-- Snapshot rows: preserve signed values and scope flags.
SELECT * FROM dian_monthly_screenshots ORDER BY month;

-- Paired chart-ready data (absolute display magnitudes).
SELECT month_number, month, fob_2025_usd_m, fob_2026_usd_m, weight_2025_m_kg, weight_2026_m_kg, row_status_as_displayed
FROM dian_monthly_comparison ORDER BY month_number;

-- Core comparable C-labelled months.
SELECT year, SUM(fob_magnitude_usd_m) AS fob_usd_m, SUM(weight_magnitude_m_kg) AS weight_m_kg,
 SUM(fob_magnitude_usd_m) / SUM(weight_magnitude_m_kg) AS ratio_usd_per_kg
FROM dian_monthly_screenshots WHERE month_number <= 8 GROUP BY year;

-- Known reconciliation failures.
SELECT * FROM dian_validation;
