#!/usr/bin/env python3
"""Refresh public WITS annual tables without assuming failed requests mean zero.

Network execution was not possible in the delivery session. Parser self-test passed.
Example: python scrape_wits_annual.py --start 2017 --end 2025 --out refreshed_wits
Outputs preserve WITS partner labels exactly; they do not apply analyst corrections.
"""
from __future__ import annotations
import argparse,csv,json,time,urllib.request
from datetime import datetime,timezone
from decimal import Decimal
from html.parser import HTMLParser
from pathlib import Path

class TableRows(HTMLParser):
    def __init__(self):
        super().__init__();self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='tr':self.row=[]
        if tag in ('td','th') and self.row is not None:self.cell=[]
    def handle_data(self,text):
        if self.cell is not None:self.cell.append(text)
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.cell is not None:
            self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
        if tag=='tr' and self.row is not None:
            self.rows.append(self.row);self.row=None

def parse_table(html: str,year: int,hs: str,url: str) -> list[dict]:
    parser=TableRows();parser.feed(html);rows=[]
    for cells in parser.rows:
        if len(cells)!=9 or cells[0]!='Colombia' or not cells[1].startswith('Import') or cells[2]!=hs or cells[4]!=str(year):continue
        value=Decimal(cells[6].replace(',',''))
        qty=Decimal(cells[7].replace(',','')) if cells[7] else None
        if qty is not None and cells[8].lower() not in ('kg','kilogram','kilograms'):
            raise ValueError(f'Unexpected quantity unit {cells[8]!r}; preserve and review rather than assume kg.')
        rows.append({'year':year,'frequency':'A','reporter':'Colombia','flow':'Imports','hs6':hs,
                     'product_description':cells[3],'partner_reported':cells[5],
                     'trade_value_1000usd':str(value),'import_value_cif_usd':str(value*1000),
                     'reported_quantity_kg':str(qty) if qty is not None else None,
                     'quantity_status':'reported' if qty is not None else 'missing_not_zero',
                     'source_url':url,'accessed_at_utc':datetime.now(timezone.utc).isoformat(timespec='seconds')})
    if sum(r['partner_reported']=='World' for r in rows)!=1:
        raise ValueError('Expected exactly one World row; page absent, changed, or not a data table.')
    return rows

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--start',type=int,default=2017);p.add_argument('--end',type=int,default=2025)
    p.add_argument('--hs',nargs='+',default=['271111','271121']);p.add_argument('--out',type=Path,default=Path('refreshed_wits'))
    p.add_argument('--self-test',action='store_true');a=p.parse_args()
    if a.self_test:
        html='<table><tr><td>Colombia</td><td>Import</td><td>271111</td><td>Natural gas, liquefied</td><td>2025</td><td>World</td><td>1,234.56</td><td></td><td></td></tr></table>'
        r=parse_table(html,2025,'271111','test://synthetic')[0]
        assert r['import_value_cif_usd']=='1234560.00' and r['reported_quantity_kg'] is None
        print('PASS: synthetic HTML parser test only.');return
    if a.start>a.end:p.error('--start must not exceed --end')
    if any(h not in ['271111','271121'] for h in a.hs):p.error('Only natural-gas HS 271111 and 271121 are supported.')
    a.out.mkdir(parents=True,exist_ok=True);(a.out/'raw_html').mkdir(exist_ok=True)
    rows=[];failures=[]
    for year in range(a.start,a.end+1):
        for hs in a.hs:
            url=f'https://wits.worldbank.org/trade/comtrade/en/country/COL/year/{year}/tradeflow/Imports/partner/ALL/product/{hs}'
            try:
                request=urllib.request.Request(url,headers={'User-Agent':'Colombia-gas-research/1.0'})
                with urllib.request.urlopen(request,timeout=60) as response:html=response.read().decode('utf-8',errors='strict')
                (a.out/'raw_html'/f'{year}_{hs}.html').write_text(html,encoding='utf-8')
                parsed=parse_table(html,year,hs,url);rows.extend(parsed)
                print(f'{year} {hs}: {len(parsed)} rows')
            except Exception as exc:
                failures.append({'year':year,'hs6':hs,'source_url':url,'error':str(exc)})
                print(f'{year} {hs}: NOT RETRIEVED ({exc})')
            time.sleep(1)
    for name,is_world in [('annual_world',True),('annual_partners',False)]:
        selected=[r for r in rows if (r['partner_reported']=='World')==is_world]
        if selected:
            with (a.out/f'{name}.csv').open('w',newline='',encoding='utf-8-sig') as f:
                w=csv.DictWriter(f,fieldnames=list(selected[0]));w.writeheader();w.writerows(selected)
    (a.out/'retrieval_failures.json').write_text(json.dumps(failures,indent=2),encoding='utf-8')
    print(f'Completed: {len(rows)} retrieved rows; {len(failures)} failed year/product requests. Failed requests are not zeros.')
    if not rows:raise SystemExit('No data retrieved; existing verified files have not been overwritten.')

if __name__=='__main__':main()
