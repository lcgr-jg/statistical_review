# Colombia gas trade: monthly screenshot update

Snapshot: 27 October 2026.

## Start here
- Excel: Monthly dashboard, Monthly comparison, Monthly long, Period analysis.
- monthly_comparison_chart_ready.csv: ten paired months, useful for graphs.
- monthly_gas_dian_screenshot.csv: 20 year-month observations.
- SQLite: new tables start with dian_; inherited historical tables are retained.

## Provenance and scope
New monthly figures were visually transcribed from two user-supplied DIAN dashboard screenshots, not directly scraped from Power BI. Original images are in evidence/ and embedded in the workbook. DIAN documentation specifies USD millions and million kg. Values are rounded to two decimals. Product/HS, partner/national scope, trade-flow choice and exact cutoff are not visible. Verified HS fields remain NULL. Negative values are preserved; positive columns are ABS values, not automatically verified gross imports. If the source is a net-trade view, verify exports before interpreting the ratio as an import unit value.

The C/O field is a shared label on each comparison row: C Jan-Aug, O Sep-Oct. It is not independently confirmed for each year's observation. C means certificadas, O observadas, not an assurance against all future revisions. October 2026 is incomplete as of the snapshot date; the comparable-day cutoff for 2025 is unknown. November/December are not invented or zero-filled.

## Important reconciliation failure
Visible Jan-Oct 2025 rows sum to FOB magnitude USD 676.77m and weight 1,223.45m kg. Displayed totals are USD 710.14m and 1,293.11m kg, gaps of USD 33.37m and 69.66m kg. These cannot be attributed to display rounding. No cause is established. Totals are stored separately, never as an extra monthly record.

2026 visible rows sum exactly to the displayed magnitudes, USD 1,553.25m and 2,074.45m kg. These include an incomplete October.

## Core calculations
January-August C-labelled rows: FOB magnitude USD 580.95m -> USD 1,024.51m, +76.3508%; weight 1,019.20m kg -> 1,579.59m kg, +54.9833%; ratio USD 0.570006/kg -> USD 0.648592/kg, +13.7870%. The additional FOB magnitude is USD 443.56m. These calculations assume the displayed rows have the same selection.

Exact accounting split: delta V = ratio25 * delta Q + Q26 * delta ratio. Interaction belongs to the ratio effect. This is not causal identification. It is an import-cost interpretation only when confirmed gross-import values and weights have the same scope. No conversion to MMBtu or gas volumes has been assumed.

DANE's Jan-Aug goods trade deficit widened from USD 10,604.5m to USD 13,877.1m, a change of USD 3,272.6m. USD 443.56m is approximately 13.6% of that change. This is a conditional scale comparison, not a fully reconciled causal contribution.

## Compatibility
Historical CIF series and new FOB screenshot data remain separate. The monthly_national microdata table remains empty because the cropped screenshots cannot verify tariff/flow scope. New dian_ tables are ready to use with explicit flags. The original annual scraping and DANE loading scripts are included unchanged; their prior limitations remain.

## Sources
https://www.dian.gov.co/dian/cifras/Paginas/EstadisticasComEx.aspx
https://www.dian.gov.co/dian/cifras/Paginas/Avance-de-Comercio-Exterior.aspx
https://www.dian.gov.co/dian/cifras/Documents/Ficha-tecnica-visualizador-de-datos-de-comercio-exterior.pdf
https://www.dane.gov.co/files/operaciones/IMP/bol-IMP-ago2026.pdf
https://app.powerbi.com/view?r=eyJrIjoiZjk4OWFjMGUtNzhiOC00YjA1LTljODItNmFmYjViNWFjMTc1IiwidCI6ImZhYjI2ZTVhLTczN2EtNDQzOC04Y2NkLThlNDY1ZWNmMjFkOCIsImMiOjR9
