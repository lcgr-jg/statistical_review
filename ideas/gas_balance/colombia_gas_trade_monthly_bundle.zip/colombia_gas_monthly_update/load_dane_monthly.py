#!/usr/bin/env python3
"""Filter public DANE import archives into monthly natural-gas datasets.

This loader was tested on synthetic CSV/ZIP fixtures, not on DANE's live ZIPs.
No API key is needed for local files. A direct public ZIP URL can be supplied.
Examples:
  python load_dane_monthly.py --input raw/Impo_2025_1.zip raw/Impo_2025_2.zip raw/Impo_2026.zip --out output
  python load_dane_monthly.py --url 'DIRECT_PUBLIC_ZIP_URL' --out output
  python load_dane_monthly.py --self-test
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import re
import sqlite3
import sys
import tempfile
import urllib.request
import zipfile
from collections import defaultdict
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterator

CODES = {'2711110000': 'LNG', '2711210000': 'Natural gas, gaseous'}
CATALOG = 'https://microdatos.dane.gov.co/index.php/catalog/856/get-microdata'
REQUIRED = {'FECH','NABAN','PAISGEN','VAFODO','VACID','PNK'}
NUMERIC_FIELDS = {'fob_usd': 'VAFODO', 'cif_usd': 'VACID', 'net_weight_kg': 'PNK'}
NULLS = {'','NA','N/A','NULL','NONE','NAN','.'}


def parse_number(value: Any, decimal: str = 'auto') -> Decimal | None:
    text = str(value if value is not None else '').strip().replace('\u00a0','').replace(' ','')
    if text.upper() in NULLS:
        return None
    if decimal == 'comma':
        text = text.replace('.','').replace(',','.')
    elif decimal == 'dot':
        text = text.replace(',','')
    elif ',' in text and '.' in text:
        if text.rfind(',') > text.rfind('.'):
            text = text.replace('.','').replace(',','.')
        else:
            text = text.replace(',','')
    elif ',' in text:
        if re.fullmatch(r'[+-]?\d+,\d{3}', text):
            raise ValueError(f'Ambiguous numeric text {text!r}; specify --decimal comma or --decimal dot.')
        text = text.replace(',','.')
    try:
        number = Decimal(text)
        if not number.is_finite():
            raise ValueError(f'Non-finite number {value!r}')
        return number
    except InvalidOperation as exc:
        raise ValueError(f'Invalid numeric value {value!r}') from exc


def parse_month(value: Any) -> str:
    text = str(value).strip()
    if re.fullmatch(r'\d+\.0+',text):
        text = text.split('.')[0]
    if re.fullmatch(r'\d{4}', text):
        yy, mm = int(text[:2]), int(text[2:])
        yyyy = 2000+yy if yy < 80 else 1900+yy
    elif re.fullmatch(r'\d{6}', text):
        yyyy, mm = int(text[:4]), int(text[4:])
    elif re.fullmatch(r'\d{8}', text):
        yyyy, mm = int(text[:4]), int(text[4:6])
    else:
        for fmt in ('%Y-%m-%d','%Y-%m','%d/%m/%Y','%m/%Y','%Y/%m/%d'):
            try:
                d = datetime.strptime(text, fmt)
                return date(d.year,d.month,1).isoformat()
            except ValueError:
                continue
        raise ValueError(f'Unsupported FECH value {value!r}; expected YYMM, YYYYMM or a supported date.')
    if not 1980 <= yyyy <= 2099:
        raise ValueError(f'Unexpected year in FECH={value!r}')
    return date(yyyy,mm,1).isoformat()


def normalise_code(value: Any) -> str:
    text = str(value).strip()
    try:
        n = Decimal(text)
        if n != n.to_integral_value():
            return ''
        return str(int(n))
    except InvalidOperation:
        return re.sub(r'[^0-9]','',text)


def country_name(raw_code: str, month: str) -> tuple[str,str]:
    # Do not apply UN country codes to pre-2025 Colombian ALADI codes.
    scheme = 'M49' if int(month[:4]) >= 2025 else 'ALADI'
    code = raw_code.zfill(3)
    if scheme == 'M49':
        try:
            import pycountry
            item = pycountry.countries.get(numeric=code)
            if item:
                return item.name, scheme
        except ImportError:
            pass
    return f'{scheme}:{code}', scheme


def csv_rows(stream: Any, label: str, encoding: str, delimiter: str | None) -> Iterator[dict[str,str]]:
    # Buffered streaming avoids loading an entire customs archive into RAM.
    wrapper = io.TextIOWrapper(stream, encoding=encoding, errors='strict', newline='')
    sample = ''.join(wrapper.readline() for _ in range(8))
    try:
        delim = delimiter or csv.Sniffer().sniff(sample, delimiters=',;\t|').delimiter
    except csv.Error as exc:
        raise ValueError(f'Cannot detect delimiter for {label}; specify --delimiter.') from exc
    import itertools
    reader = csv.DictReader(itertools.chain(io.StringIO(sample),wrapper), delimiter=delim)
    if not reader.fieldnames:
        raise ValueError(f'No header in {label}')
    reader.fieldnames = [x.lstrip('\ufeff').strip().upper() for x in reader.fieldnames]
    if not REQUIRED.issubset(reader.fieldnames):
        raise ValueError(f'{label}: missing columns {sorted(REQUIRED-set(reader.fieldnames))}; actual columns {reader.fieldnames}')
    for row_number,row in enumerate(reader,start=2):
        if None in row:
            raise ValueError(f'{label}:{row_number}: too many fields; verify delimiter/quoting.')
        row['_LINE'] = str(row_number)
        yield row


def archive_rows(path: Path, encoding: str, delimiter: str | None) -> Iterator[tuple[str,dict[str,str]]]:
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            members = [n for n in archive.namelist() if not n.endswith('/') and Path(n).suffix.lower() in {'.csv','.txt','.tsv'}]
            if not members:
                raise ValueError(f'{path.name}: no CSV/TXT/TSV member. Extract/convert the archive format first; contents: {archive.namelist()[:12]}')
            for member in members:
                label = f'{path.name}::{member}'
                with archive.open(member) as stream:
                    for row in csv_rows(stream,label,encoding,delimiter):
                        yield label,row
    elif path.suffix.lower() in {'.csv','.txt','.tsv'}:
        with path.open('rb') as stream:
            for row in csv_rows(stream,path.name,encoding,delimiter):
                yield path.name,row
    else:
        raise ValueError(f'Unsupported input {path}. Expected ZIP, CSV, TXT or TSV.')


def download(url: str, folder: Path, index: int) -> Path:
    if not url.lower().startswith(('https://','http://')):
        raise ValueError('--url must be a public HTTP(S) address.')
    target = folder / f'download_{index:02d}.zip'
    request = urllib.request.Request(url, headers={'User-Agent':'Colombia-gas-research/1.0'})
    with urllib.request.urlopen(request,timeout=120) as response, target.open('wb') as file:
        content_type = response.headers.get('Content-Type','').lower()
        if 'text/html' in content_type:
            raise ValueError('Download returned HTML, possibly a login/consent page. Download the public file in a browser and use --input.')
        while block := response.read(1024*1024):
            file.write(block)
    if not zipfile.is_zipfile(target):
        raise ValueError(f'{url}: response is not a ZIP archive; no data were ingested.')
    return target


def aggregate(paths: list[Path], *, encoding: str='utf-8-sig', delimiter: str | None=None,
              decimal: str='auto', allow_overlap: bool=False) -> tuple[list[dict],list[dict],list[dict]]:
    groups: dict[tuple,dict] = {}
    coverage: dict[tuple,dict] = {}
    hashes: set[str] = set()
    member_months: dict[str,set[str]] = defaultdict(set)
    for path in paths:
        hasher = hashlib.sha256()
        with path.open('rb') as stream:
            while block := stream.read(1024*1024):
                hasher.update(block)
        digest = hasher.hexdigest()
        if digest in hashes:
            raise ValueError(f'Duplicate input file content detected: {path}')
        hashes.add(digest)
        for member,row in archive_rows(path,encoding,delimiter):
            try:
                month = parse_month(row['FECH'])
                member_months[month].add(member)
                key_cov = (member,month)
                cov = coverage.setdefault(key_cov,{'source_file':member,'month':month,'all_product_rows':0,'gas_rows':0,'sha256_archive':digest})
                cov['all_product_rows'] += 1
                hs10 = normalise_code(row['NABAN'])
                if hs10 not in CODES:
                    continue
                cov['gas_rows'] += 1
                partner = normalise_code(row['PAISGEN']).zfill(3)
                name,scheme = country_name(partner,month)
                key = (month,hs10,partner,scheme)
                g = groups.setdefault(key,{'month':month,'hs6':hs10[:6],'hs10':hs10,'product':CODES[hs10],
                    'partner_code':partner,'country_scheme':scheme,'partner_name':name,'record_count':0,
                    **{k:Decimal(0) for k in NUMERIC_FIELDS},
                    **{f'missing_{k}':0 for k in NUMERIC_FIELDS},'negative_value_records':0,
                    'cif_below_fob_records':0,'source_files':set()})
                values = {name:parse_number(row[col],decimal) for name,col in NUMERIC_FIELDS.items()}
                for metric,value in values.items():
                    if value is None:
                        g[f'missing_{metric}'] += 1
                    else:
                        g[metric] += value
                if any(v is not None and v < 0 for v in values.values()):
                    g['negative_value_records'] += 1
                if values['cif_usd'] is not None and values['fob_usd'] is not None and values['cif_usd'] < values['fob_usd']:
                    g['cif_below_fob_records'] += 1
                g['record_count'] += 1
                g['source_files'].add(member)
            except Exception as exc:
                raise ValueError(f'{member}:{row.get("_LINE","?")}: {exc}') from exc
    overlaps = {month:sorted(members) for month,members in member_months.items() if len(members)>1}
    if overlaps and not allow_overlap:
        raise ValueError('More than one input member covers the same month. Verify the files are disjoint, not revisions; rerun with --allow-overlap only after verification. '+json.dumps(overlaps))
    if not groups:
        raise ValueError('No natural-gas records matched HS 2711110000 / 2711210000. No empty dataset was exported.')
    monthly=[]
    for _,g in sorted(groups.items()):
        row = dict(g)
        row['source_files']=' | '.join(sorted(row['source_files']))
        for k in NUMERIC_FIELDS:
            row[k] = None if row[f'missing_{k}'] else float(row[k])
        row['cif_usd_per_tonne'] = row['cif_usd']/row['net_weight_kg']*1000 if row['cif_usd'] is not None and row['net_weight_kg'] is not None and row['net_weight_kg']>0 else None
        row['source_url']=CATALOG
        row['loaded_at_utc']=datetime.now(timezone.utc).isoformat(timespec='seconds')
        monthly.append(row)
    totals=[]
    for key in sorted({(r['month'],r['hs6']) for r in monthly}):
        subset=[r for r in monthly if (r['month'],r['hs6'])==key]
        row={'month':key[0],'hs6':key[1],'product':subset[0]['product'],'record_count':sum(x['record_count'] for x in subset)}
        for k in NUMERIC_FIELDS:
            row[k]=sum(x[k] for x in subset) if all(x[k] is not None for x in subset) else None
        row['cif_usd_per_tonne']=row['cif_usd']/row['net_weight_kg']*1000 if row['cif_usd'] is not None and row['net_weight_kg'] is not None and row['net_weight_kg']>0 else None
        row['coverage']='Matched records in supplied archives; verify archive completeness against DANE releases'
        row['source_url']=CATALOG
        totals.append(row)
    return monthly,totals,list(coverage.values())


def export(rows: list[dict],totals: list[dict],coverage: list[dict],out: Path) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from openpyxl.chart import LineChart, Reference
    out.mkdir(parents=True,exist_ok=True)
    tables={'monthly_partner':rows,'monthly_totals':totals,'input_coverage':coverage}
    for name,data in tables.items():
        with (out/f'{name}.csv').open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
    with sqlite3.connect(out/'dane_monthly.sqlite') as db:
        for name,data in tables.items():
            db.execute(f'DROP TABLE IF EXISTS "{name}"')
            cols=list(data[0]); types=[]
            for col in cols:
                examples=[r[col] for r in data if r[col] is not None]
                typ='REAL' if examples and isinstance(examples[0],float) else ('INTEGER' if examples and isinstance(examples[0],int) else 'TEXT')
                types.append(f'"{col}" {typ}')
            db.execute(f'CREATE TABLE "{name}" ({",".join(types)})')
            db.executemany(f'INSERT INTO "{name}" VALUES ({",".join("?" for _ in cols)})',[[r.get(c) for c in cols] for r in data])
    wb=Workbook();wb.remove(wb.active)
    for name,data in tables.items():
        ws=wb.create_sheet(name); headers=list(data[0]);ws.append(headers)
        for r in data:
            values=[]
            for col in headers:
                value=r[col]
                if col=='month': value=date.fromisoformat(value)
                values.append(value)
            ws.append(values)
        ws.freeze_panes='D2';ws.sheet_view.showGridLines=False
        for c in ws[1]: c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='19394B');c.alignment=Alignment(wrap_text=True,vertical='center')
        ws.row_dimensions[1].height=32
        for col in ws.columns:
            key=col[0].value
            ws.column_dimensions[col[0].column_letter].width=22 if key not in {'source_url','source_files','coverage'} else 65
            for cell in list(col)[1:]:
                cell.alignment=Alignment(vertical='center',wrap_text=key in {'source_url','source_files','coverage'})
                if key=='month': cell.number_format='mmm yyyy'
                elif isinstance(cell.value,(float,int)): cell.number_format='#,##0.00;[Red](#,##0.00);"-"'
        tab=Table(displayName='T_'+name,ref=ws.dimensions);tab.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True);ws.add_table(tab)
    chart_ws=wb.create_sheet('LNG chart')
    chart_ws.append(['Month','LNG CIF US$ million'])
    lng=[r for r in totals if r['hs6']=='271111']
    for row in lng: chart_ws.append([date.fromisoformat(row['month']),row['cif_usd']/1e6 if row['cif_usd'] is not None else None])
    for c in chart_ws['A'][1:]: c.number_format='mmm yyyy'
    if lng:
        chart=LineChart();chart.title='LNG imports: supplied archives';chart.y_axis.title='US$ million, CIF';chart.x_axis.title='Month'
        chart.add_data(Reference(chart_ws,min_col=2,min_row=1,max_row=len(lng)+1),titles_from_data=True)
        chart.set_categories(Reference(chart_ws,min_col=1,min_row=2,max_row=len(lng)+1));chart.height=12;chart.width=23
        chart_ws.add_chart(chart,'D2')
    wb.save(out/'dane_monthly.xlsx')
    (out/'load_manifest.json').write_text(json.dumps({'loaded_at_utc':datetime.now(timezone.utc).isoformat(),'source_catalog':CATALOG,'monthly_partner_rows':len(rows),'monthly_total_rows':len(totals),'period_start':min(r['month'] for r in rows),'period_end':max(r['month'] for r in rows),'warning':'Missing/unloaded months are not zero. Do not combine overlapping archive revisions.'},indent=2),encoding='utf-8')


def self_test() -> None:
    assert parse_month('2501')=='2025-01-01'
    assert parse_month('202608')=='2026-08-01'
    assert parse_number('1.234,56')==Decimal('1234.56')
    assert parse_number('1,234.56')==Decimal('1234.56')
    assert parse_number('') is None
    assert normalise_code('2711110000.0')=='2711110000'
    with tempfile.TemporaryDirectory() as tmp:
        p=Path(tmp)/'synthetic_fixture.zip'
        text='FECH;NABAN;PAISGEN;VAFODO;VACID;PNK\n2501;2711110000;840;100.00;110.00;5\n2501;2711110000;840;200.00;220.00;10\n2501;2711210000;036;20;22;1\n2501;2711120000;840;999;999;999\n2502;2711110000;780;30;33;\n'
        with zipfile.ZipFile(p,'w') as z: z.writestr('synthetic.csv',text)
        rows,totals,cov=aggregate([p]);assert len(rows)==3 and len(totals)==3
        jan=[r for r in rows if r['month']=='2025-01-01' and r['hs6']=='271111'][0]
        assert (jan['fob_usd'],jan['cif_usd'],jan['net_weight_kg'])==(300,330,15)
        assert jan['cif_usd_per_tonne']==22000
        feb=[r for r in rows if r['month']=='2025-02-01'][0];assert feb['net_weight_kg'] is None
        assert sum(r['all_product_rows'] for r in cov)==5
        try:
            aggregate([p,p]);raise AssertionError('Duplicate files accepted')
        except ValueError as exc:
            assert 'Duplicate' in str(exc)
    print('PASS: synthetic tests only. Live DANE archives were not downloaded or validated in this session.')


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--input',nargs='*',type=Path,default=[])
    parser.add_argument('--url',action='append',default=[],help='Direct public DANE ZIP URL; repeat for multiple archives')
    parser.add_argument('--out',type=Path,default=Path('dane_output'))
    parser.add_argument('--encoding',default='utf-8-sig',help='Use cp1252 for legacy files if UTF-8 decoding fails')
    parser.add_argument('--delimiter',default=None,help='Optional separator, such as ;')
    parser.add_argument('--decimal',choices=['auto','dot','comma'],default='auto')
    parser.add_argument('--allow-overlap',action='store_true',help='Only for confirmed disjoint archive parts covering the same month')
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test: self_test();return
    if not args.input and not args.url: parser.error('Provide --input archive(s) or --url direct ZIP address(es).')
    paths=list(args.input)
    if args.url:
        download_dir=args.out/'downloads';download_dir.mkdir(parents=True,exist_ok=True)
        paths.extend(download(url,download_dir,i) for i,url in enumerate(args.url,1))
    rows,totals,coverage=aggregate(paths,encoding=args.encoding,delimiter=args.delimiter,decimal=args.decimal,allow_overlap=args.allow_overlap)
    export(rows,totals,coverage,args.out)
    print(f'Exported {len(rows)} monthly partner rows and {len(totals)} month/product totals to {args.out.resolve()}')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        sys.exit(1)
