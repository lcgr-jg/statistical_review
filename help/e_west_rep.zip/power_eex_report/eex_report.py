"""
EEX Power Settlement Report.

Builds an email-friendly HTML table of EEX power settlement prices, day-on-day
changes and traded volumes (MW) for each strip (tenor) and country, and sends
it via email.

All styling is inline (no <style> block, no CSS classes) so the table renders
correctly in Outlook and other email clients, which strip <head> CSS and do not
support selectors like nth-child.

Usage:
    python eex_report.py                     # dry run: writes HTML, no email
    python eex_report.py --send              # send to default recipients
    python eex_report.py --send -r a@x,b@y   # send to specific recipients
"""

from datetime import datetime
from pathlib import Path

import pandas as pd
from pandas.tseries.offsets import BusinessDay

from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery
from jain_commods.core.util.emailhelper import send_email

DEFAULT_RECIPIENTS = "michael.kane@jainglobal.com"

FONT = "Arial, Helvetica, sans-serif"

# Country display order; core markets get a darker header to anchor the eye.
# SEE/CEE markets (GR, SK, RO, BG, RS, SI) are included in case the upstream
# Snowflake ingestion (POWER_DERIVS_FUTURE_PRICES) ever starts covering them --
# any country present in the data but missing here is appended at the end anyway.
COUNTRY_ORDER = ['DE', 'FR', 'NL', 'BE', 'CH', 'AT', 'ES', 'IT', 'HU', 'CZ', 'SK', 'PL',
                 'GR', 'RO', 'BG', 'RS', 'SI', 'GB']
CORE_COUNTRIES = {'DE', 'FR', 'NL'}

TENOR_LABELS = {
    1: "Day Contracts",
    2: "Weekend Contracts",
    3: "Week Contracts",
    4: "Month Contracts",
    5: "Quarter Contracts",
    7: "Year Contracts",
}

# Max number of strips to show per short-dated tenor bucket
TENOR_LIMITS = {1: 3, 2: 2, 3: 3, 4: 3}


def get_trading_days():
    """Get the last two business days (T-1 and T-2)."""
    today = pd.Timestamp.now().normalize()
    t1 = (today - BusinessDay(1)).date()
    t2 = (today - BusinessDay(2)).date()
    return t1, t2


def get_tenor_sort_key(strip):
    strip = str(strip).upper()
    if strip.startswith("CAL"): return 7
    if strip in ["SUM", "WIN"] or "SUM-" in strip or "WIN-" in strip: return 6
    if strip.startswith("Q"): return 5
    if len(strip) >= 6 and strip[3] == "-" and strip[:3] in ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']: return 4
    # Check Weekend BEFORE Week (WK)
    if "WEEKEND" in strip or "WKEND" in strip or "W/E" in strip: return 2
    if strip.startswith("WK"): return 3
    if any(day in strip for day in ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]): return 1
    return 8


def get_color_hex(value, min_val, max_val):
    """
    Return a hex color string for a value within a range using GnYlRd colormap
    logic for SETTLEMENT prices: low -> green, high -> red.
    """
    if pd.isna(value):
        return None

    if max_val == min_val:
        norm = 0.5
    else:
        norm = (value - min_val) / (max_val - min_val)

    green = (26, 152, 80)     # #1A9850
    yellow = (255, 255, 191)  # #FFFFBF
    red = (215, 48, 39)       # #D73027

    if norm <= 0.5:
        t = norm * 2
        r = int(green[0] + (yellow[0] - green[0]) * t)
        g = int(green[1] + (yellow[1] - green[1]) * t)
        b = int(green[2] + (yellow[2] - green[2]) * t)
    else:
        t = (norm - 0.5) * 2
        r = int(yellow[0] + (red[0] - yellow[0]) * t)
        g = int(yellow[1] + (red[1] - yellow[1]) * t)
        b = int(yellow[2] + (red[2] - yellow[2]) * t)

    return f"#{r:02x}{g:02x}{b:02x}"


def get_color_hex_chg(value, min_val, max_val):
    """
    Return a hex color string for CHANGE values using a soft RdYlGn colormap,
    symmetric around 0 so that 0 is always visually neutral:
    strong negative -> soft red, ~0 -> pale yellow, strong positive -> soft green.
    """
    if pd.isna(value):
        return None

    max_abs = max(abs(min_val), abs(max_val))
    if max_abs == 0 or pd.isna(max_abs):
        norm = 0.5
    else:
        norm = (value + max_abs) / (2 * max_abs)

    norm = max(0.0, min(1.0, norm))

    red_soft = (252, 146, 114)    # #fc9272
    yellow_soft = (255, 255, 204) # #ffffcc
    green_soft = (161, 217, 155)  # #a1d99b

    if norm <= 0.5:
        t = norm * 2
        r = int(red_soft[0] + (yellow_soft[0] - red_soft[0]) * t)
        g = int(red_soft[1] + (yellow_soft[1] - red_soft[1]) * t)
        b = int(red_soft[2] + (yellow_soft[2] - red_soft[2]) * t)
    else:
        t = (norm - 0.5) * 2
        r = int(yellow_soft[0] + (green_soft[0] - yellow_soft[0]) * t)
        g = int(yellow_soft[1] + (green_soft[1] - yellow_soft[1]) * t)
        b = int(yellow_soft[2] + (green_soft[2] - yellow_soft[2]) * t)

    return f"#{r:02x}{g:02x}{b:02x}"


def _build_dataframe(t1, t2):
    """Load, merge and filter EEX strip prices for T-1 vs T-2. Returns None if no data."""
    eex = EEXQuery()

    df1 = eex.get_strip_prices(trading_day=t1, profile='Base')
    df2 = eex.get_strip_prices(trading_day=t2, profile='Base')

    if df1.empty:
        return None

    if df2.empty:
        df2 = pd.DataFrame(columns=df1.columns)

    df = pd.merge(
        df1,
        df2[['STRIP', 'COUNTRY_CODE', 'PRODUCT', 'SETTLEMENT_PRICE']],
        on=['STRIP', 'COUNTRY_CODE', 'PRODUCT'],
        how='left',
        suffixes=('', '_PREV'),
    )

    df['CHANGE'] = df['SETTLEMENT_PRICE'] - df['SETTLEMENT_PRICE_PREV']

    today = datetime.now().date()
    end_of_next_year = datetime(today.year + 1, 12, 31).date()

    df['DELIVERY_START'] = pd.to_datetime(df['DELIVERY_START'])
    df['DELIVERY_END'] = pd.to_datetime(df['DELIVERY_END'])

    # Contract duration in hours for MWh -> MW conversion (Base profile, 24h/day;
    # ignores DST 23/25h days which is standard for a rough MW figure)
    df['DAYS_DURATION'] = (df['DELIVERY_END'] - df['DELIVERY_START']).dt.days + 1
    df['HOURS_DURATION'] = df['DAYS_DURATION'] * 24

    df['DELIVERY_START'] = df['DELIVERY_START'].dt.date
    df['DELIVERY_END'] = df['DELIVERY_END'].dt.date

    df['TRADED_MW'] = df['TRADED_VOLUME'] / df['HOURS_DURATION']

    mask = (df['DELIVERY_START'] >= today) & (df['DELIVERY_END'] <= end_of_next_year)
    df = df[mask].copy()

    if df.empty:
        return None

    # Fix Week 53 labelling (end-of-year week is contextually Week 01 of next year)
    df['STRIP'] = df['STRIP'].str.replace('WK53', 'WK01', regex=False)

    df['TENOR_ORDER'] = df['STRIP'].apply(get_tenor_sort_key)

    # Remove Seasons
    df = df[df['TENOR_ORDER'] != 6].copy()

    # Limit the number of short-dated strips shown per tenor bucket
    unique_strips = df[['TENOR_ORDER', 'DELIVERY_START', 'STRIP']].drop_duplicates()
    unique_strips = unique_strips.sort_values(['TENOR_ORDER', 'DELIVERY_START'])

    strips_to_keep = []
    for tenor, limit in TENOR_LIMITS.items():
        current = unique_strips[unique_strips['TENOR_ORDER'] == tenor]
        if not current.empty:
            strips_to_keep.extend(current.head(limit)['STRIP'].tolist())

    strips_to_keep.extend(
        unique_strips[unique_strips['TENOR_ORDER'].isin([5, 7])]['STRIP'].tolist()
    )

    return df[df['STRIP'].isin(strips_to_keep)].copy()


def _build_html(df, t1, t2):
    """Render the report as a single HTML string with all styles inline (email-safe)."""
    available = [c.upper() for c in df['COUNTRY_CODE'].unique()]
    countries = [c for c in COUNTRY_ORDER if c in available]
    countries += [c for c in available if c not in countries]

    min_setl = df['SETTLEMENT_PRICE'].min()
    max_setl = df['SETTLEMENT_PRICE'].max()

    row_keys = (
        df[['TENOR_ORDER', 'DELIVERY_START', 'STRIP']]
        .drop_duplicates()
        .sort_values(['TENOR_ORDER', 'DELIVERY_START'])
    )

    # --- Inline style building blocks -------------------------------------
    base_cell = (
        f"font-family:{FONT}; font-size:11px; border:1px solid #d9d9d9; "
        "padding:4px 4px; text-align:right; white-space:nowrap; color:#222;"
    )
    # Bold divider on the right edge of each country block
    country_edge = "border-right:2px solid #666;"

    th_style = (
        f"font-family:{FONT}; font-size:11px; border:1px solid #d9d9d9; "
        "padding:5px 4px; text-align:center; font-weight:bold; "
        "background-color:#f2f2f2; color:#333; white-space:nowrap;"
    )
    th_core_style = th_style.replace("#f2f2f2", "#dcdcdc")
    row_header_style = base_cell + " text-align:left; font-weight:bold; background-color:#fafafa;"
    tenor_header_style = (
        f"font-family:{FONT}; font-size:12px; font-weight:bold; color:#ffffff; "
        "background-color:#4a4a4a; padding:5px 6px; text-align:left; "
        "border:1px solid #4a4a4a;"
    )

    html = []
    html.append('<!DOCTYPE html>')
    html.append('<html><body style="margin:0; padding:10px; background-color:#ffffff;">')

    # Title block
    html.append(
        f'<div style="font-family:{FONT}; font-size:16px; font-weight:bold; color:#1a1a1a; '
        f'padding-bottom:2px;">EEX Power Settlement Prices &mdash; Base</div>'
    )
    html.append(
        f'<div style="font-family:{FONT}; font-size:12px; color:#555; padding-bottom:8px;">'
        f'Settlement date: <b>{t1}</b> &nbsp;|&nbsp; Change vs: {t2} &nbsp;|&nbsp; '
        f'Prices in &euro;/MWh, volumes in MW</div>'
    )

    html.append('<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;">')

    # Header rows
    html.append('<tr>')
    html.append(f'<th rowspan="2" style="{th_style} text-align:left;">STRIP</th>')
    for country in countries:
        style = th_core_style if country in CORE_COUNTRIES else th_style
        html.append(f'<th colspan="3" style="{style} {country_edge}">{country}</th>')
    html.append('</tr>')

    html.append('<tr>')
    for _ in countries:
        html.append(f'<th style="{th_style}">Setl.</th>')
        html.append(f'<th style="{th_style}">Chg.</th>')
        html.append(f'<th style="{th_style} {country_edge}">Vol.</th>')
    html.append('</tr>')

    # Data rows
    current_tenor = -1
    zebra_idx = 0
    n_cols = 1 + len(countries) * 3

    for _, row in row_keys.iterrows():
        tenor = row['TENOR_ORDER']
        strip = row['STRIP']

        # Shared per-row colormap range for the Chg. heatmap across countries
        row_slice = df[df['STRIP'] == strip]
        row_min_chg = row_slice['CHANGE'].min()
        row_max_chg = row_slice['CHANGE'].max()

        if tenor != current_tenor:
            label = TENOR_LABELS.get(tenor, "Other")
            html.append(f'<tr><td colspan="{n_cols}" style="{tenor_header_style}">{label}</td></tr>')
            current_tenor = tenor
            zebra_idx = 0

        row_bg = "#ffffff" if zebra_idx % 2 == 0 else "#f7f7f7"
        zebra_idx += 1
        cell = base_cell + f" background-color:{row_bg};"

        html.append('<tr>')
        html.append(f'<td style="{row_header_style}">{strip}</td>')

        for country in countries:
            mask = (df['STRIP'] == strip) & (df['COUNTRY_CODE'].str.upper() == country)
            data = df[mask]

            if not data.empty:
                val = data.iloc[0]
                setl = val['SETTLEMENT_PRICE']
                chg = val['CHANGE']
                vol_mw = val['TRADED_MW']

                # Settlement with GnYlRd heatmap (green = low, red = high)
                setl_str, setl_cell = "", cell
                if pd.notna(setl):
                    setl_str = f"{setl:.2f}"
                    setl_cell = base_cell + f" background-color:{get_color_hex(setl, min_setl, max_setl)};"

                # Change: soft heatmap background + colored arrow/text
                chg_str, chg_cell = "", cell
                if pd.notna(chg):
                    arrow = "&#9650;" if chg > 0 else ("&#9660;" if chg < 0 else "")
                    txt_color = "#1a7a3c" if chg > 0 else ("#b03a2e" if chg < 0 else "#555")
                    chg_str = f'<span style="color:{txt_color};">{arrow} {chg:+.2f}</span>'
                    bg = get_color_hex_chg(chg, row_min_chg, row_max_chg)
                    chg_cell = base_cell + f" background-color:{bg};"

                vol_str = f"{vol_mw:,.0f}" if pd.notna(vol_mw) else ""

                html.append(f'<td style="{setl_cell}">{setl_str}</td>')
                html.append(f'<td style="{chg_cell}">{chg_str}</td>')
                html.append(f'<td style="{cell} {country_edge} color:#555;">{vol_str}</td>')
            else:
                html.append(f'<td style="{cell}"></td>')
                html.append(f'<td style="{cell}"></td>')
                html.append(f'<td style="{cell} {country_edge}"></td>')

        html.append('</tr>')

    html.append('</table>')

    # Footer / legend
    html.append(
        f'<div style="font-family:{FONT}; font-size:10px; color:#888; padding-top:8px;">'
        'Setl. heatmap: green = low price, red = high (across all cells). '
        'Chg. heatmap: red = down, green = up (per row). '
        'Vol. = traded volume converted to MW (traded MWh / delivery hours).<br>'
        f'Source: EEX via Snowflake. Generated {datetime.now().strftime("%Y-%m-%d %H:%M")} UK.'
        '</div>'
    )

    html.append('</body></html>')
    return "".join(html)


def generate_eex_report(recipients=None, dry_run=False, output_path=None):
    """
    Generate the EEX settlement report, save it as HTML and email it.

    Args:
        recipients: comma-separated email addresses (defaults to DEFAULT_RECIPIENTS)
        dry_run: if True, build and save the HTML but do not send the email
        output_path: where to write the HTML file (defaults to this folder)

    Returns:
        dict with report metadata (for Dagster).
    """
    if not recipients:
        recipients = DEFAULT_RECIPIENTS

    t1, t2 = get_trading_days()
    print(f"Generating EEX report for {t1} (vs {t2})")

    df = _build_dataframe(t1, t2)
    if df is None or df.empty:
        print("No EEX data available - skipping report.")
        return {
            "status": "no_data",
            "settlement_date": str(t1),
            "email_sent": False,
            "recipients": recipients,
        }

    html = _build_html(df, t1, t2)

    if output_path is None:
        output_path = Path(__file__).parent / "eex_report.html"
    output_path = Path(output_path)
    output_path.write_text(html, encoding="utf-8")
    print(f"Report saved to {output_path}")

    subject = f"EEX Power Settlements - {t1.strftime('%a %d %b %Y')} (Base)"

    email_sent = False
    if dry_run:
        print(f"[DRY RUN] Would send email to: {recipients}")
    else:
        print(f"Sending email to {recipients}...")
        send_email(recipients=recipients, subject=subject, body=html)
        email_sent = True
        print("Email sent successfully.")

    countries = sorted(df['COUNTRY_CODE'].str.upper().unique())
    return {
        "status": "ok",
        "settlement_date": str(t1),
        "comparison_date": str(t2),
        "num_strips": int(df['STRIP'].nunique()),
        "countries": ", ".join(countries),
        "email_sent": email_sent,
        "recipients": recipients,
        "html_path": str(output_path),
    }


def run_eex_report(recipients=None, dry_run=False):
    """Entry point for Dagster."""
    return generate_eex_report(recipients=recipients, dry_run=dry_run)


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description="EEX Power Settlement Report")
    parser.add_argument("--send", action="store_true",
                        help="Actually send the email (default is dry run)")
    parser.add_argument("-r", "--recipients", default=None,
                        help="Comma-separated email recipients")
    args = parser.parse_args()

    generate_eex_report(recipients=args.recipients, dry_run=not args.send)
