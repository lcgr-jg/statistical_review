import io
import base64

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Patch

from datetime import datetime

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.interfaces.snowflake import BloombergHerenQuery
from jain_commods.fundamental.gas import util

# ── Chart Style Configuration ──────────────────────────────────────────────────
CHART_STYLE = {
    'font.family': 'sans-serif',
    'font.sans-serif': ['Segoe UI', 'Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 9,
    'axes.titlesize': 10,
    'axes.titleweight': 500,
    'axes.labelsize': 8,
    'axes.linewidth': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'xtick.labelsize': 7,
    'ytick.labelsize': 7,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.major.size': 3,
    'ytick.major.size': 3,
    'legend.fontsize': 7,
    'legend.framealpha': 0.95,
    'legend.edgecolor': '#cccccc',
    'legend.borderpad': 0.4,
    'legend.handlelength': 1.5,
    'figure.dpi': 150,
    'savefig.dpi': 150,
    'grid.linewidth': 0.4,
    'grid.alpha': 0.4,
    'lines.linewidth': 1.2,
    'lines.markersize': 3,
}

COLORS = {
    'primary': '#2E86AB',
    'text_muted': '#666666',
    'grid': '#E0E0E0',
    'zero_line': '#333333',
}

COUNTRY_COLORS = {
    'AT': '#1f77b4',
    'BE': '#ff7f0e',
    'DE': '#2ca02c',
    'FR': '#d62728',
    'GB': '#9467bd',
    'IT': '#8c564b',
    'NL': '#e377c2',
    'Total': '#17becf',
}


def get_eu_gas_balances(dt, scenarios=['Basecase','HormuzNov26']):

    # NB: we query the previous days balance as this report runs early in the morning
    output={}
    for scenario in scenarios:
        output[scenario] = util.get_eu_gas_balance(scenario_name=scenario, ref_date= dt - pd.offsets.BDay(1))
    return output


def generate_forecast_fill_table(balances: dict) -> str:
    """
    Generate an HTML table showing forecast storage fill % for key dates.

    Parameters
    ----------
    balances : dict
        Dict of balance scenarios from get_eu_gas_balances().

    Returns
    -------
    str
        HTML table string.
    """
    # Define target dates and their display labels
    # First row is historical (Basecase only), rest are forecasts (all scenarios)
    target_dates = [
        (pd.Timestamp('2026-03-31'), 'End Mar-26', True),   # Basecase only
        (pd.Timestamp('2026-10-31'), 'End Oct-26', False),
        (pd.Timestamp('2027-03-31'), 'End Mar-27', False),
        (pd.Timestamp('2027-10-31'), 'End Oct-27', False),
    ]
    
    # Get scenario names (in order)
    scenario_names = list(balances.keys())
    
    # Build table data
    table_data = []
    for target_date, label, basecase_only in target_dates:
        row_data = {'Date': label}
        for scenario_name in scenario_names:
            # If basecase_only, skip non-Basecase scenarios
            if basecase_only and scenario_name != 'Basecase':
                row_data[scenario_name] = ''
                continue
            
            try:
                df_balance = balances[scenario_name].get('balance_daily')
                if df_balance is not None:
                    # Handle tuple column name
                    if ('Storage', 'Fill %') in df_balance.columns:
                        fill_col = ('Storage', 'Fill %')
                    elif 'Storage_Fill %' in df_balance.columns:
                        fill_col = 'Storage_Fill %'
                    else:
                        row_data[scenario_name] = '-'
                        continue
                    
                    # Get value for target date (or closest available)
                    if target_date in df_balance.index:
                        fill_pct = df_balance.loc[target_date, fill_col]
                    else:
                        # Find closest date
                        closest_idx = df_balance.index.get_indexer([target_date], method='nearest')[0]
                        if closest_idx >= 0 and closest_idx < len(df_balance):
                            fill_pct = df_balance.iloc[closest_idx][fill_col]
                        else:
                            fill_pct = None
                    
                    if pd.notna(fill_pct):
                        row_data[scenario_name] = f"{fill_pct * 100:.0f}%"
                    else:
                        row_data[scenario_name] = '-'
                else:
                    row_data[scenario_name] = '-'
            except Exception:
                row_data[scenario_name] = '-'
        
        table_data.append(row_data)
    
    # Generate HTML table
    html = """
<table style="border-collapse: collapse; font-size: 12px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;">
  <thead>
    <tr style="background-color: #2c3e50; color: white;">
      <th style="padding: 6px 12px; text-align: left; border: 1px solid #2c3e50;">Date</th>
"""
    
    for scenario_name in scenario_names:
        html += f'      <th style="padding: 6px 12px; text-align: center; border: 1px solid #2c3e50;">{scenario_name}</th>\n'
    
    html += """    </tr>
  </thead>
  <tbody>
"""
    
    for i, row in enumerate(table_data):
        bg_color = '#f8f9fa' if i % 2 == 1 else 'white'
        
        html += f'    <tr style="background-color: {bg_color};">\n'
        html += f'      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; font-weight: bold;">{row["Date"]}</td>\n'
        
        for scenario_name in scenario_names:
            val = row.get(scenario_name, '-')
            html += f'      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; text-align: center;">{val}</td>\n'
        
        html += '    </tr>\n'
    
    html += """  </tbody>
</table>
"""
    
    return html


def _apply_chart_style():
    """Apply professional chart styling via rcParams."""
    plt.rcParams.update(CHART_STYLE)


def _style_axis(ax, title=None, ylabel=None):
    """Apply consistent axis styling."""
    if title:
        ax.set_title(title, pad=8, color='#333333')
    if ylabel:
        ax.set_ylabel(ylabel, color=COLORS['text_muted'])
    
    ax.tick_params(axis='both', colors='#555555')
    ax.spines['left'].set_color('#CCCCCC')
    ax.spines['bottom'].set_color('#CCCCCC')
    
    ax.grid(axis='y', linestyle='-', color=COLORS['grid'], alpha=0.5, linewidth=0.4)
    ax.grid(axis='x', visible=False)
    ax.set_axisbelow(True)


def get_heren_prices(start_date=datetime(2026,4,1)):
    
    heren = BloombergHerenQuery()
    # IINDTEDA ICIS Index = ICIS TTF EUR/MWh Day Ahead
    # IINDTESW ICIS Index = ICIS TTF EUR/MWh WKND SPOT
    # IINDTEMA ICIS Index = ICIS TTF EUR/MWh Daily MthA
    n_days = (datetime.now() - start_date).days + 10
    res = heren.get_latest_prices(['IINDTEDA ICIS Index','IINDTEMA ICIS Index','IINDTESW ICIS Index'], n_days=n_days) 
    prices = res.pivot(index='DATE',columns='SECURITY_NAME', values='VALUE')
    # Rename columns
    prices = prices.rename(columns={'ICIS TTF EUR/MWh Day Ahead': 'Day Ahead',
                                    'ICIS TTF EUR/MWh WKND SPOT': 'Wkend Ahead',
                                    'ICIS TTF EUR/MWh Daily MthA': 'Month Ahead',})
    
    # Reindex to ALL calendar days first    
    full_calendar = pd.date_range(start=prices.index.min(), end=prices.index.max(), freq='D')
    prices = prices.reindex(full_calendar)
    
    # Forward-fill Wkend Ahead so Friday's value propagates into subsequent gap rows
    wkend_ffill = prices['Wkend Ahead'].ffill()
    
    # Merge DA and WKEND
    prices['Spot Prices'] = np.where(prices['Day Ahead'].notna(), prices['Day Ahead'], wkend_ffill)
    
    prices['Month Ahead'] = prices['Month Ahead'].ffill()
    prices['DA/FM'] = prices['Spot Prices'] - prices['Month Ahead']
    
    return prices



def get_ce_storage_data(ce_user: str, ce_pass: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Fetch European gas storage data from CommodityEdge.

    Returns:
        df_storage_inj:  Daily net injection by country (MCM), with 'Total' column.
        df_storage_fill: Daily stock & capacity by country (MCM), cols like 'DE|stock',
                         with 'Total|stock' and 'Total|stockCapacity' columns.
    """
    ASSET_IDS: dict[str, int] = {
        'AT': 1768,
        'BE': 677,
        'DE': 688,
        'FR': 458,
        'GB': 468,
        'IT': 1780,
        'NL': 477,
    }
    ASSET_IDS_STR   = ','.join(str(v) for v in ASSET_IDS.values())
    ASSET_IDS_REV   = {v: k for k, v in ASSET_IDS.items()}
    COMMON_KWARGS   = dict(assets=ASSET_IDS_STR, unit='mcm', dateFrom=2018)

    ce = CElink(ce_user, ce_pass)

    # ── Metadata (used for column renaming) ──────────────────────────────────
    df_meta = ce.eugasopdata(
        **COMMON_KWARGS,
        variable='netInjection,stock,stockCapacity',
        meta=True,
    )

    def _country(col: str) -> str:
        """Map a raw CE column name → ISO-2 country code via metadata."""
        raw_id = df_meta.loc[df_meta['seriesId'] == 'assetId', col].iloc[0]
        return ASSET_IDS_REV[int(raw_id)]

    def _variable(col: str) -> str:
        """Return the variable label (stock / stockCapacity) for a CE column."""
        return df_meta.loc[df_meta['seriesId'] == 'Variable', col].iloc[0]

    def _load(variable: str) -> pd.DataFrame:
        """Pull a CE dataset, set a DatetimeIndex, drop the Excel date column."""
        return (
            ce.eugasopdata(**COMMON_KWARGS, variable=variable)
            .set_index('Date')
            .drop(columns=['DateExcel'])
            .pipe(lambda df: df.set_index(pd.to_datetime(df.index)))
        )

    # ── Net injection ────────────────────────────────────────────────────────
    df_inj = _load('netInjection')
    df_inj.columns = [_country(c) for c in df_inj.columns]
    # Calculate Total treating NaN as 0, but keep NaN in country columns for display
    df_inj['Total'] = df_inj.fillna(0).sum(axis=1)

    # ── Stock & capacity ─────────────────────────────────────────────────────
    df_fill = _load('stock,stockCapacity').dropna()
    df_fill.columns = [f"{_country(c)}|{_variable(c)}" for c in df_fill.columns]
    # Use regex to match columns ending with |stock (not |stockCapacity)
    df_fill['Total|stock']         = df_fill.filter(regex=r'\|stock$').sum(axis=1)
    df_fill['Total|stockCapacity'] = df_fill.filter(like='|stockCapacity').sum(axis=1)

    return df_inj, df_fill


def calculate_injection_since_april(df_inj: pd.DataFrame, to_date: pd.Timestamp) -> pd.DataFrame:
    """
    Calculate total gas injection from 1st April to a given date for each year.

    Parameters
    ----------
    df_inj : pd.DataFrame
        Daily net injection by country with datetime index.
        Columns: ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']
    to_date : pd.Timestamp
        The end date to calculate to (typically today).

    Returns
    -------
    pd.DataFrame
        DataFrame with years as index and countries + Total as columns.
        Values are cumulative injection (MCM) from 1st April to the equivalent
        day of the year as to_date.
    """
    # Extract month and day from the target date
    target_month = pd.Timestamp(to_date).month
    target_day = pd.Timestamp(to_date).day
    
    # Get the range of years available in the data
    min_year = df_inj.index.min().year
    max_year = df_inj.index.max().year
    
    apr_comparison = []
    
    for year in range(min_year, max_year + 1):
        start = f'{year}-04-01'
        end = f'{year}-{target_month:02d}-{target_day:02d}'
        
        # Only include if we're past April 1st for the comparison
        if target_month < 4:
            # If current date is before April, skip current year
            if year == max_year:
                continue
        
        try:
            period_data = df_inj.loc[start:end]
            if not period_data.empty:
                totals = period_data.sum()
                totals['Year'] = year
                apr_comparison.append(totals)
        except KeyError:
            # Date range not available in data
            continue
    
    if not apr_comparison:
        return pd.DataFrame()
    
    df_apr_comparison = pd.DataFrame(apr_comparison).set_index('Year')
    df_apr_comparison.index = df_apr_comparison.index.astype(int)
    
    return df_apr_comparison


def generate_injection_chart(df_apr_injection: pd.DataFrame, to_date: pd.Timestamp) -> str:
    """
    Generate a bar chart showing injection since April 1st for each year.

    Parameters
    ----------
    df_apr_injection : pd.DataFrame
        DataFrame with years as index and countries + Total as columns.
        Values are cumulative injection in MCM.
    to_date : pd.Timestamp
        The end date used for the calculation (for chart title).

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    # Convert MCM to BCM
    df_bcm = df_apr_injection / 1000
    
    # Get country columns (excluding Total)
    country_cols = [c for c in df_bcm.columns if c != 'Total']
    n_countries = len(country_cols)
    
    # Calculate grid layout: Total on top spanning 2 cols, countries in 2 cols below
    n_rows_countries = (n_countries + 1) // 2
    
    # Create figure with gridspec
    fig = plt.figure(figsize=(12, 4 + n_rows_countries * 2.2), facecolor='white')
    gs = gridspec.GridSpec(1 + n_rows_countries, 2, figure=fig, 
                           height_ratios=[1.5] + [1] * n_rows_countries,
                           hspace=0.4, wspace=0.25)
    
    date_str = pd.Timestamp(to_date).strftime('%d %b')
    years = df_bcm.index.astype(str).tolist()
    x = np.arange(len(years))
    
    def plot_bars(ax, data, title, color):
        """Helper to plot bars with labels."""
        bars = ax.bar(x, data, color=color, width=0.65, edgecolor='white', linewidth=0.5)
        
        for bar in bars:
            height = bar.get_height()
            va = 'bottom' if height >= 0 else 'top'
            ax.annotate(f'{height:.1f}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3 if height >= 0 else -3),
                        textcoords='offset points',
                        ha='center', va=va,
                        fontsize=7, fontweight='medium', color='#333333')
        
        ax.set_xticks(x)
        ax.set_xticklabels(years, rotation=0)
        ax.axhline(0, color=COLORS['zero_line'], linewidth=0.6, linestyle='-', alpha=0.4)
        _style_axis(ax, title=title, ylabel='bcm')
    
    # ── Total chart (top, spanning both columns) ──────────────────────────────
    ax_total = fig.add_subplot(gs[0, :])
    plot_bars(ax_total, df_bcm['Total'].values, 
              f'Total Injection (01 Apr - {date_str})', 
              COUNTRY_COLORS['Total'])
    
    # ── Country charts (2 columns below) ──────────────────────────────────────
    for i, country in enumerate(country_cols):
        row = 1 + i // 2
        col = i % 2
        ax = fig.add_subplot(gs[row, col])
        plot_bars(ax, df_bcm[country].values,
                  country,
                  COUNTRY_COLORS.get(country, COLORS['primary']))
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_cumulative_injection_chart(df_inj: pd.DataFrame, to_date: pd.Timestamp) -> str:
    """
    Generate a line chart showing cumulative daily injection from 1st April.

    The chart extends to end of current month, or to end of next month if
    the current day is past the 15th. Includes 3-year and 5-year average lines
    for Total, plus per-country charts below.

    Parameters
    ----------
    df_inj : pd.DataFrame
        Daily net injection by country with datetime index.
        Columns: ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']
    to_date : pd.Timestamp
        The current date (used to determine chart range and current year).

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    import calendar
    
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    current_month = to_date.month
    current_day = to_date.day
    
    # Determine end month: if past 15th, extend to next month
    if current_day > 15:
        if current_month == 12:
            end_month = 1
            end_year_offset = 1
        else:
            end_month = current_month + 1
            end_year_offset = 0
    else:
        end_month = current_month
        end_year_offset = 0
    
    # Get last day of end month (for current year to determine max days)
    end_month_last_day = calendar.monthrange(current_year + end_year_offset, end_month)[1]
    
    # Calculate days from April 1st to end of period
    max_days = (pd.Timestamp(f'{current_year + end_year_offset}-{end_month:02d}-{end_month_last_day:02d}') 
                - pd.Timestamp(f'{current_year}-04-01')).days + 1
    
    # Get available years
    min_year = df_inj.index.min().year
    max_year = df_inj.index.max().year
    years = list(range(min_year, max_year + 1))
    
    # Color palette for years
    year_colors = [
        '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
        '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
    ]
    
    # Get country columns (excluding Total)
    country_cols = [c for c in df_inj.columns if c != 'Total']
    n_countries = len(country_cols)
    n_rows_countries = (n_countries + 1) // 2
    
    # Create figure with gridspec
    fig = plt.figure(figsize=(14, 5 + n_rows_countries * 2.5), facecolor='white')
    gs = gridspec.GridSpec(1 + n_rows_countries, 2, figure=fig,
                           height_ratios=[1.8] + [1] * n_rows_countries,
                           hspace=0.35, wspace=0.25)
    
    # Exclude 2021 from averages (Gazprom outlier)
    exclude_years = {2021}
    
    def get_cumulative_data(column):
        """Get cumulative data for all years for a given column."""
        yearly_data = {}
        for year in years:
            if year == current_year:
                year_end = to_date
            else:
                year_end_year = year + end_year_offset
                year_end_last_day = calendar.monthrange(year_end_year, end_month)[1]
                year_end = pd.Timestamp(f'{year_end_year}-{end_month:02d}-{year_end_last_day:02d}')
            
            start = f'{year}-04-01'
            try:
                period_data = df_inj.loc[start:year_end, column]
                if not period_data.empty:
                    yearly_data[year] = period_data.cumsum() / 1000
            except KeyError:
                continue
        return yearly_data
    
    def calc_average(yearly_data, years_for_avg):
        """Calculate average cumulative injection for given years."""
        filtered_years = [y for y in years_for_avg if y not in exclude_years]
        available = [yearly_data[y].values for y in filtered_years if y in yearly_data]
        if not available:
            return None, None
        max_len = max(len(a) for a in available)
        padded = []
        for a in available:
            if len(a) < max_len:
                padded.append(np.concatenate([a, np.full(max_len - len(a), np.nan)]))
            else:
                padded.append(a)
        avg = np.nanmean(padded, axis=0)
        return range(1, len(avg) + 1), avg
    
    def plot_cumulative(ax, yearly_data, title, show_averages=False, show_legend=False, show_xlabel=False):
        """Plot cumulative lines for a column."""
        for i, year in enumerate(years):
            if year not in yearly_data:
                continue
            cumulative = yearly_data[year]
            x_vals = range(1, len(cumulative) + 1)
            is_current = (year == current_year)
            color = year_colors[i % len(year_colors)]
            
            if is_current:
                ax.plot(x_vals, cumulative.values,
                        label=str(year),
                        color=color,
                        linewidth=2.5,
                        marker='o',
                        markersize=3,
                        markevery=max(1, len(cumulative) // 15),
                        zorder=10)
            else:
                ax.plot(x_vals, cumulative.values,
                        label=str(year),
                        color=color,
                        linewidth=1,
                        alpha=0.7,
                        zorder=1)
        
        if show_averages:
            # 5-year average
            years_5yr = list(range(current_year - 5, current_year))
            x_5yr, avg_5yr = calc_average(yearly_data, years_5yr)
            if avg_5yr is not None:
                ax.plot(x_5yr, avg_5yr, label='5yr Avg', color='#333333',
                        linewidth=2.0, linestyle='--', alpha=0.8, zorder=8)
            
            # 3-year average
            years_3yr = list(range(current_year - 3, current_year))
            x_3yr, avg_3yr = calc_average(yearly_data, years_3yr)
            if avg_3yr is not None:
                ax.plot(x_3yr, avg_3yr, label='3yr Avg', color='#666666',
                        linewidth=2.0, linestyle=':', alpha=0.8, zorder=9)
        
        ax.axhline(0, color=COLORS['zero_line'], linewidth=0.6, linestyle='-', alpha=0.4)
        ax.set_xlim(1, max_days)
        if show_xlabel:
            ax.set_xlabel('Days from 1st April', color=COLORS['text_muted'])
        _style_axis(ax, title=title, ylabel='bcm')
        
        if show_legend:
            ax.legend(title='Year', bbox_to_anchor=(1.02, 1), loc='upper left',
                      frameon=True, fancybox=True)
    
    # ── Total chart (top, spanning both columns) ──────────────────────────────
    ax_total = fig.add_subplot(gs[0, :])
    total_data = get_cumulative_data('Total')
    end_month_name = calendar.month_abbr[end_month]
    plot_cumulative(ax_total, total_data,
                    f'Cumulative Total Injection (01 Apr - {end_month_last_day:02d} {end_month_name})',
                    show_averages=True, show_legend=True, show_xlabel=True)
    
    # Add note about 2021 exclusion
    fig.text(0.99, 0.72,
             'Note: 2021 excluded from averages\n(Gazprom did not fill DE storage)',
             ha='right', va='top',
             fontsize=7, color='#666666', style='italic',
             transform=fig.transFigure)
    
    # ── Country charts (2 columns below) ──────────────────────────────────────
    for i, country in enumerate(country_cols):
        row = 1 + i // 2
        col = i % 2
        ax = fig.add_subplot(gs[row, col])
        country_data = get_cumulative_data(country)
        plot_cumulative(ax, country_data, country,
                        show_averages=False, show_legend=False, show_xlabel=False)
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_storage_level_chart(df_fill: pd.DataFrame, to_date: pd.Timestamp) -> str:
    """
    Generate line charts showing percent storage fill throughout the year.
    
    Total chart at top spanning 2 columns, individual country charts in 2 columns below.

    Parameters
    ----------
    df_fill : pd.DataFrame
        Daily stock and capacity data with datetime index.
        Must contain columns like 'XX|stock' and 'XX|stockCapacity' for each country,
        plus 'Total|stock' and 'Total|stockCapacity'.
    to_date : pd.Timestamp
        The current date (used to identify current year).

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Get available years
    min_year = df_fill.index.min().year
    max_year = df_fill.index.max().year
    years = list(range(min_year, max_year + 1))
    
    # Color palette for years
    year_colors = [
        '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
        '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
    ]
    
    # Month x-axis settings
    month_starts = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
    month_labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    # Countries (excluding Total)
    country_cols = ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL']
    n_countries = len(country_cols)
    n_rows_countries = (n_countries + 1) // 2
    
    # Create figure with gridspec
    fig = plt.figure(figsize=(14, 5 + n_rows_countries * 2.5), facecolor='white')
    gs = gridspec.GridSpec(1 + n_rows_countries, 2, figure=fig,
                           height_ratios=[1.8] + [1] * n_rows_countries,
                           hspace=0.35, wspace=0.25)
    
    def get_pct_fill_data(country):
        """Get percentage fill data for all years for a given country."""
        yearly_data = {}
        for year in years:
            start = f'{year}-01-01'
            end = f'{year}-12-31'
            
            try:
                if year == current_year:
                    if country == 'Total':
                        stock = df_fill.loc[start:to_date, 'Total|stock']
                        capacity = df_fill.loc[start:to_date, 'Total|stockCapacity']
                    else:
                        stock = df_fill.loc[start:to_date, f'{country}|stock']
                        capacity = df_fill.loc[start:to_date, f'{country}|stockCapacity']
                else:
                    if country == 'Total':
                        stock = df_fill.loc[start:end, 'Total|stock']
                        capacity = df_fill.loc[start:end, 'Total|stockCapacity']
                    else:
                        stock = df_fill.loc[start:end, f'{country}|stock']
                        capacity = df_fill.loc[start:end, f'{country}|stockCapacity']
                
                if not stock.empty:
                    pct_fill = (stock / capacity) * 100
                    yearly_data[year] = pct_fill
            except KeyError:
                continue
        return yearly_data
    
    def plot_pct_fill(ax, yearly_data, title, show_legend=False):
        """Plot percentage fill lines for a country."""
        for i, year in enumerate(years):
            if year not in yearly_data:
                continue
            pct_fill = yearly_data[year]
            day_of_year = pct_fill.index.dayofyear
            
            is_current = (year == current_year)
            color = year_colors[i % len(year_colors)]
            
            if is_current:
                ax.plot(day_of_year, pct_fill.values,
                        label=str(year),
                        color=color,
                        linewidth=2.5,
                        marker='o',
                        markersize=3,
                        markevery=max(1, len(pct_fill) // 15),
                        zorder=10)
            else:
                ax.plot(day_of_year, pct_fill.values,
                        label=str(year),
                        color=color,
                        linewidth=1,
                        alpha=0.7,
                        zorder=1)
        
        ax.set_xticks(month_starts)
        ax.set_xticklabels(month_labels)
        ax.set_xlim(1, 366)
        ax.set_ylim(0, 105)
        _style_axis(ax, title=title, ylabel='%')
        
        if show_legend:
            ax.legend(title='Year', bbox_to_anchor=(1.02, 1), loc='upper left',
                      frameon=True, fancybox=True)
    
    # ── Total chart (top, spanning both columns) ──────────────────────────────
    ax_total = fig.add_subplot(gs[0, :])
    total_data = get_pct_fill_data('Total')
    plot_pct_fill(ax_total, total_data, 'Total Storage Fill', show_legend=True)
    
    # ── Country charts (2 columns below) ──────────────────────────────────────
    for i, country in enumerate(country_cols):
        row = 1 + i // 2
        col = i % 2
        ax = fig.add_subplot(gs[row, col])
        country_data = get_pct_fill_data(country)
        plot_pct_fill(ax, country_data, country, show_legend=False)
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_storage_fill_table(df_fill: pd.DataFrame, to_date: pd.Timestamp) -> str:
    """
    Generate an HTML table showing current storage fill % and historical averages.

    Parameters
    ----------
    df_fill : pd.DataFrame
        Daily stock and capacity data with datetime index.
        Must contain columns like 'XX|stock' and 'XX|stockCapacity' for each country,
        plus 'Total|stock' and 'Total|stockCapacity'.
    to_date : pd.Timestamp
        The current date.

    Returns
    -------
    str
        HTML table string.
    """
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Get the latest available date in the data
    latest_date = df_fill.index.max()
    if latest_date > to_date:
        latest_date = df_fill.loc[:to_date].index.max()
    
    latest_day_of_year = latest_date.dayofyear
    
    # Countries to include (in order)
    countries = ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']
    
    def get_fill_pct(date, country):
        """Get fill percentage for a country on a given date."""
        try:
            if country == 'Total':
                stock = df_fill.loc[date, 'Total|stock']
                capacity = df_fill.loc[date, 'Total|stockCapacity']
            else:
                stock = df_fill.loc[date, f'{country}|stock']
                capacity = df_fill.loc[date, f'{country}|stockCapacity']
            return (stock / capacity) * 100
        except KeyError:
            return None
    
    def get_avg_fill_pct(country, n_years):
        """Get average fill % for the same day of year over past n years."""
        values = []
        for year_offset in range(1, n_years + 1):
            year = current_year - year_offset
            # Find the date with the same day of year
            try:
                target_date = pd.Timestamp(f'{year}-01-01') + pd.Timedelta(days=latest_day_of_year - 1)
                # Check if date exists in data
                if target_date in df_fill.index:
                    pct = get_fill_pct(target_date, country)
                    if pct is not None:
                        values.append(pct)
            except:
                continue
        
        if values:
            return np.mean(values)
        return None
    
    # Build table data
    table_data = []
    for country in countries:
        current_pct = get_fill_pct(latest_date, country)
        avg_3yr = get_avg_fill_pct(country, 3)
        avg_5yr = get_avg_fill_pct(country, 5)
        avg_7yr = get_avg_fill_pct(country, 7)
        table_data.append({
            'Country': country,
            'Current': current_pct,
            '3yr Avg': avg_3yr,
            '5yr Avg': avg_5yr,
            '7yr Avg': avg_7yr,
        })
    
    # Generate HTML table
    date_str = latest_date.strftime('%d %b')
    
    html = f"""
<table style="border-collapse: collapse; font-size: 12px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;">
  <thead>
    <tr style="background-color: #2c3e50; color: white;">
      <th style="padding: 6px 12px; text-align: left; border: 1px solid #2c3e50;">Country</th>
      <th style="padding: 6px 12px; text-align: center; border: 1px solid #2c3e50;">Current ({date_str})</th>
      <th style="padding: 6px 12px; text-align: center; border: 1px solid #2c3e50;">3yr Avg</th>
      <th style="padding: 6px 12px; text-align: center; border: 1px solid #2c3e50;">5yr Avg</th>
      <th style="padding: 6px 12px; text-align: center; border: 1px solid #2c3e50;">7yr Avg</th>
    </tr>
  </thead>
  <tbody>
"""
    
    for i, row in enumerate(table_data):
        bg_color = '#f8f9fa' if i % 2 == 1 else 'white'
        is_total = row['Country'] == 'Total'
        font_weight = 'bold' if is_total else 'normal'
        
        # Format values
        current_str = f"{row['Current']:.0f}%" if row['Current'] is not None else '-'
        avg3_str = f"{row['3yr Avg']:.0f}%" if row['3yr Avg'] is not None else '-'
        avg5_str = f"{row['5yr Avg']:.0f}%" if row['5yr Avg'] is not None else '-'
        avg7_str = f"{row['7yr Avg']:.0f}%" if row['7yr Avg'] is not None else '-'
        
        # Color coding for current vs averages
        def get_color(current, avg):
            if current is None or avg is None:
                return '#333'
            diff = current - avg
            if diff > 2:
                return '#27ae60'  # Green - above average
            elif diff < -2:
                return '#e74c3c'  # Red - below average
            return '#333'  # Neutral
        
        html += f"""    <tr style="background-color: {bg_color};">
      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; font-weight: {font_weight};">{row['Country']}</td>
      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; text-align: center; font-weight: {font_weight};">{current_str}</td>
      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; text-align: center; color: {get_color(row['Current'], row['3yr Avg'])};">{avg3_str}</td>
      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; text-align: center; color: {get_color(row['Current'], row['5yr Avg'])};">{avg5_str}</td>
      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; text-align: center; color: {get_color(row['Current'], row['7yr Avg'])};">{avg7_str}</td>
    </tr>
"""
    
    html += """  </tbody>
</table>
"""
    
    return html


def calculate_apr1_fill_pct(df_fill: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate percent full on 1st April for each year.

    Parameters
    ----------
    df_fill : pd.DataFrame
        Daily stock and capacity data with datetime index.

    Returns
    -------
    pd.DataFrame
        DataFrame with years as index and countries + Total as columns.
        Values are fill percentages on 1st April.
    """
    # Get available years
    min_year = df_fill.index.min().year
    max_year = df_fill.index.max().year
    
    # Countries to include
    countries = ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']
    
    results = []
    for year in range(min_year, max_year + 1):
        date_str = f'{year}-04-01'
        try:
            if pd.Timestamp(date_str) in df_fill.index:
                row_data = {'Year': year}
                for country in countries:
                    if country == 'Total':
                        stock_col = 'Total|stock'
                        cap_col = 'Total|stockCapacity'
                    else:
                        stock_col = f'{country}|stock'
                        cap_col = f'{country}|stockCapacity'
                    
                    if stock_col in df_fill.columns and cap_col in df_fill.columns:
                        stock = df_fill.loc[date_str, stock_col]
                        capacity = df_fill.loc[date_str, cap_col]
                        row_data[country] = (stock / capacity) * 100
                    else:
                        row_data[country] = None
                results.append(row_data)
        except KeyError:
            continue
    
    if not results:
        return pd.DataFrame()
    
    df_result = pd.DataFrame(results).set_index('Year')
    return df_result


def calculate_oct31_fill_pct(df_fill: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate percent full on 31st October for each year.

    Parameters
    ----------
    df_fill : pd.DataFrame
        Daily stock and capacity data with datetime index.

    Returns
    -------
    pd.DataFrame
        DataFrame with years as index and countries + Total as columns.
        Values are fill percentages on 31st October.
    """
    # Get available years
    min_year = df_fill.index.min().year
    max_year = df_fill.index.max().year
    
    # Countries to include
    countries = ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']
    
    results = []
    for year in range(min_year, max_year + 1):
        date_str = f'{year}-10-31'
        try:
            if pd.Timestamp(date_str) in df_fill.index:
                row_data = {'Year': year}
                for country in countries:
                    if country == 'Total':
                        stock_col = 'Total|stock'
                        cap_col = 'Total|stockCapacity'
                    else:
                        stock_col = f'{country}|stock'
                        cap_col = f'{country}|stockCapacity'
                    
                    if stock_col in df_fill.columns and cap_col in df_fill.columns:
                        stock = df_fill.loc[date_str, stock_col]
                        capacity = df_fill.loc[date_str, cap_col]
                        row_data[country] = (stock / capacity) * 100
                    else:
                        row_data[country] = None
                results.append(row_data)
        except KeyError:
            continue
    
    if not results:
        return pd.DataFrame()
    
    df_result = pd.DataFrame(results).set_index('Year')
    return df_result


def calculate_injection_season_totals(df_inj: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate total gas injected during each injection season (1st April to 1st November).

    Parameters
    ----------
    df_inj : pd.DataFrame
        Daily net injection by country with datetime index.
        Columns: ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']

    Returns
    -------
    pd.DataFrame
        DataFrame with years as index and countries + Total as columns.
        Values are total injection in MCM during the injection season.
    """
    # Get available years
    min_year = df_inj.index.min().year
    max_year = df_inj.index.max().year
    
    results = []
    for year in range(min_year, max_year + 1):
        start = f'{year}-04-01'
        end = f'{year}-11-01'
        
        try:
            period_data = df_inj.loc[start:end]
            if not period_data.empty:
                totals = period_data.sum()
                totals['Year'] = year
                results.append(totals)
        except KeyError:
            continue
    
    if not results:
        return pd.DataFrame()
    
    df_result = pd.DataFrame(results).set_index('Year')
    df_result.index = df_result.index.astype(int)
    
    return df_result


def calculate_injection_needed_for_targets(df_fill: pd.DataFrame, to_date: pd.Timestamp) -> pd.DataFrame:
    """
    Calculate how much more gas needs to be injected from current level to hit
    target fill levels (75%, 80%, 85%) by 31st October.

    Parameters
    ----------
    df_fill : pd.DataFrame
        Daily stock and capacity data with datetime index.
    to_date : pd.Timestamp
        The current date (used to get latest available data).

    Returns
    -------
    pd.DataFrame
        DataFrame with countries + Total as index and columns:
        - 'Current Stock (mcm)': Current stock level
        - 'Capacity (mcm)': Total capacity
        - 'Current Fill (%)': Current fill percentage
        - 'To 75% (mcm)': Injection needed to reach 75%
        - 'To 80% (mcm)': Injection needed to reach 80%
        - 'To 85% (mcm)': Injection needed to reach 85%
    """
    to_date = pd.Timestamp(to_date)
    
    # Get the latest available date in the data
    latest_date = df_fill.index.max()
    if latest_date > to_date:
        latest_date = df_fill.loc[:to_date].index.max()
    
    # Countries to include
    countries = ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']
    
    # Target percentages
    targets = [75, 80, 85]
    
    results = []
    for country in countries:
        if country == 'Total':
            stock_col = 'Total|stock'
            cap_col = 'Total|stockCapacity'
        else:
            stock_col = f'{country}|stock'
            cap_col = f'{country}|stockCapacity'
        
        try:
            current_stock = df_fill.loc[latest_date, stock_col]
            capacity = df_fill.loc[latest_date, cap_col]
            current_pct = (current_stock / capacity) * 100
            
            row_data = {
                'Country': country,
                'Current Stock (mcm)': current_stock,
                'Capacity (mcm)': capacity,
                'Current Fill (%)': current_pct,
            }
            
            for target_pct in targets:
                target_stock = capacity * (target_pct / 100)
                needed = target_stock - current_stock
                # If already above target, set to 0
                row_data[f'To {target_pct}% (mcm)'] = max(0, needed)
            
            results.append(row_data)
        except KeyError:
            continue
    
    if not results:
        return pd.DataFrame()
    
    df_result = pd.DataFrame(results).set_index('Country')
    
    return df_result


def generate_injection_target_chart(
    df_injection_season: pd.DataFrame,
    df_apr_injection: pd.DataFrame,
    df_apr1_fill: pd.DataFrame,
    df_oct31_fill: pd.DataFrame,
    df_fill: pd.DataFrame,
    to_date: pd.Timestamp
) -> str:
    """
    Generate a bar chart showing historic injection amounts and current year progress
    toward target fill levels (75%, 80%, 85%).

    Parameters
    ----------
    df_injection_season : pd.DataFrame
        Total injection per season (years as index, 'Total' column).
    df_apr_injection : pd.DataFrame
        Injection since April 1st (years as index, 'Total' column).
    df_apr1_fill : pd.DataFrame
        Fill % on April 1st (years as index, 'Total' column).
    df_oct31_fill : pd.DataFrame
        Fill % on October 31st (years as index, 'Total' column).
    df_fill : pd.DataFrame
        Daily stock and capacity data.
    to_date : pd.Timestamp
        The current date.

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Get historic years (complete seasons only)
    historic_years = [y for y in df_injection_season.index if y < current_year]
    
    # Get current year injection so far
    current_injected = df_apr_injection.loc[current_year, 'Total'] if current_year in df_apr_injection.index else 0
    
    # Get current stock and capacity to calculate targets
    latest_date = df_fill.index.max()
    if latest_date > to_date:
        latest_date = df_fill.loc[:to_date].index.max()
    
    current_stock = df_fill.loc[latest_date, 'Total|stock']
    capacity = df_fill.loc[latest_date, 'Total|stockCapacity']
    
    # Calculate injection needed for each target
    target_75 = capacity * 0.75
    target_80 = capacity * 0.80
    target_85 = capacity * 0.85
    
    needed_to_75 = max(0, target_75 - current_stock)
    needed_to_80 = max(0, target_80 - current_stock)
    needed_to_85 = max(0, target_85 - current_stock)
    
    # Calculate incremental amounts for stacking
    stack_to_75 = needed_to_75
    stack_75_to_80 = max(0, needed_to_80 - needed_to_75)
    stack_80_to_85 = max(0, needed_to_85 - needed_to_80)
    
    # Convert to BCM
    historic_values = [df_injection_season.loc[y, 'Total'] / 1000 for y in historic_years]
    current_injected_bcm = current_injected / 1000
    stack_to_75_bcm = stack_to_75 / 1000
    stack_75_to_80_bcm = stack_75_to_80 / 1000
    stack_80_to_85_bcm = stack_80_to_85 / 1000
    
    # Create figure
    fig, ax = plt.subplots(figsize=(14, 6), facecolor='white')
    
    # X positions
    all_years = historic_years + [current_year]
    x = np.arange(len(all_years))
    
    # Colors
    color_actual = COLORS['primary']  # Blue for actual injection (historic and current)
    color_to_75 = '#a8d5ba'           # Soft green - to 75%
    color_to_80 = '#f5d6a8'           # Soft amber - 75% to 80%
    color_to_85 = '#d4a5a5'           # Soft rose - 80% to 85%
    
    # Plot historic bars
    ax.bar(x[:-1], historic_values, color=color_actual, 
           width=0.65, edgecolor='white', linewidth=0.5, label='Actual Injection')
    
    # Plot current year stacked bar
    current_x = x[-1]
    ax.bar(current_x, current_injected_bcm, color=color_actual,
           width=0.65, edgecolor='white', linewidth=0.5)
    ax.bar(current_x, stack_to_75_bcm, bottom=current_injected_bcm,
           color=color_to_75, width=0.65, edgecolor='white', linewidth=0.5, label='To 75%')
    ax.bar(current_x, stack_75_to_80_bcm, bottom=current_injected_bcm + stack_to_75_bcm,
           color=color_to_80, width=0.65, edgecolor='white', linewidth=0.5, label='75% to 80%')
    ax.bar(current_x, stack_80_to_85_bcm, 
           bottom=current_injected_bcm + stack_to_75_bcm + stack_75_to_80_bcm,
           color=color_to_85, width=0.65, edgecolor='white', linewidth=0.5, label='80% to 85%')
    
    # Add labels on historic bars showing bcm amount and fill percentages
    for i, year in enumerate(historic_years):
        bar_height = historic_values[i]
        
        # Get fill percentages
        apr1_pct = df_apr1_fill.loc[year, 'Total'] if year in df_apr1_fill.index else None
        oct31_pct = df_oct31_fill.loc[year, 'Total'] if year in df_oct31_fill.index else None
        
        if apr1_pct is not None and oct31_pct is not None:
            label_text = f"{bar_height:.1f}bcm\n({apr1_pct:.0f}%→{oct31_pct:.0f}%)"
            # Position label in the middle of the bar
            ax.text(x[i], bar_height / 2, label_text,
                    ha='center', va='center',
                    fontsize=7, color='white', fontweight='bold')
    
    # Add label on current year bar showing current fill %
    current_fill_pct = (current_stock / capacity) * 100
    
    # Label showing current status on actual injection bar
    apr1_2026 = df_apr1_fill.loc[current_year, 'Total'] if current_year in df_apr1_fill.index else None
    if apr1_2026 is not None and current_injected_bcm > 0:
        status_text = f"{current_injected_bcm:.1f}bcm\n({apr1_2026:.0f}%→{current_fill_pct:.0f}%)"
        ax.text(current_x, current_injected_bcm / 2, status_text,
                ha='center', va='center',
                fontsize=7, color='white', fontweight='bold')
    
    # Add labels on target level stacked bars
    # Calculate cumulative amounts needed to reach each target
    total_to_75 = stack_to_75_bcm
    total_to_80 = stack_to_75_bcm + stack_75_to_80_bcm
    total_to_85 = stack_to_75_bcm + stack_75_to_80_bcm + stack_80_to_85_bcm
    
    # Label for "To 75%" bar
    if stack_to_75_bcm > 0:
        bar_bottom = current_injected_bcm
        bar_center = bar_bottom + stack_to_75_bcm / 2
        ax.text(current_x, bar_center, f"{total_to_75:.1f}bcm\n(→75%)",
                ha='center', va='center',
                fontsize=7, color='#333333', fontweight='bold')
    
    # Label for "75% to 80%" bar
    if stack_75_to_80_bcm > 0:
        bar_bottom = current_injected_bcm + stack_to_75_bcm
        bar_center = bar_bottom + stack_75_to_80_bcm / 2
        ax.text(current_x, bar_center, f"{total_to_80:.1f}bcm\n(→80%)",
                ha='center', va='center',
                fontsize=7, color='#333333', fontweight='bold')
    
    # Label for "80% to 85%" bar
    if stack_80_to_85_bcm > 0:
        bar_bottom = current_injected_bcm + stack_to_75_bcm + stack_75_to_80_bcm
        bar_center = bar_bottom + stack_80_to_85_bcm / 2
        ax.text(current_x, bar_center, f"{total_to_85:.1f}bcm\n(→85%)",
                ha='center', va='center',
                fontsize=7, color='#333333', fontweight='bold')
    
    # X-axis labels
    ax.set_xticks(x)
    ax.set_xticklabels([str(y) for y in all_years], rotation=0)
    ax.set_xlim(-0.5, len(all_years) - 0.5)
    
    _style_axis(ax, title=f'Injection Season Totals vs {current_year} Targets (Total)', ylabel='')
    
    # Legend
    ax.legend(loc='upper left', frameon=True, fancybox=True)
    
    # Add annotation explaining historic % labels
    ax.annotate('Historic bars show fill level on 1st Apr → 31st Oct',
                xy=(0.5, -0.08), xycoords='axes fraction',
                ha='center', va='top',
                fontsize=8, fontstyle='italic', color='#666666')
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_daily_activity_table(df_inj: pd.DataFrame, to_date: pd.Timestamp, n_days: int = 14) -> str:
    """
    Generate an HTML table showing daily injection activity for the past n days.

    Parameters
    ----------
    df_inj : pd.DataFrame
        Daily injection data with datetime index and country columns + 'Total'.
    to_date : pd.Timestamp
        The current date.
    n_days : int
        Number of days to show (default 14).

    Returns
    -------
    str
        HTML table string.
    """
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Get the latest available date in the data
    latest_date = df_inj.index.max()
    if latest_date > to_date:
        latest_date = df_inj.loc[:to_date].index.max()
    
    # Get date range for the table (most recent n_days)
    start_date = latest_date - pd.Timedelta(days=n_days - 1)
    date_range = pd.date_range(start=start_date, end=latest_date, freq='D')
    
    # Countries to include
    countries = ['AT', 'BE', 'DE', 'FR', 'GB', 'IT', 'NL', 'Total']
    
    def get_5yr_avg_for_day(day_of_year):
        """Get 5-year average injection for a specific day of year."""
        values = []
        for year_offset in range(1, 6):  # Past 5 years
            year = current_year - year_offset
            try:
                target_date = pd.Timestamp(f'{year}-01-01') + pd.Timedelta(days=day_of_year - 1)
                if target_date in df_inj.index:
                    val = df_inj.loc[target_date, 'Total']
                    if pd.notna(val):
                        values.append(val)
            except:
                continue
        
        if values:
            return np.mean(values)
        return None
    
    # Build table header
    html = """
<table style="border-collapse: collapse; font-size: 11px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;">
  <thead>
    <tr style="background-color: #2c3e50; color: white;">
      <th style="padding: 6px 10px; text-align: left; border: 1px solid #2c3e50;">Date</th>
"""
    
    for country in countries:
        html += f'      <th style="padding: 6px 8px; text-align: center; border: 1px solid #2c3e50;">{country}</th>\n'
    
    html += """      <th style="padding: 6px 8px; text-align: center; border: 1px solid #2c3e50;">5yr Avg</th>
      <th style="padding: 6px 8px; text-align: center; border: 1px solid #2c3e50;">Δ vs Avg</th>
    </tr>
  </thead>
  <tbody>
"""
    
    # Build table rows (oldest first, latest at bottom)
    for date in date_range:
        if date not in df_inj.index:
            continue
        
        # Check if weekend
        is_weekend = date.dayofweek >= 5  # 5 = Saturday, 6 = Sunday
        
        # Background color
        if is_weekend:
            bg_color = '#f0f4f8'  # Light blue-gray for weekends
        else:
            bg_color = 'white'
        
        # Date string
        date_str = date.strftime('%d-%b-%Y')
        
        # Get injection values
        row_values = {}
        for country in countries:
            try:
                val = df_inj.loc[date, country]
                row_values[country] = val if pd.notna(val) else None
            except KeyError:
                row_values[country] = None
        
        # Get 5yr average for this day
        avg_5yr = get_5yr_avg_for_day(date.dayofyear)
        
        # Calculate delta
        total_val = row_values.get('Total')
        if total_val is not None and avg_5yr is not None:
            delta = total_val - avg_5yr
        else:
            delta = None
        
        # Build row HTML
        html += f'    <tr style="background-color: {bg_color};">\n'
        html += f'      <td style="padding: 4px 10px; border-bottom: 1px solid #eee; white-space: nowrap;">{date_str}</td>\n'
        
        for country in countries:
            val = row_values.get(country)
            if val is not None:
                # Format as integer (mcm)
                val_str = f'{val:,.0f}'
            else:
                val_str = ''  # Empty cell for missing data
            
            font_weight = 'bold' if country == 'Total' else 'normal'
            html += f'      <td style="padding: 4px 8px; border-bottom: 1px solid #eee; text-align: right; font-weight: {font_weight};">{val_str}</td>\n'
        
        # 5yr average column
        if avg_5yr is not None:
            avg_str = f'{avg_5yr:,.0f}'
        else:
            avg_str = ''
        html += f'      <td style="padding: 4px 8px; border-bottom: 1px solid #eee; text-align: right; color: #666;">{avg_str}</td>\n'
        
        # Delta column
        if delta is not None:
            delta_str = f'{delta:+,.0f}'
            if delta > 0:
                delta_color = '#27ae60'  # Green - above average
            elif delta < 0:
                delta_color = '#e74c3c'  # Red - below average
            else:
                delta_color = '#333'
        else:
            delta_str = ''
            delta_color = '#333'
        html += f'      <td style="padding: 4px 8px; border-bottom: 1px solid #eee; text-align: right; color: {delta_color}; font-weight: bold;">{delta_str}</td>\n'
        
        html += '    </tr>\n'
    
    html += """  </tbody>
</table>
<p style="font-size: 10px; color: #888; margin-top: 4px; font-style: italic;">Values in mcm. Positive values = injections, negative = withdrawals. Shaded rows = weekends. Empty cells = data not yet published.</p>
"""
    
    return html


def generate_spread_vs_injection_chart(df_inj: pd.DataFrame, df_prices: pd.DataFrame, to_date: pd.Timestamp) -> str:
    """
    Generate a chart showing the relationship between DA/FM spread and injections
    since April 1st of the current year.

    Parameters
    ----------
    df_inj : pd.DataFrame
        Daily injection data with datetime index and 'Total' column.
    df_prices : pd.DataFrame
        Price data from get_heren_prices with 'DA/FM' column.
    to_date : pd.Timestamp
        The current date.

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Define start date as April 1st of current year
    start_date = pd.Timestamp(f'{current_year}-04-01')
    
    # Filter injection data
    df_inj_filtered = df_inj.loc[start_date:to_date, 'Total'].copy()
    
    # Filter price data
    df_prices_filtered = df_prices.loc[start_date:to_date, 'DA/FM'].copy()
    
    # Align the two series on common dates
    common_dates = df_inj_filtered.index.intersection(df_prices_filtered.index)
    df_inj_aligned = df_inj_filtered.loc[common_dates]
    df_prices_aligned = df_prices_filtered.loc[common_dates]
    
    # Create figure with two subplots
    fig = plt.figure(figsize=(14, 8), facecolor='white')
    gs = gridspec.GridSpec(2, 2, figure=fig, height_ratios=[1.2, 1], hspace=0.3, wspace=0.25)
    
    # ── Top chart: Time series with dual y-axis ──────────────────────────────
    ax1 = fig.add_subplot(gs[0, :])
    
    # Plot DA/FM spread on primary y-axis
    color_spread = '#2c3e50'
    line1 = ax1.plot(df_prices_aligned.index, df_prices_aligned.values, 
                     color=color_spread, linewidth=1.5, label='DA/FM Spread')
    ax1.set_ylabel('DA/FM Spread (€/MWh)', color=color_spread)
    ax1.tick_params(axis='y', labelcolor=color_spread)
    
    # Add zero line for spread
    ax1.axhline(y=0, color='#888888', linestyle='--', linewidth=0.8, alpha=0.7)
    
    # Create secondary y-axis for injections
    ax2 = ax1.twinx()
    color_inj = '#27ae60'
    
    # Plot injections as bars
    bar_width = 0.8
    bars = ax2.bar(df_inj_aligned.index, df_inj_aligned.values, 
                   width=bar_width, color=color_inj, alpha=0.4, label='Daily Injection')
    ax2.set_ylabel('Injection (mcm)', color=color_inj)
    ax2.tick_params(axis='y', labelcolor=color_inj)
    
    # Add zero line for injections
    ax2.axhline(y=0, color=color_inj, linestyle='-', linewidth=0.5, alpha=0.3)
    
    # Styling
    ax1.set_title(f'DA/FM Spread vs Daily Injection (Since 1st April {current_year})', pad=10, color='#333333')
    ax1.xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%d %b'))
    ax1.xaxis.set_major_locator(plt.matplotlib.dates.WeekdayLocator(byweekday=0))  # Mondays
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # Combined legend
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', frameon=True)
    
    ax1.grid(axis='y', linestyle='-', color='#E0E0E0', alpha=0.5, linewidth=0.4)
    ax1.grid(axis='x', linestyle='-', color='#E0E0E0', alpha=0.3, linewidth=0.3)
    ax1.set_axisbelow(True)
    
    # ── Bottom left: Scatter plot ────────────────────────────────────────────
    ax3 = fig.add_subplot(gs[1, 0])
    
    # Remove NaN for scatter
    valid_mask = df_prices_aligned.notna() & df_inj_aligned.notna()
    x_scatter = df_prices_aligned[valid_mask]
    y_scatter = df_inj_aligned[valid_mask]
    
    ax3.scatter(x_scatter, y_scatter, alpha=0.6, color='#3498db', edgecolors='white', linewidth=0.5, s=40)
    
    # Add trend line if enough points
    if len(x_scatter) > 5:
        z = np.polyfit(x_scatter, y_scatter, 1)
        p = np.poly1d(z)
        x_line = np.linspace(x_scatter.min(), x_scatter.max(), 100)
        ax3.plot(x_line, p(x_line), color='#e74c3c', linewidth=1.5, linestyle='--', label='Trend')
        
        # Calculate correlation
        correlation = np.corrcoef(x_scatter, y_scatter)[0, 1]
        ax3.annotate(f'r = {correlation:.2f}', xy=(0.05, 0.95), xycoords='axes fraction',
                     fontsize=9, fontweight='bold', color='#333333',
                     verticalalignment='top')
    
    ax3.axhline(y=0, color='#888888', linestyle='-', linewidth=0.5, alpha=0.5)
    ax3.axvline(x=0, color='#888888', linestyle='-', linewidth=0.5, alpha=0.5)
    
    _style_axis(ax3, title='Spread vs Injection Correlation', ylabel='Injection (mcm)')
    ax3.set_xlabel('DA/FM Spread (€/MWh)', color=COLORS['text_muted'])
    ax3.legend(loc='upper right', frameon=True)
    
    # ── Bottom right: Rolling correlation ────────────────────────────────────
    ax4 = fig.add_subplot(gs[1, 1])
    
    # Calculate 7-day rolling correlation
    df_combined = pd.DataFrame({'spread': df_prices_aligned, 'injection': df_inj_aligned})
    rolling_corr = df_combined['spread'].rolling(window=7, min_periods=5).corr(df_combined['injection'])
    
    ax4.plot(rolling_corr.index, rolling_corr.values, color='#9b59b6', linewidth=1.2)
    ax4.fill_between(rolling_corr.index, rolling_corr.values, 0, alpha=0.2, color='#9b59b6')
    ax4.axhline(y=0, color='#888888', linestyle='--', linewidth=0.8, alpha=0.7)
    
    ax4.set_ylim(-1, 1)
    ax4.xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%d %b'))
    ax4.xaxis.set_major_locator(plt.matplotlib.dates.WeekdayLocator(byweekday=0, interval=2))
    plt.setp(ax4.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    _style_axis(ax4, title='7-Day Rolling Correlation', ylabel='Correlation')
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_daily_storage_action_chart(df_inj: pd.DataFrame, to_date: pd.Timestamp) -> str:
    """
    Generate a chart showing daily storage action (Total injection) with 5-year
    average and range for comparison.

    Parameters
    ----------
    df_inj : pd.DataFrame
        Daily injection data with datetime index and 'Total' column.
    to_date : pd.Timestamp
        The current date.

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Define display range: from start of previous year to current date
    start_date = pd.Timestamp(f'{current_year - 1}-01-01')
    
    # Get current period data
    df_current = df_inj.loc[start_date:to_date, 'Total'].copy()
    
    # Calculate 5-year average and range for each day of year
    def get_historical_stats(day_of_year):
        """Get 5-year avg, min, max for a given day of year."""
        values = []
        for year_offset in range(1, 6):  # Past 5 years
            year = current_year - year_offset
            try:
                # Handle leap years
                if day_of_year == 366 and not (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)):
                    continue
                target_date = pd.Timestamp(f'{year}-01-01') + pd.Timedelta(days=day_of_year - 1)
                if target_date in df_inj.index:
                    val = df_inj.loc[target_date, 'Total']
                    if pd.notna(val):
                        values.append(val)
            except:
                continue
        
        if values:
            return np.mean(values), np.min(values), np.max(values)
        return None, None, None
    
    # Build 5-year stats for the display period
    stats_data = []
    for date in df_current.index:
        avg, min_val, max_val = get_historical_stats(date.dayofyear)
        stats_data.append({
            'date': date,
            'avg': avg,
            'min': min_val,
            'max': max_val
        })
    
    df_stats = pd.DataFrame(stats_data).set_index('date')
    
    # Calculate 7-day rolling average for the smoothed line
    df_smoothed = df_current.rolling(window=7, min_periods=1, center=True).mean()
    
    # Create figure
    fig, ax = plt.subplots(figsize=(14, 5), facecolor='white')
    
    # Add light shading for injection season (1st Apr to 31st Oct)
    color_injection_season = '#e8f4e8'  # Very light green
    # Shade previous year's injection season (if in range) and current year
    for year in [current_year - 1, current_year]:
        season_start = pd.Timestamp(f'{year}-04-01')
        season_end = pd.Timestamp(f'{year}-10-31')
        if season_end >= start_date and season_start <= to_date:
            ax.axvspan(max(season_start, start_date), min(season_end, to_date),
                      alpha=0.4, color=color_injection_season, zorder=0, label='_nolegend_')
    
    # Colors matching the reference image
    color_bars = '#f5a623'        # Orange bars
    color_line = '#3b7dd8'        # Blue smoothed line  
    color_avg = '#e67e22'         # Orange 5yr average line
    color_range = '#fdebd0'       # Light orange range fill
    
    # Plot 5-year range as shaded area
    ax.fill_between(df_stats.index, df_stats['min'], df_stats['max'],
                    color=color_range, alpha=0.6, label='5Y Range', zorder=1)
    
    # Plot daily storage action as bars
    ax.bar(df_current.index, df_current.values, width=1.0, color=color_bars, 
           alpha=0.7, zorder=2, label='Daily Action')
    
    # Plot 5-year average line
    ax.plot(df_stats.index, df_stats['avg'], color=color_avg, linewidth=1.5, 
            label='5Y AVG', zorder=3)
    
    # Plot smoothed storage action line (7-day moving average)
    ax.plot(df_smoothed.index, df_smoothed.values, color=color_line, linewidth=2.0,
            label='7-Day Avg', zorder=4)
    
    # Add zero line
    ax.axhline(y=0, color='#888888', linestyle='-', linewidth=0.8, alpha=0.7, zorder=2)
    
    # Styling
    ax.set_title('Daily Storage Action', pad=10, color='#333333', fontsize=11)
    ax.set_ylabel('mcm/d', color=COLORS['text_muted'])
    
    # X-axis formatting - show every month
    ax.xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%b %Y'))
    ax.xaxis.set_major_locator(plt.matplotlib.dates.MonthLocator(interval=1))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # Grid
    ax.grid(axis='y', linestyle='-', color='#E0E0E0', alpha=0.5, linewidth=0.4)
    ax.grid(axis='x', linestyle='-', color='#E0E0E0', alpha=0.3, linewidth=0.3)
    ax.set_axisbelow(True)
    
    # Legend - top left to avoid obscuring recent data, include injection season
    handles, labels = ax.get_legend_handles_labels()
    handles.append(Patch(facecolor=color_injection_season, alpha=0.4, label='Injection Season (Apr-Oct)'))
    labels.append('Injection Season (Apr-Oct)')
    ax.legend(handles, labels, loc='upper left', frameon=True, fancybox=True)
    
    # Add annotation about positive/negative values
    ax.annotate('Positive = injection, Negative = withdrawal',
                xy=(0.01, 0.02), xycoords='axes fraction',
                fontsize=8, fontstyle='italic', color='#666666',
                verticalalignment='bottom')
    
    # Set x limits
    ax.set_xlim(start_date, to_date + pd.Timedelta(days=5))
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_storage_stdev_chart(df_fill: pd.DataFrame, to_date: pd.Timestamp) -> str:
    """
    Generate a chart showing storage levels as standard deviations from 
    5-year rolling average, plus 30-day delta showing momentum.
    
    Methodology (matching original storage_stdev.py):
    1. Calculate 5-year rolling average for each day-of-year
    2. Calculate delta = current storage - 5yr avg
    3. Calculate rolling 5-year std of the delta values
    4. Z-score = delta / rolling_std

    Parameters
    ----------
    df_fill : pd.DataFrame
        Daily stock data with datetime index and 'Total|stock' column.
    to_date : pd.Timestamp
        The current date.

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Get storage data (absolute values, matching original approach)
    df_storage = df_fill[['Total|stock']].copy()
    df_storage.columns = ['Storage']
    
    # Reindex to full calendar
    full_date_range = pd.date_range(start=df_storage.index.min(), end=to_date, freq='D')
    df_storage = df_storage.reindex(full_date_range)
    df_storage = df_storage.interpolate(method='linear', limit_direction='both')
    
    # Add day of year
    df_storage['day_of_year'] = df_storage.index.dayofyear
    
    # STEP 1: Calculate 5-year rolling average for each day-of-year
    # Group by day_of_year, apply rolling mean within each group, shift to exclude current
    moving_avg = (
        df_storage.groupby('day_of_year')['Storage']
        .rolling(window=5, min_periods=3)
        .mean()
        .shift(1)
    )
    df_storage['5yr_avg'] = moving_avg.reset_index(level=0, drop=True)
    
    # STEP 2: Calculate delta from 5-year average
    df_storage['delta'] = df_storage['Storage'] - df_storage['5yr_avg']
    
    # STEP 3: Calculate rolling 5-year std of the delta values
    def rolling_std_5y(series):
        """Calculate rolling 5-year standard deviation."""
        result = []
        for current_date in series.index:
            start_date = current_date - pd.DateOffset(years=5)
            past_5_years = series.loc[start_date:current_date]
            if len(past_5_years) > 30:  # Need reasonable amount of data
                result.append(past_5_years.std())
            else:
                result.append(np.nan)
        return pd.Series(result, index=series.index)
    
    df_storage['rolling_std'] = rolling_std_5y(df_storage['delta'])
    
    # STEP 4: Calculate z-score (number of standard deviations)
    df_storage['n_stdevs'] = df_storage['delta'] / df_storage['rolling_std']
    
    # Clip extreme values
    df_storage['n_stdevs'] = df_storage['n_stdevs'].clip(lower=-4, upper=4)
    
    # STEP 5: Calculate 30-day delta (change in z-score)
    df_storage['delta_30d'] = df_storage['n_stdevs'].diff(30)
    
    # Prepare display data
    df_z = df_storage[['n_stdevs', 'delta_30d']].copy()
    df_z.columns = ['z_score', 'delta_30d']
    
    # Define display range: show last ~2 years of data for context
    start_date = pd.Timestamp(f'{current_year - 2}-01-01')
    df_z_display = df_z.loc[start_date:to_date]
    
    # Create figure
    fig, ax = plt.subplots(figsize=(14, 5), facecolor='white')
    
    # Add light shading for injection seasons (1st Apr to 31st Oct)
    color_injection_season = '#e8f4e8'  # Very light green
    for year in range(current_year - 2, current_year + 1):
        season_start = pd.Timestamp(f'{year}-04-01')
        season_end = pd.Timestamp(f'{year}-10-31')
        # Only shade if within display range
        if season_end >= start_date and season_start <= to_date:
            ax.axvspan(max(season_start, start_date), min(season_end, to_date),
                      alpha=0.4, color=color_injection_season, zorder=0, label='_nolegend_')
    
    # Colors
    color_line = '#3b7dd8'        # Blue line for z-score
    color_delta = '#f5a623'       # Orange for 30d delta
    
    # Plot 30-day delta as bars
    ax.bar(df_z_display.index, df_z_display['delta_30d'].values, 
           width=1.0, color=color_delta, alpha=0.6, 
           label='30d Δ (z-score change)', zorder=1)
    
    # Plot z-score line
    ax.plot(df_z_display.index, df_z_display['z_score'].values, 
            color=color_line, linewidth=1.5, 
            label='Storage vs 5Y Avg (z-score)', zorder=2)
    
    # Add zero line
    ax.axhline(y=0, color='#888888', linestyle='-', linewidth=0.8, alpha=0.7, zorder=1)
    
    # Add reference lines at +/- 1 and 2 standard deviations
    for sd in [-2, -1, 1, 2]:
        ax.axhline(y=sd, color='#cccccc', linestyle='--', linewidth=0.5, alpha=0.7, zorder=0)
    
    # Styling
    ax.set_title('Storage Level vs 5-Year Rolling Average (Std Devs)', pad=10, color='#333333', fontsize=11)
    ax.set_ylabel('Std Devs from 5Y Avg', color=COLORS['text_muted'])
    
    # X-axis formatting - show every month
    ax.xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%b %Y'))
    ax.xaxis.set_major_locator(plt.matplotlib.dates.MonthLocator(interval=1))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # Grid
    ax.grid(axis='y', linestyle='-', color='#E0E0E0', alpha=0.5, linewidth=0.4)
    ax.grid(axis='x', linestyle='-', color='#E0E0E0', alpha=0.3, linewidth=0.3)
    ax.set_axisbelow(True)
    
    # Legend - add injection season indicator
    handles, labels = ax.get_legend_handles_labels()
    handles.append(Patch(facecolor=color_injection_season, alpha=0.4, label='Injection Season (Apr-Oct)'))
    labels.append('Injection Season (Apr-Oct)')
    ax.legend(handles, labels, loc='upper left', frameon=True, fancybox=True)
    
    # Add descriptive annotation
    annotation_text = (
        'Blue line: Storage vs 5Y avg (std devs). Orange bars: 30d change in z-score. Shaded = injection season.\n'
        'Price signal: Below avg + falling = very bullish | Below avg + rising = bearish | '
        'Above avg + rising = very bearish | Above avg + falling = bullish | Stable = neutral.'
    )
    ax.annotate(annotation_text,
                xy=(0.01, -0.18), xycoords='axes fraction',
                fontsize=7, fontstyle='italic', color='#666666',
                verticalalignment='top')
    
    # Set x limits
    ax.set_xlim(start_date, to_date + pd.Timedelta(days=5))
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_balance_stdev_chart(balances: dict, to_date: pd.Timestamp) -> str:
    """
    Generate a chart showing storage levels as standard deviations from 
    5-year rolling average, using data from balance scenarios.
    
    Uses Basecase for history (solid) and shows forecast portion (dashed),
    plus other scenarios' forecasts.

    Parameters
    ----------
    balances : dict
        Dict of balance scenarios from get_eu_gas_balances().
    to_date : pd.Timestamp
        The current date.

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    
    # Get Basecase data for the main calculation
    if 'Basecase' not in balances:
        return ""
    
    basecase_data = balances['Basecase'].get('balance_daily')
    if basecase_data is None:
        return ""
    
    # Extract storage stock column
    if ('Storage', 'Stock') in basecase_data.columns:
        df_storage = basecase_data[[('Storage', 'Stock')]].copy()
        df_storage.columns = ['Storage']
    elif 'Storage_Stock' in basecase_data.columns:
        df_storage = basecase_data[['Storage_Stock']].copy()
        df_storage.columns = ['Storage']
    else:
        return ""
    
    # Reindex to full calendar
    full_date_range = pd.date_range(start=df_storage.index.min(), end=df_storage.index.max(), freq='D')
    df_storage = df_storage.reindex(full_date_range)
    df_storage = df_storage.interpolate(method='linear', limit_direction='both')
    
    # Add day of year
    df_storage['day_of_year'] = df_storage.index.dayofyear
    
    # Calculate 5-year rolling average for each day-of-year
    moving_avg = (
        df_storage.groupby('day_of_year')['Storage']
        .rolling(window=5, min_periods=3)
        .mean()
        .shift(1)
    )
    df_storage['5yr_avg'] = moving_avg.reset_index(level=0, drop=True)
    
    # Calculate delta from 5-year average
    df_storage['delta'] = df_storage['Storage'] - df_storage['5yr_avg']
    
    # Calculate rolling 5-year std of the delta values
    def rolling_std_5y(series):
        result = []
        for current_date in series.index:
            start_date_calc = current_date - pd.DateOffset(years=5)
            past_5_years = series.loc[start_date_calc:current_date]
            if len(past_5_years) > 30:
                result.append(past_5_years.std())
            else:
                result.append(np.nan)
        return pd.Series(result, index=series.index)
    
    df_storage['rolling_std'] = rolling_std_5y(df_storage['delta'])
    
    # Calculate z-score
    df_storage['n_stdevs'] = df_storage['delta'] / df_storage['rolling_std']
    df_storage['n_stdevs'] = df_storage['n_stdevs'].clip(lower=-4, upper=4)
    
    # Calculate 30-day delta
    df_storage['delta_30d'] = df_storage['n_stdevs'].diff(30)
    
    # Prepare display data
    df_z = df_storage[['n_stdevs', 'delta_30d']].copy()
    df_z.columns = ['z_score', 'delta_30d']
    
    # Define display range
    start_date = pd.Timestamp(f'{current_year - 2}-01-01')
    end_date = pd.Timestamp('2027-10-31')  # Truncate to 31st Oct 2027
    
    # Truncate df_z to end date
    df_z = df_z.loc[:end_date]
    
    # Split into history and forecast
    df_z_history = df_z.loc[start_date:to_date]
    df_z_forecast = df_z.loc[to_date:end_date]
    
    # Create figure
    fig, ax = plt.subplots(figsize=(14, 5), facecolor='white')
    
    # Add light shading for injection seasons
    color_injection_season = '#e8f4e8'
    max_date = end_date
    for year in range(current_year - 2, current_year + 3):
        season_start = pd.Timestamp(f'{year}-04-01')
        season_end = pd.Timestamp(f'{year}-10-31')
        if season_end >= start_date and season_start <= max_date:
            ax.axvspan(max(season_start, start_date), min(season_end, max_date),
                      alpha=0.4, color=color_injection_season, zorder=0, label='_nolegend_')
    
    # Colors
    color_line = '#3b7dd8'
    color_delta = '#f5a623'
    
    # Plot 30-day delta as bars (history - darker solid color)
    ax.bar(df_z_history.index, df_z_history['delta_30d'].values, 
           width=1.0, color=color_delta, alpha=0.8, 
           label='30d Δ (history)', zorder=1)
    
    # Plot 30-day delta as bars (forecast - lighter)
    if len(df_z_forecast) > 0:
        bars = ax.bar(df_z_forecast.index, df_z_forecast['delta_30d'].values, 
               width=1.0, color=color_delta, alpha=0.3, 
               label='30d Δ (fcst)', zorder=1, edgecolor=color_delta, linewidth=0.3)
    
    # Plot Basecase history (solid)
    ax.plot(df_z_history.index, df_z_history['z_score'].values, 
            color=color_line, linewidth=1.5, 
            label='Basecase (history)', zorder=2)
    
    # Plot Basecase forecast (dashed)
    if len(df_z_forecast) > 0:
        ax.plot(df_z_forecast.index, df_z_forecast['z_score'].values, 
                color=color_line, linewidth=1.5, linestyle='--',
                label='Basecase (fcst)', zorder=3)
    
    # Plot other scenarios' forecasts
    scenario_colors = {
        'HormuzAug26': '#e74c3c',     # Red
        'HormuzNov26': '#9b59b6',     # Purple
    }
    
    for scenario_name, scenario_data in balances.items():
        if scenario_name == 'Basecase':
            continue
        
        try:
            df_balance = scenario_data.get('balance_daily')
            if df_balance is None:
                continue
            
            # Extract storage stock
            if ('Storage', 'Stock') in df_balance.columns:
                fcst_storage = df_balance[('Storage', 'Stock')].copy()
            elif 'Storage_Stock' in df_balance.columns:
                fcst_storage = df_balance['Storage_Stock'].copy()
            else:
                continue
            
            # Filter to forecast period only
            fcst_storage = fcst_storage[fcst_storage.index > to_date]
            
            if fcst_storage.empty:
                continue
            
            # Get 5yr avg and rolling std from Basecase for consistent comparison
            last_5yr_avg_by_doy = df_storage.groupby('day_of_year')['5yr_avg'].last()
            last_rolling_std = df_storage['rolling_std'].dropna().iloc[-1]
            
            # Calculate z-scores
            fcst_z_scores = []
            for date in fcst_storage.index:
                doy = date.dayofyear
                storage_val = fcst_storage.loc[date]
                
                if doy in last_5yr_avg_by_doy.index:
                    avg_val = last_5yr_avg_by_doy.loc[doy]
                else:
                    avg_val = last_5yr_avg_by_doy.mean()
                
                if pd.notna(storage_val) and pd.notna(avg_val) and last_rolling_std > 0:
                    delta = storage_val - avg_val
                    z = delta / last_rolling_std
                    z = np.clip(z, -4, 4)
                else:
                    z = np.nan
                
                fcst_z_scores.append({'date': date, 'z_score': z})
            
            df_fcst_z = pd.DataFrame(fcst_z_scores).set_index('date')
            
            if not df_fcst_z.empty:
                color = scenario_colors.get(scenario_name, '#95a5a6')
                ax.plot(df_fcst_z.index, df_fcst_z['z_score'].values,
                        color=color, linewidth=1.5, linestyle='--',
                        label=f'{scenario_name} (fcst)', zorder=3)
        
        except Exception:
            continue
    
    # Add zero line
    ax.axhline(y=0, color='#888888', linestyle='-', linewidth=0.8, alpha=0.7, zorder=1)
    
    # Add reference lines at +/- 1 and 2 standard deviations
    for sd in [-2, -1, 1, 2]:
        ax.axhline(y=sd, color='#cccccc', linestyle='--', linewidth=0.5, alpha=0.7, zorder=0)
    
    # Styling
    ax.set_title('Storage Level vs 5yr Rolling Avg (Std Devs)', pad=10, color='#333333', fontsize=11)
    ax.set_ylabel('Std Devs from 5Y Avg', color=COLORS['text_muted'])
    
    # X-axis formatting
    ax.xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%b %Y'))
    ax.xaxis.set_major_locator(plt.matplotlib.dates.MonthLocator(interval=1))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # Grid
    ax.grid(axis='y', linestyle='-', color='#E0E0E0', alpha=0.5, linewidth=0.4)
    ax.grid(axis='x', linestyle='-', color='#E0E0E0', alpha=0.3, linewidth=0.3)
    ax.set_axisbelow(True)
    
    # Legend
    handles, labels = ax.get_legend_handles_labels()
    handles.append(Patch(facecolor=color_injection_season, alpha=0.4, label='Injection Season (Apr-Oct)'))
    labels.append('Injection Season (Apr-Oct)')
    ax.legend(handles, labels, loc='upper left', frameon=True, fancybox=True)
    
    # Add vertical line at current date
    ax.axvline(x=to_date, color='#333333', linestyle=':', linewidth=1, alpha=0.7, zorder=4)
    
    # Annotation
    annotation_text = (
        'Blue line: Storage vs 5Y avg (std devs). Orange bars: 30d change in z-score. Shaded = injection season.\n'
        'Solid = history, Dashed = forecast. Vertical dotted line = current date.\n'
        'Price signal: Below avg + falling = very bullish | Below avg + rising = bearish | '
        'Above avg + rising = very bearish | Above avg + falling = bullish | Stable = neutral.'
    )
    ax.annotate(annotation_text,
                xy=(0.01, -0.18), xycoords='axes fraction',
                fontsize=7, fontstyle='italic', color='#666666',
                verticalalignment='top')
    
    # Set x limits
    ax.set_xlim(start_date, end_date + pd.Timedelta(days=5))
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_storage_fill_forecast_chart(balances: dict, to_date: pd.Timestamp) -> str:
    """
    Generate a chart showing storage fill % forecast using balance scenarios.
    
    Shows Jan-Dec on x-axis, % fill on y-axis, with:
    - 5yr range as shaded region
    - Current year and previous 2 years as solid lines
    - Basecase and other scenarios as dotted lines
    - Forecast data truncated to 31st Oct-27

    Parameters
    ----------
    balances : dict
        Dict of balance scenarios from get_eu_gas_balances().
    to_date : pd.Timestamp
        The current date.

    Returns
    -------
    str
        Base64 encoded PNG image.
    """
    _apply_chart_style()
    
    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    end_date = pd.Timestamp('2027-10-31')
    
    # Get Basecase data which contains history
    if 'Basecase' not in balances:
        return ""
    
    basecase_data = balances['Basecase'].get('balance_daily')
    if basecase_data is None:
        return ""
    
    # Extract Fill % column
    if ('Storage', 'Fill %') in basecase_data.columns:
        fill_col = ('Storage', 'Fill %')
    elif 'Storage_Fill %' in basecase_data.columns:
        fill_col = 'Storage_Fill %'
    else:
        return ""
    
    df_fill_pct = basecase_data[[fill_col]].copy()
    df_fill_pct.columns = ['fill_pct']
    df_fill_pct['fill_pct'] = df_fill_pct['fill_pct'] * 100  # Convert to percentage
    
    # Truncate to end date
    df_fill_pct = df_fill_pct.loc[:end_date]
    
    # Get available years from Basecase data
    min_year = df_fill_pct.index.min().year
    max_year = min(df_fill_pct.index.max().year, 2027)
    years = list(range(min_year, max_year + 1))
    
    # Month x-axis settings
    month_starts = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
    month_labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    # Create figure
    fig, ax = plt.subplots(figsize=(14, 6), facecolor='white')
    
    # Calculate 5-year range for shading (use years before current year)
    range_years = [y for y in years if y < current_year][-5:]  # Last 5 complete years
    
    if len(range_years) >= 2:
        # Build day-of-year data for range calculation
        doy_min = {}
        doy_max = {}
        
        for year in range_years:
            start = f'{year}-01-01'
            end = f'{year}-12-31'
            year_data = df_fill_pct.loc[start:end]
            
            for idx, row in year_data.iterrows():
                doy = idx.dayofyear
                val = row['fill_pct']
                if pd.notna(val):
                    if doy not in doy_min:
                        doy_min[doy] = val
                        doy_max[doy] = val
                    else:
                        doy_min[doy] = min(doy_min[doy], val)
                        doy_max[doy] = max(doy_max[doy], val)
        
        # Plot 5yr range
        if doy_min:
            doys = sorted(doy_min.keys())
            mins = [doy_min[d] for d in doys]
            maxs = [doy_max[d] for d in doys]
            ax.fill_between(doys, mins, maxs, color='#d5e8f7', alpha=0.6, 
                           label='5Y Range', zorder=1)
    
    # Plot current year actual data only
    start = f'{current_year}-01-01'
    year_data = df_fill_pct.loc[start:to_date]
    
    if not year_data.empty:
        doy = year_data.index.dayofyear
        ax.plot(doy, year_data['fill_pct'].values, 
               color='#1f77b4', linewidth=3.0, 
               label=f'{current_year} Actual',
               marker='o', markersize=4, markevery=max(1, len(year_data) // 12),
               zorder=10)
    
    # Add vertical line at current date to mark forecast start
    current_doy = to_date.dayofyear
    ax.axvline(x=current_doy, color='#333333', linestyle=':', linewidth=1.2, 
               alpha=0.7, zorder=5, label='_nolegend_')
    
    # Scenario styling for forecasts - distinct colors and line styles
    scenario_styles = {
        'Basecase': {
            'color': '#2ecc71',       # Green for basecase
            'linestyle': '--',        # Dashed
            'linewidth': 2.5,
        },
        'HormuzAug26': {
            'color': '#e74c3c',       # Red
            'linestyle': ':',         # Dotted
            'linewidth': 2.0,
        },
        'HormuzNov26': {
            'color': '#9b59b6',       # Purple
            'linestyle': '-.',        # Dash-dot
            'linewidth': 2.0,
        },
    }
    
    # Plot scenario forecasts with distinct styles
    for scenario_name, scenario_data in balances.items():
        try:
            df_balance = scenario_data.get('balance_daily')
            if df_balance is None:
                continue
            
            # Extract Fill %
            if ('Storage', 'Fill %') in df_balance.columns:
                fcst_fill = df_balance[('Storage', 'Fill %')].copy() * 100
            elif 'Storage_Fill %' in df_balance.columns:
                fcst_fill = df_balance['Storage_Fill %'].copy() * 100
            else:
                continue
            
            # Filter to forecast period only (after current date, up to end_date)
            fcst_fill = fcst_fill[(fcst_fill.index > to_date) & (fcst_fill.index <= end_date)]
            
            if fcst_fill.empty:
                continue
            
            # Get style for this scenario
            style = scenario_styles.get(scenario_name, {
                'color': '#95a5a6', 'linestyle': '--', 'linewidth': 1.5
            })
            
            # Plot all forecast data as single continuous line per scenario
            # (data wraps around year boundary, so we plot each year segment separately
            # but only label once)
            first_segment = True
            for year in sorted(fcst_fill.index.year.unique()):
                year_data = fcst_fill[fcst_fill.index.year == year]
                if year_data.empty:
                    continue
                
                doy = year_data.index.dayofyear
                
                # Only label the first segment
                label = scenario_name if first_segment else '_nolegend_'
                first_segment = False
                
                ax.plot(doy, year_data.values, 
                       color=style['color'], 
                       linewidth=style['linewidth'], 
                       linestyle=style['linestyle'],
                       label=label, zorder=8)
            
            # Add markers at Oct 31 for each year in forecast
            # Diamond for 2026, square for 2027
            oct31_doy = 304  # Day of year for Oct 31
            for year in fcst_fill.index.year.unique():
                try:
                    oct31_date = pd.Timestamp(f'{year}-10-31')
                    if oct31_date in fcst_fill.index:
                        val = fcst_fill.loc[oct31_date]
                        marker_shape = 'D' if year == 2026 else 's'  # Diamond for 2026, square for 2027
                        ax.scatter([oct31_doy], [val], color=style['color'], 
                                  s=60, marker=marker_shape, zorder=12, edgecolors='white', linewidths=1)
                except Exception:
                    pass
        
        except Exception:
            continue
    
    # Add horizontal lines at key fill levels
    for level in [80, 90]:
        ax.axhline(y=level, color='#cccccc', linestyle=':', linewidth=0.8, alpha=0.7)
    
    # Styling
    ax.set_title('Total Storage Fill Forecast', pad=10, color='#333333', fontsize=11)
    ax.set_ylabel('%', color=COLORS['text_muted'])
    ax.set_xticks(month_starts)
    ax.set_xticklabels(month_labels)
    ax.set_xlim(1, 366)
    ax.set_ylim(0, 105)
    
    # Grid
    ax.grid(axis='y', linestyle='-', color='#E0E0E0', alpha=0.5, linewidth=0.4)
    ax.grid(axis='x', linestyle='-', color='#E0E0E0', alpha=0.3, linewidth=0.3)
    ax.set_axisbelow(True)
    
    # Legend
    ax.legend(loc='upper left', frameon=True, fancybox=True)
    
    # Annotation
    ax.annotate('Solid blue = Actual YTD. Forecasts: Basecase (--) green, HormuzAug26 (:) red, HormuzNov26 (-.) purple.\n'
                '◆ = 31 Oct 2026, ■ = 31 Oct 2027.',
                xy=(0.01, -0.08), xycoords='axes fraction',
                fontsize=8, fontstyle='italic', color='#666666',
                verticalalignment='top')
    
    plt.tight_layout()
    
    # Save to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


