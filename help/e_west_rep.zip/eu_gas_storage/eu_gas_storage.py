
"""
Email report showing latest EU Gas Storage stats

"""


import logging
import sys
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
from common.dashboard_header import dashboard_header_for

from jain_commods.core.util.emailhelper import send_email

from util import (
    get_ce_storage_data, 
    get_heren_prices,
    calculate_injection_since_april, 
    generate_injection_chart, 
    generate_cumulative_injection_chart, 
    generate_storage_level_chart, 
    generate_storage_fill_table,
    calculate_apr1_fill_pct,
    calculate_oct31_fill_pct,
    calculate_injection_season_totals,
    calculate_injection_needed_for_targets,
    generate_injection_target_chart,
    generate_daily_activity_table,
    generate_spread_vs_injection_chart,
    generate_daily_storage_action_chart,
    generate_storage_stdev_chart,
    generate_balance_stdev_chart,
    generate_storage_fill_forecast_chart,
    get_eu_gas_balances,
    generate_forecast_fill_table,
)


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/eu_gas_storage')
 
# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'eu_gas_storage.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
ce_user = config.get('CEConfig','user')
ce_pass = config.get('CEConfig','pass')


# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_eu_gas_storage.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

today = datetime.now()


# TODO: 
    # Plot injections versus DA/Front month price spread?
    # Add injectability and withdrawability charts (need per storage site stats and latest balance obvs!)
    


try:
    
    logging.info('Generating report...')
    
    # Get raw data
    logging.info('Querying CE')
    df_inj, df_fill = get_ce_storage_data(ce_user, ce_pass)
    
    logging.info('Constructing data and charts')
    
    # Calculate injection since 1st April for each year
    df_apr_injection = calculate_injection_since_april(df_inj, pd.Timestamp(today))

    # Get latest EU gas balances
    balances = get_eu_gas_balances(today)
    
    # Get basecase saved date for display
    basecase_saved_date = balances.get('Basecase', {}).get('saved_date_utc')
    if basecase_saved_date:
        basecase_saved_str = pd.Timestamp(basecase_saved_date).strftime('%d %b %Y %H:%M UTC')
    else:
        basecase_saved_str = 'Unknown'
    
    # Generate forecast fill table
    forecast_fill_table_html = generate_forecast_fill_table(balances)
    
    # Generate injection chart
    injection_chart_img = generate_injection_chart(df_apr_injection, pd.Timestamp(today))
    injection_chart_html = f"<img src='data:image/png;base64,{injection_chart_img}' alt='Injection Since April'>"
    
    # Generate cumulative injection chart
    cumulative_chart_img = generate_cumulative_injection_chart(df_inj, pd.Timestamp(today))
    cumulative_chart_html = f"<img src='data:image/png;base64,{cumulative_chart_img}' alt='Cumulative Injection'>"
    
    # Generate storage level chart
    storage_level_img = generate_storage_level_chart(df_fill, pd.Timestamp(today))
    storage_level_html = f"<img src='data:image/png;base64,{storage_level_img}' alt='Storage Level'>"
    
    # Generate storage fill table
    storage_fill_table_html = generate_storage_fill_table(df_fill, pd.Timestamp(today))
    
    # Generate daily activity table
    daily_activity_table_html = generate_daily_activity_table(df_inj, pd.Timestamp(today))
    
    # Generate daily storage action chart
    storage_action_img = generate_daily_storage_action_chart(df_inj, pd.Timestamp(today))
    storage_action_html = f"<img src='data:image/png;base64,{storage_action_img}' alt='Daily Storage Action'>"
    
    # Generate storage standard deviation chart (historical data only) - currently hidden
    # storage_stdev_img = generate_storage_stdev_chart(df_fill, pd.Timestamp(today))
    # storage_stdev_html = f"<img src='data:image/png;base64,{storage_stdev_img}' alt='Storage StDev'>"
    
    # Generate balance scenarios stdev chart (uses balance data with forecasts)
    balance_stdev_img = generate_balance_stdev_chart(balances, pd.Timestamp(today))
    balance_stdev_html = f"<img src='data:image/png;base64,{balance_stdev_img}' alt='Balance Scenarios StDev'>"
    
    # Generate storage fill forecast chart
    fill_forecast_img = generate_storage_fill_forecast_chart(balances, pd.Timestamp(today))
    fill_forecast_html = f"<img src='data:image/png;base64,{fill_forecast_img}' alt='Storage Fill Forecast'>"
    
    # # Get Heren prices and generate spread vs injection chart
    # df_prices = get_heren_prices()
    # spread_injection_img = generate_spread_vs_injection_chart(df_inj, df_prices, pd.Timestamp(today))
    # spread_injection_html = f"<img src='data:image/png;base64,{spread_injection_img}' alt='Spread vs Injection'>"
    
    # HTML for the above (to be instered below): --->
    # <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">DA/FM Spread vs Injection</h3>
    # {spread_injection_html}
    # <br>
    
    # Calculate additional stats
    df_apr1_fill = calculate_apr1_fill_pct(df_fill)
    df_oct31_fill = calculate_oct31_fill_pct(df_fill)
    df_injection_season = calculate_injection_season_totals(df_inj)
    df_injection_needed = calculate_injection_needed_for_targets(df_fill, pd.Timestamp(today))
    
    # Generate injection target chart
    injection_target_img = generate_injection_target_chart(
        df_injection_season, df_apr_injection, df_apr1_fill, df_oct31_fill, 
        df_fill, pd.Timestamp(today)
    )
    injection_target_html = f"<img src='data:image/png;base64,{injection_target_img}' alt='Injection Targets'>"
    
    # Produce report
    dashboard_header = dashboard_header_for("eu_gas_storage")
    email_body = f"""
{dashboard_header}
<div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; font-size: 13px; line-height: 1.4; color: #333;">
  <p style="margin: 0 0 4px 0; font-size: 12px; color: #555;">EU Gas Storage Report - data as of {today.strftime('%d %b %Y')}.</p>
  <p style="margin: 0 0 16px 0; font-size: 11px; color: #888; font-style: italic;">Data covers NWE+IT perimeter.</p>

  <h3 style="margin: 0 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Daily Storage Action</h3>
  <p style="margin: 0 0 6px 0; font-size: 12px; color: #555; font-weight: 500;">Recent 14d history</p>
  {daily_activity_table_html}
  <div style="margin-top: 16px;">
  {storage_action_html}
  </div>
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Balance Scenario Forecast vs Historical Avg</h3>
  {balance_stdev_html}
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Injection Since 1st April</h3>
  {injection_chart_html}
  <br>
  
  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Cumulative Injection Since 1st April</h3>
  {cumulative_chart_html}
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Storage Fill</h3>
  {storage_fill_table_html}
  <div style="margin-top: 16px;">
  {storage_level_html}
  </div>
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">2026 Injection vs Targets</h3>
  {injection_target_html}
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Storage Fill Forecast</h3>
  <p style="margin: 0 0 12px 0; font-size: 11px; color: #888; font-style: italic;">EU Gas balances generated at: {basecase_saved_str}</p>
  {forecast_fill_table_html}
  <div style="margin-top: 16px;">
  {fill_forecast_html}
  </div>
  <br>
</div>
"""
    logging.info('Sending email')    

    send_email(receivers, 
               f"EU Gas Storage Summary: {today.strftime('%d %b %Y')}", 
               email_body,
               from_address='eu.gap.reports@jainglobal.com') 
    
    
    logging.info('Done')



except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, 'ERROR EU Gas Storage Report', str(tb))    

        