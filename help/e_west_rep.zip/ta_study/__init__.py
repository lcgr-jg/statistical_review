"""Daily Technical Analysis Email - the Shternberg mean-reversion study.

For each configured product and each time horizon (weekly, daily, 4h, 1h)
the job computes:

* **RSI divergence** between consecutive confirmed price swings - the
  primary signal (:mod:`ta_study.divergence`),
* **stochastic %K/%D cross in zone** - a structurally lagging confirmation
  (:mod:`ta_study.indicators`, applied in :mod:`ta_study.study`),
* **ADX regime gate** - momentum-dominant regimes suppress or size down
  mean-reversion entries,

classifies each (product, horizon) into a state, renders a multi-panel
chart, and emails a structured summary with the charts embedded as CID
inline images. Signal history and forward returns are persisted so that hit
rates can be reported back into the email.

The maths is specified exactly in ``SPEC.md`` §8a; every module that
implements a formula cites the sub-section it comes from.

Entry points:
    ``python -m ta_study.cli run --dry-run``
    ``from ta_study import run_ta_study``
"""

from __future__ import annotations

__all__ = ["run_ta_study"]

__version__ = "0.1.0"


def run_ta_study(*args, **kwargs):  # type: ignore[no-untyped-def]
    """Lazy re-export of :func:`ta_study.pipeline.run_ta_study`.

    Imported lazily so that ``import ta_study`` stays cheap and does not drag
    in blpapi, Snowflake or matplotlib for callers that only want the pure
    study functions.
    """
    from ta_study.pipeline import run_ta_study as _run

    return _run(*args, **kwargs)
