@echo off
REM ---------------------------------------------------------------------------
REM Run the TA study with the right interpreter, whatever shell you are in.
REM
REM   ta_study\run.bat --dry-run
REM   ta_study\run.bat --to michael.kane@jainglobal.com
REM   ta_study\run.bat validate
REM
REM Why this exists: the Windows "py" launcher ignores "conda activate", so
REM "conda activate corelib && py -m ta_study.cli run" silently runs on the
REM system Python, which has no jain_commods and no confluent_kafka. This
REM pins the corelib interpreter by path so that cannot happen.
REM
REM Override with:  set TA_STUDY_PYTHON=C:\path\to\python.exe
REM ---------------------------------------------------------------------------
setlocal

cd /d "%~dp0\.."

REM Non-ASCII in the report copy (sigma, em-dash, state arrows) dies on the
REM console's cp1252 default.
set PYTHONIOENCODING=utf-8

if defined TA_STUDY_PYTHON (
    set "PY=%TA_STUDY_PYTHON%"
) else (
    set "PY=%LOCALAPPDATA%\miniconda3\envs\corelib\python.exe"
)

if not exist "%PY%" (
    echo [ta_study] corelib interpreter not found at:
    echo            %PY%
    echo.
    echo Set TA_STUDY_PYTHON to the right python.exe, e.g.
    echo   set TA_STUDY_PYTHON=C:\Users\you\miniconda3\envs\corelib\python.exe
    exit /b 1
)

REM Bare flags mean "run"; a leading subcommand is passed through as given.
set "FIRST=%~1"
if "%FIRST%"=="" (
    "%PY%" -m ta_study.cli run
) else if "%FIRST:~0,1%"=="-" (
    "%PY%" -m ta_study.cli run %*
) else (
    "%PY%" -m ta_study.cli %*
)

exit /b %ERRORLEVEL%
