"""Dagster assets, job and schedule for the TA study.

Asset graph, mirroring §13::

    bars_daily ┐
    bars_intraday ┴→ study → charts_email

``bars_daily`` and ``bars_intraday`` are thin materialisation markers: the
study runs as one process so the ~60 (product, horizon) pairs share a single
Bloomberg session and one chart pool, which is what keeps the run inside the
5-minute budget. Splitting the pipeline into one asset per stage would mean
re-fetching or serialising 60 bar frames between steps for no benefit.

``forward_returns`` is a separate nightly asset, as specified: it re-scores
divergence events whose forward horizon has since elapsed.

To register these with the repo-level Dagster instance, add to the root
``dagster_defs.py``::

    from ta_study.dagster_defs import ta_study_assets, ta_study_jobs, ta_study_schedules

and extend ``_assets`` / ``_jobs`` / ``_schedules`` with them. They are kept
here so the package stays self-contained and testable on its own.
"""

from __future__ import annotations

# Must precede any import that touches pyplot: sensors and schedules run in
# background threads where an interactive backend raises.
import matplotlib

matplotlib.use("Agg")

import datetime as dt
import os
from pathlib import Path
from typing import Any

from dagster import (
    Backoff,
    DefaultScheduleStatus,
    Definitions,
    MetadataValue,
    RetryPolicy,
    asset,
    define_asset_job,
    schedule,
)

TIMEZONE = "Europe/London"

#: 06:55 UK, Monday to Friday - ahead of the 07:00 send time.
STUDY_CRON = "55 6 * * 1-5"
#: 22:30 UK, Monday to Friday - after every European settle has printed.
STATS_CRON = "30 22 * * 1-5"

_RETRY = RetryPolicy(max_retries=2, delay=120, backoff=Backoff.EXPONENTIAL)

_TAGS = {
    "team": "commodities-research",
    "report_type": "daily",
    "priority": "medium",
    "delivery": "email",
}


def _is_production() -> bool:
    return os.environ.get("DAGSTER_ENV", "local").strip().lower() == "production"


DEFAULT_SCHEDULE_STATUS = (
    DefaultScheduleStatus.RUNNING if _is_production() else DefaultScheduleStatus.STOPPED
)


def _base_dir() -> Path:
    """Where cache/, output/ and state/ live. Overridable for containers."""
    configured = os.environ.get("TA_STUDY_BASE_DIR")
    return Path(configured) if configured else Path.cwd()


def _config_path() -> Path | None:
    configured = os.environ.get("TA_STUDY_CONFIG")
    return Path(configured) if configured else None


def _dry_run() -> bool:
    return os.environ.get("EMAIL_DRY_RUN", "false").strip().lower() == "true"


def _recipients() -> list[str] | None:
    override = os.environ.get("EMAIL_OVERRIDE")
    if not override:
        return None
    return [p.strip() for p in override.split(",") if p.strip()]


def _metadata(payload: dict[str, Any]) -> dict[str, Any]:
    """Coerce a flat summary into Dagster metadata values."""
    out: dict[str, Any] = {}
    for key, value in payload.items():
        if isinstance(value, bool):
            out[key] = MetadataValue.bool(value)
        elif isinstance(value, int):
            out[key] = MetadataValue.int(value)
        elif isinstance(value, float):
            out[key] = MetadataValue.float(value)
        elif isinstance(value, (list, dict)):
            out[key] = MetadataValue.json(value)
        elif isinstance(value, Path):
            out[key] = MetadataValue.path(str(value))
        else:
            out[key] = MetadataValue.text(str(value))
    return out


# ---------------------------------------------------------------------------
# assets
# ---------------------------------------------------------------------------
@asset(
    name="ta_study_bars_daily",
    group_name="ta_study",
    description="Daily OHLCV bars for every configured TA-study product",
    compute_kind="bloomberg",
    retry_policy=_RETRY,
    tags=_TAGS,
)
def ta_study_bars_daily(context) -> dict[str, Any]:
    """Warm the Parquet cache and report per-product bar counts.

    Materialising this separately means a Bloomberg outage is visible as a
    failed upstream asset rather than a mysteriously thin email.
    """
    import datetime as _dt

    from common.bbg import BloombergClient
    from ta_study import data as data_mod
    from ta_study.config import load_config

    cfg = load_config(_config_path())
    root = _base_dir()
    as_of = _dt.date.today()
    start, end = data_mod.daily_window(cfg, as_of)

    client = BloombergClient(
        root / cfg.run.cache_dir,
        on_server=cfg.bloomberg_on_server,
        use_cache=True,
    )
    counts: dict[str, int] = {}
    for product in cfg.products:
        bars = data_mod.normalise_daily(
            client.fetch_daily_bars(product.ticker, start, end)
        )
        counts[product.name] = bars.height
        context.log.info("%s: %d daily bars", product.name, bars.height)

    empty = [name for name, n in counts.items() if n == 0]
    if empty:
        context.log.warning("no daily history for: %s", ", ".join(empty))

    return _metadata(
        {
            "as_of": as_of.isoformat(),
            "bar_counts": counts,
            "products_empty": empty,
            "bbg_latency_s": round(client.report.latency_s, 1),
            "warnings": client.report.warnings,
        }
    )


@asset(
    name="ta_study_bars_intraday",
    group_name="ta_study",
    description="1h bars topped up from Bloomberg and persisted to MKT/TA.INTRADAY_BARS",
    compute_kind="bloomberg",
    retry_policy=_RETRY,
    tags=_TAGS,
)
def ta_study_bars_intraday(context) -> dict[str, Any]:
    """Extend the persisted intraday history forward by one run.

    Bloomberg retains roughly 140 days of intraday bars, so the 4h and 1h
    horizons only ever have deep history because this asset keeps appending
    to Snowflake. Skipped entirely when no intraday horizon is enabled.
    """
    import datetime as _dt

    from common.bbg import BloombergClient
    from ta_study import data as data_mod
    from ta_study.config import load_config
    from ta_study.store import TaStore

    cfg = load_config(_config_path())
    if not cfg.needs_intraday:
        context.log.info("no intraday horizons enabled; nothing to do")
        return _metadata({"skipped": True, "reason": "no intraday horizons enabled"})

    root = _base_dir()
    as_of = _dt.date.today()
    start, end = data_mod.intraday_window(cfg, as_of)
    interval = cfg.intraday_base_interval

    client = BloombergClient(
        root / cfg.run.cache_dir,
        on_server=cfg.bloomberg_on_server,
        use_cache=True,
    )
    store = TaStore(cfg, root)

    fetched: dict[str, int] = {}
    persisted: dict[str, int] = {}
    for product in cfg.products:
        bars = data_mod.normalise_intraday(
            client.fetch_intraday(
                product.ticker, start, end, interval_min=interval, gap_fill=True
            )
        )
        fetched[product.name] = bars.height
        if bars.height:
            persisted[product.name] = store.save_intraday_bars(
                product.ticker, interval, bars
            )
        context.log.info("%s: %d %dm bars", product.name, bars.height, interval)

    errors = list(store.errors)
    store.close()

    return _metadata(
        {
            "as_of": as_of.isoformat(),
            "interval_min": interval,
            "bars_fetched": fetched,
            "rows_persisted": persisted,
            "persist_enabled": cfg.persist.enabled,
            "errors": errors,
        }
    )


@asset(
    name="ta_study_email",
    group_name="ta_study",
    deps=[ta_study_bars_daily, ta_study_bars_intraday],
    description=(
        "Shternberg study across every product x horizon: divergences, "
        "stochastic confirmation, ADX gate, charts and the HTML email"
    ),
    compute_kind="python",
    retry_policy=_RETRY,
    tags=_TAGS,
    metadata={"output_type": "HTML Email", "data_sources": "Bloomberg, Snowflake"},
)
def ta_study_email(context) -> dict[str, Any]:
    """Run the study and send the email.

    Recipients and dry-run mode come from ``EMAIL_OVERRIDE`` and
    ``EMAIL_DRY_RUN`` so a local run can never mail the desk by accident.
    """
    from ta_study.pipeline import run_ta_study

    dry_run = _dry_run()
    recipients = _recipients()
    if dry_run:
        context.log.info("[DRY RUN] writing HTML and charts to disk, not sending")

    result = run_ta_study(
        config_path=_config_path(),
        dry_run=dry_run,
        recipients=recipients,
        base_dir=_base_dir(),
    )

    for warning in result.warnings:
        context.log.warning(warning)
    context.log.info(
        "%s | %d pairs, %d alignments, %.1f MB in %.1fs",
        result.subject,
        len(result.results),
        len(result.alignments),
        result.size_bytes / 1024 / 1024,
        result.elapsed_s,
    )
    return _metadata(result.to_metadata())


@asset(
    name="ta_study_forward_returns",
    group_name="ta_study",
    description=(
        "Nightly: fill forward returns for divergence events whose horizon "
        "has elapsed and recompute hit rates"
    ),
    compute_kind="python",
    retry_policy=_RETRY,
    tags={**_TAGS, "delivery": "table"},
)
def ta_study_forward_returns(context) -> dict[str, Any]:
    """Score resolved events so the email's hit rates mean something.

    Deliberately separate from the morning job: it needs the day's settles,
    and a failure here must never delay or block the email.
    """
    from ta_study.pipeline import fill_forward_returns

    summary = fill_forward_returns(
        config_path=_config_path(), base_dir=_base_dir()
    )
    context.log.info(
        "scored %s events, %s buckets (%s with a usable sample)",
        summary.get("events_scored"),
        summary.get("buckets"),
        summary.get("sufficient_buckets"),
    )
    return _metadata(
        {
            "as_of": summary.get("as_of", ""),
            "events_scored": summary.get("events_scored", 0),
            "rows_written": summary.get("rows_written", 0),
            "buckets": summary.get("buckets", 0),
            "sufficient_buckets": summary.get("sufficient_buckets", 0),
            "hypothesis": summary.get("hypothesis", {}),
            "warnings": summary.get("warnings", []),
        }
    )


# ---------------------------------------------------------------------------
# jobs and schedules
# ---------------------------------------------------------------------------
ta_study_job = define_asset_job(
    name="ta_study_job",
    selection=[ta_study_bars_daily, ta_study_bars_intraday, ta_study_email],
    description="TA study email - Mon-Fri 06:55 UK",
    tags={**_TAGS, "schedule": "weekday_morning", "dagster/max_runtime": "1800"},
)

ta_study_stats_job = define_asset_job(
    name="ta_study_stats_job",
    selection=[ta_study_forward_returns],
    description="TA study forward returns - Mon-Fri 22:30 UK",
    tags={**_TAGS, "schedule": "weekday_evening", "dagster/max_runtime": "1800"},
)


@schedule(
    job=ta_study_job,
    cron_schedule=STUDY_CRON,
    execution_timezone=TIMEZONE,
    default_status=DEFAULT_SCHEDULE_STATUS,
    name="ta_study_schedule",
)
def ta_study_schedule(context) -> dict[str, Any]:
    context.log.info("TA study run for %s", dt.date.today().isoformat())
    return {}


@schedule(
    job=ta_study_stats_job,
    cron_schedule=STATS_CRON,
    execution_timezone=TIMEZONE,
    default_status=DEFAULT_SCHEDULE_STATUS,
    name="ta_study_stats_schedule",
)
def ta_study_stats_schedule(context) -> dict[str, Any]:
    context.log.info("TA study forward-return fill for %s", dt.date.today().isoformat())
    return {}


ta_study_assets = [
    ta_study_bars_daily,
    ta_study_bars_intraday,
    ta_study_email,
    ta_study_forward_returns,
]
ta_study_jobs = [ta_study_job, ta_study_stats_job]
ta_study_schedules = [ta_study_schedule, ta_study_stats_schedule]

#: Standalone definitions, so ``dagster dev -f ta_study/dagster_defs.py`` works.
defs = Definitions(
    assets=ta_study_assets,
    jobs=ta_study_jobs,
    schedules=ta_study_schedules,
)
