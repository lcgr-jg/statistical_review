"""RSI divergence engine - the study's primary signal (§8a D).

For each confirmed swing ``S2``, the engine looks back to the *immediately
preceding* confirmed swing of the same kind, ``t1 = max{t in H : t < t2}``,
and requires ``s_min <= t2 - t1 <= L_max``. Note that this is deliberately
the nearest prior swing and not "the nearest prior swing that satisfies the
separation": if the previous high is too close, no divergence is emitted
rather than reaching further back. §8a D specifies it that way, and it
keeps the event set a function of the swing sequence alone.

With ``dP = P_t2 - P_t1`` and ``dR = R_t2 - R_t1``:

    bearish regular   dP > 0  and  dR < -delta      (price up, RSI down)
    bullish regular   dP < 0  and  dR > +delta      (price down, RSI up)
    bearish hidden    dP < 0  and  dR > +delta      (continuation)
    bullish hidden    dP > 0  and  dR < -delta      (continuation)

plus, when the zone filter is on, ``R_t1 >= theta_ob_soft`` for bearish and
``R_t1 <= theta_os_soft`` for bullish. Both regular cases satisfy
``m_P * m_R < 0``; the direction is ``d = -sign(m_P)``.

Economically the study is formalising decaying marginal momentum: price
makes progress while participation falls, which reads as late, forced or
automated flow and carries an elevated mean-reversion probability. That
paragraph belongs in the email appendix, not in the code path.

The event's trigger time is ``t* = t2 + k`` - the bar at which ``S2``
becomes observable - never ``t2`` itself.
"""

from __future__ import annotations

import itertools
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

import numpy as np
import numpy.typing as npt

from ta_study.config import DivergenceConfig, RsiConfig, SignalConfig
from ta_study.swings import Swing, confirmed_swings, provisional_swings

FloatArray = npt.NDArray[np.float64]

DivergenceKind = Literal["BEAR", "BULL"]

#: Direction conventions: +1 is a long bias, -1 a short bias (§8a D).
LONG, SHORT = 1, -1


@dataclass(frozen=True)
class Divergence:
    """One emitted divergence event.

    ``triggered_at`` is ``t*``; nothing downstream may act on the event
    before that bar. ``strength`` components are kept separately so the
    weighting can be re-tuned against the persisted history without
    recomputing the study.
    """

    kind: DivergenceKind
    hidden: bool
    s1: Swing
    s2: Swing
    triggered_at: int
    direction: int
    d_price: float
    d_rsi: float
    slope_price: float
    slope_rsi: float
    strength: float
    strength_rsi: float
    strength_price: float
    strength_zone: float
    atr_at_s2: float | None
    provisional: bool = False

    @property
    def bars_between(self) -> int:
        return self.s2.bar_idx - self.s1.bar_idx

    @property
    def label(self) -> str:
        base = "bearish" if self.kind == "BEAR" else "bullish"
        return f"hidden {base}" if self.hidden else base

    @property
    def ts1(self) -> Any:
        return self.s1.ts

    @property
    def ts2(self) -> Any:
        return self.s2.ts

    def expires_at(self, active_window: int) -> int:
        return self.triggered_at + active_window


# ---------------------------------------------------------------------------
# strength score (§8a D)
# ---------------------------------------------------------------------------
def strength_components(
    d_rsi: float,
    d_price: float,
    rsi_s1: float,
    atr_at_s2: float | None,
    signal: SignalConfig,
) -> tuple[float, float, float]:
    """The three normalised, clipped components of the strength score.

    ``(|dR| / rsi_scale, |dP| / (atr_multiple * ATR), |R_t1 - 50| / 50)``,
    each clipped to 1. When ATR is unavailable - only possible on a series
    too short for ATR(14) to have warmed up - the price component is 0
    rather than renormalising the weights, so a low score never silently
    means "could not measure".
    """
    rsi_part = min(abs(d_rsi) / signal.strength_rsi_scale, 1.0) if np.isfinite(d_rsi) else 0.0

    if atr_at_s2 is None or not np.isfinite(atr_at_s2) or atr_at_s2 <= 0:
        price_part = 0.0
    else:
        denom = signal.strength_atr_multiple * atr_at_s2
        price_part = min(abs(d_price) / denom, 1.0) if np.isfinite(d_price) else 0.0

    zone_part = min(abs(rsi_s1 - 50.0) / 50.0, 1.0) if np.isfinite(rsi_s1) else 0.0
    return rsi_part, price_part, zone_part


def strength_score(
    d_rsi: float,
    d_price: float,
    rsi_s1: float,
    atr_at_s2: float | None,
    signal: SignalConfig,
) -> tuple[float, tuple[float, float, float]]:
    """``sigma`` in [0, 1] and its components."""
    parts = strength_components(d_rsi, d_price, rsi_s1, atr_at_s2, signal)
    w = signal.strength_weights
    sigma = float(sum(wi * pi for wi, pi in zip(w, parts, strict=True)))
    return min(max(sigma, 0.0), 1.0), parts


# ---------------------------------------------------------------------------
# the engine
# ---------------------------------------------------------------------------
def _classify(
    kind_of_swing: str,
    d_price: float,
    d_rsi: float,
    delta: float,
) -> tuple[DivergenceKind, bool] | None:
    """Map (swing kind, dP, dR) onto (divergence kind, hidden) or nothing."""
    if kind_of_swing == "H":
        if d_price > 0 and d_rsi < -delta:
            return "BEAR", False
        if d_price < 0 and d_rsi > delta:
            return "BEAR", True
        return None
    if d_price < 0 and d_rsi > delta:
        return "BULL", False
    if d_price > 0 and d_rsi < -delta:
        return "BULL", True
    return None


def _passes_zone_filter(
    kind: DivergenceKind, rsi_s1: float, rsi_cfg: RsiConfig
) -> bool:
    """Bearish needs ``R_t1 >= ob_soft``; bullish needs ``R_t1 <= os_soft``."""
    if not np.isfinite(rsi_s1):
        return False
    if kind == "BEAR":
        return bool(rsi_s1 >= rsi_cfg.ob_soft)
    return bool(rsi_s1 <= rsi_cfg.os_soft)


def _build(
    s1: Swing,
    s2: Swing,
    kind: DivergenceKind,
    hidden: bool,
    atr: FloatArray,
    cfg: DivergenceConfig,
    signal: SignalConfig,
    provisional: bool,
) -> Divergence:
    span = s2.bar_idx - s1.bar_idx
    d_price = float(s2.price - s1.price)
    d_rsi = float(s2.rsi - s1.rsi)
    slope_price = d_price / span
    slope_rsi = d_rsi / span

    atr_at_s2: float | None = None
    if atr.size > s2.bar_idx:
        value = atr[s2.bar_idx]
        if np.isfinite(value):
            atr_at_s2 = float(value)

    sigma, (p_rsi, p_price, p_zone) = strength_score(
        d_rsi, d_price, s1.rsi, atr_at_s2, signal
    )

    if hidden:
        # d = -sign(m_P) is the regular-divergence rule; a hidden divergence
        # is a continuation signal, so its direction follows the swing kind.
        direction = SHORT if kind == "BEAR" else LONG
    else:
        direction = SHORT if slope_price > 0 else LONG

    return Divergence(
        kind=kind,
        hidden=hidden,
        s1=s1,
        s2=s2,
        triggered_at=s2.bar_idx + cfg.swing_k,
        direction=direction,
        d_price=d_price,
        d_rsi=d_rsi,
        slope_price=slope_price,
        slope_rsi=slope_rsi,
        strength=sigma,
        strength_rsi=p_rsi,
        strength_price=p_price,
        strength_zone=p_zone,
        atr_at_s2=atr_at_s2,
        provisional=provisional,
    )


def _pair(
    s1: Swing,
    s2: Swing,
    atr: FloatArray,
    cfg: DivergenceConfig,
    rsi_cfg: RsiConfig,
    signal: SignalConfig,
    provisional: bool,
) -> Divergence | None:
    """Test one (S1, S2) pair against §8a D and build the event if it holds."""
    span = s2.bar_idx - s1.bar_idx
    if not (cfg.min_swing_separation <= span <= cfg.max_lookback_bars):
        return None
    if not (np.isfinite(s1.rsi) and np.isfinite(s2.rsi)):
        return None

    d_price = float(s2.price - s1.price)
    d_rsi = float(s2.rsi - s1.rsi)

    classified = _classify(s2.kind, d_price, d_rsi, cfg.min_rsi_delta)
    if classified is None:
        return None
    kind, hidden = classified
    if hidden and not cfg.include_hidden:
        return None
    if cfg.rsi_zone_filter and not _passes_zone_filter(kind, s1.rsi, rsi_cfg):
        return None

    # Regular divergences must have opposing price and RSI slopes; this is
    # implied by the inequalities above and asserted so that a future change
    # to _classify cannot quietly break it (§7).
    if not hidden and d_price * d_rsi >= 0:
        return None

    return _build(s1, s2, kind, hidden, atr, cfg, signal, provisional)


def detect_divergences(
    swings: Sequence[Swing],
    atr: npt.ArrayLike,
    cfg: DivergenceConfig,
    rsi_cfg: RsiConfig,
    signal: SignalConfig,
) -> list[Divergence]:
    """Every confirmed divergence in the series, ordered by ``triggered_at``.

    Provisional swings are excluded here; :func:`detect_provisional` handles
    them separately so they can never be mistaken for a tradable event.
    """
    atr_arr = np.asarray(atr, dtype=np.float64)
    out: list[Divergence] = []

    for kind in ("H", "L"):
        same_kind = confirmed_swings(swings, kind)  # type: ignore[arg-type]
        for prev, cur in itertools.pairwise(same_kind):
            event = _pair(prev, cur, atr_arr, cfg, rsi_cfg, signal, provisional=False)
            if event is not None:
                out.append(event)

    return sorted(out, key=lambda e: (e.triggered_at, e.s2.bar_idx, e.kind))


def detect_provisional(
    swings: Sequence[Swing],
    atr: npt.ArrayLike,
    cfg: DivergenceConfig,
    rsi_cfg: RsiConfig,
    signal: SignalConfig,
) -> list[Divergence]:
    """Divergences a provisional swing *would* form if it confirmed (§8a G).

    Informational only: the PROVISIONAL state exists so the desk can see a
    setup forming, and these events are never persisted as signals.
    """
    atr_arr = np.asarray(atr, dtype=np.float64)
    out: list[Divergence] = []

    for prov in provisional_swings(swings):
        prior = [
            s
            for s in confirmed_swings(swings, prov.kind)
            if s.bar_idx < prov.bar_idx
        ]
        if not prior:
            continue
        event = _pair(prior[-1], prov, atr_arr, cfg, rsi_cfg, signal, provisional=True)
        if event is not None:
            out.append(event)

    return sorted(out, key=lambda e: (e.s2.bar_idx, e.kind))


def events_visible_at(
    events: Sequence[Divergence], bar: int
) -> list[Divergence]:
    """The no-lookahead filter: events whose ``t*`` has arrived by ``bar``.

    §8a I requires that this, applied to a full-series run, equals the event
    set produced by running the engine on the prefix ``[0, bar]``.
    """
    return [e for e in events if not e.provisional and e.triggered_at <= bar]


def latest_event(
    events: Sequence[Divergence], bar: int, include_hidden: bool = False
) -> Divergence | None:
    """Most recent divergence observable at ``bar``, or ``None``."""
    visible = [
        e for e in events_visible_at(events, bar) if include_hidden or not e.hidden
    ]
    if not visible:
        return None
    return max(visible, key=lambda e: (e.triggered_at, e.s2.bar_idx))
