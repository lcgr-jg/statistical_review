"""Indicator kernels: pure functions, arrays in, arrays out.

Implemented natively in numpy against the formulas in §8a rather than
wrapping TA-Lib, for two reasons: TA-Lib is not installed in the ``corelib``
environment (and is a painful source build on Windows), and every recursion
the study needs is specified exactly in the spec. The implementations are
written to **match TA-Lib to 1e-6**, including its warm-up (NaN) lengths, so
that swapping a backend in later is a no-op:

    RSI(14)        first value at index 14
    ATR(14)        first value at index 14
    PLUS_DI(14)    first value at index 14
    ADX(14)        first value at index 27        (2n - 1)
    EMA(n)         first value at index n - 1     (SMA seed)
    STOCH(14,3,3)  %K at index 15, %D at index 17
    BBANDS(20,2)   first value at index 19        (population sigma)

:mod:`ta_study.reference` provides TA-Lib and pandas-ta implementations of
the same functions; ``tests/test_parity.py`` asserts agreement and skips
whichever backend is unavailable.

Conventions
-----------
* every function returns ``float64`` arrays the same length as the input,
* warm-up positions are ``NaN`` - never zero, never forward-filled,
* a NaN inside a recursion carries the previous state forward rather than
  poisoning the rest of the series,
* nothing here reads config; periods are arguments.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
BoolArray = npt.NDArray[np.bool_]

#: %K when the look-back range is degenerate (HH == LL). §8a E specifies 50
#: - the midpoint - where TA-Lib emits 0. Only reachable on a completely
#: flat window, which for a traded contract means a stale feed.
STOCH_FLAT_VALUE = 50.0


def _as_float(values: npt.ArrayLike) -> FloatArray:
    return np.asarray(values, dtype=np.float64)


def _empty_like(values: FloatArray) -> FloatArray:
    return np.full(values.shape, np.nan, dtype=np.float64)


# ---------------------------------------------------------------------------
# smoothing primitives
# ---------------------------------------------------------------------------
def wilder_smooth(values: npt.ArrayLike, n: int, start: int = 0) -> FloatArray:
    """Wilder's smoothing seeded with the mean of the first ``n`` values.

    ``S_{start+n-1} = mean(v_start .. v_{start+n-1})`` then
    ``S_t = ((n-1) S_{t-1} + v_t) / n``  (§8a B).

    ``start`` is the first index that carries a value; series derived from a
    one-bar difference (gains, losses, true range) pass ``start=1`` so the
    seed window is ``v_1..v_n`` and the first output lands at index ``n``,
    which is what TA-Lib does.

    Scaling note: seeding with the *sum* instead of the mean - as TA-Lib
    does internally for +DM/-DM/TR - produces exactly ``n`` times these
    values, and every consumer here takes a ratio of two smoothed series, so
    the choice is immaterial.
    """
    v = _as_float(values)
    out = _empty_like(v)
    if n < 1 or v.size == 0:
        return out

    finite = np.isfinite(v)
    finite[:start] = False
    idx = np.flatnonzero(finite)
    if idx.size < n:
        return out

    seed_end = int(idx[n - 1])
    prev = float(np.mean(v[idx[:n]]))
    out[seed_end] = prev
    for i in range(seed_end + 1, v.size):
        x = v[i]
        if np.isfinite(x):
            prev = ((n - 1) * prev + x) / n
        out[i] = prev
    return out


def sma(values: npt.ArrayLike, n: int) -> FloatArray:
    """Simple moving average; NaN until ``n`` values are available.

    A NaN anywhere in the window makes the output NaN, matching TA-Lib
    (which has no notion of a partial window).
    """
    v = _as_float(values)
    out = _empty_like(v)
    if n < 1 or v.size < n:
        return out
    # Cumulative sums give an O(T) window mean. NaNs are zero-filled for the
    # sum and counted separately, so a window containing one is NaN while
    # later windows - which is to say every window past the warm-up of the
    # input series - stay valid. Summing the raw array instead would let a
    # single leading NaN poison the entire tail.
    mask = np.isfinite(v)
    csum = np.cumsum(np.insert(np.where(mask, v, 0.0), 0, 0.0))
    ccnt = np.cumsum(np.insert(mask.astype(np.int64), 0, 0))
    window_sum = csum[n:] - csum[:-n]
    window_cnt = ccnt[n:] - ccnt[:-n]
    out[n - 1 :] = np.where(window_cnt == n, window_sum / n, np.nan)
    return out


def rolling_std(values: npt.ArrayLike, n: int, ddof: int = 0) -> FloatArray:
    """Rolling standard deviation. ``ddof=0`` (population) matches TA-Lib."""
    v = _as_float(values)
    out = _empty_like(v)
    if n < 1 or v.size < n:
        return out
    for i in range(n - 1, v.size):
        win = v[i - n + 1 : i + 1]
        if not np.all(np.isfinite(win)):
            continue
        if n - ddof <= 0:
            continue
        out[i] = float(np.std(win, ddof=ddof))
    return out


def ema(values: npt.ArrayLike, n: int) -> FloatArray:
    """Exponential MA, ``alpha = 2/(n+1)``, seeded with the SMA of the first
    ``n`` finite values - TA-Lib's convention, first output at index ``n-1``."""
    v = _as_float(values)
    out = _empty_like(v)
    if n < 1 or v.size == 0:
        return out

    idx = np.flatnonzero(np.isfinite(v))
    if idx.size < n:
        return out

    alpha = 2.0 / (n + 1.0)
    seed_end = int(idx[n - 1])
    prev = float(np.mean(v[idx[:n]]))
    out[seed_end] = prev
    for i in range(seed_end + 1, v.size):
        x = v[i]
        if np.isfinite(x):
            prev = prev + alpha * (x - prev)
        out[i] = prev
    return out


def rolling_max(values: npt.ArrayLike, n: int) -> FloatArray:
    """Rolling maximum over ``n`` bars inclusive of the current one."""
    v = _as_float(values)
    out = _empty_like(v)
    for i in range(n - 1, v.size):
        win = v[i - n + 1 : i + 1]
        if not np.all(np.isfinite(win)):
            continue
        out[i] = float(np.max(win))
    return out


def rolling_min(values: npt.ArrayLike, n: int) -> FloatArray:
    """Rolling minimum over ``n`` bars inclusive of the current one."""
    v = _as_float(values)
    out = _empty_like(v)
    for i in range(n - 1, v.size):
        win = v[i - n + 1 : i + 1]
        if not np.all(np.isfinite(win)):
            continue
        out[i] = float(np.min(win))
    return out


def rolling_rank_pct(values: npt.ArrayLike, n: int, min_obs: int | None = None) -> FloatArray:
    """Percentile rank of each point within its trailing window, in [0, 1]."""
    v = _as_float(values)
    out = _empty_like(v)
    floor = min_obs if min_obs is not None else n
    for i in range(v.size):
        cur = v[i]
        if not np.isfinite(cur):
            continue
        win = v[max(0, i - n + 1) : i + 1]
        win = win[np.isfinite(win)]
        if win.size < floor:
            continue
        out[i] = float(np.mean(win <= cur))
    return out


# ---------------------------------------------------------------------------
# §8a B - RSI
# ---------------------------------------------------------------------------
def rsi(close: npt.ArrayLike, n: int = 14) -> FloatArray:
    """Wilder RSI.

    ``U_t = max(C_t - C_{t-1}, 0)``, ``D_t = max(C_{t-1} - C_t, 0)``, both
    Wilder-smoothed over ``n``; ``RSI = 100 - 100/(1 + Ubar/Dbar)`` and 100
    where ``Dbar = 0``. NaN for ``t < n``.
    """
    c = _as_float(close)
    diff = np.diff(c, prepend=np.nan)
    gains = np.where(np.isfinite(diff), np.maximum(diff, 0.0), np.nan)
    losses = np.where(np.isfinite(diff), np.maximum(-diff, 0.0), np.nan)

    avg_gain = wilder_smooth(gains, n, start=1)
    avg_loss = wilder_smooth(losses, n, start=1)

    out = np.full(c.shape, np.nan, dtype=np.float64)
    defined = np.isfinite(avg_gain) & np.isfinite(avg_loss)
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = np.where(avg_loss > 0, avg_gain / avg_loss, np.inf)
        vals = 100.0 - 100.0 / (1.0 + rs)
    # Dbar == 0 means an unbroken run of gains (or a flat series, where
    # Ubar is also 0 and RSI is conventionally 100 in TA-Lib).
    out[defined] = vals[defined]
    return out


# ---------------------------------------------------------------------------
# §8a E - stochastic oscillator
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Stoch:
    k: FloatArray
    d: FloatArray
    k_raw: FloatArray


def stoch(
    high: npt.ArrayLike,
    low: npt.ArrayLike,
    close: npt.ArrayLike,
    k_period: int = 14,
    k_smooth: int = 3,
    d_period: int = 3,
    fast: bool = False,
) -> Stoch:
    """Slow stochastic - TA-Lib ``STOCH(k_period, k_smooth, d_period)``.

    ``K_raw = 100 (C - LL) / (HH - LL)`` over ``k_period`` bars, then
    ``K = SMA(K_raw, k_smooth)`` and ``D = SMA(K, d_period)``.
    ``fast=True`` sets ``K = K_raw`` (fast stochastic).
    """
    h, lo, c = _as_float(high), _as_float(low), _as_float(close)
    hh = rolling_max(h, k_period)
    ll = rolling_min(lo, k_period)

    rng = hh - ll
    k_raw = np.full(c.shape, np.nan, dtype=np.float64)
    defined = np.isfinite(rng) & np.isfinite(c)
    with np.errstate(divide="ignore", invalid="ignore"):
        scaled = 100.0 * (c - ll) / rng
    k_raw[defined] = np.where(rng[defined] > 0, scaled[defined], STOCH_FLAT_VALUE)

    k = k_raw.copy() if fast else sma(k_raw, k_smooth)
    d = sma(k, d_period)
    return Stoch(k=k, d=d, k_raw=k_raw)


def stoch_crosses(
    k: npt.ArrayLike, d: npt.ArrayLike, ob: float = 80.0, os: float = 20.0
) -> tuple[BoolArray, BoolArray]:
    """In-zone %K/%D cross events ``(X_plus, X_minus)`` (§8a E).

    ``X+_t = 1[K_{t-1} <= D_{t-1} and K_t > D_t and K_{t-1} < os]``
    ``X-_t = 1[K_{t-1} >= D_{t-1} and K_t < D_t and K_{t-1} > ob]``

    The zone test is on the *previous* bar: the cross is only a reversal
    signal if the oscillator was still extended when it turned.
    """
    ka, da = _as_float(k), _as_float(d)
    n = ka.size
    plus = np.zeros(n, dtype=bool)
    minus = np.zeros(n, dtype=bool)
    for t in range(1, n):
        k0, k1 = ka[t - 1], ka[t]
        d0, d1 = da[t - 1], da[t]
        if not (np.isfinite(k0) and np.isfinite(k1) and np.isfinite(d0) and np.isfinite(d1)):
            continue
        if k0 <= d0 and k1 > d1 and k0 < os:
            plus[t] = True
        if k0 >= d0 and k1 < d1 and k0 > ob:
            minus[t] = True
    return plus, minus


# ---------------------------------------------------------------------------
# §8a F - true range, ATR, DMI / ADX
# ---------------------------------------------------------------------------
def true_range(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike
) -> FloatArray:
    """``TR_t = max(H-L, |H - C_{t-1}|, |L - C_{t-1}|)``; NaN at ``t = 0``."""
    h, lo, c = _as_float(high), _as_float(low), _as_float(close)
    if c.size == 0:
        # A product with no bars at all still has to flow through the study.
        return _empty_like(c)
    prev_close = np.roll(c, 1)
    prev_close[0] = np.nan
    tr = np.maximum(
        np.maximum(h - lo, np.abs(h - prev_close)), np.abs(lo - prev_close)
    )
    tr[0] = np.nan
    return tr


def atr(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike, n: int = 14
) -> FloatArray:
    """Wilder ATR; first value at index ``n``."""
    return wilder_smooth(true_range(high, low, close), n, start=1)


def directional_movement(
    high: npt.ArrayLike, low: npt.ArrayLike
) -> tuple[FloatArray, FloatArray]:
    """``(+DM, -DM)`` per §8a F; both NaN at ``t = 0``.

    Only the larger of the two moves is recorded, and only when positive -
    an inside bar contributes nothing to either side.
    """
    h, lo = _as_float(high), _as_float(low)
    up = np.diff(h, prepend=np.nan)
    down = -np.diff(lo, prepend=np.nan)

    plus = np.where((up > down) & (up > 0), up, 0.0)
    minus = np.where((down > up) & (down > 0), down, 0.0)
    undefined = ~(np.isfinite(up) & np.isfinite(down))
    plus[undefined] = np.nan
    minus[undefined] = np.nan
    return plus, minus


@dataclass(frozen=True)
class Dmi:
    plus_di: FloatArray
    minus_di: FloatArray
    adx: FloatArray
    dx: FloatArray


def dmi(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike, n: int = 14
) -> Dmi:
    """``+DI``, ``-DI``, ``DX`` and ``ADX`` per §8a F.

    ``+DM``, ``-DM`` and ``TR`` are Wilder-smoothed over ``n`` (first value
    at index ``n``), giving ``DI = 100 * DM_s / TR_s``. ``DX`` is the
    normalised DI spread and ``ADX = Wilder_n(DX)``, seeded with the mean of
    the first ``n`` DX values so the first ADX lands at index ``2n - 1``.

    ADX is non-directional: it measures the magnitude of a trend, not its
    sign. The gate in :mod:`ta_study.study` uses it for exactly that.
    """
    plus_dm, minus_dm = directional_movement(high, low)
    tr = true_range(high, low, close)

    plus_s = wilder_smooth(plus_dm, n, start=1)
    minus_s = wilder_smooth(minus_dm, n, start=1)
    tr_s = wilder_smooth(tr, n, start=1)

    with np.errstate(divide="ignore", invalid="ignore"):
        plus_di = np.where(tr_s > 0, 100.0 * plus_s / tr_s, np.nan)
        minus_di = np.where(tr_s > 0, 100.0 * minus_s / tr_s, np.nan)
        di_sum = plus_di + minus_di
        dx = np.where(di_sum > 0, 100.0 * np.abs(plus_di - minus_di) / di_sum, 0.0)
    dx = np.where(np.isfinite(plus_di) & np.isfinite(minus_di), dx, np.nan)

    # DX is NaN until index n, and wilder_smooth seeds on the first n finite
    # values, so the ADX seed lands at index 2n - 1 with no offset needed.
    adx_series = wilder_smooth(dx, n)
    return Dmi(plus_di=plus_di, minus_di=minus_di, adx=adx_series, dx=dx)


def adx_rising(adx: npt.ArrayLike, r: int = 3) -> BoolArray:
    """``ADX_t > ADX_{t-r}`` (§8a F gate)."""
    a = _as_float(adx)
    out = np.zeros(a.size, dtype=bool)
    if r < 1:
        return out
    for t in range(r, a.size):
        if np.isfinite(a[t]) and np.isfinite(a[t - r]):
            out[t] = bool(a[t] > a[t - r])
    return out


def adx_falling_streak(adx: npt.ArrayLike, r: int = 3) -> BoolArray:
    """``ADX_t < ADX_{t-1}`` on each of ``r`` consecutive bars (§8a F release)."""
    a = _as_float(adx)
    out = np.zeros(a.size, dtype=bool)
    if r < 1:
        return out
    for t in range(r, a.size):
        window = a[t - r : t + 1]
        if not np.all(np.isfinite(window)):
            continue
        out[t] = bool(np.all(np.diff(window) < 0))
    return out


def adx_gate(
    adx: npt.ArrayLike, threshold: float, r: int = 3
) -> BoolArray:
    """``G_t = 1[ADX_t >= theta and ADX_t > ADX_{t-r}]`` (§8a F).

    ``G_t = 1`` is the momentum-dominant regime: mean-reversion expectancy
    is low, so divergence entries are delayed or sized down.
    """
    a = _as_float(adx)
    above = np.zeros(a.size, dtype=bool)
    finite = np.isfinite(a)
    above[finite] = a[finite] >= threshold
    return above & adx_rising(a, r)


# ---------------------------------------------------------------------------
# MACD and Bollinger bands
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Macd:
    line: FloatArray
    signal: FloatArray
    hist: FloatArray


def macd(
    close: npt.ArrayLike, fast: int = 12, slow: int = 26, signal: int = 9
) -> Macd:
    """MACD line, signal and histogram.

    ``line = EMA(fast) - EMA(slow)``, ``signal = EMA(line, signal)``,
    ``hist = line - signal``. The line is emitted from index ``slow-1``;
    TA-Lib suppresses it until the signal is also available, so a parity
    check should compare on the region where both backends are finite.
    """
    c = _as_float(close)
    line = ema(c, fast) - ema(c, slow)
    sig = ema(line, signal)
    return Macd(line=line, signal=sig, hist=line - sig)


@dataclass(frozen=True)
class BBands:
    upper: FloatArray
    middle: FloatArray
    lower: FloatArray

    @property
    def bandwidth(self) -> FloatArray:
        with np.errstate(divide="ignore", invalid="ignore"):
            return np.where(
                self.middle != 0, (self.upper - self.lower) / self.middle, np.nan
            )


def bbands(close: npt.ArrayLike, n: int = 20, std: float = 2.0) -> BBands:
    """Bollinger bands on the SMA with a *population* sigma (TA-Lib)."""
    c = _as_float(close)
    middle = sma(c, n)
    sd = rolling_std(c, n, ddof=0)
    return BBands(upper=middle + std * sd, middle=middle, lower=middle - std * sd)


def percent_b(close: npt.ArrayLike, bands: BBands) -> FloatArray:
    """``%B = (C - lower) / (upper - lower)``; >1 or <0 means outside."""
    c = _as_float(close)
    width = bands.upper - bands.lower
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(width > 0, (c - bands.lower) / width, np.nan)


# ---------------------------------------------------------------------------
# candlestick patterns (TA-Lib only)
# ---------------------------------------------------------------------------
#: Patterns reported as text tags, never as signals (§9).
CANDLE_PATTERNS: tuple[str, ...] = (
    "CDLENGULFING",
    "CDLHAMMER",
    "CDLSHOOTINGSTAR",
    "CDLDOJI",
    "CDLMORNINGSTAR",
    "CDLEVENINGSTAR",
)

#: Human labels for the email.
CANDLE_LABELS: dict[str, str] = {
    "CDLENGULFING": "engulfing",
    "CDLHAMMER": "hammer",
    "CDLSHOOTINGSTAR": "shooting star",
    "CDLDOJI": "doji",
    "CDLMORNINGSTAR": "morning star",
    "CDLEVENINGSTAR": "evening star",
}


def talib_available() -> bool:
    try:
        import talib  # noqa: F401
    except Exception:
        return False
    return True


def candle_patterns(
    open_: npt.ArrayLike,
    high: npt.ArrayLike,
    low: npt.ArrayLike,
    close: npt.ArrayLike,
    lookback: int = 3,
) -> dict[str, int]:
    """Patterns completing in the last ``lookback`` bars, as ``{name: sign}``.

    Empty when TA-Lib is unavailable - these are cosmetic tags, so the
    caller reports "patterns unavailable" in the appendix rather than
    failing. Hand-rolling six candlestick definitions would invite
    disagreement with every other terminal on the desk.
    """
    if not talib_available():
        return {}
    import talib

    o = _as_float(open_)
    h = _as_float(high)
    lo = _as_float(low)
    c = _as_float(close)
    out: dict[str, int] = {}
    for name in CANDLE_PATTERNS:
        fn = getattr(talib, name, None)
        if fn is None:
            continue
        series = np.asarray(fn(o, h, lo, c), dtype=np.float64)
        tail = series[-lookback:] if lookback > 0 else series
        nonzero = tail[np.isfinite(tail) & (tail != 0)]
        if nonzero.size:
            out[name] = int(np.sign(nonzero[-1]))
    return out
