"""Orchestration: data -> study -> charts -> email -> persistence.

One entry point, :func:`run_ta_study`, used by both the CLI and the Dagster
assets, plus two maintenance jobs:

``backfill_study_state``  replays the state machine over a date range using
                          only the bars that existed on each date, asserting
                          that no event's ``t*`` post-dates the as-of bar.
``fill_forward_returns``  re-scores recent divergence events now that more
                          bars have printed.

Failure policy: one product, one horizon or one chart failing degrades the
email rather than cancelling it. Only a failure that leaves nothing to say -
no bars at all, or the send itself failing - is allowed to raise.
"""

from __future__ import annotations

import datetime as dt
import json
import logging
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import polars as pl

from common import deliver
from common.bbg import BloombergClient
from ta_study import charts as charts_mod
from ta_study import data as data_mod
from ta_study.config import ProductConfig, StudyConfig, load_config
from ta_study.render import (
    ChartRef,
    build_email,
    caption_block,
    make_chart_ref,
    make_product_chart_ref,
)
from ta_study.secondary import SecondaryResult, compute_secondary
from ta_study.stats import (
    EventRecord,
    HitRateIndex,
    event_records,
    hit_rates,
    hypothesis_check,
)
from ta_study.store import TaStore, divergence_event_row
from ta_study.study import Alignment, StudyResult, alignment, run_study

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# logging (§15: structured JSON with product / horizon / stage)
# ---------------------------------------------------------------------------
class JsonFormatter(logging.Formatter):
    """One JSON object per line, carrying whatever context was attached."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": dt.datetime.fromtimestamp(record.created, dt.UTC).isoformat(
                timespec="milliseconds"
            ),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key in ("product", "horizon", "stage"):
            value = getattr(record, key, None)
            if value is not None:
                payload[key] = value
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload)


def configure_logging(level: int = logging.INFO, json_logs: bool = True) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(
        JsonFormatter() if json_logs else logging.Formatter("%(levelname)s %(name)s: %(message)s")
    )
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level)


def _stage(stage: str, product: str | None = None, horizon: str | None = None) -> dict[str, Any]:
    return {"extra": {"stage": stage, "product": product, "horizon": horizon}}


# ---------------------------------------------------------------------------
# result bundle
# ---------------------------------------------------------------------------
@dataclass
class RunResult:
    """Everything a caller (CLI, Dagster) needs to report on the run."""

    run_date: dt.date
    started_at: dt.datetime
    finished_at: dt.datetime | None = None
    results: list[StudyResult] = field(default_factory=list)
    secondary: dict[tuple[str, str], SecondaryResult] = field(default_factory=dict)
    alignments: list[Alignment] = field(default_factory=list)
    records: list[EventRecord] = field(default_factory=list)
    subject: str = ""
    html_path: Path | None = None
    chart_dir: Path | None = None
    sent_via: str | None = None
    recipients: list[str] = field(default_factory=list)
    size_bytes: int = 0
    dropped_charts: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    rows_written: dict[str, int] = field(default_factory=dict)
    dry_run: bool = False

    @property
    def elapsed_s(self) -> float:
        end = self.finished_at or dt.datetime.now()
        return (end - self.started_at).total_seconds()

    @property
    def counts(self) -> dict[str, int]:
        from ta_study.render import summarise

        return summarise(self.results)

    def to_metadata(self) -> dict[str, Any]:
        """Flat, JSON-safe summary for Dagster metadata and the CLI."""
        counts = self.counts
        return {
            "run_date": self.run_date.isoformat(),
            "subject": self.subject,
            "n_pairs": len(self.results),
            "n_active": counts.get("active", 0),
            "n_confirmed": counts.get("confirmed", 0),
            "n_gated": counts.get("gated", 0),
            "n_alignments": len(self.alignments),
            "alignment_products": sorted({a.product for a in self.alignments}),
            "n_events": len(self.records),
            "email_sent": self.sent_via is not None,
            "sent_via": self.sent_via or "",
            "recipients": self.recipients,
            "size_mb": round(self.size_bytes / 1024 / 1024, 2),
            "dropped_charts": self.dropped_charts,
            "html_path": str(self.html_path) if self.html_path else "",
            "rows_written": self.rows_written,
            "elapsed_s": round(self.elapsed_s, 1),
            "warnings": self.warnings,
            "dry_run": self.dry_run,
        }


# ---------------------------------------------------------------------------
# data loading
# ---------------------------------------------------------------------------
def load_bars(
    cfg: StudyConfig,
    client: BloombergClient | None,
    store: TaStore | None,
    as_of: dt.date,
    report: data_mod.BarReport,
    products: Sequence[ProductConfig] | None = None,
) -> tuple[dict[str, pl.DataFrame], dict[str, pl.DataFrame]]:
    """``({product: daily}, {product: intraday})``, normalised.

    Intraday history is read from Snowflake first and topped up from
    Bloomberg, then written back: B-PIPE only retains about 140 days, so the
    table is what makes a 400-bar 1h window possible at all.
    """
    daily: dict[str, pl.DataFrame] = {}
    intraday: dict[str, pl.DataFrame] = {}
    prods = list(products if products is not None else cfg.products)

    start, end = data_mod.daily_window(cfg, as_of)
    intra_start, intra_end = data_mod.intraday_window(cfg, as_of)
    base_interval = cfg.intraday_base_interval

    for product in prods:
        if client is None:
            daily[product.name] = data_mod.empty_bars()
            intraday[product.name] = data_mod.empty_bars()
            continue

        log.info("fetching daily bars", **_stage("bars_daily", product.name))
        raw = client.fetch_daily_bars(product.ticker, start, end)
        daily[product.name] = data_mod.normalise_daily(raw)
        if daily[product.name].is_empty():
            report.warn(f"{product.name}: no daily history for {product.ticker}")

        if not cfg.needs_intraday:
            intraday[product.name] = data_mod.empty_bars()
            continue

        persisted = (
            store.load_intraday_bars(product.ticker, base_interval, intra_start)
            if store is not None
            else data_mod.empty_bars()
        )
        log.info("fetching intraday bars", **_stage("bars_intraday", product.name))
        fetched = data_mod.normalise_intraday(
            client.fetch_intraday(
                product.ticker,
                intra_start,
                intra_end,
                interval_min=base_interval,
                gap_fill=True,
            )
        )
        merged = data_mod.merge_intraday(persisted, fetched)
        intraday[product.name] = merged
        if merged.is_empty():
            report.warn(
                f"{product.name}: no {base_interval}m bars from Bloomberg or Snowflake"
            )
        elif store is not None and not fetched.is_empty():
            store.save_intraday_bars(product.ticker, base_interval, fetched)

    return daily, intraday


# ---------------------------------------------------------------------------
# the run
# ---------------------------------------------------------------------------
#: Signature of a bar source: ``(cfg, as_of) -> ({product: daily}, {product: intraday})``.
BarsProvider = Callable[
    [StudyConfig, dt.date], "tuple[dict[str, pl.DataFrame], dict[str, pl.DataFrame]]"
]


def run_ta_study(
    config_path: str | Path | None = None,
    as_of: dt.date | None = None,
    dry_run: bool = False,
    recipients: Sequence[str] | None = None,
    use_cache: bool = True,
    no_parallel: bool = False,
    products: Sequence[str] | None = None,
    horizons: Sequence[str] | None = None,
    base_dir: str | Path | None = None,
    offline: bool = False,
    bars_provider: BarsProvider | None = None,
) -> RunResult:
    """Run the study and send the email.

    ``dry_run`` writes the HTML and every chart to ``run.output_dir`` and
    skips the send. ``offline`` additionally skips Bloomberg, which is what
    a no-entitlement laptop uses.

    ``bars_provider`` replaces the Bloomberg/Snowflake bar loader with any
    callable returning the same pair of frame dicts. It exists so the whole
    pipeline - study, charts, email, persistence - can be exercised against
    known data, and so a replay can be driven from saved Parquet.
    """
    started = dt.datetime.now()
    cfg = load_config(config_path)
    run_date = as_of or dt.date.today()
    root = Path(base_dir) if base_dir else Path.cwd()

    to_addr = list(recipients) if recipients else list(cfg.run.recipients)
    out = RunResult(run_date=run_date, started_at=started, dry_run=dry_run, recipients=to_addr)

    prod_cfgs = [p for p in cfg.products if products is None or p.name in products]
    horizon_names = (
        {h.name for h in cfg.active_horizons} if horizons is None else set(horizons)
    )
    pairs = [
        (p, h)
        for p, h in cfg.pairs()
        if p.name in {x.name for x in prod_cfgs} and h.name in horizon_names
    ]
    if not pairs:
        msg = "no (product, horizon) pairs selected"
        raise ValueError(msg)

    # Check the transport before spending 20-30s on bars and charts. A wrong
    # interpreter or a missing credential should cost a second, not a full run.
    if not dry_run and to_addr:
        deliver.preflight(cfg.delivery)

    store = TaStore(cfg, root)
    prev_states = store.load_prev_states()
    report = data_mod.BarReport()

    client = (
        None
        if offline or bars_provider is not None
        else BloombergClient(
            root / cfg.run.cache_dir,
            on_server=cfg.bloomberg_on_server,
            use_cache=use_cache,
        )
    )

    # -- bars ------------------------------------------------------------
    if bars_provider is not None:
        daily, intraday = bars_provider(cfg, run_date)
    else:
        daily, intraday = load_bars(cfg, client, store, run_date, report, prod_cfgs)

    # -- study -----------------------------------------------------------
    results: list[StudyResult] = []
    secondary: dict[tuple[str, str], SecondaryResult] = {}
    records: list[EventRecord] = []

    for product, horizon in pairs:
        key = (product.name, horizon.name)
        try:
            bars = data_mod.build_horizon(
                daily.get(product.name, data_mod.empty_bars()),
                intraday.get(product.name, data_mod.empty_bars()),
                product,
                horizon,
                cfg,
                report,
            )
            if bars.is_empty():
                continue
            prev = prev_states.get(key)
            result = run_study(
                bars,
                cfg,
                product.name,
                horizon.name,
                prev_state=prev.state if prev else None,  # type: ignore[arg-type]
            )
            results.append(result)
            report.warnings.extend(result.warnings)

            secondary[key] = compute_secondary(
                result.series,  # type: ignore[arg-type]
                cfg,
                product.name,
                horizon.name,
                daily_ranges=horizon.name == "D" or not horizon.is_intraday,
            )
            records.extend(event_records(result, cfg))
        except Exception as exc:
            log.exception("study failed", **_stage("study", product.name, horizon.name))
            report.warn(f"{product.name} {horizon.name}: study failed ({exc})")

    if not results:
        msg = "no (product, horizon) produced a study result"
        raise RuntimeError(msg)

    out.results = results
    out.secondary = secondary
    out.records = records
    out.alignments = alignment(results)

    # -- statistics ------------------------------------------------------
    history = _history_records(store, records)
    rates = hit_rates(history, cfg.stats)
    hit_index = HitRateIndex(rates, cfg.stats)
    hypothesis = hypothesis_check(rates, cfg.stats)

    # -- charts ----------------------------------------------------------
    full_refs, thumb_refs = _build_charts(
        cfg, results, secondary, out.alignments, hit_index, no_parallel
    )

    # -- email -----------------------------------------------------------
    email = build_email(
        results=results,
        secondary=secondary,
        alignments=out.alignments,
        full_charts=full_refs,
        thumbnails=thumb_refs,
        cfg=cfg,
        run_date=run_date,
        hypothesis=hypothesis,
        warnings=report.warnings + store.errors,
        diagnostics=_diagnostics(cfg, client, report, store),
    )
    out.subject = email.subject
    out.size_bytes = email.size_bytes
    out.dropped_charts = [c.label for c in email.plan.dropped]
    out.warnings = report.warnings + store.errors

    # -- deliver ---------------------------------------------------------
    out_dir = root / cfg.run.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path = out_dir / f"ta_study_{run_date:%Y%m%d}.html"
    html_path.write_text(email.html, encoding="utf-8")
    out.html_path = html_path

    if dry_run:
        chart_dir = out_dir / f"charts_{run_date:%Y%m%d}"
        chart_dir.mkdir(parents=True, exist_ok=True)
        for img in email.inline:
            (chart_dir / img.filename).write_bytes(img.content)
        out.chart_dir = chart_dir
        log.info("dry run: wrote %s", html_path, **_stage("deliver"))
    elif to_addr:
        sent = deliver.send(
            cfg.delivery,
            email.subject,
            email.html,
            to_addr,
            inline=email.inline,
        )
        out.sent_via = sent.transport
        out.warnings.extend(sent.warnings)
    else:
        out.warnings.append("no recipients configured; email not sent")

    # -- persist ---------------------------------------------------------
    store.save_states(results, secondary, started, run_date)
    store.save_divergence_events(records)
    store.save_ma_crosses(results, secondary)
    out.rows_written = dict(store.rows_written)
    store.close()

    out.finished_at = dt.datetime.now()
    log.info(
        "run complete in %.1fs: %s", out.elapsed_s, email.subject, **_stage("done")
    )
    return out


def _history_records(
    store: TaStore, current: Sequence[EventRecord]
) -> list[EventRecord]:
    """Persisted event history merged with this run's events.

    The persisted rows are what make the hit rates meaningful; on a cold
    warehouse the run falls back to whatever the current bar windows hold,
    which will legitimately read ``insufficient``.
    """
    rows = store.load_event_history()
    if not rows:
        return list(current)

    from ta_study.stats import ForwardReturn

    out: list[EventRecord] = []
    for row in rows:
        record = EventRecord(
            product=row.get("PRODUCT", ""),
            horizon=row.get("HORIZON", ""),
            triggered_ts=row.get("TRIGGERED_TS"),
            s1_ts=row.get("S1_TS"),
            s2_ts=row.get("S2_TS"),
            kind=row.get("KIND", ""),
            hidden=bool(row.get("HIDDEN")),
            direction=int(row.get("DIRECTION") or 0),
            strength=float(row.get("STRENGTH") or 0.0),
            strength_rsi=float(row.get("STRENGTH_RSI") or 0.0),
            strength_price=float(row.get("STRENGTH_PRICE") or 0.0),
            strength_zone=float(row.get("STRENGTH_ZONE") or 0.0),
            d_price=float(row.get("D_PRICE") or 0.0),
            d_rsi=float(row.get("D_RSI") or 0.0),
            confirmed=bool(row.get("CONFIRMED")),
            gated=bool(row.get("GATED")),
            confirmation_lag=row.get("CONFIRMATION_LAG"),
            trigger_close=row.get("TRIGGER_CLOSE"),
            trigger_atr=row.get("TRIGGER_ATR"),
        )
        for h in (5, 10, 20):
            pct = row.get(f"FWD_{h}_PCT")
            atr_units = row.get(f"FWD_{h}_ATR")
            if pct is None:
                continue
            record.returns[h] = ForwardReturn(
                bars=h,
                pct=float(pct),
                atr_units=None if atr_units is None else float(atr_units),
                signed_pct=record.direction * float(pct),
                signed_atr=None if atr_units is None else record.direction * float(atr_units),
            )
        out.append(record)

    # This run's events win on key collision - they carry newer returns.
    merged = {r.key: r for r in out}
    merged.update({r.key: r for r in current})
    return list(merged.values())


def _build_charts(
    cfg: StudyConfig,
    results: Sequence[StudyResult],
    secondary: dict[tuple[str, str], SecondaryResult],
    alignments: Sequence[Alignment],
    hit_index: HitRateIndex,
    no_parallel: bool,
) -> tuple[list[ChartRef], list[ChartRef]]:
    """One combined chart per product: a column per horizon.

    Every product gets one, not just those with a live signal. Reading the
    frequencies side by side is the point of the study, and the scan value
    of seeing all six products in the same format is what the thumbnail
    strip used to provide at far greater size.

    Products are ordered by cross-horizon alignment, then by their strongest
    horizon, so whatever is actually happening leads the email.
    """
    align_score = {a.product: a.magnitude for a in alignments}

    # Columns follow run.horizon_order, the same ordering the signal grid
    # uses, so the two halves of the email cannot disagree.
    by_product: dict[str, list[StudyResult]] = {}
    for res in results:
        by_product.setdefault(res.product, []).append(res)
    for group in by_product.values():
        group.sort(key=lambda r: cfg.horizon_rank(r.horizon))

    def rank(product: str) -> tuple[float, float, str]:
        group = by_product[product]
        return (
            -align_score.get(product, 0.0),
            -max((r.strength for r in group), default=0.0),
            product,
        )

    ordered = sorted(by_product, key=rank)
    groups = [(product, by_product[product]) for product in ordered]

    t0 = time.perf_counter()
    rendered = charts_mod.render_product_charts(
        groups, cfg, workers=0 if no_parallel else None
    )
    log.info(
        "rendered %d product charts in %.1fs",
        len(rendered),
        time.perf_counter() - t0,
        **_stage("charts"),
    )

    refs: list[ChartRef] = []
    for product in ordered:
        group = by_product[product]
        prod_cfg = cfg.product(product)
        blocks = [
            caption_block(res, secondary.get(res.key), cfg, hit_index) for res in group
        ]
        ref = make_product_chart_ref(
            product,
            rendered.get(product, b""),
            blocks,
            display=prod_cfg.display if prod_cfg else product,
            strength=max((r.strength for r in group), default=0.0),
            alignment_score=align_score.get(product, 0.0),
        )
        if ref is not None:
            refs.append(ref)

    # The combined charts replace the thumbnail strip; the strip is kept
    # behind a config flag for anyone who wants the old per-cell scan.
    thumb_refs: list[ChartRef] = []
    if cfg.run.include_thumbnail_strip:
        thumbs = charts_mod.render_charts(
            [(r, "thumb") for r in results], cfg, workers=0 if no_parallel else None
        )
        for res in results:
            thumb = make_chart_ref(
                res, thumbs.get((res.product, res.horizon, "thumb"), b""), "thumb"
            )
            if thumb is not None:
                thumb_refs.append(thumb)

    return refs, thumb_refs


def _diagnostics(
    cfg: StudyConfig,
    client: BloombergClient | None,
    report: data_mod.BarReport,
    store: TaStore,
) -> dict[str, Any]:
    pairs = len(report.rows)
    thin = sorted(
        f"{p} {h} ({n})" for (p, h), n in report.rows.items() if n < cfg.run.min_bars
    )
    latest = max(report.last_ts.values()) if report.last_ts else None
    return {
        "pairs": pairs,
        "latest bar": str(latest) if latest is not None else "n/a",
        "bbg latency": f"{client.report.latency_s:.1f}s" if client else "offline",
        "cache": (
            f"{client.report.cache_hits} hit / {client.report.cache_misses} miss"
            if client
            else "n/a"
        ),
        "persisted": ", ".join(f"{k}={v}" for k, v in store.rows_written.items()) or "none",
        "thin series": ", ".join(thin) or "none",
    }


# ---------------------------------------------------------------------------
# maintenance jobs
# ---------------------------------------------------------------------------
def backfill_study_state(
    start: dt.date,
    end: dt.date,
    config_path: str | Path | None = None,
    base_dir: str | Path | None = None,
    offline: bool = False,
    use_cache: bool = True,
) -> dict[str, Any]:
    """Replay the state machine across a date range, without lookahead.

    For each as-of date the bar frames are truncated to that date and the
    study is re-run, so every state row is built from exactly the
    information available then. The assertion below is the operational form
    of §8a I: no emitted event may have a trigger bar beyond the as-of bar.
    """
    cfg = load_config(config_path)
    root = Path(base_dir) if base_dir else Path.cwd()
    store = TaStore(cfg, root)
    report = data_mod.BarReport()

    client = (
        None
        if offline
        else BloombergClient(
            root / cfg.run.cache_dir,
            on_server=cfg.bloomberg_on_server,
            use_cache=use_cache,
        )
    )
    daily, intraday = load_bars(cfg, client, store, end, report)

    written = 0
    dates = 0
    as_of = start
    while as_of <= end:
        rows: list[StudyResult] = []
        secondary: dict[tuple[str, str], SecondaryResult] = {}
        cutoff = dt.datetime.combine(as_of, dt.time(23, 59, 59))

        for product, horizon in cfg.pairs():
            d = daily.get(product.name, data_mod.empty_bars())
            i = intraday.get(product.name, data_mod.empty_bars())
            d = d.filter(pl.col("ts") <= cutoff) if not d.is_empty() else d
            i = i.filter(pl.col("ts") <= cutoff) if not i.is_empty() else i
            bars = data_mod.build_horizon(d, i, product, horizon, cfg, report)
            if bars.is_empty() or bars.height < cfg.run.min_bars:
                continue

            result = run_study(bars, cfg, product.name, horizon.name)
            last_bar = result.n_bars - 1
            for event in result.events:
                assert event.triggered_at <= last_bar, (
                    f"lookahead: {product.name} {horizon.name} event t*="
                    f"{event.triggered_at} exceeds as-of bar {last_bar} on {as_of}"
                )
            rows.append(result)
            secondary[result.key] = compute_secondary(
                result.series,  # type: ignore[arg-type]
                cfg,
                product.name,
                horizon.name,
                daily_ranges=not horizon.is_intraday,
            )

        if rows:
            written += store.save_states(
                rows, secondary, dt.datetime.now(), as_of
            )
            dates += 1
        as_of += dt.timedelta(days=1)

    store.close()
    return {
        "start": start.isoformat(),
        "end": end.isoformat(),
        "dates": dates,
        "rows_written": written,
        "warnings": report.warnings,
    }


def fill_forward_returns(
    config_path: str | Path | None = None,
    as_of: dt.date | None = None,
    base_dir: str | Path | None = None,
    offline: bool = False,
    use_cache: bool = True,
) -> dict[str, Any]:
    """Re-score divergence events whose forward horizon has now elapsed.

    Runs the same study over the current bar windows and re-MERGEs every
    event whose returns are computable. Because the longest forward horizon
    (20 bars) is far shorter than the bar window (400), any event that fired
    inside the window gets filled within a few sessions of firing; events
    older than the window were filled on an earlier pass and are left alone.
    """
    cfg = load_config(config_path)
    root = Path(base_dir) if base_dir else Path.cwd()
    run_date = as_of or dt.date.today()
    store = TaStore(cfg, root)
    report = data_mod.BarReport()

    client = (
        None
        if offline
        else BloombergClient(
            root / cfg.run.cache_dir,
            on_server=cfg.bloomberg_on_server,
            use_cache=use_cache,
        )
    )
    daily, intraday = load_bars(cfg, client, store, run_date, report)

    rows: list[dict[str, Any]] = []
    scored = 0
    for product, horizon in cfg.pairs():
        bars = data_mod.build_horizon(
            daily.get(product.name, data_mod.empty_bars()),
            intraday.get(product.name, data_mod.empty_bars()),
            product,
            horizon,
            cfg,
            report,
        )
        if bars.is_empty() or bars.height < cfg.run.min_bars:
            continue
        result = run_study(bars, cfg, product.name, horizon.name)
        for record in event_records(result, cfg):
            if any(r.elapsed for r in record.returns.values()):
                rows.append(divergence_event_row(record))
                scored += 1

    written = store.persistence.write(cfg.persist.divergence_events_table, rows)
    rates = hit_rates(_history_records(store, []), cfg.stats)
    summary = hypothesis_check(rates, cfg.stats)
    store.close()

    return {
        "as_of": run_date.isoformat(),
        "events_scored": scored,
        "rows_written": written,
        "buckets": len(rates),
        "sufficient_buckets": sum(1 for r in rates if r.sufficient),
        "hypothesis": summary,
        "warnings": report.warnings,
    }
