"""Email assembly (§11): Jinja2 context, CID images, size enforcement.

Layout decisions that are not negotiable if the email is to survive Outlook:
inline CSS only, table layout, fixed pixel widths, and charts attached as
CID inline parts rather than base64 data URIs.

Size enforcement runs *before* the send. When the message would exceed
``run.max_email_mb`` the thumbnail strip goes first - it is explicitly
optional - and then full charts are dropped in **ascending strength order**,
so the weakest signal loses its picture while the strongest keeps it. Every
dropped chart is named in the appendix with a link to the Dash page, so the
reader knows something was withheld rather than silently missing.
"""

from __future__ import annotations

import datetime as dt
import logging
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape

from common.deliver import InlineImage, new_content_id, total_size
from ta_study import charts as charts_mod
from ta_study.charts import STATE_COLOURS
from ta_study.config import STATE_GLOSS, STATE_LABELS, StudyConfig, state_label
from ta_study.divergence import Divergence
from ta_study.secondary import SecondaryResult
from ta_study.stats import HitRateIndex
from ta_study.study import Alignment, StudyResult

log = logging.getLogger(__name__)

TEMPLATE_DIR = Path(__file__).parent / "templates"
COMMON_TEMPLATE_DIR = Path(__file__).parent.parent / "common"

#: Email body width in px. Wider than a typical report because the combined
#: charts are multi-column; the desk reads these on a trading monitor.
PAGE_WIDTH = 1180

#: Displayed width of a chart image, inside the body's padding.
CHART_WIDTH = 1120

#: Chart colours the legend needs, pulled from :mod:`ta_study.charts` so a
#: swatch can never drift from the line it is describing.
PALETTE: dict[str, str] = {
    "up": charts_mod.UP,
    "down": charts_mod.DOWN,
    "ema_fast": charts_mod.EMA_FAST,
    "ema_mid": charts_mod.EMA_MID,
    "ema_slow": charts_mod.EMA_SLOW,
    "bear_line": charts_mod.BEAR_LINE,
    "bull_line": charts_mod.BULL_LINE,
    "rsi": charts_mod.RSI_LINE,
    "stoch_k": charts_mod.STOCH_K,
    "stoch_d": charts_mod.STOCH_D,
    "gate": charts_mod.GATE_SHADE,
    "ink": charts_mod.INK,
    "swing": charts_mod.SWING_MARK,
}





# ---------------------------------------------------------------------------
# chart references
# ---------------------------------------------------------------------------
@dataclass
class CaptionBlock:
    """One horizon's worth of caption inside a combined product chart."""

    horizon: str
    state: str
    colour: str
    arrow: str
    direction_label: str
    strength: float
    lines: list[str] = field(default_factory=list)

    @property
    def live(self) -> bool:
        return self.state not in ("NONE", "DVG_EXPIRED")


@dataclass
class ChartRef:
    """One rendered chart, ready to be embedded or dropped.

    A combined per-product chart uses ``horizon = ""`` and carries one
    :class:`CaptionBlock` per column; the single-pair charts keep their
    horizon and a flat ``caption``.
    """

    product: str
    horizon: str
    kind: str
    image: InlineImage
    caption: list[str] = field(default_factory=list)
    strength: float = 0.0
    alignment: float = 0.0
    display: str = ""
    blocks: list[CaptionBlock] = field(default_factory=list)

    @property
    def key(self) -> tuple[str, str]:
        return (self.product, self.horizon)

    @property
    def size(self) -> int:
        return self.image.size

    @property
    def label(self) -> str:
        return f"{self.product} {self.horizon}".strip()

    @property
    def title(self) -> str:
        return self.display or self.label


def make_chart_ref(
    result: StudyResult,
    png: bytes,
    kind: str,
    caption: Sequence[str] = (),
    alignment_score: float = 0.0,
) -> ChartRef | None:
    """Wrap PNG bytes as a CID inline image; ``None`` for a failed render."""
    if not png:
        return None
    stem = f"{result.product}-{result.horizon}-{kind}"
    return ChartRef(
        product=result.product,
        horizon=result.horizon,
        kind=kind,
        image=InlineImage(
            content_id=new_content_id(stem),
            filename=f"{stem}.png",
            content=png,
        ),
        caption=list(caption),
        strength=result.strength,
        alignment=alignment_score,
    )


def make_product_chart_ref(
    product: str,
    png: bytes,
    blocks: Sequence[CaptionBlock],
    display: str = "",
    strength: float = 0.0,
    alignment_score: float = 0.0,
) -> ChartRef | None:
    """Wrap a combined per-product chart; ``None`` for a failed render."""
    if not png:
        return None
    stem = f"{product}-all-horizons"
    return ChartRef(
        product=product,
        horizon="",
        kind="product",
        image=InlineImage(
            content_id=new_content_id(stem),
            filename=f"{stem}.png",
            content=png,
        ),
        strength=strength,
        alignment=alignment_score,
        display=display or product,
        blocks=list(blocks),
    )


# ---------------------------------------------------------------------------
# size enforcement
# ---------------------------------------------------------------------------
@dataclass
class SizePlan:
    kept_full: list[ChartRef]
    kept_thumbs: list[ChartRef]
    dropped_full: list[ChartRef]
    dropped_thumbs: list[ChartRef]
    est_bytes: int
    limit_bytes: int

    @property
    def dropped(self) -> list[ChartRef]:
        return self.dropped_thumbs + self.dropped_full

    @property
    def over_limit(self) -> bool:
        return self.est_bytes > self.limit_bytes

    @property
    def kept(self) -> list[ChartRef]:
        return self.kept_full + self.kept_thumbs


def enforce_email_size(
    html_bytes: int,
    full_charts: Sequence[ChartRef],
    thumbnails: Sequence[ChartRef],
    limit_bytes: int,
) -> SizePlan:
    """Decide which charts fit inside ``limit_bytes``.

    Drop order, as specified: the whole thumbnail strip first, then full
    charts by ascending strength (ties broken by descending size, so the
    cheapest saving per lost signal is taken first, then by name for
    determinism).
    """
    full = list(full_charts)
    thumbs = list(thumbnails)

    def estimate(f: Sequence[ChartRef], t: Sequence[ChartRef]) -> int:
        return total_size("x" * html_bytes, [c.image for c in list(f) + list(t)], [])

    if estimate(full, thumbs) <= limit_bytes:
        return SizePlan(full, thumbs, [], [], estimate(full, thumbs), limit_bytes)

    dropped_thumbs = thumbs
    thumbs = []
    if estimate(full, thumbs) <= limit_bytes:
        return SizePlan(
            full, thumbs, [], dropped_thumbs, estimate(full, thumbs), limit_bytes
        )

    order = sorted(full, key=lambda c: (c.strength, -c.size, c.label))
    dropped_full: list[ChartRef] = []
    kept = list(order)
    while kept and estimate(kept, thumbs) > limit_bytes:
        dropped_full.append(kept.pop(0))

    # Restore the caller's display order for whatever survived.
    kept_in_order = [c for c in full if c in kept]
    return SizePlan(
        kept_in_order,
        thumbs,
        dropped_full,
        dropped_thumbs,
        estimate(kept_in_order, thumbs),
        limit_bytes,
    )


# ---------------------------------------------------------------------------
# captions (§11)
# ---------------------------------------------------------------------------
def _fmt(value: float, digits: int = 2) -> str:
    return "n/a" if value is None or not np.isfinite(value) else f"{value:,.{digits}f}"


def _stamp(value: Any, fmt: str = "%d %b") -> str:
    return value.strftime(fmt) if hasattr(value, "strftime") else str(value)


def trigger_line(result: StudyResult, event: Divergence) -> str:
    """What happened, in words a reader does not have to decode.

    The old version opened with "Bearish RSI divergence: price 1,280.88 →
    1,353.83 (+5.7%) while RSI 72 → 69; swings 31 Jul → 21 Aug. σ 0.26,
    suggested size ×0.26." - every fact present, and almost none of it
    legible at a glance.
    """
    pct = ""
    if event.s1.price:
        pct = f", {event.d_price / abs(event.s1.price):+.1%}"

    if event.kind == "BEAR":
        move, momentum, meaning = (
            "a higher high",
            "a lower high",
            "the rally is gaining less ground with each push, which often "
            "comes before a turn down",
        )
    else:
        move, momentum, meaning = (
            "a lower low",
            "a higher low",
            "the selling is losing force, which often comes before a turn up",
        )

    if event.hidden:
        meaning = "a continuation signal: the pause has not broken the trend"

    return (
        f"Price made {move} ({_fmt(event.s1.price)} → {_fmt(event.s2.price)}{pct}) "
        f"between {_stamp(event.ts1)} and {_stamp(event.ts2)}, but momentum made "
        f"{momentum} (RSI {event.s1.rsi:.0f} → {event.s2.rsi:.0f}) — {meaning}."
    )


def sizing_line(result: StudyResult) -> str:
    """Confidence and size, spelled out rather than as symbols."""
    strength = result.strength
    if strength >= 0.66:
        word = "strong"
    elif strength >= 0.33:
        word = "moderate"
    else:
        word = "weak"

    size = result.size_multiplier
    if size <= 0:
        tail = "Not tradable as it stands — see above."
    else:
        tail = f"Suggested size: {size:.0%} of a normal position."
    return f"Signal quality: {word} ({strength:.2f} out of 1). {tail}"


def gate_phrase(result: StudyResult) -> str:
    """Why the gate is open, stated correctly.

    The gate is ``ADX >= theta AND ADX rising``, so it can be open with ADX
    *above* the threshold whenever the trend has stopped strengthening.
    Asserting "ADX 31.5 < 30, so the gate is open" - as this used to - is a
    falsehood the reader can check in the chart directly above it.
    """
    adx, threshold = result.adx, result.adx_threshold
    if not np.isfinite(adx):
        return "ADX unavailable"
    if adx < threshold:
        return f"ADX {adx:.1f} is below the {threshold:.0f} threshold"
    return (
        f"ADX {adx:.1f} is above the {threshold:.0f} threshold but not rising"
    )


def next_step_line(result: StudyResult, cfg: StudyConfig, event: Divergence) -> str:
    """Where it stands now and what has to happen next, in plain words."""
    dcfg = cfg.divergence
    gate = cfg.adx_gate
    turn = "turn up" if event.direction > 0 else "turn down"

    if result.gated:
        return (
            f"On hold: the trend is strong and still building (ADX "
            f"{_fmt(result.adx, 1)}, above {_fmt(result.adx_threshold, 0)}). "
            f"Fading a trend this strong is expensive, so the study stands "
            f"aside until it eases — either ADX falls "
            f"{gate.rising_slope_bars} bars running, or it drops back below "
            f"{_fmt(result.adx_threshold, 0)}."
        )

    if result.state == "DVG_GATE_RELEASING":
        return (
            f"Just cleared: the trend has stopped building (ADX "
            f"{_fmt(result.adx, 1)}), so the setup is tradable again at full size."
        )

    if result.confirmed:
        lag = (
            f", {result.confirmed_at_bar - event.triggered_at} bars ago"
            if result.confirmed_at_bar is not None
            else ""
        )
        return (
            f"The {turn} has started{lag} — the stochastic crossed while still "
            f"stretched. Nothing is blocking it: {gate_phrase(result)}."
        )

    if result.state == "PROVISIONAL":
        return (
            f"Not a signal yet: the second swing is still forming and only counts "
            f"once it survives {dcfg.swing_k} more bars. Watch it, do not trade it."
        )

    bars_left = dcfg.confirmation_window - (result.bars_since_dvg or 0)
    expiry = max(dcfg.active_window - (result.bars_since_dvg or 0), 0)

    if bars_left > 0:
        return (
            f"Waiting for the {turn} to show: the stochastic needs to cross while "
            f"still stretched, within {bars_left} more bar(s). The setup itself "
            f"expires in {expiry}. For now, {gate_phrase(result)}."
        )
    # Past W_c: the divergence is still live but can no longer be confirmed,
    # so promising that it "will confirm" would be wrong.
    # gate_phrase already starts with "ADX"; str.capitalize() would lowercase
    # the rest of the acronym and render it "Adx".
    return (
        f"The {turn} never showed — the stochastic did not cross within "
        f"{dcfg.confirmation_window} bars, so this stays unconfirmed and drops "
        f"off in {expiry} bar(s). {gate_phrase(result)}."
    )


def caption_block(
    result: StudyResult,
    secondary: SecondaryResult | None,
    cfg: StudyConfig,
    hit_index: HitRateIndex | None,
) -> CaptionBlock:
    """One column's caption for a combined product chart.

    Quiet horizons collapse to a single line - a four-column chart with four
    paragraphs under it is not readable, and the whole point of the combined
    layout is that the eye goes to the column that is doing something.
    """
    horizon = cfg.horizon(result.horizon)
    block = CaptionBlock(
        horizon=horizon.display if horizon else result.horizon,
        state=result.state,
        colour=STATE_COLOURS.get(result.state, "#9e9e9e"),
        arrow=result.arrow,
        direction_label=result.direction_label,
        strength=result.strength,
    )
    if result.state == "NONE":
        block.lines = []
        return block
    block.lines = [line for line in caption_for(result, secondary, cfg, hit_index) if line]
    return block


def caption_for(
    result: StudyResult,
    secondary: SecondaryResult | None,
    cfg: StudyConfig,
    hit_index: HitRateIndex | None,
) -> list[str]:
    """Two lines plus the historical hit rate, per §11."""
    event = result.event or result.provisional_event
    if event is None:
        if secondary is not None and secondary.ma_cross_new:
            crosses = ", ".join(c.label for c in secondary.recent_crosses)
            return [
                f"{crosses}; EMA stack {secondary.regime_label}.",
                "No divergence in the active window — shown for the cross only.",
            ]
        return [f"State {result.state}; no divergence in the active window.", ""]

    lines = [
        trigger_line(result, event),
        next_step_line(result, cfg, event),
        sizing_line(result),
    ]
    if hit_index is not None and result.direction != 0:
        lines.append(
            hit_index.caption(
                result.product,
                result.horizon,
                result.direction,
                result.confirmed,
                result.gated,
            )
        )
    return lines


# ---------------------------------------------------------------------------
# grid / table rows
# ---------------------------------------------------------------------------
@dataclass
class GridCell:
    product: str
    horizon: str
    state: str
    arrow: str
    direction_label: str
    colour: str
    outline: bool
    detail: str
    strength: float
    blank: bool

    @property
    def badge(self) -> str:
        """The plain label, not the internal identifier."""
        if self.blank:
            return ""
        label = state_label(self.state)
        return f"{label} 🔒" if self.state == "DVG_GATED" else label


def grid_cell(result: StudyResult) -> GridCell:
    """One cell: state badge, direction arrow, and the raw ingredients."""
    blank = result.state == "NONE"
    detail = (
        f"RSI {_fmt(result.rsi, 0)} · K/D {_fmt(result.k, 0)}/{_fmt(result.d, 0)} "
        f"· ADX {_fmt(result.adx, 0)}"
    )
    return GridCell(
        product=result.product,
        horizon=result.horizon,
        state=result.state,
        arrow=result.arrow if not blank else "",
        direction_label=result.direction_label,
        colour=STATE_COLOURS.get(result.state, "#9e9e9e"),
        outline=result.state in ("PROVISIONAL", "DVG_EXPIRED"),
        detail=detail,
        strength=result.strength,
        blank=blank,
    )


def change_lines(results: Sequence[StudyResult]) -> list[str]:
    """One line per state change since the previous run."""
    out: list[str] = []
    for res in results:
        if not res.changed:
            continue
        bits = f"{res.product} {res.horizon}: {res.prev_state} → {res.state}"
        if res.direction_label:
            bits += f" ({res.direction_label.lower()}, σ {res.strength:.2f})"
        out.append(bits)
    return out


# ---------------------------------------------------------------------------
# the email
# ---------------------------------------------------------------------------
@dataclass
class RenderedEmail:
    subject: str
    html: str
    inline: list[InlineImage]
    plan: SizePlan
    counts: dict[str, int]

    @property
    def size_bytes(self) -> int:
        return total_size(self.html, self.inline, [])


def _environment() -> Environment:
    return Environment(
        loader=FileSystemLoader([str(TEMPLATE_DIR), str(COMMON_TEMPLATE_DIR)]),
        # "j2" is in the list because select_autoescape keys off the *last*
        # extension: the templates are named ta_email.html.j2, so a plain
        # ["html", "xml"] silently leaves autoescape OFF. Everything the
        # templates interpolate is internal (config labels, computed
        # numbers), so nothing was exploitable - but a product label
        # containing & or < would have produced broken HTML.
        autoescape=select_autoescape(["html", "htm", "xml", "j2"]),
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
    )


def subject_line(
    counts: dict[str, int], alignments: Sequence[Alignment], run_date: dt.date
) -> str:
    """``TA Study {date} — {n} confirmed / {m} active[ — ALIGNMENT: names]``."""
    base = (
        f"TA Study {run_date:%Y-%m-%d} — "
        f"{counts.get('confirmed', 0)} confirmed / {counts.get('active', 0)} active"
    )
    if alignments:
        names = ", ".join(dict.fromkeys(a.product for a in alignments))
        base += f" — ALIGNMENT: {names}"
    return base


def summarise(results: Sequence[StudyResult]) -> dict[str, int]:
    return {
        "active": sum(1 for r in results if r.state == "DVG_ACTIVE"),
        "confirmed": sum(1 for r in results if r.state == "DVG_CONFIRMED"),
        "gated": sum(1 for r in results if r.state == "DVG_GATED"),
        "releasing": sum(1 for r in results if r.state == "DVG_GATE_RELEASING"),
        "provisional": sum(1 for r in results if r.state == "PROVISIONAL"),
        "expired": sum(1 for r in results if r.state == "DVG_EXPIRED"),
    }


def build_email(
    results: Sequence[StudyResult],
    secondary: dict[tuple[str, str], SecondaryResult],
    alignments: Sequence[Alignment],
    full_charts: Sequence[ChartRef],
    thumbnails: Sequence[ChartRef],
    cfg: StudyConfig,
    run_date: dt.date,
    hypothesis: dict[str, Any] | None = None,
    warnings: Sequence[str] = (),
    diagnostics: dict[str, Any] | None = None,
) -> RenderedEmail:
    """Render the email and return it with the inline parts it references.

    The HTML is rendered twice: once to measure the body so size
    enforcement has a real number to work with, then once more with only the
    charts that fit. Rendering is cheap relative to charting, and guessing
    the body size would risk a gateway rejection.
    """
    env = _environment()
    template = env.get_template("ta_email.html.j2")

    counts = summarise(results)
    n_crosses = sum(
        1 for sec in secondary.values() if sec.ma_cross_new and sec.horizon == "D"
    )
    horizons = [h.name for h in cfg.active_horizons]
    products = [p.name for p in cfg.products]

    by_key = {r.key: r for r in results}
    grid: list[dict[str, Any]] = []
    for product in products:
        cells = []
        for horizon in horizons:
            res = by_key.get((product, horizon))
            cells.append(grid_cell(res) if res is not None else None)
        prod_cfg = cfg.product(product)
        grid.append(
            {
                "product": product,
                "display": prod_cfg.display if prod_cfg else product,
                "group": prod_cfg.group if prod_cfg else "",
                "cells": cells,
            }
        )

    secondary_rows = [
        {
            "product": cfg.product(p).display if cfg.product(p) else p,
            "sec": secondary[(p, "D")],
            "result": by_key.get((p, "D")),
        }
        for p in products
        if (p, "D") in secondary
    ]

    base_context: dict[str, Any] = {
        "subject": "",
        "title": "Daily Technical Analysis — Shternberg Study",
        "subtitle": None,
        # Wider than the usual report body: the combined charts put one
        # column per frequency side by side, and at 1000px a four-column
        # chart scales each frequency down to an illegible ~235px.
        "page_width": PAGE_WIDTH,
        "chart_width": CHART_WIDTH,
        "as_of": f"{run_date:%A %d %B %Y}",
        "footer": "",
        "cfg": cfg,
        "run_date": run_date,
        "counts": counts,
        "n_crosses": n_crosses,
        "changes": change_lines(results),
        "alignments": list(alignments),
        "horizons": horizons,
        "grid": grid,
        "secondary_rows": secondary_rows,
        "hypothesis": hypothesis,
        "warnings": list(warnings),
        "diagnostics": diagnostics or {},
        "state_gloss": STATE_GLOSS,
        "state_labels": STATE_LABELS,
        "state_colours": STATE_COLOURS,
        "palette": PALETTE,
        "full_charts": list(full_charts),
        "thumbnails": list(thumbnails),
        "dropped": [],
        "dash_url": cfg.delivery.dash_url,
    }

    # Pass 1: measure the body with every chart referenced.
    probe = template.render(**base_context)
    plan = enforce_email_size(
        len(probe.encode("utf-8")),
        full_charts,
        thumbnails,
        cfg.run.max_email_bytes,
    )
    if plan.dropped:
        log.warning(
            "email over %.1f MB; dropped %d chart(s): %s",
            cfg.run.max_email_mb,
            len(plan.dropped),
            ", ".join(c.label for c in plan.dropped),
        )

    counts_footer = (
        f"{len(plan.kept_full)} full chart(s), {len(plan.kept_thumbs)} thumbnail(s), "
        f"~{plan.est_bytes / 1024 / 1024:.1f} MB"
    )
    subject = subject_line(counts, alignments, run_date)

    final_context = {
        **base_context,
        "subject": subject,
        "full_charts": plan.kept_full,
        "thumbnails": plan.kept_thumbs,
        "dropped": plan.dropped,
        "footer": counts_footer,
    }
    html = template.render(**final_context)

    return RenderedEmail(
        subject=subject,
        html=html,
        inline=[c.image for c in plan.kept],
        plan=plan,
        counts=counts,
    )
