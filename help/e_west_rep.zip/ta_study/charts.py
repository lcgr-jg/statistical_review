"""Multi-panel chart rendering with mplfinance (§10).

Five panels, top to bottom, with ratios ``(5, 1.5, 1.5, 1.5, 1)``:

0. **Price** - candles, EMA 20/50/200, Bollinger band fill, swing markers,
   the divergence line between S1 and S2, roll markers, last close annotated.
1. **RSI** - 30/70 dashed with shaded zones, 40/60 dotted soft zones, and the
   *same* divergence line drawn between the same two timestamps. Seeing one
   line rise while the other falls is the whole study in one glance.
2. **Stochastic** - %K solid, %D dashed, 20/80 shaded, in-zone crosses
   marked, and the cross that produced ``DVG_CONFIRMED`` circled.
3. **DMI/ADX** - ADX bold with +DI/-DI thin, the product's threshold line,
   and an amber background over every interval where the gate is closed.
   This is what makes "momentum dominant" visible rather than a footnote.
4. **Volume** - coloured by candle direction.

Accessibility: the palette is colourblind-distinguishable and direction is
never carried by colour alone - bearish also gets ▼ markers and the word
BEAR in the title.

Rendering runs on the Agg backend with every figure explicitly closed, and
optionally across a ``ProcessPoolExecutor``; ~60 charts finish well inside
the 60 s budget.
"""

from __future__ import annotations

import io
import logging
from collections.abc import Sequence
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from typing import Any

import matplotlib

matplotlib.use("Agg")  # must precede pyplot; charts render headless

import matplotlib.pyplot as plt
import mplfinance as mpf
import numpy as np

from ta_study import indicators as ind
from ta_study.config import StudyConfig, state_label
from ta_study.data import to_pandas
from ta_study.divergence import Divergence
from ta_study.study import StudyResult, StudySeries

log = logging.getLogger(__name__)

# -- palette ---------------------------------------------------------------
UP = "#26a69a"
DOWN = "#ef5350"
EMA_FAST = "#1f77b4"
EMA_MID = "#ff7f0e"
EMA_SLOW = "#7f7f7f"
BEAR_LINE = "#d62728"
BULL_LINE = "#2ca02c"
RSI_LINE = "#5c6bc0"
STOCH_K = "#0288d1"
STOCH_D = "#f57c00"
GATE_SHADE = "#ffb300"
SWING_MARK = "#78909c"
ROLL_MARK = "#b0bec5"
INK = "#1a1d21"

FULL_SIZE_PX = (1600, 1100)
FULL_DPI = 150
THUMB_SIZE_PX = (600, 360)
THUMB_DPI = 100

#: Combined per-product chart: one column per horizon, four rows.
PRODUCT_ROW_RATIOS = (3.4, 1.0, 1.0, 1.0)
PRODUCT_COL_WIDTH_PX = 620
PRODUCT_HEIGHT_PX = 1000
PRODUCT_DPI = 120

#: Skip roll markers once they exceed this fraction of the visible bars.
ROLL_MARK_MAX_DENSITY = 0.10

#: Bars drawn per column. The study still runs on the full window - this
#: only limits what is *shown*, because 400 candles in a 620 px column is an
#: unreadable smear. 140 bars comfortably contains any live divergence:
#: the two swings sit within ``max_lookback_bars`` (60) of each other and
#: the trigger is recent by construction.
PRODUCT_CHART_BARS = 140

PANEL_RATIOS = (5, 1.5, 1.5, 1.5, 1)
PANEL_PRICE, PANEL_RSI, PANEL_STOCH, PANEL_ADX, PANEL_VOLUME = 0, 1, 2, 3, 4

#: Badge colour per state, shared with the email so the two agree.
STATE_COLOURS: dict[str, str] = {
    "DVG_CONFIRMED": "#1b5e20",
    "DVG_ACTIVE": "#2e7d32",
    "DVG_GATED": "#e65100",
    "DVG_GATE_RELEASING": "#0277bd",
    "DVG_EXPIRED": "#757575",
    "PROVISIONAL": "#9e9e9e",
    "NONE": "#9e9e9e",
    "MA_CROSS_NEW": "#4527a0",
}


def _figsize(px: tuple[int, int], dpi: int) -> tuple[float, float]:
    return (px[0] / dpi, px[1] / dpi)


def build_style() -> dict[str, Any]:
    """mplfinance style: white ground, light grid, sans-serif with fallback."""
    market_colors = mpf.make_marketcolors(
        up=UP,
        down=DOWN,
        edge={"up": UP, "down": DOWN},
        wick={"up": UP, "down": DOWN},
        volume={"up": UP, "down": DOWN},
        ohlc={"up": UP, "down": DOWN},
    )
    return mpf.make_mpf_style(
        base_mpf_style="classic",
        marketcolors=market_colors,
        facecolor="white",
        figcolor="white",
        edgecolor="#cfd8dc",
        gridcolor="#e0e0e0",
        gridstyle="-",
        gridaxis="both",
        # Left-hand y axis deliberately: mplfinance draws the data on the
        # primary axis, which is axlist[panel * 2]. With y_on_right the data
        # lands on the secondary axis instead and every axhline / axhspan /
        # set_ylim below would decorate an empty twin, producing two sets of
        # tick labels at two different scales.
        y_on_right=False,
        rc={
            "font.family": "sans-serif",
            "font.sans-serif": ["Inter", "Segoe UI", "DejaVu Sans"],
            # mplfinance's "classic" base asks for font.weight "medium" and
            # axes.labelweight "semibold". DejaVu Sans - the fallback on any
            # machine without Inter - ships only normal and bold, so
            # matplotlib logs a findfont fallback for every text object:
            # 20+ lines of noise per run. Ask only for weights that exist.
            "font.weight": "normal",
            "axes.labelweight": "normal",
            "figure.titleweight": "bold",
            "font.size": 9,
            "axes.labelsize": 9,
            "axes.titlesize": 11,
            "axes.edgecolor": "#cfd8dc",
            "grid.alpha": 0.3,
            "legend.fontsize": 8,
            "figure.autolayout": False,
        },
    )


# ---------------------------------------------------------------------------
# geometry: the divergence line
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class DivergenceLine:
    """Endpoints of the divergence line, in bar-index coordinates.

    Kept as a pure value so the "line endpoints land on S1/S2" test can
    assert against it without rendering anything.
    """

    x: tuple[int, int]
    price: tuple[float, float]
    rsi: tuple[float, float]
    ts: tuple[Any, Any]
    kind: str
    dashed: bool

    @property
    def colour(self) -> str:
        return BEAR_LINE if self.kind == "BEAR" else BULL_LINE

    @property
    def alpha(self) -> float:
        return 0.5 if self.dashed else 1.0

    @property
    def linestyle(self) -> str:
        return "--" if self.dashed else "-"


def _display_price(series: StudySeries, bar: int, kind: str, swing_price: str) -> float:
    """Price to anchor the line to, taken from the *unadjusted* bars.

    The study runs on the back-adjusted series but the chart shows traded
    prices, so the line has to be re-anchored or it floats off the candles.
    """
    if swing_price == "highlow":
        source = series.high if kind == "H" else series.low
    else:
        source = series.close
    return series.at(source, bar)


def divergence_line(
    event: Divergence, series: StudySeries, swing_price: str = "close"
) -> DivergenceLine | None:
    """Line endpoints for one divergence, or ``None`` if off the window."""
    i1, i2 = event.s1.bar_idx, event.s2.bar_idx
    if not (0 <= i1 < series.n and 0 <= i2 < series.n):
        return None
    return DivergenceLine(
        x=(i1, i2),
        price=(
            _display_price(series, i1, event.s1.kind, swing_price),
            _display_price(series, i2, event.s2.kind, swing_price),
        ),
        rsi=(series.at(series.rsi, i1), series.at(series.rsi, i2)),
        ts=(series.ts[i1], series.ts[i2]),
        kind=event.kind,
        dashed=event.provisional,
    )


def _contiguous_spans(flags: np.ndarray) -> list[tuple[int, int]]:
    """``[(start, end)]`` inclusive index spans where ``flags`` is True."""
    spans: list[tuple[int, int]] = []
    start: int | None = None
    for i, flag in enumerate(flags):
        if flag and start is None:
            start = i
        elif not flag and start is not None:
            spans.append((start, i - 1))
            start = None
    if start is not None:
        spans.append((start, len(flags) - 1))
    return spans


# ---------------------------------------------------------------------------
# panel helpers
# ---------------------------------------------------------------------------
def _addplot(values: np.ndarray, **kwargs: Any) -> Any | None:
    """``mpf.make_addplot`` that returns ``None`` for an all-NaN series.

    mplfinance raises on a fully-empty overlay, which is the normal state of
    an EMA200 on a 60-bar window.

    ``secondary_y`` is pinned to False: mplfinance's default of ``'auto'``
    decides per overlay by comparing value ranges, which can scatter ADX and
    +DI/-DI across two axes of one panel - two sets of ticks, two legends,
    and decorations applied to whichever axis happened to win.
    """
    if values.size == 0 or not np.any(np.isfinite(values)):
        return None
    kwargs.setdefault("secondary_y", False)
    return mpf.make_addplot(values, **kwargs)


def _title(result: StudyResult) -> str:
    """``{product} · {horizon} · {state} · strength 0.xx · as of {ts}``."""
    parts = [result.product, result.horizon, result.state]
    if result.direction_label:
        parts.append(result.direction_label)
    if result.strength > 0:
        parts.append(f"strength {result.strength:.2f}")
    as_of = result.as_of
    stamp = as_of.strftime("%Y-%m-%d %H:%M") if hasattr(as_of, "strftime") else str(as_of)
    parts.append(f"as of {stamp}")
    return "  ·  ".join(parts)


def _to_png(fig: Any, dpi: int) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# the full chart
# ---------------------------------------------------------------------------
def full_chart(result: StudyResult, cfg: StudyConfig) -> bytes:
    """Five-panel PNG for one (product, horizon), 1600x1100 at 150 dpi."""
    series = result.series
    if series is None or series.n == 0:
        return placeholder_chart(result, FULL_SIZE_PX, FULL_DPI)

    icfg = cfg.indicators
    pdf = to_pandas(_bars_frame(result), use_adjusted=False)
    n = series.n

    overlays: list[Any] = []

    # -- price panel overlays -------------------------------------------
    for period, colour, style in (
        (icfg.ema_fast, EMA_FAST, "-"),
        (icfg.ema_mid, EMA_MID, "-"),
        (icfg.ema_slow, EMA_SLOW, "--"),
    ):
        plot = _addplot(
            ind.ema(series.close, period),
            panel=PANEL_PRICE,
            color=colour,
            width=0.9,
            linestyle=style,
            label=f"EMA{period}",
        )
        if plot is not None:
            overlays.append(plot)

    bands = ind.bbands(series.close, icfg.bbands.period, icfg.bbands.std)
    for edge in (bands.upper, bands.lower):
        plot = _addplot(edge, panel=PANEL_PRICE, color="#90a4ae", width=0.6, alpha=0.5)
        if plot is not None:
            overlays.append(plot)

    # -- RSI ------------------------------------------------------------
    rsi_plot = _addplot(
        series.rsi, panel=PANEL_RSI, color=RSI_LINE, width=1.1, ylabel="RSI"
    )
    if rsi_plot is not None:
        overlays.append(rsi_plot)

    # -- stochastic -----------------------------------------------------
    for values, colour, style, label in (
        (series.k, STOCH_K, "-", "%K"),
        (series.d, STOCH_D, "--", "%D"),
    ):
        plot = _addplot(
            values,
            panel=PANEL_STOCH,
            color=colour,
            width=1.0,
            linestyle=style,
            ylabel="Stoch",
            label=label,
        )
        if plot is not None:
            overlays.append(plot)

    # -- DMI / ADX ------------------------------------------------------
    for values, colour, width, label in (
        (series.adx, INK, 1.4, "ADX"),
        (series.plus_di, UP, 0.8, "+DI"),
        (series.minus_di, DOWN, 0.8, "-DI"),
    ):
        plot = _addplot(
            values, panel=PANEL_ADX, color=colour, width=width, ylabel="ADX", label=label
        )
        if plot is not None:
            overlays.append(plot)

    # See _draw_product_column: mplfinance rejects addplot=None, so the
    # kwarg must be omitted when there is nothing to overlay.
    plot_kwargs: dict[str, Any] = {
        "type": "candle",
        "style": build_style(),
        "panel_ratios": PANEL_RATIOS,
        "num_panels": 5,
        "volume": True,
        "volume_panel": PANEL_VOLUME,
        "figsize": _figsize(FULL_SIZE_PX, FULL_DPI),
        "returnfig": True,
        "tight_layout": True,
        "xrotation": 0,
        "update_width_config": {"candle_linewidth": 0.6, "candle_width": 0.6},
        "warn_too_much_data": n + 1,
    }
    if overlays:
        plot_kwargs["addplot"] = overlays
    fig, axes = mpf.plot(pdf, **plot_kwargs)

    # mplfinance hands back two axes per panel (left, right).
    def ax_for(panel: int) -> Any:
        idx = panel * 2
        return axes[idx] if idx < len(axes) else axes[0]

    ax_price = ax_for(PANEL_PRICE)
    ax_rsi = ax_for(PANEL_RSI)
    ax_stoch = ax_for(PANEL_STOCH)
    ax_adx = ax_for(PANEL_ADX)

    _decorate_price(ax_price, result, series, cfg, bands)
    _decorate_rsi(ax_rsi, result, series, cfg)
    _decorate_stoch(ax_stoch, result, series, cfg)
    _decorate_adx(ax_adx, series)

    fig.suptitle(
        _title(result),
        fontsize=11,
        fontweight="bold",
        color=STATE_COLOURS.get(result.state, INK),
        x=0.01,
        ha="left",
        y=0.995,
    )
    return _to_png(fig, FULL_DPI)


def _bars_frame(result: StudyResult):  # type: ignore[no-untyped-def]
    """Rebuild a polars bar frame from the series for the pandas conversion.

    ``repair_ohlc`` is applied again here rather than trusted from the data
    layer: mplfinance rejects a frame whose O/H/L/C have differing NaN
    counts, and a caller that builds a StudySeries by hand (the tests, a
    notebook) should not be able to make a chart fail.
    """
    import polars as pl

    from ta_study.data import repair_ohlc

    series = result.series
    assert series is not None
    frame = pl.DataFrame(
        {
            "ts": series.ts,
            "open": series.open,
            "high": series.high,
            "low": series.low,
            "close": series.close,
            "volume": np.nan_to_num(series.volume, nan=0.0),
        }
    )
    # NaN and null are distinct in polars; fill_null alone would miss these.
    frame = frame.with_columns(
        [
            pl.when(pl.col(c).is_nan()).then(None).otherwise(pl.col(c)).alias(c)
            for c in ("open", "high", "low", "close")
        ]
    )
    return repair_ohlc(frame.filter(pl.col("close").is_not_null()))


def _decorate_price(
    ax: Any, result: StudyResult, series: StudySeries, cfg: StudyConfig, bands: Any
) -> None:
    x = np.arange(series.n)

    # Bollinger fill between the plotted edges.
    valid = np.isfinite(bands.upper) & np.isfinite(bands.lower)
    if np.any(valid):
        ax.fill_between(
            x,
            np.where(valid, bands.lower, np.nan),
            np.where(valid, bands.upper, np.nan),
            color="#90a4ae",
            alpha=0.12,
            linewidth=0,
            zorder=0,
        )

    # Roll bars as faint verticals.
    for i in np.flatnonzero(series.is_roll):
        ax.axvline(i, color=ROLL_MARK, linewidth=0.8, alpha=0.7, zorder=0)

    # Swing markers: ▼ above highs, ▲ below lows.
    swing_price = cfg.divergence.swing_price
    for swing in result.swings:
        if not (0 <= swing.bar_idx < series.n):
            continue
        y = _display_price(series, swing.bar_idx, swing.kind, swing_price)
        if not np.isfinite(y):
            continue
        offset = 1.004 if swing.is_high else 0.996
        ax.plot(
            swing.bar_idx,
            y * offset,
            marker="v" if swing.is_high else "^",
            markersize=4,
            color=SWING_MARK,
            alpha=0.5 if swing.provisional else 0.9,
            markeredgewidth=0,
            zorder=3,
        )

    # The divergence line, plus the provisional one when that is the state.
    for event, dashed in _lines_to_draw(result):
        line = divergence_line(event, series, swing_price)
        if line is None or not all(np.isfinite(line.price)):
            continue
        ax.plot(
            line.x,
            line.price,
            color=line.colour,
            linewidth=2.0,
            linestyle="--" if dashed else "-",
            alpha=0.5 if dashed else 0.95,
            solid_capstyle="round",
            zorder=4,
        )
        ax.plot(
            line.x,
            line.price,
            linestyle="none",
            marker="o",
            markersize=3.5,
            color=line.colour,
            alpha=0.5 if dashed else 0.95,
            zorder=5,
        )

    last_close = series.at(series.close)
    if np.isfinite(last_close):
        ax.annotate(
            f"{last_close:,.2f}",
            xy=(series.n - 1, last_close),
            xytext=(6, 0),
            textcoords="offset points",
            va="center",
            ha="left",
            fontsize=9,
            fontweight="bold",
            color=INK,
            bbox={"boxstyle": "round,pad=0.25", "fc": "#eceff1", "ec": "none"},
            annotation_clip=False,
        )
    ax.set_ylabel("Price")


def _lines_to_draw(result: StudyResult) -> list[tuple[Divergence, bool]]:
    """The divergence(s) worth drawing: the live one, else the provisional."""
    out: list[tuple[Divergence, bool]] = []
    if result.event is not None:
        out.append((result.event, False))
    if result.provisional_event is not None:
        out.append((result.provisional_event, True))
    return out


def _decorate_rsi(
    ax: Any, result: StudyResult, series: StudySeries, cfg: StudyConfig
) -> None:
    rcfg = cfg.indicators.rsi
    ax.set_ylim(0, 100)
    # Only the levels that mean something. Ticks at 0 and 100 sit on the
    # panel boundary and collide with the neighbouring panel's labels.
    ax.set_yticks([rcfg.os, 50, rcfg.ob])
    ax.axhspan(rcfg.ob, 100, color=DOWN, alpha=0.08, linewidth=0, zorder=0)
    ax.axhspan(0, rcfg.os, color=UP, alpha=0.08, linewidth=0, zorder=0)
    for level in (rcfg.os, rcfg.ob):
        ax.axhline(level, color="#607d8b", linewidth=0.7, linestyle="--", alpha=0.8)
    for level in (rcfg.os_soft, rcfg.ob_soft):
        ax.axhline(level, color="#90a4ae", linewidth=0.6, linestyle=":", alpha=0.8)

    # Same S1/S2 timestamps as the price panel - that pairing is the signal.
    for event, dashed in _lines_to_draw(result):
        line = divergence_line(event, series, cfg.divergence.swing_price)
        if line is None or not all(np.isfinite(line.rsi)):
            continue
        ax.plot(
            line.x,
            line.rsi,
            color=line.colour,
            linewidth=2.0,
            linestyle="--" if dashed else "-",
            alpha=0.5 if dashed else 0.95,
            zorder=4,
        )
        ax.plot(
            line.x,
            line.rsi,
            linestyle="none",
            marker="o",
            markersize=3.5,
            color=line.colour,
            alpha=0.5 if dashed else 0.95,
            zorder=5,
        )

    if np.isfinite(result.rsi):
        ax.annotate(
            f"{result.rsi:.0f}",
            xy=(series.n - 1, result.rsi),
            xytext=(6, 0),
            textcoords="offset points",
            va="center",
            ha="left",
            fontsize=8,
            color=RSI_LINE,
            fontweight="bold",
            annotation_clip=False,
        )
    ax.set_ylabel("RSI")


def _decorate_stoch(
    ax: Any, result: StudyResult, series: StudySeries, cfg: StudyConfig
) -> None:
    scfg = cfg.indicators.stoch
    ax.set_ylim(0, 100)
    ax.set_yticks([scfg.os, 50, scfg.ob])
    ax.axhspan(scfg.ob, 100, color=DOWN, alpha=0.07, linewidth=0, zorder=0)
    ax.axhspan(0, scfg.os, color=UP, alpha=0.07, linewidth=0, zorder=0)
    for level in (scfg.os, scfg.ob):
        ax.axhline(level, color="#607d8b", linewidth=0.7, linestyle="--", alpha=0.8)

    for flags, colour in ((series.cross_up, UP), (series.cross_down, DOWN)):
        idx = np.flatnonzero(flags)
        if idx.size == 0:
            continue
        values = series.k[idx]
        keep = np.isfinite(values)
        if not np.any(keep):
            continue
        ax.plot(
            idx[keep],
            values[keep],
            linestyle="none",
            marker="o",
            markersize=3.5,
            color=colour,
            zorder=4,
        )

    # Circle the cross that actually produced DVG_CONFIRMED.
    t_c = result.confirmed_at_bar
    if t_c is not None and 0 <= t_c < series.n and np.isfinite(series.k[t_c]):
        ax.plot(
            t_c,
            series.k[t_c],
            linestyle="none",
            marker="o",
            markersize=10,
            markerfacecolor="none",
            markeredgecolor=INK,
            markeredgewidth=1.2,
            zorder=6,
        )
    ax.set_ylabel("Stoch")


def _decorate_adx(ax: Any, series: StudySeries) -> None:
    ax.axhline(
        series.adx_threshold,
        color=GATE_SHADE,
        linewidth=0.9,
        linestyle="--",
        alpha=0.9,
    )
    # Amber background wherever the gate is closed: the single most useful
    # thing on the chart, because it says "do not fade this yet".
    for start, end in _contiguous_spans(series.gate):
        ax.axvspan(start - 0.5, end + 0.5, color=GATE_SHADE, alpha=0.15, linewidth=0, zorder=0)
    ax.set_ylabel("ADX")
    ax.set_ylim(bottom=0)


# ---------------------------------------------------------------------------
# combined per-product chart: one column per horizon
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Window:
    """A display slice of a series, mapping bar indices to plot x positions."""

    start: int
    n: int

    @property
    def stop(self) -> int:
        return self.start + self.n

    def x(self, bar: int) -> int:
        return bar - self.start

    def visible(self, bar: int) -> bool:
        return self.start <= bar < self.stop

    def slice(self, values: np.ndarray) -> np.ndarray:
        return values[self.start : self.stop]


def display_window(series: StudySeries, bars: int) -> Window:
    """The last ``bars`` bars of ``series`` (or all of them, if fewer)."""
    n = min(bars, series.n)
    return Window(start=series.n - n, n=n)


def _date_ticks(
    timestamps: Sequence[Any], count: int = 4
) -> tuple[list[int], list[str]]:
    """Evenly spaced x positions and short date labels for a window.

    Built by hand rather than borrowing mplfinance's locator: in external
    axes mode the formatter lives on the price axis only, and sharing
    locator objects across axes makes them fight over tick placement.
    """
    n = len(timestamps)
    if n == 0:
        return [], []
    count = max(2, min(count, n))
    positions = [round(i * (n - 1) / (count - 1)) for i in range(count)]
    positions = sorted(set(positions))

    span_days = 0.0
    first, last = timestamps[0], timestamps[-1]
    if hasattr(first, "timestamp") and hasattr(last, "timestamp"):
        span_days = (last.timestamp() - first.timestamp()) / 86400.0

    if span_days > 400:
        # 140 weekly bars is nearly three years, and "19 Jan ... 06 Dec ...
        # 31 Oct" reads as though the axis runs backwards without the year.
        fmt = "%b %y"
    elif span_days > 5:
        fmt = "%d %b"
    else:
        # Intraday windows need the clock.
        fmt = "%d %b %H:%M"

    labels = []
    for pos in positions:
        ts = timestamps[pos]
        labels.append(ts.strftime(fmt) if hasattr(ts, "strftime") else str(ts))
    return positions, labels


def _column_title(result: StudyResult, horizon_label: str) -> tuple[str, str]:
    """``(headline, subtitle)`` for one horizon column."""
    head = horizon_label
    if result.state == "NONE":
        return head, "nothing here"
    bits = [state_label(result.state)]
    if result.direction_label:
        bits.append(f"{result.arrow} {result.direction_label}")
    if result.strength > 0:
        bits.append(f"σ {result.strength:.2f}")
    return head, "  ".join(bits)


def _draw_product_column(
    fig: Any,
    gs: Any,
    col: int,
    result: StudyResult,
    cfg: StudyConfig,
    horizon_label: str,
    display_bars: int,
    show_row_labels: bool,
) -> None:
    """Draw price / RSI / stochastic / ADX for one horizon into one column."""
    series = result.series
    axes = [fig.add_subplot(gs[row, col]) for row in range(4)]
    ax_price, ax_rsi, ax_stoch, ax_adx = axes

    if series is None or series.n == 0:
        for ax in axes:
            ax.set_xticks([])
            ax.set_yticks([])
        ax_price.text(
            0.5, 0.5, f"{horizon_label}\nno data",
            ha="center", va="center", fontsize=9, color="#9aa4b0",
            transform=ax_price.transAxes,
        )
        return

    win = display_window(series, display_bars)
    icfg = cfg.indicators
    x = np.arange(win.n)

    # -- price -----------------------------------------------------------
    pdf = to_pandas(_bars_frame(result)).iloc[win.start : win.stop]
    overlays = []
    for period, colour, style in (
        (icfg.ema_fast, EMA_FAST, "-"),
        (icfg.ema_mid, EMA_MID, "-"),
        (icfg.ema_slow, EMA_SLOW, "--"),
    ):
        values = win.slice(ind.ema(series.close, period))
        if np.any(np.isfinite(values)):
            overlays.append(
                mpf.make_addplot(
                    values, ax=ax_price, color=colour, width=0.9, linestyle=style
                )
            )

    # mplfinance validates `addplot` before use and rejects None outright, so
    # the kwarg has to be absent rather than empty. A column with no overlays
    # at all is reachable: a short window leaves every EMA in warm-up.
    plot_kwargs: dict[str, Any] = {
        "type": "candle",
        "style": build_style(),
        "ax": ax_price,
        "xrotation": 0,
        "warn_too_much_data": win.n + 1,
        "update_width_config": {"candle_linewidth": 0.7, "candle_width": 0.62},
    }
    if overlays:
        plot_kwargs["addplot"] = overlays
    mpf.plot(pdf, **plot_kwargs)

    bands = ind.bbands(series.close, icfg.bbands.period, icfg.bbands.std)
    upper, lower = win.slice(bands.upper), win.slice(bands.lower)
    valid = np.isfinite(upper) & np.isfinite(lower)
    if np.any(valid):
        ax_price.fill_between(
            x,
            np.where(valid, lower, np.nan),
            np.where(valid, upper, np.nan),
            color="#90a4ae", alpha=0.12, linewidth=0, zorder=0,
        )

    # Roll markers, unless they would dominate the panel. A weekly window of
    # 140 bars spans ~32 monthly rolls of a front-month generic, which draws
    # as a picket fence and hides the price action it is meant to annotate.
    rolls = [int(b) for b in np.flatnonzero(series.is_roll) if win.visible(int(b))]
    if len(rolls) <= max(1, int(win.n * ROLL_MARK_MAX_DENSITY)):
        for bar in rolls:
            ax_price.axvline(win.x(bar), color=ROLL_MARK, lw=0.8, alpha=0.7, zorder=0)

    swing_price = cfg.divergence.swing_price
    for swing in result.swings:
        if not win.visible(swing.bar_idx):
            continue
        y = _display_price(series, swing.bar_idx, swing.kind, swing_price)
        if not np.isfinite(y):
            continue
        ax_price.plot(
            win.x(swing.bar_idx), y * (1.004 if swing.is_high else 0.996),
            marker="v" if swing.is_high else "^", markersize=3.5, color=SWING_MARK,
            alpha=0.5 if swing.provisional else 0.85, markeredgewidth=0, zorder=3,
        )

    # -- RSI --------------------------------------------------------------
    rcfg = icfg.rsi
    ax_rsi.plot(x, win.slice(series.rsi), color=RSI_LINE, lw=1.1)
    ax_rsi.set_ylim(0, 100)
    ax_rsi.set_yticks([rcfg.os, 50, rcfg.ob])
    ax_rsi.axhspan(rcfg.ob, 100, color=DOWN, alpha=0.08, lw=0, zorder=0)
    ax_rsi.axhspan(0, rcfg.os, color=UP, alpha=0.08, lw=0, zorder=0)
    for level in (rcfg.os, rcfg.ob):
        ax_rsi.axhline(level, color="#607d8b", lw=0.7, ls="--", alpha=0.8)
    for level in (rcfg.os_soft, rcfg.ob_soft):
        ax_rsi.axhline(level, color="#90a4ae", lw=0.6, ls=":", alpha=0.7)

    # -- the divergence line, on both price and RSI ------------------------
    for event, dashed in _lines_to_draw(result):
        line = divergence_line(event, series, swing_price)
        if line is None or not (win.visible(line.x[0]) and win.visible(line.x[1])):
            continue
        xs = (win.x(line.x[0]), win.x(line.x[1]))
        for ax, ys in ((ax_price, line.price), (ax_rsi, line.rsi)):
            if not all(np.isfinite(ys)):
                continue
            ax.plot(
                xs, ys, color=line.colour, lw=1.9,
                linestyle="--" if dashed else "-",
                alpha=0.5 if dashed else 0.95, solid_capstyle="round", zorder=4,
            )
            ax.plot(
                xs, ys, linestyle="none", marker="o", markersize=3,
                color=line.colour, alpha=0.5 if dashed else 0.95, zorder=5,
            )

    # -- stochastic --------------------------------------------------------
    scfg = icfg.stoch
    ax_stoch.plot(x, win.slice(series.k), color=STOCH_K, lw=1.0)
    ax_stoch.plot(x, win.slice(series.d), color=STOCH_D, lw=1.0, ls="--")
    ax_stoch.set_ylim(0, 100)
    ax_stoch.set_yticks([scfg.os, 50, scfg.ob])
    ax_stoch.axhspan(scfg.ob, 100, color=DOWN, alpha=0.07, lw=0, zorder=0)
    ax_stoch.axhspan(0, scfg.os, color=UP, alpha=0.07, lw=0, zorder=0)
    for flags, colour in ((series.cross_up, UP), (series.cross_down, DOWN)):
        bars = [b for b in np.flatnonzero(flags) if win.visible(int(b))]
        if not bars:
            continue
        xs = [win.x(int(b)) for b in bars]
        ys = [series.k[int(b)] for b in bars]
        keep = [i for i, v in enumerate(ys) if np.isfinite(v)]
        if keep:
            ax_stoch.plot(
                [xs[i] for i in keep], [ys[i] for i in keep],
                linestyle="none", marker="o", markersize=3, color=colour, zorder=4,
            )
    t_c = result.confirmed_at_bar
    if t_c is not None and win.visible(t_c) and np.isfinite(series.k[t_c]):
        ax_stoch.plot(
            win.x(t_c), series.k[t_c], linestyle="none", marker="o", markersize=9,
            markerfacecolor="none", markeredgecolor=INK, markeredgewidth=1.1, zorder=6,
        )

    # -- ADX ---------------------------------------------------------------
    ax_adx.plot(x, win.slice(series.adx), color=INK, lw=1.3)
    ax_adx.plot(x, win.slice(series.plus_di), color=UP, lw=0.7)
    ax_adx.plot(x, win.slice(series.minus_di), color=DOWN, lw=0.7)
    ax_adx.axhline(series.adx_threshold, color=GATE_SHADE, lw=0.9, ls="--", alpha=0.9)
    ax_adx.set_ylim(bottom=0)
    for start, end in _contiguous_spans(win.slice(series.gate)):
        ax_adx.axvspan(start - 0.5, end + 0.5, color=GATE_SHADE, alpha=0.15, lw=0, zorder=0)

    # -- shared cosmetics --------------------------------------------------
    for ax in axes:
        ax.set_xlim(-0.5, win.n - 0.5)
        ax.grid(alpha=0.25, linewidth=0.5)
        ax.set_facecolor("white")
        for spine in ax.spines.values():
            spine.set_color("#cfd8dc")
        ax.tick_params(labelsize=7, length=2)
    for ax in axes[:-1]:
        ax.tick_params(labelbottom=False)
        ax.set_xlabel("")

    positions, labels = _date_ticks(win.slice(np.asarray(series.ts, dtype=object)).tolist())
    ax_adx.set_xticks(positions)
    ax_adx.set_xticklabels(labels, fontsize=7)

    if show_row_labels:
        for ax, label in zip(axes, ("Price", "RSI", "Stoch", "ADX"), strict=True):
            ax.set_ylabel(label, fontsize=8)
    else:
        for ax in axes:
            ax.set_ylabel("")

    head, sub = _column_title(result, horizon_label)
    ax_price.set_title(
        f"{head}\n{sub}",
        fontsize=9,
        fontweight="bold",
        color=STATE_COLOURS.get(result.state, INK),
        pad=6,
    )


def product_chart(
    results: Sequence[StudyResult],
    cfg: StudyConfig,
    product_label: str | None = None,
    display_bars: int | None = None,
) -> bytes:
    """One figure per product: a column per horizon, four rows deep.

    Reading the frequencies side by side is the point of the study - a
    weekly and a daily divergence pointing the same way is the headline
    signal - and that comparison is impossible when each (product, horizon)
    lives in its own section further down the email.
    """
    if not results:
        msg = "product_chart needs at least one horizon result"
        raise ValueError(msg)

    bars = display_bars or cfg.run.product_chart_bars or PRODUCT_CHART_BARS
    cols = len(results)
    product = product_label or results[0].product
    width = PRODUCT_COL_WIDTH_PX * cols

    fig = plt.figure(
        figsize=_figsize((width, PRODUCT_HEIGHT_PX), PRODUCT_DPI),
        dpi=PRODUCT_DPI,
        facecolor="white",
    )
    gs = fig.add_gridspec(
        4, cols,
        height_ratios=PRODUCT_ROW_RATIOS,
        hspace=0.10,
        wspace=0.16,
        left=0.05, right=0.99, top=0.90, bottom=0.06,
    )

    for col, result in enumerate(results):
        horizon = cfg.horizon(result.horizon)
        _draw_product_column(
            fig, gs, col, result, cfg,
            horizon.display if horizon else result.horizon,
            bars,
            show_row_labels=(col == 0),
        )

    as_of = max((r.as_of for r in results if r.as_of is not None), default=None)
    stamp = as_of.strftime("%Y-%m-%d") if hasattr(as_of, "strftime") else str(as_of)
    prod_cfg = cfg.product(product)
    title = prod_cfg.display if prod_cfg else product
    fig.suptitle(
        f"{title}  ·  {stamp}  ·  last {bars} bars",
        fontsize=13,
        fontweight="bold",
        color=INK,
        x=0.05,
        ha="left",
        y=0.975,
    )
    return _to_png(fig, PRODUCT_DPI)


# ---------------------------------------------------------------------------
# thumbnail
# ---------------------------------------------------------------------------
def thumbnail(result: StudyResult, cfg: StudyConfig) -> bytes:
    """Price + RSI only, 600x360, for the scan grid."""
    series = result.series
    if series is None or series.n == 0:
        return placeholder_chart(result, THUMB_SIZE_PX, THUMB_DPI)

    pdf = to_pandas(_bars_frame(result), use_adjusted=False)
    overlays = []
    rsi_plot = _addplot(series.rsi, panel=1, color=RSI_LINE, width=0.9, ylabel="RSI")
    if rsi_plot is not None:
        overlays.append(rsi_plot)

    thumb_kwargs: dict[str, Any] = {
        "type": "candle",
        "style": build_style(),
        "panel_ratios": (3, 1),
        "num_panels": 2,
        "volume": False,
        "figsize": _figsize(THUMB_SIZE_PX, THUMB_DPI),
        "returnfig": True,
        "tight_layout": True,
        "axisoff": False,
        "xrotation": 0,
        "warn_too_much_data": series.n + 1,
    }
    if overlays:
        thumb_kwargs["addplot"] = overlays
    fig, axes = mpf.plot(pdf, **thumb_kwargs)

    ax_price = axes[0]
    for event, dashed in _lines_to_draw(result):
        line = divergence_line(event, series, cfg.divergence.swing_price)
        if line is None or not all(np.isfinite(line.price)):
            continue
        ax_price.plot(
            line.x,
            line.price,
            color=line.colour,
            linewidth=1.6,
            linestyle="--" if dashed else "-",
            alpha=0.5 if dashed else 0.95,
        )

    if len(axes) > 2:
        axes[2].set_ylim(0, 100)
        axes[2].axhline(cfg.indicators.rsi.ob, color="#607d8b", lw=0.5, ls="--")
        axes[2].axhline(cfg.indicators.rsi.os, color="#607d8b", lw=0.5, ls="--")

    fig.suptitle(
        f"{result.product} {result.horizon} · {result.state}",
        fontsize=8,
        color=STATE_COLOURS.get(result.state, INK),
        x=0.01,
        ha="left",
    )
    return _to_png(fig, THUMB_DPI)


def placeholder_chart(
    result: StudyResult, size_px: tuple[int, int], dpi: int
) -> bytes:
    """A labelled blank when there are not enough bars to plot."""
    fig = plt.figure(figsize=_figsize(size_px, dpi), facecolor="white")
    ax = fig.add_subplot(111)
    ax.axis("off")
    ax.text(
        0.5,
        0.5,
        f"{result.product} {result.horizon}\ninsufficient bars ({result.n_bars})",
        ha="center",
        va="center",
        fontsize=11,
        color="#78909c",
    )
    return _to_png(fig, dpi)


# ---------------------------------------------------------------------------
# batch rendering
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ChartJob:
    product: str
    horizon: str
    kind: str  # "full" | "thumb"

    @property
    def key(self) -> tuple[str, str, str]:
        return (self.product, self.horizon, self.kind)


def _render_product(
    args: tuple[str, list[StudyResult], StudyConfig],
) -> tuple[str, bytes]:
    """Pool entry point for the combined per-product chart."""
    product, results, cfg = args
    matplotlib.use("Agg")
    try:
        data = product_chart(results, cfg, product_label=product)
    except Exception as exc:
        log.warning("product chart failed for %s: %s", product, exc)
        data = b""
    return product, data


def render_product_charts(
    groups: Sequence[tuple[str, list[StudyResult]]],
    cfg: StudyConfig,
    workers: int | None = None,
) -> dict[str, bytes]:
    """Render one combined chart per product, keyed by product name."""
    if not groups:
        return {}
    n_workers = cfg.run.chart_workers if workers is None else workers
    payload = [(product, list(results), cfg) for product, results in groups]

    if n_workers and len(payload) > 1:
        try:
            with ProcessPoolExecutor(max_workers=n_workers) as pool:
                return dict(pool.map(_render_product, payload))
        except Exception as exc:
            log.warning("parallel chart rendering failed (%s); rendering serially", exc)

    return dict(_render_product(item) for item in payload)


def _render_one(args: tuple[StudyResult, StudyConfig, str]) -> tuple[tuple[str, str, str], bytes]:
    """Module-level entry point so the pool can pickle it (Windows spawn)."""
    result, cfg, kind = args
    matplotlib.use("Agg")
    try:
        data = full_chart(result, cfg) if kind == "full" else thumbnail(result, cfg)
    except Exception as exc:
        log.warning("chart failed for %s %s (%s): %s", result.product, result.horizon, kind, exc)
        data = b""
    return ((result.product, result.horizon, kind), data)


def render_charts(
    jobs: Sequence[tuple[StudyResult, str]],
    cfg: StudyConfig,
    workers: int | None = None,
) -> dict[tuple[str, str, str], bytes]:
    """Render every requested chart, keyed by ``(product, horizon, kind)``.

    ``workers = 0`` renders in-process, which is what the tests and
    ``--no-parallel`` use. Any failure in the pool falls back to serial
    rendering rather than losing the email.
    """
    if not jobs:
        return {}
    n_workers = cfg.run.chart_workers if workers is None else workers
    payload = [(result, cfg, kind) for result, kind in jobs]

    if n_workers and len(payload) > 1:
        try:
            with ProcessPoolExecutor(max_workers=n_workers) as pool:
                return dict(pool.map(_render_one, payload))
        except Exception as exc:
            log.warning("parallel chart rendering failed (%s); rendering serially", exc)

    return dict(_render_one(item) for item in payload)
