"""Configuration models and YAML loader for the TA study.

Every parameter in the mathematical specification is a field here and a key
in ``config/ta_products.yaml``. Nothing in the rest of the package
hard-codes a ticker, a period or a threshold.

Symbol names from the spec are given in the field docstrings so the config
can be read side by side with §8a.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

DEFAULT_CONFIG_PATH = Path(__file__).parent / "config" / "ta_products.yaml"

RollMethod = Literal["drop", "backadjust", "none"]
SwingPrice = Literal["close", "highlow"]
HorizonSource = Literal["daily", "intraday"]

#: Left-to-right order of the horizon columns in the charts and the grid.
#: ``fine_to_coarse`` puts the fastest frequency on the left.
HorizonOrder = Literal["fine_to_coarse", "coarse_to_fine", "config"]

#: Every state the composite machine can emit (§8, §8a G).
State = Literal[
    "NONE",
    "DVG_ACTIVE",
    "DVG_CONFIRMED",
    "DVG_GATED",
    "DVG_GATE_RELEASING",
    "DVG_EXPIRED",
    "PROVISIONAL",
    "MA_CROSS_NEW",
]

#: States that carry a live directional bias.
LIVE_STATES: tuple[str, ...] = (
    "DVG_ACTIVE",
    "DVG_CONFIRMED",
    "DVG_GATED",
    "DVG_GATE_RELEASING",
)

#: Plain-language label shown in the email and on the charts.
#:
#: The identifiers above are what the spec names and what ``STUDY_STATE``
#: stores, so they never change; but "DVG_GATE_RELEASING" tells a reader
#: nothing, and a desk report should not need a decoder ring.
STATE_LABELS: dict[str, str] = {
    "DVG_CONFIRMED": "CONFIRMED",
    "DVG_ACTIVE": "SETUP",
    "DVG_GATED": "ON HOLD",
    "DVG_GATE_RELEASING": "CLEARED",
    "DVG_EXPIRED": "FADED",
    "PROVISIONAL": "FORMING",
    "NONE": "—",
    "MA_CROSS_NEW": "MA CROSS",
}

#: One-line explanation of each label, for the legend.
STATE_GLOSS: dict[str, str] = {
    "DVG_CONFIRMED": "the turn has started - price and momentum split, and the "
                     "stochastic has crossed to confirm it",
    "DVG_ACTIVE": "price and momentum have split; waiting for the turn to show",
    "DVG_GATED": "setup is there, but the trend is too strong to fade yet",
    "DVG_GATE_RELEASING": "the trend has stopped strengthening - tradable again",
    "DVG_EXPIRED": "the setup aged out without the turn arriving",
    "PROVISIONAL": "may become a setup if the latest swing holds",
    "NONE": "nothing here",
}


def state_label(state: str) -> str:
    return STATE_LABELS.get(state, state)


class _Base(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


# ---------------------------------------------------------------------------
# indicators
# ---------------------------------------------------------------------------
class RsiConfig(_Base):
    """§8a B. ``period`` is n_R."""

    period: int = Field(14, ge=2)
    ob: float = 70.0
    os: float = 30.0
    #: Soft zones theta_ob_soft / theta_os_soft used by the divergence zone filter.
    ob_soft: float = 60.0
    os_soft: float = 40.0

    @model_validator(mode="after")
    def _ordered(self) -> RsiConfig:
        if not self.os < self.os_soft < self.ob_soft < self.ob:
            msg = (
                "RSI zones must satisfy os < os_soft < ob_soft < ob, got "
                f"{self.os} < {self.os_soft} < {self.ob_soft} < {self.ob}"
            )
            raise ValueError(msg)
        return self


class StochConfig(_Base):
    """§8a E. TA-Lib ``STOCH(k_period, k_smooth, d_period)`` - slow stochastic."""

    k_period: int = Field(14, ge=1)
    k_smooth: int = Field(3, ge=1)
    d_period: int = Field(3, ge=1)
    ob: float = 80.0
    os: float = 20.0
    #: True uses K_raw directly (fast stochastic) instead of the s_K average.
    fast: bool = False


class AdxConfig(_Base):
    """§8a F. ``period`` is n_D."""

    period: int = Field(14, ge=2)


class MacdConfig(_Base):
    fast: int = Field(12, ge=1)
    slow: int = Field(26, ge=2)
    signal: int = Field(9, ge=1)

    @model_validator(mode="after")
    def _fast_lt_slow(self) -> MacdConfig:
        if self.fast >= self.slow:
            msg = f"MACD fast ({self.fast}) must be shorter than slow ({self.slow})"
            raise ValueError(msg)
        return self


class BBandsConfig(_Base):
    period: int = Field(20, ge=2)
    std: float = Field(2.0, gt=0)


class AtrConfig(_Base):
    """§8a D. ``period`` is n_A."""

    period: int = Field(14, ge=2)


class IndicatorsConfig(_Base):
    rsi: RsiConfig = Field(default_factory=RsiConfig)
    stoch: StochConfig = Field(default_factory=StochConfig)
    adx: AdxConfig = Field(default_factory=AdxConfig)
    ema: tuple[int, ...] = (20, 50, 200)
    macd: MacdConfig = Field(default_factory=MacdConfig)
    bbands: BBandsConfig = Field(default_factory=BBandsConfig)
    atr: AtrConfig = Field(default_factory=AtrConfig)
    #: Candlestick patterns need TA-Lib; skipped with a note when absent.
    candles: bool = True

    @field_validator("ema")
    @classmethod
    def _ema_sorted(cls, v: tuple[int, ...]) -> tuple[int, ...]:
        if len(v) != 3:
            msg = f"exactly three EMA periods are expected (fast, mid, slow), got {v}"
            raise ValueError(msg)
        if list(v) != sorted(v):
            msg = f"EMA periods must be ascending, got {v}"
            raise ValueError(msg)
        return v

    @property
    def ema_fast(self) -> int:
        return self.ema[0]

    @property
    def ema_mid(self) -> int:
        return self.ema[1]

    @property
    def ema_slow(self) -> int:
        return self.ema[2]


# ---------------------------------------------------------------------------
# divergence / gate / signal
# ---------------------------------------------------------------------------
class DivergenceConfig(_Base):
    """§8a C and D."""

    #: k - bars each side of a local extremum.
    swing_k: int = Field(5, ge=1)
    #: L_max - maximum bar distance between the two swings.
    max_lookback_bars: int = Field(60, ge=2)
    #: s_min - minimum bar separation between the two swings.
    min_swing_separation: int = Field(5, ge=1)
    #: delta - minimum |RSI| difference between the swings.
    min_rsi_delta: float = Field(2.0, ge=0)
    #: Require the first swing to sit in the soft OB/OS zone.
    rsi_zone_filter: bool = True
    #: W_c - bars after t* in which a stochastic cross still confirms.
    confirmation_window: int = Field(10, ge=0)
    #: W_a - bars a divergence stays active awaiting confirmation.
    active_window: int = Field(15, ge=1)
    #: Hidden (continuation) divergences. Off by default: the study as
    #: described covers regular divergences only.
    include_hidden: bool = False
    #: Which price the swing detector runs on (§8a A, ``swing_price``).
    swing_price: SwingPrice = "close"
    #: m - bars either side of a swing over which the extreme RSI is taken.
    rsi_tolerance_bars: int = Field(0, ge=0)
    #: Bars after the active window for which an unconfirmed divergence is
    #: still reported as DVG_EXPIRED rather than falling back to NONE. The
    #: spec's NONE and DVG_EXPIRED conditions overlap once a divergence has
    #: aged out; this bounds how long EXPIRED wins so the grid goes quiet.
    expired_window: int = Field(5, ge=0)

    @model_validator(mode="after")
    def _separation_fits(self) -> DivergenceConfig:
        if self.min_swing_separation > self.max_lookback_bars:
            msg = (
                f"min_swing_separation ({self.min_swing_separation}) exceeds "
                f"max_lookback_bars ({self.max_lookback_bars})"
            )
            raise ValueError(msg)
        if self.rsi_tolerance_bars > self.swing_k:
            # m > k would read RSI from bars that are not yet observable at
            # the swing's confirmation time, breaking the no-lookahead
            # invariant (§8a I).
            msg = (
                f"rsi_tolerance_bars ({self.rsi_tolerance_bars}) must not exceed "
                f"swing_k ({self.swing_k}); larger values look ahead of confirmed_at"
            )
            raise ValueError(msg)
        return self


class AdxGateConfig(_Base):
    """§8a F, gate and release."""

    #: theta_ADX when a product does not override it.
    default_threshold: float = 30.0
    #: r - slope lookback in bars.
    rising_slope_bars: int = Field(3, ge=1)


class SignalConfig(_Base):
    """§8a G - size multipliers."""

    #: lambda_u - multiplier while a divergence is unconfirmed.
    unconfirmed_multiplier: float = Field(0.5, ge=0, le=1)
    #: lambda_g - multiplier while the ADX gate is closed; 0 ignores gated
    #: signals entirely.
    gated_multiplier: float = Field(0.5, ge=0, le=1)
    #: A stochastic cross is required for a tradable signal. Off by default:
    #: confirmation changes the state label and the size, not whether the
    #: divergence is reported.
    require_confirmation: bool = False
    #: Strength-score weights w = (|dRSI|, |dP|/ATR, RSI extremity).
    strength_weights: tuple[float, float, float] = (0.5, 0.25, 0.25)
    #: Denominators in the strength score (§8a D).
    strength_rsi_scale: float = Field(30.0, gt=0)
    strength_atr_multiple: float = Field(3.0, gt=0)

    @field_validator("strength_weights")
    @classmethod
    def _weights_sum_to_one(cls, v: tuple[float, float, float]) -> tuple[float, float, float]:
        total = sum(v)
        if abs(total - 1.0) > 1e-9:
            msg = f"strength_weights must sum to 1.0, got {total}"
            raise ValueError(msg)
        if any(w < 0 for w in v):
            msg = f"strength_weights must be non-negative, got {v}"
            raise ValueError(msg)
        return v


# ---------------------------------------------------------------------------
# horizons and products
# ---------------------------------------------------------------------------
class HorizonConfig(_Base):
    """One resolution the study runs at."""

    name: str
    source: HorizonSource = "daily"
    #: pandas/polars resample rule; only meaningful for ``source: daily``.
    resample: str | None = None
    #: Bar length in minutes; only meaningful for ``source: intraday``.
    interval_min: int | None = None
    #: Bars to keep for the study and the chart.
    bars: int = Field(400, ge=50)
    enabled: bool = True
    label: str | None = None

    @model_validator(mode="after")
    def _source_consistent(self) -> HorizonConfig:
        if self.source == "intraday" and self.interval_min is None:
            msg = f"horizon {self.name}: intraday horizons need interval_min"
            raise ValueError(msg)
        if self.source == "daily" and self.interval_min is not None:
            msg = f"horizon {self.name}: interval_min is meaningless for a daily source"
            raise ValueError(msg)
        return self

    @property
    def display(self) -> str:
        return self.label or self.name

    @property
    def is_intraday(self) -> bool:
        return self.source == "intraday"

    @property
    def bar_minutes(self) -> int:
        """Nominal bar length, used to order horizons by frequency."""
        if self.interval_min is not None:
            return self.interval_min
        if self.resample:
            # Only weekly rules are supported (see data._WEEK_END_DOW).
            return 7 * 24 * 60
        return 24 * 60


class ProductConfig(_Base):
    name: str
    ticker: str
    group: str
    label: str | None = None
    #: theta_ADX override; falls back to ``adx_gate.default_threshold``.
    adx_threshold: float | None = None
    #: Exchange session start in ``session_tz``, used to align 4h bars to the
    #: session rather than to midnight (§4).
    session_start: str = "08:00"
    session_tz: str = "Europe/London"
    roll_method: RollMethod | None = None
    #: Horizon names this product is skipped on (illiquid overnight sessions,
    #: no intraday entitlement, and so on).
    skip_horizons: tuple[str, ...] = ()
    note: str | None = None

    @property
    def display(self) -> str:
        return self.label or self.name

    @field_validator("session_start")
    @classmethod
    def _hhmm(cls, v: str) -> str:
        parts = v.split(":")
        if len(parts) != 2 or not all(p.isdigit() for p in parts):
            msg = f"session_start must be HH:MM, got {v!r}"
            raise ValueError(msg)
        hh, mm = int(parts[0]), int(parts[1])
        if not (0 <= hh < 24 and 0 <= mm < 60):
            msg = f"session_start out of range: {v!r}"
            raise ValueError(msg)
        return v

    @property
    def session_start_minutes(self) -> int:
        hh, mm = (int(p) for p in self.session_start.split(":"))
        return hh * 60 + mm


# ---------------------------------------------------------------------------
# run / delivery / persistence
# ---------------------------------------------------------------------------
class RunConfig(_Base):
    timezone: str = "Europe/London"
    send_time: str = "07:00"
    recipients: list[str] = Field(default_factory=list)
    error_recipients: list[str] = Field(default_factory=list)
    max_email_mb: float = Field(8.0, gt=0)
    #: States that earn a full-size chart (§3 ``full_chart_states``).
    full_chart_states: tuple[str, ...] = (
        "DVG_CONFIRMED",
        "DVG_ACTIVE",
        "DVG_GATED",
        "MA_CROSS_NEW",
    )
    #: Calendar days of daily history to request. ~900 covers the 200-EMA
    #: warm-up plus 300 weekly bars.
    daily_lookback_days: int = Field(1200, ge=200)
    #: Calendar days of intraday history to request per run. Bloomberg
    #: retains ~140; the rest is read back from Snowflake.
    intraday_lookback_days: int = Field(120, ge=5)
    #: True connects to the B-PIPE server (Tech1ProdBPipe…:8194) with app
    #: auth; False opens a local blpapi session against a desktop Terminal
    #: on localhost:8194. A container has no Terminal, so this must stay
    #: True on the server. ``$BLOOMBERG_ON_SERVER`` overrides it, matching
    #: every other job in this repo - see :meth:`bloomberg_on_server`.
    bloomberg_on_server: bool = True
    #: Minimum bars a (product, horizon) needs before it is studied at all.
    min_bars: int = Field(60, ge=20)
    #: Worker processes for chart rendering; 0 means render in-process.
    chart_workers: int = Field(4, ge=0)
    #: Bars drawn per column in the combined per-product chart. The study
    #: still computes on the full horizon window; this only limits the view.
    product_chart_bars: int = Field(140, ge=30)
    #: Left-to-right order of the horizon columns, in both the charts and
    #: the signal grid. Fastest on the left by default, so the eye travels
    #: from the trade's own time frame out to its context.
    horizon_order: HorizonOrder = "fine_to_coarse"
    #: The old per-cell thumbnail grid. Off by default: the combined
    #: per-product chart shows every frequency already, at a readable size.
    include_thumbnail_strip: bool = False
    output_dir: str = "output"
    cache_dir: str = "cache"
    state_dir: str = "state"

    @field_validator("recipients", "error_recipients", mode="before")
    @classmethod
    def _split_csv(cls, v: Any) -> Any:
        if isinstance(v, str):
            return [p.strip() for p in v.split(",") if p.strip()]
        return v

    @property
    def max_email_bytes(self) -> int:
        return int(self.max_email_mb * 1024 * 1024)


class DeliveryConfig(_Base):
    """Satisfies :class:`common.deliver.DeliverySettings` structurally.

    Defaults to ``kafka``: it is the transport that is actually configured on
    this desk, and the relay carries charts perfectly well as base64 ``data:``
    URIs - the same thing ``ccgt_power_stack`` and ``china_summary`` do.
    Switch to ``graph`` once ``graph_tenant_id`` / ``graph_client_id`` and
    ``$GRAPH_CLIENT_SECRET`` exist; CID inline parts are the more robust
    encoding and keep the body small.
    """

    transport: Literal["graph", "smtp", "kafka"] = "kafka"
    sender: str = "eu.gap.service@jainglobal.com"
    graph_tenant_id: str | None = None
    graph_client_id: str | None = None
    graph_client_secret_env: str = "GRAPH_CLIENT_SECRET"
    smtp_host: str | None = None
    smtp_port: int = 25
    smtp_use_tls: bool = False
    smtp_user: str | None = None
    smtp_password_env: str = "SMTP_PASSWORD"
    #: Link target used in place of dropped charts.
    dash_url: str | None = None


class PersistConfig(_Base):
    enabled: bool = False
    database: str = "RISK"
    schema_: str = Field(default="TA", alias="schema")
    role: str = "FR_COMMOD_PM_EU"
    warehouse: str = "EU_COMMOD_RESEARCH_XS_WH"
    study_state_table: str = "STUDY_STATE"
    divergence_events_table: str = "DIVERGENCE_EVENTS"
    ma_cross_events_table: str = "MA_CROSS_EVENTS"
    intraday_bars_table: str = "INTRADAY_BARS"
    #: Local mirror of the previous run's states, so the "what changed since
    #: yesterday" header works with persistence disabled.
    local_state_dir: str = "state"

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)


class StatsConfig(_Base):
    """§12 - forward returns and hit rates."""

    #: Forward horizons h, in bars.
    forward_bars: tuple[int, ...] = (5, 10, 20)
    #: Minimum sample before a hit rate is displayed.
    min_sample: int = Field(20, ge=1)
    #: Which forward horizon the email caption quotes.
    headline_forward_bars: int = 10

    @model_validator(mode="after")
    def _headline_available(self) -> StatsConfig:
        if self.headline_forward_bars not in self.forward_bars:
            msg = (
                f"headline_forward_bars ({self.headline_forward_bars}) must be one "
                f"of forward_bars {self.forward_bars}"
            )
            raise ValueError(msg)
        return self


# ---------------------------------------------------------------------------
# root
# ---------------------------------------------------------------------------
class StudyConfig(_Base):
    run: RunConfig = Field(default_factory=RunConfig)
    horizons: list[HorizonConfig]
    products: list[ProductConfig]
    indicators: IndicatorsConfig = Field(default_factory=IndicatorsConfig)
    divergence: DivergenceConfig = Field(default_factory=DivergenceConfig)
    adx_gate: AdxGateConfig = Field(default_factory=AdxGateConfig)
    signal: SignalConfig = Field(default_factory=SignalConfig)
    stats: StatsConfig = Field(default_factory=StatsConfig)
    persist: PersistConfig = Field(default_factory=PersistConfig)
    delivery: DeliveryConfig = Field(default_factory=DeliveryConfig)
    #: Default roll handling for momentum indicators (§4).
    roll_method: RollMethod = "backadjust"

    @field_validator("products")
    @classmethod
    def _unique_products(cls, v: list[ProductConfig]) -> list[ProductConfig]:
        names = [p.name for p in v]
        dupes = sorted({n for n in names if names.count(n) > 1})
        if dupes:
            msg = f"duplicate product names: {dupes}"
            raise ValueError(msg)
        if not v:
            msg = "at least one product must be configured"
            raise ValueError(msg)
        return v

    @field_validator("horizons")
    @classmethod
    def _unique_horizons(cls, v: list[HorizonConfig]) -> list[HorizonConfig]:
        names = [h.name for h in v]
        dupes = sorted({n for n in names if names.count(n) > 1})
        if dupes:
            msg = f"duplicate horizon names: {dupes}"
            raise ValueError(msg)
        if not v:
            msg = "at least one horizon must be configured"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def _skip_horizons_exist(self) -> StudyConfig:
        known = {h.name for h in self.horizons}
        for prod in self.products:
            unknown = sorted(set(prod.skip_horizons) - known)
            if unknown:
                msg = f"{prod.name}: skip_horizons names unknown horizons {unknown}"
                raise ValueError(msg)
        return self

    # -- lookups --------------------------------------------------------
    def product(self, name: str) -> ProductConfig | None:
        for p in self.products:
            if p.name == name:
                return p
        return None

    def horizon(self, name: str) -> HorizonConfig | None:
        for h in self.horizons:
            if h.name == name:
                return h
        return None

    @property
    def active_horizons(self) -> list[HorizonConfig]:
        """Enabled horizons in display order (see ``run.horizon_order``).

        One ordering drives both the chart columns and the signal grid, so
        the two halves of the email can never disagree about which column
        is which.
        """
        active = [h for h in self.horizons if h.enabled]
        if self.run.horizon_order == "config":
            return active
        reverse = self.run.horizon_order == "coarse_to_fine"
        return sorted(active, key=lambda h: h.bar_minutes, reverse=reverse)

    @property
    def bloomberg_on_server(self) -> bool:
        """Whether to use B-PIPE, honouring ``$BLOOMBERG_ON_SERVER``.

        The rest of the repo reads that variable through
        ``jain_commods``' ``is_bloomberg_on_server()``; reading it here too
        means a developer can point the study at a local Terminal without
        editing the YAML, and the container keeps the B-PIPE default.
        """
        override = os.environ.get("BLOOMBERG_ON_SERVER")
        if override is None or not override.strip():
            return self.run.bloomberg_on_server
        return override.strip().lower() in ("1", "true", "yes", "on")

    def horizon_rank(self, name: str) -> int:
        """Position of ``name`` in display order; unknown names sort last."""
        order = [h.name for h in self.active_horizons]
        return order.index(name) if name in order else len(order)

    def pairs(self) -> list[tuple[ProductConfig, HorizonConfig]]:
        """Every (product, horizon) the run should evaluate, in email order."""
        return [
            (p, h)
            for p in self.products
            for h in self.active_horizons
            if h.name not in p.skip_horizons
        ]

    def adx_threshold_for(self, product: str) -> float:
        prod = self.product(product)
        if prod is not None and prod.adx_threshold is not None:
            return prod.adx_threshold
        return self.adx_gate.default_threshold

    def roll_method_for(self, product: str) -> RollMethod:
        prod = self.product(product)
        if prod is not None and prod.roll_method is not None:
            return prod.roll_method
        return self.roll_method

    @property
    def needs_intraday(self) -> bool:
        return any(h.is_intraday for h in self.active_horizons)

    @property
    def intraday_base_interval(self) -> int:
        """Finest intraday interval in use; 4h bars are derived from it."""
        intervals = [
            h.interval_min for h in self.active_horizons if h.interval_min is not None
        ]
        return min(intervals) if intervals else 60


def load_config(path: str | Path | None = None) -> StudyConfig:
    """Load and validate ``ta_products.yaml``."""
    cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not cfg_path.exists():
        msg = f"ta_study config not found: {cfg_path}"
        raise FileNotFoundError(msg)

    with cfg_path.open("r", encoding="utf-8") as fh:
        raw: dict[str, Any] = yaml.safe_load(fh) or {}

    return StudyConfig.model_validate(raw)
