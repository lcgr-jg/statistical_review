"""Secondary indicators (§9) - context, not signals.

Everything here is reported alongside the study but never feeds the
composite state machine. The one exception is ``MA_CROSS_NEW``, which can
earn a (product, horizon) a full-size chart via ``run.full_chart_states``
without changing the cell's state badge.

Candlestick patterns are text tags by design: six pattern definitions
disagree between vendors, so calling them signals would put the email at
odds with whatever the reader has on their own screen.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np
import numpy.typing as npt

from ta_study import indicators as ind
from ta_study.config import StudyConfig
from ta_study.study import StudySeries

FloatArray = npt.NDArray[np.float64]

Regime = Literal["bull-stacked", "bear-stacked", "mixed", "na"]

#: Bars within which a cross or a histogram flip counts as "new".
NEW_EVENT_BARS = 3

#: Look-back windows for the range section, in bars (§9).
RANGE_WINDOWS: tuple[int, ...] = (52, 252)


@dataclass(frozen=True)
class MaCross:
    """One EMA crossover event."""

    pair: str
    bar: int
    direction: int
    ts: Any = None

    @property
    def label(self) -> str:
        kind = "golden" if self.direction > 0 else "death"
        return f"EMA{self.pair} {kind} cross"


@dataclass(frozen=True)
class RangeStat:
    """Where the last bar sits inside its ``window``-bar range.

    ``high``/``low`` are the extremes of the window's highs and lows - the
    numbers the email prints. ``at_high`` compares the *current bar's own
    high* against the window high rather than its close: a close almost
    never equals the highest high of 52 bars, so a close-versus-high test
    would read False on the very day a contract makes a new 52-bar high.
    """

    window: int
    high: float
    low: float
    close: float
    bar_high: float
    bar_low: float

    @property
    def at_high(self) -> bool:
        return (
            np.isfinite(self.high)
            and np.isfinite(self.bar_high)
            and self.bar_high >= self.high
        )

    @property
    def at_low(self) -> bool:
        return (
            np.isfinite(self.low)
            and np.isfinite(self.bar_low)
            and self.bar_low <= self.low
        )

    @property
    def pct_of_range(self) -> float:
        """Where the close sits in the window range, 0 = low, 1 = high."""
        span = self.high - self.low
        if not np.isfinite(span) or span <= 0:
            return float("nan")
        return float((self.close - self.low) / span)


@dataclass
class SecondaryResult:
    """Per (product, horizon) context block."""

    product: str
    horizon: str

    regime: Regime = "na"
    ema: dict[int, float] = field(default_factory=dict)
    dist_atr: dict[int, float] = field(default_factory=dict)
    crosses: list[MaCross] = field(default_factory=list)
    recent_crosses: list[MaCross] = field(default_factory=list)

    macd_line: float = float("nan")
    macd_signal: float = float("nan")
    macd_hist: float = float("nan")
    macd_flip: int = 0

    percent_b: float = float("nan")
    bb_outside: int = 0
    bandwidth_pctile: float = float("nan")

    ranges: dict[int, RangeStat] = field(default_factory=dict)
    candle_tags: list[str] = field(default_factory=list)
    candles_available: bool = True

    @property
    def ma_cross_new(self) -> bool:
        return bool(self.recent_crosses)

    @property
    def regime_label(self) -> str:
        return {
            "bull-stacked": "bull stacked",
            "bear-stacked": "bear stacked",
            "mixed": "mixed",
            "na": "n/a",
        }[self.regime]

    @property
    def macd_hist_sign(self) -> str:
        if not np.isfinite(self.macd_hist):
            return "n/a"
        if self.macd_hist > 0:
            return "+"
        if self.macd_hist < 0:
            return "-"
        return "0"

    @property
    def bb_label(self) -> str:
        if not np.isfinite(self.percent_b):
            return "n/a"
        if self.bb_outside > 0:
            return f"{self.percent_b:.2f} (above upper)"
        if self.bb_outside < 0:
            return f"{self.percent_b:.2f} (below lower)"
        return f"{self.percent_b:.2f}"


# ---------------------------------------------------------------------------
# moving averages
# ---------------------------------------------------------------------------
def ema_regime(fast: float, mid: float, slow: float) -> Regime:
    """Label from the EMA ordering: 20 > 50 > 200 is bull-stacked."""
    if not all(np.isfinite(v) for v in (fast, mid, slow)):
        return "na"
    if fast > mid > slow:
        return "bull-stacked"
    if fast < mid < slow:
        return "bear-stacked"
    return "mixed"


def crossovers(
    fast: FloatArray,
    slow: FloatArray,
    pair: str,
    timestamps: Sequence[Any] | None = None,
) -> list[MaCross]:
    """Every bar where ``fast`` crosses ``slow``.

    A cross is recorded at the first bar on which the ordering differs from
    the previous bar, both bars being finite. Equality on the previous bar
    counts as "not yet crossed", so a touch-and-separate emits one event, not
    two.
    """
    out: list[MaCross] = []
    n = min(fast.size, slow.size)
    for t in range(1, n):
        f0, f1, s0, s1 = fast[t - 1], fast[t], slow[t - 1], slow[t]
        if not all(np.isfinite(v) for v in (f0, f1, s0, s1)):
            continue
        if f0 <= s0 and f1 > s1:
            out.append(
                MaCross(
                    pair=pair,
                    bar=t,
                    direction=1,
                    ts=timestamps[t] if timestamps is not None else None,
                )
            )
        elif f0 >= s0 and f1 < s1:
            out.append(
                MaCross(
                    pair=pair,
                    bar=t,
                    direction=-1,
                    ts=timestamps[t] if timestamps is not None else None,
                )
            )
    return out


def _hist_flip(hist: FloatArray, lookback: int = NEW_EVENT_BARS) -> int:
    """Sign of a MACD histogram sign change within ``lookback`` bars, else 0."""
    n = hist.size
    for t in range(max(1, n - lookback), n):
        prev, cur = hist[t - 1], hist[t]
        if not (np.isfinite(prev) and np.isfinite(cur)):
            continue
        if prev <= 0 < cur:
            return 1
        if prev >= 0 > cur:
            return -1
    return 0


# ---------------------------------------------------------------------------
# assembly
# ---------------------------------------------------------------------------
def compute_secondary(
    series: StudySeries,
    cfg: StudyConfig,
    product: str,
    horizon: str,
    daily_ranges: bool = True,
) -> SecondaryResult:
    """The secondary block for one (product, horizon).

    ``daily_ranges`` gates the 52/252-bar range stats and the candlestick
    tags, both of which §9 scopes to the daily horizon.
    """
    out = SecondaryResult(product=product, horizon=horizon)
    if series.n == 0:
        out.regime = "na"
        return out

    icfg = cfg.indicators
    close = series.close_study
    last = series.last
    atr_last = series.at(series.atr)

    # -- EMA stack -------------------------------------------------------
    emas = {period: ind.ema(close, period) for period in icfg.ema}
    for period, values in emas.items():
        out.ema[period] = series.at(values)
        distance = series.at(close) - out.ema[period]
        out.dist_atr[period] = (
            float(distance / atr_last)
            if np.isfinite(distance) and np.isfinite(atr_last) and atr_last > 0
            else float("nan")
        )

    out.regime = ema_regime(
        out.ema.get(icfg.ema_fast, float("nan")),
        out.ema.get(icfg.ema_mid, float("nan")),
        out.ema.get(icfg.ema_slow, float("nan")),
    )

    pairs = (
        (icfg.ema_fast, icfg.ema_mid),
        (icfg.ema_mid, icfg.ema_slow),
    )
    for fast_p, slow_p in pairs:
        label = f"{fast_p}/{slow_p}"
        out.crosses.extend(
            crossovers(emas[fast_p], emas[slow_p], label, series.ts)
        )
    out.crosses.sort(key=lambda c: c.bar)
    out.recent_crosses = [
        c for c in out.crosses if last - c.bar < NEW_EVENT_BARS
    ]

    # -- MACD ------------------------------------------------------------
    macd = ind.macd(close, icfg.macd.fast, icfg.macd.slow, icfg.macd.signal)
    out.macd_line = series.at(macd.line)
    out.macd_signal = series.at(macd.signal)
    out.macd_hist = series.at(macd.hist)
    out.macd_flip = _hist_flip(macd.hist)

    # -- Bollinger -------------------------------------------------------
    bands = ind.bbands(close, icfg.bbands.period, icfg.bbands.std)
    pct_b = ind.percent_b(close, bands)
    out.percent_b = series.at(pct_b)
    if np.isfinite(out.percent_b):
        out.bb_outside = 1 if out.percent_b > 1.0 else (-1 if out.percent_b < 0.0 else 0)
    bandwidth = bands.bandwidth
    # 252 bars of context where available; the percentile is meaningless on
    # a shorter sample, so min_obs guards it rather than a partial window.
    pctile = ind.rolling_rank_pct(bandwidth, 252, min_obs=60)
    out.bandwidth_pctile = series.at(pctile)

    # -- ranges and candles (daily only) ---------------------------------
    if daily_ranges:
        for window in RANGE_WINDOWS:
            if series.n < window:
                continue
            tail_high = series.high_study[series.n - window :]
            tail_low = series.low_study[series.n - window :]
            finite_high = tail_high[np.isfinite(tail_high)]
            finite_low = tail_low[np.isfinite(tail_low)]
            if finite_high.size == 0 or finite_low.size == 0:
                continue
            out.ranges[window] = RangeStat(
                window=window,
                high=float(np.max(finite_high)),
                low=float(np.min(finite_low)),
                close=series.at(close),
                bar_high=series.at(series.high_study),
                bar_low=series.at(series.low_study),
            )

        if icfg.candles:
            patterns = ind.candle_patterns(
                series.open, series.high, series.low, series.close
            )
            out.candles_available = ind.talib_available()
            out.candle_tags = [
                (
                    f"{ind.CANDLE_LABELS.get(name, name.lower())}"
                    f"{' (bull)' if sign > 0 else ' (bear)'}"
                )
                for name, sign in patterns.items()
            ]
        else:
            out.candles_available = False

    return out
