# TA Study — the Shternberg mean-reversion email

A scheduled job that, for each configured product and each horizon (weekly,
daily, 4h, 1h), computes the Shternberg study — **RSI divergence** as the
primary signal, a **stochastic %K/%D cross in zone** as lagging confirmation,
and **ADX as a momentum-regime gate** — plus a standard set of secondary
indicators. It renders a five-panel chart per (product, horizon), classifies
each into a state, and emails a structured summary with the charts embedded as
CID inline images. Signal history and forward returns are persisted so hit
rates can be reported back into the email.

The mathematics is specified exactly in `SPEC.md` §8a. Every module that
implements a formula cites the sub-section it comes from.

## Quick start

Use the launcher. It pins the right interpreter and sets the console
encoding, and works from any directory:

```powershell
ta_study\run.bat --dry-run                        # writes ./output, sends nothing
ta_study\run.bat --to you@jainglobal.com          # sends it
ta_study\run.bat validate                         # check the config
ta_study\run.bat backfill --start 2026-01-01 --end 2026-09-17
```

Two traps it exists to avoid. The Windows `py` launcher **ignores
`conda activate`**, so `conda activate corelib; py -m ta_study.cli run`
runs on the system Python, which has neither `jain_commods` nor
`confluent_kafka`. And the console defaults to cp1252, so the `σ`, `—` and
state arrows in the report copy raise `UnicodeEncodeError`.

Point `TA_STUDY_PYTHON` at a different `python.exe` to override. To invoke
the module directly instead, use `python` (never `py`) inside an activated
`corelib` env, with `PYTHONIOENCODING=utf-8` set.

```bash
# validate the config and exit
python -m ta_study.cli validate

# full run, writing HTML + charts to ./output and sending nothing
python -m ta_study.cli run --dry-run

# one product, one horizon, human-readable logs
python -m ta_study.cli run --dry-run --product TTF --horizon D --plain-logs

# replay state over a date range using only the bars available on each date
python -m ta_study.cli backfill --start 2026-01-01 --end 2026-09-17

# score events whose forward horizon has elapsed, and report hit rates
python -m ta_study.cli stats
```

Tests: `python -m pytest ta_study/tests -q` (285 tests, no Bloomberg needed).

## How the signal works

For two successive confirmed swing highs `t1 < t2`:

```
ΔP = P(t2) − P(t1)        ΔR = RSI(t2) − RSI(t1)

bearish regular   ΔP > 0  and  ΔR < −δ      price higher, RSI lower
bullish regular   ΔP < 0  and  ΔR > +δ      price lower,  RSI higher
```

plus a zone filter (`RSI(t1) ≥ 60` for bearish, `≤ 40` for bullish) and a
separation requirement `5 ≤ t2 − t1 ≤ 60` bars. The direction is
`d = −sign(ΔP)`.

Economically this is **decaying marginal momentum**: price makes progress while
participation falls, which reads as late, forced or automated flow and carries
an elevated probability of mean reversion.

At bar `t`, for the most recent divergence with `t* ≤ t ≤ t* + W_a`:

```
s_t = d
c_t = 1[a %K/%D cross in zone occurred in [t*, t* + W_c]]
G_t = 1[ADX_t ≥ θ  and  ADX_t > ADX_{t−r}]
κ_t = σ · (λ_u + (1 − λ_u)·c_t) · (1 − (1 − λ_g)·G_t)
```

`s_t` is the directional bias, `κ_t ∈ [0, 1]` the suggested size multiplier.

### States

| State | Meaning |
| --- | --- |
| `DVG_ACTIVE` | divergence live, gate open, awaiting stochastic confirmation |
| `DVG_CONFIRMED` | a %K/%D cross in zone landed inside the window |
| `DVG_GATED` | ADX ≥ threshold and rising — momentum dominant, delay or size down |
| `DVG_GATE_RELEASING` | was gated; ADX has fallen back — actionable again |
| `DVG_EXPIRED` | aged past the active window without ever confirming |
| `PROVISIONAL` | an unconfirmed swing *would* form a divergence — informational only |
| `NONE` | nothing in the active window |

Cross-horizon alignment is `A_p = Σ_h s_t⁽ʰ⁾ · κ_t⁽ʰ⁾`; a weekly + daily + 4h
agreement is the email's headline item.

## The no-lookahead invariant

A swing at bar `i` cannot be known until bar `i + k`, because the `k` bars to
its right must exist before the window extremum is decided. Every swing carries
`confirmed_at = i + k`, and a divergence's trigger is `t* = t2 + k` — never
`t2`. The last `k` bars of any series can only hold *provisional* swings, which
are flagged, drawn dashed, and never generate a signal.

`tests/test_no_lookahead.py` asserts the invariant exhaustively: for every
prefix of the series and three swing widths, the event set computed on the
prefix equals the event set computed on the full series and filtered to
`t* ≤ t`. **If that test fails, every hit rate the email reports is inflated
by information that was not available on the day.**

## Layout

```
common/                 shared with vol_monitor
  bbg.py                HistoricalDataRequest + IntradayBarRequest, Parquet cache
  deliver.py            Graph sendMail / SMTP / kafka, CID inline images
  persist.py            generic Snowflake DDL / MERGE / SELECT helpers
  email_base.html.j2    Outlook-safe HTML shell

ta_study/
  config.py             pydantic models; every §8a parameter is a field
  data.py               horizon resampling, session alignment, roll handling
  indicators.py         numpy kernels to TA-Lib parity (RSI, STOCH, DMI, …)
  reference.py          TA-Lib / pandas-ta / pandas backends, for parity tests
  swings.py             swing detection with confirmation times
  divergence.py         the divergence engine and strength score
  study.py              the composite state machine and alignment
  secondary.py          EMA stack, MA crosses, MACD, Bollinger, ranges, candles
  charts.py             mplfinance five-panel figures
  render.py             Jinja2 assembly, CID images, size enforcement
  stats.py              forward returns and hit rates
  store.py              the TA Snowflake tables plus a local state mirror
  pipeline.py           orchestration, backfill, forward-return fill
  dagster_defs.py       assets, jobs, schedules
  cli.py                command line
  config/ta_products.yaml
  templates/ta_email.html.j2
  tests/
```

`ta_study` may import from `eu_corelib` (`jain_commods`); `eu_corelib` must
never import from `eu_reports`.

## Implementation notes worth knowing

**Indicators are native numpy, not TA-Lib.** TA-Lib is not installed in the
`corelib` environment and is a C source build on Windows. Every recursion the
study needs is specified exactly in §8a, so `indicators.py` implements them
directly — matching TA-Lib to 1e-6 *including its warm-up lengths* (RSI first
value at index 14, ADX at 27, %K at 15, %D at 17, EMA at n−1, BBANDS at 19).
`tests/test_parity.py` checks this against an independent pandas
`rolling`/`ewm` implementation on every run, and against TA-Lib and pandas-ta
when either is installed (`pip install -e ".[ta-backends]"`).

One deliberate divergence from TA-Lib: on a dead-flat look-back window
(`HH == LL`) §8a E puts %K at the midpoint 50, where TA-Lib emits 0. The
parity test masks those bars.

**Intraday history has to be accumulated.** Bloomberg retains about 140 days
of intraday bars, so `TA.INTRADAY_BARS` is read first and topped up from
Bloomberg each run. Until `persist.enabled` is true, the 4h and 1h horizons
are limited to Bloomberg's own window. To ship weekly + daily first, set
`enabled: false` on the `4H` and `1H` horizons in `ta_products.yaml`.

**4h bins are anchored on the exchange session, on a fixed instant.** A grid
anchored on midnight splits the European power and gas session in the wrong
places. Deriving each bar's offset from its own local wall-clock time looks
equivalent but is not: across a daylight-saving change the local clock jumps
and bin labels run *backwards*, so a bin ends up holding bars that printed
after it. `session_anchor` fixes the grid origin instead, which keeps bins
uniform, monotonic and a true partition; the price is that local bin labels
shift by an hour after a DST change, as they do in Bloomberg.

**Rolls are handled twice.** For the momentum indicators the series is
multiplicatively back-adjusted so a contract gap never enters RSI or ADX; for
display the unadjusted bars are kept and the roll is marked with a faint
vertical line. The adjustment is anchored at the most recent bar, so the last
close on the chart is a traded price. Where a product has no true open
(`PX_LAST` only) the gap and the day's real move cannot be separated, and the
roll bar's adjusted return collapses to zero — the same information loss as
`roll_method: drop`.

**`STUDY_STATE` is keyed on the run *date*, not the run timestamp.** §12
describes `(run_ts, product, horizon)`, but a MERGE on a wall-clock timestamp
can never match an existing row, so a rerun would append rather than replace.
`RUN_TS` is kept as a column; the key is `(RUN_DATE, PRODUCT, HORIZON)`, which
makes `--date` reruns genuinely idempotent as §15 requires.

**Delivery defaults to the kafka relay**, because it is the only transport
configured on this desk (no `GRAPH_*` credentials in
`eu_commods_pipelines/.env`, no SMTP host). The relay has no MIME
multipart, so the `cid:` references are rewritten into base64 `data:` URIs in
the body at send time — the same thing `ccgt_power_stack` and
`china_summary` already do through the same relay. A live send measures
3.8 MB against the relay's 15 MB message limit, which the producer is sized
for automatically.

Switch to `transport: graph` once `delivery.graph_tenant_id`,
`delivery.graph_client_id` and `$GRAPH_CLIENT_SECRET` exist. CID inline parts
are the better encoding — locked-down Outlook builds can block `data:` URIs,
and CID keeps the body about 25% smaller — and Graph falls back to SMTP on
failure. Nothing else changes: the HTML is built once with `cid:` references
either way.

**The email shows one chart per product, a column per frequency.** Reading
the frequencies against each other is the point of the study — a weekly and
a daily divergence pointing the same way is the headline signal — and that
comparison is impossible when each (product, horizon) sits in its own
section. Each column carries the price, RSI, stochastic and ADX rows, so the
divergence line appears on price and RSI side by side. The layout is
generic: enable three horizons and it is a 1×3.

Columns run **fastest first** (1H → 4H → D → W), so the eye travels from the
trade's own time frame out to its context. `run.horizon_order` switches this
to `coarse_to_fine` or `config`, and the same ordering drives the signal
grid, so the two halves of the email cannot disagree about which column is
which.

Above the charts is a **"How to read these charts"** legend: one row per
panel giving what it measures and what to look for, with colour swatches
taken from `ta_study.charts` itself so a swatch can never drift from the
line it describes, plus a short "putting it together" reading order
(is the move tiring? → is it safe to fade? → has the turn started?).

**Captions and state names are written for a reader, not a quant.** The
internal identifiers — `DVG_GATE_RELEASING` and friends — are what the spec
names and what `STUDY_STATE` persists, so they never change; the email shows
`config.STATE_LABELS` instead:

| Internal | Shown | Means |
| --- | --- | --- |
| `DVG_CONFIRMED` | CONFIRMED | the turn has started |
| `DVG_ACTIVE` | SETUP | split in place, waiting for the turn |
| `DVG_GATED` | ON HOLD 🔒 | trend too strong to fade yet |
| `DVG_GATE_RELEASING` | CLEARED | trend stopped strengthening |
| `DVG_EXPIRED` | FADED | aged out without the turn |
| `PROVISIONAL` | FORMING | may become a setup |

Each caption is four plain sentences: what happened, where it stands and
what has to happen next, how confident and how big, and the track record.
Nothing in them is symbolic — no `σ`, no `×0.26`, no `%K/%D` without
explanation.

Two consequences worth knowing:

* Only the last `run.product_chart_bars` (140) bars are *drawn*. The study
  still computes on the full 300–400 bar window; 400 candles in a 620 px
  column is an unreadable smear, and 140 bars comfortably contains any live
  divergence, since the two swings sit within `max_lookback_bars` (60) of
  each other and the trigger is recent by construction.
* The email body is 1180 px rather than the usual ~1000. At 1000 px a
  four-column chart scales each frequency down to about 235 px, which loses
  the candles.

`full_chart` (a single five-panel chart for one product × horizon) and the
per-cell thumbnail strip both still exist — the strip behind
`run.include_thumbnail_strip`, off by default — but the email uses the
combined charts.

**Measured chart throughput** (this machine, `chart_workers: 4`): six
combined four-column charts render in 3.3 s, and a full live run is about
4 s warm / 23 s cold for 24 (product, horizon) pairs. The §15 end-to-end
budget of 5 minutes for 15 products × 4 horizons is therefore dominated by
Bloomberg latency, not by charting.

**Charts are dropped, never silently missing.** If the message would exceed
`run.max_email_mb`, the thumbnail strip goes first, then full charts in
*ascending strength order*. Everything dropped is named in the appendix.

## Snowflake tables

`RISK.TA` (created on first run when `persist.enabled` is true):

| Table | Key | Contents |
| --- | --- | --- |
| `STUDY_STATE` | `(RUN_DATE, PRODUCT, HORIZON)` | state, direction, strength, every indicator value, S1/S2 timestamps |
| `DIVERGENCE_EVENTS` | `(PRODUCT, HORIZON, TRIGGERED_TS)` | one row per emitted divergence; forward returns at +5/+10/+20 bars in % and ATR, plus `CONFIRMED`/`GATED` *as at the trigger* |
| `MA_CROSS_EVENTS` | `(PRODUCT, HORIZON, CROSS_TS, PAIR)` | same pattern for EMA crossovers |
| `INTRADAY_BARS` | `(TICKER, INTERVAL_MIN, TS)` | persisted 1h bars; 4h is derived from these |

A hit rate is only displayed at or above `stats.min_sample` (20) observations;
below that the email prints `n=…, insufficient` rather than a number the desk
might act on.

## Orchestration

```
ta_study_bars_daily ┐
ta_study_bars_intraday ┴→ ta_study_email        55 6 * * 1-5  Europe/London
ta_study_forward_returns                        30 22 * * 1-5 Europe/London
```

To register with the repo-level Dagster instance, add to the root
`dagster_defs.py`:

```python
from ta_study.dagster_defs import ta_study_assets, ta_study_jobs, ta_study_schedules
```

and extend `_assets` / `_jobs` / `_schedules`. Schedules come up `STOPPED`
unless `DAGSTER_ENV=production`, and `EMAIL_DRY_RUN` / `EMAIL_OVERRIDE` guard
against a local run mailing the desk.

## Two open design decisions

1. **Hidden (continuation) divergences** are implemented but default to off.
   The study as described covers regular divergences only, and mixing the two
   into one state machine would make the hit rates uninterpretable. Set
   `divergence.include_hidden: true` to enable; they are tagged separately
   throughout.
2. **The 4h and 1h horizons** carry the intraday-persistence overhead above.
   Weekly + daily alone would ship immediately and cover most of the value;
   both intraday horizons are implemented and enabled, and can be turned off
   per horizon or per product (`skip_horizons`) without touching code.
