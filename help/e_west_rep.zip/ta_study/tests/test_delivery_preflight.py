"""Transport preflight and the eu_corelib bootstrap.

Both exist because of one real failure: ``conda activate corelib`` followed
by ``py -m ta_study.cli run`` runs on the system Python (the Windows
launcher ignores conda), fetched every product's bars, rendered 30 charts,
and only then died on ``No module named 'jain_commods'``.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass

import pytest

from common.corelib import (
    CORELIB_DIR_NAME,
    CORELIB_PATH_ENV,
    corelib_candidates,
    ensure_corelib_on_path,
    jain_commods_available,
)
from common.deliver import DeliveryError, preflight


@dataclass
class FakeDelivery:
    """Structurally satisfies DeliverySettings."""

    transport: str = "kafka"
    sender: str = "x@y.com"
    graph_tenant_id: str | None = None
    graph_client_id: str | None = None
    graph_client_secret_env: str = "GRAPH_CLIENT_SECRET"
    smtp_host: str | None = None
    smtp_port: int = 25
    smtp_use_tls: bool = False
    smtp_user: str | None = None
    smtp_password_env: str = "SMTP_PASSWORD"


# ---------------------------------------------------------------------------
# preflight
# ---------------------------------------------------------------------------
def test_kafka_passes_when_the_relay_is_importable() -> None:
    pytest.importorskip("confluent_kafka")
    preflight(FakeDelivery(transport="kafka"))


def test_graph_without_credentials_or_smtp_is_rejected() -> None:
    with pytest.raises(DeliveryError, match="graph_tenant_id"):
        preflight(FakeDelivery(transport="graph"))


def test_graph_without_credentials_is_allowed_when_smtp_can_catch_it() -> None:
    """Graph falls back to SMTP, so a host makes the missing creds survivable."""
    preflight(FakeDelivery(transport="graph", smtp_host="mail.internal"))


def test_graph_names_every_missing_setting(monkeypatch) -> None:
    monkeypatch.delenv("GRAPH_CLIENT_SECRET", raising=False)
    with pytest.raises(DeliveryError) as exc:
        preflight(FakeDelivery(transport="graph", graph_tenant_id="t"))
    message = str(exc.value)
    assert "graph_client_id" in message
    assert "$GRAPH_CLIENT_SECRET" in message
    assert "graph_tenant_id" not in message  # this one was supplied


def test_graph_with_full_credentials_passes(monkeypatch) -> None:
    pytest.importorskip("msal")
    monkeypatch.setenv("GRAPH_CLIENT_SECRET", "secret")
    preflight(
        FakeDelivery(transport="graph", graph_tenant_id="t", graph_client_id="c")
    )


def test_smtp_without_a_host_is_rejected() -> None:
    with pytest.raises(DeliveryError, match="smtp_host"):
        preflight(FakeDelivery(transport="smtp"))


def test_smtp_with_a_host_passes() -> None:
    preflight(FakeDelivery(transport="smtp", smtp_host="mail.internal"))


def test_preflight_runs_before_any_work(tmp_path, monkeypatch) -> None:
    """A bad transport must fail without fetching bars or rendering charts."""
    import json

    import yaml

    from ta_study.config import (
        DeliveryConfig,
        HorizonConfig,
        PersistConfig,
        ProductConfig,
        RunConfig,
        StudyConfig,
    )
    from ta_study.pipeline import run_ta_study

    cfg = StudyConfig(
        run=RunConfig(recipients=["desk@example.com"], min_bars=60, chart_workers=0),
        horizons=[HorizonConfig(name="D", source="daily", bars=400)],
        products=[ProductConfig(name="TTF", ticker="T", group="gas")],
        persist=PersistConfig(enabled=False),
        # smtp with no host: guaranteed to fail preflight.
        delivery=DeliveryConfig(transport="smtp", smtp_host=None),
    )
    path = tmp_path / "cfg.yaml"
    path.write_text(
        yaml.safe_dump(json.loads(cfg.model_dump_json(by_alias=True))), encoding="utf-8"
    )

    def exploding_provider(_cfg, _as_of):
        raise AssertionError("bars were fetched despite a bad transport")

    with pytest.raises(DeliveryError, match="smtp_host"):
        run_ta_study(
            config_path=path,
            base_dir=tmp_path,
            bars_provider=exploding_provider,
        )


def test_dry_run_skips_the_preflight(tmp_path) -> None:
    """--dry-run never reaches the transport, so it must not be gated on it."""
    import datetime as dt
    import json

    import numpy as np
    import yaml

    from ta_study.config import (
        DeliveryConfig,
        HorizonConfig,
        PersistConfig,
        ProductConfig,
        RunConfig,
        StudyConfig,
    )
    from ta_study.pipeline import run_ta_study
    from ta_study.tests.conftest import bars_frame

    cfg = StudyConfig(
        run=RunConfig(recipients=["desk@example.com"], min_bars=60, chart_workers=0,
                      include_thumbnail_strip=False),
        horizons=[HorizonConfig(name="D", source="daily", bars=400)],
        products=[ProductConfig(name="TTF", ticker="T", group="gas")],
        persist=PersistConfig(enabled=False),
        delivery=DeliveryConfig(transport="smtp", smtp_host=None),
    )
    path = tmp_path / "cfg.yaml"
    path.write_text(
        yaml.safe_dump(json.loads(cfg.model_dump_json(by_alias=True))), encoding="utf-8"
    )

    close = np.linspace(100.0, 160.0, 220)
    bars = {"TTF": bars_frame(close)}
    result = run_ta_study(
        config_path=path,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        bars_provider=lambda _c, _d: (bars, {"TTF": bars_frame(close).clear()}),
    )
    assert result.sent_via is None
    assert result.html_path is not None and result.html_path.exists()


# ---------------------------------------------------------------------------
# corelib bootstrap
# ---------------------------------------------------------------------------
def test_env_var_takes_priority_over_the_sibling_directory(monkeypatch) -> None:
    monkeypatch.setenv(CORELIB_PATH_ENV, r"X:\somewhere\eu_corelib")
    candidates = corelib_candidates()
    assert str(candidates[0]).endswith("eu_corelib")
    assert "somewhere" in str(candidates[0])
    assert len(candidates) >= 2


def test_sibling_candidate_is_next_to_the_repo(monkeypatch) -> None:
    monkeypatch.delenv(CORELIB_PATH_ENV, raising=False)
    sibling = corelib_candidates()[0]
    assert sibling.name == CORELIB_DIR_NAME
    # <Projects>/eu_corelib, alongside <Projects>/eu_reports
    assert sibling.parent.name.lower() != "eu_reports"


def test_ensure_is_a_noop_when_already_importable() -> None:
    if not jain_commods_available():
        pytest.skip("jain_commods is not installed under this interpreter")
    before = list(sys.path)
    assert ensure_corelib_on_path() is None
    assert sys.path == before


def test_missing_checkout_raises_an_actionable_message(monkeypatch) -> None:
    """The message has to name the 'py' launcher trap; that was the bug."""
    monkeypatch.setattr("common.corelib.jain_commods_available", lambda: False)
    monkeypatch.setenv(CORELIB_PATH_ENV, r"X:\nope\eu_corelib")
    monkeypatch.setattr(
        "common.corelib.corelib_candidates",
        lambda: [__import__("pathlib").Path(r"X:\nope\eu_corelib")],
    )
    with pytest.raises(ModuleNotFoundError) as exc:
        ensure_corelib_on_path()
    message = str(exc.value)
    assert "conda activate" in message
    assert "py -m" in message
    assert CORELIB_PATH_ENV in message
