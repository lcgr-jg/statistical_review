"""Deployment wiring: registration, packaging and the Bloomberg session flag.

The container runs ``dagster code-server --python-file dagster_defs.py``
against the *repo root*. A code location that imports cleanly but forgets to
register its assets builds green and then simply never runs - which is the
worst kind of deployment failure, because nothing alerts.
"""

from __future__ import annotations

import ast
import tomllib
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
ROOT_DAGSTER_DEFS = REPO_ROOT / "dagster_defs.py"
PYPROJECT = REPO_ROOT / "pyproject.toml"


# ---------------------------------------------------------------------------
# root Dagster registration - this is what the container actually serves
# ---------------------------------------------------------------------------
def test_root_dagster_defs_parses() -> None:
    ast.parse(ROOT_DAGSTER_DEFS.read_text(encoding="utf-8"))


def test_root_registers_ta_study_assets_jobs_and_schedules() -> None:
    source = ROOT_DAGSTER_DEFS.read_text(encoding="utf-8")
    assert "from ta_study.dagster_defs import" in source
    assert "_assets.extend(ta_study_assets)" in source
    assert "_jobs.extend(ta_study_jobs)" in source
    assert "_schedules.extend(ta_study_schedules)" in source


def test_root_definitions_include_the_ta_study_keys() -> None:
    """Load the real Definitions object, not just the source text."""
    pytest.importorskip("dagster")
    import importlib.util
    import sys

    spec = importlib.util.spec_from_file_location(
        "_root_dagster_defs", ROOT_DAGSTER_DEFS
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["_root_dagster_defs"] = module
    try:
        spec.loader.exec_module(module)
    except Exception as exc:  # pragma: no cover - needs the full repo env
        pytest.skip(f"root dagster_defs needs the full environment: {exc}")
    finally:
        sys.modules.pop("_root_dagster_defs", None)

    assert getattr(module, "TA_STUDY_AVAILABLE", False), "ta_study failed to import"

    keys: set[str] = set()
    for asset_def in module.defs.assets:  # type: ignore[union-attr]
        keys |= {k.to_user_string() for k in asset_def.keys}
    assert {"ta_study_email", "ta_study_forward_returns"} <= keys

    job_names = {j.name for j in module.defs.jobs}  # type: ignore[union-attr]
    assert {"ta_study_job", "ta_study_stats_job"} <= job_names

    schedule_names = {s.name for s in module.defs.schedules}  # type: ignore[union-attr]
    assert {"ta_study_schedule", "ta_study_stats_schedule"} <= schedule_names


# ---------------------------------------------------------------------------
# packaging - `pip install -e .` inside the image must pick everything up
# ---------------------------------------------------------------------------
def _pyproject() -> dict:
    return tomllib.loads(PYPROJECT.read_text(encoding="utf-8"))


def test_new_packages_are_installed() -> None:
    include = _pyproject()["tool"]["setuptools"]["packages"]["find"]["include"]
    for pattern in ("common*", "ta_study*", "vol_monitor*"):
        assert pattern in include, f"{pattern} missing from packages.find"


def test_config_and_templates_ship_with_the_package() -> None:
    """Without package-data the container starts and cannot find its config."""
    data = _pyproject()["tool"]["setuptools"]["package-data"]
    assert "config/*.yaml" in data["ta_study"]
    assert "templates/*.j2" in data["ta_study"]
    assert "*.j2" in data["common"]


def test_runtime_dependencies_are_declared() -> None:
    """Anything imported at runtime must be installable in the image."""
    deps = " ".join(_pyproject()["project"]["dependencies"]).lower()
    for package in ("polars", "mplfinance", "jinja2", "pyyaml", "pydantic"):
        assert package in deps, f"{package} is imported but not declared"


def test_optional_backends_stay_optional() -> None:
    """TA-Lib must never become a hard dependency: it is a C source build."""
    deps = " ".join(_pyproject()["project"]["dependencies"]).lower()
    assert "ta-lib" not in deps
    assert "pandas-ta" not in deps
    extras = _pyproject()["project"]["optional-dependencies"]
    assert any("TA-Lib" in d for d in extras["ta-backends"])


# ---------------------------------------------------------------------------
# Bloomberg session selection
# ---------------------------------------------------------------------------
def test_defaults_to_bpipe(monkeypatch) -> None:
    """A container has no desktop Terminal, so B-PIPE is the only option."""
    from ta_study.config import load_config

    monkeypatch.delenv("BLOOMBERG_ON_SERVER", raising=False)
    cfg = load_config()
    assert cfg.run.bloomberg_on_server is True
    assert cfg.bloomberg_on_server is True


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("true", True), ("True", True), ("1", True), ("yes", True), ("on", True),
        ("false", False), ("False", False), ("0", False), ("no", False),
    ],
)
def test_env_var_overrides_the_yaml(monkeypatch, value: str, expected: bool) -> None:
    from ta_study.config import load_config

    monkeypatch.setenv("BLOOMBERG_ON_SERVER", value)
    assert load_config().bloomberg_on_server is expected


def test_blank_env_var_falls_back_to_the_yaml(monkeypatch) -> None:
    from ta_study.config import load_config

    monkeypatch.setenv("BLOOMBERG_ON_SERVER", "   ")
    assert load_config().bloomberg_on_server is True


def test_pipeline_reads_the_env_aware_property() -> None:
    """Call sites must not bypass the override by reading run.* directly."""
    for name in ("ta_study/pipeline.py", "ta_study/dagster_defs.py"):
        source = (REPO_ROOT / name).read_text(encoding="utf-8")
        assert "on_server=cfg.run.bloomberg_on_server" not in source, name
        assert "on_server=cfg.bloomberg_on_server" in source, name
