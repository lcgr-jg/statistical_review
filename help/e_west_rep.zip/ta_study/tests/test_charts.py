"""Chart geometry and rendering.

The spec asks for a golden-image test. Pixel comparison against a stored
reference is brittle across matplotlib, mplfinance and font versions - it
fails on an environment upgrade rather than on a regression - so the
geometric claim that actually matters is asserted directly and exactly:
**the divergence line endpoints land on the S1/S2 timestamps**, on both the
price and the RSI panel. Rendering itself is covered by smoke tests that
check a valid, non-trivial PNG comes back and that no figures are leaked.
"""

from __future__ import annotations

import matplotlib
import numpy as np
import pytest

matplotlib.use("Agg")

import matplotlib.pyplot as plt

from ta_study.charts import (
    FULL_SIZE_PX,
    STATE_COLOURS,
    THUMB_SIZE_PX,
    _contiguous_spans,
    build_style,
    divergence_line,
    full_chart,
    render_charts,
    thumbnail,
)
from ta_study.study import run_study
from ta_study.tests.conftest import bars_frame, bearish_divergence_close

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


@pytest.fixture
def result(cfg):
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    return run_study(bars_frame(close), cfg, "TEST", "D")


@pytest.fixture
def live_result(cfg):
    """Truncated so the final state is live and a divergence line is drawn."""
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    full = run_study(bars_frame(close), cfg, "TEST", "D")
    cut = full.events[-1].triggered_at + 3
    return run_study(bars_frame(close[: cut + 1]), cfg, "TEST", "D")


# ---------------------------------------------------------------------------
# the geometric claim
# ---------------------------------------------------------------------------
def test_divergence_line_endpoints_land_on_s1_and_s2(live_result, cfg) -> None:
    event = live_result.event
    assert event is not None
    series = live_result.series
    line = divergence_line(event, series, cfg.divergence.swing_price)
    assert line is not None

    # Bar-index coordinates match the swings exactly.
    assert line.x == (event.s1.bar_idx, event.s2.bar_idx)
    # And so do the timestamps those bars carry.
    assert line.ts == (event.s1.ts, event.s2.ts)
    assert line.ts[0] == series.ts[event.s1.bar_idx]
    assert line.ts[1] == series.ts[event.s2.bar_idx]


def test_line_rsi_endpoints_come_from_the_same_bars(live_result, cfg) -> None:
    event = live_result.event
    series = live_result.series
    line = divergence_line(event, series, cfg.divergence.swing_price)
    assert line.rsi[0] == pytest.approx(series.rsi[event.s1.bar_idx])
    assert line.rsi[1] == pytest.approx(series.rsi[event.s2.bar_idx])
    # The whole point: price rises while RSI falls.
    assert line.price[1] > line.price[0]
    assert line.rsi[1] < line.rsi[0]


def test_line_price_is_anchored_to_the_unadjusted_bars(cfg) -> None:
    """The study runs on adjusted prices; the chart shows traded ones."""
    from ta_study.data import apply_roll_adjustment

    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    bars = apply_roll_adjustment(bars_frame(close, roll_bars=(90,)), "backadjust")
    full = run_study(bars, cfg, "TEST", "D")
    if not full.events:
        pytest.skip("roll adjustment removed the fixture's divergence")

    event = full.events[-1]
    line = divergence_line(event, full.series, cfg.divergence.swing_price)
    assert line.price[0] == pytest.approx(full.series.close[event.s1.bar_idx])
    assert line.price[1] == pytest.approx(full.series.close[event.s2.bar_idx])


def test_provisional_lines_are_dashed_and_faded(live_result, cfg) -> None:
    event = live_result.event
    line = divergence_line(event, live_result.series, cfg.divergence.swing_price)
    assert not line.dashed
    assert line.alpha == 1.0
    assert line.linestyle == "-"

    from dataclasses import replace

    prov = replace(event, provisional=True)
    prov_line = divergence_line(prov, live_result.series, cfg.divergence.swing_price)
    assert prov_line.dashed
    assert prov_line.alpha == 0.5
    assert prov_line.linestyle == "--"


def test_bearish_and_bullish_lines_use_distinct_colours(live_result, cfg) -> None:
    from dataclasses import replace

    event = live_result.event
    bear = divergence_line(event, live_result.series, cfg.divergence.swing_price)
    bull = divergence_line(
        replace(event, kind="BULL"), live_result.series, cfg.divergence.swing_price
    )
    assert bear.colour != bull.colour


def test_line_is_none_when_a_swing_falls_outside_the_window(live_result, cfg) -> None:
    from dataclasses import replace

    from ta_study.swings import Swing

    event = live_result.event
    far = replace(
        event,
        s1=Swing(10_000, "H", 100.0, 70.0, 10_005, False),
    )
    assert divergence_line(far, live_result.series, cfg.divergence.swing_price) is None


# ---------------------------------------------------------------------------
# gate shading spans
# ---------------------------------------------------------------------------
def test_contiguous_spans_finds_inclusive_ranges() -> None:
    flags = np.array([False, True, True, False, True, False])
    assert _contiguous_spans(flags) == [(1, 2), (4, 4)]


def test_contiguous_spans_handles_a_run_to_the_end() -> None:
    flags = np.array([False, True, True])
    assert _contiguous_spans(flags) == [(1, 2)]


def test_contiguous_spans_on_all_false_and_all_true() -> None:
    assert _contiguous_spans(np.zeros(5, dtype=bool)) == []
    assert _contiguous_spans(np.ones(3, dtype=bool)) == [(0, 2)]


# ---------------------------------------------------------------------------
# rendering
# ---------------------------------------------------------------------------
def test_full_chart_returns_a_valid_png(live_result, cfg) -> None:
    png = full_chart(live_result, cfg)
    assert png.startswith(PNG_MAGIC)
    # A five-panel 1600x1100 chart is never trivially small.
    assert len(png) > 20_000


def test_thumbnail_is_smaller_than_the_full_chart(live_result, cfg) -> None:
    full = full_chart(live_result, cfg)
    thumb = thumbnail(live_result, cfg)
    assert thumb.startswith(PNG_MAGIC)
    assert len(thumb) < len(full)


def test_chart_dimensions_come_from_the_module_constants(live_result, cfg) -> None:
    import io

    from PIL import Image

    png = full_chart(live_result, cfg)
    width, height = Image.open(io.BytesIO(png)).size
    # bbox_inches="tight" trims whitespace, so allow generous slack.
    assert abs(width - FULL_SIZE_PX[0]) < FULL_SIZE_PX[0] * 0.15
    assert abs(height - FULL_SIZE_PX[1]) < FULL_SIZE_PX[1] * 0.15


def test_rendering_does_not_leak_figures(live_result, cfg) -> None:
    """Every figure must be closed, or a 60-chart run exhausts memory."""
    plt.close("all")
    before = len(plt.get_fignums())
    for _ in range(3):
        full_chart(live_result, cfg)
        thumbnail(live_result, cfg)
    assert len(plt.get_fignums()) == before


def test_placeholder_for_a_series_with_no_bars(cfg) -> None:
    close = np.linspace(100.0, 110.0, 30)  # under run.min_bars
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    png = full_chart(result, cfg)
    assert png.startswith(PNG_MAGIC)


def test_render_charts_keys_by_product_horizon_kind(live_result, cfg) -> None:
    out = render_charts([(live_result, "full"), (live_result, "thumb")], cfg, workers=0)
    assert set(out) == {("TEST", "D", "full"), ("TEST", "D", "thumb")}
    assert all(v.startswith(PNG_MAGIC) for v in out.values())


def test_render_charts_on_an_empty_job_list(cfg) -> None:
    assert render_charts([], cfg, workers=0) == {}


def test_a_failing_chart_yields_empty_bytes_not_an_exception(live_result, cfg) -> None:
    """One bad chart must degrade the email, never cancel it."""
    from dataclasses import replace

    broken = replace(live_result, series=None, n_bars=0)
    broken.swings = []
    out = render_charts([(broken, "full")], cfg, workers=0)
    assert ("TEST", "D", "full") in out


def test_style_is_constructible() -> None:
    style = build_style()
    assert isinstance(style, dict)
    assert "marketcolors" in style


def test_every_state_has_a_badge_colour() -> None:
    from ta_study.config import LIVE_STATES

    for state in (*LIVE_STATES, "NONE", "DVG_EXPIRED", "PROVISIONAL", "MA_CROSS_NEW"):
        assert state in STATE_COLOURS


def test_thumbnail_size_constant_is_smaller_than_full() -> None:
    assert THUMB_SIZE_PX[0] < FULL_SIZE_PX[0]
    assert THUMB_SIZE_PX[1] < FULL_SIZE_PX[1]
