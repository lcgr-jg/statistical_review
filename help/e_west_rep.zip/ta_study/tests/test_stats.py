"""Forward returns, hit rates and the minimum-sample rule (§12, §8a H)."""

from __future__ import annotations

import numpy as np
import pytest

from ta_study.config import StatsConfig
from ta_study.stats import (
    EventRecord,
    ForwardReturn,
    HitRateIndex,
    event_records,
    forward_return,
    hit_rates,
    hypothesis_check,
)
from ta_study.study import run_study
from ta_study.tests.conftest import bars_frame, bearish_divergence_close


# ---------------------------------------------------------------------------
# forward returns
# ---------------------------------------------------------------------------
def test_forward_return_signs_against_the_direction() -> None:
    close = np.array([100.0, 101.0, 102.0, 103.0, 104.0, 105.0])
    atr = np.full(6, 1.0)

    # Long bias into a rising market -> a hit.
    long_ret = forward_return(close, atr, trigger_bar=0, bars=5, direction=1)
    assert long_ret.pct == pytest.approx(0.05)
    assert long_ret.signed_pct == pytest.approx(0.05)
    assert long_ret.atr_units == pytest.approx(5.0)
    assert long_ret.hit is True

    # Short bias into the same market -> a miss.
    short_ret = forward_return(close, atr, trigger_bar=0, bars=5, direction=-1)
    assert short_ret.signed_pct == pytest.approx(-0.05)
    assert short_ret.hit is False


def test_forward_return_is_null_before_the_horizon_elapses() -> None:
    close = np.array([100.0, 101.0, 102.0])
    atr = np.full(3, 1.0)
    ret = forward_return(close, atr, trigger_bar=0, bars=10, direction=1)
    assert not ret.elapsed
    assert ret.pct is None and ret.hit is None


def test_forward_return_is_null_on_a_missing_anchor() -> None:
    close = np.array([np.nan, 101.0, 102.0])
    atr = np.full(3, 1.0)
    assert not forward_return(close, atr, 0, 2, 1).elapsed


def test_atr_units_are_null_without_an_atr() -> None:
    close = np.array([100.0, 105.0, 110.0])
    atr = np.array([np.nan, np.nan, np.nan])
    ret = forward_return(close, atr, 0, 2, 1)
    assert ret.pct is not None
    assert ret.atr_units is None
    assert ret.signed_atr is None


# ---------------------------------------------------------------------------
# event records
# ---------------------------------------------------------------------------
def test_event_records_capture_the_state_at_the_trigger(cfg) -> None:
    """§8a H conditions on the gate *at the trigger*, not today."""
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    records = event_records(result, cfg)

    assert records, "the fixture must produce at least one event"
    for record in records:
        assert record.product == "TEST"
        assert record.horizon == "D"
        assert record.direction in (-1, 1)
        assert set(record.returns) == set(cfg.stats.forward_bars)
        assert isinstance(record.confirmed, bool)
        assert isinstance(record.gated, bool)
        if record.confirmation_lag is not None:
            assert record.confirmation_lag >= 0


def test_event_records_empty_without_a_series(cfg) -> None:
    close = np.linspace(100.0, 110.0, 30)
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    assert event_records(result, cfg) == []


# ---------------------------------------------------------------------------
# hit rates and the minimum-sample rule
# ---------------------------------------------------------------------------
def _record(
    direction: int,
    signed_pct: float,
    confirmed: bool = False,
    gated: bool = False,
    product: str = "TTF",
    horizon: str = "D",
) -> EventRecord:
    record = EventRecord(
        product=product,
        horizon=horizon,
        triggered_ts=None,
        s1_ts=None,
        s2_ts=None,
        kind="BEAR" if direction < 0 else "BULL",
        hidden=False,
        direction=direction,
        strength=0.5,
        strength_rsi=0.5,
        strength_price=0.5,
        strength_zone=0.5,
        d_price=1.0,
        d_rsi=-5.0,
        confirmed=confirmed,
        gated=gated,
        confirmation_lag=1 if confirmed else None,
        trigger_close=100.0,
        trigger_atr=1.0,
    )
    record.returns[10] = ForwardReturn(
        bars=10,
        pct=abs(signed_pct),
        atr_units=abs(signed_pct) * 100,
        signed_pct=signed_pct,
        signed_atr=signed_pct * 100,
    )
    return record


def test_hit_rate_counts_only_moves_in_the_signal_direction() -> None:
    cfg = StatsConfig(min_sample=1)
    records = [_record(-1, 0.02), _record(-1, 0.01), _record(-1, -0.01), _record(-1, -0.02)]
    rates = hit_rates(records, cfg)
    assert len(rates) == 1
    assert rates[0].count == 4
    assert rates[0].hit_rate == pytest.approx(0.5)


def test_buckets_split_on_confirmed_and_gated() -> None:
    cfg = StatsConfig(min_sample=1)
    records = [
        _record(-1, 0.02, confirmed=True, gated=False),
        _record(-1, 0.02, confirmed=False, gated=False),
        _record(-1, 0.02, confirmed=False, gated=True),
    ]
    rates = hit_rates(records, cfg)
    assert len(rates) == 3
    assert {(r.confirmed, r.gated) for r in rates} == {
        (True, False),
        (False, False),
        (False, True),
    }


def test_unelapsed_returns_do_not_enter_a_bucket() -> None:
    cfg = StatsConfig(min_sample=1)
    record = _record(-1, 0.02)
    record.returns[10] = ForwardReturn(10, None, None, None, None)
    assert hit_rates([record], cfg) == []


def test_zero_sample_says_so_distinctly() -> None:
    """"no cases yet" and "too few cases" are different messages."""
    cfg = StatsConfig(min_sample=20)
    index = HitRateIndex([], cfg)
    assert "no comparable cases" in index.caption("X", "D", -1, False, False)


def test_one_case_is_singular() -> None:
    cfg = StatsConfig(min_sample=20)
    rate = hit_rates([_record(-1, 0.02)], cfg)[0]
    assert "only 1 comparable case " in rate.caption()


def test_below_min_sample_the_caption_refuses_to_quote_a_rate() -> None:
    cfg = StatsConfig(min_sample=20)
    rates = hit_rates([_record(-1, 0.02) for _ in range(5)], cfg)
    assert len(rates) == 1
    rate = rates[0]
    assert rate.count == 5
    assert not rate.sufficient
    caption = rate.caption()
    assert "only 5 comparable cases" in caption
    assert "too few to judge" in caption
    assert "%" not in caption, "a rate must not appear below min_sample"


def test_at_min_sample_the_rate_is_shown() -> None:
    cfg = StatsConfig(min_sample=20)
    rate = hit_rates([_record(-1, 0.02) for _ in range(20)], cfg)[0]
    assert rate.sufficient
    caption = rate.caption()
    assert "went the right way 100% of 20 times" in caption
    assert "averaging" in caption


def test_expectancy_is_the_mean_signed_atr_move() -> None:
    cfg = StatsConfig(min_sample=1)
    rate = hit_rates([_record(-1, 0.02), _record(-1, -0.01)], cfg)[0]
    assert rate.mean_atr == pytest.approx((2.0 + -1.0) / 2)
    assert rate.expectancy == rate.mean_atr


# ---------------------------------------------------------------------------
# caption lookup
# ---------------------------------------------------------------------------
def test_index_looks_up_the_exact_bucket() -> None:
    cfg = StatsConfig(min_sample=1)
    rates = hit_rates([_record(-1, 0.02, confirmed=True)], cfg)
    index = HitRateIndex(rates, cfg)
    assert index.lookup("TTF", "D", -1, True, False) is not None
    assert index.lookup("TTF", "D", -1, False, False) is None


def test_index_caption_says_so_when_there_is_no_history() -> None:
    index = HitRateIndex([], StatsConfig())
    caption = index.caption("TTF", "D", -1, False, False)
    assert "no comparable cases on record yet" in caption


def test_index_caption_names_the_forward_horizon() -> None:
    cfg = StatsConfig(min_sample=1, headline_forward_bars=10)
    index = HitRateIndex(hit_rates([_record(-1, 0.02)], cfg), cfg)
    caption = index.caption("TTF", "D", -1, False, False)
    assert caption.startswith("Track record over the next 10 bars:")


# ---------------------------------------------------------------------------
# the hypothesis check (§8a H)
# ---------------------------------------------------------------------------
def test_hypothesis_reports_whether_the_gate_helps() -> None:
    cfg = StatsConfig(min_sample=1)
    records = [_record(-1, 0.03, gated=False) for _ in range(10)]
    records += [_record(-1, -0.02, gated=True) for _ in range(10)]
    summary = hypothesis_check(hit_rates(records, cfg), cfg)

    assert summary["ungated"]["mean_atr"] > 0
    assert summary["gated"]["mean_atr"] < 0
    assert summary["hypothesis_holds"] is True
    assert summary["gate_helps"] is True


def test_hypothesis_holds_is_none_without_a_usable_sample() -> None:
    summary = hypothesis_check([], StatsConfig(min_sample=20))
    assert summary["hypothesis_holds"] is None
    assert summary["gate_helps"] is None
    assert summary["ungated"]["n"] == 0


def test_hypothesis_is_weighted_by_sample_size() -> None:
    """A 2-observation bucket must not outvote a 100-observation one."""
    cfg = StatsConfig(min_sample=1)
    big = [_record(-1, 0.02, product="A") for _ in range(100)]
    small = [_record(-1, -0.50, product="B") for _ in range(2)]
    summary = hypothesis_check(hit_rates(big + small, cfg), cfg)

    # Weighted: (2.0 * 100 + -50.0 * 2) / 102 = +0.98, not the -24.0 an
    # unweighted average of the two bucket means would give.
    assert summary["ungated"]["mean_atr"] == pytest.approx((2.0 * 100 - 50.0 * 2) / 102)
    assert summary["ungated"]["mean_atr"] > 0, "the large bucket should dominate"
    assert summary["ungated"]["n"] == 102


def test_config_rejects_a_headline_horizon_that_is_not_collected() -> None:
    with pytest.raises(ValueError, match="headline_forward_bars"):
        StatsConfig(forward_bars=(5, 10), headline_forward_bars=20)
