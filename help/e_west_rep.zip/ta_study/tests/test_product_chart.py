"""The combined per-product chart: one column per frequency (§10, revised).

The email shows one figure per product with the horizons side by side, rather
than a separate section per (product, horizon) - reading the frequencies
against each other is the point of the study, and that comparison is
impossible when each cell lives in its own section.
"""

from __future__ import annotations

import datetime as dt

import matplotlib
import numpy as np
import pytest

matplotlib.use("Agg")

import matplotlib.pyplot as plt

from ta_study.charts import (
    PRODUCT_CHART_BARS,
    PRODUCT_COL_WIDTH_PX,
    Window,
    _date_ticks,
    display_window,
    product_chart,
    render_product_charts,
)
from ta_study.config import (
    HorizonConfig,
    ProductConfig,
    RunConfig,
    StudyConfig,
)
from ta_study.study import run_study
from ta_study.tests.conftest import bars_frame

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


@pytest.fixture
def multi_cfg() -> StudyConfig:
    return StudyConfig(
        run=RunConfig(recipients=["x@y.com"], min_bars=60, chart_workers=0),
        horizons=[
            HorizonConfig(name="W", source="daily", resample="1W-FRI", bars=300),
            HorizonConfig(name="D", source="daily", bars=400),
            HorizonConfig(name="4H", source="intraday", interval_min=240, bars=400),
        ],
        products=[ProductConfig(name="TEST", ticker="T1", group="gas")],
    )


@pytest.fixture
def results(multi_cfg):
    """One study result per horizon, off the same synthetic series."""
    rng = np.random.default_rng(11)
    close = 100 + np.cumsum(rng.normal(0, 1, 320))
    out = []
    for horizon in multi_cfg.active_horizons:
        out.append(run_study(bars_frame(close), multi_cfg, "TEST", horizon.name))
    return out


# ---------------------------------------------------------------------------
# the display window
# ---------------------------------------------------------------------------
def test_window_maps_bar_indices_to_plot_positions() -> None:
    win = Window(start=260, n=140)
    assert win.stop == 400
    assert win.x(260) == 0
    assert win.x(399) == 139
    assert win.visible(260) and win.visible(399)
    assert not win.visible(259)
    assert not win.visible(400)


def test_window_slices_arrays_consistently() -> None:
    values = np.arange(400.0)
    win = Window(start=260, n=140)
    sliced = win.slice(values)
    assert sliced.size == 140
    assert sliced[win.x(300)] == pytest.approx(values[300])


def test_display_window_takes_the_tail(results) -> None:
    series = results[1].series  # the daily horizon, 320 bars
    win = display_window(series, 140)
    assert win.n == 140
    assert win.stop == series.n


def test_display_window_clamps_to_a_short_series(results) -> None:
    series = results[0].series  # weekly: far fewer bars
    win = display_window(series, 10_000)
    assert win.start == 0
    assert win.n == series.n


# ---------------------------------------------------------------------------
# date tick labels
# ---------------------------------------------------------------------------
def _stamps(days: float, count: int = 50) -> list[dt.datetime]:
    start = dt.datetime(2024, 1, 1)
    step = dt.timedelta(days=days / max(count - 1, 1))
    return [start + step * i for i in range(count)]


def test_long_spans_include_the_year() -> None:
    """Regression: 140 weekly bars read as 19 Jan / 06 Dec / 31 Oct / 18 Sep,
    which looks like the axis runs backwards without the year."""
    _, labels = _date_ticks(_stamps(days=1000))
    assert all(any(ch.isdigit() for ch in label) for label in labels)
    # "%b %y" -> e.g. "Jan 24"
    assert all(len(label.split()) == 2 for label in labels)
    assert labels[0] != labels[-1]


def test_medium_spans_use_day_and_month() -> None:
    _, labels = _date_ticks(_stamps(days=120))
    assert ":" not in " ".join(labels)
    assert labels[0][:2].isdigit()


def test_short_intraday_spans_include_the_clock() -> None:
    _, labels = _date_ticks(_stamps(days=2))
    assert any(":" in label for label in labels)


def test_ticks_span_the_window_and_are_in_range() -> None:
    stamps = _stamps(days=300, count=140)
    positions, labels = _date_ticks(stamps, count=4)
    assert len(positions) == len(labels)
    assert positions[0] == 0
    assert positions[-1] == len(stamps) - 1
    assert all(0 <= p < len(stamps) for p in positions)
    assert positions == sorted(positions)


def test_ticks_handle_a_degenerate_window() -> None:
    assert _date_ticks([]) == ([], [])
    positions, labels = _date_ticks(_stamps(days=1, count=1))
    assert len(positions) == len(labels) == 1


# ---------------------------------------------------------------------------
# rendering
# ---------------------------------------------------------------------------
def test_product_chart_renders_one_column_per_horizon(results, multi_cfg) -> None:
    import io

    from PIL import Image

    png = product_chart(results, multi_cfg)
    assert png.startswith(PNG_MAGIC)

    width, _ = Image.open(io.BytesIO(png)).size
    # Three columns, so roughly three column widths across (bbox_inches
    # trims, so allow slack).
    expected = PRODUCT_COL_WIDTH_PX * len(results)
    assert 0.6 * expected < width < 1.3 * expected


def test_more_horizons_makes_a_wider_chart(results, multi_cfg) -> None:
    import io

    from PIL import Image

    narrow = Image.open(io.BytesIO(product_chart(results[:1], multi_cfg))).size[0]
    wide = Image.open(io.BytesIO(product_chart(results, multi_cfg))).size[0]
    assert wide > narrow * 2


def test_single_horizon_is_allowed(results, multi_cfg) -> None:
    assert product_chart(results[:1], multi_cfg).startswith(PNG_MAGIC)


def test_no_horizons_is_rejected(multi_cfg) -> None:
    with pytest.raises(ValueError, match="at least one horizon"):
        product_chart([], multi_cfg)


def test_a_horizon_with_no_data_becomes_a_labelled_blank(results, multi_cfg) -> None:
    """A thin product must not take the whole product's chart down."""
    from dataclasses import replace

    broken = replace(results[0], series=None, n_bars=0)
    broken.swings = []
    png = product_chart([broken, results[1]], multi_cfg)
    assert png.startswith(PNG_MAGIC)


def test_rendering_does_not_leak_figures(results, multi_cfg) -> None:
    plt.close("all")
    before = len(plt.get_fignums())
    for _ in range(3):
        product_chart(results, multi_cfg)
    assert len(plt.get_fignums()) == before


def test_display_bars_limits_what_is_drawn_not_what_is_computed(
    results, multi_cfg
) -> None:
    """The study keeps its full window; only the view is trimmed."""
    daily = results[1]
    assert daily.n_bars > PRODUCT_CHART_BARS
    small = product_chart(results, multi_cfg, display_bars=40)
    big = product_chart(results, multi_cfg, display_bars=140)
    assert small.startswith(PNG_MAGIC) and big.startswith(PNG_MAGIC)
    # Same figure size, different content, so the byte counts differ.
    assert small != big
    # And the underlying result is untouched.
    assert daily.n_bars > PRODUCT_CHART_BARS


def test_display_bars_comes_from_config(results, multi_cfg) -> None:
    tweaked = multi_cfg.model_copy(
        update={"run": multi_cfg.run.model_copy(update={"product_chart_bars": 60})}
    )
    assert product_chart(results, tweaked).startswith(PNG_MAGIC)


# ---------------------------------------------------------------------------
# batch rendering
# ---------------------------------------------------------------------------
def test_render_product_charts_keys_by_product(results, multi_cfg) -> None:
    out = render_product_charts([("TEST", results)], multi_cfg, workers=0)
    assert set(out) == {"TEST"}
    assert out["TEST"].startswith(PNG_MAGIC)


def test_render_product_charts_on_an_empty_list(multi_cfg) -> None:
    assert render_product_charts([], multi_cfg, workers=0) == {}


def test_a_failing_product_chart_yields_empty_bytes(multi_cfg) -> None:
    out = render_product_charts([("TEST", [])], multi_cfg, workers=0)
    assert out["TEST"] == b""


# ---------------------------------------------------------------------------
# captions
# ---------------------------------------------------------------------------
def test_caption_block_is_empty_for_a_quiet_horizon(multi_cfg) -> None:
    from ta_study.render import caption_block

    close = np.linspace(100.0, 101.0, 200)  # flat: nothing to say
    result = run_study(bars_frame(close), multi_cfg, "TEST", "D")
    block = caption_block(result, None, multi_cfg, None)
    if result.state == "NONE":
        assert block.lines == []
        assert not block.live


def test_caption_block_carries_the_state_badge(results, multi_cfg) -> None:
    from ta_study.charts import STATE_COLOURS
    from ta_study.render import caption_block

    for result in results:
        block = caption_block(result, None, multi_cfg, None)
        assert block.colour == STATE_COLOURS.get(result.state, "#9e9e9e")
        assert block.state == result.state
        # The column header uses the horizon's display label.
        horizon = multi_cfg.horizon(result.horizon)
        assert block.horizon == (horizon.display if horizon else result.horizon)


def test_product_chart_ref_wraps_the_blocks(results, multi_cfg) -> None:
    from ta_study.render import caption_block, make_product_chart_ref

    blocks = [caption_block(r, None, multi_cfg, None) for r in results]
    ref = make_product_chart_ref("TEST", b"\x89PNG", blocks, display="Test Gas")
    assert ref is not None
    assert ref.kind == "product"
    assert ref.horizon == ""
    assert ref.title == "Test Gas"
    assert len(ref.blocks) == len(results)
    assert ref.label == "TEST"


def test_product_chart_ref_is_none_for_a_failed_render() -> None:
    from ta_study.render import make_product_chart_ref

    assert make_product_chart_ref("TEST", b"", []) is None


# ---------------------------------------------------------------------------
# column ordering
# ---------------------------------------------------------------------------
def test_columns_run_fastest_first(multi_cfg) -> None:
    assert [h.name for h in multi_cfg.active_horizons] == ["4H", "D", "W"]


def test_chart_columns_and_grid_share_one_order(tmp_path) -> None:
    """The two halves of the email must not disagree about column order."""
    import json

    import polars as pl
    import yaml

    from ta_study.config import PersistConfig
    from ta_study.pipeline import run_ta_study

    cfg = StudyConfig(
        run=RunConfig(
            recipients=["d@e.com"], min_bars=60, chart_workers=0,
            include_thumbnail_strip=False, horizon_order="fine_to_coarse",
        ),
        horizons=[
            HorizonConfig(name="W", source="daily", resample="1W-FRI", bars=300),
            HorizonConfig(name="D", source="daily", bars=400),
        ],
        products=[ProductConfig(name="AAA", ticker="A", group="gas")],
        persist=PersistConfig(enabled=False),
    )
    path = tmp_path / "cfg.yaml"
    path.write_text(
        yaml.safe_dump(json.loads(cfg.model_dump_json(by_alias=True))), encoding="utf-8"
    )

    rng = np.random.default_rng(9)
    bars = {"AAA": bars_frame(100 + np.cumsum(rng.normal(0, 1, 320)))}
    result = run_ta_study(
        config_path=path,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        bars_provider=lambda _c, _d: (bars, {"AAA": pl.DataFrame()}),
    )

    html = result.html_path.read_text(encoding="utf-8")
    # The grid header row lists the horizons; Daily must precede Weekly.
    header = html[html.index("Product"):]
    assert header.index(">D<") < header.index(">W<")


# ---------------------------------------------------------------------------
# end-to-end through the email
# ---------------------------------------------------------------------------
def test_email_carries_one_chart_per_product(tmp_path) -> None:
    import json

    import polars as pl
    import yaml

    from ta_study.config import PersistConfig
    from ta_study.pipeline import run_ta_study

    cfg = StudyConfig(
        run=RunConfig(
            recipients=["desk@example.com"], min_bars=60, chart_workers=0,
            include_thumbnail_strip=False,
        ),
        horizons=[
            HorizonConfig(name="W", source="daily", resample="1W-FRI", bars=300),
            HorizonConfig(name="D", source="daily", bars=400),
        ],
        products=[
            ProductConfig(name="AAA", ticker="A", group="gas"),
            ProductConfig(name="BBB", ticker="B", group="oil"),
        ],
        persist=PersistConfig(enabled=False),
    )
    path = tmp_path / "cfg.yaml"
    path.write_text(
        yaml.safe_dump(json.loads(cfg.model_dump_json(by_alias=True))), encoding="utf-8"
    )

    rng = np.random.default_rng(5)
    bars = {
        name: bars_frame(100 + np.cumsum(rng.normal(0, 1, 320)))
        for name in ("AAA", "BBB")
    }
    result = run_ta_study(
        config_path=path,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        bars_provider=lambda _c, _d: (bars, {n: pl.DataFrame() for n in bars}),
    )

    # Two products x two horizons studied, but only two charts.
    assert len(result.results) == 4
    assert result.html_path is not None

    html = result.html_path.read_text(encoding="utf-8")
    assert "How to read these charts" in html
    assert "Putting it together" in html
    assert html.count("cid:") == 2, "one combined chart per product, not per cell"
    # new_content_id lowercases the stem, so the body carries the id, not the
    # filename.
    assert html.lower().count("-all-horizons.") == 2
    for product in ("AAA", "BBB"):
        assert f'alt="{product} chart"' in html
    # And no per-cell thumbnail strip.
    assert "All products × horizons" not in html
