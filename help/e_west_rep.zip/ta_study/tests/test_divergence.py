"""The divergence engine: §8a D, including the edge cases the spec names."""

from __future__ import annotations

import numpy as np
import pytest

from ta_study import indicators as ind
from ta_study.config import DivergenceConfig, RsiConfig, SignalConfig
from ta_study.divergence import (
    detect_divergences,
    detect_provisional,
    events_visible_at,
    latest_event,
    strength_score,
)
from ta_study.swings import Swing, detect_swings
from ta_study.tests.conftest import (
    bearish_divergence_close,
    bullish_divergence_close,
    moderate_bearish_divergence_close,
    same_slope_close,
)


def _run(
    close: np.ndarray,
    dcfg: DivergenceConfig | None = None,
    rsi_cfg: RsiConfig | None = None,
    signal: SignalConfig | None = None,
):
    dcfg = dcfg or DivergenceConfig()
    rsi_cfg = rsi_cfg or RsiConfig()
    signal = signal or SignalConfig()
    rsi = ind.rsi(close, rsi_cfg.period)
    atr = ind.atr(close + 0.5, close - 0.5, close, 14)
    swings = detect_swings(
        close, close, rsi, k=dcfg.swing_k, rsi_tolerance_bars=dcfg.rsi_tolerance_bars
    )
    return swings, detect_divergences(swings, atr, dcfg, rsi_cfg, signal), atr


# ---------------------------------------------------------------------------
# the headline cases from §14
# ---------------------------------------------------------------------------
def test_hand_built_bearish_emits_exactly_one_event_at_the_right_trigger() -> None:
    close = bearish_divergence_close()
    dcfg = DivergenceConfig()
    _, events, _ = _run(close, dcfg)

    assert len(events) == 1, [(e.kind, e.s1.bar_idx, e.s2.bar_idx) for e in events]
    event = events[0]
    assert event.kind == "BEAR"
    assert not event.hidden
    assert (event.s1.bar_idx, event.s2.bar_idx) == (20, 37)
    # t* = t2 + k, never t2 itself.
    assert event.triggered_at == 37 + dcfg.swing_k
    assert event.direction == -1
    assert event.d_price > 0      # higher high
    assert event.d_rsi < 0        # lower RSI high
    assert event.slope_price * event.slope_rsi < 0


def test_hand_built_bullish_mirrors_it() -> None:
    close = bullish_divergence_close()
    _, events, _ = _run(close)
    assert len(events) == 1
    event = events[0]
    assert event.kind == "BULL"
    assert event.direction == 1
    assert event.d_price < 0      # lower low
    assert event.d_rsi > 0        # higher RSI low


def test_same_slope_emits_nothing() -> None:
    """Price and RSI moving the same way is not a divergence."""
    close = same_slope_close()
    swings, events, _ = _run(close)
    highs = [s.bar_idx for s in swings if s.kind == "H" and not s.provisional]
    assert len(highs) >= 2, "fixture must produce two comparable highs"
    assert events == []


# ---------------------------------------------------------------------------
# separation and look-back
# ---------------------------------------------------------------------------
def test_separation_below_s_min_is_rejected() -> None:
    close = bearish_divergence_close()
    # The real separation is 17 bars; require 20.
    dcfg = DivergenceConfig(min_swing_separation=20)
    _, events, _ = _run(close, dcfg)
    assert events == []


def test_separation_above_l_max_is_rejected() -> None:
    close = bearish_divergence_close()
    dcfg = DivergenceConfig(max_lookback_bars=10)
    _, events, _ = _run(close, dcfg)
    assert events == []


def test_separation_boundaries_are_inclusive() -> None:
    close = bearish_divergence_close()
    span = 37 - 20
    assert _run(close, DivergenceConfig(min_swing_separation=span))[1]
    assert _run(close, DivergenceConfig(max_lookback_bars=span))[1]
    assert not _run(close, DivergenceConfig(min_swing_separation=span + 1))[1]
    assert not _run(close, DivergenceConfig(max_lookback_bars=span - 1))[1]


def test_only_the_immediately_prior_swing_is_paired() -> None:
    """§8a D pairs with ``max{t in H : t < t2}``, not the nearest *eligible*.

    If the immediately-prior high is too close, the engine emits nothing
    rather than reaching further back for a pair that would qualify.
    """
    close = bearish_divergence_close()
    _, events, _ = _run(close)
    for event in events:
        assert event.s2.bar_idx - event.s1.bar_idx == 17


# ---------------------------------------------------------------------------
# delta and the zone filter
# ---------------------------------------------------------------------------
def test_min_rsi_delta_is_enforced() -> None:
    close = bearish_divergence_close()
    _, events, _ = _run(close)
    actual = abs(events[0].d_rsi)
    assert not _run(close, DivergenceConfig(min_rsi_delta=actual + 1.0))[1]
    assert _run(close, DivergenceConfig(min_rsi_delta=actual - 1.0))[1]


def test_zone_filter_requires_the_first_swing_to_be_extended() -> None:
    """Uses the mid-range fixture: S1 at RSI 100 leaves no room to threshold."""
    close = moderate_bearish_divergence_close()
    rsi_s1 = _run(close)[1][0].s1.rsi
    assert 60.0 < rsi_s1 < 95.0, f"fixture S1 RSI must be mid-range, got {rsi_s1}"

    # ob_soft above S1's RSI -> the divergence is rejected as not extended.
    strict = RsiConfig(ob=99.0, os=30, ob_soft=rsi_s1 + 5.0, os_soft=40)
    assert not _run(close, DivergenceConfig(rsi_zone_filter=True), strict)[1]

    # ob_soft below it -> accepted.
    loose = RsiConfig(ob=99.0, os=30, ob_soft=rsi_s1 - 5.0, os_soft=40)
    assert _run(close, DivergenceConfig(rsi_zone_filter=True), loose)[1]

    # And with the filter off, the strict zones are irrelevant.
    assert _run(close, DivergenceConfig(rsi_zone_filter=False), strict)[1]


# ---------------------------------------------------------------------------
# hidden divergences
# ---------------------------------------------------------------------------
def _pair_of_swings(
    kind: str, p1: float, r1: float, p2: float, r2: float, span: int = 20
) -> list[Swing]:
    """Two confirmed swings with exactly the prices and RSIs asked for.

    Hand-built rather than reverse-engineered from a price path: a hidden
    divergence needs a lower high whose RSI is *higher*, which is fiddly to
    manufacture from a ramp and would make the assertion depend on the
    fixture rather than on the rule under test.
    """
    return [
        Swing(bar_idx=10, kind=kind, price=p1, rsi=r1, confirmed_at=15, provisional=False),
        Swing(
            bar_idx=10 + span,
            kind=kind,
            price=p2,
            rsi=r2,
            confirmed_at=15 + span,
            provisional=False,
        ),
    ]


def _events_from(swings: list[Swing], **kwargs) -> list:
    dcfg = DivergenceConfig(**kwargs)
    atr = np.full(60, 1.0)
    return detect_divergences(swings, atr, dcfg, RsiConfig(), SignalConfig())


def test_hidden_divergences_are_off_by_default() -> None:
    """A lower high with a higher RSI high is a hidden continuation signal."""
    swings = _pair_of_swings("H", p1=120.0, r1=70.0, p2=115.0, r2=80.0)
    assert _events_from(swings, rsi_zone_filter=False) == []
    enabled = _events_from(swings, rsi_zone_filter=False, include_hidden=True)
    assert len(enabled) == 1
    assert enabled[0].hidden


def test_hidden_direction_follows_the_swing_kind_not_the_price_slope() -> None:
    # Hidden on highs: dP < 0, dR > delta -> bearish continuation, d = -1,
    # even though -sign(m_P) would say +1.
    highs = _pair_of_swings("H", p1=120.0, r1=70.0, p2=115.0, r2=80.0)
    event = _events_from(highs, rsi_zone_filter=False, include_hidden=True)[0]
    assert event.kind == "BEAR"
    assert event.direction == -1
    assert event.slope_price < 0

    # Hidden on lows: dP > 0, dR < -delta -> bullish continuation, d = +1.
    lows = _pair_of_swings("L", p1=100.0, r1=30.0, p2=105.0, r2=20.0)
    event = _events_from(lows, rsi_zone_filter=False, include_hidden=True)[0]
    assert event.kind == "BULL"
    assert event.direction == 1
    assert event.slope_price > 0


def test_regular_direction_is_minus_sign_of_the_price_slope() -> None:
    bear = _pair_of_swings("H", p1=115.0, r1=75.0, p2=120.0, r2=65.0)
    event = _events_from(bear, rsi_zone_filter=False)[0]
    assert event.direction == -1 == -int(np.sign(event.slope_price))

    bull = _pair_of_swings("L", p1=105.0, r1=25.0, p2=100.0, r2=35.0)
    event = _events_from(bull, rsi_zone_filter=False)[0]
    assert event.direction == 1 == -int(np.sign(event.slope_price))


# ---------------------------------------------------------------------------
# strength score
# ---------------------------------------------------------------------------
def test_strength_is_bounded_and_weighted() -> None:
    signal = SignalConfig()
    sigma, parts = strength_score(
        d_rsi=-40.0, d_price=10.0, rsi_s1=100.0, atr_at_s2=1.0, signal=signal
    )
    assert parts == pytest.approx((1.0, 1.0, 1.0))
    assert sigma == pytest.approx(1.0)

    sigma, parts = strength_score(
        d_rsi=0.0, d_price=0.0, rsi_s1=50.0, atr_at_s2=1.0, signal=signal
    )
    assert sigma == pytest.approx(0.0)


def test_strength_price_component_is_zero_without_atr() -> None:
    """Never renormalise: a missing measurement must not look like strength."""
    signal = SignalConfig()
    _, parts = strength_score(-30.0, 10.0, 100.0, None, signal)
    assert parts[1] == 0.0
    _, parts = strength_score(-30.0, 10.0, 100.0, float("nan"), signal)
    assert parts[1] == 0.0


def test_strength_components_reconstruct_the_score() -> None:
    close = bearish_divergence_close()
    signal = SignalConfig()
    event = _run(close, signal=signal)[1][0]
    w = signal.strength_weights
    rebuilt = (
        w[0] * event.strength_rsi
        + w[1] * event.strength_price
        + w[2] * event.strength_zone
    )
    assert event.strength == pytest.approx(rebuilt)
    assert 0.0 <= event.strength <= 1.0


# ---------------------------------------------------------------------------
# visibility helpers
# ---------------------------------------------------------------------------
def test_events_visible_at_gates_on_the_trigger_bar() -> None:
    close = bearish_divergence_close()
    _, events, _ = _run(close)
    t_star = events[0].triggered_at
    assert events_visible_at(events, t_star - 1) == []
    assert len(events_visible_at(events, t_star)) == 1


def test_latest_event_picks_the_most_recent_trigger() -> None:
    close = bearish_divergence_close()
    _, events, _ = _run(close)
    t_star = events[0].triggered_at
    assert latest_event(events, t_star - 1) is None
    assert latest_event(events, len(close)) is events[0]


def test_provisional_divergences_are_flagged_and_separate() -> None:
    close = bullish_divergence_close()
    dcfg = DivergenceConfig(rsi_zone_filter=False)
    rsi = ind.rsi(close, 14)
    atr = ind.atr(close + 0.5, close - 0.5, close, 14)
    swings = detect_swings(close, close, rsi, k=dcfg.swing_k)

    confirmed = detect_divergences(swings, atr, dcfg, RsiConfig(), SignalConfig())
    provisional = detect_provisional(swings, atr, dcfg, RsiConfig(), SignalConfig())

    assert all(not e.provisional for e in confirmed)
    assert all(e.provisional for e in provisional)
    # Provisional events are never visible to the no-lookahead filter.
    assert events_visible_at(provisional, len(close) + 100) == []
