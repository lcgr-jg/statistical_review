"""Swing detection: window test, confirmation time, provisional swings, ties."""

from __future__ import annotations

import numpy as np
import pytest

from ta_study import indicators as ind
from ta_study.swings import (
    Swing,
    confirmed_swings,
    detect_swings,
    observable_swings,
    provisional_swings,
)
from ta_study.tests.conftest import bearish_divergence_close, ramp


def _swings(close: np.ndarray, k: int = 5, **kwargs) -> list[Swing]:
    rsi = ind.rsi(close, 14)
    return detect_swings(close, close, rsi, k=k, **kwargs)


def test_finds_the_hand_built_extrema() -> None:
    close = bearish_divergence_close()
    swings = _swings(close)
    highs = [s.bar_idx for s in confirmed_swings(swings, "H")]
    lows = [s.bar_idx for s in confirmed_swings(swings, "L")]
    assert highs == [20, 37]
    assert lows == [28]


def test_confirmed_at_is_k_bars_after_the_swing() -> None:
    """The invariant the whole backtest rests on."""
    close = bearish_divergence_close()
    for k in (3, 5, 8):
        for swing in _swings(close, k=k):
            assert swing.confirmed_at == swing.bar_idx + k


def test_a_swing_needs_a_full_window_on_both_sides() -> None:
    close = bearish_divergence_close()
    k = 5
    n = close.size
    for swing in confirmed_swings(_swings(close, k=k)):
        assert swing.bar_idx >= k
        assert swing.bar_idx <= n - 1 - k


def test_strict_inequality_against_immediate_neighbours() -> None:
    """A plateau is not a swing: the centre must beat both neighbours."""
    close = np.array(
        [1.0, 2.0, 3.0, 4.0, 5.0, 5.0, 5.0, 4.0, 3.0, 2.0, 1.0, 0.5, 0.4]
    )
    rsi = np.full(close.size, 50.0)
    swings = detect_swings(close, close, rsi, k=2, include_provisional=False)
    assert [s.bar_idx for s in swings if s.kind == "H"] == []


def test_tie_within_the_window_keeps_the_later_bar() -> None:
    """Two equal window maxima inside k bars collapse to the latest (§8a C)."""
    close = np.array([0.0, 1.0, 5.0, 2.0, 5.0, 1.0, 0.0, -1.0, -2.0])
    rsi = np.full(close.size, 50.0)
    swings = detect_swings(close, close, rsi, k=2, include_provisional=False)
    highs = [s.bar_idx for s in swings if s.kind == "H"]
    assert highs == [4], f"expected the later of the tied highs, got {highs}"


def test_provisional_swing_sits_in_the_final_k_bars() -> None:
    close = bearish_divergence_close()
    k = 5
    swings = _swings(close, k=k)
    prov = provisional_swings(swings)
    assert prov, "a monotone tail should leave a provisional extremum"
    for swing in prov:
        assert swing.bar_idx > close.size - 1 - k
        assert swing.confirmed_at > close.size - 1  # confirmation is in the future


def test_provisional_swings_can_be_suppressed() -> None:
    close = bearish_divergence_close()
    swings = detect_swings(
        close, close, ind.rsi(close, 14), k=5, include_provisional=False
    )
    assert provisional_swings(swings) == []


def test_at_most_one_provisional_swing_per_side() -> None:
    close = bearish_divergence_close()
    prov = provisional_swings(_swings(close))
    assert len([s for s in prov if s.kind == "H"]) <= 1
    assert len([s for s in prov if s.kind == "L"]) <= 1


def test_observable_at_gates_on_confirmed_at() -> None:
    close = bearish_divergence_close()
    swings = _swings(close)
    swing = confirmed_swings(swings, "H")[0]
    assert not swing.observable_at(swing.confirmed_at - 1)
    assert swing.observable_at(swing.confirmed_at)
    assert observable_swings(swings, swing.confirmed_at - 1) == []


def test_provisional_is_never_observable() -> None:
    close = bearish_divergence_close()
    for swing in provisional_swings(_swings(close)):
        assert not swing.observable_at(len(close) + 100)


def test_highlow_mode_uses_the_true_extremes() -> None:
    close = bearish_divergence_close()
    high = close + 2.0
    low = close - 2.0
    rsi = ind.rsi(close, 14)
    swings = detect_swings(high, low, rsi, k=5, include_provisional=False)
    for swing in swings:
        source = high if swing.is_high else low
        assert swing.price == pytest.approx(source[swing.bar_idx])


def test_rsi_tolerance_takes_the_extreme_nearby() -> None:
    close = bearish_divergence_close()
    rsi = ind.rsi(close, 14)
    tight = detect_swings(close, close, rsi, k=5, rsi_tolerance_bars=0)
    loose = detect_swings(close, close, rsi, k=5, rsi_tolerance_bars=3)
    tight_by_bar = {s.bar_idx: s for s in tight if s.kind == "H"}
    for swing in (s for s in loose if s.kind == "H"):
        # Highs take the max over the tolerance window, so it can only rise.
        assert swing.rsi >= tight_by_bar[swing.bar_idx].rsi - 1e-9


def test_rejects_mismatched_input_lengths() -> None:
    with pytest.raises(ValueError, match="length mismatch"):
        detect_swings(np.zeros(10), np.zeros(10), np.zeros(9), k=3)


def test_rejects_non_positive_k() -> None:
    with pytest.raises(ValueError, match="swing_k"):
        detect_swings(np.zeros(10), np.zeros(10), np.zeros(10), k=0)


def test_series_shorter_than_the_window_yields_nothing() -> None:
    close = np.array(ramp(100, 110, 6))
    swings = detect_swings(close, close, np.full(close.size, 50.0), k=5)
    assert confirmed_swings(swings) == []
