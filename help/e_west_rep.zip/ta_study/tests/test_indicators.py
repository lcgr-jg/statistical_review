"""Indicator kernels: warm-up lengths, recursions, degenerate inputs."""

from __future__ import annotations

import numpy as np
import pytest

from ta_study import indicators as ind
from ta_study.tests.conftest import bearish_divergence_close


def first_finite(values: np.ndarray) -> int | None:
    idx = np.flatnonzero(np.isfinite(values))
    return int(idx[0]) if idx.size else None


# ---------------------------------------------------------------------------
# warm-up lengths must match TA-Lib exactly, or a backend swap shifts signals
# ---------------------------------------------------------------------------
def test_rsi_warmup_and_range() -> None:
    close = bearish_divergence_close()
    rsi = ind.rsi(close, 14)
    assert first_finite(rsi) == 14
    finite = rsi[np.isfinite(rsi)]
    assert finite.min() >= 0.0
    assert finite.max() <= 100.0


def test_rsi_is_100_on_an_unbroken_run_of_gains() -> None:
    """Dbar == 0 must give 100, not a divide-by-zero NaN."""
    close = np.arange(100, 140, dtype=float)
    rsi = ind.rsi(close, 14)
    assert rsi[20] == pytest.approx(100.0)


def test_rsi_is_zero_on_an_unbroken_run_of_losses() -> None:
    close = np.arange(140, 100, -1, dtype=float)
    rsi = ind.rsi(close, 14)
    assert rsi[20] == pytest.approx(0.0)


def test_rsi_matches_vol_monitor_reference() -> None:
    """Cross-check against the independent Wilder RSI already in the repo."""
    from vol_monitor.signals import wilder_rsi

    close = bearish_divergence_close()
    mine = ind.rsi(close, 14)
    theirs = wilder_rsi(close, 14)
    both = np.isfinite(mine) & np.isfinite(theirs)
    assert both.sum() > 40
    assert np.allclose(mine[both], theirs[both], atol=1e-12)


def test_atr_warmup() -> None:
    close = bearish_divergence_close()
    atr = ind.atr(close + 0.5, close - 0.5, close, 14)
    assert first_finite(atr) == 14


def test_true_range_first_bar_is_nan() -> None:
    close = np.array([10.0, 11.0, 12.0])
    tr = ind.true_range(close + 1, close - 1, close)
    assert np.isnan(tr[0])
    # max(H-L, |H - C_prev|, |L - C_prev|) = max(2, 2, 0) = 2
    assert tr[1] == pytest.approx(2.0)


def test_adx_warmup_is_two_n_minus_one() -> None:
    close = bearish_divergence_close()
    dm = ind.dmi(close + 0.5, close - 0.5, close, 14)
    assert first_finite(dm.plus_di) == 14
    assert first_finite(dm.minus_di) == 14
    assert first_finite(dm.adx) == 27  # 2n - 1


def test_adx_is_bounded_and_non_directional() -> None:
    up = np.arange(100, 200, dtype=float)
    down = np.arange(200, 100, -1, dtype=float)
    adx_up = ind.dmi(up + 1, up - 1, up, 14).adx
    adx_down = ind.dmi(down + 1, down - 1, down, 14).adx
    for series in (adx_up, adx_down):
        finite = series[np.isfinite(series)]
        assert finite.min() >= 0.0
        assert finite.max() <= 100.0
    # Same trend magnitude, opposite sign -> same ADX.
    assert adx_up[-1] == pytest.approx(adx_down[-1], abs=1e-9)


def test_stoch_warmups() -> None:
    close = bearish_divergence_close()
    st = ind.stoch(close + 0.5, close - 0.5, close, 14, 3, 3)
    assert first_finite(st.k_raw) == 13       # k_period - 1
    assert first_finite(st.k) == 15           # + k_smooth - 1
    assert first_finite(st.d) == 17           # + d_period - 1


def test_stoch_flat_window_is_the_midpoint() -> None:
    """A dead-flat window has no range; §8a E puts %K at 50."""
    close = np.full(30, 100.0)
    st = ind.stoch(close, close, close, 14, 3, 3)
    assert st.k_raw[20] == pytest.approx(ind.STOCH_FLAT_VALUE)


def test_stoch_fast_variant_skips_the_smoothing() -> None:
    close = bearish_divergence_close()
    fast = ind.stoch(close + 0.5, close - 0.5, close, 14, 3, 3, fast=True)
    assert np.allclose(
        fast.k[np.isfinite(fast.k)], fast.k_raw[np.isfinite(fast.k_raw)]
    )


def test_ema_warmup_and_seed() -> None:
    close = np.arange(1, 51, dtype=float)
    e = ind.ema(close, 20)
    assert first_finite(e) == 19
    assert e[19] == pytest.approx(np.mean(close[:20]))


def test_bbands_warmup_uses_population_sigma() -> None:
    close = bearish_divergence_close()
    bands = ind.bbands(close, 20, 2.0)
    assert first_finite(bands.middle) == 19
    window = close[:20]
    expected = np.mean(window) + 2.0 * np.std(window, ddof=0)
    assert bands.upper[19] == pytest.approx(expected)


def test_macd_warmups() -> None:
    close = bearish_divergence_close()
    m = ind.macd(close, 12, 26, 9)
    assert first_finite(m.line) == 25         # slow - 1
    assert first_finite(m.signal) == 33       # + signal - 1
    assert np.allclose(
        m.hist[np.isfinite(m.hist)],
        (m.line - m.signal)[np.isfinite(m.hist)],
    )


# ---------------------------------------------------------------------------
# NaN handling - the bug class that silently blanks a whole panel
# ---------------------------------------------------------------------------
def test_sma_recovers_after_leading_nans() -> None:
    """A leading NaN must not poison every later window.

    %K is NaN for its first ``k_period - 1`` bars, and %K is the input to the
    %D average; a cumulative-sum SMA without NaN accounting would leave the
    entire stochastic panel empty.
    """
    values = np.concatenate([np.full(5, np.nan), np.arange(1, 21, dtype=float)])
    out = ind.sma(values, 3)
    assert np.all(np.isnan(out[:7]))
    assert out[7] == pytest.approx(np.mean([1.0, 2.0, 3.0]))
    assert np.isfinite(out[-1])


def test_wilder_smooth_holds_previous_value_through_a_nan() -> None:
    values = np.array([1.0, 1.0, 1.0, np.nan, 1.0])
    out = ind.wilder_smooth(values, 3)
    assert out[2] == pytest.approx(1.0)
    assert out[3] == pytest.approx(1.0)  # carried, not poisoned
    assert np.isfinite(out[4])


def test_kernels_return_all_nan_when_too_short() -> None:
    short = np.arange(5, dtype=float)
    assert np.all(np.isnan(ind.rsi(short, 14)))
    assert np.all(np.isnan(ind.ema(short, 20)))
    assert np.all(np.isnan(ind.sma(short, 20)))
    assert np.all(np.isnan(ind.dmi(short + 1, short - 1, short, 14).adx))


def test_empty_input_is_handled() -> None:
    empty = np.array([], dtype=float)
    assert ind.rsi(empty, 14).size == 0
    assert ind.ema(empty, 20).size == 0
    assert ind.stoch(empty, empty, empty, 14, 3, 3).k.size == 0


# ---------------------------------------------------------------------------
# cross events and the gate
# ---------------------------------------------------------------------------
def test_stoch_cross_requires_the_zone() -> None:
    # K crosses above D, but from 50 - well outside oversold.
    k = np.array([50.0, 60.0])
    d = np.array([55.0, 55.0])
    plus, minus = ind.stoch_crosses(k, d, ob=80, os=20)
    assert not plus.any()

    # Same cross, this time from below the oversold line.
    k = np.array([10.0, 30.0])
    d = np.array([20.0, 20.0])
    plus, minus = ind.stoch_crosses(k, d, ob=80, os=20)
    assert plus[1]
    assert not minus.any()


def test_stoch_bearish_cross_in_overbought() -> None:
    k = np.array([90.0, 70.0])
    d = np.array([85.0, 85.0])
    plus, minus = ind.stoch_crosses(k, d, ob=80, os=20)
    assert minus[1]
    assert not plus.any()


def test_adx_gate_needs_both_level_and_slope() -> None:
    # Above threshold but falling -> gate open.
    falling = np.array([40.0, 39.0, 38.0, 37.0, 36.0])
    assert not ind.adx_gate(falling, threshold=30, r=3).any()

    # Above threshold and rising -> gate closed.
    rising = np.array([31.0, 32.0, 33.0, 34.0, 35.0])
    gate = ind.adx_gate(rising, threshold=30, r=3)
    assert gate[3] and gate[4]

    # Rising but below threshold -> gate open.
    low = np.array([10.0, 12.0, 14.0, 16.0, 18.0])
    assert not ind.adx_gate(low, threshold=30, r=3).any()


def test_adx_falling_streak_needs_r_consecutive_declines() -> None:
    values = np.array([40.0, 39.0, 40.0, 39.0, 38.0, 37.0])
    streak = ind.adx_falling_streak(values, r=3)
    assert not streak[3]   # 40 -> 39 -> 38 not yet three declines
    assert streak[5]       # 40, 39, 38, 37 - three consecutive


def test_percent_b_flags_outside_the_bands() -> None:
    close = np.concatenate([np.full(25, 100.0), np.array([120.0])])
    bands = ind.bbands(close, 20, 2.0)
    pct = ind.percent_b(close, bands)
    assert pct[-1] > 1.0


def test_candle_patterns_degrade_without_talib() -> None:
    """Patterns are cosmetic tags; absence must not raise."""
    close = bearish_divergence_close()
    patterns = ind.candle_patterns(close, close + 1, close - 1, close)
    assert isinstance(patterns, dict)
    if not ind.talib_available():
        assert patterns == {}
