"""Tests for the TA study."""
