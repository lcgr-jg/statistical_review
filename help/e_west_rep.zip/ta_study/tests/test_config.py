"""Config loading and validation, including the shipped ta_products.yaml."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from ta_study.config import (
    DEFAULT_CONFIG_PATH,
    AdxGateConfig,
    DivergenceConfig,
    HorizonConfig,
    IndicatorsConfig,
    MacdConfig,
    ProductConfig,
    RsiConfig,
    RunConfig,
    SignalConfig,
    StatsConfig,
    StudyConfig,
    load_config,
)


# ---------------------------------------------------------------------------
# the shipped config must be valid and coherent
# ---------------------------------------------------------------------------
def test_shipped_config_loads() -> None:
    cfg = load_config()
    assert cfg.products
    assert cfg.active_horizons
    assert cfg.run.recipients


def test_shipped_config_has_the_spec_defaults() -> None:
    cfg = load_config()
    assert cfg.indicators.rsi.period == 14
    assert (cfg.indicators.rsi.ob, cfg.indicators.rsi.os) == (70, 30)
    assert (cfg.indicators.rsi.ob_soft, cfg.indicators.rsi.os_soft) == (60, 40)
    assert (
        cfg.indicators.stoch.k_period,
        cfg.indicators.stoch.k_smooth,
        cfg.indicators.stoch.d_period,
    ) == (14, 3, 3)
    assert cfg.indicators.adx.period == 14
    assert cfg.divergence.swing_k == 5
    assert cfg.divergence.max_lookback_bars == 60
    assert cfg.divergence.min_swing_separation == 5
    assert cfg.divergence.min_rsi_delta == 2.0
    assert cfg.divergence.confirmation_window == 10
    assert cfg.divergence.active_window == 15
    assert cfg.adx_gate.rising_slope_bars == 3
    assert cfg.stats.min_sample == 20
    assert cfg.stats.forward_bars == (5, 10, 20)


def test_hidden_divergences_ship_disabled() -> None:
    """The study as described covers regular divergences only."""
    assert load_config().divergence.include_hidden is False


def test_shipped_gas_and_power_gate_higher_than_oil() -> None:
    cfg = load_config()
    for name in ("TTF", "DE_BASE"):
        assert cfg.adx_threshold_for(name) == 35
    for name in ("BRENT", "EUA"):
        assert cfg.adx_threshold_for(name) == 30


def test_shipped_config_pairs_respect_skip_horizons() -> None:
    """Settlement-only power series opt out of the intraday horizons."""
    cfg = load_config()
    full_grid = len(cfg.products) * len(cfg.active_horizons)
    skipped = sum(
        1
        for p in cfg.products
        for h in cfg.active_horizons
        if h.name in p.skip_horizons
    )
    assert skipped > 0, "the shipped config should exercise skip_horizons"
    assert len(cfg.pairs()) == full_grid - skipped


def test_settlement_only_power_skips_intraday() -> None:
    cfg = load_config()
    for name in ("DE_POWER_M1", "FR_POWER_M1"):
        product = cfg.product(name)
        assert product is not None, f"{name} missing from the shipped config"
        assert set(product.skip_horizons) == {"4H", "1H"}
        assert product.note


def test_shipped_config_covers_the_metals() -> None:
    cfg = load_config()
    metals = {p.name for p in cfg.products if p.group == "metals"}
    assert metals == {"GOLD", "SILVER", "COPPER", "ALUMINIUM"}


def test_default_config_path_exists() -> None:
    assert DEFAULT_CONFIG_PATH.exists()


def test_missing_config_raises() -> None:
    with pytest.raises(FileNotFoundError, match="ta_study config not found"):
        load_config("does-not-exist.yaml")


# ---------------------------------------------------------------------------
# validation rules
# ---------------------------------------------------------------------------
def test_rsi_zones_must_be_ordered() -> None:
    with pytest.raises(ValidationError, match="os < os_soft < ob_soft < ob"):
        RsiConfig(ob=70, os=30, ob_soft=30, os_soft=60)


def test_macd_fast_must_be_shorter_than_slow() -> None:
    with pytest.raises(ValidationError, match="shorter than slow"):
        MacdConfig(fast=26, slow=12, signal=9)


def test_ema_periods_must_be_three_and_ascending() -> None:
    with pytest.raises(ValidationError, match="exactly three"):
        IndicatorsConfig(ema=(20, 50))
    with pytest.raises(ValidationError, match="ascending"):
        IndicatorsConfig(ema=(200, 50, 20))


def test_ema_accessors() -> None:
    icfg = IndicatorsConfig(ema=(10, 40, 100))
    assert (icfg.ema_fast, icfg.ema_mid, icfg.ema_slow) == (10, 40, 100)


def test_separation_must_fit_inside_the_lookback() -> None:
    with pytest.raises(ValidationError, match="exceeds"):
        DivergenceConfig(min_swing_separation=80, max_lookback_bars=60)


def test_rsi_tolerance_cannot_exceed_swing_k() -> None:
    with pytest.raises(ValidationError, match="look ahead"):
        DivergenceConfig(swing_k=3, rsi_tolerance_bars=5)
    DivergenceConfig(swing_k=5, rsi_tolerance_bars=5)  # equal is allowed


def test_strength_weights_must_sum_to_one() -> None:
    with pytest.raises(ValidationError, match=r"sum to 1\.0"):
        SignalConfig(strength_weights=(0.5, 0.5, 0.5))
    with pytest.raises(ValidationError, match="non-negative"):
        SignalConfig(strength_weights=(1.5, -0.25, -0.25))


def test_multipliers_are_bounded_to_the_unit_interval() -> None:
    with pytest.raises(ValidationError):
        SignalConfig(gated_multiplier=1.5)
    with pytest.raises(ValidationError):
        SignalConfig(unconfirmed_multiplier=-0.1)


def test_intraday_horizon_needs_an_interval() -> None:
    with pytest.raises(ValidationError, match="need interval_min"):
        HorizonConfig(name="4H", source="intraday")


def test_daily_horizon_rejects_an_interval() -> None:
    with pytest.raises(ValidationError, match="meaningless for a daily source"):
        HorizonConfig(name="D", source="daily", interval_min=60)


def test_session_start_must_be_hhmm() -> None:
    with pytest.raises(ValidationError, match="HH:MM"):
        ProductConfig(name="X", ticker="T", group="g", session_start="8am")
    with pytest.raises(ValidationError, match="out of range"):
        ProductConfig(name="X", ticker="T", group="g", session_start="25:00")


def test_session_start_minutes() -> None:
    product = ProductConfig(name="X", ticker="T", group="g", session_start="08:30")
    assert product.session_start_minutes == 510


def test_unknown_config_keys_are_rejected() -> None:
    """extra='forbid' turns a typo into a startup failure, not a silent default."""
    with pytest.raises(ValidationError):
        RunConfig(max_email_megabytes=8)


def test_duplicate_product_names_are_rejected() -> None:
    with pytest.raises(ValidationError, match="duplicate product names"):
        StudyConfig(
            horizons=[HorizonConfig(name="D", source="daily")],
            products=[
                ProductConfig(name="TTF", ticker="A", group="gas"),
                ProductConfig(name="TTF", ticker="B", group="gas"),
            ],
        )


def test_duplicate_horizon_names_are_rejected() -> None:
    with pytest.raises(ValidationError, match="duplicate horizon names"):
        StudyConfig(
            horizons=[
                HorizonConfig(name="D", source="daily"),
                HorizonConfig(name="D", source="daily", bars=300),
            ],
            products=[ProductConfig(name="TTF", ticker="A", group="gas")],
        )


def test_at_least_one_product_is_required() -> None:
    with pytest.raises(ValidationError, match="at least one product"):
        StudyConfig(horizons=[HorizonConfig(name="D", source="daily")], products=[])


def test_skip_horizons_must_name_real_horizons() -> None:
    with pytest.raises(ValidationError, match="skip_horizons names unknown"):
        StudyConfig(
            horizons=[HorizonConfig(name="D", source="daily")],
            products=[
                ProductConfig(
                    name="TTF", ticker="A", group="gas", skip_horizons=("4H",)
                )
            ],
        )


def test_recipients_accept_a_comma_separated_string() -> None:
    run = RunConfig(recipients="a@x.com, b@x.com")  # type: ignore[arg-type]
    assert run.recipients == ["a@x.com", "b@x.com"]


# ---------------------------------------------------------------------------
# lookups and derived values
# ---------------------------------------------------------------------------
def _cfg() -> StudyConfig:
    return StudyConfig(
        horizons=[
            HorizonConfig(name="W", source="daily", resample="1W-FRI", bars=300),
            HorizonConfig(name="D", source="daily", bars=400),
            HorizonConfig(name="4H", source="intraday", interval_min=240, bars=400),
            HorizonConfig(name="1H", source="intraday", interval_min=60, bars=400),
            HorizonConfig(name="15m", source="intraday", interval_min=15, enabled=False),
        ],
        products=[
            ProductConfig(name="TTF", ticker="A", group="gas", adx_threshold=35),
            ProductConfig(
                name="THIN", ticker="B", group="power", skip_horizons=("4H", "1H")
            ),
        ],
        adx_gate=AdxGateConfig(default_threshold=30),
    )


def test_disabled_horizons_are_excluded() -> None:
    cfg = _cfg()
    assert {h.name for h in cfg.active_horizons} == {"W", "D", "4H", "1H"}
    assert "15m" not in {h.name for h in cfg.active_horizons}


# ---------------------------------------------------------------------------
# horizon display order
# ---------------------------------------------------------------------------
def _ordered(order: str) -> list[str]:
    cfg = _cfg().model_copy(
        update={"run": RunConfig(horizon_order=order)}  # type: ignore[arg-type]
    )
    return [h.name for h in cfg.active_horizons]


def test_default_order_is_fastest_first() -> None:
    assert _ordered("fine_to_coarse") == ["1H", "4H", "D", "W"]


def test_coarse_to_fine_reverses_it() -> None:
    assert _ordered("coarse_to_fine") == ["W", "D", "4H", "1H"]


def test_config_order_is_left_alone() -> None:
    """The escape hatch: whatever order `horizons:` is written in."""
    assert _ordered("config") == ["W", "D", "4H", "1H"]


def test_bar_minutes_ranks_every_horizon_kind() -> None:
    assert HorizonConfig(name="1H", source="intraday", interval_min=60).bar_minutes == 60
    assert HorizonConfig(name="4H", source="intraday", interval_min=240).bar_minutes == 240
    assert HorizonConfig(name="D", source="daily").bar_minutes == 24 * 60
    weekly = HorizonConfig(name="W", source="daily", resample="1W-FRI")
    assert weekly.bar_minutes == 7 * 24 * 60


def test_horizon_rank_follows_the_display_order() -> None:
    cfg = _cfg()
    assert cfg.horizon_rank("1H") == 0
    assert cfg.horizon_rank("W") == 3
    # An unknown or disabled horizon sorts last rather than raising.
    assert cfg.horizon_rank("15m") == 4
    assert cfg.horizon_rank("nope") == 4


def test_shipped_config_puts_the_fastest_frequency_first() -> None:
    assert [h.name for h in load_config().active_horizons] == ["1H", "4H", "D", "W"]


def test_skip_horizons_removes_pairs() -> None:
    cfg = _cfg()
    pairs = {(p.name, h.name) for p, h in cfg.pairs()}
    assert ("THIN", "4H") not in pairs
    assert ("THIN", "D") in pairs
    assert len(pairs) == 4 + 2


def test_adx_threshold_falls_back_to_the_default() -> None:
    cfg = _cfg()
    assert cfg.adx_threshold_for("TTF") == 35
    assert cfg.adx_threshold_for("THIN") == 30
    assert cfg.adx_threshold_for("UNKNOWN") == 30


def test_roll_method_per_product_overrides_the_default() -> None:
    cfg = StudyConfig(
        horizons=[HorizonConfig(name="D", source="daily")],
        products=[
            ProductConfig(name="A", ticker="A", group="g", roll_method="drop"),
            ProductConfig(name="B", ticker="B", group="g"),
        ],
        roll_method="backadjust",
    )
    assert cfg.roll_method_for("A") == "drop"
    assert cfg.roll_method_for("B") == "backadjust"


def test_intraday_base_interval_is_the_finest_enabled() -> None:
    cfg = _cfg()
    assert cfg.needs_intraday
    assert cfg.intraday_base_interval == 60  # the 15m horizon is disabled


def test_needs_intraday_is_false_without_intraday_horizons() -> None:
    cfg = StudyConfig(
        horizons=[HorizonConfig(name="D", source="daily")],
        products=[ProductConfig(name="A", ticker="A", group="g")],
    )
    assert not cfg.needs_intraday
    assert cfg.intraday_base_interval == 60  # harmless default


def test_max_email_bytes_conversion() -> None:
    assert RunConfig(max_email_mb=8).max_email_bytes == 8 * 1024 * 1024


def test_product_and_horizon_lookup() -> None:
    cfg = _cfg()
    assert cfg.product("TTF") is not None
    assert cfg.product("NOPE") is None
    assert cfg.horizon("4H") is not None
    assert cfg.horizon("NOPE") is None


def test_display_falls_back_to_the_name() -> None:
    assert ProductConfig(name="TTF", ticker="A", group="g").display == "TTF"
    assert (
        ProductConfig(name="TTF", ticker="A", group="g", label="TTF Gas").display
        == "TTF Gas"
    )
    assert HorizonConfig(name="D", source="daily").display == "D"


def test_config_is_frozen() -> None:
    cfg = _cfg()
    with pytest.raises(ValidationError):
        cfg.roll_method = "drop"  # type: ignore[misc]


def test_stats_headline_must_be_collected() -> None:
    StatsConfig(forward_bars=(5, 10), headline_forward_bars=5)
    with pytest.raises(ValidationError, match="headline_forward_bars"):
        StatsConfig(forward_bars=(5, 10), headline_forward_bars=15)
