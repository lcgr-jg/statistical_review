"""Email assembly: size enforcement drop order, captions, grid, subject."""

from __future__ import annotations

import datetime as dt

import numpy as np
import pytest

from common.deliver import InlineImage, new_content_id
from ta_study.render import (
    ChartRef,
    build_email,
    caption_for,
    change_lines,
    enforce_email_size,
    grid_cell,
    make_chart_ref,
    subject_line,
    summarise,
)
from ta_study.secondary import compute_secondary
from ta_study.study import alignment, run_study
from ta_study.tests.conftest import bars_frame, bearish_divergence_close


def _ref(label: str, strength: float, size: int, kind: str = "full") -> ChartRef:
    product, _, horizon = label.partition(" ")
    return ChartRef(
        product=product,
        horizon=horizon,
        kind=kind,
        image=InlineImage(
            content_id=new_content_id(label),
            filename=f"{label}.png",
            content=b"x" * size,
        ),
        strength=strength,
    )


# ---------------------------------------------------------------------------
# size enforcement (§11)
# ---------------------------------------------------------------------------
def test_everything_kept_when_under_the_limit() -> None:
    full = [_ref("TTF D", 0.9, 1_000), _ref("EUA W", 0.2, 1_000)]
    thumbs = [_ref("TTF D", 0.0, 100, "thumb")]
    plan = enforce_email_size(5_000, full, thumbs, limit_bytes=10_000_000)
    assert plan.kept_full == full
    assert plan.kept_thumbs == thumbs
    assert plan.dropped == []
    assert not plan.over_limit


def test_thumbnails_are_dropped_before_any_full_chart() -> None:
    """§11 makes the thumbnail strip explicitly the first thing to go."""
    full = [_ref("TTF D", 0.9, 400_000), _ref("EUA W", 0.1, 400_000)]
    thumbs = [_ref(f"P{i} D", 0.0, 100_000, "thumb") for i in range(6)]

    # Room for both full charts but not the strip.
    plan = enforce_email_size(10_000, full, thumbs, limit_bytes=1_200_000)
    assert plan.kept_full == full
    assert plan.kept_thumbs == []
    assert plan.dropped_thumbs == thumbs
    assert plan.dropped_full == []


def test_full_charts_are_dropped_in_ascending_strength_order() -> None:
    full = [
        _ref("A D", 0.90, 300_000),
        _ref("B D", 0.10, 300_000),
        _ref("C D", 0.50, 300_000),
        _ref("D D", 0.30, 300_000),
    ]
    # Room for roughly two charts once base64 overhead is counted.
    plan = enforce_email_size(10_000, full, [], limit_bytes=850_000)

    dropped = [c.label for c in plan.dropped_full]
    kept = [c.label for c in plan.kept_full]
    assert dropped == ["B D", "D D"], dropped
    assert kept == ["A D", "C D"], kept
    # The weakest goes first, and the survivors keep the caller's order.
    assert [c.strength for c in plan.dropped_full] == sorted(
        c.strength for c in plan.dropped_full
    )


def test_drop_order_is_deterministic_on_a_strength_tie() -> None:
    full = [
        _ref("A D", 0.5, 300_000),
        _ref("B D", 0.5, 300_000),
        _ref("C D", 0.5, 300_000),
    ]
    first = enforce_email_size(10_000, full, [], limit_bytes=500_000)
    second = enforce_email_size(10_000, full, [], limit_bytes=500_000)
    assert [c.label for c in first.dropped_full] == [c.label for c in second.dropped_full]


def test_everything_can_be_dropped_if_the_limit_is_tiny() -> None:
    full = [_ref("A D", 0.5, 500_000)]
    thumbs = [_ref("A D", 0.0, 100_000, "thumb")]
    plan = enforce_email_size(1_000, full, thumbs, limit_bytes=2_000)
    assert plan.kept_full == []
    assert plan.kept_thumbs == []
    assert len(plan.dropped) == 2


def test_size_estimate_accounts_for_base64_overhead() -> None:
    ref = _ref("A D", 0.5, 300_000)
    plan = enforce_email_size(1_000, [ref], [], limit_bytes=10_000_000)
    # 300 KB of PNG costs ~400 KB on the wire.
    assert plan.est_bytes > 300_000 * 1.3
    assert plan.est_bytes < 300_000 * 1.4 + 2_000


def test_cid_references_rewrite_to_data_uris_for_kafka() -> None:
    """The kafka relay has no MIME structure, so charts go in the body."""
    from common.deliver import inline_as_data_uris

    ref = _ref("TTF D", 0.5, 12)
    html = f'<img src="{ref.image.src}" alt="x">'
    out = inline_as_data_uris(html, [ref.image])

    assert "cid:" not in out
    assert out.startswith('<img src="data:image/png;base64,')
    assert ref.image.b64 in out


def test_data_uri_rewrite_leaves_unreferenced_images_alone() -> None:
    from common.deliver import inline_as_data_uris

    # Distinct byte lengths, so the two base64 payloads cannot coincide.
    used = _ref("A D", 0.5, 8)
    unused = _ref("B D", 0.5, 17)
    html = f'<img src="{used.image.src}">'
    out = inline_as_data_uris(html, [used.image, unused.image])

    assert used.image.b64 in out
    assert unused.image.b64 not in out


def test_data_uri_rewrite_is_a_noop_without_images() -> None:
    from common.deliver import inline_as_data_uris

    html = "<p>no charts today</p>"
    assert inline_as_data_uris(html, []) == html


def test_make_chart_ref_returns_none_for_a_failed_render() -> None:
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    from ta_study.config import (
        HorizonConfig,
        ProductConfig,
        RunConfig,
        StudyConfig,
    )

    cfg = StudyConfig(
        run=RunConfig(recipients=["x@y.com"], min_bars=60, chart_workers=0),
        horizons=[HorizonConfig(name="D", source="daily", bars=400)],
        products=[ProductConfig(name="TEST", ticker="T1", group="gas")],
    )
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    assert make_chart_ref(result, b"", "full") is None
    assert make_chart_ref(result, b"\x89PNG", "full") is not None


# ---------------------------------------------------------------------------
# subject and counts
# ---------------------------------------------------------------------------
def test_subject_reports_the_counts() -> None:
    counts = {"confirmed": 2, "active": 5}
    subject = subject_line(counts, [], dt.date(2026, 9, 18))
    assert subject == "TA Study 2026-09-18 — 2 confirmed / 5 active"


def test_subject_names_aligned_products() -> None:
    from ta_study.study import Alignment

    counts = {"confirmed": 1, "active": 1}
    aligned = [
        Alignment("TTF", -0.8, ("W", "D"), -1),
        Alignment("EUA", 0.4, ("W", "D"), 1),
    ]
    subject = subject_line(counts, aligned, dt.date(2026, 9, 18))
    assert subject.endswith("— ALIGNMENT: TTF, EUA")


def test_subject_deduplicates_a_product_aligned_both_ways() -> None:
    from ta_study.study import Alignment

    aligned = [
        Alignment("TTF", -0.8, ("W", "D"), -1),
        Alignment("TTF", 0.3, ("4H", "1H"), 1),
    ]
    subject = subject_line({"confirmed": 0, "active": 2}, aligned, dt.date(2026, 9, 18))
    assert subject.count("TTF") == 1


def test_summarise_counts_every_state() -> None:
    from ta_study.tests.test_study import _result

    results = [_result("A", "D", -1, 0.5), _result("B", "D", 1, 0.5)]
    results[1].state = "DVG_CONFIRMED"
    counts = summarise(results)
    assert counts["active"] == 1
    assert counts["confirmed"] == 1
    assert counts["gated"] == 0


def test_change_lines_only_mention_actual_changes() -> None:
    from ta_study.tests.test_study import _result

    changed = _result("TTF", "4H", 1, 0.71)
    changed.prev_state = "DVG_ACTIVE"
    changed.state = "DVG_CONFIRMED"
    unchanged = _result("EUA", "D", -1, 0.2)
    unchanged.prev_state = "DVG_ACTIVE"

    lines = change_lines([changed, unchanged])
    assert len(lines) == 1
    assert "TTF 4H: DVG_ACTIVE → DVG_CONFIRMED" in lines[0]
    assert "0.71" in lines[0]


# ---------------------------------------------------------------------------
# grid cells
# ---------------------------------------------------------------------------
def test_grid_cell_blanks_a_none_state() -> None:
    from ta_study.tests.test_study import _result

    result = _result("TTF", "D", 0, 0.0)
    result.state = "NONE"
    cell = grid_cell(result)
    assert cell.blank
    assert cell.badge == ""
    assert cell.arrow == ""


def test_gated_cell_carries_a_lock() -> None:
    from ta_study.tests.test_study import _result

    result = _result("TTF", "D", -1, 0.3)
    result.state = "DVG_GATED"
    assert "🔒" in grid_cell(result).badge


def test_provisional_cell_is_outlined_not_filled() -> None:
    from ta_study.tests.test_study import _result

    result = _result("TTF", "D", 0, 0.0)
    result.state = "PROVISIONAL"
    assert grid_cell(result).outline


def test_grid_cell_detail_shows_the_raw_ingredients() -> None:
    from ta_study.tests.test_study import _result

    result = _result("TTF", "D", -1, 0.5)
    result.rsi, result.k, result.d, result.adx = 27.4, 14.2, 18.9, 22.1
    detail = grid_cell(result).detail
    assert "RSI 27" in detail
    assert "K/D 14/19" in detail
    assert "ADX 22" in detail


# ---------------------------------------------------------------------------
# captions
# ---------------------------------------------------------------------------
@pytest.fixture
def live_result(cfg):
    """A study result whose final state is live, so it has a caption."""
    close = bearish_divergence_close()
    close = np.concatenate([np.linspace(95.0, 100.0, 80), close])
    full = run_study(bars_frame(close), cfg, "TEST", "D")
    # Truncate to a few bars after the last trigger so the state is active.
    cut = full.events[-1].triggered_at + 3
    return run_study(bars_frame(close[: cut + 1]), cfg, "TEST", "D")


def test_caption_names_the_trigger_and_the_next_step(live_result, cfg) -> None:
    assert live_result.event is not None, "fixture must end inside a live signal"
    lines = caption_for(live_result, None, cfg, None)
    assert len(lines) >= 3

    # Line 1 says what happened, without jargon.
    assert lines[0].startswith("Price made ")
    assert "momentum made" in lines[0]
    assert "RSI" in lines[0]
    for jargon in ("σ", "divergence", "×"):
        assert jargon not in lines[0], f"{jargon!r} should not survive the rewrite"

    # Line 2 says where it stands and what happens next.
    assert any(
        phrase in lines[1]
        for phrase in ("Waiting for", "has started", "On hold", "Just cleared",
                       "never showed", "Not a signal yet")
    )

    # Line 3 spells out confidence and size in words.
    assert lines[2].startswith("Signal quality:")
    assert any(w in lines[2] for w in ("weak", "moderate", "strong"))


def test_caption_reads_correctly_once_the_confirmation_window_has_closed(cfg) -> None:
    """Past W_c the signal can no longer confirm, so "confirms on..." is wrong."""
    from ta_study.render import next_step_line
    from ta_study.tests.test_study import _result

    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    donor = run_study(bars_frame(close), cfg, "TEST", "D")
    event = donor.events[-1]

    inside = _result("TEST", "D", -1, 0.4)
    inside.bars_since_dvg = 2          # W_c is 10
    line = next_step_line(inside, cfg, event)
    assert line.startswith("Waiting for the turn down to show")
    assert "within 8 more bar(s)" in line

    past = _result("TEST", "D", -1, 0.4)
    past.bars_since_dvg = 12           # beyond W_c, inside W_a (15)
    line = next_step_line(past, cfg, event)
    assert "never showed" in line
    assert "Waiting for" not in line
    assert "stays unconfirmed" in line
    assert "drops off in 3 bar(s)" in line
    # str.capitalize() would render the acronym "Adx".
    assert "Adx" not in line
    assert "ADX" in line


def test_gate_phrase_never_asserts_a_false_inequality(cfg) -> None:
    """The gate is `ADX >= theta AND rising`, so it can be open above theta.

    Regression: the caption read "ADX 31.5 < 30, so the gate is open" - a
    falsehood the reader can check against the chart directly above it.
    """
    from ta_study.render import gate_phrase
    from ta_study.tests.test_study import _result

    below = _result("TTF", "D", -1, 0.4)
    below.adx, below.adx_threshold = 22.6, 30.0
    assert gate_phrase(below) == "ADX 22.6 is below the 30 threshold"

    above = _result("TTF", "D", -1, 0.4)
    above.adx, above.adx_threshold = 31.5, 30.0
    phrase = gate_phrase(above)
    assert "above the 30 threshold" in phrase
    assert "not rising" in phrase
    assert "<" not in phrase

    missing = _result("TTF", "D", -1, 0.4)
    missing.adx = float("nan")
    assert gate_phrase(missing) == "ADX unavailable"


def test_confirmed_caption_explains_an_open_gate_above_threshold(cfg) -> None:
    from ta_study.render import next_step_line
    from ta_study.tests.test_study import _result

    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    event = run_study(bars_frame(close), cfg, "TEST", "D").events[-1]

    result = _result("TEST", "D", -1, 0.4)
    result.confirmed = True
    result.confirmed_at_bar = event.triggered_at + 4
    result.adx, result.adx_threshold = 31.5, 30.0

    line = next_step_line(result, cfg, event)
    assert "has started" in line
    assert "31.5 < 30" not in line
    assert "not rising" in line


def test_caption_includes_the_hit_rate_when_available(live_result, cfg) -> None:
    from ta_study.stats import HitRateIndex, event_records, hit_rates

    records = event_records(live_result, cfg)
    index = HitRateIndex(hit_rates(records, cfg.stats), cfg.stats)
    lines = caption_for(live_result, None, cfg, index)
    assert any(line.startswith("Track record over the next") for line in lines)


def test_caption_for_a_gated_signal_explains_the_release(cfg) -> None:
    from ta_study.tests.test_study import _result

    result = _result("TTF", "D", -1, 0.4)
    result.state = "DVG_GATED"
    result.gated = True
    result.adx = 41.0
    result.adx_threshold = 35.0
    # Borrow a real event so the caption has swings to describe.
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    donor = run_study(bars_frame(close), cfg, "TEST", "D")
    result.event = donor.events[-1]

    lines = caption_for(result, None, cfg, None)
    assert lines[1].startswith("On hold:")
    assert "35" in lines[1]
    assert "expensive" in lines[1]
    assert "ADX" in lines[1]


def test_caption_falls_back_to_the_ma_cross(cfg) -> None:
    close = np.linspace(100.0, 250.0, 300)
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    sec = compute_secondary(result.series, cfg, "TEST", "D")
    lines = caption_for(result, sec, cfg, None)
    assert len(lines) == 2
    assert lines[0]


# ---------------------------------------------------------------------------
# full render
# ---------------------------------------------------------------------------
def test_build_email_renders_and_references_only_kept_charts(cfg) -> None:
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    sec = compute_secondary(result.series, cfg, "TEST", "D")

    full = [_ref("TEST D", 0.5, 2_000)]
    thumbs = [_ref("TEST D", 0.0, 500, "thumb")]

    email = build_email(
        results=[result],
        secondary={("TEST", "D"): sec},
        alignments=alignment([result]),
        full_charts=full,
        thumbnails=thumbs,
        cfg=cfg,
        run_date=dt.date(2026, 9, 18),
    )

    assert email.subject.startswith("TA Study 2026-09-18")
    assert "<!DOCTYPE html>" in email.html
    assert "Signal grid" in email.html
    assert "Method" in email.html
    # Every inline part must be referenced, and every reference resolved.
    for img in email.inline:
        assert f"cid:{img.content_id}" in email.html
    assert email.html.count("cid:") == len(email.inline)


def test_build_email_lists_withheld_charts_in_the_appendix(cfg) -> None:
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    sec = compute_secondary(result.series, cfg, "TEST", "D")

    tiny = cfg.model_copy(
        update={"run": cfg.run.model_copy(update={"max_email_mb": 0.02})}
    )
    full = [_ref("TEST D", 0.5, 400_000), _ref("TEST W", 0.1, 400_000)]

    email = build_email(
        results=[result],
        secondary={("TEST", "D"): sec},
        alignments=[],
        full_charts=full,
        thumbnails=[],
        cfg=tiny,
        run_date=dt.date(2026, 9, 18),
    )
    assert email.plan.dropped
    assert "Charts withheld for size" in email.html
    for chart in email.plan.dropped:
        assert chart.label in email.html
    # And nothing dropped is still referenced.
    for chart in email.plan.dropped:
        assert f"cid:{chart.image.content_id}" not in email.html


def test_build_email_survives_a_product_with_no_secondary_block(cfg) -> None:
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    email = build_email(
        results=[result],
        secondary={},
        alignments=[],
        full_charts=[],
        thumbnails=[],
        cfg=cfg,
        run_date=dt.date(2026, 9, 18),
    )
    assert "Signal grid" in email.html


def test_build_email_includes_the_hypothesis_and_warnings(cfg) -> None:
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    email = build_email(
        results=[result],
        secondary={},
        alignments=[],
        full_charts=[],
        thumbnails=[],
        cfg=cfg,
        run_date=dt.date(2026, 9, 18),
        hypothesis={
            "min_sample": 20,
            "ungated": {"n": 40, "mean_atr": 0.3, "hit_rate": 0.6, "buckets": 2},
            "gated": {"n": 10, "mean_atr": -0.1, "hit_rate": 0.4, "buckets": 1},
            "hypothesis_holds": True,
            "gate_helps": True,
        },
        warnings=["TTF 1H: only 12 bars"],
        diagnostics={"pairs": 1, "latest bar": "2026-09-18"},
    )
    assert "Does the hypothesis hold?" in email.html
    assert "gate helps" in email.html
    assert "TTF 1H: only 12 bars" in email.html
    assert "latest bar" in email.html
