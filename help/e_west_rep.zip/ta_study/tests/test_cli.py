"""CLI argument parsing and the validate subcommand."""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

import pytest

from ta_study.cli import build_parser, main


def _parse(argv: list[str]):
    return build_parser().parse_args(argv)


# ---------------------------------------------------------------------------
# global flags in either position
# ---------------------------------------------------------------------------
def test_global_flags_accepted_before_the_subcommand() -> None:
    args = _parse(["--plain-logs", "-v", "run"])
    assert args.plain_logs is True
    assert args.verbose is True
    assert args.command == "run"


def test_global_flags_accepted_after_the_subcommand() -> None:
    args = _parse(["run", "--plain-logs", "-v"])
    assert args.plain_logs is True
    assert args.verbose is True


def test_a_flag_before_the_subcommand_is_not_reset_by_the_subparser() -> None:
    """The argparse parents gotcha: SUPPRESS defaults keep the outer value."""
    args = _parse(["--plain-logs", "run"])
    assert args.plain_logs is True

    args = _parse(["--config", "x.yaml", "run"])
    assert args.config == Path("x.yaml")

    args = _parse(["--base-dir", "/tmp/x", "run", "--dry-run"])
    assert args.base_dir == Path("/tmp/x")
    assert args.dry_run is True


def test_flags_default_off_when_given_nowhere() -> None:
    args = _parse(["run"])
    assert args.plain_logs is False
    assert args.verbose is False
    assert args.config is None
    assert args.base_dir is None


def test_subcommand_flag_wins_when_given_twice() -> None:
    args = _parse(["--config", "outer.yaml", "run", "--config", "inner.yaml"])
    assert args.config == Path("inner.yaml")


# ---------------------------------------------------------------------------
# run options
# ---------------------------------------------------------------------------
def test_date_and_as_of_are_the_same_option() -> None:
    assert _parse(["run", "--date", "2026-09-18"]).date == dt.date(2026, 9, 18)
    assert _parse(["run", "--as-of", "2026-09-18"]).date == dt.date(2026, 9, 18)


def test_a_bad_date_is_rejected_with_a_readable_message(capsys) -> None:
    with pytest.raises(SystemExit):
        _parse(["run", "--date", "18/09/2026"])
    assert "expected YYYY-MM-DD" in capsys.readouterr().err


def test_repeatable_filters_accumulate() -> None:
    args = _parse(
        ["run", "--product", "TTF", "--product", "EUA", "--horizon", "D", "--horizon", "W"]
    )
    assert args.product == ["TTF", "EUA"]
    assert args.horizon == ["D", "W"]


def test_recipient_override_is_repeatable() -> None:
    args = _parse(["run", "--to", "a@x.com", "--to", "b@x.com"])
    assert args.to == ["a@x.com", "b@x.com"]


def test_run_defaults_are_safe() -> None:
    """Nothing about a bare `run` should be surprising except that it sends."""
    args = _parse(["run"])
    assert args.dry_run is False
    assert args.offline is False
    assert args.no_cache is False
    assert args.no_parallel is False
    assert args.to is None


# ---------------------------------------------------------------------------
# backfill / stats
# ---------------------------------------------------------------------------
def test_backfill_requires_a_range() -> None:
    with pytest.raises(SystemExit):
        _parse(["backfill"])
    args = _parse(["backfill", "--start", "2026-01-01", "--end", "2026-03-01"])
    assert args.start == dt.date(2026, 1, 1)
    assert args.end == dt.date(2026, 3, 1)


def test_backfill_rejects_an_inverted_range(capsys) -> None:
    code = main(["backfill", "--start", "2026-03-01", "--end", "2026-01-01"])
    assert code == 2
    assert "--start must not be after --end" in capsys.readouterr().err


def test_a_subcommand_is_required() -> None:
    with pytest.raises(SystemExit):
        _parse([])


def test_unknown_subcommand_is_rejected() -> None:
    with pytest.raises(SystemExit):
        _parse(["frobnicate"])


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------
def test_validate_prints_a_config_summary(capsys) -> None:
    assert main(["validate", "--plain-logs"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["products"]
    assert payload["horizons"]
    # Not every product runs every horizon (skip_horizons), so this is a
    # bound rather than a product.
    assert 0 < payload["pairs"] <= len(payload["products"]) * len(payload["horizons"])
    assert payload["transport"] in {"graph", "smtp", "kafka"}
    assert payload["roll_method"] in {"backadjust", "drop", "none"}


def test_validate_reports_a_missing_config() -> None:
    with pytest.raises(FileNotFoundError, match="ta_study config not found"):
        main(["validate", "--config", "nope.yaml"])


# ---------------------------------------------------------------------------
# failure modes
# ---------------------------------------------------------------------------
def test_offline_with_no_data_fails_cleanly(tmp_path, capsys) -> None:
    """A routine outcome deserves a message, not a traceback."""
    code = main(["run", "--dry-run", "--offline", "--base-dir", str(tmp_path)])
    assert code == 1
    err = capsys.readouterr().err
    assert "ta_study:" in err
    assert "no (product, horizon) produced a study result" in err
    assert "--offline uses only the Parquet cache" in err


def test_an_unknown_product_filter_fails_cleanly(tmp_path, capsys) -> None:
    code = main(
        ["run", "--dry-run", "--product", "NOPE", "--base-dir", str(tmp_path)]
    )
    assert code == 1
    assert "no (product, horizon) pairs selected" in capsys.readouterr().err
