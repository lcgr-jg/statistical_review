"""Dagster wiring: the definitions must load and be internally consistent.

Mirrors the checks in the repo-level ``tests/test_dagster_definitions.py``:
a broken asset graph is only discovered at ``dagster dev`` time otherwise,
which in practice means discovering it when the schedule fails to fire.
"""

from __future__ import annotations

import os

import pytest

dagster = pytest.importorskip("dagster")

from ta_study.dagster_defs import (
    STATS_CRON,
    STUDY_CRON,
    TIMEZONE,
    defs,
    ta_study_assets,
    ta_study_email,
    ta_study_jobs,
    ta_study_schedules,
)


def _asset_keys(asset_def) -> set[str]:
    return {key.to_user_string() for key in asset_def.keys}


def _upstream_of(asset_def) -> set[str]:
    return {
        key.to_user_string()
        for keys in asset_def.asset_deps.values()
        for key in keys
    }


def test_definitions_load() -> None:
    assert defs is not None
    keys: set[str] = set()
    for asset_def in ta_study_assets:
        keys |= _asset_keys(asset_def)
    assert keys == {
        "ta_study_bars_daily",
        "ta_study_bars_intraday",
        "ta_study_email",
        "ta_study_forward_returns",
    }


def test_email_asset_depends_on_both_bar_assets() -> None:
    upstream = _upstream_of(ta_study_email)
    assert {"ta_study_bars_daily", "ta_study_bars_intraday"} <= upstream


def test_forward_returns_is_not_upstream_of_the_email() -> None:
    """A stats failure must never block or delay the morning email."""
    assert "ta_study_forward_returns" not in _upstream_of(ta_study_email)


def test_jobs_and_schedules_are_paired() -> None:
    assert len(ta_study_jobs) == 2
    assert len(ta_study_schedules) == 2
    job_names = {job.name for job in ta_study_jobs}
    assert job_names == {"ta_study_job", "ta_study_stats_job"}
    for sched in ta_study_schedules:
        assert sched.job_name in job_names


def test_schedules_run_on_weekdays_in_uk_time() -> None:
    for sched in ta_study_schedules:
        assert sched.cron_schedule in {STUDY_CRON, STATS_CRON}
        assert sched.cron_schedule.endswith("1-5"), "weekdays only"
        assert sched.execution_timezone == TIMEZONE


def test_study_runs_before_the_configured_send_time() -> None:
    """The schedule must fire early enough for a 07:00 send."""
    from ta_study.config import load_config

    minute, hour = STUDY_CRON.split()[:2]
    send_hour, send_minute = (int(p) for p in load_config().run.send_time.split(":"))
    assert (int(hour), int(minute)) < (send_hour, send_minute)


def test_stats_runs_after_the_european_settles() -> None:
    hour = int(STATS_CRON.split()[1])
    assert hour >= 20


def test_every_asset_has_a_retry_policy() -> None:
    for asset_def in ta_study_assets:
        policy = asset_def.op.retry_policy
        assert policy is not None, f"{_asset_keys(asset_def)} has no retry policy"
        assert policy.max_retries >= 1


def test_assets_share_one_group() -> None:
    groups: set[str] = set()
    for asset_def in ta_study_assets:
        groups |= set(asset_def.group_names_by_key.values())
    assert groups == {"ta_study"}


def test_schedule_status_follows_the_environment(monkeypatch) -> None:
    """Local runs must not come up RUNNING and mail the desk by surprise."""
    import importlib

    import ta_study.dagster_defs as module

    monkeypatch.setenv("DAGSTER_ENV", "local")
    importlib.reload(module)
    assert module.DEFAULT_SCHEDULE_STATUS == dagster.DefaultScheduleStatus.STOPPED

    monkeypatch.setenv("DAGSTER_ENV", "production")
    importlib.reload(module)
    assert module.DEFAULT_SCHEDULE_STATUS == dagster.DefaultScheduleStatus.RUNNING

    monkeypatch.delenv("DAGSTER_ENV", raising=False)
    importlib.reload(module)


def test_dry_run_and_recipient_overrides_read_the_environment(monkeypatch) -> None:
    import ta_study.dagster_defs as module

    monkeypatch.setenv("EMAIL_DRY_RUN", "true")
    assert module._dry_run() is True
    monkeypatch.setenv("EMAIL_DRY_RUN", "false")
    assert module._dry_run() is False

    monkeypatch.delenv("EMAIL_OVERRIDE", raising=False)
    assert module._recipients() is None
    monkeypatch.setenv("EMAIL_OVERRIDE", "a@x.com, b@x.com")
    assert module._recipients() == ["a@x.com", "b@x.com"]


def test_base_dir_and_config_overrides(monkeypatch, tmp_path) -> None:
    import ta_study.dagster_defs as module

    monkeypatch.delenv("TA_STUDY_BASE_DIR", raising=False)
    assert module._base_dir() == module.Path(os.getcwd())

    monkeypatch.setenv("TA_STUDY_BASE_DIR", str(tmp_path))
    assert module._base_dir() == tmp_path

    monkeypatch.delenv("TA_STUDY_CONFIG", raising=False)
    assert module._config_path() is None
    monkeypatch.setenv("TA_STUDY_CONFIG", str(tmp_path / "c.yaml"))
    assert module._config_path() == tmp_path / "c.yaml"


def test_metadata_coercion_covers_every_value_type() -> None:
    import ta_study.dagster_defs as module

    out = module._metadata(
        {
            "flag": True,
            "count": 3,
            "ratio": 0.5,
            "items": ["a", "b"],
            "mapping": {"k": 1},
            "text": "hello",
            "path": module.Path("x/y"),
        }
    )
    assert isinstance(out["flag"], dagster.BoolMetadataValue)
    assert isinstance(out["count"], dagster.IntMetadataValue)
    assert isinstance(out["ratio"], dagster.FloatMetadataValue)
    assert isinstance(out["items"], dagster.JsonMetadataValue)
    assert isinstance(out["mapping"], dagster.JsonMetadataValue)
    assert isinstance(out["text"], dagster.TextMetadataValue)
    assert isinstance(out["path"], dagster.PathMetadataValue)


def test_bool_is_not_coerced_to_int() -> None:
    """``isinstance(True, int)`` is True in Python; order matters."""
    import ta_study.dagster_defs as module

    out = module._metadata({"flag": False})
    assert isinstance(out["flag"], dagster.BoolMetadataValue)
