"""Secondary indicators: EMA stack, crossovers, Bollinger, ranges, candles."""

from __future__ import annotations

import numpy as np
import pytest

from ta_study.secondary import (
    NEW_EVENT_BARS,
    compute_secondary,
    crossovers,
    ema_regime,
)
from ta_study.study import compute_series, run_study
from ta_study.tests.conftest import bars_frame


def _series(close: np.ndarray, cfg):
    return compute_series(bars_frame(close), cfg, "TEST")


# ---------------------------------------------------------------------------
# regime labelling
# ---------------------------------------------------------------------------
def test_ema_regime_labels() -> None:
    assert ema_regime(110.0, 105.0, 100.0) == "bull-stacked"
    assert ema_regime(100.0, 105.0, 110.0) == "bear-stacked"
    assert ema_regime(105.0, 100.0, 110.0) == "mixed"
    assert ema_regime(float("nan"), 100.0, 110.0) == "na"


def test_regime_is_na_before_the_slow_ema_warms_up(cfg) -> None:
    """A 150-bar window cannot have an EMA200, so there is no stack to label."""
    close = np.linspace(100.0, 150.0, 150)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.regime == "na"
    assert not np.isfinite(sec.ema[200])


def test_bull_stack_on_a_long_uptrend(cfg) -> None:
    close = np.linspace(100.0, 300.0, 400)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.regime == "bull-stacked"
    assert sec.ema[20] > sec.ema[50] > sec.ema[200]


def test_bear_stack_on_a_long_downtrend(cfg) -> None:
    close = np.linspace(300.0, 100.0, 400)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.regime == "bear-stacked"


# ---------------------------------------------------------------------------
# crossovers
# ---------------------------------------------------------------------------
def test_crossover_direction_and_bar() -> None:
    fast = np.array([1.0, 1.0, 3.0, 3.0, 1.0])
    slow = np.array([2.0, 2.0, 2.0, 2.0, 2.0])
    crosses = crossovers(fast, slow, "20/50")
    assert [(c.bar, c.direction) for c in crosses] == [(2, 1), (4, -1)]


def test_touch_and_separate_emits_one_cross_not_two() -> None:
    """Equality on the previous bar counts as 'not yet crossed'."""
    fast = np.array([1.0, 2.0, 3.0])
    slow = np.array([2.0, 2.0, 2.0])
    crosses = crossovers(fast, slow, "20/50")
    assert len(crosses) == 1
    assert crosses[0].bar == 2


def test_crossover_ignores_nan_warmup() -> None:
    fast = np.array([np.nan, np.nan, 1.0, 3.0])
    slow = np.array([np.nan, 2.0, 2.0, 2.0])
    crosses = crossovers(fast, slow, "20/50")
    assert [c.bar for c in crosses] == [3]


def test_cross_labels_read_as_golden_and_death() -> None:
    up = crossovers(np.array([1.0, 3.0]), np.array([2.0, 2.0]), "50/200")
    assert "golden" in up[0].label and "50/200" in up[0].label

    down = crossovers(np.array([3.0, 1.0]), np.array([2.0, 2.0]), "50/200")
    assert "death" in down[0].label


def test_ma_cross_new_only_for_recent_crosses(cfg) -> None:
    # Rise then fall, so the EMA20/50 cross happens well before the last bar.
    close = np.concatenate([np.linspace(100.0, 200.0, 250), np.linspace(200.0, 120.0, 150)])
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.crosses, "a reversal this size must cross the EMAs"
    for cross in sec.recent_crosses:
        assert close.size - 1 - cross.bar < NEW_EVENT_BARS


# ---------------------------------------------------------------------------
# MACD, Bollinger, ranges
# ---------------------------------------------------------------------------
def test_macd_hist_sign_reported(cfg) -> None:
    close = np.linspace(100.0, 200.0, 300)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.macd_hist_sign in {"+", "-", "0"}
    assert np.isfinite(sec.macd_hist)


def test_percent_b_flags_a_break_above_the_upper_band(cfg) -> None:
    close = np.concatenate([np.full(100, 100.0), np.array([140.0])])
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.bb_outside == 1
    assert "above upper" in sec.bb_label


def test_percent_b_flags_a_break_below_the_lower_band(cfg) -> None:
    close = np.concatenate([np.full(100, 100.0), np.array([60.0])])
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.bb_outside == -1
    assert "below lower" in sec.bb_label


def test_range_stats_on_a_long_series(cfg) -> None:
    close = np.linspace(100.0, 200.0, 300)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert 52 in sec.ranges and 252 in sec.ranges
    r52 = sec.ranges[52]
    assert r52.high > r52.low
    # A monotone rise makes a new high on its last bar, so the bar's own high
    # is the window high. (Its close is not: the close sits below the high.)
    assert r52.at_high
    assert not r52.at_low
    assert r52.pct_of_range == pytest.approx(1.0, abs=0.05)


def test_at_low_on_a_monotone_decline(cfg) -> None:
    close = np.linspace(200.0, 100.0, 300)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    r52 = sec.ranges[52]
    assert r52.at_low
    assert not r52.at_high


def test_range_flags_are_false_mid_range(cfg) -> None:
    # Rise, fall, recover, then ease off, so the final bar is neither the
    # window high nor its low.
    close = np.concatenate(
        [
            np.linspace(100.0, 200.0, 200),
            np.linspace(200.0, 150.0, 40),
            np.linspace(150.0, 175.0, 25),
            np.linspace(175.0, 165.0, 10),
        ]
    )
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    r52 = sec.ranges[52]
    assert not r52.at_high and not r52.at_low
    assert 0.0 < r52.pct_of_range < 1.0


def test_range_windows_are_skipped_when_too_short(cfg) -> None:
    close = np.linspace(100.0, 150.0, 100)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert 52 in sec.ranges
    assert 252 not in sec.ranges


def test_ranges_and_candles_skipped_off_the_daily_horizon(cfg) -> None:
    close = np.linspace(100.0, 200.0, 300)
    sec = compute_secondary(
        _series(close, cfg), cfg, "TEST", "1H", daily_ranges=False
    )
    assert sec.ranges == {}
    assert sec.candle_tags == []


def test_candles_flagged_unavailable_without_talib(cfg) -> None:
    from ta_study import indicators as ind

    close = np.linspace(100.0, 200.0, 300)
    sec = compute_secondary(_series(close, cfg), cfg, "TEST", "D")
    assert sec.candles_available == ind.talib_available()
    if not ind.talib_available():
        assert sec.candle_tags == []


def test_secondary_on_an_empty_series(cfg) -> None:
    import polars as pl

    from ta_study.data import empty_bars

    series = compute_series(
        empty_bars().with_columns(pl.lit(None, dtype=pl.Float64).alias("close_adj")),
        cfg,
        "TEST",
    )
    sec = compute_secondary(series, cfg, "TEST", "D")
    assert sec.regime == "na"
    assert not sec.ma_cross_new


def test_distance_from_ema_is_in_atr_units(cfg) -> None:
    close = np.linspace(100.0, 200.0, 300)
    series = _series(close, cfg)
    sec = compute_secondary(series, cfg, "TEST", "D")
    expected = (series.at(series.close_study) - sec.ema[20]) / series.at(series.atr)
    assert sec.dist_atr[20] == pytest.approx(expected)


def test_secondary_runs_off_a_study_result(cfg) -> None:
    """The pipeline hands it ``result.series``; that path must work too."""
    close = np.linspace(100.0, 250.0, 300)
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    sec = compute_secondary(result.series, cfg, "TEST", "D")
    assert sec.product == "TEST"
    assert sec.regime in {"bull-stacked", "bear-stacked", "mixed", "na"}
