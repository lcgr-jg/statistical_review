"""Shared fixtures: synthetic series with known, hand-built structure.

The series here are piecewise-linear on purpose. A random walk would make the
divergence assertions probabilistic; a ramp lets every test say exactly which
bar the swing sits on and exactly how many events the engine must emit.
"""

from __future__ import annotations

import datetime as dt

import numpy as np
import polars as pl
import pytest

from ta_study.config import (
    HorizonConfig,
    ProductConfig,
    RunConfig,
    StudyConfig,
)


def ramp(start: float, stop: float, n: int) -> list[float]:
    """``n`` bars moving linearly to ``stop``, excluding the starting point."""
    return list(np.linspace(start, stop, n + 1))[1:]


def bars_frame(
    close: np.ndarray,
    start: dt.datetime | None = None,
    freq_days: int = 1,
    roll_bars: tuple[int, ...] = (),
    spread: float = 0.5,
) -> pl.DataFrame:
    """Canonical bar frame around a close series."""
    n = close.size
    origin = start or dt.datetime(2024, 1, 1)
    ts = [origin + dt.timedelta(days=i * freq_days) for i in range(n)]
    return pl.DataFrame(
        {
            "ts": ts,
            "open": close - spread * 0.4,
            "high": close + spread,
            "low": close - spread,
            "close": close,
            "volume": np.full(n, 1_000.0),
            "is_roll": [i in roll_bars for i in range(n)],
        }
    )


# ---------------------------------------------------------------------------
# hand-built series
# ---------------------------------------------------------------------------
def bearish_divergence_close() -> np.ndarray:
    """One textbook bearish divergence and nothing else.

    Peak at bar 20 (price 120, RSI 100 - an unbroken run of gains), trough at
    28, higher peak at bar 37 (price 121) whose RSI is far lower because of
    the intervening decline. Monotone thereafter, so no further swing highs
    form and the engine must emit exactly one event.
    """
    close = [100.0]
    close += ramp(100, 120, 20)   # bars 1..20  -> swing high at 20
    close += ramp(120, 112, 8)    # bars 21..28 -> swing low at 28
    close += ramp(112, 121, 9)    # bars 29..37 -> higher swing high at 37
    close += ramp(121, 100, 33)   # bars 38..70 -> monotone, no more highs
    return np.array(close, dtype=float)


def same_slope_close() -> np.ndarray:
    """A higher high with a *higher* RSI - price and RSI slopes agree.

    Opens with a decline so the first high is not pinned at RSI 100 (an
    unbroken run of gains leaves RSI nowhere to go but down, which would
    manufacture a divergence by construction). Highs land at bar 30
    (RSI ~40) and bar 55 (RSI ~90): price up, RSI up, so no regular
    divergence - and the lows move the same way, so no hidden one either.
    """
    close = [120.0]
    close += ramp(120, 100, 20)   # decline      -> swing low at 20
    close += ramp(100, 106, 10)   # modest rise  -> swing high at 30, RSI ~40
    close += ramp(106, 104, 8)    # shallow dip  -> swing low at 38
    close += ramp(104, 125, 17)   # strong rally -> higher high at 55, RSI ~90
    close += ramp(125, 112, 15)
    return np.array(close, dtype=float)


def moderate_bearish_divergence_close() -> np.ndarray:
    """A bearish divergence whose first swing RSI is mid-range (~79).

    ``bearish_divergence_close`` puts S1 at RSI 100, which makes the zone
    filter untestable - no threshold can sit above it. Here S1 is at ~79, so
    ``ob_soft`` can be set either side of it.
    """
    close = [110.0]
    close += ramp(110, 100, 15)   # decline -> swing low at 15
    close += ramp(100, 118, 15)   # rise    -> swing high at 30, RSI ~79
    close += ramp(118, 110, 10)   # fall    -> swing low at 40
    close += ramp(110, 119, 12)   # rise    -> higher high at 52, RSI ~74
    close += ramp(119, 105, 18)
    return np.array(close, dtype=float)


def bullish_divergence_close() -> np.ndarray:
    """The mirror image: lower low on price, higher low on RSI."""
    close = [130.0]
    close += ramp(130, 110, 20)   # swing low at 20, RSI 0
    close += ramp(110, 118, 8)    # swing high at 28
    close += ramp(118, 109, 9)    # lower swing low at 37, RSI higher
    close += ramp(109, 130, 33)
    return np.array(close, dtype=float)


# ---------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def cfg() -> StudyConfig:
    """Default config with one product and one daily horizon."""
    return StudyConfig(
        run=RunConfig(
            recipients=["desk@example.com"],
            min_bars=60,
            chart_workers=0,
            include_thumbnail_strip=True,
        ),
        horizons=[HorizonConfig(name="D", source="daily", bars=400)],
        products=[ProductConfig(name="TEST", ticker="T1 Comdty", group="gas")],
    )


@pytest.fixture
def multi_horizon_cfg() -> StudyConfig:
    return StudyConfig(
        run=RunConfig(recipients=["desk@example.com"], min_bars=60, chart_workers=0),
        horizons=[
            HorizonConfig(name="W", source="daily", resample="1W-FRI", bars=300),
            HorizonConfig(name="D", source="daily", bars=400),
            HorizonConfig(name="4H", source="intraday", interval_min=240, bars=400),
            HorizonConfig(name="1H", source="intraday", interval_min=60, bars=400),
        ],
        products=[
            ProductConfig(name="TTF", ticker="TZT1 Comdty", group="gas", adx_threshold=35),
            ProductConfig(name="BRENT", ticker="CO1 Comdty", group="oil"),
        ],
    )


@pytest.fixture
def bearish_close() -> np.ndarray:
    return bearish_divergence_close()


@pytest.fixture
def bearish_bars(bearish_close: np.ndarray) -> pl.DataFrame:
    return bars_frame(bearish_close)


@pytest.fixture
def long_series() -> np.ndarray:
    """~210 bars containing several divergences, ending inside an active one.

    Used wherever a test needs the state machine to have actually moved
    through its states rather than sitting on NONE.
    """
    close = [100.0]
    close += ramp(100, 120, 20)
    close += ramp(120, 112, 8)
    close += ramp(112, 121, 9)
    close += ramp(121, 100, 33)
    close += ramp(100, 118, 40)
    close += ramp(118, 108, 15)
    close += ramp(108, 125, 30)
    close += ramp(125, 115, 20)
    close += ramp(115, 130, 14)
    close += ramp(130, 122, 7)
    close += ramp(122, 131, 8)
    close += ramp(131, 127, 6)
    arr = np.array(close, dtype=float)
    # A touch of deterministic noise so no two bars are exactly equal, which
    # would otherwise exercise the tie rule everywhere at once.
    rng = np.random.default_rng(0)
    return arr + rng.normal(0, 0.08, arr.size)


@pytest.fixture
def long_bars(long_series: np.ndarray) -> pl.DataFrame:
    return bars_frame(long_series, roll_bars=(60, 120))
