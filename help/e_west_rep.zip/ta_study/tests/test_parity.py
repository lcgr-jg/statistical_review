"""Backend parity (§14): RSI, STOCH, ADX, MACD, BBANDS, ATR.

The spec asks for TA-Lib versus pandas-ta parity to 1e-6. Neither is
installed in the ``corelib`` environment, so those comparisons skip. What
does not skip is the pandas reference in :mod:`ta_study.reference`, which
computes the same definitions through ``rolling``/``ewm`` rather than the
explicit recursions in :mod:`ta_study.indicators` - a genuine independent
check that runs everywhere.

When TA-Lib or pandas-ta is later installed, these tests start asserting
against them with no code change.
"""

from __future__ import annotations

import numpy as np
import pytest

from ta_study import indicators as ind
from ta_study import reference as ref

TOL = 1e-6

#: A series with trends, reversals and a flat stretch - the flat part is
#: where degenerate-range handling differs between implementations.
def _prices() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(12345)
    steps = rng.normal(0.0, 1.0, 400)
    close = 100.0 + np.cumsum(steps)
    close[150:160] = close[150]          # deliberate flat window
    high = close + np.abs(rng.normal(0.6, 0.2, 400))
    low = close - np.abs(rng.normal(0.6, 0.2, 400))
    return high, low, close


HIGH, LOW, CLOSE = _prices()


def _compare(mine: np.ndarray, theirs: np.ndarray, tol: float = TOL) -> None:
    """Compare on the region where both are finite, and require overlap."""
    both = np.isfinite(mine) & np.isfinite(theirs)
    assert both.sum() > 50, f"too little overlap to be meaningful ({both.sum()} bars)"
    assert np.allclose(mine[both], theirs[both], atol=tol, rtol=0.0), (
        f"max abs diff {np.max(np.abs(mine[both] - theirs[both]))}"
    )


def _warmup_matches(mine: np.ndarray, theirs: np.ndarray) -> None:
    """The first finite index must agree, or a backend swap shifts signals."""
    mine_first = int(np.flatnonzero(np.isfinite(mine))[0])
    theirs_first = int(np.flatnonzero(np.isfinite(theirs))[0])
    assert mine_first == theirs_first, (
        f"warm-up differs: mine {mine_first}, reference {theirs_first}"
    )


# ---------------------------------------------------------------------------
# pandas reference - always runs
# ---------------------------------------------------------------------------
def test_rsi_matches_the_pandas_reference() -> None:
    mine = ind.rsi(CLOSE, 14)
    theirs = ref.pandas_rsi(CLOSE, 14)
    _warmup_matches(mine, theirs)
    _compare(mine, theirs)


def test_ema_matches_the_pandas_reference() -> None:
    for period in (20, 50, 200):
        mine = ind.ema(CLOSE, period)
        theirs = ref.pandas_ema(CLOSE, period)
        _warmup_matches(mine, theirs)
        _compare(mine, theirs)


def test_sma_matches_the_pandas_reference() -> None:
    mine = ind.sma(CLOSE, 20)
    theirs = ref.pandas_sma(CLOSE, 20)
    _warmup_matches(mine, theirs)
    _compare(mine, theirs)


def test_atr_matches_the_pandas_reference() -> None:
    mine = ind.atr(HIGH, LOW, CLOSE, 14)
    theirs = ref.pandas_atr(HIGH, LOW, CLOSE, 14)
    _warmup_matches(mine, theirs)
    _compare(mine, theirs)


def test_stoch_matches_the_pandas_reference() -> None:
    mine = ind.stoch(HIGH, LOW, CLOSE, 14, 3, 3)
    k_ref, d_ref = ref.pandas_stoch(HIGH, LOW, CLOSE, 14, 3, 3)
    _warmup_matches(mine.k, k_ref)
    _warmup_matches(mine.d, d_ref)
    _compare(mine.k, k_ref)
    _compare(mine.d, d_ref)


def test_bbands_match_the_pandas_reference() -> None:
    mine = ind.bbands(CLOSE, 20, 2.0)
    upper, middle, lower = ref.pandas_bbands(CLOSE, 20, 2.0)
    _warmup_matches(mine.middle, middle)
    _compare(mine.upper, upper)
    _compare(mine.middle, middle)
    _compare(mine.lower, lower)


def test_macd_matches_the_pandas_reference() -> None:
    mine = ind.macd(CLOSE, 12, 26, 9)
    line, signal, hist = ref.pandas_macd(CLOSE, 12, 26, 9)
    _compare(mine.line, line)
    _compare(mine.signal, signal)
    _compare(mine.hist, hist)


def test_dmi_matches_the_pandas_reference() -> None:
    mine = ind.dmi(HIGH, LOW, CLOSE, 14)
    plus_di, minus_di, adx = ref.pandas_dmi(HIGH, LOW, CLOSE, 14)
    _warmup_matches(mine.plus_di, plus_di)
    _warmup_matches(mine.adx, adx)
    _compare(mine.plus_di, plus_di)
    _compare(mine.minus_di, minus_di)
    _compare(mine.adx, adx)


# ---------------------------------------------------------------------------
# TA-Lib - skipped until installed
# ---------------------------------------------------------------------------
talib_required = pytest.mark.skipif(
    ref.talib_module() is None, reason="TA-Lib is not installed"
)


@talib_required
def test_rsi_matches_talib() -> None:
    theirs = ref.talib_rsi(CLOSE, 14)
    assert theirs is not None
    mine = ind.rsi(CLOSE, 14)
    _warmup_matches(mine, theirs)
    _compare(mine, theirs)


@talib_required
def test_stoch_matches_talib() -> None:
    result = ref.talib_stoch(HIGH, LOW, CLOSE, 14, 3, 3)
    assert result is not None
    k_ref, d_ref = result
    mine = ind.stoch(HIGH, LOW, CLOSE, 14, 3, 3)

    # The flat window is the one place the definitions differ by design:
    # §8a E puts %K at 50 on a zero-range look-back, TA-Lib emits 0.
    flat = ~np.isfinite(mine.k_raw) | (
        ind.rolling_max(HIGH, 14) == ind.rolling_min(LOW, 14)
    )
    mask = ~flat
    _compare(np.where(mask, mine.k, np.nan), np.where(mask, k_ref, np.nan))
    _compare(np.where(mask, mine.d, np.nan), np.where(mask, d_ref, np.nan))


@talib_required
def test_adx_matches_talib() -> None:
    result = ref.talib_dmi(HIGH, LOW, CLOSE, 14)
    assert result is not None
    plus_di, minus_di, adx = result
    mine = ind.dmi(HIGH, LOW, CLOSE, 14)
    _warmup_matches(mine.plus_di, plus_di)
    _warmup_matches(mine.adx, adx)
    _compare(mine.plus_di, plus_di)
    _compare(mine.minus_di, minus_di)
    _compare(mine.adx, adx)


@talib_required
def test_macd_matches_talib() -> None:
    result = ref.talib_macd(CLOSE, 12, 26, 9)
    assert result is not None
    line, signal, hist = result
    mine = ind.macd(CLOSE, 12, 26, 9)
    _compare(mine.line, line)
    _compare(mine.signal, signal)
    _compare(mine.hist, hist)


@talib_required
def test_bbands_match_talib() -> None:
    result = ref.talib_bbands(CLOSE, 20, 2.0)
    assert result is not None
    upper, middle, lower = result
    mine = ind.bbands(CLOSE, 20, 2.0)
    _warmup_matches(mine.middle, middle)
    _compare(mine.upper, upper)
    _compare(mine.middle, middle)
    _compare(mine.lower, lower)


@talib_required
def test_atr_matches_talib() -> None:
    theirs = ref.talib_atr(HIGH, LOW, CLOSE, 14)
    assert theirs is not None
    mine = ind.atr(HIGH, LOW, CLOSE, 14)
    _warmup_matches(mine, theirs)
    _compare(mine, theirs)


# ---------------------------------------------------------------------------
# pandas-ta - skipped until installed
# ---------------------------------------------------------------------------
pandas_ta_required = pytest.mark.skipif(
    ref.pandas_ta_module() is None, reason="pandas-ta is not installed"
)


@pandas_ta_required
def test_rsi_matches_pandas_ta() -> None:
    theirs = ref.pandas_ta_rsi(CLOSE, 14)
    assert theirs is not None
    _compare(ind.rsi(CLOSE, 14), theirs)


@pandas_ta_required
def test_adx_matches_pandas_ta() -> None:
    theirs = ref.pandas_ta_adx(HIGH, LOW, CLOSE, 14)
    assert theirs is not None
    _compare(ind.dmi(HIGH, LOW, CLOSE, 14).adx, theirs)


# ---------------------------------------------------------------------------
# meta
# ---------------------------------------------------------------------------
def test_pandas_backend_is_always_available() -> None:
    assert "pandas" in ref.available_backends()


def test_talib_availability_is_reported_consistently() -> None:
    assert ind.talib_available() == (ref.talib_module() is not None)
