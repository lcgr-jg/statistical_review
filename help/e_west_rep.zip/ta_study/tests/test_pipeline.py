"""End-to-end pipeline runs against known bars, plus the maintenance jobs.

``bars_provider`` stands in for Bloomberg and Snowflake, so these exercise
the real study, charting, email and persistence path without an entitlement.
"""

from __future__ import annotations

import datetime as dt
import json
import logging

import numpy as np
import polars as pl
import pytest

from ta_study.config import (
    HorizonConfig,
    PersistConfig,
    ProductConfig,
    RunConfig,
    StudyConfig,
)
from ta_study.data import normalise_intraday
from ta_study.pipeline import (
    JsonFormatter,
    RunResult,
    backfill_study_state,
    configure_logging,
    run_ta_study,
)
from ta_study.tests.conftest import bars_frame, ramp


# ---------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------
def _trending_close(n: int = 320, seed: int = 1) -> np.ndarray:
    close = [100.0]
    close += ramp(100, 130, 40)
    close += ramp(130, 118, 20)
    close += ramp(118, 133, 30)
    close += ramp(133, 105, 50)
    close += ramp(105, 125, 45)
    close += ramp(125, 112, 25)
    close += ramp(112, 128, 35)
    close += ramp(128, 120, 20)
    arr = np.array(close, dtype=float)
    rng = np.random.default_rng(seed)
    arr = arr + rng.normal(0, 0.15, arr.size)
    if arr.size < n:
        arr = np.concatenate([np.full(n - arr.size, arr[0]), arr])
    return arr[-n:]


def _hourly_frame(n: int, seed: int = 2) -> pl.DataFrame:
    close = _trending_close(n, seed=seed)
    start = dt.datetime(2026, 1, 5, 8, 0)
    ts = [start + dt.timedelta(hours=i) for i in range(close.size)]
    return normalise_intraday(
        pl.DataFrame(
            {
                "ts": ts,
                "open": close - 0.1,
                "high": close + 0.4,
                "low": close - 0.4,
                "close": close,
                "volume": np.full(close.size, 500.0),
            }
        )
    )


@pytest.fixture
def two_product_cfg(tmp_path) -> StudyConfig:
    return StudyConfig(
        run=RunConfig(
            recipients=["desk@example.com"],
            min_bars=60,
            chart_workers=0,
            include_thumbnail_strip=True,
            output_dir="output",
            cache_dir="cache",
        ),
        horizons=[
            HorizonConfig(name="W", source="daily", resample="1W-FRI", bars=300),
            HorizonConfig(name="D", source="daily", bars=400),
        ],
        products=[
            ProductConfig(name="TTF", ticker="TZT1 Comdty", group="gas", adx_threshold=35),
            ProductConfig(name="BRENT", ticker="CO1 Comdty", group="oil"),
        ],
        persist=PersistConfig(enabled=False, local_state_dir="state"),
    )


@pytest.fixture
def config_file(tmp_path, two_product_cfg):
    """Write the fixture config to YAML so run_ta_study can load it."""
    import yaml

    payload = json.loads(two_product_cfg.model_dump_json(by_alias=True))
    path = tmp_path / "ta_products.yaml"
    path.write_text(yaml.safe_dump(payload), encoding="utf-8")
    return path


def _provider(daily_bars: dict[str, pl.DataFrame], intraday: dict | None = None):
    def provide(cfg, as_of):
        return daily_bars, intraday or {name: pl.DataFrame() for name in daily_bars}

    return provide


@pytest.fixture
def daily_bars():
    start = dt.datetime(2025, 1, 1)
    return {
        "TTF": bars_frame(_trending_close(320, seed=1), start=start),
        "BRENT": bars_frame(_trending_close(320, seed=7), start=start),
    }


# ---------------------------------------------------------------------------
# a full dry run
# ---------------------------------------------------------------------------
def test_dry_run_writes_html_and_charts(tmp_path, config_file, daily_bars) -> None:
    result = run_ta_study(
        config_path=config_file,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        bars_provider=_provider(daily_bars),
    )

    assert isinstance(result, RunResult)
    assert result.sent_via is None, "a dry run must not send"
    assert result.html_path is not None and result.html_path.exists()

    html = result.html_path.read_text(encoding="utf-8")
    assert "Signal grid" in html
    assert "TTF" in html and "BRENT" in html

    # 2 products x 2 horizons.
    assert len(result.results) == 4
    assert {r.horizon for r in result.results} == {"W", "D"}

    # Charts landed on disk and every one is a real PNG.
    assert result.chart_dir is not None and result.chart_dir.exists()
    pngs = list(result.chart_dir.glob("*.png"))
    assert pngs
    for png in pngs:
        assert png.read_bytes().startswith(b"\x89PNG")


def test_metadata_is_json_serialisable(tmp_path, config_file, daily_bars) -> None:
    """Dagster metadata and the CLI both round-trip this."""
    result = run_ta_study(
        config_path=config_file,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        bars_provider=_provider(daily_bars),
    )
    payload = result.to_metadata()
    encoded = json.dumps(payload)
    assert json.loads(encoded)["run_date"] == "2026-09-18"
    assert payload["n_pairs"] == 4
    assert payload["dry_run"] is True
    assert payload["email_sent"] is False
    assert payload["elapsed_s"] >= 0


def test_state_mirror_enables_change_detection(tmp_path, config_file, daily_bars) -> None:
    """The second run must know what the first one said."""
    kwargs = {
        "config_path": config_file,
        "dry_run": True,
        "base_dir": tmp_path,
        "no_parallel": True,
        "bars_provider": _provider(daily_bars),
    }
    first = run_ta_study(as_of=dt.date(2026, 9, 17), **kwargs)
    assert all(r.prev_state is None for r in first.results)

    state_file = tmp_path / "state" / "ta_study_state.json"
    assert state_file.exists()
    stored = json.loads(state_file.read_text(encoding="utf-8"))
    assert len(stored) == 4

    second = run_ta_study(as_of=dt.date(2026, 9, 18), **kwargs)
    assert all(r.prev_state is not None for r in second.results)
    # Same bars in, same states out: nothing should be reported as changed.
    assert [r.state for r in second.results] == [r.state for r in first.results]
    assert not any(r.changed for r in second.results)


def test_rerun_for_the_same_date_is_deterministic(tmp_path, config_file, daily_bars) -> None:
    """§15: --date reruns are deterministic."""
    kwargs = {
        "config_path": config_file,
        "as_of": dt.date(2026, 9, 18),
        "dry_run": True,
        "base_dir": tmp_path,
        "no_parallel": True,
        "bars_provider": _provider(daily_bars),
    }
    first = run_ta_study(**kwargs)
    second = run_ta_study(**kwargs)

    assert first.subject == second.subject
    assert [r.state for r in first.results] == [r.state for r in second.results]
    assert [
        round(r.size_multiplier, 12) for r in first.results
    ] == [round(r.size_multiplier, 12) for r in second.results]


def test_product_and_horizon_filters(tmp_path, config_file, daily_bars) -> None:
    result = run_ta_study(
        config_path=config_file,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        products=["TTF"],
        horizons=["D"],
        bars_provider=_provider(daily_bars),
    )
    assert len(result.results) == 1
    assert result.results[0].key == ("TTF", "D")


def test_no_matching_pairs_raises(tmp_path, config_file, daily_bars) -> None:
    with pytest.raises(ValueError, match="no \\(product, horizon\\) pairs selected"):
        run_ta_study(
            config_path=config_file,
            dry_run=True,
            base_dir=tmp_path,
            products=["NOT_A_PRODUCT"],
            bars_provider=_provider(daily_bars),
        )


def test_no_usable_bars_raises(tmp_path, config_file) -> None:
    """Nothing to say is the one case allowed to fail the run."""
    empty = {"TTF": pl.DataFrame(), "BRENT": pl.DataFrame()}
    with pytest.raises(RuntimeError, match="no \\(product, horizon\\) produced"):
        run_ta_study(
            config_path=config_file,
            dry_run=True,
            base_dir=tmp_path,
            bars_provider=_provider(empty),
        )


def test_one_thin_product_degrades_rather_than_failing(
    tmp_path, config_file, daily_bars
) -> None:
    thin = dict(daily_bars)
    thin["BRENT"] = bars_frame(np.linspace(80.0, 82.0, 12))
    result = run_ta_study(
        config_path=config_file,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        bars_provider=_provider(thin),
    )
    assert any(r.product == "TTF" for r in result.results)
    assert result.warnings
    assert any("BRENT" in w for w in result.warnings)


def test_recipients_override_is_honoured(tmp_path, config_file, daily_bars) -> None:
    result = run_ta_study(
        config_path=config_file,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        recipients=["override@example.com"],
        bars_provider=_provider(daily_bars),
    )
    assert result.recipients == ["override@example.com"]


def test_intraday_horizon_runs_off_provided_hourly_bars(tmp_path, daily_bars) -> None:
    import yaml

    cfg = StudyConfig(
        run=RunConfig(recipients=["d@e.com"], min_bars=60, chart_workers=0),
        horizons=[
            HorizonConfig(name="D", source="daily", bars=400),
            HorizonConfig(name="4H", source="intraday", interval_min=240, bars=400),
            HorizonConfig(name="1H", source="intraday", interval_min=60, bars=400),
        ],
        products=[ProductConfig(name="TTF", ticker="TZT1 Comdty", group="gas")],
        persist=PersistConfig(enabled=False),
    )
    path = tmp_path / "cfg.yaml"
    path.write_text(
        yaml.safe_dump(json.loads(cfg.model_dump_json(by_alias=True))), encoding="utf-8"
    )

    hourly = {"TTF": _hourly_frame(1200)}
    result = run_ta_study(
        config_path=path,
        as_of=dt.date(2026, 9, 18),
        dry_run=True,
        base_dir=tmp_path,
        no_parallel=True,
        bars_provider=_provider({"TTF": daily_bars["TTF"]}, hourly),
    )
    horizons = {r.horizon for r in result.results}
    assert horizons == {"D", "4H", "1H"}
    # 1200 hourly bars aggregate to ~300 four-hour bars.
    four_hour = next(r for r in result.results if r.horizon == "4H")
    assert 250 < four_hour.n_bars <= 400


# ---------------------------------------------------------------------------
# backfill
# ---------------------------------------------------------------------------
def test_backfill_replays_without_lookahead(tmp_path, config_file, daily_bars) -> None:
    """The assertion inside backfill is §8a I in operational form."""
    summary = backfill_study_state(
        start=dt.date(2026, 9, 14),
        end=dt.date(2026, 9, 18),
        config_path=config_file,
        base_dir=tmp_path,
        offline=True,
    )
    # Offline with no bar source means nothing to replay, but it must not raise.
    assert summary["start"] == "2026-09-14"
    assert summary["end"] == "2026-09-18"
    assert summary["dates"] >= 0


# ---------------------------------------------------------------------------
# logging
# ---------------------------------------------------------------------------
def test_json_formatter_emits_one_object_per_line() -> None:
    record = logging.LogRecord(
        name="ta_study.test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="fetching %s",
        args=("bars",),
        exc_info=None,
    )
    record.product = "TTF"  # type: ignore[attr-defined]
    record.horizon = "4H"  # type: ignore[attr-defined]
    record.stage = "bars_intraday"  # type: ignore[attr-defined]

    payload = json.loads(JsonFormatter().format(record))
    assert payload["msg"] == "fetching bars"
    assert payload["level"] == "INFO"
    assert payload["product"] == "TTF"
    assert payload["horizon"] == "4H"
    assert payload["stage"] == "bars_intraday"
    assert "ts" in payload


def test_json_formatter_omits_absent_context() -> None:
    record = logging.LogRecord(
        name="x", level=logging.WARNING, pathname=__file__, lineno=1,
        msg="plain", args=(), exc_info=None,
    )
    payload = json.loads(JsonFormatter().format(record))
    assert "product" not in payload
    assert payload["msg"] == "plain"


def test_configure_logging_installs_a_single_handler() -> None:
    try:
        configure_logging(json_logs=True)
        root = logging.getLogger()
        assert len(root.handlers) == 1
        assert isinstance(root.handlers[0].formatter, JsonFormatter)

        configure_logging(json_logs=False)
        assert not isinstance(logging.getLogger().handlers[0].formatter, JsonFormatter)
    finally:
        logging.getLogger().handlers = []
