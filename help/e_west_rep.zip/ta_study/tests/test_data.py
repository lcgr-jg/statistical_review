"""Bar assembly: roll flags, weekly resampling, session alignment, adjustment."""

from __future__ import annotations

import datetime as dt
import itertools

import numpy as np
import polars as pl
import pytest

from ta_study.config import HorizonConfig, ProductConfig
from ta_study.data import (
    apply_roll_adjustment,
    back_adjust_factors,
    build_horizon,
    empty_bars,
    mark_intraday_rolls,
    merge_intraday,
    normalise_daily,
    resample_intraday,
    resample_weekly,
    roll_flags,
    to_pandas,
)
from ta_study.tests.conftest import bars_frame


# ---------------------------------------------------------------------------
# roll detection
# ---------------------------------------------------------------------------
def test_roll_flags_marks_contract_changes_only() -> None:
    series = pl.Series(["Z4", "Z4", "H5", "H5", "M5"])
    assert roll_flags(series) == [False, False, True, False, True]


def test_first_bar_is_never_a_roll() -> None:
    assert roll_flags(pl.Series(["Z4"])) == [False]


def test_nulls_do_not_count_as_a_change() -> None:
    series = pl.Series(["Z4", None, "Z4", "H5"])
    assert roll_flags(series) == [False, False, False, True]


def test_normalise_daily_builds_roll_flags_and_ts() -> None:
    raw = pl.DataFrame(
        {
            "date": [dt.date(2024, 1, i) for i in (2, 3, 4)],
            "open": [10.0, 11.0, 12.0],
            "high": [10.5, 11.5, 12.5],
            "low": [9.5, 10.5, 11.5],
            "close": [10.2, 11.2, 12.2],
            "volume": [100.0, 200.0, 300.0],
            "gen_ticker": ["Z4", "Z4", "H5"],
        }
    )
    out = normalise_daily(raw)
    assert out.columns == ["ts", "open", "high", "low", "close", "volume", "is_roll"]
    assert out.get_column("is_roll").to_list() == [False, False, True]
    assert out.get_column("ts").dtype == pl.Datetime("us")


def test_normalise_daily_drops_bars_with_no_close() -> None:
    raw = pl.DataFrame(
        {
            "date": [dt.date(2024, 1, i) for i in (2, 3, 4)],
            "open": [10.0, 11.0, 12.0],
            "high": [10.5, 11.5, 12.5],
            "low": [9.5, 10.5, 11.5],
            "close": [10.2, None, 12.2],
            "volume": [100.0, 200.0, 300.0],
        }
    )
    assert normalise_daily(raw).height == 2


def test_repair_ohlc_fills_partial_bars_from_the_close() -> None:
    """Regression: a bar with only a close broke five charts on the first
    live run, because mplfinance rejects differing NaN counts across O/H/L/C."""
    from ta_study.data import repair_ohlc

    bars = pl.DataFrame(
        {
            "open": [10.0, None, 12.0],
            "high": [10.5, None, 12.5],
            "low": [9.5, None, 11.5],
            "close": [10.2, 11.0, 12.2],
        }
    )
    out = repair_ohlc(bars)
    for col in ("open", "high", "low"):
        assert out.get_column(col).null_count() == 0
        assert out.get_column(col)[1] == pytest.approx(11.0)


def test_repair_ohlc_widens_extremes_to_enclose_open_and_close() -> None:
    """A feed reporting high < close must not yield an impossible candle."""
    from ta_study.data import repair_ohlc

    bars = pl.DataFrame(
        {
            "open": [10.0],
            "high": [10.1],   # below the close
            "low": [10.05],   # above the open
            "close": [10.5],
        }
    )
    row = repair_ohlc(bars).row(0, named=True)
    assert row["high"] == pytest.approx(10.5)
    assert row["low"] == pytest.approx(10.0)
    assert row["low"] <= row["open"] <= row["high"]
    assert row["low"] <= row["close"] <= row["high"]


def test_normalise_daily_repairs_partial_bars() -> None:
    raw = pl.DataFrame(
        {
            "date": [dt.date(2024, 1, i) for i in (2, 3, 4)],
            "open": [10.0, None, 12.0],
            "high": [10.5, None, 12.5],
            "low": [9.5, None, 11.5],
            "close": [10.2, 11.0, 12.2],
            "volume": [100.0, 200.0, 300.0],
        }
    )
    out = normalise_daily(raw)
    assert out.height == 3
    for col in ("open", "high", "low", "close"):
        assert out.get_column(col).null_count() == 0


def test_a_partial_bar_still_charts(cfg) -> None:
    """The end-to-end guard: mplfinance must accept the repaired frame."""
    from ta_study.charts import full_chart, thumbnail
    from ta_study.study import run_study

    close = np.linspace(100.0, 140.0, 200)
    bars = bars_frame(close)
    # Blank O/H/L on a handful of bars, as a thin contract does.
    for col in ("open", "high", "low"):
        values = bars.get_column(col).to_list()
        for i in (50, 51, 120):
            values[i] = None
        bars = bars.with_columns(pl.Series(col, values, dtype=pl.Float64))

    result = run_study(normalise_daily(bars), cfg, "TEST", "D")
    assert full_chart(result, cfg).startswith(b"\x89PNG")
    assert thumbnail(result, cfg).startswith(b"\x89PNG")


def test_normalise_daily_on_empty_keeps_the_schema() -> None:
    out = normalise_daily(pl.DataFrame())
    assert out.is_empty()
    assert out.columns == list(empty_bars().columns)


# ---------------------------------------------------------------------------
# weekly resampling - checked against pandas, which is the reference
# ---------------------------------------------------------------------------
def test_weekly_resample_matches_pandas_w_fri() -> None:
    n = 90
    close = np.linspace(100.0, 150.0, n)
    bars = bars_frame(close, start=dt.datetime(2024, 1, 1))
    weekly = resample_weekly(bars, "1W-FRI")

    pdf = bars.to_pandas().set_index("ts")
    expected = pdf.resample("W-FRI").agg(
        {
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "volume": "sum",
        }
    ).dropna()

    assert weekly.height == len(expected)
    assert np.allclose(weekly.get_column("close").to_numpy(), expected["close"].to_numpy())
    assert np.allclose(weekly.get_column("high").to_numpy(), expected["high"].to_numpy())
    assert np.allclose(weekly.get_column("low").to_numpy(), expected["low"].to_numpy())
    assert np.allclose(weekly.get_column("open").to_numpy(), expected["open"].to_numpy())
    assert np.allclose(
        weekly.get_column("volume").to_numpy(), expected["volume"].to_numpy()
    )
    assert [ts.date() for ts in weekly.get_column("ts").to_list()] == [
        ts.date() for ts in expected.index
    ]


def test_weekly_labels_land_on_fridays() -> None:
    close = np.linspace(100.0, 120.0, 40)
    weekly = resample_weekly(bars_frame(close, start=dt.datetime(2024, 3, 4)), "1W-FRI")
    for ts in weekly.get_column("ts").to_list():
        assert ts.weekday() == 4, f"{ts} is not a Friday"


def test_weekend_bars_roll_into_the_following_friday() -> None:
    """pandas' W-FRI is right-closed: a Saturday belongs to the next week."""
    saturday = dt.datetime(2024, 3, 9)   # Saturday
    bars = bars_frame(np.array([100.0, 101.0]), start=saturday)
    weekly = resample_weekly(bars, "1W-FRI")
    assert weekly.height == 1
    assert weekly.get_column("ts")[0].date() == dt.date(2024, 3, 15)


def test_weekly_is_roll_is_any_within_the_week() -> None:
    close = np.linspace(100.0, 120.0, 21)
    bars = bars_frame(close, start=dt.datetime(2024, 3, 4), roll_bars=(3,))
    weekly = resample_weekly(bars, "1W-FRI")
    assert weekly.get_column("is_roll").any()


def test_unsupported_resample_rule_is_rejected() -> None:
    bars = bars_frame(np.linspace(100.0, 110.0, 10))
    with pytest.raises(ValueError, match="unsupported resample rule"):
        resample_weekly(bars, "1W-XYZ")


def test_weekly_on_empty_input() -> None:
    assert resample_weekly(empty_bars()).is_empty()


# ---------------------------------------------------------------------------
# intraday session alignment
# ---------------------------------------------------------------------------
def _hourly(start: dt.datetime, hours: int) -> pl.DataFrame:
    close = np.arange(hours, dtype=float) + 100.0
    ts = [start + dt.timedelta(hours=i) for i in range(hours)]
    return pl.DataFrame(
        {
            "ts": ts,
            "open": close,
            "high": close + 0.5,
            "low": close - 0.5,
            "close": close,
            "volume": np.full(hours, 10.0),
            "is_roll": [False] * hours,
        }
    )


def test_four_hour_bins_anchor_on_the_session_start() -> None:
    """An 08:00 London session must give 08:00/12:00/16:00 bins, not 00:00."""
    bars = _hourly(dt.datetime(2024, 3, 4, 0, 0), 48)
    out = resample_intraday(
        bars, interval_min=240, session_start_minutes=8 * 60, session_tz="Europe/London"
    )
    hours = {ts.hour for ts in out.get_column("ts").to_list()}
    assert hours <= {0, 4, 8, 12, 16, 20}
    assert 8 in hours and 12 in hours


def test_bins_stay_monotonic_and_uniform_across_daylight_saving() -> None:
    """Regression: per-bar local offsets make bin labels run backwards.

    UK clocks go forward on 31 March 2024. Deriving each bar's offset from
    its own local wall-clock time put the 01:00 and 02:00 UTC bars into a
    bin labelled 23:00 the *previous* day - earlier than the 00:00 bar's
    bin - so a bin ended up holding bars that printed after it. The fixed
    anchor makes that impossible.
    """
    bars = _hourly(dt.datetime(2024, 3, 28, 0, 0), 24 * 8)
    out = resample_intraday(
        bars, interval_min=240, session_start_minutes=8 * 60, session_tz="Europe/London"
    )
    labels = out.get_column("ts").to_list()

    # Strictly increasing, and exactly one interval apart wherever the input
    # is continuous.
    assert labels == sorted(labels)
    assert len(set(labels)) == len(labels)
    gaps = {
        (b - a).total_seconds() / 60 for a, b in itertools.pairwise(labels)
    }
    assert gaps == {240.0}, gaps

    # A true partition: no bar lost, none double-counted.
    assert out.get_column("volume").sum() == pytest.approx(
        bars.get_column("volume").sum()
    )


def test_session_anchor_lands_on_or_before_the_first_bar() -> None:
    from ta_study.data import session_anchor

    # 10:00 UTC on a GMT date: the 08:00 London session opened the same day.
    anchor = session_anchor(dt.datetime(2024, 1, 10, 10, 0), 8 * 60, "Europe/London")
    assert anchor == dt.datetime(2024, 1, 10, 8, 0)

    # 03:00 UTC is before the session start, so the anchor steps back a day.
    anchor = session_anchor(dt.datetime(2024, 1, 10, 3, 0), 8 * 60, "Europe/London")
    assert anchor == dt.datetime(2024, 1, 9, 8, 0)


def test_session_anchor_respects_the_exchange_timezone() -> None:
    from ta_study.data import session_anchor

    # An 08:00 CET session is 07:00 UTC in winter.
    anchor = session_anchor(dt.datetime(2024, 1, 10, 12, 0), 8 * 60, "Europe/Berlin")
    assert anchor == dt.datetime(2024, 1, 10, 7, 0)


def test_resample_aggregates_ohlcv_correctly() -> None:
    bars = _hourly(dt.datetime(2024, 3, 4, 8, 0), 4)
    out = resample_intraday(bars, 240, session_start_minutes=8 * 60)
    assert out.height == 1
    row = out.row(0, named=True)
    assert row["open"] == pytest.approx(100.0)
    assert row["close"] == pytest.approx(103.0)
    assert row["high"] == pytest.approx(103.5)
    assert row["low"] == pytest.approx(99.5)
    assert row["volume"] == pytest.approx(40.0)


def test_bin_offsets_are_whole_minutes_of_the_interval() -> None:
    """Regression: ``dt.hour()`` is Int8, so ``hour * 60`` overflows.

    Unwidened, an 08:00 session produced bins at 04:32, 08:32, 08:48 - the
    wrapped value leaking into the offset - which silently mis-buckets every
    intraday bar.
    """
    bars = _hourly(dt.datetime(2024, 3, 4, 0, 0), 72)
    out = resample_intraday(bars, 240, session_start_minutes=8 * 60)
    for ts in out.get_column("ts").to_list():
        assert ts.minute == 0 and ts.second == 0, ts
        assert (ts.hour * 60 - 8 * 60) % 240 == 0, ts


def test_resample_rejects_a_zero_interval() -> None:
    with pytest.raises(ValueError, match="interval_min"):
        resample_intraday(_hourly(dt.datetime(2024, 3, 4), 4), 0)


def test_intraday_roll_marks_come_from_the_daily_series() -> None:
    intraday = _hourly(dt.datetime(2024, 3, 4, 0, 0), 48)
    daily = bars_frame(np.array([100.0, 101.0, 102.0]), start=dt.datetime(2024, 3, 4))
    daily = daily.with_columns(pl.Series("is_roll", [False, True, False]))

    marked = mark_intraday_rolls(intraday, daily, "Europe/London")
    flagged_dates = {
        ts.date()
        for ts, flag in zip(
            marked.get_column("ts").to_list(),
            marked.get_column("is_roll").to_list(),
            strict=True,
        )
        if flag
    }
    assert flagged_dates == {dt.date(2024, 3, 5)}


def test_merge_intraday_prefers_the_fresh_fetch() -> None:
    ts = dt.datetime(2024, 3, 4, 9, 0)
    old = pl.DataFrame(
        {
            "ts": [ts],
            "open": [1.0],
            "high": [1.0],
            "low": [1.0],
            "close": [1.0],
            "volume": [1.0],
        }
    )
    new = pl.DataFrame(
        {
            "ts": [ts],
            "open": [2.0],
            "high": [2.0],
            "low": [2.0],
            "close": [2.0],
            "volume": [2.0],
        }
    )
    merged = merge_intraday(old, new)
    assert merged.height == 1
    assert merged.get_column("close")[0] == pytest.approx(2.0)


def test_merge_intraday_handles_either_side_empty() -> None:
    bars = _hourly(dt.datetime(2024, 3, 4, 8, 0), 3)
    assert merge_intraday(empty_bars(), bars).height == 3
    assert merge_intraday(bars, empty_bars()).height == 3
    assert merge_intraday(empty_bars(), empty_bars()).is_empty()


# ---------------------------------------------------------------------------
# roll adjustment
# ---------------------------------------------------------------------------
def test_back_adjust_removes_the_gap_and_keeps_the_real_move() -> None:
    # A clean roll: prior close 100, new contract opens at 110 and closes 111.
    close = np.array([100.0, 111.0, 112.0])
    open_ = np.array([99.0, 110.0, 111.0])
    is_roll = np.array([False, True, False])

    factors = back_adjust_factors(close, open_, is_roll)
    # Bars before the roll scale by 110/100; the roll bar onwards is untouched.
    assert factors[0] == pytest.approx(1.1)
    assert factors[1] == pytest.approx(1.0)
    assert factors[2] == pytest.approx(1.0)

    adjusted = close * factors
    # The adjusted step across the roll is the new contract's own move.
    assert adjusted[1] / adjusted[0] == pytest.approx(111.0 / 110.0)


def test_back_adjust_is_anchored_at_the_last_bar() -> None:
    close = np.linspace(100.0, 120.0, 20)
    open_ = close - 0.5
    is_roll = np.zeros(20, dtype=bool)
    is_roll[5] = True
    factors = back_adjust_factors(close, open_, is_roll)
    assert factors[-1] == pytest.approx(1.0)
    assert factors[0] != pytest.approx(1.0)


def test_back_adjust_is_a_noop_without_rolls() -> None:
    close = np.linspace(100.0, 110.0, 10)
    factors = back_adjust_factors(close, close - 0.5, np.zeros(10, dtype=bool))
    assert np.allclose(factors, 1.0)


def test_back_adjust_skips_unusable_rolls() -> None:
    """A missing open or a non-positive price must not produce a NaN series."""
    close = np.array([100.0, 111.0, 112.0])
    open_ = np.array([99.0, np.nan, 111.0])
    factors = back_adjust_factors(close, open_, np.array([False, True, False]))
    assert np.all(np.isfinite(factors))
    assert np.allclose(factors, 1.0)


def test_drop_method_masks_the_roll_bar() -> None:
    bars = bars_frame(np.linspace(100.0, 110.0, 10), roll_bars=(4,))
    out = apply_roll_adjustment(bars, "drop")
    adj = out.get_column("close_adj").to_numpy()
    assert np.isnan(adj[4])
    assert np.isfinite(adj[3]) and np.isfinite(adj[5])


def test_none_method_copies_the_raw_series() -> None:
    bars = bars_frame(np.linspace(100.0, 110.0, 10), roll_bars=(4,))
    out = apply_roll_adjustment(bars, "none")
    assert np.allclose(
        out.get_column("close_adj").to_numpy(), out.get_column("close").to_numpy()
    )


def test_adjustment_on_empty_still_adds_the_columns() -> None:
    out = apply_roll_adjustment(empty_bars(), "backadjust")
    for col in ("open_adj", "high_adj", "low_adj", "close_adj"):
        assert col in out.columns


# ---------------------------------------------------------------------------
# horizon assembly and the pandas boundary
# ---------------------------------------------------------------------------
def test_build_horizon_trims_to_the_bar_budget(cfg) -> None:
    bars = bars_frame(np.linspace(100.0, 200.0, 500))
    horizon = HorizonConfig(name="D", source="daily", bars=120)
    product = ProductConfig(name="TEST", ticker="T1", group="gas")
    out = build_horizon(bars, empty_bars(), product, horizon, cfg)
    assert out.height == 120
    assert "close_adj" in out.columns


def test_build_horizon_returns_empty_for_a_missing_intraday_source(cfg) -> None:
    from ta_study.data import BarReport

    report = BarReport()
    horizon = HorizonConfig(name="1H", source="intraday", interval_min=60, bars=400)
    product = ProductConfig(name="TEST", ticker="T1", group="gas")
    out = build_horizon(empty_bars(), empty_bars(), product, horizon, cfg, report)
    assert out.is_empty()
    assert any("no intraday bars" in w for w in report.warnings)


def test_to_pandas_uses_mplfinance_column_names() -> None:
    bars = bars_frame(np.linspace(100.0, 110.0, 10))
    pdf = to_pandas(bars)
    assert list(pdf.columns) == ["Open", "High", "Low", "Close", "Volume"]
    assert pdf.index.name == "Date"


def test_to_pandas_can_swap_in_the_adjusted_series() -> None:
    bars = apply_roll_adjustment(
        bars_frame(np.linspace(100.0, 110.0, 10), roll_bars=(4,)), "backadjust"
    )
    raw = to_pandas(bars, use_adjusted=False)
    adj = to_pandas(bars, use_adjusted=True)
    assert not np.allclose(raw["Close"].to_numpy(), adj["Close"].to_numpy())
