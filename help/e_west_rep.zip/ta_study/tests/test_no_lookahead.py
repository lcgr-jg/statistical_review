"""The no-lookahead invariant (§8a I) - a required test, not a guideline.

    For every t, the event set {e : e.t* <= t} computed on the full series
    must equal the event set computed on the prefix [1, t].

If this fails, every hit rate the email reports is inflated by information
that was not available on the day, and the study is worthless. The test is
deliberately exhaustive over prefixes rather than sampling a few.
"""

from __future__ import annotations

import numpy as np
import pytest

from ta_study import indicators as ind
from ta_study.config import DivergenceConfig, RsiConfig, SignalConfig
from ta_study.divergence import (
    Divergence,
    detect_divergences,
    events_visible_at,
)
from ta_study.study import evaluate_states, run_study
from ta_study.swings import detect_swings
from ta_study.tests.conftest import (
    bars_frame,
    bearish_divergence_close,
    bullish_divergence_close,
    moderate_bearish_divergence_close,
)


def _identity(event: Divergence) -> tuple:
    """What makes two emitted events "the same" event.

    Bar indices are absolute positions from the start of the series, which is
    shared between the full run and every prefix, so they are comparable.
    """
    return (
        event.kind,
        event.hidden,
        event.s1.bar_idx,
        event.s2.bar_idx,
        event.triggered_at,
        event.direction,
        round(event.d_price, 9),
        round(event.d_rsi, 9),
    )


def _events(close: np.ndarray, dcfg: DivergenceConfig) -> list[Divergence]:
    rsi = ind.rsi(close, 14)
    atr = ind.atr(close + 0.5, close - 0.5, close, 14)
    swings = detect_swings(
        close, close, rsi, k=dcfg.swing_k, rsi_tolerance_bars=dcfg.rsi_tolerance_bars
    )
    return detect_divergences(swings, atr, dcfg, RsiConfig(), SignalConfig())


@pytest.mark.parametrize(
    "close_fn",
    [
        bearish_divergence_close,
        bullish_divergence_close,
        moderate_bearish_divergence_close,
    ],
    ids=["bearish", "bullish", "moderate"],
)
@pytest.mark.parametrize("swing_k", [3, 5, 8])
def test_prefix_event_sets_match_the_full_run(close_fn, swing_k: int) -> None:
    """The core invariant, over every prefix and three swing widths."""
    close = close_fn()
    dcfg = DivergenceConfig(swing_k=swing_k)
    full = _events(close, dcfg)

    for t in range(len(close)):
        expected = {_identity(e) for e in events_visible_at(full, t)}
        prefix = _events(close[: t + 1], dcfg)
        actual = {_identity(e) for e in events_visible_at(prefix, t)}
        assert actual == expected, (
            f"prefix ending at bar {t} (k={swing_k}) disagrees with the full run:\n"
            f"  only in prefix: {sorted(actual - expected)}\n"
            f"  only in full:   {sorted(expected - actual)}"
        )


@pytest.mark.parametrize("swing_k", [3, 5])
def test_a_prefix_never_emits_an_event_beyond_its_own_last_bar(swing_k: int) -> None:
    close = bearish_divergence_close()
    dcfg = DivergenceConfig(swing_k=swing_k)
    for t in range(len(close)):
        for event in _events(close[: t + 1], dcfg):
            assert event.triggered_at <= t, (
                f"prefix of length {t + 1} emitted t*={event.triggered_at}"
            )


def test_trigger_always_trails_the_second_swing_by_k() -> None:
    close = bearish_divergence_close()
    for k in (1, 3, 5, 8):
        for event in _events(close, DivergenceConfig(swing_k=k)):
            assert event.triggered_at == event.s2.bar_idx + k
            assert event.triggered_at > event.s2.bar_idx


def test_rsi_tolerance_does_not_break_the_invariant() -> None:
    """``m`` reads RSI either side of the swing; ``m <= k`` keeps it honest.

    Config validation caps ``m`` at ``k``, so the tolerance window can reach
    at most as far forward as ``confirmed_at``.
    """
    close = bearish_divergence_close()
    dcfg = DivergenceConfig(swing_k=5, rsi_tolerance_bars=5)
    full = _events(close, dcfg)
    for t in range(len(close)):
        expected = {_identity(e) for e in events_visible_at(full, t)}
        actual = {_identity(e) for e in events_visible_at(_events(close[: t + 1], dcfg), t)}
        assert actual == expected, f"tolerance broke the invariant at bar {t}"


def test_config_rejects_a_tolerance_that_would_look_ahead() -> None:
    with pytest.raises(ValueError, match="look ahead"):
        DivergenceConfig(swing_k=3, rsi_tolerance_bars=4)


def test_state_series_is_prefix_stable(cfg) -> None:
    """A prefix run must reproduce the full run's state at its last bar.

    This is the invariant that makes ``backfill`` trustworthy: replaying
    history must give the state the desk would actually have seen.
    """
    close = bearish_divergence_close()
    # Pad so every prefix still clears run.min_bars.
    close = np.concatenate([np.linspace(95.0, 100.0, 80), close])
    bars = bars_frame(close)

    full = run_study(bars, cfg, "TEST", "D")
    full_states = {bs.bar: bs.state for bs in full.bar_states}

    for t in range(cfg.run.min_bars + 5, len(close), 7):
        prefix = run_study(bars.head(t + 1), cfg, "TEST", "D")
        # PROVISIONAL only exists at a series' final bar, so the last bar of a
        # prefix legitimately differs from the same bar mid-series.
        if prefix.state == "PROVISIONAL":
            continue
        assert prefix.bar_states[-1].state == full_states[t], (
            f"bar {t}: prefix says {prefix.bar_states[-1].state}, "
            f"full run says {full_states[t]}"
        )


def test_evaluate_states_ignores_events_before_their_trigger(cfg) -> None:
    from ta_study.study import compute_series

    close = bearish_divergence_close()
    bars = bars_frame(close)
    series = compute_series(bars, cfg, "TEST")
    dcfg = cfg.divergence
    swings = detect_swings(close, close, series.rsi, k=dcfg.swing_k)
    events = detect_divergences(
        swings, series.atr, dcfg, cfg.indicators.rsi, cfg.signal
    )
    assert events

    states = evaluate_states(series, events, cfg)
    t_star = events[0].triggered_at
    for bar_state in states[:t_star]:
        assert bar_state.state == "NONE"
        assert bar_state.direction == 0
    assert states[t_star].state != "NONE"
