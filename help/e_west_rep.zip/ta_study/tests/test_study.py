"""The composite state machine: confirmation, the ADX gate, sizing, alignment.

The gate and confirmation tests build a :class:`StudySeries` directly with a
chosen ADX path and chosen cross bars. Reverse-engineering a price series
that produces a specific ADX shape is possible but would make the assertions
depend on the fixture rather than on the rule under test; the gate function
itself is exercised against real prices in ``test_indicators``.
"""

from __future__ import annotations

import numpy as np
import pytest

from ta_study import indicators as ind
from ta_study.config import (
    AdxGateConfig,
    DivergenceConfig,
    HorizonConfig,
    ProductConfig,
    RunConfig,
    SignalConfig,
    StudyConfig,
)
from ta_study.divergence import Divergence
from ta_study.study import (
    StudySeries,
    alignment,
    compute_series,
    confirmation_bar,
    evaluate_states,
    run_study,
)
from ta_study.swings import Swing
from ta_study.tests.conftest import bars_frame, bearish_divergence_close


# ---------------------------------------------------------------------------
# builders
# ---------------------------------------------------------------------------
def make_series(
    n: int,
    adx: np.ndarray | None = None,
    cross_up: np.ndarray | None = None,
    cross_down: np.ndarray | None = None,
    threshold: float = 30.0,
    r: int = 3,
) -> StudySeries:
    """A minimal StudySeries: only the fields the state machine reads matter."""
    adx_arr = np.full(n, 20.0) if adx is None else np.asarray(adx, dtype=float)
    assert adx_arr.size == n
    flat = np.full(n, 100.0)
    zeros = np.zeros(n, dtype=bool)
    return StudySeries(
        ts=list(range(n)),
        open=flat,
        high=flat,
        low=flat,
        close=flat,
        volume=np.full(n, 1.0),
        is_roll=zeros.copy(),
        close_study=flat,
        high_study=flat,
        low_study=flat,
        rsi=np.full(n, 50.0),
        k=np.full(n, 50.0),
        d=np.full(n, 50.0),
        k_raw=np.full(n, 50.0),
        adx=adx_arr,
        plus_di=np.full(n, 20.0),
        minus_di=np.full(n, 20.0),
        atr=np.full(n, 1.0),
        cross_up=zeros.copy() if cross_up is None else np.asarray(cross_up, dtype=bool),
        cross_down=(
            zeros.copy() if cross_down is None else np.asarray(cross_down, dtype=bool)
        ),
        gate=ind.adx_gate(adx_arr, threshold, r),
        adx_rising=ind.adx_rising(adx_arr, r),
        adx_falling=ind.adx_falling_streak(adx_arr, r),
        swing_high_price=flat,
        swing_low_price=flat,
        adx_threshold=threshold,
    )


def make_event(
    trigger: int, direction: int = 1, strength: float = 0.8, k: int = 5
) -> Divergence:
    s2_bar = trigger - k
    s1_bar = s2_bar - 20
    kind = "L" if direction > 0 else "H"
    return Divergence(
        kind="BULL" if direction > 0 else "BEAR",
        hidden=False,
        s1=Swing(s1_bar, kind, 100.0, 30.0, s1_bar + k, False),
        s2=Swing(s2_bar, kind, 95.0, 40.0, s2_bar + k, False),
        triggered_at=trigger,
        direction=direction,
        d_price=-5.0 if direction > 0 else 5.0,
        d_rsi=10.0 if direction > 0 else -10.0,
        slope_price=-0.25 if direction > 0 else 0.25,
        slope_rsi=0.5 if direction > 0 else -0.5,
        strength=strength,
        strength_rsi=strength,
        strength_price=strength,
        strength_zone=strength,
        atr_at_s2=1.0,
    )


def make_cfg(**divergence_kwargs) -> StudyConfig:
    return StudyConfig(
        run=RunConfig(recipients=["x@y.com"], min_bars=20, chart_workers=0),
        horizons=[HorizonConfig(name="D", source="daily", bars=400)],
        products=[ProductConfig(name="TEST", ticker="T1", group="gas")],
        divergence=DivergenceConfig(**divergence_kwargs),
        adx_gate=AdxGateConfig(default_threshold=30.0, rising_slope_bars=3),
        signal=SignalConfig(unconfirmed_multiplier=0.5, gated_multiplier=0.5),
    )


# ---------------------------------------------------------------------------
# stochastic confirmation (§8a E)
# ---------------------------------------------------------------------------
def test_cross_inside_the_window_confirms() -> None:
    n = 60
    cross = np.zeros(n, dtype=bool)
    cross[25] = True                      # t* = 20, W_c = 10 -> inside [20, 30]
    series = make_series(n, cross_up=cross)
    event = make_event(20, direction=1)
    assert confirmation_bar(event, series, confirmation_window=10) == 25


def test_cross_after_the_window_does_not_confirm() -> None:
    n = 60
    cross = np.zeros(n, dtype=bool)
    cross[31] = True                      # one bar past t* + W_c
    series = make_series(n, cross_up=cross)
    event = make_event(20, direction=1)
    assert confirmation_bar(event, series, confirmation_window=10) is None


def test_cross_before_the_trigger_does_not_confirm() -> None:
    n = 60
    cross = np.zeros(n, dtype=bool)
    cross[19] = True
    series = make_series(n, cross_up=cross)
    event = make_event(20, direction=1)
    assert confirmation_bar(event, series, confirmation_window=10) is None


def test_confirmation_needs_a_cross_in_the_signal_direction() -> None:
    """A bullish divergence is not confirmed by a bearish cross."""
    n = 60
    down = np.zeros(n, dtype=bool)
    down[25] = True
    series = make_series(n, cross_down=down)
    assert confirmation_bar(make_event(20, direction=1), series, 10) is None
    assert confirmation_bar(make_event(20, direction=-1), series, 10) == 25


def test_confirmation_lag_is_never_negative() -> None:
    """The stochastic lags by construction: t_c >= t*."""
    n = 60
    cross = np.zeros(n, dtype=bool)
    cross[[5, 15, 22, 28]] = True
    series = make_series(n, cross_up=cross)
    event = make_event(20, direction=1)
    t_c = confirmation_bar(event, series, 10)
    assert t_c is not None and t_c - event.triggered_at >= 0


# ---------------------------------------------------------------------------
# the ADX gate: every state on one constructed path
# ---------------------------------------------------------------------------
def _gate_path(n: int = 60) -> np.ndarray:
    """Quiet, then a sharp trend, then a collapse back below the threshold."""
    adx = np.full(n, 20.0)
    adx[22:27] = [31.0, 33.0, 35.0, 37.0, 39.0]   # rising above 30 -> gated
    adx[27] = 25.0                                 # straight back under -> release
    adx[28:] = 24.0
    return adx


def test_state_machine_visits_every_gate_state() -> None:
    cfg = make_cfg(active_window=15, confirmation_window=10)
    n = 60
    cross = np.zeros(n, dtype=bool)
    cross[30] = True                               # confirms at bar 30
    series = make_series(n, adx=_gate_path(n), cross_up=cross)
    states = [bs.state for bs in evaluate_states(series, [make_event(20)], cfg)]

    assert states[19] == "NONE"                    # before t*
    assert states[20] == "DVG_ACTIVE"              # triggered, gate open, unconfirmed
    assert states[24] == "DVG_GATED"               # ADX >= 30 and rising
    assert states[27] == "DVG_GATE_RELEASING"      # ADX back below threshold
    assert states[28] == "DVG_ACTIVE"              # actionable again, still unconfirmed
    assert states[30] == "DVG_CONFIRMED"           # cross inside the window
    assert states[36] == "NONE"                    # past t* + W_a

    assert {
        "NONE",
        "DVG_ACTIVE",
        "DVG_GATED",
        "DVG_GATE_RELEASING",
        "DVG_CONFIRMED",
    } <= set(states)


def test_unconfirmed_divergence_expires() -> None:
    cfg = make_cfg(active_window=15, confirmation_window=10, expired_window=5)
    series = make_series(60)                       # no crosses at all
    states = [bs.state for bs in evaluate_states(series, [make_event(20)], cfg)]

    assert states[35] == "DVG_ACTIVE"              # last bar of the active window
    assert states[36] == "DVG_EXPIRED"
    assert states[40] == "DVG_EXPIRED"             # t* + W_a + expired_window
    assert states[41] == "NONE"                    # falls quiet afterwards


def test_gate_releasing_requires_the_previous_bar_to_be_gated() -> None:
    """Without a preceding gated bar it is just DVG_ACTIVE."""
    cfg = make_cfg(active_window=15)
    adx = np.full(60, 20.0)
    adx[22:26] = [19.0, 18.0, 17.0, 16.0]          # falling, but never gated
    series = make_series(60, adx=adx)
    states = [bs.state for bs in evaluate_states(series, [make_event(20)], cfg)]
    assert "DVG_GATE_RELEASING" not in states
    assert states[25] == "DVG_ACTIVE"


def test_gate_stays_closed_while_adx_keeps_rising() -> None:
    cfg = make_cfg(active_window=15)
    adx = np.full(60, 20.0)
    adx[22:36] = np.linspace(31.0, 45.0, 14)
    series = make_series(60, adx=adx)
    states = [bs.state for bs in evaluate_states(series, [make_event(20)], cfg)]
    assert all(s == "DVG_GATED" for s in states[25:35])


# ---------------------------------------------------------------------------
# sizing (§8a G)
# ---------------------------------------------------------------------------
def test_kappa_applies_both_multipliers() -> None:
    cfg = make_cfg(active_window=15, confirmation_window=10)
    n = 60
    cross = np.zeros(n, dtype=bool)
    cross[26] = True
    series = make_series(n, adx=_gate_path(n), cross_up=cross)
    states = evaluate_states(series, [make_event(20, strength=0.8)], cfg)

    unconfirmed_open = states[21]                  # c = 0, G = 0
    assert unconfirmed_open.size_multiplier == pytest.approx(0.8 * 0.5)

    gated = states[24]                             # G = 1
    assert gated.gated
    assert gated.size_multiplier == pytest.approx(0.8 * 0.5 * 0.5)

    confirmed_open = states[30]                    # c = 1, G = 0
    assert confirmed_open.confirmed
    assert confirmed_open.size_multiplier == pytest.approx(0.8)


def test_gated_multiplier_of_zero_silences_gated_signals() -> None:
    cfg = StudyConfig(
        run=RunConfig(recipients=["x@y.com"], min_bars=20, chart_workers=0),
        horizons=[HorizonConfig(name="D", source="daily", bars=400)],
        products=[ProductConfig(name="TEST", ticker="T1", group="gas")],
        signal=SignalConfig(gated_multiplier=0.0),
    )
    series = make_series(60, adx=_gate_path(60))
    states = evaluate_states(series, [make_event(20)], cfg)
    assert states[24].state == "DVG_GATED"
    assert states[24].size_multiplier == pytest.approx(0.0)


def test_direction_is_zero_outside_the_active_window() -> None:
    cfg = make_cfg(active_window=15)
    series = make_series(60)
    states = evaluate_states(series, [make_event(20)], cfg)
    assert states[35].direction != 0
    assert states[40].direction == 0
    assert states[40].size_multiplier == pytest.approx(0.0)


def test_the_most_recent_divergence_wins() -> None:
    cfg = make_cfg(active_window=15)
    series = make_series(80)
    events = [make_event(20, direction=1), make_event(40, direction=-1)]
    states = evaluate_states(series, events, cfg)
    assert states[25].direction == 1
    assert states[45].direction == -1


# ---------------------------------------------------------------------------
# end-to-end on real prices
# ---------------------------------------------------------------------------
def test_run_study_reports_the_raw_ingredients(cfg) -> None:
    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    result = run_study(bars_frame(close), cfg, "TEST", "D")

    assert result.n_bars == close.size
    for value in (result.rsi, result.k, result.d, result.adx, result.atr):
        assert np.isfinite(value)
    assert 0.0 <= result.rsi <= 100.0
    assert 0.0 <= result.adx <= 100.0
    assert result.adx_threshold == cfg.adx_gate.default_threshold
    assert len(result.bar_states) == close.size


def test_short_history_degrades_to_none_with_a_warning(cfg) -> None:
    close = np.linspace(100.0, 110.0, 30)          # below run.min_bars
    result = run_study(bars_frame(close), cfg, "TEST", "D")
    assert result.state == "NONE"
    assert result.warnings
    assert "bars" in result.warnings[0]
    assert result.events == []


def test_compute_series_requires_bar_columns(cfg) -> None:
    import polars as pl

    with pytest.raises(ValueError, match="missing required columns"):
        compute_series(pl.DataFrame({"ts": [1, 2, 3]}), cfg, "TEST")


def test_compute_series_prefers_the_adjusted_close(cfg) -> None:
    """Indicators must run on the back-adjusted series when it exists."""
    from ta_study.data import apply_roll_adjustment

    close = np.concatenate([np.linspace(95.0, 100.0, 80), bearish_divergence_close()])
    bars = bars_frame(close, roll_bars=(100,))
    adjusted = apply_roll_adjustment(bars, "backadjust")

    series = compute_series(adjusted, cfg, "TEST")
    assert not np.allclose(series.close_study, series.close)
    # The display close is untouched: the chart shows traded prices.
    assert series.close[-1] == pytest.approx(close[-1])


# ---------------------------------------------------------------------------
# cross-horizon alignment (§8, §8a G)
# ---------------------------------------------------------------------------
def _result(product: str, horizon: str, direction: int, kappa: float):
    from ta_study.study import StudyResult

    return StudyResult(
        product=product,
        horizon=horizon,
        as_of=None,
        n_bars=100,
        state="DVG_ACTIVE",
        direction=direction,
        confirmed=False,
        gated=False,
        size_multiplier=kappa,
        strength=kappa,
        bars_since_dvg=1,
        close=100.0,
        rsi=50.0,
        k=50.0,
        d=50.0,
        adx=20.0,
        plus_di=20.0,
        minus_di=20.0,
        atr=1.0,
        adx_rising=False,
        adx_threshold=30.0,
    )


def test_alignment_needs_two_agreeing_horizons() -> None:
    one = [_result("TTF", "D", -1, 0.5)]
    assert alignment(one) == []

    two = [_result("TTF", "D", -1, 0.5), _result("TTF", "W", -1, 0.3)]
    aligned = alignment(two)
    assert len(aligned) == 1
    assert aligned[0].product == "TTF"
    assert aligned[0].direction == -1
    assert aligned[0].score == pytest.approx(-0.8)
    assert aligned[0].magnitude == pytest.approx(0.8)
    assert set(aligned[0].horizons) == {"D", "W"}


def test_opposing_horizons_do_not_align() -> None:
    mixed = [_result("TTF", "D", -1, 0.5), _result("TTF", "W", 1, 0.5)]
    assert alignment(mixed) == []


def test_alignment_is_ranked_by_magnitude() -> None:
    results = [
        _result("TTF", "D", -1, 0.9),
        _result("TTF", "W", -1, 0.9),
        _result("EUA", "D", 1, 0.2),
        _result("EUA", "W", 1, 0.2),
    ]
    aligned = alignment(results)
    assert [a.product for a in aligned] == ["TTF", "EUA"]


def test_non_live_states_do_not_contribute_to_alignment() -> None:
    results = [_result("TTF", "D", -1, 0.5), _result("TTF", "W", -1, 0.5)]
    results[1].state = "DVG_EXPIRED"
    assert alignment(results) == []
