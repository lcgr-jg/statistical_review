"""Snowflake tables for the TA study, plus a local state mirror.

Four tables in ``{database}.{schema}`` (default ``RISK.TA``):

``STUDY_STATE``       one row per (run date, product, horizon): state,
                      direction, strength, every indicator value and the
                      S1/S2 timestamps.
``DIVERGENCE_EVENTS`` one row per emitted divergence, later filled with
                      forward returns at +5/+10/+20 bars in ATR units and
                      per cent, plus the ``confirmed`` and ``gated`` flags
                      as they stood at the trigger.
``MA_CROSS_EVENTS``   the same pattern for EMA crossovers.
``INTRADAY_BARS``     persisted intraday bars. Bloomberg only retains about
                      140 days, so the study reads history from here first
                      and tops it up from Bloomberg - history is built
                      forward, one run at a time.

Keying note: §12 describes ``STUDY_STATE`` as keyed on
``(run_ts, product, horizon)``. A MERGE on a wall-clock timestamp can never
match an existing row, so a rerun would append rather than replace. The key
here is ``(RUN_DATE, PRODUCT, HORIZON)`` with ``RUN_TS`` kept as a column,
which makes ``--date`` reruns genuinely idempotent as §15 requires.

A local JSON mirror of the previous run's states is always written, so the
email's "what changed since yesterday" section works with persistence
disabled or the warehouse unreachable.
"""

from __future__ import annotations

import datetime as dt
import json
import logging
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import polars as pl

from common.persist import Persistence, SnowflakeSettings, TableSpec
from ta_study.config import PersistConfig, StudyConfig
from ta_study.secondary import SecondaryResult
from ta_study.stats import EventRecord
from ta_study.study import StudyResult

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# table definitions
# ---------------------------------------------------------------------------
def study_state_spec(cfg: PersistConfig) -> TableSpec:
    return TableSpec(
        name=cfg.study_state_table,
        columns={
            "RUN_DATE": "DATE NOT NULL",
            "PRODUCT": "VARCHAR(64) NOT NULL",
            "HORIZON": "VARCHAR(16) NOT NULL",
            "RUN_TS": "TIMESTAMP_NTZ",
            "AS_OF": "TIMESTAMP_NTZ",
            "STATE": "VARCHAR(32)",
            "PREV_STATE": "VARCHAR(32)",
            "DIRECTION": "NUMBER(2,0)",
            "CONFIRMED": "BOOLEAN",
            "GATED": "BOOLEAN",
            "SIZE_MULTIPLIER": "FLOAT",
            "STRENGTH": "FLOAT",
            "BARS_SINCE_DVG": "NUMBER(9,0)",
            "CLOSE": "FLOAT",
            "RSI": "FLOAT",
            "STOCH_K": "FLOAT",
            "STOCH_D": "FLOAT",
            "ADX": "FLOAT",
            "PLUS_DI": "FLOAT",
            "MINUS_DI": "FLOAT",
            "ATR": "FLOAT",
            "ADX_RISING": "BOOLEAN",
            "ADX_THRESHOLD": "FLOAT",
            "S1_TS": "TIMESTAMP_NTZ",
            "S2_TS": "TIMESTAMP_NTZ",
            "N_BARS": "NUMBER(9,0)",
            "SECONDARY": "VARIANT",
            "LOADED_AT": "TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()",
        },
        keys=("RUN_DATE", "PRODUCT", "HORIZON"),
        variant_columns=("SECONDARY",),
    )


def divergence_events_spec(cfg: PersistConfig) -> TableSpec:
    return TableSpec(
        name=cfg.divergence_events_table,
        columns={
            "PRODUCT": "VARCHAR(64) NOT NULL",
            "HORIZON": "VARCHAR(16) NOT NULL",
            "TRIGGERED_TS": "TIMESTAMP_NTZ NOT NULL",
            "KIND": "VARCHAR(8)",
            "HIDDEN": "BOOLEAN",
            "DIRECTION": "NUMBER(2,0)",
            "S1_TS": "TIMESTAMP_NTZ",
            "S2_TS": "TIMESTAMP_NTZ",
            "STRENGTH": "FLOAT",
            "STRENGTH_RSI": "FLOAT",
            "STRENGTH_PRICE": "FLOAT",
            "STRENGTH_ZONE": "FLOAT",
            "D_PRICE": "FLOAT",
            "D_RSI": "FLOAT",
            "CONFIRMED": "BOOLEAN",
            "GATED": "BOOLEAN",
            "CONFIRMATION_LAG": "NUMBER(9,0)",
            "TRIGGER_CLOSE": "FLOAT",
            "TRIGGER_ATR": "FLOAT",
            "FWD_5_PCT": "FLOAT",
            "FWD_5_ATR": "FLOAT",
            "FWD_10_PCT": "FLOAT",
            "FWD_10_ATR": "FLOAT",
            "FWD_20_PCT": "FLOAT",
            "FWD_20_ATR": "FLOAT",
            "LOADED_AT": "TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()",
        },
        keys=("PRODUCT", "HORIZON", "TRIGGERED_TS"),
    )


def ma_cross_events_spec(cfg: PersistConfig) -> TableSpec:
    return TableSpec(
        name=cfg.ma_cross_events_table,
        columns={
            "PRODUCT": "VARCHAR(64) NOT NULL",
            "HORIZON": "VARCHAR(16) NOT NULL",
            "CROSS_TS": "TIMESTAMP_NTZ NOT NULL",
            "PAIR": "VARCHAR(16) NOT NULL",
            "DIRECTION": "NUMBER(2,0)",
            "CLOSE": "FLOAT",
            "REGIME": "VARCHAR(24)",
            "FWD_5_PCT": "FLOAT",
            "FWD_5_ATR": "FLOAT",
            "FWD_10_PCT": "FLOAT",
            "FWD_10_ATR": "FLOAT",
            "FWD_20_PCT": "FLOAT",
            "FWD_20_ATR": "FLOAT",
            "LOADED_AT": "TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()",
        },
        keys=("PRODUCT", "HORIZON", "CROSS_TS", "PAIR"),
    )


def intraday_bars_spec(cfg: PersistConfig) -> TableSpec:
    return TableSpec(
        name=cfg.intraday_bars_table,
        columns={
            "TICKER": "VARCHAR(64) NOT NULL",
            "INTERVAL_MIN": "NUMBER(9,0) NOT NULL",
            "TS": "TIMESTAMP_NTZ NOT NULL",
            "OPEN": "FLOAT",
            "HIGH": "FLOAT",
            "LOW": "FLOAT",
            "CLOSE": "FLOAT",
            "VOLUME": "FLOAT",
            "LOADED_AT": "TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()",
        },
        keys=("TICKER", "INTERVAL_MIN", "TS"),
        cluster_by=("TICKER", "TS"),
    )


def table_specs(cfg: PersistConfig) -> list[TableSpec]:
    return [
        study_state_spec(cfg),
        divergence_events_spec(cfg),
        ma_cross_events_spec(cfg),
        intraday_bars_spec(cfg),
    ]


# ---------------------------------------------------------------------------
# local mirror
# ---------------------------------------------------------------------------
@dataclass
class StoredState:
    """The slice of a study result the next run needs."""

    product: str
    horizon: str
    state: str
    direction: int = 0
    strength: float = 0.0
    as_of: str | None = None
    run_date: str | None = None


class LocalState:
    """JSON-backed mirror of the last run's states. Always written."""

    def __init__(self, directory: str | Path) -> None:
        self.path = Path(directory) / "ta_study_state.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> dict[tuple[str, str], StoredState]:
        if not self.path.exists():
            return {}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            log.warning("could not read local state %s: %s", self.path, exc)
            return {}
        out: dict[tuple[str, str], StoredState] = {}
        for key, payload in raw.items():
            if not isinstance(payload, dict):
                continue
            product, _, horizon = key.partition("|")
            try:
                out[(product, horizon)] = StoredState(**payload)
            except TypeError:
                log.warning("ignoring malformed local state entry %r", key)
        return out

    def save(self, states: dict[tuple[str, str], StoredState]) -> None:
        payload = {
            f"{product}|{horizon}": asdict(state)
            for (product, horizon), state in states.items()
        }
        self.path.write_text(
            json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
        )
        log.info("wrote local state to %s", self.path)


# ---------------------------------------------------------------------------
# row builders
# ---------------------------------------------------------------------------
def _ts(value: Any) -> Any:
    """Normalise a timestamp for the connector (naive, no tz)."""
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        return value.replace(tzinfo=None)
    if isinstance(value, dt.date):
        return dt.datetime.combine(value, dt.time())
    return value


def _clean(value: Any) -> Any:
    """NaN -> NULL, numpy scalars -> Python scalars."""
    if value is None:
        return None
    try:
        as_float = float(value)
    except (TypeError, ValueError):
        return value
    if as_float != as_float:  # NaN
        return None
    return as_float


def study_state_row(
    result: StudyResult,
    secondary: SecondaryResult | None,
    run_ts: dt.datetime,
    run_date: dt.date,
) -> dict[str, Any]:
    event = result.event or result.provisional_event
    payload: dict[str, Any] = {
        "RUN_DATE": run_date,
        "PRODUCT": result.product,
        "HORIZON": result.horizon,
        "RUN_TS": _ts(run_ts),
        "AS_OF": _ts(result.as_of),
        "STATE": result.state,
        "PREV_STATE": result.prev_state,
        "DIRECTION": int(result.direction),
        "CONFIRMED": bool(result.confirmed),
        "GATED": bool(result.gated),
        "SIZE_MULTIPLIER": _clean(result.size_multiplier),
        "STRENGTH": _clean(result.strength),
        "BARS_SINCE_DVG": result.bars_since_dvg,
        "CLOSE": _clean(result.close),
        "RSI": _clean(result.rsi),
        "STOCH_K": _clean(result.k),
        "STOCH_D": _clean(result.d),
        "ADX": _clean(result.adx),
        "PLUS_DI": _clean(result.plus_di),
        "MINUS_DI": _clean(result.minus_di),
        "ATR": _clean(result.atr),
        "ADX_RISING": bool(result.adx_rising),
        "ADX_THRESHOLD": _clean(result.adx_threshold),
        "S1_TS": _ts(event.s1.ts) if event else None,
        "S2_TS": _ts(event.s2.ts) if event else None,
        "N_BARS": int(result.n_bars),
        "SECONDARY": None,
    }
    if secondary is not None:
        payload["SECONDARY"] = {
            "regime": secondary.regime,
            "ema": {str(k): _clean(v) for k, v in secondary.ema.items()},
            "dist_atr": {str(k): _clean(v) for k, v in secondary.dist_atr.items()},
            "macd_hist": _clean(secondary.macd_hist),
            "macd_flip": secondary.macd_flip,
            "percent_b": _clean(secondary.percent_b),
            "bb_outside": secondary.bb_outside,
            "bandwidth_pctile": _clean(secondary.bandwidth_pctile),
            "recent_crosses": [
                {"pair": c.pair, "direction": c.direction, "ts": str(c.ts)}
                for c in secondary.recent_crosses
            ],
            "candle_tags": secondary.candle_tags,
        }
    return payload


def divergence_event_row(record: EventRecord) -> dict[str, Any]:
    row: dict[str, Any] = {
        "PRODUCT": record.product,
        "HORIZON": record.horizon,
        "TRIGGERED_TS": _ts(record.triggered_ts),
        "KIND": record.kind,
        "HIDDEN": bool(record.hidden),
        "DIRECTION": int(record.direction),
        "S1_TS": _ts(record.s1_ts),
        "S2_TS": _ts(record.s2_ts),
        "STRENGTH": _clean(record.strength),
        "STRENGTH_RSI": _clean(record.strength_rsi),
        "STRENGTH_PRICE": _clean(record.strength_price),
        "STRENGTH_ZONE": _clean(record.strength_zone),
        "D_PRICE": _clean(record.d_price),
        "D_RSI": _clean(record.d_rsi),
        "CONFIRMED": bool(record.confirmed),
        "GATED": bool(record.gated),
        "CONFIRMATION_LAG": record.confirmation_lag,
        "TRIGGER_CLOSE": _clean(record.trigger_close),
        "TRIGGER_ATR": _clean(record.trigger_atr),
    }
    for h in (5, 10, 20):
        ret = record.returns.get(h)
        row[f"FWD_{h}_PCT"] = _clean(ret.pct) if ret else None
        row[f"FWD_{h}_ATR"] = _clean(ret.atr_units) if ret else None
    return row


def ma_cross_rows(
    result: StudyResult, secondary: SecondaryResult
) -> list[dict[str, Any]]:
    """Rows for crosses that are new this run - older ones are already stored."""
    series = result.series
    rows: list[dict[str, Any]] = []
    for cross in secondary.recent_crosses:
        rows.append(
            {
                "PRODUCT": result.product,
                "HORIZON": result.horizon,
                "CROSS_TS": _ts(cross.ts),
                "PAIR": cross.pair,
                "DIRECTION": int(cross.direction),
                "CLOSE": _clean(
                    series.at(series.close_study, cross.bar) if series else None
                ),
                "REGIME": secondary.regime,
                "FWD_5_PCT": None,
                "FWD_5_ATR": None,
                "FWD_10_PCT": None,
                "FWD_10_ATR": None,
                "FWD_20_PCT": None,
                "FWD_20_ATR": None,
            }
        )
    return rows


def intraday_bar_rows(
    ticker: str, interval_min: int, bars: pl.DataFrame
) -> list[dict[str, Any]]:
    if bars.is_empty():
        return []
    return [
        {
            "TICKER": ticker,
            "INTERVAL_MIN": int(interval_min),
            "TS": _ts(row["ts"]),
            "OPEN": _clean(row.get("open")),
            "HIGH": _clean(row.get("high")),
            "LOW": _clean(row.get("low")),
            "CLOSE": _clean(row.get("close")),
            "VOLUME": _clean(row.get("volume")),
        }
        for row in bars.iter_rows(named=True)
    ]


# ---------------------------------------------------------------------------
# the store
# ---------------------------------------------------------------------------
class TaStore:
    """Fail-soft persistence façade for the TA study."""

    def __init__(self, cfg: StudyConfig, base_dir: Path) -> None:
        self.cfg = cfg
        self.persist_cfg = cfg.persist
        self.local = LocalState(base_dir / cfg.persist.local_state_dir)
        self.persistence = Persistence(
            SnowflakeSettings(
                database=cfg.persist.database,
                schema=cfg.persist.schema_,
                role=cfg.persist.role,
                warehouse=cfg.persist.warehouse,
                enabled=cfg.persist.enabled,
            ),
            table_specs(cfg.persist),
        )

    # -- state ----------------------------------------------------------
    def load_prev_states(self) -> dict[tuple[str, str], StoredState]:
        """Previous states, from Snowflake when available, else the mirror."""
        if self.persist_cfg.enabled:
            fq = self.persistence.fq(self.persist_cfg.study_state_table)
            rows = self.persistence.read(
                f"""
                SELECT PRODUCT, HORIZON, STATE, DIRECTION, STRENGTH, AS_OF, RUN_DATE
                FROM {fq}
                QUALIFY ROW_NUMBER() OVER (
                    PARTITION BY PRODUCT, HORIZON ORDER BY RUN_DATE DESC
                ) = 1
                """
            )
            if rows:
                return {
                    (r["PRODUCT"], r["HORIZON"]): StoredState(
                        product=r["PRODUCT"],
                        horizon=r["HORIZON"],
                        state=r["STATE"],
                        direction=int(r["DIRECTION"] or 0),
                        strength=float(r["STRENGTH"] or 0.0),
                        as_of=str(r["AS_OF"]) if r["AS_OF"] else None,
                        run_date=str(r["RUN_DATE"]) if r["RUN_DATE"] else None,
                    )
                    for r in rows
                }
        return self.local.load()

    def save_states(
        self,
        results: Sequence[StudyResult],
        secondary: dict[tuple[str, str], SecondaryResult],
        run_ts: dt.datetime,
        run_date: dt.date,
    ) -> int:
        mirror = {
            res.key: StoredState(
                product=res.product,
                horizon=res.horizon,
                state=res.state,
                direction=res.direction,
                strength=res.strength,
                as_of=str(res.as_of) if res.as_of else None,
                run_date=run_date.isoformat(),
            )
            for res in results
        }
        self.local.save(mirror)

        rows = [
            study_state_row(res, secondary.get(res.key), run_ts, run_date)
            for res in results
        ]
        return self.persistence.write(self.persist_cfg.study_state_table, rows)

    # -- events ---------------------------------------------------------
    def save_divergence_events(self, records: Sequence[EventRecord]) -> int:
        rows = [divergence_event_row(r) for r in records]
        return self.persistence.write(self.persist_cfg.divergence_events_table, rows)

    def save_ma_crosses(
        self,
        results: Sequence[StudyResult],
        secondary: dict[tuple[str, str], SecondaryResult],
    ) -> int:
        rows: list[dict[str, Any]] = []
        for res in results:
            sec = secondary.get(res.key)
            if sec is not None:
                rows.extend(ma_cross_rows(res, sec))
        return self.persistence.write(self.persist_cfg.ma_cross_events_table, rows)

    def load_event_history(
        self, products: Sequence[str] | None = None
    ) -> list[dict[str, Any]]:
        """Scored divergence events, for the hit-rate tables."""
        if not self.persist_cfg.enabled:
            return []
        fq = self.persistence.fq(self.persist_cfg.divergence_events_table)
        sql = f"SELECT * FROM {fq}"
        if products:
            quoted = ", ".join(f"'{p}'" for p in products if p.replace("_", "").isalnum())
            if quoted:
                sql += f" WHERE PRODUCT IN ({quoted})"
        return self.persistence.read(sql)

    # -- intraday bars --------------------------------------------------
    def save_intraday_bars(
        self, ticker: str, interval_min: int, bars: pl.DataFrame
    ) -> int:
        rows = intraday_bar_rows(ticker, interval_min, bars)
        return self.persistence.write(self.persist_cfg.intraday_bars_table, rows)

    def load_intraday_bars(
        self, ticker: str, interval_min: int, start: dt.datetime
    ) -> pl.DataFrame:
        """Persisted bars from ``start`` onwards; empty when unavailable."""
        empty = pl.DataFrame(
            schema={
                "ts": pl.Datetime("us"),
                "open": pl.Float64,
                "high": pl.Float64,
                "low": pl.Float64,
                "close": pl.Float64,
                "volume": pl.Float64,
            }
        )
        if not self.persist_cfg.enabled:
            return empty

        fq = self.persistence.fq(self.persist_cfg.intraday_bars_table)
        rows = self.persistence.read(
            f"""
            SELECT TS, OPEN, HIGH, LOW, CLOSE, VOLUME
            FROM {fq}
            WHERE TICKER = %(ticker)s
              AND INTERVAL_MIN = %(interval)s
              AND TS >= %(start)s
            ORDER BY TS
            """,
            {"ticker": ticker, "interval": interval_min, "start": start},
        )
        if not rows:
            return empty
        return pl.DataFrame(
            {
                "ts": [r["TS"] for r in rows],
                "open": [r["OPEN"] for r in rows],
                "high": [r["HIGH"] for r in rows],
                "low": [r["LOW"] for r in rows],
                "close": [r["CLOSE"] for r in rows],
                "volume": [r["VOLUME"] for r in rows],
            },
            schema=empty.schema,
        )

    # -- diagnostics ----------------------------------------------------
    @property
    def errors(self) -> list[str]:
        return self.persistence.report.errors

    @property
    def rows_written(self) -> dict[str, int]:
        return self.persistence.report.rows_written

    def close(self) -> None:
        self.persistence.close()
