"""Bar assembly: horizon resampling, session alignment, roll handling.

One :class:`polars.DataFrame` per (product, horizon) with columns

    ts, open, high, low, close, volume, is_roll
    open_adj, high_adj, low_adj, close_adj      (when back-adjusting)

Conversion to pandas happens only at the TA-Lib / mplfinance boundary; every
transformation here stays in polars.

Horizons
--------
``W``   resampled from the daily series with a Friday week-end label. The
        weekly series is deliberately *not* fetched from Bloomberg: deriving
        it keeps the daily and weekly bars mutually consistent, so a
        divergence visible on the weekly chart is made of the same highs the
        daily chart shows.
``D``   daily bars as returned.
``4H``  derived from persisted 1h bars, binned from the exchange session
        start rather than from midnight - a 4h grid anchored on midnight
        splits the European power and gas session in the wrong places.
``1H``  persisted 1h bars as returned.

Roll handling
-------------
A roll bar is one where the generic ticker's underlying contract changed
(``FUT_CUR_GEN_TICKER``). For momentum indicators the series is
back-adjusted so the contract gap never enters RSI or ADX; for display the
unadjusted bars are kept and the roll is marked. Back-adjustment is
multiplicative and anchored at the most recent bar, so the last close on the
chart is the traded price.
"""

from __future__ import annotations

import datetime as dt
import logging
from dataclasses import dataclass, field

import numpy as np
import polars as pl

from ta_study.config import HorizonConfig, ProductConfig, RollMethod, StudyConfig

log = logging.getLogger(__name__)

BAR_COLUMNS = ("ts", "open", "high", "low", "close", "volume", "is_roll")
ADJ_COLUMNS = ("open_adj", "high_adj", "low_adj", "close_adj")

MINUTES_PER_DAY = 1440


@dataclass
class BarReport:
    """Per-(product, horizon) bar diagnostics for the email appendix."""

    rows: dict[tuple[str, str], int] = field(default_factory=dict)
    last_ts: dict[tuple[str, str], object] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def warn(self, msg: str) -> None:
        log.warning(msg)
        self.warnings.append(msg)

    def record(self, product: str, horizon: str, df: pl.DataFrame) -> None:
        key = (product, horizon)
        self.rows[key] = df.height
        if df.height:
            self.last_ts[key] = df.get_column("ts")[-1]


# ---------------------------------------------------------------------------
# normalisation
# ---------------------------------------------------------------------------
def empty_bars() -> pl.DataFrame:
    """A correctly-typed zero-row bar frame.

    Returned wherever a product or horizon has no data, so downstream code
    can rely on the schema rather than guarding for ``None``.
    """
    return pl.DataFrame(
        schema={
            "ts": pl.Datetime("us"),
            "open": pl.Float64,
            "high": pl.Float64,
            "low": pl.Float64,
            "close": pl.Float64,
            "volume": pl.Float64,
            "is_roll": pl.Boolean,
        }
    )


def repair_ohlc(bars: pl.DataFrame) -> pl.DataFrame:
    """Make every bar a self-consistent candle.

    Bloomberg returns bars where only some of O/H/L/C printed - a settlement
    with no traded range, a thin contract, a holiday session. Two problems
    follow: true range goes NaN for that bar, and mplfinance refuses the whole
    frame outright ("O,H,L,C must have the same amount of missing data"),
    which silently cost five charts on the first live run.

    Missing open, high and low are filled from the close - a bar with no
    range is still a bar - and the extremes are then widened to enclose the
    open and close, so a feed that reports ``high < close`` cannot produce an
    impossible candle.
    """
    if bars.is_empty():
        return bars

    out = bars.with_columns(
        pl.col("open").fill_null(pl.col("close")),
        pl.col("high").fill_null(pl.col("close")),
        pl.col("low").fill_null(pl.col("close")),
    )
    return out.with_columns(
        pl.max_horizontal("high", "open", "close").alias("high"),
        pl.min_horizontal("low", "open", "close").alias("low"),
    )


def roll_flags(gen_ticker: pl.Series) -> list[bool]:
    """True where the generic's underlying contract changed.

    The first observation is never a roll - there is nothing to compare it
    to - and nulls are skipped rather than treated as a change.
    """
    out: list[bool] = []
    prev: str | None = None
    for value in gen_ticker.to_list():
        if value is None:
            out.append(False)
            continue
        out.append(prev is not None and value != prev)
        prev = value
    return out


def normalise_daily(bars: pl.DataFrame) -> pl.DataFrame:
    """Bloomberg daily frame -> canonical bar frame keyed by ``ts``."""
    if bars.is_empty():
        return empty_bars()

    df = bars.sort("date" if "date" in bars.columns else "ts")
    if "date" in df.columns:
        df = df.with_columns(
            pl.col("date").cast(pl.Datetime("us")).alias("ts")
        ).drop("date")

    if "gen_ticker" in df.columns:
        flags = roll_flags(df.get_column("gen_ticker"))
        df = df.with_columns(pl.Series("is_roll", flags, dtype=pl.Boolean))
    else:
        df = df.with_columns(pl.lit(False).alias("is_roll"))

    if "volume" not in df.columns:
        df = df.with_columns(pl.lit(0.0).alias("volume"))

    df = df.with_columns(
        [pl.col(c).cast(pl.Float64) for c in ("open", "high", "low", "close", "volume")]
    )
    # A bar with no close carries no information for any indicator here.
    df = df.filter(pl.col("close").is_not_null())
    df = repair_ohlc(df)
    return df.select(list(BAR_COLUMNS)).sort("ts")


def normalise_intraday(bars: pl.DataFrame) -> pl.DataFrame:
    """Intraday frame -> canonical bar frame (``is_roll`` filled later)."""
    if bars.is_empty():
        return empty_bars()

    df = bars.sort("ts")
    if "volume" not in df.columns:
        df = df.with_columns(pl.lit(0.0).alias("volume"))
    if "is_roll" not in df.columns:
        df = df.with_columns(pl.lit(False).alias("is_roll"))

    df = df.with_columns(
        [pl.col(c).cast(pl.Float64) for c in ("open", "high", "low", "close", "volume")]
    )
    df = df.with_columns(pl.col("ts").cast(pl.Datetime("us")))
    df = df.filter(pl.col("close").is_not_null())
    df = repair_ohlc(df)
    return (
        df.select(list(BAR_COLUMNS))
        .unique(subset=["ts"], keep="last")
        .sort("ts")
    )


# ---------------------------------------------------------------------------
# resampling
# ---------------------------------------------------------------------------
#: Weekday index (Monday = 0) each supported resample rule closes on.
_WEEK_END_DOW: dict[str, int] = {
    "1W-MON": 0,
    "1W-TUE": 1,
    "1W-WED": 2,
    "1W-THU": 3,
    "1W-FRI": 4,
    "1W-SAT": 5,
    "1W-SUN": 6,
}

_OHLCV_AGG = (
    pl.col("open").first().alias("open"),
    pl.col("high").max().alias("high"),
    pl.col("low").min().alias("low"),
    pl.col("close").last().alias("close"),
    pl.col("volume").sum().alias("volume"),
    pl.col("is_roll").any().alias("is_roll"),
)


def resample_weekly(daily: pl.DataFrame, rule: str = "1W-FRI") -> pl.DataFrame:
    """Daily bars -> weekly bars labelled by the week's closing weekday.

    ``open`` = first, ``high`` = max, ``low`` = min, ``close`` = last,
    ``volume`` = sum, ``is_roll`` = any. Matches pandas' right-closed,
    right-labelled ``resample('W-FRI')``: a Saturday bar belongs to the
    *following* Friday's week.
    """
    if daily.is_empty():
        return empty_bars()

    dow = _WEEK_END_DOW.get(rule.upper())
    if dow is None:
        msg = f"unsupported resample rule {rule!r}; expected one of {sorted(_WEEK_END_DOW)}"
        raise ValueError(msg)

    df = daily.sort("ts")
    # polars' dt.weekday() is 1 = Monday .. 7 = Sunday, returned as Int8;
    # widened for the same reason as in resample_intraday.
    offset_days = (dow - (pl.col("ts").dt.weekday().cast(pl.Int32) - 1) + 7) % 7
    df = df.with_columns(
        (pl.col("ts") + pl.duration(days=offset_days)).dt.truncate("1d").alias("_bin")
    )
    out = (
        df.group_by("_bin", maintain_order=True)
        .agg(*_OHLCV_AGG)
        .rename({"_bin": "ts"})
    )
    return out.select(list(BAR_COLUMNS)).sort("ts")


def session_anchor(
    first_ts: dt.datetime,
    session_start_minutes: int,
    session_tz: str,
) -> dt.datetime:
    """The session start at or before ``first_ts``, as a naive-UTC instant.

    ``first_ts`` is in the input's clock (naive GMT, which is what Bloomberg
    returns). The anchor is the most recent session open not later than it,
    so every bar sits at a non-negative offset from the grid origin.
    """
    from zoneinfo import ZoneInfo

    tz = ZoneInfo(session_tz)
    utc = ZoneInfo("UTC")
    local = first_ts.replace(tzinfo=utc).astimezone(tz)
    start = local.replace(
        hour=session_start_minutes // 60,
        minute=session_start_minutes % 60,
        second=0,
        microsecond=0,
    )
    if start > local:
        start -= dt.timedelta(days=1)
    return start.astimezone(utc).replace(tzinfo=None)


def resample_intraday(
    bars: pl.DataFrame,
    interval_min: int,
    session_start_minutes: int = 0,
    session_tz: str = "Europe/London",
) -> pl.DataFrame:
    """Aggregate finer intraday bars onto an ``interval_min`` grid.

    The grid is anchored on the exchange session start (see
    :func:`session_anchor`) rather than on midnight, so a 4h grid for an
    08:00 session opens bins at 08:00/12:00/16:00/20:00/00:00/04:00 local
    rather than splitting the European power and gas session in the wrong
    places.

    Binning is done on the absolute instant with a fixed anchor, which makes
    the bins uniform, strictly monotonic and a true partition of the input.
    Deriving each bar's offset from its *own* local wall-clock time instead
    looks equivalent but is not: on a daylight-saving change the local clock
    jumps, and bars either side of the jump get bin labels that run
    backwards - a bin labelled 23:00 ending up holding bars that printed
    after the 00:00 bin's. The price of the fixed anchor is that the local
    bin labels shift by an hour after a DST change, which is how Bloomberg
    and most charting packages behave, and it is recorded in the chart's
    own time axis either way.

    The bin label is the bin's opening timestamp in the input's clock.
    """
    if bars.is_empty():
        return empty_bars()
    if interval_min < 1:
        msg = f"interval_min must be >= 1, got {interval_min}"
        raise ValueError(msg)

    df = bars.sort("ts")
    first_ts = df.get_column("ts")[0]
    anchor = session_anchor(first_ts, session_start_minutes, session_tz)

    interval_us = interval_min * 60 * 1_000_000
    anchor_us = int(anchor.timestamp() * 1_000_000)

    # Integer floor-division on the epoch keeps the grid exact; polars' //
    # floors like Python's, and the anchor is guaranteed not to post-date the
    # first bar, so the operand is never negative.
    elapsed = pl.col("ts").dt.epoch("us") - anchor_us
    bin_us = (elapsed // interval_us) * interval_us + anchor_us

    df = df.with_columns(
        pl.from_epoch(bin_us, time_unit="us").alias("_bin")
    )
    out = (
        df.group_by("_bin", maintain_order=True)
        .agg(*_OHLCV_AGG)
        .rename({"_bin": "ts"})
    )
    return out.select(list(BAR_COLUMNS)).sort("ts")


def mark_intraday_rolls(
    intraday: pl.DataFrame, daily: pl.DataFrame, session_tz: str = "Europe/London"
) -> pl.DataFrame:
    """Copy the daily roll flags onto the intraday bars of the same date.

    Intraday bars carry no ``FUT_CUR_GEN_TICKER``, so roll days are
    identified on the daily series and mapped across by date.

    Only the **first** intraday bar of a roll date is flagged. Flagging the
    whole day is both wrong and expensive: ``is_roll`` means "the contract
    changed at this bar", and :func:`back_adjust_factors` applies one gap
    correction per flagged bar - so a 24-bar roll day would compound
    twenty-four adjustments for a single roll and corrupt the whole history
    before it. It also drew the roll as a thick smear of vertical lines on
    the intraday charts rather than one marker.
    """
    if intraday.is_empty() or daily.is_empty():
        return intraday

    roll_dates = (
        daily.filter(pl.col("is_roll"))
        .select(pl.col("ts").dt.date().alias("_date"))
        .with_columns(pl.lit(True).alias("_roll"))
        .unique()
    )
    if roll_dates.is_empty():
        return intraday

    local_date = (
        pl.col("ts")
        .dt.replace_time_zone("UTC")
        .dt.convert_time_zone(session_tz)
        .dt.date()
        .alias("_date")
    )
    out = (
        intraday.sort("ts")
        .with_columns(local_date)
        .join(roll_dates, on="_date", how="left")
        .with_columns(pl.col("_roll").fill_null(False).alias("_roll"))
        .with_columns(
            (pl.int_range(pl.len()).over("_date") == 0).alias("_first_of_day")
        )
        .with_columns(
            (pl.col("is_roll") | (pl.col("_roll") & pl.col("_first_of_day"))).alias(
                "is_roll"
            )
        )
        .drop(["_date", "_roll", "_first_of_day"])
    )
    return out.select(list(BAR_COLUMNS)).sort("ts")


# ---------------------------------------------------------------------------
# roll adjustment
# ---------------------------------------------------------------------------
def back_adjust_factors(
    close: np.ndarray, open_: np.ndarray, is_roll: np.ndarray
) -> np.ndarray:
    """Multiplicative back-adjustment factors, anchored at the last bar.

    On a roll bar ``i`` the observed change ``C_i / C_{i-1}`` mixes the new
    contract's price level with the session's real move. The gap component
    is ``O_i / C_{i-1}``, so scaling every bar before ``i`` by that ratio
    makes the adjusted step across the roll equal ``C_i / O_i`` - the move
    that actually happened on the new contract.

    Factors are 1.0 from the last roll onwards, so recent bars - the ones
    the email quotes - are unadjusted traded prices.

    Where a product has no true open (PX_LAST only, so ``O == C``) the ratio
    collapses to ``C_i / C_{i-1}`` and the roll bar's adjusted return is
    zero. That is the same information loss as ``roll_method: drop``, which
    is the honest outcome when gap and move cannot be separated.
    """
    n = close.size
    factors = np.ones(n, dtype=np.float64)
    if n < 2:
        return factors

    for i in range(n - 1, 0, -1):
        if not is_roll[i]:
            continue
        prev_close = close[i - 1]
        open_i = open_[i]
        if not (np.isfinite(prev_close) and np.isfinite(open_i)):
            continue
        if prev_close <= 0 or open_i <= 0:
            continue
        ratio = open_i / prev_close
        if not np.isfinite(ratio) or ratio <= 0:
            continue
        factors[:i] *= ratio
    return factors


def apply_roll_adjustment(bars: pl.DataFrame, method: RollMethod) -> pl.DataFrame:
    """Add ``*_adj`` columns according to ``method``.

    ``backadjust``  multiplicative back-adjustment (see above).
    ``drop``        adjusted series equals the raw series, but the roll bar's
                    own O/H/L/C are masked so no indicator sees the gap.
    ``none``        adjusted series equals the raw series.
    """
    if bars.is_empty():
        return bars.with_columns(
            [pl.lit(None, dtype=pl.Float64).alias(c) for c in ADJ_COLUMNS]
        )

    raw = {
        col: bars.get_column(col).cast(pl.Float64).to_numpy().astype(np.float64)
        for col in ("open", "high", "low", "close")
    }
    is_roll = bars.get_column("is_roll").fill_null(False).to_numpy().astype(bool)

    if method == "backadjust":
        factors = back_adjust_factors(raw["close"], raw["open"], is_roll)
        adj = {f"{col}_adj": raw[col] * factors for col in raw}
    elif method == "drop":
        adj = {}
        for col, values in raw.items():
            masked = values.copy()
            masked[is_roll] = np.nan
            adj[f"{col}_adj"] = masked
    else:
        adj = {f"{col}_adj": raw[col].copy() for col in raw}

    return bars.with_columns(
        [pl.Series(name, values) for name, values in adj.items()]
    )


# ---------------------------------------------------------------------------
# horizon assembly
# ---------------------------------------------------------------------------
def build_horizon(
    daily: pl.DataFrame,
    intraday: pl.DataFrame,
    product: ProductConfig,
    horizon: HorizonConfig,
    cfg: StudyConfig,
    report: BarReport | None = None,
) -> pl.DataFrame:
    """The bar frame for one (product, horizon), trimmed and roll-adjusted.

    ``daily`` is the normalised daily series; ``intraday`` the normalised
    base-interval (usually 1h) series. Either may be empty, in which case
    the horizons that depend on it come back empty.
    """
    report = report or BarReport()

    if horizon.is_intraday:
        if intraday.is_empty():
            report.warn(
                f"{product.name} {horizon.name}: no intraday bars available"
            )
            return empty_bars()
        interval = horizon.interval_min or cfg.intraday_base_interval
        base = cfg.intraday_base_interval
        if interval < base:
            report.warn(
                f"{product.name} {horizon.name}: requested {interval}m bars but the "
                f"finest persisted interval is {base}m; using {base}m"
            )
            interval = base
        bars = (
            intraday
            if interval == base
            else resample_intraday(
                intraday,
                interval,
                session_start_minutes=product.session_start_minutes,
                session_tz=product.session_tz,
            )
        )
        bars = mark_intraday_rolls(bars, daily, product.session_tz)
    elif horizon.resample:
        bars = resample_weekly(daily, horizon.resample)
    else:
        bars = daily

    if bars.is_empty():
        report.record(product.name, horizon.name, bars)
        return bars

    # Keep the warm-up: indicators need ~200 bars before the EMA200 and the
    # 252-bar range are meaningful, so trim only once, at the end.
    bars = bars.tail(horizon.bars)
    bars = apply_roll_adjustment(bars, cfg.roll_method_for(product.name))
    report.record(product.name, horizon.name, bars)

    if bars.height < cfg.run.min_bars:
        report.warn(
            f"{product.name} {horizon.name}: {bars.height} bars "
            f"(need {cfg.run.min_bars})"
        )
    return bars


def daily_window(cfg: StudyConfig, as_of: dt.date) -> tuple[dt.date, dt.date]:
    """Bloomberg daily request window for a run dated ``as_of``."""
    return as_of - dt.timedelta(days=cfg.run.daily_lookback_days), as_of


def intraday_window(
    cfg: StudyConfig, as_of: dt.date
) -> tuple[dt.datetime, dt.datetime]:
    """Bloomberg intraday request window for a run dated ``as_of``.

    Clamped to the configured look-back; anything older is expected to come
    from the persisted ``INTRADAY_BARS`` table.
    """
    end = dt.datetime.combine(as_of, dt.time(23, 59))
    start = end - dt.timedelta(days=cfg.run.intraday_lookback_days)
    return start, end


def merge_intraday(
    persisted: pl.DataFrame, fetched: pl.DataFrame
) -> pl.DataFrame:
    """Union persisted history with a fresh Bloomberg top-up.

    Fetched bars win on a timestamp collision: a bar can be revised after
    the fact, and the newer read is the better one.
    """
    left = normalise_intraday(persisted) if not persisted.is_empty() else empty_bars()
    right = normalise_intraday(fetched) if not fetched.is_empty() else empty_bars()
    if left.is_empty():
        return right
    if right.is_empty():
        return left
    return (
        pl.concat([left, right], how="vertical")
        .unique(subset=["ts"], keep="last")
        .sort("ts")
    )


def to_pandas(bars: pl.DataFrame, use_adjusted: bool = False):  # type: ignore[no-untyped-def]
    """Bar frame as a pandas OHLCV frame indexed by ``ts``.

    The single conversion point for mplfinance. ``use_adjusted`` swaps in the
    back-adjusted columns, which the chart does *not* want - it shows traded
    prices with a roll marker.
    """
    cols = ["ts", "open", "high", "low", "close", "volume"]
    if use_adjusted and "close_adj" in bars.columns:
        frame = bars.select(
            pl.col("ts"),
            pl.col("open_adj").alias("open"),
            pl.col("high_adj").alias("high"),
            pl.col("low_adj").alias("low"),
            pl.col("close_adj").alias("close"),
            pl.col("volume"),
        )
    else:
        frame = bars.select([c for c in cols if c in bars.columns])

    pdf = frame.to_pandas().set_index("ts")
    pdf.index.name = "Date"
    pdf = pdf.rename(
        columns={
            "open": "Open",
            "high": "High",
            "low": "Low",
            "close": "Close",
            "volume": "Volume",
        }
    )
    return pdf
