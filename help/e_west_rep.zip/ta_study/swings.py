"""Swing high / low detection with honest confirmation times (§8a C).

A swing high sits at bar ``i`` when ``P_i`` is the maximum of the ``2k+1``
bar window centred on it *and* strictly exceeds its immediate neighbours::

    SH_i = 1[P_i >= P_{i+j}  for all j in [-k, k], j != 0]
         * 1[P_i > P_{i-1} and P_i > P_{i+1}]

Swing lows reverse every inequality.

The part that makes the backtest honest
---------------------------------------
A swing at bar ``i`` cannot be known until bar ``i + k``, because the
``k`` bars to its right have to exist before the window maximum is
decided. Every swing therefore carries ``confirmed_at = i + k``, and no
signal may be emitted before that bar. The last ``k`` bars of a series can
only hold **provisional** swings - the current bar is the running extremum
of a truncated window - which are flagged, rendered dashed, and never
generate a signal.

This module is pure: arrays in, a list of :class:`Swing` out. It does not
know what a divergence is.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]

SwingKind = Literal["H", "L"]

#: Prices within this relative tolerance count as tied when de-duplicating
#: two window extrema that share a value (§8a C, "keep the latest bar").
_TIE_RTOL = 1e-12


@dataclass(frozen=True)
class Swing:
    """One detected extremum.

    ``bar_idx`` indexes the bar series; ``confirmed_at`` is the first bar at
    which the swing is observable. ``provisional`` marks a swing whose
    right-hand window is incomplete, so ``confirmed_at`` lies in the future.
    """

    bar_idx: int
    kind: SwingKind
    price: float
    rsi: float
    confirmed_at: int
    provisional: bool
    ts: Any = None

    @property
    def is_high(self) -> bool:
        return self.kind == "H"

    def observable_at(self, bar: int) -> bool:
        """True when this swing may be used in a decision taken at ``bar``."""
        return not self.provisional and self.confirmed_at <= bar


def _swing_rsi(rsi: FloatArray, idx: int, kind: SwingKind, m: int) -> float:
    """RSI at the swing, optionally the extreme over +/- ``m`` bars (§8a C).

    ``m`` is capped at ``k`` by config validation, so this never reads a bar
    beyond ``confirmed_at``.
    """
    if rsi.size == 0:
        return float("nan")
    lo = max(0, idx - m)
    hi = min(rsi.size - 1, idx + m)
    window = rsi[lo : hi + 1]
    window = window[np.isfinite(window)]
    if window.size == 0:
        return float("nan")
    if m == 0:
        value = rsi[idx]
        return float(value) if np.isfinite(value) else float("nan")
    return float(np.max(window) if kind == "H" else np.min(window))


def _is_confirmed_extremum(p: FloatArray, i: int, k: int, high: bool) -> bool:
    """Full ``2k+1`` window test at bar ``i``."""
    n = p.size
    if i - k < 0 or i + k > n - 1:
        return False
    window = p[i - k : i + k + 1]
    if not np.all(np.isfinite(window)):
        return False
    centre = p[i]
    if high:
        if not np.all(centre >= window):
            return False
        return bool(centre > p[i - 1] and centre > p[i + 1])
    if not np.all(centre <= window):
        return False
    return bool(centre < p[i - 1] and centre < p[i + 1])


def _is_provisional_extremum(p: FloatArray, i: int, k: int, high: bool) -> bool:
    """Truncated-window test for the final ``k`` bars.

    ``P_i`` must be the running extremum of everything from ``i - k`` to the
    end of the series, and must still beat the bars adjacent to it.
    """
    n = p.size
    if i - k < 0 or i > n - 1:
        return False
    if n - 1 - i >= k:
        # A full right-hand window exists; this is not a provisional case.
        return False
    window = p[i - k :]
    if not np.all(np.isfinite(window)):
        return False
    centre = p[i]
    if high:
        if not np.all(centre >= window):
            return False
        if not centre > p[i - 1]:
            return False
        return bool(i == n - 1 or centre > p[i + 1])
    if not np.all(centre <= window):
        return False
    if not centre < p[i - 1]:
        return False
    return bool(i == n - 1 or centre < p[i + 1])


def _drop_ties(swings: list[Swing], k: int) -> list[Swing]:
    """Where two same-kind swings within ``k`` bars share a price, keep the
    later one (§8a C, tie rule)."""
    keep: list[Swing] = []
    for swing in swings:
        replaced = False
        for existing in list(keep):
            if existing.kind != swing.kind:
                continue
            if swing.bar_idx - existing.bar_idx > k:
                continue
            if np.isclose(existing.price, swing.price, rtol=_TIE_RTOL, atol=0.0):
                keep.remove(existing)
                keep.append(swing)
                replaced = True
                break
        if not replaced:
            keep.append(swing)
    return sorted(keep, key=lambda s: (s.bar_idx, s.kind))


def detect_swings(
    high: npt.ArrayLike,
    low: npt.ArrayLike,
    rsi: npt.ArrayLike,
    k: int = 5,
    rsi_tolerance_bars: int = 0,
    timestamps: Sequence[Any] | None = None,
    include_provisional: bool = True,
) -> list[Swing]:
    """Every swing in the series, ordered by bar index.

    For ``swing_price: close`` the caller passes the same close array as both
    ``high`` and ``low``; for ``highlow`` it passes the true high and low
    series (§8a A).

    Returns confirmed swings plus, when ``include_provisional``, at most one
    provisional high and one provisional low from the final ``k`` bars.
    """
    h = np.asarray(high, dtype=np.float64)
    lo = np.asarray(low, dtype=np.float64)
    r = np.asarray(rsi, dtype=np.float64)
    n = h.size
    if lo.size != n or r.size != n:
        msg = f"high/low/rsi length mismatch: {n}, {lo.size}, {r.size}"
        raise ValueError(msg)
    if k < 1:
        msg = f"swing_k must be >= 1, got {k}"
        raise ValueError(msg)

    def ts_at(i: int) -> Any:
        return timestamps[i] if timestamps is not None and i < len(timestamps) else None

    confirmed: list[Swing] = []
    for i in range(k, max(k, n - k)):
        for kind, series, is_high in (("H", h, True), ("L", lo, False)):
            if _is_confirmed_extremum(series, i, k, is_high):
                confirmed.append(
                    Swing(
                        bar_idx=i,
                        kind=kind,  # type: ignore[arg-type]
                        price=float(series[i]),
                        rsi=_swing_rsi(r, i, kind, rsi_tolerance_bars),  # type: ignore[arg-type]
                        confirmed_at=i + k,
                        provisional=False,
                        ts=ts_at(i),
                    )
                )
    swings = _drop_ties(confirmed, k)

    if not include_provisional:
        return swings

    # At most one provisional swing per side: the running extremum of the
    # tail. Scanning from the end and stopping at the first hit keeps the
    # most recent candidate, which is the one the email describes.
    for kind, series, is_high in (("H", h, True), ("L", lo, False)):
        for i in range(n - 1, max(k - 1, n - 1 - k), -1):
            if _is_provisional_extremum(series, i, k, is_high):
                swings.append(
                    Swing(
                        bar_idx=i,
                        kind=kind,  # type: ignore[arg-type]
                        price=float(series[i]),
                        rsi=_swing_rsi(r, i, kind, rsi_tolerance_bars),  # type: ignore[arg-type]
                        confirmed_at=i + k,
                        provisional=True,
                        ts=ts_at(i),
                    )
                )
                break

    return sorted(swings, key=lambda s: (s.bar_idx, s.kind, s.provisional))


def confirmed_swings(swings: Sequence[Swing], kind: SwingKind | None = None) -> list[Swing]:
    return [
        s
        for s in swings
        if not s.provisional and (kind is None or s.kind == kind)
    ]


def provisional_swings(swings: Sequence[Swing], kind: SwingKind | None = None) -> list[Swing]:
    return [s for s in swings if s.provisional and (kind is None or s.kind == kind)]


def observable_swings(swings: Sequence[Swing], bar: int) -> list[Swing]:
    """Swings usable in a decision taken at ``bar`` - the no-lookahead filter."""
    return [s for s in swings if s.observable_at(bar)]
