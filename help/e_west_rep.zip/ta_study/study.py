"""The Shternberg composite state machine (§8, §8a E-G).

Three ingredients, combined per (product, horizon):

1. **RSI divergence** (:mod:`ta_study.divergence`) - the primary signal,
   carrying a direction ``d`` and a strength ``sigma``.
2. **Stochastic %K/%D cross in zone** - confirmation. It is structurally
   lagging: a cross needs a retracement large enough to move ``HH``/``LL``
   plus ``s_K + s_D`` bars of smoothing, so ``t_c >= t*`` always. It changes
   the state label and the size multiplier, not whether the divergence is
   reported.
3. **ADX gate** - ``G_t = 1[ADX_t >= theta and ADX_t > ADX_{t-r}]`` marks a
   momentum-dominant regime in which mean-reversion expectancy is low.

The signal at bar ``t``, for the most recent divergence with
``t* <= t <= t* + W_a``::

    s_t = d
    c_t = 1[t_c exists and t_c <= t]
    kappa_t = sigma * (lambda_u + (1 - lambda_u) c_t)
                    * (1 - (1 - lambda_g) G_t)

``s_t`` is the directional bias and ``kappa_t`` in [0, 1] the suggested size
multiplier; ``s_t = 0`` outside the active window.

The state is evaluated over every bar rather than only the last one. That is
what makes ``DVG_GATE_RELEASING`` (defined against the previous bar's state)
expressible, gives the email its "what changed since yesterday" line for
free, and lets the backfill job replay history through the same code path.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import numpy.typing as npt
import polars as pl

from ta_study import indicators as ind
from ta_study.config import LIVE_STATES, State, StudyConfig
from ta_study.divergence import (
    Divergence,
    detect_divergences,
    detect_provisional,
)
from ta_study.swings import Swing, detect_swings

FloatArray = npt.NDArray[np.float64]
BoolArray = npt.NDArray[np.bool_]

#: Bar columns :func:`compute_series` needs.
REQUIRED_COLUMNS = ("ts", "open", "high", "low", "close")


def _col(df: pl.DataFrame, name: str, default: float = np.nan) -> FloatArray:
    if name not in df.columns:
        return np.full(df.height, default, dtype=np.float64)
    return df.get_column(name).cast(pl.Float64).to_numpy().astype(np.float64)


def _bool_col(df: pl.DataFrame, name: str) -> BoolArray:
    if name not in df.columns:
        return np.zeros(df.height, dtype=bool)
    return df.get_column(name).fill_null(False).cast(pl.Boolean).to_numpy().astype(bool)


# ---------------------------------------------------------------------------
# indicator bundle
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class StudySeries:
    """Every array the state machine and the charts need, one bar per row.

    ``close`` is the display (unadjusted) close; ``close_study`` is what the
    indicators ran on, which for ``roll_method: backadjust`` is the
    back-adjusted series (§4). Keeping both means the chart can show traded
    prices while the study sees a continuous one.
    """

    ts: list[Any]
    open: FloatArray
    high: FloatArray
    low: FloatArray
    close: FloatArray
    volume: FloatArray
    is_roll: BoolArray

    close_study: FloatArray
    high_study: FloatArray
    low_study: FloatArray

    rsi: FloatArray
    k: FloatArray
    d: FloatArray
    k_raw: FloatArray
    adx: FloatArray
    plus_di: FloatArray
    minus_di: FloatArray
    atr: FloatArray

    cross_up: BoolArray
    cross_down: BoolArray
    gate: BoolArray
    adx_rising: BoolArray
    adx_falling: BoolArray

    swing_high_price: FloatArray
    swing_low_price: FloatArray

    adx_threshold: float

    @property
    def n(self) -> int:
        return len(self.ts)

    @property
    def last(self) -> int:
        return self.n - 1

    def at(self, arr: FloatArray, bar: int | None = None) -> float:
        """Array value at ``bar`` (default: the last bar) as a float or NaN."""
        if self.n == 0:
            return float("nan")
        i = self.last if bar is None else bar
        if not (0 <= i < arr.size):
            return float("nan")
        value = arr[i]
        return float(value) if np.isfinite(value) else float("nan")


def compute_series(
    bars: pl.DataFrame, cfg: StudyConfig, product: str
) -> StudySeries:
    """Run every indicator over one (product, horizon) bar frame.

    ``bars`` must carry ``ts, open, high, low, close`` and may carry
    ``volume``, ``is_roll`` and the ``*_adj`` columns produced by
    :mod:`ta_study.data`. Indicators run on the adjusted series when it is
    present, which is what keeps a roll gap out of RSI and ADX.
    """
    missing = [c for c in REQUIRED_COLUMNS if c not in bars.columns]
    if missing:
        msg = f"bar frame is missing required columns: {missing}"
        raise ValueError(msg)

    bars = bars.sort("ts")
    ts = bars.get_column("ts").to_list()

    open_ = _col(bars, "open")
    high = _col(bars, "high")
    low = _col(bars, "low")
    close = _col(bars, "close")
    volume = _col(bars, "volume", default=0.0)
    is_roll = _bool_col(bars, "is_roll")

    # Adjusted series for the momentum indicators; fall back to raw when the
    # data layer did not produce one (roll_method: drop / none).
    close_study = _col(bars, "close_adj") if "close_adj" in bars.columns else close
    high_study = _col(bars, "high_adj") if "high_adj" in bars.columns else high
    low_study = _col(bars, "low_adj") if "low_adj" in bars.columns else low
    if not np.any(np.isfinite(close_study)):
        close_study, high_study, low_study = close, high, low

    icfg = cfg.indicators
    rsi = ind.rsi(close_study, icfg.rsi.period)
    st = ind.stoch(
        high_study,
        low_study,
        close_study,
        k_period=icfg.stoch.k_period,
        k_smooth=icfg.stoch.k_smooth,
        d_period=icfg.stoch.d_period,
        fast=icfg.stoch.fast,
    )
    dm = ind.dmi(high_study, low_study, close_study, icfg.adx.period)
    atr = ind.atr(high_study, low_study, close_study, icfg.atr.period)

    cross_up, cross_down = ind.stoch_crosses(
        st.k, st.d, ob=icfg.stoch.ob, os=icfg.stoch.os
    )
    threshold = cfg.adx_threshold_for(product)
    r = cfg.adx_gate.rising_slope_bars
    gate = ind.adx_gate(dm.adx, threshold, r)
    rising = ind.adx_rising(dm.adx, r)
    falling = ind.adx_falling_streak(dm.adx, r)

    # §8a A: swing_price picks which series the swing detector sees.
    if cfg.divergence.swing_price == "highlow":
        swing_high, swing_low = high_study, low_study
    else:
        swing_high = swing_low = close_study

    return StudySeries(
        ts=ts,
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=volume,
        is_roll=is_roll,
        close_study=close_study,
        high_study=high_study,
        low_study=low_study,
        rsi=rsi,
        k=st.k,
        d=st.d,
        k_raw=st.k_raw,
        adx=dm.adx,
        plus_di=dm.plus_di,
        minus_di=dm.minus_di,
        atr=atr,
        cross_up=cross_up,
        cross_down=cross_down,
        gate=gate,
        adx_rising=rising,
        adx_falling=falling,
        swing_high_price=swing_high,
        swing_low_price=swing_low,
        adx_threshold=threshold,
    )


# ---------------------------------------------------------------------------
# confirmation (§8a E)
# ---------------------------------------------------------------------------
def confirmation_bar(
    event: Divergence,
    series: StudySeries,
    confirmation_window: int,
) -> int | None:
    """``t_c = min{t in [t*, t* + W_c] : X^d_t = 1}``, or ``None``.

    A bullish divergence needs ``X+`` (%K crossing up from below the
    oversold line); a bearish one needs ``X-``. A cross outside the zone, or
    after the window, does not confirm.
    """
    crosses = series.cross_up if event.direction > 0 else series.cross_down
    lo = event.triggered_at
    hi = min(lo + confirmation_window, crosses.size - 1)
    for t in range(max(lo, 0), hi + 1):
        if crosses[t]:
            return t
    return None


def gate_release_bar(
    series: StudySeries, start: int, r: int
) -> int | None:
    """First bar at or after ``start`` where the ADX gate opens (§8a F).

    Either ADX has fallen on each of ``r`` consecutive bars, or ADX has
    dropped back below the product's threshold.
    """
    for t in range(max(start, 0), series.n):
        adx = series.adx[t]
        below = bool(np.isfinite(adx) and adx < series.adx_threshold)
        if below or series.adx_falling[t]:
            return t
    return None


# ---------------------------------------------------------------------------
# state evaluation
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class BarState:
    """The state machine's output at one bar."""

    bar: int
    state: State
    direction: int
    confirmed: bool
    gated: bool
    size_multiplier: float
    strength: float
    event: Divergence | None
    confirmed_at: int | None
    bars_since_dvg: int | None

    @property
    def live(self) -> bool:
        return self.state in LIVE_STATES


def _size_multiplier(
    sigma: float, confirmed: bool, gated: bool, cfg: StudyConfig
) -> float:
    """kappa_t = sigma (lambda_u + (1-lambda_u) c) (1 - (1-lambda_g) G)."""
    lam_u = cfg.signal.unconfirmed_multiplier
    lam_g = cfg.signal.gated_multiplier
    conf_factor = lam_u + (1.0 - lam_u) * (1.0 if confirmed else 0.0)
    gate_factor = 1.0 - (1.0 - lam_g) * (1.0 if gated else 0.0)
    return float(max(0.0, min(1.0, sigma * conf_factor * gate_factor)))


def evaluate_states(
    series: StudySeries,
    events: Sequence[Divergence],
    cfg: StudyConfig,
    provisional: Sequence[Divergence] = (),
) -> list[BarState]:
    """The state at every bar, in bar order.

    Only events whose ``t*`` has arrived are considered at each bar, so the
    series is free of lookahead by construction (§8a I).
    """
    dcfg = cfg.divergence
    usable = [e for e in events if dcfg.include_hidden or not e.hidden]
    usable = sorted(usable, key=lambda e: (e.triggered_at, e.s2.bar_idx))

    conf_bar = {
        id(e): confirmation_bar(e, series, dcfg.confirmation_window) for e in usable
    }

    out: list[BarState] = []
    cursor = -1  # index into `usable` of the most recent triggered event
    prev_state: State = "NONE"

    for t in range(series.n):
        while cursor + 1 < len(usable) and usable[cursor + 1].triggered_at <= t:
            cursor += 1

        event = usable[cursor] if cursor >= 0 else None
        state: State = "NONE"
        direction = 0
        confirmed = False
        gated = False
        sigma = 0.0
        kappa = 0.0
        t_c: int | None = None
        bars_since: int | None = None

        if event is not None:
            t_c = conf_bar[id(event)]
            bars_since = t - event.triggered_at
            gated = bool(series.gate[t])
            sigma = event.strength

            if t <= event.expires_at(dcfg.active_window):
                direction = event.direction
                confirmed = t_c is not None and t_c <= t
                kappa = _size_multiplier(sigma, confirmed, gated, cfg)
                if gated:
                    state = "DVG_GATED"
                elif confirmed:
                    state = "DVG_CONFIRMED"
                else:
                    state = "DVG_ACTIVE"
            elif t_c is None and t <= event.expires_at(
                dcfg.active_window + dcfg.expired_window
            ):
                state = "DVG_EXPIRED"

            # §8a F: a gated divergence becomes actionable again the moment
            # the gate opens. Defined against the previous bar's state, so it
            # can only be detected while walking the series.
            if (
                prev_state == "DVG_GATED"
                and not gated
                and state in ("DVG_ACTIVE", "DVG_CONFIRMED")
                and (
                    series.adx_falling[t]
                    or (
                        np.isfinite(series.adx[t])
                        and series.adx[t] < series.adx_threshold
                    )
                )
            ):
                state = "DVG_GATE_RELEASING"

        out.append(
            BarState(
                bar=t,
                state=state,
                direction=direction,
                confirmed=confirmed,
                gated=gated,
                size_multiplier=kappa,
                strength=sigma if state != "NONE" else 0.0,
                event=event if state != "NONE" else None,
                confirmed_at=t_c if state != "NONE" else None,
                bars_since_dvg=bars_since if state != "NONE" else None,
            )
        )
        prev_state = state

    # PROVISIONAL is informational and only exists on the final bar, where a
    # truncated-window swing can still exist. It never displaces a live state.
    if out and provisional:
        last = out[-1]
        if last.state in ("NONE", "DVG_EXPIRED"):
            candidate = max(provisional, key=lambda e: e.s2.bar_idx)
            out[-1] = BarState(
                bar=last.bar,
                state="PROVISIONAL",
                direction=0,
                confirmed=False,
                gated=bool(series.gate[last.bar]) if series.n else False,
                size_multiplier=0.0,
                strength=candidate.strength,
                event=candidate,
                confirmed_at=None,
                bars_since_dvg=None,
            )

    return out


# ---------------------------------------------------------------------------
# the per-(product, horizon) result
# ---------------------------------------------------------------------------
@dataclass
class StudyResult:
    """Everything one (product, horizon) contributes to the email."""

    product: str
    horizon: str
    as_of: Any
    n_bars: int

    state: State
    direction: int
    confirmed: bool
    gated: bool
    size_multiplier: float
    strength: float
    bars_since_dvg: int | None

    # raw ingredients (§8)
    close: float
    rsi: float
    k: float
    d: float
    adx: float
    plus_di: float
    minus_di: float
    atr: float
    adx_rising: bool
    adx_threshold: float

    event: Divergence | None = None
    provisional_event: Divergence | None = None
    confirmed_at_bar: int | None = None
    prev_state: State | None = None

    series: StudySeries | None = field(default=None, repr=False)
    swings: list[Swing] = field(default_factory=list, repr=False)
    events: list[Divergence] = field(default_factory=list, repr=False)
    bar_states: list[BarState] = field(default_factory=list, repr=False)
    warnings: list[str] = field(default_factory=list)

    @property
    def key(self) -> tuple[str, str]:
        return (self.product, self.horizon)

    @property
    def live(self) -> bool:
        return self.state in LIVE_STATES

    @property
    def changed(self) -> bool:
        return self.prev_state is not None and self.prev_state != self.state

    @property
    def direction_label(self) -> str:
        if self.direction > 0:
            return "BULL"
        if self.direction < 0:
            return "BEAR"
        return ""

    @property
    def arrow(self) -> str:
        if self.direction > 0:
            return "▲"  # up triangle
        if self.direction < 0:
            return "▼"  # down triangle
        return "·"

    @property
    def signed_kappa(self) -> float:
        """``s_t * kappa_t`` - the term this cell contributes to alignment."""
        return self.direction * self.size_multiplier


def run_study(
    bars: pl.DataFrame,
    cfg: StudyConfig,
    product: str,
    horizon: str,
    prev_state: State | None = None,
) -> StudyResult:
    """Full study for one (product, horizon): indicators, swings,
    divergences, state machine.

    Raises nothing on short history: a frame with fewer than
    ``run.min_bars`` rows comes back as a ``NONE`` result carrying a warning,
    which the email reports in its "insufficient bars" appendix.
    """
    series = compute_series(bars, cfg, product)
    warnings: list[str] = []

    if series.n < cfg.run.min_bars:
        warnings.append(
            f"{product} {horizon}: only {series.n} bars "
            f"(need {cfg.run.min_bars}); study skipped"
        )
        return StudyResult(
            product=product,
            horizon=horizon,
            as_of=series.ts[-1] if series.n else None,
            n_bars=series.n,
            state="NONE",
            direction=0,
            confirmed=False,
            gated=False,
            size_multiplier=0.0,
            strength=0.0,
            bars_since_dvg=None,
            close=series.at(series.close),
            rsi=float("nan"),
            k=float("nan"),
            d=float("nan"),
            adx=float("nan"),
            plus_di=float("nan"),
            minus_di=float("nan"),
            atr=float("nan"),
            adx_rising=False,
            adx_threshold=series.adx_threshold,
            series=series,
            prev_state=prev_state,
            warnings=warnings,
        )

    dcfg = cfg.divergence
    swings = detect_swings(
        series.swing_high_price,
        series.swing_low_price,
        series.rsi,
        k=dcfg.swing_k,
        rsi_tolerance_bars=dcfg.rsi_tolerance_bars,
        timestamps=series.ts,
    )
    events = detect_divergences(swings, series.atr, dcfg, cfg.indicators.rsi, cfg.signal)
    provisional = detect_provisional(
        swings, series.atr, dcfg, cfg.indicators.rsi, cfg.signal
    )
    bar_states = evaluate_states(series, events, cfg, provisional)

    last = bar_states[-1]
    prov_event = last.event if last.state == "PROVISIONAL" else None
    live_event = last.event if last.state != "PROVISIONAL" else None

    return StudyResult(
        product=product,
        horizon=horizon,
        as_of=series.ts[-1],
        n_bars=series.n,
        state=last.state,
        direction=last.direction,
        confirmed=last.confirmed,
        gated=last.gated,
        size_multiplier=last.size_multiplier,
        strength=last.strength,
        bars_since_dvg=last.bars_since_dvg,
        close=series.at(series.close),
        rsi=series.at(series.rsi),
        k=series.at(series.k),
        d=series.at(series.d),
        adx=series.at(series.adx),
        plus_di=series.at(series.plus_di),
        minus_di=series.at(series.minus_di),
        atr=series.at(series.atr),
        adx_rising=bool(series.adx_rising[series.last]),
        adx_threshold=series.adx_threshold,
        event=live_event,
        provisional_event=prov_event,
        confirmed_at_bar=last.confirmed_at,
        prev_state=prev_state,
        series=series,
        swings=swings,
        events=events,
        bar_states=bar_states,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# cross-horizon alignment (§8, §8a G)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Alignment:
    """``A_p = sum_h s_t^(h) kappa_t^(h)`` for one product."""

    product: str
    score: float
    horizons: tuple[str, ...]
    direction: int

    @property
    def magnitude(self) -> float:
        return abs(self.score)

    @property
    def n_horizons(self) -> int:
        return len(self.horizons)

    @property
    def label(self) -> str:
        arrow = "▲" if self.direction > 0 else "▼"
        return f"{arrow} {'/'.join(self.horizons)}"


def alignment(results: Sequence[StudyResult], min_horizons: int = 2) -> list[Alignment]:
    """Products where at least ``min_horizons`` horizons agree in direction.

    Only live states contribute. Sorted by absolute score, so a
    weekly + daily + 4h agreement leads the email.
    """
    by_product: dict[str, list[StudyResult]] = {}
    for res in results:
        if res.live and res.direction != 0:
            by_product.setdefault(res.product, []).append(res)

    out: list[Alignment] = []
    for product, group in by_product.items():
        for sign in (1, -1):
            same = [r for r in group if r.direction == sign]
            if len(same) < min_horizons:
                continue
            score = sum(r.signed_kappa for r in same)
            out.append(
                Alignment(
                    product=product,
                    score=float(score),
                    horizons=tuple(r.horizon for r in same),
                    direction=sign,
                )
            )

    return sorted(out, key=lambda a: (-a.magnitude, a.product))
