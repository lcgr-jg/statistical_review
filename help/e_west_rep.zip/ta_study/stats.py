"""Forward returns and hit rates - testing the study's own hypothesis (§8a H).

The study asserts that, for a forward horizon of ``h`` bars,

    E[ d * (C_{t*+h} - C_{t*}) | regular divergence, G_{t*} = 0 ] > 0

and that the inequality weakens or reverses when the ADX gate was closed at
the trigger. This module estimates that conditional mean - in ATR units and
in per cent - together with its hit rate, split by ``(confirmed, gated)``,
so the email can report whether the hypothesis holds per product × horizon
rather than asserting that it does.

Two rules keep the numbers honest:

* a forward return is only computed once ``h`` bars have actually elapsed
  past ``t*``; unelapsed events are recorded with a null return and filled
  in by the nightly job,
* a hit rate is displayed only at or above ``stats.min_sample``
  observations; below that the email says ``n=…, insufficient`` rather than
  printing a number the desk might act on.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import numpy.typing as npt

from ta_study.config import StatsConfig, StudyConfig
from ta_study.study import StudyResult, confirmation_bar

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True)
class ForwardReturn:
    """Realised move over ``bars`` bars from the trigger."""

    bars: int
    pct: float | None
    atr_units: float | None
    signed_pct: float | None
    signed_atr: float | None

    @property
    def elapsed(self) -> bool:
        return self.pct is not None

    @property
    def hit(self) -> bool | None:
        """True when the move went the way the divergence pointed."""
        if self.signed_pct is None:
            return None
        return self.signed_pct > 0


def forward_return(
    close: FloatArray,
    atr: FloatArray,
    trigger_bar: int,
    bars: int,
    direction: int,
) -> ForwardReturn:
    """``d * (C_{t*+h} - C_{t*})`` in per cent and in ATR units.

    Returns nulls when ``t* + h`` lies beyond the series - the event has not
    had time to resolve - or when the anchor values are missing.
    """
    end = trigger_bar + bars
    if trigger_bar < 0 or end >= close.size:
        return ForwardReturn(bars, None, None, None, None)

    c0, c1 = close[trigger_bar], close[end]
    if not (np.isfinite(c0) and np.isfinite(c1)) or c0 == 0:
        return ForwardReturn(bars, None, None, None, None)

    move = float(c1 - c0)
    pct = move / abs(float(c0))

    atr0 = atr[trigger_bar] if trigger_bar < atr.size else np.nan
    atr_units = (
        float(move / atr0) if np.isfinite(atr0) and atr0 > 0 else None
    )

    return ForwardReturn(
        bars=bars,
        pct=pct,
        atr_units=atr_units,
        signed_pct=direction * pct,
        signed_atr=None if atr_units is None else direction * atr_units,
    )


# ---------------------------------------------------------------------------
# event records (the persisted shape)
# ---------------------------------------------------------------------------
@dataclass
class EventRecord:
    """One divergence event with everything needed to score it later."""

    product: str
    horizon: str
    triggered_ts: Any
    s1_ts: Any
    s2_ts: Any
    kind: str
    hidden: bool
    direction: int
    strength: float
    strength_rsi: float
    strength_price: float
    strength_zone: float
    d_price: float
    d_rsi: float
    confirmed: bool
    gated: bool
    confirmation_lag: int | None
    trigger_close: float | None
    trigger_atr: float | None
    returns: dict[int, ForwardReturn] = field(default_factory=dict)

    @property
    def key(self) -> tuple[str, str, Any]:
        return (self.product, self.horizon, self.triggered_ts)

    def bucket(self) -> tuple[str, str, int, bool, bool]:
        return (self.product, self.horizon, self.direction, self.confirmed, self.gated)


def event_records(result: StudyResult, cfg: StudyConfig) -> list[EventRecord]:
    """Every divergence in one (product, horizon), scored where possible.

    ``confirmed`` and ``gated`` are evaluated **at the trigger bar** - which
    is what §8a H conditions on - not at the latest bar. A divergence that
    was gated when it fired and ungated a week later still belongs in the
    gated bucket, because that is the decision the desk faced.
    """
    series = result.series
    if series is None or series.n == 0:
        return []

    dcfg = cfg.divergence
    out: list[EventRecord] = []

    for event in result.events:
        if event.hidden and not dcfg.include_hidden:
            continue
        t_star = event.triggered_at
        if t_star >= series.n:
            # The trigger bar has not printed yet; nothing to record.
            continue

        t_c = confirmation_bar(event, series, dcfg.confirmation_window)
        confirmed = t_c is not None
        gated = bool(series.gate[t_star])

        record = EventRecord(
            product=result.product,
            horizon=result.horizon,
            triggered_ts=series.ts[t_star],
            s1_ts=event.s1.ts,
            s2_ts=event.s2.ts,
            kind=event.kind,
            hidden=event.hidden,
            direction=event.direction,
            strength=event.strength,
            strength_rsi=event.strength_rsi,
            strength_price=event.strength_price,
            strength_zone=event.strength_zone,
            d_price=event.d_price,
            d_rsi=event.d_rsi,
            confirmed=confirmed,
            gated=gated,
            confirmation_lag=None if t_c is None else t_c - t_star,
            trigger_close=series.at(series.close_study, t_star),
            trigger_atr=series.at(series.atr, t_star),
        )
        for h in cfg.stats.forward_bars:
            record.returns[h] = forward_return(
                series.close_study, series.atr, t_star, h, event.direction
            )
        out.append(record)

    return out


# ---------------------------------------------------------------------------
# hit rates
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class HitRate:
    """Conditional performance for one bucket and forward horizon."""

    product: str
    horizon: str
    direction: int
    confirmed: bool
    gated: bool
    forward_bars: int
    count: int
    hit_rate: float | None
    mean_atr: float | None
    mean_pct: float | None
    expectancy: float | None
    min_sample: int

    @property
    def sufficient(self) -> bool:
        return self.count >= self.min_sample

    @property
    def direction_label(self) -> str:
        return "bull" if self.direction > 0 else "bear"

    def caption(self) -> str:
        """One clause for a chart caption, in plain words.

        Below ``min_sample`` this deliberately refuses to print a rate: a
        hit rate off three observations is noise, and printing it invites
        the desk to act on it.
        """
        if not self.sufficient or self.hit_rate is None:
            if self.count == 0:
                return "no comparable cases on record yet"
            plural = "case" if self.count == 1 else "cases"
            return f"only {self.count} comparable {plural} on record — too few to judge"
        parts = [f"went the right way {self.hit_rate:.0%} of {self.count} times"]
        if self.mean_atr is not None:
            parts.append(f"averaging {self.mean_atr:+.2f} ATR")
        return ", ".join(parts)


def _mean(values: Sequence[float | None]) -> float | None:
    finite = [float(v) for v in values if v is not None and np.isfinite(v)]
    return float(np.mean(finite)) if finite else None


def _weighted_mean(pairs: Sequence[tuple[float, int]]) -> float | None:
    total = sum(w for _, w in pairs)
    if not pairs or total <= 0:
        return None
    return float(sum(v * w for v, w in pairs) / total)


def hit_rates(
    records: Iterable[EventRecord], cfg: StatsConfig
) -> list[HitRate]:
    """Aggregate scored events into per-bucket, per-horizon statistics.

    Buckets are ``(product, horizon, direction, confirmed, gated)``, exactly
    the split §12 asks for. Only elapsed returns contribute, so a bucket's
    count grows as events resolve.
    """
    buckets: dict[tuple[str, str, int, bool, bool, int], list[ForwardReturn]] = {}

    for record in records:
        for h, ret in record.returns.items():
            if not ret.elapsed:
                continue
            key = (*record.bucket(), h)
            buckets.setdefault(key, []).append(ret)

    out: list[HitRate] = []
    for key, rets in sorted(buckets.items()):
        product, horizon, direction, confirmed, gated, h = key
        hits = [r.hit for r in rets if r.hit is not None]
        signed_atr = [r.signed_atr for r in rets if r.signed_atr is not None]
        signed_pct = [r.signed_pct for r in rets if r.signed_pct is not None]

        rate = float(np.mean(hits)) if hits else None
        mean_atr = _mean(signed_atr)
        mean_pct = _mean(signed_pct)

        out.append(
            HitRate(
                product=product,
                horizon=horizon,
                direction=direction,
                confirmed=confirmed,
                gated=gated,
                forward_bars=h,
                count=len(rets),
                hit_rate=rate,
                mean_atr=mean_atr,
                mean_pct=mean_pct,
                # Expectancy in ATR units is just the conditional mean of the
                # signed move, which is the quantity §8a H puts a sign on.
                expectancy=mean_atr,
                min_sample=cfg.min_sample,
            )
        )
    return out


class HitRateIndex:
    """Lookup used by the chart captions.

    Falls back from the exact ``(confirmed, gated)`` bucket to a
    direction-only bucket, and reports the sample size either way, so a
    caption never silently quotes a different population than it claims.
    """

    def __init__(self, rates: Sequence[HitRate], cfg: StatsConfig) -> None:
        self.cfg = cfg
        self._exact: dict[tuple[str, str, int, bool, bool, int], HitRate] = {}
        for rate in rates:
            self._exact[
                (
                    rate.product,
                    rate.horizon,
                    rate.direction,
                    rate.confirmed,
                    rate.gated,
                    rate.forward_bars,
                )
            ] = rate

    def lookup(
        self,
        product: str,
        horizon: str,
        direction: int,
        confirmed: bool,
        gated: bool,
        forward_bars: int | None = None,
    ) -> HitRate | None:
        h = forward_bars or self.cfg.headline_forward_bars
        return self._exact.get((product, horizon, direction, confirmed, gated, h))

    def caption(
        self,
        product: str,
        horizon: str,
        direction: int,
        confirmed: bool,
        gated: bool,
        forward_bars: int | None = None,
    ) -> str:
        h = forward_bars or self.cfg.headline_forward_bars
        rate = self.lookup(product, horizon, direction, confirmed, gated, h)
        if rate is None:
            return (
                f"Track record over the next {h} bars: no comparable cases on "
                "record yet."
            )
        return f"Track record over the next {h} bars: {rate.caption()}."


def hypothesis_check(rates: Sequence[HitRate], cfg: StatsConfig) -> dict[str, Any]:
    """Does the gate actually help? (§8a H)

    Compares mean signed ATR move for ungated versus gated events across all
    sufficiently-sampled buckets. Reported in the appendix so the desk can
    see the study being marked against its own claim.
    """
    ungated = [r for r in rates if not r.gated and r.sufficient and r.mean_atr is not None]
    gated = [r for r in rates if r.gated and r.sufficient and r.mean_atr is not None]

    def summarise(group: Sequence[HitRate]) -> dict[str, Any]:
        if not group:
            return {"buckets": 0, "n": 0, "mean_atr": None, "hit_rate": None}
        # Weight each bucket by its sample count so a 200-observation bucket
        # is not averaged on equal terms with a 20-observation one.
        atr_pairs = [(r.mean_atr, r.count) for r in group if r.mean_atr is not None]
        rate_pairs = [(r.hit_rate, r.count) for r in group if r.hit_rate is not None]
        return {
            "buckets": len(group),
            "n": sum(r.count for r in group),
            "mean_atr": _weighted_mean(atr_pairs),
            "hit_rate": _weighted_mean(rate_pairs),
        }

    ung = summarise(ungated)
    gat = summarise(gated)
    holds: bool | None = None
    if ung["mean_atr"] is not None:
        holds = ung["mean_atr"] > 0
    return {
        "min_sample": cfg.min_sample,
        "ungated": ung,
        "gated": gat,
        "hypothesis_holds": holds,
        "gate_helps": (
            None
            if ung["mean_atr"] is None or gat["mean_atr"] is None
            else ung["mean_atr"] > gat["mean_atr"]
        ),
    }
