"""Command line interface.

    python -m ta_study.cli run --dry-run
    python -m ta_study.cli run --date 2026-09-17 --product TTF --horizon D
    python -m ta_study.cli backfill --start 2026-01-01 --end 2026-09-17
    python -m ta_study.cli stats
    python -m ta_study.cli validate

``--date`` / ``--as-of`` reruns are deterministic (§15): the same date with a
warm cache produces the same email, and the state MERGE is keyed on the run
*date* so a rerun replaces rather than appends.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import logging
import sys
from pathlib import Path

from ta_study.config import load_config
from ta_study.pipeline import (
    backfill_study_state,
    configure_logging,
    fill_forward_returns,
    run_ta_study,
)


def _date(value: str) -> dt.date:
    try:
        return dt.date.fromisoformat(value)
    except ValueError as exc:
        msg = f"expected YYYY-MM-DD, got {value!r}"
        raise argparse.ArgumentTypeError(msg) from exc


def _add_global_flags(parser: argparse.ArgumentParser, *, top_level: bool) -> None:
    """Flags accepted either before or after the subcommand.

    On the subparsers the defaults are ``SUPPRESS`` so that an omitted flag
    leaves the attribute untouched; otherwise a subparser default would
    silently overwrite a value given ahead of the subcommand
    (``--plain-logs run`` would come back as ``plain_logs=False``).
    """
    path_default = None if top_level else argparse.SUPPRESS
    flag_default = False if top_level else argparse.SUPPRESS

    parser.add_argument(
        "--config", type=Path, default=path_default, help="path to ta_products.yaml"
    )
    parser.add_argument(
        "--base-dir", type=Path, default=path_default, help="root for cache/output/state"
    )
    parser.add_argument("-v", "--verbose", action="store_true", default=flag_default)
    parser.add_argument(
        "--plain-logs",
        action="store_true",
        default=flag_default,
        help="human-readable logs instead of structured JSON",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ta_study",
        description="Daily technical analysis email (Shternberg study)",
    )
    _add_global_flags(parser, top_level=True)

    shared = argparse.ArgumentParser(add_help=False)
    _add_global_flags(shared, top_level=False)

    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser(
        "run", help="run the study and send the email", parents=[shared]
    )
    run.add_argument("--date", "--as-of", dest="date", type=_date, default=None)
    run.add_argument(
        "--dry-run",
        action="store_true",
        help="write the HTML and charts to the output directory, do not send",
    )
    run.add_argument(
        "--offline",
        action="store_true",
        help="skip Bloomberg entirely (cache/Snowflake only)",
    )
    run.add_argument("--to", action="append", default=None, help="override a recipient")
    run.add_argument("--product", action="append", default=None, help="restrict to a product")
    run.add_argument("--horizon", action="append", default=None, help="restrict to a horizon")
    run.add_argument("--no-cache", action="store_true", help="bypass the Parquet cache")
    run.add_argument(
        "--no-parallel", action="store_true", help="render charts in-process"
    )

    back = sub.add_parser(
        "backfill", help="replay study_state over a date range", parents=[shared]
    )
    back.add_argument("--start", type=_date, required=True)
    back.add_argument("--end", type=_date, required=True)
    back.add_argument("--offline", action="store_true")
    back.add_argument("--no-cache", action="store_true")

    stats = sub.add_parser(
        "stats", help="fill forward returns and report hit rates", parents=[shared]
    )
    stats.add_argument("--date", "--as-of", dest="date", type=_date, default=None)
    stats.add_argument("--offline", action="store_true")
    stats.add_argument("--no-cache", action="store_true")

    sub.add_parser(
        "validate", help="load and validate the config, then exit", parents=[shared]
    )

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    configure_logging(
        level=logging.DEBUG if args.verbose else logging.INFO,
        json_logs=not args.plain_logs,
    )

    if args.command == "validate":
        cfg = load_config(args.config)
        pairs = cfg.pairs()
        print(
            json.dumps(
                {
                    "products": [p.name for p in cfg.products],
                    "horizons": [h.name for h in cfg.active_horizons],
                    "pairs": len(pairs),
                    "recipients": cfg.run.recipients,
                    "transport": cfg.delivery.transport,
                    "persist_enabled": cfg.persist.enabled,
                    "roll_method": cfg.roll_method,
                },
                indent=2,
            )
        )
        return 0

    if args.command == "run":
        try:
            result = run_ta_study(
                config_path=args.config,
                as_of=args.date,
                dry_run=args.dry_run,
                recipients=args.to,
                use_cache=not args.no_cache,
                no_parallel=args.no_parallel,
                products=args.product,
                horizons=args.horizon,
                base_dir=args.base_dir,
                offline=args.offline,
            )
        except (RuntimeError, ValueError, ModuleNotFoundError) as exc:
            # "Nothing to say" is the one condition allowed to fail the run,
            # and it is a routine outcome of --offline against a cold cache;
            # a wrong interpreter or a missing credential is equally routine.
            # All of them get a message rather than a traceback.
            print(f"ta_study: {exc}", file=sys.stderr)
            if args.offline:
                print(
                    "hint: --offline uses only the Parquet cache and Snowflake; "
                    "run once without it to populate them.",
                    file=sys.stderr,
                )
            return 1
        print(json.dumps(result.to_metadata(), indent=2))
        return 0

    if args.command == "backfill":
        if args.start > args.end:
            print("--start must not be after --end", file=sys.stderr)
            return 2
        summary = backfill_study_state(
            start=args.start,
            end=args.end,
            config_path=args.config,
            base_dir=args.base_dir,
            offline=args.offline,
            use_cache=not args.no_cache,
        )
        print(json.dumps(summary, indent=2))
        return 0

    if args.command == "stats":
        summary = fill_forward_returns(
            config_path=args.config,
            as_of=args.date,
            base_dir=args.base_dir,
            offline=args.offline,
            use_cache=not args.no_cache,
        )
        print(json.dumps(summary, indent=2, default=str))
        return 0

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
