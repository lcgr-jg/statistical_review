"""Independent reference implementations, used only by the parity tests.

Three backends, in decreasing order of authority:

``talib``      the canonical implementation the spec names. Optional: it is
               not installed in the ``corelib`` environment and is a source
               build on Windows.
``pandas_ta``  the spec's stated fallback. Also optional.
``pandas``     always available. Hand-written here from the same textbook
               definitions but via a completely different mechanism
               (``ewm``, ``rolling``) than :mod:`ta_study.indicators`'
               explicit recursions, so agreement between the two is real
               evidence rather than a tautology.

Nothing in the production path imports this module.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]


# ---------------------------------------------------------------------------
# backend availability
# ---------------------------------------------------------------------------
def talib_module() -> Any | None:
    try:
        import talib
    except Exception:
        return None
    return talib


def pandas_ta_module() -> Any | None:
    try:
        import pandas_ta
    except Exception:
        return None
    return pandas_ta


def available_backends() -> list[str]:
    out = ["pandas"]
    if talib_module() is not None:
        out.append("talib")
    if pandas_ta_module() is not None:
        out.append("pandas_ta")
    return out


# ---------------------------------------------------------------------------
# pandas reference implementations
# ---------------------------------------------------------------------------
def _series(values: npt.ArrayLike):  # type: ignore[no-untyped-def]
    import pandas as pd

    return pd.Series(np.asarray(values, dtype=np.float64))


def pandas_sma(close: npt.ArrayLike, n: int) -> FloatArray:
    return _series(close).rolling(n).mean().to_numpy()


def pandas_ema(close: npt.ArrayLike, n: int) -> FloatArray:
    """SMA-seeded EMA - the convention TA-Lib uses, which ``ewm`` does not.

    ``ewm(span=n, adjust=False)`` seeds on the first observation; TA-Lib
    seeds on the mean of the first ``n``. The seed is spliced in here so the
    two are comparable.

    The seed window is the first ``n`` *finite* values, not the first ``n``
    positions: this is applied to the MACD line, which carries 25 leading
    NaNs, and seeding over those would return an all-NaN signal line.
    """
    import pandas as pd

    s = _series(close)
    out = pd.Series(np.nan, index=s.index)
    finite = np.flatnonzero(np.isfinite(s.to_numpy()))
    if finite.size < n:
        return out.to_numpy()

    seed_positions = finite[:n]
    seed_end = int(seed_positions[-1])
    alpha = 2.0 / (n + 1.0)
    prev = float(s.iloc[seed_positions].mean())
    out.iloc[seed_end] = prev
    for i in range(seed_end + 1, len(s)):
        value = s.iloc[i]
        if np.isfinite(value):
            prev = prev + alpha * (value - prev)
        out.iloc[i] = prev
    return out.to_numpy()


def pandas_rsi(close: npt.ArrayLike, n: int = 14) -> FloatArray:
    """Wilder RSI via ``ewm(alpha=1/n)`` with an SMA seed."""
    import pandas as pd

    s = _series(close)
    diff = s.diff()
    gains = diff.clip(lower=0.0)
    losses = (-diff).clip(lower=0.0)

    def wilder(series: pd.Series) -> pd.Series:
        out = pd.Series(np.nan, index=series.index)
        window = series.iloc[1 : n + 1]
        if len(window) < n:
            return out
        prev = window.mean()
        out.iloc[n] = prev
        for i in range(n + 1, len(series)):
            prev = (prev * (n - 1) + series.iloc[i]) / n
            out.iloc[i] = prev
        return out

    avg_gain = wilder(gains)
    avg_loss = wilder(losses)
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = avg_gain / avg_loss
        rsi = 100.0 - 100.0 / (1.0 + rs)
    rsi = rsi.where(avg_loss != 0, 100.0)
    return rsi.where(avg_gain.notna() & avg_loss.notna()).to_numpy()


def pandas_stoch(
    high: npt.ArrayLike,
    low: npt.ArrayLike,
    close: npt.ArrayLike,
    k_period: int = 14,
    k_smooth: int = 3,
    d_period: int = 3,
) -> tuple[FloatArray, FloatArray]:
    h, lo, c = _series(high), _series(low), _series(close)
    hh = h.rolling(k_period).max()
    ll = lo.rolling(k_period).min()
    rng = hh - ll
    with np.errstate(divide="ignore", invalid="ignore"):
        k_raw = 100.0 * (c - ll) / rng
    k_raw = k_raw.where(rng != 0, 50.0).where(rng.notna())
    k = k_raw.rolling(k_smooth).mean()
    d = k.rolling(d_period).mean()
    return k.to_numpy(), d.to_numpy()


def pandas_bbands(
    close: npt.ArrayLike, n: int = 20, std: float = 2.0
) -> tuple[FloatArray, FloatArray, FloatArray]:
    s = _series(close)
    middle = s.rolling(n).mean()
    # ddof=0 (population) is what TA-Lib's STDDEV uses.
    sigma = s.rolling(n).std(ddof=0)
    return (
        (middle + std * sigma).to_numpy(),
        middle.to_numpy(),
        (middle - std * sigma).to_numpy(),
    )


def pandas_atr(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike, n: int = 14
) -> FloatArray:
    import pandas as pd

    h, lo, c = _series(high), _series(low), _series(close)
    prev = c.shift(1)
    tr = pd.concat([(h - lo), (h - prev).abs(), (lo - prev).abs()], axis=1).max(axis=1)
    tr.iloc[0] = np.nan

    out = pd.Series(np.nan, index=tr.index)
    window = tr.iloc[1 : n + 1]
    if len(window) < n:
        return out.to_numpy()
    prev_val = window.mean()
    out.iloc[n] = prev_val
    for i in range(n + 1, len(tr)):
        prev_val = (prev_val * (n - 1) + tr.iloc[i]) / n
        out.iloc[i] = prev_val
    return out.to_numpy()


def pandas_macd(
    close: npt.ArrayLike, fast: int = 12, slow: int = 26, signal: int = 9
) -> tuple[FloatArray, FloatArray, FloatArray]:
    line = pandas_ema(close, fast) - pandas_ema(close, slow)
    sig = pandas_ema(line, signal)
    return line, sig, line - sig


def pandas_dmi(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike, n: int = 14
) -> tuple[FloatArray, FloatArray, FloatArray]:
    """``(+DI, -DI, ADX)`` via pandas, seeded the way TA-Lib seeds."""
    import pandas as pd

    h, lo, c = _series(high), _series(low), _series(close)
    up = h.diff()
    down = -lo.diff()
    plus_dm = up.where((up > down) & (up > 0), 0.0)
    minus_dm = down.where((down > up) & (down > 0), 0.0)
    prev = c.shift(1)
    tr = pd.concat([(h - lo), (h - prev).abs(), (lo - prev).abs()], axis=1).max(axis=1)
    for frame in (plus_dm, minus_dm, tr):
        frame.iloc[0] = np.nan

    def wilder(series: pd.Series, start: int) -> pd.Series:
        out = pd.Series(np.nan, index=series.index)
        window = series.iloc[start : start + n]
        if len(window) < n:
            return out
        prev_val = window.mean()
        out.iloc[start + n - 1] = prev_val
        for i in range(start + n, len(series)):
            prev_val = (prev_val * (n - 1) + series.iloc[i]) / n
            out.iloc[i] = prev_val
        return out

    plus_s = wilder(plus_dm, 1)
    minus_s = wilder(minus_dm, 1)
    tr_s = wilder(tr, 1)

    with np.errstate(divide="ignore", invalid="ignore"):
        plus_di = 100.0 * plus_s / tr_s
        minus_di = 100.0 * minus_s / tr_s
        total = plus_di + minus_di
        dx = 100.0 * (plus_di - minus_di).abs() / total
    dx = dx.where(total != 0, 0.0).where(plus_di.notna() & minus_di.notna())
    adx = wilder(dx, n)
    return plus_di.to_numpy(), minus_di.to_numpy(), adx.to_numpy()


# ---------------------------------------------------------------------------
# talib / pandas_ta adapters
# ---------------------------------------------------------------------------
def talib_rsi(close: npt.ArrayLike, n: int = 14) -> FloatArray | None:
    talib = talib_module()
    if talib is None:
        return None
    return np.asarray(talib.RSI(np.asarray(close, dtype=np.float64), timeperiod=n))


def talib_stoch(
    high: npt.ArrayLike,
    low: npt.ArrayLike,
    close: npt.ArrayLike,
    k_period: int = 14,
    k_smooth: int = 3,
    d_period: int = 3,
) -> tuple[FloatArray, FloatArray] | None:
    talib = talib_module()
    if talib is None:
        return None
    k, d = talib.STOCH(
        np.asarray(high, dtype=np.float64),
        np.asarray(low, dtype=np.float64),
        np.asarray(close, dtype=np.float64),
        fastk_period=k_period,
        slowk_period=k_smooth,
        slowk_matype=0,
        slowd_period=d_period,
        slowd_matype=0,
    )
    return np.asarray(k), np.asarray(d)


def talib_dmi(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike, n: int = 14
) -> tuple[FloatArray, FloatArray, FloatArray] | None:
    talib = talib_module()
    if talib is None:
        return None
    h = np.asarray(high, dtype=np.float64)
    lo = np.asarray(low, dtype=np.float64)
    c = np.asarray(close, dtype=np.float64)
    return (
        np.asarray(talib.PLUS_DI(h, lo, c, timeperiod=n)),
        np.asarray(talib.MINUS_DI(h, lo, c, timeperiod=n)),
        np.asarray(talib.ADX(h, lo, c, timeperiod=n)),
    )


def talib_macd(
    close: npt.ArrayLike, fast: int = 12, slow: int = 26, signal: int = 9
) -> tuple[FloatArray, FloatArray, FloatArray] | None:
    talib = talib_module()
    if talib is None:
        return None
    line, sig, hist = talib.MACD(
        np.asarray(close, dtype=np.float64),
        fastperiod=fast,
        slowperiod=slow,
        signalperiod=signal,
    )
    return np.asarray(line), np.asarray(sig), np.asarray(hist)


def talib_bbands(
    close: npt.ArrayLike, n: int = 20, std: float = 2.0
) -> tuple[FloatArray, FloatArray, FloatArray] | None:
    talib = talib_module()
    if talib is None:
        return None
    upper, middle, lower = talib.BBANDS(
        np.asarray(close, dtype=np.float64),
        timeperiod=n,
        nbdevup=std,
        nbdevdn=std,
        matype=0,
    )
    return np.asarray(upper), np.asarray(middle), np.asarray(lower)


def talib_atr(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike, n: int = 14
) -> FloatArray | None:
    talib = talib_module()
    if talib is None:
        return None
    return np.asarray(
        talib.ATR(
            np.asarray(high, dtype=np.float64),
            np.asarray(low, dtype=np.float64),
            np.asarray(close, dtype=np.float64),
            timeperiod=n,
        )
    )


def pandas_ta_rsi(close: npt.ArrayLike, n: int = 14) -> FloatArray | None:
    mod = pandas_ta_module()
    if mod is None:
        return None
    return np.asarray(mod.rsi(_series(close), length=n), dtype=np.float64)


def pandas_ta_adx(
    high: npt.ArrayLike, low: npt.ArrayLike, close: npt.ArrayLike, n: int = 14
) -> FloatArray | None:
    mod = pandas_ta_module()
    if mod is None:
        return None
    frame = mod.adx(_series(high), _series(low), _series(close), length=n)
    if frame is None:
        return None
    column = next((c for c in frame.columns if c.startswith("ADX")), None)
    if column is None:
        return None
    return np.asarray(frame[column], dtype=np.float64)
