
"""
Email report showing latest ICE CoT positions

Processes both participant groupings (Investment Funds & Commercial Undertakings)
in a single run. Scheduled to run every few minutes around the publication window;
date stamp files (per report type, email group & commodity) ensure each
report/alert is only sent once per release.

Email groups: TTF & EUA are sent together as soon as both are published; UKA
is sent in a separate email because Bloomberg typically publishes it later.

"""


import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime, timezone, timedelta
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.interfaces.bloomberg import BBGQuery

from util import (
    generate_email_body,
    generate_net_length_yearly_chart,
    generate_wow_dual_axis_chart,
    send_teams_headline,
)


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/cot_summary')

# CoT participant groupings to report on
REPORT_TYPES = {
    'investment_funds': 'Investment Funds',
    'commercial_undertakings': 'Commercial Undertakings',
}

# Markets that must all be ready before an email for that group is sent.
# UKA is split out because Bloomberg consistently publishes it later than TTF/EUA.
EMAIL_GROUPS = [
    {'id': 'ttf_eua', 'label': 'TTF & EUA', 'markets': ['TTF', 'EUA']},
    {'id': 'uka', 'label': 'UKA', 'markets': ['UKA']},
]

# Market config per participant grouping (long/short/net tickers differ per grouping)
MARKET_CONFIGS = {
    'investment_funds': [
        {'description': 'TTF',
         'price': 'TZT1 Comdty',
         'long': 'IU60MHZA Index',
         'short': 'IU60GKLQ Index',
         'net': 'IU60VSQW Index',
         'conv_factor': 1000000,
         'target_unit': 'TWh',
         'price_unit': 'EUR/MWh',
         },
        {'description': 'EUA',
         'price': 'MO1 Comdty',
         'long': 'IU34MHZA Index',
         'short': 'IU34GKLQ Index',
         'net': 'IU34VSQW Index',
         'conv_factor': 1000,
         'target_unit': 'Mt',
         'price_unit': 'EUR/Mt',
         },
        {'description': 'UKA',
         'price': 'UKE1 Comdty',
         'long': 'IU80MHZA Index',
         'short': 'IU80GKLQ Index',
         'net': 'IU80VSQW Index',
         'conv_factor': 1000,
         'target_unit': 'Mt',
         'price_unit': 'GBP/Mt',
         },
    ],
    'commercial_undertakings': [
        {'description': 'TTF',
         'price': 'TZT1 Comdty',
         'long': 'IU60VDQG Index',
         'short': 'IU60FHAX Index',
         'net': 'IU60WADG Index',
         'conv_factor': 1000000,
         'target_unit': 'TWh',
         'price_unit': 'EUR/MWh',
         },
        {'description': 'EUA',
         'price': 'MO1 Comdty',
         'long': 'IU34VDQG Index',
         'short': 'IU34FHAX Index',
         'net': 'IU34WADG Index',
         'conv_factor': 1000,
         'target_unit': 'Mt',
         'price_unit': 'EUR/Mt',
         },
        {'description': 'UKA',
         'price': 'UKE1 Comdty',
         'long': 'IU80VDQG Index',
         'short': 'IU80FHAX Index',
         'net': 'IU80WADG Index',
         'conv_factor': 1000,
         'target_unit': 'Mt',
         'price_unit': 'GBP/Mt',
         },
    ],
}

# Get config (interpolation disabled as the workflow webhook URL contains % characters)
config = configparser.ConfigParser(interpolation=None)
config.read(REPORTS_PATH / 'cot_summary.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
teams_webhook = config.get('ReportSettings','teams_webhook')
teams_webhook_workflow = config.get('ReportSettings','teams_webhook_workflow')


# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_cot_summary.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
skip_duplicate_check = system == 'windows'
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

today = datetime.today()
now_utc = datetime.now(timezone.utc)

last_cot_date_fmt = '%Y-%m-%d'

email_subject_prefix = "ICE CoT"


# Scheduled to run every few minutes around the publication window (Weds morning)


def _read_stamp_date(stamp_file: Path, legacy_file: Path | None = None) -> datetime:
    """Read a YYYY-MM-DD stamp file, optionally falling back to a legacy combined stamp."""
    if skip_duplicate_check:
        return datetime.min
    for path in (stamp_file, legacy_file):
        if path is not None and path.exists():
            return datetime.strptime(open(path, 'r').read().strip(), last_cot_date_fmt)
    return datetime.min


def _write_stamp_date(stamp_file: Path, stamp_dt: datetime) -> None:
    if not skip_duplicate_check:
        logging.info(f"Saving stamp {stamp_dt.strftime(last_cot_date_fmt)} into {stamp_file.name}")
        with open(stamp_file, 'w') as f:
            f.write(stamp_dt.strftime(last_cot_date_fmt))


try:
    
    logging.info('Running report...')
    
    # Get previous Friday
    prev_fri = pd.to_datetime((today - timedelta(days=(today.weekday() - 4) % 7 or 7))).normalize()
    
    bbg_session = BBGQuery(p_on_server=True)
    
    
    # Process each participant grouping in turn
    for report_type, report_type_name in REPORT_TYPES.items():
        
        logging.info(f'Processing {report_type_name}...')
        
        email_subject_prefix = f"ICE CoT {report_type_name}"
        cot_config = MARKET_CONFIGS[report_type]
        
        # Publication check across all markets (Teams + email groups)
        # Pattern: published on a Weds, covering up to previous Friday. Last update date will be the Friday.
        # TODO: this breaks for holidays (eg Easter when Friday is a public holiday so date value will be the Thursday)
        tickers = [d[k] for d in cot_config for k in ['long', 'short', 'net']]
        date_check = bbg_session.fetch_live(tickers, ["LAST_UPDATE_DT"])
        date_check['LAST_UPDATE_DT'] = pd.to_datetime(date_check['LAST_UPDATE_DT'])
        
        
        # Send a Teams headline per commodity as soon as it is published
        for cfg in cot_config:
            
            commodity = cfg['description']
            commodity_tickers = [cfg[k] for k in ['long', 'short', 'net']]
            commodity_dates = date_check.loc[commodity_tickers, 'LAST_UPDATE_DT']
            
            teams_date_file = REPORTS_PATH / f'last_teams_date_{report_type}_{commodity.lower()}.txt'
            last_teams_date = _read_stamp_date(teams_date_file)
            
            if (commodity_dates == prev_fri).all() and prev_fri > last_teams_date:
                
                logging.info(f"{commodity} published - sending Teams headline")
                
                headline_data = bbg_session.fetch_hist(commodity_tickers,
                                                       "PX_LAST",
                                                       today - timedelta(days=30),
                                                       today)
                headline_data = headline_data[~headline_data.index.duplicated(keep='last')]
                headline_data = headline_data / cfg['conv_factor']
                
                headline_values = {}
                for k in ['long', 'short', 'net']:
                    series = headline_data[f"{cfg[k]}_PX_LAST"].dropna()
                    headline_values[k] = (series.iloc[-1], series.iloc[-1] - series.iloc[-2])
                
                send_teams_headline(teams_webhook_workflow, report_type_name, cfg, headline_values, prev_fri)
                _write_stamp_date(teams_date_file, prev_fri)
            
            else:
                logging.info(
                    f"{commodity}: no Teams headline sent "
                    f"(published dates: {commodity_dates.dt.strftime(last_cot_date_fmt).tolist()}, "
                    f"last sent: {last_teams_date.strftime(last_cot_date_fmt)})"
                )
        
        
        # Email reports per group (TTF+EUA together; UKA separately when Bloomberg catches up)
        legacy_cot_date_file = REPORTS_PATH / f'last_cot_date_{report_type}.txt'
        
        for email_group in EMAIL_GROUPS:
            
            group_id = email_group['id']
            group_label = email_group['label']
            group_config = [c for c in cot_config if c['description'] in email_group['markets']]
            group_tickers = [d[k] for d in group_config for k in ['long', 'short', 'net']]
            
            last_cot_date_file = REPORTS_PATH / f'last_cot_date_{report_type}_{group_id}.txt'
            # Fall back to pre-split combined stamp so a release already emailed as one
            # report is not re-sent after deploying the UKA split
            last_cot_report_date = _read_stamp_date(last_cot_date_file, legacy_cot_date_file)
            
            if skip_duplicate_check:
                logging.info(f'Windows dev mode: ignoring last_cot_date duplicate check for {group_label}')
            
            if not (prev_fri > last_cot_report_date):
                logging.info(
                    f"{report_type_name} {group_label}: report already sent. "
                    f"Expected date {prev_fri.strftime(last_cot_date_fmt)} matches "
                    f"date in file {last_cot_report_date.strftime(last_cot_date_fmt)}"
                )
                continue
            
            logging.info(
                f"{report_type_name} {group_label}: expected date {prev_fri.strftime(last_cot_date_fmt)}. "
                f"Last report date {last_cot_report_date.strftime(last_cot_date_fmt)}. Checking data..."
            )
            
            group_dates = date_check.loc[group_tickers, 'LAST_UPDATE_DT']
            
            if group_dates.nunique(dropna=False) == 1 and group_dates.iloc[0] == prev_fri:
                
                last_update_dt = group_dates.iloc[0]
                logging.info(
                    f"{report_type_name} {group_label}: new data published "
                    f"(LAST_UPDATE_DT {last_update_dt.strftime(last_cot_date_fmt)})"
                )
                
                start_dt_cot_chart = datetime(2016,1,1)
                start_dt_cot_table = datetime(2026, 1, 30)
                
                logging.info(f"Querying CoT data for {group_label}")
                cot_data_all = bbg_session.fetch_hist(group_tickers,
                                                      "PX_LAST",
                                                      start_dt_cot_chart,
                                                      today)
                # Bloomberg can return duplicate dates across partial response batches
                cot_data_all = cot_data_all[~cot_data_all.index.duplicated(keep='last')]
                
                email_sections = []
                email_subject_delta_output = []
                
                for cfg in group_config:
                    cols = [f"{cfg[k]}_PX_LAST" for k in ['long', 'short', 'net']]
                    
                    cot_data = cot_data_all[cols]
                    cot_data_conv = cot_data/cfg['conv_factor']
                    inv = {v: k for k, v in cfg.items()}
                    cot_data_conv = cot_data_conv.rename(columns=lambda c: inv.get(c.removesuffix('_PX_LAST'), c))
                    cot_data_conv.index = pd.to_datetime(cot_data_conv.index)
                    
                    unit = cfg['target_unit']
                    net_length_col = f"Net Length ({unit})"
                    net_length_wow_col = "WoW Net Δ"
                    long_col = f"Long ({unit})"
                    short_col = f"Short ({unit})"
                    long_wow_col = "WoW Long Δ"
                    short_wow_col = "WoW Short Δ"
                    price_wow_col = "WoW Price Δ"
                    
                    cot_data_conv[long_wow_col] = cot_data_conv['long'].diff()
                    cot_data_conv[short_wow_col] = cot_data_conv['short'].diff()
                    cot_data_conv[net_length_wow_col] = cot_data_conv['net'].diff()
                    
                    logging.info(f"Querying prices for {cfg['description']}")
                    prices = bbg_session.fetch_hist(cfg['price'],
                                                    ["PX_LAST"],
                                                    start_dt_cot_chart,
                                                    today)
                    prices.index = pd.to_datetime(prices.index)
                    prices = prices.resample('W-FRI').mean()
                    
                    df_output = pd.concat([cot_data_conv[start_dt_cot_table:], prices], axis=1)
                    
                    price_col = f"{cfg['price']}_PX_LAST"
                    
                    # One off fix for Easter (date from CoT data is up to Thursday 2nd Apr whereas weekly prices are up to Fri 3rd Apr)
                    # TODO: sort this as far too hard coded!
                    df_output.loc[datetime(2026,4,2),price_col] = df_output.loc[datetime(2026,4,3),price_col] 
                    
                    price_display_col = f"Avg Front Contract Price ({cfg['price_unit']})"
                    df_output = df_output.rename(columns={'long': long_col,
                                                          'short': short_col,
                                                          'net': net_length_col,
                                                          price_col: price_display_col,
                                                          } )
                    df_output[price_wow_col] = df_output[price_display_col].diff()
                    df_output = df_output.dropna()
                    df_output = df_output[[
                        net_length_col,
                        net_length_wow_col,
                        long_col,
                        long_wow_col,
                        short_col,
                        short_wow_col,
                        price_display_col,
                        price_wow_col,
                    ]]
                    
                    logging.info(f"Generating {cfg['description']} report content")
                    net_chart_img = generate_net_length_yearly_chart(
                        cot_data_conv, prices, last_update_dt, cfg
                    )
                    wow_chart_img = generate_wow_dual_axis_chart(
                        cot_data_conv, prices, last_update_dt, cfg
                    )
                    email_sections.append({
                        "df_output": df_output,
                        "cfg": cfg,
                        "net_chart_img": net_chart_img,
                        "wow_chart_img": wow_chart_img,
                    })
                    
                    email_subject_delta = (
                        f"{cfg['description']} Net Length "
                        f"{df_output.loc[last_update_dt, net_length_col]:+.0f}{unit} "
                        f"({df_output.loc[last_update_dt, net_length_wow_col]:+.0f})"
                    )
                    email_subject_delta_output.append(email_subject_delta)
                
                email_body = generate_email_body(
                    email_sections, now_utc, last_update_dt, group_config, report_type_name
                )
                email_subject_final = (
                    f"{email_subject_prefix} ({last_update_dt.strftime('%d %b')}): "
                    f"{', '.join(email_subject_delta_output)}"
                )
                
                logging.info(f'Sending {report_type_name} {group_label} email')
                send_email(receivers,
                           email_subject_final,
                           email_body,
                           from_address='eu.gap.reports@jainglobal.com')
                
                _write_stamp_date(last_cot_date_file, last_update_dt)
                logging.info(f'{report_type_name} {group_label} report sent')
            
            else:
                commodity_status = []
                for cfg in group_config:
                    commodity = cfg['description']
                    commodity_tickers = [cfg[k] for k in ['long', 'short', 'net']]
                    commodity_dates = date_check.loc[commodity_tickers, 'LAST_UPDATE_DT']
                    dates_str = ', '.join(commodity_dates.dt.strftime(last_cot_date_fmt).unique().tolist())
                    if (commodity_dates == prev_fri).all():
                        commodity_status.append(f"{commodity}: {dates_str} (published)")
                    else:
                        commodity_status.append(
                            f"{commodity}: {dates_str} (awaiting {prev_fri.strftime(last_cot_date_fmt)})"
                        )
                
                status_lines = [
                    f"CoT data still publishing for {report_type_name} ({group_label}): "
                    f"not all markets in this email have LAST_UPDATE_DT of "
                    f"{prev_fri.strftime(last_cot_date_fmt)} yet.",
                    "",
                    f"The {group_label} email will send automatically once ready.",
                    "",
                    "Current status:",
                    *[f"  - {s}" for s in commodity_status],
                ]
                status_msg = '\n'.join(status_lines)
                
                logging.info(
                    f"CoT data still publishing for {report_type_name} ({group_label}): "
                    f"awaiting LAST_UPDATE_DT {prev_fri.strftime(last_cot_date_fmt)}. "
                    f"Status: {'; '.join(commodity_status)}"
                )
                
                waiting_email_file = REPORTS_PATH / f'last_waiting_email_{report_type}_{group_id}.txt'
                already_notified = (
                    not skip_duplicate_check
                    and waiting_email_file.exists()
                    and open(waiting_email_file, 'r').read().strip() == prev_fri.strftime(last_cot_date_fmt)
                )
                if not already_notified:
                    logging.info(f'Sending waiting-for-data notification for {group_label}')
                    send_email(
                        error_receivers,
                        f"ICE CoT {report_type_name} ({group_label}): awaiting data release "
                        f"({prev_fri.strftime('%d %b')})",
                        status_msg,
                        from_address='eu.gap.reports@jainglobal.com',
                    )
                    _write_stamp_date(waiting_email_file, prev_fri)
    
    
    logging.info('All done')


except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f"ERROR {email_subject_prefix}", str(tb))    
