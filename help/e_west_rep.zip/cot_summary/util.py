import base64
import io
from datetime import datetime, timezone
from urllib.parse import quote

import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
import requests

CHART_STYLE = {
    "font.family": "sans-serif",
    "font.sans-serif": ["Segoe UI", "Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.titleweight": 500,
    "axes.labelsize": 8,
    "axes.linewidth": 0.6,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "legend.fontsize": 7,
    "figure.dpi": 150,
    "savefig.dpi": 150,
    "grid.linewidth": 0.4,
    "grid.alpha": 0.4,
    "lines.linewidth": 1.2,
}

YEAR_COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd",
    "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf",
]

MONTH_STARTS = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
MONTH_LABELS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]

IRAN_WAR_START = pd.Timestamp("2026-02-28")

BLINKS_TICKER_KEYS = ("price", "long", "short", "net")
BLINKS_KEY_LABELS = {
    "price": "Price",
    "long": "Long",
    "short": "Short",
    "net": "Net",
}

SECTION_STYLE = (
    "margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; "
    "border-bottom: 1px solid #ddd; padding-bottom: 4px;"
)


def _section_header(title: str) -> str:
    return f'<h3 style="{SECTION_STYLE}">{title}</h3>'


def _apply_chart_style():
    plt.rcParams.update(CHART_STYLE)


def _style_axis(ax, title=None, ylabel=None):
    if title:
        ax.set_title(title, pad=8, color="#333333")
    if ylabel:
        ax.set_ylabel(ylabel, color="#666666")
    ax.tick_params(axis="both", colors="#555555")
    ax.spines["left"].set_color("#CCCCCC")
    ax.spines["bottom"].set_color("#CCCCCC")
    ax.grid(axis="y", linestyle="-", color="#E0E0E0", alpha=0.5, linewidth=0.4)
    ax.grid(axis="x", visible=False)
    ax.set_axisbelow(True)


def _chart_to_base64(fig) -> str:
    buffer = io.BytesIO()
    fig.savefig(buffer, format="png", bbox_inches="tight", facecolor="white", edgecolor="none")
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode("utf-8")
    buffer.close()
    plt.close(fig)
    return plot_base64


def _plot_yearly_position_lines(
    ax,
    series: pd.Series,
    years: list,
    current_year: int,
    to_date: pd.Timestamp,
    *,
    show_xlabels: bool = True,
    collect_legend: bool = False,
) -> tuple[list, list]:
    """Plot one position series as yearly lines on day-of-year x-axis."""
    series = series.dropna()
    series.index = pd.to_datetime(series.index)
    handles, labels = [], []

    for i, year in enumerate(years):
        start = pd.Timestamp(f"{year}-01-01")
        end = pd.Timestamp(f"{year}-12-31") if year < current_year else to_date
        year_data = series.loc[start:end]
        if year_data.empty:
            continue

        day_of_year = year_data.index.dayofyear
        color = YEAR_COLORS[i % len(YEAR_COLORS)]
        is_current = year == current_year

        if is_current:
            line, = ax.plot(
                day_of_year,
                year_data.values,
                color=color,
                linewidth=2.5,
                marker="o",
                markersize=3,
                markevery=max(1, len(year_data) // 15),
                zorder=10,
            )
        else:
            line, = ax.plot(
                day_of_year,
                year_data.values,
                color=color,
                linewidth=1,
                alpha=0.7,
                zorder=1,
            )

        if collect_legend:
            handles.append(line)
            labels.append(str(year))

    ax.set_xticks(MONTH_STARTS)
    ax.set_xticklabels(MONTH_LABELS if show_xlabels else [""] * len(MONTH_LABELS))
    ax.set_xlim(1, 366)
    return handles, labels


def _year_color_map(years: list) -> dict:
    return {year: YEAR_COLORS[i % len(YEAR_COLORS)] for i, year in enumerate(years)}


def _scatter_wow_points(ax, year_df: pd.DataFrame, year: int, colors: dict) -> None:
    """Plot WoW scatter points for one year, with distinct marker post Iran war in 2026."""
    color = colors.get(year, "#999999")
    scatter_kw = dict(
        color=color,
        alpha=0.75,
        s=35,
        edgecolors="white",
        linewidth=0.5,
    )

    if year == 2026:
        pre_war = year_df[year_df.index < IRAN_WAR_START]
        post_war = year_df[year_df.index >= IRAN_WAR_START]
        if not pre_war.empty:
            ax.scatter(pre_war["net_wow"], pre_war["price_wow"], marker="o", **scatter_kw)
        if not post_war.empty:
            ax.scatter(post_war["net_wow"], post_war["price_wow"], marker="D", **scatter_kw)
    else:
        ax.scatter(year_df["net_wow"], year_df["price_wow"], marker="o", **scatter_kw)


def _add_wow_trend_line(ax, x, y, color: str, linestyle: str, label: str) -> None:
    """Draw a labelled linear trend line for WoW scatter data."""
    x_line = np.linspace(x.min(), x.max(), 100)
    z = np.polyfit(x, y, 1)
    ax.plot(x_line, np.poly1d(z)(x_line), color=color, linewidth=1.5, linestyle=linestyle, label=label)


def _highlight_latest_scatter_point(
    ax, df: pd.DataFrame, colors: dict, to_date: pd.Timestamp
) -> None:
    """Ring and arrow annotation for the most recent WoW observation."""
    if df.empty:
        return

    latest_idx = to_date if to_date in df.index else df.index.max()
    latest = df.loc[latest_idx]
    x, y = latest["net_wow"], latest["price_wow"]
    point_color = colors.get(int(latest["year"]), "#333333")

    ax.scatter(
        [x],
        [y],
        s=160,
        facecolors="none",
        edgecolors=point_color,
        linewidth=2.2,
        zorder=15,
    )
    ax.annotate(
        _format_date(latest_idx),
        xy=(x, y),
        xytext=(14, 14),
        textcoords="offset points",
        fontsize=7,
        color="#333333",
        ha="left",
        va="bottom",
        arrowprops=dict(arrowstyle="-|>", color="#333333", lw=1.0, shrinkA=4, shrinkB=6),
        zorder=16,
    )


def _plot_position_price_scatter(
    ax,
    net_series: pd.Series,
    price_series: pd.Series,
    years: list,
    cfg: dict,
    to_date,
) -> None:
    """Scatter of weekly net-length change vs weekly price change, coloured by year."""
    description = cfg["description"]
    unit = cfg["target_unit"]
    price_unit = cfg["price_unit"]
    colors = _year_color_map(years)
    to_date = pd.Timestamp(to_date)
    data_start = pd.Timestamp(f"{to_date.year - 1}-01-01")

    df = pd.DataFrame({"net": net_series, "price": price_series}).dropna()
    df["net_wow"] = df["net"].diff()
    df["price_wow"] = df["price"].diff()
    df = df.dropna(subset=["net_wow", "price_wow"])
    df = df.loc[data_start:to_date]
    df["year"] = df.index.year

    for year in sorted(df["year"].unique()):
        _scatter_wow_points(ax, df[df["year"] == year], year, colors)

    _highlight_latest_scatter_point(ax, df, colors, to_date)

    post_war = df[df.index >= IRAN_WAR_START]
    pre_war = df[df.index < IRAN_WAR_START]
    stat_lines = []
    has_trend_legend = False

    px_pre = pre_war["net_wow"].values
    py_pre = pre_war["price_wow"].values
    if len(px_pre) >= 3:
        _add_wow_trend_line(ax, px_pre, py_pre, "#e74c3c", "--", "Trend (pre-war)")
        stat_lines.append(f"r = {np.corrcoef(px_pre, py_pre)[0, 1]:.2f} (pre-war)")
        has_trend_legend = True

    px = post_war["net_wow"].values
    py = post_war["price_wow"].values
    if len(px) >= 3:
        _add_wow_trend_line(ax, px, py, "#8e44ad", "-", "Trend (post-war)")
        r_post = np.corrcoef(px, py)[0, 1]
        stat_lines.append(f"r = {r_post:.2f} (post-war)")
        has_trend_legend = True

    if has_trend_legend:
        trend_legend = ax.legend(loc="upper right", frameon=True, fontsize=7)
        ax.add_artist(trend_legend)

    if not post_war.empty:
        color_2026 = colors.get(2026, "#999999")
        ax.legend(
            [
                Line2D(
                    [0], [0],
                    marker="D",
                    color="w",
                    markerfacecolor=color_2026,
                    markeredgecolor="white",
                    markeredgewidth=0.5,
                    markersize=7,
                    linestyle="None",
                )
            ],
            ["from 28 Feb 2026 (Iran war)"],
            loc="lower left",
            frameon=False,
            fontsize=7,
            handlelength=1.2,
            borderpad=0.4,
        )

    if stat_lines:
        ax.annotate(
            "\n".join(stat_lines),
            xy=(0.05, 0.95),
            xycoords="axes fraction",
            fontsize=8,
            fontweight="bold",
            color="#333333",
            verticalalignment="top",
        )

    ax.axhline(0, color="#888888", linewidth=0.5, alpha=0.5)
    ax.axvline(0, color="#888888", linewidth=0.5, alpha=0.5)
    _style_axis(
        ax,
        title=f"{description} WoW Net vs Price ({to_date.year - 1}+)",
        ylabel=f"WoW Price ({price_unit})",
    )
    ax.set_xlabel(f"WoW Net ({unit})", color="#666666")


def _limits_with_zero(vals, pad: float = 0.08) -> tuple[float, float]:
    """Axis limits that include zero with padding."""
    vmin, vmax = float(np.min(vals)), float(np.max(vals))
    vmin = min(vmin, 0.0)
    vmax = max(vmax, 0.0)
    span = vmax - vmin or 1.0
    return vmin - pad * span, vmax + pad * span


def _align_dual_axis_zero(ax_left, ax_right, left_vals, right_vals, pad: float = 0.08) -> None:
    """Align left and right y-axes so zero sits on the same horizontal line."""
    l0, l1 = _limits_with_zero(left_vals, pad)
    r0, r1 = _limits_with_zero(right_vals, pad)

    l_span = l1 - l0
    r_span = r1 - r0
    l_frac = -l0 / l_span if l_span else 0.5
    r_frac = -r0 / r_span if r_span else 0.5

    if l_frac > r_frac and r_frac < 1:
        r0 = -l_frac * r1 / (1 - l_frac)
    elif r_frac > l_frac and l_frac < 1:
        l0 = -r_frac * l1 / (1 - r_frac)

    ax_left.set_ylim(l0, l1)
    ax_right.set_ylim(r0, r1)


def generate_wow_dual_axis_chart(
    cot_data: pd.DataFrame,
    prices: pd.DataFrame,
    to_date,
    cfg: dict,
) -> str:
    """
    Dual-axis time series of weekly net and price changes.

    Parameters
    ----------
    cot_data : pd.DataFrame
        CoT data with datetime index and ``net`` column (levels).
    prices : pd.DataFrame
        Weekly resampled front-month price history.
    to_date : datetime-like
        End date for the series (typically LAST_UPDATE_DT).
    cfg : dict
        Market config with ``description``, ``target_unit``, and ``price_unit``.

    Returns
    -------
    str
        Base64-encoded PNG image.
    """
    _apply_chart_style()

    to_date = pd.Timestamp(to_date)
    description = cfg["description"]
    unit = cfg["target_unit"]
    price_unit = cfg["price_unit"]
    data_start = pd.Timestamp(f"{to_date.year - 1}-01-01")

    price_col = f"{cfg['price']}_PX_LAST"
    price_series = prices[price_col] if price_col in prices.columns else prices.iloc[:, 0]

    cot_data = cot_data.copy()
    cot_data.index = pd.to_datetime(cot_data.index)
    df = pd.DataFrame({"net": cot_data["net"], "price": price_series}).dropna()
    df = df.loc[data_start:to_date]
    df["net_wow"] = df["net"].diff()
    df["price_wow"] = df["price"].diff()
    df = df.dropna(subset=["net_wow", "price_wow"])

    color_net = "#2E86AB"
    color_price = "#e67e22"

    fig, ax1 = plt.subplots(figsize=(7, 4.5), facecolor="white")
    ax2 = ax1.twinx()

    ax1.plot(df.index, df["net_wow"], color=color_net, linewidth=1.2)
    ax2.plot(df.index, df["price_wow"], color=color_price, linewidth=1.2)

    _align_dual_axis_zero(ax1, ax2, df["net_wow"].values, df["price_wow"].values)
    ax1.axhline(0, color="#888888", linewidth=0.5, alpha=0.5, zorder=1)

    ax1.xaxis.set_major_formatter(mdates.DateFormatter("%d %b %y"))
    ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha="right")

    _style_axis(
        ax1,
        title=f"{description} Net Length and Price WoW Delta",
        ylabel=f"WoW Net ({unit})",
    )
    ax2.set_ylabel(f"WoW Price ({price_unit})", color=color_price)
    ax2.tick_params(axis="y", labelcolor=color_price)
    ax2.spines["right"].set_color("#CCCCCC")
    ax2.spines["top"].set_visible(False)

    fig.subplots_adjust(bottom=0.22)
    return _chart_to_base64(fig)


def generate_net_length_yearly_chart(
    cot_data: pd.DataFrame,
    prices: pd.DataFrame,
    to_date,
    cfg: dict,
) -> str:
    """
    Yearly line charts of net, long and short positions.

    Layout: net length spans the left; long and short stacked in the middle;
    WoW scatter spans the right at the same width as long/short.

    Parameters
    ----------
    cot_data : pd.DataFrame
        CoT data with datetime index and ``long``, ``short``, and ``net`` columns.
    prices : pd.DataFrame
        Weekly resampled front-month price history aligned to CoT dates.
    to_date : datetime-like
        End date for the current-year line (typically LAST_UPDATE_DT).
    cfg : dict
        Market config with ``description`` and ``target_unit`` keys.

    Returns
    -------
    str
        Base64-encoded PNG image.
    """
    _apply_chart_style()

    to_date = pd.Timestamp(to_date)
    current_year = to_date.year
    description = cfg["description"]
    unit = cfg["target_unit"]

    cot_data = cot_data.copy()
    cot_data.index = pd.to_datetime(cot_data.index)
    min_year = cot_data.index.min().year
    max_year = cot_data.index.max().year
    years = list(range(min_year, max_year + 1))
    price_col = f"{cfg['price']}_PX_LAST"
    price_series = prices[price_col] if price_col in prices.columns else prices.iloc[:, 0]

    fig = plt.figure(figsize=(20, 7), facecolor="white")
    gs = gridspec.GridSpec(
        2, 3, figure=fig,
        width_ratios=[1.85, 1, 1],
        height_ratios=[1, 1],
        hspace=0.32,
        wspace=0.10,
    )
    ax_net = fig.add_subplot(gs[:, 0])
    ax_long = fig.add_subplot(gs[0, 1])
    ax_short = fig.add_subplot(gs[1, 1])
    ax_scatter = fig.add_subplot(gs[:, 2])

    legend_handles, legend_labels = _plot_yearly_position_lines(
        ax_net, cot_data["net"], years, current_year, to_date,
        show_xlabels=True, collect_legend=True,
    )
    _plot_yearly_position_lines(
        ax_long, cot_data["long"], years, current_year, to_date,
        show_xlabels=False, collect_legend=False,
    )
    _plot_yearly_position_lines(
        ax_short, cot_data["short"], years, current_year, to_date,
        show_xlabels=True, collect_legend=False,
    )

    ax_net.axhline(0, color="#333333", linewidth=0.6, linestyle="-", alpha=0.4)
    _style_axis(ax_net, title=f"{description} Net Length", ylabel=unit)
    _style_axis(ax_long, title=f"{description} Long Positions", ylabel=unit)
    _style_axis(ax_short, title=f"{description} Short Positions", ylabel=unit)
    _plot_position_price_scatter(ax_scatter, cot_data["net"], price_series, years, cfg, to_date)

    if legend_handles:
        fig.legend(
            legend_handles,
            legend_labels,
            loc="lower center",
            ncol=len(legend_labels),
            frameon=True,
            bbox_to_anchor=(0.5, 0.01),
            columnspacing=0.8,
            handletextpad=0.3,
        )

    # tight_layout is incompatible with rowspan GridSpec subplots; set margins manually
    fig.subplots_adjust(left=0.05, right=0.99, top=0.93, bottom=0.14)
    return _chart_to_base64(fig)


def _format_date(dt) -> str:
    """Format datetime index values as e.g. 22 May 2026."""
    dt = pd.Timestamp(dt)
    return f"{dt.day} {dt.strftime('%b %Y')}"


def _format_run_datetime(dt: datetime) -> str:
    """Format query run time in UTC, e.g. 27 May 2026 07:45 UTC."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return f"{dt.day} {dt.strftime('%b %Y %H:%M')} UTC"


def _blinks_url(ticker: str, page: str) -> str:
    """Bloomberg BLINKS URL for a security page (DES or GP)."""
    return f"https://blinks.bloomberg.com/securities/{quote(ticker, safe='')}/{page}"


def _blinks_link(ticker: str, page: str, label: str, title: str, bg_color: str) -> str:
    href = _blinks_url(ticker, page)
    return (
        f'<a href="{href}" title="{title}" '
        f'style="display: inline-block; padding: 2px 7px; margin-left: 4px; '
        f"background-color: {bg_color}; color: white; text-decoration: none; "
        f'font-size: 10px; font-weight: bold; border-radius: 3px;">{label}</a>'
    )


def _bloomberg_ticker_rows(cfg: dict) -> str:
    """HTML table rows for one market's Bloomberg tickers."""
    rows = []
    for i, key in enumerate(BLINKS_TICKER_KEYS):
        ticker = cfg[key]
        label = BLINKS_KEY_LABELS[key]
        des = _blinks_link(ticker, "DES", "DES", "Description", "#2c3e50")
        gp = _blinks_link(ticker, "GP", "GP", "Chart", "#27ae60")
        row_pad = "2px 12px 4px 0" if i == 0 else "4px 12px 4px 0"
        rows.append(
            f"<tr><td style=\"padding: {row_pad}; white-space: nowrap;\">"
            f"<strong>{label}</strong> ({ticker})</td>"
            f"<td style=\"padding: {'2px' if i == 0 else '4px'} 0;\">{des}{gp}</td></tr>"
        )
    return "".join(rows)


def generate_bloomberg_links_section(cot_config: list) -> str:
    """Footer HTML with BLINKS links for all markets in cot_config."""
    text_style = (
        "font-size: 12px; font-family: -apple-system, BlinkMacSystemFont, "
        "'Segoe UI', Arial, sans-serif;"
    )
    market_blocks = []
    for cfg in cot_config:
        description = cfg["description"]
        market_blocks.append(
            f"""<div style="margin: 12px 0 4px 0; font-weight: bold;">{description}</div>
<table style="border-collapse: collapse; margin: 0 0 8px 0; padding: 0; {text_style}">
{_bloomberg_ticker_rows(cfg)}
</table>"""
        )

    return f"""{_section_header("Bloomberg Ticker Config")}
{"".join(market_blocks)}
"""


def _format_cell(val, signed: bool = False) -> str:
    if pd.isna(val):
        return "-"
    if signed:
        return f"{val:+.1f}"
    return f"{val:.1f}"


def _wow_cell_color(val) -> str:
    if pd.isna(val) or val == 0:
        return "#333333"
    if val > 0:
        return "#27ae60"
    return "#e74c3c"


def _format_table_header(col: str) -> str:
    """Split a column title across at most two lines for compact email headers."""
    if col == "Date":
        return col
    if col.startswith("WoW "):
        return f"WoW<br>{col[4:]}"
    if " (" in col and col.endswith(")"):
        name, unit = col.rsplit(" (", 1)
        unit = unit.rstrip(")")
        return f"{name}<br>({unit})"
    words = col.split()
    if len(words) <= 2:
        return col
    mid = len(words) // 2
    return f"{' '.join(words[:mid])}<br>{' '.join(words[mid:])}"


def _generate_data_table(df_output: pd.DataFrame) -> str:
    """HTML table for a single CoT summary dataframe."""
    columns = list(df_output.columns)
    wow_cols = {c for c in columns if c.startswith("WoW ")}

    th_base = (
        "padding: 6px 10px; border: 1px solid #2c3e50; line-height: 1.25; "
        "vertical-align: bottom; white-space: normal;"
    )
    table_html = """<table style="border-collapse: collapse; font-size: 12px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; width: auto;">
  <thead>
    <tr style="background-color: #2c3e50; color: white;">
"""
    table_html += (
        f'      <th style="{th_base} text-align: left; min-width: 78px;">'
        f"{_format_table_header('Date')}</th>\n"
    )

    for col in columns:
        min_width = "88px" if "Avg Front" in col else "64px"
        table_html += (
            f'      <th style="{th_base} text-align: right; min-width: {min_width};">'
            f"{_format_table_header(col)}</th>\n"
        )

    table_html += """    </tr>
  </thead>
  <tbody>
"""

    for i, (idx, row) in enumerate(df_output.iterrows()):
        bg_color = "#f8f9fa" if i % 2 == 1 else "white"
        table_html += f'    <tr style="background-color: {bg_color};">\n'
        table_html += (
            f'      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; '
            f'white-space: nowrap;">{_format_date(idx)}</td>\n'
        )

        for col in columns:
            val = row[col]
            val_str = _format_cell(val, signed=col in wow_cols)
            if col in wow_cols:
                color = _wow_cell_color(val)
                table_html += (
                    f'      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; '
                    f'text-align: right; color: {color}; font-weight: bold;">{val_str}</td>\n'
                )
            else:
                table_html += (
                    f'      <td style="padding: 4px 12px; border-bottom: 1px solid #eee; '
                    f'text-align: right;">{val_str}</td>\n'
                )

        table_html += "    </tr>\n"

    table_html += """  </tbody>
</table>
"""
    return table_html


def _generate_cot_section(
    df_output: pd.DataFrame,
    cfg: dict,
    net_chart_img: str,
    wow_chart_img: str,
    participant: str,
) -> str:
    """Chart and summary table HTML for one CoT market."""
    description = cfg["description"]
    chart_html = f"""{_section_header(f"{description} {participant} Net Length")}
<img src="data:image/png;base64,{net_chart_img}" alt="{description} Net Length by Year" style="max-width: 100%;">
"""
    summary_html = f"""{_section_header(f"{description} {participant} Summary")}
<table style="border-collapse: collapse; border: none; width: auto;">
  <tr>
    <td style="vertical-align: top; width: 1%; padding-right: 20px;">
      {_generate_data_table(df_output)}
    </td>
    <td style="vertical-align: top; width: auto; padding-left: 0;">
      <img src="data:image/png;base64,{wow_chart_img}" alt="{description} Net Length and Price WoW Delta" style="width: 400px; max-width: 400px; display: block;">
    </td>
  </tr>
</table>
"""
    return chart_html + summary_html


def generate_notes_section(participant: str) -> str:
    """Footer notes section describing CoT data and report scope."""
    text_style = (
        "font-size: 12px; font-family: -apple-system, BlinkMacSystemFont, "
        "'Segoe UI', Arial, sans-serif; line-height: 1.5; color: #333;"
    )
    return f"""{_section_header("Notes")}
<ul style="{text_style} margin: 0 0 8px 0; padding-left: 20px;">
  <li>The ICE <strong>CoT</strong> (Commitment of Traders) report is a weekly publication that details the aggregate holdings of different
      market participants in derivatives markets on ICE. It provides
      transparency into market sentiment by showing exactly who is holding long and short 
      positions across commodities, energy, and financial instruments.</li>
  <li><strong>Publication schedule:</strong> published each Wednesday, with positions reported as at
      the close of the previous Friday.</li>
  <li>All data is sourced from <strong>Bloomberg</strong>; there may be a slight delay versus the
      direct ICE source.</li>
  <li>This report displays <strong>{participant}</strong> positions only — not the other
      participant groupings available in the full CoT report.</li>
</ul>
"""


def send_teams_headline(
    webhook_url: str,
    report_type_name: str,
    cfg: dict,
    values: dict,
    last_update_dt,
) -> None:
    """
    Send a simple CoT headline for one commodity to a Teams channel.

    Posts an Adaptive Card to a Teams Workflow (Power Automate) webhook.

    Parameters
    ----------
    webhook_url : str
        Teams Workflow webhook URL.
    report_type_name : str
        CoT participant grouping display name (e.g. "Investment Funds").
    cfg : dict
        Market config with ``description`` and ``target_unit`` keys.
    values : dict
        Keys ``long``, ``short``, ``net`` mapping to (value, wow_change) tuples.
    last_update_dt : datetime-like
        Date the CoT data is applicable up to.
    """
    description = cfg["description"]
    unit = cfg["target_unit"]
    title = f"ICE CoT {report_type_name}: {description} ({unit})"

    row_blocks = [
        {
            "type": "TextBlock",
            "text": f"**{label}:** {val:,.1f} (Δ {chg:+.1f})",
            "wrap": True,
            "spacing": "Small",
        }
        for label, (val, chg) in (
            ("Long", values["long"]),
            ("Short", values["short"]),
            ("Net", values["net"]),
        )
    ]

    payload = {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.4",
                    "msteams": {"width": "Full"},
                    "body": [
                        {
                            "type": "TextBlock",
                            "text": f"**{title}** as at {_format_date(last_update_dt)}",
                            "size": "Medium",
                            "wrap": True,
                        },
                        *row_blocks,
                    ],
                },
            }
        ],
    }

    response = requests.post(
        webhook_url,
        json=payload,
        headers={"Content-Type": "application/json"},
        timeout=10,
    )
    response.raise_for_status()


def generate_email_body(
    sections: list,
    now_utc: datetime,
    last_update_dt,
    cot_config: list,
    participant: str,
) -> str:
    """
    Build HTML for the CoT summary email.

    Parameters
    ----------
    sections : list
        Each item is a dict with keys ``df_output``, ``cfg``, ``net_chart_img``, and ``wow_chart_img``.
    now_utc : datetime
        UTC timestamp when the Bloomberg query ran.
    last_update_dt : datetime-like
        Date the CoT data is applicable up to (Bloomberg LAST_UPDATE_DT).
    cot_config : list
        Full list of market config dicts (for Bloomberg links footer).
    participant : str
        CoT participant grouping display name (e.g. "Investment Funds").

    Returns
    -------
    str
        HTML document body suitable for send_email.
    """
    intro = f"""<p style="font-size: 12px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;">
Report generated at {_format_run_datetime(now_utc)}.<br>
CoT data applicable up to {_format_date(last_update_dt)}.
</p>
"""

    section_html = "".join(
        _generate_cot_section(
            section["df_output"],
            section["cfg"],
            section["net_chart_img"],
            section["wow_chart_img"],
            participant,
        )
        for section in sections
    )
    bloomberg_links = generate_bloomberg_links_section(cot_config)
    notes_html = generate_notes_section(participant)

    return f"""<html lang="en">
<body>
{intro}
{section_html}
{notes_html}
{bloomberg_links}
</body>
</html>
"""
