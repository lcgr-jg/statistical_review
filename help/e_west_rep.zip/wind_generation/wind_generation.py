# DE Wind Generation report 
import sys
import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime, timedelta
from pathlib import Path

from jain_commods.core.interfaces.bloomberg import weather
from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.util.htmlutils import df2html



REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/wind_generation')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'wind_generation.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')


# Check cmd line switches to see what type of report we're sending
run_12z = '--12z' in sys.argv


# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_wind_generation_12z.log" if run_12z else log_path / f"{stoday}_wind_generation.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )
system = platform.system().lower()


# Set datetime used to calculate the report dates
today = pd.to_datetime(datetime.now()).normalize()

# Over rides for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'
    
    ######## Overrides for testing 
    # run_12z = True # False
    # today = pd.to_datetime(datetime(2025,12,8)).normalize()


email_subject = "DE Wind Generation"
country='DE'

# Filename is set based on the 12z switch (as the same report is schedule to run twice at different time)
last_run_datetime_file = REPORTS_PATH / 'last_run_datetime_12z.txt' if run_12z else 'last_run_datetime.txt'
last_run_datetime_fmt = '%Y-%m-%dT%H:%M'


try:
    
    # Set which dates we are comparing 
    if run_12z:
        # We compare 12z vs 0z on the same day (except on a Sunday which is 12z Sunday vs 0z Friday)
        rd = today.replace(hour=12)
        rd_prev = (rd - timedelta(days=2)).replace(hour=0) if rd.dayofweek==6 else rd.replace(hour=0)
    else:
        # Compare 0z of current day vs 0z on previous day (except on Monday is vs Friday)
        rd = today
        rd_prev = rd - timedelta(days=3 if rd.dayofweek==0 else 1)
    
    logging.info(f'Running DE Wind Generation Report, run_12z={run_12z}, {rd.strftime(last_run_datetime_fmt)} vs {rd_prev.strftime(last_run_datetime_fmt)}')    
    
    # Get the last run report_date from the file
    last_run = datetime.strptime(open(last_run_datetime_file, 'r').read(), last_run_datetime_fmt)
    
    # Check if we've already run the report
    if rd != last_run:
        
        # Get required forecast
        df_fcast = weather.get_bbg_data('forecast-energy',country, model='Wind_Generation', pub_date=rd)
        
        # Check if published
        if len(df_fcast)>0:
            
            # Get previous forecast
            df_fcast_prev = weather.get_bbg_data('forecast-energy',country, model='Wind_Generation', pub_date=rd_prev)
            
            # Convert to daily GW & combine 
            df_fcast_d = df_fcast.resample('D').mean() / 1000 / 1000
            df_fcast_prev_d = df_fcast_prev.resample('D').mean() / 1000 / 1000
            
            # Extra check to ensure we don't send too early!
            # TODO: do BBG publish partial wind gen forecasts or not?
            if len(df_fcast_d)>=15:
                        
                # Tidy up, combine & add total
                latest_col = f"D{(rd-today).days} {rd.strftime('%H')}z"
                prev_col = f"D{(rd_prev-today).days} {rd_prev.strftime('%H')}z"
                df_fcast_d.columns = [latest_col]
                df_fcast_prev_d.columns = [prev_col]
                df_combined = pd.concat([df_fcast_d, df_fcast_prev_d], axis=1).dropna()
                df_combined['Delta'] = df_combined[latest_col] - df_combined[prev_col]
                df_combined.loc['Total'] = df_combined.sum()
         
                
                # Construct email
                df_html = df2html(df_combined, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
                email_body = f"""<p><b>DE Wind Generation forecasts using EC Ensemble Mean:</b>
                                <br>
                                {df_html}
                                <br><b>Notes:</b>
                                <br>All values are GW
                                <br>Data is queried live from Bloomberg (see EFOR for more info)
                                <br>Forecasts are produced by European Power Forecasting Ltd (EPF)
                                """
                
                # Construct email subject
                delta = df_combined.loc['Total','Delta']
                email_subject_change = f"{email_subject}: {delta:+,.0f}GW {latest_col} vs {prev_col}"
                
                # Send email
                send_email(receivers, 
                           email_subject_change, 
                           email_body,
                           from_address='eu.gap.reports@jainglobal.com')    
                
                # Save report_date value to the file to confirm we've sent today's report
                with open(last_run_datetime_file, 'w') as f:
                    f.write(rd.strftime(last_run_datetime_fmt))
                
                logging.info('Report sent')
                
            else:
                logging.info(f'DE Wind Generation Forecast for {rd.strftime(last_run_datetime_fmt)} is being published. Current days = {len(df_fcast_d)}')

        else:
            logging.info(f'DE Wind Generation Forecast for {rd.strftime(last_run_datetime_fmt)} not yet published (or missing)')
            
    else:
        logging.info(f'Report already sent for report date {rd.strftime(last_run_datetime_fmt)}')
            
        

except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))    




    
