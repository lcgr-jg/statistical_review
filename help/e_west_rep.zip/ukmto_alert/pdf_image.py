"""Rasterise a warning PDF so the map can sit in the email body.

These notices are one A4 page. The map is drawn on that page, so a picture
of the page is the useful view. Other Kafka emails on this desk already
embed PNG charts as data URIs, and the relay accepts that.
"""
from __future__ import annotations

import pymupdf

# 1x PDF points is 72 dpi. Half the previous render, so the email stays under 1 MB.
_ZOOM = 1.0


def render_pdf_pngs(content: bytes, zoom: float = _ZOOM) -> list[bytes]:
    """One PNG per page, in order."""
    document = pymupdf.open(stream=content, filetype="pdf")
    try:
        if document.page_count < 1:
            raise RuntimeError("PDF has no pages")
        matrix = pymupdf.Matrix(zoom, zoom)
        return [
            page.get_pixmap(matrix=matrix, alpha=False).tobytes("png")
            for page in document
        ]
    finally:
        document.close()
