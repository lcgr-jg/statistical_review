"""UKMTO warning alert.

Polls the Royal Navy product API behind ukmto.org and emails when a warning
is published or its PDF revision changes.
"""
