"""Subject and HTML body for a UKMTO warning email."""
from __future__ import annotations

import base64
import html
from datetime import datetime
from zoneinfo import ZoneInfo

from ukmto_alert.discover import ListedWarning, listing_page_url
from ukmto_alert.parse import ParsedWarning

_MONTHS = (
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
)


def format_listing_time(iso: str) -> str:
    """Clock time from the warnings table. The site shows it in the viewer's local zone.

    The desk reads the page in the UK, so the email uses London time.
    """
    if not iso:
        return ""
    dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
    return dt.astimezone(ZoneInfo("Europe/London")).strftime("%H:%M")


def format_issue_date(iso: str) -> str:
    if not iso:
        return ""
    dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
    return f"{dt.day:02d} {_MONTHS[dt.month - 1]} {dt.year} {dt.strftime('%H:%M')} UTC"


def build_subject(
    key: str,
    category: str | None,
    *,
    lng: bool,
    updated: bool,
    historic: bool = False,
) -> str:
    tags: list[str] = []
    if updated:
        tags.append("UPDATED")
    if lng:
        tags.append("LNG")
    if historic:
        tags.append("HISTORIC")
    prefix = (" ".join(tags) + " — ") if tags else ""
    category_suffix = f" {category}" if category else ""
    return f"{prefix}UKMTO WARNING {key}{category_suffix}"


def build_email_body(
    item: ListedWarning,
    parsed: ParsedWarning,
    *,
    updated: bool,
    page_pngs: list[bytes] | None = None,
) -> str:
    key = html.escape(item.key)
    category = html.escape(parsed.category or "")
    narrative = html.escape(parsed.narrative).replace("\n\n", "</p><p>").replace("\n", "<br>")
    pdf_href = html.escape(item.pdf_url, quote=True)
    page_href = html.escape(listing_page_url(item.year), quote=True)
    issue_date = parsed.issue_date or format_issue_date(item.issue_date)

    if parsed.lng and updated:
        banner = (
            '<p style="margin:0 0 12px;color:#9a3412;font-weight:700;font-size:22px">'
            "!! Updated warning — the notice mentions LNG !!"
            "</p>"
        )
    elif parsed.lng:
        banner = (
            '<p style="margin:0 0 12px;color:#9a3412;font-weight:700;font-size:22px">'
            "!! This warning mentions LNG !!"
            "</p>"
        )
    elif updated:
        base = html.escape(item.key.split("/", 1)[0])
        banner = (
            '<p style="margin:0 0 12px;font-weight:700">'
            f"This is an update to UKMTO warning {base}."
            "</p>"
        )
    else:
        banner = ""

    category_line = f'<p style="margin:2px 0 12px;font-size:18px;font-weight:700">{category}</p>' if category else ""
    details = _detail_lines(
        location=item.location or parsed.location,
        report_date=parsed.report_date,
        report_time=parsed.report_time,
        issue_date=issue_date,
        listing_time=format_listing_time(item.issue_date),
        source=parsed.source,
        reference=item.reference,
    )
    image_html = _page_images(page_pngs or [], key)
    return f"""<html>
<div style="font-family: Calibri, sans-serif; font-size: 15px; color: #222">
{banner}
<p style="margin:0;font-size:22px;font-weight:700">UKMTO WARNING {key}</p>
{category_line}
{details}
<p>{narrative}</p>
<p style="margin-top:16px"><a href="{pdf_href}">Open original PDF</a><br>
<a href="{page_href}">UKMTO warnings {item.year}</a><br>
<a href="https://x.com/UK_MTO">UKMTO X feed</a></p>
{image_html}
</div>
</html>
"""


def _detail_lines(
    *,
    location: str,
    report_date: str,
    report_time: str,
    issue_date: str,
    listing_time: str,
    source: str,
    reference: str,
) -> str:
    rows = [
        ("Location", location),
        ("Incident Date", report_date),
        ("Incident Time", report_time),
        ("Issue Date", issue_date),
        ("Time", listing_time),
        ("Source", source),
        ("Reference", reference),
    ]
    lines = [
        f"{html.escape(label)}: {html.escape(value)}"
        for label, value in rows
        if value
    ]
    if not lines:
        return ""
    return '<p style="margin:0 0 12px;line-height:1.45">' + "<br>".join(lines) + "</p>"


def _page_images(page_pngs: list[bytes], key: str) -> str:
    if not page_pngs:
        return ""
    tags = []
    for png in page_pngs:
        encoded = base64.b64encode(png).decode("ascii")
        tags.append(
            f'<img src="data:image/png;base64,{encoded}" alt="UKMTO warning {key}" '
            'width="450" style="width:100%;max-width:450px;height:auto;'
            'border:1px solid #cccccc">'
        )
    return '<p style="margin-top:16px">' + "<br><br>".join(tags) + "</p>"
