"""List UKMTO warnings from the product API the website already calls.

The year page is a Next.js shell. Its ProductListTable component loads data
from the Sitecore delivery host, not from the HTML:

- ``GET {api}/api/ukmto/products-count/{product_type_id}/{year}``
  months, each with an id and a product count
- ``GET {api}/api/ukmto/products/{month_id}``
  reference, issue date, location, and pdfUrl

``product_type_id`` for Warnings is ``19089a80-069d-4974-8899-2a9802bb7cdf``.
Published pages call ``https://sccd.royalnavy.mod.uk`` (draft mode uses
``https://sc.royalnavy.mod.uk``).
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import date

from curl_cffi import requests

from ukmto_alert.parse import rev_from_url, warning_key_from_reference

logger = logging.getLogger(__name__)

API_BASE = "https://sccd.royalnavy.mod.uk"
WARNINGS_PRODUCT_TYPE_ID = "19089a80-069d-4974-8899-2a9802bb7cdf"
SITE_BASE = "https://www.ukmto.org"

# The Dagster host's OpenSSL handshake is reset by the delivery host.
# Impersonating Chrome matches a browser TLS fingerprint, which that host accepts.
_ATTEMPTS = 4
_RETRYABLE = (requests.exceptions.ConnectionError, requests.exceptions.Timeout)


@dataclass(frozen=True)
class ListedWarning:
    key: str
    sitecore_id: str
    reference: str
    issue_date: str
    name: str
    location: str
    pdf_url: str
    rev: str
    year: int


def years_to_poll(today: date) -> list[int]:
    """Current calendar year, plus the previous year in the first week of January."""
    years = [today.year]
    if today.month == 1 and today.day <= 7:
        years.append(today.year - 1)
    return years


def listing_page_url(year: int) -> str:
    return f"{SITE_BASE}/ukmto-products/warnings/{year}"


def make_session() -> requests.Session:
    session = requests.Session(impersonate="chrome")
    session.headers.update({
        "Accept": "application/json",
        "Referer": f"{SITE_BASE}/",
        "Origin": SITE_BASE,
    })
    return session


def fetch_listings(
    session: requests.Session,
    *,
    api_base: str,
    product_type_id: str,
    years: list[int],
    timeout: float = 30,
) -> list[ListedWarning]:
    """Every warning currently listed for the given years."""
    found: dict[str, ListedWarning] = {}
    for year in years:
        months = _get_json(
            session,
            f"{api_base}/api/ukmto/products-count/{product_type_id}/{year}",
            timeout,
        )
        if not isinstance(months, list):
            raise RuntimeError(f"Unexpected month payload for {year}")
        for month in months:
            count = int(month.get("productItemCount") or 0)
            if count <= 0:
                continue
            month_id = month.get("id")
            month_name = month.get("name") or month_id
            products = _get_json(
                session,
                f"{api_base}/api/ukmto/products/{month_id}",
                timeout,
            )
            if not isinstance(products, list):
                raise RuntimeError(f"Unexpected product payload for {month_name} {year}")
            if not products:
                raise RuntimeError(
                    f"{month_name} {year} reported {count} warnings but the product list was empty"
                )
            for item in products:
                listed = _listed_warning(item, year)
                # A later issue date wins if the same number appears twice.
                current = found.get(listed.key)
                if current is None or listed.issue_date >= current.issue_date:
                    found[listed.key] = listed
    return list(found.values())


def download_pdf(session: requests.Session, url: str, *, timeout: float = 60) -> bytes:
    response = _get(
        session,
        url,
        timeout=timeout,
        headers={
            "Accept": "application/pdf,*/*",
            "Referer": f"{SITE_BASE}/",
        },
    )
    response.raise_for_status()
    content = response.content
    if not content.startswith(b"%PDF"):
        raise RuntimeError(f"Response was not a PDF: {url}")
    return content


def _get_json(session: requests.Session, url: str, timeout: float):
    response = _get(session, url, timeout=timeout)
    response.raise_for_status()
    return response.json()


def _get(session: requests.Session, url: str, *, timeout: float, headers: dict | None = None):
    """GET with a few retries. The peer sometimes resets the handshake."""
    last_error: Exception | None = None
    for attempt in range(1, _ATTEMPTS + 1):
        try:
            return session.get(url, timeout=timeout, headers=headers)
        except _RETRYABLE as exc:
            last_error = exc
            if attempt == _ATTEMPTS:
                break
            wait = 2 * attempt
            logger.warning("GET %s failed (%s); retry %d in %ds", url, exc, attempt, wait)
            time.sleep(wait)
    assert last_error is not None
    raise last_error


def _listed_warning(item: dict, year: int) -> ListedWarning:
    reference = str(item.get("reference") or item.get("name") or "").strip()
    sitecore_id = str(item.get("id") or "").strip()
    pdf_url = str(item.get("pdfUrl") or "").strip()
    key = warning_key_from_reference(reference) or sitecore_id
    if not key:
        raise RuntimeError(f"Warning has no reference or id: {item!r}")
    return ListedWarning(
        key=key,
        sitecore_id=sitecore_id,
        reference=reference,
        issue_date=str(item.get("issueDate") or ""),
        name=str(item.get("name") or reference),
        location=str(item.get("location") or "").strip(),
        pdf_url=pdf_url,
        rev=rev_from_url(pdf_url),
        year=year,
    )
