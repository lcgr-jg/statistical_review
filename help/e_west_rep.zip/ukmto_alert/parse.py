"""Warning numbers, PDF text, and LNG detection.

The listing ``reference`` is the identity. Examples from the live API:

- ``20260930-UKMTO_WARNING-146-26`` -> ``146-26``
- ``UKMTO 134-26/ 001`` -> ``134-26/001`` (an amendment of 134-26)

The PDF heading (``146-26 - ATTACK``) supplies the category and the narrative.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import date, datetime
from urllib.parse import parse_qs, urlparse
from zoneinfo import ZoneInfo

# ``146-26`` or ``134-26/001``. The hyphen is what the live API uses.
_REF_HYPHEN = re.compile(r"(\d{2,3}-\d{2})(?:\s*/\s*(\d+))?")
# Older filenames such as ``ukmto_056_26_warning``.
_REF_UNDERSCORE = re.compile(r"(?<![0-9])(\d{2,3})_(\d{2})(?![0-9])")
# ``ukmto-warning_059`` has the serial but no year beside it.
_REF_WORD = re.compile(r"(?i)warning[_-](\d{2,3})(?:[_-](\d{2}))?")
_HEADING = re.compile(
    r"(?m)^\s*(\d{2,3}-\d{2}(?:\s*/\s*\d+)?)\s*-\s*([A-Za-z][A-Za-z ]*?)\s*$"
)
_LNG = re.compile(r"\bLNG\b", re.IGNORECASE)
_SPACES = re.compile(r"[ \t]+")
# ``29 Sept 26``, ``23 Sep 2026``, ``17 SEP 2026``.
_DATE = r"\d{1,2}\s+[A-Za-z]{3,9}\.?\s+\d{2,4}"
_TIME = r"(?:TBC|\d{3,4}\s*UTC)"
_LABELS = re.compile(
    r"^Report Date:\s*Report Time:\s*Issue Date:\s*Source\s*:?\s*(.*)$",
    re.IGNORECASE,
)
_INCIDENT_DATE = re.compile(r"^Incident Date:\s*(.*)$", re.IGNORECASE)
_INCIDENT_TIME = re.compile(r"^Incident Time:\s*(.*)$", re.IGNORECASE)
_SOURCE_LABEL = re.compile(r"^Source\s*:?\s*(.*)$", re.IGNORECASE)
_TIME_LATE = re.compile(r"time[-\s]?late", re.IGNORECASE)
_VALUES = re.compile(
    rf"^(?P<report_date>{_DATE})\s+(?P<report_time>{_TIME})\s+"
    rf"(?P<issue_date>{_DATE})\s+(?P<source>.+)$",
    re.IGNORECASE,
)
_REPORT_DATE = re.compile(r"^(\d{1,2})\s+([A-Za-z]{3,9})\.?\s+(\d{2,4})$", re.IGNORECASE)
_MONTH_NUM = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12,
}


def warning_key_from_reference(reference: str) -> str | None:
    """Stable warning id from a listing reference, or None if it has no number."""
    if not reference:
        return None
    match = _REF_HYPHEN.search(reference)
    if match:
        base, suffix = match.group(1), match.group(2)
        if suffix:
            return f"{base}/{int(suffix):03d}"
        return base
    match = _REF_UNDERSCORE.search(reference)
    if match:
        return f"{match.group(1)}-{match.group(2)}"
    match = _REF_WORD.search(reference)
    if not match:
        return None
    number, year = match.group(1), match.group(2)
    if year:
        return f"{number}-{year}"
    return number


def parse_report_date(text: str) -> date | None:
    """PDF report date, such as ``6 Oct 2026`` or ``29 Sept 26``."""
    match = _REPORT_DATE.match((text or "").strip())
    if not match:
        return None
    day = int(match.group(1))
    month = _MONTH_NUM.get(match.group(2).lower().rstrip("."))
    if month is None:
        return None
    year = int(match.group(3))
    if year < 100:
        year += 2000
    try:
        return date(year, month, day)
    except ValueError:
        return None


def report_is_historic(report_date: str, today: date) -> bool:
    """True when the incident date is earlier than the day the email is sent.

    ``today`` is the London calendar date. The server clock's timezone is not used.
    """
    parsed = parse_report_date(report_date)
    return parsed is not None and parsed < today


def warning_is_historic(
    report_date: str,
    narrative: str,
    issue_iso: str,
    today: date,
) -> bool:
    """True when the incident is from a previous London day.

    The PDF date is the signal. If that cell is missing, a "time-late" wording
    or a listing issue date from an earlier London day is used instead.
    """
    if parse_report_date(report_date) is not None:
        return report_is_historic(report_date, today)
    if _TIME_LATE.search(narrative or ""):
        return True
    issued = _london_date(issue_iso)
    return issued is not None and issued < today


def _london_date(iso: str) -> date | None:
    if not iso:
        return None
    try:
        parsed = datetime.fromisoformat(iso.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed.astimezone(ZoneInfo("Europe/London")).date()


def is_amendment(key: str) -> bool:
    """True when UKMTO published this item as an update (``134-26/001``)."""
    return "/" in key


def rev_from_url(url: str) -> str:
    """Sitecore media revision. A new value means the PDF file was replaced."""
    if not url:
        return ""
    return parse_qs(urlparse(url).query).get("rev", [""])[0]


def text_hash(text: str) -> str:
    normalised = re.sub(r"\s+", " ", text).strip()
    return hashlib.sha256(normalised.encode("utf-8")).hexdigest()


def mentions_lng(text: str) -> bool:
    """Whole word only, so 'along' is not a match."""
    return bool(_LNG.search(text or ""))


@dataclass(frozen=True)
class ParsedWarning:
    number: str | None
    category: str | None
    narrative: str
    lng: bool
    text_hash: str
    report_date: str = ""
    report_time: str = ""
    issue_date: str = ""
    source: str = ""
    location: str = ""


def parse_warning_text(text: str) -> ParsedWarning:
    """Pull the heading, category, and body out of extracted PDF text."""
    heading = _HEADING.search(text or "")
    number = None
    category = None
    body = text or ""
    if heading:
        raw_number = re.sub(r"\s*/\s*", "/", heading.group(1))
        if "/" in raw_number:
            base, suffix = raw_number.split("/", 1)
            number = f"{base}/{int(suffix):03d}"
        else:
            number = raw_number
        category = heading.group(2).strip().upper()
        body = text[heading.end():]

    lines: list[str] = []
    for raw_line in body.splitlines():
        line = _SPACES.sub(" ", raw_line).strip()
        if not line:
            continue
        lowered = line.lower()
        if line.startswith("|") or "watchkeepers@" in lowered or lowered.startswith("www.ukmto.org"):
            continue
        lines.append(line)

    meta, lines = _extract_meta(lines)
    if not meta["report_date"]:
        meta, lines = _extract_incident_meta(lines)
    paragraphs, location = _reflow(lines)

    return ParsedWarning(
        number=number,
        category=category,
        narrative="\n\n".join(paragraphs).strip(),
        lng=mentions_lng(text or ""),
        text_hash=text_hash(text or ""),
        report_date=meta["report_date"],
        report_time=meta["report_time"],
        issue_date=meta["issue_date"],
        source=meta["source"],
        location=location,
    )


def _extract_meta(lines: list[str]) -> tuple[dict[str, str], list[str]]:
    """Split the PDF's four header fields off the narrative lines."""
    empty = {"report_date": "", "report_time": "", "issue_date": "", "source": ""}
    for index, line in enumerate(lines):
        label = _LABELS.match(line)
        if not label:
            continue
        inline = label.group(1).strip()
        if inline and (values := _VALUES.match(inline)):
            rest = lines[:index] + lines[index + 1:]
            return _meta(values), rest
        if index + 1 < len(lines) and (values := _VALUES.match(lines[index + 1])):
            rest = lines[:index] + lines[index + 2:]
            return _meta(values), rest
        rest = lines[:index] + lines[index + 1:]
        return empty, rest
    return empty, lines


def _extract_incident_meta(lines: list[str]) -> tuple[dict[str, str], list[str]]:
    """Newer PDFs stack Incident Date, Incident Time, and Source above the text."""
    empty = {"report_date": "", "report_time": "", "issue_date": "", "source": ""}
    for index, line in enumerate(lines):
        if not _INCIDENT_DATE.match(line):
            continue
        report_date, cursor = _labelled_value(lines, index, _INCIDENT_DATE)
        if cursor >= len(lines) or not _INCIDENT_TIME.match(lines[cursor]):
            continue
        report_time, cursor = _labelled_value(lines, cursor, _INCIDENT_TIME)
        if cursor >= len(lines) or not _SOURCE_LABEL.match(lines[cursor]):
            continue
        source, cursor = _labelled_value(lines, cursor, _SOURCE_LABEL)
        return (
            {
                "report_date": report_date,
                "report_time": report_time,
                "issue_date": "",
                "source": source,
            },
            lines[:index] + lines[cursor:],
        )
    return empty, lines


def _labelled_value(lines: list[str], index: int, pattern: re.Pattern[str]) -> tuple[str, int]:
    inline = (pattern.match(lines[index]).group(1) or "").strip()
    if inline:
        return inline, index + 1
    if index + 1 < len(lines):
        return lines[index + 1].strip(), index + 2
    return "", index + 1


def _meta(values: re.Match[str]) -> dict[str, str]:
    return {key: values.group(key).strip() for key in (
        "report_date", "report_time", "issue_date", "source",
    )}


def _reflow(lines: list[str]) -> tuple[list[str], str]:
    """Join PDF line wraps. A new paragraph starts only after . ! or ?

    The notice repeats the place name on its own at the bottom. That line has
    no sentence ending, so it is returned separately as the location.
    """
    paragraphs: list[str] = []
    buffer = ""
    for line in lines:
        if not buffer:
            buffer = line
            continue
        if buffer.endswith((".", "!", "?")):
            paragraphs.append(buffer)
            buffer = line
        else:
            buffer = f"{buffer} {line}"
    if buffer:
        paragraphs.append(buffer)

    location = ""
    if (
        len(paragraphs) > 1
        and not paragraphs[-1].endswith((".", "!", "?"))
        and len(paragraphs[-1]) <= 80
    ):
        location = paragraphs.pop()
    return paragraphs, location
