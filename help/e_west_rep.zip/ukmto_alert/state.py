"""Snapshot of warnings already seen.

Keyed by the warning number (``146-26`` or ``134-26/001``). A missing file
means this is the baseline run. A number that later disappears from the
listing stays in the file: the year page is split by month, and UKMTO may
drop older items from view.
"""
from __future__ import annotations

import json
from pathlib import Path

from ukmto_alert.discover import ListedWarning


def load_state(path: Path) -> dict | None:
    """None when no snapshot exists yet (the caller must baseline, not email)."""
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def save_state(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")


def needs_pdf(previous: dict | None, listed: list[ListedWarning]) -> tuple[str, list[ListedWarning]]:
    """Return ``('baseline', [])`` or ``('check', items whose PDF must be read)``.

    A PDF is read when the number is new or the Sitecore ``rev`` / URL changed.
    Unchanged revisions are not downloaded again.
    """
    if previous is None:
        return "baseline", []
    needed: list[ListedWarning] = []
    for item in listed:
        old = previous.get(item.key)
        if old is None or old.get("rev") != item.rev or old.get("pdf_url") != item.pdf_url:
            needed.append(item)
    needed.sort(key=lambda item: item.issue_date)
    return "check", needed


def baseline_record(item: ListedWarning, seen_at: str) -> dict:
    return {
        "sitecore_id": item.sitecore_id,
        "reference": item.reference,
        "issue_date": item.issue_date,
        "name": item.name,
        "location": item.location,
        "pdf_url": item.pdf_url,
        "rev": item.rev,
        "year": item.year,
        "category": "",
        "narrative": "",
        "text_hash": "",
        "lng": False,
        "first_seen": seen_at,
        "last_seen": seen_at,
        "alerted": False,
    }


def alert_record(item: ListedWarning, parsed, seen_at: str, previous: dict | None) -> dict:
    prior = (previous or {}).get(item.key) or {}
    return {
        "sitecore_id": item.sitecore_id,
        "reference": item.reference,
        "issue_date": item.issue_date,
        "name": item.name,
        "location": item.location,
        "pdf_url": item.pdf_url,
        "rev": item.rev,
        "year": item.year,
        "category": parsed.category or "",
        "narrative": parsed.narrative,
        "text_hash": parsed.text_hash,
        "lng": parsed.lng,
        "first_seen": prior.get("first_seen") or seen_at,
        "last_seen": seen_at,
        "alerted": True,
    }
