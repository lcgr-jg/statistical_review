"""UKMTO warning alert.

Every run (5 minutes by default):
  1. List warnings for the current year from the UKMTO product API.
  2. On the first run, store the listing and send nothing.
  3. After that, download the PDF only when a warning number is new or its
     Sitecore revision changed, and email the details.

Run:  python -m ukmto_alert.monitor
      python -m ukmto_alert.monitor --dry-run
      python -m ukmto_alert.monitor --loop
The Dagster schedule calls run_once() every 5 minutes.
"""
from __future__ import annotations

import argparse
import configparser
import io
import logging
import platform
import sys
import time
import traceback
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from pathlib import Path

from pypdf import PdfReader

from jain_commods.core.util.emailhelper import send_email

from ukmto_alert.discover import (
    API_BASE,
    WARNINGS_PRODUCT_TYPE_ID,
    download_pdf,
    fetch_listings,
    make_session,
    years_to_poll,
)
from ukmto_alert.email_content import build_email_body, build_subject
from ukmto_alert.parse import is_amendment, parse_warning_text, warning_is_historic
from ukmto_alert.pdf_image import render_pdf_pngs
from ukmto_alert.state import alert_record, baseline_record, load_state, needs_pdf, save_state

logger = logging.getLogger(__name__)

REPORTS_PATH = Path(__file__).parent.resolve()
STATE_FILE = REPORTS_PATH / "cache" / "warnings.json"
FROM_ADDRESS = "eu.gap.reports@jainglobal.com"


def load_config() -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    config.read(REPORTS_PATH / "ukmto_alert.cfg")
    return config


def get_receivers(config: configparser.ConfigParser) -> tuple[str, str]:
    receivers = config.get("ReportSettings", "receivers")
    error_receivers = config.get("ReportSettings", "error_receivers")
    if platform.system().lower() == "windows":
        receivers = "john.morley@jainglobal.com"
        error_receivers = "john.morley@jainglobal.com"
    return receivers, error_receivers


def pdf_bytes_to_text(content: bytes) -> str:
    reader = PdfReader(io.BytesIO(content))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def run_once(*, dry_run: bool = False, log=None) -> dict:
    """One poll. The first successful poll stores a baseline and does not email."""
    log = log or logger
    config = load_config()
    receivers, _ = get_receivers(config)
    api_base = config.get("Monitor", "api_base", fallback=API_BASE).rstrip("/")
    product_type_id = config.get(
        "Monitor", "product_type_id", fallback=WARNINGS_PRODUCT_TYPE_ID
    ).strip()

    today = datetime.now(timezone.utc).date()
    years = years_to_poll(today)
    seen_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    session = make_session()
    listed = fetch_listings(
        session,
        api_base=api_base,
        product_type_id=product_type_id,
        years=years,
    )
    log.info("Listed %d warnings for %s", len(listed), ", ".join(str(year) for year in years))
    if not listed:
        raise RuntimeError(f"UKMTO returned no warnings for {years}")

    previous = load_state(STATE_FILE)
    mode, needed = needs_pdf(previous, listed)

    if mode == "baseline":
        state = {item.key: baseline_record(item, seen_at) for item in listed}
        if not dry_run:
            save_state(STATE_FILE, state)
        log.info("First run — baseline of %d warnings, no email", len(listed))
        return {
            "email_sent": False,
            "first_run_baseline": True,
            "listed": len(listed),
            "alerted": 0,
            "subjects": [],
        }

    if not needed:
        log.info("No new or revised warnings")
        return {
            "email_sent": False,
            "first_run_baseline": False,
            "listed": len(listed),
            "alerted": 0,
            "subjects": [],
        }

    state = dict(previous or {})
    subjects: list[str] = []
    failures: list[str] = []
    for item in needed:
        if not item.pdf_url:
            failures.append(f"{item.key}: no PDF url")
            continue
        try:
            pdf_bytes = download_pdf(session, item.pdf_url)
            parsed = parse_warning_text(pdf_bytes_to_text(pdf_bytes))
            page_pngs = render_pdf_pngs(pdf_bytes)
        except Exception as exc:
            log.exception("Failed to read %s", item.key)
            failures.append(f"{item.key}: {exc}")
            continue

        updated = is_amendment(item.key) or item.key in state
        category = parsed.category
        historic = warning_is_historic(
            parsed.report_date,
            parsed.narrative,
            item.issue_date,
            datetime.now(ZoneInfo("Europe/London")).date(),
        )
        subject = build_subject(
            item.key, category, lng=parsed.lng, updated=updated, historic=historic,
        )
        body = build_email_body(item, parsed, updated=updated, page_pngs=page_pngs)
        if dry_run:
            log.info("[dry-run] would email %s: %s", receivers, subject)
            print(subject)
            print(body)
        else:
            send_email(receivers, subject, body, from_address=FROM_ADDRESS)
            state[item.key] = alert_record(item, parsed, seen_at, previous)
            save_state(STATE_FILE, state)
            log.info("Alert email sent to %s: %s", receivers, subject)
        subjects.append(subject)

    if failures:
        raise RuntimeError("Could not read some warnings: " + "; ".join(failures))

    return {
        "email_sent": bool(subjects) and not dry_run,
        "first_run_baseline": False,
        "listed": len(listed),
        "alerted": len(subjects),
        "subjects": subjects,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="UKMTO warning alert")
    parser.add_argument("--loop", action="store_true", help="poll forever every [Monitor] poll_minutes")
    parser.add_argument("--interval", type=float, default=None, help="loop interval in minutes")
    parser.add_argument("--dry-run", action="store_true", help="do not email or write the snapshot")
    args = parser.parse_args()

    log_path = REPORTS_PATH / "log"
    log_path.mkdir(exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_path / "ukmto_alert.log"),
        ],
    )

    config = load_config()
    _, error_receivers = get_receivers(config)
    interval_min = args.interval or config.getfloat("Monitor", "poll_minutes", fallback=10.0)

    if not args.loop:
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Done: %s", summary)
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            if not args.dry_run:
                send_email(error_receivers, "ERROR UKMTO Warning Alert", str(tb))
            sys.exit(1)
        return

    logger.info("Looping every %.1f minutes (Ctrl+C to stop)", interval_min)
    in_error_streak = False
    while True:
        started = time.monotonic()
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Cycle done: %s", summary)
            in_error_streak = False
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            if not in_error_streak and not args.dry_run:
                send_email(error_receivers, "ERROR UKMTO Warning Alert", str(tb))
            in_error_streak = True
        elapsed = time.monotonic() - started
        time.sleep(max(30.0, interval_min * 60 - elapsed))


if __name__ == "__main__":
    main()
