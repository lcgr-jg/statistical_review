"""Parser and snapshot tests. No network.

Run from eu_reports: python -m pytest ukmto_alert/tests -q
"""
from __future__ import annotations

from datetime import date

from ukmto_alert.discover import ListedWarning, years_to_poll
from ukmto_alert.email_content import build_email_body, build_subject
from ukmto_alert.parse import (
    mentions_lng,
    parse_warning_text,
    report_is_historic,
    warning_is_historic,
    warning_key_from_reference,
)
from ukmto_alert.state import needs_pdf

FIXTURE = """
UKMTO WARNING
| watchkeepers@ukmto.org
| www.ukmto.org

146-26 - ATTACK
Report Date: Report Time: Issue Date: Source
29 Sept 26 TBC 30 Sept 2026 Verified
UKMTO has received a time-late report of an incident within the Strait of Hormuz.

A verified source has reported that a Tanker has been struck by an unknown projectile.

Vessels are advised to transit with caution and report any suspicious activity to
UKMTO.

Strait of Hormuz
"""

LNG_FIXTURE = FIXTURE.replace("a Tanker", "an LNG carrier")

INCIDENT_FIXTURE = """
UKMTO WARNING
| watchkeepers@ukmto.org
| www.ukmto.org

167-26 - ATTACK
Incident Date:
11 OCT 2026
Incident Time:
TBC
Source
Verified
UKMTO has received a time-late report from a verified source that a container vessel
was struck by an unknown projectile while transiting inbound through the Strait
of Hormuz.

Authorities are investigating.

Vessels are advised to transit with caution and report any suspicious activity to
UKMTO.

Strait of Hormuz
"""


def _item(key: str, rev: str, url: str = "https://www.ukmto.org/a.pdf") -> ListedWarning:
    return ListedWarning(
        key=key,
        sitecore_id="id-" + key,
        reference=key,
        issue_date="2026-09-30T10:38:00Z",
        name=key,
        location="Strait of Hormuz",
        pdf_url=f"{url}?rev={rev}",
        rev=rev,
        year=2026,
    )


def test_reference_keys():
    assert warning_key_from_reference("20260930-UKMTO_WARNING-146-26") == "146-26"
    assert warning_key_from_reference("UKMTO 143-26") == "143-26"
    assert warning_key_from_reference("UKMTO 134-26/ 001") == "134-26/001"
    assert warning_key_from_reference("UKMTO 126-26/001") == "126-26/001"
    assert warning_key_from_reference("20260522-ukmto-warning_059") == "059"
    assert warning_key_from_reference("20260510-ukmto_056_26_warning_attack") == "056-26"


def test_pdf_text_extracts_number_category_and_narrative():
    parsed = parse_warning_text(FIXTURE)
    assert parsed.number == "146-26"
    assert parsed.category == "ATTACK"
    assert parsed.report_date == "29 Sept 26"
    assert parsed.report_time == "TBC"
    assert parsed.issue_date == "30 Sept 2026"
    assert parsed.source == "Verified"
    assert parsed.location == "Strait of Hormuz"
    assert "Tanker has been struck" in parsed.narrative
    assert "activity to UKMTO." in parsed.narrative
    assert "\nUKMTO." not in parsed.narrative
    assert "Report Date:" not in parsed.narrative
    assert not parsed.narrative.endswith("Strait of Hormuz")
    assert "watchkeepers@" not in parsed.narrative
    assert parsed.lng is False


def test_header_values_on_the_same_line_as_the_labels():
    text = (
        "142-26 - ATTACK\n"
        "Report Date: Report Time: Issue Date: Source "
        "23 Sep 2026 0630UTC 23 Sep 2026 Company Security Officer\n"
        "UKMTO has received a report of an incident within the Strait of Hormuz.\n"
    )
    parsed = parse_warning_text(text)
    assert parsed.report_date == "23 Sep 2026"
    assert parsed.report_time == "0630UTC"
    assert parsed.issue_date == "23 Sep 2026"
    assert parsed.source == "Company Security Officer"
    assert parsed.narrative.startswith("UKMTO has received")


def test_lng_is_a_whole_word():
    assert mentions_lng("an LNG carrier was struck")
    assert mentions_lng("lng tanker")
    assert not mentions_lng("sailing along the coast")
    assert parse_warning_text(LNG_FIXTURE).lng is True


def test_email_body_includes_number_narrative_and_links():
    parsed = parse_warning_text(LNG_FIXTURE)
    item = _item("146-26", "aaa")
    body = build_email_body(item, parsed, updated=False)
    assert "UKMTO WARNING 146-26" in body
    assert "!! This warning mentions LNG !!" in body
    assert "Tanker" not in body
    assert "LNG carrier" in body
    assert "Open original PDF" in body
    assert "Open the PDF" not in body
    assert "Location: Strait of Hormuz" in body
    assert "Incident Date: 29 Sept 26" in body
    assert "Incident Time: TBC" in body
    assert "Issue Date: 30 Sept 2026" in body
    assert "Time: 11:38" in body
    assert "Source: Verified" in body
    assert "https://www.ukmto.org/ukmto-products/warnings/2026" in body
    assert 'href="https://x.com/UK_MTO"' in body
    assert "watchkeepers@" not in body
    assert body.index("Open original PDF") < body.index("UKMTO warnings 2026") < body.index("UKMTO X feed")


def test_email_body_embeds_the_pdf_page_image():
    parsed = parse_warning_text(FIXTURE)
    item = _item("146-26", "aaa")
    body = build_email_body(item, parsed, updated=False, page_pngs=[b"\x89PNG\r\n"])
    assert 'width="450"' in body
    assert body.index("UKMTO X feed") < body.index("data:image/png;base64,")
    plain = build_email_body(item, parsed, updated=False)
    assert "data:image" not in plain


def test_render_pdf_pngs_returns_one_png_per_page():
    import pymupdf

    from ukmto_alert.pdf_image import render_pdf_pngs

    document = pymupdf.open()
    document.new_page(width=200, height=200)
    content = document.tobytes()
    document.close()
    pages = render_pdf_pngs(content, zoom=1)
    assert len(pages) == 1
    assert pages[0].startswith(b"\x89PNG")
    assert build_subject("146-26", "ATTACK", lng=False, updated=False) == (
        "UKMTO WARNING 146-26 ATTACK"
    )
    assert build_subject("146-26", "ATTACK", lng=True, updated=False) == (
        "LNG — UKMTO WARNING 146-26 ATTACK"
    )
    assert build_subject("134-26/001", "ATTACK", lng=False, updated=True) == (
        "UPDATED — UKMTO WARNING 134-26/001 ATTACK"
    )
    assert build_subject("134-26/001", "ATTACK", lng=True, updated=True) == (
        "UPDATED LNG — UKMTO WARNING 134-26/001 ATTACK"
    )
    assert build_subject("150-26", "ATTACK", lng=False, updated=False, historic=True) == (
        "HISTORIC — UKMTO WARNING 150-26 ATTACK"
    )
    assert build_subject("150-26", "ATTACK", lng=True, updated=False, historic=True) == (
        "LNG HISTORIC — UKMTO WARNING 150-26 ATTACK"
    )


def test_report_before_today_is_historic():
    today = date(2026, 10, 8)
    assert report_is_historic("6 Oct 2026", today)
    assert report_is_historic("06 Oct 26", today)
    assert not report_is_historic("8 Oct 2026", today)
    assert not report_is_historic("TBC", today)


def test_stacked_incident_date_is_split_out_and_flagged_historic():
    parsed = parse_warning_text(INCIDENT_FIXTURE)
    assert parsed.report_date == "11 OCT 2026"
    assert parsed.report_time == "TBC"
    assert parsed.source == "Verified"
    assert parsed.narrative.startswith("UKMTO has received a time-late report")
    assert "Incident Date" not in parsed.narrative
    today = date(2026, 10, 13)
    assert warning_is_historic(parsed.report_date, parsed.narrative, "2026-10-12T18:17:00Z", today)
    assert not warning_is_historic(parsed.report_date, parsed.narrative, "2026-10-12T18:17:00Z", date(2026, 10, 11))


def test_time_late_wording_is_historic_when_the_date_is_missing():
    today = date(2026, 10, 13)
    assert warning_is_historic("", "UKMTO has received a time-late report.", "", today)
    assert warning_is_historic("", "Authorities are investigating.", "2026-10-12T18:17:00Z", today)
    assert not warning_is_historic("", "Authorities are investigating.", "2026-10-13T07:40:00Z", today)


def test_missing_snapshot_is_a_baseline():
    mode, needed = needs_pdf(None, [_item("146-26", "aaa")])
    assert mode == "baseline"
    assert needed == []


def test_new_number_and_revised_pdf_need_a_download():
    previous = {
        "146-26": {"rev": "aaa", "pdf_url": "https://www.ukmto.org/a.pdf?rev=aaa"},
    }
    mode, needed = needs_pdf(previous, [
        _item("146-26", "aaa"),
        _item("147-26", "bbb"),
        _item("145-26", "ccc", url="https://www.ukmto.org/changed.pdf"),
    ])
    # 145-26 is not in previous, so it is new. Only 146-26 is unchanged.
    assert mode == "check"
    assert [item.key for item in needed] == ["147-26", "145-26"]


def test_same_rev_is_left_alone_and_a_new_rev_is_not():
    previous = {
        "146-26": {"rev": "aaa", "pdf_url": "https://www.ukmto.org/a.pdf?rev=aaa"},
    }
    _, unchanged = needs_pdf(previous, [_item("146-26", "aaa")])
    assert unchanged == []
    _, revised = needs_pdf(previous, [_item("146-26", "zzz")])
    assert [item.key for item in revised] == ["146-26"]


def test_january_also_polls_the_previous_year():
    assert years_to_poll(date(2026, 9, 30)) == [2026]
    assert years_to_poll(date(2027, 1, 3)) == [2027, 2026]
    assert years_to_poll(date(2027, 1, 8)) == [2027]
