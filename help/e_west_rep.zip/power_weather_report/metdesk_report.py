import os
import sys
import requests
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.colors as mcolors
import io
import base64
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Dict, Optional, Union, Tuple
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

from jain_commods.core.util.emailhelper import send_email

# Constants
CWG_API_URL = "https://api.metdesk.com/get/metdesk/cwg/v2"
POWER_API_URL = "https://api.metdesk.com/get/metdesk/powergen/v2"

class MetDeskClient:
    """
    Client for MetDesk API (CWG v2 and PowerGen v2).
    """
    def __init__(self, api_key: Optional[str] = None, base_url: str = CWG_API_URL):
        self.api_key = api_key or os.getenv("METDESK_API_KEY")
        self.base_url = base_url
        self.session = requests.Session()
        
    def _get_headers(self) -> Dict:
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        if self.api_key:
            headers["Authorization"] = self.api_key
        return headers

    def _request(self, method: str, endpoint: str, params: Optional[Dict] = None) -> Dict:
        url = f"{self.base_url}{endpoint}"
        
        # Debug Print
        # print(f"Requesting: {url} with params: {params}")
        
        try:
            response = self.session.request(
                method, 
                url, 
                headers=self._get_headers(), 
                params=params
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if response.status_code == 401:
                print("Authentication failed.")
            print(f"HTTP Error: {e} for url: {response.url}")
            if response.content:
                print(f"Response: {response.text}") # Debug 400 errors
            raise
        except Exception as e:
            print(f"Request failed: {e}")
            raise

    def get_locations(self, **kwargs) -> List[Dict]:
        return self._request("GET", "/locations", params=kwargs).get("data", [])

    def get_issues(self, model: str) -> List[str]:
        return self._request("GET", "/issues", params={"model": model}).get("data", [])

    def get_dtgs(self, model: str, issue: str, **kwargs) -> List[str]:
        params = {"model": model, "issue": issue}
        params.update(kwargs)
        return self._request("GET", "/dtgs", params=params).get("data", [])

    def get_forecasts(self, model: str, issue: str, start_dtg: str, end_dtg: str, 
                     element: str, locations: Union[str, List[str]], **kwargs) -> List[Dict]:
        if isinstance(locations, list):
            loc_str = ",".join(locations)
        else:
            loc_str = locations

        params = {
            "model": model,
            "issue": issue,
            "start_dtg": start_dtg,
            "end_dtg": end_dtg,
            "element": element,
            "location": loc_str
        }
        params.update(kwargs)
        return self._request("GET", "/forecasts", params=params).get("data", [])

    def get_climate(self, start_dtg: str, end_dtg: str, element: str, locations: Union[str, List[str]], **kwargs) -> List[Dict]:
        if isinstance(locations, list):
            loc_str = ",".join(locations)
        else:
            loc_str = locations
            
        params = {
            "start_dtg": start_dtg,
            "end_dtg": end_dtg,
            "element": element,
            "location": loc_str
        }
        params.update(kwargs)
        return self._request("GET", "/climate", params=params).get("data", [])

def process_forecast_evolution(api_url: str, 
                             model: str, 
                             element: str, 
                             countries: Dict[str, str],
                             days_back: int = 7, 
                             forecast_days: int = 15,
                             is_ensemble: bool = False,
                             extra_params: Dict = {}) -> Dict[str, Tuple[pd.DataFrame, pd.Series, Optional[Dict[str, pd.Series]]]]:
    
    # Instantiate client with correct Base URL
    client = MetDeskClient(base_url=api_url)
    
    all_issues = client.get_issues(model)
    if not all_issues:
        print(f"No issues found for model {model} at {api_url}")
        return {}
    
    all_issues = sorted(all_issues)
    
    issues_00z = [i for i in all_issues if 'T00:00:00Z' in i]
    
    # Filter for Weekday Issues Only (Mon=0 .. Fri=4)
    weekday_issues_00z = []
    for issue in issues_00z:
        try:
            dt = datetime.fromisoformat(issue.replace("Z", "+00:00"))
            if dt.weekday() < 5: 
                weekday_issues_00z.append(issue)
        except ValueError:
            continue
            
    recent_issues = weekday_issues_00z[-7:]
    
    # Check for absolute latest run (if not 00Z, append it)
    if all_issues:
        latest_available = all_issues[-1]
        if "T00:00:00Z" not in latest_available:
            recent_issues.append(latest_available)
    
    if not recent_issues:
        print(f"No valid issues found for model {model}")
        return {}
    
    latest_issue = recent_issues[-1]
    latest_issue_dt = datetime.fromisoformat(latest_issue.replace("Z", "+00:00"))
    
    # For PowerGen with base interval, timestamps must be at 12:00:00Z
    if "powergen" in api_url and extra_params.get("interval") == "base":
        # If latest is 00Z, analysis starts 12Z same day
        # If latest is 12Z, analysis starts 12Z same day
        start_analysis = latest_issue_dt.replace(hour=12, minute=0, second=0, microsecond=0)
    else:
        start_analysis = latest_issue_dt.replace(hour=0, minute=0, second=0, microsecond=0)
    
    end_analysis = start_analysis + timedelta(days=forecast_days)
    
    country_codes = list(countries.values())

    climate_map = {} 
    try:
        # PowerGen API has 30-day limit for climate endpoint, split into chunks
        # AND strictly limits queries to 30 days into the future
        clim_params = extra_params.copy()
        if clim_params.get("interval") == "model":
            clim_params["interval"] = "hires"
        
        # Determine strict end date limit for PowerGen
        curr_end_analysis = end_analysis
        if "powergen" in api_url:
             # Use current UTC time + 29 days as safe limit
             # Note: simple now() might be naive, but safe enough for this check
             limit_dt = datetime.now(timezone.utc).replace(hour=12, minute=0, second=0, microsecond=0) + timedelta(days=29)
             
             # If our analysis end is beyond the limit, clamp it
             if curr_end_analysis > limit_dt:
                 curr_end_analysis = limit_dt
        
        all_climate_data = []
        current_start = start_analysis
        
        while current_start < curr_end_analysis:
            # Calculate chunk end (30 days or end_analysis, whichever is earlier)
            chunk_end = min(current_start + timedelta(days=28), curr_end_analysis) # 28 days safe buffer for chunk size
            
            start_str = current_start.strftime("%Y-%m-%dT%H:%M:%SZ")
            end_str = chunk_end.strftime("%Y-%m-%dT%H:%M:%SZ")
            
            climate_data = client.get_climate(start_str, end_str, element, country_codes, **clim_params)
            if climate_data:
                all_climate_data.extend(climate_data)
            
            # Move to next chunk
            current_start = chunk_end + timedelta(days=1)
        
        if all_climate_data:
            clim_df = pd.DataFrame(all_climate_data)
            clim_df['dtg'] = pd.to_datetime(clim_df['dtg'])
            clim_df['date'] = clim_df['dtg'].dt.date
            
            # Inject Location if missing
            if 'location' not in clim_df.columns:
                 if len(country_codes) == 1 and "," not in country_codes[0]:
                     clim_df['location'] = country_codes[0]
            
            # Climate Aggregation
            # First daily per location
            if element == 'rrr6':
                daily_loc = clim_df.groupby(['date', 'location'])['value'].mean().reset_index()
            else:
                daily_loc = clim_df.groupby(['date', 'location'])['value'].mean().reset_index()
            
            # Then aggregate spatially (for regions like Nordic)
            configured_code = list(countries.values())[0]
            
            if element == 'rrr6':
                 daily = daily_loc.groupby('date')['value'].mean()
            elif element in ['wind', 'solar']:
                 daily = daily_loc.groupby('date')['value'].mean() / 1000
            else:
                 daily = daily_loc.groupby('date')['value'].mean()
                 
            climate_map[configured_code] = daily
    except Exception as e:
        print(f"Failed to fetch climate: {e}")

    country_forecasts = {code: [] for code in country_codes}
    latest_percentiles = {code: {} for code in country_codes} # Store percentiles for latest issue
    
    for issue in recent_issues:
        try:
            # Prepare DTG params
            dtg_params = {}
            
            # PowerGen API requires element/interval for /dtgs but NOT location
            if "powergen" in api_url:
                dtg_params = {
                    "element": element,
                    "interval": extra_params.get("interval")
                }
            
            valid_dtgs = client.get_dtgs(model, issue, **dtg_params)
            if not valid_dtgs:
                continue
                
            valid_dtg_objs = []
            for t_str in valid_dtgs:
                try:
                    dt = datetime.fromisoformat(t_str.replace("Z", "+00:00"))
                    valid_dtg_objs.append((dt, t_str))
                except ValueError:
                    continue
            
            valid_dtg_objs.sort(key=lambda x: x[0])
            
            # PowerGen with interval='base' requires DTGs at 12:00:00Z
            if "powergen" in api_url and extra_params.get("interval") == "base":
                valid_dtg_objs = [(dt, s) for (dt, s) in valid_dtg_objs if dt.hour == 12]
            
            overlap = [
                (dt, s) for (dt, s) in valid_dtg_objs 
                if dt >= start_analysis and dt <= end_analysis
            ]
            
            if not overlap:
                continue
            
            req_start_str = overlap[0][1]
            req_end_str = overlap[-1][1]
            
            params = extra_params.copy()
            
            # Use hires for better compatibility if model interval fails? 
            # Actually, let's stick to what passed, but allow override if needed.
            # User wants 'model' interval for Wind/Solar? I'll keep it for now.
            
            if is_ensemble:
                # If latest issue, request percentiles AND mean
                if issue == latest_issue:
                    params.update({"mean": 1, "percentiles": 1})
                else:
                    params.update({"mean": 1})
            else:
                 pass

            data = client.get_forecasts(model, issue, req_start_str, req_end_str, element, country_codes, **params)
            
            if data:
                df = pd.DataFrame(data)
                df['dtg'] = pd.to_datetime(df['dtg'])
                df['date'] = df['dtg'].dt.date
                
                # Inject Location if missing
                if 'location' not in df.columns:
                     if len(country_codes) == 1 and "," not in country_codes[0]:
                         df['location'] = country_codes[0]
                     # If mult-country request returned no location column, that's ambiguous, 
                     # but typically Forecasts endpoint returns location.
                
                # --- Processing for Evolution (Means only) ---
                if 'member' in df.columns:
                     if "mean" in df['member'].unique():
                         df_mean = df.loc[df['member'] == "mean"].copy()
                     elif "" in df['member'].unique():
                         df_mean = df.loc[df['member'] == ""].copy()
                     else:
                         df_mean = df.copy() 
                else:
                    df_mean = df.copy()

                # Deduplicate/Spatial Average AND Time Aggregation (Hires -> Daily)
                # First, aggregate to daily per location
                if element in ['wind', 'solar', 'rrr6']:
                    # Sum for Precip/Wind/Solar (if hires) - but wait, wind/solar are Rates (MW)? 
                    # No, Wind/Solar interval=base returns MWh or average MW? 
                    # Previous logic used MEAN for Wind/Solar daily aggregation from Hires.
                    # Standard practice: Daily Average MW or Total MWh. 
                    # If we use MEAN (Average MW), then GW conversion is /1000.
                    # Use MEAN to align with previous working state.
                    df_daily_loc = df_mean.groupby(['dtg', 'date', 'location'])['value'].mean().reset_index()
                else:
                    df_daily_loc = df_mean.groupby(['dtg', 'date', 'location'])['value'].mean().reset_index()

                # Now map locations to Configured Countries (Handling Aggregates like Nordic)
                # country_codes list might contain ["DE", "NO,SE,FI,DK", ...]
                # countries dict matches { "Germany": "DE", "Nordic": "NO,SE,FI,DK" }
                
                # In this loop `process_forecast_evolution` is called with ONE country item in `countries` dict
                # e.g. countries={"Nordic": "NO,SE,FI,DK"}
                # So we just validly aggregate ALL data in df to that one country key.
                
                configured_name = list(countries.keys())[0]
                
                # Aggregation across locations (Spatial)
                if element == 'rrr6':
                    # Precip: Sum across locations (e.g. Nordic Hydro)
                    daily_val = df_daily_loc.groupby('date')['value'].mean()
                elif element in ['wind', 'solar']:
                    # Wind/Solar: Sum across locations (e.g. Nordic Wind Capacity adds up)
                    # Then convert to GW
                    daily_val = df_daily_loc.groupby('date')['value'].mean() / 1000
                else:
                    # Temp: Mean across locations
                    daily_val = df_daily_loc.groupby('date')['value'].mean()
                
                # Generate Column Name: MM-DD HZ (e.g. 12-18 0Z, 12-18 12Z)
                # Generate Column Name: MM-DD HZ (e.g. 12-18 0Z, 12-18 12Z)
                try:
                    # issue format: YYYY-MM-DDTHH:MM:SSZ
                    # Manual parsing to be safe
                    # 2024-12-18T00:00:00Z
                    month = issue[5:7]
                    day = issue[8:10]
                    hour_str = issue.split("T")[1].split(":")[0]
                    hour = int(hour_str)
                    issue_short = f"{month}-{day} {hour}Z"
                except:
                     # Fallback
                     issue_short = issue.replace("T"," ").replace("Z","")[5:10] 
                
                daily_val.name = issue_short
                country_forecasts[list(countries.values())[0]].append(daily_val)
                
                # --- Processing for Percentiles (Latest Issue Only) ---
                if issue == latest_issue and is_ensemble and 'member' in df.columns:
                    # We expect members: "10%", "25%", "75%", "90%"
                    start_perc = ["10%", "25%", "75%", "90%"]
                    for p in start_perc:
                        if p in df['member'].unique():
                            df_p = df.loc[df['member'] == p].copy()
                            # Dedup
                            df_p = df_p.groupby(['dtg', 'date', 'location'])['value'].mean().reset_index()
                            
                            for loc, group in df_p.groupby('location'):
                                if element == 'rrr6':
                                    p_val = group.groupby('date')['value'].mean()
                                elif element in ['wind', 'solar']:
                                    # Convert MW to GW
                                    p_val = group.groupby('date')['value'].mean() / 1000
                                else:
                                    p_val = group.groupby('date')['value'].mean()
                                latest_percentiles[loc][p] = p_val

        except Exception as e:
            print(f"Error fetching issue {issue}: {e}")
            continue

    results = {}
    for loc, series_list in country_forecasts.items():
        if series_list:
            df = pd.concat(series_list, axis=1)
            clim = climate_map.get(loc, pd.Series())
            percs = latest_percentiles.get(loc, {})
            results[loc] = (df, clim, percs)
    
    return results

# --- Graphing Functions ---

BASE_COLORS = {
    "EC-ENS": plt.cm.Reds,
    "EC-AIFS-ENS": plt.cm.Greens,
    "EC-Ext": plt.cm.Purples,
}
MODEL_COLOR_SOLID = {
    "EC-ENS": "#d62728", # Red
    "EC-AIFS-ENS": "#2ca02c",  # Green
    "EC-Ext": "#9467bd" # Purple
}

def generate_comparison_graph(all_models_data: Dict[str, pd.DataFrame], 
                              all_models_percentiles: Dict[str, Dict[str, pd.Series]],
                              climate: pd.Series, 
                              element_name: str) -> str:
    plt.figure(figsize=(12, 5))
    
    if not climate.empty:
        dates = pd.to_datetime(climate.index)
        plt.plot(dates, climate.values, color='black', linestyle='--', linewidth=2, label='Climate', zorder=10)

    for model_name, df in all_models_data.items():
         # Plot Fans if available
         percs = all_models_percentiles.get(model_name, {})
         color = MODEL_COLOR_SOLID.get(model_name, "gray")
         
         if "10%" in percs and "90%" in percs:
             p10 = percs["10%"]
             p90 = percs["90%"]
             # Align indices
             common_idx = p10.index.intersection(p90.index)
             if not common_idx.empty:
                 plt.fill_between(pd.to_datetime(common_idx), 
                                  p10.loc[common_idx], 
                                  p90.loc[common_idx], 
                                  color=color, alpha=0.08, zorder=1, label=None) 
         
         if "25%" in percs and "75%" in percs:
             p25 = percs["25%"]
             p75 = percs["75%"]
             common_idx = p25.index.intersection(p75.index)
             if not common_idx.empty:
                 plt.fill_between(pd.to_datetime(common_idx), 
                                  p25.loc[common_idx], 
                                  p75.loc[common_idx], 
                                  color=color, alpha=0.2, zorder=2, label=None)

         if df.empty: continue
         
         latest_col = df.columns[-1]
         series = df[latest_col].dropna()
         if series.empty: continue
         
         dates = pd.to_datetime(series.index)
         
         plt.plot(dates, series.values, color=color, linewidth=2.5, label=f"{model_name} ({latest_col})", alpha=1.0, zorder=5)

    # Add Weekend Shading
    ax = plt.gca()
    all_dates = pd.Index([])
    if not climate.empty:
        all_dates = all_dates.union(pd.to_datetime(climate.index))
    for df in all_models_data.values():
        if not df.empty:
             # df index is dates
             all_dates = all_dates.union(pd.to_datetime(df.index))
             
    if len(all_dates) > 0:
        start_date = all_dates.min()
        end_date = all_dates.max()
        curr = start_date
        while curr <= end_date:
            if curr.weekday() >= 5:
                ax.axvspan(curr, curr + timedelta(days=1), color='gray', alpha=0.1, lw=0)
            curr += timedelta(days=1)

    plt.title(f"{element_name} - Model Comparison (Latest 00Z)", fontsize=14, fontweight='bold')
    plt.ylabel("Value", fontsize=12)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc='upper right', fontsize=11, framealpha=0.9)
    
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
    plt.xticks(rotation=45, fontsize=11)
    plt.yticks(fontsize=11)
    plt.tight_layout()
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=100)
    plt.close()
    buf.seek(0)
    return base64.b64encode(buf.read()).decode('utf-8')

def generate_evolution_graph(df: pd.DataFrame, climate: pd.Series, model_name: str, element_name: str) -> str:
    # Bigger Plot: Increase Height
    plt.figure(figsize=(8, 6))

    if not climate.empty:
        dates = pd.to_datetime(climate.index)
        plt.plot(dates, climate.values, color='black', linestyle='--', linewidth=1.5, label='Clim', zorder=10)

    cmap = BASE_COLORS.get(model_name, plt.cm.Greys)
    cols = df.columns
    n_cols = len(cols)
    
    for i, col in enumerate(cols):
        series = df[col].dropna()
        if series.empty: continue
        
        intensity = 0.3 + (0.7 * (i / max(1, n_cols-1)))
        color = cmap(intensity)
        
        dates = pd.to_datetime(series.index)
        
        lw = 2.0 if i == n_cols - 1 else 1.0
        alpha = 1.0 if i == n_cols - 1 else 0.6
        label = col if i == n_cols - 1 else None 
        if i == 0: label = f"{col} (Oldest)"
        if i == n_cols - 1: label = f"{col} (Latest)"

        plt.plot(dates, series.values, color=color, linewidth=lw, label=label, alpha=alpha)

    # Add Weekend Shading
    ax = plt.gca()
    # Get range of dates from index
    dates = pd.to_datetime(df.index)
        
    if len(dates) > 0:
        start_date = dates.min()
        end_date = dates.max()
        # Iterate through all days in range
        curr = start_date
        while curr <= end_date:
            # 5=Saturday, 6=Sunday
            if curr.weekday() >= 5:
                ax.axvspan(curr, curr + timedelta(days=1), color='gray', alpha=0.1, lw=0)
            curr += timedelta(days=1)
        # Iterate through all days in range
        curr = start_date
        while curr <= end_date:
            # 5=Saturday, 6=Sunday
            if curr.weekday() >= 5:
                ax.axvspan(curr, curr + timedelta(days=1), color='gray', alpha=0.1, lw=0)
            curr += timedelta(days=1)

    ax.set_title(f"{model_name} Evolution", fontsize=14, fontweight='bold')
    plt.ylabel(element_name, fontsize=12)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc='best', fontsize=11, framealpha=0.8)
    
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
    plt.xticks(rotation=45, fontsize=11)
    plt.yticks(fontsize=11)
    plt.tight_layout()
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=100)
    plt.close()
    buf.seek(0)
    return base64.b64encode(buf.read()).decode('utf-8')

# --- Styling & HTML ---

def get_color_style(val, climate_val, element_name, norm_min, norm_max):
    if pd.isna(val) or pd.isna(climate_val):
        return ""
    
    delta = val - climate_val
    abs_max = max(abs(norm_min), abs(norm_max))
    if abs_max == 0: abs_max = 1 
    
    normalized = delta / abs_max
    
    if "Precip" in element_name:
        normalized = -normalized 
        
    cmap = plt.cm.bwr 
    cmap_input = (normalized + 1) / 2
    rgba = cmap(cmap_input)
    hex_color = mcolors.to_hex(rgba)
    
    brightness = (rgba[0]*299 + rgba[1]*587 + rgba[2]*114) / 1000
    text_color = "#000000" if brightness > 0.5 else "#ffffff"
    
    return f"background-color: {hex_color}; color: {text_color};"

def get_prev_business_day(date_str: str) -> str:
    try:
        current_year = datetime.now().year
        # Handle cases like "12-18 12Z" -> "12-18"
        clean_date_str = date_str.split(" ")[0]
        dt = datetime.strptime(f"{current_year}-{clean_date_str}", "%Y-%m-%d")
        
        prev = dt - timedelta(days=1)
        while prev.weekday() >= 5:
            prev = prev - timedelta(days=1)
            
        return prev.strftime("%m-%d")
    except:
        return ""

def generate_html_table(df: pd.DataFrame, climate: pd.Series, title: str, element_name: str, norm_min: float, norm_max: float, master_index: pd.Index = None) -> str:
    if df.empty:
        return f"<p style='font-size:12px; text-align:center;'>{title}: No Data</p>"

    # Align to Master Index if provided
    if master_index is not None:
        df = df.reindex(master_index)
        if not climate.empty:
             climate = climate.reindex(master_index)
    
    climate_aligned = climate.reindex(df.index)
    
    latest_col = df.columns[-1] 
    
    delta_col = None
    if df.shape[1] >= 2:
        # Use iloc to avoid issues with duplicate column names
        delta_col = df.iloc[:, -1] - df.iloc[:, -2]
    
    html = f"""
    <div class="table-wrapper">
        <div style="font-weight: bold; font-size: 14px; margin-bottom: 5px; color: #333; text-align: center; border-bottom: 2px solid #ddd;">{title}</div>
        <table border="1" cellpadding="2" cellspacing="0" style="table-layout: fixed; width: 100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 12px;">
            <thead>
                <tr style="height: 38px; background-color: #f8f8f8;"> 
                    <th style="width: 14%; padding: 2px; vertical-align: middle;">Date</th>
                    {''.join(f'<th style="padding: 2px; vertical-align: middle; line-height: 1.2;">{col.split(" ")[0]}<br>{col.split(" ")[1]}</th>' if " " in col else f'<th style="padding: 2px; vertical-align: middle;">{col}</th>' for col in df.columns)} 
                    <th style="width: 10%; border-left: 2px solid #666; padding: 2px;">&Delta;</th>
                </tr>
            </thead>
            <tbody>
    """
    
    for date, row in df.iterrows():
        weekday = date.weekday()
        
        row_style = "height: 22px;" 
        if weekday >= 5: 
            row_style += "background-color: #eee; "
        if weekday == 6:
            row_style += "border-bottom: 2px solid #444; "
        
        date_str = date.strftime("%m-%d")
        
        date_display = f"{date_str}" 
        
        clim_val = climate_aligned.get(date, np.nan)
        clim_str = f"{clim_val:.1f}" if not pd.isna(clim_val) else "-"
        
        html += f"<tr style='{row_style}'><td style='font-weight: bold; text-align: center; padding: 1px;'>{date_display}</td>"
        
        for val in row:
            if pd.isna(val):
                html += "<td style='text-align:center; padding: 1px;'>-</td>"
            else:
                style = get_color_style(val, clim_val, element_name, norm_min, norm_max)
                html += f"<td style='{style} text-align:center; padding: 1px; font-weight:500;'>{val:.1f}</td>"
        
        delta_str = "-"
        delta_style = "text-align:center; border-left: 2px solid #666; padding: 1px;"
        if delta_col is not None:
            val = delta_col.get(date, np.nan)
            if not pd.isna(val):
                delta_str = f"{val:+.1f}"
                if val > 0.5: delta_style += "color: red;"
                elif val < -0.5: delta_style += "color: blue;"
        
        html += f"<td style='{delta_style}'>{delta_str}</td>"
        html += "</tr>"

    html += """
            </tbody>
        </table>
    </div>
    """
    return html

def main(
    recipients: str = None,
    dry_run: bool = False,
    use_saved_html: bool = False,
    elements_filter: List[str] = None
):
    """
    Main function to generate and send MetDesk weather reports.
    
    Args:
        recipients: Email recipients (default: eu.gap.ldn@jainglobal.com)
        dry_run: If True, skip sending emails (just generate files)
        use_saved_html: If True, skip API calls and send existing HTML files
        elements_filter: List of elements to generate (default: all)
    """
    # Toggle this to True to skip API calls and just send existing HTML files
    USE_SAVED_HTML = use_saved_html
    
    # Recipients must be provided (from config)
    if recipients is None:
        print("Warning: No email recipients specified. Reports will be generated but not emailed.")
        dry_run = True  # Force dry run if no recipients
    
    print("Generating Visual Power Weather Reports (Per Element)...")
    
    MODEL_MAP = {
        "EC-ENS": "eceps",
        "EC-AIFS-ENS": "ecaifsens",
        "EC-Ext": "ec46" 
    }
    ENSEMBLE_MODELS = {"eceps", "gfsens", "ecaifsens", "ec46"}
    
    # Configuration for Elements
    # Maps Name -> (API_URL, ElementCode, ExtraParams)
    ELEMENT_CONFIG = {
        "Temperature": {
            "url": CWG_API_URL,
            "code": "tt",
            "params": {}
        },
        "Precipitation": {
            "url": CWG_API_URL,
            "code": "rrr6",
            "params": {}
        },
        "Wind": {
            "url": POWER_API_URL,
            "code": "wind",
            "params": {"location_type": "country", "interval": "base"}
        },
        "Solar": {
            "url": POWER_API_URL,
            "code": "solar",
            "params": {"location_type": "country", "interval": "base"}
        }
    }
    
    COUNTRY_CONFIG = {
        "Germany": {
            "code": "DE",
            "elements": ["Temperature", "Wind", "Solar"] 
        },
        "France": {
            "code": "FR",
            "elements": ["Temperature", "Precipitation", "Wind", "Solar"]
        },
        "Spain": {
            "code": "ES",
            "elements": ["Temperature", "Precipitation", "Wind", "Solar"]
        },
        "Switzerland": {
            "code": "CH",
            "elements": ["Precipitation"]
        },
        "UK": {
            "code": "GB_met_emb",
            "elements": ["Wind", "Solar"] 
        },
        "Italy": {
            "code": "IT",
            "elements": ["Precipitation", "Wind", "Solar"]
        },
        "Nordic Hydro": {
            "code": "Nordic", 
            "elements": ["Precipitation"]
        },
        "Austria": {
            "code": "AT",
            "elements": ["Precipitation"]
        },
        "Romania": {
            "code": "RO",
            "elements": ["Precipitation", "Temperature", "Wind", "Solar"]
        },
    }

    # 1. Identify all unique elements requested
    all_requested_elements = set()
    for cfg in COUNTRY_CONFIG.values():
        all_requested_elements.update(cfg["elements"])
    
    # Apply filter if specified
    if elements_filter:
        all_requested_elements = all_requested_elements.intersection(set(elements_filter))
    
    # 2. Iterate Elements -> Create separate Report for each
    for element_name in all_requested_elements:
        el_conf = ELEMENT_CONFIG.get(element_name)
        if not el_conf: continue
        
        print(f"\n=== Generating Report for {element_name} ===")
        
        if USE_SAVED_HTML:
            # Skip API calls - just read saved HTML and send email
            data_dir = Path(__file__).parent / "data"
            filename = data_dir / f"power_weather_report_{element_name.lower()}.html"
            try:
                print(f"Reading saved HTML file: {filename}")
                with open(filename, "r", encoding='utf-8') as f:
                    report_html = f.read()
                print(f"Loaded {filename}")
                
                # Send Email with HTML as body
                if dry_run:
                    print(f"[DRY RUN] Would send email for {element_name} to {recipients}")
                else:
                    try:
                        print(f"Sending email for {element_name} to {recipients}...")
                        subject = f"Power Weather Report - {element_name} - {datetime.now().strftime('%Y-%m-%d')}"
                        if element_name != "Precipitation":
                            send_email(
                                recipients=recipients,
                                subject=subject,
                                body=report_html,
                            )
                            print("Email sent successfully.")
                    except Exception as e:
                        print(f"Failed to send email: {e}")
                    
            except FileNotFoundError:
                print(f"WARNING: {filename} not found, skipping {element_name}")
            continue
        
        # Normal API processing flow
        element_code = el_conf["code"]
        api_url = el_conf["url"]
        extra_params = el_conf["params"]
        
        # Dynamic Legend Text
        legend_left = "Low"
        legend_right = "High"
        
        if "Precip" in element_name:
            legend_left = "Wet (Blue)"
            legend_right = "Dry (Red)"
        elif "Temp" in element_name:
            legend_left = "Cool (Blue)"
            legend_right = "Warm (Red)"
        elif "Wind" in element_name:
            legend_left = "Low (Blue)"
            legend_right = "High (Red)"
        elif "Solar" in element_name:
            legend_left = "Cloudy (Blue)"
            legend_right = "Sunny (Red)"
        
        report_html = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <style>
                /* Base styles */
                body { 
                    font-family: 'Segoe UI', Arial, sans-serif; 
                    margin: 0; 
                    padding: 20px; 
                    color: #333; 
                    -webkit-text-size-adjust: 100%;
                    -ms-text-size-adjust: 100%;
                }
                
                .country-section { 
                    margin-bottom: 50px; 
                    border: 1px solid #ddd; 
                    padding: 15px; 
                }
                
                .element-section { 
                    margin-bottom: 60px; 
                } 
                
                .comparison-row {
                    width: 100%;
                    border-top: 2px dashed #eee;
                    padding-top: 20px;
                    margin-top: 20px;
                }
                
                h1 { 
                    color: #2c3e50; 
                    border-bottom: 3px solid #2c3e50; 
                    padding-bottom: 5px; 
                    margin-top: 0; 
                    font-size: 22px;
                }
                
                h2 { 
                    color: #e67e22; 
                    margin-top: 0; 
                    border-bottom: 1px solid #eee; 
                    padding-bottom: 5px; 
                    font-size: 20px; 
                }
                
                /* Responsive container for model columns */
                .models-container {
                    width: 100%;
                }
                
                .model-column {
                    display: inline-block;
                    width: 33%;
                    vertical-align: top;
                    padding: 5px;
                    box-sizing: border-box;
                }
                
                /* Table responsive wrapper */
                .table-wrapper {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                    margin-bottom: 10px;
                }
                
                /* Image scaling */
                .responsive-img {
                    width: 100%;
                    height: auto;
                    max-width: 100%;
                    border: 1px solid #eee;
                    margin-top: 10px;
                }
                
                /* Mobile-specific styles */
                @media only screen and (max-width: 600px) {
                    body {
                        padding: 10px;
                        font-size: 14px;
                    }
                    
                    .country-section {
                        padding: 10px;
                        margin-bottom: 30px;
                    }
                    
                    h1 {
                        font-size: 18px;
                        padding-bottom: 3px;
                    }
                    
                    h2 {
                        font-size: 16px;
                        padding-bottom: 3px;
                    }
                    
                    /* Stack model columns vertically on mobile */
                    .model-column {
                        display: block;
                        width: 100% !important;
                        padding: 10px 0;
                        border-bottom: 2px solid #eee;
                    }
                    
                    /* Mobile table styles */
                    table {
                        font-size: 11px !important;
                        min-width: 100%;
                    }
                    
                    table th,
                    table td {
                        padding: 3px 2px !important;
                        font-size: 11px !important;
                    }
                    
                    /* Adjust comparison chart */
                    .comparison-row {
                        padding-top: 15px;
                        margin-top: 15px;
                    }
                    
                    /* Legend adjustments */
                    .legend-text {
                        font-size: 11px !important;
                    }
                    
                    .legend-gradient {
                        width: 40px !important;
                        height: 8px !important;
                    }
                }
                
                /* Tablet styles */
                @media only screen and (min-width: 601px) and (max-width: 800px) {
                    .model-column {
                        width: 50%;
                    }
                    
                    table {
                        font-size: 11px;
                    }
                }
            </style>
        </head>
        <body>
        <div style="margin-bottom: 20px; text-align:center;">
            <h2 style="color: #333; border: none; font-size: 24px;">""" + f"{element_name} Report (00Z Runs) - " + datetime.now().strftime('%Y-%m-%d') + """</h2>
            <p class="legend-text" style='font-size: small; color: #666;'>
                <strong>Heatmap Legend:</strong> """ + legend_left + """ <span class="legend-gradient" style='display:inline-block; width:50px; height:10px; background:linear-gradient(90deg, blue, white, red); border:1px solid #ccc; vertical-align:middle; margin: 0 5px;'></span> """ + legend_right + """<br>
            </p>
        </div>
        """
        
        # 3. Iterate Countries for this Element
        for country_name, config in COUNTRY_CONFIG.items():
            if element_name not in config["elements"]:
                continue
            
            country_code = config["code"]
            
            report_html += f"<div class='country-section'><h1>{country_name}</h1>"
            report_html += f"<div class='element-section'>" 
            
            # Fetch & Process logic
            all_models_data = {}
            all_models_percentiles = {}
            climate_series = pd.Series(dtype=float)
            
            for model_name, api_model in MODEL_MAP.items():
                print(f"Processing {country_name} {element_name} {model_name}...")
                is_ensemble = api_model in ENSEMBLE_MODELS
                
                if api_model == "ec46":
                    fc_days = 46
                    days_back = 25 
                else:
                    fc_days = 15
                    days_back = 12
                
                res = process_forecast_evolution(
                    api_url, api_model, element_code, {country_name: country_code}, 
                    days_back=days_back, 
                    forecast_days=fc_days,
                    is_ensemble=is_ensemble,
                    extra_params=extra_params
                )
                
                if country_code in res:
                    df, clim, percs = res[country_code]
                    all_models_data[model_name] = df
                    all_models_percentiles[model_name] = percs
                    if climate_series.empty and not clim.empty:
                         climate_series = clim
                    elif len(clim) > len(climate_series):
                        climate_series = clim

            master_index = pd.Index([])
            for df in all_models_data.values():
                if len(df.index) > len(master_index):
                    master_index = df.index
            
            min_delta = 0
            max_delta = 0
            for model_name, df in all_models_data.items():
                 if df.empty or climate_series.empty: continue
                 clim_aligned = climate_series.reindex(df.index)
                 delta_df = df.sub(clim_aligned, axis=0)
                 min_delta = min(min_delta, delta_df.min().min())
                 max_delta = max(max_delta, delta_df.max().max())
            
            # Use responsive div layout instead of table for better mobile support
            report_html += '<div class="models-container">'
            for model_name in MODEL_MAP.keys(): 
                report_html += '<div class="model-column">'
                if model_name in all_models_data:
                    df = all_models_data[model_name]
                    report_html += generate_html_table(df, climate_series, model_name, element_name, min_delta, max_delta, master_index=master_index)
                    img_evo = generate_evolution_graph(df, climate_series, model_name, element_name)
                    report_html += f'<img src="data:image/png;base64,{img_evo}" class="responsive-img" />'
                else:
                    report_html += f'<div style="padding:20px; text-align:center;"><strong>{model_name}</strong><br>No Data</div>'
                report_html += '</div>' 
            report_html += '</div>' 
 
            
            report_html += "<div class='comparison-row'>"
            if any(not d.empty for d in all_models_data.values()):
                img_cmp = generate_comparison_graph(all_models_data, all_models_percentiles, climate_series, element_name)
                report_html += f"<img src='data:image/png;base64,{img_cmp}' style='width:100%; height:auto;' />"
            else:
                report_html += "<p>No data for comparison</p>"
            report_html += "</div>"
            
            report_html += "</div></div>" 
        
        report_html += "</body></html>"
        
        # Save to data folder (use absolute path for consistency)
        data_dir = Path(__file__).parent / "data"
        data_dir.mkdir(exist_ok=True)
        filename = data_dir / f"power_weather_report_{element_name.lower()}.html"
        with open(filename, "w", encoding='utf-8') as f:
            f.write(report_html)
        print(f"Saved {filename}")

        # Send Email with HTML as body
        if dry_run:
            print(f"[DRY RUN] Would send email for {element_name} to {recipients}")
        else:
            try:
                print(f"Sending email for {element_name} to {recipients}...")
                subject = f"Power Weather Report - {element_name} - {datetime.now().strftime('%Y-%m-%d')}"

                send_email(
                    recipients=recipients,
                    subject=subject,
                    body=report_html,
                )
                print("Email sent successfully.")
            except Exception as e:
                print(f"Failed to send email: {e}")


# ============================================================================
# Entry Point for Dagster Orchestration
# ============================================================================

def run_metdesk_report(
    recipients: str = None,
    dry_run: bool = False,
    elements: List[str] = None
) -> dict:
    """
    Entry point for Dagster orchestration.
    
    Args:
        recipients: Email recipients (if None, uses default)
        dry_run: If True, skip sending emails
        elements: List of elements to generate (default: all)
    
    Returns:
        dict with metadata about generated reports
    """
    from datetime import datetime
    
    main(
        recipients=recipients,
        dry_run=dry_run,
        elements_filter=elements
    )
    
    generated_elements = elements or ["Temperature", "Precipitation", "Wind", "Solar"]
    
    return {
        "elements": generated_elements,
        "num_elements": len(generated_elements),
        "recipients": recipients or "eu.gap.ldn@jainglobal.com",
        "dry_run": dry_run,
        "generated_at": datetime.now().isoformat()
    }


if __name__ == "__main__":
    run_metdesk_report(recipients='michael.kane@jainglobal.com')
