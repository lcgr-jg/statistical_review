"""
Wind Ensemble Probability Report

Creates HTML tables showing the probability that weekday/weekend wind generation
is above/below various thresholds, using EC-EPS ensemble members.

Tables:
1. Weekday wind above threshold
2. Weekday wind below threshold
3. Weekend wind above threshold
4. Weekend wind below threshold

Y-axis: Thresholds (0-55 GW in 5 GW steps)
X-axis: Probability that N days are above/below threshold (1 day, 2 days, etc.)
"""

import os
import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dotenv import load_dotenv


def _load_env():
    """Load .env file from common locations."""
    search_paths = [
        Path.cwd() / ".env",
        Path.cwd().parent / "eu_commods_pipelines" / ".env",
        Path(__file__).parent.parent / "eu_commods_pipelines" / ".env",
        Path(r"C:\Users\Michael.Kane\OneDrive - Jain Global\Projects\eu_commods_pipelines\.env"),
    ]
    
    for env_path in search_paths:
        if env_path.exists():
            load_dotenv(env_path)
            print(f"Loaded environment from: {env_path}")
            return
    
    # Also try loading from current directory's .env
    load_dotenv()

_load_env()

# Constants
POWER_API_URL = "https://api.metdesk.com/get/metdesk/powergen/v2"
THRESHOLDS_GW = list(range(0, 60, 5))  # 0, 5, 10, ..., 55 GW

# Model Configuration: Expected number of members
# This is used to filter out phantom members (e.g. API returning 100 members when only 51 exist)
MODEL_MEMBER_COUNTS = {
    "eceps": 51,      # Control + 50 perturbed
    "gfsens": 31,     # Control + 30 perturbed
    "ec46": 51,       # Control + 50 perturbed
    "ecaifsens": 51,  # Control + 50 perturbed
}


class MetDeskClient:
    """Client for MetDesk PowerGen API."""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("METDESK_API_KEY")
        self.base_url = POWER_API_URL
        self.session = requests.Session()
        
    def _get_headers(self) -> Dict:
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        if self.api_key:
            headers["Authorization"] = self.api_key
        return headers

    def _request(self, method: str, endpoint: str, params: Optional[Dict] = None) -> Dict:
        url = f"{self.base_url}{endpoint}"
        try:
            response = self.session.request(
                method, 
                url, 
                headers=self._get_headers(), 
                params=params
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if response.status_code == 401:
                print("Authentication failed.")
            print(f"HTTP Error: {e} for url: {response.url}")
            if response.content:
                print(f"Response: {response.text}")
            raise
        except Exception as e:
            print(f"Request failed: {e}")
            raise

    def get_issues(self, model: str) -> List[str]:
        return self._request("GET", "/issues", params={"model": model}).get("data", [])

    def get_dtgs(self, model: str, issue: str, element: str, interval: str) -> List[str]:
        """Get valid DTGs for a model/issue/element/interval combination."""
        params = {
            "model": model,
            "issue": issue,
            "element": element,
            "interval": interval
        }
        return self._request("GET", "/dtgs", params=params).get("data", [])

    def get_forecasts(self, model: str, issue: str, start_dtg: str, end_dtg: str, 
                     element: str, location: str, **kwargs) -> List[Dict]:
        params = {
            "model": model,
            "issue": issue,
            "start_dtg": start_dtg,
            "end_dtg": end_dtg,
            "element": element,
            "location": location
        }
        params.update(kwargs)
        return self._request("GET", "/forecasts", params=params).get("data", [])


def get_next_week_dates() -> Tuple[List[datetime], List[datetime]]:
    """
    Get next week's weekday and weekend dates.
    
    Returns:
        Tuple of (weekday_dates, weekend_dates)
    """
    today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Find next Monday
    days_until_monday = (7 - today.weekday()) % 7
    if days_until_monday == 0:
        days_until_monday = 7  # If today is Monday, go to next Monday
    
    next_monday = today + timedelta(days=days_until_monday)
    
    # Get all days of next week
    weekday_dates = []
    weekend_dates = []
    
    for i in range(7):
        day = next_monday + timedelta(days=i)
        if day.weekday() < 5:  # Monday=0 to Friday=4
            weekday_dates.append(day)
        else:  # Saturday=5, Sunday=6
            weekend_dates.append(day)
    
    return weekday_dates, weekend_dates


def fetch_single_model_data(client: MetDeskClient, country_code: str, 
                        start_date: datetime, end_date: datetime,
                        model_name: str,
                        issue: str = None) -> pd.DataFrame:
    """
    Fetch ensemble member data for a single model.
    
    Args:
        client: MetDeskClient instance
        country_code: Country code (e.g. "DE")
        start_date: Start date for data
        end_date: End date for data
        model_name: Model name (e.g. "eceps", "ecaifsens")
        issue: Specific issue to use (if None, finds today's 00Z)
    
    Returns:
        DataFrame with columns: dtg, member, value, value_gw
    """
    # Get issues and find today's 00Z run
    if issue is None:
        issues = client.get_issues(model_name)
        if not issues:
            print(f"No issues found for {model_name}")
            return pd.DataFrame()
        
        # Sort and find today's 00Z
        issues = sorted(issues)
        today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        issue_00z = f"{today_str}T00:00:00Z"
        
        if issue_00z in issues:
            issue = issue_00z
        else:
            # Fall back to latest 00Z issue
            issues_00z = [i for i in issues if 'T00:00:00Z' in i]
            if issues_00z:
                issue = issues_00z[-1]
            else:
                issue = issues[-1]
    
    print(f"[{model_name}] Using issue: {issue}")
    
    # Get valid DTGs for this issue
    valid_dtgs = client.get_dtgs(model_name, issue, "wind", "base")
    if not valid_dtgs:
        print(f"[{model_name}] No valid DTGs found for issue {issue}")
        return pd.DataFrame()
    
    # Parse DTGs and filter to our date range
    # For base interval, DTGs are at 12:00:00Z
    valid_dtg_objs = []
    for dtg_str in valid_dtgs:
        try:
            dt = datetime.fromisoformat(dtg_str.replace("Z", "+00:00"))
            valid_dtg_objs.append((dt, dtg_str))
        except ValueError:
            continue
    
    valid_dtg_objs.sort(key=lambda x: x[0])
    
    # Filter to base interval DTGs (12:00:00Z)
    valid_dtg_objs = [(dt, s) for (dt, s) in valid_dtg_objs if dt.hour == 12]
    
    # Convert our date range to 12Z timestamps
    start_12z = start_date.replace(hour=12, minute=0, second=0, microsecond=0)
    end_12z = end_date.replace(hour=12, minute=0, second=0, microsecond=0)
    
    # Find DTGs in our range
    overlap = [
        (dt, s) for (dt, s) in valid_dtg_objs 
        if dt >= start_12z and dt <= end_12z
    ]
    
    if not overlap:
        print(f"[{model_name}] No DTGs in range {start_12z} to {end_12z}")
        return pd.DataFrame()
    
    req_start_str = overlap[0][1]
    req_end_str = overlap[-1][1]
    
    print(f"  [{model_name}] Fetching {country_code}: {req_start_str} to {req_end_str}")
    
    # Fetch ensemble members
    data = client.get_forecasts(
        model=model_name,
        issue=issue,
        start_dtg=req_start_str,
        end_dtg=req_end_str,
        element="wind",
        location=country_code,
        location_type="country",
        interval="base",
        members=1  # Get all ensemble members
    )
    
    if not data:
        print(f"[{model_name}] No forecast data for {country_code}")
        return pd.DataFrame()
    
    df = pd.DataFrame(data)
    df['dtg'] = pd.to_datetime(df['dtg'])
    df['date'] = df['dtg'].dt.date
    
    # Convert MW to GW
    df['value_gw'] = df['value'] / 1000
    
    # Filter phantom members if model is known
    # Some API responses include members 51-100 as 0s for EC-EPS
    if model_name in MODEL_MEMBER_COUNTS:
        expected_count = MODEL_MEMBER_COUNTS[model_name]
        unique_members = df['member'].unique()
        
        if len(unique_members) > expected_count:
            print(f"  [{model_name}] Filtering members: Found {len(unique_members)}, expected {expected_count}")
            
            # Members are usually strings "0", "1", ... or "control", "1", ...
            # We need to be careful with filtering. 
            # Strategy: Keep "control" or "0", and then 1..N
            
            valid_members = []
            
            # Check for control/0
            if "control" in unique_members:
                valid_members.append("control")
            elif "0" in unique_members:
                valid_members.append("0")
            elif 0 in unique_members:
                valid_members.append(0)
                
            # Check for numbered members
            # Assuming members are 1-based index in the API response usually
            for i in range(1, expected_count):
                s_i = str(i)
                if s_i in unique_members:
                    valid_members.append(s_i)
                elif i in unique_members:
                    valid_members.append(i)
            
            # Filter
            df = df[df['member'].isin(valid_members)].copy()
            print(f"  [{model_name}] Kept {len(df['member'].unique())} members after filtering")

    return df


def fetch_merged_ensemble_data(client: MetDeskClient, country_code: str, 
                               start_date: datetime, end_date: datetime,
                               models: List[str],
                               issue: str = None) -> pd.DataFrame:
    """
    Fetch and merge ensemble data from multiple models.
    Members are renamed to {model}_{member} to ensure uniqueness.
    """
    all_dfs = []
    
    for model in models:
        df = fetch_single_model_data(client, country_code, start_date, end_date, model, issue)
        if not df.empty:
            # Rename members to include model name to ensure uniqueness
            df['member'] = f"{model}_" + df['member'].astype(str)
            all_dfs.append(df)
            
    if not all_dfs:
        return pd.DataFrame()
        
    merged_df = pd.concat(all_dfs, ignore_index=True)
    print(f"  Merged Data: Total {len(merged_df['member'].unique())} unique members from {len(all_dfs)} models")
    
    return merged_df


def compute_day_counts_by_member(df: pd.DataFrame, threshold_gw: float, 
                                  target_dates: List[datetime], 
                                  above: bool = True) -> Dict[str, int]:
    """
    For each ensemble member, count how many days in target_dates are above/below threshold.
    
    Args:
        df: DataFrame with columns: dtg, member, value_gw
        threshold_gw: Threshold in GW
        target_dates: List of target dates
        above: If True, count days above threshold; if False, below
        
    Returns:
        Dict mapping member -> count of days
    """
    # Convert target dates to date objects for comparison
    target_date_set = {d.date() for d in target_dates}
    
    # Filter to target dates
    df_filtered = df[df['date'].isin(target_date_set)].copy()
    
    if df_filtered.empty:
        return {}
    
    # For each member, compute daily average and check threshold
    member_counts = {}
    
    for member in df_filtered['member'].unique():
        member_df = df_filtered[df_filtered['member'] == member]
        
        # Group by date and get daily average (for base interval, there's one value per day anyway)
        daily_avg = member_df.groupby('date')['value_gw'].mean()
        
        if above:
            count = (daily_avg >= threshold_gw).sum()  # Use >= for "above or equal"
        else:
            count = (daily_avg <= threshold_gw).sum()  # Use <= for "below or equal"
        
        member_counts[member] = count
    
    return member_counts


def compute_probability_table(df: pd.DataFrame, target_dates: List[datetime],
                               thresholds: List[float], above: bool = True) -> pd.DataFrame:
    """
    Compute probability table for a set of dates.
    
    Args:
        df: Ensemble forecast data
        target_dates: List of target dates
        thresholds: List of thresholds in GW
        above: If True, compute probability above threshold
        
    Returns:
        DataFrame with thresholds as rows, day counts as columns, values are probabilities
    """
    max_days = len(target_dates)
    
    # Initialize result table
    # Columns: "1 day", "2 days", ..., "N days"
    columns = [f"{i} day{'s' if i > 1 else ''}" for i in range(1, max_days + 1)]
    result = pd.DataFrame(index=thresholds, columns=columns, dtype=float)
    result.index.name = "Threshold (GW)"
    
    for threshold in thresholds:
        member_counts = compute_day_counts_by_member(df, threshold, target_dates, above)
        
        if not member_counts:
            continue
        
        counts = list(member_counts.values())
        n_members = len(counts)
        
        # For each column (1 day, 2 days, etc.), compute probability
        # Probability that at least N days meet the condition
        for n_days in range(1, max_days + 1):
            # Count how many members have >= n_days meeting the condition
            members_meeting = sum(1 for c in counts if c >= n_days)
            probability = members_meeting / n_members * 100  # as percentage
            result.loc[threshold, columns[n_days - 1]] = probability
    
    return result


def get_probability_color(prob: float) -> str:
    """
    Get background color based on probability value (0-100).
    Uses a blue-white-red color scale.
    
    Low probability (0%) = light color
    High probability (100%) = intense color
    """
    if pd.isna(prob):
        return "background-color: #f0f0f0; color: #999;"
    
    # Normalize to 0-1
    norm = prob / 100
    
    # Use a blue color scale for better visibility
    # High probability = darker blue
    # Low probability = lighter blue/white
    
    if norm < 0.1:
        # Very low - light gray
        return f"background-color: #f5f5f5; color: #666;"
    elif norm < 0.25:
        # Low - very light blue
        return f"background-color: #e3f2fd; color: #333;"
    elif norm < 0.50:
        # Medium-low - light blue
        return f"background-color: #bbdefb; color: #333;"
    elif norm < 0.75:
        # Medium-high - medium blue
        return f"background-color: #64b5f6; color: #000;"
    elif norm < 0.90:
        # High - darker blue
        return f"background-color: #1e88e5; color: #fff;"
    else:
        # Very high - deep blue
        return f"background-color: #1565c0; color: #fff;"


def generate_html_table(prob_df: pd.DataFrame, title: str, 
                        is_above: bool, date_range: str) -> str:
    """
    Generate a color-formatted HTML table for the probability data.
    """
    direction = "Above" if is_above else "Below"
    direction_symbol = ">" if is_above else "<"
    
    html = f"""
    <div style="margin-bottom: 30px;">
        <h3 style="margin-bottom: 10px; color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px;">
            {title}
        </h3>
        <p style="font-size: 12px; color: #666; margin-bottom: 10px;">
            Date Range: {date_range} | Direction: Wind {direction_symbol} Threshold
        </p>
        <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; width: 100%;">
            <thead>
                <tr style="background-color: #34495e; color: white;">
                    <th style="text-align: center; padding: 10px;">Threshold<br>(GW)</th>
    """
    
    # Add column headers
    for col in prob_df.columns:
        html += f'<th style="text-align: center; padding: 10px;">{col}</th>'
    
    html += "</tr></thead><tbody>"
    
    # Add data rows
    for threshold, row in prob_df.iterrows():
        html += f'<tr><td style="text-align: center; font-weight: bold; background-color: #ecf0f1;">{threshold}</td>'
        
        for val in row:
            style = get_probability_color(val)
            if pd.isna(val):
                display = "-"
            else:
                display = f"{val:.0f}%"
            html += f'<td style="{style} text-align: center; padding: 8px;">{display}</td>'
        
        html += "</tr>"
    
    html += """
            </tbody>
        </table>
        <p style="font-size: 11px; color: #888; margin-top: 5px;">
            Probability scale: <span style="background-color: #f5f5f5; padding: 2px 5px;">0-10%</span>
            <span style="background-color: #e3f2fd; padding: 2px 5px;">10-25%</span>
            <span style="background-color: #bbdefb; padding: 2px 5px;">25-50%</span>
            <span style="background-color: #64b5f6; padding: 2px 5px;">50-75%</span>
            <span style="background-color: #1e88e5; color: white; padding: 2px 5px;">75-90%</span>
            <span style="background-color: #1565c0; color: white; padding: 2px 5px;">90-100%</span>
        </p>
    </div>
    """
    
    return html


def generate_country_report(client: MetDeskClient, country_name: str, 
                            country_code: str, weekday_dates: List[datetime],
                            weekend_dates: List[datetime],
                            models: List[str],
                            issue: str = None) -> str:
    """
    Generate the full HTML report for a single country.
    """
    print(f"\nProcessing {country_name} ({country_code})...")
    
    # Determine date range for API call
    all_dates = weekday_dates + weekend_dates
    start_date = min(all_dates)
    end_date = max(all_dates)
    
    # Fetch ensemble data
    df = fetch_merged_ensemble_data(client, country_code, start_date, end_date, models, issue=issue)
    
    if df.empty:
        return f"<div class='country-section'><h2>{country_name}</h2><p>No data available</p></div>"
    
    # Format date ranges for display
    weekday_range = f"{min(weekday_dates).strftime('%b %d')} - {max(weekday_dates).strftime('%b %d, %Y')}"
    weekend_range = f"{min(weekend_dates).strftime('%b %d')} - {max(weekend_dates).strftime('%b %d, %Y')}"
    
    # Compute 4 probability tables
    print(f"  Computing weekday above threshold probabilities...")
    weekday_above = compute_probability_table(df, weekday_dates, THRESHOLDS_GW, above=True)
    
    print(f"  Computing weekday below threshold probabilities...")
    weekday_below = compute_probability_table(df, weekday_dates, THRESHOLDS_GW, above=False)
    
    print(f"  Computing weekend above threshold probabilities...")
    weekend_above = compute_probability_table(df, weekend_dates, THRESHOLDS_GW, above=True)
    
    print(f"  Computing weekend below threshold probabilities...")
    weekend_below = compute_probability_table(df, weekend_dates, THRESHOLDS_GW, above=False)
    
    # Generate HTML for country
    html = f"""
    <div class="country-section">
        <h2 style="color: #2c3e50; border-bottom: 3px solid #2c3e50; padding-bottom: 10px; margin-top: 0;">
            {country_name}
        </h2>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div>
                {generate_html_table(weekday_above, "Weekday Wind ABOVE Threshold", True, weekday_range)}
            </div>
            <div>
                {generate_html_table(weekday_below, "Weekday Wind BELOW Threshold", False, weekday_range)}
            </div>
            <div>
                {generate_html_table(weekend_above, "Weekend Wind ABOVE Threshold", True, weekend_range)}
            </div>
            <div>
                {generate_html_table(weekend_below, "Weekend Wind BELOW Threshold", False, weekend_range)}
            </div>
        </div>
    </div>
    """
    
    return html


def main(output_dir: Optional[Path] = None, countries: Optional[Dict[str, str]] = None):
    """
    Generate the wind ensemble probability report.
    
    Args:
        output_dir: Directory to save the HTML report
        countries: Dict of country_name -> country_code (default uses standard EU countries)
    """
    # Default countries
    if countries is None:
        countries = {
            "Germany": "DE",
            "France": "FR",
            "Spain": "ES",
            "UK": "GB_met_emb",
            "Italy": "IT",
        }
    
    # Default output directory
    if output_dir is None:
        output_dir = Path(__file__).parent
    
    print("=" * 60)
    print("Wind Ensemble Probability Report Generator")
    print("=" * 60)
    
    # Initialize client
    client = MetDeskClient()
    
    # Models to use
    MODELS = ["eceps", "ecaifsens"]
    
    # Get next week dates
    weekday_dates, weekend_dates = get_next_week_dates()
    
    print(f"\nNext Week Analysis:")
    print(f"  Weekdays: {[d.strftime('%a %b %d') for d in weekday_dates]}")
    print(f"  Weekend:  {[d.strftime('%a %b %d') for d in weekend_dates]}")
    print(f"  Thresholds: {THRESHOLDS_GW} GW")
    print(f"  Models: {MODELS}")
    
    # Get common 00Z issue
    common_issues = None
    for m in MODELS:
        issues = client.get_issues(m)
        issues_00z = {i for i in issues if 'T00:00:00Z' in i}
        if common_issues is None:
            common_issues = issues_00z
        else:
            common_issues &= issues_00z
            
    if not common_issues:
        print("ERROR: No common 00Z issues found for models")
        return None
        
    issue = sorted(list(common_issues))[-1]
    print(f"  Using common issue: {issue}")
    
    # Build HTML report
    report_date = datetime.now().strftime("%Y-%m-%d")
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Wind Ensemble Probability Report - {report_date}</title>
        <style>
            body {{
                font-family: 'Segoe UI', Arial, sans-serif;
                margin: 20px;
                background-color: #fafafa;
                color: #333;
            }}
            .report-header {{
                text-align: center;
                margin-bottom: 30px;
                padding: 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border-radius: 10px;
            }}
            .report-header h1 {{
                margin: 0 0 10px 0;
                font-size: 28px;
            }}
            .report-header p {{
                margin: 5px 0;
                opacity: 0.9;
            }}
            .country-section {{
                margin-bottom: 50px;
                padding: 20px;
                background: white;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }}
            .legend {{
                margin: 20px 0;
                padding: 15px;
                background: #f8f9fa;
                border-radius: 5px;
                font-size: 13px;
            }}
        </style>
    </head>
    <body>
        <div class="report-header">
            <h1>Wind Ensemble Probability Report</h1>
            <p>Models: {", ".join([m.upper() for m in MODELS])} | Issue: {issue}</p>
            <p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")}</p>
            <p>Analysis Period: Next Week ({weekday_dates[0].strftime('%b %d')} - {weekend_dates[-1].strftime('%b %d, %Y')})</p>
        </div>
        
        <div class="legend">
            <strong>How to read these tables:</strong><br>
            Each cell shows the probability (%) that N days have wind generation above/below the threshold.<br>
            For example, if "3 days" column at "20 GW" row shows "60%", it means 60% of ensemble members 
            predict at least 3 days with wind generation above/below 20 GW.
        </div>
    """
    
    # Generate report for each country
    for country_name, country_code in countries.items():
        html += generate_country_report(client, country_name, country_code, 
                                        weekday_dates, weekend_dates, MODELS, issue=issue)
    
    html += """
    </body>
    </html>
    """
    
    # Save report
    output_file = output_dir / f"wind_ensemble_probability_report.html"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)
    
    print(f"\n{'=' * 60}")
    print(f"Report saved to: {output_file}")
    print(f"{'=' * 60}")
    
    return output_file


if __name__ == "__main__":
    main()

