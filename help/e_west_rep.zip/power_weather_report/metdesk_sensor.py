"""
MetDesk Issue Sensor - Monitors for new model runs and sends Teams notifications.

This sensor polls the MetDesk API for new issues (model runs) and sends
a Microsoft Teams notification when new data is available.

Models monitored:
- EC-ENS (eceps)
- EC-AIFS-ENS (ecaifsens)  
- GFS-ENS (gfsens)
- EC-Extended (ec46)
"""

import os
import json
import requests
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List

# Use corelib for environment config
from jain_commods.core.util.dagster.config import (
    get_teams_webhook_url,
    get_environment,
)

# MetDesk API endpoints
CWG_API_URL = "https://api.metdesk.com/get/metdesk/cwg/v2"
POWER_API_URL = "https://api.metdesk.com/get/metdesk/powergen/v2"

# Models to monitor
MONITORED_MODELS = {
    "eceps": "EC-ENS",
    "ecaifsens": "EC-AIFS-ENS", 
    "gfsens": "GFS-ENS",
    "ec46": "EC-Extended"
}


class MetDeskIssueMonitor:
    """Monitor MetDesk API for new model issues."""
    
    def __init__(self, api_key: Optional[str] = None, state_file: Optional[Path] = None):
        self.api_key = api_key or os.getenv("METDESK_API_KEY")
        self.state_file = state_file or Path(__file__).parent / "data" / ".metdesk_sensor_state.json"
        self.state_file.parent.mkdir(exist_ok=True)
        
    def _get_headers(self) -> Dict:
        return {
            "Accept": "application/json",
            "Authorization": self.api_key
        }
    
    def get_latest_issues(self, api_url: str, model: str) -> List[str]:
        """Fetch available issues for a model."""
        try:
            url = f"{api_url}/issues"
            params = {"model": model}
            response = requests.get(url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            data = response.json()
            return data.get("data", [])
        except Exception as e:
            print(f"Error fetching issues for {model}: {e}")
            return []
    
    def load_state(self) -> Dict:
        """Load the last seen issues from state file."""
        if self.state_file.exists():
            try:
                with open(self.state_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def save_state(self, state: Dict):
        """Save the current state."""
        with open(self.state_file, 'w') as f:
            json.dump(state, f, indent=2)
    
    def check_for_new_issues(self) -> List[Dict]:
        """
        Check all monitored models for new issues.
        
        Returns list of new issues: [{"model": "eceps", "display_name": "EC-ENS", "issue": "2024-01-01T00:00:00Z"}, ...]
        """
        state = self.load_state()
        new_issues = []
        
        for model_code, display_name in MONITORED_MODELS.items():
            # Check both CWG and PowerGen APIs
            for api_url in [CWG_API_URL, POWER_API_URL]:
                issues = self.get_latest_issues(api_url, model_code)
                
                if not issues:
                    continue
                
                # Get the latest issue
                latest_issue = sorted(issues)[-1]
                
                # Check if we've seen this before
                state_key = f"{model_code}_{api_url}"
                last_seen = state.get(state_key)
                
                if last_seen != latest_issue:
                    new_issues.append({
                        "model": model_code,
                        "display_name": display_name,
                        "issue": latest_issue,
                        "api": "PowerGen" if "powergen" in api_url else "CWG"
                    })
                    state[state_key] = latest_issue
        
        # Save updated state
        self.save_state(state)
        
        return new_issues


def send_teams_notification(webhook_url: str, new_issues: List[Dict]):
    """Send a Microsoft Teams notification about new issues."""
    
    if not new_issues:
        return
    
    # Build the message text
    issues_text = "\n".join([
        f"• {issue['display_name']} ({issue['api']}): {issue['issue']}"
        for issue in new_issues
    ])
    
    message_text = f"🌤️ New MetDesk Model Run Available\n\n{issues_text}\n\nTime: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    # Build facts for the card
    facts = [
        {
            "title": issue['display_name'],
            "value": f"{issue['issue']} ({issue['api']})"
        }
        for issue in new_issues
    ]
    
    # Detect webhook type and format payload accordingly
    if "powerplatform.com" in webhook_url or "logic.azure.com" in webhook_url:
        # Power Automate expects Adaptive Card format
        payload = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.4",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "🌤️ New MetDesk Model Run Available",
                    "weight": "Bolder",
                    "size": "Medium",
                    "wrap": True
                },
                {
                    "type": "TextBlock",
                    "text": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "isSubtle": True,
                    "spacing": "None"
                },
                {
                    "type": "FactSet",
                    "facts": facts
                }
            ]
        }
    else:
        # Classic Teams Incoming Webhook (MessageCard format)
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0076D7",
            "summary": "New MetDesk Model Data Available",
            "sections": [{
                "activityTitle": "🌤️ New MetDesk Model Run Available",
                "activitySubtitle": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "facts": [
                    {"name": issue['display_name'], "value": f"{issue['issue']} ({issue['api']})"}
                    for issue in new_issues
                ],
                "markdown": True
            }]
        }
    
    try:
        response = requests.post(webhook_url, json=payload, timeout=30)
        response.raise_for_status()
        print(f"Teams notification sent successfully")
    except Exception as e:
        print(f"Failed to send Teams notification: {e}")
        print(f"Response: {response.text if 'response' in dir() else 'N/A'}")


def check_and_notify(webhook_url: Optional[str] = None) -> List[Dict]:
    """
    Main entry point - check for new issues and send Teams notification.
    
    Args:
        webhook_url: Teams incoming webhook URL (or uses env-based default)
    
    Returns:
        List of new issues found
    """
    webhook_url = webhook_url or get_teams_webhook_url()
    env = get_environment()
    
    if webhook_url:
        masked = webhook_url[:50] + "..." if len(webhook_url) > 50 else webhook_url
        print(f"[{env.upper()}] Using Teams webhook: {masked}")
    
    monitor = MetDeskIssueMonitor()
    new_issues = monitor.check_for_new_issues()
    
    if new_issues:
        print(f"Found {len(new_issues)} new issue(s):")
        for issue in new_issues:
            print(f"  - {issue['display_name']}: {issue['issue']}")
        
        if webhook_url:
            send_teams_notification(webhook_url, new_issues)
        else:
            print("No TEAMS_WEBHOOK_URL configured - skipping Teams notification")
    else:
        print("No new issues found")
    
    return new_issues


if __name__ == "__main__":
    check_and_notify()

