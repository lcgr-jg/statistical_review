import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from functools import reduce
import io
import base64
import logging
import traceback
import configparser
import platform
import os
from pathlib import Path

# --- Interface Imports ---
from jain_commods.core.interfaces.energyquantified import EQClient
from jain_commods.core.util.emailhelper import send_email

# EQ Curve definitions (correct 15min resolution for forecasts)
GENERATION_FORECAST = {
    "DE": {
        "wind": "DE Wind Power Production MWh/h 15min Forecast",
        "solar": "DE Solar Photovoltaic Production MWh/h 15min Forecast",
    },
    "FR": {
        "wind": "FR Wind Power Production MWh/h 15min Forecast",
        "solar": "FR Solar Photovoltaic Production MWh/h 15min Forecast",
    },
    "ES": {
        "wind": "ES Wind Power Production MWh/h 15min Forecast",
        "solar": "ES Solar Photovoltaic Production MWh/h 15min Forecast",
    },
    "GB": {
        "wind": "GB Wind Power Production MWh/h 15min Forecast",
        "solar": "GB Solar Photovoltaic Production MWh/h 15min Forecast",
    },
}

DEMAND_FORECAST = {
    "DE": "DE Consumption MWh/h 15min Forecast",
    "FR": "FR Consumption MWh/h 15min Forecast",
    "ES": "ES Consumption MWh/h 15min Forecast",
    "GB": "GB Consumption MWh/h 15min Forecast",
}

# --- Configuration ---
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)

# Define Paths and load config
REPORTS_PATH = Path(__file__).parent
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'daily_morning_report.cfg')

# Set EQ API key from config
if config.has_option('API', 'eq_api_key'):
    os.environ['EQ_API_KEY'] = config.get('API', 'eq_api_key')

# Initialize Interfaces
eq = EQClient()

# Logging Setup
log_path = REPORTS_PATH / 'log'
log_path.mkdir(exist_ok=True)
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(
    filename=log_path / f"{stoday}_daily_email.log",
    filemode='a',
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)

# ==============================================================================
# Helper Functions
# ==============================================================================

def fetch_eq_forecast(eq_client, issue_date, release_hour, fuel_type, output_col, area_code, from_datetime):
    """Fetches forecast data from Energy Quantified API."""
    from datetime import time
    
    # Map fuel_type to curve
    if fuel_type == 'PowerDemand':
        curve = DEMAND_FORECAST.get(area_code)
    elif fuel_type == 'Wind':
        curves = GENERATION_FORECAST.get(area_code, {})
        curve = curves.get('wind')
    elif fuel_type == 'PV':
        curves = GENERATION_FORECAST.get(area_code, {})
        curve = curves.get('solar')
    else:
        return pd.DataFrame(columns=['TIMESTAMP', output_col])
    
    if curve is None:
        print(f"  Warning: No curve found for {area_code}/{fuel_type}")
        return pd.DataFrame(columns=['TIMESTAMP', output_col])
    
    try:
        # Build issued_at_latest datetime for the specific run
        issue_datetime = datetime.combine(issue_date, time(hour=int(release_hour)))
        
        # Get forecast issued at or before the specified time
        df = eq_client.get_latest_forecast(
            curve,
            tags='ec',
            issued_at_latest=issue_datetime,
            issued_time_of_day=f"{release_hour}:00",
            time_zone='CET',
            frequency='PT1H'
        )
        
        if df.empty:
            return pd.DataFrame(columns=['TIMESTAMP', output_col])
        
        # Convert index to timezone-naive for comparison
        df_reset = df.reset_index()
        df_reset.columns = ['TIMESTAMP', output_col]
        df_reset['TIMESTAMP'] = pd.to_datetime(df_reset['TIMESTAMP']).dt.tz_localize(None)
        
        # Filter to only include data from today onwards
        df_reset = df_reset[df_reset['TIMESTAMP'] >= from_datetime].copy()
        
        return df_reset
        
    except Exception as e:
        print(f"  Error fetching {area_code}/{fuel_type}: {e}")
        return pd.DataFrame(columns=['TIMESTAMP', output_col])

def create_plot_image(df, country_name, cur_date, cur_run, ref_date, ref_run):
    """Generates the 4-panel plot and returns it as a base64 string for HTML embedding."""
    metrics = ['PowerDemand', 'ResLoad', 'Wind', 'Solar']
    
    # Increase figure height slightly for email readability
    fig, axes = plt.subplots(4, 1, figsize=(10, 12), sharex=True)
    # Add title
    fig.suptitle(f"{country_name} Forecast Delta (ECMWF)\n{cur_date.strftime('%d-%b')} {cur_run}z vs {ref_date.strftime('%d-%b')} {ref_run}z", fontsize=14, fontweight='bold', y=0.96)

    for i, metric in enumerate(metrics):
        ax = axes[i]
        col_name = f'{metric}_Delta'
        
        if col_name not in df.columns or df[col_name].isna().all():
            ax.text(0.5, 0.5, 'No Data', transform=ax.transAxes, ha='center')
            continue

        data = df.dropna(subset=[col_name])
        
        # Add weekend shading
        if not data.empty:
            min_ts = data['TIMESTAMP'].min()
            max_ts = data['TIMESTAMP'].max()
            # Generate all dates in range and find weekends
            current_date_iter = min_ts.normalize()
            while current_date_iter <= max_ts:
                if current_date_iter.dayofweek in [5, 6]:  # Saturday=5, Sunday=6
                    weekend_start = current_date_iter
                    weekend_end = current_date_iter + timedelta(days=1)
                    ax.axvspan(weekend_start, weekend_end, alpha=0.15, color='gray', zorder=0)
                current_date_iter += timedelta(days=1)
        
        # Color Logic: Blue=Good/LowLoad, Red=Bad/HighLoad
        if metric in ['Wind', 'Solar']:
            colors = np.where(data[col_name] >= 0, '#2E86C1', '#C0392B') # Blue for Gain
        else:
            colors = np.where(data[col_name] >= 0, '#C0392B', '#2E86C1') # Red for Higher Load
            
        ax.bar(data['TIMESTAMP'], data[col_name], color=colors, width=0.03, alpha=0.8)
        ax.axhline(0, color='black', linewidth=0.8)
        ax.set_ylabel('MW', fontsize=10)
        ax.set_title(f'{metric} Delta', loc='left', fontsize=11, fontweight='bold', pad=4)
        ax.grid(True, axis='y', linestyle='--', alpha=0.3)
        
        # Format X-axis for readability
        ax.tick_params(axis='x', rotation=0)

    plt.tight_layout(rect=[0, 0.02, 1, 0.94])
    
    # Save to Base64
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', dpi=100)
    plt.close(fig)
    buf.seek(0)
    img_str = base64.b64encode(buf.read()).decode('utf-8')
    return f"data:image/png;base64,{img_str}"

def df_to_html_table(df):
    """Converts a pandas DataFrame to a nice HTML table."""
    if df.empty: return ""
    # Use 0 decimal places for compactness
    return df.to_html(classes='table', float_format="%.0f", index=True, border=0)


def main():
    # ==============================================================================
    # 1. DATE LOGIC
    # ==============================================================================
    now = datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    yesterday = today - timedelta(days=1)

    # Morning report: Today 00z vs Yesterday 00z
    # Script runs daily at 07:20, ECMWF 00z is available ~06:00-07:00 UTC
    cur_date = today
    cur_run = '00'
    ref_date = yesterday
    ref_run = '00'
    report_title = f"Morning Report: {cur_date.strftime('%d-%b')} 00z vs {ref_date.strftime('%d-%b')} 00z"
    print(f"{report_title}")

    # ==============================================================================
    # 2. HTML TEMPLATE
    # ==============================================================================
    html_template_start = """
<!DOCTYPE html>
<html>
<head>
<style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333; background-color: #f4f4f4; margin: 0; padding: 20px; }
    .container { max-width: 1200px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #004d99; padding-bottom: 10px; }
    h1 { color: #004d99; margin: 0; }
    h3 { color: #555; margin-top: 0; }
    
    /* Split Layout */
    .row { display: flex; flex-wrap: wrap; margin: 0 -15px; }
    .col { flex: 50%; padding: 0 15px; box-sizing: border-box; }
    
    @media screen and (max-width: 800px) { .col { flex: 100%; } }

    /* Country Card */
    .card { background: #fff; margin-bottom: 20px; }
    .card-header { background: #e9ecef; padding: 10px; border-radius: 5px 5px 0 0; text-align: center; font-size: 1.2em; font-weight: bold; color: #333; border-top: 4px solid; }
    .de-border { border-top-color: #000; } /* Germany Black */
    .fr-border { border-top-color: #0055A4; } /* France Blue */
    .es-border { border-top-color: #C60B1E; } /* Spain Red */
    .uk-border { border-top-color: #00247D; } /* UK Blue */

    /* Tables */
    .table-container { margin: 5px 0 10px 0; overflow-x: auto; }
    /* Compact Table Styling */
    table { width: 100%; border-collapse: collapse; font-size: 0.7em; } /* Smaller font */
    th { background-color: #f8f9fa; color: #495057; padding: 3px; text-align: center; border-bottom: 2px solid #dee2e6; white-space: nowrap; }
    td { padding: 3px; text-align: right; border-bottom: 1px solid #dee2e6; white-space: nowrap; }
    tr:last-child td { border-bottom: none; }
    
    /* Images */
    .plot-img { width: 100%; height: auto; display: block; border: 1px solid #eee; border-radius: 4px; }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Daily Energy Report</h1>
        <h3>Forecast Analysis (ECMWF)</h3>
        <p style="font-size: 0.9em; color: #777;">Reference: {REF_STR} | Current: {CUR_STR}</p>
    </div>
    
    <div class="row">
"""

    html_template_start = html_template_start.replace("{REF_STR}", f"{ref_date.strftime('%d-%b')} {ref_run}z")
    html_template_start = html_template_start.replace("{CUR_STR}", f"{cur_date.strftime('%d-%b')} {cur_run}z")

    html_content = html_template_start

    # ==============================================================================
    # 3. MAIN PROCESSING LOOP
    # ==============================================================================
    countries = [
        {'code': 'DE', 'name': 'Germany', 'eex_code': 'de', 'css': 'de-border'},
        {'code': 'FR', 'name': 'France', 'eex_code': 'fr', 'css': 'fr-border'},
        {'code': 'ES', 'name': 'Spain', 'eex_code': 'es', 'css': 'es-border'},
        {'code': 'GB', 'name': 'UK', 'eex_code': 'gb', 'css': 'uk-border'}
    ]

    for c in countries:
        print(f"Processing {c['name']}...")

        # --- A. Forecasts ---
        # Retrieve forecast data from Energy Quantified (ECMWF model)
        w_ref = fetch_eq_forecast(eq, ref_date, ref_run, 'Wind', 'Wind_Ref', c['code'], today)
        w_cur = fetch_eq_forecast(eq, cur_date, cur_run, 'Wind', 'Wind_Cur', c['code'], today)
        s_ref = fetch_eq_forecast(eq, ref_date, ref_run, 'PV', 'Solar_Ref', c['code'], today)
        s_cur = fetch_eq_forecast(eq, cur_date, cur_run, 'PV', 'Solar_Cur', c['code'], today)
        d_ref = fetch_eq_forecast(eq, ref_date, ref_run, 'PowerDemand', 'PowerDemand_Ref', c['code'], today)
        d_cur = fetch_eq_forecast(eq, cur_date, cur_run, 'PowerDemand', 'PowerDemand_Cur', c['code'], today)

        dfs = [w_ref, w_cur, s_ref, s_cur, d_ref, d_cur]
        # Filter out empty dataframes before merging
        non_empty_dfs = [df for df in dfs if not df.empty and 'TIMESTAMP' in df.columns]
        
        if not non_empty_dfs:
            print(f"  Warning: No data available for {c['name']}, skipping...")
            continue
            
        full_df = reduce(lambda left, right: pd.merge(left, right, on='TIMESTAMP', how='outer'), non_empty_dfs)
        full_df = full_df.sort_values('TIMESTAMP').reset_index(drop=True)

        if 'PowerDemand_Ref' in full_df.columns and 'Wind_Ref' in full_df.columns and 'Solar_Ref' in full_df.columns:
            full_df['ResLoad_Ref'] = full_df['PowerDemand_Ref'] - full_df['Wind_Ref'] - full_df['Solar_Ref']
        else:
            full_df['ResLoad_Ref'] = np.nan

        if 'PowerDemand_Cur' in full_df.columns and 'Wind_Cur' in full_df.columns and 'Solar_Cur' in full_df.columns:
            full_df['ResLoad_Cur'] = full_df['PowerDemand_Cur'] - full_df['Wind_Cur'] - full_df['Solar_Cur']
        else:
            full_df['ResLoad_Cur'] = np.nan

        for m in ['Wind', 'Solar', 'PowerDemand', 'ResLoad']:
            if f'{m}_Cur' in full_df.columns and f'{m}_Ref' in full_df.columns:
                full_df[f'{m}_Delta'] = full_df[f'{m}_Cur'] - full_df[f'{m}_Ref']

        # --- B. Build HTML Component ---
        
        # 1. Delta Table
        # Calculate daily average of the deltas
        delta_cols = [col for col in full_df.columns if col.endswith('_Delta')]
        if delta_cols:
            daily_deltas = full_df.groupby(full_df['TIMESTAMP'].dt.date)[delta_cols].mean()
            # Rename cols to be cleaner (remove _Delta)
            daily_deltas.columns = [col.replace('_Delta', '') for col in daily_deltas.columns]
            
            # Transpose rows/cols to fit horizon
            daily_deltas = daily_deltas.T
            # Shorten date columns
            daily_deltas.columns = [d.strftime('%d/%m') for d in daily_deltas.columns]
        else:
            daily_deltas = pd.DataFrame()

        # 2. Generate Image
        img_data = create_plot_image(full_df, c['name'], cur_date, cur_run, ref_date, ref_run)
        
        # 3. Add Column to HTML
        html_content += f"""
            <div class="col">
                <div class="card">
                    <div class="card-header {c['css']}">{c['name']} (ECMWF)</div>
                    <div class="table-container">
                        <h4 style="text-align:center; margin: 10px 0 5px 0; color:#555; font-size: 0.9em;">Avg Daily Change (MW)</h4>
                        {df_to_html_table(daily_deltas)}
                    </div>
                    <div>
                        <img src="{img_data}" class="plot-img" alt="{c['name']} Forecast Plot">
                    </div>
                </div>
            </div>
        """

    # Close HTML
    html_content += """
        </div> <div style="text-align: center; margin-top: 20px; color: #999; font-size: 0.8em;">
            Generated automatically by Python Analysis Script
        </div>
    </div> </body>
    </html>
    """
    
    # Write to file
    file_name = "daily_report.html"
    with open(file_name, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"\nSUCCESS: Report generated as '{file_name}'. Open this file in your browser.")

    # ==============================================================================
    # 4. SEND EMAIL
    # ==============================================================================
    email_subject = f"{today.strftime('%Y-%m-%d')} Daily Energy Report ({cur_run}z)"
    
    # Get email recipients from config (loaded at module level)
    receivers = config.get('ReportSettings', 'receivers')
    error_receivers = config.get('ReportSettings', 'error_receivers')

    system_os = platform.system().lower()
    if system_os == 'windows':
         # Overrides for testing on local
         pass

    try:
        logging.info("Sending Daily Energy report email")
        send_email(
            receivers,
            email_subject,
            html_content,
            from_address='eu.gap.reports@jainglobal.com'
        )
        logging.info("Daily report email sent successfully")
        print("Email sent successfully.")

    except Exception:
        logging.error("Failed sending Daily report email")
        tb = traceback.format_exc()
        logging.error(tb)

        send_email(
            error_receivers,
            f"ERROR {email_subject}",
            str(tb)
        )
        print("Error while sending email. Error notification sent.")

if __name__ == "__main__":
    main()
