# %% [markdown]
# # Sunday Email Report - Step by Step Debugger

# %%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from functools import reduce
import io
import base64
import logging
import traceback
import configparser
import platform
import os
from pathlib import Path

# --- Interface Imports ---
from jain_commods.core.interfaces.energyquantified import EQClient
from jain_commods.core.interfaces.snowflake.epexquery import EPEXQuery
from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery
from jain_commods.core.util.emailhelper import send_email

# EQ Curve definitions (correct 15min resolution for forecasts)
GENERATION_FORECAST = {
    "DE": {
        "wind": "DE Wind Power Production MWh/h 15min Forecast",
        "solar": "DE Solar Photovoltaic Production MWh/h 15min Forecast",
    },
    "FR": {
        "wind": "FR Wind Power Production MWh/h 15min Forecast",
        "solar": "FR Solar Photovoltaic Production MWh/h 15min Forecast",
    },
}

DEMAND_FORECAST = {
    "DE": "DE Consumption MWh/h 15min Forecast",
    "FR": "FR Consumption MWh/h 15min Forecast",
}

# --- Configuration ---
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)

# Define Paths and load config
REPORTS_PATH = Path(__file__).parent
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'sunday_email.cfg')

# Set EQ API key from config
if config.has_option('API', 'eq_api_key'):
    os.environ['EQ_API_KEY'] = config.get('API', 'eq_api_key')

# Initialize Interfaces
eq = EQClient()
epex = EPEXQuery()
eex = EEXQuery()

# ==============================================================================
# 1. DATE LOGIC
# ==============================================================================
now = datetime.now()
days_since_sunday = (now.weekday() + 1) % 7
target_date = now - timedelta(days=days_since_sunday)
target_date = target_date.replace(hour=0, minute=0, second=0, microsecond=0)

sunday = target_date
monday = sunday + timedelta(days=1)
ref_date = sunday - timedelta(days=2) # Friday

print(f"Generating Report for Sunday: {sunday.date()}")

# ==============================================================================
# 2. HELPER FUNCTIONS (Data & Plots)
# ==============================================================================
def fetch_eq_forecast(eq_client, issue_date, release_hour, fuel_type, output_col, area_code, from_datetime):
    """Fetches forecast data from Energy Quantified API."""
    from datetime import time
    
    # Map fuel_type to curve
    if fuel_type == 'PowerDemand':
        curve = DEMAND_FORECAST.get(area_code)
    elif fuel_type == 'Wind':
        curves = GENERATION_FORECAST.get(area_code, {})
        curve = curves.get('wind')
    elif fuel_type == 'PV':
        curves = GENERATION_FORECAST.get(area_code, {})
        curve = curves.get('solar')
    else:
        return pd.DataFrame(columns=['TIMESTAMP', output_col])
    
    if curve is None:
        print(f"  Warning: No curve found for {area_code}/{fuel_type}")
        return pd.DataFrame(columns=['TIMESTAMP', output_col])
    
    try:
        # Build issued_at_latest datetime for the specific run
        issue_datetime = datetime.combine(issue_date, time(hour=int(release_hour)))
        
        # Get forecast issued at or before the specified time
        df = eq_client.get_latest_forecast(
            curve,
            tags='ec',
            issued_at_latest=issue_datetime,
            issued_time_of_day=f"{release_hour}:00",
            time_zone='CET',
            frequency='PT1H'
        )
        
        if df.empty:
            return pd.DataFrame(columns=['TIMESTAMP', output_col])
        
        # Convert index to timezone-naive for comparison
        df_reset = df.reset_index()
        df_reset.columns = ['TIMESTAMP', output_col]
        df_reset['TIMESTAMP'] = pd.to_datetime(df_reset['TIMESTAMP']).dt.tz_localize(None)
        
        # Filter to only include data from sunday onwards
        df_reset = df_reset[df_reset['TIMESTAMP'] >= from_datetime].copy()
        
        return df_reset
        
    except Exception as e:
        print(f"  Error fetching {area_code}/{fuel_type}: {e}")
        return pd.DataFrame(columns=['TIMESTAMP', output_col])

def get_eex_settlement(eex_df, target_date):
    if eex_df.empty: return None
    ts = pd.to_datetime(target_date).normalize()
    mask = (eex_df['DELIVERY_START'].dt.normalize() <= ts) & (eex_df['DELIVERY_END'].dt.normalize() >= ts)
    matches = eex_df[mask].copy()
    if matches.empty: return None
    matches['duration'] = matches['DELIVERY_END'] - matches['DELIVERY_START']
    return matches.sort_values('duration').iloc[0]['SETTLEMENT_PRICE']

def create_plot_image(df, country_name):
    """Generates the 4-panel plot and returns it as a base64 string for HTML embedding."""
    metrics = ['PowerDemand', 'ResLoad', 'Wind', 'Solar']
    
    # Increase figure height slightly for email readability
    fig, axes = plt.subplots(4, 1, figsize=(10, 12), sharex=True)
    # Add ECMWF explicit label
    fig.suptitle(f"{country_name} Forecast Delta (ECMWF)\n{sunday.strftime('%d-%b')} 12z vs {ref_date.strftime('%d-%b')} 00z", fontsize=14, fontweight='bold', y=0.96)

    for i, metric in enumerate(metrics):
        ax = axes[i]
        col_name = f'{metric}_Delta'
        
        if col_name not in df.columns or df[col_name].isna().all():
            ax.text(0.5, 0.5, 'No Data', transform=ax.transAxes, ha='center')
            continue

        data = df.dropna(subset=[col_name])
        
        # Color Logic: Blue=Good/LowLoad, Red=Bad/HighLoad
        if metric in ['Wind', 'Solar']:
            colors = np.where(data[col_name] >= 0, '#2E86C1', '#C0392B') # Blue for Gain
        else:
            colors = np.where(data[col_name] >= 0, '#C0392B', '#2E86C1') # Red for Higher Load

        ax.bar(data['TIMESTAMP'], data[col_name], color=colors, width=0.03, alpha=0.8)
        ax.axhline(0, color='black', linewidth=0.8)
        ax.set_ylabel('MW', fontsize=10)
        ax.set_title(f'{metric} Delta', loc='left', fontsize=11, fontweight='bold', pad=4)
        ax.grid(True, axis='y', linestyle='--', alpha=0.3)
        
        # Format X-axis for readability
        ax.tick_params(axis='x', rotation=0)

    plt.tight_layout(rect=[0, 0.02, 1, 0.94])
    
    # Save to Base64
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', dpi=100)
    plt.close(fig)
    buf.seek(0)
    img_str = base64.b64encode(buf.read()).decode('utf-8')
    return f"data:image/png;base64,{img_str}"

# ==============================================================================
# 3. HTML GENERATION HELPERS
# ==============================================================================
def df_to_html_table(df):
    """Converts a pandas DataFrame to a nice HTML table."""
    return df.to_html(classes='table', float_format="%.2f", index=True, border=0)

html_template_start = """
<!DOCTYPE html>
<html>
<head>
<style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333; background-color: #f4f4f4; margin: 0; padding: 20px; }
    .container { max-width: 1200px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #004d99; padding-bottom: 10px; }
    h1 { color: #004d99; margin: 0; }
    h3 { color: #555; margin-top: 0; }
    
    /* Split Layout */
    .row { display: flex; flex-wrap: wrap; margin: 0 -15px; }
    .col { flex: 50%; padding: 0 15px; box-sizing: border-box; }
    
    @media screen and (max-width: 800px) { .col { flex: 100%; } }

    /* Country Card */
    .card { background: #fff; margin-bottom: 20px; }
    .card-header { background: #e9ecef; padding: 10px; border-radius: 5px 5px 0 0; text-align: center; font-size: 1.2em; font-weight: bold; color: #333; border-top: 4px solid; }
    .de-border { border-top-color: #000; } /* Germany Black */
    .fr-border { border-top-color: #0055A4; } /* France Blue */

    /* Tables */
    .table-container { margin: 15px 0; overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; font-size: 0.9em; }
    th { background-color: #f8f9fa; color: #495057; padding: 8px; text-align: right; border-bottom: 2px solid #dee2e6; }
    td { padding: 8px; text-align: right; border-bottom: 1px solid #dee2e6; }
    tr:last-child td { border-bottom: none; }
    
    /* Images */
    .plot-img { width: 100%; height: auto; display: block; border: 1px solid #eee; border-radius: 4px; }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Sunday Energy Report</h1>
        <h3>Forecast & Price Analysis (ECMWF)</h3>
        <p style="font-size: 0.9em; color: #777;">Reference: Fri 00z | Current: Sun 12z</p>
    </div>
    
    <div class="row">
"""

# ==============================================================================
# 4. MAIN PROCESSING LOOP
# ==============================================================================
countries = [
    {'code': 'DE', 'name': 'Germany', 'eex_code': 'de', 'css': 'de-border'},
    {'code': 'FR', 'name': 'France', 'eex_code': 'fr', 'css': 'fr-border'}
]

html_content = html_template_start

for c in countries:
    print(f"Processing {c['name']}...")

    # --- A. Forecasts ---
    # Retrieve forecast data from Energy Quantified (ECMWF model)
    # Sunday 12z vs Friday 00z
    w_ref = fetch_eq_forecast(eq, ref_date, '00', 'Wind', 'Wind_Ref', c['code'], sunday)
    w_cur = fetch_eq_forecast(eq, sunday, '12', 'Wind', 'Wind_Cur', c['code'], sunday)
    s_ref = fetch_eq_forecast(eq, ref_date, '00', 'PV', 'Solar_Ref', c['code'], sunday)
    s_cur = fetch_eq_forecast(eq, sunday, '12', 'PV', 'Solar_Cur', c['code'], sunday)
    d_ref = fetch_eq_forecast(eq, ref_date, '00', 'PowerDemand', 'PowerDemand_Ref', c['code'], sunday)
    d_cur = fetch_eq_forecast(eq, sunday, '12', 'PowerDemand', 'PowerDemand_Cur', c['code'], sunday)

    dfs = [w_ref, w_cur, s_ref, s_cur, d_ref, d_cur]
    # Filter out empty dataframes before merging
    non_empty_dfs = [df for df in dfs if not df.empty and 'TIMESTAMP' in df.columns]
    
    if not non_empty_dfs:
        print(f"  Warning: No data available for {c['name']}, skipping...")
        continue
        
    full_df = reduce(lambda left, right: pd.merge(left, right, on='TIMESTAMP', how='outer'), non_empty_dfs)
    full_df = full_df.sort_values('TIMESTAMP').reset_index(drop=True)

    if 'PowerDemand_Ref' in full_df.columns and 'Wind_Ref' in full_df.columns and 'Solar_Ref' in full_df.columns:
        full_df['ResLoad_Ref'] = full_df['PowerDemand_Ref'] - full_df['Wind_Ref'] - full_df['Solar_Ref']
    else:
        full_df['ResLoad_Ref'] = np.nan

    if 'PowerDemand_Cur' in full_df.columns and 'Wind_Cur' in full_df.columns and 'Solar_Cur' in full_df.columns:
        full_df['ResLoad_Cur'] = full_df['PowerDemand_Cur'] - full_df['Wind_Cur'] - full_df['Solar_Cur']
    else:
        full_df['ResLoad_Cur'] = np.nan

    for m in ['Wind', 'Solar', 'PowerDemand', 'ResLoad']:
        if f'{m}_Cur' in full_df.columns and f'{m}_Ref' in full_df.columns:
            full_df[f'{m}_Delta'] = full_df[f'{m}_Cur'] - full_df[f'{m}_Ref']

    # --- B. Prices ---
    spot = epex.get_spot_prices(country=c['code'], start_date=ref_date, end_date=monday+timedelta(days=1))
    ts = spot['TIMESTAMP']
    if ts.dt.tz is None: ts = ts.dt.tz_localize('UTC')
    spot['DATE_CET'] = ts.dt.tz_convert('Europe/Paris').dt.date
    spot_daily = spot[spot['DATE_CET'].isin([sunday.date(), monday.date()])].groupby('DATE_CET')['PRICE'].mean()

    df_eex = eex.get_strip_prices(country_code=c['eex_code'], trading_day=ref_date)
    if 'PROFILE' in df_eex.columns: df_eex = df_eex[df_eex['PROFILE'] == 'Base']
    df_eex['DELIVERY_START'] = pd.to_datetime(df_eex['DELIVERY_START'], errors='coerce')
    df_eex['DELIVERY_END'] = pd.to_datetime(df_eex['DELIVERY_END'], errors='coerce')
    df_eex = df_eex.dropna(subset=['DELIVERY_START', 'DELIVERY_END'])

    # Price Table
    price_summary = pd.DataFrame(index=['Sunday', 'Monday'])
    # price_summary['Date'] = [sunday.strftime('%Y-%m-%d'), monday.strftime('%Y-%m-%d')]
    price_summary['Spot'] = [spot_daily.get(sunday.date(), np.nan), spot_daily.get(monday.date(), np.nan)]
    price_summary['Fut (Fri)'] = [get_eex_settlement(df_eex, sunday), get_eex_settlement(df_eex, monday)]
    price_summary['Delta'] = price_summary['Spot'] - price_summary['Fut (Fri)']

    # --- C. Build HTML Component ---
    
    # 1. Generate Image
    img_data = create_plot_image(full_df, c['name'])
    
    # 2. Add Column to HTML
    html_content += f"""
        <div class="col">
            <div class="card">
                <div class="card-header {c['css']}">{c['name']} (ECMWF)</div>
                <div class="table-container">
                    {df_to_html_table(price_summary)}
                </div>
                <div>
                    <img src="{img_data}" class="plot-img" alt="{c['name']} Forecast Plot">
                </div>
            </div>
        </div>
    """

# Close HTML
html_content += """
    </div> <div style="text-align: center; margin-top: 20px; color: #999; font-size: 0.8em;">
        Generated automatically by Python Analysis Script
    </div>
</div> </body>
</html>
"""

# Write to file
file_name = "sunday_report.html"
with open(file_name, "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"\nSUCCESS: Report generated as '{file_name}'. Open this file in your browser.")

# ==============================================================================
# 5. EMAIL CONFIG + LOGGING
# ==============================================================================

# Get email recipients from config (loaded at module level)
receivers = config.get('ReportSettings', 'receivers')
error_receivers = config.get('ReportSettings', 'error_receivers')

# Logging setup
log_path = REPORTS_PATH / 'log'
log_path.mkdir(exist_ok=True)

stoday = datetime.now().strftime('%Y%m%d')

logging.basicConfig(
    filename=log_path / f"{stoday}_sunday_email.log",
    filemode='a',
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)

# ==============================================================================
# 6. SEND EMAIL WITH EMBEDDED HTML BODY
# ==============================================================================

email_subject = f"{sunday.strftime('%Y-%m-%d')} Sunday Power / Meteo Report"

try:
    logging.info("Sending Sunday Power/Meteo report email")

    send_email(
        receivers,
        email_subject,
        html_content,
        from_address='eu.gap.reports@jainglobal.com'
    )

    logging.info("Sunday report email sent successfully")
    print("Email sent successfully.")

except Exception:
    logging.error("Failed sending Sunday report email")
    tb = traceback.format_exc()
    logging.error(tb)

    # ERROR EMAIL
    send_email(
        error_receivers,
        f"ERROR {email_subject}",
        str(tb)
    )

    print("Error while sending email. Error notification sent.")
