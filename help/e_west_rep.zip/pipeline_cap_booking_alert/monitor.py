"""Pipeline capacity booking alert.

Every run (15 minutes by default):
  1. Read the pipeline assets from pipeline_cap_booking_alert.cfg.
  2. Ask Commodity Essentials eugascapbookingpath for directional booking
     revisions since the stored watermark (first run: build a baseline).
  3. When a new dateAt is published, pull eugascapbooking for those gas
     dates and email the value changes versus cache/snapshot.parquet.

Add points as extra [Asset:<id>] sections. No code change is required.

Run:  python monitor.py                 one check
      python monitor.py --loop          poll forever (cfg poll_minutes)
      python monitor.py --dry-run       print instead of emailing / writing cache
The Dagster schedule (dagster_defs.py) calls run_once() every 15 minutes.
"""
from __future__ import annotations

import argparse
import configparser
import html
import json
import logging
import platform
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

import pandas as pd

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.util.emailhelper import send_email

logger = logging.getLogger(__name__)

REPORTS_PATH = Path(__file__).parent.resolve()
CACHE_DIR = REPORTS_PATH / "cache"
SNAPSHOT_FILE = CACHE_DIR / "snapshot.parquet"
WATERMARK_FILE = CACHE_DIR / "watermark.json"

FROM_ADDRESS = "eu.gap.reports@jainglobal.com"

# Identity of one booking series on one gas day.
KEY_COLS = [
    "asset_id",
    "gas_date",
    "variable",
    "cap_type",
    "book_status",
    "book_tso",
    "book_direction",
]

SNAPSHOT_COLUMNS = KEY_COLS + [
    "value",
    "date_at",
    "market",
    "asset_name",
    "units",
    "direction_label",
]

# Ignore changes smaller than 0.05 mcm/d. The email shows whole mcm/d.
VALUE_EPS = 0.05
DISPLAY_DECIMALS = 0

# English abbreviations. strftime %b follows the machine locale, and CE
# requires Jan/Feb/... in dateFrom and updateSince.
_MONTHS = (
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
)

_CE_COLUMNS = {
    "assetId": "asset_id",
    "Date": "gas_date",
    "Variable": "variable",
    "Cap.Type": "cap_type",
    "Book.Status": "book_status",
    "Book.TSO": "book_tso",
    "Book.Direction": "book_direction",
    "Value": "value",
    "DateAt": "date_at",
    "Market": "market",
    "assetName": "asset_name",
    "Units": "units",
}


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config() -> configparser.ConfigParser:
    config = configparser.ConfigParser(interpolation=None)
    config.read(REPORTS_PATH / "pipeline_cap_booking_alert.cfg")
    return config


def get_receivers(config: configparser.ConfigParser) -> tuple[str, str]:
    receivers = config.get("ReportSettings", "receivers")
    error_receivers = config.get("ReportSettings", "error_receivers")
    # override for local debugging/testing, as per hormuz_vessel_monitor
    if platform.system().lower() == "windows":
        receivers = "john.morley@jainglobal.com"
        error_receivers = "john.morley@jainglobal.com"
    return receivers, error_receivers


def load_assets(config: configparser.ConfigParser) -> list[dict]:
    """Each [Asset:<id>] section is one monitored pipeline point."""
    assets: list[dict] = []
    for section in config.sections():
        if not section.startswith("Asset:"):
            continue
        asset_id = section.split(":", 1)[1].strip()
        if not asset_id:
            raise RuntimeError(f"Config section [{section}] is missing an asset id")
        book_dir = config.get(section, "book_dir", fallback="").strip().lower()
        if book_dir not in ("entry", "exit", "exitentry"):
            raise RuntimeError(
                f"[{section}] book_dir must be entry, exit, or exitentry (got {book_dir!r})"
            )
        assets.append({
            "id": asset_id,
            "name": config.get(section, "name").strip(),
            "direction": config.get(section, "direction").strip(),
            "short_direction": config.get(section, "short_direction", fallback="").strip()
            or config.get(section, "direction").strip(),
            "book_dir": book_dir,
            # forwardFlow is the asset's market direction (UA => HU). reverseFlow
            # is the opposite direction and can still be Book.Direction=Entry
            # on the other TSO. Empty means do not filter.
            "variable": config.get(section, "variable", fallback="").strip(),
        })
    if not assets:
        raise RuntimeError("No [Asset:<id>] sections in pipeline_cap_booking_alert.cfg")
    return assets


def _asset_by_id(assets: list[dict]) -> dict[str, dict]:
    return {asset["id"]: asset for asset in assets}


# ---------------------------------------------------------------------------
# Normalise / diff  (pure — unit-tested without the network)
# ---------------------------------------------------------------------------

def empty_frame() -> pd.DataFrame:
    return pd.DataFrame(columns=SNAPSHOT_COLUMNS)


def _as_asset_id(value) -> str:
    if value is None or (isinstance(value, float) and value != value):
        return ""
    try:
        return str(int(value))
    except (TypeError, ValueError):
        return str(value).strip()


def normalize_ce_frame(df: pd.DataFrame | None) -> pd.DataFrame:
    """Map a CE booking/path frame onto the canonical columns."""
    if df is None or df.empty:
        return empty_frame()
    missing = [src for src in ("assetId", "Date", "Value", "DateAt") if src not in df.columns]
    if missing:
        preview = df.head(2).to_string()[:400]
        raise RuntimeError(f"CE frame missing {missing}. Preview: {preview}")

    out = pd.DataFrame(index=df.index)
    for src, dest in _CE_COLUMNS.items():
        if src in df.columns:
            out[dest] = df[src]
        else:
            out[dest] = pd.NA
    out["asset_id"] = out["asset_id"].map(_as_asset_id)
    out["gas_date"] = _parse_ce_dates(out["gas_date"], with_time=False)
    out["date_at"] = _parse_ce_dates(out["date_at"], with_time=True)
    out["value"] = pd.to_numeric(out["value"], errors="coerce")
    for col in ("variable", "cap_type", "book_status", "book_tso", "book_direction", "market", "asset_name", "units"):
        out[col] = out[col].astype("string").fillna("").str.strip()
    out["direction_label"] = pd.NA
    out = out.dropna(subset=["gas_date", "asset_id"])
    out = out[out["asset_id"] != ""]
    return out.reset_index(drop=True)


def filter_book_dir(df: pd.DataFrame, book_dir: str, variable: str = "") -> pd.DataFrame:
    """Keep the configured direction and, when set, the flow variable.

    exitentry means both entry and exit. ``variable`` (forwardFlow /
    reverseFlow) separates the market direction from its reverse: on VIP
    Bereg, entry + forwardFlow is Ukraine to Hungary, while entry +
    reverseFlow is Hungary to Ukraine on the other TSO.
    """
    if df.empty:
        return df
    out = df
    if book_dir != "exitentry":
        out = out.loc[out["book_direction"].str.lower() == book_dir.lower()]
    if variable:
        out = out.loc[out["variable"].str.lower() == variable.lower()]
    return out.reset_index(drop=True)


def latest_per_key(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return empty_frame()
    ordered = df.sort_values(["date_at"], kind="mergesort", na_position="first")
    return ordered.drop_duplicates(KEY_COLS, keep="last").reset_index(drop=True)


def newer_than(path: pd.DataFrame, watermark: pd.Timestamp | None) -> pd.DataFrame:
    """Path rows published strictly after the watermark. None keeps every row."""
    if path is None or path.empty:
        return empty_frame()
    dated = path.dropna(subset=["date_at"])
    if watermark is None:
        return dated.reset_index(drop=True)
    wm = pd.Timestamp(watermark)
    return dated.loc[dated["date_at"] > wm].reset_index(drop=True)


def advance_watermark(
    published: pd.DataFrame,
    previous: pd.Timestamp | None,
) -> pd.Timestamp | None:
    """Move the watermark to the newest dateAt we have now processed."""
    candidates: list[pd.Timestamp] = []
    if previous is not None and not pd.isna(previous):
        candidates.append(pd.Timestamp(previous))
    if published is not None and not published.empty and published["date_at"].notna().any():
        candidates.append(pd.Timestamp(published["date_at"].max()))
    if not candidates:
        return None
    return max(candidates)


def _parse_ce_dates(series: pd.Series, *, with_time: bool) -> pd.Series:
    """Parse CE timestamps (``17-Sep-2026`` or ``04-Feb-2026 12:03``) without locale."""
    text = series.astype("string").str.strip()
    for month_no, name in enumerate(_MONTHS, start=1):
        text = text.str.replace(name, f"{month_no:02d}", regex=False)
    fmt = "%d-%m-%Y %H:%M" if with_time else "%d-%m-%Y"
    return pd.to_datetime(text, format=fmt, errors="coerce")


def format_update_since(watermark: pd.Timestamp) -> str:
    """CE updateSince format, CET, e.g. 24_Sep_2026_0757."""
    ts = pd.Timestamp(watermark)
    return f"{ts.day:02d}_{_MONTHS[ts.month - 1]}_{ts.year}_{ts.hour:02d}{ts.minute:02d}"


def format_ce_date(ts: pd.Timestamp) -> str:
    ts = pd.Timestamp(ts)
    return f"{ts.day:02d}_{_MONTHS[ts.month - 1]}_{ts.year}"


def diff_bookings(
    current: pd.DataFrame,
    snapshot: pd.DataFrame | None,
    published: pd.DataFrame,
) -> pd.DataFrame:
    """Value changes for keys present in ``published``.

    ``current`` (the booking endpoint) wins over the path row when both
    exist. A key with no snapshot value is a new point (previous is null).
    Unchanged values are dropped. ``delta`` is null when there is no previous.
    """
    if published is None or published.empty:
        return empty_frame()
    published = latest_per_key(published)
    parts = [published]
    if current is not None and not current.empty:
        parts.append(latest_per_key(current))
    latest = latest_per_key(pd.concat(parts, ignore_index=True))
    keys = published[KEY_COLS].drop_duplicates()
    latest = keys.merge(latest, on=KEY_COLS, how="left")

    if snapshot is not None and not snapshot.empty:
        prev = latest_per_key(snapshot)[KEY_COLS + ["value"]].rename(columns={"value": "previous"})
        latest = latest.merge(prev, on=KEY_COLS, how="left")
    else:
        latest["previous"] = pd.NA

    latest["new"] = latest["value"]
    latest["delta"] = latest["new"] - latest["previous"]
    has_previous = latest["previous"].notna()
    changed_value = has_previous & (latest["delta"].abs() >= VALUE_EPS)
    new_point = ~has_previous & latest["new"].notna()
    changed = latest.loc[changed_value | new_point].copy()
    changed.loc[~has_previous, "delta"] = pd.NA
    return changed.reset_index(drop=True)


def merge_snapshot(snapshot: pd.DataFrame | None, updates: pd.DataFrame) -> pd.DataFrame:
    """Replace snapshot rows for keys present in ``updates``."""
    if updates is None or updates.empty:
        return snapshot.reset_index(drop=True) if snapshot is not None and not snapshot.empty else empty_frame()
    updates = latest_per_key(updates)
    if snapshot is None or snapshot.empty:
        return updates
    keys = updates[KEY_COLS].drop_duplicates()
    base = snapshot.merge(keys, on=KEY_COLS, how="left", indicator=True)
    base = base.loc[base["_merge"] == "left_only"].drop(columns="_merge")
    return pd.concat([base, updates], ignore_index=True)


def direction_summary(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "no rows"
    def _uniq(col: str) -> str:
        if col not in df.columns:
            return "-"
        vals = sorted({str(v) for v in df[col].dropna().unique() if str(v)})
        return ",".join(vals) or "-"
    return (
        f"rows={len(df)} market={_uniq('market')} variable={_uniq('variable')} "
        f"direction={_uniq('book_direction')} tso={_uniq('book_tso')}"
    )


# ---------------------------------------------------------------------------
# CE pull
# ---------------------------------------------------------------------------

def _ce_client(config: configparser.ConfigParser) -> CElink:
    return CElink(config.get("CEAPI", "user"), config.get("CEAPI", "pass"))


def fetch_booking(
    ce: CElink,
    asset: dict,
    *,
    date_from: pd.Timestamp | None = None,
    date_to: pd.Timestamp | None = None,
) -> pd.DataFrame:
    kwargs = dict(
        assets=asset["id"],
        unit="mcm",
        getDir="true",
        getDateAt="true",
        bookDir=asset["book_dir"],
    )
    if asset.get("variable"):
        kwargs["variable"] = asset["variable"]
    if date_from is not None:
        kwargs["dateFrom"] = format_ce_date(date_from)
    if date_to is not None:
        kwargs["dateTo"] = format_ce_date(date_to)
    raw = ce.eugascapbooking(**kwargs)
    frame = filter_book_dir(normalize_ce_frame(raw), asset["book_dir"], asset.get("variable", ""))
    frame["direction_label"] = asset["direction"]
    if frame["asset_name"].eq("").all() or frame["asset_name"].isna().all():
        frame["asset_name"] = asset["name"]
    return frame


def fetch_path(ce: CElink, asset: dict, update_since: str) -> pd.DataFrame:
    kwargs = dict(
        assets=asset["id"],
        unit="mcm",
        getDir="true",
        bookDir=asset["book_dir"],
        updateSince=update_since,
    )
    if asset.get("variable"):
        kwargs["variable"] = asset["variable"]
    raw = ce.eugascapbookingpath(**kwargs)
    frame = filter_book_dir(normalize_ce_frame(raw), asset["book_dir"], asset.get("variable", ""))
    frame["direction_label"] = asset["direction"]
    if not frame.empty and (frame["asset_name"].eq("").all() or frame["asset_name"].isna().all()):
        frame["asset_name"] = asset["name"]
    return frame


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

def _ensure_cache_dir() -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)


def save_snapshot(df: pd.DataFrame) -> None:
    _ensure_cache_dir()
    out = df.copy()
    for col in SNAPSHOT_COLUMNS:
        if col not in out.columns:
            out[col] = pd.NA
    out = out[SNAPSHOT_COLUMNS]
    try:
        out.to_parquet(SNAPSHOT_FILE, index=False)
    except ImportError:
        out.to_pickle(SNAPSHOT_FILE.with_suffix(".pkl"))


def load_snapshot() -> pd.DataFrame | None:
    pickle_path = SNAPSHOT_FILE.with_suffix(".pkl")
    if SNAPSHOT_FILE.exists():
        df = pd.read_parquet(SNAPSHOT_FILE)
    elif pickle_path.exists():
        df = pd.read_pickle(pickle_path)
    else:
        return None
    if df.empty:
        return df
    df["gas_date"] = pd.to_datetime(df["gas_date"])
    df["date_at"] = pd.to_datetime(df["date_at"])
    df["asset_id"] = df["asset_id"].map(_as_asset_id)
    return df


def load_watermarks() -> dict[str, pd.Timestamp]:
    if not WATERMARK_FILE.exists():
        return {}
    raw = json.loads(WATERMARK_FILE.read_text(encoding="utf-8"))
    out: dict[str, pd.Timestamp] = {}
    for asset_id, text in raw.items():
        if text:
            out[str(asset_id)] = pd.Timestamp(text)
    return out


def save_watermarks(watermarks: dict[str, pd.Timestamp | None]) -> None:
    _ensure_cache_dir()
    payload = {}
    for asset_id, ts in watermarks.items():
        if ts is None or pd.isna(ts):
            continue
        payload[str(asset_id)] = pd.Timestamp(ts).strftime("%Y-%m-%dT%H:%M:%S")
    WATERMARK_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _watermark_from_frame(df: pd.DataFrame) -> pd.Timestamp | None:
    if df is None or df.empty or df["date_at"].isna().all():
        return None
    return pd.Timestamp(df["date_at"].max())


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

def _subject_label(asset: dict) -> str:
    return f"{asset['name']} ({asset['short_direction']})"


def build_subject(changes: pd.DataFrame, assets: list[dict]) -> str:
    by_id = _asset_by_id(assets)
    labels = []
    for asset_id in changes["asset_id"].drop_duplicates():
        asset = by_id.get(str(asset_id))
        labels.append(_subject_label(asset) if asset else str(asset_id))
    n_days = int(changes["gas_date"].nunique())
    day_word = "day" if n_days == 1 else "days"
    return f"Capacity booking: {', '.join(labels)} — {n_days} {day_word} revised"


def _fmt_mcm(value, *, signed: bool = False) -> str:
    number = pd.to_numeric(value, errors="coerce")
    if pd.isna(number):
        return ""
    if signed:
        return f"{float(number):+.{DISPLAY_DECIMALS}f}"
    return f"{float(number):.{DISPLAY_DECIMALS}f}"


def _changes_table_html(changes: pd.DataFrame) -> str:
    """One table per publication. Asset, direction and TSO sit in the heading.

    Several gas days often share one Commodity Essentials publication time,
    so that timestamp is not repeated on every row.
    """
    show = changes.copy()
    show["gas_date"] = pd.to_datetime(show["gas_date"])
    show["date_at"] = pd.to_datetime(show["date_at"])
    show = show.sort_values(
        ["asset_name", "date_at", "gas_date", "cap_type", "book_status"],
        kind="mergesort",
    )
    sections: list[str] = []
    group_cols = ["asset_name", "direction_label", "book_tso", "date_at"]
    for key, group in show.groupby(group_cols, dropna=False, sort=False):
        asset_name, direction, tso, published = key
        published_txt = pd.Timestamp(published).strftime("%d %b %Y %H:%M")
        n_days = int(group["gas_date"].nunique())
        day_word = "gas day" if n_days == 1 else "gas days"
        heading = (
            f"<p style=\"margin:16px 0 6px\">"
            f"<b>{html.escape(str(asset_name))}</b>"
            f" &nbsp;·&nbsp; {html.escape(str(direction))}"
            f" &nbsp;·&nbsp; {html.escape(str(tso))}<br>"
            f"<span style=\"color:#555\">Published {html.escape(published_txt)} CET"
            f" &nbsp;·&nbsp; {n_days} {day_word}</span></p>"
        )
        rows = []
        for i, row in enumerate(group.itertuples(index=False)):
            delta = pd.to_numeric(row.delta, errors="coerce")
            if pd.notna(delta) and float(delta) > 0:
                delta_style = "color:#1b5e20;font-weight:bold"
            elif pd.notna(delta) and float(delta) < 0:
                delta_style = "color:#b71c1c;font-weight:bold"
            else:
                delta_style = ""
            bg = "#f4f7fb" if i % 2 else "#ffffff"
            gas = pd.Timestamp(row.gas_date).strftime("%d %b %Y")
            cells = [
                ("left", gas, ""),
                ("left", html.escape(str(row.cap_type)), ""),
                ("left", html.escape(str(row.book_status)), ""),
                ("right", _fmt_mcm(row.previous), ""),
                ("right", _fmt_mcm(row.new), "font-weight:bold"),
                ("right", _fmt_mcm(row.delta, signed=True), delta_style),
            ]
            tds = "".join(
                f"<td style=\"padding:6px 10px;border-bottom:1px solid #e1e6ee;"
                f"text-align:{align};{extra}\">{text}</td>"
                for align, text, extra in cells
            )
            rows.append(f"<tr style=\"background:{bg}\">{tds}</tr>")
        header = "".join(
            f"<th style=\"background:#1f4e79;color:#ffffff;font-weight:600;"
            f"padding:7px 10px;text-align:{align};border-bottom:1px solid #1f4e79\">{label}</th>"
            for align, label in (
                ("left", "Gas date"),
                ("left", "Capacity"),
                ("left", "Status"),
                ("right", "Previous"),
                ("right", "New"),
                ("right", "Change"),
            )
        )
        table = (
            "<table style=\"border-collapse:collapse;font-family:Calibri,sans-serif;"
            "font-size:14px;border:1px solid #d0d7e2\">"
            f"<thead><tr>{header}</tr></thead><tbody>{''.join(rows)}</tbody></table>"
        )
        sections.append(heading + table)
    return "".join(sections)


def build_email_body(changes: pd.DataFrame, pulled_at: datetime) -> str:
    table_html = _changes_table_html(changes)
    n_days = int(pd.to_datetime(changes["gas_date"]).nunique())
    n_pubs = int(pd.to_datetime(changes["date_at"]).nunique())
    day_word = "gas day" if n_days == 1 else "gas days"
    pub_word = "publication" if n_pubs == 1 else "publications"
    return f"""<html>
<div style="font-family: Calibri, sans-serif; font-size: 14px; color: #222">
<p style="margin:0 0 8px"><b>Pipeline capacity booking update</b><br>
<span style="color:#555">{pulled_at.strftime('%d %b %Y %H:%M')} UK
&nbsp;·&nbsp; {n_pubs} {pub_word}, {n_days} {day_word}
&nbsp;·&nbsp; mcm/d</span>
</p>
{table_html}
<p style="color:#555;margin-top:14px">Change = new - previous.
A blank previous means that gas day was not in the last alert.
One publication often revises several gas days at the same time.</p>
</div>
</html>
"""


# ---------------------------------------------------------------------------
# Main run
# ---------------------------------------------------------------------------

def run_once(*, dry_run: bool = False, log=None) -> dict:
    """One monitor cycle. Returns a summary dict (used by the Dagster asset)."""
    log = log or logger
    config = load_config()
    receivers, _ = get_receivers(config)
    assets = load_assets(config)
    ce = _ce_client(config)

    snapshot = load_snapshot()
    watermarks = load_watermarks()
    first_run = snapshot is None or snapshot.empty
    pulled_at = datetime.now()

    if first_run:
        frames = []
        new_marks: dict[str, pd.Timestamp | None] = {}
        for asset in assets:
            frame = fetch_booking(ce, asset)
            log.info(
                "Baseline %s (%s) book_dir=%s %s",
                asset["id"],
                asset["name"],
                asset["book_dir"],
                direction_summary(frame),
            )
            if frame.empty:
                raise RuntimeError(
                    f"CE returned no directional bookings for asset {asset['id']} "
                    f"({asset['name']}, book_dir={asset['book_dir']})"
                )
            frames.append(frame)
            new_marks[asset["id"]] = _watermark_from_frame(frame)
        baseline = pd.concat(frames, ignore_index=True)
        if not dry_run:
            save_snapshot(latest_per_key(baseline))
            save_watermarks(new_marks)
        log.info("First run - baseline only, no email (%d rows)", len(baseline))
        return {
            "email_sent": False,
            "first_run_baseline": True,
            "changed_rows": 0,
            "changed_days": 0,
            "assets": [asset["id"] for asset in assets],
        }

    change_frames: list[pd.DataFrame] = []
    updates: list[pd.DataFrame] = []
    new_marks = dict(watermarks)
    saw_publication = False
    saw_new_asset = False

    for asset in assets:
        watermark = watermarks.get(asset["id"])
        # An asset added after the first baseline has no watermark. Store its
        # current curve and do not email those rows as brand-new points.
        if watermark is None:
            frame = fetch_booking(ce, asset)
            log.info(
                "New asset %s (%s) book_dir=%s %s - baseline only, no email",
                asset["id"],
                asset["name"],
                asset["book_dir"],
                direction_summary(frame),
            )
            if frame.empty:
                raise RuntimeError(
                    f"CE returned no directional bookings for asset {asset['id']} "
                    f"({asset['name']}, book_dir={asset['book_dir']})"
                )
            updates.append(frame)
            new_marks[asset["id"]] = _watermark_from_frame(frame)
            saw_new_asset = True
            continue
        update_since = format_update_since(watermark)
        path = fetch_path(ce, asset, update_since)
        fresh = newer_than(path, watermark)
        log.info(
            "Path %s (%s) updateSince=%s %s new=%d",
            asset["id"],
            asset["name"],
            update_since,
            direction_summary(path),
            len(fresh),
        )
        if fresh.empty:
            continue
        saw_publication = True
        booking = fetch_booking(
            ce,
            asset,
            date_from=pd.Timestamp(fresh["gas_date"].min()),
            date_to=pd.Timestamp(fresh["gas_date"].max()),
        )
        log.info("Booking refresh %s %s", asset["id"], direction_summary(booking))
        changes = diff_bookings(booking, snapshot, fresh)
        if not changes.empty:
            changes["direction_label"] = asset["direction"]
            if changes["asset_name"].eq("").all() or changes["asset_name"].isna().all():
                changes["asset_name"] = asset["name"]
            change_frames.append(changes)
        updates.append(booking if not booking.empty else latest_per_key(fresh))
        new_marks[asset["id"]] = advance_watermark(
            pd.concat([fresh, booking], ignore_index=True),
            watermark,
        )

    if not saw_publication and not saw_new_asset:
        log.info("No new capacity booking publications - no email")
        return {
            "email_sent": False,
            "first_run_baseline": False,
            "changed_rows": 0,
            "changed_days": 0,
            "assets": [asset["id"] for asset in assets],
        }

    merged = snapshot
    for frame in updates:
        merged = merge_snapshot(merged, frame)

    all_changes = (
        pd.concat(change_frames, ignore_index=True) if change_frames else empty_frame()
    )
    n_rows = len(all_changes)
    n_days = int(all_changes["gas_date"].nunique()) if n_rows else 0

    if n_rows == 0:
        if not dry_run:
            save_snapshot(merged)
            save_watermarks(new_marks)
        if saw_new_asset and not saw_publication:
            log.info("New asset baseline stored, no email")
        else:
            log.info("Publications had no value changes - watermark advanced, no email")
        return {
            "email_sent": False,
            "first_run_baseline": False,
            "changed_rows": 0,
            "changed_days": 0,
            "assets": [asset["id"] for asset in assets],
        }

    subject = build_subject(all_changes, assets)
    body = build_email_body(all_changes, pulled_at)
    if dry_run:
        log.info("[dry-run] would send email to %s: %s", receivers, subject)
        print(subject)
        print(body)
    else:
        send_email(receivers, subject, body, from_address=FROM_ADDRESS)
        save_snapshot(merged)
        save_watermarks(new_marks)
        log.info("Alert email sent to %s: %s", receivers, subject)

    return {
        "email_sent": not dry_run,
        "first_run_baseline": False,
        "changed_rows": n_rows,
        "changed_days": n_days,
        "subject": subject,
        "assets": [asset["id"] for asset in assets],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Pipeline capacity booking alert")
    parser.add_argument("--loop", action="store_true",
                        help="poll forever every [Monitor] poll_minutes")
    parser.add_argument("--interval", type=float, default=None,
                        help="loop interval in minutes (overrides cfg)")
    parser.add_argument("--dry-run", action="store_true",
                        help="do not email or update caches; log what would happen")
    args = parser.parse_args()

    log_path = REPORTS_PATH / "log"
    log_path.mkdir(exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_path / "pipeline_cap_booking_alert.log"),
        ],
    )

    config = load_config()
    _, error_receivers = get_receivers(config)
    interval_min = args.interval or config.getfloat("Monitor", "poll_minutes", fallback=15.0)

    if not args.loop:
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Done: %s", summary)
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            if not args.dry_run:
                send_email(error_receivers, "ERROR Pipeline Capacity Booking Alert", str(tb))
            sys.exit(1)
        return

    logger.info("Looping every %.1f minutes (Ctrl+C to stop)", interval_min)
    in_error_streak = False
    while True:
        started = time.monotonic()
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Cycle done: %s", summary)
            in_error_streak = False
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            if not in_error_streak and not args.dry_run:
                send_email(error_receivers, "ERROR Pipeline Capacity Booking Alert", str(tb))
            in_error_streak = True
        elapsed = time.monotonic() - started
        time.sleep(max(30.0, interval_min * 60 - elapsed))


if __name__ == "__main__":
    main()
