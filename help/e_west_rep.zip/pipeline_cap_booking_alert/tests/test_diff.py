"""Diff and watermark tests for the pipeline capacity booking alert.

Synthetic frames only — no Commodity Essentials calls.

Run from eu_reports: python -m pytest pipeline_cap_booking_alert/tests -q
"""
from __future__ import annotations

import pandas as pd

from datetime import datetime

from pipeline_cap_booking_alert.monitor import (
    advance_watermark,
    build_email_body,
    diff_bookings,
    format_update_since,
    merge_snapshot,
    newer_than,
    normalize_ce_frame,
)


def _row(
    gas_date: str,
    value: float,
    date_at: str,
    *,
    cap_type: str = "Firm",
    book_status: str = "Booked",
    asset_id: str = "2720",
) -> dict:
    return {
        "asset_id": asset_id,
        "gas_date": pd.Timestamp(gas_date),
        "variable": "forwardFlow",
        "cap_type": cap_type,
        "book_status": book_status,
        "book_tso": "FGSZ",
        "book_direction": "Entry",
        "value": value,
        "date_at": pd.Timestamp(date_at),
        "market": "UA => HU",
        "asset_name": "VIP Bereg",
        "units": "mcm/d",
        "direction_label": "Ukraine to Hungary",
    }


def _frame(*rows: dict) -> pd.DataFrame:
    return pd.DataFrame(list(rows))


def test_normalize_ce_frame_parses_dates_and_ids():
    raw = pd.DataFrame([{
        "assetId": 2720,
        "assetName": "VIP Bereg",
        "Variable": "forwardFlow",
        "Date": "24-Sep-2026",
        "Cap.Type": "Firm",
        "Book.Status": "Booked",
        "Book.TSO": "FGSZ",
        "Book.Direction": "Entry",
        "Value": "4.84",
        "DateAt": "24-Sep-2026 07:57",
        "Market": "UA => HU",
        "Units": "mcm/d",
    }])
    out = normalize_ce_frame(raw)
    assert out.loc[0, "asset_id"] == "2720"
    assert out.loc[0, "gas_date"] == pd.Timestamp("2026-09-24")
    assert out.loc[0, "date_at"] == pd.Timestamp("2026-09-24 07:57")
    assert out.loc[0, "value"] == 4.84


def test_value_change_is_reported():
    snapshot = _frame(_row("2026-09-24", 1.48, "2026-09-23 08:00"))
    published = _frame(_row("2026-09-24", 4.84, "2026-09-24 07:57"))
    current = published.copy()
    changes = diff_bookings(current, snapshot, published)
    assert len(changes) == 1
    assert changes.loc[0, "previous"] == 1.48
    assert changes.loc[0, "new"] == 4.84
    assert abs(changes.loc[0, "delta"] - 3.36) < 1e-9


def test_unchanged_republication_is_not_a_change():
    snapshot = _frame(_row("2026-09-24", 4.84, "2026-09-23 08:00"))
    published = _frame(_row("2026-09-24", 4.84, "2026-09-24 07:57"))
    changes = diff_bookings(published, snapshot, published)
    assert changes.empty


def test_new_gas_day_has_blank_previous():
    snapshot = _frame(_row("2026-09-24", 4.84, "2026-09-24 07:57"))
    published = _frame(_row("2026-09-25", 5.10, "2026-09-24 08:10"))
    changes = diff_bookings(published, snapshot, published)
    assert len(changes) == 1
    assert pd.isna(changes.loc[0, "previous"])
    assert pd.isna(changes.loc[0, "delta"])
    assert changes.loc[0, "new"] == 5.10
    assert changes.loc[0, "gas_date"] == pd.Timestamp("2026-09-25")


def test_watermark_ignores_already_seen_date_at_and_advances():
    path = _frame(
        _row("2026-09-24", 4.84, "2026-09-24 07:57"),
        _row("2026-09-25", 5.10, "2026-09-24 08:55"),
    )
    watermark = pd.Timestamp("2026-09-24 07:57")
    fresh = newer_than(path, watermark)
    assert list(fresh["gas_date"]) == [pd.Timestamp("2026-09-25")]
    advanced = advance_watermark(fresh, watermark)
    assert advanced == pd.Timestamp("2026-09-24 08:55")
    assert format_update_since(advanced) == "24_Sep_2026_0855"


def test_email_rounds_to_zero_decimals_and_groups_the_publication():
    changes = _frame(
        _row("2026-09-23", 15.61, "2026-09-24 07:57"),
        _row("2026-09-24", 20.89, "2026-09-24 07:57"),
    )
    changes["previous"] = [12.53, 0.0]
    changes["new"] = [15.61, 20.89]
    changes["delta"] = changes["new"] - changes["previous"]
    body = build_email_body(changes, datetime(2026, 9, 24, 14, 5))
    assert ">16</td>" in body
    assert ">13</td>" in body
    assert ">21</td>" in body
    assert "15.6" not in body
    assert "15.61" not in body
    assert body.count("Published 24 Sep 2026 07:57 CET") == 1


def test_merge_snapshot_replaces_only_updated_keys():
    snapshot = _frame(
        _row("2026-09-24", 1.00, "2026-09-23 08:00"),
        _row("2026-09-25", 2.00, "2026-09-23 08:00"),
    )
    updates = _frame(_row("2026-09-24", 4.84, "2026-09-24 07:57"))
    merged = merge_snapshot(snapshot, updates)
    by_date = merged.set_index("gas_date")["value"]
    assert by_date.loc[pd.Timestamp("2026-09-24")] == 4.84
    assert by_date.loc[pd.Timestamp("2026-09-25")] == 2.00
    assert len(merged) == 2
