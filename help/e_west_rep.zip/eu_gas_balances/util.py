import logging
import time
import pandas as pd
import numpy as np

from datetime import datetime, timedelta, UTC
from dateutil.relativedelta import relativedelta

from jain_commods.core.interfaces.commodityessentials import CommodityEssentials
from jain_commods.core.interfaces.sqldb import DataQuery
from jain_commods.core.util.htmlutils import df2html
from jain_commods.fundamental.gas import util




def generate_report(countries, days_history, days_forward, months_history, months_forward, seasons_history, seasons_forward, ce_stale_check_hrs, scenarios):
    
    
    # Load balance map config    
    balance_map = util.get_balance_map(option='csv', file_name='balance_map.csv')
    
    
    # Define what is our preferred column grouping order for display (assuming level [0,1] aggregation)
    reqd_col_order = [('Demand','LDZ'),
                    ('Demand','CCGT'),
                    ('Demand','Industrial'),
                    ('Demand','Linepack'),
                    ('Demand','NonLDZ'), # TODO: this can be removed once the DE implied process is live
                    ('Demand','Total'),
                    ('Production','NCS'),
                    ('Production','UKCS'),
                    ('Production','Other'),
                    ('Production','Total'),
                    ('Supply','Regas'),
                    ('Supply','Mazara'),
                    ('Supply','Gela'),
                    ('Supply','TAP'),
                    ('Supply','Other pipeline'),
                    ('Supply','Total'),
                    ('Exports','Ireland'),
                    ('Exports','Pirineos'),
                    ('Exports','Total'),
                    ('Storage','Imbalance'),
                    ('Storage','StB'),
                    ('Storage','Storage'),
                    ]

    # Add frequency specific cols
    reqd_col_order_d = reqd_col_order + [('Storage','Stock'),
                                         ('Storage','Capa'),
                                         ('Storage','Fill %'),]
    reqd_col_order_m = reqd_col_order + [('Storage','Stock Start'),
                                         ('Storage','Stock End'),
                                         ('Storage','Capa'),
                                         ('Storage','Fill Start %'),
                                         ('Storage','Fill End %'),]
    
    
    # Set ref dates
    dt_today = datetime.now()
    # DoD be set to 3 on a monday to show vs Friday
    dt_dod = dt_today - timedelta(days=3 if dt_today.weekday()==0 else 1)
    dt_wow = dt_today - timedelta(days=7)
    
    # Process each scenario for each ref_date
    output = {}
    for dt in [dt_today, dt_dod, dt_wow]:
    
        balances = {}
        for scenario in scenarios:

            # Parse config for the required countries & scenario
            balance_items, ids, variables_per_dataid, ids_storage, variables_per_dataid_f = util.parse_config(balance_map, 
                                                                                                              countries=countries, 
                                                                                                              scenario=scenario)
            
            # Get balance data (passing ref_date to determine which forecasts are used)
            start_time = time.time()
            df_balance_raw, df_storages_raw, ref_date = util.get_balance_data(ids, variables_per_dataid, ids_storage, variables_per_dataid_f,start_date=datetime(2024,1,1), ref_date=dt)
            logging.info(f"Got balance items for {scenario} scenario: took {time.time() - start_time:.2f} seconds")
            
            # Produce balance
            balance_dict, df_balance = util.construct_balance(df_balance_raw, balance_items, ref_date)
    
            # Aggregate
            df_balance_agg = df_balance.groupby(level=[0,1], axis=1).sum()
            
            # Add Total for each top level Category (except storage)
            categories = df_balance_agg.columns.get_level_values(0).unique().tolist()
            categories.remove('Storage')
            for category in categories:
                # A total is only needed if there is more than 1 item in this category
                if len(df_balance_agg.loc[:, category].columns)>1:
                    # Select all columns for this category and sum across rows
                    df_balance_agg[(category, 'Total')] = df_balance_agg.loc[:, category].sum(axis=1)
            
            # Calc storage stats
            storage_per_country, df_storage_all = util.process_storage_data(df_storages_raw, balance_items)
    
            # Add storage data to aggregated data for display purposes
            # NOte: this is linked to how many levels we've grouped by above
            # TODO: should this be done in the process_storage_data function?
            df_storage_all.columns = pd.MultiIndex.from_tuples([('Storage',c) for c in df_storage_all.columns])
    
            # Combine balance and storage data
            df_balance_daily = pd.concat([df_balance_agg, df_storage_all], axis=1)
            
            # Take current stock level + daily StB to calculate a forecasted projected stock level and % fil
            df_balance_daily = util.calc_storage_action(df_balance_daily, ref_date)
    
            
            
            ##### Now create aggregated monthly view
            
            now = datetime.now()
            curr_month_start = datetime(now.year, now.month,1)
            
            monthly_df = df_balance_daily.copy()
            
            # Add monthly Stock Start and Stock End for each row (in readiness to resample to Monthly)
            monthly_df[('Storage','Stock Start')] = monthly_df[('Storage','Stock')].resample('MS').first().reindex(monthly_df.index, method='ffill')
            monthly_df[('Storage','Stock End')] = monthly_df[('Storage','Stock')].resample('MS').last().reindex(monthly_df.index, method='ffill')
            
            # Construct monthly (prior months) & truncate accordingly
            df_balance_monthly = monthly_df[monthly_df.index<curr_month_start].resample('MS').mean()
            df_balance_monthly = df_balance_monthly[df_balance_monthly.index>=(curr_month_start-relativedelta(months=months_history))]
            
            # Add MTD and BoM (and MA if noms are published)
            df_balance_monthly_mtd = monthly_df[(monthly_df.index>=curr_month_start) & (monthly_df.index<now)].resample('MS').mean()
            df_balance_monthly_mtd.index = df_balance_monthly_mtd.index.where(df_balance_monthly_mtd.index != pd.Timestamp(curr_month_start), 'MTD')
            
            df_balance_monthly_bom = monthly_df[(monthly_df.index>now) & (monthly_df.index<now+relativedelta(months=months_forward))].resample('MS').mean()
            df_balance_monthly_bom.index = df_balance_monthly_bom.index.where(df_balance_monthly_bom.index != pd.Timestamp(curr_month_start), 'BoM')
            
            df_balance_monthly = pd.concat([df_balance_monthly, df_balance_monthly_mtd, df_balance_monthly_bom])
            
            # Calculate stock fill start/end pc and remove original columns
            df_balance_monthly[('Storage','Fill Start %')] = df_balance_monthly[('Storage','Stock Start')] / df_balance_monthly[('Storage','Capa')]
            df_balance_monthly[('Storage','Fill End %')] = df_balance_monthly[('Storage','Stock End')] / df_balance_monthly[('Storage','Capa')]
            df_balance_monthly = df_balance_monthly.drop([('Storage','Stock'),('Storage','Fill %')], axis=1)
            
            
            # Capture output
            balances[scenario] = {'daily': df_balance_daily,
                                  'monthly': df_balance_monthly,}
            
        output[dt] = balances
        
        
            
    ##### Produce output
    # Notes:
        # We show daily & monthly tables for Basecase only
        # Everything else: show in forecast storage levels
    
    # TODO: df2html needs various updates:
        # handle per column formatting
        # set "," thousand seperator (optional param)
        # allow for date index or date columns
        
    
    
    
    
    # Basecase: get dataframes ready for preparing HTML output
    basecase_d = output[dt_today]['Basecase']['daily']
    basecase_d_dod = basecase_d - output[dt_dod]['Basecase']['daily']
    
    #basecase_d_dod = output[ref_date_dod]['Basecase']['daily']

    
    # Daily: truncate as per params
    basecase_d_display = basecase_d[(basecase_d.index>=datetime.now()-timedelta(days=days_history)) & (basecase_d.index<=datetime.now()+timedelta(days=days_forward))]
    basecase_d_dod_display = basecase_d_dod[(basecase_d_dod.index>=datetime.now()-timedelta(days=days_history)) & (basecase_d_dod.index<=datetime.now()+timedelta(days=days_forward))]
    
    
    # Daily: order columns as per above
    basecase_d_display = basecase_d_display[reqd_col_order_d]
    basecase_d_display.index = pd.to_datetime(basecase_d_display.index)
    basecase_d_dod_display = basecase_d_dod_display[reqd_col_order_d]
    basecase_d_dod_display.index = pd.to_datetime(basecase_d_dod_display.index)
    
    # Daily: given current df2html limitations, we cheat for certain columns and set them as strings
    basecase_d_display[('Storage','Fill %')] = [f'{v:.0%}' for v in basecase_d_display[('Storage','Fill %')].values]
    basecase_d_display[('Storage','Stock')] = [f'{v:,.0f}' for v in basecase_d_display[('Storage','Stock')].values]
    basecase_d_display[('Storage','Capa')] = [f'{v:,.0f}' for v in basecase_d_display[('Storage','Capa')].values]
    basecase_d_dod_display[('Storage','Fill %')] = [f'{v:.0%}' for v in basecase_d_dod_display[('Storage','Fill %')].values]
    basecase_d_dod_display[('Storage','Stock')] = [f'{v:,.0f}' for v in basecase_d_dod_display[('Storage','Stock')].values]
    basecase_d_dod_display[('Storage','Capa')] = [f'{v:,.0f}' for v in basecase_d_dod_display[('Storage','Capa')].values]
   
    # Daily: tidy up nan values (string due to logic above)
    basecase_d_display = basecase_d_display.replace('nan', '')
    basecase_d_display = basecase_d_display.replace('nan%', '')
    
    # Daily: create basecase HTML table
    basecase_d_html = df2html(basecase_d_display, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y', highlight_today=True)      
    basecase_d_dod_html = df2html(basecase_d_dod_display, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y', highlight_today=True)      
            

    scenarios_m_html = ''
    for scenario in scenarios:
        
        # TODO: this is messy/copy & paste/needs tidying up
        
        scenario_m =  output[dt_today][scenario]['monthly']
        scenario_m_dod = scenario_m - output[dt_dod][scenario]['monthly']
        scenario_m_wow = scenario_m - output[dt_wow][scenario]['monthly']
        
        # Monthly: order columns as per above
        scenario_m_display = scenario_m[reqd_col_order_m]
        scenario_m_dod_display = scenario_m_dod[reqd_col_order_m]
        scenario_m_wow_display = scenario_m_wow[reqd_col_order_m]
        
        # Monthly: set display strs
        scenario_m_display[('Storage','Fill Start %')] = [f'{v:.0%}' for v in scenario_m_display[('Storage','Fill Start %')].values]
        scenario_m_display[('Storage','Fill End %')] = [f'{v:.0%}' for v in scenario_m_display[('Storage','Fill End %')].values]
        scenario_m_display[('Storage','Stock Start')] = [f'{v:,.0f}' for v in scenario_m_display[('Storage','Stock Start')].values]
        scenario_m_display[('Storage','Stock End')] = [f'{v:,.0f}' for v in scenario_m_display[('Storage','Stock End')].values]
        scenario_m_display[('Storage','Capa')] = [f'{v:,.0f}' for v in scenario_m_display[('Storage','Capa')].values]
        
        scenario_m_dod_display[('Storage','Fill Start %')] = [f'{v:.0%}' for v in scenario_m_dod_display[('Storage','Fill Start %')].values]
        scenario_m_dod_display[('Storage','Fill End %')] = [f'{v:.0%}' for v in scenario_m_dod_display[('Storage','Fill End %')].values]
        scenario_m_dod_display[('Storage','Stock Start')] = [f'{v:,.0f}' for v in scenario_m_dod_display[('Storage','Stock Start')].values]
        scenario_m_dod_display[('Storage','Stock End')] = [f'{v:,.0f}' for v in scenario_m_dod_display[('Storage','Stock End')].values]
        scenario_m_dod_display[('Storage','Capa')] = [f'{v:,.0f}' for v in scenario_m_dod_display[('Storage','Capa')].values]
        
        scenario_m_wow_display[('Storage','Fill Start %')] = [f'{v:.0%}' for v in scenario_m_wow_display[('Storage','Fill Start %')].values]
        scenario_m_wow_display[('Storage','Fill End %')] = [f'{v:.0%}' for v in scenario_m_wow_display[('Storage','Fill End %')].values]
        scenario_m_wow_display[('Storage','Stock Start')] = [f'{v:,.0f}' for v in scenario_m_wow_display[('Storage','Stock Start')].values]
        scenario_m_wow_display[('Storage','Stock End')] = [f'{v:,.0f}' for v in scenario_m_wow_display[('Storage','Stock End')].values]
        scenario_m_wow_display[('Storage','Capa')] = [f'{v:,.0f}' for v in scenario_m_wow_display[('Storage','Capa')].values]
        
        # Monthly: tidy up nan values (string due to logic above)
        scenario_m_display = scenario_m_display.replace('nan', '')
        scenario_m_display = scenario_m_display.replace('nan%', '')
        
        scenario_m_dod_display = scenario_m_dod_display.replace('nan', '')
        scenario_m_dod_display = scenario_m_dod_display.replace('nan%', '')
        scenario_m_wow_display = scenario_m_wow_display.replace('nan', '')
        scenario_m_wow_display = scenario_m_wow_display.replace('nan%', '')
        
        # Monthly: create HTML 
        scenario_m_html = df2html(scenario_m_display, precision=0, index_dt_format='%b-%y', highlight_specific_row=True, highlight_specific_row_item='MTD')            
        scenario_m_dod_html = df2html(scenario_m_dod_display, precision=0, index_dt_format='%b-%y', highlight_specific_row=True, highlight_specific_row_item='MTD')       
        scenario_m_wow_html = df2html(scenario_m_wow_display, precision=0, index_dt_format='%b-%y', highlight_specific_row=True, highlight_specific_row_item='MTD')       
            
        scenarios_m_html = scenarios_m_html + f"""<br><hr><br>
                                                  <b><u>EU Balance {scenario} (monthly):</u></b>
                                                  <br>
                                                  {scenario_m_html}
                                                  <br>
                                                  <b><u>EU Balance {scenario} (monthly: DoD):</u></b>
                                                  {scenario_m_dod_html}
                                                  <br>
                                                  <b><u>EU Balance {scenario} (monthly: WoW):</u></b>
                                                  {scenario_m_wow_html}
                                                  """
        
    
    # Construct summary table of storage carry outs
    eu_targets = {datetime(2025,3,1): 0,
                  datetime(2025,4,1): 0.26,
                  datetime(2025,6,1): 0.45,
                  datetime(2025,8,1): 0.72,
                  datetime(2025,10,1): 0.9,
                  datetime(2026,3,1): 0,
                  datetime(2026,10,1): 0,
                  }
    eu_targets_derived = {datetime(2025,3,1): 0,
                          datetime(2025,4,1): 0.19,
                          datetime(2025,6,1): 0.37,
                          datetime(2025,8,1): 0.64,
                          datetime(2025,10,1): 0.81,
                          datetime(2026,3,1): 0,
                          datetime(2026,10,1): 0,
                          }
    
    eu_target_cols = ['EU Target', 'EU Derived Target']
    carry_outs_all = {}
    for fcast_dt in [dt_today, dt_dod, dt_wow]:
        stock_pc={}
        for dt in eu_targets.keys():
            values = []
            for scenario in scenarios:
                # values.append(output[dt_today][scenario]['monthly'].loc[dt,('Storage','Fill End %')])
                values.append(output[fcast_dt][scenario]['daily'].loc[dt + pd.offsets.MonthEnd(1),('Storage','Fill %')])
                
            stock_pc[dt] = values + [eu_targets[dt], eu_targets_derived[dt]]
            
        carry_outs = pd.DataFrame.from_dict(stock_pc, orient='index')
    
        carry_outs.index = [f"End {i.strftime('%b-%y')}" for i in carry_outs.index]
        carry_outs.columns = scenarios + ['EU Target', 'EU Derived Target']
    
        carry_outs_all[fcast_dt] = carry_outs
    
    carry_outs_today = carry_outs_all[dt_today]
    carry_outs_dod = carry_outs_all[dt_today] - carry_outs_all[dt_dod]
    carry_outs_wow = carry_outs_all[dt_today] - carry_outs_all[dt_wow]
    
    # Replace zeros with "-" in the EU target cols
    carry_outs_today[eu_target_cols] = carry_outs_today[eu_target_cols].replace(0,'-')
    
    # Tidy up number format 
    for c in carry_outs_today.columns:
         carry_outs_today[c] = [f'{v:.0%}' if isinstance(v,float) else v for v in carry_outs_today[c].values]
         carry_outs_dod[c] = [f'{v:+.0%}' if isinstance(v,float) else v for v in carry_outs_dod[c].values]
         carry_outs_wow[c] = [f'{v:+.0%}' if isinstance(v,float) else v for v in carry_outs_wow[c].values]
    
    display_cols = [c for c in carry_outs_dod.columns if c not in eu_target_cols]
    
    # Produce HTML tables
    carry_outs_today_html = df2html(carry_outs_today)        
    carry_outs_dod_html = df2html(carry_outs_dod[display_cols])        
    carry_outs_wow_html = df2html(carry_outs_wow[display_cols])        
    
    
    # Get details of last CE snapshot
    ce = CommodityEssentials(logintype='prod')
    ce_snapshot = ce.get_log_entry('eugasseriesbulk')
    ce_saved_date_utc = ce_snapshot['saved_date_utc']
    
    # Check if CE data is stale
    hours_diff = (datetime.now(UTC).replace(tzinfo=None) - ce_saved_date_utc).total_seconds() / 3600
    
    # CE data has gone stale, add a warning message to the email
    ce_timestamp_prefix = '<b>stale</b>' if hours_diff > ce_stale_check_hrs else 'latest'
    ce_stale_warning_message = f"<br><p style='color:red;'><u><b>!!!WARNING!!!</b> Commodity Essentials data appears to be stale! Latest available snapshot is <b>{ce_saved_date_utc.strftime('%H:%M%p %d-%b')}</b> which is more than {ce_stale_check_hrs} hours old.</u></p><br>" if hours_diff > ce_stale_check_hrs else ''
    
    # Get EA and Platts forecast dates wrt to the ref_dates above
    forecasts_used = {}
    for provider in ['EA','Platts']:
        forecasts_used[provider] = get_provider_forecast_dt(provider, [dt_today, dt_dod, dt_wow])
        
    # Construct tables of dates
    provider_forecasts = pd.DataFrame(forecasts_used)
    provider_forecasts.index = [f"D{(dt_today-dt).days} ({pd.to_datetime(dt).strftime('%d %b')})" for dt in provider_forecasts.index]
    
    provider_forecasts['EA'] = [pd.to_datetime(dt).strftime('%d %b') for dt in provider_forecasts['EA'].values]
    provider_forecasts['Platts'] = [pd.to_datetime(dt).strftime('%d %b') for dt in provider_forecasts['Platts'].values]
    
    provider_forecasts_html = df2html(provider_forecasts)

    
    # Construct list of Supply->Other pipeline mapping
    # other_pipeline_html = ''
    # for c in countries:
        
    #     # Get ALL items for this country
    #     all_items = balance_map.loc[(balance_map.GeographyFrom == c) | (balance_map.GeographyTo == c)].copy() 
        
    #     # Get all "Supply->Other pipeline" items for this country
    #     other_pipeline = all_items.loc[all_items.SubCategory == 'Other pipeline'].sort_values('Name')
        
    #     # Construct html output
    #     country_html = ''
    #     for n in other_pipeline.Name.values:
    #         item = other_pipeline.loc[other_pipeline.Name==n].iloc[0]
    #         country_html = country_html + f"<br>{item['Name']} ({item['GeographyFrom']}->{item['GeographyTo']})"
        
    #     other_pipeline_html = other_pipeline_html + f"<br><b>{c}</b>{country_html}<br>"
    
    # Create final email body HTML
    email_body = f"""
                    {ce_stale_warning_message}
                    <b><u>Notes:</u></b>
                    <br>See email footer for more notes.
                    <br>Basecase Scenario = Jain forecasts (regas, LDZ ECENS + EC46, CCGT ECENS) + Platts (NCS) + Energy Aspects (everything else).
                    <br>Forecast comparisons: DoD = {dt_dod.strftime('%d %b')}, WoW = {dt_wow.strftime('%d %b')}
                    <br>The following provider forecast dates are being used for the scenarios:
                    {provider_forecasts_html}
                    <br><hr><br>
                    <b><u>Forecast Storage Fills:</u></b><br>
                    <table><tr><td style='vertical-align:top'><b>Today:</b><br>{carry_outs_today_html}</td><td width='15px'></td><td style='vertical-align:top'><b>DoD:</b><br>{carry_outs_dod_html}</td><td style='vertical-align:top'><b>WoW:</b><br>{carry_outs_wow_html}</td></tr></table>
                    <hr><br>
                    <b><u>EU Balance Basecase (daily):</u></b>
                    <br>
                    {basecase_d_html}
                    <br>
                    <b><u>EU Balance Basecase (daily: DoD):</u></b>
                    {basecase_d_dod_html}
                    <br>
                    {scenarios_m_html}
                    <br><hr><br>
                    <b><u>Notes (continued):</u></b>
                    <br>Our EU perimeter is defined as {','.join(countries)}
                    <br>NWE is a "dummy" country and used for displaying aggregated timeseries into our perimeter (such NCS forecast from EA).
                    <br>Current display params (history/forward): Days {days_history}/{days_forward}, Months {months_history}/{months_forward}, Seasons {seasons_history}/{seasons_forward}
                    <br>In the daily views, T0 shows nominations where available.
                    <br>StB = "Storage To Balance" and is calculated as net of all supply (positive) & demand (negative) elements (excl Storage).
                    <br>"Storage" is the actual observed storage action with "Imbalance" being the difference vs StB.
                    <br>Storage data is subject to 1-2 day lag (so T-1 is likely to be missing).
                    <br>All historical data is sourced from Commodity Essentials, using {ce_timestamp_prefix} {ce_saved_date_utc.strftime('%H:%M%p %d-%b')} snapshot.
                    <br>German NonLDZ demand: data is published as a single aggregated value until Kpler Power feed is live (hence "NonLDZ" value below).
                    <br>NCS: total may look low but <i>excludes</i> flows to DK (eg Nybro) which is typically ~25 of 29mcm/d capa.
                    <br>All units are mcm/d.
                """    
    
    
    return email_body
            


def get_provider_forecast_dt(provider, ref_dates):
    
    # Quick function to get latest available forecast date wrt to the supplied ref_date
    dq = DataQuery(logintype='prod')
    
    # TODO: this is a bit dangerous! (as hard coded IDs used below)
    if provider=='EA':
        did = 2524 # UK LDZ forecast
    elif provider=='Platts':
        did = 2951 # UK LDZ forecast
    
    # Get all instances
    instances = dq.get_instances(did, 'eu_data_datavalue')
    
    # Filter using the ref_date
    res = {}
    for ref_date in ref_dates:
        latest_instance = max(instances[instances.report_date<=ref_date].report_date.values)
        res[ref_date] = latest_instance
           
    return res


