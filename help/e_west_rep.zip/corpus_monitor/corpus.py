# Corpus Christi monitor to track ramp up progress

import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.fundamental.units import get_conversion_factor,unit_conversion_table

import util


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/corpus_monitor')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'corpus.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
kpler_user = config.get('KplerConfig','user')
kpler_pass = config.get('KplerConfig','pass')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_corpus.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'


now = datetime.now().strftime('%d %b')
email_subject = f"Corpus Christi LNG Exports Monitor {now}"


try:

    logging.info('Running Corpus monitor...')    
    
    standard_cargo_size_mcm = 90
    
    # Get conversion factors
    conv_lng_mcm = get_conversion_factor('cu m','mcm',unit_conversion_table)
    conv_bcf_mcm = get_conversion_factor('bcf/d','mcm',unit_conversion_table)
    conv_m_mt_mcm = get_conversion_factor('m mt','mcm',unit_conversion_table)
    
    # Load latest EA and Platts snapshots
    # TODO: this should be live (so we could plot previous forecasts)
    # EA: https://my.energyaspects.com/research/global-lng/data/natural-gas-lng-global-country-balances (see "US LNG exports by terminal")
    # Platts: from snowflake:
        # SELECT * FROM SPGICI_GLOBALLNGANALYTICS_SHARE.LNGANALYTICSV2.SUPPLY_FORECAST_CURRENT 
        # WHERE EXPORTPROJECT LIKE '%Corpus%'
        # ORDER BY month
    logging.info('Loading vendor forecasts from CSV')   
    df_vendors = pd.read_csv(REPORTS_PATH /'vendor_forecasts.csv')
    df_vendors['Date'] = pd.to_datetime(df_vendors['Date'], format='%d/%m/%Y')
    df_vendors =  df_vendors.set_index('Date')

    # Get latest feedgas (for all terminals)
    logging.info('Getting feedgas from BBG')   
    feedgas = util.get_feedgas() * -1
    #feedgas_corpus = feedgas[feedgas.index>=datetime(2023,12,1)][['Corpus']]
    feedgas_corpus = feedgas[['Corpus']]
    
    # Get cargoes
    logging.info('querying cargoes from Kpler')   
    df_cargoes = util.get_kpler_cargoes(kpler_user, kpler_pass, conv_lng_mcm, conv_bcf_mcm)
    
    # Create plots
    logging.info('Creating plots & table')   
    plot_feedgas_daily = util.create_plot_feedgas_daily(feedgas_corpus)
    plot_cargoes_weekly = util.create_cargo_plot_weekly(df_cargoes)
    plot_cargoes_monthly = util.create_cargo_plot_monthly(df_cargoes)
    # plot_cargoes_quarterly = util.create_cargo_plot_quaterly(df_cargoes, df_venture_global)
    plot_vendors = util.create_vendor_comparison(df_cargoes, df_vendors, conv_m_mt_mcm, standard_cargo_size_mcm)
    
    plot_feedgas_cargoes = util.create_plot_feedgas_cargoes(feedgas_corpus, df_cargoes)
    
    # Create table of exports
    cargoes_table = util.create_cargoes_html_table(df_cargoes)
    
    # Calculate cal25 stats
    # cal25_mask = df_venture_global.index.str.startswith('2025')
    # vg_forecast_cal25_low = df_venture_global.loc[cal25_mask, 'ForecastLow'].sum()
    # vg_forecast_cal25_high = df_venture_global.loc[cal25_mask, 'ForecastHigh'].sum()
    
    # Construct email body
    email_body = f"""<!DOCTYPE html>
                    <html>
                    <body>
                    {plot_feedgas_daily}
                    <br><hr><br>
                    {plot_feedgas_cargoes}
                    <br><hr><br>
                    
                    <br><hr><br>
                    {plot_cargoes_monthly}
                    <br><hr><br>
                    {plot_cargoes_weekly}
                    <br><hr><br>
                    {plot_vendors}
                    <br>Standard cargo size of {standard_cargo_size_mcm}mcm used for converting vendors forecasts
                    <br>
                    <br><hr><br>
                    {cargoes_table}
                    <br><hr><br>
                    <b><u>Notes:</u></b>
                    <br>Feedgas data is sourced from Bloomberg (GSLIQCCH Index)
                    <br>Cargo data is read direct from Kpler LNG. 
                    <br>Only cargoes on Kpler with status of "Delivered", "In Transit" and "Loading" are considered. "Scheduled" are ignored.
                    <br>Cargo dates are the date the cargo entered the terminal to commence loading.
                    <br>Cargo volumes are based on loaded not discharge values (so exclude boil off).
                    <br>Conversion factor: cu m LNG -> mcm = {conv_lng_mcm}
                    <br>Conversion factor: bcf -> mcm = {conv_bcf_mcm}
                    <br>Standard cargo size: {standard_cargo_size_mcm}mcm
                    </body>
                    </html>
                """ 
    
    send_email(receivers, 
               email_subject, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')

    logging.info('Report sent')


except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))    




    