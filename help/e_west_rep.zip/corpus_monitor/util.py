import json
import requests
import io
import base64
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from matplotlib.ticker import MaxNLocator


from jain_commods.core.interfaces.bloomberg import BBGQuery
from jain_commods.core.util.dateutils import get_quarter


def get_kpler_cargoes(kpler_user, kpler_pass, conv_lng_mcm, conv_bcf_mcm, installation='Corpus Christi', start_date=datetime(2019,11,1)):
    
    base_url = 'https://api-lng.kpler.com/v1/'

    # Get login token
    payload = json.dumps({'email': kpler_user,'password': kpler_pass})
    headers = {'Content-Type': 'application/json'}
    r = requests.post(base_url + 'login', headers=headers, data=payload)
    token = json.loads(r.text)['token']
        

    # Get cargoes
    headers = {'Authorization': token}
    payload = {'startDate': start_date.strftime('%Y-%m-%d'),
               'size': 20000, 
               'columns': 'all',
               'fromInstallations': installation}
    r = requests.get(base_url + 'trades', headers=headers, params=payload)
    df = pd.read_csv(io.StringIO(r.text), delimiter=';', low_memory=False)


    # Tidy up
    df['Start (origin)'] = pd.to_datetime(df['Start (origin)'])
    df['Date (destination)'] = pd.to_datetime(df['Date (destination)'])
    df['Volume (mcm)'] = df['Volume (origin m3)'] * conv_lng_mcm
    df['Volume (bcf)'] = df['Volume (mcm)']/conv_bcf_mcm
    
    # We only want Delivered, In Transit and Loading
    df = df[df['Trade status']!='Scheduled']

    reqd_cols = ['Vessel',
                 'IMO (vessel)',
                 'Id (vessel)',
                 'Start (origin)',
                 'Country (origin)',
                 'Installation origin',
                 'Volume (origin m3)',
                 'Volume (mcm)',
                 'Volume (bcf)',
                 'Trade status',
                 'Date (destination)',
                 'Continent Destination',
                 'Country (destination)', 
                 'Destination',
                 'Eta source (destination)']

    return df[reqd_cols]



def get_feedgas(start_date=datetime(2017,10,1), end_date=datetime.today()):
    
    us_terminals = {'GSLIQCLC Index': 'Calcasieu',
                    'GSLIQCAM Index': 'Cameron',
                    'GSLIQCCH Index': 'Corpus',
                    'GSLIQCOV Index': 'Cove',
                    'GSLIQELB Index': 'Elba',
                    'GSLIQFPT Index': 'Freeport',
                    'GSLIQPLQ Index': 'Plaq',
                    'GSLIQSPI Index': 'Sabine',
                    'GSLIQTOT Index': 'Total',
                    }
    
    bbg_session = BBGQuery(p_on_server=True)
    us_liq = bbg_session.fetch_hist(list(us_terminals.keys()),
                                    ["PX_LAST"],
                                    start_date,
                                    end_date)
    bbg_session._close_session()
    
    # Set column names
    us_liq.columns = [us_terminals[c.replace('_PX_LAST','')] for c in us_liq.columns]
        
    # Tidy up (& convert to bcf)
    us_liq_all = us_liq.sort_index(axis=1)
    us_liq_all.index = pd.to_datetime(us_liq_all.index)
    us_liq_all = us_liq_all/1000/1000
    
    return us_liq_all


def create_plot_feedgas_daily(feedgas_corpus, ma_window=10, months_history=6):
    
    # Capture stats
    max_corpus = feedgas_corpus['Corpus'].max()
    max_date = feedgas_corpus['Corpus'].idxmax()
        
    # Truncate
    df = feedgas_corpus.copy()
    df = df[df.index>=datetime.now()-relativedelta(months=months_history)]
    
    # Set the style
    plt.style.use('seaborn-v0_8-whitegrid')
    sns.set_palette("deep")

    # Create the plot with improved styling
    fig, ax = plt.subplots(figsize=(10, 5))

    # Plot the data with a nicer line
    ax.plot(df.index, df['Corpus'], linewidth=2, color='#3274A1')

    # Add a subtle area fill below the line
    ax.fill_between(df.index, 0, df['Corpus'], alpha=0.2, color='#3274A1')

    # Compute the rolling average
    rolling_avg = df['Corpus'].rolling(window=ma_window).mean()
    ax.plot(df.index, rolling_avg, linewidth=2, color='#E1812C', 
            linestyle='--', label=f'{ma_window}d MA')

    # Customize the plot
    # ax.set_title('Plaquemines Feedgas (bcf/d)', fontsize=16, pad=20)
    ax.set_title(f'Corpus Daily Feedgas {months_history} months history (bcf/d)', fontsize=16, fontweight='bold', pad=20, color='#2c3e50')
    ax.set_ylabel('bcf', labelpad=10, fontsize=12, fontweight='bold')

    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %y'))
    ax.xaxis.set_minor_locator(mdates.MonthLocator())

    # Add grid but make it subtle
    ax.grid(True, linestyle='--', alpha=0.7)

    # Improve y-axis
    ax.yaxis.set_major_locator(MaxNLocator(nbins=10))

    # Add legend
    ax.legend(frameon=True, facecolor='white', framealpha=1, loc='upper left', fontsize=11)

    # # Annotate maximum point
    # ax.annotate(f"Max: {max_corpus:.2f} on {max_date.strftime('%d %b')}", 
    #             xy=(max_date, max_corpus),
    #             xytext=(10, 15), 
    #             textcoords='offset points',
    #             arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=.2'))
    
    # Add text annotations for ATH 
    
    # Add text box with latest values
    text_box = f"""Latest: {df.iloc[-1]['Corpus']:.2f} bcf/d, {rolling_avg.iloc[-1]:.2f} {ma_window}d MA\nATH: {max_corpus:.1f}bcf/d on {max_date.strftime('%d %b-%y')}"""
    
    plt.text(0.02, 0.15, text_box, transform=plt.gca().transAxes, fontsize=11,
             verticalalignment='top', bbox=dict(boxstyle='round,pad=0.5', 
             facecolor='white', 
             edgecolor='grey', 
             alpha=0.7))

    # Tight layout to ensure everything fits nicely
    plt.tight_layout()

    # Show the plot (for testing)
    # plt.show()

    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return f"<img src='data:image/png;base64,{plot_base64}' alt='Feedgas Daily'>"



def create_plot_feedgas_cargoes(feedgas_corpus, df_cargoes, months_history=24):
    
    
    # Make a copy to avoid modifying the original
    data_cargoes = df_cargoes.copy()
    data_feedgas = feedgas_corpus.copy()
    
    start_date = datetime.now() - relativedelta(months=months_history)
    
    # We aggregate to weeks so get the start of the ISO calendar week (Monday)
    iso_week_start = pd.to_datetime(start_date - timedelta(days=start_date.weekday())).normalize()
    
    # Convert the 'Start (origin)' column to datetime
    data_cargoes['Start (origin)'] = pd.to_datetime(data_cargoes['Start (origin)'])
    
    # Just 2025 onwards to remove earlier noise
    data_cargoes = data_cargoes[data_cargoes['Start (origin)']>=iso_week_start]
    
    # Create a week column
    data_cargoes['Year'] = data_cargoes['Start (origin)'].dt.year
    data_cargoes['Week'] = data_cargoes['Start (origin)'].dt.isocalendar().week
    data_cargoes['Year-Week'] = data_cargoes['Year'].astype(str) + "-W" + data_cargoes['Week'].astype(str).str.zfill(2)
    
    # Group by week and calculate count and volume sum
    weekly_cargoes = data_cargoes.groupby('Year-Week').agg(
        vessel_count=('Vessel', 'count'),
        volume_sum=('Volume (mcm)', 'sum'),
        avg_volume=('Volume (mcm)', 'mean')
    ).reset_index()
    
    weekly_cargoes = weekly_cargoes.sort_values('Year-Week')
    
    
    # Create weekly feedgas stats
    
    data_feedgas = data_feedgas[data_feedgas.index>=iso_week_start]
    data_feedgas['Year'] = data_feedgas.index.year
    data_feedgas['Week'] = data_feedgas.index.isocalendar().week
    data_feedgas['Year-Week'] = data_feedgas['Year'].astype(str) + "-W" + data_feedgas['Week'].astype(str).str.zfill(2)
    
    weekly_feedgas = data_feedgas.groupby('Year-Week').agg(
        feedgas_sum=('Corpus', 'sum'),
        feedgas_avg=('Corpus', 'mean')
    ).reset_index()
    
    
    # Combine
    df = pd.concat([weekly_feedgas.set_index('Year-Week')[['feedgas_sum']],weekly_cargoes.set_index('Year-Week')[['vessel_count']]],axis=1)
    # Tidy up
    df['feedgas_sum'] = df['feedgas_sum'].fillna(0)
    # df['bcf/cargo'] = df['feedgas_sum']/df['vessel_count']
    
    df = df.reset_index()
    
    # Remove rows with missing vessel data
    df_clean = df.dropna(subset=['vessel_count']).copy()
    
    # Calculate cargoes per BCF and BCF per cargo
    df_clean['cargoes_per_bcf'] = df_clean['vessel_count'] / df_clean['feedgas_sum']
    df_clean['bcf_per_cargo'] = df_clean['feedgas_sum'] / df_clean['vessel_count']
    
    # Create the final chart with 4-week rolling average
    plt.figure(figsize=(10, 5))
    
    # Calculate 4-week rolling average
    df_clean['rolling_avg_4w'] = df_clean['cargoes_per_bcf'].rolling(window=4, min_periods=1).mean()
    
    # Plot the main data
    x_values = range(len(df_clean))
    plt.plot(x_values, df_clean['cargoes_per_bcf'], marker='o', linewidth=2, markersize=6, 
             color='lightblue', alpha=0.7, label='Weekly Data')
    plt.fill_between(x_values, df_clean['cargoes_per_bcf'], alpha=0.2, color='lightblue')
    
    # Add 4-week rolling average
    plt.plot(x_values, df_clean['rolling_avg_4w'], color='navy', linestyle='-', linewidth=3, 
             label='4wk MA')
    
    # Add text annotations for latest values
    latest_week = df_clean.iloc[-1]['Year-Week']
    latest_cargoes_per_bcf = df_clean.iloc[-1]['cargoes_per_bcf']
    latest_4wk_ma = df_clean.iloc[-1]['rolling_avg_4w']
    
    # Add text box with latest values
    text_box = f"{latest_week}:\n{latest_cargoes_per_bcf:.2f} cargoes/BCF\n{latest_4wk_ma:.2f} 4wk MA"
    
    plt.text(0.02, 0.15, text_box, transform=plt.gca().transAxes, fontsize=11,
             verticalalignment='top', bbox=dict(boxstyle='round,pad=0.5', 
             facecolor='white', 
             edgecolor='grey', 
             alpha=0.7))    
    
    # Formatting
    plt.title(f'Corpus Efficiency: Cargoes per BCF feedgas ({months_history} months history)', fontsize=16, fontweight='bold')
    plt.ylabel('Cargoes/BCF', fontsize=12)
    plt.grid(True, alpha=0.4)
    plt.legend(fontsize=12, loc='upper left')
    plt.xticks(range(0, len(df_clean), 4), 
              [df_clean.iloc[i]['Year-Week'] for i in range(0, len(df_clean), 4)], 
              rotation=45)
    plt.tight_layout()
    # plt.show()
    
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return f"<img src='data:image/png;base64,{plot_base64}' alt='Cargo per BCF'>"

    
    


def create_cargo_plot_weekly(df_cargoes, ma_window=4, months_history=6):
    
    # Make a copy to avoid modifying the original
    data = df_cargoes.copy()
    
    # Convert the 'Start (origin)' column to datetime
    data['Start (origin)'] = pd.to_datetime(data['Start (origin)'])
    
    # Truncate
    data = data[data['Start (origin)']>=pd.to_datetime(datetime.now()-relativedelta(months=months_history)).normalize()]
    
    # Create a week column
    data['Year'] = data['Start (origin)'].dt.year
    data['Week'] = data['Start (origin)'].dt.isocalendar().week
    data['Year-Week'] = data['Year'].astype(str) + "-W" + data['Week'].astype(str).str.zfill(2)
    
    # Group by week and calculate count and volume sum
    weekly_data = data.groupby('Year-Week').agg(
        vessel_count=('Vessel', 'count'),
        volume_sum=('Volume (mcm)', 'sum'),
        avg_volume=('Volume (mcm)', 'mean')
    ).reset_index()
    
    # Sort by year and week to ensure chronological order
    weekly_data = weekly_data.sort_values('Year-Week')
    
    # Calculate 4-week moving averages for smoothing
    weekly_data['volume_ma'] = weekly_data['volume_sum'].rolling(window=ma_window, min_periods=1).mean()
    weekly_data['count_ma'] = weekly_data['vessel_count'].rolling(window=ma_window, min_periods=1).mean()
    
    # Calculate cumulative volume
    weekly_data['cumulative_volume'] = weekly_data['volume_sum'].cumsum()
    
    # Calculate average volume per vessel
    weekly_data['volume_per_vessel'] = weekly_data['volume_sum'] / weekly_data['vessel_count']
    
    # For display, create shorter week labels
    weekly_data['Week_Label'] = weekly_data['Year-Week'].apply(lambda x: x.split('-')[1])
    
    # Destination analysis
    if 'Continent Destination' in data.columns:
        # Create a pivot table for destinations by week
        continent_pivot = pd.pivot_table(
            data, 
            values='Volume (mcm)', 
            index='Year-Week', 
            columns='Continent Destination', 
            aggfunc='sum'
        ).reset_index().fillna(0)
        
        # Merge with weekly data
        weekly_data = pd.merge(weekly_data, continent_pivot, on='Year-Week', how='left')
    
    # Create figure with subplots
    fig = plt.figure(figsize=(10, 8))
    gs = fig.add_gridspec(2, 1, height_ratios=[3, 1])
    
    # Main plot (bars + moving average)
    ax1 = fig.add_subplot(gs[0])
    
    # Data for plotting
    weeks = weekly_data['Week_Label'].tolist()
    vessel_counts = weekly_data['vessel_count'].tolist()
    volumes = weekly_data['volume_sum'].tolist()
    volume_ma = weekly_data['volume_ma'].tolist()
    count_ma = weekly_data['count_ma'].tolist()
    
    # Set position of plot for vessel count (left y-axis)
    x = np.arange(len(weeks))
    width = 0.35
    rects1 = ax1.bar(x - width/2, vessel_counts, width, label='Cargoes', color='#4472C4', alpha=0.7)
    ax1.set_ylabel('Cargoes', fontsize=12, fontweight='bold', color='#4472C4')
    ax1.tick_params(axis='y', labelcolor='#4472C4')
    ax1.set_xticks(np.arange(0, len(weeks), 1))  # Set x-ticks to interval of 1
    
    # Set y-axis tick interval to 1 for vessel count axis
    ax1.yaxis.set_major_locator(plt.MultipleLocator(1))  # Set y-ticks to interval of 1
    
    # Ensure y-axis limits are integers for cleaner appearance
    y_max = max(vessel_counts) + 1  # Add some headroom
    ax1.set_ylim(0, y_max)
    
    # Create second y-axis for volume
    ax2 = ax1.twinx()
    rects2 = ax2.bar(x + width/2, volumes, width, label='Volume (mcm)', color='#70AD47', alpha=0.7)
    ax2.set_ylabel('Volume (mcm)', fontsize=12, fontweight='bold', color='#70AD47')
    ax2.tick_params(axis='y', labelcolor='#70AD47')
    
    # Format y-axis tick labels to show integers only (no decimal places)
    from matplotlib.ticker import FuncFormatter
    ax1.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{int(x)}'))
    ax2.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{int(x)}'))
    
    # Add moving averages
    line1, = ax1.plot(x, count_ma, 'b-', linestyle='--', linewidth=2, label=f'{ma_window}wk MA (cargoes)')
    line2, = ax2.plot(x, volume_ma, 'g-', linestyle='--', linewidth=2, label=f'{ma_window}wk MA (volume)')
    
    # Add trend line for volume
    # line3, = ax2.plot(x, trend_line, 'r--', linewidth=2, label='Volume Trend')
    
    # Add title
    ax1.set_title(f'Corpus Weekly Cargo Exports ({months_history} months history)', fontsize=16, fontweight='bold')
    
    # Create combined legend
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left')
    
    # Add grid for easier reading
    ax1.grid(axis='y', linestyle='--', alpha=0.7)
    ax1.set_xticklabels([])  # Hide x labels on top plot
    
    # Add annotations for the trend
    # slope_percent = slope / weekly_data['volume_sum'].mean() * 100
    # trend_text = f"Trend: {'+' if slope > 0 else ''}{slope:.2f} mcm/week ({'+' if slope > 0 else ''}{slope_percent:.1f}%/week)"
    # ax2.annotate(trend_text, xy=(len(weeks)*0.5, trend_line[-1]),
    #             xytext=(len(weeks)*0.5, trend_line[-1] + 80),
    #             bbox=dict(boxstyle="round,pad=0.3", fc="yellow", alpha=0.3),
    #             ha='center')
    
    # Second subplot - Destination breakdown (if available)
    ax4 = fig.add_subplot(gs[1], sharex=ax1)
    
    # Stacked bar chart for destinations
    europe_data = weekly_data['Europe'].tolist()
    asia_data = weekly_data['Asia'].tolist()
    
    # Create stacked bars
    ax4.bar(x, europe_data, width=0.7, label='Europe', color='#8ECAE6')
    ax4.bar(x, asia_data, width=0.7, bottom=europe_data, label='Asia', color='#FFB703')
    
    ax4.set_ylabel('Vol by Continent (mcm)', fontsize=12, fontweight='bold')
    ax4.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{int(x)}'))
    ax4.legend(loc='upper left')
    
    
    ax4.grid(axis='y', linestyle='--', alpha=0.7)
    # ax4.set_xlabel('Week', fontsize=12)
    ax4.set_xticks(x)
    ax4.set_xticklabels(weeks, rotation=0, ha='center')
    
    # Adjust layout
    fig.tight_layout()
        
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return f"<img src='data:image/png;base64,{plot_base64}' alt='Cargo Weekly'>"



def create_cargo_plot_monthly(df_cargoes, months_history=24):
    
    # Make a copy to avoid modifying the original
    df = df_cargoes.copy()
    
    start_date = pd.to_datetime(datetime.now() - relativedelta(months=months_history)).normalize()
    
    df = df[df['Start (origin)']>=start_date]
    
    # Extract month and year from the datetime
    df['Month-Year'] = df['Start (origin)'].dt.to_period('M')
    
    # Group by month and trade status, count the number of trades
    monthly_status_counts = df.groupby(['Month-Year', 'Trade status']).size().unstack(fill_value=0)
    
    # Calculate the total per month for the cumulative line
    monthly_totals = monthly_status_counts.sum(axis=1)
    # cumulative_totals = monthly_totals.cumsum()
    
    # Create a figure with two y-axes
    fig, ax1 = plt.subplots(figsize=(10, 6))
    # ax2 = ax1.twinx()
    
    # Plot stacked bars
    monthly_status_counts.plot(kind='bar', stacked=True, ax=ax1, width=0.7)
    
    # Plot cumulative line on the secondary y-axis
    # ax2.plot(range(len(cumulative_totals)), cumulative_totals.values, 
    #          color='black', marker='o', linestyle='-', linewidth=2, label='Cumulative Total')
    
    # Convert Period index to datetime for nicer formatting
    if hasattr(monthly_status_counts.index, 'to_timestamp'):
        date_labels = [period.to_timestamp().strftime('%b-%y') for period in monthly_status_counts.index]
    else:
        date_labels = monthly_status_counts.index.astype(str)
    
    # Create labels showing every other month to avoid crowding
    display_labels = []
    for i, label in enumerate(date_labels):
        if i % 2 == 0:  # Show every other label
            display_labels.append(label)
        else:
            display_labels.append('')  # Empty string for hidden labels
    
    
    # Set x-axis labels
    # ax1.set_xticklabels(date_labels, ha='right', fontsize=12)
    ax1.set_xticklabels(display_labels, rotation=0, fontsize=12)
    ax1.set_xlabel('', fontsize=12)
    
    # Set y-axis labels
    ax1.set_ylabel('Cargoes/month', fontsize=12, fontweight='bold')
    # ax2.set_ylabel('Cumulative Total', fontsize=12, fontweight='bold')
    
    # Ensure y-axis starts at 0
    ax1.set_ylim(bottom=0)
    # ax2.set_ylim(bottom=0)
    
    # Add only horizontal grid lines
    ax1.grid(axis='y', linestyle='--', alpha=0.7)
    ax1.grid(axis='x', visible=False)
    # ax2.grid(False)
    
    # Add title
    plt.title(f'Corpus Monthly Cargo Exports ({months_history} months history)', fontsize=16, 
                 fontweight='bold', pad=20, color='#2c3e50')
    
    # Create a legend for the bars (Trade Status)
    bars_legend = ax1.legend(title='Trade Status', loc='upper left', fontsize=11)
    
    # line_legend = ax2.legend(loc='upper left')
    # Position the line legend below the bars legend but still in the plot area
    # Add the cumulative line to the first legend instead of creating a separate one
    # handles, labels = ax2.get_legend_handles_labels()
    # if handles:
    #     # Get the existing legend handles and labels from the first legend
    #     bars_handles, bars_labels = ax1.get_legend_handles_labels()
    #     # Combine the handles and labels
    #     all_handles = bars_handles + handles
    #     all_labels = bars_labels + labels
    #     # Remove the existing legend
    #     bars_legend.remove()
    #     # Create a new combined legend
    #     combined_legend = ax1.legend(all_handles, all_labels, 
    #                                loc='upper left', 
    #                                title=None,
    #                                fontsize=11)
    
    # # Add annotations for the cumulative total values
    # for i, total in enumerate(cumulative_totals):
    #     ax2.annotate(f'{total:,.0f}', 
    #                  xy=(i, total), 
    #                  xytext=(0, 10),
    #                  textcoords='offset points',
    #                  ha='center',
    #                  fontweight='bold',
    #                  fontsize=12)
    
    # Adjust layout to make room for all elements
    plt.tight_layout()
    
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return f"<img src='data:image/png;base64,{plot_base64}' alt='Cargo Monthly'>"
    
    
def create_cargo_plot_quaterly(df_cargoes, df_venture_global):
    
    
    df_vg = df_venture_global.copy()
    
    # Make a copy to avoid modifying the original
    df = df_cargoes.copy()
    
    # Extract month and year from the datetime
    df['year_quarter'] = df['Start (origin)'].dt.to_period('Q')
    
    # Group by quarter
    quarterly_counts = df.groupby('year_quarter').size().reset_index(name='items_count')
    quarterly_counts = quarterly_counts.sort_values('year_quarter')
    quarterly_counts['cumulative_total'] = quarterly_counts['items_count'].cumsum()
    
    # Combine with VG data
    quarterly_counts = quarterly_counts.set_index('year_quarter')
    quarterly_counts.index = [str(idx) for idx in quarterly_counts.index]
    quarterly_combined = pd.concat([quarterly_counts, df_vg], axis=1)
    
    # Fill missing values in items_count with 0 to ensure we can plot forecasts even with no actuals
    quarterly_combined['items_count'] = quarterly_combined['items_count'].fillna(0)
    actual_values = quarterly_combined['items_count']
    
    
    # Calculate implied value for current quarter
    today = pd.Timestamp.now()
    current_q = str(today.to_period('Q'))
    current_cargoes = quarterly_combined.loc[current_q,'items_count']
    current_q_start = get_quarter(today)
    next_q_start = current_q_start + relativedelta(months=3)
    days_into_q = (today - current_q_start).days + 1
    cargo_daily_rate = current_cargoes / days_into_q
    current_q_estimate = (cargo_daily_rate * (next_q_start - current_q_start).days).round(0)
    
    
    # Set up the figure and axis with improved style
    plt.style.use('seaborn-v0_8-whitegrid')
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Define bar width and positions
    bar_width = 0.4
    index = np.arange(len(quarterly_combined))
    
    # Create the actual value bars with better colors
    actual_bars = ax.bar(index, actual_values, bar_width, label='Exported Cargoes', 
                         # color='#3498db', 
                         color='steelblue',
                         alpha=0.8, edgecolor='#2980b9', linewidth=1.5)
    
    # Add value labels to actual bars as integers, but only if there are actual values
    for bar in actual_bars:
        height = bar.get_height()
        if height > 0:  # Only show labels for non-zero values
            ax.text(bar.get_x() + bar.get_width()/2., height + 2,
                    f'{int(height)}', ha='center', va='bottom', fontsize=12, 
                    fontweight='bold', color='#2c3e50')

    # We only display current quarter projection if we a few days into the quarter
    if days_into_q>=5:
        # Add dashed line for current_q_estimate
        if current_q in quarterly_combined.index:
            current_q_index = quarterly_combined.index.get_loc(current_q)
            
            # Plot dashed line for projection
            line_x_start = index[current_q_index] - bar_width/2  
            line_x_end = index[current_q_index] + bar_width/2
            
            # Draw the dashed line
            ax.plot([line_x_start, line_x_end], [current_q_estimate, current_q_estimate], 
                    '--', color='#2980b9', linewidth=2, label=f'{current_q} Projection (using {cargo_daily_rate:.1f} cargoes/d this Q)')
            
            # Add label for the estimated value
            ax.text(index[current_q_index], current_q_estimate+2, 
                    f'{int(current_q_estimate)}', ha='left', va='bottom', 
                    fontsize=12, fontweight='bold', color='#2980b9')
    

    
    # Make sure forecast values are not NaN
    forecast_high = quarterly_combined['ForecastHigh'].fillna(0)
    forecast_low = quarterly_combined['ForecastLow'].fillna(0)
    
    # Add error bars for forecast range
    for i in range(len(quarterly_combined)):
        if pd.notna(quarterly_combined['ForecastLow'].iloc[i]) and pd.notna(quarterly_combined['ForecastHigh'].iloc[i]):
            low_val = quarterly_combined['ForecastLow'].iloc[i]
            high_val = quarterly_combined['ForecastHigh'].iloc[i]
            
            # # Calculate error bar length
            
            mid_val = (low_val + high_val) / 2
            
            # Create the proper yerr structure - needs to be a 2xN array for asymmetric errors
            # For a single point, it's [[bottom_error], [top_error]]
            yerr = np.array([[mid_val - low_val], [high_val - mid_val]])
            
            # Plot the error bar from the middle point with specific lengths
            ax.errorbar(
                index[i] + bar_width, mid_val,
                yerr=yerr,
                fmt='o', color='#c0392b', ecolor='#c0392b',
                capsize=7, capthick=2, markersize=0, elinewidth=2
            )
            
            # Low value label as integer
            ax.text(index[i] + bar_width, low_val - 5, 
                    f'{int(low_val)}', ha='center', va='top', 
                    color='#c0392b', fontweight='bold', fontsize=12)
            
            # High value label as integer
            ax.text(index[i] + bar_width, high_val + 5, 
                    f'{int(high_val)}', ha='center', va='bottom', 
                    color='#c0392b', fontweight='bold', fontsize=12)
    
    # Add a legend entry for forecast
    ax.plot([], [], '-', color='#c0392b', label='VG Forecast Range')
    
    # Add improved labels and title
    #ax.set_xlabel('Quarter', fontsize=12, fontweight='bold', labelpad=10)
    ax.set_ylabel('Cargoes', fontsize=12, fontweight='bold', labelpad=10)
    ax.set_title('Corpus Quarterly Exports vs. Venture Global Forecast Range', fontsize=16, 
                 fontweight='bold', pad=20, color='#2c3e50')
    
    # Improve x-axis
    ax.set_xticks(index + bar_width / 2)
    ax.set_xticklabels(quarterly_combined.index, fontsize=11)
    
    # Improve legend
    ax.legend(loc='upper left', frameon=True, framealpha=0.9, fontsize=11)
    
    # Calculate the maximum y-value for setting y-axis limits
    all_values = np.concatenate([
        actual_values.to_numpy(),
        forecast_high[~forecast_high.isna()].to_numpy(),
        forecast_low[~forecast_low.isna()].to_numpy()
    ])
    y_max = max(all_values) * 1.15
    
    # Add a bit more space at the top for the labels
    plt.ylim(top=y_max)
    
    # Add a subtle grid only on the y-axis for better readability
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    
    # Remove top and right spines for cleaner look
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # Add light background color to highlight the plot area
    ax.set_facecolor('#f8f9fa')
    
    plt.tight_layout()
    # plt.show()
    
        
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()    
    
    
    return f"<img src='data:image/png;base64,{plot_base64}' alt='Cargo Quarterly'>"
    
    

def create_vendor_comparison(df_cargoes, df_vendors, conv_m_mt_mcm, standard_cargo_size_mcm):
    
    
    # Create monthly load volume df
    df = df_cargoes.copy()
    df['Month-Year'] = df['Start (origin)'].dt.to_period('M')
    monthly_df = df.groupby('Month-Year')['Volume (mcm)'].sum().reset_index()
    monthly_df['Month-Year'] = monthly_df['Month-Year'].dt.to_timestamp()
    monthly_df = monthly_df.set_index('Month-Year')
    monthly_df = monthly_df.rename(columns={'Volume (mcm)': 'Loaded Volume (mcm)'})
            
    # Convert vendors data to mcm (source is M MT LNG)
    df_v = df_vendors.copy() * conv_m_mt_mcm
    
    
    # Convert Platts & EA to monthly & combine with VG
    df_combined = pd.concat([df_v, monthly_df], axis=1)
    df_combined = df_combined.resample('QS').sum()
    
    # Truncate
    df_combined = df_combined[(df_combined.index>=datetime(2025,1,1)) & (df_combined.index<datetime(2027,1,1))]
    
    # Create figure and axis
    fig, ax = plt.subplots(figsize=(10, 6))

    # Plot lines for EA and Platts        
    ax.plot(range(len(df_combined)), df_combined['EA (29th Jun)'], marker='o', linestyle='-', color='#6CA692', label='Energy Aspects (29th Jun)')
    # ax.plot(range(len(df_combined)), df_combined['EA (20th May)'], marker='o', linestyle='-', alpha=0.7, color='#6CA692', label='Energy Aspects (20th May)')
    # ax.plot(range(len(df_combined)), df_combined['EA (6th May)'], marker='o', linestyle='-', alpha=0.4, color='#6CA692', label='Energy Aspects (6th May)')
    ax.plot(range(len(df_combined)), df_combined['Platts (23rd Jul)'], marker='s', linestyle='-', color='#7C444F', label='Platts (23rd Jul)')
    # ax.plot(range(len(df_combined)), df_combined['Platts (9th Apr)'], marker='s', linestyle='-', alpha=0.7, color='#7C444F', label='Platts (9th Apr)')

    # Plot bars for Loaded Volume
    ax.bar(range(len(df_combined)), df_combined['Loaded Volume (mcm)'], width=0.4, alpha=0.6, color='steelblue', label='Loaded Volume (actual)')

    # # Shade area between ForecastLow and ForecastHigh
    # mask = ~np.isnan(df_combined['ForecastLow'])
    # ax.fill_between(range(len(df_combined)), df_combined['ForecastLow'], df_combined['ForecastHigh'], 
    #                 where=mask, color='#e9c46a', alpha=0.3)

    # # Plot ForecastLow and ForecastHigh as lines
    # ax.plot(range(len(df_combined)), df_combined['ForecastLow'], linestyle='--', color='#e76f51', alpha=0.7, label='VG Forecast Low')
    # ax.plot(range(len(df_combined)), df_combined['ForecastHigh'], linestyle='--', color='#e76f51', alpha=0.7, label='VG Forecast High')

    # Create quarter labels in the format of Q1-25
    quarter_labels = []
    for date in df_combined.index:
        quarter = (date.month - 1) // 3 + 1
        year = str(date.year)  # Last two digits of the year
        quarter_labels.append(f"{year}Q{quarter}")

    # Set the x-tick positions and labels
    ax.set_xticks(range(len(df_combined)))
    ax.set_xticklabels(quarter_labels, fontsize=12)
    # plt.xticks(rotation=45)

    # Add labels and title
    # ax.set_xlabel('Quarter')
    ax.set_ylabel('mcm', fontsize=12, fontweight='bold')
    ax.set_title('Corpus Vendor Forecast Comparison (total mcm/quarter)', fontsize=16, fontweight='bold', pad=20, color='#2c3e50')

    # Add legend
    ax.legend(loc='best',  fontsize=11)

    # Add grid for better readability
    ax.grid(True, linestyle='--', alpha=0.7)

    # Adjust layout
    plt.tight_layout()

    # Show the plot
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()    
    
    
    return f"<img src='data:image/png;base64,{plot_base64}' alt='Vendor comparison'>"
    
    
    
    
    


def create_cargoes_html_table(df_cargoes, months_history=3):

    df = df_cargoes.copy()

    # Ensure date columns are datetime objects
    df['Start (origin)'] = pd.to_datetime(df['Start (origin)'])
    df['Date (destination)'] = pd.to_datetime(df['Date (destination)'])
    
    df = df[df['Start (origin)']>=pd.to_datetime(datetime.now()-relativedelta(months=months_history)).normalize()]
    
    # Extract year-month for grouping
    df['year_month'] = df['Start (origin)'].dt.strftime('%Y-%m')
    
    # Sort by start date in descending order
    df = df.sort_values('Start (origin)', ascending=False)
    
    # Get unique months in descending order
    months = sorted(df['year_month'].unique(), reverse=True)
    
    # Start with only CSS and a container div
    html = """<style>
    .lng-container {
        width: 900px;
        border: 1px solid #ddd;
        padding: 8px;
        box-shadow: 0 0 5px rgba(0,0,0,0.1);
        background-color: white;
        font-family: Arial, sans-serif;
        font-size: 11px;
        margin: 0 auto;
        line-height: 1.1;
    }
    
    .lng-container h1 {
        font-size: 16px;
        margin: 0 0 6px 0;
        text-align: left;
        padding: 0;
        line-height: 1.2;
    }
    
    .lng-container h2 {
        color: #2c3e50;
        border-bottom: 1px solid #3498db;
        padding: 2px 0;
        margin: 8px 0 2px 0;
        font-size: 13px;
        line-height: 1.1;
    }
    
    .lng-container table {
        border-collapse: collapse;
        width: 100%;
        margin-bottom: 8px;
    }
    
    .lng-container th {
        background-color: #3498db;
        color: white;
        padding: 2px 4px;
        text-align: left;
        position: sticky;
        top: 0;
        font-size: 10px;
        font-weight: bold;
        line-height: 1;
    }
    
    .lng-container td {
        padding: 1px 3px;
        border: 1px solid #ddd;
        font-size: 10px;
        line-height: 1;
    }
    
    .lng-container tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    
    .in-transit {
        background-color: #d4f1f9 !important; /* Light blue for "In Transit" */
    }
    
    .loading {
        background-color: #e8f8c2 !important; /* Light green for "Loading" */
    }
    
    .lng-legend {
        display: flex;
        justify-content: center;
        gap: 15px;
        margin-top: 5px;
        padding: 3px 0;
        border-top: 1px solid #ddd;
        font-size: 10px;
    }
    
    .legend-item {
        display: flex;
        align-items: center;
        height: 12px;
    }
    
    .legend-color {
        display: inline-block;
        width: 10px;
        height: 10px;
        margin-right: 3px;
    }
</style>

<div class="lng-container">
<h1>Corpus Cargo Breakdown (3 months history)</h1>
"""
    
    # Columns to include in the table
    columns = {'Vessel': 'Vessel',
               'Start (origin)': 'Loaded',
               'Volume (mcm)': 'Volume (mcm)',
               'Trade status': 'Status',
               'Date (destination)': 'ETA',
               'Continent Destination': 'Continent',
               'Country (destination)' : 'Country',
               'Destination': 'Terminal',
               'Eta source (destination)': 'Confidence'
    }
    
    
    
    
    
    # Generate tables for each month
    for month in months:
        month_data = df[df['year_month'] == month]
        
        # Get month name for header
        first_date = month_data['Start (origin)'].iloc[0]
        month_name = first_date.strftime('%B %Y')
        
        # Add month header
        html += f'<h2>{month_name}</h2>\n'
        html += '<table>\n'
        html += '<thead>\n'
        html += '<tr>\n'
        
        # Add table headers
        for col in columns.keys():
            html += f'<th>{columns[col]}</th>\n'
        
        html += '</tr>\n'
        html += '</thead>\n'
        html += '<tbody>\n'
        
        # Add rows for each shipment
        for _, row in month_data.iterrows():
            # Determine row class based on trade status
            row_class = ''
            if row['Trade status'] == 'In Transit':
                row_class = 'class="in-transit"'
            elif row['Trade status'] == 'Loading':
                row_class = 'class="loading"'
            
            html += f'<tr {row_class}>\n'
            
            # Add each cell
            for col in columns.keys():
                value = row[col]
                
                # Format date columns
                if col in ['Start (origin)', 'Date (destination)'] and not pd.isna(value):
                    value = value.strftime('%d %b-%y')
                
                # Format numeric columns
                elif col == 'Volume (mcm)' and not pd.isna(value):
                    value = f"{value:.0f}"
                
                # Handle empty values
                if pd.isna(value):
                    value = ""
                
                html += f'<td>{value}</td>\n'
            
            html += '</tr>\n'
        
        html += '</tbody>\n'
        html += '</table>\n'
    
    # Add legend
    html += "</div>"
    
    return html
