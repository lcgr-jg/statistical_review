
"""
Email report showing key EU gas flows, LNG and storage data. Sent multiple times per day in order to display latest available nominations (& allocations)

"""


import logging
import sys
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
from common.dashboard_header import dashboard_header_for
from common.email_tables import df_to_styled_html, section_block_html, side_by_side_html
from common.partial_storage import (
    PARTIAL_CELL_BG,
    PARTIAL_CELL_COLOR,
    PARTIAL_STORAGE_NOTE,
    REPORT_STORAGE_ASSET_IDS,
    apply_partial_storage,
    fetch_partial_storage_injection,
)

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.interfaces.bloomberg import BBGQuery
from jain_commods.core.util.emailhelper import send_email
from jain_commods.fundamental.units import get_conversion_factor,unit_conversion_table


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/morning_flows')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'morning_flows.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
ce_user = config.get('CEConfig','user')
ce_pass = config.get('CEConfig','pass')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_morning_flows.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

email_subject = 'EU Gas Flows'    

    
try:
    logging.info('Generating report')
        
    days_history = 15
    
    bcf_to_mcm = get_conversion_factor('bcf/d','mcm',unit_conversion_table)
    
    # Define all US terminals
    us_terminals = {'GSLIQCLC Index': 'Calcasieu',
                    'GSLIQCAM Index': 'Cameron',
                    'GSLIQCCH Index': 'Corpus',
                    'GSLIQCOV Index': 'Cove',
                    'GSLIQELB Index': 'Elba',
                    'GSLIQGLF Index': 'Golden',
                    'GSLIQFPT Index': 'Freeport',
                    'GSLIQPLQ Index': 'Plaq',
                    'GSLIQSPI Index': 'Sabine',
                    'GSLIQTOT Index': 'Total',
                    }
    
    canada_terminal = 'GSLIQLNC Index'
    
    ###### Get BBG data (US liquefaction)
    logging.info('Querying Bloomberg...')
    bbg_session = BBGQuery(p_on_server=True)
    start_date = datetime(2017, 10, 1)
    end_date = datetime.today()
    us_liq=bbg_session.fetch_hist(list(us_terminals.keys()),
                                  ["PX_LAST"],
                                  start_date,
                                  end_date)
    canada_liq = bbg_session.fetch_hist([canada_terminal],
                                        ["PX_LAST"],
                                        start_date,
                                        end_date)
    bbg_session._close_session()
    
    # Set column names
    us_liq.columns = [us_terminals[c.replace('_PX_LAST','')] for c in us_liq.columns]
    canada_liq.columns = ['CA Liq [bcf/d]']
    
    canada_liq = canada_liq/1000/1000
    canada_liq.index = pd.to_datetime(canada_liq.index).strftime('%d-%b-%Y')
    
    # Split out total only ready to add to Flows table below
    us_liq_total = us_liq[['Total']]
    us_liq_total = us_liq_total/1000/1000
    us_liq_total.columns = ['US Liq [bcf/d]']
    us_liq_total.index = pd.to_datetime(us_liq_total.index).strftime('%d-%b-%Y')
    
    # Cretae per terminal breakdown
    us_liq_all = us_liq.sort_index(axis=1)
    us_liq_all = us_liq_all/1000/1000
    us_liq_all.index = pd.to_datetime(us_liq_all.index).strftime('%d-%b-%Y')
    # Get all time high values (except the latest value)
    us_liq_all_min = us_liq_all.iloc[:-1].min()
    us_liq_all_min.name = 'ATH'
    # Truncate to reqd history
    us_liq_all = us_liq_all.tail(days_history)
    # Add ATH row
    us_liq_all = pd.concat([pd.DataFrame([us_liq_all_min]), us_liq_all])
    us_liq_all.index.name = 'bcf/d'
    # Create mcm
    us_liq_all_mcm = us_liq_all.copy() * bcf_to_mcm
    us_liq_all_mcm.index.name = 'mcm/d'
    
    
    
    ###### Get Commodity Essentials data
    logging.info('Querying CE...')
    ce=CElink(ce_user,ce_pass)
    
    lng_asset_ids = '457,676,687,1779,467,476'
    lng_asset_names = ['BE','DE','FR','UK','IT','NL']
    
    # LNG regas per country
    df_regas=ce.eugasopdata(assets=lng_asset_ids,unit='mcm',variable='withdrawal')
    df_regas=df_regas.fillna(0)
    df_regas.index=df_regas['Date']
    df_regas.drop(columns=['DateExcel','Date'],inplace=True)
    df_regas.columns=lng_asset_names
    df_regas['Total']=df_regas.sum(axis=1)
    df_regas_short=df_regas.tail(days_history)

    # LNG stocks per country -- not displayed currently?
    df_regas_stocks=ce.eugasopdata(assets=lng_asset_ids,unit='mcm',variable='stock')
    df_regas_stocks=df_regas_stocks.dropna()
    df_regas_stocks.index=df_regas_stocks['Date']
    df_regas_stocks.drop(columns=['DateExcel','Date'],inplace=True)
    df_regas_stocks.columns=lng_asset_names
    df_regas_stocks['Total']=df_regas_stocks.sum(axis=1)
    
    # Key EU flows
    df_flows=ce.eugasopdata(assets='732,475,466,1871,1792,2678,2782,1969',unit='mcm',variable='netFlow')
    df_flows=df_flows.fillna(0)
    df_flows.index=df_flows['Date']
    df_flows.drop(columns=['DateExcel','Date'],inplace=True)
    df_flows.columns=['UA Total Imports','TAP','Mazara','Turkstream','Velke','UKCS','NL Prodn','NCS']
    df_flows=df_flows.join(us_liq_total)
    df_flows=df_flows.join(canada_liq)
    df_flows=df_flows=df_flows.tail(days_history)
    # df_flows=df_flows.round(1).astype(float)
    # df_regas_short=df_regas_short.round(0).astype(int)
    
    # EU storage per country. Keep missing values until the site-level fallback
    # has run: CE withholds a country total until every site has reported.
    df_storage=ce.eugasopdata(assets='458,468,477,677,688,1768,1780',unit='mcm',variable='netInjection',dateFrom=2018)
    df_storage.index=df_storage['Date']
    df_storage.drop(columns=['DateExcel','Date'],inplace=True)
    df_storage.columns=['AT','BE','DE','FR','GB','IT','NL']
    partial_mask = pd.DataFrame(False, index=df_storage.index, columns=list(df_storage.columns))
    try:
        partial_storage = fetch_partial_storage_injection(
            ce, df_storage, asset_ids=REPORT_STORAGE_ASSET_IDS,
        )
        partial_mask = apply_partial_storage(df_storage, partial_storage)
        filled_countries = [col for col in partial_mask.columns if partial_mask[col].any()]
        if filled_countries:
            logging.info(
                'Storage using level-2 site sums for %s',
                ', '.join(filled_countries),
            )
    except Exception:
        logging.exception('Level-2 storage fallback failed')
    df_storage=df_storage.fillna(0)
    df_storage['Total']=df_storage.sum(axis=1)
    
    # Create a new column for the day of the year
    df_storage['day_of_year'] = pd.to_datetime(df_storage.index).dayofyear

    # Calculate the 5-year rolling average for the 'Total' column
    moving_avg = (
        df_storage.groupby('day_of_year')['Total']
        .rolling(window=5)
        .mean()
        .shift(1)  # Shift to get averages of the past years
    )

    # Merge back into the original DataFrame
    df_storage['5_year_moving_avg'] = moving_avg.reset_index(level=0, drop=True)

    # Optional: Drop the 'day_of_year' column if not needed
    df_storage.drop(columns='day_of_year', inplace=True)

    df_storage['Delta to 5y Avg']=df_storage['Total']-df_storage['5_year_moving_avg']
    # Optionally, filter for the years 2019-2024
    # If you want only the moving average starting from 2024

    df_storage=df_storage.tail(days_history)
    # df_storage=df_storage.round(0).astype(int)
    
    
    # EU storage fills summary
    avg_yrs = 5
    ce_storage_fills = ce.eugasopdata(assets='1768,677,688,458,468,1780,477,',unit='mcm',variable='stock,stockCapacity',dateFrom=2018).set_index('Date').drop(columns=['DateExcel'])
    ce_storage_fills.index = pd.to_datetime(ce_storage_fills.index)
    ce_meta = ce.eugasmeta(id='seriesperasset')
    ce_storage_fills.columns = [f"{ce_meta[ce_meta['seriesId']==int(c)].iloc[0]['direction']}|{ce_meta[ce_meta['seriesId']==int(c)].iloc[0]['variable']}" for c  in ce_storage_fills.columns] 
    ce_storage_fills = ce_storage_fills.dropna()
    
    # Add total column
    ce_storage_fills['Total|stock'] = ce_storage_fills[[c for c in ce_storage_fills.columns if c.endswith('|stock')]].sum(axis=1)
    ce_storage_fills['Total|stockCapacity'] = ce_storage_fills.filter(like='stockCapacity').sum(axis=1)
    
    # Set what time horizons we're comparing
    d = ce_storage_fills.index[-1]
    d7 = ce_storage_fills.index[-7]
    d14 = ce_storage_fills.index[-14]
    d365 = ce_storage_fills.index[-365]
    
    # Get list of countries and calculate fill for each
    countries = set([c.split('|')[0] for c in ce_storage_fills.columns])
    storage_pc = {}
    storage_bcm = {}
    avg_yrs_col = f'{avg_yrs}yr avg'
    for c in countries:
        
        # Get day of year
        day_of_year = d.timetuple().tm_yday
        
        # Create filter for same day of year in past 5 years
        mask = (ce_storage_fills.index.map(lambda x: x.timetuple().tm_yday) == day_of_year) & \
               (ce_storage_fills.index >= d - pd.DateOffset(years=5)) & \
               (ce_storage_fills.index < d)
        # Calculate 5-year avg for the same day
        avg_pc = (ce_storage_fills.loc[mask, f"{c}|stock"] / ce_storage_fills.loc[mask, f"{c}|stockCapacity"]).mean()
        avg_bcm = (ce_storage_fills.loc[mask, f"{c}|stock"] / 1000).mean()
        
        # Capture & store value
        storage_pc[c] = {d: ce_storage_fills[f"{c}|stock"].iloc[-1] / ce_storage_fills[f"{c}|stockCapacity"].iloc[-1],
                         d7: ce_storage_fills[f"{c}|stock"].iloc[-7] / ce_storage_fills[f"{c}|stockCapacity"].iloc[-7],
                         d14: ce_storage_fills[f"{c}|stock"].iloc[-14] / ce_storage_fills[f"{c}|stockCapacity"].iloc[-14],
                         d365: ce_storage_fills[f"{c}|stock"].iloc[-365] / ce_storage_fills[f"{c}|stockCapacity"].iloc[-365],
                         avg_yrs_col: avg_pc,
                         }
        storage_bcm[c] = {d: ce_storage_fills[f"{c}|stock"].iloc[-1] / 1000,
                          d7: ce_storage_fills[f"{c}|stock"].iloc[-7] / 1000,
                          d14: ce_storage_fills[f"{c}|stock"].iloc[-14] / 1000,
                          d365: ce_storage_fills[f"{c}|stock"].iloc[-365] / 1000,
                          avg_yrs_col: avg_bcm,
                          'Capa': ce_storage_fills[f"{c}|stockCapacity"].iloc[-1]  / 1000,
                          }       

    # Prepare output
    df_storage_pc = pd.DataFrame.from_dict(storage_pc, orient='index', columns=[d,d7,d14,avg_yrs_col])
    df_storage_pc[f"vs {d7.strftime('%d-%b')}"] = df_storage_pc[d] - df_storage_pc[d7]
    df_storage_pc[f"vs {d14.strftime('%d-%b')}"] = df_storage_pc[d] - df_storage_pc[d14]
    df_storage_pc[f"vs {avg_yrs_col}"] = df_storage_pc[d] - df_storage_pc[avg_yrs_col]
    df_storage_pc = df_storage_pc.rename(columns={d: d.strftime('%d-%b')})
    df_storage_pc = df_storage_pc.drop([d7,d14,avg_yrs_col],axis=1)
    df_storage_pc = df_storage_pc * 100
    # Set display format
    for col in df_storage_pc.columns:
        if col.startswith('vs'):
            df_storage_pc[col] = [f'{v:+.0f}' for v in df_storage_pc[col].values]
    df_storage_pc.columns = pd.MultiIndex.from_tuples([('pct',c) for c in df_storage_pc.columns])        
    df_storage_pc = df_storage_pc.sort_index()
    
    
    df_storage_bcm = pd.DataFrame.from_dict(storage_bcm, orient='index', columns=[d,d7,d14,avg_yrs_col,'Capa'])
    df_storage_bcm[f"vs {d7.strftime('%d-%b')}"] = df_storage_bcm[d] - df_storage_bcm[d7]
    df_storage_bcm[f"vs {d14.strftime('%d-%b')}"] = df_storage_bcm[d] - df_storage_bcm[d14]
    df_storage_bcm[f"vs {avg_yrs_col}"] = df_storage_bcm[d] - df_storage_bcm[avg_yrs_col]
    df_storage_bcm = df_storage_bcm.rename(columns={d: d.strftime('%d-%b')})
    df_storage_bcm = df_storage_bcm.drop([d7,d14,avg_yrs_col],axis=1)
    # Fiddle with ordering (ie move Capa to the end)
    capa_col = df_storage_bcm.pop('Capa')
    df_storage_bcm['Capa'] = capa_col
    # Set display format
    for col in df_storage_bcm.columns:
        if col.startswith('vs'):
            df_storage_bcm[col] = [f'{v:+.1f}' for v in df_storage_bcm[col].values]
    df_storage_bcm.columns = pd.MultiIndex.from_tuples([('bcm',c) for c in df_storage_bcm.columns])        
    df_storage_bcm = df_storage_bcm.sort_index()
    
    
    ###### Construct email body and send
    logging.info(f'Sending email to {receivers}...')
    # df_regas_short_html=df_regas_short.to_html()
    # df_flows_html=df_flows.to_html()
    # df_storage_html=df_storage.to_html()
    
    # We set df_flows precision to zero below but but we cheat and set US feedgas as a string here with precision 1 
    # TODO: extend df2html function to be able to set precision per column 
    df_flows['US Liq [bcf/d]'] = [f'{v:,.1f}' for v in df_flows['US Liq [bcf/d]'].values]
    df_flows['CA Liq [bcf/d]'] = [f'{v:,.1f}' for v in df_flows['CA Liq [bcf/d]'].values]

    note = 'font-size:10pt;font-family:Arial,sans-serif;color:#555;'

    df_regas_short_html = df_to_styled_html(
        df_regas_short, precision=0, highlight_weekends=True,
        index_header="Date", index_dt_format="%d-%b-%Y",
    )
    df_flows_html = df_to_styled_html(
        df_flows, precision=0, highlight_weekends=True,
        index_header="Date", index_dt_format="%d-%b-%Y",
    )
    storage_highlight = pd.DataFrame(False, index=df_storage.index, columns=df_storage.columns)
    shown = partial_mask.reindex(df_storage.index).fillna(False)
    for col in shown.columns:
        if col in storage_highlight.columns:
            storage_highlight[col] = shown[col].astype(bool)
    country_cols = [col for col in shown.columns if col in storage_highlight.columns and col != 'Total']
    if country_cols and 'Total' in storage_highlight.columns:
        storage_highlight['Total'] = shown[country_cols].any(axis=1)
    df_storage_html = df_to_styled_html(
        df_storage, precision=0, highlight_weekends=True,
        index_header="Date", index_dt_format="%d-%b-%Y",
        highlight_cells=storage_highlight,
        highlight_color=PARTIAL_CELL_COLOR,
        highlight_bg=PARTIAL_CELL_BG,
    )
    storage_note = (
        f'<div style="font-size:10pt;font-family:Arial,sans-serif;margin-top:6px;'
        f'color:{PARTIAL_CELL_COLOR};">{PARTIAL_STORAGE_NOTE}</div>'
    )
    df_storage_pc_html = df_to_styled_html(df_storage_pc, precision=0)
    df_storage_bcm_html = df_to_styled_html(df_storage_bcm, precision=1)
    df_us_liq_html = df_to_styled_html(
        us_liq_all, precision=1, highlight_weekends=True,
        index_header=us_liq_all.index.name or "", index_dt_format="%d-%b-%Y",
    )
    df_us_liq_mcm_html = df_to_styled_html(
        us_liq_all_mcm, precision=0, highlight_weekends=True,
        index_header=us_liq_all_mcm.index.name or "", index_dt_format="%d-%b-%Y",
    )

    dashboard_header = dashboard_header_for("morning_flows")
    notes = (
        f'<span style="{note}">'
        "EU data queried live direct from Commodity Essentials."
        '<br>US & CA feedgas queried from Bloomberg (CA = "GSLIQLNC Index")'
        f"<br>bcf/d to mcm conversion factor = {bcf_to_mcm}"
        f"<br>{PARTIAL_STORAGE_NOTE}</span>"
    )
    # One outer table so Outlook mobile cannot float/overlay consecutive sections.
    email_body = f"""
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;mso-table-lspace:0pt;mso-table-rspace:0pt;">
  <tr>
    <td>
      {dashboard_header}
      <span style="{note}">Note: if today's noms = 0 they are likely not nominated yet.</span>
      <br><br>
    </td>
  </tr>
  <tr><td>{section_block_html("Regas", df_regas_short_html, first=True)}</td></tr>
  <tr><td>{section_block_html("Flows", df_flows_html)}</td></tr>
  <tr><td>{section_block_html("Storage Action", df_storage_html + storage_note)}</td></tr>
  <tr><td>{section_block_html("Storage Levels", side_by_side_html(df_storage_pc_html, df_storage_bcm_html))}</td></tr>
  <tr><td>{section_block_html("US LNG Feedgas Breakdown", side_by_side_html(df_us_liq_html, df_us_liq_mcm_html))}</td></tr>
  <tr><td>{section_block_html("Notes", notes)}</td></tr>
</table>
"""
    send_email(receivers, 
               email_subject, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')    

    logging.info('Report sent')
    

except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))    

        