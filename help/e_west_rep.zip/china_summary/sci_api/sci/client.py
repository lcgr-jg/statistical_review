"""
Client for the SCI datapack API (open.sci99.com).

See Operation Description for SCI Data Access for endpoint details.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Any, Iterable, Optional, Union

import pandas as pd
import requests

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

DateLike = Union[date, datetime, str]

BASE_URL = "https://open.sci99.com/datapackapi/pkg"
AUTH_HEADER = "scipkgauth"
TOKEN_MAX_AGE = timedelta(hours=23)


class SCIError(Exception):
    """Raised when the API returns a non-success status code."""

    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f"SCI API error {status}: {message}")


@dataclass(frozen=True)
class SCIConfig:
    username: str
    password: str
    user_type: int = 2  # 1 = Chinese account, 2 = English account
    base_url: str = BASE_URL
    timeout: float = 60.0

    @classmethod
    def from_env(
        cls,
        username_var: str = "SCI_USERNAME",
        password_var: str = "SCI_PASSWORD",
        user_type_var: str = "SCI_USER_TYPE",
    ) -> "SCIConfig":
        username = os.getenv(username_var)
        password = os.getenv(password_var)
        if not username or not password:
            raise ValueError(
                f"Set {username_var} and {password_var} environment variables "
                "or pass credentials explicitly."
            )
        user_type = int(os.getenv(user_type_var, "2"))
        return cls(username=username, password=password, user_type=user_type)


@dataclass(frozen=True)
class DataPackage:
    package_id: int
    latest_date: Optional[datetime]
    historical_dates: tuple[datetime, ...] = ()

    @classmethod
    def from_api(cls, row: dict[str, Any]) -> "DataPackage":
        latest_raw = row.get("LatestDate")
        latest_dt = None
        if latest_raw:
            latest_dt = pd.to_datetime(latest_raw).to_pydatetime()

        hist_raw = row.get("HistoricalDateList") or []
        hist_dates = tuple(
            sorted(pd.to_datetime(d).to_pydatetime() for d in hist_raw if d)
        )
        return cls(
            package_id=int(row["DataPackageID"]),
            latest_date=latest_dt,
            historical_dates=hist_dates,
        )

    def latest_date_in_year(self, year: int) -> Optional[datetime]:
        """Latest published date within the given calendar year, if any."""
        in_year = [d for d in self.historical_dates if d.year == year]
        if self.latest_date and self.latest_date.year == year:
            in_year.append(self.latest_date)
        return max(in_year) if in_year else None


@dataclass(frozen=True)
class SheetData:
    sheet_name: str
    topic: str
    unit: Optional[str]
    note: Optional[str]
    methodology: Optional[str]
    data_list: list[dict[str, Any]]

    @classmethod
    def from_api(cls, row: dict[str, Any]) -> "SheetData":
        return cls(
            sheet_name=row["SheetName"],
            topic=row["Topic"],
            unit=row.get("Unit"),
            note=row.get("Note"),
            methodology=row.get("Methodology"),
            data_list=list(row.get("DataList") or []),
        )

    def to_dataframe(self) -> pd.DataFrame:
        if not self.data_list:
            return pd.DataFrame()
        return pd.DataFrame(self.data_list)


@dataclass
class PackageData:
    package_name: str
    pub_date: datetime
    sheets: list[SheetData]

    def sheet_by_topic(self, topic: str, *, exact: bool = False) -> SheetData:
        if exact:
            matches = [s for s in self.sheets if s.topic == topic]
        else:
            key = topic.casefold()
            matches = [s for s in self.sheets if key in s.topic.casefold()]
        if not matches:
            available = [s.topic for s in self.sheets]
            raise KeyError(f"No sheet matching topic {topic!r}. Available: {available}")
        if len(matches) > 1:
            names = [s.topic for s in matches]
            raise KeyError(f"Multiple sheets match topic {topic!r}: {names}")
        return matches[0]

    def sheet_by_name(self, sheet_name: str, *, exact: bool = False) -> SheetData:
        if exact:
            matches = [s for s in self.sheets if s.sheet_name == sheet_name]
        else:
            key = sheet_name.casefold()
            matches = [s for s in self.sheets if key in s.sheet_name.casefold()]
        if not matches:
            available = [s.sheet_name for s in self.sheets]
            raise KeyError(
                f"No sheet matching name {sheet_name!r}. Available: {available}"
            )
        if len(matches) > 1:
            names = [s.sheet_name for s in matches]
            raise KeyError(f"Multiple sheets match name {sheet_name!r}: {names}")
        return matches[0]


class SCIClient:
    """Login, list datapackages, and fetch latest or historical forecast issues."""

    def __init__(
        self,
        config: SCIConfig,
        *,
        token: Optional[str] = None,
        session: Optional[requests.Session] = None,
    ):
        self.config = config
        self._session = session or requests.Session()
        self._token: Optional[str] = token
        self._token_obtained_at: Optional[datetime] = None

    @classmethod
    def from_env(cls, **kwargs: Any) -> "SCIClient":
        return cls(SCIConfig.from_env(), **kwargs)

    @property
    def token(self) -> Optional[str]:
        return self._token

    def login(self, *, force: bool = False) -> str:
        """Request a new access token (valid ~1 day). Returns the token string."""
        if (
            not force
            and self._token
            and self._token_obtained_at
            and datetime.now() - self._token_obtained_at < TOKEN_MAX_AGE
        ):
            return self._token

        url = f"{self.config.base_url}/user/gettoken"
        payload = {
            "UserName": self.config.username,
            "Password": self.config.password,
            "UserType": self.config.user_type,
        }
        response = self._session.post(
            url,
            json=payload,
            timeout=self.config.timeout,
        )
        response.raise_for_status()
        body = response.json()
        status, msg, data = _parse_envelope(body)
        if status != 200:
            raise SCIError(status, msg)
        if not data:
            raise SCIError(status, "Token response missing data field")
        self._token = str(data)
        self._token_obtained_at = datetime.now()
        return self._token

    def _auth_headers(self) -> dict[str, str]:
        token = self.login()
        return {AUTH_HEADER: token, "Content-Type": "application/json"}

    def get_raw_package_list(self) -> list[dict[str, Any]]:
        """Return the raw getmypkglist 'data' rows (for inspecting keys like HistoricalDateList)."""
        url = f"{self.config.base_url}/getmypkglist"
        response = self._session.get(
            url,
            headers=self._auth_headers(),
            timeout=self.config.timeout,
        )
        response.raise_for_status()
        status, msg, data = _parse_envelope(response.json())
        if status != 200:
            raise SCIError(status, msg)
        return list(data or [])

    def list_packages(self) -> list[DataPackage]:
        """Return datapackages the account can access (IDs and latest issue dates)."""
        return [DataPackage.from_api(row) for row in self.get_raw_package_list()]

    def get_package_data(
        self,
        package_id: int,
        pub_date: Optional[DateLike] = None,
        *,
        retry_on_auth: bool = True,
    ) -> PackageData:
        """
        Fetch one datapackage issue.

        Omit pub_date for the latest issue. Pass pub_date for a historical issue
        (format as in the package list, e.g. 2022-1-1 or 2022-10-21).
        """
        url = f"{self.config.base_url}/getpkgdata"
        params: dict[str, Any] = {"pkgid": package_id}
        if pub_date is not None:
            params["pubdate"] = _format_pub_date(pub_date)

        response = self._session.get(
            url,
            headers=self._auth_headers(),
            params=params,
            timeout=self.config.timeout,
        )
        response.raise_for_status()
        status, msg, data = _parse_envelope(response.json())
        if status == 10002 and retry_on_auth:
            self.login(force=True)
            return self.get_package_data(
                package_id, pub_date, retry_on_auth=False
            )
        if status != 200:
            raise SCIError(status, msg)
        if not data:
            raise SCIError(status, "Package data response missing data field")

        sheets = [SheetData.from_api(s) for s in data.get("SheetList") or []]
        pub_dt = pd.to_datetime(data["PubDate"]).to_pydatetime()
        return PackageData(
            package_name=data["DataPackageName"],
            pub_date=pub_dt,
            sheets=sheets,
        )

    def get_package(self, package_id: int) -> DataPackage:
        """Return the DataPackage entry (with latest + historical dates) by id."""
        for pkg in self.list_packages():
            if pkg.package_id == package_id:
                return pkg
        raise SCIError(10004, f"Package {package_id} not in accessible package list")

    def get_latest_date(self, package_id: int) -> Optional[datetime]:
        """Latest issue date for a package, taken from the package list."""
        return self.get_package(package_id).latest_date

    def get_latest_forecast(
        self,
        package_id: int,
        topic: Optional[str] = None,
        *,
        sheet_name: Optional[str] = None,
    ) -> Union[PackageData, SheetData, pd.DataFrame]:
        """
        Latest issue for a package. If topic or sheet_name is given, return that sheet's DataFrame.
        Otherwise return the full PackageData.

        The getpkgdata endpoint rejects calls with no pubdate (10000), so we resolve
        the latest issue date from the package list first.
        """
        latest_date = self.get_latest_date(package_id)
        pkg = self.get_package_data(package_id, pub_date=latest_date)
        return _select_sheet(pkg, topic=topic, sheet_name=sheet_name, as_frame=True)

    def get_historic_forecast(
        self,
        package_id: int,
        pub_date: DateLike,
        topic: Optional[str] = None,
        *,
        sheet_name: Optional[str] = None,
    ) -> Union[PackageData, SheetData, pd.DataFrame]:
        """
        Historical issue for a package. If topic or sheet_name is given, return that sheet's DataFrame.
        Otherwise return the full PackageData.
        """
        pkg = self.get_package_data(package_id, pub_date=pub_date)
        return _select_sheet(pkg, topic=topic, sheet_name=sheet_name, as_frame=True)

    def get_forecast_history(
        self,
        package_id: int,
        years: Iterable[int],
        topic: Optional[str] = None,
        *,
        sheet_name: Optional[str] = None,
        month_column: str = "Month",
        debug: bool = False,
    ) -> pd.DataFrame:
        """
        Stitch one topic across several years into a single DataFrame.

        For each requested year the most complete issue is chosen:
          - current / future years -> the latest available forecast
          - past years             -> the last forecast published in that year,
            which carries actuals back to the start of that year.

        Each issue's rows are filtered to their source year and concatenated.
        Adds 'period' (month-start Timestamp), 'year', 'is_estimate' and
        'pub_date' columns; the result is sorted by period with duplicate
        periods resolved in favour of the latest issue.

        Either topic or sheet_name must be given (the package holds several topics).
        """
        if topic is None and sheet_name is None:
            raise ValueError("Specify a topic or sheet_name to stitch.")
        if topic is not None and sheet_name is not None:
            raise ValueError("Specify only one of topic or sheet_name")

        def log(msg: str) -> None:
            if debug:
                print(f"[get_forecast_history] {msg}")

        wanted_years = sorted({int(y) for y in years})
        if not wanted_years:
            raise ValueError("Provide at least one year.")

        package = self.get_package(package_id)
        latest_date = package.latest_date
        latest_year = latest_date.year if latest_date else max(wanted_years)

        log(f"wanted_years={wanted_years}")
        log(f"latest_date={latest_date}  latest_year={latest_year}")
        log(f"historical_dates count={len(package.historical_dates)}")
        if package.historical_dates:
            sample = [d.date().isoformat() for d in package.historical_dates[:5]]
            tail = [d.date().isoformat() for d in package.historical_dates[-5:]]
            log(f"historical_dates first={sample} last={tail}")
            years_avail = sorted({d.year for d in package.historical_dates})
            log(f"years present in historical_dates={years_avail}")
        else:
            log(
                "historical_dates is EMPTY -> past years will be skipped. "
                "Check that getmypkglist returns 'HistoricalDateList' "
                "(see raw keys printed by list_packages debug)."
            )

        cache: dict[str, PackageData] = {}

        def fetch(pub_date: Optional[DateLike]) -> PackageData:
            key = _format_pub_date(pub_date) if pub_date is not None else "__latest__"
            if key not in cache:
                cache[key] = self.get_package_data(package_id, pub_date=pub_date)
            return cache[key]

        frames: list[pd.DataFrame] = []
        for year in wanted_years:
            if year >= latest_year:
                # current/future years: best info is in the latest issue
                pub_date: Optional[DateLike] = latest_date
                log(f"year={year}: using LATEST issue pub_date={pub_date}")
            else:
                # past years: last issue published within that year
                pub_date = package.latest_date_in_year(year)
                log(f"year={year}: latest_date_in_year -> {pub_date}")
                if pub_date is None:
                    log(f"year={year}: SKIPPED (no issue published in this year)")
                    continue

            pkg = fetch(pub_date)
            log(
                f"year={year}: fetched issue pub_date={pkg.pub_date} "
                f"name={pkg.package_name!r} sheets={len(pkg.sheets)}"
            )

            try:
                sheet = (
                    pkg.sheet_by_topic(topic)
                    if topic is not None
                    else pkg.sheet_by_name(sheet_name)
                )
            except KeyError as exc:
                log(f"year={year}: sheet lookup FAILED -> {exc}")
                log(
                    f"year={year}: available topics={[s.topic for s in pkg.sheets]}"
                )
                log(
                    f"year={year}: available sheet names={[s.sheet_name for s in pkg.sheets]}"
                )
                raise

            df = sheet.to_dataframe()
            log(
                f"year={year}: sheet={sheet.sheet_name!r} rows={len(df)} "
                f"columns={list(df.columns)}"
            )
            if df.empty:
                log(f"year={year}: SKIPPED (sheet DataFrame is empty)")
                continue

            col = month_column if month_column in df.columns else df.columns[0]
            if col != month_column:
                log(
                    f"year={year}: month_column {month_column!r} not found; "
                    f"falling back to first column {col!r}"
                )
            raw_sample = df[col].astype(str).head(6).tolist()
            log(f"year={year}: month column={col!r} raw sample={raw_sample}")

            period, is_estimate = _parse_month_series(df[col])
            n_nat = int(period.isna().sum())
            parsed_sample = [
                None if pd.isna(p) else p.date().isoformat()
                for p in period.head(6)
            ]
            log(
                f"year={year}: parsed period sample={parsed_sample} "
                f"NaT_count={n_nat}/{len(period)}"
            )
            if n_nat == len(period):
                log(
                    f"year={year}: ALL month labels failed to parse with "
                    f"format '%b-%y'. The label format differs - tell the "
                    f"assistant the raw sample above to fix the parser."
                )

            df = df.assign(
                period=period,
                year=period.dt.year,
                is_estimate=is_estimate,
                pub_date=pkg.pub_date,
            )
            year_counts = df["year"].value_counts(dropna=False).to_dict()
            log(f"year={year}: parsed year distribution={year_counts}")

            df = df[df["year"] == year]
            log(f"year={year}: rows after filtering to year {year} = {len(df)}")
            if not df.empty:
                frames.append(df)

        if not frames:
            log("RESULT: no frames collected -> returning empty DataFrame")
            return pd.DataFrame()

        result = pd.concat(frames, ignore_index=True)
        result = result.sort_values(["period", "pub_date"])
        result = result.drop_duplicates(subset="period", keep="last")
        result = result.sort_values("period").reset_index(drop=True)

        front = ["period", "year", "is_estimate", "pub_date"]
        ordered = front + [c for c in result.columns if c not in front]
        return result[ordered]


def _parse_month_series(values: pd.Series) -> tuple[pd.Series, pd.Series]:
    """
    Parse SCI month labels into (period, is_estimate).

    Handles both label styles seen across topics:
      - abbreviated month, e.g. 'Oct-21' / 'Nov-21(E)'
      - ISO date,          e.g. '2024-01-01' / '2024/1/1'
    """
    raw = values.astype(str).str.strip()
    is_estimate = raw.str.contains(r"\(E\)", flags=re.IGNORECASE, regex=True)
    cleaned = raw.str.replace(
        r"\s*\(E\)\s*$", "", regex=True, flags=re.IGNORECASE
    ).str.strip()

    # Try the abbreviated month-year label first (avoids day-first ambiguity).
    period = pd.to_datetime(cleaned, format="%b-%y", errors="coerce")

    # Fall back to generic parsing for anything still unparsed (ISO dates etc.).
    missing = period.isna() & cleaned.ne("") & cleaned.str.lower().ne("nan")
    if missing.any():
        fallback = pd.to_datetime(cleaned[missing], errors="coerce")
        period = period.copy()
        period.loc[missing] = fallback

    # Normalise to month start so the two styles align.
    period = period.dt.to_period("M").dt.to_timestamp()
    return period, is_estimate


def _parse_envelope(body: dict[str, Any]) -> tuple[int, str, Any]:
    status = body.get("status", body.get("Status"))
    msg = body.get("msg", body.get("Msg", ""))
    data = body.get("data", body.get("Data"))
    return int(status), str(msg), data


def _format_pub_date(pub_date: DateLike) -> str:
    if isinstance(pub_date, str):
        return pub_date
    if isinstance(pub_date, datetime):
        return pub_date.strftime("%Y-%m-%d")
    return pub_date.isoformat()


def _select_sheet(
    pkg: PackageData,
    *,
    topic: Optional[str],
    sheet_name: Optional[str],
    as_frame: bool,
) -> Union[PackageData, SheetData, pd.DataFrame]:
    if topic is None and sheet_name is None:
        return pkg
    if topic is not None and sheet_name is not None:
        raise ValueError("Specify only one of topic or sheet_name")
    sheet = (
        pkg.sheet_by_topic(topic)
        if topic is not None
        else pkg.sheet_by_name(sheet_name)
    )
    return sheet.to_dataframe() if as_frame else sheet
