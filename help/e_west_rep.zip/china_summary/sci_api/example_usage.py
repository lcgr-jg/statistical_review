"""
Inspect what your SCI account can access:
  - every datapackage (id + latest issue date)
  - every topic / sheet inside each package

Credentials: edit the SCIConfig(...) below, or use SCIConfig.from_env()
(SCI_USERNAME, SCI_PASSWORD, SCI_USER_TYPE) if you prefer env / .env.
"""

from sci.client import SCIClient, SCIConfig


def build_client() -> SCIClient:
    # --- Option A: hard-code for a quick local test ---
    # NOTE: local testing creds. Keep this file local; do not commit/push it.
    config = SCIConfig(
        username="jainglobal",
        password="123456abc",
        user_type=2,  # 2 = English account, 1 = Chinese
    )
    return SCIClient(config)

    # --- Option B: read from env / .env instead ---
    # return SCIClient(SCIConfig.from_env())


def main() -> None:
    client = build_client()
    client.login()
    print("Token obtained.\n")

    # Raw getmypkglist payload - confirms the exact keys (e.g. HistoricalDateList)
    import json

    raw = client.get_raw_package_list()
    print("Raw getmypkglist rows (first row keys + sample):")
    if raw:
        print("  keys:", list(raw[0].keys()))
        print("  row0:", json.dumps(raw[0], default=str)[:800])
    print()

    packages = client.list_packages()
    if not packages:
        print("No packages accessible for this account.")
        return

    print(f"{len(packages)} package(s) accessible:")
    for pkg in packages:
        print(f"  id={pkg.package_id}  latest={pkg.latest_date}")
        if pkg.historical_dates:
            by_year = {}
            for d in pkg.historical_dates:
                by_year[d.year] = max(d, by_year.get(d.year, d))
            latest_per_year = ", ".join(
                f"{y}->{by_year[y].date()}" for y in sorted(by_year)
            )
            print(f"      latest issue per year: {latest_per_year}")
    print()

    # Inspect topics/sheets inside each package.
    # NOTE: getpkgdata returns 10000 "Parameter Invalid" if pubdate is omitted,
    # so we pass the LatestDate from the package list to fetch the latest issue.
    for pkg in packages:
        print("=" * 70)
        try:
            data = client.get_package_data(pkg.package_id, pub_date=pkg.latest_date)
        except Exception as exc:  # noqa: BLE001 - inspection script
            print(f"[id={pkg.package_id}] could not load: {exc}")
            continue

        print(f"id={pkg.package_id}  {data.package_name}  (issue {data.pub_date})")
        print(f"  {len(data.sheets)} topic(s):")
        for sheet in data.sheets:
            unit = f"  [{sheet.unit}]" if sheet.unit else ""
            print(f"    - sheet={sheet.sheet_name!r}")
            print(f"        topic={sheet.topic!r}{unit}")
    print("=" * 70)

    print(
        "\nTo pull one topic as a DataFrame, e.g.:\n"
        "    df = client.get_latest_forecast(\n"
        "        package_id, topic='China LNG Consumption Volume Forecast')\n"
    )

    # --- Stitch history + latest forecast across several years -----------
    # Past years come from the last issue published in that year (so they
    # carry actuals back to Jan); the current year uses the latest issue.
    #
    # package_id = packages[0].package_id
    # df = client.get_forecast_history(
    #     package_id,
    #     years=[2024, 2025, 2026],
    #     topic="China LNG Consumption Volume Forecast",
    #     debug=True,  # prints step-by-step diagnostics
    # )
    # print(df.head(40))


if __name__ == "__main__":
    main()
