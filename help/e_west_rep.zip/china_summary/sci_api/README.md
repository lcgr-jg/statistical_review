# SCI datapack API client

Python wrapper for [Sublime China Information](https://www.sci99.com) datapack API (`open.sci99.com`).

## Setup

```bash
pip install -r requirements.txt
```

Environment variables (optional if you pass `SCIConfig` explicitly):

| Variable | Description |
|----------|-------------|
| `SCI_USERNAME` | Account email |
| `SCI_PASSWORD` | Account password |
| `SCI_USER_TYPE` | `1` = Chinese account, `2` = English (default) |

## Usage

```python
from sci.client import SCIClient, SCIConfig

client = SCIClient(SCIConfig.from_env())
client.login()

# Packages you have access to (e.g. your 3 datapacks)
for pkg in client.list_packages():
    print(pkg.package_id, pkg.latest_date)

package_id = 3

# Latest full issue
latest = client.get_package_data(package_id)

# Latest forecast for one topic → pandas DataFrame
df = client.get_latest_forecast(
    package_id,
    topic="China LNG Consumption Volume Forecast",
)

# Historical issue (pubdate as in API docs, e.g. 2022-10-21)
historic = client.get_historic_forecast(package_id, "2022-10-21", topic="China LNG Consumption Volume Forecast")
```

See `example_usage.py` for a runnable sketch.

## API mapping

| Method | HTTP | Endpoint |
|--------|------|----------|
| `login()` | POST | `/user/gettoken` |
| `list_packages()` | GET | `/getmypkglist` (header `scipkgauth`) |
| `get_package_data()` | GET | `/getpkgdata?pkgid=&pubdate=` |

Token is cached for 23 hours then refreshed automatically. Status `10002` triggers one forced re-login and retry.
