"""
Helpers for the China Summary report: SCI data pulls and chart generation.
"""

import io
import base64

from datetime import datetime, timedelta

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests

from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table

from sci_client import SCIClient, SCIError

# Kpler LNG API (cargo-level trade trackings)
KPLER_LNG_BASE_URL = "https://api-lng.kpler.com/v1/"
# Kpler cargo volumes are m3 of LNG (liquid); convert to gas-equivalent mcm
KPLER_M3_TO_MCM = get_conversion_factor('cu m', 'mcm', unit_conversion_table)
# LNG mass to gas-equivalent volume: 1 Mt of LNG ~= 1395 mcm of gas
MT_TO_MCM = get_conversion_factor('m mt', 'mcm', unit_conversion_table)

# SCI package/topic identifiers
SCI_PKG_GAS_KEY_DRIVERS = 782  # 'SCI China Natural Gas Datapack-Key Drivers'
SCI_TOPIC_DOMESTIC_PRODUCTION = "China Natural Gas Output"  # sheet '03.NG Output', bcm

SCI_TOPIC_SD_BALANCE = "China Natural Gas S&D Balance Summary"  # sheet '14.S&D Balance ', bcm
# NB: SCI's topic name carries a trailing space; sheet_by_topic normalises it
SCI_TOPIC_CONSUMPTION_STRUCTURE = "China Natural Gas Monthly Consumption Structure"  # % split by sector
SCI_TOPIC_WEEKLY_SUMMARY = "China NG Industry Weekly Summary"  # sheet '02.Weekly Summary'; transposed weekly layout
SCI_TOPIC_TERMINAL_TRUCK_LOADING = "China LNG Terminal Truck Loading"  # sheet '07.Truck Loading'; daily kt by terminal
SCI_TOPIC_LNG_STORAGE_CAPACITY = "China LNG Storage Capacity"  # sheet '49', liquid mcm, weekly
SCI_TOPIC_LNG_INVENTORY_RATE = "China LNG Inventory Rate"  # sheet '48', fill fraction, weekly

SCI_PKG_GAS_FORECAST = 742  # 'SCI China Natural Gas Forecast Datapack'
SCI_TOPIC_PRODUCTION_FORECAST = "China NG Output Forecast"  # sheet '02.NG Output FCST', bcm
SCI_TOPIC_CONSUMPTION_FORECAST = "China Natural Gas Apparent Consumption 24-Month Forecast"  # sheet '07', bcm
SCI_TOPIC_LNG_IMPORT_FORECAST = "China LNG Import Forecast"  # sheet '04.LNG Import FCST', bcm
SCI_TOPIC_PNG_IMPORT_FORECAST = "China PNG Import Forecast"  # sheet '03.PNG Import FCST', bcm
SCI_TOPIC_SD_BALANCE_FORECAST = "China NG Supply-Demand Balance Forecast"  # sheet '01.S&D FCST', bcm
SCI_TOPIC_CONSUMPTION_STRUCTURE_FORECAST = "China Natural Gas Consumption Structure 24-Month Forecast"  # % split by sector

# Demand sectors in the SCI consumption structure topics. SCI publish the
# 6-sector split from 2025 onwards; before that residential, public
# service/commercial and NGV were lumped into a single 'City gas' bucket,
# which is carried as an extra column so the history can extend pre-2025.
DEMAND_SECTORS = [
    "Industrial gas",
    "Residential gas",
    "Gas power",
    "NGV",
    "Public service and commercial gas",
    "Chemical feedstock",
]
DEMAND_SECTOR_CITY_GAS = "City gas"  # pre-2025 bucket: residential + public svc/commercial + NGV
# Stack/row order for charts and tables: City gas next to the sectors it
# used to contain, big sectors at the bottom of the stacks
DEMAND_SECTORS_DISPLAY = [
    "Industrial gas",
    "Residential gas",
    DEMAND_SECTOR_CITY_GAS,
    "Gas power",
    "NGV",
    "Public service and commercial gas",
    "Chemical feedstock",
]
DEMAND_SECTOR_LABELS = {  # display names for chart legends / table rows
    "Industrial gas": "Industry",
    "Residential gas": "Residential",
    "NGV": "Transport",  # NGV = natural gas vehicles (mostly LNG trucking)
    "Public service and commercial gas": "Public service & commercial",
}
DEMAND_SECTOR_COLORS = {
    "Industrial gas": "#2f7d6c",
    "Residential gas": "#2c6fbb",
    DEMAND_SECTOR_CITY_GAS: "#5f87a5",
    "Gas power": "#e67e22",
    "NGV": "#7d3c98",
    "Public service and commercial gas": "#c9a227",
    "Chemical feedstock": "#c0392b",
}


# Shared inline styles for HTML email tables. Email clients (Outlook in
# particular) don't inherit the body font into <table> cells, so the family
# must be set explicitly on every cell. NOTE: keep this free of quote
# characters - cells are emitted with single-quoted style attributes, so any
# quote here would terminate the attribute and break the styling.
_TABLE_FONT = "font-family:Segoe UI,Arial,sans-serif;"
TABLE_TH_STYLE = (_TABLE_FONT + "text-align:right; padding:4px 12px; "
                  "border-bottom:2px solid #2c3e50; font-weight:600; "
                  "color:#2c3e50; font-size:12px; white-space:nowrap;")
TABLE_TD_STYLE = (_TABLE_FONT + "text-align:right; padding:4px 12px; "
                  "color:#333; font-size:12px; border-bottom:1px solid #e8e8e8; "
                  "white-space:nowrap;")
TABLE_NOTE_STYLE = _TABLE_FONT + "margin:6px 0 0 0; font-size:10px; color:#777;"


def _find_col(df: pd.DataFrame, name: str):
    """Find a column by name, ignoring case and stray whitespace."""
    key = " ".join(name.split()).casefold()
    for c in df.columns:
        if " ".join(str(c).split()).casefold() == key:
            return c
    raise KeyError(f"No column matching {name!r}. Available: {list(df.columns)}")


def get_domestic_production(client: SCIClient, years) -> pd.DataFrame:
    """
    Monthly China domestic natural gas production (bcm) stitched across years.

    Returns a DataFrame with columns: month (Timestamp), pub_date, value.
    """
    df = client.get_topic_history(
        SCI_PKG_GAS_KEY_DRIVERS,
        SCI_TOPIC_DOMESTIC_PRODUCTION,
        years=years,
    )
    if df.empty:
        return df
    # Value column is 'NG output'; pick the first numeric non-meta column to be safe
    meta_cols = {"month", "pub_date", "Month"}
    value_col = next(
        c for c in df.columns
        if c not in meta_cols and pd.api.types.is_numeric_dtype(df[c])
    )
    return df[["month", "pub_date"]].assign(value=df[value_col])


def get_apparent_consumption(client: SCIClient, years) -> pd.DataFrame:
    """
    Monthly China total gas demand / NG apparent consumption (bcm) stitched
    across years from the S&D Balance Summary topic.

    Older issues don't carry the 'NG apparent consumption' column, so where it
    is missing it is computed from the balance components (production + LNG &
    PNG imports - LNG & PNG exports), which sums to the published figure.

    Returns a DataFrame with columns: month (Timestamp), pub_date, value.
    """
    df = client.get_topic_history(
        SCI_PKG_GAS_KEY_DRIVERS,
        SCI_TOPIC_SD_BALANCE,
        years=years,
    )
    if df.empty:
        return df

    def col(name):
        return pd.to_numeric(df.get(name), errors="coerce")

    value = col("NG apparent consumption")
    computed = (
        col("NG production") + col("LNG import") + col("PNG import")
        - col("LNG export") - col("PNG export")
    )
    value = value.fillna(computed)
    return df[["month", "pub_date"]].assign(value=value)


def _forecast_frame(issue, topic: str) -> pd.DataFrame:
    """
    Parse one forecast topic from an already-fetched forecast datapack issue.

    Returns a DataFrame with columns: month (Timestamp), value, lower, upper,
    pub_date (issue publication date).
    """
    df = issue.sheet_by_topic(topic).to_dataframe()
    if df.empty:
        return df

    # Columns: Month, <forecast value>, Confidence lower/upper limit, <actual>
    lower_col = next(c for c in df.columns if "lower" in c.lower())
    upper_col = next(c for c in df.columns if "upper" in c.lower())
    value_col = next(
        c for c in df.columns[1:]
        if c not in (lower_col, upper_col) and "actual" not in c.lower()
    )

    out = pd.DataFrame({
        "month": pd.to_datetime(df[df.columns[0]]).dt.to_period("M").dt.to_timestamp(),
        "value": pd.to_numeric(df[value_col], errors="coerce"),
        "lower": pd.to_numeric(df[lower_col], errors="coerce"),
        "upper": pd.to_numeric(df[upper_col], errors="coerce"),
        "pub_date": issue.pub_date,
    })
    return out.sort_values("month").reset_index(drop=True)


def _get_forecast_topic(client: SCIClient, topic: str, pub_date=None) -> pd.DataFrame:
    """
    A 24-month forecast topic from one SCI forecast datapack issue (latest by
    default, or a specific historical vintage via pub_date).
    """
    issue = client.get_package_data(SCI_PKG_GAS_FORECAST, pub_date)
    return _forecast_frame(issue, topic)


def get_domestic_production_forecast(client: SCIClient) -> pd.DataFrame:
    """Latest SCI 24-month NG output forecast (bcm) with confidence limits."""
    return _get_forecast_topic(client, SCI_TOPIC_PRODUCTION_FORECAST)


def get_apparent_consumption_forecast(client: SCIClient) -> pd.DataFrame:
    """Latest SCI 24-month apparent consumption forecast (bcm) with confidence limits."""
    return _get_forecast_topic(client, SCI_TOPIC_CONSUMPTION_FORECAST)


def get_consumption_structure(client: SCIClient, years) -> pd.DataFrame:
    """
    Monthly demand split by sector, as fractions of total demand (rows sum
    to 1), stitched across years. Pre-2025 months use SCI's older 4-sector
    classification, where residential, public service/commercial and NGV
    are lumped into 'City gas'; those months carry the City gas column with
    the three sub-sectors NaN (and vice versa from 2025).

    Returns a DataFrame with columns: month, pub_date, plus one fraction
    column per DEMAND_SECTORS entry and City gas.
    """
    df = client.get_topic_history(
        SCI_PKG_GAS_KEY_DRIVERS,
        SCI_TOPIC_CONSUMPTION_STRUCTURE,
        years=years,
    )
    if df.empty:
        return df
    out = df[["month", "pub_date"]].copy()
    for sector in DEMAND_SECTORS + [DEMAND_SECTOR_CITY_GAS]:
        try:
            out[sector] = pd.to_numeric(df[_find_col(df, sector)], errors="coerce")
        except KeyError:  # e.g. no City gas column if only 2025+ requested
            out[sector] = np.nan
    # keep months where one of the classifications is complete
    total = out[DEMAND_SECTORS + [DEMAND_SECTOR_CITY_GAS]].fillna(0.0).sum(axis=1)
    out = out[np.isclose(total, 1.0, atol=0.02)]
    return out.sort_values("month").reset_index(drop=True)


def get_consumption_structure_forecast(client: SCIClient, pub_date=None) -> pd.DataFrame:
    """
    SCI 24-month consumption structure forecast: demand split by sector as
    fractions of total demand. Same columns as get_consumption_structure.
    """
    issue = client.get_package_data(SCI_PKG_GAS_FORECAST, pub_date)
    df = issue.sheet_by_topic(SCI_TOPIC_CONSUMPTION_STRUCTURE_FORECAST).to_dataframe()
    if df.empty:
        return df
    out = pd.DataFrame({
        "month": pd.to_datetime(df[df.columns[0]]).dt.to_period("M").dt.to_timestamp(),
        "pub_date": issue.pub_date,
    })
    for sector in DEMAND_SECTORS:
        out[sector] = pd.to_numeric(df[_find_col(df, sector)], errors="coerce")
    out[DEMAND_SECTOR_CITY_GAS] = np.nan  # forecasts only use the 6-sector split
    return out.sort_values("month").reset_index(drop=True)


def _get_net_imports(client: SCIClient, years, import_col: str, export_col: str) -> pd.DataFrame:
    """
    Monthly net imports (imports - exports, bcm) stitched across years from
    the S&D Balance Summary topic.

    Returns a DataFrame with columns: month (Timestamp), pub_date, value.
    """
    df = client.get_topic_history(
        SCI_PKG_GAS_KEY_DRIVERS,
        SCI_TOPIC_SD_BALANCE,
        years=years,
    )
    if df.empty:
        return df
    value = (
        pd.to_numeric(df[_find_col(df, import_col)], errors="coerce")
        - pd.to_numeric(df[_find_col(df, export_col)], errors="coerce")
    )
    return df[["month", "pub_date"]].assign(value=value)


def get_net_lng_imports(client: SCIClient, years) -> pd.DataFrame:
    """Monthly China net LNG imports (imports - re-exports, bcm)."""
    return _get_net_imports(client, years, "LNG import", "LNG export")


def get_net_png_imports(client: SCIClient, years) -> pd.DataFrame:
    """Monthly China net pipeline (PNG) imports (imports - exports, bcm)."""
    return _get_net_imports(client, years, "PNG import", "PNG export")


def _get_net_import_forecast(
    client: SCIClient,
    import_topic: str,
    export_col: str,
    pub_date=None,
) -> pd.DataFrame:
    """
    A 24-month import forecast (latest issue or a historical vintage), netted
    of the corresponding export forecast taken from the S&D balance forecast
    topic of the same issue. Confidence limits are shifted by the (point)
    export forecast, since SCI publishes no limits for exports.

    Returns a DataFrame with columns: month, value, lower, upper, pub_date.
    """
    issue = client.get_package_data(SCI_PKG_GAS_FORECAST, pub_date)
    imports = _forecast_frame(issue, import_topic)
    if imports.empty:
        return imports

    balance = issue.sheet_by_topic(SCI_TOPIC_SD_BALANCE_FORECAST).to_dataframe()
    exports = pd.DataFrame({
        "month": pd.to_datetime(balance[balance.columns[0]]).dt.to_period("M").dt.to_timestamp(),
        "export": pd.to_numeric(
            balance[_find_col(balance, export_col)], errors="coerce"
        ),
    })

    out = imports.merge(exports, on="month", how="left")
    out["export"] = out["export"].fillna(0.0)
    for col in ("value", "lower", "upper"):
        out[col] = out[col] - out["export"]
    return out.drop(columns="export")


def get_net_lng_import_forecast(client: SCIClient, pub_date=None) -> pd.DataFrame:
    """Latest (or vintage) net LNG import forecast (imports - re-exports, bcm)."""
    return _get_net_import_forecast(
        client, SCI_TOPIC_LNG_IMPORT_FORECAST, "LNG export", pub_date
    )


def get_net_png_import_forecast(client: SCIClient, pub_date=None) -> pd.DataFrame:
    """Latest (or vintage) net pipeline (PNG) import forecast (imports - exports, bcm)."""
    return _get_net_import_forecast(
        client, SCI_TOPIC_PNG_IMPORT_FORECAST, "PNG export", pub_date
    )


def _get_forecast_vintages(
    client: SCIClient,
    fetch_one,
    n_previous: int,
    step_weeks: int,
    anchor_date=None,
) -> pd.DataFrame:
    """
    The latest forecast plus n_previous historical vintages (issues are
    published weekly on Fridays, so consecutive ones barely differ).

    Without an anchor_date, vintages sit at step_weeks intervals: each is the
    nearest available issue on or before (latest - k * step_weeks), which
    handles the occasional skipped week.

    With an anchor_date, the oldest vintage is pinned to the last issue on or
    before that date and the remaining n_previous - 1 vintages are spaced
    evenly between the anchor and the latest issue, so the anchor stays fixed
    as new issues are published.

    Note the SCI forecast datapack only serves issues from the current and
    previous calendar year - anything older returns 'Data overdue' and is
    skipped.

    fetch_one(pub_date) must return a forecast frame with a pub_date column.
    """
    package = client.get_package(SCI_PKG_GAS_FORECAST)
    available = package.all_dates()
    latest = package.latest_date

    chosen = {latest}
    if anchor_date is not None:
        anchor = package.last_issue_on_or_before(
            pd.Timestamp(anchor_date).to_pydatetime()
        )
        if anchor is not None and anchor < latest:
            chosen.add(anchor)
            span = latest - anchor
            for k in range(1, n_previous):
                target = anchor + span * (k / n_previous)
                eligible = [d for d in available if d <= target]
                if eligible:
                    chosen.add(max(eligible))
    else:
        for k in range(1, n_previous + 1):
            target = latest - timedelta(weeks=k * step_weeks)
            eligible = [d for d in available if d <= target]
            if eligible:
                chosen.add(max(eligible))

    frames = []
    for pub_date in sorted(chosen):
        try:
            frames.append(fetch_one(pub_date))
        except (SCIError, KeyError):
            # issue outside the served window ('Data overdue') or topic missing
            continue

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def get_domestic_production_forecast_history(
    client: SCIClient,
    n_previous: int = 4,
    step_weeks: int = 4,
    anchor_date=None,
) -> pd.DataFrame:
    """
    Latest + n_previous vintages of the NG output forecast (see
    _get_forecast_vintages for the selection logic). One DataFrame with
    columns month, value, lower, upper, pub_date; one vintage per pub_date.
    """
    return _get_forecast_vintages(
        client,
        lambda d: _get_forecast_topic(client, SCI_TOPIC_PRODUCTION_FORECAST, d),
        n_previous,
        step_weeks,
        anchor_date,
    )


def get_apparent_consumption_forecast_history(
    client: SCIClient,
    n_previous: int = 4,
    step_weeks: int = 4,
    anchor_date=None,
) -> pd.DataFrame:
    """
    Latest + n_previous vintages of the apparent consumption forecast (see
    _get_forecast_vintages for the selection logic).
    """
    return _get_forecast_vintages(
        client,
        lambda d: _get_forecast_topic(client, SCI_TOPIC_CONSUMPTION_FORECAST, d),
        n_previous,
        step_weeks,
        anchor_date,
    )


def get_net_lng_import_forecast_history(
    client: SCIClient,
    n_previous: int = 4,
    step_weeks: int = 4,
    anchor_date=None,
) -> pd.DataFrame:
    """
    Latest + n_previous vintages of the net LNG import forecast (imports
    netted of re-exports; see _get_forecast_vintages for selection logic).
    """
    return _get_forecast_vintages(
        client,
        lambda d: get_net_lng_import_forecast(client, d),
        n_previous,
        step_weeks,
        anchor_date,
    )


def get_net_png_import_forecast_history(
    client: SCIClient,
    n_previous: int = 4,
    step_weeks: int = 4,
    anchor_date=None,
) -> pd.DataFrame:
    """
    Latest + n_previous vintages of the net PNG import forecast (imports
    netted of exports; see _get_forecast_vintages for selection logic).
    """
    return _get_forecast_vintages(
        client,
        lambda d: get_net_png_import_forecast(client, d),
        n_previous,
        step_weeks,
        anchor_date,
    )


def generate_production_yoy_table(
    df: pd.DataFrame,
    df_forecast: pd.DataFrame = None,
) -> str:
    """
    HTML table of annual production totals and year-on-year growth.

    Complete historical years use actuals; the current year combines actuals
    with the SCI forecast for the remaining months (marked 'E'); the next
    year is the SCI forecast (marked 'F').
    """
    monthly = df.dropna(subset=["value"]).set_index("month")["value"].sort_index()
    last_actual = monthly.index.max()
    current_year = last_actual.year

    counts = monthly.groupby(monthly.index.year).count()
    sums = monthly.groupby(monthly.index.year).sum()

    totals = {}  # year -> (total_bcm, suffix)
    for year in sums.index:
        if counts[year] == 12:
            totals[year] = (sums[year], "")

    if df_forecast is not None and not df_forecast.empty:
        fc = df_forecast[df_forecast["month"] > last_actual]
        fc_current = fc[fc["month"].dt.year == current_year]
        if int(counts.get(current_year, 0)) + len(fc_current) == 12:
            totals[current_year] = (
                sums[current_year] + fc_current["value"].sum(), "E"
            )
        fc_next = fc[fc["month"].dt.year == current_year + 1]
        if len(fc_next) == 12:
            totals[current_year + 1] = (fc_next["value"].sum(), "F")

    th = TABLE_TH_STYLE
    td = TABLE_TD_STYLE

    rows_html = ""
    for year in sorted(totals):
        total, suffix = totals[year]
        prev = totals.get(year - 1)
        if prev:
            growth = 100.0 * (total / prev[0] - 1.0)
            colour = "#1e8449" if growth >= 0 else "#c0392b"
            growth_html = f"<span style='color:{colour};'>{growth:+.1f}%</span>"
        else:
            growth_html = "&ndash;"
        year_label = f"{year}{suffix}"
        style = td if not suffix else td + " font-style:italic;"
        rows_html += (
            f"<tr><td style='{style}'>{year_label}</td>"
            f"<td style='{style}'>{total:,.1f}</td>"
            f"<td style='{style}'>{growth_html}</td></tr>"
        )

    return f"""<table style="border-collapse:collapse; margin:0;">
  <tr><th style="{th}">Year</th><th style="{th}">Total (bcm)</th><th style="{th}">YoY</th></tr>
  {rows_html}
</table>
<p style="{TABLE_NOTE_STYLE}">
  E = actuals to {last_actual.strftime('%b')} + SCI forecast &nbsp;|&nbsp; F = SCI forecast
</p>"""


def generate_domestic_production_chart(
    df: pd.DataFrame,
    df_forecast: pd.DataFrame = None,
    title: str = "China Domestic Natural Gas Production",
    ylabel: str = "bcm / month",
    note: str = None,
    current_month_label: str = None,
) -> str:
    """
    Seasonal chart of a monthly series: one line per year, current year
    highlighted. If a forecast frame is given (month, value, lower, upper),
    months after the last actual are drawn as dashed lines with a shaded
    confidence band. current_month_label, if given, is annotated onto the
    first forecast point (used on the Kpler charts to show the actual vs
    ETA split of the current month). Returns a base64-encoded PNG.
    """
    pivot = df.pivot_table(
        index=df["month"].dt.month, columns=df["month"].dt.year, values="value"
    )
    years = sorted(pivot.columns)
    current_year = years[-1]

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")

    # older years fade from light to dark teal (oldest lightest); the
    # previous year is blue and the current year red
    older_years = [y for y in years if y < current_year - 1]
    teals = ["#c2e1da", "#8ac3b6", "#54a291", "#2f7d6c", "#1d5c4f"]
    for year in years:
        if year == current_year:
            ax.plot(pivot.index, pivot[year], color="#c0392b", linewidth=2.4,
                    marker="o", markersize=4.5, label=str(year), zorder=5)
        elif year == current_year - 1:
            ax.plot(pivot.index, pivot[year], color="#2c6fbb", linewidth=1.6,
                    label=str(year), zorder=4)
        else:
            colour = teals[older_years.index(year) % len(teals)]
            ax.plot(pivot.index, pivot[year], color=colour, linewidth=1.3,
                    label=str(year), zorder=3)

    # Overlay the SCI forecast as dashed continuations with confidence bands
    n_forecast_lines = 0
    if df_forecast is not None and not df_forecast.empty:
        last_actual = df.dropna(subset=["value"]).iloc[-1]
        fc = df_forecast[df_forecast["month"] > last_actual["month"]]
        fc_colors = {current_year: "#c0392b", current_year + 1: "#e67e22"}
        for year, color in fc_colors.items():
            sub = fc[fc["month"].dt.year == year].sort_values("month")
            if sub.empty:
                continue
            x = sub["month"].dt.month.tolist()
            y = sub["value"].tolist()
            if year == last_actual["month"].year:
                # join the dashed line onto the last actual point
                x = [last_actual["month"].month] + x
                y = [last_actual["value"]] + y
            ax.plot(x, y, color=color, linewidth=1.8, linestyle="--",
                    label=f"{year} fcst", zorder=4)
            ax.fill_between(sub["month"].dt.month, sub["lower"], sub["upper"],
                            color=color, alpha=0.12, linewidth=0, zorder=2)
            n_forecast_lines += 1

        if current_month_label and not fc.empty:
            first = fc.sort_values("month").iloc[0]
            ax.annotate(
                current_month_label,
                xy=(first["month"].month, first["value"]),
                xytext=(14, -32), textcoords="offset points",
                fontsize=8, color="#444444", zorder=6,
                arrowprops=dict(arrowstyle="-", color="#888888", linewidth=0.8),
                bbox=dict(boxstyle="round,pad=0.3", facecolor="white",
                          edgecolor="#cccccc", alpha=0.85))

    ax.set_xticks(range(1, 13))
    ax.set_xticklabels(
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], fontsize=9)
    ax.tick_params(axis="y", labelsize=9)
    ax.set_ylabel(ylabel, fontsize=10)
    ax.set_title(title, fontsize=12,
                 fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=9, frameon=False, ncol=len(years) + n_forecast_lines,
              loc="upper center", bbox_to_anchor=(0.5, -0.12))

    if note is None:
        latest = df.dropna(subset=["value"]).iloc[-1]
        note = (f"Latest actual: {latest['month'].strftime('%b %Y')}"
                "  |  Source: SCI (band = SCI confidence limits)")
    ax.annotate(note, xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
                fontsize=8, color="#777777")

    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format="png", bbox_inches="tight", facecolor="white",
                edgecolor="none", dpi=110)
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode("utf-8")
    buffer.close()
    plt.close(fig)

    return plot_base64


def _fig_to_base64(fig) -> str:
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png", bbox_inches="tight", facecolor="white",
                edgecolor="none", dpi=110)
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode("utf-8")
    buffer.close()
    plt.close(fig)
    return plot_base64


def generate_supply_demand_chart(
    df_prod: pd.DataFrame,
    df_demand: pd.DataFrame,
    df_prod_fcst: pd.DataFrame = None,
    df_demand_fcst: pd.DataFrame = None,
) -> str:
    """
    Two-panel time-series chart:
      - top: domestic production vs total demand (apparent consumption), SCI
        forecasts dashed with confidence limits shaded;
      - bottom: production as % of total demand as bars (forecast-derived
        months lighter) with a trailing 12-month average trend line.
    Returns a base64-encoded PNG.
    """
    share_colour = "#7d3c98"

    fig, (ax, ax2) = plt.subplots(
        2, 1, figsize=(10, 6.8), facecolor="white", sharex=True,
        gridspec_kw={"height_ratios": [2.1, 1.0], "hspace": 0.08},
    )

    # ── Top panel: levels ─────────────────────────────────────────────────
    series = [
        ("Total demand (apparent consumption)", df_demand, df_demand_fcst, "#2c6fbb"),
        ("Domestic production", df_prod, df_prod_fcst, "#c0392b"),
    ]
    for label, actual, forecast, color in series:
        act = actual.dropna(subset=["value"]).sort_values("month")
        ax.plot(act["month"], act["value"], color=color, linewidth=1.8,
                label=label, zorder=4)
        if forecast is None or forecast.empty:
            continue
        last = act.iloc[-1]
        fc = forecast[forecast["month"] > last["month"]].sort_values("month")
        if fc.empty:
            continue
        # join the dashed forecast onto the last actual point
        x = [last["month"]] + fc["month"].tolist()
        y = [last["value"]] + fc["value"].tolist()
        ax.plot(x, y, color=color, linewidth=1.6, linestyle="--", zorder=4)
        ax.fill_between(fc["month"], fc["lower"], fc["upper"],
                        color=color, alpha=0.12, linewidth=0, zorder=2)

    ax.tick_params(axis="y", labelsize=9)
    ax.set_ylabel("bcm / month", fontsize=10)
    ax.set_title("China Gas: Domestic Production vs Total Demand", fontsize=12,
                 fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=9, frameon=False, ncol=2, loc="upper left")
    ax.annotate(
        "Bands = SCI confidence limits  |  Source: SCI",
        xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
        fontsize=8, color="#777777")

    # ── Bottom panel: production as % of demand ──────────────────────────
    act_pct = pd.merge(
        df_prod.dropna(subset=["value"])[["month", "value"]].rename(columns={"value": "prod"}),
        df_demand.dropna(subset=["value"])[["month", "value"]].rename(columns={"value": "demand"}),
        on="month",
    ).sort_values("month")
    act_pct["pct"] = 100.0 * act_pct["prod"] / act_pct["demand"]

    fc_pct = pd.DataFrame(columns=["month", "pct"])
    if (df_prod_fcst is not None and not df_prod_fcst.empty
            and df_demand_fcst is not None and not df_demand_fcst.empty):
        fc_pct = pd.merge(
            df_prod_fcst[["month", "value"]].rename(columns={"value": "prod"}),
            df_demand_fcst[["month", "value"]].rename(columns={"value": "demand"}),
            on="month",
        ).sort_values("month")
        fc_pct = fc_pct[fc_pct["month"] > act_pct["month"].max()]
        fc_pct["pct"] = 100.0 * fc_pct["prod"] / fc_pct["demand"]

    bar_width = 22  # days
    ax2.bar(act_pct["month"], act_pct["pct"], width=bar_width,
            color=share_colour, alpha=0.85, label="Prod % of demand", zorder=3)
    if not fc_pct.empty:
        ax2.bar(fc_pct["month"], fc_pct["pct"], width=bar_width,
                color=share_colour, alpha=0.35, label="Forecast", zorder=3)

    # trailing 12-month average across actuals + forecast
    combined = pd.concat([
        act_pct[["month", "pct"]], fc_pct[["month", "pct"]]
    ]).set_index("month")["pct"].sort_index()
    ma = combined.rolling(12).mean()
    last_actual_month = act_pct["month"].max()
    ma_act = ma[ma.index <= last_actual_month]
    ma_fc = ma[ma.index >= last_actual_month]  # overlap one point to join lines
    ax2.plot(ma_act.index, ma_act.values, color="#222222", linewidth=1.6,
             label="12m avg", zorder=5)
    if len(ma_fc) > 1:
        ax2.plot(ma_fc.index, ma_fc.values, color="#222222", linewidth=1.4,
                 linestyle="--", zorder=5)

    pct_all = combined.dropna()
    ax2.set_ylim(max(0, pct_all.min() - 5), pct_all.max() + 4)
    ax2.xaxis.set_major_locator(mdates.YearLocator())
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    ax2.tick_params(axis="both", labelsize=9)
    ax2.set_ylabel("% of demand", fontsize=10)
    ax2.grid(True, alpha=0.3, linewidth=0.5, axis="y")
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.legend(fontsize=8, frameon=False, ncol=3, loc="upper center",
               bbox_to_anchor=(0.5, -0.18))

    # tight_layout is incompatible with sharex+gridspec here; savefig's
    # bbox_inches='tight' handles the trimming instead
    return _fig_to_base64(fig)


def generate_forecast_delta_table(
    df_prod: pd.DataFrame,
    df_vintages: pd.DataFrame,
) -> str:
    """
    HTML table showing each forecast vintage's implied annual production
    totals and the delta vs the previous displayed vintage.

    For each vintage the current-year total combines published actuals for
    months before the vintage's forecast window with the vintage's forecast
    for the remainder; the following year is pure forecast.
    """
    actuals = df_prod.dropna(subset=["value"]).set_index("month")["value"].sort_index()
    vintage_dates = sorted(pd.Timestamp(d) for d in df_vintages["pub_date"].unique())

    latest_start = df_vintages[
        df_vintages["pub_date"] == vintage_dates[-1]
    ]["month"].min()
    years = [latest_start.year, latest_start.year + 1]
    year_labels = {years[0]: f"{years[0]}E", years[1]: f"{years[1]}F"}

    totals: dict = {}
    for d in vintage_dates:
        vin = df_vintages[df_vintages["pub_date"] == d].set_index("month")["value"]
        totals[d] = {}
        for year in years:
            months = pd.date_range(f"{year}-01-01", f"{year}-12-01", freq="MS")
            vals = []
            for m in months:
                if m in vin.index:
                    vals.append(vin[m])
                elif m in actuals.index:
                    vals.append(actuals[m])
                else:
                    vals = None
                    break
            totals[d][year] = sum(vals) if vals is not None else None

    th = TABLE_TH_STYLE
    td = TABLE_TD_STYLE

    header = f"<th style='{th}'>Forecast</th>"
    for year in years:
        header += (f"<th style='{th}'>{year_labels[year]} (bcm)</th>"
                   f"<th style='{th}'>&Delta;</th>")

    rows_html = ""
    for i, d in enumerate(vintage_dates):
        label = d.strftime("%d %b-%y")
        if i == len(vintage_dates) - 1:
            label += " (latest)"
        cells = f"<td style='{td}'>{label}</td>"
        for year in years:
            total = totals[d][year]
            if total is None:
                cells += f"<td style='{td}'>&ndash;</td><td style='{td}'>&ndash;</td>"
                continue
            prev = totals[vintage_dates[i - 1]][year] if i > 0 else None
            if prev is not None:
                delta = total - prev
                colour = "#1e8449" if delta >= 0 else "#c0392b"
                delta_html = f"<span style='color:{colour};'>{delta:+.1f}</span>"
            else:
                delta_html = "&ndash;"
            cells += (f"<td style='{td}'>{total:,.1f}</td>"
                      f"<td style='{td}'>{delta_html}</td>")
        rows_html += f"<tr>{cells}</tr>"

    # Summary row: latest forecast vs the oldest displayed forecast (the
    # anchored pre-Iran issue when anchor_date is in use)
    if len(vintage_dates) >= 2:
        base, last = vintage_dates[0], vintage_dates[-1]
        td_sum = td + " border-top:2px solid #2c3e50; font-weight:600;"
        cells = f"<td style='{td_sum}'>Latest vs {base.strftime('%d %b-%y')}</td>"
        for year in years:
            t_base, t_last = totals[base][year], totals[last][year]
            if t_base is None or t_last is None:
                cells += (f"<td style='{td_sum}'>&ndash;</td>"
                          f"<td style='{td_sum}'>&ndash;</td>")
                continue
            delta = t_last - t_base
            colour = "#1e8449" if delta >= 0 else "#c0392b"
            cells += (f"<td style='{td_sum}'></td>"
                      f"<td style='{td_sum}'><span style='color:{colour};'>{delta:+.1f}</span></td>")
        rows_html += f"<tr>{cells}</tr>"

    return f"""<table style="border-collapse:collapse; margin:0;">
  <tr>{header}</tr>
  {rows_html}
</table>
<p style="{TABLE_NOTE_STYLE} max-width:340px;">
  Annual totals implied by each SCI forecast (published actuals + forecast
  for remaining months).<br>
  &Delta; = change vs previous forecast
</p>"""


def generate_production_forecast_history_chart(
    df_prod: pd.DataFrame,
    df_vintages: pd.DataFrame,
    start_date: str = "2025-01-01",
    title: str = "China Domestic Production: SCI Forecast Evolution",
) -> str:
    """
    Chart showing how an SCI forecast has evolved: actuals from start_date
    onwards (solid black) with each forecast vintage dashed - older vintages
    in progressively lighter blues, the latest in red with its confidence
    band. Returns a base64-encoded PNG.
    """
    act = df_prod.dropna(subset=["value"]).sort_values("month")
    act = act[act["month"] >= pd.Timestamp(start_date)]
    last_actual = act.iloc[-1]

    vintage_dates = sorted(df_vintages["pub_date"].unique())
    latest_vintage = vintage_dates[-1]
    older = vintage_dates[:-1]
    blues = plt.cm.Blues(np.linspace(0.4, 0.85, max(len(older), 1)))

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")
    ax.plot(act["month"], act["value"], color="#222222", linewidth=2.0,
            label="Actual", zorder=6)

    for pub_date, colour in zip(older, blues):
        vin = df_vintages[df_vintages["pub_date"] == pub_date].sort_values("month")
        label = pd.Timestamp(pub_date).strftime("fcst %d %b %y")
        ax.plot(vin["month"], vin["value"], color=colour, linewidth=1.3,
                linestyle="--", label=label, zorder=4)

    vin = df_vintages[df_vintages["pub_date"] == latest_vintage].sort_values("month")
    # join the latest vintage onto the last actual point
    fc = vin[vin["month"] > last_actual["month"]]
    x = [last_actual["month"]] + fc["month"].tolist()
    y = [last_actual["value"]] + fc["value"].tolist()
    ax.plot(x, y, color="#c0392b", linewidth=1.8, linestyle="--",
            label=pd.Timestamp(latest_vintage).strftime("fcst %d %b %y (latest)"),
            zorder=5)
    ax.fill_between(fc["month"], fc["lower"], fc["upper"], color="#c0392b",
                    alpha=0.10, linewidth=0, zorder=2)

    ax.xaxis.set_major_locator(mdates.YearLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    ax.xaxis.set_minor_locator(mdates.MonthLocator(bymonth=(4, 7, 10)))
    ax.xaxis.set_minor_formatter(mdates.DateFormatter("%b"))
    ax.tick_params(axis="x", which="minor", labelsize=7, colors="#888888")
    ax.tick_params(axis="both", labelsize=9)
    ax.set_ylabel("bcm / month", fontsize=10)
    ax.set_title(title, fontsize=12,
                 fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=8, frameon=False, ncol=3, loc="upper center",
              bbox_to_anchor=(0.5, -0.14))
    ax.annotate(
        "Band = latest forecast confidence limits  |  Source: SCI",
        xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
        fontsize=8, color="#777777")

    plt.tight_layout()
    return _fig_to_base64(fig)


# ── Demand breakdown (consumption structure) ────────────────────────────────
#
# SCI publish the sector split of total demand only as percentages, so the
# bcm-per-sector view is derived here: sector share x total apparent
# consumption (both actuals where published, SCI forecasts thereafter).


def get_demand_sector_annual(
    df_shares: pd.DataFrame,
    df_shares_fcst: pd.DataFrame,
    df_dem: pd.DataFrame,
    df_dem_fcst: pd.DataFrame,
) -> pd.DataFrame:
    """
    Implied annual demand per sector (bcm) for complete calendar years:
    monthly sector shares applied to monthly total demand, summed by year.

    Returns a DataFrame indexed by sector (including the pre-2025 City gas
    bucket, zero in years using the 6-sector split) with one column per year
    label - plain year for pure actuals, 'E' where actuals are topped up
    with forecast months, 'F' for all-forecast years.
    """
    sectors = DEMAND_SECTORS + [DEMAND_SECTOR_CITY_GAS]
    shares = df_shares[["month"] + sectors].copy()
    shares["share_fcst"] = False
    if df_shares_fcst is not None and not df_shares_fcst.empty:
        extra = df_shares_fcst[df_shares_fcst["month"] > shares["month"].max()]
        extra = extra[["month"] + sectors].copy()
        extra["share_fcst"] = True
        shares = pd.concat([shares, extra], ignore_index=True)

    dem = df_dem.dropna(subset=["value"])[["month", "value"]].copy()
    dem["dem_fcst"] = False
    if df_dem_fcst is not None and not df_dem_fcst.empty:
        extra = df_dem_fcst[df_dem_fcst["month"] > dem["month"].max()]
        extra = extra[["month", "value"]].copy()
        extra["dem_fcst"] = True
        dem = pd.concat([dem, extra], ignore_index=True)

    monthly = shares.merge(dem, on="month", how="inner").sort_values("month")
    for sector in sectors:
        monthly[sector] = monthly[sector] * monthly["value"]
    monthly["is_fcst"] = monthly["share_fcst"] | monthly["dem_fcst"]

    annual = {}
    for year, grp in monthly.groupby(monthly["month"].dt.year):
        if len(grp) < 12:
            continue
        if not grp["is_fcst"].any():
            label = str(year)
        elif grp["is_fcst"].all():
            label = f"{year}F"
        else:
            label = f"{year}E"
        annual[label] = grp[sectors].sum()  # absent sectors sum to 0
    return pd.DataFrame(annual)


def generate_demand_breakdown_chart(
    df_shares: pd.DataFrame,
    df_shares_fcst: pd.DataFrame = None,
    title: str = "China Gas Demand by Sector: Share of Total",
) -> str:
    """
    100% stacked monthly bars of the sector split of demand, actuals plus
    the SCI forecast (lighter bars after the dashed divider). Returns a
    base64-encoded PNG.
    """
    hist = df_shares.sort_values("month")
    last_actual = hist["month"].max()
    fc = pd.DataFrame(columns=["month"] + DEMAND_SECTORS)
    if df_shares_fcst is not None and not df_shares_fcst.empty:
        fc = df_shares_fcst[df_shares_fcst["month"] > last_actual].sort_values("month")

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")
    for part, alpha, labelled in ((hist, 0.9, True), (fc, 0.45, False)):
        if part.empty:
            continue
        bottom = np.zeros(len(part))
        for sector in DEMAND_SECTORS_DISPLAY:
            vals = part[sector].fillna(0.0).to_numpy() * 100.0
            ax.bar(part["month"], vals, bottom=bottom, width=24,
                   color=DEMAND_SECTOR_COLORS[sector], alpha=alpha, linewidth=0,
                   label=(DEMAND_SECTOR_LABELS.get(sector, sector)
                          if labelled and vals.any() else None),
                   zorder=3)
            bottom += vals

    if not fc.empty:
        ax.axvline(last_actual + pd.Timedelta(days=16), color="#555555",
                   linewidth=1.0, linestyle="--", zorder=4)

    ax.set_ylim(0, 100)
    ax.xaxis.set_major_locator(mdates.YearLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    ax.xaxis.set_minor_locator(mdates.MonthLocator(bymonth=(4, 7, 10)))
    ax.xaxis.set_minor_formatter(mdates.DateFormatter("%b"))
    ax.tick_params(axis="x", which="minor", labelsize=7, colors="#888888")
    ax.tick_params(axis="both", labelsize=9)
    ax.set_ylabel("% of total demand", fontsize=10)
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left", color="#2c3e50")
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=8, frameon=False, ncol=3, loc="upper center",
              bbox_to_anchor=(0.5, -0.14))
    ax.annotate(
        f"Actuals to {last_actual.strftime('%b %Y')}, SCI forecast after dashed line  |  Source: SCI",
        xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
        fontsize=8, color="#777777")

    plt.tight_layout()
    return _fig_to_base64(fig)


def generate_demand_sector_annual_chart(
    annual: pd.DataFrame,
    title: str = "China Gas Demand by Sector (bcm)",
) -> str:
    """
    Stacked annual bars of implied demand per sector (bcm), from
    get_demand_sector_annual. Returns a base64-encoded PNG.
    """
    year_labels = list(annual.columns)
    x = np.arange(len(year_labels))
    grand_max = annual.sum().max()

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")
    bottom = np.zeros(len(year_labels))
    for sector in DEMAND_SECTORS_DISPLAY:
        vals = annual.loc[sector].to_numpy()
        ax.bar(x, vals, bottom=bottom, width=0.62,
               color=DEMAND_SECTOR_COLORS[sector], alpha=0.9, linewidth=0,
               label=(DEMAND_SECTOR_LABELS.get(sector, sector)
                      if vals.any() else None), zorder=3)
        for xi, (v, b) in enumerate(zip(vals, bottom)):
            if v > grand_max * 0.05:  # label segments big enough to fit text
                ax.text(xi, b + v / 2, f"{v:,.0f}", ha="center", va="center",
                        fontsize=8, color="white", zorder=4)
        bottom += vals
    for xi, total in enumerate(annual.sum()):
        ax.text(xi, total + grand_max * 0.015, f"{total:,.0f}", ha="center",
                va="bottom", fontsize=9, fontweight="bold", color="#2c3e50")

    ax.set_xticks(x)
    ax.set_xticklabels(year_labels, fontsize=10)
    ax.set_ylim(0, grand_max * 1.08)
    ax.tick_params(axis="y", labelsize=9)
    ax.set_ylabel("bcm / year", fontsize=10)
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, alpha=0.3, linewidth=0.5, axis="y")
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=8, frameon=False, ncol=4, loc="upper center",
              bbox_to_anchor=(0.5, -0.08))
    ax.annotate(
        "Source: SCI",
        xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
        fontsize=8, color="#777777")

    plt.tight_layout()
    return _fig_to_base64(fig)


def generate_demand_share_table(annual: pd.DataFrame) -> str:
    """
    HTML table of each sector's share of annual demand (%), by year, from
    get_demand_sector_annual.
    """
    shares = 100.0 * annual / annual.sum()
    th, td = TABLE_TH_STYLE, TABLE_TD_STYLE

    header = f"<th style='{th} text-align:left;'>Sector</th>"
    for year in shares.columns:
        header += f"<th style='{th}'>{year}</th>"

    rows_html = ""
    for sector in DEMAND_SECTORS_DISPLAY:
        name = DEMAND_SECTOR_LABELS.get(sector, sector)
        cells = f"<td style='{td} text-align:left;'>{name}</td>"
        for year in shares.columns:
            value = shares.loc[sector, year]
            cell = f"{value:.1f}%" if value > 0.05 else "&ndash;"
            cells += f"<td style='{td}'>{cell}</td>"
        rows_html += f"<tr>{cells}</tr>"

    return f"""<table style="border-collapse:collapse; margin:0;">
  <tr>{header}</tr>
  {rows_html}
</table>
<p style="{TABLE_NOTE_STYLE} max-width:640px;">
  Share of annual total demand. E = actuals + SCI forecast for remaining
  months &nbsp;|&nbsp; F = SCI forecast<br>
  Transport = SCI NGV (natural gas vehicles): mostly LNG-fuelled heavy
  trucks, plus CNG buses and taxis<br>
  City gas = SCI classification used before 2025, combining residential,
  public service &amp; commercial and transport
</p>"""


def generate_demand_sector_table(annual: pd.DataFrame) -> str:
    """
    HTML table of implied annual demand per sector (bcm) with year-on-year
    deltas, from get_demand_sector_annual. Shows which sectors drive the
    overall demand growth.
    """
    th, td = TABLE_TH_STYLE, TABLE_TD_STYLE
    years = list(annual.columns)

    header = f"<th style='{th} text-align:left;'>Sector</th>"
    for i, year in enumerate(years):
        header += f"<th style='{th}'>{year} (bcm)</th>"
        if i > 0:
            header += f"<th style='{th}'>&Delta;</th>"

    def row_cells(values, style, name):
        # a sector summing to ~0 for a year doesn't exist under that year's
        # classification (e.g. City gas from 2025) - show dashes, and only
        # show deltas where both years use the same classification
        cells = f"<td style='{style} text-align:left;'>{name}</td>"
        for i, year in enumerate(years):
            value = values[year] if values[year] > 0.05 else None
            cells += f"<td style='{style}'>{value:,.1f}</td>" if value is not None \
                else f"<td style='{style}'>&ndash;</td>"
            if i > 0:
                prev = values[years[i - 1]] if values[years[i - 1]] > 0.05 else None
                if value is not None and prev is not None:
                    delta = value - prev
                    colour = "#1e8449" if delta >= 0 else "#c0392b"
                    cells += (f"<td style='{style}'>"
                              f"<span style='color:{colour};'>{delta:+.1f}</span></td>")
                else:
                    cells += f"<td style='{style}'>&ndash;</td>"
        return cells

    rows_html = ""
    for sector in DEMAND_SECTORS_DISPLAY:
        name = DEMAND_SECTOR_LABELS.get(sector, sector)
        rows_html += f"<tr>{row_cells(annual.loc[sector], td, name)}</tr>"

    td_sum = td + " border-top:2px solid #2c3e50; font-weight:600;"
    rows_html += f"<tr>{row_cells(annual.sum(), td_sum, 'Total')}</tr>"

    return f"""<table style="border-collapse:collapse; margin:0;">
  <tr>{header}</tr>
  {rows_html}
</table>
<p style="{TABLE_NOTE_STYLE} max-width:640px;">
  Implied bcm = SCI sector share x total demand (published actuals + SCI
  forecast).<br>
  &Delta; = change vs previous year<br>
  Transport = SCI NGV (natural gas vehicles): mostly LNG-fuelled heavy
  trucks, plus CNG buses and taxis<br>
  City gas = SCI classification used before 2025, combining residential,
  public service &amp; commercial and transport
</p>"""


# ── Weekly summary (high-frequency SCI data) ────────────────────────────────


def _weekly_issue_dates(package, years) -> list:
    """
    One issue per requested year for weekly topics (each issue only carries
    the current year's weeks): the last issue of the year, or the latest
    issue for the current year.
    """
    dates = []
    for year in sorted({int(y) for y in years}):
        if year >= package.latest_date.year:
            pub_date = package.latest_date
        else:
            pub_date = package.last_issue_on_or_before(datetime(year, 12, 31))
            if pub_date is None or pub_date.year != year:
                continue
        if pub_date not in dates:
            dates.append(pub_date)
    return dates


def get_weekly_summary(client: SCIClient, years) -> pd.DataFrame:
    """
    China NG Industry Weekly Summary stitched across years.

    Unlike the monthly topics this sheet is transposed: rows are items (with
    Sub-category/Item/Unit columns), columns are week numbers, and the first
    data row carries each week's date. Each issue only holds the current
    year's weeks, so one issue per requested year is parsed - the last issue
    of the year, or the latest issue for the current year.

    Returns a long DataFrame with columns: date, item, unit, value, pub_date
    (item names are whitespace-normalised - SCI's carry stray newlines).
    """
    package = client.get_package(SCI_PKG_GAS_KEY_DRIVERS)

    frames = []
    for pub_date in _weekly_issue_dates(package, years):
        issue = client.get_package_data(SCI_PKG_GAS_KEY_DRIVERS, pub_date)
        try:
            df = issue.sheet_by_topic(SCI_TOPIC_WEEKLY_SUMMARY).to_dataframe()
        except KeyError:  # topic not present in this (older) issue
            continue
        if df.empty:
            continue
        week_cols = [c for c in df.columns if "week" in str(c).lower()]
        dates = pd.to_datetime(df.iloc[0][week_cols], errors="coerce")
        for _, row in df.iloc[1:].iterrows():
            frames.append(pd.DataFrame({
                "date": dates.values,
                "item": " ".join(str(row["Item"]).split()),
                "unit": str(row["Unit"]).strip(),
                "value": pd.to_numeric(row[week_cols], errors="coerce").values,
                "pub_date": issue.pub_date,
            }).dropna(subset=["date", "value"]))

    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True)
    return out.sort_values(["item", "date"]).reset_index(drop=True)


def get_weekly_item(df_weekly: pd.DataFrame, item: str):
    """
    One item's series from the get_weekly_summary output (name matching
    ignores case and whitespace). Returns (df, unit) where df has columns
    date, value.
    """
    key = " ".join(item.split()).casefold()
    sub = df_weekly[df_weekly["item"].str.casefold() == key]
    if sub.empty:
        available = sorted(df_weekly["item"].unique())
        raise KeyError(f"No weekly item matching {item!r}. Available: {available}")
    unit = sub["unit"].iloc[-1]
    return sub[["date", "value"]].sort_values("date").reset_index(drop=True), unit


def get_weekly_topic_history(client: SCIClient, topic: str, years) -> pd.DataFrame:
    """
    Stitch a weekly topic laid out with a 'Week' date column (e.g. LNG
    storage capacity / inventory rate) across years - one issue per year,
    as per get_weekly_summary.

    Returns the topic's columns plus 'date' (Timestamp) and 'pub_date',
    sorted by date.
    """
    package = client.get_package(SCI_PKG_GAS_KEY_DRIVERS)

    frames = []
    for pub_date in _weekly_issue_dates(package, years):
        issue = client.get_package_data(SCI_PKG_GAS_KEY_DRIVERS, pub_date)
        try:
            df = issue.sheet_by_topic(topic).to_dataframe()
        except KeyError:  # topic not present in this (older) issue
            continue
        if df.empty:
            continue
        df = df.assign(
            date=pd.to_datetime(df[_find_col(df, "Week")], errors="coerce"),
            pub_date=issue.pub_date,
        ).dropna(subset=["date"])
        frames.append(df)

    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True)
    return out.sort_values("date").reset_index(drop=True)


def get_lng_stock_levels(client: SCIClient, years) -> pd.DataFrame:
    """
    Weekly China LNG stock levels at liquefaction plants and import
    terminals: SCI publish storage capacity and a percentage fill (inventory
    rate) separately, so stocks = capacity x fill rate.

    Returns a DataFrame with columns: date, plant, terminal (gas-equivalent
    mcm, converted from SCI's liquid mcm via KPLER_M3_TO_MCM) plus
    plant_fill, terminal_fill (% of capacity - useful alongside the
    absolute levels since capacity keeps being built out).
    """
    capacity = get_weekly_topic_history(client, SCI_TOPIC_LNG_STORAGE_CAPACITY, years)
    rate = get_weekly_topic_history(client, SCI_TOPIC_LNG_INVENTORY_RATE, years)

    out = pd.merge(capacity, rate, on="date", suffixes=("_cap", "_rate"))
    for col in ("LNG plant", "LNG terminal"):
        cap = pd.to_numeric(out[_find_col(out, col + "_cap")], errors="coerce")
        fill = pd.to_numeric(out[_find_col(out, col + "_rate")], errors="coerce")
        # capacity x fill is liquid mcm (millions of m3 of LNG); convert to
        # gas-equivalent mcm with the same factor as the Kpler cargo volumes
        out[col] = cap * fill * 1e6 * KPLER_M3_TO_MCM
        out[col + " fill"] = fill * 100.0
    columns = {
        "LNG plant": "plant",
        "LNG terminal": "terminal",
        "LNG plant fill": "plant_fill",
        "LNG terminal fill": "terminal_fill",
    }
    return (out[["date"] + list(columns)]
            .rename(columns=columns)
            .dropna().sort_values("date").reset_index(drop=True))


def generate_weekly_seasonal_chart(
    df: pd.DataFrame,
    title: str,
    ylabel: str,
    figsize: tuple = (6.2, 4.2),
) -> str:
    """
    Seasonal (year-on-year) chart of a weekly series: one line per year,
    current year highlighted. Returns a base64-encoded PNG.
    """
    years = sorted(df["date"].dt.year.unique())
    current_year = years[-1]
    older_years = [y for y in years if y < current_year - 1]
    teals = ["#c2e1da", "#8ac3b6", "#54a291", "#2f7d6c", "#1d5c4f"]

    fig, ax = plt.subplots(figsize=figsize, facecolor="white")
    for year in years:
        sub = df[df["date"].dt.year == year].sort_values("date")
        x = sub["date"].dt.dayofyear
        if year == current_year:
            ax.plot(x, sub["value"], color="#c0392b", linewidth=2.2,
                    label=str(year), zorder=5)
        elif year == current_year - 1:
            ax.plot(x, sub["value"], color="#2c6fbb", linewidth=1.4,
                    label=str(year), zorder=4)
        else:
            colour = teals[older_years.index(year) % len(teals)]
            ax.plot(x, sub["value"], color=colour, linewidth=1.2,
                    label=str(year), zorder=3)

    month_starts = [pd.Timestamp(2025, m, 1).dayofyear for m in range(1, 13)]
    ax.set_xticks(month_starts)
    ax.set_xticklabels(
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], fontsize=8)
    ax.set_xlim(1, 366)
    ax.tick_params(axis="y", labelsize=8)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.set_title(title, fontsize=11, fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=8, frameon=False, ncol=len(years),
              loc="upper center", bbox_to_anchor=(0.5, -0.12))
    ax.annotate(
        f"Latest: {df['date'].max().strftime('%d %b %Y')}  |  Source: SCI",
        xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
        fontsize=7, color="#777777")

    plt.tight_layout()
    return _fig_to_base64(fig)


# ── Kpler LNG cargo trackings ───────────────────────────────────────────────
#
# Live cargo-level LNG trades from the Kpler LNG API: imports are dated and
# measured at the destination berth, re-exports at the origin. Cargo volumes
# (m3 of LNG) are converted to gas-equivalent mcm via KPLER_M3_TO_MCM.


def _kpler_lng_token(email: str, password: str) -> str:
    """Log in to the Kpler LNG API and return an access token."""
    response = requests.post(
        KPLER_LNG_BASE_URL + "login",
        json={"email": email, "password": password},
        timeout=60,
    )
    response.raise_for_status()
    return response.json()["token"]


def _kpler_lng_trades(token: str, **params) -> pd.DataFrame:
    """One Kpler LNG trades query (semicolon-separated CSV) as a DataFrame."""
    response = requests.get(
        KPLER_LNG_BASE_URL + "trades",
        params={"size": 10000, "columns": "all", **params},
        headers={"Authorization": token},
        timeout=120,
    )
    response.raise_for_status()
    return pd.read_csv(io.StringIO(response.text), delimiter=";", low_memory=False)


def _kpler_daily_volumes(trades: pd.DataFrame, date_col: str, volume_col: str) -> pd.DataFrame:
    """
    Cargo-level trades to a daily volume series (gas-equivalent mcm).
    Scheduled trades are excluded; other statuses are kept, so in-transit
    cargoes appear at their forecast (ETA) arrival date and future dates
    understate the final flow until further cargoes load. Cargo volumes are
    summed per day and days without a cargo are filled with real zeros so
    moving averages are correct.

    Returns a DataFrame with columns: date (Timestamp), value.
    """
    trades = trades[trades[_find_col(trades, "Trade status")] != "Scheduled"]
    daily = pd.DataFrame({
        "date": pd.to_datetime(trades[_find_col(trades, date_col)],
                               errors="coerce").dt.normalize(),
        "value": pd.to_numeric(trades[_find_col(trades, volume_col)],
                               errors="coerce") * KPLER_M3_TO_MCM,
    }).dropna().groupby("date")["value"].sum()
    idx = pd.date_range(daily.index.min(), daily.index.max(), freq="D")
    daily = daily.reindex(idx, fill_value=0.0)
    return pd.DataFrame({"date": daily.index, "value": daily.values})


def get_kpler_china_lng_flows(email: str, password: str, start_date: str = "2022-01-01",
                              origin_countries: dict = None):
    """
    Daily China LNG imports and re-exports from Kpler cargo trackings.
    Imports use the destination date/volume, re-exports the origin
    date/volume; scheduled cargoes are excluded.

    The API's startDate filters on loading date, so the query reaches back
    three months before start_date (cargoes loaded late in the prior period
    arrive after start_date) and the returned series are truncated back to
    start_date - otherwise the first month's arrivals look artificially low.

    Returns (df_imports, df_reexports), each with columns date, value
    (gas-equivalent mcm/day).

    Pass origin_countries as {display label: 'Country (origin)' value in the
    Kpler data}, e.g. {'Russia': 'Russian Federation'}, to also get:
      - {display label: df_imports for that origin}. Unlike the total flows
        these only include cargoes with a Delivered trade status (no
        in-transit/loading cargoes at forecast ETA).
      - a monthly imports-by-origin frame (month Period[M], origin, value
        in mcm) covering every origin country, same Delivered-only filter,
        for the stacked origin chart.
    """
    start = pd.Timestamp(start_date)
    query_start = (start - pd.DateOffset(months=3)).strftime("%Y-%m-%d")
    token = _kpler_lng_token(email, password)
    imports = _kpler_lng_trades(token, startDate=query_start, toZones="China")
    reexports = _kpler_lng_trades(token, startDate=query_start, fromZones="China")

    def _truncate(df):
        return df[df["date"] >= start].reset_index(drop=True)

    df_imports = _truncate(_kpler_daily_volumes(
        imports, "Date (destination)", "Volume (destination m3)"))
    df_reexports = _truncate(_kpler_daily_volumes(
        reexports, "Date (origin)", "Volume (origin m3)"))

    if origin_countries is None:
        return df_imports, df_reexports

    delivered = imports[imports[_find_col(imports, "Trade status")] == "Delivered"]
    country_col = _find_col(delivered, "Country (origin)")
    origin_flows = {
        label: _truncate(_kpler_daily_volumes(
            delivered[delivered[country_col] == country],
            "Date (destination)", "Volume (destination m3)"))
        for label, country in origin_countries.items()
    }
    origin_monthly = _kpler_monthly_imports_by_origin(delivered, start)
    return df_imports, df_reexports, origin_flows, origin_monthly


def _kpler_monthly_imports_by_origin(delivered: pd.DataFrame,
                                    start: pd.Timestamp) -> pd.DataFrame:
    """
    Delivered China LNG imports aggregated to calendar month and origin
    country. ``delivered`` is the trades frame already filtered to Trade
    status == Delivered.

    Returns columns: month (Period[M]), origin, value (gas-equivalent mcm).
    """
    if delivered.empty:
        return pd.DataFrame(columns=["month", "origin", "value"])
    df = pd.DataFrame({
        "month": pd.to_datetime(delivered[_find_col(delivered, "Date (destination)")],
                                errors="coerce").dt.to_period("M"),
        "origin": (delivered[_find_col(delivered, "Country (origin)")]
                   .fillna("Unknown").replace("", "Unknown")),
        "value": pd.to_numeric(delivered[_find_col(delivered, "Volume (destination m3)")],
                               errors="coerce") * KPLER_M3_TO_MCM,
    }).dropna(subset=["month", "value"])
    df = df[df["month"] >= start.to_period("M")]
    return df.groupby(["month", "origin"], as_index=False)["value"].sum()


# Shorter legend labels for the monthly origin stack. Unlisted Kpler
# country names are shown as returned.
_ORIGIN_DISPLAY = {
    "Russian Federation": "Russia",
    "United States": "US",
    "Papua New Guinea": "PNG",
    "United Arab Emirates": "UAE",
    "Trinidad and Tobago": "Trinidad",
    "Equatorial Guinea": "Eq. Guinea",
}
_ORIGIN_STACK_COLORS = [
    "#2c6fbb", "#c0392b", "#2f7d6c", "#e67e22",
    "#7d3c98", "#117a65", "#b7950b", "#1a5276",
    "#a04000", "#5d6d7e",
]
_ORIGIN_OTHER_COLOR = "#b0b8c1"


def _monthly_origin_stack(df_origin: pd.DataFrame, months: pd.PeriodIndex,
                          n_top: int = 4) -> pd.DataFrame:
    """
    Keep each month's own top ``n_top`` origin countries and sum the rest
    into Other. A country is absent (zero) in months where it falls outside
    that month's top origins, so its volume sits in Other instead.

    df_origin columns: month (Period[M]), origin, value. Returns a frame
    indexed by ``months``, columns ordered by total shown volume (largest
    first) with Other last. Values stay in the input units.
    """
    df = df_origin[df_origin["month"].isin(months)].copy()
    df["origin"] = df["origin"].map(lambda o: _ORIGIN_DISPLAY.get(o, o))
    rows = []
    for month in months:
        ranked = (df.loc[df["month"] == month]
                  .groupby("origin")["value"].sum()
                  .reset_index()
                  .sort_values(["value", "origin"], ascending=[False, True]))
        row = dict(zip(ranked["origin"].iloc[:n_top], ranked["value"].iloc[:n_top]))
        rest = ranked["value"].iloc[n_top:]
        if not rest.empty:
            row["Other"] = float(rest.sum())
        rows.append(row)
    pivot = pd.DataFrame(rows, index=months).fillna(0.0)
    countries = [c for c in pivot.columns if c != "Other"]
    countries.sort(key=lambda c: float(pivot[c].sum()), reverse=True)
    if "Other" in pivot.columns and float(pivot["Other"].sum()) > 0:
        countries.append("Other")
    return pivot.reindex(columns=countries, fill_value=0.0)


def generate_kpler_origin_monthly_chart(df_origin: pd.DataFrame,
                                        n_months: int = 12,
                                        n_top: int = 4) -> str:
    """
    Stacked bars of China LNG imports by origin for the last ``n_months``
    calendar months (through the current month), in bcm/month. Each month
    shows its own top ``n_top`` origin countries; every other origin that
    month is grouped into Other. Delivered cargoes only. The current month
    is incomplete and drawn lighter. Returns a base64-encoded PNG.
    """
    end = pd.Timestamp.now().to_period("M")
    months = pd.period_range(end - (n_months - 1), end, freq="M")
    pivot = _monthly_origin_stack(df_origin, months, n_top=n_top) / 1000.0

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")
    x = np.arange(len(months))
    bottom = np.zeros(len(months))
    complete = np.array(months < end)
    for i, origin in enumerate(pivot.columns):
        colour = (_ORIGIN_OTHER_COLOR if origin == "Other"
                  else _ORIGIN_STACK_COLORS[i % len(_ORIGIN_STACK_COLORS)])
        bars = ax.bar(x, pivot[origin].values, bottom=bottom, color=colour,
                      label=origin, width=0.72, zorder=3)
        for bar, is_complete in zip(bars, complete):
            if not is_complete:
                bar.set_alpha(0.45)
        bottom += pivot[origin].values

    ax.set_xticks(x)
    ax.set_xticklabels([p.strftime("%b-%y") for p in months],
                       fontsize=8, rotation=45, ha="right")
    ax.set_ylim(bottom=0)
    ax.tick_params(axis="y", labelsize=9)
    ax.set_ylabel("bcm / month", fontsize=10)
    ax.set_title("China LNG Imports by Origin (Kpler, monthly)",
                 fontsize=12, fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, axis="y", alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.annotate(
        f"Top {n_top} origins each month; rest as Other  |  Source: Kpler",
        xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
        fontsize=8, color="#777777")
    if len(pivot.columns):
        ax.legend(fontsize=8, frameon=False, ncol=min(4, len(pivot.columns)),
                  loc="upper center", bbox_to_anchor=(0.5, -0.28))

    plt.tight_layout()
    return _fig_to_base64(fig)


def _kpler_monthly_split(daily: pd.Series):
    """
    Aggregate a daily Kpler series to months and split it at the current
    month: months fully in the past are actuals, while the current and later
    months contain forecast (ETA) arrivals of in-transit cargoes and are
    returned separately so charts can draw them as a forecast.

    Returns (df_actual, df_forecast); df_forecast carries lower/upper set to
    the value so it plugs into the seasonal chart's forecast overlay.
    """
    monthly = daily.groupby(daily.index.to_period("M")).sum()
    current_period = pd.Timestamp.now().normalize().to_period("M")
    actual = monthly[monthly.index < current_period]
    forecast = monthly[monthly.index >= current_period]

    df_actual = pd.DataFrame({
        "month": actual.index.to_timestamp(),
        "value": actual.values,
    })
    df_forecast = pd.DataFrame({
        "month": forecast.index.to_timestamp(),
        "value": forecast.values,
    })
    df_forecast["lower"] = df_forecast["value"]
    df_forecast["upper"] = df_forecast["value"]
    return df_actual, df_forecast


def kpler_monthly_net_imports(df_imports: pd.DataFrame, df_reexports: pd.DataFrame):
    """
    Monthly net LNG imports (imports - re-exports, mcm/month) from the Kpler
    daily flows, split into actual months and months containing forecast
    (ETA) arrivals - see _kpler_monthly_split.

    Returns (df_actual, df_forecast) with columns month, value (+ lower/upper
    on the forecast frame).
    """
    imports = df_imports.set_index("date")["value"]
    reexports = df_reexports.set_index("date")["value"]
    return _kpler_monthly_split(imports.sub(reexports, fill_value=0.0))


def kpler_monthly_reexports(df_reexports: pd.DataFrame):
    """
    Monthly LNG re-exports (mcm/month) from the Kpler daily flows, split as
    per kpler_monthly_net_imports.
    """
    return _kpler_monthly_split(df_reexports.set_index("date")["value"])


def kpler_current_month_split(df_daily: pd.DataFrame, df_subtract: pd.DataFrame = None):
    """
    Actual vs forecast volume split of the current calendar month for a
    daily Kpler series: days up to today have happened, later days are
    in-transit cargoes at forecast ETA. Pass df_subtract to net one series
    off another (e.g. re-exports off imports).

    Returns (actual, eta) in the series' units (mcm).
    """
    daily = df_daily.set_index("date")["value"]
    if df_subtract is not None:
        daily = daily.sub(df_subtract.set_index("date")["value"], fill_value=0.0)
    today = pd.Timestamp.now().normalize()
    month = daily[daily.index.to_period("M") == today.to_period("M")]
    return month[month.index <= today].sum(), month[month.index > today].sum()


def generate_kpler_lng_daily_chart(
    df_imports: pd.DataFrame,
    df_reexports: pd.DataFrame,
    window: int = 10,
    title: str = None,
) -> str:
    """
    Seasonal (year-on-year) chart of daily net LNG imports (imports -
    re-exports) as a rolling mean: one line per year with the current year
    highlighted. The part of the current year beyond today reflects
    in-transit cargoes at their forecast (ETA) arrival date and is drawn
    dashed. Returns a base64-encoded PNG.
    """
    if title is None:
        title = f"China Net LNG Imports (Kpler, {window}d moving avg)"
    imports = df_imports.set_index("date")["value"]
    reexports = df_reexports.set_index("date")["value"]
    net = imports.sub(reexports, fill_value=0.0).sort_index()
    ma = net.rolling(window).mean().dropna()

    years = sorted(ma.index.year.unique())
    current_year = years[-1]
    older_years = [y for y in years if y < current_year - 1]
    teals = ["#c2e1da", "#8ac3b6", "#54a291", "#2f7d6c", "#1d5c4f"]
    today = pd.Timestamp.now().normalize()

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")
    for year in years:
        sub = ma[ma.index.year == year]
        if year == current_year:
            actual = sub[sub.index <= today]
            eta = sub[sub.index >= today]  # overlap one point to join lines
            ax.plot(actual.index.dayofyear, actual.values, color="#c0392b",
                    linewidth=2.2, label=str(year), zorder=5)
            if len(eta) > 1:
                ax.plot(eta.index.dayofyear, eta.values, color="#c0392b",
                        linewidth=1.8, linestyle="--", label=f"{year} ETA",
                        zorder=5)
        elif year == current_year - 1:
            ax.plot(sub.index.dayofyear, sub.values, color="#2c6fbb",
                    linewidth=1.4, label=str(year), zorder=4)
        else:
            colour = teals[older_years.index(year) % len(teals)]
            ax.plot(sub.index.dayofyear, sub.values, color=colour,
                    linewidth=1.2, label=str(year), zorder=3)

    month_starts = [pd.Timestamp(2025, m, 1).dayofyear for m in range(1, 13)]
    ax.set_xticks(month_starts)
    ax.set_xticklabels(
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], fontsize=9)
    ax.set_xlim(1, 366)
    ax.set_ylim(bottom=0)
    ax.tick_params(axis="y", labelsize=9)
    ax.set_ylabel("mcm/d", fontsize=10)
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=9, frameon=False, ncol=len(years) + 1,
              loc="upper center", bbox_to_anchor=(0.5, -0.12))
    ax.annotate(
        "Dashed = in-transit cargoes at forecast ETA  |  Source: Kpler",
        xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
        fontsize=8, color="#777777")

    plt.tight_layout()
    return _fig_to_base64(fig)


def generate_kpler_origin_grid_chart(origin_flows: dict, window: int = 30) -> str:
    """
    2x2 grid of small seasonal charts of daily LNG imports into China by
    origin country (rolling mean of delivered cargoes only - no forecast
    ETA data), sized to sit alongside the two stacked net import charts.
    Returns a base64-encoded PNG.
    """
    teals = ["#c2e1da", "#8ac3b6", "#54a291", "#2f7d6c", "#1d5c4f"]
    tick_months = [1, 3, 5, 7, 9, 11]
    month_starts = [pd.Timestamp(2025, m, 1).dayofyear for m in tick_months]
    month_labels = ["Jan", "Mar", "May", "Jul", "Sep", "Nov"]

    fig, axes = plt.subplots(2, 2, figsize=(7.5, 8.4), facecolor="white")
    legend_handles = {}

    for ax, (label, df) in zip(axes.flat, origin_flows.items()):
        ma = (df.set_index("date")["value"].sort_index()
              .rolling(window).mean().dropna())
        years = sorted(ma.index.year.unique())
        current_year = years[-1]
        older_years = [y for y in years if y < current_year - 1]
        for year in years:
            sub = ma[ma.index.year == year]
            if year == current_year:
                line, = ax.plot(sub.index.dayofyear, sub.values,
                                color="#c0392b", linewidth=1.8, zorder=5)
            elif year == current_year - 1:
                line, = ax.plot(sub.index.dayofyear, sub.values,
                                color="#2c6fbb", linewidth=1.2, zorder=4)
            else:
                colour = teals[older_years.index(year) % len(teals)]
                line, = ax.plot(sub.index.dayofyear, sub.values,
                                color=colour, linewidth=1.0, zorder=3)
            legend_handles.setdefault(str(year), line)

        ax.set_xticks(month_starts)
        ax.set_xticklabels(month_labels, fontsize=7)
        ax.set_xlim(1, 366)
        ax.set_ylim(bottom=0)
        ax.tick_params(axis="y", labelsize=7)
        ax.set_ylabel("mcm/d", fontsize=8)
        ax.set_title(label, fontsize=10, fontweight="bold", loc="left",
                     color="#2c3e50")
        ax.grid(True, alpha=0.3, linewidth=0.5)
        ax.spines[["top", "right"]].set_visible(False)

    fig.suptitle(f"China LNG Imports by Origin (Kpler, {window}d moving avg)",
                 fontsize=12, fontweight="bold", x=0.02, y=0.995,
                 ha="left", color="#2c3e50")
    fig.text(0.98, 0.955, "Delivered cargoes only  |  Source: Kpler",
             ha="right", fontsize=8, color="#777777")
    fig.legend(legend_handles.values(), legend_handles.keys(),
               fontsize=9, frameon=False, ncol=len(legend_handles),
               loc="lower center", bbox_to_anchor=(0.5, 0.0))
    plt.tight_layout(rect=(0, 0.035, 1, 0.94))
    return _fig_to_base64(fig)


# ── Sanctioned Russian LNG into PipeChina Beihai ────────────────────────────
#
# Beihai took its first sanctioned Russian cargo on 28 Aug 2025 and imports
# have ramped up since. Cargoes arrive direct from the sanctioned ALNG2
# (Arctic LNG 2) and Portovaya terminals or via the Murmansk and Kamchatka
# STS transfer locations. PipeChina Longkou is speculated to start receiving
# sanctioned cargoes too once online (currently expected Oct-26).

BEIHAI_INSTALLATION = "PipeChina Beihai"  # 'Installation Destination' in Kpler
BEIHAI_START_DATE = "2025-08-01"  # first sanctioned cargo berthed 28 Aug 2025
# Energy Aspects speculate all sanctioned Russian gas at Beihai is loaded
# onto trucks rather than sent into the grid (sanction concerns); their
# assumed max truck loading capacity is 0.21 Mt of LNG per month
BEIHAI_TRUCK_CAPACITY_MT = 0.21
BEIHAI_TRUCK_CAPACITY_MCM = BEIHAI_TRUCK_CAPACITY_MT * MT_TO_MCM  # ~293 mcm/month
# Origin terminals/STS locations as named in Kpler's 'Installation origin';
# fixed stack order and colours for the origin breakdown chart
BEIHAI_ORIGIN_COLORS = {
    "ALNG2": "#c0392b",
    "Murmansk STS": "#2c6fbb",
    "Kamchatka STS": "#2f7d6c",
    "Portovaya": "#e67e22",
}
BEIHAI_OTHER_COLOR = "#9aa7b0"  # any other Russian origin (e.g. Yamal)
ALNG2_INSTALLATION = "ALNG2"  # 'Installation origin' in Kpler
# Vessels flagged in the fleet table (asterisk + shaded row + footnote)
BEIHAI_FLEET_NOTES = {
    "Arctic Metagaz": ("destroyed in the Mediterranean Sea by a series of "
                       "Ukrainian drone strikes on 3 Mar 2026"),
}
# ALNG2 loaded its first (sanctioned) cargo in Aug 2024, so a query from
# here captures every loading at the terminal - any vessel that has ever
# lifted an ALNG2 cargo is part of the sanctioned fleet, even if it only
# shuttles to the Murmansk/Kamchatka STS and never discharges in China
ALNG2_LOADINGS_START = "2024-01-01"


def _kpler_lng_vessels(token: str) -> pd.DataFrame:
    """
    The Kpler LNG vessels endpoint (fleet characteristics) as a DataFrame.
    Unlike the trades endpoint it accepts no size parameter. The 'Carrier
    type' column carries the ice classification: ARC7 (ice-breaking LNG
    carriers built for Yamal/ALNG2), ARC4 (ice-strengthened) or Ocean
    (conventional).
    """
    response = requests.get(
        KPLER_LNG_BASE_URL + "vessels",
        params={"columns": "all"},
        headers={"Authorization": token},
        timeout=120,
    )
    response.raise_for_status()
    return pd.read_csv(io.StringIO(response.text), delimiter=";", low_memory=False)


def _fleet_activity_rows(trades: pd.DataFrame, date_col: str) -> pd.DataFrame:
    """Vessel/IMO/date rows for the fleet table from raw Kpler trades."""
    return pd.DataFrame({
        "vessel": trades[_find_col(trades, "Vessel")],
        "imo": pd.to_numeric(trades[_find_col(trades, "IMO (vessel)")], errors="coerce"),
        "date": pd.to_datetime(trades[_find_col(trades, date_col)],
                               errors="coerce").dt.normalize(),
    }).dropna(subset=["date"])


def get_kpler_beihai_russian_imports(email: str, password: str,
                                     start_date: str = BEIHAI_START_DATE):
    """
    Russian LNG imports into PipeChina Beihai plus the sanctioned fleet
    from the Kpler trade trackings.

    df_cargoes has one row per discharge at the terminal, dated and
    measured at the destination berth. Scheduled trades are excluded but
    in-transit cargoes (at their forecast ETA) are kept, so the current/
    future months are incomplete. As per the total China flows, the API's
    startDate filters on loading date so the query reaches back four months
    before start_date (Murmansk cargoes are ~1.5 months on the water) and
    the result is truncated back to start_date.

    df_fleet has one row per sanctioned activity: every loading at ALNG2
    since ALNG2_LOADINGS_START (one per loading port call, dated at the
    loading berth - this catches vessels that only shuttle ALNG2 cargoes to
    the Murmansk/Kamchatka STS and never discharge in China), plus every
    Russian discharge at Beihai from any other origin (dated at the
    discharge berth). Direct ALNG2->Beihai cargoes sit in the loadings set
    only, so nothing is double counted. Each row carries the vessel's ice
    classification ('Carrier type': ARC7/ARC4/Ocean) and Kpler vessel id
    (for deep links into the Kpler terminal UI), both from the Kpler
    vessels endpoint matched on IMO.

    Returns (df_cargoes, df_fleet):
      - df_cargoes: date (Timestamp), origin, value (gas-equivalent mcm), status
      - df_fleet: vessel, ice_class, vessel_id, date (Timestamp)
    """
    start = pd.Timestamp(start_date)
    query_start = (start - pd.DateOffset(months=4)).strftime("%Y-%m-%d")
    token = _kpler_lng_token(email, password)
    trades = _kpler_lng_trades(token, startDate=query_start, toZones="China")
    trades = trades[trades[_find_col(trades, "Trade status")] != "Scheduled"]
    beihai = trades[
        (trades[_find_col(trades, "Installation Destination")] == BEIHAI_INSTALLATION)
        & (trades[_find_col(trades, "Country (origin)")] == "Russian Federation")
    ]
    df_cargoes = pd.DataFrame({
        "date": pd.to_datetime(beihai[_find_col(beihai, "Date (destination)")],
                               errors="coerce").dt.normalize(),
        "origin": beihai[_find_col(beihai, "Installation origin")].fillna("Unknown"),
        "value": pd.to_numeric(beihai[_find_col(beihai, "Volume (destination m3)")],
                               errors="coerce") * KPLER_M3_TO_MCM,
        "status": beihai[_find_col(beihai, "Trade status")],
    }).dropna(subset=["date", "value"])
    df_cargoes = (df_cargoes[df_cargoes["date"] >= start]
                  .sort_values("date").reset_index(drop=True))

    # Sanctioned fleet: all ALNG2 loadings (deduplicated per loading port
    # call - a cargo split across several discharges is one loading) plus
    # Beihai discharges from other origins over the chart window
    alng2 = _kpler_lng_trades(token, startDate=ALNG2_LOADINGS_START,
                              fromInstallations=ALNG2_INSTALLATION)
    alng2 = alng2[alng2[_find_col(alng2, "Trade status")] != "Scheduled"]
    alng2 = alng2.drop_duplicates(subset=[_find_col(alng2, "Origin PortCall Id")])
    other = beihai[beihai[_find_col(beihai, "Installation origin")] != ALNG2_INSTALLATION]
    df_fleet = pd.concat([
        _fleet_activity_rows(alng2, "Date (origin)"),
        _fleet_activity_rows(other, "Date (destination)").query("date >= @start"),
    ], ignore_index=True)

    vessels = _kpler_lng_vessels(token)
    vessel_imos = pd.to_numeric(vessels[_find_col(vessels, "IMO")], errors="coerce")
    ice_class = pd.Series(vessels[_find_col(vessels, "Carrier type")].values,
                          index=vessel_imos)
    vessel_ids = pd.Series(
        pd.to_numeric(vessels[_find_col(vessels, "Vessel id")], errors="coerce").values,
        index=vessel_imos)
    df_fleet["ice_class"] = df_fleet["imo"].map(ice_class).fillna("?")
    df_fleet["vessel_id"] = df_fleet["imo"].map(vessel_ids)
    df_fleet = (df_fleet.drop(columns="imo")
                .sort_values("date").reset_index(drop=True))

    return df_cargoes, df_fleet


def get_beihai_truck_loadings(client: SCIClient,
                              start_date: str = BEIHAI_START_DATE) -> pd.DataFrame:
    """
    Monthly LNG truck loadings out of the PipeChina Beihai terminal from
    SCI's daily terminal truck loading topic (kt of LNG per day by
    terminal; each issue carries one calendar year, stitched per year as
    per the weekly topics). Daily kt are summed per month and converted to
    gas-equivalent mcm (kt -> Mt -> mcm via MT_TO_MCM). Months whose daily
    data doesn't reach month end (SCI publish a few days behind) are
    dropped so the series only shows complete months.

    Returns a DataFrame with columns: month (Period[M]), value (mcm).
    """
    start = pd.Timestamp(start_date)
    package = client.get_package(SCI_PKG_GAS_KEY_DRIVERS)

    frames = []
    for pub_date in _weekly_issue_dates(package, range(start.year, datetime.now().year + 1)):
        issue = client.get_package_data(SCI_PKG_GAS_KEY_DRIVERS, pub_date)
        try:
            df = issue.sheet_by_topic(SCI_TOPIC_TERMINAL_TRUCK_LOADING).to_dataframe()
        except KeyError:  # topic not present in this (older) issue
            continue
        if df.empty:
            continue
        frames.append(pd.DataFrame({
            "date": pd.to_datetime(df[_find_col(df, "Day")], errors="coerce"),
            "kt": pd.to_numeric(df[_find_col(df, "PipeChina Beihai")], errors="coerce"),
        }).dropna())

    if not frames:
        return pd.DataFrame(columns=["month", "value"])

    daily = (pd.concat(frames, ignore_index=True)
             .drop_duplicates("date").sort_values("date"))
    daily = daily[daily["date"] >= start]
    grp = daily.groupby(daily["date"].dt.to_period("M"))
    monthly = grp["kt"].sum() / 1000.0 * MT_TO_MCM  # kt -> Mt -> mcm
    complete = grp["date"].max().dt.normalize() == grp["date"].max().dt.to_period("M").dt.end_time.dt.normalize()
    monthly = monthly[complete]
    return pd.DataFrame({"month": monthly.index, "value": monthly.values})


def _beihai_monthly_frame(df: pd.DataFrame):
    """
    Cargo-level Beihai frame to a complete monthly PeriodIndex (gap months
    as zeros), plus x positions, month labels and a mask of complete months
    (the current month - and any later months holding in-transit cargoes at
    forecast ETA - are incomplete).

    Returns (monthly_index, x, labels, complete) where monthly_index is the
    PeriodIndex to reindex aggregations onto.
    """
    months = pd.period_range(df["date"].min().to_period("M"),
                             max(df["date"].max().to_period("M"),
                                 pd.Timestamp.now().to_period("M")),
                             freq="M")
    x = np.arange(len(months))
    labels = [p.strftime("%b-%y") for p in months]
    complete = np.array(months < pd.Timestamp.now().to_period("M"))
    return months, x, labels, complete


def _beihai_style_axes(ax, x, labels, title, note):
    """Shared axis styling for the two Beihai monthly bar charts."""
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8.5, rotation=45, ha="right")
    ax.tick_params(axis="y", labelsize=9)
    ax.set_ylabel("mcm / month", fontsize=10)
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left", color="#2c3e50")
    ax.grid(True, axis="y", alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.annotate(note, xy=(1.0, 1.02), xycoords="axes fraction", ha="right",
                fontsize=8, color="#777777")


def generate_beihai_monthly_chart(df: pd.DataFrame, df_truck: pd.DataFrame = None) -> str:
    """
    Monthly Russian LNG imports into PipeChina Beihai: volume bars
    (gas-equivalent mcm), the number of cargoes on a right-hand axis and
    Energy Aspects' assumed max truck loading capacity (0.21 Mt/month,
    ~293 mcm) as a dotted line - sustained imports above that line imply
    gas is likely being sent into the grid. The current (and any ETA-only
    future) months are incomplete and drawn lighter.

    Pass df_truck (month Period[M], value mcm - see
    get_beihai_truck_loadings) to overlay SCI's actual truck loadings out
    of the terminal, so imports can be compared against both the trucked-out
    volumes and the estimated capacity. Returns a base64-encoded PNG.
    """
    months, x, labels, complete = _beihai_monthly_frame(df)
    grp = df.groupby(df["date"].dt.to_period("M"))
    volume = grp["value"].sum().reindex(months, fill_value=0.0)
    cargoes = grp.size().reindex(months, fill_value=0)

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")
    ax.bar(x[complete], volume.values[complete], color="#2f7d6c",
           label="monthly imports", zorder=3)
    if (~complete).any():
        ax.bar(x[~complete], volume.values[~complete], color="#2f7d6c",
               alpha=0.45, label="current month (incomplete)", zorder=3)

    ax.axhline(BEIHAI_TRUCK_CAPACITY_MCM, color="#2c3e50", linewidth=1.4,
               linestyle=(0, (2, 2)), zorder=4,
               label=(f"EA est. truck loading capacity "
                      f"({BEIHAI_TRUCK_CAPACITY_MT:g} Mt/m ~ {BEIHAI_TRUCK_CAPACITY_MCM:.0f} mcm/m)"))

    if df_truck is not None and not df_truck.empty:
        truck = df_truck.set_index("month")["value"].reindex(months)
        ax.plot(x[truck.notna()], truck.dropna().values, color="#e67e22",
                linewidth=2.0, marker="D", markersize=3.5,
                label="actual truck loadings (SCI)", zorder=5)

    ax.set_ylim(0, max(volume.max(), BEIHAI_TRUCK_CAPACITY_MCM) * 1.15)
    _beihai_style_axes(ax, x, labels, "PipeChina Beihai: Sanctioned Russian LNG Imports",
                       "First cargo 28 Aug 2025  |  Source: Kpler, SCI")

    ax2 = ax.twinx()
    count_line, = ax2.plot(x, cargoes.values, color="#7d3c98", linewidth=1.2,
                           marker="s", markersize=3.5, label="cargoes (rhs)", zorder=6)
    ax2.set_ylim(bottom=0)
    ax2.tick_params(axis="y", labelsize=8, colors="#7d3c98")
    ax2.set_ylabel("cargoes / month", fontsize=9, color="#7d3c98")
    ax2.spines[["top"]].set_visible(False)
    ax2.spines["right"].set_color("#7d3c98")

    # two legend rows, otherwise the single row is wider than the plot and
    # the rendered chart misaligns with the origin chart below it
    handles, leg_labels = ax.get_legend_handles_labels()
    handles.append(count_line)
    leg_labels.append(count_line.get_label())
    ax.legend(handles, leg_labels, fontsize=9, frameon=False, ncol=3,
              loc="upper center", bbox_to_anchor=(0.5, -0.22))

    plt.tight_layout()
    return _fig_to_base64(fig)


def generate_beihai_origin_chart(df: pd.DataFrame) -> str:
    """
    Monthly Russian LNG imports into PipeChina Beihai stacked by origin
    terminal/STS location, to show how routing shifts through the year
    (e.g. ice-breakers shuttle ALNG2 volumes to the Kamchatka STS while the
    Northern Sea Route is open; otherwise flows route via the Murmansk
    STS, with some vessels sailing direct from ALNG2 without transferring).
    Incomplete months are drawn lighter as per the monthly totals chart.
    Returns a base64-encoded PNG.
    """
    months, x, labels, complete = _beihai_monthly_frame(df)
    pivot = df.pivot_table(index=df["date"].dt.to_period("M"), columns="origin",
                           values="value", aggfunc="sum").reindex(months).fillna(0.0)
    extras = [c for c in pivot.columns if c not in BEIHAI_ORIGIN_COLORS]
    if extras:
        pivot["Other"] = pivot[extras].sum(axis=1)
        pivot = pivot.drop(columns=extras)

    fig, ax = plt.subplots(figsize=(10, 4.5), facecolor="white")
    bottom = np.zeros(len(months))
    stack = [o for o in BEIHAI_ORIGIN_COLORS if o in pivot.columns]
    stack += ["Other"] if extras else []
    for origin in stack:
        colour = BEIHAI_ORIGIN_COLORS.get(origin, BEIHAI_OTHER_COLOR)
        label = "ALNG2 (direct)" if origin == "ALNG2" else origin
        bars = ax.bar(x, pivot[origin].values, bottom=bottom, color=colour,
                      label=label, zorder=3)
        for bar, is_complete in zip(bars, complete):
            if not is_complete:
                bar.set_alpha(0.45)
        bottom += pivot[origin].values

    ax.set_ylim(bottom=0)
    _beihai_style_axes(ax, x, labels,
                       "PipeChina Beihai: Sanctioned Russian LNG Imports by Origin",
                       "Lighter = current month (incomplete)  |  Source: Kpler")
    ax.legend(fontsize=9, frameon=False, ncol=len(stack),
              loc="upper center", bbox_to_anchor=(0.5, -0.22))

    plt.tight_layout()
    return _fig_to_base64(fig)


def generate_beihai_fleet_table(df_fleet: pd.DataFrame) -> str:
    """
    HTML table of the sanctioned Russian LNG fleet from the fleet activity
    frame (see get_kpler_beihai_russian_imports): every vessel that has
    loaded a cargo at ALNG2 or delivered Russian LNG into PipeChina Beihai,
    with its ice classification (Kpler 'Carrier type': ARC7 = ice-breaking,
    ARC4 = ice-strengthened, Ocean = conventional), the date of its first
    sanctioned activity (so new fleet additions stand out) and its total
    activity count. Sorted by first activity (earliest first), then vessel
    name. Vessel names link through to the vessel's voyage view in the
    Kpler terminal UI. Vessels
    in BEIHAI_FLEET_NOTES (e.g. those attacked/damaged) are asterisked and
    shaded, with the notes appended as footnotes.
    """
    fleet = (df_fleet.groupby("vessel")
             .agg(ice_class=("ice_class", "first"),
                  vessel_id=("vessel_id", "first"),
                  first_activity=("date", "min"),
                  cargoes=("vessel", "size"))
             .sort_values(["first_activity", "vessel"]))

    th = TABLE_TH_STYLE
    td = TABLE_TD_STYLE
    td_left = td.replace("text-align:right", "text-align:left")

    rows_html = ""
    for vessel, row in fleet.iterrows():
        vessel_html = vessel
        if pd.notna(row["vessel_id"]):
            url = ("https://terminal.kpler.com/map/search/voyages?"
                   f"installationLayer=hidden&amp;fields=vessel&amp;vessels={row['vessel_id']:.0f}")
            vessel_html = (f"<a href='{url}' style='color:#2c6fbb; "
                           f"text-decoration:none;'>{vessel}</a>")
        ice = row["ice_class"]
        ice_html = (f"<span style='color:#c0392b; font-weight:600;'>{ice}</span>"
                    if ice == "ARC7" else ice)
        row_td, row_td_left = td, td_left
        if vessel in BEIHAI_FLEET_NOTES:
            vessel_html += "*"
            row_td = td + " background:#e8e8e8;"
            row_td_left = td_left + " background:#e8e8e8;"
        rows_html += (
            f"<tr><td style='{row_td_left}'>{vessel_html}</td>"
            f"<td style='{row_td}'>{ice_html}</td>"
            f"<td style='{row_td}'>{row['first_activity'].strftime('%d %b %y')}</td>"
            f"<td style='{row_td}'>{row['cargoes']}</td></tr>"
        )
    footnotes = "".join(f"<br>* {vessel} {note}"
                        for vessel, note in BEIHAI_FLEET_NOTES.items()
                        if vessel in fleet.index)

    th_left = th.replace("text-align:right", "text-align:left")
    title_style = (_TABLE_FONT + "margin:0 0 6px 0; font-size:13px; "
                   "font-weight:bold; color:#2c3e50;")
    return f"""<p style="{title_style}">Russian Sanctioned LNG Fleet</p>
<table style="border-collapse:collapse; margin:0;">
  <tr><th style="{th_left}">Vessel</th><th style="{th}">Ice class</th>
      <th style="{th}">First activity</th><th style="{th}">Cargoes</th></tr>
  {rows_html}
</table>
<p style="{TABLE_NOTE_STYLE}">
  Vessels that have loaded a cargo at ALNG2 (since its first loading, Aug 2024)
  or delivered Russian LNG into Beihai; first activity and cargo counts cover
  both, with direct ALNG2-to-Beihai cargoes counted once at their loading date<br>
  Ice class per Kpler: ARC7 = ice-breaking, ARC4 = ice-strengthened,
  Ocean = conventional{footnotes}
</p>"""
