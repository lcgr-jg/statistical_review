"""
Client for the SCI (Sublime China Information) datapack API (open.sci99.com).

Endpoints (see sci_api/Operation Description for SCI Data Access.docx):
    POST /user/gettoken                 -> get an access token (valid ~1 day)
    GET  /getmypkglist                  -> list packages the account can access
    GET  /getpkgdata?pkgid=&pubdate=    -> fetch one package issue

Notes on the API's behaviour (confirmed against the live service):
    - getpkgdata rejects calls without a pubdate (status 10000), so the latest
      issue date is always resolved from the package list first.
    - Each issue of a monthly topic carries roughly the current calendar
      year's months. The last issue of a year carries the full Jan-Dec, and
      early issues of the following year carry revised prior-year actuals.
      get_topic_history() uses both to stitch a clean multi-year series.

Credentials currently live in china_summary.cfg ([SCI] section).
TODO: shift username/password to environment variables before production release.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Any, Iterable, Optional, Union

import pandas as pd
import requests

DateLike = Union[date, datetime, str]

BASE_URL = "https://open.sci99.com/datapackapi/pkg"
AUTH_HEADER = "scipkgauth"
TOKEN_MAX_AGE = timedelta(hours=23)

# Status code returned when the token has expired / is invalid
STATUS_AUTH_FAILED = 10002


class SCIError(Exception):
    """Raised when the SCI API returns a non-success status code."""

    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f"SCI API error {status}: {message}")


@dataclass(frozen=True)
class SCIPackage:
    """One entry from getmypkglist: a package id plus its issue dates."""

    package_id: int
    latest_date: Optional[datetime]
    historical_dates: tuple[datetime, ...] = ()

    @classmethod
    def from_api(cls, row: dict[str, Any]) -> "SCIPackage":
        latest_raw = row.get("LatestDate")
        latest_dt = pd.to_datetime(latest_raw).to_pydatetime() if latest_raw else None
        hist_raw = row.get("HistoricalDateList") or []
        hist_dates = tuple(
            sorted(pd.to_datetime(d).to_pydatetime() for d in hist_raw if d)
        )
        return cls(
            package_id=int(row["DataPackageID"]),
            latest_date=latest_dt,
            historical_dates=hist_dates,
        )

    def all_dates(self) -> tuple[datetime, ...]:
        """All known issue dates (historical + latest), sorted ascending."""
        dates = set(self.historical_dates)
        if self.latest_date:
            dates.add(self.latest_date)
        return tuple(sorted(dates))

    def last_issue_on_or_before(self, cutoff: datetime) -> Optional[datetime]:
        """Most recent issue date on or before the cutoff, if any."""
        eligible = [d for d in self.all_dates() if d <= cutoff]
        return max(eligible) if eligible else None


@dataclass(frozen=True)
class SCISheet:
    """One sheet/topic inside a package issue."""

    sheet_name: str
    topic: str
    unit: Optional[str]
    note: Optional[str]
    methodology: Optional[str]
    data_list: tuple[dict[str, Any], ...]

    @classmethod
    def from_api(cls, row: dict[str, Any]) -> "SCISheet":
        return cls(
            sheet_name=row["SheetName"],
            topic=row["Topic"],
            unit=row.get("Unit"),
            note=row.get("Note"),
            methodology=row.get("Methodology"),
            data_list=tuple(row.get("DataList") or ()),
        )

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(list(self.data_list))


@dataclass(frozen=True)
class SCIPackageData:
    """One full package issue: name, publication date and all sheets."""

    package_name: str
    pub_date: datetime
    sheets: tuple[SCISheet, ...]

    def sheet_by_topic(self, topic: str) -> SCISheet:
        """
        Find a sheet by topic name. Whitespace and case insensitive; falls back
        to a substring match (SCI topic names often have stray trailing spaces,
        e.g. 'China Natural Gas Output ').
        """
        key = _normalise(topic)
        exact = [s for s in self.sheets if _normalise(s.topic) == key]
        if len(exact) == 1:
            return exact[0]
        partial = [s for s in self.sheets if key in _normalise(s.topic)]
        if len(partial) == 1:
            return partial[0]
        matches = exact or partial
        if not matches:
            available = [s.topic for s in self.sheets]
            raise KeyError(f"No sheet matching topic {topic!r}. Available: {available}")
        raise KeyError(
            f"Multiple sheets match topic {topic!r}: {[s.topic for s in matches]}"
        )


class SCIClient:
    """
    SCI datapack API client.

    Handles token acquisition/refresh and wraps the package list and package
    data endpoints. Higher-level helpers return pandas DataFrames.

    Usage:
        client = SCIClient(username, password)          # or .from_config(cfg)
        client.get_token()                              # optional; lazy otherwise
        packages = client.get_package_list()
        issue = client.get_package_data(782)            # latest issue
        df = client.get_topic(782, "China Natural Gas Output")
        df = client.get_topic_history(782, "China Natural Gas Output",
                                      years=range(2022, 2027))
    """

    def __init__(
        self,
        username: str,
        password: str,
        user_type: int = 2,  # 1 = Chinese account, 2 = English account
        base_url: str = BASE_URL,
        timeout: float = 60.0,
    ):
        self.username = username
        self.password = password
        self.user_type = user_type
        self.base_url = base_url
        self.timeout = timeout
        self._session = requests.Session()
        self._token: Optional[str] = None
        self._token_obtained_at: Optional[datetime] = None

    @classmethod
    def from_config(cls, config, section: str = "SCI") -> "SCIClient":
        """Build a client from a configparser object with an [SCI] section."""
        return cls(
            username=config.get(section, "username"),
            password=config.get(section, "password"),
            user_type=config.getint(section, "user_type", fallback=2),
        )

    # ── Auth ──────────────────────────────────────────────────────────────

    def get_token(self, force: bool = False) -> str:
        """
        Return a valid access token, requesting a new one if none is held or
        the cached one is older than ~23h (tokens last ~1 day).
        """
        if (
            not force
            and self._token
            and self._token_obtained_at
            and datetime.now() - self._token_obtained_at < TOKEN_MAX_AGE
        ):
            return self._token

        response = self._session.post(
            f"{self.base_url}/user/gettoken",
            json={
                "UserName": self.username,
                "Password": self.password,
                "UserType": self.user_type,
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        status, msg, data = _parse_envelope(response.json())
        if status != 200:
            raise SCIError(status, msg)
        if not data:
            raise SCIError(status, "Token response missing data field")
        self._token = str(data)
        self._token_obtained_at = datetime.now()
        return self._token

    def _get(
        self,
        endpoint: str,
        params: Optional[dict[str, Any]] = None,
        retry_on_auth: bool = True,
    ) -> Any:
        """GET an endpoint with auth header; re-login once on auth failure."""
        response = self._session.get(
            f"{self.base_url}/{endpoint}",
            headers={AUTH_HEADER: self.get_token(), "Content-Type": "application/json"},
            params=params,
            timeout=self.timeout,
        )
        response.raise_for_status()
        status, msg, data = _parse_envelope(response.json())
        if status == STATUS_AUTH_FAILED and retry_on_auth:
            self.get_token(force=True)
            return self._get(endpoint, params, retry_on_auth=False)
        if status != 200:
            raise SCIError(status, msg)
        return data

    # ── Core endpoints ────────────────────────────────────────────────────

    def get_package_list(self) -> list[SCIPackage]:
        """All packages the account can access (ids + issue dates)."""
        rows = self._get("getmypkglist") or []
        return [SCIPackage.from_api(row) for row in rows]

    def get_package(self, package_id: int) -> SCIPackage:
        """The package list entry for one package id."""
        for pkg in self.get_package_list():
            if pkg.package_id == package_id:
                return pkg
        raise SCIError(10004, f"Package {package_id} not in accessible package list")

    def get_package_data(
        self,
        package_id: int,
        pub_date: Optional[DateLike] = None,
    ) -> SCIPackageData:
        """
        Fetch one package issue. Omit pub_date for the latest issue (resolved
        via the package list, since the API requires an explicit pubdate).
        """
        if pub_date is None:
            pub_date = self.get_package(package_id).latest_date
            if pub_date is None:
                raise SCIError(10005, f"Package {package_id} has no published issues")

        data = self._get(
            "getpkgdata",
            params={"pkgid": package_id, "pubdate": _format_pub_date(pub_date)},
        )
        if not data:
            raise SCIError(200, "Package data response missing data field")
        return SCIPackageData(
            package_name=data["DataPackageName"],
            pub_date=pd.to_datetime(data["PubDate"]).to_pydatetime(),
            sheets=tuple(SCISheet.from_api(s) for s in data.get("SheetList") or []),
        )

    # ── DataFrame helpers ─────────────────────────────────────────────────

    def get_topic(
        self,
        package_id: int,
        topic: str,
        pub_date: Optional[DateLike] = None,
    ) -> pd.DataFrame:
        """One topic from one issue (latest by default) as a DataFrame."""
        return self.get_package_data(package_id, pub_date).sheet_by_topic(topic).to_dataframe()

    def get_topic_history(
        self,
        package_id: int,
        topic: str,
        years: Iterable[int],
        month_column: str = "Month",
    ) -> pd.DataFrame:
        """
        Stitch a monthly topic across several calendar years.

        For each year the series is assembled from:
          - the last issue published in that year (carries the full Jan-Dec,
            with the final months typically estimates), and
          - the last issue published by 1 March of the following year (carries
            revised actuals for the prior year), where available.
        The current year always uses the latest issue. Where issues overlap,
        the later publication wins.

        Returns the topic's columns plus 'month' (Timestamp, month start) and
        'pub_date', sorted by month.
        """
        wanted_years = sorted({int(y) for y in years})
        if not wanted_years:
            raise ValueError("Provide at least one year.")

        package = self.get_package(package_id)
        if package.latest_date is None:
            raise SCIError(10005, f"Package {package_id} has no published issues")
        latest_year = package.latest_date.year

        # Collect the issue dates worth fetching
        issue_dates: set[datetime] = set()
        for year in wanted_years:
            if year >= latest_year:
                issue_dates.add(package.latest_date)
                continue
            # Last issue within the year itself (full Jan-Dec incl. estimates)
            in_year = package.last_issue_on_or_before(datetime(year, 12, 31))
            if in_year and in_year.year == year:
                issue_dates.add(in_year)
            # Last issue by 1 March of the following year (revised actuals)
            revised = package.last_issue_on_or_before(datetime(year + 1, 3, 1))
            if revised:
                issue_dates.add(revised)

        frames: list[pd.DataFrame] = []
        for pub_date in sorted(issue_dates):
            issue = self.get_package_data(package_id, pub_date)
            try:
                df = issue.sheet_by_topic(topic).to_dataframe()
            except KeyError:
                # topic not present in this (older) issue - skip it
                continue
            if df.empty:
                continue
            col = month_column if month_column in df.columns else df.columns[0]
            df = df.assign(month=_parse_month_series(df[col]), pub_date=issue.pub_date)
            df = df[df["month"].dt.year.isin(wanted_years)]
            frames.append(df)

        if not frames:
            return pd.DataFrame()

        result = pd.concat(frames, ignore_index=True)
        result = result.sort_values(["month", "pub_date"])
        result = result.drop_duplicates(subset="month", keep="last")
        result = result.sort_values("month").reset_index(drop=True)

        front = ["month", "pub_date"]
        return result[front + [c for c in result.columns if c not in front]]


# ── Module helpers ────────────────────────────────────────────────────────


def _normalise(value: str) -> str:
    return " ".join(value.split()).casefold()


def _parse_envelope(body: dict[str, Any]) -> tuple[int, str, Any]:
    status = body.get("status", body.get("Status"))
    msg = body.get("msg", body.get("Msg", ""))
    data = body.get("data", body.get("Data"))
    return int(status), str(msg), data


def _format_pub_date(pub_date: DateLike) -> str:
    if isinstance(pub_date, str):
        return pub_date
    if isinstance(pub_date, datetime):
        return pub_date.strftime("%Y-%m-%d")
    return pub_date.isoformat()


def _parse_month_series(values: pd.Series) -> pd.Series:
    """
    Parse SCI month labels to month-start Timestamps. Handles both label
    styles seen across topics: 'Oct-21' / 'Nov-21(E)' and '2024-01-01'.
    """
    cleaned = (
        values.astype(str)
        .str.strip()
        .str.replace(r"\s*\(E\)\s*$", "", regex=True, flags=re.IGNORECASE)
    )
    period = pd.to_datetime(cleaned, format="%b-%y", errors="coerce")
    missing = period.isna() & cleaned.ne("") & cleaned.str.lower().ne("nan")
    if missing.any():
        period = period.copy()
        period.loc[missing] = pd.to_datetime(cleaned[missing], errors="coerce")
    return period.dt.to_period("M").dt.to_timestamp()
