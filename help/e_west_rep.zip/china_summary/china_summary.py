
"""
Email report showing current snapshot of China data (currently SCI and Kpler)

"""


import logging
import sys
import traceback
import configparser
import platform

from datetime import datetime, timedelta

from pathlib import Path

from jain_commods.core.util.emailhelper import send_email

from sci_client import SCIClient
from util import (
    SCI_PKG_GAS_FORECAST,
    get_domestic_production,
    get_domestic_production_forecast,
    get_domestic_production_forecast_history,
    generate_production_forecast_history_chart,
    generate_forecast_delta_table,
    get_apparent_consumption,
    get_apparent_consumption_forecast,
    get_apparent_consumption_forecast_history,
    get_consumption_structure,
    get_consumption_structure_forecast,
    get_demand_sector_annual,
    generate_demand_breakdown_chart,
    generate_demand_sector_annual_chart,
    generate_demand_share_table,
    generate_demand_sector_table,
    get_net_lng_imports,
    get_net_lng_import_forecast,
    get_net_lng_import_forecast_history,
    get_net_png_imports,
    get_net_png_import_forecast,
    get_net_png_import_forecast_history,
    generate_domestic_production_chart,
    generate_production_yoy_table,
    generate_supply_demand_chart,
    get_weekly_summary,
    get_weekly_item,
    get_lng_stock_levels,
    generate_weekly_seasonal_chart,
    get_kpler_china_lng_flows,
    kpler_monthly_net_imports,
    kpler_monthly_reexports,
    kpler_current_month_split,
    generate_kpler_lng_daily_chart,
    generate_kpler_origin_grid_chart,
    generate_kpler_origin_monthly_chart,
    get_kpler_beihai_russian_imports,
    generate_beihai_monthly_chart,
    generate_beihai_origin_chart,
    generate_beihai_fleet_table,
    get_beihai_truck_loadings,
    BEIHAI_TRUCK_CAPACITY_MT,
    BEIHAI_TRUCK_CAPACITY_MCM,
    KPLER_M3_TO_MCM,
)


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/china_summary')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'china_summary.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')


# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_china_summary.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
skip_duplicate_check = system == 'windows'
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

today = datetime.now()

# Forecast evolution settings: 5 previous forecasts, with the oldest pinned
# to the last issue published before the Iran war (end of Feb 2026) so the
# pre/post-war development stays visible as new issues are published
FCST_N_PREVIOUS = 5
FCST_ANCHOR_DATE = '2026-02-28'

# The report is scheduled every 30 minutes on Fridays but should only email
# once per SCI release: the forecast issue date last reported on is stamped
# into a text file alongside this script (same approach as cot_summary)
stamp_fmt = '%Y-%m-%d'
last_forecast_file = REPORTS_PATH / 'sci_last_forecast_date.txt'


def _read_stamp_date(stamp_file: Path) -> datetime:
    """Read the YYYY-MM-DD stamp file holding the last reported forecast date."""
    if skip_duplicate_check:
        return datetime.min
    if stamp_file.exists():
        return datetime.strptime(open(stamp_file, 'r').read().strip(), stamp_fmt)
    return datetime.min


def _write_stamp_date(stamp_file: Path, stamp_dt: datetime) -> None:
    if not skip_duplicate_check:
        logging.info(f"Saving stamp {stamp_dt.strftime(stamp_fmt)} into {stamp_file.name}")
        with open(stamp_file, 'w') as f:
            f.write(stamp_dt.strftime(stamp_fmt))

   
try:
    
    # SCI client (credentials from cfg; TODO shift to env variables before production)
    sci_client = SCIClient.from_config(config)
    
    # Only send once per SCI release: compare the latest published forecast
    # issue date against the stamp file from the last successful send
    logging.info('Checking for a new SCI forecast release...')
    latest_forecast_date = sci_client.get_package(SCI_PKG_GAS_FORECAST).latest_date
    last_sent_date = _read_stamp_date(last_forecast_file)
    
    if skip_duplicate_check:
        logging.info('Windows dev mode: ignoring last forecast date duplicate check')
    
    if not latest_forecast_date > last_sent_date:
        logging.info(
            f"Report already sent for the latest SCI forecast "
            f"({latest_forecast_date.strftime(stamp_fmt)}, stamp file: "
            f"{last_sent_date.strftime(stamp_fmt)}). Waiting for a new forecast "
            f"to be published - not sending a report."
        )
        sys.exit(0)
    
    logging.info(
        f"New SCI forecast published {latest_forecast_date.strftime(stamp_fmt)} "
        f"(last report sent for {last_sent_date.strftime(stamp_fmt)}). Generating report..."
    )
    
    # Live LNG cargo trackings from Kpler: daily imports/re-exports as a 10d
    # moving average, plus a seasonal view of monthly net imports. Also
    # imports by key origin country (display label -> Kpler country name)
    KPLER_ORIGIN_COUNTRIES = {'Australia': 'Australia',
                              'Qatar': 'Qatar',
                              'Russia': 'Russian Federation',
                              'Malaysia': 'Malaysia'}
    logging.info('Fetching Kpler LNG trades...')
    df_kpler_imp, df_kpler_re, kpler_origin_flows, df_kpler_origin_month = get_kpler_china_lng_flows(
        config.get('Kpler', 'email'), config.get('Kpler', 'password'),
        start_date=f"{today.year - 4}-01-01",
        origin_countries=KPLER_ORIGIN_COUNTRIES)
    kpler_daily_img = generate_kpler_lng_daily_chart(df_kpler_imp, df_kpler_re)
    kpler_daily_img_html = f"<img src='data:image/png;base64,{kpler_daily_img}' alt='China Net LNG Imports Daily 10d MA (Kpler)'>"
    kpler_daily30_img = generate_kpler_lng_daily_chart(df_kpler_imp, df_kpler_re, window=30)
    kpler_daily30_img_html = f"<img src='data:image/png;base64,{kpler_daily30_img}' alt='China Net LNG Imports Daily 30d MA (Kpler)'>"
    kpler_origin_img = generate_kpler_origin_grid_chart(kpler_origin_flows)
    kpler_origin_img_html = f"<img src='data:image/png;base64,{kpler_origin_img}' alt='China LNG Imports by Origin (Kpler)'>"
    
    # Monthly net imports (bcm), with the current/future months (which contain
    # forecast ETA arrivals) drawn as a dashed forecast continuation
    df_kpler_net, df_kpler_net_fcst = kpler_monthly_net_imports(df_kpler_imp, df_kpler_re)
    df_kpler_net['value'] = df_kpler_net['value'] / 1000.0  # mcm -> bcm
    for col in ('value', 'lower', 'upper'):
        df_kpler_net_fcst[col] = df_kpler_net_fcst[col] / 1000.0
    net_act, net_eta = kpler_current_month_split(df_kpler_imp, df_kpler_re)  # mcm
    net_split_label = (f"{today.strftime('%b%y')}\n"
                       f"{net_act / 1000.0:.1f}bcm arrived\n"
                       f"{net_eta / 1000.0:.1f}bcm forecasted")
    kpler_month_img = generate_domestic_production_chart(
        df_kpler_net, df_kpler_net_fcst,
        title='China Net LNG Imports (Kpler, monthly)', ylabel='bcm / month',
        note="Dashed = months containing forecast (ETA) arrivals  |  Source: Kpler",
        current_month_label=net_split_label)
    kpler_month_img_html = f"<img src='data:image/png;base64,{kpler_month_img}' alt='China Net LNG Imports Monthly (Kpler)'>"
    # Past 12 months of gross imports, stacked by origin: each month's own
    # top 4 countries, with every other origin that month in Other
    kpler_origin_month_img = generate_kpler_origin_monthly_chart(df_kpler_origin_month)
    kpler_origin_month_img_html = f"<img src='data:image/png;base64,{kpler_origin_month_img}' alt='China LNG Imports by Origin Monthly (Kpler)'>"
    
    # Monthly re-exports in isolation (mcm - volumes are far smaller)
    df_kpler_reex, df_kpler_reex_fcst = kpler_monthly_reexports(df_kpler_re)
    reex_act, reex_eta = kpler_current_month_split(df_kpler_re)  # mcm
    reex_split_label = (f"{today.strftime('%b%y')}\n"
                        f"{reex_act:.0f}mcm departed\n"
                        f"{reex_eta:.0f}mcm forecasted")
    kpler_reex_img = generate_domestic_production_chart(
        df_kpler_reex, df_kpler_reex_fcst,
        title='China LNG Re-exports (Kpler, monthly)', ylabel='mcm / month',
        note="Dashed = months containing forecast (ETA) departures  |  Source: Kpler",
        current_month_label=reex_split_label)
    kpler_reex_img_html = f"<img src='data:image/png;base64,{kpler_reex_img}' alt='China LNG Re-exports Monthly (Kpler)'>"
    
    # Sanctioned Russian LNG into PipeChina Beihai (first cargo 28 Aug 2025):
    # monthly volumes/cargo count vs the estimated truck loading capacity,
    # plus the breakdown by origin terminal/STS location
    logging.info('Fetching Kpler Beihai imports...')
    df_beihai, df_ru_fleet = get_kpler_beihai_russian_imports(
        config.get('Kpler', 'email'), config.get('Kpler', 'password'))
    # Actual truck loadings out of Beihai (SCI daily kt, complete months as
    # gas-equivalent mcm) overlaid on the monthly imports chart
    logging.info('Fetching SCI Beihai truck loadings...')
    df_beihai_truck = get_beihai_truck_loadings(sci_client)
    beihai_month_img = generate_beihai_monthly_chart(df_beihai, df_beihai_truck)
    beihai_month_img_html = f"<img src='data:image/png;base64,{beihai_month_img}' alt='PipeChina Beihai Sanctioned Russian LNG Imports (Kpler)'>"
    beihai_origin_img = generate_beihai_origin_chart(df_beihai)
    beihai_origin_img_html = f"<img src='data:image/png;base64,{beihai_origin_img}' alt='PipeChina Beihai Sanctioned Russian LNG Imports by Origin (Kpler)'>"
    beihai_fleet_html = generate_beihai_fleet_table(df_ru_fleet)
    
    # Domestic production seasonal chart (last 5 years actuals + SCI forecast)
    # plus YoY stats table. One extra year is fetched so the first chart year
    # still gets a growth figure in the table.
    logging.info('Fetching SCI domestic production...')
    df_prod = get_domestic_production(sci_client, years=range(today.year - 5, today.year + 1))
    df_prod_fcst = get_domestic_production_forecast(sci_client)
    df_prod_chart = df_prod[df_prod['month'].dt.year >= today.year - 4]
    prod_img = generate_domestic_production_chart(df_prod_chart, df_prod_fcst)
    prod_img_html = f"<img src='data:image/png;base64,{prod_img}' alt='China Domestic Gas Production'>"
    prod_yoy_html = generate_production_yoy_table(df_prod, df_prod_fcst)
    
    # Forecast evolution: latest + previous SCI forecast vintages (~monthly spacing)
    logging.info('Fetching SCI production forecast history...')
    df_prod_fcst_hist = get_domestic_production_forecast_history(sci_client, n_previous=FCST_N_PREVIOUS, anchor_date=FCST_ANCHOR_DATE)
    fcst_hist_img = generate_production_forecast_history_chart(df_prod, df_prod_fcst_hist)
    fcst_hist_img_html = f"<img src='data:image/png;base64,{fcst_hist_img}' alt='SCI Production Forecast Evolution'>"
    fcst_delta_html = generate_forecast_delta_table(df_prod, df_prod_fcst_hist)
    
    # Net LNG imports (imports - re-exports): seasonal chart, YoY stats and
    # forecast evolution, mirroring the domestic production section
    logging.info('Fetching SCI LNG imports...')
    df_lng = get_net_lng_imports(sci_client, years=range(today.year - 5, today.year + 1))
    df_lng_fcst = get_net_lng_import_forecast(sci_client)
    df_lng_chart = df_lng[df_lng['month'].dt.year >= today.year - 4]
    lng_img = generate_domestic_production_chart(df_lng_chart, df_lng_fcst,
                                                 title='China Net LNG Imports')
    lng_img_html = f"<img src='data:image/png;base64,{lng_img}' alt='China Net LNG Imports'>"
    lng_yoy_html = generate_production_yoy_table(df_lng, df_lng_fcst)
    
    logging.info('Fetching SCI LNG import forecast history...')
    df_lng_fcst_hist = get_net_lng_import_forecast_history(sci_client, n_previous=FCST_N_PREVIOUS, anchor_date=FCST_ANCHOR_DATE)
    lng_hist_img = generate_production_forecast_history_chart(
        df_lng, df_lng_fcst_hist, title='China Net LNG Imports: SCI Forecast Evolution')
    lng_hist_img_html = f"<img src='data:image/png;base64,{lng_hist_img}' alt='SCI LNG Import Forecast Evolution'>"
    lng_delta_html = generate_forecast_delta_table(df_lng, df_lng_fcst_hist)
    
    # Net pipeline (PNG) imports: same layout as the LNG section
    logging.info('Fetching SCI PNG imports...')
    df_png = get_net_png_imports(sci_client, years=range(today.year - 5, today.year + 1))
    df_png_fcst = get_net_png_import_forecast(sci_client)
    df_png_chart = df_png[df_png['month'].dt.year >= today.year - 4]
    png_img = generate_domestic_production_chart(df_png_chart, df_png_fcst,
                                                 title='China Net Pipeline Imports')
    png_img_html = f"<img src='data:image/png;base64,{png_img}' alt='China Net Pipeline Imports'>"
    png_yoy_html = generate_production_yoy_table(df_png, df_png_fcst)
    
    logging.info('Fetching SCI PNG import forecast history...')
    df_png_fcst_hist = get_net_png_import_forecast_history(sci_client, n_previous=FCST_N_PREVIOUS, anchor_date=FCST_ANCHOR_DATE)
    png_hist_img = generate_production_forecast_history_chart(
        df_png, df_png_fcst_hist, title='China Net Pipeline Imports: SCI Forecast Evolution')
    png_hist_img_html = f"<img src='data:image/png;base64,{png_hist_img}' alt='SCI Pipeline Import Forecast Evolution'>"
    png_delta_html = generate_forecast_delta_table(df_png, df_png_fcst_hist)
    
    # Total demand (apparent consumption): same layout as the supply sections
    logging.info('Fetching SCI apparent consumption...')
    df_dem = get_apparent_consumption(sci_client, years=range(today.year - 5, today.year + 1))
    df_dem_fcst = get_apparent_consumption_forecast(sci_client)
    df_dem_chart = df_dem[df_dem['month'].dt.year >= today.year - 4]
    dem_img = generate_domestic_production_chart(df_dem_chart, df_dem_fcst,
                                                 title='China Total Gas Demand (Apparent Consumption)')
    dem_img_html = f"<img src='data:image/png;base64,{dem_img}' alt='China Total Gas Demand'>"
    dem_yoy_html = generate_production_yoy_table(df_dem, df_dem_fcst)
    
    logging.info('Fetching SCI consumption forecast history...')
    df_dem_fcst_hist = get_apparent_consumption_forecast_history(sci_client, n_previous=FCST_N_PREVIOUS, anchor_date=FCST_ANCHOR_DATE)
    dem_hist_img = generate_production_forecast_history_chart(
        df_dem, df_dem_fcst_hist, title='China Total Gas Demand: SCI Forecast Evolution')
    dem_hist_img_html = f"<img src='data:image/png;base64,{dem_hist_img}' alt='SCI Total Demand Forecast Evolution'>"
    dem_delta_html = generate_forecast_delta_table(df_dem, df_dem_fcst_hist)
    
    # Demand breakdown: SCI publish the sector split as percentages only, so
    # the bcm view is implied from share x total demand. Pre-2025 years use
    # SCI's older classification with a combined 'City gas' bucket.
    logging.info('Fetching SCI consumption structure...')
    df_struct = get_consumption_structure(sci_client, years=range(2022, today.year + 1))
    df_struct_fcst = get_consumption_structure_forecast(sci_client)
    struct_img = generate_demand_breakdown_chart(df_struct, df_struct_fcst)
    struct_img_html = f"<img src='data:image/png;base64,{struct_img}' alt='China Gas Demand Sector Shares'>"
    df_sector_annual = get_demand_sector_annual(df_struct, df_struct_fcst, df_dem, df_dem_fcst)
    struct_share_html = generate_demand_share_table(df_sector_annual)
    sector_img = generate_demand_sector_annual_chart(df_sector_annual)
    sector_img_html = f"<img src='data:image/png;base64,{sector_img}' alt='China Gas Demand by Sector (bcm)'>"
    sector_table_html = generate_demand_sector_table(df_sector_annual)
    
    # Production vs total demand (apparent consumption) charts
    sd_img = generate_supply_demand_chart(df_prod, df_dem, df_prod_fcst, df_dem_fcst)
    sd_img_html = f"<img src='data:image/png;base64,{sd_img}' alt='Production vs Total Demand'>"
    
    # Weekly high-frequency data: terminal truck loadings plus LNG and
    # alternative fuel prices from the SCI weekly summary
    logging.info('Fetching SCI weekly summary...')
    df_weekly = get_weekly_summary(sci_client, years=range(today.year - 4, today.year + 1))
    
    def weekly_chart_html(item, title, figsize=(6.2, 4.2)):
        df_item, unit = get_weekly_item(df_weekly, item)
        img = generate_weekly_seasonal_chart(df_item, title=title, ylabel=unit, figsize=figsize)
        return f"<img src='data:image/png;base64,{img}' alt='{title}'>"
    
    wk_truck_html = weekly_chart_html('LNG truck loading from terminals',
                                      'LNG Truck Loading from Terminals', figsize=(10, 4.5))
    wk_exworks_html = weekly_chart_html('LNG ex-works price', 'LNG Ex-Works')
    wk_exterm_html = weekly_chart_html('LNG ex-terminal price', 'LNG Ex-Terminal')
    wk_hgv_lng_html = weekly_chart_html('Heavy truck-use LNG', 'Heavy Truck-Use LNG')
    wk_hgv_diesel_html = weekly_chart_html('Heavy truck-use diesel', 'Heavy Truck-Use Diesel')
    wk_ind_lng_html = weekly_chart_html('Industrial-use LNG', 'Industrial-Use LNG')
    wk_ind_coal_html = weekly_chart_html('Industrial-use steam coal', 'Industrial-Use Steam Coal')
    wk_ind_lpg_html = weekly_chart_html('Industrial-use LPG', 'Industrial-Use LPG')
    
    # LNG stock levels: SCI publish capacity and % fill separately, combined
    # and converted to gas-equivalent mcm in get_lng_stock_levels
    logging.info('Fetching SCI LNG stock levels...')
    df_stocks = get_lng_stock_levels(sci_client, years=range(today.year - 4, today.year + 1))
    wk_term_stock_img = generate_weekly_seasonal_chart(
        df_stocks[['date', 'terminal']].rename(columns={'terminal': 'value'}),
        title='LNG Terminal Stocks (Absolute Level)', ylabel='mcm')
    wk_term_stock_html = f"<img src='data:image/png;base64,{wk_term_stock_img}' alt='LNG Terminal Stocks'>"
    wk_plant_stock_img = generate_weekly_seasonal_chart(
        df_stocks[['date', 'plant']].rename(columns={'plant': 'value'}),
        title='LNG Plant Stocks (Absolute Level)', ylabel='mcm')
    wk_plant_stock_html = f"<img src='data:image/png;base64,{wk_plant_stock_img}' alt='LNG Plant Stocks'>"
    # ... and as % of capacity, since capacity build-out lifts the absolute levels
    wk_term_fill_img = generate_weekly_seasonal_chart(
        df_stocks[['date', 'terminal_fill']].rename(columns={'terminal_fill': 'value'}),
        title='LNG Terminal Stocks (% Full)', ylabel='% of capacity')
    wk_term_fill_html = f"<img src='data:image/png;base64,{wk_term_fill_img}' alt='LNG Terminal Stocks Percent Full'>"
    wk_plant_fill_img = generate_weekly_seasonal_chart(
        df_stocks[['date', 'plant_fill']].rename(columns={'plant_fill': 'value'}),
        title='LNG Plant Stocks (% Full)', ylabel='% of capacity')
    wk_plant_fill_html = f"<img src='data:image/png;base64,{wk_plant_fill_img}' alt='LNG Plant Stocks Percent Full'>"
    
      
    # Construct html
    email_body = f"""
<div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; font-size: 13px; line-height: 1.4; color: #333;">
  <p style="margin: 0 0 12px 0; font-size: 12px; color: #555;">Weekly summary of China gas fundamentals (SCI &amp; Kpler).</p>

  <h3 style="margin: 0 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Supply: LNG (Kpler)</h3>
  <table style="border-collapse:collapse;"><tr>
    <td style="vertical-align:top;">
      {kpler_daily_img_html}
      <div style="margin-top: 8px;">{kpler_daily30_img_html}</div>
    </td>
    <td style="vertical-align:top; padding-left:8px;">{kpler_origin_img_html}</td>
  </tr></table>
  <table style="border-collapse:collapse; margin-top:8px;"><tr>
    <td style="vertical-align:top;">{kpler_month_img_html}</td>
    <td style="vertical-align:top; padding-left:8px;">{kpler_origin_month_img_html}</td>
  </tr></table>
  <div style="margin-top: 8px;">{kpler_reex_img_html}</div>
  <p style="font-family:Segoe UI,Arial,sans-serif; margin:6px 0 0 0; font-size:10px; color:#777;">
    Kpler cargo volumes are m3 of LNG (liquid), converted to gas-equivalent mcm
    using a factor of {KPLER_M3_TO_MCM:g} (1 m3 of LNG &asymp; 600 m3 of gas)<br>
    Cargoes in transit are included at their forecast (ETA) arrival date, so
    current/future periods will look artificially low until the remaining
    cargoes load and appear in the trackings<br>
    The origin chart is delivered cargoes only. Each month shows that month's
    top 4 origin countries, with every other origin grouped as Other. The
    current month is drawn lighter because it is still incomplete
  </p>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Supply: Sanctioned Russian LNG (Kpler, SCI)</h3>
  <div style="margin-top: 8px;">{beihai_month_img_html}</div>
  <div style="margin-top: 8px;">{beihai_origin_img_html}</div>
  <p style="font-family:Segoe UI,Arial,sans-serif; margin:6px 0 0 0; font-size:10px; color:#777;">
    PipeChina Beihai took its first sanctioned Russian cargo on 28 Aug 2025 and imports have ramped
    up since. Cargoes arrive direct from the sanctioned ALNG2 (Arctic LNG 2) and Portovaya terminals
    or via the Murmansk and Kamchatka STS transfer locations: when the Northern Sea Route is open,
    ice-breakers shuttle ALNG2 volumes to the Kamchatka STS for onward delivery to China (with some
    vessels sailing on direct without unloading); otherwise flows route via the Murmansk STS<br>
    Energy Aspects speculate that all sanctioned Russian gas at Beihai has been loaded onto trucks
    rather than sent into the grid (potentially due to sanction concerns). Their assumed max truck
    loading capacity is {BEIHAI_TRUCK_CAPACITY_MT:g} Mt/month (~{BEIHAI_TRUCK_CAPACITY_MCM:.0f}
    mcm/month, dotted line), so sustained imports above that level imply gas is likely being sent
    into the grid. Actual truck loadings out of the terminal (SCI daily data summed per complete
    month, orange line) are overlaid for comparison<br>
    The PipeChina Longkou terminal is speculated to start receiving sanctioned cargoes too once it
    comes online (currently expected Oct-26)
  </p>
  <div style="margin-top: 12px;">{beihai_fleet_html}</div>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Supply: LNG (SCI)</h3>
  <table style="border-collapse:collapse;"><tr>
    <td style="vertical-align:top;">{lng_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{lng_yoy_html}</td>
  </tr></table>
  <p style="font-family:Segoe UI,Arial,sans-serif; margin:6px 0 0 0; font-size:10px; color:#777;">
    SCI LNG data is based on official Chinese customs data and won't match the
    Kpler cargo trackings exactly<br>
    The latest SCI month is likely to include estimated data, so may deviate
    from Kpler until customs figures are finalised
  </p>
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{lng_hist_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{lng_delta_html}</td>
  </tr></table>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Supply: Domestic Production</h3>
  <table style="border-collapse:collapse;"><tr>
    <td style="vertical-align:top;">{prod_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{prod_yoy_html}</td>
  </tr></table>
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{fcst_hist_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{fcst_delta_html}</td>
  </tr></table>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Supply: Pipeline</h3>
  <table style="border-collapse:collapse;"><tr>
    <td style="vertical-align:top;">{png_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{png_yoy_html}</td>
  </tr></table>
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{png_hist_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{png_delta_html}</td>
  </tr></table>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Demand: Total Demand</h3>
  <table style="border-collapse:collapse;"><tr>
    <td style="vertical-align:top;">{dem_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{dem_yoy_html}</td>
  </tr></table>
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{dem_hist_img_html}</td>
    <td style="vertical-align:top; padding-left:16px;">{dem_delta_html}</td>
  </tr></table>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Demand: Breakdown</h3>
  {struct_img_html}
  <div style="margin-top: 8px;">{struct_share_html}</div>
  <div style="margin-top: 12px;">{sector_img_html}</div>
  <div style="margin-top: 8px;">{sector_table_html}</div>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Supply vs Demand</h3>
  {sd_img_html}

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Weekly: Data</h3>
  {wk_truck_html}
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{wk_term_stock_html}</td>
    <td style="vertical-align:top; padding-left:8px;">{wk_plant_stock_html}</td>
  </tr></table>
  <p style="font-family:Segoe UI,Arial,sans-serif; margin:6px 0 0 0; font-size:10px; color:#777;">
    SCI publish stock levels in mcm of LNG (liquid), converted to gas-equivalent mcm
    using a factor of {KPLER_M3_TO_MCM:g} (1 m3 of LNG &asymp; 600 m3 of gas) - the same
    factor as used for the Kpler cargo volumes above
  </p>
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{wk_term_fill_html}</td>
    <td style="vertical-align:top; padding-left:8px;">{wk_plant_fill_html}</td>
  </tr></table>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Weekly: Prices</h3>
  <table style="border-collapse:collapse;"><tr>
    <td style="vertical-align:top;">{wk_exworks_html}</td>
    <td style="vertical-align:top; padding-left:8px;">{wk_exterm_html}</td>
  </tr></table>
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{wk_hgv_lng_html}</td>
    <td style="vertical-align:top; padding-left:8px;">{wk_hgv_diesel_html}</td>
  </tr></table>
  <table style="border-collapse:collapse; margin-top: 8px;"><tr>
    <td style="vertical-align:top;">{wk_ind_lng_html}</td>
    <td style="vertical-align:top; padding-left:8px;">{wk_ind_coal_html}</td>
  </tr></table>
  <div style="margin-top: 8px;">{wk_ind_lpg_html}</div>
  <br>
</div>
"""
    
    send_email(receivers, 
               f"China Gas+LNG Summary: {today.strftime('%d %b %Y')}", 
               email_body,
               from_address='eu.gap.reports@jainglobal.com') 
    
    _write_stamp_date(last_forecast_file, latest_forecast_date)
    
    logging.info('Done')



except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, 'ERROR China Gas+LNG Summary', str(tb))    

        