"""Threshold -> status per signal, and aggregation to a product status.

Pure functions over the signal values produced by :mod:`vol_monitor.signals`
plus the threshold table from :mod:`vol_monitor.config`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Literal

from vol_monitor.config import ActionsConfig, MonitorConfig, Threshold

Status = Literal["green", "amber", "red", "na"]

#: Display groups, in the order they appear in the email.
GROUPS: tuple[str, ...] = ("Range", "Vol", "Stretch", "Corr", "Size")

#: Status ordering for aggregation / comparison.
_RANK: dict[str, int] = {"na": -1, "green": 0, "amber": 1, "red": 2}


@dataclass(frozen=True)
class SignalSpec:
    """How one signal is scored and displayed."""

    name: str
    label: str
    group: str
    # high      -> larger is worse
    # abs       -> larger absolute value is worse
    # two_sided -> amber/red outside the [lo, hi] band
    # bool      -> amber when truthy (no red)
    mode: Literal["high", "abs", "two_sided", "bool"]
    fmt: str = "{:.2f}"
    suffix: str = ""
    scale: float = 1.0
    #: Signals marked informational are reported but never drive a status.
    informational: bool = False


#: The five triggers that actually imply "cut". Everything else
#: :mod:`vol_monitor.signals` computes still lands in the CSV for
#: backtesting, but it does not drive a status or clutter the email.
SIGNAL_SPECS: tuple[SignalSpec, ...] = (
    # Is today getting away from us, right now?
    SignalSpec("range_vs_typical", "Range vs typical", "Range", "high", "{:.2f}", "x"),
    # Is the vol regime shifting under us?
    SignalSpec("rv_ratio_10_60", "RV 10/60", "Vol", "high", "{:.2f}", "x"),
    # How far has price run from its anchor?
    SignalSpec("dist_ma20_atr", "Stretch", "Stretch", "abs", "{:+.1f}", " ATR"),
    # Is the book actually one bet?
    # 3dp: at these levels "{:.2f}" rounds 0.995 to a misleading "1.00".
    SignalSpec("corr_20d_abs", "Max |corr|", "Corr", "high", "{:.3f}"),
    # How much smaller should the position be on vol alone?
    SignalSpec("vol_implied_cut", "Vol-implied cut", "Size", "high", "{:.0f}", "%", scale=100.0),
)

SPEC_BY_NAME: dict[str, SignalSpec] = {s.name: s for s in SIGNAL_SPECS}


@dataclass(frozen=True)
class SignalResult:
    name: str
    label: str
    group: str
    value: float | None
    status: Status
    display: str
    informational: bool
    #: Optional qualifier shown next to the value, e.g. the peer driving a
    #: correlation. Keeps "0.99" from reading as an unattributable number.
    context: str = ""

    @property
    def fired(self) -> bool:
        return self.status in ("amber", "red")


@dataclass
class ProductRegime:
    product: str
    status: Status
    action: str
    signals: list[SignalResult] = field(default_factory=list)
    amber_count: int = 0
    red_count: int = 0
    prev_status: Status | None = None
    missing_iv: bool = False

    @property
    def changed(self) -> bool:
        return self.prev_status is not None and self.prev_status != self.status

    @property
    def direction(self) -> str:
        """Arrow for a status change: worse is up, better is down."""
        if not self.changed or self.prev_status is None:
            return ""
        return "up" if _RANK[self.status] > _RANK[self.prev_status] else "down"

    def by_group(self, group: str) -> list[SignalResult]:
        return [s for s in self.signals if s.group == group]

    def group_status(self, group: str) -> Status:
        members = [s for s in self.by_group(group) if not s.informational]
        return aggregate_status([s.status for s in members])

    @property
    def fired_signals(self) -> list[SignalResult]:
        order = {"red": 0, "amber": 1}
        return sorted(
            (s for s in self.signals if s.fired and not s.informational),
            key=lambda s: (order[s.status], s.name),
        )


def _is_missing(value: float | None) -> bool:
    return value is None or (isinstance(value, float) and math.isnan(value))


def classify(value: float | None, threshold: Threshold | None, mode: str) -> Status:
    """Map one signal value onto a traffic light."""
    if _is_missing(value):
        return "na"
    v = float(value)  # type: ignore[arg-type]

    if mode == "bool":
        if v == 0:
            return "green"
        return "amber"

    if threshold is None:
        return "na"

    if mode == "two_sided":
        if not threshold.two_sided:
            msg = "two-sided signal requires [lo, hi] thresholds"
            raise ValueError(msg)
        red_lo, red_hi = threshold.red  # type: ignore[misc]
        amber_lo, amber_hi = threshold.amber  # type: ignore[misc]
        if v <= red_lo or v >= red_hi:
            return "red"
        if v <= amber_lo or v >= amber_hi:
            return "amber"
        return "green"

    if threshold.two_sided:
        msg = f"one-sided signal got a two-sided threshold: {threshold}"
        raise ValueError(msg)

    x = abs(v) if mode == "abs" else v
    if x >= float(threshold.red):  # type: ignore[arg-type]
        return "red"
    if x >= float(threshold.amber):  # type: ignore[arg-type]
        return "amber"
    return "green"


def aggregate_status(statuses: list[Status]) -> Status:
    """Worst-of for a group of signals; all-``na`` stays ``na``."""
    known = [s for s in statuses if s != "na"]
    if not known:
        return "na"
    return max(known, key=lambda s: _RANK[s])


def format_value(spec: SignalSpec, value: float | None) -> str:
    if _is_missing(value):
        return "n/a"
    v = float(value)  # type: ignore[arg-type]
    if spec.mode == "bool":
        if spec.name == "rsi_divergence":
            if v > 0:
                return "bearish"
            if v < 0:
                return "bullish"
            return "no"
        return "yes" if v != 0 else "no"
    return spec.fmt.format(v * spec.scale) + spec.suffix


def evaluate_product(
    product: str,
    values: dict[str, Any],
    config: MonitorConfig,
    prev_status: Status | None = None,
    missing_iv: bool = False,
) -> ProductRegime:
    """Score every signal for one product and aggregate to a product status."""
    results: list[SignalResult] = []
    for spec in SIGNAL_SPECS:
        raw = values.get(spec.name)
        threshold = config.threshold_for(product, spec.name)
        status = (
            "na"
            if spec.informational
            else classify(raw, threshold, spec.mode)
        )
        context = ""
        if spec.name in ("corr_20d_abs", "corr_spike"):
            peer = values.get("corr_20d_peer")
            context = f"vs {peer}" if isinstance(peer, str) else ""
        results.append(
            SignalResult(
                name=spec.name,
                label=spec.label,
                group=spec.group,
                value=None if _is_missing(raw) else float(raw),  # type: ignore[arg-type]
                status=status,
                display=format_value(spec, raw),
                informational=spec.informational,
                context=context,
            )
        )

    scored = [r for r in results if not r.informational]
    red_count = sum(1 for r in scored if r.status == "red")
    amber_count = sum(1 for r in scored if r.status == "amber")

    status = product_status(red_count, amber_count, config.actions)
    return ProductRegime(
        product=product,
        status=status,
        action=action_for(status, config.actions),
        signals=results,
        amber_count=amber_count,
        red_count=red_count,
        prev_status=prev_status,
        missing_iv=missing_iv,
    )


def product_status(red_count: int, amber_count: int, actions: ActionsConfig) -> Status:
    if red_count > 0:
        return "red"
    if amber_count >= actions.amber_count_for_product_amber:
        return "amber"
    return "green"


def action_for(status: Status, actions: ActionsConfig) -> str:
    return {
        "red": actions.product_red,
        "amber": actions.product_amber,
        "green": actions.product_green,
        "na": actions.product_green,
    }[status]
