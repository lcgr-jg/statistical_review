"""End-to-end orchestration: fetch -> signals -> regime -> sizing -> render -> send.

Deterministic for a given ``--date`` and a warm cache: the same inputs
produce byte-identical HTML apart from the generation timestamp.
"""

from __future__ import annotations

import datetime as dt
import json
import logging
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import polars as pl

from vol_monitor import bbg, render
from vol_monitor import sizing as sizing_mod
from vol_monitor.config import MonitorConfig, ProductConfig, load_config
from vol_monitor.deliver import Attachment, send, send_failure_alert
from vol_monitor.persist import Persistence, ProductState, RunRecord
from vol_monitor.regime import SIGNAL_SPECS, ProductRegime, evaluate_product
from vol_monitor.signals import (
    compute_signals,
    correlation_signals,
    intraday_range_signals,
    intraday_vol_series,
    zscore_of_last,
)

log = logging.getLogger(__name__)

PACKAGE_DIR = Path(__file__).parent


# ---------------------------------------------------------------------------
# structured logging
# ---------------------------------------------------------------------------
class JsonFormatter(logging.Formatter):
    """JSON lines with run_date / product / stage when the caller supplies them."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key in ("run_date", "product", "stage"):
            value = getattr(record, key, None)
            if value is not None:
                payload[key] = str(value)
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload)


def configure_logging(level: int = logging.INFO, json_logs: bool = True) -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        JsonFormatter()
        if json_logs
        else logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    )
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level)


# ---------------------------------------------------------------------------
# optional internal feeds
# ---------------------------------------------------------------------------
def load_positions(config: MonitorConfig) -> tuple[dict[str, float], dict[str, dict[str, float]]]:
    """Current lots and MTD P&L / monthly budget per product.

    Absent or failing feeds return empty dicts - the email drops the
    corresponding sections rather than erroring.
    """
    if not config.positions.enabled:
        return {}, {}
    try:
        from jain_commods.core.interfaces.snowflake import SnowFlake

        sf = SnowFlake(
            database=config.positions.database,
            schema=config.positions.schema_,
            role=config.positions.role,
        )
        positions: dict[str, float] = {}
        pnl: dict[str, dict[str, float]] = {}
        cur = sf._conn.cursor()  # noqa: SLF001
        try:
            if config.positions.positions_query:
                cur.execute(config.positions.positions_query)
                positions = {row[0]: float(row[1]) for row in cur.fetchall()}
            if config.positions.pnl_query:
                cur.execute(config.positions.pnl_query)
                pnl = {
                    row[0]: {"mtd_pnl": float(row[1]), "monthly_budget": float(row[2])}
                    for row in cur.fetchall()
                }
        finally:
            cur.close()
        return positions, pnl
    except Exception as exc:  # noqa: BLE001 - optional feed
        log.warning("position/P&L feed unavailable (%s); omitting those sections", exc)
        return {}, {}


# ---------------------------------------------------------------------------
# per-product signal extraction
# ---------------------------------------------------------------------------
def _latest_values(frame: pl.DataFrame) -> dict[str, float | None]:
    """Last row of the signal frame as a plain dict of floats/None."""
    if frame.is_empty():
        return {}
    row = frame.tail(1).to_dicts()[0]
    out: dict[str, float | None] = {}
    for key, value in row.items():
        if key == "date":
            continue
        if isinstance(value, bool):
            out[key] = 1.0 if value else 0.0
        elif isinstance(value, (int, float)):
            out[key] = float(value)
        else:
            out[key] = None
    return out


def compute_product_frames(
    config: MonitorConfig,
    client: bbg.BloombergClient,
    start: dt.date,
    end: dt.date,
) -> tuple[dict[str, pl.DataFrame], dict[str, bool]]:
    """Signal frame per product, plus whether IV was missing for each."""
    frames: dict[str, pl.DataFrame] = {}
    missing_iv: dict[str, bool] = {}
    for product in config.products:
        log.info(
            "fetching bars", extra={"product": product.name, "stage": "bbg_daily_bars"}
        )
        bars = bbg.fetch_product_bars(
            client, product, start, end, iv_staleness_days=config.run.iv_staleness_days
        )
        if bars.is_empty():
            log.warning(
                "no data, product skipped",
                extra={"product": product.name, "stage": "bbg_daily_bars"},
            )
            continue
        frame = compute_signals(
            bars,
            roll_method=config.roll_method_for(product.name),
            half_lives=config.run.vol_half_lives,
        )
        frames[product.name] = frame
        iv_col = frame.get_column("iv_atm_1m")
        missing_iv[product.name] = iv_col.null_count() == frame.height
    return frames, missing_iv


def fetch_intraday_frames(
    config: MonitorConfig,
    client: bbg.BloombergClient,
    run_date: dt.date,
) -> dict[str, pl.DataFrame]:
    """Intraday bars per product, or an empty dict when intraday is disabled.

    Intraday is an enhancement, not a dependency: if B-PIPE will not serve
    bars (they only go back ~140 days, so any older ``--date`` returns
    nothing) the range trigger degrades to n/a and the rest still works.
    """
    if not config.intraday.enabled:
        return {}
    end = dt.datetime.combine(run_date, dt.time(23, 59))
    start = end - dt.timedelta(days=config.intraday.lookback_days)
    out: dict[str, pl.DataFrame] = {}
    for product in config.products:
        log.info(
            "fetching intraday",
            extra={"product": product.name, "stage": "intraday_bars"},
        )
        bars = bbg.fetch_intraday(
            client,
            product,
            start,
            end,
            interval_min=config.intraday.bar_minutes,
            timezone=config.run.timezone,
        )
        if not bars.is_empty():
            out[product.name] = bars
    return out


def compute_signals_intraday(
    bars: pl.DataFrame, profile_sessions: int
) -> dict[str, float | None]:
    return intraday_range_signals(bars, sessions=profile_sessions)


def build_returns_frame(frames: dict[str, pl.DataFrame]) -> pl.DataFrame:
    """Wide date x product frame of log returns for the correlation step."""
    out: pl.DataFrame | None = None
    for name, frame in frames.items():
        part = frame.select(["date", pl.col("r").alias(name)])
        out = part if out is None else out.join(part, on="date", how="full", coalesce=True)
    return out.sort("date") if out is not None else pl.DataFrame({"date": []})


# ---------------------------------------------------------------------------
# main entry point
# ---------------------------------------------------------------------------
def run_vol_monitor(
    run_date: dt.date | str | None = None,
    config_path: str | Path | None = None,
    dry_run: bool = False,
    recipients: list[str] | str | None = None,
    use_cache: bool = True,
    output_dir: str | Path | None = None,
    send_email: bool = True,
    intraday_run: bool = False,
) -> dict[str, Any]:
    """Run the monitor for one date and (unless ``dry_run``) email the result.

    ``intraday_run`` marks this as a mid-session re-check: the email is then
    only sent when a product's status has got worse since the last check.
    """
    started = dt.datetime.now()
    config = load_config(config_path)

    if run_date is None:
        run_date = dt.date.today()
    elif isinstance(run_date, str):
        run_date = dt.date.fromisoformat(run_date)

    if isinstance(recipients, str):
        recipients = [r.strip() for r in recipients.split(",") if r.strip()]
    to = list(recipients) if recipients else list(config.run.recipients)

    out_dir = Path(output_dir) if output_dir else PACKAGE_DIR / config.run.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    record = RunRecord(
        run_date=run_date.isoformat(), started_at=started.isoformat(timespec="seconds")
    )
    persistence = Persistence(config.persist, PACKAGE_DIR)

    try:
        result = _run_inner(
            config, run_date, to, dry_run, use_cache, out_dir, persistence, record,
            send_email, intraday_run,
        )
    except Exception as exc:
        record.finished_at = dt.datetime.now().isoformat(timespec="seconds")
        record.success = False
        record.error = f"{type(exc).__name__}: {exc}"
        persistence.save_run(record)
        log.exception("vol monitor failed", extra={"run_date": run_date, "stage": "run"})
        alert_to = config.run.error_recipients or to
        if not dry_run and send_email and alert_to:
            send_failure_alert(config.delivery, alert_to, run_date.isoformat(), record.error)
        raise

    record.finished_at = dt.datetime.now().isoformat(timespec="seconds")
    record.success = True
    persistence.save_run(record)
    return result


def _run_inner(
    config: MonitorConfig,
    run_date: dt.date,
    to: list[str],
    dry_run: bool,
    use_cache: bool,
    out_dir: Path,
    persistence: Persistence,
    record: RunRecord,
    send_email: bool,
    intraday_run: bool = False,
) -> dict[str, Any]:
    t0 = time.perf_counter()
    start = run_date - dt.timedelta(days=config.run.lookback_days)

    # -- data ---------------------------------------------------------------
    client = bbg.BloombergClient(
        cache_dir=PACKAGE_DIR / config.run.cache_dir,
        on_server=config.run.bloomberg_on_server,
        use_cache=use_cache,
    )
    frames, missing_iv = compute_product_frames(config, client, start, run_date)
    if not frames:
        msg = "no product returned any data from Bloomberg"
        raise RuntimeError(msg)
    fx = bbg.fetch_fx(client, config, start, run_date)

    # -- correlation --------------------------------------------------------
    log.info("correlations", extra={"run_date": run_date, "stage": "vol_signals"})
    corr_per_product, corr_short, corr_long = correlation_signals(
        build_returns_frame(frames),
        groups={p.name: p.group for p in config.products},
        scope=config.run.corr_scope,
    )
    corr_lookup = {row["product"]: row for row in corr_per_product.to_dicts()}

    # -- intraday range profile ---------------------------------------------
    intraday_bars = fetch_intraday_frames(config, client, run_date)
    intraday_stats: dict[str, dict[str, float | None]] = {
        name: compute_signals_intraday(bars, config.intraday.profile_sessions)
        for name, bars in intraday_bars.items()
    }
    intraday_vol: dict[str, pl.DataFrame] = {
        name: intraday_vol_series(bars) for name, bars in intraday_bars.items()
    }

    # -- optional feeds -----------------------------------------------------
    positions, pnl = load_positions(config)

    # -- regime + sizing ----------------------------------------------------
    prev_state = persistence.load_state()
    regimes: list[ProductRegime] = []
    sizings: dict[str, sizing_mod.SizingResult] = {}
    drawdowns: dict[str, sizing_mod.DrawdownResult] = {}
    new_state: dict[str, ProductState] = {}
    csv_rows: list[dict[str, Any]] = []
    signal_rows: list[dict[str, Any]] = []
    data_timestamps: dict[str, str] = {}
    vol_panels: dict[str, str | None] = {}
    vol_table: list[dict[str, Any]] = []

    for product in config.products:
        frame = frames.get(product.name)
        if frame is None:
            continue
        values = _latest_values(frame)
        values.update(_corr_values(corr_lookup.get(product.name)))

        lots = positions.get(product.name)
        adv = values.get("adv_20")
        values["pos_pct_adv"] = (
            abs(lots) / adv if lots is not None and adv not in (None, 0) else None
        )
        values.update(intraday_stats.get(product.name, {}))

        prior = prev_state.get(product.name)

        # Sizing has to run before the regime, because vol_implied_cut is one
        # of the five triggers.
        sz = sizing_mod.compute_sizing(
            product=product.name,
            close=values.get("close"),
            ewma_fast=values.get("ewma_fast"),
            multiplier=product.multiplier,
            fx_to_usd=fx.get(product.currency),
            target_daily_pnl_vol_usd=config.target_vol_for(product.name),
            current_lots=lots,
            sigma_at_last_resize=prior.sigma_at_last_resize if prior else None,
            resize_band=config.run.resize_band,
        )
        sizings[product.name] = sz
        values["vol_implied_cut"] = sz.vol_implied_cut

        regime = evaluate_product(
            product.name,
            values,
            config,
            prev_status=prior.last_status if prior else None,  # type: ignore[arg-type]
            missing_iv=missing_iv.get(product.name, False),
        )
        regimes.append(regime)

        budget = pnl.get(product.name, {})
        drawdowns[product.name] = sizing_mod.compute_drawdown(
            product.name,
            budget.get("mtd_pnl"),
            budget.get("monthly_budget"),
            red_at=config.actions.drawdown_red_at,
            red_action=config.actions.drawdown_red,
        )

        new_state[product.name] = _next_state(product, sz, regime, prior, run_date)
        last_date = str(frame.get_column("date").max())
        iv_asof = client.report.iv_asof.get(product.name)
        data_timestamps[product.name] = (
            f"{last_date} (IV {iv_asof})" if iv_asof and iv_asof != last_date else last_date
        )
        iv_series = intraday_vol.get(product.name)
        vol_panels[product.name] = render.vol_panel_png(
            frame, iv_series, config.run.vol_half_lives
        )
        vol_table.append(_vol_row(product.name, frame, iv_series, config.run.vol_half_lives))

        csv_rows.append(_csv_row(product, run_date, values, regime, sz, drawdowns[product.name]))
        signal_rows.append(_signal_row(product, regime, sz, values))

    # -- persist ------------------------------------------------------------
    persistence.save_signals(run_date, signal_rows)
    persistence.save_state(new_state)

    # -- render -------------------------------------------------------------
    log.info("rendering", extra={"run_date": run_date, "stage": "vol_monitor_email"})
    warnings = list(client.report.warnings) + list(persistence.errors)
    generated_at = dt.datetime.now()
    html = render.render_email(
        config=config,
        run_date=run_date,
        generated_at=generated_at,
        regimes=regimes,
        sizing=sizings,
        drawdowns=drawdowns,
        sparklines={},
        corr_short=corr_short,
        corr_long=corr_long,
        data_timestamps=data_timestamps,
        warnings=warnings,
        intraday=intraday_stats,
        is_intraday_run=intraday_run,
        vol_panels=vol_panels,
        vol_table=vol_table,
        half_lives=config.run.vol_half_lives,
    )

    n_red = sum(1 for r in regimes if r.status == "red")
    n_amber = sum(1 for r in regimes if r.status == "amber")
    escalated = [r.product for r in regimes if r.changed and r.direction == "up"]
    any_change = any(r.changed for r in regimes)
    subject = render.build_subject(
        run_date,
        n_red,
        n_amber,
        any_change,
        intraday_at=generated_at.strftime("%H:%M") if intraday_run else None,
    )

    csv_bytes = render.build_csv(csv_rows)
    csv_name = f"vol_monitor_{run_date:%Y%m%d}.csv"
    html_path = out_dir / f"vol_monitor_{run_date:%Y%m%d}.html"
    html_path.write_text(html, encoding="utf-8")
    (out_dir / csv_name).write_bytes(csv_bytes)

    record.n_products = len(regimes)
    record.n_red = n_red
    record.n_amber = n_amber
    record.bloomberg_latency_s = round(client.report.latency_s, 2)
    record.warnings = warnings

    # An intraday re-check only earns an email when something got worse -
    # otherwise the desk learns to ignore it, which defeats the point.
    suppressed = (
        intraday_run
        and config.intraday.send_on_escalation_only
        and not escalated
    )

    transport = None
    if dry_run or not send_email:
        log.info("dry run - not sending", extra={"run_date": run_date, "stage": "deliver"})
    elif suppressed:
        log.info(
            "intraday check, nothing escalated - not sending",
            extra={"run_date": run_date, "stage": "deliver"},
        )
    elif not to:
        log.warning("no recipients - not sending")
    else:
        transport = send(
            config.delivery,
            subject,
            html,
            to,
            [Attachment(csv_name, csv_bytes, "text/csv")],
        )

    elapsed = time.perf_counter() - t0
    log.info(
        "run complete in %.1fs (%d red, %d amber, escalated: %s)",
        elapsed,
        n_red,
        n_amber,
        ", ".join(escalated) or "none",
        extra={"run_date": run_date, "stage": "run"},
    )

    return {
        "status": "ok",
        "run_date": run_date.isoformat(),
        "n_products": len(regimes),
        "n_red": n_red,
        "n_amber": n_amber,
        "status_changes": [r.product for r in regimes if r.changed],
        "escalated": escalated,
        "intraday_run": intraday_run,
        "email_suppressed": bool(suppressed),
        "subject": subject,
        "html_path": str(html_path),
        "csv_path": str(out_dir / csv_name),
        "email_sent": transport is not None,
        "transport": transport,
        "recipients": to,
        "warnings": warnings,
        "elapsed_s": round(elapsed, 2),
        "bloomberg_latency_s": round(client.report.latency_s, 2),
    }


# ---------------------------------------------------------------------------
# row builders
# ---------------------------------------------------------------------------
def _vol_row(
    product: str,
    frame: pl.DataFrame,
    intraday_vol: pl.DataFrame | None,
    half_lives: tuple[int, ...],
) -> dict[str, Any]:
    """One heatmap row: each vol measure's current level and its own z-score."""
    last = frame.tail(1).to_dicts()[0] if frame.height else {}
    cells: list[dict[str, Any]] = []
    for h in half_lives:
        cells.append(
            {
                "label": f"EWMA {h}d",
                "level": last.get(f"ewma_hl{h}"),
                "z": last.get(f"ewma_hl{h}_z"),
            }
        )

    iv_level: float | None = None
    iv_z: float | None = None
    if intraday_vol is not None and not intraday_vol.is_empty():
        series = intraday_vol.get_column("iv_realized").cast(pl.Float64).to_numpy()
        series = np.asarray(series, dtype=float)
        if series.size and np.isfinite(series[-1]):
            iv_level = float(series[-1])
            iv_z = zscore_of_last(series)
    cells.append({"label": "Within-day", "level": iv_level, "z": iv_z})

    # 50-delta implied vol, where the product has an option chain at all.
    atm_level = last.get("iv_atm_1m")
    atm_z: float | None = None
    if atm_level is not None and "iv_atm_1m" in frame.columns:
        atm_series = np.asarray(
            frame.get_column("iv_atm_1m").cast(pl.Float64).to_numpy(), dtype=float
        )
        atm_z = zscore_of_last(atm_series)
    cells.append({"label": "Implied 50D", "level": atm_level, "z": atm_z})

    ratio = last.get("rv_ratio_10_60")
    return {
        "product": product,
        "cells": cells,
        "has_iv": atm_level is not None,
        "ratio": ratio,
        "ratio_status": (
            "red" if ratio is not None and ratio >= 2.0
            else "amber" if ratio is not None and ratio >= 1.5
            else "green"
        ),
    }


def _corr_values(row: dict[str, Any] | None) -> dict[str, float | None]:
    if not row:
        return {"corr_20d_abs": None, "corr_spike": None}
    return {
        "corr_20d_abs": row.get("corr_20d_abs"),
        "corr_20d_signed": row.get("corr_20d_signed"),
        "corr_120d_signed": row.get("corr_120d_signed"),
        "corr_spike": 1.0 if row.get("corr_spike") else 0.0,
        "corr_20d_peer": row.get("corr_20d_peer"),
    }


def _next_state(
    product: ProductConfig,
    sz: sizing_mod.SizingResult,
    regime: ProductRegime,
    prior: ProductState | None,
    run_date: dt.date,
) -> ProductState:
    """Carry state forward, re-baselining sigma whenever the resize flag fires."""
    sigma = prior.sigma_at_last_resize if prior else None
    resize_date = prior.last_resize_date if prior else None
    if sz.sigma_daily is not None and (sigma is None or sz.resize_flag):
        sigma = sz.sigma_daily
        resize_date = run_date.isoformat()
    return ProductState(
        product=product.name,
        sigma_at_last_resize=sigma,
        last_resize_date=resize_date,
        last_status=regime.status,
        last_run_date=run_date.isoformat(),
    )


def _csv_row(
    product: ProductConfig,
    run_date: dt.date,
    values: dict[str, Any],
    regime: ProductRegime,
    sz: sizing_mod.SizingResult,
    dd: sizing_mod.DrawdownResult,
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "run_date": run_date.isoformat(),
        "product": product.name,
        "group": product.group,
        "ticker": product.ticker,
        "option_ticker": product.option_ticker or "",
        "currency": product.currency,
        "status": regime.status,
        "prev_status": regime.prev_status or "",
        "action": regime.action,
        "amber_count": regime.amber_count,
        "red_count": regime.red_count,
    }
    row.update({k: v for k, v in values.items() if not isinstance(v, (dict, list))})
    for spec in SIGNAL_SPECS:
        row[f"status_{spec.name}"] = next(
            (s.status for s in regime.signals if s.name == spec.name), "na"
        )
    row.update({f"sizing_{k}": v for k, v in asdict(sz).items() if k != "product"})
    row.update({f"dd_{k}": v for k, v in asdict(dd).items() if k != "product"})
    return row


def _signal_row(
    product: ProductConfig,
    regime: ProductRegime,
    sz: sizing_mod.SizingResult,
    values: dict[str, Any],
) -> dict[str, Any]:
    payload = {
        "values": {k: v for k, v in values.items() if not isinstance(v, (dict, list))},
        "statuses": {s.name: s.status for s in regime.signals},
        "sizing": asdict(sz),
        "ticker": product.ticker,
        "currency": product.currency,
        "multiplier": product.multiplier,
    }
    return {
        "product": product.name,
        "product_group": product.group,
        "status": regime.status,
        "prev_status": regime.prev_status,
        "action": regime.action,
        "amber_count": regime.amber_count,
        "red_count": regime.red_count,
        "payload": json.dumps(payload, default=str),
    }


# ---------------------------------------------------------------------------
# backfill (no email) for threshold backtesting
# ---------------------------------------------------------------------------
def backfill(
    start_date: dt.date | str,
    end_date: dt.date | str,
    config_path: str | Path | None = None,
    use_cache: bool = True,
) -> dict[str, Any]:
    """Run signals + regime over a date range, persisting but never emailing."""
    if isinstance(start_date, str):
        start_date = dt.date.fromisoformat(start_date)
    if isinstance(end_date, str):
        end_date = dt.date.fromisoformat(end_date)

    days: list[str] = []
    cursor = start_date
    while cursor <= end_date:
        if cursor.weekday() < 5:
            run_vol_monitor(
                run_date=cursor,
                config_path=config_path,
                dry_run=True,
                use_cache=use_cache,
                send_email=False,
            )
            days.append(cursor.isoformat())
        cursor += dt.timedelta(days=1)

    return {"status": "ok", "days": days, "n_days": len(days)}
