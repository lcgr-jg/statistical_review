"""Pure signal computation: DataFrame in, DataFrame out, no I/O.

Everything here is deterministic and free of Bloomberg/Snowflake/config
dependencies so it can be unit-tested against reference implementations and
re-run over history for threshold backfills.

Input frame (one product), columns:
    date, open, high, low, close, volume, oi, gen_ticker,
    iv_atm_1m, iv_25c, iv_25p      (option columns nullable)

Output: one row per input date with the full signal column set.
"""

from __future__ import annotations

import math
from typing import Any, Callable

import numpy as np
import numpy.typing as npt
import polars as pl

TRADING_DAYS = 252

#: Columns the input frame must provide.
REQUIRED_COLUMNS = ("date", "open", "high", "low", "close", "volume", "oi")

#: Optional columns; filled with nulls when the product has no option data.
OPTIONAL_COLUMNS = ("gen_ticker", "iv_atm_1m", "iv_25c", "iv_25p")

FloatArray = npt.NDArray[np.float64]


# ---------------------------------------------------------------------------
# numpy kernels for the recursive / windowed pieces polars has no builtin for
# ---------------------------------------------------------------------------
def wilder_smooth(values: FloatArray, n: int) -> FloatArray:
    """Wilder's smoothing, seeded with the simple mean of the first ``n`` obs.

    ``S_n = mean(v_1..v_n)`` then ``S_t = (S_{t-1}*(n-1) + v_t) / n``.
    NaNs before the seed window propagate; NaNs afterwards carry the previous
    value forward rather than poisoning the recursion.
    """
    out = np.full(values.shape, np.nan, dtype=np.float64)
    finite = np.isfinite(values)
    if finite.sum() < n:
        return out

    # Seed on the first n finite observations.
    idx_finite = np.flatnonzero(finite)
    seed_end = int(idx_finite[n - 1])
    prev = float(np.mean(values[idx_finite[:n]]))
    out[seed_end] = prev

    for i in range(seed_end + 1, values.shape[0]):
        v = values[i]
        if np.isfinite(v):
            prev = (prev * (n - 1) + v) / n
        out[i] = prev
    return out


def ewma_vol(returns: FloatArray, lam: float, annualise: bool = True) -> FloatArray:
    """RiskMetrics EWMA volatility: ``s2_t = lam*s2_{t-1} + (1-lam)*r_t^2``.

    Seeded with the sample variance of the first ``1/(1-lam)`` finite returns
    so the series does not start at a single squared return. Masked (NaN)
    returns hold the previous estimate rather than updating it.
    """
    out = np.full(returns.shape, np.nan, dtype=np.float64)
    finite = np.isfinite(returns)
    warmup = max(round(1.0 / (1.0 - lam)), 2)
    idx_finite = np.flatnonzero(finite)
    if idx_finite.size < warmup:
        return out

    seed_end = int(idx_finite[warmup - 1])
    prev = float(np.mean(returns[idx_finite[:warmup]] ** 2))
    out[seed_end] = prev

    for i in range(seed_end + 1, returns.shape[0]):
        r = returns[i]
        if np.isfinite(r):
            prev = lam * prev + (1.0 - lam) * r * r
        out[i] = prev

    vol = np.sqrt(out)
    return vol * np.sqrt(TRADING_DAYS) if annualise else vol


def lambda_from_half_life(half_life: float) -> float:
    """EWMA decay for a given half-life in days: ``lam = 0.5 ** (1/H)``.

    Half-lives read more naturally than lambdas on a chart legend. For
    reference the RiskMetrics pair sits at H = 11.0 (0.94) and H = 22.8
    (0.97).
    """
    if half_life <= 0:
        msg = f"half_life must be positive, got {half_life}"
        raise ValueError(msg)
    return float(0.5 ** (1.0 / half_life))


def ewma_vol_half_life(
    returns: FloatArray, half_life: float, annualise: bool = True
) -> FloatArray:
    """EWMA volatility parameterised by half-life rather than lambda."""
    return ewma_vol(returns, lambda_from_half_life(half_life), annualise=annualise)


def rolling_rank_pct(values: FloatArray, window: int, min_obs: int) -> FloatArray:
    """Percentile rank of each point within its trailing window, in [0, 1].

    Rank is the fraction of finite window observations at or below the current
    value, so an all-time high maps to 1.0. NaN where the current value is NaN
    or the window holds fewer than ``min_obs`` finite points.
    """
    n = values.shape[0]
    out = np.full(n, np.nan, dtype=np.float64)
    for i in range(n):
        cur = values[i]
        if not np.isfinite(cur):
            continue
        lo = max(0, i - window + 1)
        win = values[lo : i + 1]
        win = win[np.isfinite(win)]
        if win.size < min_obs:
            continue
        out[i] = float(np.mean(win <= cur))
    return out


def rolling_zscore(values: FloatArray, window: int, min_obs: int) -> FloatArray:
    """Z-score of each point against its trailing window (ddof=1)."""
    n = values.shape[0]
    out = np.full(n, np.nan, dtype=np.float64)
    for i in range(n):
        cur = values[i]
        if not np.isfinite(cur):
            continue
        lo = max(0, i - window + 1)
        win = values[lo : i + 1]
        win = win[np.isfinite(win)]
        if win.size < min_obs:
            continue
        mean = float(np.mean(win))
        sd = float(np.std(win, ddof=1))
        # A constant series does not give sd exactly 0 - float error leaves
        # ~1e-17, and dividing the equally-tiny numerator by it yields a
        # spurious ~1 sigma. Guard on scale, or a flat contract lights up the
        # heatmap as if it had moved.
        if not np.isfinite(sd) or sd <= max(abs(mean), 1.0) * 1e-12:
            continue
        out[i] = (cur - mean) / sd
    return out


def wilder_rsi(close: FloatArray, n: int = 14) -> FloatArray:
    """Wilder RSI: simple mean of the first ``n`` gains/losses, then smoothed."""
    diff = np.diff(close, prepend=np.nan)
    gains = np.where(np.isfinite(diff), np.maximum(diff, 0.0), np.nan)
    losses = np.where(np.isfinite(diff), np.maximum(-diff, 0.0), np.nan)

    avg_gain = wilder_smooth(gains, n)
    avg_loss = wilder_smooth(losses, n)

    with np.errstate(divide="ignore", invalid="ignore"):
        rs = np.where(avg_loss > 0, avg_gain / avg_loss, np.inf)
        rsi = 100.0 - 100.0 / (1.0 + rs)
    # All-gain windows give RSI 100; undefined windows stay NaN.
    rsi = np.where(np.isfinite(avg_gain) & np.isfinite(avg_loss), rsi, np.nan)
    return rsi.astype(np.float64)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _col(df: pl.DataFrame, name: str) -> FloatArray:
    if name not in df.columns:
        return np.full(df.height, np.nan, dtype=np.float64)
    return df.get_column(name).cast(pl.Float64).to_numpy().astype(np.float64)


def _pct_change(values: FloatArray, periods: int) -> FloatArray:
    out = np.full(values.shape, np.nan, dtype=np.float64)
    if values.shape[0] <= periods:
        return out
    prev = values[:-periods]
    cur = values[periods:]
    with np.errstate(divide="ignore", invalid="ignore"):
        out[periods:] = np.where(prev != 0, cur / prev - 1.0, np.nan)
    return out


def _rolling_apply(
    values: FloatArray,
    window: int,
    min_obs: int,
    fn: Callable[[FloatArray], Any],
) -> FloatArray:
    n = values.shape[0]
    out = np.full(n, np.nan, dtype=np.float64)
    for i in range(n):
        lo = max(0, i - window + 1)
        win = values[lo : i + 1]
        win = win[np.isfinite(win)]
        if win.size < min_obs:
            continue
        out[i] = float(fn(win))
    return out


def _as_float(value: Any) -> float | None:
    """Narrow a polars aggregate (typed as any python literal) to a float."""
    if value is None or isinstance(value, (str, bytes)):
        return None
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if np.isfinite(out) else None


def _as_int(value: Any) -> int | None:
    out = _as_float(value)
    return None if out is None else int(out)


def _ensure_columns(df: pl.DataFrame) -> pl.DataFrame:
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        msg = f"input frame is missing required columns: {missing}"
        raise ValueError(msg)
    for name in OPTIONAL_COLUMNS:
        if name not in df.columns:
            dtype = pl.Utf8 if name == "gen_ticker" else pl.Float64
            df = df.with_columns(pl.lit(None, dtype=dtype).alias(name))
    return df.sort("date")


# ---------------------------------------------------------------------------
# roll handling
# ---------------------------------------------------------------------------
def roll_mask(gen_ticker: pl.Series) -> FloatArray:
    """1.0 on days where the generic's underlying contract changed, else 0.0.

    The first observation is never a roll (there is nothing to compare it to).
    """
    vals = gen_ticker.to_list()
    out = np.zeros(len(vals), dtype=np.float64)
    prev: str | None = None
    for i, v in enumerate(vals):
        if v is None:
            continue
        if prev is not None and v != prev:
            out[i] = 1.0
        prev = v
    return out


def log_returns(
    close: FloatArray,
    is_roll: FloatArray,
    roll_method: str = "drop",
    open_: FloatArray | None = None,
) -> FloatArray:
    """Log returns with roll days handled.

    ``drop``       - the roll-day return is masked to NaN so the contract gap
                     never enters vol / RSI.
    ``backadjust`` - the roll-day return is replaced by the same-session move
                     (open to close) on the new contract, which removes the
                     gap but keeps the day's risk.
    """
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.log(close / np.roll(close, 1))
    r[0] = np.nan
    r = np.where(np.isfinite(r), r, np.nan)

    roll_days = is_roll > 0
    if not roll_days.any():
        return r

    if roll_method == "backadjust" and open_ is not None:
        with np.errstate(divide="ignore", invalid="ignore"):
            intraday = np.log(close / open_)
        intraday = np.where(np.isfinite(intraday), intraday, np.nan)
        return np.where(roll_days, intraday, r)

    return np.where(roll_days, np.nan, r)


# ---------------------------------------------------------------------------
# main per-product signal computation
# ---------------------------------------------------------------------------
#: EWMA half-lives (days) charted and z-scored: week, fortnight, month, quarter.
DEFAULT_HALF_LIVES: tuple[int, ...] = (5, 10, 21, 63)


def compute_signals(
    df: pl.DataFrame,
    roll_method: str = "drop",
    half_lives: tuple[int, ...] = DEFAULT_HALF_LIVES,
) -> pl.DataFrame:
    """Compute the full single-product signal set.

    Pure: no I/O, no config, no globals. The output always has one row per
    input date and the same column set regardless of whether option data was
    supplied - IV-derived columns are simply null when it was not.
    """
    df = _ensure_columns(df)

    date = df.get_column("date")
    open_ = _col(df, "open")
    high = _col(df, "high")
    low = _col(df, "low")
    close = _col(df, "close")
    volume = _col(df, "volume")
    oi = _col(df, "oi")
    iv = _col(df, "iv_atm_1m")
    iv_c = _col(df, "iv_25c")
    iv_p = _col(df, "iv_25p")

    n = df.height
    is_roll = roll_mask(df.get_column("gen_ticker"))

    # -- returns ------------------------------------------------------------
    r = log_returns(close, is_roll, roll_method=roll_method, open_=open_)

    # -- realized vol -------------------------------------------------------
    rv_10 = _rolling_apply(r, 10, 8, lambda w: np.std(w, ddof=1)) * np.sqrt(TRADING_DAYS)
    rv_20 = _rolling_apply(r, 20, 15, lambda w: np.std(w, ddof=1)) * np.sqrt(TRADING_DAYS)
    rv_60 = _rolling_apply(r, 60, 45, lambda w: np.std(w, ddof=1)) * np.sqrt(TRADING_DAYS)
    ewma_fast = ewma_vol(r, lam=0.94)
    ewma_slow = ewma_vol(r, lam=0.97)

    with np.errstate(divide="ignore", invalid="ignore"):
        rv_ratio_10_60 = np.where(rv_60 > 0, rv_10 / rv_60, np.nan)
        ewma_ratio = np.where(ewma_slow > 0, ewma_fast / ewma_slow, np.nan)

    # -- implied vol (null-safe) -------------------------------------------
    # IV arrives as a decimal fraction (the data layer divides Bloomberg's vol
    # points by 100), so it is directly comparable with realized vol.
    iv_percentile_1y = rolling_rank_pct(iv, TRADING_DAYS, min_obs=60)
    iv_change_5d = _pct_change(iv, 5)
    iv_minus_rv = iv - rv_20
    iv_minus_rv_z = rolling_zscore(iv_minus_rv, TRADING_DAYS, min_obs=60)

    # -- range expansion ----------------------------------------------------
    prev_close = np.roll(close, 1)
    prev_close[0] = np.nan
    # fmax propagates the finite operand when the other is NaN, so the first
    # bar (no previous close) correctly falls back to H-L.
    tr = np.fmax(np.fmax(high - low, np.abs(high - prev_close)), np.abs(low - prev_close))

    atr_5 = wilder_smooth(tr, 5)
    atr_20 = wilder_smooth(tr, 20)
    with np.errstate(divide="ignore", invalid="ignore"):
        atr_ratio_5_20 = np.where(atr_20 > 0, atr_5 / atr_20, np.nan)
        range_pct = np.where(close != 0, (high - low) / close, np.nan)
    range_z_20d = rolling_zscore(range_pct, 20, min_obs=15)

    # -- Bollinger(20, 2 sigma) --------------------------------------------
    # Tolerate the odd missing print: demanding all 20 observations lets a
    # single null close wipe out MA20 (and with it the Bollinger and
    # dist_ma20_atr signals) for a full 20 sessions.
    ma20 = _rolling_apply(close, 20, 18, np.mean)
    sd20 = _rolling_apply(close, 20, 18, lambda w: np.std(w, ddof=1))
    bb_upper = ma20 + 2.0 * sd20
    bb_lower = ma20 - 2.0 * sd20
    with np.errstate(divide="ignore", invalid="ignore"):
        bb_width = np.where(ma20 != 0, (bb_upper - bb_lower) / ma20, np.nan)
    bb_width_pctile = rolling_rank_pct(bb_width, 250, min_obs=60)
    bb_squeeze_release = _squeeze_release(bb_width_pctile, lookback=10)

    # -- momentum / stretch -------------------------------------------------
    rsi_14 = wilder_rsi(close, 14)
    rsi_div = _rsi_divergence(close, rsi_14, window=20)
    with np.errstate(divide="ignore", invalid="ignore"):
        dist_ma20_atr = np.where(atr_20 > 0, (close - ma20) / atr_20, np.nan)

    # -- skew (null-safe) ---------------------------------------------------
    rr_25d = iv_c - iv_p
    skew_z = rolling_zscore(rr_25d, TRADING_DAYS, min_obs=60)

    # -- liquidity ----------------------------------------------------------
    adv_20 = _rolling_apply(volume, 20, 10, np.mean)
    oi_change_5d = _pct_change(oi, 5)

    out = pl.DataFrame(
        {
            "date": date,
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
            "oi": oi,
            "is_roll": is_roll.astype(bool),
            "r": r,
            "rv_10": rv_10,
            "rv_20": rv_20,
            "rv_60": rv_60,
            "ewma_fast": ewma_fast,
            "ewma_slow": ewma_slow,
            "rv_ratio_10_60": rv_ratio_10_60,
            "ewma_ratio": ewma_ratio,
            "iv_atm_1m": iv,
            "iv_25c": iv_c,
            "iv_25p": iv_p,
            "iv_percentile_1y": iv_percentile_1y,
            "iv_change_5d": iv_change_5d,
            "iv_minus_rv": iv_minus_rv,
            "iv_minus_rv_z": iv_minus_rv_z,
            "tr": tr,
            "atr_5": atr_5,
            "atr_20": atr_20,
            "atr_ratio_5_20": atr_ratio_5_20,
            "range_pct": range_pct,
            "range_z_20d": range_z_20d,
            "ma20": ma20,
            "bb_upper": bb_upper,
            "bb_lower": bb_lower,
            "bb_width": bb_width,
            "bb_width_pctile": bb_width_pctile,
            "bb_squeeze_release": bb_squeeze_release.astype(bool),
            "rsi_14": rsi_14,
            "rsi_divergence": rsi_div,
            "dist_ma20_atr": dist_ma20_atr,
            "rr_25d": rr_25d,
            "skew_z": skew_z,
            "adv_20": adv_20,
            "oi_change_5d": oi_change_5d,
        }
    )

    # EWMA vol at each charted half-life, plus the z-score of today's level
    # against its own trailing year - that z-score is what the email heatmap
    # colours, so it lives here rather than in the render layer.
    for h in half_lives:
        series = ewma_vol_half_life(r, h)
        out = out.with_columns(
            pl.Series(f"ewma_hl{h}", series),
            pl.Series(f"ewma_hl{h}_z", rolling_zscore(series, TRADING_DAYS, min_obs=60)),
        )

    return out.with_columns(
        # The kernels work in NaN; the frame speaks null, so "no value" is a
        # single concept downstream (null_count, CSV blanks, Jinja `is none`).
        pl.lit(n).cast(pl.Int64).alias("n_obs"),
        pl.col(pl.Float64).fill_nan(None),
    )


def _squeeze_release(bb_width_pctile: FloatArray, lookback: int = 10) -> FloatArray:
    """1 where width was below the 20th pctile in the last ``lookback`` days
    and is now above the 50th."""
    n = bb_width_pctile.shape[0]
    out = np.zeros(n, dtype=np.float64)
    for i in range(n):
        cur = bb_width_pctile[i]
        if not np.isfinite(cur) or cur <= 0.50:
            continue
        lo = max(0, i - lookback)
        win = bb_width_pctile[lo:i]
        win = win[np.isfinite(win)]
        if win.size and (win < 0.20).any():
            out[i] = 1.0
    return out


def _rsi_divergence(
    close: FloatArray, rsi: FloatArray, window: int = 20, gap: float = 5.0
) -> FloatArray:
    """+1 bearish divergence at 20d highs, -1 bullish at 20d lows, else 0."""
    n = close.shape[0]
    out = np.zeros(n, dtype=np.float64)
    for i in range(n):
        if i + 1 < window:
            continue
        lo = i - window + 1
        c_win = close[lo : i + 1]
        r_win = rsi[lo : i + 1]
        if not np.isfinite(close[i]) or not np.isfinite(rsi[i]):
            continue
        c_fin = c_win[np.isfinite(c_win)]
        r_fin = r_win[np.isfinite(r_win)]
        if c_fin.size < window or r_fin.size < 2:
            continue
        if close[i] >= c_fin.max() and rsi[i] < r_fin.max() - gap:
            out[i] = 1.0
        elif close[i] <= c_fin.min() and rsi[i] > r_fin.min() + gap:
            out[i] = -1.0
    return out


# ---------------------------------------------------------------------------
# intraday range expansion
# ---------------------------------------------------------------------------
def intraday_range_signals(
    bars: pl.DataFrame,
    sessions: int = 20,
    min_sessions: int = 5,
    min_bars: int = 2,
) -> dict[str, float | None]:
    """How unusual today's range is *for this point in the session*.

    The daily range signals only know what happened by the close, which is no
    use to someone deciding at 10:30 whether the day is getting away from
    them. This compares the range traced out so far today against the median
    range traced out by the same time of day over the trailing ``sessions``.

    ``bars`` is the frame from :func:`vol_monitor.bbg.fetch_intraday` with
    ``session`` (local date) and ``tod`` (minutes since local midnight).

    Returns ``range_today``, ``range_typical``, ``range_vs_typical``,
    ``session_progress`` (fraction of the typical session elapsed) and
    ``last_price``. All None when there is not enough history to judge.
    """
    empty: dict[str, float | None] = {
        "range_today": None,
        "range_typical": None,
        "range_vs_typical": None,
        "session_progress": None,
        "last_price": None,
    }
    if bars.is_empty() or "session" not in bars.columns:
        return empty

    bars = bars.sort(["session", "tod"])
    all_sessions = bars.get_column("session").unique().sort().to_list()
    if len(all_sessions) < min_sessions + 1:
        return empty

    today = all_sessions[-1]
    today_bars = bars.filter(pl.col("session") == today)
    if today_bars.height < min_bars:
        return empty

    now_tod = _as_int(today_bars.get_column("tod").max())
    hi_today = _as_float(today_bars.get_column("high").max())
    lo_today = _as_float(today_bars.get_column("low").min())
    if now_tod is None or hi_today is None or lo_today is None:
        return empty
    range_today = hi_today - lo_today

    last_price = today_bars.get_column("close").drop_nulls()
    last = float(last_price[-1]) if not last_price.is_empty() else None

    # Cumulative range by this time of day, one value per prior session.
    prior = [s for s in all_sessions[:-1]][-sessions:]
    partials: list[float] = []
    fulls: list[float] = []
    for s in prior:
        part = bars.filter((pl.col("session") == s) & (pl.col("tod") <= now_tod))
        whole = bars.filter(pl.col("session") == s)
        if part.height < min_bars or whole.is_empty():
            continue
        hi = _as_float(part.get_column("high").max())
        lo = _as_float(part.get_column("low").min())
        w_hi = _as_float(whole.get_column("high").max())
        w_lo = _as_float(whole.get_column("low").min())
        if hi is None or lo is None or w_hi is None or w_lo is None:
            continue
        partials.append(hi - lo)
        fulls.append(w_hi - w_lo)

    if len(partials) < min_sessions:
        return empty

    typical = float(np.median(partials))
    typical_full = float(np.median(fulls))
    if typical <= 0:
        return empty

    return {
        "range_today": range_today,
        "range_typical": typical,
        "range_vs_typical": range_today / typical,
        "session_progress": (typical / typical_full) if typical_full > 0 else None,
        "last_price": last,
    }


#: Parkinson's constant: 1 / (4 ln 2).
_PARKINSON_K = 1.0 / (4.0 * math.log(2.0))


def intraday_vol_series(
    bars: pl.DataFrame, min_bars: int = 4, method: str = "parkinson"
) -> pl.DataFrame:
    """Annualised within-day volatility, one row per session.

    ``parkinson`` (default)
        Range-based: ``sqrt(ln(H/L)^2 / (4 ln2))`` over the session's high and
        low, annualised. Robust to microstructure noise and directly
        comparable with close-to-close EWMA vol.
    ``realized``
        Textbook realized variance: the sum of squared intra-session log
        returns. Left available because it is the standard definition, but on
        these contracts it reads roughly three times the close-to-close vol -
        30-minute bars through thin overnight sessions are dominated by
        bid-ask bounce, and squaring that noise inflates the estimate. Do not
        put it on a chart beside EWMA vol without expecting the mismatch.

    The newest session is usually incomplete. Parkinson handles that
    gracefully (the range simply has not finished widening), and ``partial``
    marks it so the caller can caveat the last point.

    Returns ``session, iv_realized, n_bars, partial``.
    """
    schema = {
        "session": pl.Date,
        "iv_realized": pl.Float64,
        "n_bars": pl.Int64,
        "partial": pl.Boolean,
    }
    if bars.is_empty() or "session" not in bars.columns:
        return pl.DataFrame(schema=schema)

    bars = bars.sort(["session", "tod"])
    groups = list(bars.group_by("session", maintain_order=True))
    counts = [int(g.height) for _, g in groups]
    if not counts:
        return pl.DataFrame(schema=schema)
    full_bars = float(np.median(counts))

    rows: list[dict[str, Any]] = []
    for (session,), part in groups:
        n_bars = int(part.height)
        if n_bars < min_bars:
            continue

        if method == "parkinson":
            hi = _as_float(part.get_column("high").max())
            lo = _as_float(part.get_column("low").min())
            if hi is None or lo is None or lo <= 0 or hi <= lo:
                continue
            daily_var = _PARKINSON_K * math.log(hi / lo) ** 2
        else:
            closes = _col(part, "close")
            closes = closes[np.isfinite(closes) & (closes > 0)]
            if closes.size < min_bars:
                continue
            with np.errstate(divide="ignore", invalid="ignore"):
                rets = np.diff(np.log(closes))
            rets = rets[np.isfinite(rets)]
            if rets.size < min_bars - 1:
                continue
            # Measure per bar and scale to a full session so a half-finished
            # day is not mechanically calm.
            daily_var = float(np.mean(rets**2)) * max(full_bars - 1.0, 1.0)

        rows.append(
            {
                "session": session,
                "iv_realized": float(np.sqrt(daily_var * TRADING_DAYS)),
                "n_bars": n_bars,
                "partial": bool(n_bars < full_bars * 0.9),
            }
        )

    if not rows:
        return pl.DataFrame(schema=schema)
    return pl.DataFrame(rows, schema=schema)


def zscore_of_last(
    values: FloatArray, window: int = TRADING_DAYS, min_obs: int = 30
) -> float | None:
    """Z-score of the final observation against its trailing window."""
    z = rolling_zscore(values, window, min_obs)
    if z.size == 0 or not np.isfinite(z[-1]):
        return None
    return float(z[-1])


# ---------------------------------------------------------------------------
# portfolio-level correlation
# ---------------------------------------------------------------------------
def correlation_signals(
    returns: pl.DataFrame,
    short_window: int = 20,
    long_window: int = 120,
    spike_gap: float = 0.15,
    groups: dict[str, str] | None = None,
    scope: str = "cross_group",
) -> tuple[pl.DataFrame, pl.DataFrame, pl.DataFrame]:
    """Pairwise correlations across products.

    ``returns`` is a wide frame: a ``date`` column plus one return column per
    product. Returns ``(per_product, corr_short, corr_long)`` where the
    correlation frames are square matrices indexed by a ``product`` column.

    ``corr_20d_abs`` is the largest absolute 20d correlation across pairs
    involving that product; ``corr_spike`` fires when that pair's 20d
    correlation exceeds its 120d value by more than ``spike_gap``.

    ``scope`` controls which pairs count toward ``corr_20d_abs``:

    ``cross_group`` (default)
        Only pairs in *different* groups. Two gas legs running at 0.99 is a
        fact of life, not a risk alert - it would pin the signal on every day
        and train the desk to ignore it. Gas moving with power is news.
    ``all``
        Every pair, as originally specified.

    The returned matrices always contain every pair regardless of scope, so
    nothing is hidden from the email - only the *trigger* is scoped.
    """
    products = [c for c in returns.columns if c != "date"]
    k = len(products)

    short_m = np.full((k, k), np.nan, dtype=np.float64)
    long_m = np.full((k, k), np.nan, dtype=np.float64)

    series = {p: _col(returns, p) for p in products}

    for i, a in enumerate(products):
        short_m[i, i] = 1.0
        long_m[i, i] = 1.0
        for j in range(i + 1, k):
            b = products[j]
            short_m[i, j] = short_m[j, i] = _tail_corr(series[a], series[b], short_window)
            long_m[i, j] = long_m[j, i] = _tail_corr(series[a], series[b], long_window)

    groups = groups or {}
    rows = []
    for i, p in enumerate(products):
        best_abs = np.nan
        best_peer: str | None = None
        best_short = np.nan
        best_long = np.nan
        for j in range(k):
            if i == j or not np.isfinite(short_m[i, j]):
                continue
            if (
                scope == "cross_group"
                and groups.get(p) is not None
                and groups.get(p) == groups.get(products[j])
            ):
                continue
            if not np.isfinite(best_abs) or abs(short_m[i, j]) > best_abs:
                best_abs = abs(short_m[i, j])
                best_peer = products[j]
                best_short = short_m[i, j]
                best_long = long_m[i, j]
        spike = bool(
            np.isfinite(best_short)
            and np.isfinite(best_long)
            and best_short > best_long + spike_gap
        )
        rows.append(
            {
                "product": p,
                "corr_20d_abs": None if not np.isfinite(best_abs) else float(best_abs),
                "corr_20d_peer": best_peer,
                "corr_20d_signed": None if not np.isfinite(best_short) else float(best_short),
                "corr_120d_signed": None if not np.isfinite(best_long) else float(best_long),
                "corr_spike": spike,
            }
        )

    per_product = pl.DataFrame(
        rows,
        schema={
            "product": pl.Utf8,
            "corr_20d_abs": pl.Float64,
            "corr_20d_peer": pl.Utf8,
            "corr_20d_signed": pl.Float64,
            "corr_120d_signed": pl.Float64,
            "corr_spike": pl.Boolean,
        },
    )

    def _matrix(m: FloatArray) -> pl.DataFrame:
        data: dict[str, list[Any]] = {"product": list(products)}
        for j, p in enumerate(products):
            data[p] = [None if not np.isfinite(v) else float(v) for v in m[:, j]]
        return pl.DataFrame(data)

    return per_product, _matrix(short_m), _matrix(long_m)


def _tail_corr(a: FloatArray, b: FloatArray, window: int) -> float:
    """Pearson correlation over the last ``window`` *jointly observed* returns.

    Counting overlapping observations rather than calendar rows keeps the
    sample size fixed: roll-masked days and dates one leg does not trade would
    otherwise silently shrink the window and inflate the correlation.
    """
    idx = np.flatnonzero(np.isfinite(a) & np.isfinite(b))
    min_obs = max(int(window * 0.6), 5)
    if idx.size < min_obs:
        return float("nan")
    idx = idx[-window:]
    x, y = a[idx], b[idx]
    if np.std(x) == 0 or np.std(y) == 0:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])
