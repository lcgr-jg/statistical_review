"""Daily Vol-Regime & Position-Sizing Monitor.

A scheduled job that pulls daily OHLCV, open interest and option implied-vol
data from Bloomberg for a configurable list of commodity futures, computes
volatility-regime / range-expansion / momentum / correlation / liquidity
signals, maps them to traffic-light statuses with pre-committed sizing
actions, and emails a one-page HTML summary to the desk before the open.

Entry points:
    ``python -m vol_monitor.cli run --dry-run``
    ``from vol_monitor import run_vol_monitor``
"""

from __future__ import annotations

from typing import Any

__all__ = ["run_vol_monitor"]

__version__ = "0.1.0"


def run_vol_monitor(*args: Any, **kwargs: Any) -> dict[str, Any]:
    """Lazy re-export of :func:`vol_monitor.pipeline.run_vol_monitor`.

    Imported lazily so that ``import vol_monitor`` stays cheap and does not
    drag in blpapi / Snowflake for callers that only want the pure signal
    functions.
    """
    from vol_monitor.pipeline import run_vol_monitor as _run

    return _run(*args, **kwargs)
