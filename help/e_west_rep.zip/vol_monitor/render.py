"""Jinja2 HTML email + CSV attachment.

Outlook-safe by construction: tables for layout, inline styles only, no
flexbox, no external CSS/JS/fonts, images embedded as base64 data URIs.

Colour follows the desk palette:
  status   good #0ca30c / warning #fab219 / critical #d03b3b
  series   blue #2a78d6 for the price line, its light steps for the ATR band
  corr     diverging blue <-> red with a neutral grey midpoint

Red and green are indistinguishable to a deuteranope, so status is never
carried by colour alone: every status cell also shows a distinct glyph
(circle / triangle / square) and the driving value as text.
"""

from __future__ import annotations

import base64
import csv
import datetime as dt
import io
import logging
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import polars as pl
from jinja2 import Environment, FileSystemLoader, select_autoescape

from vol_monitor.config import MonitorConfig
from vol_monitor.regime import GROUPS, SIGNAL_SPECS, ProductRegime

log = logging.getLogger(__name__)

TEMPLATE_DIR = Path(__file__).parent / "templates"

# -- palette ---------------------------------------------------------------
INK = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#898781"
SURFACE = "#fcfcfb"
PLANE = "#f9f9f7"
GRIDLINE = "#e1e0d9"
BASELINE = "#c3c2b7"

STATUS_STYLE: dict[str, dict[str, str]] = {
    "red": {"bg": "#fbeaea", "accent": "#d03b3b", "glyph": "■", "label": "RED"},
    "amber": {"bg": "#fef4e0", "accent": "#fab219", "glyph": "▲", "label": "AMBER"},
    "green": {"bg": "#eff8ef", "accent": "#0ca30c", "glyph": "●", "label": "GREEN"},
    "na": {"bg": "#f4f4f2", "accent": "#898781", "glyph": "–", "label": "n/a"},
}

#: Diverging ramp for the correlation matrix: blue (negative) .. grey .. red.
_CORR_NEG = ["#f0efec", "#dbe9fb", "#c0daf8", "#9ec5f4", "#7db1f0"]
_CORR_POS = ["#f0efec", "#fbe1e1", "#f6c6c6", "#eda5a5", "#e38080"]


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _fmt(value: float | None, spec: str = "{:,.0f}", dash: str = "n/a") -> str:
    if value is None:
        return dash
    try:
        return spec.format(value)
    except (TypeError, ValueError):
        return dash


def corr_cell_color(rho: float | None) -> str:
    if rho is None:
        return "#f4f4f2"
    ramp = _CORR_POS if rho >= 0 else _CORR_NEG
    idx = min(int(abs(rho) * len(ramp)), len(ramp) - 1)
    return ramp[idx]


def status_style(status: str) -> dict[str, str]:
    return STATUS_STYLE.get(status, STATUS_STYLE["na"])


# ---------------------------------------------------------------------------
# sparkline
# ---------------------------------------------------------------------------
#: Ordinal blue ramp for the EWMA half-lives: light = fast, dark = slow.
#: Starts at palette step 250, the lightest step that still clears 2:1 on the
#: light surface, so the fastest line is not washed out.
LAG_RAMP: tuple[str, ...] = ("#86b6ef", "#5598e7", "#2a78d6", "#1c5cab", "#104281")
#: Intraday vol is a different measure, not another point on the lag ramp, so
#: it gets its own hue rather than a fifth blue.
INTRADAY_ORANGE = "#eb6834"
#: 50-delta implied vol. Magenta is the only palette hue that clears CVD
#: separation against both the blue ramp and the orange - violet collides
#: with the dark end of the ramp, green collides with the orange under
#: protanopia. It is also dashed, so identity never rests on colour alone.
IMPLIED_MAGENTA = "#e87ba4"

#: Diverging ramp for the z-score heatmap: blue (calm) .. grey .. red (hot).
_Z_NEG = ("#f0efec", "#dbe9fb", "#c0daf8", "#9ec5f4")
_Z_POS = ("#f0efec", "#fbe1e1", "#f6c6c6", "#eda5a5", "#e38080")


def lag_colors(n: int) -> list[str]:
    """One ramp step per half-life, spread across the available steps."""
    if n <= 1:
        return [LAG_RAMP[2]]
    if n <= len(LAG_RAMP):
        idx = np.linspace(0, len(LAG_RAMP) - 1, n).round().astype(int)
        return [LAG_RAMP[i] for i in idx]
    return [LAG_RAMP[i % len(LAG_RAMP)] for i in range(n)]


def z_cell_color(z: float | None) -> str:
    """Heat colour for a z-score. One sigma per step, capped at the ends."""
    if z is None:
        return "#f4f4f2"
    ramp = _Z_POS if z >= 0 else _Z_NEG
    idx = min(int(abs(z)), len(ramp) - 1)
    return ramp[idx]


def _panel_series(
    frame: pl.DataFrame,
    intraday_vol: pl.DataFrame | None,
    half_lives: tuple[int, ...],
    days: int,
) -> tuple[list[Any], list[dict[str, Any]]] | None:
    """Shared data prep for both chart backends.

    Returns ``(dates, series)`` where each series is
    ``{name, values, color, dash}``, all in annualised vol *points*.
    """
    if frame.is_empty():
        return None
    tail = frame.tail(days)
    cols = [f"ewma_hl{h}" for h in half_lives if f"ewma_hl{h}" in tail.columns]
    if not cols:
        return None

    dates = tail.get_column("date").to_list()
    series: list[dict[str, Any]] = []

    for col, colour, h in zip(cols, lag_colors(len(cols)), half_lives):
        values = np.array(tail.get_column(col).to_list(), dtype=float) * 100.0
        if np.isfinite(values).any():
            series.append(
                {"name": f"{h}d", "values": values, "color": colour, "dash": None}
            )

    if intraday_vol is not None and not intraday_vol.is_empty():
        lookup = {r["session"]: r["iv_realized"] for r in intraday_vol.to_dicts()}
        values = np.array(
            [
                (lookup[d] * 100.0 if lookup.get(d) is not None else np.nan)
                for d in dates
            ],
            dtype=float,
        )
        if np.isfinite(values).any():
            series.append(
                {
                    "name": "within-day",
                    "values": values,
                    "color": INTRADAY_ORANGE,
                    "dash": None,
                }
            )

    if "iv_atm_1m" in tail.columns:
        values = np.array(tail.get_column("iv_atm_1m").to_list(), dtype=float) * 100.0
        if np.isfinite(values).any():
            series.append(
                {
                    "name": "implied 50D",
                    "values": values,
                    "color": IMPLIED_MAGENTA,
                    "dash": "dash",
                }
            )

    return (dates, series) if series else None


def vol_panel_png(
    frame: pl.DataFrame,
    intraday_vol: pl.DataFrame | None,
    half_lives: tuple[int, ...],
    days: int = 90,
    width_px: int = 330,
    height_px: int = 165,
) -> str | None:
    """EWMA vol by half-life, within-day vol and implied vol, one product.

    All series are annualised so they share one axis: you can read fast vol
    pulling away from slow, within-day spiking, and implied sitting over the
    top, without converting anything in your head.

    Rendered with Plotly (crisper line joins and typography at this size than
    matplotlib), falling back to matplotlib if Kaleido cannot produce an
    image - the Docker image pins Kaleido 0.2.1 while dev boxes have 1.x, so
    a static-export failure must degrade the chart, not lose it.

    No legend is drawn inside the panel; six panels would repeat it six
    times. The email carries one shared legend above the grid.
    """
    prepared = _panel_series(frame, intraday_vol, half_lives, days)
    if prepared is None:
        return None
    dates, series = prepared

    try:
        return _vol_panel_plotly(dates, series, width_px, height_px)
    except Exception as exc:  # noqa: BLE001 - never lose the chart to an export bug
        log.warning("plotly export failed (%s); falling back to matplotlib", exc)
        return _vol_panel_matplotlib(dates, series, width_px, height_px)


def _vol_panel_plotly(
    dates: list[Any],
    series: list[dict[str, Any]],
    width_px: int,
    height_px: int,
) -> str:
    import plotly.graph_objs as go
    import plotly.io as pio

    x = list(range(len(dates)))
    fig = go.Figure()
    for s in series:
        fig.add_trace(
            go.Scatter(
                x=x,
                y=[None if not np.isfinite(v) else float(v) for v in s["values"]],
                mode="lines",
                name=s["name"],
                line={
                    "color": s["color"],
                    "width": 1.9 if s["dash"] else 1.7,
                    "dash": s["dash"] or "solid",
                    "shape": "linear",
                },
                connectgaps=False,
            )
        )

    fig.update_layout(
        width=width_px,
        height=height_px,
        showlegend=False,
        paper_bgcolor=SURFACE,
        plot_bgcolor=SURFACE,
        font={"family": "Segoe UI, system-ui, Helvetica, Arial, sans-serif",
              "size": 9, "color": INK_MUTED},
        # Right margin has to clear the final x tick label, or the end date
        # is silently clipped off the plot.
        margin={"l": 34, "r": 26, "t": 6, "b": 18},
        xaxis={
            "showgrid": False,
            "zeroline": False,
            "showline": True,
            "linecolor": BASELINE,
            "linewidth": 1,
            "ticks": "",
            "tickmode": "array",
            "tickvals": [0, len(x) - 1] if x else [],
            "ticktext": [_short_date(dates[0]), _short_date(dates[-1])] if dates else [],
        },
        yaxis={
            "showgrid": True,
            "gridcolor": GRIDLINE,
            "gridwidth": 1,
            "zeroline": False,
            "showline": False,
            "ticks": "",
            "ticksuffix": "%",
            "nticks": 5,
        },
    )
    img = pio.to_image(fig, format="png", width=width_px, height=height_px, scale=2)
    return "data:image/png;base64," + base64.b64encode(img).decode("ascii")


def _vol_panel_matplotlib(
    dates: list[Any],
    series: list[dict[str, Any]],
    width_px: int,
    height_px: int,
) -> str | None:
    """Fallback renderer. Same content, plainer output."""
    if not series:
        return None

    dpi = 100.0
    fig, ax = plt.subplots(
        figsize=(width_px / dpi, height_px / dpi), dpi=dpi * 2, facecolor=SURFACE
    )
    ax.set_facecolor(SURFACE)

    for s in series:
        ax.plot(
            range(len(s["values"])),
            s["values"],
            color=s["color"],
            linewidth=1.6,
            linestyle=(0, (5, 2)) if s["dash"] else "solid",
            zorder=3,
        )

    ax.grid(axis="y", color=GRIDLINE, linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(BASELINE)
    ax.spines["bottom"].set_linewidth(0.8)
    ax.tick_params(axis="y", labelsize=7, colors=INK_MUTED, length=0)
    ax.yaxis.set_major_formatter(lambda v, _pos: f"{v:.0f}%")
    if dates:
        ax.set_xticks([0, len(dates) - 1])
        ax.set_xticklabels(
            [_short_date(dates[0]), _short_date(dates[-1])],
            fontsize=7, color=INK_MUTED,
        )
    ax.tick_params(axis="x", length=0)
    ax.margins(x=0.02)
    fig.tight_layout(pad=0.2)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=SURFACE, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")



def _short_date(value: Any) -> str:
    if isinstance(value, (dt.date, dt.datetime)):
        return value.strftime("%d %b")
    return str(value)


# ---------------------------------------------------------------------------
# CSV attachment
# ---------------------------------------------------------------------------
def build_csv(rows: list[dict[str, Any]]) -> bytes:
    """Every computed column for every product, one row per product."""
    if not rows:
        return b""
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({k: _csv_value(row.get(k)) for k in fieldnames})
    return buf.getvalue().encode("utf-8-sig")


def _csv_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, float):
        return f"{value:.10g}"
    return value


# ---------------------------------------------------------------------------
# subject line
# ---------------------------------------------------------------------------
def build_subject(
    run_date: dt.date,
    n_red: int,
    n_amber: int,
    any_change: bool,
    intraday_at: str | None = None,
) -> str:
    """Lead with the action, because that is what gets read in a preview pane."""
    when = f"{run_date:%Y-%m-%d}" + (f" {intraday_at}" if intraday_at else "")
    if n_red == 0 and n_amber == 0:
        head = "no action"
    else:
        parts = []
        if n_red:
            parts.append(f"CUT {n_red}")
        if n_amber:
            parts.append(f"trim {n_amber}")
        head = " / ".join(parts)
    suffix = " - ESCALATION" if any_change else ""
    return f"Risk Monitor {when} - {head}{suffix}"


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------
def _environment() -> Environment:
    env = Environment(
        loader=FileSystemLoader(str(TEMPLATE_DIR)),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["num"] = _fmt
    return env


def render_email(
    config: MonitorConfig,
    run_date: dt.date,
    generated_at: dt.datetime,
    regimes: list[ProductRegime],
    sizing: dict[str, Any],
    drawdowns: dict[str, Any],
    sparklines: dict[str, str | None],
    corr_short: pl.DataFrame,
    corr_long: pl.DataFrame,
    data_timestamps: dict[str, Any],
    warnings: list[str],
    intraday: dict[str, dict[str, float | None]] | None = None,
    is_intraday_run: bool = False,
    vol_panels: dict[str, str | None] | None = None,
    vol_table: list[dict[str, Any]] | None = None,
    half_lives: tuple[int, ...] = (5, 10, 21, 63),
    template_name: str = "email.html.j2",
) -> str:
    """Render the risk dashboard."""
    env = _environment()
    template = env.get_template(template_name)
    intraday = intraday or {}
    vol_panels = vol_panels or {}
    vol_table = vol_table or []

    #: Shared legend for the vol panels - drawn once in HTML rather than
    #: repeated inside all six PNGs.
    colours = lag_colors(len(half_lives))
    vol_legend: list[dict[str, Any]] = [
        {"label": f"{h}d half-life", "color": c, "dashed": False}
        for h, c in zip(half_lives, colours)
    ]
    vol_legend.append(
        {"label": "within-day", "color": INTRADAY_ORANGE, "dashed": False}
    )
    if any(row.get("has_iv") for row in vol_table):
        vol_legend.append(
            {"label": "implied 50Δ", "color": IMPLIED_MAGENTA, "dashed": True}
        )

    order = {"red": 0, "amber": 1, "green": 2, "na": 3}
    ranked = sorted(regimes, key=lambda r: (order[r.status], r.product))

    changes = [r for r in ranked if r.changed]
    n_red = sum(1 for r in regimes if r.status == "red")
    n_amber = sum(1 for r in regimes if r.status == "amber")
    n_green = sum(1 for r in regimes if r.status == "green")

    # One tile per product: chart, the headline cut, and the firing triggers.
    tiles = []
    for r in ranked:
        sz = sizing.get(r.product)
        idr = intraday.get(r.product, {})
        ratio = idr.get("range_vs_typical")
        cut = getattr(sz, "suggested_cut", None) if sz else None
        tiles.append(
            {
                "product": r.product,
                "regime": r,
                "status": r.status,
                "image": sparklines.get(r.product),
                "cut_pct": cut,
                "cut_text": f"CUT ~{cut:.0%}" if cut and cut >= 0.05 else None,
                "range_ratio": ratio,
                # Gauge is clipped at 2.5x so one wild product cannot squash
                # the rest; 100% of the bar is the amber threshold.
                "range_bar_pct": min(100, int((ratio or 0) / 2.5 * 100)),
                "triggers": r.fired_signals,
                "sizing": sz,
            }
        )
    tile_rows = [tiles[i : i + 3] for i in range(0, len(tiles), 3)]

    products = [c for c in corr_short.columns if c != "product"]
    corr_rows = []
    short_lookup = {r["product"]: r for r in corr_short.to_dicts()}
    long_lookup = {r["product"]: r for r in corr_long.to_dicts()}
    for a in products:
        cells = []
        for b in products:
            rho = short_lookup.get(a, {}).get(b)
            rho_long = long_lookup.get(a, {}).get(b)
            cells.append(
                {
                    "self": a == b,
                    "short": rho,
                    "long": rho_long,
                    # 3dp: at these levels 2dp rounds 0.995 to a misleading 1.00.
                    "text": "-" if a == b else _fmt(rho, "{:+.3f}", "n/a"),
                    "sub": "" if a == b else _fmt(rho_long, "({:+.3f})", ""),
                    "bg": "#f4f4f2" if a == b else corr_cell_color(rho),
                }
            )
        corr_rows.append({"product": a, "cells": cells})

    detail = [r for r in ranked if r.status in ("red", "amber")]
    missing_iv = [r.product for r in regimes if r.missing_iv]

    thresholds = []
    for spec in SIGNAL_SPECS:
        if spec.mode == "bool" or spec.informational:
            continue
        th = config.thresholds.get(spec.name)
        if th is None:
            continue
        thresholds.append(
            {
                "label": spec.label,
                "group": spec.group,
                "amber": _band_text(th.amber),
                "red": _band_text(th.red),
            }
        )

    has_positions = any(
        sizing.get(r.product) is not None
        and getattr(sizing[r.product], "current_lots", None) is not None
        for r in regimes
    )
    has_drawdown = any(
        d is not None and getattr(d, "dd_pct_of_budget", None) is not None
        for d in drawdowns.values()
    )

    return template.render(
        run_date=run_date,
        generated_at=generated_at,
        timezone=config.run.timezone,
        regimes=ranked,
        changes=changes,
        detail=detail,
        groups=GROUPS,
        tiles=tiles,
        tile_rows=tile_rows,
        intraday=intraday,
        is_intraday_run=is_intraday_run,
        vol_panels=vol_panels,
        vol_panel_rows=[
            [t for t in tiles[i : i + 3]] for i in range(0, len(tiles), 3)
        ],
        vol_table=vol_table,
        vol_legend=vol_legend,
        half_lives=half_lives,
        z_cell_color=z_cell_color,
        calls=[t for t in tiles if t["status"] in ("red", "amber")],
        sizing=sizing,
        drawdowns=drawdowns,
        sparklines=sparklines,
        corr_products=products,
        corr_rows=corr_rows,
        thresholds=thresholds,
        warnings=warnings,
        missing_iv=missing_iv,
        data_timestamps=data_timestamps,
        n_red=n_red,
        n_amber=n_amber,
        n_green=n_green,
        n_products=len(regimes),
        target_vol=config.run.target_daily_pnl_vol_usd,
        resize_band=config.run.resize_band,
        actions=config.actions,
        has_positions=has_positions,
        has_drawdown=has_drawdown,
        status_style=status_style,
        fmt=_fmt,
        palette={
            "ink": INK,
            "ink_secondary": INK_SECONDARY,
            "ink_muted": INK_MUTED,
            "surface": SURFACE,
            "plane": PLANE,
            "gridline": GRIDLINE,
            "baseline": BASELINE,
        },
    )


def _band_text(band: float | tuple[float, float]) -> str:
    if isinstance(band, tuple):
        return f"<{band[0]:g} or >{band[1]:g}"
    return f">={band:g}"
