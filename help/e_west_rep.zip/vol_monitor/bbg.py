"""Bloomberg data access (blpapi via B-PIPE) with a local Parquet cache.

The cache is keyed by (ticker, field-set, start, end) so reruns and backfills
do not re-hit Bloomberg. Anything the terminal does not return comes back as
nulls rather than an exception - a product with no option chain must still
produce a complete row.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import polars as pl

from vol_monitor.config import IvFields, MonitorConfig, ProductConfig

log = logging.getLogger(__name__)

#: Daily futures fields pulled for every product.
FUT_FIELDS: tuple[str, ...] = (
    "PX_OPEN",
    "PX_HIGH",
    "PX_LOW",
    "PX_LAST",
    "PX_VOLUME",
    "OPEN_INT",
    "FUT_CUR_GEN_TICKER",
)

_FIELD_TO_COL = {
    "PX_OPEN": "open",
    "PX_HIGH": "high",
    "PX_LOW": "low",
    "PX_LAST": "close",
    "PX_VOLUME": "volume",
    "OPEN_INT": "oi",
    "FUT_CUR_GEN_TICKER": "gen_ticker",
}


@dataclass
class FetchReport:
    """What the data layer managed to get, for the run log and email footer."""

    latency_s: float = 0.0
    warnings: list[str] = field(default_factory=list)
    cache_hits: int = 0
    cache_misses: int = 0
    #: product -> date of the newest genuine implied-vol observation.
    iv_asof: dict[str, str] = field(default_factory=dict)

    def warn(self, msg: str) -> None:
        log.warning(msg)
        self.warnings.append(msg)


class BloombergClient:
    """Thin caching wrapper over ``jain_commods`` ``BBGQuery``."""

    def __init__(
        self,
        cache_dir: str | Path,
        on_server: bool = True,
        use_cache: bool = True,
    ) -> None:
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.on_server = on_server
        self.use_cache = use_cache
        self._session = None
        self.report = FetchReport()

    # -- session --------------------------------------------------------
    @property
    def session(self) -> Any:
        if self._session is None:
            from jain_commods.core.interfaces.bloomberg import BBGQuery

            log.info("opening Bloomberg session (on_server=%s)", self.on_server)
            self._session = BBGQuery(p_on_server=self.on_server)
        return self._session

    # -- cache ----------------------------------------------------------
    def _cache_path(
        self, ticker: str, fields: tuple[str, ...], start: dt.date, end: dt.date
    ) -> Path:
        key = f"{ticker}|{','.join(fields)}|{start:%Y%m%d}|{end:%Y%m%d}"
        digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]
        safe = "".join(c if c.isalnum() else "_" for c in ticker)[:24]
        return self.cache_dir / f"{safe}_{digest}.parquet"

    # -- fetch ----------------------------------------------------------
    def fetch_history(
        self,
        ticker: str,
        fields: tuple[str, ...],
        start: dt.date,
        end: dt.date,
    ) -> pl.DataFrame:
        """Daily history for one ticker. Empty frame (not an error) on failure."""
        path = self._cache_path(ticker, fields, start, end)
        if self.use_cache and path.exists():
            self.report.cache_hits += 1
            log.debug("cache hit %s", path.name)
            return pl.read_parquet(path)

        self.report.cache_misses += 1
        t0 = time.perf_counter()
        try:
            raw = self.session.fetch_hist(
                ticker,
                list(fields),
                p_start=dt.datetime.combine(start, dt.time()),
                p_end=dt.datetime.combine(end, dt.time()),
            )
        except Exception as exc:  # noqa: BLE001 - one bad ticker must not kill the run
            self.report.warn(f"{ticker}: Bloomberg request failed ({exc})")
            return pl.DataFrame()
        finally:
            self.report.latency_s += time.perf_counter() - t0

        df = _from_bbg_frame(raw, ticker, fields)
        if df.is_empty():
            self.report.warn(f"{ticker}: Bloomberg returned no rows for {list(fields)}")
            return df

        if self.use_cache:
            df.write_parquet(path)
        return df

    def fetch_intraday_bars(
        self,
        ticker: str,
        start: dt.datetime,
        end: dt.datetime,
        interval_min: int = 30,
    ) -> pl.DataFrame:
        """Intraday OHLCV bars (Bloomberg IntradayBarRequest), bar times in GMT.

        Cached per (ticker, interval, start, end-hour). The end is rounded up
        to the hour so that repeated runs inside the same hour reuse one
        request instead of issuing a fresh one every few minutes.
        """
        bucket = end.replace(minute=0, second=0, microsecond=0) + dt.timedelta(hours=1)
        key = f"intraday|{ticker}|{interval_min}|{start:%Y%m%d%H}|{bucket:%Y%m%d%H}"
        digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]
        safe = "".join(c if c.isalnum() else "_" for c in ticker)[:24]
        path = self.cache_dir / f"id_{safe}_{digest}.parquet"

        if self.use_cache and path.exists():
            self.report.cache_hits += 1
            return pl.read_parquet(path)

        self.report.cache_misses += 1
        t0 = time.perf_counter()
        try:
            raw = self.session.fetch_intraday_bars(
                ticker, start, end, p_interval_min=interval_min
            )
        except Exception as exc:  # noqa: BLE001 - intraday is an enhancement, not a hard dep
            self.report.warn(f"{ticker}: intraday request failed ({exc})")
            return pl.DataFrame()
        finally:
            self.report.latency_s += time.perf_counter() - t0

        if raw is None or raw.empty:
            self.report.warn(f"{ticker}: no intraday bars returned")
            return pl.DataFrame()

        pdf = raw.copy()
        pdf.index.name = "time"
        pdf = pdf.reset_index()[["time", "open", "high", "low", "close", "volume"]]
        df = pl.from_pandas(pdf).with_columns(
            pl.col("time").cast(pl.Datetime("us")),
            pl.col(["open", "high", "low", "close", "volume"]).cast(pl.Float64),
        )
        if self.use_cache:
            df.write_parquet(path)
        return df

    def fetch_snapshot(self, tickers: list[str], fields: list[str]) -> pl.DataFrame:
        """BDP snapshot - the fallback when a field has no history."""
        try:
            raw = self.session.fetch_live(tickers=tickers, fields=fields)
        except Exception as exc:  # noqa: BLE001
            self.report.warn(f"snapshot failed for {tickers}: {exc}")
            return pl.DataFrame()
        if raw is None or raw.empty:
            return pl.DataFrame()
        out = raw.reset_index().rename(columns={"index": "ticker"})
        return pl.from_pandas(out)


def _from_bbg_frame(raw: Any, ticker: str, fields: tuple[str, ...]) -> pl.DataFrame:
    """Convert ``BBGQuery.fetch_hist`` output (pandas, ``{ticker}_{field}``
    columns, date index) to a tidy polars frame keyed by ``date``."""
    if raw is None or raw.empty:
        return pl.DataFrame()

    pdf = raw.copy()
    pdf.index.name = "date"
    pdf = pdf.reset_index()
    rename = {f"{ticker}_{f}": f for f in fields if f"{ticker}_{f}" in pdf.columns}
    pdf = pdf.rename(columns=rename)
    keep = ["date"] + [f for f in fields if f in pdf.columns]
    pdf = pdf[keep]

    df = pl.from_pandas(pdf)
    return df.with_columns(pl.col("date").cast(pl.Date)).sort("date")


# ---------------------------------------------------------------------------
# product-level assembly
# ---------------------------------------------------------------------------
def _iv_fields(product: ProductConfig) -> IvFields:
    return product.iv_fields or IvFields()


def _max_date(df: pl.DataFrame, col: str) -> dt.date | None:
    if df.is_empty() or col not in df.columns:
        return None
    value = df.get_column(col).max()
    if isinstance(value, dt.datetime):
        return value.date()
    return value if isinstance(value, dt.date) else None


def fetch_product_bars(
    client: BloombergClient,
    product: ProductConfig,
    start: dt.date,
    end: dt.date,
    iv_staleness_days: int = 5,
) -> pl.DataFrame:
    """OHLCV + OI + (optional) implied-vol history for one product.

    Returns the frame :func:`vol_monitor.signals.compute_signals` expects:
    ``date, open, high, low, close, volume, oi, gen_ticker, iv_atm_1m,
    iv_25c, iv_25p``. Option columns are all-null when the product has no
    option ticker, when Bloomberg returns nothing for it, or when the IV
    history is stale relative to the price history.
    """
    fut = client.fetch_history(product.ticker, FUT_FIELDS, start, end)
    if fut.is_empty():
        client.report.warn(f"{product.name}: no futures history for {product.ticker}")
        return pl.DataFrame()

    fut = fut.rename({k: v for k, v in _FIELD_TO_COL.items() if k in fut.columns})
    for col in ("open", "high", "low", "close", "volume", "oi"):
        if col not in fut.columns:
            fut = fut.with_columns(pl.lit(None, dtype=pl.Float64).alias(col))
        else:
            fut = fut.with_columns(pl.col(col).cast(pl.Float64))
    if "gen_ticker" not in fut.columns:
        fut = fut.with_columns(pl.lit(None, dtype=pl.Utf8).alias("gen_ticker"))
    else:
        fut = fut.with_columns(pl.col("gen_ticker").cast(pl.Utf8))

    # Some generics (e.g. German monthly base) only populate PX_LAST. Fall
    # back to close for the missing OHLC so TR degrades to |C - C_prev|
    # instead of vanishing.
    for col in ("open", "high", "low"):
        if fut.get_column(col).null_count() == fut.height:
            client.report.warn(
                f"{product.name}: {product.ticker} has no {col.upper()} history; "
                "falling back to PX_LAST for range signals"
            )
            fut = fut.with_columns(pl.col("close").alias(col))

    empty_iv = [
        pl.lit(None, dtype=pl.Float64).alias(c)
        for c in ("iv_atm_1m", "iv_25c", "iv_25p")
    ]
    if not product.has_options:
        return fut.with_columns(empty_iv)

    ivf = _iv_fields(product)
    iv_field_tuple = (ivf.atm, ivf.call_wing, ivf.put_wing)
    iv = client.fetch_history(product.option_ticker or "", iv_field_tuple, start, end)
    if iv.is_empty():
        client.report.warn(
            f"{product.name}: no implied-vol history on {product.option_ticker}"
        )
        return fut.with_columns(empty_iv)

    iv = iv.rename(
        {ivf.atm: "iv_atm_1m", ivf.call_wing: "iv_25c", ivf.put_wing: "iv_25p"}
    )
    # Bloomberg quotes these in vol points; the rest of the package works in
    # decimals so IV is directly comparable with realized vol.
    iv = iv.with_columns(
        [(pl.col(c).cast(pl.Float64) / 100.0).alias(c) for c in ("iv_atm_1m", "iv_25c", "iv_25p")]
    )

    iv_dated = iv.filter(pl.col("iv_atm_1m").is_not_null())
    last_iv = _max_date(iv_dated, "date")
    last_px = _max_date(fut, "date")
    if last_iv is None:
        client.report.warn(f"{product.name}: implied-vol column is entirely null")
        return fut.with_columns(empty_iv)
    if last_px is not None and (last_px - last_iv).days > iv_staleness_days:
        client.report.warn(
            f"{product.name}: implied vol stale (last {last_iv}, price {last_px}) "
            "- IV signals suppressed"
        )
        return fut.with_columns(empty_iv)

    merged = fut.join(iv, on="date", how="left")

    # Bloomberg publishes the vol surface a day or two behind the price, so
    # the newest bars would otherwise carry a null IV and the whole Implied
    # column would read n/a on every run. Carry the last surface forward, but
    # only as far as the staleness tolerance.
    merged = merged.with_columns(
        [
            pl.col(c).forward_fill(limit=iv_staleness_days)
            for c in ("iv_atm_1m", "iv_25c", "iv_25p")
        ]
    )
    client.report.iv_asof[product.name] = last_iv.isoformat()
    if last_px is not None and last_iv < last_px:
        log.info(
            "%s: implied vol as of %s carried forward to %s",
            product.name,
            last_iv,
            last_px,
        )
    return merged


def fetch_intraday(
    client: BloombergClient,
    product: ProductConfig,
    start: dt.datetime,
    end: dt.datetime,
    interval_min: int = 30,
    timezone: str = "Europe/London",
) -> pl.DataFrame:
    """Intraday OHLCV bars for one product, bucketed into trading sessions.

    Returns ``time, session, tod, open, high, low, close, volume`` where
    ``session`` is the London calendar date the bar belongs to and ``tod`` is
    minutes since midnight in that timezone. Sessions for every product in the
    book fall inside a single London date (TTF 00:40-21:40, Brent 01:00-22:30,
    German power 07:30-16:30), so the calendar date is a clean session key.

    Bloomberg keeps roughly 140 days of intraday history; older windows come
    back empty rather than erroring.
    """
    raw = client.fetch_intraday_bars(product.ticker, start, end, interval_min)
    if raw.is_empty():
        return raw

    return raw.with_columns(
        pl.col("time").dt.replace_time_zone("UTC").dt.convert_time_zone(timezone).alias("local")
    ).with_columns(
        pl.col("local").dt.date().alias("session"),
        (pl.col("local").dt.hour() * 60 + pl.col("local").dt.minute()).alias("tod"),
    )


def fetch_fx(
    client: BloombergClient,
    config: MonitorConfig,
    start: dt.date,
    end: dt.date,
) -> dict[str, float | None]:
    """Latest {currency: rate to multiply by to reach USD}."""
    out: dict[str, float | None] = {"USD": 1.0}
    for ccy, fx in config.fx.items():
        if ccy == "USD" or not fx.ticker:
            out[ccy] = 1.0
            continue
        df = client.fetch_history(fx.ticker, ("PX_LAST",), start, end)
        if df.is_empty() or "PX_LAST" not in df.columns:
            client.report.warn(f"FX {ccy}: no data for {fx.ticker}")
            out[ccy] = None
            continue
        series = df.get_column("PX_LAST").drop_nulls()
        if series.is_empty():
            out[ccy] = None
            continue
        rate = float(series[-1])
        out[ccy] = rate if fx.quoted_per_usd else (1.0 / rate if rate else None)
    return out
