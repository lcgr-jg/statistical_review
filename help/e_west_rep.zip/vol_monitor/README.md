# Vol Monitor

A risk tool that tells traders when to consider cutting. It runs a full
baseline before the open, then re-checks every 30 minutes against live
intraday bars and mails again **only when something gets worse**.

The email is three blocks:

1. **The call** - one line per product that warrants action, with the size of
   the cut and what fired.
2. **A vol heatmap** - every product's realised vol at each EWMA half-life
   plus its within-day vol, each cell coloured by that measure's z-score
   against its own trailing year.
3. **Vol timeseries** - one panel per product with all the EWMA half-lives,
   within-day vol and 50-delta implied vol on one annualised axis.

Five triggers, no more:

| Trigger | Question it answers | Source |
|---|---|---|
| `range_vs_typical` | Is today getting away from us *right now*? | 30-min intraday bars |
| `rv_ratio_10_60` | Is the vol regime shifting under us? | daily |
| `dist_ma20_atr` | How far has price run from its anchor? | daily |
| `corr_20d_abs` | Is the book actually one bet? | daily, cross-group |
| `vol_implied_cut` | How much smaller should we be on vol alone? | sizing |

Everything else the package computes still lands in the CSV for backtesting;
it just does not drive a status or clutter the mail.

## Quick start

```bash
# from the eu_reports root, using the corelib conda env
python -m vol_monitor.cli run --dry-run            # writes HTML+CSV, no send
python -m vol_monitor.cli run                      # baseline, always sends
python -m vol_monitor.cli run --intraday           # re-check, sends only on escalation
python -m vol_monitor.cli run --date 2026-09-18    # re-run a historical day
python -m vol_monitor.cli --plain-logs run --dry-run
python -m vol_monitor.cli backfill --start 2026-01-02 --end 2026-01-31
```

Set `PYTHONIOENCODING=utf-8` first: the console is cp1252 and the email uses
status glyphs, so without it you get a `UnicodeEncodeError` that looks like a
code bug but is not.

## Layout

| Module | Role |
|---|---|
| `config.py` | pydantic models + YAML loader |
| `bbg.py` | B-PIPE access via `jain_commods` `BBGQuery`, daily + intraday, Parquet cache |
| `signals.py` | **pure** - DataFrame in, DataFrame out, no I/O |
| `regime.py` | thresholds to status per trigger, aggregation per product |
| `sizing.py` | vol-target sizing, resize band, the headline cut, drawdown |
| `render.py` | Jinja2 email, Plotly vol charts (matplotlib fallback), CSV attachment |
| `deliver.py` | Kafka relay (default) / Microsoft Graph / SMTP |
| `persist.py` | Snowflake tables + local JSON state mirror |
| `pipeline.py` | orchestration; `run_vol_monitor()` is the entry point |
| `dagster_defs.py` | assets, jobs, baseline + intraday schedules |
| `cli.py` | `run` and `backfill` subcommands |

`signals.py` imports nothing from the rest of the package, so it can be
unit-tested against reference implementations and reused for backfills.

## Configuration

Everything lives in `config/products.yaml` - tickers, Bloomberg field names,
thresholds, sizing targets, recipients, the intraday window. Nothing is
hard-coded in the Python. Any threshold can be overridden per product with a
`thresholds:` block.

### Bloomberg fields (verified on B-PIPE, 2026-09-18)

Futures OHLCV + OI come back on the generic tickers. Implied vol is the fiddly
part and differs by contract:

| Product | Price ticker | Vol ticker | Notes |
|---|---|---|---|
| TTF | `TZT1 Comdty` | `FJSA Comdty` | vol lives on the **option** root, not `TZT1` |
| EUA | `MODEC1 Comdty` | `MZBA Comdty` | `MO1` is thin (~15 lots/day), Dec generic used |
| Brent | `CO1 Comdty` | `CO1 Comdty` | vol surface sits on the futures generic |
| Gasoil | `QS1 Comdty` | `QS1 Comdty` | same |
| German base | `JXY1 Comdty` | - | `DETA` IV last printed 2025-08-12 |
| NBP | `FN1 Comdty` | - | no IV history returned at all |

Two deliberate choices worth knowing:

* **`JXY1` not `DET1` for German power.** `DET1` (monthly) populates only
  `PX_LAST` - no OHLC at all - which would leave every range signal empty.
  `JXY1` (calendar base) carries full OHLCV + OI.
* **Moneyness stands in for delta.** Bloomberg exposes these surfaces by
  moneyness, so `rr_25d` uses the 102.5% / 97.5% points rather than true
  25-delta wings. Both are config keys (`iv_fields`).

Bloomberg publishes the vol surface one to two days behind the price. IV is
forward-filled up to `run.iv_staleness_days` and the true as-of date is shown
in the email footer; beyond that tolerance IV is suppressed.

## Signals

**Intraday range - the reactive one.** `range_vs_typical` is today's range so
far divided by the median range traced out *by the same time of day* over the
trailing 20 sessions. Comparing a 10:30 range against a full-day range would
read ~0.5x every normal morning and never fire; comparing it against the
typical 10:30 range is what makes the tool react mid-session. Sessions are
keyed on the London calendar date, which is clean for every product in the
book (TTF 00:40-21:40, Brent 01:00-22:30, German power 07:30-16:30).

Bloomberg keeps ~140 days of intraday history, so a `--date` older than that
gets `n/a` for this trigger and everything else still works.

**Correlation scope.** `corr_20d_abs` defaults to `cross_group` pairs only
(`run.corr_scope`). TTF and NBP are the same molecule and run ~0.99 correlated
every day; against the 0.92 red they would both be red permanently, which is
noise, not a call to act. Scoped cross-group the signal says something real -
"your gas book is moving with your power book". The matrix in the email always
shows every pair regardless; only the *trigger* is scoped.

**EWMA by half-life.** `run.vol_half_lives` (default 5 / 10 / 21 / 63 days)
drives both the heatmap columns and the chart lines; lambda is derived as
`0.5 ** (1/H)`. Half-lives read more naturally on a legend than lambdas, and
the ladder is what shows fast vol pulling away from slow. Sizing still uses
the RiskMetrics λ = 0.94 series for continuity.

**Within-day vol** is **Parkinson's range estimator** over each session's
30-minute bars: `sqrt(ln(H/L)^2 / (4 ln2))`, annualised. The textbook
sum-of-squared-returns form is available as `method="realized"` but is *not*
the default - on these contracts it reads roughly three times the
close-to-close vol, because 30-minute bars through thin overnight sessions
are dominated by bid-ask bounce and squaring that noise inflates the
estimate. The range estimator is robust to it and lands on the same axis as
the EWMA lines. It sits somewhat below close-to-close vol because it excludes
the overnight gap.

**50-delta implied vol** is the `30DAY_IMPVOL_100.0%MNY_DF` series already
fetched for the IV signals - 100% moneyness *is* the at-the-money, i.e.
50-delta, point. It is drawn dashed magenta so it reads apart from the blue
lag ramp and the orange within-day line for a colour-blind reader too, and
shows `n/a` for NBP and German power, which have no option chain on B-PIPE.

B-PIPE serves these tenors on the option roots: **30DAY, 60DAY, 3MTH, 6MTH,
12MTH**. There is no 50-*day* field; if a longer tenor is wanted, override
`iv_fields.atm` per product (60DAY is the nearest).

**Still computed, still in the CSV, just not in the email:** realized vol
(`rv_10/20/60`, RiskMetrics EWMA at λ = 0.94 / 0.97), implied vol (1y
percentile, 5d change, IV−RV z-score), Wilder ATR 5/20, 20d range z, Bollinger
width percentile and squeeze release, Wilder RSI-14, RSI divergence, 25d risk
reversal z-score, liquidity (% of ADV, 5d OI change).

**Roll handling.** Roll days are detected from `FUT_CUR_GEN_TICKER`. Under
`roll_method: drop` the roll-day return is masked so the contract gap never
reaches vol or RSI; under `backadjust` it is replaced by the same-session
open-to-close move. Range and ATR always use unadjusted H/L/C.

## Sizing and the headline cut

```
sigma_daily     = ewma_fast / sqrt(252)
usd_vol_per_lot = close * multiplier * fx_to_usd * sigma_daily
target_lots     = target_daily_pnl_vol_usd / usd_vol_per_lot
```

The **"CUT ~x%"** on each tile is `suggested_cut`:

* with a position feed, `1 - target_lots / |current_lots|` - cut against what
  is actually on;
* without one, `vol_implied_cut = 1 - sigma_then / sigma_now` - how much
  smaller the position should be than when it was last sized, on vol alone.

The second form is why the tool is useful with no position feed at all. It
reads `n/a` on a product's very first run, because there is no prior sizing
level to have drifted from yet.

`resize_flag` fires when daily vol has drifted more than `resize_band` from
the level at which the position was last sized; the state is then re-baselined.

**Confirm the multipliers before trading off these numbers.** They are set to
exchange contract sizes (TTF 720 MWh/lot, German cal base 8760 MWh/lot, EUA
1000 t, Brent 1000 bbl, Gasoil 100 t, NBP 300) but have not been reconciled
against the desk's own contract table.

## Optional feeds

Current position in lots and MTD P&L / monthly budget come from internal
Snowflake tables via `positions.positions_query` / `positions.pnl_query`. With
`positions.enabled: false` the tiles show target lots and the vol-implied cut
only - a missing feed degrades the report, it never errors it.

## Persistence

`persist.enabled` is **false** by default. Turn it on once `RISK.VOL_MONITOR_*`
exists and `FR_COMMOD_PM_EU` has write access; the tables are created if
missing and `SIGNALS` merges on `(RUN_DATE, PRODUCT)` so re-runs are idempotent.

Either way the job writes `state/vol_monitor_state.json`, which is what
escalation detection and the resize band read. Snowflake failures log a
warning and let the email go out.

## Delivery

`delivery.transport` is `kafka` by default - the in-house `jain_commods` relay
every other eu_reports job uses. `graph` (client-credentials via msal, falls
back to SMTP) and `smtp` are implemented; Graph needs
`delivery.graph_tenant_id`, `graph_client_id` and `$GRAPH_CLIENT_SECRET`, and
`msal` is not currently installed in the corelib env.

## Orchestration

Two schedules, both shipping **STOPPED** - enable them in the Dagster UI.

**Baseline** `vol_monitor_job`: `bbg_daily_bars -> vol_signals ->
regime_status -> vol_monitor_email`, cron `10 7 * * 1-5` Europe/London, 3
retries with 5-minute linear backoff on the Bloomberg asset. Always sends.

**Intraday** `vol_monitor_intraday_job`: `vol_monitor_intraday_check`, cron
`*/30 7-16 * * 1-5`. The asset re-reads `intraday.start_time`/`end_time` from
config and skips outside the window, so tightening the hours needs no cron
edit. Mails only when a product's status has got *worse* since the previous
check (`intraday.send_on_escalation_only`) - a re-check that mails every 30
minutes regardless is one the desk learns to filter away.

`vol_monitor_backfill` recomputes a date range with no email, for threshold
backtesting. Pass `vol_monitor/start` and `vol_monitor/end` run tags, or
`vol_monitor/date` to re-run a single historical day on the baseline job.

A terminal failure sends a plain-text "monitor did not run" alert to
`run.error_recipients`.

## Tests

```bash
python -m pytest vol_monitor/tests -q          # 187 tests
cd vol_monitor && python -m ruff check .
python -m mypy --strict --ignore-missing-imports vol_monitor
```

The intraday range trigger is tested against a synthetic session series: a
normal day reads near 1.0x, tripling the final session's moves clears the red
band, and a half-finished session still reads near 1.0 against the
half-session yardstick - the test that would fail if the time-of-day
comparison ever regressed to a whole-day one.

RSI, ATR, Bollinger and EWMA are checked against hand-written reference
implementations at 1e-6 on a fixed synthetic series. Roll masking is verified
by injecting a 30% contract gap and asserting it does not reach `rv_10`, plus
the mirror assertion that the same gap *does* blow up `rv_10` when unmasked,
so the test cannot pass vacuously. `render.py` has a golden-file snapshot and
an assertion that the HTML references no external resources.

Ruff config is scoped to this package (`vol_monitor/ruff.toml`) so the strict
rule set does not apply to the repo's older packages.

## Charting

The vol panels are rendered with **Plotly**, exported to static PNG through
Kaleido and embedded as base64 - crisper line joins and typography at 330px
than matplotlib, and Plotly + Kaleido are already dependencies used by
`option_morning_brief` and `hormuz_vessel_monitor`.

Two things to know:

* **Kaleido costs about 2.5s per figure**, so six panels add ~15s to a run
  (a warm run goes from ~1s to ~16s). Acceptable for a scheduled job, but it
  is the dominant cost now, not Bloomberg.
* **`pyproject.toml` pins `kaleido==0.2.1`** (it bundles its own Chromium for
  the slim Docker image) while dev machines here have **1.3.0** (which needs
  a system Chrome). `pio.to_image` is stable across both, but because the
  deployed and local versions differ, export failure falls back to the
  matplotlib renderer rather than dropping the chart. There is a test that
  forces the failure path.

TA-Lib is *not* a charting library - it computes indicators. This package
computes its own (RSI, ATR, Bollinger, EWMA) in numpy, verified to 1e-6
against hand-written references, which matches the repo's existing stance of
keeping TA-Lib as an optional `ta-backends` extra for parity testing only.

## Known caveats

* **Multipliers are unverified.** They drive the target-lot and cut numbers.
* **The cut zone uses a stepped daily anchor.** Each session's band comes from
  that day's MA20/ATR20, not today's - a single anchor across five sessions
  would mis-shade every bar but the last and visibly contradict the stretch
  figure printed beside it.
* **`vol_implied_cut` needs one prior run** before it can say anything.
* **Within-day vol excludes the overnight gap** by construction, so it reads
  below close-to-close vol on gap-prone contracts. That is the estimator
  behaving correctly, not a scaling error.
* **The vol charts span 90 sessions**, bounded by Bloomberg's ~140-day
  intraday retention (`intraday.lookback_days`).
