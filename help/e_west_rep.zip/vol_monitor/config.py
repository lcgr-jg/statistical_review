"""Configuration models and YAML loader for the vol monitor.

Everything that a desk would want to tune - tickers, Bloomberg field names,
thresholds, sizing targets, recipients - lives in ``config/products.yaml``.
Nothing in the rest of the package hard-codes a ticker or a threshold.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

DEFAULT_CONFIG_PATH = Path(__file__).parent / "config" / "products.yaml"

RollMethod = Literal["drop", "backadjust"]
Status = Literal["green", "amber", "red", "na"]


class _Base(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class Threshold(_Base):
    """Amber/red cut-offs for one signal.

    Either one-sided (``amber: 1.5``) or two-sided (``amber: [30, 70]``,
    meaning amber outside the band).
    """

    amber: float | tuple[float, float]
    red: float | tuple[float, float]

    @model_validator(mode="after")
    def _consistent_arity(self) -> Threshold:
        if isinstance(self.amber, tuple) != isinstance(self.red, tuple):
            msg = "amber and red must both be scalars or both be [lo, hi] bands"
            raise ValueError(msg)
        for band in (self.amber, self.red):
            if isinstance(band, tuple) and band[0] >= band[1]:
                msg = f"two-sided threshold must be [lo, hi] with lo < hi, got {band}"
                raise ValueError(msg)
        return self

    @property
    def two_sided(self) -> bool:
        return isinstance(self.amber, tuple)


class FxConfig(_Base):
    """Maps a product currency onto the Bloomberg pair used to reach USD."""

    ticker: str
    # True when the quote is CCY/USD (multiply), False when USD/CCY (divide).
    quoted_per_usd: bool = True


class IvFields(_Base):
    """Bloomberg field names for the implied-vol surface.

    Commodity option vol fields vary by contract; these are config keys so a
    new product can be wired up after checking ``FLDS <GO>`` on its option
    ticker without touching code.
    """

    # 100% moneyness is the at-the-money point, i.e. the 50-delta vol.
    # Tenors B-PIPE serves on these roots: 30DAY, 60DAY, 3MTH, 6MTH, 12MTH.
    # There is no 50-day field; use 60DAY if a longer tenor is wanted.
    atm: str = "30DAY_IMPVOL_100.0%MNY_DF"
    # Wing points. Bloomberg exposes moneyness rather than delta for these
    # contracts, so 102.5%/97.5% moneyness stand in for the 25-delta wings.
    call_wing: str = "30DAY_IMPVOL_102.5%MNY_DF"
    put_wing: str = "30DAY_IMPVOL_97.5%MNY_DF"


class ProductConfig(_Base):
    name: str
    ticker: str
    group: str
    multiplier: float = 1.0
    currency: str = "USD"
    option_ticker: str | None = None
    iv_fields: IvFields | None = None
    roll_method: RollMethod | None = None
    target_daily_pnl_vol_usd: float | None = None
    thresholds: dict[str, Threshold] = Field(default_factory=dict)
    label: str | None = None
    note: str | None = None

    @property
    def display(self) -> str:
        return self.label or self.name

    @property
    def has_options(self) -> bool:
        return self.option_ticker is not None


class RunConfig(_Base):
    timezone: str = "Europe/London"
    send_time: str = "07:15"
    lookback_days: int = 550
    recipients: list[str] = Field(default_factory=list)
    error_recipients: list[str] = Field(default_factory=list)
    target_daily_pnl_vol_usd: float = 250_000.0
    resize_band: float = 0.25
    roll_method: RollMethod = "drop"
    corr_scope: Literal["cross_group", "all"] = "cross_group"
    # EWMA speeds charted and z-scored, as half-lives in days.
    vol_half_lives: tuple[int, ...] = (5, 10, 21, 63)
    bloomberg_on_server: bool = True
    # Max business days an IV observation may lag the price before we call it
    # stale and show it as n/a.
    iv_staleness_days: int = 5
    output_dir: str = "output"
    cache_dir: str = "cache"

    @field_validator("recipients", "error_recipients", mode="before")
    @classmethod
    def _split_csv(cls, v: Any) -> Any:
        if isinstance(v, str):
            return [p.strip() for p in v.split(",") if p.strip()]
        return v


class IntradayConfig(_Base):
    """Intraday re-check behaviour."""

    enabled: bool = True
    bar_minutes: int = 30
    profile_sessions: int = 20
    lookback_days: int = 130
    start_time: str = "07:00"
    end_time: str = "17:00"
    check_minutes: int = 30
    send_on_escalation_only: bool = True


class ActionsConfig(_Base):
    amber_count_for_product_amber: int = 2
    product_green: str = "No change"
    product_amber: str = "Cut gross 25%"
    product_red: str = "Cut gross 50%; re-underwrite thesis"
    drawdown_red: str = "Halve size regardless of view"
    drawdown_red_at: float = 0.5


class PersistConfig(_Base):
    enabled: bool = False
    database: str = "RISK"
    schema_: str = Field(default="PUBLIC", alias="schema")
    role: str = "FR_COMMOD_PM_EU"
    warehouse: str = "EU_COMMOD_RESEARCH_XS_WH"
    signals_table: str = "VOL_MONITOR_SIGNALS"
    state_table: str = "VOL_MONITOR_STATE"
    runs_table: str = "VOL_MONITOR_RUNS"
    # Local mirror of STATE/last-status so status-change detection and the
    # resize band still work when Snowflake is unavailable.
    local_state_dir: str = "state"

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)


class DeliveryConfig(_Base):
    # "kafka" is the in-house transport used by every other eu_reports job.
    transport: Literal["kafka", "graph", "smtp"] = "kafka"
    sender: str = "eu.gap.service@jainglobal.com"
    graph_tenant_id: str | None = None
    graph_client_id: str | None = None
    graph_client_secret_env: str = "GRAPH_CLIENT_SECRET"
    smtp_host: str | None = None
    smtp_port: int = 25
    smtp_use_tls: bool = False
    smtp_user: str | None = None
    smtp_password_env: str = "SMTP_PASSWORD"


class PositionsConfig(_Base):
    """Optional internal feeds. Absent feeds degrade the email, never break it."""

    enabled: bool = False
    positions_query: str | None = None
    pnl_query: str | None = None
    database: str = "RISK"
    schema_: str = Field(default="PUBLIC", alias="schema")
    role: str = "FR_COMMOD_PM_EU"

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)


class MonitorConfig(_Base):
    run: RunConfig = Field(default_factory=RunConfig)
    intraday: IntradayConfig = Field(default_factory=IntradayConfig)
    products: list[ProductConfig]
    thresholds: dict[str, Threshold]
    actions: ActionsConfig = Field(default_factory=ActionsConfig)
    fx: dict[str, FxConfig] = Field(default_factory=dict)
    persist: PersistConfig = Field(default_factory=PersistConfig)
    delivery: DeliveryConfig = Field(default_factory=DeliveryConfig)
    positions: PositionsConfig = Field(default_factory=PositionsConfig)

    @field_validator("products")
    @classmethod
    def _unique_names(cls, v: list[ProductConfig]) -> list[ProductConfig]:
        names = [p.name for p in v]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            msg = f"duplicate product names: {sorted(dupes)}"
            raise ValueError(msg)
        if not v:
            msg = "at least one product must be configured"
            raise ValueError(msg)
        return v

    def threshold_for(self, product: str, signal: str) -> Threshold | None:
        """Per-product override wins over the global threshold table."""
        prod = self.product(product)
        if prod is not None and signal in prod.thresholds:
            return prod.thresholds[signal]
        return self.thresholds.get(signal)

    def product(self, name: str) -> ProductConfig | None:
        for p in self.products:
            if p.name == name:
                return p
        return None

    def target_vol_for(self, product: str) -> float:
        prod = self.product(product)
        if prod is not None and prod.target_daily_pnl_vol_usd is not None:
            return prod.target_daily_pnl_vol_usd
        return self.run.target_daily_pnl_vol_usd

    def roll_method_for(self, product: str) -> RollMethod:
        prod = self.product(product)
        if prod is not None and prod.roll_method is not None:
            return prod.roll_method
        return self.run.roll_method


def _coerce_thresholds(raw: dict[str, Any] | None) -> dict[str, Any]:
    """YAML lists become tuples so pydantic picks the two-sided branch."""
    out: dict[str, Any] = {}
    for key, val in (raw or {}).items():
        if isinstance(val, dict):
            out[key] = {
                k: tuple(v) if isinstance(v, list) else v for k, v in val.items()
            }
        else:
            out[key] = val
    return out


def load_config(path: str | Path | None = None) -> MonitorConfig:
    """Load and validate ``products.yaml``."""
    cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not cfg_path.exists():
        msg = f"vol_monitor config not found: {cfg_path}"
        raise FileNotFoundError(msg)

    with cfg_path.open("r", encoding="utf-8") as fh:
        raw: dict[str, Any] = yaml.safe_load(fh) or {}

    raw["thresholds"] = _coerce_thresholds(raw.get("thresholds"))
    for prod in raw.get("products", []):
        if isinstance(prod, dict) and prod.get("thresholds"):
            prod["thresholds"] = _coerce_thresholds(prod["thresholds"])

    return MonitorConfig.model_validate(raw)
