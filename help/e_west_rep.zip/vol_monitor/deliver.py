"""Email delivery.

Three transports behind one ``send`` signature:

``kafka``  the in-house ``jain_commods`` mail relay every other eu_reports
           job uses. Default, because it is what works on the desk today.
``graph``  Microsoft Graph ``POST /users/{sender}/sendMail`` with
           client-credentials auth via msal.
``smtp``   plain SMTP fallback.

``--dry-run`` never reaches this module: the pipeline writes the HTML to disk
and skips the send entirely.
"""

from __future__ import annotations

import base64
import logging
import os
import smtplib
from dataclasses import dataclass
from email.message import EmailMessage

from vol_monitor.config import DeliveryConfig

log = logging.getLogger(__name__)

GRAPH_SCOPE = "https://graph.microsoft.com/.default"
GRAPH_ROOT = "https://graph.microsoft.com/v1.0"


@dataclass(frozen=True)
class Attachment:
    filename: str
    content: bytes
    mime_type: str = "text/csv"

    @property
    def b64(self) -> str:
        return base64.b64encode(self.content).decode("ascii")


class DeliveryError(RuntimeError):
    pass


def send(
    cfg: DeliveryConfig,
    subject: str,
    html: str,
    recipients: list[str],
    attachments: list[Attachment] | None = None,
) -> str:
    """Send the email, returning the transport actually used."""
    if not recipients:
        msg = "no recipients configured"
        raise DeliveryError(msg)
    attachments = attachments or []

    if cfg.transport == "kafka":
        _send_kafka(cfg, subject, html, recipients, attachments)
        return "kafka"
    if cfg.transport == "graph":
        try:
            _send_graph(cfg, subject, html, recipients, attachments)
            return "graph"
        except Exception as exc:  # noqa: BLE001 - documented Graph->SMTP fallback
            log.warning("Graph sendMail failed (%s); falling back to SMTP", exc)
            _send_smtp(cfg, subject, html, recipients, attachments)
            return "smtp (graph fallback)"
    _send_smtp(cfg, subject, html, recipients, attachments)
    return "smtp"


# ---------------------------------------------------------------------------
# transports
# ---------------------------------------------------------------------------
def _send_kafka(
    cfg: DeliveryConfig,
    subject: str,
    html: str,
    recipients: list[str],
    attachments: list[Attachment],
) -> None:
    from jain_commods.core.util.emailhelper import send_email

    # The relay takes at most one attachment per message.
    attachment: dict[str, str] = {}
    if attachments:
        first = attachments[0]
        attachment = {"filename": first.filename, "content": first.b64}
        if len(attachments) > 1:
            log.warning(
                "kafka transport takes one attachment; dropping %d extra",
                len(attachments) - 1,
            )

    send_email(
        recipients=",".join(recipients),
        subject=subject,
        body=html,
        from_address=cfg.sender,
        attachment=attachment,
    )
    log.info("queued email to %s via kafka relay", recipients)


def _send_graph(
    cfg: DeliveryConfig,
    subject: str,
    html: str,
    recipients: list[str],
    attachments: list[Attachment],
) -> None:
    import msal
    import requests

    secret = os.environ.get(cfg.graph_client_secret_env)
    if not (cfg.graph_tenant_id and cfg.graph_client_id and secret):
        msg = (
            "Graph transport needs delivery.graph_tenant_id, "
            f"delivery.graph_client_id and ${cfg.graph_client_secret_env}"
        )
        raise DeliveryError(msg)

    app = msal.ConfidentialClientApplication(
        client_id=cfg.graph_client_id,
        authority=f"https://login.microsoftonline.com/{cfg.graph_tenant_id}",
        client_credential=secret,
    )
    token = app.acquire_token_for_client(scopes=[GRAPH_SCOPE])
    if "access_token" not in token:
        msg = f"Graph token request failed: {token.get('error_description', token)}"
        raise DeliveryError(msg)

    payload = {
        "message": {
            "subject": subject,
            "body": {"contentType": "HTML", "content": html},
            "toRecipients": [{"emailAddress": {"address": r}} for r in recipients],
            "attachments": [
                {
                    "@odata.type": "#microsoft.graph.fileAttachment",
                    "name": a.filename,
                    "contentType": a.mime_type,
                    "contentBytes": a.b64,
                }
                for a in attachments
            ],
        },
        "saveToSentItems": True,
    }
    resp = requests.post(
        f"{GRAPH_ROOT}/users/{cfg.sender}/sendMail",
        headers={
            "Authorization": f"Bearer {token['access_token']}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=60,
    )
    if resp.status_code >= 300:
        msg = f"Graph sendMail returned {resp.status_code}: {resp.text[:500]}"
        raise DeliveryError(msg)
    log.info("sent email to %s via Microsoft Graph", recipients)


def _send_smtp(
    cfg: DeliveryConfig,
    subject: str,
    html: str,
    recipients: list[str],
    attachments: list[Attachment],
) -> None:
    if not cfg.smtp_host:
        msg = "SMTP transport needs delivery.smtp_host"
        raise DeliveryError(msg)

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = cfg.sender
    message["To"] = ", ".join(recipients)
    message.set_content("This report requires an HTML-capable mail client.")
    message.add_alternative(html, subtype="html")
    for a in attachments:
        maintype, _, subtype = a.mime_type.partition("/")
        message.add_attachment(
            a.content, maintype=maintype, subtype=subtype or "octet-stream",
            filename=a.filename,
        )

    with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=60) as server:
        if cfg.smtp_use_tls:
            server.starttls()
        if cfg.smtp_user:
            server.login(cfg.smtp_user, os.environ.get(cfg.smtp_password_env, ""))
        server.send_message(message)
    log.info("sent email to %s via SMTP %s", recipients, cfg.smtp_host)


def send_failure_alert(
    cfg: DeliveryConfig, recipients: list[str], run_date: str, error: str
) -> None:
    """Plain-text 'monitor did not run' alert for terminal job failures."""
    body = (
        f"<pre>Vol Monitor {run_date}: THE MONITOR DID NOT RUN.\n\n"
        f"{error}\n\n"
        "No sizing guidance is available for today. Treat yesterday's "
        "statuses as stale.</pre>"
    )
    try:
        send(cfg, f"Vol Monitor {run_date} - MONITOR DID NOT RUN", body, recipients)
    except Exception as exc:  # noqa: BLE001 - alerting must never raise
        log.error("could not send failure alert: %s", exc)
