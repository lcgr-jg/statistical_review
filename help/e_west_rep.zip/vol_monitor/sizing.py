"""Vol-target position sizing and drawdown scaling.

Pure functions: given a close, an EWMA vol and the contract multiplier, how
many lots hold the desk's daily P&L vol at target, and has vol moved far
enough since the last resize to warrant acting.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from vol_monitor.signals import TRADING_DAYS


@dataclass(frozen=True)
class SizingResult:
    product: str
    sigma_daily: float | None
    usd_vol_per_lot: float | None
    target_lots: float | None
    current_lots: float | None
    implied_pnl_vol_at_current: float | None
    sigma_at_last_resize: float | None
    resize_flag: bool
    target_daily_pnl_vol_usd: float

    @property
    def sigma_drift(self) -> float | None:
        """|sigma_daily / sigma_at_last_resize - 1|, or None if unknown."""
        if (
            self.sigma_daily is None
            or self.sigma_at_last_resize is None
            or self.sigma_at_last_resize <= 0
        ):
            return None
        return abs(self.sigma_daily / self.sigma_at_last_resize - 1.0)

    @property
    def vol_implied_cut(self) -> float | None:
        """Fraction the position should shrink on vol alone since the last resize.

        Target size is inversely proportional to sigma, so if vol has doubled
        the same risk budget buys half the lots: ``1 - sigma_then/sigma_now``.
        This is the headline number a trader can act on *without* a position
        feed - it says how much smaller you should be than when you sized,
        not how big you currently are. Zero when vol has fallen.
        """
        if (
            self.sigma_daily is None
            or self.sigma_at_last_resize is None
            or self.sigma_daily <= 0
            or self.sigma_at_last_resize <= 0
        ):
            return None
        return max(0.0, 1.0 - self.sigma_at_last_resize / self.sigma_daily)

    @property
    def suggested_cut(self) -> float | None:
        """How much to cut: measured against the book if known, else vol-implied."""
        if (
            self.current_lots is not None
            and self.target_lots is not None
            and abs(self.current_lots) > 0
            and abs(self.current_lots) > self.target_lots
        ):
            return 1.0 - self.target_lots / abs(self.current_lots)
        return self.vol_implied_cut


@dataclass(frozen=True)
class DrawdownResult:
    product: str
    mtd_pnl: float | None
    monthly_budget: float | None
    dd_pct_of_budget: float | None
    status: str  # "green" | "red" | "na"
    action: str | None


def _num(x: float | None) -> float | None:
    """Return ``x`` as a finite float, or None."""
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def compute_sizing(
    product: str,
    close: float | None,
    ewma_fast: float | None,
    multiplier: float,
    fx_to_usd: float | None,
    target_daily_pnl_vol_usd: float,
    current_lots: float | None = None,
    sigma_at_last_resize: float | None = None,
    resize_band: float = 0.25,
) -> SizingResult:
    """Vol-target sizing for one product.

        sigma_daily     = ewma_fast / sqrt(252)
        usd_vol_per_lot = close * multiplier * fx_to_usd * sigma_daily
        target_lots     = target_daily_pnl_vol_usd / usd_vol_per_lot

    ``resize_flag`` fires when daily vol has drifted more than ``resize_band``
    away from the level at which the position was last sized. With no prior
    resize level recorded there is nothing to drift from, so it stays False
    and the caller seeds the state with today's sigma.
    """
    px = _num(close)
    vol = _num(ewma_fast)
    fx = _num(fx_to_usd)
    lots = _num(current_lots)
    sigma_prev = _num(sigma_at_last_resize)

    sigma_daily = vol / math.sqrt(TRADING_DAYS) if vol is not None else None

    usd_vol_per_lot: float | None = None
    target_lots: float | None = None
    if px is not None and fx is not None and sigma_daily is not None and sigma_daily > 0:
        usd_vol_per_lot = abs(px) * multiplier * fx * sigma_daily
        if usd_vol_per_lot > 0:
            target_lots = target_daily_pnl_vol_usd / usd_vol_per_lot

    implied: float | None = None
    if usd_vol_per_lot is not None and lots is not None:
        implied = abs(lots) * usd_vol_per_lot

    resize_flag = False
    if sigma_daily is not None and sigma_prev is not None and sigma_prev > 0:
        resize_flag = abs(sigma_daily / sigma_prev - 1.0) > resize_band

    return SizingResult(
        product=product,
        sigma_daily=sigma_daily,
        usd_vol_per_lot=usd_vol_per_lot,
        target_lots=target_lots,
        current_lots=lots,
        implied_pnl_vol_at_current=implied,
        sigma_at_last_resize=sigma_prev,
        resize_flag=resize_flag,
        target_daily_pnl_vol_usd=target_daily_pnl_vol_usd,
    )


def compute_drawdown(
    product: str,
    mtd_pnl: float | None,
    monthly_budget: float | None,
    red_at: float = 0.5,
    red_action: str = "Halve size regardless of view",
) -> DrawdownResult:
    """Month-to-date drawdown as a fraction of the monthly risk budget.

        dd_pct_of_budget = -min(0, mtd_pnl) / monthly_budget
    """
    pnl = _num(mtd_pnl)
    budget = _num(monthly_budget)
    if pnl is None or budget is None or budget <= 0:
        return DrawdownResult(product, None, None, None, "na", None)

    dd = -min(0.0, pnl) / budget
    if dd >= red_at:
        return DrawdownResult(product, pnl, budget, dd, "red", red_action)
    return DrawdownResult(product, pnl, budget, dd, "green", None)
