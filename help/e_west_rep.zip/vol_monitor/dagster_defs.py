"""Dagster assets, jobs and schedules for the vol monitor.

Asset chain: ``bbg_daily_bars -> vol_signals -> regime_status -> vol_monitor_email``.

The pipeline itself is one function, so the assets are thin wrappers that
carve it into observable stages: the first three materialise the computed
state for a date and the last one renders and sends. Splitting the Bloomberg
pull from the send is what lets the retry policy re-attempt B-PIPE failures
without re-emailing the desk.

Import from the repo-root ``dagster_defs.py`` with::

    from vol_monitor.dagster_defs import (
        vol_monitor_assets, vol_monitor_jobs, vol_monitor_schedules,
    )
"""

# NB: no `from __future__ import annotations` here. Dagster inspects the raw
# `context` annotation to validate asset signatures, and PEP 563 stringifies
# it into something it will not accept.

import datetime as dt
from typing import Any

import matplotlib

matplotlib.use("Agg")

from dagster import (
    AssetExecutionContext,
    Backoff,
    DefaultScheduleStatus,
    Definitions,
    MetadataValue,
    RetryPolicy,
    RunRequest,
    ScheduleEvaluationContext,
    asset,
    define_asset_job,
    schedule,
)

TIMEZONE = "Europe/London"
CRON = "10 7 * * 1-5"
#: Mid-session re-check. The asset re-reads the window from config and skips
#: outside it, so tightening the hours does not need a cron change.
INTRADAY_CRON = "*/30 7-16 * * 1-5"

#: Bloomberg wobbles more than anything else here, so retry generously.
BBG_RETRY = RetryPolicy(max_retries=3, delay=300, backoff=Backoff.LINEAR)

_TAGS = {
    "team": "eu_commods",
    "report_type": "daily",
    "priority": "high",
    "delivery": "email",
}


def _now_local(timezone: str) -> dt.datetime:
    from zoneinfo import ZoneInfo

    return dt.datetime.now(ZoneInfo(timezone))


def _parse_hhmm(value: str) -> dt.time:
    hh, _, mm = value.partition(":")
    return dt.time(int(hh), int(mm or 0))


def _run_date(context: AssetExecutionContext) -> dt.date:
    """Honour a ``date`` run-config tag so any historical day can be re-run."""
    raw = context.run.tags.get("vol_monitor/date") if context.run else None
    return dt.date.fromisoformat(raw) if raw else dt.date.today()


# ---------------------------------------------------------------------------
# assets
# ---------------------------------------------------------------------------
@asset(
    group_name="reports_morning",
    description="Vol Monitor - daily OHLCV, open interest and implied vol from Bloomberg",
    compute_kind="bloomberg",
    retry_policy=BBG_RETRY,
    tags=_TAGS,
)
def bbg_daily_bars(context: AssetExecutionContext) -> dict[str, Any]:
    """Pull and cache the raw daily bars for every configured product."""
    import datetime as _dt

    from vol_monitor import bbg
    from vol_monitor.config import load_config
    from vol_monitor.pipeline import PACKAGE_DIR

    config = load_config()
    run_date = _run_date(context)
    start = run_date - _dt.timedelta(days=config.run.lookback_days)

    client = bbg.BloombergClient(
        cache_dir=PACKAGE_DIR / config.run.cache_dir,
        on_server=config.run.bloomberg_on_server,
    )
    fetched: list[str] = []
    for product in config.products:
        bars = bbg.fetch_product_bars(
            client, product, start, run_date, config.run.iv_staleness_days
        )
        if not bars.is_empty():
            fetched.append(product.name)
    bbg.fetch_fx(client, config, start, run_date)

    if not fetched:
        msg = "Bloomberg returned no data for any product"
        raise RuntimeError(msg)

    context.add_output_metadata(
        {
            "run_date": MetadataValue.text(run_date.isoformat()),
            "products": MetadataValue.text(", ".join(fetched)),
            "bloomberg_latency_s": MetadataValue.float(round(client.report.latency_s, 2)),
            "warnings": MetadataValue.int(len(client.report.warnings)),
        }
    )
    return {"run_date": run_date.isoformat(), "products": fetched}


@asset(
    group_name="reports_morning",
    description="Vol Monitor - realized/implied vol, range, momentum and correlation signals",
    compute_kind="python",
    deps=[bbg_daily_bars],
    tags=_TAGS,
)
def vol_signals(context: AssetExecutionContext) -> dict[str, Any]:
    """Compute the signal frames from the cached bars (no Bloomberg round-trip)."""
    import datetime as _dt

    from vol_monitor import bbg
    from vol_monitor.config import load_config
    from vol_monitor.pipeline import PACKAGE_DIR, build_returns_frame, compute_product_frames
    from vol_monitor.signals import correlation_signals

    config = load_config()
    run_date = _run_date(context)
    start = run_date - _dt.timedelta(days=config.run.lookback_days)

    client = bbg.BloombergClient(
        cache_dir=PACKAGE_DIR / config.run.cache_dir,
        on_server=config.run.bloomberg_on_server,
    )
    frames, missing_iv = compute_product_frames(config, client, start, run_date)
    correlation_signals(build_returns_frame(frames))

    context.add_output_metadata(
        {
            "run_date": MetadataValue.text(run_date.isoformat()),
            "n_products": MetadataValue.int(len(frames)),
            "missing_iv": MetadataValue.text(
                ", ".join(p for p, m in missing_iv.items() if m) or "none"
            ),
        }
    )
    return {"run_date": run_date.isoformat(), "products": sorted(frames)}


@asset(
    group_name="reports_morning",
    description="Vol Monitor - traffic-light status and sizing action per product",
    compute_kind="python",
    deps=[vol_signals],
    tags=_TAGS,
)
def regime_status(context: AssetExecutionContext) -> dict[str, Any]:
    """Score signals against thresholds without sending anything."""
    from vol_monitor.pipeline import run_vol_monitor

    run_date = _run_date(context)
    result = run_vol_monitor(run_date=run_date, dry_run=True, send_email=False)

    context.add_output_metadata(
        {
            "run_date": MetadataValue.text(result["run_date"]),
            "n_red": MetadataValue.int(result["n_red"]),
            "n_amber": MetadataValue.int(result["n_amber"]),
            "status_changes": MetadataValue.text(
                ", ".join(result["status_changes"]) or "none"
            ),
            "html_path": MetadataValue.path(result["html_path"]),
        }
    )
    return result


@asset(
    group_name="reports_morning",
    description="Vol Monitor - one-page HTML email with CSV attachment to the desk",
    compute_kind="python",
    deps=[regime_status],
    tags=_TAGS,
    metadata={"output_type": "HTML Email", "data_sources": "Bloomberg B-PIPE"},
)
def vol_monitor_email(context: AssetExecutionContext) -> dict[str, Any]:
    """Render and send. Cached bars mean this does not re-hit Bloomberg."""
    from vol_monitor.pipeline import run_vol_monitor

    run_date = _run_date(context)
    result = run_vol_monitor(run_date=run_date)

    context.log.info(
        "Vol Monitor %s: %d red, %d amber, changes: %s",
        result["run_date"],
        result["n_red"],
        result["n_amber"],
        result["status_changes"] or "none",
    )
    context.add_output_metadata(
        {
            "run_date": MetadataValue.text(result["run_date"]),
            "subject": MetadataValue.text(result["subject"]),
            "n_red": MetadataValue.int(result["n_red"]),
            "n_amber": MetadataValue.int(result["n_amber"]),
            "email_sent": MetadataValue.bool(result["email_sent"]),
            "transport": MetadataValue.text(result["transport"] or "none"),
            "recipients": MetadataValue.text(", ".join(result["recipients"])),
            "elapsed_s": MetadataValue.float(result["elapsed_s"]),
            "html_path": MetadataValue.path(result["html_path"]),
            "csv_path": MetadataValue.path(result["csv_path"]),
        }
    )
    return result


@asset(
    group_name="alerts",
    description="Vol Monitor - mid-session risk re-check, emails only on escalation",
    compute_kind="python",
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={"team": "eu_commods", "report_type": "alert", "delivery": "email"},
)
def vol_monitor_intraday_check(context: AssetExecutionContext) -> dict[str, Any]:
    """Re-run the triggers against fresh intraday bars.

    Skips outside the configured window and on weekends, and only mails when
    a product's status has got worse since the previous check - a re-check
    that mails every 30 minutes regardless is one the desk filters away.
    """
    from vol_monitor.config import load_config
    from vol_monitor.pipeline import run_vol_monitor

    config = load_config()
    now = _now_local(config.run.timezone)
    start = _parse_hhmm(config.intraday.start_time)
    end = _parse_hhmm(config.intraday.end_time)

    if now.weekday() >= 5 or not (start <= now.time() < end):
        context.log.info("outside the intraday window (%s) - skipping", now.strftime("%a %H:%M"))
        return {"skipped": True, "reason": "outside window", "email_sent": False}

    result = run_vol_monitor(run_date=now.date(), intraday_run=True)
    context.log.info(
        "intraday check %s: %d red, %d amber, escalated: %s, sent: %s",
        result["run_date"],
        result["n_red"],
        result["n_amber"],
        ", ".join(result["escalated"]) or "none",
        result["email_sent"],
    )
    context.add_output_metadata(
        {
            "checked_at": MetadataValue.text(now.strftime("%Y-%m-%d %H:%M %Z")),
            "n_red": MetadataValue.int(result["n_red"]),
            "n_amber": MetadataValue.int(result["n_amber"]),
            "escalated": MetadataValue.text(", ".join(result["escalated"]) or "none"),
            "email_sent": MetadataValue.bool(result["email_sent"]),
        }
    )
    return result


@asset(
    group_name="reports_backfill",
    description="Vol Monitor - recompute signals and statuses over a date range, no email",
    compute_kind="python",
    tags={"team": "eu_commods", "report_type": "backfill"},
)
def vol_monitor_backfill(context: AssetExecutionContext) -> dict[str, Any]:
    """Backtest threshold choices. Range comes from run tags, defaulting to 90d."""
    from vol_monitor.pipeline import backfill

    tags = context.run.tags if context.run else {}
    end = dt.date.fromisoformat(
        tags.get("vol_monitor/end", dt.date.today().isoformat())
    )
    start = dt.date.fromisoformat(
        tags.get("vol_monitor/start", (end - dt.timedelta(days=90)).isoformat())
    )

    result = backfill(start, end)
    context.add_output_metadata(
        {
            "start": MetadataValue.text(start.isoformat()),
            "end": MetadataValue.text(end.isoformat()),
            "n_days": MetadataValue.int(result["n_days"]),
        }
    )
    return result


# ---------------------------------------------------------------------------
# jobs & schedules
# ---------------------------------------------------------------------------
vol_monitor_job = define_asset_job(
    name="vol_monitor_job",
    selection=[bbg_daily_bars, vol_signals, regime_status, vol_monitor_email],
    description="Vol Monitor - runs Mon-Fri at 07:10 UK, emails the desk before the open",
    tags={"team": "eu_commods", "priority": "high", "schedule": "weekday_premarket"},
)

vol_monitor_backfill_job = define_asset_job(
    name="vol_monitor_backfill_job",
    selection=[vol_monitor_backfill],
    description="Vol Monitor - recompute a date range for threshold backtesting (no email)",
    tags={"team": "eu_commods", "priority": "low"},
)


vol_monitor_intraday_job = define_asset_job(
    name="vol_monitor_intraday_job",
    selection=[vol_monitor_intraday_check],
    description="Vol Monitor - mid-session risk re-check, emails only on escalation",
    tags={"team": "eu_commods", "priority": "high", "schedule": "intraday"},
)


@schedule(
    job=vol_monitor_job,
    cron_schedule=CRON,
    execution_timezone=TIMEZONE,
    default_status=DefaultScheduleStatus.STOPPED,
)
def vol_monitor_schedule(context: ScheduleEvaluationContext) -> RunRequest:
    """07:10 UK, Mon-Fri - the pre-open baseline. Always sends."""
    return RunRequest()


@schedule(
    job=vol_monitor_intraday_job,
    cron_schedule=INTRADAY_CRON,
    execution_timezone=TIMEZONE,
    default_status=DefaultScheduleStatus.STOPPED,
)
def vol_monitor_intraday_schedule(context: ScheduleEvaluationContext) -> RunRequest:
    """Every 30 min, 07:00-17:00 UK, Mon-Fri. The asset itself re-checks the
    window against config, so narrowing the hours needs no cron edit."""
    return RunRequest()


vol_monitor_assets = [
    bbg_daily_bars,
    vol_signals,
    regime_status,
    vol_monitor_email,
    vol_monitor_intraday_check,
    vol_monitor_backfill,
]
vol_monitor_jobs = [vol_monitor_job, vol_monitor_intraday_job, vol_monitor_backfill_job]
vol_monitor_schedules = [vol_monitor_schedule, vol_monitor_intraday_schedule]

#: Standalone definitions so `dagster dev -f vol_monitor/dagster_defs.py` works.
defs = Definitions(
    assets=vol_monitor_assets,
    jobs=vol_monitor_jobs,
    schedules=vol_monitor_schedules,
)
