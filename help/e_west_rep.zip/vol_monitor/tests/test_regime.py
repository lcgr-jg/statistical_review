"""Table-driven tests for threshold -> status and product aggregation."""

from __future__ import annotations

import pytest

from vol_monitor.config import ActionsConfig, MonitorConfig, Threshold
from vol_monitor.regime import (
    GROUPS,
    SIGNAL_SPECS,
    aggregate_status,
    classify,
    evaluate_product,
    format_value,
    product_status,
)

ONE_SIDED = Threshold(amber=1.5, red=2.0)
TWO_SIDED = Threshold(amber=(30.0, 70.0), red=(20.0, 80.0))


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (0.0, "green"),
        (1.49, "green"),
        (1.5, "amber"),   # boundary is inclusive
        (1.99, "amber"),
        (2.0, "red"),
        (5.0, "red"),
        (-3.0, "green"),  # one-sided: only the upper tail scores
        (None, "na"),
        (float("nan"), "na"),
    ],
)
def test_one_sided_classification(value: float | None, expected: str) -> None:
    assert classify(value, ONE_SIDED, "high") == expected


@pytest.mark.parametrize(
    ("value", "expected"),
    [(0.0, "green"), (1.6, "amber"), (-1.6, "amber"), (2.5, "red"), (-2.5, "red")],
)
def test_abs_classification_scores_both_tails(value: float, expected: str) -> None:
    assert classify(value, ONE_SIDED, "abs") == expected


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (50.0, "green"),
        (30.1, "green"),
        (30.0, "amber"),
        (29.0, "amber"),
        (20.0, "red"),
        (15.0, "red"),
        (69.9, "green"),
        (70.0, "amber"),
        (79.9, "amber"),
        (80.0, "red"),
        (95.0, "red"),
    ],
)
def test_two_sided_rsi_classification(value: float, expected: str) -> None:
    assert classify(value, TWO_SIDED, "two_sided") == expected


@pytest.mark.parametrize(
    ("value", "expected"), [(0.0, "green"), (1.0, "amber"), (-1.0, "amber")]
)
def test_boolean_signals_are_amber_when_set(value: float, expected: str) -> None:
    assert classify(value, None, "bool") == expected


def test_missing_threshold_is_na() -> None:
    assert classify(1.0, None, "high") == "na"


def test_mismatched_threshold_arity_raises() -> None:
    with pytest.raises(ValueError, match="two-sided"):
        classify(50.0, ONE_SIDED, "two_sided")
    with pytest.raises(ValueError, match="one-sided"):
        classify(1.0, TWO_SIDED, "high")


def test_threshold_model_rejects_mixed_arity() -> None:
    with pytest.raises(ValueError, match="both be scalars"):
        Threshold(amber=1.5, red=(2.0, 3.0))


def test_threshold_model_rejects_inverted_band() -> None:
    with pytest.raises(ValueError, match=r"\[lo, hi\]"):
        Threshold(amber=(70.0, 30.0), red=(80.0, 20.0))


# ---------------------------------------------------------------------------
# aggregation
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("statuses", "expected"),
    [
        ([], "na"),
        (["na", "na"], "na"),
        (["green", "na"], "green"),
        (["green", "amber"], "amber"),
        (["amber", "red", "green"], "red"),
    ],
)
def test_aggregate_status(statuses: list[str], expected: str) -> None:
    assert aggregate_status(statuses) == expected  # type: ignore[arg-type]


@pytest.mark.parametrize(
    ("red", "amber", "expected"),
    [
        (0, 0, "green"),
        (0, 1, "green"),   # one amber is not enough at the default count of 2
        (0, 2, "amber"),
        (0, 5, "amber"),
        (1, 0, "red"),     # a single red wins outright
        (1, 4, "red"),
    ],
)
def test_product_status_counts(red: int, amber: int, expected: str) -> None:
    assert product_status(red, amber, ActionsConfig()) == expected


def test_amber_count_is_configurable() -> None:
    actions = ActionsConfig(amber_count_for_product_amber=3)
    assert product_status(0, 2, actions) == "green"
    assert product_status(0, 3, actions) == "amber"


# ---------------------------------------------------------------------------
# end-to-end product evaluation
# ---------------------------------------------------------------------------
def _all_green() -> dict[str, float | None]:
    """Every one of the five triggers comfortably inside its band."""
    return {
        "range_vs_typical": 1.0,
        "rv_ratio_10_60": 1.0,
        "dist_ma20_atr": 0.3,
        "corr_20d_abs": 0.3,
        "vol_implied_cut": 0.02,
    }


def test_all_green_product(config: MonitorConfig) -> None:
    regime = evaluate_product("AAA", _all_green(), config)
    assert regime.status == "green"
    assert regime.action == config.actions.product_green
    assert regime.fired_signals == []


def test_two_ambers_make_the_product_amber(config: MonitorConfig) -> None:
    values = _all_green()
    values["rv_ratio_10_60"] = 1.6
    values["range_vs_typical"] = 1.7
    regime = evaluate_product("AAA", values, config)
    assert regime.amber_count == 2
    assert regime.status == "amber"
    assert regime.action == config.actions.product_amber


def test_one_red_makes_the_product_red(config: MonitorConfig) -> None:
    values = _all_green()
    values["range_vs_typical"] = 2.4
    regime = evaluate_product("AAA", values, config)
    assert regime.red_count == 1
    assert regime.status == "red"
    assert regime.action == config.actions.product_red


def test_status_change_direction(config: MonitorConfig) -> None:
    values = _all_green()
    values["range_vs_typical"] = 2.4
    worse = evaluate_product("AAA", values, config, prev_status="green")
    assert worse.changed and worse.direction == "up"

    better = evaluate_product("AAA", _all_green(), config, prev_status="red")
    assert better.changed and better.direction == "down"

    same = evaluate_product("AAA", _all_green(), config, prev_status="green")
    assert not same.changed and same.direction == ""


def test_missing_intraday_does_not_crash_and_shows_na(config: MonitorConfig) -> None:
    """A product with no intraday bars still produces a full row."""
    values = _all_green()
    values["range_vs_typical"] = None
    regime = evaluate_product("BBB", values, config)
    rng = {s.name: s for s in regime.by_group("Range")}
    assert all(s.status == "na" for s in rng.values())
    assert all(s.display == "n/a" for s in rng.values())
    assert regime.group_status("Range") == "na"
    assert regime.status == "green"  # na never contributes an amber


def test_all_triggers_missing_is_green_not_a_crash(config: MonitorConfig) -> None:
    regime = evaluate_product("BBB", dict.fromkeys(_all_green(), None), config)
    assert regime.status == "green"
    assert regime.amber_count == 0
    assert all(s.display == "n/a" for s in regime.signals)


def test_per_product_threshold_override(config: MonitorConfig) -> None:
    tightened = config.model_copy(
        update={
            "products": [
                config.products[0].model_copy(
                    update={"thresholds": {"rv_ratio_10_60": Threshold(amber=1.0, red=1.2)}}
                ),
                config.products[1],
            ]
        }
    )
    values = _all_green()
    values["rv_ratio_10_60"] = 1.1
    assert evaluate_product("AAA", values, tightened).red_count == 0
    assert (
        next(
            s.status
            for s in evaluate_product("AAA", values, tightened).signals
            if s.name == "rv_ratio_10_60"
        )
        == "amber"
    )
    # the un-overridden product still uses the global table
    assert (
        next(
            s.status
            for s in evaluate_product("BBB", values, tightened).signals
            if s.name == "rv_ratio_10_60"
        )
        == "green"
    )


def test_the_lean_set_is_exactly_five_triggers(config: MonitorConfig) -> None:
    """The simplification is load-bearing: guard it."""
    assert len(SIGNAL_SPECS) == 5
    regime = evaluate_product("AAA", _all_green(), config)
    assert len(regime.signals) == 5
    assert [s.group for s in regime.signals] == list(GROUPS)
    assert {s.name for s in regime.signals} == {
        "range_vs_typical", "rv_ratio_10_60", "dist_ma20_atr",
        "corr_20d_abs", "vol_implied_cut",
    }


# ---------------------------------------------------------------------------
# display formatting
# ---------------------------------------------------------------------------
def test_format_value() -> None:
    specs = {s.name: s for s in SIGNAL_SPECS}
    assert format_value(specs["rv_ratio_10_60"], None) == "n/a"
    assert format_value(specs["rv_ratio_10_60"], 1.4231) == "1.42x"
    assert format_value(specs["range_vs_typical"], 1.836) == "1.84x"
    assert format_value(specs["vol_implied_cut"], 0.324) == "32%"
    assert format_value(specs["dist_ma20_atr"], -2.24) == "-2.2 ATR"
    # 3dp on correlation: 2dp would round 0.995 to a misleading 1.00
    assert format_value(specs["corr_20d_abs"], 0.9951) == "0.995"
