"""Golden-file snapshot of the HTML plus the no-external-resources guarantee."""

from __future__ import annotations

import datetime as dt
import re
from pathlib import Path

import polars as pl
import pytest

from vol_monitor.config import MonitorConfig
from vol_monitor.regime import evaluate_product
from vol_monitor.render import build_csv, build_subject, corr_cell_color, render_email
from vol_monitor.signals import compute_signals
from vol_monitor.sizing import compute_drawdown, compute_sizing
from vol_monitor.tests.conftest import synthetic_ohlcv

GOLDEN = Path(__file__).parent / "golden" / "email.html"

RUN_DATE = dt.date(2026, 3, 16)
GENERATED_AT = dt.datetime(2026, 3, 16, 7, 10, 0)


def _fixture_values(with_iv: bool) -> dict[str, float | None]:
    frame = compute_signals(synthetic_ohlcv(n=400, seed=7, with_iv=with_iv))
    row = frame.tail(1).to_dicts()[0]
    out: dict[str, float | None] = {}
    for key, value in row.items():
        if key == "date":
            continue
        if isinstance(value, bool):
            out[key] = 1.0 if value else 0.0
        elif isinstance(value, (int, float)):
            out[key] = float(value)
        else:
            out[key] = None
    return out


def _build_html(config: MonitorConfig) -> str:
    values_a = _fixture_values(True)
    values_b = _fixture_values(False)
    # Pin every trigger so the golden file depends only on the template, not
    # on the signal kernels.
    values_a.update({
        "range_vs_typical": 2.15,     # red
        "rv_ratio_10_60": 1.62,       # amber
        "dist_ma20_atr": 2.4,         # amber
        "corr_20d_abs": 0.88,         # amber
        "vol_implied_cut": 0.31,      # amber
    })
    values_b.update({
        "range_vs_typical": None,     # no intraday bars -> n/a
        "rv_ratio_10_60": 0.95,
        "dist_ma20_atr": 0.4,
        "corr_20d_abs": 0.88,
        "vol_implied_cut": 0.03,
    })

    regimes = [
        evaluate_product("AAA", values_a, config, prev_status="green"),
        evaluate_product("BBB", values_b, config, prev_status=None, missing_iv=True),
    ]

    sizing = {
        "AAA": compute_sizing("AAA", 100.0, 0.55, 100.0, 1.15, 250_000.0,
                              sigma_at_last_resize=0.03),
        "BBB": compute_sizing("BBB", 50.0, 0.30, 50.0, 1.0, 250_000.0),
    }
    drawdowns = {
        "AAA": compute_drawdown("AAA", None, None),
        "BBB": compute_drawdown("BBB", None, None),
    }
    corr_short = pl.DataFrame(
        {"product": ["AAA", "BBB"], "AAA": [1.0, 0.88], "BBB": [0.88, 1.0]}
    )
    corr_long = pl.DataFrame(
        {"product": ["AAA", "BBB"], "AAA": [1.0, 0.61], "BBB": [0.61, 1.0]}
    )

    return render_email(
        config=config,
        run_date=RUN_DATE,
        generated_at=GENERATED_AT,
        regimes=regimes,
        sizing=sizing,
        drawdowns=drawdowns,
        sparklines={},
        corr_short=corr_short,
        corr_long=corr_long,
        data_timestamps={"AAA": "2026-03-16", "BBB": "2026-03-16"},
        warnings=["BBB: no intraday bars returned"],
        intraday={
            "AAA": {"range_vs_typical": 2.15, "range_today": 4.3, "range_typical": 2.0},
            "BBB": {},
        },
        vol_panels={"AAA": None, "BBB": None},
        vol_table=[
            {
                "product": "AAA",
                "cells": [
                    {"label": "EWMA 5d", "level": 0.52, "z": 1.8},
                    {"label": "EWMA 10d", "level": 0.48, "z": 1.2},
                    {"label": "EWMA 21d", "level": 0.44, "z": 0.4},
                    {"label": "EWMA 63d", "level": 0.40, "z": -0.3},
                    {"label": "Within-day", "level": 0.31, "z": 0.9},
                    {"label": "Implied 50D", "level": 0.58, "z": 1.4},
                ],
                "has_iv": True,
                "ratio": 1.62,
                "ratio_status": "amber",
            },
            {
                "product": "BBB",
                "cells": [
                    {"label": "EWMA 5d", "level": 0.20, "z": -0.4},
                    {"label": "EWMA 10d", "level": 0.21, "z": -0.2},
                    {"label": "EWMA 21d", "level": 0.22, "z": 0.1},
                    {"label": "EWMA 63d", "level": 0.23, "z": 0.2},
                    {"label": "Within-day", "level": None, "z": None},
                    {"label": "Implied 50D", "level": None, "z": None},
                ],
                "has_iv": False,
                "ratio": 0.95,
                "ratio_status": "green",
            },
        ],
        half_lives=(5, 10, 21, 63),
    )


def test_golden_snapshot(config: MonitorConfig) -> None:
    html = _build_html(config)
    if not GOLDEN.exists():  # pragma: no cover - first run writes the baseline
        GOLDEN.parent.mkdir(parents=True, exist_ok=True)
        GOLDEN.write_text(html, encoding="utf-8")
        pytest.skip(f"wrote golden baseline to {GOLDEN}")
    assert html == GOLDEN.read_text(encoding="utf-8")


def test_render_is_deterministic(config: MonitorConfig) -> None:
    assert _build_html(config) == _build_html(config)


def test_no_external_resources(config: MonitorConfig) -> None:
    """Nothing may reference a remote host, external stylesheet, or script."""
    html = _build_html(config)

    assert "<script" not in html.lower()
    assert "<link" not in html.lower()
    assert "@import" not in html.lower()
    assert "flex" not in html.lower()

    for match in re.findall(r'(?:src|href|url)\s*[=(]\s*["\']?([^"\'\s>)]+)', html, re.I):
        assert not match.lower().startswith(("http://", "https://", "//")), match









def test_missing_intraday_shows_na_not_a_crash(config: MonitorConfig) -> None:
    html = _build_html(config)
    assert "n/a" in html
    assert "BBB" in html


def test_email_leads_with_the_call(config: MonitorConfig) -> None:
    """The action has to be above the analytics, not buried under it."""
    html = _build_html(config)
    assert "CUT ~" in html
    assert html.index("CUT ~") < html.index("Where vol sits now")


def test_heatmap_has_a_column_per_half_life(config: MonitorConfig) -> None:
    html = _build_html(config)
    for h in (5, 10, 21, 63):
        assert f"EWMA {h}d" in html
    assert "Within-day" in html


def test_vol_legend_names_every_series(config: MonitorConfig) -> None:
    """Six lines per panel, so identity must not rest on colour alone."""
    html = _build_html(config)
    for label in ("5d half-life", "10d half-life", "21d half-life",
                  "63d half-life", "within-day", "implied 50"):
        assert label in html


def test_implied_vol_column_is_present_and_na_safe(config: MonitorConfig) -> None:
    """AAA has an option chain, BBB does not - both must render."""
    html = _build_html(config)
    assert "Implied 50D" in html
    assert "58%" in html      # AAA's implied level
    assert "n/a" in html      # BBB's missing one


def test_status_is_not_colour_alone(config: MonitorConfig) -> None:
    """Status carries a glyph, not just a hue, for CVD readers."""
    html = _build_html(config)
    assert "▲" in html or "■" in html or "●" in html


# ---------------------------------------------------------------------------
# subject / CSV
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("n_red", "n_amber", "changed", "expected"),
    [
        (0, 0, False, "Risk Monitor 2026-03-16 - no action"),
        (2, 3, False, "Risk Monitor 2026-03-16 - CUT 2 / trim 3"),
        (0, 3, False, "Risk Monitor 2026-03-16 - trim 3"),
        (1, 0, True, "Risk Monitor 2026-03-16 - CUT 1 - ESCALATION"),
    ],
)
def test_subject_leads_with_the_action(
    n_red: int, n_amber: int, changed: bool, expected: str
) -> None:
    assert build_subject(RUN_DATE, n_red, n_amber, changed) == expected


def test_intraday_subject_carries_the_time() -> None:
    assert build_subject(RUN_DATE, 1, 0, True, intraday_at="14:30") == (
        "Risk Monitor 2026-03-16 14:30 - CUT 1 - ESCALATION"
    )


def test_csv_has_a_row_per_product_and_a_union_of_columns() -> None:
    rows = [
        {"product": "AAA", "rv_10": 0.5, "iv_atm_1m": 0.4},
        {"product": "BBB", "rv_10": 0.3, "oi_change_5d": None},
    ]
    text = build_csv(rows).decode("utf-8-sig")
    lines = text.strip().splitlines()
    assert lines[0] == "product,rv_10,iv_atm_1m,oi_change_5d"
    assert len(lines) == 3
    assert lines[2].endswith(",,")  # missing/None render as empty, not "None"


def test_csv_of_nothing_is_empty() -> None:
    assert build_csv([]) == b""


@pytest.mark.parametrize(
    ("rho", "expect_warm"), [(0.95, True), (0.3, True), (-0.95, False), (None, False)]
)
def test_corr_cell_colour_arm(rho: float | None, expect_warm: bool) -> None:
    colour = corr_cell_color(rho)
    if rho is None:
        assert colour == "#f4f4f2"
        return
    warm = (colour.startswith("#f") and colour not in ("#f0efec",)) or colour.startswith("#e")
    assert warm == expect_warm or abs(rho) < 0.2
