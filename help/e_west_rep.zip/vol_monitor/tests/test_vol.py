"""EWMA by half-life, within-day vol, and the z-score heatmap encoding."""

from __future__ import annotations

import math

import numpy as np
import polars as pl
import pytest

from vol_monitor.render import lag_colors, z_cell_color
from vol_monitor.signals import (
    TRADING_DAYS,
    compute_signals,
    ewma_vol,
    ewma_vol_half_life,
    intraday_vol_series,
    lambda_from_half_life,
    zscore_of_last,
)
from vol_monitor.tests.conftest import synthetic_intraday, synthetic_ohlcv


# ---------------------------------------------------------------------------
# half-life parameterisation
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("half_life", "expected_lambda"),
    [(5, 0.870551), (10, 0.933033), (21, 0.967532), (63, 0.989058)],
)
def test_lambda_from_half_life(half_life: int, expected_lambda: float) -> None:
    assert lambda_from_half_life(half_life) == pytest.approx(expected_lambda, abs=1e-6)


def test_half_life_is_the_inverse_of_the_riskmetrics_lambdas() -> None:
    """lambda 0.94 and 0.97 correspond to ~11d and ~22.8d."""
    assert -math.log(2) / math.log(0.94) == pytest.approx(11.2, abs=0.1)
    assert -math.log(2) / math.log(0.97) == pytest.approx(22.8, abs=0.1)


def test_half_life_must_be_positive() -> None:
    with pytest.raises(ValueError, match="must be positive"):
        lambda_from_half_life(0)


def test_ewma_by_half_life_matches_the_lambda_form() -> None:
    rng = np.random.default_rng(5)
    r = rng.normal(0, 0.02, 400)
    np.testing.assert_allclose(
        ewma_vol_half_life(r, 10), ewma_vol(r, lambda_from_half_life(10)), atol=1e-12
    )


def test_shorter_half_life_reacts_faster_to_a_vol_shock() -> None:
    """The point of charting several: fast must move first."""
    r = np.concatenate([np.full(300, 0.005), np.full(20, 0.05)])
    fast = ewma_vol_half_life(r, 5)[-1]
    slow = ewma_vol_half_life(r, 63)[-1]
    assert fast > slow
    # and monotonically across the ladder
    ladder = [ewma_vol_half_life(r, h)[-1] for h in (5, 10, 21, 63)]
    assert ladder == sorted(ladder, reverse=True)


def test_compute_signals_emits_a_column_per_half_life() -> None:
    frame = compute_signals(synthetic_ohlcv(n=400), half_lives=(5, 21))
    for h in (5, 21):
        assert f"ewma_hl{h}" in frame.columns
        assert f"ewma_hl{h}_z" in frame.columns
        assert frame.get_column(f"ewma_hl{h}").null_count() < frame.height
    assert "ewma_hl63" not in frame.columns


# ---------------------------------------------------------------------------
# within-day vol
# ---------------------------------------------------------------------------
def test_parkinson_is_comparable_to_close_to_close() -> None:
    """The whole point of the estimator choice: it must share an axis.

    A naive sum of squared 30-minute returns reads several times the
    close-to-close vol on these contracts because of bid-ask bounce; the
    range estimator has to land in the same ballpark instead.
    """
    bars = synthetic_intraday(sessions=40, bars_per_session=20)
    park = intraday_vol_series(bars, method="parkinson")
    naive = intraday_vol_series(bars, method="realized")

    p_med = float(np.median(park.get_column("iv_realized").to_numpy()))
    n_med = float(np.median(naive.get_column("iv_realized").to_numpy()))
    assert 0.0 < p_med < 5.0          # a plausible annualised vol, not 15x
    assert n_med > p_med               # the naive form is the inflated one


def test_within_day_vol_rises_with_a_wider_session() -> None:
    calm = intraday_vol_series(synthetic_intraday(last_session_range_mult=1.0))
    wild = intraday_vol_series(synthetic_intraday(last_session_range_mult=4.0))
    assert (
        wild.get_column("iv_realized")[-1] > calm.get_column("iv_realized")[-1] * 2
    )


def test_within_day_vol_matches_the_parkinson_formula() -> None:
    bars = synthetic_intraday(sessions=6, bars_per_session=12)
    out = intraday_vol_series(bars, method="parkinson")
    last_session = bars.get_column("session").max()
    part = bars.filter(pl.col("session") == last_session)
    hi = part.get_column("high").to_numpy().max()
    lo = part.get_column("low").to_numpy().min()
    expected = math.sqrt(
        (math.log(hi / lo) ** 2) / (4 * math.log(2)) * TRADING_DAYS
    )
    assert out.get_column("iv_realized")[-1] == pytest.approx(expected)


def test_partial_session_is_flagged() -> None:
    out = intraday_vol_series(
        synthetic_intraday(bars_per_session=20, last_session_bars=6)
    )
    assert out.get_column("partial")[-1] is True
    assert out.get_column("partial")[0] is False


def test_within_day_vol_of_nothing_is_an_empty_frame() -> None:
    out = intraday_vol_series(pl.DataFrame())
    assert out.is_empty()
    assert out.columns == ["session", "iv_realized", "n_bars", "partial"]


def test_sessions_with_too_few_bars_are_skipped() -> None:
    out = intraday_vol_series(synthetic_intraday(sessions=5, bars_per_session=2))
    assert out.is_empty()


def test_flat_session_does_not_produce_a_zero_log() -> None:
    rows = [
        {"session": __import__("datetime").date(2026, 3, 1), "tod": 480 + b * 30,
         "open": 50.0, "high": 50.0, "low": 50.0, "close": 50.0, "volume": 1.0}
        for b in range(8)
    ]
    out = intraday_vol_series(pl.DataFrame(rows))
    assert out.is_empty()  # hi == lo carries no information


def test_within_day_vol_is_deterministic() -> None:
    bars = synthetic_intraday()
    assert intraday_vol_series(bars).equals(intraday_vol_series(bars))


# ---------------------------------------------------------------------------
# z-scores and the heatmap encoding
# ---------------------------------------------------------------------------
def test_zscore_of_last_flags_an_extreme_reading() -> None:
    rng = np.random.default_rng(9)
    series = np.concatenate([rng.normal(0.3, 0.02, 300), [0.45]])
    z = zscore_of_last(series)
    assert z is not None and z > 3.0


def test_zscore_of_last_is_none_without_enough_history() -> None:
    assert zscore_of_last(np.array([0.3, 0.31])) is None


def test_zscore_of_last_is_none_for_a_flat_series() -> None:
    assert zscore_of_last(np.full(200, 0.3)) is None


@pytest.mark.parametrize(
    ("z", "warm"),
    [(3.5, True), (1.2, True), (0.1, False), (-1.2, False), (-3.5, False)],
)
def test_z_heatmap_arm(z: float, warm: bool) -> None:
    """Hot vol reads warm, calm vol reads cool, near-normal reads neutral."""
    colour = z_cell_color(z)
    if abs(z) < 1:
        assert colour == "#f0efec"  # neutral grey
    elif warm:
        assert colour.startswith("#f") or colour.startswith("#e")
    else:
        assert colour in ("#dbe9fb", "#c0daf8", "#9ec5f4")


def test_z_heatmap_is_na_safe() -> None:
    assert z_cell_color(None) == "#f4f4f2"


def test_z_heatmap_caps_at_the_ramp_ends() -> None:
    assert z_cell_color(9.0) == z_cell_color(4.0)
    assert z_cell_color(-9.0) == z_cell_color(-3.0)


# ---------------------------------------------------------------------------
# implied vol on the panels
# ---------------------------------------------------------------------------
def test_panel_draws_the_implied_line_when_iv_is_present() -> None:
    """A product with an option chain must render differently to one without."""
    from vol_monitor.render import vol_panel_png

    with_iv = compute_signals(synthetic_ohlcv(n=300, seed=7, with_iv=True))
    without = with_iv.with_columns(
        pl.lit(None, dtype=pl.Float64).alias("iv_atm_1m")
    )
    a = vol_panel_png(with_iv, None, (5, 21))
    b = vol_panel_png(without, None, (5, 21))
    assert a is not None and b is not None
    assert a != b


def test_panel_without_any_iv_still_renders() -> None:
    """NBP and German power have no IV at all - the panel must not vanish."""
    from vol_monitor.render import vol_panel_png

    frame = compute_signals(synthetic_ohlcv(n=300, seed=11, with_iv=False))
    assert vol_panel_png(frame, None, (5, 21)) is not None


def test_panel_of_an_empty_frame_is_none() -> None:
    from vol_monitor.render import vol_panel_png

    assert vol_panel_png(pl.DataFrame(), None, (5, 21)) is None


def test_chart_degrades_to_matplotlib_when_plotly_export_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Kaleido needs a browser. Docker pins 0.2.1, dev boxes have 1.x - an
    export failure must cost us the polish, not the chart."""
    from vol_monitor import render

    def boom(*_args: object, **_kwargs: object) -> str:
        msg = "no chrome"
        raise RuntimeError(msg)

    monkeypatch.setattr(render, "_vol_panel_plotly", boom)
    frame = compute_signals(synthetic_ohlcv(n=200, seed=7))
    out = render.vol_panel_png(frame, None, (5, 21))
    assert out is not None
    assert out.startswith("data:image/png;base64,")


def test_both_backends_draw_the_same_series() -> None:
    """The two renderers must not drift apart in *what* they plot."""
    from vol_monitor.render import _panel_series

    frame = compute_signals(synthetic_ohlcv(n=200, seed=7, with_iv=True))
    prepared = _panel_series(frame, None, (5, 10, 21, 63), 90)
    assert prepared is not None
    _dates, series = prepared
    names = [s["name"] for s in series]
    assert names == ["5d", "10d", "21d", "63d", "implied 50D"]
    # the implied line is the only dashed one
    assert [s["name"] for s in series if s["dash"]] == ["implied 50D"]


# ---------------------------------------------------------------------------
# lag ramp
# ---------------------------------------------------------------------------
def test_lag_colors_are_distinct_and_ordered() -> None:
    colours = lag_colors(4)
    assert len(colours) == 4
    assert len(set(colours)) == 4


def test_lag_colors_handles_one_and_many() -> None:
    assert len(lag_colors(1)) == 1
    assert len(lag_colors(7)) == 7
