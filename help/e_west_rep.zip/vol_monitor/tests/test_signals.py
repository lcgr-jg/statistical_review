"""signals.py against hand-computed reference implementations, tol 1e-6."""

from __future__ import annotations

import numpy as np
import numpy.typing as npt
import polars as pl
import pytest

from vol_monitor.signals import (
    TRADING_DAYS,
    compute_signals,
    correlation_signals,
    ewma_vol,
    log_returns,
    roll_mask,
    rolling_rank_pct,
    rolling_zscore,
    wilder_rsi,
    wilder_smooth,
)
from vol_monitor.tests.conftest import synthetic_ohlcv

TOL = 1e-6

Arr = npt.NDArray[np.float64]


# ---------------------------------------------------------------------------
# reference implementations (deliberately naive / loop-based)
# ---------------------------------------------------------------------------
def ref_wilder_smooth(values: Arr, n: int) -> Arr:
    out = np.full(len(values), np.nan)
    out[n - 1] = values[:n].mean()
    for i in range(n, len(values)):
        out[i] = (out[i - 1] * (n - 1) + values[i]) / n
    return out


def ref_rsi(close: Arr, n: int = 14) -> Arr:
    diff = np.diff(close, prepend=np.nan)
    gains = np.where(diff > 0, diff, 0.0)
    losses = np.where(diff < 0, -diff, 0.0)
    gains[0] = np.nan
    losses[0] = np.nan

    avg_g = np.full(len(close), np.nan)
    avg_l = np.full(len(close), np.nan)
    avg_g[n] = gains[1 : n + 1].mean()
    avg_l[n] = losses[1 : n + 1].mean()
    for i in range(n + 1, len(close)):
        avg_g[i] = (avg_g[i - 1] * (n - 1) + gains[i]) / n
        avg_l[i] = (avg_l[i - 1] * (n - 1) + losses[i]) / n
    rs = avg_g / avg_l
    result: Arr = 100.0 - 100.0 / (1.0 + rs)
    return result


def ref_atr(high: Arr, low: Arr, close: Arr, n: int) -> Arr:
    tr = np.full(len(close), np.nan)
    tr[0] = high[0] - low[0]
    for i in range(1, len(close)):
        tr[i] = max(
            high[i] - low[i],
            abs(high[i] - close[i - 1]),
            abs(low[i] - close[i - 1]),
        )
    return ref_wilder_smooth(tr, n)


def ref_bollinger(close: Arr, n: int = 20, k: float = 2.0) -> Arr:
    width = np.full(len(close), np.nan)
    for i in range(n - 1, len(close)):
        win = close[i - n + 1 : i + 1]
        mid = win.mean()
        sd = win.std(ddof=1)
        width[i] = ((mid + k * sd) - (mid - k * sd)) / mid
    return width


def ref_ewma_vol(r: Arr, lam: float) -> Arr:
    warmup = max(round(1.0 / (1.0 - lam)), 2)
    finite = np.flatnonzero(np.isfinite(r))
    out = np.full(len(r), np.nan)
    seed_end = finite[warmup - 1]
    var = float(np.mean(r[finite[:warmup]] ** 2))
    out[seed_end] = var
    for i in range(seed_end + 1, len(r)):
        if np.isfinite(r[i]):
            var = lam * var + (1 - lam) * r[i] ** 2
        out[i] = var
    result: Arr = np.sqrt(out) * np.sqrt(TRADING_DAYS)
    return result


# ---------------------------------------------------------------------------
# kernels
# ---------------------------------------------------------------------------
def test_wilder_smooth_matches_reference() -> None:
    rng = np.random.default_rng(1)
    values = np.abs(rng.normal(2.0, 0.5, 120))
    np.testing.assert_allclose(
        wilder_smooth(values, 14), ref_wilder_smooth(values, 14), rtol=0, atol=TOL
    )


def test_rsi_matches_reference() -> None:
    frame = synthetic_ohlcv(n=200, seed=3)
    close = frame.get_column("close").to_numpy()
    got = wilder_rsi(close, 14)
    want = ref_rsi(close, 14)
    mask = np.isfinite(want)
    np.testing.assert_allclose(got[mask], want[mask], rtol=0, atol=TOL)


def test_rsi_is_bounded_and_extreme_on_monotone_series() -> None:
    rising = np.arange(1.0, 60.0)
    rsi = wilder_rsi(rising, 14)
    finite = rsi[np.isfinite(rsi)]
    assert finite.min() >= 0.0
    assert finite.max() <= 100.0
    assert finite[-1] == pytest.approx(100.0)


def test_atr_matches_reference() -> None:
    frame = synthetic_ohlcv(n=200, seed=5)
    out = compute_signals(frame)
    high = frame.get_column("high").to_numpy()
    low = frame.get_column("low").to_numpy()
    close = frame.get_column("close").to_numpy()
    for n, col in ((5, "atr_5"), (20, "atr_20")):
        want = ref_atr(high, low, close, n)
        got = out.get_column(col).to_numpy()
        mask = np.isfinite(want)
        np.testing.assert_allclose(got[mask], want[mask], rtol=0, atol=TOL)


def test_bollinger_width_matches_reference() -> None:
    frame = synthetic_ohlcv(n=200, seed=11)
    out = compute_signals(frame)
    want = ref_bollinger(frame.get_column("close").to_numpy())
    got = out.get_column("bb_width").to_numpy()
    mask = np.isfinite(want)
    np.testing.assert_allclose(got[mask], want[mask], rtol=0, atol=TOL)


def test_ewma_matches_riskmetrics_recursion() -> None:
    rng = np.random.default_rng(13)
    r = rng.normal(0, 0.02, 300)
    for lam in (0.94, 0.97):
        want = ref_ewma_vol(r, lam)
        got = ewma_vol(r, lam)
        mask = np.isfinite(want)
        np.testing.assert_allclose(got[mask], want[mask], rtol=0, atol=TOL)


def test_rolling_rank_pct_bounds() -> None:
    values = np.arange(100.0)
    pct = rolling_rank_pct(values, window=20, min_obs=5)
    # A strictly rising series is always the max of its own window.
    assert np.nanmax(pct) == pytest.approx(1.0)
    assert np.nanmin(pct[5:]) == pytest.approx(1.0)


def test_rolling_zscore_of_constant_is_null() -> None:
    values = np.full(50, 3.0)
    z = rolling_zscore(values, window=20, min_obs=5)
    assert np.all(np.isnan(z))


# ---------------------------------------------------------------------------
# roll handling
# ---------------------------------------------------------------------------
def test_roll_mask_flags_only_contract_changes() -> None:
    s = pl.Series(["A", "A", "B", "B", "C"])
    np.testing.assert_array_equal(roll_mask(s), np.array([0.0, 0.0, 1.0, 0.0, 1.0]))


def test_roll_gap_is_excluded_from_rv10() -> None:
    """A synthetic 30% roll gap must not reach rv_10."""
    frame = synthetic_ohlcv(n=200, seed=17, with_iv=False)
    close = frame.get_column("close").to_numpy().copy()
    gen = frame.get_column("gen_ticker").to_list()

    roll_idx = 150
    close[roll_idx:] *= 1.30  # contract switch, not a market move
    for i in range(roll_idx, len(gen)):
        gen[i] = "XX1"

    injected = frame.with_columns(
        [pl.Series("close", close), pl.Series("gen_ticker", gen)]
    )

    dropped = compute_signals(injected, roll_method="drop")
    assert dropped.get_column("r")[roll_idx] is None

    # rv_10 across the roll window must stay in line with the surrounding
    # regime rather than spiking on a 26% log gap.
    rv10 = dropped.get_column("rv_10").to_numpy()
    around = rv10[roll_idx : roll_idx + 10]
    baseline = np.nanmedian(rv10[roll_idx - 40 : roll_idx - 5])
    assert np.nanmax(around) < baseline * 2.0

    # Without masking, the same gap blows rv_10 up - proving the test bites.
    naive = compute_signals(
        injected.with_columns(pl.lit("XX0").alias("gen_ticker")), roll_method="drop"
    )
    naive_rv = naive.get_column("rv_10").to_numpy()
    assert np.nanmax(naive_rv[roll_idx : roll_idx + 10]) > baseline * 3.0


def test_backadjust_keeps_the_day_but_removes_the_gap() -> None:
    frame = synthetic_ohlcv(n=120, seed=19, with_iv=False)
    close = frame.get_column("close").to_numpy().copy()
    open_ = frame.get_column("open").to_numpy().copy()
    gen = frame.get_column("gen_ticker").to_list()

    roll_idx = 80
    close[roll_idx:] *= 1.30
    open_[roll_idx:] *= 1.30
    for i in range(roll_idx, len(gen)):
        gen[i] = "XX1"

    injected = frame.with_columns(
        [pl.Series("close", close), pl.Series("open", open_), pl.Series("gen_ticker", gen)]
    )
    out = compute_signals(injected, roll_method="backadjust")
    r = out.get_column("r")[roll_idx]
    assert r is not None
    assert abs(r) < 0.1  # the 26% log gap is gone, the session move remains


def test_first_bar_is_never_a_roll() -> None:
    assert roll_mask(pl.Series(["A", "B"]))[0] == 0.0


# ---------------------------------------------------------------------------
# null safety
# ---------------------------------------------------------------------------
def test_no_iv_produces_full_frame_with_null_iv_columns(ohlcv_no_iv: pl.DataFrame) -> None:
    out = compute_signals(ohlcv_no_iv)
    assert out.height == ohlcv_no_iv.height
    for col in ("iv_atm_1m", "iv_percentile_1y", "iv_change_5d", "iv_minus_rv_z", "skew_z"):
        assert out.get_column(col).null_count() == out.height, col
    # price-side signals still compute
    assert out.get_column("rv_10").null_count() < out.height
    assert out.get_column("atr_20").null_count() < out.height


def test_missing_required_column_raises() -> None:
    with pytest.raises(ValueError, match="missing required columns"):
        compute_signals(pl.DataFrame({"date": [1], "close": [1.0]}))


def test_output_schema_is_stable_with_and_without_iv() -> None:
    with_iv = compute_signals(synthetic_ohlcv(n=120, with_iv=True))
    without = compute_signals(synthetic_ohlcv(n=120, with_iv=False))
    assert with_iv.columns == without.columns


# ---------------------------------------------------------------------------
# determinism
# ---------------------------------------------------------------------------
def test_same_input_gives_identical_output(ohlcv: pl.DataFrame) -> None:
    assert compute_signals(ohlcv).equals(compute_signals(ohlcv))


# ---------------------------------------------------------------------------
# derived ratios
# ---------------------------------------------------------------------------
def test_ratios_are_consistent_with_their_components(ohlcv: pl.DataFrame) -> None:
    out = compute_signals(ohlcv).tail(1).to_dicts()[0]
    assert out["rv_ratio_10_60"] == pytest.approx(out["rv_10"] / out["rv_60"], abs=TOL)
    assert out["atr_ratio_5_20"] == pytest.approx(out["atr_5"] / out["atr_20"], abs=TOL)
    assert out["ewma_ratio"] == pytest.approx(out["ewma_fast"] / out["ewma_slow"], abs=TOL)
    assert out["rr_25d"] == pytest.approx(out["iv_25c"] - out["iv_25p"], abs=TOL)


def test_log_returns_mask_roll_days() -> None:
    close = np.array([100.0, 101.0, 130.0, 131.0])
    is_roll = np.array([0.0, 0.0, 1.0, 0.0])
    r = log_returns(close, is_roll, "drop")
    assert np.isnan(r[0])
    assert r[1] == pytest.approx(np.log(101 / 100))
    assert np.isnan(r[2])
    assert r[3] == pytest.approx(np.log(131 / 130))


# ---------------------------------------------------------------------------
# correlation
# ---------------------------------------------------------------------------
def test_correlation_identifies_the_strongest_peer() -> None:
    rng = np.random.default_rng(23)
    n = 200
    a = rng.normal(0, 0.02, n)
    b = a * 0.98 + rng.normal(0, 0.001, n)  # near-identical to A
    c = rng.normal(0, 0.02, n)              # independent

    frame = pl.DataFrame(
        {"date": list(range(n)), "AAA": a, "BBB": b, "CCC": c}
    )
    per_product, short, long = correlation_signals(frame)
    rows = {r["product"]: r for r in per_product.to_dicts()}

    assert rows["AAA"]["corr_20d_peer"] == "BBB"
    assert rows["AAA"]["corr_20d_abs"] > 0.9
    assert rows["CCC"]["corr_20d_abs"] < 0.8
    assert short.shape == (3, 4)
    assert long.shape == (3, 4)


def test_cross_group_scope_ignores_the_same_group_twin() -> None:
    """Two gas legs at 0.99 must not pin the trigger; gas-vs-power must show.

    Without this, the correlation trigger is on every day for any book with
    two contracts on the same underlying, which is noise rather than a call
    to cut.
    """
    rng = np.random.default_rng(37)
    n = 200
    ttf = rng.normal(0, 0.02, n)
    nbp = ttf * 0.99 + rng.normal(0, 0.0008, n)   # same group, near-identical
    power = ttf * 0.60 + rng.normal(0, 0.016, n)  # different group, moderate

    frame = pl.DataFrame(
        {"date": list(range(n)), "TTF": ttf, "NBP": nbp, "DE_BASE": power}
    )
    groups = {"TTF": "gas", "NBP": "gas", "DE_BASE": "power"}

    scoped, short, _ = correlation_signals(frame, groups=groups, scope="cross_group")
    rows = {r["product"]: r for r in scoped.to_dicts()}
    assert rows["TTF"]["corr_20d_peer"] == "DE_BASE"
    assert rows["TTF"]["corr_20d_abs"] < 0.95

    # ...but the matrix still reports the gas pair in full.
    matrix = {r["product"]: r for r in short.to_dicts()}
    assert matrix["TTF"]["NBP"] > 0.95

    # scope="all" restores the original behaviour
    every, _, _ = correlation_signals(frame, groups=groups, scope="all")
    assert {r["product"]: r for r in every.to_dicts()}["TTF"]["corr_20d_peer"] == "NBP"


def test_scope_without_groups_falls_back_to_all_pairs() -> None:
    rng = np.random.default_rng(41)
    n = 150
    a = rng.normal(0, 0.02, n)
    frame = pl.DataFrame({"date": list(range(n)), "AAA": a, "BBB": a * 0.99})
    out, _, _ = correlation_signals(frame, scope="cross_group")
    assert {r["product"]: r for r in out.to_dicts()}["AAA"]["corr_20d_peer"] == "BBB"


def test_correlation_matrix_diagonal_is_one() -> None:
    rng = np.random.default_rng(29)
    frame = pl.DataFrame(
        {
            "date": list(range(150)),
            "AAA": rng.normal(0, 0.02, 150),
            "BBB": rng.normal(0, 0.02, 150),
        }
    )
    _, short, _ = correlation_signals(frame)
    rows = {r["product"]: r for r in short.to_dicts()}
    assert rows["AAA"]["AAA"] == pytest.approx(1.0)
    assert rows["BBB"]["BBB"] == pytest.approx(1.0)


def test_corr_spike_fires_when_short_exceeds_long() -> None:
    rng = np.random.default_rng(31)
    n = 300
    a = rng.normal(0, 0.02, n)
    b = rng.normal(0, 0.02, n)
    b[-20:] = a[-20:] * 0.99 + rng.normal(0, 0.0005, 20)  # recent coupling only

    frame = pl.DataFrame({"date": list(range(n)), "AAA": a, "BBB": b})
    per_product, _, _ = correlation_signals(frame)
    rows = {r["product"]: r for r in per_product.to_dicts()}
    assert rows["AAA"]["corr_spike"] is True
