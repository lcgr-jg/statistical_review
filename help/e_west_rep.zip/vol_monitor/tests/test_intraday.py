"""The intraday range trigger - the one that makes the tool react mid-session."""

from __future__ import annotations

import datetime as dt

import polars as pl
import pytest

from vol_monitor.signals import intraday_range_signals
from vol_monitor.tests.conftest import synthetic_intraday


def val(out: dict[str, float | None], key: str) -> float:
    """Narrow a signal value to a float, failing the test if it is absent."""
    v = out[key]
    assert v is not None, f"{key} was None"
    return float(v)


EMPTY_KEYS = {
    "range_today",
    "range_typical",
    "range_vs_typical",
    "session_progress",
    "last_price",
}


def test_normal_day_reads_near_one() -> None:
    out = intraday_range_signals(synthetic_intraday())
    assert 0.4 < val(out, "range_vs_typical") < 2.0


def test_wide_day_is_flagged_as_expansion() -> None:
    """Triple the final session's moves and the ratio must clear the red band."""
    calm = intraday_range_signals(synthetic_intraday(last_session_range_mult=1.0))
    wild = intraday_range_signals(synthetic_intraday(last_session_range_mult=3.0))
    assert val(wild, "range_vs_typical") > val(calm, "range_vs_typical")
    assert val(wild, "range_vs_typical") > 2.0  # red at 2.0


def test_comparison_is_against_the_same_time_of_day() -> None:
    """Half a session in, the yardstick must be the half-session range.

    This is the whole point: comparing 10:00's range against a full day's
    range would read ~0.5x on every normal morning and never trigger.
    """
    half = intraday_range_signals(
        synthetic_intraday(bars_per_session=20, last_session_bars=10)
    )
    # A normal half-day still scores near 1.0 against the half-day yardstick.
    assert 0.4 < val(half, "range_vs_typical") < 2.0
    # ...and the typical partial range is genuinely smaller than a full day.
    assert val(half, "session_progress") < 1.0


def test_early_session_with_one_bar_is_na() -> None:
    out = intraday_range_signals(synthetic_intraday(last_session_bars=1))
    assert out["range_vs_typical"] is None


def test_too_little_history_is_na() -> None:
    out = intraday_range_signals(synthetic_intraday(sessions=3), min_sessions=5)
    assert out["range_vs_typical"] is None
    assert set(out) == EMPTY_KEYS


def test_empty_frame_is_na_not_a_crash() -> None:
    out = intraday_range_signals(pl.DataFrame())
    assert out["range_vs_typical"] is None
    assert set(out) == EMPTY_KEYS


def test_frame_without_session_column_is_na() -> None:
    out = intraday_range_signals(pl.DataFrame({"close": [1.0, 2.0]}))
    assert out["range_vs_typical"] is None


def test_last_price_is_the_final_close() -> None:
    bars = synthetic_intraday()
    out = intraday_range_signals(bars)
    expected = float(bars.sort(["session", "tod"]).get_column("close")[-1])
    assert val(out, "last_price") == pytest.approx(expected)


def test_range_today_matches_the_session_high_low() -> None:
    bars = synthetic_intraday()
    last = bars.get_column("session").max()
    today = bars.filter(pl.col("session") == last)
    expected = float(today.get_column("high").max()) - float(  # type: ignore[arg-type]
        today.get_column("low").min()  # type: ignore[arg-type]
    )
    out = intraday_range_signals(bars)
    assert val(out, "range_today") == pytest.approx(expected)


def test_flat_history_does_not_divide_by_zero() -> None:
    """A product that never moved gives a zero yardstick - must not blow up."""
    rows = [
        {
            "session": dt.date(2026, 3, 1) + dt.timedelta(days=s),
            "tod": 480 + b * 30,
            "open": 50.0,
            "high": 50.0,
            "low": 50.0,
            "close": 50.0,
            "volume": 1.0,
        }
        for s in range(10)
        for b in range(5)
    ]
    out = intraday_range_signals(pl.DataFrame(rows))
    assert out["range_vs_typical"] is None


def test_is_deterministic() -> None:
    bars = synthetic_intraday()
    assert intraday_range_signals(bars) == intraday_range_signals(bars)
