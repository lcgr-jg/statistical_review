"""The shipped products.yaml must load, and nothing may be hard-coded."""

from __future__ import annotations

from pathlib import Path

import pytest

from vol_monitor.config import DEFAULT_CONFIG_PATH, MonitorConfig, Threshold, load_config
from vol_monitor.regime import SIGNAL_SPECS


def test_default_config_loads() -> None:
    config = load_config()
    assert config.products
    assert config.run.recipients


def test_every_scored_signal_has_a_threshold() -> None:
    config = load_config()
    for spec in SIGNAL_SPECS:
        if spec.mode == "bool" or spec.informational:
            continue
        assert spec.name in config.thresholds, f"no threshold for {spec.name}"


def test_every_product_currency_has_an_fx_entry() -> None:
    config = load_config()
    for product in config.products:
        assert product.currency in config.fx, product.currency


def test_yaml_lists_become_two_sided_thresholds(tmp_path: Path) -> None:
    """The loader must coerce YAML lists into the two-sided threshold form."""
    cfg = tmp_path / "p.yaml"
    cfg.write_text(
        """
products:
  - {name: A, ticker: A1, group: g}
thresholds:
  rsi_14: {amber: [30, 70], red: [20, 80]}
  rv_ratio_10_60: {amber: 1.5, red: 2.0}
""",
        encoding="utf-8",
    )
    config = load_config(cfg)
    rsi = config.thresholds["rsi_14"]
    assert rsi.two_sided
    assert rsi.amber == (30.0, 70.0)
    assert not config.thresholds["rv_ratio_10_60"].two_sided


def test_missing_config_raises() -> None:
    with pytest.raises(FileNotFoundError):
        load_config(Path("does-not-exist.yaml"))


def test_duplicate_product_names_rejected() -> None:
    with pytest.raises(ValueError, match="duplicate product names"):
        MonitorConfig.model_validate(
            {
                "products": [
                    {"name": "A", "ticker": "A1", "group": "g"},
                    {"name": "A", "ticker": "A2", "group": "g"},
                ],
                "thresholds": {},
            }
        )


def test_empty_product_list_rejected() -> None:
    with pytest.raises(ValueError, match="at least one product"):
        MonitorConfig.model_validate({"products": [], "thresholds": {}})


def test_unknown_key_is_rejected_rather_than_silently_ignored() -> None:
    with pytest.raises(ValueError):
        MonitorConfig.model_validate(
            {
                "products": [{"name": "A", "ticker": "A1", "group": "g", "typo": 1}],
                "thresholds": {},
            }
        )


def test_per_product_threshold_lookup(config: MonitorConfig) -> None:
    overridden = config.model_copy(
        update={
            "products": [
                config.products[0].model_copy(
                    update={"thresholds": {"rv_ratio_10_60": Threshold(amber=1.0, red=1.2)}}
                ),
                config.products[1],
            ]
        }
    )
    aaa = overridden.threshold_for("AAA", "rv_ratio_10_60")
    bbb = overridden.threshold_for("BBB", "rv_ratio_10_60")
    assert aaa is not None and aaa.amber == 1.0
    assert bbb is not None and bbb.amber == 1.5
    assert overridden.threshold_for("AAA", "no_such_signal") is None


def test_target_vol_override_per_product(config: MonitorConfig) -> None:
    tweaked = config.model_copy(
        update={
            "products": [
                config.products[0].model_copy(update={"target_daily_pnl_vol_usd": 100_000.0}),
                config.products[1],
            ]
        }
    )
    assert tweaked.target_vol_for("AAA") == 100_000.0
    assert tweaked.target_vol_for("BBB") == config.run.target_daily_pnl_vol_usd


def test_roll_method_override_per_product(config: MonitorConfig) -> None:
    tweaked = config.model_copy(
        update={
            "products": [
                config.products[0].model_copy(update={"roll_method": "backadjust"}),
                config.products[1],
            ]
        }
    )
    assert tweaked.roll_method_for("AAA") == "backadjust"
    assert tweaked.roll_method_for("BBB") == "drop"


def test_recipients_accept_a_comma_separated_string() -> None:
    config = MonitorConfig.model_validate(
        {
            "run": {"recipients": "a@x.com, b@x.com"},
            "products": [{"name": "A", "ticker": "A1", "group": "g"}],
            "thresholds": {},
        }
    )
    assert config.run.recipients == ["a@x.com", "b@x.com"]


def test_config_path_is_inside_the_package() -> None:
    assert DEFAULT_CONFIG_PATH.exists()
    assert DEFAULT_CONFIG_PATH.name == "products.yaml"
