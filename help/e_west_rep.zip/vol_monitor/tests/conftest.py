"""Shared fixtures: a deterministic synthetic price series and a test config."""

from __future__ import annotations

import datetime as dt

import numpy as np
import polars as pl
import pytest

from vol_monitor.config import MonitorConfig

N_DAYS = 400


def synthetic_ohlcv(
    n: int = N_DAYS,
    seed: int = 7,
    start_price: float = 100.0,
    with_iv: bool = True,
    roll_every: int | None = None,
) -> pl.DataFrame:
    """A reproducible OHLCV + OI (+ IV) frame.

    Deliberately not a random walk each call: the seed is fixed so golden-file
    and tolerance tests are stable.
    """
    rng = np.random.default_rng(seed)
    rets = rng.normal(0.0, 0.02, size=n)
    close = start_price * np.exp(np.cumsum(rets))

    spread = np.abs(rng.normal(0.0, 0.012, size=n)) * close + 0.05 * close * 0.01
    high = close + spread
    low = close - spread
    open_ = np.concatenate([[start_price], close[:-1]]) * (
        1.0 + rng.normal(0.0, 0.003, size=n)
    )
    volume = rng.integers(5_000, 50_000, size=n).astype(float)
    oi = np.linspace(100_000, 140_000, n) + rng.normal(0, 800, size=n)

    base = dt.date(2025, 1, 1)
    dates = [base + dt.timedelta(days=int(i)) for i in range(n)]

    gen: list[str] = []
    for i in range(n):
        idx = i // roll_every if roll_every else 0
        gen.append(f"XX{idx}")

    data: dict[str, object] = {
        "date": dates,
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": volume,
        "oi": oi,
        "gen_ticker": gen,
    }
    if with_iv:
        iv = 0.45 + 0.08 * np.sin(np.arange(n) / 23.0) + rng.normal(0, 0.01, size=n)
        data["iv_atm_1m"] = iv
        data["iv_25c"] = iv + 0.02 + rng.normal(0, 0.004, size=n)
        data["iv_25p"] = iv - 0.01 + rng.normal(0, 0.004, size=n)

    return pl.DataFrame(data)


def synthetic_intraday(
    sessions: int = 25,
    bars_per_session: int = 20,
    seed: int = 3,
    start_price: float = 100.0,
    last_session_bars: int | None = None,
    last_session_range_mult: float = 1.0,
) -> pl.DataFrame:
    """Intraday bars shaped like :func:`vol_monitor.bbg.fetch_intraday` output.

    ``last_session_range_mult`` inflates the final session's bar-to-bar moves,
    which is how the range-expansion tests manufacture an unusual day.
    """
    rng = np.random.default_rng(seed)
    rows: list[dict[str, object]] = []
    base = dt.date(2026, 3, 2)
    price = start_price

    for s in range(sessions):
        session = base + dt.timedelta(days=s)
        n_bars = (
            last_session_bars
            if (last_session_bars is not None and s == sessions - 1)
            else bars_per_session
        )
        mult = last_session_range_mult if s == sessions - 1 else 1.0
        for b in range(n_bars):
            step = rng.normal(0.0, 0.25) * mult
            o = price
            c = price + step
            wick = abs(rng.normal(0.0, 0.08)) * mult
            rows.append(
                {
                    "session": session,
                    "tod": 8 * 60 + b * 30,
                    "open": o,
                    "high": max(o, c) + wick,
                    "low": min(o, c) - wick,
                    "close": c,
                    "volume": float(rng.integers(100, 900)),
                }
            )
            price = c

    return pl.DataFrame(rows)


@pytest.fixture
def intraday() -> pl.DataFrame:
    return synthetic_intraday()


@pytest.fixture
def ohlcv() -> pl.DataFrame:
    return synthetic_ohlcv()


@pytest.fixture
def ohlcv_no_iv() -> pl.DataFrame:
    return synthetic_ohlcv(with_iv=False)


@pytest.fixture
def config() -> MonitorConfig:
    return MonitorConfig.model_validate(
        {
            "run": {"recipients": ["desk@example.com"], "lookback_days": 400},
            "products": [
                {"name": "AAA", "ticker": "AAA1 Comdty", "group": "gas",
                 "multiplier": 100, "currency": "EUR", "option_ticker": "AAAA Comdty"},
                {"name": "BBB", "ticker": "BBB1 Comdty", "group": "power",
                 "multiplier": 50, "currency": "USD"},
            ],
            "thresholds": {
                "range_vs_typical": {"amber": 1.5, "red": 2.0},
                "rv_ratio_10_60": {"amber": 1.5, "red": 2.0},
                "dist_ma20_atr": {"amber": 2.0, "red": 3.0},
                "corr_20d_abs": {"amber": 0.85, "red": 0.92},
                "vol_implied_cut": {"amber": 0.20, "red": 0.35},
            },
        }
    )
