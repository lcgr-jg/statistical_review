"""Known inputs -> known lots, and resize-band boundary behaviour."""

from __future__ import annotations

import math

import pytest

from vol_monitor.signals import TRADING_DAYS
from vol_monitor.sizing import compute_drawdown, compute_sizing

SQRT_252 = math.sqrt(TRADING_DAYS)


def test_known_inputs_give_known_lots() -> None:
    # 63.5% annualised -> 4.0% daily; 100 * 10 * 1.0 * 0.04 = $40 vol per lot;
    # $250k target / $40 = 6,250 lots.
    ewma = 0.04 * SQRT_252
    result = compute_sizing(
        product="AAA",
        close=100.0,
        ewma_fast=ewma,
        multiplier=10.0,
        fx_to_usd=1.0,
        target_daily_pnl_vol_usd=250_000.0,
    )
    assert result.sigma_daily == pytest.approx(0.04)
    assert result.usd_vol_per_lot == pytest.approx(40.0)
    assert result.target_lots == pytest.approx(6_250.0)


def test_fx_scales_usd_vol_per_lot() -> None:
    ewma = 0.04 * SQRT_252
    base = compute_sizing("AAA", 100.0, ewma, 10.0, 1.0, 250_000.0)
    eur = compute_sizing("AAA", 100.0, ewma, 10.0, 1.15, 250_000.0)
    assert base.usd_vol_per_lot is not None and base.target_lots is not None
    assert eur.usd_vol_per_lot == pytest.approx(base.usd_vol_per_lot * 1.15)
    assert eur.target_lots == pytest.approx(base.target_lots / 1.15)


def test_implied_pnl_vol_at_current_lots() -> None:
    ewma = 0.04 * SQRT_252
    result = compute_sizing(
        "AAA", 100.0, ewma, 10.0, 1.0, 250_000.0, current_lots=-1_000.0
    )
    assert result.current_lots == -1_000.0
    # sign-agnostic: a short carries the same P&L vol as the equivalent long
    assert result.implied_pnl_vol_at_current == pytest.approx(40_000.0)


# ---------------------------------------------------------------------------
# resize band
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("sigma_now", "expected"),
    [
        (0.0400, False),   # unchanged
        (0.0499, False),   # +24.75%, inside the band
        (0.0500, False),   # exactly +25%, strictly-greater test does not fire
        (0.0501, True),    # +25.25%, fires
        (0.0300, False),   # exactly -25% in ratio terms, same boundary rule
        (0.0299, True),    # -25.25%, fires on the downside too
        (0.0310, False),   # -22.5%, inside
    ],
)
def test_resize_band_boundaries(sigma_now: float, expected: bool) -> None:
    result = compute_sizing(
        "AAA",
        close=100.0,
        ewma_fast=sigma_now * SQRT_252,
        multiplier=10.0,
        fx_to_usd=1.0,
        target_daily_pnl_vol_usd=250_000.0,
        sigma_at_last_resize=0.04,
        resize_band=0.25,
    )
    assert result.resize_flag is expected


def test_no_prior_resize_level_does_not_fire() -> None:
    result = compute_sizing(
        "AAA", 100.0, 0.60, 10.0, 1.0, 250_000.0, sigma_at_last_resize=None
    )
    assert result.resize_flag is False
    assert result.sigma_drift is None


# ---------------------------------------------------------------------------
# the headline "cut x%" number
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("sigma_then", "sigma_now", "expected_cut"),
    [
        (0.02, 0.04, 0.50),   # vol doubled -> the same risk buys half the lots
        (0.02, 0.025, 0.20),  # +25% vol -> cut 20%
        (0.02, 0.02, 0.00),   # unchanged
        (0.04, 0.02, 0.00),   # vol halved -> no cut implied (never negative)
    ],
)
def test_vol_implied_cut(sigma_then: float, sigma_now: float, expected_cut: float) -> None:
    result = compute_sizing(
        "AAA", 100.0, sigma_now * SQRT_252, 10.0, 1.0, 250_000.0,
        sigma_at_last_resize=sigma_then,
    )
    assert result.vol_implied_cut == pytest.approx(expected_cut, abs=1e-9)


def test_vol_implied_cut_is_none_without_a_baseline() -> None:
    result = compute_sizing("AAA", 100.0, 0.6, 10.0, 1.0, 250_000.0)
    assert result.vol_implied_cut is None
    assert result.suggested_cut is None


def test_suggested_cut_prefers_the_actual_book_when_known() -> None:
    """With a position feed, cut against what is actually on, not against vol."""
    ewma = 0.04 * SQRT_252  # -> 6,250 target lots
    result = compute_sizing(
        "AAA", 100.0, ewma, 10.0, 1.0, 250_000.0,
        current_lots=10_000.0, sigma_at_last_resize=0.038,
    )
    assert result.target_lots == pytest.approx(6_250.0)
    # 10,000 held vs 6,250 target -> cut 37.5%, not the ~5% vol-implied figure
    assert result.suggested_cut == pytest.approx(0.375)


def test_suggested_cut_falls_back_to_vol_when_inside_target() -> None:
    ewma = 0.04 * SQRT_252
    result = compute_sizing(
        "AAA", 100.0, ewma, 10.0, 1.0, 250_000.0,
        current_lots=1_000.0, sigma_at_last_resize=0.02,
    )
    # already smaller than target, so the book implies no cut; vol still does
    assert result.suggested_cut == pytest.approx(result.vol_implied_cut)
    assert result.suggested_cut == pytest.approx(0.5)


def test_suggested_cut_handles_a_short_position() -> None:
    ewma = 0.04 * SQRT_252
    result = compute_sizing(
        "AAA", 100.0, ewma, 10.0, 1.0, 250_000.0, current_lots=-10_000.0
    )
    assert result.suggested_cut == pytest.approx(0.375)


def test_sigma_drift_reports_the_move() -> None:
    result = compute_sizing(
        "AAA", 100.0, 0.05 * SQRT_252, 10.0, 1.0, 250_000.0, sigma_at_last_resize=0.04
    )
    assert result.sigma_drift == pytest.approx(0.25)


# ---------------------------------------------------------------------------
# degraded inputs
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("close", "ewma", "fx"),
    [
        (None, 0.6, 1.0),
        (100.0, None, 1.0),
        (100.0, 0.6, None),
        (100.0, float("nan"), 1.0),
        (100.0, 0.0, 1.0),
    ],
)
def test_missing_inputs_give_none_not_an_exception(
    close: float | None, ewma: float | None, fx: float | None
) -> None:
    result = compute_sizing("AAA", close, ewma, 10.0, fx, 250_000.0)
    assert result.target_lots is None
    assert result.resize_flag is False


# ---------------------------------------------------------------------------
# drawdown
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("pnl", "budget", "dd", "status"),
    [
        (50_000.0, 1_000_000.0, 0.0, "green"),    # profit is no drawdown
        (-100_000.0, 1_000_000.0, 0.1, "green"),
        (-499_999.0, 1_000_000.0, 0.499999, "green"),
        (-500_000.0, 1_000_000.0, 0.5, "red"),    # boundary is inclusive
        (-900_000.0, 1_000_000.0, 0.9, "red"),
    ],
)
def test_drawdown_thresholds(pnl: float, budget: float, dd: float, status: str) -> None:
    result = compute_drawdown("AAA", pnl, budget, red_at=0.5)
    assert result.dd_pct_of_budget == pytest.approx(dd)
    assert result.status == status
    assert (result.action is not None) == (status == "red")


@pytest.mark.parametrize(
    ("pnl", "budget"), [(None, 1_000_000.0), (-1.0, None), (-1.0, 0.0)]
)
def test_drawdown_without_a_feed_is_na(pnl: float | None, budget: float | None) -> None:
    result = compute_drawdown("AAA", pnl, budget)
    assert result.status == "na"
    assert result.dd_pct_of_budget is None
