"""Persistence: Snowflake tables plus a local state mirror.

Three tables, created if missing:

``VOL_MONITOR_SIGNALS``  one row per (run_date, product): every signal value,
                         its status, the product status, action and sizing
                         outputs. Idempotent - MERGE on (RUN_DATE, PRODUCT).
``VOL_MONITOR_STATE``    per product: sigma_at_last_resize, last_resize_date
                         and the last status, which is what the email's
                         status-change section compares against.
``VOL_MONITOR_RUNS``     run metadata: success flag, Bloomberg latency,
                         missing-field warnings.

Snowflake is optional. The same STATE information is always mirrored to a
local JSON file so status-change detection and the resize band keep working
when ``persist.enabled`` is false or the warehouse is unreachable.
"""

from __future__ import annotations

import datetime as dt
import json
import logging
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from vol_monitor.config import PersistConfig

log = logging.getLogger(__name__)


@dataclass
class ProductState:
    product: str
    sigma_at_last_resize: float | None = None
    last_resize_date: str | None = None
    last_status: str | None = None
    last_run_date: str | None = None


@dataclass
class RunRecord:
    run_date: str
    started_at: str
    finished_at: str | None = None
    success: bool = False
    n_products: int = 0
    n_red: int = 0
    n_amber: int = 0
    bloomberg_latency_s: float = 0.0
    warnings: list[str] = field(default_factory=list)
    error: str | None = None


# ---------------------------------------------------------------------------
# local state mirror
# ---------------------------------------------------------------------------
class LocalState:
    """JSON-backed store of per-product state. Always written."""

    def __init__(self, directory: str | Path) -> None:
        self.path = Path(directory) / "vol_monitor_state.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> dict[str, ProductState]:
        if not self.path.exists():
            return {}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            log.warning("could not read local state %s: %s", self.path, exc)
            return {}
        return {
            name: ProductState(**payload)
            for name, payload in raw.items()
            if isinstance(payload, dict)
        }

    def save(self, states: dict[str, ProductState]) -> None:
        payload = {name: asdict(st) for name, st in states.items()}
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        log.info("wrote local state to %s", self.path)


# ---------------------------------------------------------------------------
# Snowflake
# ---------------------------------------------------------------------------
_SIGNALS_DDL = """
CREATE TABLE IF NOT EXISTS {fq} (
    RUN_DATE        DATE          NOT NULL,
    PRODUCT         VARCHAR(64)   NOT NULL,
    PRODUCT_GROUP   VARCHAR(64),
    STATUS          VARCHAR(16),
    PREV_STATUS     VARCHAR(16),
    ACTION          VARCHAR(256),
    AMBER_COUNT     NUMBER(9,0),
    RED_COUNT       NUMBER(9,0),
    PAYLOAD         VARIANT,
    LOADED_AT       TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (RUN_DATE, PRODUCT)
)
"""

_STATE_DDL = """
CREATE TABLE IF NOT EXISTS {fq} (
    PRODUCT              VARCHAR(64) NOT NULL PRIMARY KEY,
    SIGMA_AT_LAST_RESIZE FLOAT,
    LAST_RESIZE_DATE     DATE,
    LAST_STATUS          VARCHAR(16),
    LAST_RUN_DATE        DATE,
    UPDATED_AT           TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
)
"""

_RUNS_DDL = """
CREATE TABLE IF NOT EXISTS {fq} (
    RUN_DATE            DATE,
    STARTED_AT          TIMESTAMP_NTZ,
    FINISHED_AT         TIMESTAMP_NTZ,
    SUCCESS             BOOLEAN,
    N_PRODUCTS          NUMBER(9,0),
    N_RED               NUMBER(9,0),
    N_AMBER             NUMBER(9,0),
    BLOOMBERG_LATENCY_S FLOAT,
    WARNINGS            VARIANT,
    ERROR               VARCHAR(4000)
)
"""


class SnowflakeStore:
    """Thin writer over the in-house ``SnowFlake`` connector.

    Every method is fail-soft: a persistence problem logs a warning and lets
    the email go out, because the desk needs the email more than the table.
    """

    def __init__(self, cfg: PersistConfig) -> None:
        self.cfg = cfg
        self._conn: Any = None

    # -- connection -----------------------------------------------------
    def _connection(self) -> Any:
        if self._conn is None:
            from jain_commods.core.interfaces.snowflake import SnowFlake

            sf = SnowFlake(
                database=self.cfg.database,
                schema=self.cfg.schema_,
                role=self.cfg.role,
                warehouse=self.cfg.warehouse,
            )
            self._conn = sf._conn  # noqa: SLF001 - the connector exposes no public handle
        return self._conn

    def _fq(self, table: str) -> str:
        return f"{self.cfg.database}.{self.cfg.schema_}.{table}"

    # -- DDL ------------------------------------------------------------
    def ensure_tables(self) -> None:
        cur = self._connection().cursor()
        try:
            cur.execute(_SIGNALS_DDL.format(fq=self._fq(self.cfg.signals_table)))
            cur.execute(_STATE_DDL.format(fq=self._fq(self.cfg.state_table)))
            cur.execute(_RUNS_DDL.format(fq=self._fq(self.cfg.runs_table)))
        finally:
            cur.close()

    # -- writes ---------------------------------------------------------
    def merge_signals(self, run_date: dt.date, rows: list[dict[str, Any]]) -> int:
        """MERGE one row per product on (RUN_DATE, PRODUCT)."""
        if not rows:
            return 0
        fq = self._fq(self.cfg.signals_table)
        sql = f"""
        MERGE INTO {fq} t
        USING (
            SELECT %(run_date)s::DATE          AS RUN_DATE,
                   %(product)s                 AS PRODUCT,
                   %(product_group)s           AS PRODUCT_GROUP,
                   %(status)s                  AS STATUS,
                   %(prev_status)s             AS PREV_STATUS,
                   %(action)s                  AS ACTION,
                   %(amber_count)s             AS AMBER_COUNT,
                   %(red_count)s               AS RED_COUNT,
                   PARSE_JSON(%(payload)s)     AS PAYLOAD
        ) s
        ON t.RUN_DATE = s.RUN_DATE AND t.PRODUCT = s.PRODUCT
        WHEN MATCHED THEN UPDATE SET
            PRODUCT_GROUP = s.PRODUCT_GROUP, STATUS = s.STATUS,
            PREV_STATUS = s.PREV_STATUS, ACTION = s.ACTION,
            AMBER_COUNT = s.AMBER_COUNT, RED_COUNT = s.RED_COUNT,
            PAYLOAD = s.PAYLOAD, LOADED_AT = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN INSERT
            (RUN_DATE, PRODUCT, PRODUCT_GROUP, STATUS, PREV_STATUS, ACTION,
             AMBER_COUNT, RED_COUNT, PAYLOAD)
            VALUES (s.RUN_DATE, s.PRODUCT, s.PRODUCT_GROUP, s.STATUS,
                    s.PREV_STATUS, s.ACTION, s.AMBER_COUNT, s.RED_COUNT, s.PAYLOAD)
        """
        cur = self._connection().cursor()
        try:
            for row in rows:
                cur.execute(sql, {**row, "run_date": run_date.isoformat()})
        finally:
            cur.close()
        return len(rows)

    def merge_state(self, states: dict[str, ProductState]) -> int:
        if not states:
            return 0
        fq = self._fq(self.cfg.state_table)
        sql = f"""
        MERGE INTO {fq} t
        USING (
            SELECT %(product)s              AS PRODUCT,
                   %(sigma)s                AS SIGMA_AT_LAST_RESIZE,
                   %(resize_date)s::DATE    AS LAST_RESIZE_DATE,
                   %(last_status)s          AS LAST_STATUS,
                   %(last_run_date)s::DATE  AS LAST_RUN_DATE
        ) s
        ON t.PRODUCT = s.PRODUCT
        WHEN MATCHED THEN UPDATE SET
            SIGMA_AT_LAST_RESIZE = s.SIGMA_AT_LAST_RESIZE,
            LAST_RESIZE_DATE = s.LAST_RESIZE_DATE,
            LAST_STATUS = s.LAST_STATUS,
            LAST_RUN_DATE = s.LAST_RUN_DATE,
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN INSERT
            (PRODUCT, SIGMA_AT_LAST_RESIZE, LAST_RESIZE_DATE, LAST_STATUS, LAST_RUN_DATE)
            VALUES (s.PRODUCT, s.SIGMA_AT_LAST_RESIZE, s.LAST_RESIZE_DATE,
                    s.LAST_STATUS, s.LAST_RUN_DATE)
        """
        cur = self._connection().cursor()
        try:
            for st in states.values():
                cur.execute(
                    sql,
                    {
                        "product": st.product,
                        "sigma": st.sigma_at_last_resize,
                        "resize_date": st.last_resize_date,
                        "last_status": st.last_status,
                        "last_run_date": st.last_run_date,
                    },
                )
        finally:
            cur.close()
        return len(states)

    def load_state(self) -> dict[str, ProductState]:
        fq = self._fq(self.cfg.state_table)
        cur = self._connection().cursor()
        try:
            cur.execute(
                f"SELECT PRODUCT, SIGMA_AT_LAST_RESIZE, LAST_RESIZE_DATE, "
                f"LAST_STATUS, LAST_RUN_DATE FROM {fq}"
            )
            out: dict[str, ProductState] = {}
            for product, sigma, resize_date, status, run_date in cur.fetchall():
                out[product] = ProductState(
                    product=product,
                    sigma_at_last_resize=float(sigma) if sigma is not None else None,
                    last_resize_date=str(resize_date) if resize_date else None,
                    last_status=status,
                    last_run_date=str(run_date) if run_date else None,
                )
            return out
        finally:
            cur.close()

    def insert_run(self, record: RunRecord) -> None:
        fq = self._fq(self.cfg.runs_table)
        cur = self._connection().cursor()
        try:
            cur.execute(
                f"""
                INSERT INTO {fq}
                    (RUN_DATE, STARTED_AT, FINISHED_AT, SUCCESS, N_PRODUCTS,
                     N_RED, N_AMBER, BLOOMBERG_LATENCY_S, WARNINGS, ERROR)
                SELECT %(run_date)s::DATE, %(started_at)s::TIMESTAMP_NTZ,
                       %(finished_at)s::TIMESTAMP_NTZ, %(success)s, %(n_products)s,
                       %(n_red)s, %(n_amber)s, %(latency)s,
                       PARSE_JSON(%(warnings)s), %(error)s
                """,
                {
                    "run_date": record.run_date,
                    "started_at": record.started_at,
                    "finished_at": record.finished_at,
                    "success": record.success,
                    "n_products": record.n_products,
                    "n_red": record.n_red,
                    "n_amber": record.n_amber,
                    "latency": record.bloomberg_latency_s,
                    "warnings": json.dumps(record.warnings),
                    "error": record.error,
                },
            )
        finally:
            cur.close()


# ---------------------------------------------------------------------------
# façade used by the pipeline
# ---------------------------------------------------------------------------
class Persistence:
    """Local state always; Snowflake when enabled and reachable."""

    def __init__(self, cfg: PersistConfig, base_dir: Path) -> None:
        self.cfg = cfg
        self.local = LocalState(base_dir / cfg.local_state_dir)
        self._store: SnowflakeStore | None = None
        self.errors: list[str] = []

    @property
    def store(self) -> SnowflakeStore | None:
        if not self.cfg.enabled:
            return None
        if self._store is None:
            try:
                store = SnowflakeStore(self.cfg)
                store.ensure_tables()
                self._store = store
            except Exception as exc:  # noqa: BLE001
                msg = f"Snowflake unavailable, falling back to local state only: {exc}"
                log.warning(msg)
                self.errors.append(msg)
                self.cfg = self.cfg.model_copy(update={"enabled": False})
                return None
        return self._store

    def load_state(self) -> dict[str, ProductState]:
        store = self.store
        if store is not None:
            try:
                remote = store.load_state()
                if remote:
                    return remote
            except Exception as exc:  # noqa: BLE001
                msg = f"could not read VOL_MONITOR_STATE: {exc}"
                log.warning(msg)
                self.errors.append(msg)
        return self.local.load()

    def save_state(self, states: dict[str, ProductState]) -> None:
        self.local.save(states)
        store = self.store
        if store is None:
            return
        try:
            store.merge_state(states)
        except Exception as exc:  # noqa: BLE001
            msg = f"could not write VOL_MONITOR_STATE: {exc}"
            log.warning(msg)
            self.errors.append(msg)

    def save_signals(self, run_date: dt.date, rows: list[dict[str, Any]]) -> None:
        store = self.store
        if store is None:
            log.info("persistence disabled - skipping VOL_MONITOR_SIGNALS write")
            return
        try:
            n = store.merge_signals(run_date, rows)
            log.info("merged %d rows into VOL_MONITOR_SIGNALS", n)
        except Exception as exc:  # noqa: BLE001
            msg = f"could not write VOL_MONITOR_SIGNALS: {exc}"
            log.warning(msg)
            self.errors.append(msg)

    def save_run(self, record: RunRecord) -> None:
        store = self.store
        if store is None:
            return
        try:
            store.insert_run(record)
        except Exception as exc:  # noqa: BLE001
            msg = f"could not write VOL_MONITOR_RUNS: {exc}"
            log.warning(msg)
            self.errors.append(msg)
