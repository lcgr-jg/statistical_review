"""Command line entry point.

    python -m vol_monitor.cli run --date 2026-09-18 --dry-run
    python -m vol_monitor.cli backfill --start 2026-01-02 --end 2026-01-31
"""

from __future__ import annotations

import argparse
import json
import logging
import sys

from vol_monitor.pipeline import backfill, configure_logging, run_vol_monitor


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vol-monitor", description="Daily vol-regime & position-sizing monitor"
    )
    parser.add_argument("--config", default=None, help="path to products.yaml")
    parser.add_argument("--verbose", action="store_true", help="debug logging")
    parser.add_argument(
        "--plain-logs", action="store_true", help="human-readable logs instead of JSON"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="run the monitor for one date")
    run.add_argument("--date", default=None, help="YYYY-MM-DD (default: today)")
    run.add_argument(
        "--dry-run",
        action="store_true",
        help="write the HTML to disk and skip sending",
    )
    run.add_argument("--recipients", default=None, help="comma-separated override")
    run.add_argument("--output-dir", default=None)
    run.add_argument(
        "--no-cache", action="store_true", help="bypass the local Parquet cache"
    )
    run.add_argument(
        "--intraday",
        action="store_true",
        help="mid-session re-check: only sends if a product's status got worse",
    )

    bf = sub.add_parser("backfill", help="signals + regime over a range, no email")
    bf.add_argument("--start", required=True, help="YYYY-MM-DD")
    bf.add_argument("--end", required=True, help="YYYY-MM-DD")
    bf.add_argument("--no-cache", action="store_true")

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    configure_logging(
        level=logging.DEBUG if args.verbose else logging.INFO,
        json_logs=not args.plain_logs,
    )

    if args.command == "run":
        result = run_vol_monitor(
            run_date=args.date,
            config_path=args.config,
            dry_run=args.dry_run,
            recipients=args.recipients,
            use_cache=not args.no_cache,
            output_dir=args.output_dir,
            intraday_run=args.intraday,
        )
    else:
        result = backfill(
            start_date=args.start,
            end_date=args.end,
            config_path=args.config,
            use_cache=not args.no_cache,
        )

    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
