import logging
import time
import pandas as pd
import numpy as np
import calendar

from datetime import datetime, timedelta, UTC
from dateutil.relativedelta import relativedelta

from jain_commods.core.interfaces.commodityessentials import CommodityEssentials
from jain_commods.core.interfaces.sqldb import DataQuery
from jain_commods.core.util.htmlutils import df2html
from jain_commods.core.util.dateutils import get_nextcontract, get_season
from jain_commods.fundamental.gas import util


# TODO: hard coded. They publish this as a time series in their "European gas storage" dataset but we don't currently store it 
ea_storage_capa_eu = 109.32


def get_ea_storage_data_eu(dt_today, dt_dod, dt_wow, months_history):
    
    # Retrieve latest storage data for the full EA perimeter
    dq = DataQuery(logintype='prod')

    # Set start date
    start_date = (dt_today-relativedelta(months=months_history)).replace(day=1)
    
    # Get data for each report date
    res = []
    for report_dt in [dt_today, dt_dod, dt_wow]:
        data = dq.get_data(by='metadata',
                           metadata={'description': 'Monthly EA forecast for natural gas inventories in Europe in bcm'},
                           start_date=start_date,
                           querytype='bulk', 
                           report_date_to=report_dt,
                           multi_instance='latest',
                           )
        # Capture output
        df = data[list(data.keys())[0]].set_index('date')[['value']].rename(columns={'value':report_dt})
        res.append(df)
        
    df_output = pd.concat(res, axis=1)
    
    return df_output
    

    


def generate_report(countries, days_history, days_forward, months_history, months_forward, seasons_history, seasons_forward, ce_stale_check_hrs, scenarios, use_balance_cache):
    
    # Set ref dates
    dt_today = datetime.now()
    # DoD be set to 3 on a monday to show vs Friday
    dt_dod = dt_today - timedelta(days=3 if dt_today.weekday()==0 else 1)
    dt_wow = dt_today - timedelta(days=7)
    
    # We want to send the monthly basecase as a csv
    balance_for_csv = pd.DataFrame()
    
    # Process each scenario for each ref_date
    logging.info(f"Querying balances for {len(scenarios)} scenarios on {dt_today.strftime('%d %b')}, {dt_dod.strftime('%d %b')} and {dt_wow.strftime('%d %b')}")
    output = {}
    for dt in [dt_today, dt_dod, dt_wow]:
    
        balances = {}
        for scenario in scenarios:
            
            # Get balance from the db/cache
            try:
                res = util.get_eu_gas_balance(ref_date=dt, scenario_name=scenario, use_cache=use_balance_cache)
            except Exception as e:
                print(f"Warning: could not load {scenario} scenario for ref_date {dt}: {e}")
                res = None
            
            if res is not None:
                df_daily = res['balance_daily']
                
                # Capture latest raw monthly basecase so we can email it
                if (dt==dt_today) & (scenario=='Basecase'):
                    balance_for_csv = res['balance_monthly'].copy()
    
                # Truncate monthly as per params, ready for display (note: daily is truncated below)
                df_monthly = res['balance_monthly']
                
                # Set range
                start_date = (dt_today-relativedelta(months=months_history)).replace(day=1)
                end_date = (dt_today+relativedelta(months=months_forward)).replace(day=1)
                # Little function needed to ensure we filter on dates AND keep MTD and BOM
                def keep_datetime_in_range(idx_val, start_date, end_date):
                    if idx_val in ["MTD", "BoM"]:
                        return True
                    try:
                        dt = pd.to_datetime(idx_val)
                        return start_date <= dt <= end_date
                    except:
                        return False
                # Filter monthly values
                df_monthly = df_monthly.loc[[keep_datetime_in_range(idx, start_date, end_date) for idx in df_monthly.index]]
                
                # Truncate seasonal as per params
                df_seasons = res['balance_seasonal']
                season_start = get_nextcontract(dt_today, 's', seasons_history*-1)
                season_end = get_nextcontract(dt_today, 's', seasons_forward)
                df_seasons = df_seasons[(df_seasons.index>=season_start) & (df_seasons.index<=season_end)]
                
                # Generate seasonal labels
                # TODO: should we do this now? Or easier to leave as dates and do this at the last minute? (ie as we create the html table??)
                df_seasons.index = [get_season(idx,return_label=True) for idx in df_seasons.index]
                
                # Capture output
                balances[scenario] = {'daily': df_daily,
                                      'monthly': df_monthly,
                                      'seasonal': df_seasons,
                                      }
        output[dt] = balances
       
    
    ##### Produce output
    logging.info('Got data, producing report content')
    
    # Notes:
        # We show daily & monthly tables for Basecase only
        # Everything else: show in forecast storage levels
    
    # TODO: df2html needs various updates:
        # handle per column formatting
        # set "," thousand seperator (optional param)
        # allow for date index or date columns

    # Basecase: get dataframes ready for preparing HTML output
    basecase_d = output[dt_today]['Basecase']['daily']
    basecase_d_dod = basecase_d - output[dt_dod]['Basecase']['daily']
    
    # Daily: set index type
    basecase_d.index = pd.to_datetime(basecase_d.index)
    basecase_d_dod.index = pd.to_datetime(basecase_d_dod.index)
    
    # Truncate as per params (ready for display)
    basecase_d = basecase_d[(basecase_d.index>=dt_today-timedelta(days=days_history)) & 
                            (basecase_d.index<=dt_today+timedelta(days=days_forward))
                            ]
    basecase_d_dod = basecase_d_dod[(basecase_d_dod.index>=dt_today-timedelta(days=days_history)) & 
                                    (basecase_d_dod.index<=dt_today+timedelta(days=days_forward))
                                    ]
    
    
    # Daily: given current df2html limitations, we cheat for certain columns and set them as strings
    basecase_d[('Storage','Fill %')] = [f'{v:.0%}' for v in basecase_d[('Storage','Fill %')].values]
    basecase_d[('Storage','Stock')] = [f'{v:,.0f}' for v in basecase_d[('Storage','Stock')].values]
    basecase_d[('Storage','Capa')] = [f'{v:,.0f}' for v in basecase_d[('Storage','Capa')].values]
    basecase_d_dod[('Storage','Fill %')] = [f'{v:.0%}' for v in basecase_d_dod[('Storage','Fill %')].values]
    basecase_d_dod[('Storage','Stock')] = [f'{v:,.0f}' for v in basecase_d_dod[('Storage','Stock')].values]
    basecase_d_dod[('Storage','Capa')] = [f'{v:,.0f}' for v in basecase_d_dod[('Storage','Capa')].values]
   
    # Daily: tidy up nan values (string due to logic above)
    basecase_d = basecase_d.replace('nan', '')
    basecase_d = basecase_d.replace('nan%', '')
    
    # Daily: create basecase HTML table
    basecase_d_html = df2html(basecase_d, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y', highlight_today=True)      
    basecase_d_dod_html = df2html(basecase_d_dod, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y', highlight_today=True)      
            

    scenarios_m_html = ''
    for scenario in scenarios:
        
        if scenario not in ['UkraineHigh','LowLNG','HighLNG','ALNG2','PlattsCCGT','CCGT_JG_DEFR','HormuzAug26','HormuzOct26','HormuzNov26']:
        
            # TODO: this is messy/copy & paste/needs tidying up
            
            scenario_m =  output[dt_today][scenario]['monthly']
            scenario_m_dod = scenario_m - output[dt_dod][scenario]['monthly']
            scenario_m_wow = scenario_m - output[dt_wow][scenario]['monthly']
            
            # Extra logic to handle mess when comparing MTD and BoM across months
            if dt_today.month != dt_dod.month:
                scenario_m_dod = scenario_m_dod.drop(["BoM", "MTD"])
            if dt_today.month != dt_wow.month:
                scenario_m_wow = scenario_m_wow.drop(["BoM", "MTD"])
    
            # Monthly: set display strs
            scenario_m[('Storage','Fill Start %')] = [f'{v:.0%}' for v in scenario_m[('Storage','Fill Start %')].values]
            scenario_m[('Storage','Fill End %')] = [f'{v:.0%}' for v in scenario_m[('Storage','Fill End %')].values]
            scenario_m[('Storage','Stock Start')] = [f'{v:,.0f}' for v in scenario_m[('Storage','Stock Start')].values]
            scenario_m[('Storage','Stock End')] = [f'{v:,.0f}' for v in scenario_m[('Storage','Stock End')].values]
            scenario_m[('Storage','Capa')] = [f'{v:,.0f}' for v in scenario_m[('Storage','Capa')].values]
            
            scenario_m_dod[('Storage','Fill Start %')] = [f'{v:.0%}' for v in scenario_m_dod[('Storage','Fill Start %')].values]
            scenario_m_dod[('Storage','Fill End %')] = [f'{v:.0%}' for v in scenario_m_dod[('Storage','Fill End %')].values]
            scenario_m_dod[('Storage','Stock Start')] = [f'{v:,.0f}' for v in scenario_m_dod[('Storage','Stock Start')].values]
            scenario_m_dod[('Storage','Stock End')] = [f'{v:,.0f}' for v in scenario_m_dod[('Storage','Stock End')].values]
            scenario_m_dod[('Storage','Capa')] = [f'{v:,.0f}' for v in scenario_m_dod[('Storage','Capa')].values]
            
            scenario_m_wow[('Storage','Fill Start %')] = [f'{v:.0%}' for v in scenario_m_wow[('Storage','Fill Start %')].values]
            scenario_m_wow[('Storage','Fill End %')] = [f'{v:.0%}' for v in scenario_m_wow[('Storage','Fill End %')].values]
            scenario_m_wow[('Storage','Stock Start')] = [f'{v:,.0f}' for v in scenario_m_wow[('Storage','Stock Start')].values]
            scenario_m_wow[('Storage','Stock End')] = [f'{v:,.0f}' for v in scenario_m_wow[('Storage','Stock End')].values]
            scenario_m_wow[('Storage','Capa')] = [f'{v:,.0f}' for v in scenario_m_wow[('Storage','Capa')].values]
            
            # Monthly: tidy up nan values (string due to logic above)
            scenario_m = scenario_m.replace('nan', '')
            scenario_m = scenario_m.replace('nan%', '')
            
            scenario_m_dod = scenario_m_dod.replace('nan', '')
            scenario_m_dod = scenario_m_dod.replace('nan%', '')
            scenario_m_wow = scenario_m_wow.replace('nan', '')
            scenario_m_wow = scenario_m_wow.replace('nan%', '')
            
            # Monthly: create HTML 
            scenario_m_html = df2html(scenario_m, precision=0, index_dt_format='%b-%y', highlight_specific_row=True, highlight_specific_row_item='MTD')            
            scenario_m_dod_html = f"<br><b><u>{scenario} (monthly: DoD):</u></b>" + df2html(scenario_m_dod, precision=0, index_dt_format='%b-%y', highlight_specific_row=True, highlight_specific_row_item='MTD')
            # NB: we only show WoW for the basecase
            scenario_m_wow_html = f"<br><b><u>{scenario} (monthly: WoW):</u></b>" + df2html(scenario_m_wow, precision=0, index_dt_format='%b-%y', highlight_specific_row=True, highlight_specific_row_item='MTD') if scenario == 'Basecase' else ''      
                
            scenarios_m_html = scenarios_m_html + f"""<br><hr><br>
                                                      <b><u>{scenario} (monthly):</u></b>
                                                      <br>
                                                      {scenario_m_html}
                                                      {scenario_m_dod_html}
                                                      {scenario_m_wow_html}
                                                      """
    
    # Seasonal: only created for basecase
    basecase_seasonal = output[dt_today]['Basecase']['seasonal']
    
    # Seasonal: set display strs
    basecase_seasonal[('Storage','Fill Start %')] = [f'{v:.0%}' for v in basecase_seasonal[('Storage','Fill Start %')].values]
    basecase_seasonal[('Storage','Fill End %')] = [f'{v:.0%}' for v in basecase_seasonal[('Storage','Fill End %')].values]
    basecase_seasonal[('Storage','Stock Start')] = [f'{v:,.0f}' for v in basecase_seasonal[('Storage','Stock Start')].values]
    basecase_seasonal[('Storage','Stock End')] = [f'{v:,.0f}' for v in basecase_seasonal[('Storage','Stock End')].values]
    basecase_seasonal[('Storage','Capa')] = [f'{v:,.0f}' for v in basecase_seasonal[('Storage','Capa')].values]
   
    # Seasonal: tidy up nan values (string due to logic above)
    basecase_seasonal = basecase_seasonal.replace('nan', '')
    basecase_seasonal = basecase_seasonal.replace('nan%', '')
    
    # Seasonal: create basecase HTML table
    curr_season = get_season(dt_today,return_label=True)
    basecase_seasonal_html = df2html(basecase_seasonal, precision=0, highlight_specific_row=True, highlight_specific_row_item=curr_season)  
    
    
    
    
    
    # Monthly: YoY summary tables
    res = util.get_eu_gas_balance(ref_date=dt_today, scenario_name='Basecase', use_cache=use_balance_cache) # NB: we requery the base to get the full history (ie 2019)
    basecase_m =  res['balance_daily'].resample('MS').mean() # NB: we use daily to avoid handling MTD and BoM
    # Truncate
    basecase_m = basecase_m[basecase_m.index<=datetime(2027,12,31)]
    # Define groupings
    yoy_col_groupings = {'Demand': [('Demand','LDZ'),('Demand','CCGT'),('Demand','Industrial')],
                         'Production': [('Production','NCS'),('Production','UKCS'),('Production','Other')],
                         'Supply': [('Supply','Regas'),('Supply','Mazara'),('Supply','Gela'),('Supply','TAP')],
                         'Exports': [('Exports','Ireland'),('Exports','Pirineos')],
                         'Storage': [('Storage','StB')]
                         }
    # Create tables
    yoy_output = {}
    for yoy_grp in yoy_col_groupings.keys():

        yoy_output_grp = []
        for reqd_col in yoy_col_groupings[yoy_grp]:
            item_data = basecase_m[[reqd_col]].copy()
            item_data['year'] = item_data.index.year
            item_data['month'] = item_data.index.month
            
            # Pivot the data to have months as index and years as columns
            yoy = item_data.pivot_table(
                        values=item_data, 
                        index='month', 
                        columns='year', 
                        aggfunc='first'  # Use 'first' since we expect one value per month/year
                    )
            yoy_output_grp.append(df2html(yoy, precision=0, highlight_specific_row=True))
         
        yoy_output[yoy_grp] = yoy_output_grp
        
        
    # Create html tables
    yoy_html = ''
    for n in yoy_output.keys():
        grp_cells = ''
        for tbl in yoy_output[n]:
            grp_cells = grp_cells + f"<td style='vertical-align:top'>{tbl}</td><td width='15px'></td>"
            
        grp_tbl = f"<table><tr>{grp_cells}</tr></table>"
        
        yoy_html = yoy_html + f"<br>{grp_tbl}"
            
            
    
    
    
    # Get Energy Aspects forecast stock levels for their entire EU perimter
    df_ea_stock = get_ea_storage_data_eu(dt_today, dt_dod, dt_wow, months_history)
    df_ea_stock_pc = df_ea_stock / ea_storage_capa_eu
        
    
    # Construct summary table of storage carry outs
    eu_targets = {#datetime(2025,3,1): 0,
                  #datetime(2025,4,1): 0.26,
                  # datetime(2025,6,1): 0.45,
                  # datetime(2025,8,1): 0.72,
                  # datetime(2025,10,1): 0.9,
                  # datetime(2026,3,1): 0,
                  datetime(2026,10,1): 0,
                  datetime(2027,3,1): 0,
                  datetime(2027,10,1): 0,
                  }
    eu_targets_derived = {#datetime(2025,3,1): 0,
                          #datetime(2025,4,1): 0.19,
                          # datetime(2025,6,1): 0.37,
                          # datetime(2025,8,1): 0.64,
                          # datetime(2025,10,1): 0.81,
                          # datetime(2026,3,1): 0,
                          datetime(2026,10,1): 0,
                          datetime(2027,3,1): 0,
                          datetime(2027,10,1): 0,
                          }
    
    eu_target_cols = ['EU Target', 'EU Derived Target']
    ea_full = 'EA (full)'
    carry_outs_all = {}
    for fcast_dt in [dt_today, dt_dod, dt_wow]:
        stock_pc={}
        for dt in eu_targets.keys():
            values = []
            for scenario in scenarios:
                if scenario in output[fcast_dt].keys():
                    values.append(output[fcast_dt][scenario]['daily'].loc[dt + pd.offsets.MonthEnd(1),('Storage','Fill %')])
                else:
                    values.append(0)
            
            # Get EA full perimeter value for this dt
            ea_full_eu_pc = df_ea_stock_pc.loc[dt,fcast_dt]
            
            stock_pc[dt] = values + [ea_full_eu_pc, eu_targets[dt], eu_targets_derived[dt]]
            
        carry_outs = pd.DataFrame.from_dict(stock_pc, orient='index')
    
        carry_outs.index = [f"End {i.strftime('%b-%y')}" for i in carry_outs.index]
        carry_outs.columns = scenarios + [ea_full, 'EU Target', 'EU Derived Target']
    
        carry_outs_all[fcast_dt] = carry_outs
    
    carry_outs_today = carry_outs_all[dt_today]
    carry_outs_dod = carry_outs_all[dt_today] - carry_outs_all[dt_dod]
    carry_outs_wow = carry_outs_all[dt_today] - carry_outs_all[dt_wow]
    
    # Replace zeros with "-" in the EU target cols
    carry_outs_today[eu_target_cols] = carry_outs_today[eu_target_cols].replace(0,'-')
    
    # Tidy up number format 
    for c in carry_outs_today.columns:
         carry_outs_today[c] = [f'{v:.0%}' if isinstance(v,float) else v for v in carry_outs_today[c].values]
         carry_outs_dod[c] = [f'{v:+.0%}' if isinstance(v,float) else v for v in carry_outs_dod[c].values]
         carry_outs_wow[c] = [f'{v:+.0%}' if isinstance(v,float) else v for v in carry_outs_wow[c].values]
    
    display_cols = [c for c in carry_outs_dod.columns if c not in eu_target_cols]
    
    # Fiddle with order to insert "EA (full)" at the correct location
    ea_index = display_cols.index('EA')
    display_cols.insert(ea_index + 1, ea_full)
    display_cols = display_cols[:-1]
    
    
    # Produce HTML tables
    # carry_outs_today_html = df2html(carry_outs_today[display_cols + eu_target_cols])        
    carry_outs_today_html = df2html(carry_outs_today[display_cols])   
    carry_outs_dod_html = df2html(carry_outs_dod[display_cols])        
    carry_outs_wow_html = df2html(carry_outs_wow[display_cols])        
    
    # Produce summary table of absolute EA full perimter storage forecast levels
    df_ea_stock_summary = df_ea_stock[[dt_today]].rename(columns={dt_today: 'Stock'})
    df_ea_stock_summary['Capa'] = ea_storage_capa_eu
    df_ea_stock_summary = pd.concat([df_ea_stock_summary, df_ea_stock_pc[[dt_today]].rename(columns={dt_today: 'Fill %'})], axis=1)
    df_ea_stock_summary['Fill %'] = [f'{v:.0%}' if isinstance(v,float) else v for v in df_ea_stock_summary['Fill %'].values]
    df_ea_stock_summary = df_ea_stock_summary[df_ea_stock_summary.index.isin(eu_targets.keys())]
    df_ea_stock_summary_html = df2html(df_ea_stock_summary, precision=0, index_dt_format='%b-%y', highlight_specific_row=False)
    
    
    # Get details of last CE snapshot
    ce = CommodityEssentials(logintype='prod')
    ce_snapshot = ce.get_log_entry('eugasseriesbulk')
    ce_saved_date_utc = ce_snapshot['saved_date_utc']
    
    # Check if CE data is stale
    hours_diff = (datetime.now(UTC).replace(tzinfo=None) - ce_saved_date_utc).total_seconds() / 3600
    
    # CE data has gone stale, add a warning message to the email
    ce_timestamp_prefix = '<b>stale</b>' if hours_diff > ce_stale_check_hrs else 'latest'
    ce_stale_warning_message = f"<br><p style='color:red;'><u><b>!!!WARNING!!!</b> Commodity Essentials data appears to be stale! Latest available snapshot is <b>{ce_saved_date_utc.strftime('%H:%M%p %d-%b')}</b> which is more than {ce_stale_check_hrs} hours old.</u></p><br>" if hours_diff > ce_stale_check_hrs else ''
    
    # Get EA and Platts forecast dates wrt to the ref_dates above
    forecasts_used = {}
    for provider in ['EA','Platts']:
        forecasts_used[provider] = get_provider_forecast_dt(provider, [dt_today, dt_dod, dt_wow])
        
    # Construct tables of dates
    provider_forecasts = pd.DataFrame(forecasts_used)
    provider_forecasts.index = [f"D{(dt_today-dt).days} ({pd.to_datetime(dt).strftime('%d %b')})" for dt in provider_forecasts.index]
    
    provider_forecasts['EA'] = [pd.to_datetime(dt).strftime('%d %b') for dt in provider_forecasts['EA'].values]
    provider_forecasts['Platts'] = [pd.to_datetime(dt).strftime('%d %b') for dt in provider_forecasts['Platts'].values]
    
    provider_forecasts_html = df2html(provider_forecasts)

    
    ##### Calculate cumulative DoD changes for each S&D element
    base_d = output[dt_today]['Basecase']['daily']
    base_d_dod = base_d - output[dt_dod]['Basecase']['daily']
    # Set index type & truncate
    base_d_dod.index = pd.to_datetime(base_d_dod.index)
    base_d_dod = base_d_dod[base_d_dod.index>=dt_today]
    # Exclude Storage cols
    cols_cumsum = [c for c in base_d_dod.columns if not c[0] == "Storage"]
    # Calc cumulative sum 
    base_d_cumsum = base_d_dod[cols_cumsum].cumsum()
    
    # Select the reqd target dates (NB: daily so we need to get end of month list of dates)
    end_of_months = [datetime(dt.year, dt.month, calendar.monthrange(dt.year, dt.month)[1]) for dt in eu_targets.keys()]
    base_d_cumsum_res = base_d_cumsum.loc[end_of_months]
    base_d_cumsum_res.index = [f"End {i.strftime('%b-%y')}" for i in base_d_cumsum_res.index]
    base_d_cumsum_res_html = df2html(base_d_cumsum_res, precision=0)

    
    # Create final email body HTML
    email_body = f"""
                    {ce_stale_warning_message}
                    <b><u>Notes:</u></b>
                    <br>See email footer for more notes.
                    <br>Using balances cache: {use_balance_cache}
                    <br>Basecase Scenario = Jain forecasts (regas, LDZ ECENS + EC46, CCGT ECENS) + Platts (NCS) + Energy Aspects (everything else).
                    <br>Forecast comparisons: DoD = {dt_dod.strftime('%d %b')}, WoW = {dt_wow.strftime('%d %b')}
                    <br>The "{ea_full}" column in "Forecast Storage Fills" is EA's full European perimeter with {ea_storage_capa_eu:.0f}bcm capa (whereas "EA" is a reduced perimeter, aligned with our Basecase).
                    <br>The following provider forecast dates are being used for the scenarios:
                    {provider_forecasts_html}
                    <br><hr><br>
                    <b><u>Forecast Storage Fills:</u></b><br>
                    <table><tr><td style='vertical-align:top'><b>Today:</b><br>{carry_outs_today_html}</td><td width='15px'></td><td style='vertical-align:top'><b>DoD:</b><br>{carry_outs_dod_html}</td><td style='vertical-align:top'><b>WoW:</b><br>{carry_outs_wow_html}</td></tr></table>
                    <br><hr><br>
                    <b><u>Cumulative Changes (mcm):</u></b><br>
                    <b>Basecase (DoD):</b>
                    {base_d_cumsum_res_html}
                    <br><hr><br>
                    <b><u>Basecase (daily):</u></b>
                    <br>
                    {basecase_d_html}
                    <br>
                    <b><u>Basecase (daily: DoD):</u></b>
                    {basecase_d_dod_html}
                    <br>
                    {scenarios_m_html}
                    <br><hr><br>
                    <b><u>{ea_full} Storage Stock Forecast (monthly, bcm):</u></b>
                    {df_ea_stock_summary_html}
                    <br><hr><br>
                    <b><u>Basecase (seasonal):</u></b>
                    {basecase_seasonal_html}
                    <br><hr><br>
                    <b><u>Basecase (year-on-year):</u></b>
                    <br>
                    {yoy_html}
                    <br><hr><br>
                    <b><u>Notes (continued):</u></b>
                    <br>Our EU perimeter is defined as {','.join(countries)}
                    <br>NWE is a "dummy" country and used for displaying aggregated timeseries into our perimeter (such NCS forecast from EA).
                    <br>Current display params (history/forward): Days {days_history}/{days_forward}, Months {months_history}/{months_forward}
                    <br>In the daily views, T0 shows nominations where available.
                    <br>StB = "Storage To Balance" and is calculated as net of all supply (positive) & demand (negative) elements (excl Storage).
                    <br>"Storage" is the actual observed storage action with "Imbalance" being the difference vs StB.
                    <br>Storage data is subject to 1-2 day lag (so T-1 is likely to be missing).
                    <br>All historical data is sourced from Commodity Essentials, using {ce_timestamp_prefix} {ce_saved_date_utc.strftime('%H:%M%p %d-%b')} snapshot.
                    <br>German NonLDZ demand: data is published as a single aggregated value until Kpler Power feed is live (hence "NonLDZ" value below).
                    <br>NCS: total may look low but <i>excludes</i> flows to DK (eg Nybro) which is typically ~25 of 29mcm/d capa.
                    <br>The full EA European perimeter has a storage capacity of {ea_storage_capa_eu}bcm.
                    <br>All units are mcm/d (except "{ea_full}" summary table which is bcm)
                """    

    return email_body, balance_for_csv
            


def get_provider_forecast_dt(provider, ref_dates):
    
    # Quick function to get latest available forecast date wrt to the supplied ref_date
    dq = DataQuery(logintype='prod')
    
    # TODO: this is a bit dangerous! (as hard coded IDs used below)
    # TODO: this caused an issue in mid Mar-25 when EA updated their metadata values which triggered us to write to new data_ids in our database
    if provider=='EA':
        # did = 2524 # UK LDZ forecast (original)
        # did = 3307 # UK LDZ forecast (new, post Mar-25)
        did = 3488 # UK LDZ forecast (changed again in Jun-25)
    elif provider=='Platts':
        did = 2951 # UK LDZ forecast
    
    # Get all instances
    instances = dq.get_instances(did, 'eu_data_datavalue')
    
    # Filter using the ref_date
    res = {}
    for ref_date in ref_dates:
        latest_instance = max(instances[instances.report_date<=ref_date].report_date.values)
        res[ref_date] = latest_instance
           
    return res


