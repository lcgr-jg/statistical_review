import base64
import io
import os
import logging
import traceback
import configparser
import platform

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email

from util import generate_report

REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/eu_gas_balances_v2')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'eu_gas_balances_v2.cfg')
receivers = config.get('ReportSettings','receivers')
receivers_csv = config.get('ReportSettings','receivers_csv')
error_receivers = config.get('ReportSettings','error_receivers')

days_history = config.getint('ReportSettings','days_history')
days_forward = config.getint('ReportSettings','days_forward')
months_history = config.getint('ReportSettings','months_history')
months_forward = config.getint('ReportSettings','months_forward')
seasons_history = config.getint('ReportSettings','seasons_history')
seasons_forward = config.getint('ReportSettings','seasons_forward')
countries = config.get('ReportSettings','countries')
scenarios = config.get('ReportSettings','scenarios')

use_balance_cache = config.getboolean('ReportSettings','use_balance_cache')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_eu_gas_balances_v2.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    receivers_csv = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'
    
    # TODO: for now when running locally we can't use the s3 cache
    use_balance_cache = True

    
# Define our EU/north west europe zone perimeter
countries = countries.split(',')

# Define which scenarios we want to display
scenarios = scenarios.split(',')

email_subject = f"EU Gas Balances {datetime.now().strftime('%d-%b-%Y')}"

try:
    logging.info(f"Generating {email_subject} report for countries:{','.join(countries)}")
    
    # Generate report content
    report, balance_for_csv = generate_report(countries, days_history, days_forward, months_history, months_forward, seasons_history, seasons_forward, 2, scenarios, use_balance_cache)
    
    # Send report
    send_email(receivers, email_subject, report)
    logging.info('Main report sent')
    
    # Send attachment as csv to reduced audience
    buffer = io.BytesIO()
    balance_for_csv.to_csv(buffer, index=True)
    buffer.seek(0)
    balance_encoded = base64.b64encode(buffer.getvalue()).decode('utf-8')
    attachment = {'content': balance_encoded,
                  'filename': f'{stoday}_basecase.csv',
                  }
    send_email(receivers_csv, f"{email_subject}: CSV extract", 'Latest EU Balance Basecase monthly extract is attached.', attachment=attachment)
    logging.info('CSV extract sent')
    
except Exception:
    logging.error(f"Failed generating report for {','.join(countries)}")
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))
        
        