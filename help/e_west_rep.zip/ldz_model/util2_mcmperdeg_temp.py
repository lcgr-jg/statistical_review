
import logging
import numpy as np
import pandas as pd
import statsmodels.api as sm

from datetime import datetime, timedelta
from tqdm import tqdm

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.interfaces.bloomberg import bsrch_handler, BBGQuery
from jain_commods.core.interfaces.sqldb import DataLoader




def get_ce_demand(ce_user, ce_pass, countries):
    
    
    # Hard coded list of what we require
    # NB: if we update countries then we need to update this dict
    demand_asset_ids = {'BE': 665,
                        'DE_H': 2965,
                        'DE_L': 2967,
                        'FR': 192,
                        'GB': 54,
                        'IT': 1803,
                        'NL': 209,
                        }
    
    # Build str of assets ids
    asset_ids = ','.join([str(demand_asset_ids[c]) for c in countries])
    
    
    #  Query CE
    ce = CElink(ce_user,ce_pass)
    df_ldz_demand = ce.eugasopdata(assets=asset_ids,unit='mcm',dateFrom=2014)
    
    # Tidy up
    df_ldz_demand = df_ldz_demand.dropna()
    df_ldz_demand.index = pd.to_datetime(df_ldz_demand['Date'])
    df_ldz_demand = df_ldz_demand.drop(columns=['DateExcel','Date'])
    
    # Rename columns (NB: CE returns series IDs as column names but is preserved from original query)
    df_ldz_demand.columns = demand_asset_ids.keys()
    
    # Add total
    df_ldz_demand['Total'] = df_ldz_demand.sum(axis=1)
    
    return df_ldz_demand


def _clean(df):
    df = df.iloc[:, 1:]
    df = df.set_index('Location Time')
    df = df.replace('', np.nan).astype(float)
    idx = df.columns.to_frame(False)
    idx.columns = ['field']

    df.columns = pd.MultiIndex.from_frame(idx)
    return df


def get_temp_data_actuals(country):
    

    # Open connection and start session
    session = BBGQuery(p_on_server=True)._start_session_server()
    # Data container for each iteration
    df = pd.DataFrame()

    # Weather forecast example
    session.openService('//blp/exrsvc')
    exrService = session.getService('//blp/exrsvc')
    request = exrService.createRequest('ExcelGetGridRequest')

    request.set('Domain', 'COMDTY:WEATHER')
    overrides = request.getElement("Overrides")

    yday = (datetime.today().date()-pd.DateOffset(days=1)).strftime('%Y-%m-%d')
    
    # Define config
    override_configs = [
        ('provider', 'wsi'),
        ('location', country),
        ('target_start_date', '2021-01-05'),
        # ('target_start_date', '2018-03-21'),
        ('frequency', 'DAILY'),
        ('model', 'ACTUALS'),
        ('target_end_date', yday),
        ('location_time', 'TRUE'),
        ('fields', 'TEMPERATURE')
    ]
    
    # Apply overrides
    overrides = request.getElement("Overrides")
    for name, value in override_configs:
        override = overrides.appendElement()
        override.setElement("name", name)
        override.setElement("value", value)        

    session.sendRequest(request)

    # Loop through the results and put them into a DataFrame
    try:
        while (True):
            event = session.nextEvent(500)
            if event.eventType() != bsrch_handler.BLP_RESPONSE and \
                    event.eventType() != bsrch_handler.BLP_PARTIAL_RESPONSE:
                continue
            for msg in event:
                sub = bsrch_handler.getBSRCHData(msg)
                if len(sub) > 0:
                    sub = _clean(sub)
                    df = pd.concat([df, sub], axis=1)
            if event.eventType() == bsrch_handler.BLP_RESPONSE:
                break
    except Exception as e:
        print(f"An error occurred: {e}")

    # Stop the session
    session.stop()
    
    # Tidy up the output
    df.columns = [f"{country}_Temp"]
    df.index = pd.to_datetime(df.index,utc=True).tz_localize(None)
    df.index = df.index.normalize()

    return df


def _clean_forecast(df, pub_date):
    df = df.iloc[:, 1:]
    df = df.set_index('Location Time')
    df = df.replace('', np.nan).astype(float)
    idx = df.columns.to_frame(False)
    idx.columns = ['field']
    idx['pub_date'] = pub_date
    df.columns = pd.MultiIndex.from_frame(idx)
    
    # Fix on 17th feb to remove time zone info (was causing issues for UK as we entered DST and +01:00 in the string)
    df.index = df.index.str[:-6]
    df.index = pd.to_datetime(df.index)
    
    return df


def _pub_dates(model_type):
    
    # Consider EC46 publication timing (ie approx 5pm the previous day)
    offset = 0 if model_type=='ENSEMBLE_MEAN' else 1 
    
    # On a monday we want to check vs friday
    if datetime.now().weekday() == 0:
        days_back = 3
    else:
        days_back = 1
    
    # Construct forecast dates we want to query
    current = pd.to_datetime(datetime.now()).normalize() - timedelta(days=offset)
    previous = current - timedelta(days=days_back)
    
    return [current, previous]


def get_temp_data_forecast(country, model='ECMWF', model_type='ENSEMBLE_MEAN'):
    pub_dates = _pub_dates(model_type)

    # Open connection and start session
    session = BBGQuery(p_on_server=True)._start_session_server()

    # Data container for each iteration
    df = pd.DataFrame()

    for pub_date in tqdm(pub_dates):
        print(f"processing {pub_date}")

        # Weather forecast example
        session.openService('//blp/exrsvc')
        exrService = session.getService('//blp/exrsvc')
        request = exrService.createRequest('ExcelGetGridRequest')

        request.set('Domain', 'COMDTY:WEATHER')
        overrides = request.getElement("Overrides")       
        
        # Define config
        override_configs = [
                            ('provider', 'wsi'),
                            ('location', country),
                            ('publication_date', pub_date.strftime('%Y-%m-%dT%H:00:00')),
                            ('frequency', 'DAILY'),
                            ('model', model),
                            ('type', model_type),
                            ('location_time', 'TRUE'),
                            ('fields', 'TEMPERATURE'),
                            ]
        
        # Apply overrides
        overrides = request.getElement("Overrides")
        for name, value in override_configs:
            override = overrides.appendElement()
            override.setElement("name", name)
            override.setElement("value", value)       
        

        session.sendRequest(request)

        # Loop through the results and put them into a DataFrame
        try:
            while (True):
                event = session.nextEvent(500)
                if event.eventType() != bsrch_handler.BLP_RESPONSE and \
                        event.eventType() != bsrch_handler.BLP_PARTIAL_RESPONSE:
                    continue
                for msg in event:
                    sub = bsrch_handler.getBSRCHData(msg)
                    if len(sub) > 0:
                        sub = _clean_forecast(sub, pub_date)
                        df = pd.concat([df, sub], axis=1)
                if event.eventType() == bsrch_handler.BLP_RESPONSE:
                    break
        except Exception as e:
            print(f"An error occurred: {e}")
            break

    # Stop the session
    session.stop()
    
    # Tidy up the output
    df.index = pd.to_datetime(df.index,utc=True).tz_localize(None)
    df.index = df.index.normalize()

    return df



def ldz_demand_temp_regression(df_demand, demand_column, df_temp, temp_column, degree=2):
    """
    Perform polynomial regression of LDZ demand as a function of temperature with month-specific coefficients.

    Parameters:
    df_demand (pd.DataFrame): DataFrame containing LDZ demand data.
    demand_column (str): Column name in df_demand representing LDZ demand.
    df_temp (pd.DataFrame): DataFrame containing temperature data.
    temp_column (str): Column name in df_temp representing temperatures.
    degree (int): The degree of the polynomial regression. Default is 2 for quadratic regression.

    Returns:
    dict: A dictionary of regression coefficients, with different coefficients for each month.
    """

    # Ensure both DataFrames have datetime indices
    if not pd.api.types.is_datetime64_any_dtype(df_demand.index):
        df_demand.index = pd.to_datetime(df_demand.index)
    if not pd.api.types.is_datetime64_any_dtype(df_temp.index):
        df_temp.index = pd.to_datetime(df_temp.index)

    # Align the two DataFrames on the datetime index
    df = pd.merge(df_demand[[demand_column]], df_temp[[temp_column]], left_index=True, right_index=True)

    # Create a new column for the month (this will help apply different coefficients per month)
    df['month'] = df.index.month

    # Initialize a dictionary to store the regression coefficients
    monthly_coefficients = {}

    # Perform polynomial regression for each month
    for month, group in df.groupby('month'):
        # Extract demand (y) and temperature (X) for the current month
        y = group[demand_column]
        X = group[temp_column]

        # Manually create polynomial features (e.g., temperature, temperature^2, etc.)
        X_poly = np.column_stack([X ** i for i in range(1, degree + 1)])

        # Add a constant to the polynomial features for the intercept
        X_poly_with_constant = sm.add_constant(X_poly)

        # Fit the polynomial regression model
        model = sm.OLS(y, X_poly_with_constant).fit()

        # Extract coefficients (including intercept)
        intercept = model.params[0]
        poly_coeffs = model.params[1:].tolist()  # List of polynomial coefficients

        # Store coefficients for the current month
        monthly_coefficients[f'month_{month}'] = {
            'intercept': intercept,
            'poly_coeffs': poly_coeffs
        }

    return monthly_coefficients



def handle_df(df, model_type='ENSEMBLE_MEAN'):
        
    temp = df.xs('Temperature (°C)', axis=1, level='field')    
    # Add delta
    temp['Delta'] = temp.iloc[:, 0] - temp.iloc[:, 1]
    
    return temp


def forecast_ldz_demand(temp_series, forecast_coeffs, degree=2):
    """
    Forecast LDZ demand based on a Series of temperatures with a datetime index and polynomial coefficients.

    Parameters:
    temp_series (pd.Series): Series of temperatures with a datetime index.
    forecast_coeffs (dict): Coefficients from the regression model, including intercept and polynomial terms.
    degree (int): The degree of the polynomial regression (default is 2 for quadratic).

    Returns:
    pd.Series: Forecasted LDZ gas demand as a Series with the same index as temp_series.
    """

    # Initialize an empty list to store forecasted demand
    forecasted_demand = []
    
    # Define our weekday/weekend weighting. Notes:
        # for simplicity we apply just a single weighting value per month irrespective of country
        # values below calculated across a 10yr mean for all our 7 countries (ignores post-2022 demand destrucion/change of regime etc)
        # in future we should apply different weightings per country based on observed behaviour
    weightings = {1: 0.94,
                  2: 0.93,
                  3: 0.92,
                  4: 0.90,
                  5: 0.89,
                  6: 0.83,
                  7: 0.82,
                  8: 0.86,
                  9: 0.86,
                  10: 0.89,
                  11: 0.92,
                  12: 0.94,
                  }
    

    temp_series.index=pd.to_datetime(temp_series.index, utc = True).tz_localize(None).normalize()

    # Loop over the temperature Series
    for date, temp in temp_series.items():
        # Extract the month from the datetime index
        month = date.month

        # Get the intercept and polynomial coefficients for the specific month
        if f'month_{month}' in forecast_coeffs:
            intercept = forecast_coeffs[f'month_{month}']['intercept']
            poly_coeffs = forecast_coeffs[f'month_{month}']['poly_coeffs']
        else:
            # If no coefficients for this month, skip or set default values
            intercept = 0
            poly_coeffs = [0] * degree

        # Initialize forecast with the intercept
        forecast = intercept

        # Add polynomial terms to the forecast (e.g., temp, temp^2, etc.)
        for i, coeff in enumerate(poly_coeffs):
            forecast += coeff * (temp ** (i + 1))  # i+1 because i=0 is temp^1, i=1 is temp^2, etc.
            
        # Apply weekend/weekday weighting using lookup defined above
        is_weekend = date.weekday() >= 5
        weighting = weightings[month] if is_weekend else 1
        forecast *= weighting

        # Append the forecasted value
        forecasted_demand.append(forecast)

    # Return the forecasted values as a Series with the same index as temp_series
    return pd.Series(forecasted_demand, index=temp_series.index)





def get_report(ce_user, ce_pass, countries=['BE','DE_H','DE_L','FR','GB','IT','NL']):
    
    ce_user='john.morley@jainglobal.com'
    ce_pass = 'Knockers99!'
    
    # Load historical LDZ demand from CE
    logging.info('Querying CE: gas demand actuals...')
    df_ldz_demand = get_ce_demand(ce_user, ce_pass, countries)
    
    
    # Load wx actuals from BBG
    logging.info('Querying BBG: temp actuals...')
    wx_historic = {}
    for c in countries:
        country = 'DE' if c == 'DE_H' else c
        if country != 'DE_L':
            wx_historic[country] = get_temp_data_actuals(country)


    # Define model training range
    start_dt = datetime(2021,10,1)
    end_dt = datetime(2024,3,1)

    
    # Perform polynomial regression, creating monthly coeffs  
    monthly_coeffs = {}
    for c in countries:
        # Define which columns we require in the source data
        demand_col = c
        temp_col = 'DE' if c in ['DE_H','DE_L'] else c
        # Perform regression
        monthly_coeffs[c] = ldz_demand_temp_regression(df_ldz_demand[start_dt:end_dt],
                                                       demand_col,
                                                       wx_historic[temp_col][start_dt:end_dt],
                                                       f"{temp_col}_Temp",
                                                       )

    # Get current & previous weather forecasts
    logging.info('Querying BBG: ECENS, EC46 & GFSENS weather forecasts...')
    wx_forecast = {}
    for c in countries:
        country = 'DE' if c == 'DE_H' else c
        if country != 'DE_L':
            ecens = handle_df(get_temp_data_forecast(country))
            ec46 = handle_df(get_temp_data_forecast(country, model_type='MONTH_AHEAD'), model_type='MONTH_AHEAD')
            gfsens = handle_df(get_temp_data_forecast(country, model='GFS'))
            # Capture forecasts in dict
            wx_forecast[country] = {'ecens': ecens,
                                    'ec46': ec46,
                                    'gfsens': gfsens,
                                    }
            
    
            
    ############# Temporary stuff to see LDZ delta/per degC in april
    
    
    
    # set apr
    month = 4
    
    # get avg monthly temp per country from actuals
    avg_temps = {}
    for c,temps in wx_historic.items():
        df = temps.copy()
        df['month'] = df.index.month
        avg_temps[c] = df[df['month']==month].values.mean()
        
    # get avg apr forecast from ec46
    ec46_avg = {}
    reqd_col = pd.Timestamp(2025,3,20)
    for c,temps in wx_forecast.items():
        df = temps['ec46'].copy()
        df['month'] = df.index.month
        ec46_avg[c] =df[df['month']==month][reqd_col].values.mean()
        
    
    import numpy as np
    import matplotlib.pyplot as plt
    
    def calculate_effective_slope(model_coeffs, month, temperature):
        """
        Calculate the effective slope (rate of change) of gas demand with respect to
        temperature at a specific temperature point for a given month.
        
        Parameters:
        model_coeffs (dict): Dictionary containing the polynomial model coefficients by month
        month (int): Month (1-12)
        temperature (float): Temperature point at which to calculate the slope
        
        Returns:
        float: Effective slope (dDemand/dTemperature) at the specified temperature
        """
        # Get the coefficients for the specified month
        month_key = f"month_{month}"
        if month_key not in model_coeffs:
            raise ValueError(f"No coefficients available for {month_key}")
        
        month_coeffs = model_coeffs[month_key]
        poly_coeffs = month_coeffs["poly_coeffs"]
        
        # Based on the regression function, poly_coeffs is ordered as:
        # poly_coeffs[0] = coefficient for x^1 (first-order term)
        # poly_coeffs[1] = coefficient for x^2 (second-order term)
        linear_coeff = poly_coeffs[0]
        quadratic_coeff = poly_coeffs[1] 
        
        # For a polynomial of form: intercept + linear_coeff*x + quadratic_coeff*x^2
        # The derivative (slope) is: linear_coeff + 2*quadratic_coeff*x
        effective_slope = linear_coeff + 2 * quadratic_coeff * temperature
        
        return effective_slope
    
    def get_polynomial_demand(model_coeffs, month, temperature):
        """
        Calculate the predicted demand at a specific temperature for a given month.
        """
        month_key = f"month_{month}"
        month_coeffs = model_coeffs[month_key]
        poly_coeffs = month_coeffs["poly_coeffs"]
        intercept = month_coeffs["intercept"]
        
        # Based on the regression function:
        # poly_coeffs[0] = coefficient for x^1 (first-order term)
        # poly_coeffs[1] = coefficient for x^2 (second-order term)
        linear_coeff = poly_coeffs[0]
        quadratic_coeff = poly_coeffs[1]
        
        # Calculate demand: intercept + linear_coeff*x + quadratic_coeff*x^2
        return intercept + linear_coeff * temperature + quadratic_coeff * temperature**2
    
    def plot_linearization(country, model_coeffs, month, temperature, temp_range=10):
        """
        Plot the polynomial curve and its linearized approximation at a specific temperature.
        """
        month_key = f"month_{month}"
        month_coeffs = model_coeffs[month_key]
        
        # Calculate the effective slope at the given temperature
        slope = calculate_effective_slope(model_coeffs, month, temperature)
        
        # Calculate the demand at the given temperature
        demand_at_temp = get_polynomial_demand(model_coeffs, month, temperature)
        
        # Generate a range of temperatures for plotting
        temps = np.linspace(temperature - temp_range/2, temperature + temp_range/2, 100)
        
        # Calculate demands for the polynomial curve
        poly_demands = [get_polynomial_demand(model_coeffs, month, t) for t in temps]
        
        # Calculate the y-intercept for the linearized function (y = mx + c)
        linear_intercept = demand_at_temp - slope * temperature
        
        # Calculate demands for the linearized curve
        linear_demands = [slope * t + linear_intercept for t in temps]
        
        # Create the plot
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot the polynomial curve
        ax.plot(temps, poly_demands, 'b-', linewidth=2, label='Polynomial Model')
        
        # Plot the linearized approximation
        ax.plot(temps, linear_demands, 'r--', linewidth=2, 
                label=f'Linearized (Slope = {slope:.3f})')
        
        # Mark the specific temperature point
        ax.plot(temperature, demand_at_temp, 'ko', markersize=8,
                label=f'Temperature = {temperature}°C')
        
        # Add a grid, labels, and legend
        ax.grid(True, linestyle='--', alpha=0.7)
        ax.set_xlabel('Temp (°C)', fontsize=12)
        ax.set_ylabel('mcm', fontsize=12)
        ax.set_title(f'{country} LDZ Demand Model for Month {month}\nPolynomial vs. Linearized Approximation', 
                    fontsize=14)
        ax.legend(fontsize=10)
        
        # Add text with the equation of the linearized model
        equation_text = f'Linearized model: y = {slope:.3f}x + {linear_intercept:.3f}'
        ax.text(0.02, 0.95, equation_text, transform=ax.transAxes, 
                fontsize=12, bbox=dict(facecolor='white', alpha=0.8))
        
        plt.tight_layout()
        return fig
    

    
    # call above functions for each country to create plot and summary stats
    slope_output = {}
    for country in monthly_coeffs.keys():
        
        cc = 'DE' if country in ['DE_H','DE_L'] else country
        
        model_coefficients = monthly_coeffs[country]
        
        # temperature = avg_temps[cc]
        temperature = ec46_avg[cc]
        
        month = 4
        
        # Calculate demand and slope
        demand = get_polynomial_demand(model_coefficients, month, temperature)
        slope = calculate_effective_slope(model_coefficients, month, temperature)
        
        # Calculate demand at temperature+1 to verify slope
        demand_plus_1 = get_polynomial_demand(model_coefficients, month, temperature+1)
        actual_change = demand_plus_1 - demand
        
        print(f"{country} at {temperature}°C in April:")
        print(f"  - Polynomial model: y = {model_coefficients['month_4']['intercept']} + ({model_coefficients['month_4']['poly_coeffs'][0]})x + ({model_coefficients['month_4']['poly_coeffs'][1]})x²")
        print(f"  - Effective slope (derivative): {slope:.3f} units per degree")
        print(f"  - Predicted demand at {temperature}°C: {demand:.3f} units")
        print(f"  - Predicted demand at {temperature+1}°C: {demand_plus_1:.3f} units")
        print(f"  - Actual change for 1°C increase: {actual_change:.3f} units")
        
        
        slope_output[country] = actual_change
        
        # Generate the plot
        fig = plot_linearization(country, model_coefficients, month, temperature)
        plt.show()
                        
    
    # get diffs between average temps versus current ec46
    diffs = {}
    for c in ec46_avg.keys():
        diffs[c] = ec46_avg[c] - avg_temps[c]
    
    
    print(f"Average of diffs across all countries: {np.average(list(diffs.values()))}")
        
    # Create dataframes to make it easy to export
    df_diffs = pd.DataFrame.from_dict(diffs, orient='index')
    df_slope_output = pd.DataFrame.from_dict(slope_output, orient='index')
    df_slope_output.to_clipboard()

           
    
    
    ############### END OF TEMPORARY CODE
            
            
            
            
            
            
            
            
            
            
            


    # Generate demand forecasts
    logging.info('Producing demand forecasts...')
    demand_forecast = {}
    for c in countries:
        # Process each country
        fcast_c = 'DE' if c in ['DE_H','DE_L'] else c
        res = {}
        for model in ['ecens','ec46', 'gfsens']:
            # Create forecasts for each wx model
            curr = forecast_ldz_demand(wx_forecast[fcast_c][model].iloc[:, 0], monthly_coeffs[c]).dropna()
            prev = forecast_ldz_demand(wx_forecast[fcast_c][model].iloc[:, 1], monthly_coeffs[c]).dropna()
            curr.name = c
            prev.name = c
            res[model] = {'curr': curr, 'prev': prev,}
        # Capture output
        demand_forecast[c] = res
        
    
    # Sum demand forecasts and get deltas
    ecens_total_curr = sum([demand_forecast[c]['ecens']['curr'] for c in countries])
    ecens_total_prev = sum([demand_forecast[c]['ecens']['prev'] for c in countries])
    ecens_delta = ecens_total_curr - ecens_total_prev    
    ec46_total_curr = sum([demand_forecast[c]['ec46']['curr'] for c in countries])
    ec46_total_prev = sum([demand_forecast[c]['ec46']['prev'] for c in countries])
    ec46_delta = ec46_total_curr - ec46_total_prev
    
    gfsens_total_curr = sum([demand_forecast[c]['gfsens']['curr'] for c in countries])
    gfsens_total_prev = sum([demand_forecast[c]['gfsens']['prev'] for c in countries])
    gfsens_delta = gfsens_total_curr - gfsens_total_prev    
    
    
    # Get DE temp deltas
    ecens_de_temp_delta = wx_forecast['DE']['ecens']['Delta']
    ec46_de_temp_delta = wx_forecast['DE']['ec46']['Delta']
    gfsens_de_temp_delta = wx_forecast['DE']['gfsens']['Delta']
    
    # Construct summary table labels
    ens_pub_dates = _pub_dates('ENSEMBLE_MEAN')
    ec46_pub_dates = _pub_dates('MONTH_AHEAD')
    now = pd.to_datetime(datetime.now()).normalize()
    ens_labels = [f"D{(dt - now).days}_00z Demand" for dt in ens_pub_dates]
    ec46_labels = [f"D{(dt - now).days}_00z Demand" for dt in ec46_pub_dates]
    
    # Assign names to series for display df
    ecens_total_curr.name = ens_labels[0]
    ecens_total_prev.name = ens_labels[1]
    ecens_delta.name = 'Demand Delta'
    ecens_de_temp_delta.name = 'DE Temp Delta'
    
    ec46_total_curr.name = ec46_labels[0]
    ec46_total_prev.name = ec46_labels[1]
    ec46_delta.name = 'Demand Delta'
    ec46_de_temp_delta.name = 'DE Temp Delta'
    
    gfsens_total_curr.name = ens_labels[0]
    gfsens_total_prev.name = ens_labels[1]
    gfsens_delta.name = 'Demand Delta'
    gfsens_de_temp_delta.name = 'DE Temp Delta'
    
    # Construct summary dfs
    ecens_summary = pd.concat([ecens_total_curr, ecens_total_prev, ecens_delta, ecens_de_temp_delta], axis=1).dropna()
    ec46_summary = pd.concat([ec46_total_curr, ec46_total_prev, ec46_delta, ec46_de_temp_delta], axis=1).dropna()
    gfsens_summary = pd.concat([gfsens_total_curr, gfsens_total_prev, gfsens_delta, gfsens_de_temp_delta], axis=1).dropna()
    
    # Add total rows    
    ecens_summary.loc['Total'] = ecens_summary.sum()
    ec46_summary.loc['Total'] = ec46_summary.sum()
    gfsens_summary.loc['Total'] = gfsens_summary.sum()
    
    # Cheat and set the DE Temp Delta as str (ready for display)
    ecens_summary['DE Temp Delta'] = [f'{v:+.2f}' for v in ecens_summary['DE Temp Delta'].values]
    ec46_summary['DE Temp Delta'] = [f'{v:+.2f}' for v in ec46_summary['DE Temp Delta'].values]
    gfsens_summary['DE Temp Delta'] = [f'{v:+.2f}' for v in gfsens_summary['DE Temp Delta'].values]
    
    # Save results to db
    logging.info("Saving forecasts to the database...")
    # Process each countries forecast
    dataitems = []
    i=0
    for c in demand_forecast.keys():
        geography1 = c.split('_')[0]
        for model in ['ecens','ec46','gfsens']:
            # Select the relevant forecast (we only save the current one)
            df = demand_forecast[c][model]['curr'].to_frame()
            
            # Prepare df for saving
            df.index.name = 'date'
            df = df.rename(columns={c:'value'})
            df = df.reset_index()
            
            # Set the report_date
            report_date = ens_pub_dates[0] if model in ['ecens','gfsens'] else ec46_pub_dates[0]
            df['report_date'] = report_date
            
            # Define metadata
            md = {'commodity': 'GAS',
                    'geography1': geography1,
                    'category1': 'Demand',
                    'category2': 'LDZ',
                    'category3': c,
                    'category4': model.upper(),
                    'measurement_type': 'FORECAST',
                    'unit': 'mcm',
                    'frequency': 'Daily',
                    'source1': 'JainGlobal',
                    'instances': 'Multi',
                    'data_table': 'eu_data_datavalue',
                    'description': f"{c} {model.upper()} Demand Forecast mcm",
                    }
            # Construct payload
            dataitems.append({'id': i, 
                              'metadata': md,
                              'data': df,
                              })
            # Increment counter
            i+=1
        
    # Save to database
    dl = DataLoader(logintype='prod') 
    dl.process_data(dataitems)
    
    
    return ecens_summary, ec46_summary, gfsens_summary