
"""
Email report to calculate LDZ gas demand for NWE and send results

"""


import logging
import traceback
import configparser
import platform

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.util.htmlutils import df2html

from util2 import get_report


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/ldz_model')


# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'ldz_model.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

ce_user = config.get('CEConfig','user')
ce_pass = config.get('CEConfig','pass')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_ldz_model.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'


email_subject = datetime.today().strftime('%Y-%m-%d') + " Weather Delta"

    
try:
    logging.info('Generating report')  
    
    # Generate report data
    data_ecens, data_ec46, data_gfsens = get_report(ce_user, ce_pass)
    
    data_ecens_html = df2html(data_ecens, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
    data_ec46_html = df2html(data_ec46, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
    data_gfsens_html = df2html(data_gfsens, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
    
    # Get total diffs
    diff_ecens = data_ecens.loc['Total','Demand Delta']
    diff_ec46 = data_ec46.loc['Total','Demand Delta']
    diff_gfsens = data_gfsens.loc['Total','Demand Delta']
    
    # Construct email subject
    email_subject_change = f"{email_subject}: ECENS {diff_ecens:+,.0f}mcm {data_ecens.columns[0].replace(' Demand', '')} vs {data_ecens.columns[1].replace(' Demand', '')} (GFSENS {diff_gfsens:+,.0f}mcm)"
    
    # Construct email body
    email_body = f"""<p><b>EC ENS 00Z Total LDZ demand forecast for DE, FR, UK, IT, NL, BE:</b>
                     <br>
                     {data_ecens_html}
                     <br>
                     <hr>
                     <p><b>GFS ENS 00Z Total LDZ demand forecast for DE, FR, UK, IT, NL, BE:</b>
                     <br>
                     {data_gfsens_html}
                     <br>
                     <hr>                     
                     <p><b>EC46 00Z Total LDZ demand forecast for DE, FR, UK, IT, NL, BE:</b>
                     {data_ec46_html}
                     <br>
                     <br><b>Notes:</b>
                     <br>Demand values mcm, temp deg C.
                     <br>Latest 00z EC Ensemble Mean, EC46 and GFS Ensemble Mean forecasts are all queried from Bloomberg.
                     <br>For the EC46, this report shows the previous days forecast.
                     <br>Historic LDZ demand actuals for the regression are queried from Commodity Essentials.
                    """
    
    # Send email
    send_email(receivers, 
               email_subject_change, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')    
    
    
    logging.info('Report sent')
    

except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))        