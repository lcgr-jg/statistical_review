import logging
import numpy as np
import pandas as pd
import statsmodels.api as sm

from datetime import datetime, timedelta
from tqdm import tqdm

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.interfaces.bloomberg import bsrch_handler, BBGQuery
from jain_commods.core.interfaces.sqldb import DataLoader




def ldz_demand_temp_regression(df_demand, demand_column, df_temp, temp_column, degree=2):
    """
    Perform polynomial regression of LDZ demand as a function of temperature with month-specific coefficients.

    Parameters:
    df_demand (pd.DataFrame): DataFrame containing LDZ demand data.
    demand_column (str): Column name in df_demand representing LDZ demand.
    df_temp (pd.DataFrame): DataFrame containing temperature data.
    temp_column (str): Column name in df_temp representing temperatures.
    degree (int): The degree of the polynomial regression. Default is 2 for quadratic regression.

    Returns:
    dict: A dictionary of regression coefficients, with different coefficients for each month.
    """

    # Ensure both DataFrames have datetime indices
    if not pd.api.types.is_datetime64_any_dtype(df_demand.index):
        df_demand.index = pd.to_datetime(df_demand.index)
    if not pd.api.types.is_datetime64_any_dtype(df_temp.index):
        df_temp.index = pd.to_datetime(df_temp.index)

    # Align the two DataFrames on the datetime index
    df = pd.merge(df_demand[[demand_column]], df_temp[[temp_column]], left_index=True, right_index=True)

    # Create a new column for the month (this will help apply different coefficients per month)
    df['month'] = df.index.month

    # Initialize a dictionary to store the regression coefficients
    monthly_coefficients = {}

    # Perform polynomial regression for each month
    for month, group in df.groupby('month'):
        # Extract demand (y) and temperature (X) for the current month
        y = group[demand_column]
        X = group[temp_column]

        # Manually create polynomial features (e.g., temperature, temperature^2, etc.)
        X_poly = np.column_stack([X ** i for i in range(1, degree + 1)])

        # Add a constant to the polynomial features for the intercept
        X_poly_with_constant = sm.add_constant(X_poly)

        # Fit the polynomial regression model
        model = sm.OLS(y, X_poly_with_constant).fit()

        # Extract coefficients (including intercept)
        intercept = model.params[0]
        poly_coeffs = model.params[1:].tolist()  # List of polynomial coefficients

        # Store coefficients for the current month
        monthly_coefficients[f'month_{month}'] = {
            'intercept': intercept,
            'poly_coeffs': poly_coeffs
        }

    return monthly_coefficients



def _clean(df):
    df = df.iloc[:, 1:]
    df = df.set_index('Location Time')
    df = df.replace('', np.nan).astype(float)
    idx = df.columns.to_frame(False)
    idx.columns = ['field']

    df.columns = pd.MultiIndex.from_frame(idx)
    return df

def _clean_forecast(df, pub_date):
    df = df.iloc[:, 1:]
    df = df.set_index('Location Time')
    df = df.replace('', np.nan).astype(float)
    idx = df.columns.to_frame(False)
    idx.columns = ['field']
    idx['pub_date'] = pub_date
    df.columns = pd.MultiIndex.from_frame(idx)
    return df


def get_temp_data_actuals(country):
    
    yday=datetime.today().date()-pd.DateOffset(days=1)
    yday=yday.strftime('%Y-%m-%d')


    # Open connection and start session
    session = BBGQuery(p_on_server=True)._start_session_server()
    # Data container for each iteration
    df = pd.DataFrame()

    # Weather forecast example
    session.openService('//blp/exrsvc')
    exrService = session.getService('//blp/exrsvc')
    request = exrService.createRequest('ExcelGetGridRequest')

    request.set('Domain', 'COMDTY:WEATHER')
    overrides = request.getElement("Overrides")

    # Set Weather Provider
    override1 = overrides.appendElement()
    override1.setElement("name", "provider")
    override1.setElement("value", "wsi")

    # Set locations
    override2 = overrides.appendElement()
    override2.setElement("name", "location")
    override2.setElement("value", country)

    # Set model with adjusted date
    override3 = overrides.appendElement()
    override3.setElement("name", "target_start_date")
    override3.setElement("value", '2021-01-05')

    # Set frequency
    override4 = overrides.appendElement()
    override4.setElement("name", "frequency")
    override4.setElement("value", "DAILY")

    # Set model
    override5 = overrides.appendElement()
    override5.setElement("name", "model")
    override5.setElement("value", "ACTUALS")

    # Set model with adjusted date
    override6 = overrides.appendElement()
    override6.setElement("name", "target_end_date")
    override6.setElement("value", yday)

    # Set location_time
    override7 = overrides.appendElement()
    override7.setElement("name", "location_time")
    override7.setElement("value", "TRUE")

    # Set return fields
    override8 = overrides.appendElement()
    override8.setElement("name", "fields")
    override8.setElement("value", "TEMPERATURE")

    session.sendRequest(request)

    # Loop through the results and put them into a DataFrame
    try:
        while (True):
            event = session.nextEvent(500)
            if event.eventType() != bsrch_handler.BLP_RESPONSE and \
                    event.eventType() != bsrch_handler.BLP_PARTIAL_RESPONSE:
                continue
            for msg in event:
                sub = bsrch_handler.getBSRCHData(msg)
                if len(sub) > 0:
                    sub = _clean(sub)
                    df = pd.concat([df, sub], axis=1)
            if event.eventType() == bsrch_handler.BLP_RESPONSE:
                break
    except Exception as e:
        print(f"An error occurred: {e}")

    # Stop the session
    session.stop()

    return df


def forecast_ldz_demand(temp_series, forecast_coeffs, degree=2):
    """
    Forecast LDZ demand based on a Series of temperatures with a datetime index and polynomial coefficients.

    Parameters:
    temp_series (pd.Series): Series of temperatures with a datetime index.
    forecast_coeffs (dict): Coefficients from the regression model, including intercept and polynomial terms.
    degree (int): The degree of the polynomial regression (default is 2 for quadratic).

    Returns:
    pd.Series: Forecasted LDZ gas demand as a Series with the same index as temp_series.
    """

    # Initialize an empty list to store forecasted demand
    forecasted_demand = []

    temp_series.index=pd.to_datetime(temp_series.index, utc = True).tz_localize(None).normalize()

    # Loop over the temperature Series
    for date, temp in temp_series.items():
        # Extract the month from the datetime index
        month = date.month

        # Get the intercept and polynomial coefficients for the specific month
        if f'month_{month}' in forecast_coeffs:
            intercept = forecast_coeffs[f'month_{month}']['intercept']
            poly_coeffs = forecast_coeffs[f'month_{month}']['poly_coeffs']
        else:
            # If no coefficients for this month, skip or set default values
            intercept = 0
            poly_coeffs = [0] * degree

        # Initialize forecast with the intercept
        forecast = intercept

        # Add polynomial terms to the forecast (e.g., temp, temp^2, etc.)
        for i, coeff in enumerate(poly_coeffs):
            forecast += coeff * (temp ** (i + 1))  # i+1 because i=0 is temp^1, i=1 is temp^2, etc.

        # Append the forecasted value
        forecasted_demand.append(forecast)

    # Return the forecasted values as a Series with the same index as temp_series
    return pd.Series(forecasted_demand, index=temp_series.index)


def _pub_dates():
    
    if  datetime.now().weekday() == 0:
        days_back = 4  # max = 18 months
    if not datetime.now().weekday() == 0:
        days_back = 2  # max = 18 months
    
    end = datetime.utcnow().date() + timedelta(days=1)
    start = end - timedelta(days=days_back)
    df = pd.date_range(start, end, freq='6h')
    df = df[df < datetime.utcnow()]
    df = df.strftime('%Y-%m-%dT%H:00:00')
    return df

def get_temp_data_forecast(country):
    pub_dates = _pub_dates()

    # Open connection and start session
    session = BBGQuery(p_on_server=True)._start_session_server()
    #options = blpapi.SessionOptions()
    #options.setServerHost('localhost')
    #options.setServerPort(8194)
    #session = blpapi.Session(options)
    #session.start()

    # Data container for each iteration
    df = pd.DataFrame()

    for pub_date in tqdm(pub_dates):

        # Weather forecast example
        session.openService('//blp/exrsvc')
        exrService = session.getService('//blp/exrsvc')
        request = exrService.createRequest('ExcelGetGridRequest')

        request.set('Domain', 'COMDTY:WEATHER')
        overrides = request.getElement("Overrides")

        # Set Weather Provider
        override1 = overrides.appendElement()
        override1.setElement("name", "provider")
        override1.setElement("value", "wsi")

        # Set locations
        override2 = overrides.appendElement()
        override2.setElement("name", "location")
        override2.setElement("value", country)

        # Set model with adjusted date
        override3 = overrides.appendElement()
        override3.setElement("name", "publication_date")
        override3.setElement("value", pub_date)

        # Set frequency
        override4 = overrides.appendElement()
        override4.setElement("name", "frequency")
        override4.setElement("value", "DAILY")

        # Set model
        override5 = overrides.appendElement()
        override5.setElement("name", "model")
        override5.setElement("value", "ECMWF")

        # Set forecast type
        override6 = overrides.appendElement()
        override6.setElement("name", "type")
        override6.setElement("value", "ENSEMBLE_MEAN")

        # Set location_time
        override7 = overrides.appendElement()
        override7.setElement("name", "location_time")
        override7.setElement("value", "TRUE")

        # Set return fields
        override8 = overrides.appendElement()
        override8.setElement("name", "fields")
        override8.setElement("value", "TEMPERATURE")

        session.sendRequest(request)

        # Loop through the results and put them into a DataFrame
        try:
            while (True):
                event = session.nextEvent(500)
                if event.eventType() != bsrch_handler.BLP_RESPONSE and \
                        event.eventType() != bsrch_handler.BLP_PARTIAL_RESPONSE:
                    continue
                for msg in event:
                    sub = bsrch_handler.getBSRCHData(msg)
                    if len(sub) > 0:
                        sub = _clean_forecast(sub, pub_date)
                        df = pd.concat([df, sub], axis=1)
                if event.eventType() == bsrch_handler.BLP_RESPONSE:
                    break
        except Exception as e:
            print(f"An error occurred: {e}")
            break

    # Stop the session
    session.stop()

    return df


#handle the df's data and convert to temp delta
def handle_df(df):
    df = df[df.columns[::-1]]

    if not datetime.now().weekday() == 0:
        filtered_columns = [col for col in df.columns if isinstance(col, tuple) and col[-1].endswith('00:00:00')]
        # Create a new DataFrame with only the filtered columns
        df_filtered = df[filtered_columns]
        temp = df_filtered.xs('Temperature (°C)', axis=1, level='field')
        temp['Delta'] = temp.iloc[:, 0] - temp.iloc[:, 1]
        temp.columns = ['D0 00z', 'D-1 00z', 'Delta']

    if datetime.now().weekday() == 0:
        # Convert the 'pub_date' level of the columns to datetime for comparison
        df.columns = pd.MultiIndex.from_tuples(
            [(field, pd.to_datetime(pub_date)) for field, pub_date in df.columns],
            names=['field', 'pub_date']
        )

        # Extract the 'pub_date' level and filter only for 'T00:00:00' times
        pub_dates = df.columns.get_level_values('pub_date')
        t00_columns = pub_dates[pub_dates.strftime('%H:%M:%S') == '00:00:00']

        # Get the earliest and latest 'T00:00:00' pub_dates
        earliest_date = t00_columns.min()
        latest_date = t00_columns.max()

        # Filter the DataFrame to keep only the earliest and latest 'T00:00:00' columns
        filtered_columns = [col for col in df.columns if col[1] == earliest_date or col[1] == latest_date]
        df_filtered = df[filtered_columns]

        temp = df_filtered
        temp['Delta'] = temp.iloc[:, 0] - temp.iloc[:, 1]
        temp.columns=['D0 00z','D-3 00z', 'Delta']
    return temp



def get_report(ce_user, ce_pass):
    
    
    # Load historical LDZ demand from CE
    logging.info('Querying CE...')
    
    ce=CElink(ce_user,ce_pass)
    df_ldz_demand=ce.eugasopdata(assets='665,2965,2967,192,54,1803,209',unit='mcm',dateFrom=2014)
    df_ldz_demand=df_ldz_demand.dropna()
    df_ldz_demand.index=df_ldz_demand['Date']
    df_ldz_demand.drop(columns=['DateExcel','Date'],inplace=True)
    df_ldz_demand.columns=['BE','DE_H','DE_L','FR','UK','IT','NL']
    df_ldz_demand['Total']=df_ldz_demand.sum(axis=1)
    df_ldz_demand.index=pd.to_datetime(df_ldz_demand.index)
    
    # Load wx actuals from BBG
    logging.info('Querying BBG actuals...')
    
    df_germany_hist=get_temp_data_actuals('DE')
    df_germany_hist.columns=['DE_Temp']
    df_germany_hist.index=pd.to_datetime(df_germany_hist.index,utc=True).tz_localize(None)
    df_germany_hist.index=df_germany_hist.index.normalize()
    df_france_hist=get_temp_data_actuals('FR')
    df_france_hist.columns=['FR_Temp']
    df_france_hist.index=pd.to_datetime(df_france_hist.index,utc=True).tz_localize(None)
    df_france_hist.index=df_france_hist.index.normalize()
    df_italy_hist=get_temp_data_actuals('IT')
    df_italy_hist.columns=['IT_Temp']
    df_italy_hist.index=pd.to_datetime(df_italy_hist.index,utc=True).tz_localize(None)
    df_italy_hist.index=df_italy_hist.index.normalize()
    df_uk_hist=get_temp_data_actuals('GB')
    df_uk_hist.columns=['UK_Temp']
    df_uk_hist.index=pd.to_datetime(df_uk_hist.index,utc=True).tz_localize(None)
    df_uk_hist.index=df_uk_hist.index.normalize()
    df_belgium_hist=get_temp_data_actuals('BE')
    df_belgium_hist.columns=['BE_Temp']
    df_belgium_hist.index=pd.to_datetime(df_belgium_hist.index,utc=True).tz_localize(None)
    df_belgium_hist.index=df_belgium_hist.index.normalize()
    df_netherlands_hist=get_temp_data_actuals('NL')
    df_netherlands_hist.columns=['NL_Temp']
    df_netherlands_hist.index=pd.to_datetime(df_netherlands_hist.index,utc=True).tz_localize(None)
    df_netherlands_hist.index=df_netherlands_hist.index.normalize()
    df_austria_hist=get_temp_data_actuals('AT')
    df_austria_hist.columns=['AT_Temp']
    df_austria_hist.index=pd.to_datetime(df_austria_hist.index,utc=True).tz_localize(None)
    df_austria_hist.index=df_austria_hist.index.normalize()
    
    
    
    
    
    # Run for new 2021-2024 model build
    df_ldz_demand_new=df_ldz_demand['2021-10-01':'2024-03-01']

    # Regress LDZ vs. temps
    de_h_m = ldz_demand_temp_regression(df_ldz_demand_new,'DE_H',df_germany_hist['2021-10-01':'2024-03-01'],'DE_Temp')
    de_l_m = ldz_demand_temp_regression(df_ldz_demand_new,'DE_L',df_germany_hist['2021-10-01':'2024-03-01'],'DE_Temp')
    be_m = ldz_demand_temp_regression(df_ldz_demand_new,'BE',df_belgium_hist['2021-10-01':'2024-03-01'],'BE_Temp')
    fr_m = ldz_demand_temp_regression(df_ldz_demand_new,'FR',df_france_hist['2021-10-01':'2024-03-01'],'FR_Temp')
    uk_m = ldz_demand_temp_regression(df_ldz_demand_new,'UK',df_uk_hist['2021-10-01':'2024-03-01'],'UK_Temp')
    ######## ISSUE: error spotted below whereby UK demand values are being used to produce monthly coeffs for IT
    it_m = ldz_demand_temp_regression(df_ldz_demand_new,'UK',df_italy_hist['2021-10-01':'2024-03-01'],'IT_Temp')
    nl_m = ldz_demand_temp_regression(df_ldz_demand_new,'NL',df_netherlands_hist['2021-10-01':'2024-03-01'],'NL_Temp')
    
    
    
    # Get latest forecasts
    logging.info('Querying BBG forecasts...')
    
    df_germany=handle_df(get_temp_data_forecast('DE'))
    df_france=handle_df(get_temp_data_forecast('FR'))
    df_italy=handle_df(get_temp_data_forecast('IT'))
    df_uk=handle_df(get_temp_data_forecast('GB'))
    df_belgium=handle_df(get_temp_data_forecast('BE'))
    df_netherlands=handle_df(get_temp_data_forecast('NL'))
    
    
    # Forecast demand for d0 00z
    logging.info('Producing forecast...')
    demand_de_h_d0=forecast_ldz_demand(df_germany['D0 00z'],de_h_m).dropna().astype(int)
    demand_de_l_d0=forecast_ldz_demand(df_germany['D0 00z'],de_l_m).dropna().astype(int)
    demand_be_d0=forecast_ldz_demand(df_belgium['D0 00z'],be_m).dropna().astype(int)
    demand_fr_d0=forecast_ldz_demand(df_france['D0 00z'],fr_m).dropna().astype(int)
    demand_uk_d0=forecast_ldz_demand(df_uk['D0 00z'],uk_m).dropna().astype(int)
    demand_it_d0=forecast_ldz_demand(df_italy['D0 00z'],it_m).dropna().astype(int)
    demand_nl_d0=forecast_ldz_demand(df_netherlands['D0 00z'],nl_m).dropna().astype(int)
    if datetime.now().weekday() == 0:
        demand_de_h_d3=forecast_ldz_demand(df_germany['D-3 00z'],de_h_m).dropna().astype(int)
        demand_de_l_d3=forecast_ldz_demand(df_germany['D-3 00z'],de_l_m).dropna().astype(int)
        demand_be_d3=forecast_ldz_demand(df_belgium['D-3 00z'],be_m).dropna().astype(int)
        demand_fr_d3=forecast_ldz_demand(df_france['D-3 00z'],fr_m).dropna().astype(int)
        demand_uk_d3=forecast_ldz_demand(df_uk['D-3 00z'],uk_m).dropna().astype(int)
        demand_it_d3=forecast_ldz_demand(df_italy['D-3 00z'],it_m).dropna().astype(int)
        demand_nl_d3=forecast_ldz_demand(df_netherlands['D-3 00z'],nl_m).dropna().astype(int)
    if not datetime.now().weekday() == 0:
        demand_de_h_d1=forecast_ldz_demand(df_germany['D-1 00z'],de_h_m).dropna().astype(int)
        demand_de_l_d1=forecast_ldz_demand(df_germany['D-1 00z'],de_l_m).dropna().astype(int)
        demand_be_d1=forecast_ldz_demand(df_belgium['D-1 00z'],be_m).dropna().astype(int)
        demand_fr_d1=forecast_ldz_demand(df_france['D-1 00z'],fr_m).dropna().astype(int)
        demand_uk_d1=forecast_ldz_demand(df_uk['D-1 00z'],uk_m).dropna().astype(int)
        demand_it_d1=forecast_ldz_demand(df_italy['D-1 00z'],it_m).dropna().astype(int)
        demand_nl_d1=forecast_ldz_demand(df_netherlands['D-1 00z'],nl_m).dropna().astype(int)

    
    #sum the demand deltas
    demand_new_D0_00z=demand_de_h_d0+demand_de_l_d0+demand_be_d0+demand_fr_d0+demand_uk_d0+demand_it_d0+demand_nl_d0
    if not datetime.now().weekday() == 0:
        demand_new_D1_00z=demand_de_h_d1+demand_de_l_d1+demand_be_d1+demand_fr_d1+demand_uk_d1+demand_it_d1+demand_nl_d1
        demand_delta=demand_new_D0_00z-demand_new_D1_00z
    if datetime.now().weekday() == 0:
        demand_new_D3_00z = demand_de_h_d3 + demand_de_l_d3 + demand_be_d3 + demand_fr_d3 + demand_uk_d3 + demand_it_d3 + demand_nl_d3
        demand_delta = demand_new_D0_00z - demand_new_D3_00z
    #demand_new_D0_00z.index=pd.to_datetime(demand_new_D0_00z.index)
    #demand_new_D1_00z.index=pd.to_datetime(demand_new_D1_00z.index)
    #demand_delta.index=pd.to_datetime(demand_delta.index)
    
    
    #df_germany=convert_index_to_datetime(df_germany)
    df_germany.index=pd.to_datetime(df_germany.index,utc = True).tz_localize(None).normalize()
    temp_delta=df_germany['Delta']
    if not datetime.now().weekday() == 0:
        summary_df=pd.concat([demand_new_D0_00z,demand_new_D1_00z,demand_delta,temp_delta],axis=1)
        summary_df=summary_df.dropna()
    
    
    if datetime.now().weekday() == 0:
        summary_df=pd.concat([demand_new_D0_00z,demand_new_D3_00z,demand_delta,temp_delta],axis=1)
        summary_df=summary_df.dropna()
    
    # Tidy up df date time index for display
    summary_df.index = pd.to_datetime(summary_df.index)
    # summary_df.index = summary_df.index.strftime('%d-%b-%Y')
    
    if datetime.now().weekday() == 0:
        summary_df.columns = ['D0_00z Demand', 'D-3_00z Demand', 'Demand Delta', 'DE Temp Delta']
        totals=summary_df.sum()
        summary_df.loc['Total']=totals
        columns_to_change = ['D0_00z Demand', 'D-3_00z Demand','Demand Delta']
        summary_df[columns_to_change] = summary_df[columns_to_change].astype(int)
    else:
        summary_df.columns = ['D0_00z Demand', 'D-1_00z Demand', 'Demand Delta', 'DE Temp Delta']
        totals = summary_df.sum()
        summary_df.loc['Total'] = totals
        columns_to_change = ['D0_00z Demand', 'D-1_00z Demand', 'Demand Delta']
        summary_df[columns_to_change] = summary_df[columns_to_change].astype(int)
    # print(demand_new_D0_00z)
    
    
    #### Save per country forecast into the database
    
    # Define what we want to save
    data_to_save = {'DE LDZ H': demand_de_h_d0,
                    'DE LDZ L': demand_de_l_d0,
                    'BE LDZ': demand_be_d0,
                    'FR LDZ': demand_fr_d0,
                    'GB LDZ': demand_uk_d0,
                    'IT LDZ': demand_it_d0,
                    'NL LDZ': demand_nl_d0,
                    }
    # Set report_date time to 00:00 as forecast is generated from the 0Z run
    now = datetime.now()
    report_date = datetime(now.year, now.month, now.day)
    
    logging.info(f"Saving {len(data_to_save)} forecasts to the database...")
    
    # Process each countries forecast
    dataitems = []
    for i, (k, v) in enumerate(data_to_save.items()):
        geography1 = k.split(' ')[0]
        # Define metadata
        md = {'commodity': 'GAS',
                     'geography1': geography1,
                     'category1': 'Demand',
                     'category2': k,
                     'measurement_type': 'FORECAST',
                     'unit': 'mcm',
                     'frequency': 'Daily',
                     'source1': 'JainGlobal',
                     'instances': 'Multi',
                     'data_table': 'eu_data_datavalue',
                     'description': f"{k} ECENS Demand Forecast mcm",
                     }
        
        # Prepare data
        df = v.to_frame()
        df.index.name = 'date'
        df.columns = ['value']
        df = df.reset_index()
        df['report_date'] = report_date
    
        # Construct payload
        dataitems.append({'id': i, 
                          'metadata': md,
                          'data': df,
                          })
        
    # Save to database
    dl = DataLoader(logintype='prod') 
    dl.process_data(dataitems)

    
    
    return summary_df
