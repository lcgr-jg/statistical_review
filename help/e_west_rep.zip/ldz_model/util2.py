
import logging
import numpy as np
import pandas as pd
import statsmodels.api as sm

from datetime import datetime, timedelta
from tqdm import tqdm

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.interfaces.bloomberg import bsrch_handler, BBGQuery
from jain_commods.core.interfaces.sqldb import DataLoader




def get_ce_demand(ce_user, ce_pass, countries):
    
    
    # Hard coded list of what we require
    # NB: if we update countries then we need to update this dict
    demand_asset_ids = {'BE': 665,
                        'DE_H': 2965,
                        'DE_L': 2967,
                        'FR': 192,
                        'GB': 54,
                        'IT': 1803,
                        'NL': 209,
                        }
    
    # Build str of assets ids
    asset_ids = ','.join([str(demand_asset_ids[c]) for c in countries])
    
    
    #  Query CE
    ce = CElink(ce_user,ce_pass)
    df_ldz_demand = ce.eugasopdata(assets=asset_ids,unit='mcm',dateFrom=2014)
    
    # Tidy up
    df_ldz_demand = df_ldz_demand.dropna()
    df_ldz_demand.index = pd.to_datetime(df_ldz_demand['Date'])
    df_ldz_demand = df_ldz_demand.drop(columns=['DateExcel','Date'])
    
    # Rename columns (NB: CE returns series IDs as column names but is preserved from original query)
    df_ldz_demand.columns = demand_asset_ids.keys()
    
    # Add total
    df_ldz_demand['Total'] = df_ldz_demand.sum(axis=1)
    
    return df_ldz_demand


def _clean(df):
    df = df.iloc[:, 1:]
    df = df.set_index('Location Time')
    df = df.replace('', np.nan).astype(float)
    idx = df.columns.to_frame(False)
    idx.columns = ['field']

    df.columns = pd.MultiIndex.from_frame(idx)
    return df


def get_temp_data_actuals(country):
    

    # Open connection and start session
    session = BBGQuery(p_on_server=True)._start_session_server()
    # Data container for each iteration
    df = pd.DataFrame()

    # Weather forecast example
    session.openService('//blp/exrsvc')
    exrService = session.getService('//blp/exrsvc')
    request = exrService.createRequest('ExcelGetGridRequest')

    request.set('Domain', 'COMDTY:WEATHER')
    overrides = request.getElement("Overrides")

    yday = (datetime.today().date()-pd.DateOffset(days=1)).strftime('%Y-%m-%d')
    
    # Define config
    override_configs = [
        ('provider', 'wsi'),
        ('location', country),
        ('target_start_date', '2021-01-05'),
        ('frequency', 'DAILY'),
        ('model', 'ACTUALS'),
        ('target_end_date', yday),
        ('location_time', 'TRUE'),
        ('fields', 'TEMPERATURE')
    ]
    
    # Apply overrides
    overrides = request.getElement("Overrides")
    for name, value in override_configs:
        override = overrides.appendElement()
        override.setElement("name", name)
        override.setElement("value", value)        

    session.sendRequest(request)

    # Loop through the results and put them into a DataFrame
    try:
        while (True):
            event = session.nextEvent(500)
            if event.eventType() != bsrch_handler.BLP_RESPONSE and \
                    event.eventType() != bsrch_handler.BLP_PARTIAL_RESPONSE:
                continue
            for msg in event:
                sub = bsrch_handler.getBSRCHData(msg)
                if len(sub) > 0:
                    sub = _clean(sub)
                    df = pd.concat([df, sub], axis=1)
            if event.eventType() == bsrch_handler.BLP_RESPONSE:
                break
    except Exception as e:
        print(f"An error occurred: {e}")

    # Stop the session
    session.stop()
    
    # Tidy up the output
    df.columns = [f"{country}_Temp"]
    df.index = pd.to_datetime(df.index,utc=True).tz_localize(None)
    df.index = df.index.normalize()

    return df


def _clean_forecast(df, pub_date):
    df = df.iloc[:, 1:]
    df = df.set_index('Location Time')
    df = df.replace('', np.nan).astype(float)
    idx = df.columns.to_frame(False)
    idx.columns = ['field']
    idx['pub_date'] = pub_date
    df.columns = pd.MultiIndex.from_frame(idx)
    
    # Fix on 17th feb to remove time zone info (was causing issues for UK as we entered DST and +01:00 in the string)
    df.index = df.index.str[:-6]
    df.index = pd.to_datetime(df.index)
    
    return df


def _pub_dates(model_type):
    
    # Consider EC46 publication timing (ie approx 5pm the previous day)
    offset = 0 if model_type=='ENSEMBLE_MEAN' else 1 
    
    # On a monday we want to check vs friday
    if datetime.now().weekday() == 0:
        days_back = 3
    else:
        days_back = 1
    
    # Construct forecast dates we want to query
    current = pd.to_datetime(datetime.now()).normalize() - timedelta(days=offset)
    previous = current - timedelta(days=days_back)
    
    return [current, previous]


def get_temp_data_forecast(country, model='ECMWF', model_type='ENSEMBLE_MEAN'):
    pub_dates = _pub_dates(model_type)

    # Open connection and start session
    session = BBGQuery(p_on_server=True)._start_session_server()

    # Data container for each iteration
    df = pd.DataFrame()

    for pub_date in tqdm(pub_dates):
        print(f"processing {pub_date}")

        # Weather forecast example
        session.openService('//blp/exrsvc')
        exrService = session.getService('//blp/exrsvc')
        request = exrService.createRequest('ExcelGetGridRequest')

        request.set('Domain', 'COMDTY:WEATHER')
        overrides = request.getElement("Overrides")       
        
        # Define config
        override_configs = [
                            ('provider', 'wsi'),
                            ('location', country),
                            ('publication_date', pub_date.strftime('%Y-%m-%dT%H:00:00')),
                            ('frequency', 'DAILY'),
                            ('model', model),
                            ('type', model_type),
                            ('location_time', 'TRUE'),
                            ('fields', 'TEMPERATURE'),
                            ]
        
        # Apply overrides
        overrides = request.getElement("Overrides")
        for name, value in override_configs:
            override = overrides.appendElement()
            override.setElement("name", name)
            override.setElement("value", value)       
        

        session.sendRequest(request)

        # Loop through the results and put them into a DataFrame
        try:
            while (True):
                event = session.nextEvent(500)
                if event.eventType() != bsrch_handler.BLP_RESPONSE and \
                        event.eventType() != bsrch_handler.BLP_PARTIAL_RESPONSE:
                    continue
                for msg in event:
                    sub = bsrch_handler.getBSRCHData(msg)
                    if len(sub) > 0:
                        sub = _clean_forecast(sub, pub_date)
                        df = pd.concat([df, sub], axis=1)
                if event.eventType() == bsrch_handler.BLP_RESPONSE:
                    break
        except Exception as e:
            print(f"An error occurred: {e}")
            break

    # Stop the session
    session.stop()
    
    # Tidy up the output
    df.index = pd.to_datetime(df.index,utc=True).tz_localize(None)
    df.index = df.index.normalize()

    return df



def ldz_demand_temp_regression(df_demand, demand_column, df_temp, temp_column, degree=2):
    """
    Perform polynomial regression of LDZ demand as a function of temperature with month-specific coefficients.

    Parameters:
    df_demand (pd.DataFrame): DataFrame containing LDZ demand data.
    demand_column (str): Column name in df_demand representing LDZ demand.
    df_temp (pd.DataFrame): DataFrame containing temperature data.
    temp_column (str): Column name in df_temp representing temperatures.
    degree (int): The degree of the polynomial regression. Default is 2 for quadratic regression.

    Returns:
    dict: A dictionary of regression coefficients, with different coefficients for each month.
    """

    # Ensure both DataFrames have datetime indices
    if not pd.api.types.is_datetime64_any_dtype(df_demand.index):
        df_demand.index = pd.to_datetime(df_demand.index)
    if not pd.api.types.is_datetime64_any_dtype(df_temp.index):
        df_temp.index = pd.to_datetime(df_temp.index)

    # Align the two DataFrames on the datetime index
    df = pd.merge(df_demand[[demand_column]], df_temp[[temp_column]], left_index=True, right_index=True)

    # Create a new column for the month (this will help apply different coefficients per month)
    df['month'] = df.index.month

    # Initialize a dictionary to store the regression coefficients
    monthly_coefficients = {}

    # Perform polynomial regression for each month
    for month, group in df.groupby('month'):
        # Extract demand (y) and temperature (X) for the current month
        y = group[demand_column]
        X = group[temp_column]

        # Manually create polynomial features (e.g., temperature, temperature^2, etc.)
        X_poly = np.column_stack([X ** i for i in range(1, degree + 1)])

        # Add a constant to the polynomial features for the intercept
        X_poly_with_constant = sm.add_constant(X_poly)

        # Fit the polynomial regression model
        model = sm.OLS(y, X_poly_with_constant).fit()

        # Extract coefficients (including intercept)
        intercept = model.params[0]
        poly_coeffs = model.params[1:].tolist()  # List of polynomial coefficients

        # Store coefficients for the current month
        monthly_coefficients[f'month_{month}'] = {
            'intercept': intercept,
            'poly_coeffs': poly_coeffs
        }

    return monthly_coefficients



def handle_df(df, model_type='ENSEMBLE_MEAN'):
        
    temp = df.xs('Temperature (°C)', axis=1, level='field')    
    # Add delta
    temp['Delta'] = temp.iloc[:, 0] - temp.iloc[:, 1]
    
    return temp


def forecast_ldz_demand(temp_series, forecast_coeffs, degree=2):
    """
    Forecast LDZ demand based on a Series of temperatures with a datetime index and polynomial coefficients.

    Parameters:
    temp_series (pd.Series): Series of temperatures with a datetime index.
    forecast_coeffs (dict): Coefficients from the regression model, including intercept and polynomial terms.
    degree (int): The degree of the polynomial regression (default is 2 for quadratic).

    Returns:
    pd.Series: Forecasted LDZ gas demand as a Series with the same index as temp_series.
    """

    # Initialize an empty list to store forecasted demand
    forecasted_demand = []
    
    # Define our weekday/weekend weighting. Notes:
        # for simplicity we apply just a single weighting value per month irrespective of country
        # values below calculated across a 10yr mean for all our 7 countries (ignores post-2022 demand destrucion/change of regime etc)
        # in future we should apply different weightings per country based on observed behaviour
    weightings = {1: 0.94,
                  2: 0.93,
                  3: 0.92,
                  4: 0.90,
                  5: 0.89,
                  6: 0.83,
                  7: 0.82,
                  8: 0.86,
                  9: 0.86,
                  10: 0.89,
                  11: 0.92,
                  12: 0.94,
                  }
    

    temp_series.index=pd.to_datetime(temp_series.index, utc = True).tz_localize(None).normalize()

    # Loop over the temperature Series
    for date, temp in temp_series.items():
        # Extract the month from the datetime index
        month = date.month

        # Get the intercept and polynomial coefficients for the specific month
        if f'month_{month}' in forecast_coeffs:
            intercept = forecast_coeffs[f'month_{month}']['intercept']
            poly_coeffs = forecast_coeffs[f'month_{month}']['poly_coeffs']
        else:
            # If no coefficients for this month, skip or set default values
            intercept = 0
            poly_coeffs = [0] * degree

        # Initialize forecast with the intercept
        forecast = intercept

        # Add polynomial terms to the forecast (e.g., temp, temp^2, etc.)
        for i, coeff in enumerate(poly_coeffs):
            forecast += coeff * (temp ** (i + 1))  # i+1 because i=0 is temp^1, i=1 is temp^2, etc.
            
        # Apply weekend/weekday weighting using lookup defined above
        is_weekend = date.weekday() >= 5
        weighting = weightings[month] if is_weekend else 1
        forecast *= weighting

        # Append the forecasted value
        forecasted_demand.append(forecast)

    # Return the forecasted values as a Series with the same index as temp_series
    return pd.Series(forecasted_demand, index=temp_series.index)




def get_report(ce_user, ce_pass, countries=['BE','DE_H','DE_L','FR','GB','IT','NL']):
    
    
    # Load historical LDZ demand from CE
    logging.info('Querying CE: gas demand actuals...')
    df_ldz_demand = get_ce_demand(ce_user, ce_pass, countries)
    
    
    # Load wx actuals from BBG
    logging.info('Querying BBG: temp actuals...')
    wx_historic = {}
    for c in countries:
        country = 'DE' if c == 'DE_H' else c
        if country != 'DE_L':
            wx_historic[country] = get_temp_data_actuals(country)


    # Define model training range
    start_dt = datetime(2021,10,1)
    end_dt = datetime(2024,3,1)

    
    # Perform polynomial regression, creating monthly coeffs  
    monthly_coeffs = {}
    for c in countries:
        # Define which columns we require in the source data
        demand_col = c
        temp_col = 'DE' if c in ['DE_H','DE_L'] else c
        # Perform regression
        monthly_coeffs[c] = ldz_demand_temp_regression(df_ldz_demand[start_dt:end_dt],
                                                       demand_col,
                                                       wx_historic[temp_col][start_dt:end_dt],
                                                       f"{temp_col}_Temp",
                                                       )

    # Get current & previous weather forecasts
    logging.info('Querying BBG: ECENS, EC46 & GFSENS weather forecasts...')
    wx_forecast = {}
    for c in countries:
        country = 'DE' if c == 'DE_H' else c
        if country != 'DE_L':
            ecens = handle_df(get_temp_data_forecast(country))
            ec46 = handle_df(get_temp_data_forecast(country, model_type='MONTH_AHEAD'), model_type='MONTH_AHEAD')
            gfsens = handle_df(get_temp_data_forecast(country, model='GFS'))
            # Capture forecasts in dict
            wx_forecast[country] = {'ecens': ecens,
                                    'ec46': ec46,
                                    'gfsens': gfsens,
                                    }


    # Generate demand forecasts
    logging.info('Producing demand forecasts...')
    demand_forecast = {}
    for c in countries:
        # Process each country
        fcast_c = 'DE' if c in ['DE_H','DE_L'] else c
        res = {}
        for model in ['ecens','ec46', 'gfsens']:
            # Create forecasts for each wx model
            curr = forecast_ldz_demand(wx_forecast[fcast_c][model].iloc[:, 0], monthly_coeffs[c]).dropna()
            prev = forecast_ldz_demand(wx_forecast[fcast_c][model].iloc[:, 1], monthly_coeffs[c]).dropna()
            curr.name = c
            prev.name = c
            res[model] = {'curr': curr, 'prev': prev,}
        # Capture output
        demand_forecast[c] = res
        
    
    # Sum demand forecasts and get deltas
    ecens_total_curr = sum([demand_forecast[c]['ecens']['curr'] for c in countries])
    ecens_total_prev = sum([demand_forecast[c]['ecens']['prev'] for c in countries])
    ecens_delta = ecens_total_curr - ecens_total_prev    
    ec46_total_curr = sum([demand_forecast[c]['ec46']['curr'] for c in countries])
    ec46_total_prev = sum([demand_forecast[c]['ec46']['prev'] for c in countries])
    ec46_delta = ec46_total_curr - ec46_total_prev
    
    gfsens_total_curr = sum([demand_forecast[c]['gfsens']['curr'] for c in countries])
    gfsens_total_prev = sum([demand_forecast[c]['gfsens']['prev'] for c in countries])
    gfsens_delta = gfsens_total_curr - gfsens_total_prev    
    
    
    # Get DE temp deltas
    ecens_de_temp_delta = wx_forecast['DE']['ecens']['Delta']
    ec46_de_temp_delta = wx_forecast['DE']['ec46']['Delta']
    gfsens_de_temp_delta = wx_forecast['DE']['gfsens']['Delta']
    
    # Construct summary table labels
    ens_pub_dates = _pub_dates('ENSEMBLE_MEAN')
    ec46_pub_dates = _pub_dates('MONTH_AHEAD')
    now = pd.to_datetime(datetime.now()).normalize()
    ens_labels = [f"D{(dt - now).days}_00z Demand" for dt in ens_pub_dates]
    ec46_labels = [f"D{(dt - now).days}_00z Demand" for dt in ec46_pub_dates]
    
    # Assign names to series for display df
    ecens_total_curr.name = ens_labels[0]
    ecens_total_prev.name = ens_labels[1]
    ecens_delta.name = 'Demand Delta'
    ecens_de_temp_delta.name = 'DE Temp Delta'
    
    ec46_total_curr.name = ec46_labels[0]
    ec46_total_prev.name = ec46_labels[1]
    ec46_delta.name = 'Demand Delta'
    ec46_de_temp_delta.name = 'DE Temp Delta'
    
    gfsens_total_curr.name = ens_labels[0]
    gfsens_total_prev.name = ens_labels[1]
    gfsens_delta.name = 'Demand Delta'
    gfsens_de_temp_delta.name = 'DE Temp Delta'
    
    # Construct summary dfs
    ecens_summary = pd.concat([ecens_total_curr, ecens_total_prev, ecens_delta, ecens_de_temp_delta], axis=1).dropna()
    ec46_summary = pd.concat([ec46_total_curr, ec46_total_prev, ec46_delta, ec46_de_temp_delta], axis=1).dropna()
    gfsens_summary = pd.concat([gfsens_total_curr, gfsens_total_prev, gfsens_delta, gfsens_de_temp_delta], axis=1).dropna()
    
    # Add total rows    
    ecens_summary.loc['Total'] = ecens_summary.sum()
    ec46_summary.loc['Total'] = ec46_summary.sum()
    gfsens_summary.loc['Total'] = gfsens_summary.sum()
    
    # Cheat and set the DE Temp Delta as str (ready for display)
    ecens_summary['DE Temp Delta'] = [f'{v:+.2f}' for v in ecens_summary['DE Temp Delta'].values]
    ec46_summary['DE Temp Delta'] = [f'{v:+.2f}' for v in ec46_summary['DE Temp Delta'].values]
    gfsens_summary['DE Temp Delta'] = [f'{v:+.2f}' for v in gfsens_summary['DE Temp Delta'].values]
    
    # Save results to db
    logging.info("Saving forecasts to the database...")
    # Process each countries forecast
    dataitems = []
    i=0
    for c in demand_forecast.keys():
        geography1 = c.split('_')[0]
        for model in ['ecens','ec46','gfsens']:
            # Select the relevant forecast (we only save the current one)
            df = demand_forecast[c][model]['curr'].to_frame()
            
            # Prepare df for saving
            df.index.name = 'date'
            df = df.rename(columns={c:'value'})
            df = df.reset_index()
            
            # Set the report_date
            report_date = ens_pub_dates[0] if model in ['ecens','gfsens'] else ec46_pub_dates[0]
            df['report_date'] = report_date
            
            # Define metadata
            md = {'commodity': 'GAS',
                    'geography1': geography1,
                    'category1': 'Demand',
                    'category2': 'LDZ',
                    'category3': c,
                    'category4': model.upper(),
                    'measurement_type': 'FORECAST',
                    'unit': 'mcm',
                    'frequency': 'Daily',
                    'source1': 'JainGlobal',
                    'instances': 'Multi',
                    'data_table': 'eu_data_datavalue',
                    'description': f"{c} {model.upper()} Demand Forecast mcm",
                    }
            # Construct payload
            dataitems.append({'id': i, 
                              'metadata': md,
                              'data': df,
                              })
            # Increment counter
            i+=1
        
    # Save to database
    dl = DataLoader(logintype='prod') 
    dl.process_data(dataitems)
    
    
    return ecens_summary, ec46_summary, gfsens_summary