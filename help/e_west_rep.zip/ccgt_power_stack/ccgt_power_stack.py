# Report to compare latest CCGT gas burn forecasts from Jain Global Power Stack

import logging
import traceback
import configparser
import platform
import pandas as pd
import sys

from datetime import datetime, timedelta
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.util.htmlutils import df2html

from jain_commods.fundamental.gas.util import get_eu_gas_balance


import util


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/ccgt_power_stack')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'ccgt_power_stack.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')


# Check cmd line switches to see which forecast we're comparing
early_run = '--early' in sys.argv


# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_ccgt_power_stack.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'


now = datetime.now()
email_subject = f"CCGT Demand {now.strftime('%d-%b-%Y')} (Power Stack Forecasts)"


# TODO: add checks to see if expected results exist (ie 6:37am run if early run or 8:37am for later run)
# TODO: implement using the early_run cmd line switch


try:

    logging.info('Running CCGT forecast report...')    
    
    # Get the latest gas balances (easiest way to get CCGT history)
    eu_gas_balance_basecase = get_eu_gas_balance(ref_date = now - pd.offsets.BDay(1), scenario_name='Basecase')
    eu_gas_balance_ea = get_eu_gas_balance(ref_date = now - pd.offsets.BDay(1), scenario_name='EA')
    eu_gas_balance_platts = get_eu_gas_balance(ref_date = now - pd.offsets.BDay(1), scenario_name='Platts')
    
    # Check what dates we are querying
    report_date = pd.to_datetime(datetime.now()).normalize()
    report_date_prev = report_date - timedelta(3 if report_date.dayofweek==0 else 1)
    report_date_from = report_date - timedelta(7)
    
    # Define the IDs we want to query
    # TODO: should this by a dynamic metadata query in case data IDs change?
    data_id_cfg = {'DE': {'Basecase': [4852, 4853],
                          'P10': [4856, 4857],
                          'P90': [4860, 4861],
                          },
                   'FR': {'Basecase': [4854, 4855],
                          'P10': [4858, 4859],
                          'P90': [4862, 4863],
                          },
                   }
    
    # Get relevant forecasts from the database   
    output_all = util.get_forecasts(data_id_cfg, report_date_from)
    
    # Assemble data for tables & charts
    table_output = util.process_forecasts(data_id_cfg, output_all, report_date_prev)
    
    # Prepare data for the charts (we plot all Basecase and just latest P10 + P90)
    df_de_chart = util.prepare_chart_data('DE', table_output)
    df_fr_chart = util.prepare_chart_data('FR', table_output)
    
    # Create charts: daily 
    plt_daily = util.plot_forecast_comparison(df_de_chart, df_fr_chart, n_days=15)
    plt_daily_img = f"<img src='data:image/png;base64,{plt_daily}' alt='CCGT Daily Forecast Comparison'>"
    
    # Create charts: monthly
    plt_monthly = util.plot_forecast_comparison(df_de_chart, df_fr_chart, monthly=True)
    plt_monthly_img = f"<img src='data:image/png;base64,{plt_monthly}' alt='CCGT Monthly Forecast Comparison'>"
            
    # Combine table outputs for better display  (just Basecase) and create HTML equivalents
    df_key, df_d, df_m = util.produce_display_tables(table_output)
    html_daily = df2html(df_d, precision=0, highlight_weekends=True, index_dt_format='%d-%b-%Y')
    html_monthly = df2html(df_m, precision=0)
    html_key_dates = df2html(df_key, precision=0)   
    
    # Create chart: Power Stack vs gas balances
    plt_balance_comparison, balance_cum_delta = util.plot_forecast_vs_balances(eu_gas_balance_basecase, eu_gas_balance_ea, eu_gas_balance_platts, df_de_chart, df_fr_chart)
    plt_balance_comparison_img = f"<img src='data:image/png;base64,{plt_balance_comparison}' alt='CCGT Stack vs Balances Comparison'>"
    
    html_balance_key_dates = df2html(balance_cum_delta, precision=1)
    
    # Construct email body
    email_body = f"""<b>Summary (cumulative mcm):</b>
                     <br>
                     {html_key_dates}
                     <br>
                     <br><hr>
                     <p><b>Daily (mcm):</b>
                     <br>
                     <table>
                     <tr>
                     <td style="vertical-align: top;">{html_daily}</td>
                     <td width=5>&nbsp;</td>
                     <td style="vertical-align: top;">{plt_daily_img}</td>
                     </tr>
                     </table>
                     <br><hr>
                     <p><b>Monthly (mcm/d):</b>
                     <br>
                     <table>
                     <tr>
                     <td style="vertical-align: top;">{html_monthly}</td>
                     <td width=5>&nbsp;</td>
                     <td style="vertical-align: top;">{plt_monthly_img}</td>
                     </tr>
                     </table>
                     <br><hr>
                     <p><b>Power Stack vs EU Gas Balance Scenarios (mcm/d):</b>
                     <br>
                     {plt_balance_comparison_img}
                     <br>
                     {html_balance_key_dates}
                     <br>Note: EU Gas Balance Scenarios saved at {eu_gas_balance_basecase['saved_date_utc'].strftime('%Y-%m-%d %H:%M')} UTC
                     <br><hr>
                     <p><b><u>Notes:</u></b>
                     <br>Currently 2 power stack runs are created per day (the early morning report shows the latest available forecasts and is used for the the EU gas balances).
                     <br>All units mcm/d.
                     <br>Forecasts are generated by the new Jain Global EU Power Stack. 
                     <br>Timestamps are all UTC and equate to when forecasts were saved into the DB. Previous days forecasts display the latest available forecast on that date.
                     <br>Positive deltas means latest > previous, ie increased CCGT demand.
                """ 
    
    send_email(receivers, 
               email_subject, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')

    logging.info('Report sent')


except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))    




    