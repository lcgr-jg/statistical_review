import io
import base64
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.colors as mcolors

from datetime import datetime, timedelta

from jain_commods.core.interfaces.sqldb import DataQuery


key_dates = [datetime(2026,3,31),
             datetime(2026,10,31),
             datetime(2027,3,31)]


def get_forecasts(data_id_cfg, report_date_from):
    
    
    # Query all the raw data
    dq = DataQuery(logintype='prod')
    output_all = {}
    for c, cfg in data_id_cfg.items():
        
        output_per_c = {}
        for scenario, dids in cfg.items():
            output_scenario = []
            
            # NB: new extra param so we can get all instances loaded per report_date
            res = dq.get_data(by='id', data_id=dids, report_date_from = report_date_from, multi_instance='all', all_load_dates=True, querytype='bulk')
    
            # Group data by load_date
            grouped_res = {}
            for did in res.keys():
                grouped = res[did].groupby('load_date_utc')
                grouped_res[did] = {load_date_utc.replace(second=0, microsecond=0): df for load_date_utc, df in grouped}
    
    
            did1 = dids[0]
            did2 = dids[1]
            for ld1 in grouped_res[did1].keys():
                # Find the same/close load date for the other data id
                ld2 = [dt for dt in grouped_res[did2].keys() if abs(dt - ld1) <= timedelta(minutes=5)][0]
                df1 = grouped_res[did1][ld1].set_index('date')[['value']].rename(columns={'value':did1})
                df2 = grouped_res[did2][ld2].set_index('date')[['value']].rename(columns={'value':did2})
                df_combined = pd.concat([df1, df2], axis=1)
                df_combined[ld1] = df_combined.sum(axis=1)
                output_scenario.append(df_combined[[ld1]])

            
            output_per_c[scenario] = output_scenario
            
        output_all[c] = output_per_c
        
    return output_all
        
        
        
def process_forecasts(data_id_cfg, output_all, report_date_prev):
    
    # Create data for tables & charts
    table_output = {}   
    
    for c in data_id_cfg.keys():
        
        table_output_scenario = {} 
        
        for scenario in data_id_cfg[c].keys():
    
            # Extract data from the dict
            df = pd.concat(output_all[c][scenario], axis=1)
            
            # We will have multiple results per date (ie the early and later run). We only want to keep the latest
            
            # Group columns by date (ignoring time)
            all_days = set([dt.date() for dt in df.columns])
                    
            # Find the latest date
            latest_date = max(all_days)
            
            # Find the earliest date (to show WoW)
            earliest_date = min(all_days)
            
            # For each date (except the latest), keep only the column with the latest time
            columns_to_keep = []
            
            for dt in all_days:
                if dt == latest_date:
                    # Keep all columns for the latest date
                    columns_to_keep.extend([c for c in df.columns if c.date()==dt])
                else:
                    if dt in [report_date_prev.date(),earliest_date]:
                        # Keep only the column with the latest time for this date
                        matching_cols = [c for c in df.columns if c.date()==dt]
                        columns_to_keep.append(max(matching_cols))
         
            # Select just the reqd columns
            df = df[columns_to_keep]
            
            
            # Capture raw data ready for plot
            df_chart = df.dropna()
            
            
            # Prepare data for display table        
            # Fix column order
            df_table = df[sorted(df.columns, reverse=True)]
            
            # Get the first (latest) column
            latest_col = df_table.columns[0]
            
            
            reqd_fmt = '%d %b %H:%M'
            
            # Calculate deltas for all columns except the first
            # NB: positive values mean the latest value is higher than the historical value.
            original_cols = []
            for col in df_table.columns[1:]:
                new_col = f"vs {col.strftime('%H:%M')}" if col.date()==latest_col.date() else f"D-{(latest_col.date() - col.date()).days}" # f"vs {col.strftime(reqd_fmt)}"
                df_table[new_col] = df_table[latest_col] - df_table[col]
                original_cols.append(col)
            
            # Drop original outright cols
            df_table = df_table.drop(columns=original_cols)
            # Tidy up
            df_table = df_table.rename(columns={latest_col:latest_col.strftime(reqd_fmt)})
            df_table = df_table.dropna()
            
            # Create dfs for html tables
            df_daily = df_table.head(15)
            df_monthly = df_table.resample('MS').mean()
            
            # Produce cumulative diff for our key dates
            key_dates_output = {}
            for kd in key_dates:
                col_output={}
                for col in df_table.columns:
                    # if col!=latest_col.strftime(reqd_fmt):
                    #     col_output[col] = df_table.loc[:kd, col].sum()
                    col_output[col] = df_table.loc[:kd, col].sum()
                        
                key_dates_output[kd] = col_output
            df_key_dates = pd.DataFrame.from_dict(key_dates_output, orient='index')    
            
            # Tidy up date indexes for display
            df_key_dates.index = [f"End {i.strftime('%b-%y')}" for i in df_key_dates.index]
            # df_daily.index = [i.strftime('%d-%b-%Y') for i in df_daily.index]
            df_monthly.index = [i.strftime('%b-%y') for i in df_monthly.index]
            
            table_output_scenario[scenario] = {'table_daily': df_daily,
                                               'table_monthly': df_monthly,
                                               'table_key_dates': df_key_dates,
                                               'chart_data': df_chart,
                                               }
        table_output[c] = table_output_scenario
        
    return table_output


def prepare_chart_data(country, table_output):
    chart_data = []
    for s in table_output[country].keys():
        if s=='Basecase':
            df = table_output[country][s]['chart_data'].copy()
            # df.columns = [f'Basecase {c}' for c in df.columns]
            chart_data.append(df)
        else:
            # we only want the latest P90 and P10 forecast
            latest_col = max(table_output[country][s]['chart_data'].columns)
            chart_data.append(table_output[country][s]['chart_data'][[latest_col]].rename(columns={latest_col: s}))
    return pd.concat(chart_data, axis=1)






def plot_forecast_comparison(df_germany, df_france, figsize=(10, 6), n_days=30, monthly=False):
    
    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=figsize)
    
    x_label_fmt = '%b-%y' if monthly else '%d-%b'
    mdates_locator = mdates.MonthLocator() if monthly else mdates.DayLocator()
    
    # --- Germany Plot ---
    # Identify forecast columns (datetime strings) and percentile columns
    forecast_cols_de = [col for col in df_germany.columns if col not in ['P10', 'P90']]
    
    # Convert column names to datetime objects for sorting
    col_dates_de = [(col, pd.to_datetime(col)) for col in forecast_cols_de]
    col_dates_de.sort(key=lambda x: x[1])  # Sort by datetime
    
    if monthly:
        df_de = df_germany.resample('MS').mean().copy()
        # Truncate to remove current month
        start_dt = df_germany.index.min()
        df_de = df_de[df_de.index>datetime(start_dt.year, start_dt.month, 1)]
        
    else:
        df_de = df_germany.head(n_days).copy()
        
    
    # Plot P10/P90 shaded area
    ax1.fill_between(df_de.index, df_de['P10'], df_de['P90'], 
                     alpha=0.2, color='gray', label='P10-P90 Latest')
    
    # Plot forecast lines with varying shades of red (older = lighter)
    n_forecasts_de = len(col_dates_de)
    for idx, (col_name, col_date) in enumerate(col_dates_de):
        # Calculate color intensity: oldest = light red, newest = dark red
        # Use a range from light salmon/pink to dark red
        intensity = 0.3 + (0.7 * idx / max(1, n_forecasts_de - 1))
        color = mcolors.to_rgb('darkred')
        # Blend with white for lighter shades
        color = tuple(c * intensity + 1.0 * (1 - intensity) for c in color)
        
        # Use dashed line for all except the latest (last one)
        linestyle = '-' if idx == n_forecasts_de - 1 else '--'
        
        ax1.plot(df_de.index, df_de[col_name], 
                color=color, linewidth=1.5, linestyle=linestyle,
                label=f'{col_date.strftime("%d-%b %H:%M")}')
    
    # ax1.set_xlabel('Date', fontsize=11)
    ax1.set_ylabel('mcm/d', fontsize=10)
    de_title = 'DE CCGT Monthly Forecast Comparison' if monthly else f'DE CCGT {n_days} day Forecast Comparison'
    ax1.set_title(de_title, fontsize=11)
    ax1.legend(loc='best', fontsize=7)
    ax1.grid(True, alpha=0.3)
    ax1.xaxis.set_major_locator(mdates_locator)
    ax1.xaxis.set_major_formatter(mdates.DateFormatter(x_label_fmt))
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    ax1.set_xlim(df_de.index.min(), df_de.index.max())
    
    # --- France Plot ---
    # Identify forecast columns (datetime strings) and percentile columns
    forecast_cols_fr = [col for col in df_france.columns if col not in ['P10', 'P90']]
    
    # Convert column names to datetime objects for sorting
    col_dates_fr = [(col, pd.to_datetime(col)) for col in forecast_cols_fr]
    col_dates_fr.sort(key=lambda x: x[1])  # Sort by datetime
    
    if monthly:
        df_fr = df_france.resample('MS').mean().copy()
        # Truncate to remove current month
        start_dt = df_france.index.min()
        df_fr = df_fr[df_fr.index>datetime(start_dt.year, start_dt.month, 1)]
    else:
        df_fr = df_france.head(n_days).copy()
    
    
    # Plot P10/P90 shaded area
    ax2.fill_between(df_fr.index, df_fr['P10'], df_fr['P90'], 
                     alpha=0.2, color='gray', label='P10-P90 Latest')
    
    # Plot forecast lines with varying shades of blue (older = lighter)
    n_forecasts_fr = len(col_dates_fr)
    for idx, (col_name, col_date) in enumerate(col_dates_fr):
        # Calculate color intensity: oldest = light blue, newest = dark blue
        intensity = 0.3 + (0.7 * idx / max(1, n_forecasts_fr - 1))
        color = mcolors.to_rgb('darkblue')
        # Blend with white for lighter shades
        color = tuple(c * intensity + 1.0 * (1 - intensity) for c in color)
        
        # Use dashed line for all except the latest (last one)
        linestyle = '-' if idx == n_forecasts_fr - 1 else '--'
        
        ax2.plot(df_fr.index, df_fr[col_name], 
                color=color, linewidth=1.5, linestyle=linestyle,
                label=f'{col_date.strftime("%d-%b %H:%M")}')
    
    # ax2.set_xlabel('Date', fontsize=11)
    ax2.set_ylabel('mcm/d', fontsize=10)
    fr_title = 'FR CCGT Monthly Forecast Comparison' if monthly else f'FR CCGT {n_days} day Forecast Comparison'
    ax2.set_title(fr_title, fontsize=11)
    ax2.legend(loc='best', fontsize=7)
    ax2.grid(True, alpha=0.3)
    ax2.xaxis.set_major_locator(mdates_locator)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter(x_label_fmt))
    
    ax2.set_xlim(df_fr.index.min(), df_fr.index.max())
    
    plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    plt.tight_layout()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)

    return plot_base64


def produce_display_tables(table_output):
    
    # Horrible extra steps added below to manually set display format of changes
    # TODO: this should really be in df2html function!!
    
    
    # Summary / key dates
    df_key_de = table_output['DE']['Basecase']['table_key_dates'].copy()
    for c in df_key_de.columns[1:]:
        df_key_de[c] = [f'{v:+,.0f}' for v in df_key_de[c].values]
    df_key_de.columns = pd.MultiIndex.from_tuples([('DE',c) for c in df_key_de.columns])       
    df_key_fr = table_output['FR']['Basecase']['table_key_dates'].copy()
    for c in df_key_fr.columns[1:]:
        df_key_fr[c] = [f'{v:+,.0f}' for v in df_key_fr[c].values]
    
    df_key_fr.columns = pd.MultiIndex.from_tuples([('FR',c) for c in df_key_fr.columns])       
    df_key = pd.concat([df_key_de, df_key_fr], axis=1)
    
    # Daily
    df_d_de = table_output['DE']['Basecase']['table_daily'].copy()
    for c in df_d_de.columns[1:]:
        df_d_de[c] = [f'{v:+,.0f}' for v in df_d_de[c].values]
    
    df_d_de.columns = pd.MultiIndex.from_tuples([('DE',c) for c in df_d_de.columns])        
    df_d_fr = table_output['FR']['Basecase']['table_daily'].copy()
    for c in df_d_fr.columns[1:]:
        df_d_fr[c] = [f'{v:+,.0f}' for v in df_d_fr[c].values]
    df_d_fr.columns = pd.MultiIndex.from_tuples([('FR',c) for c in df_d_fr.columns])         
    df_d = pd.concat([df_d_de, df_d_fr], axis=1)
    
    # Monthly 
    df_m_de = table_output['DE']['Basecase']['table_monthly'].copy()
    for c in df_m_de.columns[1:]:
        df_m_de[c] = [f'{v:+,.0f}' for v in df_m_de[c].values]
    df_m_de.columns = pd.MultiIndex.from_tuples([('DE',c) for c in df_m_de.columns])        
    df_m_fr = table_output['FR']['Basecase']['table_monthly'].copy()
    for c in df_m_fr.columns[1:]:
        df_m_fr[c] = [f'{v:+,.0f}' for v in df_m_fr[c].values]
    df_m_fr.columns = pd.MultiIndex.from_tuples([('FR',c) for c in df_m_fr.columns])        
    df_m = pd.concat([df_m_de, df_m_fr], axis=1)
    
    return df_key, df_d, df_m


def plot_forecast_vs_balances(eu_gas_balance_basecase, eu_gas_balance_ea, eu_gas_balance_platts, df_germany, df_france, figsize=(12, 10)):
    
    # Extract DE and FR balance forecasts
    de_balance_base = eu_gas_balance_basecase['balance_daily_per_country']['DE'][[('Demand','CCGT','Total')]].resample('MS').mean() * -1 
    de_balance_ea = eu_gas_balance_ea['balance_daily_per_country']['DE'][[('Demand','CCGT','Total')]].resample('MS').mean() * -1
    de_balance_platts = eu_gas_balance_platts['balance_daily_per_country']['DE'][[('Demand','CCGT','Total')]].resample('MS').mean() * -1
    
    fr_balance_base = eu_gas_balance_basecase['balance_daily_per_country']['FR'][[('Demand','CCGT','Total')]].resample('MS').mean() * -1 
    fr_balance_ea = eu_gas_balance_ea['balance_daily_per_country']['FR'][[('Demand','CCGT','Total')]].resample('MS').mean() * -1
    fr_balance_platts = eu_gas_balance_platts['balance_daily_per_country']['FR'][[('Demand','CCGT','FR CCGT')]].resample('MS').mean() * -1
    
    # Tidy up 
    de_balance_base.columns = ['Basecase']
    de_balance_ea.columns = ['EA']
    de_balance_platts.columns = ['Platts']
    
    fr_balance_base.columns = ['Basecase']
    fr_balance_ea.columns = ['EA']
    fr_balance_platts.columns = ['Platts']
    
    # Extract power stack data
    df_de = df_germany.resample('MS').mean().copy()
    df_fr = df_france.resample('MS').mean().copy()
    # Truncate to remove current month
    start_dt = df_germany.index.min()
    df_de = df_de[df_de.index>datetime(start_dt.year, start_dt.month, 1)]
    df_fr = df_fr[df_fr.index>datetime(start_dt.year, start_dt.month, 1)]
    
    # Truncate balances
    de_balance_base = de_balance_base[(de_balance_base.index>start_dt) & (de_balance_base.index<=df_de.index.max())]
    de_balance_ea = de_balance_ea[(de_balance_ea.index>start_dt) & (de_balance_ea.index<=df_de.index.max())]
    de_balance_platts = de_balance_platts[(de_balance_platts.index>start_dt) & (de_balance_platts.index<=df_de.index.max())]
    
    fr_balance_base = fr_balance_base[(fr_balance_base.index>start_dt) & (fr_balance_base.index<=df_fr.index.max())]
    fr_balance_ea = fr_balance_ea[(fr_balance_ea.index>start_dt) & (fr_balance_ea.index<=df_fr.index.max())]
    fr_balance_platts = fr_balance_platts[(fr_balance_platts.index>start_dt) & (fr_balance_platts.index<=df_fr.index.max())]
    
    
    
    # Create figure with two subplots
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=figsize)
    
    x_label_fmt = '%b-%y'
    mdates_locator = mdates.MonthLocator()
    
    # --- Germany ---
    # Identify Power Stack forecast columns (datetime strings) and percentile columns
    forecast_col_de = max([col for col in df_de.columns if col not in ['P10', 'P90']])        
    
    # Plot P10/P90 shaded area
    ax1.fill_between(df_de.index, df_de['P10'], df_de['P90'], alpha=0.2, color='gray', label='PS: P10-P90 Latest')
    
    # Plot Power Stack forecast line
    color = mcolors.to_rgb('darkred')    
    ax1.plot(df_de.index, df_de[forecast_col_de], color=color, linewidth=1.5, linestyle='-',label='PS: Base Latest')
    
    # Add balance forecasts
    ax1.plot(de_balance_base.index, de_balance_base['Basecase'], color='#008B8B', linewidth=1.5, linestyle='-', label='Balances: Basecase')
    ax1.plot(de_balance_ea.index, de_balance_ea['EA'], color='#008B8B', linewidth=1, alpha=0.8, linestyle='--', label='Balances: EA')
    ax1.plot(de_balance_platts.index, de_balance_platts['Platts'], color='#008B8B', linewidth=1, alpha=0.8, linestyle=':', label='Balances: Platts')
    
    
    
    # ax1.set_xlabel('Date', fontsize=11)
    ax1.set_ylabel('mcm/d', fontsize=10)
    # de_title = 'DE CCGT Power Stack vs EU Gas Balances'
    de_title = 'DE'
    ax1.set_title(de_title, fontsize=11)
    ax1.legend(loc='best', fontsize=7)
    ax1.grid(True, alpha=0.3)
    ax1.xaxis.set_major_locator(mdates_locator)
    ax1.xaxis.set_major_formatter(mdates.DateFormatter(x_label_fmt))
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    ax1.set_xlim(df_de.index.min(), df_de.index.max())
    
    # --- France ---
    # Identify forecast columns (datetime strings) and percentile columns
    forecast_col_fr = max([col for col in df_fr.columns if col not in ['P10', 'P90']])  
        
    # Plot P10/P90 shaded area
    ax2.fill_between(df_fr.index, df_fr['P10'], df_fr['P90'], alpha=0.2, color='gray', label='PS: P10-P90 Latest')
        
    # Plot Power Stack forecast line
    color = mcolors.to_rgb('darkblue')    
    ax2.plot(df_fr.index, df_fr[forecast_col_fr], color=color, linewidth=1.5, linestyle='-',label='PS: Base')
    
    # Add balance forecasts
    ax2.plot(fr_balance_base.index, fr_balance_base['Basecase'], color='#FF8C00', linewidth=1.5, linestyle='-', label='Balances: Basecase')
    ax2.plot(fr_balance_ea.index, fr_balance_ea['EA'], color='#FF8C00', linewidth=1, alpha=0.8, linestyle='--', label='Balances: EA')
    ax2.plot(fr_balance_platts.index, fr_balance_platts['Platts'], color='#FF8C00', linewidth=1, alpha=0.8, linestyle=':', label='Balances: Platts')
    
    
    # ax2.set_xlabel('Date', fontsize=11)
    ax2.set_ylabel('mcm/d', fontsize=10)
    # fr_title = 'FR CCGT Power Stack vs EU Gas Balances'
    fr_title = 'FR'
    ax2.set_title(fr_title, fontsize=11)
    ax2.legend(loc='best', fontsize=7)
    ax2.grid(True, alpha=0.3)
    ax2.xaxis.set_major_locator(mdates_locator)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter(x_label_fmt))
    
    ax2.set_xlim(df_fr.index.min(), df_fr.index.max())
    
    plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    
    
    # --- Combined ---
    df_combined = df_de + df_fr
    combined_balance_base = de_balance_base + fr_balance_base
    combined_balance_ea = de_balance_ea + fr_balance_ea
    combined_balance_platts = de_balance_platts + fr_balance_platts
    
    
    forecast_col_combined = max([col for col in df_combined.columns if col not in ['P10', 'P90']])        
    
    # Plot P10/P90 shaded area
    ax3.fill_between(df_combined.index, df_combined['P10'], df_combined['P90'], alpha=0.2, color='gray', label='PS: P10-P90 Latest')
    
    # Plot Power Stack forecast line
    color = mcolors.to_rgb('darkgreen')    
    ax3.plot(df_combined.index, df_combined[forecast_col_combined], color=color, linewidth=1.5, linestyle='-',label='PS: Base Latest')
    
    # Add balance forecasts
    ax3.plot(combined_balance_base.index, combined_balance_base['Basecase'], color='#8B008B', linewidth=1.5, linestyle='-', label='Balances: Basecase')
    ax3.plot(combined_balance_ea.index, combined_balance_ea['EA'], color='#8B008B', linewidth=1, alpha=0.8, linestyle='--', label='Balances: EA')
    ax3.plot(combined_balance_platts.index, combined_balance_platts['Platts'], color='#8B008B', linewidth=1, alpha=0.8, linestyle=':', label='Balances: Platts')

    ax3.set_ylabel('mcm/d', fontsize=10)
    combined_title = 'DE+FR' #' CCGT Power Stack vs EU Gas Balances'
    ax3.set_title(combined_title, fontsize=11)
    ax3.legend(loc='best', fontsize=7)
    ax3.grid(True, alpha=0.3)
    ax3.xaxis.set_major_locator(mdates_locator)
    ax3.xaxis.set_major_formatter(mdates.DateFormatter(x_label_fmt))
    plt.setp(ax3.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    ax3.set_xlim(df_combined.index.min(), df_combined.index.max())
    

    plt.tight_layout()
    
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)
    
    
    # Extra final step to produce table to show cumulative deltas of Power Stack vs Gas Balances
    df_summary = pd.concat([df_combined, combined_balance_base, combined_balance_ea, combined_balance_platts], axis=1)
    
    df_summary = df_summary.rename(columns={forecast_col_de: 'PS Basecase'})
    
    df_summary['PS Basecase vs Basecase'] = df_summary['PS Basecase'] - df_summary['Basecase']
    df_summary['PS Basecase vs EA'] = df_summary['PS Basecase'] - df_summary['EA']
    df_summary['PS Basecase vs Platts'] = df_summary['PS Basecase'] - df_summary['Platts']
    
    
    df_summary['PS Basecase vs Basecase'] = df_summary['PS Basecase vs Basecase'] * df_summary.index.daysinmonth
    df_summary['PS Basecase vs EA'] = df_summary['PS Basecase vs EA'] * df_summary.index.daysinmonth
    df_summary['PS Basecase vs Platts'] = df_summary['PS Basecase vs Platts'] * df_summary.index.daysinmonth
    
    key_dates_output = {}
    for kd in key_dates:
        col_output={}
        for col in ['PS Basecase vs Basecase','PS Basecase vs EA','PS Basecase vs Platts']:
            col_output[col] = df_summary.loc[:kd, col].sum()
                
        key_dates_output[kd] = col_output
    df_key_dates = pd.DataFrame.from_dict(key_dates_output, orient='index')
    
    
    # Tidy up date indexes for display
    df_key_dates.index = [f"End {i.strftime('%b-%y')}" for i in df_key_dates.index]
    
    # Convert to bcm & sort str display
    df_key_dates = df_key_dates / 1000    
    for c in df_key_dates.columns:
        df_key_dates[c] = [f'{v:+,.1f}' for v in df_key_dates[c].values]
    
    # Improve col names
    df_key_dates.columns = pd.MultiIndex.from_tuples([('DE + FR PS Basecase Cumulative Delta (bcm)', c.replace('PS Basecase ','')) for c in df_key_dates.columns])        
    
    
    

    return plot_base64, df_key_dates
    
    