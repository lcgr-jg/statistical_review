"""
CSS Efficiency Report for ES Q3 2026

Plots Clean Spark Spread (CSS) for Spain Q3 2026 with different gas efficiencies
(50%, 60%, 70%, 80%) over the last 90 trading days.

X-axis: Trading date
Y-axis: CSS (€/MWh)
Color: Gas efficiency
"""

import sys
import os
# Ensure we use local eu_corelib if available
corelib_path = 'c:/Users/Michael.Kane/OneDrive - Jain Global/Projects/eu_corelib'
if os.path.exists(corelib_path) and corelib_path not in sys.path:
    sys.path.insert(0, corelib_path)

from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery
from jain_commods.core.interfaces.snowflake.icequery import ICEFuturesQuery

from datetime import datetime, timedelta
import snowflake.connector
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Rectangle
import matplotlib.dates as mdates

# Monkey-patch snowflake connector to bypass SSL/OCSP checks due to environmental issues
_original_connect = snowflake.connector.connect
def insecure_connect(*args, **kwargs):
    kwargs['insecure_mode'] = True
    return _original_connect(*args, **kwargs)
snowflake.connector.connect = insecure_connect

# Constants
GAS_EMISSIONS = 0.1821  # tCO2/MWh
GAS_EFFICIENCIES = [0.50, 0.60, 0.70, 0.80]  # 50%, 60%, 70%, 80%
Q3_2026_START = datetime(2026, 7, 1)
Q3_2026_END = datetime(2026, 9, 30)


class CSSEfficiencyReport:
    """Generate CSS efficiency report for ES Q3 2026."""
    
    def __init__(self):
        self.eex = EEXQuery()
        self.ice = ICEFuturesQuery()
    
    def fetch_q3_2026_data(self, country_code='es', days=90):
        """
        Fetch Q3 2026 power, gas, and carbon prices for the last N trading days.
        
        Returns:
            DataFrame with columns: trading_date, power_price, gas_price, carbon_price
        """
        print(f"Fetching Q3 2026 data for {country_code.upper()} (last {days} trading days)...")
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days * 2)  # Buffer for weekends/holidays
        
        results = []
        
        # 1. Fetch Power prices (EEX) - filter for Q3-26 strip
        print("  Fetching EEX power prices...")
        try:
            df_power = self.eex.get_strip_prices(
                country_code=country_code.lower(),
                profile='Base',
                start_date=start_date,
                end_date=end_date
            )
            
            if not df_power.empty:
                # Standardize column names
                df_power.columns = [c.lower() for c in df_power.columns]
                
                # Filter for Q3 2026 strip
                # Strip format could be 'Q3-26', 'Q3-2026', 'Q326', etc.
                df_power['strip_upper'] = df_power['strip'].astype(str).str.upper()
                q3_filters = [
                    df_power['strip_upper'].str.contains('Q3-26', na=False),
                    df_power['strip_upper'].str.contains('Q3-2026', na=False),
                    df_power['strip_upper'].str.contains('Q326', na=False),
                    df_power['strip_upper'] == 'Q3-26',
                ]
                q3_mask = pd.concat(q3_filters, axis=1).any(axis=1)
                df_q3_power = df_power[q3_mask].copy()
                
                if df_q3_power.empty:
                    print(f"    Warning: No Q3-26 power data found. Available strips: {df_power['strip'].unique()[:10]}")
                else:
                    # Get trading date and price columns
                    date_col = 'trading_day' if 'trading_day' in df_q3_power.columns else 'trade_date'
                    price_col = 'price' if 'price' in df_q3_power.columns else 'settlement_price'
                    
                    if date_col in df_q3_power.columns and price_col in df_q3_power.columns:
                        for _, row in df_q3_power.iterrows():
                            trading_date = pd.to_datetime(row[date_col])
                            if hasattr(trading_date, 'normalize'):
                                trading_date = trading_date.normalize()
                            else:
                                trading_date = pd.to_datetime(trading_date).normalize()
                            results.append({
                                'trading_date': trading_date,
                                'power_price': float(row[price_col]),
                                'gas_price': np.nan,
                                'carbon_price': np.nan,
                            })
                        print(f"    Found {len(df_q3_power)} Q3-26 power price records")
            else:
                print("    Warning: No EEX power data returned")
        except Exception as e:
            error_msg = str(e)
            if 'certificate' in error_msg.lower() or 'ssl' in error_msg.lower():
                print(f"    SSL/Certificate error fetching EEX power (environment issue): {error_msg[:100]}...")
                print("    Continuing without EEX data - will try to use ICE data only")
            else:
                print(f"    Error fetching EEX power: {e}")
                import traceback
                traceback.print_exc()
        
        # 2. Fetch Gas prices (ICE TTF) - need Q3 2026 contract
        print("  Fetching ICE TTF gas prices...")
        try:
            # Fetch historical data by iterating through trading dates
            # This is similar to how price_report.py does it
            date_range = pd.bdate_range(start=start_date, end=end_date)
            gas_results = []
            
            print(f"    Fetching TTF prices for {len(date_range)} trading days...")
            for trade_date in date_range:
                try:
                    df_gas = self.ice.get_curve('TTF', trade_date=trade_date)
                    
                    if not df_gas.empty:
                        # Standardize column names (handle both upper and lower case)
                        df_gas.columns = [c.upper() for c in df_gas.columns]
                        
                        # Check for Q3 2026 contracts
                        if 'DELIVERY_START' in df_gas.columns and 'DELIVERY_END' in df_gas.columns:
                            df_gas['DELIVERY_START'] = pd.to_datetime(df_gas['DELIVERY_START'])
                            df_gas['DELIVERY_END'] = pd.to_datetime(df_gas['DELIVERY_END'])
                            
                            # Filter for contracts that overlap with Q3 2026
                            q3_mask = (
                                (df_gas['DELIVERY_START'] <= Q3_2026_END) &
                                (df_gas['DELIVERY_END'] >= Q3_2026_START)
                            )
                            df_q3_gas = df_gas[q3_mask].copy()
                            
                            if not df_q3_gas.empty:
                                # Get price column
                                price_col = 'SETTLEMENT_PRICE' if 'SETTLEMENT_PRICE' in df_q3_gas.columns else 'PRICE'
                                if price_col in df_q3_gas.columns:
                                    # Take average of all Q3 2026 contracts for this date
                                    avg_price = df_q3_gas[price_col].mean()
                                    if not pd.isna(avg_price):
                                        gas_results.append({
                                            'trading_date': trade_date.normalize(),
                                            'gas_price': float(avg_price)
                                        })
                except Exception as e:
                    # Skip this date if there's an error
                    continue
            
            if gas_results:
                gas_df = pd.DataFrame(gas_results)
                gas_df = gas_df.sort_values('trading_date').drop_duplicates(subset=['trading_date'], keep='last')
                
                # Merge with results
                if results:
                    results_df = pd.DataFrame(results)
                    results_df = results_df.merge(gas_df, on='trading_date', how='outer', suffixes=('', '_gas'))
                    # Handle merged columns
                    if 'gas_price_gas' in results_df.columns:
                        results_df['gas_price'] = results_df['gas_price'].fillna(results_df['gas_price_gas'])
                        results_df = results_df.drop(columns=['gas_price_gas'])
                    results = results_df.to_dict('records')
                else:
                    results = gas_df.to_dict('records')
                    for r in results:
                        r['power_price'] = np.nan
                        r['carbon_price'] = np.nan
                
                print(f"    Found {len(gas_df)} Q3 2026 gas price records")
            else:
                print("    Warning: No Q3 2026 gas prices found")
        except Exception as e:
            print(f"    Error fetching ICE gas: {e}")
            import traceback
            traceback.print_exc()
        
        # 3. Fetch Carbon prices (ICE EUA) - need Q3 2026 period
        print("  Fetching ICE EUA carbon prices...")
        try:
            # Fetch historical data by iterating through trading dates
            date_range = pd.bdate_range(start=start_date, end=end_date)
            carbon_results = []
            
            print(f"    Fetching EUA prices for {len(date_range)} trading days...")
            for trade_date in date_range:
                try:
                    df_carbon = self.ice.get_curve('EUA', trade_date=trade_date)
                    
                    if not df_carbon.empty:
                        # Standardize column names (handle both upper and lower case)
                        df_carbon.columns = [c.upper() for c in df_carbon.columns]
                        
                        # Carbon contracts are typically annual (Dec contracts)
                        # For Q3 2026, we'd use Dec 2026 contract
                        if 'DELIVERY_START' in df_carbon.columns and 'DELIVERY_END' in df_carbon.columns:
                            df_carbon['DELIVERY_START'] = pd.to_datetime(df_carbon['DELIVERY_START'])
                            df_carbon['DELIVERY_END'] = pd.to_datetime(df_carbon['DELIVERY_END'])
                            
                            # Find contracts that cover Q3 2026 (typically Dec 2026)
                            q3_mask = (
                                (df_carbon['DELIVERY_START'] <= Q3_2026_END) &
                                (df_carbon['DELIVERY_END'] >= Q3_2026_START)
                            )
                            df_q3_carbon = df_carbon[q3_mask].copy()
                            
                            if not df_q3_carbon.empty:
                                # Get price column
                                price_col = 'SETTLEMENT_PRICE' if 'SETTLEMENT_PRICE' in df_q3_carbon.columns else 'PRICE'
                                if price_col in df_q3_carbon.columns:
                                    # Take average of all Q3 2026 contracts for this date
                                    avg_price = df_q3_carbon[price_col].mean()
                                    if not pd.isna(avg_price):
                                        carbon_results.append({
                                            'trading_date': trade_date.normalize(),
                                            'carbon_price': float(avg_price)
                                        })
                except Exception as e:
                    # Skip this date if there's an error
                    continue
            
            if carbon_results:
                carbon_df = pd.DataFrame(carbon_results)
                carbon_df = carbon_df.sort_values('trading_date').drop_duplicates(subset=['trading_date'], keep='last')
                
                # Merge with results
                if results:
                    results_df = pd.DataFrame(results)
                    results_df = results_df.merge(carbon_df, on='trading_date', how='outer', suffixes=('', '_carbon'))
                    # Handle merged columns
                    if 'carbon_price_carbon' in results_df.columns:
                        results_df['carbon_price'] = results_df['carbon_price'].fillna(results_df['carbon_price_carbon'])
                        results_df = results_df.drop(columns=['carbon_price_carbon'])
                    results = results_df.to_dict('records')
                else:
                    results = carbon_df.to_dict('records')
                    for r in results:
                        r['power_price'] = np.nan
                        r['gas_price'] = np.nan
                
                print(f"    Found {len(carbon_df)} Q3 2026 carbon price records")
            else:
                print("    Warning: No Q3 2026 carbon prices found")
        except Exception as e:
            print(f"    Error fetching ICE carbon: {e}")
            import traceback
            traceback.print_exc()
        
        # Convert to DataFrame and clean up
        if results:
            df = pd.DataFrame(results)
            df['trading_date'] = pd.to_datetime(df['trading_date']).dt.normalize()
            
            # Sort by trading date and take last N days
            df = df.sort_values('trading_date').drop_duplicates(subset=['trading_date'], keep='last')
            df = df.tail(days)
            
            # Forward fill missing values (within reason)
            df = df.sort_values('trading_date')
            df['power_price'] = df['power_price'].ffill(limit=5)
            df['gas_price'] = df['gas_price'].ffill(limit=5)
            df['carbon_price'] = df['carbon_price'].ffill(limit=5)
            
            print(f"  Final dataset: {len(df)} trading days")
            print(f"    Date range: {df['trading_date'].min()} to {df['trading_date'].max()}")
            print(f"    Power prices: {df['power_price'].notna().sum()} / {len(df)}")
            print(f"    Gas prices: {df['gas_price'].notna().sum()} / {len(df)}")
            print(f"    Carbon prices: {df['carbon_price'].notna().sum()} / {len(df)}")
            
            return df
        else:
            print("  Warning: No data collected")
            return pd.DataFrame()
    
    def calculate_css(self, power_price, gas_price, carbon_price, efficiency):
        """
        Calculate Clean Spark Spread for given efficiency.
        
        CSS = Power - Gas_Cost
        Gas_Cost = (Gas / Efficiency) + (Gas_Emissions / Efficiency) * Carbon
        """
        if pd.isna(power_price) or pd.isna(gas_price) or pd.isna(carbon_price):
            return np.nan
        
        gas_cost = (gas_price / efficiency) + (GAS_EMISSIONS / efficiency) * carbon_price
        css = power_price - gas_cost
        return css
    
    def generate_report(self, output_file=None, days=90):
        """
        Generate CSS efficiency report PDF.
        
        Args:
            output_file: Path to output PDF file (optional)
            days: Number of trading days to include (default: 90)
        """
        print(f"\n{'='*60}")
        print("CSS Efficiency Report: ES Q3 2026")
        print(f"{'='*60}\n")
        
        # Fetch data
        df = self.fetch_q3_2026_data(country_code='es', days=days)
        
        if df.empty:
            print("Error: No data available. Cannot generate report.")
            return None
        
        # Calculate CSS for each efficiency
        print("\nCalculating CSS for different efficiencies...")
        for eff in GAS_EFFICIENCIES:
            df[f'CSS_{int(eff*100)}'] = df.apply(
                lambda row: self.calculate_css(
                    row['power_price'],
                    row['gas_price'],
                    row['carbon_price'],
                    eff
                ),
                axis=1
            )
            css_count = df[f'CSS_{int(eff*100)}'].notna().sum()
            print(f"  {int(eff*100)}% efficiency: {css_count} valid CSS values")
        
        # Filter to dates with at least one valid CSS
        df = df[df[[f'CSS_{int(eff*100)}' for eff in GAS_EFFICIENCIES]].notna().any(axis=1)].copy()
        
        if df.empty:
            print("Error: No valid CSS calculations. Cannot generate report.")
            return None
        
        # Generate output filename if not provided
        if output_file is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"CSS_Efficiency_Report_ES_Q3_2026_{timestamp}.pdf"
        
        # Create PDF
        print(f"\nGenerating PDF: {output_file}")
        with PdfPages(output_file) as pdf:
            # Create figure
            fig = plt.figure(figsize=(16, 10))
            fig.patch.set_facecolor('white')
            
            # Header
            header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig.transFigure, 
                                   facecolor='#231F20', edgecolor='none', zorder=1000)
            fig.patches.append(header_rect)
            fig.text(0.5, 0.98, 'CSS Efficiency Analysis: ES Q3 2026', 
                    fontsize=20, fontweight='bold', va='center', ha='center', 
                    color='white', zorder=1002)
            
            # Footer
            footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig.transFigure, 
                                   facecolor='#231F20', edgecolor='none', zorder=1000)
            fig.patches.append(footer_rect)
            fig.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', 
                    fontsize=9, va='center', ha='right', color='white', zorder=1002)
            
            # Main plot
            ax = plt.subplot(111)
            ax.set_facecolor('white')
            
            # Plot CSS for each efficiency with different colors
            colors = ['#d62728', '#ff7f0e', '#2ca02c', '#1f77b4']  # Red, Orange, Green, Blue
            for i, eff in enumerate(GAS_EFFICIENCIES):
                css_col = f'CSS_{int(eff*100)}'
                valid_data = df[df[css_col].notna()].copy()
                
                if not valid_data.empty:
                    ax.plot(valid_data['trading_date'], valid_data[css_col], 
                           label=f'{int(eff*100)}% Efficiency', 
                           color=colors[i], linewidth=2.5, marker='o', markersize=4)
            
            # Formatting
            ax.set_xlabel('Trading Date', fontsize=14, fontweight='bold')
            ax.set_ylabel('Clean Spark Spread (€/MWh)', fontsize=14, fontweight='bold')
            ax.set_title('CSS Evolution for ES Q3 2026 by Gas Efficiency', 
                        fontsize=16, fontweight='bold', pad=20)
            ax.grid(True, alpha=0.3, linestyle='--')
            ax.legend(loc='best', fontsize=12, framealpha=0.9)
            
            # Format x-axis dates
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
            ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=2))
            plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=10)
            plt.setp(ax.get_yticklabels(), fontsize=10)
            
            # Add zero line
            ax.axhline(y=0, color='black', linestyle='-', linewidth=0.8, alpha=0.5)
            
            plt.tight_layout(rect=[0, 0.03, 1, 0.96])
            
            pdf.savefig(fig, dpi=150, bbox_inches='tight')
            plt.close(fig)
            
            # Add summary statistics page
            fig2 = plt.figure(figsize=(16, 10))
            fig2.patch.set_facecolor('white')
            
            header_rect2 = Rectangle((0, 0.96), 1, 0.04, transform=fig2.transFigure, 
                                    facecolor='#231F20', edgecolor='none', zorder=1000)
            fig2.patches.append(header_rect2)
            fig2.text(0.5, 0.98, 'CSS Efficiency Statistics: ES Q3 2026', 
                     fontsize=20, fontweight='bold', va='center', ha='center', 
                     color='white', zorder=1002)
            
            footer_rect2 = Rectangle((0, 0), 1, 0.03, transform=fig2.transFigure, 
                                     facecolor='#231F20', edgecolor='none', zorder=1000)
            fig2.patches.append(footer_rect2)
            fig2.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', 
                     fontsize=9, va='center', ha='right', color='white', zorder=1002)
            
            ax2 = plt.subplot(111)
            ax2.axis('off')
            
            # Create statistics table
            stats_data = []
            for eff in GAS_EFFICIENCIES:
                css_col = f'CSS_{int(eff*100)}'
                css_values = df[css_col].dropna()
                if not css_values.empty:
                    stats_data.append([
                        f'{int(eff*100)}%',
                        f'{css_values.mean():.2f}',
                        f'{css_values.median():.2f}',
                        f'{css_values.min():.2f}',
                        f'{css_values.max():.2f}',
                        f'{css_values.std():.2f}',
                        f'{len(css_values)}'
                    ])
            
            if stats_data:
                table = ax2.table(cellText=stats_data,
                                 colLabels=['Efficiency', 'Mean', 'Median', 'Min', 'Max', 'Std Dev', 'Count'],
                                 cellLoc='center',
                                 loc='center',
                                 bbox=[0.1, 0.3, 0.8, 0.5])
                table.auto_set_font_size(False)
                table.set_fontsize(12)
                table.scale(1, 2)
                
                # Style header
                for i in range(7):
                    table[(0, i)].set_facecolor('#231F20')
                    table[(0, i)].set_text_props(weight='bold', color='white')
                
                # Style data rows
                for i in range(1, len(stats_data) + 1):
                    for j in range(7):
                        if i % 2 == 0:
                            table[(i, j)].set_facecolor('#f0f0f0')
            
            plt.tight_layout(rect=[0, 0.03, 1, 0.96])
            pdf.savefig(fig2, dpi=150, bbox_inches='tight')
            plt.close(fig2)
        
        print(f"\n✓ Report generated successfully: {output_file}")
        return output_file


def run_css_efficiency_report(output_dir=None, days=90):
    """
    Main function to run the CSS efficiency report.
    
    Args:
        output_dir: Directory to save the report (default: current directory)
        days: Number of trading days to include (default: 90)
    
    Returns:
        Path to generated PDF file
    """
    if output_dir is None:
        output_dir = os.path.dirname(os.path.abspath(__file__))
    
    report = CSSEfficiencyReport()
    output_file = report.generate_report(days=days)
    
    if output_file:
        # Move to output directory if specified
        if output_dir != os.path.dirname(os.path.abspath(output_file)):
            import shutil
            dest_path = os.path.join(output_dir, os.path.basename(output_file))
            shutil.move(output_file, dest_path)
            return dest_path
    
    return output_file


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate CSS Efficiency Report for ES Q3 2026')
    parser.add_argument('--output-dir', type=str, default=None, 
                      help='Output directory for PDF (default: current directory)')
    parser.add_argument('--days', type=int, default=90,
                      help='Number of trading days to include (default: 90)')
    
    args = parser.parse_args()
    
    output_file = run_css_efficiency_report(output_dir=args.output_dir, days=args.days)
    
    if output_file:
        print(f"\n✓ Report saved to: {output_file}")
    else:
        print("\n✗ Failed to generate report")
