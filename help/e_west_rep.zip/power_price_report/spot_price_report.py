"""
Spot Price Report Generator

Fetches Day Ahead power prices from multiple sources (Database, ENTSOE API, EPEX)
and generates an HTML report with interactive map and price table.
"""

import pandas as pd
import os
import json
import glob
import time
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import plotly.express as px
from entsoe import EntsoePandasClient
from entsoe.mappings import lookup_area
from entsoe.exceptions import NoMatchingDataError
from requests.exceptions import HTTPError

# Import Core Library Interfaces
try:
    from jain_commods.core.interfaces.snowflake.epexquery import EPEXQuery
    from jain_commods.core.interfaces.sqldb import DataQuery
    from jain_commods.core.interfaces.bloomberg.bpipe import BBGQuery
    DATAQUERY_AVAILABLE = True
except ImportError as e:
    logging.error(f"Failed to import core libraries: {e}")
    EPEXQuery = None
    DataQuery = None
    BBGQuery = None
    DATAQUERY_AVAILABLE = False

import entsoe

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration

REGIONS = {
    "CWE": ["DE", "FR", "NL", "BE", "AT", "CH"],
    "UK+IE": ["UK", "IE"],
    "Iberia": ["ES", "PT"],
    "Italy": ["IT"],
    "CEE": ["PL", "CZ", "HU", "SK"],
    "SEE": ["RO", "GR", "RS", "BG", "HR", "SI"],
    "Nordics": ["SE1", "SE2", "SE3", "SE4", "DK1", "DK2", "FI", "NO1", "NO2", "NO3", "NO4", "NO5"],
}

ZONE_ALIASES = {
    "IT_NORD": "IT-NO",
    "UK": "GB",
    "DE": "DE_LU",
    "SE1": "SE_1", "SE2": "SE_2", "SE3": "SE_3", "SE4": "SE_4",
    "NO1": "NO_1", "NO2": "NO_2", "NO3": "NO_3", "NO4": "NO_4", "NO5": "NO_5",
    "DK1": "DK_1", "DK2": "DK_2",
}

ENTSOE_API_KEY = "98c0eeb9-19cf-4664-8bb6-5dad7a3ac105"

ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "zones")
ENTSOE_GEO_DIR = os.path.join(os.path.dirname(entsoe.__file__), 'geo', 'geojson')


def _load_geojson(zone_code: str) -> Optional[str]:
    """Load GeoJSON file path for a zone code."""
    # Check aliases
    if zone_code in ZONE_ALIASES:
        zone_code = ZONE_ALIASES[zone_code]
    
    # Try ENTSOE package directory
    entsoe_path = os.path.join(ENTSOE_GEO_DIR, f"{zone_code}.geojson")
    if os.path.exists(entsoe_path):
        return entsoe_path
    
    # Try local assets
    local_path = os.path.join(ASSETS_DIR, f"{zone_code}.geojson")
    if os.path.exists(local_path):
        return local_path
    
    # Search for pattern matches
    candidates = glob.glob(os.path.join(ASSETS_DIR, f"*-{zone_code}.geojson"))
    if candidates:
        return candidates[0]
    
    # Country fallback (strip numbers)
    country = ''.join([i for i in zone_code if not i.isdigit()])
    if len(country) == 2 and country != zone_code:
        country_path = os.path.join(ASSETS_DIR, f"{country}.geojson")
        if os.path.exists(country_path):
            return country_path
    
    return None


class PriceDataFetcher:
    """Handles fetching price data from multiple sources (Database, ENTSOE, EPEX)."""
    
    def __init__(self, entsoe_api_key: str = ENTSOE_API_KEY, db_logintype: str = 'prod'):
        self.entsoe_api_key = entsoe_api_key
        self.db_logintype = db_logintype
        self.entsoe_client = EntsoePandasClient(api_key=entsoe_api_key)
        self.gbp_eur_rate = None
    
    @staticmethod
    def _map_country_code(code: str) -> str:
        """Map country codes to ENTSOE area codes."""
        overrides = {
            "UK": "GB", "DE": "DE_LU", "IE": "IE_SEM", "IT": "IT_NORD",
            "NO1": "NO_1", "NO2": "NO_2", "NO3": "NO_3", "NO4": "NO_4", "NO5": "NO_5",
            "SE1": "SE_1", "SE2": "SE_2", "SE3": "SE_3", "SE4": "SE_4",
            "DK1": "DK_1", "DK2": "DK_2", "XK": "XK",
        }
        return overrides.get(code.upper(), code.upper())
    
    @staticmethod
    def _get_db_zone_code(display_code: str) -> str:
        """Map display codes to database zone codes."""
        db_map = {
            "SE1": "SE_1", "SE2": "SE_2", "SE3": "SE_3", "SE4": "SE_4",
            "NO1": "NO_1", "NO2": "NO_2", "NO3": "NO_3", "NO4": "NO_4", "NO5": "NO_5",
            "DK1": "DK_1", "DK2": "DK_2", "UK": "GB",
        }
        return db_map.get(display_code, display_code)
    
    def fetch_from_database_batch(self, target_date: pd.Timestamp, country_codes: List[str]) -> Dict[str, pd.Series]:
        """Fetch prices for multiple zones from database in one query."""
        if not DATAQUERY_AVAILABLE or not country_codes:
            return {code: pd.Series(dtype=float) for code in country_codes}
        
        db_zone_codes = [self._get_db_zone_code(code) for code in country_codes]
        code_mapping = dict(zip(country_codes, db_zone_codes))
        
        try:
            dq = DataQuery(logintype=self.db_logintype)
            
            # Build metadata query
            metadata = {
                'commodity': 'POWER',
                'geography1': ','.join(db_zone_codes),
                'category1': 'Price',
                'category2': 'Day Ahead',
                'measurement_type': 'Actual',
                'source1': 'ENTSOE',
            }
            
            # Build WHERE clause
            metadata_clause = ''
            for k, v in metadata.items():
                if ',' in v:
                    items = ','.join([f"'{vi}'" for vi in v.split(',')])
                    metadata_clause += f' and {k} in ({items})'
                elif '%' in v:
                    metadata_clause += f" and {k} like '{v}'"
                elif v == 'NULL':
                    metadata_clause += f' and {k} is NULL'
                else:
                    metadata_clause += f" and {k}='{v}'"
            
            # Query metadata
            query = f"""select data_id, geography1 from {dq.schema}.{dq.tmetadata}
                        where 1=1 {metadata_clause}"""
            
            with dq.engine.begin() as conn:
                res = pd.read_sql(query, conn)
            
            logger.info(f"[DB Batch] Query returned {len(res)} rows for zones: {db_zone_codes}")
            
            if res.empty:
                return {code: pd.Series(dtype=float) for code in country_codes}
            
            # Build zone -> data_id mapping
            zone_to_data_id = {row['geography1']: row['data_id'] 
                              for _, row in res.iterrows() 
                              if row['geography1'] and row['data_id']}
            
            logger.info(f"[DB Batch] Found data_ids for zones: {list(zone_to_data_id.keys())}")
            
            data_ids = list(zone_to_data_id.values())
            if not data_ids:
                return {code: pd.Series(dtype=float) for code in country_codes}
            
            # Fetch data
            start_date = target_date - pd.Timedelta(hours=4)
            end_date = target_date + pd.Timedelta(hours=28)
            
            result = dq.get_data(by='id', data_id=data_ids, start_date=start_date, 
                                end_date=end_date, querytype='bulk')
            
            if not result:
                return {code: pd.Series(dtype=float) for code in country_codes}
            
            # Process results
            target_day_str = target_date.strftime('%Y-%m-%d')
            output = {}
            
            for display_code, db_zone_code in code_mapping.items():
                if db_zone_code not in zone_to_data_id:
                    output[display_code] = pd.Series(dtype=float)
                    continue
                
                data_id = zone_to_data_id[db_zone_code]
                if data_id not in result:
                    output[display_code] = pd.Series(dtype=float)
                    continue
                
                df = result[data_id]
                if df.empty:
                    output[display_code] = pd.Series(dtype=float)
                    continue
                
                # Process timezone and filter
                df['date'] = pd.to_datetime(df['date'])
                if df['date'].dt.tz is None:
                    df['date'] = df['date'].dt.tz_localize('UTC')
                df['date'] = df['date'].dt.tz_convert('Europe/Brussels')
                df = df.set_index('date')
                
                df_day = df[df.index.strftime('%Y-%m-%d') == target_day_str].copy()
                if df_day.empty:
                    output[display_code] = pd.Series(dtype=float)
                    continue
                
                # Create hourly series
                df_temp = pd.DataFrame({'price': df_day['value']})
                df_temp['hour'] = df_temp.index.hour
                series_by_hour = df_temp.groupby('hour')['price'].mean().reindex(range(24))
                output[display_code] = series_by_hour
            
            logger.info(f"[DB Batch] Fetched {sum(1 for s in output.values() if not s.empty)}/{len(country_codes)} zones")
            return output
            
        except Exception as e:
            logger.warning(f"Error fetching batch prices: {e}")
            return {code: pd.Series(dtype=float) for code in country_codes}
    
    def fetch_from_entsoe(self, country: str, start: pd.Timestamp, end: pd.Timestamp) -> pd.Series:
        """Fetch prices from ENTSOE API with retry logic."""
        api_code = self._map_country_code(country)
        
        try:
            area = lookup_area(api_code)
        except ValueError:
            try:
                area = lookup_area(country)
            except ValueError:
                logger.warning(f"Invalid area code for {country}")
                return pd.Series(dtype=float)
        
        max_retries = 3
        for attempt in range(max_retries):
            try:
                prices = self.entsoe_client.query_day_ahead_prices(area, start=start, end=end)
                break
            except HTTPError as e:
                if e.response.status_code == 429:
                    wait_time = 2 * (2 ** attempt)
                    logger.warning(f"Rate limit for {country}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                    continue
                logger.error(f"HTTP Error for {country}: {e}")
                return pd.Series(dtype=float)
            except NoMatchingDataError:
                logger.info(f"No data for {country}")
                return pd.Series(dtype=float)
            except Exception as e:
                logger.error(f"Error fetching {country}: {e}")
                return pd.Series(dtype=float)
        else:
            logger.error(f"Failed to fetch {country} after {max_retries} retries")
            return pd.Series(dtype=float)
        
        # Process timezone and resample
        if prices.index.tz is None:
            prices = prices.tz_localize('UTC')
        prices = prices.tz_convert('Europe/Brussels')
        
        hourly_prices = prices.resample('h').mean()
        df_temp = pd.DataFrame({'price': hourly_prices})
        df_temp['hour'] = df_temp.index.hour
        series_by_hour = df_temp.groupby('hour')['price'].mean().reindex(range(24))
        
        return series_by_hour
    
    def fetch_from_epex(self, target_date: pd.Timestamp, country_code: str) -> pd.Series:
        """Fetch prices from EPEX via Snowflake."""
        if EPEXQuery is None:
            return pd.Series(dtype=float)
        
        epex_country = {'UK': 'GB'}.get(country_code, country_code)
        
        try:
            epex = EPEXQuery()
            query_start = (target_date - pd.Timedelta(hours=4)).strftime('%Y-%m-%d %H:%M:%S')
            query_end = (target_date + pd.Timedelta(hours=28)).strftime('%Y-%m-%d %H:%M:%S')
            
            logger.info(f"Fetching {epex_country} prices from EPEX...")
            
            df = epex.get_spot_prices(country=epex_country, start_date=query_start, 
                                     end_date=query_end, convert_timezone=False)
            
            if df.empty:
                return pd.Series(dtype=float)
            
            # Process timezone
            if 'TIMESTAMP' in df.columns:
                df['TIMESTAMP'] = pd.to_datetime(df['TIMESTAMP'])
                if df['TIMESTAMP'].dt.tz is None:
                    df['TIMESTAMP'] = df['TIMESTAMP'].dt.tz_localize('UTC')
                df['TIMESTAMP'] = df['TIMESTAMP'].dt.tz_convert('Europe/Brussels')
                df = df.set_index('TIMESTAMP')
            
            # Filter for target date
            target_day_str = target_date.strftime('%Y-%m-%d')
            df_day = df[df.index.strftime('%Y-%m-%d') == target_day_str].copy()
            
            if df_day.empty:
                return pd.Series(dtype=float)
            
            # Resample to hourly
            hourly_prices = df_day['PRICE'].resample('h').mean()
            df_temp = pd.DataFrame({'price': hourly_prices})
            df_temp['hour'] = df_temp.index.hour
            series_by_hour = df_temp.groupby('hour')['price'].mean().reindex(range(24))
            
            return series_by_hour
            
        except Exception as e:
            logger.error(f"Error fetching {country_code} from EPEX: {e}")
            return pd.Series(dtype=float)
    
    def get_gbp_eur_rate(self) -> Optional[float]:
        """Fetch GBP/EUR exchange rate from Bloomberg."""
        if BBGQuery is None:
            return None
        
        try:
            bbg = BBGQuery(p_on_server=True)
            df = bbg.fetch_live(tickers=['GBPEUR Curncy'], fields=['LAST_PRICE'])
            if df is not None and not df.empty and 'LAST_PRICE' in df.columns:
                rate = df['LAST_PRICE'].iloc[0]
                logger.info(f"Fetched GBP/EUR Rate from Bloomberg: {rate}")
                return rate
            else:
                logger.warning("Bloomberg PX_LAST field missing or empty. Returning None.")
                return None
        except Exception as e:
            logger.error(f"Error fetching GBP/EUR rate from Bloomberg: {e}.")
            return None
        return None


class MapGenerator:
    """Generates interactive choropleth maps from price data."""
    
    def generate_html(self, df: pd.DataFrame) -> str:
        """Generate Plotly choropleth map HTML."""
        try:
            base_prices = df.mean()
            features = []
            map_data = []
            
            for zone, price in base_prices.items():
                zone_code = zone[1]
                self._add_feature(zone_code, price, features, map_data)
                
                if zone_code == 'IE':
                    self._add_feature("GB-NIR", price, features, map_data, overlay_id="GB-NIR")
            
            if not map_data:
                return "<div>No map data available</div>"
            
            combined_geojson = {"type": "FeatureCollection", "features": features}
            df_map = pd.DataFrame(map_data)
            
            fig = px.choropleth(
                df_map, geojson=combined_geojson, locations="zone", color="price",
                hover_name="zone", color_continuous_scale="RdYlGn_r", fitbounds="locations"
            )
            
            fig.update_layout(
                geo=dict(showframe=False, showcoastlines=True, showcountries=True, visible=False),
                margin={"r": 0, "t": 0, "l": 0, "b": 0},
                height=900, width=1200, dragmode=False
            )
            fig.update_geos(visible=True, fitbounds="locations")
            
            return fig.to_html(full_html=False, include_plotlyjs='cdn')
            
        except Exception as e:
            logger.error(f"Error generating map: {e}")
            return f"<div>Error generating map: {e}</div>"
    
    def _add_feature(self, code: str, price_val: float, features: list, map_data: list, overlay_id: str = None):
        """Add a GeoJSON feature to the map."""
        geo_path = _load_geojson(code)
        if not geo_path:
            logger.warning(f"No GeoJSON found for {code}")
            return
        
        try:
            with open(geo_path, 'r', encoding='utf-8') as f:
                geo = json.load(f)
            
            if geo.get('type') == 'FeatureCollection':
                feature = geo['features'][0] if geo['features'] else None
            else:
                feature = geo
            
            if feature:
                feat_id = overlay_id if overlay_id else code
                feature['id'] = feat_id
                features.append(feature)
                map_data.append({'zone': feat_id, 'price': price_val})
        except Exception as e:
            logger.warning(f"Failed to load {geo_path}: {e}")


class ReportGenerator:
    """Generates HTML reports with styled tables and maps."""
    
    def __init__(self, map_generator: MapGenerator):
        self.map_generator = map_generator
    
    def generate(self, df: pd.DataFrame, target_date: pd.Timestamp, 
                filename: str = 'spot_price_report.html', 
                send_email: bool = False,
                email_recipients: Optional[str] = None,
                email_dry_run: bool = False) -> Dict[str, Any]:
        """Generate complete HTML report and optionally send via email."""
        if df.empty:
            logger.warning("No data to plot")
            return
        
        # Convert index to string first (before combining)
        df.index = df.index.astype(str)
        
        # Calculate summary statistics
        base = df.mean()
        peak = df.iloc[8:20].mean()
        offpeak = pd.concat([df.iloc[0:8], df.iloc[20:24]]).mean()
        
        # Create summary DataFrame
        spacer = pd.Series([pd.NA] * len(df.columns), index=df.columns)
        df_summary = pd.DataFrame({
            '': spacer,
            'Base': base,
            'Peak': peak,
            'Offpeak': offpeak
        }).T
        df_summary.index.name = 'Hour'
        
        # Combine data (both have string index now)
        df_combined = pd.concat([df, df_summary])
        target_rows = df.index.tolist() + ['Base', 'Peak', 'Offpeak']
        
        # Style the table
        styles = [
            {'selector': 'table', 'props': [
                ('border-collapse', 'collapse'),
                ('font-family', 'Calibri, Arial, sans-serif'),
                ('font-size', '13px'),
                ('width', '100%'),
                ('border', '1px solid #ddd')
            ]},
            {'selector': 'th', 'props': [
                ('background-color', '#f2f2f2'),
                ('color', '#333'),
                ('border', '1px solid #999'),
                ('padding', '8px'),
                ('text-align', 'center'),
                ('font-weight', 'bold')
            ]},
            {'selector': 'td', 'props': [
                ('border', '1px solid #ddd'),
                ('padding', '6px'),
                ('text-align', 'center')
            ]},
            {'selector': 'tr:nth-last-child(-n+3)', 'props': [
                ('font-weight', 'bold'),
                ('border-top', '2px solid #333')
            ]},
            {'selector': 'tr:hover', 'props': [('background-color', '#f5f5f5')]}
        ]
        
        def highlight_nan(val):
            return 'background-color: #e0e0e0 !important' if pd.isna(val) else ''
        
        styler = df_combined.style \
            .background_gradient(cmap='RdYlGn_r', axis=None, 
                               vmin=df.min().min(), vmax=df.max().max(), 
                               subset=pd.IndexSlice[target_rows, :]) \
            .map(highlight_nan) \
            .format("{:.2f}", na_rep="") \
            .set_table_styles(styles) \
            .set_caption(f"Day Ahead Power Prices - {target_date.strftime('%Y-%m-%d')}") \
            .set_properties(**{'width': '60px'})
        
        table_html = styler.to_html()
        map_html = self.map_generator.generate_html(df)
        
        # Generate full HTML
        full_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Spot Price Report</title>
            <style>
                body {{ font-family: Calibri, Arial, sans-serif; margin: 20px; }}
                h2 {{ color: #333; }}
                tr:nth-last-child(4) td, tr:nth-last-child(4) th {{
                    border: none !important;
                    background-color: white !important;
                    height: 15px;
                }}
                tr:nth-last-child(3) td {{ border-top: 3px solid #000 !important; }}
                tr:nth-last-child(1) td {{ border-bottom: 3px solid #000 !important; }}
                tr:nth-last-child(1) td:first-child, tr:nth-last-child(2) td:first-child, 
                tr:nth-last-child(3) td:first-child {{ border-left: 3px solid #000 !important; }}
                tr:nth-last-child(1) td:last-child, tr:nth-last-child(2) td:last-child, 
                tr:nth-last-child(3) td:last-child {{ border-right: 3px solid #000 !important; }}
                tr:nth-last-child(1) td, tr:nth-last-child(2) td, tr:nth-last-child(3) td {{
                    font-weight: bold;
                }}
                .container {{
                    display: flex;
                    flex-direction: column;
                    gap: 30px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div>
                    <h2>Day Ahead Power Prices (€/MWh)</h2>
                    {table_html}
                </div>
            </div>
        </body>
        </html>
        """
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(full_html)
        
        logger.info(f"Report generated: {os.path.abspath(filename)}")
        
        result = {
            "output_file": os.path.abspath(filename),
            "email_sent": False,
            "recipients": None
        }
        
        # Send email if requested
        # Send email if requested
        if send_email and email_recipients:
            try:
                from jain_commods.core.util.emailhelper import send_email
                
                # Read HTML file for BODY
                with open(filename, 'r', encoding='utf-8') as f:
                    html_body = f.read()
                
                subject = f"Spot Price Report - {target_date.strftime('%Y-%m-%d')}"
                
                if email_dry_run:
                    logger.info(f"[DRY RUN] Would send email to {email_recipients} with embedded HTML body")
                else:
                    logger.info(f"Sending email to {email_recipients}...")
                    send_email(
                        recipients=email_recipients,
                        subject=subject,
                        body=html_body,
                        attachment={}
                    )
                    logger.info("Email sent successfully.")
                    result["email_sent"] = True
                    result["recipients"] = email_recipients
                    
            except ImportError:
                logger.warning("emailhelper not available, cannot send email")
            except Exception as e:
                logger.error(f"Failed to send email: {e}")
                import traceback
                traceback.print_exc()
        
        return result


class SpotPriceReport:
    """Main class for generating spot price reports."""
    
    def __init__(self, entsoe_api_key: str = ENTSOE_API_KEY, db_logintype: str = 'prod'):
        self.data_fetcher = PriceDataFetcher(entsoe_api_key, db_logintype)
        self.map_generator = MapGenerator()
        self.report_generator = ReportGenerator(self.map_generator)
        self.regions = REGIONS
    
    def fetch_prices(self, target_date: Optional[pd.Timestamp] = None, 
                    use_database: bool = True) -> pd.DataFrame:
        """Fetch Day Ahead prices for all regions."""
        if target_date is None:
            target_date = pd.Timestamp.now(tz='Europe/Brussels').normalize() + pd.Timedelta(days=1)
        else:
            target_date = pd.Timestamp(target_date)
            if target_date.tzinfo is None:
                target_date = target_date.tz_localize('Europe/Brussels').normalize()
            else:
                target_date = target_date.tz_convert('Europe/Brussels').normalize()
        
        start = target_date
        end = target_date + pd.Timedelta(days=1)
        
        logger.info(f"Fetching Day Ahead prices for {start.date()}...")
        if use_database:
            logger.info("  -> Trying database first, then fallback to APIs...")
        
        data = {}
        
        # Batch database fetch
        db_results = {}
        if use_database:
            countries_to_fetch = []
            for region, countries in self.regions.items():
                for country in countries:
                    if country != "UK":
                        countries_to_fetch.append(country)
            
            if any("UK" in countries for countries in self.regions.values()):
                countries_to_fetch.append("GB")
            
            if countries_to_fetch:
                logger.info(f"[DB Batch] Fetching {len(countries_to_fetch)} zones from database...")
                db_results = self.data_fetcher.fetch_from_database_batch(target_date, countries_to_fetch)
                logger.info(f"[DB Batch] Retrieved {sum(1 for s in db_results.values() if not s.empty)}/{len(countries_to_fetch)} zones")
        
        # Process each country
        for region, countries in self.regions.items():
            for country in countries:
                # Try database first
                if use_database and country != "UK":
                    if country in db_results:
                        db_prices = db_results[country]
                        if not db_prices.empty and not db_prices.isna().all():
                            data[(region, country)] = db_prices
                            logger.info(f"[DB] Successfully fetched {country} from database")
                            continue
                
                # Special handling for UK
                if country == "UK":
                    if use_database and "GB" in db_results:
                        uk_prices = db_results["GB"]
                        if not uk_prices.empty and not uk_prices.isna().all():
                            data[(region, country)] = uk_prices
                            logger.info(f"[DB] Successfully fetched UK (GB) from database")
                            continue
                    
                    # Try EPEX + FX conversion
                    uk_prices_gbp = self.data_fetcher.fetch_from_epex(target_date, "UK")
                    if not uk_prices_gbp.isna().all() and not uk_prices_gbp.empty:
                        if self.data_fetcher.gbp_eur_rate is None:
                            self.data_fetcher.gbp_eur_rate = self.data_fetcher.get_gbp_eur_rate()
                        
                        if self.data_fetcher.gbp_eur_rate:
                            data[(region, country)] = uk_prices_gbp * self.data_fetcher.gbp_eur_rate
                            logger.info(f"Successfully fetched and converted UK prices (Rate: {self.data_fetcher.gbp_eur_rate:.4f})")
                        else:
                            logger.warning("Could not convert UK prices to EUR. Leaving blank.")
                            data[(region, country)] = pd.Series([float('nan')] * 24, index=range(24))
                        continue
                
                # Try ENTSOE API
                prices = self.data_fetcher.fetch_from_entsoe(country, start, end)
                if not prices.empty:
                    data[(region, country)] = prices
                    time.sleep(0.2)  # Polite delay
                    continue
                
                # Try EPEX fallback
                epex_prices = self.data_fetcher.fetch_from_epex(target_date, country)
                if not epex_prices.empty and not epex_prices.isna().all():
                    data[(region, country)] = epex_prices
                    logger.info(f"Successfully fetched {country} from EPEX fallback")
                else:
                    data[(region, country)] = pd.Series([float('nan')] * 24, index=range(24))
        
        # Construct DataFrame
        df = pd.DataFrame(data)
        df.columns = pd.MultiIndex.from_tuples(df.columns, names=['Region', 'Country'])
        df.index.name = 'Hour'
        
        return df
    
    def generate_report(self, df: pd.DataFrame, target_date: pd.Timestamp, 
                       filename: str = 'spot_price_report.html',
                       send_email: bool = False,
                       email_recipients: Optional[str] = None,
                       email_dry_run: bool = False) -> Dict[str, Any]:
        """Generate HTML report and optionally send via email."""
        return self.report_generator.generate(df, target_date, filename, send_email, email_recipients, email_dry_run)


# Convenience functions for backward compatibility
def get_spot_prices(target_date=None, use_database=True, db_logintype='prod'):
    """Convenience function for fetching spot prices."""
    report = SpotPriceReport(db_logintype=db_logintype)
    return report.fetch_prices(target_date, use_database)


def generate_html_report(df, target_date, filename='spot_price_report.html',
                         send_email=False, email_recipients=None, email_dry_run=False):
    """Convenience function for generating HTML report."""
    map_generator = MapGenerator()
    report_generator = ReportGenerator(map_generator)
    return report_generator.generate(df, target_date, filename, send_email, email_recipients, email_dry_run)


if __name__ == "__main__":
    target_date = pd.Timestamp.now(tz='Europe/Brussels').normalize() + pd.Timedelta(days=1)
    
    report = SpotPriceReport()
    df = report.fetch_prices(target_date)
    
    logger.info("Data fetched. Generating HTML report...")
    report.generate_report(df, target_date)
