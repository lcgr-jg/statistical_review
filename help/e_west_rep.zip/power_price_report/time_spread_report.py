import sys
import os
# Ensure we use local eu_corelib if available
corelib_path = 'c:/Users/Michael.Kane/OneDrive - Jain Global/Projects/eu_corelib'
if os.path.exists(corelib_path) and corelib_path not in sys.path:
    sys.path.insert(0, corelib_path)

from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery

from datetime import datetime, timedelta
from calendar import monthrange
from dateutil.relativedelta import relativedelta
import snowflake.connector
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.gridspec as gridspec
import matplotlib as mpl
from matplotlib.patches import Rectangle

# Monkey-patch snowflake connector to bypass SSL/OCSP checks
_original_connect = snowflake.connector.connect
def insecure_connect(*args, **kwargs):
    kwargs['insecure_mode'] = True
    return _original_connect(*args, **kwargs)
snowflake.connector.connect = insecure_connect

import warnings
warnings.filterwarnings('ignore')

# Distinct color palette for spreads - highly distinguishable colors
SPREAD_COLORS = [
    '#1f77b4',  # Blue
    '#d62728',  # Red
    '#2ca02c',  # Green
    '#ff7f0e',  # Orange
    '#9467bd',  # Purple
    '#8c564b',  # Brown
    '#e377c2',  # Pink
    '#17becf',  # Cyan
    '#bcbd22',  # Olive
    '#7f7f7f',  # Gray
]

def get_spread_colormap(n_spreads):
    """Return distinct colors for spreads - highly distinguishable."""
    return SPREAD_COLORS[:n_spreads]

def format_contract_name(contract):
    """Format contract name from 'JAN-26' to 'JAN 26'."""
    return contract.replace('-', ' ')

def format_spread_label(front_contract, back_contract):
    """Format spread label as 'JAN 26 - FEB 26'."""
    front = format_contract_name(front_contract)
    back = format_contract_name(back_contract)
    return f"{front} - {back}"



# Color palette for years (for SEAG charts)
YEAR_COLORS = {
    2020: '#1f77b4',
    2021: '#ff7f0e',
    2022: '#2ca02c',
    2023: '#d62728',
    2024: '#9467bd',
    2025: '#8c564b',
    2026: '#e377c2',
    2027: '#7f7f7f',
}

# Countries to include
COUNTRIES = ['FR', 'DE']

# Tenor configurations
TENOR_CONFIG = {
    'Monthly': {
        'prefix': 'M',
        'spreads': [(1, 2), (2, 3), (3, 4), (4, 5), (5, 6)],  # M+1-M+2, M+2-M+3, etc.
    },
    'Quarterly': {
        'prefix': 'Q', 
        'spreads': [(1, 2), (2, 3), (3, 4)],  # Q+1-Q+2, Q+2-Q+3, Q+3-Q+4
    },
    'Calendar': {
        'prefix': 'Cal',
        'spreads': [(1, 2), (2, 3)],  # Cal+1-Cal+2, Cal+2-Cal+3
    },
}


class DataLoader:
    def __init__(self):
        self.eex = EEXQuery()
    
    def get_contract_prices(self, country_code, start_date=None, end_date=None, profile='Base'):
        """
        Get all contract prices with parsed tenor information.
        
        Returns DataFrame with columns: trading_day, tenor_type, delivery_start, delivery_year, strip, price
        """
        print(f"  Fetching contract prices for {country_code}...")
        
        if start_date is None:
            start_date = datetime(2020, 1, 1)
        if end_date is None:
            end_date = datetime.now()
            
        try:
            # Get all strip prices
            df = self.eex.get_strip_prices(
                country_code=country_code.lower(),
                profile=profile,
                start_date=start_date,
                end_date=end_date
            )
            
            if df.empty:
                print(f"  Warning: No EEX data for {country_code}")
                return pd.DataFrame()
            
            # Standardize column names
            df.columns = [c.lower() for c in df.columns]
            
            date_col = 'trading_day' if 'trading_day' in df.columns else 'trade_date'
            price_col = 'settlement_price' if 'settlement_price' in df.columns else 'price'
            strip_col = 'strip' if 'strip' in df.columns else 'contract'
            
            df[date_col] = pd.to_datetime(df[date_col])
            df = df[[date_col, strip_col, price_col]].copy()
            df.columns = ['trading_day', 'strip', 'price']
            
            # Parse strips
            df = self._parse_strips(df)
            
            return df
            
        except Exception as e:
            print(f"  Error fetching contract prices: {e}")
            import traceback
            traceback.print_exc()
            return pd.DataFrame()
    
    def get_specific_spreads(self, df, as_of_date, tenor_type):
        """
        Calculate spreads for SPECIFIC contracts based on as_of_date positions.
        
        At as_of_date, determines which contracts are M+1, M+2, etc.
        Then tracks those SPECIFIC contracts throughout history.
        
        Returns DataFrame with columns: trading_day, position, spread, front_contract, back_contract
        """
        if df.empty:
            return pd.DataFrame()
        
        # Filter to tenor type
        tenor_df = df[df['tenor_type'] == tenor_type].copy()
        if tenor_df.empty:
            return pd.DataFrame()
        
        # Get contracts available on the as_of date (or closest prior date)
        ref_dates = tenor_df[tenor_df['trading_day'] <= as_of_date]['trading_day'].unique()
        if len(ref_dates) == 0:
            return pd.DataFrame()
        
        ref_date = max(ref_dates)
        ref_data = tenor_df[tenor_df['trading_day'] == ref_date].sort_values('delivery_start')
        
        if ref_data.empty:
            return pd.DataFrame()
        
        # Assign positions at reference date
        ref_data = ref_data.reset_index(drop=True)
        ref_data['position'] = range(1, len(ref_data) + 1)
        
        # Get spread configs for this tenor type
        if tenor_type == 'M':
            spread_configs = TENOR_CONFIG['Monthly']['spreads']
        elif tenor_type == 'Q':
            spread_configs = TENOR_CONFIG['Quarterly']['spreads']
        else:
            spread_configs = TENOR_CONFIG['Calendar']['spreads']
        
        results = []
        
        for front_n, back_n in spread_configs:
            front_row = ref_data[ref_data['position'] == front_n]
            back_row = ref_data[ref_data['position'] == back_n]
            
            if front_row.empty or back_row.empty:
                continue
            
            front_delivery = front_row['delivery_start'].iloc[0]
            back_delivery = back_row['delivery_start'].iloc[0]
            front_strip = front_row['strip'].iloc[0]
            back_strip = back_row['strip'].iloc[0]
            
            # Get prices for these SPECIFIC contracts throughout history
            front_prices = tenor_df[tenor_df['delivery_start'] == front_delivery][['trading_day', 'price']].copy()
            front_prices = front_prices.rename(columns={'price': 'front_price'})
            
            back_prices = tenor_df[tenor_df['delivery_start'] == back_delivery][['trading_day', 'price']].copy()
            back_prices = back_prices.rename(columns={'price': 'back_price'})
            
            # Merge
            merged = pd.merge(front_prices, back_prices, on='trading_day', how='inner')
            merged['spread'] = merged['front_price'] - merged['back_price']
            merged['position'] = front_n
            merged['front_contract'] = front_strip
            merged['back_contract'] = back_strip
            merged['front_delivery'] = front_delivery
            merged['back_delivery'] = back_delivery
            
            results.append(merged)
        
        if not results:
            return pd.DataFrame()
        
        return pd.concat(results, ignore_index=True)
    
    def _parse_strips(self, df):
        """Parse strip names to extract tenor type and delivery period."""
        
        # Month mapping
        month_map = {
            'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
            'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12
        }
        
        # Quarter to start month
        quarter_start = {'Q1': 1, 'Q2': 4, 'Q3': 7, 'Q4': 10}
        
        results = []
        
        for _, row in df.iterrows():
            strip = str(row['strip']).upper()
            
            if '-' not in strip:
                continue
                
            parts = strip.split('-')
            tenor = parts[0]
            year_suffix = parts[1] if len(parts) > 1 else ''
            
            if not year_suffix.isdigit():
                continue
                
            year = 2000 + int(year_suffix) if int(year_suffix) < 50 else 1900 + int(year_suffix)
            
            # Determine tenor type and delivery start
            if tenor in month_map:
                tenor_type = 'M'
                delivery_start = datetime(year, month_map[tenor], 1)
            elif tenor in quarter_start:
                tenor_type = 'Q'
                delivery_start = datetime(year, quarter_start[tenor], 1)
            elif tenor == 'CAL':
                tenor_type = 'CAL'
                delivery_start = datetime(year, 1, 1)
            else:
                continue
            
            results.append({
                'trading_day': row['trading_day'],
                'strip': row['strip'],
                'price': row['price'],
                'tenor_type': tenor_type,
                'delivery_start': delivery_start,
                'delivery_year': year,
            })
        
        return pd.DataFrame(results)
    
    def get_contract_volumes(self, country_code, start_date=None, end_date=None, profile='Base'):
        """
        Get volume data for contracts with parsed tenor information.
        
        Returns DataFrame with columns: trading_day, tenor_type, delivery_start, delivery_year, strip, traded_volume
        """
        print(f"  Fetching contract volumes for {country_code}...")
        
        if start_date is None:
            start_date = datetime(2020, 1, 1)
        if end_date is None:
            end_date = datetime.now()
            
        try:
            # Get all strip volumes
            df = self.eex.get_strip_prices(
                country_code=country_code.lower(),
                profile=profile,
                start_date=start_date,
                end_date=end_date
            )
            
            if df.empty:
                print(f"  Warning: No EEX volume data for {country_code}")
                return pd.DataFrame()
            
            # Standardize column names
            df.columns = [c.lower() for c in df.columns]
            
            date_col = 'trading_day' if 'trading_day' in df.columns else 'trade_date'
            volume_col = 'traded_volume'
            strip_col = 'strip' if 'strip' in df.columns else 'contract'
            maturity_col = 'maturity' if 'maturity' in df.columns else None
            
            df[date_col] = pd.to_datetime(df[date_col])
            
            required_cols = [date_col, strip_col, volume_col]
            if maturity_col:
                required_cols.append(maturity_col)
            
            df = df[required_cols].copy()
            
            if maturity_col:
                df.columns = ['trading_day', 'strip', 'traded_volume', 'maturity']
            else:
                df.columns = ['trading_day', 'strip', 'traded_volume']
            
            # Parse strips to get tenor info
            df = self._parse_strips_for_volumes(df)
            
            return df
            
        except Exception as e:
            print(f"  Error fetching contract volumes: {e}")
            import traceback
            traceback.print_exc()
            return pd.DataFrame()
    
    def _parse_strips_for_volumes(self, df):
        """Parse strip names for volume data."""
        
        # Month mapping
        month_map = {
            'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
            'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12
        }
        
        results = []
        
        for _, row in df.iterrows():
            strip = str(row['strip']).upper()
            
            if '-' not in strip:
                continue
                
            parts = strip.split('-')
            tenor = parts[0]
            year_suffix = parts[1] if len(parts) > 1 else ''
            
            if not year_suffix.isdigit():
                continue
                
            year = 2000 + int(year_suffix) if int(year_suffix) < 50 else 1900 + int(year_suffix)
            
            # Determine tenor type and delivery start (only monthly for M+1 vs M+2)
            if tenor in month_map:
                tenor_type = 'M'
                delivery_start = datetime(year, month_map[tenor], 1)
                
                # Calculate end of trading month from maturity if available
                if 'maturity' in row and pd.notna(row['maturity']):
                    maturity_str = str(row['maturity'])
                    if len(maturity_str) >= 7:  # Format: YYYY-MM
                        try:
                            maturity_date = pd.to_datetime(maturity_str)
                            # Trading typically ends last business day of maturity month
                            end_of_maturity_month = maturity_date + pd.offsets.MonthEnd(0)
                        except:
                            # Default to end of delivery month
                            end_of_maturity_month = datetime(year, month_map[tenor], monthrange(year, month_map[tenor])[1])
                    else:
                        end_of_maturity_month = datetime(year, month_map[tenor], monthrange(year, month_map[tenor])[1])
                else:
                    # Default to end of delivery month
                    end_of_maturity_month = datetime(year, month_map[tenor], monthrange(year, month_map[tenor])[1])
                
                results.append({
                    'trading_day': row['trading_day'],
                    'strip': row['strip'],
                    'traded_volume': row['traded_volume'],
                    'tenor_type': tenor_type,
                    'delivery_start': delivery_start,
                    'delivery_year': year,
                    'maturity_end': end_of_maturity_month,
                })
        
        return pd.DataFrame(results)


class Report:
    """
    Generate time spread reports with SEAG charts and time series.
    """
    def __init__(self, loader=None):
        self.loader = loader if loader else DataLoader()
    
    def generate_report(self, countries=None, start_date=None, end_date=None,
                        as_of=None, output_file='time_spread_report.pdf'):
        """
        Generate PDF report with time spread analysis.
        
        Args:
            as_of: Reference date for determining contract positions. 
                   Filters out trading days after this date.
                   If None, uses today.
        """
        if countries is None:
            countries = COUNTRIES
        if start_date is None:
            start_date = datetime(2020, 1, 1)
        if end_date is None:
            end_date = datetime.now()
        if as_of is None:
            as_of = datetime.now()
            
        print(f"Generating Time Spread Report...")
        print(f"  Countries: {countries}")
        print(f"  Period: {start_date.date()} to {end_date.date()}")
        print(f"  As of: {as_of.date()}")
        
        with PdfPages(output_file) as pdf:
            for country in countries:
                print(f"\nProcessing {country}...")
                
                # Fetch raw contract prices once per country
                df = self.loader.get_contract_prices(country, start_date, end_date)
                
                if df.empty:
                    print(f"  No data for {country}, skipping...")
                    continue
                
                # Monthly spreads section
                self._create_time_series_page(pdf, country, df, 'M', 'Monthly', as_of)
                
                # Quarterly spreads section  
                self._create_time_series_page(pdf, country, df, 'Q', 'Quarterly', as_of)
                
                # Calendar spreads section
                self._create_time_series_page(pdf, country, df, 'CAL', 'Calendar', as_of)
                
                # Volume analysis section
                self._create_volume_analysis_page(pdf, country, start_date, end_date)
                
                # Volume distribution analysis section
                self._create_volume_distribution_page(pdf, country, start_date, end_date)
        
        print(f"\nReport saved to {output_file}")
    
    def _add_header_footer(self, fig, title):
        """Add header and footer in the style of price_report.py"""
        # Header
        header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig.transFigure, 
                                  facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(header_rect)
        fig.text(0.5, 0.98, title, fontsize=20, fontweight='bold', 
                 va='center', ha='center', color='white', zorder=1002)
        
        # Footer
        footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig.transFigure, 
                                  facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(footer_rect)
        fig.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', 
                 fontsize=12, va='center', ha='right', color='white', zorder=1002)
    
    def _create_time_series_page(self, pdf, country, df, tenor_type, tenor_name, as_of):
        """
        Create a time series page showing spread evolution.
        Top chart: All spreads on one plot
        Below: Stacked comparison charts showing consecutive spread pairs with fill between
        
        Uses SPECIFIC contract pairs based on as_of date to avoid roll jumps.
        """
        print(f"  Creating {tenor_name} time series page for {country}...")
        
        # Filter to this tenor type
        tenor_df = df[df['tenor_type'] == tenor_type].copy()
        
        if tenor_df.empty:
            print(f"    No {tenor_name} data available")
            return
        
        # Get spreads for as_of date
        start = as_of - timedelta(days=90)
        spreads = self.loader.get_specific_spreads(tenor_df, as_of, tenor_type)
        if spreads.empty:
            print(f"    No spread data available")
            return
        
        spreads = spreads[(spreads['trading_day'] <= as_of) & 
                          (spreads['trading_day'] >= start)]
        
        # Get unique positions
        positions = sorted(spreads['position'].unique())
        n_comparisons = len(positions) - 1  # Number of consecutive pairs to compare
        
        if n_comparisons < 1:
            print(f"    Not enough spreads to compare")
            return
        
        # Build consistent color mapping for all spread labels
        # Map each unique contract pair label to a color from viridis
        spread_color_map = {}
        n_spreads = len(positions)
        colors = get_spread_colormap(n_spreads)
        for idx, pos in enumerate(positions):
            pos_data = spreads[spreads['position'] == pos].iloc[0]
            label = format_spread_label(pos_data['front_contract'], pos_data['back_contract'])
            spread_color_map[label] = colors[idx]
        
        # Create figure with stacked charts (1 overview + n comparisons)
        n_rows = 1 + n_comparisons
        fig = plt.figure(figsize=(24, 5 + 4.5 * n_comparisons))
        fig.patch.set_facecolor('white')
        
        self._add_header_footer(fig, f"{country} Power: {tenor_name} Time Spreads - Consecutive Pair Analysis")
        
        gs = gridspec.GridSpec(n_rows, 1, height_ratios=[1.2] + [1] * n_comparisons, 
                               hspace=0.35, top=0.94, bottom=0.06, left=0.06, right=0.94)
        
        # Top chart: All spreads overview
        ax_overview = fig.add_subplot(gs[0])
        self._plot_spread_chart(ax_overview, spreads, tenor_type, as_of, 
                                title=f"All Spreads: As of {as_of.strftime('%d-%b-%Y')} (Last 90 Days)", 
                                is_main=True, color_map=spread_color_map)
        
        # Comparison charts: Each consecutive pair
        for i in range(n_comparisons):
            ax = fig.add_subplot(gs[i + 1])
            pos1 = positions[i]
            pos2 = positions[i + 1]
            self._plot_spread_comparison(ax, spreads, pos1, pos2, spread_color_map)
        
        pdf.savefig(fig)
        plt.close()
    
    def _plot_spread_comparison(self, ax, spreads, pos1, pos2, color_map):
        """
        Plot two consecutive spreads with fill between.
        Green fill when spread1 > spread2, red fill when spread1 < spread2.
        Uses color_map for consistent colors across all plots.
        """
        # Get data for each position
        spread1 = spreads[spreads['position'] == pos1].set_index('trading_day')['spread'].sort_index()
        spread2 = spreads[spreads['position'] == pos2].set_index('trading_day')['spread'].sort_index()
        
        # Get contract labels
        spread1_data = spreads[spreads['position'] == pos1].iloc[0]
        spread2_data = spreads[spreads['position'] == pos2].iloc[0]
        label1 = format_spread_label(spread1_data['front_contract'], spread1_data['back_contract'])
        label2 = format_spread_label(spread2_data['front_contract'], spread2_data['back_contract'])
        
        # Align the two series
        common_idx = spread1.index.intersection(spread2.index)
        spread1 = spread1.loc[common_idx]
        spread2 = spread2.loc[common_idx]
        
        if len(common_idx) == 0:
            ax.text(0.5, 0.5, 'No overlapping data', ha='center', va='center', fontsize=12)
            return
        
        dates = common_idx.to_numpy()
        s1 = spread1.values
        s2 = spread2.values
        
        # Add alternating month shading and vertical lines
        min_date = pd.Timestamp(dates.min())
        max_date = pd.Timestamp(dates.max())
        current_date = datetime(min_date.year, min_date.month, 1)
        month_idx = 0
        
        while current_date <= max_date:
            month_start = max(current_date, min_date.to_pydatetime())
            if current_date.month == 12:
                next_month = datetime(current_date.year + 1, 1, 1)
            else:
                next_month = datetime(current_date.year, current_date.month + 1, 1)
            month_end = min(next_month - timedelta(days=1), max_date.to_pydatetime())
            
            # Alternating gray shading
            if month_idx % 2 == 0:
                ax.axvspan(month_start, month_end + timedelta(days=1), 
                           alpha=0.15, color='#888888', zorder=0)
            
            # Vertical line at month boundary
            if next_month <= max_date.to_pydatetime():
                ax.axvline(next_month, color='#666666', linewidth=0.8, linestyle='-', zorder=1)
            
            current_date = next_month
            month_idx += 1
        
        # Plot the two lines using consistent colors from color_map
        color1 = color_map.get(label1, '#1f77b4')
        color2 = color_map.get(label2, '#ff7f0e')
        ax.plot(dates, s1, label=label1, color=color1, linewidth=2.5, zorder=3)
        ax.plot(dates, s2, label=label2, color=color2, linewidth=2.5, zorder=3)
        
        # Fill between: green where spread1 > spread2, red where spread1 < spread2
        ax.fill_between(dates, s1, s2, where=(s1 >= s2), 
                        color='#2ecc71', alpha=0.4, interpolate=True)
        ax.fill_between(dates, s1, s2, where=(s1 < s2), 
                        color='#e74c3c', alpha=0.4, interpolate=True)
        
        # Formatting
        ax.set_title(f"{label1}  vs  {label2}", fontsize=13, fontweight='bold', pad=5)
        ax.set_ylabel('Spread (€/MWh)', fontsize=11, fontweight='bold')
        
        # X-axis formatting
        import matplotlib.dates as mdates
        ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.MO, interval=2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=9, fontweight='bold')
        plt.setp(ax.get_yticklabels(), fontsize=9, fontweight='bold')
        
        # Grid and zero line
        ax.grid(True, linestyle=':', alpha=0.4)
        ax.axhline(0, color='black', linewidth=0.8, linestyle='-')
        
        # Legend (only spread labels, no fill descriptions)
        ax.legend(loc='upper left', fontsize=9, framealpha=0.9)
    
    def _plot_spread_chart(self, ax, spread_df, tenor_type, as_of, title, is_main=True, color_map=None):
        """
        Plot a spread time series chart on the given axes.
        
        spread_df: Output from get_specific_spreads() with columns:
                   trading_day, position, spread, front_contract, back_contract
        color_map: Optional dict mapping spread labels to colors for consistency
        
        Uses sequential colormap (viridis) for intuitive "near to far" visualization.
        """
        if spread_df.empty:
            ax.text(0.5, 0.5, 'No Data', ha='center', va='center', fontsize=14)
            ax.set_title(title, fontsize=14 if is_main else 11, fontweight='bold')
            return
        
        # Get unique positions sorted (1=front spread, 2=next, etc.)
        positions = sorted(spread_df['position'].unique())
        n_spreads = len(positions)
        
        # Generate sequential colors if no color_map provided
        if color_map is None:
            colors = get_spread_colormap(n_spreads)
        
        for idx, position in enumerate(positions):
            pos_data = spread_df[spread_df['position'] == position].sort_values('trading_day')
            
            if pos_data.empty:
                continue
            
            # Get contract labels
            front_contract = pos_data['front_contract'].iloc[0]
            back_contract = pos_data['back_contract'].iloc[0]
            label = format_spread_label(front_contract, back_contract)
            
            # Use color_map if provided, otherwise use generated colors
            if color_map and label in color_map:
                color = color_map[label]
            else:
                color = colors[idx] if color_map is None else '#333333'
            
            linewidth = 2.5 if is_main else 1.5
            
            ax.plot(pos_data['trading_day'], pos_data['spread'], 
                    label=label, color=color, linewidth=linewidth, alpha=0.9)
        
        # Format axes
        if is_main:
            ax.set_xlabel('Date', fontsize=14, fontweight='bold')
            ax.set_ylabel('Spread (€/MWh)', fontsize=14, fontweight='bold')
            fontsize_ticks = 11
            fontsize_legend = 12
        else:
            ax.set_xlabel('', fontsize=10)
            ax.set_ylabel('€/MWh', fontsize=10, fontweight='bold')
            fontsize_ticks = 9
            fontsize_legend = 9
        
        ax.set_title(title, fontsize=14 if is_main else 11, fontweight='bold', pad=8)
        
        # X-axis formatting (90 days of data)
        import matplotlib.dates as mdates
        if is_main:
            ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.MO, interval=2))
        else:
            ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.MO, interval=3))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=fontsize_ticks, fontweight='bold')
        plt.setp(ax.get_yticklabels(), fontsize=fontsize_ticks, fontweight='bold')
        
        # Add alternating month shading and vertical lines
        if not spread_df.empty:
            min_date = spread_df['trading_day'].min()
            max_date = spread_df['trading_day'].max()
            
            # Find all month boundaries in the range
            current_date = datetime(min_date.year, min_date.month, 1)
            month_idx = 0
            while current_date <= max_date:
                month_start = max(current_date, min_date)
                # Next month start
                if current_date.month == 12:
                    next_month = datetime(current_date.year + 1, 1, 1)
                else:
                    next_month = datetime(current_date.year, current_date.month + 1, 1)
                month_end = min(next_month - timedelta(days=1), max_date)
                
                # Alternating gray shading
                if month_idx % 2 == 0:
                    ax.axvspan(month_start, month_end + timedelta(days=1), 
                               alpha=0.15, color='#888888', zorder=0)
                
                # Vertical line at month boundary
                if next_month <= max_date:
                    ax.axvline(next_month, color='#666666', linewidth=0.8, linestyle='-', zorder=1)
                
                current_date = next_month
                month_idx += 1
        
        # Grid and zero line
        ax.grid(True, linestyle=':', alpha=0.5)
        ax.axhline(0, color='black', linewidth=0.8, linestyle='-')
        
        # Legend
        ncol = 2 if is_main else 1
        ax.legend(loc='upper left', fontsize=fontsize_legend, framealpha=0.9, ncol=ncol)
        
        # Format axes
        if is_main:
            ax.set_xlabel('Date', fontsize=14, fontweight='bold')
            ax.set_ylabel('Spread (€/MWh)', fontsize=14, fontweight='bold')
            fontsize_ticks = 11
            fontsize_legend = 12
        else:
            ax.set_xlabel('', fontsize=10)
            ax.set_ylabel('€/MWh', fontsize=10, fontweight='bold')
            fontsize_ticks = 9
            fontsize_legend = 9
        
        ax.set_title(title, fontsize=14 if is_main else 11, fontweight='bold', pad=8)
        
        # X-axis formatting
        import matplotlib.dates as mdates
        if is_main:
            ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.MO, interval=2))  # Every 2 weeks
        else:
            ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.MO, interval=3))  # Every 3 weeks
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=fontsize_ticks, fontweight='bold')
        plt.setp(ax.get_yticklabels(), fontsize=fontsize_ticks, fontweight='bold')
        
        # Grid and zero line
        ax.grid(True, linestyle=':', alpha=0.5)
        ax.axhline(0, color='black', linewidth=0.8, linestyle='-')
        
        # Legend
        ncol = 2 if is_main else 1
        ax.legend(loc='upper left', fontsize=fontsize_legend, framealpha=0.9, ncol=ncol)
    
    def _create_volume_analysis_page(self, pdf, country, start_date, end_date):
        """
        Create a page showing volume analysis between M+1 and M+2 contracts.
        
        Creates a 4x3 grid showing the last 12 calendar months.
        Each chart shows all trading dates within that month:
        - X-axis: trading_date
        - Y-axis (primary): traded volume (M+1 and M+2 as lines)
        - Y-axis (secondary): volume difference (M+1 - M+2 as bars)
        """
        print(f"  Creating volume analysis page for {country}...")
        
        # Fetch volume data from Jan 2025 to today
        start_date = datetime(2025, 1, 1)
        end_date = datetime.now()
        
        volume_df = self.loader.get_contract_volumes(country, start_date, end_date)
        
        if volume_df.empty:
            print(f"    No volume data available")
            return
        
        # Filter to monthly contracts only
        monthly_volumes = volume_df[volume_df['tenor_type'] == 'M'].copy()
        
        if monthly_volumes.empty:
            print(f"    No monthly volume data available")
            return
        
        # Get unique calendar months from trading dates
        monthly_volumes['year_month'] = monthly_volumes['trading_day'].dt.to_period('M')
        calendar_months = sorted(monthly_volumes['year_month'].unique())
        
        # Take the last 12 calendar months
        selected_months = calendar_months[-12:]
        
        if len(selected_months) < 12:
            print(f"    Only {len(selected_months)} months available, proceeding...")
        
        # Create 4x3 grid figure
        fig = plt.figure(figsize=(24, 24))
        fig.patch.set_facecolor('white')
        
        self._add_header_footer(fig, f"{country} Power: Volume Analysis - M+1 vs M+2 (Last 12 Months)")
        
        gs = gridspec.GridSpec(4, 3, hspace=0.35, wspace=0.25, top=0.94, bottom=0.05, left=0.06, right=0.96)
        
        # Plot each of the last 12 calendar months
        for idx, year_month in enumerate(selected_months):
            row = idx // 3
            col = idx % 3
            ax = fig.add_subplot(gs[row, col])
            
            self._plot_volume_chart(ax, monthly_volumes, year_month, country)
        
        pdf.savefig(fig)
        plt.close()
    
    def _plot_volume_chart(self, ax, volume_df, year_month, country):
        """
        Plot volume comparison for a specific calendar month.
        
        For each trading date in the calendar month:
        - Determine M+1 and M+2 contracts
        - Plot their volumes as lines
        - Plot difference as bars
        - X-axis: days until end of month
        
        Args:
            year_month: pandas Period object representing the calendar month
        """
        # Filter to trading dates within this calendar month
        month_data = volume_df[volume_df['year_month'] == year_month].copy()
        
        if month_data.empty:
            ax.text(0.5, 0.5, 'No Data', ha='center', va='center', fontsize=12)
            ax.set_title(f"{year_month}", fontsize=11, fontweight='bold')
            return
        
        # Determine M+1 and M+2 contracts for this calendar month
        # M+1 = next month, M+2 = month after that
        calendar_date = year_month.to_timestamp()
        m1_delivery = calendar_date + relativedelta(months=1)
        m2_delivery = calendar_date + relativedelta(months=2)
        
        # Get end of this calendar month
        month_end = calendar_date + pd.offsets.MonthEnd(0)
        
        # Format contract names (e.g., JAN-25, FEB-25)
        month_names = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 
                       'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
        m1_contract = f"{month_names[m1_delivery.month - 1]}-{str(m1_delivery.year)[2:]}"
        m2_contract = f"{month_names[m2_delivery.month - 1]}-{str(m2_delivery.year)[2:]}"
        
        # Get all unique trading dates in this month
        trading_dates = sorted(month_data['trading_day'].unique())
        
        m1_volumes = []
        m2_volumes = []
        days_until_month_end = []
        
        for trading_date in trading_dates:
            day_data = month_data[month_data['trading_day'] == trading_date]
            
            # Get M+1 volume
            m1_row = day_data[day_data['strip'] == m1_contract]
            m1_vol = m1_row['traded_volume'].iloc[0] if not m1_row.empty and pd.notna(m1_row['traded_volume'].iloc[0]) else None
            
            # Get M+2 volume
            m2_row = day_data[day_data['strip'] == m2_contract]
            m2_vol = m2_row['traded_volume'].iloc[0] if not m2_row.empty and pd.notna(m2_row['traded_volume'].iloc[0]) else None
            
            # Only include if both volumes are available
            if m1_vol is not None and m2_vol is not None:
                # Calculate days until end of month
                days_left = (month_end - trading_date).days
                days_until_month_end.append(days_left)
                m1_volumes.append(m1_vol)
                m2_volumes.append(m2_vol)
        
        if not days_until_month_end:
            ax.text(0.5, 0.5, f'No data for {m1_contract} and {m2_contract}', 
                   ha='center', va='center', fontsize=10)
            ax.set_title(f"{year_month}", fontsize=11, fontweight='bold')
            return
        
        # Convert to arrays for plotting
        days_until_month_end = np.array(days_until_month_end)
        m1_volumes = np.array(m1_volumes)
        m2_volumes = np.array(m2_volumes)
        volume_diff = m1_volumes - m2_volumes
        
        # Create twin axis for bars
        ax2 = ax.twinx()
        
        # Plot bars for difference
        bar_colors = ['#2ecc71' if diff >= 0 else '#e74c3c' for diff in volume_diff]
        ax2.bar(days_until_month_end, volume_diff, width=0.8, color=bar_colors, alpha=0.3, label='M+1 - M+2 Diff')
        
        # Plot lines for volumes
        ax.plot(days_until_month_end, m1_volumes, 'o-', color='#1f77b4', linewidth=2, 
                markersize=6, label=f'{m1_contract}', zorder=3)
        ax.plot(days_until_month_end, m2_volumes, 's-', color='#ff7f0e', linewidth=2, 
                markersize=6, label=f'{m2_contract}', zorder=3)
        
        # Formatting
        ax.set_xlabel('Days Until End of Month', fontsize=10, fontweight='bold')
        ax.set_ylabel('Traded Volume', fontsize=10, fontweight='bold', color='black')
        ax2.set_ylabel('Volume Difference (M+1 - M+2)', fontsize=9, fontweight='bold', color='gray')
        
        ax.tick_params(axis='y', labelcolor='black')
        ax2.tick_params(axis='y', labelcolor='gray')
        
        # Set title with calendar month
        title = f"{year_month.strftime('%b %Y')}\n{m1_contract} vs {m2_contract}"
        ax.set_title(title, fontsize=10, fontweight='bold', pad=8)
        
        # Grid
        ax.grid(True, linestyle=':', alpha=0.4, axis='y')
        ax.axhline(0, color='black', linewidth=0.5, linestyle='-', alpha=0.3)
        
        # Reverse x-axis so earlier dates (more days left) are on the left
        ax.set_xlim(max(days_until_month_end) + 1, min(days_until_month_end) - 1)
        
        # Format x-axis
        plt.setp(ax.get_xticklabels(), fontsize=8, fontweight='bold')
        
        # Legend
        lines1, labels1 = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=8, framealpha=0.9)
        
        # Format tick labels
        plt.setp(ax.get_yticklabels(), fontsize=8, fontweight='bold')
        plt.setp(ax2.get_yticklabels(), fontsize=8, fontweight='bold')
    
    def _create_volume_distribution_page(self, pdf, country, start_date, end_date):
        """
        Create a page showing distribution of volume differences vs days to end of trading month.
        
        Investigates whether there are jumps in volume differences as the month progresses.
        Creates:
        1. Scatter plot showing M+1 and M+2 volumes vs days until end of month
        2. Candlestick chart showing average volume difference by 5-day bins
        """
        print(f"  Creating volume distribution analysis page for {country}...")
        
        # Fetch volume data from Jan 2025 to today
        start_date = datetime(2025, 1, 1)
        end_date = datetime.now()
        
        volume_df = self.loader.get_contract_volumes(country, start_date, end_date)
        
        if volume_df.empty:
            print(f"    No volume data available")
            return
        
        # Filter to monthly contracts only
        monthly_volumes = volume_df[volume_df['tenor_type'] == 'M'].copy()
        
        if monthly_volumes.empty:
            print(f"    No monthly volume data available")
            return
        
        # Collect all data points: (days_until_month_end, m1_volume, m2_volume, volume_diff)
        all_data = []
        
        monthly_volumes['year_month'] = monthly_volumes['trading_day'].dt.to_period('M')
        calendar_months = sorted(monthly_volumes['year_month'].unique())
        
        for year_month in calendar_months:
            month_data = monthly_volumes[monthly_volumes['year_month'] == year_month].copy()
            
            # Determine M+1 and M+2 contracts for this trading month
            calendar_date = year_month.to_timestamp()
            m1_delivery = calendar_date + relativedelta(months=1)
            m2_delivery = calendar_date + relativedelta(months=2)
            
            # Get end of this TRADING month (not M+1 delivery month)
            month_end = calendar_date + pd.offsets.MonthEnd(0)
            
            month_names = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 
                           'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
            m1_contract = f"{month_names[m1_delivery.month - 1]}-{str(m1_delivery.year)[2:]}"
            m2_contract = f"{month_names[m2_delivery.month - 1]}-{str(m2_delivery.year)[2:]}"
            
            trading_dates = sorted(month_data['trading_day'].unique())
            
            for trading_date in trading_dates:
                day_data = month_data[month_data['trading_day'] == trading_date]
                
                # Get M+1 volume
                m1_row = day_data[day_data['strip'] == m1_contract]
                m1_vol = m1_row['traded_volume'].iloc[0] if not m1_row.empty and pd.notna(m1_row['traded_volume'].iloc[0]) else None
                
                # Get M+2 volume
                m2_row = day_data[day_data['strip'] == m2_contract]
                m2_vol = m2_row['traded_volume'].iloc[0] if not m2_row.empty and pd.notna(m2_row['traded_volume'].iloc[0]) else None
                
                if m1_vol is not None and m2_vol is not None:
                    # Calculate days until end of TRADING month (0-31 range)
                    days_until_month_end = (month_end - trading_date).days
                    volume_diff = m1_vol - m2_vol
                    
                    all_data.append({
                        'days_until_month_end': days_until_month_end,
                        'm1_volume': m1_vol,
                        'm2_volume': m2_vol,
                        'volume_diff': volume_diff,
                        'trading_date': trading_date,
                        'month': year_month,
                        'm1_contract': m1_contract,
                        'm2_contract': m2_contract
                    })
        
        if not all_data:
            print(f"    No distribution data available")
            return
        
        # Convert to DataFrame
        dist_df = pd.DataFrame(all_data)
        
        # Exclude December trading months to avoid year-end effects
        dist_df = dist_df[dist_df['month'].apply(lambda x: x.month != 12)]
        
        if dist_df.empty:
            print(f"    No distribution data available after filtering")
            return
        
        # Create figure with 2 rows: scatter plot on top, candlestick on bottom
        fig = plt.figure(figsize=(24, 16))
        fig.patch.set_facecolor('white')
        
        self._add_header_footer(fig, f"{country} Power: Volume Analysis - Days Until End of Trading Month")
        
        gs = gridspec.GridSpec(2, 1, height_ratios=[1, 1], hspace=0.20, top=0.94, bottom=0.06, left=0.06, right=0.96)
        
        # Plot 1: Scatter plot with M+1 and M+2 volumes
        ax1 = fig.add_subplot(gs[0])
        self._plot_volume_scatter(ax1, dist_df)
        
        # Plot 2: Candlestick chart with 5-day bins
        ax2 = fig.add_subplot(gs[1])
        self._plot_volume_diff_candlestick(ax2, dist_df)
        
        pdf.savefig(fig)
        plt.close()
    
    def _plot_volume_scatter(self, ax, dist_df):
        """Scatter plot showing M+1 and M+2 volumes vs days until end of month."""
        days = dist_df['days_until_month_end'].values
        m1_vols = dist_df['m1_volume'].values
        m2_vols = dist_df['m2_volume'].values
        
        # Scatter plots for M+1 and M+2
        ax.scatter(days, m1_vols, alpha=0.5, s=40, color='#1f77b4', edgecolors='none', label='M+1 Volume', zorder=3)
        ax.scatter(days, m2_vols, alpha=0.5, s=40, color='#ff7f0e', marker='s', edgecolors='none', label='M+2 Volume', zorder=3)
        
        # Calculate and plot median trend lines (median by day)
        m1_median = dist_df.groupby('days_until_month_end')['m1_volume'].median()
        m2_median = dist_df.groupby('days_until_month_end')['m2_volume'].median()
        
        ax.plot(m1_median.index, m1_median.values, '-', color='#1f77b4', linewidth=3, 
               label='M+1 Median', zorder=5)
        ax.plot(m2_median.index, m2_median.values, '-', color='#ff7f0e', linewidth=3, 
               label='M+2 Median', zorder=5)
        
        ax.set_xlabel('Days Until End of Trading Month', fontsize=14, fontweight='bold')
        ax.set_ylabel('Traded Volume', fontsize=14, fontweight='bold')
        ax.set_title('Volume Distribution: M+1 vs M+2', fontsize=16, fontweight='bold', pad=10)
        ax.grid(True, linestyle=':', alpha=0.4)
        ax.legend(fontsize=12, framealpha=0.9, loc='upper left')
        
        # Reverse x-axis so early month (high days) is on left
        ax.set_xlim(max(days) + 1, min(days) - 1)
        
        plt.setp(ax.get_xticklabels(), fontsize=11, fontweight='bold')
        plt.setp(ax.get_yticklabels(), fontsize=11, fontweight='bold')
    
    def _plot_volume_diff_candlestick(self, ax, dist_df):
        """Candlestick chart showing median volume difference by 5-day bins."""
        # Create 5-day bins
        max_days = int(dist_df['days_until_month_end'].max())
        bins = list(range(0, max_days + 5, 5))
        labels = [f'{bins[i]}-{bins[i+1]-1}' for i in range(len(bins)-1)]
        
        dist_df['day_bin'] = pd.cut(dist_df['days_until_month_end'], bins=bins, labels=labels, right=False, include_lowest=True)
        
        # Calculate statistics for each bin
        stats = dist_df.groupby('day_bin')['volume_diff'].agg([
            ('median', 'median'),
            ('std', 'std'),
            ('q25', lambda x: x.quantile(0.25)),
            ('q75', lambda x: x.quantile(0.75)),
            ('min', 'min'),
            ('max', 'max'),
            ('count', 'count')
        ]).reset_index()
        
        stats = stats[stats['count'] > 0]  # Remove empty bins
        
        # Create candlestick-style plot
        x_pos = np.arange(len(stats))
        
        # Draw candlesticks
        for i, row in stats.iterrows():
            idx = x_pos[i]
            median_val = row['median']
            q25 = row['q25']
            q75 = row['q75']
            min_val = row['min']
            max_val = row['max']
            
            # Color based on median
            color = '#2ecc71' if median_val >= 0 else '#e74c3c'
            
            # Draw wick (min to max)
            ax.plot([idx, idx], [min_val, max_val], color='black', linewidth=1.5, zorder=2)
            
            # Draw box (Q1 to Q3)
            box_height = q75 - q25
            ax.bar(idx, box_height, bottom=q25, width=0.6, color=color, alpha=0.7, 
                  edgecolor='black', linewidth=1.5, zorder=3)
            
            # Draw median line
            ax.plot([idx - 0.3, idx + 0.3], [median_val, median_val], color='white', 
                   linewidth=2.5, zorder=4)
        
        # Zero line
        ax.axhline(0, color='black', linewidth=1.5, linestyle='-', alpha=0.7, zorder=1)
        
        ax.set_xticks(x_pos)
        ax.set_xticklabels(stats['day_bin'], fontsize=11, fontweight='bold', rotation=0)
        ax.set_xlabel('Days Until End of Month (Bins)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Median Volume Difference (M+1 - M+2)', fontsize=14, fontweight='bold')
        ax.set_title('Volume Difference by 5-Day Bins (Candlestick: Median=White Line, Box=Q1-Q3, Wick=Min-Max)', 
                    fontsize=14, fontweight='bold', pad=10)
        ax.grid(True, linestyle=':', alpha=0.4, axis='y')
        plt.setp(ax.get_yticklabels(), fontsize=11, fontweight='bold')
        
        # Add sample size annotations
        for i, row in stats.iterrows():
            ax.text(x_pos[i], row['max'], f"n={int(row['count'])}", 
                   ha='center', va='bottom', fontsize=9, fontweight='bold')



if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Time Spread Report')
    parser.add_argument('--countries', type=str, nargs='+', default=['FR', 'DE'], 
                        help='Countries to include (e.g., FR DE)')
    parser.add_argument('--start_date', type=str, default=None, help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end_date', type=str, default=None, help='End date (YYYY-MM-DD)')
    parser.add_argument('--as_of', type=str, default=None, 
                        help='As-of date for contract positions (YYYY-MM-DD). Filters trading days up to this date.')
    parser.add_argument('--output', type=str, default='time_spread_report.pdf', help='Output PDF file')
    
    args = parser.parse_args()
    
    # Parse dates
    start_date = datetime.strptime(args.start_date, '%Y-%m-%d') if args.start_date else datetime(2020, 1, 1)
    end_date = datetime.strptime(args.end_date, '%Y-%m-%d') if args.end_date else datetime.now()
    as_of = datetime.strptime(args.as_of, '%Y-%m-%d') if args.as_of else datetime.now()
    
    report = Report()
    report.generate_report(
        countries=args.countries,
        start_date=start_date,
        end_date=end_date,
        as_of=as_of,
        output_file=args.output
    )
