import sys
import os
# Ensure we use local eu_corelib if available
corelib_path = 'c:/Users/Michael.Kane/OneDrive - Jain Global/Projects/eu_corelib'
if os.path.exists(corelib_path) and corelib_path not in sys.path:
    sys.path.insert(0, corelib_path)

from jain_commods.core.cache.data.market import ForexSpot, PricePowerSpot

# Pre-load S3 caches BEFORE snowflake.connector is imported.
# snowflake.connector vendors its own urllib3 which contaminates botocore's
# HTTP session and causes "issubclass() arg 2 must be a class" errors.
_PRELOADED_CACHES = {}
for _label, _cls, _kwargs in [
    ('power', PricePowerSpot, {'freq': 'h'}),
    ('fx', ForexSpot, {}),
]:
    try:
        _obj = _cls(**_kwargs)
        _obj.load(from_s3=True, show_metadata=False)
        if _obj.data is not None and not _obj.data.empty:
            _PRELOADED_CACHES[_label] = _obj.data
    except Exception:
        pass

# BBGQuery requires Bloomberg Terminal - optional in Docker
try:
    from jain_commods.core.interfaces.bloomberg import BBGQuery
    BLOOMBERG_AVAILABLE = True
except ImportError:
    BBGQuery = None
    BLOOMBERG_AVAILABLE = False
from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery
from jain_commods.core.util.curves import BootstrapBuilder, RedundancyMode
from jain_commods.core.util.emailhelper import send_email
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import snowflake.connector
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.gridspec as gridspec
import matplotlib as mpl
from matplotlib.patches import Rectangle
import holidays
import calendar

# Monkey-patch snowflake connector to bypass SSL/OCSP checks
_original_connect = snowflake.connector.connect
def insecure_connect(*args, **kwargs):
    kwargs['insecure_mode'] = True
    return _original_connect(*args, **kwargs)
snowflake.connector.connect = insecure_connect

# Support both direct execution and package import
try:
    from .utils import july
except ImportError:
    from utils import july

import warnings
warnings.filterwarnings('ignore')

if not hasattr(mpl.cbook, 'MatplotlibDeprecationWarning'):
    mpl.cbook.MatplotlibDeprecationWarning = mpl.MatplotlibDeprecationWarning

BORDER_CONFIG = {
    'DE' : ['BE' , 'NL' , 'FR'],
}

SPOT_ZONE_MAP = {
    'UK': 'GB',
}

EEX_COUNTRY_MAP = {
    'UK': 'gb',
}


class DataLoader:
    def __init__(self):
        self.eex = EEXQuery()

    @staticmethod
    def _last_uk_business_day(ref_date=None):
        from datetime import date as _date
        if ref_date is None:
            ref_date = _date.today()
        uk_hols = holidays.UK(years=range(ref_date.year - 1, ref_date.year + 1))
        d = ref_date - timedelta(days=1)
        while d.weekday() >= 5 or d in uk_hols:
            d -= timedelta(days=1)
        return d

    def _fetch_macq_uk_power(self, as_of_date=None):
        """Fetch UK power forward curve from MACQ_FWD_CURVES in Snowflake."""
        from jain_commods.core.interfaces.snowflake.snowflake import SnowFlake
        if as_of_date is None:
            as_of_date = self._last_uk_business_day()
        as_of_str = as_of_date.strftime('%Y-%m-%d') if hasattr(as_of_date, 'strftime') else str(as_of_date)
        try:
            sf = SnowFlake(database='COMMOD', schema='PUBLIC')
            cur = sf._conn.cursor()
            cur.execute(f"""
                SELECT DATE, PRICE, GRANULARITY
                FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
                WHERE COMMODITY = 'ELEC_UK.BASELOAD'
                  AND AS_OF_DATE = '{as_of_str}'
                ORDER BY DATE
            """)
            df = cur.fetch_pandas_all()
            cur.close()
            sf._conn.close()
        except Exception as e:
            print(f"  Error fetching MACQ UK power: {e}")
            return pd.DataFrame()
        if df.empty:
            return pd.DataFrame()
        contracts = []
        for _, row in df.iterrows():
            d = pd.Timestamp(row['DATE'])
            gran = row['GRANULARITY']
            price = float(row['PRICE'])
            if gran == 'D':
                start, end = d, d + pd.Timedelta(days=1)
            elif gran == 'M':
                start = d
                end = d + pd.offsets.MonthEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Q':
                start = d
                end = d + pd.offsets.QuarterEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Y':
                start = d
                end = pd.Timestamp(year=d.year + 1, month=1, day=1)
            else:
                start, end = d, d + pd.Timedelta(days=1)
            contracts.append({
                'commodity': 'Power', 'hub': 'UK',
                'start': start, 'end': end,
                'price': price, 'shape': 'Base',
                'issue_date': pd.Timestamp(as_of_date),
            })
        return pd.DataFrame(contracts)

    def _fetch_macq_uk_power_history(self, start_date, end_date):
        """Fetch multiple AS_OF_DATEs of UK power forward curves from MACQ."""
        from jain_commods.core.interfaces.snowflake.snowflake import SnowFlake
        start_str = start_date.strftime('%Y-%m-%d')
        end_str = end_date.strftime('%Y-%m-%d')
        try:
            sf = SnowFlake(database='COMMOD', schema='PUBLIC')
            cur = sf._conn.cursor()
            cur.execute(f"""
                SELECT DATE, PRICE, GRANULARITY, AS_OF_DATE
                FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
                WHERE COMMODITY = 'ELEC_UK.BASELOAD'
                  AND AS_OF_DATE >= '{start_str}'
                  AND AS_OF_DATE <= '{end_str}'
                ORDER BY AS_OF_DATE, DATE
            """)
            df = cur.fetch_pandas_all()
            cur.close()
            sf._conn.close()
        except Exception as e:
            print(f"  Error fetching MACQ UK power history: {e}")
            return pd.DataFrame()
        if df.empty:
            return pd.DataFrame()
        contracts = []
        for _, row in df.iterrows():
            d = pd.Timestamp(row['DATE'])
            gran = row['GRANULARITY']
            price = float(row['PRICE'])
            as_of = pd.Timestamp(row['AS_OF_DATE'])
            if gran == 'D':
                start, end = d, d + pd.Timedelta(days=1)
            elif gran == 'M':
                start = d
                end = d + pd.offsets.MonthEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Q':
                start = d
                end = d + pd.offsets.QuarterEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Y':
                start = d
                end = pd.Timestamp(year=d.year + 1, month=1, day=1)
            else:
                start, end = d, d + pd.Timedelta(days=1)
            contracts.append({
                'commodity': 'Power', 'hub': 'UK',
                'start': start, 'end': end,
                'price': price, 'shape': 'Base',
                'issue_date': as_of,
            })
        return pd.DataFrame(contracts)

    def get_forward_power(self, country_code):
        """
        Build daily forward curve for Power.
        For UK: uses MACQ Snowflake data. For others: EEX.
        Returns Series with DatetimeIndex.
        """
        if country_code == 'UK':
            return self._build_uk_forward()

        eex_code = EEX_COUNTRY_MAP.get(country_code, country_code.lower())
        print(f"  Fetching forward power for {country_code} (EEX code: {eex_code})...")
        try:
            df_power = self.eex.get_latest_prices(country_code=eex_code, profile='Base')
            if df_power.empty:
                print(f"  Warning: No EEX data for {country_code}")
                return pd.Series()

            df_transformed = self._transform_eex_data(df_power, country_code)
            
            if df_transformed.empty:
                return pd.Series()
                
            builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
            builder.add_contracts(df_transformed)
            
            df_curve = builder.build_curves(freq='D', commodity='Power')
            if not df_curve.empty:
                if isinstance(df_curve.index, pd.PeriodIndex):
                    df_curve.index = df_curve.index.to_timestamp()
                return df_curve['price']
                
        except Exception as e:
            print(f"  Error building forward curve for {country_code}: {e}")
            
        return pd.Series()

    def _build_uk_forward(self):
        """Build UK forward curve from MACQ data."""
        try:
            df_contracts = self._fetch_macq_uk_power()
            if df_contracts.empty:
                print(f"  Warning: MACQ UK power returned empty")
                return pd.Series()
            print(f"  Loaded {len(df_contracts)} UK power contracts from MACQ")
            builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
            builder.add_contracts(df_contracts)
            curve = builder.build_curves(freq='D', commodity='Power')
            if not curve.empty:
                if isinstance(curve.index, pd.PeriodIndex):
                    curve.index = curve.index.to_timestamp()
                return curve['price']
        except Exception as e:
            print(f"  Error building UK forward curve: {e}")
        return pd.Series()

    def get_spot_power(self, country_code, start_date, end_date):
        """
        Load historical spot prices from PricePowerSpot cache.
        """
        raw = _PRELOADED_CACHES.get('power')
        if raw is None or raw.empty:
            print(f"  Warning: PricePowerSpot cache not available")
            return pd.Series()

        zone = SPOT_ZONE_MAP.get(country_code, country_code)
        preferred_ccy = 'GBP' if country_code == 'UK' else 'EUR'

        chosen = None
        for col in raw.columns:
            if col[0] == zone and col[2] == preferred_ccy:
                chosen = col
                break
        if chosen is None:
            for col in raw.columns:
                if col[0] == zone:
                    chosen = col
                    break
        if chosen is None:
            print(f"  Warning: {country_code} (zone {zone}) not found in power cache")
            return pd.Series()

        series = raw[chosen].dropna()
        series.index = pd.to_datetime(series.index)
        if series.index.tz is not None:
            series.index = series.index.tz_convert('Europe/Brussels').tz_localize(None)

        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, '%Y-%m-%d')

        series = series[(series.index >= start_date) & (series.index <= end_date)]
        print(f"  Loaded {country_code} spot from cache ({len(series)} points, ccy={chosen[2]})")
        return series

    def get_historical_forward_curves(self, country_code, days=45):
        """
        Fetch last N days of forward curves (Cal contracts mostly).
        For UK: uses MACQ Snowflake data. For others: EEX.
        Returns dict: {trade_date: Series}
        """
        if country_code == 'UK':
            return self._get_uk_historical_curves(days)

        eex_code = EEX_COUNTRY_MAP.get(country_code, country_code.lower())
        print(f"  Fetching historical curves for {country_code} (EEX: {eex_code}, last {days} days)...")
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days*2) # Buffer
        
        try:
            df_contracts = self.eex.get_strip_prices(
                country_code=eex_code,
                profile='Base',
                start_date=start_date,
                end_date=end_date
            )
            
            if df_contracts.empty:
                return {}
                
            df_contracts = self._transform_eex_data(df_contracts, country_code)
            
            history = {}
            trading_dates = sorted(df_contracts['issue_date'].unique())[-days:]
            
            for trade_date in trading_dates:
                daily = df_contracts[df_contracts['issue_date'] == trade_date]
                
                builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
                builder.add_contracts(daily)
                
                try:
                    curve = builder.build_curves(freq='D', commodity='Power')
                    if not curve.empty:
                        if isinstance(curve.index, pd.PeriodIndex):
                            curve.index = curve.index.to_timestamp()
                        history[trade_date] = curve['price']
                except:
                    pass
                    
            return history
            
        except Exception as e:
            print(f"  Error fetching historical curves: {e}")
            return {}

    def _get_uk_historical_curves(self, days=45):
        """Build historical forward curves for UK from MACQ data."""
        print(f"  Fetching UK historical curves from MACQ (last {days} days)...")
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days * 2)
        try:
            df_contracts = self._fetch_macq_uk_power_history(start_date, end_date)
            if df_contracts.empty:
                return {}

            df_contracts['issue_date'] = df_contracts['issue_date'].dt.normalize()
            trading_dates = sorted(df_contracts['issue_date'].unique())[-days:]

            history = {}
            for trade_date in trading_dates:
                daily = df_contracts[df_contracts['issue_date'] == trade_date]
                builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
                builder.add_contracts(daily)
                try:
                    curve = builder.build_curves(freq='D', commodity='Power')
                    if not curve.empty:
                        if isinstance(curve.index, pd.PeriodIndex):
                            curve.index = curve.index.to_timestamp()
                        history[trade_date] = curve['price']
                except Exception:
                    pass
            print(f"  Built {len(history)} UK historical curves from MACQ")
            return history
        except Exception as e:
            print(f"  Error fetching UK historical curves: {e}")
            return {}

    def _transform_eex_data(self, df, country_code):
        """
        Transform EEX raw data to BootstrapBuilder format.
        """
        cols = df.columns
        price_col = 'SETTLEMENT_PRICE'
        if 'settlement_price' in cols: price_col = 'settlement_price'
        
        if price_col not in cols:
             if 'price' in cols: price_col = 'price'
             else: return pd.DataFrame()

        df = df[df[price_col].notna()].copy()
        out = pd.DataFrame()
        
        if 'DELIVERY_START' in cols and 'DELIVERY_END' in cols:
            out['start'] = pd.to_datetime(df['DELIVERY_START'])
            out['end'] = pd.to_datetime(df['DELIVERY_END']) + timedelta(days=1)
        elif 'start_date' in cols and 'end_date' in cols:
            out['start'] = pd.to_datetime(df['start_date'])
            out['end'] = pd.to_datetime(df['end_date']) + timedelta(days=1)
        else:
            return pd.DataFrame()

        out['price'] = df[price_col]
        
        date_col = 'TRADING_DAY'
        if 'trade_date' in cols: date_col = 'trade_date'
        
        if date_col in cols:
            out['issue_date'] = pd.to_datetime(df[date_col])
        else:
            out['issue_date'] = pd.Timestamp.now().normalize()
            
        out['hub'] = country_code 
        out['commodity'] = 'Power'
        out['source'] = 'EEX'
        
        return out

class Report:
    """
    Generate PDF reports for location spreads.
    """
    def __init__(self, loader=None, border_config=None):
        self.loader = loader if loader else DataLoader()
        self.border_config = border_config if border_config else BORDER_CONFIG
        self._spot_cache = {}
        self._fc_cache = {}
        self._hist_cache = {}
        self.fx_gbp_eur = self._load_fx_gbp_eur()

    def _load_fx_gbp_eur(self):
        """Load GBP/EUR spot FX rate time series for converting UK prices to EUR."""
        has_uk = any(
            'UK' in [country_a] + neighbors
            for country_a, neighbors in self.border_config.items()
        )
        if not has_uk:
            return pd.Series(dtype=float)

        print("  Loading GBP/EUR FX rate for UK price conversion...")
        fx_data = _PRELOADED_CACHES.get('fx')
        if fx_data is not None and not fx_data.empty:
            for col in fx_data.columns:
                if 'GBP/EUR' in str(col):
                    series = fx_data[col].dropna()
                    if not series.empty:
                        print(f"    Loaded {len(series)} GBP/EUR FX rates "
                              f"(latest: {series.iloc[-1]:.4f})")
                        return series
            print("  Warning: GBP/EUR pair not found in FX cache")
        else:
            print("  Warning: FX cache not available")
        return pd.Series(dtype=float)

    def _convert_gbp_to_eur(self, series, country_code):
        """Convert a price series from GBP to EUR if country is UK."""
        if country_code != 'UK' or series.empty or self.fx_gbp_eur.empty:
            return series

        fx = self.fx_gbp_eur.copy()
        fx.index = pd.to_datetime(fx.index)

        price_df = series.to_frame(name='price')
        price_df.index = pd.to_datetime(price_df.index)

        fx_df = fx.to_frame(name='fx_rate')

        merged = pd.merge_asof(
            price_df.sort_index(),
            fx_df.sort_index(),
            left_index=True,
            right_index=True,
            direction='backward'
        )

        result = merged['price'] * merged['fx_rate']
        result.index = series.index
        result.name = series.name
        return result

    def _get_spot(self, country_code, start_date, end_date):
        """Cached spot data fetch with GBP/EUR conversion."""
        if country_code not in self._spot_cache:
            raw = self.loader.get_spot_power(country_code, start_date, end_date)
            self._spot_cache[country_code] = self._convert_gbp_to_eur(raw, country_code)
        return self._spot_cache[country_code]

    def _get_forward(self, country_code):
        """Cached forward curve fetch with GBP/EUR conversion."""
        if country_code not in self._fc_cache:
            raw = self.loader.get_forward_power(country_code)
            self._fc_cache[country_code] = self._convert_gbp_to_eur(raw, country_code)
        return self._fc_cache[country_code]

    def _get_hist(self, country_code, days=60):
        """Cached historical forward curves fetch with GBP/EUR conversion."""
        if country_code not in self._hist_cache:
            hist = self.loader.get_historical_forward_curves(country_code, days=days)
            if country_code == 'UK':
                hist = {d: self._convert_gbp_to_eur(c, country_code) for d, c in hist.items()}
            self._hist_cache[country_code] = hist
        return self._hist_cache[country_code]

    def _compute_aligned_spread(self, daily_a, daily_b):
        """
        Compute spread between two daily series, reindexing both to a
        continuous daily range and forward-filling gaps up to 3 days so
        that weekends/holidays in one country don't create blank cells.
        """
        all_dates = daily_a.index.union(daily_b.index)
        if all_dates.empty:
            return pd.Series(dtype=float)
        full_range = pd.date_range(all_dates.min(), all_dates.max(), freq='D')
        a = daily_a.reindex(full_range).ffill(limit=3)
        b = daily_b.reindex(full_range).ffill(limit=3)
        spread = a - b
        return spread.dropna()

    def generate_report(self, start_date='2018-01-01', end_date=None, output_file='location_spread_report.pdf'):
        if end_date is None:
            end_date = datetime.now()

        print(f"Generating report from {start_date} to {end_date}...")
        print(f"Hubs: {list(self.border_config.keys())}")

        with PdfPages(output_file) as pdf:
            self._create_title_page(pdf, start_date, end_date)

            for country_a, neighbors in self.border_config.items():
                print(f"\n{'='*60}")
                print(f"  Hub: {country_a}  |  Borders: {neighbors}")
                print(f"{'='*60}")

                self._create_country_summary_page(pdf, country_a, neighbors, start_date, end_date)
                self._create_country_spot_page(pdf, country_a, neighbors, start_date, end_date)

                for country_b in neighbors:
                    print(f"  Processing spread {country_a} - {country_b}...")
                    try:
                        self._create_spread_page(pdf, country_a, country_b, start_date, end_date)
                    except Exception as e:
                        print(f"  Error creating page for {country_a}-{country_b}: {e}")
                        import traceback
                        traceback.print_exc()

        print(f"\nReport saved to: {output_file}")

    def _create_title_page(self, pdf, start_date, end_date):
        fig = plt.figure(figsize=(24, 18))
        fig.patch.set_facecolor('white')

        header_rect = Rectangle((0, 0.82), 1, 0.18,
                                transform=fig.transFigure,
                                facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(header_rect)

        fig.text(0.5, 0.92, 'Location Spread Report',
                 fontsize=52, fontweight='bold', va='center', ha='center',
                 color='white', zorder=1002)
        fig.text(0.5, 0.86, 'European Power Markets',
                 fontsize=28, va='center', ha='center',
                 color='#CCCCCC', zorder=1002)

        ax = fig.add_axes([0.1, 0.08, 0.8, 0.70])
        ax.axis('off')

        y = 0.92
        ax.text(0.5, y, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}',
                ha='center', fontsize=22, color='#555555')
        y -= 0.08
        s = start_date.strftime('%Y-%m-%d') if isinstance(start_date, datetime) else str(start_date)
        e = end_date.strftime('%Y-%m-%d') if isinstance(end_date, datetime) else str(end_date)
        ax.text(0.5, y, f'Spot History: {s}  to  {e}',
                ha='center', fontsize=20, color='#555555')

        y -= 0.14
        ax.text(0.5, y, 'Hubs & Borders', ha='center', fontsize=26,
                fontweight='bold', color='#231F20')
        y -= 0.04
        for hub, borders in self.border_config.items():
            y -= 0.06
            ax.text(0.25, y, hub, fontsize=20, fontweight='bold',
                    color='#1f77b4', ha='right')
            ax.text(0.28, y, '\u2194  ' + ', '.join(borders),
                    fontsize=18, color='#333333', ha='left')

        footer_rect = Rectangle((0, 0), 1, 0.05,
                                transform=fig.transFigure,
                                facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(footer_rect)
        fig.text(0.5, 0.025, 'Jain Global',
                 fontsize=16, va='center', ha='center',
                 color='white', zorder=1002)

        pdf.savefig(fig)
        plt.close()

    def _add_header_footer(self, fig, title):
        """
        Add header and footer in the style of price_report.py
        Uses larger font sizes for larger figures.
        """
        # Header
        header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(header_rect)
        fig.text(0.5, 0.98, title, fontsize=20, fontweight='bold', va='center', ha='center', color='white', zorder=1002)
        
        # Footer
        footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(footer_rect)
        fig.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', fontsize=12, va='center', ha='right', color='white', zorder=1002)

    def _create_country_summary_page(self, pdf, country_a, neighbors, start_date, end_date):
        """
        Create a summary page for a country with heatmap tables for each neighbor.
        Uses same sizing as price_report.py for consistency.
        """
        print(f"Creating summary page for {country_a}...")
        
        # Limit neighbors to fit on page (max 6? 2x3 grid)
        display_neighbors = neighbors[:6]
        
        # Use large figure size like price_report.py
        fig = plt.figure(figsize=(24, 18))
        fig.patch.set_facecolor('white')
        
        self._add_header_footer(fig, f"{country_a} Border Spreads (Monthly Average)")
        
        gs = gridspec.GridSpec(2, 3, wspace=0.15, hspace=0.35, top=0.90, bottom=0.06, left=0.05, right=0.95)
        
        fc_a = self._get_forward(country_a)
        spot_a = self._get_spot(country_a, start_date, end_date)

        for i, country_b in enumerate(display_neighbors):
            row = i // 3
            col = i % 3
            ax = plt.subplot(gs[row, col])

            fc_b = self._get_forward(country_b)
            spot_b = self._get_spot(country_b, start_date, end_date)
            
            # Combine Spot and Forward to get Monthly Series
            spread_series = self._combine_spot_and_forward(spot_a, spot_b, fc_a, fc_b)
            
            if spread_series.empty:
                ax.text(0.5, 0.5, 'No Data', ha='center', va='center')
                ax.set_title(f"{country_a} - {country_b}")
                continue
                
            # Create Pivot Table
            df_pivot = self._create_monthly_pivot(spread_series)
            
            # Use RdYlGn_r colormap like price_report.py (Red=High, Green=Low)
            self._create_monthly_table_heatmap(df_pivot, ax, f"{country_a} - {country_b}", cmap='RdYlGn_r')
            
        pdf.savefig(fig)
        plt.close()

    def _create_country_spot_page(self, pdf, country_a, neighbors, start_date, end_date):
        """
        Create a summary page with stacked spot heatmaps for all borders.
        Uses same sizing as price_report.py for consistency.
        """
        print(f"Creating spot summary page for {country_a}...")
        
        num_plots = len(neighbors)
        if num_plots == 0:
            return

        # Use large figure size like price_report.py (24, 32 for 7 plots)
        # Scale height based on number of plots
        fig_height = max(18, num_plots * 5)
        fig = plt.figure(figsize=(24, fig_height))
        fig.patch.set_facecolor('white')
        
        self._add_header_footer(fig, f"{country_a} Spot Spreads (Last 365 Days)")
        
        gs = gridspec.GridSpec(num_plots, 1, hspace=0.08, top=0.93, bottom=0.05, left=0.03, right=0.85)

        spot_a = self._get_spot(country_a, start_date, end_date)
        if not spot_a.empty:
            spot_a = spot_a.resample('D').mean()
        
        for i, country_b in enumerate(neighbors):
            ax = plt.subplot(gs[i])
            
            spot_b = self._get_spot(country_b, start_date, end_date)
            if not spot_b.empty:
                spot_b = spot_b.resample('D').mean()
            
            if spot_a.empty or spot_b.empty:
                ax.text(0.5, 0.5, 'Missing Data', ha='center', va='center')
                ax.set_title(f"{country_a} - {country_b}", fontweight='bold')
                continue
            
            spread = self._compute_aligned_spread(spot_a, spot_b)
            
            # Filter last 365 days
            if not spread.empty:
                end_view = spread.index.max()
                start_view = end_view - timedelta(days=365)
                spread = spread[spread.index >= start_view]
            
            self._create_calendar_heatmap(spread, ax, f"{country_a} - {country_b}", cmap='RdYlGn_r', value_format='decimal')
            
        pdf.savefig(fig)
        plt.close()

    def _combine_spot_and_forward(self, spot_a, spot_b, fc_a, fc_b):
        """
        Combine spot and forward data into a single spread series.
        Priority: Spot > Forward
        """
        series = pd.Series()
        
        # 1. Spot Spread
        if not spot_a.empty and not spot_b.empty:
            common_idx = spot_a.index.intersection(spot_b.index)
            spot_spread = spot_a.loc[common_idx] - spot_b.loc[common_idx]
            series = spot_spread.resample('MS').mean()
        
        # 2. Forward Spread
        if not fc_a.empty and not fc_b.empty:
            common_idx = fc_a.index.intersection(fc_b.index)
            fwd_spread = fc_a.loc[common_idx] - fc_b.loc[common_idx]
            fwd_monthly = fwd_spread.resample('MS').mean()
            
            today = datetime.now()
            current_month = today.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            
            # Filter Forward: >= Current Month
            fwd_monthly = fwd_monthly[fwd_monthly.index >= current_month]
            
            # Filter Spot: < Current Month
            series = series[series.index < current_month]
            
            # Concatenate
            series = pd.concat([series, fwd_monthly])
            
            # Sort and deduplicate
            series = series.sort_index()
            series = series[~series.index.duplicated(keep='last')]
            
        return series

    def _create_monthly_pivot(self, series):
        """
        Pivot a monthly series into Year columns and Month rows.
        """
        df = pd.DataFrame({'value': series})
        df['Year'] = df.index.year
        df['Month'] = df.index.month
        
        # Filter Years <= current_year + 2
        max_year = datetime.now().year + 2
        df = df[df['Year'] <= max_year]
        
        pivot = df.pivot(index='Month', columns='Year', values='value')
        return pivot

    def _create_monthly_table_heatmap(self, df, ax, title, cmap='RdYlGn_r'):
        """
        Create a heatmap table for monthly data (Year cols, Month rows).
        Matches price_report.py style.
        """
        if df.empty:
            ax.text(0.5, 0.5, 'No Data', ha='center', va='center', transform=ax.transAxes)
            ax.set_title(title)
            return

        # Prepare data (1-12 months)
        for m in range(1, 13):
            if m not in df.index:
                df.loc[m] = np.nan
        df.sort_index(inplace=True)
        
        # Ensure columns are sorted integers
        df = df[sorted(df.columns)]

        # Bottom row: annual mean (mean of monthly values in each year column)
        avg_row = df.mean(axis=0, skipna=True)
        df = pd.concat([df, pd.DataFrame([avg_row.values], columns=df.columns, index=[13])])
        
        data = df.values
        
        # Calculate percentiles for color scaling (10th-90th like price_report.py)
        valid_data = data[~np.isnan(data)]
        if len(valid_data) > 0:
            vmin, vmax = np.percentile(valid_data, [10, 90])
        else:
            vmin, vmax = None, None
        
        im = ax.imshow(data, cmap=cmap, aspect='auto', vmin=vmin, vmax=vmax)
        
        ax.set_xticks(np.arange(len(df.columns)))
        ax.set_yticks(np.arange(len(df.index)))
        
        ax.set_xticklabels(df.columns, fontsize=9)
        ax.set_yticklabels([calendar.month_abbr[i] for i in range(1, 13)] + ['Avg'], fontsize=9)
        
        # Move x-axis to top
        ax.xaxis.tick_top()
        ax.xaxis.set_label_position('top') 
        ax.tick_params(axis='both', which='both', length=0) # Hide ticks
        
        # Rotate x labels
        plt.setp(ax.get_xticklabels(), rotation=45, ha="left", rotation_mode="anchor")
        
        # Annotations
        now = datetime.now()

        def is_future_cell(r_idx, c_idx):
            if r_idx < 0 or r_idx >= len(df.index):
                return False
            if c_idx < 0 or c_idx >= len(df.columns):
                return False
            row_key = df.index[r_idx]
            _yr = df.columns[c_idx]
            if row_key == 13:
                # Annual average row: same-year column includes forward months
                return _yr >= now.year
            _mon = row_key
            if _yr > now.year:
                return True
            if _yr == now.year and _mon >= now.month:
                return True
            return False

        for i in range(len(df.index)):
            for j in range(len(df.columns)):
                val = data[i, j]
                if not np.isnan(val):
                    # Format like price_report.py: 0 decimals if > 10, otherwise 2 decimals
                    text = f"{val:.0f}" if abs(val) > 10 else f"{val:.1f}"
                    ax.text(j, i, text, ha="center", va="center", color="black", fontsize=11, fontweight='bold')

                if is_future_cell(i, j):
                    # Top Border
                    if i > 0 and not is_future_cell(i - 1, j):
                        ax.plot([j - 0.5, j + 0.5], [i - 0.5, i - 0.5], color='black', linewidth=2)
                    # Left Border
                    if j > 0 and not is_future_cell(i, j - 1):
                        ax.plot([j - 0.5, j - 0.5], [i - 0.5, i + 0.5], color='black', linewidth=2)

        # Separator between monthly grid and annual average row
        ax.axhline(11.5, color='black', linewidth=1.0)
        # Set title above the table with enough padding to clear rotated x-labels
        ax.set_title(title, fontsize=14, pad=35, fontweight='bold')
        
        # Add frame
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color('black')

    def _create_spread_page(self, pdf, country_a, country_b, start_date, end_date):
        """
        Create a detailed report page for spread A - B.
        Uses same sizing as price_report.py for consistency.
        """
        fc_a = self._get_forward(country_a)
        fc_b = self._get_forward(country_b)
        spot_a = self._get_spot(country_a, start_date, end_date)
        spot_b = self._get_spot(country_b, start_date, end_date)
        hist_a = self._get_hist(country_a, days=60)
        hist_b = self._get_hist(country_b, days=60)

        fig = plt.figure(figsize=(24, 18))
        fig.patch.set_facecolor('white')
        self._add_header_footer(fig, f'{country_a} - {country_b} Spread Analysis')

        gs = gridspec.GridSpec(2, 2, height_ratios=[1, 1.2], top=0.92, bottom=0.05, left=0.06, right=0.94, hspace=0.15, wspace=0.12)

        ax1 = fig.add_subplot(gs[0, 0])
        self._plot_forward_spread(ax1, fc_a, fc_b, country_a, country_b)

        ax2 = fig.add_subplot(gs[0, 1])
        self._plot_spread_evolution(ax2, hist_a, hist_b, country_a, country_b)

        ax3 = fig.add_subplot(gs[1, :])
        self._plot_spot_heatmap(ax3, spot_a, spot_b, country_a, country_b)

        pdf.savefig(fig)
        plt.close()

    def _plot_forward_spread(self, ax, fc_a, fc_b, country_a, country_b):
        """
        Bar chart of monthly forward spreads.
        """
        if fc_a.empty or fc_b.empty:
            ax.text(0.5, 0.5, 'Missing Forward Data', ha='center', va='center')
            return

        common_idx = fc_a.index.intersection(fc_b.index)
        if common_idx.empty:
            ax.text(0.5, 0.5, 'No Overlapping Forward Data', ha='center', va='center')
            return
            
        spread = fc_a.loc[common_idx] - fc_b.loc[common_idx]
        spread_m = spread.resample('MS').mean()
        
        # Filter <= current_year + 2
        max_year = datetime.now().year + 2
        spread_m = spread_m[spread_m.index.year <= max_year]
        
        colors = ['#2ca02c' if x >= 0 else '#d62728' for x in spread_m.values] 
        ax.bar(spread_m.index, spread_m.values, width=20, color=colors, alpha=0.8, label=f'{country_a} - {country_b}')
        
        ax.set_title(f'Forward Spread Structure (Max {max_year})', fontsize=18, fontweight='bold')
        ax.set_ylabel('Spread (€/MWh)', fontsize=14, fontweight='bold')
        ax.grid(True, linestyle=':', alpha=0.5)
        ax.axhline(0, color='black', linewidth=0.8)
        
        import matplotlib.dates as mdates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontweight='bold', fontsize=12)
        plt.setp(ax.get_yticklabels(), fontweight='bold', fontsize=12)

    def _plot_spread_evolution(self, ax, hist_a, hist_b, country_a, country_b):
        """
        Evolution of Cal+1 Spread over last N days.
        """
        if not hist_a or not hist_b:
            ax.text(0.5, 0.5, 'Missing History Data', ha='center', va='center')
            return

        today = datetime.now()
        cal_year = today.year + 1
        
        dates = []
        spreads = []
        common_dates = sorted(list(set(hist_a.keys()) & set(hist_b.keys())))
        
        for d in common_dates:
            curve_a = hist_a[d]
            curve_b = hist_b[d]
            mask_a = curve_a.index.year == cal_year
            mask_b = curve_b.index.year == cal_year
            
            if mask_a.any() and mask_b.any():
                price_a = curve_a[mask_a].mean()
                price_b = curve_b[mask_b].mean()
                dates.append(d)
                spreads.append(price_a - price_b)
        
        if not dates:
            ax.text(0.5, 0.5, f'No Cal-{cal_year} Data', ha='center', va='center')
            return
            
        ax.plot(dates, spreads, marker='o', linestyle='-', markersize=6, color='#1f77b4', linewidth=2)
        ax.set_title(f'Cal-{cal_year} Spread Evolution (Last 60 Days)', fontsize=18, fontweight='bold')
        ax.set_ylabel('Spread (€/MWh)', fontsize=14, fontweight='bold')
        ax.grid(True, linestyle=':', alpha=0.5)
        # Use auto y-range instead of fixing at 0
        
        import matplotlib.dates as mdates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontweight='bold', fontsize=12)
        plt.setp(ax.get_yticklabels(), fontweight='bold', fontsize=12)

    def _plot_spot_heatmap(self, ax, spot_a, spot_b, country_a, country_b):
        """
        Calendar heatmap of spot spreads.
        """
        if spot_a.empty or spot_b.empty:
            ax.text(0.5, 0.5, 'Missing Spot Data', ha='center', va='center')
            return
            
        spot_a = spot_a.resample('D').mean()
        spot_b = spot_b.resample('D').mean()
        
        spread = self._compute_aligned_spread(spot_a, spot_b)
        if spread.empty:
            ax.text(0.5, 0.5, 'No Overlapping Spot Data', ha='center', va='center')
            return
        
        # Filter last 365 days
        end_view = spread.index.max()
        start_view = end_view - timedelta(days=365)
        spread = spread[spread.index >= start_view]
        
        self._create_calendar_heatmap(spread, ax, f'Spot Spread Heatmap ({country_a} - {country_b})', cmap='RdYlGn_r', value_format='decimal')

    def _create_calendar_heatmap(self, data_series, ax, title, cmap='RdYlGn_r', vmin=None, vmax=None, value_format='decimal', decimals=1):
        """
        Create a calendar heatmap using july library.
        """
        if data_series.empty or data_series.isna().all():
            ax.text(0.5, 0.5, 'No Data', ha='center', va='center', transform=ax.transAxes, fontsize=14)
            ax.set_title(title, fontsize=14, pad=2)
            return
        
        dates = data_series.index.tolist()
        values = data_series.values
        
        if value_format == 'int':
            values = np.round(values, 0)
        else:
            values = np.round(values, decimals)
        
        if vmin is None: cmin = float(np.nanpercentile(values, 5))
        else: cmin = float(vmin)
            
        if vmax is None: cmax = float(np.nanpercentile(values, 95))
        else: cmax = float(vmax)
        
        # Make range symmetric
        if cmin < 0 and cmax > 0:
            limit = max(abs(cmin), abs(cmax))
            cmin = -limit
            cmax = limit

        july.heatmap(
            dates=dates,
            data=values,
            cmap=cmap,
            month_grid=True,
            horizontal=True,
            value_label=True,
            date_label=False,
            weekday_label=True,
            month_label=True,
            year_label=True,
            colorbar=True,
            value_format=value_format,
            title=title,
            cmin=cmin,
            cmax=cmax,
            week_avg=True,
            month_avg=True,
            ax=ax,
            fontfamily="monospace",
            fontsize=7,
            titlesize=10
        )
        
        # Make bold labels
        for text in ax.texts:
            text.set_weight('bold')

def run_location_spread_report(
    border_config: dict = None,
    output_file: str = None,
    output_dir: str = None,
    recipients: str = None,
    dry_run: bool = False,
    start_date: str = '2018-01-01',
) -> dict:
    """
    Entry point for Dagster orchestration.

    Args:
        border_config: Dict mapping hub country to list of border countries.
                       Defaults to BORDER_CONFIG.
        output_file: Output PDF filename (auto-generated if None).
        output_dir: Output directory (default: current directory).
        recipients: Email recipients (semicolon-separated). If None, skip email.
        dry_run: If True, skip sending emails.
        start_date: Start date for spot history (default '2018-01-01').

    Returns:
        dict with output_file path and metadata.
    """
    import warnings
    warnings.simplefilter(action='ignore', category=FutureWarning)

    if border_config is None:
        border_config = BORDER_CONFIG

    if output_file is None:
        output_file = f"Location_Spread_Report_JG_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.pdf"

    if output_dir:
        output_file = os.path.join(output_dir, output_file)

    loader = DataLoader()
    report = Report(loader=loader, border_config=border_config)
    report.generate_report(
        start_date=start_date,
        output_file=output_file,
    )

    hubs = list(border_config.keys())
    total_borders = sum(len(v) for v in border_config.values())

    if recipients is None:
        print("Warning: No email recipients specified. Skipping email.")
        return {
            "output_file": output_file,
            "hubs": hubs,
            "num_hubs": len(hubs),
            "total_borders": total_borders,
            "email_sent": False,
            "recipients": None,
        }

    report_date = datetime.now().strftime('%Y-%m-%d')
    subject = f"Location Spread Report - {report_date}"
    body = f"""
    <html>
    <body>
    <p>Please find attached the Location Spread Report for {report_date}.</p>
    <p>Hubs: {', '.join(hubs)}</p>
    <p><i>This is an automated report.</i></p>
    </body>
    </html>
    """

    email_sent = False
    if dry_run:
        print(f"[DRY RUN] Would send email to {recipients} with attachment {output_file}")
    else:
        try:
            print(f"Sending email to {recipients}...")
            import base64
            with open(output_file, 'rb') as f:
                pdf_content = base64.b64encode(f.read()).decode('utf-8')

            attachment = {
                'content': pdf_content,
                'filename': os.path.basename(output_file)
            }

            send_email(
                recipients=recipients,
                subject=subject,
                body=body,
                attachment=attachment,
            )
            print("Email sent successfully.")
            email_sent = True
        except Exception as e:
            print(f"Failed to send email: {e}")
            import traceback
            traceback.print_exc()

    return {
        "output_file": output_file,
        "hubs": hubs,
        "num_hubs": len(hubs),
        "total_borders": total_borders,
        "email_sent": email_sent,
        "recipients": recipients,
    }


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Location Spread Report')
    parser.add_argument('--start_date', type=str, default=None, help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end_date', type=str, default=None, help='End date (YYYY-MM-DD)')
    parser.add_argument('--output', type=str, default=None, help='Output PDF file')

    args = parser.parse_args()

    result = run_location_spread_report(
        start_date=args.start_date or '2018-01-01',
        output_file=args.output,
    )
