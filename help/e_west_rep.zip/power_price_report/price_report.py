import sys
import os
# Ensure we use local eu_corelib if available
corelib_path = 'c:/Users/Michael.Kane/OneDrive - Jain Global/Projects/eu_corelib'
if os.path.exists(corelib_path) and corelib_path not in sys.path:
    sys.path.insert(0, corelib_path)

from jain_commods.fundamental.power.price_functions import FuelSpreadsCalculator
from jain_commods.core.cache.data.market import PricePowerSpot, PriceGasSpot, PriceCO2Spot, PriceCoalSpot, ForexSpot

# Pre-load all S3 caches BEFORE snowflake.connector is imported.
# snowflake.connector vendors its own urllib3 which contaminates botocore's
# HTTP session and causes "issubclass() arg 2 must be a class" errors.
_PRELOADED_CACHES = {}
for _label, _cls, _kwargs in [
    ('power', PricePowerSpot, {'freq': 'h'}),
    ('gas', PriceGasSpot, {}),
    ('co2', PriceCO2Spot, {}),
    ('coal', PriceCoalSpot, {}),
    ('fx', ForexSpot, {}),
]:
    try:
        _obj = _cls(**_kwargs)
        _obj.load(from_s3=True, show_metadata=False)
        if _obj.data is not None and not _obj.data.empty:
            _PRELOADED_CACHES[_label] = _obj.data
    except Exception:
        pass

# BBGQuery requires Bloomberg Terminal - optional in Docker
try:
    from jain_commods.core.interfaces.bloomberg import BBGQuery
    BLOOMBERG_AVAILABLE = True
except ImportError:
    BBGQuery = None
    BLOOMBERG_AVAILABLE = False
from jain_commods.core.interfaces.snowflake.bbg_heren import BloombergHerenQuery
from jain_commods.core.interfaces.snowflake.epexquery import EPEXQuery
from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery


from jain_commods.core.util.curves import BootstrapBuilder, RedundancyMode, CurveMetadata, SplineBuilder, DayOfWeekAdjuster, Contract, Curve
from jain_commods.core.util.curves.shaping import HistoricalShaper
from jain_commods.core.util.emailhelper import send_email

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import snowflake.connector

# Monkey-patch snowflake connector to bypass SSL/OCSP checks due to environmental issues
_original_connect = snowflake.connector.connect
def insecure_connect(*args, **kwargs):
    kwargs['insecure_mode'] = True
    return _original_connect(*args, **kwargs)
snowflake.connector.connect = insecure_connect

import snowflake.connector
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Rectangle
import holidays


# Support both direct execution and package import
try:
    from .utils import july
    from .utils.july.utils import date_range
except ImportError:
    from utils import july
    from utils.july.utils import date_range
import warnings

import matplotlib as mpl
if not hasattr(mpl.cbook, 'MatplotlibDeprecationWarning'):
    mpl.cbook.MatplotlibDeprecationWarning = mpl.MatplotlibDeprecationWarning


class DataLoader:
    UK_CARBON_TAX = 18.0  # GBP/tonne

    def __init__(self):
        self.calc = FuelSpreadsCalculator()
        self.bbg = BBGQuery(p_on_server=True) if BLOOMBERG_AVAILABLE else None
        self.epex = EPEXQuery()
        self._power_cache = None
        self._gas_cache = None
        self._co2_cache = None
        self._coal_cache = None
        self._fx_cache = None

    def _ensure_power_cache(self):
        if self._power_cache is None:
            self._power_cache = _PRELOADED_CACHES.get('power')
        return self._power_cache

    def _ensure_gas_cache(self):
        if self._gas_cache is None:
            self._gas_cache = _PRELOADED_CACHES.get('gas')
        return self._gas_cache

    def _ensure_co2_cache(self):
        if self._co2_cache is None:
            self._co2_cache = _PRELOADED_CACHES.get('co2')
        return self._co2_cache

    def _ensure_coal_cache(self):
        if self._coal_cache is None:
            self._coal_cache = _PRELOADED_CACHES.get('coal')
        return self._coal_cache

    def _ensure_fx_cache(self):
        if self._fx_cache is None:
            self._fx_cache = _PRELOADED_CACHES.get('fx')
        return self._fx_cache

    def _get_fx_series(self, pair='EUR/GBP'):
        """Get FX rate time series from cache."""
        raw = self._ensure_fx_cache()
        if raw is None or raw.empty:
            return pd.Series(dtype=float)
        for col in raw.columns:
            if pair.replace('/', '_') in str(col).replace('/', '_').upper() or pair in str(col):
                series = raw[col].dropna()
                series.index = pd.to_datetime(series.index)
                if series.index.tz is not None:
                    series.index = series.index.tz_localize(None)
                return series
        return pd.Series(dtype=float)

    @staticmethod
    def _last_uk_business_day(ref_date=None):
        from datetime import date as _date
        if ref_date is None:
            ref_date = _date.today()
        uk_hols = holidays.UK(years=range(ref_date.year - 1, ref_date.year + 1))
        d = ref_date - timedelta(days=1)
        while d.weekday() >= 5 or d in uk_hols:
            d -= timedelta(days=1)
        return d

    def _fetch_macq_uk_power(self, as_of_date=None):
        """
        Fetch UK power forward curve from MACQ_FWD_CURVES in Snowflake.
        Returns DataFrame in BootstrapBuilder format with columns:
        commodity, hub, start, end, price, shape, issue_date
        """
        from jain_commods.core.interfaces.snowflake.snowflake import SnowFlake
        if as_of_date is None:
            as_of_date = self._last_uk_business_day()

        as_of_str = as_of_date.strftime('%Y-%m-%d') if hasattr(as_of_date, 'strftime') else str(as_of_date)

        try:
            sf = SnowFlake(database='COMMOD', schema='PUBLIC')
            cur = sf._conn.cursor()
            cur.execute(f"""
                SELECT DATE, PRICE, GRANULARITY
                FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
                WHERE COMMODITY = 'ELEC_UK.BASELOAD'
                  AND AS_OF_DATE = '{as_of_str}'
                ORDER BY DATE
            """)
            df = cur.fetch_pandas_all()
            cur.close()
            sf._conn.close()
        except Exception as e:
            print(f"  Error fetching MACQ UK power: {e}")
            return pd.DataFrame()

        if df.empty:
            return pd.DataFrame()

        contracts = []
        for _, row in df.iterrows():
            d = pd.Timestamp(row['DATE'])
            gran = row['GRANULARITY']
            price = float(row['PRICE'])

            if gran == 'D':
                start, end = d, d + pd.Timedelta(days=1)
            elif gran == 'M':
                start = d
                end = d + pd.offsets.MonthEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Q':
                start = d
                end = d + pd.offsets.QuarterEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Y':
                start = d
                end = pd.Timestamp(year=d.year + 1, month=1, day=1)
            else:
                start, end = d, d + pd.Timedelta(days=1)

            contracts.append({
                'commodity': 'Power', 'hub': 'UK',
                'start': start, 'end': end,
                'price': price, 'shape': 'Base',
                'issue_date': pd.Timestamp(as_of_date),
            })

        return pd.DataFrame(contracts)

    def _fetch_macq_uk_power_history(self, start_date, end_date):
        """
        Fetch multiple AS_OF_DATEs of UK power forward curves from MACQ.
        Returns DataFrame with all contracts across all dates.
        """
        from jain_commods.core.interfaces.snowflake.snowflake import SnowFlake
        start_str = start_date.strftime('%Y-%m-%d')
        end_str = end_date.strftime('%Y-%m-%d')
        try:
            sf = SnowFlake(database='COMMOD', schema='PUBLIC')
            cur = sf._conn.cursor()
            cur.execute(f"""
                SELECT DATE, PRICE, GRANULARITY, AS_OF_DATE
                FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
                WHERE COMMODITY = 'ELEC_UK.BASELOAD'
                  AND AS_OF_DATE >= '{start_str}'
                  AND AS_OF_DATE <= '{end_str}'
                ORDER BY AS_OF_DATE, DATE
            """)
            df = cur.fetch_pandas_all()
            cur.close()
            sf._conn.close()
        except Exception as e:
            print(f"  Error fetching MACQ UK power history: {e}")
            return pd.DataFrame()

        if df.empty:
            return pd.DataFrame()

        contracts = []
        for _, row in df.iterrows():
            d = pd.Timestamp(row['DATE'])
            gran = row['GRANULARITY']
            price = float(row['PRICE'])
            as_of = pd.Timestamp(row['AS_OF_DATE'])

            if gran == 'D':
                start, end = d, d + pd.Timedelta(days=1)
            elif gran == 'M':
                start = d
                end = d + pd.offsets.MonthEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Q':
                start = d
                end = d + pd.offsets.QuarterEnd(0) + pd.Timedelta(days=1)
            elif gran == 'Y':
                start = d
                end = pd.Timestamp(year=d.year + 1, month=1, day=1)
            else:
                start, end = d, d + pd.Timedelta(days=1)

            contracts.append({
                'commodity': 'Power', 'hub': 'UK',
                'start': start, 'end': end,
                'price': price, 'shape': 'Base',
                'issue_date': as_of,
            })

        return pd.DataFrame(contracts)

    def build_forward_curves(self, country_code):
        """
        Build daily forward curves for Power, Gas, Coal, and Carbon using the 'curves' package.
        For UK: uses ICE NBP (gas) and ICE UKA (carbon). UK power forward not available via EEX.
        Returns a dictionary of daily Series.
        """
        print(f"  Building forward curves for {country_code} using 'curves' package...")
        is_uk = (country_code == 'UK')

        df_contracts = self._fetch_raw_contracts(country_code)

        if df_contracts.empty:
            print("  Warning: No contract data found.")
            return {}

        builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
        builder.add_contracts(df_contracts)

        curves = {}
        commodities = ['Power', 'Gas', 'Coal', 'Carbon']

        for comm in commodities:
            try:
                relevant = [c for c in builder.contracts if c.commodity == comm]
                if not relevant:
                    continue

                df_curve = builder.build_curves(freq='D', commodity=comm)
                if not df_curve.empty:
                    if isinstance(df_curve.index, pd.PeriodIndex):
                        df_curve.index = df_curve.index.to_timestamp()
                    curves[comm] = df_curve['price']
            except Exception as e:
                print(f"  Error building {comm} curve: {e}")

        return curves

    def _fetch_raw_contracts(self, country_code):
        """
        Fetch and standardize raw futures data for Power, Gas, Coal, Carbon.
        For UK: uses ICE NBP (gas) and ICE UKA (carbon). No EEX power for UK.
        """
        dfs = []
        is_uk = (country_code == 'UK')

        # A. Power
        if is_uk:
            try:
                df_uk_power = self._fetch_macq_uk_power()
                if not df_uk_power.empty:
                    print(f"  Loaded {len(df_uk_power)} UK power contracts from MACQ")
                    dfs.append(df_uk_power)
                else:
                    print(f"  Warning: MACQ UK power returned empty")
            except Exception as e:
                print(f"  Error fetching MACQ UK Power: {e}")
        else:
            try:
                eex = EEXQuery()
                df_power = eex.get_latest_prices(country_code=country_code.lower(), profile='Base')
                if not df_power.empty:
                    df_p = self._transform_eex_data(df_power, country_code)
                    dfs.append(df_p)
            except Exception as e:
                print(f"  Error fetching EEX Power: {e}")

        # B. Gas, Coal, Carbon via ICE
        try:
            from jain_commods.core.interfaces.snowflake.icequery import ICEFuturesQuery
            ice = ICEFuturesQuery()

            if is_uk:
                ice_products = [
                    ('NBP', 'Gas', 'NBP'),
                    ('API2', 'Coal', 'API2'),
                    ('UKA', 'Carbon', 'UKA')
                ]
            else:
                ice_products = [
                    ('TTF', 'Gas', 'TTF'),
                    ('API2', 'Coal', 'API2'),
                    ('EUA', 'Carbon', 'EUA')
                ]

            for prod_code, comm_name, hub_name in ice_products:
                try:
                    df_ice = ice.get_curve(prod_code)
                    if not df_ice.empty:
                        df_i = self._transform_ice_data(df_ice, comm_name, hub_name)
                        if not df_i.empty:
                            dfs.append(df_i)
                        else:
                            print(f"  Warning: ICE {prod_code} transformation returned empty.")
                    else:
                        print(f"  Warning: ICE get_curve returned empty for {prod_code}")
                except Exception as e:
                    print(f"  Error fetching ICE {prod_code}: {e}")
                    import traceback
                    traceback.print_exc()

        except Exception as e:
            print(f"  Error initializing ICEQuery: {e}")

        if dfs:
            return pd.concat(dfs, ignore_index=True)
        return pd.DataFrame()

    def get_historical_curves(self, country_code, days=14):
        """
        Fetch and build forward curves for the last N trading days.
        Returns a structured dictionary:
        {
            trading_date: {
                'Power': Series,
                'Gas': Series,
                'Carbon': Series,
                'CSS': Series
            }
        }
        """
        print(f"  Fetching historical curves for {country_code} (last {days} days)...")
        is_uk = (country_code == 'UK')

        end_date = datetime.now()
        start_date = end_date - timedelta(days=days*2)

        df_contracts = self._fetch_historical_contracts(country_code, start_date, end_date)
        
        if df_contracts.empty:
            print("  Warning: No historical contract data found.")
            return {}
            
        # Normalize issue_date to align EEX and ICE timestamps
        df_contracts['issue_date'] = df_contracts['issue_date'].dt.normalize()
            
        # 2. Process each trading day
        history = {}
        
        # Get unique trading dates, sorted
        trading_dates = sorted(df_contracts['issue_date'].unique())
        
        # Take only the last N days requested
        trading_dates = trading_dates[-days:]
        
        print(f"  Building curves for {len(trading_dates)} trading dates...")
        
        for trade_date in trading_dates:
            try:
                # Filter contracts for this specific date
                # Ensure comparison works by converting to datetime if needed, though they should be datetimes from transform
                daily_contracts = df_contracts[df_contracts['issue_date'] == trade_date].copy()
                
                builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
                builder.add_contracts(daily_contracts)
                
                daily_data = {}
                commodities = ['Power', 'Gas', 'Carbon'] # Coal optional for CSS
                
                for comm in commodities:
                    try:
                        relevant = [c for c in builder.contracts if c.commodity == comm]
                        if not relevant: continue
                        
                        df_curve = builder.build_curves(freq='D', commodity=comm)
                        if not df_curve.empty:
                            if isinstance(df_curve.index, pd.PeriodIndex):
                                df_curve.index = df_curve.index.to_timestamp()
                            daily_data[comm] = df_curve['price']
                    except Exception as e:
                        pass
                
                # Calculate CSS if we have Gas and Carbon (Power optional for UK)
                has_gas = 'Gas' in daily_data
                has_carbon = 'Carbon' in daily_data
                has_power = 'Power' in daily_data

                if has_gas and has_carbon:
                    idx_parts = [daily_data['Gas'].index, daily_data['Carbon'].index]
                    if has_power:
                        idx_parts.append(daily_data['Power'].index)
                    all_indices = idx_parts[0]
                    for idx_part in idx_parts[1:]:
                        all_indices = all_indices.union(idx_part)
                    if all_indices.empty:
                        continue

                    min_date = all_indices.min()
                    max_date = all_indices.max()
                    full_idx = pd.date_range(start=min_date, end=max_date, freq='D')

                    g = daily_data['Gas'].reindex(full_idx).interpolate(method='linear', limit_direction='both')
                    c = daily_data['Carbon'].reindex(full_idx).interpolate(method='linear', limit_direction='both')

                    GAS_EFF = 0.4913 if is_uk else 0.50
                    GAS_EMISSIONS = 0.1821

                    if is_uk:
                        THERMS_PER_MWH = 34.121
                        g = g * THERMS_PER_MWH / 100.0
                        c_total = c + DataLoader.UK_CARBON_TAX
                    else:
                        c_total = c

                    if has_power:
                        p = daily_data['Power'].reindex(full_idx).interpolate(method='linear', limit_direction='both')
                        gas_cost = (g / GAS_EFF) + (GAS_EMISSIONS / GAS_EFF) * c_total
                        daily_data['CSS'] = p - gas_cost
                        daily_data['Power'] = p

                    daily_data['Gas'] = g
                    daily_data['Carbon'] = c
                
                if daily_data:
                    history[trade_date] = daily_data
                    
            except Exception as e:
                print(f"    Error building history for {trade_date}: {e}")
                
        return history

    def _fetch_historical_contracts(self, country_code, start_date, end_date):
        """
        Fetch historical raw futures data for Power, Gas, Carbon.
        For UK: uses MACQ Snowflake for Power, ICE for NBP/UKA.
        """
        dfs = []
        is_uk = (country_code == 'UK')

        if is_uk:
            try:
                df_uk_power = self._fetch_macq_uk_power_history(start_date, end_date)
                if not df_uk_power.empty:
                    print(f"  Loaded {len(df_uk_power)} UK power historical contracts from MACQ")
                    dfs.append(df_uk_power)
            except Exception as e:
                print(f"  Error fetching MACQ UK Power history: {e}")
        else:
            try:
                eex = EEXQuery()
                df_power = eex.get_strip_prices(
                    country_code=country_code.lower(),
                    profile='Base',
                    start_date=start_date,
                    end_date=end_date
                )
                if not df_power.empty:
                    df_p = self._transform_eex_data(df_power, country_code)
                    dfs.append(df_p)
            except Exception as e:
                print(f"  Error fetching historical EEX Power: {e}")

        try:
            from jain_commods.core.interfaces.snowflake.icequery import ICEFuturesQuery
            ice = ICEFuturesQuery()

            if is_uk:
                ice_products = [
                    ('NBP', 'Gas', 'NBP'),
                    ('UKA', 'Carbon', 'UKA')
                ]
            else:
                ice_products = [
                    ('TTF', 'Gas', 'TTF'),
                    ('EUA', 'Carbon', 'EUA')
                ]

            date_range = pd.bdate_range(start=start_date, end=end_date)

            for prod_code, comm_name, hub_name in ice_products:
                print(f"  Fetching ICE {prod_code} history ({len(date_range)} days)...")
                for trade_date in date_range:
                    try:
                        df_ice = ice.get_curve(
                            product=prod_code,
                            trade_date=trade_date
                        )
                        if not df_ice.empty:
                            df_i = self._transform_ice_data(df_ice, comm_name, hub_name)
                            if not df_i.empty:
                                dfs.append(df_i)
                    except Exception as e:
                        pass

        except Exception as e:
            print(f"  Error initializing ICEQuery: {e}")

        if dfs:
            return pd.concat(dfs, ignore_index=True)
        return pd.DataFrame()

    def _transform_eex_data(self, df, country_code):
        # Expected cols: DELIVERY_START, DELIVERY_END, SETTLEMENT_PRICE, TRADING_DAY
        df = df[df['SETTLEMENT_PRICE'].notna()].copy()
        out = pd.DataFrame()
        out['start'] = pd.to_datetime(df['DELIVERY_START'])
        out['end'] = pd.to_datetime(df['DELIVERY_END']) + timedelta(days=1)
        out['price'] = df['SETTLEMENT_PRICE']
        out['issue_date'] = pd.to_datetime(df['TRADING_DAY'])
        out['hub'] = country_code 
        out['commodity'] = 'Power'
        out['source'] = 'EEX'
        return out

    def _transform_ice_data(self, df, commodity, hub):
        # ICE get_curve returns: DELIVERY_START, DELIVERY_END, SETTLEMENT_PRICE, TRADE_DATE
        
        # Standardize column names
        price_col = 'PRICE' if 'PRICE' in df.columns else 'SETTLEMENT_PRICE'
        if price_col not in df.columns: 
            print(f"  Missing price col in ICE data. Cols: {df.columns}")
            return pd.DataFrame()
        
        df = df[df[price_col].notna()].copy()
        out = pd.DataFrame()
        
        # Date parsing - handle both START_DATE (old) and DELIVERY_START (new)
        if 'DELIVERY_START' in df.columns and 'DELIVERY_END' in df.columns:
            out['start'] = pd.to_datetime(df['DELIVERY_START'])
            out['end'] = pd.to_datetime(df['DELIVERY_END']) + timedelta(days=1)
        elif 'START_DATE' in df.columns and 'END_DATE' in df.columns:
            out['start'] = pd.to_datetime(df['START_DATE'])
            out['end'] = pd.to_datetime(df['END_DATE']) + timedelta(days=1)
        else:
             print(f"  Missing date cols in ICE data. Cols: {df.columns}")
             return pd.DataFrame()
             
        out['price'] = df[price_col]
        
        # Issue Date
        date_col = 'TRADE_DATE' if 'TRADE_DATE' in df.columns else 'TRADING_DAY'
        if date_col in df.columns:
            out['issue_date'] = pd.to_datetime(df[date_col])
        else:
            out['issue_date'] = datetime.now() # Fallback
            
        out['hub'] = hub
        out['commodity'] = commodity
        out['source'] = 'ICE'
        return out


    def get_latest_fx_rate(self):
        """
        Fetch latest EURUSD exchange rate from Bloomberg.
        Returns EUR/USD (e.g. 1.10).
        """
        # Bloomberg not available in Docker
        if self.bbg is None:
            print("  Bloomberg not available, using default FX rate 1.10")
            return 1.10
            
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=7)
            
            # BBGQuery.fetch_hist arguments: p_ticker, p_field, p_start, p_end...
            df = self.bbg.fetch_hist(
                p_ticker=['EURUSD Curncy'],
                p_field=['PX_LAST'],
                p_start=start_date,
                p_end=end_date
            )
            
            if df is not None and not df.empty and 'EURUSD Curncy_PX_LAST' in df.columns:
                return df['EURUSD Curncy_PX_LAST'].iloc[-1]
            
            print("  Warning: Could not fetch FX rate (empty), using default 1.10")
            return 1.10
            
        except Exception as e:
            print(f"  Error fetching FX: {e}")
            return 1.10

    # ... (skipping to _calculate_monthly_metrics merge logic)

    def load_power(self, countries='DE', start_date='2023-01-01', end_date=None):
        if end_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')

        target_countries = countries if isinstance(countries, list) else [countries]

        # --- Try cache first ---
        raw = self._ensure_power_cache()
        if raw is not None and not raw.empty:
            s_ts = pd.Timestamp(start_date)
            e_ts = pd.Timestamp(end_date)
            zone_map = {'UK': 'GB'}

            result_frames = []
            for cc in target_countries:
                cache_zone = zone_map.get(cc, cc)
                preferred_ccy = 'GBP' if cc == 'UK' else 'EUR'
                cols = [c for c in raw.columns
                        if c[0].upper() == cache_zone.upper() and c[2] == preferred_ccy]
                if not cols:
                    cols = [c for c in raw.columns
                            if c[0].upper() == cache_zone.upper()]
                if not cols:
                    print(f"Warning: {cc} not found in power cache, will try EPEX fallback")
                    continue

                series = raw[cols[0]].copy()
                series.index = pd.to_datetime(series.index)
                if series.index.tz is not None:
                    series.index = series.index.tz_localize(None)
                series = series.dropna()
                series = series[(series.index >= s_ts) & (series.index <= e_ts)]
                series.name = cc
                result_frames.append(series)

            if result_frames:
                return pd.concat(result_frames, axis=1)

        # --- Fallback to EPEX ---
        print(f"  Falling back to EPEX for power data...")
        try:
            if isinstance(start_date, datetime):
                start_date = start_date.strftime('%Y-%m-%d')

            epex_hourly = self.epex.get_spot_prices(
                country=countries,
                start_date=start_date,
                end_date=end_date,
                convert_timezone=False
            )

            epex_hourly['TIMESTAMP'] = epex_hourly['TIMESTAMP'].dt.tz_localize('UTC').dt.tz_convert(
                'Europe/Berlin').dt.tz_localize(None)

            if not epex_hourly.empty:
                date_col = 'DELIVERY_TIME' if 'DELIVERY_TIME' in epex_hourly.columns else 'TIMESTAMP'
                val_col = 'PRICE' if 'PRICE' in epex_hourly.columns else 'VALUE'

                if date_col in epex_hourly.columns:
                    epex_hourly[date_col] = pd.to_datetime(epex_hourly[date_col])
                    epex_hourly = epex_hourly.pivot_table(index=date_col, columns='COUNTRY', values=val_col)
                    return epex_hourly
                else:
                    print("Warning: Could not find date column in EPEX data")
                    return pd.DataFrame()
            else:
                print("Warning: EPEX data empty")
                return pd.DataFrame()

        except Exception as e:
            print(f"Error fetching EPEX Power data: {e}")
            return pd.DataFrame()

    def load_gas(self, start_date='2019-01-01', country_code='DE'):
        """
        Load gas prices from cache.
        Returns DataFrame with TTF (EUR/MWh) and NBP columns.
        For UK the caller will convert NBP from EUR/MWh to GBP/MWh using FX.
        Falls back to Bloomberg Heren if cache is empty.
        """
        try:
            raw = self._ensure_gas_cache()
            if raw is not None and not raw.empty:
                s_ts = pd.Timestamp(start_date)
                result = {}
                for hub_name in ['TTF', 'NBP']:
                    cols = [c for c in raw.columns if hub_name in str(c[0]).upper()]
                    if cols:
                        series = raw[cols[0]].dropna().copy()
                        series.index = pd.to_datetime(series.index)
                        if series.index.tz is not None:
                            series.index = series.index.tz_localize(None)
                        series = series[series.index >= s_ts]
                        result[hub_name] = series
                if result:
                    return pd.DataFrame(result)
        except Exception as e:
            print(f"  Gas cache failed ({e}), falling back to Bloomberg Heren...")

        bbg_heren = BloombergHerenQuery()
        try:
            tickers = ["IINDTEDI ICIS Index", "IINDNGDI ICIS Index"]
            tickers_history = bbg_heren.get_ticker_history(bbg_tickers=tickers, start_date=start_date)
            gas_data = tickers_history.pivot_table(index='DATE', columns='BBG_TICKER', values='VALUE')
            if gas_data.empty:
                print(f"Warning: No gas data found for {tickers}")
                return pd.DataFrame()
            gas_data.columns = ['NBP', 'TTF']
            return gas_data
        except Exception as e:
            print(f"Error fetching Gas data: {e}")
            return pd.DataFrame()
        finally:
            if hasattr(bbg_heren, 'close') and callable(bbg_heren.close):
                bbg_heren.close()

    def load_coal(self, start_date='2019-01-01', end_date=None):
        """
        Load Coal (API2) prices and FX rates from Bloomberg.
        """
        # Bloomberg not available in Docker
        if self.bbg is None:
            print("  Bloomberg not available, skipping Coal data")
            return pd.DataFrame()
            
        if end_date is None:
            end_date = datetime.now()
        
        # Ensure datetime objects
        if isinstance(start_date, str):
            start_date_dt = datetime.strptime(start_date, '%Y-%m-%d')
        else:
            start_date_dt = start_date
            
        if isinstance(end_date, str):
            end_date_dt = datetime.strptime(end_date, '%Y-%m-%d')
        else:
            end_date_dt = end_date
            
        try:
            tickers = {'Coal': 'XA1 Comdty'}
            bbg_tickers = list(tickers.values()) + ['EURUSD Curncy']

            hist_other = self.bbg.fetch_hist(
                bbg_tickers,
                ['PX_LAST'],
                start_date_dt,
                end_date_dt
            )

            # Process BBG Data
            if hist_other is not None and not hist_other.empty:
                rename_map = {}
                for name, ticker in tickers.items():
                    expected_col = f"{ticker}_PX_LAST"
                    if expected_col in hist_other.columns:
                        rename_map[expected_col] = name

                fx_col = 'EURUSD Curncy_PX_LAST'
                if fx_col in hist_other.columns:
                    hist_other['USD_TO_EUR'] = 1 / hist_other[fx_col]
                else:
                    hist_other['USD_TO_EUR'] = 0.85

                hist_other = hist_other.rename(columns=rename_map)
                return hist_other
            else:
                return pd.DataFrame()

        except Exception as e:
            print(f"Error fetching Coal/FX data: {e}")
            return pd.DataFrame()

    def load_carbon(self, start_date='2019-01-01', end_date=None):
        """
        Load daily carbon prices (EUA in EUR/t, UKA in GBP/t).
        Tries cache first, falls back to Bloomberg.
        """
        print("Loading daily carbon prices...")

        if end_date is None:
            end_date = datetime.now()

        s_ts = pd.Timestamp(start_date)
        e_ts = pd.Timestamp(end_date)

        try:
            raw = self._ensure_co2_cache()
            if raw is not None and not raw.empty:
                result = {}
                for label in ['EUA', 'UKA']:
                    cols = [c for c in raw.columns if label in str(c[0]).upper()]
                    if cols:
                        series = raw[cols[0]].dropna().copy()
                        series.index = pd.to_datetime(series.index)
                        if series.index.tz is not None:
                            series.index = series.index.tz_localize(None)
                        series = series[(series.index >= s_ts) & (series.index <= e_ts)]
                        result[label] = series
                if result:
                    return pd.DataFrame(result)
        except Exception as e:
            print(f"  CO2 cache failed ({e}), falling back to Bloomberg...")

        if self.bbg is None:
            print("  Bloomberg not available, skipping Carbon data")
            return pd.DataFrame()

        if isinstance(start_date, str):
            start_date_dt = datetime.strptime(start_date, '%Y-%m-%d')
        else:
            start_date_dt = start_date
        if isinstance(end_date, str):
            end_date_dt = datetime.strptime(end_date, '%Y-%m-%d')
        else:
            end_date_dt = end_date

        try:
            tickers = ["MO1 Comdty", "UKE1 Comdty"]
            carbon_df = self.bbg.fetch_hist(
                p_ticker=tickers, p_field="PX_LAST",
                p_start=start_date_dt, p_end=end_date_dt, p_pd_datetime=True
            )
            if carbon_df is not None and not carbon_df.empty:
                rename_map = {'MO1 Comdty_PX_LAST': 'EUA', 'UKE1 Comdty_PX_LAST': 'UKA'}
                carbon_df = carbon_df.rename(columns=rename_map)
                available_cols = [col for col in ['EUA', 'UKA'] if col in carbon_df.columns]
                return carbon_df[available_cols]
            return pd.DataFrame()
        except Exception as e:
            print(f"Error fetching Carbon Bloomberg data: {e}")
            return pd.DataFrame()


    def get_hourly_forward_curve(self, country_code):
        """
        Build fully shaped hourly forward curve for Power using Base + Peak contracts.
        For UK: uses MACQ daily Baseload curve (no hourly shaping).
        Returns a Series of hourly prices.
        """
        print(f"  Building hourly forward curve for {country_code}...")

        if country_code == 'UK':
            return self._get_uk_hourly_forward()

        try:
            eex = EEXQuery()
            
            # Helper to fetch and prepare contracts
            def fetch_and_prepare(profile):
                # Fetch latest prices
                df = eex.get_latest_prices(country_code=country_code.lower(), profile=profile)
                if df.empty: return []
                
                # Check Trading Day
                date_col = 'TRADING_DAY' if 'TRADING_DAY' in df.columns else 'issue_date'
                if date_col in df.columns:
                    trading_days = pd.to_datetime(df[date_col]).unique()
                    trading_day = trading_days.max() if len(trading_days) > 1 else trading_days[0]
                else:
                    trading_day = pd.Timestamp.now().normalize()
                    
                df_clean = df[df['SETTLEMENT_PRICE'].notna()].copy()
                contracts = []
                for _, row in df_clean.iterrows():
                    start = pd.Timestamp(row['DELIVERY_START'])
                    end = pd.Timestamp(row['DELIVERY_END']) + pd.Timedelta(days=1)
                    # Skip if start >= end
                    if start >= end: continue
                    
                    c = Contract(
                        commodity='Power',
                        hub=country_code.upper(),
                        start=start,
                        end=end,
                        shape=profile,
                        price=float(row['SETTLEMENT_PRICE']),
                        issue_date=trading_day
                    )
                    contracts.append(c)
                return contracts

            base_contracts = fetch_and_prepare('Base')
            peak_contracts = fetch_and_prepare('Peak')
            
            if not base_contracts:
                return self._flag_missing_forward(
                    country_code, 'EEX returned no Base contracts'
                )

            # Reason the Peak leg ends up unavailable. Stays None if peak shaping works.
            peak_status = None
            if not peak_contracts:
                peak_status = f"EEX returned no Peak contracts for {country_code}"

            # Filter Peak contracts (Remove Day <= 1 day and Weekend contracts)
            valid_peak = []
            for c in peak_contracts:
                duration = (c.end - c.start).days
                if duration <= 1: continue
                bdays = pd.bdate_range(c.start, c.end - pd.Timedelta(seconds=1))
                if bdays.empty: continue
                valid_peak.append(c)
            if peak_contracts and not valid_peak:
                peak_status = "every Peak contract was daily or weekend-only and got filtered out"
            peak_contracts = valid_peak
            
            # Determine trading day from contracts
            trading_day = base_contracts[0].issue_date
            
            # --- Historical Shaper ---
            # Fetch history from 2023-01-01 to Trading Day for robust shaping
            end_hist = trading_day
            start_hist = pd.Timestamp('2023-01-01')
            
            # Try to get spot history using EPEX (reuse load_power logic or fetch directly)
            # We need hourly data for shaping
            hist_spot = self.load_power(country_code, start_hist.strftime('%Y-%m-%d'), end_hist.strftime('%Y-%m-%d'))
            
            if hist_spot.empty or country_code not in hist_spot.columns:
                print("    Warning: Could not fetch history for shaping. Using flat shape.")
                # We can still proceed with flat shape if needed, but for now let's try to be robust
                # If no history, maybe just return daily base? But user wants hourly.
                # Let's create a synthetic history if needed
                idx = pd.date_range(start_hist, end_hist, freq='h')
                vals = np.full(len(idx), 50.0)
                vals[(idx.hour >= 8) & (idx.hour < 20) & (idx.dayofweek < 5)] += 20.0
                history_df = pd.DataFrame({'price': vals}, index=idx)
            else:
                history_df = hist_spot[[country_code]].rename(columns={country_code: 'price'})
                history_df = history_df.dropna()
                
            shaper = HistoricalShaper(history_df)
            we_ratio_curve = shaper.predict_weekend_ratio_curve()
            
            # --- Build Curves ---
            temp_builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
            
            # Base
            non_redundant_base = temp_builder._filter_redundant_contracts(base_contracts)
            dow_adj = DayOfWeekAdjuster(weekdays=1.0, weekends=we_ratio_curve)
            base_spliner = SplineBuilder(non_redundant_base, freq='D', adjusters=[dow_adj])
            base_df = base_spliner.build_curves()
            
            if base_df.empty:
                return self._flag_missing_forward(
                    country_code, 'Base spline produced no rows'
                )
            
            # Filter Start > Trading Day
            if isinstance(base_df.index, pd.PeriodIndex):
                start_filter = pd.Period(trading_day, freq='D')
                base_df = base_df[base_df.index > start_filter]
                base_index_ts = base_df.index.to_timestamp()
            else:
                base_df = base_df[base_df.index > trading_day]
                base_index_ts = base_df.index

            # Peak
            peak_df = pd.DataFrame()
            if peak_contracts:
                non_redundant_peak = temp_builder._filter_redundant_contracts(peak_contracts)
                peak_spliner = SplineBuilder(non_redundant_peak, freq='D')
                
                try:
                    peak_df = peak_spliner.build_curves(shape='Peak')
                    if not peak_df.empty:
                        if isinstance(peak_df.index, pd.PeriodIndex):
                            start_filter = pd.Period(trading_day, freq='B')
                            peak_df = peak_df[peak_df.index > start_filter]
                        else:
                            peak_df = peak_df[peak_df.index > trading_day]
                    if peak_df.empty:
                        peak_status = "Peak spline produced no rows after the trading-day filter"
                except TypeError as te:
                     print(f"    Warning: Peak Spline Build Failed (TypeError): {te}")
                     print(f"      Contracts: {len(non_redundant_peak)}")
                     for c in non_redundant_peak[:3]:
                         print(f"      - {c.start} -> {c.end} | {c.price}")
                     peak_df = pd.DataFrame()
                     peak_status = f"Peak spline build raised TypeError: {te}"
                except Exception as e:
                     print(f"    Warning: Peak Spline Build Failed: {e}")
                     peak_df = pd.DataFrame()
                     peak_status = f"Peak spline build failed: {str(e).splitlines()[0]}"

            # --- Shaping ---
            curve_start_date = base_index_ts[0]
            
            # Prepare Input Curves
            valid_base_contracts = [c for c in non_redundant_base if c.start >= curve_start_date]
            
            base_curve_input = Curve(
                base_df['price'],
                index=base_df.index,
                metadata=CurveMetadata(commodity='Power', contracts=tuple(valid_base_contracts))
            )
            
            peak_curve_input = None
            if not peak_df.empty:
                valid_peak_contracts = [c for c in non_redundant_peak if c.start >= curve_start_date]
                peak_curve_input = Curve(
                    peak_df['price'],
                    index=peak_df.index,
                    metadata=CurveMetadata(commodity='Power', contracts=tuple(valid_peak_contracts))
                )
                
            final_hourly_curve = shaper.shape_hourly(
                base_daily_curve=base_curve_input,
                peak_daily_curve=peak_curve_input
            )
            
            # Convert to pandas Series to ensure downstream compatibility
            result = pd.Series(data=final_hourly_curve.values, index=final_hourly_curve.index)
            if peak_curve_input is None:
                self._flag_unshaped_forward(
                    result, country_code, peak_status or 'Peak leg unavailable'
                )
            else:
                result.attrs['shape_source'] = 'Base + Peak (market-implied)'
            self._flag_stale_forward(result, country_code, trading_day)
            return result

        except Exception as e:
            import traceback
            traceback.print_exc()
            return self._flag_missing_forward(
                country_code, f'build failed: {str(e).splitlines()[0]}'
            )

    def _flag_unshaped_forward(self, series, country_code, reason,
                               shape_source='Base only (historical shape)'):
        """
        Record and announce that an hourly forward curve carries no market peak shape.

        Without a Peak leg the intraday profile comes from the fitted historical shape
        rescaled to the Base price, so the peak/off-peak spread is historical rather
        than market-implied. Callers read these attrs to label the output.
        """
        note = f"{country_code}: no market peak shape ({reason})"
        series.attrs['shape_source'] = shape_source
        series.attrs['shape_warning'] = note
        series.attrs['shape_detail'] = ('Forward peak/off-peak spread is historical, '
                                        'not market-implied.')
        print(f"    [SHAPE WARNING] {note}")
        print( "                    Intraday peak/off-peak spread is historical, "
               "not market-implied.")

    def _flag_missing_forward(self, country_code, reason):
        """
        Return an empty curve stamped with the reason no forward could be built.

        An absent curve is easy to miss because the chart still renders from history
        alone. Callers read these attrs to caption the gap rather than leave it blank.
        """
        note = f"{country_code}: no forward curve ({reason})"
        series = pd.Series(dtype=float)
        series.attrs['shape_source'] = 'No forward curve'
        series.attrs['shape_warning'] = note
        series.attrs['shape_detail'] = ('Chart shows realised history only; no forward '
                                        'prices were available.')
        print(f"    [FORWARD MISSING] {note}")
        return series

    def _flag_stale_forward(self, series, country_code, trading_day):
        """
        Note when a curve was priced on an older trading day than expected.

        EEX ingestion for one country can lag the others; the curve is still valid
        settlements, just not today's, so it is drawn with the date it came from.
        """
        expected = (pd.Timestamp.now().normalize() - pd.tseries.offsets.BDay(1)).normalize()
        td = pd.Timestamp(trading_day).normalize()
        if td >= expected:
            return
        note = (f"{country_code}: forward priced on {td:%Y-%m-%d}, "
                f"not the latest trading day")
        series.attrs['trading_day'] = td
        series.attrs['stale_warning'] = note
        print(f"    [STALE FORWARD] {note}")

    def _get_uk_hourly_forward(self):
        """Build UK forward curve from MACQ (daily granularity, no hourly shaping)."""
        try:
            df_contracts = self._fetch_macq_uk_power()
            if df_contracts.empty:
                return self._flag_missing_forward('UK', 'MACQ returned no contracts')

            builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
            builder.add_contracts(df_contracts)
            curve = builder.build_curves(freq='D', commodity='Power')
            if curve.empty:
                return self._flag_missing_forward('UK', 'MACQ bootstrap produced no rows')
            if isinstance(curve.index, pd.PeriodIndex):
                curve.index = curve.index.to_timestamp()

            daily = curve['price']
            hourly_idx = pd.date_range(daily.index.min(), daily.index.max() + pd.Timedelta(hours=23), freq='h')
            hourly = daily.reindex(hourly_idx.normalize()).values
            result = pd.Series(hourly, index=hourly_idx, name='Power')
            self._flag_unshaped_forward(
                result, 'UK', 'MACQ curve is daily Baseload only',
                shape_source='Base only (flat within day)'
            )
            return result
        except Exception as e:
            return self._flag_missing_forward(
                'UK', f'build failed: {str(e).splitlines()[0]}'
            )


def calculate_srmc(hist_data):
    if hist_data.empty:
        return hist_data

    # Calculate SRMCs
    # Efficiencies for ranges
    gas_eff_min, gas_eff_max = 0.48, 0.58
    coal_eff_min, coal_eff_max = 0.35, 0.45
    lig_eff_min, lig_eff_max = 0.34, 0.40

    # Constants
    GAS_EMISSIONS = 0.185
    COAL_EMISSIONS = 0.34
    LIG_EMISSIONS = 0.40
    LIG_FUEL_COST = 3
    API2_TO_MWH = 6.97

            # Calculations
            # Gas SRMC (TTF is EUR/MWh)
    if 'Gas' in hist_data.columns and 'Carbon' in hist_data.columns:
        hist_data['Gas_SRMC_Min'] = (hist_data['Gas'] / gas_eff_max) + (GAS_EMISSIONS / gas_eff_max) * hist_data['Carbon']
        hist_data['Gas_SRMC_Max'] = (hist_data['Gas'] / gas_eff_min) + (GAS_EMISSIONS / gas_eff_min) * hist_data['Carbon']

            # Coal SRMC (API2 is USD/t)
    if 'Coal' in hist_data.columns and 'USD_TO_EUR' in hist_data.columns and 'Carbon' in hist_data.columns:
        coal_eur_mwh = hist_data['Coal'] * hist_data['USD_TO_EUR'] / API2_TO_MWH
        hist_data['Coal_SRMC_Min'] = (coal_eur_mwh / coal_eff_max) + (COAL_EMISSIONS / coal_eff_max) * hist_data['Carbon']
        hist_data['Coal_SRMC_Max'] = (coal_eur_mwh / coal_eff_min) + (COAL_EMISSIONS / coal_eff_min) * hist_data['Carbon']

            # Lignite SRMC
    if 'Carbon' in hist_data.columns:
        hist_data['Lig_SRMC_Min'] = (LIG_FUEL_COST / lig_eff_max) + (LIG_EMISSIONS / lig_eff_max) * hist_data['Carbon']
        hist_data['Lig_SRMC_Max'] = (LIG_FUEL_COST / lig_eff_min) + (LIG_EMISSIONS / lig_eff_min) * hist_data['Carbon']

    return hist_data


class Report:
    """
    Generate PDF reports with calendar heatmaps for power market metrics.
    """
    
    def __init__(self, loader=None):
        """
        Initialize Report generator.
        
        Args:
            loader: DataLoader instance (creates new one if None)
        """
        self.loader = loader if loader is not None else DataLoader()
        
    def _create_calendar_heatmap(self, data_series, ax, title, cmap='RdYlGn_r', vmin=None, vmax=None, value_format='decimal', decimals=1):
        """
        Create a calendar heatmap for the given time series using july library.
        
        Args:
            data_series: pandas Series with DatetimeIndex
            ax: matplotlib axis to plot on
            title: Title for the heatmap
            cmap: colormap to use
            vmin, vmax: color scale limits (mapped to cmin/cmax for july)
            value_format: 'int' or 'decimal' for value labels
            decimals: number of decimal places (only used if value_format='decimal')
        """
    

        if data_series.empty or data_series.isna().all():
            ax.text(0.5, 0.5, 'No Data', ha='center', va='center', transform=ax.transAxes)
            ax.set_title(title, fontsize=9, pad=2)
            return
        
        # Prepare data for july
        # july expects dates and values as separate arrays
        dates = data_series.index.tolist()
        values = data_series.values
        
        # Round values based on decimals parameter
        if value_format == 'int':
            values = np.round(values, 0)
        else:
            values = np.round(values, decimals)
        
        # Set cmin/cmax for color scale (july uses cmin/cmax not vmin/vmax)
        if vmin is None:
            cmin = float(np.nanpercentile(values, 5))
        else:
            cmin = float(vmin)
            
        if vmax is None:
            cmax = float(np.nanpercentile(values, 95))
        else:
            cmax = float(vmax)
        
        # Create heatmap using july with week and month averages
        july.heatmap(
            dates=dates,
            data=values,
            cmap=cmap,
            month_grid=True,
            horizontal=True,
            value_label=True,
            date_label=False,
            weekday_label=True,
            month_label=True,
            year_label=True,
            colorbar=True,
            value_format=value_format,
            title=title,
            cmin=cmin,
            cmax=cmax,
            week_avg=True,
            month_avg=True,
            ax=ax,
            fontfamily="monospace",
            fontsize=7,
            titlesize=10
        )
        
        # Make value labels bold by modifying the axes text objects after creation
        for text in ax.texts:
            # Only make the cell value labels bold, not the averages
                text.set_weight('bold')

    def _create_evolution_chart(self, ax, history_dict, commodity, title, ylabel, cmap_name='viridis', max_date=None, resample_freq='MS'):
        """
        Plot evolution of forward curves.
        history_dict: {trading_date: {commodity: Series}}
        """
        import matplotlib.cm as cm
        import matplotlib.colors as mcolors
        
        # Extract curves for this commodity
        curves = []
        for trade_date, data in history_dict.items():
            if commodity in data:
                series = data[commodity]
                
                # Resample if requested
                if resample_freq:
                    series = series.resample(resample_freq).mean()
                    
                # Filter Date
                if max_date:
                    series = series[series.index <= max_date]
                    
                if not series.empty:
                    curves.append((trade_date, series))
        
        if not curves:
            ax.text(0.5, 0.5, 'No Data', ha='center', va='center', transform=ax.transAxes)
            ax.set_title(title)
            return

        # Sort by trade date
        curves.sort(key=lambda x: x[0])
        
        # Setup colormap (fading from light to dark/intense)
        # We want the LATEST date to be the most prominent
        # For Viridis: 0=Purple (Old), 1=Yellow (New). 
        # Yellow is bright. Purple is dark.
        
        try:
            cmap = mpl.colormaps[cmap_name]
        except (AttributeError, KeyError):
            # Fallback for older matplotlib or invalid name
            cmap = plt.get_cmap(cmap_name)
        
        # Normalize
        n_curves = len(curves)
        
        for i, (trade_date, series) in enumerate(curves):
            # Calculate color intensity (0.0 to 1.0)
            intensity = i / (n_curves - 1) if n_curves > 1 else 1.0
            color = cmap(intensity)
            
            # Line width: latest is thick, others thin
            # Make latest VERY distinct
            lz = 2.5 if i == n_curves - 1 else 1.2
            
            # Opacity: Make older ones slightly transparent to reduce clutter? 
            # Viridis handles distinction well, but Alpha helps layering.
            alpha = 1.0 if i == n_curves - 1 else 0.7
            
            # Plot
            label = trade_date.strftime('%Y-%m-%d')
            
            # Plot with step-'mid' or 'post' for monthly data looks better? 
            # Standard plot is fine for "Curve" interpolation, but 'steps-post' emphasizes monthly granularity.
            # User just said "Monthly granularity". Standard line plot of monthly points is mostly standard.
            ax.plot(series.index, series.values, color=color, linewidth=lz, alpha=alpha, label=label)
            
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.set_ylabel(ylabel, fontsize=12, fontweight='bold')
        ax.grid(True, linestyle=':', alpha=0.6)
        
        # Format x-axis
        import matplotlib.dates as mdates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
        
        # Make ticks bigger and bolder
        ax.tick_params(axis='both', which='major', labelsize=12)
        for label in ax.get_xticklabels() + ax.get_yticklabels():
            label.set_fontweight('bold')
        
        # Legend (show all)
        ax.legend(loc='upper right', fontsize=10, frameon=True, facecolor='white', framealpha=0.9, ncol=2)


    def _calculate_metrics(self, power, gas, carbon, coal, country_code='DE'):
        """
        Calculate all required metrics for a country.
        For UK: prices in GBP, NBP gas converted EUR->GBP, UKA + 18 GBP/t carbon tax.
        UK CSS = Power - (NBP_GBP / 0.4913) - (0.1821 / 0.4913) * (UKA + 18)
        UK CDS = Power - (Coal_GBP / 0.40)  - (0.34 / 0.40) * (UKA + 18)
        Returns a DataFrame with columns for each metric.
        """
        is_uk = (country_code == 'UK')
        GAS_EFF = 0.4913 if is_uk else 0.5
        COAL_EFF = 0.4
        GAS_EMISSIONS = 0.1821
        COAL_EMISSIONS = 0.34
        API2_TO_MWH = 6.97

        if is_uk:
            gas_price = gas['NBP'] if 'NBP' in gas.columns else gas.iloc[:, 0]
            carbon_price = carbon['UKA'] if 'UKA' in carbon.columns else carbon.iloc[:, 0]
        else:
            gas_price = gas['TTF'] if 'TTF' in gas.columns else gas.iloc[:, 0]
            carbon_price = carbon['EUA'] if 'EUA' in carbon.columns else carbon.iloc[:, 0]

        if country_code in power.columns:
            power_price = power[country_code]
        else:
            print(f"Warning: {country_code} not found in power data")
            power_price = pd.Series(index=power.index, dtype=float)

        gas_price.index = pd.to_datetime(gas_price.index)
        carbon_price.index = pd.to_datetime(carbon_price.index)
        power_price.index = pd.to_datetime(power_price.index)

        coal_price = coal['Coal'] if 'Coal' in coal.columns else coal.iloc[:, 0]
        usd_to_eur = coal['USD_TO_EUR'] if 'USD_TO_EUR' in coal.columns else pd.Series(0.85, index=coal.index)
        coal_price.index = pd.to_datetime(coal_price.index)
        usd_to_eur.index = pd.to_datetime(usd_to_eur.index)

        df = pd.DataFrame({
            'Power': power_price,
            'Gas': gas_price,
            'Carbon': carbon_price,
            'Coal': coal_price,
            'USD_TO_EUR': usd_to_eur
        })

        if is_uk:
            fx_series = self.loader._get_fx_series('EUR_GBP') if hasattr(self, 'loader') else self._get_fx_series('EUR_GBP')
            if not fx_series.empty:
                df['EUR_GBP'] = fx_series
                df['EUR_GBP'] = df['EUR_GBP'].ffill(limit=5)
            else:
                df['EUR_GBP'] = 0.85
            # NBP from cache is EUR/MWh -> convert to GBP/MWh
            df['Gas'] = df['Gas'] * df['EUR_GBP']
            # Add UK carbon tax (18 GBP/t) to carbon price for cost calculations
            carbon_tax = self.loader.UK_CARBON_TAX if hasattr(self, 'loader') else DataLoader.UK_CARBON_TAX
            df['Carbon_Total'] = df['Carbon'] + carbon_tax
            # Coal: USD -> GBP (USD_TO_EUR * EUR_GBP = USD_TO_GBP)
            df['USD_TO_LOCAL'] = df['USD_TO_EUR'] * df['EUR_GBP']
        else:
            df['Carbon_Total'] = df['Carbon']
            df['USD_TO_LOCAL'] = df['USD_TO_EUR']

        df[['Gas', 'Carbon', 'Coal', 'USD_TO_EUR']] = df[['Gas', 'Carbon', 'Coal', 'USD_TO_EUR']].ffill(limit=5)
        if 'Carbon_Total' in df.columns:
            df['Carbon_Total'] = df['Carbon_Total'].ffill(limit=5)
        if 'USD_TO_LOCAL' in df.columns:
            df['USD_TO_LOCAL'] = df['USD_TO_LOCAL'].ffill(limit=5)

        if df.empty:
            return df

        # CSS: gas cost includes carbon tax for UK
        gas_cost = (df['Gas'] / GAS_EFF) + (GAS_EMISSIONS / GAS_EFF) * df['Carbon_Total']
        df['CSS'] = df['Power'] - gas_cost

        # CDS
        coal_local_mwh = df['Coal'] * df['USD_TO_LOCAL'] / API2_TO_MWH
        coal_cost = (coal_local_mwh / COAL_EFF) + (COAL_EMISSIONS / COAL_EFF) * df['Carbon_Total']
        df['CDS'] = df['Power'] - coal_cost

        df['HeatRate'] = df['Power'] / (df['Gas'] + GAS_EMISSIONS * df['Carbon_Total'])
        df['Implied_Eff'] = (df['Gas'] + GAS_EMISSIONS * df['Carbon_Total']) / df['Power']

        return df

    def _generate_country_data(self, country_code, start_date, end_date):
        """
        Generate report data for a single country.
        
        Returns DataFrame with all metrics.
        """
        print(f"\nProcessing {country_code}...")
        
        # Load all data
        # Load all data
        print("  Loading power data...")
        raw_power = self.loader.load_power([country_code], start_date, end_date)
        
        # Store native spot data for hourly plots
        self.power_spot = raw_power
        
        # Resample to Daily for metrics calculation
        if not raw_power.empty:
             power = raw_power.resample('D').mean()
        else:
             power = pd.DataFrame()
        
        print("  Loading gas data...")
        gas = self.loader.load_gas(start_date.strftime('%Y-%m-%d'))
        
        print("  Loading coal data...")
        coal = self.loader.load_coal(start_date, end_date)
        
        print("  Loading carbon data...")
        carbon = self.loader.load_carbon(start_date, end_date)
        
        # Calculate metrics
        print("  Calculating metrics...")
        df = self._calculate_metrics(power, gas, carbon, coal, country_code)
        
        return df

    def _get_forward_data(self, country):
        """
        Fetch forward curve data using 'curves' package (daily -> monthly).
        For UK: ICE NBP (p/th on ICE -> converted), ICE UKA + 18 GBP/t carbon tax.
        Includes current month.
        """
        is_uk = (country == 'UK')
        try:
            daily_curves = self.loader.build_forward_curves(country)

            if not daily_curves:
                return pd.DataFrame()

            monthly_data = {}
            for comm, series in daily_curves.items():
                if not series.empty:
                    monthly_data[comm] = series.resample('MS').mean()

            df = pd.DataFrame(monthly_data)
            if df.empty:
                return pd.DataFrame()

            if 'Carbon' in df.columns:
                df['Carbon'] = df['Carbon'].interpolate(method='linear', limit_direction='both')

            today = datetime.now()
            start_date = today.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            end_year = today.year + 1
            if today.month >= 11:
                end_year = today.year + 2
            end_date = datetime(end_year, 12, 31)

            df = df[(df.index >= start_date) & (df.index <= end_date)].copy()
            if df.empty:
                return pd.DataFrame()

            # For UK without Power forward, we can still compute Gas/Carbon metrics
            # but skip Power-dependent ones (CSS, CDS, HR)
            has_power = 'Power' in df.columns
            has_gas = 'Gas' in df.columns
            has_carbon = 'Carbon' in df.columns

            if not has_gas or not has_carbon:
                print(f"  Missing Gas or Carbon forward curve for {country}.")
                return pd.DataFrame()

            gas = df['Gas']
            carbon = df['Carbon']
            coal = df['Coal'] if 'Coal' in df.columns else pd.Series(np.nan, index=df.index)

            GAS_EMISSIONS = 0.1821
            COAL_EMISSIONS = 0.34
            GAS_EFF = 0.4913 if is_uk else 0.50
            COAL_EFF = 0.40
            API2_TO_MWH = 6.97

            if is_uk:
                # ICE NBP forward is in p/th -> convert to GBP/MWh
                # 1 therm = 0.029307222 MWh, so 1 MWh = 34.121 therms
                # p/th * 34.121 / 100 = GBP/MWh
                THERMS_PER_MWH = 34.121
                gas = gas * THERMS_PER_MWH / 100.0
                # Add UK carbon tax
                carbon_total = carbon + DataLoader.UK_CARBON_TAX
            else:
                carbon_total = carbon

            if has_power:
                power = df['Power']
                hr = power / (gas + GAS_EMISSIONS * carbon_total)
                gas_cost = (gas / GAS_EFF) + (GAS_EMISSIONS / GAS_EFF) * carbon_total
                css = power - gas_cost
            else:
                power = pd.Series(np.nan, index=df.index)
                hr = pd.Series(np.nan, index=df.index)
                css = pd.Series(np.nan, index=df.index)

            if is_uk:
                fx_eur_gbp = self.loader._get_fx_series('EUR_GBP')
                if not fx_eur_gbp.empty:
                    latest_fx_eur_gbp = fx_eur_gbp.iloc[-1]
                else:
                    latest_fx_eur_gbp = 0.85
                fx_eur_usd = self.loader.get_latest_fx_rate()
                fx_usd_gbp = (1.0 / fx_eur_usd) * latest_fx_eur_gbp
                coal_local_mwh = (coal * fx_usd_gbp) / API2_TO_MWH
            else:
                fx_eur_usd = self.loader.get_latest_fx_rate()
                coal_local_mwh = (coal / fx_eur_usd) / API2_TO_MWH

            coal_cost = (coal_local_mwh / COAL_EFF) + (COAL_EMISSIONS / COAL_EFF) * carbon_total
            cds = power - coal_cost if has_power else pd.Series(np.nan, index=df.index)

            LIG_EFF = 0.38
            LIG_EMISSIONS = 0.40
            LIG_FUEL_COST = 3.0
            lig_cost = (LIG_FUEL_COST / LIG_EFF) + (LIG_EMISSIONS / LIG_EFF) * carbon_total
            cls_spread = power - lig_cost if has_power else pd.Series(np.nan, index=df.index)

            df_out = pd.DataFrame({
                'HeatRate': hr,
                'CSS': css,
                'CDS': cds,
                'CLS': cls_spread,
                'Gas': gas,
                'Coal': coal,
                'Carbon': carbon,
                'Power': power
            })

            df_out['Month'] = df_out.index.month
            df_out['Year'] = df_out.index.year

            return df_out

        except Exception as e:
            print(f"  ERROR fetching forward data: {e}")
            import traceback
            traceback.print_exc()
            return pd.DataFrame()

    def _calculate_monthly_metrics(self, country_code, start_date, end_date):
        """
        Calculate monthly average Heat Rate, CSS, and CDS.
        For UK: converts NBP EUR->GBP, uses UKA + 18 GBP/t carbon tax, coal USD->GBP.
        Returns 8 DataFrames (pivoted Year x Month).
        """
        calc_start_date = '2019-01-01'
        calc_end_date = end_date.strftime('%Y-%m-%d') if isinstance(end_date, datetime) else end_date
        is_uk = (country_code == 'UK')

        print(f"  Calculating monthly metrics data from {calc_start_date}...")

        power = self.loader.load_power([country_code], calc_start_date, calc_end_date)
        gas = self.loader.load_gas(calc_start_date)
        carbon = self.loader.load_carbon(calc_start_date, calc_end_date)
        coal = self.loader.load_coal(calc_start_date, calc_end_date)

        _empty8 = tuple(pd.DataFrame() for _ in range(8))

        if power.empty or gas.empty or carbon.empty or coal.empty:
            return _empty8

        power_series = power[country_code] if country_code in power.columns else pd.Series()

        if is_uk:
            gas_series = gas['NBP'] if 'NBP' in gas.columns else gas.iloc[:, 0]
            carbon_series = carbon['UKA'] if 'UKA' in carbon.columns else carbon.iloc[:, 0]
        else:
            gas_series = gas['TTF'] if 'TTF' in gas.columns else gas.iloc[:, 0]
            carbon_series = carbon['EUA'] if 'EUA' in carbon.columns else carbon.iloc[:, 0]

        coal_series = coal['Coal'] if 'Coal' in coal.columns else coal.iloc[:, 0]
        usd_to_eur = coal['USD_TO_EUR'] if 'USD_TO_EUR' in coal.columns else pd.Series(0.85, index=coal.index)

        if power_series.empty:
            return _empty8

        for s in [power_series, gas_series, carbon_series, coal_series, usd_to_eur]:
            if not isinstance(s.index, pd.DatetimeIndex):
                s.index = pd.to_datetime(s.index)

        if is_uk:
            fx_series = self.loader._get_fx_series('EUR_GBP')
            if not fx_series.empty:
                if not isinstance(fx_series.index, pd.DatetimeIndex):
                    fx_series.index = pd.to_datetime(fx_series.index)
                # Convert NBP from EUR/MWh to GBP/MWh
                aligned = pd.DataFrame({'gas': gas_series, 'fx': fx_series}).ffill(limit=5)
                gas_series = aligned['gas'] * aligned['fx']
                gas_series = gas_series.dropna()
            else:
                gas_series = gas_series * 0.85
            # Add UK carbon tax
            carbon_total = carbon_series + DataLoader.UK_CARBON_TAX
        else:
            carbon_total = carbon_series

        monthly_power = power_series.resample('MS').mean()
        monthly_gas = gas_series.resample('MS').mean()
        monthly_carbon = carbon_series.resample('MS').mean()
        monthly_carbon_total = carbon_total.resample('MS').mean()
        monthly_coal = coal_series.resample('MS').mean()
        monthly_fx_usd_eur = usd_to_eur.resample('MS').mean()

        GAS_EMISSIONS = 0.1821
        COAL_EMISSIONS = 0.34
        GAS_EFF = 0.4913 if is_uk else 0.50
        COAL_EFF = 0.40
        API2_TO_MWH = 6.97

        monthly_heat_rate = monthly_power / (monthly_gas + GAS_EMISSIONS * monthly_carbon_total)

        gas_cost = (monthly_gas + GAS_EMISSIONS * monthly_carbon_total) / GAS_EFF
        monthly_css = monthly_power - gas_cost

        if is_uk:
            fx_eur_gbp = self.loader._get_fx_series('EUR_GBP')
            if not fx_eur_gbp.empty:
                if not isinstance(fx_eur_gbp.index, pd.DatetimeIndex):
                    fx_eur_gbp.index = pd.to_datetime(fx_eur_gbp.index)
                monthly_fx_eur_gbp = fx_eur_gbp.resample('MS').mean()
            else:
                monthly_fx_eur_gbp = pd.Series(0.85, index=monthly_coal.index)
            monthly_fx_local = monthly_fx_usd_eur * monthly_fx_eur_gbp
        else:
            monthly_fx_local = monthly_fx_usd_eur

        coal_local_mwh = monthly_coal * monthly_fx_local / API2_TO_MWH
        coal_cost = (coal_local_mwh + COAL_EMISSIONS * monthly_carbon_total) / COAL_EFF
        monthly_cds = monthly_power - coal_cost

        LIG_EFF = 0.38
        LIG_EMISSIONS = 0.40
        LIG_FUEL_COST = 3.0
        lig_cost = (LIG_FUEL_COST + LIG_EMISSIONS * monthly_carbon_total) / LIG_EFF
        monthly_cls = monthly_power - lig_cost

        now = datetime.now()
        current_month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        def filter_before_current(df_in):
            if not df_in.empty:
                return df_in[df_in.index < current_month_start]
            return df_in

        monthly_heat_rate = filter_before_current(monthly_heat_rate)
        monthly_css = filter_before_current(monthly_css)
        monthly_cds = filter_before_current(monthly_cds)
        monthly_cls = filter_before_current(monthly_cls)
        monthly_gas = filter_before_current(monthly_gas)
        monthly_coal = filter_before_current(monthly_coal) if isinstance(monthly_coal, pd.Series) else monthly_coal
        monthly_carbon = filter_before_current(monthly_carbon)

        hist_df = pd.DataFrame({
            'HeatRate': monthly_heat_rate,
            'CSS': monthly_css,
            'CDS': monthly_cds,
            'CLS': monthly_cls,
            'Gas': monthly_gas,
            'Coal': monthly_coal,
            'Carbon': monthly_carbon,
            'Power': monthly_power
        })
        hist_df['Year'] = hist_df.index.year
        hist_df['Month'] = hist_df.index.month

        fwd_df = self._get_forward_data(country_code)
        
        combined_df = hist_df
        if not fwd_df.empty:
            print(f"  Merging {len(fwd_df)} forward rows for {country_code}...")
            # Concatenate
            combined_df = pd.concat([hist_df, fwd_df], ignore_index=True)
            
            # Deduplicate by Month/Year just in case overlap remains
            # (Keep last = keep forward if overlap)
            combined_df.drop_duplicates(subset=['Year', 'Month'], keep='last', inplace=True)
        
        # Format Pivots
        pivot_hr = combined_df.pivot(index='Month', columns='Year', values='HeatRate')
        pivot_css = combined_df.pivot(index='Month', columns='Year', values='CSS')
        pivot_cds = combined_df.pivot(index='Month', columns='Year', values='CDS')
        pivot_cls = combined_df.pivot(index='Month', columns='Year', values='CLS')
        
        pivot_power = combined_df.pivot(index='Month', columns='Year', values='Power')
        pivot_gas = combined_df.pivot(index='Month', columns='Year', values='Gas')
        pivot_coal = combined_df.pivot(index='Month', columns='Year', values='Coal')
        pivot_carbon = combined_df.pivot(index='Month', columns='Year', values='Carbon')

        # Sort
        for p in [pivot_hr, pivot_css, pivot_cds, pivot_cls, pivot_power, pivot_gas, pivot_coal, pivot_carbon]:
            p.sort_index(axis=0, inplace=True)
            p.sort_index(axis=1, inplace=True)
        
        return pivot_hr, pivot_css, pivot_cds, pivot_cls, pivot_gas, pivot_coal, pivot_carbon, pivot_power

    def _create_monthly_table_heatmap(self, df, ax, title, cmap='RdYlGn_r'):
        """
        Create a heatmap table for monthly data.
        """
        import calendar
        from matplotlib.patches import Rectangle
        
        if df.empty:
            ax.text(0.5, 0.5, 'No Data', ha='center', va='center', transform=ax.transAxes)
            ax.set_title(title)
            return

        # Prepare data
        for m in range(1, 13):
            if m not in df.index:
                df.loc[m] = np.nan
        df.sort_index(inplace=True)
        
        # Compute yearly average row (mean over months for each year column)
        yearly_avg = df.mean(axis=0, skipna=True)
        
        monthly_data = df.values
        avg_row = yearly_avg.values.reshape(1, -1)
        data = np.vstack([monthly_data, avg_row])
        
        # Calculate percentiles for robust color scaling (ignore outliers)
        # Use only the monthly data so the avg row doesn't compress contrast
        valid_data = monthly_data[~np.isnan(monthly_data)]
        if len(valid_data) > 0:
            vmin, vmax = np.percentile(valid_data, [10, 90])
        else:
            vmin, vmax = None, None
        
        # Mask the avg row so it renders as neutral (no color fill)
        display_data = np.ma.array(data, mask=False)
        display_data.mask = np.zeros_like(data, dtype=bool)
        display_data.mask[-1, :] = True
        
        cmap_obj = plt.get_cmap(cmap).copy() if hasattr(plt.get_cmap(cmap), 'copy') else plt.get_cmap(cmap)
        try:
            cmap_obj.set_bad(color='#f0f0f0')
        except Exception:
            pass
        
        im = ax.imshow(display_data, cmap=cmap_obj, aspect='auto', vmin=vmin, vmax=vmax)
        
        n_rows = data.shape[0]
        ax.set_xticks(np.arange(len(df.columns)))
        ax.set_yticks(np.arange(n_rows))
        
        ax.set_xticklabels(df.columns, fontsize=9)
        ax.set_yticklabels(
            [calendar.month_abbr[i] for i in df.index] + ['Avg'],
            fontsize=9,
        )
        
        # Separator line above the Avg row
        ax.plot([-0.5, len(df.columns) - 0.5], [n_rows - 1.5, n_rows - 1.5],
                color='black', linewidth=1.2)
        
        # Move x-axis to top
        ax.xaxis.tick_top()
        ax.xaxis.set_label_position('top') 
        
        # Rotate x labels if many years
        plt.setp(ax.get_xticklabels(), rotation=45, ha="left", rotation_mode="anchor")
        
        # Annotations and Future Outline
        now = datetime.now()
        
        for i in range(len(df.index)): # i = month index (0=Jan, 11=Dec)
            month_num = df.index[i]
            for j in range(len(df.columns)): # j = year index
                year_num = df.columns[j]
                
                val = monthly_data[i, j]
                if not np.isnan(val):
                    ax.text(j, i, f"{val:.0f}" if abs(val) > 10 else f"{val:.2f}",
                           ha="center", va="center", color="black", fontsize=11, fontweight='bold')
                
                # Define Future Condition
                # Future if year > now.year OR (year == now.year and month >= now.month)
                # Note: We treat current month as Future/Forward based on data split
                def is_future_cell(r_idx, c_idx):
                    # Handle out of bounds
                    if r_idx < 0 or r_idx >= len(df.index): return False # boundary
                    if c_idx < 0 or c_idx >= len(df.columns): return False # boundary
                    
                    _mon = df.index[r_idx]
                    _yr = df.columns[c_idx]
                    
                    if _yr > now.year: return True
                    if _yr == now.year and _mon >= now.month: return True
                    return False
                
                # Current cell status
                cell_is_future = is_future_cell(i, j)
                
                if cell_is_future:
                    # Check Top Neighbor (i-1, j)
                    # If Top is NOT future (i.e. History or Edge), draw Top Border
                    # Actually if i=0 (Jan), Top is edge. 
                    # User said "touching cells from history".
                    # Edge of grid is not history cell?
                    # But usually we outline the block. 
                    # If Jan is Future, and neighboring Year (Left) is History, we draw Left.
                    # Top of Jan is grid boundary. Let's draw it if it looks better?
                    # The prompt says "touching cells from history".
                    # Strictly speaking, 'out of bounds' is not 'history'.
                    # However, to form a nice boundary line, we usually want to close it?
                    # Let's stick to strict "touching history".
                    
                    # Top Neighbor
                    if i > 0:
                        if not is_future_cell(i-1, j):
                            # Draw Top Border
                            ax.plot([j-0.5, j+0.5], [i-0.5, i-0.5], color='black', linewidth=2)
                    
                    # Left Neighbor
                    if j > 0:
                        if not is_future_cell(i, j-1):
                            # Draw Left Border
                            ax.plot([j-0.5, j-0.5], [i-0.5, i+0.5], color='black', linewidth=2)
                    else:
                        # If j=0 (First Column), and it is Future (e.g. next year report?), Left is Grid Edge.
                        # Can treat as history boundary if we assume previous years exist but are hidden?
                        pass
                           
        # Annotate the Avg row
        avg_row_idx = n_rows - 1
        for j in range(len(df.columns)):
            val = yearly_avg.iloc[j]
            if not np.isnan(val):
                ax.text(j, avg_row_idx, f"{val:.0f}" if abs(val) > 10 else f"{val:.2f}",
                       ha="center", va="center", color="black", fontsize=11, fontweight='bold')
        
        ax.set_title(title, fontsize=12, pad=15) # Increased pad for top axis
        # plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04) # Shared colorbar or individual? Let's hide individual for space or keep small

    def _create_stack_fan_page(self, pdf, country, pivot_power, pivot_gas, pivot_coal, pivot_carbon, hourly_power,
                               fan_start_year=2023):
        """
        Create a 4x3 page of 'Stack Fan' plots (one per month).
        Shows evolution of Power vs SRMC Bands (Lignite, Coal, Gas) across years.
        Only shows years >= fan_start_year.
        Includes Hourly Price Violins split by Weekday/Weekend.
        """
        print(f"  Creating Stack Fan page for {country} (Bands + Violins, {fan_start_year}+)...")
        
        fig = plt.figure(figsize=(24, 18))
        fig.patch.set_facecolor('white')
        
        # Header
        header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(header_rect)
        fig.text(0.5, 0.98, f'Monthly Stack Fan Plot: {country}', fontsize=20, fontweight='bold', va='center', ha='center', color='white', zorder=1002)
        
        # Footer
        footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(footer_rect)
        fig.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', fontsize=9, va='center', ha='right', color='white', zorder=1002)
        
        # Grid 4x3
        gs = gridspec.GridSpec(4, 3, wspace=0.2, hspace=0.3, top=0.92, bottom=0.08, left=0.05, right=0.95)
        
        months = [
            (1, 'January'), (2, 'February'), (3, 'March'),
            (4, 'April'), (5, 'May'), (6, 'June'),
            (7, 'July'), (8, 'August'), (9, 'September'),
            (10, 'October'), (11, 'November'), (12, 'December')
        ]
        
        # Parameters for Bands
        GAS_EFF_MIN, GAS_EFF_MAX = 0.48, 0.58
        COAL_EFF_MIN, COAL_EFF_MAX = 0.35, 0.45
        LIG_EFF_MIN, LIG_EFF_MAX = 0.34, 0.40
        
        GAS_EM = 0.185
        COAL_EM = 0.34
        LIG_EM = 0.40
        LIG_COST = 3.0
        API2_TO_MWH = 6.97
        FX = 1.08

        # Prepare Hourly Data
        if not hourly_power.empty:
            hourly_power = hourly_power.copy()
            hourly_power.columns = ['Price']
            hourly_power['Year'] = hourly_power.index.year
            hourly_power['Month'] = hourly_power.index.month
            hourly_power['IsWeekend'] = hourly_power.index.weekday >= 5

        for i, (m_num, m_name) in enumerate(months):
            ax = plt.subplot(gs[i // 3, i % 3])
            
            try:
                # Extract pivoted annual means
                p_power = pivot_power.loc[m_num] if m_num in pivot_power.index else pd.Series()
                p_gas = pivot_gas.loc[m_num] if m_num in pivot_gas.index else pd.Series()
                p_coal = pivot_coal.loc[m_num] if m_num in pivot_coal.index else pd.Series()
                p_carbon = pivot_carbon.loc[m_num] if m_num in pivot_carbon.index else pd.Series()
                
                # Align Years
                years = sorted(list(set(p_power.index) | set(p_gas.index)))
                years = [y for y in years if isinstance(y, (int, float))]
                
                # Filter to the requested start year onwards
                years = [y for y in years if y >= fan_start_year]

                if not years:
                    ax.text(0.5, 0.5, f'No Data (>={fan_start_year})', ha='center', va='center')
                    ax.set_title(m_name, fontweight='bold')
                    continue
                
                # Reindex
                p_power = p_power.reindex(years)
                p_gas = p_gas.reindex(years)
                p_coal = p_coal.reindex(years)
                p_carbon = p_carbon.reindex(years)
                
                # Calculate Band SRMCs
                gas_srmc_min = (p_gas + GAS_EM * p_carbon) / GAS_EFF_MAX
                gas_srmc_max = (p_gas + GAS_EM * p_carbon) / GAS_EFF_MIN
                
                coal_eur = (p_coal / FX) / API2_TO_MWH
                coal_srmc_min = (coal_eur + COAL_EM * p_carbon) / COAL_EFF_MAX
                coal_srmc_max = (coal_eur + COAL_EM * p_carbon) / COAL_EFF_MIN
                
                lig_srmc_min = (LIG_COST + LIG_EM * p_carbon) / LIG_EFF_MAX
                lig_srmc_max = (LIG_COST + LIG_EM * p_carbon) / LIG_EFF_MIN
                
                # Plot Bands (Background)
                ax.fill_between(years, lig_srmc_min, lig_srmc_max, color='#8B4513', alpha=0.3, label='Lignite')
                ax.fill_between(years, coal_srmc_min, coal_srmc_max, color='black', alpha=0.15, label='Coal') 
                ax.fill_between(years, gas_srmc_min, gas_srmc_max, color='blue', alpha=0.15, label='Gas')
                
                # Plot Violins (Foreground)
                if not hourly_power.empty:
                    # Filter for this Month
                    m_hourly = hourly_power[hourly_power['Month'] == m_num]
                    
                    for y in years:
                        # Get data for Year Y
                        data_y = m_hourly[m_hourly['Year'] == y]
                        if data_y.empty: continue
                        
                        # Split (Unclipped Data for Stats)
                        wd_series = data_y[~data_y['IsWeekend']]['Price'].dropna()
                        we_series = data_y[data_y['IsWeekend']]['Price'].dropna()
                        
                        # Calculate Means (Unclipped)
                        wd_mean = wd_series.mean() if not wd_series.empty else None
                        we_mean = we_series.mean() if not we_series.empty else None
                        
                        # Clip Data [-30, 250] for Histogram
                        wd_data = wd_series.clip(lower=-30, upper=250)
                        we_data = we_series.clip(lower=-30, upper=250)
                        
                        # Histogram Configuration
                        bins = np.arange(-30, 261, 10) # 10 EUR bins
                        scale = 1.0 # 100% prob = 1.0 width (fills gap mostly). 
                                   # Gap is 1 year. We split left/right. 
                                   # 0.4 max width per side is safe. 
                                   # If prob is > 40% in one bin, it might overlap. 
                                   # Let's cap width or use smaller scale? 
                                   # Distribution usually spread out. 40% in one 10eur bin is rare (unless flat price).
                                   # Let's keep scale 1.0 but maybe clip bar length visual if needed? No, let's try 1.0 first.
                        
                        # Plot Weekday (Left Histogram)
                        if not wd_data.empty:
                            counts, edges = np.histogram(wd_data, bins=bins)
                            probs = counts / len(wd_data)
                            width = probs * scale
                            # bars extend left from y:  left = y - width
                            ax.barh(y=edges[:-1], width=width, height=10, left=y - width, align='edge', color='red', alpha=0.6, edgecolor='none')
                            
                            # Add Mean dot (Unclipped)
                            if wd_mean is not None:
                                ax.scatter(y - 0.15, wd_mean, color='#8B0000', s=15, zorder=5, label='_nolegend_')

                        # Plot Weekend (Right Histogram)
                        if not we_data.empty:
                            counts, edges = np.histogram(we_data, bins=bins)
                            probs = counts / len(we_data)
                            width = probs * scale
                            # bars extend right from y: left = y
                            ax.barh(y=edges[:-1], width=width, height=10, left=y, align='edge', color='orange', alpha=0.6, edgecolor='none')
                            
                            # Add Mean dot (Unclipped)
                            if we_mean is not None:
                                ax.scatter(y + 0.15, we_mean, color='#8B4500', s=15, zorder=5, label='_nolegend_')

                # Plot Power Mean Line (Connecting years)
                # Red, Solid, Thicker as requested (calculated from unclipped pivot_power)
                ax.plot(years, p_power, color='red', linewidth=2.5, linestyle='-', marker='o', markersize=4, alpha=0.8, label='Monthly Mean')
                
                ax.set_title(m_name, fontweight='bold')
                ax.grid(True, linestyle=':', alpha=0.5)
                ax.xaxis.set_major_locator(plt.MaxNLocator(integer=True))
                
                # Legend only on first plot
                if i == 0:
                    # Create custom legend handles for violins
                    from matplotlib.patches import Patch
                    from matplotlib.lines import Line2D
                    
                    legend_elements = [
                        Patch(facecolor='#8B4513', alpha=0.3, label='Lignite Band'),
                        Patch(facecolor='black', alpha=0.15, label='Coal Band'),
                        Patch(facecolor='blue', alpha=0.15, label='Gas Band'),
                        Patch(facecolor='red', alpha=0.6, label='WkDay Dist'),
                        Patch(facecolor='orange', alpha=0.6, label='WkEnd Dist'),
                        Line2D([0], [0], color='red', linestyle='-', linewidth=2.5, label='Monthly Mean')
                    ]
                    ax.legend(handles=legend_elements, loc='upper left', fontsize=8, framealpha=0.9, ncol=2)
                    
            except Exception as e:
                print(f"Error fan plot {m_name}: {e}")
                
        pdf.savefig(fig, dpi=150)
        plt.close(fig)
        print(f"  [OK] {country} stack fan page added")

    def _calculate_srmc_bands(self, gas, coal, carbon, country_code='DE'):
        """
        Calculate SRMC bands for Gas, Coal, Lignite.
        For UK: gas is already GBP/MWh, carbon includes UK carbon tax,
        coal USD->GBP conversion.
        Returns DataFrame with band columns + Daily fuels.
        """
        is_uk = (country_code == 'UK')

        gas_eff_min, gas_eff_max = 0.48, 0.58
        ocgt_eff_min, ocgt_eff_max = 0.30, 0.38
        coal_eff_min, coal_eff_max = 0.35, 0.45
        lig_eff_min, lig_eff_max = 0.34, 0.40

        GAS_EMISSIONS = 0.185
        COAL_EMISSIONS = 0.34
        LIG_EMISSIONS = 0.40
        LIG_FUEL_COST = 1.5

        df = pd.DataFrame({'Gas': gas, 'Coal': coal, 'Carbon': carbon})

        if is_uk:
            # Add UK carbon tax for cost calculations
            df['Carbon_Total'] = df['Carbon'] + DataLoader.UK_CARBON_TAX
            fx_eur_gbp = self.loader._get_fx_series('EUR_GBP') if hasattr(self, 'loader') else pd.Series(dtype=float)
            if not fx_eur_gbp.empty:
                latest_eur_gbp = fx_eur_gbp.iloc[-1]
            else:
                latest_eur_gbp = 0.85
            df['USD_TO_LOCAL'] = 0.85 * latest_eur_gbp
        else:
            df['Carbon_Total'] = df['Carbon']
            df['USD_TO_LOCAL'] = 0.85

        df['Gas_SRMC_Min'] = (df['Gas'] / gas_eff_max) + (GAS_EMISSIONS / gas_eff_max) * df['Carbon_Total']
        df['Gas_SRMC_Max'] = (df['Gas'] / gas_eff_min) + (GAS_EMISSIONS / gas_eff_min) * df['Carbon_Total']

        df['Gas_OCGT_Min'] = (df['Gas'] / ocgt_eff_max) + (GAS_EMISSIONS / ocgt_eff_max) * df['Carbon_Total']
        df['Gas_OCGT_Max'] = (df['Gas'] / ocgt_eff_min) + (GAS_EMISSIONS / ocgt_eff_min) * df['Carbon_Total']

        API2_TO_MWH = 6.97
        coal_local_mwh = df['Coal'] * df['USD_TO_LOCAL'] / API2_TO_MWH
        df['Coal_SRMC_Min'] = (coal_local_mwh / coal_eff_max) + (COAL_EMISSIONS / coal_eff_max) * df['Carbon_Total']
        df['Coal_SRMC_Max'] = (coal_local_mwh / coal_eff_min) + (COAL_EMISSIONS / coal_eff_min) * df['Carbon_Total']

        df['Lig_SRMC_Min'] = (LIG_FUEL_COST / lig_eff_max) + (LIG_EMISSIONS / lig_eff_max) * df['Carbon_Total']
        df['Lig_SRMC_Max'] = (LIG_FUEL_COST / lig_eff_min) + (LIG_EMISSIONS / lig_eff_min) * df['Carbon_Total']

        if df.index.has_duplicates:
            df = df.groupby(df.index).mean()

        return df

    def _create_hourly_srmc_chart(self, ax, power_hourly, srmc_df, title, today_date=None,
                                  shape_warning=None, shape_detail=None):
        """
        Plot hourly power vs daily SRMC bands.
        power_hourly: Hourly/Native Series
        srmc_df: Daily DataFrame with SRMC bands
        today_date: Optional datetime to mark "Today" / separation between Spot and Forward
        shape_warning: Optional caveat about the forward curve, drawn on the axes
        shape_detail: Second caveat line explaining the consequence of shape_warning
        """
        if power_hourly.empty or srmc_df.empty:
            msg = 'No Data' if not shape_warning else f'No Data\n{shape_warning}'
            ax.text(0.5, 0.5, msg, ha='center', va='center', transform=ax.transAxes)
            ax.set_title(title)
            return

        # Ensure indices are datetimes
        srmc_df.index = pd.to_datetime(srmc_df.index) 
        power_hourly.index = pd.to_datetime(power_hourly.index)
        
        # Deduplicate SRMC index
        if srmc_df.index.has_duplicates:
             srmc_df = srmc_df.groupby(srmc_df.index).mean()
        
        # Add Weekend Shading
        current_date = power_hourly.index.min().normalize()
        end_date = power_hourly.index.max().normalize() + timedelta(days=1)
        
        while current_date < end_date:
            if current_date.weekday() >= 5: # Saturday (5) or Sunday (6)
                ax.axvspan(current_date, current_date + timedelta(days=1), 
                          facecolor='grey', alpha=0.15, zorder=0)
            current_date += timedelta(days=1)
        
        # Plot Bands using step='post'
        # Lignite (Brown)
        ax.fill_between(srmc_df.index, srmc_df['Lig_SRMC_Min'], srmc_df['Lig_SRMC_Max'], 
                       color='saddlebrown', alpha=0.3, step='post', label='Lignite SRMC')
        # Coal (Grey)
        ax.fill_between(srmc_df.index, srmc_df['Coal_SRMC_Min'], srmc_df['Coal_SRMC_Max'], 
                       color='grey', alpha=0.3, step='post', label='Coal SRMC')
        # Gas CCGT (Blue)
        ax.fill_between(srmc_df.index, srmc_df['Gas_SRMC_Min'], srmc_df['Gas_SRMC_Max'], 
                       color='blue', alpha=0.1, step='post', label='Gas CCGT SRMC')
        # Gas OCGT (Light Blue / SkyBlue)
        ax.fill_between(srmc_df.index, srmc_df['Gas_OCGT_Min'], srmc_df['Gas_OCGT_Max'], 
                       color='dodgerblue', alpha=0.15, step='post', label='Gas OCGT SRMC')
                       
        # Plot Power
        ax.plot(power_hourly.index, power_hourly.values, color='darkred', linewidth=1.5, label='Hourly Price')
        
        # Plot Daily Mean (Black line with dots at 12:00)
        power_daily_mean = power_hourly.resample('D').mean()
        power_daily_mean.index = power_daily_mean.index + pd.Timedelta(hours=12)
        
        ax.plot(power_daily_mean.index, power_daily_mean.values, color='black', linewidth=2, 
                linestyle='-', marker='o', markersize=6, label='Daily Mean')
        
        # Today Line
        if today_date:
            ax.axvline(x=today_date, color='red', linestyle='--', linewidth=2, label='Today')

        if shape_warning:
            caveat = f"CAVEAT  {shape_warning}"
            if shape_detail:
                caveat += f"\n{shape_detail}"
            ax.text(0.99, 0.02, caveat,
                    transform=ax.transAxes, ha='right', va='bottom',
                    fontsize=13, fontweight='bold', color='darkred', zorder=1005,
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='lemonchiffon',
                              edgecolor='darkred', alpha=0.95))

        ax.set_title(title, fontsize=24, fontweight='bold', pad=20)
        ax.set_ylabel('€/MWh', fontsize=16, fontweight='bold')
        ax.grid(True, linestyle=':', alpha=0.6)
        
        # Format X-axis
        import matplotlib.dates as mdates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=14, fontweight='bold')
        plt.setp(ax.get_yticklabels(), fontsize=14, fontweight='bold')
        
        # Legend
        ax.legend(loc='upper left', fontsize=16, frameon=True, facecolor='white', framealpha=0.9, ncol=2)

    def generate_pdf(self, countries=['DE', 'FR'], days=365, output_file='power_price_report.pdf',
                     fan_start_year=2023):
        """
        Create a PDF report with calendar heatmaps for each country.

        Args:
            countries: List of country codes
            days: Number of days to show (default 450)
            output_file: Output PDF filename
            fan_start_year: First year shown on the monthly Stack Fan page (default 2023).
                            Cached spot data reaches back to 2018.
        """
        # Calculate date range
        n_days = 40
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days + n_days)  # Extra buffer for data availability
        
        print(f"Generating report for {', '.join(countries)}")
        print(f"Date range: {start_date.date()} to {end_date.date()}")
        
        # Create PDF
        with PdfPages(output_file) as pdf:
            for country in countries:
                ccy = '£' if country == 'UK' else '€'
                gas_label = 'NBP' if country == 'UK' else 'TTF'
                carbon_label = 'UKA' if country == 'UK' else 'EUA'
                carbon_ccy = '£' if country == 'UK' else '€'

                gas_eff_label = '49.13%' if country == 'UK' else '50%'
                css_subtitle = f'  [Power - (1/eff)*(NBP GBP/MWh + 0.1821*(UKA+18))]' if country == 'UK' else ''
                cds_subtitle = f'  [Power - (1/eff)*(Coal GBP/MWh + 0.34*(UKA+18))]' if country == 'UK' else ''
                metrics = [
                    ('Power', f'Power Price ({ccy}/MWh)', 'YlOrRd', 'int', 0),
                    ('CDS', f'Clean Dark Spread ({ccy}/MWh) - Coal Eff: 40%{cds_subtitle}', 'RdYlGn_r', 'int', 0),
                    ('CSS', f'Clean Spark Spread ({ccy}/MWh) - Gas Eff: {gas_eff_label}{css_subtitle}', 'RdYlGn_r', 'int', 0),
                    ('HeatRate', 'Heat Rate', 'viridis', 'decimal', 2),
                    ('Gas', f'Gas Price ({gas_label} {ccy}/MWh)', 'YlOrRd', 'decimal', 1),
                    ('Carbon', f'Carbon Price ({carbon_label} {carbon_ccy}/t)', 'Reds', 'decimal', 1),
                    ('Coal', 'Coal Price ($/t)', 'YlOrBr', 'int', 0)
                ]
                # --- Page 1: Daily Heatmaps ---
                df = self._generate_country_data(country, start_date, end_date)
                
                if df.empty:
                    print(f"  No data for {country}, skipping...")
                    continue
                
                # Filter to last N days
                df = df.sort_index()
                if not isinstance(df.index, pd.DatetimeIndex):
                    df.index = pd.to_datetime(df.index)
                cutoff_date = end_date - timedelta(days=days)
                df_plot = df.loc[df.index >= cutoff_date].copy()
                
                print(f"  Creating daily heatmaps for {country}...")
                
                fig = plt.figure(figsize=(24, 32)) 
                fig.patch.set_facecolor('white')
                
                gs = gridspec.GridSpec(7, 1, height_ratios=[1]*7, hspace=0.08, top=0.96, bottom=0.03, left=0.03, right=0.85)
                
                # Header
                header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                fig.patches.append(header_rect)
                fig.text(0.44, 0.983, f'Power Price Report: {country}', fontsize=16, fontweight='bold', va='center', ha='center', color='white', zorder=1002)
                fig.text(0.44, 0.970, f'{df_plot.index.min().date()} to {df_plot.index.max().date()}', fontsize=11, va='center', ha='center', color='white', zorder=1002)
                
                # Footer
                footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                fig.patches.append(footer_rect)
                fig.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', fontsize=9, va='center', ha='right', color='white', zorder=1002)
                
                for i, (metric_col, metric_title, cmap, val_format, decimals) in enumerate(metrics):
                    ax = plt.subplot(gs[i])
                    if metric_col in df_plot.columns:
                        self._create_calendar_heatmap(df_plot[metric_col], ax, metric_title, cmap=cmap, value_format=val_format, decimals=decimals)
                    else:
                        ax.text(0.5, 0.5, f'{metric_col} not available', ha='center', va='center', transform=ax.transAxes)
                
                plt.subplots_adjust(left=0.03, right=0.85, top=0.96, bottom=0.03, hspace=0.08)
                pdf.savefig(fig, dpi=150)
                plt.close(fig)
                print(f"  [OK] {country} daily page added")
                
                # --- Page 2: Monthly Metrics (HR, CSS, CDS) ---
                print(f"  Creating monthly metrics table for {country}...")
                hr_df, css_df, cds_df, cls_df, gas_df, coal_df, carbon_df, power_df = self._calculate_monthly_metrics(country, end_date - timedelta(days=365*5), end_date)
                
                if not hr_df.empty:
                    # Same size as daily page
                    fig2 = plt.figure(figsize=(24, 32)) 
                    fig2.patch.set_facecolor('white')
                    
                    # Header
                    header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig2.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                    fig2.patches.append(header_rect)
                    fig2.text(0.5, 0.98, f'Monthly Analysis: {country}', fontsize=20, fontweight='bold', va='center', ha='center', color='white', zorder=1002)
                    
                    # Footer
                    footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig2.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                    fig2.patches.append(footer_rect)
                    fig2.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', fontsize=9, va='center', ha='right', color='white', zorder=1002)

                    # 3 rows of 3 Side-by-Side Tables
                    # Row 1: HR, CSS, CDS
                    # Row 2: (Empty), Power, (Empty)
                    # Row 3: Gas, Coal, Carbon
                    
                    # Adjust constraints
                    gs2 = gridspec.GridSpec(3, 3, width_ratios=[1, 1, 1], height_ratios=[1, 1, 1], wspace=0.15, hspace=0.3, top=0.92, bottom=0.08, left=0.05, right=0.95)
                    
                    # Row 1
                    # 1. Heat Rate
                    ax_hr = plt.subplot(gs2[0, 0])
                    self._create_monthly_table_heatmap(hr_df, ax_hr, "Monthly Heat Rate", cmap='RdYlGn_r')
                    
                    # Currency-aware labels
                    ccy = '£' if country == 'UK' else '€'
                    gas_label = 'NBP' if country == 'UK' else 'TTF'
                    carbon_label = 'UKA' if country == 'UK' else 'EUA'
                    carbon_ccy = '£' if country == 'UK' else '€'

                    # 2. CSS
                    ax_css = plt.subplot(gs2[0, 1])
                    self._create_monthly_table_heatmap(css_df, ax_css, f"Monthly Clean Spark Spread ({ccy}/MWh)", cmap='RdYlGn_r')
                    
                    # 3. CDS
                    ax_cds = plt.subplot(gs2[0, 2])
                    self._create_monthly_table_heatmap(cds_df, ax_cds, f"Monthly Clean Dark Spread ({ccy}/MWh)", cmap='RdYlGn_r')
                    
                    # Row 2
                    # 4. Power (Center)
                    ax_power = plt.subplot(gs2[1, 1])
                    self._create_monthly_table_heatmap(power_df, ax_power, f"Monthly Power Price ({ccy}/MWh)", cmap='YlOrRd')

                    # 4b. CLS (Only for DE)
                    if country == 'DE':
                         ax_cls = plt.subplot(gs2[1, 0])
                         self._create_monthly_table_heatmap(cls_df, ax_cls, "Monthly Clean Lignite Spread (€/MWh)", cmap='RdYlGn_r')
                    
                    # Row 3
                    # 5. Gas
                    ax_gas = plt.subplot(gs2[2, 0])
                    self._create_monthly_table_heatmap(gas_df, ax_gas, f"Monthly Gas Price ({gas_label} {ccy}/MWh)", cmap='YlOrRd')
                    
                    # 6. Coal
                    ax_coal = plt.subplot(gs2[2, 1])
                    self._create_monthly_table_heatmap(coal_df, ax_coal, "Monthly Coal Price (API2 USD/t)", cmap='YlOrBr')

                    # 7. Carbon
                    ax_carbon = plt.subplot(gs2[2, 2])
                    self._create_monthly_table_heatmap(carbon_df, ax_carbon, f"Monthly Carbon Price ({carbon_label} {carbon_ccy}/t)", cmap='Reds')
                    
                    pdf.savefig(fig2, dpi=150)
                    plt.close(fig2)
                    print(f"  [OK] {country} monthly page added")

                    # --- Page 2b: Monthly Stack Fan Plot ---
                    if country in ['DE', 'FR', 'ES', 'IT', 'NL', 'HU', 'UK']:
                        print(f"  Fetching hourly power for Stack Fan page (from {fan_start_year})...")
                        # Fetch from 1 Jan of the fan start year for the multi-year fan plot
                        fan_start = datetime(fan_start_year, 1, 1)
                        hourly_power_df = self.loader.load_power(countries=country, start_date=fan_start, end_date=end_date)
                        self._create_stack_fan_page(pdf, country, power_df, gas_df, coal_df, carbon_df, hourly_power_df,
                                                    fan_start_year=fan_start_year)

                # --- Page 3: Forward Curve Evolution (14 Days) ---
                print(f"  Creating curve evolution charts for {country}...")
                try: 
                    history = self.loader.get_historical_curves(country, days=14)
                except Exception as e:
                    history = {}
                    print(f"Error fetching curve history: {e}")
                
                if history:
                    fig3 = plt.figure(figsize=(24, 32))
                    fig3.patch.set_facecolor('white')
                    
                    today = datetime.now()
                    max_plot_date = datetime(today.year + 2, 12, 31)
                    
                    header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig3.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                    fig3.patches.append(header_rect)
                    fig3.text(0.5, 0.98, f'Forward Curve Evolution (Last 14 Days): {country}', fontsize=20, fontweight='bold', va='center', ha='center', color='white', zorder=1002)
                    
                    footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig3.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                    fig3.patches.append(footer_rect)
                    fig3.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', fontsize=9, va='center', ha='right', color='white', zorder=1002)
                    
                    gs3 = gridspec.GridSpec(2, 1, height_ratios=[1, 1], hspace=0.2, top=0.92, bottom=0.08, left=0.08, right=0.92)
                    
                    ax1 = plt.subplot(gs3[0])
                    self._create_evolution_chart(
                        ax1, history, 'Power', 
                        'Power Price Evolution (Monthly Granularity)', f'{ccy}/MWh', 
                        cmap_name='viridis', max_date=max_plot_date, resample_freq='MS'
                    )
                    
                    ax2 = plt.subplot(gs3[1])
                    self._create_evolution_chart(
                        ax2, history, 'CSS', 
                        'Clean Spark Spread Evolution (Monthly Granularity)', f'{ccy}/MWh', 
                        cmap_name='viridis', max_date=max_plot_date, resample_freq='MS'
                    )
                    
                    pdf.savefig(fig3, dpi=150)
                    plt.close(fig3)
                    print(f"  [OK] {country} evolution page added")
                else:
                    print(f"  Warning: No history data for {country}, evolution page skipped.")
                    
                # --- Page 4: Hourly Spot vs SRMC (Spot + 60 days Forward) ---
                print(f"  Creating hourly spot & forward analysis for {country}...")
                
                try:
                    if hasattr(self, 'power_spot') and not self.power_spot.empty and country in self.power_spot.columns:
                        # 1. Historical Data (Last 30 Days)
                        today_dt = pd.to_datetime(end_date).normalize() 
                        hourly_start_hist = today_dt - timedelta(days=n_days)
                        
                        # Resample Spot to Hourly
                        power_native = self.power_spot[country].sort_index()
                        power_native.index = pd.to_datetime(power_native.index)
                        power_hist = power_native[(power_native.index >= hourly_start_hist) & (power_native.index < (today_dt + timedelta(days=1)))].resample('h').mean()
                        
                        # Fetch Historical Fuels
                        fuel_start_hist = hourly_start_hist.strftime('%Y-%m-%d')
                        fuel_end_hist = today_dt.strftime('%Y-%m-%d')
                        
                        gas_h = self.loader.load_gas(fuel_start_hist, country)
                        carb_h = self.loader.load_carbon(fuel_start_hist, fuel_end_hist)
                        coal_h = self.loader.load_coal(fuel_start_hist, fuel_end_hist)
                        
                        # Prepare History SRMC
                        srmc_hist = pd.DataFrame()
                        if country == 'UK':
                            gh = gas_h['NBP'] if 'NBP' in gas_h.columns else (gas_h['TTF'] if 'TTF' in gas_h.columns else pd.Series())
                            ch = carb_h['UKA'] if 'UKA' in carb_h.columns else pd.Series()
                            # NBP from cache is EUR/MWh -> convert to GBP/MWh
                            if not gh.empty:
                                fx_series = self.loader._get_fx_series('EUR_GBP')
                                if not fx_series.empty:
                                    aligned = pd.DataFrame({'gas': gh, 'fx': fx_series}).ffill(limit=5)
                                    gh = (aligned['gas'] * aligned['fx']).dropna()
                                else:
                                    gh = gh * 0.85
                        else:
                            gh = gas_h['TTF'] if 'TTF' in gas_h.columns else (gas_h['NBP'] if 'NBP' in gas_h.columns else pd.Series())
                            ch = carb_h['EUA'] if 'EUA' in carb_h.columns else pd.Series()
                        coh = coal_h['Coal'] if 'Coal' in coal_h.columns else pd.Series()
                        
                        if not gh.empty and not ch.empty and not coh.empty:
                            # Align to common daily index to handle mismatched holidays/weekends
                            # Use ffill(limit=7) to bridge weekends/holidays but not masked long outages
                            # normalize() ensures we match standard daily data (00:00:00)
                            common_idx = pd.date_range(start=hourly_start_hist, end=today_dt, freq='D')
                            
                            def align_fuel(s):
                                if s.empty: return s
                                # Ensure index is datetime
                                s.index = pd.to_datetime(s.index).normalize()
                                # Remove duplicates
                                if s.index.has_duplicates:
                                    s = s.groupby(s.index).mean()
                                return s.reindex(common_idx).ffill(limit=7)

                            gh_aligned = align_fuel(gh)
                            ch_aligned = align_fuel(ch)
                            coh_aligned = align_fuel(coh)
                            
                            srmc_hist = self._calculate_srmc_bands(gh_aligned, coh_aligned, ch_aligned, country_code=country)
                            srmc_hist.index = pd.to_datetime(srmc_hist.index)
                            srmc_hist = srmc_hist[srmc_hist.index <= today_dt]
                        
                        # 2. Forward Data (Next 60 Days)
                        # Fetch Forward Hourly Power
                        forward_power = self.loader.get_hourly_forward_curve(country)
                        # Capture provenance before slicing, which does not always carry attrs
                        fwd_shape_source = forward_power.attrs.get('shape_source')
                        fwd_shape_detail = forward_power.attrs.get('shape_detail')
                        # Shape and staleness are independent caveats: a curve can carry a
                        # proper market peak shape and still be priced off an older day.
                        fwd_shape_warning = ' | '.join(
                            w for w in (forward_power.attrs.get('shape_warning'),
                                        forward_power.attrs.get('stale_warning')) if w
                        ) or None
                        
                        srmc_fwd = pd.DataFrame()
                        power_fwd = pd.Series(dtype=float)
                        
                        if not forward_power.empty:
                            # Filter Forward to relevant range (Today to Today + 60d)
                            forward_power.index = pd.to_datetime(forward_power.index)
                            fwd_end = today_dt + timedelta(days=60)
                            # Ensure we don't double count today if specific timing overlaps, or just take > today
                            power_fwd = forward_power[(forward_power.index > today_dt) & (forward_power.index <= fwd_end)]
                            
                            if not power_fwd.empty:
                                # Fetch Forward Fuels (Daily)
                                curves = self.loader.build_forward_curves(country)
                                gf = curves.get('Gas')
                                cf = curves.get('Carbon')
                                cof = curves.get('Coal')
                                
                                if gf is not None and cf is not None and cof is not None:
                                    if country == 'UK':
                                        # ICE NBP forward is p/th -> GBP/MWh
                                        THERMS_PER_MWH = 34.121
                                        gf = gf * THERMS_PER_MWH / 100.0
                                    srmc_fwd_full = self._calculate_srmc_bands(gf, cof, cf, country_code=country)
                                    srmc_fwd_full.index = pd.to_datetime(srmc_fwd_full.index)
                                    # Filter
                                    srmc_fwd = srmc_fwd_full[(srmc_fwd_full.index > today_dt) & (srmc_fwd_full.index <= fwd_end)]
                                    
                        # [NEW] Bridge the gap between History and Forward (Interpolation)
                        # Ensure we work with valid data only
                        if not srmc_fwd.empty:
                            srmc_fwd = srmc_fwd.dropna()
                                    
                        # Identify gap
                        _last_hist_raw = srmc_hist.index.max() if not srmc_hist.empty else pd.NaT
                        _first_fwd_raw = srmc_fwd.index.min() if not srmc_fwd.empty else pd.NaT
                        last_hist_date = pd.to_datetime(_last_hist_raw).normalize() if pd.notna(_last_hist_raw) else pd.NaT
                        first_fwd_date = pd.to_datetime(_first_fwd_raw).normalize() if pd.notna(_first_fwd_raw) else pd.NaT
                        
                        srmc_bridge = pd.DataFrame()
                        
                        # Only bridge if we have both history and forward, and there is a gap > 1 day
                        if not srmc_hist.empty and not srmc_fwd.empty and pd.notna(last_hist_date) and pd.notna(first_fwd_date):
                             diff_days = (first_fwd_date - last_hist_date).days
                             
                             if diff_days > 1:
                                 # 1. Create Bridge Index (Daily)
                                 # Start from day after history, up to day before forward
                                 bridge_idx = pd.date_range(start=last_hist_date + timedelta(days=1), end=first_fwd_date - timedelta(days=1), freq='D')
                                 
                                 if not bridge_idx.empty:
                                     # 2. Interpolate Fuels
                                     # Get last history values
                                     last_hist_vals = {
                                         'Gas': gh_aligned.loc[last_hist_date] if not gh_aligned.empty else np.nan,
                                         'Coal': coh_aligned.loc[last_hist_date] if not coh_aligned.empty else np.nan,
                                         'Carbon': ch_aligned.loc[last_hist_date] if not ch_aligned.empty else np.nan
                                     }
                                     
                                     # Get first forward values (from the curves dict we loaded earlier, need to align)
                                     # We have 'gf', 'cf', 'cof' which are full series. Align them.
                                     # Forward curves might be monthly start, so we grab value at first_fwd_date
                                     first_fwd_vals = {
                                         'Gas': gf.asof(first_fwd_date) if gf is not None else np.nan,
                                         'Coal': cof.asof(first_fwd_date) if cof is not None else np.nan,
                                         'Carbon': cf.asof(first_fwd_date) if cf is not None else np.nan
                                     }
                                     
                                     # Build bridge DF
                                     bridge_df = pd.DataFrame(index=bridge_idx)
                                     for fuel in ['Gas', 'Coal', 'Carbon']:
                                         # Create series with start and end points for interpolation
                                         s_interp = pd.Series(index=[last_hist_date, first_fwd_date], data=[last_hist_vals[fuel], first_fwd_vals[fuel]])
                                         # Reindex to include bridge and interpolte
                                         full_span = bridge_idx.union([last_hist_date, first_fwd_date]).sort_values()
                                         # Interpolate using time-based method if index is datetime (which it is)
                                         interpolated = s_interp.reindex(full_span).interpolate(method='time') # better for datetimes
                                         # Extract only bridge portion
                                         bridge_df[fuel] = interpolated.reindex(bridge_idx)

                                     # 3. Calculate SRMC for Bridge
                                     if not bridge_df.isna().any().any():
                                          srmc_bridge = self._calculate_srmc_bands(bridge_df['Gas'], bridge_df['Coal'], bridge_df['Carbon'], country_code=country)
                                          srmc_bridge.index = pd.to_datetime(srmc_bridge.index)
                                     else:
                                          pass # Removed debug print


                        # 3. Merge
                        # Power
                        if not power_fwd.empty:
                            full_power = pd.concat([power_hist, power_fwd])
                            full_power = full_power.sort_index()
                        else:
                            full_power = power_hist

                        # SRMC (History + Bridge + Forward)
                        dfs_to_concat = [df for df in [srmc_hist, srmc_bridge, srmc_fwd] if not df.empty]
                        if dfs_to_concat:
                            full_srmc = pd.concat(dfs_to_concat)
                            full_srmc = full_srmc.sort_index()
                            # Deduplicate in case of overlap
                            full_srmc = full_srmc[~full_srmc.index.duplicated(keep='first')]
                        else:
                            full_srmc = pd.DataFrame()

                        if not full_power.empty and not full_srmc.empty:
                            # Create Page
                            fig4 = plt.figure(figsize=(24, 32))
                            fig4.patch.set_facecolor('white')
                            
                            # Header
                            header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig4.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                            fig4.patches.append(header_rect)
                            shape_label = f' | Fwd shape: {fwd_shape_source}' if fwd_shape_source else ''
                            fig4.text(0.5, 0.98, f'{country}: Hourly Power vs SRMC (Spot -{n_days}d / Forward +60d) [{full_power.index.min().date()} - {full_power.index.max().date()}]{shape_label}', fontsize=20, fontweight='bold', va='center', ha='center', color='white', zorder=1002)
                            
                            # Footer
                            footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig4.transFigure, facecolor='#231F20', edgecolor='none', zorder=1000)
                            fig4.patches.append(footer_rect)
                            fig4.text(0.97, 0.015, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M")}', fontsize=9, va='center', ha='right', color='white', zorder=1002)
                            
                            ax4 = plt.subplot(111)
                            
                            self._create_hourly_srmc_chart(ax4, full_power, full_srmc, "", today_date=today_dt,
                                                           shape_warning=fwd_shape_warning,
                                                           shape_detail=fwd_shape_detail)
                            
                            pdf.savefig(fig4, dpi=150)
                            plt.close(fig4)
                            print(f"  [OK] {country} hourly spot+forward page added")
                        else:
                            print(f"  Warning: Data incomplete for spot+forward page ({len(full_power)} power, {len(full_srmc)} srmc).")

                    else:
                        print(f"  Warning: No native power data stored for {country}.")
                        
                except Exception as e:
                    print(f"  Error creating hourly page for {country}: {e}")
                    import traceback
                    traceback.print_exc()

        print(f"\n[OK] Report saved to: {output_file}")


# ============================================================================
# Entry Point for Dagster Orchestration
# ============================================================================

def run_price_report(
    countries: list = None,
    days: int = 450,
    output_file: str = None,
    output_dir: str = None,
    recipients: str = None,
    dry_run: bool = False,
    fan_start_year: int = 2023
) -> dict:
    """
    Entry point for Dagster orchestration.

    Args:
        countries: List of country codes (default: DE, FR, NL, BE, UK, IT, ES)
        days: Number of days of historical data (default: 450)
        output_file: Output filename (auto-generated if None)
        output_dir: Output directory (default: current directory)
        recipients: Email recipients (if None, uses default)
        dry_run: If True, skip sending emails
        fan_start_year: First year shown on the Stack Fan page (default: 2023)
    
    Returns:
        dict with output_file path and metadata
    """
    import warnings
    warnings.simplefilter(action='ignore', category=FutureWarning)
    
    if countries is None:
        countries = ['DE', 'FR', 'NL', 'BE', 'UK', 'IT', 'ES']
    
    if output_file is None:
        output_file = f"Power_Price_Report_JG_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.pdf"
    
    if output_dir:
        import os
        output_file = os.path.join(output_dir, output_file)
    
    # Generate the PDF
    loader = DataLoader()
    report = Report(loader=loader)
    report.generate_pdf(countries=countries, days=days, output_file=output_file,
                        fan_start_year=fan_start_year)

    # Send email with PDF attachment
    if recipients is None:
        print("Warning: No email recipients specified. Skipping email.")
        return {
            "output_file": output_file,
            "countries": countries,
            "num_countries": len(countries),
            "days": days,
            "email_sent": False,
            "recipients": None
        }
    
    report_date = datetime.now().strftime('%Y-%m-%d')
    subject = f"Price Report - {report_date}"
    body = f"""
    <html>
    <body>
    <p>Please find attached the Power Price Report for {report_date}.</p>
    <p>Countries: {', '.join(countries)}</p>
    <p><i>This is an automated report.</i></p>
    </body>
    </html>
    """
    
    email_sent = False
    if dry_run:
        print(f"[DRY RUN] Would send email to {recipients} with attachment {output_file}")
    else:
        try:
            print(f"Sending email to {recipients}...")
            
            # Read and encode PDF attachment
            import base64
            with open(output_file, 'rb') as f:
                pdf_content = base64.b64encode(f.read()).decode('utf-8')
            
            attachment = {
                'content': pdf_content,
                'filename': os.path.basename(output_file)
            }
            
            send_email(
                recipients=recipients,
                subject=subject,
                body=body,
                attachment=attachment
            )
            print("Email sent successfully.")
            email_sent = True
        except Exception as e:
            print(f"Failed to send email: {e}")
            import traceback
            traceback.print_exc()
    
    return {
        "output_file": output_file,
        "countries": countries,
        "num_countries": len(countries),
        "days": days,
        "email_sent": email_sent,
        "recipients": recipients
    }


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Generate the Power Price Report PDF.')
    parser.add_argument('--countries', nargs='+', default=['FR', 'DE', 'IT'],
                        help='Country codes to include (default: FR DE IT)')
    parser.add_argument('--fan-start-year', type=int, default=2023,
                        help='First year on the monthly Stack Fan page (default: 2023; data available from 2018)')
    args = parser.parse_args()

    loader = DataLoader()

    output_filename = "Power Price Report" + "- JG - " + datetime.now().strftime('%Y-%m-%d_%H-%M-%S') + ".pdf"

    import warnings
    warnings.simplefilter(action='ignore', category=FutureWarning)

    report = Report(loader=loader)
    report.generate_pdf(countries=args.countries, days=450, output_file=output_filename,
                        fan_start_year=args.fan_start_year)
