"""
Dagster Sensor for Transmission Outage Alerts

Wraps the TransmissionOutageAlertService to run as a Dagster sensor,
using Dagster's cursor for state management.
"""

import json
from datetime import datetime, timedelta
from typing import Dict, Set, List, Optional

from dagster import sensor, SensorEvaluationContext, SkipReason, DefaultSensorStatus

# Import the core service class
from power_transmission_alert.power_transmission_alert import TransmissionOutageAlertService


class DagsterTransmissionAlertService(TransmissionOutageAlertService):
    """
    Subclass that uses Dagster context for logging and state management.
    """
    
    def __init__(self, context: SensorEvaluationContext, recipients: str):
        """
        Initialize with Dagster context instead of file-based state.
        
        Args:
            context: Dagster sensor evaluation context
            recipients: Email recipients
        """
        from pathlib import Path
        
        self.context = context
        self.base_dir = Path(__file__).parent.resolve()
        self.recipients = recipients
        self.monitored_assets_file = self.base_dir / "monitored_assets.json"
        
        # Load monitored assets from file (still use file for config)
        self.monitored_assets = self._load_monitored_assets()
        
        # Load state from Dagster cursor
        self.state = self._load_state_from_cursor()
    
    def _load_state_from_cursor(self) -> Dict:
        """Load state from Dagster cursor instead of file."""
        if self.context.cursor:
            try:
                state = json.loads(self.context.cursor)
                self.context.log.info(
                    f"Loaded state from cursor: last_publish_time={state.get('last_publish_time')}, "
                    f"seen_ids count={len(state.get('seen_ids', []))}"
                )
                return state
            except Exception as e:
                self.context.log.warning(f"Failed to parse cursor: {e}")
        
        # Default state: start from 1 hour ago
        start_time = (datetime.utcnow() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M')
        self.context.log.info(f"No cursor found, starting from {start_time}")
        return {"last_publish_time": start_time, "seen_ids": []}
    
    def _save_state_to_cursor(self):
        """Save state to Dagster cursor."""
        self.context.update_cursor(json.dumps(self.state))
    
    # Override logging to use Dagster context
    def _setup_logging(self, log_level):
        """Use Dagster context logging instead of file-based."""
        pass  # No-op, we use context.log
    
    @property
    def logger(self):
        """Return Dagster context logger."""
        return self.context.log
    
    def _load_monitored_assets(self) -> Dict[str, Dict[str, str]]:
        """Load monitored assets from JSON file."""
        if not self.monitored_assets_file.exists():
            self.context.log.warning(f"Monitored assets file not found: {self.monitored_assets_file}")
            return {}
        
        try:
            with open(self.monitored_assets_file, 'r') as f:
                config = json.load(f)
                assets = config.get('monitored_assets', {})
            self.context.log.info(f"Loaded {len(assets)} monitored assets")
            return assets
        except Exception as e:
            self.context.log.error(f"Failed to load monitored assets: {e}")
            return {}
    
    def check_and_alert(self) -> Dict:
        """
        Main check cycle - returns summary instead of just logging.
        
        Returns:
            Dict with summary of what was processed
        """
        import requests
        
        last_time_str = self.state.get("last_publish_time")
        seen_ids = set(self.state.get("seen_ids", []))
        
        if last_time_str is None:
            last_time_str = datetime.today().date().strftime('%Y-%m-%d %H:%M')
        
        now = datetime.utcnow()
        to_time_str = now.strftime('%Y-%m-%d %H:%M')
        
        self.context.log.info(f"Checking for outages from {last_time_str} to {to_time_str}")
        
        # Query API
        params = {
            "from": last_time_str,
            "to": to_time_str,
            "eventType": "Transmission unavailability",
            "latestRevisionOnly": "true"
        }
        headers = {'accept': 'application/json'}
        
        summary = {
            "total_messages": 0,
            "already_seen": 0,
            "filtered_out": 0,
            "alerts_sent": 0,
            "alert_details": []
        }
        
        try:
            resp = requests.get(self.REMIT_LIST_URL, params=params, headers=headers, timeout=30)
            if resp.status_code != 200:
                self.context.log.error(f"API Error: {resp.status_code}")
                return summary
            
            messages = resp.json()
            if not messages:
                self.context.log.info("No new messages.")
                self.state["last_publish_time"] = to_time_str
                self._save_state_to_cursor()
                return summary
            
            summary["total_messages"] = len(messages)
            self.context.log.info(f"Found {len(messages)} messages.")
            messages.sort(key=lambda x: x['publishTime'])
            
            # Process each message
            for msg in messages:
                msg_id = msg['id']
                
                if msg_id in seen_ids:
                    summary["already_seen"] += 1
                    continue
                
                mrid = msg.get('mrid')
                publish_time = msg.get('publishTime')
                
                # Fetch message detail
                try:
                    detail_url = self.REMIT_DETAIL_URL.format(message_id=msg_id)
                    detail_resp = requests.get(detail_url, headers=headers, timeout=30)
                    if detail_resp.status_code != 200:
                        seen_ids.add(msg_id)
                        continue
                    
                    detail_data = detail_resp.json()
                    if isinstance(detail_data, dict) and 'data' in detail_data:
                        msg_detail = detail_data['data'][0] if isinstance(detail_data['data'], list) else detail_data['data']
                    else:
                        msg_detail = detail_data
                    
                    asset_id = msg_detail.get('assetId')
                    
                    # Filter by monitored assets
                    if self.monitored_assets and asset_id not in self.monitored_assets:
                        seen_ids.add(msg_id)
                        summary["filtered_out"] += 1
                        continue
                    
                    # Get friendly name and direction
                    asset_info = self.monitored_assets.get(asset_id, {})
                    asset_name = asset_info.get('name', asset_id)
                    border = asset_info.get('border', asset_name)
                    direction = asset_info.get('direction', 'Unknown Direction')
                    
                except Exception as e:
                    self.context.log.error(f"Error fetching detail for {msg_id}: {e}")
                    seen_ids.add(msg_id)
                    continue
                
                self.context.log.info(f"Processing: {asset_name} ({direction}) - MRID: {mrid}")
                
                # Fetch revisions and create plot
                revisions = self._fetch_revisions(mrid)
                if not revisions:
                    seen_ids.add(msg_id)
                    continue
                
                img_base64, changes = self._create_plot(revisions, mrid, asset_name, direction)
                
                # --- Filtering Logic ---
                if not changes:
                    self.context.log.info(f"Skipping {mrid} - No capacity changes detected")
                    seen_ids.add(msg_id)
                    continue
                
                # Filter 1: Total duration < 12 hours
                total_seconds = sum((c['end'] - c['start']).total_seconds() for c in changes)
                hours_duration = total_seconds / 3600.0
                if hours_duration < 12.0:
                    self.context.log.info(f"Skipping {mrid} - Duration {hours_duration:.1f}h < 12h")
                    seen_ids.add(msg_id)
                    continue
                
                # Filter 2: All changes fully within today
                today_date = datetime.utcnow().date()
                all_within_today = all(
                    c['start'].date() == today_date and c['end'].date() == today_date
                    for c in changes
                )
                
                if all_within_today:
                    self.context.log.info(f"Skipping {mrid} - All changes within today")
                    seen_ids.add(msg_id)
                    continue
                
                # Send alert
                if img_base64:
                    subject = f"Transmission Outage Alert: {border} ({direction}) - {msg_detail.get('unavailabilityType', 'Unknown')}"
                    
                    latest_rev = revisions[-1] if revisions else {}
                    body = self._build_email_body(
                        asset_name, direction, asset_id, mrid,
                        msg_detail, latest_rev, publish_time,
                        changes
                    )
                    
                    try:
                        from jain_commods.core.util.emailhelper import send_email
                        send_email(recipients=self.recipients, subject=subject, body=body)
                        self.context.log.info(f"✓ Alert sent: {asset_name} ({direction})")
                        summary["alerts_sent"] += 1
                        summary["alert_details"].append(f"{asset_name} ({direction})")
                    except Exception as e:
                        self.context.log.error(f"Failed to send email: {e}")
                
                seen_ids.add(msg_id)
            
            # Update state
            if len(seen_ids) > 1000:
                seen_ids = list(seen_ids)[-1000:]
            else:
                seen_ids = list(seen_ids)
            
            self.state["seen_ids"] = seen_ids
            self.state["last_publish_time"] = to_time_str
            self._save_state_to_cursor()
            
            return summary
            
        except Exception as e:
            self.context.log.error(f"Error in check_and_alert: {e}")
            return summary


def create_transmission_outage_sensor(
    recipients: str = None,
    minimum_interval_seconds: int = 600,  # 10 minutes
    default_status: DefaultSensorStatus = DefaultSensorStatus.STOPPED
):
    """
    Factory function to create the transmission outage sensor.
    
    Args:
        recipients: Email recipients (comma-separated)
        minimum_interval_seconds: How often to check (default 10 min)
        default_status: Whether sensor starts running or stopped
    
    Returns:
        Configured sensor
    """
    
    @sensor(
        name="transmission_outage_sensor",
        minimum_interval_seconds=minimum_interval_seconds,
        description="Monitors UK interconnector transmission outages and sends email alerts",
        default_status=default_status,
    )
    def transmission_outage_sensor(context: SensorEvaluationContext):
        """
        Sensor that monitors REMIT API for transmission unavailability events
        and sends email alerts when significant changes are detected.
        """
        import os
        
        # Get recipients from parameter, env var, or config
        email_recipients = recipients
        if not email_recipients:
            email_recipients = os.getenv("TRANSMISSION_ALERT_RECIPIENTS")
        if not email_recipients:
            try:
                from jain_commods.core.util.dagster.config import get_email_receivers
                email_recipients = get_email_receivers(default=None)
            except ImportError:
                pass
        
        if not email_recipients:
            context.log.warning("No email recipients configured for transmission alerts")
            return SkipReason("No email recipients configured")
        
        context.log.info(f"Starting transmission outage check, recipients: {email_recipients}")
        
        # Create service instance with Dagster context
        service = DagsterTransmissionAlertService(context, email_recipients)
        
        # Run the check
        summary = service.check_and_alert()
        
        # Return appropriate result
        if summary["alerts_sent"] > 0:
            details = ", ".join(summary["alert_details"])
            return SkipReason(
                f"Sent {summary['alerts_sent']} alert(s): {details}"
            )
        else:
            return SkipReason(
                f"No alerts. Checked {summary['total_messages']} messages, "
                f"{summary['filtered_out']} filtered, {summary['already_seen']} already seen"
            )
    
    return transmission_outage_sensor

