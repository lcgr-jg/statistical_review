"""
Transmission Outage Alert Service

Monitors Elexon BMRS REMIT API for transmission unavailability events
and sends email alerts with visual comparisons when changes are detected.

Author: Michael Kane
Date: December 2025
"""

import time
import json
import logging
import base64
import requests
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
from io import BytesIO
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set

try:
    from jain_commods.core.util.emailhelper import send_email
except ImportError:
    # Fallback for local testing
    def send_email(*args, **kwargs):
        print(f"Mock Email Sent: {kwargs.get('subject')}")


class TransmissionOutageAlertService:
    """
    Service class for monitoring and alerting on transmission outages.
    
    This service continuously polls the REMIT API for transmission unavailability
    messages, compares revisions to detect changes, and sends HTML email alerts
    with embedded visualizations.
    """
    
    # API Endpoints
    REMIT_LIST_URL = "https://data.elexon.co.uk/bmrs/api/v1/remit/list/by-publish/stream"
    REMIT_REVISIONS_URL = "https://data.elexon.co.uk/bmrs/api/v1/remit/revisions"
    REMIT_DETAIL_URL = "https://data.elexon.co.uk/bmrs/api/v1/remit/{message_id}"
    
    def __init__(
        self,
        base_dir: Path = None,
        check_interval: int = 600,
        recipients: str = "michael.kane@jainglobal.com",
        log_level: int = logging.INFO
    ):
        """
        Initialize the alert service.
        
        Args:
            base_dir: Base directory for config/state files
            check_interval: Seconds between API checks
            recipients: Email recipients (comma-separated)
            log_level: Logging level
        """
        self.base_dir = base_dir or Path(__file__).parent.resolve()
        self.check_interval = check_interval
        self.recipients = recipients
        self.recipients = recipients

        # File paths
        self.state_file = self.base_dir / "state.json"
        self.log_file = self.base_dir / "power_transmission_alert.log"
        self.monitored_assets_file = self.base_dir / "monitored_assets.json"
        
        # Setup logging
        self._setup_logging(log_level)
        
        # Load configuration and state
        self.monitored_assets = self._load_monitored_assets()
        self.state = self._load_state()
    
    def _setup_logging(self, log_level: int):
        """Configure logging for the service."""
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[logging.StreamHandler()]
        )
        self.logger = logging.getLogger(__name__)
    
    def _load_monitored_assets(self) -> Dict[str, Dict[str, str]]:
        """
        Load monitored assets configuration from JSON file.
        
        Returns:
            Dictionary mapping asset ID to {name, direction}
        """
        if not self.monitored_assets_file.exists():
            self.logger.warning(f"Monitored assets file not found: {self.monitored_assets_file}")
            return {}
        
        try:
            with open(self.monitored_assets_file, 'r') as f:
                config = json.load(f)
                assets = config.get('monitored_assets', {})
            self.logger.info(f"Loaded {len(assets)} monitored assets")
            return assets
        except Exception as e:
            self.logger.error(f"Failed to load monitored assets: {e}")
            return {}
    
    def _load_state(self) -> Dict:
        """
        Load service state from file.
        
        Returns:
            State dictionary with last_publish_time and seen_ids
        """
        if self.state_file.exists():
            try:
                with open(self.state_file, 'r') as f:
                    state = json.load(f)
                    self.logger.info(
                        f"Loaded state: last_publish_time={state.get('last_publish_time')}, "
                        f"seen_ids count={len(state.get('seen_ids', []))}"
                    )
                    return state
            except Exception as e:
                self.logger.error(f"Failed to load state: {e}")
        
        # Default state: start from 1 hour ago
        start_time = (datetime.utcnow() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M')
        self.logger.warning(f"No state file found, starting with default state from {start_time}")
        return {"last_publish_time": start_time, "seen_ids": []}
    
    def _save_state(self):
        """Save current state to file."""
        try:
            with open(self.state_file, 'w') as f:
                json.dump(self.state, f)
            self.logger.debug(
                f"State saved: last_publish_time={self.state.get('last_publish_time')}, "
                f"seen_ids count={len(self.state.get('seen_ids', []))}"
            )
        except Exception as e:
            self.logger.error(f"Failed to save state: {e}")
    
    def _fetch_revisions(self, mrid: str) -> List[Dict]:
        """
        Fetch all revisions for a given MRID.
        
        Args:
            mrid: Market Resource Identifier
            
        Returns:
            List of revision dictionaries (last 2 revisions)
        """
        headers = {'accept': 'application/json'}
        
        # Step 1: Get revision list
        try:
            self.logger.debug(f"Fetching revision list for MRID: {mrid}")
            resp = requests.get(
                self.REMIT_REVISIONS_URL,
                params={"mrid": mrid},
                headers=headers,
                timeout=30
            )
            
            if resp.status_code != 200:
                self.logger.error(f"Error listing revisions for {mrid}: {resp.status_code}")
                return []
            
            data = resp.json()
            revisions_meta = data.get('data', []) if isinstance(data, dict) else data
            
            self.logger.info(f"Found {len(revisions_meta)} revisions for MRID: {mrid}")
            
        except Exception as e:
            self.logger.error(f"Exception listing revisions for {mrid}: {e}")
            return []
        
        if not revisions_meta:
            self.logger.warning(f"No revisions found for MRID: {mrid}")
            return []
        
        # Sort and get last 2
        revisions_meta.sort(key=lambda x: x['revisionNumber'])
        target_metas = revisions_meta[-2:]
        
        self.logger.debug(f"Fetching details for last 2 revisions of MRID: {mrid}")
        
        # Step 2: Fetch full details
        full_revisions = []
        for meta in target_metas:
            msg_id = meta['id']
            rev_num = meta.get('revisionNumber')
            
            try:
                self.logger.debug(f"Fetching revision {rev_num} (msg_id: {msg_id}) for MRID: {mrid}")
                url = self.REMIT_DETAIL_URL.format(message_id=msg_id)
                r = requests.get(url, headers=headers, timeout=30)
                
                if r.status_code == 200:
                    d = r.json()
                    # Extract from data wrapper
                    if isinstance(d, dict) and 'data' in d:
                        if isinstance(d['data'], list) and len(d['data']) > 0:
                            full_revisions.append(d['data'][0])
                        elif isinstance(d['data'], dict):
                            full_revisions.append(d['data'])
                    else:
                        full_revisions.append(d)
                    self.logger.debug(f"Successfully fetched revision {rev_num}")
                else:
                    self.logger.error(f"Failed detail fetch for msg_id {msg_id} (rev {rev_num}): {r.status_code}")
            except Exception as e:
                self.logger.error(f"Failed to fetch detail for revision {msg_id} (rev {rev_num}): {e}")
        
        self.logger.info(f"Retrieved {len(full_revisions)} full revision details for MRID: {mrid}")
        return full_revisions
    
    def _create_plot(
        self,
        revisions: List[Dict],
        mrid: str,
        asset_name: str = None,
        direction: str = None
    ) -> Tuple[Optional[str], List[Dict]]:
        """
        Create comparison plot for revisions.
        
        Args:
            revisions: List of revision dictionaries
            mrid: Market Resource Identifier
            asset_name: Friendly name of asset
            direction: Flow direction (UK Import/Export)
            
        Returns:
            Tuple of (base64 encoded image string, list of change dictionaries)
        """
        self.logger.info(f"Creating plot for MRID: {mrid}, Asset: {asset_name}, Direction: {direction}")
        
        if not revisions:
            self.logger.warning(f"No revisions provided for plotting MRID: {mrid}")
            return None, []
        
        # Sort and extract latest/previous
        revisions.sort(key=lambda x: x['revisionNumber'])
        latest = revisions[-1]
        previous = revisions[-2] if len(revisions) > 1 else None
        
        self.logger.debug(
            f"Plotting revisions - Latest: {latest.get('revisionNumber')}, "
            f"Previous: {previous.get('revisionNumber') if previous else 'N/A'}"
        )
        
        # Extract profiles
        def get_profile_df(rev):
            if not rev or 'outageProfile' not in rev:
                return pd.DataFrame(columns=['startTime', 'endTime', 'capacity'])
            
            data = rev['outageProfile']
            if not data:
                 return pd.DataFrame(columns=['startTime', 'endTime', 'capacity'])
            
            df = pd.DataFrame(data)
            # Ensure required columns exist
            if 'startTime' not in df.columns:
                df['startTime'] = pd.Series(dtype='datetime64[ns]')
            if 'endTime' not in df.columns:
                 df['endTime'] = pd.Series(dtype='datetime64[ns]')
            if 'capacity' not in df.columns:
                 df['capacity'] = pd.Series(dtype='float')

            if not df.empty:
                df['startTime'] = pd.to_datetime(df['startTime'])
                df['endTime'] = pd.to_datetime(df['endTime'])
            return df
        
        df_latest = get_profile_df(latest).sort_values('startTime')
        df_prev = get_profile_df(previous).sort_values('startTime')
        
        self.logger.debug(f"Extracted profiles - Latest: {len(df_latest)} rows, Previous: {len(df_prev)} rows")
        
        if df_latest.empty:
            self.logger.warning(f"Latest profile is empty for MRID: {mrid}")
            return None, []
        
        # Determine time window
        today = pd.Timestamp.now(tz='UTC').floor('D')
        lookback_start = today - pd.Timedelta(days=30)
        
        min_start = df_latest['startTime'].min()
        max_end = df_latest['endTime'].max()
        
        # Ensure timezone
        if min_start.tz is None:
            min_start = min_start.tz_localize('UTC')
        if max_end.tz is None:
            max_end = max_end.tz_localize('UTC')
        
        # Smart window: show relevant period only
        if min_start > lookback_start:
            view_start = min_start - pd.Timedelta(days=2)
        else:
            view_start = lookback_start
        
        view_end = max_end + pd.Timedelta(days=30)
        
        # Create plot
        fig = plt.figure(figsize=(18, 10))
        gs = fig.add_gridspec(2, 1, height_ratios=[3, 1], hspace=0.3)
        
        ax_main = fig.add_subplot(gs[0])
        ax_delta = fig.add_subplot(gs[1], sharex=ax_main)
        
        # Plot normal capacity
        normal_cap = latest.get('normalCapacity')
        
        # Fallback if normal_cap is 0 or None (happens with some interconnectors)
        if not normal_cap:
            avail = latest.get('availableCapacity', 0) or 0
            unavail = latest.get('unavailableCapacity', 0) or 0
            if avail + unavail > 0:
                normal_cap = avail + unavail
                self.logger.info(f"Normal capacity missing/zero. Estimated from available+unavailable: {normal_cap}")

        if normal_cap is not None:
            ax_main.axhline(y=normal_cap, color='green', linestyle='-', label='_nolegend_', linewidth=2, alpha=0.6)
        
        # Function to plot step profiles
        def plot_step(ax, df, label, style, color):
            if df.empty:
                return
            x, y = [], []
            for _, row in df.iterrows():
                x.extend([row['startTime'], row['endTime']])
                y.extend([row['capacity'], row['capacity']])
            
            # Extend to view_end
            if not df.empty and normal_cap is not None:
                last_end = df.iloc[-1]['endTime']
                x.extend([last_end, view_end])
                y.extend([normal_cap, normal_cap])
            
            ax.plot(x, y, style, color=color, label=label, linewidth=2)
            if label.startswith("Latest"):
                ax.fill_between(x, y, alpha=0.1, color=color)
        
        # Format timestamps for legend
        def fmt_ts(ts_str):
            try:
                dt = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
                return dt.strftime('%Y-%m-%d\n%H:%M')
            except:
                return ts_str
        
        prev_ts = fmt_ts(previous.get('publishTime')) if previous else "N/A"
        latest_ts = fmt_ts(latest.get('publishTime'))
        
        # Plot profiles
        plot_step(ax_main, df_latest, f"Latest:\n{latest_ts}", '--', 'blue')
        if not df_prev.empty:
            plot_step(ax_main, df_prev, f"Previous:\n{prev_ts}", ':', 'red')
        
        # Calculate delta
        changes = []
        if not df_latest.empty:
            # Combine all unique timestamps
            if not df_prev.empty:
                all_times = sorted(list(set(
                    df_latest['startTime'].tolist() + df_latest['endTime'].tolist() +
                    df_prev['startTime'].tolist() + df_prev['endTime'].tolist()
                )))
            else:
                all_times = sorted(list(set(
                    df_latest['startTime'].tolist() + df_latest['endTime'].tolist()
                )))
            
            def make_series(df, times):
                res = []
                for t in times:
                    match = df[(df['startTime'] <= t) & (df['endTime'] > t)]
                    val = match.iloc[0]['capacity'] if not match.empty else (normal_cap if normal_cap is not None else 0)
                    res.append(val)
                return pd.Series(res, index=times)
            
            view_times = [t for t in all_times if view_start <= t <= view_end]
            if not view_times:
                view_times = [view_start, view_end]
            
            s_latest = make_series(df_latest, view_times)
            
            if not df_prev.empty:
                s_prev = make_series(df_prev, view_times)
            else:
                # For new revisions, compare against normal capacity
                val = normal_cap if normal_cap is not None else 0
                s_prev = pd.Series(val, index=view_times)

            delta = s_latest - s_prev
            
            # Plot delta
            dx, dy = [], []
            for i in range(len(view_times)-1):
                dx.extend([view_times[i], view_times[i+1]])
                dy.extend([delta.loc[view_times[i]], delta.loc[view_times[i]]])
            
            ax_delta.plot(dx, dy, color='black', linewidth=1)
            ax_delta.fill_between(dx, dy, alpha=0.2, color='gray')
            ax_delta.axhline(0, color='black', linestyle='-', linewidth=0.5)
            
            # Extract changes
            for i in range(len(view_times)-1):
                t_start = view_times[i]
                t_end = view_times[i+1]
                val = delta.loc[t_start]
                if abs(val) > 0.1:
                    if changes and changes[-1]['val'] == val and changes[-1]['end'] == t_start:
                        changes[-1]['end'] = t_end
                    else:
                        changes.append({
                            'start': t_start,
                            'end': t_end,
                            'val': val,
                            'prev': s_prev.loc[t_start],
                            'curr': s_latest.loc[t_start]
                        })
        
        # Formatting
        ax_main.set_xlim(view_start, view_end)
        now_ts = pd.Timestamp.now(tz='UTC')
        
        for ax in [ax_main, ax_delta]:
            ax.xaxis.set_major_locator(mdates.MonthLocator())
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
            ax.xaxis.set_minor_locator(mdates.MonthLocator())
            
            ax.grid(True, which='major', axis='x', linestyle=':', color='gray', alpha=0.7)
            ax.grid(True, which='major', axis='y', alpha=0.3)
            
            # Weekend shading
            curr = view_start
            days_until_sat = (5 - curr.weekday()) % 7
            curr += timedelta(days=days_until_sat)
            while curr < view_end:
                ax.axvspan(curr, curr + timedelta(days=2), color='gray', alpha=0.1)
                curr += timedelta(days=7)
            
            # Today line
            if view_start <= now_ts <= view_end:
                ax.axvline(now_ts, color='black', linestyle='--', linewidth=1, alpha=0.8)
            
            # Tick formatting
            for label in ax.get_xticklabels():
                label.set_rotation(45)
                label.set_ha('right')
        
        plt.setp(ax_main.get_xticklabels(), visible=True)
        
        # Titles and labels
        asset_display = asset_name if asset_name else latest.get('assetId', 'N/A')
        direction_display = f" ({direction})" if direction else ""
        
        is_new = latest.get('revisionNumber') == 1
        new_tag = " [NEW OUTAGE]" if is_new else ""
        
        ax_main.set_title(
            f"Transmission Outage Profile: {asset_display}{direction_display}{new_tag}\n"
            f"Asset ID: {latest.get('assetId', 'N/A')} | Participant: {latest.get('participantId', 'N/A')}"
        )
        ax_main.set_ylabel("Capacity (MW)")
        ax_delta.set_ylabel("Delta (MW)")
        ax_delta.set_title("Delta (Latest - Previous)")
        
        # Legend
        ax_main.legend(
            loc='center left',
            bbox_to_anchor=(1.01, 0.5),
            borderaxespad=0,
            frameon=True,
            fancybox=True,
            shadow=True,
            fontsize=9
        )
        
        # Save to base64
        buf = BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)
        
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        self.logger.info(f"Plot created successfully for MRID: {mrid}, Changes detected: {len(changes)}")
        
        return img_str, changes
    
    def _build_email_body(
        self,
        asset_name: str,
        direction: str,
        asset_id: str,
        mrid: str,
        msg_detail: Dict,
        latest_rev: Dict,
        publish_time: str,
        changes: List[Dict]
    ) -> str:
        """
        Build HTML email body with change summary and details.
        
        Returns:
            HTML string
        """
        # Build changes table HTML
        changes_table_html = ""
        if changes:
            self.logger.debug(f"Building capacity changes table with {len(changes)} change periods")
            changes_table_html = """
            <h3>Capacity Changes Summary</h3>
            <table class="delta-table">
                <thead>
                    <tr>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Previous MW</th>
                        <th>Current MW</th>
                        <th>Delta MW</th>
                    </tr>
                </thead>
                <tbody>
            """
            for c in changes:
                s_str = c['start'].strftime('%Y-%m-%d %H:%M')
                e_str = c['end'].strftime('%Y-%m-%d %H:%M')
                delta_val = c['val']
                delta_class = 'negative' if delta_val < 0 else 'positive'
                changes_table_html += f"""
                    <tr>
                        <td>{s_str}</td>
                        <td>{e_str}</td>
                        <td>{c['prev']:.1f}</td>
                        <td>{c['curr']:.1f}</td>
                        <td class="{delta_class}">{delta_val:+.1f}</td>
                    </tr>
                """
            changes_table_html += """
                </tbody>
            </table>
            """
        
        # Full HTML body
        rev_num = msg_detail.get('revisionNumber', latest_rev.get('revisionNumber', 0))
        email_title = "New Transmission Outage Message Received" if rev_num == 1 else "Transmission Outage Update Received"
        remit_url = f"https://bmrs.elexon.co.uk/remit/details/{mrid}"

        return f"""
        <html>
        <head>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    font-size: 14px;
                }}
                .info-section {{
                    margin-bottom: 20px;
                }}
                .info-row {{
                    margin: 5px 0;
                }}
                .label {{
                    font-weight: bold;
                    display: inline-block;
                    width: 200px;
                }}
                .delta-table {{
                    border-collapse: collapse;
                    width: 100%;
                    margin-bottom: 30px;
                    font-size: 16px;
                    border: 2px solid #333;
                }}
                .delta-table th {{
                    background-color: #d0d0d0;
                    color: #333;
                    padding: 18px;
                    text-align: center;
                    font-size: 18px;
                    font-weight: bold;
                    border: 2px solid #333;
                }}
                .delta-table td {{
                    border: 2px solid #999;
                    padding: 18px;
                    text-align: center;
                    font-size: 16px;
                }}
                .delta-table tr:nth-child(even) {{
                    background-color: #f9f9f9;
                }}
                .delta-table tr:hover {{
                    background-color: #e0e0e0;
                }}
                .negative {{
                    background-color: #ffcccc !important;
                    color: #cc0000;
                    font-weight: bold;
                }}
                .positive {{
                    background-color: #ccffcc !important;
                    color: #006600;
                    font-weight: bold;
                }}
                .link-section {{
                    margin-bottom: 20px;
                    font-size: 16px;
                }}
            </style>
        </head>
        <body>
            <h2>{email_title}</h2>
            
            <div class="link-section">
                <a href="{remit_url}">View details on BMRS ({mrid})</a>
            </div>

            {changes_table_html}
            
            <h3>Outage Details</h3>
            <div class="info-section">
                <div class="info-row"><span class="label">Interconnector:</span> {asset_name}</div>
                <div class="info-row"><span class="label">Direction:</span> {direction}</div>
                <div class="info-row"><span class="label">Asset ID:</span> {asset_id}</div>
                <div class="info-row"><span class="label">MRID:</span> {mrid}</div>
            </div>
            
            <div class="info-section">
                <div class="info-row"><span class="label">Participant:</span> {msg_detail.get('participantId')}</div>
                <div class="info-row"><span class="label">Type:</span> {msg_detail.get('unavailabilityType')}</div>
                <div class="info-row"><span class="label">Event Start:</span> {latest_rev.get('eventStartTime')}</div>
                <div class="info-row"><span class="label">Event End:</span> {latest_rev.get('eventEndTime')}</div>
                <div class="info-row"><span class="label">Cause:</span> {latest_rev.get('cause')}</div>
            </div>
            
            <div class="info-section">
                <div class="info-row"><span class="label">Normal Capacity:</span> {latest_rev.get('normalCapacity')} MW</div>
                <div class="info-row"><span class="label">Available Capacity:</span> {latest_rev.get('availableCapacity')} MW</div>
                <div class="info-row"><span class="label">Unavailable Capacity:</span> {latest_rev.get('unavailableCapacity')} MW</div>
            </div>
            
            <div class="info-section">
                <div class="info-row"><span class="label">Publish Time:</span> {publish_time}</div>
                <div class="info-row"><span class="label">Revision:</span> {msg_detail.get('revisionNumber')}</div>
            </div>
        </body>
        </html>
        """
    
    def check_and_alert(self):
        """
        Main check cycle: query API, process messages, send alerts.
        """

        last_time_str = self.state.get("last_publish_time")
        seen_ids = set(self.state.get("seen_ids", []))

        if last_time_str == None:
            last_time_str = datetime.today().date().strftime('%Y-%m-%d %H:%M')



        now = datetime.utcnow()
        to_time_str = now.strftime('%Y-%m-%d %H:%M')
        
        self.logger.info(f"Checking for outages from {last_time_str} to {to_time_str}")
        
        # Query API
        params = {
            "from": last_time_str,
            "to": to_time_str,
            "eventType": "Transmission unavailability",
            "latestRevisionOnly": "true"
        }
        headers = {'accept': 'application/json'}
        
        try:
            resp = requests.get(self.REMIT_LIST_URL, params=params, headers=headers, timeout=30)
            if resp.status_code != 200:
                self.logger.error(f"API Error: {resp.status_code}")
                return
            
            messages = resp.json()
            if not messages:
                self.logger.info("No new messages.")
                self.state["last_publish_time"] = to_time_str
                self._save_state()
                return
            
            self.logger.info(f"Found {len(messages)} messages.")
            messages.sort(key=lambda x: x['publishTime'])
            
            processed_count = 0
            filtered_count = 0
            
            # Process each message
            for msg in messages:
                msg_id = msg['id']
                
                if msg_id in seen_ids:
                    self.logger.debug(f"Skipping already seen message ID: {msg_id}")
                    continue
                
                mrid = msg.get('mrid')
                publish_time = msg.get('publishTime')
                self.logger.debug(f"Processing message ID: {msg_id}, MRID: {mrid}, Published: {publish_time}")
                
                # Fetch message detail
                try:
                    detail_url = self.REMIT_DETAIL_URL.format(message_id=msg_id)
                    detail_resp = requests.get(detail_url, headers=headers, timeout=30)
                    if detail_resp.status_code != 200:
                        self.logger.warning(f"Failed to fetch detail for message {msg_id}")
                        seen_ids.add(msg_id)
                        continue
                    
                    detail_data = detail_resp.json()
                    if isinstance(detail_data, dict) and 'data' in detail_data:
                        msg_detail = detail_data['data'][0] if isinstance(detail_data['data'], list) else detail_data['data']
                    else:
                        msg_detail = detail_data
                    
                    asset_id = msg_detail.get('assetId')
                    
                    # Filter by monitored assets
                    if self.monitored_assets and asset_id not in self.monitored_assets:
                        self.logger.info(f"Skipping message {msg_id} - Asset {asset_id} not in monitored list")
                        seen_ids.add(msg_id)
                        filtered_count += 1
                        continue
                    
                    # Get friendly name and direction
                    asset_info = self.monitored_assets.get(asset_id, {})
                    asset_name = asset_info.get('name', asset_id)
                    border = asset_info.get('border', asset_name)
                    direction = asset_info.get('direction', 'Unknown Direction')
                    
                except Exception as e:
                    self.logger.error(f"Error fetching detail for {msg_id}: {e}")
                    seen_ids.add(msg_id)
                    continue
                
                self.logger.info(f"Processing new message ID {msg_id} (MRID: {mrid}, Asset: {asset_id})")
                
                # Fetch revisions and create plot
                revisions = self._fetch_revisions(mrid)
                if not revisions:
                    self.logger.warning(f"No revisions retrieved for MRID: {mrid}, skipping")
                    seen_ids.add(msg_id)
                    continue
                
                img_base64, changes = self._create_plot(revisions, mrid, asset_name, direction)
                
                # --- Filtering Logic ---
                if not changes:
                    self.logger.info(f"Skipping {mrid} - No capacity changes detected (or empty delta)")
                    seen_ids.add(msg_id)
                    continue

                # Filter 1: Total duration < 12 hours
                total_seconds = sum((c['end'] - c['start']).total_seconds() for c in changes)
                hours_duration = total_seconds / 3600.0
                if hours_duration < 12.0:
                    self.logger.info(f"Skipping {mrid} - Total delta duration {hours_duration:.2f}h < 12h")
                    seen_ids.add(msg_id)
                    continue

                # Filter 2: All changes fully within today's UTC date
                today_date = datetime.utcnow().date()
                all_within_today = True
                for c in changes:
                    # Check if both start and end of the change period are on today's date
                    if c['start'].date() != today_date or c['end'].date() != today_date:
                        all_within_today = False
                        break
                
                if all_within_today:
                    self.logger.info(f"Skipping {mrid} - All changes are fully within today ({today_date})")
                    seen_ids.add(msg_id)
                    continue
                # -----------------------
                
                if img_base64:
                    # Build and send email
                    subject = f"Transmission Outage Alert: {border} ({direction}) - {msg_detail.get('unavailabilityType', 'Unknown')}"
                    self.logger.info(f"Preparing email for {asset_name} ({direction}), Changes: {len(changes)}")
                    
                    latest_rev = revisions[-1] if revisions else {}
                    body = self._build_email_body(
                        asset_name, direction, asset_id, mrid,
                        msg_detail, latest_rev, publish_time,
                        changes
                    )
                    
                    try:
                        self.logger.debug(f"Sending email to {self.recipients}, Subject: {subject}")
                        send_email(recipients=self.recipients, subject=subject, body=body)
                        self.logger.info(f"Email sent successfully for {asset_name} ({direction}) - MRID: {mrid}")
                    except Exception as e:
                        self.logger.error(f"Failed to send email for {mrid}: {e}", exc_info=True)
                
                seen_ids.add(msg_id)
                processed_count += 1
            
            # Update state
            if len(seen_ids) > 1000:
                seen_ids = list(seen_ids)[-1000:]
            else:
                seen_ids = list(seen_ids)
            
            self.state["seen_ids"] = seen_ids
            self.state["last_publish_time"] = to_time_str
            self._save_state()
            
            # Summary
            self.logger.info(f"=== Check cycle complete ===")
            self.logger.info(f"Total messages found: {len(messages)}")
            self.logger.info(f"Already seen (skipped): {len(messages) - filtered_count - processed_count}")
            self.logger.info(f"Filtered out (not monitored): {filtered_count}")
            self.logger.info(f"Processed and alerted: {processed_count}")
            self.logger.info(f"Next check will start from: {to_time_str}")
            
        except Exception as e:
            self.logger.error(f"Error in check_and_alert: {e}", exc_info=True)
    
    def run(self):
        """
        Main service loop: continuously check and alert.
        """
        self.logger.info("="*60)
        self.logger.info("Starting Power Transmission Alert Service")
        self.logger.info(f"Check interval: {self.check_interval} seconds")
        self.logger.info(f"Recipients: {self.recipients}")
        self.logger.info(f"State file: {self.state_file}")
        self.logger.info(f"Monitored assets config: {self.monitored_assets_file}")
        self.logger.info("="*60)
        
        cycle_count = 0
        while True:
            try:
                cycle_count += 1
                self.logger.info(f"\n{'='*60}")
                self.logger.info(f"Starting check cycle #{cycle_count}")
                self.logger.info(f"{'='*60}")
                self.check_and_alert()
            except KeyboardInterrupt:
                self.logger.info("Service stopped by user (KeyboardInterrupt)")
                break
            except Exception as e:
                self.logger.error(f"Error in main loop (cycle #{cycle_count}): {e}", exc_info=True)
            
            self.logger.info(f"Sleeping for {self.check_interval} seconds until next check...")
            time.sleep(self.check_interval)


def main():
    """Entry point for the service."""
    service = TransmissionOutageAlertService()
    service.run()


if __name__ == "__main__":
    main()
