"""
Script to fetch BM Units reference data from Elexon BMRS API and save to Excel.
This creates a config file that can be used for filtering transmission alerts.

Usage:
    python fetch_bm_units.py
"""

import requests
import pandas as pd
from pathlib import Path
from datetime import datetime

# Configuration
API_URL = "https://data.elexon.co.uk/bmrs/api/v1/reference/bmunits/all"
OUTPUT_DIR = Path(__file__).parent.resolve()
OUTPUT_FILE = OUTPUT_DIR / "bm_units_reference.xlsx"

def fetch_bm_units():
    """
    Fetch BM Units data from Elexon API.
    
    Returns:
        list: List of BM unit dictionaries
    """
    print(f"Fetching BM Units from {API_URL}...")
    
    headers = {'accept': 'application/json'}
    
    try:
        response = requests.get(API_URL, headers=headers, timeout=60)
        response.raise_for_status()
        
        data = response.json()
        print(f"Successfully fetched {len(data)} BM units")
        return data
        
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data: {e}")
        return []

def save_to_excel(data, output_file):
    """
    Save BM Units data to Excel file.
    
    Args:
        data (list): List of BM unit dictionaries
        output_file (Path): Path to output Excel file
    """
    if not data:
        print("No data to save")
        return
    
    # Convert to DataFrame
    df = pd.DataFrame(data)
    
    # Add metadata
    metadata = pd.DataFrame([{
        'Fetch Date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'Total Records': len(df),
        'API URL': API_URL
    }])
    
    # Save to Excel with multiple sheets
    print(f"Saving to {output_file}...")
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # Main data sheet
        df.to_excel(writer, sheet_name='BM_Units', index=False)
        
        # Metadata sheet
        metadata.to_excel(writer, sheet_name='Metadata', index=False)
        
        # Summary by fuel type
        if 'fuelType' in df.columns:
            fuel_summary = df.groupby('fuelType').size().reset_index(name='Count')
            fuel_summary.to_excel(writer, sheet_name='Fuel_Type_Summary', index=False)
        
        # Summary by BM unit type
        if 'bmUnitType' in df.columns:
            type_summary = df.groupby('bmUnitType').size().reset_index(name='Count')
            type_summary.to_excel(writer, sheet_name='BM_Type_Summary', index=False)
    
    print(f"Successfully saved {len(df)} records to {output_file}")
    
    # Print some summary statistics
    print("\n=== Summary ===")
    print(f"Total BM Units: {len(df)}")
    if 'fuelType' in df.columns:
        print(f"\nTop 10 Fuel Types:")
        print(df['fuelType'].value_counts().head(10))
    if 'bmUnitType' in df.columns:
        print(f"\nBM Unit Types:")
        print(df['bmUnitType'].value_counts())

def main():
    """Main function to fetch and save BM Units data."""
    print("=== Elexon BM Units Reference Data Fetcher ===\n")
    
    # Fetch data
    data = fetch_bm_units()
    
    if not data:
        print("Failed to fetch data. Exiting.")
        return
    
    # Save to Excel
    save_to_excel(data, OUTPUT_FILE)
    
    print(f"\n=== Complete ===")
    print(f"Output file: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()

