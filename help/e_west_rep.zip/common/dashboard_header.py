"""Reusable email header linking to the interactive dashboard equivalent.

Reports are typically run as scripts from their own folder, so add the
eu_reports repo root to ``sys.path`` before importing::

    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from common.dashboard_header import dashboard_header_for

    body = dashboard_header_for("lng_vessels") + body

The banner reads::

    View interactive version of this report:
    Jain Global Commodities Dashboard | {page name} ->

To add a new report, register it in ``DASHBOARD_PAGES`` and call
``dashboard_header_for("<key>")``.  Or pass a path and label directly to
``dashboard_link_html``.
"""

from __future__ import annotations

DASHBOARD_BASE_URL = "http://10.115.0.70:8071"

# report key -> (dashboard path or full URL, page name shown in the banner)
DASHBOARD_PAGES: dict[str, tuple[str, str]] = {
    "lng_vessels": ("/power/lng/cargo_dod", "LNG Cargo DoD Changes"),
    "eu_gas_storage": ("/power/gas_balance/storage_summary", "EU Gas Storage Summary"),
    "morning_flows": ("/power/gas_balance/live_flows", "Live Flows"),
    "spreads_monitor": ("/gas/ttf_spreads", "TTF Spreads Monitor"),
    "lng_netbacks": ("/power/lng/netbacks", "LNG Netbacks"),
}

DASHBOARD_NAME = "Jain Global Commodities Dashboard"
_LINK = "#1565c0"
# Same declaration Mimecast uses on the EXTERNAL bar (which does render as
# Arial in this mail path). Outlook Word ignores font-family on a <div>
# and applies Times via Normal; a <span> with 10pt Arial sticks.
_BANNER_FONT = "font-size:10pt;font-family:Arial,sans-serif"


def dashboard_url(path_or_url: str) -> str:
    """Resolve a dashboard path against ``DASHBOARD_BASE_URL``."""
    if path_or_url.startswith(("http://", "https://")):
        return path_or_url
    return f"{DASHBOARD_BASE_URL.rstrip('/')}/{path_or_url.lstrip('/')}"


def dashboard_link_html(path_or_url: str, page_name: str) -> str:
    """Return the standard dashboard CTA for ``page_name``."""
    url = dashboard_url(path_or_url)
    # ASCII arrow only: the mail gateway sends charset=ks_c_5601-1987 and
    # turns &#8599; into mojibake.
    link_label = f"{DASHBOARD_NAME} | {page_name} -&gt;"
    return (
        f'<span style="{_BANNER_FONT};color:#333333;">'
        f"View interactive version of this report: "
        f'<a href="{url}" target="_blank" '
        f'style="{_BANNER_FONT};color:{_LINK};font-weight:bold;text-decoration:underline;">'
        f"{link_label}</a></span><br><br>"
    )


def dashboard_header_for(report_key: str) -> str:
    """Return the standard header for a registered report key."""
    try:
        path, page_name = DASHBOARD_PAGES[report_key]
    except KeyError as exc:
        known = ", ".join(sorted(DASHBOARD_PAGES))
        raise KeyError(
            f"Unknown dashboard header key {report_key!r}. Registered: {known}"
        ) from exc
    return dashboard_link_html(path, page_name)
