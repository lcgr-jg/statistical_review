"""Shared helpers and infrastructure for the EU email reports.

Two groups of things live here, added independently and kept apart on
purpose:

**Presentation helpers**, eagerly re-exported below because they are cheap
and every report wants them::

    dashboard_header_for, dashboard_link_html   common.dashboard_header
    df_to_styled_html, section_header_html      common.email_tables

**Market-mail infrastructure** for ``vol_monitor`` and ``ta_study``,
deliberately *not* imported here::

    bbg       Bloomberg daily history + intraday bars behind a Parquet cache
    deliver   kafka relay / Microsoft Graph / SMTP, with CID inline images
    persist   generic Snowflake DDL / MERGE / SELECT helpers
    corelib   locates the eu_corelib checkout that provides jain_commods

Those stay lazy (``from common import bbg``) so that importing ``common``
for a table helper never drags in blpapi, msal or the Snowflake connector -
which would make every report pay for a dependency it does not use, and
would break outright on a machine without a Bloomberg entitlement.

Everything here is config-agnostic: modules take plain arguments or
duck-typed settings protocols, never a pydantic model from a specific job,
so nothing in ``common`` has to change when a job adds a config field.
"""

from __future__ import annotations

from common.dashboard_header import dashboard_header_for, dashboard_link_html
from common.email_tables import (
    df_to_styled_html,
    section_block_html,
    section_header_html,
    side_by_side_html,
)

__all__ = [
    "dashboard_header_for",
    "dashboard_link_html",
    "df_to_styled_html",
    "section_block_html",
    "section_header_html",
    "side_by_side_html",
]

__version__ = "0.1.0"
