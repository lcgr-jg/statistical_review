"""Email delivery with CID inline images.

Three transports behind one ``send`` signature:

``graph``  Microsoft Graph ``POST /users/{sender}/sendMail`` with
           client-credentials auth via msal. The only transport that
           supports many inline images, so it is the default for any report
           that embeds charts.
``smtp``   ``multipart/related`` via ``EmailMessage``; also supports CID.
``kafka``  the in-house ``jain_commods`` mail relay every other eu_reports
           job uses. It carries one body plus at most one attachment and has
           no MIME multipart/related, so there is nowhere to put a CID part;
           inline images are instead rewritten into base64 ``data:`` URIs in
           the body, which is exactly what ``ccgt_power_stack`` and
           ``china_summary`` already do through the same relay.

Images are referenced from the HTML as ``<img src="cid:{content_id}">``.
Under Graph and SMTP those resolve to real inline parts, which is the more
robust encoding - Outlook desktop can be configured to block ``data:`` URIs,
and CID keeps the body small. The kafka path converts them at the last
moment (:func:`inline_as_data_uris`) so that callers build the HTML once and
do not care which transport it ends up on.

``--dry-run`` never reaches this module: the pipeline writes the HTML and
charts to disk and skips the send entirely.
"""

from __future__ import annotations

import base64
import importlib.util
import logging
import mimetypes
import os
import smtplib
from dataclasses import dataclass, field
from email.message import EmailMessage
from email.utils import make_msgid
from typing import Protocol, cast, runtime_checkable

log = logging.getLogger(__name__)

GRAPH_SCOPE = "https://graph.microsoft.com/.default"
GRAPH_ROOT = "https://graph.microsoft.com/v1.0"


@runtime_checkable
class DeliverySettings(Protocol):
    """What ``send`` needs from a job's delivery config.

    Declared as a protocol so ``common`` does not import any job's pydantic
    models; ``vol_monitor.config.DeliveryConfig`` and
    ``ta_study.config.DeliveryConfig`` both satisfy it structurally.
    """

    transport: str
    sender: str
    graph_tenant_id: str | None
    graph_client_id: str | None
    graph_client_secret_env: str
    smtp_host: str | None
    smtp_port: int
    smtp_use_tls: bool
    smtp_user: str | None
    smtp_password_env: str


@dataclass(frozen=True)
class Attachment:
    """A regular (non-inline) attachment."""

    filename: str
    content: bytes
    mime_type: str = "text/csv"

    @property
    def b64(self) -> str:
        return base64.b64encode(self.content).decode("ascii")

    @property
    def size(self) -> int:
        return len(self.content)


@dataclass(frozen=True)
class InlineImage:
    """An image embedded in the HTML body via ``cid:``.

    ``content_id`` is the bare id with no angle brackets - exactly what goes
    in ``<img src="cid:...">``. Use :func:`new_content_id` to mint one.
    """

    content_id: str
    filename: str
    content: bytes
    mime_type: str = "image/png"

    @property
    def b64(self) -> str:
        return base64.b64encode(self.content).decode("ascii")

    @property
    def size(self) -> int:
        return len(self.content)

    @property
    def src(self) -> str:
        return f"cid:{self.content_id}"


@dataclass
class SendResult:
    transport: str
    recipients: list[str] = field(default_factory=list)
    bytes_sent: int = 0
    inline_dropped: int = 0
    warnings: list[str] = field(default_factory=list)


class DeliveryError(RuntimeError):
    pass


def new_content_id(stem: str) -> str:
    """A domain-qualified, RFC-compliant Content-ID for ``stem``.

    ``make_msgid`` guarantees global uniqueness, which matters because some
    clients cache inline parts by id across messages.
    """
    safe = "".join(c if c.isalnum() else "-" for c in stem).strip("-").lower()
    return f"{safe}.{make_msgid()[1:-1]}"


def preflight(cfg: DeliverySettings) -> None:
    """Check the configured transport can actually run, and raise if not.

    Called *before* the expensive work. Without this, a misconfigured
    environment fetches every product's bars and renders every chart and only
    then dies on the send - which is exactly what
    ``conda activate corelib; py -m ta_study.cli run`` did, because the
    Windows ``py`` launcher ignores the conda env.
    """
    transport = cfg.transport

    if transport == "kafka":
        from common.corelib import ensure_corelib_on_path

        ensure_corelib_on_path()
        if importlib.util.find_spec("confluent_kafka") is None:
            msg = (
                "transport 'kafka' needs confluent_kafka, which is not importable "
                "under this interpreter. Use the 'corelib' env's python."
            )
            raise DeliveryError(msg)
        return

    if transport == "graph":
        missing = [
            name
            for name, value in (
                ("delivery.graph_tenant_id", cfg.graph_tenant_id),
                ("delivery.graph_client_id", cfg.graph_client_id),
                (f"${cfg.graph_client_secret_env}", os.environ.get(cfg.graph_client_secret_env)),
            )
            if not value
        ]
        # Graph falls back to SMTP, so an SMTP host makes the gaps survivable.
        if missing and not cfg.smtp_host:
            msg = (
                f"transport 'graph' is missing {', '.join(missing)} and there is no "
                "delivery.smtp_host to fall back on. Set the credentials, or use "
                "transport: kafka."
            )
            raise DeliveryError(msg)
        if importlib.util.find_spec("msal") is None and not cfg.smtp_host:
            msg = (
                "transport 'graph' needs msal (pip install -e \".[graph]\") and "
                "there is no delivery.smtp_host to fall back on."
            )
            raise DeliveryError(msg)
        return

    if not cfg.smtp_host:
        msg = "transport 'smtp' needs delivery.smtp_host"
        raise DeliveryError(msg)


def inline_as_data_uris(html: str, inline: list[InlineImage]) -> str:
    """Rewrite every ``cid:`` reference into a base64 ``data:`` URI.

    For transports with no MIME structure to hang an inline part on. Only
    ids that actually appear in the HTML are substituted, so an unreferenced
    image adds nothing to the body.
    """
    out = html
    for img in inline:
        out = out.replace(
            f"cid:{img.content_id}", f"data:{img.mime_type};base64,{img.b64}"
        )
    return out


def total_size(
    html: str,
    inline: list[InlineImage] | None = None,
    attachments: list[Attachment] | None = None,
) -> int:
    """On-the-wire size estimate, base64 overhead included.

    Used by callers to enforce a maximum message size *before* sending, so
    charts can be dropped deterministically rather than having the gateway
    reject the message.
    """
    raw = len(html.encode("utf-8"))
    for part in list(inline or []) + list(attachments or []):  # type: ignore[operator]
        # base64 inflates by 4/3; both Graph and SMTP encode attachments.
        raw += (part.size * 4) // 3
    return raw


def send(
    cfg: DeliverySettings,
    subject: str,
    html: str,
    recipients: list[str],
    inline: list[InlineImage] | None = None,
    attachments: list[Attachment] | None = None,
) -> SendResult:
    """Send the email, returning what was actually used."""
    if not recipients:
        msg = "no recipients configured"
        raise DeliveryError(msg)
    inline = list(inline or [])
    attachments = list(attachments or [])
    size = total_size(html, inline, attachments)

    if cfg.transport == "kafka":
        body = inline_as_data_uris(html, inline)
        size = total_size(body, [], attachments)
        _send_kafka(cfg, subject, body, recipients, attachments, size)
        result = SendResult("kafka", recipients, size)
        if len(attachments) > 1:
            result.warnings.append(
                f"kafka relay takes one attachment; {len(attachments) - 1} dropped"
            )
        return result

    if cfg.transport == "graph":
        try:
            _send_graph(cfg, subject, html, recipients, inline, attachments)
            return SendResult("graph", recipients, size)
        except Exception as exc:
            log.warning("Graph sendMail failed (%s); falling back to SMTP", exc)
            _send_smtp(cfg, subject, html, recipients, inline, attachments)
            result = SendResult("smtp (graph fallback)", recipients, size)
            result.warnings.append(f"Graph sendMail failed: {exc}")
            return result

    _send_smtp(cfg, subject, html, recipients, inline, attachments)
    return SendResult("smtp", recipients, size)


# ---------------------------------------------------------------------------
# transports
# ---------------------------------------------------------------------------
def _send_kafka(
    cfg: DeliverySettings,
    subject: str,
    html: str,
    recipients: list[str],
    attachments: list[Attachment],
    size_bytes: int = 0,
) -> None:
    """Queue the message on the in-house relay.

    ``html`` is expected to have had its ``cid:`` references already
    rewritten by :func:`inline_as_data_uris`. The producer's message limit is
    sized from the actual payload plus headroom for the JSON envelope,
    because the relay silently drops a message that exceeds it.
    """
    from common.corelib import ensure_corelib_on_path

    ensure_corelib_on_path()
    from jain_commods.core.util.emailhelper import send_email

    attachment: dict[str, str] = {}
    if attachments:
        first = attachments[0]
        attachment = {"filename": first.filename, "content": first.b64}

    # Round up to whole MB with 4 MB of slack; never below the relay default.
    limit_mb = max(15, int(size_bytes / 1024 / 1024) + 4)

    send_email(
        recipients=",".join(recipients),
        subject=subject,
        body=html,
        from_address=cfg.sender,
        attachment=attachment,
        mb_msg_size=limit_mb,
    )
    log.info(
        "queued email to %s via kafka relay (%.1f MB, limit %d MB)",
        recipients,
        size_bytes / 1024 / 1024,
        limit_mb,
    )


def _send_graph(
    cfg: DeliverySettings,
    subject: str,
    html: str,
    recipients: list[str],
    inline: list[InlineImage],
    attachments: list[Attachment],
) -> None:
    import msal
    import requests

    secret = os.environ.get(cfg.graph_client_secret_env)
    if not (cfg.graph_tenant_id and cfg.graph_client_id and secret):
        msg = (
            "Graph transport needs delivery.graph_tenant_id, "
            f"delivery.graph_client_id and ${cfg.graph_client_secret_env}"
        )
        raise DeliveryError(msg)

    app = msal.ConfidentialClientApplication(
        client_id=cfg.graph_client_id,
        authority=f"https://login.microsoftonline.com/{cfg.graph_tenant_id}",
        client_credential=secret,
    )
    token = app.acquire_token_for_client(scopes=[GRAPH_SCOPE])
    if "access_token" not in token:
        msg = f"Graph token request failed: {token.get('error_description', token)}"
        raise DeliveryError(msg)

    graph_attachments = [
        {
            "@odata.type": "#microsoft.graph.fileAttachment",
            "name": img.filename,
            "contentType": img.mime_type,
            "contentBytes": img.b64,
            # isInline + contentId is what makes cid: resolve in Outlook.
            "isInline": True,
            "contentId": img.content_id,
        }
        for img in inline
    ]
    graph_attachments += [
        {
            "@odata.type": "#microsoft.graph.fileAttachment",
            "name": a.filename,
            "contentType": a.mime_type,
            "contentBytes": a.b64,
        }
        for a in attachments
    ]

    payload = {
        "message": {
            "subject": subject,
            "body": {"contentType": "HTML", "content": html},
            "toRecipients": [{"emailAddress": {"address": r}} for r in recipients],
            "attachments": graph_attachments,
        },
        "saveToSentItems": True,
    }
    resp = requests.post(
        f"{GRAPH_ROOT}/users/{cfg.sender}/sendMail",
        headers={
            "Authorization": f"Bearer {token['access_token']}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=120,
    )
    if resp.status_code >= 300:
        msg = f"Graph sendMail returned {resp.status_code}: {resp.text[:500]}"
        raise DeliveryError(msg)
    log.info(
        "sent email to %s via Microsoft Graph (%d inline, %d attached)",
        recipients,
        len(inline),
        len(attachments),
    )


def _send_smtp(
    cfg: DeliverySettings,
    subject: str,
    html: str,
    recipients: list[str],
    inline: list[InlineImage],
    attachments: list[Attachment],
) -> None:
    if not cfg.smtp_host:
        msg = "SMTP transport needs delivery.smtp_host"
        raise DeliveryError(msg)

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = cfg.sender
    message["To"] = ", ".join(recipients)
    message.set_content("This report requires an HTML-capable mail client.")
    message.add_alternative(html, subtype="html")

    # Inline parts must live in a multipart/related alongside the HTML, which
    # is what add_related on the HTML sub-part builds.
    html_part = cast(EmailMessage, message.get_payload(-1))
    for img in inline:
        maintype, _, subtype = img.mime_type.partition("/")
        html_part.add_related(
            img.content,
            maintype=maintype or "image",
            subtype=subtype or "png",
            cid=f"<{img.content_id}>",
            filename=img.filename,
        )

    for a in attachments:
        maintype, _, subtype = a.mime_type.partition("/")
        if not maintype:
            guessed, _ = mimetypes.guess_type(a.filename)
            maintype, _, subtype = (guessed or "application/octet-stream").partition("/")
        message.add_attachment(
            a.content,
            maintype=maintype,
            subtype=subtype or "octet-stream",
            filename=a.filename,
        )

    with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=120) as server:
        if cfg.smtp_use_tls:
            server.starttls()
        if cfg.smtp_user:
            server.login(cfg.smtp_user, os.environ.get(cfg.smtp_password_env, ""))
        server.send_message(message)
    log.info("sent email to %s via SMTP %s", recipients, cfg.smtp_host)


def send_failure_alert(
    cfg: DeliverySettings,
    recipients: list[str],
    job: str,
    run_date: str,
    error: str,
) -> None:
    """Plain-text 'the job did not run' alert for terminal failures."""
    body = (
        f"<pre>{job} {run_date}: THE JOB DID NOT RUN.\n\n"
        f"{error}\n\n"
        "Treat yesterday's output as stale.</pre>"
    )
    try:
        send(cfg, f"{job} {run_date} - DID NOT RUN", body, recipients)
    except Exception as exc:
        log.error("could not send failure alert: %s", exc)
