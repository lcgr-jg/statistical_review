"""Outlook-safe HTML tables matching the EU Gas Storage Daily Storage Action look."""

from __future__ import annotations

import pandas as pd

# Inline on every cell: Outlook ignores font-family on a wrapping <table>
# and falls back to Times (same issue as the dashboard banner).
_FONT = "font-family:Arial,sans-serif;font-size:11px;"
# Outlook.com / Outlook mobile float sibling <table>s; these stop them collapsing.
_MSO = "mso-table-lspace:0pt;mso-table-rspace:0pt;"
_TABLE = f"border-collapse:collapse;{_MSO}{_FONT}"
_WRAP = (
    'role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"'
    f' style="border-collapse:collapse;{_MSO}"'
)
_HEADING_TD = (
    "padding:0 0 8px 0;font-size:14px;font-family:Arial,sans-serif;"
    "color:#2c3e50;border-bottom:1px solid #ddd;font-weight:bold;"
)
_TH = (
    f"padding:6px 8px;text-align:center;border:1px solid #2c3e50;"
    f"color:white;{_FONT}font-weight:bold;"
)
_TH_INDEX = (
    f"padding:6px 10px;text-align:left;border:1px solid #2c3e50;"
    f"color:white;{_FONT}font-weight:bold;"
)
_TD = f"padding:4px 8px;border-bottom:1px solid #eee;text-align:right;{_FONT}"
_TD_INDEX = (
    f"padding:4px 10px;border-bottom:1px solid #eee;white-space:nowrap;"
    f"text-align:left;{_FONT}"
)
_HEADER_ROW = "background-color:#2c3e50;color:white;"
_WEEKEND_BG = "#f0f4f8"


def _format_index(value, index_dt_format: str | None) -> str:
    if index_dt_format:
        ts = pd.to_datetime(value, errors="coerce", dayfirst=True)
        if not pd.isna(ts):
            return ts.strftime(index_dt_format)
    return str(value)


def _is_weekend(value) -> bool:
    ts = pd.to_datetime(value, errors="coerce", dayfirst=True)
    if pd.isna(ts):
        return False
    return int(ts.dayofweek) >= 5


def _format_value(val, precision: int) -> str:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return ""
    if isinstance(val, str):
        return val
    try:
        if pd.isna(val):
            return ""
    except (TypeError, ValueError):
        pass
    try:
        num = float(val)
    except (TypeError, ValueError):
        return str(val)
    if precision == 0:
        return f"{num:,.0f}"
    return f"{num:,.{precision}f}"


def _delta_color(val) -> str | None:
    """Green/red for signed deltas; None if not a signed number."""
    if val is None:
        return None
    text = str(val).replace(",", "").strip()
    if not text or text in {"", "-"}:
        return None
    try:
        num = float(text)
    except ValueError:
        return None
    if num > 0:
        return "#27ae60"
    if num < 0:
        return "#e74c3c"
    return "#333"


def _cell_highlighted(highlight_cells: pd.DataFrame | None, idx, col) -> bool:
    if highlight_cells is None or highlight_cells.empty:
        return False
    try:
        return bool(highlight_cells.loc[idx, col])
    except (KeyError, TypeError, ValueError):
        return False


def _is_delta_column(name) -> bool:
    label = str(name)
    if isinstance(name, tuple):
        label = str(name[-1])
    return label.startswith("vs ") or "Delta" in label or label.startswith("Δ")


def df_to_styled_html(
    df: pd.DataFrame,
    *,
    precision: int = 0,
    highlight_weekends: bool = False,
    index_header: str | None = None,
    index_dt_format: str | None = None,
    bold_columns: tuple[str, ...] = ("Total",),
    highlight_cells: pd.DataFrame | None = None,
    highlight_color: str = "#9a6700",
    highlight_bg: str = "#fff4d6",
) -> str:
    """Render *df* as an HTML table in Daily Storage Action style."""
    if index_header is None:
        index_header = df.index.name or ""

    html = [
        f'<table cellpadding="0" cellspacing="0" border="0" style="{_TABLE}">',
        "<thead>",
    ]

    if isinstance(df.columns, pd.MultiIndex) and df.columns.nlevels == 2:
        html.append(f'  <tr style="{_HEADER_ROW}">')
        html.append(
            f'    <th rowspan="2" style="{_TH_INDEX}">{index_header}</th>'
        )
        top_vals = list(df.columns.get_level_values(0))
        i = 0
        while i < len(top_vals):
            val = top_vals[i]
            span = 1
            while i + span < len(top_vals) and top_vals[i + span] == val:
                span += 1
            html.append(f'    <th colspan="{span}" style="{_TH}">{val}</th>')
            i += span
        html.append("  </tr>")
        html.append(f'  <tr style="{_HEADER_ROW}">')
        for col in df.columns:
            html.append(f'    <th style="{_TH}">{col[1]}</th>')
        html.append("  </tr>")
        col_labels = list(df.columns)
    else:
        html.append(f'  <tr style="{_HEADER_ROW}">')
        html.append(f'    <th style="{_TH_INDEX}">{index_header}</th>')
        for col in df.columns:
            html.append(f'    <th style="{_TH}">{col}</th>')
        html.append("  </tr>")
        col_labels = list(df.columns)

    html.append("</thead><tbody>")

    for idx, row in df.iterrows():
        bg = _WEEKEND_BG if highlight_weekends and _is_weekend(idx) else "white"
        html.append(f'  <tr style="background-color:{bg};">')
        html.append(f'    <td style="{_TD_INDEX}">{_format_index(idx, index_dt_format)}</td>')
        for col in col_labels:
            val = row[col]
            text = _format_value(val, precision)
            weight = "bold" if str(col[-1] if isinstance(col, tuple) else col) in bold_columns else "normal"
            extra = f"font-weight:{weight};"
            if _is_delta_column(col):
                color = _delta_color(val)
                if color:
                    extra += f"color:{color};font-weight:bold;"
            if _cell_highlighted(highlight_cells, idx, col):
                extra += f"color:{highlight_color};background-color:{highlight_bg};font-weight:bold;"
            html.append(f'    <td style="{_TD}{extra}">{text}</td>')
        html.append("  </tr>")

    html.append("</tbody></table>")
    return "\n".join(html)


def _spacer_row(height_px: int) -> str:
    """Height on a <td> is respected by Outlook; CSS margin on <h3> is not."""
    if height_px <= 0:
        return ""
    return (
        f'<tr><td height="{height_px}" style="height:{height_px}px;line-height:{height_px}px;'
        f'font-size:{height_px}px;mso-line-height-rule:exactly;">&nbsp;</td></tr>'
    )


def section_header_html(title: str, *, first: bool = False) -> str:
    """Section title matching EU Gas Storage report headings.

    Outlook mobile ignores CSS margin on headings and floats consecutive
    tables, so spacing is an explicit spacer row in a 100% wrapper table.
    """
    top = 0 if first else 20
    return (
        f"<table {_WRAP}>"
        f"{_spacer_row(top)}"
        f'<tr><td style="{_HEADING_TD}">{title}</td></tr>'
        "</table>"
    )


def section_block_html(title: str, body: str, *, first: bool = False) -> str:
    """Heading plus body in one full-width table so Outlook cannot overlay sections."""
    top = 0 if first else 20
    return (
        f"<table {_WRAP}>"
        f"{_spacer_row(top)}"
        f'<tr><td style="{_HEADING_TD}">{title}</td></tr>'
        f'<tr><td style="padding:0;">{body}</td></tr>'
        "</table>"
    )


def side_by_side_html(*tables: str, gap_px: int = 15) -> str:
    """Place tables in adjacent cells with a spacer column Outlook will honour."""
    parts: list[str] = []
    for i, table in enumerate(tables):
        if i:
            parts.append(
                f'<td width="{gap_px}" style="width:{gap_px}px;font-size:{gap_px}px;'
                f'line-height:{gap_px}px;">&nbsp;</td>'
            )
        parts.append(f'<td valign="top" style="vertical-align:top;padding:0;">{table}</td>')
    return (
        f'<table role="presentation" cellpadding="0" cellspacing="0" border="0" '
        f'style="border-collapse:collapse;{_MSO}">'
        f'<tr>{"".join(parts)}</tr></table>'
    )
