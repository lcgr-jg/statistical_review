"""Generic Snowflake helpers: DDL, MERGE, SELECT.

Table-agnostic on purpose. A job declares its tables as :class:`TableSpec`
objects and hands rows over as dicts; this module builds the MERGE, runs it
in batches and never raises on a persistence problem - the desk needs the
email more than it needs the table.

Column names are validated against a strict identifier pattern before being
interpolated into SQL, because Snowflake's Python connector only
parameterises values, not identifiers.
"""

from __future__ import annotations

import contextlib
import json
import logging
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)

#: Snowflake unquoted identifiers. Anything else is rejected rather than
#: interpolated - the column lists come from code, so a mismatch is a bug,
#: not user input.
_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")

#: Rows per MERGE round-trip.
DEFAULT_BATCH = 200


def _ident(name: str) -> str:
    if not _IDENT.match(name):
        msg = f"unsafe SQL identifier: {name!r}"
        raise ValueError(msg)
    return name.upper()


@dataclass(frozen=True)
class TableSpec:
    """One table a job owns.

    ``columns`` maps column name -> Snowflake type, in DDL order.
    ``keys`` are the MERGE match columns and must all appear in ``columns``.
    ``variant_columns`` are written with ``PARSE_JSON`` and accept a dict or
    list on the Python side.
    """

    name: str
    columns: dict[str, str]
    keys: tuple[str, ...]
    variant_columns: tuple[str, ...] = ()
    cluster_by: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for col in self.columns:
            _ident(col)
        missing = [k for k in self.keys if k not in self.columns]
        if missing:
            msg = f"{self.name}: key columns not in columns: {missing}"
            raise ValueError(msg)
        unknown = [c for c in self.variant_columns if c not in self.columns]
        if unknown:
            msg = f"{self.name}: variant columns not in columns: {unknown}"
            raise ValueError(msg)

    def ddl(self, fq: str) -> str:
        cols = ",\n    ".join(
            f"{_ident(name)} {sql_type}" for name, sql_type in self.columns.items()
        )
        pk = ", ".join(_ident(k) for k in self.keys)
        stmt = f"CREATE TABLE IF NOT EXISTS {fq} (\n    {cols},\n    PRIMARY KEY ({pk})\n)"
        if self.cluster_by:
            stmt += " CLUSTER BY (" + ", ".join(_ident(c) for c in self.cluster_by) + ")"
        return stmt


@dataclass
class PersistReport:
    """What persistence managed to do, for the run log."""

    rows_written: dict[str, int] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def fail(self, msg: str) -> None:
        log.warning(msg)
        self.errors.append(msg)

    @property
    def ok(self) -> bool:
        return not self.errors


@dataclass(frozen=True)
class SnowflakeSettings:
    """Connection coordinates. Plain dataclass so ``common`` stays
    independent of any job's pydantic config; jobs build one from theirs."""

    database: str
    schema: str
    role: str
    warehouse: str
    enabled: bool = True


class SnowflakeStore:
    """Thin writer/reader over the in-house ``SnowFlake`` connector."""

    def __init__(self, settings: SnowflakeSettings) -> None:
        self.settings = settings
        self._conn: Any = None

    # -- connection -----------------------------------------------------
    def connection(self) -> Any:
        if self._conn is None:
            from common.corelib import ensure_corelib_on_path

            ensure_corelib_on_path()
            from jain_commods.core.interfaces.snowflake import SnowFlake

            sf = SnowFlake(
                database=self.settings.database,
                schema=self.settings.schema,
                role=self.settings.role,
                warehouse=self.settings.warehouse,
            )
            self._conn = sf._conn
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            with contextlib.suppress(Exception):
                self._conn.close()
            self._conn = None

    def fq(self, table: str) -> str:
        return (
            f"{_ident(self.settings.database)}."
            f"{_ident(self.settings.schema)}."
            f"{_ident(table)}"
        )

    # -- DDL ------------------------------------------------------------
    def ensure_schema(self) -> None:
        cur = self.connection().cursor()
        try:
            cur.execute(
                f"CREATE SCHEMA IF NOT EXISTS "
                f"{_ident(self.settings.database)}.{_ident(self.settings.schema)}"
            )
        finally:
            cur.close()

    def ensure_tables(self, specs: Sequence[TableSpec]) -> None:
        self.ensure_schema()
        cur = self.connection().cursor()
        try:
            for spec in specs:
                cur.execute(spec.ddl(self.fq(spec.name)))
        finally:
            cur.close()

    # -- writes ---------------------------------------------------------
    def merge(
        self,
        spec: TableSpec,
        rows: Sequence[dict[str, Any]],
        batch: int = DEFAULT_BATCH,
    ) -> int:
        """MERGE ``rows`` on ``spec.keys``. Returns rows sent.

        Every row must supply every key column; non-key columns default to
        NULL when absent, so a partially-populated row is legal.
        """
        if not rows:
            return 0

        sql = self._merge_sql(spec)
        payloads = [self._payload(spec, row) for row in rows]

        cur = self.connection().cursor()
        sent = 0
        try:
            for i in range(0, len(payloads), batch):
                chunk = payloads[i : i + batch]
                cur.executemany(sql, chunk)
                sent += len(chunk)
        finally:
            cur.close()
        return sent

    def _merge_sql(self, spec: TableSpec) -> str:
        cols = list(spec.columns)
        source_terms = []
        for col in cols:
            if col in spec.variant_columns:
                source_terms.append(f"PARSE_JSON(%({col})s) AS {_ident(col)}")
            else:
                source_terms.append(f"%({col})s AS {_ident(col)}")
        select = ",\n                   ".join(source_terms)

        on = " AND ".join(f"t.{_ident(k)} = s.{_ident(k)}" for k in spec.keys)
        updates = ",\n            ".join(
            f"{_ident(c)} = s.{_ident(c)}" for c in cols if c not in spec.keys
        )
        insert_cols = ", ".join(_ident(c) for c in cols)
        insert_vals = ", ".join(f"s.{_ident(c)}" for c in cols)

        matched = (
            f"WHEN MATCHED THEN UPDATE SET\n            {updates}\n        "
            if updates
            else ""
        )
        return f"""
        MERGE INTO {self.fq(spec.name)} t
        USING (
            SELECT {select}
        ) s
        ON {on}
        {matched}WHEN NOT MATCHED THEN INSERT
            ({insert_cols})
            VALUES ({insert_vals})
        """

    @staticmethod
    def _payload(spec: TableSpec, row: dict[str, Any]) -> dict[str, Any]:
        missing = [k for k in spec.keys if row.get(k) is None]
        if missing:
            msg = f"{spec.name}: row is missing key column(s) {missing}"
            raise ValueError(msg)
        out: dict[str, Any] = {}
        for col in spec.columns:
            value = row.get(col)
            if col in spec.variant_columns:
                out[col] = json.dumps(value) if value is not None else None
            elif isinstance(value, bool):
                out[col] = value
            else:
                out[col] = value
        return out

    # -- reads ----------------------------------------------------------
    def select(
        self, sql: str, params: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        """Run ``sql`` and return rows as dicts keyed by upper-case column."""
        cur = self.connection().cursor()
        try:
            cur.execute(sql, params or {})
            names = [d[0] for d in cur.description]
            return [dict(zip(names, row, strict=True)) for row in cur.fetchall()]
        finally:
            cur.close()

    def execute(self, sql: str, params: dict[str, Any] | None = None) -> None:
        cur = self.connection().cursor()
        try:
            cur.execute(sql, params or {})
        finally:
            cur.close()


class Persistence:
    """Fail-soft façade: every method logs and records rather than raising.

    ``enabled=False``, an unreachable warehouse or a missing grant all
    degrade to "nothing written", which callers surface in the email footer.
    """

    def __init__(self, settings: SnowflakeSettings, specs: Sequence[TableSpec]) -> None:
        self.settings = settings
        self.specs = {spec.name: spec for spec in specs}
        self.report = PersistReport()
        self._store: SnowflakeStore | None = None
        self._tables_ready = False

    @property
    def enabled(self) -> bool:
        return self.settings.enabled

    @property
    def store(self) -> SnowflakeStore | None:
        if not self.settings.enabled:
            return None
        if self._store is None:
            try:
                store = SnowflakeStore(self.settings)
                store.ensure_tables(list(self.specs.values()))
                self._store = store
                self._tables_ready = True
            except Exception as exc:
                self.report.fail(f"Snowflake unavailable, not persisting: {exc}")
                self.settings = SnowflakeSettings(
                    database=self.settings.database,
                    schema=self.settings.schema,
                    role=self.settings.role,
                    warehouse=self.settings.warehouse,
                    enabled=False,
                )
                return None
        return self._store

    def write(self, table: str, rows: Sequence[dict[str, Any]]) -> int:
        spec = self.specs.get(table)
        if spec is None:
            self.report.fail(f"unknown table {table!r}")
            return 0
        store = self.store
        if store is None:
            log.info("persistence disabled - skipping %s write (%d rows)", table, len(rows))
            return 0
        try:
            n = store.merge(spec, rows)
        except Exception as exc:
            self.report.fail(f"could not write {table}: {exc}")
            return 0
        self.report.rows_written[table] = self.report.rows_written.get(table, 0) + n
        log.info("merged %d rows into %s", n, table)
        return n

    def read(self, sql: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        store = self.store
        if store is None:
            return []
        try:
            return store.select(sql, params)
        except Exception as exc:
            self.report.fail(f"query failed: {exc}")
            return []

    def fq(self, table: str) -> str:
        """Fully-qualified name, usable even when persistence is disabled."""
        return (
            f"{self.settings.database.upper()}."
            f"{self.settings.schema.upper()}."
            f"{table.upper()}"
        )

    def close(self) -> None:
        if self._store is not None:
            self._store.close()
