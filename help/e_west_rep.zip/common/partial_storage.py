"""Site-level storage fallback when a CE country total is not published yet.

Commodity Essentials publishes a level-1 country aggregate only once every
underlying storage site has reported. A country is often missing for the latest
day or two while most level-2 sites already have a value. This module sums
those sites for missing days in the last week so the storage table can show a
partial total and mark it as incomplete.

Kept in step with ``eu_dashboard_power/core/gas_data_ce/partial_storage.py``.
"""
from __future__ import annotations

import logging

import pandas as pd

logger = logging.getLogger(__name__)

# Level-1 country storage assets shown in the morning flows table.
REPORT_STORAGE_ASSET_IDS: dict[str, int] = {
    "AT": 1768,
    "BE": 677,
    "DE": 688,
    "FR": 458,
    "GB": 468,
    "IT": 1780,
    "NL": 477,
}

SITE_LEVEL = 2
LOOKBACK_DAYS = 7
# CE ``nd`` is a day count. A short pad keeps the latest gas day inside the pull.
SITE_QUERY_PAD_DAYS = 2

PARTIAL_CELL_COLOR = "#9a6700"
PARTIAL_CELL_BG = "#fff4d6"
PARTIAL_STORAGE_NOTE = (
    "Amber = partial: sites reported so far, not the full country total. Included in Total."
)


def recent_missing_days(country: pd.Series, lookback_days: int = LOOKBACK_DAYS) -> pd.DatetimeIndex:
    """Normalised dates in the recent window where *country* has no value."""
    if country is None or len(country) == 0:
        return pd.DatetimeIndex([])
    parsed = _naive_days(country.index)
    if len(parsed) == 0 or parsed.isna().all():
        return pd.DatetimeIndex([])
    cutoff = parsed.max() - pd.Timedelta(days=int(lookback_days) - 1)
    values = pd.to_numeric(pd.Series(country.to_numpy()), errors="coerce")
    mask = values.isna().to_numpy() & (parsed >= cutoff)
    return pd.DatetimeIndex(parsed[mask]).unique().sort_values()


def level2_storage_signs(
    assets: pd.DataFrame,
    tree: pd.DataFrame,
    parent_id: int,
) -> dict[int, float]:
    """Map level-2 storage asset id → tree sign for direct children of *parent_id*."""
    if assets is None or tree is None or assets.empty or tree.empty:
        return {}
    parents = pd.to_numeric(tree["parent_id"], errors="coerce")
    child_ids = pd.to_numeric(tree["child_id"], errors="coerce")
    direct = tree.loc[parents == int(parent_id)].copy()
    if direct.empty:
        return {}
    direct["_child"] = child_ids.loc[direct.index].to_numpy()
    meta = assets.copy()
    meta["_id"] = pd.to_numeric(meta["assetId"], errors="coerce")
    merged = direct.merge(meta, left_on="_child", right_on="_id", how="inner")
    level = pd.to_numeric(merged["level"], errors="coerce")
    keep = (merged["type"] == "Storage") & (level == SITE_LEVEL)
    signs: dict[int, float] = {}
    for _, row in merged.loc[keep].iterrows():
        signs[int(row["_id"])] = float(row["sign"])
    return signs


def sum_signed_site_frame(
    raw: pd.DataFrame,
    meta: pd.DataFrame,
    signs: dict[int, float],
) -> pd.Series:
    """Daily sum of site columns, applying asset-tree signs. All-missing days stay NaN."""
    if raw is None or raw.empty or meta is None or meta.empty or not signs:
        return pd.Series(dtype=float)
    labelled = _signed_site_columns(raw, meta, {i: ("_", sign) for i, sign in signs.items()})
    parts = labelled.get("_", [])
    if not parts:
        return pd.Series(dtype=float)
    summed = pd.concat(parts, axis=1).sum(axis=1, min_count=1)
    summed.index = _naive_days(raw["Date"])
    summed = summed.groupby(level=0).sum(min_count=1)
    summed.index = pd.DatetimeIndex(summed.index).normalize()
    return summed.sort_index()


def fetch_partial_storage_injection(
    ce,
    injection: pd.DataFrame,
    *,
    asset_ids: dict[str, int],
    unit: str = "mcm",
    lookback_days: int = LOOKBACK_DAYS,
) -> pd.DataFrame:
    """
    Level-2 site sums for recent days where a country total is missing.

    Returns a frame indexed by normalised date, with one column per country
    that was filled. Empty when every country total in *asset_ids* is already
    present, or when no underlying site has reported.
    """
    gaps = _recent_gaps(injection, asset_ids, lookback_days)
    if not gaps:
        return pd.DataFrame()

    assets = ce.eugasmeta("assets")
    tree = ce.eugasmeta("assettree")
    signs_by_asset: dict[int, tuple[str, float]] = {}
    for country in gaps:
        for asset_id, sign in level2_storage_signs(assets, tree, asset_ids[country]).items():
            signs_by_asset.setdefault(asset_id, (country, sign))
    if not signs_by_asset:
        logger.warning(
            "No level-2 storage sites for %s",
            ", ".join(sorted(gaps)),
        )
        return pd.DataFrame()

    ids = ",".join(str(i) for i in sorted(signs_by_asset))
    nd = int(lookback_days) + SITE_QUERY_PAD_DAYS
    logger.info(
        "Country storage totals missing (%s); querying %d level-2 sites",
        ", ".join(f"{country}:{len(days)}d" for country, days in gaps.items()),
        len(signs_by_asset),
    )
    raw = ce.eugasopdata(assets=ids, unit=unit, variable="netInjection", nd=nd)
    meta = ce.eugasopdata(assets=ids, unit=unit, variable="netInjection", meta=True)
    by_country = _sum_sites_by_country(raw, meta, signs_by_asset)

    columns: dict[str, pd.Series] = {}
    for country, missing in gaps.items():
        if country not in by_country.columns:
            continue
        filled = by_country[country].reindex(missing).dropna()
        if not filled.empty:
            columns[country] = filled
    if not columns:
        return pd.DataFrame()
    return pd.DataFrame(columns).sort_index()


def apply_partial_storage(
    frame: pd.DataFrame,
    partial: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Write *partial* into missing country cells.

    Official (non-null) values are left unchanged. Returns a boolean frame on
    *frame*'s index, True where a country cell was filled from sites.
    """
    countries = [c for c in frame.columns if c != "Total"]
    mask = pd.DataFrame(False, index=frame.index, columns=countries)
    if (
        frame is None
        or frame.empty
        or partial is None
        or not isinstance(partial, pd.DataFrame)
        or partial.empty
    ):
        return mask

    parsed = _naive_days(frame.index)
    for country in partial.columns:
        if country not in frame.columns:
            continue
        site = pd.to_numeric(partial[country], errors="coerce").copy()
        site.index = _naive_days(site.index)
        site = site[~site.index.duplicated(keep="last")]
        incoming = site.reindex(parsed)
        current = pd.to_numeric(frame[country], errors="coerce")
        cell_mask = current.isna().to_numpy() & incoming.notna().to_numpy()
        if not bool(cell_mask.any()):
            continue
        updated = current.mask(cell_mask, incoming.to_numpy())
        frame[country] = updated.to_numpy()
        mask.loc[mask.index[cell_mask], country] = True
    return mask


def _recent_gaps(
    injection: pd.DataFrame,
    asset_ids: dict[str, int],
    lookback_days: int,
) -> dict[str, pd.DatetimeIndex]:
    if injection is None or injection.empty:
        return {}
    gaps: dict[str, pd.DatetimeIndex] = {}
    for country in asset_ids:
        if country not in injection.columns:
            continue
        missing = recent_missing_days(injection[country], lookback_days)
        if len(missing):
            gaps[country] = missing
    return gaps


def _sum_sites_by_country(
    raw: pd.DataFrame,
    meta: pd.DataFrame,
    signs_by_asset: dict[int, tuple[str, float]],
) -> pd.DataFrame:
    labelled = _signed_site_columns(raw, meta, signs_by_asset)
    if not labelled or raw is None or "Date" not in raw.columns:
        return pd.DataFrame()
    dates = _naive_days(raw["Date"])
    columns: dict[str, pd.Series] = {}
    for country, parts in labelled.items():
        summed = pd.concat(parts, axis=1).sum(axis=1, min_count=1)
        summed.index = dates
        summed = summed.groupby(level=0).sum(min_count=1)
        columns[country] = summed
    out = pd.DataFrame(columns)
    out.index = pd.DatetimeIndex(out.index).normalize()
    return out.sort_index()


def _signed_site_columns(
    raw: pd.DataFrame,
    meta: pd.DataFrame,
    signs_by_asset: dict[int, tuple[str, float]],
) -> dict[str, list[pd.Series]]:
    if raw is None or raw.empty or meta is None or meta.empty or not signs_by_asset:
        return {}
    asset_rows = meta.loc[meta["seriesId"] == "assetId"]
    if asset_rows.empty:
        return {}
    asset_row = asset_rows.iloc[0]
    labelled: dict[str, list[pd.Series]] = {}
    for col in raw.columns:
        if col in ("Date", "DateExcel"):
            continue
        asset_id = _meta_asset_id(asset_row, col)
        if asset_id is None or asset_id not in signs_by_asset:
            continue
        country, sign = signs_by_asset[asset_id]
        values = pd.to_numeric(raw[col], errors="coerce") * sign
        labelled.setdefault(country, []).append(values)
    return labelled


def _naive_days(index) -> pd.DatetimeIndex:
    parsed = pd.DatetimeIndex(pd.to_datetime(index, format="mixed"))
    if parsed.tz is not None:
        parsed = parsed.tz_convert(None)
    return parsed.normalize()


def _meta_asset_id(asset_row: pd.Series, col) -> int | None:
    keys: list = [col, str(col)]
    try:
        keys.append(int(col))
    except (TypeError, ValueError):
        pass
    for key in keys:
        if key not in asset_row.index:
            continue
        try:
            return int(asset_row[key])
        except (TypeError, ValueError):
            return None
    return None
