"""Locate the local ``eu_corelib`` checkout that provides ``jain_commods``.

``jain_commods`` is installed editable in the ``corelib`` conda env, so an
import just works there. It does not work under any other interpreter - and
the Windows ``py`` launcher ignores ``conda activate`` entirely, so
``conda activate corelib; py -m ta_study.cli run`` silently runs on the
system Python and fails at the first ``jain_commods`` import, after the bars
and charts have already been produced.

Every other job in this repo solves it with a hard-coded
``sys.path.insert`` at the top of the module. This does the same thing
without the hard-coded user name, and only when the import would otherwise
fail:

1. if ``jain_commods`` already imports, do nothing,
2. else try ``$LOCAL_EU_CORELIB_PATH`` (already set in the pipelines
   ``.env``),
3. else try the sibling ``../eu_corelib`` next to this repo.

Called lazily, at the point of use, so importing ``common`` stays free of
side effects.
"""

from __future__ import annotations

import importlib.util
import logging
import os
import sys
from pathlib import Path

log = logging.getLogger(__name__)

#: Environment variable the pipelines repo already uses for this.
CORELIB_PATH_ENV = "LOCAL_EU_CORELIB_PATH"

#: Sibling directory name to fall back on.
CORELIB_DIR_NAME = "eu_corelib"


def corelib_candidates() -> list[Path]:
    """Places ``eu_corelib`` might live, in priority order."""
    out: list[Path] = []
    configured = os.environ.get(CORELIB_PATH_ENV)
    if configured:
        out.append(Path(configured))
    # This file is <repo>/common/corelib.py, so parents[1] is the repo root
    # and parents[2] the Projects directory holding both checkouts.
    out.append(Path(__file__).resolve().parents[2] / CORELIB_DIR_NAME)
    return out


def jain_commods_available() -> bool:
    try:
        return importlib.util.find_spec("jain_commods") is not None
    except (ImportError, ValueError):
        return False


def ensure_corelib_on_path() -> Path | None:
    """Make ``jain_commods`` importable; return the path added, if any.

    Raises :class:`ModuleNotFoundError` with an actionable message when the
    checkout cannot be found, rather than letting an opaque
    ``No module named 'jain_commods'`` surface from deep inside a transport.
    """
    if jain_commods_available():
        return None

    for candidate in corelib_candidates():
        if not (candidate / "jain_commods").is_dir():
            continue
        path = str(candidate)
        if path not in sys.path:
            sys.path.insert(0, path)
            log.info("added local eu_corelib to sys.path: %s", path)
        if jain_commods_available():
            return candidate

    tried = ", ".join(str(c) for c in corelib_candidates())
    msg = (
        "jain_commods is not importable. It is installed in the 'corelib' conda "
        "env; note that the Windows 'py' launcher ignores 'conda activate', so "
        "use 'python -m ta_study.cli ...' (or the env's python.exe by full "
        f"path) rather than 'py -m ...'. Alternatively set ${CORELIB_PATH_ENV} "
        f"to the eu_corelib checkout. Tried: {tried}"
    )
    raise ModuleNotFoundError(msg)
