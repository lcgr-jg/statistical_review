"""Bloomberg data access (blpapi via B-PIPE) with a local Parquet cache.

Two request types, both routed through ``jain_commods`` ``BBGQuery``:

``fetch_history``   ``HistoricalDataRequest`` - daily bars and any other
                    daily field, returned as a tidy frame keyed by ``date``.
``fetch_intraday``  ``IntradayBarRequest`` - OHLCV bars at a minute interval,
                    returned keyed by ``ts``. Bloomberg returns bar times in
                    GMT and only retains roughly 140 days of intraday
                    history, so callers are expected to persist what they
                    fetch and build history forward.

The cache is keyed by (ticker, field-set / interval, start, end) so reruns
and backfills do not re-hit Bloomberg. Anything the terminal does not return
comes back as an empty frame with a recorded warning rather than an
exception - one bad ticker must never kill a run.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path

import polars as pl

log = logging.getLogger(__name__)

#: Daily OHLCV + roll-tracking fields. ``FUT_CUR_GEN_TICKER`` names the
#: contract a generic ticker is currently pointing at, which is how roll
#: bars are detected.
DAILY_BAR_FIELDS: tuple[str, ...] = (
    "PX_OPEN",
    "PX_HIGH",
    "PX_LOW",
    "PX_LAST",
    "PX_VOLUME",
    "FUT_CUR_GEN_TICKER",
)

#: Bloomberg field -> bar column.
DAILY_FIELD_TO_COL: dict[str, str] = {
    "PX_OPEN": "open",
    "PX_HIGH": "high",
    "PX_LOW": "low",
    "PX_LAST": "close",
    "PX_VOLUME": "volume",
    "OPEN_INT": "oi",
    "FUT_CUR_GEN_TICKER": "gen_ticker",
}

#: Bloomberg's documented intraday retention for B-PIPE. Requests reaching
#: further back come back empty rather than erroring, so this is used to
#: clamp the request window and to explain gaps in the run log.
INTRADAY_RETENTION_DAYS = 140


@dataclass
class FetchReport:
    """What the data layer managed to get, for the run log and email footer."""

    latency_s: float = 0.0
    warnings: list[str] = field(default_factory=list)
    cache_hits: int = 0
    cache_misses: int = 0
    requests: int = 0

    def warn(self, msg: str) -> None:
        log.warning(msg)
        self.warnings.append(msg)


class BloombergClient:
    """Thin caching wrapper over ``jain_commods`` ``BBGQuery``.

    The blpapi session is opened lazily on first use so that importing this
    module - or running a job with ``use_cache`` against a warm cache - never
    requires a terminal or B-PIPE entitlement.
    """

    def __init__(
        self,
        cache_dir: str | Path,
        on_server: bool = True,
        use_cache: bool = True,
    ) -> None:
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.on_server = on_server
        self.use_cache = use_cache
        self._session = None
        self.report = FetchReport()

    # -- session --------------------------------------------------------
    @property
    def session(self):  # type: ignore[no-untyped-def]
        if self._session is None:
            from common.corelib import ensure_corelib_on_path

            ensure_corelib_on_path()
            from jain_commods.core.interfaces.bloomberg import BBGQuery

            log.info("opening Bloomberg session (on_server=%s)", self.on_server)
            self._session = BBGQuery(p_on_server=self.on_server)
        return self._session

    # -- cache ----------------------------------------------------------
    def _cache_path(self, kind: str, ticker: str, key_parts: str) -> Path:
        key = f"{kind}|{ticker}|{key_parts}"
        digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]
        safe = "".join(c if c.isalnum() else "_" for c in ticker)[:24]
        return self.cache_dir / f"{kind}_{safe}_{digest}.parquet"

    # -- daily ----------------------------------------------------------
    def fetch_history(
        self,
        ticker: str,
        fields: tuple[str, ...],
        start: dt.date,
        end: dt.date,
    ) -> pl.DataFrame:
        """Daily history for one ticker. Empty frame (not an error) on failure.

        Output columns: ``date`` plus one column per requested field, using
        the raw Bloomberg field names.
        """
        path = self._cache_path(
            "hist", ticker, f"{','.join(fields)}|{start:%Y%m%d}|{end:%Y%m%d}"
        )
        if self.use_cache and path.exists():
            self.report.cache_hits += 1
            log.debug("cache hit %s", path.name)
            return pl.read_parquet(path)

        self.report.cache_misses += 1
        self.report.requests += 1
        t0 = time.perf_counter()
        try:
            raw = self.session.fetch_hist(
                ticker,
                list(fields),
                p_start=dt.datetime.combine(start, dt.time()),
                p_end=dt.datetime.combine(end, dt.time()),
            )
        except Exception as exc:
            self.report.warn(f"{ticker}: HistoricalDataRequest failed ({exc})")
            return pl.DataFrame()
        finally:
            self.report.latency_s += time.perf_counter() - t0

        df = _from_hist_frame(raw, ticker, fields)
        if df.is_empty():
            self.report.warn(f"{ticker}: Bloomberg returned no rows for {list(fields)}")
            return df

        if self.use_cache:
            df.write_parquet(path)
        return df

    def fetch_daily_bars(
        self,
        ticker: str,
        start: dt.date,
        end: dt.date,
        fields: tuple[str, ...] = DAILY_BAR_FIELDS,
    ) -> pl.DataFrame:
        """:meth:`fetch_history` renamed to bar columns and typed.

        Output columns: ``date, open, high, low, close, volume, gen_ticker``.
        Missing OHLC columns fall back to ``close`` so that true-range based
        indicators degrade to ``|C - C_prev|`` instead of vanishing.
        """
        raw = self.fetch_history(ticker, fields, start, end)
        if raw.is_empty():
            return pl.DataFrame()

        df = raw.rename({k: v for k, v in DAILY_FIELD_TO_COL.items() if k in raw.columns})
        for col in ("open", "high", "low", "close", "volume"):
            if col not in df.columns:
                df = df.with_columns(pl.lit(None, dtype=pl.Float64).alias(col))
            else:
                df = df.with_columns(pl.col(col).cast(pl.Float64))
        if "gen_ticker" not in df.columns:
            df = df.with_columns(pl.lit(None, dtype=pl.Utf8).alias("gen_ticker"))
        else:
            df = df.with_columns(pl.col("gen_ticker").cast(pl.Utf8))

        if df.get_column("close").null_count() == df.height:
            self.report.warn(f"{ticker}: PX_LAST is entirely null")
            return pl.DataFrame()

        for col in ("open", "high", "low"):
            if df.get_column(col).null_count() == df.height:
                self.report.warn(
                    f"{ticker}: no {col.upper()} history; falling back to PX_LAST "
                    "(true range degrades to |C - C_prev|)"
                )
                df = df.with_columns(pl.col("close").alias(col))

        keep = ["date", "open", "high", "low", "close", "volume", "gen_ticker"]
        return df.select([c for c in keep if c in df.columns]).sort("date")

    # -- intraday -------------------------------------------------------
    def fetch_intraday(
        self,
        ticker: str,
        start: dt.datetime,
        end: dt.datetime,
        interval_min: int = 60,
        event_type: str = "TRADE",
        gap_fill: bool = True,
    ) -> pl.DataFrame:
        """Intraday OHLCV bars for one ticker, keyed by ``ts`` (GMT).

        Output columns: ``ts, open, high, low, close, volume``. Empty frame
        on failure or when the window falls outside Bloomberg's retention.
        """
        path = self._cache_path(
            "intra",
            ticker,
            f"{interval_min}|{event_type}|{start:%Y%m%dT%H%M}|{end:%Y%m%dT%H%M}",
        )
        if self.use_cache and path.exists():
            self.report.cache_hits += 1
            return pl.read_parquet(path)

        self.report.cache_misses += 1
        self.report.requests += 1
        t0 = time.perf_counter()
        try:
            raw = self.session.fetch_intraday_bars(
                ticker,
                p_start=start,
                p_end=end,
                p_event_type=event_type,
                p_interval_min=interval_min,
                p_gap_fill=gap_fill,
            )
        except Exception as exc:
            self.report.warn(f"{ticker}: IntradayBarRequest failed ({exc})")
            return pl.DataFrame()
        finally:
            self.report.latency_s += time.perf_counter() - t0

        df = _from_intraday_frame(raw)
        if df.is_empty():
            self.report.warn(
                f"{ticker}: no {interval_min}m bars for "
                f"{start:%Y-%m-%d} to {end:%Y-%m-%d} "
                f"(Bloomberg retains ~{INTRADAY_RETENTION_DAYS} days)"
            )
            return df

        if self.use_cache:
            df.write_parquet(path)
        return df

    # -- snapshot -------------------------------------------------------
    def fetch_snapshot(self, tickers: list[str], fields: list[str]) -> pl.DataFrame:
        """BDP snapshot - the fallback when a field has no history."""
        self.report.requests += 1
        try:
            raw = self.session.fetch_live(tickers=tickers, fields=fields)
        except Exception as exc:
            self.report.warn(f"snapshot failed for {tickers}: {exc}")
            return pl.DataFrame()
        if raw is None or raw.empty:
            return pl.DataFrame()
        out = raw.reset_index().rename(columns={"index": "ticker"})
        return pl.from_pandas(out)


# ---------------------------------------------------------------------------
# pandas -> polars adapters
# ---------------------------------------------------------------------------
def _from_hist_frame(raw, ticker: str, fields: tuple[str, ...]) -> pl.DataFrame:  # type: ignore[no-untyped-def]
    """Convert ``BBGQuery.fetch_hist`` output (pandas, ``{ticker}_{field}``
    columns, date index) to a tidy polars frame keyed by ``date``."""
    if raw is None or raw.empty:
        return pl.DataFrame()

    pdf = raw.copy()
    pdf.index.name = "date"
    pdf = pdf.reset_index()
    rename = {f"{ticker}_{f}": f for f in fields if f"{ticker}_{f}" in pdf.columns}
    pdf = pdf.rename(columns=rename)
    keep = ["date"] + [f for f in fields if f in pdf.columns]
    pdf = pdf[keep]

    df = pl.from_pandas(pdf)
    return df.with_columns(pl.col("date").cast(pl.Date)).sort("date")


def _from_intraday_frame(raw) -> pl.DataFrame:  # type: ignore[no-untyped-def]
    """Convert ``BBGQuery.fetch_intraday_bars`` output (pandas, bar-time
    index, OHLCV + numEvents + value) to ``ts, open, high, low, close, volume``."""
    if raw is None or raw.empty:
        return pl.DataFrame()

    pdf = raw.copy()
    pdf.index.name = "ts"
    pdf = pdf.reset_index()
    keep = [c for c in ("ts", "open", "high", "low", "close", "volume") if c in pdf.columns]
    pdf = pdf[keep]

    df = pl.from_pandas(pdf)
    df = df.with_columns(pl.col("ts").cast(pl.Datetime("us")))
    for col in ("open", "high", "low", "close", "volume"):
        if col in df.columns:
            df = df.with_columns(pl.col(col).cast(pl.Float64))
    return df.sort("ts").unique(subset=["ts"], keep="last", maintain_order=True)
