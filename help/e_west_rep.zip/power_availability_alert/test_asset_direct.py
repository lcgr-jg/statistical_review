"""
Direct test of the power_availability_alert asset

This script simulates how Dagster would call the asset,
allowing you to test the asset logic directly.

Usage:
    python test_asset_direct.py
"""

import sys
from pathlib import Path
from datetime import datetime
from unittest.mock import Mock, MagicMock, patch

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the asset function directly
# Note: This will only work if dagster_defs is importable
# In Dagster, the asset is defined in the code location
try:
    from dagster_defs import power_availability_alert, power_availability_alert_history
except ImportError:
    print("Warning: Could not import from dagster_defs. This test requires Dagster to be set up.")
    print("Try running from the eu_reports directory or with proper Python path.")
    sys.exit(1)

# Set up logging
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Create a mock Dagster context
class MockAssetContext:
    """Mock AssetExecutionContext for testing."""
    def __init__(self):
        self.log = logging.getLogger(__name__)
        self.run_id = "test_run_123"
        self.asset_key = Mock()
        self.asset_key.path = ["power_availability_alert"]


def test_asset_direct():
    """Test the asset function directly."""
    print("=" * 80)
    print("Testing power_availability_alert Asset Directly")
    print("=" * 80)
    print()
    
    # Create mock context
    context = MockAssetContext()
    
    print("[1/3] Testing asset execution...")
    try:
        # Mock the service initialization
        with patch('dagster_defs.DagsterPowerAvailabilityService') as mock_service_class:
            # Create a mock service instance
            mock_service = MagicMock()
            mock_service.check_and_alert.return_value = {
                "alerts_sent": 1,
                "teams_alerts_sent": 0,
                "aggregates_checked": 6,
                "units_checked": 10,
                "curves_with_changes": 2,
                "alert_details": ["DE Nuclear: -500 MW", "FR Gas: +200 MW"],
                "teams_breaches": [],
                "timing": {"total": 2.5, "discovery": 0.3, "calc": 1.2},
            }
            mock_service_class.return_value = mock_service
            
            # Call the asset
            result = power_availability_alert(context)
            
            print(f"  ✓ Asset executed successfully")
            print(f"  - Alerts sent: {result.get('alerts_sent', 0)}")
            print(f"  - Aggregates checked: {result.get('aggregates_checked', 0)}")
            print(f"  - Units checked: {result.get('units_checked', 0)}")
            print()
            
            # Test alert history asset
            print("[2/3] Testing alert history asset...")
            try:
                history_result = power_availability_alert_history(result, context)
                print(f"  ✓ Alert history asset executed")
                print(f"  - Materialized at: {history_result.get('materialized_at', 'N/A')}")
                print()
            except Exception as e:
                print(f"  ✗ Alert history asset failed: {e}")
                import traceback
                traceback.print_exc()
                return False
            
            print("[3/3] Verifying results...")
            print(f"  ✓ Main asset returned: {type(result)}")
            print(f"  ✓ Alert history returned: {type(history_result)}")
            print()
            
            return True
            
    except Exception as e:
        print(f"  ✗ Asset execution failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    try:
        success = test_asset_direct()
        if success:
            print("=" * 80)
            print("✓ Test passed!")
            print("=" * 80)
            sys.exit(0)
        else:
            print("=" * 80)
            print("✗ Test failed")
            print("=" * 80)
            sys.exit(1)
    except Exception as e:
        print(f"\n✗ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

