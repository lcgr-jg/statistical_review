"""
Persistent alert state and a run lock.

All state lives in ONE json file written atomically (temp file + rename), so
there is no cursor/cache pair that can drift out of sync, and a crash mid-write
leaves the previous state intact.

Location: ``$POWER_AVAILABILITY_STATE_DIR`` if set, else ``./cache`` next to
this module. In a container that directory must be on a persistent volume,
otherwise every redeploy starts from scratch (the next alert then re-lists the
day's changes, and says so in a banner).
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

SCHEMA_VERSION = 2
STATE_FILE = "alert_state.json"
LOCK_FILE = "alert_state.lock"


def default_state_dir() -> Path:
    configured = os.environ.get("POWER_AVAILABILITY_STATE_DIR")
    return Path(configured) if configured else Path(__file__).parent / "cache"


def empty_state() -> dict:
    return {
        "schema": SCHEMA_VERSION,
        "business_day": None,        # UK date (iso) the per-unit baselines belong to
        "baseline_close": None,      # iso: previous business day 17:00 UK
        "state_rebuilt": False,      # True when today's state had to be rebuilt mid-day
        "last_email_at": None,
        "last_email_signature": None,
        "last_teams_signature": None,
        "groups": {},                # "FR|Nuclear" -> {"agg_fp", "recheck_until"}
        "units": {},                 # curve -> {"alerted_blocks", "alerted_at", "alerted_issued",
                                     #           "current_blocks", "current_issued", "group"}
    }


class StateStore:
    def __init__(self, state_dir: Path | None = None):
        self.dir = Path(state_dir) if state_dir else default_state_dir()
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / STATE_FILE

    def load(self) -> dict:
        """Return saved state, or a fresh one (``_loaded=False``) if missing/unreadable."""
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            if data.get("schema") == SCHEMA_VERSION:
                data["_loaded"] = True
                return data
        except (OSError, ValueError):
            pass
        data = empty_state()
        data["_loaded"] = False
        return data

    def save(self, data: dict) -> None:
        payload = {k: v for k, v in data.items() if not k.startswith("_")}
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, default=str)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.path)


class LockHeld(RuntimeError):
    pass


class RunLock:
    """
    Exclusive lock file so two overlapping runs can never both send the same
    alert. A lock older than ``stale_after_s`` is assumed abandoned (crashed run).
    """

    def __init__(self, state_dir: Path, stale_after_s: int = 20 * 60):
        self.path = Path(state_dir) / LOCK_FILE
        self.stale_after_s = stale_after_s
        self._held = False

    def __enter__(self):
        for _ in range(2):
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, f"{os.getpid()} {time.time()}".encode())
                os.close(fd)
                self._held = True
                return self
            except FileExistsError as exists:
                try:
                    age = time.time() - self.path.stat().st_mtime
                except FileNotFoundError:
                    continue
                if age < self.stale_after_s:
                    raise LockHeld(f"another run holds {self.path} ({age:.0f}s old)") from exists
                self.path.unlink(missing_ok=True)
        raise LockHeld(f"could not acquire {self.path}")

    def __exit__(self, *exc):
        if self._held:
            self.path.unlink(missing_ok=True)
            self._held = False
        return False
