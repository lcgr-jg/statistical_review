> **Superseded (Sep 2026).** State handling and change detection were rewritten: one atomic state file (`state.py`, `$POWER_AVAILABILITY_STATE_DIR`), exact REMIT-period diffs (`diff.py`), no Dagster cursor, no market-close freeze, and changes are only marked as alerted after a send succeeds. The authoritative description is the docstring at the top of `power_availability_alert.py`; tests are `python -m pytest power_availability_alert/tests`. Sections below on cursors, `StateCache`, fingerprints and the market-close freeze describe the old design.

# Power Availability REMIT Alert System - Complete Architecture Map

## Table of Contents
1. [System Overview](#system-overview)
2. [Component Architecture](#component-architecture)
3. [Data Flow Diagram](#data-flow-diagram)
4. [State Management](#state-management)
5. [Alert Triggering Logic](#alert-triggering-logic)
6. [Key Decision Points](#key-decision-points)

---

## System Overview

**Purpose**: Monitor REMIT power plant capacity changes and send alerts when significant changes are detected compared to the previous business day close.

**Schedule**: Runs every 5 minutes during business hours (07:00-17:00 UK, Mon-Fri)

**Architecture Pattern**: Sensor + Asset (Event-driven polling with historical tracking)

---

## Component Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    DAGSTER ORCHESTRATION                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  power_availability_sensor (Sensor)                     │  │
│  │  - Evaluates every 5 minutes                            │  │
│  │  - Business hours check (07:00-17:00 UK, Mon-Fri)       │  │
│  │  - Triggers: power_availability_alert_history_job       │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          │                                       │
│                          │ RunRequest (when alerts sent)        │
│                          ▼                                       │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  power_availability_alert_history_job (Job)              │  │
│  │  - Materializes: power_availability_alert_history        │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          │                                       │
│                          │ Materializes                          │
│                          ▼                                       │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  power_availability_alert_history (Asset)                │  │
│  │  - Stores alert metadata                                 │  │
│  │  - Visible in Dagster UI asset graph                     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
                          │
                          │ Uses
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│              POWER AVAILABILITY ALERT SERVICE                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  DagsterPowerAvailabilityService                         │  │
│  │  - Subclass of PowerAvailabilityAlertService             │  │
│  │  - Uses Dagster context for logging                     │  │
│  │  - Manages hybrid state (cursor + cache file)           │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          │                                       │
│                          │ Inherits                              │
│                          ▼                                       │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  PowerAvailabilityAlertService (Core Logic)              │  │
│  │  - Curve discovery                                        │  │
│  │  - Data fetching                                          │  │
│  │  - Delta calculation                                      │  │
│  │  - Alert building                                         │  │
│  │  - Email/Teams sending                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
                          │
                          │ Uses
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    STATE MANAGEMENT                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Dagster Cursor (Lightweight State)                     │  │
│  │  - Fingerprints (hashes of capacity profiles)          │  │
│  │  - Timestamps (last_check_time, last_alert_time)        │  │
│  │  - Cache version (validates cursor/cache sync)         │  │
│  │  - Market close state (frozen flag, close time)        │  │
│  │  - Last alert run_key (prevents duplicate triggers)   │  │
│  │  Size: ~32KB (scales to 1000+ units)                   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Local Cache File (Heavy State)                        │  │
│  │  Path: cache/state_cache.json                           │  │
│  │  - prev_bd_blocks: Previous business day capacity       │  │
│  │  - alerted_blocks: Last alerted capacity (incremental)│  │
│  │  - Version hash (validates with cursor)                │  │
│  │  Size: ~500KB (scales to 1000+ units)                  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
                          │
                          │ Uses
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    EXTERNAL SERVICES                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Energy Quantified (EQ) API                              │  │
│  │  - REMIT curve data (period-based instances)            │  │
│  │  - Aggregate curves (per country/fuel)                   │  │
│  │  - Individual plant curves                               │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Email Service (Kafka)                                  │  │
│  │  - jain_commods.core.util.emailhelper.send_email        │  │
│  │  - HTML email with heatmap + detailed table             │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Teams Webhook                                           │  │
│  │  - Microsoft Teams channel notifications                 │  │
│  │  - Threshold breach alerts                               │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagram

### Complete Alert Cycle Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 1: SENSOR EVALUATION                                          │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              │ Every 5 minutes
                              ▼
                    ┌─────────────────────┐
                    │ Business Hours?      │
                    │ (07:00-17:00 UK)     │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  NO │                   │ YES
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ SkipReason    │   │ Load Hybrid State    │
            │ (Outside hrs) │   │ - Cursor (fingerprints)│
            └───────────────┘   │ - Cache (blocks)     │
                              └──────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 2: STATE LOADING                                              │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Load Cursor State    │
                    │ - Fingerprints       │
                    │ - Timestamps         │
                    │ - Cache version      │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Load Cache File     │
                    │ - prev_bd_blocks    │
                    │ - alerted_blocks    │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Validate Versions   │
                    │ (cursor vs cache)   │
                    └─────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 3: BUSINESS DAY CHECK                                         │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ New Business Day?    │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  YES│                   │ NO
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Clear         │   │ Continue with        │
            │ alerted_blocks│   │ existing state       │
            │ Reset         │   │                      │
            │ fingerprints  │   │                      │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 4: MARKET CLOSE/OPEN LOGIC                                    │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Market Close?       │
                    │ (>= 17:00 UK)       │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  YES│                   │ NO
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Freeze State  │   │ Market Open?         │
            │ - Set flag    │   │ (>= 07:00 UK +       │
            │ - Record time │   │  frozen state)       │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
                    ┌─────────────────────┐
                    │ Use Frozen State    │
                    │ as Baseline         │
                    └─────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 5: AGGREGATE-FIRST OPTIMIZATION                               │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ For each            │
                    │ Country/Fuel:        │
                    │ 1. Fetch Aggregate  │
                    │ 2. Compute Fingerprint│
                    │ 3. Compare vs Baseline│
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Aggregate Changed?  │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  NO │                   │ YES
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Skip Units    │   │ Fetch Individual     │
            │ (No change)   │   │ Plant Curves         │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 6: INDIVIDUAL PLANT PROCESSING                                │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ For each Plant:     │
                    │ 1. Fetch Current    │
                    │ 2. Compute Fingerprint│
                    │ 3. Compare vs Baseline│
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Changes Detected?   │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  NO │                   │ YES
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Skip          │   │ Calculate Deltas     │
            │               │   │ - Convert to Hourly  │
            │               │   │ - Compare DataFrames │
            │               │   │ - Extract Blocks    │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
                    ┌─────────────────────┐
                    │ Filter Changes      │
                    │ - Remove past hours │
                    │ - Min duration      │
                    └─────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 7: TENOR-BASED FILTERING                                      │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Aggregate Changes   │
                    │ by Tenor            │
                    │ (D+1, Week+1, etc.) │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Calculate Avg Delta │
                    │ per Tenor           │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Check Tenor         │
                    │ Thresholds          │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Significant Tenors? │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  NO │                   │ YES
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Skip Alert    │   │ Filter Changes       │
            │               │   │ (only significant)   │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 8: TEAMS THRESHOLD CHECK                                       │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Build Heatmap       │
                    │ (Tenor x Country/Fuel)│
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Check Teams         │
                    │ Thresholds          │
                    │ (per country/fuel/tenor)│
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Breaches Found?     │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  YES│                   │ NO
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Send Teams    │   │ Continue             │
            │ Alert         │   │                      │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 9: EMAIL COOLDOWN CHECK                                        │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Check Global        │
                    │ Cooldown            │
                    │ (default: 60 min)   │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Cooldown Active?    │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  YES│                   │ NO
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Skip Email    │   │ Build Email          │
            │ (keep changes │   │ - Heatmap Table      │
            │  for next)    │   │ - Detailed Table     │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
                    ┌─────────────────────┐
                    │ Send Email          │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Email Sent?         │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  YES│                   │ NO
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Update State  │   │ Don't Update         │
            │ - alerted_blocks│   │ (changes appear next)│
            │ - last_alert_time│   │                      │
            │ - fingerprints │   │                      │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 10: ASSET TRIGGERING                                           │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Alerts Sent?       │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  YES│                   │ NO
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ Generate      │   │ Return SkipReason    │
            │ RunRequest    │   │                      │
            │ - run_key     │   │                      │
            │ - run_config  │   │                      │
            │ - tags        │   │                      │
            └───────────────┘   └──────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Check Duplicate     │
                    │ run_key?            │
                    └─────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  YES│                   │ NO
                    │                   │
                    ▼                   ▼
            ┌───────────────┐   ┌──────────────────────┐
            │ SkipReason    │   │ Save State           │
            │ (duplicate)   │   │ - Store run_key     │
            └───────────────┘   └──────────────────────┘
                                          │
                                          ▼
                    ┌─────────────────────┐
                    │ Return RunRequest   │
                    │ (triggers job)      │
                    └─────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ STEP 11: ASSET MATERIALIZATION                                      │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Dagster Executes    │
                    │ Alert History Job   │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Asset Reads         │
                    │ op_config           │
                    │ (alert metadata)    │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Store Alert History │
                    │ - Timestamp         │
                    │ - Breaches          │
                    │ - Changes count     │
                    │ - Timing metrics    │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │ Asset Materialized  │
                    │ (visible in UI)     │
                    └─────────────────────┘
```

---

## State Management

### Hybrid State Persistence

**Why Hybrid?**
- Dagster cursor has size limits (~32KB)
- Block data (periods with start/end/mw) is large (~500KB for 1000+ units)
- Need both: fingerprints for fast duplicate detection + blocks for delta calculation

### Cursor State (Lightweight)
```json
{
  "last_check_time": "2026-01-09T12:00:00+00:00",
  "last_alert_time": "2026-01-09T11:30:00+00:00",
  "last_alert_run_key": "alert_2026-01-09T11-30-00_abc12345",
  "current_business_day": "2026-01-09",
  "cache_version": "62311b338e44",
  "market_close_state_frozen": false,
  "last_market_close_time": "2026-01-08T17:00:00+00:00",
  "curves": {
    "DE @Brokdorf Nuclear...": {
      "prev_bd_fingerprint": "abc123...",
      "alerted_fingerprint": "def456...",
      "market_close_fingerprint": "ghi789...",
      "alerted_at": "2026-01-09T11:30:00+00:00"
    }
  }
}
```

### Cache File State (Heavy)
```json
{
  "version": "62311b338e44",
  "updated_at": "2026-01-09T12:00:00+00:00",
  "curves": {
    "DE @Brokdorf Nuclear...": {
      "prev_bd_blocks": [
        {"start": "2026-01-09T00:00:00+01:00", "end": "2026-01-10T00:00:00+01:00", "mw": 1410},
        {"start": "2026-01-10T00:00:00+01:00", "end": "2026-01-11T00:00:00+01:00", "mw": 1410}
      ],
      "alerted_blocks": [
        {"start": "2026-01-09T00:00:00+01:00", "end": "2026-01-10T00:00:00+01:00", "mw": 0},
        {"start": "2026-01-10T00:00:00+01:00", "end": "2026-01-11T00:00:00+01:00", "mw": 0}
      ]
    }
  }
}
```

### State Lifecycle

1. **First Run of Day**:
   - Load `prev_bd_blocks` from cache
   - Compare current vs `prev_bd_blocks` (baseline)
   - If changes → send alert → update `alerted_blocks`

2. **Subsequent Runs**:
   - Compare current vs `alerted_blocks` (incremental)
   - Only show NEW changes since last alert
   - If changes → send alert → update `alerted_blocks`

3. **Market Close (17:00 UK)**:
   - Freeze `alerted_blocks` (don't update after this)
   - Set `market_close_state_frozen = true`
   - Record `last_market_close_time`

4. **Market Open (07:00 UK)**:
   - Use frozen `alerted_blocks` as baseline
   - Compare current vs frozen state
   - Capture all overnight changes in one alert
   - After first alert → unfreeze state → resume incremental

5. **Business Day Rollover**:
   - Clear `alerted_blocks` (keep `prev_bd_blocks`)
   - Reset fingerprints
   - Next run compares vs `prev_bd_blocks` (new baseline)

---

## Alert Triggering Logic

### Duplicate Prevention (3 Layers)

1. **Fingerprint Check** (Per Curve):
   ```
   current_fingerprint == alerted_fingerprint → Skip (no change)
   ```

2. **Global Cooldown** (Per Alert):
   ```
   time_since_last_alert < cooldown_minutes → Skip (too soon)
   ```

3. **Run Key Check** (Per Asset Trigger):
   ```
   last_alert_run_key == current_run_key → Skip (duplicate trigger)
   ```

### Alert Conditions

**Email Alert Sent When**:
- ✅ Changes detected (fingerprint differs)
- ✅ Significant tenors found (avg delta > threshold)
- ✅ Cooldown expired (or first alert)
- ✅ Email sent successfully

**Teams Alert Sent When**:
- ✅ Heatmap built
- ✅ Threshold breach detected (country/fuel/tenor)
- ✅ Independent of email cooldown

**Asset Triggered When**:
- ✅ Email or Teams alert sent
- ✅ Job provided to sensor
- ✅ Unique run_key (not duplicate)

---

## Key Decision Points

### 1. Baseline Selection
```
IF market_close_state_frozen:
    baseline = frozen alerted_blocks (from 17:00 UK yesterday)
ELSE IF alerted_blocks exists:
    baseline = alerted_blocks (incremental comparison)
ELSE:
    baseline = prev_bd_blocks (first run of day)
```

### 2. Aggregate-First Optimization
```
FOR each country/fuel:
    IF aggregate_fingerprint == baseline_fingerprint:
        SKIP individual plants (no change)
    ELSE:
        FETCH and PROCESS individual plants
```

### 3. Tenor Filtering
```
1. Calculate avg_delta per tenor (D+1, Week+1, Month+1, etc.)
2. Check if avg_delta > threshold for that tenor
3. IF any tenor significant:
    FILTER changes to only those contributing to significant tenors
    SEND alert
ELSE:
    SKIP alert (no significant impact)
```

### 4. Cooldown Behavior
```
IF cooldown_active:
    SKIP email alert
    KEEP changes in state (don't update alerted_blocks)
    NEXT alert will include both blocked + new changes
ELSE:
    SEND email alert
    UPDATE alerted_blocks
    UPDATE last_alert_time
```

### 5. State Update Timing
```
ONLY update alerted_blocks AFTER:
    - Email sent successfully
    - NOT if cooldown blocked it
    - NOT if no significant tenors

This ensures:
    - Blocked changes appear in next alert
    - alerted_blocks always = "what we've alerted about"
```

---

## Configuration

### monitored_curves.json

**Countries**: DE, FR, GB, ES, NL, BE, CH, HU, BG, RO, CZ, SE3, FI

**Fuel Types**: Nuclear, Natural Gas, Hard Coal, Lignite

**Tenor Thresholds**:
- Daily (D+1-D+5/Weekends): 500 MW avg
- Weekly (Week+1-3): 100 MW avg
- Monthly (M+1-12): 250 MW avg

**Cooldown**: 60 minutes (prevents duplicate emails)

**Teams Thresholds**: Per country/fuel/tenor_type (inversely proportional to tenor length and fuel load factor)

---

## Data Structures

### CapacityChange
```python
@dataclass
class CapacityChange:
    curve_name: str          # "FR @Chinon-4 Nuclear..."
    plant_name: str          # "Chinon-4"
    country: str             # "FR"
    fuel_type: str           # "Nuclear"
    period_start: datetime   # Start of outage block
    period_end: datetime     # End of outage block
    prev_capacity_mw: float  # Previous capacity (avg)
    current_capacity_mw: float # Current capacity (avg)
    delta_mw: float          # Change (current - prev)
    issued_at: datetime      # When detected
```

### Block Format (Compact Storage)
```python
{
    "start": "2026-01-09T00:00:00+01:00",  # ISO format
    "end": "2026-01-10T00:00:00+01:00",    # ISO format
    "mw": 1410.0                            # Capacity in MW
}
```

---

## Error Handling

1. **EQ API Failures**: Logged, continue with other curves
2. **Email Send Failures**: Logged, state NOT updated (retry next run)
3. **Cache Corruption**: Version mismatch → clear cache, fresh start
4. **State Persistence Failures**: Logged, continue with in-memory state

---

## Performance Characteristics

- **Aggregate Checks**: ~6 curves (countries × fuels)
- **Individual Checks**: Only when aggregate changed (~10-50 per run)
- **API Calls**: Optimized (aggregate-first reduces calls by ~90%)
- **State Size**: ~32KB cursor + ~500KB cache (scales to 1000+ units)
- **Execution Time**: ~1-5 seconds per check cycle

---

## Testing Scenarios

1. **First Run**: Compares vs prev_bd_blocks, sends alert, updates state
2. **Incremental Run**: Compares vs alerted_blocks, shows only new changes
3. **Cooldown Active**: Skips email, keeps changes, next alert includes both
4. **Market Close**: Freezes state, stops updating alerted_blocks
5. **Market Open**: Uses frozen state, captures overnight changes
6. **Business Day Rollover**: Clears alerted_blocks, resets to prev_bd baseline
7. **Duplicate Prevention**: Fingerprint + cooldown + run_key checks
8. **Multi-Day Failure**: First run after recovery shows cumulative changes

---

## Summary

The system uses a **Sensor + Asset** pattern with **hybrid state persistence** to:
- Monitor REMIT power plant capacity changes
- Send incremental alerts (only new changes)
- Prevent duplicates (fingerprint + cooldown + run_key)
- Optimize API calls (aggregate-first)
- Track alert history (asset materialization)
- Handle edge cases (market close/open, business day rollover, failures)

The architecture scales to 1000+ units while maintaining fast duplicate detection and accurate incremental alerts.

