"""
Power Availability REMIT Alert Service

Polls Energy Quantified REMIT capacity curves (per country x fuel) and alerts
the desk by email / Teams when available capacity changes materially.

How a change is decided
-----------------------
Every unit carries two states in the persisted state file:

* ``alerted_blocks`` - what the desk has already been told. At the start of a
  business day this is the REMIT state as of the previous business day's
  17:00 UK close; after each alert it becomes the state that was sent.
* ``current_blocks`` - the latest REMIT state seen (only kept while it differs).

Each poll the pending change for a unit is ``current - alerted`` (exact REMIT
periods, future only). Pending changes are summed per country/fuel into tenor
averages; a group is alerted when any tenor crosses its threshold. Nothing is
marked as "told" until an alert has actually been sent, so changes held back
by the threshold or the email cooldown accumulate and go out later instead of
being dropped, and a sent change is never sent again.

Aggregate curves are only used to decide which country/fuel groups to re-scan.
After an aggregate moves, its units are re-scanned for a grace window because
EQ can publish a unit a poll after its aggregate.

Run window: 07:00-17:10 UK, Mon-Fri. Runs at/after 17:00 read REMIT as of
17:00 exactly - the same snapshot the next day's baseline uses - so nothing
published just before the close falls into a gap.

Author: Michael Kane
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from datetime import time as dtime
from html import escape
from pathlib import Path
from typing import Any

from power_availability_alert.diff import (
    Segment,
    blocks_fingerprint,
    diff_blocks,
    periodseries_to_blocks,
    tenor_average_delta,
)
from power_availability_alert.state import LockHeld, RunLock, StateStore

try:
    from dotenv import load_dotenv
    _env_file = Path(__file__).parent / ".env"
    if _env_file.exists():
        load_dotenv(_env_file, override=True)
except ImportError:
    pass

try:
    from energyquantified import EnergyQuantified
    from energyquantified.exceptions import NotFoundError
    from energyquantified.metadata import Area, CurveType, DataType
    EQ_AVAILABLE = True
except ImportError:
    EQ_AVAILABLE = False

    class NotFoundError(Exception):  # type: ignore[no-redef]
        pass

try:
    from jain_commods.core.util.emailhelper import send_email
except ImportError:
    def send_email(*args, **kwargs):
        print(f"Mock Email Sent: {kwargs.get('subject')}")

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from zoneinfo import ZoneInfo

CET = ZoneInfo("Europe/Berlin")
UK_TZ = ZoneInfo("Europe/London")

MARKET_OPEN_UK = dtime(7, 0)
MARKET_CLOSE_UK = dtime(17, 0)
#: Runs until 17:10 so the last poll reads the full 17:00 snapshot.
RUN_WINDOW_END_UK = dtime(17, 10)

#: EQ exact_category per configured fuel. Group fuel names must match the
#: Teams threshold config ("Hard Coal", not "Coal").
FUEL_CATEGORIES = {
    "Nuclear": "Nuclear Capacity Available",
    "Natural Gas": "Natural Gas Power Capacity Available",
    "Hard Coal": "Hard Coal Power Capacity Available",
    "Coal": "Hard Coal Power Capacity Available",
    "Lignite": "Lignite Power Capacity Available",
    "Hydro": "Hydro Capacity Available",
}

FUEL_COLORS = {
    "Nuclear": "#FFE5E5",
    "Natural Gas": "#FFF3E0",
    "Hard Coal": "#F0F0F0",
    "Coal": "#F0F0F0",
    "Lignite": "#EFEBE9",
    "Hydro": "#E3F2FD",
}

#: Changes shorter than this are listed as a count, not as rows.
MIN_ROW_HOURS = 1.0


# =============================================================================
# Calendar
# =============================================================================

def is_business_hours(now: datetime | None = None) -> bool:
    """07:00-17:10 UK, Mon-Fri."""
    now_uk = (now or datetime.now(UK_TZ)).astimezone(UK_TZ)
    return now_uk.weekday() < 5 and MARKET_OPEN_UK <= now_uk.time() < RUN_WINDOW_END_UK


def business_day(now_uk: datetime) -> date:
    d = now_uk.astimezone(UK_TZ).date()
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    return d


def previous_business_close(bd: date) -> datetime:
    d = bd - timedelta(days=1)
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    return datetime.combine(d, MARKET_CLOSE_UK, tzinfo=UK_TZ)


def todays_close(now_uk: datetime) -> datetime:
    return datetime.combine(now_uk.astimezone(UK_TZ).date(), MARKET_CLOSE_UK, tzinfo=UK_TZ)


@dataclass
class CapacityChange:
    """One contiguous period of changed availability for one unit."""
    curve_name: str
    plant_name: str
    country: str
    fuel_type: str
    period_start: datetime
    period_end: datetime
    prev_capacity_mw: float
    current_capacity_mw: float
    delta_mw: float
    issued_at: datetime | None       # REMIT publication time of the new state
    compared_with: str = "prev close"   # "prev close" or "alert HH:MM"

    @property
    def hours(self) -> float:
        return (self.period_end - self.period_start).total_seconds() / 3600.0


@dataclass
class Evaluation:
    """Everything one poll decided, used for sending, rendering and the summary."""
    pending: dict[str, dict[str, list[Segment]]] = field(default_factory=dict)
    tenor_avgs: dict[str, dict[str, float]] = field(default_factory=dict)
    significant: dict[str, list[str]] = field(default_factory=dict)
    teams_breaches: list[dict] = field(default_factory=list)
    tenors: dict[str, tuple[datetime, datetime]] = field(default_factory=dict)

    @property
    def alert_groups(self) -> list[str]:
        return sorted(set(self.significant) | {b["group"] for b in self.teams_breaches})


class PowerAvailabilityAlertService:
    """Polls EQ REMIT curves and sends availability alerts. See module docstring."""

    def __init__(
        self,
        config_path: Path | None = None,
        recipients: str | None = None,
        log_level: int = logging.INFO,
        state_dir: Path | None = None,
        eq: Any = None,
    ):
        self.base_dir = Path(__file__).parent.resolve()
        self.config_path = config_path or self.base_dir / "monitored_curves.json"
        self._setup_logging(log_level)
        self.config = self._load_config()
        self.recipients = recipients or self.config.get("recipients", {}).get("default", "")
        self.eq = eq if eq is not None else self._init_eq_client()
        self.store = StateStore(state_dir)
        self.state: dict = {}

    # ------------------------------------------------------------------ setup

    def _setup_logging(self, log_level: int):
        logging.basicConfig(level=log_level, format="%(asctime)s - %(levelname)s - %(message)s")
        self.logger = logging.getLogger(__name__)

    def _load_config(self) -> dict:
        with open(self.config_path, encoding="utf-8") as f:
            return json.load(f)

    def _init_eq_client(self) -> Any | None:
        if not EQ_AVAILABLE:
            self.logger.warning("energyquantified package not available")
            return None
        api_key = os.getenv(self.config.get("eq_api_key_env_var", "EQ_API_KEY"))
        if not api_key:
            self.logger.warning("EQ API key not found")
            return None
        return EnergyQuantified(api_key=api_key)

    @property
    def cooldown(self) -> timedelta:
        return timedelta(minutes=self.config.get("thresholds", {}).get("cooldown_minutes", 60))

    @property
    def recheck_window(self) -> timedelta:
        return timedelta(minutes=self.config.get("unit_recheck_minutes", 15))

    # ------------------------------------------------------------- EQ access

    def _search_curves(self, area, exact_category: str, has_place: bool) -> list[str]:
        """All curve names for a category. Raises on API failure (never returns a partial list)."""
        page = self.eq.metadata.curves(
            area=area,
            data_type=DataType.REMIT,
            curve_type=CurveType.INSTANCE_PERIOD,
            exact_category=exact_category,
            has_place=has_place,
            page_size=100,
        )
        names = []
        while True:
            names.extend(c.name for c in page)
            if page.page < page.total_pages:
                page = page.get_next_page()
            else:
                return names

    def _fetch(self, curve: str, issued_at_latest: datetime | None, today_cet: date):
        """
        Latest REMIT instance issued at or before ``issued_at_latest`` (None = latest).
        Returns (blocks, issued_iso). blocks is [] when no instance exists yet.
        Raises on API failure so the caller can avoid advancing state.
        """
        end_days = self.config.get("date_range", {}).get("end_days_forward", 400)
        kwargs = {"begin": today_cet, "end": today_cet + timedelta(days=end_days)}
        if issued_at_latest is not None:
            kwargs["issued_at_latest"] = issued_at_latest
        try:
            ps = self.eq.period_instances.latest(curve, **kwargs)
        except NotFoundError:
            return [], None
        issued = getattr(getattr(ps, "instance", None), "issued", None)
        return periodseries_to_blocks(ps) or [], issued.isoformat() if issued else None

    # ------------------------------------------------------------ main cycle

    def check_and_alert(self, now: datetime | None = None) -> dict:
        """One poll. Holds the run lock for its whole duration."""
        summary = {
            "aggregates_checked": 0, "aggregates_changed": 0, "units_checked": 0,
            "curves_with_changes": 0, "alerts_sent": 0, "alert_details": [],
            "teams_alerts_sent": 0, "teams_breaches": [], "errors": [], "timing": {},
        }
        if not self.eq:
            summary["errors"].append("EQ client not available")
            return summary
        try:
            with RunLock(self.store.dir):
                return self._check_and_alert_locked(now or datetime.now(UK_TZ), summary)
        except LockHeld as e:
            self.logger.warning(f"Skipping poll: {e}")
            summary["errors"].append(f"skipped: {e}")
            return summary

    def _check_and_alert_locked(self, now: datetime, summary: dict) -> dict:
        t0 = time.time()
        now_uk = now.astimezone(UK_TZ)
        state = self.state = self.store.load()
        bd = business_day(now_uk)
        baseline_close = previous_business_close(bd)

        if state.get("business_day") != bd.isoformat():
            rebuilt = state["_loaded"] is False and now_uk.time() > dtime(7, 20)
            self.logger.info(
                f"New business day {bd} - baseline is REMIT as of {baseline_close:%a %d-%b %H:%M} UK"
                + (" (state missing: rebuilding mid-day)" if rebuilt else "")
            )
            state.update({
                "business_day": bd.isoformat(),
                "baseline_close": baseline_close.isoformat(),
                "state_rebuilt": rebuilt,
                "groups": {},
                "units": {},
                "last_teams_signature": None,
                "last_email_signature": None,
            })

        close = todays_close(now_uk)
        issued_cap = close if now_uk >= close else None
        as_of = min(now_uk, close)
        today_cet = as_of.astimezone(CET).date()

        # 1. Refresh the groups whose aggregate moved (or are inside the re-scan window)
        for country in self.config.get("countries", []):
            for fuel in self.config.get("fuel_types", []):
                self._scan_group(state, country, fuel, now_uk, issued_cap, baseline_close,
                                 today_cet, summary)
        summary["timing"]["scan"] = time.time() - t0

        # 2. Decide
        ev = self.evaluate(state, as_of)
        summary["curves_with_changes"] = sum(len(u) for u in ev.pending.values())

        # 3. Alert
        if ev.alert_groups:
            self._alert(state, ev, now_uk, summary)
        else:
            self.logger.info(
                f"No threshold crossed ({summary['curves_with_changes']} unit(s) with pending sub-threshold changes)"
            )

        self.store.save(state)
        summary["timing"]["total"] = time.time() - t0
        self.logger.info(
            f"Poll done in {summary['timing']['total']:.1f}s: aggs={summary['aggregates_checked']} "
            f"(moved {summary['aggregates_changed']}), units={summary['units_checked']}, "
            f"pending={summary['curves_with_changes']}, email={summary['alerts_sent']}, "
            f"teams={summary['teams_alerts_sent']}, errors={len(summary['errors'])}"
        )
        return summary

    def _scan_group(self, state, country, fuel, now_uk, issued_cap, baseline_close, today_cet, summary):
        category = FUEL_CATEGORIES.get(fuel)
        if not category:
            summary["errors"].append(f"{country}/{fuel}: unknown fuel type in config")
            return
        key = f"{country}|{fuel}"
        g = state["groups"].setdefault(key, {"agg_fp": None, "recheck_until": None, "agg": None, "units": None})
        try:
            area = Area.by_tag(country)
            if g.get("agg") is None:
                aggs = self._search_curves(area, category, has_place=False)
                if not aggs:
                    g["agg"] = ""   # no such market/fuel: remember, don't search again today
                    return
                g["agg"] = aggs[0]
            if not g["agg"]:
                return
            summary["aggregates_checked"] += 1
            agg_blocks, _ = self._fetch(g["agg"], issued_cap, today_cet)
            agg_fp = blocks_fingerprint(agg_blocks)

            moved = agg_fp != g["agg_fp"]
            in_window = g["recheck_until"] and now_uk < datetime.fromisoformat(g["recheck_until"])
            if moved:
                summary["aggregates_changed"] += 1
                g["recheck_until"] = (now_uk + self.recheck_window).isoformat()
            if not (moved or in_window):
                return

            if g.get("units") is None:
                g["units"] = self._search_curves(area, category, has_place=True)
            for curve in g["units"]:
                summary["units_checked"] += 1
                u = state["units"].setdefault(curve, {"group": key})
                if "alerted_blocks" not in u:
                    base_blocks, base_issued = self._fetch(curve, baseline_close, today_cet)
                    u.update(alerted_blocks=base_blocks, alerted_issued=base_issued,
                             alerted_at=None, current_blocks=None, current_issued=None)
                cur_blocks, cur_issued = self._fetch(curve, issued_cap, today_cet)
                if blocks_fingerprint(cur_blocks) == blocks_fingerprint(u["alerted_blocks"]):
                    u["current_blocks"], u["current_issued"] = None, None
                else:
                    u["current_blocks"], u["current_issued"] = cur_blocks, cur_issued
            # Only record the aggregate once every unit was read successfully.
            g["agg_fp"] = agg_fp
        except Exception as e:
            # Leave agg_fp untouched so the group is re-scanned next poll.
            self.logger.error(f"{key}: scan failed, will retry next poll: {e}")
            summary["errors"].append(f"{key}: {e}")

    def evaluate(self, state: dict, as_of: datetime) -> Evaluation:
        """Pure decision step over persisted state (no API calls)."""
        ev = Evaluation()
        today_cet = as_of.astimezone(CET).date()
        ev.tenors = self.tenor_ranges(today_cet)
        window_end = datetime.combine(
            today_cet + timedelta(days=self.config.get("date_range", {}).get("end_days_forward", 400)),
            dtime(0), tzinfo=CET,
        )
        for curve, u in state["units"].items():
            if not u.get("current_blocks"):
                continue
            segs = diff_blocks(u["alerted_blocks"], u["current_blocks"], as_of, window_end)
            if segs:
                ev.pending.setdefault(u["group"], {})[curve] = segs

        tenors = ev.tenors
        teams_cfg = self.config.get("teams_alerts", {})
        teams_on = teams_cfg.get("enabled", False)
        for key, units in ev.pending.items():
            country, fuel = key.split("|", 1)
            all_segs = [s for segs in units.values() for s in segs]
            avgs = {t: tenor_average_delta(all_segs, a, b) for t, (a, b) in tenors.items()}
            ev.tenor_avgs[key] = avgs
            sig = [t for t, v in avgs.items() if abs(v) >= self.email_threshold(t)]
            if sig:
                ev.significant[key] = sig
            if teams_on:
                for t, v in avgs.items():
                    thr = self.teams_threshold(country, fuel, tenor_type(t), teams_cfg.get("thresholds", []))
                    if thr is not None and abs(v) >= thr:
                        ev.teams_breaches.append(
                            {"group": key, "country": country, "fuel": fuel, "tenor": t,
                             "tenor_type": tenor_type(t), "delta_mw": round(v, 1), "threshold": thr}
                        )
        return ev

    def _alert(self, state: dict, ev: Evaluation, now_uk: datetime, summary: dict):
        groups = ev.alert_groups
        changes = self.build_changes(state, ev, groups)
        signature = _signature([(c.curve_name, c.period_start.isoformat(), c.period_end.isoformat(),
                                 round(c.prev_capacity_mw), round(c.current_capacity_mw)) for c in changes])
        if signature == state.get("last_email_signature"):
            self.logger.warning("Identical alert already sent - marking as told, not resending")
            self._mark_alerted(state, ev, groups, now_uk)
            return

        urgent = bool(ev.teams_breaches)
        last = state.get("last_email_at")
        if last and not urgent and now_uk - datetime.fromisoformat(last) < self.cooldown:
            self.logger.info(
                f"Email cooldown ({self.cooldown}) - {len(changes)} change(s) held and will be "
                f"included in the next alert"
            )
            summary["alert_details"] = ["Held by cooldown (will be sent in next alert)"]
            return

        teams_ok = False
        if ev.teams_breaches:
            # Same content as the email: a retry after an email failure must not re-post to Teams.
            teams_sig = signature
            if teams_sig != state.get("last_teams_signature"):
                teams_ok = self.send_teams_alert(ev, changes, state)
                if teams_ok:
                    state["last_teams_signature"] = teams_sig
                    summary["teams_alerts_sent"] = len(ev.teams_breaches)
                    summary["teams_breaches"] = [
                        f"{b['country']} {b['fuel']} {b['tenor']}: {b['delta_mw']:+.0f} MW" for b in ev.teams_breaches[:5]
                    ]

        email_ok = self.send_alert(changes, ev, state)
        if not email_ok:
            # Nothing marked: the email is retried next poll (Teams is de-duplicated by signature).
            summary["errors"].append("email send failed - will retry")
            return

        self._mark_alerted(state, ev, groups, now_uk)
        state["last_email_at"] = now_uk.isoformat()
        state["last_email_signature"] = signature
        state["state_rebuilt"] = False
        summary["alerts_sent"] = 1
        summary["alert_details"] = [
            f"{c.plant_name} ({c.country}): {c.delta_mw:+.0f} MW" for c in changes[:5]
        ] + ([f"... and {len(changes) - 5} more"] if len(changes) > 5 else [])

    # --------------------------------------------------------------- helpers

    @staticmethod
    def _mark_alerted(state: dict, ev: Evaluation, groups: list[str], now_uk: datetime) -> None:
        """The desk has now seen these units' current state: it becomes their new baseline."""
        for key in groups:
            for curve in ev.pending.get(key, {}):
                u = state["units"][curve]
                u["alerted_blocks"], u["alerted_issued"] = u["current_blocks"], u["current_issued"]
                u["current_blocks"], u["current_issued"] = None, None
                u["alerted_at"] = now_uk.isoformat()

    def build_changes(self, state: dict, ev: Evaluation, groups: list[str]) -> list[CapacityChange]:
        out = []
        for key in groups:
            country, fuel = key.split("|", 1)
            for curve, segs in ev.pending.get(key, {}).items():
                u = state["units"][curve]
                issued = datetime.fromisoformat(u["current_issued"]) if u.get("current_issued") else None
                compared = (
                    f"alert {datetime.fromisoformat(u['alerted_at']).astimezone(UK_TZ):%H:%M}"
                    if u.get("alerted_at") else "prev close"
                )
                for s in segs:
                    out.append(CapacityChange(
                        curve_name=curve, plant_name=plant_name(curve, fuel), country=country,
                        fuel_type=fuel, period_start=s.start, period_end=s.end,
                        prev_capacity_mw=s.prev_mw, current_capacity_mw=s.cur_mw,
                        delta_mw=s.delta_mw, issued_at=issued, compared_with=compared,
                    ))
        return out

    def tenor_ranges(self, today_cet: date) -> dict[str, tuple[datetime, datetime]]:
        """D+1..D+5, Wknd+1..2, Week+1..3, then 12 calendar months (CET delivery)."""
        def midnight(d: date) -> datetime:
            return datetime.combine(d, dtime(0), tzinfo=CET)

        ranges: dict[str, tuple[datetime, datetime]] = {}
        for i in range(1, 6):
            d = today_cet + timedelta(days=i)
            ranges[f"D+{i}"] = (midnight(d), midnight(d + timedelta(days=1)))
        to_sat = (5 - today_cet.weekday()) % 7 or 7
        for i in range(2):
            sat = today_cet + timedelta(days=to_sat + 7 * i)
            ranges[f"Wknd+{i + 1}"] = (midnight(sat), midnight(sat + timedelta(days=2)))
        to_mon = (0 - today_cet.weekday()) % 7 or 7
        for i in range(3):
            mon = today_cet + timedelta(days=to_mon + 7 * i)
            ranges[f"Week+{i + 1}"] = (midnight(mon), midnight(mon + timedelta(days=7)))
        y, m = today_cet.year, today_cet.month
        for _ in range(12):
            y, m = (y + 1, 1) if m == 12 else (y, m + 1)
            start = date(y, m, 1)
            nxt = date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)
            ranges[start.strftime("%b-%y")] = (midnight(start), midnight(nxt))
        return ranges

    def email_threshold(self, tenor: str) -> float:
        t = self.config.get("thresholds", {}).get("tenor_thresholds", {})
        kind = tenor_type(tenor)
        if kind == "Daily":
            return float(t.get("daily_avg_mw", 500))
        if kind == "Weekly":
            return float(t.get("weekly_avg_mw", 100))
        return float(t.get("monthly_avg_mw", 250))

    @staticmethod
    def teams_threshold(country: str, fuel: str, kind: str, thresholds: list[dict]) -> float | None:
        """First matching rule wins ('*' matches anything)."""
        for rule in thresholds:
            if (rule.get("country") in (country, "*") and rule.get("fuel") in (fuel, "*")
                    and rule.get("tenor_type") in (kind, "*")):
                return float(rule.get("threshold", 0))
        return None

    # -------------------------------------------------------------- delivery

    def send_alert(self, changes: list[CapacityChange], ev: Evaluation, state: dict) -> bool:
        if not self.recipients:
            self.logger.warning("No recipients configured for alerts")
            return False
        subject = self.build_email_subject(ev, changes)
        try:
            send_email(recipients=self.recipients, subject=subject,
                       body=self.build_email_body(changes, ev, state))
            self.logger.info(f"Alert sent: {subject}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to send alert: {e}")
            return False

    def impact(self, ev: Evaluation, cs: list[CapacityChange]) -> float:
        """Largest tenor move these changes cause, as a multiple of that tenor's alert threshold."""
        best = 0.0
        for t, (a, b) in ev.tenors.items():
            mwh = sum(c.delta_mw * max(0.0, (min(b, c.period_end) - max(a, c.period_start)).total_seconds() / 3600)
                      for c in cs)
            best = max(best, abs(mwh / ((b - a).total_seconds() / 3600)) / self.email_threshold(t))
        return best

    def _headlines(self, ev: Evaluation, changes: list[CapacityChange]) -> list[tuple[str, float, str, list[str]]]:
        """(group, avg MW, tenor, units by impact) per alerted group, most material first."""
        out = []
        for key in ev.alert_groups:
            avgs = ev.tenor_avgs.get(key, {})
            if not avgs:
                continue
            tenor = max(avgs, key=lambda t: abs(avgs[t]) / self.email_threshold(t))
            per_unit: dict[str, list[CapacityChange]] = {}
            for c in changes:
                if f"{c.country}|{c.fuel_type}" == key:
                    per_unit.setdefault(c.plant_name, []).append(c)
            units = sorted(per_unit, key=lambda n: self.impact(ev, per_unit[n]), reverse=True)
            out.append((key, avgs[tenor], tenor, units, abs(avgs[tenor]) / self.email_threshold(tenor)))
        out.sort(key=lambda h: h[4], reverse=True)
        return [h[:4] for h in out]

    def build_email_subject(self, ev: Evaluation, changes: list[CapacityChange]) -> str:
        parts = []
        for key, avg, tenor, units in self._headlines(ev, changes)[:3]:
            country, fuel = key.split("|", 1)
            who = units[0] + (f" +{len(units) - 1}" if len(units) > 1 else "") if units else ""
            parts.append(f"{country} {fuel} {avg:+,.0f} MW {tenor}" + (f" ({who})" if who else ""))
        extra = len(ev.alert_groups) - len(parts)
        subject = "REMIT: " + " | ".join(parts) + (f" | +{extra} more" if extra > 0 else "")
        return ("[LARGE] " if ev.teams_breaches else "") + subject

    def build_email_body(self, changes: list[CapacityChange], ev: Evaluation, state: dict) -> str:
        baseline = datetime.fromisoformat(state["baseline_close"]).astimezone(UK_TZ)
        now_str = datetime.now(UK_TZ).strftime("%a %d-%b %H:%M UK")
        visible = [c for c in changes if c.hours >= MIN_ROW_HOURS]
        hidden = len(changes) - len(visible)
        published = [c.issued_at for c in changes if c.issued_at]
        pub_str = ""
        if published:
            lo, hi = min(published).astimezone(UK_TZ), max(published).astimezone(UK_TZ)
            pub_str = _fmt_time(lo) if lo == hi else f"{_fmt_time(lo)} to {_fmt_time(hi)}"
        any_since_alert = any(c.compared_with != "prev close" for c in changes)

        banner = ""
        if state.get("state_rebuilt"):
            banner = (
                '<table width="100%" cellpadding="0" cellspacing="0"><tr><td bgcolor="#FFF4CE" '
                'style="padding:10px;border:1px solid #E0B000;"><b>Alert state was reset today.</b> '
                'This email lists every change since the previous close and may repeat changes '
                'already alerted earlier today.</td></tr></table><br>'
            )

        # --- key changes: one line per unit, biggest first
        by_unit: dict[str, list[CapacityChange]] = {}
        for c in visible:
            by_unit.setdefault(c.curve_name, []).append(c)
        order = sorted(by_unit, key=lambda k: -self.impact(ev, by_unit[k]))
        key_lines = []
        for curve in order[:12]:
            cs = by_unit[curve]
            main = max(cs, key=lambda c: self.impact(ev, [c]))
            colour = "#C00000" if main.delta_mw < 0 else "#2E7D32"
            word = "DOWN" if main.delta_mw < 0 else "UP"
            more = f" <span style='color:#777'>(+{len(cs) - 1} more period{'s' if len(cs) > 2 else ''})</span>" if len(cs) > 1 else ""
            since = "" if main.compared_with == "prev close" else f" <span style='color:#777'>[update since {main.compared_with}]</span>"
            key_lines.append(
                f"<li style='margin-bottom:4px;'><b style='color:{colour}'>{word} {main.delta_mw:+,.0f} MW</b> "
                f"<b>{escape(main.plant_name)}</b> ({main.country} {main.fuel_type}): "
                f"{main.prev_capacity_mw:,.0f} &rarr; {main.current_capacity_mw:,.0f} MW, "
                f"{_fmt_period(main)}"
                + (f" &middot; published {_fmt_time(main.issued_at)}" if main.issued_at else "")
                + more + since + "</li>"
            )
        if len(order) > 12:
            key_lines.append(f"<li style='color:#777'>... and {len(order) - 12} more unit(s) below</li>")

        heatmap = self._heatmap_html(ev)
        rows = "\n".join(self._detail_row(c) for c in sorted(
            visible, key=lambda c: (c.country, c.fuel_type, c.plant_name, c.period_start)))
        hidden_note = (f"<p style='font-size:11px;color:#777;'>{hidden} sub-hour adjustment(s) not listed.</p>"
                       if hidden else "")
        compare_note = (
            f"Previous business day close ({baseline:%a %d-%b %H:%M} UK)."
            + (" Rows marked <i>alert HH:MM</i> are updates since that earlier alert today."
               if any_since_alert else "")
        )
        th = 'bgcolor="#f2f2f2" style="padding:6px;border:1px solid #999;font-weight:bold;"'
        headers = ["Country", "Fuel", "Unit", "From (UK)", "To (UK)", "Duration",
                   "Was MW", "Now MW", "Change MW", "Published (UK)", "Compared with"]

        return f'''<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="font-family:Calibri,Arial,sans-serif;font-size:13px;color:#333;margin:0;padding:16px;">
{banner}
<h2 style="font-size:17px;margin:0 0 8px 0;">Key changes</h2>
<ul style="margin:0 0 12px 0;padding-left:18px;">{"".join(key_lines)}</ul>
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td style="padding:8px;background-color:#f2f2f2;border:1px solid #bbb;font-size:12px;">
<b>Compared with:</b> {compare_note}<br>
<b>REMIT published:</b> {pub_str or "n/a"} &nbsp; <b>Alert generated:</b> {now_str}
</td></tr></table>
<br>
<h2 style="font-size:17px;margin:0 0 4px 0;">Net change by tenor (average MW over the period)</h2>
<p style="font-size:11px;color:#666;margin:0 0 6px 0;">Negative = less capacity available. Coloured cells crossed the alert threshold; grey cells did not.</p>
{heatmap}
<br>
<h2 style="font-size:17px;margin:0 0 6px 0;">All changes</h2>
<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
<tr>{"".join(f"<th {th}>{h}</th>" for h in headers)}</tr>
{rows}
</table>
{hidden_note}
<p style="font-size:11px;color:#777;">Times are UK local. Periods are REMIT unavailability windows; tenors are CET delivery days.
Data: Energy Quantified REMIT.</p>
</body></html>'''

    def _detail_row(self, c: CapacityChange) -> str:
        bg = FUEL_COLORS.get(c.fuel_type, "#ffffff")
        td = f'bgcolor="{bg}" style="padding:5px;border:1px solid #ccc;"'
        tdw = 'style="padding:5px;border:1px solid #ccc;text-align:right;"'
        delta_bg = _gradient(c.delta_mw, 1000.0)
        return (
            f"<tr><td {td}>{c.country}</td><td {td}>{c.fuel_type}</td><td {td}><b>{escape(c.plant_name)}</b></td>"
            f"<td {td}>{_fmt_time(c.period_start)}</td><td {td}>{_fmt_time(c.period_end)}</td>"
            f"<td {tdw}>{_fmt_duration(c.hours)}</td>"
            f"<td {tdw}>{c.prev_capacity_mw:,.0f}</td><td {tdw}>{c.current_capacity_mw:,.0f}</td>"
            f'<td bgcolor="{delta_bg}" style="padding:5px;border:1px solid #ccc;text-align:right;font-weight:bold;">'
            f"{c.delta_mw:+,.0f}</td>"
            f"<td {tdw}>{_fmt_time(c.issued_at) if c.issued_at else '-'}</td>"
            f"<td {td}>{c.compared_with}</td></tr>"
        )

    def _heatmap_html(self, ev: Evaluation) -> str:
        groups = ev.alert_groups
        if not groups:
            return ""
        tenors = [t for t in next(iter(ev.tenor_avgs.values()))
                  if any(t in ev.significant.get(g, []) for g in groups)
                  or any(b["tenor"] == t for b in ev.teams_breaches)]
        cell = 'style="padding:5px 8px;text-align:center;border:1px solid #ccc;'
        head = "".join(
            f'<th bgcolor="#f2f2f2" {cell}font-weight:bold;">{g.replace("|", "<br>")}</th>' for g in groups)
        body = []
        for t in tenors:
            tds = []
            for g in groups:
                v = ev.tenor_avgs.get(g, {}).get(t, 0.0)
                if t in ev.significant.get(g, []) or any(b["group"] == g and b["tenor"] == t for b in ev.teams_breaches):
                    tds.append(f'<td bgcolor="{_gradient(v, 1000.0)}" {cell}font-weight:bold;">{v:+,.0f}</td>')
                elif abs(v) >= 1:
                    tds.append(f'<td {cell}color:#aaa;">{v:+,.0f}</td>')
                else:
                    tds.append(f'<td {cell}color:#ccc;">-</td>')
            body.append(f'<tr><td bgcolor="#f2f2f2" {cell}font-weight:bold;">{t}</td>{"".join(tds)}</tr>')
        return (f'<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;">'
                f'<tr><th bgcolor="#f2f2f2" {cell}">Tenor</th>{head}</tr>{"".join(body)}</table>')

    def _teams_webhook(self) -> str | None:
        url = os.getenv("POWER_AVAILABILITY_TEAMS_WEBHOOK_URL") or self.config.get("teams_alerts", {}).get("webhook_url")
        if url:
            return url
        try:
            from jain_commods.core.util.dagster.config import get_teams_webhook_url
            return get_teams_webhook_url()
        except ImportError:
            if os.environ.get("DAGSTER_ENV", "local") == "production":
                return os.environ.get("TEAMS_WEBHOOK_URL")
            return os.environ.get("DEV_TEAMS_WEBHOOK_URL") or os.environ.get("TEAMS_WEBHOOK_URL")

    def build_teams_lines(self, ev: Evaluation, changes: list[CapacityChange]) -> tuple[str, list[str]]:
        """Markdown title + lines (Teams cards render markdown, not HTML tables)."""
        title = "⚡ " + self.build_email_subject(ev, changes).replace("[LARGE] ", "")
        lines = []
        by_group: dict[str, list[dict]] = {}
        for b in ev.teams_breaches:
            by_group.setdefault(b["group"], []).append(b)
        for key, bs in by_group.items():
            country, fuel = key.split("|", 1)
            by_value: dict[int, list[str]] = {}
            for b in bs:
                by_value.setdefault(round(b["delta_mw"]), []).append(b["tenor"])
            tenors = ", ".join(f"{_compact_tenors(ts)} **{v:+,} MW**" for v, ts in by_value.items())
            lines.append(f"**{country} {fuel}**: {tenors}")
            units = sorted((c for c in changes if f"{c.country}|{c.fuel_type}" == key and c.hours >= MIN_ROW_HOURS),
                           key=lambda c: -self.impact(ev, [c]))
            for c in units[:5]:
                pub = f", published {_fmt_time(c.issued_at)}" if c.issued_at else ""
                lines.append(
                    f"- {c.plant_name}: {c.prev_capacity_mw:,.0f} → {c.current_capacity_mw:,.0f} MW "
                    f"({c.delta_mw:+,.0f}), {_fmt_period(c, '→')}{pub}"
                )
            if len(units) > 5:
                lines.append(f"- ... and {len(units) - 5} more (see email)")
        return title, lines

    def send_teams_alert(self, ev: Evaluation, changes: list[CapacityChange], state: dict) -> bool:
        if not REQUESTS_AVAILABLE:
            return False
        url = self._teams_webhook()
        if not url:
            self.logger.warning("No Teams webhook URL configured - skipping Teams alert")
            return False
        title, lines = self.build_teams_lines(ev, changes)
        baseline = datetime.fromisoformat(state["baseline_close"]).astimezone(UK_TZ)
        subtitle = (f"{datetime.now(UK_TZ):%a %d-%b %H:%M} UK · vs prev close {baseline:%a %H:%M} UK "
                    f"or last alert · full detail in email")
        if "powerplatform.com" in url or "logic.azure.com" in url:
            body = [
                {"type": "TextBlock", "text": title, "weight": "Bolder", "size": "Medium", "wrap": True,
                 "color": "Attention" if any(b["delta_mw"] < 0 for b in ev.teams_breaches) else "Good"},
                {"type": "TextBlock", "text": subtitle, "isSubtle": True, "spacing": "None", "wrap": True},
            ] + [{"type": "TextBlock", "text": line, "wrap": True, "spacing": "Small"} for line in lines]
            payload = {"type": "AdaptiveCard", "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                       "version": "1.4", "body": body}
        else:
            payload = {
                "@type": "MessageCard", "@context": "http://schema.org/extensions",
                "themeColor": "C00000" if any(b["delta_mw"] < 0 for b in ev.teams_breaches) else "2E7D32",
                "summary": title,
                "sections": [{"activityTitle": title, "activitySubtitle": subtitle,
                              "text": "\n\n".join(lines), "markdown": True}],
            }
        try:
            r = requests.post(url, json=payload, timeout=30)
            r.raise_for_status()
            self.logger.info(f"Teams alert sent: {len(ev.teams_breaches)} breach(es)")
            return True
        except Exception as e:
            self.logger.error(f"Failed to send Teams alert: {e}")
            return False

    # ------------------------------------------------------------ standalone

    def run(self, check_interval: int | None = None):
        interval = check_interval or self.config.get("check_interval_seconds", 300)
        while True:
            try:
                if is_business_hours():
                    self.check_and_alert()
            except KeyboardInterrupt:
                break
            except Exception as e:
                self.logger.error(f"Error in main loop: {e}", exc_info=True)
            time.sleep(interval)


# =============================================================================
# Formatting helpers
# =============================================================================

def tenor_type(tenor: str) -> str:
    if tenor.startswith("D+") or tenor.startswith("Wknd"):
        return "Daily"
    if tenor.startswith("Week"):
        return "Weekly"
    return "Monthly"


def plant_name(curve: str, fuel: str) -> str:
    """'FR @Flamanville 3 Nuclear Capacity Available MW REMIT' -> 'Flamanville 3'."""
    if "@" not in curve:
        return f"{curve.split()[0]} {fuel} (aggregate)"
    rest = curve.split("@", 1)[1]
    category = FUEL_CATEGORIES.get(fuel, fuel)
    return rest.split(" " + category)[0].strip() if (" " + category) in rest else rest.split(" Capacity")[0].strip()


def _compact_tenors(tenors: list[str]) -> str:
    """['D+1','D+2','D+3','Wknd+1'] -> 'D+1–D+3, Wknd+1'."""
    out, run = [], []
    for t in [*tenors, None]:
        if t and t.startswith("D+") and (not run or int(t[2:]) == int(run[-1][2:]) + 1):
            run.append(t)
            continue
        if run:
            out.append(run[0] if len(run) == 1 else f"{run[0]}–{run[-1]}")
            run = []
        if t and t.startswith("D+"):
            run = [t]
        elif t:
            out.append(t)
    return ", ".join(out)


def _signature(items) -> str:
    return hashlib.md5(json.dumps(sorted(items), default=str).encode()).hexdigest()


def _fmt_time(dt: datetime | None) -> str:
    if dt is None:
        return "-"
    return dt.astimezone(UK_TZ).strftime("%a %d-%b %H:%M")


def _fmt_duration(hours: float) -> str:
    if hours < 48:
        return f"{hours:.0f}h" if hours >= 1 else f"{hours * 60:.0f}m"
    return f"{hours / 24:.1f}d"


def _fmt_period(c: CapacityChange, arrow: str = "&rarr;") -> str:
    return f"{_fmt_time(c.period_start)} {arrow} {_fmt_time(c.period_end)} ({_fmt_duration(c.hours)})"


def _gradient(val: float, abs_max: float) -> str:
    """White -> red for less capacity, white -> green for more."""
    if abs(val) < 0.5:
        return "#ffffff"
    x = min(1.0, abs(val) / abs_max)
    if val < 0:
        return f"#ff{int(255 - 187 * x):02x}{int(255 - 187 * x):02x}"
    return f"#{int(255 - 187 * x):02x}{int(255 - 85 * x):02x}{int(255 - 187 * x):02x}"


def main():
    PowerAvailabilityAlertService().run()


if __name__ == "__main__":
    main()
