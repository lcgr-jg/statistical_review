#!/usr/bin/env python3
"""
Test script to diagnose Energy Quantified API connection issues.
Run this on the server to check connectivity.
"""
import os
import sys
import socket
import ssl


def test_dns():
    """Test DNS resolution for EQ API."""
    print("\n[1/4] Testing DNS resolution...")
    try:
        ip = socket.gethostbyname("api.energyquantified.com")
        print(f"  ✅ DNS OK: api.energyquantified.com -> {ip}")
        return True
    except socket.gaierror as e:
        print(f"  ❌ DNS FAILED: {e}")
        return False


def test_tcp_connection():
    """Test TCP connection to EQ API."""
    print("\n[2/4] Testing TCP connection to api.energyquantified.com:443...")
    try:
        sock = socket.create_connection(("api.energyquantified.com", 443), timeout=10)
        sock.close()
        print("  ✅ TCP connection OK")
        return True
    except (socket.timeout, socket.error) as e:
        print(f"  ❌ TCP connection FAILED: {e}")
        return False


def test_ssl_connection():
    """Test SSL/TLS handshake."""
    print("\n[3/4] Testing SSL/TLS handshake...")
    try:
        context = ssl.create_default_context()
        with socket.create_connection(("api.energyquantified.com", 443), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname="api.energyquantified.com") as ssock:
                print(f"  ✅ SSL OK: {ssock.version()}")
                return True
    except Exception as e:
        print(f"  ❌ SSL FAILED: {e}")
        return False


def test_eq_api():
    """Test actual EQ API call."""
    print("\n[4/4] Testing Energy Quantified API...")
    
    api_key = os.getenv("EQ_API_KEY")
    if not api_key:
        print("  ⚠️  EQ_API_KEY environment variable not set")
        print("     Set it with: export EQ_API_KEY=your_key_here")
        return False
    
    print(f"  API key found: {api_key[:8]}...{api_key[-4:]}")
    
    try:
        from energyquantified import EnergyQuantified
        eq = EnergyQuantified(api_key=api_key)
        
        # Try a simple metadata call
        areas = eq.metadata.areas()
        print(f"  ✅ EQ API OK: Found {len(areas)} areas")
        return True
    except ImportError:
        print("  ❌ energyquantified package not installed")
        return False
    except Exception as e:
        print(f"  ❌ EQ API FAILED: {type(e).__name__}: {e}")
        return False


def check_proxy_settings():
    """Check if proxy environment variables are set."""
    print("\n[Proxy Settings]")
    http_proxy = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
    https_proxy = os.getenv("HTTPS_PROXY") or os.getenv("https_proxy")
    no_proxy = os.getenv("NO_PROXY") or os.getenv("no_proxy")
    
    if http_proxy:
        print(f"  HTTP_PROXY: {http_proxy}")
    else:
        print("  HTTP_PROXY: (not set)")
        
    if https_proxy:
        print(f"  HTTPS_PROXY: {https_proxy}")
    else:
        print("  HTTPS_PROXY: (not set)")
        
    if no_proxy:
        print(f"  NO_PROXY: {no_proxy}")


def main():
    print("=" * 60)
    print("Energy Quantified API Connection Diagnostic")
    print("=" * 60)
    
    check_proxy_settings()
    
    results = {
        "DNS": test_dns(),
        "TCP": test_tcp_connection(),
        "SSL": test_ssl_connection(),
        "API": test_eq_api(),
    }
    
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    
    all_ok = True
    for test, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"  {test}: {status}")
        if not passed:
            all_ok = False
    
    if all_ok:
        print("\n✅ All tests passed! EQ API connection is working.")
    else:
        print("\n❌ Some tests failed. Check the issues above.")
        
        # Provide specific advice
        if not results["DNS"]:
            print("\n💡 DNS Issue: Check /etc/resolv.conf or container DNS settings")
        elif not results["TCP"]:
            print("\n💡 TCP Issue: Firewall may be blocking outbound HTTPS (port 443)")
            print("   - Check security groups/firewall rules")
            print("   - Check if a proxy is required")
        elif not results["SSL"]:
            print("\n💡 SSL Issue: TLS handshake failed")
            print("   - Check if TLS inspection/proxy is interfering")
            print("   - Update CA certificates: apt-get update && apt-get install ca-certificates")
        elif not results["API"]:
            print("\n💡 API Issue: Connection works but API call failed")
            print("   - Check EQ_API_KEY is valid")
            print("   - Check if your IP is rate-limited or blocked")
            print("   - Contact Energy Quantified support")
    
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
