"""
Scenario tests for the REMIT availability alert: a fake EQ API with a
publication timeline, a controllable clock, and captured email/Teams sends.

Run: python -m pytest power_availability_alert/tests -q
"""

import json
from datetime import datetime
from types import SimpleNamespace

import pytest

import power_availability_alert.power_availability_alert as paa
from power_availability_alert.diff import diff_blocks, tenor_average_delta
from power_availability_alert.state import RunLock

UK = paa.UK_TZ
CET = paa.CET

# Tue 22-Sep-2026; prev close Mon 21-Sep 17:00 UK
MON_CLOSE = datetime(2026, 9, 21, 17, 0, tzinfo=UK)


def uk(day, hh, mm=0):
    return datetime(2026, 9, day, hh, mm, tzinfo=UK)


def cet(day, hh, mm=0, month=9):
    return datetime(2026, month, day, hh, mm, tzinfo=CET)


FAR = datetime(2027, 12, 1, tzinfo=CET)
START = datetime(2026, 9, 1, tzinfo=CET)


def flat(mw):
    return [(START, FAR, mw)]


def outage(mw, lo, hi, cap):
    return [(START, lo, cap), (lo, hi, mw), (hi, FAR, cap)]


class FakeEQ:
    """
    Timeline of REMIT versions per unit curve: (issued, periods, visible_at).
    Aggregates are derived from unit versions by *issued* time; a unit version
    only becomes readable at ``visible_at`` (models EQ publishing a unit late).
    """

    def __init__(self):
        self.now = None
        self.units = {}   # group -> [curve]
        self.aggs = {}    # group -> agg curve
        self.versions = {}
        self.fail = set()
        self.period_instances = SimpleNamespace(latest=self._latest)
        self.metadata = SimpleNamespace(curves=self._curves)

    def add_unit(self, country, fuel, name, periods):
        cat = paa.FUEL_CATEGORIES[fuel]
        group = (country, cat)
        curve = f"{country} @{name} {cat} MW REMIT"
        self.aggs[group] = f"{country} {cat} MW REMIT"
        self.units.setdefault(group, []).append(curve)
        self.versions[curve] = [(datetime(2026, 1, 1, tzinfo=UK), periods, None)]
        return curve

    def publish(self, curve, issued, periods, visible_at=None):
        self.versions[curve].append((issued, periods, visible_at))

    def _pick(self, curve, cap, by_visibility):
        best = None
        for issued, periods, visible in self.versions[curve]:
            t = (visible or issued) if by_visibility else issued
            if issued <= cap and t <= self.now:
                best = (issued, periods)
        return best

    def _latest(self, curve, begin, end, issued_at_latest=None):
        if curve in self.fail:
            raise RuntimeError("EQ 503")
        cap = issued_at_latest or self.now
        agg_group = next((g for g, a in self.aggs.items() if a == curve), None)
        if agg_group:
            picks = [self._pick(u, cap, by_visibility=False) for u in self.units[agg_group]]
            issued = max(p[0] for p in picks)
            signature = sum(hash(tuple((a.timestamp(), b.timestamp(), v) for a, b, v in p[1])) % 10**6 for p in picks)
            periods = [(START, FAR, float(signature))]
        else:
            issued, periods = self._pick(curve, cap, by_visibility=True)
        return SimpleNamespace(
            instance=SimpleNamespace(issued=issued),
            data=[SimpleNamespace(begin=a, end=b, value=v) for a, b, v in periods],
        )

    def _curves(self, area, data_type, curve_type, exact_category, has_place, page_size):
        group = (area.tag, exact_category)
        names = self.units.get(group, []) if has_place else ([self.aggs[group]] if group in self.aggs else [])
        return _Page(SimpleNamespace(name=n) for n in names)


class _Page(list):
    page = 1
    total_pages = 1


@pytest.fixture
def env(tmp_path, monkeypatch):
    config = json.loads((paa.Path(paa.__file__).parent / "monitored_curves.json").read_text())
    config.update(countries=["FR"], fuel_types=["Nuclear", "Natural Gas", "Hard Coal"])
    config["teams_alerts"]["webhook_url"] = "https://example.invalid/hook"
    cfg = tmp_path / "cfg.json"
    cfg.write_text(json.dumps(config))

    eq = FakeEQ()
    emails, teams = [], []
    ctl = SimpleNamespace(email_fails=False)

    def fake_send_email(recipients, subject, body):
        if ctl.email_fails:
            raise RuntimeError("smtp down")
        emails.append(SimpleNamespace(subject=subject, body=body))

    def fake_post(url, json=None, timeout=None):
        teams.append(json)
        return SimpleNamespace(raise_for_status=lambda: None)

    monkeypatch.setattr(paa, "send_email", fake_send_email)
    monkeypatch.setattr(paa.requests, "post", fake_post)
    monkeypatch.delenv("POWER_AVAILABILITY_TEAMS_WEBHOOK_URL", raising=False)

    def poll(at):
        eq.now = at
        svc = paa.PowerAvailabilityAlertService(config_path=cfg, recipients="desk@x", state_dir=tmp_path / "state", eq=eq)
        return svc.check_and_alert(now=at)

    return SimpleNamespace(eq=eq, emails=emails, teams=teams, poll=poll, ctl=ctl, dir=tmp_path / "state")


D1 = (cet(23, 0), cet(24, 0))  # D+1 from Tue 22-Sep


def test_overnight_outage_alerted_once(env):
    fl = env.eq.add_unit("FR", "Nuclear", "Flamanville 3", flat(1330))
    env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.eq.publish(fl, uk(22, 2), outage(0, *D1, 1330))

    env.poll(uk(22, 7))
    env.poll(uk(22, 7, 5))
    env.poll(uk(22, 7, 10))

    assert len(env.emails) == 1
    subj = env.emails[0].subject
    assert "FR Nuclear -1,330 MW D+1" in subj and "Flamanville 3" in subj and subj.startswith("[LARGE]")
    assert "Previous business day close (Mon 21-Sep 17:00 UK)" in env.emails[0].body
    assert "published Tue 22-Sep 02:00" in env.emails[0].body
    assert len(env.teams) == 1


def test_sub_threshold_changes_accumulate(env):
    # Gas: email daily threshold 500, Teams daily 1000.
    a = env.eq.add_unit("FR", "Natural Gas", "Blenod", flat(400))
    b = env.eq.add_unit("FR", "Natural Gas", "Martigues", flat(400))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(100, *D1, 400))       # -300: below 500
    env.poll(uk(22, 9, 5))
    assert env.emails == []
    env.eq.publish(b, uk(22, 10), outage(100, *D1, 400))      # another -300: total -600
    env.poll(uk(22, 10, 5))
    assert len(env.emails) == 1
    body = env.emails[0].body
    assert "Blenod" in body and "Martigues" in body and "-600" in body
    assert env.teams == []


def test_cooldown_holds_then_sends(env):
    a = env.eq.add_unit("FR", "Natural Gas", "Blenod", flat(800))
    b = env.eq.add_unit("FR", "Natural Gas", "Martigues", flat(800))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 800))
    env.poll(uk(22, 9, 5))
    env.eq.publish(b, uk(22, 9, 20), outage(0, *D1, 800))
    env.poll(uk(22, 9, 25))                                   # inside 60 min cooldown
    assert len(env.emails) == 1
    env.poll(uk(22, 10, 10))                                  # cooldown over, nothing new published
    assert len(env.emails) == 2
    assert "Martigues" in env.emails[1].body and "Blenod" not in env.emails[1].body


def test_large_move_bypasses_cooldown(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    b = env.eq.add_unit("FR", "Nuclear", "Paluel 2", flat(1300))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 1300))
    env.poll(uk(22, 9, 5))
    env.eq.publish(b, uk(22, 9, 10), outage(0, *D1, 1300))
    env.poll(uk(22, 9, 15))
    assert len(env.emails) == 2 and len(env.teams) == 2


def test_revert_to_baseline_is_alerted(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 1300))
    env.poll(uk(22, 9, 5))
    env.eq.publish(a, uk(22, 11), flat(1300))                 # outage cancelled
    env.poll(uk(22, 11, 5))
    assert len(env.emails) == 2
    assert "UP +1,300 MW" in env.emails[1].body
    assert "alert 09:05" in env.emails[1].body


def test_unit_published_after_aggregate(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 1300), visible_at=uk(22, 9, 7))
    env.poll(uk(22, 9, 5))                                    # aggregate moved, unit not yet visible
    assert env.emails == []
    env.poll(uk(22, 9, 10))                                   # re-scan window catches it
    assert len(env.emails) == 1


def test_publication_just_before_close_not_lost_or_repeated(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.poll(uk(22, 7))
    env.poll(uk(22, 16, 55))
    env.eq.publish(a, uk(22, 16, 58), outage(0, cet(24, 0), cet(25, 0), 1300))
    env.eq.publish(a, uk(22, 17, 3), outage(0, cet(24, 0), cet(26, 0), 1300))  # after close
    env.poll(uk(22, 17, 5))                                   # reads the 17:00 snapshot
    assert len(env.emails) == 1
    first = env.emails[0].body
    assert "Wed 23-Sep 23:00" in first and "Thu 24-Sep 23:00" in first  # 24-Sep CET day only
    env.poll(uk(23, 7))                                       # Wed: baseline = Tue 17:00
    assert len(env.emails) == 2
    second = env.emails[1].body
    assert "Thu 24-Sep 23:00" in second and "Fri 25-Sep 23:00" in second  # only the post-close extension
    assert "Wed 23-Sep 23:00" not in second


def test_email_failure_retries_without_duplicate_teams(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 1300))
    env.ctl.email_fails = True
    env.poll(uk(22, 9, 5))
    env.ctl.email_fails = False
    env.poll(uk(22, 9, 10))
    env.poll(uk(22, 9, 15))
    assert len(env.emails) == 1 and len(env.teams) == 1


def test_scan_failure_does_not_lose_change(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.eq.add_unit("FR", "Nuclear", "Paluel 2", flat(1300))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 1300))
    env.eq.fail.add(a)
    env.poll(uk(22, 9, 5))
    assert env.emails == []
    env.eq.fail.clear()
    env.poll(uk(22, 9, 30))                                   # well past the re-scan window
    assert len(env.emails) == 1


def test_lock_prevents_overlapping_runs(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.eq.publish(a, uk(22, 2), outage(0, *D1, 1300))
    env.dir.mkdir(parents=True, exist_ok=True)
    with RunLock(env.dir):
        summary = env.poll(uk(22, 7))
    assert env.emails == [] and "skipped" in summary["errors"][0]
    env.poll(uk(22, 7, 5))
    assert len(env.emails) == 1


def test_state_lost_mid_day_is_flagged(env):
    a = env.eq.add_unit("FR", "Nuclear", "Paluel 1", flat(1300))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 1300))
    env.poll(uk(22, 11))
    assert "Alert state was reset today" in env.emails[0].body


def test_hard_coal_is_monitored(env):
    a = env.eq.add_unit("FR", "Hard Coal", "Cordemais 4", flat(600))
    env.poll(uk(22, 7))
    env.eq.publish(a, uk(22, 9), outage(0, *D1, 600))
    env.poll(uk(22, 9, 5))
    assert len(env.emails) == 1 and "FR Hard Coal -600 MW D+1 (Cordemais 4)" in env.emails[0].subject


# ---------------------------------------------------------------- pure diff

def _b(*rows):
    return [{"start": a.isoformat(), "end": b.isoformat(), "mw": v} for a, b, v in rows]


def test_diff_identical_with_quarter_hour_boundaries_is_empty():
    blocks = _b((cet(22, 0), cet(23, 23, 45), 120.0), (cet(23, 23, 45), FAR, 0.0))
    assert diff_blocks(blocks, list(reversed(blocks)), cet(22, 0), FAR) == []


def test_diff_exact_boundaries_and_horizon():
    prev = _b((cet(22, 0), cet(30, 0), 1000.0))
    cur = _b((cet(22, 0), cet(23, 6, 30), 1000.0), (cet(23, 6, 30), cet(25, 0), 0.0), (cet(25, 0), FAR, 1000.0))
    segs = diff_blocks(prev, cur, cet(22, 12), FAR)
    assert len(segs) == 1                                     # beyond prev horizon is ignored
    s = segs[0]
    assert s.start == cet(23, 6, 30) and s.end == cet(25, 0) and s.delta_mw == -1000
    avg = tenor_average_delta(segs, cet(23, 0), cet(24, 0))
    assert avg == pytest.approx(-1000 * 17.5 / 24)
