"""
Test script to verify Sensor + Asset integration works correctly.

Tests:
1. Sensor returns SkipReason when no alerts (no job trigger)
2. Sensor returns RunRequest when alerts sent (triggers asset)
3. Asset can access op_config correctly
4. Backward compatibility (sensor works without job)
"""

import sys
from pathlib import Path
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

def test_sensor_without_job():
    """Test sensor works without job (backward compatibility)."""
    print("=" * 80)
    print("Test 1: Sensor without job (backward compatibility)")
    print("=" * 80)
    
    from power_availability_alert.availability_sensor import create_power_availability_sensor
    from dagster import SensorEvaluationContext
    
    # Create sensor without job
    sensor = create_power_availability_sensor(
        recipients="test@example.com",
        minimum_interval_seconds=300,
        enforce_business_hours=False,  # Allow testing outside business hours
        alert_history_job=None,  # No job provided
    )
    
    print(f"[OK] Sensor created without job: {sensor.name}")
    print("  This ensures backward compatibility")
    return True

def test_sensor_with_job():
    """Test sensor can accept job parameter."""
    print("\n" + "=" * 80)
    print("Test 2: Sensor with job parameter")
    print("=" * 80)
    
    from power_availability_alert.availability_sensor import create_power_availability_sensor
    from dagster import define_asset_job, asset
    
    # Create a dummy asset and job for testing
    @asset(name="test_alert_history")
    def test_alert_history(context):
        return {"test": "data"}
    
    test_job = define_asset_job(
        name="test_alert_history_job",
        selection=[test_alert_history]
    )
    
    # Create sensor with job
    sensor = create_power_availability_sensor(
        recipients="test@example.com",
        minimum_interval_seconds=300,
        enforce_business_hours=False,
        alert_history_job=test_job,
    )
    
    print(f"[OK] Sensor created with job: {sensor.name}")
    print(f"  Job attached: {sensor._target_def.name if hasattr(sensor, '_target_def') else 'N/A'}")
    return True

def test_run_request_structure():
    """Test that RunRequest structure is correct."""
    print("\n" + "=" * 80)
    print("Test 3: RunRequest structure validation")
    print("=" * 80)
    
    import json
    from datetime import datetime
    
    try:
        from zoneinfo import ZoneInfo
        UK_TZ = ZoneInfo("Europe/London")
    except ImportError:
        import pytz
        UK_TZ = pytz.timezone("Europe/London")
    
    # Simulate what the sensor would create
    alert_timestamp = datetime.now(UK_TZ).isoformat()
    run_key = f"alert_{alert_timestamp.replace(':', '-').replace('.', '-').replace('+', '-')}"
    
    summary = {
        "alerts_sent": 1,
        "teams_alerts_sent": 2,
        "aggregates_checked": 6,
        "units_checked": 10,
        "curves_with_changes": 3,
        "alert_details": ["DE Nuclear: -500 MW", "FR Gas: +200 MW"],
        "teams_breaches": ["DE Nuclear D+1: -500 MW"],
        "timing": {"total": 1.5, "discovery": 0.2, "calc": 0.8}
    }
    
    run_config = {
        "ops": {
            "power_availability_alert_history": {
                "config": {
                    "alert_timestamp": alert_timestamp,
                    "alerts_sent": summary["alerts_sent"],
                    "teams_alerts_sent": summary["teams_alerts_sent"],
                    "aggregates_checked": summary["aggregates_checked"],
                    "units_checked": summary["units_checked"],
                    "curves_with_changes": summary["curves_with_changes"],
                    "alert_details": json.dumps(summary["alert_details"]),
                    "teams_breaches": json.dumps(summary["teams_breaches"]),
                    "timing": json.dumps(summary["timing"]),
                }
            }
        }
    }
    
    print(f"[OK] RunRequest structure:")
    print(f"  Run key: {run_key}")
    print(f"  Config structure: ops -> power_availability_alert_history -> config")
    print(f"  Alerts sent: {summary['alerts_sent']} email, {summary['teams_alerts_sent']} Teams")
    print(f"  Config JSON valid: {json.dumps(run_config) is not None}")
    
    return True

def test_asset_config_access():
    """Test asset can parse config correctly."""
    print("\n" + "=" * 80)
    print("Test 4: Asset config parsing")
    print("=" * 80)
    
    import json
    
    # Simulate op_config that asset would receive
    op_config = {
        "alert_timestamp": "2026-01-09T12:00:00+00:00",
        "alerts_sent": "1",
        "teams_alerts_sent": "2",
        "aggregates_checked": "6",
        "units_checked": "10",
        "curves_with_changes": "3",
        "alert_details": json.dumps(["DE Nuclear: -500 MW", "FR Gas: +200 MW"]),
        "teams_breaches": json.dumps(["DE Nuclear D+1: -500 MW"]),
        "timing": json.dumps({"total": 1.5, "discovery": 0.2}),
    }
    
    # Parse like asset would
    alert_details = op_config.get("alert_details", [])
    if isinstance(alert_details, str):
        try:
            alert_details = json.loads(alert_details)
        except:
            alert_details = []
    
    teams_breaches = op_config.get("teams_breaches", [])
    if isinstance(teams_breaches, str):
        try:
            teams_breaches = json.loads(teams_breaches)
        except:
            teams_breaches = []
    
    timing = op_config.get("timing", {})
    if isinstance(timing, str):
        try:
            timing = json.loads(timing)
        except:
            timing = {}
    
    print(f"[OK] Config parsing:")
    print(f"  Alert details: {alert_details}")
    print(f"  Teams breaches: {teams_breaches}")
    print(f"  Timing: {timing}")
    print(f"  All parsed correctly: {len(alert_details) == 2 and len(teams_breaches) == 1}")
    
    return True

if __name__ == "__main__":
    print("Testing Sensor + Asset Integration")
    print("=" * 80)
    
    try:
        test_sensor_without_job()
        test_sensor_with_job()
        test_run_request_structure()
        test_asset_config_access()
        
        print("\n" + "=" * 80)
        print("All tests passed! [OK]")
        print("=" * 80)
        print("\nNext steps:")
        print("1. Verify sensor triggers asset when alerts are sent")
        print("2. Check asset appears in Dagster UI asset graph")
        print("3. Verify alert history is recorded correctly")
        
    except Exception as e:
        print(f"\n[FAILED] Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

