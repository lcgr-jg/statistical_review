> **Superseded (Sep 2026).** State handling and change detection were rewritten: one atomic state file (`state.py`, `$POWER_AVAILABILITY_STATE_DIR`), exact REMIT-period diffs (`diff.py`), no Dagster cursor, no market-close freeze, and changes are only marked as alerted after a send succeeds. The authoritative description is the docstring at the top of `power_availability_alert.py`; tests are `python -m pytest power_availability_alert/tests`. Sections below on cursors, `StateCache`, fingerprints and the market-close freeze describe the old design.

# Testing Guide for Power Availability Alert System

## Overview

This guide explains how to test the power availability alert system with fake data.

## Test Scripts

### 1. `test_full_system.py` - Comprehensive System Test

**Purpose**: Tests the entire system end-to-end with mocked data.

**What it tests**:
- State management (cursor + cache file)
- Curve discovery (mocked EQ API)
- Data fetching (mocked REMIT data)
- Delta calculation
- Tenor filtering
- Alert building
- Email/Teams sending (mocked)
- State persistence

**Usage**:
```bash
cd eu_reports/power_availability_alert
python test_full_system.py
```

**What to expect**:
- Creates mock EQ client with fake REMIT data
- Simulates an outage (Irsching-4 plant: 561 MW → 0 MW)
- Runs two checks (baseline + change detection)
- Verifies state is saved correctly
- Shows email/Teams alerts that would be sent

**Output**:
```
[1/8] Setting up test environment...
[2/8] Creating service with mocked EQ client...
[3/8] Testing curve discovery...
[4/8] Setting up email/Teams mocks...
[5/8] Running first check (baseline)...
[6/8] Running second check (should detect changes)...
[7/8] Testing state persistence...
[8/8] Verifying results...
```

### 2. `test_asset_direct.py` - Direct Asset Test

**Purpose**: Tests the Dagster asset function directly (simulates Dagster execution).

**What it tests**:
- Asset function execution
- Service initialization
- Alert history asset dependency

**Usage**:
```bash
cd eu_reports/power_availability_alert
python test_asset_direct.py
```

**What to expect**:
- Mocks the service to return fake summary
- Calls asset function directly
- Tests alert history asset dependency

## Testing in Dagster UI

### Manual Testing

1. **Start Dagster**:
   ```bash
   cd eu_commods_pipelines
   dagster dev -w workspace.yaml
   ```

2. **Navigate to Assets**:
   - Go to: http://localhost:3000/assets
   - Find: `power_availability_alert`

3. **Materialize Asset Manually**:
   - Click on `power_availability_alert` asset
   - Click "Materialize" button
   - Watch the run execute

4. **Check Results**:
   - View logs in the run details
   - Check if `power_availability_alert_history` asset was also materialized
   - Verify alert history metadata

### Schedule Testing

1. **Enable Schedule**:
   - Go to: http://localhost:3000/automation/schedules
   - Find: `power_availability_alert_schedule`
   - Click "Start" to enable

2. **Monitor Runs**:
   - Schedule runs every 5 minutes (Mon-Fri, 07:00-17:00 UK)
   - Check run history
   - Verify assets are materialized

3. **Check Business Hours**:
   - Outside business hours: Asset should skip (check logs)
   - Inside business hours: Asset should execute

## Testing Scenarios

### Scenario 1: First Run (Baseline)

**Expected behavior**:
- Fetches current REMIT data
- Compares vs previous business day (or empty if first run)
- Stores baseline in `prev_bd_blocks`
- May or may not send alert (depends on changes)

**How to test**:
```bash
# Clear state first
rm -rf cache/state_cache.json cache/dagster_cursor.json

# Run test
python test_full_system.py
```

### Scenario 2: Change Detection

**Expected behavior**:
- Detects changes vs baseline
- Calculates deltas
- Filters by tenor thresholds
- Sends alerts if significant
- Updates `alerted_blocks`

**How to test**:
```bash
# Run test (second check simulates change)
python test_full_system.py
```

### Scenario 3: Cooldown

**Expected behavior**:
- If alert sent < 60 minutes ago: Skip email
- Changes are kept (not added to `alerted_blocks`)
- Next alert includes both blocked + new changes

**How to test**:
- Modify `test_full_system.py` to run checks within 60 minutes
- Verify second check skips email but keeps changes

### Scenario 4: Market Close/Open

**Expected behavior**:
- At 17:00 UK: Freeze state (`market_close_state_frozen = true`)
- At 07:00 UK (next day): Use frozen state as baseline
- First morning alert shows all overnight changes

**How to test**:
- Set system time to 17:00 UK, run check
- Set system time to 07:00 UK next day, run check
- Verify frozen state is used

### Scenario 5: Business Day Rollover

**Expected behavior**:
- New business day: Clear `alerted_blocks`
- Reset fingerprints
- Compare vs `prev_bd_blocks` (new baseline)

**How to test**:
- Simulate business day change in test
- Verify `alerted_blocks` are cleared
- Verify comparison uses `prev_bd_blocks`

## Mock Data Structure

The test uses the following mock data:

### Aggregate Curves
- `DE Nuclear Capacity Available MW REMIT`: 10 GW base
- `DE Natural Gas Power Capacity Available MW REMIT`: 5 GW base
- `FR Nuclear Capacity Available MW REMIT`: 60 GW base

### Individual Plants
- `DE @Brokdorf Nuclear...`: 1410 MW
- `DE @Isar-2 Nuclear...`: 1410 MW
- `DE @Irsching-4 Natural Gas...`: 561 MW → 0 MW (outage simulated)
- `DE @Tiefstack-CCGT Natural Gas...`: 500 MW

## Verifying Test Results

### Check State Files

```bash
# Cursor state (fingerprints)
cat cache/dagster_cursor.json

# Cache state (blocks)
cat cache/state_cache.json
```

### Check Logs

The test script outputs detailed logs showing:
- Curve discovery
- Data fetching
- Delta calculation
- Alert sending
- State updates

### Expected Output

```
[OK] First check completed
  - Aggregates checked: 6
  - Units checked: 0-10 (depends on changes)
  - Changes detected: 0-2
  - Alerts sent: 0-1 email, 0-1 Teams

[OK] Second check completed
  - Changes detected: 1-2 (should detect Irsching-4 outage)
  - Alerts sent: 1 email (if significant)
```

## Troubleshooting

### Issue: "EQ client not available"

**Solution**: The test mocks the EQ client. If you see this, the mock isn't working. Check that `patch` is applied correctly.

### Issue: "No changes detected"

**Solution**: The mock data includes an outage for Irsching-4. If no changes are detected, check:
- Mock data is correct
- State comparison logic
- Fingerprint calculation

### Issue: "State not persisting"

**Solution**: Check:
- Cache directory exists and is writable
- Cursor file is being saved
- File permissions are correct

### Issue: "Asset not materializing in Dagster"

**Solution**: 
- Check Dagster is running
- Verify asset is in Definitions
- Check for import errors
- Review Dagster logs

## Next Steps

After running tests:

1. **Verify in Dagster UI**:
   - Assets appear in asset graph
   - Runs execute successfully
   - Alert history is tracked

2. **Check Real Data**:
   - Enable schedule in production
   - Monitor first few runs
   - Verify alerts are sent correctly

3. **Monitor Performance**:
   - Check execution times
   - Verify state persistence
   - Monitor API call counts

## Additional Resources

- `SYSTEM_ARCHITECTURE.md`: Complete system architecture documentation
- `monitored_curves.json`: Configuration file
- Dagster UI: http://localhost:3000

