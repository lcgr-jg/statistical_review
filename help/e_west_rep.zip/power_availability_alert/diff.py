"""
Pure REMIT diff logic: no API, no state, no clock.

A curve's availability is stored as a list of blocks
``{"start": iso, "end": iso, "mw": float}`` (REMIT periods, non-overlapping).
Two block lists are compared as exact step functions - at the REMIT
message's own boundaries (e.g. 23:45), not on an hourly grid - so the same
REMIT state always diffs to nothing, whatever its period boundaries are.
"""

from __future__ import annotations

import bisect
import hashlib
import json
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from itertools import pairwise

#: Deltas smaller than this are float noise, not REMIT changes.
MIN_DELTA_MW = 1.0


@dataclass(frozen=True)
class Segment:
    """A contiguous period where availability differs between two states."""
    start: datetime   # tz-aware UTC
    end: datetime     # tz-aware UTC, exclusive
    prev_mw: float
    cur_mw: float

    @property
    def delta_mw(self) -> float:
        return self.cur_mw - self.prev_mw

    @property
    def hours(self) -> float:
        return (self.end - self.start).total_seconds() / 3600.0


def periodseries_to_blocks(periodseries) -> list[dict] | None:
    """Convert an EQ Periodseries to sorted blocks; None if there is no series."""
    if periodseries is None:
        return None
    data = getattr(periodseries, "data", None) or []
    blocks = []
    for p in sorted(data, key=lambda p: p.begin):
        blocks.append({
            "start": p.begin.isoformat(),
            "end": p.end.isoformat(),
            "mw": round(float(p.value), 1) if p.value is not None else 0.0,
        })
    return blocks


def blocks_fingerprint(blocks: Sequence[dict] | None) -> str:
    """Stable content hash of a block list."""
    if blocks is None:
        return "none"
    payload = json.dumps(
        [(_epoch(b["start"]), _epoch(b["end"]), round(float(b["mw"]), 1)) for b in blocks]
    )
    return hashlib.md5(payload.encode()).hexdigest()


def _epoch(iso: str) -> float:
    return datetime.fromisoformat(iso).timestamp()


def _to_steps(blocks: Sequence[dict]) -> tuple[list[float], list[float], list[float]]:
    rows = sorted((_epoch(b["start"]), _epoch(b["end"]), float(b["mw"])) for b in blocks)
    return [r[0] for r in rows], [r[1] for r in rows], [r[2] for r in rows]


def _value_at(steps, t: float) -> float | None:
    starts, ends, values = steps
    i = bisect.bisect_right(starts, t) - 1
    if i >= 0 and t < ends[i]:
        return values[i]
    return None  # not covered by this state


def diff_blocks(
    prev_blocks: Sequence[dict] | None,
    cur_blocks: Sequence[dict] | None,
    window_start: datetime,
    window_end: datetime,
) -> list[Segment]:
    """
    Periods inside [window_start, window_end) where availability changed.

    Only time covered by *both* states is compared, so a horizon that rolls
    forward (new months appearing) is not mistaken for a capacity change.
    Adjacent periods with the same before/after values are merged.
    """
    if not prev_blocks or not cur_blocks:
        return []
    prev, cur = _to_steps(prev_blocks), _to_steps(cur_blocks)
    lo, hi = window_start.timestamp(), window_end.timestamp()
    edges = {lo, hi}
    for steps in (prev, cur):
        edges.update(t for t in steps[0] + steps[1] if lo < t < hi)
    edges = sorted(edges)

    segments: list[Segment] = []
    for a, b in pairwise(edges):
        mid = (a + b) / 2.0
        p, c = _value_at(prev, mid), _value_at(cur, mid)
        if p is None or c is None or abs(c - p) < MIN_DELTA_MW:
            continue
        last = segments[-1] if segments else None
        if last and last.end.timestamp() == a and last.prev_mw == p and last.cur_mw == c:
            segments[-1] = Segment(last.start, _utc(b), p, c)
        else:
            segments.append(Segment(_utc(a), _utc(b), p, c))
    return segments


def _utc(ts: float) -> datetime:
    return datetime.fromtimestamp(ts, tz=UTC)


def tenor_average_delta(
    segments: Iterable[Segment], tenor_start: datetime, tenor_end: datetime
) -> float:
    """Time-weighted average MW change over a tenor (sum of MW*h / tenor hours)."""
    total_hours = (tenor_end - tenor_start).total_seconds() / 3600.0
    if total_hours <= 0:
        return 0.0
    mwh = 0.0
    for s in segments:
        overlap = (min(tenor_end, s.end) - max(tenor_start, s.start)).total_seconds() / 3600.0
        if overlap > 0:
            mwh += s.delta_mw * overlap
    return mwh / total_hours

