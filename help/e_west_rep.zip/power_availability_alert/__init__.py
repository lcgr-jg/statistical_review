"""
Power Availability REMIT Alert Package

Monitors REMIT power plant capacity data from Energy Quantified API
and sends email alerts for significant changes vs previous business day.
"""

from .power_availability_alert import PowerAvailabilityAlertService
from .availability_sensor import create_power_availability_sensor

__all__ = [
    "PowerAvailabilityAlertService",
    "create_power_availability_sensor",
]

