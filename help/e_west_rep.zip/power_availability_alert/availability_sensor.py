"""
Dagster wiring for the Power Availability REMIT alert.

Production runs the ``power_availability_alert`` asset on a 5-minute schedule
(see dagster_defs.py). This module provides the Dagster-logging service
subclass used there, plus an optional sensor with the same behaviour.

All alert state lives in the service's state file (see state.py); nothing is
kept in a Dagster cursor, so a sensor/asset switch or a cursor reset cannot
cause re-alerts.
"""


from dagster import DefaultSensorStatus, RunRequest, SensorEvaluationContext, SkipReason, sensor

from power_availability_alert.power_availability_alert import (
    PowerAvailabilityAlertService,
    is_business_hours,
)


class DagsterPowerAvailabilityService(PowerAvailabilityAlertService):
    """Service that logs through a Dagster context (anything with ``.log``)."""

    def __init__(self, context, recipients: str | None = None, **kwargs):
        self.context = context
        super().__init__(recipients=recipients, **kwargs)
        self.logger = context.log

    def _setup_logging(self, log_level):
        pass


def create_power_availability_sensor(
    recipients: str | None = None,
    minimum_interval_seconds: int = 300,
    default_status: DefaultSensorStatus = DefaultSensorStatus.STOPPED,
    enforce_business_hours: bool = True,
    alert_history_job=None,
):
    """Sensor variant of the scheduled asset (not used in production)."""

    @sensor(
        name="power_availability_sensor",
        minimum_interval_seconds=minimum_interval_seconds,
        job=alert_history_job,
        description="REMIT capacity change alerts (07:00-17:10 UK, Mon-Fri).",
        default_status=default_status,
    )
    def power_availability_sensor(context: SensorEvaluationContext):
        import os

        if enforce_business_hours and not is_business_hours():
            return SkipReason("Outside business hours")
        email_recipients = recipients or os.getenv("POWER_AVAILABILITY_ALERT_RECIPIENTS")
        if not email_recipients:
            return SkipReason("No email recipients configured")

        summary = DagsterPowerAvailabilityService(context, email_recipients).check_and_alert()
        sent = summary.get("alerts_sent", 0) + summary.get("teams_alerts_sent", 0)
        if sent and alert_history_job is not None:
            import json
            return RunRequest(run_config={"ops": {"power_availability_alert_history": {"config": {
                "alert_details": json.dumps(summary.get("alert_details", [])),
                "teams_breaches": json.dumps(summary.get("teams_breaches", [])),
            }}}})
        if summary.get("errors"):
            return SkipReason("Completed with errors: " + "; ".join(summary["errors"][:3]))
        return SkipReason(
            f"Email {summary.get('alerts_sent', 0)}, Teams {summary.get('teams_alerts_sent', 0)}, "
            f"pending units {summary.get('curves_with_changes', 0)}"
        )

    return power_availability_sensor
