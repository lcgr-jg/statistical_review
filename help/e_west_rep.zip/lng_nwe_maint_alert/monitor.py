"""NWE LNG terminal maintenance alert.

Every run (30 minutes by default):
  1. Pull Commodity Essentials eugasout ``Out.Total`` (mcm/d of
     maintenance / outage capacity) for NWE LNG terminals over the front
     12 months, plus recent sendout via eugasopdata.
  2. Diff against the last-alerted snapshot in cache/.
  3. Email when any terminal/day revises by at least 5 mcm/d.

Run:  python monitor.py                 one check
      python monitor.py --loop          poll forever (cfg poll_minutes)
      python monitor.py --dry-run       print instead of emailing / writing cache
The Dagster schedule (dagster_defs.py) calls run_once() every 30 minutes.
"""
from __future__ import annotations

import argparse
import configparser
import json
import logging
import platform
import sys
import time
import traceback
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
from dateutil.relativedelta import relativedelta

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.util.htmlutils import df2html

logger = logging.getLogger(__name__)

REPORTS_PATH = Path(__file__).parent.resolve()
CACHE_DIR = REPORTS_PATH / "cache"
LATEST_FILE = CACHE_DIR / "latest_maint.parquet"
REFERENCE_FILE = CACHE_DIR / "alert_reference.parquet"
TECH_CAPS_FILE = CACHE_DIR / "tech_caps.json"
META_FILE = CACHE_DIR / "meta.json"

FROM_ADDRESS = "eu.gap.reports@jainglobal.com"

# Same CE terminal IDs as lng_st_summary (Fos C/T, no Le Havre, WH combined)
LNG_TERMINAL_ASSET_IDS = [
    663,
    3198,
    3312,
    3197,  # Wilhelmshaven (combined)
    184,
    200,  # Fos Cavaou
    201,  # Fos Tonkin
    181,
    164,
    167,
    165,
    1793,
    1795,
    3247,
    3412,
    1794,
    3136,
    214,
]

COUNTRY_ORDER = ["BE", "NL", "FR", "GB", "DE", "IT"]
ZONE_LABEL = "NWE (BE, NL, FR, GB, DE, IT)"

REPORT_FONT_FAMILY = "Calibri"
REPORT_FONT_SIZE = "14"

# Out.Total Δ > 0 = more maintenance = reduced available regas
COLOR_REDUCED = "#b71c1c"
COLOR_INCREASED = "#1b5e20"
COLOR_REDUCED_BG = "#ffcdd2"
COLOR_INCREASED_BG = "#c8e6c9"
WEEKEND_BG = "#B3C8CF"
TODAY_BG = "#ffef96"
EPS = 0.05


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config() -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    config.read(REPORTS_PATH / "lng_nwe_maint_alert.cfg")
    return config


def get_receivers(config: configparser.ConfigParser) -> tuple[str, str]:
    receivers = config.get("ReportSettings", "receivers")
    error_receivers = config.get("ReportSettings", "error_receivers")
    if platform.system().lower() == "windows":
        receivers = "john.morley@jainglobal.com"
        error_receivers = "john.morley@jainglobal.com"
    return receivers, error_receivers


def _monitor_settings(config: configparser.ConfigParser) -> dict:
    cfg = config["Monitor"]
    return {
        "poll_minutes": cfg.getfloat("poll_minutes", fallback=30.0),
        "horizon_months": cfg.getint("horizon_months", fallback=12),
        "cache_buffer_days": cfg.getint("cache_buffer_days", fallback=31),
        "days_back": cfg.getint("days_back", fallback=7),
        "days_forward_daily": cfg.getint("days_forward_daily", fallback=14),
        "min_daily_delta_mcm": cfg.getfloat("min_daily_delta_mcm", fallback=5.0),
    }


# ---------------------------------------------------------------------------
# CE pull
# ---------------------------------------------------------------------------

def _col_key(country: str, terminal: str) -> str:
    return f"{country}|{terminal}"


def _split_key(key: str) -> tuple[str, str]:
    country, terminal = key.split("|", 1)
    return country, terminal


def _country_sort_key(country: str) -> tuple[int, str]:
    try:
        return COUNTRY_ORDER.index(country), country
    except ValueError:
        return len(COUNTRY_ORDER), country


def _sort_columns(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    return df.reindex(columns=sorted(df.columns, key=lambda c: (_country_sort_key(c.split("|", 1)[0]), c)))


def _display_header(key: str, tech_caps: dict[str, float]) -> tuple[str, str]:
    country, terminal = _split_key(key)
    cap = tech_caps.get(terminal)
    if cap is not None and pd.notna(cap):
        return country, f"{terminal} ({cap:.0f})"
    return country, terminal


def fetch_ce_data(
    ce_user: str,
    ce_pass: str,
    *,
    days_back: int,
    horizon_months: int,
    cache_buffer_days: int,
) -> dict:
    """Pull maintenance (Out.Total) and recent terminal sendout from CE."""
    ce = CElink(ce_user, ce_pass)
    ce_metadata_spa = ce.eugasmeta(id="seriesperasset")

    today = pd.Timestamp.today().normalize()
    start_date = today - timedelta(days=days_back)
    horizon_end = today + relativedelta(months=horizon_months)
    cache_end = horizon_end + timedelta(days=cache_buffer_days)

    df_maint = ce.eugasout(
        assets=LNG_TERMINAL_ASSET_IDS,
        unit="mcm",
        variable="withdrawal",
        dateFrom=start_date.strftime("%Y-%m-%d"),
        dateTo=cache_end.strftime("%Y-%m-%d"),
    )
    if df_maint is None or df_maint.empty:
        raise RuntimeError("CE eugasout returned no LNG terminal maintenance data")

    df_maint["Date"] = pd.to_datetime(df_maint["Date"], format="%d-%b-%Y")
    if "Updated" in df_maint.columns:
        df_maint["Updated"] = pd.to_datetime(df_maint["Updated"], format="%d-%b-%Y", errors="coerce")
    df_maint["Out.Total"] = df_maint["Out.Total"].fillna(0)
    df_maint["key"] = df_maint["Market"].astype(str) + "|" + df_maint["assetName"].astype(str)

    latest_caps = (
        df_maint.sort_values("Updated", ascending=False, na_position="last")
        .drop_duplicates("assetName")[["assetName", "Tech.Cap"]]
        if "Updated" in df_maint.columns
        else df_maint.drop_duplicates("assetName")[["assetName", "Tech.Cap"]]
    )
    tech_caps = {
        row["assetName"]: float(row["Tech.Cap"])
        for _, row in latest_caps.iterrows()
        if pd.notna(row["Tech.Cap"])
    }

    df_outage = df_maint.pivot_table(
        index="Date",
        columns="key",
        values="Out.Total",
        aggfunc="first",
    )
    df_outage = df_outage.sort_index()
    df_outage = _sort_columns(df_outage).fillna(0)

    df_regas = ce.eugasopdata(
        assets=LNG_TERMINAL_ASSET_IDS,
        unit="mcm",
        variable="withdrawal",
        dateFrom=start_date.strftime("%Y-%m-%d"),
        dateTo=today.strftime("%Y-%m-%d"),
    )
    if df_regas is None or df_regas.empty:
        df_regas = pd.DataFrame()
    else:
        df_regas = df_regas.set_index("Date")
        if "DateExcel" in df_regas.columns:
            df_regas = df_regas.drop(columns=["DateExcel"])
        df_regas.index = pd.to_datetime(df_regas.index)
        renamed = []
        for c in df_regas.columns:
            try:
                meta = ce_metadata_spa[ce_metadata_spa["seriesId"] == int(c)].iloc[0]
                renamed.append(_col_key(str(meta["direction"]), str(meta["assetName"])))
            except Exception:
                renamed.append(str(c))
        df_regas.columns = renamed
        df_regas = _sort_columns(df_regas)

    return {
        "today": today,
        "horizon_end": horizon_end,
        "df_outage": df_outage,
        "df_regas": df_regas,
        "tech_caps": tech_caps,
    }


def _slice_horizon(df: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.loc[(df.index >= start) & (df.index <= end)].copy()
    idx = pd.date_range(start, end, freq="D")
    return out.reindex(idx).fillna(0)


def _to_display(df: pd.DataFrame, tech_caps: dict[str, float], total_label: str) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    out.columns = pd.MultiIndex.from_tuples(
        [_display_header(c, tech_caps) for c in out.columns],
        names=["Country", "Terminal"],
    )
    out[("Total", total_label)] = out.sum(axis=1)
    return out


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

def _ensure_cache_dir() -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)


def _save_parquet(path: Path, df: pd.DataFrame) -> None:
    _ensure_cache_dir()
    out = df.copy()
    out.index = pd.to_datetime(out.index)
    try:
        out.to_parquet(path)
    except ImportError:
        out.to_pickle(path.with_suffix(".pkl"))


def _load_parquet(path: Path) -> pd.DataFrame | None:
    pickle_path = path.with_suffix(".pkl")
    if path.exists():
        df = pd.read_parquet(path)
    elif pickle_path.exists():
        df = pd.read_pickle(pickle_path)
    else:
        return None
    df.index = pd.to_datetime(df.index)
    return _sort_columns(df.fillna(0))


def _save_tech_caps(tech_caps: dict[str, float]) -> None:
    _ensure_cache_dir()
    TECH_CAPS_FILE.write_text(json.dumps(tech_caps), encoding="utf-8")


def _save_meta(payload: dict) -> None:
    _ensure_cache_dir()
    META_FILE.write_text(json.dumps(payload, default=str), encoding="utf-8")


# ---------------------------------------------------------------------------
# Diff / period collapse
# ---------------------------------------------------------------------------

def align_schedules(
    current: pd.DataFrame,
    reference: pd.DataFrame,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Align current vs last-alerted on the alert horizon.

    Dates beyond the previous reference's max index are excluded so a rolling
    window does not look like new maintenance. The cache stores a buffer past
    the horizon so those days already have a reference value.
    """
    cols = sorted(set(current.columns) | set(reference.columns))
    cur = _slice_horizon(current.reindex(columns=cols).fillna(0), start, end)
    ref = _slice_horizon(reference.reindex(columns=cols).fillna(0), start, end)
    if not reference.empty:
        ref_max = pd.Timestamp(reference.index.max()).normalize()
        keep = cur.index[cur.index <= ref_max]
        cur = cur.loc[keep]
        ref = ref.reindex(keep).fillna(0)
    return _sort_columns(cur), _sort_columns(ref)


def significant_mask(delta: pd.DataFrame, threshold: float) -> pd.DataFrame:
    return delta.abs() >= threshold


def collapse_periods(
    current: pd.DataFrame,
    reference: pd.DataFrame,
    delta: pd.DataFrame,
    threshold: float,
) -> pd.DataFrame:
    """Collapse consecutive days with the same daily Δ into period rows."""
    rows: list[dict] = []
    mask = significant_mask(delta, threshold)
    for col in delta.columns:
        hit_dates = delta.index[mask[col]].sort_values()
        if hit_dates.empty:
            continue
        country, terminal = _split_key(col)

        def _round_tuple(ts: pd.Timestamp) -> tuple[float, float, float]:
            prev = float(reference.at[ts, col]) if ts in reference.index else 0.0
            new = float(current.at[ts, col]) if ts in current.index else 0.0
            dlt = float(delta.at[ts, col])
            return (round(prev, 1), round(new, 1), round(dlt, 1))

        start = prev_date = hit_dates[0]
        prev_key = _round_tuple(start)
        for ts in hit_dates[1:]:
            key = _round_tuple(ts)
            if (ts - prev_date).days == 1 and key == prev_key:
                prev_date = ts
                continue
            rows.append(_period_row(country, terminal, start, prev_date, prev_key))
            start = prev_date = ts
            prev_key = key
        rows.append(_period_row(country, terminal, start, prev_date, prev_key))

    if not rows:
        return pd.DataFrame()
    out = pd.DataFrame(rows)
    out["_co"] = out["Country"].map(_country_sort_key)
    out = out.sort_values(["_co", "Terminal", "Period start"]).drop(columns="_co")
    return out.reset_index(drop=True)


def _available_regas_label(delta_out_total: float) -> str:
    """Out.Total Δ > 0 = new maintenance = reduced available regas."""
    if delta_out_total > EPS:
        return "reduced"
    if delta_out_total < -EPS:
        return "increased"
    return "unchanged"


def _period_row(
    country: str,
    terminal: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    key: tuple[float, float, float],
) -> dict:
    prev, new, dlt = key
    days = int((end - start).days) + 1
    return {
        "Country": country,
        "Terminal": terminal,
        "Period start": start,
        "Period end": end,
        "Period": _format_period(start, end),
        "Days": days,
        "Prev mcm/d": prev,
        "New mcm/d": new,
        "Daily Δ": dlt,
        "Cumulative mcm": round(dlt * days, 1),
        "Available Regas": _available_regas_label(dlt),
    }


def _format_period(start: pd.Timestamp, end: pd.Timestamp) -> str:
    if start == end:
        return start.strftime("%d %b")
    if start.year == end.year:
        return f"{start.strftime('%d %b')} – {end.strftime('%d %b')}"
    return f"{start.strftime('%d %b %Y')} – {end.strftime('%d %b %Y')}"


def cumulative_tables(
    delta: pd.DataFrame,
    periods: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame | None]:
    """Per-terminal (and country, if more than one change) sum of daily Δ."""
    if delta.empty or periods.empty:
        return pd.DataFrame(), None

    fired_cols = []
    for col in delta.columns:
        country, terminal = _split_key(col)
        if ((periods["Country"] == country) & (periods["Terminal"] == terminal)).any():
            fired_cols.append(col)

    if not fired_cols:
        return pd.DataFrame(), None

    records = []
    for col in fired_cols:
        country, terminal = _split_key(col)
        cumul = float(delta[col].sum())
        records.append({
            "Country": country,
            "Terminal": terminal,
            "Cumulative Δ mcm": round(cumul, 1),
            "Available Regas": _available_regas_label(cumul),
        })
    terminal_tbl = pd.DataFrame(records)
    nwe_cumul = float(terminal_tbl["Cumulative Δ mcm"].sum())
    terminal_tbl = pd.concat(
        [
            terminal_tbl,
            pd.DataFrame([{
                "Country": "NWE",
                "Terminal": "Total",
                "Cumulative Δ mcm": round(nwe_cumul, 1),
                "Available Regas": _available_regas_label(nwe_cumul),
            }]),
        ],
        ignore_index=True,
    )

    country_tbl = None
    n_terminals = periods[["Country", "Terminal"]].drop_duplicates().shape[0]
    if n_terminals > 1 or len(periods) > 1:
        grp = (
            terminal_tbl[terminal_tbl["Terminal"] != "Total"]
            .groupby("Country", as_index=False)["Cumulative Δ mcm"]
            .sum()
        )
        grp["Cumulative Δ mcm"] = grp["Cumulative Δ mcm"].round(1)
        grp["Available Regas"] = grp["Cumulative Δ mcm"].map(_available_regas_label)
        country_tbl = grp.sort_values("Country", key=lambda s: s.map(_country_sort_key))
    return terminal_tbl, country_tbl


def monthly_view(
    current: pd.DataFrame,
    reference: pd.DataFrame,
    tech_caps: dict[str, float],
) -> pd.DataFrame:
    """Monthly sum of daily Out.Total (mcm of scheduled maintenance) plus Δ vs reference."""
    if current.empty:
        return pd.DataFrame()

    def _monthly(df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return pd.DataFrame()
        m = df.copy()
        m.index = pd.to_datetime(m.index)
        return m.groupby(m.index.to_period("M")).sum()

    cur_m = _monthly(current)
    ref_m = _monthly(reference).reindex(index=cur_m.index, columns=cur_m.columns).fillna(0)
    dlt_m = cur_m - ref_m

    keep_cols = [
        c for c in cur_m.columns
        if (cur_m[c].abs().sum() > EPS) or (dlt_m[c].abs().sum() > EPS)
    ]
    if not keep_cols:
        keep_cols = list(cur_m.columns)
    cur_m = _sort_columns(cur_m[keep_cols])
    dlt_m = _sort_columns(dlt_m[keep_cols])

    country_cur = _country_monthly(cur_m)
    country_dlt = _country_monthly(dlt_m)
    nwe_cur = cur_m.sum(axis=1).rename("NWE|Total")
    nwe_dlt = dlt_m.sum(axis=1).rename("NWE|Total")

    cur_all = pd.concat([cur_m, country_cur, nwe_cur], axis=1)
    dlt_all = pd.concat([dlt_m, country_dlt, nwe_dlt], axis=1)
    ordered = []
    for country in sorted({_split_key(c)[0] for c in cur_m.columns}, key=_country_sort_key):
        ordered.extend(sorted(c for c in cur_m.columns if _split_key(c)[0] == country))
        country_total = f"{country}|{country} total"
        if country_total in cur_all.columns:
            ordered.append(country_total)
    ordered.append("NWE|Total")
    cur_all = cur_all.reindex(columns=ordered)
    dlt_all = dlt_all.reindex(columns=ordered)

    frames = []
    for period in cur_m.index:
        label = period.strftime("%b-%y")
        cur_row = cur_all.loc[period]
        dlt_row = dlt_all.loc[period]
        part = pd.DataFrame({(label, "Current"): cur_row, (label, "Δ"): dlt_row})
        frames.append(part)
    out = pd.concat(frames, axis=1)
    out.index = pd.MultiIndex.from_tuples(
        [_monthly_index_label(c, tech_caps) for c in out.index],
        names=["Country", "Terminal"],
    )
    return out


def _country_monthly(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    grouped = {}
    for col in df.columns:
        country, _ = _split_key(col)
        grouped.setdefault(country, [])
        grouped[country].append(col)
    parts = {
        f"{country}|{country} total": df[cols].sum(axis=1)
        for country, cols in grouped.items()
        if len(cols) > 1
    }
    if not parts:
        return pd.DataFrame()
    return pd.DataFrame(parts)


def _monthly_index_label(key: str, tech_caps: dict[str, float]) -> tuple[str, str]:
    country, terminal = _split_key(key)
    if terminal.endswith(" total") or terminal == "Total":
        return country, terminal
    return _display_header(key, tech_caps)


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------

def _html_context_table(
    df: pd.DataFrame,
    tech_caps: dict[str, float],
    total_label: str,
    *,
    change_delta: pd.DataFrame | None = None,
    threshold: float | None = None,
) -> str:
    if df is None or df.empty:
        return "<p>No data.</p>"
    display = _to_display(df, tech_caps, total_label)
    if change_delta is None or threshold is None:
        return df2html(
            display.copy(),
            precision=0,
            font_size=REPORT_FONT_SIZE,
            font_family=REPORT_FONT_FAMILY,
            highlight_weekends=True,
            index_dt_format="%d-%b-%Y",
            highlight_today=True,
        )
    return _html_maint_table_with_changes(display, df.columns, change_delta, threshold, tech_caps)


def _change_cell_css(delta_value: float, threshold: float) -> str:
    if abs(delta_value) < threshold:
        return ""
    if delta_value > 0:
        return f"background-color: {COLOR_REDUCED_BG}; color: {COLOR_REDUCED}; font-weight: bold"
    return f"background-color: {COLOR_INCREASED_BG}; color: {COLOR_INCREASED}; font-weight: bold"


def _html_maint_table_with_changes(
    display: pd.DataFrame,
    source_cols: pd.Index,
    change_delta: pd.DataFrame,
    threshold: float,
    tech_caps: dict[str, float],
) -> str:
    """Near-term maint table with weekend/today rows plus changed-cell fill."""
    display = display.copy()
    header_by_key = {key: _display_header(key, tech_caps) for key in source_cols}

    def _row_date(name) -> pd.Timestamp | None:
        try:
            return pd.Timestamp(name).normalize()
        except Exception:
            return None

    def highlight_wkend_row(s):
        dt = _row_date(s.name)
        if dt is None:
            return [""] * len(s)
        return [f"background-color: {WEEKEND_BG}"] * len(s) if dt.dayofweek >= 5 else [""] * len(s)

    def highlight_today_row(s):
        dt = _row_date(s.name)
        if dt is None:
            return [""] * len(s)
        if dt == pd.Timestamp.today().normalize():
            return [f"background-color: {TODAY_BG}"] * len(s)
        return [""] * len(s)

    def highlight_wkend_index(row):
        dt = _row_date(row)
        if dt is None:
            return ""
        return f"background-color: {WEEKEND_BG}" if dt.dayofweek >= 5 else ""

    def highlight_today_index(row):
        dt = _row_date(row)
        if dt is None:
            return ""
        return f"background-color: {TODAY_BG}" if dt == pd.Timestamp.today().normalize() else ""

    def highlight_change_cells(data: pd.DataFrame) -> pd.DataFrame:
        styles = pd.DataFrame("", index=data.index, columns=data.columns)
        if change_delta is None or change_delta.empty:
            return styles
        for key, header in header_by_key.items():
            if header not in data.columns or key not in change_delta.columns:
                continue
            for idx in data.index:
                dt = _row_date(idx)
                if dt is None or dt not in change_delta.index:
                    continue
                styles.at[idx, header] = _change_cell_css(float(change_delta.at[dt, key]), threshold)
        return styles

    styled = (
        display.style
        .apply(highlight_wkend_row, axis=1)
        .apply(highlight_today_row, axis=1)
        .apply(highlight_change_cells, axis=None)
    )
    try:
        styled = styled.map_index(highlight_wkend_index, axis="index")
        styled = styled.map_index(highlight_today_index, axis="index")
    except AttributeError:
        styled = styled.applymap_index(highlight_wkend_index, axis="index")
        styled = styled.applymap_index(highlight_today_index, axis="index")

    styled = styled.format(precision=0, thousands=",")
    styled = styled.format_index(lambda v: pd.Timestamp(v).strftime("%d-%b-%Y"), axis=0)
    styled.set_table_styles([{
        "selector": "th,td",
        "props": [
            ("padding", "1px"),
            ("border-style", "solid"),
            ("border-width", "1px"),
            ("font-size", f"{REPORT_FONT_SIZE}px"),
            ("font-family", REPORT_FONT_FAMILY),
        ],
    }])
    return styled.to_html()


def _signed_color(value: float, *, outage_sign: bool = True) -> str:
    """Colour by Out.Total Δ: + (more outage / reduced available regas) red."""
    if abs(value) <= EPS:
        return ""
    more_outage = value > 0 if outage_sign else value < 0
    return COLOR_REDUCED if more_outage else COLOR_INCREASED


def _fmt(value: float, *, precision: int = 0, signed: bool = False) -> str:
    if pd.isna(value):
        return ""
    if abs(value) <= EPS:
        return f"{0:.{precision}f}" if precision else "0"
    if signed:
        return f"{value:+,.{precision}f}"
    return f"{value:,.{precision}f}"


def _html_table(
    df: pd.DataFrame,
    *,
    signed_cols: tuple[str, ...] = (),
    color_cols: tuple[str, ...] = (),
    precision: int = 0,
    hide_cols: tuple[str, ...] = (),
) -> str:
    show = df.drop(columns=list(hide_cols), errors="ignore")
    header = "".join(f"<th>{c}</th>" for c in show.columns)
    body_rows = []
    for _, row in show.iterrows():
        cells = []
        for col in show.columns:
            val = row[col]
            color = ""
            if col in color_cols and isinstance(val, (int, float)):
                color = _signed_color(float(val))
            style = f" style='color:{color};font-weight:bold'" if color else ""
            if col in signed_cols and isinstance(val, (int, float)):
                text = _fmt(float(val), precision=precision, signed=True)
            elif isinstance(val, (int, float)) and col not in ("Days",):
                text = _fmt(float(val), precision=precision)
            else:
                text = "" if pd.isna(val) else str(val)
            if col == "Available Regas":
                if val == "reduced":
                    style = f" style='color:{COLOR_REDUCED};font-weight:bold'"
                elif val == "increased":
                    style = f" style='color:{COLOR_INCREASED};font-weight:bold'"
            cells.append(f"<td{style}>{text}</td>")
        body_rows.append("<tr>" + "".join(cells) + "</tr>")
    return (
        f"<table style='border-collapse:collapse;font-family:{REPORT_FONT_FAMILY};"
        f"font-size:{REPORT_FONT_SIZE}px' border='1' cellpadding='3'>"
        f"<thead><tr>{header}</tr></thead><tbody>{''.join(body_rows)}</table>"
    )


def _html_monthly(df: pd.DataFrame) -> str:
    if df.empty:
        return "<p>No maintenance scheduled in the front 12 months.</p>"
    # Flatten MultiIndex columns for a simple HTML table with grouped month headers
    months = []
    seen = []
    for month, kind in df.columns:
        if month not in seen:
            seen.append(month)
            months.append(month)
    header1 = "<th rowspan='2'>Country</th><th rowspan='2'>Terminal</th>" + "".join(
        f"<th colspan='2'>{m}</th>" for m in months
    )
    header2 = "".join("<th>Current</th><th>Δ</th>" for _ in months)
    body = []
    for (country, terminal), row in df.iterrows():
        cells = [f"<td>{country}</td><td>{terminal}</td>"]
        for month in months:
            cur = float(row[(month, "Current")])
            dlt = float(row[(month, "Δ")])
            dlt_color = _signed_color(dlt)
            dlt_style = f" style='color:{dlt_color};font-weight:bold'" if dlt_color else ""
            cells.append(f"<td>{_fmt(cur, precision=0)}</td>")
            cells.append(f"<td{dlt_style}>{_fmt(dlt, precision=0, signed=True)}</td>")
        is_total = terminal in ("Total",) or str(terminal).endswith("total")
        weight = " style='font-weight:bold;background-color:#f3f3f3'" if is_total else ""
        body.append(f"<tr{weight}>{''.join(cells)}</tr>")
    return (
        f"<table style='border-collapse:collapse;font-family:{REPORT_FONT_FAMILY};"
        f"font-size:{REPORT_FONT_SIZE}px' border='1' cellpadding='3'>"
        f"<thead><tr>{header1}</tr><tr>{header2}</tr></thead>"
        f"<tbody>{''.join(body)}</tbody></table>"
    )


def build_subject(periods: pd.DataFrame) -> str:
    if periods.empty:
        return "NWE LNG Maintenance Alert"
    bits = []
    ranked = periods.assign(abs_cumul=lambda d: d["Cumulative mcm"].abs()).sort_values(
        "abs_cumul", ascending=False
    )
    for _, row in ranked.head(3).iterrows():
        avail_daily = -float(row["Daily Δ"])  # available-regas sign
        avail_cumul = -float(row["Cumulative mcm"])
        bits.append(
            f"{row['Terminal']} {avail_daily:+.0f} mcm/d from "
            f"{row['Period start'].strftime('%d %b')} "
            f"(cumul {avail_cumul:+.0f} mcm)"
        )
    extra = f"; +{len(ranked) - 3} more" if len(ranked) > 3 else ""
    return "NWE LNG Maintenance Alert — " + "; ".join(bits) + extra


def build_email_body(
    *,
    pulled_at: datetime,
    periods: pd.DataFrame,
    terminal_cumul: pd.DataFrame,
    country_cumul: pd.DataFrame | None,
    monthly: pd.DataFrame,
    df_regas_near: pd.DataFrame,
    df_maint_near: pd.DataFrame,
    tech_caps: dict[str, float],
    settings: dict,
    change_delta: pd.DataFrame | None = None,
) -> str:
    change_html = _html_table(
        periods.drop(columns=["Period start", "Period end"], errors="ignore"),
        signed_cols=("Daily Δ", "Cumulative mcm"),
        color_cols=("Daily Δ", "Cumulative mcm"),
        hide_cols=("Period start", "Period end"),
    ) if not periods.empty else "<p>No period rows.</p>"

    cumul_html = _html_table(
        terminal_cumul,
        signed_cols=("Cumulative Δ mcm",),
        color_cols=("Cumulative Δ mcm",),
    ) if not terminal_cumul.empty else ""

    country_html = ""
    if country_cumul is not None and not country_cumul.empty:
        country_html = (
            "<p><b>Cumulative impact by country (mcm over {horizon} months):</b></p>".format(
                horizon=settings["horizon_months"]
            )
            + _html_table(
                country_cumul,
                signed_cols=("Cumulative Δ mcm",),
                color_cols=("Cumulative Δ mcm",),
            )
        )

    monthly_html = _html_monthly(monthly)
    regas_html = _html_context_table(df_regas_near, tech_caps, "Total Regas")
    maint_html = _html_context_table(
        df_maint_near,
        tech_caps,
        "Total Maint",
        change_delta=change_delta,
        threshold=settings.get("min_daily_delta_mcm"),
    )

    return f"""<html>
<div style="font-family: {REPORT_FONT_FAMILY}; font-size: {REPORT_FONT_SIZE}px">
<p><b>NWE LNG Terminal Maintenance Alert</b><br>
Snapshot: {pulled_at.strftime('%d %b %Y %H:%M')} UK<br>
Horizon: front {settings['horizon_months']} months &nbsp;|&nbsp;
Threshold: |daily Δ| ≥ {settings['min_daily_delta_mcm']:.0f} mcm/d
</p>
<hr>
<p><b>Changes vs last alerted schedule</b><br>
Daily Δ is the change in CE <i>Out.Total</i> (mcm/d of scheduled maintenance / outage capacity).
Positive Daily Δ = new maintenance = <span style="color:{COLOR_REDUCED};font-weight:bold">reduced</span> available regas;
negative Daily Δ = maintenance removed = <span style="color:{COLOR_INCREASED};font-weight:bold">increased</span> available regas.
This is not actual sendout: a 50 mcm/d outage against 100 mcm/d capacity has no flow impact if the terminal is only running 10 mcm/d.
</p>
{change_html}
<br>
<p><b>Cumulative maintenance Δ by terminal (mcm over {settings['horizon_months']} months):</b></p>
{cumul_html}
{country_html}
<br>
<hr>
<p><b>Monthly scheduled maintenance (mcm, front {settings['horizon_months']} months):</b><br>
Current = sum of daily Out.Total in the month. Δ vs the last-alerted schedule.
</p>
{monthly_html}
<br>Note: terminal mcm/d technical capa in column headers where shown.
<br>
<hr>
<p><b>NWE LNG Terminal Regas (mcm/d):</b></p>
{regas_html}
<br>Note: terminal mcm/d technical capa in column headers. Some nominations may be missing for the current day.
<br>
<hr>
<p><b>NWE LNG Terminal Maintenance (mcm/d, near term):</b></p>
{maint_html}
<br>Note 1: all values are daily maintenance regas impact.
<br>Note 2: terminal mcm/d technical capa in column headers.
<br>Note 3: cells highlighted <span style="background-color:{COLOR_REDUCED_BG};color:{COLOR_REDUCED};font-weight:bold">red</span> / <span style="background-color:{COLOR_INCREASED_BG};color:{COLOR_INCREASED};font-weight:bold">green</span> are dates in this window whose Out.Total changed (reduced / increased available regas).
<br>
<hr>
<p><b>Notes:</b></p>
<ul>
<li>Source: Commodity Essentials <code>eugasout</code> (variable=withdrawal, unit=mcm), column Out.Total.</li>
<li>Zone: {ZONE_LABEL}.</li>
<li>Email is sent only when any terminal/day revises by at least {settings['min_daily_delta_mcm']:.0f} mcm/d vs the last-alerted schedule.</li>
<li>Sub-threshold revisions accumulate against that reference (a 3 then +3 later still fires).</li>
<li>Available Regas is capacity-side only (maintenance added vs removed). Actual sendout impact depends on utilisation vs remaining capacity.</li>
<li>Near-term tables match the LNG NWE Cargo Forecast Change Summary window ({settings['days_back']}d back / {settings['days_forward_daily']}d forward).</li>
</ul>
</div>
</html>
"""


# ---------------------------------------------------------------------------
# Main run
# ---------------------------------------------------------------------------

def run_once(*, dry_run: bool = False, log=None) -> dict:
    """One monitor cycle. Returns a summary dict (used by the Dagster asset)."""
    log = log or logger
    config = load_config()
    receivers, _ = get_receivers(config)
    settings = _monitor_settings(config)
    ce_user = config.get("CEAPI", "user")
    ce_pass = config.get("CEAPI", "pass")

    data = fetch_ce_data(
        ce_user,
        ce_pass,
        days_back=settings["days_back"],
        horizon_months=settings["horizon_months"],
        cache_buffer_days=settings["cache_buffer_days"],
    )
    today = data["today"]
    horizon_end = data["horizon_end"]
    df_outage = data["df_outage"]
    df_regas = data["df_regas"]
    tech_caps = data["tech_caps"]
    threshold = settings["min_daily_delta_mcm"]

    near_start = today - timedelta(days=settings["days_back"])
    near_end = today + timedelta(days=settings["days_forward_daily"])
    df_regas_near = df_regas.loc[df_regas.index >= near_start].copy() if not df_regas.empty else df_regas
    df_maint_near = df_outage.loc[(df_outage.index >= near_start) & (df_outage.index <= near_end)].copy()

    reference = _load_parquet(REFERENCE_FILE)
    first_run = reference is None or reference.empty
    pulled_at = datetime.now()

    if not dry_run:
        _save_parquet(LATEST_FILE, df_outage)
        _save_tech_caps(tech_caps)
        _save_meta({"updated_at": pulled_at.isoformat(), "first_run_baseline": first_run})

    if first_run:
        if not dry_run:
            _save_parquet(REFERENCE_FILE, df_outage)
        log.info("First run — baseline only, no email")
        return {
            "email_sent": False,
            "first_run_baseline": True,
            "changed_cells": 0,
            "changed_terminals": 0,
            "horizon_start": str(today.date()),
            "horizon_end": str(horizon_end.date()),
        }

    current_h, ref_h = align_schedules(df_outage, reference, today, horizon_end)
    delta = current_h - ref_h
    mask = significant_mask(delta, threshold)
    n_cells = int(mask.to_numpy().sum())
    changed_terminals = [c for c in delta.columns if mask[c].any()]

    if n_cells == 0:
        log.info("No significant maintenance revisions — no email")
        return {
            "email_sent": False,
            "first_run_baseline": False,
            "changed_cells": 0,
            "changed_terminals": 0,
            "horizon_start": str(today.date()),
            "horizon_end": str(horizon_end.date()),
        }

    periods = collapse_periods(current_h, ref_h, delta, threshold)
    terminal_cumul, country_cumul = cumulative_tables(delta, periods)
    monthly = monthly_view(current_h, ref_h, tech_caps)
    subject = build_subject(periods)
    body = build_email_body(
        pulled_at=pulled_at,
        periods=periods,
        terminal_cumul=terminal_cumul,
        country_cumul=country_cumul,
        monthly=monthly,
        df_regas_near=df_regas_near,
        df_maint_near=df_maint_near,
        tech_caps=tech_caps,
        settings=settings,
        change_delta=delta,
    )

    if dry_run:
        log.info("[dry-run] would send email: %s", subject)
        log.info("[dry-run] %d significant cell(s) across %d terminal(s)", n_cells, len(changed_terminals))
        print(subject)
        print(body)
    else:
        send_email(receivers, subject, body, from_address=FROM_ADDRESS)
        _save_parquet(REFERENCE_FILE, df_outage)
        log.info("Alert email sent to %s: %s", receivers, subject)

    return {
        "email_sent": not dry_run,
        "first_run_baseline": False,
        "changed_cells": n_cells,
        "changed_terminals": len(changed_terminals),
        "subject": subject,
        "horizon_start": str(today.date()),
        "horizon_end": str(horizon_end.date()),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="NWE LNG terminal maintenance alert")
    parser.add_argument("--loop", action="store_true",
                        help="poll forever every [Monitor] poll_minutes")
    parser.add_argument("--interval", type=float, default=None,
                        help="loop interval in minutes (overrides cfg)")
    parser.add_argument("--dry-run", action="store_true",
                        help="do not email or update caches; log what would happen")
    args = parser.parse_args()

    log_path = REPORTS_PATH / "log"
    log_path.mkdir(exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_path / "lng_nwe_maint_alert.log"),
        ],
    )

    config = load_config()
    _, error_receivers = get_receivers(config)
    interval_min = args.interval or config.getfloat("Monitor", "poll_minutes", fallback=30.0)

    if not args.loop:
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Done: %s", summary)
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            if not args.dry_run:
                send_email(error_receivers, "ERROR NWE LNG Maintenance Alert", str(tb))
            sys.exit(1)
        return

    logger.info("Looping every %.1f minutes (Ctrl+C to stop)", interval_min)
    in_error_streak = False
    while True:
        started = time.monotonic()
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Cycle done: %s", summary)
            in_error_streak = False
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            if not in_error_streak and not args.dry_run:
                send_email(error_receivers, "ERROR NWE LNG Maintenance Alert", str(tb))
            in_error_streak = True
        elapsed = time.monotonic() - started
        time.sleep(max(30.0, interval_min * 60 - elapsed))


if __name__ == "__main__":
    main()
