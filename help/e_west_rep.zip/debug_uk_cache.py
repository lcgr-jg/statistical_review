"""
Debug script: Check what UK data is available in cache and why it's not loading.
"""
import sys
import os
corelib_path = 'c:/Users/Michael.Kane/OneDrive - Jain Global/Projects/eu_corelib'
if os.path.exists(corelib_path) and corelib_path not in sys.path:
    sys.path.insert(0, corelib_path)

import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import urllib3
import botocore

print("=" * 70)
print("ENVIRONMENT CHECK")
print("=" * 70)
print(f"  Python:    {sys.executable}")
print(f"  urllib3:   {urllib3.__version__} ({urllib3.__file__})")
print(f"  botocore:  {botocore.__version__}")
print()

print("=" * 70)
print("1. POWER CACHE (PricePowerSpot)")
print("=" * 70)
try:
    from jain_commods.core.cache.data.market import PricePowerSpot
    p = PricePowerSpot(freq='h')
    print(f"  storage_type: {p.storage_type}")
    p.load(from_s3=True, show_metadata=False)
    if p.data is not None and not p.data.empty:
        print(f"  Shape: {p.data.shape}")
        zones = sorted(set(c[0] for c in p.data.columns))
        print(f"  Zones in cache: {zones}")
        gb_cols = [c for c in p.data.columns if c[0] == 'GB']
        print(f"  GB columns ({len(gb_cols)}):")
        for c in gb_cols:
            vals = p.data[c].dropna()
            print(f"    {c}  ->  {len(vals)} values, range: {vals.min():.2f} to {vals.max():.2f}")
        uk_cols = [c for c in p.data.columns if c[0] == 'UK']
        print(f"  UK columns ({len(uk_cols)}): {uk_cols}")
        print()
        print("  ** KEY: Power cache stores UK as 'GB', not 'UK' **")
        print("  ** price_report.py zone_map: {'UK': 'GB'} maps this correctly **")
    else:
        print("  EMPTY / None")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")
print()

print("=" * 70)
print("2. GAS CACHE (PriceGasSpot)")
print("=" * 70)
try:
    from jain_commods.core.cache.data.market import PriceGasSpot
    g = PriceGasSpot()
    g.load(from_s3=True, show_metadata=False)
    if g.data is not None and not g.data.empty:
        print(f"  Shape: {g.data.shape}")
        hubs = sorted(set(str(c[0]) for c in g.data.columns))
        print(f"  Hubs in cache: {hubs}")
        for hub in ['TTF', 'NBP']:
            hub_cols = [c for c in g.data.columns if hub in str(c[0]).upper()]
            if hub_cols:
                vals = g.data[hub_cols[0]].dropna()
                print(f"  {hub}: col={hub_cols[0]}, {len(vals)} values, last={vals.iloc[-1]:.2f} ({vals.index[-1].date()})")
            else:
                print(f"  {hub}: NOT FOUND")
    else:
        print("  EMPTY / None")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")
print()

print("=" * 70)
print("3. CARBON CACHE (PriceCO2Spot)")
print("=" * 70)
try:
    from jain_commods.core.cache.data.market import PriceCO2Spot
    co2 = PriceCO2Spot()
    co2.load(from_s3=True, show_metadata=False)
    if co2.data is not None and not co2.data.empty:
        print(f"  Shape: {co2.data.shape}")
        labels = sorted(set(str(c[0]) for c in co2.data.columns))
        print(f"  Labels in cache: {labels}")
        for label in ['EUA', 'UKA']:
            label_cols = [c for c in co2.data.columns if label in str(c[0]).upper()]
            if label_cols:
                vals = co2.data[label_cols[0]].dropna()
                ccy = label_cols[0][1] if len(label_cols[0]) > 1 else '?'
                print(f"  {label}: col={label_cols[0]}, ccy={ccy}, {len(vals)} values, last={vals.iloc[-1]:.2f}")
            else:
                print(f"  {label}: NOT FOUND")
    else:
        print("  EMPTY / None")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")
print()

print("=" * 70)
print("4. FOREX CACHE (ForexSpot)")
print("=" * 70)
try:
    from jain_commods.core.cache.data.market import ForexSpot
    fx = ForexSpot()
    fx.load(from_s3=True, show_metadata=False)
    if fx.data is not None and not fx.data.empty:
        print(f"  Shape: {fx.data.shape}")
        pairs = [str(c) for c in fx.data.columns]
        print(f"  Pairs: {pairs[:20]}{'...' if len(pairs) > 20 else ''}")
        for target in ['EUR_GBP', 'EUR/GBP', 'GBP']:
            matching = [c for c in fx.data.columns if target in str(c).upper()]
            if matching:
                vals = fx.data[matching[0]].dropna()
                print(f"  {target}: col={matching[0]}, {len(vals)} values, last={vals.iloc[-1]:.4f}")
    else:
        print("  EMPTY / None")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")
print()

print("=" * 70)
print("5. SIMULATING price_report.py load_power for UK")
print("=" * 70)
try:
    p2 = PricePowerSpot(freq='h')
    p2.load(from_s3=True, show_metadata=False)
    raw = p2.data
    if raw is not None and not raw.empty:
        zone_map = {'UK': 'GB'}
        cc = 'UK'
        cache_zone = zone_map.get(cc, cc)
        preferred_ccy = 'GBP'

        cols_gbp = [c for c in raw.columns if c[0].upper() == cache_zone.upper() and c[2] == preferred_ccy]
        print(f"  GB columns with GBP: {cols_gbp}")

        cols_any = [c for c in raw.columns if c[0].upper() == cache_zone.upper()]
        print(f"  GB columns (any ccy): {cols_any}")

        if cols_gbp:
            series = raw[cols_gbp[0]].dropna()
            print(f"  Using: {cols_gbp[0]}")
            print(f"  Values: {len(series)}, range: {series.min():.2f} to {series.max():.2f}")
            print(f"  Date range: {series.index[0]} to {series.index[-1]}")
            print(f"  Last 5 values:")
            for dt, val in series.tail().items():
                print(f"    {dt}: {val:.2f}")
        else:
            print("  NO GBP columns found for GB!")
    else:
        print("  Power cache is empty/None - this is the problem")
        print("  The S3 cache load failed (issubclass error) AND no local cache exists")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")
print()

print("=" * 70)
print("6. SIMULATING price_report.py load_gas for UK (NBP)")
print("=" * 70)
try:
    g2 = PriceGasSpot()
    g2.load(from_s3=True, show_metadata=False)
    raw_g = g2.data
    if raw_g is not None and not raw_g.empty:
        for hub_name in ['TTF', 'NBP']:
            cols = [c for c in raw_g.columns if hub_name in str(c[0]).upper()]
            if cols:
                series = raw_g[cols[0]].dropna()
                print(f"  {hub_name}: {cols[0]}, {len(series)} values, last={series.iloc[-1]:.2f}")
            else:
                print(f"  {hub_name}: NOT FOUND in cache columns")
                print(f"    All column level-0 values: {sorted(set(str(c[0]) for c in raw_g.columns))}")
    else:
        print("  Gas cache is empty/None")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")
print()

print("=" * 70)
print("SUMMARY")
print("=" * 70)
print("""
If all sections above show data successfully:
  -> The S3 cache works fine from this Python.
  -> The issubclass() errors in your terminal are an environment issue.
  -> The report WILL work once cache loads succeed.

If sections show 'FAILED':
  -> That specific cache is not loading from S3.
  -> Check the error message for details.

For UK specifically, price_report.py needs:
  1. Power: PricePowerSpot -> 'GB' zone with 'GBP' currency
  2. Gas:   PriceGasSpot   -> 'NBP' hub (in EUR/MWh, converted to GBP)
  3. CO2:   PriceCO2Spot   -> 'UKA' label (in GBP/t) + 18 GBP/t carbon tax
  4. FX:    ForexSpot      -> EUR/GBP rate for gas conversion
""")
