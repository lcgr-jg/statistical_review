import anthropic
import pandas as pd
import json
import re
import logging
import markdown
import requests

from datetime import date, datetime, timedelta
from typing import Optional, Union

import holidays


logger = logging.getLogger(__name__)


# Platts publishes regional pricing holiday schedules here (not available via spgci).
PLATTS_HOLIDAY_SCHEDULE_URL = (
    "https://www.spglobal.com/energy/en/pricing-benchmarks/our-methodology/holiday"
)


def _as_date(d: Union[date, datetime, pd.Timestamp]) -> date:
    if isinstance(d, datetime):
        return d.date()
    if isinstance(d, pd.Timestamp):
        return d.date()
    return d


def singapore_holiday_calendar(*years: int):
    """Singapore national public holidays (incl. observed Mondays)."""
    yrs = years or (datetime.now().year,)
    return holidays.Singapore(years=yrs)


def singapore_holiday_name(d: Union[date, datetime, pd.Timestamp]) -> Optional[str]:
    """Return the Singapore public-holiday name for `d`, or None if not a holiday."""
    day = _as_date(d)
    sg = singapore_holiday_calendar(day.year - 1, day.year, day.year + 1)
    return sg.get(day)


def is_singapore_holiday(d: Union[date, datetime, pd.Timestamp]) -> bool:
    return singapore_holiday_name(d) is not None


def botes_is_empty(df: Optional[pd.DataFrame]) -> bool:
    """True when Platts returned no usable BOTE rows (incl. columnless empty frames)."""
    if df is None or df.empty:
        return True
    return not {"market_maker", "order_type", "order_id"}.intersection(df.columns)


def explain_empty_botes_day(d: Union[date, datetime, pd.Timestamp]) -> Optional[str]:
    """
    If `d` is a Singapore public holiday, return a short confirmation string.
    Used when a BOTE query comes back empty.
    """
    name = singapore_holiday_name(d)
    if not name:
        return None
    day = _as_date(d)
    return (
        f"{day.strftime('%d %b %Y')} is a Singapore public holiday ({name}); "
        "JKM Physical typically does not run."
    )


def holiday_notice_markdown(session_date: Union[date, datetime], *, holiday_name: str) -> str:
    """Markdown body for a holiday / no-window notice."""
    day = _as_date(session_date)
    date_str = day.strftime("%d %B %Y")
    return "\n".join([
        f"## Platts JKM LNG — Potential Pricing Holiday — {date_str}",
        "",
        f"**{date_str}** looks like a **Singapore public holiday** ({holiday_name}).",
        "",
        "No usable JKM Physical BOTE data was returned for today. The Asia LNG "
        "physical window generally does not run on Singapore national public holidays.",
        "",
        "Please confirm against the Platts pricing holiday schedule:",
        f"- {PLATTS_HOLIDAY_SCHEDULE_URL}",
        "",
        "_No MOC snapshot / summary will be generated for this session._",
    ])


def holiday_notice_email_html(session_date: Union[date, datetime], *, holiday_name: str) -> str:
    """Simple HTML email noting today is likely a Platts/SG holiday."""
    day = _as_date(session_date)
    date_str = day.strftime("%d %B %Y")
    return f"""\
<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#222;line-height:1.5;">
  <h2 style="color:#0f2044;">Platts JKM LNG — Potential Pricing Holiday — {date_str}</h2>
  <p><strong>{date_str}</strong> looks like a <strong>Singapore public holiday</strong>
  ({holiday_name}).</p>
  <p>No usable JKM Physical BOTE data was returned for today. The Asia LNG physical
  window generally does not run on Singapore national public holidays.</p>
  <p>Please confirm against the Platts pricing holiday schedule:<br>
  <a href="{PLATTS_HOLIDAY_SCHEDULE_URL}">{PLATTS_HOLIDAY_SCHEDULE_URL}</a></p>
  <p style="color:#666;font-size:13px;"><em>No MOC summary emails will be generated
  for this session.</em></p>
</body></html>
"""


def send_teams_holiday_notice(
    webhook_url: str,
    session_date: Union[date, datetime],
    *,
    holiday_name: str,
) -> None:
    """Post a short Teams notice that today is a likely Singapore/Platts holiday."""
    day = _as_date(session_date)
    date_str = day.strftime("%d %B %Y")
    title = f"Platts JKM LNG — Potential Pricing Holiday — {date_str}"
    body_text = (
        f"**{date_str}** looks like a **Singapore public holiday** ({holiday_name}).\n\n"
        "No usable JKM Physical BOTE data was returned for today. The Asia LNG "
        "physical window generally does not run on Singapore national public holidays.\n\n"
        f"Platts holiday schedule: {PLATTS_HOLIDAY_SCHEDULE_URL}"
    )

    if _is_workflow_webhook(webhook_url):
        payload = _workflow_payload([
            {
                "type": "TextBlock",
                "text": f"**{title}**",
                "size": "Medium",
                "weight": "Bolder",
                "wrap": True,
            },
            {
                "type": "TextBlock",
                "text": body_text,
                "wrap": True,
                "spacing": "Small",
            },
            {
                "type": "TextBlock",
                "text": f"[Open Platts holiday schedule]({PLATTS_HOLIDAY_SCHEDULE_URL})",
                "wrap": True,
                "spacing": "Medium",
            },
        ])
    else:
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0f2044",
            "summary": title,
            "sections": [{
                "activityTitle": f"**{title}**",
                "text": (
                    f"<p><strong>{date_str}</strong> looks like a "
                    f"<strong>Singapore public holiday</strong> ({holiday_name}).</p>"
                    "<p>No usable JKM Physical BOTE data was returned for today. "
                    "The Asia LNG physical window generally does not run on "
                    "Singapore national public holidays.</p>"
                    f'<p><a href="{PLATTS_HOLIDAY_SCHEDULE_URL}">'
                    "Platts pricing holiday schedule</a></p>"
                ),
                "markdown": True,
            }],
            "potentialAction": [{
                "@type": "OpenUri",
                "name": "Platts holiday schedule",
                "targets": [{"os": "default", "uri": PLATTS_HOLIDAY_SCHEDULE_URL}],
            }],
        }

    _post_teams(webhook_url, payload, label="Teams holiday notice")


# ---------------------------------------------------------------------------
# Helper: compress a dataframe to the key analytical facts Claude needs
# ---------------------------------------------------------------------------

def _prepare_physical_context(df: pd.DataFrame) -> dict:
    """
    Extract structured facts from a physical MOC dataframe.
    Returns a dict that is serialised to JSON for the prompt.
    """
    df = df.copy()

    # ---- Trades ------------------------------------------------------------
    trades = df[df["order_state"] == "consummated"].copy()
    trade_records = []
    for _, row in trades.iterrows():
        trade_records.append({
            "time":          str(row.get("order_time", ""))[:19],
            "buyer":         row.get("buyer", ""),
            "seller":        row.get("seller", ""),
            "price_basis":   row.get("c1_price_basis", ""),
            "price":         row.get("c1_price", 0),
            "basis_period":  row.get("c1_basis_period", ""),
            "delivery_begin":str(row.get("deal_begin", "")),
            "delivery_end":  str(row.get("deal_end", "")),
            "quantity_tbtu": row.get("deal_quantity", 3.3),
            "deal_terms":    str(row.get("deal_terms", ""))[:200],
        })

    # ---- Withdrawn orders --------------------------------------------------
    withdrawn = df[df["order_state"] == "withdrawn"].copy()
    wdn_records = []
    for _, row in withdrawn.iterrows():
        wdn_records.append({
            "market_maker":  row.get("market_maker", ""),
            "order_type":    row.get("order_type", ""),
            "price_basis":   row.get("c1_price_basis", ""),
            "price":         row.get("c1_price", 0),
            "delivery_begin":str(row.get("order_begin", "")),
            "delivery_end":  str(row.get("order_end", "")),
            "deal_terms":    str(row.get("deal_terms", ""))[:150],
            "state_detail":  row.get("order_state_detail", ""),
        })

    # ---- Price trajectories per order -------------------------------------
    trajectories = []
    for oid, grp in df.groupby("order_id"):
        g = grp.sort_values("order_sequence")
        prices = g["c1_price"].tolist()
        if len(prices) < 1:
            continue
        trajectories.append({
            "market_maker":  g["market_maker"].iloc[0],
            "order_type":    g["order_type"].iloc[0],
            "delivery_begin":str(g["order_begin"].iloc[0]),
            "delivery_end":  str(g["order_end"].iloc[0]),
            "price_basis":   g["c1_price_basis"].iloc[0],
            "deal_terms":    str(g["deal_terms"].iloc[0])[:150],
            "open_price":    prices[0],
            "close_price":   prices[-1],
            "price_range":   sorted(set(prices)),
            "final_state":   g["order_state"].iloc[-1],
            "n_sequences":   len(prices),
            "time_open":     str(g["order_time"].iloc[0])[:19],
            "time_close":    str(g["order_time"].iloc[-1])[:19],
        })

    # ---- Closing books (final sequence per order_id) ----------------------
    final = (
        df[df["order_state"].isin(["active", "inactive"])]
        .sort_values("order_sequence")
        .groupby("order_id")
        .last()
        .reset_index()
    )
    closing_bids = (
        final[final["order_type"] == "Bid"]
        [["market_maker", "c1_price_basis", "c1_price", "c1_basis_period",
          "order_begin", "order_end", "deal_terms"]]
        .sort_values("c1_price", ascending=False)
        .head(15)
        .to_dict("records")
    )
    closing_offers = (
        final[final["order_type"] == "Offer"]
        [["market_maker", "c1_price_basis", "c1_price", "c1_basis_period",
          "order_begin", "order_end", "deal_terms"]]
        .sort_values("c1_price")
        .head(15)
        .to_dict("records")
    )

    participants = sorted(df["market_maker"].dropna().unique().tolist())

    return {
        "trades":         trade_records,
        "withdrawn":      wdn_records,
        "trajectories":   trajectories,
        "closing_bids":   closing_bids,
        "closing_offers": closing_offers,
        "participants":   participants,
        "n_total_orders": len(df),
    }


def _prepare_derivatives_context(df: pd.DataFrame) -> dict:
    """
    Extract structured facts from a derivatives MOC dataframe.
    Returns a dict serialised to JSON for the prompt.
    """
    df = df.copy()

    # ---- Trades ------------------------------------------------------------
    trades = df[df["order_state"] == "consummated"].copy()
    trade_records = []
    for _, row in trades.sort_values("order_time").iterrows():
        trade_records.append({
            "time":         str(row.get("order_time", ""))[:19],
            "product":      row.get("product", ""),
            "strip":        row.get("strip", ""),
            "buyer":        row.get("buyer", ""),
            "seller":       row.get("seller", ""),
            "price":        row.get("price", 0),
            "leg_prices":   row.get("leg_prices", ""),
            "is_spread":    row.get("order_spread", "F") == "T",
            "deal_begin":   str(row.get("deal_begin", "")),
            "deal_end":     str(row.get("deal_end", "")),
            "deal_id":      row.get("deal_id", ""),
        })

    # ---- Opening and closing prices per participant/strip/side ------------
    open_prices = {}
    close_prices = {}

    sorted_df = df.sort_values("order_time")
    for (mm, strip, side), grp in sorted_df.groupby(
        ["market_maker", "strip", "order_type"]
    ):
        key = f"{mm}|{strip}|{side}"
        open_prices[key]  = grp["price"].iloc[0]
        # closing = last active/inactive sequence
        active = grp[grp["order_state"].isin(["active", "inactive"])]
        if len(active) > 0:
            close_prices[key] = active["price"].iloc[-1]

    # Flatten to list of dicts for readability
    open_list, close_list = [], []
    for key, p in open_prices.items():
        mm, strip, side = key.split("|")
        open_list.append({"market_maker": mm, "strip": strip, "side": side, "price": p})
    for key, p in close_prices.items():
        mm, strip, side = key.split("|")
        close_list.append({"market_maker": mm, "strip": strip, "side": side, "price": p})

    # ---- Withdrawn orders summary -----------------------------------------
    wdn = df[df["order_state"] == "withdrawn"]
    wdn_last = wdn.sort_values("order_sequence").groupby("order_id").last().reset_index()
    wdn_summary = {
        "total": len(wdn_last),
        "by_participant": wdn_last["market_maker"].value_counts().to_dict(),
        "by_strip":       wdn_last["strip"].value_counts().to_dict(),
        "spread_bid_min": (
            wdn_last[
                (wdn_last["strip"].str.contains("May|Jun", na=False)) &
                (wdn_last["order_type"] == "Bid")
            ]["price"].min()
            if len(wdn_last) > 0 else None
        ),
        "spread_offer_max": (
            wdn_last[
                (wdn_last["strip"].str.contains("May|Jun", na=False)) &
                (wdn_last["order_type"] == "Offer")
            ]["price"].max()
            if len(wdn_last) > 0 else None
        ),
    }

    participants = sorted(df["market_maker"].dropna().unique().tolist())
    strips       = df["strip"].value_counts().to_dict()
    products     = df["product"].value_counts().to_dict()

    return {
        "trades":           trade_records,
        "opening_prices":   open_list,
        "closing_prices":   close_list,
        "withdrawn_summary":wdn_summary,
        "participants":     participants,
        "strips":           strips,
        "products":         products,
        "n_total_orders":   len(df),
    }


def _build_history_context(hist_df: pd.DataFrame, window_type: str) -> str:
    """
    Build historical context by running the full _prepare_physical_context /
    _prepare_derivatives_context on each prior session and serialising to JSON.

    Claude receives exactly the same structured data for history as for today:
    full closing bid/offer books, all participant names, all price trajectories,
    and trade details. This prevents "not available" values in day-on-day
    comparisons and ensures participant lists are accurate across sessions.

    Parameters
    ----------
    hist_df : pd.DataFrame
        Combined dataframe of prior sessions. Must have an 'order_date' column.
    window_type : 'physical' or 'derivatives'
    """
    if hist_df is None or len(hist_df) == 0:
        return "No historical data provided."

    prepare_fn = (
        _prepare_physical_context
        if window_type == "physical"
        else _prepare_derivatives_context
    )

    sessions = {}
    for date, day_df in hist_df.groupby("order_date"):
        sessions[str(date)] = prepare_fn(day_df.copy())

    return json.dumps(sessions, indent=2, default=str)


# ---------------------------------------------------------------------------
# Platts LNG news (SPGCI Insights API)
# ---------------------------------------------------------------------------

def _first_present(row, keys, default=""):
    """Return the first non-empty value among `keys` in a dict/Series row."""
    for k in keys:
        try:
            val = row.get(k)
        except AttributeError:
            val = row[k] if k in row else None
        if val is not None and str(val).strip() and str(val).lower() != "nan":
            return val
    return default


def fetch_platts_lng_news(
    days_back: int = 3,
    page_size: int = 100,
    max_stories: int = 40,
    body_chars: int = 600,
) -> str:
    """
    Fetch recent Platts LNG news stories from the SPGCI Insights API and
    format them as a plain-text context block for the Claude prompt.

    This mirrors the querying approach used by
    ``news_report/platts_news_api.py`` but is scoped to LNG stories only and
    returns a compact, prompt-ready string rather than an email.

    Credentials are assumed to be already configured by the caller via
    ``spgci.set_credentials(user, pass)`` (the main report script does this
    before invoking the generator).

    Parameters
    ----------
    days_back : int
        Look-back window in days for `updatedDate`.
    page_size : int
        Page size passed to the Insights API (paginated).
    max_stories : int
        Hard cap on the number of stories included in the context block.
    body_chars : int
        Number of characters of each story body to include.

    Returns
    -------
    str
        A formatted context block, or a short notice string if no stories
        are found / the API is unavailable.
    """
    try:
        import spgci as ci
    except ImportError:
        logger.warning("spgci not installed; skipping Platts LNG news context.")
        return "Platts LNG news context unavailable (spgci not installed)."

    date_gte = datetime.now() - timedelta(days=days_back)

    try:
        insights = ci.Insights()
        df = insights.get_stories(
            commodity="LNG",
            updated_date_gte=date_gte,
            page_size=page_size,
            paginate=True,
        )
    except Exception as exc:  # noqa: BLE001 - never fail the report on news
        logger.warning("Failed to fetch Platts LNG news: %s", exc)
        return f"Platts LNG news context unavailable (fetch error: {exc})."

    if df is None or len(df) == 0:
        return f"No Platts LNG news stories found in the last {days_back} days."

    df = df.copy()

    # ---- Sort newest first if a date column is available ------------------
    date_cols = [c for c in ("updatedDate", "updated_date", "modifiedDate",
                             "storyDateTime", "date") if c in df.columns]
    if date_cols:
        date_col = date_cols[0]
        df["_sort_dt"] = pd.to_datetime(df[date_col], errors="coerce")
        df = df.sort_values("_sort_dt", ascending=False)

    # ---- Build the context block, de-duplicating on headline --------------
    lines = [f"=== RECENT PLATTS LNG NEWS (last {days_back} days) ==="]
    seen_headlines = set()
    n = 0

    for _, row in df.iterrows():
        headline = str(_first_present(row, ["headline", "title"], "")).strip()
        if not headline:
            continue
        hkey = re.sub(r"\W+", " ", headline.lower()).strip()
        if hkey in seen_headlines:
            continue
        seen_headlines.add(hkey)

        date_val   = _first_present(row, ["updatedDate", "updated_date",
                                          "modifiedDate", "storyDateTime",
                                          "date"], "")
        geography  = _first_present(row, ["geography", "geographies",
                                          "region"], "")
        body       = str(_first_present(row, ["body", "snippet", "summary"], "")).strip()
        body       = re.sub(r"\s+", " ", body)[:body_chars]

        date_str = str(date_val)[:10] if date_val else "n/a"
        geo_str  = f" | {geography}" if geography else ""

        n += 1
        lines.append(f"\n[{n}] {date_str}{geo_str} — {headline}")
        if body:
            lines.append(f"    {body}")

        if n >= max_stories:
            break

    if n == 0:
        return f"No Platts LNG news stories found in the last {days_back} days."

    logger.info("Included %d Platts LNG news stories in Claude context.", n)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

PHYSICAL_SYSTEM_PROMPT = """
You are a senior LNG market analyst specialising in Platts APAC LNG physical
Market-on-Close (MOC) windows. Your task is to produce a detailed, structured
daily summary in the style of a professional commodity market report.

Follow this template exactly:

## Platts LNG JKM Physical MOC Summary — {DATE}

### Overview
[2-4 sentence overview: number of trades, key context (geopolitical, market
conditions), dominant participants, delivery windows in play, and the
physical–derivatives relationship if relevant.]

### Trades
[Table of all consummated trades with: buyer, seller, price (basis + level),
delivery window, discharge port, vessel/loading origin, time. If no trades,
state "No physical trades were concluded in this window." and explain why.]

### Key Observations
[6-10 substantive bullet-point observations covering:
- Seller repricing trajectories (open → close, ¢ improvement)
- Buyer bid trajectories
- OCO structure and withdrawals
- New participants vs prior sessions
- Origin premiums (Australian vs US vs Malaysian vs Middle Eastern)
- Physical–derivatives price gap or alignment
- Near-miss trades (orders within 1–5¢ of crossing)
- Any unusual pricing or structural features]

### Closing Bid Book
[Table: Bidder | Delivery | Price | Discharge | Notes]

### Closing Offer Book
[Table: Offerer | Delivery | Price | Cargo details | Notes]

### Bid/Offer Spread Analysis
[1-2 paragraphs on the residual spread, whether it widened or tightened vs
prior session, implied JKM from flat-price legs, and likelihood of trades
tomorrow.]

### Comparison with Prior Session
[Table comparing key metrics vs prior day: trades, cleared level, best bid,
best offer, spread, new participants, notable changes]

### Key Takeaways
[3-5 concise analytical conclusions]

STYLE RULES:
- Write like a professional commodity market report, not a chatbot
- Use specific numbers from the data; never vague language
- Name participants by their short mnemonic where appropriate
(e.g. "Shell Eastern", "Vitol", "BP", "Hartree", "Mercuria", "Marubeni")
- Identify OCO pairs from simultaneous withdrawals tagged
  withdrawn_with_headline
- Note the implied JKM level when flat-price orders are present
  (flat price ± differential = implied JKM)
- Highlight any change in discharge port or origin vs prior sessions
- Physical–derivatives relationship: note whether both windows imply the
  same JKM level (aligned) or diverge
- Do not use bullet points in prose paragraphs; use them only in designated
  bullet sections
""".strip()


DERIVATIVES_SYSTEM_PROMPT = """
You are a senior LNG market analyst specialising in Platts APAC LNG JKM
financial derivatives Market-on-Close (MOC) windows. Your task is to produce
a detailed, structured daily summary in the style of a professional commodity
market report.

Follow this template exactly:

## Platts LNG JKM Derivatives MOC Summary — {DATE}

### Overview
[2-4 sentence overview: total trades, instruments traded (BalMnth NextDay,
Jun26, spreads), clearing price range, key contextual factors (geopolitical
events, prior-day price level), dominant buyer and seller, and note whether
physical and derivatives windows were aligned or diverged.]

### Trades

**Instrument 1: JKM Bal Month (May) NextDay**
[Table: # | Buyer | Seller | Price | Lots | Time]

**Instrument 2: JKM Jun26 outright** (if any)
[Table: # | Buyer | Seller | Price | Lots | Time]

**Instrument 3: Calendar spreads** (if any)
[Table: # | Buyer | Seller | Spread | Legs | Time]

[If no trades in an instrument, omit that instrument section.]

### Key Observations
[6-10 substantive observations covering:
- Seller offer trajectories (open → close, movement in $)
- Buyer bid trajectories (open → close)
- Who cleared and who did not, and why
- New participants vs prior sessions
- QatarEnergy / ADNOC / Gulf entity positioning
- BalMnth/Jun26 spread direction and what it implies
- Withdrawn orders and what they represent (post-panic clearing,
  normalisation, etc.)
- Shell Eastern positioning across multiple sessions if relevant
- Physical–derivatives alignment
- Any unusual participants (financial firms, European traders, etc.)]

### Closing Bid Book Summary
[Separate tables for: BalMnth May | Jun26 | BalMnth/Jun26 spread
Show: Bidder | Price | Notes]

### Closing Offer Book Summary
[Separate tables for: BalMnth May | Jun26 | BalMnth/Jun26 spread
Show: Offerer | Price | Notes]

### Curve Structure and Spread Analysis
[1-2 paragraphs: BalMnth vs Jun26 level, spread direction (backwardation /
flat / contango), what this implies about disruption duration/severity,
comparison to pre-event levels if relevant]

### Comparison with Prior Session
[Table comparing: BalMnth cleared, Jun26 cleared, spread cleared, total
trades, dominant buyer/seller, new participants, physical alignment, key changes]

### Key Takeaways
[3-5 concise analytical conclusions]

STYLE RULES:
- Write like a professional commodity market report
- Use specific prices and participant names throughout
- Identify spread trades by their leg decomposition (e.g. 22.90/22.90)
- Interpret Gulf entity positioning (QatarEnergy selling = Qatari supply
  available; QatarEnergy absent = uncertainty)
- Note Shell Eastern's cumulative cross-session position if history provided
- Interpret the BalMnth/Jun26 spread direction in terms of disruption
  duration expectations (backwardation = near-term disruption; contango =
  disruption expected to persist into forward months or normalise quickly)
- Withdrawn orders: interpret what they represent (e.g. post-Ras Laffan panic
  positioning being cleared)
- Do not use bullet points in prose paragraphs; use them only in designated
  bullet sections
- If only 1-2 trades: note that price discovery was thin and explain why the
  cleared level is or is not a robust assessment anchor
""".strip()


WEB_SEARCH_GUIDANCE = """

--- LIVE WEB SEARCH ---
You have access to a `web_search` tool. Before writing the report, run a small
number of targeted searches (typically 2-4) to gather market-moving context
for the session date that is NOT already present in the structured eWMD data
or the supplied Platts LNG news block, for example:
- LNG supply disruptions, outages, force majeure, or maintenance at major
  liquefaction plants (Qatar/Ras Laffan, US Gulf, Australia, Malaysia, PNG, etc.)
- Geopolitical events affecting LNG flows or shipping (Middle East, Strait of
  Hormuz, Panama/Suez canals, sanctions)
- JKM / TTF / Henry Hub price moves and notable spot cargo trades
- Weather-driven demand swings in North-East Asia and Europe
Prefer reputable sources (Reuters, Bloomberg, S&P Global Platts, Argus, ICIS,
Montel, exchange/operator/government statements). Only incorporate findings
that are relevant and corroborated, and reference the source inline in prose
where you rely on a searched fact. Do not fabricate. If searches return nothing
relevant, proceed using the structured data and supplied context only.

IMPORTANT: Do not narrate your search process and do not write any preamble or
commentary. After searching, output ONLY the report itself, beginning directly
with the `##` title heading. Fold any market-moving findings into the report's
Overview / Key Observations sections.
""".rstrip()


PHYSICAL_USER_TEMPLATE = """
Session date: {date}

=== TODAY'S PHYSICAL MOC DATA (structured) ===
{today_context}

=== HISTORICAL CONTEXT (prior sessions) ===
{history_summary}

=== ADDITIONAL CONTEXT ===
{additional_context}

Please generate the full MOC summary following the template in your instructions.
Include specific day-on-day comparisons where historical data is available.
""".strip()


DERIVATIVES_USER_TEMPLATE = """
Session date: {date}

=== TODAY'S DERIVATIVES MOC DATA (structured) ===
{today_context}

=== HISTORICAL CONTEXT (prior sessions) ===
{history_summary}

=== ADDITIONAL CONTEXT ===
{additional_context}

Please generate the full MOC summary following the template in your instructions.
Include specific day-on-day comparisons where historical data is available.
""".strip()


# ---------------------------------------------------------------------------
# Main generator class
# ---------------------------------------------------------------------------

def _strip_preamble(md_text: str) -> str:
    """
    Remove any conversational preamble Claude may emit before the report
    proper (e.g. "I'll gather some market-moving context..."). This can happen
    when the web_search tool is enabled and the model narrates its searches.

    The report always begins with a Markdown heading (``## ...``), so we drop
    everything before the first heading line. If no heading is found the text
    is returned unchanged.
    """
    lines = md_text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^\s{0,3}#{1,6}\s", line):
            return "\n".join(lines[i:]).strip()
    return md_text.strip()


class MOCSummaryGenerator:
    """
    Generates analyst-quality Platts APAC LNG MOC summaries using Claude.

    Parameters
    ----------
    api_key : str
        Your Anthropic API key.
    model : str
        Claude model to use. Defaults to claude-opus-4-8 for highest quality.
    max_tokens : int
        Maximum tokens in the response.
    effort : str
        Reasoning effort level for adaptive thinking
        ('low' | 'medium' | 'high' | 'xhigh' | 'max'). Defaults to 'high'.
    enable_web_search : bool
        If True, expose Anthropic's server-side `web_search` tool so Claude
        can pull in live market-moving context while writing the report.
    web_search_max_uses : int
        Hard cap on the number of searches Claude may perform per request.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "claude-opus-4-8",
        max_tokens: int = 32000,
        effort: str = "high",
        enable_web_search: bool = True,
        web_search_max_uses: int = 5,
    ):
        self.client    = anthropic.Anthropic(api_key=api_key)
        self.model     = model
        self.max_tokens = max_tokens
        self.effort    = effort
        self.enable_web_search   = enable_web_search
        self.web_search_max_uses = web_search_max_uses

    # ------------------------------------------------------------------ #
    #  Public methods                                                       #
    # ------------------------------------------------------------------ #

    def generate_physical_summary(
        self,
        today_df: pd.DataFrame,
        session_date: str,
        history_df: Optional[pd.DataFrame] = None,
        additional_context: str = "",
    ) -> str:
        """
        Generate a physical MOC window summary.

        Parameters
        ----------
        today_df : pd.DataFrame
            Full eWMD dataframe for today's physical MOC session.
        session_date : str
            Date string, e.g. "2026-03-25".
        history_df : pd.DataFrame, optional
            Combined dataframe of prior sessions (last 7 days recommended).
            Must have an 'order_date' column.
        additional_context : str, optional
            Free-text context to inject (e.g. "Iran struck Ras Laffan overnight").
        """
        today_ctx   = _prepare_physical_context(today_df)
        history_txt = _build_history_context(history_df, "physical")

        user_msg = PHYSICAL_USER_TEMPLATE.format(
            date               = session_date,
            today_context      = json.dumps(today_ctx, indent=2, default=str),
            history_summary    = history_txt,
            additional_context = additional_context or "None provided.",
        )

        return self._call_claude(
            system   = PHYSICAL_SYSTEM_PROMPT,
            user_msg = user_msg,
        )

    def generate_derivatives_summary(
        self,
        today_df: pd.DataFrame,
        session_date: str,
        history_df: Optional[pd.DataFrame] = None,
        additional_context: str = "",
    ) -> str:
        """
        Generate a derivatives MOC window summary.

        Parameters
        ----------
        today_df : pd.DataFrame
            Full eWMD dataframe for today's derivatives MOC session.
        session_date : str
            Date string, e.g. "2026-03-25".
        history_df : pd.DataFrame, optional
            Combined dataframe of prior sessions (last 7 days recommended).
            Must have an 'order_date' column.
        additional_context : str, optional
            Free-text context to inject.
        """
        today_ctx   = _prepare_derivatives_context(today_df)
        history_txt = _build_history_context(history_df, "derivatives")

        user_msg = DERIVATIVES_USER_TEMPLATE.format(
            date               = session_date,
            today_context      = json.dumps(today_ctx, indent=2, default=str),
            history_summary    = history_txt,
            additional_context = additional_context or "None provided.",
        )

        return self._call_claude(
            system   = DERIVATIVES_SYSTEM_PROMPT,
            user_msg = user_msg,
        )

    def generate_both(
        self,
        phys_df: pd.DataFrame,
        deriv_df: pd.DataFrame,
        session_date: str,
        phys_history_df: Optional[pd.DataFrame] = None,
        deriv_history_df: Optional[pd.DataFrame] = None,
        additional_context: str = "",
    ) -> dict:
        """
        Convenience method: generate both physical and derivatives summaries.

        Returns
        -------
        dict with keys 'physical' and 'derivatives'
        """
        physical = self.generate_physical_summary(
            today_df           = phys_df,
            session_date       = session_date,
            history_df         = phys_history_df,
            additional_context = additional_context,
        )
        derivatives = self.generate_derivatives_summary(
            today_df           = deriv_df,
            session_date       = session_date,
            history_df         = deriv_history_df,
            additional_context = additional_context,
        )
        return {"physical": physical, "derivatives": derivatives}

    # ------------------------------------------------------------------ #
    #  Private                                                             #
    # ------------------------------------------------------------------ #

    def _call_claude(self, system: str, user_msg: str) -> str:
        tools = []
        if self.enable_web_search:
            tools.append({
                "type":     "web_search_20250305",
                "name":     "web_search",
                "max_uses": self.web_search_max_uses,
            })
            # Tell Claude how/when to use the search tool.
            system = f"{system}\n{WEB_SEARCH_GUIDANCE}"

        messages = [{"role": "user", "content": user_msg}]

        # The server-side web_search tool can return a `pause_turn` stop
        # reason when Claude needs another round-trip to finish. Loop until we
        # get a natural stop, feeding the prior assistant turn (including any
        # thinking and tool_use blocks) back in each iteration.
        while True:
            kwargs = dict(
                model         = self.model,
                max_tokens    = self.max_tokens,
                thinking      = {"type": "adaptive"},
                output_config = {"effort": self.effort},
                system        = system,
                messages      = messages,
            )
            if tools:
                kwargs["tools"] = tools

            # Stream the request. The SDK requires streaming for requests that
            # may run longer than 10 minutes (large max_tokens + thinking +
            # web search), so we accumulate the final message rather than
            # calling messages.create() directly.
            with self.client.messages.stream(**kwargs) as stream:
                response = stream.get_final_message()

            if response.stop_reason == "pause_turn":
                messages.append({"role": "assistant", "content": response.content})
                continue
            break

        # A truncated response (hit max_tokens) drops trailing sections such as
        # "Key Takeaways" — surface it so the cause is obvious in the logs.
        if response.stop_reason == "max_tokens":
            logger.warning(
                "Claude response truncated (stop_reason=max_tokens); consider "
                "raising max_tokens (currently %d).", self.max_tokens
            )

        # With adaptive thinking / web search enabled the response may contain
        # thinking and tool-result blocks before the answer, so return the
        # text block(s) rather than assuming content[0] is the text.
        text_parts = [block.text for block in response.content if block.type == "text"]
        text = "\n".join(text_parts).strip()

        # Drop any conversational preamble emitted before the report heading
        # (a side-effect of the web_search tool narrating its searches).
        return _strip_preamble(text)






# ---------------------------------------------------------------------------
# CSS — designed for compatibility with major email clients (Outlook, Gmail,
# Apple Mail). Uses inline-friendly styles; no flexbox or grid.
# ---------------------------------------------------------------------------

EMAIL_CSS = """
    /* Base reset — applies inside <td class="email-body"> */
    body, table, td, p, h1, h2, h3, h4 {
        margin: 0; padding: 0; border: 0;
        font-family: Arial, Helvetica, sans-serif;
    }

    /* Headings inside the body cell */
    .email-body h2 {
        color: #0f2044;
        font-size: 18px;
        font-weight: 700;
        margin: 0 0 18px 0;
        padding-bottom: 8px;
        border-bottom: 2px solid #e8a020;
    }
    /* Document title H2 is extracted into the banner — hide if it survives */
    .email-body h2:first-child {
        display: none;
    }
    .email-body h3 {
        color: #1a3a6b;
        font-size: 13px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        margin: 24px 0 10px 0;
        padding: 6px 0 6px 12px;
        border-left: 3px solid #e8a020;
    }
    .email-body h3:first-child {
        margin-top: 0;
    }
    .email-body h4 {
        color: #0f2044;
        font-size: 13px;
        font-weight: 700;
        margin: 16px 0 8px 0;
    }

    /* Paragraphs */
    .email-body p {
        color: #2c2c3e;
        font-size: 14px;
        line-height: 1.7;
        margin: 0 0 12px 0;
    }

    /* Lists */
    .email-body ul, .email-body ol {
        padding-left: 20px;
        margin: 0 0 12px 0;
    }
    .email-body li {
        color: #2c2c3e;
        font-size: 14px;
        line-height: 1.7;
        margin-bottom: 4px;
    }

    /* Tables */
    .email-body table {
        width: 100%;
        border-collapse: collapse;
        margin: 12px 0 20px 0;
        font-size: 13px;
    }
    .email-body table thead tr {
        background: #0f2044;
        color: #ffffff;
    }
    .email-body table thead th {
        padding: 9px 12px;
        text-align: left;
        font-weight: 600;
        font-size: 12px;
        letter-spacing: 0.5px;
        white-space: nowrap;
        color: #ffffff;
    }
    .email-body table tbody tr {
        border-bottom: 1px solid #e8ecf4;
    }
    .email-body table tbody tr:nth-child(even) {
        background: #f5f7fb;
    }
    .email-body table tbody td {
        padding: 8px 12px;
        color: #2c2c3e;
        vertical-align: top;
    }

    /* Inline code */
    .email-body code {
        background: #edf2ff;
        color: #0f2044;
        font-family: 'Courier New', Courier, monospace;
        font-size: 12px;
        padding: 1px 5px;
        border-radius: 3px;
    }

    /* Blockquotes */
    .email-body blockquote {
        background: #f5f7fb;
        border-left: 4px solid #1a3a6b;
        margin: 12px 0;
        padding: 12px 16px;
    }
    .email-body blockquote p {
        color: #1a3a6b;
        font-style: italic;
        margin: 0;
    }

    /* Horizontal rules */
    .email-body hr {
        border: none;
        border-top: 1px solid #e8ecf4;
        margin: 24px 0;
    }

    /* Bold */
    .email-body strong {
        color: #0f2044;
        font-weight: 700;
    }

    /* Price change utilities */
    .price-up   { color: #1a7a3a; font-weight: 600; }
    .price-down { color: #b02020; font-weight: 600; }
    .price-flat { color: #555555; font-weight: 600; }
""".strip()


# ---------------------------------------------------------------------------
# Markdown → HTML conversion
# ---------------------------------------------------------------------------

def _ensure_table_blank_lines(md_text: str) -> str:
    """
    Insert a blank line before any pipe-table that is glued directly to a
    preceding non-blank, non-table line (e.g. a bold sub-label like
    ``**Bal Month (Aug)**`` written immediately above the table).

    Python-Markdown's `tables` extension only recognises a table when it forms
    its own block (preceded by a blank line); otherwise the header row and the
    label collapse into a single paragraph and the table renders as raw text.
    """
    lines = md_text.split("\n")

    def _is_row(line: str) -> bool:
        return line.lstrip().startswith("|")

    def _is_delim(line: str) -> bool:
        s = line.strip()
        return bool(s) and set(s) <= set("|-: ") and "-" in s

    out: list[str] = []
    for i, line in enumerate(lines):
        starts_table = (
            _is_row(line)
            and i + 1 < len(lines)
            and _is_delim(lines[i + 1])
        )
        if starts_table and out:
            prev = out[-1]
            if prev.strip() != "" and not _is_row(prev):
                out.append("")
        out.append(line)

    return "\n".join(out)


def _md_to_html(md_text: str) -> str:
    """
    Convert markdown string to HTML fragment using the `markdown` library.

    nl2br is intentionally excluded: it converts every single newline to <br>
    which causes spurious <br> tags at the top of the document (before the
    title heading) and between table rows. We instead normalise the markdown
    source by stripping leading blank lines before conversion.
    """
    # Strip leading/trailing blank lines from the markdown source so the
    # converter doesn't see empty lines before the title heading
    md_text = md_text.strip()

    # Ensure tables glued to a preceding label line are still parsed as tables
    md_text = _ensure_table_blank_lines(md_text)

    html = markdown.markdown(
        md_text,
        extensions=["tables", "fenced_code", "sane_lists"],
        output_format="html",
    )
    return html


def _strip_h1(html: str) -> tuple[str, str]:
    """
    Extract the document title from the first heading tag (h1 or h2) and
    return (title, remaining_html).

    Claude's system prompt produces '## Platts LNG JKM ... Summary — DATE'
    as an H2, not H1, so we check for both. The heading is removed from the
    body because it is rendered in the header banner instead.

    We also strip any leading <br>, <p></p>, or whitespace that appears
    before the heading (artifact of the nl2br extension on blank lines at
    the top of the markdown string).
    """
    # Try H1 first, then H2 — whichever comes first in the document
    h1_match = re.search(r"<h1[^>]*>(.*?)</h1>", html, re.IGNORECASE | re.DOTALL)
    h2_match = re.search(r"<h2[^>]*>(.*?)</h2>", html, re.IGNORECASE | re.DOTALL)

    match = None
    if h1_match and h2_match:
        match = h1_match if h1_match.start() < h2_match.start() else h2_match
    elif h1_match:
        match = h1_match
    elif h2_match:
        match = h2_match

    if match:
        title = re.sub(r"<[^>]+>", "", match.group(1)).strip()
        html  = html[:match.start()] + html[match.end():]
    else:
        title = ""

    # Remove any leading <br>, <br/>, empty <p></p> or whitespace left
    # behind before the first real content block
    html = re.sub(r"^\s*(<br\s*/?>|<p>\s*</p>|<p><br\s*/?>\s*</p>)\s*", "", html,
                  flags=re.IGNORECASE).strip()

    return title, html


# ---------------------------------------------------------------------------
# HTML document assembly
# Outlook requires table-based layout — <div> CSS is largely ignored.
# Every structural element uses <table>/<tr>/<td> so rendering is consistent
# across Outlook 2016/2019/365, Gmail, and Apple Mail.
# ---------------------------------------------------------------------------

HTML_SHELL = """<!DOCTYPE html>
<html lang="en" xmlns:v="urn:schemas-microsoft-com:vml"
      xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--[if mso]>
<noscript><xml><o:OfficeDocumentSettings>
  <o:PixelsPerInch>96</o:PixelsPerInch>
</o:OfficeDocumentSettings></xml></noscript>
<![endif]-->
<title>{page_title}</title>
<style>
{css}
</style>
</head>
<body style="margin:0;padding:0;background-color:#f0f2f5;">

<!-- Preheader text: hidden but controls inbox preview snippet -->
<div style="display:none;max-height:0;overflow:hidden;mso-hide:all;">
  {preheader}&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;
  &nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;
  &nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;
</div>

<!-- Outer wrapper table -->
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"
       border="0" style="background-color:#f0f2f5;">
<tr><td align="center" style="padding:24px 16px;">

  <!-- Inner content table: max 900px -->
  <table role="presentation" width="900" cellpadding="0" cellspacing="0"
         border="0" style="max-width:900px;width:100%;background:#ffffff;
         border-radius:8px;overflow:hidden;">

    <!-- ── Banner header ── -->
    <tr>
      <td style="background:#0f2044;padding:28px 36px;
                 border-bottom:3px solid #e8a020;">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td>
              <p style="margin:0 0 4px 0;font-family:Arial,sans-serif;
                        font-size:20px;font-weight:700;color:#ffffff;
                        letter-spacing:0.3px;">{banner_title}</p>
              <p style="margin:0;font-family:Arial,sans-serif;
                        font-size:13px;color:#9bb8e8;">
                Platts APAC LNG Market-on-Close Analysis</p>
            </td>
            <td align="right" valign="top">
              <p style="margin:0;font-family:Arial,sans-serif;
                        font-size:13px;font-weight:600;color:#e8a020;
                        white-space:nowrap;">{datestamp}</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- ── Body content ── -->
    {body_html}

    <!-- ── Footer ── -->
    <tr>
      <td style="background:#f5f7fb;padding:16px 36px;
                 border-top:1px solid #e8ecf4;
                 font-family:Arial,sans-serif;font-size:11px;
                 color:#888888;text-align:center;line-height:1.5;">
        This summary is generated from Platts eWindow Market Data (eWMD).
        All prices in USD/MMBtu unless stated. Cargo sizes 3.3&ndash;3.5 TBtu.
        For internal distribution only.
        <br>Generated {generated_at}
      </td>
    </tr>

  </table><!-- /inner -->
</td></tr>
</table><!-- /outer -->

</body>
</html>"""


# Section label row + body content row — both as proper <tr><td> blocks
SECTION_DIVIDER = """
    <!-- Section label -->
    <tr>
      <td style="background:#1a3a6b;padding:10px 36px;
                 border-left:4px solid #e8a020;
                 font-family:Arial,sans-serif;font-size:13px;
                 font-weight:700;letter-spacing:1.2px;
                 text-transform:uppercase;color:#ffffff;">
        {label}
      </td>
    </tr>
    <!-- Section body -->
    <tr>
      <td class="email-body" style="padding:28px 36px;">
        {content}
      </td>
    </tr>
"""


# ---------------------------------------------------------------------------
# Public formatter class
# ---------------------------------------------------------------------------

class MOCEmailFormatter:
    """
    Converts Claude-generated markdown MOC summaries to styled HTML emails.
    """

    def to_html(
        self,
        markdown_text: str,
        title: str = "Platts APAC LNG MOC Summary",
        session_date: str = "",
    ) -> str:
        """
        Convert a single markdown summary to a standalone HTML email document.

        Parameters
        ----------
        markdown_text : str
            The raw markdown string returned by MOCSummaryGenerator.
        title : str
            Section label shown in the blue bar, e.g. "Physical MOC Window".
        session_date : str
            Human-readable date shown in the banner, e.g. "25 March 2026".
        """
        body_html  = _md_to_html(markdown_text)
        doc_title, body_html = _strip_h1(body_html)

        # Banner title comes from the extracted H2; fall back to title param
        banner_title = doc_title or title
        datestamp    = session_date or datetime.today().strftime("%-d %B %Y")
        generated_at = datetime.now().strftime("%d %b %Y %H:%M UTC")

        # Preheader: first ~90 chars of body text, stripped of tags
        plain_preview = re.sub(r"<[^>]+>", " ", body_html)
        plain_preview = re.sub(r"\s+", " ", plain_preview).strip()[:90]

        body_section = SECTION_DIVIDER.format(
            label   = title.upper(),
            content = body_html,
        )

        return HTML_SHELL.format(
            page_title   = banner_title,
            banner_title = banner_title,
            datestamp    = datestamp,
            preheader    = plain_preview,
            css          = EMAIL_CSS,
            body_html    = body_section,
            generated_at = generated_at,
        )



def _is_workflow_webhook(webhook_url: str) -> bool:
    return "powerplatform.com" in webhook_url or "logic.azure.com" in webhook_url


def _workflow_payload(body: list) -> dict:
    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.4",
                    "msteams": {"width": "Full"},
                    "body": body,
                },
            }
        ],
    }


def _post_teams(webhook_url: str, payload: dict, label: str = "Teams message") -> None:
    response = requests.post(
        webhook_url,
        json=payload,
        headers={"Content-Type": "application/json"},
        timeout=10,
    )
    response.raise_for_status()
    print(
        f"{label} sent ({response.status_code}), "
        f"{len(json.dumps(payload).encode()):,} bytes"
    )


def send_teams_summary(
    markdown_text: str,
    webhook_url: str,
    session_date: str = "",
) -> None:
    """
    Sends a concise Teams message containing only the Overview section
    of the MOC summary, with a prompt to check email for full analysis.
    """

    lines = markdown_text.strip().splitlines()

    # ── Extract title ──────────────────────────────────────────────────────
    title = ""
    for line in lines:
        if line.startswith("## "):
            title = line.lstrip("# ").strip()
            break
    title = title or f"Platts APAC LNG MOC Summary — {session_date}"

    # ── Extract Overview section only ──────────────────────────────────────
    overview_lines = []
    in_overview = False
    for line in lines:
        if line.startswith("### ") and line.lstrip("# ").strip().upper() == "OVERVIEW":
            in_overview = True
            continue
        if in_overview:
            if line.startswith("### "):
                break  # hit the next section — stop
            overview_lines.append(line)

    footnote = (
        "_Full detailed commentary, trade analysis, bid/offer books "
        "and key takeaways available in the summary email._"
    )

    if _is_workflow_webhook(webhook_url):
        overview_md = "\n".join(line for line in overview_lines if line.strip())
        body = [
            {
                "type": "TextBlock",
                "text": f"**{title}**",
                "size": "Medium",
                "weight": "Bolder",
                "wrap": True,
            },
        ]
        if overview_md:
            body.append({
                "type": "TextBlock",
                "text": overview_md,
                "wrap": True,
                "spacing": "Small",
            })
        body.append({
            "type": "TextBlock",
            "text": footnote,
            "wrap": True,
            "isSubtle": True,
            "size": "Small",
            "spacing": "Medium",
        })
        payload = _workflow_payload(body)
    else:
        # ── Convert overview to HTML (legacy Incoming Webhook) ─────────────
        def to_html(body_lines: list) -> str:
            parts = []
            for line in body_lines:
                if line.strip() == "":
                    continue
                text = line.strip()
                text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
                text = re.sub(r"\*(.+?)\*",     r"<em>\1</em>",          text)
                parts.append(f'<p style="margin:4px 0;">{text}</p>')
            return "".join(parts)

        overview_html = to_html(overview_lines)
        footnote_html = (
            '<p style="margin:12px 0 0 0;color:#666666;font-size:12px;">'
            '<em>Full detailed commentary, trade analysis, bid/offer books '
            'and key takeaways available in the summary email.</em>'
            '</p>'
        )
        payload = {
            "@type":    "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0f2044",
            "summary": f"Platts APAC LNG MOC — {session_date}",
            "sections": [
                {
                    "activityTitle": f"**{title}**",
                    "text": overview_html + footnote_html,
                    "markdown": True,
                }
            ],
        }

    _post_teams(webhook_url, payload)
    
    



# def generate_window_open_snapshot(
#     today_snapshot_df: pd.DataFrame,
#     yesterday_df: pd.DataFrame,
#     session_date: datetime,
# ) -> str:
#     """
#     Generate a brief markdown snapshot of who is bidding and offering
#     at window open, flagging any participants not seen yesterday.

#     """

#     df   = today_snapshot_df.copy()
#     prev = yesterday_df.copy()

#     # ── Snapshot time ──────────────────────────────────────────────────────
#     snapshot_time = session_date.strftime("%H:%M")

#     # ── Participant sets ───────────────────────────────────────────────────
#     prev_participants = set(prev["market_maker"].dropna().unique())

#     bidders = set(
#         df.loc[df["order_type"] == "Bid", "market_maker"].dropna().unique()
#     )
#     sellers = set(
#         df.loc[df["order_type"] == "Offer", "market_maker"].dropna().unique()
#     )

#     # ── Name shortener ─────────────────────────────────────────────────────
#     KNOWN_NAMES = {
#         "Shell Eastern trading (pte) Ltd trading as Shell Eastern LNG": "Shell Eastern",
#         "TOTALENERGIES GAS & POWER ASIA PRIVATE LIMITED":               "TotalEnergies",
#         "Hartree Partners Power & Gas Company (UK) Limited":            "Hartree",
#         "Petrochina International (Hong Kong) Corporation LTD.":        "PetroChina HK",
#         "PetroChina International (Singapore) Pte. Ltd.":               "PetroChina SG",
#         "Mercuria Energy Trading SA":                                    "Mercuria",
#         "Vitol Asia Pte Ltd":                                            "Vitol",
#         "Marubeni Corporation":                                          "Marubeni",
#         "Glencore Singapore Pte Ltd":                                    "Glencore",
#         "Trafigura Pte Ltd.":                                            "Trafigura",
#         "BP Singapore":                                                  "BP Singapore",
#         "JERA Global Markets":                                           "JERA",
#     }

#     def _name(mm: str) -> str:
#         return KNOWN_NAMES.get(mm, mm)

#     def _format_list(participants: set) -> list[str]:
#         """Sort participants: new ones first, then alphabetical."""
#         return sorted(participants, key=lambda mm: (mm in prev_participants, _name(mm)))

#     # ── Absent vs yesterday ────────────────────────────────────────────────
#     today_all    = bidders | sellers
#     absent_today = {
#         p for p in prev_participants
#         if p and str(p) != "nan" and p not in today_all
#     }

#     # ── Build markdown ─────────────────────────────────────────────────────
#     date_str = session_date.strftime("%d %B %Y")
#     lines    = []

#     lines.append(
#         f"## Platts LNG JKM Physical MOC — Early Window Snapshot — {date_str}"
#     )
#     lines.append("")
#     lines.append(f"Snapshot taken at **{snapshot_time}**.")
#     lines.append("")

#     # Bids
#     lines.append("### Bidders")
#     lines.append("")
#     if bidders:
#         for mm in _format_list(bidders):
#             new_flag = " 🆕" if mm not in prev_participants else ""
#             lines.append(f"- {_name(mm)}{new_flag}")
#     else:
#         lines.append("*No bids at snapshot time.*")
#     lines.append("")

#     # Offers
#     lines.append("### Sellers")
#     lines.append("")
#     if sellers:
#         for mm in _format_list(sellers):
#             new_flag = " 🆕" if mm not in prev_participants else ""
#             lines.append(f"- {_name(mm)}{new_flag}")
#     else:
#         lines.append("*No offers at snapshot time.*")
#     lines.append("")

#     # Not yet active
#     if absent_today:
#         lines.append("### Not Yet Active (present yesterday)")
#         lines.append("")
#         for mm in sorted(absent_today, key=_name):
#             lines.append(f"- {_name(mm)}")
#         lines.append("")

#     lines.append("---")
#     lines.append(
#         "*Early snapshot only — participant list will evolve through the session.*"
#     )

#     return "\n".join(lines)


def generate_window_open_snapshot(
    today_snapshot_df: pd.DataFrame,
    yesterday_df: pd.DataFrame,
    session_date: datetime,
) -> str:
    """
    Generate a brief markdown snapshot of who is bidding and offering
    at window open, flagging any participants not seen yesterday.

    Parameters
    ----------
    today_snapshot_df : pd.DataFrame
        Snapshot of the eWMD physical dataframe taken shortly after open.
    yesterday_df : pd.DataFrame
        Complete eWMD physical dataframe from the prior session.
    session_date : datetime
    """

    df   = today_snapshot_df.copy() if today_snapshot_df is not None else pd.DataFrame()
    prev = yesterday_df.copy() if yesterday_df is not None else pd.DataFrame()

    # ── Snapshot time ──────────────────────────────────────────────────────
    snapshot_time = session_date.strftime("%H:%M")

    # Empty API responses (weekend/holiday / no BOTE rows) often come back as
    # DataFrames with no columns — guard before touching market_maker / order_type.
    required_cols = {"market_maker", "order_type", "order_id"}

    # ── Participant sets and order counts ──────────────────────────────────
    if prev.empty or "market_maker" not in prev.columns:
        prev_participants: set = set()
    else:
        prev_participants = set(prev["market_maker"].dropna().unique())

    if df.empty or not required_cols.issubset(df.columns):
        bid_counts: dict = {}
        offer_counts: dict = {}
    else:
        bid_df   = df[df["order_type"] == "Bid"].dropna(subset=["market_maker"])
        offer_df = df[df["order_type"] == "Offer"].dropna(subset=["market_maker"])

        # Count of distinct active orders (order_ids) per participant
        # Using nunique() on order_id avoids double-counting reprices
        bid_counts   = bid_df.groupby("market_maker")["order_id"].nunique().to_dict()
        offer_counts = offer_df.groupby("market_maker")["order_id"].nunique().to_dict()

    bidders = set(bid_counts.keys())
    sellers = set(offer_counts.keys())

    total_bids   = sum(bid_counts.values())
    total_offers = sum(offer_counts.values())

    # ── Name shortener ─────────────────────────────────────────────────────
    KNOWN_NAMES = {
        "Shell Eastern trading (pte) Ltd trading as Shell Eastern LNG": "Shell Eastern",
        "TOTALENERGIES GAS & POWER ASIA PRIVATE LIMITED":               "TotalEnergies",
        "Hartree Partners Power & Gas Company (UK) Limited":            "Hartree",
        "Petrochina International (Hong Kong) Corporation LTD.":        "PetroChina HK",
        "PetroChina International (Singapore) Pte. Ltd.":               "PetroChina SG",
        "Mercuria Energy Trading SA":                                    "Mercuria",
        "Vitol Asia Pte Ltd":                                            "Vitol",
        "Marubeni Corporation":                                          "Marubeni",
        "Glencore Singapore Pte Ltd":                                    "Glencore",
        "Trafigura Pte Ltd.":                                            "Trafigura",
        "BP Singapore":                                                  "BP Singapore",
        "JERA Global Markets":                                           "JERA",
    }

    def _name(mm: str) -> str:
        return KNOWN_NAMES.get(mm, mm)

    def _format_list(participants: set) -> list:
        """Sort: new participants first, then alphabetical by short name."""
        return sorted(
            participants,
            key=lambda mm: (mm in prev_participants, _name(mm))
        )

    # ── Absent vs prior session ────────────────────────────────────────────
    today_all    = bidders | sellers
    absent_today = {
        p for p in prev_participants
        if p and str(p) != "nan" and p not in today_all
    }

    # ── Build markdown ─────────────────────────────────────────────────────
    date_str = session_date.strftime("%d %B %Y")
    lines    = []

    lines.append(
        f"## Platts LNG JKM Physical MOC — Early Window Snapshot — {date_str}"
    )
    lines.append("")
    lines.append(f"Snapshot taken at **{snapshot_time}**.")
    lines.append("")

    # ── Bidders ────────────────────────────────────────────────────────────
    lines.append(
        f"### Bidders — {len(bidders)} counterpart{'y' if len(bidders) == 1 else 'ies'}, "
        f"{total_bids} total order{'s' if total_bids != 1 else ''}"
    )
    lines.append("")
    if bidders:
        for mm in _format_list(bidders):
            count    = bid_counts[mm]
            new_flag = " 🆕" if mm not in prev_participants else ""
            order_str = f"{count} order{'s' if count != 1 else ''}"
            lines.append(f"- {_name(mm)} ({order_str}){new_flag}")
    else:
        lines.append("*No bids at snapshot time.*")
    lines.append("")

    # ── Sellers ────────────────────────────────────────────────────────────
    lines.append(
        f"### Sellers — {len(sellers)} counterpart{'y' if len(sellers) == 1 else 'ies'}, "
        f"{total_offers} total order{'s' if total_offers != 1 else ''}"
    )
    lines.append("")
    if sellers:
        for mm in _format_list(sellers):
            count    = offer_counts[mm]
            new_flag = " *(new)*" if mm not in prev_participants else ""
            order_str = f"{count} order{'s' if count != 1 else ''}"
            lines.append(f"- {_name(mm)} ({order_str}){new_flag}")
    else:
        lines.append("*No offers at snapshot time.*")
    lines.append("")

    # ── Not yet active ─────────────────────────────────────────────────────
    if absent_today:
        lines.append("### Not Yet Active (present in prior session)")
        lines.append("")
        for mm in sorted(absent_today, key=_name):
            lines.append(f"- {_name(mm)}")
        lines.append("")

    lines.append("---")
    lines.append(
        "*Early snapshot only — participant list will evolve through the session.*"
    )

    return "\n".join(lines)


def send_teams_snapshot(
    markdown_text: str,
    webhook_url: str,
    session_date: datetime,
) -> None:
    """
    Send the early window snapshot to a Microsoft Teams channel.

    """

    lines = markdown_text.strip().splitlines()

    # ── Extract title ──────────────────────────────────────────────────────
    title = ""
    for line in lines:
        if line.startswith("## "):
            title = line.lstrip("# ").strip()
            break
    title = title or f"Platts APAC LNG MOC — Early Snapshot — {session_date.strftime('%d %B %Y')}"

    # ── Extract snapshot time line (first non-empty line after title) ──────
    subtitle = ""
    for line in lines:
        if line.startswith("##") or line.strip() == "":
            continue
        subtitle = line.strip()
        break
    
    subtitle_md = subtitle

    # ── Build bid and seller lists as HTML ─────────────────────────────────
    def _section_to_html(section_lines: list) -> str:
        parts = []
        for line in section_lines:
            if line.strip() == "" or line.startswith("---"):
                continue
            # Italic footnote line
            if line.startswith("*") and line.endswith("*"):
                text = line.strip("*")
                parts.append(
                    f'<p style="margin:8px 0 0 0;color:#666666;font-size:12px;">'
                    f'<em>{text}</em></p>'
                )
            # Bullet item
            elif line.startswith("- "):
                content = line[2:].strip()
                # Bold for new participants — markdown **name** → <strong>
                content = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", content)
                # Italic *(new)* marker
                content = re.sub(r"\*\(new\)\*", r"<em>(new)</em>", content)
                parts.append(
                    f'<p style="margin:2px 0;">&#8226;&nbsp;{content}</p>'
                )
            else:
                continue
        return "".join(parts)

    # Parse sections
    sections = {}
    current_heading = None
    current_lines = []

    for line in lines:
        if line.startswith("## "):
            continue
        elif line.startswith("### "):
            if current_heading is not None:
                sections[current_heading] = current_lines
            current_heading = line.lstrip("# ").strip()
            current_lines = []
        else:
            current_lines.append(line)

    if current_heading:
        sections[current_heading] = current_lines

    if _is_workflow_webhook(webhook_url):
        body = [
            {
                "type": "TextBlock",
                "text": f"**{title}**",
                "size": "Medium",
                "weight": "Bolder",
                "wrap": True,
            },
        ]
        if subtitle_md:
            body.append({
                "type": "TextBlock",
                "text": subtitle_md,
                "wrap": True,
                "isSubtle": True,
                "spacing": "Small",
            })
        for heading, body_lines in sections.items():
            section_md = "\n".join(
                line for line in body_lines
                if line.strip() and not line.startswith("---")
            )
            if not section_md.strip():
                continue
            body.append({
                "type": "TextBlock",
                "text": f"**{heading.upper()}**",
                "weight": "Bolder",
                "wrap": True,
                "spacing": "Medium",
            })
            body.append({
                "type": "TextBlock",
                "text": section_md,
                "wrap": True,
                "spacing": "Small",
            })
        payload = _workflow_payload(body)
    else:
        subtitle = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", subtitle_md)

        # ── Assemble card sections (legacy Incoming Webhook) ───────────────
        card_sections = []

        card_sections.append({
            "activityTitle": f"**{title}**",
            "text": f'<p style="margin:0;color:#555555;">{subtitle}</p>',
            "markdown": True,
        })

        for heading, body_lines in sections.items():
            body_html = _section_to_html(body_lines)
            if not body_html.strip():
                continue
            card_sections.append({
                "activityTitle": f"**{heading.upper()}**",
                "text": body_html,
                "markdown": True,
            })

        payload = {
            "@type":    "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0f2044",
            "summary": f"Platts APAC LNG MOC Early Snapshot — {session_date}",
            "sections": card_sections,
        }

    _post_teams(webhook_url, payload, label="Teams snapshot")