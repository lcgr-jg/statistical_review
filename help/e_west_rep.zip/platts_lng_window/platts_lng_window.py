
"""
Email report showing summary of Platts JKM Physical and Derivatives windows

"""


import logging
import os
import sys
import time
import traceback
import configparser
import platform
import pandas as pd
import spgci as ci

from datetime import datetime, timedelta
from typing import Optional, Tuple

from pathlib import Path

from dotenv import load_dotenv
from requests.exceptions import ConnectionError, HTTPError, Timeout

from jain_commods.core.util.dateutils import get_daybefore
from jain_commods.core.util.emailhelper import send_email

from util import (
    MOCSummaryGenerator,
    MOCEmailFormatter,
    send_teams_summary,
    generate_window_open_snapshot,
    send_teams_snapshot,
    fetch_platts_lng_news,
    singapore_holiday_calendar,
    singapore_holiday_name,
    botes_is_empty,
    explain_empty_botes_day,
    holiday_notice_email_html,
    send_teams_holiday_notice,
)

GAS_ALERTS_TEAMS_WEBHOOK_ENV = "GAS_ALERTS_TEAMS_WEBHOOK_URL"

# Platts/SPGCI occasionally returns 502/503/504; spgci's own tenacity retries are
# short-lived, so we add a longer outer backoff before failing the report.
_TRANSIENT_HTTP_STATUS = {502, 503, 504}


def _get_botes_with_retry(
    ewmd,
    *,
    market,
    order_time,
    paginate: bool = True,
    max_retries: int = 5,
    base_delay: float = 30.0,
):
    """Call EWindowMarketData.get_botes with retries on transient API failures."""
    last_exc: Optional[BaseException] = None
    for attempt in range(1, max_retries + 1):
        try:
            return ewmd.get_botes(market=market, order_time=order_time, paginate=paginate)
        except HTTPError as e:
            status = getattr(getattr(e, "response", None), "status_code", None)
            if status not in _TRANSIENT_HTTP_STATUS:
                raise
            last_exc = e
            if attempt >= max_retries:
                break
            delay = base_delay * (2 ** (attempt - 1))
            logging.warning(
                "Platts get_botes HTTP %s for market=%s order_time=%s "
                "(attempt %s/%s). Retrying in %.0fs...",
                status, market, order_time, attempt, max_retries, delay,
            )
            time.sleep(delay)
        except (ConnectionError, Timeout) as e:
            last_exc = e
            if attempt >= max_retries:
                break
            delay = base_delay * (2 ** (attempt - 1))
            logging.warning(
                "Platts get_botes connection error for market=%s order_time=%s "
                "(attempt %s/%s): %s. Retrying in %.0fs...",
                market, order_time, attempt, max_retries, e, delay,
            )
            time.sleep(delay)
    raise last_exc


def _fetch_prev_session_botes(ewmd, market, ref_date: datetime, max_lookback: int = 10):
    """
    Fetch BOTE data for the prior Platts session day.

    Skips weekends via get_daybefore and steps over Singapore public holidays
    (both proactively and when an empty response confirms a holiday miss).
    """
    sg = singapore_holiday_calendar(ref_date.year - 1, ref_date.year, ref_date.year + 1)
    d = get_daybefore(ref_date, calendar=sg)

    last_df = pd.DataFrame()
    for _ in range(max_lookback):
        logging.info(f"Querying Platts API (prior session): {d.strftime('%d %b %Y')}")
        last_df = _get_botes_with_retry(ewmd, market=market, order_time=d.date())
        if not botes_is_empty(last_df):
            return last_df, d

        reason = explain_empty_botes_day(d)
        if reason:
            logging.info("Empty prior-session BOTE response: %s Stepping back.", reason)
            d = get_daybefore(d, calendar=sg)
            continue

        logging.warning(
            "Empty prior-session BOTE response for %s and not a known Singapore holiday.",
            d.strftime('%d %b %Y'),
        )
        return last_df, d

    logging.warning("Exhausted lookback for prior-session BOTE data; last tried %s", d)
    return last_df, d


def _resolve_teams_webhook(config) -> Optional[str]:
    """Gas Alerts workflow URL from env; legacy cfg fallback for local dev only."""
    url = os.getenv(GAS_ALERTS_TEAMS_WEBHOOK_ENV)
    if url:
        return url
    return config.get('ReportSettings', 'teams_webhook', fallback=None)


def _load_local_dotenv() -> None:
    """Load .env files without overriding vars already in the process environment."""
    search_paths = [
        Path.cwd() / ".env",
        Path(__file__).resolve().parent / ".env",
        Path(__file__).resolve().parent.parent / ".env",
        Path(__file__).resolve().parent.parent.parent / "eu_commod_pipelines" / ".env",
    ]
    for env_path in search_paths:
        if env_path.exists():
            load_dotenv(env_path, override=False)


def _cfg_get(config, section: str, option: str) -> Optional[str]:
    value = config.get(section, option, fallback=None)
    if value is None:
        return None
    value = value.strip()
    return value or None


def _resolve_spgci_credentials(config) -> Tuple[str, str]:
    """Platts/SPGCI credentials from container env (same as news_report)."""
    _load_local_dotenv()
    user = (os.getenv("SPGCI_USERNAME") or "").strip() or _cfg_get(config, "PlattsApiConfig", "user")
    password = (os.getenv("SPGCI_PASSWORD") or "").strip() or _cfg_get(config, "PlattsApiConfig", "pass")
    if not user or not password:
        raise ValueError(
            "SPGCI credentials not configured. Set SPGCI_USERNAME and SPGCI_PASSWORD "
            "in the environment (or PlattsApiConfig user/pass locally)."
        )
    return user, password


def _resolve_claude_api_key(config) -> str:
    """Anthropic API key from env; optional cfg fallback for local dev only."""
    key = os.getenv("ANTHROPIC_API_KEY") or config.get('ClaudeOptions', 'api_key', fallback=None)
    if not key:
        raise ValueError(
            "Claude API key not configured. Set ANTHROPIC_API_KEY in the environment "
            "(or ClaudeOptions api_key locally)."
        )
    return key


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/platts_lng_window')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'platts_lng_window.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
days_history = config.getint('ReportSettings','days_history')
teams_webhook = _resolve_teams_webhook(config)

platts_user, platts_pass = _resolve_spgci_credentials(config)
claude_api_key = _resolve_claude_api_key(config)
enable_web_search = config.getboolean('ClaudeOptions','enable_web_search', fallback=True)
web_search_max_uses = config.getint('ClaudeOptions','web_search_max_uses', fallback=5)

news_days_back = config.getint('ReportSettings','news_days_back', fallback=3)

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_platts_lng_window.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

# Check cmd line switches to see what type of report we're sending
run_first_look = '--first_look' in sys.argv 


system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

today = datetime.now()

   
try:
    
    if run_first_look:
        logging.info('Generating window open snapshot')
        
        
        # ── 1. Load today & prior session data ────────────────────────────────
        
        # Connect to Platts
        ci.set_credentials(platts_user,platts_pass)
        ewmd = ci.EWindowMarketData()
        
        # Query data
        market_phys = 'ASIA LNG Physical'
        
        logging.info(f"Querying Platts API for {today.strftime('%d %b %Y')}")
        df_phys_today_snapshot = _get_botes_with_retry(
            ewmd, market=[market_phys], order_time=today.date()
        )

        # Empty today + Singapore holiday → Teams notice, skip normal snapshot
        if botes_is_empty(df_phys_today_snapshot):
            holiday_name = singapore_holiday_name(today)
            if holiday_name:
                logging.info(
                    "Empty today BOTE response confirmed as Singapore holiday (%s). "
                    "Sending Teams holiday notice.",
                    holiday_name,
                )
                send_teams_holiday_notice(
                    teams_webhook,
                    today,
                    holiday_name=holiday_name,
                )
                logging.info("Holiday notice sent via Teams")
                sys.exit(0)
            logging.warning(
                "Empty today BOTE response for %s and not a known Singapore holiday; "
                "continuing with empty snapshot.",
                today.strftime('%d %b %Y'),
            )

        df_phys_prev, prev_session = _fetch_prev_session_botes(
            ewmd, market=[market_phys], ref_date=today
        )
        logging.info(
            "Prior session for comparison: %s (rows=%s)",
            prev_session.strftime('%d %b %Y'),
            0 if botes_is_empty(df_phys_prev) else len(df_phys_prev),
        )
        
        # ── 2. Generate snapshot summary ──────────────────────────────────────
        
        # Generate markdown 
        phys_snapshot_md = generate_window_open_snapshot(df_phys_today_snapshot, df_phys_prev, today)
        
        
        # ── 3. Send summary via Teams ─────────────────────────────────────────
        
        # Send via Teams
        send_teams_snapshot(markdown_text = phys_snapshot_md,
                            webhook_url   = teams_webhook,
                            session_date  = today,
                            )
        
        logging.info("Snapshot sent via Teams")
        
    else:
    
    
        logging.info('Generating full phys & derviatives reports')
        
        
        # ── 1. Initialise ──────────────────────────────────────────────────────
        gen = MOCSummaryGenerator(
            api_key             = claude_api_key,
            enable_web_search   = enable_web_search,
            web_search_max_uses = web_search_max_uses,
        )
        
        
        # ── 2. Load today's data ───────────────────────────────────────────────
        
        # Connect to Platts
        ci.set_credentials(platts_user,platts_pass)
        ewmd = ci.EWindowMarketData()
    
        # Get permissioned markets
        # mkts = ewmd.get_markets()
        # Check available markets
        # print(mkts[mkts['max(order_date)']==pd.Timestamp(today.date())])
    
        # Get BOTEs (Bids, Offers, Trades)
        market_deriv = 'Asia LNG Derivative' 
        market_phys = 'ASIA LNG Physical'
        
        logging.info(f"Querying Platts API: {today.strftime('%d %b')}")
        
        df_botes_derivs_today = _get_botes_with_retry(ewmd, market=[market_deriv], order_time=today.date())
        df_botes_phys_today = _get_botes_with_retry(ewmd, market=[market_phys], order_time=today.date())

        # Empty today + Singapore holiday → holiday emails instead of MOC summaries
        if botes_is_empty(df_botes_phys_today):
            holiday_name = singapore_holiday_name(today)
            if holiday_name:
                logging.info(
                    "Empty today physical BOTE response confirmed as Singapore holiday (%s). "
                    "Sending holiday notice email.",
                    holiday_name,
                )
                if not botes_is_empty(df_botes_derivs_today):
                    logging.info(
                        "Derivatives BOTE data was present despite physical being empty; "
                        "still treating as holiday session for notifications."
                    )
                holiday_html = holiday_notice_email_html(today, holiday_name=holiday_name)
                send_email(
                    receivers,
                    f"Platts JKM MOC — Potential Pricing Holiday: {today.strftime('%d %b %Y')}",
                    holiday_html,
                    from_address='eu.gap.reports@jainglobal.com',
                )
                logging.info('Holiday notice email sent')
                sys.exit(0)
            logging.warning(
                "Empty today physical BOTE response for %s and not a known Singapore holiday; "
                "continuing with normal report generation.",
                today.strftime('%d %b %Y'),
            )
        
        
        # ── 3. Load history ─────────────────────────────────────────────────────
        
        # Get history for previous n days (& pre-compute to reduce payload to ChatGPT)
        botes_phys_history = []
        botes_derivs_history = []
        sg = singapore_holiday_calendar(today.year - 1, today.year, today.year + 1)
        
        for d in pd.date_range(today - timedelta(days=days_history), today - timedelta(days=1)):
            # Skip weekends / known SG holidays — no window expected
            if d.weekday() >= 5 or d.date() in sg:
                name = sg.get(d.date())
                logging.info(
                    "Skipping history day %s%s",
                    d.strftime('%d %b'),
                    f" (Singapore holiday: {name})" if name else " (weekend)",
                )
                continue

            logging.info(f"Querying Platts API: {d.strftime('%d %b')}")
        
            botes_derivs = _get_botes_with_retry(ewmd, market=["Asia LNG Derivative"], order_time=d.date())
            if botes_is_empty(botes_derivs):
                reason = explain_empty_botes_day(d)
                if reason:
                    logging.info("Empty derivatives history: %s", reason)
            elif len(botes_derivs) > 0:
                botes_derivs_history.append(botes_derivs)
        
            botes_phys = _get_botes_with_retry(ewmd, market=["Asia LNG Physical"], order_time=d.date())
            if botes_is_empty(botes_phys):
                reason = explain_empty_botes_day(d)
                if reason:
                    logging.info("Empty physical history: %s", reason)
            elif len(botes_phys) > 0:
                botes_phys_history.append(botes_phys)
        
        df_botes_derivs_history = pd.concat(botes_derivs_history, axis=0) if botes_derivs_history else pd.DataFrame()
        df_botes_phys_history = pd.concat(botes_phys_history, axis=0) if botes_phys_history else pd.DataFrame()
        
        
    
        # ── 4. Build additional context ────────────────────────────────────────
        # Combine (a) recent Platts LNG news pulled from the SPGCI Insights API
        # with (b) any manual desk colour. Claude additionally has live web
        # search enabled (see MOCSummaryGenerator) to fill any remaining gaps.
        logging.info('Fetching Platts LNG news for additional context')
        lng_news = fetch_platts_lng_news(days_back=news_days_back)

        # Manual freetext slot — add market-moving colour here when relevant.
        manual_context = ""

        context = "\n\n".join(part for part in (manual_context, lng_news) if part)
        
    
        # ── 5. Generate ────────────────────────────────────────────────────────
        session_date = today.strftime('%d %B %Y') #"2026-03-25"
    
        logging.info("Generating Claude physical summary...")
        phys_summary = gen.generate_physical_summary(
            today_df           = df_botes_phys_today,
            session_date       = session_date,
            history_df         = df_botes_phys_history,
            additional_context = context,
        )
    
        logging.info("Generating Claude derivatives summary...")
        deriv_summary = gen.generate_derivatives_summary(
            today_df           = df_botes_derivs_today,
            session_date       = session_date,
            history_df         = df_botes_derivs_history,
            additional_context = context,
        )
    
        
        # ── 6. Output ──────────────────────────────────────────────────────────
        
        logging.info('Generating emails')
        formatter = MOCEmailFormatter()
        
        # Construct phys HTML & send email
        phys_html = formatter.to_html(
            markdown_text = phys_summary,
            title         = "Physical MOC",
            session_date  = today.strftime("%d %B %Y"),
        )
        send_email(receivers, 
                   f"Platts JKM Physical MOC Summary: {today.strftime('%d %b %Y')}", 
                   phys_html,
                   from_address='eu.gap.reports@jainglobal.com') 
        
        
        # Construct deriv HTML & send email
        deriv_html = formatter.to_html(
            markdown_text = deriv_summary,
            title         = "Derivative MOC",
            session_date  = today.strftime("%d %B %Y"),
        )
        send_email(receivers, 
                   f"Platts JKM Derivatives MOC Summary: {today.strftime('%d %b %Y')}", 
                   deriv_html,
                   from_address='eu.gap.reports@jainglobal.com') 
        
        
        # Send via Teams
        logging.info('Sending Teams overview')
        send_teams_summary(markdown_text = phys_summary,
                           webhook_url   = teams_webhook,
                           session_date  = today.strftime("%d %B %Y"),
                           )
        
        send_teams_summary(markdown_text = deriv_summary,
                           webhook_url   = teams_webhook,
                           session_date  = today.strftime("%d %B %Y"),
                           )
        
        
        logging.info('Done')


except Exception:
    logging.error('Failed generating reports')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, 'ERROR Platts JKM Summary Report', str(tb))
    # Non-zero exit so Dagster asset RetryPolicy can re-run the job. Previously the
    # script swallowed the error and exited 0, so Dagster never retried.
    sys.exit(1)
