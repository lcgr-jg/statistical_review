import io
import base64
import time
import logging
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from jain_commods.core.interfaces.snowflake import SnowFlake

log = logging.getLogger(__name__)

# ------------------------------------------------------------
# get_report: returns HTML by default; if return_meta=True also
# returns a dict with counts so the wrapper can decide on retries.
# ------------------------------------------------------------
def get_report(return_meta: bool = False):
    # --- 1) Fetch & prepare data ---
    conn = SnowFlake(database='EEX', schema='MARKET_DATA', role='FR_COMMOD_PM_EU')
    conn._login
    cur = conn._conn.cursor()
    cur.execute("""
        SELECT COUNTRY, TIMESTAMP, PRICE, VOLUME
        FROM EEX.SPOT.PRICE_VOLUMES
        WHERE MARKET='DA' AND GRANULARITY='60 MIN'
        ORDER BY COUNTRY, TIMESTAMP
    """)
    df = cur.fetch_pandas_all()

    df['TIMESTAMP'] = (
        pd.to_datetime(df['TIMESTAMP'], utc=True)
          .dt.tz_convert('Europe/Berlin')
          .dt.tz_localize(None)
    )
    df['LocalDate'] = df['TIMESTAMP'].dt.normalize()
    df['Hour']      = df['TIMESTAMP'].dt.hour
    latest = df['LocalDate'].max()
    df['COUNTRY'] = df['COUNTRY'].replace({'DE': 'DE-LU'})

    # --- 2) Country/Zonal heatmaps with baseload/peakload annotations ---
    country_imgs = []
    for country in sorted(df['COUNTRY'].unique()):
        sub = df[(df['COUNTRY']==country) & (df['LocalDate']==latest)]
        if sub.empty:
            continue

        # compute metrics
        baseload = sub['PRICE'].mean()
        peakload = sub.loc[sub['Hour'].between(8,19), 'PRICE'].mean()

        pivot = sub.set_index('Hour')[['PRICE','VOLUME']].reindex(range(24))
        fig, ax = plt.subplots(figsize=(3,6), constrained_layout=False)
        fig.subplots_adjust(top=0.9)
        sns.heatmap(
            pivot[['PRICE']], cmap='RdYlGn',
            vmin=pivot['PRICE'].min(), vmax=pivot['PRICE'].max(),
            cbar=False, ax=ax
        )
        # annotate only the cell values, no baseload/peakload here
        for y, h in enumerate(pivot.index):
            p, v = pivot.at[h,'PRICE'], pivot.at[h,'VOLUME']
            if pd.notnull(p):
                ax.text(0.5, y+0.5, f"{p:.2f}", ha='center', va='center')
            if pd.notnull(v):
                ax.text(1.5, y+0.5, f"{v:,.0f}", ha='center', va='center')
        ax.set_xticks([0.5, 1.5])
        ax.set_xticklabels(['Price (€/MWh)', 'Volume'], fontsize=6)
        ax.set_yticks(range(24))
        ax.set_yticklabels(range(24), fontsize=6)
        ax.set_ylabel('Hour', fontsize=7)
        ax.set_title(country, fontsize=8)

        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        img = base64.b64encode(buf.getvalue()).decode('utf-8')
        country_imgs.append({
            'name':      country,
            'data':      img,
            'baseload':  f"{baseload:.2f}",
            'peakload':  f"{peakload:.2f}"
        })

    # --- 3) Cross-border spreads ---
    def get_borders():
        pairs = [
            ('AT','DE-LU'),('AT','CH'),('AT','HU'),('AT','SI'),
            ('BE','FR'),('BE','NL'),('BE','DE-LU'),
            ('CH','FR'),('CH','IT'),('CH','DE-LU'),
            ('DE-LU','FR'),('DE-LU','NL'),('DE-LU','PL'),('DE-LU','DK1'),
            ('DK1','DK2'),('DK1','DE-LU'),('DK2','SE4'),
            ('FI','SE1'),('FR','ES'),('FR','IT'),('FR','BE'),
            ('NL','BE'),('NL','DE-LU'),
            ('NO1','NO2'),('NO2','NO5'),('NO3','SE2'),('NO4','SE1'),
            ('PL','DE-LU'),('SE1','SE2'),('SE2','SE3'),('SE3','SE4')
        ]
        return list({tuple(sorted(p)) for p in pairs})

    spread_imgs = []
    for a, b in get_borders():
        da = df[(df['COUNTRY']==a) & (df['LocalDate']==latest)]
        db = df[(df['COUNTRY']==b) & (df['LocalDate']==latest)]
        if da.empty or db.empty:
            continue

        merged = pd.merge(
            da[['Hour','PRICE']], db[['Hour','PRICE']],
            on='Hour', suffixes=(f'_{a}', f'_{b}')
        )
        merged['SPREAD'] = merged[f'PRICE_{a}'] - merged[f'PRICE_{b}']
        pivot = merged.set_index('Hour')['SPREAD'].reindex(range(24))

        # compute spread metrics
        baseload_spread = pivot.mean()
        peakload_spread = pivot.loc[8:19].mean()

        fig, ax = plt.subplots(figsize=(3,6), constrained_layout=False)
        fig.subplots_adjust(top=0.88)
        sns.heatmap(
            pivot.to_frame(), annot=True, fmt='.2f',
            cmap='RdYlGn', center=0, ax=ax
        )

        # rename the single SPREAD column header:
        ax.set_xticks([0.5])
        ax.set_xticklabels(['Spread (€/MWh)'], fontsize=7)

        # annotate spread metrics above
        ax.set_yticks(range(24))
        ax.set_yticklabels(range(24), fontsize=6)
        ax.set_ylabel('Hour', fontsize=7)
        ax.set_title(f"{a}–{b}", fontsize=8)

        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=100)
        plt.close(fig)
        buf.seek(0)
        img = base64.b64encode(buf.getvalue()).decode('utf-8')
        spread_imgs.append({
            'name': f"{a}-{b}",
            'data': img,
            'baseload': f"{baseload_spread:.2f}",
            'peakload': f"{peakload_spread:.2f}"
        })

    # sort by highest baseload spread descending
    spread_imgs.sort(key=lambda x: float(x['baseload']), reverse=True)

    # --- 4) Assemble HTML email ---
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
  body{{font-family:Arial;color:#333;background:#f4f4f4;margin:0;padding:0}}
  .container{{max-width:800px;margin:auto;padding:20px;background:#fff}}
  h1{{margin-bottom:5px}}
  .section{{margin-top:30px}}
  .chart-title{{margin:5px 0}}
  img{{width:100%;height:auto;border:none}}
  .footer{{text-align:center;font-size:12px;color:#777;margin-top:30px}}
  table{{width:100%;border-collapse:collapse}}
  td{{padding:5px;vertical-align:top;width:33%}}
</style></head><body>
<div class="container">
  <h1>EPEX Daily Auction Report</h1>
  <p>Day-Ahead Results for: <strong>{latest.date()}</strong></p>

  <div class="section">
    <h2>Country / Zonal Prices</h2>
    <table><tr>
"""
    for i, img in enumerate(country_imgs):
        html += f"""
      <td>
        <div class="chart-title" style="font-size:14px; font-weight:bold; margin-bottom:4px;">
        {img['name']}
        </div>
        <div style="font-size:12px; margin-bottom:10px; color:#555;">
        Baseload: {img['baseload']} €/MWh &bull; Peakload: {img['peakload']} €/MWh
        </div>
        <img src="data:image/png;base64,{img['data']}">
      </td>
"""
        if (i % 3) == 2 and (i+1) < len(country_imgs):
            html += "    </tr><tr>\n"
    html += """
    </tr></table>
  </div>

  <div class="section">
    <h2>Cross-Border Spreads</h2>
    <table><tr>
"""
    for i, img in enumerate(spread_imgs):
        html += f"""
      <td>
        <div class="chart-title" style="font-size:14px; font-weight:bold; margin-bottom:4px;">
        {img['name']}
        </div>
        <div style="font-size:12px; margin-bottom:10px; color:#555;">
        Baseload: {img['baseload']} €/MWh &bull; Peakload: {img['peakload']} €/MWh
        </div>
        <img src="data:image/png;base64,{img['data']}">
      </td>
"""
        if (i % 3) == 2 and (i+1) < len(spread_imgs):
            html += "    </tr><tr>\n"
    html += f"""
    </tr></table>
  </div>

  <div class="footer">Report generated {ts}</div>
</div>
</body></html>
"""

    if return_meta:
        meta = {
            "country_count": len(country_imgs),
            "spread_count": len(spread_imgs),
            "latest_date": str(latest.date())
        }
        return html, meta

    return html


# ------------------------------------------------------------
# Wrapper: retry at absolute +15m and +45m from first attempt
# if country panels are too few (<= 3).
# Always returns HTML string.
# ------------------------------------------------------------
def _sleep_until(target_dt: datetime):
    delay = (target_dt - datetime.now()).total_seconds()
    if delay > 0:
        time.sleep(delay)

def get_report_with_retries(*, min_countries: int = 4,
                            checkpoints=(timedelta(minutes=15), timedelta(minutes=45))) -> str:
    """
    Run get_report(); if the number of country images is below `min_countries`,
    retry at absolute start+15m and start+45m. Returns the final HTML.
    """
    start = datetime.now()

    html, meta = get_report(return_meta=True)
    count = meta["country_count"]
    if count >= min_countries:
        return html

    log.warning("Only %d country panels on first run; retrying at +15m and +45m.", count)

    for offset in checkpoints:
        _sleep_until(start + offset)
        html, meta = get_report(return_meta=True)
        count = meta["country_count"]
        if count >= min_countries:
            return html
        log.warning("Retry at +%dm produced %d country panels.",
                    int(offset.total_seconds() // 60), count)

    # Return the last HTML even if still short
    return html