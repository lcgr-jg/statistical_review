
"""
Email report to compute NWE Polygon LNG volumes and send results

"""


import logging
import traceback
import configparser
import platform

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email

from util_15min import get_report_with_retries


REPORTS_PATH = Path(__file__).parent.resolve()


# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'epex_auction_results.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
'''
logging.basicConfig(filename = log_path / "epex_auction_results.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )
'''
system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'andre.leithaeuser@jainglobal.com'
    error_receivers= 'andre.leithaeuser@jainglobal.com'


email_subject = datetime.today().strftime('%Y-%m-%d') + " EPEX Day-Ahead Auction Results"

    
try:
    #logging.info('Generating report')

    # Generate report data
    email_body = get_report_with_retries(min_countries=4)
    
    # Send email
    send_email(receivers, 
               email_subject, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')    
    

    #logging.info('Report sent')
    

except Exception:
    #logging.error('Failed generating report')
    tb = traceback.format_exc()
    #logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))        