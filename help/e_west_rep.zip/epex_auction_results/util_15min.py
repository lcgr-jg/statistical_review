import io
import base64
import time
import logging
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from jain_commods.core.interfaces.snowflake import SnowFlake

log = logging.getLogger(__name__)

# ------------------------------------------------------------
# get_report: returns HTML by default; if return_meta=True also
# returns a dict with counts so the wrapper can decide on retries.
# ------------------------------------------------------------

# ---- GLOBAL SETTINGS ----
# toggle at module level if you want (default False)
RESAMPLE_HOUR = False

def get_report(return_meta: bool = False):
    # fallback to module-level toggle if defined
    try:
        RESAMPLE_HOUR = RESAMPLE_HOUR  # True => force hourly display
    except NameError:
        RESAMPLE_HOUR = False

    # --- 1) Fetch & prepare data (15m preferred, else 60m) -------------------
    conn = SnowFlake(database='EEX', schema='MARKET_DATA', role='FR_COMMOD_PM_EU')
    conn._login
    cur = conn._conn.cursor()
    cur.execute("""
        SELECT COUNTRY, TIMESTAMP, PRICE, VOLUME, GRANULARITY
        FROM EEX.SPOT.PRICE_VOLUMES
        WHERE MARKET='DA' AND GRANULARITY IN ('15 MIN','60 MIN')
        ORDER BY COUNTRY, TIMESTAMP
    """)
    df = cur.fetch_pandas_all()
    if df.empty:
        raise ValueError("No DA data found for 15/60 MIN.")

    # local time (Berlin), naive
    df['TIMESTAMP'] = (pd.to_datetime(df['TIMESTAMP'], utc=True)
                         .dt.tz_convert('Europe/Berlin')
                         .dt.tz_localize(None))
    df['COUNTRY']   = df['COUNTRY'].replace({'DE': 'DE-LU'})
    df['LocalDate'] = df['TIMESTAMP'].dt.normalize()
    latest          = df['LocalDate'].max()

    # convenience columns for 15m & 60m floors, and hour for peak computation
    df['Slot15'] = df['TIMESTAMP'].dt.floor('15min')
    df['Slot60'] = df['TIMESTAMP'].dt.floor('60min')
    df['Hour']   = df['TIMESTAMP'].dt.hour

    def _country_panel(sub_all: pd.DataFrame, country: str):
        """
        Country/zonal heatmap.
        - If RESAMPLE_HOUR is True -> display & metrics hourly.
        - Else prefer 15m if available for this country on 'latest' day; fallback hourly.
        - Show EVERY interval label.
        """
        # read module-level toggle safely
        FORCE_HOURLY = bool(globals().get("RESAMPLE_HOUR", False))

        sub_all = sub_all[sub_all['LocalDate'] == latest].copy()
        if sub_all.empty:
            return None

        # make sure slot columns exist
        if 'Slot15' not in sub_all.columns:
            sub_all['Slot15'] = pd.to_datetime(sub_all['TIMESTAMP']).dt.floor('15min')
        if 'Slot60' not in sub_all.columns:
            sub_all['Slot60'] = pd.to_datetime(sub_all['TIMESTAMP']).dt.floor('60min')

        # detect if 15m data exists for this country/day
        has_15 = (sub_all.get('GRANULARITY', pd.Series()).eq('15 MIN').any()
                or sub_all['Slot15'].nunique() > 48)

        # decide granularity
        show_hourly = FORCE_HOURLY or not has_15

        day0 = latest
        if show_hourly:
            idx = pd.date_range(day0, day0 + pd.Timedelta(days=1),
                                freq='60min', inclusive='left', name='Slot60')
            grid = (sub_all.groupby('Slot60', as_index=True)
                            .agg(PRICE=('PRICE', 'mean'), VOLUME=('VOLUME', 'sum'))
                            .reindex(idx))
            labels   = [f"{t:%H:%M}–{(t + pd.Timedelta(hours=1)):%H:%M}" for t in idx]
            nrows    = len(idx)
            per_row  = 0.20
            baseload = float(grid['PRICE'].mean()) if grid['PRICE'].notna().any() else np.nan
            peak     = float(grid['PRICE'][(idx.hour >= 8) & (idx.hour <= 19)].mean()) if grid['PRICE'].notna().any() else np.nan
        else:
            idx = pd.date_range(day0, day0 + pd.Timedelta(days=1),
                                freq='15min', inclusive='left', name='Slot15')
            grid = (sub_all.groupby('Slot15', as_index=True)
                            .agg(PRICE=('PRICE', 'mean'), VOLUME=('VOLUME', 'sum'))
                            .reindex(idx))
            labels   = [f"{t:%H:%M}–{(t + pd.Timedelta(minutes=15)):%H:%M}" for t in idx]
            nrows    = len(idx)
            per_row  = 0.155
            baseload = float(grid['PRICE'].mean()) if grid['PRICE'].notna().any() else np.nan
            # peak 08:00–19:59 in local time
            peak     = float(grid['PRICE'].between_time('08:00', '19:59').mean()) if grid['PRICE'].notna().any() else np.nan

        # --- plotting (wider left margin for dense labels) ---
        fig_h = float(np.clip(nrows * per_row, 6.0, 28.0))
        fig, ax = plt.subplots(figsize=(4.3, fig_h))
        plt.subplots_adjust(top=0.90, left=0.60, right=0.98)

        vmin = grid['PRICE'].min(skipna=True) if grid['PRICE'].notna().any() else None
        vmax = grid['PRICE'].max(skipna=True) if grid['PRICE'].notna().any() else None
        sns.heatmap(grid[['PRICE']], cmap='RdYlGn', vmin=vmin, vmax=vmax, cbar=False, ax=ax)

        # annotate EVERY interval (price in-cell; volume to the right)
        for y in range(nrows):
            p = grid['PRICE'].iloc[y]
            v = grid['VOLUME'].iloc[y]
            if pd.notna(p):
                ax.text(0.5, y + 0.5, f"{p:.2f}", ha='center', va='center', fontsize=6.7)
            if pd.notna(v):
                ax.text(1.55, y + 0.5, f"{v:,.0f}", ha='center', va='center', fontsize=6.2, clip_on=False)

        ax.set_xticks([0.5, 1.5])
        ax.set_xticklabels(['Price (€/MWh)', 'Volume'], fontsize=7)

        ax.set_yticks(np.arange(0.5, nrows + 0.5, 1))
        ax.set_yticklabels(labels, fontsize=6.2)
        ax.set_ylabel('Interval', fontsize=7)
        ax.set_title(country, fontsize=9)

        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=132, bbox_inches='tight')
        plt.close(fig)
        img = base64.b64encode(buf.getvalue()).decode('utf-8')

        return {
            'name': country,
            'data': img,
            'baseload': f"{baseload:.2f}" if pd.notna(baseload) else "NA",
            'peakload': f"{peak:.2f}" if pd.notna(peak) else "NA",
        }

    def _spread_panel(da_all: pd.DataFrame, db_all: pd.DataFrame, a: str, b: str):
        """
        Cross-border spread heatmap (A - B).
        - If RESAMPLE_HOUR is True -> display & metrics hourly.
        - Else use 15m only if BOTH sides have 15m; fallback hourly.
        - Show EVERY interval label.
        """
        FORCE_HOURLY = bool(globals().get("RESAMPLE_HOUR", False))

        # ensure LocalDate/slots exist
        for dfX in (da_all, db_all):
            if 'LocalDate' not in dfX.columns:
                dfX['TIMESTAMP'] = pd.to_datetime(dfX['TIMESTAMP'], utc=True)\
                                    .dt.tz_convert('Europe/Berlin')\
                                    .dt.tz_localize(None)
                dfX['LocalDate'] = dfX['TIMESTAMP'].dt.normalize()
            if 'Slot15' not in dfX.columns:
                dfX['Slot15'] = pd.to_datetime(dfX['TIMESTAMP']).dt.floor('15min')
            if 'Slot60' not in dfX.columns:
                dfX['Slot60'] = pd.to_datetime(dfX['TIMESTAMP']).dt.floor('60min')

        latest_local = min(
            da_all['LocalDate'].max() if not da_all.empty else pd.NaT,
            db_all['LocalDate'].max() if not db_all.empty else pd.NaT
        )
        da = da_all[da_all['LocalDate'] == latest_local].copy()
        db = db_all[db_all['LocalDate'] == latest_local].copy()
        if da.empty or db.empty:
            return None

        def _has_15(dfX: pd.DataFrame) -> bool:
            return (dfX.get('GRANULARITY', pd.Series()).eq('15 MIN').any()
                    or dfX['Slot15'].nunique() > 48)

        # decide granularity
        if FORCE_HOURLY:
            use_15 = False
        else:
            use_15 = _has_15(da) and _has_15(db)

        if use_15:
            gcol    = 'Slot15'
            step_td = pd.Timedelta(minutes=15)
            idx = pd.date_range(latest_local, latest_local + pd.Timedelta(days=1),
                                freq='15min', inclusive='left', name=gcol)
            per_row = 0.155
        else:
            gcol    = 'Slot60'
            step_td = pd.Timedelta(hours=1)
            idx = pd.date_range(latest_local, latest_local + pd.Timedelta(days=1),
                                freq='60min', inclusive='left', name=gcol)
            per_row = 0.20

        A = da.groupby(gcol, as_index=True)['PRICE'].mean().reindex(idx)
        B = db.groupby(gcol, as_index=True)['PRICE'].mean().reindex(idx)
        spread = A - B

        labels = [f"{t:%H:%M}–{(t + step_td):%H:%M}" for t in idx]
        nrows  = len(idx)

        # metrics on the displayed granularity
        baseload_spread = float(spread.mean()) if spread.notna().any() else np.nan
        peak_mask = (idx.hour >= 8) & (idx.hour <= 19)
        peak_spread = float(spread[peak_mask].mean()) if peak_mask.any() else np.nan

        # plot
        fig_h = float(np.clip(nrows * per_row, 6.0, 28.0))
        fig, ax = plt.subplots(figsize=(4.3, fig_h))
        plt.subplots_adjust(top=0.90, left=0.60, right=0.98)

        pv = spread.to_frame('SPREAD')
        vmin = pv['SPREAD'].min(skipna=True) if pv['SPREAD'].notna().any() else None
        vmax = pv['SPREAD'].max(skipna=True) if pv['SPREAD'].notna().any() else None

        sns.heatmap(
            pv, annot=False, fmt='.2f',
            cmap='RdYlGn', center=0, cbar=False,
            vmin=vmin, vmax=vmax, ax=ax
        )

        # annotate EVERY interval value
        for y in range(nrows):
            v = spread.iloc[y]
            if pd.notna(v):
                ax.text(0.5, y + 0.5, f"{v:.2f}", ha='center', va='center', fontsize=6.5, color='black')

        ax.set_xticks([0.5])
        ax.set_xticklabels(['Spread (€/MWh)'], fontsize=7)
        ax.set_yticks(np.arange(0.5, nrows + 0.5, 1))
        ax.set_yticklabels(labels, fontsize=6.2)
        ax.set_ylabel('Interval', fontsize=7)
        ax.set_title(f"{a}–{b}", fontsize=9)

        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=132, bbox_inches='tight')
        plt.close(fig)
        img = base64.b64encode(buf.getvalue()).decode('utf-8')

        return {
            'name': f"{a}-{b}",
            'data': img,
            'baseload': f"{baseload_spread:.2f}" if pd.notna(baseload_spread) else "NA",
            'peakload': f"{peak_spread:.2f}"     if pd.notna(peak_spread)     else "NA",
        }

    def get_borders():
        pairs = [
            ('AT','DE-LU'),('AT','CH'),('AT','HU'),('AT','SI'),
            ('BE','FR'),('BE','NL'),('BE','DE-LU'),
            ('CH','FR'),('CH','IT'),('CH','DE-LU'),
            ('DE-LU','FR'),('DE-LU','NL'),('DE-LU','PL'),('DE-LU','DK1'),
            ('DK1','DK2'),('DK1','DE-LU'),('DK2','SE4'),
            ('FI','SE1'),('FR','ES'),('FR','IT'),('FR','BE'),
            ('NL','BE'),('NL','DE-LU'),
            ('NO1','NO2'),('NO2','NO5'),('NO3','SE2'),('NO4','SE1'),
            ('PL','DE-LU'),('SE1','SE2'),('SE2','SE3'),('SE3','SE4')
        ]
        return list({tuple(sorted(p)) for p in pairs})

    # --- 2) Build images ------------------------------------------------------
    country_imgs = []
    for c in sorted(df['COUNTRY'].unique()):
        sub_c = df[df['COUNTRY'] == c]
        item = _country_panel(sub_c, c)
        if item:
            country_imgs.append(item)

    spread_imgs = []
    for a, b in get_borders():
        da = df[df['COUNTRY'] == a]
        db = df[df['COUNTRY'] == b]
        item = _spread_panel(da, db, a, b)
        if item:
            spread_imgs.append(item)

    # sort spreads by highest baseload
    def _as_float(x):
        try:
            return float(x)
        except Exception:
            return -1e9
    spread_imgs.sort(key=lambda x: _as_float(x['baseload']), reverse=True)

    # --- 4) Assemble HTML email (unchanged) ----------------------------------
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
  body{{font-family:Arial;color:#333;background:#f4f4f4;margin:0;padding:0}}
  .container{{max-width:800px;margin:auto;padding:20px;background:#fff}}
  h1{{margin-bottom:5px}}
  .section{{margin-top:30px}}
  .chart-title{{margin:5px 0}}
  img{{width:100%;height:auto;border:none}}
  .footer{{text-align:center;font-size:12px;color:#777;margin-top:30px}}
  table{{width:100%;border-collapse:collapse}}
  td{{padding:5px;vertical-align:top;width:33%}}
</style></head><body>
<div class="container">
  <h1>EPEX Daily Auction Report</h1>
  <p>Day-Ahead Results for: <strong>{latest.date()}</strong></p>

  <div class="section">
    <h2>Country / Zonal Prices</h2>
    <table><tr>
"""
    for i, img in enumerate(country_imgs):
        html += f"""
      <td>
        <div class="chart-title" style="font-size:14px; font-weight:bold; margin-bottom:4px;">
        {img['name']}
        </div>
        <div style="font-size:12px; margin-bottom:10px; color:#555;">
        Baseload: {img['baseload']} €/MWh &bull; Peakload: {img['peakload']} €/MWh
        </div>
        <img src="data:image/png;base64,{img['data']}">
      </td>
"""
        if (i % 3) == 2 and (i+1) < len(country_imgs):
            html += "    </tr><tr>\n"
    html += """
    </tr></table>
  </div>

  <div class="section">
    <h2>Cross-Border Spreads</h2>
    <table><tr>
"""
    for i, img in enumerate(spread_imgs):
        html += f"""
      <td>
        <div class="chart-title" style="font-size:14px; font-weight:bold; margin-bottom:4px;">
        {img['name']}
        </div>
        <div style="font-size:12px; margin-bottom:10px; color:#555;">
        Baseload: {img['baseload']} €/MWh &bull; Peakload: {img['peakload']} €/MWh
        </div>
        <img src="data:image/png;base64,{img['data']}">
      </td>
"""
        if (i % 3) == 2 and (i+1) < len(spread_imgs):
            html += "    </tr><tr>\n"
    html += f"""
    </tr></table>
  </div>

  <div class="footer">Report generated {ts}</div>
</div>
</body></html>
"""

    if return_meta:
        meta = {
            "country_count": len(country_imgs),
            "spread_count": len(spread_imgs),
            "latest_date": str(latest.date())
        }
        return html, meta

    return html

# ------------------------------------------------------------
# Wrapper: retry at absolute +15m and +45m from first attempt
# if country panels are too few (<= 3).
# Always returns HTML string.
# ------------------------------------------------------------
def _sleep_until(target_dt: datetime):
    delay = (target_dt - datetime.now()).total_seconds()
    if delay > 0:
        time.sleep(delay)

def get_report_with_retries(*, min_countries: int = 4,
                            checkpoints=(timedelta(minutes=15), timedelta(minutes=45))) -> str:
    """
    Run get_report(); if the number of country images is below `min_countries`,
    retry at absolute start+15m and start+45m. Returns the final HTML.
    """
    start = datetime.now()

    html, meta = get_report(return_meta=True)
    count = meta["country_count"]
    if count >= min_countries:
        return html

    log.warning("Only %d country panels on first run; retrying at +15m and +45m.", count)

    for offset in checkpoints:
        _sleep_until(start + offset)
        html, meta = get_report(return_meta=True)
        count = meta["country_count"]
        if count >= min_countries:
            return html
        log.warning("Retry at +%dm produced %d country panels.",
                    int(offset.total_seconds() // 60), count)

    # Return the last HTML even if still short
    return html