import io
import base64
import logging
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from pathlib import Path
from matplotlib.colors import LinearSegmentedColormap, Normalize

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
from common.dashboard_header import dashboard_header_for

from jain_commods.core.interfaces.bloomberg import BBGQuery
from jain_commods.core.interfaces.sqldb import KplerQuery, DataQuery
from jain_commods.fundamental.gas import util
from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table
from jain_commods.core.util.htmlutils import df2html
from jain_commods.core.interfaces.commodityessentials import CElink



# Template URL for clicking through to BBG and Kpler
bbg_map_url = 'bbg://screens/MAP IMO {}'
kpler_map_url = 'https://terminal.kpler.com/map/search/voyages?fields=vessel&vessels={}'

report_font_family = 'Calibri'
report_font_size = '14'

# Kpler full name / short display name
country_codes = {'Belgium':'BE',
                 'Germany':'DE',
                 'France':'FR',
                 'United Kingdom':'UK',
                 'Italy':'IT',
                 'Netherlands':'NL',
                 }

zone_config = {'NWE': list(country_codes.keys())}

ce_user = 'john.morley@jainglobal.com'
ce_pass = 'Knockers99!'

# Hard coded CE asset IDs for our 6 countries
lng_asset_ids = '457,676,687,1779,467,476'


def get_lng_regas(start_date):
    
    ce=CElink(ce_user,ce_pass)
    # LNG regas across our perimeter
    # NB: we set dateTo as today as we sometimes see DA noms
    df_regas=ce.eugasopdata(assets=lng_asset_ids, unit='mcm', variable='withdrawal',dateFrom=start_date.strftime('%Y-%m-%d'),dateTo=datetime.now().strftime('%Y-%m-%d')).set_index('Date').drop(columns=['DateExcel'])
    df_regas.index = pd.to_datetime(df_regas.index)
    df_regas['Total'] = df_regas.sum(axis=1)
        
    return df_regas[['Total']]


def get_lng_terminal_regas_maint(days_back=7, days_forward=14):
    
    ce=CElink(ce_user,ce_pass)

    # Get CE metadata (so we can confidently rename them below and not rely on column ordering)    
    ce_metadata_spa = ce.eugasmeta(id='seriesperasset')
    
    # Upcoming LNG maint across our perimeter
    lng_terminal_asset_ids = [663
                                ,3198
                                ,3312
                                ,3197
                                ,184
                                ,182
                                ,3261
                                ,181
                                ,164
                                ,167
                                ,165
                                ,1793
                                ,1795
                                ,3247
                                ,3412
                                ,1794
                                ,3136
                                ,214
                                ]
    
    today = pd.Timestamp.today().normalize()
    start_date = today - timedelta(days=days_back)
    end_date = today + timedelta(days=days_forward)
    
    # Get maintenance data
    df_maint = ce.eugasout(assets=lng_terminal_asset_ids, unit='mcm', variable='withdrawal',dateFrom=start_date.strftime('%Y-%m-%d'), dateTo=end_date.strftime('%Y-%m-%d'))
    df_maint['Date'] = pd.to_datetime(df_maint['Date'], format='%d-%b-%Y')
    df_maint['Updated'] = pd.to_datetime(df_maint['Updated'], format='%d-%b-%Y')
    # Some terminals have nan instead of zeros in the important "Out.Total" column
    df_maint['Out.Total'] = df_maint['Out.Total'].fillna(0)
    # Get the technical capacities
    latest_tech_caps = df_maint.sort_values('Updated', ascending=False).drop_duplicates(['assetName'])[['assetName', 'Tech.Cap']]
    tech_caps = dict(zip(latest_tech_caps['assetName'], latest_tech_caps['Tech.Cap']))
    # Create table of upcoming maint
    df_output = df_maint.pivot_table(
                    index='Date',
                    columns=[df_maint['Market'] + '|' + df_maint['assetName']],
                    values='Out.Total',
                    aggfunc='first'
                )
    # Create new column names
    df_output.columns = pd.MultiIndex.from_tuples([(c.split('|')[0],f"{c.split('|')[1]} ({tech_caps[c.split('|')[1]]:.0f})") for c in df_output.columns], names=['Country','Terminal'])
    
    
    # Get regas data per terminal
    df_regas = ce.eugasopdata(assets=lng_terminal_asset_ids, unit='mcm', variable='withdrawal',dateFrom=start_date.strftime('%Y-%m-%d'), dateTo=today.strftime('%Y-%m-%d')).set_index('Date').drop(columns=['DateExcel'])
    df_regas.columns = [f"{ce_metadata_spa[ce_metadata_spa['seriesId']==int(c)].iloc[0]['direction']}|{ce_metadata_spa[ce_metadata_spa['seriesId']==int(c)].iloc[0]['assetName']}" for c  in df_regas.columns] 
    
    # Create new column names
    df_regas.columns = pd.MultiIndex.from_tuples([(c.split('|')[0],f"{c.split('|')[1]} ({tech_caps[c.split('|')[1]]:.0f})") for c in df_regas.columns], names=['Country','Terminal'])
    
    
    # Add totals
    df_regas[('Total','Total Regas')] = df_regas.sum(axis=1)
    df_output[('Total','Total Maint')] = df_output.sum(axis=1)
    
   
    return df_regas, df_output



def get_lng_stocks(start_date, fill_pc_only=True):

    
    # Query CE
    ce = CElink(ce_user,ce_pass)
    df_stock = ce.eugasopdata(assets=lng_asset_ids, unit='mcm', variable='stock', dateFrom=start_date.strftime('%Y-%m-%d')).set_index('Date').drop(columns=['DateExcel'])
    df_stockcapa = ce.eugasopdata(assets=lng_asset_ids, unit='mcm', variable='stockcapacity', dateFrom=start_date.strftime('%Y-%m-%d')).set_index('Date').drop(columns=['DateExcel'])
    
    # Tidy up
    df_stock.index = pd.to_datetime(df_stock.index)
    df_stockcapa.index = pd.to_datetime(df_stockcapa.index)
    
    # Forward fill to cover missing stocks for current day
    df_stock = df_stock.ffill()
    
    # Add total
    df_stock['Stock'] = df_stock.sum(axis=1)
    df_stockcapa['Capacity'] = df_stockcapa.sum(axis=1)
    
    # Combine and calculate fill level
    df_output = pd.concat([df_stock[['Stock']],df_stockcapa[['Capacity']]], axis=1).dropna()
    df_output['fill_pc'] = df_stock['Stock'] / df_stockcapa['Capacity']
    
    if fill_pc_only:    
        return df_output[['fill_pc']]
    else:
        return df_output



def get_bbg_lng_water(start_year):
    
    bbg_session = BBGQuery(p_on_server=True)
    start_date = datetime(start_year, 1, 1)
    end_date = datetime.today()
    lng_on_water=bbg_session.fetch_hist(['LNGG20DC Index','LNGG30DC Index'],
                                        ["PX_LAST"],
                                        start_date,
                                        end_date)
    bbg_session._close_session()
    lng_on_water.columns = [f"{c.replace('DC Index_PX_LAST','').replace('LNGG','')} days" for c in lng_on_water.columns]
    
    lng_on_water.index = pd.to_datetime(lng_on_water.index)
    
    return lng_on_water



def plot_seasonal_lng_on_water(start_year):
    
    # query BBG to get the data
    df = get_bbg_lng_water(start_year=2019)
    
    # Create figure with two subplots side by side
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 6))
    
    # Get the current year and previous year
    current_year = df.index.max().year
    previous_year = current_year - 1
    
    # Get list of previous years (so we can label the historic range)
    hist_range = [yr for yr in set(df.index.year) if yr not in [current_year, previous_year]]
    
    # Create a copy of the dataframe to avoid modifying the original
    df_copy = df.copy()
    
    # Extract day of year for indexing
    df_copy['doy'] = df_copy.index.dayofyear
    
    # Data for current year
    current_year_data = df_copy[df_copy.index.year == current_year]
    
    # Data for previous year
    previous_year_data = df_copy[df_copy.index.year == previous_year]
    
    # Historical data (all years except current and previous)
    historical_years = df_copy[df_copy.index.year < previous_year]
    
    # Create a standard date range for the x-axis (Jan 1 to Dec 31)
    days_in_year = pd.date_range(start=f'{current_year}-01-01', 
                               end=f'{current_year}-12-31', freq='D')
    
    # Function to plot data for a given column and axis
    def plot_lng_data(ax, column_name, title_suffix):
        # Process historical data to get min/max ranges
        if not historical_years.empty:
            # Initialize arrays to store min and max values for each day of year
            days_count = 366  # Account for leap years
            min_by_doy = np.full(days_count, np.nan)
            max_by_doy = np.full(days_count, np.nan)
            
            # Group by day of year and compute min and max of 7-day moving averages
            # First calculate 7-day MA for each historical year
            historical_years_ma = historical_years.copy()
            for year, year_data in historical_years.groupby(historical_years.index.year):
                # Sort by day of year
                year_data = year_data.sort_values('doy')
                # Calculate 7-day moving average
                year_data[f'ma_{column_name}'] = year_data[column_name].rolling(window=7, min_periods=1).mean()
                # Update the values in our dataframe
                historical_years_ma.loc[year_data.index, f'ma_{column_name}'] = year_data[f'ma_{column_name}'].values
            
            # Now use the MA values to compute the historical range
            for doy, group in historical_years_ma.groupby('doy'):
                if 1 <= doy <= days_count:  # Ensure we stay within array bounds
                    min_by_doy[doy-1] = group[f'ma_{column_name}'].min()
                    max_by_doy[doy-1] = group[f'ma_{column_name}'].max()
            
            # Interpolate any missing values
            min_series = pd.Series(min_by_doy).interpolate(method='linear')
            max_series = pd.Series(max_by_doy).interpolate(method='linear')
            
            # Plot the historical range
            ax.fill_between(days_in_year[:len(min_series)], 
                           min_series.values[:len(days_in_year)], 
                           max_series.values[:len(days_in_year)],
                           color='gray', alpha=0.3, label=f'Hist Range {hist_range[0]}-{hist_range[-1]} (7d MA)')
        
        # Process and plot previous year data
        if not previous_year_data.empty:
            # Create a day-of-year to fill_pc mapping for previous year
            previous_year_map = pd.Series(
                index=previous_year_data['doy'],
                data=previous_year_data[column_name].values
            )
            
            # Reindex to standard days (use full year for previous year)
            standard_days = np.arange(1, 367)
            previous_year_series = previous_year_map.reindex(standard_days).interpolate(method='linear')
            
            # Calculate 7-day moving average
            previous_year_ma = previous_year_series.rolling(window=7, min_periods=1).mean()
            
            # Plot with current year dates for proper alignment
            valid_length = min(len(previous_year_series), len(days_in_year))
            ax.plot(days_in_year[:valid_length], 
                   previous_year_series.values[:valid_length],
                   color='#5499C7', linestyle='--', linewidth=1, alpha=0.5,
                   label=f'{previous_year} (Daily)')
                   
            # Plot the 7-day moving average
            ax.plot(days_in_year[:valid_length], 
                   previous_year_ma.values[:valid_length],
                   color='#5499C7', linewidth=2, 
                   label=f'{previous_year} (7d MA)')
        
        # Process and plot current year data
        if not current_year_data.empty:
            # Create a day-of-year to fill_pc mapping for current year
            current_year_map = pd.Series(
                index=current_year_data['doy'],
                data=current_year_data[column_name].values
            )
            
            # Only use the actual days we have data for (don't extrapolate future dates)
            max_doy = current_year_data['doy'].max()
            standard_days = np.arange(1, max_doy + 1)
            
            # Create series and interpolate missing days within our actual date range
            current_year_series = current_year_map.reindex(standard_days).interpolate(method='linear')
            
            # Calculate 7-day moving average
            current_year_ma = current_year_series.rolling(window=7, min_periods=1).mean()
            
            # Plot with current year dates for proper alignment
            valid_length = min(len(current_year_series), len(days_in_year))
            ax.plot(days_in_year[:valid_length], 
                   current_year_series.values[:valid_length],
                   color='#1A5276', linewidth=1, alpha=0.5,
                   label=f'{current_year} (Daily)')
                   
            # Plot the 7-day moving average
            ax.plot(days_in_year[:valid_length], 
                   current_year_ma.values[:valid_length],
                   color='#1A5276', linewidth=2, 
                   label=f'{current_year} (7d MA)')
        
        # Set labels and title
        ax.set_ylabel('Vessel Count', fontsize=12)
        current_value = df_copy.iloc[-1][column_name]
        ax.set_title(f"{title_suffix} (7d MA) | Vessels today {current_value:.0f}", fontsize=12)
        
        # Set x-axis to show months
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
        
        # Add minor grid for weeks
        ax.xaxis.set_minor_locator(mdates.WeekdayLocator(byweekday=0))  # Minor ticks on Mondays
        ax.grid(True, linestyle='-', alpha=0.2)
        ax.grid(True, which='minor', linestyle=':', alpha=0.2)
        
        # Add legend with better positioning (will be removed later for central legend)
        ax.legend(loc='upper right', ncol=2, framealpha=0.7, fontsize=10)
        
        # Set y-axis limits with some padding
        min_val = df[column_name].min() * 0.95
        max_val = df[column_name].max() * 1.05
        ax.set_ylim(min_val, max_val)
    
    # Plot 20 days data on the first subplot (left)
    plot_lng_data(ax1, '20 days', '20 Days')
    
    # Plot 30 days data on the second subplot (right)
    plot_lng_data(ax2, '30 days', '30 Days')
    
    # Add central title
    fig.suptitle('LNG On The Water: Total Vessel Count', fontsize=16, y=0.98)
    
    # Collect legend handles and labels from both subplots
    handles1, labels1 = ax1.get_legend_handles_labels()
    handles2, labels2 = ax2.get_legend_handles_labels()
    
    # Remove individual legends
    ax1.legend().remove()
    ax2.legend().remove()
    
    # Create single legend at bottom
    fig.legend(handles1, labels1, loc='lower center', ncol=len(labels1), 
               bbox_to_anchor=(0.5, -0.05), framealpha=0.7, fontsize=10)
    
    # Adjust layout to make room for legend and title
    plt.tight_layout()
    plt.subplots_adjust(top=0.9, bottom=0.15)
    plt.tight_layout()
    
    # plt.show()
        
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)
    
    return plot_base64



def create_arrivals_chart(rolling_months_history=3, ma_window=14, start_date=datetime(2022,1,1)):
    
    dq = DataQuery(logintype='prod')
    
    # Get all historical data
    historical_data = dq.get_data(by='metadata', 
                                 start_date=start_date - timedelta(days=ma_window), # adjust start date to include MA window
                                 querytype='bulk',
                                 metadata={'source1': 'JainGlobal',
                                           'geography1': 'NWE',
                                           'category1': 'Supply',
                                           'category2': 'Volume',
                                           'category3': 'total',
                                           'category4': 'port_ais,kpler',
                                           })
    
    # Process historical data
    historical_dfs = []
    for k, df in historical_data.items():
        confidence = df.name.split('.')[5]
        historical_dfs.append(df.set_index('date')[['value']].rename(columns={'value':confidence}))
    df_historical = pd.concat(historical_dfs, axis=1)
    
    # Get data for rolling window (left subplot)
    df_rolling = df_historical.loc[(datetime.now() - relativedelta(months=rolling_months_history)) - timedelta(days=ma_window):]
    
    
    # Calculate simple moving average for rolling data
    df_rolling[f'{ma_window}d_sma'] = df_rolling['port_ais'].rolling(window=ma_window).mean()
    df_rolling = df_rolling.dropna()
    
    
    # Calculate simple moving average for historical data
    df_historical[f'{ma_window}d_sma'] = df_historical['port_ais'].rolling(window=ma_window).mean()
    df_historical = df_historical.dropna()
    
    # Create the figure with subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 6))
    
    # Calculate latest value and day-on-day change
    latest_value = df_rolling['port_ais'].iloc[-1]
    previous_value = df_rolling['port_ais'].iloc[-2]
    dod = latest_value - previous_value
    dod_pct = (dod / previous_value) * 100 if previous_value != 0 else 0
    
    # Add overall chart title
    fig.suptitle(f"LNG Volume Signalling {', '.join(country_codes.values())} (Port+AIS)\nLatest: {latest_value:,.0f}mcm | DoD: {dod:,.0f}mcm ({dod_pct:.0f}%)", fontsize=16, y=0.96)
    
    # Left subplot - Rolling window data
    ax1.plot(df_rolling.index, df_rolling['port_ais'], label='Port+AIS', color='#1A5276', linewidth=1, alpha=0.5)
    ax1.plot(df_rolling.index, df_rolling[f'{ma_window}d_sma'], label=f'{ma_window}d MA', color='#1A5276', linewidth=2)
    
    # Format left subplot
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%d %b-%y'))
    ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
    ax1.set_xlim(df_rolling.index[0], df_rolling.index[-1])
    
    ax1.set_ylabel('mcm/d')
    ax1.set_title(f"{rolling_months_history} months rolling window")
    ax1.grid(True, linestyle='--', alpha=0.7)
    
    # Right subplot - Historical data
    ax2.plot(df_historical.index, df_historical['port_ais'], label='Port+AIS', color='#1A5276', linewidth=1, alpha=0.5)
    ax2.plot(df_historical.index, df_historical[f'{ma_window}d_sma'], label=f'{ma_window}d MA', color='#1A5276', linewidth=2)
    
    # Format right subplot
    ax2.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
    ax2.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    
    ax2.set_xlim(df_historical.index[0], df_historical.index[-1])
    ax2.set_ylabel('mcm/d')
    ax2.set_title(f"Historical Data Since {start_date.strftime('%b-%y')}")
    ax2.grid(True, linestyle='--', alpha=0.7)
    
    # Add single legend for both subplots
    fig.legend(['Port+AIS', f'{ma_window}d MA'], loc='upper center', bbox_to_anchor=(0.5, 0.02), ncol=2)
    
    # Adjust layout to prevent label cutoff
    plt.tight_layout()
    
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def produce_forecast_vs_regas_charts(start_date):

    # Kpler 14d cargo forecast vs actual 7d sendout 
        # eg: for given date in the past, show number of cargoes forecast to arrive in the following 14 days vs the avg sendout in the following 7 days
    # Actual 14d cargo forecasts vs actual 7d sendout
        # eg as above but use actual number of cargoes that did arrive in the following 14 days
    
    
    ##### Get latest EU gas balance (to get historic and forecast regas)
    # Get balance from the db
    # TODO: can switch to using the cache when available)
    res = util.get_eu_gas_balance(use_cache=False, start_date=start_date)
    df_daily = res['balance_daily']
    # Filter to just regas
    df_balance_regas = df_daily[[('Supply','Regas')]]
    
    # Create 7d rolling forwad looking average of sendout
    indexer = pd.api.indexers.FixedForwardWindowIndexer(window_size=7)
    df_balance_regas[('Supply','Regas 7d')] = df_balance_regas[('Supply','Regas')].rolling(window=indexer, min_periods=1).mean()
    df_balance_regas.columns = ['regas' ,'regas_7d']
    # Truncate (to day head to ensure we skip current day which could contain partial & therefore low noms)
    df_balance_regas = df_balance_regas[df_balance_regas.index<=datetime.today()+timedelta(days=1)]
    
    
    ##### Get LNG storage levels
    df_lng_storage = get_lng_stocks(start_date)
    
    
    ##### Get forecast of rolling 14d forecast arrivals (port_ais AND kpler)
    dq = DataQuery(logintype='prod')
    data = dq.get_data(by='metadata', 
                       start_date=start_date,
                       querytype='bulk',
                       metadata={'source1': 'JainGlobal',
                                 'geography1': 'NWE',
                                 'category1': 'Supply',
                                 'category2': 'Cargoes',
                                 'category3': '14d',
                                 'category4': 'port_ais,kpler', # NB: we query both groups
                                 })
    #Construct df
    dfs = []
    for k, df in data.items():
        confidence = df.name.split('.')[5]
        dfs.append(df.set_index('date')[['value']].rename(columns={'value':confidence}))
    df_arrivals_14d = pd.concat(dfs, axis=1)
    # Add total column for port_ais + kpler forecasts
    df_arrivals_14d['total'] = df_arrivals_14d.sum(axis=1)
    
    # Select first item in results (there should only be 1!). Origina logic when cat4 was just port_ais
    # df_arrivals_14d = next(iter(data.items()))[1].set_index('date')[['value']].rename(columns={'value': 'forecast_14d'})
    
    
    ##### Combine and produce plots
    df_combined_port_ais = pd.concat([df_balance_regas, 
                                      df_arrivals_14d[['port_ais']].rename(columns={'port_ais':'forecast_14d'}),
                                      df_lng_storage], axis=1).ffill()
    # Note: we need to forward fill the 14d forecast & fill % (as we want the 7d regas forecast from tomorrow onwards - ie so it contains just out forecast and not erronesouly low WD noms)
    
    

    
    
    
    #### Temporary code #1: to produce table of difference largest month ahead step up in regas flows (21 days ahead of the front month)
    #### .... useful to quantify just how much a realistic a month on month increase we will see (and also show what the 14d forecast line up was at that point - ie how good a lead indicator is it)
    
    # df = df_combined_port_ais.copy()
    
    # # Ensure DateTimeIndex and sorted
    # df.index = pd.to_datetime(df.index)
    # df.sort_index(inplace=True)
    
    # # --- 1) Days to the start of next month (vectorized) ---
    # next_month_start = (df.index + pd.offsets.MonthBegin(1)).normalize()
    # df['days_to_month_ahead'] = pd.Series(next_month_start - df.index, index=df.index).dt.days
    
    # # --- 2) Average regas for the next calendar month (per row) ---
    # next_month_period = (df.index + pd.offsets.MonthBegin(1)).to_period('M')
    # df['month_ahead_avg'] = df.groupby(next_month_period)['regas'].transform('mean')
    
    # # Result
    # print(df[['regas', 'month_ahead_avg', 'days_to_month_ahead']].head())
    

    # # Filter to rows exactly 21 days before next month
    # mask = (df['days_to_month_ahead'] == 21) & df['regas'].notna() & df['month_ahead_avg'].notna()
    # subset = df.loc[mask].copy()
    
    # # Compute the increase
    # subset['increase'] = subset['month_ahead_avg'] - subset['regas']
    
    # if subset.empty:
    #     print("No rows where days_to_month_ahead == 21.")
    # else:
    #     # Find the date with the greatest increase
    #     best_date = subset['increase'].idxmax()
    #     best_row = subset.loc[best_date, ['regas', 'month_ahead_avg', 'increase', 'forecast_14d']]
        
    #     # print("Greatest increase (where days_to_month_ahead == 21):")
    #     # print(f"Date: {best_date}")
    #     # print(best_row)
    
    #     subset_rounded = subset.round(0)
    
    #     # Optional: show top 10
    #     print("\nTop 10 increases:")
    #     print(subset_rounded.sort_values('increase', ascending=False)
    #                 .head(10)[['regas', 'month_ahead_avg', 'increase', 'forecast_14d']])
        
    #     subset_rounded.sort_values('increase', ascending=False).head(10)[['regas', 'month_ahead_avg', 'increase', 'forecast_14d']].to_clipboard()

            
        
        
        
    
    
    #### Temporary code #2: produce a scatter plot of whenever we've had regas above 370mcm (to get a feel of what is a realistic amount of cargoes in the lineup)
    
    # regas_filter = 370
    # df = df_combined_port_ais[df_combined_port_ais['regas']>=regas_filter][['regas', 'forecast_14d']]

    
    # df.index.name = 'date'
    # df = df.reset_index()
    
        
    # import matplotlib.pyplot as plt
    # import pandas as pd
    # import numpy as np
    # from matplotlib.colors import ListedColormap
    
    # # Ensure 'date' is in datetime format and extract year
    # df['date'] = pd.to_datetime(df['date'])
    # df['year'] = df['date'].dt.year  # extract year
    
    # # Create a discrete color palette (one color per unique year)
    # years = sorted(df['year'].unique())
    # colors = plt.cm.tab10(np.linspace(0, 1, len(years)))  # tab10 gives up to 10 distinct colors
    # cmap = ListedColormap(colors)
    
    # plt.figure(figsize=(8, 6))
    
    # # Plot each year as a separate scatter series with its own color
    # for i, year in enumerate(years):
    #     subset = df[df['year'] == year]
    #     plt.scatter(
    #         subset['forecast_14d'],
    #         subset['regas'],
    #         color=cmap(i),
    #         s=80,
    #         edgecolors='black',
    #         label=str(year)
    #     )
    
    # # Labels and title
    # plt.xlabel('Cargoes Forecast in next 14d')
    # plt.ylabel('Regas mcm/d')
    # plt.title(f"Cargoes vs Regas >= {regas_filter}")
    
    # # Add grid and legend
    # plt.grid(True)
    # plt.legend(title='Year')
    # plt.tight_layout()
    
    # # Display plot
    # plt.show()






    
    
    
    plot_port_ais_str = create_scatter_plots(df_combined_port_ais, 'Port+AIS')    
    
    df_combined_all = pd.concat([df_balance_regas, 
                                df_arrivals_14d[['total']].rename(columns={'total':'forecast_14d'}),
                                df_lng_storage], axis=1).ffill()
    plot_all_str = create_scatter_plots(df_combined_all, 'Port+AIS+Kpler')    
    
    return plot_port_ais_str



def create_scatter_plots(df, title_suffix, show_latest_values=True):
    """
    Create three scatter plots showing forecast_14d vs regas_7d, grouped by fill percentage.
    Points are colored by month using shades of blue.
    
    Parameters:
    df : pandas DataFrame
        DataFrame with datetime index and columns forecast_14d, regas_7d, and fill_pc
    show_latest_values : bool, optional
        If True, adds lines showing the latest forecast_14d and regas_7d values on the relevant plot (default: False)
    """
    # Set the style to a built-in style
    plt.style.use('default')
    
    # Extract month from the datetime index
    if not isinstance(df.index, pd.DatetimeIndex):
        # Try to convert the index to datetime if it's not already
        try:
            df.index = pd.to_datetime(df.index)
        except:
            raise ValueError("DataFrame index must be convertible to datetime for month-based coloring")
    
    # Extract months (1-12) from index
    months = df.index.month
    
    # Create a blue colormap for months
    # Start with light blue and progress to dark blue
    blues = ['#EBF5FB', '#D4E6F1', '#A9CCE3', '#7FB3D5', '#5499C7', 
            '#2980B9', '#2471A3', '#1F618D', '#1A5276', '#154360', '#0F3C5A', '#0A2942']
    month_cmap = LinearSegmentedColormap.from_list('blue_months', blues, N=12)
    
    # Create a figure with three subplots and space for colorbar
    fig = plt.figure(figsize=(20, 6))
    # Create a gridspec with room for colorbar on the right
    gs = fig.add_gridspec(1, 4, width_ratios=[1, 1, 1, 0.1])
    
    # Create the three axes for plots
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[0, 2])
    cax = fig.add_subplot(gs[0, 3])  # This is for the colorbar
    
    latest_fill_pc = df['fill_pc'].iloc[-1]
    
    fig.suptitle(f'Kpler 14d Cargoes ({title_suffix}) vs 7d Avg Regas, bucketed by Stock (colored by Month) | Stock today {latest_fill_pc:.0%}', fontsize=14)
    
    # Create masks for each fill percentage group
    low_fill = df[df['fill_pc'] < 0.55]
    med_fill = df[(df['fill_pc'] >= 0.55) & (df['fill_pc'] <= 0.7)]
    high_fill = df[df['fill_pc'] > 0.7]
    
    # Get the latest values if needed
    if show_latest_values:
        latest_row = df.iloc[-1]
        latest_forecast = latest_row['forecast_14d']
        latest_regas = latest_row['regas_7d']
        latest_fill = latest_row['fill_pc']
        latest_month = df.index[-1].month
    
    # Normalize the month values for the colormap (1-12 to 0-1)
    norm = Normalize(vmin=1, vmax=12)
    
    # Plot scatter with colors by month
    def scatter_by_month(ax, data, title):
        if len(data) > 0:
            # Get months for this subset
            data_months = data.index.month
            
            # Create a scatter plot with coloring by month
            scatter = ax.scatter(
                data['forecast_14d'], 
                data['regas_7d'],
                c=data_months, 
                cmap=month_cmap,
                norm=norm,
                alpha=0.7,
                s=50
            )
        
        ax.set_title(title)
        ax.set_xlabel('Cargo Forecast in next 14d')
        ax.set_ylabel('Regas Forecast in next 7d (mcm/d)')
        ax.grid(True, alpha=0.3)
        return scatter if len(data) > 0 else None
    
    # Plot each group
    scatter1 = scatter_by_month(ax1, low_fill, 'Stock <55%')
    scatter2 = scatter_by_month(ax2, med_fill, 'Stock between 55-70%')
    scatter3 = scatter_by_month(ax3, high_fill, 'Stock >70%')
    
    # Add reference lines for latest values if requested
    if show_latest_values:
        # Determine which plot should show the lines based on the fill percentage
        target_ax = None
        if latest_fill < 0.55:
            target_ax = ax1
        elif 0.55 <= latest_fill <= 0.7:
            target_ax = ax2
        elif latest_fill > 0.7:
            target_ax = ax3
            
        if target_ax is not None:
            # Add vertical line for forecast_14d
            target_ax.axvline(x=latest_forecast, color='red', linestyle='--', 
                             label=f'Latest 14d cargoes: {latest_forecast:.0f}')
            
            # Add horizontal line for regas_7d
            target_ax.axhline(y=latest_regas, color='red', linestyle=':', 
                             label=f'Latest 7d regas: {latest_regas:.0f}')
            
            # Highlight the intersection point - use the month color for consistency
            month_color = month_cmap(norm(latest_month))
            target_ax.plot(latest_forecast, latest_regas, 'o', color=month_color,
                          markersize=12, markeredgecolor='red', markeredgewidth=2,
                          label='Latest')
                          
        print(f"\nLatest values:")
        print(f"forecast_14d: {latest_forecast:.2f}")
        print(f"regas_7d: {latest_regas:.2f}")
        print(f"Fill %: {latest_fill:.2%}")
        print(f"Month: {latest_month}")
    
    # Add a colorbar for months
    # Find a non-empty scatter to use for the colorbar
    for scatter in [scatter1, scatter2, scatter3]:
        if scatter is not None:
            cbar = plt.colorbar(scatter, cax=cax)
            cbar.set_ticks(np.arange(1, 13))
            cbar.set_ticklabels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                               'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
            cbar.set_label('Month')
            break
    
    # Add legends
    ax1.legend()
    ax2.legend()
    ax3.legend()
    
    # Adjust layout to prevent overlap
    plt.tight_layout()
    
    # Print some statistics about the data
    print(f"Number of points in each category:")
    print(f"Fill % < 0.55: {len(low_fill)}")
    print(f"0.55 ≤ Fill % ≤ 0.7: {len(med_fill)}")
    print(f"Fill % > 0.7: {len(high_fill)}")
    
    # Show the plot
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)


    return plot_base64



def plot_seasonal_lng_regas(start_year):
    
    # query regas data direct from CE
    df = get_lng_regas(datetime(start_year,1,1))
    
    # Create figure and axis
    fig, ax = plt.subplots(figsize=(12, 5))
    
    # Get the current year and previous year
    current_year = df.index.max().year
    previous_year = current_year - 1
    
    # Get list of previus years (so we can label the historic range)
    hist_range = [yr for yr in set(df.index.year) if yr not in [current_year,previous_year]]
    
    # Create a copy of the dataframe to avoid modifying the original
    df_copy = df.copy()
    
    # Extract day of year for indexing
    df_copy['doy'] = df_copy.index.dayofyear
    
    # Data for current year
    current_year_data = df_copy[df_copy.index.year == current_year]
    
    # Data for previous year
    previous_year_data = df_copy[df_copy.index.year == previous_year]
    
    # Historical data (all years except current and previous)
    historical_years = df_copy[df_copy.index.year < previous_year]
    
    # Create a standard date range for the x-axis (Jan 1 to Dec 31)
    days_in_year = pd.date_range(start=f'{current_year}-01-01', 
                               end=f'{current_year}-12-31', freq='D')
    
    # Process historical data to get min/max ranges
    if not historical_years.empty:
        # Initialize arrays to store min and max values for each day of year
        days_count = 366  # Account for leap years
        min_by_doy = np.full(days_count, np.nan)
        max_by_doy = np.full(days_count, np.nan)
        
        # Group by day of year and compute min and max of 7-day moving averages
        # First calculate 7-day MA for each historical year
        historical_years_ma = historical_years.copy()
        for year, year_data in historical_years.groupby(historical_years.index.year):
            # Sort by day of year
            year_data = year_data.sort_values('doy')
            # Calculate 7-day moving average
            year_data['regas_ma'] = year_data['Total'].rolling(window=7, min_periods=1).mean()
            # Update the values in our dataframe
            historical_years_ma.loc[year_data.index, 'regas_ma'] = year_data['regas_ma'].values
        
        # Now use the MA values to compute the historical range
        for doy, group in historical_years_ma.groupby('doy'):
            if 1 <= doy <= days_count:  # Ensure we stay within array bounds
                min_by_doy[doy-1] = group['regas_ma'].min()
                max_by_doy[doy-1] = group['regas_ma'].max()
        
        # Interpolate any missing values
        min_series = pd.Series(min_by_doy).interpolate(method='linear')
        max_series = pd.Series(max_by_doy).interpolate(method='linear')
        
        # Plot the historical range
        ax.fill_between(days_in_year[:len(min_series)], 
                       min_series.values[:len(days_in_year)], 
                       max_series.values[:len(days_in_year)],
                       color='gray', alpha=0.3, label=f'Hist Range {hist_range[0]}-{hist_range[-1]} (7d MA)')
    
    # Process and plot previous year data
    if not previous_year_data.empty:
        # Create a day-of-year to fill_pc mapping for previous year
        previous_year_map = pd.Series(
            index=previous_year_data['doy'],
            data=previous_year_data['Total'].values
        )
        
        # Reindex to standard days (use full year for previous year)
        standard_days = np.arange(1, 367)
        previous_year_series = previous_year_map.reindex(standard_days).interpolate(method='linear')
        
        # Calculate 7-day moving average
        previous_year_ma = previous_year_series.rolling(window=7, min_periods=1).mean()
        
        # Plot with current year dates for proper alignment
        valid_length = min(len(previous_year_series), len(days_in_year))
        ax.plot(days_in_year[:valid_length], 
               previous_year_series.values[:valid_length],
               color='#5499C7', linestyle='--', linewidth=1, alpha=0.5,
               label=f'{previous_year} (Daily)')
               
        # Plot the 7-day moving average
        ax.plot(days_in_year[:valid_length], 
               previous_year_ma.values[:valid_length],
               color='#5499C7', linewidth=2, 
               label=f'{previous_year} (7d MA)')
    
    # Process and plot current year data
    if not current_year_data.empty:
        # Create a day-of-year to fill_pc mapping for current year
        current_year_map = pd.Series(
            index=current_year_data['doy'],
            data=current_year_data['Total'].values
        )
        
        # Only use the actual days we have data for (don't extrapolate future dates)
        max_doy = current_year_data['doy'].max()
        standard_days = np.arange(1, max_doy + 1)
        
        # Create series and interpolate missing days within our actual date range
        current_year_series = current_year_map.reindex(standard_days).interpolate(method='linear')
        
        # Calculate 7-day moving average
        current_year_ma = current_year_series.rolling(window=7, min_periods=1).mean()
        
        # Plot with current year dates for proper alignment
        valid_length = min(len(current_year_series), len(days_in_year))
        ax.plot(days_in_year[:valid_length], 
               current_year_series.values[:valid_length],
               color='#1A5276', linewidth=1, alpha=0.5,
               label=f'{current_year} (Daily)')
               
        # Plot the 7-day moving average
        ax.plot(days_in_year[:valid_length], 
               current_year_ma.values[:valid_length],
               color='#1A5276', linewidth=2, 
               label=f'{current_year} (7d MA)')
    
    # Set labels and title
    ax.set_ylabel('mcm/d', fontsize=12)
    ax.set_title(f"LNG Regas mcm/d (7d MA) | Regas today {df_copy.iloc[-1]['Total']:.0f}mcm**", fontsize=14)
    
    # Set x-axis to show months
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    
    # Add minor grid for weeks
    ax.xaxis.set_minor_locator(mdates.WeekdayLocator(byweekday=0))  # Minor ticks on Mondays
    ax.grid(True, linestyle='-', alpha=0.2)
    ax.grid(True, which='minor', linestyle=':', alpha=0.2)
    
    # Add legend with better positioning
    #ax.legend(loc='lower left', bbox_to_anchor=(0.0, 1.01), ncol=4, borderaxespad=0, frameon=False)
    ax.legend(loc='upper right', ncol=2, framealpha=0.7, fontsize=10)
    
    # Set y-axis limits with some padding
    min_val = df['Total'].min() * 0.95
    max_val = df['Total'].max() * 1.05
    ax.set_ylim(min_val, max_val)
    
    # Tight layout
    plt.tight_layout()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)
    
    return plot_base64  




def plot_seasonal_storage_fill(start_year):
    
    # query stock data direct from CE (but with extended data range)
    df = get_lng_stocks(datetime(start_year,1,1), fill_pc_only=False)
    
    # Create figure and axis
    fig, ax = plt.subplots(figsize=(12, 5))
    
    # Get the current year and previous year
    current_year = df.index.max().year
    previous_year = current_year - 1
    
    # Get list of previus years (so we can label the historic range)
    hist_range = [yr for yr in set(df.index.year) if yr not in [current_year,previous_year]]
    
    # Create a copy of the dataframe to avoid modifying the original
    df_copy = df.copy()
    
    # Extract day of year for indexing
    df_copy['doy'] = df_copy.index.dayofyear
    
    # Data for current year
    current_year_data = df_copy[df_copy.index.year == current_year]
    
    # Data for previous year
    previous_year_data = df_copy[df_copy.index.year == previous_year]
    
    # Historical data (all years except current and previous)
    historical_years = df_copy[df_copy.index.year < previous_year]
    
    # Create a standard date range for the x-axis (Jan 1 to Dec 31)
    days_in_year = pd.date_range(start=f'{current_year}-01-01', 
                               end=f'{current_year}-12-31', freq='D')
    
    # Process historical data to get min/max ranges
    if not historical_years.empty:
        # Initialize arrays to store min and max values for each day of year
        days_count = 366  # Account for leap years
        min_by_doy = np.full(days_count, np.nan)
        max_by_doy = np.full(days_count, np.nan)
        
        # Group by day of year and compute min and max of 7-day moving averages
        # First calculate 7-day MA for each historical year
        historical_years_ma = historical_years.copy()
        for year, year_data in historical_years.groupby(historical_years.index.year):
            # Sort by day of year
            year_data = year_data.sort_values('doy')
            # Calculate 7-day moving average
            year_data['fill_pc_ma'] = year_data['fill_pc'].rolling(window=7, min_periods=1).mean()
            # Update the values in our dataframe
            historical_years_ma.loc[year_data.index, 'fill_pc_ma'] = year_data['fill_pc_ma'].values
        
        # Now use the MA values to compute the historical range
        for doy, group in historical_years_ma.groupby('doy'):
            if 1 <= doy <= days_count:  # Ensure we stay within array bounds
                min_by_doy[doy-1] = group['fill_pc_ma'].min()
                max_by_doy[doy-1] = group['fill_pc_ma'].max()
        
        # Interpolate any missing values
        min_series = pd.Series(min_by_doy).interpolate(method='linear')
        max_series = pd.Series(max_by_doy).interpolate(method='linear')
        
        # Plot the historical range
        ax.fill_between(days_in_year[:len(min_series)], 
                       min_series.values[:len(days_in_year)], 
                       max_series.values[:len(days_in_year)],
                       color='gray', alpha=0.3, label=f'Hist Range {hist_range[0]}-{hist_range[-1]} (7d MA)')
    
    # Process and plot previous year data
    if not previous_year_data.empty:
        # Create a day-of-year to fill_pc mapping for previous year
        previous_year_map = pd.Series(
            index=previous_year_data['doy'],
            data=previous_year_data['fill_pc'].values
        )
        
        # Reindex to standard days (use full year for previous year)
        standard_days = np.arange(1, 367)
        previous_year_series = previous_year_map.reindex(standard_days).interpolate(method='linear')
        
        # Calculate 7-day moving average
        previous_year_ma = previous_year_series.rolling(window=7, min_periods=1).mean()
        
        # Plot with current year dates for proper alignment
        valid_length = min(len(previous_year_series), len(days_in_year))
        ax.plot(days_in_year[:valid_length], 
               previous_year_series.values[:valid_length],
               color='#5499C7', linestyle='--', linewidth=1, alpha=0.5,
               label=f'{previous_year} (Daily)')
               
        # Plot the 7-day moving average
        ax.plot(days_in_year[:valid_length], 
               previous_year_ma.values[:valid_length],
               color='#5499C7', linewidth=2, 
               label=f'{previous_year} (7d MA)')
    
    # Process and plot current year data
    if not current_year_data.empty:
        # Create a day-of-year to fill_pc mapping for current year
        current_year_map = pd.Series(
            index=current_year_data['doy'],
            data=current_year_data['fill_pc'].values
        )
        
        # Only use the actual days we have data for (don't extrapolate future dates)
        max_doy = current_year_data['doy'].max()
        standard_days = np.arange(1, max_doy + 1)
        
        # Create series and interpolate missing days within our actual date range
        current_year_series = current_year_map.reindex(standard_days).interpolate(method='linear')
        
        # Calculate 7-day moving average
        current_year_ma = current_year_series.rolling(window=7, min_periods=1).mean()
        
        # Plot with current year dates for proper alignment
        valid_length = min(len(current_year_series), len(days_in_year))
        ax.plot(days_in_year[:valid_length], 
               current_year_series.values[:valid_length],
               color='#1A5276', linewidth=1, alpha=0.5,
               label=f'{current_year} (Daily)')
               
        # Plot the 7-day moving average
        ax.plot(days_in_year[:valid_length], 
               current_year_ma.values[:valid_length],
               color='#1A5276', linewidth=2, 
               label=f'{current_year} (7d MA)')
    
    # Set labels and title
    ax.set_ylabel('Fill %', fontsize=12)
    ax.set_title(f"LNG Stock Fill % (7d MA) | Stock today {df_copy.iloc[-1]['Stock']/1000:.1f}bcm, capa {df_copy.iloc[-1]['Capacity']/1000:.1f}bcm, fill {df_copy.iloc[-1]['fill_pc']:.0%}", fontsize=14)
    
    # Set x-axis to show months
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    
    # Add minor grid for weeks
    ax.xaxis.set_minor_locator(mdates.WeekdayLocator(byweekday=0))  # Minor ticks on Mondays
    ax.grid(True, linestyle='-', alpha=0.2)
    ax.grid(True, which='minor', linestyle=':', alpha=0.2)
    
    # Add legend with better positioning
    #ax.legend(loc='lower left', bbox_to_anchor=(0.0, 1.01), ncol=4, borderaxespad=0, frameon=False)
    ax.legend(loc='upper right', ncol=2, framealpha=0.7, fontsize=10)
    
    # Set y-axis limits with some padding
    min_val = df['fill_pc'].min() * 0.95
    max_val = df['fill_pc'].max() * 1.05
    ax.set_ylim(min_val, max_val)
    
    # Tight layout
    plt.tight_layout()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)
    
    return plot_base64  
    
    


def get_dates():
    
    # TODO: 
        # do we want to run this in the afternoon as well? Once per day in the morning seems fine for now...
        # Kpler loader will run every hour (at 5 past?) 
        # .... or do we want to run every 30 mins? (probably too much, esp if we just run this report once per day)
        # need to consider DST as Kpler timestamps in the db are all UTC

    now = datetime.now()
    
    # Report likely run at 6:30am so we will querying the 6am snapshot 
    snapshot_am_hr = 6
    snapshot_am_min = 30
        
    # Skip weekend on a Mon to compare vs Fri
    days_offset = -3 if now.weekday()==0 else -1
    
    # Set dates we will be comparing
    curr_date = datetime(now.year, now.month, now.day, snapshot_am_hr, snapshot_am_min)
    prev_date = curr_date + timedelta(days_offset)
    
    return curr_date, prev_date


def get_report(zone, email_subject_template, volume_filter_m3=10000, delivered_lookback=7):
    
    # Get countries based on the zone
    countries = zone_config[zone]
    
    # Create Kpler query object
    kq = KplerQuery(logintype='prod')

    # TODO: we need to consider the local time on the server when doing this. All kpler timestamps in the db are in UTC    
    curr_target, prev_target = get_dates()
    # curr_target, prev_target = datetime(2025,10,15,6,30), datetime(2025,10,14,6,30)
    
    
    logging.info(f'Retrieving snapshots with target dates of {curr_target} and {prev_target}')
    
    # Query snapshots from the db
    trades_curr, trades_dt_curr = kq.get_forecast(curr_target, 'trades')
    vessels_curr, vessels_dt_curr = kq.get_forecast(curr_target, 'vessels')
    
    trades_prev, trades_dt_prev = kq.get_forecast(prev_target, 'trades')
    vessels_prev, vessels_dt_prev = kq.get_forecast(prev_target, 'vessels')
    
    # TODO: add check to make sure snapshots are not stale

    # Create "clean set" of data
    # TODO: explode STS activity into multiple rows
    clean_curr = create_clean_data(trades_curr, volume_filter_m3, vessels_curr)
    clean_prev = create_clean_data(trades_prev, volume_filter_m3, vessels_prev)
    
    # Also create a clean history for use below
    clean_curr_inc_hist = create_clean_data(trades_curr, volume_filter_m3, vessels_curr, inc_history=True)
    
    # Filter to current zone
    # curr2zone = clean_curr[clean_curr['ToContinent']==zone]
    # prev2zone = clean_prev[clean_prev['ToContinent']==zone]
    # recentlydelivered_inzone = clean_curr_inc_hist[(clean_curr_inc_hist['ToContinent']==zone) & (clean_curr_inc_hist['DestinationDate']>=trades_dt_prev)]
    curr2zone = clean_curr[clean_curr['ToCountry'].isin(countries)]
    prev2zone = clean_prev[clean_prev['ToCountry'].isin(countries)]
    recentlydelivered_inzone = clean_curr_inc_hist[(clean_curr_inc_hist['ToCountry'].isin(countries)) & (clean_curr_inc_hist['DestinationDate']>=trades_dt_prev)]
    
    
    # TODO: remove any noise of cargoes that were delivered which are now not delivered (so assumed to be error)
    # vessels_flipped_back = [v for v in curr2zone[curr2zone['trade_status']!='Delivered']['vessel'].values if v in prev2zone[prev2zone['trade_status']=='Delivered']['vessel'].values]
    
    
    # TODO: sections:
        # new in zone (ie not in prev forecast)
        # moved to zone (ie in prev forecast but different zone)
        # out of zone 
        # updated within zone (do we care right now?)
        # delivered cargoes
    # TODO: stats
        # total headline on the water heading to zone inc DoD
        # unassigned (total, not related to zone)

    
    
    # Global stats
    curr_floating = clean_curr[clean_curr['FloatingStorage']==1]
    prev_floating = clean_prev[clean_prev['FloatingStorage']==1]
    
    
    # Into the zone: destined here now, but not in the previous zone set.
    # Loaded = absent from the previous forecast entirely.
    # Reallocated = already tracked, previously destined outside the zone.
    # (Comparing against the whole previous forecast dropped those reallocations.)
    prev_zone_vessels = set(prev2zone['Vessel'])
    prev_global_vessels = set(clean_prev['Vessel'])
    new_cargoes2zone = sorted(
        c for c in curr2zone['Vessel'].unique() if c not in prev_zone_vessels)
    new_cargoes2zone_loaded = [c for c in new_cargoes2zone if c not in prev_global_vessels]
    new_cargoes2zone_relocated = [c for c in new_cargoes2zone if c in prev_global_vessels]
    
    # Cargoes in prev set but are no longer present
    cargoes_leftzone = [c for c in prev2zone.Vessel.values if c not in curr2zone.Vessel.values]
    
    # If a cargo is not present in the zone it can either be discharged, relocated or be missing
    cargoes_discharged = [c for c in cargoes_leftzone if c in recentlydelivered_inzone.Vessel.values]
    cargoes_relocated = [c for c in cargoes_leftzone if c in clean_curr.Vessel.values]
    cargoes_missing = [c for c in cargoes_leftzone if c not in cargoes_relocated and c not in cargoes_discharged]
    
    # Get list of cargoes in both (so we can compare and list out any within zone updates)
    cargoes_common = [c for c in curr2zone.Vessel.values if c in prev2zone.Vessel.values]
    
    #### Generate summary

    # new arrivals (just loaded)
    newarrivals_loaded_n = len(new_cargoes2zone_loaded)
    newarrivals_loaded_ending = '' if newarrivals_loaded_n == 1 else 'es'
    volume_new_loaded = curr2zone.loc[curr2zone.Vessel.isin(new_cargoes2zone_loaded), 'Volume(mcm)'].sum()
    volume_new_loaded_s = f'{volume_new_loaded:,.0f}'   
    # new arrivals (relocated to zone)
    newarrivals_relocated_n = len(new_cargoes2zone_relocated)
    newarrivals_relocated_ending = '' if newarrivals_relocated_n == 1 else 'es'
    volume_new_relocated = curr2zone.loc[curr2zone.Vessel.isin(new_cargoes2zone_relocated), 'Volume(mcm)'].sum()
    volume_new_relocated_s = f'{volume_new_relocated:,.0f}'   
    
    # relocated out of zone
    relocated_n = len(cargoes_relocated)
    relocated_ending = '' if relocated_n == 1 else 'es'
    volume_relocated = clean_curr.loc[clean_curr.Vessel.isin(cargoes_relocated), 'Volume(mcm)'].sum()
    volume_relocated_s = f'{volume_relocated:,.0f}'  
    
    # missing
    missing_n = len(cargoes_missing)
    missing_ending = '' if missing_n ==1 else 'es'
    volume_missing = clean_prev.loc[clean_prev.Vessel.isin(cargoes_missing), 'Volume(mcm)'].sum()
    volume_missing_s = f'{volume_missing:,.0f}'
    
    # discharged
    discharged_n = len(cargoes_discharged)
    discharged_ending = '' if discharged_n ==1 else 'es'
    discharged_volume = recentlydelivered_inzone.loc[recentlydelivered_inzone.Vessel.isin(cargoes_discharged), 'Volume(mcm)'].sum()
    discharged_volume_s = f'{discharged_volume:,.0f}'
    
    # blank destination
    destination_blank = 1
    
    
    # Overall summary stats
    cargo_curr = len(curr2zone)
    # cargo_curr -= discharged_n
    cargo_curr_s = f'{cargo_curr:,.0f}'
    cargo_curr_ending = '' if cargo_curr ==1 else 'es'
    
    volume_curr = curr2zone['Volume(mcm)'].sum()
    # volume_curr -= discharged_volume    
    volume_curr_s = f'{volume_curr:,.0f}'
    
    cargo_prev = len(prev2zone)
    cargo_prev_s = f'{cargo_prev:,.0f}'
    cargo_prev_ending = '' if cargo_prev ==1 else 'es'
    volume_prev = prev2zone['Volume(mcm)'].sum()
    volume_prev_s = f'{volume_prev:,.0f}'
    
    # cargo_change = cargo_curr - len(prev2zone)
    # volume_change = volume_curr - prev2zone['Volume(mcm)'].sum()
    cargo_change = cargo_curr - cargo_prev #- discharged_n
    volume_change = volume_curr - volume_prev #- discharged_volume
    
    cargo_change_s = f'{cargo_change:+,.0f}'
    cargo_change_colour = 'green' if cargo_change >=0 else 'red'
    cargo_change_msg = f"<span style='color:{cargo_change_colour}'>{cargo_change_s}</span>"
    
    volume_change_s = f'{volume_change:+,.0f}'
    volume_change_colour = 'green' if volume_change >=0 else 'red'
    volume_change_msg = f"<span style='color:{volume_change_colour}'>{volume_change_s}</span>"
    
    
    # Define colours
    color_default = 'black'
    color_past_eta = '#ff8f2d'
    color_new_zone = '#B19A34'
    color_forward = '#00BC8C'
    color_back = 'red'
    color_diversion = 'white'
    color_diversion_in = 'white'
    
    color_highlight_default = 'white'
    color_highlight_floating = 'yellow'
    color_highlight_diversion = 'red'
    color_highlight_diversion_in = '#2ea043'
    
    # Create email body
    no_items = '<br>No change<br><br>'
    
    possible_diversions_2zone = {}
    
    messages_new = []
    messages_moved2zone = []
    for c in sorted(new_cargoes2zone):

        # Get current details of this cargo
        curr_cargo = curr2zone[curr2zone.Vessel==c].iloc[0]
        
        # Check if floating
        cargo_highlight = color_highlight_floating if curr_cargo['IMO'] in curr_floating['IMO'].values else color_highlight_default
        
        # Check if cargo was in previous forecast (ie has it just loaded)
        prev_cargo = clean_prev[clean_prev['Vessel']==c].iloc[0] if c in clean_prev['Vessel'].values else None
            
        
        # Define Kpler and BBG URLs
        url_bbg = bbg_map_url.format(curr_cargo['IMO'])
        url_kpler = kpler_map_url.format(curr_cargo['KplerVesselId'])
        
        svessel = f"<a href='{url_kpler}' target='_blank'>{curr_cargo['Vessel']}</a>"
        svolume = '{:.0f}'.format(curr_cargo['Volume(mcm)'])
        
        from_country = curr_cargo['FromCountry']
        sdate = curr_cargo['DepartureDate'].strftime('%d-%b-%y')
        
        
        if prev_cargo is None:
            
            to_country = curr_cargo['ToCountry']
            to_terminal = curr_cargo['ToTerminal']
            
            # TODO: could this be blank?
            seta = curr_cargo['DestinationDate'].strftime('%d-%b-%y')
            
            source = curr_cargo['Source']
            conf = curr_cargo['Confidence']
            
            # TODO: add STS logic (ie show STSVesselFrom and STSVesselTo)
            
            item = f"""<li><strong><span style='background-color: {cargo_highlight}'>{svessel}</span></strong> ({svolume}mcm) loaded in {from_country} on {sdate}:
                        ToCountry: {to_country}, ToTerminal: {to_terminal}, ETA: {seta}, Source/Confidence: {source}/{conf}
                        </li>
                    """
                    
            messages_new.append(item)
        
        else:
            
            msg = []
            
            curr_eta = curr_cargo['DestinationDate']
            prev_eta = prev_cargo['DestinationDate']
            
            # Potential diversion into zone: previously a hard AIS/Port
            # signal outside the zone. The source itself need not have
            # changed (AIS Bangladesh -> AIS Zeebrugge).
            possible_diversion = prev_cargo['Source'] in ['AIS', 'Port']
            if possible_diversion:
                possible_diversions_2zone[c] = {'current': curr_cargo, 'previous': prev_cargo}
                cargo_highlight = color_highlight_diversion_in

            
            # ToContinent
            if curr_cargo['ToContinent'] != prev_cargo['ToContinent']:
                msg.append(f"ToContinent was {prev_cargo['ToContinent']} now <strong><span style='color: {color_new_zone}'>{curr_cargo['ToContinent']}</span></strong>")
                
            # ToCountry
            if curr_cargo['ToCountry'] != prev_cargo['ToCountry']:
                if possible_diversion:
                    msg.append(f"<span style='background-color: {color_highlight_diversion_in};color: {color_diversion_in}'>ToCountry was {prev_cargo['ToCountry']} now {curr_cargo['ToCountry']}</span>")
                else:
                    msg.append(f"ToCountry was {prev_cargo['ToCountry']} now {curr_cargo['ToCountry']}")
                
            # ToTerminal
            if curr_cargo['ToTerminal'] != prev_cargo['ToTerminal']:
                msg.append(f"ToTerminal was {prev_cargo['ToTerminal']} now {curr_cargo['ToTerminal']}")
                
            # ETA
            if pd.isnull(prev_eta) or pd.isnull(curr_eta):
                seta = curr_cargo['DestinationDate'].strftime('%d-%b-%y')
                msg.append(f"ETA: {seta}")
            else:
                seconds = abs(curr_eta-prev_eta).total_seconds()
                dateformat = None
                if seconds>=86400:
                    dateformat = '%d-%b-%y'
                else:
                    if curr_eta.day != prev_eta.day:
                        dateformat = '%d-%b-%y %H:%M'
            
                if dateformat is not None:
                    if curr_eta > prev_eta: # date moved back
                        curr_eta_color = color_back
                    else:
                        curr_eta_color = color_forward
                    sceta = curr_eta
                    try:
                        sceta = sceta.strftime(dateformat)
                    except Exception:
                        pass
                    speta = prev_eta
                    try:
                        speta = speta.strftime(dateformat)
                    except Exception:
                        pass
                    msg.append(f"ETA was {speta} now <strong><span style='color: {curr_eta_color}'>{sceta}</span></strong>")
                    
                else:
                    sceta = curr_eta
                    try:
                        sceta = sceta = sceta.strftime(dateformat)
                    except Exception:
                        pass
                    msg.append(f"ETA: {sceta}")
            
            # Source
            if curr_cargo['Source'] != prev_cargo['Source']:

                if possible_diversion:
                    msg.append(f"<span style='background-color: {color_highlight_diversion_in};color: {color_diversion_in}'>Source was {prev_cargo['Source']} now {curr_cargo['Source']}</span>")
                else:
                    msg.append(f"Source was {prev_cargo['Source']} now {curr_cargo['Source']}")

            else:
                msg.append(f"Source: {curr_cargo['Source']}")
                
            # Confidence
            if curr_cargo['Confidence'] != prev_cargo['Confidence']:
                if np.isnan(prev_cargo['Confidence']):
                    color = color_forward
                else:
                    color = color_forward if curr_cargo['Confidence'] > prev_cargo['Confidence'] else color_back
                msg.append(f"Confidence was {prev_cargo['Confidence']} now <strong><span style='color: {color}'>{curr_cargo['Confidence']}</span></strong>")
            else:
                msg.append(f"Confidence: {curr_cargo['Confidence']}")
                
                
            # Create highlighted message if deemed a potential diversion
            # possible_diversion_msg = f". <span style='background-color: {color_highlight_diversion};color: {color_diversion}'>POTENTIAL DIVERSION</span>" if possible_diversion else ""
            
            msg_str = ', '.join(msg)                                
            item = f"""<li><strong><span style='background-color: {cargo_highlight}'>{svessel}</span></strong> ({svolume}mcm) loaded in {from_country} on {sdate}: {msg_str}
                        </li>
                    """
            messages_moved2zone.append(item)

    possible_diversions_outofzone = {}

    messages_movedoutofzone = []
    for c in sorted(cargoes_relocated):

        # Get current and previous details of this cargo 
        curr_cargo = clean_curr[clean_curr.Vessel==c].iloc[0]
        prev_cargo = clean_prev[clean_prev.Vessel==c].iloc[0]

        # Check if floating
        cargo_highlight = color_highlight_floating if curr_cargo['IMO'] in curr_floating['IMO'].values else color_highlight_default
        
        # Define Kpler and BBG URLs
        url_bbg = bbg_map_url.format(curr_cargo['IMO'])
        url_kpler = kpler_map_url.format(curr_cargo['KplerVesselId'])
        
        svessel = f"<a href='{url_kpler}' target='_blank'>{curr_cargo['Vessel']}</a>"
        svolume = '{:.0f}'.format(curr_cargo['Volume(mcm)'])
        
        from_country = curr_cargo['FromCountry']
        sdate = curr_cargo['DepartureDate'].strftime('%d-%b-%y')
        
        # Construct message
        msg = []
        
        curr_eta = curr_cargo['DestinationDate']
        prev_eta = prev_cargo['DestinationDate']
        
        
        # Potential diversion out of zone: previously a hard AIS/Port
        # signal inside the zone. Today's source does not have to change.
        possible_diversion = prev_cargo['Source'] in ['AIS', 'Port']
        if possible_diversion:
            possible_diversions_outofzone[c] = {'current': curr_cargo, 'previous': prev_cargo}
            cargo_highlight = color_highlight_diversion
        
        
        # ToContinent
        if curr_cargo['ToContinent'] != prev_cargo['ToContinent']:
            msg.append(f"ToContinent was {prev_cargo['ToContinent']} now <strong><span style='color: {color_new_zone}'>{curr_cargo['ToContinent']}</span></strong>")
        
        # ToCountry
        if curr_cargo['ToCountry'] != prev_cargo['ToCountry']:
            if possible_diversion:
                msg.append(f"<span style='background-color: {color_highlight_diversion};color: {color_diversion}'>ToCountry was {prev_cargo['ToCountry']} now {curr_cargo['ToCountry']}</span>")
            else:
                msg.append(f"ToCountry was {prev_cargo['ToCountry']} now {curr_cargo['ToCountry']}")
            
        # ToTerminal
        if curr_cargo['ToTerminal'] != prev_cargo['ToTerminal']:
            msg.append(f"ToTerminal was {prev_cargo['ToTerminal']} now {curr_cargo['ToTerminal']}")
            
        # ETA
        if pd.isnull(prev_eta) or pd.isnull(curr_eta):
            seta = curr_cargo['DestinationDate']
            try:
                seta = curr_cargo['DestinationDate'].strftime('%d-%b-%y')
            except Exception:
                pass
            msg.append(f"ETA: {seta}")
        else:
            seconds = abs(curr_eta-prev_eta).total_seconds()
            dateformat = None
            if seconds>=86400:
                dateformat = '%d-%b-%y'
            else:
                if curr_eta.day != prev_eta.day:
                    dateformat = '%d-%b-%y %H:%M'
        
            if dateformat is not None:
                if curr_eta > prev_eta: # date moved back
                    curr_eta_color = color_back
                else:
                    curr_eta_color = color_forward
                sceta = curr_eta
                try:
                    sceta = sceta.strftime(dateformat)
                except Exception:
                    pass
                speta = prev_eta
                try:
                    speta = speta.strftime(dateformat)
                except Exception:
                    pass
                msg.append(f"ETA was {speta} now <strong><span style='color: {curr_eta_color}'>{sceta}</span></strong>")
                
            else:
                sceta = curr_eta
                try:
                    sceta = sceta = sceta.strftime(dateformat)
                except Exception:
                    pass
                msg.append(f"ETA: {sceta}")
        
        # Source
        if curr_cargo['Source'] != prev_cargo['Source']:
            if possible_diversion:
                msg.append(f"<span style='background-color: {color_highlight_diversion};color: {color_diversion}'>Source was {prev_cargo['Source']} now {curr_cargo['Source']}</span>")
            else:
                msg.append(f"Source was {prev_cargo['Source']} now {curr_cargo['Source']}")
                
        else:
            msg.append(f"Source: {curr_cargo['Source']}")
            
        # Confidence
        if curr_cargo['Confidence'] != prev_cargo['Confidence']:
            if np.isnan(prev_cargo['Confidence']):
                color = color_forward
            else:
                color = color_forward if curr_cargo['Confidence'] > prev_cargo['Confidence'] else color_back
            msg.append(f"Confidence was {prev_cargo['Confidence']} now <strong><span style='color: {color}'>{curr_cargo['Confidence']}</span></strong>")
        else:
            msg.append(f"Confidence: {curr_cargo['Confidence']}")
            
        # Create highlighted message if deemed a potential diversion
        # possible_diversion_msg = f". <span style='background-color: {color_highlight_diversion};color: {color_diversion}'>POTENTIAL DIVERSION</span>" if possible_diversion else ""
        
        msg_str = ', '.join(msg)                                
        item = f"""<li><strong><span style='background-color: {cargo_highlight}'>{svessel}</span></strong> ({svolume}mcm) loaded in {from_country} on {sdate}: {msg_str}
                    </li>
                """
                
        messages_movedoutofzone.append(item)
        
        
    messages_discharged = []
    for c in sorted(cargoes_discharged):
        
        # Get details of this delivered cargo 
        curr_cargo = recentlydelivered_inzone[recentlydelivered_inzone.Vessel==c].iloc[0]
        
        # Check if it was tagged as floating
        cargo_highlight = color_highlight_floating if curr_cargo['IMO'] in prev_floating['IMO'].values else color_highlight_default
        
        # Define Kpler and BBG URLs
        url_bbg = bbg_map_url.format(curr_cargo['IMO'])
        url_kpler = kpler_map_url.format(curr_cargo['KplerVesselId'])
        
        svessel = f"<a href='{url_kpler}' target='_blank'>{curr_cargo['Vessel']}</a>"
        svolume = '{:.0f}'.format(curr_cargo['Volume(mcm)'])
        
        from_country = curr_cargo['FromCountry']
        sdate = curr_cargo['DepartureDate'].strftime('%d-%b-%y')
        
        to_country = curr_cargo['ToCountry']
        delivery_date = curr_cargo['DestinationDate'].strftime('%d-%b-%y %H:%M')
        
        item = f"""<li><strong><span style='background-color: {cargo_highlight}'>{svessel}</span></strong> ({svolume}mcm) loaded in {from_country} on {sdate}
                        discharged in {to_country} on {delivery_date}
                    </li>
                """
        
        messages_discharged.append(item)
        
        
    messages_update_within_zone = []
    updated_cargoes = []
    for c in sorted(cargoes_common):
        
        # Get current and previous details of this cargo 
        curr_cargo = clean_curr[clean_curr.Vessel==c].iloc[0]
        prev_cargo = clean_prev[clean_prev.Vessel==c].iloc[0]
        
        curr_eta = curr_cargo['DestinationDate']
        prev_eta = prev_cargo['DestinationDate']
        
        # Check if it was tagged as floating
        cargo_highlight = color_highlight_floating if curr_cargo['IMO'] in prev_floating['IMO'].values else color_highlight_default
        
        msg = []
        
        # ToTerminal
        if curr_cargo['ToTerminal'] != prev_cargo['ToTerminal']:
            msg.append(f"ToTerminal was {prev_cargo['ToTerminal']} now {curr_cargo['ToTerminal']}")
            
        # ToCountry
        if curr_cargo['ToCountry'] != prev_cargo['ToCountry']:
            msg.append(f"ToCountry was {prev_cargo['ToCountry']} now {curr_cargo['ToCountry']}")
        
        # ETA
        if curr_eta != prev_eta:            
            try:
                seconds = abs(curr_eta-prev_eta).total_seconds()
                
                dateformat = None
                if seconds>=86400:
                    dateformat = '%d-%b-%y'
                else:
                    if curr_eta.day != prev_eta.day:
                        dateformat = '%d-%b-%y %H:%M'
                        
                if dateformat is not None:
                    if curr_eta > prev_eta: # date moved back
                        curr_eta_color = color_back
                    else:
                        curr_eta_color = color_forward
                    sceta = curr_eta
                    try:
                        sceta = sceta.strftime(dateformat)
                    except Exception:
                        pass
                    speta = prev_eta
                    try:
                        speta = speta.strftime(dateformat)
                    except Exception:
                        pass
                    msg.append(f"ETA was {speta} now <strong><span style='color: {curr_eta_color}'>{sceta}</span></strong>")
                    
                else:
                    sceta = curr_eta
                    try:
                        sceta = sceta = sceta.strftime(dateformat)
                    except Exception:
                        pass
                    msg.append(f"ETA was {prev_eta} now {curr_eta}")
                
            except Exception:
                msg.append(f"ETA was {prev_eta} now {curr_eta}")
                
        
        # Source
        if curr_cargo['Source'] != prev_cargo['Source']:
            msg.append(f"Source was {prev_cargo['Source']} now {curr_cargo['Source']}")
        
        # Confidence
        if curr_cargo['Confidence'] != prev_cargo['Confidence']:
            if np.isnan(prev_cargo['Confidence']):
                color = color_forward
            else:
                color = color_forward if curr_cargo['Confidence'] > prev_cargo['Confidence'] else color_back
            msg.append(f"Confidence was {prev_cargo['Confidence']} now <strong><span style='color: {color}'>{curr_cargo['Confidence']}</span></strong>")
        
        # Construct msg and add to output if any changes detected
        if len(msg)>0:
            msg_str = ', '.join(msg)
            
            # Define Kpler and BBG URLs
            url_bbg = bbg_map_url.format(curr_cargo['IMO'])
            url_kpler = kpler_map_url.format(curr_cargo['KplerVesselId'])
            
            svessel = f"<a href='{url_kpler}' target='_blank'>{curr_cargo['Vessel']}</a>"
            svolume = '{:.0f}'.format(curr_cargo['Volume(mcm)'])
            
            from_country = curr_cargo['FromCountry']
            sdate = curr_cargo['DepartureDate'].strftime('%d-%b-%y')
            
            item = f"""<li><strong><span style='background-color: {cargo_highlight}'>{svessel}</span></strong> ({svolume}mcm) loaded in {from_country} on {sdate} destination {curr_cargo['ToCountry']}: {msg_str}
                        </li>
                    """
            messages_update_within_zone.append(item)
            # Also capture the name of the vessel so we can calculate stats below
            updated_cargoes.append(curr_cargo['Vessel'])
    
    
    # Calculcate summary stats for updated cargoes
    updated_n = len(messages_update_within_zone)
    updated_ending = '' if updated_n == 1 else 'es'
    updated_volume = curr2zone.loc[curr2zone.Vessel.isin(updated_cargoes), 'Volume(mcm)'].sum()
    updated_volume_s = f'{updated_volume:,.0f}'
    

    # TODO:
        # summary of unallocated terminals
        # switch to displaying as table (with notes column showing summary of changes)    
        # added days on water count if previously floating cargo is listed in the discharged section?

    
    # Weighted summary to our zone
    curr2zone['Weighted'] = curr2zone['Volume(mcm)'] * curr2zone['Confidence']
    df_volume = curr2zone.groupby(['Source'])[['Volume(mcm)','Weighted']].sum()
    df_volume.loc['Total'] = df_volume.sum(numeric_only=True)
    df_volume = df_volume.rename(columns={'Volume(mcm)':zone})
    # repeat with previous 
    prev2zone['Weighted'] = prev2zone['Volume(mcm)'] * prev2zone['Confidence']
    df_volume_prev = prev2zone.groupby(['Source'])[['Volume(mcm)','Weighted']].sum()
    df_volume_prev.loc['Total'] = df_volume_prev.sum(numeric_only=True)
    df_volume_prev = df_volume_prev.rename(columns={'Volume(mcm)':f'{zone}_prev',
                                                    'Weighted': 'Weighted_prev'})
    # join & calc DoD
    df_volume_comb = pd.concat([df_volume, df_volume_prev], axis=1)
    df_volume_comb = df_volume_comb.fillna(0)
    col_name = f'{zone}_diff'
    df_volume_comb[col_name] = df_volume_comb[zone] - df_volume_comb[f'{zone}_prev']
    df_volume_comb['Weighted_diff'] = df_volume_comb['Weighted'] - df_volume_comb['Weighted_prev']
    col_zone = f'{zone} ({chr(916)})'
    col_weighted = f'Weighted ({chr(916)})'
    df_volume_comb[col_zone] = df_volume_comb.apply(lambda x: f"{x[zone]:,.0f} ({x[col_name]:+,.0f})", axis=1)
    df_volume_comb[col_weighted] = df_volume_comb.apply(lambda x: f"{x['Weighted']:,.0f} ({x['Weighted_diff']:+,.0f})", axis=1)
    df_volume_comb = df_volume_comb[[col_zone,col_weighted]]
    
    
    
    # Summary of Europe tagged (but no country)
    eu_nc_col = 'Europe (no country)'
    df_europe_no_country = clean_curr[(clean_curr['ToContinent']=='Europe') & (clean_curr['ToCountry'].isnull())]
    df_europe_no_country['Weighted'] = df_europe_no_country['Volume(mcm)'] * df_europe_no_country['Confidence']
    df_europe_volume = df_europe_no_country.groupby(['Source'])[['Volume(mcm)','Weighted']].sum()
    df_europe_volume.loc['Total'] = df_europe_volume.sum(numeric_only=True)
    df_europe_volume = df_europe_volume.rename(columns={'Volume(mcm)':eu_nc_col})
    # repeat with previous 
    df_europe_no_country_prev = clean_prev[(clean_prev['ToContinent']=='Europe') & (clean_prev['ToCountry'].isnull())]
    df_europe_no_country_prev['Weighted'] = df_europe_no_country_prev['Volume(mcm)'] * df_europe_no_country_prev['Confidence']
    df_europe_volume_prev = df_europe_no_country_prev.groupby(['Source'])[['Volume(mcm)','Weighted']].sum()
    df_europe_volume_prev.loc['Total'] = df_europe_volume_prev.sum(numeric_only=True)
    df_europe_volume_prev = df_europe_volume_prev.rename(columns={'Volume(mcm)':f'{eu_nc_col}_prev',
                                                                  'Weighted': 'Weighted_prev',})
    
    # join & calc DoD
    df_europe_comb = pd.concat([df_europe_volume, df_europe_volume_prev], axis=1)
    df_europe_comb = df_europe_comb.fillna(0)
    col_name = f'{eu_nc_col}_diff'
    df_europe_comb[col_name] = df_europe_comb[eu_nc_col] - df_europe_comb[f'{eu_nc_col}_prev']
    df_europe_comb['Weighted_diff'] = df_europe_comb['Weighted'] - df_europe_comb['Weighted_prev']
    
    col_zone = f'{eu_nc_col} ({chr(916)})'
    col_weighted = f'Weighted ({chr(916)})'
    df_europe_comb[col_zone] = df_europe_comb.apply(lambda x: f"{x[eu_nc_col]:,.0f} ({x[col_name]:+,.0f})", axis=1)
    df_europe_comb[col_weighted] = df_europe_comb.apply(lambda x: f"{x['Weighted']:,.0f} ({x['Weighted_diff']:+,.0f})", axis=1)
    df_europe_comb = df_europe_comb[[col_zone,col_weighted]]

    
        
    # Construct final bulleted lists
    newitems = '<ul>' + ''.join(messages_new) + '</ul>' if len(messages_new)>0 else no_items
    moved_to_zoneitems = '<ul>' + ''.join(messages_moved2zone) + '</ul>' if len(messages_moved2zone)>0 else no_items
    moved_outof_zoneitems = '<ul>' + ''.join(messages_movedoutofzone) + '</ul>' if len(messages_movedoutofzone)>0 else no_items
    discharged_items = '<ul>' + ''.join(messages_discharged) + '</ul>' if len(messages_discharged)>0 else no_items
    updated_in_zone_items = '<ul>' + ''.join(messages_update_within_zone) + '</ul>' if len(messages_update_within_zone)>0 else no_items
    
    # Convert voume summary per source tables to html
    # volume_comb_html = df_volume_comb.to_html(float_format='{:,.0f}'.format, index_names=False)
    # europe_comb_html = df_europe_comb.to_html(float_format='{:,.0f}'.format, index_names=False)
    volume_comb_html = df2html(df_volume_comb, precision=0, font_size=report_font_size, font_family=report_font_family)
    europe_comb_html = df2html(df_europe_comb, precision=0, font_size=report_font_size, font_family=report_font_family)
    
    
    # Create LNG temrinal regas & maint tables
    df_terminal_regas, df_terminal_maint = get_lng_terminal_regas_maint()
    df_regas_html = df2html(df_terminal_regas, precision=0, font_size=report_font_size, font_family=report_font_family, highlight_weekends=True, index_dt_format='%d-%b-%Y', highlight_today=True)
    df_maint_html = df2html(df_terminal_maint, precision=0, font_size=report_font_size, font_family=report_font_family, highlight_weekends=True, index_dt_format='%d-%b-%Y', highlight_today=True)
        
    # Produce plots
    arrivals_plot = create_arrivals_chart()
    arrivals_plot_img = f"<img src='data:image/png;base64,{arrivals_plot}' alt='Embedded Image'>"
    
    scatter_start_date = datetime(2021,1,1)
    scatter_plot = produce_forecast_vs_regas_charts(scatter_start_date)
    scatter_plot_img = f"<img src='data:image/png;base64,{scatter_plot}' alt='Embedded Image'>"
    stocks_plot_fill_pc = plot_seasonal_storage_fill(2019)
    stocks_plot_fill_pc_img = f"<img src='data:image/png;base64,{stocks_plot_fill_pc}' alt='Embedded Image'>"
    
    regas_plot = plot_seasonal_lng_regas(2019)
    regas_plot_img = f"<img src='data:image/png;base64,{regas_plot}' alt='Embedded Image'>"
    
    
    on_the_water = plot_seasonal_lng_on_water(2019)
    on_the_water_img = f"<img src='data:image/png;base64,{on_the_water}' alt='LNG On The Water'>"
    
    # Construct the email title (add in diversion warnings if there are any)
    n_div_in = len(possible_diversions_2zone)
    n_div_out = len(possible_diversions_outofzone)

    def _diversion_phrase(n, direction):
        if n <= 0:
            return None
        word = 'diversion' if n == 1 else 'diversions'
        return f'{n} possible {word} {direction}'

    diversion_parts = [p for p in (
        _diversion_phrase(n_div_in, 'into zone'),
        _diversion_phrase(n_div_out, 'out of zone'),
    ) if p]
    email_subject_suffix = '' if not diversion_parts else ' (' + ', '.join(diversion_parts) + ')'
    
    email_subject = f"{email_subject_template}{email_subject_suffix}"
    
    # Assemble
    dashboard_header = dashboard_header_for("lng_vessels")
    body = f"""<html>                    
                {dashboard_header}
                <div style="font-family: {report_font_family}; font-size: {report_font_size}px">
                Forecast comparison: {trades_dt_curr.strftime('%d %b %H:%M')} vs {trades_dt_prev.strftime('%d %b %H:%M')}
                <br><br>
                <p><b>{zone} Summary ({volume_curr:,.0f}mcm)</b>
                <br>{cargo_curr_s} cargo{cargo_curr_ending} (<strong>{cargo_change_msg}</strong>), total volume {volume_curr_s}mcm (<strong>{volume_change_msg}</strong>)
                <br>
                <br>{cargo_curr_s} cargo{cargo_curr_ending} ({volume_curr_s}mcm) in current fcast
                <br>{cargo_prev_s} cargo{cargo_prev_ending} ({volume_prev_s}mcm) in previous fcast
                <br>
                <br>{discharged_n} cargo{discharged_ending} ({discharged_volume_s}mcm) discharged between forecasts
                <br>{newarrivals_loaded_n} new cargo{newarrivals_loaded_ending} ({volume_new_loaded_s}mcm)
                <br>{newarrivals_relocated_n} cargo{newarrivals_relocated_ending} ({volume_new_relocated_s}mcm) <b>reallocated</b> to {zone}
                <br>{relocated_n} cargo{relocated_ending} ({volume_relocated_s}mcm) <b>reallocated</b> out of {zone}
                <br>{updated_n} cargo{updated_ending} ({updated_volume_s}mcm) updated within {zone}
                <br>
                <br>
                <hr>
                <p><b>{zone} Forecast Volume (all days, Port+AIS only):</b>
                <br>
                {arrivals_plot_img}
                <br>
                <hr>
                <p><b>{zone} Forecast Cargoes (14 days, Port+AIS only) vs Regas:</b>
                <br>
                {scatter_plot_img}
                <br>
                <br>Note 1: these plots show current (& previously forecast) arrivals due within 14 days vs a forward looking rolling 7d avg of regas.
                <br>Note 2: forecasts since {scatter_start_date.strftime('%d %b-%y')} are considered.
                <br>Note 3: only cargoes tagged for our NWE perimeter countries with either AIS or Port confidence are included.
                <br>Note 4: the red lines & circle show the latest value for today.
                <br>
                <hr>
                <p><b>LNG On The Water:</b>
                <br>
                {on_the_water_img}
                <br>
                <br>** data is sourced from BBG tickers and is their "estimate of LNG volumes that were exported or re-exported at least n days ago and have not yet unloaded at their destination. Only ships with gas capacity above 70,000 cubic metres are included."
                <br>
                <hr>
                <p><b>{zone} LNG Stocks:</b>
                <br>
                {stocks_plot_fill_pc_img}
                <br>
                <hr>
                <p><b>{zone} LNG Regas:</b>
                <br>
                {regas_plot_img}
                <br>
                <br>** some nominations may be missing for current day.
                <br>
                <hr>
                <p><b>{zone} LNG Terminal Regas (mcm/d):</b>
                <br>
                {df_regas_html}
                <br>Note 1: terminal mcm/d technical capa in column headers.
                <br>
                <hr>
                <p><b>{zone} LNG Terminal Maintenance (mcm/d):</b>
                <br>
                {df_maint_html}
                <br>Note 1: all values are daily maintenance regas impact.
                <br>Note 2: terminal mcm/d technical capa in column headers.
                <br>
                <hr>
                <p><b>Cargo Volume summary per source (mcm):</b>
                <table><tr><td style='vertical-align:top'>{volume_comb_html}</td><td width='15px'></td><td style='vertical-align:top'>{europe_comb_html}</td></tr></table>
                <br>Note 1: "Europe (no country)" means cargoes that have a destination continent of Europe but no country specified.
                <br>Note 2: Weighted volume is raw volume * confidence value
                <hr>
                <br>
                <b>New/recently loaded ({volume_new_loaded_s}mcm):</b>
                {newitems}
                <b>New/reallocated to {zone} ({volume_new_relocated_s}mcm):</b>
                {moved_to_zoneitems}
                <b>Reallocated out of {zone} ({volume_relocated_s}mcm):</b>
                {moved_outof_zoneitems}
                <b>Updated within {zone} ({updated_volume_s}mcm):</b>
                {updated_in_zone_items}
                <b>Discharged ({discharged_volume_s}mcm):</b>
                {discharged_items}
                <br>
                <hr>
                <br>
                <b>Notes:</b>
                <br>This report compares the above snapshots and considers ALL cargoes on the water (irespective of delivery date)
                <br>{zone} zone definition = {', '.join(country_codes.keys())}
                <br>Confidence rating: Port 1, AIS 0.9, Market/Analyst 0.75, Model as per Kpler
                <br>Net cargo & volume change calcs considers the discharged cargoes (eg current - discharged - previous) 
                <br>Minimum cargo size filter = {volume_filter_m3}m3 LNG / {volume_filter_m3 * get_conversion_factor('cu m', 'mcm', unit_conversion_table):.0f}mcm
                <br>
                <br>
                <b>Key:</b>
                <br>ETA: <span style='color: {color_forward}'>moved forward</span>/<span style='color: {color_back}'>moved back</span>
                <br><span style='color: {color_new_zone}'>New zone</span>
                <br>Confidence: <span style='color: {color_forward}'>higher</span>/<span style='color: {color_back}'>lower</span>
                <br><span style='background-color: {color_highlight_floating}'>Tagged as floating storage</span>
                <br><span style='background-color: {color_highlight_diversion_in};color:{color_diversion_in}'>Tagged as potential diversion into zone</span>
                <br><span style='background-color: {color_highlight_diversion};color:{color_diversion}'>Tagged as potential diversion out of zone</span>
                </div>
                </html>
            """
            
    
    return body, email_subject



def assign_confidence(x):
    
    # # Assign confidence for non-model forecasts
    
    if x['Source']=='Port':
        return 1
    elif x['Source']=='AIS':
        return 0.9
    elif x['Source'] in ['Market','Analyst']:
        return 0.75
    elif x['Source']=='Model':
        return x['Confidence']
    else:
        np.nan


def assign_destination(x, df_vessels):
    
    # Selects relevant destination value (also considering vessel snapshot)

    if x['continent_destination']:
        return x['continent_destination']
    else:
        if x['forecasted_destination']:
            return x['forecasted_destination']
        elif x['zone_destination']:
            return x['zone_destination']
        else:
            # Attempt to use vessels snapshot (if available) to populate any empty destinations
            if df_vessels is not None:
                match = df_vessels[df_vessels['imo']==x['imo_vessel']].iloc[0]
                if len(match)>0:
                    return match['destination'] if match['destination'] else ''
                else:
                    print('no match, should not be possible?')
            else:
                return ''


def check_floating(x, df_vessels):

    if df_vessels is not None:
        match = df_vessels[df_vessels['imo']==x['imo_vessel']].iloc[0]
        if len(match)>0:
            return 1 if match['floating_storage'] else 0
    else:
        return ''
    
    

    
def create_clean_data(df_trades, volume_filter_m3, df_vessels=None, inc_history=False):
    
    
     # TODO: we only pass df_vessels if one is available (ie a snapshot was saved at the same time)
    
    # Filter out small cargoes (ie small/coastal vessels)
    df_clean = df_trades[df_trades['volume_origin_m3']>=volume_filter_m3]
    
    # Remove anything scheduled and delivered if reqd
    reqd_status = ['In Transit', 'Loading'] 
    if inc_history:
        reqd_status = reqd_status + ['Delivered']
    df_clean = df_clean[df_clean['trade_status'].isin(reqd_status)]
    
    # Populate ToContinent for any blanks (using other available fields)
    df_clean['ToContinent'] = df_clean.apply(lambda x: assign_destination(x, df_vessels), axis=1)
    
    # Add floating storage tag (only captured in vessels data)
    df_clean['FloatingStorage'] = df_clean.apply(lambda x: check_floating(x, df_vessels), axis=1)
    
    
    # Define what our "clean" columns, with friendly names
    clean_columns = {
        'query_id': 'query_id',
        'vessel': 'Vessel',  
        'imo_vessel': 'IMO',
        'id_vessel': 'KplerVesselId',
        'date_origin': 'DepartureDate',
        'date_destination': 'DestinationDate',
        'trade_status': 'Status',
        'installation_origin': 'FromTerminal',
        'country_origin': 'FromCountry',
        'continent_origin': 'FromContinent',
        'subcontinent_origin': 'FromSubContinent',
        'installation_destination': 'ToTerminal',
        'country_destination': 'ToCountry',
        'ToContinent': 'ToContinent',
        'subcontinent_destination': 'ToSubContinent',
        'eta_source_destination': 'Source',
        'forecasted_confidence': 'Confidence',
        'volume_origin_m3': 'Volume(m3)',
        # '', # STSFlag
        # '', # STSVesselFrom
        # '', # STSVesselTo
        # '', # Error
        # '', # Altered (1-15)
        'zone_canal_transit': 'Zone Canal Transit',
        'FloatingStorage': 'FloatingStorage',
        
        
        # other potential destination values
        
        # 'zone_destination': 'zone_destination',
        # 'forecasted_destination': 'forecasted_destination',
        # 'forecasted_eta': 'forecasted_eta',
        }

    # Select & rename the columns we want
    df_clean = df_clean[clean_columns.keys()].rename(columns=clean_columns)
    
    # Apply our confidence values
    df_clean['Confidence'] = df_clean.apply(lambda x: assign_confidence(x), axis=1)   
    
    # Calculate mcm
    df_clean['Volume(mcm)'] = df_clean['Volume(m3)'] * get_conversion_factor('cu m', 'mcm', unit_conversion_table)
    
    
    
    # TODO: 
        # Process STS trades (this will generate a delivered leg(s) as well as )
        # Check how to handle multiple (comma seperated) values in the trades "forecasted_destination" field

    
    return df_clean
    
    
    
    
    
    
    
    
    
    
    
    