import os
import logging
import traceback
import configparser
import platform

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email

from util import get_report


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/lng_vessels')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'report.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_lngvessels.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'
       
    
# Define our 'zone'
zone = 'NWE'    

email_subject_template = f'LNG {zone} Cargo Forecast DoD Delta'

try:
    logging.info(f'Generating report for {zone}')
    
    # Generate report content
    report, email_subject = get_report(zone, email_subject_template)
    
    # Send report
    send_email(receivers, email_subject, report)
    logging.info('Report sent')
    
except Exception:
    logging.error(f'Failed generating report for {zone}')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))
        
        