
"""
Email report showing latest US LNG netbacks and associated prices

"""


import logging
import sys
import traceback
import configparser
import platform

from datetime import datetime, timedelta

from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
from common.dashboard_header import dashboard_header_for

from jain_commods.core.util.dateutils import get_daybefore, public_holidays
from jain_commods.core.util.emailhelper import send_email

from util import (
    generate_netbacks,
    generate_report,
    generate_jkm_tfu_table,
    generate_jkm_tfu_occupancy_chart,
    generate_freight_chart,
    get_platts_data,
    generate_spot_freight_chart,
    generate_spot_prices_chart,
)


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/lng_netbacks')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'lng_netbacks.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')


# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_lng_netbacks.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

today = datetime.now()


# TODO: ideas to add to report:
    # Panama canal crossings? (laden & unladen)
    # Add plot of LT contract rates (and include current spot level)

   
try:
    
    logging.info('Generating report...')
    
    # Get public holidays 
    # TODO: needs to be smarter as JKM sometimes published on TTF holidays. For now just use UK holidays...
    holidays = public_holidays('UK',dates_only=True)
    
    # Note: report runs 6am Tues-Sat showing data for proceeding date 
    now = datetime.now()
    # now = pd.Timestamp(2026,4,11)
    
    # use_freight_forward=True
    hh_slope = 1.15
    
    # Generate netbacks for dates we're going to compare
    settle_date = get_daybefore(now, holidays).normalize()
    netbacks_spotf = {}
    netbacks_fwdf = {}
    for offset in [0, 1, 7, 14, 28]:
        dt = get_daybefore(now-timedelta(days=offset), holidays).normalize()
        print(dt)
        for use_freight_forward in [True, False]:
            df_netbacks, freight_asia, freight_atlantic, freight_fallback_info = generate_netbacks(dt, use_freight_forward, hh_slope)
            # Extra check in case some data missing
            if len(df_netbacks)>0:
                if use_freight_forward:
                    netbacks_fwdf[dt] = {'netbacks': df_netbacks,
                                         'freight_asia': freight_asia,
                                         'freight_atlantic': freight_atlantic,
                                         'freight_fallback_info': freight_fallback_info,
                                         }
                else:
                    netbacks_spotf[dt] = {'netbacks': df_netbacks,
                                        'freight_asia': freight_asia,
                                        'freight_atlantic': freight_atlantic,
                                        'freight_fallback_info': freight_fallback_info,
                                        }
    
    # Get Platts spot data (history LNG index prices and freight) ready for seperate charts
    df_spot = get_platts_data(now, freight_only=False)
    

    netbacks_img, prices_img, notes_html, freight_fallback_notes = generate_report(netbacks_fwdf, netbacks_spotf)
    netbacks_img_html = f"<img src='data:image/png;base64,{netbacks_img}' alt='Netbacks'>"
    prices_img_html = f"<img src='data:image/png;base64,{prices_img}' alt='HH, TFU & JKM Forward Curves'>"
    
    # Build fallback notes HTML if any
    fallback_notes_html = ""
    if freight_fallback_notes:
        fallback_items = "".join([f"<li>{note}</li>" for note in freight_fallback_notes])
        fallback_notes_html = f"""<p style="margin: 0 0 12px 0; font-size: 12px; color: #856404; background-color: #fff3cd; padding: 8px 12px; border-radius: 4px; border-left: 3px solid #ffc107;">
    <strong>Note:</strong> Some spot freight rates were unavailable for the settlement date:
    <ul style="margin: 4px 0 0 0; padding-left: 20px;">{fallback_items}</ul>
  </p>"""     
    

    # Generate freight charts
    freight_img = generate_freight_chart(netbacks_fwdf, True)
    freight_img_html = f"<img src='data:image/png;base64,{freight_img}' alt='Freight Rate History'>"
    
    freight_spot_img = generate_spot_freight_chart(df_spot)
    freight_spot_img_html = f"<img src='data:image/png;base64,{freight_spot_img}' alt='Spot Freight Rate History'>"


    # Generate price chart
    prices_spot_img = generate_spot_prices_chart(df_spot)
    prices_spot_img_html = f"<img src='data:image/png;base64,{prices_spot_img}' alt='Platts Spot LNG Prices'>"

    # Generate price table + occupancy heatmap
    jkm_tfu_html = generate_jkm_tfu_table(netbacks_fwdf, return_html=True)
    logging.info('Generating JKM/TFU occupancy heatmap...')
    jkm_tfu_occ_img = generate_jkm_tfu_occupancy_chart()
    jkm_tfu_occ_html = (
        f"<img src='data:image/png;base64,{jkm_tfu_occ_img}' "
        f"alt='JKM/TFU Strength vs Persistence' style='max-width:100%;'>"
    )
    
      
    # Construct html
    dashboard_header = dashboard_header_for("lng_netbacks")
    email_body = f"""
{dashboard_header}
<div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; font-size: 13px; line-height: 1.4; color: #333;">
  <p style="margin: 0 0 4px 0; font-size: 12px; color: #555;">This report shows Asian &amp; European netbacks for US LNG exports.</p>
  <p style="margin: 0 0 12px 0; font-size: 12px; color: #555;">Generated using settlement prices from {settle_date.strftime('%d %b %Y')}.</p>
  {fallback_notes_html}
  <h3 style="margin: 0 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">US LNG Netbacks</h3>
  {netbacks_img_html}
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">LNG Freight Rates</h3>
  {freight_img_html}
  <div style="margin-top: 8px;">{freight_spot_img_html}</div>
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">LNG Prices</h3>
  {prices_img_html}
  <h4 style="margin: 14px 0 6px 0; font-size: 12px; color: #555; font-weight: 500;">JKM/TFU Spread</h4>
  {jkm_tfu_html}
  <div style="margin-top: 12px;">{jkm_tfu_occ_html}</div>
  <p style="margin: 8px 0 0 0; font-size: 11px; color: #666; line-height: 1.5;">
    <em>Expired tenors (*)</em> stop trading mid-month of the prior month.
    Into that last trading window the contract behaves more like spot: the JKM/TFU spread can gap sharply versus its earlier forward history, so the outlined final settle may sit in an extreme bucket relative to the rest of the 90-day distribution.
  </p>
  <div style="margin-top: 16px;">{prices_spot_img_html}</div>
  <br>

  <h3 style="margin: 16px 0 8px 0; font-size: 14px; color: #2c3e50; border-bottom: 1px solid #ddd; padding-bottom: 4px;">Assumptions</h3>
  {notes_html}
</div>
"""
    
    send_email(receivers, 
               f"LNG Netbacks Summary: {today.strftime('%d %b %Y')}", 
               email_body,
               from_address='eu.gap.reports@jainglobal.com') 
    
    
    logging.info('Done')



except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, 'ERROR LNG Netbacks Report', str(tb))    

        