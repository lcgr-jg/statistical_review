import io
import base64
import calendar
import logging
import traceback

import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from datetime import datetime, timedelta
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle

from jain_commods.core.interfaces.snowflake import ICEFuturesQuery
from jain_commods.core.interfaces.snowflake import PlattsQuery


# ── Chart Style Configuration ──────────────────────────────────────────────────
CHART_STYLE = {
    'font.family': 'sans-serif',
    'font.sans-serif': ['Segoe UI', 'Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 9,
    'axes.titlesize': 10,
    'axes.titleweight': 500,
    'axes.labelsize': 8,
    'axes.linewidth': 0.6,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'xtick.labelsize': 7,
    'ytick.labelsize': 7,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.major.size': 3,
    'ytick.major.size': 3,
    'legend.fontsize': 7,
    'legend.framealpha': 0.95,
    'legend.edgecolor': '#cccccc',
    'legend.borderpad': 0.4,
    'legend.handlelength': 1.5,
    'figure.dpi': 150,
    'savefig.dpi': 150,
    'grid.linewidth': 0.4,
    'grid.alpha': 0.4,
    'lines.linewidth': 1.2,
    'lines.markersize': 3,
}

COLORS = {
    'us_nl': '#4A90A4',
    'us_sk': '#5B9A6F', 
    'us_panama': '#D4864A',
    'us_suez': '#9B7CB4',
    'jkm': '#E8A54B',
    'tfu': '#5A9BD4',
    'hh': '#C45B5B',
    'hh_liq': '#D98080',
    'freight_asia': '#8E6BAD',
    'freight_atlantic': '#4BA3A3',
    'positive': '#5A9BD4',
    'negative': '#A8C8E8',
    'positive_alt': '#E8A54B',
    'negative_alt': '#F5D5A0',
    'freight_stack': ['#7A8B8B', '#9FAFAF', '#5A6A6A'],
    'text_muted': '#666666',
    'grid': '#E0E0E0',
    'zero_line': '#333333',
}


def _apply_chart_style():
    """Apply professional chart styling via rcParams."""
    plt.rcParams.update(CHART_STYLE)


def _style_axis(ax, title=None, ylabel=None, show_right_spine=False):
    """Apply consistent axis styling."""
    if title:
        ax.set_title(title, pad=8, color='#333333')
    if ylabel:
        ax.set_ylabel(ylabel, color=COLORS['text_muted'])
    
    ax.tick_params(axis='both', colors='#555555')
    ax.spines['left'].set_color('#CCCCCC')
    ax.spines['bottom'].set_color('#CCCCCC')
    
    if show_right_spine:
        ax.spines['right'].set_visible(True)
        ax.spines['right'].set_color('#CCCCCC')
    
    ax.grid(axis='y', linestyle='-', color=COLORS['grid'], alpha=0.5, linewidth=0.4)
    ax.grid(axis='x', linestyle='-', color=COLORS['grid'], alpha=0.3, linewidth=0.3)
    ax.set_axisbelow(True)


###### Define relevant constants
# TODO: all netback calcs should be in corelib

mwh2mmbtu = 3.40951

vessel_sizes = {'platts': 165000,
                'standard': 150000,
                'qflex': 216200,
                'qmax': 266000,
                }

freight_constants = {'energy_content': 23, # m3 to mmbtu
                     'boiloffrate_laden': 0.0012,
                     'boiloffrate_ballast': 0.0009,
                     'fillable_volume': 0.985,
                     'days_in_port': 1.5,
                     'bunker_consumption_rate': 100,
                     'bunker_fuel_energy_content': 40.26,
                     'insurance_usd_per_day': 2600,
                     'bunker_price': 842, # TODO: find correct/live pricing eg "LQM1HOVL Index" = BBG ticker for Houston. Can get live from Platts?
                     }

# Assume 16 knots
voyages = {'us>panama>sk': 26,
           'us>suez>sk': 37,
           'us>sk':40,
           'us>nl': 13}

port_costs = {'nl':0.28,
              'sk': 0.12,
              }

# TODO: check this (assumptions - can be calculated dynamically on exact volume etc)
panama_canal_fee=0.34
suez_canal_fee = 0.45




def get_ice_settles(dt):
    # NB: Spark25S = Asia Pacific, Spark30S = Atlantic
    ice = ICEFuturesQuery()
    prices = []
    freight = []
    for product in ['TFU','TTF','JKM','HH','Spark25S','Spark30S']:
        # Query snowflake for ICE
        df = ice.get_curve(product,trade_date = dt)
        # Filter to months & tidy up
        df = df[df['STRIP_TYPE']=='Month']
        df = df[~df['STRIP'].str.contains('-')]
        df = df.set_index('DELIVERY_START')[['SETTLEMENT_PRICE']].rename(columns={'SETTLEMENT_PRICE':product})
        
        if product.startswith('Spark'):
            freight.append(df)
        else:
            prices.append(df)
        
    df_prices = pd.concat(prices, axis=1)
    df_freight = pd.concat(freight, axis=1)

    return df_prices, df_freight




def get_platts_data(dt, freight_only=True):

    pq = PlattsQuery(querytype='spot prices', warehouse='EU_COMMOD_RESEARCH_M_WH')    

    if freight_only:
        # Set date (only short lookback as we basically want freight for the date we're passing)
        start_date = dt - timedelta(days=20)
        # Query snowflake
        spot_prices = pq.get_spot_prices('lng',start_date=start_date)
        # Filter for just freight
        df = spot_prices[spot_prices['DESCRIPTION'].isin(['LNG Asia Pacific Carrier Day Rate','LNG Atlantic Carrier Day Rate'])]
        df_freight = df.pivot(index="ASSESSDATE",
                              columns="DESCRIPTION",
                              values="VALUE"
                              )
        # Extract the values - use latest available date if requested date is missing or NaN
        actual_date_asia = dt
        actual_date_atlantic = dt
        
        # Get Asia Pacific rate - check for both missing date AND NaN value
        asia_col = 'LNG Asia Pacific Carrier Day Rate'
        if dt in df_freight.index and pd.notna(df_freight.loc[dt, asia_col]):
            asia_pac = df_freight.loc[dt, asia_col]
        else:
            # Find latest available date with non-NaN value prior to or on requested date
            asia_series = df_freight[asia_col].dropna()
            available_dates = asia_series.index[asia_series.index <= dt]
            if len(available_dates) > 0:
                actual_date_asia = available_dates.max()
                asia_pac = asia_series.loc[actual_date_asia]
            else:
                raise KeyError(f"No Asia Pacific freight data available on or before {dt}")
        
        # Get Atlantic rate - check for both missing date AND NaN value
        atlantic_col = 'LNG Atlantic Carrier Day Rate'
        if dt in df_freight.index and pd.notna(df_freight.loc[dt, atlantic_col]):
            atlantic = df_freight.loc[dt, atlantic_col]
        else:
            # Find latest available date with non-NaN value prior to or on requested date
            atlantic_series = df_freight[atlantic_col].dropna()
            available_dates = atlantic_series.index[atlantic_series.index <= dt]
            if len(available_dates) > 0:
                actual_date_atlantic = available_dates.max()
                atlantic = atlantic_series.loc[actual_date_atlantic]
            else:
                raise KeyError(f"No Atlantic freight data available on or before {dt}")
        
        # Build fallback info dict (only include dates that differ from requested)
        fallback_info = {}
        if actual_date_asia != dt:
            fallback_info['asia_pacific'] = actual_date_asia
        if actual_date_atlantic != dt:
            fallback_info['atlantic'] = actual_date_atlantic
        
        return asia_pac, atlantic, fallback_info
    
    else:
        # Query snowflake
        spot_prices = pq.get_spot_prices('lng',start_date = dt - timedelta(days=365))
        
        # Filter for reqd data
        reqd_prices = ['LNG Asia Pacific Carrier Day Rate',
                       'LNG Atlantic Carrier Day Rate',
                       'LNG Japan/Korea DES Spot Crg',
                       'LNG Med DES $/MMBtu',
                       'LNG NWE DES $/MMBtu',
                       'LNG West India Marker'
                       ]
        df = spot_prices[spot_prices['DESCRIPTION'].isin(reqd_prices)]
        df_spot = df.pivot(index="ASSESSDATE",
                           columns="DESCRIPTION",
                           values="VALUE"
                           )
        return df_spot
        
    



def get_freight_costs(hub_price, freight_dayrate, voyage_days, port_cost=0, canal_toll=0, vessel_type='platts', label=None):
    
    # in mmbtu
    loaded_cargo_qty = vessel_sizes[vessel_type]
    loaded_cargo_qty *= freight_constants['energy_content']
    loaded_cargo_qty *= freight_constants['fillable_volume']
    
    total_days = voyage_days + freight_constants['days_in_port']
    total_days2 = total_days + freight_constants['days_in_port']
    
    heel_gas = loaded_cargo_qty
    heel_gas *= total_days * freight_constants['boiloffrate_ballast']
    delivered_cargo = loaded_cargo_qty
    delivered_cargo *= (1 - freight_constants['boiloffrate_laden']) ** total_days
    delivered_cargo -= heel_gas
    
    laden_boiloff_qty = loaded_cargo_qty - heel_gas - delivered_cargo
    bunker_fuel_reqd = freight_constants['bunker_consumption_rate'] * total_days2
    bunker_fuel_reqd -= heel_gas/freight_constants['bunker_fuel_energy_content']
    bunker_fuel_cost = bunker_fuel_reqd * freight_constants['bunker_price'] / delivered_cargo
    
    df = pd.DataFrame({'hub_price': hub_price})
    df['boiloff_heel_gas_cost'] = df['hub_price'] * (heel_gas + laden_boiloff_qty) / delivered_cargo
    
    cargo_days = 2 * total_days / delivered_cargo
    
    if isinstance(freight_dayrate, pd.Series):
        # Truncate prices as forwad freight is only published for less than 2yrs (ie less than the settles)
        df = df[:len(freight_dayrate)]
        df['charter_cost'] = freight_dayrate.values * cargo_days
    else:
        df['charter_cost'] = freight_dayrate * cargo_days
        
    insurance_cost = freight_constants['insurance_usd_per_day'] * cargo_days
        
    df['total_freight'] = df['boiloff_heel_gas_cost'] + df['charter_cost'] + bunker_fuel_cost + canal_toll + insurance_cost + port_cost
    
    df['heel_gas'] = heel_gas
    df['delivered_cargo'] = delivered_cargo
    df['laden_boiloff_qty'] = laden_boiloff_qty
    df['bunker_fuel_reqd'] = bunker_fuel_reqd
    df['bunker_fuel_cost'] = bunker_fuel_cost
    df['insurance_cost'] = insurance_cost
    
    if label:
        new_col = f"total_freight_{label}"
        df = df.rename(columns={'total_freight': new_col})
        return df[[new_col]]
    else:
        return df
    


def generate_netbacks(settle_date, use_freight_forward, hh_slope = 1.15):

    try:
        df_prices, df_freight = get_ice_settles(settle_date)
        
        # Shift JKM prices to reflect journey time
        df_prices['JKM_shifted'] = df_prices['JKM'].shift(-1).dropna()
        
        # Track any fallback dates used for spot freight
        freight_fallback_info = {}
        
        if use_freight_forward:
            freight_asia = df_freight['Spark25S'] 
            freight_atlantic = df_freight['Spark30S'] 
        else:
            # Get platts spot freight (may use fallback dates if requested date missing)
            freight_asia, freight_atlantic, freight_fallback_info = get_platts_data(settle_date)
            
        
        
        hh_desc = f"HH + {hh_slope:.2f}"
            
        df_prices[hh_desc] = df_prices['HH'] * hh_slope
        
    
        
        
        us2nl = get_freight_costs(df_prices[hh_desc],
                                  freight_atlantic, 
                                  voyages['us>nl'],
                                  port_cost=port_costs['nl'],
                                   label='us>nl'
                                  )
        
        us2sk_suez = get_freight_costs(df_prices[hh_desc],
                                       freight_atlantic, 
                                       voyages['us>suez>sk'],
                                       port_cost=port_costs['sk'],
                                       canal_toll=suez_canal_fee,
                                       label='us>suez>sk'
                                       )
        
        
        us2sk_panama = get_freight_costs(df_prices[hh_desc],
                                         freight_atlantic, 
                                         voyages['us>panama>sk'],
                                         port_cost=port_costs['sk'],
                                         canal_toll=panama_canal_fee,
                                         label='us>panama>sk'
                                         )
        
        us2sk = get_freight_costs(df_prices[hh_desc],
                                  freight_atlantic, 
                                  voyages['us>sk'],
                                  port_cost=port_costs['sk'],
                                  label='us>sk'
                                  )
        
        
        df_netbacks = pd.concat([df_prices, us2nl, us2sk_panama, us2sk_suez, us2sk], axis=1)
        
        # df_netbacks.columns
        
        df_netbacks['US>SK [Total]'] = df_netbacks[hh_desc] + df_netbacks["total_freight_us>sk"]
        df_netbacks['US>SK [Profit]'] = df_netbacks['JKM_shifted'] - df_netbacks['US>SK [Total]']
        
        df_netbacks['US>Panama>SK [Total]'] = df_netbacks[hh_desc] + df_netbacks["total_freight_us>panama>sk"]
        df_netbacks['US>Panama>SK [Profit]'] = df_netbacks['JKM_shifted'] - df_netbacks['US>Panama>SK [Total]']
        
        df_netbacks['US>Suez>SK [Total]'] = df_netbacks[hh_desc] + df_netbacks["total_freight_us>suez>sk"]
        df_netbacks['US>Suez>SK [Profit]'] = df_netbacks['JKM_shifted'] - df_netbacks['US>Suez>SK [Total]']
        
        df_netbacks['US>NL [Total]'] = df_netbacks[hh_desc] + df_netbacks["total_freight_us>nl"]
        df_netbacks['US>NL [Profit]'] = df_netbacks['TFU'] - df_netbacks['US>NL [Total]']
        
        
        df_netbacks['US>Asia vs US>EU [Profit]'] = df_netbacks['US>SK [Profit]'] - df_netbacks['US>NL [Profit]']
        df_netbacks['US>Suez>Asia vs US>EU [Profit]'] = df_netbacks['US>Suez>SK [Profit]'] - df_netbacks['US>NL [Profit]']
        df_netbacks['US>Panama>Asia vs US>EU [Profit]'] = df_netbacks['US>Panama>SK [Profit]'] - df_netbacks['US>NL [Profit]']
        
        df_netbacks['JKM/TFU'] = df_netbacks['JKM'] - df_netbacks['TFU']
        
        # df_netbacks.columns
        # df_netbacks['JKM/TFU'].plot()
        
        # df_netbacks.to_csv('c:/temp/netbacks.csv')
        
        df_netbacks = df_netbacks[:'2028-01-01'].dropna()
        
        return df_netbacks, freight_asia, freight_atlantic, freight_fallback_info
    
    except Exception:
        logging.error('Failed generating report')
        tb = traceback.format_exc()
        logging.error(tb)
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), {} 


def generate_report(netbacks_fwdf: dict, netbacks_spotf: dict):
    """
    Generate LNG netbacks report comparing forward vs spot freight.

    Returns two images:
        1. Netbacks panel (6-panel, 3x2 grid):
            Row 1: Netback Premium       (Fwd) | Netback Premium       (Spot)
            Row 2: Profit Margins        (Fwd) | Profit Margins        (Spot)
            Row 3: Cost Stack            (Fwd) | Cost Stack            (Spot)
        2. Price curves chart: HH / TFU / JKM Forward Curves

    Parameters
    ----------
    netbacks_fwdf : dict
        Keys are settlement dates (datetime). Each value is a dict with:
            'netbacks'         : pd.DataFrame (DELIVERY_START index)
            'freight_asia'     : pd.Series (date index, $/day)
            'freight_atlantic' : pd.Series (date index, $/day)
            'freight_fallback_info' : dict (optional, dates used if fallback occurred)
    netbacks_spotf : dict
        Same structure as netbacks_fwdf but freight values are floats (spot rate).

    Returns
    -------
    tuple : (netbacks_base64, prices_base64, notes_html, freight_fallback_notes)
        netbacks_base64 : str - Base64 encoded PNG of netbacks panel
        prices_base64 : str - Base64 encoded PNG of price curves chart
        notes_html : str - HTML string with report notes/assumptions
        freight_fallback_notes : list - List of strings describing any fallback dates used
    """
    _apply_chart_style()
    
    # ── Sort dates, identify today and historical snapshots ───────────────────
    sorted_dates = sorted(netbacks_fwdf.keys(), reverse=True)
    settle_date  = sorted_dates[0]
    
    # For spot freight, use latest available date if settle_date not available
    sorted_spot_dates = sorted(netbacks_spotf.keys(), reverse=True)
    if settle_date in netbacks_spotf:
        spot_settle_date = settle_date
    else:
        # Use the latest available spot date
        spot_settle_date = sorted_spot_dates[0] if sorted_spot_dates else None

    def build_historical(netbacks_dict, primary_date):
        historical = []
        dict_dates = sorted(netbacks_dict.keys(), reverse=True)
        for d in dict_dates:
            if d == primary_date:
                continue
            offset_days = (settle_date - d).days
            historical.append({
                'df':    netbacks_dict[d]['netbacks'],
                'data':  netbacks_dict[d],
                'label': f'T-{offset_days}',
                'alpha': max(0.25, 0.55 - 0.08 * len(historical)),
                'lw':    max(0.5, 0.8 - 0.1 * len(historical)),
            })
        return historical

    hist_fwd  = build_historical(netbacks_fwdf, settle_date)
    hist_spot = build_historical(netbacks_spotf, spot_settle_date)

    df_fwd  = netbacks_fwdf[settle_date]['netbacks']
    df_spot = netbacks_spotf[spot_settle_date]['netbacks'] if spot_settle_date else df_fwd
    
    # Collect fallback notes for spot freight
    freight_fallback_notes = []
    if spot_settle_date and spot_settle_date in netbacks_spotf:
        fallback_info = netbacks_spotf[spot_settle_date].get('freight_fallback_info', {})
        if 'asia_pacific' in fallback_info:
            freight_fallback_notes.append(
                f"Asia Pacific spot freight: using rate from {fallback_info['asia_pacific'].strftime('%d %b %Y')} (no data for {settle_date.strftime('%d %b %Y')} due to holiday)"
            )
        if 'atlantic' in fallback_info:
            freight_fallback_notes.append(
                f"Atlantic spot freight: using rate from {fallback_info['atlantic'].strftime('%d %b %Y')} (no data for {settle_date.strftime('%d %b %Y')} due to holiday)"
            )

    # ── Figure layout (3 rows for netbacks) ─────────────────────────────────────
    fig = plt.figure(figsize=(16, 14), facecolor='white')
    gs  = gridspec.GridSpec(3, 2, figure=fig, hspace=0.45, wspace=0.22,
                            height_ratios=[1, 1, 1])

    ax1l = fig.add_subplot(gs[0, 0])
    ax1r = fig.add_subplot(gs[0, 1])
    ax2l = fig.add_subplot(gs[1, 0])
    ax2r = fig.add_subplot(gs[1, 1])
    ax3l = fig.add_subplot(gs[2, 0])
    ax3r = fig.add_subplot(gs[2, 1])

    # ── Shared styling constants ──────────────────────────────────────────────
    profit_cols  = ['US>NL [Profit]', 'US>SK [Profit]', 'US>Panama>SK [Profit]']
    colors_lines = {'US>NL [Profit]': COLORS['us_nl'], 'US>SK [Profit]': COLORS['us_sk'],
                    'US>Panama>SK [Profit]': COLORS['us_panama']}
    labels_lines = {'US>NL [Profit]': 'US → NL', 'US>SK [Profit]': 'US → SK (via CoGH)',
                    'US>Panama>SK [Profit]': 'US → SK (via Panama)'}

    bar_cols   = ['US>Asia vs US>EU [Profit]', 'US>Panama>Asia vs US>EU [Profit]']
    bar_labels = ['US → Asia (via CoGH)', 'US → Asia (via Panama)']
    colors_pos = [COLORS['positive'], COLORS['positive_alt']]
    colors_neg = [COLORS['negative'], COLORS['negative_alt']]

    routes = {
        'US → NL':          {'freight': 'total_freight_us>nl',        'dest': 'TFU', 'color': COLORS['us_nl']},
        'US → SK (CoGH)':   {'freight': 'total_freight_us>sk',        'dest': 'JKM', 'color': COLORS['us_sk']},
        'US → SK (Panama)': {'freight': 'total_freight_us>panama>sk', 'dest': 'JKM', 'color': COLORS['us_panama']},
    }
    freight_colors = COLORS['freight_stack']
    c_hh  = COLORS['hh']
    c_liq = COLORS['hh_liq']

    # ── Helper: plot profit margins ───────────────────────────────────────────
    def plot_profit_margins(ax, df_nb, historical, title):
        for h in historical:
            for col in profit_cols:
                if col in h['df'].columns:
                    h_clipped = h['df'].loc[df_nb.index[0]:]
                    ax.plot(h_clipped.index, h_clipped[col], color=colors_lines[col],
                            linewidth=h['lw'], alpha=h['alpha'], linestyle='--', zorder=1)
        for col in profit_cols:
            ax.plot(df_nb.index, df_nb[col], marker='o', markersize=2.5, linewidth=1.2,
                    color=colors_lines[col], label=labels_lines[col], zorder=3)
        ax.axhline(0, color=COLORS['zero_line'], linewidth=0.5, linestyle='-', alpha=0.4)
        ax.set_xlim(df_nb.index[0] - pd.Timedelta(days=10),
                    df_nb.index[-1] + pd.Timedelta(days=10))
        _style_axis(ax, title=title)
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        plt.setp(ax.get_xticklabels(), rotation=40, ha='right')
        legend_els = [Line2D([0], [0], color=colors_lines[c], linewidth=1.2, marker='o',
                             markersize=2.5, label=labels_lines[c]) for c in profit_cols]
        legend_els += [Line2D([0], [0], color='#888888', linewidth=h['lw'], linestyle='--',
                              alpha=min(h['alpha'] + 0.15, 0.7), label=h['label'])
                       for h in historical]
        ax.legend(handles=legend_els, loc='upper center', bbox_to_anchor=(0.5, -0.18),
                  ncol=min(len(legend_els), 5), columnspacing=1.0, handletextpad=0.5)

    # ── Helper: plot netback premium ──────────────────────────────────────────
    def plot_netback_premium(ax, df_nb, historical, title):
        dates = df_nb.index
        x     = np.arange(len(dates))
        width = 0.35
        for i, (col, label, cp, cn) in enumerate(zip(bar_cols, bar_labels, colors_pos, colors_neg)):
            vals       = df_nb[col].values
            bar_colors = [cp if v >= 0 else cn for v in vals]
            offset     = (i - 0.5) * width
            ax.bar(x + offset, vals, width=width, color=bar_colors,
                   edgecolor='none', linewidth=0, zorder=3)
        ax.axhline(0, color=COLORS['zero_line'], linewidth=0.6, linestyle='-', zorder=4)
        ax.plot(x, df_nb['JKM/TFU'].values, color='#505A64', linewidth=1.2,
                linestyle='--', marker='o', markersize=2.5, zorder=5)
        for h in historical:
            if 'JKM/TFU' in h['df'].columns:
                aligned = h['df']['JKM/TFU'].reindex(df_nb.index)
                ax.plot(x, aligned.values, color='#505A64',
                        linewidth=h['lw'], alpha=h['alpha'], linestyle='--', zorder=2)
        ax.set_xlim(-0.5, len(x) - 0.5)
        trans = ax.get_xaxis_transform()
        ax.text(x[-1] - 0.3, 0.96, 'Asia Premium', color=COLORS['text_muted'], fontsize=6,
                va='top', ha='right', style='italic', transform=trans)
        ax.text(x[-1] - 0.3, 0.04, 'Europe Premium', color=COLORS['text_muted'], fontsize=6,
                va='bottom', ha='right', style='italic', transform=trans)
        ax.set_xticks(x)
        ax.set_xticklabels([d.strftime('%b-%y') for d in dates], rotation=40, ha='right')
        _style_axis(ax, title=title)
        legend_els = [
            Patch(facecolor=colors_pos[0], edgecolor='none', label=bar_labels[0]),
            Patch(facecolor=colors_pos[1], edgecolor='none', label=bar_labels[1]),
            Line2D([0], [0], color='#505A64', linewidth=1.2, linestyle='--',
                   marker='o', markersize=2.5, label='JKM/TFU'),
        ]
        legend_els += [Line2D([0], [0], color='#888888', linewidth=h['lw'], linestyle='--',
                              alpha=min(h['alpha'] + 0.15, 0.7), label=h['label'])
                       for h in historical]
        ax.legend(handles=legend_els, loc='upper center', bbox_to_anchor=(0.5, -0.18),
                  ncol=min(len(legend_els), 5), columnspacing=1.0, handletextpad=0.5)

    # ── Helper: plot cost stack ───────────────────────────────────────────────
    def plot_cost_stack(ax, df_nb, today_data, title, use_forward_freight=True):
        n_months = len(df_nb)
        bar_w    = 0.22
        x4       = np.arange(n_months)

        for i, (route_label, rc) in enumerate(routes.items()):
            offset   = (i - 1) * bar_w
            hh_vals  = df_nb['HH'].values
            liq_vals = hh_vals * 0.15
            fr_vals  = df_nb[rc['freight']].values
            ax.bar(x4 + offset, hh_vals,  width=bar_w, color=c_hh,
                   edgecolor='none', linewidth=0, zorder=3,
                   label='HH' if i == 0 else '')
            ax.bar(x4 + offset, liq_vals, width=bar_w, bottom=hh_vals,
                   color=c_liq, edgecolor='none', linewidth=0, zorder=3,
                   label='Liquefaction (15%)' if i == 0 else '')
            ax.bar(x4 + offset, fr_vals,  width=bar_w, bottom=hh_vals + liq_vals,
                   color=freight_colors[i], edgecolor='none', linewidth=0, zorder=3,
                   label=f'Freight — {route_label}')

        dest_lines = {
            'US → NL':        {'dest': 'TFU', 'color': COLORS['tfu'], 'label': 'TFU'},
            'US → SK (CoGH)': {'dest': 'JKM', 'color': COLORS['jkm'], 'label': 'JKM'},
        }
        for route_label, dl in dest_lines.items():
            ax.plot(x4, df_nb[dl['dest']].values, color=dl['color'], linewidth=1.2,
                    marker='o', markersize=2.5, zorder=6, label=dl['label'])

        ax_twin = ax.twinx()
        fr_asia     = today_data['freight_asia']
        fr_atlantic = today_data['freight_atlantic']

        fr_asia_vals     = (fr_asia.reindex(df_nb.index, method='nearest').values
                            if isinstance(fr_asia, pd.Series)
                            else np.full(n_months, float(fr_asia)))
        fr_atlantic_vals = (fr_atlantic.reindex(df_nb.index, method='nearest').values
                            if isinstance(fr_atlantic, pd.Series)
                            else np.full(n_months, float(fr_atlantic)))

        # Set labels based on freight type
        if use_forward_freight:
            asia_label = 'Spark25S — Asia'
            atlantic_label = 'Spark30S — Atlantic'
        else:
            asia_label = 'Platts Spot — Asia'
            atlantic_label = 'Platts Spot — Atlantic'

        ax_twin.plot(x4, fr_asia_vals,     color=COLORS['freight_asia'], linewidth=1.0,
                     linestyle=':', marker='^', markersize=2, zorder=7)
        ax_twin.plot(x4, fr_atlantic_vals, color=COLORS['freight_atlantic'], linewidth=1.0,
                     linestyle=':', marker='v', markersize=2, zorder=7)
        ax_twin.set_ylabel('Freight Rate ($/day)', color=COLORS['text_muted'])
        ax_twin.tick_params(axis='y', colors='#555555')
        ax_twin.spines['right'].set_color('#CCCCCC')
        ax_twin.set_xlim(-0.5, n_months - 0.5)

        ax.axhline(0, color=COLORS['zero_line'], linewidth=0.5, linestyle='-', alpha=0.4)
        ax.set_xlim(-0.5, n_months - 0.5)
        ax.set_xticks(x4)
        ax.set_xticklabels([d.strftime('%b-%y') for d in df_nb.index], rotation=40, ha='right')
        _style_axis(ax, title=title, show_right_spine=True)

        legend_els = [
            Patch(facecolor=c_hh, edgecolor='none', label='HH'),
            Patch(facecolor=c_liq, edgecolor='none', label='Liquefaction (15%)'),
            Patch(facecolor=freight_colors[0], edgecolor='none', label='Freight — US → NL'),
            Patch(facecolor=freight_colors[1], edgecolor='none', label='Freight — US → SK (CoGH)'),
            Patch(facecolor=freight_colors[2], edgecolor='none', label='Freight — US → SK (Panama)'),
            Line2D([0], [0], color=COLORS['tfu'], linewidth=1.2, marker='o', markersize=2.5, label='TFU'),
            Line2D([0], [0], color=COLORS['jkm'], linewidth=1.2, marker='o', markersize=2.5, label='JKM'),
            Line2D([0], [0], color=COLORS['freight_asia'], linewidth=1.0, linestyle=':',
                   marker='^', markersize=2, label=asia_label),
            Line2D([0], [0], color=COLORS['freight_atlantic'], linewidth=1.0, linestyle=':',
                   marker='v', markersize=2, label=atlantic_label),
        ]
        ax.legend(handles=legend_els, loc='upper center', bbox_to_anchor=(0.5, -0.18),
                  ncol=3, columnspacing=0.8, handletextpad=0.4)

    # ── Row 1: Netback Premium ────────────────────────────────────────────────
    plot_netback_premium(ax1l, df_fwd,  hist_fwd,
                         f"JKM/TFU USGC Netback Premium — Spark Futures Freight: {settle_date.strftime('%d %b')}")
    plot_netback_premium(ax1r, df_spot, hist_spot,
                         f"JKM/TFU USGC Netback Premium — Platts Spot Freight: {settle_date.strftime('%d %b')}")

    # ── Row 2: Profit Margins ─────────────────────────────────────────────────
    plot_profit_margins(ax2l, df_fwd,  hist_fwd,
                        f"Forward Profit Margins — Spark Futures Freight: {settle_date.strftime('%d %b')}")
    plot_profit_margins(ax2r, df_spot, hist_spot,
                        f"Forward Profit Margins — Platts Spot Freight: {settle_date.strftime('%d %b')}")

    # ── Row 3: Cost Stack ─────────────────────────────────────────────────────
    plot_cost_stack(ax3l, df_fwd,  netbacks_fwdf[settle_date],
                    f"USGC LNG Cost Stack — Spark Futures Freight: {settle_date.strftime('%d %b')}",
                    use_forward_freight=True)
    plot_cost_stack(ax3r, df_spot, netbacks_spotf[spot_settle_date],
                    f"USGC LNG Cost Stack — Platts Spot Freight: {settle_date.strftime('%d %b')}",
                    use_forward_freight=False)

    # Save netbacks figure
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    netbacks_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()

    # ── Separate chart: HH / TFU / JKM Price Curves ───────────────────────────
    fig_prices, ax_prices = plt.subplots(figsize=(10, 4), facecolor='white')
    
    price_cols = ['HH', 'TFU', 'JKM']
    colors_px  = {'HH': COLORS['hh'], 'TFU': COLORS['tfu'], 'JKM': COLORS['jkm']}
    labels_px  = {'HH': 'HH', 'TFU': 'TFU', 'JKM': 'JKM'}
    spread_color = '#7B68A0'

    for h in hist_fwd:
        for col in price_cols:
            if col in h['df'].columns:
                h_clipped = h['df'].loc[df_fwd.index[0]:]
                ax_prices.plot(h_clipped.index, h_clipped[col], color=colors_px[col],
                               linewidth=h['lw'], alpha=h['alpha'], linestyle='--', zorder=1)

    for col in price_cols:
        ax_prices.plot(df_fwd.index, df_fwd[col], marker='o', markersize=2.5, linewidth=1.2,
                       color=colors_px[col], label=labels_px[col], zorder=3)

    ax_prices.set_xlim(df_fwd.index[0] - pd.Timedelta(days=10),
                       df_fwd.index[-1] + pd.Timedelta(days=10))
    _style_axis(ax_prices, title=f"HH, TFU & JKM Forward Curves ($/MMBtu): {settle_date.strftime('%d %b')}",
                ylabel='$/MMBtu', show_right_spine=True)
    ax_prices.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
    ax_prices.xaxis.set_major_locator(mdates.MonthLocator())
    plt.setp(ax_prices.get_xticklabels(), rotation=40, ha='right')

    # Secondary y-axis for JKM/TFU spread
    ax_spread = ax_prices.twinx()
    for h in hist_fwd:
        if 'JKM/TFU' in h['df'].columns:
            h_clipped = h['df'].loc[df_fwd.index[0]:]
            ax_spread.plot(h_clipped.index, h_clipped['JKM/TFU'], color=spread_color,
                           linewidth=h['lw'], alpha=h['alpha'], linestyle=':', zorder=1)
    
    ax_spread.plot(df_fwd.index, df_fwd['JKM/TFU'], marker='s', markersize=2.5, linewidth=1.2,
                   color=spread_color, linestyle='-', zorder=3)
    ax_spread.axhline(0, color=spread_color, linewidth=0.4, linestyle='-', alpha=0.3)
    ax_spread.set_ylabel('JKM/TFU Spread', color=spread_color)
    ax_spread.tick_params(axis='y', colors=spread_color)
    ax_spread.spines['right'].set_color(spread_color)

    legend_els_prices = [Line2D([0], [0], color=colors_px[c], linewidth=1.2, marker='o',
                                 markersize=2.5, label=labels_px[c]) for c in price_cols]
    legend_els_prices.append(Line2D([0], [0], color=spread_color, linewidth=1.2, marker='s',
                                     markersize=2.5, label='JKM/TFU Spread'))
    legend_els_prices += [Line2D([0], [0], color='#888888', linewidth=h['lw'], linestyle='--',
                                  alpha=min(h['alpha'] + 0.15, 0.7), label=h['label'])
                          for h in hist_fwd]
    ax_prices.legend(handles=legend_els_prices, loc='upper center', bbox_to_anchor=(0.5, -0.15),
                     ncol=min(len(legend_els_prices), 6), columnspacing=1.0, handletextpad=0.5)

    plt.tight_layout()
    
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    prices_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    
    # ── Construct notes ───────────────────────────────────────────────────────
    table_style = "border-collapse:collapse; font-size:12px; margin:0 0 12px 0;"
    th_style = "text-align:left; padding:3px 12px 3px 0; border-bottom:1px solid #ccc; font-weight:600; color:#2c3e50;"
    td_style = "padding:2px 12px 2px 0; color:#555;"
    td_val_style = "padding:2px 0; color:#333;"
    
    pct_keys = {'fillable_volume', 'boiloffrate_laden', 'boiloffrate_ballast'}
    
    constants_rows = []
    for key, value in freight_constants.items():
        label = key.replace('_', ' ').title()
        if key in pct_keys:
            formatted = f"{value * 100:.2f}%"
        else:
            formatted = str(value)
        constants_rows.append(f'<tr><td style="{td_style}">{label}</td><td style="{td_val_style}">{formatted}</td></tr>')
    
    voyages = {'us>panama>sk': 26, 'us>suez>sk': 37, 'us>sk': 40, 'us>nl': 13}
    port_costs = {'nl': 0.28, 'sk': 0.12}
    
    notes_html = f"""<table style="border-collapse:collapse; border:none;"><tr>
<td style="vertical-align:top; padding:0 24px 0 0;">
<table style="{table_style}">
<tr><th colspan="2" style="{th_style}">Vessel &amp; Route</th></tr>
<tr><td style="{td_style}">Default vessel size (Platts)</td><td style="{td_val_style}">{vessel_sizes['platts']:,.0f} m³</td></tr>
<tr><td style="{td_style} font-style:italic;" colspan="2">Journey days (16 kts)</td></tr>
<tr><td style="{td_style} padding-left:8px;">NL</td><td style="{td_val_style}">{voyages['us>nl']}d</td></tr>
<tr><td style="{td_style} padding-left:8px;">SK via CoGH</td><td style="{td_val_style}">{voyages['us>sk']}d</td></tr>
<tr><td style="{td_style} padding-left:8px;">SK via Panama</td><td style="{td_val_style}">{voyages['us>panama>sk']}d</td></tr>
<tr><td style="{td_style} padding-left:8px;">SK via Suez</td><td style="{td_val_style}">{voyages['us>suez>sk']}d</td></tr>
</table>
</td>
<td style="vertical-align:top; padding:0 24px 0 0;">
<table style="{table_style}">
<tr><th colspan="2" style="{th_style}">Freight Constants</th></tr>
{''.join(constants_rows)}
</table>
</td>
<td style="vertical-align:top; padding:0;">
<table style="{table_style}">
<tr><th colspan="2" style="{th_style}">Canal &amp; Port Fees</th></tr>
<tr><td style="{td_style}">Panama Canal</td><td style="{td_val_style}">${panama_canal_fee}/mmbtu</td></tr>
<tr><td style="{td_style}">Suez Canal</td><td style="{td_val_style}">${suez_canal_fee}/mmbtu</td></tr>
<tr><td style="{td_style}">Port fee NL</td><td style="{td_val_style}">${port_costs['nl']}/mmbtu</td></tr>
<tr><td style="{td_style}">Port fee SK</td><td style="{td_val_style}">${port_costs['sk']}/mmbtu</td></tr>
</table>
</td>
</tr></table>"""

    return netbacks_base64, prices_base64, notes_html, freight_fallback_notes
    
    

def generate_jkm_tfu_table(netbacks: dict, return_html: bool = True):
    """
    Generate a JKM/TFU spread table across trading dates with aggregated rows.

    Parameters
    ----------
    netbacks : dict
        Keys are settlement dates (datetime). Each value is a dict with:
            'netbacks' : pd.DataFrame (DELIVERY_START index, must contain 'JKM/TFU' column)
    return_html : bool
        True  = return styled HTML string
        False = return raw pandas DataFrame

    Returns
    -------
    str or pd.DataFrame
    """
    def days_in_month(dt):
        return calendar.monthrange(dt.year, dt.month)[1]

    def weighted_avg(values, dates):
        weights = np.array([days_in_month(d) for d in dates])
        values  = np.array(values, dtype=float)
        mask    = ~np.isnan(values)
        if mask.sum() == 0:
            return np.nan
        return np.dot(values[mask], weights[mask]) / weights[mask].sum()

    def quarter_num(month):
        return (month - 1) // 3 + 1

    def quarter_start_month(q):
        return (q - 1) * 3 + 1

    def season_of(dt):
        if 4 <= dt.month <= 9:
            return ('Sum', dt.year)
        else:
            return ('Win', dt.year if dt.month >= 10 else dt.year - 1)

    def winter_months(win_yr):
        return (
            [(win_yr, m) for m in [10, 11, 12]] +
            [(win_yr + 1, m) for m in [1, 2, 3]]
        )

    def build_aggregated(df_nb, settle_dt):
        jkm_tfu = df_nb['JKM/TFU']
        dates    = df_nb.index

        today_year  = settle_dt.year
        today_month = settle_dt.month
        rows        = {}

        # ── Front 6 individual months ─────────────────────────────────────────
        for dt in dates[:6]:
            rows[dt.strftime('%b-%y')] = jkm_tfu.loc[dt]

        # ── Front 3 quarters (strictly after current month) ───────────────────
        cur_q      = quarter_num(today_month)
        front_q    = cur_q + 1
        front_q_yr = today_year
        if front_q > 4:
            front_q    = 1
            front_q_yr = today_year + 1

        quarters_added = 0
        q, q_yr = front_q, front_q_yr
        while quarters_added < 3:
            q_dates = [d for d in dates if d.year == q_yr and quarter_num(d.month) == q]
            if q_dates:
                vals  = [jkm_tfu.loc[d] for d in q_dates]
                label = f'Q{q}-{str(q_yr)[2:]}'
                rows[label] = weighted_avg(vals, q_dates)
                quarters_added += 1
            q += 1
            if q > 4:
                q    = 1
                q_yr += 1

        # ── Front 2 seasons (strictly after current month) ────────────────────
        if today_month < 4:
            front_season = ('Sum', today_year)
        elif today_month < 10:
            front_season = ('Win', today_year)
        else:
            front_season = ('Sum', today_year + 1)

        seasons_added = 0
        s_name, s_yr = front_season
        while seasons_added < 2:
            if s_name == 'Sum':
                s_dates = [d for d in dates if d.year == s_yr and 4 <= d.month <= 9]
                label   = f'Sum-{str(s_yr)[2:]}'
                next_season = ('Win', s_yr)
            else:
                wm      = winter_months(s_yr)
                s_dates = [d for d in dates if (d.year, d.month) in wm]
                label   = f'Win-{str(s_yr)[2:]}'
                next_season = ('Sum', s_yr + 1)

            if s_dates:
                vals = [jkm_tfu.loc[d] for d in s_dates]
                rows[label] = weighted_avg(vals, s_dates)
                seasons_added += 1

            s_name, s_yr = next_season

        # ── Front 1 calendar year (first full cal year after current year) ─────
        cals_added = 0
        yr = today_year + 1
        while cals_added < 1:
            cal_dates = [d for d in dates if d.year == yr]
            if cal_dates:
                vals = [jkm_tfu.loc[d] for d in cal_dates]
                rows[f'Cal-{str(yr)[2:]}'] = weighted_avg(vals, cal_dates)
                cals_added += 1
            yr += 1

        return rows

    # ── Sort dates, most recent first ─────────────────────────────────────────
    sorted_dates = sorted(netbacks.keys(), reverse=True)
    settle_date  = sorted_dates[0]

    # ── Build latest column ───────────────────────────────────────────────────
    latest_rows = build_aggregated(netbacks[settle_date]['netbacks'], settle_date)
    df_out      = pd.DataFrame({'latest': latest_rows})
    df_out.columns = [settle_date.strftime('%d %b')]

    # ── Add delta columns for each historical date ────────────────────────────
    for d in sorted_dates[1:]:
        col_label   = f'vs {d.strftime("%d %b")}'
        hist_rows   = build_aggregated(netbacks[d]['netbacks'], d)
        hist_series = pd.Series(hist_rows)
        delta       = df_out.iloc[:, 0] - hist_series
        df_out[col_label] = delta

    if not return_html:
        return df_out

    # ── Format and style ──────────────────────────────────────────────────────
    format_dict = {df_out.columns[0]: '{:.2f}'}
    for col in df_out.columns[1:]:
        format_dict[col] = '{:+.2f}'

    def style_row(row):
        styles = []
        for i, val in enumerate(row):
            if pd.isna(val):
                styles.append('color: grey;')
            elif i == 0:
                styles.append('color: black; font-weight: bold;')
            elif val > 0:
                styles.append('color: #27ae60; font-weight: bold;')
            elif val < 0:
                styles.append('color: #e74c3c; font-weight: bold;')
            else:
                styles.append('color: grey;')
        return styles

    styled = (
        df_out.style
        .apply(style_row, axis=1)
        .format(format_dict, na_rep='')
        .set_table_styles([
            {'selector': '',
             'props': [('border-collapse', 'collapse'), ('font-size', '11px'),
                       ('font-family', '-apple-system, BlinkMacSystemFont, Segoe UI, Arial, sans-serif')]},
            {'selector': 'thead th',
             'props': [('background-color', '#2c3e50'), ('color', 'white'),
                       ('font-size', '11px'), ('font-weight', '500'), ('text-align', 'center'),
                       ('padding', '5px 8px'), ('border', '1px solid #2c3e50')]},
            {'selector': 'tbody td',
             'props': [('font-size', '11px'), ('text-align', 'center'),
                       ('padding', '3px 8px'), ('border-bottom', '1px solid #eee')]},
            {'selector': 'tbody tr:nth-child(even)',
             'props': [('background-color', '#f8f9fa')]},
            {'selector': 'th.index_name, td.row_heading',
             'props': [('font-weight', '500'), ('background-color', '#f0f1f2'),
                       ('text-align', 'left'), ('padding', '3px 8px'),
                       ('border-bottom', '1px solid #ddd'), ('color', '#333')]},
        ])
    )

    return styled.to_html()



def generate_spot_freight_chart(df_platts: pd.DataFrame):
    """
    Plot historical Platts spot LNG freight rates for Pacific and Atlantic routes.

    Parameters
    ----------
    df_platts : pd.DataFrame
        DataFrame with ASSESSDATE as index and columns:
            'LNG Asia Pacific Carrier Day Rate'
            'LNG Atlantic Carrier Day Rate'
    """
    _apply_chart_style()
    
    fig, ax = plt.subplots(figsize=(9, 3.5), facecolor='white')

    route_config = {
        'LNG Asia Pacific Carrier Day Rate': {'label': 'Asia Pacific', 'color': COLORS['freight_asia']},
        'LNG Atlantic Carrier Day Rate':     {'label': 'Atlantic',     'color': COLORS['freight_atlantic']},
    }

    latest_values = {}
    for col, rc in route_config.items():
        series = df_platts[col].dropna()
        ax.plot(series.index, series.values, color=rc['color'], linewidth=1.2,
                label=rc['label'], zorder=3)
        # Store latest and previous values for annotation
        if len(series) >= 2:
            latest_values[rc['label']] = {
                'current': series.iloc[-1],
                'previous': series.iloc[-2],
                'color': rc['color']
            }

    _style_axis(ax, title='Platts Spot LNG Freight Rate History ($/day)', ylabel='$/day')
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    plt.setp(ax.get_xticklabels(), rotation=40, ha='right')
    ax.set_xlim(df_platts.index[0] - pd.Timedelta(days=5),
                df_platts.index[-1] + pd.Timedelta(days=5))
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'${x:,.0f}'))

    # Add annotation box with current values and deltas
    annotation_lines = ['Latest values (DoD):']
    for label, vals in latest_values.items():
        delta = vals['current'] - vals['previous']
        delta_sign = '+' if delta >= 0 else ''
        annotation_lines.append(f"{label}: ${vals['current']:,.0f} ({delta_sign}{delta:,.0f})")
    
    annotation_text = '\n'.join(annotation_lines)
    ax.text(0.98, 0.96, annotation_text, transform=ax.transAxes, fontsize=8,
            verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round,pad=0.4', facecolor='white', edgecolor='#ccc', alpha=0.9),
            family='monospace', linespacing=1.4, ha='right', ma='left')

    legend_els = [
        Line2D([0], [0], color=rc['color'], linewidth=1.2, label=rc['label'])
        for rc in route_config.values()
    ]
    ax.legend(handles=legend_els, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2)

    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()

    return plot_base64


def generate_freight_chart(netbacks: dict, use_freight_forward: bool):
    """
    Generate a forward freight rates chart for Asia and Atlantic routes.

    Parameters
    ----------
    netbacks : dict
        Keys are settlement dates (datetime). Each value is a dict with:
            'netbacks'         : pd.DataFrame (DELIVERY_START index)
            'freight_asia'     : pd.Series (date index, $/day, name=Spark25S)
            'freight_atlantic' : pd.Series (date index, $/day, name=Spark30S)
    use_freight_forward : bool
        True = Spark Futures freight basis, False = Platts Spot
    """
    _apply_chart_style()

    # ── Sort dates, identify today and historical snapshots ───────────────────
    sorted_dates = sorted(netbacks.keys(), reverse=True)
    settle_date  = sorted_dates[0]
    today_data   = netbacks[settle_date]
    df_netbacks  = today_data['netbacks']
    delivery_idx = df_netbacks.index

    historical = []
    for d in sorted_dates[1:]:
        offset_days = (settle_date - d).days
        historical.append({
            'data':  netbacks[d],
            'label': f'T-{offset_days}',
            'alpha': max(0.25, 0.55 - 0.08 * len(historical)),
            'lw':    max(0.5, 0.8 - 0.1 * len(historical)),
        })

    routes = {
        'freight_asia':     {'label': 'Asia Pacific (Spark25S)', 'color': COLORS['freight_asia']},
        'freight_atlantic': {'label': 'Atlantic (Spark30S)',     'color': COLORS['freight_atlantic']},
    }

    fig, ax = plt.subplots(figsize=(9, 3.5), facecolor='white')

    # ── Historical lines (faded) ──────────────────────────────────────────────
    for h in historical:
        for key, rc in routes.items():
            series  = h['data'][key]
            aligned = series.reindex(delivery_idx, method='nearest')
            ax.plot(delivery_idx, aligned.values, color=rc['color'],
                    linewidth=h['lw'], alpha=h['alpha'], linestyle='--', zorder=1)

    # ── Current lines (with markers) ──────────────────────────────────────────
    for key, rc in routes.items():
        series  = today_data[key]
        aligned = series.reindex(delivery_idx, method='nearest')
        ax.plot(delivery_idx, aligned.values, color=rc['color'], linewidth=1.2,
                marker='o', markersize=2.5, zorder=3, label=rc['label'])

    ax.set_xlim(delivery_idx[0] - pd.Timedelta(days=10),
                delivery_idx[-1] + pd.Timedelta(days=10))
    _style_axis(ax, title=f"LNG Forward Freight Rates ($/day): {settle_date.strftime('%d %b')}",
                ylabel='$/day')
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    plt.setp(ax.get_xticklabels(), rotation=40, ha='right')

    # ── Legend ────────────────────────────────────────────────────────────────
    legend_elements = [
        Line2D([0], [0], color=rc['color'], linewidth=1.2, marker='o',
               markersize=2.5, label=rc['label'])
        for rc in routes.values()
    ]
    legend_elements += [
        Line2D([0], [0], color='#888888', linewidth=h['lw'], linestyle='--',
               alpha=min(h['alpha'] + 0.15, 0.7), label=h['label'])
        for h in historical
    ]
    ax.legend(handles=legend_elements, loc='upper center', bbox_to_anchor=(0.5, -0.15),
              ncol=min(len(legend_elements), 5), columnspacing=1.0, handletextpad=0.5)

    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()

    return plot_base64


def generate_spot_prices_chart(df_spot: pd.DataFrame):
    """
    Plot historical Platts spot LNG prices for JKM, Med, NWE and WIM,
    plus a bar chart showing the JKM/NWE spread.

    Parameters
    ----------
    df_spot : pd.DataFrame
        DataFrame with ASSESSDATE as index and columns:
            'LNG Japan/Korea DES Spot Crg'
            'LNG Med DES $/MMBtu'
            'LNG NWE DES $/MMBtu'
            'LNG West India Marker'

    Returns
    -------
    str
        Base64 encoded PNG image
    """
    _apply_chart_style()

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6), facecolor='white',
                                    height_ratios=[1, 0.8], sharex=True)
    fig.subplots_adjust(hspace=0.35)

    price_config = {
        'LNG Japan/Korea DES Spot Crg': {'label': 'JKM',     'color': COLORS['jkm']},
        'LNG Med DES $/MMBtu':          {'label': 'Med DES', 'color': COLORS['us_panama']},
        'LNG NWE DES $/MMBtu':          {'label': 'NWE DES', 'color': COLORS['tfu']},
        'LNG West India Marker':        {'label': 'WIM',     'color': COLORS['us_suez']},
    }

    jkm_col = 'LNG Japan/Korea DES Spot Crg'

    latest_values = {}
    for col, cfg in price_config.items():
        if col not in df_spot.columns:
            continue
        series = df_spot[col].dropna()
        ax1.plot(series.index, series.values, color=cfg['color'], linewidth=1.2,
                 label=cfg['label'], zorder=3)
        if len(series) >= 2:
            latest_values[cfg['label']] = {
                'current': series.iloc[-1],
                'previous': series.iloc[-2],
                'color': cfg['color']
            }

    _style_axis(ax1, title='Platts LNG Spot Prices ($/MMBtu)', ylabel='$/MMBtu')
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
    ax1.xaxis.set_major_locator(mdates.MonthLocator())

    annotation_lines = ['Latest (DoD):']
    for label, vals in latest_values.items():
        delta = vals['current'] - vals['previous']
        delta_sign = '+' if delta >= 0 else ''
        annotation_lines.append(f"{label}: ${vals['current']:.2f} ({delta_sign}{delta:.2f})")

    annotation_text = '\n'.join(annotation_lines)
    ax1.text(0.02, 0.96, annotation_text, transform=ax1.transAxes, fontsize=8,
             verticalalignment='top', horizontalalignment='left',
             bbox=dict(boxstyle='round,pad=0.4', facecolor='white', edgecolor='#ccc', alpha=0.9),
             family='monospace', linespacing=1.4)

    legend_els = [
        Line2D([0], [0], color=cfg['color'], linewidth=1.2, label=cfg['label'])
        for cfg in price_config.values()
    ]
    ax1.legend(handles=legend_els, loc='upper center', bbox_to_anchor=(0.5, -0.12), ncol=4, fontsize=7)

    nwe_col = 'LNG NWE DES $/MMBtu'
    jkm_series = df_spot[jkm_col].dropna() if jkm_col in df_spot.columns else None
    spread_latest = {}

    if jkm_series is not None and nwe_col in df_spot.columns:
        nwe_series = df_spot[nwe_col].dropna()
        common_idx = jkm_series.index.intersection(nwe_series.index)
        spread = jkm_series.loc[common_idx] - nwe_series.loc[common_idx]

        bar_colors = [COLORS['positive'] if v >= 0 else COLORS['negative'] for v in spread.values]
        ax2.bar(spread.index, spread.values, color=bar_colors, width=2, edgecolor='none', zorder=3)

        if len(spread) >= 2:
            spread_latest['JKM - NWE'] = {
                'current': spread.iloc[-1],
                'previous': spread.iloc[-2],
            }

    ax2.axhline(0, color=COLORS['zero_line'], linewidth=0.6, linestyle='-', zorder=4)
    _style_axis(ax2, title='JKM/NWE Spread ($/MMBtu)', ylabel='$/MMBtu')
    plt.setp(ax2.get_xticklabels(), rotation=40, ha='right')
    ax2.set_xlim(df_spot.index[0] - pd.Timedelta(days=5),
                 df_spot.index[-1] + pd.Timedelta(days=5))

    if spread_latest:
        vals = spread_latest['JKM - NWE']
        delta = vals['current'] - vals['previous']
        delta_sign = '+' if delta >= 0 else ''
        spread_annotation = f"Latest: ${vals['current']:.2f} ({delta_sign}{delta:.2f})"
        ax2.text(0.02, 0.96, spread_annotation, transform=ax2.transAxes, fontsize=8,
                 verticalalignment='top', horizontalalignment='left',
                 bbox=dict(boxstyle='round,pad=0.4', facecolor='white', edgecolor='#ccc', alpha=0.9),
                 family='monospace')

    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', facecolor='white', edgecolor='none')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()

    return plot_base64


# ── JKM/TFU strength vs persistence occupancy heatmap ─────────────────────────

def get_jkm_tfu_spread_history(
    start_date=None,
    end_date=None,
    history_years: int = 1,
) -> pd.DataFrame:
    """
    Pull daily ICE monthly settles for JKM and TFU and compute the spread.

    Returns columns: TRADE_DATE, STRIP, DELIVERY_START, JKM, TFU, JKM_TFU
    """
    if end_date is None:
        end_date = datetime.now()
    if start_date is None:
        end = pd.Timestamp(end_date)
        start_date = end.replace(year=end.year - history_years)

    ice = ICEFuturesQuery()

    frames = []
    for product in ("JKM", "TFU"):
        df = ice.get_strip_prices(
            product=product,
            start_date=start_date,
            end_date=end_date,
        )
        if df.empty:
            raise ValueError(f"No ICE strip prices returned for {product}")

        df = df[df["STRIP_TYPE"] == "Month"].copy()
        df = df[~df["STRIP"].astype(str).str.contains("-", regex=False)]
        df = df[["TRADE_DATE", "STRIP", "DELIVERY_START", "SETTLEMENT_PRICE"]].rename(
            columns={"SETTLEMENT_PRICE": product}
        )
        frames.append(df)

    df_jkm, df_tfu = frames
    merged = df_jkm.merge(
        df_tfu,
        on=["TRADE_DATE", "STRIP", "DELIVERY_START"],
        how="inner",
    )
    merged["JKM_TFU"] = merged["JKM"] - merged["TFU"]
    merged["TRADE_DATE"] = pd.to_datetime(merged["TRADE_DATE"])
    merged["DELIVERY_START"] = pd.to_datetime(merged["DELIVERY_START"])

    return (
        merged.sort_values(["TRADE_DATE", "DELIVERY_START"])
        .reset_index(drop=True)
    )


def _jkm_tfu_bucket_edges(values: pd.Series, bucket_size: float) -> np.ndarray:
    lo = np.floor(values.min() / bucket_size) * bucket_size
    hi = np.ceil(values.max() / bucket_size) * bucket_size
    if np.isclose(lo, hi):
        hi = lo + bucket_size
    return np.arange(lo, hi + bucket_size * 0.5, bucket_size)


def _jkm_tfu_bucket_label(left: float, right: float) -> str:
    return f"[{left:.2f}, {right:.2f}]"


def build_jkm_tfu_occupancy(
    df: pd.DataFrame,
    lookback_days: int = 90,
    bucket_size: float = 0.25,
    n_tenors: int = 18,
    n_expired: int = 3,
):
    """
    Count days each tenor spent in each JKM/TFU spread bucket over a lookback window.

    Returns
    -------
    occupancy : pd.DataFrame
        Tenor × bucket day counts.
    summary : pd.DataFrame
        Per-tenor meta including expired flag and latest/final settle.
    """
    if df.empty:
        raise ValueError("Spread history is empty")

    latest = df["TRADE_DATE"].max()
    window_start = latest - pd.Timedelta(days=lookback_days)
    hist_all = df[df["TRADE_DATE"] >= window_start].copy()

    latest_curve = (
        hist_all[hist_all["TRADE_DATE"] == latest]
        .sort_values("DELIVERY_START")
        .head(n_tenors)
    )
    if latest_curve.empty:
        raise ValueError(f"No strips found on latest trade date {latest.date()}")

    active = latest_curve[["STRIP", "DELIVERY_START"]].drop_duplicates()
    front_delivery = active["DELIVERY_START"].min()

    expired = (
        hist_all[hist_all["DELIVERY_START"] < front_delivery]
        .groupby("STRIP", as_index=False)
        .agg(DELIVERY_START=("DELIVERY_START", "first"))
        .sort_values("DELIVERY_START", ascending=False)
        .head(n_expired)
        .sort_values("DELIVERY_START")
    )

    tenors = pd.concat([expired, active], ignore_index=True)
    tenors["expired"] = tenors["STRIP"].isin(expired["STRIP"])
    hist = hist_all[hist_all["STRIP"].isin(tenors["STRIP"])].copy()

    edges = _jkm_tfu_bucket_edges(hist["JKM_TFU"], bucket_size)
    labels = [_jkm_tfu_bucket_label(edges[i], edges[i + 1]) for i in range(len(edges) - 1)]
    hist["bucket"] = pd.cut(
        hist["JKM_TFU"],
        bins=edges,
        labels=labels,
        right=False,
        include_lowest=True,
    )

    counts = (
        hist.groupby(["STRIP", "bucket"], observed=False)
        .size()
        .unstack(fill_value=0)
        .reindex(columns=labels, fill_value=0)
    )

    tenor_order = tenors.set_index("STRIP")["DELIVERY_START"]
    expired_flag = tenors.set_index("STRIP")["expired"]
    counts = counts.reindex(tenor_order.index).fillna(0).astype(int)
    counts.index = [pd.Timestamp(d).strftime("%b-%y") for d in tenor_order.values]
    counts.index.name = "TENOR"
    counts.columns.name = "JKM/TFU bucket ($/mmbtu)"

    summary = (
        hist.groupby("STRIP")
        .agg(
            n_obs=("JKM_TFU", "size"),
            mean=("JKM_TFU", "mean"),
            min=("JKM_TFU", "min"),
            max=("JKM_TFU", "max"),
        )
        .reindex(tenor_order.index)
    )
    last_settle = (
        hist.sort_values("TRADE_DATE")
        .groupby("STRIP")
        .tail(1)
        .set_index("STRIP")["JKM_TFU"]
    )
    summary.insert(0, "DELIVERY_START", tenor_order.values)
    summary.insert(1, "expired", expired_flag.reindex(tenor_order.index).astype(bool).values)
    summary.insert(2, "latest", last_settle.reindex(tenor_order.index).values)
    summary["latest_bucket"] = pd.cut(
        summary["latest"],
        bins=edges,
        labels=labels,
        right=False,
        include_lowest=True,
    ).astype(str)
    summary.index = counts.index
    summary.index.name = "TENOR"

    return counts, summary


def plot_jkm_tfu_occupancy_heatmap(
    occupancy: pd.DataFrame,
    title: str,
    summary: pd.DataFrame = None,
) -> str:
    """
    Render the strength-vs-persistence occupancy heatmap; return base64 PNG.
    """
    fig, ax = plt.subplots(
        figsize=(max(16, occupancy.shape[1] * 1.2), max(7, occupancy.shape[0] * 0.42)),
        facecolor="white",
    )
    data = occupancy.values.astype(float)
    im = ax.imshow(data, aspect="auto", cmap="YlOrRd", interpolation="nearest")

    if summary is not None and "expired" in summary.columns:
        expired_mask = [
            bool(summary.loc[t, "expired"]) if t in summary.index else False
            for t in occupancy.index
        ]
    else:
        expired_mask = [False] * len(occupancy.index)

    for i, is_exp in enumerate(expired_mask):
        if is_exp:
            ax.axhspan(
                i - 0.5, i + 0.5,
                facecolor="#6b7280", alpha=0.22, zorder=3, linewidth=0,
            )

    ax.set_xticks(np.arange(occupancy.shape[1]))
    ax.set_yticks(np.arange(occupancy.shape[0]))
    ax.set_xticklabels(list(occupancy.columns), rotation=45, ha="right", fontsize=8)

    ytick_labels = [f"{t}*" if exp else t for t, exp in zip(occupancy.index, expired_mask)]
    ax.set_yticklabels(ytick_labels, fontsize=9)
    for tick, is_exp in zip(ax.get_yticklabels(), expired_mask):
        if is_exp:
            tick.set_color("#6b7280")
            tick.set_fontstyle("italic")

    ax.set_xlabel("JKM/TFU spread strength ($/mmbtu)")
    ax.set_ylabel("Tenor")
    ax.set_title(title, fontsize=11, pad=10)

    vmax = data.max() if data.size else 1
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            val = int(data[i, j])
            if val == 0:
                continue
            color = "#4b5563" if expired_mask[i] else (
                "white" if val > vmax * 0.55 else "#333333"
            )
            ax.text(j, i + 0.12, str(val), ha="center", va="center", fontsize=8, color=color)

    latest_marker = None
    expired_key = None
    if summary is not None and "latest" in summary.columns:
        col_index = {c: j for j, c in enumerate(occupancy.columns)}
        for i, tenor in enumerate(occupancy.index):
            if tenor not in summary.index:
                continue
            row = summary.loc[tenor]
            bucket = row.get("latest_bucket")
            latest_px = row.get("latest")
            is_exp = bool(row.get("expired", False))
            if pd.isna(bucket) or bucket not in col_index or pd.isna(latest_px):
                continue
            j = col_index[bucket]
            edge = "#6b7280" if is_exp else "#1a1a1a"
            ax.add_patch(
                Rectangle(
                    (j - 0.48, i - 0.48), 0.96, 0.96,
                    fill=False, edgecolor=edge, linewidth=1.8, zorder=6,
                )
            )
            ax.text(
                j, i - 0.32, f"{latest_px:.2f}",
                ha="center", va="center", fontsize=6.5, fontweight="bold",
                color="#374151" if is_exp else "#111111",
                bbox=dict(
                    boxstyle="round,pad=0.15",
                    facecolor="#f3f4f6" if is_exp else "white",
                    edgecolor=edge, linewidth=0.6, alpha=0.92,
                ),
                zorder=7,
            )

        latest_marker = Line2D(
            [], [], linestyle="none", marker="s", markersize=8,
            markerfacecolor="none", markeredgecolor="#1a1a1a", markeredgewidth=1.6,
            label="Latest / final settle",
        )
        if any(expired_mask):
            expired_key = Patch(
                facecolor="#6b7280", alpha=0.35, edgecolor="none",
                label="Expired tenor (*)",
            )

    cbar = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    cbar.set_label("Days in bucket (persistence)", fontsize=8)
    cbar.ax.tick_params(labelsize=7)

    ax.set_xticks(np.arange(occupancy.shape[1] + 1) - 0.5, minor=True)
    ax.set_yticks(np.arange(occupancy.shape[0] + 1) - 0.5, minor=True)
    ax.grid(which="minor", color="white", linestyle="-", linewidth=0.6)
    ax.tick_params(which="minor", bottom=False, left=False)

    plt.tight_layout()

    handles = [h for h in (latest_marker, expired_key) if h is not None]
    if handles:
        fig.legend(
            handles=handles,
            loc="lower right",
            bbox_to_anchor=(0.98, 0.01),
            fontsize=7,
            frameon=True,
            fancybox=False,
            edgecolor="#cccccc",
            framealpha=0.95,
        )

    buffer = io.BytesIO()
    plt.savefig(buffer, format="png", bbox_inches="tight", facecolor="white", edgecolor="none")
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode("utf-8")
    buffer.close()
    plt.close(fig)

    return plot_base64


def generate_jkm_tfu_occupancy_chart(
    lookback_days: int = 90,
    bucket_size: float = 0.25,
    n_tenors: int = 18,
    n_expired: int = 3,
    history_years: int = 1,
) -> str:
    """
    Build the JKM/TFU strength-vs-persistence occupancy heatmap for the email report.

    Returns base64-encoded PNG string.
    """
    df_spread = get_jkm_tfu_spread_history(history_years=history_years)
    occupancy, summary = build_jkm_tfu_occupancy(
        df_spread,
        lookback_days=lookback_days,
        bucket_size=bucket_size,
        n_tenors=n_tenors,
        n_expired=n_expired,
    )
    latest = df_spread["TRADE_DATE"].max()
    window_start = latest - pd.Timedelta(days=lookback_days)
    title = (
        f"JKM/TFU strength vs persistence — last {lookback_days}d "
        f"({window_start.date()} → {latest.date()}), "
        f"{bucket_size:.2f} $/mmbtu buckets"
    )
    return plot_jkm_tfu_occupancy_heatmap(occupancy, title=title, summary=summary)
