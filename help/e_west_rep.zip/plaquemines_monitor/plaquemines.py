# Plaquemines monitor to track ramp up progress

import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.fundamental.units import get_conversion_factor,unit_conversion_table

import util


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/plaquemines_monitor')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'plaquemines.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
kpler_user = config.get('KplerConfig','user')
kpler_pass = config.get('KplerConfig','pass')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_plaquemines.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'


now = datetime.now().strftime('%d %b')
email_subject = f"Plaquemines LNG Exports Monitor {now}"


# TODO: new plot to show Plaq vs Calcasieu Pass ramp up comparison?

try:

    logging.info('Running Plaquemines monitor...')    
    
    standard_cargo_size_mcm = 90
    
    # Get conversion factors
    conv_lng_mcm = get_conversion_factor('cu m','mcm',unit_conversion_table)
    conv_bcf_mcm = get_conversion_factor('bcf/d','mcm',unit_conversion_table)
    conv_m_mt_mcm = get_conversion_factor('m mt','mcm',unit_conversion_table)
    
    # Define Venture Global targets (as per earnings calls)
    quarters = ['2024Q4','2025Q1', '2025Q2', '2025Q3', '2025Q4', '2026Q1', '2026Q2', '2026Q3', '2026Q4', '2027Q1']
    #quarters = pd.PeriodIndex(['2024Q4', '2025Q1', '2025Q2', '2025Q3', '2025Q4'], freq='Q')
    # data = {'ForecastLow': [0, 28, 45, 58, 88],
    #         'ForecastHigh': [0, 29, 50, 64, 96],
    #         'Contracted': [0, 24, 18, 18, 18],
    #         'PotentialLow': [0, 28, 45, 58, 88],
    #         'PotentialHigh': [0, 29, 50, 64, 96],
    #         }
    # updated may-25
    # data = {'ForecastLow': [0, 28, 47, 58, 88, 89],
    #         'ForecastHigh': [0, 29, 50, 64, 96, 96],
    #         'Contracted': [0, 24, 18, 18, 18, 18],
    #         'PotentialLow': [0, 28, 47, 58, 88, 89],
    #         'PotentialHigh': [0, 29, 50, 64, 96, 96],
    #         }
    # updated dec-25
    # data = {'ForecastLow': [0, 28, 47, 58, 90, 88, 82, 82],
    #         'ForecastHigh': [0, 29, 50, 64, 94, 94, 88, 88],
    #         'Contracted': [0, 24, 18, 18, 18, 18, 18, 18],
    #         'PotentialLow': [0, 28, 47, 58, 90, 88, 82, 82],
    #         'PotentialHigh': [0, 29, 50, 64, 94, 94, 88, 88],
    #         }
    # updated may-26
    data = {'ForecastLow': [0, 28, 47, 58, 90, 88, 86, 82, 87, 88],
            'ForecastHigh': [0, 29, 50, 64, 94, 94, 92, 90, 95, 94],
            'Contracted': [0, 24, 18, 18, 18, 18, 18, 18, 18, 18],
            'PotentialLow': [0, 28, 47, 58, 90, 88, 82, 82, 82, 82],
            'PotentialHigh': [0, 29, 50, 64, 94, 94, 88, 88, 88, 88],
            }
    
    df_venture_global = pd.DataFrame(data, index=quarters)
    
    # Load latest EA and Platts snapshots
    # TODO: this should be live (so we could plot previous forecasts)
    # EA: https://my.energyaspects.com/explorer/catalogue (see "US LNG exports by terminal")
    # Platts: snowflake query "SELECT * FROM SPGICI_GLOBALLNGANALYTICS_SHARE.LNGANALYTICSV2.SUPPLY_FORECAST_CURRENT WHERE EXPORTPROJECT LIKE '%Plaq%' ORDER BY month"
    logging.info('Loading vendor forecasts from CSV')   
    df_vendors = pd.read_csv(REPORTS_PATH /'vendor_forecasts.csv')
    df_vendors['Date'] = pd.to_datetime(df_vendors['Date'], format='%d/%m/%Y')
    df_vendors =  df_vendors.set_index('Date')

    # Get latest feedgas (for all terminals)
    logging.info('Getting feedgas from BBG')   
    feedgas = util.get_feedgas() * -1
    feedgas_plaq = feedgas[feedgas.index>=datetime(2024,12,1)][['Plaq']]
    
    # Get cargoes
    logging.info('querying cargoes from Kpler')   
    df_cargoes = util.get_kpler_cargoes(kpler_user, kpler_pass, conv_lng_mcm, conv_bcf_mcm)
    
    # Create plots
    logging.info('Creating plots & table')   
    plot_feedgas_daily = util.create_plot_feedgas_daily(feedgas_plaq)
    plot_cargoes_weekly = util.create_cargo_plot_weekly(df_cargoes)
    plot_cargoes_monthly = util.create_cargo_plot_monthly(df_cargoes)
    plot_cargoes_quarterly = util.create_cargo_plot_quaterly(df_cargoes, df_venture_global)
    # plot_vg = util.create_vg_plot(df_venture_global)
    plot_vendors = util.create_vendor_comparison(df_cargoes, df_vendors, df_venture_global, conv_m_mt_mcm, standard_cargo_size_mcm)
    
    plot_feedgas_cargoes = util.create_plot_feedgas_cargoes(feedgas_plaq, df_cargoes)
    
    # Create table of exports
    cargoes_table = util.create_cargoes_html_table(df_cargoes)

    # Define current nameplate
    nplate = 27.2
    
    # Calculate cal25 stats
    cal25_mask = df_venture_global.index.str.startswith('2025')
    vg_forecast_cal25_low = df_venture_global.loc[cal25_mask, 'ForecastLow'].sum()
    vg_forecast_cal25_high = df_venture_global.loc[cal25_mask, 'ForecastHigh'].sum()
    
    # Construct email body
    email_body = f"""<!DOCTYPE html>
                    <html>
                    <body>
                    {plot_feedgas_daily}
                    <br><hr><br>
                    {plot_feedgas_cargoes}
                    <br><hr><br>
                    {plot_cargoes_quarterly}
                    <br><hr><br>
                    {plot_cargoes_monthly}
                    <br><hr><br>
                    {plot_cargoes_weekly}
                    <br><hr><br>
                    {plot_vendors}
                    <br>Standard cargo size of {standard_cargo_size_mcm}mcm used for converting Venture Global forecast.
                    <br>
                    <br><hr><br>
                    {cargoes_table}
                    <br><hr><br>
                    <b><u>Plaquemines Info:</u></b>
                    <br>Nameplate: {nplate}mtpa ({(nplate * conv_m_mt_mcm)/1000:.0f}bcm/yr, {(nplate * conv_m_mt_mcm)/365:.0f}mcm/d, {(nplate * conv_m_mt_mcm)/52/99:.0f}cargoes/wk)
                    <br>Startup Dec-24, 36 trains in total
                    <br>Phase 1: 18 trains (2 trains/block, 9 blocks/phase), 13.6mtpa capa
                    <br>Phase 2: 18 trains (2 trains/block, 9 blocks/phase), 13.6mtpa capa
                    <br>Kpler LNG: <a href='https://terminal.kpler.com/map/search/voyages?fields=location&locations=i7077'>Plaquemines</a>
                    <br>
                    <br>
                    <b><u>Notes:</u></b>
                    <br>Feedgas data is sourced from Bloomberg (GSLIQPLQ Index)
                    <br>Cargo data is read direct from Kpler LNG. 
                    <br>Only cargoes on Kpler with status of "Delivered", "In Transit" and "Loading" are considered. "Scheduled" are ignored.
                    <br>Cargo dates are the date the cargo entered the terminal to commence loading (relevant as Venture Bayou spent just over 1 month at the terminal before departing on 26th Dec-24).
                    <br>Cargo volumes are based on loaded not discharge values (so exclude boil off).
                    <br>Venture Global forecasts originally published in Q4 earnings on 6th Mar-25. <a href='https://www.investing.com/news/transcripts/earnings-call-transcript-venture-global-q4-2024-results-reveal-revenue-decline-93CH-3912652'>See here</a>
                    <br>Revised each quarter, latest as per Q1-26 earnings call <a href='https://s205.q4cdn.com/622838971/files/doc_financials/2026/q1/VG-Quarterly-Investor-Presentation_1Q2026_vF.pdf'>See here</a>
                    <br>Conversion factor: cu m LNG -> mcm = {conv_lng_mcm}
                    <br>Conversion factor: bcf -> mcm = {conv_bcf_mcm}
                    <br>Standard cargo size: {standard_cargo_size_mcm}mcm
                    </body>
                    </html>
                """ 
    
    send_email(receivers, 
               email_subject, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')

    logging.info('Report sent')


except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))    




    