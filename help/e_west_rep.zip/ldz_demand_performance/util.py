import base64
import io
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import pandas as pd

from collections import defaultdict
from datetime import datetime, timedelta

from jain_commods.core.interfaces.sqldb import DataQuery
from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.util.htmlutils import df2html
from jain_commods.fundamental.gas import Forecaster


def get_actual_ldz_demand_ce(demand_zones, date_from, agg_col_name, ce_user, ce_pass):
        
    # Hard coded list of what we require
    # NB: if we update countries then we need to update this dict
    demand_asset_ids = {'BE': 665,
                        'DE_H': 2965,
                        'DE_L': 2967,
                        'FR': 192,
                        'GB': 54,
                        'IT': 1803,
                        'NL': 209,
                        }
    
    # Build str of assets ids
    asset_ids = ','.join([str(demand_asset_ids[c]) for c in demand_zones])
    
    # Query CE
    ce = CElink(ce_user,ce_pass)
    df_ldz_demand = ce.eugasopdata(assets=asset_ids,unit='mcm',dateFrom=date_from.strftime('%Y%m%d'))
    # Repeat the same query to get the metadata
    df_ldz_demand_meta = ce.eugasopdata(assets=asset_ids,unit='mcm',dateFrom=date_from.strftime('%Y%m%d'),meta=True)
    
    # Tidy up
    df_ldz_demand = df_ldz_demand.dropna()
    df_ldz_demand.index = pd.to_datetime(df_ldz_demand['Date'])
    df_ldz_demand = df_ldz_demand.drop(columns=['DateExcel','Date'])
    
    # Rename columns (NB: CE returns series IDs as column names but is preserved from original query)
    # df_ldz_demand.columns = demand_asset_ids.keys()
    # Really overly complicated but ensures we are clean (use metadata query and our dict to rename the columns from the CE response)
    demand_asset_ids_reverse = {v: k for k, v in demand_asset_ids.items()}
    df_ldz_demand.columns = [demand_asset_ids_reverse[int(df_ldz_demand_meta[df_ldz_demand_meta['seriesId']=='assetId'][str(col)].iloc[0])] for col in df_ldz_demand.columns]
    
    # Add total
    df_ldz_demand[agg_col_name] = df_ldz_demand.sum(axis=1)
    
    return df_ldz_demand



def get_data(today, days_history, agg_col_name, ce_user, ce_pass):
    
    to_return = {}
    
    report_date_from = today-timedelta(days=days_history)
    
    countries = ['GB','NL','FR','DE_H','DE_L','IT','BE']
    
    # Get actual demand data
    from_date = datetime(today.year-8,1,1)
    actual_demand = get_actual_ldz_demand_ce(countries,from_date,agg_col_name, ce_user, ce_pass)
    
    # Get forecast history
    dq = DataQuery(logintype='prod')
    
    da_ecens = {}
    
    # Query data for each model
    for model in ['ECENS', 'GFSENS','EC46']:
    
        # Define metadata to query relevant set of curves
        md = {'commodity': 'GAS',
              'category1': 'Demand',
              'category2': 'LDZ',
              'category3': ','.join(countries),
              'category4': model,
              'measurement_type': 'FORECAST',
              'source1': 'JainGlobal',
              'source2': 'EuGasModelProcessor'
              }
        
        # Get historical forecasts
        res = dq.get_data(by='metadata', metadata=md, report_date_from=report_date_from, report_date_to = today, querytype='bulk')
        
        final_output = {}
        
        # Dictionary to store forecasts and actuals for aggregation
        aggregate_data = defaultdict(lambda: defaultdict(dict))
        
        # Process each data_id (ie a demand zone)
        for k in res.keys():
            
            md_name = res[k].name.split('.')
            country = md_name[1]
            demand_zone = md_name[4]
            
            df = res[k].copy()
            
            da = {}
            output = {}
            for rd in sorted(set(df['report_date'].values)):
                
                # We only consider the 0z forecast (as that is what we used in the balance)
                if pd.to_datetime(rd).hour==0:
                    
                    # Get forecast for this report date
                    df_fcast = df[df['report_date']==rd]
            
                    d = {}    
                    
                    # Define offsets we will check
                    for offset in [1,7,10,14,21,28,35,42]:
                        # Calc date to check
                        offset_dt = (pd.Timestamp(rd)+timedelta(days=offset)).normalize()
                        # Check dt exists in actuals (ie its not in the future!)
                        if offset_dt in actual_demand.index.values:
                            # Check dt exists in the forecasts (in case of errors/forecast hasn't been produced)
                            if offset_dt in df_fcast['date'].values:
                                # Get fcast and actual values
                                fcast_val = df_fcast[df_fcast['date']==offset_dt]['value'].iloc[0]
                                actual_val = actual_demand[actual_demand.index==offset_dt][demand_zone].iloc[0]
                                # Calc and capture error
                                error = fcast_val - actual_val
                                d[offset] = error
                                
                                # Store values for the DA plot
                                if offset==1 and model=='ECENS':
                                    da[offset_dt] = [fcast_val, actual_val]
                                
                                # Store values for aggregation
                                key = (rd, offset)
                                if key not in aggregate_data['forecast']:
                                    aggregate_data['forecast'][key] = 0
                                    aggregate_data['actual'][key] = 0
                                
                                aggregate_data['forecast'][key] += fcast_val
                                aggregate_data['actual'][key] += actual_val
                        #     else:
                        #         print(f'{offset_dt} does not exist in data_id {k} report_date {rd}')
                                
                        # else:
                        #     print(f'Actuals data for {offset_dt} does not exist yet')
                    
                    # Capture output for this report_date
                    output[rd] = d
            
            # Store DA and actual
            if model=='ECENS':
                da_ecens[demand_zone] = pd.DataFrame.from_dict(da, orient='index', columns=['forecast','actual'])
            
            # Store offset errors and capture
            df_output = pd.DataFrame(output).T
            
            final_output[demand_zone] = df_output
            
        # Create aggregated 
        agg_output = {}
        for (rd, offset), fcast_val in aggregate_data['forecast'].items():
            actual_val = aggregate_data['actual'][(rd, offset)]
            error = fcast_val - actual_val
            
            if rd not in agg_output:
                agg_output[rd] = {}
            agg_output[rd][offset] = error
        
        df_aggregated = pd.DataFrame(agg_output).T
        final_output[agg_col_name] = df_aggregated
        
        to_return[model] = final_output
        
        
        
    # Add combined df to produce ECENS DA error   
    da_ecens[agg_col_name] = sum(da_ecens.values())        
        
    # Calculate demand averages & add to output
    actual_demand['day_of_year'] = pd.to_datetime(actual_demand.index).dayofyear
    start_dt_5yr = datetime(today.year-5, 1, 1)
    start_dt_3yr = datetime(today.year-3, 1, 1)
    end_dt = datetime(today.year-1, 12, 31)
    df_5yr = actual_demand[start_dt_5yr:end_dt].groupby('day_of_year').mean()
    df_3yr = actual_demand[start_dt_3yr:end_dt].groupby('day_of_year').mean()
        
    da_ecens['5yr_avg'] = df_5yr
    da_ecens['3yr_avg'] = df_3yr

    return to_return, da_ecens
        

def plot_forecast_error_histograms(model, df, country, days_history, days_history_short, bins=20, figsize=(6, 10)):

    # Get the number of offsets (columns)
    n_offsets = len(df.columns)
    
    # Create subplots vertically stacked with shared x-axis
    fig, axes = plt.subplots(n_offsets, 1, figsize=figsize, sharex=True)
    
    # Add overall title
    fig.suptitle(f'{country}: {model} 0Z Forecast Error ({days_history}d history)', 
                 fontsize=12, 
                 # fontweight='bold', 
                 y=0.995)
    
    # Handle case where there's only one offset
    if n_offsets == 1:
        axes = [axes]
    
    # Plot histogram for each offset
    for idx, (col, ax) in enumerate(zip(df.columns, axes)):
        # Get error values, dropping any NaN values
        errors = df[col].dropna()
        
        # Calculate statistics
        mean_error = errors.mean()
        median_error = errors.median()
        std_error = errors.std()
        
        # Calculate more recent mean error
        filter_dt = max(errors.index) - timedelta(days_history_short)
        mean_error_recent = errors[filter_dt:].mean()
        
        # Plot histogram
        ax.hist(errors, bins=bins, alpha=0.3, edgecolor='black', color='gray')  # steelblue
        
        # Add vertical lines for mean and median
        ax.axvline(mean_error, color='red', linestyle='--', linewidth=2, label=f'{days_history}d mean: {mean_error:+.0f}')
        ax.axvline(mean_error_recent, color='green', linestyle='--', linewidth=2, label=f'{days_history_short}d mean: {mean_error_recent:+.0f}')
        ax.axvline(0, color='black', linestyle='-', linewidth=1, alpha=0.5)
        
        # Labels and title
        # Only add x-label to the bottom plot
        if idx == n_offsets - 1:
            ax.set_xlabel('LDZ Error (mcm/d)', fontsize=8)
        
        ax.set_ylabel('Freq', fontsize=8)
        ax.set_title(f'D+{col} (std dev: {std_error:.0f})',  # σ
                     fontsize=11, 
                     # fontweight='bold', 
                     loc='left')
        ax.legend(fontsize=8, loc='upper right')
        ax.grid(True, alpha=0.3, axis='y')
        ax.tick_params(axis='both', labelsize=8)  
    
    plt.tight_layout()
    
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def plot_da_fcast_vs_actual(da_ecens, country, days_history_short):
    
    df = da_ecens[country].copy()
    
    # Add the 3 and 5yr averages
    df['day_of_year'] = pd.to_datetime(df.index).dayofyear
    df['5yr'] = df['day_of_year'].map(da_ecens['5yr_avg'][country])
    df['3yr'] = df['day_of_year'].map(da_ecens['3yr_avg'][country])
    
    # Get recent hist
    df_recent = df.tail(days_history_short)
    
    # Calculate delta (forecast - actual)
    df_recent['delta'] = df_recent['forecast'] - df_recent['actual']
    
    # Create the plot with 2 subplots
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 5), gridspec_kw={'height_ratios': [3, 1]}, sharex=True)
    
    # Top plot: forecast and actual lines
    ax1.plot(df_recent.index, df_recent['forecast'], label='Forecast', linewidth=2, color='darkred', alpha=0.8)
    ax1.plot(df_recent.index, df_recent['actual'], label='Actual', linewidth=2, color='darkblue', alpha=0.8)
    ax1.plot(df_recent.index, df_recent['5yr'], label='LDZ 5yr ma', linewidth=1.5, 
             linestyle='--', color='black', alpha=0.7)
    ax1.plot(df_recent.index, df_recent['3yr'], label='LDZ 3yr ma', linewidth=1.5, 
             linestyle='--', color='#888888', alpha=0.7)
    
    # Formatting for top plot
    ax1.set_ylabel('LDZ (mcm)', fontsize=8)
    ax1.set_title(f'{country}: ECENS 0Z {days_history_short} day DA LDZ Forecast vs Actual', 
                  fontsize=12, 
                  # fontweight='bold',
                  )
    ax1.legend(fontsize=8)
    ax1.grid(True, alpha=0.3)
    ax1.tick_params(axis='both', labelsize=8)
    
    # Bottom plot: bar chart of delta
    colors = ['#E63946' if x > 0 else '#06A77D' for x in df_recent['delta']]
    ax2.bar(df_recent.index, df_recent['delta'], color=colors, alpha=0.7, width=0.8)
    ax2.axhline(y=0, color='black', linestyle='-', linewidth=0.8)
    
    # Formatting for bottom plot
    ax2.set_ylabel('Error (mcm)', fontsize=8)
    ax2.grid(True, alpha=0.3, axis='y')
    ax2.set_xticks(df_recent.index)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter('%d %b'))
    plt.setp(ax2.get_xticklabels(), rotation=45, ha='right')
    ax2.tick_params(axis='both', labelsize=8)  
    
    # Tight layout to prevent label cutoff
    plt.tight_layout()
    
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64


def generate_report(data, today, days_history, agg_col_name, da_ecens):

    days_history_short = 14

    # Produce histogram images for each model results
    plots = defaultdict(lambda: defaultdict(dict))
    for model in data.keys():
        
        for c in data[model].keys():
            plot_img = plot_forecast_error_histograms(model, data[model][c], c, days_history, days_history_short) 
            plot_img_html = f"<img src='data:image/png;base64,{plot_img}' alt='{model} {c} histogram'>"
            plots[model][c] = plot_img_html

    # Produce ECENS DA error plots
    plots_ecens_da = {}
    for c in data['ECENS'].keys():
        plot_img = plot_da_fcast_vs_actual(da_ecens, c, days_history_short)
        plot_img_html = f"<img src='data:image/png;base64,{plot_img}' alt='ECENS {c} DA Error'>"
        plots_ecens_da[c] = plot_img_html

    # Produce section HTML for each country (but in special order)
    c_ordered = [agg_col_name] + sorted([c for c in data['ECENS'].keys() if c != agg_col_name])
    html_all = ''
    for c in c_ordered:
        html = f"""<b>{c} LDZ Forecast vs Actual Error:</b>
                         <br><br>
                         <table>
                         <tr>
                         <td style="vertical-align: top;">{plots['ECENS'][c]}</td>
                         <td width=5>&nbsp;</td>
                         <td style="vertical-align: top;">{plots['GFSENS'][c]}</td>
                         <td width=5>&nbsp;</td>
                         <td style="vertical-align: top;">{plots['EC46'][c]}</td>
                         </tr>
                         <tr>
                         <td colspan=3><br>{plots_ecens_da[c]}</td>
                         </tr>
                         </table>
                         <br><hr><br>
                         """
         
        html_all = html_all + html
        
    # Produce table of all LDZ model stats (this take a few seconds to run)
    model_stats = {}
    for c in sorted([x for x in data['ECENS'].keys() if x != agg_col_name]):
        f = Forecaster(geography=c.replace('_H','').replace('_L',''), cat1='Demand', cat2='LDZ', cat3=c)
        model_stats[c] = {'R2 score': f"{f.model['stats']['validation score']:.4f}",
                          'Mean Abs Error (mcm)': f"{f.model['stats']['validation mae']:.1f}",
                          'Mean Pct Error': f"{f.model['stats']['validation mean %error']:.1f}%",
                          'Training Start': f.config['training_start'],
                          'Training End': f.config['training_end'],
                          }
    df_model_stats = pd.DataFrame.from_dict(model_stats, orient='index')
    model_stats_html = df2html(df_model_stats, hide_index_label=False)
  
    # Construct html
    email_body = f"""<b><u>Notes:</u></b>
                     <br>This weekly report shows recent LDZ model performance. Positive error = overforecast, negative error = underforecast
                     <br>The histograms display a rolling {days_history} days history of LDZ forecasts and the errors at different time horizons.
                     <br>Only the 0Z forecasts are considered as these are used in the daily EU Gas Balances.
                     <br>Whilst the GFSENS model results are displayed, only the ECENS+EC46 outputs are used in the balances.
                     <br>No consideration is given to seperate LDZ model and weather model errors, although the D+1 performance gives an approx indication of any bias.
                     <br>For reference, Metdesk CWG biases for each weather model are here: <a href='https://live.tradingweather.com/?dashboard=cwg-biases'>https://live.tradingweather.com/?dashboard=cwg-biases</a> (although we still use BBG as the forecast provider).
                     <br><hr><br>
                     {html_all}
                     <b><u>Model Stats:</u></b>
                     <br>Following data is read live from the latest saved LDZ models (all are Gradient Boosting regressions).
                     <br><br>
                     {model_stats_html}
                    """
                    
    return email_body
    

            
    
        
    
    
    
    
