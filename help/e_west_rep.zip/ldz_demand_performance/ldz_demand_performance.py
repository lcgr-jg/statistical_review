# LDZ Demand report 
import sys
import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime, timedelta
from pathlib import Path

from jain_commods.fundamental.gas import util
from jain_commods.core.util.emailhelper import send_email

from util import get_data, generate_report


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/ldz_demand_performance')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'ldz_demand_performance.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
days_history = config.getint('ReportSettings','days_history')

ce_user = config.get('CEConfig','user')
ce_pass = config.get('CEConfig','pass')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_ldz_demand_performance.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )
system = platform.system().lower()


# Over rides for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

# Set datetime used for filtering etc
today = pd.to_datetime(datetime.now()).normalize()
email_subject = f"LDZ Demand Model Performance Recap {today.strftime('%d-%b-%Y')}"


try:        
    logging.info(f'Running {email_subject} report')
    
    # Get data
    logging.info('Querying data')
    agg_col_name = 'NWE+IT'
    data, da_ecens = get_data(today, days_history, agg_col_name, ce_user, ce_pass)
    
    # Construct report
    logging.info('Constructing email content')
    email_body = generate_report(data, today, days_history, agg_col_name, da_ecens)
    
    
    # Send email
    logging.info('Sending email')  
    send_email(receivers, 
               email_subject, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')
    
    logging.info('Report sent')
    
except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))    
    