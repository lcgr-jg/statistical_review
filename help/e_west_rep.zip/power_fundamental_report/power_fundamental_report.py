import datetime as dt
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Rectangle


REGIONS = {
    "CWE": ["de", "fr", "nl", "be", "at", "ch"],
    "CEE": ["pl", "cz", "hu"],
    "SEE": ["gr", "rs", "hr",  "si", "ro"],
    "Nordics": [
        "no1", "no2", "no3", "no4", "no5",
        "se1", "se2", "se3", "se4",
        "fi", "dk1", "dk2"
    ],
    "Iberia": ["es", "pt"],
    "UK+IE": ["gb", "ie"],
}

# Sub-zones to generate individual charts for (per region)
# If a region is not listed here, all zones in that region will get individual charts
# Region aggregates always use ALL zones regardless of this setting
SUB_ZONES_TO_PLOT = {
}

# Zone to country name mapping
ZONE_TO_COUNTRY = {
    'de': 'Germany', 'fr': 'France', 'nl': 'Netherlands', 'be': 'Belgium',
    'at': 'Austria', 'ch': 'Switzerland', 'pl': 'Poland', 'cz': 'Czech Republic',
    'sk': 'Slovakia', 'hu': 'Hungary', 'gr': 'Greece', 'ba': 'Bosnia',
    'rs': 'Serbia', 'hr': 'Croatia', 'me': 'Montenegro', 'al': 'Albania',
    'mk': 'North Macedonia', 'si': 'Slovenia', 'ro': 'Romania', 'bg': 'Bulgaria',
    'no1': 'NO1', 'no2': 'NO2', 'no3': 'NO3', 'no4': 'NO4', 'no5': 'NO5',
    'se1': 'SE1', 'se2': 'SE2', 'se3': 'SE3', 'se4': 'SE4',
    'fi': 'Finland', 'dk1': 'DK1', 'dk2': 'DK2',
    'es': 'Spain', 'pt': 'Portugal', 'gb': 'United Kingdom', 'ie': 'Ireland',
    'it': 'Italy', 'it': 'Italy', 'dk': 'Denmark', 'no': 'Norway', 'se': 'Sweden',
}

# Flow destinations config: maps region to list of destination groups
# Each destination group is a list of zones - flows to these zones will be summed together
FLOW_DESTINATIONS = {
    'CWE': [
        ['es'],
        ['gb'],
        ['dk1', 'dk2', 'no2', 'se4'],
        ['cz', 'hu', 'pl', 'si'],
        ['it-nord']
    ],
    'UK+IE': [
        ['ie'],
        ['no2'],
        ['nl', 'dk1', 'be'],
        ['fr']
    ],
    'CEE': [
        ['de', 'at'],
        ['si' , 'ro'],
        ['it-nord'],  # To Italy (via Austria/Slovenia)
    ],
    'SEE': [
        ['at' , 'hu'],  # To CWE (Austria borders SI)
        ['it', 'it-cnor', 'it-csud', 'it-sud'],  # To Italy (borders SI/HR)
    ],
    'Nordics': [
        ['de'],  # To CWE (Germany borders DK1/DK2)
        ['gb'],  # To UK+IE (via interconnectors)
        ['nl']  # To CWE (Netherlands via interconnector)
    ],
    'Iberia': [
        ['fr'],
    ],
    # Individual country flow destinations
    'de': [
        ['fr'], ['nl', 'be'], ['at', 'ch'], ['cz', 'pl'], ['dk1' ,'dk2' , 'se4', 'no2']
    ],
    'fr': [
        ['de', 'be' , 'ch' ], ['es'], ['gb'], ['it-nord']
    ],
    'nl': [
        ['de', 'be'], ['gb'], ['dk1', 'no2']
    ],
    'be': [
         ['fr'], ['nl' , 'de'], ['gb']
    ],
    'at': [
         ['it-nord'], ['cz' , 'de'], ['hu', 'si'], ['ch']
    ],
    'ch': [
        ['de'], ['fr'], ['it-nord'], ['at']
    ],
    'es': [
        ['fr'], ['pt']
    ],
    'pt': [
        ['es']
    ],
    'gb': [
        ['fr'], ['ie'], ['nl' , 'be'], ['no2']
    ],
    'ie': [
        ['gb']
    ],
    'pl': [
        ['de'], ['cz', 'sk'] , ['ua']
    ],
    'cz': [
        ['de'], ['at'], ['sk'], ['pl']
    ],
    'sk': [
        ['cz'], ['pl'], ['hu'], ['at'] , ['ua']
    ],
    'hu': [
        ['at' , 'si' , 'hr'], ['sk'], ['ro'], ['rs'] , ['ua']
    ],
    'si': [
        ['at'], ['it-nord'], ['hr'], ['hu']
    ],
    'ro': [
        ['hu'], ['rs'], ['bg'], ['ua']
    ],
    'bg': [
        ['ro'], ['rs'], ['gr'], ['tr']
    ],
    'hr': [
        ['si'], ['hu'], ['rs'], ['ba'], ['it-csud']
    ],
    'gr': [
        ['bg'], ['al'], ['mk'], ['tr']
    ],
    'dk1': [
        ['de'], ['se1', 'no2']
    ],
    'dk2': [
        ['de'], ['se4']
    ],
    'se1': [
        ['dk1'], ['no3'], ['fi']
    ],
    'se2': [
        ['se1'], ['se3']
    ],
    'se3': [
        ['se2'], ['se4'], ['no1']
    ],
    'se4': [
        ['de'], ['dk2'], ['se3'], ['pl']
    ],
    'no1': [
        ['se3'], ['no2']
    ],
    'no2': [
        ['dk1'], ['no1'], ['no3'], ['gb'], ['nl']
    ],
    'no3': [
        ['no2'], ['no4'], ['se1']
    ],
    'no4': [
        ['no3'], ['no5']
    ],
    'no5': [
        ['no4']
    ],
    'fi': [
        ['se1'], ['ee'], ['ru']
    ],
    'it': [
        ['at'], ['si'], ['ch'], ['fr'], ['it-cnor']
    ],
    'it-cnor': [
        ['it'], ['it-csud'], ['si'], ['at']
    ],
    'it-csud': [
        ['it-cnor'], ['it-sud'], ['hr']
    ],
    'it-sud': [
        ['it-csud'], ['it-cala']
    ],
}


class Report:
    """
    Generate PDF reports with YoY charts for power market data.
    Uses commodity-data-cache DataLoader for data retrieval.
    """
    
    # Fuel type mappings (simple names)
    FUEL_MAPPING = {
        'gas': ['gas'],
        'coal': ['coal'],
        'lignite': ['lignite'],
        'nuclear': ['nuclear'],
        'biomass': ['biomass'],
        'wind': ['wind'],
        'solar': ['solar'],
    }
    
    def __init__(self, start_year, end_year, regions, report_years=None, per_country=False):
        """
        Initialize Report and load data.
        
        Args:
            start_year: Start year for data retrieval
            end_year: End year for data retrieval
            regions: List of region keys or zone codes
            report_years: List of years to include in report (default: all available)
            per_country: If True, generate charts per zone
        """
        self.start_year = start_year
        self.end_year = end_year
        self.regions = regions
        
        # Determine report years
        if report_years is None:
            self.report_years = list(range(start_year, end_year + 1))
        else:
            self.report_years = sorted(report_years)
        
        self.per_country = per_country
        
        # Initialize data attributes
        self.generation = pd.DataFrame()
        self.availability = pd.DataFrame()
        self.load = pd.DataFrame()
        self.hydro_total = pd.DataFrame()
        self.hydro_ror = pd.DataFrame()
        self.hydro_res = pd.DataFrame()
        self.hydro_res_fill = pd.DataFrame()
        self.hydro_balance = pd.DataFrame()
        self.commercial_flow = pd.DataFrame()
        
        # Load data
        print(f"Loading data for regions: {regions}")
        print(f"Year range: {start_year} to {end_year}")
        print(f"Report will cover years: {self.report_years}")
        self._load_data()
    
    def _get_zones_from_regions(self, regions):
        """Convert region names to list of zone codes."""
        zones = []
        for region in regions:
            if region in REGIONS:
                zones.extend(REGIONS[region])
            else:
                zones.append(region.lower())
        # Normalize all zones to lowercase and strip whitespace for consistency
        zones = [z.lower().strip() for z in zones]
        return sorted(list(set(zones)))  # Return sorted unique zones
    
    def _extract_to_long_format(self, df, variable, rename_col='zone'):
        """
        Extract a variable from MultiIndex DataFrame and convert to long format.
        
        Args:
            df: MultiIndex DataFrame from DataLoader
            variable: Variable name to extract (e.g., 'consumption', 'wind')
            rename_col: Name for the entity column (default: 'zone')
        
        Returns:
            DataFrame with columns: datetime, zone, value
        """
        if df.empty or variable not in df.columns.get_level_values(0):
            return pd.DataFrame(columns=['datetime', rename_col, 'value'])
        
        # Extract variable using xs()
        var_data = df.xs(variable, level='variable', axis=1)
        
        # Reset index and melt to long format
        datetime_col = var_data.index.name or 'valuedate'
        long_df = var_data.reset_index().melt(
            id_vars=[datetime_col],
            var_name=rename_col,
            value_name='value'
        )
        long_df = long_df.rename(columns={datetime_col: 'datetime'})
        long_df[rename_col] = long_df[rename_col].str.lower()
        
        return long_df.dropna(subset=['value'])
    
    def _load_data(self):
        """Load all data using commodity-data-cache DataLoader."""
        from jain_commods.core.cache.data.loader import DataLoader
        
        start_date = dt.date(self.start_year, 1, 1)
        end_date = dt.date(self.end_year, 12, 31)
        zones = self._get_zones_from_regions(self.regions)
        today = dt.date.today()
        
        print(f"Loading data for zones: {zones}")
        
        # Load all data in one aligned DataFrame
        loader = DataLoader(
            start_date=start_date,
            end_date=end_date,
            cache_strategy='local_first',
            column_format='multiindex',
            save_to_cache=True,
        )
        
        print("\nLoading fundamental data...")
        df = loader.load([
            ('consumption', {'zones': zones}),
            ('wind', {'zones': zones}),
            ('solar', {'zones': zones}),
            ('nuclear_gen', {'zones': zones}),
            ('gas_gen', {'zones': zones}),
            ('coal_gen', {'zones': zones}),
            ('lignite_gen', {'zones': zones}),
            ('biomass_gen', {'zones': zones}),
            ('hydro_total', {'zones': zones}),
            ('hydro_ror', {'zones': zones}),
            ('hydro_res', {'zones': zones}),
            ('hydro_res_fill', {'zones': zones}),
            ('hydro_balance', {'zones': zones}),
            ('residual_load', {'zones': zones}),
            ('consumption_normal', {'zones': zones}),
            ('wind_normal', {'zones': zones}),
            ('solar_normal', {'zones': zones}),
            ('residual_load_normal', {'zones': zones}),
        ])

        # Fill future actual values with normals for demand, wind, solar, residual load
        today_dt = pd.Timestamp(today).tz_localize(df.index.tz)
        
        for var in ['consumption', 'wind', 'solar', 'residual_load']:
            normal_var = f"{var}_normal"
            if var in df.columns.get_level_values(0) and normal_var in df.columns.get_level_values(0):
                for zone in zones:
                    if zone in df[var].columns and zone in df[normal_var].columns:
                        mask = df.index >= today_dt
                        df.loc[mask, (var, zone)] = df.loc[mask, (normal_var, zone)]
        
        # Load REMIT availability data separately (sequential for reliability)
        print("Loading REMIT availability data...")
        remit_loader = DataLoader(
            start_date=start_date,
            end_date=end_date,
            cache_strategy='local_first',
            column_format='multiindex',
            auto_download=True,
            save_to_cache=True,
            enable_parallel=False
        )
        df_remit = remit_loader.load([
            ('nuclear_avail', {'zones': zones}),
            ('gas_avail', {'zones': zones}),
            ('coal_avail', {'zones': zones}),
            ('lignite_avail', {'zones': zones}),
            ('biomass_avail', {'zones': zones}),
        ])


        if not df.empty and isinstance(df.columns, pd.MultiIndex):
            available_vars = df.columns.get_level_values(0).unique().tolist()
            print(f"  Available variables in df: {available_vars}")
            print(f"  Column level names: {df.columns.names}")
        else:
            print(f"  Warning: df is empty or not MultiIndex. Shape: {df.shape if not df.empty else 'empty'}")
        
        # Load consumption -> self.load
        self.load = self._extract_to_long_format(df, 'consumption')
        
        # Load generation data with fuel_type column
        gen_vars = [
            ('wind', 'wind'), ('solar', 'solar'), ('nuclear_gen', 'nuclear'),
            ('gas_gen', 'gas'), ('coal_gen', 'coal'), ('lignite_gen', 'lignite'),
            ('biomass_gen', 'biomass'),
        ]
        gen_dfs = []
        for var_name, fuel_type in gen_vars:
            gen_df = self._extract_to_long_format(df, var_name)
            if not gen_df.empty:
                gen_df['fuel_type'] = fuel_type
                gen_dfs.append(gen_df)
        self.generation = pd.concat(gen_dfs, ignore_index=True) if gen_dfs else pd.DataFrame()
        
        # Load availability data from REMIT with fuel_type column
        avail_vars = [
            ('nuclear_avail', 'nuclear'), ('gas_avail', 'gas'), ('coal_avail', 'coal'),
            ('lignite_avail', 'lignite'), ('biomass_avail', 'biomass'),
        ]
        avail_dfs = []
        for var_name, fuel_type in avail_vars:
            avail_df = self._extract_to_long_format(df_remit, var_name)
            if not avail_df.empty:
                avail_df['fuel_type'] = fuel_type
                avail_dfs.append(avail_df)
        self.availability = pd.concat(avail_dfs, ignore_index=True) if avail_dfs else pd.DataFrame()
        
        # Load hydro data
        self.hydro_total = self._extract_to_long_format(df, 'hydro_total')
        self.hydro_ror = self._extract_to_long_format(df, 'hydro_ror')
        self.hydro_res = self._extract_to_long_format(df, 'hydro_res')
        self.hydro_res_fill = self._extract_to_long_format(df, 'hydro_res_fill')
        self.hydro_balance = self._extract_to_long_format(df, 'hydro_balance')
        
        # Load commercial flows
        self.commercial_flow = self._load_commercial_flow_data(start_date, end_date, today)
        
        # Performance optimization: Pre-normalize all dataframes to avoid expensive string operations in loops
        print("Optimizing data for performance...")
        dfs_to_normalize = [
            self.load, self.generation, self.availability, 
            self.hydro_total, self.hydro_ror, self.hydro_res, 
            self.hydro_res_fill, self.hydro_balance
        ]
        for df_norm in dfs_to_normalize:
            if not df_norm.empty:
                if 'zone' in df_norm.columns:
                    df_norm['zone'] = df_norm['zone'].astype(str).str.lower().str.strip()
                if 'fuel_type' in df_norm.columns:
                    df_norm['fuel_type'] = df_norm['fuel_type'].astype(str).str.lower().str.strip()
        
        if not self.commercial_flow.empty:
            self.commercial_flow['border'] = self.commercial_flow['border'].astype(str).str.lower().str.strip()
            # Cache available borders for much faster availability checks
            self._available_borders = set(self.commercial_flow['border'].unique())
        else:
            self._available_borders = set()

        print(f"Data loaded: generation={len(self.generation)}, availability={len(self.availability)}, "
              f"load={len(self.load)}, hydro_total={len(self.hydro_total)}, flows={len(self.commercial_flow)}")
        


    
    def generate_pdf(self, output_path):
        """
        Generate PDF report with all charts.
        First shows region-level plots (sum of component countries), then individual country plots.
        
        Args:
            output_path: Path to save PDF file
        """
        print(f"Generating PDF report: {output_path}")
        
        # Collect all regions and zones that will be in the report
        report_regions = []
        report_zones = []
        for region in self.regions:
            if region in REGIONS:
                report_regions.append(region)
                # Use SUB_ZONES_TO_PLOT if configured for this region, otherwise use all zones
                if region in SUB_ZONES_TO_PLOT:
                    report_zones.extend(SUB_ZONES_TO_PLOT[region])
                else:
                    report_zones.extend(REGIONS[region])
            else:
                # Single zone, treat as a "region" for display
                report_zones.append(region.lower())
        
        report_zones = sorted(set(report_zones))
        
        # Define planned pages: (title, region_or_zone, zones_list, is_region, method_name)
        planned_pages = []
        
        # Sort report_zones for consistent sub-ordering
        report_zones_sorted = sorted(set(report_zones))
        
        # Helper to get zones belonging to a region in the report
        def get_report_zones_for_region(region_name):
            if region_name not in REGIONS:
                return [region_name.lower()] if region_name.lower() in report_zones_sorted else []
            r_zones = [z.lower() for z in REGIONS[region_name]]
            return [z for z in report_zones_sorted if z.lower() in r_zones]

        # Organize pages: Region, then its Zones
        for region in report_regions:
            # 1. Add Region pages
            zones = REGIONS.get(region, [region.lower()])
            is_reg = region in REGIONS
            
            planned_pages.append(('Demand + Renewables', region, zones, is_reg, '_create_demand_chart'))
            planned_pages.append(('Generation by Fuel Type', region, zones, is_reg, '_create_generation_chart'))
            planned_pages.append(('Availability by Fuel Type', region, zones, is_reg, '_create_availability_chart'))
            planned_pages.append(('Hydro Situation', region, zones, is_reg, '_create_hydro_chart'))
            if region in FLOW_DESTINATIONS:
                planned_pages.append(('Commercial Flows', region, zones, is_reg, '_create_flow_chart'))
                
            # 2. Add individual Zone pages for this region
            if is_reg:
                for zone in get_report_zones_for_region(region):
                    zone_l = zone.lower()
                    planned_pages.append(('Demand + Renewables', zone, [zone_l], False, '_create_demand_chart'))
                    planned_pages.append(('Generation by Fuel Type', zone, [zone_l], False, '_create_generation_chart'))
                    planned_pages.append(('Availability by Fuel Type', zone, [zone_l], False, '_create_availability_chart'))
                    planned_pages.append(('Hydro Situation', zone, [zone_l], False, '_create_hydro_chart'))
                    if zone_l in FLOW_DESTINATIONS:
                        planned_pages.append(('Commercial Flows', zone_l, [zone_l], False, '_create_flow_chart'))


        # Filter pages that have no data
        final_pages = []
        print("\nChecking data availability for planned pages...")
        
        # Performance: Pre-calculate sets of available zones for each variable to avoid repeated filtering
        avail_load_z = set(self.load['zone'].unique()) if not self.load.empty else set()
        avail_gen_z = set(self.generation['zone'].unique()) if not self.generation.empty else set()
        avail_rem_z = set(self.availability['zone'].unique()) if not self.availability.empty else set()
        avail_hy_tot_z = set(self.hydro_total['zone'].unique()) if not self.hydro_total.empty else set()
        avail_hy_ror_z = set(self.hydro_ror['zone'].unique()) if not self.hydro_ror.empty else set()
        avail_hy_res_z = set(self.hydro_res_fill['zone'].unique()) if not self.hydro_res_fill.empty else set()
        avail_hy_bal_z = set(self.hydro_balance['zone'].unique()) if not self.hydro_balance.empty else set()

        for title, entity, zones, is_region, method_name in planned_pages:
            has_data = False
            zones_l = [z.lower().strip() for z in zones]
            
            if method_name == '_create_demand_chart':
                if any(z in avail_load_z for z in zones_l) or any(z in avail_gen_z for z in zones_l):
                    has_data = True
            elif method_name == '_create_generation_chart':
                # Check specifically for the fuel types plotted in this chart
                if any(z in avail_gen_z for z in zones_l):
                    gen_subset = self.generation[self.generation['zone'].isin(zones_l)]
                    if not gen_subset.empty and any(f in ['nuclear', 'gas', 'coal', 'lignite', 'biomass'] for f in gen_subset['fuel_type'].unique()):
                        has_data = True
            elif method_name == '_create_availability_chart':
                # Check specifically for the fuel types plotted in this chart
                if any(z in avail_rem_z for z in zones_l):
                    avail_subset = self.availability[self.availability['zone'].isin(zones_l)]
                    if not avail_subset.empty and any(f in ['nuclear', 'gas', 'coal', 'lignite', 'biomass'] for f in avail_subset['fuel_type'].unique()):
                        has_data = True
            elif method_name == '_create_hydro_chart':
                if any(z in avail_hy_tot_z for z in zones_l) or any(z in avail_hy_ror_z for z in zones_l) or \
                   any(z in avail_hy_res_z for z in zones_l) or any(z in avail_hy_bal_z for z in zones_l):
                    has_data = True

            elif method_name == '_create_flow_chart':
                # Fast check using cached borders
                found = False
                for sz in zones_l:
                    for dz_group in FLOW_DESTINATIONS.get(entity, []):
                        for dz in dz_group:
                            dz_l = dz.lower().strip()
                            if f"{sz}>{dz_l}" in self._available_borders or \
                               f"{sz}>{dz_l.replace('-', '_')}" in self._available_borders or \
                               f"{sz}>{dz_l.replace('_', '-')}" in self._available_borders:
                                found = True; break
                        if found: break
                    if found: break
                has_data = found

            if has_data:
                final_pages.append((title, entity, zones, is_region, method_name))
            else:
                print(f"  Skipping {title} for {entity} (no data)")

        total_pages = len(final_pages)
        current_page = 0
        
        with PdfPages(output_path) as pdf:
            for title, entity, zones, is_region, method_name in final_pages:
                current_page += 1
                print(f"\nGenerating Page {current_page}/{total_pages}: {title} for {entity}...")
                method = getattr(self, method_name)
                method(pdf, entity, zones, is_region=is_region, 
                       report_regions=report_regions, report_zones=report_zones,
                       page_num=current_page, total_pages=total_pages)
        
        print(f"\nPDF report saved to: {output_path}")
    
    def _get_region_zones(self, region):
        """Get list of zones for a region"""
        if region in REGIONS:
            return REGIONS[region]
        else:
            return [region.lower()]  # Single zone, normalize to lowercase
    
    def _get_borders_for_region(self, region, zones):
        """Get list of borders to load for a region based on FLOW_DESTINATIONS config."""
        if region not in FLOW_DESTINATIONS:
            return []
        
        destination_groups = FLOW_DESTINATIONS[region]
        borders = []
        
        for dest_group in destination_groups:
            for source_zone in zones:
                for dest_zone in dest_group:
                    # Format: SOURCE>DEST
                    border = f"{source_zone.upper()}>{dest_zone.upper()}"
                    borders.append(border)
        
        return list(set(borders))  # Remove duplicates
    
    def _load_commercial_flow_data(self, start_date, end_date, today):
        """Load commercial flow data for all regions with flow destinations configured."""
        from jain_commods.core.cache.data.loader import DataLoader
        
        all_borders = []
        region_borders_map = {}
        
        # Collect all borders needed for configured regions and individual zones
        processed_regions = set()
        
        for region in self.regions:
            if region in REGIONS:
                zones = REGIONS[region]
                # Process region-level flow destinations
                if region in FLOW_DESTINATIONS:
                    borders = self._get_borders_for_region(region, zones)
                    if borders:
                        all_borders.extend(borders)
                        region_borders_map[region] = borders
                        processed_regions.add(region)
                
                # Also process individual zones that have flow destinations
                for zone in zones:
                    zone_lower = zone.lower()
                    if zone_lower in FLOW_DESTINATIONS and zone_lower not in processed_regions:
                        borders = self._get_borders_for_region(zone_lower, [zone_lower])
                        if borders:
                            all_borders.extend(borders)
                            region_borders_map[zone_lower] = borders
                            processed_regions.add(zone_lower)
            elif region in FLOW_DESTINATIONS:
                # Single zone treated as region
                zones = [region.lower()]
                borders = self._get_borders_for_region(region, zones)
                if borders:
                    all_borders.extend(borders)
                    region_borders_map[region] = borders
                    processed_regions.add(region)
        
        if not all_borders:
            return pd.DataFrame()
        
        # Remove duplicates
        all_borders = list(set(all_borders))

        loader = DataLoader(
            start_date=start_date,
            end_date=end_date,
            cache_strategy='local_first',
            column_format='multiindex',
            save_to_cache=True  # Save downloaded data to local cache
        )
        
        # Load all available flow data to see what borders exist
        df = loader.load([
            ('net_commercial_flow_da', {}),  # Load all available borders
        ])
        
        if df.empty:
            print("Warning: No flow data loaded from DataLoader")
            return pd.DataFrame()
        
        # Drop the variable level from MultiIndex - columns are now just border names
        df.columns = df.columns.droplevel(0)
        
        # Get available borders (now they're the column names)
        available_borders = set(df.columns.tolist())
        
        # Filter to only borders that exist and are needed
        # Normalize both requested and available borders for comparison (handle hyphen/underscore variants)
        requested_lower = [b.lower() for b in all_borders]
        available_lower = {b.lower(): b for b in available_borders}
        
        borders_to_keep = []
        for req_border in requested_lower:
            # Try exact match first
            if req_border in available_lower:
                borders_to_keep.append(available_lower[req_border])
            else:
                # Try hyphen/underscore variants for IT borders
                if 'it' in req_border:
                    # Try replacing hyphen with underscore and vice versa
                    variants = [
                        req_border.replace('-', '_'),
                        req_border.replace('_', '-'),
                    ]
                    for variant in variants:
                        if variant in available_lower:
                            borders_to_keep.append(available_lower[variant])
                            break
        
        if borders_to_keep:
            borders_to_keep = list(set(borders_to_keep))  # Remove duplicates
            df = df[borders_to_keep]
            print(f"Loaded {len(borders_to_keep)} borders out of {len(requested_lower)} requested")
        else:
            print(f"Warning: None of the requested borders exist in the data")
            return pd.DataFrame()
        
        # Convert to long format: datetime, border, value
        df_long = df.reset_index()
        
        # Get the datetime column name
        datetime_col = df.index.name if df.index.name else 'valuedate'
        if datetime_col not in df_long.columns:
            datetime_col = 'valuedate'
        
        # Melt to long format (columns are now border names directly)
        df_long = df_long.melt(
            id_vars=[datetime_col],
            var_name='border',
            value_name='value'
        )
        
        # Rename datetime column
        df_long = df_long.rename(columns={datetime_col: 'datetime'})
        
        # Keep only needed columns and drop nulls
        df_long = df_long[['datetime', 'border', 'value']].copy()
        df_long = df_long.dropna(subset=['value'])
        
        print(f"Flow data after conversion: {len(df_long)} rows, {df_long['border'].nunique()} unique borders")
        
        # Store region mapping for later use
        self._region_borders_map = region_borders_map
        
        return df_long.sort_values(['datetime', 'border']).reset_index(drop=True)
    
    def _filter_and_aggregate(self, df, zones, fuel_types=None, sum_zones=False):
        """
        Filter by zones/fuel types and aggregate. Resamples hourly to daily if needed.
        
        Args:
            df: DataFrame with datetime, zone, value (and optionally fuel_type)
            zones: List of zones to filter
            fuel_types: Optional list of fuel types to filter
            sum_zones: If True, sum values across zones (for regions). If False, take mean (for single zones).
        """
        if df.empty:
            return pd.DataFrame(columns=['datetime', 'value'])
        
        # Normalize requested zones (small list, fast)
        zones_lower = [z.lower().strip() for z in zones]
        
        # Performance: Original df['zone'] is already normalized in _load_data
        df_filtered = df[df['zone'].isin(zones_lower)]
        
        # Fallback: try fuzzy matching ONLY if exact match fails
        if df_filtered.empty:
            available_zones = sorted(df['zone'].unique()) if 'zone' in df.columns else []
            print(f"  Warning: No exact zone match. Requested: {zones_lower}, Available: {available_zones}")
            
            # Try fuzzy matching: find zones that contain or are contained by requested zones
            fuzzy_matches = set()
            for req_zone in zones_lower:
                for avail_zone in available_zones:
                    # Match if one contains the other
                    if req_zone in avail_zone or avail_zone in req_zone:
                        fuzzy_matches.add(avail_zone)
                        print(f"    Fuzzy match: '{req_zone}' -> '{avail_zone}'")
            
            if fuzzy_matches:
                print(f"  Using fuzzy matches: {sorted(fuzzy_matches)}")
                df_filtered = df[df['zone'].isin(fuzzy_matches)]
            else:
                return pd.DataFrame(columns=['datetime', 'value'])
        
        if fuel_types and 'fuel_type' in df_filtered.columns:
            # fuel_type column is also pre-normalized in _load_data
            df_filtered = df_filtered[df_filtered['fuel_type'].isin([f.lower() for f in fuel_types])]
        
        if not pd.api.types.is_datetime64_any_dtype(df_filtered['datetime']):
            df_filtered['datetime'] = pd.to_datetime(df_filtered['datetime'])
        
        df_filtered = df_filtered.set_index('datetime')
        
        # Detect hourly data and resample to daily
        sample_times = df_filtered.index[:10]
        is_hourly = any(
            pd.notna(ts) and (ts.hour != 0 or ts.minute != 0 or ts.second != 0)
            for ts in sample_times if pd.notna(ts)
        )
        
        if is_hourly:
            if sum_zones:
                # For regions: sum across zones for each hour, then take mean across hours to get daily average
                # First sum zones for each hour
                df_hourly_summed = df_filtered.groupby(df_filtered.index)['value'].sum()
                # Then resample to daily and take mean
                df_agg = df_hourly_summed.resample('D').mean().reset_index()
                df_agg.columns = ['datetime', 'value']
            else:
                # For single zones: use mean() to get daily average power (MW)
                df_agg = df_filtered['value'].resample('D').mean().reset_index()
                df_agg.columns = ['datetime', 'value']
        else:
            # For daily data
            if sum_zones:
                # Sum across zones for each day
                df_agg = df_filtered.groupby(df_filtered.index.date)['value'].sum().reset_index()
                df_agg['datetime'] = pd.to_datetime(df_agg['index'])
                df_agg = df_agg[['datetime', 'value']]
            else:
                # Take mean if multiple values per day
                df_agg = df_filtered['value'].reset_index()
                df_agg = df_agg.groupby('datetime')['value'].mean().reset_index()
        
        return df_agg.sort_values('datetime').reset_index(drop=True)
    
    def _calculate_rolling_mean(self, df, window=7):
        """Calculate rolling mean (window in days for daily data).
        
        Uses min_periods=1 to avoid NaN explosion on sparse data or at boundaries.
        """
        if df.empty:
            return df
        df = df.sort_values('datetime').copy()
        df['value_rolling'] = df['value'].rolling(window=window, center=True, min_periods=1).mean()
        return df
    
    def _normalize_dates_for_comparison(self, df):
        """Normalize dates to reference year (2020) for multi-year comparison.
        
        Handles timezone-aware datetimes by making them timezone-naive first.
        Returns empty DataFrame if input is empty or missing datetime column.
        """
        if df.empty or 'datetime' not in df.columns:
            return df
        
        df = df.copy()
        
        # Ensure datetime column is datetime type
        if not pd.api.types.is_datetime64_any_dtype(df['datetime']):
            df['datetime'] = pd.to_datetime(df['datetime'], errors='coerce')
        
        # Drop rows where datetime conversion failed
        df = df.dropna(subset=['datetime'])
        if df.empty:
            return df
        
        # Ensure datetime column is timezone-naive for consistent comparison
        if df['datetime'].dt.tz is not None:
            df['datetime'] = df['datetime'].dt.tz_localize(None)
        
        df['year'] = df['datetime'].dt.year
        df['date_normalized'] = df['datetime'].apply(lambda x: x.replace(year=2020))
        return df
    
    def _get_year_style(self, year, is_future=False):
        """
        Get line style and properties for a given year.
        
        Args:
            year: Year to style
            is_future: Whether this segment represents future dates (after today)
            
        Returns:
            Dict with styling properties
        """
        current_year = dt.datetime.now().year
        years_ago = current_year - year
        
        # Improved color palette with better visual distinction
        # Using a perceptually uniform color progression from cool to warm
        color_map = {
            2019: '#2E86AB',  # Deep blue
            2020: '#A23B72',  # Purple
            2021: '#F18F01',  # Orange
            2022: '#C73E1D',  # Red-orange
            2023: '#6A994E',  # Green
            2024: '#BC4749',  # Red
            2025: '#219EBC',  # Cyan-blue
            2026: '#DC143C',  # Crimson (current year)
            2027: '#7209B7',  # Purple
            2028: '#06A77D',  # Teal
        }
        
        # Default color if not in map (use a gradient)
        if year not in color_map:
            # Generate a color based on year position
            base_colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#6A994E']
            color = base_colors[year % len(base_colors)]
        else:
            color = color_map[year]
        
        # Line width: thinner for older years, thicker for recent/future
        # Years ago: 0 = current, 1 = last year, 2 = 2 years ago, etc.
        if year == current_year:
            # Current year: bold
            linewidth = 3.5
            alpha = 1.0
        elif year > current_year:
            # Future years: medium thickness
            linewidth = 2.8
            alpha = 0.85
        else:
            # Historical years: thinner as they get older
            # 1 year ago: 2.2, 2 years ago: 1.8, 3 years ago: 1.5, 4+ years ago: 1.2
            if years_ago == 1:
                linewidth = 2.2
            elif years_ago == 2:
                linewidth = 1.8
            elif years_ago == 3:
                linewidth = 1.5
            elif years_ago == 4:
                linewidth = 1.3
            else:
                linewidth = 1.1  # Very old years
            
            # Alpha also decreases slightly for older years
            alpha = max(0.6, 0.95 - (years_ago - 1) * 0.05)
        
        # Line style: dotted for future dates, solid for historical/current
        linestyle = ':' if is_future else '-'
        
        return {
            'color': color,
            'linestyle': linestyle,
            'alpha': alpha,
            'linewidth': linewidth
        }
    
    def _add_header_footer(self, fig, title, current_zones=None, current_region=None, 
                          report_regions=None, report_zones=None, page_num=None, total_pages=None):
        """
        Add black header and footer in professional style.
        
        Args:
            fig: Matplotlib figure
            title: Header title (without country)
            current_zones: List of current zone codes for footer highlighting
            current_region: Current region name for footer highlighting
            report_regions: List of regions in the report
            report_zones: List of zones in the report
            page_num: Current page number
            total_pages: Total number of pages
        """
        # Header (without country)
        header_rect = Rectangle((0, 0.96), 1, 0.04, transform=fig.transFigure, 
                                facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(header_rect)
        fig.text(0.5, 0.98, title, fontsize=16, fontweight='bold', va='center', 
                ha='center', color='white', zorder=1002)
        
        # Footer
        footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig.transFigure, 
                               facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(footer_rect)
        
        # Use only regions/zones in the report
        if report_regions is None:
            report_regions = []
        if report_zones is None:
            report_zones = []
        
        # Highlight color (yellow that works on black background)
        highlight_color = '#FFD700'  # Gold/yellow
        
        # Determine current item display name
        current_zones_set = set(z.lower() for z in (current_zones or []))
        current_region_lower = current_region.lower() if current_region else None
        
        # Build current location text
        if current_region and current_region_lower and current_region in report_regions:
            # This is a region page
            current_display = current_region
        elif current_zones and len(current_zones) == 1:
            # Single zone page
            zone = current_zones[0].lower()
            current_display = ZONE_TO_COUNTRY.get(zone, zone.upper())
        else:
            current_display = None
        
        # LEFT SIDE: Region list
        if report_regions:
            # Determine "active" region (current region or parent of current zone)
            active_region = None
            is_on_region_page = False
            
            if current_region and current_region in report_regions:
                # This could be a region-level page
                if current_zones and len(current_zones) > 1:
                    is_on_region_page = True
                active_region = current_region
            elif current_zones and len(current_zones) == 1:
                z_l = current_zones[0].lower()
                for r_name, z_list in REGIONS.items():
                    if any(z.lower() == z_l for z in z_list):
                        active_region = r_name
                        break
            
            # Even spacing for regions: use a fixed increment
            x_pos = 0.03
            region_skip = 0.07  # Adjusted for CWE/Iberia/CEE/SEE/Nordics
            for i, reg in enumerate(report_regions):
                is_active = (reg == active_region)
                color = highlight_color if is_active else 'white'
                fig.text(x_pos, 0.015, reg, fontsize=9, fontweight='bold' if is_active else 'normal',
                       va='center', ha='left', color=color, zorder=1002)
                
                # Draw separator if not the last one
                if i < len(report_regions) - 1:
                    # Draw at exactly halfway to next region
                    fig.text(x_pos + region_skip/2, 0.015, "|", fontsize=8, color='#555555', va='center', ha='center')
                
                x_pos += region_skip
        
        # CENTER: Current Region/Zone breadcrumb
        if active_region and active_region in REGIONS:
            # Get all zones in the active region that are also in the report
            region_zones_full = [z.lower() for z in REGIONS[active_region]]
            # Map subset plotted (from report_zones) to preserve order
            if report_zones:
                region_zones_in_report = [z for z in report_zones if z.lower() in region_zones_full]
            else:
                region_zones_in_report = region_zones_full
            
            if region_zones_in_report:
                # Fixed increment for zones too to keep it neat
                z_x_pos = 0.4  # Start point (adjust centering)
                z_skip = 0.035
                
                # Recalculate z_x_pos to center the whole list
                total_z_width = (len(region_zones_in_report) - 1) * z_skip
                z_x_pos = 0.5 - (total_z_width / 2)
                
                for i, z in enumerate(region_zones_in_report):
                    z_upper = z.upper()
                    # Highlight logic:
                    # If on region page -> all yellow
                    # If on zone page -> only this zone yellow
                    is_this_zone_active = False
                    if is_on_region_page:
                        is_this_zone_active = True
                    elif current_zones and len(current_zones) == 1:
                        if z.lower() == current_zones[0].lower():
                            is_this_zone_active = True
                    
                    color = highlight_color if is_this_zone_active else 'white'
                    fig.text(z_x_pos, 0.015, z_upper, fontsize=9, fontweight='bold' if is_this_zone_active else 'normal',
                           va='center', ha='center', color=color, zorder=1002)
                    
                    if i < len(region_zones_in_report) - 1:
                        fig.text(z_x_pos + z_skip/2, 0.015, "|", fontsize=8, color='#555555', va='center', ha='center')
                    
                    z_x_pos += z_skip
        elif current_display:
            # Fallback for single entities not in a region
            fig.text(0.5, 0.015, current_display, fontsize=10, fontweight='bold',
                   va='center', ha='center', color=highlight_color, zorder=1002)
        
        # RIGHT SIDE: Page number in WHITE
        if page_num is not None and total_pages is not None:
            fig.text(0.97, 0.015, f'Page {page_num} / {total_pages}', 
                    fontsize=9, fontweight='bold', va='center', ha='right', 
                    color='white', zorder=1002)


    
    def _get_country_name(self, zone):
        """Get country name from zone code."""
        return ZONE_TO_COUNTRY.get(zone.lower(), zone.upper())
    
    def _safe_legend(self, ax, loc='upper left', fontsize=8):
        """Safely add legend only if there are artists with labels.
        Places legend in top-right corner, outside the plot area."""
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(loc=loc, bbox_to_anchor=(0.98, 1), fontsize=fontsize, 
                     frameon=True, facecolor='white', framealpha=0.9, edgecolor='gray')
    
    def _format_subplot(self, ax, title, xlabel=None, ylabel=None):
        """Apply standard formatting to a subplot with background shading."""
        # Set background color (light gray) to distinguish from white
        ax.set_facecolor('#F5F5F5')
        
        ax.set_title(title, fontsize=12, fontweight='bold', pad=10)
        if xlabel:
            ax.set_xlabel(xlabel, fontsize=10)
        if ylabel:
            ax.set_ylabel(ylabel, fontsize=10)
        self._safe_legend(ax)
        ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5, color='gray')
        ax.set_xlim(dt.datetime(2020, 1, 1), dt.datetime(2020, 12, 31))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
        
        # Add subtle border
        for spine in ax.spines.values():
            spine.set_edgecolor('#CCCCCC')
            spine.set_linewidth(0.5)
    
    def _plot_subplot(self, ax, df, title, xlabel=None, ylabel=None, value_col='value_rolling'):
        """Plot data for a single subplot with year-over-year comparison."""
        # Early return if no data or missing required columns
        if df.empty or 'year' not in df.columns or 'date_normalized' not in df.columns:
            ax.text(0.5, 0.5, 'No data available', 
                   ha='center', va='center', transform=ax.transAxes, fontsize=12)
            self._format_subplot(ax, title, xlabel, ylabel)
            return
        
        current_year = dt.datetime.now().year
        today = dt.date.today()
        
        # Detect timezone from data if present
        tz = None
        if not df.empty and pd.api.types.is_datetime64_any_dtype(df['date_normalized']):
            tz = df['date_normalized'].dt.tz
        
        # Create today_normalized with same timezone as data
        today_normalized = dt.datetime(2020, today.month, today.day)
        if tz is not None:
            today_normalized = pd.Timestamp(today_normalized, tz=tz)
        else:
            today_normalized = pd.Timestamp(today_normalized)
        
        for year in self.report_years:
            year_data = df[df['year'] == year].copy()
            if year_data.empty:
                continue
            
            # Sort by date to ensure proper line plotting
            year_data = year_data.sort_values('date_normalized')
            
            # For current year, split at today's date to make future dates dotted
            if year == current_year:
                past_data = year_data[year_data['date_normalized'] <= today_normalized]
                future_data = year_data[year_data['date_normalized'] > today_normalized]
                
                # Plot past segment (solid)
                if not past_data.empty:
                    style_past = self._get_year_style(year, is_future=False)
                    ax.plot(past_data['date_normalized'], past_data[value_col], 
                           label=f'{year}', **style_past)
                
                # Plot future segment (dotted) - only if there's data
                if not future_data.empty:
                    style_future = self._get_year_style(year, is_future=True)
                    # Don't add label again (already added for past segment)
                    ax.plot(future_data['date_normalized'], future_data[value_col], 
                           label='_nolegend_', **style_future)
            elif year > current_year:
                # Future years: all dotted
                style = self._get_year_style(year, is_future=True)
                ax.plot(year_data['date_normalized'], year_data[value_col], 
                       label=f'{year}', **style)
            else:
                # Historical years: all solid
                style = self._get_year_style(year, is_future=False)
                ax.plot(year_data['date_normalized'], year_data[value_col], 
                       label=f'{year}', **style)
        
        self._format_subplot(ax, title, xlabel, ylabel)
    
    def _create_demand_chart(self, pdf, region, zones, is_region=False, 
                            report_regions=None, report_zones=None, page_num=None, total_pages=None):
        """Chart 1: 2x2 layout with (Residual Load, Load) and (Wind, Solar) (7 day rolling mean)."""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.patch.set_facecolor('white')
        
        # Adjust layout for header/footer
        plt.subplots_adjust(top=0.92, bottom=0.08, left=0.08, right=0.95, hspace=0.3, wspace=0.3)
        
        # Get country/region name for chart titles
        if is_region:
            country_name = region  # Keep region name as-is from config
        elif len(zones) == 1:
            country_name = self._get_country_name(zones[0])
        else:
            country_name = region if region not in REGIONS else ' / '.join([self._get_country_name(z) for z in zones])
        
        # Header without country
        current_region = region if is_region else None
        self._add_header_footer(fig, 'Demand + Renewables', current_zones=zones, 
                               current_region=current_region, report_regions=report_regions, 
                               report_zones=report_zones, page_num=page_num, total_pages=total_pages)
        
        # Data already has actual + forecast + normal merged in _load_data()
        # Use sum_zones=True for regions to sum component countries
        demand = self._filter_and_aggregate(self.load, zones, sum_zones=is_region)
        demand = self._calculate_rolling_mean(demand)
        demand = self._normalize_dates_for_comparison(demand)
        
        wind = self._filter_and_aggregate(self.generation, zones, ['wind'], sum_zones=is_region)
        wind = self._calculate_rolling_mean(wind)
        wind = self._normalize_dates_for_comparison(wind)
        
        solar = self._filter_and_aggregate(self.generation, zones, ['solar'], sum_zones=is_region)
        solar = self._calculate_rolling_mean(solar)
        solar = self._normalize_dates_for_comparison(solar)
        
        # Calculate residual load (demand - wind - solar)
        # Use raw values (with forecasts/normal already merged) before rolling mean
        demand_raw = self._filter_and_aggregate(self.load, zones, sum_zones=is_region)
        wind_raw = self._filter_and_aggregate(self.generation, zones, ['wind'], sum_zones=is_region)
        solar_raw = self._filter_and_aggregate(self.generation, zones, ['solar'], sum_zones=is_region)
        
        # Calculate residual load with normal values
        residual = demand_raw.copy()
        if not wind_raw.empty:
            residual = residual.merge(
                wind_raw[['datetime', 'value']], 
                on='datetime', how='left', suffixes=('', '_wind')
            )
            residual['value'] = residual['value'] - residual['value_wind'].fillna(0)
            residual = residual.drop('value_wind', axis=1)
        
        if not solar_raw.empty:
            residual = residual.merge(
                solar_raw[['datetime', 'value']], 
                on='datetime', how='left', suffixes=('', '_solar')
            )
            residual['value'] = residual['value'] - residual['value_solar'].fillna(0)
            residual = residual.drop('value_solar', axis=1)
        
        # Now calculate rolling mean for residual
        residual = self._calculate_rolling_mean(residual)
        residual = self._normalize_dates_for_comparison(residual)
        
        # Plot subplots with country names in titles
        self._plot_subplot(axes[0, 0], residual, f'Residual Load - {country_name}', ylabel='Power (MW)')
        self._plot_subplot(axes[0, 1], demand, f'Demand - {country_name}', ylabel='Power (MW)')
        self._plot_subplot(axes[1, 0], wind, f'Wind Generation - {country_name}', xlabel='Date', ylabel='Generation (MW)')
        self._plot_subplot(axes[1, 1], solar, f'Solar Generation - {country_name}', xlabel='Date', ylabel='Generation (MW)')
        
        pdf.savefig(fig, dpi=150)
        plt.close(fig)
    
    def _create_generation_chart(self, pdf, region, zones, is_region=False,
                                report_regions=None, report_zones=None, page_num=None, total_pages=None):
        """Chart 2: 2x2 layout with (Nuclear, Gas) and (Coal, Lignite) (7 day rolling mean)."""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.patch.set_facecolor('white')
        
        # Adjust layout for header/footer
        plt.subplots_adjust(top=0.92, bottom=0.08, left=0.08, right=0.95, hspace=0.3, wspace=0.3)
        
        # Get country/region name for chart titles
        if is_region:
            country_name = region  # Keep region name as-is from config
        elif len(zones) == 1:
            country_name = self._get_country_name(zones[0])
        else:
            country_name = region if region not in REGIONS else ' / '.join([self._get_country_name(z) for z in zones])
        
        # Header without country
        current_region = region if is_region else None
        self._add_header_footer(fig, 'Generation by Fuel Type', current_zones=zones,
                               current_region=current_region, report_regions=report_regions,
                               report_zones=report_zones, page_num=page_num, total_pages=total_pages)

        subplot_fuels = {
            (0, 0): ('nuclear', 'Nuclear'),
            (0, 1): ('gas', 'Gas'),
            (1, 0): ('coal', 'Coal'),
            (1, 1): ('lignite', 'Lignite')
        }
        
        for (row, col), (fuel_key, fuel_title) in subplot_fuels.items():
            ax = axes[row, col]
            fuel_types = self.FUEL_MAPPING[fuel_key]
            
            # Use generation data only (not availability, which is capacity)
            # Use sum_zones=True for regions to sum component countries
            fuel_gen = self._filter_and_aggregate(self.generation, zones, fuel_types, sum_zones=is_region)
            
            fuel_gen = self._calculate_rolling_mean(fuel_gen)
            if not fuel_gen.empty:
                fuel_gen = self._normalize_dates_for_comparison(fuel_gen)
                self._plot_subplot(ax, fuel_gen, f'{fuel_title} Generation - {country_name}',
                                 xlabel='Date' if row == 1 else None,
                                 ylabel='Generation (MW)')
            else:
                # If no generation data, show empty plot with message
                ax.text(0.5, 0.5, f'No {fuel_title} generation data available', 
                       ha='center', va='center', transform=ax.transAxes, fontsize=12)
                self._format_subplot(ax, f'{fuel_title} Generation - {country_name}',
                                   xlabel='Date' if row == 1 else None,
                                   ylabel='Generation (MW)')
        
        pdf.savefig(fig, dpi=150)
        plt.close(fig)
    
    def _create_availability_chart(self, pdf, region, zones, is_region=False,
                                  report_regions=None, report_zones=None, page_num=None, total_pages=None):
        """Chart 3: 2x2 layout with (Nuclear, Gas) and (Coal, Lignite) Availability."""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.patch.set_facecolor('white')
        
        # Adjust layout for header/footer
        plt.subplots_adjust(top=0.92, bottom=0.08, left=0.08, right=0.95, hspace=0.3, wspace=0.3)
        
        # Get country/region name for chart titles
        if is_region:
            country_name = region  # Keep region name as-is from config
        elif len(zones) == 1:
            country_name = self._get_country_name(zones[0])
        else:
            country_name = region if region not in REGIONS else ' / '.join([self._get_country_name(z) for z in zones])
        
        # Header without country
        current_region = region if is_region else None
        self._add_header_footer(fig, 'Availability by Fuel Type', current_zones=zones,
                               current_region=current_region, report_regions=report_regions,
                               report_zones=report_zones, page_num=page_num, total_pages=total_pages)

        subplot_fuels = {
            (0, 0): ('nuclear', 'Nuclear'),
            (0, 1): ('gas', 'Gas'),
            (1, 0): ('coal', 'Coal'),
            (1, 1): ('lignite', 'Lignite')
        }
        
        for (row, col), (fuel_key, fuel_title) in subplot_fuels.items():
            ax = axes[row, col]
            fuel_types = self.FUEL_MAPPING[fuel_key]
            
            # Normalize zones to lowercase for consistent matching
            zones_normalized = [z.lower().strip() for z in zones]
            
            fuel_avail = self._filter_and_aggregate(self.availability, zones_normalized, fuel_types, sum_zones=is_region)
            fuel_avail = self._calculate_rolling_mean(fuel_avail)
            
            if not fuel_avail.empty:
                fuel_avail = self._normalize_dates_for_comparison(fuel_avail)
                self._plot_subplot(ax, fuel_avail, f'{fuel_title} Availability - {country_name}',
                                 xlabel='Date' if row == 1 else None,
                                 ylabel='Availability (MW)')
            else:
                ax.text(0.5, 0.5, f'No {fuel_title} availability data available', 
                       ha='center', va='center', transform=ax.transAxes, fontsize=12)
                self._format_subplot(ax, f'{fuel_title} Availability - {country_name}',
                                   xlabel='Date' if row == 1 else None,
                                   ylabel='Availability (MW)')
        
        pdf.savefig(fig, dpi=150)
        plt.close(fig)
    
    def _create_hydro_chart(self, pdf, region, zones, is_region=False,
                           report_regions=None, report_zones=None, page_num=None, total_pages=None):
        """Chart 4: 2x2 layout with (Total Hydro, Run-of-River) and (Reservoir, Hydro Balance) (7 day rolling mean)."""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.patch.set_facecolor('white')
        
        # Adjust layout for header/footer
        plt.subplots_adjust(top=0.92, bottom=0.08, left=0.08, right=0.95, hspace=0.3, wspace=0.3)
        
        # Get country/region name for chart titles
        if is_region:
            country_name = region  # Keep region name as-is from config
        elif len(zones) == 1:
            country_name = self._get_country_name(zones[0])
        else:
            country_name = region if region not in REGIONS else ' / '.join([self._get_country_name(z) for z in zones])
        
        # Header without country
        current_region = region if is_region else None
        self._add_header_footer(fig, 'Hydro Situation', current_zones=zones,
                               current_region=current_region, report_regions=report_regions,
                               report_zones=report_zones, page_num=page_num, total_pages=total_pages)
        
        # Prepare hydro data with rolling mean
        hydro_total_data = self._filter_and_aggregate(self.hydro_total, zones, sum_zones=is_region)
        if not hydro_total_data.empty:
            hydro_total_data = hydro_total_data.copy()
            hydro_total_data['value'] = hydro_total_data['value'] / 24_000
        hydro_total_data = self._calculate_rolling_mean(hydro_total_data)
        if not hydro_total_data.empty:
            hydro_total_data = self._normalize_dates_for_comparison(hydro_total_data)
        
        hydro_ror_data = self._filter_and_aggregate(self.hydro_ror, zones, sum_zones=is_region)
        hydro_ror_data = self._calculate_rolling_mean(hydro_ror_data)
        if not hydro_ror_data.empty:
            hydro_ror_data = self._normalize_dates_for_comparison(hydro_ror_data)
        
        # Prepare hydro balance data (convert MWh to TWh)
        hydro_balance_data = self._filter_and_aggregate(self.hydro_balance, zones, sum_zones=is_region)
        hydro_balance_data = self._calculate_rolling_mean(hydro_balance_data)
        if not hydro_balance_data.empty:
            # Convert MWh to TWh (divide by 1,000,000)
            hydro_balance_data = hydro_balance_data.copy()
            hydro_balance_data['value'] = hydro_balance_data['value'] / 1_000_000
            hydro_balance_data = self._normalize_dates_for_comparison(hydro_balance_data)
        
        # Prepare reservoir filling data (convert MWh to TWh)
        hydro_res_fill_data = self._filter_and_aggregate(self.hydro_res_fill, zones, sum_zones=is_region)
        hydro_res_fill_data = self._calculate_rolling_mean(hydro_res_fill_data)
        if not hydro_res_fill_data.empty:
            # Convert MWh to TWh (divide by 1,000,000)
            hydro_res_fill_data = hydro_res_fill_data.copy()
            hydro_res_fill_data['value'] = hydro_res_fill_data['value'] / 1_000_000
            hydro_res_fill_data = self._normalize_dates_for_comparison(hydro_res_fill_data)
        
        # Plot subplots
        # Top-left: Hydro Balance
        if not hydro_balance_data.empty:
            self._plot_subplot(axes[0, 0], hydro_balance_data, f'Hydro Balance - {country_name}',
                             ylabel='Balance (TWh)')
        else:
            axes[0, 0].text(0.5, 0.5, 'No hydro balance data available', 
                           ha='center', va='center', transform=axes[0, 0].transAxes, fontsize=12)
            self._format_subplot(axes[0, 0], f'Hydro Balance - {country_name}',
                               ylabel='Balance (TWh)')
        
        # Top-right: Hydro Reservoir Filling TWh
        if not hydro_res_fill_data.empty:
            self._plot_subplot(axes[0, 1], hydro_res_fill_data, f'Hydro Reservoir Filling - {country_name}',
                             ylabel='Filling (TWh)')
        else:
            axes[0, 1].text(0.5, 0.5, 'No hydro reservoir filling data available', 
                           ha='center', va='center', transform=axes[0, 1].transAxes, fontsize=12)
            self._format_subplot(axes[0, 1], f'Hydro Reservoir Filling - {country_name}',
                               ylabel='Filling (TWh)')
        
        # Bottom-left: Total Hydro Generation
        if not hydro_total_data.empty:
            self._plot_subplot(axes[1, 0], hydro_total_data, f'Total Hydro Generation - {country_name}',
                             xlabel='Date', ylabel='Generation (GW)')
        else:
            axes[1, 0].text(0.5, 0.5, 'No total hydro generation data available', 
                           ha='center', va='center', transform=axes[1, 0].transAxes, fontsize=12)
            self._format_subplot(axes[1, 0], f'Total Hydro Generation - {country_name}',
                               xlabel='Date', ylabel='Generation (MW)')
        
        # Bottom-right: Run-of-River Hydro Generation
        if not hydro_ror_data.empty:
            self._plot_subplot(axes[1, 1], hydro_ror_data, f'Run-of-River Hydro Generation - {country_name}',
                             xlabel='Date', ylabel='Generation (MW)')
        else:
            axes[1, 1].text(0.5, 0.5, 'No run-of-river hydro generation data available', 
                           ha='center', va='center', transform=axes[1, 1].transAxes, fontsize=12)
            self._format_subplot(axes[1, 1], f'Run-of-River Hydro Generation - {country_name}',
                               xlabel='Date', ylabel='Generation (MW)')
        
        pdf.savefig(fig, dpi=150)
        plt.close(fig)

    def _aggregate_flows_by_destination(self, flow_df, region, zones, silent=True):
        """Aggregate flows by destination groups for a region.
        
        Args:
            flow_df: DataFrame with datetime, border, value
            region: Region/Zone name
            zones: List of source zones
            silent: If True, suppress progress prints (useful for pre-check)
        """
        if flow_df.empty or region not in FLOW_DESTINATIONS:
            return {}
        
        destination_groups = FLOW_DESTINATIONS[region]
        result = {}
        
        # Performance: Use the pre-cached available borders set for fast lookup
        # If not cached yet (shouldn't happen with updated _load_data), find them now
        if not hasattr(self, '_available_borders'):
            self._available_borders = set(flow_df['border'].unique())
        
        all_matching_borders = []
        mapping_groups = []
        
        for dest_group in destination_groups:
            group_borders = []
            for source_zone in zones:
                source_lower = source_zone.lower().strip()
                for dest_zone in dest_group:
                    dest_lower = dest_zone.lower().strip()
                    
                    # Try primary border name: source>dest
                    border_name = f"{source_lower}>{dest_lower}"
                    if border_name in self._available_borders:
                        group_borders.append(border_name)
                    else:
                        # Try common variants (hyphen vs underscore for IT zones)
                        if 'it' in dest_lower:
                            variants = [
                                dest_lower.replace('-', '_'),
                                dest_lower.replace('_', '-'),
                            ]
                            for v in variants:
                                if f"{source_lower}>{v}" in self._available_borders:
                                    group_borders.append(f"{source_lower}>{v}")
                                    break
            
            if group_borders:
                all_matching_borders.extend(group_borders)
                mapping_groups.append((tuple(dest_group), group_borders))
        
        if not all_matching_borders:
            return {}
            
        # Fast filter: slice the giant dataframe once for ALL matching borders in the region
        subset_df = flow_df[flow_df['border'].isin(all_matching_borders)]
        if subset_df.empty:
            return {}
            
        # Group result by dest_group tuple
        for dest_key, borders in mapping_groups:
            group_data = subset_df[subset_df['border'].isin(borders)]
            if not group_data.empty:
                # Sum values across individual borders in the group
                daily_agg = group_data.groupby('datetime')['value'].sum().reset_index()
                result[dest_key] = daily_agg
        
        if not silent:
            print(f"  Aggregated flows for {len(result)} destination groups in {region}")
            
        return result
    
    def _create_flow_chart(self, pdf, region, zones, is_region=False,
                          report_regions=None, report_zones=None, page_num=None, total_pages=None):
        """Chart 5: Commercial flows to destination groups (2x2 or appropriate layout)."""
        if region not in FLOW_DESTINATIONS:
            return
        
        destination_groups = FLOW_DESTINATIONS[region]
        n_groups = len(destination_groups)
        
        # Determine grid size (2x2, 2x3, 3x2, etc.)
        if n_groups <= 4:
            rows, cols = 2, 2
        elif n_groups <= 6:
            rows, cols = 2, 3
        elif n_groups <= 9:
            rows, cols = 3, 3
        else:
            rows, cols = 3, 4
        
        fig, axes = plt.subplots(rows, cols, figsize=(16, 12))
        fig.patch.set_facecolor('white')
        
        # Normalize axes to always be a 2D list for consistent access
        if rows == 1 and cols == 1:
            # Single subplot: plt.subplots returns a single Axes object
            axes = [[axes]]
        elif rows == 1:
            # 1D array (one row, multiple cols): wrap in outer list
            axes = [list(np.atleast_1d(axes))]
        elif cols == 1:
            # 1D array (multiple rows, one col): convert to list of single-element lists
            axes = [[ax] for ax in np.atleast_1d(axes)]
        else:
            # 2D array: convert to list of lists
            axes = [[axes[r][c] for c in range(cols)] for r in range(rows)]
        
        # Adjust layout for header/footer
        plt.subplots_adjust(top=0.92, bottom=0.08, left=0.08, right=0.95, hspace=0.3, wspace=0.3)
        
        # Get country/region name for chart titles
        if is_region:
            country_name = region  # Keep region name as-is from config
        else:
            country_name = self._get_country_name(zones[0]) if len(zones) == 1 else region
        
        # Header without country
        current_region = region if is_region else None
        self._add_header_footer(fig, 'Commercial Flows', current_zones=zones,
                               current_region=current_region, report_regions=report_regions,
                               report_zones=report_zones, page_num=page_num, total_pages=total_pages)
        
        # Aggregate flows by destination groups
        flow_groups = self._aggregate_flows_by_destination(self.commercial_flow, region, zones)
        
        # Plot each destination group
        for idx, dest_group in enumerate(destination_groups):
            if idx >= rows * cols:
                break
            
            row = idx // cols
            col = idx % cols
            ax = axes[row][col]
            
            dest_key = tuple(dest_group)
            if dest_key in flow_groups:
                flow_data = flow_groups[dest_key].copy()
                
                # Ensure datetime is datetime type and set as index for resampling
                if not pd.api.types.is_datetime64_any_dtype(flow_data['datetime']):
                    flow_data['datetime'] = pd.to_datetime(flow_data['datetime'])
                
                flow_data = flow_data.set_index('datetime').sort_index()
                
                # Resample hourly data to daily (take mean for flow)
                if len(flow_data) > 0:
                    # Check if data is hourly (more than 24 points per day on average)
                    time_diff = (flow_data.index[-1] - flow_data.index[0]).total_seconds() / 3600
                    if len(flow_data) > time_diff / 2:  # More than 2 points per hour on average = likely hourly
                        flow_data = flow_data.resample('D').mean()
                    else:
                        # Already daily or lower frequency, just ensure daily
                        flow_data = flow_data.resample('D').mean()
                
                flow_data = flow_data.reset_index()
                
                # Apply 7-day rolling mean
                flow_data = self._calculate_rolling_mean(flow_data)
                
                if not flow_data.empty:
                    # Normalize dates for year-over-year comparison
                    flow_data = self._normalize_dates_for_comparison(flow_data)
                    
                    # Create destination label
                    dest_label = ' / '.join([z.upper() for z in dest_group])
                    
                    # Format title: "Source -> Destination - DA Commercial Flow"
                    title = f'{country_name} -> {dest_label} - DA Commercial Flow'
                    
                    self._plot_subplot(ax, flow_data, 
                                     title,
                                     xlabel='Date' if row == rows - 1 else None,
                                     ylabel='Flow (MW)')
                else:
                    dest_label = ' / '.join([z.upper() for z in dest_group])
                    title = f'{country_name} -> {dest_label} - Day Ahead Commercial Flow'
                    ax.text(0.5, 0.5, f'No flow data available', 
                           ha='center', va='center', transform=ax.transAxes, fontsize=12)
                    self._format_subplot(ax, title,
                                       xlabel='Date' if row == rows - 1 else None,
                                       ylabel='Flow (MW)')
            else:
                dest_label = ' / '.join([z.upper() for z in dest_group])
                title = f'{country_name} -> {dest_label} - Day Ahead Commercial Flow'
                ax.text(0.5, 0.5, f'No flow data available', 
                       ha='center', va='center', transform=ax.transAxes, fontsize=12)
                self._format_subplot(ax, title,
                                   xlabel='Date' if row == rows - 1 else None,
                                   ylabel='Flow (MW)')
        

        for idx in range(n_groups, rows * cols):
            row = idx // cols
            col = idx % cols
            axes[row][col].axis('off')
        
        pdf.savefig(fig, dpi=150)
        plt.close(fig)


if __name__ == '__main__':
    start_year = 2020
    end_year = 2026
    regions = [ "CWE" , "Iberia" , "CEE" , "SEE" ,  "Nordics"  ]
    
    print("Loading data and generating report...")
    report = Report(
        start_year=start_year - 1,
        end_year=end_year,
        regions=regions,
        report_years=None,
        per_country=True
    )

    date_str = dt.datetime.now().strftime('%Y-%m-%d')
    output_path = f'Power Fundamental Report - {date_str}.pdf'
    report.generate_pdf(output_path)


    print(f"\nReport generated for years {start_year} to {end_year} for regions {report.regions}")

