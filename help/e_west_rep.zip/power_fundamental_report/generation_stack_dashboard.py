"""
Plotly Dash dashboard: average hourly generation stack by region/country, period and weekday/weekend.
Side-by-side comparison of two years.

Run:
    python generation_stack_dashboard.py

Data source: jain_commods DataLoader (generation, hydro) + Another/NetExportDayAhead (net_export_da).
"""
import datetime as dt
import pandas as pd
import numpy as np
from dash import Dash, dcc, html, Input, Output, no_update
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from jain_commods.core.cache.data.loader import DataLoader
from jain_commods.core.cache.data.fundamentals importNetExportDayAhead


REGIONS = {
    "CWE": ["de", "fr", "nl", "be", "at", "ch"],
    "CEE": ["pl", "cz", "hu"],
    "SEE": ["gr", "rs", "hr", "si", "ro"],
    "Nordics": [
        "no1", "no2", "no3", "no4", "no5",
        "se1", "se2", "se3", "se4",
        "fi", "dk1", "dk2"
    ],
    "Iberia": ["es", "pt"],
    "UK+IE": ["gb", "ie"],
}

ZONE_TO_COUNTRY = {
    'de': 'Germany', 'fr': 'France', 'nl': 'Netherlands', 'be': 'Belgium',
    'at': 'Austria', 'ch': 'Switzerland', 'pl': 'Poland', 'cz': 'Czech Republic',
    'hu': 'Hungary', 'gr': 'Greece', 'rs': 'Serbia', 'hr': 'Croatia',
    'si': 'Slovenia', 'ro': 'Romania',
    'no1': 'NO1', 'no2': 'NO2', 'no3': 'NO3', 'no4': 'NO4', 'no5': 'NO5',
    'se1': 'SE1', 'se2': 'SE2', 'se3': 'SE3', 'se4': 'SE4',
    'fi': 'Finland', 'dk1': 'DK1', 'dk2': 'DK2',
    'es': 'Spain', 'pt': 'Portugal', 'gb': 'United Kingdom', 'ie': 'Ireland',
}

# Stacking order (bottom -> top): must-run / inflexible -> flexible -> variable renewables.
# net_import is handled separately (split into imports stacked on top + exports below zero).
STACK_ORDER = [
    'nuclear', 'lignite', 'coal', 'biomass',
    'hydro_ror', 'hydro_res', 'gas',
    'wind', 'solar',
]
# Selectable fuels for the per-fuel YoY chart.
FUEL_ORDER = STACK_ORDER + ['net_import']

FUEL_COLORS = {
    'nuclear': '#C71585',
    'lignite': '#6B4423',
    'coal': '#1C1C1C',
    'biomass': '#7CB342',
    'hydro_ror': '#1E88E5',
    'hydro_res': '#5DADE2',
    'gas': '#E67E22',
    'wind': '#00BCD4',
    'solar': '#FBC02D',
    'net_import': '#9E9E9E',
    'net_export': '#5D6D7E',
    'consumption': '#000000',
}

# Variables to load via DataLoader (key in registry -> stack fuel name).
# hydro_ror (must-run) and hydro_res (flexible reservoir) are kept distinct and stacked separately.
# consumption is loaded too — it's overlaid as a demand line on the stack and gets its own YoY chart.
# (hydro_total is daily and would muddy the hourly profile.)
GEN_VARS = {
    'wind': 'wind',
    'solar': 'solar',
    'nuclear_gen': 'nuclear',
    'gas_gen': 'gas',
    'coal_gen': 'coal',
    'lignite_gen': 'lignite',
    'biomass_gen': 'biomass',
    'hydro_ror': 'hydro_ror',
    'hydro_res': 'hydro_res',
    'consumption': 'consumption',
}

DEFAULT_START_YEAR = 2019
DEFAULT_END_YEAR = dt.date.today().year

PERIOD_OPTIONS = (
    [{'label': f'Q{q}', 'value': f'Q{q}'} for q in range(1, 5)] +
    [{'label': m, 'value': f'M{i}'} for i, m in enumerate(
        ['January', 'February', 'March', 'April', 'May', 'June',
         'July', 'August', 'September', 'October', 'November', 'December'], start=1)]
)


def all_zones() -> list:
    zones = set()
    for zs in REGIONS.values():
        zones.update(zs)
    return sorted(zones)


def region_options() -> list:
    """Region groups first, then individual countries."""
    opts = [{'label': f'Region: {r}', 'value': f'R:{r}'} for r in REGIONS]
    seen = set()
    for r, zs in REGIONS.items():
        for z in zs:
            if z in seen:
                continue
            seen.add(z)
            label = ZONE_TO_COUNTRY.get(z, z.upper())
            opts.append({'label': label, 'value': f'Z:{z}'})
    return opts


def resolve_zones(region_value: str) -> list:
    kind, name = region_value.split(':', 1)
    if kind == 'R':
        return [z.lower() for z in REGIONS[name]]
    return [name.lower()]


def period_to_months(period_value: str) -> list:
    if period_value.startswith('Q'):
        q = int(period_value[1:])
        return list(range((q - 1) * 3 + 1, (q - 1) * 3 + 4))
    if period_value.startswith('M'):
        return [int(period_value[1:])]
    raise ValueError(period_value)


def _resolve_is_weekend(daytype: str):
    """'weekday' -> False, 'weekend' -> True, 'week' -> None (no day-of-week filter)."""
    if daytype == 'weekend':
        return True
    if daytype == 'weekday':
        return False
    return None  # 'week' / anything else -> average over the full week


def _daytype_label(daytype: str) -> str:
    return {'weekday': 'Weekday', 'weekend': 'Weekend', 'week': 'Full Week'}.get(daytype, daytype)


# ----- data loading ---------------------------------------------------------

def load_all_data(start_year: int, end_year: int):
    """Load generation + net export for all zones, return tidy DataFrame indexed by datetime."""
    zones = all_zones()
    start_date = dt.date(start_year, 1, 1)
    end_date = dt.date(end_year, 12, 31)

    print(f"Loading generation/hydro for {len(zones)} zones, {start_year}-{end_year}...")
    loader = DataLoader(
        start_date=start_date,
        end_date=end_date,
        cache_strategy='local_first',
        column_format='multiindex',
        save_to_cache=True,
        show_metadata=False,
    )
    df = loader.load([(v, {'zones': zones}) for v in GEN_VARS.keys()])

    print("Loading net_export_da...")
    nx = NetExportDayAhead()
    nx.load(start_date=start_date, end_date=end_date)
    nx_df = nx.data  # index=valuedate, columns=zone

    # Align timezone — strip tz so groupby on hour/dow is consistent
    if df.index.tz is not None:
        df.index = df.index.tz_convert('Europe/Brussels').tz_localize(None)
    if nx_df.index.tz is not None:
        nx_df.index = nx_df.index.tz_convert('Europe/Brussels').tz_localize(None)

    # Build a tidy long DataFrame: datetime, zone, fuel, value (MW)
    frames = []
    for var, fuel in GEN_VARS.items():
        if var not in df.columns.get_level_values(0):
            continue
        sub = df.xs(var, level='variable', axis=1)
        sub.columns = [c.lower() for c in sub.columns]
        long = sub.stack().rename('value').reset_index()
        long.columns = ['datetime', 'zone', 'value']
        long['fuel'] = fuel
        frames.append(long)

    nx_df = nx_df.copy()
    nx_df.columns = [c.lower() for c in nx_df.columns]
    # Net IMPORT = -net_export so positive => imports (adds to local supply)
    nx_long = (-nx_df).stack().rename('value').reset_index()
    nx_long.columns = ['datetime', 'zone', 'value']
    nx_long['fuel'] = 'net_import'
    frames.append(nx_long)

    tidy = pd.concat(frames, ignore_index=True)
    tidy = tidy.dropna(subset=['value'])
    tidy['hour'] = tidy['datetime'].dt.hour
    tidy['year'] = tidy['datetime'].dt.year
    tidy['month'] = tidy['datetime'].dt.month
    tidy['is_weekend'] = tidy['datetime'].dt.dayofweek >= 5

    print(f"Tidy frame: {len(tidy):,} rows, years {tidy['year'].min()}-{tidy['year'].max()}")
    return tidy


# ----- aggregation ----------------------------------------------------------

def hourly_stack(tidy: pd.DataFrame, zones, year: int, months,
                 is_weekend) -> pd.DataFrame:
    """Mean MW by (hour, fuel). Per-hour first sums zones into a single time series.

    is_weekend: True/False filters to weekend/weekday; None (or 'all') uses every day of the week.
    """
    mask = (
        tidy['zone'].isin(zones)
        & (tidy['year'] == year)
        & tidy['month'].isin(months)
    )
    if is_weekend is not None:
        mask &= (tidy['is_weekend'] == is_weekend)
    sub = tidy[mask]
    if sub.empty:
        return pd.DataFrame(columns=['hour', 'fuel', 'value'])

    # Sum zones per timestamp & fuel, then average across timestamps by hour-of-day
    summed = (sub.groupby(['datetime', 'hour', 'fuel'], as_index=False)['value']
                 .sum())
    out = (summed.groupby(['hour', 'fuel'], as_index=False)['value']
                 .mean())
    return out


def _add_stack_traces(fig: go.Figure, df: pd.DataFrame, col: int, showlegend: bool) -> None:
    """Add stacked-area traces for one panel (one year) of the side-by-side comparison."""
    if df.empty:
        return
    pivot = df.pivot(index='hour', columns='fuel', values='value').reindex(range(24)).fillna(0)

    # Generation stack (bottom -> top), all positive values share stackgroup='gen'
    for fuel in STACK_ORDER:
        if fuel not in pivot.columns:
            continue
        fig.add_trace(go.Scatter(
            x=pivot.index,
            y=pivot[fuel].values,
            name=fuel,
            legendgroup=fuel,
            showlegend=showlegend,
            mode='lines',
            line=dict(width=0.5, color=FUEL_COLORS[fuel]),
            fillcolor=FUEL_COLORS[fuel],
            stackgroup='gen',
            hovertemplate='%{y:,.0f} MW<extra>%{fullData.name}</extra>',
        ), row=1, col=col)

    # Net flows: imports (positive) stack above generation, exports (negative) in their own group below 0
    if 'net_import' in pivot.columns:
        net = pivot['net_import']
        imports = net.clip(lower=0)
        exports = net.clip(upper=0)
        if (imports > 0).any():
            fig.add_trace(go.Scatter(
                x=pivot.index,
                y=imports.values,
                name='net_import',
                legendgroup='net_import',
                showlegend=showlegend,
                mode='lines',
                line=dict(width=0.5, color=FUEL_COLORS['net_import']),
                fillcolor=FUEL_COLORS['net_import'],
                stackgroup='gen',
                hovertemplate='%{y:,.0f} MW<extra>imports</extra>',
            ), row=1, col=col)
        if (exports < 0).any():
            fig.add_trace(go.Scatter(
                x=pivot.index,
                y=exports.values,
                name='net_export',
                legendgroup='net_export',
                showlegend=showlegend,
                mode='lines',
                line=dict(width=0.5, color=FUEL_COLORS['net_export']),
                fillcolor=FUEL_COLORS['net_export'],
                stackgroup='exp',
                hovertemplate='%{y:,.0f} MW<extra>exports</extra>',
            ), row=1, col=col)

    # Consumption: overlay as a line (no fill, no stackgroup) so it can be visually
    # compared against the top of the generation stack.
    if 'consumption' in pivot.columns and (pivot['consumption'].abs() > 0).any():
        fig.add_trace(go.Scatter(
            x=pivot.index,
            y=pivot['consumption'].values,
            name='consumption',
            legendgroup='consumption',
            showlegend=showlegend,
            mode='lines',
            line=dict(color=FUEL_COLORS['consumption'], width=2.5, dash='dot'),
            hovertemplate='%{y:,.0f} MW<extra>consumption</extra>',
        ), row=1, col=col)


def make_stacked_area_pair(df1: pd.DataFrame, df2: pd.DataFrame,
                           title1: str, title2: str) -> go.Figure:
    """Side-by-side stacked-area generation profile, shared y-axis for fair comparison."""
    fig = make_subplots(
        rows=1, cols=2,
        shared_yaxes=True,
        subplot_titles=(title1, title2),
        horizontal_spacing=0.04,
    )
    _add_stack_traces(fig, df1, col=1, showlegend=True)
    _add_stack_traces(fig, df2, col=2, showlegend=False)

    fig.update_xaxes(title_text='Hour of day', dtick=2, tickmode='linear', row=1, col=1)
    fig.update_xaxes(title_text='Hour of day', dtick=2, tickmode='linear', row=1, col=2)
    fig.update_yaxes(title_text='Mean MW', col=1, zeroline=True, zerolinecolor='#444')
    fig.update_yaxes(zeroline=True, zerolinecolor='#444', col=2)

    fig.update_layout(
        height=560,
        margin=dict(l=60, r=20, t=70, b=50),
        legend=dict(traceorder='reversed'),  # legend top->bottom mirrors visual stack top->bottom
        hovermode='x unified',
        plot_bgcolor='#fff',
    )
    return fig


def hourly_by_year(tidy: pd.DataFrame, zones, fuel: str, months,
                   is_weekend) -> pd.DataFrame:
    """Mean MW by (year, hour) for a single fuel — sums zones at each timestamp first.

    is_weekend: True/False filters to weekend/weekday; None uses every day of the week.
    """
    mask = (
        tidy['zone'].isin(zones)
        & (tidy['fuel'] == fuel)
        & tidy['month'].isin(months)
    )
    if is_weekend is not None:
        mask &= (tidy['is_weekend'] == is_weekend)
    sub = tidy[mask]
    if sub.empty:
        return pd.DataFrame(columns=['year', 'hour', 'value'])
    summed = (sub.groupby(['datetime', 'year', 'hour'], as_index=False)['value']
                 .sum())
    out = (summed.groupby(['year', 'hour'], as_index=False)['value']
                 .mean())
    return out


# Per-fuel YoY grid: 2 rows x 5 cols.
# Row 1 = variable / flow:    renewables  + hydro     + net flows
# Row 2 = thermal:            must-run baseload -> flexible gas
PER_FUEL_GRID = [
    ['solar', 'wind', 'hydro_ror', 'hydro_res', 'net_import'],
    ['nuclear', 'lignite', 'coal', 'biomass', 'gas'],
]
YEAR_PALETTE = ['#2E86AB', '#5DADE2', '#48C9B0', '#82C341', '#F4D03F',
                '#F39C12', '#E67E22', '#C0392B', '#8E44AD']


def make_per_fuel_yoy_grid(tidy: pd.DataFrame, zones, months, is_weekend: bool,
                           region_label: str, period_label: str, daytype_label: str) -> go.Figure:
    """One subplot per fuel; within each subplot one line per year."""
    rows = len(PER_FUEL_GRID)
    cols = len(PER_FUEL_GRID[0])
    titles = [f.replace('_', ' ').title() for row in PER_FUEL_GRID for f in row]
    fig = make_subplots(
        rows=rows, cols=cols,
        subplot_titles=titles,
        horizontal_spacing=0.04,
        vertical_spacing=0.16,
    )

    today_year = dt.date.today().year
    legend_shown = False
    for r, row_fuels in enumerate(PER_FUEL_GRID, start=1):
        for c, fuel in enumerate(row_fuels, start=1):
            df = hourly_by_year(tidy, zones, fuel, months, is_weekend)
            if df.empty:
                continue
            pivot = df.pivot(index='hour', columns='year', values='value').reindex(range(24))
            years = sorted(pivot.columns.tolist())
            for i, y in enumerate(years):
                color = YEAR_PALETTE[i % len(YEAR_PALETTE)]
                is_current = (y == today_year)
                fig.add_trace(go.Scatter(
                    x=pivot.index,
                    y=pivot[y].values,
                    name=str(y),
                    legendgroup=str(y),
                    showlegend=(not legend_shown),
                    mode='lines',
                    line=dict(color=color, width=2.6 if is_current else 1.5),
                    hovertemplate='%{y:,.0f} MW<extra>%{fullData.name}</extra>',
                ), row=r, col=c)
            legend_shown = True

    fig.update_xaxes(dtick=4, tickmode='linear', title_text='Hour')
    fig.update_yaxes(title_text='MW', col=1)
    for sub_col in range(2, cols + 1):
        fig.update_yaxes(title_text=None, col=sub_col)

    fig.update_layout(
        title=f"Hourly profile by year — {region_label} — {period_label} ({daytype_label})",
        height=640,
        margin=dict(l=60, r=20, t=80, b=50),
        legend=dict(title='Year', orientation='v'),
        hovermode='x unified',
        plot_bgcolor='#fff',
    )
    return fig


def make_consumption_yoy(tidy: pd.DataFrame, zones, months, is_weekend,
                         region_label: str, period_label: str, daytype_label: str) -> go.Figure:
    """Single-panel hourly consumption profile, one line per year."""
    df = hourly_by_year(tidy, zones, 'consumption', months, is_weekend)
    fig = go.Figure()
    title = f"Consumption — {region_label} — {period_label} ({daytype_label}) — by year"
    if df.empty:
        fig.update_layout(title=f"{title} (no data)", height=420)
        return fig
    pivot = df.pivot(index='hour', columns='year', values='value').reindex(range(24))
    today_year = dt.date.today().year
    for i, y in enumerate(sorted(pivot.columns.tolist())):
        color = YEAR_PALETTE[i % len(YEAR_PALETTE)]
        is_current = (y == today_year)
        fig.add_trace(go.Scatter(
            x=pivot.index,
            y=pivot[y].values,
            name=str(y),
            mode='lines',
            line=dict(color=color, width=2.6 if is_current else 1.5),
            hovertemplate='%{y:,.0f} MW<extra>%{fullData.name}</extra>',
        ))
    fig.update_layout(
        title=title,
        xaxis=dict(title='Hour of day', dtick=1, tickmode='linear'),
        yaxis=dict(title='Mean MW'),
        height=440,
        margin=dict(l=60, r=20, t=70, b=50),
        legend=dict(title='Year'),
        hovermode='x unified',
        plot_bgcolor='#fff',
    )
    return fig


# ----- app ------------------------------------------------------------------

print("Bootstrapping data cache...")
TIDY = load_all_data(DEFAULT_START_YEAR, DEFAULT_END_YEAR)
AVAILABLE_YEARS = sorted(TIDY['year'].unique().tolist())

app = Dash(__name__)
app.title = "Generation Stack — Hourly Profile"

selector_style = {'display': 'flex', 'gap': '16px', 'flexWrap': 'wrap', 'alignItems': 'flex-end',
                  'padding': '12px 16px', 'background': '#f5f5f5', 'borderBottom': '1px solid #ddd'}
control_style = {'display': 'flex', 'flexDirection': 'column', 'minWidth': '180px'}

app.layout = html.Div([
    html.Div([
        html.H2("Average Hourly Generation Stack", style={'margin': '0 16px 0 0'}),
        html.Span("Year-on-year comparison by region/country, period and weekday/weekend",
                  style={'color': '#666'}),
    ], style={'display': 'flex', 'alignItems': 'baseline', 'padding': '12px 16px',
              'borderBottom': '1px solid #222', 'background': '#fff'}),

    html.Div([
        html.Div([
            html.Label("Region / Country"),
            dcc.Dropdown(
                id='region-dd',
                options=region_options(),
                value='R:CWE',
                clearable=False,
            ),
        ], style=control_style),

        html.Div([
            html.Label("Period"),
            dcc.Dropdown(
                id='period-dd',
                options=PERIOD_OPTIONS,
                value='Q1',
                clearable=False,
            ),
        ], style=control_style),

        html.Div([
            html.Label("Year 1 (left)"),
            dcc.Dropdown(
                id='year1-dd',
                options=[{'label': str(y), 'value': y} for y in AVAILABLE_YEARS],
                value=AVAILABLE_YEARS[-2] if len(AVAILABLE_YEARS) >= 2 else AVAILABLE_YEARS[-1],
                clearable=False,
            ),
        ], style=control_style),

        html.Div([
            html.Label("Year 2 (right)"),
            dcc.Dropdown(
                id='year2-dd',
                options=[{'label': str(y), 'value': y} for y in AVAILABLE_YEARS],
                value=AVAILABLE_YEARS[-1],
                clearable=False,
            ),
        ], style=control_style),

        html.Div([
            html.Label("Day type"),
            dcc.RadioItems(
                id='daytype-rd',
                options=[{'label': 'Weekday', 'value': 'weekday'},
                         {'label': 'Weekend', 'value': 'weekend'},
                         {'label': 'Week', 'value': 'week'}],
                value='weekday',
                inline=True,
                inputStyle={'marginRight': '4px', 'marginLeft': '12px'},
            ),
        ], style=control_style),
    ], style=selector_style),

    html.Div([
        dcc.Loading(
            id='loading-pair',
            type='default',
            children=dcc.Graph(id='fig-pair'),
        ),
    ], style={'padding': '8px'}),

    html.Div([
        dcc.Loading(
            id='loading-fuel-yoy',
            type='default',
            children=dcc.Graph(id='fig-fuel-yoy'),
        ),
    ], style={'padding': '8px', 'borderTop': '1px solid #ddd'}),

    html.Div([
        dcc.Loading(
            id='loading-consumption-yoy',
            type='default',
            children=dcc.Graph(id='fig-consumption-yoy'),
        ),
    ], style={'padding': '8px', 'borderTop': '1px solid #ddd'}),
])


@app.callback(
    Output('fig-pair', 'figure'),
    Input('region-dd', 'value'),
    Input('period-dd', 'value'),
    Input('year1-dd', 'value'),
    Input('year2-dd', 'value'),
    Input('daytype-rd', 'value'),
)
def update(region_value, period_value, year1, year2, daytype):
    zones = resolve_zones(region_value)
    months = period_to_months(period_value)
    is_weekend = _resolve_is_weekend(daytype)

    region_label = region_value.split(':', 1)[1]
    if region_value.startswith('Z:'):
        region_label = ZONE_TO_COUNTRY.get(region_label, region_label.upper())

    period_label = next((o['label'] for o in PERIOD_OPTIONS if o['value'] == period_value),
                        period_value)
    daytype_label = _daytype_label(daytype)

    df1 = hourly_stack(TIDY, zones, year1, months, is_weekend)
    df2 = hourly_stack(TIDY, zones, year2, months, is_weekend)

    title1 = f"{region_label} — {period_label} {year1} ({daytype_label})"
    title2 = f"{region_label} — {period_label} {year2} ({daytype_label})"

    return make_stacked_area_pair(df1, df2, title1, title2)


@app.callback(
    Output('fig-fuel-yoy', 'figure'),
    Input('region-dd', 'value'),
    Input('period-dd', 'value'),
    Input('daytype-rd', 'value'),
)
def update_fuel_yoy(region_value, period_value, daytype):
    zones = resolve_zones(region_value)
    months = period_to_months(period_value)
    is_weekend = _resolve_is_weekend(daytype)

    region_label = region_value.split(':', 1)[1]
    if region_value.startswith('Z:'):
        region_label = ZONE_TO_COUNTRY.get(region_label, region_label.upper())
    period_label = next((o['label'] for o in PERIOD_OPTIONS if o['value'] == period_value),
                        period_value)
    daytype_label = _daytype_label(daytype)

    return make_per_fuel_yoy_grid(TIDY, zones, months, is_weekend,
                                  region_label, period_label, daytype_label)


@app.callback(
    Output('fig-consumption-yoy', 'figure'),
    Input('region-dd', 'value'),
    Input('period-dd', 'value'),
    Input('daytype-rd', 'value'),
)
def update_consumption_yoy(region_value, period_value, daytype):
    zones = resolve_zones(region_value)
    months = period_to_months(period_value)
    is_weekend = _resolve_is_weekend(daytype)

    region_label = region_value.split(':', 1)[1]
    if region_value.startswith('Z:'):
        region_label = ZONE_TO_COUNTRY.get(region_label, region_label.upper())
    period_label = next((o['label'] for o in PERIOD_OPTIONS if o['value'] == period_value),
                        period_value)
    daytype_label = _daytype_label(daytype)

    return make_consumption_yoy(TIDY, zones, months, is_weekend,
                                region_label, period_label, daytype_label)


if __name__ == '__main__':
    app.run(debug=False, port=8050)
