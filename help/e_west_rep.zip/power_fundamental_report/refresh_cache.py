"""
Script to refresh/download the cache for CEE zone variables.
This will force a re-download from Energy Quantified.
"""

import sys
from datetime import date
import pandas as pd

# Add commodity-data-cache to path
sys.path.insert(0, r'C:\Users\Michael.Kane\OneDrive - Jain Global\Projects\commodity-data-cache')

from commodity.power.data.loader import DataLoader


def main():
    print("="*80)
    print(" REFRESHING CACHE FOR CEE ZONES")
    print("="*80)
    
    zones = ['cz', 'hu', 'pl']
    start_date = date(2020, 1, 1)
    end_date = date(2026, 12, 31)
    
    print(f"\nZones: {zones}")
    print(f"Date range: {start_date} to {end_date}")
    
    # Create loader with auto_download=True and save_to_cache=True
    loader = DataLoader(
        start_date=start_date,
        end_date=end_date,
        cache_strategy='local_first',
        column_format='multiindex',
        auto_download=True,    # Download from EQ if not in cache
        save_to_cache=True,    # Save to cache after download
        show_metadata=True,
        enable_parallel=False  # Sequential for reliability
    )
    
    # Variables to refresh
    variables = [
        # Core variables
        'consumption',
        'wind',
        'solar',
        'nuclear_gen',
        'gas_gen',
        'coal_gen',
        'lignite_gen',
        'biomass_gen',
        # Hydro
        'hydro_total',
        'hydro_ror',
        'hydro_res',
        'hydro_res_fill',
        'hydro_balance',
        # Normal/forecast
        'consumption_normal',
        'wind_normal',
        'solar_normal',
        # REMIT availability
        'nuclear_avail',
        'gas_avail',
        'coal_avail',
        'lignite_avail',
        'biomass_avail',
    ]
    
    results = {}
    
    for var in variables:
        print(f"\n{'='*60}")
        print(f"Loading/Refreshing: {var}")
        print('='*60)
        
        try:
            df = loader.load([(var, {'zones': zones})])
            
            if df is not None and not df.empty:
                if isinstance(df.columns, pd.MultiIndex):
                    zones_loaded = df.columns.get_level_values(1).unique().tolist()
                else:
                    zones_loaded = df.columns.tolist()
                
                print(f"  [OK] Loaded {len(df)} rows for zones: {zones_loaded}")
                results[var] = ('OK', len(df), zones_loaded)
            else:
                print(f"  [EMPTY] No data returned")
                results[var] = ('EMPTY', 0, [])
                
        except Exception as e:
            print(f"  [ERROR] {type(e).__name__}: {e}")
            results[var] = ('ERROR', 0, str(e)[:50])
    
    # Summary
    print("\n" + "="*80)
    print(" SUMMARY")
    print("="*80)
    
    success = [v for v, r in results.items() if r[0] == 'OK']
    failed = [v for v, r in results.items() if r[0] != 'OK']
    
    print(f"\nSuccessful ({len(success)}/{len(variables)}):")
    for var in success:
        status, rows, zones_info = results[var]
        print(f"  ✓ {var}: {rows} rows, zones: {zones_info}")
    
    print(f"\nFailed ({len(failed)}/{len(variables)}):")
    for var in failed:
        status, rows, info = results[var]
        print(f"  ✗ {var}: {status} - {info}")


if __name__ == '__main__':
    main()
