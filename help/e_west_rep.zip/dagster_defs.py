"""
Dagster Definitions for EU Reports

This module defines Dagster assets for automated report generation.

Usage:
    1. Install eu_reports in editable mode: pip install -e .
    2. Run from eu_commods_pipelines: dagster dev -w workspace.yaml
    3. Or directly: dagster dev -f dagster_defs.py

Scheduled Assets:
    - power_price_report: PDF with forward curves and spot analysis (09:00 AM UK, Mondays only)
    - power_fundamental_report: PDF with power market fundamentals analysis (09:00 AM UK, Mondays only)
    - power_flowbased_report: PDF with CORE FBMC flow, maxbex, net position analysis (09:00 AM UK, Mondays only)
    - metdesk_weather_report: HTML email with temperature, wind, solar, precipitation (07:30 AM UK, Mon-Fri)
    - news_report: AI-summarized commodity news from Platts/SPGCI (06:40 AM UK, Mon-Fri)
    - eex_settlement_report: HTML email with EEX settles, changes and volumes per strip/country (08:00 AM UK, Mon-Fri)

Sensors:
    - metdesk_new_issue_sensor: Monitors MetDesk for new weather model runs
    - transmission_outage_sensor: Monitors UK interconnector outages (polls every 10 min)

Scheduled Jobs:
    - power_availability_alert: Monitors REMIT power plant capacity changes (runs every 5 min, 07:00-17:00 UK, Mon-Fri)
"""

# MUST be before ANY other imports that might use matplotlib
# Prevents "main thread is not in main loop" errors when sensors run in background threads
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend, no Tkinter

import os
from pathlib import Path
from datetime import timedelta

# Default enablement behavior:
# - In production, sensors should come up RUNNING automatically.
# - In local/dev, keep sensors STOPPED to avoid surprise API calls/emails.
def _is_production_env() -> bool:
    return os.environ.get("DAGSTER_ENV", "local").strip().lower() == "production"

# Load .env file from eu_commods_pipelines if running from workspace
def _load_env():
    """Load .env file from common locations."""
    from dotenv import load_dotenv
    
    search_paths = [
        Path.cwd() / ".env",  # Current directory
        Path.cwd().parent / "eu_commods_pipelines" / ".env",
        Path(__file__).parent.parent / "eu_commods_pipelines" / ".env",
        Path(r"C:\Users\Michael.Kane\OneDrive - Jain Global\Projects\eu_commods_pipelines\.env"),
    ]
    
    for env_path in search_paths:
        if env_path.exists():
            load_dotenv(env_path)
            print(f"Loaded environment from: {env_path}")
            return
    
    # Also try loading from current directory's .env
    load_dotenv()

_load_env()

# Import Dagster components from corelib
try:
    from jain_commods.core.util.dagster import (
        asset, Definitions, MetadataValue, AutomationCondition,
        get_email_receivers, is_email_dry_run, is_bloomberg_on_server,
        teams_failure_hook, get_alerting_hooks,
        DAGSTER_AVAILABLE
    )
    from dagster import AssetKey, DefaultSensorStatus, DefaultScheduleStatus, FreshnessPolicy, RetryPolicy, Backoff, schedule, RunRequest, SkipReason  # For cross-location asset dependencies
    HOOKS_AVAILABLE = True
except ImportError:
    # Fallback if corelib dagster module not available
    from dagster import asset, Definitions, MetadataValue, AssetKey, AutomationCondition, DefaultSensorStatus, DefaultScheduleStatus, FreshnessPolicy, RetryPolicy, Backoff, schedule, RunRequest, SkipReason
    DAGSTER_AVAILABLE = True
    HOOKS_AVAILABLE = False
    teams_failure_hook = None
    
    def get_alerting_hooks():
        return set()
    
    def get_email_receivers(default: str) -> str:
        return os.environ.get("EMAIL_OVERRIDE", default)
    
    def is_email_dry_run() -> bool:
        return os.environ.get("EMAIL_DRY_RUN", "false").lower() == "true"
    
    def is_bloomberg_on_server() -> bool:
        return os.environ.get("BLOOMBERG_ON_SERVER", "true").lower() == "true"

# Compute once so all sensors are consistent.
DEFAULT_SENSOR_STATUS = (
    DefaultSensorStatus.RUNNING if _is_production_env() else DefaultSensorStatus.STOPPED
)

# Compute once so all schedules are consistent.
DEFAULT_SCHEDULE_STATUS = (
    DefaultScheduleStatus.RUNNING if _is_production_env() else DefaultScheduleStatus.STOPPED
)

# 8:35 AM UK time, weekdays only (Mon-Fri)
WEEKDAY_MORNING_UK = AutomationCondition.on_cron("35 8 * * 1-5", cron_timezone="Europe/London")

# 9:00 AM UK time, Mondays only
MONDAY_MORNING_UK = AutomationCondition.on_cron("0 9 * * 1", cron_timezone="Europe/London")

# 6:30 AM UK time, Mondays only
MONDAY_630_AM_UK = AutomationCondition.on_cron("30 6 * * 1", cron_timezone="Europe/London")


# =============================================================================
# System Configuration Asset
# =============================================================================

@asset(
    group_name="system",
    description="System Configuration Info - Shows current environment, config file, and email settings",
    compute_kind="python",
    metadata={
        "purpose": "Display current Dagster configuration",
        "refreshable": "Materialize anytime to see current config",
    }
)
def system_configuration(context) -> dict:
    """
    Display current system configuration in Dagster UI.
    
    Shows:
    - Environment (local/production)
    - Config file being used
    - Email recipients for all reports
    - Email dry run status
    
    Materialize this asset anytime to check what configuration is active.
    """
    from jain_commods.core.util.dagster.config import (
        get_config, get_environment, get_report_email_config
    )
    
    # Get environment info
    env = get_environment()
    config = get_config()
    
    # Get email config for each report
    reports = [
        "power_price_report",
        "power_fundamental_report",
        "power_flowbased_report",
        "metdesk_weather_report",
        "news_report",
        "eex_settlement_report",
    ]
    
    email_configs = {}
    for report_name in reports:
        report_config = get_report_email_config(report_name)
        email_configs[report_name] = {
            "recipients": report_config.get("recipients", "Not configured"),
            "dry_run": report_config.get("dry_run", False)
        }
    
    # Get config file path if available
    config_file_path = os.environ.get("PIPELINE_CONFIG_PATH", "Not set (using defaults)")
    
    # Log the configuration
    context.log.info(f"Environment: {env}")
    context.log.info(f"Config file: {config_file_path}")
    for report_name, email_cfg in email_configs.items():
        context.log.info(f"{report_name}: {email_cfg['recipients']} (dry_run={email_cfg['dry_run']})")
    
    # Return metadata for Dagster UI
    metadata = {
        "environment": MetadataValue.text(env),
        "config_file": MetadataValue.text(config_file_path),
        "dagster_env_var": MetadataValue.text(os.environ.get("DAGSTER_ENV", "not set")),
        "email_override_var": MetadataValue.text(os.environ.get("EMAIL_OVERRIDE", "not set")),
    }
    
    # Add email config for each report
    for report_name, email_cfg in email_configs.items():
        metadata[f"{report_name}_recipients"] = MetadataValue.text(
            str(email_cfg['recipients'])
        )
        metadata[f"{report_name}_dry_run"] = MetadataValue.bool(
            email_cfg['dry_run']
        )
    
    return metadata


# =============================================================================
# Asset Configurations
# =============================================================================

try:
    from dagster import Config
except ImportError:
    from pydantic import BaseModel as Config


class PowerPriceReportConfig(Config):
    """Configuration for the Power Price Report asset."""
    countries: str = "DE,FR,NL,BE,ES,CH,HU"  # Comma-separated country codes
    days: int = 450  # Number of days of history to include


class LocationSpreadReportConfig(Config):
    """Configuration for the Location Spread Report asset."""
    start_date: str = "2018-01-01"  # Spot history start date


# =============================================================================
# Power Price Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="Power Price Report PDF - Multi-country forward curves and spot analysis",
    compute_kind="python",
    # Freshness: Report should be generated by 9:30 AM UK on Mondays (scheduled at 9 AM)
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="30 9 * * 1",  # Expected by 9:30 AM Monday
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "power",
        "report_type": "daily",
        "priority": "high",
        "delivery": "email",
    },
    metadata={
        "countries": "DE, FR, NL, BE, ES, CH, HU",
        "output_type": "PDF + Email",
        "data_sources": "Bloomberg, EEX, ICE, EPEX, ENTSOE"
    }
)
def power_price_report(context, config: PowerPriceReportConfig) -> dict:
    """
    Generate the Power Price Report PDF and send via email.
    
    This report includes:
    - Forward curves for power, gas, coal, carbon
    - Monthly analysis with heatmaps
    - Curve evolution charts
    - Hourly spot vs SRMC analysis
    
    Output is saved locally as a PDF file and emailed to recipients.
    Email recipients and dry-run mode are controlled by pipeline config.
    
    Config:
    - countries: Comma-separated country codes (default: DE,FR,NL,BE,ES,CH,HU)
    - days: Number of days of history (default: 450)
    """
    from datetime import datetime
    from power_price_report import run_price_report
    
    # Parse countries from config
    countries = [c.strip() for c in config.countries.split(",") if c.strip()]
    
    # Get email configuration from pipeline config
    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("power_price_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)
    
    if not recipients:
        raise ValueError("Email recipients not configured. Set 'reports.power_price_report.email.recipients' or 'email.override_receivers' in config YAML.")
    
    context.log.info(f"Countries: {countries}")
    context.log.info(f"Days of history: {config.days}")
    
    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")
    
    context.log.info("Starting Power Price Report generation...")
    
    # Output to eu_reports directory
    output_dir = os.path.dirname(os.path.abspath(__file__))
    
    result = run_price_report(
        countries=countries,
        days=config.days,
        output_dir=output_dir,
        recipients=recipients,
        dry_run=dry_run
    )
    
    context.log.info(f"Report generated: {result['output_file']}")
    context.log.info(f"Email sent: {result.get('email_sent', False)}")
    context.log.info(f"Recipients: {result.get('recipients', 'None')}")
    
    if result.get('email_sent'):
        context.log.info(f"✓ Email successfully sent to: {result['recipients']}")
    else:
        context.log.warning(f"✗ Email was NOT sent. Check stdout/stderr for details.")
    
    # Return rich metadata for Dagster UI
    return {
        "output_file": MetadataValue.path(result['output_file']),
        "countries": MetadataValue.text(", ".join(result['countries'])),
        "num_countries": MetadataValue.int(result['num_countries']),
        "days_history": MetadataValue.int(result['days']),
        "email_sent": MetadataValue.bool(result.get('email_sent', False)),
        "recipients": MetadataValue.text(result.get('recipients', '')),
        "generated_at": MetadataValue.text(datetime.now().isoformat())
    }


# =============================================================================
# MetDesk Weather Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="MetDesk Weather Reports - Temperature, Wind, Solar, Precipitation forecasts",
    compute_kind="python",
    # No automation_condition - runs via weather_report_job at 7:30 AM
    # Freshness: Report should be generated by 9:00 AM UK on weekdays
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="0 9 * * 1-5",
        lower_bound_delta=timedelta(hours=1),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "power",
        "report_type": "daily",
        "priority": "high",
        "delivery": "email",
        "data_source": "metdesk",
    },
    metadata={
        "elements": "Temperature, Wind, Solar, Precipitation",
        "output_type": "HTML Email",
        "data_sources": "MetDesk CWG API, MetDesk PowerGen API"
    }
)
def metdesk_weather_report(context) -> dict:
    """
    Generate and send MetDesk weather forecast reports.
    
    This generates separate HTML email reports for:
    - Temperature (EC-ENS, EC-AIFS-ENS, EC-Ext models)
    - Wind generation forecasts
    - Solar generation forecasts
    - Precipitation (for hydro regions)
    
    Email recipients and dry-run mode are controlled by pipeline config.
    """
    from datetime import datetime
    from power_weather_report import run_metdesk_report
    
    # Get email configuration from pipeline config
    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("metdesk_weather_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)
    
    if not recipients:
        raise ValueError("Email recipients not configured. Set 'reports.metdesk_weather_report.email.recipients' or 'email.override_receivers' in config YAML.")
    
    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Sending reports to: {recipients}")
    
    result = run_metdesk_report(
        recipients=recipients,
        dry_run=dry_run
    )
    
    context.log.info(f"Generated {result['num_elements']} weather reports")
    
    # Return rich metadata for Dagster UI
    return {
        "elements": MetadataValue.text(", ".join(result['elements'])),
        "num_elements": MetadataValue.int(result['num_elements']),
        "recipients": MetadataValue.text(result['recipients']),
        "dry_run": MetadataValue.bool(result['dry_run']),
        "generated_at": MetadataValue.text(result['generated_at'])
    }


# =============================================================================
# News Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="Morning News Summary - AI-summarized commodity news from Platts/SPGCI",
    compute_kind="python",
    # automation_condition=WEEKDAY_MORNING_UK,  # Removed to consolidate at 7:00 AM
    # Freshness: Report should be generated by 9:00 AM UK on weekdays
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="0 9 * * 1-5",
        lower_bound_delta=timedelta(hours=1),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "research",
        "report_type": "daily",
        "priority": "medium",
        "delivery": "email",
        "data_source": "spgci",
    },
    metadata={
        "categories": "Power, Gas, Oil, Coal, Emissions, LNG, Metals",
        "output_type": "HTML Email",
        "data_sources": "SPGCI Insights API, OpenAI GPT-4"
    }
)
def news_report(context) -> dict:
    """
    Generate and send the Morning News Summary.
    
    This fetches commodity news from Platts/SPGCI, summarizes it with GPT-4,
    and sends an HTML email.
    
    On Mondays, looks back 3 days (to cover the weekend).
    On other days, looks back 1 day.
    """
    from datetime import datetime
    from news_report import run_news_report
    
    # Get email configuration from pipeline config
    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("news_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)
    
    if not recipients:
        raise ValueError("Email recipients not configured. Set 'reports.news_report.email.recipients' or 'email.override_receivers' in config YAML.")
    
    # Determine days_back based on day of week (Monday = 0)
    today = datetime.now()
    if today.weekday() == 0:  # Monday
        days_back = 3
        context.log.info("Today is Monday - looking back 3 days to cover weekend")
    else:
        days_back = 1
        context.log.info(f"Looking back {days_back} day(s)")
    
    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")
    
    result = run_news_report(
        days_back=days_back,
        recipients=recipients,
        dry_run=dry_run
    )
    
    context.log.info(f"Fetched {result.get('total_stories_fetched', 0)} stories")
    context.log.info(f"Summarized {result.get('total_stories_summarized', 0)} stories")
    context.log.info(f"Email sent: {result.get('email_sent', False)}")
    
    # Return rich metadata for Dagster UI
    return {
        "status": MetadataValue.text(result.get('status', 'unknown')),
        "days_back": MetadataValue.int(result.get('days_back', 0)),
        "total_stories_fetched": MetadataValue.int(result.get('total_stories_fetched', 0)),
        "total_stories_summarized": MetadataValue.int(result.get('total_stories_summarized', 0)),
        "email_sent": MetadataValue.bool(result.get('email_sent', False)),
        "recipients": MetadataValue.text(result.get('recipients', '')),
        "generated_at": MetadataValue.text(datetime.now().isoformat())
    }


# =============================================================================
# MetDesk Issue Sensor - Monitors for new model runs
# =============================================================================

try:
    from dagster import sensor, RunRequest, SkipReason, SensorEvaluationContext
    SENSOR_AVAILABLE = True
except ImportError:
    SENSOR_AVAILABLE = False

if SENSOR_AVAILABLE:
    import json as _json
    
    # Models to monitor
    METDESK_MODELS = {
        "eceps": "EC-ENS",
        "ecaifsens": "EC-AIFS-ENS", 
        "gfsens": "GFS-ENS",
        "ec46": "EC-Extended"
    }
    
    @sensor(
        minimum_interval_seconds=180,  # Check every 3 minutes
        description="Monitors MetDesk API for new model runs (EC-ENS, EC-AIFS-ENS, GFS-ENS, EC-Extended) and sends Teams notifications",
        default_status=DEFAULT_SENSOR_STATUS,
    )
    def metdesk_new_issue_sensor(context: SensorEvaluationContext):
        """
        Sensor that checks for new MetDesk model issues every 3 minutes.
        Uses Dagster cursor to track state (visible in UI).
        """
        import requests
        
        # Import config functions with fallback
        try:
            from jain_commods.core.util.dagster.config import get_teams_webhook_url, get_environment
        except ImportError:
            # Fallback if jain_commods.core.util.dagster.config not available
            def get_teams_webhook_url():
                env = os.environ.get("DAGSTER_ENV", "local")
                if env == "production":
                    return os.environ.get("TEAMS_WEBHOOK_URL")
                return os.environ.get("DEV_TEAMS_WEBHOOK_URL") or os.environ.get("TEAMS_WEBHOOK_URL")
            
            def get_environment():
                return os.environ.get("DAGSTER_ENV", "local")
        
        from power_weather_report.metdesk_sensor import send_teams_notification
        
        context.log.info("Checking MetDesk API for new model runs...")
        
        # Get webhook URL
        webhook_url = get_teams_webhook_url()
        env = get_environment()
        
        if webhook_url:
            masked = webhook_url[:50] + "..." if len(webhook_url) > 50 else webhook_url
            context.log.info(f"[{env.upper()}] Webhook: {masked}")
        else:
            context.log.warning("No Teams webhook URL configured!")
        
        # Load previous state from cursor
        previous_state = {}
        if context.cursor:
            try:
                previous_state = _json.loads(context.cursor)
            except:
                pass
        
        # API configuration
        api_key = os.getenv("METDESK_API_KEY")
        headers = {"Accept": "application/json", "Authorization": api_key}
        apis = [
            ("https://api.metdesk.com/get/metdesk/cwg/v2", "CWG"),
            ("https://api.metdesk.com/get/metdesk/powergen/v2", "PowerGen")
        ]
        
        # Check each model
        new_issues = []
        current_state = {}
        
        for model_code, display_name in METDESK_MODELS.items():
            for api_url, api_name in apis:
                state_key = f"{model_code}_{api_name}"
                
                try:
                    response = requests.get(
                        f"{api_url}/issues",
                        headers=headers,
                        params={"model": model_code},
                        timeout=10
                    )
                    response.raise_for_status()
                    issues = response.json().get("data", [])
                    
                    if issues:
                        latest_issue = sorted(issues)[-1]
                        current_state[state_key] = latest_issue
                        
                        # Check if this is new
                        if previous_state.get(state_key) != latest_issue:
                            new_issues.append({
                                "display_name": display_name,
                                "issue": latest_issue,
                                "api": api_name
                            })
                            context.log.info(f"New: {display_name} ({api_name}): {latest_issue}")
                except Exception as e:
                    context.log.warning(f"Failed to check {display_name} ({api_name}): {e}")
                    # Preserve previous state on error
                    if state_key in previous_state:
                        current_state[state_key] = previous_state[state_key]
        
        # Update cursor with current state
        context.update_cursor(_json.dumps(current_state))
        
        if new_issues:
            issue_names = ", ".join([i['display_name'] for i in new_issues])
            context.log.info(f"Found {len(new_issues)} new issue(s): {issue_names}")
            
            # Send Teams notification
            if webhook_url:
                try:
                    send_teams_notification(webhook_url, new_issues)
                    context.log.info("✓ Teams notification sent successfully")
                except Exception as e:
                    context.log.error(f"Failed to send Teams notification: {e}")
            
            return SkipReason(f"Notified Teams: {issue_names}")
        else:
            context.log.info("No new issues found")
            return SkipReason("No new issues")


# =============================================================================
# FTR Calendar Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="FTR Calendar Report - Weekly summary of FTR Auctions (Mon-Sun)",
    compute_kind="python",
    # Freshness: Report should be generated by 7:00 AM UK on Mondays (scheduled at 6:30 AM)
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="0 7 * * 1",  # Expected by 7:00 AM Monday
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "power",
        "report_type": "weekly",
        "priority": "medium",
        "delivery": "email",
    },
    metadata={
        "output_type": "HTML Email",
        "data_sources": "FTR Calendar Excel"
    }
)
def ftr_calendar_report(context) -> dict:
    """
    Generate and send the FTR Calendar weekly report.
    
    This report filters the FTR Calendar Excel for auctions starting or ending
    in the current week, excluding weekly auctions.
    
    Email recipients and dry-run mode are controlled by pipeline config.
    """
    from datetime import datetime
    from ftr_calendar import run_ftr_calendar_report
    
    # Get email configuration from pipeline config
    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("ftr_calendar_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)
    
    if not recipients:
        # Fallback to default if not in config
        recipients = "michael.kane@jainglobal.com"
        context.log.warning(f"Email recipients not configured. Using default: {recipients}")
    
    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")
    
    result = run_ftr_calendar_report(
        recipients=recipients,
        dry_run=dry_run
    )
    
    context.log.info(f"Report generated for {result['num_auctions']} auctions")
    
    # Return rich metadata for Dagster UI
    return {
        "num_auctions": MetadataValue.int(result['num_auctions']),
        "email_sent": MetadataValue.bool(result.get('email_sent', False)),
        "recipients": MetadataValue.text(result.get('recipients', '')),
        "week_range": MetadataValue.text(f"{result['week_start']} to {result['week_end']}"),
        "generated_at": MetadataValue.text(datetime.now().isoformat())
    }


# =============================================================================
# Power Fundamental Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="Power Fundamental Report PDF - Multi-region power market fundamentals analysis",
    compute_kind="python",
    # Freshness: Report should be generated by 9:30 AM UK on Mondays (scheduled at 9:00 AM)
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="30 9 * * 1",  # Expected by 9:30 AM Monday
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "power",
        "report_type": "weekly",
        "priority": "medium",
        "delivery": "email",
    },
    metadata={
        "output_type": "PDF + Email",
        "data_sources": "Kpler Snowflake, Meteologica",
        "regions": "CWE, Iberia, CEE, SEE, Nordics"
    }
)
def power_fundamental_report(context) -> dict:
    """
    Generate the Power Fundamental Report PDF and send via email.
    
    This report includes:
    - Demand + Renewables charts (Residual Load, Demand, Wind, Solar)
    - Generation by Fuel Type (Nuclear, Gas, Coal, Lignite)
    - Availability by Fuel Type
    - Hydro Situation (Balance, Reservoir Filling, Total Hydro, Run-of-River)
    - Commercial Flows
    
    Output is saved locally as a PDF file and emailed to recipients.
    Email recipients and dry-run mode are controlled by pipeline config.
    """
    from datetime import datetime
    import datetime as dt
    import base64
    from power_fundamental_report.power_fundamental_report import Report
    from jain_commods.core.util.emailhelper import send_email
    
    # Get email configuration from pipeline config
    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("power_fundamental_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)
    
    if not recipients:
        recipients = "michael.kane@jainglobal.com"
        context.log.warning(f"Email recipients not configured. Using default: {recipients}")
    
    context.log.info("Starting Power Fundamental Report generation...")
    
    # Configuration - same as the main script
    start_year = 2020
    end_year = 2026
    regions = ["CWE", "Iberia", "CEE", "SEE", "Nordics"]
    
    # Output to eu_reports directory
    output_dir = os.path.dirname(os.path.abspath(__file__))
    date_str = dt.datetime.now().strftime('%Y-%m-%d')
    output_path = os.path.join(output_dir, f'Power Fundamental Report - {date_str}.pdf')
    
    context.log.info(f"Regions: {regions}")
    context.log.info(f"Year range: {start_year} to {end_year}")
    context.log.info(f"Output path: {output_path}")
    
    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")
    
    # Create and generate report
    report = Report(
        start_year=start_year - 1,
        end_year=end_year,
        regions=regions,
        report_years=None,
        per_country=True
    )
    
    report.generate_pdf(output_path)
    
    context.log.info(f"Report generated: {output_path}")
    
    # Send email with PDF attachment
    email_sent = False
    report_date = dt.datetime.now().strftime('%Y-%m-%d')
    subject = f"Power Fundamental Report - {report_date}"
    body = f"""
    <html>
    <body>
    <p>Please find attached the Power Fundamental Report for {report_date}.</p>
    <p>Regions: {', '.join(regions)}</p>
    <p>Year range: {start_year} to {end_year}</p>
    <p><i>This is an automated report.</i></p>
    </body>
    </html>
    """
    
    if dry_run:
        context.log.info(f"[DRY RUN] Would send email to {recipients} with attachment {output_path}")
    else:
        try:
            context.log.info(f"Sending email to {recipients}...")
            with open(output_path, 'rb') as f:
                pdf_content = base64.b64encode(f.read()).decode('utf-8')
            
            attachment = {
                'content': pdf_content,
                'filename': os.path.basename(output_path)
            }
            
            send_email(
                recipients=recipients,
                subject=subject,
                body=body,
                attachment=attachment
            )
            context.log.info("Email sent successfully.")
            email_sent = True
        except Exception as e:
            context.log.error(f"Failed to send email: {e}")
            import traceback
            context.log.error(traceback.format_exc())
    
    # Return rich metadata for Dagster UI
    return {
        "output_file": MetadataValue.path(output_path),
        "regions": MetadataValue.text(", ".join(regions)),
        "num_regions": MetadataValue.int(len(regions)),
        "start_year": MetadataValue.int(start_year),
        "end_year": MetadataValue.int(end_year),
        "email_sent": MetadataValue.bool(email_sent),
        "recipients": MetadataValue.text(recipients),
        "generated_at": MetadataValue.text(datetime.now().isoformat())
    }


# =============================================================================
# Power Flow-Based Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="Power Flow-Based Market Report PDF - CORE FBMC flow, maxbex, net position analysis (no grid constraint)",
    compute_kind="python",
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="30 9 * * 1",  # Expected by 9:30 AM Monday
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "power",
        "report_type": "weekly",
        "priority": "medium",
        "delivery": "email",
    },
    metadata={
        "output_type": "PDF + Email",
        "data_sources": "JAO Publication Tool, ENTSOE",
        "countries": "CORE FBMC members (AT, BE, CZ, DE, FR, HR, HU, NL, PL, RO, SI, SK)"
    }
)
def power_flowbased_report(context) -> dict:
    """
    Generate the Power Flow-Based Market Report PDF and send via email.
    
    This report includes for each CORE FBMC country:
    - YoY Maxbex Analysis (Export vs Import)
    - 30-Day History (Corridor View: Flow vs Maxbex)
    - Net Position Analysis (Min/Max limits and actual)
    - Allocation Constraint Analysis (PL only)
    
    Output is saved locally as PDF and emailed to recipients.
    Email recipients and dry-run mode are controlled by pipeline config.
    """
    from datetime import datetime
    import base64
    import pandas as pd
    from power_flowbased_report.flowbased_report import DataHandler, ReportGenerator
    from jain_commods.core.util.emailhelper import send_email
    
    # Get email configuration from pipeline config
    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("power_flowbased_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)
    
    if not recipients:
        recipients = "michael.kane@jainglobal.com"
        context.log.warning(f"Email recipients not configured. Using default: {recipients}")
    
    context.log.info("Starting Power Flow-Based Report generation...")
    
    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")
    
    output_dir = os.path.dirname(os.path.abspath(__file__))
    today_str = pd.Timestamp.now().strftime("%d-%m-%Y")
    
    # Generate Flow-Based Market Report
    context.log.info("Generating Flow-Based Market Report...")
    handler = DataHandler(context=context)
    handler.hydrate_cache()
    reporter = ReportGenerator(handler)
    fb_filename = f"FBMC Report - JG - {today_str}.pdf"
    fb_output_path = os.path.join(output_dir, fb_filename)
    reporter.generate_full_report(fb_output_path)
    context.log.info(f"Flow-Based report generated: {fb_output_path}")
    
    # Send email with PDF attachment
    email_sent = False
    report_date = datetime.now().strftime('%Y-%m-%d')
    subject = f"Flow-Based Market Report - {report_date}"
    body = f"""
    <html>
    <body>
    <p>Please find attached the Flow-Based Market Report for {report_date}.</p>
    <p>Report includes: YoY Maxbex, 30-Day Flow History, Net Position Analysis for all CORE FBMC members.</p>
    <p><i>This is an automated report.</i></p>
    </body>
    </html>
    """
    
    if dry_run:
        context.log.info(f"[DRY RUN] Would send email to {recipients}")
    else:
        try:
            context.log.info(f"Sending email to {recipients}...")
            
            if os.path.exists(fb_output_path):
                with open(fb_output_path, 'rb') as f:
                    pdf_content = base64.b64encode(f.read()).decode('utf-8')
                attachment = {
                    'content': pdf_content,
                    'filename': os.path.basename(fb_output_path)
                }
                send_email(
                    recipients=recipients,
                    subject=subject,
                    body=body,
                    attachment=attachment
                )
                context.log.info("Email sent successfully.")
                email_sent = True
            else:
                context.log.error("Report file not found to attach.")
        except Exception as e:
            context.log.error(f"Failed to send email: {e}")
            import traceback
            context.log.error(traceback.format_exc())
    
    # Return rich metadata for Dagster UI
    return {
        "fb_output_file": MetadataValue.path(fb_output_path),
        "email_sent": MetadataValue.bool(email_sent),
        "recipients": MetadataValue.text(recipients),
        "generated_at": MetadataValue.text(datetime.now().isoformat())
    }


# =============================================================================
# Location Spread Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="Location Spread Report PDF - Cross-border power spread analysis for all major EU hubs",
    compute_kind="python",
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="30 9 * * 1",  # Expected by 9:30 AM Monday
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "power",
        "report_type": "weekly",
        "priority": "medium",
        "delivery": "email",
    },
    metadata={
        "hubs": "DE, FR, NL, BE, CH, IT, UK, ES, HU",
        "output_type": "PDF + Email",
        "data_sources": "EEX, ENTSOE, ForexSpot"
    }
)
def location_spread_report(context, config: LocationSpreadReportConfig) -> dict:
    """
    Generate the Location Spread Report PDF and send via email.

    This report includes for each hub country:
    - Monthly average spread heatmaps (spot + forward)
    - Calendar heatmaps of daily spot spreads (last 365 days)
    - Detailed per-border pages with forward spread structure,
      Cal+1 evolution, and spot spread heatmap

    Hubs: DE, FR, NL, BE, CH, IT, UK, ES, HU

    Config:
    - start_date: Start date for spot history (default: 2018-01-01)
    """
    from datetime import datetime
    from power_price_report.location_spread_report import run_location_spread_report

    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("location_spread_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)

    if not recipients:
        recipients = "michael.kane@jainglobal.com"
        context.log.warning(f"Email recipients not configured. Using default: {recipients}")

    context.log.info(f"Start date: {config.start_date}")

    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")

    context.log.info("Starting Location Spread Report generation...")

    output_dir = os.path.dirname(os.path.abspath(__file__))

    result = run_location_spread_report(
        output_dir=output_dir,
        recipients=recipients,
        dry_run=dry_run,
        start_date=config.start_date,
    )

    context.log.info(f"Report generated: {result['output_file']}")
    context.log.info(f"Email sent: {result.get('email_sent', False)}")

    return {
        "output_file": MetadataValue.path(result['output_file']),
        "hubs": MetadataValue.text(", ".join(result['hubs'])),
        "num_hubs": MetadataValue.int(result['num_hubs']),
        "total_borders": MetadataValue.int(result['total_borders']),
        "email_sent": MetadataValue.bool(result.get('email_sent', False)),
        "recipients": MetadataValue.text(result.get('recipients', '')),
        "generated_at": MetadataValue.text(datetime.now().isoformat())
    }


# =============================================================================
# EEX Settlement Report Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="EEX Settlement Report - Daily settles, changes and volumes per strip/country (HTML email)",
    compute_kind="python",
    # Freshness: Report should be generated by 8:30 AM UK on weekdays (scheduled at 8:00 AM)
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="30 8 * * 1-5",  # Expected by 8:30 AM Mon-Fri
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "power",
        "report_type": "daily",
        "priority": "medium",
        "delivery": "email",
    },
    metadata={
        "output_type": "HTML Email",
        "data_sources": "EEX (Snowflake)",
    }
)
def eex_settlement_report(context) -> dict:
    """
    Generate and send the daily EEX Power Settlement report.

    One table with a row per strip (Day/Weekend/Week/Month/Quarter/Year contracts)
    and a Setl./Chg./Vol. column block per country, heatmapped, T-1 vs T-2.

    Email recipients and dry-run mode are controlled by pipeline config.
    """
    from datetime import datetime
    from power_eex_report import run_eex_report

    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("eex_settlement_report")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)

    if not recipients:
        recipients = "michael.kane@jainglobal.com"
        context.log.warning(f"Email recipients not configured. Using default: {recipients}")

    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")

    result = run_eex_report(recipients=recipients, dry_run=dry_run)

    if result.get("status") == "no_data":
        context.log.warning("No EEX settlement data available - report skipped")
        return {
            "status": MetadataValue.text("no_data"),
            "settlement_date": MetadataValue.text(result.get("settlement_date", "")),
            "email_sent": MetadataValue.bool(False),
            "generated_at": MetadataValue.text(datetime.now().isoformat()),
        }

    context.log.info(
        f"Report generated for {result['settlement_date']} "
        f"({result['num_strips']} strips, countries: {result['countries']})"
    )

    return {
        "status": MetadataValue.text(result["status"]),
        "settlement_date": MetadataValue.text(result["settlement_date"]),
        "comparison_date": MetadataValue.text(result["comparison_date"]),
        "num_strips": MetadataValue.int(result["num_strips"]),
        "countries": MetadataValue.text(result["countries"]),
        "html_path": MetadataValue.path(result["html_path"]),
        "email_sent": MetadataValue.bool(result.get("email_sent", False)),
        "recipients": MetadataValue.text(result.get("recipients", "")),
        "generated_at": MetadataValue.text(datetime.now().isoformat()),
    }


# =============================================================================
# Jobs
# =============================================================================

from dagster import define_asset_job

# Job for EEX settlement report (weekdays, 8:00 AM)
eex_settlement_report_job = define_asset_job(
    name="eex_settlement_report_job",
    selection=[eex_settlement_report],
    description="EEX Settlement Report - runs Mon-Fri at 8:00 AM UK",
    hooks=get_alerting_hooks(),  # Teams notification on failure
    tags={
        "team": "power",
        "priority": "medium",
        "schedule": "weekday_morning",
        "dagster/max_runtime": "1800",  # 30 minutes
    },
)

# Job for power price report (Mondays only)
power_price_report_job = define_asset_job(
    name="power_price_report_job",
    selection=[power_price_report],
    description="Power Price Report - runs Mondays at 9 AM UK",
    hooks=get_alerting_hooks(),  # Teams notification on failure
    tags={
        "team": "power",
        "priority": "high",
        "schedule": "monday_morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)

# Job for weather report with failure alerting
weather_report_job = define_asset_job(
    name="weather_report_job",
    selection=[metdesk_weather_report],
    description="Weather report (Mon-Fri 7:30 AM)",
    hooks=get_alerting_hooks(),  # Teams notification on failure
    tags={
        "team": "power",
        "priority": "high",
        "schedule": "morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)

# Job for news report with failure alerting
morning_news_report_job = define_asset_job(
    name="morning_news_report_job",
    selection=[news_report],
    description="Morning news report (Mon-Fri 6:40 AM)",
    hooks=get_alerting_hooks(),  # Teams notification on failure
    tags={
        "team": "power",
        "priority": "high",
        "schedule": "morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)


# Job for FTR Calendar report (Mondays only, 6:30 AM)
ftr_calendar_report_job = define_asset_job(
    name="ftr_calendar_report_job",
    selection=[ftr_calendar_report],
    description="FTR Calendar Report - runs Mondays at 6:30 AM UK",
    hooks=get_alerting_hooks(),  # Teams notification on failure
    tags={
        "team": "power",
        "priority": "medium",
        "schedule": "monday_morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)

# Job for power fundamental report (Mondays only, 8:00 AM)
power_fundamental_report_job = define_asset_job(
    name="power_fundamental_report_job",
    selection=[power_fundamental_report],
    description="Power Fundamental Report - runs Mondays at 9:00 AM UK",
    hooks=get_alerting_hooks(),  # Teams notification on failure
    tags={
        "team": "power",
        "priority": "medium",
        "schedule": "monday_morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)

# Job for power flow-based report (Mondays only, 8:00 AM)
power_flowbased_report_job = define_asset_job(
    name="power_flowbased_report_job",
    selection=[power_flowbased_report],
    description="Power Flow-Based Report - runs Mondays at 9:00 AM UK",
    hooks=get_alerting_hooks(),
    tags={
        "team": "power",
        "priority": "medium",
        "schedule": "monday_morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)

# Job for location spread report (Mondays only, 9:00 AM - same as power price report)
location_spread_report_job = define_asset_job(
    name="location_spread_report_job",
    selection=[location_spread_report],
    description="Location Spread Report - runs Mondays at 9:00 AM UK",
    hooks=get_alerting_hooks(),
    tags={
        "team": "power",
        "priority": "medium",
        "schedule": "monday_morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)


# =============================================================================
# Transmission Outage Sensor
# =============================================================================

try:
    from power_transmission_alert.transmission_sensor import create_transmission_outage_sensor
    transmission_outage_sensor = create_transmission_outage_sensor(
        minimum_interval_seconds=600,  # Check every 10 minutes
        default_status=DEFAULT_SENSOR_STATUS,
    )
    TRANSMISSION_SENSOR_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not load transmission sensor: {e}")
    transmission_outage_sensor = None
    TRANSMISSION_SENSOR_AVAILABLE = False


# =============================================================================
# Power Availability REMIT Scheduled Job + Assets
# =============================================================================
#
# Power Availability Alert: Monitors REMIT power plant capacity changes
# Runs every 5 minutes during business hours (07:00-17:00 UK, Mon-Fri)
#
# Architecture: Scheduled Job + Asset pattern
# - Main Asset: Does the check_and_alert work (no timeout issues)
# - Alert History Asset: Tracks alert history for observability
# - Scheduled Job: Runs every 5 minutes during business hours
#
# Enable in the Dagster UI under Automation > Schedules

try:
    from power_availability_alert.power_availability_alert import (
        PowerAvailabilityAlertService,
        is_business_hours,
        UK_TZ,
    )
    import os
    from datetime import datetime

    # Main Asset: Does the actual alert checking and sending
    @asset(
        group_name="alerts",
        description=(
            "Power Availability Alert - Monitors REMIT power plant capacity changes "
            "and sends email/Teams alerts when significant changes are detected. "
            "Runs every 5 minutes during business hours (07:00-17:10 UK, Mon-Fri)."
        ),
        compute_kind="python",
        metadata={
            "source": "Energy Quantified REMIT API",
            "data_type": "alert",
            "team": "power",
            "frequency": "Every 5 minutes during business hours",
        }
    )
    def power_availability_alert(context) -> dict:
        """
        Main asset that checks for power availability changes and sends alerts.
        
        This asset:
        - Loads state (cursor + cache file)
        - Checks aggregates first (optimization)
        - Fetches individual plants if aggregate changed
        - Calculates deltas
        - Filters by tenor thresholds
        - Sends Teams alerts (if thresholds breached)
        - Sends email alerts (if cooldown expired)
        - Updates state
        - Returns summary for alert history asset
        """
        import traceback
        from pathlib import Path
        
        # Check business hours (skip if outside)
        if not is_business_hours():
            context.log.info("Outside business hours - skipping check")
            return {
                "skipped": True,
                "reason": "Outside business hours",
                "alerts_sent": 0,
                "teams_alerts_sent": 0,
            }
        
        # Get recipients
        email_recipients = None
        try:
            from jain_commods.core.util.dagster.config import get_email_receivers
            email_recipients = get_email_receivers(default=None)
        except ImportError:
            pass
        
        if not email_recipients:
            email_recipients = os.getenv("POWER_AVAILABILITY_ALERT_RECIPIENTS")
        if not email_recipients:
            email_recipients = "michael.kane@jainglobal.com"  # Fallback
        
        context.log.info(f"Starting power availability check, recipients: {email_recipients}")
        
        # All alert state lives in the service's own state file (atomic, locked).
        try:
            from power_availability_alert.availability_sensor import DagsterPowerAvailabilityService
            service = DagsterPowerAvailabilityService(context, email_recipients)
        except Exception as e:
            context.log.error(f"Failed to initialize service: {e}")
            context.log.error(traceback.format_exc())
            return {
                "error": str(e),
                "alerts_sent": 0,
                "teams_alerts_sent": 0,
            }
        
        # Run the check
        try:
            summary = service.check_and_alert()
        except Exception as e:
            context.log.error(f"Error during check: {e}")
            context.log.error(traceback.format_exc())
            return {
                "error": str(e),
                "alerts_sent": 0,
                "teams_alerts_sent": 0,
            }
        
        # Log summary
        timing = summary.get("timing", {})
        alerts_sent = summary.get("alerts_sent", 0)
        teams_alerts_sent = summary.get("teams_alerts_sent", 0)
        
        context.log.info(
            f"Check complete in {timing.get('total', 0):.1f}s. "
            f"Aggregates: {summary.get('aggregates_checked', 0)}, "
            f"Units: {summary.get('units_checked', 0)}, "
            f"Changes: {summary.get('curves_with_changes', 0)}, "
            f"Alerts: {alerts_sent} email, {teams_alerts_sent} Teams"
        )
        
        # Return summary for alert history asset
        return {
            "alert_timestamp": datetime.now(UK_TZ).isoformat(),
            "alerts_sent": alerts_sent,
            "teams_alerts_sent": teams_alerts_sent,
            "aggregates_checked": summary.get("aggregates_checked", 0),
            "units_checked": summary.get("units_checked", 0),
            "curves_with_changes": summary.get("curves_with_changes", 0),
            "alert_details": summary.get("alert_details", []),
            "teams_breaches": summary.get("teams_breaches", []),
            "timing": timing,
            "skipped": False,
        }
    
    # Alert History Asset: Stores metadata about alerts sent
    @asset(
        group_name="alerts",
        description=(
            "Power Availability Alert History - Tracks all alerts sent. "
            "Materialized after each alert check. Provides observability and queryability."
        ),
        compute_kind="python",
        metadata={
            "source": "Power Availability Alert Asset",
            "data_type": "alert_history",
            "team": "power",
        }
    )
    def power_availability_alert_history(context, power_availability_alert) -> dict:
        """
        Asset that stores alert history metadata.
        
        Materialized after each alert check (via dependency on power_availability_alert).
        Stores: timestamp, breach details, changes count, timing metrics.
        
        Gets alert data from the main asset's output.
        
        Returns:
            Dict with alert metadata for Dagster UI display
        """
        from datetime import datetime
        
        # Timezone for timestamps
        try:
            from zoneinfo import ZoneInfo
            UK_TZ = ZoneInfo("Europe/London")
        except ImportError:
            import pytz
            UK_TZ = pytz.timezone("Europe/London")
        
        # Extract alert metadata from main asset output
        alert_data = power_availability_alert or {}
        
        alert_timestamp = alert_data.get("alert_timestamp", datetime.now(UK_TZ).isoformat())
        alerts_sent = int(alert_data.get("alerts_sent", 0))
        teams_alerts_sent = int(alert_data.get("teams_alerts_sent", 0))
        aggregates_checked = int(alert_data.get("aggregates_checked", 0))
        units_checked = int(alert_data.get("units_checked", 0))
        curves_with_changes = int(alert_data.get("curves_with_changes", 0))
        alert_details = alert_data.get("alert_details", [])
        teams_breaches = alert_data.get("teams_breaches", [])
        timing = alert_data.get("timing", {})
        skipped = alert_data.get("skipped", False)
        
        if skipped:
            context.log.info("Alert check skipped - not recording history")
            return {
                "skipped": MetadataValue.bool(True),
                "reason": MetadataValue.text(alert_data.get("reason", "Unknown")),
            }
        
        context.log.info(
            f"Recording alert history: {alerts_sent} email alert(s), "
            f"{teams_alerts_sent} Teams alert(s), "
            f"{curves_with_changes} curves with changes"
        )
        
        # Return metadata for Dagster UI
        return {
            "alert_timestamp": MetadataValue.text(alert_timestamp),
            "alerts_sent": MetadataValue.int(alerts_sent),
            "teams_alerts_sent": MetadataValue.int(teams_alerts_sent),
            "aggregates_checked": MetadataValue.int(aggregates_checked),
            "units_checked": MetadataValue.int(units_checked),
            "curves_with_changes": MetadataValue.int(curves_with_changes),
            "alert_details": MetadataValue.text(", ".join(alert_details[:5]) if alert_details else "None"),
            "teams_breaches_count": MetadataValue.int(len(teams_breaches)),
            "teams_breaches": MetadataValue.text(", ".join(teams_breaches[:5]) if teams_breaches else "None"),
            "timing_total_seconds": MetadataValue.float(float(timing.get("total", 0.0)) if timing else 0.0),
            "materialized_at": MetadataValue.text(datetime.now(UK_TZ).isoformat()),
        }
    
    # Job that materializes both assets
    power_availability_alert_job = define_asset_job(
        name="power_availability_alert_job",
        selection=[power_availability_alert, power_availability_alert_history],
        description="Check power availability and record alert history - runs every 5 minutes during business hours",
        tags={
            "team": "power",
            "frequency": "Every 5 minutes",
            "business_hours": "07:00-17:10 UK, Mon-Fri",
            "dagster/max_runtime": "3600",  # 1 hour
        },
    )
    
    # Schedule: Runs every 5 minutes during business hours
    # Note: Business hours check is also done in the asset itself as a safety measure
    @schedule(
        job=power_availability_alert_job,
        cron_schedule="*/5 * * * 1-5",  # Every 5 minutes, Mon-Fri
        execution_timezone="Europe/London",
        default_status=DEFAULT_SCHEDULE_STATUS,  # Use schedule status enum
    )
    def power_availability_alert_schedule(context):
        """
        Schedule that triggers the power availability alert job every 5 minutes.
        
        The job runs every 5 minutes, but the asset itself checks business hours
        and skips if outside 07:00-17:00 UK time.
        """
        # Check business hours before triggering
        if not is_business_hours():
            return SkipReason("Outside business hours (07:00-17:10 UK, Mon-Fri)")
        
        # Never overlap runs: a slow poll must not race the next one into a duplicate alert.
        # (The service also holds a lock file; this just avoids launching a run that would skip.)
        from dagster import DagsterRunStatus, RunsFilter
        in_flight = context.instance.get_runs(
            filters=RunsFilter(
                job_name="power_availability_alert_job",
                statuses=[DagsterRunStatus.QUEUED, DagsterRunStatus.NOT_STARTED,
                          DagsterRunStatus.STARTING, DagsterRunStatus.STARTED],
            ),
            limit=1,
        )
        if in_flight:
            return SkipReason(f"Previous run {in_flight[0].run_id[:8]} still in progress")
        
        return RunRequest()
    
    POWER_AVAILABILITY_ALERT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not load power availability alert: {e}")
    power_availability_alert = None
    power_availability_alert_history = None
    power_availability_alert_job = None
    power_availability_alert_schedule = None
    POWER_AVAILABILITY_ALERT_AVAILABLE = False


# =============================================================================
# Hormuz LNG Vessel Monitor (every 5 minutes)
# =============================================================================
# Blends Bloomberg BSRCH AIS + Kpler LNG vessel/trade data into per-vessel
# snapshots, auto-adds LNG vessels entering the Strait of Hormuz zone, and
# emails on any change vs the previous snapshot. See hormuz_vessel_monitor/.

try:
    from hormuz_vessel_monitor.monitor import run_once as _hormuz_monitor_run_once

    @asset(
        group_name="alerts",
        description=(
            "Hormuz LNG Vessel Monitor - blends Bloomberg AIS (BSRCH comdty:ship) "
            "and Kpler LNG vessel/trade data into per-vessel snapshots, auto-adds "
            "LNG vessels entering the Strait of Hormuz zone, and emails on any "
            "change vs the previous snapshot. Runs every 5 minutes."
        ),
        compute_kind="python",
        metadata={
            "source": "Bloomberg BSRCH (comdty:ship) + Kpler LNG API",
            "data_type": "alert",
            "team": "gas",
            "frequency": "Every 5 minutes",
        },
    )
    def hormuz_vessel_monitor(context) -> dict:
        """Run one Hormuz vessel monitor cycle (snapshot, diff, alert email)."""
        summary = _hormuz_monitor_run_once(log=context.log)
        context.log.info(f"Hormuz vessel monitor summary: {summary}")
        return summary

    hormuz_vessel_monitor_job = define_asset_job(
        name="hormuz_vessel_monitor_job",
        selection=[hormuz_vessel_monitor],
        description="Hormuz LNG vessel monitor - snapshot/diff/alert email, every 5 minutes",
        tags={
            "team": "gas",
            "frequency": "Every 5 minutes",
            "dagster/max_runtime": "240",  # finish well before the next 5-min run
        },
    )

    @schedule(
        job=hormuz_vessel_monitor_job,
        cron_schedule="*/5 * * * *",  # every 5 minutes, 24/7
        execution_timezone="Europe/London",
        default_status=DEFAULT_SCHEDULE_STATUS,
    )
    def hormuz_vessel_monitor_schedule(context):
        """Trigger the Hormuz vessel monitor job every 5 minutes."""
        return RunRequest()

    HORMUZ_VESSEL_MONITOR_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not load Hormuz vessel monitor: {e}")
    hormuz_vessel_monitor = None
    hormuz_vessel_monitor_job = None
    hormuz_vessel_monitor_schedule = None
    HORMUZ_VESSEL_MONITOR_AVAILABLE = False


# =============================================================================
# NWE LNG Terminal Maintenance Alert (every 30 minutes)
# =============================================================================
# Polls Commodity Essentials eugasout Out.Total for NWE LNG terminals over
# the front 12 months and emails when any terminal/day revises by >= 5 mcm/d
# vs the last-alerted schedule. See lng_nwe_maint_alert/.

try:
    from lng_nwe_maint_alert.monitor import run_once as _lng_nwe_maint_alert_run_once

    @asset(
        group_name="alerts",
        description=(
            "NWE LNG Terminal Maintenance Alert - polls Commodity Essentials "
            "eugasout (Out.Total, mcm/d of maintenance) for NWE LNG terminals "
            "over the front 12 months and emails when any terminal/day revises "
            "by at least 5 mcm/d vs the last-alerted schedule. Runs every 30 minutes."
        ),
        compute_kind="python",
        metadata={
            "source": "Commodity Essentials eugasout / eugasopdata",
            "data_type": "alert",
            "team": "gas",
            "frequency": "Every 30 minutes",
        },
    )
    def lng_nwe_maint_alert(context) -> dict:
        """Run one NWE LNG maintenance alert cycle (pull, diff, alert email)."""
        summary = _lng_nwe_maint_alert_run_once(log=context.log)
        context.log.info(f"NWE LNG maintenance alert summary: {summary}")
        return summary

    lng_nwe_maint_alert_job = define_asset_job(
        name="lng_nwe_maint_alert_job",
        selection=[lng_nwe_maint_alert],
        description="NWE LNG terminal maintenance alert - snapshot/diff/email, every 30 minutes",
        tags={
            "team": "gas",
            "frequency": "Every 30 minutes",
            "dagster/max_runtime": "240",
        },
    )

    @schedule(
        job=lng_nwe_maint_alert_job,
        cron_schedule="*/30 * * * *",  # every 30 minutes, 24/7
        execution_timezone="Europe/London",
        default_status=DEFAULT_SCHEDULE_STATUS,
    )
    def lng_nwe_maint_alert_schedule(context):
        """Trigger the NWE LNG maintenance alert job every 30 minutes."""
        return RunRequest()

    LNG_NWE_MAINT_ALERT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not load NWE LNG maintenance alert: {e}")
    lng_nwe_maint_alert = None
    lng_nwe_maint_alert_job = None
    lng_nwe_maint_alert_schedule = None
    LNG_NWE_MAINT_ALERT_AVAILABLE = False


# =============================================================================
# Pipeline capacity booking alert (every 15 minutes)
# =============================================================================
# Polls Commodity Essentials eugascapbookingpath for new publications on the
# configured pipeline assets and emails value changes from eugascapbooking.
# See pipeline_cap_booking_alert/.

try:
    from pipeline_cap_booking_alert.monitor import run_once as _pipeline_cap_booking_run_once

    @asset(
        group_name="alerts",
        description=(
            "Pipeline Capacity Booking Alert - polls Commodity Essentials "
            "eugascapbookingpath for new directional capacity bookings on the "
            "configured pipeline assets and emails the value changes versus "
            "the last snapshot. Runs every 15 minutes."
        ),
        compute_kind="python",
        metadata={
            "source": "Commodity Essentials eugascapbooking / eugascapbookingpath",
            "data_type": "alert",
            "team": "gas",
            "frequency": "Every 15 minutes",
        },
    )
    def pipeline_cap_booking_alert(context) -> dict:
        """Run one pipeline capacity booking cycle (path, diff, alert email)."""
        summary = _pipeline_cap_booking_run_once(log=context.log)
        context.log.info(f"Pipeline capacity booking alert summary: {summary}")
        return summary

    pipeline_cap_booking_alert_job = define_asset_job(
        name="pipeline_cap_booking_alert_job",
        selection=[pipeline_cap_booking_alert],
        description="Pipeline capacity booking alert - publication diff and email, every 15 minutes",
        tags={
            "team": "gas",
            "frequency": "Every 15 minutes",
            "dagster/max_runtime": "240",
        },
    )

    @schedule(
        job=pipeline_cap_booking_alert_job,
        cron_schedule="*/15 * * * *",  # every 15 minutes, 24/7
        execution_timezone="Europe/London",
        default_status=DEFAULT_SCHEDULE_STATUS,
    )
    def pipeline_cap_booking_alert_schedule(context):
        """Trigger the pipeline capacity booking alert every 15 minutes."""
        return RunRequest()

    PIPELINE_CAP_BOOKING_ALERT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not load pipeline capacity booking alert: {e}")
    pipeline_cap_booking_alert = None
    pipeline_cap_booking_alert_job = None
    pipeline_cap_booking_alert_schedule = None
    PIPELINE_CAP_BOOKING_ALERT_AVAILABLE = False


# =============================================================================
# UKMTO warning alert (every 5 minutes)
# =============================================================================
# Lists warnings from the UKMTO product API and emails when a warning number
# is new or its PDF revision changes. The first run stores a baseline only.
# See ukmto_alert/.

try:
    from ukmto_alert.monitor import run_once as _ukmto_alert_run_once

    @asset(
        group_name="alerts",
        description=(
            "UKMTO Warning Alert - polls the UKMTO warnings product API and "
            "emails when a warning number is new or its PDF revision changes. "
            "LNG notices are marked in the subject. Runs every 5 minutes."
        ),
        compute_kind="python",
        metadata={
            "source": "UKMTO product API (sccd.royalnavy.mod.uk)",
            "data_type": "alert",
            "team": "gas",
            "frequency": "Every 5 minutes",
        },
    )
    def ukmto_alert(context) -> dict:
        """Run one UKMTO warning cycle (list, diff, alert email)."""
        summary = _ukmto_alert_run_once(log=context.log)
        context.log.info(f"UKMTO warning alert summary: {summary}")
        return summary

    ukmto_alert_job = define_asset_job(
        name="ukmto_alert_job",
        selection=[ukmto_alert],
        description="UKMTO warning alert - new and revised warnings, every 5 minutes",
        tags={
            "team": "gas",
            "frequency": "Every 5 minutes",
            "dagster/max_runtime": "240",
        },
    )

    @schedule(
        job=ukmto_alert_job,
        cron_schedule="*/5 * * * *",  # every 5 minutes, 24/7
        execution_timezone="Europe/London",
        default_status=DEFAULT_SCHEDULE_STATUS,
    )
    def ukmto_alert_schedule(context):
        """Trigger the UKMTO warning alert every 5 minutes."""
        return RunRequest()

    UKMTO_ALERT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not load UKMTO warning alert: {e}")
    ukmto_alert = None
    ukmto_alert_job = None
    ukmto_alert_schedule = None
    UKMTO_ALERT_AVAILABLE = False


# =============================================================================
# Option Morning Brief Asset
# =============================================================================

@asset(
    group_name="reports_morning",
    description="Energy Options Morning Brief - Bloomberg BPIPE + Claude cross-market analysis",
    compute_kind="python",
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="0 7 * * 1-5",
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=RetryPolicy(max_retries=2, delay=60),
    tags={
        "team": "commodities",
        "report_type": "daily",
        "priority": "high",
        "delivery": "email",
        "data_source": "bloomberg_bpipe",
    },
    metadata={
        "instruments": "TTF, Brent, EUA, German Power, French Power, Gasoil, RBOB, Copper, Aluminium",
        "output_type": "HTML Email + Dashboard",
        "data_sources": "Bloomberg BPIPE, Anthropic Claude",
        "contract_depth": "Front 3M + 3Q + Cal",
    }
)
def option_morning_brief(context) -> dict:
    """
    Generate and send the Bloomberg-powered Energy Options Morning Brief.

    Pipeline: BBG BPIPE data fetch (BDH/BDP/BDS) -> metrics + percentile ranks ->
    cross-asset analysis -> Claude narration -> Plotly charts -> HTML email -> Kafka send.

    Also saves a cache file for the companion Dash dashboard.
    """
    from option_morning_brief import run_morning_brief

    from jain_commods.core.util.dagster.config import get_report_email_config
    email_config = get_report_email_config("option_morning_brief")
    recipients = email_config.get("recipients")
    dry_run = email_config.get("dry_run", False)

    if not recipients:
        recipients = "michael.kane@jainglobal.com"
        context.log.warning(f"Email recipients not configured. Using default: {recipients}")

    if dry_run:
        context.log.info(f"[DRY RUN MODE] Would send to: {recipients}")
    else:
        context.log.info(f"Will send report to: {recipients}")

    context.log.info("Starting Energy Options Morning Brief (Bloomberg BPIPE)...")

    result = run_morning_brief(
        recipients=recipients,
        dry_run=dry_run,
        on_server=is_bloomberg_on_server(),
    )

    context.log.info(f"Brief generated for {result['num_instruments']} instruments "
                     f"({result.get('total_contracts', '?')} contracts) in {result['elapsed_seconds']}s")
    context.log.info(f"Email sent: {result.get('email_sent', False)}")

    return {
        "status": MetadataValue.text(result["status"]),
        "instruments": MetadataValue.text(", ".join(result["instruments"])),
        "num_instruments": MetadataValue.int(result["num_instruments"]),
        "total_contracts": MetadataValue.int(result.get("total_contracts", 0)),
        "email_sent": MetadataValue.bool(result.get("email_sent", False)),
        "recipients": MetadataValue.text(result.get("recipients", "")),
        "elapsed_seconds": MetadataValue.float(result["elapsed_seconds"]),
        "generated_at": MetadataValue.text(result["generated_at"]),
        "data_source": MetadataValue.text(result.get("data_source", "bloomberg_bpipe")),
    }


# =============================================================================
# Platts LNG Window Report Assets (First Look + Full)
# =============================================================================
#
# Runs the platts_lng_window/platts_lng_window.py script as a subprocess so the
# existing CLI behaviour (--first_look flag, .cfg loading, internal logging,
# error emails) is preserved exactly.
#
# Schedules use Europe/London which automatically follows BST in summer and
# GMT in winter (i.e. UTC+1 BST / UTC+0 GMT) - the cron times are interpreted
# in local UK wall-clock time, so 09:05 / 09:35 local always.

def _env_for_platts_subprocess() -> dict:
    """Environment for platts_lng_window.py, including container env if the worker is filtered."""
    env = {k: v for k, v in os.environ.items() if v is not None}
    if env.get("SPGCI_USERNAME") and env.get("SPGCI_PASSWORD"):
        return env

    proc1 = Path("/proc/1/environ")
    if proc1.exists():
        try:
            for item in proc1.read_bytes().split(b"\0"):
                if not item or b"=" not in item:
                    continue
                key_b, _, val_b = item.partition(b"=")
                key = key_b.decode("utf-8", "replace")
                if key and key not in env:
                    env[key] = val_b.decode("utf-8", "replace")
        except OSError:
            pass
    return env


def _run_platts_lng_window(context, first_look: bool) -> dict:
    """Invoke the platts_lng_window script as a subprocess.

    The script is module-level (not wrapped in a function) and reads --first_look
    from sys.argv, so running it as a subprocess is the cleanest integration.
    """
    import subprocess
    import sys
    from datetime import datetime

    script_path = Path(__file__).parent / "platts_lng_window" / "platts_lng_window.py"
    cmd = [sys.executable, str(script_path)]
    if first_look:
        cmd.append("--first_look")

    mode = "first_look" if first_look else "full"
    env = _env_for_platts_subprocess()
    context.log.info(
        f"Running Platts LNG Window report ({mode}) -> {' '.join(cmd)} "
        f"(SPGCI_USERNAME set={bool(env.get('SPGCI_USERNAME'))}, "
        f"SPGCI_PASSWORD set={bool(env.get('SPGCI_PASSWORD'))})"
    )

    started_at = datetime.now()
    proc = subprocess.run(
        cmd,
        cwd=str(script_path.parent),
        capture_output=True,
        text=True,
        env=env,
    )
    elapsed = (datetime.now() - started_at).total_seconds()

    if proc.stdout:
        context.log.info(f"stdout:\n{proc.stdout}")
    if proc.stderr:
        context.log.info(f"stderr:\n{proc.stderr}")

    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        suffix = f"\n{detail}" if detail else ""
        raise RuntimeError(
            f"platts_lng_window.py ({mode}) exited with code {proc.returncode}{suffix}"
        )

    return {
        "mode": MetadataValue.text(mode),
        "exit_code": MetadataValue.int(proc.returncode),
        "elapsed_seconds": MetadataValue.float(elapsed),
        "script": MetadataValue.path(str(script_path)),
        "generated_at": MetadataValue.text(datetime.now().isoformat()),
    }


# Longer exponential backoff: Platts 502s often need a few minutes to clear.
_PLATTS_LNG_RETRY = RetryPolicy(max_retries=3, delay=120, backoff=Backoff.EXPONENTIAL)


@asset(
    group_name="reports_morning",
    description="Platts JKM LNG Window - Snapshot at window open (first look)",
    compute_kind="python",
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="10 9 * * 1-5",  # Expected by 09:10 UK
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=_PLATTS_LNG_RETRY,
    tags={
        "team": "gas_lng",
        "report_type": "daily",
        "priority": "high",
        "delivery": "teams",
        "data_source": "platts_spgci",
    },
    metadata={
        "output_type": "Teams snapshot",
        "data_sources": "Platts EWindowMarketData (ASIA LNG Physical)",
        "schedule": "Mon-Fri 09:05 Europe/London (BST/GMT)",
    },
)
def platts_lng_window_first_look(context) -> dict:
    """Platts JKM LNG window-open snapshot - runs platts_lng_window.py --first_look."""
    return _run_platts_lng_window(context, first_look=True)


@asset(
    group_name="reports_morning",
    description="Platts JKM LNG MOC - Full Physical & Derivatives summary (post-window)",
    compute_kind="python",
    freshness_policy=FreshnessPolicy.cron(
        deadline_cron="0 10 * * 1-5",  # Expected by 10:00 UK
        lower_bound_delta=timedelta(minutes=30),
        timezone="Europe/London",
    ),
    retry_policy=_PLATTS_LNG_RETRY,
    tags={
        "team": "gas_lng",
        "report_type": "daily",
        "priority": "high",
        "delivery": "email",
        "data_source": "platts_spgci",
    },
    metadata={
        "output_type": "Email + Teams",
        "data_sources": "Platts EWindowMarketData (Physical + Derivatives), Anthropic Claude",
        "schedule": "Mon-Fri 09:35 Europe/London (BST/GMT)",
    },
)
def platts_lng_window_full(context) -> dict:
    """Full Platts JKM Physical + Derivatives MOC summary - runs platts_lng_window.py."""
    return _run_platts_lng_window(context, first_look=False)


platts_lng_window_first_look_job = define_asset_job(
    name="platts_lng_window_first_look_job",
    selection=[platts_lng_window_first_look],
    description="Platts LNG window first-look snapshot - Mon-Fri 09:05 UK",
    hooks=get_alerting_hooks(),
    tags={
        "team": "gas_lng",
        "priority": "high",
        "schedule": "weekday_morning",
        "dagster/max_runtime": "1800",  # 30 min
    },
)

platts_lng_window_full_job = define_asset_job(
    name="platts_lng_window_full_job",
    selection=[platts_lng_window_full],
    description="Platts LNG full MOC summary - Mon-Fri 09:35 UK",
    hooks=get_alerting_hooks(),
    tags={
        "team": "gas_lng",
        "priority": "high",
        "schedule": "weekday_morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)


@schedule(
    job=platts_lng_window_first_look_job,
    cron_schedule="5 9 * * 1-5",  # 09:05 Mon-Fri
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def platts_lng_window_first_look_schedule(context):
    """Trigger Platts LNG first-look snapshot at 09:05 UK (BST in summer / GMT in winter)."""
    return RunRequest()


@schedule(
    job=platts_lng_window_full_job,
    cron_schedule="35 9 * * 1-5",  # 09:35 Mon-Fri
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def platts_lng_window_full_schedule(context):
    """Trigger full Platts LNG MOC summary at 09:35 UK (BST in summer / GMT in winter)."""
    return RunRequest()


# =============================================================================
# Definitions
# =============================================================================

# Build sensors list
_sensors = []
if SENSOR_AVAILABLE:
    _sensors.append(metdesk_new_issue_sensor)
if TRANSMISSION_SENSOR_AVAILABLE:
    _sensors.append(transmission_outage_sensor)

# Build assets list
_assets = [
    system_configuration,  # System info asset - shows environment and email config
    power_price_report,
    metdesk_weather_report,
    news_report,
    ftr_calendar_report,
    power_fundamental_report,
    power_flowbased_report,
    location_spread_report,
    eex_settlement_report,
    option_morning_brief,
    platts_lng_window_first_look,
    platts_lng_window_full,
]
if POWER_AVAILABILITY_ALERT_AVAILABLE:
    if power_availability_alert is not None:
        _assets.append(power_availability_alert)
    if power_availability_alert_history is not None:
        _assets.append(power_availability_alert_history)
if HORMUZ_VESSEL_MONITOR_AVAILABLE and hormuz_vessel_monitor is not None:
    _assets.append(hormuz_vessel_monitor)
if LNG_NWE_MAINT_ALERT_AVAILABLE and lng_nwe_maint_alert is not None:
    _assets.append(lng_nwe_maint_alert)
if PIPELINE_CAP_BOOKING_ALERT_AVAILABLE and pipeline_cap_booking_alert is not None:
    _assets.append(pipeline_cap_booking_alert)
if UKMTO_ALERT_AVAILABLE and ukmto_alert is not None:
    _assets.append(ukmto_alert)

# =============================================================================
# Vol Monitor (daily vol-regime & position-sizing email, 07:10 UK Mon-Fri)
# =============================================================================
# Defined in its own module so the package stays self-contained and can also
# be served standalone via `dagster dev -f vol_monitor/dagster_defs.py`.
try:
    from vol_monitor.dagster_defs import (
        vol_monitor_assets,
        vol_monitor_jobs,
        vol_monitor_schedules,
    )
    VOL_MONITOR_AVAILABLE = True
    _assets.extend(vol_monitor_assets)
except ImportError as e:
    print(f"Warning: Could not load vol_monitor: {e}")
    vol_monitor_assets, vol_monitor_jobs, vol_monitor_schedules = [], [], []
    VOL_MONITOR_AVAILABLE = False

# =============================================================================
# TA Study (Shternberg mean-reversion email, 06:55 UK Mon-Fri; stats 22:30)
# =============================================================================
# Defined in its own module so the package stays self-contained and can also
# be served standalone via `dagster dev -f ta_study/dagster_defs.py`.
try:
    from ta_study.dagster_defs import (
        ta_study_assets,
        ta_study_jobs,
        ta_study_schedules,
    )
    TA_STUDY_AVAILABLE = True
    _assets.extend(ta_study_assets)
except ImportError as e:
    print(f"Warning: Could not load ta_study: {e}")
    ta_study_assets, ta_study_jobs, ta_study_schedules = [], [], []
    TA_STUDY_AVAILABLE = False

# Build jobs list
# Job for option morning brief (weekdays, 6:30 AM)
option_morning_brief_job = define_asset_job(
    name="option_morning_brief_job",
    selection=[option_morning_brief],
    description="Energy Options Morning Brief - Bloomberg BPIPE + Claude cross-market analysis, weekdays at 6:30 AM UK",
    hooks=get_alerting_hooks(),
    tags={
        "team": "commodities",
        "priority": "high",
        "schedule": "weekday_morning",
        "dagster/max_runtime": "3600",  # 1 hour
    },
)

_jobs = [power_price_report_job, weather_report_job, morning_news_report_job, ftr_calendar_report_job, power_fundamental_report_job, power_flowbased_report_job, location_spread_report_job, eex_settlement_report_job, option_morning_brief_job, platts_lng_window_first_look_job, platts_lng_window_full_job]
if POWER_AVAILABILITY_ALERT_AVAILABLE and power_availability_alert_job is not None:
    _jobs.append(power_availability_alert_job)
if VOL_MONITOR_AVAILABLE:
    _jobs.extend(vol_monitor_jobs)
if TA_STUDY_AVAILABLE:
    _jobs.extend(ta_study_jobs)
if HORMUZ_VESSEL_MONITOR_AVAILABLE and hormuz_vessel_monitor_job is not None:
    _jobs.append(hormuz_vessel_monitor_job)
if LNG_NWE_MAINT_ALERT_AVAILABLE and lng_nwe_maint_alert_job is not None:
    _jobs.append(lng_nwe_maint_alert_job)
if PIPELINE_CAP_BOOKING_ALERT_AVAILABLE and pipeline_cap_booking_alert_job is not None:
    _jobs.append(pipeline_cap_booking_alert_job)
if UKMTO_ALERT_AVAILABLE and ukmto_alert_job is not None:
    _jobs.append(ukmto_alert_job)

# =============================================================================
# Power Price Report Schedule (Mondays only, 9 AM UK)
# =============================================================================

@schedule(
    job=power_price_report_job,
    cron_schedule="0 9 * * 1",  # 09:00 AM, Monday only
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def power_price_report_schedule(context):
    """
    Schedule that triggers the power price report at 09:00 AM UK time on Mondays only.
    """
    return RunRequest()


# =============================================================================
# Weather Report Schedule (Weekdays, 7:30 AM UK)
# =============================================================================

@schedule(
    job=weather_report_job,
    cron_schedule="30 7 * * 1-5",  # 07:30 AM, Mon-Fri
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def weather_report_schedule(context):
    """
    Schedule that triggers the weather report job at 07:30 AM UK time on weekdays.
    """
    return RunRequest()


# =============================================================================
# Morning News Report Schedule (Weekdays, 6:40 AM UK)
# =============================================================================

@schedule(
    job=morning_news_report_job,
    cron_schedule="40 6 * * 1-5",  # 06:40 AM, Mon-Fri
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def morning_news_report_schedule(context):
    """
    Schedule that triggers the morning news report job at 06:40 AM UK time on weekdays.
    """
    return RunRequest()


# =============================================================================
# FTR Calendar Report Schedule (Mondays only, 6:30 AM UK)
# =============================================================================

@schedule(
    job=ftr_calendar_report_job,
    cron_schedule="30 6 * * 1",  # 06:30 AM, Monday only
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def ftr_calendar_report_schedule(context):
    """
    Schedule that triggers the FTR calendar report at 06:30 AM UK time on Mondays only.
    """
    return RunRequest()


# =============================================================================
# Power Fundamental Report Schedule (Mondays only, 9:00 AM UK)
# =============================================================================

@schedule(
    job=power_fundamental_report_job,
    cron_schedule="0 9 * * 1",  # 09:00 AM, Monday only
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def power_fundamental_report_schedule(context):
    """
    Schedule that triggers the power fundamental report at 09:00 AM UK time on Mondays only.
    """
    return RunRequest()


# =============================================================================
# Power Flow-Based Report Schedule (Mondays only, 9:00 AM UK)
# =============================================================================

@schedule(
    job=power_flowbased_report_job,
    cron_schedule="0 9 * * 1",  # 09:00 AM, Monday only
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def power_flowbased_report_schedule(context):
    """
    Schedule that triggers the power flow-based report at 09:00 AM UK time on Mondays only.
    """
    return RunRequest()


# =============================================================================
# Location Spread Report Schedule (Mondays only, 9:00 AM UK)
# =============================================================================

@schedule(
    job=location_spread_report_job,
    cron_schedule="0 9 * * 1",  # 09:00 AM, Monday only
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def location_spread_report_schedule(context):
    """
    Schedule that triggers the location spread report at 09:00 AM UK time on Mondays only.
    """
    return RunRequest()


# =============================================================================
# EEX Settlement Report Schedule (Weekdays, 8:00 AM UK)
# =============================================================================

@schedule(
    job=eex_settlement_report_job,
    cron_schedule="0 8 * * 1-5",  # 08:00 AM, Mon-Fri
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def eex_settlement_report_schedule(context):
    """
    Schedule that triggers the EEX settlement report at 08:00 AM UK time on weekdays.
    """
    return RunRequest()


# =============================================================================
# Option Morning Brief Schedule (Weekdays, 6:30 AM UK)
# =============================================================================

@schedule(
    job=option_morning_brief_job,
    cron_schedule="30 6 * * 1-5",  # 06:30 AM, Mon-Fri
    execution_timezone="Europe/London",
    default_status=DEFAULT_SCHEDULE_STATUS,
)
def option_morning_brief_schedule(context):
    """
    Schedule that triggers the option morning brief at 06:30 AM UK time on weekdays.
    """
    return RunRequest()


# Build schedules list
_schedules = [power_price_report_schedule, weather_report_schedule, morning_news_report_schedule, ftr_calendar_report_schedule, power_fundamental_report_schedule, power_flowbased_report_schedule, location_spread_report_schedule, eex_settlement_report_schedule, option_morning_brief_schedule, platts_lng_window_first_look_schedule, platts_lng_window_full_schedule]
if POWER_AVAILABILITY_ALERT_AVAILABLE and power_availability_alert_schedule is not None:
    _schedules.append(power_availability_alert_schedule)
if VOL_MONITOR_AVAILABLE:
    _schedules.extend(vol_monitor_schedules)
if TA_STUDY_AVAILABLE:
    _schedules.extend(ta_study_schedules)
if HORMUZ_VESSEL_MONITOR_AVAILABLE and hormuz_vessel_monitor_schedule is not None:
    _schedules.append(hormuz_vessel_monitor_schedule)
if LNG_NWE_MAINT_ALERT_AVAILABLE and lng_nwe_maint_alert_schedule is not None:
    _schedules.append(lng_nwe_maint_alert_schedule)
if PIPELINE_CAP_BOOKING_ALERT_AVAILABLE and pipeline_cap_booking_alert_schedule is not None:
    _schedules.append(pipeline_cap_booking_alert_schedule)
if UKMTO_ALERT_AVAILABLE and ukmto_alert_schedule is not None:
    _schedules.append(ukmto_alert_schedule)

defs = Definitions(
    assets=_assets,
    jobs=_jobs,
    sensors=_sensors,
    schedules=_schedules,
)

