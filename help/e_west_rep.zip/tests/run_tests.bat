@echo off
REM Simple batch script to run Dagster definitions tests on Windows

cd /d "%~dp0\.."
echo Running Dagster definitions tests...
echo.

python tests\test_dagster_definitions.py

if %ERRORLEVEL% EQU 0 (
    echo.
    echo All tests passed!
) else (
    echo.
    echo Tests failed!
    exit /b %ERRORLEVEL%
)

