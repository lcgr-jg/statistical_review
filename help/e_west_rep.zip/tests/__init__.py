"""Tests for eu_reports Dagster definitions."""

