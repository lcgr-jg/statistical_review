# Dagster Definitions Tests

This test suite validates the `dagster_defs.py` file to prevent common errors that can cause Dagster to fail to load.

## What These Tests Check

1. **Syntax Validation**: Ensures `dagster_defs.py` has valid Python syntax (catches indentation errors, etc.)
2. **Schedule Status**: Verifies that `@schedule` decorators use `DefaultScheduleStatus`, not `DefaultSensorStatus`
3. **Sensor Status**: Verifies that `@sensor` decorators use `DefaultSensorStatus`, not `DefaultScheduleStatus`
4. **Asset Context Order**: Ensures that asset functions have `context` as the first parameter if present
5. **Required Imports**: Checks that `DefaultScheduleStatus` and `DefaultSensorStatus` are imported
6. **Required Constants**: Verifies that `DEFAULT_SENSOR_STATUS` and `DEFAULT_SCHEDULE_STATUS` are defined

## Running the Tests

### Using Python directly:
```bash
cd eu_reports
python tests/test_dagster_definitions.py
```

### Using pytest:
```bash
cd eu_reports
pytest tests/test_dagster_definitions.py -v
```

### Using unittest:
```bash
cd eu_reports
python -m unittest tests.test_dagster_definitions -v
```

## Common Issues These Tests Prevent

### Issue 1: Wrong Enum Type for Schedules
**Error**: `Param "default_status" is not a DefaultScheduleStatus. Got <DefaultSensorStatus.STOPPED>`

**Fix**: Use `DEFAULT_SCHEDULE_STATUS` instead of `DEFAULT_SENSOR_STATUS` in `@schedule` decorators.

### Issue 2: Wrong Parameter Order in Assets
**Error**: `"context" is not a valid name in Dagster. It conflicts with a Dagster or python reserved keyword.`

**Fix**: Put `context` as the first parameter in asset functions:
```python
# ✅ Correct
def my_asset(context, dependency) -> dict:
    ...

# ❌ Wrong
def my_asset(dependency, context) -> dict:
    ...
```

### Issue 3: Syntax/Indentation Errors
**Error**: `IndentationError: expected an indented block after 'try' statement`

**Fix**: Ensure proper indentation in try/except blocks and all code blocks.

## Adding to CI/CD

These tests should be run before deploying to catch issues early. Consider adding to your CI/CD pipeline:

```yaml
# Example GitHub Actions
- name: Test Dagster Definitions
  run: |
    cd eu_reports
    python tests/test_dagster_definitions.py
```

## Notes

- These tests use AST parsing to analyze the code structure without executing it
- They catch issues at the definition level, before Dagster tries to load the code
- Run these tests after any changes to `dagster_defs.py`

