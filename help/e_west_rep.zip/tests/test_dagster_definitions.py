"""
Tests to validate Dagster definitions and prevent common errors.

This test suite checks for:
1. Syntax/indentation errors
2. Correct use of DefaultScheduleStatus vs DefaultSensorStatus
3. Correct parameter ordering in asset functions (context should be first)
4. Import correctness
"""

import ast
import importlib.util
from pathlib import Path
import sys


def test_dagster_defs_syntax():
    """Test that dagster_defs.py has valid Python syntax."""
    dagster_defs_path = Path(__file__).parent.parent / "dagster_defs.py"
    
    # Read the file
    with open(dagster_defs_path, 'r', encoding='utf-8') as f:
        source_code = f.read()
    
    # Try to parse it as AST
    try:
        ast.parse(source_code)
    except SyntaxError as e:
        raise AssertionError(
            f"Syntax error in dagster_defs.py at line {e.lineno}: {e.msg}\n"
            f"Text: {e.text}"
        )


def test_schedule_uses_default_schedule_status():
    """Test that @schedule decorators use DefaultScheduleStatus, not DefaultSensorStatus."""
    dagster_defs_path = Path(__file__).parent.parent / "dagster_defs.py"
    
    with open(dagster_defs_path, 'r', encoding='utf-8') as f:
        source_code = f.read()
    
    # Parse AST
    tree = ast.parse(source_code)
    
    # Find all @schedule decorators
    schedule_issues = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            # Check if function has @schedule decorator
            has_schedule_decorator = False
            for decorator in node.decorator_list:
                if isinstance(decorator, ast.Call):
                    if isinstance(decorator.func, ast.Name) and decorator.func.id == 'schedule':
                        has_schedule_decorator = True
                        break
                    elif isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'schedule':
                        has_schedule_decorator = True
                        break
            
            if has_schedule_decorator:
                # Check keyword arguments for default_status
                for decorator in node.decorator_list:
                    if isinstance(decorator, ast.Call):
                        for keyword in decorator.keywords:
                            if keyword.arg == 'default_status':
                                # Check if it references DEFAULT_SENSOR_STATUS
                                if isinstance(keyword.value, ast.Name):
                                    if keyword.value.id == 'DEFAULT_SENSOR_STATUS':
                                        schedule_issues.append(
                                            f"Line {decorator.lineno}: Schedule '{node.name}' uses DEFAULT_SENSOR_STATUS. "
                                            f"Should use DEFAULT_SCHEDULE_STATUS instead."
                                        )
                                elif isinstance(keyword.value, ast.Attribute):
                                    # Check if it's DefaultSensorStatus.SOMETHING
                                    if isinstance(keyword.value.value, ast.Name):
                                        if keyword.value.value.id == 'DefaultSensorStatus':
                                            schedule_issues.append(
                                                f"Line {decorator.lineno}: Schedule '{node.name}' uses DefaultSensorStatus. "
                                                f"Should use DefaultScheduleStatus instead."
                                            )
    
    if schedule_issues:
        raise AssertionError(
            "Found schedules using DefaultSensorStatus instead of DefaultScheduleStatus:\n" +
            "\n".join(f"  - {issue}" for issue in schedule_issues)
        )


def test_sensor_uses_default_sensor_status():
    """Test that @sensor decorators use DefaultSensorStatus, not DefaultScheduleStatus."""
    dagster_defs_path = Path(__file__).parent.parent / "dagster_defs.py"
    
    with open(dagster_defs_path, 'r', encoding='utf-8') as f:
        source_code = f.read()
    
    # Parse AST
    tree = ast.parse(source_code)
    
    # Find all @sensor decorators
    sensor_issues = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            # Check if function has @sensor decorator
            has_sensor_decorator = False
            for decorator in node.decorator_list:
                if isinstance(decorator, ast.Call):
                    if isinstance(decorator.func, ast.Name) and decorator.func.id == 'sensor':
                        has_sensor_decorator = True
                        break
                    elif isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'sensor':
                        has_sensor_decorator = True
                        break
            
            if has_sensor_decorator:
                # Check keyword arguments for default_status
                for decorator in node.decorator_list:
                    if isinstance(decorator, ast.Call):
                        for keyword in decorator.keywords:
                            if keyword.arg == 'default_status':
                                # Check if it references DEFAULT_SCHEDULE_STATUS
                                if isinstance(keyword.value, ast.Name):
                                    if keyword.value.id == 'DEFAULT_SCHEDULE_STATUS':
                                        sensor_issues.append(
                                            f"Line {decorator.lineno}: Sensor '{node.name}' uses DEFAULT_SCHEDULE_STATUS. "
                                            f"Should use DEFAULT_SENSOR_STATUS instead."
                                        )
                                elif isinstance(keyword.value, ast.Attribute):
                                    # Check if it's DefaultScheduleStatus.SOMETHING
                                    if isinstance(keyword.value.value, ast.Name):
                                        if keyword.value.value.id == 'DefaultScheduleStatus':
                                            sensor_issues.append(
                                                f"Line {decorator.lineno}: Sensor '{node.name}' uses DefaultScheduleStatus. "
                                                f"Should use DefaultSensorStatus instead."
                                            )
    
    if sensor_issues:
        raise AssertionError(
            "Found sensors using DefaultScheduleStatus instead of DefaultSensorStatus:\n" +
            "\n".join(f"  - {issue}" for issue in sensor_issues)
        )


def test_asset_context_parameter_order():
    """Test that asset functions have 'context' as the first parameter if present."""
    dagster_defs_path = Path(__file__).parent.parent / "dagster_defs.py"
    
    with open(dagster_defs_path, 'r', encoding='utf-8') as f:
        source_code = f.read()
    
    # Parse AST
    tree = ast.parse(source_code)
    
    # Find all @asset decorators
    asset_issues = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            # Check if function has @asset decorator
            has_asset_decorator = False
            for decorator in node.decorator_list:
                if isinstance(decorator, ast.Call):
                    if isinstance(decorator.func, ast.Name) and decorator.func.id == 'asset':
                        has_asset_decorator = True
                        break
                    elif isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'asset':
                        has_asset_decorator = True
                        break
                elif isinstance(decorator, ast.Name) and decorator.id == 'asset':
                    has_asset_decorator = True
                    break
            
            if has_asset_decorator and node.args.args:
                # Check if 'context' is a parameter
                param_names = [arg.arg for arg in node.args.args]
                if 'context' in param_names:
                    # Check if it's the first parameter
                    if param_names[0] != 'context':
                        asset_issues.append(
                            f"Line {node.lineno}: Asset '{node.name}' has 'context' parameter but it's not first. "
                            f"Parameters: {', '.join(param_names)}. "
                            f"'context' should be the first parameter."
                        )
    
    if asset_issues:
        raise AssertionError(
            "Found assets with 'context' parameter in wrong position:\n" +
            "\n".join(f"  - {issue}" for issue in asset_issues)
        )


def test_imports_exist():
    """Test that required imports are present."""
    dagster_defs_path = Path(__file__).parent.parent / "dagster_defs.py"
    
    with open(dagster_defs_path, 'r', encoding='utf-8') as f:
        source_code = f.read()
    
    # Check for required imports
    required_imports = [
        'DefaultScheduleStatus',
        'DefaultSensorStatus',
    ]
    
    missing_imports = []
    for required_import in required_imports:
        if required_import not in source_code:
            missing_imports.append(required_import)
    
    if missing_imports:
        raise AssertionError(
            f"Missing required imports in dagster_defs.py:\n" +
            "\n".join(f"  - {imp}" for imp in missing_imports)
        )


def test_constants_defined():
    """Test that required constants are defined."""
    dagster_defs_path = Path(__file__).parent.parent / "dagster_defs.py"
    
    with open(dagster_defs_path, 'r', encoding='utf-8') as f:
        source_code = f.read()
    
    # Check for required constants
    required_constants = [
        'DEFAULT_SENSOR_STATUS',
        'DEFAULT_SCHEDULE_STATUS',
    ]
    
    missing_constants = []
    for required_constant in required_constants:
        if f'{required_constant} =' not in source_code:
            missing_constants.append(required_constant)
    
    if missing_constants:
        raise AssertionError(
            f"Missing required constants in dagster_defs.py:\n" +
            "\n".join(f"  - {const}" for const in missing_constants)
        )


if __name__ == "__main__":
    # Run tests
    import unittest
    
    class TestDagsterDefinitions(unittest.TestCase):
        def test_syntax(self):
            test_dagster_defs_syntax()
        
        def test_schedule_status(self):
            test_schedule_uses_default_schedule_status()
        
        def test_sensor_status(self):
            test_sensor_uses_default_sensor_status()
        
        def test_asset_context_order(self):
            test_asset_context_parameter_order()
        
        def test_imports(self):
            test_imports_exist()
        
        def test_constants(self):
            test_constants_defined()
    
    unittest.main(verbosity=2)

