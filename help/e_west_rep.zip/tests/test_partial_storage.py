"""Level-2 storage fallback used by the morning flows report."""
from __future__ import annotations

import pandas as pd

from common.email_tables import df_to_styled_html
from common.partial_storage import (
    PARTIAL_CELL_BG,
    PARTIAL_STORAGE_NOTE,
    apply_partial_storage,
    fetch_partial_storage_injection,
    level2_storage_signs,
    sum_signed_site_frame,
)


def _catalog():
    assets = pd.DataFrame(
        {
            "assetId": [688, 1768, 551, 552, 10, 999],
            "name": ["DE", "AT", "Bierwang", "Rehden", "Haidach", "Nested"],
            "type": ["Storage"] * 6,
            "level": [1, 1, 2, 2, 2, 3],
        }
    )
    tree = pd.DataFrame(
        {
            "parent_id": [688, 688, 1768, 551],
            "child_id": [551, 552, 10, 999],
            "sign": [1, -1, 1, 1],
        }
    )
    return assets, tree


def _opdata():
    raw = pd.DataFrame(
        {
            "DateExcel": [1, 2],
            "Date": ["28-Sep-2026", "29-Sep-2026"],
            "111": [10.0, 8.0],
            "222": [1.0, 3.0],
            "333": [1.0, 4.0],
        }
    )
    meta = pd.DataFrame(
        {
            "seriesId": ["assetId"],
            "111": [551],
            "222": [552],
            "333": [10],
        }
    )
    return raw, meta


class _FakeCE:
    def __init__(self):
        self.assets, self.tree = _catalog()
        self.raw, self.meta = _opdata()
        self.calls = []

    def eugasmeta(self, id_):
        self.calls.append(id_)
        return self.assets if id_ == "assets" else self.tree

    def eugasopdata(self, **kwargs):
        self.calls.append(kwargs)
        return self.meta if kwargs.get("meta") else self.raw


def test_level2_signs_and_signed_sum():
    assets, tree = _catalog()
    signs = level2_storage_signs(assets, tree, 688)
    assert signs == {551: 1.0, 552: -1.0}
    raw, meta = _opdata()
    total = sum_signed_site_frame(raw, meta, signs)
    assert total.loc[pd.Timestamp("2026-09-29")] == 5.0


def test_fetch_and_apply_on_report_style_index():
    ce = _FakeCE()
    frame = pd.DataFrame(
        {"AT": [1.0, None], "DE": [9.0, None]},
        index=["28-Sep-2026", "29-Sep-2026"],
    )
    partial = fetch_partial_storage_injection(
        ce, frame, asset_ids={"AT": 1768, "DE": 688},
    )
    mask = apply_partial_storage(frame, partial)
    assert frame.loc["28-Sep-2026", "DE"] == 9.0
    assert frame.loc["29-Sep-2026", "AT"] == 4.0
    assert frame.loc["29-Sep-2026", "DE"] == 5.0
    assert list(mask.index[mask["AT"]]) == ["29-Sep-2026"]
    assert list(mask.index[mask["DE"]]) == ["29-Sep-2026"]
    frame = frame.fillna(0)
    frame["Total"] = frame.sum(axis=1)

    highlight = pd.DataFrame(False, index=frame.index, columns=frame.columns)
    shown = mask.reindex(frame.index).fillna(False)
    for col in shown.columns:
        highlight[col] = shown[col].astype(bool)
    highlight["Total"] = shown.any(axis=1)
    html = df_to_styled_html(
        frame,
        precision=0,
        highlight_weekends=True,
        index_header="Date",
        index_dt_format="%d-%b-%Y",
        highlight_cells=highlight,
    )
    assert html.count(f"background-color:{PARTIAL_CELL_BG}") == 3
    assert "background-color:#fff4d6" not in html.split("28-Sep-2026")[1].split("29-Sep-2026")[0]
    assert PARTIAL_STORAGE_NOTE
