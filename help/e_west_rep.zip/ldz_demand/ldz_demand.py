# LDZ Demand report 
import sys
import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime, timedelta
from pathlib import Path

from jain_commods.fundamental.gas import util
from jain_commods.core.util.emailhelper import send_email

from util import generate_report, get_ldz_forecasts, check_ldz_models_complete


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/ldz_demand')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'ldz_demand.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
days_back = config.getint('ReportSettings','days_back_dod')

# Check cmd line switches to see what type of report we're sending
run_12z = '--12z' in sys.argv
run_ec46 = '--ec46' in sys.argv


# Set datetime used to calculate the report dates
now = datetime.now()


system = platform.system().lower()
# Over rides for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'
    
    ######## Overrides for testing 
    # run_12z = True 
    # now = datetime(2026,2,26)
    # run_ec46 = True
    

# Filename is set based on the 12z switch (as the same report is schedule to run twice at different time)
file_suffix = '_12z' if run_12z else '_ec46' if run_ec46 else ''

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_ldz_demand{file_suffix}.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )



email_subject = "LDZ Demand"

last_run_datetime_file = REPORTS_PATH / f'last_run_datetime{file_suffix}.txt'
last_run_datetime_fmt = '%Y-%m-%dT%H:%M'


try:
    # TODO: 
        # show individual country breakdowns? (on the dash prob as we already show total changes per country)
        # send early look when partial forecasts are available?
    
    # Set which dates we are comparing 
    if run_12z:
        # We compare 12z vs 0z on the same day (except on a Sunday which is 12z Sunday vs 0z Friday)
        report_date = pd.to_datetime(now).normalize().replace(hour=12)
        report_date_prev = (report_date - timedelta(days=2)).replace(hour=0) if report_date.dayofweek==6 else report_date.replace(hour=0)
    else:
        # Compare 0z of current day vs 0z on previous day (except on Monday is vs Friday)
        report_date = pd.to_datetime(now).normalize()
        report_date_prev = report_date - timedelta(days=3 if report_date.dayofweek==0 else 1)
    
    logging.info(f'Running LDZ Demand Report, run_12z={run_12z}, run_ec46={run_ec46}, {report_date.strftime(last_run_datetime_fmt)} vs {report_date_prev.strftime(last_run_datetime_fmt)}')    
    
    # Get the last run report_date from the file
    last_run = datetime.strptime(open(last_run_datetime_file, 'r').read(), last_run_datetime_fmt)
    
    if report_date != last_run:
        # Define which "demand zones" and countries we are going to query
        demand_zones = ['BE','DE_H','DE_L','FR','GB','IT','NL']
        countries = ['BE','DE','FR','GB','IT','NL']
        
        # Define which forecasts we want
        forecasts = ['ECENS','GFSENS','EC46','weather_normal','weather_year']
        
        # Check if reqd LDZ forecasts have been loaded into the db yet
        if check_ldz_models_complete(demand_zones, report_date, run_12z, run_ec46):
            # Get reqd LDZ forecasts
            logging.info('Retrieving LDZ forecasts')  
            df_ldz_forecasts = get_ldz_forecasts(demand_zones, report_date, report_date_prev, run_ec46)
            
            # Get required balances (given timings we have to use previous day/align with DoD)
            # Extra date check to cover running am report on a Sunday (ie last available balance will be from the Friday)
            balance_ref_date = report_date_prev - timedelta(days=1) if report_date.dayofweek==6 else report_date_prev
            
            logging.info(f"Retrieving EU gas balance scenarios for {balance_ref_date}")  
            balances = {'Basecase': util.get_eu_gas_balance(scenario_name='Basecase', ref_date=balance_ref_date),
                        'EA': util.get_eu_gas_balance(scenario_name='EA', ref_date=balance_ref_date),
                        'Platts': util.get_eu_gas_balance(scenario_name='Platts', ref_date=balance_ref_date),
                        }
            
            # Construct report
            logging.info('Constructing email')  
            email_subject_change, email_body = generate_report(email_subject, df_ldz_forecasts, forecasts, report_date, report_date_prev, demand_zones, countries, balances, run_12z, run_ec46, days_back)
        
            # Send email
            logging.info('Sending email')  
            send_email(receivers, 
                       email_subject_change, 
                       email_body,
                       from_address='eu.gap.reports@jainglobal.com')
        
            # Save report_date value to the file confirm we've sent today's report
            with open(last_run_datetime_file, 'w') as f:
                f.write(report_date.strftime(last_run_datetime_fmt))
        
            logging.info('Report sent')
        
        else:
            logging.info('LDZ Forecasts are still missing')
            
    else:
        logging.info(f'Report already sent for report_date {report_date.strftime(last_run_datetime_fmt)}')


except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))    




    
