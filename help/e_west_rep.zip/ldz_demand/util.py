import base64
import io
import logging
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import numpy as np

from collections import defaultdict
from datetime import datetime, timedelta

from jain_commods.core.interfaces.bloomberg import weather
from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.interfaces.sqldb import SQLdb, DataQuery
from jain_commods.core.util.htmlutils import df2html

from jain_commods.fundamental.gas.ldz_temp_bumps import get_ldz_demand_bumps_all



fcast_dt_fmt = '%Y%m%d%H%M'

agg_col_name = 'NWE+IT'


def caluclate_avg_change_per_degree(ldz_bumps_dict):
    
    output = {}
    
    for k in ldz_bumps_dict.keys():

        # Get the data for this country
        df = ldz_bumps_dict[k]
    
        # Get all temperature bump columns (excluding date)
        temp_cols = [col for col in df.columns if col.startswith('temp_bump_')]
        
        # Extract the degree values from column names and sort by degree
        col_degree_pairs = []
        for col in temp_cols:
            degree = float(col.replace('temp_bump_', '').replace('+', ''))
            col_degree_pairs.append((col, degree))
        
        # Sort by degree value
        col_degree_pairs.sort(key=lambda x: x[1])
        sorted_cols = [col for col, deg in col_degree_pairs]
        
        # Calculate average increase per degree for each row
        def calculate_avg_increase_per_degree_abs(row):
            increases_per_degree = []
            
            for i in range(len(sorted_cols) - 1):
                col1 = sorted_cols[i]
                col2 = sorted_cols[i + 1]
                
                # The difference in bump values between adjacent columns
                bump_diff = row[col2] - row[col1]
                
                # Temperature difference (0.5 degrees between columns)
                temp_diff = 0.5
                
                # Increase per degree
                increase_per_deg = bump_diff / temp_diff
                increases_per_degree.append(increase_per_deg)
            
            # Return absolute value of the average
            return abs(np.mean(increases_per_degree))
        
        # Apply the function to each row
        df[f'{k}_avg_increase_per_degree_abs'] = df.apply(calculate_avg_increase_per_degree_abs, axis=1)
            
        output[k] = df[[f'{k}_avg_increase_per_degree_abs']]
    
    # Add combined DE value
    df_de = pd.concat([output['DE_H'],output['DE_L']], axis=1)
    df_de['DE_avg_increase_per_degree_abs'] = df_de.sum(axis=1)
    output['DE'] = df_de[['DE_avg_increase_per_degree_abs']]
    
    # Combine into single df (skipping the DE zones)
    df_combined = pd.concat([output[k] for k in output.keys() if k not in ['DE_H','DE_L']], axis=1)
    # Tidy up column names & sort
    df_combined.columns = [c.split('_')[0] for c in df_combined.columns]
    df_combined = df_combined[sorted(df_combined.columns)]
    # Add overall total
    df_combined['Total'] = df_combined.sum(axis=1)
    
    return df_combined



def check_ldz_models_complete(demand_zones, report_date, run_12z, run_ec46):
    
    if run_ec46:
        forecasts = ['ECENS', 'GFSENS', 'EC46']
    else:
        forecasts = ['ECENS', 'GFSENS']
        
    
    # forecasts = ['ECENS', 'GFSENS'] if run_12z else ['ECENS', 'GFSENS', 'EC46']
    expected = len(demand_zones) * len(forecasts)
    
    # Define common metadata
    md_common = {'commodity': 'GAS',
                'category1': 'Demand',
                'category2': 'LDZ',
                'category3': ','.join(demand_zones),
                'source1': 'JainGlobal',
                'source2': 'EuGasModelProcessor',
                }
        
    dq = DataQuery(logintype='prod')

    # Query for reqd ENS forecasts
    md = md_common.copy()
    # md['category4'] = ','.join(['ECENS', 'GFSENS'])
    md['category4'] = ','.join(forecasts)
    
    res1 = dq.get_data(by='metadata', metadata=md, report_date=report_date, querytype='bulk')
    
    # # Query again for EC46 (shifted report_date)
    # if not run_12z:
    #     md = md_common.copy()
    #     md['category4'] = 'EC46'
    #     res2 = dq.get_data(by='metadata', metadata=md, report_date=report_date-timedelta(days=1), querytype='bulk')
    # else:
    #     res2 = {}

    # Check whats in the db against what we're expecting
    # found = len(res1) + len(res2)
    found = len(res1)
    
    if found == expected:
        # Extra guard: a partial "early look" forecast can be saved to the db whilst the weather 
        # forecast is still being published, so also check the runs are marked complete in the runlog
        if not check_ldz_runs_complete(forecasts, report_date, expected):
            logging.info('LDZ forecasts found but some runs are still partial')
            return False
        logging.info(f'Found {found} expected LDZ forecasts')  
        return True
    else:
        logging.info(f'Required LDZ forecasts not found! Expected {expected}, found {found}') 
        return False


def check_ldz_runs_complete(forecasts, report_date, expected):
    """Checks the model processor runlog to confirm all required jobs are marked as complete.
    NB: needed because partial (early look) forecasts are saved to the db whilst a weather 
    forecast is still being published (ie data exists but the run isn't finished).
    """
    
    run = report_date.strftime('%H') # ie '00' or '12'
    sforecasts = ','.join([f"'{f}'" for f in forecasts])
    
    query = f"""SELECT count(distinct rl.schedule_id) as complete_count
                FROM commod_research.eu_gas_model_runlog rl
                JOIN commod_research.eu_gas_model_schedule s on rl.schedule_id=s.schedule_id
                JOIN commod_research.eu_gas_model_forecasts f on s.forecast_id=f.forecast_id
                WHERE f.forecast in ({sforecasts})
                and f.run='{run}'
                and s.enabled=True
                and rl.report_date='{report_date.strftime('%Y-%m-%d %H:%M')}'
                and rl.output_timestamp_utc is not null
                """
    with SQLdb(logintype='prod').engine.begin() as conn:
        res = pd.read_sql(query, conn)
    
    complete_count = res['complete_count'].iloc[0]
    
    if complete_count >= expected:
        return True
    else:
        logging.info(f'Runlog shows {complete_count} of {expected} required jobs complete')
        return False



def get_actual_ldz_demand_ce(ce_user, ce_pass, demand_zones, date_from):
        
    # Hard coded list of what we require
    # NB: if we update countries then we need to update this dict
    demand_asset_ids = {'BE': 665,
                        'DE_H': 2965,
                        'DE_L': 2967,
                        'FR': 192,
                        'GB': 54,
                        'IT': 1803,
                        'NL': 209,
                        }
    
    
    # Build str of assets ids
    asset_ids = ','.join([str(demand_asset_ids[c]) for c in demand_zones])
    
    # Query CE
    ce = CElink(ce_user,ce_pass)
    df_ldz_demand = ce.eugasopdata(assets=asset_ids,unit='mcm',dateFrom=date_from.strftime('%Y%m%d'))
    # Repeat the same query to get the metadata
    df_ldz_demand_meta = ce.eugasopdata(assets=asset_ids,unit='mcm',dateFrom=date_from.strftime('%Y%m%d'),meta=True)
    
    # Tidy up
    df_ldz_demand = df_ldz_demand.dropna()
    df_ldz_demand.index = pd.to_datetime(df_ldz_demand['Date'], format='%d-%b-%Y')
    df_ldz_demand = df_ldz_demand.drop(columns=['DateExcel','Date'])
    
    # Rename columns (NB: CE returns series IDs as column names but is preserved from original query)
    # df_ldz_demand.columns = demand_asset_ids.keys()
    # Really overly complicated but ensures we are clean (use metadata query and our dict to rename the columns from the CE response)
    demand_asset_ids_reverse = {v: k for k, v in demand_asset_ids.items()}
    df_ldz_demand.columns = [demand_asset_ids_reverse[int(df_ldz_demand_meta[df_ldz_demand_meta['seriesId']=='assetId'][str(col)].iloc[0])] for col in df_ldz_demand.columns]
    
    # Add total
    df_ldz_demand['Total'] = df_ldz_demand.sum(axis=1)
    
    return df_ldz_demand


def create_storage_distribution_box(target_dates, cumulative_at_dates):
    
    # Plot comparison of percentage fill against basecase
    
    # Separate percentage fill columns by type
    weather_year_cols = [col for col in cumulative_at_dates.columns 
                         if col.startswith('weather_year_') and col.endswith('_pct_fill')]
    weather_normal_cols = [col for col in cumulative_at_dates.columns 
                           if col.startswith('weather_normal_') and col.endswith('_pct_fill')]
    
    # Create figure with subplots - one for each target date
    fig, axes = plt.subplots(len(target_dates), 1, figsize=(12, 4*len(target_dates)))
    
    # Handle case where there's only one date
    if len(target_dates) == 1:
        axes = [axes]
    
    for idx, date in enumerate(target_dates):
        # Extract weather year percentage fill values for box plot
        year_pct_values = cumulative_at_dates.loc[date, weather_year_cols].dropna().values
        basecase_pct = cumulative_at_dates.loc[date, 'basecase_pct_fill']
        
        # Create box plot for weather year scenarios
        bp = axes[idx].boxplot([year_pct_values], vert=False, widths=0.5, 
                               patch_artist=True,
                               # whis=[10, 90],
                               boxprops=dict(facecolor='lightblue', alpha=0.7),
                               medianprops=dict(color='darkblue', linewidth=2))
        
        # Add basecase reference line
        if pd.notna(basecase_pct):
            axes[idx].axvline(basecase_pct, color='red', linestyle='--', 
                             linewidth=2.5, label=f'Basecase (ECENS+EC46+10yrWN): {basecase_pct:.0f}%')
        
        # Add weather normal scenarios as vertical lines
        colors = ['green', 'orange', 'purple']
        for col_idx, col in enumerate(weather_normal_cols):
            normal_pct = cumulative_at_dates.loc[date, col]
            if pd.notna(normal_pct):
                col_name = col.replace('weather_normal_', '').replace('_pct_fill', ' WN')
                axes[idx].axvline(normal_pct, color=colors[col_idx % len(colors)], 
                                linestyle=':', linewidth=2,
                                label=f'{col_name}: {normal_pct:.0f}%')
        
        # Add scatter points for all weather year scenarios
        y_positions = [1] * len(year_pct_values)
        axes[idx].scatter(year_pct_values, y_positions, alpha=0.4, s=30, color='darkblue')
        
        axes[idx].set_xlabel('Percentage', fontsize=11)
        axes[idx].set_title(f"Storage % Fill Distribution end {date.strftime('%b%y')}",  #" (n={len(year_pct_values)} year scenarios)", 
                           fontsize=12, fontweight='bold')
        axes[idx].set_yticks([])
        axes[idx].grid(True, alpha=0.3, axis='x')
        axes[idx].legend(loc='upper left', fontsize=9)
        
        # Add statistics
        stats_text = (f'WY {len(year_pct_values)} Scenarios :\n'
                     f'Min: {year_pct_values.min():.0f}%\n'
                     f'Q1: {pd.Series(year_pct_values).quantile(0.25):.0f}%\n'
                     f'Median: {pd.Series(year_pct_values).median():.0f}%\n'
                     f'Q3: {pd.Series(year_pct_values).quantile(0.75):.0f}%\n'
                     f'Max: {year_pct_values.max():.0f}%\n'
                     f'Mean: {year_pct_values.mean():.0f}%')
        axes[idx].text(0.98, 0.5, stats_text, transform=axes[idx].transAxes,
                      verticalalignment='center', horizontalalignment='right', fontsize=9,
                      bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
    
    plt.tight_layout()
    
    # Show the plot
    # plt.show()   
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64
    


def create_monthly_plot(df_months, weather_year_shading=True):
    
    df = df_months.copy()
    df = df.reset_index() 
    
    # Get weather year columns for min/max range
    weather_cols = [col for col in df.columns if col.startswith('weather_year_')]
    
    # Calculate min and max across weather years
    df['weather_min'] = df[weather_cols].min(axis=1)
    df['weather_max'] = df[weather_cols].max(axis=1)
    
    # Create side-by-side plots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    # Function to plot data on an axis
    def plot_data(ax, df, title, filter_date):
        
        # Filter data 
        data = df[df['date'] <= filter_date]
        
        # Plot Basecase
        basecase_label = 'Basecase (ECENS+EC46+10yr norm)' if weather_year_shading else 'Basecase'
        ax.plot(data['date'], data['Basecase'], label=basecase_label, 
                linewidth=2, color='#006494', alpha=0.9)
        
        if weather_year_shading:
            # Plot Basecase, EA, and Platts
            ax.plot(data['date'], data['Platts'], label='Platts', 
                    linewidth=2, color='#e09f3e')
            ax.plot(data['date'], data['EA'], label='EA', 
                    linewidth=2, color='green', alpha=0.8)
            
            # Plot ECENS columns    
            ax.plot(data['date'], data['ECENS_EC46_5yr'], label='ECENS+EC46+5yr norm', 
                    linewidth=2, color='#9e2a2b', alpha=0.6, linestyle='--')
            # ax.plot(data['date'], data['ECENS_EC46_10yr'], label='ECENS+EC46+10yr norm', 
            #         linewidth=2, color='#9e2a2b', alpha=0.6, linestyle='--')
            ax.plot(data['date'], data['ECENS_EC46_30yr'], label='ECENS+EC46+30yr norm', 
                    linewidth=2, color='#9e2a2b', alpha=0.3, linestyle='--')
            
            # Plot the shaded area for weather year range
            ax.fill_between(data['date'], data['weather_min'], data['weather_max'], 
                            alpha=0.3, color='lightgray', label='Weather Year Range (2010-2021)')
            
        else:

            # Plot weather_year columns with lighter colors (alpha=0.3)
            for col in weather_cols:
                ax.plot(data['date'], data[col], alpha=0.5, linewidth=1, label=col.replace('weather_year_',''))

        # Formatting
        ax.set_title(title, fontsize=12)
        ax.set_ylabel('mcm/d', fontsize=10)
        ax.grid(True, alpha=0.3)
        
        # Format x-axis dates as "Mon-YY"
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
        
        # Rotate x-axis labels for better readability
        ax.tick_params(axis='x', rotation=45)
    
    # Plot left panel (before Mar-26)
    plot_data(ax1, df, 'Balance Sum26', datetime(2026,9,1))
    
    # Plot right panel (before Mar-27)
    plot_data(ax2, df, 'All Data', datetime(2027,3,1))
    
    # Add main title
    maint_title = 'LDZ Demand Forecast (Basecase vs scenarios, normals & weather year range)' if weather_year_shading else 'LDZ Demand Forecast (Basecase vs weather years)'
    fig.suptitle(maint_title, fontsize=16, y=1.02)
    
    # Get handles and labels from one of the axes (they're the same for both)
    handles, labels = ax1.get_legend_handles_labels()
    
    # Create a single legend below both plots
    fig.legend(handles, labels, loc='lower center', ncol=6, fontsize=9, 
               framealpha=0.9, bbox_to_anchor=(0.5, -0.05))
    
    # Tight layout to prevent label cutoff
    plt.tight_layout()
    plt.subplots_adjust(bottom=0.15)  # Make room for the legend
    
    # Show the plot
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()
    
    return plot_base64



def create_short_term_forecast_plot(fcast_dod_tables, df_ldz_forecasts, run_12z, ec46=False):
    
    df_ec = fcast_dod_tables['ECENS'].copy()
    df_gfs = fcast_dod_tables['GFSENS'].copy()

    # Get column names we want to plot (as could either be D0 vs D-1 or D0 vs D-3)
    cols = df_ec.columns[:2]

    # Prepare the dataframes
    df_ec = df_ec.reset_index()
    df_gfs = df_gfs.reset_index()
    df_ec['date'] = pd.to_datetime(df_ec['date'])
    df_gfs['date'] = pd.to_datetime(df_gfs['date'])
        
    if ec46:
        df_ec46 = fcast_dod_tables['EC46'].copy()
        
        cols_ec46 = df_ec46.columns[:2]
        
        # Prepare the dataframes
        df_ec46 = df_ec46.reset_index()
        df_ec46['date'] = pd.to_datetime(df_ec46['date'])

    if not run_12z:
        # Extract weather normals        
        df_sn = df_ldz_forecasts[agg_col_name][['weather_normal_5yr','weather_normal_10yr','weather_normal_30yr']].copy()
        df_sn = df_sn.reset_index()
        df_sn['date'] = pd.to_datetime(df_sn['date'])
    
    # Truncate normals depending what we want to plot
    if ec46:
        df_sn = df_sn[(df_sn['date']>=min(df_ec46['date'].values)) & (df_sn['date']<=max(df_ec46['date'].values))]
    else:
        if not run_12z:
            df_sn = df_sn[(df_sn['date']>=min(df_ec['date'].values)) & (df_sn['date']<=max(df_ec['date'].values))]


    # Create the plot
    fig, ax = plt.subplots(figsize=(12, 5))
    
    # Add weekend shading
    dt_values = df_ec46['date'] if ec46 else df_ec['date']
    for date in dt_values:
        if date.weekday() >= 5:
            ax.axvspan(date, date + timedelta(days=1), facecolor='lightgray', alpha=0.3, zorder=0)

    # Plot ECENS lines
    plt.plot(df_ec['date'], df_ec[cols[0]], color='#457b9d', linewidth=2, label=f"ECENS {cols[0].split(' ')[0]}", zorder=3)
    plt.plot(df_ec['date'], df_ec[cols[1]], color='#457b9d', linewidth=2, linestyle='--', alpha=0.5, label=f"ECENS {cols[1].split(' ')[0]}", zorder=3)
    
    # Plot GFSENS lines
    plt.plot(df_gfs['date'], df_gfs[cols[0]], color='#e26d5c', linewidth=2, label=f"GFSENS {cols[0].split(' ')[0]}", zorder=3)
    plt.plot(df_gfs['date'], df_gfs[cols[1]], color='#e26d5c', linewidth=2, linestyle='--', alpha=0.5, label=f"GFSENS {cols[1].split(' ')[0]}", zorder=3)

    if ec46:
        # Plot EC46 lines
        plt.plot(df_ec46['date'], df_ec46[cols_ec46[0]], color='#386641', linewidth=2, label=f"EC46 {cols_ec46[0].split(' ')[0]}", zorder=3)
        plt.plot(df_ec46['date'], df_ec46[cols_ec46[1]], color='#386641', linewidth=2, linestyle='--', alpha=0.5, label=f"EC46 {cols_ec46[1].split(' ')[0]}", zorder=3)

    if not run_12z:
        # Plot seasonal normals
        plt.plot(df_sn['date'], df_sn['weather_normal_5yr'], color='#B0B0B0', linewidth=2, alpha=0.8, label='5yr weather normal', zorder=3)
        plt.plot(df_sn['date'], df_sn['weather_normal_10yr'], color='#B0B0B0', linewidth=2, alpha=0.4, label='10yr weather normal', zorder=3)
        plt.plot(df_sn['date'], df_sn['weather_normal_30yr'], color='#B0B0B0', linewidth=2, alpha=0.2, label='30yr weather normal', zorder=3)
    
    # Format x-axis dates
    if not ec46:
        ax.xaxis.set_major_locator(mdates.DayLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d %b'))
    plt.xticks(rotation=45, ha='right')
    
    # Set title
    chart_title_ec46 = f"EC Ext 46d ({cols_ec46[0].split(' ')[0]} vs {cols_ec46[1].split(' ')[0]}), " if ec46 else ""
    chart_title = f"{chart_title_ec46}EC & GFS Ens LDZ Demand Forecast ({cols[0].split(' ')[0]} vs {cols[1].split(' ')[0]})"
    ax.set_title(chart_title)
    
    # Formatting
    plt.ylabel('mcm', fontsize=12)
    plt.legend(loc='best')
    plt.grid(True, alpha=0.3, zorder=1)
    plt.tight_layout()   
    
    # Show the plot
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)

    return plot_base64



def produce_da_error_heatmaps(demand_zones, report_date, forecasts=['ECENS','GFSENS'], days_history=21):
    
    dq = DataQuery(logintype='prod')

    md = {'commodity': 'GAS',
        'category1': 'Demand',
        'category2': 'LDZ',
        'category3': ','.join(demand_zones),
        'category4': ','.join(forecasts),
        'source1': 'JainGlobal',
        'source2': 'EuGasModelProcessor',
        }

    # Generate reqd range of report_dates
    start_date = report_date - timedelta(days=days_history)
    end_date = report_date - timedelta(days=2) # NB: we do this as we won't have correct demand data for the current day (so table won't show misleading diff)
    report_dates = pd.date_range(start=start_date,end=end_date, freq='D')
    # Query data
    res = dq.get_data(by='metadata', metadata=md, report_date_from=start_date, querytype='bulk')
    
    # Process results
    output_ecens = defaultdict(list)
    output_gfsens = defaultdict(list)
    for i, df in res.items():
        
        # Parse dataframe name
        name_parts = df.name.split('.')
        cat3 = name_parts[4]  # demand zone
        cat4 = name_parts[5]  # forecast
        
        # Select appropriate output dictionary
        if cat4 == 'ECENS':
            output_dict = output_ecens
        elif cat4 == 'GFSENS':
            output_dict = output_gfsens
        else:
            continue  # Skip if neither ECENS nor GFSENS
            
        # Process each report date
        for rd in report_dates:
            da_dt = rd + timedelta(days=1)
            
            # Filter and extract value
            filtered = df[(df['report_date'] == rd) & (df['date'] == da_dt)]
            
            if len(filtered) == 1:
                da = filtered['value'].iloc[0]
                output_dict[da_dt].append(da)
        

    
    # Sum all the values
    for k, v in output_ecens.items():
        output_ecens[k] = sum(v)
    for k, v in output_gfsens.items():
        output_gfsens[k] = sum(v)
        
    df_output_ecens = pd.DataFrame(output_ecens.items(), columns=['date','ECENS']).set_index('date')
    df_output_gfsens = pd.DataFrame(output_gfsens.items(), columns=['date','GFSENS']).set_index('date')
    df_output = pd.concat([df_output_ecens, df_output_gfsens], axis=1)
    
    
    # Get actual demand
    actual_demand = get_actual_ldz_demand_ce('john.morley@jainglobal.com','Knockers99!', demand_zones, date_from=start_date)
    df_output['Actual'] = actual_demand['Total']
    
    
    df_output = df_output.dropna()
    
    # Original code to produce simple HTML table
    # df_output['ECENS Diff'] = df_output['Actual'] - df_output['ECENS']
    # df_output['GFSENS Diff'] = df_output['Actual'] - df_output['GFSENS']
    # df_da_error = df_output[['Actual','ECENS Diff','GFSENS Diff']]
    # df_da_error['ECENS Diff'] = [f'{v:+.1f}' for v in df_da_error['ECENS Diff'].values]
    # df_da_error['GFSENS Diff'] = [f'{v:+.1f}' for v in df_da_error['GFSENS Diff'].values]
    # da_error_html = df2html(df_da_error, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
    
    
    # Prepare the data for display
    df = df_output.reset_index()
    df['date'] = pd.to_datetime(df['date'])
    df['date_formatted'] = df['date'].dt.strftime('%d-%b-%Y')
    
    # Cal absolute diffs
    abs_diff = pd.DataFrame({'ECENS': (df['ECENS'].values - df['Actual'].values),
                             'GFSENS': (df['GFSENS'].values - df['Actual'].values)
                             }, index=df['date_formatted'])
    
    # Calculate pc diffs
    pct_diff = pd.DataFrame({'ECENS': ((df['ECENS'].values - df['Actual'].values) / df['Actual'].values) * 100,
                             'GFSENS': ((df['GFSENS'].values - df['Actual'].values) / df['Actual'].values) * 100
                             }, index=df['date_formatted'])
    
    # Create actuals dataframe
    actuals = pd.DataFrame({'Actual': df['Actual'].values}, index=df['date_formatted'])
    
    # Create figure with three subplots - adjust spacing and width ratios
    fig = plt.figure(figsize=(8, 6))
    gs = fig.add_gridspec(1, 3, wspace=0.1, width_ratios=[0.4, 1, 1])
    ax0 = fig.add_subplot(gs[0])
    ax1 = fig.add_subplot(gs[1])
    ax2 = fig.add_subplot(gs[2])
    
    # Heatmap 0: Actuals (no color shading)
    im0 = ax0.imshow(actuals, cmap='Greys', aspect='auto', vmin=actuals.min().min(), vmax=actuals.max().max(), alpha=0.01)
    ax0.set_yticks(np.arange(len(actuals.index)))
    ax0.set_xticks(np.arange(len(actuals.columns)))
    ax0.set_yticklabels(actuals.index, fontsize=8)
    # ax0.set_xticklabels(actuals.columns, fontsize=9)
    ax0.set_xticklabels([])
    ax0.set_title('Actual (mcm)', fontsize=11)
    ax0.tick_params(axis='both', which='major', pad=2)
    
    # Add text annotations for actuals
    for i in range(len(actuals.index)):
        for j in range(len(actuals.columns)):
            text = ax0.text(j, i, f'{actuals.iloc[i, j]:.0f}',
                           ha="center", va="center", color="black", fontsize=9,
                           fontweight='bold')
    
    # Define a red/green colormap centered at 0
    vmin_abs = min(abs_diff.min().min(), -abs_diff.max().max())
    vmax_abs = max(abs_diff.max().max(), -abs_diff.min().min())
    
    # Heatmap 1: Absolute Diffs 
    im1 = ax1.imshow(abs_diff, cmap='RdYlGn', aspect='auto', vmin=vmin_abs, vmax=vmax_abs)
    ax1.set_yticks(np.arange(len(abs_diff.index)))
    ax1.set_xticks(np.arange(len(abs_diff.columns)))
    ax1.set_yticklabels([])  # Remove y-axis labels
    ax1.set_xticklabels(abs_diff.columns, fontsize=9)
    ax1.set_title('DA Forecast Error (mcm)', fontsize=11)
    ax1.tick_params(axis='both', which='major', pad=2)
    
    # Add text annotations 
    for i in range(len(abs_diff.index)):
        for j in range(len(abs_diff.columns)):
            text = ax1.text(j, i, f'{abs_diff.iloc[i, j]:+.0f}',
                           ha="center", va="center", color="black", fontsize=9,
                           fontweight='bold')
    # Add colorbar
    cbar1 = plt.colorbar(im1, ax=ax1, pad=0.02)
    
    # Heatmap 2: Percentage Diffs
    vmin_pct = min(pct_diff.min().min(), -pct_diff.max().max())
    vmax_pct = max(pct_diff.max().max(), -pct_diff.min().min())
    
    im2 = ax2.imshow(pct_diff, cmap='RdYlGn', aspect='auto',vmin=vmin_pct, vmax=vmax_pct)
    ax2.set_yticks(np.arange(len(pct_diff.index)))
    ax2.set_xticks(np.arange(len(pct_diff.columns)))
    ax2.set_yticklabels([])  # Remove y-axis labels from third plot
    ax2.set_xticklabels(pct_diff.columns, fontsize=9)
    ax2.set_title('DA Forecast Error (%)', fontsize=11)
    ax2.tick_params(axis='both', which='major', pad=2)
    
    # Add text annotations
    for i in range(len(pct_diff.index)):
        for j in range(len(pct_diff.columns)):
            text = ax2.text(j, i, f'{pct_diff.iloc[i, j]:+.0f}%',
                           ha="center", va="center", color="black", fontsize=9,
                           fontweight='bold')
    # Add colorbar
    cbar2 = plt.colorbar(im2, ax=ax2, pad=0.02)
    
    plt.subplots_adjust(left=0.12, right=0.95, top=0.88, bottom=0.12)
    # Show the plot
    # plt.show()
    
    # Save to base64 string
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)

    return plot_base64





def parse_ldz_db_results(df_input, rd):
    
    did_name = df_input.name.split('.')
    cat3 = did_name[4] # demand zone
    cat4 = did_name[5] # forecast
    cat5 = did_name[6] # only relevant for normals or weather year
    
    # Prepare the new df
    new_col = f"{cat4}_{cat5}" if cat4 in ['weather_normal','weather_year'] else f"{cat4}_{rd.strftime(fcast_dt_fmt)}"
    df_output = df_input.set_index('date')[['value']].rename(columns={'value': new_col})
    
    return df_output, cat3



def get_ldz_forecasts(demand_zones, report_date, report_date_prev, run_ec46):
    
    # Define common metadata
    md_common = {'commodity': 'GAS',
                 'category1': 'Demand',
                 'category2': 'LDZ',
                 'category3': ','.join(demand_zones),
                 'source1': 'JainGlobal',
                 'source2': 'EuGasModelProcessor',
                 }
    
    dq = DataQuery(logintype='prod')
    
    output_dz = {}
    
    forecasts = ['EC46','ECENS', 'GFSENS','weather_normal', 'weather_year'] # if run_ec46 else ['ECENS', 'GFSENS','weather_normal', 'weather_year']
   
    # Query for latest ECENS, GFSENS, normals and weather years
    md = md_common.copy()
    # md['category4'] = ','.join(['ECENS', 'GFSENS','weather_normal', 'weather_year'])
    md['category4'] = ','.join(forecasts)
    res = dq.get_data(by='metadata', metadata=md, report_date=report_date, querytype='bulk')
    # Process the results and split out accordingly
    for i, v in res.items():
        df, cat3 = parse_ldz_db_results(v,report_date)
        # Store the result
        if cat3 in output_dz.keys():
            output_dz[cat3] = output_dz[cat3] + [df]
        else:
            output_dz[cat3] = [df]
            
    # Query for previous 
    md = md_common.copy()
    forecast_prev = ['EC46','ECENS', 'GFSENS'] # if run_ec46 else ['ECENS', 'GFSENS']
    md['category4'] = ','.join(forecast_prev)
    res = dq.get_data(by='metadata', metadata=md, report_date=report_date_prev, querytype='bulk')
    # Process the results and split out accordingly
    for i, v in res.items():
        df, cat3 = parse_ldz_db_results(v,report_date_prev)
        # Store the result
        output_dz[cat3] = output_dz[cat3] + [df]

    
    # Produce the dataframes
    output = {k: pd.concat(dfs, axis=1) for k, dfs in output_dz.items()}

    # Create new EU aggregated total
    output[agg_col_name] = sum(output.values())
    
    return output


def plot_dod_heatmap(df: pd.DataFrame, title: str = "LDZ Forecast Changes"):

    df = df.copy()
    df.index = pd.to_datetime(df.index)

    # Drop fully-NaN rows
    df = df.dropna(how="all")

    n_cols = len(df.columns)
    col_names = df.columns.tolist()

    # ── Build a calendar grid (weeks × days) for each column ──────────────────
    dates = df.index.normalize().unique().sort_values()
    all_dates_df = pd.DataFrame({"date": dates})
    all_dates_df["weekday"] = all_dates_df["date"].dt.dayofweek   # 0=Mon
    all_dates_df["week"] = all_dates_df["date"].dt.isocalendar().week.astype(int)
    all_dates_df["year"] = all_dates_df["date"].dt.isocalendar().year.astype(int)
    all_dates_df["week_seq"] = (
        all_dates_df.groupby(["year", "week"], sort=False).ngroup()
    )

    n_weeks = all_dates_df["week_seq"].nunique()
    all_day_labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

    def build_grid(col):
        col_dates = df[col].dropna().index.normalize().unique()
        active_wds = sorted(
            all_dates_df[all_dates_df["date"].isin(col_dates)]["weekday"].unique()
        )
        wd_to_slot = {wd: i for i, wd in enumerate(active_wds)}
        n_active = len(active_wds)

        grid = np.full((n_weeks, n_active), np.nan)
        for _, row in all_dates_df.iterrows():
            date = row["date"]
            ws = row["week_seq"]
            wd = row["weekday"]
            if wd not in wd_to_slot:
                continue
            val = df.loc[df.index.normalize() == date, col]
            if not val.empty and not pd.isna(val.iloc[0]):
                grid[ws, wd_to_slot[wd]] = val.iloc[0]

        wk_labels = []
        for ws in range(n_weeks):
            rows = all_dates_df[all_dates_df["week_seq"] == ws]
            wk_labels.append(rows["date"].min().strftime("%d %b") if not rows.empty else "")

        d_labels = [all_day_labels[wd] for wd in active_wds]
        return grid, d_labels, wk_labels

    panel_data = [build_grid(c) for c in col_names]
    grids     = [p[0] for p in panel_data]
    day_lbls  = [p[1] for p in panel_data]
    week_lbls = [p[2] for p in panel_data]

    # ── Shared colour scale (symmetric around 0) ──────────────────────────────
    all_vals = np.concatenate([g[~np.isnan(g)] for g in grids])
    vmax = np.nanpercentile(np.abs(all_vals), 95) if len(all_vals) else 1
    vmin = -vmax
    cmap = plt.cm.RdYlGn

    # ── Figure layout ─────────────────────────────────────────────────────────
    if n_cols == 1:
        figsize = (6, 10)
    else:
        figsize = (10, 10)

    CB_W_IN = 0.18
    CB_PAD_IN = 0.1

    fig = plt.figure(figsize=figsize)
    fig.subplots_adjust(top=0.88, right=0.88, wspace=0.35)

    from matplotlib.gridspec import GridSpec
    gs = GridSpec(
        2, n_cols,
        figure=fig,
        height_ratios=[3, 1],
        hspace=0.3,
        wspace=0.35,
        width_ratios=[max(1, len(d)) for d in day_lbls],
    )

    heat_axes = [fig.add_subplot(gs[0, i]) for i in range(n_cols)]
    bar_ax    = fig.add_subplot(gs[1, :])   # spans full width

    # ── Heatmaps ──────────────────────────────────────────────────────────────
    ims = []
    for ax, col, grid, dlbls, wlbls in zip(heat_axes, col_names, grids, day_lbls, week_lbls):
        n_active = grid.shape[1]
        im = ax.imshow(
            grid,
            aspect="auto",
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            interpolation="nearest",
        )
        ims.append(im)

        for ws in range(n_weeks):
            for slot in range(n_active):
                v = grid[ws, slot]
                if not np.isnan(v):
                    txt_color = "black" if abs(v) < vmax * 0.6 else "white"
                    ax.text(
                        slot, ws, f"{v:+.0f}",
                        ha="center", va="center",
                        fontsize=7.5, color=txt_color,
                    )

        ax.set_xticks(range(n_active))
        ax.set_xticklabels(dlbls, fontsize=9)
        ax.set_yticks(range(n_weeks))
        ax.set_yticklabels(wlbls, fontsize=8)
        ax.set_title(f"{col}", fontsize=11, fontweight="bold", pad=6)

    # ── Full-width bar chart: one bar per date, first column only ─────────────
    daily_totals = df[col_names[0]].dropna().sort_index()
    bar_dates  = daily_totals.index
    bar_values = daily_totals.values
    bar_colors = ["#4dac26" if v >= 0 else "#cc0000" for v in bar_values]

    x = np.arange(len(bar_dates))
    bar_ax.bar(x, bar_values, width=0.7, color=bar_colors)
    bar_ax.axhline(0, color="black", linewidth=0.8)

    # Show labels only for 1st and 15th of each month
    tick_positions = [i for i, d in enumerate(bar_dates) if d.day in (1, 15)]
    tick_labels    = [bar_dates[i].strftime("%d %b") for i in tick_positions]
    bar_ax.set_xticks(tick_positions)
    bar_ax.set_xticklabels(tick_labels, fontsize=7, rotation=45, ha="right")
    bar_ax.set_ylabel("")
    bar_ax.tick_params(axis="y", labelsize=7)
    bar_ax.set_title(col_names[0], fontsize=11, fontweight="bold", pad=6)
    bar_ax.yaxis.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)
    bar_ax.set_axisbelow(True)
    bar_ax.set_xlim(-0.5, len(bar_dates) - 0.5)

    # ── Colorbars (rightmost heatmap only) ────────────────────────────────────
    fig.canvas.draw()
    fig_w, fig_h = fig.get_size_inches()
    for i, (ax, im) in enumerate(zip(heat_axes, ims)):
        if i < n_cols - 1:
            continue
        pos = ax.get_position()
        cax = fig.add_axes([
            pos.x1 + CB_PAD_IN / fig_w,
            pos.y0,
            CB_W_IN / fig_w,
            pos.height,
        ])
        cb = fig.colorbar(im, cax=cax)
        cb.set_label("mcm", fontsize=8)
        cb.ax.tick_params(labelsize=7)

    # ── Save to base64 ────────────────────────────────────────────────────────
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    plot_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close(fig)

    return plot_base64
    


def generate_previous_dod_changes(demand_zones, report_date, run_12z, run_ec46, days_back=90):
    
    # Define common metadata
    md = {'commodity': 'GAS',
          'category1': 'Demand',
          'category2': 'LDZ',
          'category3': ','.join(demand_zones),
          'category4': 'EC46' if run_ec46 else 'ECENS',
          'source1': 'JainGlobal',
          'source2': 'EuGasModelProcessor',
          }
    
    tmp_dt = report_date - timedelta(days=days_back)
    # Go back to previous monday so heatmap looks better (minus 1 day so we can see DoD!)
    report_date_from = tmp_dt - timedelta(days=tmp_dt.weekday()+1)
    
    # Query the datapase
    dq = DataQuery(logintype='prod')
    res = dq.get_data(by='metadata', metadata=md, report_date_from=report_date_from, querytype='bulk')

    # Process results for each country
    output_per_country = {}
    output_per_country_mon = {}
    output_per_country_sun_pm = {}
    for k in res.keys():
        
        md_name = res[k].name.split('.')
        country = md_name[1]
        demand_zone = md_name[4]
        
        df = res[k].copy()
        
        output = {}
        output_mon = {}
        output_sun_pm = {}
        
        for rd in sorted(set(df['report_date'].values)):
            
            if run_12z:
                # we want all forecasts (as we are comparing 12z vs 0z on the same day)
                if pd.to_datetime(rd).hour==12:
                    
                    # Get forecast for this report date
                    df_fcast = df[df['report_date']==rd]
                    
                    rd_prev = pd.Timestamp(rd).replace(hour=0)

                    if rd_prev in df['report_date'].values:
                        df_fcast_prev = df[df['report_date']==rd_prev]
                        df_combined = pd.concat([df_fcast.set_index('date')[['value']].rename(columns={'value': pd.Timestamp(rd).strftime(fcast_dt_fmt)}),
                                                 df_fcast_prev.set_index('date')[['value']].rename(columns={'value': rd_prev.strftime(fcast_dt_fmt)}),
                                                 ], axis=1)
                        df_combined['delta'] = df_combined[pd.Timestamp(rd).strftime(fcast_dt_fmt)] - df_combined[rd_prev.strftime(fcast_dt_fmt)]
                        
                        # Store the total delta for this report date
                        output[rd] = df_combined['delta'].sum()
                        
                    # Special logic on a Sunday pm (when we compare 12z Sunday vs 0z Friday)
                    if pd.Timestamp(rd).dayofweek==6:
                        rd_prev_fri = (rd-pd.Timedelta(days=2)).replace(hour=0)
                        
                        if rd_prev_fri in df['report_date'].values:
                            # Get forecast for previous report date, combine & calc delta
                            df_fcast_prev = df[df['report_date']==rd_prev_fri]
                            df_combined = pd.concat([df_fcast.set_index('date')[['value']].rename(columns={'value': pd.Timestamp(rd).strftime(fcast_dt_fmt)}),
                                                     df_fcast_prev.set_index('date')[['value']].rename(columns={'value': rd_prev_fri.strftime(fcast_dt_fmt)}),
                                                     ], axis=1)
                            df_combined['delta'] = df_combined[pd.Timestamp(rd).strftime(fcast_dt_fmt)] - df_combined[rd_prev_fri.strftime(fcast_dt_fmt)]
                            
                            # Store the total delta for this report date
                            output_sun_pm[rd] = df_combined['delta'].sum()
                        
            else:
                # We only want to consider the 0z forecast
                if pd.to_datetime(rd).hour==0:
                    
                    # Get forecast for this report date
                    df_fcast = df[df['report_date']==rd]
                    
                    # Check if previous report date exists (as no DoD to calculate)
                    rd_prev = rd-pd.Timedelta(days=1)
                    if rd_prev in df['report_date'].values:

                        # Get forecast for previous report date, combine & calc delta
                        df_fcast_prev = df[df['report_date']==rd_prev]
                        df_combined = pd.concat([df_fcast.set_index('date')[['value']].rename(columns={'value': pd.Timestamp(rd).strftime(fcast_dt_fmt)}),
                                                 df_fcast_prev.set_index('date')[['value']].rename(columns={'value': rd_prev.strftime(fcast_dt_fmt)}),
                                                 ], axis=1)
                        df_combined['delta'] = df_combined[pd.Timestamp(rd).strftime(fcast_dt_fmt)] - df_combined[rd_prev.strftime(fcast_dt_fmt)]
                        
                        # Store the total delta for this report date
                        output[rd] = df_combined['delta'].sum()
                        
                    # Special logic for Monday as we compare versus Fri
                    if pd.Timestamp(rd).dayofweek==0:
                        rd_prev_fri = rd-pd.Timedelta(days=3)
                        if rd_prev_fri in df['report_date'].values:
                            
                            # Get forecast for previous report date, combine & calc delta
                            df_fcast_prev = df[df['report_date']==rd_prev_fri]
                            df_combined = pd.concat([df_fcast.set_index('date')[['value']].rename(columns={'value': pd.Timestamp(rd).strftime(fcast_dt_fmt)}),
                                                     df_fcast_prev.set_index('date')[['value']].rename(columns={'value': rd_prev_fri.strftime(fcast_dt_fmt)}),
                                                     ], axis=1)
                            df_combined['delta'] = df_combined[pd.Timestamp(rd).strftime(fcast_dt_fmt)] - df_combined[rd_prev_fri.strftime(fcast_dt_fmt)]
                            
                            # Store the total delta for this report date
                            output_mon[rd] = df_combined['delta'].sum()
                            
        # Capture results
        output_per_country[f"{country}_{demand_zone}"] = output
        output_per_country_mon[f"{country}_{demand_zone}"] = output_mon
        output_per_country_sun_pm[f"{country}_{demand_zone}"] = output_sun_pm
    

    # Create df
    df_output_per_country = pd.DataFrame(output_per_country)
    
    if run_12z:
        
        if pd.Timestamp(report_date).dayofweek==6:
            # Special case on a Sun pm when we compare vs Fri 0z 
            wd = df_output_per_country.sum(axis=1).rename('12z vs 0z').to_frame()
            sun_vs_fri = pd.DataFrame(output_per_country_sun_pm).sum(axis=1).rename('Sun12zVsFri0z')
            df_output = pd.concat([wd, sun_vs_fri], axis=1)
        else:
            df_output = df_output_per_country.sum(axis=1).rename('12z vs 0z').to_frame()
    else:
        dod = df_output_per_country.sum(axis=1).rename('0z DoD')
        mon_vs_fri = pd.DataFrame(output_per_country_mon).sum(axis=1).rename('MonVsFri')
        df_output = pd.concat([dod, mon_vs_fri], axis=1)
    
    df_output = df_output.sort_index(ascending=False)
    
    return df_output
    
    
    




def generate_report(email_subject, df_ldz_forecasts, forecasts, report_date, report_date_prev, demand_zones, countries, balances, run_12z, run_ec46, days_back):
    
    today = pd.to_datetime(datetime.now()).normalize()
    
    ############# Construct DoD tables
    fcast_dod_tables = {}
    fcast_list = ['ECENS','GFSENS','EC46'] if run_ec46 else ['ECENS','GFSENS']
    temps_dod_tables = {}
    for fcast in fcast_list:
        
        # Get columns for this forecast (dynamic due to Mon vs Fri)
        cols = sorted([c for c in df_ldz_forecasts[agg_col_name].columns if c.startswith(fcast)], reverse=True)
        col_latest = cols[0]
        col_prev = cols[1]
        rd = datetime.strptime(col_latest.split('_')[1], fcast_dt_fmt)
        rd_prev = datetime.strptime(col_prev.split('_')[1], fcast_dt_fmt)
        df = df_ldz_forecasts[agg_col_name][[col_latest,col_prev]].dropna()
        df['Delta'] = df[col_latest] - df[col_prev]
        # Rename columns
        df = df.rename(columns={col_latest: f"D{(rd-today).days} {rd.strftime('%H')}z",
                                col_prev: f"D{(rd_prev-today).days} {rd_prev.strftime('%H')}z",})
        
        # Get latest & previous temperatures (for context)
        per_country_deltas = {}
        for geography in countries:
            logging.info(f"Getting latest & previous {geography} {fcast} forecasts from BBG...")
            if fcast=='ECENS':
                weather_data = weather.get_bbg_data('forecast-weather',geography, model='ECMWF', model_type='ENSEMBLE_MEAN', pub_date=rd)
                weather_data_prev = weather.get_bbg_data('forecast-weather',geography, model='ECMWF', model_type='ENSEMBLE_MEAN', pub_date=rd_prev)
            elif fcast=='EC46': 
                if run_ec46:
                    weather_data = weather.get_bbg_data('forecast-weather',geography, model_type='MONTH_AHEAD', pub_date=rd)
                    weather_data_prev = weather.get_bbg_data('forecast-weather',geography, model_type='MONTH_AHEAD', pub_date=rd_prev)
            elif fcast=='GFSENS':
                weather_data = weather.get_bbg_data('forecast-weather',geography, model='GFS', model_type='ENSEMBLE_MEAN', pub_date=rd)
                weather_data_prev = weather.get_bbg_data('forecast-weather',geography, model='GFS', model_type='ENSEMBLE_MEAN', pub_date=rd_prev)
            
            # Store the delta sum for this country
            per_country_deltas[geography] = (weather_data['t_celsius'] - weather_data_prev['t_celsius']).sum()
            
            # Capture DE temperatures (for context) in our main df
            if geography=='DE':
                # Add weather forecast diff
                df['DE Temp Delta'] = weather_data['t_celsius'] - weather_data_prev['t_celsius']
                
        # Store temperature forecasts so we can include by country summary table
        temps_dod_tables[fcast] = pd.DataFrame([per_country_deltas],index=['Total Delta'])
        
        # Capture forecast in our main dict
        fcast_dod_tables[fcast] = df
    
    # Combine the Ensemble forecasts (so we can create multi index header for neater display)
    df_ecens = fcast_dod_tables['ECENS'].copy()
    df_ecens.loc['Total'] = df_ecens.sum()
    diff_ecens = df_ecens.loc['Total','Delta']
    df_ecens.columns = pd.MultiIndex.from_tuples([('ECENS',c) for c in df_ecens.columns])        
    
    df_gfsens = fcast_dod_tables['GFSENS'].copy()
    df_gfsens.loc['Total'] = df_gfsens.sum()
    diff_gfsens = df_gfsens.loc['Total','Delta']
    df_gfsens.columns = pd.MultiIndex.from_tuples([('GFSENS',c) for c in df_gfsens.columns])        
    
    df_ens = pd.concat([df_ecens,df_gfsens], axis=1).dropna()
    
    if run_ec46:
        # Add total row
        df_ec46 = fcast_dod_tables['EC46'].copy()
        df_ec46.loc['Total'] = df_ec46.sum()
        diff_ec46 = df_ec46.loc['Total','Delta']
    
    # Construct summary table 
    if run_ec46:
        df_tmp = df_ec46.loc[['Total']]
        df_tmp.columns = pd.MultiIndex.from_tuples([('EC46',c) for c in df_tmp.columns])   
        # df_summary = pd.concat([df_ecens.loc[['Total']],
        #                         df_gfsens.loc[['Total']],
        #                         df_tmp.loc[['Total']],
        #                         ], axis=1)
        df_summary = df_tmp.loc[['Total']]
    else:
        df_summary = pd.concat([df_ecens.loc[['Total']],
                                df_gfsens.loc[['Total']],
                                ], axis=1)
    
    # set display formats (as we have a mixture)
    for col in df_summary.columns:
        if col[1]=='DE Temp Delta':
            df_summary[col] = [f'{v:+.2f}' for v in df_summary[col].values]
        if col[1]=='Delta':
            df_summary[col] = [f'{v:+.0f}' for v in df_summary[col].values]    
        if col[1].startswith('D0') | col[1].startswith('D-'):
            df_summary[col] = [f'{v:,.0f}' for v in df_summary[col].values]    
    
    # Now back to the seperate tables.... we "cheat" and set the DE Temp Delta as str (ready for display as other values will have precision=0)
    df_ens[('ECENS','DE Temp Delta')] = [f'{v:+.2f}' for v in df_ens[('ECENS','DE Temp Delta')].values]
    df_ens[('GFSENS','DE Temp Delta')] = [f'{v:+.2f}' for v in df_ens[('GFSENS','DE Temp Delta')].values]
    if run_ec46:
        df_ec46['DE Temp Delta'] = [f'{v:+.2f}' for v in df_ec46['DE Temp Delta'].values]
    
    
    # Create per country summary tables
    country_diffs = {}
    for fcast in ['ECENS','GFSENS','EC46'] if run_ec46 else ['ECENS','GFSENS']:
        if run_12z and fcast=='EC46':
            # We skip EC46 as we don't display this when running the non EC46 reports
            continue
        fcast_country_diffs = {}
        for c in df_ldz_forecasts.keys():
            if c != agg_col_name:
                # Get columns for this forecast (dynamic due to Mon vs Fri)
                cols = sorted([c for c in df_ldz_forecasts[c].columns if c.startswith(fcast)], reverse=True)
                col_latest = cols[0]
                col_prev = cols[1]
                # Calculate totals and resulting diff
                df = pd.concat([df_ldz_forecasts[c][[col_latest]], df_ldz_forecasts[c][[col_prev]]], axis=1).dropna()
                fcast_country_diffs[c] = df[col_latest].sum() - df[col_prev].sum()
                
        # Combine the two DE regions & remove originals
        fcast_country_diffs['DE'] = fcast_country_diffs['DE_H'] + fcast_country_diffs['DE_L']
        del fcast_country_diffs['DE_H']
        del fcast_country_diffs['DE_L']
        
        # Store in output
        country_diffs[fcast] = fcast_country_diffs
                
    # Create dataframes and combine etc
    df_ecens_country = pd.DataFrame(country_diffs['ECENS'],index=['Total'])
    df_ecens_country = df_ecens_country.sort_index(axis=1)
    df_ecens_country['Total'] = df_ecens_country.sum(axis=1)
    df_ecens_country.columns = pd.MultiIndex.from_tuples([('ECENS',c) for c in df_ecens_country.columns])   
    df_gfsens_country = pd.DataFrame(country_diffs['GFSENS'],index=['Total'])
    df_gfsens_country = df_gfsens_country.sort_index(axis=1)
    df_gfsens_country['Total'] = df_gfsens_country.sum(axis=1)
    df_gfsens_country.columns = pd.MultiIndex.from_tuples([('GFSENS',c) for c in df_gfsens_country.columns])   
    df_ens_country = pd.concat([df_ecens_country, df_gfsens_country], axis=1)
    # Create html table
    ens_country_html = df2html(df_ens_country, precision=0)
    
    # Create temperature delta per country table
    df_ecens_temp_delta = temps_dod_tables['ECENS'].copy()
    for c in df_ecens_temp_delta.columns:
        df_ecens_temp_delta[c] = [f'{v:+.2f}' for v in df_ecens_temp_delta[c].values]
    df_ecens_temp_delta.columns = pd.MultiIndex.from_tuples([('ECENS',c) for c in df_ecens_temp_delta.columns])     
    df_gfsens_temp_delta = temps_dod_tables['GFSENS'].copy()
    for c in df_gfsens_temp_delta.columns:
        df_gfsens_temp_delta[c] = [f'{v:+.2f}' for v in df_gfsens_temp_delta[c].values]
    df_gfsens_temp_delta.columns = pd.MultiIndex.from_tuples([('GFSENS',c) for c in df_gfsens_temp_delta.columns]) 
    df_ens_temp_delta_country = pd.concat([df_ecens_temp_delta, df_gfsens_temp_delta], axis=1)
    # Create HTML table
    ens_temp_delta_html = df2html(df_ens_temp_delta_country, precision=0)
    
    
    if run_ec46:
        df_ec46_country = pd.DataFrame(country_diffs['EC46'],index=['Total'])
        df_ec46_country = df_ec46_country.sort_index(axis=1)
        df_ec46_country['Total'] = df_ec46_country.sum(axis=1)
        # Create html table
        ec46_country_html = df2html(df_ec46_country, precision=0)
        
        # Create per country temperature deltas
        df_ec46_temp_delta = temps_dod_tables['EC46'].copy()
        for c in df_ec46_temp_delta.columns:
            df_ec46_temp_delta[c] = [f'{v:+.2f}' for v in df_ec46_temp_delta[c].values]
        ec46_temp_delta_html = df2html(df_ec46_temp_delta, precision=0)
    
    
    # Generate table showing history of recent changes
    df_changes = generate_previous_dod_changes(demand_zones, report_date, run_12z, run_ec46, days_back)
    dod_heatmap = plot_dod_heatmap(df_changes)
    dod_heatmap_img = f"<img src='data:image/png;base64,{dod_heatmap}' alt='DoD Change Heatmap'>"
    
    
    # Create html tables for the report
    ens_html = df2html(df_ens, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
    if run_ec46:
        ec46_html = df2html(df_ec46, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
    summary_html = df2html(df_summary)
    
    # Create charts
    plot_ens_forecast = create_short_term_forecast_plot(fcast_dod_tables, df_ldz_forecasts, run_12z)
    plot_ens_forecast_img = f"<img src='data:image/png;base64,{plot_ens_forecast}' alt='Ensemble Forecast Comparison'>"

    if run_ec46:    
        plot_ext_forecast = create_short_term_forecast_plot(fcast_dod_tables, df_ldz_forecasts, run_12z, ec46=True)
        plot_ext_forecast_img = f"<img src='data:image/png;base64,{plot_ext_forecast}' alt='Extended Forecast Comparison'>"
    
    
    if run_12z==False and run_ec46==False:
        # NB: we only display this extra content in the "main" 0z report in the morning
        
        ############# Get DA error
        plot_da_error_heatmaps = produce_da_error_heatmaps(demand_zones, report_date)
        plot_da_error_heatmaps_img = f"<img src='data:image/png;base64,{plot_da_error_heatmaps}' alt='DA Error Heatmaps'>"
    
    
        ############# Produce monthly plot
        
        # Produce monthly table
        # Select columns we want
        cols_weather_years = [c for c in df_ldz_forecasts[agg_col_name].columns if c.startswith('weather_year')]
        cols_weather_normal = [c for c in df_ldz_forecasts[agg_col_name].columns if c.startswith('weather_normal')]
        col_ecens = f"ECENS_{report_date.strftime(fcast_dt_fmt)}"
        col_ec46 = f"EC46_{report_date_prev.strftime(fcast_dt_fmt)}"
        df_months = df_ldz_forecasts[agg_col_name][[col_ecens,col_ec46] + cols_weather_normal + cols_weather_years]
        # Truncate
        df_months = df_months[df_months.index>=report_date]
        # Merge ECENS and EC46
        df_months['ECENS_EC46_5yr'] = df_months[col_ecens].combine_first(df_months[col_ec46]).combine_first(df_months['weather_normal_5yr'])
        df_months['ECENS_EC46_10yr'] = df_months[col_ecens].combine_first(df_months[col_ec46]).combine_first(df_months['weather_normal_10yr'])
        df_months['ECENS_EC46_30yr'] = df_months[col_ecens].combine_first(df_months[col_ec46]).combine_first(df_months['weather_normal_30yr'])
        
        df_months = df_months.resample('MS').mean()
        df_months = df_months.drop([col_ecens,col_ec46] + cols_weather_normal, axis=1)
    
    
        # Get monthly LDZ demand from each balance scenario NB: we include CH so we have to aggregate from the individual countries
        for k, b in balances.items():
            # print(f"scenario: {k}")
            country_balances = []
            for c in countries:
                # print(f"processing {c}")
                ldz_col = ('Demand','LDZ','Total') if k=='Basecase' else ('Demand','LDZ',f"{c} LDZ")
                country_balances.append(b['balance_daily_per_country'][c][ldz_col].resample('MS').mean() * -1)
            monthly = pd.concat(country_balances, axis=1)
            df_months[k] = monthly.sum(axis=1)
        
        # Create plot
        plot_monthly_shading = create_monthly_plot(df_months)
        plot_monthly_shading_img = f"<img src='data:image/png;base64,{plot_monthly_shading}' alt='Monthly Forecast Comparison (with shading)'>"
        
        plot_monthly_wy = create_monthly_plot(df_months, weather_year_shading=False)
        plot_monthly_wy_img = f"<img src='data:image/png;base64,{plot_monthly_wy}' alt='Monthly Forecast Comparison (weather years)'>"
            
        ############# End of season storage impact
        
        # Add our basecase to the forecasts (so we can calculate diffs)
        df_daily_combined = df_ldz_forecasts[agg_col_name].copy()
        df_daily_combined['basecase'] = balances['Basecase']['balance_daily'][('Demand','LDZ')] * -1
        
        # Drop columns we don't require
        reqd_cols = [c for c in df_daily_combined.columns if ('ENS_' not in c and not c.startswith('EC46_'))]
        df_daily_combined = df_daily_combined[reqd_cols].dropna()
           
        # Get current storage level for key dates:
            # end Mar26
            # end Oct26
            # end Mar27
        target_dates = [datetime(2026,10,31), datetime(2027,3,31)]
        basecase_future_stocks = {}
        for dt in target_dates:
            basecase_future_stocks[dt] = dict(stock = balances['Basecase']['balance_daily'].loc[dt,('Storage','Stock')], 
                                              capa = balances['Basecase']['balance_daily'].loc[dt,('Storage','Capa')])
        
        # Calculate cumulative diff of impact at these dates (for all weather years and normals)
        # Identify all weather columns (exclude 'date' and 'basecase')
        weather_columns = [col for col in df_daily_combined.columns if col != 'basecase']
        
        # Calculate daily differences (weather_column - basecase)
        diff_df = pd.DataFrame(index=df_daily_combined.index)
        for col in weather_columns:
            diff_df[f'{col}_diff'] = df_daily_combined[col] - df_daily_combined['basecase']
        
        cumulative_df = pd.DataFrame(index=df_daily_combined.index)
        for col in weather_columns:
            cumulative_df[f'{col}_cumsum'] = (df_daily_combined[col] - df_daily_combined['basecase']).cumsum()
        
        # Filter cumulative differences for specific dates
        cumulative_at_dates = cumulative_df.loc[target_dates]
        
        # Calculate projected stock levels
        cumulative_at_dates['stock'] = [basecase_future_stocks[date]['stock'] for date in target_dates]
        cumulative_at_dates['capacity'] = [basecase_future_stocks[date]['capa'] for date in target_dates]
        
        # Add adjusted stock levels (cumulative difference + stock) for each weather column
        for col in cumulative_at_dates.columns:
            if col.endswith('_cumsum'):
                scenario_name = col.replace('_cumsum', '')
                cumulative_at_dates[f'{scenario_name}_adjusted_stock'] = (cumulative_at_dates['stock'] - cumulative_at_dates[col])
                # Calculate percentage fill (adjusted stock / capacity * 100)
                cumulative_at_dates[f'{scenario_name}_pct_fill'] = (cumulative_at_dates[f'{scenario_name}_adjusted_stock'] / cumulative_at_dates['capacity'] * 100)
        
        # Calculate basecase percentage fill
        cumulative_at_dates['basecase_pct_fill'] = (
            cumulative_at_dates['stock'] / cumulative_at_dates['capacity'] * 100
        )
        
        boxplot_storage = create_storage_distribution_box(target_dates, cumulative_at_dates)
        boxplot_storage_img = f"<img src='data:image/png;base64,{boxplot_storage}' alt='Storage Distribution Boxplot'>"
        
        
        ############# LDZ temperature bumps

                
        # Get LDZ demand bumps (aggregated & individual country) LDZ demand temp bumps using different weather normals
        df_ldz_bumps_5yr, ldz_bumps_dict_5yr = get_ldz_demand_bumps_all(source='csv', weather_normal_yr=5, delta=True)
        df_ldz_bumps_10yr, ldz_bumps_dict_10yr = get_ldz_demand_bumps_all(source='csv', weather_normal_yr=10, delta=True)
        df_ldz_bumps_30yr, ldz_bumps_dict_30yr = get_ldz_demand_bumps_all(source='csv', weather_normal_yr=30, delta=True)
        
        # Create total bcm equivalents
        df_ldz_bumps_5yr_bcm = df_ldz_bumps_5yr.copy()
        for idx in df_ldz_bumps_5yr_bcm.index:
            days_in_month = idx.days_in_month
            df_ldz_bumps_5yr_bcm.loc[idx] = df_ldz_bumps_5yr_bcm.loc[idx] * days_in_month
        df_ldz_bumps_5yr_bcm = df_ldz_bumps_5yr_bcm / 1000
        
        df_ldz_bumps_10yr_bcm = df_ldz_bumps_10yr.copy()
        for idx in df_ldz_bumps_10yr_bcm.index:
            days_in_month = idx.days_in_month
            df_ldz_bumps_10yr_bcm.loc[idx] = df_ldz_bumps_10yr_bcm.loc[idx] * days_in_month
        df_ldz_bumps_10yr_bcm = df_ldz_bumps_10yr_bcm / 1000
        
        df_ldz_bumps_30yr_bcm = df_ldz_bumps_30yr.copy()
        for idx in df_ldz_bumps_30yr_bcm.index:
            days_in_month = idx.days_in_month
            df_ldz_bumps_30yr_bcm.loc[idx] = df_ldz_bumps_30yr_bcm.loc[idx] * days_in_month
        df_ldz_bumps_30yr_bcm = df_ldz_bumps_30yr_bcm / 1000
        
    
        # Tidy up indexes & column names
        df_ldz_bumps_5yr.index = [idx.strftime('%b') for idx in df_ldz_bumps_5yr.index]
        df_ldz_bumps_10yr.index = [idx.strftime('%b') for idx in df_ldz_bumps_10yr.index]
        df_ldz_bumps_30yr.index = [idx.strftime('%b') for idx in df_ldz_bumps_30yr.index]
        
        df_ldz_bumps_5yr_bcm.index = [idx.strftime('%b') for idx in df_ldz_bumps_5yr_bcm.index]
        df_ldz_bumps_10yr_bcm.index = [idx.strftime('%b') for idx in df_ldz_bumps_10yr_bcm.index]
        df_ldz_bumps_30yr_bcm.index = [idx.strftime('%b') for idx in df_ldz_bumps_30yr_bcm.index]
        
        
        # Combine into single multi index dataframes
        df_ldz_bumps_5yr.columns = pd.MultiIndex.from_tuples([('5yr Weather Normal (mcm/d)',c.replace('temp_bump_+0.0','Baseline').replace('temp_bump_','')) for c in df_ldz_bumps_5yr.columns])
        df_ldz_bumps_10yr.columns = pd.MultiIndex.from_tuples([('10yr Weather Normal (mcm/d)',c.replace('temp_bump_+0.0','Baseline').replace('temp_bump_','')) for c in df_ldz_bumps_10yr.columns])
        df_ldz_bumps_30yr.columns = pd.MultiIndex.from_tuples([('30yr Weather Normal (mcm/d)',c.replace('temp_bump_+0.0','Baseline').replace('temp_bump_','')) for c in df_ldz_bumps_30yr.columns])
        df_ldz_bumps_mcmd = pd.concat([df_ldz_bumps_5yr, df_ldz_bumps_10yr, df_ldz_bumps_30yr], axis=1)
        
        df_ldz_bumps_5yr_bcm.columns = pd.MultiIndex.from_tuples([('5yr Weather Normal (bcm)',c.replace('temp_bump_+0.0','Baseline').replace('temp_bump_','')) for c in df_ldz_bumps_5yr_bcm.columns])
        df_ldz_bumps_10yr_bcm.columns = pd.MultiIndex.from_tuples([('10yr Weather Normal (bcm)',c.replace('temp_bump_+0.0','Baseline').replace('temp_bump_','')) for c in df_ldz_bumps_10yr_bcm.columns])
        df_ldz_bumps_30yr_bcm.columns = pd.MultiIndex.from_tuples([('30yr Weather Normal (bcm)',c.replace('temp_bump_+0.0','Baseline').replace('temp_bump_','')) for c in df_ldz_bumps_30yr_bcm.columns])
        df_ldz_bumps_bcm = pd.concat([df_ldz_bumps_5yr_bcm, df_ldz_bumps_10yr_bcm, df_ldz_bumps_30yr_bcm], axis=1)
        
        
        
        # Create simplified view which shows average mcm change per deg for each country
        df_ldz_bumps_per_deg_10yr = caluclate_avg_change_per_degree(ldz_bumps_dict_10yr)
        
        # Convert to bcm
        df_ldz_bumps_per_deg_10yr_bcm = df_ldz_bumps_per_deg_10yr.copy()
        for idx in df_ldz_bumps_per_deg_10yr_bcm.index:
            days_in_month = idx.days_in_month
            df_ldz_bumps_per_deg_10yr_bcm.loc[idx] = df_ldz_bumps_per_deg_10yr_bcm.loc[idx] * days_in_month
        df_ldz_bumps_per_deg_10yr_bcm = df_ldz_bumps_per_deg_10yr_bcm / 1000
        
        # Combine into single multi index dataframes
        df_ldz_bumps_per_deg_10yr.columns = pd.MultiIndex.from_tuples([('mcm/d',c) for c in df_ldz_bumps_per_deg_10yr.columns])
        df_ldz_bumps_per_deg_10yr_bcm.columns = pd.MultiIndex.from_tuples([('bcm',c) for c in df_ldz_bumps_per_deg_10yr_bcm.columns])

        # Tidy up indexes for display
        df_ldz_bumps_per_deg_10yr.index = [idx.strftime('%b') for idx in df_ldz_bumps_per_deg_10yr.index]
        df_ldz_bumps_per_deg_10yr_bcm.index = [idx.strftime('%b') for idx in df_ldz_bumps_per_deg_10yr_bcm.index]
        
        
        # Create HTML tables
        ldz_bump_mcmd_html = df2html(df_ldz_bumps_mcmd, precision=0)
        ldz_bump_bcm_html = df2html(df_ldz_bumps_bcm, precision=1)
        
        ldz_bump_per_deg_mcmd_html = df2html(df_ldz_bumps_per_deg_10yr, precision=0)
        ldz_bump_per_deg_bcm_html = df2html(df_ldz_bumps_per_deg_10yr_bcm, precision=1)
        
        
        

        # TODO: 
            # create HTML tables or heatmaps?
            # create plot
    
    
    
    ############# Construct email
    
    # Construct email subject
    
    # subject_hour = ' (12z)' if run_12z else ''
    # subject_ec46_diff = "" if run_12z else f", EC46 {diff_ec46:+,.0f}mcm"
    # email_subject_change = f"{email_subject}{subject_hour}: ECENS {diff_ecens:+,.0f}mcm {fcast_dod_tables['ECENS'].columns[0].replace(' Demand', '')} vs {fcast_dod_tables['ECENS'].columns[1].replace(' Demand', '')} (GFSENS {diff_gfsens:+,.0f}mcm{subject_ec46_diff})"
    
    if run_ec46:
        email_subject_change = f"{email_subject}: EC46 {diff_ec46:+,.0f}mcm {fcast_dod_tables['EC46'].columns[0].replace(' Demand', '')} vs {fcast_dod_tables['EC46'].columns[1].replace(' Demand', '')}"
    else:
        subject_hour = ' (12z)' if run_12z else ''
        email_subject_change = f"{email_subject}{subject_hour}: ECENS {diff_ecens:+,.0f}mcm {fcast_dod_tables['ECENS'].columns[0].replace(' Demand', '')} vs {fcast_dod_tables['ECENS'].columns[1].replace(' Demand', '')} (GFSENS {diff_gfsens:+,.0f}mcm)"
        
    
    
    # Construct email body
    if run_12z:
        email_body = f"""<p><b>NB: this is a truncated 12z version of the main morning report</b>
                         <br><hr>
                         <p><b>Summary:</b>
                         <br>
                         {summary_html}
                         <br>
                         <br><hr>
                         <p><b>EC and GFS Ensemble LDZ Demand Forecasts:</b>
                         <br>
                         <table>
                         <tr>
                         <td style="vertical-align: top;">{ens_html}</td>
                         <td width=5>&nbsp;</td>
                         <td style="vertical-align: top;">{plot_ens_forecast_img}</td>
                         </tr>
                         <tr>
                         <td colspan=3>Total LDZ Delta per Country (mcm):<br>{ens_country_html}</td>
                         </tr>
                         <tr>
                         <td colspan=3><br>Total Temp Delta per Country (degC):<br>{ens_temp_delta_html}</td>
                         </tr>
                         </table>
                         <br><hr>
                         <p><b>Forecast Delta {days_back}d History (ECENS 12z vs 0z)</b>
                         <br>
                         {dod_heatmap_img}
                         <br><hr>
                        """
    elif run_ec46:
        email_body = f"""<p><b>NB: this is a truncated EC46 version of the main morning report</b>
                         <br><hr>
                         <p><b>Summary:</b>
                         <br>
                         {summary_html}
                         <br>
                         <br><hr>
                         <p><b>EC Extended 46d LDZ Demand Forecast:</b>
                         <table>
                         <tr>
                         <td style="vertical-align: top;">{ec46_html}</td>
                         <td width=5>&nbsp;</td>
                         <td style="vertical-align: top;">{plot_ext_forecast_img}<br><br>Total Change per Country (mcm):<br>{ec46_country_html}<br><br>Temp Delta per Country (degC):<br>{ec46_temp_delta_html}</td>
                         </tr>
                         </table>
                         <br><hr>
                         <p><b>Forecast Delta {days_back}d History (EC46)</b>
                         <br>
                         {dod_heatmap_img}
                         <br><hr>
                        """
    else:
        email_body = f"""<b>Summary:</b>
                         <br>
                         {summary_html}
                         <br>
                         <br><hr>
                         <p><b>EC and GFS Ensemble LDZ Demand Forecasts:</b>
                         <br>
                         <table>
                         <tr>
                         <td style="vertical-align: top;">{ens_html}</td>
                         <td width=5>&nbsp;</td>
                         <td style="vertical-align: top;">{plot_ens_forecast_img}</td>
                         </tr>
                         <tr>
                         <td colspan=3>Total LDZ Delta per Country (mcm):<br>{ens_country_html}</td>
                         </tr>
                         <tr>
                         <td colspan=3><br>Total Temp Delta per Country (degC):<br>{ens_temp_delta_html}</td>
                         </tr>
                         </table>                         
                         <br><hr>
                         <p><b>Forecast Delta {days_back}d History (ECENS 0z)</b>
                         <br>
                         {dod_heatmap_img}
                         <br><hr>
                         <p><b>Weather Year and Normals Storage % Fill Distribution:</b>
                         <br>
                         {boxplot_storage_img}
                         <br>Note 1: WN = Weather Normals, WY = Weather Years
                         <br>Note 2: Storage capacity = {basecase_future_stocks[datetime(2026,10,31)]['capa']/1000:,.0f}bcm
                         <br><hr>
                         <p><b>Monthly Forecast Comparison:</b>
                         <br>
                         {plot_monthly_shading_img}
                         <br><br>
                         {plot_monthly_wy_img}
                         <br><hr>
                         <p><b>LDZ Demand Impact Average Per degC Change (10yr Weather Normal):</b>
                         <br>
                         <table>
                         <tr>
                         <td style='vertical-align:top'>{ldz_bump_per_deg_mcmd_html}</td><td width='15px'></td><td style='vertical-align:top'>{ldz_bump_per_deg_bcm_html}</td>
                         </tr>
                         </table>
                         <br>Note 1: The above is calculated from the full 10yr Weather Normal dataset below.
                         <br>Note 2: To give a shorthand view on impact, temperature increases AND decreases are considered together (even though a downside skew exists whereby colder temps have a slightly greater impact on LDZ).
                         <br><hr>
                         <p><b>LDZ Demand Temperature Scenarios vs Normals (delta vs baseline):</b>
                         <br>
                         {ldz_bump_mcmd_html}
                         <br>
                         {ldz_bump_bcm_html}
                         <br>Note 1: The forecasts are generated per month (for each country, then aggregated) by bumping the different weather normals in 0.5deg C steps.
                         <br>Note 2: only temperatures are adjusted whilst wind speed and precip remain unchanged (although these are less important model features).
                         <br>Note 3: Historical 2024 demand figures are used to generate the baseline (only for the autoregressive feature of the models)
                         <br><hr>
                         <p><b>EC and GFS Ensemble Day Ahead Forecast Error:</b>
                         <br>
                         {plot_da_error_heatmaps_img}
                         <br>Note 1: The latest actual demand could still be missing final data (so error could be distorted/incorrect).
                         <br><hr>
                         <p><b><u>Notes:</u></b>
                         <br>Report shows aggregated Total LDZ Demand for country perimeter: BE, DE, FR, GB, IT, NL
                         <br>Basecase balance applicable for {balances['Basecase']['ref_date'].strftime('%d %b')} generated at {balances['Basecase']['saved_date_utc'].strftime('%d %b %H:%M')} UTC
                         <br>Demand values mcm, temp deg C.
                         <br>Latest 00z EC Ensemble Mean, EC46 and GFS Ensemble Mean weather forecasts are all queried from Bloomberg.
                         <br>For the EC46, this report shows the previous days forecast.
                         <br>Forecasts are produced per country (using new LDZ Demand Models) and aggregated to our perimeter.
                         <br>Historic LDZ demand actuals are queried from Commodity Essentials.
                         <br>The "weather normals" are not LDZ demand normals but rather forecasts produced by using Bloombergs 5, 10 and 30 year weather normals as inputs to the models per country. 
                        """
    
    return email_subject_change, email_body
    
    
    
    
    