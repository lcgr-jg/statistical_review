import os
import json
import base64
import logging
import warnings
import datetime as dt
import pandas as pd
import numpy as np
#import networkx as nx
import matplotlib.pyplot as plt
from io import BytesIO
from pathlib import Path
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from tempfile import gettempdir
from tqdm import tqdm

from confluent_kafka import Producer
from shapely.geometry import Point, Polygon
from sklearn.model_selection import train_test_split, GridSearchCV, ParameterGrid
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report
from statsmodels.api import OLS, add_constant
from statsmodels.tsa.holtwinters import SimpleExpSmoothing

# Custom modules
from jain_commods.core.interfaces.sqldb import SQLdb
from jain_commods.core.interfaces.bloomberg import BBGQuery
from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.util.htmlutils import df2html

#from xgboost import XGBRegressor
#from sklearn.metrics import r2_score

REPORTS_PATH = Path(__file__).parent.resolve()

n_years = 4 #6
plot_years = 3

months_lookback = 12*n_years

HISTORICAL_PERIOD_DAYS = 1

def calculate_transition_probabilities_with_graph(data, locations, time_horizon_days=7):
    """
    Calculate transition probabilities, average times, conditional probabilities,
    and detailed trip data for vessels entering the NWE perimeter (excluding entries from NWE itself).
    Visualize results with a graph network and Bayesian probabilities.
    Includes detailed progress updates.
    """
    import warnings
    import networkx as nx
    import matplotlib.pyplot as plt
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    from sklearn.metrics import classification_report
    from shapely.geometry import Point, Polygon
    from tqdm import tqdm
    import numpy as np

    # Suppress specific sklearn warnings
    warnings.filterwarnings("ignore", message="X does not have valid feature names, but")

    logging.info("Starting the calculation of vessel transition probabilities...")

    # Step 1: Assign zones based on coordinates
    logging.info("Step 1: Assigning zones to vessel positions...")
    data['zone'] = data.apply(
        lambda row: next(
            (zone for zone, coords in locations.items() if Polygon(coords).contains(Point(row['longitude'], row['latitude']))),
            None
        ),
        axis=1
    )

    # Drop rows where the zone could not be determined
    initial_count = len(data)
    data = data.dropna(subset=['zone'])
    logging.info(f"Step 1 complete: Dropped {initial_count - len(data)} rows where the zone could not be determined.")

    # Step 2: Sort data and compute transitions
    logging.info("Step 2: Sorting data by vessel and timestamp, and calculating transitions...")
    data = data.sort_values(['imo', 'last_seen'])
    data['next_zone'] = data.groupby('imo')['zone'].shift(-1)
    data['transition'] = data['zone'] + '->' + data['next_zone']
    logging.info("Step 2 complete: Transitions calculated.")

    # Step 3: Compute time differences
    logging.info("Step 3: Calculating time differences between transitions...")
    data['time_diff'] = data.groupby('imo')['last_seen'].diff().dt.total_seconds() / (60 * 60 * 24)

    # Step 4: Filter transitions leading to NWE from other zones
    logging.info("Step 4: Filtering transitions leading to the NWE perimeter from other zones...")
    data_to_nwe = data[(data['next_zone'] == 'NWE') & (data['zone'] != 'NWE')]
    logging.info(f"Step 4 complete: Found {len(data_to_nwe)} transitions leading to NWE from other zones.")

    # Step 5: Calculate results for each ship
    logging.info("Step 5: Calculating detailed results for transitions to NWE...")
    results = {}
    total_entries_per_zone = {}

    for imo, group in tqdm(data_to_nwe.groupby('imo'), desc="Processing vessels to NWE"):
        total_transitions = len(group)
        from_zones = group['zone'].value_counts()
        avg_time = group.groupby('zone')['time_diff'].mean()
        trip_details = group[['zone', 'last_seen', 'time_diff']]

        # Summarize total entries per zone across all ships
        for zone, count in from_zones.items():
            if zone not in total_entries_per_zone:
                total_entries_per_zone[zone] = 0
            total_entries_per_zone[zone] += count

        results[imo] = {
            'total_transitions': total_transitions,
            'from_zones': from_zones.to_dict(),
            'average_times': avg_time.to_dict(),
            'trip_details': trip_details
        }

    logging.info("Step 5 complete: Calculated detailed results for all vessels.")

    # Step 6: Print structured results
    logging.info("Step 6: Printing structured results for transitions to NWE...")
    for imo, res in results.items():
        print(f"IMO: {imo}")
        print(f"  Total Transitions to NWE: {res['total_transitions']}")
        print(f"  From Zones: {res['from_zones']}")
        print(f"  Average Times (days): {res['average_times']}")
        print(f"  Trip Details (zone -> NWE):")
        print(res['trip_details'])
        print()

    # Print total entries per zone across all ships
    print("Total Entries into NWE from each zone across all ships:")
    for zone, total in total_entries_per_zone.items():
        print(f"  {zone}: {total}")

    # Step 7: Prepare data for conditional probability modeling
    logging.info("Step 7: Preparing data for Bayesian/conditional probability modeling...")
    data = data.dropna(subset=['next_zone'])
    le = LabelEncoder()
    data['zone_encoded'] = le.fit_transform(data['zone'])
    data['next_zone_encoded'] = le.transform(data['next_zone'])

    features = ['zone_encoded', 'time_diff']
    target = 'next_zone_encoded'

    X = data[features]
    y = data[target]

    # Split data
    logging.info("Step 7: Splitting data into training and testing sets...")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Step 8: Train Random Forest for Bayesian modeling
    logging.info("Step 8: Training Random Forest model to compute conditional probabilities...")
    model = RandomForestClassifier(random_state=42)
    model.fit(X_train, y_train)
    logging.info("Step 8 complete: Model trained.")

    # Evaluate
    y_pred = model.predict(X_test)
    logging.info("Step 8: Model evaluation metrics:")
    logging.info("\n" + classification_report(y_test, y_pred, target_names=le.classes_))

    # Step 9: Build a conditional probability graph
    logging.info("Step 9: Building a conditional probability graph...")
    transition_graph = nx.DiGraph()
    for _, row in data.iterrows():
        current_zone = row['zone']
        next_zone = row['next_zone']
        if current_zone != next_zone:  # Exclude self-loops
            feature_array = row[features].values.reshape(1, -1)
            prob = model.predict_proba(feature_array)[0][le.transform([next_zone])[0]]
            if transition_graph.has_edge(current_zone, next_zone):
                transition_graph[current_zone][next_zone]['weight'] += prob
            else:
                transition_graph.add_edge(current_zone, next_zone, weight=prob)

    # Normalize edge weights
    logging.info("Step 9: Normalizing edge weights in the graph...")
    for node in transition_graph.nodes():
        total_weight = sum(data['weight'] for _, _, data in transition_graph.out_edges(node, data=True))
        if total_weight > 0:
            for _, _, data in transition_graph.out_edges(node, data=True):
                data['normalized_weight'] = data['weight'] / total_weight

    # Step 10: Visualize the graph
    logging.info("Step 10: Visualizing the conditional probability graph...")
    pos = nx.spring_layout(transition_graph, seed=42)
    plt.figure(figsize=(12, 8))
    nx.draw(
        transition_graph, pos, with_labels=True, node_size=2000, node_color="lightblue",
        font_size=10, font_weight="bold", edge_color="gray"
    )
    edge_labels = {
        (u, v): f"{d['normalized_weight']:.2f}"
        for u, v, d in transition_graph.edges(data=True)
    }
    nx.draw_networkx_edge_labels(
        transition_graph, pos, edge_labels=edge_labels, font_color="red"
    )
    plt.title("Conditional Transition Probabilities to NWE")
    plt.show()

    logging.info("Transition probabilities calculation and visualization completed.")
    return results, transition_graph, total_entries_per_zone

def get_report(ce_user, ce_pass, logging):
    
    images = []
    
    #logging = logging.getLogger(__name__)

    # Calculate the start date based on the variable number of months
    start_date = (datetime.now() - relativedelta(months=months_lookback)).strftime("%Y-%m-%d")

    # Configure logging
    #logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    # Initial log for script execution
    logging.info("Starting LNG Polygon Volume Analysis")
    
    # Log CElink initialization
    logging.info("Initializing CElink...")

    ce = CElink(ce_user, ce_pass)

    # Log data retrieval
    logging.info("Fetching regasification data...")

    df_regas = ce.eugasopdata(assets='457,676,687,1779,467,476', unit='mcm', variable='withdrawal')
    df_regas = df_regas.dropna()
    df_regas.index = pd.to_datetime(df_regas['Date'], format='%d-%b-%Y')
    df_regas.drop(columns=['DateExcel', 'Date'], inplace=True)
    df_regas.columns = ['BE', 'DE', 'FR', 'UK', 'IT', 'NL']
    df_regas['Total'] = df_regas.sum(axis=1)

    logging.info("Regasification data loaded successfully.")

    locations = {
        #"NWE": [ 
        #(-1.484225, 43.252775), (9.600000, 54.028446), (8.555358, 58.416661), (5.244432, 59.463539), 
        #(-3.032884, 58.584074), (-3.299894, 56.077401), (1.025671, 51.007890), (-4.154327, 53.076737), 
        #(-6.023398, 53.012527), (-10.188757, 51.774293), (-13.766693, 46.689216), (-9.067314, 43.057991), 
        #(-1.484225, 43.252775)
        #]
        #,
        
        "NWE": [
        (-1.484225, 43.252775), (9.600000, 54.028446), (8.555358, 58.416661), (5.244432, 59.463539), 
        (-3.032884, 58.584074), (-3.299894, 56.077401), (-10.188757, 51.774293), (-13.766693, 46.689216), 
        (-9.067314, 43.057991), (-1.484225, 43.252775)
        ],
        
        "Europe_Ext": [
            (-16.978762, 43.295896), (-9.834162, 36.223094), (-5.894616, 35.682579), (-0.753175, 35.574033),
            (10.798375, 37.346077), (19.411958, 34.864901), (22.817328, 37.080194), (21.281573, 57.062242),
            (10.531287, 59.382076), (-1.354122, 60.254813), (-10.368338, 54.393872), (-16.978762, 43.295896)
        ]
    }

    # Define the SQL query to fetch all data from the table
    query = "SELECT * FROM commod_research.lng_polygons"

    # Execute the query and retrieve the data as a DataFrame
    sqldb = SQLdb(logintype='prod')
    with sqldb.engine.begin() as conn:
        polygon_df = pd.read_sql(query, conn)

    #Method to convert DataFrame to dictionary format
    def dataframe_to_location_dict(df):
        locations = {}
        for _, row in df.iterrows():
            name = row['name']
            # Extract coordinates from the 'definition' column
            polygon_str = row['definition']
            # Remove 'POLYGON((' and '))', then split by commas
            points = polygon_str.replace('POLYGON((', '').replace('))', '').split(',')
            # Convert each point to a tuple of floats
            coordinates = [tuple(map(float, point.split())) for point in points]
            locations[name] = coordinates
        return locations
    
    '''
    # Convert DataFrame
    locations_db = dataframe_to_location_dict(polygon_df)
    
    locations = {**locations, **locations_db}

    # Keys to keep (with desired order)
    selected_location_keys = ["NWE",  "English Channel", "Strait of Gibraltar", "Qatar Extended", "Cape of Good Hope", "Suez Canal"]  # Note: list preserves the order

    # Filtered dictionary in the desired order
    locations = {key: locations[key] for key in selected_location_keys if key in locations}
    '''
    
    # Define the SQL query to fetch all data from the table
    query = f"""SELECT 
                    imo, 
                    vessel_name, 
                    last_seen, 
                    gas_capacity_cubic_meters, 
                    draft_percent, 
                    destination,
                    longitude, 
                    latitude,
                    reported_speed_knots
                FROM 
                    commod_research.bbg_ship_imo_data
                WHERE 
                    last_seen >= '{start_date}'"""

    # Execute the query and retrieve the data as a DataFrame
    sqldb = SQLdb(logintype='prod')
    with sqldb.engine.begin() as conn:
        data = pd.read_sql(query, conn)
    data = data.drop_duplicates()

    # Load and preprocess data
    data['last_seen'] = pd.to_datetime(data['last_seen'], format='ISO8601') #errors='coerce')
    data = data.dropna(subset=['last_seen'])

    # Log the start of calculations
    logging.info("Starting calculation of weighted LNG volumes and IMO IDs for each zone.")

    data['lng_volume_mcm'] = (
        data['gas_capacity_cubic_meters'] *
        data['draft_percent'] / 100 *
        600 * 0.9 * 1e-6 * 1.1
    )

    # Calculate transition probabilities and get the transition graph
    #transition_probabilities, transition_graph = calculate_transition_probabilities_with_graph(data, locations)

    # Initialize results dictionary
    #zone_results = {zone: {'lng_volume_mcm': [], 'imo_ids': [], 'entered': [], 'exited': []} for zone in locations.keys()}
    #zone_dates = {zone: [] for zone in locations.keys()}
    #imo_history = {zone: set() for zone in locations.keys()}

    # Generate date range for processing
    date_range = pd.date_range(
        start=data['last_seen'].min().normalize(),
        end=data['last_seen'].max().normalize(),
        freq="D"
    ).normalize()

    # Add the current UTC timestamp as the final entry
    current_timestamp = pd.Timestamp.now(tz="UTC")
    date_range_extended = date_range.append(pd.DatetimeIndex([current_timestamp]))

    # Initialize results dictionary for zones
    zone_dfs = {}

    # Iterate over each zone first
    for zone, coordinates in tqdm(locations.items(), desc="Processing Zones"):
    
        zone_data = {"date": [], "lng_volume_mcm": [], "daily_change": [], "entered": [], "exited": []}
        imo_history = set()
        previous_positions = pd.DataFrame()  # To track positions from the prior day
        previous_total_volume = 0  # Initialize previous day's total volume

        # Initialize previous_positions with proper columns
        previous_positions = pd.DataFrame(columns=['imo', 'vessel_name', 'lng_volume_mcm', 'destination', 'longitude', 'latitude', 'last_seen'])

        # Iterate over extended dates
        for i, _date in enumerate(date_range_extended):
            # Define the end of day for comparison
            if _date == current_timestamp.normalize():  # For today, use current timestamp
                end_of_day = current_timestamp
            else:
                end_of_day = _date.replace(hour=23, minute=59, second=59)

            historical_start_date = end_of_day - timedelta(days=HISTORICAL_PERIOD_DAYS)

            # Filter historical data up to the current date
            historical_positions = data[
                (data['last_seen'].dt.tz_convert('UTC') >= historical_start_date)
                & (data['last_seen'].dt.tz_convert('UTC') <= end_of_day)
            ]

            # Get the most recent positions for each IMO on the current day
            most_recent_positions = historical_positions.loc[
                historical_positions.groupby("imo")["last_seen"].idxmax()
            ].reset_index(drop=True)

            # Filter positions within the polygon
            polygon = Polygon(coordinates)
            in_zone = most_recent_positions[
                most_recent_positions.apply(
                    lambda row: polygon.contains(Point(row['longitude'], row['latitude'])), axis=1
                )
            ]

            # Get latest positions grouped by IMO (ensures one position per IMO)
            latest_positions = in_zone.groupby("imo").last().reset_index()

            # Calculate total LNG volume for the current day
            total_volume = latest_positions["lng_volume_mcm"].sum().round().astype(int)

            # Calculate daily change accurately
            daily_change = total_volume - previous_total_volume

            # Determine IMOs and volumes for ships entering and exiting
            current_imos = set(latest_positions["imo"].unique())

            # Compare current positions with previous positions strictly
            if not previous_positions.empty:
                entered_imos = current_imos - set(previous_positions["imo"])
                exited_imos = set(previous_positions["imo"]) - current_imos
            else:
                entered_imos = current_imos
                exited_imos = set()

            # Filter entered/exited ship details strictly based on IMO IDs
            entered_details = latest_positions[latest_positions["imo"].isin(entered_imos)][
                ["vessel_name", "imo", "lng_volume_mcm", "destination"]
            ]
            exited_details = previous_positions[previous_positions["imo"].isin(exited_imos)][
                ["vessel_name", "imo", "lng_volume_mcm", "destination"]
            ]

            entered_volume = entered_details['lng_volume_mcm'].sum()
            exited_volume = exited_details['lng_volume_mcm'].sum()

            # Append results for the current date
            if not (end_of_day.date() == datetime.now().date() and end_of_day.hour == 23 and current_timestamp.hour != 23 and current_timestamp.minute != 59):
                if i == 0 or zone_data["date"][-1] != end_of_day:  # Avoid duplicates
                    zone_data["date"].append(end_of_day)
                    zone_data["lng_volume_mcm"].append(total_volume)
                    zone_data["daily_change"].append(daily_change)
                    zone_data["entered"].append({
                        "date": end_of_day,
                        "entered_ships": entered_details,
                        "entered_volume": entered_volume
                    })
                    zone_data["exited"].append({
                        "date": end_of_day,
                        "exited_ships": exited_details,
                        "exited_volume": exited_volume
                    })

            # Update IMO history, previous positions, and previous total volume
            imo_history = current_imos
            previous_positions = latest_positions  # Keep the latest positions for the next day's comparison
            previous_total_volume = total_volume


        # Convert zone data to a DataFrame
        zone_df = pd.DataFrame({
            "lng_volume_mcm": zone_data["lng_volume_mcm"],
            "daily_change": zone_data["daily_change"],
            "entered": zone_data["entered"],
            "exited": zone_data["exited"]
        }, index=pd.to_datetime(zone_data["date"]).tz_localize(None))

        # Store in zone_dfs dictionary
        zone_dfs[zone] = zone_df


    # Kafka producer settings
    kafka_server = 'kafka1.jainglobal.net:9092,kafka2.jainglobal.net:9092'

    # Email function
    def produce_email_body(body, images=None):
        """Send email via Kafka with inline images."""
        if images:
            # Add images to attachments and inline HTML
            image_html = ""
            for i, img in enumerate(images):
                image_type = 'png'  # Set the image type
                image_base_64 = img["data"]  # Assuming img["data"] is the base64-encoded string of the image
                image_data = f"<img src='data:image/{image_type};base64,{image_base_64}' alt='{img['name']}' style='max-width:100%; height:auto;'>"
                
                # Append the image data directly to the HTML
                image_html += f"<br>{image_data}"
            
            # Prepend the images at the top of the body
            body = image_html + body
            
        return body
        
    def save_plot_to_base64(fig):
        """Save Matplotlib figure to base64 string."""
        buf = BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        buf.close()
        plt.close(fig)
        return img_str

    email_body = "<h2>Daily Report: NWE Polygon Volume vs Regas</h2>"

    # Ensure consistent time zones for indices
    df_regas.index = pd.to_datetime(df_regas.index).tz_localize(None)  # Remove timezone info

    # Function to compute moving averages
    def apply_moving_average(df, column, window):
        return df[column].rolling(window=window, min_periods=1).mean()

    # Test a range of moving average windows
    ma_windows = range(3, 31, 1)  # Test moving averages from 3 to 30 days

    # Determine the range of years in the dataset dynamically
    years = pd.date_range(start=start_date, end=pd.Timestamp.now(), freq='YE').year
    years = np.append(years, pd.Timestamp.now().year)  # Add the current year if not already included
    years = years[years >= int(start_date[:4])+1]  # Ensure years from start_date onwards

    # Process only selected keys
    selected_keys = ['NWE']  # Replace with the actual keys you want

    logging.info('Querying Bloomberg...')
    bbg_session = BBGQuery(p_on_server=True)
    start_date = zone_dfs['NWE'].index[0]
    end_date = dt.datetime.today()
    ttf_df = bbg_session.fetch_hist("TZT1 COMDTY",
                                    ["PX_LAST"],
                                    start_date,
                                    end_date)

    '''
    rd = {
        'HistoricalDataRequest': {
        'securities': ['TZT1 COMDTY'],
        'fields': [
            'PX_LAST',         # Last price (Close)
            #'PX_OPEN',         # Open price
            #'PX_HIGH',         # High price
            #'PX_LOW',          # Low price
            #'PX_VOLUME',       # Volume traded
            #'PX_BID',          # Bid price
            #'PX_ASK',          # Ask price
            #'PX_MID',          # Mid price (average of Bid and Ask)
            #'PX_SETTLE',       # Settlement price
        ],
        'startDate': zone_dfs['NWE'].index[0].strftime('%Y%m%d'),
        'endDate': dt.datetime.today().strftime('%Y%m%d')
        }
    }

    bq = blp.BlpQuery().start()
    data_ = bq.query(rd, collector=list)
    bq.stop()

    # Extract the relevant data for the DataFrame
    security = data_[0]['security']
    data_points = data_[0]['data']

    # Convert to DataFrame
    ttf_df = pd.DataFrame(data_points)

    # Convert the 'date' column to datetime
    ttf_df['date'] = pd.to_datetime(ttf_df['date'])
    
    # Set 'date' column as the index
    ttf_df.set_index('date', inplace=True)
    ttf_df = ttf_df.rename(columns={"PX_LAST": "TTF Front Month"})
    
    ''' 

    ttf_df.columns = ['TTF Front Month']
    ttf_df.index = pd.to_datetime(ttf_df.index)

    for zone in selected_keys:
        logging.info(f"Processing zone: {zone}")

        # Extract LNG volume data for the current zone
        zone_df = zone_dfs[zone]
        
        zone_df.index = zone_df.index.tz_localize(None)
        zone_df.index = pd.to_datetime(zone_df.index).normalize()
        zone_df.index = pd.DatetimeIndex(zone_df.index)
        
        zone_df = zone_df[zone_df.index >= start_date]  # Apply the start_date filter
        
        if zone_df.empty:
            logging.warning(f"Zone {zone} has no data. Skipping...")
            continue

        # Merge with regression table
        merged_df = df_regas.merge(zone_df[['lng_volume_mcm']], left_index=True, right_index=True, how='inner')
        merged_df = merged_df.replace([np.inf, -np.inf], np.nan).ffill().bfill().dropna(axis=0)

        if merged_df.empty:
            logging.warning(f"Zone {zone} has no matching data after merge. Skipping...")
            continue

        # Initialize variables to track the best R² and parameters
        best_r2 = -1
        best_ma_window = None
        best_model = None
        best_x = None
        best_y = None

        # Test the same moving average window for both time series
        for ma_window in ma_windows:
            # Apply moving averages
            merged_df['lng_volume_ma'] = apply_moving_average(merged_df, 'lng_volume_mcm', ma_window)
            merged_df['regas_total_ma'] = apply_moving_average(merged_df, 'Total', ma_window)

            # Drop rows with NaNs introduced by moving averages
            filtered_data = merged_df[['lng_volume_ma', 'regas_total_ma']].dropna()

            if filtered_data.empty:
                continue

            x = filtered_data['lng_volume_ma']
            y = filtered_data['regas_total_ma']

            # Fit regression model
            scatter_X = add_constant(x)  # Add constant for intercept
            scatter_model = OLS(y, scatter_X).fit()

            # Update the best model if this R² is higher
            if scatter_model.rsquared > best_r2:
                best_r2 = scatter_model.rsquared
                best_ma_window = ma_window
                best_model = scatter_model
                best_x = x
                best_y = y

        if best_model is None:
            logging.warning(f"No valid model found for zone {zone}. Skipping...")
            continue

        # Print best results for the zone
        print(f"\nZone: {zone}")
        print(f"Best R²: {best_r2:.4f}")
        print(f"Best MA Window: {best_ma_window} days")

        best_ma_window_str = str(best_ma_window)
        
        # Plot each year in a separate row
        years = years[-n_years-1:]
        
        #fig, axes = plt.subplots(nrows=len(years), ncols=1, figsize=(10, 6 * len(years)))
        #fig, axes = plt.subplots(nrows=len(years), ncols=1, figsize=(12, 8))
        #if len(years) == 1:  # Handle single year case
        #    axes = [axes]

        # Combine data for the two years and plot a continuous plot
        #fig, ax = plt.subplots(figsize=(12, 8))

        # Combine data for the two years into one DataFrame
        #combined_data = pd.concat([
        #    merged_df.loc[f"{year}-01-01":f"{year}-12-31"] for year in years
        #])
        
        combined_data = pd.concat([
            merged_df.loc[f"{year}-01-01":f"{year}-12-31"] for year in years[-plot_years:]
        ])

        # Ensure the index is sorted for plotting
        combined_data = combined_data.sort_index()

        if combined_data.empty:
            logging.warning(f"No data available for {zone} in the selected years. Skipping plot...")
        else:
            # Create a new figure and axis for the plot with consistent size
            fig, ax = plt.subplots(figsize=(12, 8))  # Ensure consistent size

            # Plot the LNG volume data on the left y-axis
            ax.plot(
                combined_data.index,
                combined_data['lng_volume_mcm'],
                label=f'{zone} LNG Volume',
                color='blue',
            )
            ax.set_ylabel('LNG Volume (mcm)', color='blue')
            ax.tick_params(axis='y', labelcolor='blue')

            # Overlay moving averages for LNG volume
            lng_volume_ma = combined_data['lng_volume_mcm'].rolling(best_ma_window, min_periods=1).mean()
            ax.plot(
                lng_volume_ma.index,
                lng_volume_ma,
                label=f'MA ({best_ma_window} days) LNG Volume',
                color='cyan',
                linestyle='solid',
            )

            # Plot the regas data on the right y-axis
            ax2 = ax.twinx()
            ax2.plot(
                combined_data.index,
                combined_data['Total'],
                label=f'Total (Regas)',
                color='red',
                linestyle='dashed',
            )
            ax2.set_ylabel('Regas Total (mcm)', color='red')
            ax2.tick_params(axis='y', labelcolor='red')

            # Overlay moving averages for regas data
            regas_ma = combined_data['Total'].rolling(best_ma_window, min_periods=1).mean()
            ax2.plot(
                regas_ma.index,
                regas_ma,
                label=f'MA ({best_ma_window} days) Total (Regas)',
                color='orange',
                linestyle='solid',
            )

            # Title and grid for the continuous plot
            ax.set_title(f'Polygon LNG Volume vs. Regas for Zone: {zone}')
            ax.grid()

            # Add legends
            ax.legend(loc='upper left', fontsize='small')
            ax2.legend(loc='upper right', fontsize='small')


        """
        for ax, year in zip(axes, years):
            # Filter data for the specific year
            year_start = f"{year}-01-01"
            year_end = f"{year}-12-31"
            zone_year_data = merged_df.loc[year_start:year_end]

            if zone_year_data.empty:
                logging.warning(f"No data available for {zone} in {year}. Skipping...")
                continue

            # Plot the LNG volume data on the left y-axis
            ax.plot(
                zone_year_data.index,
                zone_year_data['lng_volume_mcm'],
                label=f'{zone} LNG Volume ({year})',
                color='blue',
            )
            ax.set_ylabel('LNG Volume (mcm)', color='blue')
            ax.tick_params(axis='y', labelcolor='blue')
            ax.legend(loc='upper left')

            # Plot the regas data on the right y-axis
            ax2 = ax.twinx()
            ax2.plot(
                zone_year_data.index,
                zone_year_data['Total'],
                label=f'Total (Regas) ({year})',
                color='red',
                linestyle='dashed',
            )
            ax2.set_ylabel('Regas Total (mcm)', color='red')
            ax2.tick_params(axis='y', labelcolor='red')
            ax2.legend(loc='upper right')

            # Overlay moving averages
            zone_year_ma = zone_year_data['lng_volume_mcm'].rolling(best_ma_window, min_periods=1).mean()
            regas_year_ma = zone_year_data['Total'].rolling(best_ma_window, min_periods=1).mean()

            # Plot moving averages
            ax.plot(
                zone_year_ma.index,
                zone_year_ma,
                label=f'MA ({best_ma_window} days) LNG Volume ({year})',
                color='cyan',
                linestyle='solid',
            )
            ax2.plot(
                regas_year_ma.index,
                regas_year_ma,
                label=f'MA ({best_ma_window} days) Total (Regas) ({year})',
                color='orange',
                linestyle='solid',
            )

            # Title and grid for the specific year
            ax.set_title(f'Polygon LNG Volume v. Regas for Zone: {zone} - Year: {year}')
            ax.grid()

            # Ensure moving averages appear in the legend
            ax.legend(loc='upper left', fontsize='small')
            ax2.legend(loc='upper right', fontsize='small')
        """
        
        image = save_plot_to_base64(fig)
        images.append({"name": f"{zone}_plot.png", "data": image})

        # Adjust layout to prevent overlapping
        #plt.tight_layout()
        #plt.show()

        # Ensure consistent time zones for indices
        df_regas.index = pd.to_datetime(df_regas.index).tz_localize(None)  # Remove timezone info
        
        # Filter numeric columns to avoid issues with .diff()
        numeric_cols = merged_df.select_dtypes(include=[np.number]).columns
        merged_df = merged_df[numeric_cols]

        merged_df = merged_df.rename(columns={'lng_volume_ma': f'lng_volume_{best_ma_window_str}d_ma', 
                            'regas_total_ma': f'regas_total_ma_{best_ma_window_str}d_ma'})
        
        merged_df = merged_df.loc[~merged_df.index.duplicated(keep='first')]
        ttf_df = ttf_df.loc[~ttf_df.index.duplicated(keep='first')]

        # Concatenate
        merged_df = pd.concat([merged_df, ttf_df], axis=1).ffill().bfill().dropna(axis=0)
        
        # Define date range for the last two weeks, 12 weeks, and 12 months
        two_weeks_ago = pd.Timestamp.now() - timedelta(days=14)
        twelve_weeks_ago = pd.Timestamp.now() - timedelta(weeks=12)
        twelve_months_ago = pd.Timestamp.now() - pd.DateOffset(months=12)

        # Filter data for the last two weeks
        recent_data = merged_df.loc[two_weeks_ago:]

        # Calculate day-on-day changes
        day_on_day_changes = recent_data.diff()
        
        # Calculate weekly changes (12-week lookback)
        weekly_changes = (
            merged_df.loc[twelve_weeks_ago:]
            .resample('W')
            .mean()
            .diff()
        )

        weekly_changes.index = weekly_changes.index.to_series().apply(
            lambda x: f"Week {x.isocalendar().week}-{x.year}"
        )
        
        # Calculate monthly changes (12-month lookback)
        monthly_changes = (
            merged_df.loc[twelve_months_ago:]
            .resample('ME')
            .mean()
            .diff()
        )

        monthly_changes.index = monthly_changes.index.to_series().apply(
            lambda x: x.strftime("%B-%Y")
        )
        
        # Define excluded columns
        excluded_columns = ['TTF Front Month']
        
        # Function to process DataFrame columns
        def process_dataframe(df, excluded_columns):
            processed_df = df.copy()
            for col in processed_df.columns:
                if col in excluded_columns:
                    processed_df[col] = processed_df[col].fillna(0).round(2)  # Round to 2 decimals
                else:
                    processed_df[col] = processed_df[col].fillna(0).round(0).astype(int)  # Round to 0 and convert to int
            return processed_df
        
        # Apply the processing to each DataFrame
        recent_data_processed = process_dataframe(recent_data, excluded_columns)
        day_on_day_changes_processed = process_dataframe(day_on_day_changes, excluded_columns)
        weekly_changes_processed = process_dataframe(weekly_changes, excluded_columns)
        monthly_changes_processed = process_dataframe(monthly_changes, excluded_columns)
        
        # --- Initialize Parameters ---
        best_r2 = -1
        best_backward_window = None
        best_forward_window = None
        best_model = None

        # Step 1: Determine Best Backward and Forward MA Windows for Regression
        for backward_window in range(3, 31):  # Test backward MA windows (3 to 30 days)
            merged_df[f'lng_volume_ma_{backward_window}'] = (
                merged_df['lng_volume_mcm'].rolling(window=backward_window, min_periods=1).mean()
            )
            
            for forward_window in range(1, 15):  # Test forward MA windows (1 to 14 days)
                # Target: Forward-moving average for regasification
                merged_df[f'regas_ma_forward_{forward_window}'] = (
                    merged_df['Total'].rolling(window=forward_window, min_periods=1).mean().shift(-forward_window)
                )

                # Prepare data for regression
                data_ = merged_df.dropna(subset=[f'lng_volume_ma_{backward_window}', f'regas_ma_forward_{forward_window}'])
                if data_.empty:
                    continue
                
                x = data_[f'lng_volume_ma_{backward_window}']
                y = data_[f'regas_ma_forward_{forward_window}']

                # Fit OLS Regression
                model = OLS(y, add_constant(x)).fit()
                if model.rsquared > best_r2:
                    best_r2 = model.rsquared
                    best_backward_window = backward_window
                    best_forward_window = forward_window
                    best_model = model

        # Log Best Combination
        logging.info(f"Best Backward MA: {best_backward_window} days, Best Forward MA: {best_forward_window} days (R²: {best_r2:.4f})")

        # Step 2: Forecast Next Day Using Regression
        merged_df['lng_volume_ma_best'] = merged_df['lng_volume_mcm'].rolling(window=best_backward_window, min_periods=1).mean()

        # Prepare the training data
        regression_data = merged_df.dropna(subset=['lng_volume_ma_best', f'regas_ma_forward_{best_forward_window}'])
        x_reg = regression_data['lng_volume_ma_best']
        y_reg = regression_data[f'regas_ma_forward_{best_forward_window}']

        # Fit the final regression model
        best_model = OLS(y_reg, add_constant(x_reg)).fit()

        # Forecast for the next day
        latest_input = pd.DataFrame({'const': 1, 'lng_volume_ma_best': [merged_df['lng_volume_ma_best'].iloc[-1]]})
        regression_forecast = best_model.predict(latest_input).iloc[0]
        
        # Determine the start and end dates of the regression training data
        regression_start_date = x_reg.index.min().strftime('%Y-%m-%d')
        regression_end_date = x_reg.index.max().strftime('%Y-%m-%d')

        # Step 3: Use the regression model to predict and plot forecasts vs actual regas numbers
        logging.info(f"Generating predictions using the best model for {zone}...")

        # Filter data for the time range defined by the combined_data
        combined_data = pd.concat([
            merged_df.loc[f"{year}-01-01":f"{year}-12-31"] for year in years[-plot_years:]
        ])
        
        # Ensure combined_data is sorted for plotting
        combined_data = combined_data.sort_index()

        # Apply the regression model to the filtered data
        combined_data['regas_forecast'] = best_model.predict(add_constant(combined_data['lng_volume_ma_best']))
        combined_data = combined_data.dropna(subset=['regas_forecast', 'Total'])

        if combined_data.empty:
            logging.warning(f"No data available for {zone} in the selected years. Skipping plot...")
        else:
            # Create a new figure and axis for the plot
            fig, ax = plt.subplots(figsize=(12, 8))

            # Plot the actual regas total data
            ax.plot(
                combined_data.index,
                combined_data['Total'],
                label='Actual Regas Total (mcm)',
                color='red',
                linestyle='dashed',
            )

            # Plot the forecast regas total data
            ax.plot(
                combined_data.index,
                combined_data['regas_forecast'],
                label='Forecast Regas Total (mcm)',
                color='blue',
                linestyle='solid',
            )

            # Add a mirrored right-hand axis
            ax2 = ax.twinx()
            ax2.set_ylabel("Regas Total (mcm)", color='black')  # Match the label with the left axis
            ax2.tick_params(axis='y', labelcolor='black')  # Use black for tick labels for consistency

            # Synchronize the y-axis range for both sides
            ax2.set_ylim(ax.get_ylim())

            # Add title, labels, and legend
            ax.set_title(f'Regression Forecast ({best_forward_window}-day Forward MA) vs. Actual Regas Total for Zone: {zone}')
            ax.set_ylabel('Regas Total (mcm)')
            ax.set_xlabel('Date')
            ax.grid()
            ax.legend(loc='upper left')

            # Save the plot to a base64 string
            forecast_vs_actual_image = save_plot_to_base64(fig)
            images.append({"name": f"{zone}_regression_forecast_plot.png", "data": forecast_vs_actual_image})


            # Append the plot image to the email body
            #email_body += f"<h3>Regression Forecast vs. Actual Regas Total for Zone: {zone}</h3>"
            #email_body += f"<img src='data:image/png;base64,{forecast_vs_actual_image}' alt='Forecast vs Actual Regas Total'/>"

            # Log training data details for regression
            #email_body += f"<p><b>Regression Model:</b> Backward Window: {best_backward_window} days, Forward Window: {best_forward_window} days<br>"
            #email_body += f"<b>Training Period:</b> {regression_start_date} to {regression_end_date}<br>"
            #email_body += f"<b>Model R²:</b> {round(best_r2 * 100, 2)}%</p>"

            # Include additional insights (if needed)
            #email_body += "<p>Note: The regression forecasts are based on the best model using moving averages of LNG volumes and forward regasification values.</p>"

        # Ensure the index is sorted for plotting
        combined_data_lng_ttf = combined_data.copy()

        # Merge TTF data into combined_data_lng_ttf to align indices for plotting
        #combined_data_lng_ttf = combined_data_lng_ttf.merge(ttf_df, left_index=True, right_index=True, how='inner')

        # Ensure the index is sorted for plotting
        if combined_data_lng_ttf.empty:
            logging.warning(f"No data available for {zone} in the selected years. Skipping plot...")
        else:
            # Create a new figure and axis for the plot
            fig, ax = plt.subplots(figsize=(12, 8))

            # Plot the LNG volume data on the left y-axis
            ax.plot(
                combined_data_lng_ttf.index,
                combined_data_lng_ttf['lng_volume_mcm'],
                label=f'{zone} LNG Volume',
                color='blue',
            )
            ax.set_ylabel('LNG Volume (mcm)', color='blue')
            ax.tick_params(axis='y', labelcolor='blue')

            # Overlay moving averages for LNG volume
            lng_volume_ma = combined_data_lng_ttf['lng_volume_mcm'].rolling(best_ma_window, min_periods=1).mean()
            ax.plot(
                lng_volume_ma.index,
                lng_volume_ma,
                label=f'MA ({best_ma_window} days) LNG Volume',
                color='cyan',
                linestyle='solid',
            )

            # Compute a 30-day moving average for TTF price
            ttf_price_ma = combined_data_lng_ttf['TTF Front Month'].rolling(30, min_periods=1).mean()

            # Plot the TTF price data on the right y-axis
            ax2 = ax.twinx()
            ax2.plot(
                combined_data_lng_ttf.index,
                combined_data_lng_ttf['TTF Front Month'],
                label='TTF Price ($/MWh)',
                color='green',
                linestyle='solid',  # Make the line solid
            )
            # Overlay the 30-day moving average for TTF price
            ax2.plot(
                ttf_price_ma.index,
                ttf_price_ma,
                label='MA (30 days) TTF Price',
                color='limegreen',
                linestyle='dashed',
            )
            ax2.set_ylabel('TTF Price ($/MWh)', color='green')
            ax2.tick_params(axis='y', labelcolor='green')

            # Title and grid for the continuous plot
            ax.set_title(f'Polygon LNG Volume vs. TTF Price for Zone: {zone}')
            ax.grid()

            # Add legends
            ax.legend(loc='upper left', fontsize='small')
            ax2.legend(loc='upper right', fontsize='small')

        image = save_plot_to_base64(fig)
        images.append({"name": f"{zone}_LNG_TTF_plot.png", "data": image})

        # Prepare Forecast Output
        email_body += f"<h3>Next {best_forward_window}-Day Forward Average LNG Volume Forecast</h3>"
        email_body += (
            f"<p><b>Regression Model:</b> {round(regression_forecast)} mcm "
            f"(Backward LNG Polygon Horizon: {best_backward_window} days, Forward Regas Horizon: {best_forward_window} days, "
            f"Training Period: {regression_start_date} to {regression_end_date}, "
            f"R²: {round(best_r2 * 100, 2)}%)</p>"
        )

        # Construct the email body
        email_body += f"<h2>Zone: {zone}</h2>"
        email_body += f"<h4>(Note: If today's noms = 0 they are likely not nominated yet.)</h4>"
        email_body += "<h4>Last Two Weeks' Data:</h4>" + df2html(recent_data_processed.tail(14),
                                                                highlight_weekends=True, index_dt_format='%d-%b-%Y')
        email_body += "<h4>Day-on-Day Changes (Last Two Weeks):</h4>" + df2html(day_on_day_changes_processed.tail(14),
                                                                                highlight_weekends=True, index_dt_format='%d-%b-%Y')
        email_body += "<h4>Weekly Changes (Last 12 Weeks):</h4>" + df2html(weekly_changes_processed.tail(12),
                                                                        highlight_weekends=False)
        email_body += "<h4>Monthly Changes (Last 12 Months):</h4>" + df2html(monthly_changes_processed.tail(12),
                                                                            highlight_weekends=False)

    # Generate Logs for Ship Movements and Day-on-Day Changes
    entry_exit_log = """
    <h2 style="margin-bottom: 15px; border-bottom: 2px solid #ddd; padding-bottom: 5px;">
        Ship Movements and Day-on-Day Changes (Last 7 Days):
    </h2>
    """

    # Process only the last 7 days in reverse order
    for zone, df in zone_dfs.items():
        # Add spacing and distinct formatting for each zone
        entry_exit_log += f"""
        <h3 style="margin-top: 25px; margin-bottom: 10px; color: #00509E;">
            {zone}:
        </h3>
        <hr style="border: 1px solid #ccc; margin: 10px 0;">
        """

        # Filter for the last 7 days and sort in reverse order
        last_7_days_df = df.loc[df.index >= (df.index.max() - timedelta(days=7))].sort_index(ascending=False)
        
        # Compute change by subtracting the 'lng_volume_mcm' of the next row (shift(-1))
        last_7_days_df['change'] = last_7_days_df['lng_volume_mcm'] - last_7_days_df['lng_volume_mcm'].shift(-1)
        last_7_days_df['change'] = last_7_days_df['change'].round()

        for index, row in last_7_days_df.iterrows():
            date_str = index.strftime('%d-%b-%Y')
            current_volume = round(row['lng_volume_mcm'])  # Round to integer
            change = f"{round(row['change'])} mcm" if pd.notnull(row['change']) else "N/A"

            # Add a distinct section for each date
            entry_exit_log += f"""
            <h4 style="margin-top: 15px; margin-bottom: 5px; color: #0077CC;">
                <b>{date_str}:</b>
            </h4>
            <p style="margin-left: 10px;">
                <b>Total Volume:</b> {current_volume} mcm <br>
                <b>Change:</b> {change}
            </p>
            """

            # Ships that entered the zone
            if not row['entered']['entered_ships'].empty:
                entry_exit_log += "<div style='margin-left: 20px; margin-bottom: 5px;'>"
                entry_exit_log += "<span style='color:green; font-weight:bold;'>Entered Ships:</span><br>"
                for _, ship in row['entered']['entered_ships'].iterrows():
                    destination = ship['destination'] if pd.notnull(ship['destination']) else "N/A"
                    lng_volume = round(ship['lng_volume_mcm'])  # Round to integer
                    entry_exit_log += f"""
                    {ship['vessel_name']} (IMO: {ship['imo']} - LNG Volume: {lng_volume} mcm - Destination: {destination})<br>
                    """
                entry_exit_log += "</div>"
            else:
                entry_exit_log += """
                <p style="margin-left: 20px; color: green; font-style: italic;">
                    No ships entered.
                </p>
                """

            # Ships that exited the zone
            if not row['exited']['exited_ships'].empty:
                entry_exit_log += "<div style='margin-left: 20px; margin-bottom: 5px;'>"
                entry_exit_log += "<span style='color:red; font-weight:bold;'>Exited Ships:</span><br>"
                for _, ship in row['exited']['exited_ships'].iterrows():
                    destination = ship['destination'] if pd.notnull(ship['destination']) else "N/A"
                    lng_volume = round(ship['lng_volume_mcm'])  # Round to integer
                    entry_exit_log += f"""
                    {ship['vessel_name']} (IMO: {ship['imo']} - LNG Volume: {lng_volume} mcm - Destination: {destination})<br>
                    """
                entry_exit_log += "</div>"
            else:
                entry_exit_log += """
                <p style="margin-left: 20px; color: red; font-style: italic;">
                    No ships exited.
                </p>
                """

    # Add a final separator for clean formatting
    entry_exit_log += "<hr style='border-top: 2px solid #aaa; margin-top: 20px;'>"

    # Append the ship movements log to the email body
    email_body += entry_exit_log

    # Append probabilities to the report
    #probability_section = "<h2>Vessel Transition Probabilities to NWE</h2>"
    #for zone, vessels in transition_probabilities.items():
    #    probability_section += f"<h3>Zone: {zone}</h3><ul>"
    #    for imo, details in vessels.items():
    #        probability_section += (
    #            f"<li>{details['vessel_name']} (IMO: {imo}) - Probability to NWE: "
    #            f"{details['probability_to_NWE']:.2%}</li>"
    #        )
    #    probability_section += "</ul>"

    # Add probability section to the email body
    #email_body += probability_section

    #graph_filename = save_graph_as_image(transition_graph)
    #with open(graph_filename, "rb") as image_file:
    #    graph_base64 = base64.b64encode(image_file.read()).decode("utf-8")
    #email_body += f"<img src='data:image/png;base64,{graph_base64}' alt='Transition Graph'/>"

    # Calculate overnight changes in mcm volume per ship based on their moored location
    # and compare to regas country values
    '''
    import seaborn as sns
    
    # Function to check if a point is inside the Europe_Ext zone polygon
    def is_in_zone(coords, polygon_coords):
        # Create a Shapely polygon from the coordinates
        polygon = Polygon(polygon_coords)
        point = Point(coords)
        # Check if the point is within the polygon
        return polygon.contains(point)

    # Function to calculate LNG volume changes and regas volume comparisons
    def calculate_lng_changes_and_regas(ship_data, regas_data, latitude_col, longitude_col, status_col, locations):
        comparison_results = []  # To store comparison results
        moored_ships_lng = []  # To store LNG volumes of moored ships
        moored_dates = []  # To store dates of moored ships
        
        # Loop through the ship data by IMO
        for imo, group in ship_data.groupby('imo'):
            group = group.sort_values('last_seen')  # Sort by last_seen timestamp
            previous_volume = None
            
            for idx, row in group.iterrows():
                # Ensure both the 'last_seen' and current timestamp have the same timezone-awareness
                if row['last_seen'].tzinfo:  # If 'last_seen' is timezone-aware
                    now = pd.Timestamp.now(tz=row['last_seen'].tzinfo)  # Use the same timezone
                else:  # If 'last_seen' is naive
                    now = pd.Timestamp.now()  # Use naive current time
                    
                # If the ship is in Europe_Ext and is moored
                coordinates = (row[longitude_col], row[latitude_col])
                if is_in_zone(coordinates, locations["Europe_Ext"]) and row[status_col] == 'Moored':
                    
                    # Sum the LNG volume of moored ships
                    moored_ships_lng.append(row['lng_volume_mcm'])
                    moored_dates.append(row['last_seen'].date())
                    
                    # Get the regas volume for the matching date from regas_data
                    date_str = row['last_seen'].date()  # Get the date part of the timestamp
                    regas_volume = regas_data.loc[str(date_str), 'Total'] if str(date_str) in regas_data.index else 0
                    
                    # Append results for comparison
                    comparison_results.append({
                        'IMO': row['imo'],
                        'Date': row['last_seen'],
                        'LNG Volume (mcm)': row['lng_volume_mcm'],
                        'Regas Volume (mcm)': regas_volume,
                        'Moored': row[status_col] == 'Moored'
                    })
        
        # Convert the comparison results into a DataFrame
        comparison_df = pd.DataFrame(comparison_results)
        
        return comparison_df, moored_ships_lng, moored_dates

    # Function to plot the scatter plot and regression line
    def plot_scatter_and_regression(moored_ships_lng, regas_data, moored_dates):
        # Prepare the data for plotting
        regas_values = [regas_data.get(str(date), 0) for date in moored_dates]
        
        # Create a DataFrame for plotting
        plot_data = pd.DataFrame({
            'LNG Volume (mcm)': moored_ships_lng,
            'Regas Volume (mcm)': regas_values
        })
        
        # Create a scatter plot with regression line
        plt.figure(figsize=(10, 6))
        sns.regplot(x='LNG Volume (mcm)', y='Regas Volume (mcm)', data=plot_data, scatter_kws={'color':'blue'}, line_kws={'color':'red'})
        
        plt.title('LNG Volume vs Regas Volume for Moored Ships in Europe_Ext')
        plt.xlabel('LNG Volume (mcm)')
        plt.ylabel('Regas Volume (mcm)')
        plt.grid(True)
        plt.show()

    # Example call to the functions
    comparison_df, moored_ships_lng, moored_dates = calculate_lng_changes_and_regas(data, df_regas, 'latitude', 'longitude', 'reported_speed_knots', locations)

    # Summarize the data for the ships that are moored
    moored_summary = comparison_df[comparison_df['Moored'] == True].groupby('Date').agg(
        {'LNG Volume (mcm)': 'sum', 'Regas Volume (mcm)': 'sum'}).reset_index()

    # Print the moored summary
    print("Moored Ships LNG Volume vs Regas Volume Summary:")
    print(moored_summary)

    # Plot the scatter plot and regression line
    plot_scatter_and_regression(moored_ships_lng, df_regas, moored_dates)
    '''
    
    # Send the email
    body = produce_email_body(
        body=email_body,
        images=images
    )
    
    return body