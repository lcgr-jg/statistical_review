
"""
Email report to compute NWE Polygon LNG volumes and send results

"""


import logging
import traceback
import configparser
import platform

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email

from util import get_report


REPORTS_PATH = Path(__file__).parent.resolve()


# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'lng_polygon_volume.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

ce_user = config.get('CEConfig','user')
ce_pass = config.get('CEConfig','pass')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / "lng_polygon_volume.log", #filename = log_path / f"{stoday}_lng_polygon_volume.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'andre.leithaeuser@jainglobal.com'
    error_receivers= 'andre.leithaeuser@jainglobal.com'


email_subject = datetime.today().strftime('%Y-%m-%d') + " NWE Polygon LNG Volume v. Regas"

    
try:
    logging.info('Generating report')

    # Generate report data
    email_body = get_report(ce_user, ce_pass, logging)
    
    # Send email
    send_email(receivers, 
               email_subject, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')    
    

    logging.info('Report sent')
    

except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))        