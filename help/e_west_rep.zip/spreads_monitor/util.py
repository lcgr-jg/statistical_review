"""
Utilities for the TTF Spreads Monitor report.

The spread engine (data fetch, strip classification, rolling generic-spread
construction and statistics) lives in ``jain_commods.core.analytics.spreads``
and is shared with the eu_dashboard_power TTF Spreads Monitor page.  This
module keeps only what is specific to the email: HTML rendering and the local
debug CSV dumps.
"""

import numpy as np
import pandas as pd
import sys

from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
from common.dashboard_header import dashboard_header_for

from jain_commods.core.analytics.spreads import (  # noqa: F401  (re-exported for spreads_monitor.py / CLI use)
    # Report defaults / thresholds
    CRISIS_YEARS,
    EXCLUDE_CRISIS_YEARS,
    N_CARDS,
    PCT_HI,
    PCT_LO,
    Z_EXTREME,
    Z_METHOD,
    # Data access
    get_bbg_ice_settles,
    get_ice_settles,
    verify_bbg_vs_internal,
    # Engine
    SpreadEngine,
    classify_strips,
    build_spread_universe,
    compute_spread_stats,
    classify_flag,
    # Display helpers
    format_legs as _legs,
    leg_label as _leg_label,
    # Internals used by the debug dumps
    _delivery_start,
    _granularity_of,
)


# --------------------------------------------------------------------------- #
# Debug CSV dumps (local inspection only)
# --------------------------------------------------------------------------- #

def dump_debug_csvs(df_prices, out_dir='c:/temp'):
    """Write the intermediate data to CSVs for manual inspection.

    Produces five files in `out_dir`:
      * spreads_classified.csv       - raw rows after strip parsing/classification
      * spreads_contract_prices.csv  - enriched per-contract settle (wide, incl.
                                        quarter/season/year reconstructed from months)
      * spreads_history.csv          - ROLLING spread value per trade date (the
                                        generic front-leg/following-leg series the
                                        report uses), one column per spread
      * spreads_history_fixed.csv    - the SAME spreads but tracking the literal
                                        fixed contract pair (e.g. Q1-27 minus Q2-27)
                                        for side-by-side comparison
      * spreads_stats.csv            - summary table; includes both the rolling
                                        (z/pct/n) and fixed (z_fixed/pct_fixed/
                                        n_fixed) statistics
    """
    from pathlib import Path

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    df = classify_strips(df_prices)
    engine = SpreadEngine(df)

    # 1) classified raw rows
    classified_path = out / 'spreads_classified.csv'
    df.sort_values(['TRADE_DATE', 'DELIVERY_START']).to_csv(classified_path, index=False)

    # 2) enriched per-contract price matrix (direct strips + reconstructed coarse)
    prices_path = out / 'spreads_contract_prices.csv'
    engine.wide.sort_index().to_csv(prices_path)

    # 3) rolling spread history + 4) fixed-pair history + 5) stats
    specs = build_spread_universe(df, engine)
    history = {}
    history_fixed = {}
    detail_rows = []

    def _series_stats(series):
        if engine.live_date not in series.index:
            return None
        live = series.loc[engine.live_date]
        n = int(series.count())
        mean = series.mean()
        std = series.std(ddof=1)
        z = (live - mean) / std if std and not np.isnan(std) else 0.0
        pct = float((series <= live).mean() * 100.0)
        return live, mean, std, z, pct, n

    for spec in specs:
        col = f"{spec['cadence']} {_legs(spec)}"

        # Rolling generic series (what the report uses).
        series, _ = engine.spread_series(
            spec['front_label'], spec['back_label'],
            spec['year_offset'], spec['rank'],
        )
        history[col] = series

        # Fixed literal contract pair, e.g. Q1_2027 minus Q2_2027.
        fcol = f"{spec['front_label']}_{spec['front_year']}"
        bcol = f"{spec['back_label']}_{spec['back_year']}"
        if fcol in engine.wide.columns and bcol in engine.wide.columns:
            fixed = (engine.wide[fcol] - engine.wide[bcol]).dropna()
        else:
            fixed = pd.Series(dtype=float)
        history_fixed[col] = fixed

        roll = _series_stats(series)
        if roll is None:
            continue
        live, mean, std, z, pct, n = roll

        fx = _series_stats(fixed) if not fixed.empty else None
        row = {
            'cadence': spec['cadence'], 'legs': _legs(spec),
            'front_label': spec['front_label'], 'front_year': spec['front_year'],
            'back_label': spec['back_label'], 'back_year': spec['back_year'],
            'rank': spec['rank'], 'year_offset': spec['year_offset'],
            'live': live, 'mean': mean, 'std': std, 'z': z, 'pct': pct, 'n': n,
            'first_obs': series.index.min(), 'last_obs': series.index.max(),
            'flag': classify_flag(z, pct),
        }
        if fx is not None:
            _, mean_f, std_f, z_f, pct_f, n_f = fx
            row.update({
                'mean_fixed': mean_f, 'z_fixed': z_f, 'pct_fixed': pct_f,
                'n_fixed': n_f, 'first_obs_fixed': fixed.index.min(),
            })
        detail_rows.append(row)

    history_path = out / 'spreads_history.csv'
    pd.DataFrame(history).sort_index().to_csv(history_path)

    history_fixed_path = out / 'spreads_history_fixed.csv'
    pd.DataFrame(history_fixed).sort_index().to_csv(history_fixed_path)

    stats_path = out / 'spreads_stats.csv'
    (pd.DataFrame(detail_rows)
     .assign(absz=lambda d: d['z'].abs())
     .sort_values('absz', ascending=False)
     .drop(columns='absz')
     .to_csv(stats_path, index=False))

    paths = [classified_path, prices_path, history_path, history_fixed_path, stats_path]
    for p in paths:
        print(f'Wrote {p}')

    # Detailed per-date breakdown of the Q1/Q2 spread -- its rolling mean has
    # been the hardest to reconcile against the reference report.
    q12 = next((s for s in specs
                if s['front_label'] == 'Q1' and s['back_label'] == 'Q2'), None)
    if q12 is not None:
        dump_generic_series(
            df_prices,
            q12['front_label'], q12['front_year'],
            q12['back_label'], q12['back_year'],
            out_dir=out_dir,
        )

    return paths


def dump_generic_series(df_prices, front_label, front_year, back_label, back_year,
                        out_dir='c:/temp'):
    """Dump the per-date breakdown of one rolling generic spread for inspection.

    For the spread defined on the live date by ``(front_label, front_year)`` vs
    ``(back_label, back_year)`` this writes a CSV with, for every historical
    trade date: the actual contract the generic roll selected for each leg, both
    leg settles, the rolling spread, and the days-to-delivery of the rolled front
    leg.  It also prints a per-calendar-year summary (obs, mean, range and which
    front contracts were active) plus a days-to-delivery bucket summary, so it is
    easy to see what drives the rolling mean (e.g. crisis-era near-delivery
    spikes).  Returns ``(detail, yearly)``.
    """
    from pathlib import Path

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    df = classify_strips(df_prices)
    engine = SpreadEngine(df)

    # Resolve the roll exactly as build_spread_universe does.
    year_offset = back_year - front_year
    rank = engine.front_rank_on_live(front_label, front_year)

    front_year_arr = engine.nth_future_year(front_label, rank)
    back_year_arr = front_year_arr + year_offset
    front_px = engine._gather(front_label, front_year_arr)
    back_px = engine._gather(back_label, back_year_arr)

    idx = pd.DatetimeIndex(engine.wide.index)

    def _contract(label, yr):
        return _leg_label(label, int(yr)) if not np.isnan(yr) else None

    def _deliv_days(label, yr, td):
        if np.isnan(yr):
            return np.nan
        ds = _delivery_start(_granularity_of(label), label, int(yr))
        return int((ds - td).days)

    detail = pd.DataFrame({
        'TRADE_DATE': idx,
        'front_contract': [_contract(front_label, y) for y in front_year_arr],
        'back_contract': [_contract(back_label, y) for y in back_year_arr],
        'front_px': front_px,
        'back_px': back_px,
    })
    detail['spread'] = detail['front_px'] - detail['back_px']
    detail['front_days_to_delivery'] = [
        _deliv_days(front_label, y, td) for y, td in zip(front_year_arr, idx)
    ]
    detail = detail.dropna(subset=['spread']).reset_index(drop=True)

    legs = f"{_leg_label(front_label, front_year)} / {_leg_label(back_label, back_year)}"
    safe = legs.replace(' / ', '_').replace(' ', '')
    detail_path = out / f'series_{safe}.csv'
    detail.to_csv(detail_path, index=False, date_format='%Y-%m-%d')

    # Per-calendar-year summary of the rolling series.
    by_year = detail.assign(year=detail['TRADE_DATE'].dt.year).groupby('year')
    yearly = by_year['spread'].agg(['count', 'mean', 'min', 'max']).round(3)
    yearly['front_contracts'] = by_year['front_contract'].agg(
        lambda s: ', '.join(sorted(s.unique())))

    # Days-to-delivery buckets (the rolling series mixes every maturity).
    bins = [-1, 90, 180, 270, 360, 450, 100000]
    labels = ['0-90', '90-180', '180-270', '270-360', '360-450', '450+']
    dte_bucket = pd.cut(detail['front_days_to_delivery'], bins=bins, labels=labels)
    dte = detail.groupby(dte_bucket, observed=False)['spread'].agg(['count', 'mean']).round(3)

    print(f'\n=== Generic series {legs} (rank={rank}, year_offset={year_offset}) ===')
    print(f'overall: n={len(detail)} mean={detail["spread"].mean():.3f} '
          f'std={detail["spread"].std(ddof=1):.3f} '
          f'first={detail["TRADE_DATE"].min().date()} '
          f'last={detail["TRADE_DATE"].max().date()}')
    print('\n-- by trade-date year --')
    print(yearly.to_string())
    print('\n-- by front-leg days-to-delivery --')
    print(dte.to_string())
    print(f'\nWrote {detail_path}')

    return detail, yearly


# --------------------------------------------------------------------------- #
# Display helpers
# --------------------------------------------------------------------------- #

def _ordinal_date(ts):
    """Format a timestamp as e.g. '22nd Jun' (ordinal day + abbreviated month)."""
    ts = pd.Timestamp(ts)
    d = ts.day
    suffix = 'th' if 11 <= d % 100 <= 13 else {1: 'st', 2: 'nd', 3: 'rd'}.get(d % 10, 'th')
    return f"{d}{suffix} {ts.strftime('%b')}"


def _lerp(c1, c2, t):
    return tuple(int(round(a + (b - a) * t)) for a, b in zip(c1, c2))


_WHITE = (255, 255, 255)
_PINK = (224, 150, 166)   # rich / high
_GREEN = (193, 208, 178)  # cheap / low


def _heat(t):
    """t in [-1, 1]: negative -> green, 0 -> white, positive -> pink."""
    t = max(-1.0, min(1.0, t))
    if t >= 0:
        r, g, b = _lerp(_WHITE, _PINK, t)
    else:
        r, g, b = _lerp(_WHITE, _GREEN, -t)
    return f'rgb({r},{g},{b})'


def _heat_pct(pct):
    return _heat((pct - 50.0) / 50.0)


def _heat_z(z):
    return _heat(z / 2.0)


_DELTA_POS = '#3d7a5a'
_DELTA_NEG = '#b23a48'
_DELTA_ZERO = '#2b2b2b'


def _delta_colour(d):
    if pd.isna(d):
        return _DELTA_ZERO
    if d > 0:
        return _DELTA_POS
    if d < 0:
        return _DELTA_NEG
    return _DELTA_ZERO


def _fmt_delta(d):
    if pd.isna(d):
        return '&mdash;'
    return f'{d:+.3f}'


def _fmt_price(v):
    if pd.isna(v):
        return '&mdash;'
    return f'{v:.3f}'


_FLAG_COLOURS = {
    'RICH': ('#b23a48', '#ffffff'),
    'CHEAP': ('#3d7a5a', '#ffffff'),
    'NEUTRAL': ('#9aa0a6', '#ffffff'),
}


def _badge(flag, font_size='11px', align='center'):
    bg, fg = _FLAG_COLOURS[flag]
    # Rendered as a padded table cell (not a span) so the coloured background
    # honours the padding in Outlook, which ignores padding on inline spans.
    return (
        f'<table cellpadding="0" cellspacing="0" align="{align}" '
        f'style="display:inline-table; border-radius:4px; '
        f'font-family:Arial,Helvetica,sans-serif;">'
        f'<tr><td bgcolor="{bg}" style="background:{bg}; color:{fg}; '
        f'padding:6px 14px; border-radius:4px; font-size:{font_size}; '
        f'font-weight:bold; letter-spacing:0.5px; text-align:center; '
        f'white-space:nowrap;">{flag}</td></tr></table>'
    )


# --------------------------------------------------------------------------- #
# HTML rendering
# --------------------------------------------------------------------------- #

def _render_card(row):
    legs = _legs(row)
    return f"""
      <td width="33%" valign="top" style="padding:6px;">
        <table width="100%" cellpadding="0" cellspacing="0"
               style="border:1px solid #e2e2e2; border-radius:8px;
                      font-family:Arial,Helvetica,sans-serif;">
          <tr><td style="padding:14px 16px;">
            <div style="font-size:11px; color:#9aa0a6; text-transform:uppercase;
                        letter-spacing:0.5px;">{row['cadence']}</div>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="margin-top:4px; font-family:Arial,Helvetica,sans-serif;">
              <tr>
                <td style="font-size:18px; font-weight:bold; color:#2b2b2b;">{legs}</td>
                <td align="right" style="font-size:18px; font-weight:bold; color:#2b2b2b;
                    white-space:nowrap;">z {row['z']:+.2f}</td>
              </tr>
            </table>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="margin-top:10px; font-family:Arial,Helvetica,sans-serif;">
              <tr>
                <td align="left" style="padding:0;">{_badge(row['flag'], align='left')}</td>
              </tr>
              <tr>
                <td style="padding:10px 0 0 0; font-size:13px; color:#555;">
                  Settle {row['live']:.3f} &euro;/MWh &middot; %ile {row['pct']:.0f}
                </td>
              </tr>
              <tr>
                <td style="padding:2px 0 0 0; font-size:12px; color:#9aa0a6;">n={row['n']:,}</td>
              </tr>
            </table>
          </td></tr>
        </table>
      </td>"""


def _render_cards(res):
    cards = res.head(N_CARDS)
    cells = ''.join(_render_card(r) for _, r in cards.iterrows())
    return f"""
    <table width="100%" cellpadding="0" cellspacing="0"
           style="margin:8px 0 20px; font-family:Arial,Helvetica,sans-serif;">
      <tr>{cells}</tr>
    </table>"""


def _render_table(res, settle_label='Settle'):
    th_style = ('padding:8px 10px; font-size:12px; font-weight:normal; color:#9aa0a6; '
                'border-bottom:1px solid #e2e2e2; text-transform:none;')
    z_label = 'z (robust)' if Z_METHOD == 'robust' else 'z'
    center_label = 'Median' if Z_METHOD == 'robust' else 'Mean'
    header = f"""
      <tr>
        <th style="{th_style} text-align:center;">Granularity</th>
        <th style="{th_style} text-align:center;">Legs (front / back)</th>
        <th style="{th_style} text-align:right;">{settle_label}</th>
        <th style="{th_style} text-align:right;">DoD &Delta;</th>
        <th style="{th_style} text-align:right;">YTD High</th>
        <th style="{th_style} text-align:right;">YTD Low</th>
        <th style="{th_style} text-align:center;">%ile</th>
        <th style="{th_style} text-align:center;">{z_label}</th>
        <th style="{th_style} text-align:right;">{center_label}</th>
        <th style="{th_style} text-align:right;">n</th>
        <th style="{th_style} text-align:center;">Flag</th>
      </tr>"""

    # Every cell gets a 1px border in its OWN background colour. With
    # border-collapse this bleeds each cell's colour over the sub-pixel row
    # seam, so no white hairlines show through any column (zebra or heat).
    def _cell(bg, align, extra=''):
        return (f'padding:8px 10px; font-size:13px; color:#2b2b2b; '
                f'background:{bg}; border:1px solid {bg}; text-align:{align}; {extra}')

    body_rows = []
    for i, (_, row) in enumerate(res.iterrows()):
        zebra = '#ffffff' if i % 2 == 0 else '#fafafa'
        pct_bg = _heat_pct(row['pct'])
        z_bg = _heat_z(row['z'])
        body_rows.append(f"""
      <tr>
        <td style="{_cell(zebra, 'center', 'color:#777;')}">{row['cadence']}</td>
        <td style="{_cell(zebra, 'center')}">{_legs(row)}</td>
        <td style="{_cell(zebra, 'right')}">{row['live']:.3f}</td>
        <td style="{_cell(zebra, 'right', f'color:{_delta_colour(row["dod"])}; font-weight:bold;')}">{_fmt_delta(row['dod'])}</td>
        <td style="{_cell(zebra, 'right', 'color:#777;')}">{_fmt_price(row['ytd_high'])}</td>
        <td style="{_cell(zebra, 'right', 'color:#777;')}">{_fmt_price(row['ytd_low'])}</td>
        <td style="{_cell(pct_bg, 'center')}">{row['pct']:.0f}</td>
        <td style="{_cell(z_bg, 'center')}">{row['z']:+.2f}</td>
        <td style="{_cell(zebra, 'right', 'color:#777;')}">{row['mean']:.3f}</td>
        <td style="{_cell(zebra, 'right', 'color:#777;')}">{row['n']:,}</td>
        <td style="{_cell(zebra, 'center')}">{_badge(row['flag'])}</td>
      </tr>""")

    return f"""
    <table width="100%" cellpadding="0" cellspacing="0"
           style="border-collapse:collapse; font-family:Arial,Helvetica,sans-serif;">
      {header}
      {''.join(body_rows)}
    </table>"""


def generate_report(df_prices, history_years=None):
    """Build the full HTML email body from the raw settlement frame.

    ``history_years`` is the configured length of the rolling history window; it
    is shown in the footer note alongside the actual start date when provided.
    """
    df = classify_strips(df_prices)
    engine = SpreadEngine(df)
    res = compute_spread_stats(df, engine)

    live_date = engine.live_date.strftime('%d %b %Y')

    if res.empty:
        return (
            dashboard_header_for("spreads_monitor")
            + f'<div style="font-family:Arial,Helvetica,sans-serif;">'
            + f'<p>No spreads with sufficient history on {live_date}.</p></div>'
        )

    n_extreme = int(res['extreme'].sum())

    if Z_METHOD == 'robust':
        z_desc = 'Robust z (median / MAD, resistant to crisis spikes)'
    else:
        z_desc = 'Standard z (mean / std)'

    crisis_years_str = ", ".join(str(y) for y in CRISIS_YEARS)
    if EXCLUDE_CRISIS_YEARS:
        crisis_note = f'Energy-crisis years ({crisis_years_str}) excluded from the history.'
    else:
        crisis_note = f'Energy-crisis years ({crisis_years_str}) included in the history.'

    subtitle_lines = [
        (f'{n_extreme} spread{"s" if n_extreme != 1 else ""} at an extreme '
         f'(z &ge; {Z_EXTREME} or %ile &ge; {PCT_HI} / &le; {PCT_LO}) across the whole '
         f'TTF curve.'),
        'RICH = sell-bias, CHEAP = buy-bias.',
        "Ranked by z vs each spread's own history.",
        crisis_note,
    ]
    subtitle = '<br>'.join(subtitle_lines)

    # Date-range note: overall settlement window + per-spread history depth.
    data_start = engine.dates.min()
    data_start = pd.Timestamp(data_start).strftime('%d %b %Y')
    n_days = len(engine.dates)
    if EXCLUDE_CRISIS_YEARS:
        n_days = int(sum(pd.Timestamp(d).year not in CRISIS_YEARS for d in engine.dates))
    n_min, n_max = int(res['n'].min()), int(res['n'].max())

    window_prefix = (
        f'{history_years}-year rolling history: ' if history_years is not None else ''
    )
    note_lines = [
        f'{z_desc}.',
        crisis_note,
        (f'{window_prefix}window {data_start} &ndash; {live_date} '
         f'({n_days:,} trading days; per-spread sample {n_min:,}&ndash;{n_max:,} obs).'),
        ('History rolled on a generic basis (front-leg seasonal label + year rank) '
         'relative to each trade date; quarter/season/year legs are always '
         'reconstructed from their constituent monthly contracts (day-weighted).'),
    ]

    html = f"""
{dashboard_header_for("spreads_monitor")}
<div style="font-family:Arial,Helvetica,sans-serif; color:#2b2b2b;
            max-width:1200px; margin:0 auto; padding:8px;">
  <div style="font-size:22px; font-weight:bold;">
    Spread Monitor
  </div>
  <div style="font-size:13px; color:#6b6b6b; margin-top:6px; line-height:1.5;">{subtitle}</div>
  {_render_cards(res)}
  {_render_table(res, settle_label=f'{_ordinal_date(engine.live_date)} Settle')}
  <div style="font-size:11px; color:#b0b0b0; margin-top:16px; line-height:1.6;">
    {'<br>'.join(note_lines)}
  </div>
</div>"""

    return html


# --------------------------------------------------------------------------- #
# Local preview (does not hit Snowflake)
# --------------------------------------------------------------------------- #

if __name__ == '__main__':
    import sys
    from datetime import datetime
    from pathlib import Path

    # Cross-check the Bloomberg backfill against the internal source over an
    # overlapping window:  python util.py --verify-bbg [start YYYY-MM-DD] [end YYYY-MM-DD]
    if len(sys.argv) > 1 and sys.argv[1] == '--verify-bbg':
        args = sys.argv[2:]
        v_start = datetime.strptime(args[0], '%Y-%m-%d') if len(args) > 0 else datetime(2019, 1, 1)
        v_end = datetime.strptime(args[1], '%Y-%m-%d') if len(args) > 1 else datetime(2021, 1, 1)
        verify_bbg_vs_internal(start_date=v_start, end_date=v_end)
        sys.exit(0)

    csv_path = sys.argv[1] if len(sys.argv) > 1 else r'c:\Temp\ice_ttf_settles.csv'
    df_prices = pd.read_csv(csv_path)
    # Drop a leading unnamed index column if the CSV was saved with one.
    if df_prices.columns[0].startswith('Unnamed'):
        df_prices = df_prices.drop(columns=df_prices.columns[0])

    # Diagnostics: data coverage + per-spread observation counts.
    _df = classify_strips(df_prices)
    _eng = SpreadEngine(_df)
    _res = compute_spread_stats(_df, _eng)
    print(f'Trade dates: {_df["TRADE_DATE"].min().date()} -> '
          f'{_df["TRADE_DATE"].max().date()} ({_df["TRADE_DATE"].nunique()} days)')
    pd.set_option('display.width', 200)
    print(_res[['cadence', 'front_label', 'front_year',
                'back_label', 'back_year', 'n', 'z', 'pct', 'flag']].to_string())

    dump_debug_csvs(df_prices, out_dir=r'c:\temp')

    body = generate_report(df_prices)

    out = Path(__file__).parent / 'preview.html'
    out.write_text(body, encoding='utf-8')
    print(f'Wrote {out}')
