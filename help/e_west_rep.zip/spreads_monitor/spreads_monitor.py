
"""
Email report showing mispriced spreads
"""


import logging
import os
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email

from util import (
    get_ice_settles,
    generate_report,
    dump_debug_csvs
)


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/spreads_monitor')
 
# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'spreads_monitor.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')
history_years = config.getint('ReportSettings','history_years')
ce_user = config.get('CEConfig','user')
ce_pass = config.get('CEConfig','pass')


# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_spreads_monitor.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'

today = datetime.now()


email_subject = 'TTF Spreads Monitor'

# Set SPREADS_MONITOR_PREVIEW=1 to write preview.html locally instead of emailing.
preview_mode = os.environ.get('SPREADS_MONITOR_PREVIEW', '').lower() in ('1', 'true', 'yes')


try:
    
    logging.info('Running report...')
    
    logging.info('Querying ICE settlement data')
    df_prices = get_ice_settles(start_date=today.replace(year=today.year-history_years))

    # On Windows (local debugging) dump the intermediate data for inspection.
    if system == 'windows':
        dump_debug_csvs(df_prices, out_dir=r'c:\temp')
    
    
    logging.info('Constructing report body')
    email_body = generate_report(df_prices, history_years=history_years)
    
    
    if preview_mode:
        preview_path = REPORTS_PATH / 'preview.html'
        preview_path.write_text(email_body, encoding='utf-8')
        logging.info('Preview mode: wrote %s', preview_path)
    else:
        logging.info('Sending email')
        send_email(receivers,
                   # f"{email_subject}: {today.strftime('%d %b %Y')}",
                   email_subject,
                   email_body,
                   from_address='eu.gap.reports@jainglobal.com')

    logging.info('Done')



except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f"ERROR {email_subject}", str(tb))    

        