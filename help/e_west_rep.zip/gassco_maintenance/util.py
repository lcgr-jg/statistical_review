import logging
import json
import time
import requests
import traceback
import pandas as pd
import xmltodict
import os
import re

from bs4 import BeautifulSoup
from zoneinfo import ZoneInfo
from dateutil.parser import parse
from datetime import datetime
from collections import OrderedDict

from jain_commods.core.util.htmlutils import df2html


def get_gassco_page():

    session_disclaimer = requests.Session()
    
    res_disclaimer = session_disclaimer.get('http://umm.gassco.no/disclaimer')
    cookies_disclaimer = res_disclaimer.cookies.get_dict()
    
    max_retries = 5
    ncount = 0
    output = ''
    while output=='' and ncount<=max_retries:
        # Note: sleep needed as sometimes have to wait before making subsequent request with above cookies
        time.sleep(5)
        res_content = requests.get('https://umm.gassco.no/disclaimer/acceptDisclaimer?',
                                   cookies=cookies_disclaimer)
        output = res_content.text
        ncount += 1
    
    return output


def extract_realtime_flows(soup):
    
    flows = {}
    # Locate the flows table cells 
    tds = soup.find_all('td', {'class':'flow'})
    # Extract each flow
    for td in tds:
        value = td.find('div',class_='value').get_text(strip=True)
        label = td.find('div',class_='heading').get_text(strip=True)
        flows[label] = [value]
        
    last_update_str = soup.find('div', {'class': 'lastUpdate'}).get_text(strip=True).replace('Last updated\r\n','').strip()
    last_update = datetime.strptime(last_update_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=ZoneInfo('CET'))
    
    last_update_utc = last_update.astimezone(ZoneInfo('UTC'))
    
    return flows, last_update_utc


def extract_events(soup, table_name):
    
    try:
        # Locate the section we want
        table_header = soup.find('h2', text=table_name)
        table = table_header.findNext('table',{'class':'msgTable'})
        
        header_rows = 2
        data_rows = table.findAll('tr')[header_rows:]
        
        # Table could be empty (most likely for "other")
        empty_table = False
        if len(data_rows)==1:
            if len(data_rows[0].findAll('td'))==1:
                empty_table = True

        if not empty_table:
            
            new_rows = []
            
            for row in data_rows:
                
                # Get the columns in this row
                cols = row.findAll('td')
                
                # Event columns
                messageid = cols[0].text
                messageid_url = cols[0].find('a').get('href')
                asset = cols[1].text
                event_status = cols[2].text
                unavailability_type = cols[3].text
                event_type = cols[4].text
                published = parse(cols[5].text)
                start = parse(cols[6].text)
                stop = parse(cols[7].text)
                unit = cols[8].text
                cap_technical = float(cols[9].text)
                cap_avail = float(cols[10].text)
                cap_unavail = float(cols[11].text)
                reason = cols[12].text
                remarks = cols[13].text
                
                new_row = {'MessageId': messageid,
                           'Link': messageid_url,
                           'Asset': asset,
                           'Status': event_status,
                           'Type': unavailability_type,
                           'Event Type': event_type,
                           'Published': published,
                           'Start': start,
                           'Stop': stop,
                           # 'Unit': unit,
                           'Tech Capa': cap_technical,
                           'Avail Capa': cap_avail,
                           'Unavail Capa': cap_unavail,
                           'Reason': reason,
                           'Remarks': remarks,
                           }
                
                new_rows.append(new_row)
                
            df_events = pd.DataFrame(new_rows)
            
            return df_events
        
        else:
            # Note: quite feasible for there to be no events (most likely in "Events-Other" section)
            return pd.DataFrame(columns=['Start', 'Stop'])
                
        
    except Exception:
        tb = traceback.format_exc()
        logging.error(f"Exception caught in extract_events: {tb}")
        return pd.DataFrame(columns=['Start', 'Stop'])



def get_gassco_maintenances():
    
    # Retrieve latest Gassco page
    raw_html = get_gassco_page()
    
    soup = BeautifulSoup(raw_html)
    
    if soup.contents:
        
        # Extract all events from the html
        df_fields = extract_events(soup, 'EVENTS - Fields and Processing Plants')
        df_terminals = extract_events(soup, 'EVENTS - Exit terminals')
        df_other = extract_events(soup, 'EVENTS - Other')
        
        # Extract current realtime flows
        flows, last_update_utc = extract_realtime_flows(soup)
        
        # Join together
        df_events_all = pd.concat([df_fields, df_terminals, df_other])
        # df_events = df_events.sort_values(by=['EventType','MessageId'])
        
        return {'field_processing': df_fields,
                'terminals': df_terminals,
                'other': df_other,
                'all': df_events_all,
                'flows': {'flows': flows, 'last_update_utc': last_update_utc},
                }


def generate_maint_html(updated_events):
    
    def make_hyperlink(row):
        # match = re.search(r'(\d{3})$', row['MessageId'])
        return f'<a href="https://umm.gassco.no{row["Link"]}">{row["MessageId"]}</a>'

    def format_published(dt):
        current_year = datetime.now().year
        if dt.year == current_year:
            return dt.strftime('%d %b %H:%M')
        else:
            return dt.strftime('%d %b-%y %H:%M')

    df = updated_events.copy()

    # Convert date columns to datetime
    for col in ['Published', 'Start', 'Stop']:
        df[col] = pd.to_datetime(df[col], utc=True)

    # Format and highlight Published column
    def format_and_highlight(dt):
        formatted = format_published(dt)
        return formatted

    df['Published'] = df['Published'].apply(format_and_highlight)

    # Format Start and Stop columns
    df['Start'] = df['Start'].dt.strftime('%d %b-%y')
    df['Stop'] = df['Stop'].dt.strftime('%d %b-%y')

    # Create hyperlinks for MessageId — must be done before dropping 'Link'
    df['MessageId'] = df.apply(make_hyperlink, axis=1)

    # Now safe to drop the Link column
    df = df.drop(columns=['Link'])

    # Generate HTML table
    table_html = df.to_html(escape=False, index=False, border=0)

    # Add style block
    styled_html = f"""
    <style>
        table {{
            font-size: 12px;
            border-collapse: collapse;
            width: auto;
        }}
        thead tr {{
            background-color: #f2f2f2;
        }}
        th, td {{
            padding: 4px 8px;
            border: 1px solid #ccc;
            text-align: left;
        }}
    </style>
    {table_html}
    """
    return styled_html


def create_alert(updated_message_ids, last_check_utc):
    
    # Get current Gassco maintenance
    logging.info('Downloading current Gassco page')
    gassco_remits_flows = get_gassco_maintenances()
    
    # Get the updated events
    df = gassco_remits_flows['all'].copy()
    updated_events = df[df['MessageId'].isin(updated_message_ids)]
    
    # Generate html maint table
    logging.info('Creating HTML')
    updated_events_html = generate_maint_html(updated_events)
    
    # Prepare real time flows
    realtime_flows = pd.DataFrame(gassco_remits_flows['flows']['flows']).T
    realtime_flows.index.name = 'Exit Point Nomination'
    realtime_flows.columns = [f"As of {gassco_remits_flows['flows']['last_update_utc'].strftime('%Y-%m-%d %H:%M')} UTC"]
    
    # Generate html realtime flows table
    # realtime_flows_html = df2html(realtime_flows, font_size=12, border=0)
    realtime_flows_html = realtime_flows.to_html(escape=False, index=True, border=0)

    # Add style block
    realtime_flows_html_styled = f"""
    <style>
        table {{
            font-size: 12px;
            border-collapse: collapse;
            width: auto;
        }}
        thead tr {{
            background-color: #f2f2f2;
        }}
        th, td {{
            padding: 4px 8px;
            border: 1px solid #ccc;
            text-align: left;
        }}
    </style>
    {realtime_flows_html}
    """
    
    
    
    # Construct email body
    email_body = f"""<html lang="en">
                    <body>
                    <b><u>Real Time Flows Snapshot (mcm/d):</u></b>
                    <br>
                    {realtime_flows_html_styled}
                    <br><hr>
                    <p><b><u>Gassco Maintenance Remits</u></b> (all changes since {last_check_utc.strftime('%Y-%m-%d %H:%M')} UTC):                  
                    <br>
                    {updated_events_html}
                    <br><hr>
                    <p><b><u>Notes:</u></b>
                    <br>Remits sorted by Published date
                    <br>All data taken from <a href='https://umm.gassco.no/'>https://umm.gassco.no/</a> 
                    <br>Gassco Map: <a href='https://map.gassco.eu/map'>https://map.gassco.eu/map</a> 
                    </body>
                    </html>
                """
    
    return email_body
   
    
def check_maint_rss(max_retries=3, retry_delay=5):      
    
    logging.info('Retrieving data from RSS xml feed')
    url = 'https://umm.gassco.no/atom.xml'
    
    for attempt in range(max_retries):
        try:
            response = requests.get(url)
            
            events_summary = {}
            
            if response.status_code == 200:
                # Parse the results to xml
                res = xmltodict.parse(response.text)
                
                # Extract count and updated timestamp
                updated_str = res['feed']['updated']
                logging.info(f"RSS xml feed updated at {updated_str}")
                
                # Capture the updated timestamp (is when the page is rendered)
                # NB: we only need this to check when the day rolls over
                events_summary['updated'] = updated_str
                updated = datetime.strptime(updated_str, '%Y-%m-%dT%H:%M:%SZ')
                
                # Check if there are any entries (feed gets updated but can be empty if there are no new events today)
                if 'entry' in res['feed'].keys():
                    
                    # Check type to correctly handle if single or multiple events
                    if isinstance(res['feed']['entry'], dict):
                        # Only one event
                        events = [res['feed']['entry']]
                    else:
                        # Extract all events
                        events = res['feed']['entry']
                        
                    logging.info(f"Parsing {len(events)} events in RSS file")
                    
                    event_details = {}
                    for event in events:
                        # Handle different RSS feed structures for summary field
                        summary_data = event['summary']
                        if isinstance(summary_data, dict):
                            summary_text = summary_data.get('#text', summary_data)
                        else:
                            summary_text = summary_data
                        
                        summary = xmltodict.parse(summary_text)
                        message_id = summary['REMITUrgentMarketMessages']['UMM']['messageId']
                        # Capture the message Id and updated timestamp 
                        # 2025-10-03T08:55:00Z
                        naive_time = datetime.strptime(event['updated'], "%Y-%m-%dT%H:%M:%SZ")
                        utc_time = naive_time.replace(tzinfo=ZoneInfo('UTC'))
                        event_details[message_id] = {'updated_raw': event['updated'],
                                                     'updated_utc': utc_time,
                                                     }
                    events_summary['event_details'] = event_details
                
                # If we got here successfully, return the results
                return events_summary
            
            else:
                raise Exception(f"Error querying Gassco. Got error code: {response.status_code}")
        
        except (TypeError, KeyError, AttributeError) as e:
            # Catch structure-related errors
            logging.warning(f"Attempt {attempt + 1}/{max_retries} failed due to unexpected RSS structure: {e}")
            if attempt < max_retries - 1:
                logging.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.error(f"Failed after {max_retries} attempts")
                raise Exception(f"RSS feed structure error after {max_retries} attempts: {e}")
        
        except Exception as e:
            # For other errors (like network issues), also retry
            logging.warning(f"Attempt {attempt + 1}/{max_retries} failed: {e}")
            if attempt < max_retries - 1:
                logging.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.error(f"Failed after {max_retries} attempts")
                raise   
    

def check_maint_rss_no_loop():      
    
    logging.info('Retrieving data from RSS xml feed')

    url = 'https://umm.gassco.no/atom.xml'
    
    response = requests.get(url)
    
    events_summary = {}
    
    if response.status_code==200:
        # Parse the results to xml
        res = xmltodict.parse(response.text)
        
        # Extract count and updated timestamp
        updated_str = res['feed']['updated']
        logging.info(f"RSS xml feed updated at {updated_str}")
        
        # Capture the updated timestamp (is when the page is rendered)
        # NB: we only need this to check when the day rolls over
        events_summary['updated'] = updated_str
        updated = datetime.strptime(updated_str, '%Y-%m-%dT%H:%M:%SZ')
        
        # Check if there are any entries (feed gets updated but can be empty if there are no new events today)
        if 'entry' in res['feed'].keys():
            
            # Check type to correctly handle if single or multiple events
            if isinstance(res['feed']['entry'], OrderedDict):
                # Only one event
                events = [res['feed']['entry']]
            else:
                # Extract all events
                events = res['feed']['entry']
                
            logging.info(f"Parsing {len(events)} events in RSS file")
            
            event_details = {}
            for event in events:
                summary = xmltodict.parse(event['summary']['#text'])
                message_id = summary['REMITUrgentMarketMessages']['UMM']['messageId']
                # Capture the message Id and updated timestamp 
                # 2025-10-03T08:55:00Z
                naive_time = datetime.strptime(event['updated'], "%Y-%m-%dT%H:%M:%SZ")
                utc_time = naive_time.replace(tzinfo=ZoneInfo('UTC'))
                event_details[message_id] = {'updated_raw': event['updated'],
                                             'updated_utc': utc_time,
                                             }
            events_summary['event_details'] = event_details
            
        return events_summary
    
    else:
        raise Exception(f"Error querying Gassco. Got error code: {response.status_code}")    
        
            


def check_maint_rss_old(events_summary_prev_file):
    
    try:
        logging.info('Retrieving data from RSS xml feed')
        
        
        url = 'https://umm.gassco.no/atom.xml'
        
        response = requests.get(url)
        
        new_events_published = False
        events_summary = {}
        
        if response.status_code==200:
            
            # Parse the results to xml
            res = xmltodict.parse(response.text)
            
            # Extract count and updated timestamp
            updated_str = res['feed']['updated']
            logging.info(f"RSS xml feed updated at {updated_str}")
            
            # Capture the updated timestamp (is when the page is rendered)
            # NB: we only need this to check when the day rolls over
            events_summary['updated'] = updated_str
            updated = datetime.strptime(updated_str, '%Y-%m-%dT%H:%M:%SZ')
            
            if os.path.isfile(events_summary_prev_file):
                with open(events_summary_prev_file, 'rb') as f:
                    events_summary_prev = json.load(f)
                    
                # Check if there are any entries (feed gets updated but can be empty if there are no new events today)
                if 'entry' in res['feed'].keys():
                    
                    # Check type to correctly handle if single or multiple events
                    if isinstance(res['feed']['entry'], OrderedDict):
                        # Only one event
                        events = [res['feed']['entry']]
                    else:
                        # Extract all events
                        events = res['feed']['entry']
                        
                    logging.info(f"Found {len(events)} events. Processing...")
                    
                    event_details = {}
                    for event in events:
                        summary = xmltodict.parse(event['summary']['#text'])
                        message_id = summary['REMITUrgentMarketMessages']['UMM']['messageId']
                        # We capture the message Id and updated timestamp in case the same event gets updated within the same day
                        event_details[message_id] = event['updated']
                        
                    events_summary['event_details'] = event_details
                    
                    # We've now parsed the latest results set... compare if anything has changed (NB: we assume ordering of existing items won't change)
                    if events_summary['event_details'] != events_summary_prev['event_details']:
                        logging.info('*** New data found. Event details have changed!')
                        new_events_published = True
                        
                        # Write latest snapshot details to file ready for next check
                        with open(events_summary_prev_file, 'w') as fp:
                            json.dump(events_summary, fp)
                    else:
                        # Nothing to do
                        logging.info('No new events')
                        
            else:
                logging.error(f"Check file not found! {events_summary_prev_file} is missing!")
                
        else:
            logging.error(f"Error retrieving data from {url} with error code {response.status_code}")
            
        return new_events_published
                
        
    except Exception:
        tb = traceback.format_exc()
        logging.error(f"Exception caught in check_maint_rss: {tb}")
        return False