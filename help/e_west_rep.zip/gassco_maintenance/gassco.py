import os
import logging
import traceback
import configparser
import platform

from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from jain_commods.core.util.emailhelper import send_email

from util import check_maint_rss, create_alert


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/gassco_maintenance')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'gassco.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_gassco.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'
  

email_subject = 'Gassco Maintenance Alert'

last_check_datetime_file = REPORTS_PATH / 'last_check_datetime.txt'
last_check_datetime_fmt = '%Y-%m-%dT%H:%M:%S'


try:
    logging.info('Starting Gassco maintenance report...')
    
    # TODO:
        # split out event types and display seperately
        # calculate total impact
        # add highlighting if prompt, medium or distant start dates or status is dismissed
        # save previous real time flows to show WD change?
        # save previous events to show diffs in the table?
        # switch to getting real time flows from https://umm.gassco.no/realTimeAtom.xml (we currently parse the page!)
    
    now_utc = datetime.now(timezone.utc)
    
    last_check_utc = datetime.strptime(open(last_check_datetime_file, 'r').read(), last_check_datetime_fmt).replace(tzinfo=ZoneInfo('UTC'))
    
    # Check RSS file to see if anything published today
    events_rss = check_maint_rss()
    
    if 'event_details' in events_rss.keys():
        # New events have been published today. Check if anything updated since our last check
        updated_message_ids = [k for k,v in events_rss['event_details'].items() if v['updated_utc']>last_check_utc]
        
        if len(updated_message_ids)>0:
            logging.info(f"Found {len(updated_message_ids)} events updated since {last_check_utc}")
            
            # Create new alert for new items
            report = create_alert(updated_message_ids, last_check_utc)
            
            # Update email subject
            plural_or_not = 's' if len(updated_message_ids)>1 else ''
            email_subject_updated = f"{email_subject}: {len(updated_message_ids)} update{plural_or_not}"
            
            # Send alert
            logging.info('Sending alert')
            send_email(receivers, email_subject_updated, report)
            logging.info('Alert sent')
            
        else:
            # Events published today but nothing updated since our last check
            logging.info(f"Events published today but no updates since last check at {last_check_utc}")
            
    else:
        # Do nothing 
        logging.info('No events published today')
        
    # Save check time for next run
    with open(last_check_datetime_file, 'w') as last_check:
        last_check.write(now_utc.strftime(last_check_datetime_fmt))
        
    logging.info('Process complete')

    
except Exception:
    logging.error('Exception caught running process!')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))
        
        