import pandas as pd
from datetime import datetime, timedelta

from jain_commods.core.interfaces.bloomberg import BBGQuery, bsrch_handler


def _pub_dates(ref_dt = datetime.now()):
    
    
    if  ref_dt.weekday() == 0:
        days_back = 4  # max = 18 months
    if not ref_dt.weekday() == 0:
        days_back = 2  # max = 18 months# max = 18 months
    
    end = ref_dt.date() + timedelta(days=1)
    start = end - timedelta(days=days_back)
    df = pd.date_range(start, end, freq='6h')
    df = df[df < ref_dt]
    df = df.strftime('%Y-%m-%dT%H:00:00')
    df = df[df.str.endswith('00:00:00')]
    return df


def _clean(df, pub_date):

    df.index=pd.to_datetime(df['Reported Time (UTC)'])
    df = df.iloc[:, 1:]
    df.columns=[pub_date]
    df=df.resample('D').mean()

    return df


def get_wind_data():
    
    
    # Get DE wind data
    
    pub_dates = _pub_dates()

    # Open connection and start session
    session = BBGQuery(p_on_server=True)._start_session_server()
    
    df = pd.DataFrame()

    for pub_date in pub_dates:
        
        # Data container for each iteration


        # Weather forecast example
        session.openService('//blp/exrsvc')
        exrService = session.getService('//blp/exrsvc')
        request = exrService.createRequest('ExcelGetGridRequest')

        request.set('Domain', 'COMDTY:MODEL')
        overrides = request.getElement("Overrides")

        # Set ensemble type
        override1 = overrides.appendElement()
        override1.setElement("name", "subtype")
        override1.setElement("value", "Ensemble")

        # Set ensemble type
        override7 = overrides.appendElement()
        override7.setElement("name", "ensemble_type")
        override7.setElement("value", "MEAN")

        # Set locations
        override2 = overrides.appendElement()
        override2.setElement("name", "location")
        override2.setElement("value", "DE")

        # Set model with adjusted date
        override3 = overrides.appendElement()
        override3.setElement("name", "weather_publication_date")
        override3.setElement("value", pub_date)

        # Set model
        override4 = overrides.appendElement()
        override4.setElement("name", "weather_model")
        override4.setElement("value", "ECMWF")

        # Set model output
        override5 = overrides.appendElement()
        override5.setElement("name", "model")
        override5.setElement("value", "wind_generation")

        # Set provider
        override6 = overrides.appendElement()
        override6.setElement("name", "provider")
        override6.setElement("value", "bloomberg")

        session.sendRequest(request)

        # Loop through the results and put them into a DataFrame
        try:
            while (True):
                event = session.nextEvent(500)
                if event.eventType() != bsrch_handler.BLP_RESPONSE and \
                        event.eventType() != bsrch_handler.BLP_PARTIAL_RESPONSE:
                    continue
                for msg in event:
                    sub = bsrch_handler.getBSRCHData(msg)
                    if len(sub) > 0:
                        sub = _clean(sub, pub_date)
                        df = pd.concat([df, sub], axis=1)
                if event.eventType() == bsrch_handler.BLP_RESPONSE:
                    break
        except Exception as e:
            print(f"An error occurred: {e}")


    # Stop the session
    session.stop()

    return df


#handle the df's data and convert to temp delta
def handle_df(df):

    # Reverse column order
    df = df[df.columns[::-1]]

    if not datetime.now().weekday() == 0:
        df = df.dropna()
        df = df / 1000 / 1000
        df['Delta'] = df.iloc[:, 0] - df.iloc[:, 1]
        # df.loc['Total'] = df.sum()
        # df = df.round(0)
        df.columns = ['D0_00z Gen', 'D-1_00z Gen', 'Delta']

    if datetime.now().weekday() == 0:


        # Extract the 'pub_date' level and filter only for 'T00:00:00' times
        # NB: these are already being filtered above
        t00_columns = df.columns
        # t00_columns = pub_dates[pub_dates.strftime('%H:%M:%S') == '00:00:00']

        # Get the earliest and latest 'T00:00:00' pub_dates
        earliest_date = t00_columns.min()
        latest_date = t00_columns.max()

        # Filter the DataFrame to keep only the earliest and latest 'T00:00:00' columns
        filtered_columns = [col for col in df.columns if col in [earliest_date,latest_date]]
        df_filtered = df[filtered_columns]
        df = df_filtered
        df = df.dropna()
        df = df / 1000 / 1000
        df['Delta'] = df.iloc[:, 0] - df.iloc[:, 1]
        # df.loc['Total'] = df.sum()
        # df = df.round(0)
        df.columns = ['D0_00z Gen', 'D-3_00z Gen', 'Delta']
        
    # Tidy up df for display
    df.index = pd.to_datetime(df.index)
    #df.index = df.index.strftime('%d-%b-%Y')
    df.loc['Total'] = df.sum()
    #df = df.round(0)
    
    return df