
"""
Email report showing current renewables DE wind forecast from Bloomberg

"""


import logging
import traceback
import configparser
import platform

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.util.htmlutils import df2html

from util import get_wind_data, handle_df


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/bbg_renewables_fcst')


# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'bbg_renewables_fcst.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_bbg_renewables_fcst.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'


email_subject = datetime.today().strftime('%Y-%m-%d') + ' DE Wind Delta'

    
try:
    logging.info('Generating report')
    
    # Get data
    de_wind_gen = handle_df(get_wind_data())
    
    # Get total diff
    diff = de_wind_gen.loc['Total','Delta']
    
    # Construct email subject
    email_subject_change = f"{email_subject}: {diff:+,.0f}GW {de_wind_gen.columns[0].replace(' Gen', '')} vs {de_wind_gen.columns[1].replace(' Gen', '')}"
    
    # Convert to html
    #df_html = de_wind_gen.to_html(index_names=False)
    df_html = df2html(de_wind_gen, highlight_weekends=True, precision=0, index_dt_format='%d-%b-%Y')
    
    # Construct email body
    email_body = f"""<p><b>DE Wind Generation forecasts using EC Ensemble Mean:</b>
                    <br>
                    {df_html}
                    <br><b>Notes:</b>
                    <br>All values are GW
                    <br>Data is queried live from Bloomberg (see EFOR for more info)
                    <br>Forecasts are produced by European Power Forecasting Ltd (EPF)
                    """
    
    # Send email
    send_email(receivers, 
               email_subject_change, 
               email_body,
               from_address='eu.gap.reports@jainglobal.com')    
    
    
    logging.info('Report sent')
    

except Exception:
    logging.error('Failed generating report')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))        