from jao.jao import JaoPublicationToolPandasClient
from jao.exceptions import NoMatchingDataError
import arcticdb as arctic

import pandas as pd
from pathlib import Path
from datetime import datetime
import logging
import matplotlib.pyplot as plt
import matplotlib.colors
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
import numpy as np

from entsoe import EntsoePandasClient


ENTSOE_API_KEY = '98c0eeb9-19cf-4664-8bb6-5dad7a3ac105'

try:
    from .flowbased_report import JAO_API_KEY
except ImportError:
    from flowbased_report import JAO_API_KEY


# Configure logging (re-use same style as flowbased_report)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


class ConstraintDataHandler:
    """
    Data handler focused on scraping and storing grid constraints (shadowPrices)
    using JAO's `query_active_constraints` endpoint.
    """

    def __init__(self):
        self.jao = JaoPublicationToolPandasClient(JAO_API_KEY)

        # Create data folder if it doesn't exist (share same Arctic DB as flowbased_report)
        script_dir = Path(__file__).parent
        data_dir = script_dir / "data"
        data_dir.mkdir(exist_ok=True)

        # Initialize Arctic with data folder
        self.ac = arctic.Arctic(f"lmdb://{data_dir}")

        # Create / open shared 'jao' library
        if "jao" not in self.ac.list_libraries():
            self.ac.create_library("jao")

        self.lib = self.ac["jao"]

    # -------------------------------------------------------------------------
    # LOAD LAYER
    # -------------------------------------------------------------------------
    def load_active_constraints(self, start_date: pd.Timestamp, end_date: pd.Timestamp) -> pd.DataFrame:
        """
        Load (scrape) active constraints (shadowPrices) from JAO for the given
        date range [start_date, end_date], inclusive.
        """
        # Normalize to a common timezone to avoid pandas date_range tz conflicts
        if start_date.tzinfo is None:
            start_date = start_date.tz_localize("UTC")
        else:
            start_date = start_date.tz_convert("UTC")

        if end_date.tzinfo is None:
            end_date = end_date.tz_localize("UTC")
        else:
            end_date = end_date.tz_convert("UTC")

        logging.info(f"Loading active constraints from {start_date} to {end_date}")
        constraints = []

        date_range = pd.date_range(start_date, end_date)
        total_days = len(date_range)

        for idx, day in enumerate(date_range, 1):
            logging.info(f"Scraping active constraints for {day.date()} ({idx}/{total_days})")
            try:
                day_df = self.jao.query_active_constraints(day)
            except NoMatchingDataError:
                logging.info(f"No active constraints returned by JAO for {day.date()} – skipping")
                continue

            # Skip empty or all-NA frames to avoid concat dtype warnings
            if day_df is None or day_df.empty or day_df.isna().all().all():
                logging.info(f"Active constraints for {day.date()} empty/all-NA – skipping")
                continue

            constraints.append(day_df)

        if not constraints:
            logging.warning("No active constraints data returned from JAO for the entire range")
            return pd.DataFrame()

        # Concatenate only non-empty / non-all-NA frames
        constraints_df = pd.concat(constraints)
        # Drop columns that are entirely NA across the whole range to avoid
        # pandas' concat deprecation warning and unnecessary schema drift
        constraints_df = constraints_df.dropna(axis=1, how="all")
        # Ensure a clean DateTimeIndex named 'mtu' (as in flowbased_report)
        constraints_df = constraints_df.reset_index().sort_values(["mtu", "tso"])
        constraints_df = constraints_df.set_index("mtu")

        # Ensure stable dtypes for known columns to avoid Arctic schema drift.
        # 'ram_mcp' has previously been stored as UTF/string in Arctic, so we coerce
        # to plain Python string (object-dtype) here to match the existing symbol.
        if "ram_mcp" in constraints_df.columns:
            constraints_df["ram_mcp"] = constraints_df["ram_mcp"].astype(str)

        # Replace 'de_lu' with 'de' in column names (e.g. ptdf_DE_LU -> ptdf_DE)
        constraints_df = constraints_df.rename(columns=lambda x: x.replace('DE_LU', 'DE').replace('de_lu', 'de'))

        logging.info(f"Loaded {len(constraints_df)} rows of active constraints data")
        return constraints_df

    # -------------------------------------------------------------------------
    # SAVE LAYER (same methodology as in flowbased_report)
    # -------------------------------------------------------------------------
    def _save_to_arctic(self, df: pd.DataFrame, symbol: str) -> None:
        """
        Generic method to save dataframe to Arctic with duplicate prevention.
        Only appends data after the max datetime index in existing data.
        """
        if df.empty:
            logging.info(f"No data to save for symbol '{symbol}'")
            return

        if self.lib.has_symbol(symbol):
            existing_df = self.lib.read(symbol).data
            max_date = existing_df.index.max()
            logging.info(f"Symbol '{symbol}' exists. Current max date: {max_date}")

            new_data = df[df.index > max_date]

            if len(new_data) > 0:
                logging.info(f"Appending {len(new_data)} new rows to '{symbol}' (after {max_date})")
                self.lib.append(symbol, new_data)
                logging.info(f"Successfully appended data to '{symbol}'")
            else:
                logging.info(f"No new data to append to '{symbol}'")
        else:
            logging.info(f"Creating new symbol '{symbol}' with {len(df)} rows")
            self.lib.write(symbol, df)
            logging.info(f"Successfully created and saved '{symbol}'")

    def save_active_constraints(self, df: pd.DataFrame) -> None:
        """
        Validate and save active constraints to Arctic.
        """
        logging.info("Validating active constraints data before saving...")

        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        assert "tso" in df.columns, "active_constraints must contain 'tso' column"

        logging.info("Validation passed. Saving active constraints...")
        self._save_to_arctic(df, "active_constraints")

    # Convenience wrapper: scrape and save in one go
    def load_and_save_active_constraints(self, start_date: pd.Timestamp, end_date: pd.Timestamp) -> pd.DataFrame:
        df = self.load_active_constraints(start_date, end_date)
        if not df.empty:
            self.save_active_constraints(df)
        return df



class ConstraintReportGenerator:
    """PDF report generator styled after institutional research publications."""

    # --- Design System --------------------------------------------------
    NAVY       = "#1B2A4A"
    CHARCOAL   = "#2D3436"
    DARK_GREY  = "#636E72"
    MID_GREY   = "#B2BEC3"
    LIGHT_GREY = "#DFE6E9"
    BG_GREY    = "#F8F9FA"
    ACCENT     = "#0984E3"
    RED        = "#D63031"
    AMBER      = "#E17055"
    GREEN      = "#00B894"

    PALETTE = [
        "#0984E3", "#D63031", "#00B894", "#6C5CE7",
        "#E17055", "#00CEC9", "#FDCB6E", "#E84393",
        "#2D3436", "#636E72",
    ]

    REGIME_COLORS = [BG_GREY, "#FFEAA7", AMBER, RED]

    PAGE_W, PAGE_H = 16, 11  # landscape A4-ish

    def __init__(self, handler=None, output_dir="."):
        self.handler = handler or ConstraintDataHandler()
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self._apply_theme()

        self.country_tso_mapping = {
            "FR": ["RTE", "Rte"],
            "DE": ["Amprion", "TennetGmbh", "50Hertz", "TransnetBW"],
            "NL": ["TennetBv", "TenneT NL"],
            "BE": ["Elia"],
            "AT": ["APG", "Apg"],
            "PL": ["PSE"],
            "CZ": ["CEPS", "ČEPS"],
            "SK": ["SEPS"],
            "HU": ["MAVIR"],
            "RO": ["Transelectrica"],
            "HR": ["HOPS"],
            "SI": ["ELES"],
        }

        self.current_page = 1

    # --- Theme ----------------------------------------------------------
    @staticmethod
    def _apply_theme():
        sns.set_theme(style="white")
        rc = {
            "font.family":        "sans-serif",
            "font.sans-serif":    ["Helvetica Neue", "Helvetica", "Arial", "Calibri"],
            "font.size":          9,
            "axes.titlesize":     10,
            "axes.titleweight":   "bold",
            "axes.labelsize":     8,
            "axes.linewidth":     0.6,
            "axes.edgecolor":     "#B2BEC3",
            "axes.grid":          True,
            "grid.color":         "#DFE6E9",
            "grid.linewidth":     0.4,
            "grid.alpha":         0.7,
            "xtick.labelsize":    7,
            "ytick.labelsize":    7,
            "xtick.major.width":  0.5,
            "ytick.major.width":  0.5,
            "xtick.color":        "#636E72",
            "ytick.color":        "#636E72",
            "legend.fontsize":    7,
            "legend.framealpha":  0.95,
            "legend.edgecolor":   "#DFE6E9",
            "figure.facecolor":   "white",
            "axes.facecolor":     "white",
            "savefig.facecolor":  "white",
        }
        plt.rcParams.update(rc)

    def get_active_constraints(self):
        if self.handler.lib.has_symbol("active_constraints"):
            return self.handler.lib.read("active_constraints").data
        return pd.DataFrame()

    def _calculate_frequency_data(self, df, start_date, end_date, zone_from, zone_to):
        # Filter relevant constraints based on hubFrom/hubTo
        relevant_df = df.loc[(df['hubFrom'] == zone_from) & (df['hubTo'] == zone_to)]
        
        if relevant_df.empty:
            return None

        # Deduplicate per MTU and CNEC
        relevant_df = relevant_df.reset_index()[["mtu", "cnec_name"]].drop_duplicates()
        relevant_df["active"] = 1
        
        # Pivot to continuous time series
        pivot_df = relevant_df.pivot(index="mtu", columns="cnec_name", values="active").fillna(0)
        
        # Reindex to full hourly range
        full_range_end = end_date + pd.Timedelta(days=1) - pd.Timedelta(hours=1)
        full_idx = pd.date_range(start=start_date, end=full_range_end, freq="1h", tz="UTC")
        pivot_df = pivot_df.reindex(full_idx, fill_value=0)
        
        # Rolling Window (14 Days)
        window_days = 14
        rolling_freq = pivot_df.rolling(window=f"{window_days}D", min_periods=window_days*24).mean()
        
        # Drop the initial NaN period
        return rolling_freq.dropna(axis=0, how="all")

    def _get_top_occurring_constraints(self, df, n=10):
        # Rank CNECs by frequency of occurrence (row count)
        return df["cnec_name"].value_counts().nlargest(n).index
    
    def _add_header_footer(self, fig, country, content_title, current_page, total_pages=2):
        """Institutional-style header and footer with accent stripe."""
        from matplotlib.patches import Rectangle

        # Thin navy accent stripe at very top
        fig.patches.append(Rectangle(
            (0, 0.975), 1, 0.025,
            transform=fig.transFigure, facecolor=self.NAVY,
            edgecolor="none", zorder=1000,
        ))

        # Report title (navy, left-aligned, below stripe)
        fig.text(
            0.04, 0.96,
            f"Grid Constraint Report  |  {country.upper()}",
            fontsize=13, fontweight="bold", va="center", ha="left",
            color=self.NAVY, zorder=1002,
        )
        # Section subtitle (grey, right-aligned)
        fig.text(
            0.96, 0.96, content_title,
            fontsize=10, va="center", ha="right",
            color=self.DARK_GREY, zorder=1002,
        )
        # Thin rule under header text
        fig.patches.append(Rectangle(
            (0.04, 0.948), 0.92, 0.001,
            transform=fig.transFigure, facecolor=self.LIGHT_GREY,
            edgecolor="none", zorder=1000,
        ))

        # Footer: thin line + page number + date
        fig.patches.append(Rectangle(
            (0.04, 0.032), 0.92, 0.001,
            transform=fig.transFigure, facecolor=self.LIGHT_GREY,
            edgecolor="none", zorder=1000,
        ))
        fig.text(
            0.04, 0.016,
            f"Jain Global  |  European Power Grid Constraints  |  {datetime.now().strftime('%d %b %Y')}",
            fontsize=7, va="center", ha="left", color=self.DARK_GREY, zorder=1002,
        )
        fig.text(
            0.96, 0.016, f"Page {current_page} / {total_pages}",
            fontsize=7, va="center", ha="right", color=self.DARK_GREY, zorder=1002,
        )

    def generate_report(self, start_date, end_date, country_code="FR"):
        logging.info(f"Generating Constraint Report for {country_code} ({start_date.date()} to {end_date.date()})...")
        
        # Load Data
        df = self.get_active_constraints()
        if df.empty:
            logging.warning("No active constraints data found in Arctic.")
            return
            
        # Filter by date first
        df = df.sort_index()
        df_period = df[(df.index >= start_date) & (df.index <= end_date)]
        
        if df_period.empty:
             logging.warning("No data in requested date range.")
             return

        # Filter for Country TSOs
        tsos = self.country_tso_mapping.get(country_code, [])
        if not tsos:
            logging.warning(f"No TSO mapping found for country code {country_code}")
            # If unknown country, maybe try to use it as a TSO name directly?
            # But for now, let's be strict.
            return

        df_country = df_period[df_period['tso'].isin(tsos)].copy()
        
        if df_country.empty:
            unique_tsos = df_period['tso'].unique() if 'tso' in df_period.columns else "No 'tso' column"
            logging.warning(f"No active constraints for {country_code} (TSOs: {tsos}) found. Available TSOs: {unique_tsos}")
            return

        self.current_page = 1
        total_pages = 3

        pdf_path = self.output_dir / f"{country_code.lower()}_constraint_report.pdf"
        with PdfPages(pdf_path) as pdf:
            # 1. Shadow Price Analysis (Long Term + Short Term)
            self._plot_shadow_price_combined_page(pdf, df_country, end_date, country_code, total_pages)

            # 2. Congestion Regime & Seasonal Profile
            self._plot_regime_and_seasonal_page(pdf, df_country, country_code, total_pages)

            # 3. Weekly Shadow Price Profile (Bar + Line)
            self._plot_weekly_stats_page(pdf, df_country, country_code, total_pages)

        logging.info(f"Report generated: {pdf_path}")

    # -------------------------------------------------------------------------
    # COMPOSITION DRIFT (Jaccard Similarity)
    # -------------------------------------------------------------------------
    @staticmethod
    def _jaccard(a: set, b: set) -> float:
        if not a and not b:
            return float("nan")
        if not a or not b:
            return 0.0
        return len(a & b) / len(a | b)

    def _compute_daily_cnec_scores(self, df: pd.DataFrame, score_mode: str = "impact") -> pd.DataFrame:
        """
        Compute per-day scores per CNEC for set-building / ranking.

        score_mode:
          - "impact": sum of positive hourly shadow prices over the day
          - "frequency": number of active hours in the day
        """
        if df.empty:
            return pd.DataFrame(columns=["day", "cnec_name", "score"])

        tmp = df.reset_index().copy()
        if "mtu" not in tmp.columns:
            raise ValueError("Expected 'mtu' column after reset_index().")

        tmp["mtu"] = pd.to_datetime(tmp["mtu"])
        if tmp["mtu"].dt.tz is None:
            tmp["mtu"] = tmp["mtu"].dt.tz_localize("UTC")
        else:
            tmp["mtu"] = tmp["mtu"].dt.tz_convert("UTC")

        tmp = tmp.dropna(subset=["cnec_name"])
        tmp["day"] = tmp["mtu"].dt.floor("D")

        # De-duplicate per (mtu, cnec) by averaging shadow_price in case there are
        # multiple rows per hour (e.g., multiple TSOs/variants for same CNEC).
        per_hour = tmp.groupby(["day", "mtu", "cnec_name"], as_index=False)["shadow_price"].mean()

        if score_mode not in {"impact", "frequency"}:
            raise ValueError("score_mode must be one of {'impact','frequency'}")

        if score_mode == "frequency":
            daily = (
                per_hour.groupby(["day", "cnec_name"])
                .size()
                .rename("score")
                .reset_index()
            )
        else:
            daily = (
                per_hour.assign(shadow_pos=lambda x: np.maximum(x["shadow_price"].astype(float), 0.0))
                .groupby(["day", "cnec_name"])["shadow_pos"]
                .sum()
                .rename("score")
                .reset_index()
            )

        return daily.sort_values(["day", "score"], ascending=[True, False])

    def _top_n_set_for_window(
        self,
        daily_scores: pd.DataFrame,
        window_start: pd.Timestamp,
        window_end: pd.Timestamp,
        n: int,
    ) -> set:
        window = daily_scores[(daily_scores["day"] >= window_start) & (daily_scores["day"] <= window_end)]
        if window.empty:
            return set()
        summed = window.groupby("cnec_name")["score"].sum()
        return set(summed.nlargest(n).index)

    def _plot_constraint_composition_drift_page(self, pdf, df, country, total_pages):
        """Jaccard similarity drift (7 d vs 28 d) and daily set-similarity heatmap."""
        top_n = 15
        score_mode = "impact"
        heatmap_days = 60

        daily_scores = self._compute_daily_cnec_scores(df, score_mode=score_mode)
        if daily_scores.empty:
            logging.warning("No data available for composition drift plots.")
            return

        def _to_utc(ts) -> pd.Timestamp:
            t = pd.Timestamp(ts)
            return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")

        days = pd.Index(sorted(daily_scores["day"].unique()))
        if len(days) < 35:
            logging.warning("Not enough days for 7 d vs 28 d comparison (need ~35+).")
            return

        rows = []
        for d in days:
            d = _to_utc(d)
            w7_s, w7_e = d - pd.Timedelta(days=7), d - pd.Timedelta(days=1)
            w28_s, w28_e = d - pd.Timedelta(days=28), d - pd.Timedelta(days=1)
            if w28_s < days.min():
                continue
            s7 = self._top_n_set_for_window(daily_scores, w7_s, w7_e, top_n)
            s28 = self._top_n_set_for_window(daily_scores, w28_s, w28_e, top_n)
            rows.append({
                "day": d,
                "jaccard_7d_vs_28d": self._jaccard(s7, s28),
                "entrants_7d_not_28d": len(s7 - s28),
            })

        drift = pd.DataFrame(rows).set_index("day").sort_index()
        if drift.empty:
            logging.warning("Composition drift series empty after windowing.")
            return

        recent_days = days[-heatmap_days:] if len(days) > heatmap_days else days
        day_sets = {_to_utc(d): set(daily_scores[daily_scores["day"] == d].nlargest(top_n, "score")["cnec_name"])
                    for d in recent_days}
        idx = list(day_sets.keys())
        n = len(idx)
        mat = np.array([[self._jaccard(day_sets[idx[i]], day_sets[idx[j]]) for j in range(n)] for i in range(n)])

        fig = plt.figure(figsize=(self.PAGE_W, self.PAGE_H))
        self._add_header_footer(
            fig, country,
            f"Constraint Composition Drift  (Jaccard, top {top_n})",
            self.current_page, total_pages,
        )
        self.current_page += 1

        gs = gridspec.GridSpec(
            2, 1, figure=fig, height_ratios=[0.85, 1.3],
            top=0.93, bottom=0.06, left=0.08, right=0.93, hspace=0.38,
        )

        # (A) 7 d vs 28 d Jaccard time series
        ax1 = fig.add_subplot(gs[0])
        ax1.plot(drift.index, drift["jaccard_7d_vs_28d"], color=self.NAVY, linewidth=1.6,
                 label="Jaccard (7 d vs 28 d)")
        ax1.set_ylim(0, 1.05)
        ax1.set_ylabel("Jaccard Similarity")
        ax1.set_title("Short-term (7 d) vs Baseline (28 d) Top-N Set Similarity", loc="left", pad=5)
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
        for lbl in ax1.get_xticklabels():
            lbl.set_rotation(30)
            lbl.set_ha("right")
        for spine in ("top", "right"):
            ax1.spines[spine].set_visible(False)

        ax1b = ax1.twinx()
        ax1b.bar(drift.index, drift["entrants_7d_not_28d"], width=0.8, alpha=0.22,
                 color=self.RED, label="New in 7 d (not in 28 d)")
        ax1b.set_ylabel("# New Constraints")
        ax1b.grid(False)
        ax1b.spines["top"].set_visible(False)

        h1, l1 = ax1.get_legend_handles_labels()
        h2, l2 = ax1b.get_legend_handles_labels()
        ax1.legend(h1 + h2, l1 + l2, loc="upper left", fontsize=6.5, frameon=True, edgecolor=self.LIGHT_GREY)

        # (B) Daily Jaccard heatmap
        ax2 = fig.add_subplot(gs[1])
        cmap_jac = sns.light_palette(self.NAVY, as_cmap=True)
        sns.heatmap(
            mat, ax=ax2, cmap=cmap_jac, vmin=0, vmax=1,
            cbar_kws={"label": "Jaccard Similarity"},
            xticklabels=[d.strftime("%m-%d") for d in idx],
            yticklabels=[d.strftime("%m-%d") for d in idx],
        )
        ax2.set_title(f"Daily Top-N Set Similarity  (last {n} days)", loc="left", pad=5)
        ax2.set_xlabel("Day")
        ax2.set_ylabel("Day")
        step = max(1, n // 12)
        ax2.set_xticks(np.arange(0, n, step))
        ax2.set_xticklabels([idx[i].strftime("%m-%d") for i in range(0, n, step)], rotation=45, ha="right")
        ax2.set_yticks(np.arange(0, n, step))
        ax2.set_yticklabels([idx[i].strftime("%m-%d") for i in range(0, n, step)], rotation=0)

        pdf.savefig(fig)
        plt.close(fig)

    def _plot_weekly_stats_page(self, pdf, df, country, total_pages):
        """Weekly trend (bar + line), day-of-week and hour-of-day profiles."""
        fig = plt.figure(figsize=(self.PAGE_W, self.PAGE_H))
        self._add_header_footer(fig, country, "Weekly Shadow Price Profile", self.current_page, total_pages)
        self.current_page += 1

        weekly = df.resample("W")["shadow_price"].agg(["mean", "sum", "count", "max"])

        gs = gridspec.GridSpec(
            2, 2, figure=fig,
            height_ratios=[1.4, 1],
            top=0.93, bottom=0.07, left=0.07, right=0.93,
            hspace=0.35, wspace=0.20,
        )

        # --- Weekly trend (top, full width) -------------------------
        ax1 = fig.add_subplot(gs[0, :])
        ax1.bar(
            weekly.index, weekly["mean"], width=5,
            color=self.ACCENT, alpha=0.70, label="Avg Shadow Price (EUR/MW)",
            edgecolor=self.ACCENT, linewidth=0.3,
        )
        ax1.set_ylabel("Average Shadow Price (EUR/MW)", color=self.NAVY)
        ax1.tick_params(axis="y", labelcolor=self.NAVY)
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
        ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        ax1.spines["top"].set_visible(False)

        ax2 = ax1.twinx()
        ax2.plot(
            weekly.index, weekly["count"], color=self.RED,
            linewidth=1.3, marker="o", markersize=1.8, alpha=0.75, label="Constraint Count",
        )
        ax2.set_ylabel("Number of Constraints", color=self.RED)
        ax2.tick_params(axis="y", labelcolor=self.RED)
        ax2.grid(False)
        ax2.spines["top"].set_visible(False)

        h1, l1 = ax1.get_legend_handles_labels()
        h2, l2 = ax2.get_legend_handles_labels()
        ax1.legend(h1 + h2, l1 + l2, loc="upper right", frameon=True, edgecolor=self.LIGHT_GREY)
        ax1.set_title("Weekly Average Shadow Price & Constraint Activity", loc="left", pad=6)

        # --- Day-of-week (bottom left) ------------------------------
        ax_dow = fig.add_subplot(gs[1, 0])
        df_tmp = df.copy()
        df_tmp["dow"] = df_tmp.index.dayofweek
        df_tmp["hour"] = df_tmp.index.hour
        dow_profile = df_tmp.groupby("dow")["shadow_price"].mean()
        dow_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

        colors_dow = [self.ACCENT if v < dow_profile.mean() else self.RED for v in dow_profile.values]
        ax_dow.bar(dow_names, dow_profile.values, color=colors_dow, alpha=0.80, edgecolor="white", linewidth=0.5)
        ax_dow.axhline(dow_profile.mean(), color=self.CHARCOAL, linestyle="--", linewidth=1.0, alpha=0.6, label="Avg")
        ax_dow.set_ylabel("Avg Shadow Price (EUR/MW)")
        ax_dow.set_title("Day-of-Week Profile", loc="left", pad=4)
        for spine in ("top", "right"):
            ax_dow.spines[spine].set_visible(False)
        ax_dow.legend(loc="upper right", frameon=True, edgecolor=self.LIGHT_GREY)

        # --- Hour-of-day (bottom right) -----------------------------
        ax_hod = fig.add_subplot(gs[1, 1])
        hour_profile = df_tmp.groupby("hour")["shadow_price"].mean()

        cmap_bar = sns.light_palette(self.ACCENT, as_cmap=True)
        norm_v = (hour_profile.values - hour_profile.min()) / (hour_profile.max() - hour_profile.min() + 1e-6)
        colors_hod = cmap_bar(norm_v * 0.85 + 0.15)

        ax_hod.bar(
            hour_profile.index, hour_profile.values,
            color=colors_hod, alpha=0.90, edgecolor="white", width=0.8, linewidth=0.5,
        )
        ax_hod.axhline(hour_profile.mean(), color=self.CHARCOAL, linestyle="--", linewidth=1.0, alpha=0.6, label="Avg")
        ax_hod.set_ylabel("Avg Shadow Price (EUR/MW)")
        ax_hod.set_xlabel("Hour of Day")
        ax_hod.set_title("Hour-of-Day Profile", loc="left", pad=4)
        ax_hod.set_xticks(range(0, 24, 3))
        for spine in ("top", "right"):
            ax_hod.spines[spine].set_visible(False)
        ax_hod.legend(loc="upper right", frameon=True, edgecolor=self.LIGHT_GREY)

        pdf.savefig(fig)
        plt.close(fig)

    def _plot_shadow_price_combined_page(self, pdf, df, end_date, country, total_pages):
        """Shadow Price Analysis — yearly small-multiples above a 60-day detail panel."""
        import matplotlib.lines as mlines

        top_cnecs = self._get_top_occurring_constraints(df, n=10)
        color_map = {cnec: self.PALETTE[i % len(self.PALETTE)] for i, cnec in enumerate(top_cnecs)}

        years = sorted(df.index.year.unique())
        n_years = len(years)

        fig = plt.figure(figsize=(self.PAGE_W, self.PAGE_H))
        self._add_header_footer(fig, country, "Shadow Price Analysis", self.current_page, total_pages)
        self.current_page += 1

        n_cols_yearly = min(3, n_years)
        n_rows_yearly = (n_years + n_cols_yearly - 1) // n_cols_yearly

        gs = gridspec.GridSpec(
            n_rows_yearly + 1, n_cols_yearly, figure=fig,
            height_ratios=[1] * n_rows_yearly + [1.3],
            top=0.93, bottom=0.06, left=0.06, right=0.87,
            hspace=0.40, wspace=0.18,
        )

        # --- Prepare rolling averages --------------------------------
        full_idx = pd.date_range(df.index.min(), df.index.max(), freq="1h")
        df_top = df[df["cnec_name"].isin(top_cnecs)]
        pivot_top = df_top.reset_index().pivot_table(
            index="mtu", columns="cnec_name", values="shadow_price", aggfunc="mean",
        )
        pivot_top = pivot_top.reindex(full_idx, fill_value=0).fillna(0)
        rolling_avg = pivot_top.mean(axis=1).rolling(window=24 * 7, min_periods=24, center=True).mean()

        def _normalise_year(idx):
            return idx.map(lambda x: x.replace(year=2000))

        # --- Small-multiple yearly panels ----------------------------
        for i, year in enumerate(years):
            ax = fig.add_subplot(gs[i // n_cols_yearly, i % n_cols_yearly])
            yr_s = pd.Timestamp(f"{year}-01-01", tz="UTC")
            yr_e = pd.Timestamp(f"{year}-12-31 23:59:59", tz="UTC")
            yr_idx = pd.date_range(yr_s, yr_e, freq="1h")
            yr_df = df[(df.index >= yr_s) & (df.index <= yr_e)]
            yr_roll = rolling_avg[(rolling_avg.index >= yr_s) & (rolling_avg.index <= yr_e)]

            for cnec in top_cnecs:
                subset = yr_df[yr_df["cnec_name"] == cnec]
                if subset.empty:
                    continue
                s = subset.groupby("mtu")["shadow_price"].mean().reindex(yr_idx, fill_value=0)
                s_r = s.rolling(window=24 * 7, min_periods=24, center=True).mean()
                ax.plot(_normalise_year(s_r.index), s_r, color=color_map[cnec], alpha=0.8, linewidth=0.9)

            if not yr_roll.empty:
                ax.plot(_normalise_year(yr_roll.index), yr_roll, color=self.NAVY, linewidth=1.8, alpha=0.9)

            ax.set_ylabel("EUR/MW" if i % n_cols_yearly == 0 else "")
            ax.set_title(str(year), loc="left", pad=4)
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%b"))
            ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
            for spine in ("top", "right"):
                ax.spines[spine].set_visible(False)

        # --- 60-day detail panel (bottom, full width) ----------------
        ax_s = fig.add_subplot(gs[n_rows_yearly, :])
        start_short = end_date - pd.Timedelta(days=60)
        df_short = df[df.index >= start_short]

        if not df_short.empty:
            top_short = self._get_top_occurring_constraints(df_short, n=8)
            cm_short = {c: self.PALETTE[i % len(self.PALETTE)] for i, c in enumerate(top_short)}
            idx_s = pd.date_range(start_short, end_date, freq="1h")
            piv_s = (
                df_short[df_short["cnec_name"].isin(top_short)]
                .reset_index()
                .pivot_table(index="mtu", columns="cnec_name", values="shadow_price", aggfunc="mean")
                .reindex(idx_s, fill_value=0)
                .fillna(0)
            )
            roll_s = piv_s.mean(axis=1).rolling(window=24 * 7, min_periods=24, center=True).mean()

            for cnec in top_short:
                if cnec in piv_s.columns:
                    r = piv_s[cnec].rolling(window=24 * 7, min_periods=24, center=True).mean()
                    ax_s.plot(r.index, r, color=cm_short[cnec], alpha=0.8, linewidth=1.1)

            if not roll_s.empty:
                ax_s.plot(roll_s.index, roll_s, color=self.NAVY, linewidth=2.2, alpha=0.9)

            hdl = [mlines.Line2D([], [], color=cm_short[c], label=self._truncate_cnec_name(c, 32), linewidth=1.8)
                   for c in top_short]
            hdl.append(mlines.Line2D([], [], color=self.NAVY, linewidth=2.2, label="Market Avg"))
            ax_s.legend(
                handles=hdl, loc="upper left", bbox_to_anchor=(1.01, 1.0),
                fontsize=6.5, title="Top CNECs (60 d)", title_fontsize=7.5,
                frameon=True, edgecolor=self.LIGHT_GREY,
            )

        ax_s.set_title(
            f"Last 60 Days  ({start_short.strftime('%d %b')} \u2013 {end_date.strftime('%d %b %Y')})",
            loc="left", pad=6,
        )
        ax_s.set_ylabel("EUR/MW")
        ax_s.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
        ax_s.xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
        for spine in ("top", "right"):
            ax_s.spines[spine].set_visible(False)

        # Long-term legend (right margin)
        hdl_lt = [mlines.Line2D([], [], color=color_map[c], label=self._truncate_cnec_name(c, 32), linewidth=1.8)
                  for c in top_cnecs]
        hdl_lt.append(mlines.Line2D([], [], color=self.NAVY, linewidth=2.2, label="Market Avg"))
        fig.legend(
            handles=hdl_lt, loc="upper left", bbox_to_anchor=(0.88, 0.93),
            fontsize=6.5, title="Top CNECs (All Time)", title_fontsize=7.5,
            frameon=True, edgecolor=self.LIGHT_GREY,
        )

        pdf.savefig(fig)
        plt.close(fig)

    def _truncate_cnec_name(self, name, max_len=35):
        """Truncate CNEC name for cleaner legend display."""
        if len(name) > max_len:
            return name[:max_len - 3] + "..."
        return name

    def _plot_regime_and_seasonal_page(self, pdf, df, country, total_pages):
        """Congestion regime timeline + seasonal hour/month heatmaps."""
        from matplotlib.patches import Patch

        hourly_active = df.groupby("mtu").size().clip(upper=1)
        full_idx = pd.date_range(df.index.min(), df.index.max(), freq="1h")
        hourly_series = hourly_active.reindex(full_idx, fill_value=0)
        hourly_df = pd.DataFrame({"active": hourly_series})
        hourly_df["year"] = hourly_df.index.year
        hourly_df["month"] = hourly_df.index.month
        hourly_df["hour"] = hourly_df.index.hour
        years = sorted(hourly_df["year"].unique())
        n_years = len(years)

        fig = plt.figure(figsize=(self.PAGE_W, self.PAGE_H))
        self._add_header_footer(fig, country, "Congestion Regime & Seasonal Profile", self.current_page, total_pages)
        self.current_page += 1

        hourly_max = df.groupby("mtu")["shadow_price"].max().reindex(full_idx, fill_value=0)

        n_cols = min(3, n_years)
        n_rows = (n_years + n_cols - 1) // n_cols

        gs = gridspec.GridSpec(
            n_rows + 1, n_cols, figure=fig,
            height_ratios=[0.30] + [1] * n_rows,
            top=0.93, bottom=0.06, left=0.06, right=0.93,
            hspace=0.35, wspace=0.20,
        )

        # --- Regime timeline strip ----------------------------------
        ax_reg = fig.add_subplot(gs[0, :])
        six_h = hourly_max.resample("6h").max()
        data = six_h.values.reshape(1, -1)

        bounds = [0, 1, 100, 500, 9999]
        cmap_reg = matplotlib.colors.ListedColormap(self.REGIME_COLORS)
        norm_reg = matplotlib.colors.BoundaryNorm(bounds, cmap_reg.N)

        ax_reg.imshow(
            data, aspect="auto", cmap=cmap_reg, norm=norm_reg,
            extent=[mdates.date2num(six_h.index[0]), mdates.date2num(six_h.index[-1]), 0, 1],
        )
        ax_reg.xaxis_date()
        ax_reg.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
        ax_reg.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        ax_reg.set_yticks([])
        ax_reg.set_title("Congestion Regime Timeline  (6 h max shadow price, EUR/MW)", loc="left", pad=4)
        for spine in ("top", "right", "left"):
            ax_reg.spines[spine].set_visible(False)

        legend_el = [
            Patch(facecolor=self.BG_GREY,  edgecolor=self.MID_GREY, label="None"),
            Patch(facecolor="#FFEAA7",      edgecolor="#F0D78C",     label="Mild (< 100)"),
            Patch(facecolor=self.AMBER,     edgecolor="#C0603C",     label="Severe (< 500)"),
            Patch(facecolor=self.RED,       edgecolor="#A52020",     label="Extreme (\u2265 500)"),
        ]
        ax_reg.legend(
            handles=legend_el, loc="upper right", ncol=4,
            fontsize=6.5, framealpha=0.95, handlelength=1.1, handletextpad=0.3,
            edgecolor=self.LIGHT_GREY,
        )

        # --- Seasonal heatmaps (small-multiples) --------------------
        month_lbl = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"]
        cmap_heat = sns.light_palette(self.RED, as_cmap=True)

        for idx, year in enumerate(years):
            ax = fig.add_subplot(gs[idx // n_cols + 1, idx % n_cols])
            yr_data = hourly_df[hourly_df["year"] == year]
            pivot = yr_data.pivot_table(index="hour", columns="month", values="active", aggfunc="mean")
            pivot = pivot.reindex(columns=range(1, 13))

            sns.heatmap(
                pivot, cmap=cmap_heat, annot=False, ax=ax, vmin=0, vmax=1,
                cbar=False, linewidths=0.25, linecolor="white",
            )
            ax.set_title(str(year), loc="left", pad=4)
            ax.set_ylabel("Hour" if idx % n_cols == 0 else "")
            ax.set_xlabel("")
            ax.set_xticklabels(month_lbl, fontsize=7, rotation=0)
            ax.set_yticks([0, 6, 12, 18, 24])
            ax.set_yticklabels(["0", "6", "12", "18", "24"], fontsize=7)

        cbar_ax = fig.add_axes([0.95, 0.12, 0.012, 0.30])
        sm = plt.cm.ScalarMappable(cmap=cmap_heat, norm=plt.Normalize(vmin=0, vmax=1))
        sm.set_array([])
        cbar = fig.colorbar(sm, cax=cbar_ax)
        cbar.set_label("Congestion Probability", fontsize=7)
        cbar.ax.tick_params(labelsize=6)
        cbar.outline.set_edgecolor(self.LIGHT_GREY)

        pdf.savefig(fig)
        plt.close(fig)

if __name__ == "__main__":
    logging.info("=" * 60)
    logging.info("Starting Grid Constraint Scrape Script")
    logging.info("=" * 60)

    handler = ConstraintDataHandler()

    # ----------------------------------------------------------------------
    # 1. Determine dynamic date range from Arctic (same methodology)
    # ----------------------------------------------------------------------
    symbols_to_check = ["active_constraints"]
    max_dates = []

    for symbol in symbols_to_check:
        if handler.lib.has_symbol(symbol):
            try:
                df_symbol = handler.lib.read(symbol).data
                if not df_symbol.empty:
                    max_dates.append(df_symbol.index.max())
            except Exception as e:
                logging.warning(f"Could not read symbol '{symbol}': {e}")

    if max_dates:
        start_date = min(max_dates)
        logging.info(f"Computed per-symbol max dates: {max_dates}")
        logging.info(f"Dynamic start_date set to min(max_dates): {start_date}")
    else:
        # No existing data: start from a reasonable historical point
        start_date = pd.Timestamp(2022, 6, 9, tz="UTC")
        logging.info("No existing 'active_constraints' symbol, using default start_date 2022-06-09 UTC")

    end_date = pd.Timestamp.now(tz="UTC").normalize()
    logging.info(f"Dynamic end_date set to today (UTC): {end_date}")

    # ----------------------------------------------------------------------
    # 2. Scrape & save in 30-day chunks
    # ----------------------------------------------------------------------
    chunk_size = 30
    current_start = start_date

    logging.info(f"Total date range to update: {start_date} to {end_date}")
    logging.info(f"Processing in {chunk_size}-day chunks...")
    logging.info("=" * 60)

    chunk_num = 1
    while current_start < end_date:
        current_end = min(current_start + pd.Timedelta(days=chunk_size), end_date)

        logging.info("\\n" + "=" * 60)
        logging.info(f"CHUNK {chunk_num}: {current_start.date()} to {current_end.date()}")
        logging.info("=" * 60)

        try:
            df_chunk = handler.load_and_save_active_constraints(current_start, current_end)
            logging.info(f"Chunk {chunk_num} completed successfully with {len(df_chunk)} rows")
        except Exception as e:
            logging.error(f"Error processing chunk {chunk_num} ({current_start} -> {current_end}): {e}")
            import traceback

            traceback.print_exc()

        current_start = current_end + pd.Timedelta(days=1)
        chunk_num += 1

    # ----------------------------------------------------------------------
    # 3. Generate Report
    # ----------------------------------------------------------------------
    logging.info("=" * 60)
    logging.info("Generating Reports")
    logging.info("=" * 60)

    # Start date for the report analysis window (Core FB MC go-live)
    report_start_date = pd.Timestamp("2022-06-09", tz="UTC")

    try:
        report_gen = ConstraintReportGenerator(handler=handler, output_dir=".")
        report_gen.generate_report(report_start_date, end_date, country_code="FR")
    except Exception as e:
        logging.error(f"Error generating report: {e}")
        import traceback
        traceback.print_exc()

