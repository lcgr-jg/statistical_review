from jao.jao import JaoPublicationToolPandasClient
import arcticdb as arctic

import pandas as pd
from pathlib import Path

import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
from matplotlib.patches import Rectangle

import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

JAO_API_KEY = "ae7f763e-c60f-450b-9a07-574e775b9216"

CORE_FBMC_NEIGHBOURS = {
    "at": ["de", "si", "hu"],
    "be": ["fr", "de", "nl"],
    "hr": ["si", "hu"],
    "cz": ["de", "pl", "sk", "at"],
    "fr": ["be", "de"],
    "de": ["nl", "be", "fr", "at", "cz", "pl"],
    "hu": ["at", "sk", "si", "hr", "ro"],
    "nl": ["be", "de"],
    "pl": ["de", "cz", "sk"],
    "ro": ["hu"],
    "sk": ["cz", "pl", "hu"],
    "si": ["at", "hu", "hr"]
}


def process_scheduled_exchanges(df: pd.DataFrame) -> pd.DataFrame:
    """
    Processes scheduled exchanges data to create net flow columns (e.g., 'fr-de')
    by combining opposing directional flows (FR->DE minus DE->FR).
    Drops the original constituent columns.
    """
    new_df = df.copy()
    borders = [c for c in df.columns if c.startswith('border_')]
    processed_pairs = set()

    for col in borders:
        # Parse border code, e.g. 'border_FR_DE' -> ['FR', 'DE']
        parts = col.replace('border_', '').split('_')
        if len(parts) != 2:
            continue

        c1, c2 = parts[0], parts[1]

        # Sort to ensure we always process a pair in the same order (A-B)
        # This creates canonical names like 'at-cz', 'de-fr'
        # If the user preferred 'fr-de' specifically over 'de-fr', we'd need a mapping.
        # Here we default to alphabetical: Net Flow from Alphabetically First to Second.
        pair = tuple(sorted([c1, c2]))

        col_fwd = f"border_{pair[0]}_{pair[1]}"
        col_rev = f"border_{pair[1]}_{pair[0]}"

        # Name as requested: lowercase with hyphen, replace de_lu with de
        new_col_name = f"{pair[0].lower()}-{pair[1].lower()}".replace('de_lu', 'de')

        # Calculate Net Flow: Forward (A->B) - Reverse (B->A)
        # If one direction is missing, treat as 0 (though usually both exist in this dataset)
        val_fwd = df[col_fwd] if col_fwd in df.columns else 0
        val_rev = df[col_rev] if col_rev in df.columns else 0

        new_df[new_col_name] = val_fwd - val_rev
        processed_pairs.add(pair)

    # Drop the original 'border_X_Y' columns
    cols_to_drop = [c for c in new_df.columns if c.startswith('border_')]
    new_df.drop(columns=cols_to_drop, inplace=True)

    return new_df





class DataHandler():
    def __init__(self, context=None):
        self.context = context
        self.jao = JaoPublicationToolPandasClient(JAO_API_KEY)
        
        # Create data folder if it doesn't exist
        script_dir = Path(__file__).parent
        data_dir = script_dir / 'data'
        data_dir.mkdir(exist_ok=True)
        
        # Initialize Arctic with data folder
        self.ac = arctic.Arctic(f'lmdb://{data_dir}')
        
        # Create jao library if it doesn't exist
        if 'jao' not in self.ac.list_libraries():
            self.ac.create_library('jao')
        
        self.lib = self.ac['jao']

    def log(self, message, level="info"):
        if self.context:
            if level == "info":
                self.context.log.info(message)
            elif level == "warning":
                self.context.log.warning(message)
            elif level == "error":
                self.context.log.error(message)
        else:
            if level == "info":
                logging.info(message)
            elif level == "warning":
                logging.warning(message)
            elif level == "error":
                logging.error(message)

    def hydrate_cache(self, chunk_size=30):
        """
        Hydrate the ArcticDB cache with JAO data.
        Determines the start date based on existing data or defaults to FBMC start.
        """
        self.log("=" * 60)
        self.log("Hydrating Flow-Based Cache")
        self.log("=" * 60)
        
        # 1. Determine dynamic start/end dates from existing ArcticDB symbols
        symbols_to_check = [
            "scheduled_flow",
            "maxbex",
            "netpos",
            "minmax_netpos",
            "active_constraints",
            "allocation_constraint",
        ]
        max_dates = []
        for symbol in symbols_to_check:
            if self.lib.has_symbol(symbol):
                try:
                    df_symbol = self.lib.read(symbol).data
                    if not df_symbol.empty:
                        max_dates.append(df_symbol.index.max())
                except Exception as e:
                    self.log(f"Could not read symbol '{symbol}': {e}", level="warning")
        
        if max_dates:
            # Normalize all timestamps to UTC before comparing (some may be tz-naive)
            max_dates = [d.tz_localize('UTC') if d.tzinfo is None else d.tz_convert('UTC') for d in max_dates]
            # Use the minimum of the per-table maxima so we backfill from the "slowest" table
            start_date = min(max_dates)
            self.log(f"Computed per-symbol max dates: {max_dates}")
            self.log(f"Dynamic start_date set to min(max_dates): {start_date}")
        else:
            # No data in ArcticDB yet – fall back to a sensible historical start
            start_date = pd.Timestamp(2022, 6, 9, tz='UTC')
            self.log("No existing symbols found in ArcticDB, using default start_date 2022-06-09 UTC")
        
        # End date is today (UTC), normalised to midnight
        end_date = pd.Timestamp.now(tz='UTC').normalize()
        self.log(f"Dynamic end_date set to today (UTC): {end_date}")
        
        if start_date >= end_date:
            self.log("Cache is already up to date.")
            return

        # 2. Scrape & save new data in chunks
        current_start = start_date
        chunk_num = 1
        
        self.log(f"Total date range to update: {start_date} to {end_date}")
        self.log(f"Processing in {chunk_size}-day chunks...")
        
        while current_start < end_date:
            current_end = min(current_start + pd.Timedelta(days=chunk_size), end_date)
            
            self.log(f"CHUNK {chunk_num}: {current_start.date()} to {current_end.date()}")
            
            try:
                latest_flow, latest_maxbex, latest_netpos, latest_minmax_netpos, latest_alloc = self.load_latest(current_start, current_end)
                self.save_all(latest_flow, latest_maxbex, latest_netpos, latest_minmax_netpos, latest_alloc)
                self.log(f"Chunk {chunk_num} completed successfully")
            except Exception as e:
                self.log(f"Error processing chunk {chunk_num} ({current_start} -> {current_end}): {e}", level="error")
            
            current_start = current_end + pd.Timedelta(days=1)
            chunk_num += 1
        
        self.log("=" * 60)
        self.log("Cache hydration completed")
        self.log("=" * 60)

    def delete_all_symbols(self):
        """Delete all symbols from the Arctic library"""
        symbols = self.lib.list_symbols()
        if not symbols:
            logging.info("No symbols found in Arctic library")
            return
        
        logging.info(f"Found {len(symbols)} symbols to delete: {symbols}")
        for symbol in symbols:
            logging.info(f"Deleting symbol: {symbol}")
            self.lib.delete(symbol)
            logging.info(f"Successfully deleted: {symbol}")
        
        logging.info("All symbols deleted successfully")

    def load_latest(self , start_date , end_date):
        logging.info(f"Loading all data from {start_date} to {end_date}")
        flow = self.load_scheduled_flow(start_date, end_date)
        maxbex = self.load_maxbex(start_date, end_date)
        netpos = self.load_netpos(start_date, end_date)
        minmax_netpos = self.load_minmax_netpos(start_date, end_date)
        alloc_constraint = self.load_allocation_constraint(start_date, end_date)
        logging.info("All data loaded successfully")
        return flow, maxbex, netpos, minmax_netpos, alloc_constraint

    def load_scheduled_flow(self , start_date, end_date):
        logging.info(f"Loading scheduled flows from {start_date} to {end_date}")
        flow = self.jao.query_scheduled_exchange(start_date, end_date)
        flow = process_scheduled_exchanges(flow)
        logging.info(f"Loaded {len(flow)} rows of scheduled flow data")
        return flow

    def load_maxbex(self , start_date , end_date):
        logging.info(f"Loading maxbex from {start_date} to {end_date}")
        maxbex_df = []
        date_range = pd.date_range(start_date, end_date)
        total_days = len(date_range)
        for idx, day in enumerate(date_range, 1):
            logging.info(f"Scraping maxbex for {day.date()} ({idx}/{total_days})")
            maxbex = self.jao.query_maxbex(day)
            maxbex_df.append(maxbex)
        maxbex_df = pd.concat(maxbex_df)
        maxbex_df.columns = [col.lower().replace('>' , '-').replace('de_lu', 'de') for col in maxbex_df.columns]
        logging.info(f"Loaded {len(maxbex_df)} rows of maxbex data")
        return maxbex_df

    def load_netpos(self , start_date , end_date):
        logging.info(f"Loading net positions from {start_date} to {end_date}")
        netpos_df = []
        date_range = pd.date_range(start_date, end_date)
        total_days = len(date_range)
        for idx, day in enumerate(date_range, 1):
            logging.info(f"Scraping net positions for {day.date()} ({idx}/{total_days})")
            netpos = self.jao.query_net_position(day)
            netpos_df.append(netpos)
        netpos_df = pd.concat(netpos_df)
        netpos_df.columns = [col.replace('hub_', '').lower().replace('de_lu', 'de') for col in netpos_df.columns]
        logging.info(f"Loaded {len(netpos_df)} rows of net position data")
        return netpos_df

    def load_minmax_netpos(self , start_date , end_date):
        logging.info(f"Loading min/max net positions from {start_date} to {end_date}")
        minmax_df = []
        date_range = pd.date_range(start_date, end_date)
        total_days = len(date_range)
        for idx, day in enumerate(date_range, 1):
            logging.info(f"Scraping min/max net positions for {day.date()} ({idx}/{total_days})")
            minmax = self.jao.query_minmax_np(day)
            minmax_df.append(minmax)
        minmax_df = pd.concat(minmax_df)
        minmax_df.columns = [col.lower().replace('>' , '-').replace('de_lu', 'de') for col in minmax_df.columns]
        minmax_df = minmax_df.melt(ignore_index=False , var_name = 'zone' , value_name = 'value')
        minmax_df['type'] = ''
        minmax_df.loc[minmax_df['zone'].str.contains('min') == True, 'type'] = 'min'
        minmax_df.loc[minmax_df['zone'].str.contains('max') == True, 'type'] =  'max'
        minmax_df['zone'] = minmax_df['zone'].str.replace('min' , '').str.replace('max' ,'').str.replace('de_lu', 'de')
        minmax_df = minmax_df.reset_index().pivot_table(index = 'mtu' , columns = ['zone' , 'type'] , values = 'value')
        
        # Flatten MultiIndex columns for ArcticDB compatibility (zone_type format)
        minmax_df.columns = [f"{zone}_{type_}" for zone, type_ in minmax_df.columns]
        
        logging.info(f"Loaded {len(minmax_df)} rows of min/max net position data")
        return minmax_df

    def query_active_constraints(self , start_date , end_date):
        logging.info(f"Loading active constraints from {start_date} to {end_date}")
        active_constraints = []
        date_range = pd.date_range(start_date, end_date)
        total_days = len(date_range)
        for idx, day in enumerate(date_range, 1):
            logging.info(f"Scraping active constraints for {day.date()} ({idx}/{total_days})")
            day_constraints = self.jao.query_active_constraints(day)
            active_constraints.append(day_constraints)
        active_constraints_df = pd.concat(active_constraints)
        active_constraints_df = active_constraints_df.reset_index().sort_values(['mtu' , 'tso'])
        active_constraints_df = active_constraints_df.set_index('mtu')
        logging.info(f"Loaded {len(active_constraints_df)} rows of active constraints data")
        return active_constraints_df

    def load_allocation_constraint(self, start_date, end_date):
        """Load allocation constraint data (used for PL import/export limits)"""
        logging.info(f"Loading allocation constraints from {start_date} to {end_date}")
        alloc_df = self.jao.query_allocationconstraint(d_from=start_date, d_to=end_date)
        # Columns will be in format: zone_import or zone_export (e.g., pl_import, pl_export)
        alloc_df.columns = [col.lower().replace('de_lu', 'de') for col in alloc_df.columns]
        logging.info(f"Loaded {len(alloc_df)} rows of allocation constraint data")
        return alloc_df

    def _save_to_arctic(self, df: pd.DataFrame, symbol: str):
        """
        Generic method to save dataframe to Arctic with duplicate prevention.
        Only appends data after the max datetime index in existing data.
        """
        # Check if symbol exists and has data
        if self.lib.has_symbol(symbol):
            # Read existing data to get max datetime
            existing_df = self.lib.read(symbol).data
            max_date = existing_df.index.max()
            logging.info(f"Symbol '{symbol}' exists. Current max date: {max_date}")
            
            # Ensure timezone compatibility before comparison
            if df.index.tz is not None and max_date.tzinfo is None:
                max_date = max_date.tz_localize(df.index.tz)
            elif df.index.tz is None and max_date.tzinfo is not None:
                max_date = max_date.tz_localize(None)
            
            # Filter new data to only include rows after max_date
            new_data = df[df.index > max_date]
            
            if len(new_data) > 0:
                logging.info(f"Appending {len(new_data)} new rows to '{symbol}' (after {max_date})")
                self.lib.append(symbol, new_data)
                logging.info(f"Successfully appended data to '{symbol}'")
            else:
                logging.info(f"No new data to append to '{symbol}'")
        else:
            # Symbol doesn't exist, write all data
            logging.info(f"Creating new symbol '{symbol}' with {len(df)} rows")
            self.lib.write(symbol, df)
            logging.info(f"Successfully created and saved '{symbol}'")

    def _backfill_to_arctic(self, df: pd.DataFrame, symbol: str):
        """
        Backfill/gap-fill data to Arctic by merging with existing data.
        Used when we need to fill gaps or prepend older data.
        """
        if not self.lib.has_symbol(symbol):
            # Symbol doesn't exist, just write
            logging.info(f"Creating new symbol '{symbol}' with {len(df)} rows (backfill)")
            self.lib.write(symbol, df)
            logging.info(f"Successfully created '{symbol}'")
            return
        
        # Read existing data
        existing_df = self.lib.read(symbol).data
        # Normalize tz for safe comparison
        if isinstance(existing_df.index, pd.DatetimeIndex) and isinstance(df.index, pd.DatetimeIndex):
            if existing_df.index.tz is None and df.index.tz is not None:
                existing_df.index = existing_df.index.tz_localize(df.index.tz)
            elif existing_df.index.tz is not None and df.index.tz is None:
                df.index = df.index.tz_localize(existing_df.index.tz)
        min_date = existing_df.index.min()
        max_date = existing_df.index.max()
        logging.info(f"Symbol '{symbol}' exists. Date range: {min_date} to {max_date}, rows: {len(existing_df)}")
        
        # Find rows in new data that DON'T already exist in existing data (by index)
        # This handles both gaps and prepending
        new_indices = df.index.difference(existing_df.index)
        new_data = df.loc[new_indices]
        
        if len(new_data) > 0:
            logging.info(f"Adding {len(new_data)} new rows to '{symbol}' (gap-fill/backfill)")
            # Concatenate: existing data + new data
            combined = pd.concat([existing_df, new_data]).sort_index()
            # Remove any duplicates (keep first occurrence)
            combined = combined[~combined.index.duplicated(keep='first')]
            # Overwrite the symbol with combined data
            self.lib.write(symbol, combined)
            logging.info(f"Successfully updated '{symbol}'. New range: {combined.index.min()} to {combined.index.max()}, rows: {len(combined)}")
        else:
            logging.info(f"No new data to add to '{symbol}' (all indices already exist)")

    def save_scheduled_flow(self, df: pd.DataFrame):
        """Save scheduled flow data with validation"""
        logging.info("Validating scheduled flow data...")
        # Validate dataframe
        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        
        # Check that columns are border pairs (lowercase with hyphen)
        for col in df.columns:
            assert '-' in col, f"Column {col} must be in format 'xx-yy' (e.g., 'at-de')"
            assert col == col.lower(), f"Column {col} must be lowercase"
        
        # Ensure all columns are float64 for consistent types
        df = df.astype('float64')
        
        logging.info("Validation passed. Saving scheduled flow...")
        self._save_to_arctic(df, 'scheduled_flow')

    def save_maxbex(self, df: pd.DataFrame):
        """Save maxbex data with validation"""
        logging.info("Validating maxbex data...")
        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        
        # Check that columns are border pairs (lowercase with hyphen)
        for col in df.columns:
            assert '-' in col, f"Column {col} must be in format 'xx-yy' (e.g., 'at-de')"
            assert col == col.lower(), f"Column {col} must be lowercase"
        
        # Ensure all columns are float64 for consistent types
        df = df.astype('float64')
        
        logging.info("Validation passed. Saving maxbex...")
        self._save_to_arctic(df, 'maxbex')

    def save_netpos(self, df: pd.DataFrame):
        """Save net position data with validation"""
        logging.info("Validating net position data...")
        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        
        # Check that columns are country/zone codes (lowercase)
        # Valid formats: 2-letter (at, de, fr), 4-letter (albe, alde)
        valid_zones = ['albe', 'alde']  # 4-letter zones
        for col in df.columns:
            assert col == col.lower(), f"Column {col} must be lowercase"
            # Allow 2-letter country codes or specific 4-letter zones
            assert len(col) == 2 or col in valid_zones, f"Column {col} must be 2-letter country code or valid zone (albe, alde)"
        
        assert 'de' in df.columns, "netpos must contain 'de' column"
        
        # Ensure all columns are float64 for consistent types
        df = df.astype('float64')
        
        logging.info("Validation passed. Saving net positions...")
        self._save_to_arctic(df, 'netpos')

    def save_minmax_netpos(self, df: pd.DataFrame):
        """Save min/max net position data with validation"""
        logging.info("Validating min/max net position data...")
        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        
        # Check that columns are flattened format (zone_type, e.g., 'at_min', 'at_max')
        # All columns should contain '_min' or '_max'
        has_min_cols = any('_min' in str(col) for col in df.columns)
        has_max_cols = any('_max' in str(col) for col in df.columns)
        assert has_min_cols and has_max_cols, "Columns must include both '_min' and '_max' suffixes"
        
        # Ensure all columns are float64 for consistent types
        df = df.astype('float64')
        
        logging.info("Validation passed. Saving min/max net positions...")
        self._save_to_arctic(df, 'minmax_netpos')

    def save_active_constraints(self, df: pd.DataFrame):
        """Save active constraints data with validation"""
        logging.info("Validating active constraints data...")
        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        
        # Check that 'tso' column exists (key column for constraints)
        assert 'tso' in df.columns, "active_constraints must contain 'tso' column"
        
        logging.info("Validation passed. Saving active constraints...")
        self._save_to_arctic(df, 'active_constraints')

    def save_allocation_constraint(self, df: pd.DataFrame):
        """Save allocation constraint data with validation"""
        logging.info("Validating allocation constraint data...")
        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        
        # Check that columns contain _import or _export suffixes
        has_import = any('_import' in str(col) for col in df.columns)
        has_export = any('_export' in str(col) for col in df.columns)
        assert has_import or has_export, "Columns must include '_import' or '_export' suffixes"
        
        # Ensure all columns are float64 for consistent types
        df = df.astype('float64')
        
        logging.info("Validation passed. Saving allocation constraint...")
        self._save_to_arctic(df, 'allocation_constraint')

    def backfill_allocation_constraint(self, df: pd.DataFrame):
        """Backfill historical allocation constraint data with validation"""
        logging.info("Validating allocation constraint data for backfill...")
        assert isinstance(df, pd.DataFrame), "Input must be a pandas DataFrame"
        assert not df.empty, "DataFrame cannot be empty"
        assert isinstance(df.index, pd.DatetimeIndex), "Index must be DatetimeIndex"
        
        # Check that columns contain _import or _export suffixes
        has_import = any('_import' in str(col) for col in df.columns)
        has_export = any('_export' in str(col) for col in df.columns)
        assert has_import or has_export, "Columns must include '_import' or '_export' suffixes"
        
        # Ensure all columns are float64 for consistent types
        df = df.astype('float64')
        
        logging.info("Validation passed. Backfilling allocation constraint...")
        self._backfill_to_arctic(df, 'allocation_constraint')

    def save_all(self, flow_df: pd.DataFrame, maxbex_df: pd.DataFrame, 
                 netpos_df: pd.DataFrame, minmax_netpos_df: pd.DataFrame,
                 alloc_constraint_df: pd.DataFrame):
        """Save all datasets to Arctic DB"""
        logging.info("=" * 60)
        logging.info("Starting save_all operation")
        logging.info("=" * 60)
        
        self.save_scheduled_flow(flow_df)
        self.save_maxbex(maxbex_df)
        self.save_netpos(netpos_df)
        self.save_minmax_netpos(minmax_netpos_df)
        self.save_allocation_constraint(alloc_constraint_df)
        
        logging.info("=" * 60)
        logging.info("All data saved successfully!")
        logging.info("=" * 60)



class ReportGenerator:
    def __init__(self, data_handler):
        self.handler = data_handler
        self.sns_style = "whitegrid"
        sns.set_theme(style=self.sns_style)
        self.data_cache = {}
        self._load_all_data()

    def _normalize_index_tz(self, df: pd.DataFrame) -> pd.DataFrame:
        """Ensure DatetimeIndex is tz-aware (UTC) for consistent comparisons."""
        if isinstance(df.index, pd.DatetimeIndex):
            if df.index.tz is None:
                df.index = df.index.tz_localize('UTC')
            else:
                df.index = df.index.tz_convert('UTC')
        return df

    def _load_all_data(self):
        """Load all data once to improve performance"""
        logging.info("Caching all ArcticDB data for reports...")
        
        symbols = {
            'flow': 'scheduled_flow',
            'maxbex': 'maxbex',
            'netpos': 'netpos',
            'minmax': 'minmax_netpos',
            'alloc_constraint': 'allocation_constraint'
        }
        
        for cache_key, symbol in symbols.items():
            if self.handler.lib.has_symbol(symbol):
                try:
                    self.data_cache[cache_key] = self._normalize_index_tz(self.handler.lib.read(symbol).data)
                except Exception as e:
                    logging.warning(f"Failed to read symbol '{symbol}' from ArcticDB: {e}")
                    self.data_cache[cache_key] = pd.DataFrame()
            else:
                logging.warning(f"Symbol '{symbol}' not found in ArcticDB.")
                self.data_cache[cache_key] = pd.DataFrame()
                
        logging.info("Data caching completed.")

    def _add_header_footer(self, fig, country, content_title, current_page, total_pages):
        """Add standardized header and footer to the figure"""
        # Add black header bar
        header_rect = Rectangle((0, 0.95), 1, 0.05, transform=fig.transFigure, 
                               facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(header_rect)
        
        # Header Text
        fig.text(0.02, 0.975, f'European Flow-Based Market Report: {country.upper()}', 
                fontsize=14, fontweight='bold', va='center', ha='left', color='white', zorder=1002)
        fig.text(0.98, 0.975, content_title,
                fontsize=12, va='center', ha='right', color='white', zorder=1002)
        
        # Add black footer bar
        footer_rect = Rectangle((0, 0), 1, 0.03, transform=fig.transFigure,
                               facecolor='#231F20', edgecolor='none', zorder=1000)
        fig.patches.append(footer_rect)
        
        # Footer Text - Page Number (Replacing Timestamp)
        fig.text(0.98, 0.015, f'Page {current_page} / {total_pages}', 
                fontsize=12, fontweight='bold', va='center', ha='right', color='white', zorder=1002)

    def _calculate_neighbors(self, country, all_borders):
        """Helper to calculate direct neighbors for pagination logic"""
        data_neighbors = set()
        for b in all_borders:
            parts = b.split('-')
            if len(parts) == 2:
                if parts[0] == country: data_neighbors.add(parts[1])
                elif parts[1] == country: data_neighbors.add(parts[0])
        
        if country in CORE_FBMC_NEIGHBOURS:
            valid_neighbors = set(CORE_FBMC_NEIGHBOURS[country])
            return sorted(list(data_neighbors.intersection(valid_neighbors)))
        else:
            return sorted(list(data_neighbors))

    def _precalculate_total_pages(self, countries):
        """Pre-calculate total pages for "Page X / Y" footer"""
        total_pages = 0
        for country in countries:
            data = self._get_country_data(country)
            if data['flow'].empty: continue
            
            # Page 1: YoY Maxbex (3 neighbors per page)
            neighbors = self._calculate_neighbors(country, data['maxbex_cols'])
            n_neighbors = len(neighbors)
            page1_count = (n_neighbors + 2) // 3 if n_neighbors > 0 else 0
            
            # Page 2: History (3 borders per page)
            # Filter to direct borders only
            borders = [b for b in sorted(data['flow_cols']) if country in b.split('-')]
            n_borders = len(borders)
            page2_count = (n_borders + 2) // 3 if n_borders > 0 else 0
            
            # Page 3: NetPos (Always 1 page)
            page3_count = 1
            
            # Page 4: Allocation Constraint (PL only)
            page4_count = 0
            if country == 'pl' and not self.data_cache['alloc_constraint'].empty:
                page4_count = 1
            
            total_pages += page1_count + page2_count + page3_count + page4_count
            
        return total_pages

    def _get_country_data(self, country_code):
        """Extracts data specific to a country from cached datasets"""
        flow = self.data_cache['flow']
        maxbex = self.data_cache['maxbex']
        netpos = self.data_cache['netpos']
        minmax = self.data_cache['minmax']

        # Filter Flow columns (these are canonical 'a-b')
        flow_borders = [c for c in flow.columns if country_code in c.split('-')]
        
        # Filter Maxbex columns (these include both 'a-b' and 'b-a')
        # We want all borders where country_code is one of the parties
        maxbex_borders = [c for c in maxbex.columns if country_code in c.split('-')]
        
        # Net Position data for country
        country_netpos = netpos[[c for c in netpos.columns if c == country_code]] if country_code in netpos.columns else pd.DataFrame()
        
        # Min/Max Net Position for country
        mm_cols = [c for c in minmax.columns if c.startswith(f"{country_code}_")]
        country_minmax = minmax[mm_cols] if mm_cols else pd.DataFrame()

        return {
            'flow': flow[flow_borders],
            'maxbex': maxbex[maxbex_borders],
            'netpos': country_netpos,
            'minmax': country_minmax,
            'flow_cols': flow_borders,
            'maxbex_cols': maxbex_borders
        }

    def create_country_report(self, country_code, pdf, total_pages):
        """Generates report pages for a specific country"""
        logging.info(f"Generating report for {country_code.upper()}...")
        data = self._get_country_data(country_code)
        
        if data['flow'].empty:
            logging.warning(f"No data found for {country_code}, skipping report.")
            return

        # Page 1: YoY Maxbex Grid (Paginated)
        self._create_page_1_yoy_maxbex(country_code, data, pdf, total_pages)
        
        # Page 2: 30-Day History (Corridor View)
        self._create_page_2_history_30d(country_code, data, pdf, total_pages)
        
        # Page 3: Net Position Analysis (Split)
        self._create_page_3_netpos_analysis(country_code, data, pdf, total_pages)
        
        # Page 4: Allocation Constraint (PL only)
        if country_code == 'pl' and not self.data_cache['alloc_constraint'].empty:
            self._create_page_allocation_constraint(country_code, pdf, total_pages)

    def _create_page_1_yoy_maxbex(self, country, data, pdf, total_pages):
        """Page 1: YoY Maxbex plots grid (Paired & Paginated)"""
        # Use helper to calculate neighbors
        neighbors = self._calculate_neighbors(country, data['maxbex_cols'])
        
        # Pagination logic (3 neighbors per page = 3 rows)
        neighbors_per_page = 3
        chunks = [neighbors[i:i + neighbors_per_page] for i in range(0, len(neighbors), neighbors_per_page)]
        
        for page_idx, neighbor_chunk in enumerate(chunks):
            n_rows = len(neighbor_chunk)
            fig = plt.figure(figsize=(16, 11)) # A4-ish ratio landscape
            
            # Grid: 2 columns (Export vs Import), n_rows
            gs = gridspec.GridSpec(n_rows, 2, figure=fig, wspace=0.15, hspace=0.3, 
                                   top=0.85, bottom=0.1, left=0.08, right=0.92)
            
            # Page Titles/Headers
            self._add_header_footer(fig, country, "YoY Maxbex Analysis (Export vs Import)", self.current_page, total_pages)
            self.current_page += 1 # Increment page count
            
            # Column Headers
            fig.text(0.28, 0.88, "EXPORT", fontsize=12, fontweight='bold', ha='center', color='#1f77b4')
            fig.text(0.72, 0.88, "IMPORT", fontsize=12, fontweight='bold', ha='center', color='#d62728')
            
            # Vertical dividing line
            line = plt.Line2D([0.5, 0.5], [0.1, 0.86], transform=fig.transFigure, color='gray', linestyle='-', linewidth=1, alpha=0.5)
            fig.lines.append(line)

            for row_idx, neighbor in enumerate(neighbor_chunk):
                # Left Plot: Export (Country -> Neighbor)
                ax_export = fig.add_subplot(gs[row_idx, 0])
                export_border = f"{country}-{neighbor}"
                
                # Right Plot: Import (Neighbor -> Country)
                ax_import = fig.add_subplot(gs[row_idx, 1])
                import_border = f"{neighbor}-{country}"
                
                # Plot Export
                if export_border in data['maxbex'].columns:
                    self._plot_yoy_line(ax_export, data['maxbex'], export_border, f"{country.upper()} -> {neighbor.upper()}")
                else:
                    ax_export.text(0.5, 0.5, "No Data", ha='center', va='center')

                # Plot Import
                if import_border in data['maxbex'].columns:
                    self._plot_yoy_line(ax_import, data['maxbex'], import_border, f"{neighbor.upper()} -> {country.upper()}")
                else:
                    ax_import.text(0.5, 0.5, "No Data", ha='center', va='center')
            
            pdf.savefig(fig)
            plt.close()

    def _plot_yoy_line(self, ax, df_source, col_name, title):
        """Helper to plot YoY lines on an axis"""
        df = df_source[[col_name]].copy()
        df['year'] = df.index.year
        df['doy'] = df.index.dayofyear
        
        sns.lineplot(data=df, x='doy', y=col_name, hue='year', palette='viridis', ax=ax, linewidth=1.5)
        ax.set_title(title, fontsize=10, fontweight='bold')
        ax.set_xlabel("")
        ax.set_ylabel("MW")
        
        # Format X-axis to %d-%b
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))

        # Legend outside (right side) to avoid covering lines
        ax.legend(
            title=None,
            loc='upper left',
            bbox_to_anchor=(1.02, 1),
            borderaxespad=0,
            fontsize='x-small',
            framealpha=0.8,
        )
        ax.grid(True, alpha=0.3)

    def _create_page_2_history_30d(self, country, data, pdf, total_pages):
        """Page 2: 30 Day History - Flow vs Maxbex (Corridor View)"""
        # We drive this by Flow columns (Canonical pairs)
        # Filter to only borders directly connected to country
        borders = [b for b in sorted(data['flow_cols']) if country in b.split('-')]
        
        # Pagination (3 rows per page)
        rows_per_page = 3
        chunks = [borders[i:i + rows_per_page] for i in range(0, len(borders), rows_per_page)]
        
        last_date = data['flow'].index.max()
        start_date = last_date - pd.Timedelta(days=30)
        
        for page_idx, chunk in enumerate(chunks):
            n_rows = len(chunk)
            fig = plt.figure(figsize=(16, 11))
            
            gs = gridspec.GridSpec(n_rows, 1, figure=fig, hspace=0.4, top=0.85, bottom=0.1, left=0.08, right=0.92)
            
            self._add_header_footer(fig, country, "30-Day History (Corridor View)", self.current_page, total_pages)
            self.current_page += 1 # Increment page count
            
            for idx, border in enumerate(chunk):
                ax = fig.add_subplot(gs[idx])
                
                c1, c2 = border.split('-')
                fwd_col = f"{c1}-{c2}"
                rev_col = f"{c2}-{c1}"
                
                # Determine slice
                flow_30d = data['flow'].loc[start_date:last_date, border]
                
                if fwd_col in data['maxbex'].columns:
                    max_fwd = data['maxbex'].loc[start_date:last_date, fwd_col]
                else:
                    max_fwd = pd.Series(0, index=flow_30d.index)
                    
                if rev_col in data['maxbex'].columns:
                    max_rev = data['maxbex'].loc[start_date:last_date, rev_col] * -1 
                else:
                    max_rev = pd.Series(0, index=flow_30d.index)

                # Plot Corridor
                ax.fill_between(max_fwd.index, max_fwd, color='green', alpha=0.1, label=f'Max {c1}->{c2}')
                ax.plot(max_fwd.index, max_fwd, color='green', linestyle='--', linewidth=1)
                
                ax.fill_between(max_rev.index, max_rev, color='red', alpha=0.1, label=f'Max {c2}->{c1}')
                ax.plot(max_rev.index, max_rev, color='red', linestyle='--', linewidth=1)
                
                # Plot Net Flow
                ax.plot(flow_30d.index, flow_30d, color='blue', linewidth=2, label=f'Net Flow ({c1}-{c2})')
                
                ax.axhline(0, color='black', linewidth=0.5)
                
                ax.set_title(f"Border: {border.upper()}", fontweight='bold')
                ax.set_ylabel("MW (+=Fwd, -=Rev)")
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
                
                ax.legend(loc='upper left', bbox_to_anchor=(1, 1), fontsize='small')
                ax.grid(True, alpha=0.3)
                
            pdf.savefig(fig)
            plt.close()

    def _create_page_3_netpos_analysis(self, country, data, pdf, total_pages):
        """Page 3: Min/Max Net Position Analysis"""
        fig = plt.figure(figsize=(16, 11))
        self._add_header_footer(fig, country, "Net Position Analysis", self.current_page, total_pages)
        self.current_page += 1 # Increment page count
        
        gs = gridspec.GridSpec(2, 2, height_ratios=[1, 1], hspace=0.3, top=0.85, bottom=0.1)

        min_col = f"{country}_min"
        max_col = f"{country}_max"
        
        # --- Top Row: YoY Split (Left=Max, Right=Min) ---
        ax_max = fig.add_subplot(gs[0, 0])
        ax_min = fig.add_subplot(gs[0, 1])
        
        if min_col in data['minmax'].columns and max_col in data['minmax'].columns:
            df = data['minmax'][[min_col, max_col]].rolling(window=7).mean().copy()
            df['year'] = df.index.year
            df['doy'] = df.index.dayofyear
            
            # Plot Max (Export Limit)
            sns.lineplot(data=df, x='doy', y=max_col, hue='year', palette='viridis', ax=ax_max)
            ax_max.set_title("Max Net Position (Export Limit) - 7D Rolling", fontweight='bold')
            ax_max.set_xlabel("")
            ax_max.set_ylabel("MW")
            ax_max.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
            ax_max.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
            ax_max.legend(
                title='Year',
                loc='upper right',
                bbox_to_anchor=(-0.02, 1),
                borderaxespad=0,
                fontsize='small',
            )
            ax_max.grid(True, alpha=0.3)
            
            # Plot Min (Import Limit)
            sns.lineplot(data=df, x='doy', y=min_col, hue='year', palette='viridis', ax=ax_min)
            ax_min.set_title("Min Net Position (Import Limit) - 7D Rolling", fontweight='bold')
            ax_min.set_xlabel("")
            ax_min.set_ylabel("MW")
            ax_min.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
            ax_min.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
            ax_min.legend(
                title='Year',
                loc='upper left',
                bbox_to_anchor=(1.02, 1),
                borderaxespad=0,
                fontsize='small',
            )
            ax_min.grid(True, alpha=0.3)
        
        # --- Bottom Row: Historical Context (Spans both cols) ---
        ax_hist = fig.add_subplot(gs[1, :])
        last_date = data['minmax'].index.max()
        start_date = last_date - pd.Timedelta(days=90)
        
        mm_90d = data['minmax'].loc[start_date:last_date]
        np_90d = data['netpos'].loc[start_date:last_date]
        
        if not mm_90d.empty and not np_90d.empty:
            # Plot Min/Max Band
            ax_hist.fill_between(mm_90d.index, mm_90d[min_col], mm_90d[max_col], color='lightgray', alpha=0.5, label='Min/Max Band')
            ax_hist.plot(mm_90d.index, mm_90d[min_col], 'r--', alpha=0.5)
            ax_hist.plot(mm_90d.index, mm_90d[max_col], 'b--', alpha=0.5)
            
            # Plot Actual Netpos
            if country in np_90d.columns:
                ax_hist.plot(np_90d.index, np_90d[country], color='black', linewidth=2, label='Actual NetPos')
            
            ax_hist.set_title("90-Day Net Export vs Limits", fontweight='bold')
            ax_hist.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
            ax_hist.legend(loc='upper left', bbox_to_anchor=(1, 1), fontsize='small')
            ax_hist.grid(True, alpha=0.3)

        pdf.savefig(fig)
        plt.close()

    def _create_page_allocation_constraint(self, country, pdf, total_pages):
        """Page 4 (PL only): Allocation Constraint Import/Export Analysis - YoY View"""
        fig = plt.figure(figsize=(16, 11))
        self._add_header_footer(fig, country, "Allocation Constraint Analysis", self.current_page, total_pages)
        self.current_page += 1
        
        gs = gridspec.GridSpec(1, 2, figure=fig, wspace=0.25, top=0.85, bottom=0.15, left=0.08, right=0.92)
        
        alloc_df = self.data_cache['alloc_constraint']
        export_col = f"{country}_export"
        import_col = f"{country}_import"
        
        # Left Plot: Export Limit (Max Net Position)
        ax_export = fig.add_subplot(gs[0, 0])
        if export_col in alloc_df.columns:
            df_export = alloc_df[[export_col]].rolling(window=7*24).mean().copy()  # 7D rolling (hourly data)
            df_export['year'] = df_export.index.year
            df_export['doy'] = df_export.index.dayofyear
            
            sns.lineplot(data=df_export, x='doy', y=export_col, hue='year', palette='viridis', ax=ax_export, linewidth=1.5)
            ax_export.set_title("Max Net Position (Export Limit) - 7D Rolling", fontsize=11, fontweight='bold')
            ax_export.set_xlabel("")
            ax_export.set_ylabel("MW")
            
            # Format X-axis to show months
            ax_export.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
            ax_export.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
            
            ax_export.legend(
                title='Year',
                loc='upper right',
                bbox_to_anchor=(-0.02, 1),
                borderaxespad=0,
                fontsize='small',
            )
            ax_export.grid(True, alpha=0.3)
        else:
            ax_export.text(0.5, 0.5, f"No '{export_col}' data available", ha='center', va='center', fontsize=12)
            ax_export.set_title("Max Net Position (Export Limit) - 7D Rolling", fontsize=11, fontweight='bold')
        
        # Right Plot: Import Limit (Min Net Position)
        ax_import = fig.add_subplot(gs[0, 1])
        if import_col in alloc_df.columns:
            df_import = alloc_df[[import_col]].rolling(window=7*24).mean().copy()  # 7D rolling (hourly data)
            df_import['year'] = df_import.index.year
            df_import['doy'] = df_import.index.dayofyear
            
            sns.lineplot(data=df_import, x='doy', y=import_col, hue='year', palette='viridis', ax=ax_import, linewidth=1.5)
            ax_import.set_title("Min Net Position (Import Limit) - 7D Rolling", fontsize=11, fontweight='bold')
            ax_import.set_xlabel("")
            ax_import.set_ylabel("MW")
            
            # Format X-axis to show months
            ax_import.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
            ax_import.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
            
            ax_import.legend(
                title='Year',
                loc='upper left',
                bbox_to_anchor=(1.02, 1),
                borderaxespad=0,
                fontsize='small',
            )
            ax_import.grid(True, alpha=0.3)
        else:
            ax_import.text(0.5, 0.5, f"No '{import_col}' data available", ha='center', va='center', fontsize=12)
            ax_import.set_title("Min Net Position (Import Limit) - 7D Rolling", fontsize=11, fontweight='bold')
        
        pdf.savefig(fig)
        plt.close()

    def generate_full_report(self, filename="FB_Market_Report.pdf"):
        """Main method to generate the full PDF report"""
        logging.info(f"Starting report generation: {filename}")
        
        # Identify all countries from netpos columns
        netpos_cols = self.handler.lib.read('netpos').data.columns
        countries = sorted(list(set(netpos_cols)))
        
        # Pre-calculate total pages
        logging.info("Pre-calculating total pages...")
        total_pages = self._precalculate_total_pages(countries)
        logging.info(f"Total estimated pages: {total_pages}")
        
        self.current_page = 1
        
        with PdfPages(filename) as pdf:
            # REMOVED Title Page as requested
            
            for country in countries:
                try:
                    self.create_country_report(country, pdf, total_pages)
                except Exception as e:
                    logging.error(f"Failed to generate report for {country}: {e}")
                    import traceback
                    traceback.print_exc()
                    continue

        logging.info("Report generation completed successfully!")

if __name__ == "__main__":
    logging.info("=" * 60)
    logging.info("Starting Flow-Based Report Script")
    logging.info("=" * 60)
    
    handler = DataHandler()
    
    # ----------------------------------------------------------------------------------
    # 1. Determine dynamic start/end dates from existing ArcticDB symbols
    # ----------------------------------------------------------------------------------
    symbols_to_check = [
        "scheduled_flow",
        "maxbex",
        "netpos",
        "minmax_netpos",
        "active_constraints",
        "allocation_constraint",
    ]
    max_dates = []
    for symbol in symbols_to_check:
        if handler.lib.has_symbol(symbol):
            try:
                df_symbol = handler.lib.read(symbol).data
                if not df_symbol.empty:
                    max_dates.append(df_symbol.index.max())
            except Exception as e:
                logging.warning(f"Could not read symbol '{symbol}': {e}")
    
    if max_dates:
        # Normalize all timestamps to UTC before comparing (some may be tz-naive)
        max_dates = [d.tz_localize('UTC') if d.tzinfo is None else d.tz_convert('UTC') for d in max_dates]
        # Use the minimum of the per-table maxima so we backfill from the "slowest" table
        start_date = min(max_dates)
        logging.info(f"Computed per-symbol max dates: {max_dates}")
        logging.info(f"Dynamic start_date set to min(max_dates): {start_date}")
    else:
        # No data in ArcticDB yet – fall back to a sensible historical start
        start_date = pd.Timestamp(2022, 6, 9, tz='UTC')
        logging.info("No existing symbols found in ArcticDB, using default start_date 2022-06-09 UTC")
    
    # End date is today (UTC), normalised to midnight
    end_date = pd.Timestamp.now(tz='UTC').normalize()
    logging.info(f"Dynamic end_date set to today (UTC): {end_date}")
    
    # ----------------------------------------------------------------------------------
    # 1b. Check if allocation_constraint needs historical backfill
    # ----------------------------------------------------------------------------------
    alloc_backfill_start = None
    historical_start = pd.Timestamp(2022, 6, 9, tz='UTC')  # FBMC start date
    
    # Calculate expected row count (hourly data from June 2022 to now)
    days_since_start = (end_date - historical_start).days
    expected_rows_minimum = days_since_start * 20  # At least 20 rows per day (conservative estimate)
    
    if handler.lib.has_symbol('allocation_constraint'):
        alloc_df = handler.lib.read('allocation_constraint').data
        if not alloc_df.empty:
            alloc_min = alloc_df.index.min()
            alloc_max = alloc_df.index.max()
            row_count = len(alloc_df)
            
            if alloc_min.tzinfo is not None:
                alloc_min = alloc_min.tz_convert('UTC')
            
            logging.info(f"allocation_constraint: {row_count} rows, range: {alloc_min} to {alloc_max}")
            
            # Check if we're missing significant data (either by min date or by row count)
            if alloc_min > historical_start + pd.Timedelta(days=30):
                alloc_backfill_start = historical_start
                alloc_backfill_end = alloc_min - pd.Timedelta(days=1)
                logging.info(f"allocation_constraint needs backfill (min date): {alloc_backfill_start} to {alloc_backfill_end}")
            elif row_count < expected_rows_minimum:
                # Not enough rows - likely has gaps, do full backfill
                alloc_backfill_start = historical_start
                alloc_backfill_end = end_date
                logging.info(f"allocation_constraint needs gap-fill: only {row_count} rows (expected ~{expected_rows_minimum}+)")
    else:
        # Symbol doesn't exist - need full historical load
        alloc_backfill_start = historical_start
        alloc_backfill_end = end_date
        logging.info(f"allocation_constraint doesn't exist - will backfill from {alloc_backfill_start}")
    
    # Backfill allocation_constraint if needed
    if alloc_backfill_start is not None:
        logging.info("=" * 60)
        logging.info("Backfilling allocation_constraint historical data...")
        logging.info("=" * 60)
        
        chunk_size_backfill = 30
        current = alloc_backfill_start
        chunk_num = 1
        
        while current < alloc_backfill_end:
            chunk_end = min(current + pd.Timedelta(days=chunk_size_backfill), alloc_backfill_end)
            logging.info(f"Backfill chunk {chunk_num}: {current.date()} to {chunk_end.date()}")
            
            try:
                alloc_df = handler.load_allocation_constraint(current, chunk_end)
                handler.backfill_allocation_constraint(alloc_df)
                logging.info(f"Backfill chunk {chunk_num} completed")
            except Exception as e:
                logging.error(f"Error backfilling allocation_constraint: {e}")
            
            current = chunk_end + pd.Timedelta(days=1)
            chunk_num += 1
        
        logging.info("allocation_constraint backfill completed")
        logging.info("=" * 60)
    
    # ----------------------------------------------------------------------------------
    # 2. Scrape & save new data in 30-day chunks between start_date and end_date
    # ----------------------------------------------------------------------------------
    chunk_size = 30  # days
    current_start = start_date
    
    logging.info(f"Total date range to update: {start_date} to {end_date}")
    logging.info(f"Processing in {chunk_size}-day chunks...")
    logging.info("=" * 60)
    
    chunk_num = 1
    while current_start < end_date:
        current_end = min(current_start + pd.Timedelta(days=chunk_size), end_date)
        
        logging.info("\n" + "=" * 60)
        logging.info(f"CHUNK {chunk_num}: {current_start.date()} to {current_end.date()}")
        logging.info("=" * 60)
        
        try:
            latest_flow, latest_maxbex, latest_netpos, latest_minmax_netpos, latest_alloc = handler.load_latest(current_start, current_end)
            handler.save_all(latest_flow, latest_maxbex, latest_netpos, latest_minmax_netpos, latest_alloc)
            logging.info(f"Chunk {chunk_num} completed successfully")
        except Exception as e:
            logging.error(f"Error processing chunk {chunk_num} ({current_start} -> {current_end}): {e}")
            import traceback
            traceback.print_exc()
        
        current_start = current_end + pd.Timedelta(days=1)
        chunk_num += 1
    
    logging.info("=" * 60)
    logging.info("Data scraping completed")
    logging.info("=" * 60)

    # 2. Generate PDF Report
    logging.info("\n" + "=" * 60)
    logging.info("Generating PDF Report")
    logging.info("=" * 60)
    
    try:
        reporter = ReportGenerator(handler)
        today_str = pd.Timestamp.now().strftime("%d-%m-%Y")
        reporter.generate_full_report(f"FBMC Report - JG - {today_str}.pdf")
    except Exception as e:
        logging.error(f"Report generation failed: {e}")
        import traceback
        traceback.print_exc()
    
    logging.info("=" * 60)
    logging.info("Script execution finished")
    logging.info("=" * 60)
    

