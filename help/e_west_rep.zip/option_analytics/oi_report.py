
"""
Email report to visualize ICE Options Open Interest Concentrations and send results

"""


import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.interfaces.snowflake import SnowFlake

from util import get_report


REPORTS_PATH = Path(__file__).parent.resolve()


# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'oi_report.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / "oi_report.log", #filename = log_path / f"{stoday}_oi_report.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'andre.leithaeuser@jainglobal.com'
    error_receivers= 'andre.leithaeuser@jainglobal.com'

conn = SnowFlake(database='ICE', schema='MFT', role='FR_COMMOD_PM_EU')

# Define the instruments dictionary
instruments = {
    "TTF": {"commodity_names": [{"commodity_name": "TFO", "id": 22256}], "bbg_ticker":'TZT1 Comdty', "bbg_ticker_root":'TZT'},
    "EUA": {"commodity_names": [{"commodity_name": "EFO", "id": 22304}], "bbg_ticker":'MODEC1 Comdty', "bbg_ticker_root":'MO'},
    "Brent Crude": {"commodity_names": [{"commodity_name": "B", "id": 254}], "bbg_ticker":'CO1 Comdty', "bbg_ticker_root":'CO'},
#    "WTI": {"commodity_names": [{"commodity_name": "T", "id": 425}], "bbg_ticker":'CL1 Comdty', "bbg_ticker_root":'CL'},
#    "NBP": {"commodity_names": [{"commodity_name": "UKF", "id": 22302}], "bbg_ticker":'FN1 Comdty', "bbg_ticker_root":'FN'},
#    "German Power Base": {"commodity_names": [{"commodity_name": "GAB", "id": 19032}], "eex_ticker":'DEBY'},
    "German Power Base": {"commodity_names": [{"commodity_name": "GAB", "id": 19032}], "bbg_ticker":'DET1 Comdty', "bbg_ticker_root":'DET'},
    "UKA": {"commodity_names": [{"commodity_name": "UKA", "id": 26132}], "bbg_ticker":'UKEDEC1 Comdty', "bbg_ticker_root":'UKE'},
#    "API2": {"commodity_names": [{"commodity_name": "ATD", "id": 19877}], "bbg_ticker":'MFE1 Comdty', "bbg_ticker_root":'MFE'},
#    "NEWC": {"commodity_names": [{"commodity_name": "NWD", "id": 21794}], "bbg_ticker":'XW1 Comdty', "bbg_ticker_root":'XW'},
    "Henry Hub": {"commodity_names": [{"commodity_name": "PHE", "id": 261}], "bbg_ticker":'NG1 Comdty', "bbg_ticker_root":'NG'},
#    "Cocoa": {"commodity_names": [{"commodity_name": "C", "id": 15246}], "bbg_ticker":'CC1 Comdty', "bbg_ticker_root":'CC'},
#    "Coffee": {"commodity_names": [{"commodity_name": "RC", "id": 15247}], "bbg_ticker":'KC1 Comdty', "bbg_ticker_root":'KC'},
#    "Sugar": {"commodity_names": [{"commodity_name":"W","id":15249}], "bbg_ticker":'SB1 Comdty', "bbg_ticker_root":'SB'},
#    "CCA": {"commodity_names":[
#        #{"commodity_name":"CB4","id":25761},
#        {"commodity_name":"CB5","id":26478},
#        {"commodity_name":"CB6","id":27756},
#        #{"commodity_name":"FSI","id":25767},
#    ], "bbg_ticker":'CC(YY)M (MC)(YY) Index', "bbg_ticker_root":'CC'},
#    "RGGI": {"commodity_names": [
#        #{"commodity_name":"RJ4","id":28911},
#        {"commodity_name":"RJ5","id":29815},
#        {"commodity_name":"RJ6","id":30061},
#        #{"commodity_name":"RHB","id":27761},
#    ], "bbg_ticker":'RG(YY)M (MC)(YY) Index', "bbg_ticker_root":'RG'}, 
#    "WCA": {"commodity_names": [{"commodity_name":"WCB","id":28563},
#                                {"commodity_name":"WCC","id":29101},
#                                ], "bbg_ticker":'WKC(MC)(YY)', "bbg_ticker_root":'WKCZ'},
#    "CA LCFS Credit": {"commodity_names": [{"commodity_name":"LFT","id":29140}], "bbg_ticker":'ZRI(MC)(YY)', "bbg_ticker_root":'ZRI'}
}

# Create an empty dictionary to store the results.
results = {}

# Get a cursor from your connection (assumes conn is your connection object).
cur = conn._conn.cursor()

for instrument, info in instruments.items():
    print(instrument)

    all_dfs = []  # collect partial results here

    for entry in info["commodity_names"]:
        commodity = entry["commodity_name"]
        product_id = entry["id"]

        query = f"""
        SELECT *
        FROM ice.mft.options
        WHERE commodity = '{commodity}'
        AND TRADE_DATE >= (CURRENT_DATE - INTERVAL '4 weeks')
        AND product = {product_id}
        AND source NOT LIKE 'UTIL MKT'
        """

        # Execute the query
        cur.execute(query)

        # Fetch results into a DataFrame
        df_part = cur.fetch_pandas_all()
        df_part["commodity_name"] = commodity  # optional: track source commodity
        df_part["product_id"] = product_id

        all_dfs.append(df_part)

    # Concatenate all results for this instrument
    if all_dfs:
        results[instrument] = pd.concat(all_dfs, ignore_index=True)
    else:
        results[instrument] = pd.DataFrame()

for instrument, info in instruments.items():
    try:
        
        logging.info('Generating report')

        # Generate report data  
        input_dict = {instrument: results[instrument]}
        email_body = get_report(input_dict)
        
        email_subject = datetime.today().strftime('%Y-%m-%d') + f' ICE Options Open Interest Report - {instrument}'
        
        # Send email
        send_email(receivers, 
                email_subject, 
                email_body, 
                from_address='eu.gap.reports@jainglobal.com')    
        
        logging.info('Report sent') 
        

    except Exception:
        logging.error('Failed generating report')
        tb = traceback.format_exc()
        logging.error(tb)
        # Send error email
        send_email(error_receivers, f'ERROR {email_subject}', str(tb))        


    
