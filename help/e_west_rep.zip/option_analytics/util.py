import os
import io
import sys
import base64
import warnings
import numpy as np
import pandas as pd
import datetime as dt
import matplotlib.pyplot as plt
from io import BytesIO
from tqdm import tqdm
from datetime import timedelta
from scipy.stats import gaussian_kde

import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Jain Commods Packages
from jain_commods.core.interfaces.bloomberg import BBGQuery
from jain_commods.core.interfaces.snowflake import SnowFlake

# Suppress specific warnings from KDE if needed
warnings.filterwarnings("ignore", category=RuntimeWarning)

tenor_count = 5

# Define the instruments dictionary
instruments = {
    "TTF": {"commodity_names": [{"commodity_name": "TFO", "id": 22256}], "bbg_ticker":'TZT1 Comdty', "bbg_ticker_root":'TZT'},
    "EUA": {"commodity_names": [{"commodity_name": "EFO", "id": 22304}], "bbg_ticker":'MODEC1 Comdty', "bbg_ticker_root":'MO'},
    "Brent Crude": {"commodity_names": [{"commodity_name": "B", "id": 254}], "bbg_ticker":'CO1 Comdty', "bbg_ticker_root":'CO'},
    "WTI": {"commodity_names": [{"commodity_name": "T", "id": 425}], "bbg_ticker":'CL1 Comdty', "bbg_ticker_root":'CL'},
    "NBP": {"commodity_names": [{"commodity_name": "UKF", "id": 22302}], "bbg_ticker":'FN1 Comdty', "bbg_ticker_root":'FN'},
    #"German Power Base": {"commodity_names": [{"commodity_name": "GAB", "id": 19032}], "eex_ticker":'DEBY'},
    "German Power Base": {"commodity_names": [{"commodity_name": "GAB", "id": 19032}], "bbg_ticker":'DET1 Comdty', "bbg_ticker_root":'DET'},
    "UKA": {"commodity_names": [{"commodity_name": "UKA", "id": 26132}], "bbg_ticker":'UKEDEC1 Comdty', "bbg_ticker_root":'UKE'},
    "API2": {"commodity_names": [{"commodity_name": "ATD", "id": 19877}], "bbg_ticker":'MFE1 Comdty', "bbg_ticker_root":'MFE'},
    "NEWC": {"commodity_names": [{"commodity_name": "NWD", "id": 21794}], "bbg_ticker":'XW1 Comdty', "bbg_ticker_root":'XW'},
    "Henry Hub": {"commodity_names": [{"commodity_name": "PHE", "id": 261}], "bbg_ticker":'NG1 Comdty', "bbg_ticker_root":'NG'},
    "Cocoa": {"commodity_names": [{"commodity_name": "C", "id": 15246}], "bbg_ticker":'CC1 Comdty', "bbg_ticker_root":'CC'},
    "Coffee": {"commodity_names": [{"commodity_name": "RC", "id": 15247}], "bbg_ticker":'KC1 Comdty', "bbg_ticker_root":'KC'},
    "Sugar": {"commodity_names": [{"commodity_name":"W","id":15249}], "bbg_ticker":'SB1 Comdty', "bbg_ticker_root":'SB'},
    "CCA": {"commodity_names":[
        #{"commodity_name":"CB4","id":25761},
        {"commodity_name":"CB5","id":26478},
        {"commodity_name":"CB6","id":27756},
        #{"commodity_name":"FSI","id":25767},
    ], "bbg_ticker":'CC(YY)M (MC)(YY) Index', "bbg_ticker_root":'CC'},
    "RGGI": {"commodity_names": [
        #{"commodity_name":"RJ4","id":28911},
        {"commodity_name":"RJ5","id":29815},
        {"commodity_name":"RJ6","id":30061},
        #{"commodity_name":"RHB","id":27761},
    ], "bbg_ticker":'RG(YY)M (MC)(YY) Index', "bbg_ticker_root":'RG'}, 
    "WCA": {"commodity_names": [{"commodity_name":"WCB","id":28563},
                                {"commodity_name":"WCC","id":29101},
                                ], "bbg_ticker":'WKC(MC)(YY)', "bbg_ticker_root":'WKCZ'},
    "CA LCFS Credit": {"commodity_names": [{"commodity_name":"LFT","id":29140}], "bbg_ticker":'ZRI(MC)(YY)', "bbg_ticker_root":'ZRI'}
}

# Define special price format with more decimals for given instruments
special_price_formatting_dict = {"Henry Hub", "TTF"}

##############################################################################
# Helper A: Derive EXPIRY from STRIP if needed
##############################################################################
def parse_strip_to_expiry_code(strip_value):
    mon2code = {
        "Jan": "F", "Feb": "G", "Mar": "H", "Apr": "J", "May": "K", "Jun": "M",
        "Jul": "N", "Aug": "Q", "Sep": "U", "Oct": "V", "Nov": "X", "Dec": "Z"
    }
    if not isinstance(strip_value, str):
        return None
    strip_value = strip_value.strip()
    month_str = strip_value[:3]
    year_str  = strip_value[3:]
    if month_str not in mon2code:
        return None
    letter = mon2code[month_str]
    return f"{letter}{year_str}"

##############################################################################
# Helper B: Convert expiry code (e.g. "H25") to a readable format (e.g. "Mar25")
##############################################################################
def convert_expiry_to_readable(expiry_code):
    """Converts an expiry code (e.g. 'H25') into a readable format (e.g. 'Mar25')."""
    letter_to_month = {
        'F': 'Jan', 'G': 'Feb', 'H': 'Mar', 'J': 'Apr', 'K': 'May', 'M': 'Jun',
        'N': 'Jul', 'Q': 'Aug', 'U': 'Sep', 'V': 'Oct', 'X': 'Nov', 'Z': 'Dec'
    }
    if not expiry_code or len(expiry_code) < 2:
        return expiry_code
    letter = expiry_code[0]
    year = expiry_code[1:]
    month_abbr = letter_to_month.get(letter, expiry_code)
    return f"{month_abbr}{year}"

##############################################################################
# Helper C: Compute Day and Week Changes for the latest trade date.
# If the latest day's total OPEN_INTEREST is zero, use the previous day.
# If force_previous is True, then always use the day before the most recent date.
##############################################################################
def compute_changes_for_latest_date(df, force_previous=False, threshold=0.5, max_lookback_days=180):
    """
    Compute DAY_CHANGE and WEEK_CHANGE in OPEN_INTEREST for the effective latest TRADE_DATE.
    Only rows with TRADE_DATE >= (latest_date - max_lookback_days) are included in the computation.
    
    For each contract (PRODUCT, STRIP, PUT_CALL, STRIKE), this computes:
      - the most recent available OPEN_INTEREST (and corresponding TRADE_DATE)
        prior to (TRADE_DATE - 1 day) and (TRADE_DATE - 7 days).
    Returns a DataFrame filtered to the final effective TRADE_DATE with:
      - DAY_PREV_OI, DAY_PREV_DATE
      - WEEK_PREV_OI, WEEK_PREV_DATE
      - DAY_CHANGE, WEEK_CHANGE
    """
    if 'TRADE_DATE' not in df.columns or 'OPEN_INTEREST' not in df.columns:
        return df.copy()

    df = df.copy()
    df['TRADE_DATE'] = pd.to_datetime(df['TRADE_DATE'])
    sort_cols = ['TRADE_DATE', 'PRODUCT', 'PUT_CALL', 'STRIKE', 'STRIP', 'OPEN_INTEREST']
    df_sorted = df.sort_values(by=sort_cols, ascending=True)
    df_sorted = df_sorted.drop_duplicates(subset=sort_cols)
    
    df_filtered = df_sorted[~(
    (df_sorted['FILE_FLAG'] == 'Early') &
    ((df_sorted['OPEN_INTEREST'] == 0) | (df_sorted['OPEN_INTEREST'].isna()))
    )]

    # --- Step 1: Determine latest and cutoff date for filtering ---
    unique_dates = sorted(df_filtered['TRADE_DATE'].unique())
    if not unique_dates:
        return df_filtered

    latest_date = unique_dates[-1]
    min_date = latest_date - pd.Timedelta(days=max_lookback_days)

    df_recent = df_filtered[df_filtered['TRADE_DATE'] >= min_date].copy()

    # --- Step 2: Compute previous OI using custom logic on recent data only ---
    def compute_prev_oi(g, group_keys):
        g = g.sort_values('TRADE_DATE').copy()

        # Re-insert group keys into the DataFrame
        for col, val in group_keys.items():
            g[col] = val

        dates = pd.to_datetime(g['TRADE_DATE']).values
        day_prev_oi, day_prev_date = [], []
        week_prev_oi, week_prev_date = [], []

        for _, row in g.iterrows():
            current_date = row['TRADE_DATE']
            target_day = np.datetime64(current_date - pd.Timedelta(days=1))
            target_week = np.datetime64(current_date - pd.Timedelta(days=7))

            pos_day = np.searchsorted(dates, target_day, side='right') - 1
            if pos_day >= 0:
                day_prev_oi.append(g.iloc[pos_day]['OPEN_INTEREST'])
                day_prev_date.append(g.iloc[pos_day]['TRADE_DATE'])
            else:
                day_prev_oi.append(np.nan)
                day_prev_date.append(pd.NaT)

            pos_week = np.searchsorted(dates, target_week, side='right') - 1
            if pos_week >= 0:
                week_prev_oi.append(g.iloc[pos_week]['OPEN_INTEREST'])
                week_prev_date.append(g.iloc[pos_week]['TRADE_DATE'])
            else:
                week_prev_oi.append(np.nan)
                week_prev_date.append(pd.NaT)

        g['DAY_PREV_OI'] = day_prev_oi
        g['DAY_PREV_DATE'] = day_prev_date
        g['WEEK_PREV_OI'] = week_prev_oi
        g['WEEK_PREV_DATE'] = week_prev_date
        return g

    group_cols = ['PRODUCT', 'STRIP', 'PUT_CALL', 'STRIKE']

    df_with_prev = (
        df_recent.groupby(group_cols, group_keys=False)
        .apply(lambda g: compute_prev_oi(g, group_keys=dict(zip(group_cols, g.name))), include_groups=False)
        .sort_values(by=sort_cols)
    )
    
    _product = df_with_prev['PRODUCT'].unique()[0]

    # --- Step 3: Compute changes ---
    df_with_prev['DAY_CHANGE'] = df_with_prev['OPEN_INTEREST'] - df_with_prev['DAY_PREV_OI'].fillna(0)
    df_with_prev['WEEK_CHANGE'] = df_with_prev['OPEN_INTEREST'] - df_with_prev['WEEK_PREV_OI'].fillna(0)

    # --- Step 4: Threshold fallback for effective latest date ---
    final_dates = sorted(df_with_prev['TRADE_DATE'].unique())
    latest_date = final_dates[-1]
    if len(final_dates) > 1:
        penultimate_date = final_dates[-2]
        oi_latest = df_with_prev[df_with_prev['TRADE_DATE'] == latest_date]['OPEN_INTEREST'].sum()
        oi_penultimate = df_with_prev[df_with_prev['TRADE_DATE'] == penultimate_date]['OPEN_INTEREST'].sum()
        if oi_latest < threshold * oi_penultimate:
            logging.info(f"Latest date {latest_date.date()} has substantially less OPEN_INTEREST "
                  f"({oi_latest:,}) than penultimate date {penultimate_date.date()} ({oi_penultimate:,}). "
                  f"Using penultimate date.")
            latest_date = penultimate_date

    if force_previous:
        latest_date = latest_date - pd.Timedelta(days=1 if latest_date.weekday() != 0 else 3)
    elif df_with_prev[df_with_prev['TRADE_DATE'] == latest_date]['OPEN_INTEREST'].sum() == 0:
        latest_date = latest_date - pd.Timedelta(days=1)

    # --- Step 5: Filter for final date ---
    current_data = df_with_prev[df_with_prev['TRADE_DATE'] == latest_date].copy()
    
    return current_data.sort_values(by=sort_cols)

##############################################################################
# Helper E: Get top X tenors by total OI.
##############################################################################
def get_top_X_tenors_by_oi(df, product):
    sub = df[df['PRODUCT'] == product]
    if sub.empty:
        return []
    tenor_sums = sub.groupby('EXPIRY')['OPEN_INTEREST'].sum().sort_values(ascending=False)
    return tenor_sums.head(tenor_count).index.tolist()

##############################################################################
# Helper F: Get next 3 December expiries for EUA/UKA.
##############################################################################
def get_next_3_dec_expiries(df, product):
    sub = df[(df['PRODUCT'] == product) & (df['EXPIRY'].str.startswith('Z'))]
    if sub.empty:
        return []
    unique_dec = sub['EXPIRY'].unique().tolist()
    unique_dec_sorted = sorted(unique_dec, key=lambda x: int(x[1:]))
    return unique_dec_sorted[:3]

##############################################################################
# Plotting Function: Combined Plot for OI and OI Changes.
# bar_layout: "stacked" (default) or "side_by_side".
##############################################################################
def plot_combined_oi_and_changes(df, product, expiry, key, bar_layout='side_by_side', fallback_attempted=False):
    
    price_fmt = "{:.3f}" if key in special_price_formatting_dict else "{:.2f}"
    
    def get_bbg_future_ticker(product_key, expiry_code):
        """
        Build a Bloomberg ticker from instruments[…].

        Supported index-style templates in instruments[product_key]['bbg_ticker']:
        1) '<ROOT>(YY)M (MC)(YY) Index'  →  '<ROOT><yy>M <mc><yy> Index'
            e.g. root='CC', expiry='Z25' → 'CC25M Z25 Index'
        2) '<ROOT> (MC)(YY) Index'       →  '<ROOT> <mc><yy> Index'
            e.g. root='ELGBM', expiry='Z25' → 'ELGBM Z25 Index'

        Otherwise, falls back to legacy:
        '<root><month><year_part> Comdty'
        """
        inst = instruments.get(product_key, {}) or {}
        root = inst.get("bbg_ticker_root", "") or ""
        tmpl = (inst.get("bbg_ticker", "") or "").strip()
        if not root or not expiry_code or len(expiry_code) < 2:
            return None

        # Parse expiry like "Z25" / "Z2025"
        mc = str(expiry_code[0]).upper()      # month code letter
        yy = str(expiry_code[1:])             # '25' or '2025'
        if len(yy) == 4:
            yy = yy[-2:]                      # normalize to two digits

        t = tmpl.upper()  # for robust detection of 'Index', '(YY)', '(MC)'

        # ── Index-style #1: '<ROOT>(YY)M (MC)(YY) Index'
        if ("(YY)" in t) and ("(MC)" in t) and ("INDEX" in t) and ("(YY)M" in t):
            left  = f"{root}{yy}M"
            right = f"{mc}{yy} Index"
            return f"{left} {right}"

        # ── Index-style #2: '<ROOT> (MC)(YY) Index'
        if ("(MC)(YY)" in t) and ("INDEX" in t) and ("(YY)M" not in t):
            return f"{root} {mc}{yy} Index"

        # ── Legacy fallback ────────────────────────────────────────────────
        month = mc
        year_part = yy if product_key in ("EUA", "Henry Hub") else yy[-1]
        return f"{root}{month}{year_part} Comdty"

    def fetch_underlying_price_from_ticker(ticker, start_date, end_date):
        try:
            bbg_session = BBGQuery(p_on_server=True)
            df = bbg_session.fetch_hist(ticker, ["PX_LAST"], start_date, end_date)
            df.rename(columns={df.columns[0]: "Price"}, inplace=True)
            return df
        except Exception as e:
            logging.info(f"Failed to fetch price for {ticker}: {e}")
            return None

    future_ticker = get_bbg_future_ticker(key, expiry)
    start_date = pd.to_datetime(dt.datetime.today() - pd.Timedelta(days=1))
    end_date = pd.to_datetime(dt.datetime.today())
    price_df = fetch_underlying_price_from_ticker(future_ticker, start_date, end_date)

    # Skip plotting if price data is not available.
    #if price_df is None or price_df.empty:l
    #    logging.info(f"No underlying price data available for ticker {future_ticker}. Skipping plot.")
    #    return

    latest_price = price_df["Price"].iloc[-1] if price_df is not None and not price_df.empty else None

    sub = df[(df['PRODUCT'] == product) & (df['EXPIRY'] == expiry)].copy()
    duplicates = sub.duplicated(subset=['TRADE_DATE', 'PRODUCT', 'EXPIRY', 'STRIKE', 'PUT_CALL'], keep=False)
    sub = sub.drop_duplicates(subset=['TRADE_DATE', 'PRODUCT', 'EXPIRY', 'STRIKE', 'PUT_CALL'])
    
    print(df['LONG_NAME'].unique()[0], product, expiry, latest_price)
    
    # Compute total positive/negative bars for week-on-week changes
    week_pos_bars = (sub['WEEK_CHANGE'] > 0).sum()
    week_neg_bars = (sub['WEEK_CHANGE'] < 0).sum()
    
    '''
    n_bars = 1
    
    # Skip plot if total bars on either side of week-on-week change are still fewer than n_bars
    if week_pos_bars < n_bars or week_neg_bars < n_bars:

    
    if week_pos_bars==0 and week_neg_bars==0 :
        logging.info(f"Skipping {product} - {expiry}: Insufficient week-on-week data (0 bars on either side).")
        return
    '''
    
    if 'DAY_CHANGE' not in sub.columns:
        sub['DAY_CHANGE'] = 0
    if 'WEEK_CHANGE' not in sub.columns:
        sub['WEEK_CHANGE'] = 0
    
    sub = sub[np.isfinite(sub['STRIKE']) & np.isfinite(sub['OPEN_INTEREST'])]
    sub = sub.sort_values('STRIKE')
    
    calls = sub[sub['PUT_CALL'] == 'C']
    puts  = sub[sub['PUT_CALL'] == 'P']
    
    all_strikes = np.concatenate([calls['STRIKE'].values, puts['STRIKE'].values])
    min_strike, max_strike = np.nanmin(all_strikes), np.nanmax(all_strikes)
    
    import matplotlib.gridspec as gridspec
    # Increase figure size (width x height) to stretch vertically
    fig = plt.figure(figsize=(26, 24))
    gs = gridspec.GridSpec(2, 2, height_ratios=[2, 1.8])
    ax_top  = fig.add_subplot(gs[0, :])
    ax_day  = fig.add_subplot(gs[1, 0])
    ax_week = fig.add_subplot(gs[1, 1])
    
    # Define bar colors to be used consistently for calls and puts
    call_bar_color = 'green'
    put_bar_color  = 'gray'
    
    def plot_kde_and_labels(ax, data, color, label_side, side_multiplier, is_top_panel, avoid_overlap=False):
        """Plots KDE with three or five dashed lines depending on panel type, intelligently filtering labels."""
        try:
            kde = gaussian_kde(data['STRIKE'], weights=np.abs(data.iloc[:, 1]), bw_method=0.5)
            x_grid = np.linspace(data['STRIKE'].min(), data['STRIKE'].max(), 100)
            density = kde(x_grid)
            scale_factor = max(np.abs(data.iloc[:, 1])) / max(density) * 0.8
            ax.plot(density * scale_factor * side_multiplier, x_grid, color=color,
                    label=f"{'Call' if color in ['seagreen','darkgreen','green'] else 'Put'} KDE")

            # Compute peak and ±0.5 std levels
            peak_idx = np.argmax(density)
            peak = x_grid[peak_idx]
            delta = 0.5 * np.std(data['STRIKE'])

            all_levels = [peak - 2*delta, peak - delta, peak, peak + delta, peak + 2*delta] if is_top_panel else [peak]
            filtered_levels = [all_levels[2]]  # Always keep the middle level

            if len(all_levels) > 3:
                if abs(all_levels[1] - all_levels[2]) > 2 and abs(all_levels[3] - all_levels[2]) > 2:
                    filtered_levels.extend([all_levels[1], all_levels[3]])
                elif abs(all_levels[0] - all_levels[2]) > 2 and abs(all_levels[4] - all_levels[2]) > 2:
                    filtered_levels.extend([all_levels[0], all_levels[4]])

            
            for j, lvl in enumerate(filtered_levels):
                lw    = 3 if lvl == peak else 1
                alpha = 0.5 if lvl == peak else 0.3
                ax.axhline(y=lvl, color=color, linestyle='--', linewidth=lw, alpha=alpha)

            
            for j, lvl in enumerate(filtered_levels):
                # compute fraction inside axes (0.05 from left or 0.95 from right)
                x_frac = 0.95 if label_side=='right' else 0.05
                ha     = 'left' if label_side=='right' else 'right'
                fs     = 14 if lvl==peak else 12
                wt     = 'bold' if lvl==peak else 'normal'

                ax.text(
                    x_frac, lvl,
                    f"{lvl:.2f}",
                    transform=ax.get_yaxis_transform(),  # y in data, x in axes fraction
                    ha=ha, va='bottom',                 # always above the line
                    color=color,                        # green or gray
                    fontsize=fs, weight=wt,
                    bbox=dict(facecolor='white', alpha=0.6,
                            edgecolor='none', boxstyle='round,pad=0.2'),
                    clip_on=False                       # never clip it
                )
                
        except Exception as e:
            logging.info(f"KDE failed for {color} data:", e)


    def plot_kde(ax, data, color, side_multiplier, is_top_panel, label, show_values=True, price_side="right", vertical_offset=2.5):
        """Plots KDE while ensuring valid data and preventing errors."""
        if data.shape[0] < 2 or data['STRIKE'].nunique() < 2:
            return  
        try:
            kde = gaussian_kde(data['STRIKE'], weights=np.abs(data.iloc[:, 1]), bw_method=0.5)
            x_grid = np.linspace(data['STRIKE'].min(), data['STRIKE'].max(), 100)
            density = kde(x_grid)
            scale_factor = max(np.abs(data.iloc[:, 1])) / max(density) * 0.8
            ax.plot(density * scale_factor * side_multiplier, x_grid, color=color, label=label)
            peak_idx = np.argmax(density)
            peak = x_grid[peak_idx]
            delta = 0.5 * np.std(data['STRIKE'])
            if is_top_panel:
                levels = [peak - 2*delta, peak - delta, peak, peak + delta, peak + 2*delta]
                alpha_values = [0.3, 0.5, 1.0, 0.5, 0.3]
            else:
                levels = [peak]
                alpha_values = [1.0]
                
           
            for j, lvl in enumerate(levels):
                ax.axhline(y=lvl, color=color, linestyle='--', linewidth=1, alpha=alpha_values[j])

            if show_values:
                for j, lvl in enumerate(levels):
                    x_frac = 0.95 if price_side=='right' else 0.05
                    ha     = 'left' if price_side=='right' else 'right'
                    fs     = 14 if lvl==peak else 12
                    wt     = 'bold' if lvl==peak else 'normal'

                    ax.text(
                        x_frac, lvl,
                        f"{lvl:.2f}",
                        transform=ax.get_yaxis_transform(),
                        ha=ha, va='bottom',
                        color=color,
                        fontsize=fs, weight=wt,
                        bbox=dict(facecolor='white', alpha=0.6,
                                edgecolor='none', boxstyle='round,pad=0.2'),
                        clip_on=False
                    )

        except Exception as e:
            logging.info(f"KDE failed for {label} data:", e)
    
    # ------------------ Top Panel: OI Distribution ------------------
    offset = 0.3
    
    if bar_layout == 'stacked':
        if not calls.empty:
            ax_top.barh(calls['STRIKE'], calls['OPEN_INTEREST'], color=call_bar_color, alpha=0.3, label='Calls OI')
            plot_kde_and_labels(ax_top, calls[['STRIKE', 'OPEN_INTEREST']], call_bar_color, "right", 1, is_top_panel=True)
        if not puts.empty:
            ax_top.barh(puts['STRIKE'], -puts['OPEN_INTEREST'], color=put_bar_color, alpha=0.3, label='Puts OI')
            plot_kde_and_labels(ax_top, puts[['STRIKE', 'OPEN_INTEREST']], put_bar_color, "left", -1, is_top_panel=True)
    
    # ---- Annotate highest calls and highest puts in top panel ----
    def annotate_top_bars_by_abs_value(df, value_col, ax, is_call=True, offset_val=0.3, mirror=False, value_color='black'):
        """
        Annotate the 3 bars with the highest absolute values inside the bars (white text).
        If mirror=True, inverts the value (e.g. for top panel puts).
        """
        df = df.copy()
        df['ABS_VAL'] = np.abs(df[value_col])
        top_bars = df.nlargest(3, 'ABS_VAL')

        for _, row in top_bars.iterrows():
            if not np.isfinite(row[value_col]) or not np.isfinite(row['STRIKE']):
                continue

            bar_val = -row[value_col] if mirror else row[value_col]
            strike = row['STRIKE'] + (-offset_val if is_call else offset_val)
            
            # Place label *inside the bar* near the start
            text_x = bar_val * 0.05  # start 5% from the base of the bar
            ha = 'left' if bar_val > 0 else 'right'

            strike_val = row['STRIKE']
            strike_str = f"{strike_val:.2f}".rstrip('0').rstrip('.')
            ax.text(text_x, strike,
                    f"{strike_str} ({int(row[value_col]):,})",
                    color=value_color, va='center', ha=ha,
                    fontsize=9, fontweight='bold')

    # ---- Annotate top 3 call and put bars (absolute OI) in top panel ----
    # Calls: plotted as-is (positive), so no mirror
    if not calls.empty:
        annotate_top_bars_by_abs_value(calls, 'OPEN_INTEREST', ax_top, is_call=True, offset_val=offset)

    # Puts: plotted negative, so mirror values
    if not puts.empty:
        annotate_top_bars_by_abs_value(puts, 'OPEN_INTEREST', ax_top, is_call=False, offset_val=offset, mirror=True)
        
    # --- Overlay latest underlying price line (top panel) ---
    if latest_price is not None:
        # 1) draw the line once
        ax_top.axhline(y=latest_price, linestyle='--', linewidth=2, alpha=0.5, color='red')

        # 2) pad the x‐axis (so internal fraction positions are safe)
        #x0, x1 = ax_top.get_xlim()
        #pad    = (x1 - x0) * 0.05
        #ax_top.set_xlim(x0 - pad, x1 + pad)
        ax_top.margins(x=0.1)

        # 3) annotate using axes‐fraction for x, data‐coord for y
        ax_top.text(
            0.95,                           # x at 95% of axes width 
            latest_price,                   # y in data coords
            f"Underlying Price: {price_fmt.format(latest_price)}",
            transform=ax_top.get_yaxis_transform(),  # mixed coords
            color='red',
            ha='right',
            va='bottom',                    # always above the line
            fontsize=10,
            weight='bold',
            bbox=dict(facecolor='white', alpha=0.6, edgecolor='none'),
            clip_on=False                   # never clip it away
        )

    # ---------------------------------------------------------------------
    
    ax_top.set_xlabel('Open Interest / KDE Density')
    ax_top.set_ylabel('Strike')
    
    max_date_value = sub['TRADE_DATE'].max()
    if pd.isnull(max_date_value):
        logging.info(f"No valid trade date available for ticker {future_ticker}. Skipping plot.")
        return
    max_date = max_date_value.strftime('%Y-%m-%d')
    
    long_name = sub["LONG_NAME"].iloc[0] if "LONG_NAME" in sub.columns and not sub["LONG_NAME"].isnull().all() else product
    
    # --- Compute Call/Put stats ---
    call_oi = calls['OPEN_INTEREST'].sum()
    put_oi = puts['OPEN_INTEREST'].sum()
    call_put_ratio = call_oi / put_oi if put_oi > 0 else np.nan

    itm_calls = calls[calls['STRIKE'] < latest_price]['OPEN_INTEREST'].sum()
    itm_puts  = puts[puts['STRIKE'] > latest_price]['OPEN_INTEREST'].sum()
    itm_call_pct = 100 * itm_calls / call_oi if call_oi > 0 else np.nan
    itm_put_pct  = 100 * itm_puts  / put_oi if put_oi > 0 else np.nan

    # --- Compute Total OI Volume ---
    total_oi = call_oi + put_oi

    # --- Format in title ---
    title_str = (
        f"{long_name} - {convert_expiry_to_readable(expiry)} Open Interest Distribution (as of {max_date})\n"
        f"Call/Put Ratio: {call_put_ratio:.2f}   |   "
        f"ITM Calls: {itm_call_pct:.1f}%   |   "
        f"ITM Puts: {itm_put_pct:.1f}%   |   "
        f"Call OI Volume: {call_oi:,.0f}   |   "
        f"Put OI Volume: {put_oi:,.0f}   |   "
        f"Total OI Volume: {total_oi:,.0f}"
    )
    ax_top.set_title(title_str)

    ax_top.legend()

    # --- Center the top panel x-axis around 0 with grid lines ---
    x_max_val_top = max(abs(sub['OPEN_INTEREST'].max()), abs(sub['OPEN_INTEREST'].min()))
    interval_val_top = 5000 if x_max_val_top > 20000 else 1000
    x_lim_top = int(np.ceil(x_max_val_top / interval_val_top) * interval_val_top)
    ax_top.set_xlim(-x_lim_top, x_lim_top)
    ax_top.set_xticks(np.arange(-x_lim_top, x_lim_top + interval_val_top, interval_val_top))
    ax_top.xaxis.grid(True, linestyle='--', linewidth=1, alpha=0.3)
    from matplotlib.ticker import AutoLocator, FormatStrFormatter

    ax_top.yaxis.set_major_locator(AutoLocator())
    ax_top.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax_top.yaxis.grid(True, linestyle='--', linewidth=1, alpha=0.3)
    ax_top.tick_params(axis='x', rotation=45, labelsize=8)
    ax_top.tick_params(axis='y', labelsize=8)
    
    # ------------- Bottom Panels: KDE for Change Levels -------------
    # Global toggle for netting calls/puts by strike (and removing duplicates)
    NET_CHANGES = True  # (by default true)
    
    for ax, change_col, title in [
        (ax_day, 'DAY_CHANGE', 'Day-on-Day Open Interest Change'),
        (ax_week, 'WEEK_CHANGE', 'Week-on-Week Open Interest Change')
    ]:
        
        if NET_CHANGES:
            # --- Step 1: Net changes by STRIKE and PUT_CALL (this groups and removes duplicates) ---
            net_df = sub.groupby(['STRIKE', 'PUT_CALL'])[change_col].sum().reset_index()
        else:
            net_df = sub.copy()

        # --- Step 1b: Drop NaN/zero change values ---
        net_df = net_df[np.isfinite(net_df[change_col])]
        net_df = net_df[net_df[change_col] != 0]

        # --- Step 2: Separate net calls/puts ---
        net_calls = net_df[net_df['PUT_CALL'] == 'C'].copy()
        net_puts  = net_df[net_df['PUT_CALL'] == 'P'].copy()
    
        # --- Step 3: Plot net bars ---
        ax.barh(net_calls['STRIKE'] - offset, net_calls[change_col], color=call_bar_color, alpha=0.7, label='Calls', height=0.5)
        ax.barh(net_puts['STRIKE'] + offset, net_puts[change_col], color=put_bar_color, alpha=0.7, label='Puts', height=0.5)
    
        # --- Step 4: Axis + Title ---
        ax.axvline(0, color='black', linestyle='--', linewidth=1)
        ax.set_xlabel(change_col.replace("_", " ").title())
        ax.set_ylabel('Strike')
        ax.set_title(title)
    
        # --- Step 5: KDE lines ---
        kde_combos = [
            (net_calls if NET_CHANGES else calls, 'seagreen', 1, "+Call KDE", "right", True),
            (net_calls if NET_CHANGES else calls, 'darkgreen', -1, "-Call KDE", "left", False),
            (net_puts if NET_CHANGES else puts, 'silver', 1, "+Put KDE", "right", True),
            (net_puts if NET_CHANGES else puts, 'dimgray', -1, "-Put KDE", "left", False)
        ]
    
        for df_temp, color, mult, label, side, pos in kde_combos:
            data = df_temp[df_temp[change_col] > 0] if pos else df_temp[df_temp[change_col] < 0]
            plot_kde(ax, data[['STRIKE', change_col]], color, mult,
                     is_top_panel=False, label=label, price_side=side, vertical_offset=2.5)
    
        # --- Step 6: Annotate extreme values ---
        for df_temp, lbl, is_call in [
            (net_calls, 'Calls', True),
            (net_puts, 'Puts', False)
        ] if NET_CHANGES else [
            (calls, 'Calls', True),
            (puts, 'Puts', False)
        ]:
            annotate_top_bars_by_abs_value(df_temp, change_col, ax, is_call=is_call, offset_val=offset)
            
        ax.legend()
    
        # --- Step 7a: Center x-axis around 0 based on change values (independent scaling) ---
        all_change_vals = pd.concat([net_calls[change_col], net_puts[change_col]]) if NET_CHANGES else pd.concat([calls[change_col], puts[change_col]])
        if not all_change_vals.empty:
            max_val = np.abs(all_change_vals).max()
            interval_val = 5000 if max_val > 20000 else 1000
            x_lim = int(np.ceil(max_val / interval_val) * interval_val)
            ax.set_xlim(-x_lim, x_lim)
            ax.set_xticks(np.arange(-x_lim, x_lim + interval_val, interval_val))

        # --- Step 7b: Compact y-axis scaling based on actual STRIKE values (per subplot) ---
        y_strikes = pd.concat([net_calls['STRIKE'], net_puts['STRIKE']])
        if not y_strikes.empty:
            strike_min = y_strikes.min()
            strike_max = y_strikes.max()
            strike_range = strike_max - strike_min

            # Apply a 2.5% buffer on each side, with a minimum of ±1
            buffer = max(strike_range * 0.025, 1.0)

            y_min = round(strike_min - buffer, 2)
            y_max = round(strike_max + buffer, 2)

            # Round to nearest 1s for tick alignment
            y_min = np.floor(y_min)
            y_max = np.ceil(y_max)

            ax.set_ylim(y_min, y_max)
            ax.set_yticks(np.arange(y_min, y_max + 1, 5))
    
        # --- Step 8: Apply gridlines and styling ---
        ax.xaxis.grid(True, linestyle='--', linewidth=1, alpha=0.3)
        ax.yaxis.set_major_locator(plt.MultipleLocator(5))
        ax.yaxis.grid(True, linestyle='--', linewidth=1, alpha=0.3)
        ax.tick_params(axis='x', rotation=45, labelsize=8)
        ax.tick_params(axis='y', labelsize=8)
    
        # --- Overlay latest underlying price line (bottom panels) ---
        if latest_price is not None:
            # collect the strikes actually plotted in this panel
            strikes = np.concatenate([
                net_calls['STRIKE'].values,
                net_puts['STRIKE'].values
            ])
            if strikes.size and (strikes.min() <= latest_price <= strikes.max()):
                # draw the red line
                ax.axhline(y=latest_price, linestyle='--', linewidth=2, alpha=0.5, color='red')

                # give a little breathing room so the text never hugs the edge
                ax.margins(x=0.1)

                # pin the label at 95% of the width, at the data‐y level, always above it
                ax.text(
                    0.95, latest_price,
                    f"Underlying Price: {price_fmt.format(latest_price)}",
                    transform=ax.get_yaxis_transform(),  # x in axes‐fraction, y in data
                    ha='right', va='bottom',
                    color='red', fontsize=10, weight='bold',
                    bbox=dict(facecolor='white', alpha=0.6, edgecolor='none'),
                    clip_on=False
                )

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.subplots_adjust(left=0.08, right=0.92)
    
    def save_plot_to_base64(fig):
        """Save Matplotlib figure to base64 string."""
        buf = BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        buf.close()
        plt.close(fig)
        return img_str
    
    image = save_plot_to_base64(fig)
    
    return image

##############################################################################
# Main Plot Generator: For each product, find top tenors + December expiries and plot.
##############################################################################
def generate_all_plots(df_all, key, bar_layout='stacked'):
    products = df_all['PRODUCT'].unique()
    images = []
    for product in products:
        top_X = get_top_X_tenors_by_oi(df_all, product)
        '''
        if key in ['EUA', 'UKA']:
            dec_exp = get_next_3_dec_expiries(df_all, product)
            all_tenors = list(set(top_X + dec_exp))
        else:
            all_tenors = top_X
        '''
        all_tenors = top_X
        for expiry in all_tenors:
            image = plot_combined_oi_and_changes(df_all, product, expiry, key, bar_layout=bar_layout)
            # Only append if a valid image was returned
            if image is not None:
                product_long_name = str(df_all[df_all["EXPIRY"] == expiry]['LONG_NAME'].unique()[0])
                images.append({"name": f"{product_long_name}_{str(expiry)}.png", "data": image})
    return images

##############################################################################
# ----------------------------------------------------------------------
# Fetch underlying price data from Snowflake (EEX) or Bloomberg.
# ----------------------------------------------------------------------
def fetch_underlying_price(instrument_key, start_date, end_date):
    ticker_info = instruments.get(instrument_key, {})
    price_df = None
    if "eex_ticker" in ticker_info and ticker_info["eex_ticker"]:
        eex_product_name = ticker_info["eex_ticker"]
        query_eex = f"""
                    SELECT TRADING_DAY,
                        PRODUCT, 
                        SETTLEMENT_PRICE,
                        MATURITY
                    FROM EEX.MARKET_DATA.POWER_DERIVS_FUTURE_PRICES
                    WHERE PRODUCT = '{eex_product_name}'
                    AND TRADING_DAY > '{start_date}'
                    ORDER BY TRADING_DAY DESC
                    """
        conn = SnowFlake(database='ICE', schema='MFT', role='FR_COMMOD_PM_EU')
        cur = conn._conn.cursor()
        cur.execute(query_eex)
        df_eex_data = cur.fetch_pandas_all()
        df_eex_data["TRADING_DAY"] = pd.to_datetime(df_eex_data["TRADING_DAY"])
        df_eex_data["MATURITY_DATE"] = pd.to_datetime(df_eex_data["MATURITY"], format="%Y-%m")
        df_eex_data = df_eex_data.sort_values(["PRODUCT", "MATURITY_DATE", "TRADING_DAY"])
        df_eex_data = df_eex_data.groupby(["PRODUCT", "TRADING_DAY"], group_keys=False).head(1)
        df_eex_data = df_eex_data.set_index("TRADING_DAY")
        df_eex_data = df_eex_data[['SETTLEMENT_PRICE']]
        df_eex_data.rename(columns={"SETTLEMENT_PRICE": "Price"}, inplace=True)
        price_df = df_eex_data
        
    elif "bbg_ticker" in ticker_info and ticker_info["bbg_ticker"]:
        ticker = ticker_info["bbg_ticker"]
        try:
            bbg_session = BBGQuery(p_on_server=True)
            date_range = pd.date_range(start=start_date, end=end_date, freq='D')
            df_bbg = bbg_session.fetch_hist(ticker, ["PX_LAST"], start_date, end_date)
            if not df_bbg.empty:
                df_bbg = df_bbg.reindex(date_range, method='ffill')
                df_bbg.rename(columns={df_bbg.columns[0]: "Price"}, inplace=True)
                price_df = df_bbg[["Price"]]
        except Exception as e:
            logging.info(f"Error fetching Bloomberg data for ticker {ticker}: {e}")
            
    return price_df

##############################################################################
# Main usage: Iterate over the results dictionary and process each DataFrame.
##############################################################################

def get_expiry_date(expiry_code):
    import datetime as dt
    mon2num = {"F": 1, "G": 2, "H": 3, "J": 4, "K": 5, "M": 6,
               "N": 7, "Q": 8, "U": 9, "V": 10, "X": 11, "Z": 12}
    try:
        letter = expiry_code[0]
        year_str = expiry_code[1:]
        year = 2000 + int(year_str)
        month = mon2num[letter]
        return dt.datetime(year, month, 1)
    except Exception:
        return None

def get_report(results):
    from datetime import datetime

    def produce_email_body(body, images=None):
        # Define the email template with structured HTML and inline CSS
        html_body = """<!DOCTYPE html>
        <html>
        <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Daily ICE Options Report</title>
        <style>
            body {font-family: Arial, sans-serif; color: #333; margin: 0; padding: 0; background-color: #f4f4f4;}
            .email-container {width: 100%; max-width: 600px; margin: 0 auto; background-color: #fff; padding: 20px;}
            h1, h2 {color: #333;}
            p {font-size: 14px; line-height: 1.6;}
            .image-container {margin-top: 20px;}
            img {max-width: 100%; height: auto; border: none;}
            hr {border: 1px solid #ddd; margin-top: 20px; margin-bottom: 20px;}
            .footer {font-size: 12px; color: #777; text-align: center; margin-top: 20px;}
        </style>
        </head>
        <body>
        <div class="email-container">
        <h1>Daily ICE Options Report</h1>
        <div>Open Interest Distribution</div>
        """

        if images:
            for i, img in enumerate(images):
                # Clean up the image name: remove '.png' and replace underscores with spaces
                image_name = img["name"].replace('.png', '').replace('_', ' ')
                image_type = 'png'
                image_base_64 = img["data"]  # Base64 encoded image string

                # Wrap each image in a div with heading and horizontal rule
                image_html = (
                    f"<div class='image-container'>"
                    f"<h3>{image_name}</h3>"
                    f"<img src='data:image/{image_type};base64,{image_base_64}' alt='{image_name}' />"
                    f"</div>"
                    f"<hr>"
                )
                html_body += image_html

        # Add note at the bottom with the current date and time
        html_body += f"<div class='footer'><p>Data as of {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} GMT</p></div>"
        html_body += "</div></body></html>"
        return html_body

    email_bodies = []

    # Iterate over datasets in 'results'
    for key, result_df in results.items():
        
        logging.info(f"Processing dataset: {key}")

        # Ensure EXPIRY column exists (e.g., from STRIP)
        if 'EXPIRY' not in result_df.columns and 'STRIP' in result_df.columns:
            result_df['EXPIRY'] = result_df['STRIP'].apply(parse_strip_to_expiry_code)

        # Parse dates
        result_df['EXPIRY_DATE'] = pd.to_datetime(result_df['EXPIRY'].astype(str).apply(get_expiry_date))
        result_df['TRADE_DATE']  = pd.to_datetime(result_df['TRADE_DATE']).dt.tz_localize(None).dt.normalize()

        # Today / recent cutoff
        today   = pd.Timestamp.today().normalize()
        cutoff  = today - pd.Timedelta(days=7)

        # Expiries that still traded in the last 7 days
        recent_expiries = set(result_df.loc[result_df['TRADE_DATE'] >= cutoff, 'EXPIRY'].dropna().unique())

        # Keep unexpired OR recently-traded expiries
        mask = (result_df['EXPIRY_DATE'] >= today) | (result_df['EXPIRY'].isin(recent_expiries))
        result_df = result_df.loc[mask].copy()
        
        # Step 2: Compute changes on the dataset
        if 'TRADE_DATE' in result_df.columns:
            result_df = compute_changes_for_latest_date(result_df)

        # Generate images (each image is a dict with keys "name" and "data")
        images = generate_all_plots(result_df, key, bar_layout='stacked')

        # Build a header with a title
        email_body = f"<h2>{key} ICE Options Open Interest Distribution</h2>"

        # Produce the full HTML email body for this dataset
        body = produce_email_body(body=email_body, images=images)
        email_bodies.append(body)

    # Combine all report bodies into a single email content if needed
    final_report_body = "<br><br>".join(email_bodies)
    return final_report_body



