
"""
Email report to visualize ICE Options Open Interest Concentrations and send results

"""


import logging
import traceback
import configparser
import platform
import pandas as pd

from datetime import datetime
from pathlib import Path

from jain_commods.core.util.emailhelper import send_email
from jain_commods.core.interfaces.snowflake import SnowFlake

from util_us_carbon import get_report


REPORTS_PATH = Path(__file__).parent.resolve()


# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'oi_report_us_carbon.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / "oi_report.log", #filename = log_path / f"{stoday}_oi_report_us_carbon.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging/testing
if system == 'windows':
    receivers = 'andre.leithaeuser@jainglobal.com'
    error_receivers= 'andre.leithaeuser@jainglobal.com'

conn = SnowFlake(database='ICE', schema='MFT', role='FR_COMMOD_PM_EU')

# Define the instruments dictionary
instruments = {
    "CCA": {"option_tickers":[
        #{"commodity_name":"CB4","id":25761},
        #{"commodity_name":"CB5","id":26478},
        {"commodity_name":"CB6","id":27756},
        {"commodity_name":"CB7","id":29813},
        {"commodity_name":"CB8","id":30057},
        {"commodity_name":"CB9","id":30442},
        #{"commodity_name":"FSI","id":25767},
    ], 
        "future_tickers":[
        {"commodity_name":"CB6","id":27756},
        {"commodity_name":"CB7","id":29813},
        {"commodity_name":"CB8","id":30057},
        {"commodity_name":"CB9","id":30442},
    ]},
    "RGGI": {"option_tickers": [
        {"commodity_name":"RJ6","id":30061},
        {"commodity_name":"RJ7","id":31322},
        {"commodity_name":"RJ8","id":31324},
        {"commodity_name":"RJ9","id":31566},
    ], 
        "future_tickers":[
        {"commodity_name":"RJ6","id":30061},
        {"commodity_name":"RJ7","id":31322},
        {"commodity_name":"RJ8","id":31324},
        {"commodity_name":"RJ9","id":31566},
    ]},
    #"WCA": {"option_tickers": [
    #    {"commodity_name":"WCC","id":29101},
    #    {"commodity_name":"WCD","id":29102},
    #    {"commodity_name":"WCE","id":29810},
    #    {"commodity_name":"WCF","id":30059},
    #    {"commodity_name":"WCG","id":31570},
    #], 
    #    "future_tickers":[
    #    {"commodity_name":"WCC","id":29101},
    #    {"commodity_name":"WCD","id":29102},
    #    {"commodity_name":"WCE","id":29810},
    #    {"commodity_name":"WCF","id":30059},
    #    {"commodity_name":"WCG","id":31570},
    #]},
    "CA LCFS Credit":{"option_tickers":[
        {"commodity_name":"LFT","id":29140},
    ], 
        "future_tickers":[
        #{"commodity_name":"CCF","id":30492},
        {"commodity_name":"LFS","id":20500},
    ]},
}

# Derive which COMMODITY codes to use for pricing futures per instrument
instrument_commodity_map: dict[str, dict[str, str]] = {}

for inst_key, cfg in instruments.items():
    opt_names = [t["commodity_name"] for t in cfg.get("option_tickers", [])]
    fut_names = [t["commodity_name"] for t in cfg.get("future_tickers", [])]

    mapping: dict[str, str] = {}

    # First, map by position (2026 CCA first, 2027 CCA second, etc.)
    for opt_name, fut_name in zip(opt_names, fut_names):
        mapping[opt_name] = fut_name

    instrument_commodity_map[inst_key] = mapping

# Create an empty dictionary to store the results.
option_results = {}
futures_results = {}

# Get a cursor from your connection (assumes conn is your connection object).
cur = conn._conn.cursor()

for instrument, info in instruments.items():
    print(f"Fetching {instrument}")
    logging.info("Fetching %s", instrument)

    # ------------------------------
    # OPTIONS
    # ------------------------------
    option_dfs = []
    seen_opt_keys = set()  # avoid duplicated (commodity, id) like WCC

    for entry in info.get("option_tickers", []):
        commodity = entry["commodity_name"]
        product_id = entry["id"]
        key = (commodity, product_id)

        if key in seen_opt_keys:
            # skip exact duplicates in the config (e.g. WCC repeated)
            continue
        seen_opt_keys.add(key)

        query = f"""
            SELECT *
            FROM ice.mft.options
            WHERE commodity = '{commodity}'
              AND TRADE_DATE >= (CURRENT_DATE - INTERVAL '4 weeks')
              AND product = {product_id}
              AND source NOT LIKE 'UTIL MKT'
        """

        try:
            cur.execute(query)
            df_part = cur.fetch_pandas_all()
        except Exception as e:
            logging.warning(
                "Options query failed for %s (commodity=%s, product_id=%s): %s",
                instrument, commodity, product_id, e
            )
            continue

        if df_part is None or df_part.empty:
            logging.info(
                "Options query returned no rows for %s (commodity=%s, product_id=%s)",
                instrument, commodity, product_id
            )
            continue

        df_part["commodity_name"] = commodity
        df_part["product_id"] = product_id
        option_dfs.append(df_part)

    option_results[instrument] = (
        pd.concat(option_dfs, ignore_index=True) if option_dfs else pd.DataFrame()
    )

    # ------------------------------
    # FUTURES
    # ------------------------------
    futures_dfs = []
    seen_fut_keys = set()

    for entry in info.get("future_tickers", []):
        commodity = entry["commodity_name"]
        product_id = entry["id"]
        key = (commodity, product_id)

        if key in seen_fut_keys:
            continue
        seen_fut_keys.add(key)

        query = f"""
            SELECT *
            FROM ice.mft.futures
            WHERE commodity = '{commodity}'
              AND TRADE_DATE >= (CURRENT_DATE - INTERVAL '4 weeks')
              AND product = {product_id}
              AND source NOT LIKE 'UTIL MKT'
        """

        try:
            cur.execute(query)
            df_part = cur.fetch_pandas_all()
        except Exception as e:
            logging.warning(
                "Futures query failed for %s (commodity=%s, product_id=%s): %s",
                instrument, commodity, product_id, e
            )
            continue

        if df_part is None or df_part.empty:
            logging.info(
                "Futures query returned no rows for %s (commodity=%s, product_id=%s)",
                instrument, commodity, product_id
            )
            continue

        df_part["commodity_name"] = commodity
        df_part["product_id"] = product_id
        futures_dfs.append(df_part)

    futures_results[instrument] = (
        pd.concat(futures_dfs, ignore_index=True) if futures_dfs else pd.DataFrame()
    )

for instrument in instruments.keys():
    try:
        logging.info(f'Generating report for {instrument}')

        opts_df = option_results[instrument]
        futs_df = futures_results[instrument]

        # get_report *must* accept both option and futures data
        email_body = get_report(
            option_results={instrument: opts_df},
            futures_results={instrument: futs_df},
            instrument_commodity_map=instrument_commodity_map
        )

        email_subject = (
            datetime.today().strftime('%Y-%m-%d')
            + f' US Carbon ICE Options Open Interest Report - {instrument}'
        )

        send_email(
            receivers,
            email_subject,
            email_body,
            from_address='eu.gap.reports@jainglobal.com'
        )

        logging.info('Report sent')

    except Exception:
        logging.error(f'Failed generating report for {instrument}')
        tb = traceback.format_exc()
        logging.error(tb)
        send_email(error_receivers, f'ERROR {email_subject}', str(tb))
  


    
