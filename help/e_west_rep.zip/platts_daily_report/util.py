"""
Utilities for the Platts daily-report summariser.

Three responsibilities, kept deliberately separate:

1. ``PlattsReportFinder`` — discover and download a named Platts publication
   (e.g. "Metals Daily") from the SPGCI Insights API (``/v1/search/packages``
   + ``/v1/content/{id}``). Returns a downloaded PDF path plus metadata.

2. ``ClaudeReportSummariser`` — send the downloaded PDF straight to Claude as a
   native ``document`` block (no local PDF text extraction — preserves tables
   and figures) and get back a structured markdown summary.

3. ``ReportEmailFormatter`` — render the markdown summary as a styled HTML
   email (Outlook-friendly, table-based layout).

Credentials (SPGCI_USERNAME / SPGCI_PASSWORD / ANTHROPIC_API_KEY) are resolved
by the caller; this module assumes ``spgci.set_credentials(...)`` has been run.
"""

from __future__ import annotations

import base64
import logging
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import anthropic
import markdown
import pandas as pd
import spgci as ci

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 1. Finding & downloading the report
# ---------------------------------------------------------------------------

class ReportNotFoundError(Exception):
    """Raised when no package matching the requested report name is found."""


class PlattsReportFinder:
    """
    Locate and download a named Platts publication from the SPGCI Insights API.

    The Insights ``packages`` endpoint returns downloadable publication bundles
    (id + title + mimeType + updatedDate). We free-text search for the report
    name, keep only PDF-bearing packages whose title/headline actually matches,
    pick the most recent, and download it via ``get_content(id, download=...)``.
    """

    # Columns that may carry the human-readable report title across API versions.
    _TITLE_COLS = ("title", "headline", "publication", "name")
    # Columns that may carry the last-updated timestamp.
    _DATE_COLS = ("updatedDate", "updated_date", "modifiedDate", "date")
    # Columns that may carry the content mime type.
    _MIME_COLS = ("mimeType", "mime_type")
    _PDF_MIME = "application/pdf"

    def __init__(self) -> None:
        self.insights = ci.Insights()

    # -- discovery ----------------------------------------------------------

    def search(
        self,
        report_name: str,
        *,
        days_back: int = 4,
        page_size: int = 100,
    ) -> pd.DataFrame:
        """
        Return packages matching ``report_name`` updated within ``days_back``
        days, newest first. Raises ``ReportNotFoundError`` if none match.
        """
        date_gte = datetime.now() - timedelta(days=days_back)

        logger.info("Searching Platts packages for '%s' (last %d days)", report_name, days_back)
        df = self.insights.get_packages(
            q=report_name,
            updated_date_gte=date_gte,
            page_size=page_size,
            paginate=True,
        )

        if df is None or len(df) == 0:
            raise ReportNotFoundError(
                f"No Platts packages returned for '{report_name}' in the last {days_back} days."
            )

        df = self._filter_and_sort(df, report_name)
        if len(df) == 0:
            raise ReportNotFoundError(
                f"Platts returned packages but none matched title '{report_name}'. "
                f"Try --list to inspect available package titles."
            )
        return df

    def _filter_and_sort(self, df: pd.DataFrame, report_name: str) -> pd.DataFrame:
        """
        Narrow free-text results to the packages that actually represent this
        report, then rank them so the newest downloadable PDF is first.

        The Insights ``packages`` endpoint splits each issue into two rows: a
        titled metadata entry (``title='Metals Daily'``, no mime type, whose
        content endpoint serves a JSON/HTML envelope) and a companion binary
        entry (``mimeType='application/pdf'`` with a blank title, whose content
        endpoint serves the actual PDF). We want the PDF entry, so we keep both
        PDF rows and title-matching rows and sort PDFs first, newest first.
        """
        df = df.copy()

        mime_col = next((c for c in self._MIME_COLS if c in df.columns), None)
        df["_is_pdf"] = (
            df[mime_col].astype(str).str.lower().eq(self._PDF_MIME)
            if mime_col is not None else False
        )

        title_col = next((c for c in self._TITLE_COLS if c in df.columns), None)
        if title_col is not None:
            needle = report_name.lower().strip()
            df["_title_match"] = (
                df[title_col].astype(str).str.lower().str.contains(re.escape(needle), na=False)
            )
        else:
            df["_title_match"] = False

        # Drop unrelated free-text hits (neither a PDF nor a title match), but
        # only if that leaves us with something to work with.
        keep = df["_is_pdf"] | df["_title_match"]
        if keep.any():
            df = df[keep]

        date_col = next((c for c in self._DATE_COLS if c in df.columns), None)
        if date_col is not None:
            df["_sort_dt"] = pd.to_datetime(df[date_col], errors="coerce", utc=True)
        else:
            df["_sort_dt"] = pd.NaT

        # PDFs first, then newest first.
        return df.sort_values(["_is_pdf", "_sort_dt"], ascending=[False, False])

    @classmethod
    def describe(cls, df: pd.DataFrame) -> pd.DataFrame:
        """Compact, human-readable view of candidate packages for logging/--list."""
        cols = []
        for c in ("id", *cls._TITLE_COLS, "mimeType", "mime_type", *cls._DATE_COLS):
            if c in df.columns and c not in cols:
                cols.append(c)
        return df[cols] if cols else df

    # -- download -----------------------------------------------------------

    def download(self, package_row: pd.Series, dest_dir: Path, name_hint: str = "") -> Path:
        """
        Download the report for a package row to ``dest_dir`` and return the path.

        Uses ``Insights.get_content(id, download=...)`` which writes a PDF when
        the content endpoint serves one. Falls back to saving raw bytes / HTML.
        """
        if "id" not in package_row or pd.isna(package_row["id"]):
            raise ReportNotFoundError("Selected package has no 'id' field; cannot download.")

        content_id = str(package_row["id"])
        title = name_hint or self._row_title(package_row)
        safe_title = re.sub(r"[^\w\-]+", "_", title).strip("_") or content_id
        stamp = datetime.now().strftime("%Y%m%d")
        dest = dest_dir / f"{safe_title}_{stamp}.pdf"

        dest_dir.mkdir(parents=True, exist_ok=True)
        logger.info("Downloading content id=%s -> %s", content_id, dest)

        result = self.insights.get_content(id=content_id, download=str(dest))

        # get_content returns the filepath (str) when it wrote a PDF.
        if isinstance(result, str):
            return Path(result)

        # Otherwise it returned a DataFrame/Response of the content envelope.
        # Try to persist any raw PDF/HTML body we can find so the run still
        # produces something summarisable.
        saved = self._save_non_pdf(result, dest)
        if saved is not None:
            return saved

        raise ReportNotFoundError(
            f"Content id={content_id} did not return a downloadable PDF "
            f"(got {type(result).__name__}). It may be HTML-only or not entitled."
        )

    def _save_non_pdf(self, result, dest: Path) -> Optional[Path]:
        # Raw requests.Response with binary body.
        content = getattr(result, "content", None)
        if isinstance(content, (bytes, bytearray)) and content[:4] == b"%PDF":
            dest.write_bytes(content)
            return dest

        # DataFrame envelope with an HTML/text body column.
        if isinstance(result, pd.DataFrame) and len(result) > 0:
            for col in ("body", "content", "html"):
                if col in result.columns:
                    html_path = dest.with_suffix(".html")
                    html_path.write_text(str(result.iloc[0][col]), encoding="utf-8")
                    return html_path
        return None

    @classmethod
    def _row_title(cls, row: pd.Series) -> str:
        for c in cls._TITLE_COLS:
            if c in row and pd.notna(row[c]) and str(row[c]).strip():
                return str(row[c]).strip()
        return "Platts Report"


# ---------------------------------------------------------------------------
# 2. Claude summarisation (native PDF document input)
# ---------------------------------------------------------------------------

DEFAULT_SYSTEM_PROMPT = """
You are a senior commodities market analyst on a trading desk. You are handed a
daily Platts/S&P Global publication (attached as a PDF) and must produce a
sharp, structured internal summary that a portfolio manager can read in two
minutes and trust as a faithful digest of the source.

Follow this template exactly (Markdown):

## {REPORT_TITLE} — {DATE}

### Executive Summary
[3-5 sentences: the single most important theme of today's report and the
overall market direction/tone.]

### Key Price Moves
[Markdown table of the notable assessments/benchmarks mentioned, with level,
day-on-day change (absolute and/or %), and units. Only include figures that
appear in the source — never invent numbers.]

### Market Drivers & Commentary
[6-10 bullet points capturing the substantive fundamental/technical drivers the
report cites: supply, demand, inventories, macro, policy, disruptions,
company/asset news, spread and arb dynamics.]

### Notable Trades / Deals / Tenders
[Bullets for any specific transactions, tenders or fixtures named. If none,
write "None reported in this issue."]

### Regional Detail
[Short sub-sections for each region/product covered with material content.]

### Watch Items
[3-5 forward-looking bullets: what to watch next / catalysts flagged.]

RULES:
- Ground every figure and claim in the attached PDF. Do NOT fabricate prices,
  names, or events. If something is ambiguous, say so.
- Preserve exact benchmark names and price bases as written in the report.
- Be specific and quantitative; write like a market report, not a chatbot.
- Do not include any preamble before the "##" heading.
""".strip()


class ClaudeReportSummariser:
    """Summarise a report PDF with Claude using native document input."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-opus-4-8",
        max_tokens: int = 16000,
        effort: str = "high",
        system_prompt: str = DEFAULT_SYSTEM_PROMPT,
    ) -> None:
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model
        self.max_tokens = max_tokens
        self.effort = effort
        self.system_prompt = system_prompt

    def summarise(self, pdf_path: Path, report_title: str, session_date: str) -> str:
        pdf_path = Path(pdf_path)
        suffix = pdf_path.suffix.lower()

        if suffix == ".pdf":
            document_block = {
                "type": "document",
                "source": {
                    "type": "base64",
                    "media_type": "application/pdf",
                    "data": base64.standard_b64encode(pdf_path.read_bytes()).decode("ascii"),
                },
            }
        else:
            # HTML/text fallback — feed the text directly as a document block.
            text = pdf_path.read_text(encoding="utf-8", errors="ignore")
            text = re.sub(r"<[^>]+>", " ", text)
            document_block = {
                "type": "document",
                "source": {
                    "type": "text",
                    "media_type": "text/plain",
                    "data": text,
                },
            }

        user_msg = (
            f"Report title: {report_title}\n"
            f"Session date: {session_date}\n\n"
            "Summarise the attached daily report following the template in your "
            "instructions. Use only information contained in the document."
        )

        messages = [{
            "role": "user",
            "content": [document_block, {"type": "text", "text": user_msg}],
        }]

        logger.info("Sending %s to Claude (%s) for summarisation", pdf_path.name, self.model)
        with self.client.messages.stream(
            model=self.model,
            max_tokens=self.max_tokens,
            thinking={"type": "adaptive"},
            output_config={"effort": self.effort},
            system=self.system_prompt,
            messages=messages,
        ) as stream:
            response = stream.get_final_message()

        if response.stop_reason == "max_tokens":
            logger.warning(
                "Claude response truncated (max_tokens=%d); consider raising it.",
                self.max_tokens,
            )

        text_parts = [b.text for b in response.content if b.type == "text"]
        return _strip_preamble("\n".join(text_parts).strip())


def _strip_preamble(md_text: str) -> str:
    """Drop any conversational preamble before the first markdown heading."""
    lines = md_text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^\s{0,3}#{1,6}\s", line):
            return "\n".join(lines[i:]).strip()
    return md_text.strip()


# ---------------------------------------------------------------------------
# 3. HTML email formatting
# ---------------------------------------------------------------------------

_EMAIL_CSS = """
body,table,td,p,h1,h2,h3,h4{margin:0;padding:0;border:0;font-family:Arial,Helvetica,sans-serif;}
.email-body h2{color:#0f2044;font-size:18px;font-weight:700;margin:0 0 18px 0;padding-bottom:8px;border-bottom:2px solid #e8a020;}
.email-body h2:first-child{display:none;}
.email-body h3{color:#1a3a6b;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;margin:24px 0 10px 0;padding:6px 0 6px 12px;border-left:3px solid #e8a020;}
.email-body h3:first-child{margin-top:0;}
.email-body h4{color:#0f2044;font-size:13px;font-weight:700;margin:16px 0 8px 0;}
.email-body p{color:#2c2c3e;font-size:14px;line-height:1.7;margin:0 0 12px 0;}
.email-body ul,.email-body ol{padding-left:20px;margin:0 0 12px 0;}
.email-body li{color:#2c2c3e;font-size:14px;line-height:1.7;margin-bottom:4px;}
.email-body table{width:100%;border-collapse:collapse;margin:12px 0 20px 0;font-size:13px;}
.email-body table thead tr{background:#0f2044;color:#fff;}
.email-body table thead th{padding:9px 12px;text-align:left;font-weight:600;font-size:12px;letter-spacing:.5px;white-space:nowrap;color:#fff;}
.email-body table tbody tr{border-bottom:1px solid #e8ecf4;}
.email-body table tbody tr:nth-child(even){background:#f5f7fb;}
.email-body table tbody td{padding:8px 12px;color:#2c2c3e;vertical-align:top;}
.email-body strong{color:#0f2044;font-weight:700;}
""".strip()

_HTML_SHELL = """<!DOCTYPE html>
<html lang="en" xmlns:o="urn:schemas-microsoft-com:office:office">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{page_title}</title><style>{css}</style></head>
<body style="margin:0;padding:0;background-color:#f0f2f5;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f0f2f5;">
<tr><td align="center" style="padding:24px 16px;">
  <table role="presentation" width="900" cellpadding="0" cellspacing="0" border="0" style="max-width:900px;width:100%;background:#fff;border-radius:8px;overflow:hidden;">
    <tr><td style="background:#0f2044;padding:28px 36px;border-bottom:3px solid #e8a020;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
        <td><p style="margin:0 0 4px 0;font-size:20px;font-weight:700;color:#fff;">{banner_title}</p>
            <p style="margin:0;font-size:13px;color:#9bb8e8;">Platts / S&amp;P Global — AI Daily Report Digest</p></td>
        <td align="right" valign="top"><p style="margin:0;font-size:13px;font-weight:600;color:#e8a020;white-space:nowrap;">{datestamp}</p></td>
      </tr></table>
    </td></tr>
    <tr><td class="email-body" style="padding:28px 36px;">{body_html}</td></tr>
    <tr><td style="background:#f5f7fb;padding:16px 36px;border-top:1px solid #e8ecf4;font-size:11px;color:#888;text-align:center;line-height:1.5;">
      AI-generated summary of a Platts/S&amp;P Global publication. May contain errors — refer to the source PDF for detail.
      For internal distribution only.<br>Generated {generated_at}
    </td></tr>
  </table>
</td></tr></table>
</body></html>"""


def _ensure_table_blank_lines(md_text: str) -> str:
    lines = md_text.split("\n")

    def _is_row(line: str) -> bool:
        return line.lstrip().startswith("|")

    def _is_delim(line: str) -> bool:
        s = line.strip()
        return bool(s) and set(s) <= set("|-: ") and "-" in s

    out: list[str] = []
    for i, line in enumerate(lines):
        starts_table = _is_row(line) and i + 1 < len(lines) and _is_delim(lines[i + 1])
        if starts_table and out and out[-1].strip() != "" and not _is_row(out[-1]):
            out.append("")
        out.append(line)
    return "\n".join(out)


def _md_to_html(md_text: str) -> str:
    md_text = _ensure_table_blank_lines(md_text.strip())
    return markdown.markdown(
        md_text,
        extensions=["tables", "fenced_code", "sane_lists"],
        output_format="html",
    )


def _extract_title(html: str) -> tuple[str, str]:
    match = re.search(r"<h2[^>]*>(.*?)</h2>", html, re.IGNORECASE | re.DOTALL)
    if not match:
        return "", html
    title = re.sub(r"<[^>]+>", "", match.group(1)).strip()
    html = (html[:match.start()] + html[match.end():]).strip()
    return title, html


class ReportEmailFormatter:
    """Render a markdown report summary as a styled HTML email."""

    def to_html(self, markdown_text: str, title: str, session_date: str = "") -> str:
        body_html = _md_to_html(markdown_text)
        doc_title, body_html = _extract_title(body_html)
        banner_title = doc_title or title
        datestamp = session_date or datetime.today().strftime("%d %B %Y")
        generated_at = datetime.now().strftime("%d %b %Y %H:%M")

        return _HTML_SHELL.format(
            page_title=banner_title,
            banner_title=banner_title,
            datestamp=datestamp,
            css=_EMAIL_CSS,
            body_html=body_html,
            generated_at=generated_at,
        )
