"""
Platts daily-report summariser.

Downloads a named Platts / S&P Global publication (default: "Metals Daily")
from the SPGCI Insights API, summarises the PDF with Claude, and emails the
digest. Built to generalise to any daily publication via ``--report``.

Data path (see the eu_corelib investigation): the SPGCI Insights API exposes
downloadable publications through ``/v1/search/packages`` (discovery) and
``/v1/content/{id}`` (PDF download) — wrapped here by ``PlattsReportFinder``.
The PDF is handed to Claude as a native document block so tables/figures are
preserved without any local PDF text extraction.

Usage
-----
    # List candidate packages for a report name (no download, good for discovery)
    python platts_daily_report.py --report "Metals Daily" --list

    # Download newest "Metals Daily", summarise, and email
    python platts_daily_report.py --report "Metals Daily"

    # Summarise but do not send email (writes PDF + markdown to ./output)
    python platts_daily_report.py --report "Metals Daily" --dry-run

Credentials (env or a nearby .env):
    SPGCI_USERNAME, SPGCI_PASSWORD, ANTHROPIC_API_KEY
"""

from __future__ import annotations

import argparse
import configparser
import logging
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

import spgci as ci
import spgci.config as spgci_config
from dotenv import load_dotenv
import os

from jain_commods.core.util.emailhelper import send_email

from util import (
    ClaudeReportSummariser,
    PlattsReportFinder,
    ReportEmailFormatter,
    ReportNotFoundError,
)

REPORTS_PATH = Path(__file__).parent.resolve()
OUTPUT_PATH = REPORTS_PATH / "output"
LOG_PATH = REPORTS_PATH / "log"


# ---------------------------------------------------------------------------
# Config / credentials
# ---------------------------------------------------------------------------

def _load_local_dotenv() -> None:
    """Load .env from likely locations without overriding real env vars."""
    for env_path in (
        Path.cwd() / ".env",
        REPORTS_PATH / ".env",
        REPORTS_PATH.parent / ".env",
        REPORTS_PATH.parent.parent / "eu_commods_pipelines" / ".env",
    ):
        if env_path.exists():
            load_dotenv(env_path, override=False)


def _cfg_get(config, section: str, option: str) -> Optional[str]:
    value = config.get(section, option, fallback=None)
    return value.strip() if value and value.strip() else None


def _resolve_spgci_credentials(config) -> Tuple[str, str]:
    _load_local_dotenv()
    user = (os.getenv("SPGCI_USERNAME") or "").strip() or _cfg_get(config, "PlattsApiConfig", "user")
    password = (os.getenv("SPGCI_PASSWORD") or "").strip() or _cfg_get(config, "PlattsApiConfig", "pass")
    if not user or not password:
        raise ValueError(
            "SPGCI credentials not configured. Set SPGCI_USERNAME and SPGCI_PASSWORD "
            "in the environment (or PlattsApiConfig user/pass in the .cfg)."
        )
    return user, password


def _resolve_claude_api_key(config) -> str:
    _load_local_dotenv()
    key = os.getenv("ANTHROPIC_API_KEY") or _cfg_get(config, "ClaudeOptions", "api_key")
    if not key:
        raise ValueError(
            "Claude API key not configured. Set ANTHROPIC_API_KEY in the environment "
            "(or ClaudeOptions api_key in the .cfg)."
        )
    return key


def _read_config() -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    config.read(REPORTS_PATH / "platts_daily_report.cfg")
    return config


def _setup_logging() -> None:
    LOG_PATH.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(LOG_PATH / f"{stamp}_platts_daily_report.log", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


# ---------------------------------------------------------------------------
# Core routine (importable for Dagster / tests)
# ---------------------------------------------------------------------------

def run_daily_report_summary(
    report_name: str = "Metals Daily",
    *,
    days_back: int = 4,
    recipients: Optional[str] = None,
    error_recipients: Optional[str] = None,
    dry_run: bool = False,
    list_only: bool = False,
    config: Optional[configparser.ConfigParser] = None,
) -> dict:
    """
    Download, summarise and (optionally) email the newest issue of a Platts
    daily publication. Returns a metadata dict describing the run.
    """
    config = config or _read_config()
    platts_user, platts_pass = _resolve_spgci_credentials(config)

    # SPGCI's estate periodically has SSL/cert quirks behind the corp proxy;
    # the sibling reports disable verification for the same reason.
    spgci_config.verify_ssl = False
    ci.set_credentials(platts_user, platts_pass)

    finder = PlattsReportFinder()

    # ── 1. Discover ─────────────────────────────────────────────────────────
    candidates = finder.search(report_name, days_back=days_back)
    logging.info("Found %d candidate package(s) for '%s'", len(candidates), report_name)
    logging.info("Candidates:\n%s", finder.describe(candidates).head(10).to_string(index=False))

    if list_only:
        return {
            "status": "listed",
            "report_name": report_name,
            "n_candidates": int(len(candidates)),
            "candidates": finder.describe(candidates).head(20).to_dict("records"),
        }

    # ── 2. Download newest ──────────────────────────────────────────────────
    top = candidates.iloc[0]
    # PDF package rows carry a blank title, so use the requested name for
    # display/filenames and fall back to any title present on the row.
    report_title = report_name or PlattsReportFinder._row_title(top)
    pdf_path = finder.download(top, OUTPUT_PATH, name_hint=report_title)
    logging.info("Downloaded report to %s", pdf_path)

    # ── 3. Summarise with Claude ─────────────────────────────────────────────
    claude_api_key = _resolve_claude_api_key(config)
    summariser = ClaudeReportSummariser(api_key=claude_api_key)
    session_date = datetime.now().strftime("%d %B %Y")
    summary_md = summariser.summarise(pdf_path, report_title=report_title, session_date=session_date)

    md_path = pdf_path.with_suffix(".summary.md")
    md_path.write_text(summary_md, encoding="utf-8")
    logging.info("Wrote summary markdown to %s", md_path)

    # ── 4. Format + email ────────────────────────────────────────────────────
    formatter = ReportEmailFormatter()
    html = formatter.to_html(summary_md, title=f"{report_title} — Summary", session_date=session_date)
    html_path = pdf_path.with_suffix(".summary.html")
    html_path.write_text(html, encoding="utf-8")

    email_sent = False
    subject = f"{report_title} — AI Summary: {datetime.now().strftime('%d %b %Y')}"
    if dry_run:
        logging.info("[DRY RUN] Skipping email. Would send '%s' to %s", subject, recipients)
    elif not recipients:
        logging.warning("No recipients configured; skipping email.")
    else:
        send_email(
            recipients,
            subject,
            html,
            from_address="eu.gap.reports@jainglobal.com",
        )
        email_sent = True
        logging.info("Summary email sent to %s", recipients)

    return {
        "status": "success",
        "report_name": report_name,
        "report_title": report_title,
        "pdf_path": str(pdf_path),
        "summary_md_path": str(md_path),
        "summary_html_path": str(html_path),
        "email_sent": email_sent,
        "recipients": recipients,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Download and summarise a Platts daily report with Claude.")
    p.add_argument("--report", default="Metals Daily", help="Report/publication name to search for.")
    p.add_argument("--days-back", type=int, default=4, help="How many days back to search for the latest issue.")
    p.add_argument("--recipients", default=None, help="Override email recipients (comma-separated).")
    p.add_argument("--dry-run", action="store_true", help="Summarise but do not send email.")
    p.add_argument("--list", dest="list_only", action="store_true",
                   help="List matching packages and exit (no download/summary).")
    return p.parse_args(argv)


def main(argv=None) -> int:
    _setup_logging()
    args = _parse_args(argv)
    config = _read_config()

    recipients = args.recipients or _cfg_get(config, "ReportSettings", "receivers")
    error_recipients = _cfg_get(config, "ReportSettings", "error_receivers")
    days_back = config.getint("ReportSettings", "days_history", fallback=args.days_back)

    try:
        result = run_daily_report_summary(
            report_name=args.report,
            days_back=args.days_back if args.days_back != 4 else days_back,
            recipients=recipients,
            error_recipients=error_recipients,
            dry_run=args.dry_run,
            list_only=args.list_only,
            config=config,
        )
        logging.info("Done: %s", {k: v for k, v in result.items() if k != "candidates"})
        if args.list_only:
            for row in result.get("candidates", []):
                logging.info("  %s", row)
        return 0
    except ReportNotFoundError as e:
        logging.error("Report not found: %s", e)
        return 2
    except Exception:
        tb = traceback.format_exc()
        logging.error("Failed generating Platts daily report summary\n%s", tb)
        if error_recipients and not args.dry_run:
            try:
                send_email(error_recipients, "ERROR Platts Daily Report Summary", str(tb))
            except Exception:
                logging.error("Also failed to send error email.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
