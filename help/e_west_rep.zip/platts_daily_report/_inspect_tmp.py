import os, configparser, warnings
import spgci as ci
import spgci.config as cfg
import pandas as pd
from dotenv import load_dotenv
from pathlib import Path

warnings.filterwarnings("ignore")
for p in [Path('.')/'.env', Path('..')/'.env', Path('..')/'..'/'eu_commods_pipelines'/'.env']:
    if p.exists():
        load_dotenv(p, override=False)

c = configparser.ConfigParser(); c.read('platts_daily_report.cfg')
u = os.getenv('SPGCI_USERNAME') or c.get('PlattsApiConfig', 'user', fallback='')
pw = os.getenv('SPGCI_PASSWORD') or c.get('PlattsApiConfig', 'pass', fallback='')
cfg.verify_ssl = False
ci.set_credentials(u, pw)
ins = ci.Insights()

pkgs = ins.get_packages(q='Metals Daily', page_size=20)
print('PACKAGE COLS:', list(pkgs.columns))
pd.set_option('display.max_colwidth', 200)
print(pkgs.head(2).T.to_string())

cid = pkgs.iloc[0]['id']
print('\n=== get_content(id) ===')
df = ins.get_content(id=cid)
print('type:', type(df))
print('CONTENT COLS:', list(df.columns))
print(df.head(1).T.to_string())

print('\n=== get_content(id, raw=True) headers ===')
resp = ins.get_content(id=cid, raw=True)
print('status', resp.status_code, 'content-type', resp.headers.get('content-type'))
