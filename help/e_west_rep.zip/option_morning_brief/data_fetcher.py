"""
Bloomberg BPIPE data fetcher for the Energy Options Morning Brief.

Uses BBGQuery from jain_commods for BDH (historical futures) and BDP
(vol surface snapshot, per-strike option data).  Implements a local BDS
handler for option-chain queries (OPT_CHAIN) since BBGQuery does not
natively support bulk/sequence fields.

Option chain strategy:
  - TTF & EUA use per-contract options-root tickers (FJSJ6, MZBK6, etc.)
    for OPT_CHAIN queries, returning per-month option chains with full
    per-strike IV, delta, OI, and Greeks.
  - All other instruments query OPT_CHAIN on each futures contract ticker.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta

import blpapi
import numpy as np
import pandas as pd

from jain_commods.core.interfaces.bloomberg import BBGQuery

from . import config as cfg
from .bbg_tickers import ContractSpec, all_contract_tickers

logger = logging.getLogger(__name__)


class BloombergDataFetcher:
    """Orchestrates all Bloomberg data retrieval for the morning brief."""

    def __init__(self, on_server: bool = True):
        self.bbg = BBGQuery(p_on_server=on_server)

    # ------------------------------------------------------------------
    # 1. Futures historical data (BDH)
    # ------------------------------------------------------------------
    def fetch_futures_history(
        self,
        contracts: dict[str, list[ContractSpec]],
        lookback_days: int | None = None,
    ) -> dict[str, pd.DataFrame]:
        """
        BDH: fetch daily PX_LAST, VOLUME, OPEN_INT for every contract.

        Returns {instrument_key: DataFrame} where each DataFrame has a
        DatetimeIndex and columns like ``{ticker}_PX_LAST``, etc.
        """
        lookback = lookback_days or cfg.HIST_LOOKBACK_DAYS
        end_dt = datetime.now()
        start_dt = end_dt - timedelta(days=int(lookback * 1.5))

        results: dict[str, pd.DataFrame] = {}

        for inst_key, specs in contracts.items():
            tickers = [s.ticker for s in specs]
            logger.info("BDH futures for %s: %s", inst_key, tickers)

            try:
                df = self.bbg.fetch_hist(
                    p_ticker=tickers,
                    p_field=cfg.FUTURES_BDH_FIELDS,
                    p_start=start_dt,
                    p_end=end_dt,
                    p_pd_datetime=True,
                )
                if df is not None and not df.empty:
                    results[inst_key] = df
                    logger.info("  %s: %d rows x %d cols", inst_key, len(df), len(df.columns))
                else:
                    logger.warning("  %s: no data returned", inst_key)
                    results[inst_key] = pd.DataFrame()
            except Exception:
                logger.exception("BDH failed for %s", inst_key)
                results[inst_key] = pd.DataFrame()

        return results

    # ------------------------------------------------------------------
    # 2. Vol surface + aggregate options snapshot (BDP)
    # ------------------------------------------------------------------
    def fetch_vol_surface_snapshot(
        self,
        contracts: dict[str, list[ContractSpec]],
    ) -> dict[str, pd.DataFrame]:
        """
        BDP: fetch current vol surface and aggregate options data.

        For instruments with a separate options root (TTF, EUA), queries
        the options-root-based tickers (e.g. FJSK6, MZBZ6) and re-indexes
        the result to the futures ticker so downstream code can join by
        futures ticker transparently.

        Returns {instrument_key: DataFrame} indexed by *futures* ticker.
        """
        results: dict[str, pd.DataFrame] = {}

        for inst_key, specs in contracts.items():
            vol_tickers = [s.vol_surface_ticker for s in specs]
            futures_tickers = [s.ticker for s in specs]
            has_separate_root = vol_tickers != futures_tickers

            logger.info("BDP vol surface for %s: %s", inst_key, vol_tickers)

            try:
                df = self.bbg.fetch_live(
                    tickers=vol_tickers,
                    fields=cfg.VOL_SURFACE_BDP_FIELDS,
                )
                if df is not None and not df.empty:
                    # Re-index from options ticker to futures ticker so
                    # analytics can look up by spec.ticker uniformly
                    if has_separate_root:
                        vol_to_fut = {s.vol_surface_ticker: s.ticker for s in specs}
                        df.index = df.index.map(lambda t: vol_to_fut.get(t, t))

                    results[inst_key] = df
                    logger.info("  %s: %d tickers", inst_key, len(df))
                else:
                    logger.warning("  %s: no snapshot data", inst_key)
                    results[inst_key] = pd.DataFrame()
            except Exception:
                logger.exception("BDP vol surface failed for %s", inst_key)
                results[inst_key] = pd.DataFrame()

        return results

    # ------------------------------------------------------------------
    # 3. Option chain per-strike data (BDS + BDP)
    # ------------------------------------------------------------------
    def fetch_option_chains(
        self,
        contracts: dict[str, list[ContractSpec]],
        max_contracts_per_inst: int = 6,
    ) -> dict[str, pd.DataFrame]:
        """
        For the front N contracts of each instrument, fetch the option
        chain (BDS OPT_CHAIN) and then query per-strike OI / Greeks
        via batched BDP.

        For instruments with a product-level opt_chain_ticker, the chain
        is fetched once and options are matched to contracts by expiry.
        For all others (including TTF/EUA with options_root), OPT_CHAIN
        is queried per contract on the options-root ticker (FJSJ6, MZBK6).

        Returns {instrument_key: DataFrame} with per-strike rows.
        """
        results: dict[str, pd.DataFrame] = {}

        for inst_key, specs in contracts.items():
            inst_cfg = cfg.INSTRUMENTS[inst_key]
            subset = specs[:max_contracts_per_inst]
            all_rows: list[pd.DataFrame] = []

            if inst_cfg.opt_chain_ticker:
                # Product-level query: one OPT_CHAIN call covers all expiries
                all_rows = self._fetch_chain_product_level(
                    inst_key, inst_cfg, subset,
                )
                # Fallback: any contracts not matched by the product-level
                # chain get a per-contract attempt (e.g. EUA Dec27 is beyond
                # what MZBA covers, but MZBZ7 Comdty has its own chain).
                matched_tickers: set[str] = set()
                for df_chunk in all_rows:
                    if "underlying_ticker" in df_chunk.columns:
                        matched_tickers.update(df_chunk["underlying_ticker"].dropna().unique())
                unmatched = [s for s in subset if s.ticker not in matched_tickers]
                if unmatched:
                    logger.info(
                        "  %s: %d contracts unmatched by product chain, trying per-contract...",
                        inst_key, len(unmatched),
                    )
                    fallback_rows = self._fetch_chain_per_contract(inst_key, unmatched)
                    all_rows.extend(fallback_rows)
            else:
                # Per-contract query
                all_rows = self._fetch_chain_per_contract(inst_key, subset)

            if all_rows:
                results[inst_key] = pd.concat(all_rows)
                logger.info("  %s: %d option rows total", inst_key, len(results[inst_key]))
            else:
                results[inst_key] = pd.DataFrame()

        return results

    # ------------------------------------------------------------------
    # 3a. Product-level chain fetch (TTF, EUA)
    # ------------------------------------------------------------------
    def _fetch_chain_product_level(
        self,
        inst_key: str,
        inst_cfg: cfg.InstrumentConfig,
        target_specs: list[ContractSpec],
    ) -> list[pd.DataFrame]:
        """
        Query OPT_CHAIN once on the product-level ticker, then filter
        and tag options to their matching futures contracts.
        """
        opt_ticker = inst_cfg.opt_chain_ticker
        logger.info(
            "Fetching product-level option chain for %s (%s)...",
            inst_key, opt_ticker,
        )

        try:
            chain_tickers = self._fetch_option_chain_tickers(opt_ticker)
        except Exception:
            logger.exception("OPT_CHAIN failed for %s (%s)", inst_key, opt_ticker)
            return []

        if not chain_tickers:
            logger.warning("  No option chain for %s (%s)", inst_key, opt_ticker)
            return []

        logger.info(
            "  %s chain has %d options, querying fields...",
            inst_key, len(chain_tickers),
        )

        # Build month-code lookup to match options to target contracts
        target_month_codes: dict[str, ContractSpec] = {}
        for spec in target_specs:
            mc = cfg.BBG_MONTH_CODES[spec.month]
            yc = str(spec.year % 10)
            key = f"{mc}{yc}"
            target_month_codes[key] = spec

        all_rows: list[pd.DataFrame] = []
        batch_size = 100
        for i in range(0, len(chain_tickers), batch_size):
            batch = chain_tickers[i:i + batch_size]
            df = self._bdp_option_fields(batch)
            if df is None or df.empty:
                continue

            # Try to match each option to a target contract via expiry date
            # or by parsing the option ticker's month/year code
            for idx, row in df.iterrows():
                ticker_str = str(idx)
                matched_spec = self._match_option_to_contract(
                    ticker_str, row, target_specs, target_month_codes,
                    inst_cfg.options_root,
                )
                if matched_spec:
                    df.loc[idx, "underlying_ticker"] = matched_spec.ticker
                    df.loc[idx, "instrument"] = inst_key
                    df.loc[idx, "contract_label"] = matched_spec.label

            # Keep only rows that were matched
            if "underlying_ticker" in df.columns:
                matched = df[df["underlying_ticker"].notna()]
                if not matched.empty:
                    all_rows.append(matched)

        return all_rows

    # ------------------------------------------------------------------
    # 3b. Per-contract chain fetch (most instruments)
    # ------------------------------------------------------------------
    def _fetch_chain_per_contract(
        self,
        inst_key: str,
        target_specs: list[ContractSpec],
    ) -> list[pd.DataFrame]:
        """
        Query OPT_CHAIN on each individual futures contract ticker.
        """
        all_rows: list[pd.DataFrame] = []

        for spec in target_specs:
            opt_ticker = spec.opt_chain_ticker
            logger.info(
                "Fetching option chain for %s (%s via %s)...",
                inst_key, spec.label, opt_ticker,
            )
            try:
                chain_tickers = self._fetch_option_chain_tickers(opt_ticker)
                if not chain_tickers:
                    logger.warning("  No option chain for %s", opt_ticker)
                    continue
                logger.info(
                    "  Chain has %d options, querying fields...",
                    len(chain_tickers),
                )

                batch_size = 100
                for i in range(0, len(chain_tickers), batch_size):
                    batch = chain_tickers[i:i + batch_size]
                    df = self._bdp_option_fields(batch)
                    if df is not None and not df.empty:
                        df["underlying_ticker"] = spec.ticker
                        df["instrument"] = inst_key
                        df["contract_label"] = spec.label
                        all_rows.append(df)
            except Exception:
                logger.exception(
                    "Option chain failed for %s %s", inst_key, spec.ticker,
                )

        return all_rows

    # ------------------------------------------------------------------
    # BDP helper for per-strike option fields
    # ------------------------------------------------------------------
    def _bdp_option_fields(self, tickers: list[str]) -> pd.DataFrame | None:
        try:
            return self.bbg.fetch_live(
                tickers=tickers,
                fields=cfg.OPTION_CHAIN_FIELDS,
            )
        except Exception:
            logger.exception("BDP option fields failed for batch of %d", len(tickers))
            return None

    # ------------------------------------------------------------------
    # Match an option ticker to one of the target contract specs
    # ------------------------------------------------------------------
    @staticmethod
    def _match_option_to_contract(
        option_ticker: str,
        row: pd.Series,
        target_specs: list[ContractSpec],
        target_month_codes: dict[str, ContractSpec],
        options_root: str | None,
    ) -> ContractSpec | None:
        """
        Try to match via OPT_EXPIRE_DT first; fall back to parsing the
        month+year code out of the option ticker string.
        """
        # Strategy 1: match by expiry date month/year
        expire_dt = row.get("OPT_EXPIRE_DT")
        if expire_dt is not None and not (isinstance(expire_dt, float) and np.isnan(expire_dt)):
            try:
                if isinstance(expire_dt, str):
                    dt = datetime.strptime(expire_dt, "%Y-%m-%d")
                else:
                    dt = pd.Timestamp(expire_dt).to_pydatetime()
                for spec in target_specs:
                    if dt.month == spec.month and dt.year == spec.year:
                        return spec
            except (ValueError, TypeError):
                pass

        # Strategy 2: parse month+year code from option ticker
        if options_root:
            # e.g. "FJSF6C 34.00 Comdty" — after removing root "FJS",
            # the next chars are month code + year digit
            root_stripped = option_ticker.replace(" Comdty", "").split()[0]
            if root_stripped.startswith(options_root):
                after_root = root_stripped[len(options_root):]
            else:
                after_root = root_stripped
            if len(after_root) >= 2:
                mc_char = after_root[0]
                yr_char = after_root[1]
                key = f"{mc_char}{yr_char}"
                if key in target_month_codes:
                    return target_month_codes[key]

        return None

    # ------------------------------------------------------------------
    # BDS helper (OPT_CHAIN) — uses blpapi session directly
    # ------------------------------------------------------------------
    def _fetch_option_chain_tickers(self, query_ticker: str) -> list[str]:
        """
        Fetch listed option tickers via the OPT_CHAIN bulk field.

        ``query_ticker`` is either a product-level ticker like
        "FJSA Comdty" or a specific contract like "COZ7 Comdty".
        """
        session = self.bbg.session
        service = session.getService("//blp/refdata")
        request = service.createRequest("ReferenceDataRequest")
        request.getElement("securities").appendValue(query_ticker)
        request.getElement("fields").appendValue("OPT_CHAIN")
        session.sendRequest(request)

        option_tickers: list[str] = []

        while True:
            event = session.nextEvent(5000)
            for msg in event:
                if not msg.hasElement("securityData"):
                    continue
                sec_data_array = msg.getElement("securityData")
                for i in range(sec_data_array.numValues()):
                    sec_data = sec_data_array.getValueAsElement(i)
                    if not sec_data.hasElement("fieldData"):
                        continue
                    field_data = sec_data.getElement("fieldData")
                    if not field_data.hasElement("OPT_CHAIN"):
                        continue
                    chain = field_data.getElement("OPT_CHAIN")
                    for j in range(chain.numValues()):
                        row = chain.getValueAsElement(j)
                        if row.hasElement("Security Description"):
                            ticker = row.getElementAsString("Security Description")
                            option_tickers.append(ticker)
            if event.eventType() == blpapi.Event.RESPONSE:
                break

        return option_tickers


def fetch_all_data(
    on_server: bool = True,
    ref_date: datetime | None = None,
) -> dict:
    """
    Convenience function: fetch all Bloomberg data in one call.

    For ICE instruments, vol_surface and option_chains are skipped
    (use snowflake_options.ICEOptionsDataFetcher instead).

    Returns a dict with keys:
        contracts, futures_hist, vol_surface, option_chains
    """
    contracts = all_contract_tickers(ref_date)
    fetcher = BloombergDataFetcher(on_server=on_server)

    futures_hist = fetcher.fetch_futures_history(contracts)

    non_ice = {
        k: v for k, v in contracts.items()
        if not cfg.INSTRUMENTS[k].has_ice_options
    }
    vol_surface = fetcher.fetch_vol_surface_snapshot(non_ice) if non_ice else {}
    option_chains = fetcher.fetch_option_chains(non_ice) if non_ice else {}

    return {
        "contracts": contracts,
        "futures_hist": futures_hist,
        "vol_surface": vol_surface,
        "option_chains": option_chains,
    }
