"""
Snowflake ICE MFT options data fetcher for the Energy Options Morning Brief.

Primary source for options analytics on ICE-traded instruments (TTF, Brent,
EUA, German Power, French Power, Gasoil).  Adopts the delta-tolerance
methodology from the existing options positioning dashboard.

Data comes from the ``ice.mft.options`` table in Snowflake.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from jain_commods.core.interfaces.snowflake import SnowFlake

from . import config as cfg
from .bbg_tickers import ContractSpec

logger = logging.getLogger(__name__)

# Strip label → Bloomberg month-code mapping (for matching Snowflake strips
# to ContractSpec objects).
_MON_ABBR_TO_BBG = {
    "Jan": "F", "Feb": "G", "Mar": "H", "Apr": "J", "May": "K", "Jun": "M",
    "Jul": "N", "Aug": "Q", "Sep": "U", "Oct": "V", "Nov": "X", "Dec": "Z",
}


# ======================================================================
# Data structures for Snowflake options output
# ======================================================================

@dataclass
class ICEVolMetrics:
    """Vol metrics computed from Snowflake ICE MFT for one strip on one trade date."""
    trade_date: pd.Timestamp | None = None
    strip: str = ""
    atm_vol: float | None = None
    vol_25d_call: float | None = None
    vol_25d_put: float | None = None
    vol_25d_rr: float | None = None
    vol_25d_bf: float | None = None
    vol_10d_call: float | None = None
    vol_10d_put: float | None = None
    vol_10d_rr: float | None = None
    vol_10d_bf: float | None = None
    call_oi: float | None = None
    put_oi: float | None = None
    total_volume: float | None = None


@dataclass
class ICEOptionsResult:
    """Complete options data for one instrument from Snowflake."""
    instrument: str = ""
    raw_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    latest_metrics: dict[str, ICEVolMetrics] = field(default_factory=dict)
    historical_metrics: dict[str, pd.DataFrame] = field(default_factory=dict)
    oi_by_strike: dict[str, pd.DataFrame] = field(default_factory=dict)


# ======================================================================
# Vol computation helpers (delta-tolerance methodology)
# ======================================================================

def find_atm(
    df: pd.DataFrame,
    delta_tol: float = cfg.ICE_DELTA_TOL_ATM,
) -> float | None:
    """Find ATM vol: option closest to |delta| = 0.50 within tolerance."""
    sub = df.dropna(subset=["DELTA_FACTOR", "OPTION_VOLATILITY"])
    if sub.empty:
        return None
    diffs = (sub["DELTA_FACTOR"].abs() - 0.5).abs()
    within = diffs[diffs <= delta_tol]
    if within.empty:
        return None
    return float(sub.loc[within.idxmin(), "OPTION_VOLATILITY"])


def find_vol_at_delta(
    df: pd.DataFrame,
    target_delta: float,
    put_call: str,
    delta_tol: float = cfg.ICE_DELTA_TOL_VOL,
) -> float | None:
    """Find vol for option closest to target delta (signed) within tolerance."""
    sub = df[
        (df["PUT_CALL"] == put_call)
        & df["DELTA_FACTOR"].notna()
        & df["OPTION_VOLATILITY"].notna()
    ]
    if sub.empty:
        return None
    diffs = (sub["DELTA_FACTOR"] - target_delta).abs()
    idx = diffs.idxmin()
    if diffs[idx] > delta_tol:
        return None
    return float(sub.loc[idx, "OPTION_VOLATILITY"])


def compute_vol_metrics(df: pd.DataFrame) -> ICEVolMetrics:
    """Compute all vol metrics for a single strip on a single trade date."""
    metrics = ICEVolMetrics()

    atm = find_atm(df)
    metrics.atm_vol = atm

    v25c = find_vol_at_delta(df, 0.25, "C")
    v25p = find_vol_at_delta(df, -0.25, "P")
    metrics.vol_25d_call = v25c
    metrics.vol_25d_put = v25p
    if v25c is not None and v25p is not None:
        metrics.vol_25d_rr = round(v25c - v25p, 6)
        if atm is not None:
            metrics.vol_25d_bf = round((v25c + v25p) / 2.0 - atm, 6)

    v10c = find_vol_at_delta(df, 0.10, "C")
    v10p = find_vol_at_delta(df, -0.10, "P")
    metrics.vol_10d_call = v10c
    metrics.vol_10d_put = v10p
    if v10c is not None and v10p is not None:
        metrics.vol_10d_rr = round(v10c - v10p, 6)
        if atm is not None:
            metrics.vol_10d_bf = round((v10c + v10p) / 2.0 - atm, 6)

    calls = df[df["PUT_CALL"] == "C"]
    puts = df[df["PUT_CALL"] == "P"]
    if "OPEN_INTEREST" in df.columns:
        metrics.call_oi = float(calls["OPEN_INTEREST"].sum()) if not calls.empty else 0.0
        metrics.put_oi = float(puts["OPEN_INTEREST"].sum()) if not puts.empty else 0.0
    if "TOTAL_VOLUME" in df.columns:
        metrics.total_volume = float(df["TOTAL_VOLUME"].sum())

    return metrics


def parse_strip_label(strip_val: str) -> str | None:
    """Convert Snowflake STRIP like 'Apr26' → 'Apr26' (normalized)."""
    if not isinstance(strip_val, str) or len(strip_val) < 4:
        return None
    mon = strip_val[:3].title()
    yr = strip_val[3:].strip().replace("-", "").replace(" ", "")
    if mon not in _MON_ABBR_TO_BBG or not yr:
        return None
    if len(yr) == 4:
        yr = yr[-2:]
    return f"{mon}{yr}"


def match_strip_to_spec(
    strip_label: str,
    specs: list[ContractSpec],
) -> ContractSpec | None:
    """Match a normalized strip label (e.g. 'May26') to a ContractSpec."""
    for spec in specs:
        if spec.label == strip_label:
            return spec
    return None


# ======================================================================
# ICEOptionsDataFetcher
# ======================================================================

class ICEOptionsDataFetcher:
    """Fetches and processes options data from Snowflake ICE MFT."""

    def __init__(self):
        self.conn = SnowFlake(
            database=cfg.ICE_SNOWFLAKE_DB,
            schema=cfg.ICE_SNOWFLAKE_SCHEMA,
            role=cfg.ICE_SNOWFLAKE_ROLE,
        )

    def fetch_all(
        self,
        contracts: dict[str, list[ContractSpec]],
        lookback_days: int = 30,
    ) -> dict[str, ICEOptionsResult]:
        """Fetch ICE options data for all instruments that have ICE mappings.

        Args:
            contracts: instrument_key → list of ContractSpec
            lookback_days: number of trading days of history

        Returns:
            dict mapping instrument_key → ICEOptionsResult
        """
        results: dict[str, ICEOptionsResult] = {}
        cur = self.conn._conn.cursor()

        for inst_key, specs in contracts.items():
            inst_cfg = cfg.INSTRUMENTS[inst_key]
            if not inst_cfg.has_ice_options:
                continue

            logger.info("Fetching Snowflake ICE options for %s...", inst_key)
            raw_df = self._query_instrument(cur, inst_cfg, lookback_days)

            if raw_df.empty:
                logger.warning("  %s: no Snowflake data returned", inst_key)
                results[inst_key] = ICEOptionsResult(instrument=inst_key)
                continue

            logger.info(
                "  %s: %d rows, %d unique strips, %d trade dates",
                inst_key, len(raw_df),
                raw_df["STRIP"].nunique(),
                raw_df["TRADE_DATE"].nunique(),
            )

            result = self._process_instrument(inst_key, raw_df, specs)
            results[inst_key] = result

        return results

    def _query_instrument(
        self,
        cur,
        inst_cfg: cfg.InstrumentConfig,
        lookback_days: int,
    ) -> pd.DataFrame:
        """Run the Snowflake query for one instrument (may have multiple products).

        Mirrors the positioning dashboard's query with ``delta_factor IS NOT NULL``
        to ensure every row has valid delta/vol data for ATM vol computation.
        """
        dfs: list[pd.DataFrame] = []

        for member in inst_cfg.ice_commodity:
            commodity_name = member["commodity_name"]
            product_id = member["id"]

            query = f"""
                SELECT *
                  FROM {cfg.ICE_OPTIONS_TABLE}
                 WHERE commodity = '{commodity_name}'
                   AND product   = {product_id}
                   AND source NOT LIKE 'UTIL MKT'
                   AND delta_factor IS NOT NULL
                   AND trade_date >= DATEADD(day, -{lookback_days * 2}, CURRENT_DATE())
            """
            try:
                cur.execute(query)
                df = cur.fetch_pandas_all()
                if not df.empty:
                    dfs.append(df)
            except Exception:
                logger.exception(
                    "Snowflake query failed for %s (product=%d)",
                    commodity_name, product_id,
                )

        if not dfs:
            return pd.DataFrame()

        combined = pd.concat(dfs, ignore_index=True)
        combined.columns = [c.upper() for c in combined.columns]

        if "TRADE_DATE" in combined.columns:
            combined["TRADE_DATE"] = pd.to_datetime(combined["TRADE_DATE"])

        # Filter out 'Early' intraday rows that have 0 or NULL OI — these
        # are preliminary records before end-of-day settlement.  Matches the
        # logic in option_analytics/util.py.
        if "FILE_FLAG" in combined.columns and "OPEN_INTEREST" in combined.columns:
            before = len(combined)
            combined = combined[~(
                (combined["FILE_FLAG"] == "Early")
                & ((combined["OPEN_INTEREST"] == 0) | (combined["OPEN_INTEREST"].isna()))
            )].copy()
            dropped = before - len(combined)
            if dropped > 0:
                logger.info("  Filtered %d 'Early' rows with 0 OI", dropped)

        return combined

    def _process_instrument(
        self,
        inst_key: str,
        raw_df: pd.DataFrame,
        specs: list[ContractSpec],
    ) -> ICEOptionsResult:
        """Process raw Snowflake data into structured metrics."""
        result = ICEOptionsResult(instrument=inst_key, raw_df=raw_df)

        raw_df["_strip_label"] = raw_df["STRIP"].apply(parse_strip_label)
        spec_labels = {s.label for s in specs}
        relevant = raw_df[raw_df["_strip_label"].isin(spec_labels)].copy()

        if relevant.empty:
            logger.warning(
                "  %s: no matching strips (available: %s, needed: %s)",
                inst_key,
                sorted(raw_df["_strip_label"].dropna().unique()[:10]),
                sorted(spec_labels),
            )
            return result

        global_latest = relevant["TRADE_DATE"].max()
        logger.info("  %s: global latest trade date = %s", inst_key, global_latest.date())

        for strip_label in sorted(spec_labels):
            strip_data = relevant[relevant["_strip_label"] == strip_label]
            if strip_data.empty:
                continue

            # Use per-strip latest trade date (not global) — some strips
            # may not trade every day, especially illiquid months.
            strip_latest = strip_data["TRADE_DATE"].max()

            # If the latest date has zero total OI and a previous date has
            # real OI, fall back to the previous date (same pattern as
            # option_analytics/util.py threshold fallback).
            latest = strip_data[strip_data["TRADE_DATE"] == strip_latest]
            if "OPEN_INTEREST" in latest.columns:
                total_oi = latest["OPEN_INTEREST"].sum()
                if total_oi == 0:
                    dates_sorted = sorted(strip_data["TRADE_DATE"].unique())
                    for fallback_dt in reversed(dates_sorted[:-1]):
                        candidate = strip_data[strip_data["TRADE_DATE"] == fallback_dt]
                        if candidate["OPEN_INTEREST"].sum() > 0:
                            logger.info(
                                "  %s %s: latest %s has 0 OI, falling back to %s",
                                inst_key, strip_label,
                                strip_latest.date(), fallback_dt.date(),
                            )
                            strip_latest = fallback_dt
                            latest = candidate
                            break

            if not latest.empty:
                vm = compute_vol_metrics(latest)
                vm.trade_date = strip_latest
                vm.strip = strip_label
                result.latest_metrics[strip_label] = vm

            # Historical time series of vol metrics per trade date
            hist_rows: list[dict] = []
            for td, td_group in strip_data.groupby("TRADE_DATE"):
                hm = compute_vol_metrics(td_group)
                hist_rows.append({
                    "trade_date": td,
                    "atm_vol": hm.atm_vol,
                    "vol_25d_rr": hm.vol_25d_rr,
                    "vol_25d_bf": hm.vol_25d_bf,
                    "vol_10d_rr": hm.vol_10d_rr,
                    "vol_10d_bf": hm.vol_10d_bf,
                    "call_oi": hm.call_oi,
                    "put_oi": hm.put_oi,
                })
            if hist_rows:
                hist_df = pd.DataFrame(hist_rows).set_index("trade_date").sort_index()
                n_atm_valid = hist_df["atm_vol"].notna().sum()
                logger.info(
                    "  %s %s: %d trade dates, %d with valid ATM vol",
                    inst_key, strip_label, len(hist_df), n_atm_valid,
                )
                result.historical_metrics[strip_label] = hist_df

            # OI by strike for the latest date
            if not latest.empty and "STRIKE" in latest.columns and "OPEN_INTEREST" in latest.columns:
                oi_data = latest[["STRIKE", "PUT_CALL", "OPEN_INTEREST"]].copy()
                oi_data = oi_data.dropna(subset=["STRIKE", "OPEN_INTEREST"])
                result.oi_by_strike[strip_label] = oi_data

        logger.info(
            "  %s: %d strips with latest metrics, %d with history",
            inst_key,
            len(result.latest_metrics),
            len(result.historical_metrics),
        )

        return result
