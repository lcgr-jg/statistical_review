"""
Debug script #2: Find the correct Bloomberg field names for vol surface data.

The first debug showed that ONLY 30DAY_IMPVOL_100.0%MNY_DF returns data.
All delta-based vols, OI, and volume fields return None.

This script tests:
  1. A broad set of candidate Bloomberg field names for vol/skew/OI
  2. Whether per-contract vol differs from generic vol
  3. Alternative LME ticker formats
  4. Fields available on OPTIONS tickers (e.g. FJSJ6C 50 Comdty)

Run from eu_reports/:
    python -m option_morning_brief.debug_vol_fields
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent / ".env")

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

logging.basicConfig(level=logging.WARNING, format="%(message)s")
log = logging.getLogger(__name__)

SEPARATOR = "=" * 72


def main():
    on_server = os.environ.get("BLOOMBERG_ON_SERVER", "true").lower() == "true"

    from jain_commods.core.interfaces.bloomberg import BBGQuery
    bbg = BBGQuery(p_on_server=on_server)

    # ──────────────────────────────────────────────────────────────
    # 1. EXHAUSTIVE FIELD TEST on a known-good options ticker
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("1. EXHAUSTIVE FIELD TEST — FJSK6 Comdty (TTF May26 options)")
    print("   Testing ~50 candidate vol surface field names")
    print(SEPARATOR)

    candidate_fields = [
        # ATM vol variants
        "30DAY_IMPVOL_100.0%MNY_DF",
        "IVOL_MID",
        "OPT_IMPLIED_VOLATILITY_MID",
        "OPT_IMPLIED_VOLATILITY_ASK",
        "OPT_IMPLIED_VOLATILITY_BID",
        "HIST_VOL_30D",
        "30DAY_IMPVOL_100.0%MNY",
        "IVOL_ATM",

        # Delta-based vol (different naming conventions)
        "IVOL_DELTA_CALL_25",
        "IVOL_DELTA_PUT_25",
        "IVOL_DELTA_CALL_10",
        "IVOL_DELTA_PUT_10",
        "25D_CALL_IMP_VOL",
        "25D_PUT_IMP_VOL",
        "10D_CALL_IMP_VOL",
        "10D_PUT_IMP_VOL",
        "30DAY_IMPVOL_97.5%MNY_DF",
        "30DAY_IMPVOL_95.0%MNY_DF",
        "30DAY_IMPVOL_90.0%MNY_DF",
        "30DAY_IMPVOL_110.0%MNY_DF",
        "30DAY_IMPVOL_105.0%MNY_DF",
        "30DAY_IMPVOL_102.5%MNY_DF",
        "IVOL_DELTA_25_CALL",
        "IVOL_DELTA_25_PUT",

        # Skew fields
        "IVOL_RISK_REVERSAL_25",
        "IVOL_BUTTERFLY_25",
        "25D_RISK_REVERSAL",
        "25D_BUTTERFLY",
        "OPT_RISK_REVERSAL_25",
        "RISK_REVERSAL_25_DELTA",
        "BUTTERFLY_25_DELTA",

        # OI and volume
        "CALL_OPEN_INT",
        "PUT_OPEN_INT",
        "CALL_VOLUME",
        "PUT_VOLUME",
        "OPEN_INT",
        "VOLUME",
        "OPT_OPEN_INT",
        "PUT_CALL_OPEN_INTEREST_RATIO",
        "PUT_CALL_VOLUME_RATIO",

        # Other useful
        "PX_LAST",
        "OPT_STRIKE_PX",
        "OPT_EXPIRE_DT",
        "OPT_PUT_CALL",
        "OPT_DELTA",
        "OPT_GAMMA",
        "OPT_VEGA",
        "OPT_THETA",
    ]

    test_ticker = "FJSK6 Comdty"

    # BBG BDP sometimes rejects batches with invalid fields, so test in small groups
    batch_size = 8
    for i in range(0, len(candidate_fields), batch_size):
        batch = candidate_fields[i:i + batch_size]
        try:
            df = bbg.fetch_live(tickers=[test_ticker], fields=batch)
            if df is not None and not df.empty:
                row = df.iloc[0]
                for field in batch:
                    val = row.get(field)
                    is_ok = val is not None and str(val) != "nan" and str(val) != "None"
                    marker = "  OK  " if is_ok else "  --- "
                    print(f"  {marker} {field}: {val}")
            else:
                for field in batch:
                    print(f"    ---  {field}: (batch returned empty)")
        except Exception as e:
            for field in batch:
                print(f"    ERR  {field}: {e}")

    # ──────────────────────────────────────────────────────────────
    # 2. TEST SAME FIELDS ON FUTURES TICKER (COK6 Comdty = Brent May26)
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("2. EXHAUSTIVE FIELD TEST — COK6 Comdty (Brent May26 futures)")
    print(SEPARATOR)

    test_ticker2 = "COK6 Comdty"
    for i in range(0, len(candidate_fields), batch_size):
        batch = candidate_fields[i:i + batch_size]
        try:
            df = bbg.fetch_live(tickers=[test_ticker2], fields=batch)
            if df is not None and not df.empty:
                row = df.iloc[0]
                for field in batch:
                    val = row.get(field)
                    is_ok = val is not None and str(val) != "nan" and str(val) != "None"
                    marker = "  OK  " if is_ok else "  --- "
                    print(f"  {marker} {field}: {val}")
            else:
                for field in batch:
                    print(f"    ---  {field}: (batch returned empty)")
        except Exception as e:
            for field in batch:
                print(f"    ERR  {field}: {e}")

    # ──────────────────────────────────────────────────────────────
    # 3. PER-CONTRACT VOL: Is 30DAY_IMPVOL the same across tenors?
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("3. PER-CONTRACT ATM VOL — checking if values differ by tenor")
    print(SEPARATOR)

    tenor_tests = {
        "TTF (options tickers)": [
            "FJSJ6 Comdty", "FJSK6 Comdty", "FJSM6 Comdty",
            "FJSN6 Comdty", "FJSV6 Comdty", "FJSZ7 Comdty",
        ],
        "Brent (futures tickers)": [
            "COK6 Comdty", "COM6 Comdty", "CON6 Comdty",
            "COV6 Comdty", "COZ7 Comdty",
        ],
        "Gasoil": [
            "QSJ6 Comdty", "QSK6 Comdty", "QSM6 Comdty",
        ],
    }

    for group_name, tickers in tenor_tests.items():
        print(f"\n  {group_name}:")
        try:
            df = bbg.fetch_live(
                tickers=tickers,
                fields=["30DAY_IMPVOL_100.0%MNY_DF", "PX_LAST"],
            )
            if df is not None and not df.empty:
                for idx, row in df.iterrows():
                    iv = row.get("30DAY_IMPVOL_100.0%MNY_DF")
                    px = row.get("PX_LAST")
                    iv_s = f"{iv:.2f}%" if iv is not None and str(iv) != "nan" else "—"
                    px_s = f"{px:.2f}" if px is not None and str(px) != "nan" else "—"
                    print(f"    {str(idx):20s}  IV={iv_s:>10s}  PX={px_s:>10s}")
            else:
                print("    No data")
        except Exception as e:
            print(f"    ERROR: {e}")

    # ──────────────────────────────────────────────────────────────
    # 4. FIELDS ON A SPECIFIC OPTION (not the underlying)
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("4. FIELDS ON SPECIFIC OPTIONS (individual strikes)")
    print(SEPARATOR)

    option_tickers = [
        "FJSK6C 55 Comdty",    # TTF May26 call strike 55
        "FJSK6P 50 Comdty",    # TTF May26 put strike 50
        "COK6C 100 Comdty",    # Brent May26 call strike 100
        "MZBK6C 70 Comdty",   # EUA May26 call strike 70
        "QSK6C 1100 Comdty",  # Gasoil May26 call strike 1100
    ]

    option_fields = [
        "OPT_IMPLIED_VOLATILITY_MID",
        "OPT_DELTA", "OPT_GAMMA", "OPT_VEGA", "OPT_THETA",
        "OPEN_INT", "VOLUME", "OPT_STRIKE_PX", "OPT_PUT_CALL",
        "OPT_EXPIRE_DT", "PX_LAST", "PX_BID", "PX_ASK",
    ]

    for opt_ticker in option_tickers:
        print(f"\n  {opt_ticker}:")
        try:
            df = bbg.fetch_live(tickers=[opt_ticker], fields=option_fields)
            if df is not None and not df.empty:
                row = df.iloc[0]
                for field in option_fields:
                    val = row.get(field)
                    is_ok = val is not None and str(val) != "nan"
                    marker = "OK  " if is_ok else "--- "
                    print(f"    {marker} {field}: {val}")
            else:
                print("    No data returned")
        except Exception as e:
            print(f"    ERROR: {e}")

    # ──────────────────────────────────────────────────────────────
    # 5. LME ALTERNATIVE TICKER FORMATS
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("5. LME ALTERNATIVE TICKER FORMATS")
    print(SEPARATOR)

    lme_tests = [
        # Generic contracts
        ("LCA1 Comdty",  "Copper 3-month generic"),
        ("LCA2 Comdty",  "Copper 2nd generic"),
        ("LCA3 Comdty",  "Copper 3rd generic"),
        ("LAA1 Comdty",  "Aluminium 3-month generic"),
        ("LAA2 Comdty",  "Aluminium 2nd generic"),
        ("LAA3 Comdty",  "Aluminium 3rd generic"),
        # Cash / 3-month
        ("LMCADS03 Comdty", "Copper 3-month LME"),
        ("LMAHDS03 Comdty", "Aluminium 3-month LME"),
        # Try different roots
        ("HG1 Comdty",   "COMEX Copper front"),
        ("HGK6 Comdty",  "COMEX Copper May26"),
        ("AH1 Comdty",   "COMEX Aluminium front"),
    ]

    for ticker, desc in lme_tests:
        try:
            df = bbg.fetch_live(
                tickers=[ticker],
                fields=["PX_LAST", "VOLUME", "OPEN_INT"],
            )
            if df is not None and not df.empty:
                row = df.iloc[0]
                px = row.get("PX_LAST")
                vol = row.get("VOLUME")
                oi = row.get("OPEN_INT")
                px_s = f"{px}" if px is not None and str(px) != "nan" else "—"
                vol_s = f"{vol}" if vol is not None and str(vol) != "nan" else "—"
                oi_s = f"{oi}" if oi is not None and str(oi) != "nan" else "—"
                print(f"  {ticker:22s} {desc:35s} PX={px_s:>10s} VOL={vol_s:>10s} OI={oi_s}")
            else:
                print(f"  {ticker:22s} {desc:35s} NO DATA")
        except Exception as e:
            print(f"  {ticker:22s} {desc:35s} ERROR: {e}")

    # ──────────────────────────────────────────────────────────────
    # 6. MONEYNESS-BASED VOL SURFACE (the field that DOES work)
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("6. MONEYNESS-BASED VOL FIELDS (expanding the working approach)")
    print(SEPARATOR)

    moneyness_fields = [
        "30DAY_IMPVOL_100.0%MNY_DF",  # ATM
        "30DAY_IMPVOL_97.5%MNY_DF",   # ~25D put
        "30DAY_IMPVOL_95.0%MNY_DF",   # ~10D put
        "30DAY_IMPVOL_90.0%MNY_DF",   # deep put
        "30DAY_IMPVOL_102.5%MNY_DF",  # ~25D call
        "30DAY_IMPVOL_105.0%MNY_DF",  # ~10D call
        "30DAY_IMPVOL_110.0%MNY_DF",  # deep call
    ]

    mny_test_tickers = [
        "FJSK6 Comdty",   # TTF May26
        "COK6 Comdty",    # Brent May26
        "MZBK6 Comdty",   # EUA May26
        "QSK6 Comdty",    # Gasoil May26
        "XBK6 Comdty",    # RBOB May26
    ]

    for ticker in mny_test_tickers:
        print(f"\n  {ticker}:")
        try:
            df = bbg.fetch_live(tickers=[ticker], fields=moneyness_fields)
            if df is not None and not df.empty:
                row = df.iloc[0]
                for field in moneyness_fields:
                    val = row.get(field)
                    is_ok = val is not None and str(val) != "nan"
                    marker = "OK  " if is_ok else "--- "
                    print(f"    {marker} {field}: {val}")
            else:
                print("    No data returned")
        except Exception as e:
            print(f"    ERROR: {e}")

    print(f"\n{SEPARATOR}")
    print("DEBUG #2 COMPLETE")
    print(SEPARATOR)


if __name__ == "__main__":
    main()
