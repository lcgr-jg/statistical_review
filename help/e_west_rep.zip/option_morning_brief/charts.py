"""
Chart generation for the Bloomberg-Powered Energy Options Morning Brief.

Produces Plotly figures for:
  - ATM Vol time series (trailing 60d)
  - Vol term structure (ATM vol across tenors)
  - 25D skew (RR) across tenors
  - OI by strike (put vs call, from option chain)
  - Cross-asset ATM vol comparison (normalized)
  - Price time series with vol overlay
"""

from __future__ import annotations

import base64
import logging
import os

import plotly.graph_objs as go
import plotly.io as pio

from .analytics import InstrumentMetrics, ContractMetrics

_KALEIDO_ENABLED = os.environ.get("ENABLE_KALEIDO", "0") == "1"

logger = logging.getLogger(__name__)

CHART_WIDTH = 600
CHART_HEIGHT = 360

LAYOUT_DEFAULTS = dict(
    paper_bgcolor="white",
    plot_bgcolor="white",
    font=dict(family="Arial, sans-serif", size=11, color="#333"),
    margin=dict(l=55, r=20, t=50, b=45),
    xaxis=dict(showgrid=True, gridcolor="#eee"),
    yaxis=dict(showgrid=True, gridcolor="#eee"),
    width=CHART_WIDTH,
    height=CHART_HEIGHT,
)

COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
    "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
]


def _series_to_xy(series: list[dict]) -> tuple[list[str], list[float]]:
    dates = [p["date"] for p in series if p.get("value") is not None]
    values = [p["value"] for p in series if p.get("value") is not None]
    return dates, values


# ------------------------------------------------------------------
# 1. ATM Vol time series (front contract, trailing 60d)
# ------------------------------------------------------------------

def create_atm_vol_chart(im: InstrumentMetrics) -> go.Figure:
    """ATM vol time series from ICE historical data, with term structure fallback."""
    dates, values = _series_to_xy(im.atm_vol_series)

    if dates:
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=dates, y=values, mode="lines+markers",
            line=dict(color=COLORS[0], width=2),
            marker=dict(size=3),
            name="ATM Vol",
            hovertemplate="%{x} — %{y:.1f}%<extra></extra>",
        ))
        if values:
            fig.add_trace(go.Scatter(
                x=[dates[-1]], y=[values[-1]], mode="markers",
                marker=dict(color="gold", size=10, line=dict(color=COLORS[0], width=2)),
                showlegend=False,
            ))
        front_label = im.front.label if im.front else ""
        fig.update_layout(
            title=f"{im.instrument} — ATM Vol ({front_label})",
            yaxis_title="Vol (%)",
            **LAYOUT_DEFAULTS,
        )
        return fig

    # Fallback: show current ATM vol across contracts as a term structure snapshot
    labels = [c.label for c in im.contracts if c.atm_vol.current is not None]
    vols = [c.atm_vol.current for c in im.contracts if c.atm_vol.current is not None]
    if not labels:
        return _empty_figure(f"{im.instrument} — ATM Vol (no data)")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=labels, y=vols, mode="lines+markers",
        line=dict(color=COLORS[0], width=2),
        marker=dict(size=8, color=COLORS[0], line=dict(color="white", width=1)),
        name="ATM Vol",
        hovertemplate="%{x} — %{y:.1f}%<extra></extra>",
    ))
    fig.update_layout(
        title=f"{im.instrument} — ATM Vol (snapshot by contract)",
        yaxis_title="Vol (%)",
        xaxis_title="Contract",
        **LAYOUT_DEFAULTS,
    )
    return fig


# ------------------------------------------------------------------
# 2. Vol term structure (ATM vol across tenors)
# ------------------------------------------------------------------

def create_term_structure_chart(im: InstrumentMetrics) -> go.Figure:
    """ATM vol by contract tenor."""
    labels = [c.label for c in im.contracts if c.atm_vol.current is not None]
    vols = [c.atm_vol.current for c in im.contracts if c.atm_vol.current is not None]

    if not labels:
        return _empty_figure(f"{im.instrument} — Vol Term Structure (no data)")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=labels, y=vols, mode="lines+markers",
        line=dict(color=COLORS[0], width=2),
        marker=dict(size=7),
        name="ATM Vol",
        hovertemplate="%{x} — %{y:.2f}%<extra></extra>",
    ))

    fig.update_layout(
        title=f"{im.instrument} — Vol Term Structure",
        yaxis_title="ATM Vol (%)",
        xaxis_title="Contract",
        **LAYOUT_DEFAULTS,
    )
    return fig


# ------------------------------------------------------------------
# 3. 25D Skew (Risk Reversal) across tenors
# ------------------------------------------------------------------

def create_skew_term_chart(im: InstrumentMetrics) -> go.Figure:
    """25D Risk Reversal by contract tenor."""
    labels = [c.label for c in im.contracts if c.vol_25d_rr.current is not None]
    rrs = [c.vol_25d_rr.current for c in im.contracts if c.vol_25d_rr.current is not None]

    if not labels:
        return _empty_figure(f"{im.instrument} — 25D Skew Term (no data)")

    colors = ["#2ca02c" if v >= 0 else "#d62728" for v in rrs]
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=labels, y=rrs, marker_color=colors, name="25D RR",
        hovertemplate="%{x} — %{y:+.2f}pts<extra></extra>",
    ))

    fig.update_layout(
        title=f"{im.instrument} — 25D Risk Reversal by Tenor",
        yaxis_title="Skew (vol pts)",
        xaxis_title="Contract",
        **LAYOUT_DEFAULTS,
    )
    return fig


# ------------------------------------------------------------------
# 4. OI by strike (from option chain)
# ------------------------------------------------------------------

def create_oi_by_strike_chart(im: InstrumentMetrics) -> go.Figure:
    """Open interest by strike for the front contract."""
    front = im.front
    if front is None or not front.oi_by_strike:
        return _empty_figure(f"{im.instrument} — OI by Strike (no data)")

    calls = [(d["strike"], d["oi"]) for d in front.oi_by_strike
             if d["put_call"] == "Call" and d["strike"] and d["oi"]]
    puts = [(d["strike"], d["oi"]) for d in front.oi_by_strike
            if d["put_call"] == "Put" and d["strike"] and d["oi"]]

    fig = go.Figure()
    if calls:
        fig.add_trace(go.Bar(
            x=[c[0] for c in calls], y=[c[1] for c in calls],
            name="Call OI", marker_color=COLORS[0],
            hovertemplate="Strike %{x} — %{y:,.0f}<extra>Call OI</extra>",
        ))
    if puts:
        fig.add_trace(go.Bar(
            x=[p[0] for p in puts], y=[p[1] for p in puts],
            name="Put OI", marker_color="#d62728",
            hovertemplate="Strike %{x} — %{y:,.0f}<extra>Put OI</extra>",
        ))

    # Overlay current price as vertical line
    if front.price.current is not None:
        fig.add_vline(
            x=front.price.current, line_dash="dash", line_color="red",
            annotation_text=f"Spot {front.price.current:.2f}",
        )

    fig.update_layout(
        title=f"{im.instrument} — OI by Strike ({front.label})",
        xaxis_title="Strike",
        yaxis_title="Open Interest",
        barmode="group",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        **LAYOUT_DEFAULTS,
    )
    return fig


# ------------------------------------------------------------------
# 5. Cross-asset ATM vol comparison
# ------------------------------------------------------------------

def create_cross_asset_vol_chart(
    all_metrics: dict[str, InstrumentMetrics],
) -> go.Figure:
    """Grouped bar chart of ATM vol levels and 1d changes for all instruments."""
    names = []
    atm_vols = []
    vol_changes = []

    for key, im in all_metrics.items():
        front = im.front
        if front is None or front.atm_vol.current is None:
            continue
        names.append(key)
        atm_vols.append(front.atm_vol.current)
        vol_changes.append(front.atm_vol.change_1d or 0)

    if not names:
        return _empty_figure("Cross-Asset ATM Vol (no data)")

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=names, y=atm_vols, name="ATM Vol",
        marker_color=COLORS[0],
        hovertemplate="%{x} — %{y:.2f}%<extra>ATM Vol</extra>",
    ))
    change_colors = ["#2ca02c" if c >= 0 else "#d62728" for c in vol_changes]
    fig.add_trace(go.Bar(
        x=names, y=vol_changes, name="1D Change",
        marker_color=change_colors,
        hovertemplate="%{x} — %{y:+.2f}pts<extra>1D Change</extra>",
    ))

    fig.update_layout(
        title="Cross-Asset ATM Vol Comparison",
        yaxis_title="Vol (%)",
        barmode="group",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        **{**LAYOUT_DEFAULTS, "width": 800},
    )
    return fig


# ------------------------------------------------------------------
# 6. Price chart with OI overlay
# ------------------------------------------------------------------

def create_price_chart(im: InstrumentMetrics) -> go.Figure:
    """Price time series with OI on secondary axis."""
    dates_p, prices = _series_to_xy(im.price_series)
    dates_o, ois = _series_to_xy(im.oi_series)

    if not dates_p:
        return _empty_figure(f"{im.instrument} — Price (no data)")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates_p, y=prices, mode="lines",
        line=dict(color=COLORS[0], width=2),
        name="Price",
        hovertemplate="%{x} — %{y:.4f}<extra>Price</extra>",
    ))
    if dates_o:
        fig.add_trace(go.Bar(
            x=dates_o, y=ois, name="Open Interest",
            marker_color="rgba(31,119,180,0.2)",
            yaxis="y2",
            hovertemplate="%{x} — %{y:,.0f}<extra>OI</extra>",
        ))

    front_label = im.front.label if im.front else ""
    fig.update_layout(
        title=f"{im.instrument} — Price & OI ({front_label})",
        yaxis_title=f"Price ({im.unit})",
        yaxis2=dict(
            title="Open Interest",
            overlaying="y",
            side="right",
            showgrid=False,
        ),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        **LAYOUT_DEFAULTS,
    )
    return fig


# ------------------------------------------------------------------
# Export helpers
# ------------------------------------------------------------------

def figure_to_base64(fig: go.Figure, fmt: str = "png") -> str | None:
    """Export figure to base64 PNG (for email).  Returns None on failure."""
    if not _KALEIDO_ENABLED:
        return None
    try:
        img_bytes = pio.to_image(fig, format=fmt, width=CHART_WIDTH, height=CHART_HEIGHT)
        return base64.b64encode(img_bytes).decode("utf-8")
    except Exception:
        logger.warning("Chart image export failed")
        return None


def generate_all_charts(
    all_metrics: dict[str, InstrumentMetrics],
) -> dict[str, dict[str, go.Figure]]:
    """
    Generate all per-instrument charts + cross-asset chart.

    Returns:
        {instrument_name: {"atm_vol": fig, "term_structure": fig,
                           "skew_term": fig, "oi_strike": fig, "price": fig}}
        Plus a special key "__cross_asset__" with the comparison chart.
    """
    charts: dict[str, dict[str, go.Figure]] = {}

    for name, im in all_metrics.items():
        logger.info("Generating charts for %s...", name)
        charts[name] = {
            "atm_vol": create_atm_vol_chart(im),
            "term_structure": create_term_structure_chart(im),
            "skew_term": create_skew_term_chart(im),
            "oi_strike": create_oi_by_strike_chart(im),
            "price": create_price_chart(im),
        }

    charts["__cross_asset__"] = {
        "vol_comparison": create_cross_asset_vol_chart(all_metrics),
    }

    return charts


def _empty_figure(title: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        title=title,
        annotations=[dict(
            text="No data available",
            xref="paper", yref="paper", x=0.5, y=0.5,
            showarrow=False, font=dict(size=14, color="#999"),
        )],
        **LAYOUT_DEFAULTS,
    )
    return fig
