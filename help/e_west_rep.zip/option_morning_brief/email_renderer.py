"""
HTML email renderer for the Energy Options Morning Brief.

Composes a charts-first visual email from modular ReportSection results:
  - Executive summary (LLM-generated)
  - Cross-asset heatmap + ATM vol chart (global sections)
  - Per-instrument: LLM narrative, visual section blocks (vol surface heatmap,
    skew change heatmaps, term structure chart, OI profile chart, price overview)
  - Volume z-score heatmap (global, bottom)
  - Footer

Sends via jain_commods Kafka-backed send_email.
"""

from __future__ import annotations

import logging
from datetime import datetime

from jain_commods.core.util.emailhelper import send_email

from .sections.base import SectionResult

logger = logging.getLogger(__name__)

CSS = """
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; color: #333; margin: 0; padding: 0; background: #f0f2f5; }
  .container { max-width: 980px; margin: 0 auto; background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
  .header { background: linear-gradient(135deg, #0d1b2a 0%, #1b3a5c 100%); color: #fff; padding: 28px 32px; }
  .header h1 { margin: 0; font-size: 24px; font-weight: 700; letter-spacing: -0.3px; }
  .header .sub { font-size: 13px; color: #8ca5c0; margin-top: 6px; }
  .exec-summary { background: #f7f9fc; border-left: 4px solid #1b4f72; padding: 18px 24px; margin: 20px 24px; border-radius: 0 6px 6px 0; }
  .exec-summary h2 { font-size: 13px; color: #0d1b2a; margin: 0 0 10px 0; text-transform: uppercase; letter-spacing: 1.2px; font-weight: 700; }
  .exec-summary p { font-size: 13px; line-height: 1.75; margin: 0; color: #2d3748; }
  .global-section { margin: 12px 24px; }
  .commodity-section { margin: 20px 24px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
  .commodity-header { background: linear-gradient(135deg, #0d1b2a 0%, #1b3a5c 100%); color: #fff; padding: 12px 18px; font-size: 17px; font-weight: 700; letter-spacing: -0.2px; }
  .commodity-header .unit { font-size: 12px; color: #8ca5c0; font-weight: 400; margin-left: 10px; }
  .narrative { padding: 12px 18px; font-size: 13px; line-height: 1.7; background: #f7f9fc; border-bottom: 1px solid #e2e8f0; color: #2d3748; }
  .section-body { padding: 10px 18px; }
  .footer { text-align: center; font-size: 11px; color: #a0aec0; padding: 18px; border-top: 1px solid #e2e8f0; }
</style>
"""


def render_html(
    exec_summary: str,
    cross_asset_narrative: str,
    all_metrics: dict,
    narratives: dict[str, str],
    section_results: dict[str, dict[str, SectionResult]],
    global_results: dict[str, SectionResult],
) -> str:
    """
    Render the full HTML email body from section results.

    Args:
        exec_summary:          LLM executive summary text
        cross_asset_narrative: LLM cross-asset insights text
        all_metrics:           {inst_key: InstrumentMetrics} for metadata
        narratives:            {inst_key: narrative_text}
        section_results:       {section_name: {inst_key: SectionResult}}
        global_results:        {section_name: SectionResult} for global sections
    """
    report_date = datetime.now().strftime("%A %d %B %Y, %H:%M")
    n_instruments = len(all_metrics)

    # --- Global sections above per-instrument (e.g. cross-asset dashboard) ---
    top_global_html = ""
    for sec_name in ("cross_asset",):
        sr = global_results.get(sec_name)
        if sr and sr.html:
            top_global_html += f'<div class="global-section">{sr.html}</div>\n'

    # --- Per-instrument blocks ---
    per_instrument_sections = []
    section_order = [
        "futures_chart",
        "price_overview",
        "vol_surface",
        "skew_change",
        "term_structure",
        "oi_profile",
    ]

    for inst_key, im in all_metrics.items():
        narrative = narratives.get(inst_key, "")

        section_blocks = []
        for sec_name in section_order:
            sec_results = section_results.get(sec_name, {})
            sr = sec_results.get(inst_key)
            if sr and sr.html:
                section_blocks.append(f'<div class="section-body">{sr.html}</div>')

        per_instrument_sections.append(f"""
        <div class="commodity-section">
          <div class="commodity-header">
            {im.instrument}
            <span class="unit">{im.unit} | {im.trade_date}</span>
          </div>
          <div class="narrative">{narrative}</div>
          {"".join(section_blocks)}
        </div>
        """)

    # --- Global sections below per-instrument (e.g. volume z-scores) ---
    bottom_global_html = ""
    for sec_name in ("volume_zscore",):
        sr = global_results.get(sec_name)
        if sr and sr.html:
            bottom_global_html += f'<div class="global-section">{sr.html}</div>\n'

    # --- Cross-asset narrative ---
    cross_asset_block = ""
    if cross_asset_narrative:
        cross_asset_block = f"""
        <div style="background:#fff8e1;border-left:4px solid #f9a825;padding:14px 24px;margin:0 24px 20px 24px;">
          <div style="font-size:14px;color:#5d4037;margin:0 0 6px 0;text-transform:uppercase;letter-spacing:1px;font-weight:600;">Cross-Market Insights</div>
          <p style="font-size:13px;line-height:1.6;margin:0;">{cross_asset_narrative}</p>
        </div>
        """

    html = f"""
    <html>
    <head>{CSS}</head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Energy &amp; Metals Morning Brief</h1>
          <div class="sub">{report_date} | Bloomberg BPIPE | {n_instruments} Instruments</div>
        </div>

        <div class="exec-summary">
          <h2>Executive Summary</h2>
          <p>{exec_summary}</p>
        </div>

        {top_global_html}

        {cross_asset_block}

        {"".join(per_instrument_sections)}

        {bottom_global_html}

        <div class="footer">
          Automated report — EU Commodities Desk | Futures &amp; Options | Bloomberg BPIPE + ICE Snowflake
        </div>
      </div>
    </body>
    </html>
    """
    return html


def send_morning_brief(
    html_body: str,
    recipients: str,
    dry_run: bool = False,
) -> bool:
    """Send the morning brief email via the Kafka-backed email service."""
    report_date = datetime.now().strftime("%Y-%m-%d")
    subject = f"Energy & Metals Morning Brief — {report_date}"

    if dry_run:
        logger.info("[DRY RUN] Would send to: %s", recipients)
        logger.info("[DRY RUN] Subject: %s", subject)
        return False

    try:
        send_email(
            recipients=recipients,
            subject=subject,
            body=html_body,
        )
        logger.info("Email sent to %s", recipients)
        return True
    except Exception:
        logger.exception("Failed to send email")
        return False
