"""
Diagnostic script: traces ATM vol history data flow from Snowflake → analytics → chart.
Run from eu_reports root:  python -m option_morning_brief.debug_atm_vol_history
"""
from __future__ import annotations

import logging
import sys

import numpy as np
import pandas as pd

from jain_commods.core.interfaces.snowflake import SnowFlake

from . import config as cfg
from .bbg_tickers import all_contract_tickers
from .snowflake_options import (
    ICEOptionsDataFetcher,
    compute_vol_metrics,
    find_atm,
    parse_strip_label,
)

logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stdout)
log = logging.getLogger(__name__)

INSTRUMENT = "TTF"


def main():
    contracts = all_contract_tickers()
    specs = contracts.get(INSTRUMENT, [])
    if not specs:
        log.error("No specs for %s", INSTRUMENT)
        return

    inst_cfg = cfg.INSTRUMENTS[INSTRUMENT]
    log.info("=== Instrument: %s ===", INSTRUMENT)
    log.info("Spec labels: %s", [s.label for s in specs])
    log.info("ICE commodity: %s", inst_cfg.ice_commodity)
    log.info("")

    # --- Step 1: Raw Snowflake query (mirroring positioning dashboard exactly) ---
    log.info("--- Step 1: Raw Snowflake query ---")
    conn = SnowFlake(database="ICE", schema="MFT", role="FR_COMMOD_PM_EU")
    cur = conn._conn.cursor()

    for member in inst_cfg.ice_commodity:
        commodity_name = member["commodity_name"]
        product_id = member["id"]

        # Query A: positioning dashboard style (with delta_factor IS NOT NULL, no date filter)
        q_positioning = f"""
            SELECT COUNT(*) AS cnt,
                   MIN(TRADE_DATE) AS min_td,
                   MAX(TRADE_DATE) AS max_td,
                   COUNT(DISTINCT TRADE_DATE) AS n_dates,
                   COUNT(DISTINCT STRIP) AS n_strips
              FROM ice.mft.options
             WHERE commodity = '{commodity_name}'
               AND product   = {product_id}
               AND source NOT LIKE 'UTIL MKT'
               AND delta_factor IS NOT NULL
        """
        cur.execute(q_positioning)
        row = cur.fetchone()
        log.info("Positioning-style query (delta IS NOT NULL, no date limit):")
        log.info("  rows=%s, dates=%s–%s, n_dates=%s, n_strips=%s", *row)

        # Query B: our current query (no delta filter, 60-day lookback)
        q_ours = f"""
            SELECT COUNT(*) AS cnt,
                   MIN(TRADE_DATE) AS min_td,
                   MAX(TRADE_DATE) AS max_td,
                   COUNT(DISTINCT TRADE_DATE) AS n_dates,
                   COUNT(DISTINCT STRIP) AS n_strips
              FROM ice.mft.options
             WHERE commodity = '{commodity_name}'
               AND product   = {product_id}
               AND source NOT LIKE 'UTIL MKT'
               AND trade_date >= DATEADD(day, -60, CURRENT_DATE())
        """
        cur.execute(q_ours)
        row = cur.fetchone()
        log.info("Our current query (no delta filter, 60-day lookback):")
        log.info("  rows=%s, dates=%s–%s, n_dates=%s, n_strips=%s", *row)

        # Query C: improved (delta IS NOT NULL + 240-day lookback)
        q_improved = f"""
            SELECT COUNT(*) AS cnt,
                   MIN(TRADE_DATE) AS min_td,
                   MAX(TRADE_DATE) AS max_td,
                   COUNT(DISTINCT TRADE_DATE) AS n_dates,
                   COUNT(DISTINCT STRIP) AS n_strips
              FROM ice.mft.options
             WHERE commodity = '{commodity_name}'
               AND product   = {product_id}
               AND source NOT LIKE 'UTIL MKT'
               AND delta_factor IS NOT NULL
               AND trade_date >= DATEADD(day, -240, CURRENT_DATE())
        """
        cur.execute(q_improved)
        row = cur.fetchone()
        log.info("Improved query (delta IS NOT NULL + 240-day lookback):")
        log.info("  rows=%s, dates=%s–%s, n_dates=%s, n_strips=%s", *row)

    # --- Step 2: Fetch full data for front strip and check ATM vol per date ---
    log.info("")
    log.info("--- Step 2: ATM vol per trade date for front strip ---")
    front_label = specs[0].label
    log.info("Front strip label: %s", front_label)

    member = inst_cfg.ice_commodity[0]
    q_front = f"""
        SELECT *
          FROM ice.mft.options
         WHERE commodity = '{member["commodity_name"]}'
           AND product   = {member["id"]}
           AND source NOT LIKE 'UTIL MKT'
           AND delta_factor IS NOT NULL
           AND trade_date >= DATEADD(day, -240, CURRENT_DATE())
    """
    cur.execute(q_front)
    df = cur.fetch_pandas_all()
    df.columns = [c.upper() for c in df.columns]

    if "TRADE_DATE" in df.columns:
        df["TRADE_DATE"] = pd.to_datetime(df["TRADE_DATE"])

    df["_strip_label"] = df["STRIP"].apply(parse_strip_label)
    log.info("Unique parsed strip labels: %s", sorted(df["_strip_label"].dropna().unique()))

    front_data = df[df["_strip_label"] == front_label]
    log.info("Rows matching front label '%s': %d", front_label, len(front_data))

    if front_data.empty:
        log.error("No data for front strip! Check label matching.")
        log.info("Sample STRIP values: %s", df["STRIP"].unique()[:20].tolist())
        return

    log.info("")
    log.info("ATM vol by trade date (last 30 dates):")
    atm_results = []
    for td, grp in front_data.groupby("TRADE_DATE"):
        atm = find_atm(grp)
        n_with_delta = grp["DELTA_FACTOR"].notna().sum()
        n_near_50 = ((grp["DELTA_FACTOR"].abs() - 0.5).abs() <= 0.05).sum()
        atm_results.append({
            "date": td,
            "atm_vol": atm,
            "n_rows": len(grp),
            "n_with_delta": n_with_delta,
            "n_near_50d": n_near_50,
        })

    atm_df = pd.DataFrame(atm_results).set_index("date").sort_index().tail(30)
    log.info(atm_df.to_string())

    n_valid = atm_df["atm_vol"].notna().sum()
    n_total = len(atm_df)
    log.info("")
    log.info("Valid ATM vol: %d / %d dates (%.0f%%)", n_valid, n_total, 100 * n_valid / n_total if n_total else 0)

    # --- Step 3: Run our fetcher and check what comes out ---
    log.info("")
    log.info("--- Step 3: Run ICEOptionsDataFetcher with current settings ---")
    fetcher = ICEOptionsDataFetcher()
    ice_result_current = fetcher.fetch_all({INSTRUMENT: specs})
    result = ice_result_current.get(INSTRUMENT)
    if result is None:
        log.error("No result from ICEOptionsDataFetcher!")
        return

    log.info("latest_metrics keys: %s", list(result.latest_metrics.keys()))
    log.info("historical_metrics keys: %s", list(result.historical_metrics.keys()))

    hist = result.historical_metrics.get(front_label)
    if hist is None:
        log.error("No historical_metrics for '%s'! Available: %s", front_label, list(result.historical_metrics.keys()))
    else:
        log.info("historical_metrics['%s'] shape: %s", front_label, hist.shape)
        log.info("ATM vol non-null count: %d / %d", hist["atm_vol"].notna().sum(), len(hist))
        log.info("Last 10 rows:")
        log.info(hist.tail(10).to_string())


if __name__ == "__main__":
    main()
