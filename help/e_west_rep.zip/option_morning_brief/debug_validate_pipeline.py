"""
Pipeline validation script: end-to-end check of all data flowing through the
morning brief pipeline.

Runs the same steps as run.py but with detailed per-instrument, per-contract
diagnostics printed to console. Flags missing data clearly.

Validates both Snowflake ICE MFT options data and Bloomberg futures data.

Usage:
    cd "C:\...\eu_reports"
    python -m option_morning_brief.debug_validate_pipeline
"""

from __future__ import annotations

import sys
from pathlib import Path

_pkg_parent = str(Path(__file__).resolve().parent.parent)
if _pkg_parent not in sys.path:
    sys.path.insert(0, _pkg_parent)

import logging
logging.basicConfig(level=logging.WARNING)

import os
import pandas as pd
from dotenv import load_dotenv
load_dotenv(Path(__file__).parent / ".env")

from option_morning_brief import config as cfg
from option_morning_brief.bbg_tickers import all_contract_tickers
from option_morning_brief.data_fetcher import BloombergDataFetcher
from option_morning_brief.snowflake_options import ICEOptionsDataFetcher
from option_morning_brief.analytics import MetricsEngine, CrossAssetAnalyzer

DIV = "=" * 76
SUB = "-" * 76


def _fmt(v, fmt=".2f"):
    if v is None:
        return "—"
    try:
        return f"{v:{fmt}}"
    except (TypeError, ValueError):
        return str(v)


def main():
    on_server = os.environ.get("BLOOMBERG_ON_SERVER", "true").lower() == "true"

    # ══════════════════════════════════════════════════════════════════
    # 1. TICKER GENERATION
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("1. TICKER GENERATION")
    print(DIV)

    contracts = all_contract_tickers()
    for inst_key, specs in contracts.items():
        inst_cfg = cfg.INSTRUMENTS[inst_key]
        source = "ICE Snowflake" if inst_cfg.has_ice_options else "Bloomberg only"
        lines = []
        for s in specs:
            parts = [f"ticker={s.ticker:<22}"]
            if s.vol_surface_ticker != s.ticker:
                parts.append(f"vol={s.vol_surface_ticker}")
            if s.opt_chain_ticker != s.ticker:
                parts.append(f"opt_chain={s.opt_chain_ticker}")
            lines.append(f"    {s.label:<8} {s.tenor_type:<10} {'  '.join(parts)}")
        print(f"\n  {inst_key} ({len(specs)} contracts) [options: {source}]:")
        for ln in lines:
            print(ln)

    # ══════════════════════════════════════════════════════════════════
    # 2. DATA FETCH
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("2. FETCHING DATA")
    print(DIV)

    fetcher = BloombergDataFetcher(on_server=on_server)

    print("\n  [2a] BDH Futures History (all instruments)...")
    futures_hist = fetcher.fetch_futures_history(contracts, lookback_days=30)

    # 2b. Snowflake ICE options
    print("\n  [2b] Snowflake ICE MFT Options...")
    ice_options = {}
    try:
        ice_fetcher = ICEOptionsDataFetcher()
        ice_options = ice_fetcher.fetch_all(contracts, lookback_days=30)
        print(f"    Snowflake returned data for: {[k for k, v in ice_options.items() if v.latest_metrics]}")
    except Exception as e:
        print(f"    !! Snowflake fetch failed: {e}")

    # 2c. BDP Vol Surface (non-ICE only)
    non_ice = {k: v for k, v in contracts.items() if not cfg.INSTRUMENTS[k].has_ice_options}
    print(f"\n  [2c] BDP Vol Surface (non-ICE: {list(non_ice.keys()) or 'none'})...")
    vol_surface = fetcher.fetch_vol_surface_snapshot(non_ice) if non_ice else {}

    # 2d. Option Chains (non-ICE only)
    print(f"\n  [2d] Option Chains (non-ICE)...")
    option_chains = fetcher.fetch_option_chains(non_ice) if non_ice else {}

    # Prune expired/illiquid contracts
    min_rows = 20
    for inst_key, specs in list(contracts.items()):
        futs_df = futures_hist.get(inst_key)
        if futs_df is None or futs_df.empty:
            continue
        live = []
        for s in specs:
            px_col = f"{s.ticker}_PX_LAST"
            n_rows = futs_df[px_col].dropna().shape[0] if px_col in futs_df.columns else 0
            if n_rows >= min_rows:
                live.append(s)
            else:
                print(f"  PRUNED: {s.ticker} ({s.label}) — {n_rows} rows")
        contracts[inst_key] = live

    # ══════════════════════════════════════════════════════════════════
    # 3. BDH FUTURES DATA CHECK
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("3. BDH FUTURES DATA — per instrument")
    print(DIV)

    for inst_key, specs in contracts.items():
        futs_df = futures_hist.get(inst_key, pd.DataFrame())
        print(f"\n  {inst_key}:")
        if futs_df.empty:
            print(f"    !! NO DATA")
            continue
        for s in specs:
            px_col = f"{s.ticker}_PX_LAST"
            vol_col = f"{s.ticker}_VOLUME"
            oi_col = f"{s.ticker}_OPEN_INT"
            has_px = px_col in futs_df.columns and futs_df[px_col].dropna().shape[0] > 0
            has_vol = vol_col in futs_df.columns and futs_df[vol_col].dropna().shape[0] > 0
            has_oi = oi_col in futs_df.columns and futs_df[oi_col].dropna().shape[0] > 0
            last_px = futs_df[px_col].dropna().iloc[-1] if has_px else None
            last_vol = futs_df[vol_col].dropna().iloc[-1] if has_vol else None
            last_oi = futs_df[oi_col].dropna().iloc[-1] if has_oi else None
            status = "OK" if has_px else "!!"
            print(
                f"    {status} {s.ticker:<22} {s.label:<8}  "
                f"PX={_fmt(last_px, '.2f'):>10}  "
                f"VOL={_fmt(last_vol, ',.0f'):>10}  "
                f"OI={_fmt(last_oi, ',.0f'):>10}  "
                f"({futs_df[px_col].dropna().shape[0] if has_px else 0} rows)"
            )

    # ══════════════════════════════════════════════════════════════════
    # 4. SNOWFLAKE ICE OPTIONS CHECK
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("4. SNOWFLAKE ICE OPTIONS — per instrument/strip")
    print(DIV)

    for inst_key, specs in contracts.items():
        inst_cfg = cfg.INSTRUMENTS[inst_key]
        if not inst_cfg.has_ice_options:
            print(f"\n  {inst_key}: [non-ICE, skipped]")
            continue

        ice_result = ice_options.get(inst_key)
        print(f"\n  {inst_key}:")
        if ice_result is None or not ice_result.latest_metrics:
            print(f"    !! NO SNOWFLAKE DATA")
            continue

        raw_strips = sorted(ice_result.raw_df["STRIP"].unique()) if not ice_result.raw_df.empty else []
        print(f"    Raw data: {len(ice_result.raw_df)} rows, strips: {raw_strips[:15]}{'...' if len(raw_strips) > 15 else ''}")

        latest_date = ice_result.raw_df["TRADE_DATE"].max() if not ice_result.raw_df.empty else None
        print(f"    Latest trade date: {latest_date.date() if latest_date else '?'}")

        hdr = (
            f"    {'Strip':<10} {'TradeDate':>10} {'ATM Vol':>8} {'25D RR':>8} {'25D BF':>8} "
            f"{'10D RR':>8} {'10D BF':>8} {'CallOI':>10} {'PutOI':>10} {'Hist':>5}"
        )
        print(hdr)
        print(f"    {'-' * 100}")

        for s in specs:
            vm = ice_result.latest_metrics.get(s.label)
            hist_df = ice_result.historical_metrics.get(s.label)
            n_hist = len(hist_df) if hist_df is not None else 0

            if vm is None:
                print(f"    !! {s.label:<10} NO MATCHING STRIP IN SNOWFLAKE")
                continue

            td_str = vm.trade_date.date().isoformat() if vm.trade_date else "?"
            print(
                f"    OK {s.label:<10} "
                f"{td_str:>10} "
                f"{_fmt(vm.atm_vol, '.1f'):>8} "
                f"{_fmt(vm.vol_25d_rr, '+.1f'):>8} "
                f"{_fmt(vm.vol_25d_bf, '+.1f'):>8} "
                f"{_fmt(vm.vol_10d_rr, '+.1f'):>8} "
                f"{_fmt(vm.vol_10d_bf, '+.1f'):>8} "
                f"{_fmt(vm.call_oi, ',.0f'):>10} "
                f"{_fmt(vm.put_oi, ',.0f'):>10} "
                f"{n_hist:>5}d"
            )

    # ══════════════════════════════════════════════════════════════════
    # 5. BDP VOL SURFACE CHECK (non-ICE only)
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("5. BDP VOL SURFACE — non-ICE instruments")
    print(DIV)

    mny_fields = [f for f in cfg.VOL_SURFACE_BDP_FIELDS if "IMPVOL" in f]
    for inst_key, specs in contracts.items():
        inst_cfg = cfg.INSTRUMENTS[inst_key]
        if inst_cfg.has_ice_options:
            continue
        vol_df = vol_surface.get(inst_key, pd.DataFrame())
        print(f"\n  {inst_key}:")
        if vol_df.empty:
            print(f"    !! NO DATA")
            continue
        for s in specs:
            ticker = s.ticker
            if ticker not in vol_df.index:
                print(f"    !! {ticker:<22} {s.label:<8}  NOT IN INDEX")
                continue
            row = vol_df.loc[ticker]
            atm = row.get("30DAY_IMPVOL_100.0%MNY_DF")
            oi = row.get("OPEN_INT")
            vol = row.get("VOLUME")
            n_fields = sum(1 for f in mny_fields if row.get(f) is not None)
            atm_s = f"{atm:.1f}%" if atm is not None else "—"
            print(
                f"    OK {ticker:<22} {s.label:<8}  "
                f"ATM={atm_s:>8}  "
                f"OI={_fmt(oi, ',.0f'):>10}  "
                f"VOL={_fmt(vol, ',.0f'):>10}  "
                f"({n_fields}/{len(mny_fields)} moneyness fields)"
            )

    # ══════════════════════════════════════════════════════════════════
    # 6. OPTION CHAINS CHECK (non-ICE only)
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("6. OPTION CHAINS — non-ICE instruments")
    print(DIV)

    for inst_key, specs in contracts.items():
        inst_cfg = cfg.INSTRUMENTS[inst_key]
        if inst_cfg.has_ice_options:
            continue
        chain_df = option_chains.get(inst_key, pd.DataFrame())
        print(f"\n  {inst_key}:")
        if chain_df.empty:
            print(f"    !! NO CHAIN DATA")
            continue
        for s in specs:
            if "underlying_ticker" not in chain_df.columns:
                print(f"    !! {s.ticker:<22} missing underlying_ticker column")
                continue
            sub = chain_df[chain_df["underlying_ticker"] == s.ticker]
            if sub.empty:
                print(f"    !! {s.ticker:<22} {s.label:<8}  0 options")
                continue
            calls = sub[sub.get("OPT_PUT_CALL", pd.Series()) == "C"] if "OPT_PUT_CALL" in sub.columns else pd.DataFrame()
            puts = sub[sub.get("OPT_PUT_CALL", pd.Series()) == "P"] if "OPT_PUT_CALL" in sub.columns else pd.DataFrame()
            n_calls = len(calls)
            n_puts = len(puts)

            iv_col = "OPT_IMPLIED_VOLATILITY_MID"
            d_col = "OPT_DELTA"
            c_both = (calls[iv_col].notna() & calls[d_col].notna()).sum() if iv_col in calls.columns and d_col in calls.columns else 0
            has_oi = "OPEN_INT" in sub.columns and sub["OPEN_INT"].notna().sum() > 0

            iv_detail = f"IV+D: {c_both}/{n_calls}C"
            flags = []
            if c_both > 0:
                flags.append("IV")
            if has_oi:
                flags.append("OI")
            print(
                f"    OK {s.ticker:<22} {s.label:<8}  "
                f"{len(sub):>4} opts ({n_calls}C/{n_puts}P)  "
                f"{iv_detail}  "
                f"fields: {', '.join(flags) if flags else 'NONE'}"
            )

    # ══════════════════════════════════════════════════════════════════
    # 7. ANALYTICS — COMPUTED METRICS
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("7. COMPUTED METRICS — per instrument/contract")
    print(DIV)

    engine = MetricsEngine()
    all_metrics = engine.compute_all(
        contracts, futures_hist, vol_surface, option_chains,
        ice_options=ice_options,
    )

    for inst_key, im in all_metrics.items():
        print(f"\n  {inst_key} ({im.unit}):")
        if not im.contracts:
            print(f"    !! NO CONTRACTS")
            continue
        hdr = (
            f"    {'Contract':<10} {'Price':>8} {'ATM Vol':>8} "
            f"{'25D RR':>8} {'25D BF':>8} {'10D RR':>8} "
            f"{'P/C':>6} {'CallOI':>8} {'PutOI':>8} {'Source':>8}"
        )
        print(hdr)
        print(f"    {'-'*90}")
        for cm in im.contracts:
            src = cm.vol_source or "none"
            print(
                f"    {cm.label:<10} "
                f"{_fmt(cm.price.current, '.2f'):>8} "
                f"{_fmt(cm.atm_vol.current, '.1f'):>8} "
                f"{_fmt(cm.vol_25d_rr.current, '+.1f'):>8} "
                f"{_fmt(cm.vol_25d_bf.current, '+.1f'):>8} "
                f"{_fmt(cm.vol_10d_rr.current, '+.1f'):>8} "
                f"{_fmt(cm.pc_oi_ratio.current, '.2f'):>6} "
                f"{_fmt(cm.call_oi.current, ',.0f'):>8} "
                f"{_fmt(cm.put_oi.current, ',.0f'):>8} "
                f"{src:>8}"
            )

        ts = im.vol_term_spread.current
        ts_s = f"{ts:+.1f}pts" if ts is not None else "—"
        print(f"    Term spread: {ts_s}")

    # ══════════════════════════════════════════════════════════════════
    # 8. CROSS-ASSET ANALYSIS
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("8. CROSS-ASSET ANALYSIS")
    print(DIV)

    xa = CrossAssetAnalyzer()
    cross_asset = xa.analyze(all_metrics, futures_hist)

    anomalies = cross_asset.get("anomalies", [])
    if anomalies:
        print(f"\n  Anomalies ({len(anomalies)}):")
        for a in anomalies:
            print(f"    - {a.get('description', '?')}")
    else:
        print("\n  No anomalies detected")

    divergences = cross_asset.get("divergences", [])
    if divergences:
        print(f"\n  Divergences ({len(divergences)}):")
        for d in divergences:
            print(f"    - {d.get('description', '?')}")
    else:
        print("  No divergences detected")

    # ══════════════════════════════════════════════════════════════════
    # 9. SUMMARY — MISSING DATA FLAGS
    # ══════════════════════════════════════════════════════════════════
    print(f"\n{DIV}")
    print("9. MISSING DATA SUMMARY")
    print(DIV)

    issues: list[str] = []
    for inst_key, specs in contracts.items():
        inst_cfg = cfg.INSTRUMENTS[inst_key]
        im = all_metrics.get(inst_key)
        if im is None or not im.contracts:
            issues.append(f"{inst_key}: NO METRICS AT ALL")
            continue
        for cm in im.contracts:
            if cm.price.current is None:
                issues.append(f"{inst_key} {cm.label}: no price")
            if inst_cfg.has_ice_options:
                if cm.atm_vol.current is None:
                    issues.append(f"{inst_key} {cm.label}: no ATM vol (ICE)")
                if cm.vol_25d_rr.current is None:
                    issues.append(f"{inst_key} {cm.label}: no 25D RR (ICE)")
                if cm.call_oi.current is None and cm.put_oi.current is None:
                    issues.append(f"{inst_key} {cm.label}: no option OI (ICE)")

    if issues:
        print(f"\n  {len(issues)} data gaps:")
        for iss in issues:
            print(f"    !! {iss}")
    else:
        print("\n  ALL DATA PRESENT — no gaps detected!")

    print(f"\n{DIV}")
    print("VALIDATION COMPLETE")
    print(DIV)


if __name__ == "__main__":
    main()
