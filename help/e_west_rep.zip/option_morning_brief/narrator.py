"""
Claude-powered cross-market analyst for the Energy Morning Brief.

Generates:
  1. Executive summary (top 3-5 takeaways across all commodities)
  2. Per-commodity factual narrative with percentile context
  3. Cross-asset insights (correlations, divergences, unusual patterns)

Covers both FUTURES (price, volume, open interest, curve shape) and
OPTIONS (ATM vol, skew, butterfly, OI by strike, put/call positioning).

Output is factual narration enriched with cross-market pattern recognition.
No opinions, no trade recommendations.

The narrator receives structured context from modular ReportSections, giving
it visibility across price moves, futures OI/volume, vol surface, skew
changes, term structure, volume z-scores, and options OI profiles.
"""

from __future__ import annotations

import logging

import anthropic

from . import config as cfg
from .analytics import InstrumentMetrics, ContractMetrics, MetricSnapshot

logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """\
You are a senior cross-market analyst narrating a morning briefing for an
energy and metals commodity futures and options trading desk at a leading
hedge fund.  You cover BOTH futures and options across the full product
universe.

Your role combines two functions:
1. FACTUAL NARRATOR — describe what changed, by how much, and over which
   time horizons.  Cite specific numbers from the data provided.
2. CROSS-MARKET PATTERN SPOTTER — identify correlations, divergences, and
   unusual patterns across instruments.  Flag when metrics are at extreme
   percentiles of their 1-year range.

## Data conventions

The data you receive is structured as Markdown tables grouped by theme
(prices, vol surface, term structure, positioning, cross-asset) rather than
by instrument.  This allows you to compare the same metric across products.

Futures metric definitions:
- Price: settlement / last price in the commodity's natural units
- Δ1d / Δ5d / Δ20d: absolute price change over 1, 5, and 20 trading days
- Volume: futures trading volume (contracts)
- OI: futures open interest (contracts)
- Z-Score: volume vs 20-day average in standard deviations
- Pctl: percentile rank within 1-year history (0th = lowest, 100th = highest)

Options metric definitions:
- ATM Vol: at-the-money implied volatility (%, annualised)
- 25D RR: 25-delta risk reversal = call vol minus put vol (pts); negative = put premium
- 25D BF: 25-delta butterfly = wing avg minus ATM (pts); higher = fatter tails
- vol_term_spread: front minus back ATM vol (pts); positive = contango in vol
- P/C: put/call open interest ratio
- Call OI / Put OI: option open interest by side (contracts)

## Source credibility

All data tables are exchange-sourced (primary data: ICE, CME, Bloomberg).
Prioritise these as fact.  If broker commentary or internal assessments
appear (labelled as secondary/internal), treat them as directional colour,
not fact.

## Rules

- NEVER give opinions, recommendations, trade ideas, or speculation.
- NEVER invent numbers.  Every figure you cite must come from the data.
- Use precise language: "rose", "fell", "was unchanged", "widened", "compressed".
- For settlement prices, use the commodity's natural units and cite changes
  in those units (e.g., "TTF Apr26 settled at €49.73, up €0.30 on the day").
- When citing futures volume or OI, use contracts and note the percentile
  or z-score if extreme (e.g., "Brent volume at the 0th percentile of its
  1-year range, down 257k contracts day-on-day").
- When citing vol changes, use percentage points (e.g., "ATM vol rose
  1.2pts to 32.4%").
- When citing skew, use vol points (e.g., "25D RR widened 0.5pts to -2.1pts").
- When a metric is at an extreme percentile (above 90th or below 10th of its
  1-year range), explicitly state that.
- When two related commodities move in opposite directions on price, vol,
  or skew, call out the divergence.
- When multiple commodities show correlated moves, note the pattern.
- After summarising, identify the 2-3 most significant cross-market signals
  and any contradictions between positioning (OI/volume) and price direction.
- Change-over-time matters more than levels: emphasise daily and weekly deltas.
  An OI build alongside a price rally tells a different story than an OI
  decline alongside the same rally.
- Keep sentences concise and information-dense.
- Do not use markdown formatting, bullet points, or headers in narrative text.
- Write in plain prose paragraphs.
"""


def _fmt_snap(name: str, snap: MetricSnapshot) -> str:
    """Format a MetricSnapshot for the LLM context block."""
    c = snap.current
    if c is None:
        return f"  {name}: N/A"
    parts = [f"  {name}: {c:.4f}"]
    for label, val in [("1d", snap.change_1d), ("5d", snap.change_5d), ("20d", snap.change_20d)]:
        if val is not None:
            parts.append(f"{label}: {val:+.4f}")
    if snap.percentile_1y is not None:
        parts.append(f"pctl: {snap.percentile_1y:.0f}th")
    return "  |  ".join(parts)


def _contract_block(cm: ContractMetrics) -> str:
    """Build a text block for one contract."""
    lines = [
        f"  Contract: {cm.label} ({cm.tenor_type}) — {cm.ticker}",
        _fmt_snap("Price", cm.price),
        _fmt_snap("Futures Volume", cm.volume),
        _fmt_snap("Futures OI", cm.open_interest),
        _fmt_snap("ATM Vol", cm.atm_vol),
        _fmt_snap("25D RR", cm.vol_25d_rr),
        _fmt_snap("25D BF", cm.vol_25d_bf),
        _fmt_snap("10D RR", cm.vol_10d_rr),
        _fmt_snap("10D BF", cm.vol_10d_bf),
        _fmt_snap("Call OI", cm.call_oi),
        _fmt_snap("Put OI", cm.put_oi),
        _fmt_snap("Call Volume", cm.call_volume),
        _fmt_snap("Put Volume", cm.put_volume),
        _fmt_snap("P/C OI Ratio", cm.pc_oi_ratio),
    ]
    if cm.net_delta is not None:
        lines.append(f"  Net Delta: {cm.net_delta:.2f}  |  Net Gamma: {cm.net_gamma:.4f}  |  Net Vega: {cm.net_vega:.2f}")
    return "\n".join(lines)


def _build_instrument_context(im: InstrumentMetrics) -> str:
    """Build the full context block for one instrument."""
    header = f"=== {im.instrument} ({cfg.INSTRUMENTS[im.instrument].display_name}) ===\nUnit: {im.unit}\n"
    contract_blocks = "\n\n".join(_contract_block(c) for c in im.contracts)

    ts = im.vol_term_spread
    ts_line = ""
    if ts.current is not None:
        ts_line = f"\n  Vol Term Structure (front - back ATM): {ts.current:+.4f}"

    return header + contract_blocks + ts_line


def generate_executive_summary(
    all_metrics: dict[str, InstrumentMetrics],
    cross_asset: dict | None = None,
    section_context: str = "",
) -> str:
    """Generate a 4-6 sentence executive summary across all commodities."""

    if section_context:
        data_context = section_context
    else:
        data_blocks = [_build_instrument_context(im) for im in all_metrics.values()]
        data_context = "\n\n---\n\n".join(data_blocks)

    cross_section = ""
    if cross_asset:
        anomalies = cross_asset.get("anomalies", [])
        divergences = cross_asset.get("divergences", [])
        if anomalies:
            cross_section += "\n\nANOMALIES (extreme percentile moves):\n"
            cross_section += "\n".join(f"- {a['description']}" for a in anomalies)
        if divergences:
            cross_section += "\n\nDIVERGENCES:\n"
            cross_section += "\n".join(f"- {d['description']}" for d in divergences)

    prompt = (
        "Below is the latest futures and options data for 8 energy and metals commodities. "
        "Write an executive summary of 4 to 6 sentences highlighting the most notable "
        "changes across all commodities.  Cover BOTH futures (price moves, volume, "
        "open interest changes, curve shape) AND options (ATM vol, skew, put/call "
        "positioning).  Focus on the largest moves and any extreme percentile readings. "
        "Call out cross-market patterns and compare 1-day, 5-day, and 20-day changes "
        "where they tell different stories.\n\n"
        f"{data_context}"
        f"{cross_section}"
    )

    return _call_claude(prompt)


def generate_commodity_narrative(
    im: InstrumentMetrics,
    cross_asset: dict | None = None,
    section_context: str = "",
) -> str:
    """Generate a 3-5 sentence factual narrative for a single commodity."""

    if section_context:
        context = f"=== {im.instrument} ===\nUnit: {im.unit}\n\n{section_context}"
    else:
        context = _build_instrument_context(im)

    related = ""
    if cross_asset:
        for d in cross_asset.get("divergences", []):
            if im.instrument in d["pair"]:
                related += f"\nRelated divergence: {d['description']}"
        for a in cross_asset.get("anomalies", []):
            if a["instrument"] == im.instrument:
                related += f"\nAnomaly flag: {a['description']}"

    prompt = (
        f"Below is the latest futures and options data for {im.instrument}. "
        "Write 3 to 5 concise sentences summarising what changed across the "
        "contract curve.  Start with the most significant futures moves "
        "(price direction, volume, OI changes and what they imply about "
        "positioning).  Then cover options activity: ATM vol level and change, "
        "skew direction, butterfly, and vol term structure.  Note any "
        "contradictions between futures flow (OI/volume) and options positioning "
        "(put/call ratio, skew shift).  Cite specific numbers and flag any "
        "extreme percentile readings."
        f"\n\n{context}{related}"
    )

    return _call_claude(prompt)


def generate_cross_asset_insights(
    all_metrics: dict[str, InstrumentMetrics],
    cross_asset: dict,
) -> str:
    """Generate a paragraph on cross-market patterns and divergences."""
    anomalies = cross_asset.get("anomalies", [])
    divergences = cross_asset.get("divergences", [])
    corr_matrix = cross_asset.get("vol_correlation_matrix")

    parts = ["CROSS-ASSET DATA:"]

    if anomalies:
        parts.append("\nAnomalies:")
        for a in anomalies:
            parts.append(f"  - {a['description']}")

    if divergences:
        parts.append("\nDivergences:")
        for d in divergences:
            parts.append(f"  - {d['description']}")

    if corr_matrix is not None:
        parts.append(f"\nPrice return correlation matrix (20d):\n{corr_matrix.to_string()}")

    if not anomalies and not divergences:
        return "No notable cross-asset divergences or anomalies detected in today's data."

    prompt = (
        "Based on the cross-asset data below, write 2-4 sentences describing "
        "the most notable patterns, divergences, or unusual readings across "
        "the energy and metals complex.  Consider both futures signals (price "
        "moves, OI changes, volume extremes) and options signals (vol, skew, "
        "put/call ratios).  Be specific about which instruments are diverging "
        "and on which metrics.\n\n"
        + "\n".join(parts)
    )

    return _call_claude(prompt)


def _call_claude(user_prompt: str) -> str:
    """Call the Anthropic Claude API and return the text response."""
    client = anthropic.Anthropic()

    try:
        response = client.messages.create(
            model=cfg.CLAUDE_MODEL,
            max_tokens=cfg.CLAUDE_MAX_TOKENS,
            temperature=cfg.CLAUDE_TEMPERATURE,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_prompt}],
        )
        text = response.content[0].text
        logger.info("Claude response (%d chars)", len(text))
        return text.strip()
    except Exception:
        logger.exception("Claude API call failed")
        return "(Narrative generation failed — see logs for details.)"
