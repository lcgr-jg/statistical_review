"""
Metrics engine for the Energy Options Morning Brief.

Computes per-instrument, per-contract metrics with multi-horizon changes
and 1-year percentile ranks:

  Futures:   settlement price, volume, open interest (Bloomberg BDH)
  Options:   ATM vol, 25D RR, 25D BF, 10D RR, 10D BF,
             aggregate call/put OI & volume, P/C ratio
             (primary: Snowflake ICE MFT; fallback: Bloomberg moneyness)
  Greeks:    net delta, gamma, vega (from option chain)
  Surface:   vol term structure (front vs. back ATM)
  Context:   percentile ranks for ATM vol, skew, OI

Also provides CrossAssetAnalyzer for correlation and divergence detection.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field, asdict

import numpy as np
import pandas as pd

from . import config as cfg
from .bbg_tickers import ContractSpec
from .cache_manager import (
    compute_change_from_cache,
    compute_percentile_rank,
    load_history,
    save_daily_snapshot,
)
from .snowflake_options import ICEOptionsResult, ICEVolMetrics

logger = logging.getLogger(__name__)


# ======================================================================
# Data classes
# ======================================================================

@dataclass
class MetricSnapshot:
    """A single metric value with multi-horizon changes and percentile."""
    current: float | None = None
    change_1d: float | None = None
    change_5d: float | None = None
    change_20d: float | None = None
    percentile_1y: float | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ContractMetrics:
    """Metrics for a single futures/options contract."""
    ticker: str = ""
    label: str = ""           # e.g. "May26"
    tenor_type: str = ""      # monthly / quarterly / calendar

    price: MetricSnapshot = field(default_factory=MetricSnapshot)
    volume: MetricSnapshot = field(default_factory=MetricSnapshot)
    open_interest: MetricSnapshot = field(default_factory=MetricSnapshot)

    atm_vol: MetricSnapshot = field(default_factory=MetricSnapshot)
    vol_25d_rr: MetricSnapshot = field(default_factory=MetricSnapshot)
    vol_25d_bf: MetricSnapshot = field(default_factory=MetricSnapshot)
    vol_10d_rr: MetricSnapshot = field(default_factory=MetricSnapshot)
    vol_10d_bf: MetricSnapshot = field(default_factory=MetricSnapshot)

    call_oi: MetricSnapshot = field(default_factory=MetricSnapshot)
    put_oi: MetricSnapshot = field(default_factory=MetricSnapshot)
    call_volume: MetricSnapshot = field(default_factory=MetricSnapshot)
    put_volume: MetricSnapshot = field(default_factory=MetricSnapshot)
    pc_oi_ratio: MetricSnapshot = field(default_factory=MetricSnapshot)

    vol_source: str = ""  # "chain" if ATM vol from option chain, "mny30d" if from moneyness

    net_delta: float | None = None
    net_gamma: float | None = None
    net_vega: float | None = None

    oi_by_strike: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


@dataclass
class InstrumentMetrics:
    """All metrics for a single instrument across its contract depth."""
    instrument: str = ""
    unit: str = ""
    trade_date: str = ""
    contracts: list[ContractMetrics] = field(default_factory=list)

    # Term structure: front ATM vol minus back ATM vol
    vol_term_spread: MetricSnapshot = field(default_factory=MetricSnapshot)

    # Time series for charting (from BDH history, front contract only)
    price_series: list[dict] = field(default_factory=list)
    atm_vol_series: list[dict] = field(default_factory=list)
    skew_series: list[dict] = field(default_factory=list)
    oi_series: list[dict] = field(default_factory=list)

    @property
    def front(self) -> ContractMetrics | None:
        return self.contracts[0] if self.contracts else None

    def to_dict(self) -> dict:
        return {
            "instrument": self.instrument,
            "unit": self.unit,
            "trade_date": self.trade_date,
            "vol_term_spread": self.vol_term_spread.to_dict(),
            "contracts": [c.to_dict() for c in self.contracts],
            "price_series": self.price_series,
            "atm_vol_series": self.atm_vol_series,
            "skew_series": self.skew_series,
            "oi_series": self.oi_series,
        }


# ======================================================================
# Helpers
# ======================================================================

def _chain_vol_at_delta(
    sub: pd.DataFrame,
    target_delta: float,
    pc: str,
) -> float | None:
    """Find the option in *sub* closest to *target_delta* and return its IV.

    Args:
        sub: option chain rows for one underlying contract
        target_delta: absolute delta level (e.g. 0.50 for ATM, 0.25 for 25D)
        pc: "C" for calls, "P" for puts
    """
    if "OPT_DELTA" not in sub.columns or "OPT_IMPLIED_VOLATILITY_MID" not in sub.columns:
        return None
    filtered = sub[
        (sub["OPT_PUT_CALL"] == pc)
        & sub["OPT_DELTA"].notna()
        & sub["OPT_IMPLIED_VOLATILITY_MID"].notna()
    ].copy()
    if filtered.empty:
        return None
    if pc == "C":
        filtered["_dist"] = (filtered["OPT_DELTA"] - target_delta).abs()
    else:
        filtered["_dist"] = (filtered["OPT_DELTA"].abs() - target_delta).abs()
    closest = filtered.loc[filtered["_dist"].idxmin()]
    return closest["OPT_IMPLIED_VOLATILITY_MID"]


def _safe(v) -> float | None:
    if v is None:
        return None
    try:
        f = float(v)
        return None if np.isnan(f) else round(f, 6)
    except (TypeError, ValueError):
        return None


def _build_snapshot_from_bdh(
    series: pd.Series,
    inst_key: str,
    ticker: str,
    field_name: str,
) -> MetricSnapshot:
    """
    Build a MetricSnapshot from a BDH time-series with changes computed
    from the series itself (not cache), for futures data where we have
    the full historical series.
    """
    series = series.dropna().sort_index()
    if series.empty:
        return MetricSnapshot()

    current = _safe(series.iloc[-1])
    dates = series.index.tolist()

    def _lookback(n: int) -> float | None:
        if len(dates) <= n:
            return _safe(series.iloc[0])
        return _safe(series.iloc[-(n + 1)])

    prev_1d = _lookback(1)
    prev_5d = _lookback(5)
    prev_20d = _lookback(20)

    def _diff(a, b):
        if a is None or b is None:
            return None
        return round(a - b, 6)

    # Percentile from full series
    pct = compute_percentile_rank(current, series)

    return MetricSnapshot(
        current=current,
        change_1d=_diff(current, prev_1d),
        change_5d=_diff(current, prev_5d),
        change_20d=_diff(current, prev_20d),
        percentile_1y=pct,
    )


def _build_snapshot_from_bdp(
    value: float | None,
    inst_key: str,
    ticker: str,
    field_name: str,
) -> MetricSnapshot:
    """
    Build a MetricSnapshot from a single BDP value, using the snapshot
    cache for historical changes and percentile.
    """
    current = _safe(value)
    history = load_history(inst_key)

    change_1d = compute_change_from_cache(inst_key, ticker, field_name, current, 1)
    change_5d = compute_change_from_cache(inst_key, ticker, field_name, current, 5)
    change_20d = compute_change_from_cache(inst_key, ticker, field_name, current, 20)

    pct = None
    if not history.empty and field_name in history.columns and ticker in history.index.values:
        hist_vals = history.loc[history.index == ticker, field_name]
        pct = compute_percentile_rank(current, hist_vals)

    return MetricSnapshot(
        current=current,
        change_1d=change_1d,
        change_5d=change_5d,
        change_20d=change_20d,
        percentile_1y=pct,
    )


# ======================================================================
# MetricsEngine
# ======================================================================

class MetricsEngine:
    """Computes all metrics for every instrument / contract."""

    def compute_all(
        self,
        contracts: dict[str, list[ContractSpec]],
        futures_hist: dict[str, pd.DataFrame],
        vol_surface: dict[str, pd.DataFrame],
        option_chains: dict[str, pd.DataFrame],
        ice_options: dict[str, ICEOptionsResult] | None = None,
    ) -> dict[str, InstrumentMetrics]:
        results: dict[str, InstrumentMetrics] = {}
        ice_options = ice_options or {}

        for inst_key, specs in contracts.items():
            logger.info("Computing metrics for %s (%d contracts)...", inst_key, len(specs))
            inst_cfg = cfg.INSTRUMENTS[inst_key]
            ice_result = ice_options.get(inst_key)
            use_ice = inst_cfg.has_ice_options and ice_result is not None and bool(ice_result.latest_metrics)

            im = InstrumentMetrics(
                instrument=inst_key,
                unit=inst_cfg.unit,
                trade_date=pd.Timestamp.now().strftime("%Y-%m-%d"),
            )

            futs_df = futures_hist.get(inst_key, pd.DataFrame())
            vol_df = vol_surface.get(inst_key, pd.DataFrame())
            chain_df = option_chains.get(inst_key, pd.DataFrame())

            if not vol_df.empty:
                save_daily_snapshot(inst_key, vol_df)

            for spec in specs:
                if use_ice:
                    cm = self._compute_contract_ice(
                        inst_key, spec, futs_df, ice_result,
                    )
                else:
                    cm = self._compute_contract(
                        inst_key, spec, futs_df, vol_df, chain_df,
                    )
                im.contracts.append(cm)

            # Term structure: front ATM minus back ATM
            if len(im.contracts) >= 2:
                front_atm = im.contracts[0].atm_vol.current
                back_atm = im.contracts[-1].atm_vol.current
                if front_atm is not None and back_atm is not None:
                    spread = round(front_atm - back_atm, 4)
                    im.vol_term_spread = MetricSnapshot(current=spread)

            # Build time series from BDH for charting (front contract)
            if specs and not futs_df.empty:
                front_ticker = specs[0].ticker
                im.price_series = self._extract_series(futs_df, front_ticker, "PX_LAST", 90)
                im.oi_series = self._extract_series(futs_df, front_ticker, "OPEN_INT", 90)

            # Build ATM vol / skew time series from ICE historical data
            front_label = specs[0].label if specs else None
            if use_ice and ice_result is not None and front_label:
                hist_df = ice_result.historical_metrics.get(front_label)
                if hist_df is not None and not hist_df.empty:
                    logger.info(
                        "  %s: ICE history for %s — %d rows, cols=%s",
                        inst_key, front_label, len(hist_df), list(hist_df.columns),
                    )
                    if "atm_vol" in hist_df.columns:
                        im.atm_vol_series = self._extract_ice_series(hist_df, "atm_vol", 90)
                        logger.info("    atm_vol_series: %d points", len(im.atm_vol_series))
                    if "vol_25d_rr" in hist_df.columns:
                        im.skew_series = self._extract_ice_series(hist_df, "vol_25d_rr", 90)
                else:
                    avail = list(ice_result.historical_metrics.keys()) if ice_result else []
                    logger.warning(
                        "  %s: no ICE history for front label '%s' (available: %s)",
                        inst_key, front_label, avail[:10],
                    )

            results[inst_key] = im

        return results

    def _compute_contract(
        self,
        inst_key: str,
        spec: ContractSpec,
        futs_df: pd.DataFrame,
        vol_df: pd.DataFrame,
        chain_df: pd.DataFrame,
    ) -> ContractMetrics:
        cm = ContractMetrics(
            ticker=spec.ticker,
            label=spec.label,
            tenor_type=spec.tenor_type,
        )

        # --- Futures from BDH ---
        px_col = f"{spec.ticker}_PX_LAST"
        vol_col = f"{spec.ticker}_VOLUME"
        oi_col = f"{spec.ticker}_OPEN_INT"

        if px_col in futs_df.columns:
            cm.price = _build_snapshot_from_bdh(
                futs_df[px_col], inst_key, spec.ticker, "PX_LAST",
            )
        if vol_col in futs_df.columns:
            cm.volume = _build_snapshot_from_bdh(
                futs_df[vol_col], inst_key, spec.ticker, "VOLUME",
            )
        if oi_col in futs_df.columns:
            cm.open_interest = _build_snapshot_from_bdh(
                futs_df[oi_col], inst_key, spec.ticker, "OPEN_INT",
            )

        # --- Vol surface from BDP (moneyness-based fields) ---
        if not vol_df.empty and spec.ticker in vol_df.index:
            row = vol_df.loc[spec.ticker]

            atm_val = _safe(row.get("30DAY_IMPVOL_100.0%MNY_DF"))
            cm.atm_vol = _build_snapshot_from_bdp(
                atm_val, inst_key, spec.ticker, "atm_vol",
            )
            if atm_val is not None:
                cm.vol_source = "mny30d"

            # 25D RR ≈ 105% moneyness − 95% moneyness (call wing − put wing)
            v105 = _safe(row.get("30DAY_IMPVOL_105.0%MNY_DF"))
            v95 = _safe(row.get("30DAY_IMPVOL_95.0%MNY_DF"))
            if v105 is not None and v95 is not None:
                rr25 = round(v105 - v95, 4)
                cm.vol_25d_rr = _build_snapshot_from_bdp(
                    rr25, inst_key, spec.ticker, "vol_25d_rr",
                )
                if atm_val is not None:
                    bf25 = round((v105 + v95) / 2.0 - atm_val, 4)
                    cm.vol_25d_bf = _build_snapshot_from_bdp(
                        bf25, inst_key, spec.ticker, "vol_25d_bf",
                    )

            # 10D RR ≈ 110% moneyness − 90% moneyness
            v110 = _safe(row.get("30DAY_IMPVOL_110.0%MNY_DF"))
            v90 = _safe(row.get("30DAY_IMPVOL_90.0%MNY_DF"))
            if v110 is not None and v90 is not None:
                rr10 = round(v110 - v90, 4)
                cm.vol_10d_rr = _build_snapshot_from_bdp(
                    rr10, inst_key, spec.ticker, "vol_10d_rr",
                )
                if atm_val is not None:
                    bf10 = round((v110 + v90) / 2.0 - atm_val, 4)
                    cm.vol_10d_bf = _build_snapshot_from_bdp(
                        bf10, inst_key, spec.ticker, "vol_10d_bf",
                    )

        # --- Option chain: per-expiry vols, greeks, aggregate OI ---
        if not chain_df.empty and spec.ticker in chain_df.get("underlying_ticker", pd.Series()).values:
            sub = chain_df[chain_df["underlying_ticker"] == spec.ticker]

            # Check days-to-expiry: skip chain vol override for near-expiry
            # options (DTE < 7) where IV becomes extremely noisy.
            min_dte_for_chain_vol = 7
            use_chain_vol = True
            if "OPT_EXPIRE_DT" in sub.columns:
                expire_vals = sub["OPT_EXPIRE_DT"].dropna()
                if not expire_vals.empty:
                    try:
                        sample_exp = pd.Timestamp(expire_vals.iloc[0])
                        dte = (sample_exp - pd.Timestamp.now()).days
                        if dte < min_dte_for_chain_vol:
                            logger.info(
                                "  %s: DTE=%d < %d, skipping chain vol override",
                                spec.ticker, dte, min_dte_for_chain_vol,
                            )
                            use_chain_vol = False
                    except (ValueError, TypeError):
                        pass

            if use_chain_vol:
                # Per-expiry vols from near-delta options (overrides moneyness vols)
                chain_atm = _safe(_chain_vol_at_delta(sub, 0.50, "C"))
                if chain_atm is not None:
                    cm.atm_vol = _build_snapshot_from_bdp(
                        chain_atm, inst_key, spec.ticker, "atm_vol",
                    )
                    cm.vol_source = "chain"

                chain_25c = _safe(_chain_vol_at_delta(sub, 0.25, "C"))
                chain_25p = _safe(_chain_vol_at_delta(sub, 0.25, "P"))
                if chain_25c is not None and chain_25p is not None:
                    rr25 = round(chain_25c - chain_25p, 4)
                    cm.vol_25d_rr = _build_snapshot_from_bdp(
                        rr25, inst_key, spec.ticker, "vol_25d_rr",
                    )
                    if chain_atm is not None:
                        bf25 = round((chain_25c + chain_25p) / 2.0 - chain_atm, 4)
                        cm.vol_25d_bf = _build_snapshot_from_bdp(
                            bf25, inst_key, spec.ticker, "vol_25d_bf",
                        )

                chain_10c = _safe(_chain_vol_at_delta(sub, 0.10, "C"))
                chain_10p = _safe(_chain_vol_at_delta(sub, 0.10, "P"))
                if chain_10c is not None and chain_10p is not None:
                    rr10 = round(chain_10c - chain_10p, 4)
                    cm.vol_10d_rr = _build_snapshot_from_bdp(
                        rr10, inst_key, spec.ticker, "vol_10d_rr",
                    )
                    if chain_atm is not None:
                        bf10 = round((chain_10c + chain_10p) / 2.0 - chain_atm, 4)
                        cm.vol_10d_bf = _build_snapshot_from_bdp(
                            bf10, inst_key, spec.ticker, "vol_10d_bf",
                        )

            cm.net_delta = _safe(sub.get("OPT_DELTA", pd.Series()).sum())
            cm.net_gamma = _safe(sub.get("OPT_GAMMA", pd.Series()).sum())
            cm.net_vega = _safe(sub.get("OPT_VEGA", pd.Series()).sum())

            # Aggregate OI and volume by put/call (from chain, not BDP)
            if "OPT_PUT_CALL" in sub.columns and "OPEN_INT" in sub.columns:
                calls = sub[sub["OPT_PUT_CALL"] == "C"]
                puts = sub[sub["OPT_PUT_CALL"] == "P"]
                call_oi_total = _safe(calls["OPEN_INT"].sum()) if not calls.empty else None
                put_oi_total = _safe(puts["OPEN_INT"].sum()) if not puts.empty else None
                cm.call_oi = MetricSnapshot(current=call_oi_total)
                cm.put_oi = MetricSnapshot(current=put_oi_total)
                if call_oi_total is not None and call_oi_total > 0:
                    cm.pc_oi_ratio = MetricSnapshot(
                        current=_safe((put_oi_total or 0) / call_oi_total),
                    )

            if "OPT_PUT_CALL" in sub.columns and "VOLUME" in sub.columns:
                calls = sub[sub["OPT_PUT_CALL"] == "C"]
                puts = sub[sub["OPT_PUT_CALL"] == "P"]
                cm.call_volume = MetricSnapshot(
                    current=_safe(calls["VOLUME"].sum()) if not calls.empty else None,
                )
                cm.put_volume = MetricSnapshot(
                    current=_safe(puts["VOLUME"].sum()) if not puts.empty else None,
                )

            # OI by strike for charting
            if "OPT_STRIKE_PX" in sub.columns and "OPEN_INT" in sub.columns:
                oi_agg = sub.groupby(["OPT_STRIKE_PX", "OPT_PUT_CALL"])["OPEN_INT"].sum()
                for (strike, pc), oi_val in oi_agg.items():
                    cm.oi_by_strike.append({
                        "strike": _safe(strike),
                        "put_call": str(pc),
                        "oi": _safe(oi_val),
                    })

        return cm

    def _compute_contract_ice(
        self,
        inst_key: str,
        spec: ContractSpec,
        futs_df: pd.DataFrame,
        ice_result: ICEOptionsResult,
    ) -> ContractMetrics:
        """Compute metrics using Snowflake ICE MFT as primary options source."""
        cm = ContractMetrics(
            ticker=spec.ticker,
            label=spec.label,
            tenor_type=spec.tenor_type,
        )

        # --- Futures from BDH (same as Bloomberg path) ---
        px_col = f"{spec.ticker}_PX_LAST"
        vol_col = f"{spec.ticker}_VOLUME"
        oi_col = f"{spec.ticker}_OPEN_INT"

        if px_col in futs_df.columns:
            cm.price = _build_snapshot_from_bdh(
                futs_df[px_col], inst_key, spec.ticker, "PX_LAST",
            )
        if vol_col in futs_df.columns:
            cm.volume = _build_snapshot_from_bdh(
                futs_df[vol_col], inst_key, spec.ticker, "VOLUME",
            )
        if oi_col in futs_df.columns:
            cm.open_interest = _build_snapshot_from_bdh(
                futs_df[oi_col], inst_key, spec.ticker, "OPEN_INT",
            )

        # --- Options from Snowflake ICE MFT ---
        vm = ice_result.latest_metrics.get(spec.label)
        hist_df = ice_result.historical_metrics.get(spec.label)

        if vm is not None:
            cm.vol_source = "ice_mft"

            cm.atm_vol = self._build_snapshot_from_ice_history(
                vm.atm_vol, hist_df, "atm_vol", inst_key, spec.ticker,
            )
            cm.vol_25d_rr = self._build_snapshot_from_ice_history(
                vm.vol_25d_rr, hist_df, "vol_25d_rr", inst_key, spec.ticker,
            )
            cm.vol_25d_bf = self._build_snapshot_from_ice_history(
                vm.vol_25d_bf, hist_df, "vol_25d_bf", inst_key, spec.ticker,
            )
            cm.vol_10d_rr = self._build_snapshot_from_ice_history(
                vm.vol_10d_rr, hist_df, "vol_10d_rr", inst_key, spec.ticker,
            )
            cm.vol_10d_bf = self._build_snapshot_from_ice_history(
                vm.vol_10d_bf, hist_df, "vol_10d_bf", inst_key, spec.ticker,
            )

            cm.call_oi = MetricSnapshot(current=_safe(vm.call_oi))
            cm.put_oi = MetricSnapshot(current=_safe(vm.put_oi))
            if vm.call_oi and vm.call_oi > 0 and vm.put_oi is not None:
                cm.pc_oi_ratio = MetricSnapshot(
                    current=_safe(vm.put_oi / vm.call_oi),
                )
            if vm.total_volume is not None:
                cm.call_volume = MetricSnapshot(current=_safe(vm.total_volume))

            # Historical OI changes from Snowflake time series
            if hist_df is not None and "call_oi" in hist_df.columns:
                total_oi_series = (
                    hist_df["call_oi"].fillna(0) + hist_df["put_oi"].fillna(0)
                )
                if len(total_oi_series) > 1:
                    cm.call_oi = self._build_snapshot_from_ice_history(
                        vm.call_oi, hist_df, "call_oi", inst_key, spec.ticker,
                    )
                    cm.put_oi = self._build_snapshot_from_ice_history(
                        vm.put_oi, hist_df, "put_oi", inst_key, spec.ticker,
                    )

        # OI by strike for charting
        oi_strike_df = ice_result.oi_by_strike.get(spec.label)
        if oi_strike_df is not None and not oi_strike_df.empty:
            for _, row in oi_strike_df.iterrows():
                cm.oi_by_strike.append({
                    "strike": _safe(row.get("STRIKE")),
                    "put_call": str(row.get("PUT_CALL", "")),
                    "oi": _safe(row.get("OPEN_INTEREST", 0)),
                })

        return cm

    @staticmethod
    def _build_snapshot_from_ice_history(
        current_val: float | None,
        hist_df: pd.DataFrame | None,
        col_name: str,
        inst_key: str,
        ticker: str,
    ) -> MetricSnapshot:
        """Build a MetricSnapshot from ICE Snowflake historical time series."""
        current = _safe(current_val)

        if hist_df is None or hist_df.empty or col_name not in hist_df.columns:
            return MetricSnapshot(current=current)

        series = hist_df[col_name].dropna().sort_index()
        if series.empty:
            return MetricSnapshot(current=current)

        def _lookback(n: int) -> float | None:
            if len(series) <= n:
                return _safe(series.iloc[0])
            return _safe(series.iloc[-(n + 1)])

        prev_1d = _lookback(1)
        prev_5d = _lookback(5)
        prev_20d = _lookback(20)

        def _diff(a, b):
            if a is None or b is None:
                return None
            return round(a - b, 6)

        pct = compute_percentile_rank(current, series)

        return MetricSnapshot(
            current=current,
            change_1d=_diff(current, prev_1d),
            change_5d=_diff(current, prev_5d),
            change_20d=_diff(current, prev_20d),
            percentile_1y=pct,
        )

    @staticmethod
    def _extract_series(
        df: pd.DataFrame, ticker: str, field: str, n_days: int,
    ) -> list[dict]:
        col = f"{ticker}_{field}"
        if col not in df.columns:
            return []
        s = df[col].dropna().sort_index().tail(n_days)
        return [
            {"date": str(d.date()) if hasattr(d, "date") else str(d), "value": _safe(v)}
            for d, v in s.items()
        ]

    @staticmethod
    def _extract_ice_series(
        hist_df: pd.DataFrame, col_name: str, n_days: int,
    ) -> list[dict]:
        """Extract a time series from ICE Snowflake historical DataFrame."""
        if col_name not in hist_df.columns:
            return []
        s = hist_df[col_name].dropna().sort_index().tail(n_days)
        return [
            {"date": str(d.date()) if hasattr(d, "date") else str(d), "value": _safe(v)}
            for d, v in s.items()
        ]


# ======================================================================
# CrossAssetAnalyzer
# ======================================================================

class CrossAssetAnalyzer:
    """Identifies cross-commodity correlations and unusual moves."""

    def analyze(
        self,
        all_metrics: dict[str, InstrumentMetrics],
        futures_hist: dict[str, pd.DataFrame],
    ) -> dict:
        """
        Returns a dict with:
            vol_correlation_matrix:  DataFrame of 20d ATM vol change correlations
            anomalies:               list of {instrument, metric, description}
            divergences:             list of {pair, description}
        """
        result = {
            "vol_correlation_matrix": None,
            "anomalies": [],
            "divergences": [],
        }

        # --- Vol correlation matrix ---
        vol_changes: dict[str, pd.Series] = {}
        for inst_key, im in all_metrics.items():
            if im.price_series:
                vals = pd.Series(
                    {d["date"]: d["value"] for d in im.price_series if d["value"] is not None}
                )
                if len(vals) > 20:
                    vol_changes[inst_key] = vals.pct_change().dropna()

        if len(vol_changes) >= 2:
            combined = pd.DataFrame(vol_changes).dropna()
            if len(combined) >= 10:
                result["vol_correlation_matrix"] = combined.corr().round(3)

        # --- Anomaly detection (>2 sigma moves) ---
        for inst_key, im in all_metrics.items():
            front = im.front
            if front is None:
                continue
            for metric_name, snap in [
                ("ATM Vol", front.atm_vol),
                ("25D Risk Reversal", front.vol_25d_rr),
                ("Open Interest", front.open_interest),
                ("Volume", front.volume),
            ]:
                if snap.change_1d is not None and snap.percentile_1y is not None:
                    if snap.percentile_1y >= 95 or snap.percentile_1y <= 5:
                        result["anomalies"].append({
                            "instrument": inst_key,
                            "metric": metric_name,
                            "value": snap.current,
                            "change_1d": snap.change_1d,
                            "percentile": snap.percentile_1y,
                            "description": (
                                f"{inst_key} {metric_name} at {snap.current:.4f} "
                                f"({snap.percentile_1y:.0f}th percentile, "
                                f"1d change {snap.change_1d:+.4f})"
                            ),
                        })

        # --- Divergence detection ---
        inst_list = list(all_metrics.keys())
        for i, a_key in enumerate(inst_list):
            for b_key in inst_list[i + 1:]:
                a_front = all_metrics[a_key].front
                b_front = all_metrics[b_key].front
                if a_front is None or b_front is None:
                    continue

                a_vol_chg = a_front.atm_vol.change_1d
                b_vol_chg = b_front.atm_vol.change_1d
                if a_vol_chg is not None and b_vol_chg is not None:
                    if abs(a_vol_chg) > 0.5 and abs(b_vol_chg) > 0.5:
                        if (a_vol_chg > 0) != (b_vol_chg > 0):
                            result["divergences"].append({
                                "pair": f"{a_key} / {b_key}",
                                "description": (
                                    f"Vol divergence: {a_key} ATM vol "
                                    f"{a_vol_chg:+.2f}pts vs {b_key} "
                                    f"{b_vol_chg:+.2f}pts"
                                ),
                            })

        logger.info(
            "Cross-asset: %d anomalies, %d divergences",
            len(result["anomalies"]),
            len(result["divergences"]),
        )
        return result
