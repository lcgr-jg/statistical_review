"""
Orchestrator for the Energy Options Morning Brief.

Pipeline:
  1.  Generate contract tickers (front 3M, 3Q, Cal for 8 instruments)
  2a. Fetch Bloomberg BDH futures history (all instruments)
  2b. Fetch Snowflake ICE MFT options data (ICE instruments only)
  2c. Fetch Bloomberg BDP vol surface snapshot (non-ICE fallback)
  2d. Fetch Bloomberg BDS option chains (non-ICE fallback)
  2e. Prune expired/illiquid contracts
  3.  Compute per-contract metrics with percentile ranks
  4.  Run cross-asset analysis (correlations, anomalies, divergences)
  5.  Run modular report sections (vol surface, skew, term structure, etc.)
  6.  Generate LLM narratives using section-provided context
  7.  Generate legacy charts (for dashboard)
  8.  Save dashboard cache
  9.  Render and send HTML email
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from pathlib import Path

import snowflake.connector
_original_connect = snowflake.connector.connect
def _insecure_connect(*args, **kwargs):
    kwargs['insecure_mode'] = True
    return _original_connect(*args, **kwargs)
snowflake.connector.connect = _insecure_connect

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent / ".env")

from .bbg_tickers import all_contract_tickers
from .data_fetcher import BloombergDataFetcher
from .snowflake_options import ICEOptionsDataFetcher
from .analytics import MetricsEngine, CrossAssetAnalyzer
from .narrator import (
    generate_executive_summary,
    generate_commodity_narrative,
    generate_cross_asset_insights,
)
from .charts import generate_all_charts
from .email_renderer import render_html, send_morning_brief
from .dashboard import save_cache
from .cache_manager import clear_history_cache, prune_old_snapshots
from .sections import ALL_SECTIONS, DataBlock, PipelineData, SectionResult
from . import config as cfg

logger = logging.getLogger(__name__)


def run_morning_brief(
    recipients: str | None = None,
    dry_run: bool = False,
    on_server: bool = True,
) -> dict:
    """
    Run the full morning brief pipeline.

    Args:
        recipients: Comma-separated email addresses
        dry_run:    If True, skip sending email
        on_server:  BBGQuery p_on_server flag (True = BPIPE, False = Desktop)

    Returns:
        Dict with pipeline metadata for Dagster
    """
    start = datetime.now()
    logger.info("=" * 70)
    logger.info("Starting Energy Options Morning Brief (Bloomberg BPIPE)")
    logger.info("=" * 70)

    clear_history_cache()

    # 1. Generate contract tickers
    logger.info("[1/9] Generating contract tickers...")
    contracts = all_contract_tickers()
    total_contracts = sum(len(v) for v in contracts.values())
    logger.info("  %d instruments, %d contracts total", len(contracts), total_contracts)

    # 2. Fetch data
    logger.info("[2/9] Fetching data...")
    fetcher = BloombergDataFetcher(on_server=on_server)

    logger.info("  [2a] BDH futures history (all instruments)...")
    futures_hist = fetcher.fetch_futures_history(contracts)

    # 2b. Snowflake ICE options (primary for ICE instruments)
    logger.info("  [2b] Snowflake ICE MFT options (ICE instruments)...")
    try:
        ice_fetcher = ICEOptionsDataFetcher()
        ice_options = ice_fetcher.fetch_all(contracts, lookback_days=120)
        ice_inst_count = sum(1 for v in ice_options.values() if v.latest_metrics)
        logger.info("  Snowflake: %d instruments with data", ice_inst_count)
    except Exception:
        logger.exception("Snowflake ICE options fetch failed — falling back to Bloomberg")
        ice_options = {}

    # 2c. BDP vol surface (non-ICE instruments only, as fallback)
    non_ice_contracts = {
        k: v for k, v in contracts.items()
        if not cfg.INSTRUMENTS[k].has_ice_options
    }
    logger.info("  [2c] BDP vol surface (non-ICE: %s)...", list(non_ice_contracts.keys()) or "none")
    vol_surface = fetcher.fetch_vol_surface_snapshot(non_ice_contracts) if non_ice_contracts else {}

    # 2d. BDS option chains (non-ICE instruments only)
    logger.info("  [2d] BDS option chains (non-ICE)...")
    option_chains = fetcher.fetch_option_chains(non_ice_contracts) if non_ice_contracts else {}

    # 2e. Prune expired/illiquid contracts (insufficient BDH data)
    min_rows = 20
    for inst_key, specs in list(contracts.items()):
        futs_df = futures_hist.get(inst_key)
        if futs_df is None or futs_df.empty:
            continue
        live_specs = []
        for s in specs:
            px_col = f"{s.ticker}_PX_LAST"
            n_rows = futs_df[px_col].dropna().shape[0] if px_col in futs_df.columns else 0
            if n_rows >= min_rows:
                live_specs.append(s)
            else:
                logger.warning(
                    "  Pruning contract %s (%s) — only %d rows",
                    s.ticker, s.label, n_rows,
                )
        contracts[inst_key] = live_specs

    # 3. Compute metrics
    logger.info("[3/9] Computing metrics...")
    engine = MetricsEngine()
    all_metrics = engine.compute_all(
        contracts, futures_hist, vol_surface, option_chains,
        ice_options=ice_options,
    )
    logger.info("  Computed metrics for %d instruments", len(all_metrics))

    # 4. Cross-asset analysis
    logger.info("[4/9] Running cross-asset analysis...")
    xa = CrossAssetAnalyzer()
    cross_asset = xa.analyze(all_metrics, futures_hist)

    # 5. Run modular report sections
    logger.info("[5/9] Computing report sections...")
    pipeline_data = PipelineData(
        contracts=contracts,
        futures_hist=futures_hist,
        vol_surface=vol_surface,
        option_chains=option_chains,
        all_metrics=all_metrics,
        cross_asset=cross_asset,
    )

    section_results: dict[str, dict[str, SectionResult]] = {}
    global_results: dict[str, SectionResult] = {}

    for section in ALL_SECTIONS:
        logger.info("  Section: %s (order=%d, global=%s)",
                     section.name, section.order, not section.is_per_instrument)
        results = section.compute(pipeline_data)

        if section.is_per_instrument:
            section_results[section.name] = results
        else:
            sr = results.get("__global__")
            if sr:
                global_results[section.name] = sr

    # 6. Generate LLM narratives using section-provided context
    logger.info("[6/9] Generating AI narratives...")

    all_section_context = _build_section_context(
        all_metrics, section_results, global_results,
    )

    logger.info("  Executive summary...")
    exec_summary = generate_executive_summary(
        all_metrics, cross_asset, section_context=all_section_context,
    )
    logger.info("  Summary: %d chars", len(exec_summary))

    logger.info("  Per-commodity narratives...")
    narratives: dict[str, str] = {}
    for name, im in all_metrics.items():
        logger.info("    Narrating %s...", name)
        inst_context = _build_instrument_section_context(name, section_results)
        narratives[name] = generate_commodity_narrative(
            im, cross_asset, section_context=inst_context,
        )

    logger.info("  Cross-asset insights...")
    cross_asset_narrative = generate_cross_asset_insights(all_metrics, cross_asset)

    # 7. Generate legacy charts (for dashboard compatibility)
    logger.info("[7/9] Generating dashboard charts...")
    all_charts = generate_all_charts(all_metrics)

    # 8. Save dashboard cache
    logger.info("[8/9] Saving dashboard cache...")
    save_cache(all_metrics, narratives, exec_summary, cross_asset_narrative)

    prune_old_snapshots()

    # 9. Render and send email
    logger.info("[9/9] Rendering email...")
    html_body = render_html(
        exec_summary, cross_asset_narrative,
        all_metrics, narratives,
        section_results, global_results,
    )

    email_sent = False
    if recipients:
        email_sent = send_morning_brief(html_body, recipients, dry_run=dry_run)
    else:
        logger.info("No recipients specified — skipping email")

    elapsed = (datetime.now() - start).total_seconds()
    logger.info("=" * 70)
    logger.info("Morning Brief complete in %.1fs", elapsed)
    logger.info("=" * 70)

    return {
        "status": "success",
        "instruments": list(all_metrics.keys()),
        "num_instruments": len(all_metrics),
        "total_contracts": total_contracts,
        "email_sent": email_sent,
        "recipients": recipients or "",
        "dry_run": dry_run,
        "elapsed_seconds": round(elapsed, 1),
        "generated_at": datetime.now().isoformat(),
        "data_source": "snowflake_ice_mft+bloomberg_bpipe",
    }


def _collect_all_blocks(
    section_results: dict[str, dict[str, SectionResult]],
    global_results: dict[str, SectionResult],
) -> list[DataBlock]:
    """Collect all DataBlocks from per-instrument and global sections."""
    blocks: list[DataBlock] = []
    for sec_name, per_inst in section_results.items():
        for inst_key, sr in per_inst.items():
            blocks.extend(sr.blocks)
    for sec_name, sr in global_results.items():
        blocks.extend(sr.blocks)
    return blocks


def _build_section_context(
    all_metrics: dict,
    section_results: dict[str, dict[str, SectionResult]],
    global_results: dict[str, SectionResult],
) -> str:
    """
    Build LLM context grouped by *theme* rather than by instrument.

    Ordering follows the narrative flow defined in PROMPT_THEMES:
    prices → vol surface → vol term structure → positioning → cross-asset.

    Within each theme, blocks are ordered by product (instrument key).
    This lets the LLM compare the same metric across products in one
    contiguous section.
    """
    blocks = _collect_all_blocks(section_results, global_results)
    if not blocks:
        return _build_section_context_legacy(all_metrics, section_results, global_results)

    theme_order = {t: i for i, t in enumerate(cfg.PROMPT_THEMES)}
    product_order = {k: i for i, k in enumerate(cfg.INSTRUMENTS)}

    blocks.sort(key=lambda b: (
        theme_order.get(b.theme, 99),
        product_order.get(b.product, 99),
    ))

    parts: list[str] = []
    current_theme = ""
    theme_titles = {
        "prices": "MARKET PRICES",
        "vol_surface": "OPTIONS VOL SURFACE & SKEW",
        "vol_term_structure": "VOL TERM STRUCTURE",
        "positioning": "VOLUME & OI POSITIONING",
        "cross_asset": "CROSS-ASSET ANALYSIS",
    }

    for block in blocks:
        if block.theme != current_theme:
            current_theme = block.theme
            heading = theme_titles.get(current_theme, current_theme.upper())
            parts.append(f"\n# {heading}\n")

        src_label = f"[source: {block.source}, {block.source_type}]" if block.source else ""
        parts.append(f"## {block.title} {src_label}\n")
        parts.append(block.content)
        parts.append("")

    return "\n".join(parts)


def _build_section_context_legacy(
    all_metrics: dict,
    section_results: dict[str, dict[str, SectionResult]],
    global_results: dict[str, SectionResult],
) -> str:
    """Fallback: instrument-first ordering using llm_context strings."""
    parts: list[str] = []
    for inst_key in all_metrics:
        parts.append(f"=== {inst_key} ===")
        for sec_name, per_inst in section_results.items():
            sr = per_inst.get(inst_key)
            if sr and sr.llm_context:
                parts.append(sr.llm_context.rstrip())
        parts.append("")
    for sec_name, sr in global_results.items():
        if sr.llm_context:
            parts.append(sr.llm_context.rstrip())
            parts.append("")
    return "\n".join(parts)


def _build_instrument_section_context(
    inst_key: str,
    section_results: dict[str, dict[str, SectionResult]],
) -> str:
    """Build concatenated LLM context for a single instrument.

    Uses DataBlocks if available, ordered by theme.  Falls back to
    llm_context strings.
    """
    blocks: list[DataBlock] = []
    for sec_name, per_inst in section_results.items():
        sr = per_inst.get(inst_key)
        if sr:
            blocks.extend(sr.blocks)

    if blocks:
        theme_order = {t: i for i, t in enumerate(cfg.PROMPT_THEMES)}
        blocks.sort(key=lambda b: theme_order.get(b.theme, 99))
        parts = []
        for block in blocks:
            parts.append(f"## {block.title}\n")
            parts.append(block.content)
            parts.append("")
        return "\n".join(parts)

    parts: list[str] = []
    for sec_name, per_inst in section_results.items():
        sr = per_inst.get(inst_key)
        if sr and sr.llm_context:
            parts.append(sr.llm_context.rstrip())
    return "\n".join(parts)


if __name__ == "__main__":
    import sys
    _pkg_parent = str(Path(__file__).resolve().parent.parent)
    if _pkg_parent not in sys.path:
        sys.path.insert(0, _pkg_parent)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    on_server = os.environ.get("BLOOMBERG_ON_SERVER", "true").lower() == "true"

    from option_morning_brief.run import run_morning_brief as _run
    dry = "--dry-run" in sys.argv
    recip = "michael.kane@jainglobal.com"
    result = _run(dry_run=dry, on_server=on_server, recipients=recip)
    print(json.dumps(result, indent=2))
