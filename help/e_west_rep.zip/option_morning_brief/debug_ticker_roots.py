"""
Debug script #3: Investigate option ticker roots and per-contract chains.

Tests:
  1. FJSA vs FJCA vs other roots for TTF options
  2. Per-contract OPT_CHAIN on individual FJS/FJC tickers (FJSJ6, FJSK6, etc.)
  3. Per-contract OPT_CHAIN on underlying futures (TZTJ6, TZTK6, etc.)
  4. OVDV-related BDP fields for per-expiry vol
  5. Test if different moneyness fields vary by expiry on FJC tickers
"""

from __future__ import annotations

import sys
from pathlib import Path

_pkg_parent = str(Path(__file__).resolve().parent.parent)
if _pkg_parent not in sys.path:
    sys.path.insert(0, _pkg_parent)

import logging
logging.basicConfig(level=logging.WARNING)

import blpapi
from jain_commods.core.interfaces.bloomberg import BBGQuery


def bdp(bbg, tickers, fields):
    try:
        df = bbg.fetch_live(tickers=tickers, fields=fields)
        return df
    except Exception as e:
        print(f"    ERROR: {e}")
        return None


def opt_chain(bbg, ticker):
    session = bbg.session
    service = session.getService("//blp/refdata")
    request = service.createRequest("ReferenceDataRequest")
    request.getElement("securities").appendValue(ticker)
    request.getElement("fields").appendValue("OPT_CHAIN")
    session.sendRequest(request)

    tickers_out = []
    while True:
        event = session.nextEvent(5000)
        for msg in event:
            if not msg.hasElement("securityData"):
                continue
            arr = msg.getElement("securityData")
            for i in range(arr.numValues()):
                sd = arr.getValueAsElement(i)
                if not sd.hasElement("fieldData"):
                    continue
                fd = sd.getElement("fieldData")
                if not fd.hasElement("OPT_CHAIN"):
                    continue
                chain = fd.getElement("OPT_CHAIN")
                for j in range(chain.numValues()):
                    row = chain.getValueAsElement(j)
                    if row.hasElement("Security Description"):
                        tickers_out.append(row.getElementAsString("Security Description"))
        if event.eventType() == blpapi.Event.RESPONSE:
            break
    return tickers_out


def main():
    bbg = BBGQuery(p_on_server=True)

    DIVIDER = "=" * 72

    # ------------------------------------------------------------------
    # 1. Compare product-level tickers: FJSA, FJCA, FJDA, etc.
    # ------------------------------------------------------------------
    print(f"\n{DIVIDER}")
    print("1. PRODUCT-LEVEL TICKER COMPARISON (TTF options)")
    print(f"   Testing FJSA, FJCA, FJDA, FJEA for basic data")
    print(f"{DIVIDER}")

    candidate_roots = ["FJS", "FJC", "FJD", "FJE", "FJF", "FJT"]
    product_tickers = [f"{r}A Comdty" for r in candidate_roots]
    basic_fields = ["PX_LAST", "30DAY_IMPVOL_100.0%MNY_DF", "NAME", "SECURITY_DES"]

    for ticker in product_tickers:
        df = bdp(bbg, [ticker], basic_fields)
        if df is not None and not df.empty and not df.isna().all(axis=1).all():
            row = df.iloc[0]
            name = row.get("NAME", "?")
            desc = row.get("SECURITY_DES", "?")
            px = row.get("PX_LAST")
            iv = row.get("30DAY_IMPVOL_100.0%MNY_DF")
            print(f"  {ticker:<20} NAME={name}  DESC={desc}  PX={px}  IV={iv}")
        else:
            print(f"  {ticker:<20} NO DATA")

    # ------------------------------------------------------------------
    # 2. OPT_CHAIN on product-level tickers that returned data
    # ------------------------------------------------------------------
    print(f"\n{DIVIDER}")
    print("2. OPT_CHAIN ON PRODUCT-LEVEL TICKERS")
    print(f"{DIVIDER}")

    for root in candidate_roots:
        ticker = f"{root}A Comdty"
        chain = opt_chain(bbg, ticker)
        if chain:
            unique_prefixes = set()
            for t in chain:
                parts = t.replace(" Comdty", "").split()
                if parts:
                    prefix = ""
                    for ch in parts[0]:
                        if ch.isalpha():
                            prefix += ch
                        else:
                            break
                    month_year = parts[0][len(prefix):len(prefix)+2] if len(parts[0]) > len(prefix)+1 else "?"
                    unique_prefixes.add(f"{prefix}{month_year}")
            sorted_pf = sorted(unique_prefixes)
            print(f"  {ticker:<20} {len(chain):>5} options | Expiry prefixes: {sorted_pf[:15]}")
            print(f"    First 3: {chain[:3]}")
            print(f"    Last 3:  {chain[-3:]}")
        else:
            print(f"  {ticker:<20} NO CHAIN")

    # ------------------------------------------------------------------
    # 3. Per-contract OPT_CHAIN on FJS tickers
    # ------------------------------------------------------------------
    print(f"\n{DIVIDER}")
    print("3. PER-CONTRACT OPT_CHAIN (individual option tickers)")
    print(f"{DIVIDER}")

    per_contract_tickers = [
        ("FJSJ6 Comdty", "TTF Apr26 options"),
        ("FJSK6 Comdty", "TTF May26 options"),
        ("FJSM6 Comdty", "TTF Jun26 options"),
    ]

    # Also test FJC if it exists
    for root in ["FJC"]:
        for suffix, label in [("J6", "Apr26"), ("K6", "May26"), ("M6", "Jun26")]:
            per_contract_tickers.append(
                (f"{root}{suffix} Comdty", f"TTF {label} {root} options")
            )

    for ticker, label in per_contract_tickers:
        chain = opt_chain(bbg, ticker)
        if chain:
            print(f"  {ticker:<20} {label:<30} {len(chain):>5} options")
            print(f"    First 2: {chain[:2]}")
        else:
            print(f"  {ticker:<20} {label:<30} NO CHAIN")

    # ------------------------------------------------------------------
    # 4. Per-contract OPT_CHAIN on FUTURES tickers (TZT root)
    # ------------------------------------------------------------------
    print(f"\n{DIVIDER}")
    print("4. PER-CONTRACT OPT_CHAIN ON FUTURES TICKERS (TZT)")
    print(f"{DIVIDER}")

    futures_tickers = [
        ("TZTJ6 Comdty", "TTF Apr26 futures"),
        ("TZTK6 Comdty", "TTF May26 futures"),
        ("TZTM6 Comdty", "TTF Jun26 futures"),
    ]

    for ticker, label in futures_tickers:
        chain = opt_chain(bbg, ticker)
        if chain:
            print(f"  {ticker:<20} {label:<30} {len(chain):>5} options")
            print(f"    First 2: {chain[:2]}")
        else:
            print(f"  {ticker:<20} {label:<30} NO CHAIN")

    # ------------------------------------------------------------------
    # 5. Per-expiry moneyness vol comparison (FJS vs FJC)
    # ------------------------------------------------------------------
    print(f"\n{DIVIDER}")
    print("5. PER-EXPIRY VOL COMPARISON — do values differ by tenor?")
    print(f"{DIVIDER}")

    vol_fields = [
        "30DAY_IMPVOL_100.0%MNY_DF",
        "30DAY_IMPVOL_95.0%MNY_DF",
        "30DAY_IMPVOL_105.0%MNY_DF",
    ]

    for root_label, tickers in [
        ("FJS (current)", ["FJSJ6 Comdty", "FJSK6 Comdty", "FJSM6 Comdty", "FJSN6 Comdty"]),
        ("FJC (candidate)", ["FJCJ6 Comdty", "FJCK6 Comdty", "FJCM6 Comdty", "FJCN6 Comdty"]),
    ]:
        print(f"\n  {root_label}:")
        df = bdp(bbg, tickers, vol_fields)
        if df is not None and not df.empty:
            for idx, row in df.iterrows():
                atm = row.get("30DAY_IMPVOL_100.0%MNY_DF")
                p95 = row.get("30DAY_IMPVOL_95.0%MNY_DF")
                c105 = row.get("30DAY_IMPVOL_105.0%MNY_DF")
                atm_s = f"{atm:>8.2f}%" if atm is not None else "      —"
                p95_s = f"{p95:>8.2f}%" if p95 is not None else "      —"
                c105_s = f"{c105:>8.2f}%" if c105 is not None else "      —"
                print(f"    {str(idx):<20} ATM={atm_s}  95%={p95_s}  105%={c105_s}")
        else:
            print(f"    NO DATA for any ticker")

    # ------------------------------------------------------------------
    # 6. Other commodity option roots for comparison
    # ------------------------------------------------------------------
    print(f"\n{DIVIDER}")
    print("6. BRENT & EUA — per-contract OPT_CHAIN on futures tickers")
    print(f"{DIVIDER}")

    other_tests = [
        ("COK6 Comdty", "Brent May26 futures"),
        ("COM6 Comdty", "Brent Jun26 futures"),
        ("MOJ26 Comdty", "EUA Apr26 futures"),
        ("MOK26 Comdty", "EUA May26 futures"),
        ("MZBJ6 Comdty", "EUA Apr26 opt ticker"),
        ("MZBK6 Comdty", "EUA May26 opt ticker"),
        ("QSJ6 Comdty", "Gasoil Apr26 futures"),
        ("QSK6 Comdty", "Gasoil May26 futures"),
        ("DETJ6 Comdty", "DE Power Apr26"),
        ("DETK6 Comdty", "DE Power May26"),
        ("HGK6 Comdty", "COMEX Copper May26"),
        ("HGM6 Comdty", "COMEX Copper Jun26"),
    ]

    for ticker, label in other_tests:
        chain = opt_chain(bbg, ticker)
        if chain:
            print(f"  {ticker:<20} {label:<30} {len(chain):>5} options")
        else:
            print(f"  {ticker:<20} {label:<30} NO CHAIN")

    # ------------------------------------------------------------------
    # 7. Vol surface fields with overrides
    # ------------------------------------------------------------------
    print(f"\n{DIVIDER}")
    print("7. CHECKING IVOL FIELDS WITH OVERRIDES (PRICING_SOURCE)")
    print(f"   Some fields may need OVR to specify pricing source")
    print(f"{DIVIDER}")

    test_ticker = "FJSK6 Comdty"
    override_fields = [
        "IVOL_SURFACE_100",
        "OPT_ATM_IMPLIED_VOL",
        "OPT_IMPVOL_AVG_100%",
        "IVOL_PX",
        "IVOL_LAST",
        "HIST_CALL_IMP_VOL",
        "HIST_PUT_IMP_VOL",
        "IMPLIED_VOLATILITY_ASK",
        "IMPLIED_VOLATILITY_BID",
        "IMPLIED_VOLATILITY_MID",
        "IVOL_MID_CALL",
        "IVOL_MID_PUT",
    ]

    df = bdp(bbg, [test_ticker], override_fields)
    if df is not None and not df.empty:
        row = df.iloc[0]
        for f in override_fields:
            v = row.get(f)
            status = f"OK   {v}" if v is not None else "---  None"
            print(f"    {status:<10}  {f}")
    else:
        print(f"    NO DATA returned for {test_ticker}")

    print(f"\n{DIVIDER}")
    print("DEBUG #3 COMPLETE")
    print(f"{DIVIDER}")


if __name__ == "__main__":
    main()
