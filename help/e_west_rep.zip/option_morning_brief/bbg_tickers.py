"""
Bloomberg ticker generation for the Energy Options Morning Brief.

Constructs specific contract tickers for futures (and their options) given
the instrument configuration and contract depth settings.

Ticker format: {base_ticker}{month_code}{year_code} {security_type}

Year code formats:
    hybrid:             historical (<current year) = 2-digit, current/future = 1-digit
    always_two_digits:  always 2-digit (EUA, UKA)
    power_year_hybrid:  current/past = 2-digit, future only = 1-digit (DE/FR power)

Option chain ticker strategy:
    - TTF, EUA: options trade under a separate root; OPT_CHAIN is queried on
      a product-level ticker (e.g. "FJSA Comdty", "MZBA Comdty").
    - All others: options share the futures root; OPT_CHAIN is queried on
      each specific futures contract ticker (e.g. "COZ7 Comdty").

Vol surface ticker strategy:
    - TTF, EUA: BDP vol surface fields live on the options-root tickers
      (e.g. "FJSK6 Comdty" for TTF May26, "MZBZ6 Comdty" for EUA Dec26).
    - All others: BDP vol surface fields live on the futures ticker itself.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime

from . import config as cfg

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ContractSpec:
    """Identifies a single futures contract and how to reach its options."""
    ticker: str               # futures ticker, e.g. "COK6 Comdty"
    instrument: str           # config key, e.g. "Brent"
    tenor_type: str           # "monthly" | "quarterly" | "calendar"
    year: int
    month: int
    label: str                # human-readable, e.g. "May26"
    opt_chain_ticker: str     # ticker to query OPT_CHAIN on
    vol_surface_ticker: str   # ticker to query BDP vol surface fields on


def _year_code(year: int, fmt: str, year_offset: int = 0) -> str:
    adjusted = year + year_offset
    current_year = datetime.now().year

    if fmt == "always_two_digits":
        return f"{adjusted % 100:02d}"
    elif fmt == "power_year_hybrid":
        if adjusted <= current_year:
            return f"{adjusted % 100:02d}"
        return str(adjusted % 10)
    else:  # hybrid
        if adjusted < current_year:
            return f"{adjusted % 100:02d}"
        return str(adjusted % 10)


def _month_label(month: int, year: int) -> str:
    names = {
        1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
        7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec",
    }
    return f"{names[month]}{year % 100:02d}"


def _build_ticker(root: str, month: int, year: int,
                  year_code_format: str, year_offset: int,
                  security_type: str) -> str:
    mc = cfg.BBG_MONTH_CODES[month]
    yc = _year_code(year, year_code_format, year_offset)
    return f"{root}{mc}{yc} {security_type}"


def _resolve_opt_chain_ticker(
    inst: cfg.InstrumentConfig,
    futures_ticker: str,
    month: int,
    year: int,
) -> str:
    """
    Determine the correct ticker for OPT_CHAIN queries.

    Priority:
      1. Product-level opt_chain_ticker (shared across all expiries)
      2. Per-contract from opt_chain_root (German Power → DET-based tickers)
      3. Per-contract from options_root (TTF → FJSJ6, EUA → MZBK6, etc.)
      4. The futures contract ticker itself (Brent, Gasoil, RBOB, etc.)
    """
    if inst.opt_chain_ticker:
        return inst.opt_chain_ticker
    if inst.opt_chain_root:
        yc_fmt = inst.opt_chain_year_code_format or inst.year_code_format
        sec_type = inst.opt_chain_security_type or inst.security_type
        return _build_ticker(
            root=inst.opt_chain_root,
            month=month,
            year=year,
            year_code_format=yc_fmt,
            year_offset=inst.year_offset,
            security_type=sec_type,
        )
    if inst.options_root:
        return _build_ticker(
            root=inst.options_root,
            month=month,
            year=year,
            year_code_format=inst.effective_options_year_code_format,
            year_offset=inst.year_offset,
            security_type=inst.security_type,
        )
    return futures_ticker


def _resolve_vol_surface_ticker(
    inst: cfg.InstrumentConfig,
    futures_ticker: str,
    month: int,
    year: int,
) -> str:
    """
    For instruments where options have a separate root (TTF, EUA), construct
    the per-contract options ticker for vol surface BDP queries.
    e.g. TTF May26 → "FJSK6 Comdty", EUA Dec26 → "MZBZ6 Comdty".

    For all others, the futures ticker itself carries vol surface fields.
    """
    if not inst.options_root:
        return futures_ticker
    return _build_ticker(
        root=inst.options_root,
        month=month,
        year=year,
        year_code_format=inst.effective_options_year_code_format,
        year_offset=inst.year_offset,
        security_type=inst.security_type,
    )


def identify_front_contracts(
    instrument_key: str,
    ref_date: datetime | None = None,
) -> list[ContractSpec]:
    """
    Return the front N monthly, quarterly, and calendar contracts for
    the given instrument, based on the current date.
    """
    inst = cfg.INSTRUMENTS[instrument_key]
    now = ref_date or datetime.now()
    cur_year, cur_month = now.year, now.month

    contracts: list[ContractSpec] = []
    seen_tickers: set[str] = set()

    def _add(month: int, year: int, tenor_type: str):
        root = inst.root_for_tenor(tenor_type)
        sec_type = inst.security_type_for_tenor(tenor_type)
        ticker = _build_ticker(
            root, month, year,
            inst.year_code_format, inst.year_offset, sec_type,
        )
        if ticker in seen_tickers:
            return
        seen_tickers.add(ticker)
        opt_ticker = _resolve_opt_chain_ticker(inst, ticker, month, year)
        vol_ticker = _resolve_vol_surface_ticker(inst, ticker, month, year)
        contracts.append(ContractSpec(
            ticker=ticker,
            instrument=instrument_key,
            tenor_type=tenor_type,
            year=year,
            month=month,
            label=_month_label(month, year),
            opt_chain_ticker=opt_ticker,
            vol_surface_ticker=vol_ticker,
        ))

    # Front N monthly
    m, y = cur_month, cur_year
    added = 0
    while added < cfg.MONTHLY_DEPTH:
        m += 1
        if m > 12:
            m = 1
            y += 1
        _add(m, y, "monthly")
        added += 1

    # Front N quarterly (use first month of quarter)
    cur_q = (cur_month - 1) // 3 + 1
    q, qy = cur_q, cur_year
    added = 0
    while added < cfg.QUARTERLY_DEPTH:
        q += 1
        if q > 4:
            q = 1
            qy += 1
        first_month = cfg.QUARTER_FIRST_MONTH[q]
        _add(first_month, qy, "quarterly")
        added += 1

    # Front calendar year — pick the nearest December contract that is
    # still in the future, but cap at 12 months from reference date.
    for cal_offset in range(0, 3):
        cal_year = cur_year + cal_offset
        cal_month = 12
        # Skip if already expired (Dec of current year and we're past Dec)
        if cal_year == cur_year and cal_month <= cur_month:
            continue
        # Skip if beyond 12-month horizon
        months_out = (cal_year - cur_year) * 12 + (cal_month - cur_month)
        if months_out > 12:
            break
        _add(cal_month, cal_year, "calendar")
        break

    return contracts


def all_contract_tickers(
    ref_date: datetime | None = None,
) -> dict[str, list[ContractSpec]]:
    """Return contract specs for every instrument in the universe."""
    result: dict[str, list[ContractSpec]] = {}
    for key in cfg.INSTRUMENTS:
        result[key] = identify_front_contracts(key, ref_date)
    return result
