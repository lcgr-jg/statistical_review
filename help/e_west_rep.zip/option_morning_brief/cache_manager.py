"""
Daily snapshot cache for the Energy Options Morning Brief.

Persists BDP vol-surface / options snapshots to parquet so that
subsequent runs can compute multi-horizon changes and percentile
ranks without re-querying Bloomberg for historical data.

Directory layout:
    cache/daily_snapshots/{instrument_key}/{YYYY-MM-DD}.parquet
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

from . import config as cfg

logger = logging.getLogger(__name__)

_CACHE_ROOT = Path(__file__).parent / cfg.DASHBOARD_CACHE_DIR / "daily_snapshots"

_history_cache: dict[str, pd.DataFrame] = {}


def clear_history_cache():
    """Clear the in-memory cache (call at the start of each run)."""
    _history_cache.clear()


def _inst_dir(instrument_key: str) -> Path:
    d = _CACHE_ROOT / instrument_key.replace(" ", "_")
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_daily_snapshot(
    instrument_key: str,
    data: pd.DataFrame,
    date: datetime | None = None,
) -> Path:
    """Persist today's vol-surface / options snapshot to parquet."""
    date = date or datetime.now()
    fname = _inst_dir(instrument_key) / f"{date.strftime('%Y-%m-%d')}.parquet"
    data.to_parquet(fname, index=True)
    logger.info("Saved snapshot for %s -> %s", instrument_key, fname)
    return fname


def load_history(
    instrument_key: str,
    lookback_days: int | None = None,
) -> pd.DataFrame:
    """
    Load accumulated daily snapshots for an instrument.

    Results are cached in-memory for the duration of the run so that
    repeated calls (one per metric per contract) don't re-read parquet
    files or flood the log.

    Returns a DataFrame with a ``snapshot_date`` column so the caller
    can align dates.
    """
    if instrument_key in _history_cache:
        return _history_cache[instrument_key]

    lookback = lookback_days or cfg.CACHE_LOOKBACK_DAYS
    cutoff = datetime.now() - timedelta(days=lookback)
    inst_dir = _inst_dir(instrument_key)

    frames: list[pd.DataFrame] = []
    for f in sorted(inst_dir.glob("*.parquet")):
        try:
            file_date = datetime.strptime(f.stem, "%Y-%m-%d")
        except ValueError:
            continue
        if file_date < cutoff:
            continue
        df = pd.read_parquet(f)
        df["snapshot_date"] = file_date
        frames.append(df)

    if not frames:
        _history_cache[instrument_key] = pd.DataFrame()
        return _history_cache[instrument_key]

    combined = pd.concat(frames, ignore_index=True)
    logger.info("Loaded %d snapshot rows for %s (%d days)",
                len(combined), instrument_key, combined["snapshot_date"].nunique())
    _history_cache[instrument_key] = combined
    return combined


def compute_percentile_rank(
    current_value: float | None,
    history_series: pd.Series,
) -> float | None:
    """
    Compute the percentile rank (0-100) of *current_value* within
    a historical series.  Returns None when insufficient data.
    """
    if current_value is None or np.isnan(current_value):
        return None
    clean = history_series.dropna()
    if len(clean) < 10:
        return None
    rank = (clean < current_value).sum() / len(clean) * 100.0
    return round(rank, 1)


def compute_change_from_cache(
    instrument_key: str,
    ticker: str,
    field: str,
    current_value: float | None,
    horizon_days: int,
) -> float | None:
    """
    Look up the snapshot from *horizon_days* ago and return
    current_value - historical_value.  Returns None on missing data.
    """
    if current_value is None:
        return None
    target_date = datetime.now() - timedelta(days=horizon_days)
    inst_dir = _inst_dir(instrument_key)

    # Walk backwards up to 5 extra calendar days to find nearest snapshot
    for offset in range(6):
        check = target_date - timedelta(days=offset)
        f = inst_dir / f"{check.strftime('%Y-%m-%d')}.parquet"
        if f.exists():
            df = pd.read_parquet(f)
            if ticker in df.index and field in df.columns:
                prev = df.loc[ticker, field]
                if prev is not None and not (isinstance(prev, float) and np.isnan(prev)):
                    return round(current_value - float(prev), 6)
            break
    return None


def prune_old_snapshots(max_age_days: int | None = None):
    """Remove snapshots older than *max_age_days* to keep cache tidy."""
    max_age = max_age_days or cfg.CACHE_LOOKBACK_DAYS + 30
    cutoff = datetime.now() - timedelta(days=max_age)

    for inst_dir in _CACHE_ROOT.iterdir():
        if not inst_dir.is_dir():
            continue
        for f in inst_dir.glob("*.parquet"):
            try:
                file_date = datetime.strptime(f.stem, "%Y-%m-%d")
            except ValueError:
                continue
            if file_date < cutoff:
                f.unlink()
                logger.debug("Pruned old snapshot: %s", f)
