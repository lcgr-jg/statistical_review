"""
Configuration for the Energy Options Morning Brief.

Instrument universe with BBG ticker mappings, ICE Snowflake product codes,
contract depth settings, field definitions, and AI / dashboard config.

Options data is sourced primarily from Snowflake (ICE MFT options table)
for ICE-traded instruments, with Bloomberg BDH for futures prices.
Non-ICE instruments (RBOB, Copper) use Bloomberg futures only.
"""

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Bloomberg month codes
# ---------------------------------------------------------------------------
BBG_MONTH_CODES: dict[int, str] = {
    1: "F", 2: "G", 3: "H", 4: "J", 5: "K", 6: "M",
    7: "N", 8: "Q", 9: "U", 10: "V", 11: "X", 12: "Z",
}
MONTH_CODE_TO_NUM: dict[str, int] = {v: k for k, v in BBG_MONTH_CODES.items()}

QUARTER_FIRST_MONTH: dict[int, int] = {1: 1, 2: 4, 3: 7, 4: 10}


# ---------------------------------------------------------------------------
# Instrument universe
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class InstrumentConfig:
    display_name: str
    bbg_root: str                           # futures ticker root (e.g. "TZT")
    security_type: str = "Comdty"
    year_code_format: str = "hybrid"
    year_offset: int = 0
    unit: str = ""
    generic_ticker: str = ""                # e.g. "CO1 Comdty"

    # Options may trade under a different ticker root than futures.
    # options_root is the *base* root for constructing per-contract options
    # tickers (e.g. "FJS" for TTF → FJSK6 Comdty, "MZB" for EUA → MZBZ6).
    # The product-level ticker adds "A" (e.g. "FJSA Comdty", "MZBA Comdty").
    options_root: str | None = None
    opt_chain_ticker: str | None = None     # product-level OPT_CHAIN ticker

    # Options may use a different year code format than futures.
    # e.g. EUA futures = always_two_digits (MOZ26), but EUA options = hybrid (MZBZ6).
    # If None, inherits year_code_format from the futures.
    options_year_code_format: str | None = None

    # Some instruments use different roots per tenor type (e.g. French Power:
    # monthly=FAC, quarterly=FAB, calendar=FAA).  If None, bbg_root is used.
    quarterly_root: str | None = None
    calendar_root: str | None = None

    # Per-tenor security type overrides (e.g. German Power monthly = "Index",
    # quarterly/calendar = "Comdty").  If None, inherits security_type.
    quarterly_security_type: str | None = None
    calendar_security_type: str | None = None

    # For instruments where the option chain uses a different root than the
    # futures price ticker (e.g. German Power: prices via FEGBM but OPT_CHAIN
    # via DET).  If None and opt_chain_ticker is also None, uses futures ticker.
    opt_chain_root: str | None = None
    opt_chain_security_type: str | None = None
    opt_chain_year_code_format: str | None = None

    # ICE Snowflake options data (primary source for options analytics).
    # Maps to ice.mft.options table: commodity + product columns.
    # French Power uses multiple product IDs for monthly/quarterly/calendar.
    ice_commodity: list[dict] | None = None

    def generic(self, n: int = 1) -> str:
        return f"{self.bbg_root}{n} {self.security_type}"

    def root_for_tenor(self, tenor_type: str) -> str:
        if tenor_type == "quarterly" and self.quarterly_root:
            return self.quarterly_root
        if tenor_type == "calendar" and self.calendar_root:
            return self.calendar_root
        return self.bbg_root

    def security_type_for_tenor(self, tenor_type: str) -> str:
        if tenor_type == "quarterly" and self.quarterly_security_type:
            return self.quarterly_security_type
        if tenor_type == "calendar" and self.calendar_security_type:
            return self.calendar_security_type
        return self.security_type

    @property
    def options_use_separate_root(self) -> bool:
        return self.options_root is not None

    @property
    def effective_options_year_code_format(self) -> str:
        return self.options_year_code_format or self.year_code_format

    @property
    def has_ice_options(self) -> bool:
        return self.ice_commodity is not None


INSTRUMENTS: dict[str, InstrumentConfig] = {
    "TTF": InstrumentConfig(
        display_name="TTF Natural Gas",
        bbg_root="TZT",
        unit="EUR/MWh",
        generic_ticker="TZT1 Comdty",
        options_root="FJS",
        ice_commodity=[{"commodity_name": "TFO", "id": 22256}],
    ),
    "Brent": InstrumentConfig(
        display_name="Brent Crude",
        bbg_root="CO",
        unit="USD/bbl",
        generic_ticker="CO1 Comdty",
        ice_commodity=[{"commodity_name": "B", "id": 254}],
    ),
    "EUA": InstrumentConfig(
        display_name="EU Carbon (EUA)",
        bbg_root="MO",
        year_code_format="always_two_digits",
        unit="EUR/t",
        generic_ticker="MODEC1 Comdty",
        options_root="MZB",
        opt_chain_ticker="MZBA Comdty",
        options_year_code_format="hybrid",
        ice_commodity=[{"commodity_name": "EFO", "id": 22304}],
    ),
    "German Power": InstrumentConfig(
        display_name="German Power Baseload",
        bbg_root="DET",
        unit="EUR/MWh",
        generic_ticker="DET1 Comdty",
        quarterly_root="DEQ",
        calendar_root="JXY",
        ice_commodity=[{"commodity_name": "GAB", "id": 19032}],
    ),
    "French Power": InstrumentConfig(
        display_name="French Power Baseload",
        bbg_root="FAC",
        year_code_format="power_year_hybrid",
        unit="EUR/MWh",
        generic_ticker="FAC1 Comdty",
        quarterly_root="FAB",
        calendar_root="FAA",
        ice_commodity=[
            {"commodity_name": "FNB", "id": 19033},
            {"commodity_name": "FNQ", "id": 20367},
            {"commodity_name": "FNR", "id": 20368},
        ],
    ),
    "Gasoil": InstrumentConfig(
        display_name="ICE Gasoil",
        bbg_root="QS",
        unit="USD/t",
        generic_ticker="QS1 Comdty",
        ice_commodity=[{"commodity_name": "G", "id": 5817}],
    ),
    "RBOB": InstrumentConfig(
        display_name="RBOB Gasoline",
        bbg_root="XB",
        unit="USc/gal",
        generic_ticker="XB1 Comdty",
    ),
    "Copper": InstrumentConfig(
        display_name="COMEX Copper",
        bbg_root="HG",
        unit="USc/lb",
        generic_ticker="HG1 Comdty",
    ),
}

# ---------------------------------------------------------------------------
# Contract depth
# ---------------------------------------------------------------------------
MONTHLY_DEPTH = 3
QUARTERLY_DEPTH = 3
CAL_DEPTH = 1

# ---------------------------------------------------------------------------
# Lookback / horizon settings
# ---------------------------------------------------------------------------
LOOKBACK_HORIZONS = [1, 5, 20]
HIST_LOOKBACK_DAYS = 252
CACHE_LOOKBACK_DAYS = 260

# ---------------------------------------------------------------------------
# Bloomberg field definitions
# ---------------------------------------------------------------------------
FUTURES_BDH_FIELDS = ["PX_OPEN", "PX_HIGH", "PX_LOW", "PX_LAST", "VOLUME", "OPEN_INT"]

VOL_SURFACE_BDP_FIELDS = [
    "30DAY_IMPVOL_100.0%MNY_DF",   # ATM
    "30DAY_IMPVOL_97.5%MNY_DF",    # ~25D put wing
    "30DAY_IMPVOL_95.0%MNY_DF",    # ~10D put wing
    "30DAY_IMPVOL_90.0%MNY_DF",    # deep put wing
    "30DAY_IMPVOL_102.5%MNY_DF",   # ~25D call wing
    "30DAY_IMPVOL_105.0%MNY_DF",   # ~10D call wing
    "30DAY_IMPVOL_110.0%MNY_DF",   # deep call wing
    "OPEN_INT",
    "VOLUME",
]

# Moneyness-to-approximate-delta mapping for vol surface analytics
MONEYNESS_FIELD_MAP = {
    "90%": "30DAY_IMPVOL_90.0%MNY_DF",
    "95%": "30DAY_IMPVOL_95.0%MNY_DF",
    "97.5%": "30DAY_IMPVOL_97.5%MNY_DF",
    "ATM": "30DAY_IMPVOL_100.0%MNY_DF",
    "102.5%": "30DAY_IMPVOL_102.5%MNY_DF",
    "105%": "30DAY_IMPVOL_105.0%MNY_DF",
    "110%": "30DAY_IMPVOL_110.0%MNY_DF",
}

OPTION_CHAIN_FIELDS = [
    "OPT_IMPLIED_VOLATILITY_MID",
    "OPEN_INT",
    "VOLUME",
    "OPT_DELTA",
    "OPT_GAMMA",
    "OPT_VEGA",
    "OPT_THETA",
    "OPT_STRIKE_PX",
    "OPT_PUT_CALL",
    "OPT_EXPIRE_DT",
    "PX_LAST",
]

# ---------------------------------------------------------------------------
# Delta / vol tolerances
# ---------------------------------------------------------------------------
DELTA_ATM = 0.50
DELTA_25 = 0.25
DELTA_10 = 0.10
SIGMA_STRIKE_FILTER = 2.0

# ICE Snowflake delta tolerances (from options positioning dashboard)
ICE_DELTA_TOL_ATM = 0.05   # ATM: |delta| within 0.45-0.55
ICE_DELTA_TOL_VOL = 0.03   # wings: delta within ±0.03 of target

# ---------------------------------------------------------------------------
# ICE Snowflake connection
# ---------------------------------------------------------------------------
ICE_SNOWFLAKE_DB = "ICE"
ICE_SNOWFLAKE_SCHEMA = "MFT"
ICE_SNOWFLAKE_ROLE = "FR_COMMOD_PM_EU"
ICE_OPTIONS_TABLE = "ice.mft.options"

# ---------------------------------------------------------------------------
# Metric taxonomy — controlled vocabulary for LLM context
# ---------------------------------------------------------------------------
METRIC_TAXONOMY: dict[str, str] = {
    "settlement": "Settlement / last price in natural units",
    "price_1d": "1-day price change",
    "price_5d": "5-day price change",
    "price_20d": "20-day price change",
    "atm_vol": "At-the-money implied vol (%, annualised)",
    "25d_RR": "25-delta risk reversal (call vol minus put vol, pts)",
    "25d_BF": "25-delta butterfly (wing avg minus ATM, pts)",
    "10d_RR": "10-delta risk reversal (pts)",
    "10d_BF": "10-delta butterfly (pts)",
    "vol_term_spread": "Front minus back ATM vol (pts); positive = contango",
    "total_volume": "Futures trading volume (contracts)",
    "call_volume": "Options call volume (contracts)",
    "put_volume": "Options put volume (contracts)",
    "put_call_ratio": "Put / call open interest ratio",
    "total_OI": "Futures open interest (contracts)",
    "call_OI": "Call option open interest (contracts)",
    "put_OI": "Put option open interest (contracts)",
    "OI_change_1d": "1-day OI change (contracts)",
    "volume_zscore": "Volume vs 20-day average (standard deviations)",
}

# Source types for credibility weighting
SOURCE_TYPES: dict[str, str] = {
    "primary": "Exchange data / official settlements (ICE, CME, Bloomberg)",
    "secondary": "Broker commentary, news wires, third-party research",
    "internal": "Internal models, views, assessments",
}

# Block types for polymorphic content
BLOCK_TYPES = ("table", "text", "timeseries", "event", "assessment")

# Themes for prompt ordering (narrative flow order)
PROMPT_THEMES = (
    "prices",
    "vol_surface",
    "vol_term_structure",
    "positioning",
    "cross_asset",
)

# Section → theme mapping
SECTION_THEME_MAP: dict[str, str] = {
    "price_overview": "prices",
    "vol_surface": "vol_surface",
    "skew_change": "vol_surface",
    "term_structure": "vol_term_structure",
    "volume_zscore": "positioning",
    "oi_profile": "positioning",
    "cross_asset": "cross_asset",
}

# Domain per instrument (for block metadata)
INSTRUMENT_DOMAINS: dict[str, str] = {
    "TTF": "energy",
    "Brent": "energy",
    "EUA": "carbon",
    "German Power": "power",
    "French Power": "power",
    "Gasoil": "energy",
    "RBOB": "energy",
    "Copper": "metals",
}

# ---------------------------------------------------------------------------
# Claude LLM settings
# ---------------------------------------------------------------------------
CLAUDE_MODEL = "claude-sonnet-4-20250514"
CLAUDE_MAX_TOKENS = 8192
CLAUDE_TEMPERATURE = 0.0

# ---------------------------------------------------------------------------
# Dashboard settings
# ---------------------------------------------------------------------------
DASHBOARD_PORT = 5003
DASHBOARD_CACHE_DIR = "cache"

# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------
DEFAULT_RECIPIENTS = "michael.kane@jainglobal.com"
