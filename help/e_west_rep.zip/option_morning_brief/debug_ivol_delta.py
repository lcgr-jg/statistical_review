"""
Debug script #4: Test IVOL_DELTA with blpapi overrides.

Based on ASKB guidance:
  - IVOL_DELTA with overrides IVOL_DELTA_LEVEL, IVOL_DELTA_PUT_OR_CALL, IVOL_MATURITY
  - Per-expiry: try with and without IVOL_MATURITY to see if values differ by tenor
  - OPT_CHAIN on individual FJS tickers for per-month option chains
"""

from __future__ import annotations

import sys
from pathlib import Path

_pkg_parent = str(Path(__file__).resolve().parent.parent)
if _pkg_parent not in sys.path:
    sys.path.insert(0, _pkg_parent)

import logging
logging.basicConfig(level=logging.WARNING)

import blpapi
from jain_commods.core.interfaces.bloomberg import BBGQuery


def bdp_with_overrides(bbg, tickers: list[str], field: str, overrides: dict) -> dict:
    """BDP request with field overrides. Returns {ticker: value}."""
    session = bbg.session
    service = session.getService("//blp/refdata")
    request = service.createRequest("ReferenceDataRequest")

    for t in tickers:
        request.getElement("securities").appendValue(t)
    request.getElement("fields").appendValue(field)

    ovr_elem = request.getElement("overrides")
    for key, value in overrides.items():
        o = ovr_elem.appendElement()
        o.setElement("fieldId", key)
        o.setElement("value", str(value))

    session.sendRequest(request)

    results = {}
    while True:
        event = session.nextEvent(5000)
        for msg in event:
            if not msg.hasElement("securityData"):
                continue
            arr = msg.getElement("securityData")
            for i in range(arr.numValues()):
                sd = arr.getValueAsElement(i)
                ticker = sd.getElementAsString("security")
                if not sd.hasElement("fieldData"):
                    continue
                fd = sd.getElement("fieldData")
                if fd.hasElement(field):
                    try:
                        val = fd.getElementAsFloat(field)
                        results[ticker] = val
                    except Exception:
                        results[ticker] = None
                else:
                    results[ticker] = None
        if event.eventType() == blpapi.Event.RESPONSE:
            break

    return results


def opt_chain(bbg, ticker: str) -> list[str]:
    session = bbg.session
    service = session.getService("//blp/refdata")
    request = service.createRequest("ReferenceDataRequest")
    request.getElement("securities").appendValue(ticker)
    request.getElement("fields").appendValue("OPT_CHAIN")
    session.sendRequest(request)

    out = []
    while True:
        event = session.nextEvent(5000)
        for msg in event:
            if not msg.hasElement("securityData"):
                continue
            arr = msg.getElement("securityData")
            for i in range(arr.numValues()):
                sd = arr.getValueAsElement(i)
                if not sd.hasElement("fieldData"):
                    continue
                fd = sd.getElement("fieldData")
                if not fd.hasElement("OPT_CHAIN"):
                    continue
                chain = fd.getElement("OPT_CHAIN")
                for j in range(chain.numValues()):
                    row = chain.getValueAsElement(j)
                    if row.hasElement("Security Description"):
                        out.append(row.getElementAsString("Security Description"))
        if event.eventType() == blpapi.Event.RESPONSE:
            break
    return out


def main():
    bbg = BBGQuery(p_on_server=True)

    DIV = "=" * 72
    ttf_tickers = ["FJSJ6 Comdty", "FJSK6 Comdty", "FJSM6 Comdty", "FJSN6 Comdty"]

    # ------------------------------------------------------------------
    # 1. IVOL_DELTA WITH IVOL_MATURITY=30D (standardized 30-day)
    # ------------------------------------------------------------------
    print(f"\n{DIV}")
    print("1. IVOL_DELTA with IVOL_MATURITY=30D (standardized 30-day)")
    print(f"   Expect same values across tenors (like moneyness fields)")
    print(f"{DIV}")

    queries = [
        ("ATM (50D Call)", {"IVOL_DELTA_LEVEL": "50", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL", "IVOL_MATURITY": "30D"}),
        ("25D Call",       {"IVOL_DELTA_LEVEL": "25", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL", "IVOL_MATURITY": "30D"}),
        ("25D Put",        {"IVOL_DELTA_LEVEL": "25", "IVOL_DELTA_PUT_OR_CALL": "IVOL_PUT",  "IVOL_MATURITY": "30D"}),
        ("10D Call",       {"IVOL_DELTA_LEVEL": "10", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL", "IVOL_MATURITY": "30D"}),
        ("10D Put",        {"IVOL_DELTA_LEVEL": "10", "IVOL_DELTA_PUT_OR_CALL": "IVOL_PUT",  "IVOL_MATURITY": "30D"}),
    ]

    for label, overrides in queries:
        results = bdp_with_overrides(bbg, ttf_tickers, "IVOL_DELTA", overrides)
        vals = "  |  ".join(
            f"{t.split()[0]}: {v:.2f}%" if v is not None else f"{t.split()[0]}: —"
            for t, v in sorted(results.items())
        )
        print(f"  {label:<15}  {vals}")

    # ------------------------------------------------------------------
    # 2. IVOL_DELTA WITHOUT IVOL_MATURITY (per-expiry?)
    # ------------------------------------------------------------------
    print(f"\n{DIV}")
    print("2. IVOL_DELTA WITHOUT IVOL_MATURITY (should vary by tenor)")
    print(f"{DIV}")

    queries_no_mat = [
        ("ATM (50D Call)", {"IVOL_DELTA_LEVEL": "50", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL"}),
        ("25D Call",       {"IVOL_DELTA_LEVEL": "25", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL"}),
        ("25D Put",        {"IVOL_DELTA_LEVEL": "25", "IVOL_DELTA_PUT_OR_CALL": "IVOL_PUT"}),
        ("10D Call",       {"IVOL_DELTA_LEVEL": "10", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL"}),
        ("10D Put",        {"IVOL_DELTA_LEVEL": "10", "IVOL_DELTA_PUT_OR_CALL": "IVOL_PUT"}),
    ]

    for label, overrides in queries_no_mat:
        results = bdp_with_overrides(bbg, ttf_tickers, "IVOL_DELTA", overrides)
        vals = "  |  ".join(
            f"{t.split()[0]}: {v:.2f}%" if v is not None else f"{t.split()[0]}: —"
            for t, v in sorted(results.items())
        )
        print(f"  {label:<15}  {vals}")

    # ------------------------------------------------------------------
    # 3. IVOL_DELTA with different IVOL_MATURITY values
    # ------------------------------------------------------------------
    print(f"\n{DIV}")
    print("3. IVOL_DELTA at 50D Call with different IVOL_MATURITY values")
    print(f"   Testing on FJSK6 Comdty (TTF May26)")
    print(f"{DIV}")

    for mat in ["7D", "14D", "30D", "60D", "90D", "180D", "1Y"]:
        results = bdp_with_overrides(
            bbg, ["FJSK6 Comdty"], "IVOL_DELTA",
            {"IVOL_DELTA_LEVEL": "50", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL", "IVOL_MATURITY": mat},
        )
        v = results.get("FJSK6 Comdty")
        vs = f"{v:.2f}%" if v is not None else "—"
        print(f"  IVOL_MATURITY={mat:<5}  ATM={vs}")

    # ------------------------------------------------------------------
    # 4. Cross-instrument test (do overrides work for other commodities?)
    # ------------------------------------------------------------------
    print(f"\n{DIV}")
    print("4. IVOL_DELTA across instruments (50D Call, no IVOL_MATURITY)")
    print(f"{DIV}")

    cross_tickers = [
        "FJSK6 Comdty",    # TTF May26
        "COK6 Comdty",     # Brent May26
        "MZBK6 Comdty",    # EUA May26
        "QSK6 Comdty",     # Gasoil May26
        "XBK6 Comdty",     # RBOB May26
        "DETK6 Comdty",    # German Power May26
        "HGK6 Comdty",     # COMEX Copper May26
    ]

    results = bdp_with_overrides(
        bbg, cross_tickers, "IVOL_DELTA",
        {"IVOL_DELTA_LEVEL": "50", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL"},
    )
    for t in cross_tickers:
        v = results.get(t)
        vs = f"{v:.2f}%" if v is not None else "—"
        print(f"  {t:<20}  ATM 50D={vs}")

    # Also 25D call/put for RR
    results_c25 = bdp_with_overrides(
        bbg, cross_tickers, "IVOL_DELTA",
        {"IVOL_DELTA_LEVEL": "25", "IVOL_DELTA_PUT_OR_CALL": "IVOL_CALL"},
    )
    results_p25 = bdp_with_overrides(
        bbg, cross_tickers, "IVOL_DELTA",
        {"IVOL_DELTA_LEVEL": "25", "IVOL_DELTA_PUT_OR_CALL": "IVOL_PUT"},
    )
    print(f"\n  25D RR (call - put):")
    for t in cross_tickers:
        c = results_c25.get(t)
        p = results_p25.get(t)
        if c is not None and p is not None:
            rr = c - p
            print(f"  {t:<20}  25D_C={c:.2f}  25D_P={p:.2f}  RR={rr:+.2f}")
        else:
            print(f"  {t:<20}  25D_C={'—' if c is None else f'{c:.2f}'}  25D_P={'—' if p is None else f'{p:.2f}'}")

    # ------------------------------------------------------------------
    # 5. OPT_CHAIN on individual FJS per-contract tickers
    # ------------------------------------------------------------------
    print(f"\n{DIV}")
    print("5. OPT_CHAIN on individual FJS tickers (per-month chains)")
    print(f"{DIV}")

    for ticker, label in [
        ("FJSJ6 Comdty", "TTF Apr26"),
        ("FJSK6 Comdty", "TTF May26"),
        ("FJSM6 Comdty", "TTF Jun26"),
        ("FJSN6 Comdty", "TTF Q3-26"),
    ]:
        chain = opt_chain(bbg, ticker)
        if chain:
            print(f"  {ticker:<20} {label:<15} {len(chain):>5} options")
            print(f"    First 2: {chain[:2]}")
        else:
            print(f"  {ticker:<20} {label:<15} NO CHAIN")

    # Also test on futures tickers
    print(f"\n  OPT_CHAIN on TZT futures tickers:")
    for ticker, label in [
        ("TZTJ6 Comdty", "TTF Apr26 fut"),
        ("TZTK6 Comdty", "TTF May26 fut"),
    ]:
        chain = opt_chain(bbg, ticker)
        if chain:
            print(f"  {ticker:<20} {label:<15} {len(chain):>5} options")
            print(f"    First 2: {chain[:2]}")
        else:
            print(f"  {ticker:<20} {label:<15} NO CHAIN")

    # ------------------------------------------------------------------
    # 6. Quick test: IVOL_MONEYNESS with overrides (per-expiry?)
    # ------------------------------------------------------------------
    print(f"\n{DIV}")
    print("6. IVOL_MONEYNESS with overrides (per-expiry comparison)")
    print(f"{DIV}")

    for mat_label, ovr in [("no maturity", {}), ("30D", {"IVOL_MATURITY": "30D"})]:
        base_ovr = {"IVOL_MONEYNESS_LEVEL": "100.0"}
        base_ovr.update(ovr)
        results = bdp_with_overrides(bbg, ttf_tickers, "IVOL_MONEYNESS", base_ovr)
        vals = "  |  ".join(
            f"{t.split()[0]}: {v:.2f}%" if v is not None else f"{t.split()[0]}: —"
            for t, v in sorted(results.items())
        )
        print(f"  IVOL_MONEYNESS ATM ({mat_label}):  {vals}")

    print(f"\n{DIV}")
    print("DEBUG #4 COMPLETE")
    print(f"{DIV}")


if __name__ == "__main__":
    main()
