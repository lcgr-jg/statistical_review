"""
Dash dashboard for the Bloomberg-Powered Energy Options Morning Brief.

Interactive companion to the email report.  Reads cached metrics from the
latest run and presents:
  - Executive summary + cross-asset insights
  - Per-commodity tabs with contract tenor selector
  - Interactive Plotly charts (vol term structure, skew, OI by strike, price)
  - Cross-asset comparison tab
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

import dash
from dash import html, dcc, Input, Output, callback
import plotly.graph_objs as go

from . import config as cfg
from .analytics import InstrumentMetrics, ContractMetrics, MetricSnapshot
from .charts import (
    create_atm_vol_chart,
    create_term_structure_chart,
    create_skew_term_chart,
    create_oi_by_strike_chart,
    create_price_chart,
    create_cross_asset_vol_chart,
)

logger = logging.getLogger(__name__)

CACHE_DIR = Path(__file__).parent / cfg.DASHBOARD_CACHE_DIR


# ------------------------------------------------------------------
# Cache load / save
# ------------------------------------------------------------------

def _load_cached_data() -> tuple[dict[str, InstrumentMetrics], dict[str, str], str, str]:
    """
    Load cached metrics, narratives, executive summary, and cross-asset
    insights from the latest run.
    """
    cache_file = CACHE_DIR / "latest_brief.json"
    if not cache_file.exists():
        return {}, {}, "No data available. Run the morning brief pipeline first.", ""

    with open(cache_file, "r") as f:
        data = json.load(f)

    all_metrics: dict[str, InstrumentMetrics] = {}
    for name, raw in data.get("metrics", {}).items():
        im = InstrumentMetrics(
            instrument=raw.get("instrument", name),
            unit=raw.get("unit", ""),
            trade_date=raw.get("trade_date", ""),
        )

        # Reconstruct contracts
        for c_raw in raw.get("contracts", []):
            cm = ContractMetrics(
                ticker=c_raw.get("ticker", ""),
                label=c_raw.get("label", ""),
                tenor_type=c_raw.get("tenor_type", ""),
            )
            for field_name in [
                "price", "volume", "open_interest",
                "atm_vol", "vol_25d_rr", "vol_25d_bf",
                "vol_10d_rr", "vol_10d_bf",
                "call_oi", "put_oi", "call_volume", "put_volume", "pc_oi_ratio",
            ]:
                snap_data = c_raw.get(field_name, {})
                if isinstance(snap_data, dict):
                    setattr(cm, field_name, MetricSnapshot(**{
                        k: snap_data.get(k) for k in MetricSnapshot.__dataclass_fields__
                    }))
            cm.net_delta = c_raw.get("net_delta")
            cm.net_gamma = c_raw.get("net_gamma")
            cm.net_vega = c_raw.get("net_vega")
            cm.oi_by_strike = c_raw.get("oi_by_strike", [])
            im.contracts.append(cm)

        ts_raw = raw.get("vol_term_spread", {})
        if isinstance(ts_raw, dict):
            im.vol_term_spread = MetricSnapshot(**{
                k: ts_raw.get(k) for k in MetricSnapshot.__dataclass_fields__
            })

        im.price_series = raw.get("price_series", [])
        im.atm_vol_series = raw.get("atm_vol_series", [])
        im.skew_series = raw.get("skew_series", [])
        im.oi_series = raw.get("oi_series", [])
        all_metrics[name] = im

    narratives = data.get("narratives", {})
    exec_summary = data.get("executive_summary", "")
    cross_asset_narrative = data.get("cross_asset_narrative", "")

    return all_metrics, narratives, exec_summary, cross_asset_narrative


def save_cache(
    all_metrics: dict[str, InstrumentMetrics],
    narratives: dict[str, str],
    exec_summary: str,
    cross_asset_narrative: str = "",
):
    """Persist metrics and narratives to disk for the dashboard."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = CACHE_DIR / "latest_brief.json"

    data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "executive_summary": exec_summary,
        "cross_asset_narrative": cross_asset_narrative,
        "narratives": narratives,
        "metrics": {},
    }

    for name, im in all_metrics.items():
        d = im.to_dict()
        d["price_series"] = im.price_series
        d["atm_vol_series"] = im.atm_vol_series
        d["skew_series"] = im.skew_series
        d["oi_series"] = im.oi_series
        data["metrics"][name] = d

    with open(cache_file, "w") as f:
        json.dump(data, f, indent=2, default=str)

    logger.info("Dashboard cache saved to %s", cache_file)


# ------------------------------------------------------------------
# Dash helper components
# ------------------------------------------------------------------

def _change_cell(value: float | None):
    if value is None:
        return html.Td("—", style={"textAlign": "right", "fontFamily": "monospace", "color": "#999"})
    color = "#2e7d32" if value > 0 else ("#c62828" if value < 0 else "#333")
    return html.Td(f"{value:+.4f}", style={"textAlign": "right", "fontFamily": "monospace", "color": color})


def _value_cell(value: float | None):
    if value is None:
        return html.Td("—", style={"textAlign": "right", "fontFamily": "monospace", "color": "#999"})
    return html.Td(f"{value:,.4f}", style={"textAlign": "right", "fontFamily": "monospace"})


def _pctl_badge(pctl: float | None):
    if pctl is None:
        return ""
    if pctl <= 25:
        bg, color = "#e8f5e9", "#2e7d32"
    elif pctl >= 75:
        bg, color = "#ffebee", "#c62828"
    else:
        bg, color = "#fff3e0", "#e65100"
    return html.Span(
        f"{pctl:.0f}th",
        style={
            "backgroundColor": bg, "color": color, "padding": "1px 5px",
            "borderRadius": "3px", "fontSize": "10px", "fontWeight": "bold", "marginLeft": "4px",
        },
    )


def _metric_row_dash(label: str, snap: MetricSnapshot):
    return html.Tr([
        html.Td([label, _pctl_badge(snap.percentile_1y)], style={"fontWeight": "500"}),
        _value_cell(snap.current),
        _change_cell(snap.change_1d),
        _change_cell(snap.change_5d),
        _change_cell(snap.change_20d),
    ])


def _contract_panel(cm: ContractMetrics):
    """Build a Dash component for a single contract's metrics."""
    metric_table = html.Table(
        [
            html.Thead(html.Tr([
                html.Th("Metric", style={"textAlign": "left", "padding": "6px"}),
                html.Th("Current", style={"textAlign": "right", "padding": "6px"}),
                html.Th("1D Chg", style={"textAlign": "right", "padding": "6px"}),
                html.Th("5D Chg", style={"textAlign": "right", "padding": "6px"}),
                html.Th("20D Chg", style={"textAlign": "right", "padding": "6px"}),
            ])),
            html.Tbody([
                _metric_row_dash("Price", cm.price),
                _metric_row_dash("Futures Volume", cm.volume),
                _metric_row_dash("Futures OI", cm.open_interest),
                _metric_row_dash("ATM Vol", cm.atm_vol),
                _metric_row_dash("25D RR", cm.vol_25d_rr),
                _metric_row_dash("25D Butterfly", cm.vol_25d_bf),
                _metric_row_dash("10D RR", cm.vol_10d_rr),
                _metric_row_dash("10D Butterfly", cm.vol_10d_bf),
                _metric_row_dash("Call OI", cm.call_oi),
                _metric_row_dash("Put OI", cm.put_oi),
                _metric_row_dash("Call Volume", cm.call_volume),
                _metric_row_dash("Put Volume", cm.put_volume),
                _metric_row_dash("P/C OI Ratio", cm.pc_oi_ratio),
            ]),
        ],
        style={"width": "100%", "borderCollapse": "collapse", "fontSize": "12px", "marginBottom": "12px"},
    )

    greeks_line = ""
    if cm.net_delta is not None:
        greeks_line = html.Div(
            f"Net Delta: {cm.net_delta:.2f} | Net Gamma: {cm.net_gamma:.4f} | Net Vega: {cm.net_vega:.2f}",
            style={"fontSize": "11px", "color": "#666", "padding": "4px 0"},
        )

    return html.Div([
        html.Div(
            f"{cm.label} ({cm.tenor_type}) — {cm.ticker}",
            style={
                "backgroundColor": "#1b4f72", "color": "#e0e8f0",
                "padding": "6px 14px", "fontSize": "13px", "fontWeight": "600",
            },
        ),
        html.Div([metric_table, greeks_line], style={"padding": "10px 14px"}),
    ])


# ------------------------------------------------------------------
# Create Dash app
# ------------------------------------------------------------------

def create_dashboard() -> dash.Dash:
    all_metrics, narratives, exec_summary, cross_asset_narrative = _load_cached_data()

    app = dash.Dash(__name__)
    app.title = "Energy Options Morning Brief"

    last_update = datetime.now(timezone.utc).strftime("%A %d %B %Y, %H:%M UTC")

    # --- Per-instrument tabs ---
    instrument_tabs = []
    for name, im in all_metrics.items():
        narrative = narratives.get(name, "")

        contract_panels = [_contract_panel(c) for c in im.contracts]

        charts_div = html.Div([
            html.Div([
                dcc.Graph(figure=create_price_chart(im), style={"flex": "1 1 48%", "minWidth": "320px"}),
                dcc.Graph(figure=create_atm_vol_chart(im), style={"flex": "1 1 48%", "minWidth": "320px"}),
            ], style={"display": "flex", "flexWrap": "wrap", "gap": "8px"}),
            html.Div([
                dcc.Graph(figure=create_term_structure_chart(im), style={"flex": "1 1 48%", "minWidth": "320px"}),
                dcc.Graph(figure=create_skew_term_chart(im), style={"flex": "1 1 48%", "minWidth": "320px"}),
            ], style={"display": "flex", "flexWrap": "wrap", "gap": "8px"}),
            dcc.Graph(figure=create_oi_by_strike_chart(im)),
        ], style={"padding": "8px"})

        tab_content = html.Div([
            html.Div(
                f"{name} — {im.unit} | {im.trade_date}",
                style={
                    "backgroundColor": "#0d1b2a", "color": "white",
                    "padding": "12px 16px", "fontSize": "18px", "fontWeight": "bold",
                },
            ),
            *contract_panels,
            html.Div(
                narrative,
                style={
                    "padding": "10px 16px", "backgroundColor": "#fafafa",
                    "borderTop": "1px solid #eee", "fontSize": "13px", "lineHeight": "1.6",
                },
            ) if narrative else html.Div(),
            charts_div,
        ])

        instrument_tabs.append(dcc.Tab(
            label=name, value=name, children=[tab_content],
            style={"backgroundColor": "lightgrey"},
        ))

    # --- Cross-asset tab ---
    xa_tab = dcc.Tab(
        label="Cross-Asset",
        value="__cross_asset__",
        children=[html.Div([
            html.Div(
                "Cross-Asset Comparison",
                style={
                    "backgroundColor": "#0d1b2a", "color": "white",
                    "padding": "12px 16px", "fontSize": "18px", "fontWeight": "bold",
                },
            ),
            html.Div([
                html.H3("Cross-Market Insights", style={"fontSize": "14px", "color": "#5d4037", "margin": "0 0 6px 0"}),
                html.P(cross_asset_narrative, style={"fontSize": "13px", "lineHeight": "1.6"}),
            ], style={"backgroundColor": "#fff8e1", "padding": "14px 20px", "margin": "16px"}),
            dcc.Graph(figure=create_cross_asset_vol_chart(all_metrics)),
        ])],
        style={"backgroundColor": "lightgrey"},
    )

    app.layout = html.Div([
        html.Div(
            f"Last Update: {last_update}",
            style={"textAlign": "center", "fontSize": "12px", "color": "gray", "margin": "8px 0"},
        ),
        html.Div(
            style={"backgroundColor": "#0d1b2a", "padding": "15px", "textAlign": "center"},
            children=[html.H1("Energy Options Morning Brief", style={"color": "white", "margin": 0, "fontSize": "24px"})],
        ),

        # Executive summary
        html.Div([
            html.H3("Executive Summary", style={
                "fontSize": "14px", "color": "#0d1b2a", "margin": "0 0 8px 0",
                "textTransform": "uppercase", "letterSpacing": "1px",
            }),
            html.P(exec_summary, style={"fontSize": "13px", "lineHeight": "1.6", "margin": 0}),
        ], style={
            "backgroundColor": "#eef2f8", "borderLeft": "4px solid #1b4f72",
            "padding": "16px 24px", "margin": "20px 30px",
        }),

        html.Div(
            style={"padding": "0 30px 30px 30px"},
            children=[
                dcc.Tabs(
                    id="main-tabs",
                    value=list(all_metrics.keys())[0] if all_metrics else "__cross_asset__",
                    children=[*instrument_tabs, xa_tab],
                    persistence=True,
                    persistence_type="session",
                    persisted_props=["value"],
                    style={"borderRadius": "8px", "padding": "5px"},
                ),
            ],
        ),
    ])

    return app


def run_dashboard():
    """Entry point to run the dashboard standalone."""
    app = create_dashboard()
    app.run(debug=True, port=cfg.DASHBOARD_PORT, use_reloader=False)


if __name__ == "__main__":
    import sys
    _pkg_parent = str(Path(__file__).resolve().parent.parent)
    if _pkg_parent not in sys.path:
        sys.path.insert(0, _pkg_parent)

    from option_morning_brief.dashboard import run_dashboard as _run
    _run()
