"""Quick test to verify the Anthropic API key is valid."""

from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

import anthropic

client = anthropic.Anthropic()

try:
    resp = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=50,
        messages=[{"role": "user", "content": "Say hello in one sentence."}],
    )
    print("API key is valid.")
    print(f"Response: {resp.content[0].text}")
except anthropic.AuthenticationError as e:
    print(f"API key is INVALID: {e}")
except Exception as e:
    print(f"Other error: {e}")
