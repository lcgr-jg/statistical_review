"""
Debug script to check Bloomberg data availability for every instrument.

Checks:
  1. Ticker generation — what tickers are being built
  2. BDH futures — does each ticker return price/volume/OI history?
  3. BDP vol surface — which fields come back non-null per ticker?
  4. BDS option chains — does OPT_CHAIN return options?
  5. Vol surface ticker mapping — are vol queries hitting the right ticker?

Run from eu_reports/:
    python -m option_morning_brief.debug_data
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent / ".env")

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from option_morning_brief import config as cfg
from option_morning_brief.bbg_tickers import all_contract_tickers, ContractSpec

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)

SEPARATOR = "=" * 72


def main():
    on_server = os.environ.get("BLOOMBERG_ON_SERVER", "true").lower() == "true"

    from jain_commods.core.interfaces.bloomberg import BBGQuery
    bbg = BBGQuery(p_on_server=on_server)

    contracts = all_contract_tickers()

    # ──────────────────────────────────────────────────────────────
    # 1. TICKER GENERATION
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("1. TICKER GENERATION")
    print(SEPARATOR)
    for inst_key, specs in contracts.items():
        print(f"\n  {inst_key} ({len(specs)} contracts):")
        for s in specs:
            vol_note = ""
            if s.vol_surface_ticker != s.ticker:
                vol_note = f"  [vol→{s.vol_surface_ticker}]"
            opt_note = ""
            if s.opt_chain_ticker != s.ticker:
                opt_note = f"  [opt→{s.opt_chain_ticker}]"
            print(f"    {s.label:8s} {s.tenor_type:10s} "
                  f"ticker={s.ticker:22s}{vol_note}{opt_note}")

    # ──────────────────────────────────────────────────────────────
    # 2. BDH FUTURES — test front contract per instrument
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("2. BDH FUTURES HISTORY (front contract, last 5 days)")
    print(SEPARATOR)
    end_dt = datetime.now()
    start_dt = end_dt - timedelta(days=10)

    for inst_key, specs in contracts.items():
        front = specs[0]
        print(f"\n  {inst_key} — {front.ticker}")
        try:
            df = bbg.fetch_hist(
                p_ticker=[front.ticker],
                p_field=["PX_LAST", "VOLUME", "OPEN_INT"],
                p_start=start_dt,
                p_end=end_dt,
                p_pd_datetime=True,
            )
            if df is not None and not df.empty:
                cols = list(df.columns)
                print(f"    OK: {len(df)} rows, cols={cols}")
                last = df.iloc[-1]
                for c in cols:
                    print(f"      {c}: {last[c]}")
            else:
                print("    FAIL: no data returned")
        except Exception as e:
            print(f"    ERROR: {e}")

    # ──────────────────────────────────────────────────────────────
    # 3. BDP VOL SURFACE — test front contract per instrument
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("3. BDP VOL SURFACE (front contract)")
    print(SEPARATOR)

    all_vol_fields = cfg.VOL_SURFACE_BDP_FIELDS + cfg.VOL_SURFACE_FALLBACK_FIELDS

    for inst_key, specs in contracts.items():
        front = specs[0]
        vol_ticker = front.vol_surface_ticker
        fut_ticker = front.ticker
        ticker_note = f" (vol ticker: {vol_ticker})" if vol_ticker != fut_ticker else ""
        print(f"\n  {inst_key} — {vol_ticker}{ticker_note}")

        try:
            df = bbg.fetch_live(
                tickers=[vol_ticker],
                fields=all_vol_fields,
            )
            if df is not None and not df.empty:
                row = df.iloc[0]
                for field in all_vol_fields:
                    val = row.get(field)
                    status = "OK" if val is not None and str(val) != "nan" else "MISSING"
                    print(f"    {status:8s} {field}: {val}")
            else:
                print("    FAIL: no data returned at all")
        except Exception as e:
            print(f"    ERROR: {e}")

    # ──────────────────────────────────────────────────────────────
    # 4. BDS OPTION CHAINS — test front contract per instrument
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("4. BDS OPTION CHAINS (front contract)")
    print(SEPARATOR)

    import blpapi

    for inst_key, specs in contracts.items():
        front = specs[0]
        inst_cfg = cfg.INSTRUMENTS[inst_key]
        opt_ticker = front.opt_chain_ticker
        print(f"\n  {inst_key} — querying OPT_CHAIN on {opt_ticker}")

        try:
            session = bbg.session
            service = session.getService("//blp/refdata")
            request = service.createRequest("ReferenceDataRequest")
            request.getElement("securities").appendValue(opt_ticker)
            request.getElement("fields").appendValue("OPT_CHAIN")
            session.sendRequest(request)

            option_tickers: list[str] = []
            while True:
                event = session.nextEvent(5000)
                for msg in event:
                    if not msg.hasElement("securityData"):
                        continue
                    sec_data_array = msg.getElement("securityData")
                    for i in range(sec_data_array.numValues()):
                        sec_data = sec_data_array.getValueAsElement(i)
                        if not sec_data.hasElement("fieldData"):
                            continue
                        field_data = sec_data.getElement("fieldData")
                        if not field_data.hasElement("OPT_CHAIN"):
                            continue
                        chain = field_data.getElement("OPT_CHAIN")
                        for j in range(chain.numValues()):
                            row = chain.getValueAsElement(j)
                            if row.hasElement("Security Description"):
                                ticker = row.getElementAsString("Security Description")
                                option_tickers.append(ticker)
                if event.eventType() == blpapi.Event.RESPONSE:
                    break

            if option_tickers:
                print(f"    OK: {len(option_tickers)} options found")
                print(f"    First 5: {option_tickers[:5]}")
                print(f"    Last 5:  {option_tickers[-5:]}")
            else:
                print("    FAIL: no options returned")

                if inst_cfg.opt_chain_ticker and inst_cfg.opt_chain_ticker != opt_ticker:
                    alt = inst_cfg.opt_chain_ticker
                    print(f"    Trying product-level ticker {alt}...")
                    request2 = service.createRequest("ReferenceDataRequest")
                    request2.getElement("securities").appendValue(alt)
                    request2.getElement("fields").appendValue("OPT_CHAIN")
                    session.sendRequest(request2)
                    alt_tickers: list[str] = []
                    while True:
                        event = session.nextEvent(5000)
                        for msg in event:
                            if not msg.hasElement("securityData"):
                                continue
                            sda = msg.getElement("securityData")
                            for i in range(sda.numValues()):
                                sd = sda.getValueAsElement(i)
                                if not sd.hasElement("fieldData"):
                                    continue
                                fd = sd.getElement("fieldData")
                                if not fd.hasElement("OPT_CHAIN"):
                                    continue
                                ch = fd.getElement("OPT_CHAIN")
                                for j in range(ch.numValues()):
                                    r = ch.getValueAsElement(j)
                                    if r.hasElement("Security Description"):
                                        alt_tickers.append(
                                            r.getElementAsString("Security Description"))
                        if event.eventType() == blpapi.Event.RESPONSE:
                            break
                    if alt_tickers:
                        print(f"    ALT OK: {len(alt_tickers)} options via {alt}")
                        print(f"    First 5: {alt_tickers[:5]}")
                    else:
                        print(f"    ALT also returned nothing")

        except Exception as e:
            print(f"    ERROR: {e}")

    # ──────────────────────────────────────────────────────────────
    # 5. QUICK TICKER TESTS — try known-good tickers to verify BBG
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("5. MANUAL TICKER SPOT CHECKS")
    print(SEPARATOR)

    spot_checks = [
        ("DET1 Comdty",  "German Power front month"),
        ("DEQ1 Comdty",  "German Power front quarter"),
        ("JXY1 Comdty",  "German Power front year"),
        ("DETJ6 Comdty", "German Power Apr26 specific"),
        ("DETK6 Comdty", "German Power May26 specific"),
        ("LCA1 Comdty",  "Copper front month"),
        ("LCAJ6 Comdty", "Copper Apr26 specific"),
        ("LAA1 Comdty",  "Aluminium front month"),
        ("LAAJ6 Comdty", "Aluminium Apr26 specific"),
        ("FJSA Comdty",  "TTF options product-level"),
        ("FJSK6 Comdty", "TTF May26 options ticker"),
        ("MZBA Comdty",  "EUA options product-level"),
        ("MZBJ26 Comdty", "EUA Apr26 options (2-digit year)"),
        ("MZBJ6 Comdty", "EUA Apr26 options (1-digit year)"),
        ("COK6 Comdty",  "Brent May26"),
    ]

    for ticker, desc in spot_checks:
        try:
            df = bbg.fetch_live(
                tickers=[ticker],
                fields=["PX_LAST", "30DAY_IMPVOL_100.0%MNY_DF"],
            )
            if df is not None and not df.empty:
                row = df.iloc[0]
                px = row.get("PX_LAST")
                iv = row.get("30DAY_IMPVOL_100.0%MNY_DF")
                px_s = f"{px:.4f}" if px is not None and str(px) != "nan" else "—"
                iv_s = f"{iv:.2f}%" if iv is not None and str(iv) != "nan" else "—"
                print(f"  {ticker:22s} {desc:40s} PX={px_s:>12s}  IV={iv_s}")
            else:
                print(f"  {ticker:22s} {desc:40s} NO DATA")
        except Exception as e:
            print(f"  {ticker:22s} {desc:40s} ERROR: {e}")

    # ──────────────────────────────────────────────────────────────
    # 6. SUMMARY
    # ──────────────────────────────────────────────────────────────
    print(f"\n{SEPARATOR}")
    print("DEBUG COMPLETE")
    print(SEPARATOR)
    print("\nKey things to check in output above:")
    print("  - Section 2: Which instruments get BDH price data?")
    print("  - Section 3: Which vol surface fields return non-NaN?")
    print("    (If 30DAY_IMPVOL is same for ALL tenors, it may be")
    print("     returning generic vol not per-contract vol)")
    print("  - Section 4: Which option chains return options?")
    print("  - Section 5: Do the German Power DET tickers work?")
    print("  - Section 5: Do Copper/Aluminium LCA/LAA tickers work?")


if __name__ == "__main__":
    main()
