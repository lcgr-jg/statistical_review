"""
Skew change section: side-by-side 1D and 5D heatmap tables of vol surface metric changes.
"""

from __future__ import annotations

from .. import config as cfg
from .base import (
    DataBlock,
    PipelineData,
    ReportSection,
    SectionResult,
    _fmt,
    header_cell,
    heatmap_cell,
    md_table,
    row_header_cell,
    section_title_html,
    wrap_table,
)


class SkewChangeSection(ReportSection):
    name = "skew_change"
    order = 20

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        out: dict[str, SectionResult] = {}
        metric_specs: list[tuple[str, str]] = [
            ("atm_vol", "ATM Vol"),
            ("vol_25d_rr", "25D RR"),
            ("vol_25d_bf", "25D BF"),
            ("vol_10d_rr", "10D RR"),
            ("vol_10d_bf", "10D BF"),
        ]

        for inst_key, im in data.all_metrics.items():
            inst_cfg = cfg.INSTRUMENTS.get(inst_key)
            display_name = inst_cfg.display_name if inst_cfg else inst_key

            hdr = "<tr>" + row_header_cell("Contract") + "".join(
                header_cell(label) for _, label in metric_specs
            ) + "</tr>"

            rows_1d: list[str] = []
            rows_5d: list[str] = []
            change_events: list[tuple[float, float, str, str, str]] = []

            for cm in im.contracts:
                label = cm.label or cm.ticker
                cells_1d = []
                cells_5d = []
                for attr, mlabel in metric_specs:
                    snap = getattr(cm, attr)
                    c1 = snap.change_1d
                    c5 = snap.change_5d
                    cells_1d.append(heatmap_cell(c1, scale=3.0))
                    cells_5d.append(heatmap_cell(c5, scale=3.0))
                    if c1 is not None:
                        change_events.append((abs(c1), c1, label, mlabel, "1D"))
                    if c5 is not None:
                        change_events.append((abs(c5), c5, label, mlabel, "5D"))
                rows_1d.append("<tr>" + row_header_cell(label) + "".join(cells_1d) + "</tr>")
                rows_5d.append("<tr>" + row_header_cell(label) + "".join(cells_5d) + "</tr>")

            tables_wrap = (
                '<div style="display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap;">'
                + wrap_table(hdr + "".join(rows_1d), title="1D Change")
                + wrap_table(hdr + "".join(rows_5d), title="5D Change")
                + "</div>"
            )

            html = section_title_html("Skew & surface changes") + tables_wrap

            change_events.sort(key=lambda t: t[0], reverse=True)
            top = change_events[:12]

            md_headers = ["Contract", "Metric", "Horizon", "Change"]
            md_rows: list[list[str]] = []
            for _abs_v, signed, contract, metric, hz in top:
                md_rows.append([contract, metric, hz, f"{signed:+.2f}"])

            md_content = md_table(md_headers, md_rows) if md_rows else "(no change data)"
            src = "ICE" if (inst_cfg and inst_cfg.has_ice_options) else "Bloomberg"
            block = DataBlock(
                block_type="table",
                theme="vol_surface",
                domain=cfg.INSTRUMENT_DOMAINS.get(inst_key, ""),
                product=inst_key,
                source=src,
                source_type="primary",
                title=f"Vol Surface Changes — {display_name}",
                content=md_content,
                tags=["atm_vol", "25d_RR", "25d_BF", "10d_RR", "10d_BF"],
            )

            out[inst_key] = SectionResult(
                html=html,
                llm_context=f"## Vol Surface Changes — {display_name} (top {len(top)})\n\n{md_content}\n",
                figures={},
                blocks=[block],
            )

        return out
