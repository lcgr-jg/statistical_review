"""
Cross-asset section: global heatmap of front-contract metrics and ATM vol bar chart.
"""

from __future__ import annotations

import plotly.graph_objs as go

from .. import config as cfg
from .base import (
    COLORS,
    LAYOUT_DEFAULTS,
    PRO_LEGEND,
    DataBlock,
    PipelineData,
    ReportSection,
    SectionResult,
    _fmt,
    chart_to_img_tag,
    empty_figure,
    header_cell,
    heatmap_cell,
    md_table,
    pctl_cell,
    pro_title,
    row_header_cell,
    section_title_html,
    value_cell,
    wrap_table,
)


def _price_change_pct_1d(current: float | None, change_1d: float | None) -> float | None:
    if current is None or change_1d is None:
        return None
    prev = current - change_1d
    if prev == 0 or abs(prev) < 1e-12:
        return None
    return 100.0 * change_1d / prev


class CrossAssetSection(ReportSection):
    name = "cross_asset"
    order = 5  # renders first in email (before per-instrument sections)

    @property
    def is_per_instrument(self) -> bool:
        return False

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        ca = data.cross_asset or {}

        inst_keys = [k for k in cfg.INSTRUMENTS if k in data.all_metrics]

        header_cols = (
            "Instrument",
            "Price (1D%)",
            "ATM Vol",
            "ATM 1D Chg",
            "25D RR",
            "Vol Pctl",
            "Volume Pctl",
        )
        header_row = "<tr>" + "".join(header_cell(h) for h in header_cols) + "</tr>"

        body_rows: list[str] = []

        for inst_key in inst_keys:
            im = data.all_metrics[inst_key]
            front = im.front
            if front is None:
                body_rows.append(
                    "<tr>"
                    + row_header_cell(inst_key)
                    + "".join(
                        f'<td style="padding:4px 8px;text-align:right;font-size:12px;'
                        f'font-family:\'Courier New\',monospace;border:1px solid #e0e0e0;'
                        f'background:#f9f9f9;color:#bbb;">—</td>'
                        for _ in range(6)
                    )
                    + "</tr>"
                )
                continue

            price = front.price
            atm = front.atm_vol
            rr = front.vol_25d_rr
            vol = front.volume

            px_pct = _price_change_pct_1d(price.current, price.change_1d)

            body_rows.append(
                "<tr>"
                + row_header_cell(inst_key)
                + heatmap_cell(px_pct, scale=3.0, fmt="+.2f")
                + value_cell(atm.current, fmt=".1f")
                + heatmap_cell(atm.change_1d, scale=3.0)
                + heatmap_cell(rr.current, scale=5.0)
                + pctl_cell(atm.percentile_1y)
                + pctl_cell(vol.percentile_1y)
                + "</tr>"
            )

        table_inner = header_row + "".join(body_rows)
        table_html = wrap_table(table_inner)

        # Plotly: grouped bars — ATM level vs 1D change (secondary y-axis for scale)
        fig: go.Figure
        bx: list[str] = []
        batm: list[float] = []
        bchg: list[float] = []
        chg_colors: list[str] = []
        for inst_key in inst_keys:
            im = data.all_metrics[inst_key]
            front = im.front
            if front is None:
                continue
            av = front.atm_vol.current
            dc = front.atm_vol.change_1d
            if av is None:
                continue
            bx.append(inst_key)
            batm.append(float(av))
            if dc is not None:
                fv = float(dc)
                bchg.append(fv)
                chg_colors.append("#2ca02c" if fv >= 0 else "#d62728")
            else:
                bchg.append(0.0)
                chg_colors.append("#999999")

        if bx:
            fig = go.Figure(
                data=[
                    go.Bar(
                        name="ATM vol",
                        x=bx,
                        y=batm,
                        marker_color="rgba(31,119,180,0.75)",
                        yaxis="y",
                        hovertemplate="%{x} — %{y:.1f}%<extra>ATM Vol</extra>",
                    ),
                    go.Bar(
                        name="ATM 1D Δ",
                        x=bx,
                        y=bchg,
                        marker_color=chg_colors,
                        yaxis="y2",
                        hovertemplate="%{x} — %{y:+.2f}pts<extra>1D Δ</extra>",
                    ),
                ]
            )
            layout_kw = {
                **LAYOUT_DEFAULTS,
                "title": pro_title("Cross-Asset ATM Vol"),
                "barmode": "group",
                "xaxis_title": "",
                "width": 740,
                "yaxis": dict(
                    title="ATM implied vol (%)",
                    side="left",
                    showgrid=True,
                    gridcolor="#e5e5e5",
                ),
                "yaxis2": dict(
                    title="1D change (pts)",
                    overlaying="y",
                    side="right",
                    showgrid=False,
                ),
                "legend": PRO_LEGEND,
            }
            fig.update_layout(**layout_kw)
        else:
            fig = empty_figure("Cross-Asset ATM Vol")

        img_tag = chart_to_img_tag(fig, alt="Cross-asset ATM vol")
        html = (
            section_title_html("Cross-Asset Dashboard")
            + table_html
            + (f'<div style="text-align:center;margin:8px 0;">{img_tag}</div>' if img_tag else "")
        )

        # Cross-asset Markdown table
        md_headers = ["Product", "Price 1D%", "ATM Vol", "ATM Δ1d", "25D RR", "Vol Pctl", "Vol Z"]
        md_rows: list[list[str]] = []
        for ik in inst_keys:
            im_r = data.all_metrics[ik]
            f = im_r.front
            if f is None:
                continue
            px_pct_r = _price_change_pct_1d(f.price.current, f.price.change_1d)
            v_pctl = f"{f.volume.percentile_1y:.0f}th" if f.volume.percentile_1y is not None else "—"
            atm_pctl = f"{f.atm_vol.percentile_1y:.0f}th" if f.atm_vol.percentile_1y is not None else "—"
            md_rows.append([
                ik,
                _fmt(px_pct_r, "+.2f"),
                _fmt(f.atm_vol.current, ".1f"),
                _fmt(f.atm_vol.change_1d, "+.1f"),
                _fmt(f.vol_25d_rr.current, "+.1f"),
                atm_pctl,
                v_pctl,
            ])

        xa_table = md_table(md_headers, md_rows) if md_rows else ""

        # Anomalies and divergences as structured text
        anomalies = ca.get("anomalies") or []
        divergences = ca.get("divergences") or []
        context_parts = [xa_table] if xa_table else []

        if anomalies:
            anom_lines = ["**Anomalies:**"]
            for a in anomalies:
                d = a.get("description")
                if d:
                    anom_lines.append(f"- {d}")
            context_parts.append("\n".join(anom_lines))

        if divergences:
            div_lines = ["**Divergences:**"]
            for d in divergences:
                desc = d.get("description", "")
                if desc:
                    div_lines.append(f"- {desc}")
            context_parts.append("\n".join(div_lines))

        vcm = ca.get("vol_correlation_matrix")
        if vcm is not None and hasattr(vcm, "index") and hasattr(vcm, "columns"):
            corr_parts: list[str] = []
            idx = list(vcm.index)
            cols = list(vcm.columns)
            for i, a in enumerate(idx):
                for j, b in enumerate(cols):
                    if i < j:
                        corr_parts.append(f"{a}-{b} {float(vcm.loc[a, b]):.2f}")
            if corr_parts:
                context_parts.append("**20D Price Correlation:** " + ", ".join(corr_parts))

        full_content = "\n\n".join(context_parts) if context_parts else "(no cross-asset data)"
        block = DataBlock(
            block_type="table",
            theme="cross_asset",
            domain="",
            product="",
            source="Bloomberg",
            source_type="primary",
            title="Cross-Asset Dashboard",
            content=full_content,
            tags=["atm_vol", "25d_RR", "settlement", "total_volume"],
        )

        return {
            "__global__": SectionResult(
                html=html,
                llm_context=f"## Cross-Asset Dashboard\n\n{full_content}\n",
                figures={"cross_asset": fig},
                blocks=[block],
            ),
        }
