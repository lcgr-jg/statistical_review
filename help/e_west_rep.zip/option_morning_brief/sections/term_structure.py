"""
ATM vol term structure: line + 1D change bars per instrument.
"""

from __future__ import annotations

import plotly.graph_objs as go

from .. import config as cfg
from .base import (
    COLORS,
    LAYOUT_DEFAULTS,
    PRO_LEGEND,
    DataBlock,
    PipelineData,
    ReportSection,
    SectionResult,
    _fmt,
    chart_to_img_tag,
    empty_figure,
    header_cell,
    md_table,
    pro_title,
    row_header_cell,
    section_title_html,
    value_cell,
    wrap_table,
)


class TermStructureSection(ReportSection):
    name = "term_structure"
    order = 30

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        out: dict[str, SectionResult] = {}
        for inst_key, im in data.all_metrics.items():
            inst_cfg = cfg.INSTRUMENTS.get(inst_key)
            display_name = inst_cfg.display_name if inst_cfg else inst_key

            x_labels: list[str] = []
            y_atm: list[float] = []
            y_chg: list[float | None] = []

            for cm in im.contracts:
                label = cm.label or cm.ticker
                atm = cm.atm_vol.current
                chg = cm.atm_vol.change_1d
                if atm is None:
                    continue
                x_labels.append(label)
                y_atm.append(float(atm))
                y_chg.append(chg)

            bar_colors = [
                "#2ca02c" if c is not None and c >= 0 else ("#d62728" if c is not None else "#bdbdbd")
                for c in y_chg
            ]
            bar_heights = [0.0 if c is None else float(c) for c in y_chg]

            if x_labels and y_atm:
                color = COLORS[0]
                fig = go.Figure(
                    data=[
                        go.Scatter(
                            x=x_labels,
                            y=y_atm,
                            mode="lines+markers",
                            line=dict(color=color, width=2.5),
                            marker=dict(size=8, color=color, line=dict(color="white", width=1)),
                            name="ATM vol",
                            yaxis="y",
                            hovertemplate="%{x} — %{y:.1f}%<extra>ATM</extra>",
                        ),
                        go.Bar(
                            x=x_labels,
                            y=bar_heights,
                            marker_color=bar_colors,
                            name="1D Δ",
                            yaxis="y2",
                            opacity=0.75,
                            hovertemplate="%{x} — %{y:+.2f}pts<extra>1D Δ</extra>",
                        ),
                    ]
                )
                layout_kw = {
                    **LAYOUT_DEFAULTS,
                    "title": pro_title(f"{display_name} — ATM Vol Term Structure"),
                    "xaxis_title": "Contract",
                    "yaxis": dict(
                        title="ATM Vol (%)",
                        side="left",
                        showgrid=True,
                        gridcolor="#e5e5e5",
                    ),
                    "yaxis2": dict(
                        title="1D Δ (pts)",
                        overlaying="y",
                        side="right",
                        showgrid=False,
                        zeroline=True,
                        zerolinewidth=1,
                        zerolinecolor="#d0d0d0",
                    ),
                    "showlegend": True,
                    "legend": PRO_LEGEND,
                }
                fig.update_layout(**layout_kw)
            else:
                fig = empty_figure(f"{display_name} — ATM Vol Term Structure")

            img_tag = chart_to_img_tag(fig, alt=f"{display_name} ATM vol term structure")

            if img_tag:
                chart_html = f'<div style="text-align:center;margin:8px 0;">{img_tag}</div>'
            else:
                hdr = (
                    "<tr>"
                    + header_cell("Contract")
                    + header_cell("ATM Vol")
                    + header_cell("1D Δ")
                    + "</tr>"
                )
                rows: list[str] = []
                for cm in im.contracts:
                    label = cm.label or cm.ticker
                    atm = cm.atm_vol.current
                    chg = cm.atm_vol.change_1d
                    if atm is None:
                        continue
                    rows.append(
                        "<tr>"
                        + row_header_cell(label)
                        + value_cell(atm, fmt=".1f")
                        + value_cell(chg, fmt="+.2f")
                        + "</tr>"
                    )
                chart_html = (
                    wrap_table(hdr + "".join(rows), title="ATM vol term structure (table)")
                    if rows
                    else ""
                )

            html = section_title_html("ATM vol term structure") + chart_html

            md_headers = ["Contract", "ATM Vol", "Δ1d"]
            md_rows: list[list[str]] = []
            for cm in im.contracts:
                atm = cm.atm_vol.current
                if atm is None:
                    continue
                md_rows.append([
                    cm.label or cm.ticker,
                    _fmt(atm, ".1f"),
                    _fmt(cm.atm_vol.change_1d, "+.1f"),
                ])

            ts = im.vol_term_spread.current
            front_atm = im.contracts[0].atm_vol.current if im.contracts else None
            back_atm = im.contracts[-1].atm_vol.current if im.contracts else None

            summary_parts: list[str] = []
            if front_atm is not None and back_atm is not None:
                summary_parts.append(
                    f"Front ATM: {front_atm:.1f}% | Back ATM: {back_atm:.1f}%"
                )
            if ts is not None:
                shape = "contango" if ts > 0 else ("backwardation" if ts < 0 else "flat")
                summary_parts.append(f"Term spread: {ts:+.1f}pts ({shape})")

            candidates: list[tuple[float, str, float]] = []
            for cm in im.contracts:
                c = cm.atm_vol.change_1d
                if c is not None:
                    candidates.append((abs(c), cm.label or cm.ticker, c))
            if candidates:
                candidates.sort(key=lambda t: t[0], reverse=True)
                _, lab, signed = candidates[0]
                summary_parts.append(f"Largest 1D move: {lab} {signed:+.1f}pts")

            md_content = md_table(md_headers, md_rows) if md_rows else "(no data)"
            summary_line = " | ".join(summary_parts)
            full_content = f"{md_content}\n\n{summary_line}" if summary_line else md_content

            src = "ICE" if (inst_cfg and inst_cfg.has_ice_options) else "Bloomberg"
            block = DataBlock(
                block_type="table",
                theme="vol_term_structure",
                domain=cfg.INSTRUMENT_DOMAINS.get(inst_key, ""),
                product=inst_key,
                source=src,
                source_type="primary",
                title=f"ATM Vol Term Structure — {display_name}",
                content=full_content,
                tags=["atm_vol", "vol_term_spread"],
            )

            out[inst_key] = SectionResult(
                html=html,
                llm_context=f"## ATM Vol Term Structure — {display_name}\n\n{full_content}\n",
                figures={"term_structure": fig},
                blocks=[block],
            )

        return out
