"""
Vol surface section: per-contract ATM, skew, butterfly, and OI table plus term-structure chart.
"""

from __future__ import annotations

import plotly.graph_objs as go

from .. import config as cfg
from .base import (
    ReportSection,
    PipelineData,
    SectionResult,
    DataBlock,
    LAYOUT_DEFAULTS,
    PRO_LEGEND,
    COLORS,
    _fmt,
    empty_figure,
    header_cell,
    md_table,
    pro_title,
    row_header_cell,
    value_cell,
    heatmap_cell,
    wrap_table,
    section_title_html,
    chart_to_img_tag,
)


class VolSurfaceSection(ReportSection):
    name = "vol_surface"
    order = 10

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        out: dict[str, SectionResult] = {}
        for inst_key, im in data.all_metrics.items():
            inst_cfg = cfg.INSTRUMENTS.get(inst_key)
            display_name = inst_cfg.display_name if inst_cfg else inst_key

            header_cols = (
                "Contract",
                "ATM Vol",
                "25D RR",
                "25D BF",
                "P/C Ratio",
                "Call OI",
                "Put OI",
            )
            header_row = "<tr>" + "".join(header_cell(h) for h in header_cols) + "</tr>"

            body_rows: list[str] = []
            x_labels: list[str] = []
            y_atm: list[float] = []

            for cm in im.contracts:
                label = cm.label or cm.ticker
                rr = cm.vol_25d_rr.current
                body_rows.append(
                    "<tr>"
                    + row_header_cell(label)
                    + value_cell(cm.atm_vol.current, fmt=".1f")
                    + heatmap_cell(rr, scale=5.0)
                    + value_cell(cm.vol_25d_bf.current, fmt=".2f")
                    + value_cell(cm.pc_oi_ratio.current, fmt=".2f")
                    + value_cell(cm.call_oi.current, fmt=".0f")
                    + value_cell(cm.put_oi.current, fmt=".0f")
                    + "</tr>"
                )
                if cm.atm_vol.current is not None:
                    x_labels.append(label)
                    y_atm.append(float(cm.atm_vol.current))

            table_html = wrap_table(header_row + "".join(body_rows), title="Vol surface")

            if y_atm:
                color = COLORS[0]
                fig = go.Figure(
                    data=[
                        go.Scatter(
                            x=x_labels,
                            y=y_atm,
                            mode="lines+markers",
                            line=dict(color=color, width=2),
                            marker=dict(size=8, color=color, line=dict(color="white", width=1)),
                            name="ATM vol",
                            hovertemplate="%{x} — %{y:.1f}%<extra></extra>",
                        )
                    ]
                )
                fig.update_layout(
                    title=pro_title(f"{display_name} — Vol Surface"),
                    xaxis_title="Contract",
                    yaxis_title="ATM implied vol (%)",
                    showlegend=False,
                    **LAYOUT_DEFAULTS,
                )
            else:
                fig = empty_figure(f"{display_name} — Vol Surface")

            md_rows: list[list[str]] = []
            for cm in im.contracts:
                label = cm.label or cm.ticker
                pctl_s = f"{cm.atm_vol.percentile_1y:.0f}th" if cm.atm_vol.percentile_1y is not None else "—"
                md_rows.append([
                    label,
                    _fmt(cm.atm_vol.current, ".1f"),
                    _fmt(cm.atm_vol.change_1d, "+.1f"),
                    pctl_s,
                    _fmt(cm.vol_25d_rr.current, "+.1f"),
                    _fmt(cm.vol_25d_bf.current, "+.1f"),
                    _fmt(cm.pc_oi_ratio.current, ".2f"),
                    _fmt(cm.call_oi.current, ",.0f"),
                    _fmt(cm.put_oi.current, ",.0f"),
                ])

            md_headers = ["Contract", "ATM Vol", "Δ1d", "Pctl", "25D RR", "25D BF", "P/C", "Call OI", "Put OI"]
            md_content = md_table(md_headers, md_rows)
            src = "ICE" if (inst_cfg and inst_cfg.has_ice_options) else "Bloomberg"
            block = DataBlock(
                block_type="table",
                theme="vol_surface",
                domain=cfg.INSTRUMENT_DOMAINS.get(inst_key, ""),
                product=inst_key,
                source=src,
                source_type="primary",
                title=f"Options Vol Surface — {display_name}",
                content=md_content,
                tags=["atm_vol", "25d_RR", "25d_BF", "call_OI", "put_OI", "put_call_ratio"],
            )

            img_tag = chart_to_img_tag(fig, alt=f"{display_name} vol surface")
            html = (
                section_title_html("Vol surface")
                + table_html
                + (f'<div style="text-align:center;margin:8px 0;">{img_tag}</div>' if img_tag else "")
            )

            out[inst_key] = SectionResult(
                html=html,
                llm_context=f"## Options Vol Surface — {display_name}\n\n{md_content}\n",
                figures={"vol_surface": fig},
                blocks=[block],
            )

        return out
