"""
Cross-asset front-contract futures volume z-scores vs a 20-day history window.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objs as go

from .. import config as cfg
from .base import (
    COLOR_NEGATIVE,
    COLOR_POSITIVE,
    LAYOUT_DEFAULTS,
    DataBlock,
    PipelineData,
    ReportSection,
    SectionResult,
    _fmt,
    chart_to_img_tag,
    empty_figure,
    header_cell,
    heatmap_cell,
    md_table,
    pctl_cell,
    pro_title,
    row_header_cell,
    section_title_html,
    value_cell,
    wrap_table,
)


class VolumeZScoreSection(ReportSection):
    name = "volume_zscore"
    order = 60

    @property
    def is_per_instrument(self) -> bool:
        return False

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        rows_data: list[dict] = []

        for inst_key, im in data.all_metrics.items():
            inst_cfg = cfg.INSTRUMENTS.get(inst_key)
            display_name = inst_cfg.display_name if inst_cfg else inst_key

            front = im.front
            if front is None:
                continue

            vol_snap = front.volume
            zscore: float | None = None

            vol_col = f"{front.ticker}_VOLUME"
            futs_df = data.futures_hist.get(inst_key, pd.DataFrame())
            if vol_col in futs_df.columns:
                series = futs_df[vol_col].dropna().tail(20)
                if len(series) >= 5:
                    arr = series.to_numpy(dtype=float)
                    mean = float(np.nanmean(arr))
                    std = float(np.nanstd(arr, ddof=1))
                    current = vol_snap.current
                    if current is not None and std > 0:
                        zscore = float((float(current) - mean) / std)

            rows_data.append({
                "inst_key": inst_key,
                "display_name": display_name,
                "volume": vol_snap.current,
                "chg_1d": vol_snap.change_1d,
                "pctl": vol_snap.percentile_1y,
                "zscore": zscore,
            })

        chg_vals = [r["chg_1d"] for r in rows_data if r["chg_1d"] is not None]
        max_abs_chg = max((abs(c) for c in chg_vals), default=0.0)
        vol_chg_scale = max(1.0, max_abs_chg * 1.05) if chg_vals else 1.0

        header_cols = ("Instrument", "Volume", "1D Chg", "Z-Score", "Pctl")
        header_row = "<tr>" + "".join(header_cell(h) for h in header_cols) + "</tr>"

        table_rows: list[str] = []
        for r in sorted(rows_data, key=lambda x: x["display_name"]):
            z = r["zscore"]
            table_rows.append(
                "<tr>"
                + row_header_cell(r["display_name"])
                + value_cell(r["volume"], fmt=",.0f")
                + heatmap_cell(r["chg_1d"], scale=vol_chg_scale)
                + heatmap_cell(z, scale=3.0)
                + pctl_cell(r["pctl"])
                + "</tr>"
            )

        table_html = wrap_table(header_row + "".join(table_rows), title="Volume vs 20D average")

        z_for_chart = [(r["display_name"], r["zscore"]) for r in rows_data if r["zscore"] is not None]
        z_for_chart.sort(key=lambda t: abs(t[1]), reverse=True)
        labels = [t[0] for t in z_for_chart]
        zvals = [t[1] for t in z_for_chart]
        bar_colors = [COLOR_POSITIVE if z >= 0 else COLOR_NEGATIVE for z in zvals]
        labels = labels[::-1]
        zvals = zvals[::-1]
        bar_colors = bar_colors[::-1]

        if zvals:
            bar_fig = go.Figure(
                data=[
                    go.Bar(
                        x=zvals,
                        y=labels,
                        orientation="h",
                        marker_color=bar_colors,
                        hovertemplate="%{y} — %{x:+.2f}σ<extra></extra>",
                    )
                ]
            )
            bar_fig.update_layout(
                title=pro_title("Volume Z-Scores (vs 20D Average)"),
                xaxis_title="Z-Score (σ)",
                yaxis_title="",
                showlegend=False,
                **LAYOUT_DEFAULTS,
            )
        else:
            bar_fig = empty_figure("Volume Z-Scores (vs 20D Average)")

        img_tag = chart_to_img_tag(bar_fig, alt="Volume z-scores")
        chart_block = (
            f'<div style="text-align:center;margin:8px 0;">{img_tag}</div>'
            if img_tag
            else ""
        )

        html = (
            section_title_html("Volume z-scores")
            + table_html
            + chart_block
        )

        md_headers = ["Product", "Volume", "Δ1d", "Z-Score", "Pctl"]
        md_rows: list[list[str]] = []
        for r in sorted(rows_data, key=lambda x: abs(x["zscore"] or 0), reverse=True):
            pctl_s = f"{r['pctl']:.0f}th" if r["pctl"] is not None else "—"
            md_rows.append([
                r["display_name"],
                _fmt(r["volume"], ",.0f"),
                _fmt(r["chg_1d"], "+,.0f"),
                _fmt(r["zscore"], "+.2f"),
                pctl_s,
            ])

        md_content = md_table(md_headers, md_rows) if md_rows else "(no data)"
        block = DataBlock(
            block_type="table",
            theme="positioning",
            domain="",
            product="",
            source="Bloomberg",
            source_type="primary",
            title="Futures Volume Z-Scores (vs 20D Average)",
            content=md_content,
            tags=["total_volume", "volume_zscore"],
        )

        return {
            "__global__": SectionResult(
                html=html,
                llm_context=f"## Futures Volume Z-Scores\n\n{md_content}\n",
                figures={"volume_zscore": bar_fig},
                blocks=[block],
            ),
        }
