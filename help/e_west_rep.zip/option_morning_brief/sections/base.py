"""
Base classes and HTML helpers for the modular report section architecture.

Each ReportSection is self-contained: it computes data from the pipeline,
renders HTML for email, generates plotly figures for the dashboard, and
provides structured DataBlocks for the LLM.

DataBlock is the universal content unit for LLM consumption.  Every piece
of information — structured market data, broker commentary, supply events,
fundamental timeseries — becomes a DataBlock with consistent metadata.
The prompt builder groups blocks by *theme* (prices → vol → positioning →
cross-asset) rather than by instrument, so the LLM can compare across
products within each topic.
"""

from __future__ import annotations

import base64
import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import pandas as pd
import plotly.graph_objs as go
import plotly.io as pio

from ..analytics import InstrumentMetrics
from ..bbg_tickers import ContractSpec

logger = logging.getLogger(__name__)

_KALEIDO_ENABLED = os.environ.get("ENABLE_KALEIDO", "0") == "1"

CHART_WIDTH = 620
CHART_HEIGHT = 370

_FONT_STACK = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif'

LAYOUT_DEFAULTS = dict(
    template="plotly_white",
    paper_bgcolor="#ffffff",
    plot_bgcolor="#ffffff",
    font=dict(family=_FONT_STACK, size=12, color="#333333"),
    margin=dict(l=60, r=30, t=50, b=50),
    hovermode="x unified",
    xaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor="#e5e5e5",
        zeroline=False,
        showline=True,
        linewidth=1,
        linecolor="#e5e5e5",
        tickfont=dict(size=11, color="#333"),
        title_font=dict(size=12, color="#333"),
    ),
    yaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor="#e5e5e5",
        zeroline=True,
        zerolinewidth=1,
        zerolinecolor="#d0d0d0",
        showline=True,
        linewidth=1,
        linecolor="#e5e5e5",
        tickfont=dict(size=11, color="#333"),
        title_font=dict(size=12, color="#333"),
    ),
    width=CHART_WIDTH,
    height=CHART_HEIGHT,
)

PRO_LEGEND = dict(
    orientation="h",
    yanchor="bottom",
    y=1.02,
    xanchor="right",
    x=1,
    bgcolor="rgba(255,255,255,0.9)",
    bordercolor="#e5e5e5",
    borderwidth=1,
    font=dict(size=11),
)

COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
    "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
    "#17becf", "#bcbd22",
]

COLOR_POSITIVE = "#2ca02c"
COLOR_NEGATIVE = "#d62728"
COLOR_NEUTRAL = "#999999"


# ======================================================================
# Data containers
# ======================================================================

@dataclass
class DataBlock:
    """Universal content block for LLM consumption.

    Every piece of information — whether it's an options skew table, broker
    commentary, or a supply outage event — becomes a DataBlock.  The metadata
    wrapper is always the same; only ``content`` varies by ``block_type``.
    """
    block_type: str = "table"
    theme: str = ""
    domain: str = ""
    product: str = ""
    source: str = ""
    source_type: str = "primary"
    title: str = ""
    content: str = ""
    tags: list[str] = field(default_factory=list)
    relevance_window: str = "prompt"
    timestamp: str = ""


@dataclass
class PipelineData:
    """Shared data bag passed to all sections."""
    contracts: dict[str, list[ContractSpec]]
    futures_hist: dict[str, pd.DataFrame]
    vol_surface: dict[str, pd.DataFrame]
    option_chains: dict[str, pd.DataFrame]
    all_metrics: dict[str, InstrumentMetrics]
    cross_asset: dict = field(default_factory=dict)


@dataclass
class SectionResult:
    """Output from a single section for one instrument (or global)."""
    html: str = ""
    llm_context: str = ""
    figures: dict[str, go.Figure] = field(default_factory=dict)
    blocks: list[DataBlock] = field(default_factory=list)


# ======================================================================
# Markdown table helpers (for LLM context)
# ======================================================================

def md_table(headers: list[str], rows: list[list[str]]) -> str:
    """Build a Markdown table string from headers and row data."""
    if not headers:
        return ""
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(col_widths):
                col_widths[i] = max(col_widths[i], len(cell))

    def _pad(cells: list[str]) -> str:
        parts = []
        for i, c in enumerate(cells):
            w = col_widths[i] if i < len(col_widths) else len(c)
            parts.append(c.ljust(w) if i == 0 else c.rjust(w))
        return "| " + " | ".join(parts) + " |"

    sep = "|" + "|".join(
        "-" * (w + 2) if i == 0 else "-" * (w + 2)
        for i, w in enumerate(col_widths)
    ) + "|"

    lines = [_pad(headers), sep]
    for row in rows:
        padded = row + [""] * (len(headers) - len(row))
        lines.append(_pad(padded))
    return "\n".join(lines)


def _fmt(v: float | None, fmt: str = ".2f") -> str:
    if v is None:
        return "—"
    try:
        return f"{v:{fmt}}"
    except (TypeError, ValueError):
        return str(v)


# ======================================================================
# Abstract base
# ======================================================================

class ReportSection(ABC):
    name: str = ""
    order: int = 0

    @abstractmethod
    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        """
        Return {instrument_key: SectionResult} for per-instrument sections,
        or {"__global__": SectionResult} for cross-asset sections.
        """

    @property
    def is_per_instrument(self) -> bool:
        return True


# ======================================================================
# Chart utilities
# ======================================================================

def figure_to_base64(fig: go.Figure, fmt: str = "png") -> str | None:
    if not _KALEIDO_ENABLED:
        return None
    try:
        img_bytes = pio.to_image(fig, format=fmt, width=CHART_WIDTH, height=CHART_HEIGHT)
        return base64.b64encode(img_bytes).decode("utf-8")
    except Exception:
        logger.warning("Chart image export failed")
        return None


def chart_to_img_tag(fig: go.Figure, alt: str = "", max_width: int = 460) -> str:
    b64 = figure_to_base64(fig)
    if not b64:
        return ""
    return (
        f'<img src="data:image/png;base64,{b64}" alt="{alt}" '
        f'style="max-width:{max_width}px;height:auto;display:block;margin:4px auto;" />'
    )


def empty_figure(title: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        title=dict(text=title, font=dict(size=14, color="#333"), x=0.02, xanchor="left"),
        annotations=[dict(
            text="No data available",
            xref="paper", yref="paper", x=0.5, y=0.5,
            showarrow=False, font=dict(size=14, color="#999"),
        )],
        **LAYOUT_DEFAULTS,
    )
    return fig


def pro_title(text: str) -> dict:
    """Return a Plotly title dict with professional left-aligned styling."""
    return dict(text=text, font=dict(size=14, color="#333"), x=0.02, xanchor="left")


# ======================================================================
# HTML heatmap helpers (pure inline CSS — works in all email clients)
# ======================================================================

_CELL_STYLE = (
    "padding:6px 10px;text-align:right;font-size:12px;"
    "font-family:'SF Mono','Consolas','Courier New',monospace;"
    "border-bottom:1px solid #e8eaed;border-right:none;border-left:none;border-top:none;"
    "color:#333;"
)

_HEADER_STYLE = (
    "padding:8px 10px;text-align:center;font-size:11px;font-weight:700;"
    "text-transform:uppercase;letter-spacing:0.5px;"
    "background:linear-gradient(180deg,#f7f8fa 0%,#eef0f4 100%);"
    "color:#4a5568;border-bottom:2px solid #cbd5e0;"
    "border-right:none;border-left:none;border-top:none;"
)

_ROW_HEADER_STYLE = (
    "padding:6px 10px;text-align:left;font-size:12px;font-weight:600;"
    "color:#1a202c;border-bottom:1px solid #e8eaed;"
    "border-right:none;border-left:none;border-top:none;"
    "background:#fafbfc;"
)


def heatmap_bg(value: float | None, scale: float = 1.0, neutral_zero: bool = True) -> str:
    """Return an inline background-color string for a heatmap cell."""
    if value is None:
        return "background:#f9f9f9;"
    if neutral_zero and value == 0:
        return "background:#fff;"
    clamped = max(-1.0, min(1.0, value / max(scale, 0.001)))
    intensity = abs(clamped)
    alpha = round(0.08 + intensity * 0.35, 3)
    if clamped > 0:
        return f"background:rgba(46,125,50,{alpha});"
    return f"background:rgba(198,40,40,{alpha});"


def heatmap_cell(value: float | None, scale: float = 1.0, fmt: str = "+.2f") -> str:
    if value is None:
        return f'<td style="{_CELL_STYLE}background:#f9f9f9;color:#bbb;">—</td>'
    bg = heatmap_bg(value, scale)
    return f'<td style="{_CELL_STYLE}{bg}">{value:{fmt}}</td>'


def value_cell(value: float | None, fmt: str = ".2f") -> str:
    if value is None:
        return f'<td style="{_CELL_STYLE}background:#f9f9f9;color:#bbb;">—</td>'
    return f'<td style="{_CELL_STYLE}">{value:{fmt}}</td>'


def pctl_cell(pctl: float | None) -> str:
    if pctl is None:
        return f'<td style="{_CELL_STYLE}background:#f9f9f9;color:#bbb;">—</td>'
    if pctl >= 90:
        bg = "background:rgba(198,40,40,0.25);"
    elif pctl >= 75:
        bg = "background:rgba(255,152,0,0.2);"
    elif pctl <= 10:
        bg = "background:rgba(46,125,50,0.25);"
    elif pctl <= 25:
        bg = "background:rgba(33,150,243,0.15);"
    else:
        bg = "background:#fff;"
    return f'<td style="{_CELL_STYLE}{bg}">{pctl:.0f}th</td>'


def header_cell(text: str) -> str:
    return f'<th style="{_HEADER_STYLE}">{text}</th>'


def row_header_cell(text: str) -> str:
    return f'<td style="{_ROW_HEADER_STYLE}">{text}</td>'


def wrap_table(rows_html: str, title: str = "") -> str:
    title_html = ""
    if title:
        title_html = (
            f'<div style="font-size:13px;font-weight:700;color:#1a202c;'
            f'padding:8px 0 4px 0;font-family:Arial,Helvetica,sans-serif;">{title}</div>'
        )
    return (
        f'{title_html}'
        f'<table style="border-collapse:collapse;width:100%;margin-bottom:12px;'
        f'border-radius:6px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.06);">'
        f'{rows_html}</table>'
    )


def section_title_html(title: str) -> str:
    return (
        f'<div style="font-size:13px;font-weight:700;color:#0d1b2a;'
        f'text-transform:uppercase;letter-spacing:0.8px;'
        f'padding:10px 0 5px 0;border-bottom:2px solid #1b4f72;margin-bottom:8px;'
        f'font-family:Arial,Helvetica,sans-serif;">'
        f'{title}</div>'
    )
