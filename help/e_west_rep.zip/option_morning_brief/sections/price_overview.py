"""
Price overview section: price & OI time-series chart plus compact contract table (front 3).
"""

from __future__ import annotations

import plotly.graph_objs as go

from .. import config as cfg
from .base import (
    COLORS,
    LAYOUT_DEFAULTS,
    PRO_LEGEND,
    DataBlock,
    PipelineData,
    ReportSection,
    SectionResult,
    _fmt,
    chart_to_img_tag,
    empty_figure,
    header_cell,
    heatmap_cell,
    md_table,
    pctl_cell,
    pro_title,
    row_header_cell,
    section_title_html,
    value_cell,
    wrap_table,
)


class PriceOverviewSection(ReportSection):
    name = "price_overview"
    order = 50

    def _create_price_chart(self, im) -> go.Figure:
        dates_p = [p["date"] for p in im.price_series if p.get("value") is not None]
        prices = [p["value"] for p in im.price_series if p.get("value") is not None]
        dates_o = [p["date"] for p in im.oi_series if p.get("value") is not None]
        ois = [p["value"] for p in im.oi_series if p.get("value") is not None]

        if not dates_p:
            return empty_figure(f"{im.instrument} — Price (no data)")

        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=dates_p,
                y=prices,
                mode="lines",
                line=dict(color=COLORS[0], width=2.5),
                name="Price",
                hovertemplate="%{x|%d %b} — %{y:.2f}<extra></extra>",
            )
        )
        if dates_o:
            fig.add_trace(
                go.Bar(
                    x=dates_o,
                    y=ois,
                    name="OI",
                    marker_color="rgba(31,119,180,0.12)",
                    yaxis="y2",
                    hovertemplate="%{x|%d %b} — %{y:,.0f}<extra>OI</extra>",
                )
            )

        fig.update_layout(
            title=pro_title(f"{im.instrument} — Price & OI"),
            yaxis_title=f"Price ({im.unit})",
            yaxis2=dict(
                title="OI",
                overlaying="y",
                side="right",
                showgrid=False,
            ),
            legend=PRO_LEGEND,
            **LAYOUT_DEFAULTS,
        )
        return fig

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        out: dict[str, SectionResult] = {}
        for inst_key, im in data.all_metrics.items():
            inst_cfg = cfg.INSTRUMENTS.get(inst_key)
            display_name = inst_cfg.display_name if inst_cfg else inst_key

            fig = self._create_price_chart(im)

            header_cols = (
                "Contract",
                "Price",
                "1D Chg",
                "5D Chg",
                "20D Chg",
                "Pctl",
            )
            header_row = "<tr>" + "".join(header_cell(h) for h in header_cols) + "</tr>"

            body_rows: list[str] = []
            md_rows: list[list[str]] = []

            front_three = im.contracts[:3]
            abs_changes: list[float] = []
            for cm in front_three:
                px = cm.price
                for c in (px.change_1d, px.change_5d, px.change_20d):
                    if c is not None:
                        abs_changes.append(abs(c))
            chg_scale = max(abs_changes) if abs_changes else 1.0

            for cm in front_three:
                label = cm.label or cm.ticker
                px = cm.price
                body_rows.append(
                    "<tr>"
                    + row_header_cell(label)
                    + value_cell(px.current, fmt=".2f")
                    + heatmap_cell(px.change_1d, scale=chg_scale)
                    + heatmap_cell(px.change_5d, scale=chg_scale)
                    + heatmap_cell(px.change_20d, scale=chg_scale)
                    + pctl_cell(px.percentile_1y)
                    + "</tr>"
                )
                pctl_s = f"{px.percentile_1y:.0f}th" if px.percentile_1y is not None else "—"
                md_rows.append([
                    label,
                    _fmt(px.current, ".2f"),
                    _fmt(px.change_1d, "+.2f"),
                    _fmt(px.change_5d, "+.2f"),
                    _fmt(px.change_20d, "+.2f"),
                    pctl_s,
                ])

            u = im.unit or ""
            md_headers = ["Contract", f"Price ({u})", "Δ1d", "Δ5d", "Δ20d", "Pctl"]
            md_content = md_table(md_headers, md_rows)
            block = DataBlock(
                block_type="table",
                theme="prices",
                domain=cfg.INSTRUMENT_DOMAINS.get(inst_key, ""),
                product=inst_key,
                source="Bloomberg" if not (inst_cfg and inst_cfg.has_ice_options) else "ICE",
                source_type="primary",
                title=f"Futures Prices — {display_name}",
                content=md_content,
                tags=["settlement", "price_1d", "price_5d", "price_20d"],
            )

            table_html = wrap_table(header_row + "".join(body_rows), title="Futures prices")
            img_tag = chart_to_img_tag(fig, alt=f"{display_name} price & OI")
            html = (
                section_title_html("Price overview")
                + table_html
                + (
                    f'<div style="text-align:center;margin:8px 0;">{img_tag}</div>'
                    if img_tag
                    else ""
                )
            )

            out[inst_key] = SectionResult(
                html=html,
                llm_context=f"## Futures Prices — {display_name}\n\n{md_content}\n",
                figures={"price_overview": fig},
                blocks=[block],
            )

        return out
