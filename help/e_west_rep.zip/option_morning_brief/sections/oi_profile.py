"""
OI profile section: open interest by strike for the front options contract.
"""

from __future__ import annotations

import plotly.graph_objs as go

from .. import config as cfg
from .base import (
    COLORS,
    LAYOUT_DEFAULTS,
    PRO_LEGEND,
    DataBlock,
    PipelineData,
    ReportSection,
    SectionResult,
    chart_to_img_tag,
    empty_figure,
    pro_title,
    section_title_html,
)


class OIProfileSection(ReportSection):
    name = "oi_profile"
    order = 40

    def _create_oi_chart(self, im) -> go.Figure:
        front = im.front
        if front is None or not front.oi_by_strike:
            return empty_figure(f"{im.instrument} — OI by Strike (no data)")

        calls = [
            (d["strike"], d["oi"])
            for d in front.oi_by_strike
            if d.get("put_call") in ("C", "Call")
            and d.get("strike") is not None
            and d.get("oi") is not None
        ]
        puts = [
            (d["strike"], d["oi"])
            for d in front.oi_by_strike
            if d.get("put_call") in ("P", "Put")
            and d.get("strike") is not None
            and d.get("oi") is not None
        ]

        fig = go.Figure()
        if calls:
            fig.add_trace(
                go.Bar(
                    x=[c[0] for c in calls],
                    y=[c[1] for c in calls],
                    name="Call OI",
                    marker_color="rgba(31,119,180,0.7)",
                    hovertemplate="Strike %{x} — %{y:,.0f}<extra>Call OI</extra>",
                )
            )
        if puts:
            fig.add_trace(
                go.Bar(
                    x=[p[0] for p in puts],
                    y=[p[1] for p in puts],
                    name="Put OI",
                    marker_color="rgba(214,39,40,0.7)",
                    hovertemplate="Strike %{x} — %{y:,.0f}<extra>Put OI</extra>",
                )
            )
        spot = front.price.current
        if spot is not None:
            fig.add_vline(
                x=spot,
                line_dash="dash",
                line_color="#e53e3e",
                line_width=2,
                annotation_text=f"Spot {spot:.2f}",
                annotation_font_size=11,
            )

        fig.update_layout(
            title=pro_title(f"{im.instrument} — OI by Strike ({front.label})"),
            xaxis_title="Strike",
            yaxis_title="Open Interest",
            barmode="group",
            legend=PRO_LEGEND,
            **LAYOUT_DEFAULTS,
        )
        return fig

    @staticmethod
    def _strike_totals_and_heaviest(
        oi_by_strike: list[dict],
    ) -> tuple[float, float, float | None, tuple[float, float] | None, tuple[float, float] | None]:
        call_total = 0.0
        put_total = 0.0
        best_call: tuple[float, float] | None = None
        best_put: tuple[float, float] | None = None

        for d in oi_by_strike:
            oi = d.get("oi")
            strike = d.get("strike")
            pc = d.get("put_call")
            if oi is None or strike is None:
                continue
            try:
                oi_f = float(oi)
                k_f = float(strike)
            except (TypeError, ValueError):
                continue
            if pc in ("C", "Call"):
                call_total += oi_f
                if best_call is None or oi_f > best_call[1]:
                    best_call = (k_f, oi_f)
            elif pc in ("P", "Put"):
                put_total += oi_f
                if best_put is None or oi_f > best_put[1]:
                    best_put = (k_f, oi_f)

        pc_ratio = (put_total / call_total) if call_total > 0 else None
        return call_total, put_total, pc_ratio, best_call, best_put

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        out: dict[str, SectionResult] = {}
        for inst_key, im in data.all_metrics.items():
            inst_cfg = cfg.INSTRUMENTS.get(inst_key)
            display_name = inst_cfg.display_name if inst_cfg else inst_key

            front = im.front
            has_chain = front is not None and bool(front.oi_by_strike)

            fig = self._create_oi_chart(im)

            if not has_chain:
                html = (
                    section_title_html("OI by strike")
                    + '<p style="font-size:12px;color:#666;margin:4px 0;">No option chain data</p>'
                )
                md_content = "(no option chain data for front contract)"
            else:
                assert front is not None
                call_total, put_total, pc_ratio, best_call, best_put = (
                    self._strike_totals_and_heaviest(front.oi_by_strike)
                )
                img_tag = chart_to_img_tag(fig, alt=f"{display_name} OI by strike")
                html = (
                    section_title_html("OI by strike")
                    + (
                        f'<div style="text-align:center;margin:8px 0;">{img_tag}</div>'
                        if img_tag
                        else ""
                    )
                )

                label = front.label or front.ticker
                pc_s = f"{pc_ratio:.2f}" if pc_ratio is not None else "—"
                hc_s = (
                    f"{best_call[0]:.2f} ({best_call[1]:,.0f})"
                    if best_call
                    else "—"
                )
                hp_s = (
                    f"{best_put[0]:.2f} ({best_put[1]:,.0f})"
                    if best_put
                    else "—"
                )
                md_content = (
                    f"Total call OI: {call_total:,.0f} | "
                    f"Total put OI: {put_total:,.0f} | P/C ratio: {pc_s}\n"
                    f"Heaviest call strike: {hc_s} | "
                    f"Heaviest put strike: {hp_s}"
                )

            front_label = front.label if front else ""
            src = "ICE" if (inst_cfg and inst_cfg.has_ice_options) else "Bloomberg"
            block = DataBlock(
                block_type="table",
                theme="positioning",
                domain=cfg.INSTRUMENT_DOMAINS.get(inst_key, ""),
                product=inst_key,
                source=src,
                source_type="primary",
                title=f"OI By Strike — {display_name} ({front_label})",
                content=md_content,
                tags=["call_OI", "put_OI", "put_call_ratio"],
            )

            out[inst_key] = SectionResult(
                html=html,
                llm_context=f"## OI By Strike — {display_name} ({front_label})\n\n{md_content}\n",
                figures={"oi_profile": fig},
                blocks=[block],
            )

        return out
