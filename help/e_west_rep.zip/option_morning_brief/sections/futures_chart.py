"""
Futures OHLCV candlestick chart section: 90-day candlestick with volume bars
for the front-month contract of each instrument.
"""

from __future__ import annotations

import pandas as pd
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from .. import config as cfg
from .base import (
    COLOR_NEGATIVE,
    COLOR_POSITIVE,
    COLORS,
    LAYOUT_DEFAULTS,
    PRO_LEGEND,
    DataBlock,
    PipelineData,
    ReportSection,
    SectionResult,
    _fmt,
    chart_to_img_tag,
    empty_figure,
    md_table,
    pro_title,
    section_title_html,
)

OHLCV_LOOKBACK_DAYS = 90


class FuturesChartSection(ReportSection):
    name = "futures_chart"
    order = 45

    def _create_ohlcv_chart(
        self,
        inst_key: str,
        display_name: str,
        unit: str,
        front_ticker: str,
        front_label: str,
        futs_df: pd.DataFrame,
    ) -> go.Figure:
        o_col = f"{front_ticker}_PX_OPEN"
        h_col = f"{front_ticker}_PX_HIGH"
        l_col = f"{front_ticker}_PX_LOW"
        c_col = f"{front_ticker}_PX_LAST"
        v_col = f"{front_ticker}_VOLUME"

        needed = [c_col]
        if not all(col in futs_df.columns for col in needed):
            return empty_figure(f"{display_name} — Futures ({front_label})")

        df = futs_df[[col for col in [o_col, h_col, l_col, c_col, v_col] if col in futs_df.columns]].copy()
        df = df.dropna(subset=[c_col])
        df = df.tail(OHLCV_LOOKBACK_DAYS)

        if df.empty:
            return empty_figure(f"{display_name} — Futures ({front_label})")

        has_ohlc = all(col in df.columns for col in [o_col, h_col, l_col])
        has_volume = v_col in df.columns

        fig = make_subplots(
            rows=2 if has_volume else 1,
            cols=1,
            shared_xaxes=True,
            vertical_spacing=0.03,
            row_heights=[0.75, 0.25] if has_volume else [1.0],
        )

        if has_ohlc:
            fig.add_trace(
                go.Candlestick(
                    x=df.index,
                    open=df[o_col],
                    high=df[h_col],
                    low=df[l_col],
                    close=df[c_col],
                    name="OHLC",
                    increasing_line_color=COLOR_POSITIVE,
                    increasing_fillcolor="rgba(44,160,44,0.35)",
                    decreasing_line_color=COLOR_NEGATIVE,
                    decreasing_fillcolor="rgba(214,39,40,0.35)",
                    whiskerwidth=0.4,
                ),
                row=1, col=1,
            )
        else:
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df[c_col],
                    mode="lines",
                    line=dict(color=COLORS[0], width=2),
                    name="Close",
                    hovertemplate="%{x|%d %b} — %{y:.2f}<extra></extra>",
                ),
                row=1, col=1,
            )

        if has_volume:
            vol = df[v_col].fillna(0)
            closes = df[c_col]
            if has_ohlc:
                opens = df[o_col]
                bar_colors = [
                    "rgba(44,160,44,0.55)" if c >= o else "rgba(214,39,40,0.55)"
                    for c, o in zip(closes, opens)
                ]
            else:
                bar_colors = [
                    "rgba(44,160,44,0.55)" if i == 0 or closes.iloc[i] >= closes.iloc[i - 1]
                    else "rgba(214,39,40,0.55)"
                    for i in range(len(closes))
                ]
            fig.add_trace(
                go.Bar(
                    x=df.index,
                    y=vol,
                    name="Volume",
                    marker_color=bar_colors,
                    hovertemplate="%{x|%d %b} — %{y:,.0f}<extra>Volume</extra>",
                ),
                row=2 if has_volume else 1,
                col=1,
            )

        fig.update_layout(
            title=pro_title(f"{display_name} — {front_label} (90D)"),
            legend=PRO_LEGEND,
            xaxis_rangeslider_visible=False,
            **{k: v for k, v in LAYOUT_DEFAULTS.items() if k not in ("xaxis", "yaxis")},
        )

        fig.update_yaxes(
            title_text=f"Price ({unit})",
            row=1, col=1,
            showgrid=True,
            gridcolor="#e5e5e5",
            showline=True,
            linecolor="#e5e5e5",
        )
        if has_volume:
            fig.update_yaxes(
                title_text="Volume",
                row=2, col=1,
                showgrid=True,
                gridcolor="#e5e5e5",
                showline=True,
                linecolor="#e5e5e5",
            )
            fig.update_xaxes(
                showgrid=True,
                gridcolor="#e5e5e5",
                showline=True,
                linecolor="#e5e5e5",
                row=2, col=1,
            )

        fig.update_xaxes(
            showgrid=True,
            gridcolor="#e5e5e5",
            showline=True,
            linecolor="#e5e5e5",
            row=1, col=1,
        )

        fig.update_layout(height=420 if has_volume else 340)

        return fig

    def compute(self, data: PipelineData) -> dict[str, SectionResult]:
        out: dict[str, SectionResult] = {}
        for inst_key, im in data.all_metrics.items():
            inst_cfg = cfg.INSTRUMENTS.get(inst_key)
            display_name = inst_cfg.display_name if inst_cfg else inst_key
            unit = im.unit or ""

            front = im.front
            if front is None:
                out[inst_key] = SectionResult(
                    html=section_title_html("Futures chart") + '<p style="color:#888;font-size:12px;">No data</p>',
                )
                continue

            futs_df = data.futures_hist.get(inst_key, pd.DataFrame())
            fig = self._create_ohlcv_chart(
                inst_key, display_name, unit,
                front.ticker, front.label or front.ticker, futs_df,
            )

            img_tag = chart_to_img_tag(fig, alt=f"{display_name} OHLCV", max_width=580)
            html = (
                section_title_html(f"Futures — {front.label or front.ticker}")
                + (f'<div style="text-align:center;margin:8px 0;">{img_tag}</div>' if img_tag else "")
            )

            px = front.price
            md_rows = [[
                front.label or front.ticker,
                _fmt(px.current, ".2f"),
                _fmt(px.change_1d, "+.2f"),
                _fmt(px.change_5d, "+.2f"),
                _fmt(px.change_20d, "+.2f"),
            ]]
            md_headers = ["Contract", f"Last ({unit})", "Δ1d", "Δ5d", "Δ20d"]
            md_content = md_table(md_headers, md_rows)

            block = DataBlock(
                block_type="table",
                theme="prices",
                domain=cfg.INSTRUMENT_DOMAINS.get(inst_key, ""),
                product=inst_key,
                source="Bloomberg",
                source_type="primary",
                title=f"Futures OHLCV — {display_name} ({front.label})",
                content=md_content,
                tags=["settlement", "price_1d"],
            )

            out[inst_key] = SectionResult(
                html=html,
                llm_context=f"## Futures OHLCV — {display_name}\n\n{md_content}\n",
                figures={"futures_chart": fig},
                blocks=[block],
            )

        return out
