"""
Section registry for the modular report architecture.

Adding a new section:
  1. Create sections/my_new_section.py implementing ReportSection
  2. Import it here and add to ALL_SECTIONS
  3. Done — the pipeline, LLM, email, and dashboard all pick it up automatically.
"""

from .base import DataBlock, PipelineData, ReportSection, SectionResult
from .cross_asset import CrossAssetSection
from .futures_chart import FuturesChartSection
from .vol_surface import VolSurfaceSection
from .skew_change import SkewChangeSection
from .term_structure import TermStructureSection
from .oi_profile import OIProfileSection
from .price_overview import PriceOverviewSection
from .volume_zscore import VolumeZScoreSection

ALL_SECTIONS: list[ReportSection] = sorted(
    [
        CrossAssetSection(),
        FuturesChartSection(),
        VolSurfaceSection(),
        SkewChangeSection(),
        TermStructureSection(),
        OIProfileSection(),
        PriceOverviewSection(),
        VolumeZScoreSection(),
    ],
    key=lambda s: s.order,
)

__all__ = [
    "ALL_SECTIONS",
    "DataBlock",
    "PipelineData",
    "ReportSection",
    "SectionResult",
]
