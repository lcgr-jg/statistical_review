"""
Debug script: Inspect MACQ UK Power Forward Curve data from Snowflake.
Checks the structure, granularity, and date ranges available.
"""
import sys
import os
corelib_path = 'c:/Users/Michael.Kane/OneDrive - Jain Global/Projects/eu_corelib'
if os.path.exists(corelib_path) and corelib_path not in sys.path:
    sys.path.insert(0, corelib_path)

import pandas as pd
from datetime import date, timedelta
from jain_commods.core.interfaces.snowflake.snowflake import SnowFlake

import holidays

uk_holidays = holidays.UK(years=range(2024, date.today().year + 1))

def last_uk_business_day(ref_date: date) -> date:
    d = ref_date - timedelta(days=1)
    while d.weekday() >= 5 or d in uk_holidays:
        d -= timedelta(days=1)
    return d


print("=" * 70)
print("CONNECTING TO SNOWFLAKE")
print("=" * 70)

sf = SnowFlake(database='COMMOD', schema='PUBLIC')
conn = sf._conn

as_of = last_uk_business_day(date.today())
print(f"Last UK business day: {as_of}")

# 1. Fetch latest curve
print("\n" + "=" * 70)
print(f"1. LATEST CURVE (AS_OF_DATE = {as_of})")
print("=" * 70)

query_latest = """
    SELECT DATE, PRICE, GRANULARITY, KEY, AS_OF_DATE
    FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
    WHERE COMMODITY = 'ELEC_UK.BASELOAD'
      AND AS_OF_DATE = %(as_of)s
    ORDER BY DATE
"""
df_latest = pd.read_sql(query_latest, conn, params={'as_of': as_of.strftime('%Y-%m-%d')})
print(f"  Rows: {len(df_latest)}")
if not df_latest.empty:
    print(f"  Columns: {list(df_latest.columns)}")
    print(f"  Date range: {df_latest['DATE'].min()} to {df_latest['DATE'].max()}")
    print(f"  Granularities: {df_latest['GRANULARITY'].unique().tolist()}")
    print(f"  KEY values: {df_latest['KEY'].unique().tolist()}")
    print(f"\n  First 15 rows:")
    print(df_latest.head(15).to_string(index=False))

    # Show transition from D to M
    gran_change = df_latest[df_latest['GRANULARITY'] != df_latest['GRANULARITY'].shift(1)]
    print(f"\n  Granularity transitions:")
    for _, row in gran_change.iterrows():
        print(f"    {row['DATE']} -> {row['GRANULARITY']} (price={row['PRICE']})")

    # Show monthly data
    monthly = df_latest[df_latest['GRANULARITY'] == 'M']
    print(f"\n  Monthly contracts ({len(monthly)} rows):")
    print(monthly.to_string(index=False))
else:
    print("  NO DATA FOUND")

# 2. Check available AS_OF_DATEs (last 30 days)
print("\n" + "=" * 70)
print("2. AVAILABLE AS_OF_DATES (last 30 days)")
print("=" * 70)

query_dates = """
    SELECT DISTINCT AS_OF_DATE, COUNT(*) as ROW_COUNT
    FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
    WHERE COMMODITY = 'ELEC_UK.BASELOAD'
      AND AS_OF_DATE >= %(start)s
    GROUP BY AS_OF_DATE
    ORDER BY AS_OF_DATE DESC
"""
start_30 = (date.today() - timedelta(days=30)).strftime('%Y-%m-%d')
df_dates = pd.read_sql(query_dates, conn, params={'start': start_30})
print(f"  Available dates ({len(df_dates)}):")
for _, row in df_dates.iterrows():
    print(f"    {row['AS_OF_DATE']}  ({row['ROW_COUNT']} rows)")

# 3. Check available commodities (to see what else is there)
print("\n" + "=" * 70)
print("3. AVAILABLE COMMODITIES (UK-related)")
print("=" * 70)

query_commodities = """
    SELECT DISTINCT COMMODITY, COUNT(*) as ROW_COUNT
    FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
    WHERE COMMODITY LIKE '%UK%' OR COMMODITY LIKE '%GB%'
    GROUP BY COMMODITY
    ORDER BY COMMODITY
"""
df_comm = pd.read_sql(query_commodities, conn)
print(f"  UK/GB commodities:")
for _, row in df_comm.iterrows():
    print(f"    {row['COMMODITY']}  ({row['ROW_COUNT']} rows)")

# 4. Transform to BootstrapBuilder format
print("\n" + "=" * 70)
print("4. TRANSFORM TO BOOTSTRAPBUILDER FORMAT")
print("=" * 70)

if not df_latest.empty:
    contracts = []
    for _, row in df_latest.iterrows():
        d = pd.Timestamp(row['DATE'])
        gran = row['GRANULARITY']
        price = float(row['PRICE'])

        if gran == 'D':
            start = d
            end = d + pd.Timedelta(days=1)
        elif gran == 'M':
            start = d
            end = d + pd.offsets.MonthEnd(0) + pd.Timedelta(days=1)
        elif gran == 'Q':
            start = d
            end = d + pd.offsets.QuarterEnd(0) + pd.Timedelta(days=1)
        elif gran == 'Y':
            start = d
            end = pd.Timestamp(year=d.year + 1, month=1, day=1)
        else:
            start = d
            end = d + pd.Timedelta(days=1)

        contracts.append({
            'commodity': 'Power',
            'hub': 'UK',
            'start': start,
            'end': end,
            'price': price,
            'shape': 'Base',
            'issue_date': pd.Timestamp(as_of),
        })

    df_contracts = pd.DataFrame(contracts)
    print(f"  Contracts: {len(df_contracts)}")
    print(f"  Date range: {df_contracts['start'].min()} to {df_contracts['end'].max()}")
    print(f"\n  First 10:")
    print(df_contracts.head(10).to_string(index=False))
    print(f"\n  Last 10:")
    print(df_contracts.tail(10).to_string(index=False))

    # Try building curve
    print("\n" + "=" * 70)
    print("5. BUILD FORWARD CURVE WITH BOOTSTRAPBUILDER")
    print("=" * 70)
    try:
        from jain_commods.core.util.curves import BootstrapBuilder, RedundancyMode
        builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
        builder.add_contracts(df_contracts)
        curve = builder.build_curves(freq='D', commodity='Power')
        if not curve.empty:
            if isinstance(curve.index, pd.PeriodIndex):
                curve.index = curve.index.to_timestamp()
            print(f"  Curve built: {len(curve)} daily points")
            print(f"  Date range: {curve.index.min()} to {curve.index.max()}")
            print(f"  Price range: {curve['price'].min():.2f} to {curve['price'].max():.2f}")
            print(f"\n  First 10:")
            print(curve.head(10).to_string())
            print(f"\n  Around granularity transition:")
            mid = len(curve) // 4
            print(curve.iloc[mid-2:mid+3].to_string())
        else:
            print("  Curve is empty!")
    except Exception as e:
        print(f"  Error building curve: {e}")
        import traceback
        traceback.print_exc()

conn.close()
print("\n\nDone.")
