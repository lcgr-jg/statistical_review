import os
import sys
import requests
import json
import logging

from dotenv import load_dotenv
from pathlib import Path

# Set up module logger
logger = logging.getLogger(__name__)
# Ensure logs are captured by Dagster (it captures logs at INFO level and above)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Load .env from multiple locations (later loads override earlier ones)
# 1. First load from CWD (e.g., eu_commods_pipelines/.env)
load_dotenv()

# 2. Then load from this module's directory (news_report/.env) with override
_module_dir = Path(__file__).parent
_local_env = _module_dir / ".env"
if _local_env.exists():
    load_dotenv(_local_env, override=True)
    logger.info(f"Loaded local .env from {_local_env}")


import spgci as ci
import spgci.config as spgci_config
import spgci.auth as spgci_auth
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Union
import httpx
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from jain_commods.core.util.emailhelper import send_email



# Validating / Standardizing the email configuration
# This config defines the valid regions for each commodity category.
# If a commodity has no specific regions of interest, it is an empty list.
EMAIL_CONFIG = {
    'Power': ['Central Western Europe', 'Central Eastern Europe', 'South Eastern Europe', 'Iberia', 'Italy',  'Nordics'  , "Asia"],
    'Gas': [  'Germany', 'France', 'UK', 'Italy', 'Spain', 'Austria', 'Netherlands', 'Norway' , "Asia" , 'US'],
    'Oil' : ['Europe' , 'Asia' , 'Middle East' , 'South America' , 'North America' , 'Africa'],
    'Coal': ['Europe', 'Asia', 'Americas'],
    'Emissions': ['Europe'],
    'LNG': ['US', 'Asia', 'Europe', 'Global'],
    'Gold': ["All"],
    'Silver': ["All"],
    'Copper': ["All"],
    'Aluminium' : ["All"],
    'Zinc' : ["All"],
    'Platinum' : ["All"],
    'Nickel' : ["All"] ,
    "Steel" : ['Europe' , 'Asia']

}


class PlattsNewsScraper:
    """
    A wrapper class for the SPGCI Insights API to fetch and categorize news stories.
    """
    def __init__(self, username: Optional[str] = None, password: Optional[str] = None, access_token: Optional[str] = None):
        """
        Initialize the scraper. 
        """
        # 0. Check for access token first
        if access_token:
            spgci_config.set_token(access_token)
            # If token is provided, we don't strictly need username/password for auth, 
            # though some parts of the lib might still check config.username.
            # We'll rely on the token being set in spgci_config.

        # 1. Explicit arguments
        elif username and password:
            ci.set_credentials(username, password)
        
        # 2. Check env vars (spgci might have loaded them, or we loaded them via dotenv)
        elif not spgci_config.username or not spgci_config.password:
            env_user = os.getenv("SPGCI_USERNAME", "").strip()
            env_pass = os.getenv("SPGCI_PASSWORD", "").strip()
            
            if env_user and env_pass:
                ci.set_credentials(env_user, env_pass)
            else:
                logger.warning("No credentials found in arguments or environment variables.")
                logger.warning("Set SPGCI_USERNAME and SPGCI_PASSWORD in .env or environment.")

        self.insights = ci.Insights()

    def diagnose_auth(self):
        """
        Runs a diagnostic check to verify credentials and entitlements.
        """
        logger.info("--- Running Auth Diagnostics ---")
        user = spgci_config.username
        token_set = spgci_config.get_token()

        if token_set:
            logger.info("Access token is manually set.")
        elif not user:
            logger.error("FAIL: No username configured and no token set.")
            return
        
        logger.info(f"Username: {user[:3]}{'*' * (len(user)-3) if len(user)>3 else ''}")
        
        # Step 1: Try to get token
        logger.info("Attempting to retrieve access token...")
        try:
            if token_set:
                token = token_set
                logger.info("SUCCESS: Using manually provided access token.")
            else:
                # Force fresh token
                spgci_auth.get_token.cache_clear()
                token = spgci_auth.get_token(
                    spgci_config.username,
                    spgci_config.password,
                    spgci_config.base_url
                )
                logger.info("SUCCESS: Access token retrieved.")
        except Exception as e:
            logger.error(f"FAIL: Could not retrieve token. Error: {e}")
            return

        # Step 2: Try a raw request to see the actual error if API fails
        logger.info("Attempting raw API call to News Stories endpoint...")
        url = f"{spgci_config.base_url}/news-insights/v1/search/story"
        headers = {
            "Authorization": f"Bearer {token}",
            "User-Agent": "diagnostic-script/1.0"
        }
        # Minimal query
        params = {"pageSize": 1, "page": 1}
        
        try:
            resp = requests.get(url, headers=headers, params=params)
            logger.info(f"Response Status: {resp.status_code}")
            
            if resp.status_code == 200:
                logger.info("SUCCESS: API call worked. You are entitled to this data.")
            elif resp.status_code in [401, 403]:
                logger.error("FAIL: Access Denied (401/403).")
                logger.error("Response Body (may contain reason):")
                try:
                    logger.error(json.dumps(resp.json(), indent=2))
                except:
                    logger.error(resp.text)
                logger.warning("NOTE: This usually means your account does not have a subscription for 'News & Insights'.")
            else:
                logger.error(f"FAIL: Unexpected status code {resp.status_code}")
                logger.error(resp.text)
                
        except Exception as e:
            logger.error(f"FAIL: Request failed. {e}")

    def fetch_stories(
        self, 
        q: Optional[str] = None,
        geography: Optional[Union[List[str], str]] = None,
        commodity: Optional[Union[List[str], str]] = None,
        days_back: int = 1,
        limit: int = 1000
    ) -> pd.DataFrame:
        """
        Fetch stories from Platts Insights API.
        """
        date_gte = datetime.now() - timedelta(days=days_back)
        
        try:
            # Ensure credentials are set before calling
            if not spgci_config.get_token() and (not spgci_config.username or not spgci_config.password):
                 raise ValueError("Missing SPGCI credentials or token.")

            df = self.insights.get_stories(
                q=q,
                geography=geography,
                commodity=commodity,
                updated_date_gte=date_gte,
                page_size=limit,
                paginate=True
            )
            return df
        except Exception as e:
            logger.error(f"Error fetching stories: {e}")
            # If it's an auth error, hint at diagnostics
            if "Invalid Username" in str(e):
                logger.info("Tip: Run scraper.diagnose_auth() to check if this is an entitlement issue.")
            return pd.DataFrame()

    def _init_llm(self):
        """Initialize LLM if not already done."""
        if not hasattr(self, 'llm'):
            api_key = "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"
            if not api_key:
                logger.warning("OPENAI_API_KEY not found. Summarization will be skipped.")
                self.llm = None
            else:
                # Disable SSL verify as requested due to cert issues
                http_client = httpx.Client(verify=False)
                self.llm = ChatOpenAI(api_key=api_key, model="gpt-4o", temperature=0, http_client=http_client)
                logger.info("LLM initialized (gpt-4o)")

    def process_and_summarize(self, news_map: Dict[str, pd.DataFrame]) -> Dict:
        """
        Process fetched stories, summarize them, and categorize according to EMAIL_CONFIG.
        """
        self._init_llm()
        if not self.llm:
            return {}

        # Initialize structure: {Category: {Region: [stories]}}
        # Only use regions defined in EMAIL_CONFIG - no "General" bucket
        processed_data = {}
        for k in EMAIL_CONFIG.keys():
            processed_data[k] = {}
            for region in EMAIL_CONFIG[k]:
                processed_data[k][region] = []

        
        # Pydantic model for structured output
        class ArticleAnalysis(BaseModel):
            summary: Optional[str] = Field(description="A concise 1-2 sentence summary. It must add value to the headline by including details from the body."),
            new_headline: Optional[str] = Field(description="A new, concise headline for the article, derived from the original headline and body. It should be punchy and relevant to a market analyst.")
            category: Optional[str] = Field(description="The main commodity category (e.g. Power, Gas, LNG) from the provided config keys. Return None if article should be ignored.")
            region: Optional[str] = Field(description="The specific region from the provided config list for that category. If the article does not match a specific region in the list, or the list is empty, return None.")

        parser = PydanticOutputParser(pydantic_object=ArticleAnalysis)

        seen_ids = set()
        seen_headlines = set()  # For deduplication based on headline similarity
        
        def normalize_headline(h: str) -> str:
            """Normalize headline for deduplication."""
            import re
            # Remove punctuation, lowercase, and extract key words
            h = re.sub(r'[^\w\s]', '', h.lower())
            # Remove common filler words
            stopwords = {'the', 'a', 'an', 'in', 'on', 'at', 'to', 'for', 'of', 'and', 'or', 'with', 'amid', 'as', 'by'}
            words = [w for w in h.split() if w not in stopwords]
            return ' '.join(sorted(words[:8]))  # First 8 significant words, sorted

        for category_name, df in news_map.items():
            if df.empty:
                continue
                
            logger.info(f"Summarizing {len(df)} stories for {category_name}...")
            
            # Limit to top N stories per category to avoid excessive API usage during dev
            # df = df.head(5) 
            
            for index, row in df.iterrows():
                story_id = row.get('id')
                if story_id in seen_ids:
                    continue
                seen_ids.add(story_id)

                headline = row.get('headline', '')
                body = row.get('body', '')
                
                # Deduplication check
                norm_headline = normalize_headline(headline)
                if norm_headline in seen_headlines:
                    logger.debug(f"Skipping duplicate headline: {headline[:50]}...")
                    continue
                seen_headlines.add(norm_headline)
                
                # Construct Prompt
                prompt_text = """
                You are a senior commodity analyst screening news for a trading desk that follows markets EVERY DAY.
                
                IMPORTANT: Even if the headline or most of the article is routine market noise, 
                LOOK FOR structural nuggets buried in the text. Extract ONLY the structural information.
                
                Headline: {headline}
                BodySnippet: {body}
                
                === WHAT TO EXTRACT (structural/fundamental info) ===
                - NEW infrastructure: pipelines, plants, terminals, interconnectors , mines (with MW/bcm/b/d etc capacity)
                - Policy/regulatory CHANGES (new laws, government decisions)
                - Corporate M&A, new long-term contracts, capacity expansions
                - Sanctions, trade restrictions, geopolitical events with LASTING impact
                - Technology breakthroughs with commercial deployment
                - Capacity auctions, tender RESULTS
                - Production facility closures or major expansions (permanent)
                - New trade routes, export/import agreements
                - Anything that may impact the supply/demand balance of the commodity
                
                === WHAT TO IGNORE (do NOT include in summary) ===
                - Weather-driven short-term changes (cold snaps, storms, wind fluctuations)
                - Daily/weekly price movements, spot prices, settlements
                - Short-term demand surges or drops
                - Platts/Argus methodology descriptions
                - Generic market commentary without new facts
                - "Prices surge/fall/fluctuate" content
                
                === YOUR TASK ===
                1. Read the ENTIRE article carefully
                2. If there is ANY structural nugget (even buried in routine content), extract it
                3. If the article is 100% routine with no structural info, return category=None
                
                Output (if structural info found):
                - summary: 2 sentences about the STRUCTURAL change only (ignore the routine parts). Include specific numbers, dates, and why it matters.
                - new_headline: Max 10 words, focusing on the structural change
                - category: From config keys
                - region: From config values for that category, or None
                
                Output (if no structural info):
                - category: None
                
                Configuration:
                {config}
                
                {format_instructions}
                """
                
                prompt = ChatPromptTemplate.from_template(prompt_text)
                
                try:
                    chain = prompt | self.llm | parser
                    result = chain.invoke({
                        "headline": headline,
                        "body": body[:2000],
                        "config": json.dumps(EMAIL_CONFIG, indent=2),
                        "format_instructions": parser.get_format_instructions()
                    })
                    
                    # Store result
                    cat = result.category
                    reg = result.region
                    
                    # If LLM returns None for category or summary (indicating ignore), skip it
                    if not cat or not result.summary:
                        continue

                    # Validate category exists in config
                    if cat not in processed_data:
                        # If LLM returns a category we don't track, try the original fetch category
                        if category_name in processed_data:
                            cat = category_name
                        else:
                            # Skip - category not in our config
                            logger.debug(f"Skipping article - category '{cat}' not in config")
                            continue

                    # Validate region - must match exactly or skip
                    # For categories with no regions defined, accept the article
                    if EMAIL_CONFIG.get(cat):
                        # This category has region requirements
                        if reg and reg in processed_data[cat]:
                            reg_key = reg
                        else:
                            # Region doesn't match config - skip article
                            logger.debug(f"Skipping article - region '{reg}' not in {cat} config")
                            continue
                    else:
                        # Category has no region requirements (empty list in config)
                        # Skip these too since there's no bucket for them
                        logger.debug(f"Skipping article - category '{cat}' has no regions configured")
                        continue

                    # Add to structure
                    processed_data[cat][reg_key].append({
                        'headline': result.new_headline or headline,
                        'summary': result.summary,
                        'link': row.get('documentUrl', row.get('id', ''))
                    })
                    
                except Exception as e:
                    logger.warning(f"Error processing story '{headline}': {e}")
                    continue
        
        return processed_data

    def fetch_all_categories(self, days_back: int = 1) -> Dict[str, pd.DataFrame]:
        """
        Fetches stories for all defined categories of interest.
        """
        results = {}
        
        categories = {
            "Power": {"commodity": "Electricity", "geography": ["Europe", "North America"]},
            "Gas": {"commodity": "Natural Gas", "geography": ["Europe", "North America"]},
            "Oil": {"commodity": "Midstream Oil|Crude Oil", "geography": ["Europe", "Asia", "Middle East", "Americas", "Africa"]},
            "Coal": {"commodity": "Coal", "geography": ["Europe", "Asia", "Americas"]},
            "Emissions": {"commodity": "Emissions", "geography": ["Europe", "North America", "China"]},
            "LNG": {"commodity": "LNG"},
            "Gold" : {"commodity": "Gold"},
            "Silver" : {"commodity": "Silver"},
            "Copper" : {'commodity': 'Copper'},
            "Aluminium" : {'commodity': 'Aluminium'},
            "Platinum" : {'commodity': 'Platinum'},
            "Zinc" : {'commodity': 'Zinc'}
        }

        for cat_name, filters in categories.items():
            logger.info(f"Fetching {cat_name} stories...")
            df = self.fetch_stories(
                days_back=days_back,
                **filters
            )
            results[cat_name] = df
            logger.info(f"Found {len(df)} stories for {cat_name}")

        return results

def main():
    # Initialize
    # To use spgci.auth.get_token, we must ensure credentials are set.
    # They should be picked up from .env automatically if imported via spgci or load_dotenv.
    # We can explicitly call get_token to verify/get it.
    
    try:
        logger.info("Getting access token via spgci.auth...")
        
        # Disable SSL verify for SPGCI as well
        spgci_config.verify_ssl = False
        
        # Force a refresh to avoid stale token issues
        spgci_auth.get_token.cache_clear()
        
        # We assume SPGCI_USERNAME and SPGCI_PASSWORD are in .env (loaded at top)
        # or we can check config directly.
        if not spgci_config.username:
             env_user = os.getenv("SPGCI_USERNAME")
             env_pass = os.getenv("SPGCI_PASSWORD")
             if env_user and env_pass:
                 ci.set_credentials(env_user, env_pass)
        
        token = spgci_auth.get_token()
        logger.info("SUCCESS: Access token retrieved.")
    except Exception as e:
        logger.error(f"FAIL: Could not retrieve token: {e}")
        sys.exit(1)
        
    scraper = PlattsNewsScraper(access_token=token)
    
    # Run diagnostics first to rule out auth issues
    scraper.diagnose_auth()
    
    logger.info("--- Starting Scraping ---")

    news_map = scraper.fetch_all_categories(days_back=1)
    
    logger.info("--- Processing and Summarizing ---")
    summary_data = scraper.process_and_summarize(news_map)
    
    # Generate HTML Body
    html_body = """<html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; font-size: 12px; line-height: 1.4; }
            h2 { font-size: 16px; color: #2E86C1; margin-bottom: 8px; }
            h3 { font-size: 14px; margin-bottom: 6px; }
            ul { margin-top: 4px; padding-left: 20px; }
            li { margin-bottom: 6px; }
        </style>
    </head>
    <body>"""
    html_body += f"<p style='font-size: 11px; color: #666;'>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>"
    html_body += "<p style='color: #8B0000; font-weight: bold; font-size: 12px;'>DISCLAIMER: AI summarized content - may contain errors. Check links for details.</p>"

    logger.info("=== FINAL REPORT ===")
    
    for category, sub_cats in summary_data.items():
        # Add to HTML
        html_body += f"<h2>{category}</h2>"
        logger.info(f"# {category}")
        

        for sub_cat, stories in sub_cats.items():
            if stories:
                # Add to HTML
                html_body += f"<h3>{sub_cat}</h3><ul>"
                logger.info(f"  ## {sub_cat}")
                
                for s in stories:
                    headline = s.get('headline', 'No Headline')
                    summary = s.get('summary', '')
                    link_id = s.get('link', '')
                    # Construct a link if possible, otherwise just ID
                    # Assuming standard platts link structure if known, else just ID
                    
                    if link_id and link_id.startswith('http'):
                        li = f"<li><b><a href='{link_id}'>{headline}</a></b>: {summary}</li>"
                    else:
                        li = f"<li><b>{headline}</b>: {summary} <span style='font-size:0.8em; color:gray;'>(ID: {link_id})</span></li>"
                    html_body += li
                    
                    logger.debug(f"    - {summary} (Source ID: {link_id})")
                
                html_body += "</ul>"
            else:
                 pass 

    html_body += "</body></html>"
    
    # Send Email
    logger.info("--- Sending Email ---")
    try:
        subject = f"Morning News Summary - {datetime.now().strftime('%Y-%m-%d')}"
        send_email(
            recipients="michael.kane@jainglobal.com",
            subject=subject,
            body=html_body,
        )
        logger.info("Email sent successfully.")
    except Exception as e:
        logger.error(f"Failed to send email: {e}")

# ============================================================================
# Entry Point for Dagster Orchestration
# ============================================================================

def run_news_report(
    days_back: int = 1,
    recipients: str = None,
    dry_run: bool = False
) -> dict:
    """
    Entry point for Dagster orchestration.
    
    Args:
        days_back: Number of days to look back for news (default: 1, use 3 for Mondays)
        recipients: Email recipients
        dry_run: If True, skip sending email
    
    Returns:
        dict with metadata about the run
    """
    import spgci.auth as spgci_auth
    import spgci.config as spgci_config
    
    # Disable SSL verify for SPGCI
    spgci_config.verify_ssl = False
    
    # Get token
    try:
        logger.info("Getting access token via spgci.auth...")
        spgci_auth.get_token.cache_clear()
        
        if not spgci_config.username:
            env_user = os.getenv("SPGCI_USERNAME")
            env_pass = os.getenv("SPGCI_PASSWORD")
            if env_user and env_pass:
                ci.set_credentials(env_user, env_pass)
                logger.info("Set SPGCI credentials from environment")
        
        token = spgci_auth.get_token()
        logger.info("SUCCESS: Access token retrieved.")
    except Exception as e:
        logger.error(f"FAIL: Could not retrieve token: {e}")
        return {"status": "failed", "error": str(e)}
    
    scraper = PlattsNewsScraper(access_token=token)
    
    logger.info(f"--- Starting Scraping (days_back={days_back}) ---")
    news_map = scraper.fetch_all_categories(days_back=days_back)
    
    total_stories = sum(len(df) for df in news_map.values())
    logger.info(f"Total stories fetched: {total_stories}")
    
    logger.info("--- Processing and Summarizing ---")
    summary_data = scraper.process_and_summarize(news_map)
    
    # Generate HTML Body
    html_body = """<html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; font-size: 12px; line-height: 1.4; }
            h2 { font-size: 16px; color: #2E86C1; margin-bottom: 8px; }
            h3 { font-size: 14px; margin-bottom: 6px; }
            ul { margin-top: 4px; padding-left: 20px; }
            li { margin-bottom: 6px; }
        </style>
    </head>
    <body>"""
    html_body += f"<p style='font-size: 11px; color: #666;'>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>"
    html_body += "<p style='color: #8B0000; font-weight: bold; font-size: 12px;'>DISCLAIMER: AI summarized content - may contain errors. Check links for details.</p>"

    total_summarized = 0
    for category, sub_cats in summary_data.items():
        html_body += f"<h2>{category}</h2>"
        
        for sub_cat, stories in sub_cats.items():
            if stories:
                html_body += f"<h3>{sub_cat}</h3><ul>"
                total_summarized += len(stories)
                
                for s in stories:
                    headline = s.get('headline', 'No Headline')
                    summary = s.get('summary', '')
                    link_id = s.get('link', '')
                    
                    if link_id and link_id.startswith('http'):
                        li = f"<li><b><a href='{link_id}'>{headline}</a></b>: {summary}</li>"
                    else:
                        li = f"<li><b>{headline}</b>: {summary} <span style='font-size:0.8em; color:gray;'>(ID: {link_id})</span></li>"
                    html_body += li
                
                html_body += "</ul>"

    html_body += "</body></html>"
    
    # Send Email
    email_sent = False
    if recipients is None:
        logger.warning("No email recipients specified. Skipping email.")
    elif dry_run:
        logger.info(f"[DRY RUN] Would send email to {recipients}")
    else:
        logger.info(f"--- Sending Email to {recipients} ---")
        try:
            subject = f"Morning News Summary - {datetime.now().strftime('%Y-%m-%d')}"
            send_email(
                recipients=recipients,
                subject=subject,
                body=html_body,
            )
            logger.info("Email sent successfully.")
            email_sent = True
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
    
    return {
        "status": "success",
        "days_back": days_back,
        "total_stories_fetched": total_stories,
        "total_stories_summarized": total_summarized,
        "email_sent": email_sent,
        "recipients": recipients
    }


if __name__ == "__main__":
    main()

