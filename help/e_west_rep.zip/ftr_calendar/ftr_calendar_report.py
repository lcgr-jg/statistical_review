import os
import shutil
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
from jain_commods.core.util.emailhelper import send_email

def get_current_week_range():
    """Returns the start and end dates of the current ISO week."""
    today = datetime.now()
    start = today - timedelta(days=today.weekday())
    start = start.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=6, hours=23, minutes=59, seconds=59)
    return start, end

def read_ftr_calendar(file_path):
    """Reads the FTR Calendar Excel file, handling potential file locks by copying."""
    temp_path = file_path.with_name(f"{file_path.stem}_tmp{file_path.suffix}")
    try:
        shutil.copy2(file_path, temp_path)
        df = pd.read_excel(temp_path)
        return df
    finally:
        if temp_path.exists():
            os.remove(temp_path)

def format_html_table(df):
    """Formats the DataFrame into a nicely styled HTML table."""
    if df.empty:
        return "<p>No FTR Auctions found for the current week.</p>"
    
    # Basic styling for the table
    style = """
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }
        th {
            background-color: #800040;
            color: white;
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
    </style>
    """
    
    html = style + df.to_html(index=False, classes='ftr-table')
    return html

def get_ordinal_suffix(day):
    """Returns the ordinal suffix (st, nd, rd, th) for a given day."""
    if 11 <= day <= 13:
        return 'th'
    else:
        return {1: 'st', 2: 'nd', 3: 'rd'}.get(day % 10, 'th')

def main(recipients=None, dry_run=False):
    base_path = Path(__file__).parent
    file_path = base_path / "FTR Calendar.xlsx"
    
    # Use default if not provided
    if not recipients:
        recipients = "michael.kane@jainglobal.com"
    
    print(f"Reading FTR Calendar from {file_path}...")
    if not file_path.exists():
        print(f"Error: {file_path} does not exist.")
        return {"status": "error", "message": "File not found"}

    df = read_ftr_calendar(file_path)
    
    # Convert date columns to datetime
    df['Auction Start'] = pd.to_datetime(df['Auction Start'], dayfirst=True)
    df['Auction end'] = pd.to_datetime(df['Auction end'], dayfirst=True)
    
    # Filtering logic
    # 1. Exclude Weekly auctions
    df = df[df['Horizon'] != 'Weekly']
    
    # 2. Filter for current week
    week_start, week_end = get_current_week_range()
    print(f"Filtering for week: {week_start.date()} to {week_end.date()}")
    
    mask = (
        ((df['Auction Start'] >= week_start) & (df['Auction Start'] <= week_end)) |
        ((df['Auction end'] >= week_start) & (df['Auction end'] <= week_end))
    )
    df_filtered = df[mask].copy()
    
    # Sort by Auction Start
    df_filtered = df_filtered.sort_values('Auction Start')
    
    # Format dates for display
    df_filtered['Auction Start'] = df_filtered['Auction Start'].dt.strftime('%d/%m/%Y %H:%M')
    df_filtered['Auction end'] = df_filtered['Auction end'].dt.strftime('%d/%m/%Y %H:%M')
    
    print(f"Found {len(df_filtered)} auctions.")
    
    # Generate Email
    # FTR Auctions - Week of 26th Jan 2026
    day = week_start.day
    suffix = get_ordinal_suffix(day)
    date_str = week_start.strftime(f"{day}{suffix} %b %Y")
    subject = f"FTR Auctions - Week of {date_str}"
    print(f"Subject: {subject}")
    body_html = f"""
    <html>
    <body>
        <h2 style="color: #800040;">FTR Auctions - Current Week</h2>
        {format_html_table(df_filtered)}
    </body>
    </html>
    """
    
    email_sent = False
    if len(df_filtered) > 0:
        if dry_run:
            print(f"[DRY RUN] Would send email to: {recipients}")
        else:
            print(f"Sending email to {recipients}...")
            send_email(
                recipients=recipients,
                subject=subject,
                body=body_html
            )
            email_sent = True
            print("Email sent successfully.")
    else:
        print("No auctions found for this week. Skipping email.")

    return {
        "num_auctions": len(df_filtered),
        "email_sent": email_sent,
        "recipients": recipients,
        "dry_run": dry_run,
        "week_start": week_start.strftime('%Y-%m-%d'),
        "week_end": week_end.strftime('%Y-%m-%d')
    }

def run_ftr_calendar_report(recipients=None, dry_run=False):
    """Entry point for Dagster."""
    return main(recipients=recipients, dry_run=dry_run)

if __name__ == "__main__":
    main()
