"""FTR Calendar Package"""
from .ftr_calendar_report import run_ftr_calendar_report

__all__ = ["run_ftr_calendar_report"]
