import pandas as pd
import sys

try:
    path = r'C:\Users\Michael.Kane\OneDrive - Jain Global\Projects\eu_reports\ftr_calendar\FTR Calendar_copy.xlsx'
    df = pd.read_excel(path)
    print("COLUMNS:")
    print(df.columns.tolist())
    print("HEAD:")
    print(df.head().to_string())
except Exception as e:
    print(f"ERROR: {e}")
