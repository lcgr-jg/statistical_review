"""Hormuz LNG vessel monitor.

Every run (5 minutes by default):
  1. Pull the full in-service LNG fleet from Bloomberg BSRCH (positions,
     speed, heading, destination, nav status, draft, ...).
  2. Any LNG vessel inside the Strait of Hormuz zone (GeoJSON polygon) that
     is not yet monitored is auto-added to the persisted watchlist.
  3. Pull Kpler LNG ``vessels`` (fleet status) and ``trades`` (current
     voyage) for the watchlist and blend everything, per vessel, into a
     point-in-time snapshot.
  4. Diff against the previous snapshot in cache/latest_snapshot.json and
     email (send_email, as per china_summary) when any field changed for a
     monitored vessel or a new vessel entered the zone. Every snapshot is
     also appended to cache/snapshot_history.csv.

Add vessels via [Monitor] vessels in hormuz_vessel_monitor.cfg; the zone
polygon lives in zones/hormuz_zone.geojson (replaceable with your own
mapping-tool GeoJSON).

Run:  python monitor.py                 one check
      python monitor.py --loop          poll forever (cfg poll_minutes)
      python monitor.py --dry-run       print instead of emailing
The Dagster schedule (dagster_defs.py) calls run_once() every 5 minutes.
"""
from __future__ import annotations

import argparse
import base64
import configparser
import io
import json
import logging
import math
import platform
import sys
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # non-interactive backend (headless / Dagster safe)
import matplotlib.pyplot as plt
import pandas as pd
import plotly.graph_objects as go

from jain_commods.core.util.emailhelper import send_email
from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table

try:  # package import (Dagster) / script import (python monitor.py)
    from hormuz_vessel_monitor import bbg_ships, kpler_data, zone_watch
except ImportError:
    import bbg_ships
    import kpler_data
    import zone_watch

logger = logging.getLogger(__name__)

REPORTS_PATH = Path(__file__).parent.resolve()
CACHE_DIR = REPORTS_PATH / "cache"
LATEST_SNAPSHOT_FILE = CACHE_DIR / "latest_snapshot.json"
WATCHLIST_FILE = CACHE_DIR / "watchlist.json"
HISTORY_FILE = CACHE_DIR / "snapshot_history.csv"
# Whole-fleet positions from the last run (transit detection is fleet-wide,
# not watchlist-only, so retired/dark vessels cannot slip through the strait
# unnoticed - see detect_transits)
FLEET_FILE = CACHE_DIR / "fleet_positions.json"

FROM_ADDRESS = "eu.gap.reports@jainglobal.com"

# Vessel deep links, as per the eu_dashboard_power Cargo Forecast History page
KPLER_VESSEL_MAP_URL = (
    "https://terminal.kpler.com/map/search/voyages?fields=vessel&vessels={}"
)
BBG_VESSEL_MAP_URL = "bbg://screens/MAP IMO {}"

# 1 m3 of LNG = 0.0006 mcm of natural gas (same factor as the dashboard's
# qatar_monitor/fleet.py and cargo pages)
M3_LNG_TO_MCM = get_conversion_factor("cu m", "mcm", unit_conversion_table)

# Every field in a vessel snapshot, in email/CSV order. A change in ANY of
# these triggers an alert; trim this tuple if the emails get too noisy
# (e.g. drop latitude/longitude/last_seen, which move on every AIS ping).
SNAPSHOT_FIELDS = (
    # Bloomberg AIS
    "vessel_name",
    "latitude",
    "longitude",
    "heading",
    "speed_knots",
    "navigation_status",
    "destination",
    "normalized_destination",
    "eta",
    "current_draft",
    "draft_pct",
    "cargo_status",
    "depart_port",
    "depart_time",
    "last_seen",
    "ais_status",
    "in_zone",
    # Kpler fleet status
    "kpler_vessel_id",
    "kpler_vessel_type",
    "kpler_owners",
    "kpler_controller",
    "laden",
    "cargo_mcm",
    "kpler_status",
    "kpler_destination",
    "kpler_eta",
    "kpler_forecasted_destination",
    "kpler_forecasted_eta",
    "kpler_last_speed_kn",
    "kpler_last_port_call",
    "kpler_departure_date",
    "kpler_last_signal",
    # Kpler current trade
    "trade_status",
    "trade_origin",
    "trade_destination",
    "trade_eta_destination",
    "trade_volume_m3",
    "trade_buyer",
    "trade_charterer",
)

# Fields that never trigger an alert on their own (display/history only):
# last_seen updates on every AIS ping; Kpler last speed mirrors bbg speed.
ALERT_EXEMPT_FIELDS = {"last_seen", "kpler_last_speed_kn"}

# Numeric fields alerted only beyond a threshold, measured against the last
# ALERTED value (a reference that rebases when an alert fires), so ping
# jitter is ignored but slow cumulative drift still alerts eventually.
THRESHOLD_FIELDS = {"latitude", "longitude", "speed_knots", "heading"}


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config() -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    config.read(REPORTS_PATH / "hormuz_vessel_monitor.cfg")
    return config


def get_receivers(config: configparser.ConfigParser) -> tuple[str, str]:
    receivers = config.get("ReportSettings", "receivers")
    error_receivers = config.get("ReportSettings", "error_receivers")
    # override for local debugging/testing, as per china_summary
    if platform.system().lower() == "windows":
        receivers = "john.morley@jainglobal.com"
        error_receivers = "john.morley@jainglobal.com"
    return receivers, error_receivers


# ---------------------------------------------------------------------------
# Snapshot build
# ---------------------------------------------------------------------------

def _norm(value, ndigits: int | None = None) -> str:
    """Normalise any raw value to a stable string for diffing/storage."""
    if value is None:
        return ""
    if isinstance(value, float) and value != value:  # NaN
        return ""
    if isinstance(value, pd.Timestamp):
        if pd.isna(value):
            return ""
        return value.isoformat()
    if ndigits is not None:
        try:
            return f"{round(float(value), ndigits):.{ndigits}f}"
        except (TypeError, ValueError):
            return ""
    text = str(value).strip()
    return "" if text.lower() in ("nan", "nat", "none") else text


def _get(row: pd.Series | None, *candidates: str):
    """First present value among candidate column names, else None."""
    if row is None:
        return None
    for col in candidates:
        if col in row.index:
            value = row[col]
            if value is not None and not (isinstance(value, float) and value != value):
                return value
    return None


def build_vessel_snapshot(
    imo: int,
    name: str,
    bbg_row: pd.Series | None,
    kpler_row: pd.Series | None,
    trade_row: pd.Series | None,
    zone_name: str | None,
    ais_dark_hours: float = 12.0,
) -> dict[str, str]:
    """Blend Bloomberg + Kpler data into one flat, normalised snapshot."""
    # Laden/unladen + cargo from the Kpler vessels 'Volume' (m3 of LNG on
    # board, NaN when in ballast) - same logic as the dashboard fleet pages
    if kpler_row is None:
        laden, cargo_mcm = "", ""
    else:
        vol = pd.to_numeric(_get(kpler_row, "Volume"), errors="coerce")
        vol = 0.0 if pd.isna(vol) else float(vol)
        laden = "Laden" if vol > 0 else "Unladen"
        cargo_mcm = f"{vol * M3_LNG_TO_MCM:.1f}"

    # AIS dark flag from the Bloomberg last_seen timestamp. The value is
    # stable while a vessel stays dark ("Dark since <last ping>"), so the
    # alert fires once when it goes dark and once when it reappears.
    last_seen_ts = pd.to_datetime(
        _get(bbg_row, "last_seen"), errors="coerce", utc=True
    )
    if pd.isna(last_seen_ts):
        ais_status = "No AIS data"
    else:
        age_hours = (
            pd.Timestamp.now(tz="UTC") - last_seen_ts
        ).total_seconds() / 3600.0
        if age_hours <= ais_dark_hours:
            ais_status = "Live"
        else:
            ais_status = f"Dark since {last_seen_ts.isoformat()}"

    snap = {
        # Bloomberg AIS
        "vessel_name": zone_watch.title_case_vessel_name(
            _norm(_get(bbg_row, "vessel_name")) or name
        ),
        "latitude": _norm(_get(bbg_row, "latitude"), ndigits=4),
        "longitude": _norm(_get(bbg_row, "longitude"), ndigits=4),
        "heading": _norm(_get(bbg_row, "heading"), ndigits=0),
        "speed_knots": _norm(
            _get(bbg_row, "reported_speed_knots", "reported_speed"), ndigits=1
        ),
        "navigation_status": _norm(_get(bbg_row, "navigation_status")),
        "destination": _norm(_get(bbg_row, "destination")),
        "normalized_destination": _norm(_get(bbg_row, "normalized_destination")),
        "eta": _norm(_get(bbg_row, "eta")),
        "current_draft": _norm(_get(bbg_row, "current_draft"), ndigits=1),
        "draft_pct": _norm(_get(bbg_row, "draft_pct", "draft_percent"), ndigits=1),
        "cargo_status": _norm(_get(bbg_row, "cargo_status")),
        "depart_port": _norm(_get(bbg_row, "depart_port")),
        "depart_time": _norm(_get(bbg_row, "depart_time")),
        "last_seen": _norm(_get(bbg_row, "last_seen")),
        "ais_status": ais_status,
        "in_zone": zone_name or "",
        # Kpler fleet status
        "kpler_vessel_id": _norm(_get(kpler_row, "Vessel id"), ndigits=0),
        "kpler_vessel_type": _norm(_get(kpler_row, "Vessel type")),
        "kpler_owners": _norm(_get(kpler_row, "Owners")),
        "kpler_controller": _norm(_get(kpler_row, "Current controller")),
        "laden": laden,
        "cargo_mcm": cargo_mcm,
        "kpler_status": _norm(_get(kpler_row, "Status")),
        "kpler_destination": _norm(_get(kpler_row, "Destination")),
        "kpler_eta": _norm(_get(kpler_row, "ETA")),
        "kpler_forecasted_destination": _norm(
            _get(kpler_row, "Forecasted destination")
        ),
        "kpler_forecasted_eta": _norm(_get(kpler_row, "Forecasted ETA")),
        "kpler_last_speed_kn": _norm(
            _get(kpler_row, "Last speed (kn)", "Last speed"), ndigits=1
        ),
        "kpler_last_port_call": _norm(_get(kpler_row, "Last port-call")),
        "kpler_departure_date": _norm(_get(kpler_row, "Departure date")),
        "kpler_last_signal": _norm(_get(kpler_row, "Last signal received")),
        # Kpler current trade
        "trade_status": _norm(_get(trade_row, "Trade status")),
        "trade_origin": _norm(_get(trade_row, "Origin")),
        "trade_destination": _norm(_get(trade_row, "Destination")),
        "trade_eta_destination": _norm(_get(trade_row, "Eta (destination)")),
        "trade_volume_m3": _norm(_get(trade_row, "Volume (origin m3)"), ndigits=0),
        "trade_buyer": _norm(_get(trade_row, "Buyer (destination)")),
        "trade_charterer": _norm(_get(trade_row, "Charterer")),
    }
    assert set(snap) == set(SNAPSHOT_FIELDS)
    return snap


# ---------------------------------------------------------------------------
# Snapshot cache / history
# ---------------------------------------------------------------------------

def load_latest_snapshots() -> tuple[dict[int, dict[str, str]], dict[int, dict]]:
    """Returns (previous vessel snapshots, alert references per vessel)."""
    if not LATEST_SNAPSHOT_FILE.exists():
        return {}, {}
    raw = json.loads(LATEST_SNAPSHOT_FILE.read_text(encoding="utf-8"))
    vessels = {int(imo): snap for imo, snap in raw.get("vessels", {}).items()}
    references = {int(imo): ref for imo, ref in raw.get("references", {}).items()}
    return vessels, references


def save_latest_snapshots(
    snapshots: dict[int, dict[str, str]], references: dict[int, dict]
) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "run_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "vessels": {str(imo): snap for imo, snap in snapshots.items()},
        "references": {str(imo): ref for imo, ref in references.items()},
    }
    LATEST_SNAPSHOT_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def append_history(snapshots: dict[int, dict[str, str]]) -> None:
    """One row per vessel per run, fixed column order.

    If SNAPSHOT_FIELDS has changed since the file was created, the old file
    is migrated to the new schema (missing columns empty) instead of
    appending misaligned rows."""
    if not snapshots:
        return
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    run_utc = datetime.now(timezone.utc).isoformat(timespec="seconds")
    rows = [
        {"run_utc": run_utc, "imo": imo,
         **{f: snap.get(f, "") for f in SNAPSHOT_FIELDS}}
        for imo, snap in sorted(snapshots.items())
    ]
    df = pd.DataFrame(rows)
    if HISTORY_FILE.exists():
        with open(HISTORY_FILE, encoding="utf-8") as fh:
            header = fh.readline().strip()
        if header != ",".join(df.columns):
            old = pd.read_csv(HISTORY_FILE, on_bad_lines="skip")
            old = old.reindex(columns=df.columns)
            pd.concat([old, df], ignore_index=True).to_csv(
                HISTORY_FILE, index=False
            )
            return
    df.to_csv(HISTORY_FILE, mode="a", header=not HISTORY_FILE.exists(), index=False)


def load_fleet_positions() -> dict[int, dict]:
    """Previous run's whole-fleet positions: {imo: {name, lat, lon, seen_utc,
    cargo_status, last_transit_utc}}. Empty on first run."""
    if not FLEET_FILE.exists():
        return {}
    raw = json.loads(FLEET_FILE.read_text(encoding="utf-8"))
    return {int(imo): entry for imo, entry in raw.get("vessels", {}).items()}


def save_fleet_positions(fleet: dict[int, dict]) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "run_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "vessels": {str(imo): entry for imo, entry in fleet.items()},
    }
    FLEET_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def fleet_positions_from_bbg(bbg: pd.DataFrame) -> dict[int, dict]:
    """Compact {imo: {name, lat, lon, seen_utc, cargo_status}} for every
    vessel in the Bloomberg fleet snapshot with sane coordinates."""
    fleet: dict[int, dict] = {}
    if bbg.empty or "imo" not in bbg.columns:
        return fleet
    for _, row in bbg.dropna(subset=["imo"]).iterrows():
        lat = _to_float(row.get("latitude"))
        lon = _to_float(row.get("longitude"))
        if not _sane_position(lat, lon):
            continue
        seen = row.get("last_seen")
        fleet[int(row["imo"])] = {
            "name": str(row.get("vessel_name") or ""),
            "lat": lat,
            "lon": lon,
            "seen_utc": seen.isoformat() if pd.notna(seen) else "",
            "cargo_status": str(row.get("cargo_status") or ""),
        }
    return fleet


def _sane_position(lat: float | None, lon: float | None) -> bool:
    """Reject missing, out-of-range and null-island (0, 0) coordinates so a
    corrupt AIS fix cannot fake a transit-line flip."""
    if lat is None or lon is None:
        return False
    if abs(lat) > 90 or abs(lon) > 180:
        return False
    return not (lat == 0.0 and lon == 0.0)


def _to_float(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _distance_nm(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Equirectangular approximation in nautical miles (fine for short range).
    1 minute of latitude = 1 nm; longitude scaled by cos(latitude)."""
    mean_lat = math.radians((lat1 + lat2) / 2.0)
    dlat_nm = (lat2 - lat1) * 60.0
    dlon_nm = (lon2 - lon1) * 60.0 * math.cos(mean_lat)
    return math.hypot(dlat_nm, dlon_nm)


def detect_transits(
    prev_fleet: dict[int, dict],
    curr_fleet: dict[int, dict],
    gulf_zones: list[dict],
    snapshots: dict[int, dict[str, str]] | None = None,
    realert_hours: float = 6.0,
    ais_dark_hours: float = 12.0,
) -> list[dict]:
    """
    Vessels whose previous and current positions sit on opposite sides of
    the transit line - a successful strait transit.

    Tested FLEET-WIDE (every in-service LNG tanker in the Bloomberg
    snapshot), not just watchlist vessels: a vessel that left the monitored
    zone (monitoring retired), went dark inside the Gulf and reappeared in
    the Arabian Sea still trips this check.

    "Side" is evaluated as membership of the Persian-Gulf-side polygon
    (zones/persian_gulf_side.geojson), whose seaward edge is exactly the
    transit line and whose remaining ring runs over land. Because the
    strait is the only sea route out of the Persian Gulf, ANY voyage that
    flips membership must have passed through it - including a dark vessel
    whose AIS reappears far away (off India, Red Sea en route Suez, ...)
    where a straight-line side test would fail.

    False-positive guards: coordinates are sanity-checked upstream
    (fleet_positions_from_bbg), and a vessel re-flipping within
    ``realert_hours`` of its last alerted transit is suppressed, so one
    anchored right on the line cannot ping-pong an email every 5 minutes.
    """
    transits: list[dict] = []
    if not gulf_zones:
        return transits
    snapshots = snapshots or {}
    now = datetime.now(timezone.utc)
    for imo, entry in curr_fleet.items():
        old = prev_fleet.get(imo)
        if not old:
            continue
        p1 = (_to_float(old.get("lon")), _to_float(old.get("lat")))
        p2 = (_to_float(entry.get("lon")), _to_float(entry.get("lat")))
        if None in p1 or None in p2 or p1 == p2:
            continue
        prev_in_gulf = zone_watch.point_in_zones(p1[0], p1[1], gulf_zones) is not None
        curr_in_gulf = zone_watch.point_in_zones(p2[0], p2[1], gulf_zones) is not None
        if prev_in_gulf == curr_in_gulf:
            continue  # same side - no transit
        # If this crossing was already alerted as a Kpler port-call inference
        # (at an uncharted port, so the position could not be re-anchored),
        # Bloomberg's eventual catch-up fix flips against the SAME stale
        # position the inference was judged on - not a new transit
        alerted_seen = old.get("transit_alerted_seen")
        if alerted_seen and old.get("seen_utc") == alerted_seen:
            continue
        # Re-alert cooldown: a vessel drifting across the line repeatedly
        # only alerts once per realert_hours window (but its position cache
        # still updates, so the flip is not re-detected against stale data)
        last = old.get("last_transit_utc") or ""
        if last:
            try:
                age_h = (now - datetime.fromisoformat(last)).total_seconds() / 3600
                if age_h < realert_hours:
                    entry["last_transit_utc"] = last
                    continue
            except ValueError:
                pass
        eastbound = prev_in_gulf  # left the Gulf side
        moved_nm = _distance_nm(p1[1], p1[0], p2[1], p2[0])
        # Dark jump: the previous fix was already stale, or the hop is far
        # larger than 5 minutes of sailing
        prev_seen = pd.to_datetime(old.get("seen_utc"), errors="coerce", utc=True)
        prev_stale = (
            pd.notna(prev_seen)
            and (now - prev_seen).total_seconds() / 3600 > ais_dark_hours
        )
        snap = snapshots.get(imo, {})
        cargo_status = str(entry.get("cargo_status") or "").lower()
        laden = snap.get("laden") or {
            "laden": "Laden", "ballast": "Unladen"
        }.get(cargo_status, "")
        transits.append({
            "imo": imo,
            "name": (
                snap.get("vessel_name")
                or zone_watch.title_case_vessel_name(entry.get("name", ""))
                or f"IMO {imo}"
            ),
            "direction": (
                "eastbound (out of the Persian Gulf)" if eastbound
                else "westbound (into the Persian Gulf)"
            ),
            "laden": laden,
            "cargo_mcm": snap.get("cargo_mcm", ""),
            "moved_nm": moved_nm,
            "dark_jump": prev_stale or moved_nm > 50,
            "prev_pos": (p1[1], p1[0]),  # (lat, lon)
            "curr_pos": (p2[1], p2[0]),  # (lat, lon)
            "monitored": imo in snapshots,
        })
        entry["last_transit_utc"] = now.isoformat(timespec="seconds")
    return transits


def _port_key(name: str) -> str:
    """Canonical port label: case, hyphens, periods and spacing ignored.

    Kpler's "Last port-call" does not always match the configured spelling
    ("Al Zour" vs "Al-Zour", "Mina Al Ahmadi" vs "Mina Al-Ahmadi",
    "Dubai Light" vs "Dubai Light."). An in-Gulf loading port that fails
    this match is treated as outside the Gulf and becomes a false
    eastbound transit.
    """
    return "".join(ch for ch in str(name or "").lower() if ch.isalnum())


def _index_gulf_ports(
    gulf_ports: dict[str, tuple[float, float]],
) -> dict[str, tuple[float, float]]:
    """Re-key a port table by :func:`_port_key` (idempotent)."""
    return {_port_key(name): coords for name, coords in gulf_ports.items()}


def _match_gulf_port(
    port: str, gulf_ports: dict[str, tuple[float, float]]
) -> tuple[float, float] | None:
    """Coordinates when ``port`` is an in-Gulf port, else None.

    Exact canonical match, plus a trailing Kpler qualifier ("Al Zour LNG"
    still matches "Al Zour"). The longest configured name wins.
    """
    key = _port_key(port)
    if not key:
        return None
    hit = gulf_ports.get(key)
    if hit is not None:
        return hit
    best: tuple[float, float] | None = None
    best_len = 0
    for name, coords in gulf_ports.items():
        if len(name) >= 4 and key.startswith(name) and len(name) > best_len:
            best, best_len = coords, len(name)
    return best


def _is_neutral_port(port: str, neutral_ports: set[str]) -> bool:
    """True for zones that straddle the transit line (no side to assume)."""
    key = _port_key(port)
    if not key:
        return False
    if key in neutral_ports:
        return True
    return any(len(name) >= 4 and key.startswith(name) for name in neutral_ports)


def _drop_false_gulf_stamp(
    entry: dict,
    old: dict,
    port: str,
    gulf_ports: dict[str, tuple[float, float]],
    gulf_zones: list[dict],
) -> None:
    """Forget a transit stamp left by a mis-read in-Gulf port call.

    An unmatched in-Gulf name (Kpler "Al Zour" vs config "Al-Zour") is
    inferred as an eastbound exit and stamped onto the current AIS fix.
    ``detect_transits`` then treats the vessel's real departure as that
    same crossing and stays silent. When the port is actually in-Gulf and
    the fix itself is still inside the Gulf, the stamp is wrong.
    """
    if not old.get("transit_alerted_seen"):
        return
    if _match_gulf_port(port, gulf_ports) is None:
        return
    blat = _to_float(entry.get("lat"))
    blon = _to_float(entry.get("lon"))
    if blat is None or blon is None:
        blat, blon = _to_float(old.get("lat")), _to_float(old.get("lon"))
    if blat is None or blon is None:
        return
    if zone_watch.point_in_zones(blon, blat, gulf_zones) is None:
        return
    entry["transit_alerted_seen"] = ""


def _parse_gulf_ports(raw: str) -> dict[str, tuple[float, float]]:
    """'Name:lat:lon, Name:lat:lon, ...' -> {canonical name: (lat, lon)}."""
    ports: dict[str, tuple[float, float]] = {}
    for item in raw.split(","):
        parts = [p.strip() for p in item.split(":")]
        if len(parts) != 3:
            continue
        try:
            ports[_port_key(parts[0])] = (float(parts[1]), float(parts[2]))
        except ValueError:
            continue
    return ports


def detect_port_call_transits(
    prev_fleet: dict[int, dict],
    curr_fleet: dict[int, dict],
    kpler_fleet: pd.DataFrame | None,
    gulf_zones: list[dict],
    gulf_ports: dict[str, tuple[float, float]],
    snapshots: dict[int, dict[str, str]] | None = None,
    skip_imos: set[int] | None = None,
    realert_hours: float = 6.0,
    neutral_ports: set[str] | None = None,
) -> list[dict]:
    """
    Transits INFERRED from Kpler port calls, for vessels whose AIS never
    showed the crossing (the Bu Samra case: dark north of Oman per
    Bloomberg, then registered by Kpler as calling at Ras Laffan).

    A vessel whose Kpler "Last port-call" changes (new port-call id) to a
    port on the OPPOSITE side of the strait from where Bloomberg AIS still
    places it must have transited. Ports in ``gulf_ports`` count as inside
    the Persian Gulf; any other port counts as outside. Names are matched
    ignoring case, hyphens, periods and spacing, so a vessel already inside
    the Gulf that goes dark while loading at Al Zour is not read as an
    eastbound exit just because Kpler spells it "Al Zour" and the config
    says "Al-Zour". Alerted once per port-call id, marked as inferred (the
    alert deviates from the Bloomberg position on purpose). When the port's
    coordinates are known, the cached fleet position is re-anchored to the
    port so the same transit is not re-alerted by the AIS flip test once
    Bloomberg catches up.

    Also records every vessel's latest port-call id into ``curr_fleet``
    (mutated in place) so the next run has a baseline.
    """
    transits: list[dict] = []
    if (
        kpler_fleet is None or kpler_fleet.empty
        or not gulf_zones or not gulf_ports
    ):
        return transits
    if "Last port-call id" not in kpler_fleet.columns:
        logger.warning("Kpler fleet has no 'Last port-call id' column - "
                       "port-call transit inference skipped")
        return transits
    snapshots = snapshots or {}
    skip_imos = skip_imos or set()
    gulf_ports = _index_gulf_ports(gulf_ports)
    neutral_ports = {_port_key(p) for p in (neutral_ports or set())}
    now = datetime.now(timezone.utc)
    for _, row in kpler_fleet.iterrows():
        imo = pd.to_numeric(row.get("IMO"), errors="coerce")
        pc_id = pd.to_numeric(row.get("Last port-call id"), errors="coerce")
        port = str(row.get("Last port-call") or "").strip()
        if pd.isna(imo) or pd.isna(pc_id) or not port or port.lower() == "nan":
            continue
        imo, pc_id = int(imo), int(pc_id)
        entry = curr_fleet.setdefault(
            imo, {"name": str(row.get("Name") or "")}
        )
        old = prev_fleet.get(imo) or {}
        old_id = old.get("port_call_id")
        entry["port_call_id"] = pc_id
        entry["port_call"] = port
        if _is_neutral_port(port, neutral_ports):
            continue  # straddles the line (e.g. Strait of Hormuz waiting
            # zone) - no side can be assumed, baseline recorded only
        if old_id is None:
            continue  # first sighting - baseline only
        if int(old_id) == pc_id:
            # Unchanged call. Drop a stamp left when this in-Gulf port was
            # previously mis-read as an exit (see _drop_false_gulf_stamp).
            _drop_false_gulf_stamp(entry, old, port, gulf_ports, gulf_zones)
            continue
        if imo in skip_imos:
            continue  # already alerted via the AIS flip this run
        last = old.get("last_transit_utc") or ""
        if last:
            try:
                age_h = (now - datetime.fromisoformat(last)).total_seconds() / 3600
                if age_h < realert_hours:
                    entry.setdefault("last_transit_utc", last)
                    continue
            except ValueError:
                pass
        # Bloomberg's (possibly stale) view of the vessel
        blat = _to_float(entry.get("lat"))
        blon = _to_float(entry.get("lon"))
        if blat is None or blon is None:
            blat, blon = _to_float(old.get("lat")), _to_float(old.get("lon"))
        if blat is None or blon is None:
            continue  # no AIS view at all - no side to compare against
        bbg_in_gulf = zone_watch.point_in_zones(blon, blat, gulf_zones) is not None
        # If a previous inference already concluded the vessel crossed (and
        # Bloomberg has not produced a new fix since), the vessel's PRESUMED
        # side is the opposite of the stale position - so a later port call
        # back on the original side (a dark return trip) is still caught
        seen_now = entry.get("seen_utc") or old.get("seen_utc") or ""
        alerted_seen = old.get("transit_alerted_seen")
        if alerted_seen and seen_now == alerted_seen:
            bbg_in_gulf = not bbg_in_gulf
        port_coords = _match_gulf_port(port, gulf_ports)  # (lat, lon) | None
        port_in_gulf = port_coords is not None
        if bbg_in_gulf == port_in_gulf:
            continue  # AIS agrees with the port's side - a normal port call
        bbg_seen = pd.to_datetime(
            entry.get("seen_utc") or old.get("seen_utc"),
            errors="coerce", utc=True,
        )
        bbg_age_h = (
            (now - bbg_seen).total_seconds() / 3600
            if pd.notna(bbg_seen) else None
        )
        vol = pd.to_numeric(row.get("Volume"), errors="coerce")
        snap = snapshots.get(imo, {})
        transits.append({
            "imo": imo,
            "name": (
                snap.get("vessel_name")
                or zone_watch.title_case_vessel_name(
                    str(row.get("Name") or entry.get("name") or "")
                )
                or f"IMO {imo}"
            ),
            "direction": (
                "westbound (into the Persian Gulf)" if port_in_gulf
                else "eastbound (out of the Persian Gulf)"
            ),
            "laden": (
                snap.get("laden")
                or ("Laden" if pd.notna(vol) and float(vol) > 0 else "Unladen")
            ),
            "cargo_mcm": snap.get("cargo_mcm") or (
                f"{float(vol) * M3_LNG_TO_MCM:.1f}" if pd.notna(vol) else ""
            ),
            "moved_nm": (
                _distance_nm(blat, blon, *port_coords) if port_coords else None
            ),
            "dark_jump": True,
            "prev_pos": (blat, blon),          # stale Bloomberg fix (lat, lon)
            "curr_pos": port_coords,           # port (lat, lon) or None
            "monitored": imo in snapshots,
            "inferred_port_call": port,
            "bbg_pos": (blat, blon),
            "bbg_age_h": bbg_age_h,
        })
        entry["last_transit_utc"] = now.isoformat(timespec="seconds")
        if port_coords:
            # Re-anchor the cached position to the port: the vessel is
            # really there, and this stops detect_transits re-alerting the
            # same crossing when Bloomberg's AIS finally updates
            entry["lat"], entry["lon"] = port_coords
            entry["pos_source"] = "kpler_port_call"
            entry["transit_alerted_seen"] = ""  # position trustworthy again
        else:
            # Unlisted (outside-Gulf) port - no coordinates to re-anchor to.
            # Stamp the stale fix this inference was judged against so
            # detect_transits can recognise Bloomberg's eventual catch-up
            # flip as the SAME crossing and stay silent
            entry["transit_alerted_seen"] = seen_now
        logger.info(
            "Inferred transit from Kpler port call: %s (IMO %s) at %s, "
            "Bloomberg still shows %.2f, %.2f",
            entry.get("name") or imo, imo, port, blat, blon,
        )
    return transits


def detect_dark_loadings(
    prev_fleet: dict[int, dict],
    curr_fleet: dict[int, dict],
    kpler_fleet: pd.DataFrame | None,
    trade_rows: dict[int, pd.Series] | None,
    gulf_zones: list[dict],
    gulf_ports: dict[str, tuple[float, float]],
    snapshots: dict[int, dict[str, str]] | None = None,
    skip_imos: set[int] | None = None,
    ais_dark_hours: float = 12.0,
) -> list[dict]:
    """
    DOUBLE-DARK transits: a vessel that flips Kpler unladen -> laden with a
    Gulf loading port while Bloomberg AIS has it dark OUTSIDE the Gulf. The
    only physical explanation is that it entered the strait dark, loaded,
    and (unless it resurfaces inside) will leave dark too - a round trip no
    AIS fix and possibly no side-flipping port call ever shows.

    The laden state (Kpler cargo Volume > 0) is tracked per vessel in the
    fleet cache; only the unladen -> laden TRANSITION triggers, so this
    alerts once per loading. The loading port comes from the Kpler last
    port-call or, failing that, the active trade's origin - it must be a
    listed in-Gulf port. The cached position is re-anchored to that port
    afterwards, so the eventual AIS reappearance outside the Gulf raises a
    normal eastbound flip alert, completing the round-trip picture.
    """
    out: list[dict] = []
    if (
        kpler_fleet is None or kpler_fleet.empty
        or not gulf_zones or not gulf_ports
    ):
        return out
    snapshots = snapshots or {}
    skip_imos = skip_imos or set()
    trade_rows = trade_rows or {}
    gulf_ports = _index_gulf_ports(gulf_ports)
    now = datetime.now(timezone.utc)
    for _, row in kpler_fleet.iterrows():
        imo = pd.to_numeric(row.get("IMO"), errors="coerce")
        if pd.isna(imo):
            continue
        imo = int(imo)
        vol = pd.to_numeric(row.get("Volume"), errors="coerce")
        laden_now = bool(pd.notna(vol) and float(vol) > 0)
        entry = curr_fleet.setdefault(
            imo, {"name": str(row.get("Name") or "")}
        )
        old = prev_fleet.get(imo) or {}
        was_laden = old.get("kpler_laden")
        entry["kpler_laden"] = laden_now
        if was_laden is not False or not laden_now:
            continue  # no baseline yet, or no unladen -> laden flip
        if imo in skip_imos:
            continue  # already alerted this run via another signal
        # Where did the cargo come from? Must be a listed in-Gulf port.
        origin = None
        port = str(row.get("Last port-call") or "").strip()
        if port and _match_gulf_port(port, gulf_ports) is not None:
            origin = port
        else:
            trade = trade_rows.get(imo)
            if trade is not None:
                trade_origin = str(trade.get("Origin") or "").strip()
                if (
                    trade_origin
                    and _match_gulf_port(trade_origin, gulf_ports) is not None
                ):
                    origin = trade_origin
        if not origin:
            continue
        # Bloomberg must be dark (stale fix) and (presumed) outside the Gulf
        blat, blon = _to_float(entry.get("lat")), _to_float(entry.get("lon"))
        if blat is None or blon is None:
            blat, blon = _to_float(old.get("lat")), _to_float(old.get("lon"))
        if blat is None or blon is None:
            continue
        seen = entry.get("seen_utc") or old.get("seen_utc") or ""
        seen_ts = pd.to_datetime(seen, errors="coerce", utc=True)
        age_h = (
            (now - seen_ts).total_seconds() / 3600
            if pd.notna(seen_ts) else None
        )
        if age_h is None or age_h < ais_dark_hours:
            continue  # AIS is live - the ordinary flip logic applies
        in_gulf = zone_watch.point_in_zones(blon, blat, gulf_zones) is not None
        alerted_seen = old.get("transit_alerted_seen")
        if alerted_seen and seen == alerted_seen:
            in_gulf = not in_gulf  # presumed side after an earlier inference
        if in_gulf:
            continue  # loading inside while presumed inside - normal call
        port_coords = _match_gulf_port(origin, gulf_ports)
        if port_coords is None:
            continue
        snap = snapshots.get(imo, {})
        out.append({
            "imo": imo,
            "name": (
                snap.get("vessel_name")
                or zone_watch.title_case_vessel_name(
                    str(row.get("Name") or entry.get("name") or "")
                )
                or f"IMO {imo}"
            ),
            "direction": "westbound (into the Persian Gulf)",
            "laden": "Laden",
            "cargo_mcm": f"{float(vol) * M3_LNG_TO_MCM:.1f}",
            "moved_nm": _distance_nm(blat, blon, *port_coords),
            "dark_jump": True,
            "double_dark": True,
            "loaded_at": origin,
            "prev_pos": (blat, blon),
            "curr_pos": port_coords,
            "monitored": imo in snapshots,
            "bbg_pos": (blat, blon),
            "bbg_age_h": age_h,
        })
        entry["last_transit_utc"] = now.isoformat(timespec="seconds")
        entry["lat"], entry["lon"] = port_coords
        entry["pos_source"] = "kpler_dark_loading"
        entry["transit_alerted_seen"] = ""
        logger.info(
            "Double-dark transit inferred: %s (IMO %s) went laden at %s while "
            "Bloomberg AIS dark outside the Gulf (%.2f, %.2f, %.0fh old)",
            entry.get("name") or imo, imo, origin, blat, blon, age_h,
        )
    return out


def diff_snapshots(
    prev: dict[int, dict[str, str]],
    curr: dict[int, dict[str, str]],
    references: dict[int, dict],
    thresholds: dict[str, float],
) -> tuple[dict[int, dict[str, tuple[str, str]]], dict[int, tuple[float, float]]]:
    """
    Returns (changes, moved_from). ``references`` is updated in place.

    - Categorical fields (destination, nav status, in_zone, laden, ...):
      any change vs the previous snapshot alerts. Zone entry/exit is one of
      these, so it always alerts.
    - Position / speed / heading: compared against the reference (the value
      at the last alert), alerting only beyond the configured thresholds and
      rebasing the reference when they fire. Position uses a tighter
      threshold while a vessel has been monitored for < recent_hours.
    - ALERT_EXEMPT_FIELDS never alert (display only).

    ``moved_from`` maps imo -> (lon, lat) of the old reference position for
    vessels whose position alert fired (used for the map's pale markers).
    """
    now = datetime.now(timezone.utc)
    changes: dict[int, dict[str, tuple[str, str]]] = {}
    moved_from: dict[int, tuple[float, float]] = {}

    for imo, snap in curr.items():
        old = prev.get(imo)
        ref = references.setdefault(
            imo, {"monitor_start_utc": now.isoformat(timespec="seconds")}
        )
        # Seed missing reference values from the previous (or first) snapshot
        seed_source = old if old is not None else snap
        for f in ("latitude", "longitude", "speed_knots", "heading"):
            if f not in ref:
                v = _to_float(seed_source.get(f, ""))
                if v is not None:
                    ref[f] = v
        if old is None:
            continue  # first snapshot for this vessel - baseline, not a change

        fields: dict[str, tuple[str, str]] = {}

        # Categorical fields: any change alerts
        for f in SNAPSHOT_FIELDS:
            if f in ALERT_EXEMPT_FIELDS or f in THRESHOLD_FIELDS:
                continue
            if old.get(f, "") != snap.get(f, ""):
                fields[f] = (old.get(f, ""), snap.get(f, ""))

        # Position vs reference
        lat, lon = _to_float(snap.get("latitude")), _to_float(snap.get("longitude"))
        rlat, rlon = ref.get("latitude"), ref.get("longitude")
        if lat is not None and lon is not None:
            if rlat is None or rlon is None:
                ref["latitude"], ref["longitude"] = lat, lon
            else:
                start = pd.to_datetime(ref.get("monitor_start_utc"), utc=True)
                age_hours = (
                    (now - start).total_seconds() / 3600.0
                    if pd.notna(start) else 1e9
                )
                pos_thr = (
                    thresholds["position_nm_recent"]
                    if age_hours < thresholds["recent_hours"]
                    else thresholds["position_nm"]
                )
                moved = _distance_nm(rlat, rlon, lat, lon)
                if moved >= pos_thr:
                    fields["position"] = (
                        f"{rlat:.4f}, {rlon:.4f}",
                        f"{lat:.4f}, {lon:.4f} (moved {moved:.1f} nm)",
                    )
                    moved_from[imo] = (rlon, rlat)
                    ref["latitude"], ref["longitude"] = lat, lon

        # Speed vs reference
        spd, rspd = _to_float(snap.get("speed_knots")), ref.get("speed_knots")
        if spd is not None:
            if rspd is None:
                ref["speed_knots"] = spd
            elif abs(spd - rspd) >= thresholds["speed_kn"]:
                fields["speed_knots"] = (f"{rspd:.1f}", f"{spd:.1f}")
                ref["speed_knots"] = spd

        # Heading vs reference (circular difference). Ignored while the
        # vessel is essentially stationary: anchored/moored vessels swing
        # with wind and tide without going anywhere, which is not news. The
        # reference is NOT rebased while stationary, so if the vessel gets
        # under way on a genuinely new heading it still alerts.
        hdg, rhdg = _to_float(snap.get("heading")), ref.get("heading")
        stationary = (
            spd is not None and spd < thresholds.get("heading_min_speed_kn", 1.0)
        )
        if hdg is not None and not stationary:
            if rhdg is None:
                ref["heading"] = hdg
            else:
                turn = abs(hdg - rhdg) % 360.0
                turn = min(turn, 360.0 - turn)
                if turn >= thresholds["heading_deg"]:
                    fields["heading"] = (
                        f"{rhdg:.0f}", f"{hdg:.0f} (turned {turn:.0f} deg)"
                    )
                    ref["heading"] = hdg

        if fields:
            changes[imo] = fields

    # Drop references for vessels no longer monitored
    for imo in list(references):
        if imo not in curr:
            del references[imo]

    return changes, moved_from


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

_TABLE_STYLE = (
    "border-collapse:collapse;font-family:Calibri,Arial,sans-serif;"
    "font-size:13px;margin-bottom:14px;"
)
_TH_STYLE = (
    "border:1px solid #999;padding:3px 8px;background:#1f3864;color:#fff;"
    "text-align:left;"
)
_TD_STYLE = "border:1px solid #999;padding:3px 8px;"


def _html_table(headers: list[str], rows: list[list[str]]) -> str:
    head = "".join(f"<th style='{_TH_STYLE}'>{h}</th>" for h in headers)
    body = "".join(
        "<tr>" + "".join(f"<td style='{_TD_STYLE}'>{c or '&ndash;'}</td>" for c in row) + "</tr>"
        for row in rows
    )
    return f"<table style='{_TABLE_STYLE}'><tr>{head}</tr>{body}</table>"


def _ais_display(snap: dict[str, str]) -> str:
    """Last AIS ping (timestamp + age) for the email table; dark in red."""
    last_seen = pd.to_datetime(snap.get("last_seen", ""), errors="coerce", utc=True)
    if pd.isna(last_seen):
        return snap.get("ais_status", "")
    stamp = last_seen.strftime("%d-%b %H:%M")
    age_hours = (pd.Timestamp.now(tz="UTC") - last_seen).total_seconds() / 3600.0
    if snap.get("ais_status", "").startswith("Dark"):
        return (
            f"<b style='color:#c0392b;'>DARK {age_hours:,.0f}h "
            f"(last {stamp} UTC)</b>"
        )
    age = (
        f"{age_hours * 60:.0f}m ago" if age_hours < 1 else f"{age_hours:.1f}h ago"
    )
    return f"{stamp} UTC ({age})"


def _vessel_links_html(imo: int, snap: dict[str, str]) -> str:
    """Kpler map + Bloomberg Terminal deep links (as per Cargo Forecast
    History in eu_dashboard_power). bbg:// opens the Terminal MAP screen."""
    links = []
    kpler_id = snap.get("kpler_vessel_id", "")
    if kpler_id:
        links.append(
            f"<a href='{KPLER_VESSEL_MAP_URL.format(kpler_id)}'>Kpler</a>"
        )
    links.append(f"<a href='{BBG_VESSEL_MAP_URL.format(imo)}'>Bloomberg</a>")
    return " &middot; ".join(links)


def _spread_label_positions(
    points: list[tuple[float, float]], threshold: float = 0.3
) -> list[str]:
    """A text position per point; nearby points get different positions so
    labels of co-located vessels do not overprint."""
    order = [
        "top center", "bottom center", "middle right", "middle left",
        "top right", "bottom left", "top left", "bottom right",
    ]
    out: list[str] = []
    placed: list[tuple[float, float]] = []
    for lon, lat in points:
        n_near = sum(
            1 for plon, plat in placed
            if abs(plon - lon) < threshold and abs(plat - lat) < threshold
        )
        out.append(order[n_near % len(order)])
        placed.append((lon, lat))
    return out


def load_position_trails(
    imos: set[int], hours: float = 12.0
) -> dict[int, list[tuple[float, float]]]:
    """Recent (lon, lat) positions per vessel from the snapshot history CSV
    (oldest first, consecutive duplicates collapsed) - the map's breadcrumb
    trail. Only vessels with at least 2 distinct points get a trail."""
    if not imos or hours <= 0 or not HISTORY_FILE.exists():
        return {}
    try:
        hist = pd.read_csv(
            HISTORY_FILE, usecols=["run_utc", "imo", "latitude", "longitude"]
        )
    except (ValueError, pd.errors.ParserError) as exc:
        logger.warning("Could not read history for map trails: %s", exc)
        return {}
    hist["run_utc"] = pd.to_datetime(hist["run_utc"], errors="coerce", utc=True)
    cutoff = pd.Timestamp.now(tz="UTC") - pd.Timedelta(hours=hours)
    hist = hist[hist["run_utc"] >= cutoff]
    trails: dict[int, list[tuple[float, float]]] = {}
    for imo in imos:
        rows = hist[hist["imo"] == imo].sort_values("run_utc")
        pts: list[tuple[float, float]] = []
        for _, r in rows.iterrows():
            lat, lon = _to_float(r["latitude"]), _to_float(r["longitude"])
            if lat is None or lon is None:
                continue
            if pts and pts[-1] == (lon, lat):
                continue  # stationary run - no new breadcrumb
            pts.append((lon, lat))
        if len(pts) >= 2:
            trails[imo] = pts
    return trails


def build_map_png(
    zones: list[dict],
    snapshots: dict[int, dict[str, str]],
    highlight_imos: set[int],
    prev_positions: dict[int, tuple[float, float]] | None = None,
    transit_lines: list[dict] | None = None,
    trails: dict[int, list[tuple[float, float]]] | None = None,
    trail_hours: float = 12.0,
) -> str | None:
    """Base64 PNG map: zone polygon(s), monitored vessels (grey), new/changed
    vessels (solid red, labelled) and, for changed vessels, their previous
    cached position (pale red, dashed connector). None when nothing has a
    position.

    Rendered as a real map (Plotly Scattergeo: Natural Earth coastlines,
    land and borders, bundled with plotly so it works offline) via kaleido;
    falls back to a plain matplotlib lon/lat plot if that renderer is
    unavailable (e.g. no Chrome for kaleido >= 1.0)."""
    points = []
    for imo, snap in snapshots.items():
        try:
            lat = float(snap.get("latitude", ""))
            lon = float(snap.get("longitude", ""))
        except ValueError:
            continue
        name = snap.get("vessel_name") or f"IMO {imo}"
        points.append((imo, lon, lat, name, imo in highlight_imos))
    if not points:
        return None
    prev_positions = prev_positions or {}
    transit_lines = transit_lines or []
    trails = trails or {}
    try:
        return _map_png_plotly(
            zones, points, prev_positions, transit_lines, trails, trail_hours
        )
    except Exception as exc:
        logger.warning("Plotly map render failed (%s); matplotlib fallback", exc)
        return _map_png_matplotlib(
            zones, points, prev_positions, transit_lines, trails, trail_hours
        )


TOPOJSON_DIR = REPORTS_PATH / "topojson"


def _map_png_plotly(
    zones: list[dict],
    points: list[tuple],
    prev_positions: dict[int, tuple[float, float]],
    transit_lines: list[dict] | None = None,
    trails: dict[int, list[tuple[float, float]]] | None = None,
    trail_hours: float = 12.0,
) -> str:
    """Proper map: Scattergeo with coastlines/land, zone fill, vessel markers."""
    # Scattergeo base-map geometry is normally fetched from cdn.plot.ly at
    # render time, which fails on the firewalled server. Point kaleido at the
    # topojson files vendored in this repo instead (fully offline render).
    if TOPOJSON_DIR.is_dir():
        import plotly.io as pio

        pio.kaleido.scope.topojson = TOPOJSON_DIR.as_uri() + "/"

    fig = go.Figure()
    for zone in zones:
        lons, lats = zip(*zone["ring"])
        fig.add_trace(go.Scattergeo(
            lon=lons, lat=lats, mode="lines", fill="toself",
            fillcolor="rgba(31,56,100,0.16)",
            line={"width": 2, "color": "#1f3864"},
            name=zone["name"],
        ))

    for line in (transit_lines or []):
        lons, lats = zip(*line["coords"])
        fig.add_trace(go.Scattergeo(
            lon=lons, lat=lats, mode="lines",
            line={"width": 2, "color": "#c0392b", "dash": "dash"},
            name="Transit line",
        ))

    # Breadcrumb trails (drawn first, so markers sit on top): recent
    # positions of the highlighted vessels from the snapshot history
    show_trail_legend = True
    for pts in (trails or {}).values():
        lons, lats = zip(*pts)
        fig.add_trace(go.Scattergeo(
            lon=lons, lat=lats, mode="lines+markers",
            marker={"size": 3, "color": "rgba(192,57,43,0.45)"},
            line={"width": 0.8, "color": "rgba(192,57,43,0.25)"},
            name=f"Trail (last {trail_hours:.0f}h)",
            showlegend=show_trail_legend, hoverinfo="skip",
        ))
        show_trail_legend = False

    existing = [p for p in points if not p[4]]
    marked = [p for p in points if p[4]]
    current_pos = {p[0]: (p[1], p[2]) for p in points}

    if existing:
        fig.add_trace(go.Scattergeo(
            lon=[p[1] for p in existing], lat=[p[2] for p in existing],
            mode="markers",
            marker={"size": 5, "color": "#6c757d"},
            name="Monitored vessels",
        ))

    # Previous cached positions of changed vessels: pale red diamonds with a
    # dashed connector to the current position (shows the movement)
    prev_pts = [
        (imo, lon, lat) for imo, (lon, lat) in prev_positions.items()
        if imo in current_pos
    ]
    if prev_pts:
        for imo, plon, plat in prev_pts:
            clon, clat = current_pos[imo]
            fig.add_trace(go.Scattergeo(
                lon=[plon, clon], lat=[plat, clat], mode="lines",
                line={"width": 1.2, "color": "rgba(192,57,43,0.45)",
                      "dash": "dot"},
                showlegend=False, hoverinfo="skip",
            ))
        fig.add_trace(go.Scattergeo(
            lon=[p[1] for p in prev_pts], lat=[p[2] for p in prev_pts],
            mode="markers",
            marker={"size": 7, "color": "rgba(192,57,43,0.25)",
                    "symbol": "diamond"},
            name="Previous position",
        ))

    if marked:
        fig.add_trace(go.Scattergeo(
            lon=[p[1] for p in marked], lat=[p[2] for p in marked],
            mode="markers+text",
            marker={"size": 8, "color": "#c0392b", "symbol": "diamond"},
            text=[p[3] for p in marked],
            textposition=_spread_label_positions(
                [(p[1], p[2]) for p in marked]
            ),
            textfont={"size": 8, "color": "#c0392b", "family": "Arial Black"},
            name="New / changed vessel(s)",
        ))

    # Frame on the zone + highlighted vessels (and their previous positions),
    # so a distant monitored vessel does not zoom the map out; out-of-frame
    # fleet markers just clip off.
    frame_pts = [(p[1], p[2]) for p in points if p[4]]
    frame_pts += [(lon, lat) for _, lon, lat in prev_pts]
    frame_pts += [pt for pts in (trails or {}).values() for pt in pts]
    all_lons = [p[0] for p in frame_pts] + [c[0] for z in zones for c in z["ring"]]
    all_lats = [p[1] for p in frame_pts] + [c[1] for z in zones for c in z["ring"]]
    pad = 0.6
    fig.update_geos(
        resolution=50,
        showland=True, landcolor="#ece5d4",
        showocean=True, oceancolor="#d8e7f2",
        showcountries=True, countrycolor="#b0a998",
        showcoastlines=True, coastlinecolor="#8a8272",
        lonaxis_range=[min(all_lons) - pad, max(all_lons) + pad],
        lataxis_range=[min(all_lats) - pad, max(all_lats) + pad],
    )
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 6, "b": 0},
        width=560, height=380,
        legend={
            "orientation": "h", "yanchor": "bottom", "y": 0.01,
            "xanchor": "left", "x": 0.01,
            "bgcolor": "rgba(255,255,255,0.85)", "font": {"size": 8},
        },
    )
    return base64.b64encode(fig.to_image(format="png", scale=2)).decode()


def _map_png_matplotlib(
    zones: list[dict],
    points: list[tuple],
    prev_positions: dict[int, tuple[float, float]],
    transit_lines: list[dict] | None = None,
    trails: dict[int, list[tuple[float, float]]] | None = None,
    trail_hours: float = 12.0,
) -> str:
    """Fallback: plain lon/lat plot of the zone polygon(s) and markers."""
    fig, ax = plt.subplots(figsize=(6.2, 4.2), dpi=100)
    for zone in zones:
        lons, lats = zip(*zone["ring"])
        ax.fill(lons, lats, color="#1f3864", alpha=0.10, zorder=1)
        ax.plot(lons, lats, color="#1f3864", lw=1.3, zorder=2,
                label=zone["name"])
    for line in (transit_lines or []):
        lons, lats = zip(*line["coords"])
        ax.plot(lons, lats, color="#c0392b", lw=1.6, ls="--", zorder=2,
                label="Transit line")

    # Breadcrumb trails under the markers
    for i, pts in enumerate((trails or {}).values()):
        lons, lats = zip(*pts)
        ax.plot(lons, lats, color="#c0392b", alpha=0.25, lw=0.8, zorder=2)
        ax.scatter(lons, lats, s=6, color="#c0392b", alpha=0.4, zorder=2,
                   label=f"Trail (last {trail_hours:.0f}h)" if i == 0 else None)

    existing = [p for p in points if not p[4]]
    marked = [p for p in points if p[4]]
    current_pos = {p[0]: (p[1], p[2]) for p in points}
    if existing:
        ax.scatter([p[1] for p in existing], [p[2] for p in existing],
                   s=28, color="#6c757d", zorder=3, label="Monitored vessels")
    prev_pts = [
        (imo, lon, lat) for imo, (lon, lat) in prev_positions.items()
        if imo in current_pos
    ]
    if prev_pts:
        for imo, plon, plat in prev_pts:
            clon, clat = current_pos[imo]
            ax.plot([plon, clon], [plat, clat], color="#c0392b", alpha=0.45,
                    lw=1.0, ls=":", zorder=3)
        ax.scatter([p[1] for p in prev_pts], [p[2] for p in prev_pts],
                   s=50, color="#c0392b", alpha=0.25, marker="D", zorder=3,
                   label="Previous position")
    if marked:
        ax.scatter([p[1] for p in marked], [p[2] for p in marked],
                   s=60, color="#c0392b", marker="D", zorder=4,
                   label="New / changed vessel(s)")
        for i, (_, lon, lat, name, _) in enumerate(marked):
            offset = (6, 5) if i % 2 == 0 else (6, -12)
            ax.annotate(name, (lon, lat), textcoords="offset points",
                        xytext=offset, fontsize=7, color="#c0392b",
                        fontweight="bold", zorder=5)

    frame_pts = [(p[1], p[2]) for p in points if p[4]]
    frame_pts += [(lon, lat) for _, lon, lat in prev_pts]
    frame_pts += [pt for pts in (trails or {}).values() for pt in pts]
    all_lons = [p[0] for p in frame_pts] + [c[0] for z in zones for c in z["ring"]]
    all_lats = [p[1] for p in frame_pts] + [c[1] for z in zones for c in z["ring"]]
    pad = 0.6
    ax.set_xlim(min(all_lons) - pad, max(all_lons) + pad)
    ax.set_ylim(min(all_lats) - pad, max(all_lats) + pad)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Monitored zone and vessel positions")
    ax.grid(True, lw=0.3, alpha=0.5)
    ax.legend(loc="lower left", fontsize=7)
    fig.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


_VESSEL_TABLE_HEADERS = [
    "Vessel", "IMO", "Type", "Owner", "Controller", "Laden", "Cargo (mcm)",
    "Position (lat, lon)", "Speed (kn)", "Heading", "Last AIS",
    "Destination", "Nav status", "Trade status", "View Location",
]


def _vessel_table_row(imo: int, snap: dict[str, str]) -> list[str]:
    return [
        snap.get("vessel_name") or f"IMO {imo}",
        str(imo),
        snap.get("kpler_vessel_type", ""),
        snap.get("kpler_owners", ""),
        snap.get("kpler_controller", ""),
        snap.get("laden", ""),
        snap.get("cargo_mcm", ""),
        f"{snap.get('latitude', '')}, {snap.get('longitude', '')}",
        snap.get("speed_knots", ""),
        snap.get("heading", ""),
        _ais_display(snap),
        snap.get("destination", "") or snap.get("kpler_destination", ""),
        snap.get("navigation_status", ""),
        snap.get("trade_status", ""),
        _vessel_links_html(imo, snap),
    ]


def build_email_body(
    changes: dict[int, dict[str, tuple[str, str]]],
    new_vessels: list[dict],
    snapshots: dict[int, dict[str, str]],
    n_monitored: int,
    zones: list[dict],
    moved_from: dict[int, tuple[float, float]] | None = None,
    thresholds: dict[str, float] | None = None,
    exited_vessels: list[dict] | None = None,
    transits: list[dict] | None = None,
    transit_lines: list[dict] | None = None,
    trail_hours: float = 12.0,
) -> str:
    moved_from = moved_from or {}
    exited_vessels = exited_vessels or []
    transits = transits or []
    transit_lines = transit_lines or []
    now = datetime.now(timezone.utc).strftime("%d %b %Y %H:%M UTC")
    parts = [
        "<div style='font-family:Calibri,Arial,sans-serif;'>",
        f"<h2 style='margin-bottom:2px;'>Hormuz LNG Vessel Monitor</h2>",
        f"<p style='margin-top:2px;color:#555;'>Snapshot {now} &middot; "
        f"{n_monitored} vessels monitored</p>",
    ]

    if transits:
        parts.append(
            "<h3 style='color:#1e7d32;'>Successful Strait of Hormuz "
            "transits</h3>"
        )
        rows = []
        for t in sorted(transits, key=lambda x: x["name"]):
            snap = snapshots.get(t["imo"], {})
            if t.get("double_dark"):
                blat, blon = t["bbg_pos"]
                age = t.get("bbg_age_h")
                age_txt = f", {age:,.0f}h old" if age is not None else ""
                note = (
                    "<b style='color:#c0392b;'>DOUBLE-DARK TRANSIT inferred "
                    "from Kpler cargo data</b>: went unladen &rarr; laden "
                    f"after loading at {t['loaded_at']}, while Bloomberg AIS "
                    "has the vessel dark OUTSIDE the Gulf at "
                    f"{blat:.2f}, {blon:.2f} (last fix{age_txt}) - it entered "
                    "dark and will likely leave dark; deviates from the "
                    "Bloomberg position"
                )
            elif t.get("inferred_port_call"):
                blat, blon = t["bbg_pos"]
                age = t.get("bbg_age_h")
                age_txt = f", {age:,.0f}h old" if age is not None else ""
                note = (
                    "<b style='color:#c0392b;'>INFERRED from Kpler port call "
                    f"at {t['inferred_port_call']}</b> - deviates from "
                    "Bloomberg AIS, which still shows the vessel at "
                    f"{blat:.2f}, {blon:.2f} (last fix{age_txt}); no AIS fix "
                    "of the crossing exists"
                )
            elif t.get("dark_jump"):
                note = "<b style='color:#c0392b;'>crossed while AIS dark</b>"
            else:
                note = ""
            direction = t["direction"] + (
                " <i>(inferred)</i>"
                if t.get("inferred_port_call") or t.get("double_dark") else ""
            )
            cargo = t.get("cargo_mcm") or ""
            moved = (
                f"{t['moved_nm']:,.1f} nm"
                if t.get("moved_nm") is not None else "&mdash;"
            )
            rows.append([
                f"<b>{t['name']}</b>", t["imo"], direction,
                t.get("laden") or "&mdash;", cargo,
                moved, note,
                _vessel_links_html(t["imo"], snap),
            ])
        parts.append(_html_table(
            ["Vessel", "IMO", "Direction", "Laden", "Cargo (mcm)",
             "Moved", "Note", "View Location"],
            rows,
        ))

    if new_vessels:
        parts.append("<h3>New vessels in monitored zone</h3>")
        parts.append(_html_table(
            _VESSEL_TABLE_HEADERS,
            [_vessel_table_row(e["imo"], snapshots.get(e["imo"], {}))
             for e in new_vessels],
        ))

    if exited_vessels:
        parts.append(
            "<h3 style='color:#c0392b;'>Vessels that LEFT the monitored zone</h3>"
        )
        rows = []
        for e in sorted(exited_vessels, key=lambda x: x["name"]):
            snap = snapshots.get(e["imo"], {})
            plat, plon = e.get("prev_pos") or (None, None)
            last_pos = (
                f"{plat:.4f}, {plon:.4f}" if plat is not None and plon is not None
                else ""
            )
            curr_pos = f"{snap.get('latitude', '')}, {snap.get('longitude', '')}"
            jump = e.get("jump_nm")
            if jump is None:
                jump_txt = ""
            elif jump >= 50:
                jump_txt = (
                    f"<b style='color:#c0392b;'>{jump:,.0f} nm jump "
                    "(AIS gap - position was stale)</b>"
                )
            else:
                jump_txt = f"{jump:.1f} nm"
            status = (
                "still monitored (static list)" if e.get("static")
                else "monitoring stopped"
            )
            rows.append([
                f"<b>{e['name']}</b>", e["imo"], e["from_zone"],
                last_pos, curr_pos, jump_txt, status,
                _vessel_links_html(e["imo"], snap),
            ])
        parts.append(_html_table(
            ["Vessel", "IMO", "Zone left", "Last position in zone",
             "Current position", "Moved", "Status", "View Location"],
            rows,
        ))

    if changes:
        parts.append("<h3>Changes since previous snapshot</h3>")
        for imo, fields in sorted(changes.items()):
            snap = snapshots.get(imo, {})
            name = snap.get("vessel_name") or f"IMO {imo}"
            parts.append(
                f"<h4 style='margin-bottom:2px;'>{name} (IMO {imo})</h4>"
                f"<p style='margin:0 0 6px 0;font-size:12px;'>"
                f"{_vessel_links_html(imo, snap)}</p>"
            )
            rows = []
            for f, (old, new) in fields.items():
                if f == "in_zone":  # make exits/entries explicit, not blank
                    old = old or "(outside zone)"
                    new = new or "<b style='color:#c0392b;'>(outside zone)</b>"
                rows.append([f, old or "&mdash;", new or "&mdash;"])
            parts.append(_html_table(["Field", "Previous", "Current"], rows))

    # Map: new + changed + transiting vessels highlighted; vessels whose
    # position alert fired also get their previous reference position (pale)
    highlight = (
        {e["imo"] for e in new_vessels} | set(changes)
        | {t["imo"] for t in transits}
    )
    if highlight:
        trails = load_position_trails(highlight, trail_hours)
        map_b64 = build_map_png(
            zones, snapshots, highlight, moved_from, transit_lines,
            trails, trail_hours,
        )
        if map_b64:
            parts.append(
                f"<img src='data:image/png;base64,{map_b64}' "
                "style='max-width:560px;width:100%;' "
                "alt='Zone map with vessel positions'>"
            )

    # Recap: everything currently inside the monitored zone
    in_zone_imos = sorted(
        (imo for imo, s in snapshots.items() if s.get("in_zone")),
        key=lambda i: snapshots[i].get("vessel_name", ""),
    )
    if in_zone_imos:
        parts.append("<h3>All vessels currently in monitored zone</h3>")
        parts.append(_html_table(
            _VESSEL_TABLE_HEADERS,
            [_vessel_table_row(imo, snapshots[imo]) for imo in in_zone_imos],
        ))

    # Notes: what triggers an alert and what is suppressed
    if thresholds:
        parts.append(
            "<h4 style='margin-bottom:4px;color:#555;'>Alert rules</h4>"
            "<ul style='color:#666;font-size:11px;margin-top:2px;'>"
            "<li>Zone entry/exit, destination, nav status, laden/unladen, "
            "AIS going dark or reappearing, and voyage/controller changes "
            "always alert.</li>"
            "<li>Position, speed and heading are compared against their value "
            "at the <i>last alert</i> (not the previous 5-minute snapshot), so "
            "AIS ping jitter is ignored but slow drift still accumulates to "
            "an alert. Thresholds: position &ge; "
            f"{thresholds['position_nm']:.1f} nm "
            f"({thresholds['position_nm_recent']:.1f} nm while a vessel has "
            f"been monitored &lt; {thresholds['recent_hours']:.0f}h), "
            f"speed &ge; {thresholds['speed_kn']:.1f} kn, "
            f"heading &ge; {thresholds['heading_deg']:.0f}&deg;.</li>"
            "<li>Last AIS timestamp updates never alert on their own; the "
            "latest ping is shown in the zone table above.</li>"
            "<li>A vessel leaving the zone gets a final exit alert and then "
            "stops being monitored (vessels on the static config list are "
            "always kept). If it re-enters within "
            f"{thresholds.get('reentry_cooldown_min', 60):.0f} minutes, "
            "monitoring resumes silently; later re-entries alert as a new "
            "vessel.</li>"
            "<li>Heading changes are ignored while a vessel is doing "
            f"&lt; {thresholds.get('heading_min_speed_kn', 1):.1f} kn "
            "(anchored vessels swing with wind/tide without moving).</li>"
            "<li>A vessel that flips sides of the transit line (dashed red "
            "on the map) is flagged as a successful strait transit with "
            "direction and cargo state. This check runs against the "
            "<i>entire in-service LNG fleet</i>, not just monitored vessels, "
            "and sides are judged against the whole Persian-Gulf region - so "
            "a vessel that left the zone, went dark inside the Gulf and "
            "reappeared far beyond the line (off India, en route Suez, ...) "
            "still counts. A vessel re-crossing within "
            f"{thresholds.get('transit_realert_hours', 6):.0f}h of its last "
            "transit alert is suppressed (boundary ping-pong guard).</li>"
            "<li>Transits are ALSO inferred from Kpler port calls: a vessel "
            "whose registered last port call flips to the other side of the "
            "strait from where Bloomberg AIS still places it (typical for "
            "dark vessels) is alerted as an inferred transit - explicitly "
            "marked, since it deviates from the Bloomberg lat/lon. The list "
            "of in-Gulf ports is configurable (gulf_ports).</li>"
            "<li>DOUBLE-DARK transits: a vessel flipping Kpler unladen "
            "&rarr; laden with an in-Gulf loading port while Bloomberg AIS "
            "has it dark outside the Gulf must have entered the strait dark "
            "(and will likely leave dark) - alerted once per loading. Its "
            "eventual AIS reappearance outside the Gulf then alerts as a "
            "normal eastbound transit, completing the round trip.</li>"
            "</ul>"
        )

    parts.append(
        "<p style='color:#888;font-size:11px;'>Sources: Bloomberg BSRCH "
        "(comdty:ship AIS) + Kpler LNG API (vessels &amp; trades). "
        "Config: eu_reports/hormuz_vessel_monitor/hormuz_vessel_monitor.cfg</p></div>"
    )
    return "".join(parts)


# ---------------------------------------------------------------------------
# Main run
# ---------------------------------------------------------------------------

def run_once(*, dry_run: bool = False, log=None) -> dict:
    """One monitor cycle. Returns a summary dict (used by the Dagster asset)."""
    log = log or logger
    config = load_config()
    receivers, _ = get_receivers(config)
    monitor_cfg = config["Monitor"]

    static_vessels = zone_watch.parse_static_vessels(monitor_cfg.get("vessels", ""))
    zone_file = REPORTS_PATH / monitor_cfg.get("zone_file", "zones/hormuz_zone.geojson")
    lookback_days = monitor_cfg.getint("trades_lookback_days", fallback=90)
    ais_dark_hours = monitor_cfg.getfloat("ais_dark_hours", fallback=12.0)
    thresholds = {
        "position_nm": monitor_cfg.getfloat("position_alert_nm", fallback=2.0),
        "position_nm_recent": monitor_cfg.getfloat(
            "position_alert_nm_recent", fallback=0.5
        ),
        "recent_hours": monitor_cfg.getfloat("recent_hours", fallback=12.0),
        "speed_kn": monitor_cfg.getfloat("speed_alert_kn", fallback=2.0),
        "heading_deg": monitor_cfg.getfloat("heading_alert_deg", fallback=20.0),
        "heading_min_speed_kn": monitor_cfg.getfloat(
            "heading_alert_min_speed_kn", fallback=1.0
        ),
    }
    reentry_cooldown_min = monitor_cfg.getfloat(
        "exit_reentry_cooldown_minutes", fallback=60.0
    )
    thresholds["reentry_cooldown_min"] = reentry_cooldown_min
    trail_hours = monitor_cfg.getfloat("map_trail_hours", fallback=12.0)
    transit_realert_hours = monitor_cfg.getfloat(
        "transit_realert_hours", fallback=6.0
    )
    thresholds["transit_realert_hours"] = transit_realert_hours

    zones = zone_watch.load_zones(zone_file)
    # The line is what gets DRAWN on the map; the Gulf-side polygon (whose
    # seaward edge is that same line) is what transit detection tests against
    transit_lines = zone_watch.load_transit_lines(
        REPORTS_PATH / monitor_cfg.get(
            "transit_line_file", "zones/hormuz_transit_line.geojson"
        )
    )
    try:
        gulf_zones = zone_watch.load_zones(
            REPORTS_PATH / monitor_cfg.get(
                "transit_gulf_polygon_file", "zones/persian_gulf_side.geojson"
            )
        )
    except (FileNotFoundError, ValueError) as exc:
        log.warning("Gulf-side polygon unavailable (%s) - transit detection off", exc)
        gulf_zones = []

    # 1. Bloomberg: whole in-service LNG fleet, one BSRCH call
    bbg = bbg_ships.fetch_lng_ship_snapshot()
    log.info("Bloomberg LNG fleet snapshot: %d vessels", len(bbg))

    # 2. Zone watch: auto-add new vessels in zone to the persisted watchlist
    auto_watchlist = zone_watch.load_auto_watchlist(WATCHLIST_FILE)
    in_zone = zone_watch.vessels_in_zone(bbg, zones)
    log.info("Vessels currently in zone: %d", len(in_zone))
    new_entries = zone_watch.update_watchlist_from_zone(
        in_zone, static_vessels, auto_watchlist,
        reentry_cooldown_min=reentry_cooldown_min,
    )

    # Monitor statics + autos that have not exited the zone
    watchlist: dict[int, str] = {
        **static_vessels,
        **{imo: entry["name"] for imo, entry in auto_watchlist.items()
           if not entry.get("exited_utc")},
    }
    imos = list(watchlist)
    log.info("Watchlist: %d vessels (%d static, %d auto)",
             len(watchlist), len(static_vessels),
             len(watchlist) - len(static_vessels))

    # 3. Kpler: fleet status + current voyage per watchlist vessel
    token = kpler_data.kpler_login(
        config.get("Kpler", "email"), config.get("Kpler", "password")
    )
    # Whole fleet once: watchlist enrichment + fleet-wide port-call checks
    kpler_fleet = kpler_data.fetch_kpler_fleet(token)
    kpler_vessels = kpler_data.fetch_kpler_vessels(token, imos, fleet=kpler_fleet)
    start_date = (
        datetime.now(timezone.utc) - timedelta(days=lookback_days)
    ).date().isoformat()
    trades = kpler_data.fetch_kpler_trades(token, start_date)
    trade_rows = kpler_data.current_trade_by_imo(trades, imos)

    # Bloomberg rows keyed by IMO
    bbg_by_imo: dict[int, pd.Series] = {}
    if not bbg.empty and "imo" in bbg.columns:
        valid = bbg.dropna(subset=["imo"])
        bbg_by_imo = {int(r["imo"]): r for _, r in valid.iterrows()
                      if int(r["imo"]) in watchlist}

    # 4. Blend into per-vessel snapshots
    snapshots: dict[int, dict[str, str]] = {}
    for imo, name in watchlist.items():
        bbg_row = bbg_by_imo.get(imo)
        zone_name = None
        if bbg_row is not None:
            zone_name = zone_watch.point_in_zones(
                bbg_row.get("longitude"), bbg_row.get("latitude"), zones
            )
        snapshots[imo] = build_vessel_snapshot(
            imo, name, bbg_row,
            kpler_vessels.loc[imo] if imo in kpler_vessels.index else None,
            trade_rows.get(imo), zone_name,
            ais_dark_hours=ais_dark_hours,
        )

    # 5. Diff vs previous snapshot (thresholded), persist, alert
    prev, references = load_latest_snapshots()
    changes, moved_from = diff_snapshots(prev, snapshots, references, thresholds)

    # Transit detection is FLEET-WIDE (whole Bloomberg LNG fleet vs its
    # positions last run) so vessels retired from monitoring - or never
    # monitored at all - still alert when they cross the strait
    prev_fleet = load_fleet_positions()
    curr_fleet = fleet_positions_from_bbg(bbg)
    transits = detect_transits(
        prev_fleet, curr_fleet, gulf_zones, snapshots,
        realert_hours=transit_realert_hours, ais_dark_hours=ais_dark_hours,
    )
    for t in transits:
        log.info("Successful strait transit: %s (IMO %s) %s, %s%s",
                 t["name"], t["imo"], t["direction"], t["laden"] or "cargo n/a",
                 "" if t["monitored"] else " [not on watchlist]")
    # Second, independent signal: transits inferred from Kpler port calls,
    # for crossings Bloomberg AIS never showed (dark vessel reappears as a
    # registered port call on the other side of the strait)
    gulf_ports = _parse_gulf_ports(monitor_cfg.get("gulf_ports", ""))
    neutral_ports = {
        p.strip().lower()
        for p in monitor_cfg.get("neutral_ports", "").split(",") if p.strip()
    }
    transits += detect_port_call_transits(
        prev_fleet, curr_fleet, kpler_fleet, gulf_zones, gulf_ports,
        snapshots=snapshots, skip_imos={t["imo"] for t in transits},
        realert_hours=transit_realert_hours, neutral_ports=neutral_ports,
    )
    # Third signal: double-dark transits - unladen -> laden with a Gulf
    # loading port while Bloomberg AIS is dark outside the Gulf (the vessel
    # entered, loaded and will likely leave without a single AIS fix)
    fleet_imos = (
        pd.to_numeric(kpler_fleet.get("IMO"), errors="coerce")
        .dropna().astype("int64").unique().tolist()
        if not kpler_fleet.empty else []
    )
    transits += detect_dark_loadings(
        prev_fleet, curr_fleet, kpler_fleet,
        kpler_data.current_trade_by_imo(trades, fleet_imos),
        gulf_zones, gulf_ports, snapshots=snapshots,
        skip_imos={t["imo"] for t in transits}, ais_dark_hours=ais_dark_hours,
    )
    # Carry forward anything this run could not refresh: whole entries for
    # vessels missing from both feeds, and per-field backfill (stale BBG
    # position, cooldown stamp, port call) where the current entry has gaps -
    # the old position stays the flip baseline for when a vessel reappears
    for imo, old in prev_fleet.items():
        if imo not in curr_fleet:
            curr_fleet[imo] = old
            continue
        entry = curr_fleet[imo]
        for key in ("lat", "lon", "seen_utc", "cargo_status",
                    "port_call_id", "port_call", "last_transit_utc",
                    "transit_alerted_seen", "kpler_laden"):
            # key-presence check (not truthiness): an explicitly cleared
            # stamp ("") or kpler_laden=False must not be resurrected
            if key not in entry and old.get(key) not in (None, ""):
                entry[key] = old[key]
    if not dry_run:
        save_fleet_positions(curr_fleet)

    # 6. Zone exits: final alert, then stop monitoring (auto vessels only;
    # static vessels always stay). Kept on file for the re-entry cooldown.
    exits: list[dict] = []
    for imo, snap in snapshots.items():
        if snap.get("in_zone"):
            continue
        prev_zone = (prev.get(imo) or {}).get("in_zone", "")
        if not prev_zone:
            # Already outside with no fresh exit flip (e.g. left before this
            # logic was deployed, or restored watchlist after a restart):
            # retire silently rather than keep alerting on an outside vessel
            if imo not in static_vessels:
                zone_watch.mark_exited(auto_watchlist, imo)
                log.info(
                    "Vessel outside zone (no exit flip), monitoring stopped: "
                    "%s (IMO %s)", snap.get("vessel_name") or imo, imo,
                )
            continue
        plat = _to_float((prev.get(imo) or {}).get("latitude"))
        plon = _to_float((prev.get(imo) or {}).get("longitude"))
        clat, clon = _to_float(snap.get("latitude")), _to_float(snap.get("longitude"))
        jump_nm = (
            _distance_nm(plat, plon, clat, clon)
            if None not in (plat, plon, clat, clon) else None
        )
        exits.append({
            "imo": imo,
            "name": snap.get("vessel_name") or f"IMO {imo}",
            "from_zone": prev_zone,
            "prev_pos": (plat, plon),
            "jump_nm": jump_nm,
            "static": imo in static_vessels,
        })
        if imo not in static_vessels:
            zone_watch.mark_exited(auto_watchlist, imo)
            log.info("Vessel left zone, monitoring stopped: %s (IMO %s)",
                     exits[-1]["name"], imo)
    zone_watch.prune_exited(auto_watchlist)
    if not dry_run:
        zone_watch.save_auto_watchlist(WATCHLIST_FILE, auto_watchlist)
        save_latest_snapshots(snapshots, references)
        append_history(snapshots)

    email_sent = False
    if changes or new_entries or exits or transits:
        subject_bits = []
        if transits:
            subject_bits.append(
                "TRANSIT: " + ", ".join(
                    f"{t['name']} ("
                    + ("DOUBLE DARK" if t.get("double_dark")
                       else t["direction"].split(" ")[0])
                    + (f", {t['laden'].lower()})" if t["laden"] else ")")
                    for t in transits
                )
            )
        if new_entries:
            subject_bits.append(f"{len(new_entries)} new vessel(s) in zone")
        if exits:
            subject_bits.append(
                "left zone: " + ", ".join(e["name"] for e in exits)
            )
        if changes:
            names = [snapshots[i].get("vessel_name") or f"IMO {i}"
                     for i in sorted(changes)]
            shown = ", ".join(names[:3]) + ("..." if len(names) > 3 else "")
            subject_bits.append(f"changes: {shown}")
        subject = "Hormuz LNG Monitor - " + "; ".join(subject_bits)
        # Unmonitored transiting vessels have no watchlist snapshot - give
        # the email/map a minimal stub (name + position + the pre-transit
        # position for the jump line). Email-only: not persisted to cache.
        email_snapshots = dict(snapshots)
        for t in transits:
            # Map jump line from the pre-transit position (diff-based
            # reference wins if the vessel also tripped a position alert)
            plat, plon = t["prev_pos"]
            moved_from.setdefault(t["imo"], (plon, plat))
            if t["imo"] in email_snapshots or not t.get("curr_pos"):
                continue  # curr_pos None: inferred call at an unlisted port
            clat, clon = t["curr_pos"]
            email_snapshots[t["imo"]] = {
                "vessel_name": t["name"],
                "latitude": f"{clat:.4f}",
                "longitude": f"{clon:.4f}",
                "laden": t["laden"],
            }
        body = build_email_body(
            changes, new_entries, email_snapshots, len(watchlist), zones,
            moved_from, thresholds, exits, transits, transit_lines, trail_hours,
        )
        if dry_run:
            log.info("[dry-run] would send email: %s", subject)
            for imo, fields in changes.items():
                log.info("[dry-run] %s: %s", imo, fields)
        else:
            send_email(receivers, subject, body, from_address=FROM_ADDRESS)
            email_sent = True
            log.info("Alert email sent to %s: %s", receivers, subject)
    else:
        log.info("No changes and no new vessels - no email")

    return {
        "monitored": len(watchlist),
        "in_zone": int(len(in_zone)),
        "new_vessels": len(new_entries),
        "exited_vessels": len(exits),
        "transits": len(transits),
        "changed_vessels": len(changes),
        "email_sent": email_sent,
        "first_run_baseline": not prev,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Hormuz LNG vessel monitor")
    parser.add_argument("--loop", action="store_true",
                        help="poll forever every [Monitor] poll_minutes")
    parser.add_argument("--interval", type=float, default=None,
                        help="loop interval in minutes (overrides cfg)")
    parser.add_argument("--dry-run", action="store_true",
                        help="do not email or update caches; log what would happen")
    args = parser.parse_args()

    log_path = REPORTS_PATH / "log"
    log_path.mkdir(exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_path / "hormuz_vessel_monitor.log"),
        ],
    )

    config = load_config()
    _, error_receivers = get_receivers(config)
    interval_min = args.interval or config.getfloat(
        "Monitor", "poll_minutes", fallback=5.0
    )

    if not args.loop:
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Done: %s", summary)
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            if not args.dry_run:
                send_email(error_receivers, "ERROR Hormuz LNG Monitor", str(tb))
            sys.exit(1)
        return

    logger.info("Looping every %.1f minutes (Ctrl+C to stop)", interval_min)
    in_error_streak = False
    while True:
        started = time.monotonic()
        try:
            summary = run_once(dry_run=args.dry_run)
            logger.info("Cycle done: %s", summary)
            in_error_streak = False
        except Exception:
            tb = traceback.format_exc()
            logger.error(tb)
            # only email the first error of a streak to avoid a mail storm
            if not in_error_streak and not args.dry_run:
                send_email(error_receivers, "ERROR Hormuz LNG Monitor", str(tb))
            in_error_streak = True
        elapsed = time.monotonic() - started
        time.sleep(max(30.0, interval_min * 60 - elapsed))


if __name__ == "__main__":
    main()
