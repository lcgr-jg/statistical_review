"""Zone polygons and the persisted vessel watchlist.

Zone logic follows eu_dashboard_power core/qatar_monitor/fleet_zones.py:
polygons come from a GeoJSON FeatureCollection ((lon, lat) rings) and a
vessel is "in zone" when its position is inside any polygon
(matplotlib point-in-polygon).

The watchlist is the union of:
  - static vessels from hormuz_vessel_monitor.cfg ([Monitor] vessels), and
  - vessels auto-added when first seen inside the zone, persisted to
    cache/watchlist.json so they stay monitored after leaving the zone.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from matplotlib.path import Path as MplPath

logger = logging.getLogger(__name__)

# Words kept fully uppercase when title-casing vessel names
_NAME_ACRONYMS = {"LNG", "FSRU", "II", "III", "IV", "VI"}


def title_case_vessel_name(name: str) -> str:
    """'AL GHASHAMIYA' -> 'Al Ghashamiya', 'MARIGOLD LNG' -> 'Marigold LNG'."""
    words = str(name).split()
    return " ".join(
        w if w.upper() in _NAME_ACRONYMS else w.capitalize() for w in words
    )


# ---------------------------------------------------------------------------
# Zones
# ---------------------------------------------------------------------------

def load_zones(geojson_path: Path) -> list[dict[str, Any]]:
    """Zone polygons from GeoJSON: id, name, ring ((lon, lat)) and mpl path."""
    raw = json.loads(Path(geojson_path).read_text(encoding="utf-8"))
    zones: list[dict[str, Any]] = []
    for feat in raw.get("features") or []:
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        if geom.get("type") != "Polygon":
            continue
        coords = (geom.get("coordinates") or [[]])[0]
        ring = [(float(lon), float(lat)) for lon, lat in coords]
        if len(ring) < 3:
            continue
        if ring[0] != ring[-1]:
            ring.append(ring[0])
        zone_id = str(props.get("id") or f"zone_{len(zones)}")
        zones.append({
            "id": zone_id,
            "name": str(props.get("name") or zone_id),
            "ring": ring,
            "path": MplPath(ring, closed=True),
        })
    if not zones:
        raise ValueError(f"No polygon features found in {geojson_path}")
    return zones


def load_transit_lines(geojson_path: Path) -> list[dict[str, Any]]:
    """LineString features from GeoJSON as {name, segments: [((lon, lat),
    (lon, lat)), ...]}. Returns [] if the file does not exist."""
    path = Path(geojson_path)
    if not path.exists():
        logger.warning("Transit line file not found: %s", path)
        return []
    raw = json.loads(path.read_text(encoding="utf-8"))
    lines: list[dict[str, Any]] = []
    for feat in raw.get("features") or []:
        geom = feat.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [(float(lon), float(lat))
                  for lon, lat in (geom.get("coordinates") or [])]
        if len(coords) < 2:
            continue
        props = feat.get("properties") or {}
        lines.append({
            "name": str(props.get("name") or f"transit_line_{len(lines)}"),
            "coords": coords,
        })
    return lines


def point_in_zones(
    longitude: float | None,
    latitude: float | None,
    zones: list[dict[str, Any]],
) -> str | None:
    """Name of the first zone containing the point, else None."""
    if longitude is None or latitude is None:
        return None
    try:
        lon, lat = float(longitude), float(latitude)
    except (TypeError, ValueError):
        return None
    if lon != lon or lat != lat:  # NaN
        return None
    for zone in zones:
        if zone["path"].contains_point((lon, lat)):
            return zone["name"]
    return None


def vessels_in_zone(
    bbg_ships: pd.DataFrame, zones: list[dict[str, Any]]
) -> pd.DataFrame:
    """Rows of the Bloomberg LNG fleet snapshot currently inside any zone."""
    if bbg_ships.empty:
        return bbg_ships
    mask = [
        point_in_zones(row.get("longitude"), row.get("latitude"), zones) is not None
        for _, row in bbg_ships.iterrows()
    ]
    return bbg_ships[mask]


# ---------------------------------------------------------------------------
# Watchlist
# ---------------------------------------------------------------------------

def parse_static_vessels(cfg_value: str) -> dict[int, str]:
    """Parse the cfg "Name:IMO, Name:IMO" list into {imo: name}."""
    vessels: dict[int, str] = {}
    for item in cfg_value.split(","):
        item = item.strip()
        if not item:
            continue
        name, _, imo = item.rpartition(":")
        vessels[int(imo.strip())] = name.strip()
    return vessels


def load_auto_watchlist(watchlist_file: Path) -> dict[int, dict[str, Any]]:
    """Auto-added vessels: {imo: {name, added_utc, added_reason}}."""
    if not Path(watchlist_file).exists():
        return {}
    raw = json.loads(Path(watchlist_file).read_text(encoding="utf-8"))
    return {int(imo): entry for imo, entry in raw.items()}


def save_auto_watchlist(
    watchlist_file: Path, watchlist: dict[int, dict[str, Any]]
) -> None:
    Path(watchlist_file).parent.mkdir(parents=True, exist_ok=True)
    Path(watchlist_file).write_text(
        json.dumps({str(imo): entry for imo, entry in watchlist.items()}, indent=2),
        encoding="utf-8",
    )


def update_watchlist_from_zone(
    in_zone: pd.DataFrame,
    static_vessels: dict[int, str],
    auto_watchlist: dict[int, dict[str, Any]],
    reentry_cooldown_min: float = 60.0,
) -> list[dict[str, Any]]:
    """
    Add zone vessels not yet monitored to ``auto_watchlist`` (mutated in
    place). Returns the newly added entries (with imo/name/position) so the
    caller can flag them in the alert email.

    Entries carrying ``exited_utc`` are vessels that previously left the zone
    (monitoring stopped). If one re-enters, monitoring resumes; within
    ``reentry_cooldown_min`` of the exit that happens silently (no "new
    vessel" email), so a vessel drifting across the boundary does not spam
    alternating exit/entry alerts.
    """
    new_entries: list[dict[str, Any]] = []
    now = datetime.now(timezone.utc)
    for _, row in in_zone.iterrows():
        imo = row.get("imo")
        if imo is None or imo != imo:  # missing / NaN
            continue
        imo = int(imo)
        if imo in static_vessels:
            continue
        entry = auto_watchlist.get(imo)
        if entry is not None and not entry.get("exited_utc"):
            continue  # already actively monitored
        name = title_case_vessel_name(row.get("vessel_name") or f"IMO {imo}")
        if entry is not None:  # re-entry of a previously exited vessel
            exited = pd.to_datetime(entry["exited_utc"], utc=True)
            silent = (
                pd.notna(exited)
                and (now - exited).total_seconds() / 60.0 < reentry_cooldown_min
            )
            entry.pop("exited_utc", None)
            entry["name"] = name
            entry["added_utc"] = now.isoformat(timespec="seconds")
            entry["added_reason"] = "re-entered monitored zone"
            if silent:
                logger.info(
                    "Vessel re-entered zone within cooldown, resumed silently: "
                    "%s (IMO %s)", name, imo,
                )
                continue
            new_entries.append({"imo": imo, "name": name, "row": row})
            logger.info("Vessel re-entered zone, monitoring resumed: %s (IMO %s)",
                        name, imo)
            continue
        auto_watchlist[imo] = {
            "name": name,
            "added_utc": now.isoformat(timespec="seconds"),
            "added_reason": "entered monitored zone",
        }
        new_entries.append({"imo": imo, "name": name, "row": row})
        logger.info("New vessel in zone, added to watchlist: %s (IMO %s)", name, imo)
    return new_entries


def mark_exited(auto_watchlist: dict[int, dict[str, Any]], imo: int) -> None:
    """Stop monitoring an auto-added vessel (kept on file for the re-entry
    cooldown; pruned later by prune_exited)."""
    entry = auto_watchlist.get(imo)
    if entry is not None and not entry.get("exited_utc"):
        entry["exited_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")


def prune_exited(
    auto_watchlist: dict[int, dict[str, Any]], retention_days: float = 14.0
) -> None:
    """Drop exited entries older than ``retention_days`` (mutates in place)."""
    now = datetime.now(timezone.utc)
    for imo in list(auto_watchlist):
        exited = auto_watchlist[imo].get("exited_utc")
        if not exited:
            continue
        exited_ts = pd.to_datetime(exited, utc=True)
        if pd.isna(exited_ts) or (now - exited_ts).days >= retention_days:
            del auto_watchlist[imo]
