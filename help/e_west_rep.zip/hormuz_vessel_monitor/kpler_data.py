"""Kpler LNG API pulls for the Hormuz vessel monitor.

Same API/query logic as the china_summary and ras_laffan_loadings reports:
login with email/password for a bearer token, then GET the ``vessels``
(fleet status: destination, ETA, last speed, last signal - no lat/lon) and
``trades`` (cargo-level trackings, used for each vessel's current voyage)
endpoints, both of which return semicolon-separated CSV.
"""
from __future__ import annotations

import io
import logging

import pandas as pd
import requests

logger = logging.getLogger(__name__)

KPLER_LNG_BASE_URL = "https://api-lng.kpler.com/v1/"

# Trade statuses that represent a live voyage (most recent one of these is
# taken as the vessel's current trade)
ACTIVE_TRADE_STATUSES = ("Loading", "In Transit")


def kpler_login(email: str, password: str) -> str:
    """Log in to the Kpler LNG API and return an access token."""
    response = requests.post(
        KPLER_LNG_BASE_URL + "login",
        json={"email": email, "password": password},
        timeout=60,
    )
    response.raise_for_status()
    return response.json()["token"]


def _kpler_get(token: str, endpoint: str, **params) -> pd.DataFrame:
    """One Kpler LNG GET (semicolon-separated CSV) as a DataFrame."""
    response = requests.get(
        KPLER_LNG_BASE_URL + endpoint,
        params=params,
        headers={"Authorization": token},
        timeout=120,
    )
    response.raise_for_status()
    return pd.read_csv(io.StringIO(response.text), delimiter=";", low_memory=False)


def fetch_kpler_fleet(token: str) -> pd.DataFrame:
    """The whole Kpler LNG fleet status table (one row per vessel) - used
    both for watchlist enrichment and fleet-wide port-call transit checks."""
    return _kpler_get(token, "vessels", columns="all")


def fetch_kpler_vessels(
    token: str, imos: list[int], fleet: pd.DataFrame | None = None
) -> pd.DataFrame:
    """Kpler fleet status rows for the given IMOs, indexed by IMO. Pass a
    prefetched ``fleet`` frame to avoid a second API call."""
    df = fleet.copy() if fleet is not None else _kpler_get(
        token, "vessels", columns="all"
    )
    df["IMO"] = pd.to_numeric(df.get("IMO"), errors="coerce")
    df = df[df["IMO"].isin(imos)].copy()
    df["IMO"] = df["IMO"].astype("int64")
    # A vessel should only appear once; keep the last row if not
    return df.drop_duplicates(subset="IMO", keep="last").set_index("IMO")


def fetch_kpler_trades(token: str, start_date: str) -> pd.DataFrame:
    """All Kpler LNG trades loading from ``start_date`` (raw rows)."""
    return _kpler_get(
        token, "trades", startDate=start_date, size=20000, columns="all"
    )


def current_trade_by_imo(trades: pd.DataFrame, imos: list[int]) -> dict[int, pd.Series]:
    """
    The current (or failing that, most recent) trade row per IMO.

    Prefers active voyages (Loading / In Transit) over anything else, then
    the latest loading date. Multi-discharge cargoes share a voyage; any row
    carries the voyage-level fields used downstream, so the first is fine.
    """
    if trades.empty or "IMO (vessel)" not in trades.columns:
        return {}
    df = trades.copy()
    df["_imo"] = pd.to_numeric(df["IMO (vessel)"], errors="coerce")
    df = df[df["_imo"].isin(imos)]
    if df.empty:
        return {}
    df["_date_origin"] = pd.to_datetime(df.get("Date (origin)"), errors="coerce")
    df["_active"] = df.get("Trade status").isin(ACTIVE_TRADE_STATUSES)
    df = df.sort_values(["_active", "_date_origin"])  # best row last
    out: dict[int, pd.Series] = {}
    for imo, group in df.groupby("_imo"):
        out[int(imo)] = group.iloc[-1]
    return out
