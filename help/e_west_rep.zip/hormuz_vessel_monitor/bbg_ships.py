"""Bloomberg BSRCH snapshot of in-service LNG tankers (lat/lon, speed etc).

Slim port of eu_dashboard_power/core/lng_data_bbg_ships/api.py: one
ExcelGetGridRequest on the ``comdty:ship`` domain returns the whole
in-service LNG fleet in a single call (there are no per-vessel tickers).

Session: desktop Terminal on Windows (Terminal must be running and logged
in), B-PIPE from the server (same host/app as the power dashboard).
"""
from __future__ import annotations

import logging
import platform

import blpapi
import pandas as pd

from jain_commods.core.interfaces.bloomberg import bsrch_handler

logger = logging.getLogger(__name__)

# Same BSRCH output fields as eu_dashboard_power core/lng_data_bbg_ships
SHIP_OUTPUT_FIELDS = (
    "IMO|VESSEL_NAME|LAST_SEEN|ETA|LATITUDE|LONGITUDE|DEPART_TIME|"
    "NAVIGATION_STATUS|NORMALIZED_DESTINATION|NORMALIZED_COUNTRY_REGION|"
    "REPORTED_SPEED|DESTINATION|DELIVERY_DATE|BENEFICIAL_OWNER|VESSEL_TYPE|"
    "GAS_CAPACITY|VESSEL_TYPE_4|DWT|LIQUID_CAPACITY|CARGO_STATUS|CARGO_PRODUCT|"
    "VESSEL_CLASS|BUILD_DATE|LOA|MMSI|CURRENT_DRAFT|FLAG|MAX_DRAFT|DRAFT_PCT|"
    "DEPART_PORT|HEADING|SERVICE_SPEED|OPERATIONAL_STATUS|MOVEMENT_SOURCE|"
    "GRAIN_CAPACITY|"
)
VESSEL_TYPE = "LNG TANKER"
OPERATIONAL_STATUS = "In Service/Commission"
BPIPE_HOST = "Tech1ProdBPipe47537.jainglobal.net"
BPIPE_APP = "JAIN:commoditiespmdashboard"


def _default_on_server() -> bool:
    return platform.system().lower() != "windows"


def _start_session(on_server: bool) -> blpapi.Session:
    if on_server:
        options = blpapi.SessionOptions()
        options.sessionName = "BBG Hormuz Vessel Monitor"
        options.setServerAddress(BPIPE_HOST, 8194, 0)
        auth = blpapi.AuthOptions.createWithApp(BPIPE_APP)
        options.setSessionIdentityOptions(auth, blpapi.CorrelationId("authCorrelation"))
        session = blpapi.Session(options)
    else:
        session = blpapi.Session()

    if not session.start():
        raise RuntimeError("Failed to start Bloomberg session")
    if not session.openService("//blp/exrsvc"):
        raise RuntimeError("Failed to open //blp/exrsvc (BSRCH / ExcelGetGridRequest)")
    return session


def _ship_snapshot_request(service: blpapi.Service) -> blpapi.Request:
    request = service.createRequest("ExcelGetGridRequest")
    request.set("Domain", "comdty:ship")
    overrides = request.getElement("Overrides")
    for name, value in (
        ("VESSEL_TYPE", VESSEL_TYPE),
        ("OPERATIONAL_STATUS", OPERATIONAL_STATUS),
        ("OUTPUT", SHIP_OUTPUT_FIELDS),
    ):
        ov = overrides.appendElement()
        ov.setElement("name", name)
        ov.setElement("value", value)
    return request


def _collect_bsrch_response(session: blpapi.Session) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    while True:
        event = session.nextEvent(10_000)
        if event.eventType() not in (
            bsrch_handler.BLP_RESPONSE,
            bsrch_handler.BLP_PARTIAL_RESPONSE,
        ):
            continue
        for msg in event:
            df = bsrch_handler.getBSRCHData(msg)
            if len(df) > 0:
                frames.append(df)
        if event.eventType() == bsrch_handler.BLP_RESPONSE:
            break
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [
        (
            c.lower()
            .replace(" ", "_")
            .replace("(", "")
            .replace(")", "")
            .replace("%", "percent")
            .replace("/", "__")
        )
        for c in out.columns
    ]
    for col in ("latitude", "longitude", "heading", "reported_speed_knots", "imo"):
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    if "last_seen" in out.columns:
        out["last_seen"] = pd.to_datetime(out["last_seen"], errors="coerce", utc=True)
    return out


def fetch_lng_ship_snapshot(*, on_server: bool | None = None) -> pd.DataFrame:
    """Return one row per in-service LNG tanker from Bloomberg BSRCH."""
    if on_server is None:
        on_server = _default_on_server()
    logger.info(
        "Bloomberg LNG ship snapshot via %s",
        "B-PIPE" if on_server else "desktop Terminal",
    )
    session = _start_session(on_server)
    try:
        service = session.getService("//blp/exrsvc")
        session.sendRequest(_ship_snapshot_request(service))
        df = _collect_bsrch_response(session)
    finally:
        session.stop()
    return _normalise_columns(df)
