"""Port-call transit inference. No network.

Run from eu_reports: python -m pytest hormuz_vessel_monitor/tests -q
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from hormuz_vessel_monitor import zone_watch
from hormuz_vessel_monitor.monitor import (
    _match_gulf_port,
    _parse_gulf_ports,
    detect_dark_loadings,
    detect_port_call_transits,
)

ZONES = zone_watch.load_zones(
    Path(__file__).resolve().parents[1] / "zones" / "persian_gulf_side.geojson"
)
# Config spelling is hyphenated on purpose: Kpler sent "Al Zour" for Qtaifan.
PORTS = _parse_gulf_ports(
    "Al-Zour:28.72:48.40, Ras Laffan:25.91:51.60, Mina Al-Ahmadi:29.06:48.17, "
    "Dubai Light.:25.30:55.15"
)
QTAIFAN = 9981049


def _kpler(imo: int, pc_id: int, port: str, volume: float = 0.0, name: str = "Qtaifan"):
    return pd.DataFrame([{
        "IMO": imo,
        "Name": name,
        "Last port-call id": pc_id,
        "Last port-call": port,
        "Volume": volume,
    }])


def _fleet(imo: int, lat: float, lon: float, *, seen: str, port_call_id: int | None = None):
    entry = {"name": "Qtaifan", "lat": lat, "lon": lon, "seen_utc": seen}
    if port_call_id is not None:
        entry["port_call_id"] = port_call_id
    return {imo: entry}


def test_port_keys_ignore_hyphen_space_and_period():
    assert _match_gulf_port("Al Zour", PORTS) == (28.72, 48.40)
    assert _match_gulf_port("Al-Zour", PORTS) == (28.72, 48.40)
    assert _match_gulf_port("Al Zour LNG", PORTS) == (28.72, 48.40)
    assert _match_gulf_port("Mina Al Ahmadi", PORTS) == (29.06, 48.17)
    assert _match_gulf_port("Dubai Light", PORTS) == (25.30, 55.15)
    assert _match_gulf_port("Singapore", PORTS) is None


def test_qtaifan_loading_at_al_zour_is_not_a_transit():
    """Already inside the Gulf, dark/berthed at Al Zour. Kpler spells the
    port with a space; that must not be read as an eastbound exit."""
    assert zone_watch.point_in_zones(48.41, 28.71, ZONES) is not None
    seen = "2026-10-13T05:30:00+00:00"
    prev = _fleet(QTAIFAN, 28.80, 48.50, seen=seen, port_call_id=100)
    curr = _fleet(QTAIFAN, 28.71, 48.41, seen=seen)
    transits = detect_port_call_transits(
        prev, curr, _kpler(QTAIFAN, 200, "Al Zour"), ZONES, PORTS,
    )
    assert transits == []
    assert curr[QTAIFAN]["port_call"] == "Al Zour"
    assert "last_transit_utc" not in curr[QTAIFAN]


def test_outside_ais_calling_al_zour_is_still_westbound():
    seen = "2026-10-13T05:30:00+00:00"
    prev = _fleet(QTAIFAN, 24.0, 59.0, seen=seen, port_call_id=100)
    curr = _fleet(QTAIFAN, 24.0, 59.0, seen=seen)
    assert zone_watch.point_in_zones(59.0, 24.0, ZONES) is None
    transits = detect_port_call_transits(
        prev, curr, _kpler(QTAIFAN, 200, "Al Zour"), ZONES, PORTS,
    )
    assert len(transits) == 1
    assert transits[0]["direction"].startswith("westbound")
    assert transits[0]["inferred_port_call"] == "Al Zour"
    assert curr[QTAIFAN]["pos_source"] == "kpler_port_call"
    assert curr[QTAIFAN]["lat"] == 28.72


def test_in_gulf_ais_calling_unlisted_port_is_still_eastbound():
    seen = "2026-10-13T05:30:00+00:00"
    prev = _fleet(QTAIFAN, 25.91, 51.60, seen=seen, port_call_id=100)
    curr = _fleet(QTAIFAN, 25.91, 51.60, seen=seen)
    transits = detect_port_call_transits(
        prev, curr, _kpler(QTAIFAN, 200, "Singapore"), ZONES, PORTS,
    )
    assert len(transits) == 1
    assert transits[0]["direction"].startswith("eastbound")


def test_false_al_zour_stamp_does_not_swallow_a_later_exit():
    """The alert already sent for Qtaifan stamped that AIS fix as a crossing.
    Recognising Al Zour as in-Gulf must clear the stamp, or the real
    departure is suppressed by detect_transits."""
    seen = "2026-10-13T05:30:00+00:00"
    prev = _fleet(QTAIFAN, 28.71, 48.41, seen=seen, port_call_id=200)
    prev[QTAIFAN]["transit_alerted_seen"] = seen
    curr = _fleet(QTAIFAN, 28.71, 48.41, seen=seen)
    transits = detect_port_call_transits(
        prev, curr, _kpler(QTAIFAN, 200, "Al Zour"), ZONES, PORTS,
    )
    assert transits == []
    assert curr[QTAIFAN]["transit_alerted_seen"] == ""


def test_real_outside_port_stamp_is_kept():
    seen = "2026-10-13T05:30:00+00:00"
    prev = _fleet(QTAIFAN, 25.91, 51.60, seen=seen, port_call_id=200)
    prev[QTAIFAN]["transit_alerted_seen"] = seen
    curr = _fleet(QTAIFAN, 25.91, 51.60, seen=seen)
    transits = detect_port_call_transits(
        prev, curr, _kpler(QTAIFAN, 200, "Singapore"), ZONES, PORTS,
    )
    assert transits == []
    assert "transit_alerted_seen" not in curr[QTAIFAN]


def test_neutral_strait_call_does_not_infer():
    seen = "2026-10-13T05:30:00+00:00"
    prev = _fleet(QTAIFAN, 25.91, 51.60, seen=seen, port_call_id=100)
    curr = _fleet(QTAIFAN, 25.91, 51.60, seen=seen)
    transits = detect_port_call_transits(
        prev, curr, _kpler(QTAIFAN, 200, "Strait of Hormuz"), ZONES, PORTS,
        neutral_ports={"Strait of Hormuz"},
    )
    assert transits == []


def test_dark_loading_at_al_zour_while_already_inside_is_not_a_transit():
    now = datetime.now(timezone.utc)
    stale = (now - timedelta(hours=20)).isoformat()
    prev = _fleet(QTAIFAN, 28.71, 48.41, seen=stale, port_call_id=100)
    prev[QTAIFAN]["kpler_laden"] = False
    curr = _fleet(QTAIFAN, 28.71, 48.41, seen=stale)
    out = detect_dark_loadings(
        prev, curr, _kpler(QTAIFAN, 200, "Al Zour", volume=100000),
        None, ZONES, PORTS,
    )
    assert out == []


def test_dark_loading_at_al_zour_from_outside_is_still_inferred():
    now = datetime.now(timezone.utc)
    stale = (now - timedelta(hours=20)).isoformat()
    prev = _fleet(QTAIFAN, 24.0, 59.0, seen=stale, port_call_id=100)
    prev[QTAIFAN]["kpler_laden"] = False
    curr = _fleet(QTAIFAN, 24.0, 59.0, seen=stale)
    out = detect_dark_loadings(
        prev, curr, _kpler(QTAIFAN, 200, "Al Zour", volume=100000),
        None, ZONES, PORTS,
    )
    assert len(out) == 1
    assert out[0]["loaded_at"] == "Al Zour"
    assert out[0]["direction"].startswith("westbound")
