import logging
import traceback
import configparser
import platform

from datetime import datetime
from pathlib import Path


from jain_commods.core.util.emailhelper import send_email

from util import create_report


REPORTS_PATH = Path(__file__).parent.resolve()
# REPORTS_PATH = Path('C:/Projects/eu_reports/lng_st_summary')

# Get config 
config = configparser.ConfigParser()
config.read(REPORTS_PATH / 'lng_st_summary.cfg')
receivers = config.get('ReportSettings','receivers')
error_receivers = config.get('ReportSettings','error_receivers')

# CE credentials 
ce_user = config.get('CEAPI','user')
ce_pass = config.get('CEAPI','pass')

# Set up logging
log_path = REPORTS_PATH / 'log'
stoday = datetime.now().strftime('%Y%m%d')
logging.basicConfig(filename = log_path / f"{stoday}_lng_st_summary.log",
                    filemode='a',
                    level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    )

system = platform.system().lower()

# over ride for local debugging
if system == 'windows':
    receivers = 'john.morley@jainglobal.com'
    error_receivers= 'john.morley@jainglobal.com'
  

email_subject = 'LNG ST Summary'


try:
    logging.info('Generating LNG ST Summary Report...')

    # Create new report
    report = create_report(ce_user, ce_pass)
        
    # Send report
    logging.info('Sending report')
    send_email(receivers, email_subject, report)
    logging.info('Report sent')
        
    logging.info('Process complete')

    
except Exception:
    logging.error('Exception caught running process!')
    tb = traceback.format_exc()
    logging.error(tb)
    # Send error email
    send_email(error_receivers, f'ERROR {email_subject}', str(tb))
        
        