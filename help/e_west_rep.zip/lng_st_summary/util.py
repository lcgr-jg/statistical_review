import pandas as pd
from datetime import datetime, timedelta

from jain_commods.core.interfaces.commodityessentials import CElink
from jain_commods.core.interfaces.sqldb import KplerQuery

from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table

from jain_commods.core.util.htmlutils import df2html


variables = ['Arrivals', 'Outage', 'Sendout', 'Sendout Capa', 'Stock', 'Stock Capa']


def get_data(ce_user, ce_pass, days_back, days_fwd, mcm_filter):
    """ Function to query Kpler and CE """
    
    # Kpler: query latest snapshots from the db
    kq = KplerQuery(logintype='prod')
    now = datetime.now()
    trades_curr, trades_dt_curr = kq.get_forecast(now, 'trades')
    vessels_curr, vessels_dt_curr = kq.get_forecast(now, 'vessels')

    # Set date range    
    now = pd.to_datetime(datetime.now()).normalize()
    start_date = now - timedelta(days=days_back)
    end_date = now + timedelta(days=days_fwd)

    # Get historic regas, stock & stock capa from CE
    ce = CElink(ce_user,ce_pass)
    # Get CE metadata (so we can confidently rename them below and not rely on column ordering)    
    ce_metadata_spa = ce.eugasmeta(id='seriesperasset')
    # Define terminals
    lng_terminal_asset_ids = [663
                                ,3198
                                ,3312
                                ,3197 # Wilhelmshaven (combined)
                                # ,3419 # Wilhelmshaven 1
                                # ,3420 # Wilhelmshaven 2
                                ,184
                                # ,182 # Fos (combined)
                                ,200 # Fos C
                                ,201 # Fos T
                                # ,3261 # Le Havre (removed as now decomissioned)
                                ,181
                                ,164
                                ,167
                                ,165
                                ,1793
                                ,1795
                                ,3247
                                ,3412
                                ,1794
                                ,3136
                                ,214
                                ]
    
    
    # Get the data from CE
    df_lng = ce.eugasopdata(assets=lng_terminal_asset_ids, 
                            unit='mcm', 
                            variable='stock,stockcapacity,withdrawal', 
                            dateFrom=start_date.strftime('%Y-%m-%d'),
                            dateTo=end_date.strftime('%Y-%m-%d'),
                            ).set_index('Date').drop(columns=['DateExcel'])
    df_lng.index = pd.to_datetime(df_lng.index, format="%d-%b-%Y")
    # Set column names
    df_lng.columns = [f"{row['direction']}|{row['assetName']}|{row['variable'].replace('stockCapacity','Stock Capa').replace('withdrawal','Sendout').replace('stock','Stock')}" for c in df_lng.columns for row in [ce_metadata_spa[ce_metadata_spa['seriesId']==int(c)].iloc[0]]]
    
    # Set multindex column names
    df_lng.columns = pd.MultiIndex.from_tuples([(c.split('|')[0],c.split('|')[1],c.split('|')[2]) for c in df_lng.columns], names=['Country','Terminal', 'Variable'])

    # Get maintenance data from CE
    df_maint_raw = ce.eugasout(assets=lng_terminal_asset_ids, unit='mcm', variable='withdrawal',dateFrom=start_date.strftime('%Y-%m-%d'), dateTo=end_date.strftime('%Y-%m-%d'))
    df_maint_raw['Date'] = pd.to_datetime(df_maint_raw['Date'], format='%d-%b-%Y')
    df_maint_raw['Updated'] = pd.to_datetime(df_maint_raw['Updated'], format='%d-%b-%Y')
    # Some terminals have nan instead of zeros in the important "Out.Total" column
    df_maint_raw['Out.Total'] = df_maint_raw['Out.Total'].fillna(0)
    
    # Create uniqe name
    df_maint_raw['terminal'] = df_maint_raw['Market'] + '|' + df_maint_raw['assetName']

    # Get unique terminal list
    unique_combos = df_maint_raw['terminal'].unique()

    # Create the pivoted dataframe
    df_maint = pd.DataFrame()
    
    # Set Date as index
    df_maint['Date'] = pd.to_datetime(df_maint_raw['Date'].unique())
    df_maint = df_maint.set_index('Date')
    
    # For each unique Market-assetName combination, create Out.Total and Tech.Cap columns
    for combo in unique_combos:
        combo_data = df_maint_raw[df_maint_raw['terminal'] == combo].copy()
        combo_data['Date'] = pd.to_datetime(combo_data['Date'])
        combo_data = combo_data.set_index('Date')
        
        # Add Out.Total column
        df_maint[f'{combo}|Outage'] = combo_data['Out.Total']
        
        # Add Tech.Cap column
        df_maint[f'{combo}|Sendout Capa'] = combo_data['Tech.Cap']
    
    # Sort by date
    df_maint = df_maint.sort_index()
    # Create multindex columns
    df_maint.columns = pd.MultiIndex.from_tuples([(c.split('|')[0],c.split('|')[1],c.split('|')[2]) for c in df_maint.columns], names=['Country','Terminal', 'Variable'])
    # Forward fill maint
    df_maint = df_maint.ffill()

    # Combine flows/stock and maint
    df = pd.concat([df_lng,df_maint], axis=1)

    # Forward fill every stock capaacity column
    stock_capacity_cols = df.columns[df.columns.get_level_values('Variable') == 'stockCapacity'].tolist()
    df[stock_capacity_cols] = df[stock_capacity_cols].ffill()

    # Define Kpler : CE mappings
    terminal_mappings = {
        'Zeebrugge Lng': 'Zeebrugge Lng',
        'Zeebrugge': 'Zeebrugge Lng',
        'Brunsbüttel FSRU': 'Brunsbuettel',
        'Mukran': 'Mukran, Deutsche ReGas',
        'Wilhelmshaven': 'Wilhelmshaven',
        'Wilhelmshaven GasPort': 'Wilhelmshaven',
        'Wilhelmshaven 2': 'Wilhelmshaven',
        'Dunkerque LNG': 'Dunkerque LNG',
        'Dunkerque': 'Dunkerque LNG',
        'Fos Cavaou': 'Fos Cavaou',
        'Fos Tonkin': 'Fos Tonkin',
        'Le Havre FSRU': 'Le Havre',
        'Montoir': 'Montoir',
        'Dragon': 'Dragon',
        'Grain': 'Isle Of Grain',
        'South Hook': 'South Hook',
        'Rovigo': 'Adriatic',
        'La Spezia': 'Panigaglia',
        'Piombino LNG': 'Piombino',
        'Ravenna FSRU': 'Ravenna FSRU',
        'Ravenna LNG': 'Ravenna FSRU',
        'Ravenna': 'Ravenna FSRU',
        'Toscana': 'Toscana',
        'EemsEnergyTerminal':'Eemshaven',
        'Gate': 'Gate LNG',
        'Milford Haven': 'South Hook', # we assume MH = SH 
         }

    # Define country per terminal
    terminal_country = {
        'Adriatic':'IT',
         'Brunsbuettel':'DE',
         'Dragon':'GB',
         'Dunkerque LNG':'FR',
         'Eemshaven':'NL',
         'Fos Cavaou':'FR',
         'Fos Tonkin':'FR',
         'Gate LNG':'NL',
         'Isle Of Grain':'GB',
         'Le Havre':'FR',
         'Montoir':'FR',
         'Mukran, Deutsche ReGas':'DE',
         'Panigaglia':'IT',
         'Piombino':'IT',
         'Ravenna FSRU':'IT',
         'South Hook':'GB',
         'Toscana':'IT',
         'Wilhelmshaven':'DE',
         # 'Wilhelmshaven 2':'DE',
         'Zeebrugge Lng':'BE',
         }

    # Map Kpler destinations to CE equivalent
    trades_curr['ce_mapping'] = trades_curr['installation_destination'].map(terminal_mappings)
    # 2nd pass to cover anything we've missed by using zone destination
    trades_curr['ce_mapping_alt'] = trades_curr['zone_destination'].map(terminal_mappings)
    # Combine 
    trades_curr['ce_mapping'] = trades_curr['ce_mapping'].fillna(trades_curr['ce_mapping_alt'])    
    
    # Convert to mcm & filter out small volumes
    trades_curr['delivered_mcm'] = trades_curr['volume_destination_m3']  * get_conversion_factor('cu m', 'mcm', unit_conversion_table)
    trades_curr = trades_curr[trades_curr['delivered_mcm']>=mcm_filter]
    
    # Tidy up
    trades_curr['date_destination'] = pd.to_datetime(trades_curr['date_destination']).dt.normalize()


    # Insert Kpler arrivals into the main df
    terminal_cols = set([t[1] for t in df.columns])
    for terminal in terminal_cols:
        country = terminal_country[terminal]
        
        # Get arrivals for this terminal
        terminal_lineup = trades_curr[trades_curr['ce_mapping']==terminal]
        # Tidy up
        df_temp = terminal_lineup.set_index('date_destination')[['delivered_mcm']]
        # Groupby to cater for more than 1 cargo arriving on the same day
        df_temp = df_temp.groupby('date_destination')['delivered_mcm'].sum().to_frame()
        # Set multindex columns
        df_temp.columns = pd.MultiIndex.from_tuples([(country,terminal,'Arrivals')], names=['Country','Terminal', 'Variable'])
        # Join to output
        df = df.join(df_temp, how='left')
    
    df_sorted = df.sort_index(axis=1, level=['Country', 'Terminal', 'Variable'])
        
    # Create an extra "country" to store aggregated totals
    for variable in variables:
        # Get all match columns for this variable
        cols = df_sorted.columns[df_sorted.columns.get_level_values('Variable')==variable]
        # Select relevant columns
        df_sorted[('NWE+IT','NWE+IT',variable)] = df_sorted[cols].sum(axis=1)
    
    # Produce seperate table for each country
    country_cols = sorted(set([t[0] for t in df_sorted.columns]))
    country_tables = {}
    for c in country_cols:
        
        terminals_percountry_cols = df_sorted.columns[df_sorted.columns.get_level_values('Country') == c]
        # Select the relevant columns
        country_tables[c] = df_sorted[terminals_percountry_cols]
        
        
    return country_tables, trades_dt_curr


def create_report(ce_user, ce_pass):
    
    # Generate summary dataframes per country
    days_back = 7
    days_fwd = 14
    mcm_filter = 10
    country_tables, kpler_snapshot_dt = get_data(ce_user, ce_pass, days_back, days_fwd, mcm_filter)
    
    
    report_font_family = 'Calibri'
    report_font_size = '14'
    country_html = ''
    # Define custom display order
    countries_display_order = ['NWE+IT'] + sorted([c for c in country_tables.keys() if c != 'NWE+IT'])
    
    # Create HTML table for each country
    for c1 in countries_display_order:
        
        # Prepare table for display
        df = country_tables[c1].copy()
        
        multi_terminal = len(df.columns.get_level_values('Terminal').unique()) > 1
        
        # If more than 1 terminal for this country, add a Total column
        if multi_terminal:
        
            # For each variable, sum across all terminals within DE country
            for variable in variables:
                # Select all columns
                cols_to_sum = [(country, terminal, var) 
                               for country, terminal, var in df.columns 
                               if country == c1 and var == variable]
                
                # Sum these columns and create a new column with Terminal='Total'
                df[(c1, 'Total', variable)] = df[cols_to_sum].sum(axis=1)

        # Flatten columns before rename        
        df.columns = ['_'.join(col).strip() for col in df.columns.values]
        
        # Get capa details so we can prepare column names for display
        stock_capacity_cols = [c for c in df.columns if c.endswith('Stock Capa')]
        stock_capas = {k: df[k].dropna().iloc[0] for k in stock_capacity_cols}
        
        sendout_capacity_cols = [c for c in df.columns if c.endswith('Sendout Capa')]
        sendout_capas = {k: df[k].dropna().iloc[0] for k in sendout_capacity_cols}
        
        # Rename columns
        df = df.rename(columns={c.replace(' Capa', ''): c.replace(' Capa', f' ({stock_capas[c]:.0f})') for c in stock_capacity_cols})
        df = df.rename(columns={c.replace(' Capa', ''): c.replace(' Capa', f' ({sendout_capas[c]:.0f})') for c in sendout_capacity_cols})
        
        # Drop unreqd columns & fill nans
        df = df.drop([col for col in df.columns if col.endswith(' Capa')], axis=1)
        df = df.fillna('')
        
        # Replace 0 in all outage columns
        for c in [col for col in df.columns if col.endswith('_Outage')]:
            df[c] = df[c].replace(0, '')
            
        if multi_terminal:            
            # Replace 0 in Total Arrivals columns
            df[f"{c1}_Total_Arrivals"] = df[f"{c1}_Total_Arrivals"].replace(0, '')
        
        # Re-instate multindex columns 
        df.columns = pd.MultiIndex.from_tuples([(c.split('_')[0],c.split('_')[1],c.split('_')[2]) for c in df.columns], names=['Country','Terminal', 'Variable'])

        # Create html and add to the report output
        html_table = df2html(df, precision=0, font_size=report_font_size, font_family=report_font_family, highlight_weekends=True, index_dt_format='%d-%b-%Y', highlight_today=True)
        country_html = country_html + f"""<br><hr><br>{html_table}"""


    # Construct email body
    email_body = f"""<html lang="en">
                    <body>
                    <p>LNG Short Term Summary for all terminals in NWE+IT, grouped per country. 
                    <br>Arrivals based on Kpler snapshot taken at {kpler_snapshot_dt.strftime('%d %b %H:%M')} UTC. Arrivals smaller than {mcm_filter}mcm are filtered out.
                    <br>Current view: {days_back} days history, {days_fwd} days forecast.
                    <br>Max sendout and stock values in column headers (in brackets).
                    <br>All values mcm/d.
                    <br>Elengy forward noms displayed for Fos Cavaou, Fos Tonkin & Montoir in FR.
                    <br>Total LNG storage capa excludes the upcoming Stade (onshore) & decommissioned Mukran (Energos Power FSRU) terminals in DE.
                    <br>For clarity, currently 4x active terminals in DE: Brunsbuttel (Hoegh Gannet FSRU), Mukran (Neptune FSRU), Wilhelmshaven (Hoegh Esperanza & Excelsior FSRUs)
                    <br>
                    {country_html}
                    </body>
                    </html>
                """
    
    return email_body

