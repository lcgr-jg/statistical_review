import logging
import threading
import pandas as pd
import numpy as np
from jain_commods.fundamental.power.price_functions import FuelSpreadsCalculator
from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery
from jain_commods.core.interfaces.snowflake.epexquery import EPEXQuery
from jain_commods.core.interfaces.bloomberg import BBGQuery
from jain_commods.core.interfaces.sqldb import DataQuery
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import partial
from datetime import datetime

logger = logging.getLogger(__name__)

# Import enterprise caching
from core.cache import cached_result
from core.data_freshness import tracker

# Import spot price classes from market cache
from jain_commods.core.cache.data.market import (
    PricePowerSpot,
    PriceGasSpot,
    PriceCO2Spot,
    PriceCoalSpot
)


@cached_result(ttl_seconds=3600, key_prefix="prices_power_spot")
def load_power_spot_data():
    """Load power spot prices using PricePowerSpot class from market cache."""
    logger.info("Loading power spot prices from market cache...")
    
    try:
        power_spot = PricePowerSpot(freq='h')  # Hourly frequency
        power_spot.load(from_s3=True, show_metadata=True)
        
        if power_spot.data is not None and not power_spot.data.empty:
            # Register data freshness
            tracker.register_data_source(
                "Prices Power Spot",
                datetime.now(),
                expected_frequency_minutes=60,
                metadata={
                    'rows': len(power_spot.data),
                    'columns': len(power_spot.data.columns),
                    'date_range': f"{power_spot.data.index.min()} to {power_spot.data.index.max()}"
                }
            )
            logger.info(f"Loaded power spot data - shape: {power_spot.data.shape}")
            return power_spot.data, power_spot.data_normalized
        
        logger.warning("No power spot data available")
        return pd.DataFrame(), pd.DataFrame()
        
    except Exception as e:
        logger.error(f"Error loading power spot data: {e}", exc_info=True)
        return pd.DataFrame(), pd.DataFrame()


@cached_result(ttl_seconds=3600, key_prefix="prices_gas_spot")
def load_gas_spot_data():
    """Load gas spot prices using PriceGasSpot class from market cache."""
    logger.info("Loading gas spot prices from market cache...")
    
    try:
        gas_spot = PriceGasSpot()
        gas_spot.load(from_s3=True, show_metadata=True)
        
        if gas_spot.data is not None and not gas_spot.data.empty:
            # Register data freshness (registered with cache class like PricePowerSpot)
            tracker.register_data_source(
                "Prices Gas Spot",
                datetime.now(),
                expected_frequency_minutes=60,
                metadata={
                    'rows': len(gas_spot.data),
                    'columns': len(gas_spot.data.columns),
                    'date_range': f"{gas_spot.data.index.min()} to {gas_spot.data.index.max()}"
                }
            )
            logger.info(f"Loaded gas spot data - shape: {gas_spot.data.shape}")
            return gas_spot.data, gas_spot.data_normalized
        
        logger.warning("No gas spot data available")
        return pd.DataFrame(), pd.DataFrame()
        
    except Exception as e:
        logger.error(f"Error loading gas spot data: {e}", exc_info=True)
        return pd.DataFrame(), pd.DataFrame()


@cached_result(ttl_seconds=3600, key_prefix="prices_co2_spot")
def load_co2_spot_data():
    """Load CO2 spot prices using PriceCO2Spot class from market cache."""
    logger.info("Loading CO2 spot prices from market cache...")
    
    try:
        co2_spot = PriceCO2Spot()
        co2_spot.load(from_s3=True, show_metadata=True)
        
        if co2_spot.data is not None and not co2_spot.data.empty:
            # Register data freshness (registered with cache class like PricePowerSpot)
            tracker.register_data_source(
                "Prices CO2 Spot",
                datetime.now(),
                expected_frequency_minutes=60,
                metadata={
                    'rows': len(co2_spot.data),
                    'columns': len(co2_spot.data.columns),
                    'date_range': f"{co2_spot.data.index.min()} to {co2_spot.data.index.max()}"
                }
            )
            logger.info(f"Loaded CO2 spot data - shape: {co2_spot.data.shape}")
            return co2_spot.data, co2_spot.data_normalized
        
        logger.warning("No CO2 spot data available")
        return pd.DataFrame(), pd.DataFrame()
        
    except Exception as e:
        logger.error(f"Error loading CO2 spot data: {e}", exc_info=True)
        return pd.DataFrame(), pd.DataFrame()


@cached_result(ttl_seconds=3600, key_prefix="prices_coal_spot")
def load_coal_spot_data():
    """Load coal spot prices using PriceCoalSpot class from market cache."""
    logger.info("Loading coal spot prices from market cache...")
    
    try:
        coal_spot = PriceCoalSpot()
        coal_spot.load(from_s3=True, show_metadata=True)
        
        if coal_spot.data is not None and not coal_spot.data.empty:
            # Register data freshness
            tracker.register_data_source(
                "Prices Coal Spot",
                datetime.now(),
                expected_frequency_minutes=60,
                metadata={
                    'rows': len(coal_spot.data),
                    'columns': len(coal_spot.data.columns),
                    'date_range': f"{coal_spot.data.index.min()} to {coal_spot.data.index.max()}"
                }
            )
            logger.info(f"Loaded coal spot data - shape: {coal_spot.data.shape}")
            return coal_spot.data, coal_spot.data_normalized
        
        logger.warning("No coal spot data available")
        return pd.DataFrame(), pd.DataFrame()
        
    except Exception as e:
        logger.error(f"Error loading coal spot data: {e}", exc_info=True)
        return pd.DataFrame(), pd.DataFrame()


@cached_result(ttl_seconds=14400, key_prefix="prices_css_cds_raw")
def load_css_cds_data(calculator, contracts):
    """Load CSS and CDS data using optimized method that loads common data only once"""
    logger.info("Loading CSS and CDS data (optimized)...")
    
    # Get both CSS and CDS in a single call - this loads power and carbon data only once
    CSS_raw, CDS_raw = calculator.get_fuel_spreads(
        strip=contracts,
        country_code=["de", "fr", "nl", "gb", "be", "ch", "it", "es", "at", "hu"],
        spread_types=['css', 'cds'],
        profile='Base'
    )
    
    # Rename columns - only keep CSS_MID_EFF as requested
    CSS_raw = CSS_raw.rename(columns={
        'CSS_EFF2': 'CSS_MID_EFF'
    })
    
    # Drop other efficiency columns if they exist
    cols_to_drop = ['CSS_EFF1', 'CSS_EFF3']
    if hasattr(CSS_raw, 'columns'):
        CSS_raw = CSS_raw.drop(columns=[col for col in cols_to_drop if col in CSS_raw.columns], errors='ignore')
    
    CDS_raw = CDS_raw.rename(columns={
        'CDS_EFF1': 'CDS_LOW_EFF',
        'CDS_EFF2': 'CDS_MID_EFF',
        'CDS_EFF3': 'CDS_HI_EFF'
    })
    
    return CSS_raw, CDS_raw


@cached_result(ttl_seconds=3600, key_prefix="prices_css_spot_computed")
def compute_css_spot_from_cache(
    power_spot_normalized: pd.DataFrame,
    gas_spot_normalized: pd.DataFrame,
    co2_spot_normalized: pd.DataFrame,
    calculator
) -> pd.DataFrame:
    """
    Compute CSS spot from cached gas and CO2 spot data.
    
    Args:
        power_spot_normalized: Power spot prices from PricePowerSpot (normalized format)
        gas_spot_normalized: Gas spot prices from PriceGasSpot (normalized format)
        co2_spot_normalized: CO2 spot prices from PriceCO2Spot (normalized format)
        calculator: FuelSpreadsCalculator instance for efficiency and emissions factors
    
    Returns:
        DataFrame with CSS_MID_EFF in the same format as CSS_processed_spot
    """
    logger.info("Computing CSS spot from cached gas and CO2 spot data...")
    
    if power_spot_normalized.empty or gas_spot_normalized.empty or co2_spot_normalized.empty:
        logger.warning("Missing required spot data - cannot compute CSS spot")
        return pd.DataFrame()
    
    try:
        # Get efficiency and emissions factors
        efficiency = calculator.DEFAULT_GAS_EFFICIENCIES[1]  # Mid efficiency
        emissions = calculator.GAS_EMISSIONS_FACTOR

        # Map countries to gas hubs (TTF for continental Europe, NBP for GB)
        country_to_hub = {
            'DE': 'TTF', 'FR': 'TTF', 'NL': 'TTF', 'BE': 'TTF', 'AT': 'TTF',
            'CH': 'TTF', 'IT': 'TTF', 'ES': 'TTF', 'CZ': 'TTF', 'SK': 'TTF',
            'SI': 'TTF', 'GR': 'TTF', 'RO': 'TTF', 'BG': 'TTF', 'HR': 'TTF',
            'GB': 'NBP'
        }

        # Map countries to CO2 hubs (EUA for EU, UKA for GB)
        country_to_carbon = {
            'DE': 'EUA', 'FR': 'EUA', 'NL': 'EUA', 'BE': 'EUA', 'AT': 'EUA',
            'CH': 'EUA', 'IT': 'EUA', 'ES': 'EUA', 'CZ': 'EUA', 'SK': 'EUA',
            'SI': 'EUA', 'GR': 'EUA', 'RO': 'EUA', 'BG': 'EUA', 'HR': 'EUA',
            'GB': 'UKA'
        }

        # Normalize the valuedate column across the three feeds.  Power spot
        # arrives as ``datetime64[ns, CET]`` while gas / CO2 are tz-naive —
        # pandas refuses to merge across that boundary.  Strip timezone info
        # uniformly so the joins align on wall-clock time.
        def _to_naive_hour(ts: pd.Series) -> pd.Series:
            ts = pd.to_datetime(ts)
            if getattr(ts.dt, "tz", None) is not None:
                ts = ts.dt.tz_localize(None)
            return ts.dt.floor("h")

        # Power spot data is already filtered to hourly EUR in load_data()
        power_df = power_spot_normalized.copy()
        power_df['valuedate'] = _to_naive_hour(power_df['valuedate'])
        power_hourly = (
            power_df
            .groupby(['valuedate', 'zone', 'exchange'], as_index=False)['value']
            .mean()
            .rename(columns={'value': 'power_price'})
        )
        power_hourly['COUNTRY'] = power_hourly['zone'].astype(str).str.upper()
        power_hourly['gas_hub'] = power_hourly['COUNTRY'].map(country_to_hub)
        power_hourly['co2_hub'] = power_hourly['COUNTRY'].map(country_to_carbon)
        power_hourly = power_hourly.dropna(subset=['gas_hub', 'co2_hub'])

        # Prepare gas data - aggregate to hourly by hub
        gas_hourly = gas_spot_normalized.copy()
        gas_hourly['valuedate'] = _to_naive_hour(gas_hourly['valuedate'])
        gas_hourly['hub'] = gas_hourly['hub'].astype(str).str.upper()
        gas_hourly = (
            gas_hourly
            .groupby(['valuedate', 'hub'], as_index=False)['value']
            .mean()
            .rename(columns={'value': 'gas_price'})
        )

        # Prepare CO2 data - aggregate to hourly by hub
        co2_hourly = co2_spot_normalized.copy()
        co2_hourly['valuedate'] = _to_naive_hour(co2_hourly['valuedate'])
        co2_hourly['hub'] = co2_hourly['hub'].astype(str).str.upper()
        co2_hourly = (
            co2_hourly
            .groupby(['valuedate', 'hub'], as_index=False)['value']
            .mean()
            .rename(columns={'value': 'co2_price'})
        )

        # Vectorized joins instead of row-by-row filtering.
        css_df = power_hourly.merge(
            gas_hourly.rename(columns={'hub': 'gas_hub'}),
            on=['valuedate', 'gas_hub'],
            how='inner',
        )
        css_df = css_df.merge(
            co2_hourly.rename(columns={'hub': 'co2_hub'}),
            on=['valuedate', 'co2_hub'],
            how='inner',
        )

        if css_df.empty:
            logger.warning("No CSS spot data computed - no matching gas/CO2 prices found")
            return pd.DataFrame()

        # Calculate CSS: Power - Gas/Efficiency - (CO2 * Emissions)/Efficiency
        css_df['CSS_MID_EFF'] = (
            css_df['power_price']
            - (css_df['gas_price'] / efficiency)
            - ((emissions / efficiency) * css_df['co2_price'])
        )

        # Build expected output schema
        css_df['DATE'] = css_df['valuedate'].dt.normalize()
        css_df['DELIVERY_START'] = css_df['valuedate']
        css_df['HOUR'] = css_df['valuedate'].dt.hour
        css_df['DAY'] = css_df['valuedate'].dt.day
        css_df['MONTH'] = css_df['valuedate'].dt.month
        css_df['YEAR'] = css_df['valuedate'].dt.year
        css_df['DAYS_TO_DELIVERY'] = 0
        css_df['CONTRACT_TYPE'] = 'SPOT'
        css_df['DELIVERY_PERIOD'] = css_df['valuedate'].dt.strftime('%Y-%m-%d')
        css_df['DELIVERY_END'] = css_df['valuedate'] + pd.Timedelta(hours=1)

        css_df = css_df[[
            'DATE', 'DELIVERY_START', 'COUNTRY', 'HOUR', 'DAY', 'MONTH', 'YEAR',
            'DAYS_TO_DELIVERY', 'CSS_MID_EFF', 'CONTRACT_TYPE', 'DELIVERY_PERIOD', 'DELIVERY_END'
        ]]

        # Add Period column
        month_map = {
            1: 'JAN', 2: 'FEB', 3: 'MAR', 4: 'APR', 5: 'MAY', 6: 'JUN',
            7: 'JUL', 8: 'AUG', 9: 'SEP', 10: 'OCT', 11: 'NOV', 12: 'DEC'
        }
        css_df['Period'] = css_df['MONTH'].map(month_map)

        # Set multi-index to match expected format
        css_df = css_df.set_index(['DATE', 'COUNTRY', 'DELIVERY_PERIOD', 'DAYS_TO_DELIVERY'])

        logger.info(f"Computed CSS spot data - shape: {css_df.shape}")
        logger.debug(f"Countries: {css_df.index.get_level_values('COUNTRY').unique()}")
        logger.debug(f"Date range: {css_df.index.get_level_values('DATE').min()} to {css_df.index.get_level_values('DATE').max()}")

        return css_df

    except Exception as e:
        logger.error(f"Error computing CSS spot from cache: {e}", exc_info=True)
        return pd.DataFrame()


@cached_result(ttl_seconds=1800, key_prefix="prices_css_cds")
def load_precomputed_css_cds_data():
    """Load precomputed CSS and CDS data from new database using DataQuery interface"""
    logger.info("Loading precomputed CSS and CDS data from database...")
    
    dq = DataQuery(logintype='prod')
    
    try:
        # Load CSS spot data - NOTE: This is now only used for futures, spot is computed from cache
        logger.debug("Loading CSS spot data from database (for reference only - spot computed from cache)...")
        css_spot = dq.get_data(
            by='metadata', 
            metadata={'commodity': 'POWER',
                     'category1': 'PRICE',
                     'category2': 'CSS',
                     'category3': 'Spot'},
            multi_instance='latest',
            querytype='bulk',
            start_date=datetime(2020, 1, 1)
            # No end_date to get all available data up to today
        )
        
        css_spot_df = next(iter(css_spot.values())) if css_spot else pd.DataFrame()
        
        # Load CSS futures data by frequency to preserve contract type information
        logger.debug("Loading CSS futures data by frequency...")
        
        css_fut_dfs = []
        for frequency in ['Monthly', 'Quarterly', 'Yearly']:
            logger.debug(f"Loading {frequency} CSS futures...")
            css_fut = dq.get_data(
                by='metadata', 
                metadata={'commodity': 'POWER',
                         'category1': 'PRICE',
                         'category2': 'CSS',
                         'category3': 'Futures',
                         'frequency': frequency},
                querytype='bulk',
                report_date_from=datetime(2020, 1, 1)
            )
            
            css_fut_df = next(iter(css_fut.values())) if css_fut else pd.DataFrame()
            
            if not css_fut_df.empty:
                # Tag with contract type
                css_fut_df['CONTRACT_TYPE'] = frequency.upper()
                css_fut_dfs.append(css_fut_df)
                logger.debug(f"{frequency}: {css_fut_df.shape[0]} rows")
        
        # Combine all frequencies
        css_fut_df = pd.concat(css_fut_dfs, ignore_index=True) if css_fut_dfs else pd.DataFrame()
        
        # Process and combine CSS data
        css_combined_df = process_precomputed_css_data(css_spot_df, css_fut_df)
        
        # Load CDS spot data
        logger.debug("Loading CDS spot data...")
        cds_spot = dq.get_data(
            by='metadata', 
            metadata={'commodity': 'POWER',
                     'category1': 'PRICE',
                     'category2': 'CDS',
                     'category3': 'Spot'},
            multi_instance='latest',
            querytype='bulk',
            start_date=datetime(2020, 1, 1)
        )
        
        cds_spot_df = next(iter(cds_spot.values())) if cds_spot else pd.DataFrame()
        
        # Load CDS futures data by frequency
        logger.debug("Loading CDS futures data by frequency...")
        
        cds_fut_dfs = []
        for frequency in ['Monthly', 'Quarterly', 'Yearly']:
            logger.debug(f"Loading {frequency} CDS futures...")
            cds_fut = dq.get_data(
                by='metadata', 
                metadata={'commodity': 'POWER',
                         'category1': 'PRICE',
                         'category2': 'CDS',
                         'category3': 'Futures',
                         'frequency': frequency},
                querytype='bulk',
                report_date_from=datetime(2020, 1, 1)
            )
            
            cds_fut_df = next(iter(cds_fut.values())) if cds_fut else pd.DataFrame()
            
            if not cds_fut_df.empty:
                # Tag with contract type
                cds_fut_df['CONTRACT_TYPE'] = frequency.upper()
                cds_fut_dfs.append(cds_fut_df)
                logger.debug(f"{frequency}: {cds_fut_df.shape[0]} rows")
        
        # Combine all frequencies
        cds_fut_df = pd.concat(cds_fut_dfs, ignore_index=True) if cds_fut_dfs else pd.DataFrame()
        
        # Process and combine CDS data
        cds_combined_df = process_precomputed_cds_data(cds_spot_df, cds_fut_df)
        
        logger.debug(f"Loaded CSS data shape: {css_combined_df.shape}")
        logger.debug(f"Loaded CDS data shape: {cds_combined_df.shape}")
        
        # Register data freshness
        tracker.register_data_source(
            "Prices CSS/CDS Data",
            datetime.now(),
            expected_frequency_minutes=30,
            metadata={'css_rows': len(css_combined_df), 'cds_rows': len(cds_combined_df)}
        )
        
        return css_combined_df, cds_combined_df
        
    except Exception as e:
        logger.error(f"Error loading precomputed CSS/CDS data: {e}", exc_info=True)
        logger.warning("Falling back to empty DataFrames")
        return pd.DataFrame(), pd.DataFrame()


def process_precomputed_css_data(css_spot_df, css_fut_df):
    """Process and format precomputed CSS data to match existing interface, keeping spot and futures separate"""
    
    def process_single_dataframe(df, data_type):
        """Process a single dataframe (spot or futures)"""
        if df.empty:
            return pd.DataFrame()
        
        logger.debug(f"Processing {data_type} data with columns: {list(df.columns)}")
        logger.debug(f"{data_type} data shape: {df.shape}")
            
        # Select columns of interest (excluding first and last columns as in spot_example)
        # But preserve CONTRACT_TYPE if it exists
        if 'CONTRACT_TYPE' in df.columns:
            # Keep CONTRACT_TYPE even if it's in the last column position
            df_processed = df[df.columns[1:]].copy()  # Keep all except first column
        else:
            df_processed = df[df.columns[1:len(df.columns)-1]].copy()
        
        # Check for required columns and add error handling
        required_cols = ['date', 'report_date']
        missing_cols = [col for col in required_cols if col not in df_processed.columns]
        
        if missing_cols:
            logger.warning(f"Missing required columns for {data_type}: {missing_cols}")
            logger.debug(f"Available columns: {list(df_processed.columns)}")
            return pd.DataFrame()
        
        # Ensure date columns are datetime
        df_processed['date'] = pd.to_datetime(df_processed['date'])
        df_processed['report_date'] = pd.to_datetime(df_processed['report_date'])
        
        # Add days to delivery column - ensure this is calculated correctly
        df_processed['days_to_delivery'] = (df_processed['date'] - df_processed['report_date']).dt.days
        
        # Filter out negative days to delivery (past contracts)
        logger.debug(f"Before filtering: {len(df_processed)} rows")
        df_processed = df_processed[df_processed['days_to_delivery'] >= 0]
        logger.debug(f"After filtering negative days: {len(df_processed)} rows")
        
        # Add time components
        df_processed['hour'] = df_processed['date'].dt.hour
        df_processed['day'] = df_processed['date'].dt.day
        df_processed['month'] = df_processed['date'].dt.month
        df_processed['year'] = df_processed['date'].dt.year
        
        # Rename columns to match existing interface
        df_processed = df_processed.rename(columns={
            'report_date': 'DATE',
            'date': 'DELIVERY_START',
            'country': 'COUNTRY'
        })
        
        # Convert efficiency columns to match existing naming convention
        # Keep LOW, MID, HI efficiency columns (drop only eff4)
        df_processed = df_processed.rename(columns={
            'eff1': 'CSS_LOW_EFF',
            'eff2': 'CSS_MID_EFF',
            'eff3': 'CSS_HI_EFF',
            'days_to_delivery': 'DAYS_TO_DELIVERY'  # Rename before uppercase conversion
        })
        
        # Drop only eff4 (very high efficiency)
        cols_to_drop = ['eff4']
        df_processed = df_processed.drop(columns=[col for col in cols_to_drop if col in df_processed.columns], errors='ignore')
        
        # Preserve CONTRACT_TYPE before uppercase conversion if it exists
        contract_type_values = None
        if 'CONTRACT_TYPE' in df_processed.columns:
            contract_type_values = df_processed['CONTRACT_TYPE'].copy()
        
        # Convert all column names to uppercase
        df_processed.columns = df_processed.columns.str.upper()
        
        # Add data source identifier 
        df_processed['DATA_SOURCE'] = data_type.upper()
        
        # Set CONTRACT_TYPE appropriately
        if contract_type_values is not None:
            # Restore the original contract type values for futures data
            df_processed['CONTRACT_TYPE'] = contract_type_values
        else:
            # Set contract type for spot data
            df_processed['CONTRACT_TYPE'] = 'SPOT' if data_type == 'spot' else 'UNKNOWN'
        
        # KEEP HOURLY DATA - do NOT aggregate here!
        # Daily aggregation will be handled in the spot dashboard when user selects "Daily Avg"
        if data_type == 'spot':
            logger.debug("Preserving hourly CSS spot data (not aggregating)...")
            logger.debug(f"Total hourly records: {len(df_processed)} rows")
            
            # Ensure HOUR column is preserved (don't set to 0)
            # HOUR should already be set from the 'hour' column in the raw data
            if 'HOUR' not in df_processed.columns and 'hour' in df_processed.columns:
                df_processed['HOUR'] = df_processed['hour']
            elif 'HOUR' not in df_processed.columns:
                # If HOUR is missing, extract from DELIVERY_START
                df_processed['HOUR'] = df_processed['DELIVERY_START'].dt.hour
            
            # Ensure other time columns exist
            df_processed['DAY'] = df_processed['DELIVERY_START'].dt.day
            df_processed['MONTH'] = df_processed['DELIVERY_START'].dt.month
            df_processed['YEAR'] = df_processed['DELIVERY_START'].dt.year
            
            # DELIVERY_END should be 1 hour later for hourly data, not 1 day
            df_processed['DELIVERY_END'] = df_processed['DELIVERY_START'] + pd.Timedelta(hours=1)
            
            logger.debug(f"Sample hours in CSS data: {sorted(df_processed['HOUR'].unique())}")
        
        # Extract period information using actual contract type and delivery dates
        df_processed['Period'] = df_processed.apply(lambda row: extract_period_from_contract(row['DELIVERY_START'], row.get('CONTRACT_TYPE', 'SPOT')), axis=1)
        df_processed['Year'] = df_processed['DELIVERY_START'].dt.year
        
        # Use delivery date as the natural identifier instead of artificial STRIP
        df_processed['DELIVERY_PERIOD'] = df_processed['DELIVERY_START'].dt.strftime('%Y-%m-%d')
        
        # Create DELIVERY_END column based on contract type
        def calculate_delivery_end(row):
            contract_type = row.get('CONTRACT_TYPE', 'SPOT')
            delivery_start = row['DELIVERY_START']
            
            if contract_type == 'MONTHLY' or contract_type == 'monthly':
                # End of month
                return delivery_start + pd.offsets.MonthEnd(1)
            elif contract_type == 'QUARTERLY' or contract_type == 'quarterly':
                # 3 months later
                return delivery_start + pd.DateOffset(months=3) - pd.Timedelta(days=1)
            elif contract_type == 'YEARLY' or contract_type == 'yearly':
                # 1 year later
                return delivery_start + pd.DateOffset(years=1) - pd.Timedelta(days=1)
            else:  # SPOT
                return delivery_start + pd.Timedelta(hours=1)
        
        df_processed['DELIVERY_END'] = df_processed.apply(calculate_delivery_end, axis=1)
        
        # Debug: Basic data info
        if data_type == 'futures':
            days_dist = df_processed['DAYS_TO_DELIVERY'].describe()
            logger.debug(f"Futures days-to-delivery: Min: {days_dist['min']}, Max: {days_dist['max']}, Mean: {days_dist['mean']:.1f}")
        
        logger.debug(f"Final {data_type} data shape: {df_processed.shape}")
        
        # Sort by DATE, COUNTRY, DELIVERY_START, DAYS_TO_DELIVERY to ensure proper ordering
        df_processed = df_processed.sort_values(['DATE', 'COUNTRY', 'DELIVERY_START', 'DAYS_TO_DELIVERY'])
        
        return df_processed
    
    # Process spot and futures separately
    spot_processed = process_single_dataframe(css_spot_df, 'spot')
    futures_processed = process_single_dataframe(css_fut_df, 'futures')
    
    # Combine processed data - include both spot and futures
    processed_dfs = []
    if not spot_processed.empty:
        processed_dfs.append(spot_processed)
    if not futures_processed.empty:
        processed_dfs.append(futures_processed)
    
    if not processed_dfs:
        logger.warning("No valid data to process")
        return pd.DataFrame()
    
    # Combine all data
    result_df = pd.concat(processed_dfs, ignore_index=True)
    
    # Final sort to ensure proper index ordering
    result_df = result_df.sort_values(['DATE', 'COUNTRY', 'DELIVERY_PERIOD', 'DAYS_TO_DELIVERY'])
    
    # Set multi-index using actual delivery period instead of artificial STRIP
    result_df = result_df.set_index(['DATE', 'COUNTRY', 'DELIVERY_PERIOD', 'DAYS_TO_DELIVERY'])
    
    logger.debug(f"Processed CSS data: {len(result_df)} rows")
    logger.debug(f"Countries: {result_df.index.get_level_values('COUNTRY').unique()}")
    logger.debug(f"Date range: {result_df.index.get_level_values('DATE').min()} to {result_df.index.get_level_values('DATE').max()}")
    
    return result_df


def process_precomputed_cds_data(cds_spot_df, cds_fut_df):
    """Process and format precomputed CDS data to match CSS interface exactly"""
    
    def process_single_dataframe(df, data_type):
        """Process a single dataframe (spot or futures)"""
        if df.empty:
            return pd.DataFrame()
        
        logger.debug(f"Processing {data_type} CDS data with columns: {list(df.columns)}")
        logger.debug(f"{data_type} CDS data shape: {df.shape}")
            
        # Select columns of interest (excluding first and last columns)
        if 'CONTRACT_TYPE' in df.columns:
            df_processed = df[df.columns[1:]].copy()
        else:
            df_processed = df[df.columns[1:len(df.columns)-1]].copy()
        
        # Check for required columns
        required_cols = ['date', 'report_date']
        missing_cols = [col for col in required_cols if col not in df_processed.columns]
        
        if missing_cols:
            logger.warning(f"Missing required columns for {data_type}: {missing_cols}")
            logger.debug(f"Available columns: {list(df_processed.columns)}")
            return pd.DataFrame()
        
        # Ensure date columns are datetime
        df_processed['date'] = pd.to_datetime(df_processed['date'])
        df_processed['report_date'] = pd.to_datetime(df_processed['report_date'])
        
        # Add days to delivery column
        df_processed['days_to_delivery'] = (df_processed['date'] - df_processed['report_date']).dt.days
        
        # Filter out negative days to delivery
        logger.debug(f"Before filtering: {len(df_processed)} rows")
        df_processed = df_processed[df_processed['days_to_delivery'] >= 0]
        logger.debug(f"After filtering negative days: {len(df_processed)} rows")
        
        # Add time components
        df_processed['hour'] = df_processed['date'].dt.hour
        df_processed['day'] = df_processed['date'].dt.day
        df_processed['month'] = df_processed['date'].dt.month
        df_processed['year'] = df_processed['date'].dt.year
        
        # Rename columns to match existing interface
        df_processed = df_processed.rename(columns={
            'report_date': 'DATE',
            'date': 'DELIVERY_START',
            'country': 'COUNTRY'
        })
        
        # Convert efficiency columns to match CDS naming
        df_processed = df_processed.rename(columns={
            'eff1': 'CDS_LOW_EFF',
            'eff2': 'CDS_MID_EFF',
            'eff3': 'CDS_HI_EFF',
            'days_to_delivery': 'DAYS_TO_DELIVERY'
        })
        
        # Drop eff4 if it exists
        cols_to_drop = ['eff4']
        df_processed = df_processed.drop(columns=[col for col in cols_to_drop if col in df_processed.columns], errors='ignore')
        
        # Preserve CONTRACT_TYPE before uppercase conversion if it exists
        contract_type_values = None
        if 'CONTRACT_TYPE' in df_processed.columns:
            contract_type_values = df_processed['CONTRACT_TYPE'].copy()
        
        # Convert all column names to uppercase
        df_processed.columns = df_processed.columns.str.upper()
        
        # Add data source identifier
        df_processed['DATA_SOURCE'] = data_type.upper()
        
        # Set CONTRACT_TYPE appropriately
        if contract_type_values is not None:
            df_processed['CONTRACT_TYPE'] = contract_type_values
        else:
            df_processed['CONTRACT_TYPE'] = 'SPOT' if data_type == 'spot' else 'UNKNOWN'
        
        # Handle spot data (hourly)
        if data_type == 'spot':
            logger.debug("Preserving hourly CDS spot data (not aggregating)...")
            logger.debug(f"Total hourly records: {len(df_processed)} rows")
            
            if 'HOUR' not in df_processed.columns and 'hour' in df_processed.columns:
                df_processed['HOUR'] = df_processed['hour']
            elif 'HOUR' not in df_processed.columns:
                df_processed['HOUR'] = df_processed['DELIVERY_START'].dt.hour
            
            df_processed['DAY'] = df_processed['DELIVERY_START'].dt.day
            df_processed['MONTH'] = df_processed['DELIVERY_START'].dt.month
            df_processed['YEAR'] = df_processed['DELIVERY_START'].dt.year
            df_processed['DELIVERY_END'] = df_processed['DELIVERY_START'] + pd.Timedelta(hours=1)
            
            logger.debug(f"Sample hours in CDS data: {sorted(df_processed['HOUR'].unique())}")
        
        # Extract period information using contract type and delivery dates
        df_processed['Period'] = df_processed.apply(lambda row: extract_period_from_contract(row['DELIVERY_START'], row.get('CONTRACT_TYPE', 'SPOT')), axis=1)
        df_processed['Year'] = df_processed['DELIVERY_START'].dt.year
        
        # Use delivery date as identifier
        df_processed['DELIVERY_PERIOD'] = df_processed['DELIVERY_START'].dt.strftime('%Y-%m-%d')
        
        # Create DELIVERY_END column based on contract type (don't overwrite spot data's hourly end)
        def calculate_delivery_end(row):
            contract_type = row.get('CONTRACT_TYPE', 'SPOT')
            delivery_start = row['DELIVERY_START']
            
            if contract_type == 'MONTHLY' or contract_type == 'monthly':
                # End of month
                return delivery_start + pd.offsets.MonthEnd(1)
            elif contract_type == 'QUARTERLY' or contract_type == 'quarterly':
                # 3 months later
                return delivery_start + pd.DateOffset(months=3) - pd.Timedelta(days=1)
            elif contract_type == 'YEARLY' or contract_type == 'yearly':
                # 1 year later
                return delivery_start + pd.DateOffset(years=1) - pd.Timedelta(days=1)
            else:  # SPOT
                return delivery_start + pd.Timedelta(hours=1)
        
        # Only calculate DELIVERY_END if not already set (spot data sets it to +1 hour above)
        if data_type != 'spot' or 'DELIVERY_END' not in df_processed.columns:
            df_processed['DELIVERY_END'] = df_processed.apply(calculate_delivery_end, axis=1)
        
        # Debug info
        if data_type == 'futures':
            days_dist = df_processed['DAYS_TO_DELIVERY'].describe()
            logger.debug(f"Futures days-to-delivery: Min: {days_dist['min']}, Max: {days_dist['max']}, Mean: {days_dist['mean']:.1f}")
        
        logger.debug(f"Final {data_type} CDS data shape: {df_processed.shape}")
        
        # Sort by DATE, COUNTRY, DELIVERY_START, DAYS_TO_DELIVERY
        df_processed = df_processed.sort_values(['DATE', 'COUNTRY', 'DELIVERY_START', 'DAYS_TO_DELIVERY'])
        
        return df_processed
    
    # Process spot and futures separately
    spot_processed = process_single_dataframe(cds_spot_df, 'spot')
    futures_processed = process_single_dataframe(cds_fut_df, 'futures')
    
    # Combine processed data
    processed_dfs = []
    if not spot_processed.empty:
        processed_dfs.append(spot_processed)
    if not futures_processed.empty:
        processed_dfs.append(futures_processed)
    
    if not processed_dfs:
        logger.warning("No valid CDS data to process")
        return pd.DataFrame()
    
    # Combine all data
    result_df = pd.concat(processed_dfs, ignore_index=True)
    
    # Final sort to match CSS structure
    result_df = result_df.sort_values(['DATE', 'COUNTRY', 'DELIVERY_PERIOD', 'DAYS_TO_DELIVERY'])
    
    # Set multi-index to match CSS structure exactly: ['DATE', 'COUNTRY', 'DELIVERY_PERIOD', 'DAYS_TO_DELIVERY']
    result_df = result_df.set_index(['DATE', 'COUNTRY', 'DELIVERY_PERIOD', 'DAYS_TO_DELIVERY'])
    
    logger.debug(f"Processed CDS data: {len(result_df)} rows")
    logger.debug(f"Countries: {result_df.index.get_level_values('COUNTRY').unique()}")
    logger.debug(f"Date range: {result_df.index.get_level_values('DATE').min()} to {result_df.index.get_level_values('DATE').max()}")
    
    return result_df


def extract_period_from_contract(delivery_date, contract_type):
    """Extract period string from delivery date and contract type"""
    month = delivery_date.month
    day = delivery_date.day
    
    # Map months to abbreviations
    month_map = {
        1: 'JAN', 2: 'FEB', 3: 'MAR', 4: 'APR',
        5: 'MAY', 6: 'JUN', 7: 'JUL', 8: 'AUG',
        9: 'SEP', 10: 'OCT', 11: 'NOV', 12: 'DEC'
    }
    
    # Use actual contract type to determine period
    if contract_type == 'YEARLY':
        return 'CAL'
    elif contract_type == 'QUARTERLY':
        # Determine quarter from delivery month
        if month in [1, 2, 3]:
            return 'Q1'
        elif month in [4, 5, 6]:
            return 'Q2'
        elif month in [7, 8, 9]:
            return 'Q3'
        else:  # month in [10, 11, 12]
            return 'Q4'
    elif contract_type == 'MONTHLY':
        return month_map.get(month, 'UNK')
    else:  # SPOT or unknown
        return month_map.get(month, 'UNK')

def extract_period_from_date(delivery_date, report_date=None):
    """Extract period string from delivery date (e.g., 'JAN', 'Q1', 'CAL')"""
    month = delivery_date.month
    day = delivery_date.day
    delivery_year = delivery_date.year
    
    # Map months to abbreviations
    month_map = {
        1: 'JAN', 2: 'FEB', 3: 'MAR', 4: 'APR',
        5: 'MAY', 6: 'JUN', 7: 'JUL', 8: 'AUG',
        9: 'SEP', 10: 'OCT', 11: 'NOV', 12: 'DEC'
    }
    
    # Calculate days to delivery if report_date is available
    if report_date is not None:
        days_to_delivery = (delivery_date - report_date).days
    else:
        days_to_delivery = None
    
    # Enhanced logic to properly distinguish between different contract types
    
    # For January 1st, distinguish between CAL, Q1, and JAN based on days to delivery
    if month == 1 and day == 1:
        if days_to_delivery is not None:
            if days_to_delivery > 250:  # Very long period suggests calendar year
                return 'CAL'
            elif days_to_delivery > 60:  # Medium period suggests quarterly 
                return 'Q1'
            else:  # Short period suggests monthly
                return 'JAN'
        else:
            # Fallback without days_to_delivery - assume monthly for safety
            return 'JAN'
    
    # Detect quarterly contracts (start on quarter boundaries)
    # But be more careful about days to delivery to avoid confusing with monthly
    if day == 1 and days_to_delivery is not None:
        if month == 4 and days_to_delivery > 60:  # Q2
            return 'Q2'
        elif month == 7 and days_to_delivery > 60:  # Q3
            return 'Q3'
        elif month == 10 and days_to_delivery > 60:  # Q4
            return 'Q4'
    
    # For the first day of any month, check if it's really a monthly contract
    # or if it should be treated as quarterly based on delivery period
    if day == 1 and days_to_delivery is not None and days_to_delivery <= 60:
        # Short delivery period suggests this is actually a monthly contract
        return month_map.get(month, 'UNK')
    
    # Default to monthly periods for all other cases
    return month_map.get(month, 'UNK')


@cached_result(ttl_seconds=14400, key_prefix="prices_power_data")
def load_power_data(eex, contracts):
    """Load base-peak and xb-spread data in parallel"""
    with ThreadPoolExecutor(max_workers=2) as executor:
        future_xb = executor.submit(
            eex.get_strip_prices_verbose,
            strip=contracts,
            country_code=['de', 'gb', 'fr', 'it', 'nl', 'at', 'ch', 'hu', 'no2', 'se4', 'dk2', 'dk1'],
            profile=['Base', 'Peak'],
            start_date='2019-04-01'
        )
    
    future_base_peak = future_xb
    base_peak_data = future_base_peak.result()
    xb_spread_data = future_xb.result()
        
    return base_peak_data, xb_spread_data


def process_css_data(CSS_raw, calculator):
    """Process CSS data with rolling metrics"""
    CSS_processed = add_rolling_metrics(CSS_raw)
    
    # Extract Period and Year from STRIP column
    temp_df = CSS_processed.reset_index()
    temp_df['Period'] = temp_df['STRIP'].apply(lambda x: x.split('-')[0] if '-' in str(x) else x)
    temp_df['Year'] = temp_df['STRIP'].apply(lambda x: 
                                         int('20' + x.split('-')[1]) if '-' in str(x) and len(x.split('-')[1]) == 2 
                                         else int(x.split('-')[1]) if '-' in str(x) else None)
    
    return temp_df.set_index(CSS_processed.index.names)


def process_precomputed_css_data_with_metrics(CSS_raw):
    """Process precomputed CSS data and add rolling metrics if needed"""
    if CSS_raw.empty:
        return CSS_raw
    
    # For precomputed data, the Period and Year columns are already added during processing
    # Just return the original data since it already has the proper structure
    return CSS_raw


@cached_result(ttl_seconds=3600, key_prefix="prices_delivered_spot")
def load_delivered_spot_prices(epex):
    """Load delivered spot prices for comparison with futures"""
    logger.info("Loading delivered spot prices...")
    
    # Get spot prices for major markets - returns entire history
    delivered_data = epex.calculate_period_averages(
        country=['DE', 'FR', 'GB', 'NL', 'BE', 'AT', 'CH', 'ES', 'IT', 'HU', 'CZ', 'SK', 'SI', 'GR', 'RO', 'BG', 'HR', 'NO2', 'SE4', 'DK2', 'DK1'],
        include_spreads=True
    )
    
    # Format the data with proper columns for matching with futures
    if delivered_data is not None and not delivered_data.empty:
        # Rename main columns for consistency but keep original format
        delivered_data = delivered_data.rename(columns={
            'Value': 'DELIVERED_PRICE'
        })
            
        # Create a 'year' column from YEAR for easier matching (if not already present)
        if 'YEAR' in delivered_data.columns and 'year' not in delivered_data.columns:
            delivered_data['year'] = delivered_data['YEAR']
            
        logger.info(f"Loaded {len(delivered_data)} delivered spot price records")
        return delivered_data
    
    logger.warning("No delivered spot price data available")
    return pd.DataFrame()



@cached_result(ttl_seconds=1800, key_prefix="prices_epex_hourly")
def load_epex_hourly_spot_prices(epex):
    """Load actual EPEX hourly spot prices"""
    logger.info("Loading EPEX hourly spot prices...")
    
    try:
        # Get hourly spot prices for comprehensive spot analysis
        from datetime import datetime, timedelta
        # Use a week in the future to ensure we get all available data
        end_date = datetime.now() + timedelta(days=7)  # A week in the future
        start_date = datetime(2024, 1, 1)  # Get full year of hourly data, not just 30 days!
        
        logger.debug(f"Requesting EPEX data from {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
        
        # Get hourly spot prices - EXCLUDE GB, IT, HU, ES, CZ, SK (use BBG for these)
        hourly_spot_data = epex.get_spot_prices(
            country=['DE', 'FR', 'NL', 'BE', 'AT', 'CH', 'SI', 'GR', 'RO', 'BG', 'HR', 'NO2'],
            start_date=start_date.strftime('%Y-%m-%d'),
            end_date=end_date.strftime('%Y-%m-%d')
        )
        
        if hourly_spot_data is not None and not hourly_spot_data.empty:
            # Filter to only 60-minute resolution (exclude 30-minute data)
            if 'DELIVERY_TIME' in hourly_spot_data.columns:
                date_col = 'DELIVERY_TIME'
            elif 'TIMESTAMP' in hourly_spot_data.columns:
                date_col = 'TIMESTAMP'
            else:
                date_col = hourly_spot_data.columns[0]  # Fallback to first column
            
            # Convert to datetime and check resolution
            hourly_spot_data[date_col] = pd.to_datetime(hourly_spot_data[date_col])
            
            # Handle mixed granularity data (60 MIN old data + 15 MIN recent data)
            before_filter = len(hourly_spot_data)
            
            # Check if GRANULARITY column exists
            if 'GRANULARITY' in hourly_spot_data.columns:
                granularity_counts = hourly_spot_data['GRANULARITY'].value_counts()
                logger.debug(f"GRANULARITY breakdown: {granularity_counts.to_dict()}")
                
                # Split data by granularity
                hourly_data_60min = hourly_spot_data[hourly_spot_data['GRANULARITY'] == '60 MIN'].copy()
                sub_hourly_data = hourly_spot_data[hourly_spot_data['GRANULARITY'] != '60 MIN'].copy()
                
                logger.debug(f"60 MIN data (already hourly): {len(hourly_data_60min)} records")
                logger.debug(f"Sub-hourly data (needs resampling): {len(sub_hourly_data)} records")
                
                # Process sub-hourly data - resample to hourly by averaging
                if not sub_hourly_data.empty:
                    logger.debug(f"Resampling {len(sub_hourly_data)} sub-hourly records to hourly by averaging...")
                    
                    # Floor timestamps to hour
                    sub_hourly_data['Hour'] = sub_hourly_data[date_col].dt.floor('h')
                    
                    # Identify columns
                    country_col = 'COUNTRY' if 'COUNTRY' in sub_hourly_data.columns else 'COUNTRY_CODE'
                    price_col = 'PRICE' if 'PRICE' in sub_hourly_data.columns else 'VALUE'
                    
                    # Average across sub-hourly periods to get hourly values
                    hourly_resampled = sub_hourly_data.groupby(['Hour', country_col]).agg({
                        price_col: 'mean',
                        'VOLUME': 'sum' if 'VOLUME' in sub_hourly_data.columns else 'first'
                    }).reset_index()
                    
                    # Rename Hour back to original timestamp column
                    hourly_resampled.rename(columns={'Hour': date_col}, inplace=True)
                    hourly_resampled['GRANULARITY'] = '60 MIN (resampled)'
                    
                    # Combine 60 MIN data with resampled sub-hourly data
                    hourly_spot_data = pd.concat([hourly_data_60min, hourly_resampled], ignore_index=True)
                else:
                    hourly_spot_data = hourly_data_60min
                    
            else:
                # No GRANULARITY column, use old logic (filter to minute==0)
                logger.debug("No GRANULARITY column found, filtering to minute==0")
                hourly_spot_data = hourly_spot_data[hourly_spot_data[date_col].dt.minute == 0]
            
            after_filter = len(hourly_spot_data)
            logger.debug(f"EPEX processing: {before_filter} total records -> {after_filter} hourly records")
            
            # Debug: Show the date range of loaded data
            min_date = hourly_spot_data[date_col].min()
            max_date = hourly_spot_data[date_col].max()
            logger.info(f"Loaded {len(hourly_spot_data)} EPEX hourly spot price records (60-minute resolution only)")
            logger.debug(f"EPEX data range: {min_date} to {max_date}")
            return hourly_spot_data
            
    except Exception as e:
        logger.error(f"Error loading EPEX hourly spot prices: {e}")
    
    logger.warning("No EPEX hourly spot price data available")
    return pd.DataFrame()


@cached_result(ttl_seconds=3600, key_prefix="prices_block_avg")
def load_block_averages(epex):
    """Load block averages for base, peak, and base-peak spreads"""
    logger.info("Loading block average prices...")
    
    # Get block averages for 2020-2025 - using static dates to ensure all delivered periods are included
    block_data = epex.calculate_block_averages(
        country=['DE', 'FR', 'GB', 'IT', 'NL', 'BE', 'AT', 'CH', 'ES', 'HU', 'CZ', 'SK', 'SI', 'GR', 'RO', 'BG', 'HR', 'NO2', 'SE4', 'DK2', 'DK1'],
        start_date='2020-01-01',
        end_date='2025-12-31'
    )
    
    # Format the data for matching with futures
    if block_data is not None and not block_data.empty:
        logger.info(f"Block averages loaded - shape: {block_data.shape}")
        return block_data
    
    logger.warning("No block average data available")
    return pd.DataFrame()


@cached_result(ttl_seconds=3600, key_prefix="prices_carbon_daily")
def get_daily_carbon_prices(calculator, start_date='2019-01-01', end_date=None):
    """
    Get daily carbon prices for EUA (EU) and UKA (UK) December contracts.
    Each day shows the closing price of that year's December carbon contract.
    """
    logger.info("Loading daily carbon prices...")
    
    if end_date is None:
        end_date = datetime.now()
    
    # Convert dates to datetime
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)
    
    # Get all years we need December contracts for
    start_year = start_date.year
    end_year = end_date.year
    
    # Generate all December strips we need
    dec_strips = []
    for year in range(start_year, end_year + 1):
        year_short = year % 100
        dec_strips.append(f"Dec{year_short:02d}")
    
    # Get EUA prices
    eua_product = calculator.ice.get_product_codes()['EUA']['product_code']
    eua_df = calculator.ice.get_strip_prices(
        product=eua_product,
        strip=dec_strips,
        start_date=start_date,
        end_date=end_date
    )
    
    # Get UKA prices
    uka_product = calculator.ice.get_product_codes()['UKA']['product_code']
    uka_df = calculator.ice.get_strip_prices(
        product=uka_product,
        strip=dec_strips,
        start_date=start_date,
        end_date=end_date
    )
    
    # Process EUA data
    if not eua_df.empty:
        eua_df['YEAR'] = pd.to_datetime(eua_df['TRADE_DATE']).dt.year
        eua_df['STRIP_YEAR'] = 2000 + eua_df['STRIP'].str.extract(r'Dec(\d{2})').astype(int)
        # Keep only current year's December contract for each date
        eua_current = eua_df[eua_df['YEAR'] == eua_df['STRIP_YEAR']]
        eua_pivot = eua_current.pivot_table(
            index='TRADE_DATE',
            values='SETTLEMENT_PRICE',
            aggfunc='last'
        )
        eua_pivot.columns = ['EUA_PRICE']
    else:
        eua_pivot = pd.DataFrame()
    
    # Process UKA data
    if not uka_df.empty:
        uka_df['YEAR'] = pd.to_datetime(uka_df['TRADE_DATE']).dt.year
        uka_df['STRIP_YEAR'] = 2000 + uka_df['STRIP'].str.extract(r'Dec(\d{2})').astype(int)
        # Keep only current year's December contract for each date
        uka_current = uka_df[uka_df['YEAR'] == uka_df['STRIP_YEAR']]
        uka_pivot = uka_current.pivot_table(
            index='TRADE_DATE',
            values='SETTLEMENT_PRICE',
            aggfunc='last'
        )
        uka_pivot.columns = ['UKA_PRICE']
    else:
        uka_pivot = pd.DataFrame()
    
    # Combine EUA and UKA data
    if not eua_pivot.empty and not uka_pivot.empty:
        carbon_prices = pd.concat([eua_pivot, uka_pivot], axis=1)
    elif not eua_pivot.empty:
        carbon_prices = eua_pivot
    elif not uka_pivot.empty:
        carbon_prices = uka_pivot
    else:
        return pd.DataFrame()
    
    # Reset index to have DATE as a column
    carbon_prices = carbon_prices.reset_index()
    carbon_prices.rename(columns={'TRADE_DATE': 'DATE'}, inplace=True)
    
    # Sort by date
    carbon_prices = carbon_prices.sort_values('DATE')
    
    logger.info(f"Loaded {len(carbon_prices)} days of carbon price data")
    return carbon_prices


@cached_result(ttl_seconds=3600, key_prefix="prices_delivered_spreads")
def calculate_delivered_spreads_new(
    delivered_spot_data: pd.DataFrame,
    gas_spot_normalized: pd.DataFrame,
    co2_spot_normalized: pd.DataFrame,
    fx_data: pd.DataFrame,
    calculator
) -> pd.DataFrame:
    """
    Calculate spark spreads for delivered spot prices using new spot data classes.
    
    Args:
        delivered_spot_data: Delivered power spot prices with Period, Country, Year columns
        gas_spot_normalized: Gas spot prices from PriceGasSpot (normalized format)
        co2_spot_normalized: CO2 spot prices from PriceCO2Spot (normalized format)
        fx_data: EUR/GBP exchange rates
        calculator: FuelSpreadsCalculator instance for emissions factors
    
    Returns:
        DataFrame with CSS_MID_EFF spark spreads for delivered periods
    """
    logger.info("Calculating delivered spark spreads using new spot data classes...")
    
    # Constants
    UK_CARBON_TAX_GBP = 18.0  # UK carbon tax in GBP/tonne
    
    # Filter out country pairs - only keep single countries
    single_countries = delivered_spot_data[~delivered_spot_data['Country'].str.contains('-', na=False)].copy()
    logger.debug(f"Filtered to {len(single_countries)} single country rows from {len(delivered_spot_data)} total")
    
    if gas_spot_normalized.empty or co2_spot_normalized.empty:
        logger.error("Gas or CO2 spot data is empty - cannot calculate spreads")
        return pd.DataFrame()
    
    # Process gas spot data - convert to daily averages in EUR/MWh
    gas_daily = gas_spot_normalized.copy()
    gas_daily['valuedate'] = pd.to_datetime(gas_daily['valuedate'])
    
    # Filter for TTF (continental Europe) and NBP (UK)
    ttf_data = gas_daily[gas_daily['hub'].str.upper() == 'TTF'].copy()
    nbp_data = gas_daily[gas_daily['hub'].str.upper() == 'NBP'].copy()
    
    # Aggregate to daily (in case there are multiple entries per day)
    ttf_daily = ttf_data.groupby('valuedate')['value'].mean().reset_index()
    ttf_daily.rename(columns={'valuedate': 'DATE', 'value': 'TTF_EUR_MWh'}, inplace=True)
    
    nbp_daily = nbp_data.groupby('valuedate')['value'].mean().reset_index()
    nbp_daily.rename(columns={'valuedate': 'DATE', 'value': 'NBP_GBP_MWh'}, inplace=True)
    
    # Process CO2 spot data - convert to daily averages in EUR/tonne
    co2_daily = co2_spot_normalized.copy()
    co2_daily['valuedate'] = pd.to_datetime(co2_daily['valuedate'])
    
    # Filter for EUA (EU) and UKA (UK)
    eua_data = co2_daily[co2_daily['hub'].str.upper() == 'EUA'].copy()
    uka_data = co2_daily[co2_daily['hub'].str.upper() == 'UKA'].copy()
    
    # Aggregate to daily
    eua_daily = eua_data.groupby('valuedate')['value'].mean().reset_index()
    eua_daily.rename(columns={'valuedate': 'DATE', 'value': 'EUA_EUR_tonne'}, inplace=True)
    
    uka_daily = uka_data.groupby('valuedate')['value'].mean().reset_index()
    uka_daily.rename(columns={'valuedate': 'DATE', 'value': 'UKA_GBP_tonne'}, inplace=True)
    
    # Process FX data
    fx_daily = fx_data.copy()
    fx_daily = fx_daily.reset_index()
    
    if 'date' in fx_daily.columns:
        fx_daily['DATE'] = pd.to_datetime(fx_daily['date'])
    elif 'DATE' in fx_daily.columns:
        fx_daily['DATE'] = pd.to_datetime(fx_daily['DATE'])
    else:
        fx_daily['DATE'] = pd.to_datetime(fx_daily.index)
    
    # Find EUR/GBP column
    eurgbp_col = None
    for col in fx_daily.columns:
        if 'EURGBP' in col.upper() and 'PX_LAST' in col.upper():
            eurgbp_col = col
            break
    
    if eurgbp_col:
        fx_daily = fx_daily.rename(columns={eurgbp_col: 'EURGBP'})
    else:
        logger.error("Could not find EURGBP column in FX data")
        return pd.DataFrame()
    
    # Merge all daily data
    daily_prices = ttf_daily.merge(nbp_daily, on='DATE', how='outer')
    daily_prices = daily_prices.merge(eua_daily, on='DATE', how='outer')
    daily_prices = daily_prices.merge(uka_daily, on='DATE', how='outer')
    daily_prices = daily_prices.merge(fx_daily[['DATE', 'EURGBP']], on='DATE', how='outer')
    
    # Forward fill missing values
    daily_prices = daily_prices.sort_values('DATE').ffill()
    
    # Convert UK prices to EUR
    daily_prices['NBP_EUR_MWh'] = daily_prices['NBP_GBP_MWh'] / daily_prices['EURGBP']
    daily_prices['UKA_EUR_tonne'] = (daily_prices['UKA_GBP_tonne'] + UK_CARBON_TAX_GBP) / daily_prices['EURGBP']
    
    # Add date components for aggregation
    daily_prices['YEAR'] = daily_prices['DATE'].dt.year
    daily_prices['WEEK'] = daily_prices['DATE'].dt.isocalendar().week
    daily_prices['MONTH'] = daily_prices['DATE'].dt.month
    daily_prices['QUARTER'] = daily_prices['DATE'].dt.quarter
    
    # Aggregate to match delivered periods
    # Weekly averages
    weekly_prices = daily_prices.groupby(['YEAR', 'WEEK']).agg({
        'TTF_EUR_MWh': 'mean',
        'NBP_EUR_MWh': 'mean',
        'EUA_EUR_tonne': 'mean',
        'UKA_EUR_tonne': 'mean'
    }).reset_index()
    weekly_prices['Period'] = weekly_prices.apply(
        lambda x: f"WK{int(x['WEEK']):02d}-{int(x['YEAR'])%100:02d}", axis=1
    )
    
    # Monthly averages
    monthly_prices = daily_prices.groupby(['YEAR', 'MONTH']).agg({
        'TTF_EUR_MWh': 'mean',
        'NBP_EUR_MWh': 'mean',
        'EUA_EUR_tonne': 'mean',
        'UKA_EUR_tonne': 'mean'
    }).reset_index()
    month_map = {1: 'JAN', 2: 'FEB', 3: 'MAR', 4: 'APR', 5: 'MAY', 6: 'JUN',
                 7: 'JUL', 8: 'AUG', 9: 'SEP', 10: 'OCT', 11: 'NOV', 12: 'DEC'}
    monthly_prices['Period'] = monthly_prices.apply(
        lambda x: f"{month_map[x['MONTH']]}-{int(x['YEAR'])%100:02d}", axis=1
    )
    
    # Quarterly averages
    quarterly_prices = daily_prices.groupby(['YEAR', 'QUARTER']).agg({
        'TTF_EUR_MWh': 'mean',
        'NBP_EUR_MWh': 'mean',
        'EUA_EUR_tonne': 'mean',
        'UKA_EUR_tonne': 'mean'
    }).reset_index()
    quarterly_prices['Period'] = quarterly_prices.apply(
        lambda x: f"Q{int(x['QUARTER'])}-{int(x['YEAR'])%100:02d}", axis=1
    )
    
    # Yearly averages
    yearly_prices = daily_prices.groupby(['YEAR']).agg({
        'TTF_EUR_MWh': 'mean',
        'NBP_EUR_MWh': 'mean',
        'EUA_EUR_tonne': 'mean',
        'UKA_EUR_tonne': 'mean'
    }).reset_index()
    yearly_prices['Period'] = yearly_prices.apply(
        lambda x: f"CAL-{int(x['YEAR'])%100:02d}", axis=1
    )
    
    # Combine all period prices
    all_period_prices = pd.concat([weekly_prices, monthly_prices, quarterly_prices, yearly_prices], ignore_index=True)
    
    # Merge with delivered spot data
    spreads_data = single_countries.merge(
        all_period_prices[['Period', 'TTF_EUR_MWh', 'NBP_EUR_MWh', 'EUA_EUR_tonne', 'UKA_EUR_tonne']], 
        on='Period', 
        how='left'
    )
    
    # Vectorized CSS calculation for mid efficiency
    is_gb = spreads_data['Country'] == 'GB'
    efficiency = calculator.DEFAULT_GAS_EFFICIENCIES[1]
    emissions = calculator.GAS_EMISSIONS_FACTOR

    gas_price = np.where(is_gb, spreads_data['NBP_EUR_MWh'], spreads_data['TTF_EUR_MWh'])
    carbon_price = np.where(is_gb, spreads_data['UKA_EUR_tonne'], spreads_data['EUA_EUR_tonne'])
    power_price = spreads_data['DELIVERED_PRICE']

    fuel_cost = gas_price / efficiency
    carbon_cost = (emissions / efficiency) * carbon_price
    css = power_price - fuel_cost - carbon_cost

    # Mask rows missing any input
    valid = power_price.notna() & pd.notna(gas_price) & pd.notna(carbon_price)
    spreads_data['CSS_MID_EFF'] = np.where(valid, css, np.nan)
    
    # Keep only relevant columns
    delivered_spreads = spreads_data[['Country', 'Period', 'YEAR', 'CSS_MID_EFF']].copy()
    delivered_spreads = delivered_spreads.dropna(subset=['CSS_MID_EFF'])
    
    logger.info(f"Calculated spreads for {len(delivered_spreads)} delivered periods")
    return delivered_spreads


@cached_result(ttl_seconds=14400, key_prefix="prices_xb_spreads")
def compute_cross_border_spreads(df: pd.DataFrame) -> pd.DataFrame:
    """Compute cross-border spreads between neighboring countries"""
    df_copy = df.copy()
    
    if 'COUNTRY_CODE' in df_copy.columns:
        df_copy['COUNTRY_CODE'] = df_copy['COUNTRY_CODE'].str.upper()
    
    neighboring_countries = [
        ('DE', 'FR'), ('DE', 'NL'), ('DE', 'AT'), ('DE', 'CH'), ('DE', 'DK'),
        ('FR', 'ES'), ('FR', 'IT'), ('FR', 'BE'), ('FR', 'CH'), ('FR', 'GB'),
        ('NL', 'BE'), ('NL', 'GB'), ('NL', 'NO'),
        ('IT', 'CH'), ('IT', 'AT'), ('IT', 'SI'), 
        ('ES', 'PT'),
        ('AT', 'CH'), ('AT', 'SI'), ('AT', 'HU'),
        ('SE', 'DK'), ('SE', 'FI'), ('SE', 'NO'),
        ('GB', 'IE')
    ]
    
    available_countries = df_copy['COUNTRY_CODE'].unique()
    valid_pairs = [
        (country1, country2) for country1, country2 in neighboring_countries
        if country1 in available_countries and country2 in available_countries
    ]
    
    if not valid_pairs:
        raise ValueError("No valid neighboring country pairs found in the dataframe")
    
    all_spreads = []
    
    for country1, country2 in valid_pairs:
        df_filtered = df_copy[df_copy['COUNTRY_CODE'].isin([country1, country2])]
        
        if df_filtered['COUNTRY_CODE'].nunique() < 2:
            continue
        
        try:
            pivoted = df_filtered.pivot_table(
                index=[
                    "TRADING_DAY",
                    "PROFILE",
                    "STRIP",
                    "MATURITY",
                    "tenor",
                    "period",
                    "year"
                ],
                columns="COUNTRY_CODE",
                values=[
                    "SETTLEMENT_PRICE",
                    "OPEN_PRICE",
                    "HIGH_PRICE",
                    "LOW_PRICE",
                    "LAST_PRICE",
                    "TRADED_VOLUME",
                    "OPEN_INTEREST_VOLUME"
                ],
                aggfunc="first"
            )
            
            pivoted.columns = [
                f"{col[0]}_{col[1]}" 
                for col in pivoted.columns
            ]
            
            for metric in ["SETTLEMENT_PRICE", "OPEN_PRICE", "HIGH_PRICE", "LOW_PRICE", "LAST_PRICE"]:
                country1_col = f"{metric}_{country1}"
                country2_col = f"{metric}_{country2}"
                spread_col = f"{metric}_spread"
                
                if country1_col in pivoted.columns and country2_col in pivoted.columns:
                    pivoted[spread_col] = pivoted[country1_col] - pivoted[country2_col]
            
            result = pivoted.reset_index()
            result['DAYS_TO_DELIVERY'] = (pd.to_datetime(result['MATURITY']) - pd.to_datetime(result['TRADING_DAY'])).dt.days
            result['SPREAD_TYPE'] = f"{country1}-{country2}"
            
            all_spreads.append(result)
            
        except Exception as e:
            logger.error(f"Error processing {country1}-{country2} spread: {str(e)}")
            continue
    
    if not all_spreads:
        raise ValueError("No valid spreads could be calculated")
    
    return pd.concat(all_spreads, ignore_index=True)


def add_rolling_metrics(df, window_size=20, power_col='POWER_PRICE', gas_col='GAS_PRICE'):
    """Calculate rolling correlation and beta between power and gas prices"""
    result_df = df.copy()
    result_df['ROLLING_CORR_POWER_GAS'] = np.nan
    result_df['BETA_POWER_GAS'] = np.nan

    if power_col not in df.columns or gas_col not in df.columns:
        logger.warning(f"Required columns not found: {power_col} or {gas_col}")
        return result_df

    df_reset = df.reset_index()
    metrics_parts = []

    for (country, strip), group in df_reset.groupby(['COUNTRY', 'STRIP']):
        try:
            if len(group) < window_size:
                continue
            group = group.sort_values('DATE')
            power_series = group[power_col]
            gas_series = group[gas_col]
            if power_series.isna().all() or gas_series.isna().all():
                continue

            temp_df = pd.DataFrame({
                'DATE': group['DATE'],
                'COUNTRY': country,
                'STRIP': strip,
                'DAYS_TO_DELIVERY': group['DAYS_TO_DELIVERY'],
                'power': power_series,
                'gas': gas_series
            }).dropna()
            if len(temp_df) < window_size:
                continue

            temp_df['corr'] = temp_df['power'].rolling(window=window_size).corr(temp_df['gas'])
            rolling_var = temp_df['gas'].rolling(window=window_size).var()
            rolling_cov = temp_df['power'].rolling(window=window_size).cov(temp_df['gas'])
            temp_df['beta'] = np.where(rolling_var > 0, rolling_cov / rolling_var, np.nan)

            valid = temp_df['corr'].notna() & temp_df['beta'].notna()
            if valid.any():
                metrics_parts.append(
                    temp_df.loc[valid, ['DATE', 'COUNTRY', 'STRIP', 'DAYS_TO_DELIVERY', 'corr', 'beta']]
                )
        except Exception as e:
            logger.error(f"Error processing {country}-{strip}: {e}")

    if metrics_parts:
        all_metrics = pd.concat(metrics_parts, ignore_index=True)
        all_metrics = all_metrics.set_index(['DATE', 'COUNTRY', 'STRIP', 'DAYS_TO_DELIVERY'])
        result_df.update(all_metrics.rename(columns={'corr': 'ROLLING_CORR_POWER_GAS', 'beta': 'BETA_POWER_GAS'}))

    result_df['ROLLING_CORR_POWER_GAS'] = result_df['ROLLING_CORR_POWER_GAS'].clip(-1, 1)
    result_df['BETA_POWER_GAS'] = result_df['BETA_POWER_GAS'].clip(-10, 10)

    non_null_corr = result_df['ROLLING_CORR_POWER_GAS'].count()
    non_null_beta = result_df['BETA_POWER_GAS'].count()
    logger.debug(f"Metrics calculation complete. Non-null values: Correlation={non_null_corr}, Beta={non_null_beta}")

    return result_df


def _compact_string_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Store pure-text object columns as ``string[pyarrow]``.

    The bundle is ~2.5 GB as Python-object strings and ~1.1 GB this way.
    Arrow strings keep normal ``groupby``/assignment semantics (unlike
    ``category``, which adds unobserved groups); missing values become
    ``pd.NA`` and comparisons against them are NA, which masks treat as False.
    Columns holding dates or mixed types are left alone.
    """
    if not isinstance(df, pd.DataFrame) or df.empty:
        return df
    out = None
    for col in df.columns[df.dtypes == object]:
        values = df[col]
        non_null = values.dropna()
        if non_null.empty or not non_null.map(type).eq(str).all():
            continue
        if out is None:
            out = df.copy(deep=False)
        out[col] = values.astype("string[pyarrow]")
    return df if out is None else out


# Global flag to prevent double loading
_data_loaded = False
_cached_data = None
_load_lock = threading.Lock()

def clear_data_cache():
    """Clear the cached data to force reload"""
    global _data_loaded, _cached_data
    _data_loaded = False
    _cached_data = None
    logger.info("Data cache cleared")

def load_data():
    """Load and initialize all required data for the dashboard"""
    global _data_loaded, _cached_data

    # Fast path (no lock): already loaded
    if _data_loaded and _cached_data is not None:
        logger.debug("Using cached data (already loaded)")
        return _cached_data

    # Serialize concurrent callers — only one thread loads at a time.
    # Threads that arrive while loading is in progress block here, then
    # take the fast-path above once the loading thread releases the lock.
    _load_lock.acquire()

    # Double-check after acquiring lock (another thread may have finished)
    if _data_loaded and _cached_data is not None:
        _load_lock.release()
        logger.debug("Using cached data (loaded while waiting for lock)")
        return _cached_data

    logger.info("Initializing data...")

    # Initialize calculator and query engines
    eex = EEXQuery()
    epex = EPEXQuery()
    calculator = FuelSpreadsCalculator()

    # Get contracts
    contracts = eex.get_all_eex_contracts_for_years(7)
    
    try:
        # Load data in parallel
        with ThreadPoolExecutor(max_workers=10) as executor:
            # Submit all independent tasks - using new precomputed CSS/CDS data
            future_css_cds = executor.submit(load_precomputed_css_cds_data)
            future_power = executor.submit(load_power_data, eex, contracts)
            future_delivered = executor.submit(load_delivered_spot_prices, epex)
            future_epex_hourly = executor.submit(load_epex_hourly_spot_prices, epex)
            future_block_avg = executor.submit(load_block_averages, epex)
            
            # NEW: Load spot data from market cache classes
            future_power_spot = executor.submit(load_power_spot_data)
            future_gas_spot = executor.submit(load_gas_spot_data)
            future_co2_spot = executor.submit(load_co2_spot_data)
            future_coal_spot = executor.submit(load_coal_spot_data)
            
            future_fx = None  # FX loaded sequentially below to avoid Bloomberg threading issues
            
            FUTURE_TIMEOUT = 300  # seconds per future

            logger.info("⏳ Waiting for CSS/CDS data...")
            CSS_raw, CDS_raw = future_css_cds.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ CSS/CDS data loaded")
            
            logger.info("⏳ Waiting for Power Base/Peak/Spread data...")
            base_peak_data, xb_spread_data = future_power.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ Power Base/Peak/Spread data loaded")
            
            logger.info("⏳ Waiting for Delivered Spot data...")
            delivered_spot_data = future_delivered.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ Delivered Spot data loaded")
            
            logger.info("⏳ Waiting for EPEX Hourly Spot data...")
            epex_hourly_spot_data = future_epex_hourly.result(timeout=FUTURE_TIMEOUT) 
            logger.info("✅ EPEX Hourly Spot data loaded")
            
            logger.info("⏳ Waiting for Block Averages data...")
            block_averages_data = future_block_avg.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ Block Averages data loaded")

            logger.info("⏳ Waiting for Power Spot (Market Cache)...")
            power_spot_data, power_spot_normalized = future_power_spot.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ Power Spot (Market Cache) loaded")
            
            # Filter power_spot_normalized to reduce memory usage and processing time
            # Keep only hourly EUR data (most common use case for spot page)
            # This reduces data size from ~6.3M to ~3M rows, significantly improving performance
            if not power_spot_normalized.empty:
                original_shape = power_spot_normalized.shape
                original_size_mb = power_spot_normalized.memory_usage(deep=True).sum() / 1024**2
                
                # Filter for hourly frequency and EUR currency
                if 'frequency' in power_spot_normalized.columns and 'currency' in power_spot_normalized.columns:
                    # Use case-insensitive matching
                    freq_mask = power_spot_normalized['frequency'].str.upper() == 'H'
                    curr_mask = power_spot_normalized['currency'].str.upper() == 'EUR'
                    
                    power_spot_normalized = power_spot_normalized[freq_mask & curr_mask].copy()
                    
                    new_shape = power_spot_normalized.shape
                    new_size_mb = power_spot_normalized.memory_usage(deep=True).sum() / 1024**2
                    reduction_pct = (1 - new_shape[0] / original_shape[0]) * 100
                    
                    logger.info(f"Filtered power_spot_normalized: {original_shape[0]:,} rows -> {new_shape[0]:,} rows "
                              f"({reduction_pct:.1f}% reduction, {original_size_mb:.1f}MB -> {new_size_mb:.1f}MB)")
                    logger.info(f"  Keeping: frequency='H', currency='EUR' (for spot page optimization)")
                else:
                    logger.warning("Could not filter power_spot_normalized - missing frequency/currency columns")
                    logger.debug(f"Available columns: {list(power_spot_normalized.columns)}")
            
            logger.info("⏳ Waiting for Gas Spot (Market Cache)...")
            gas_spot_data, gas_spot_normalized = future_gas_spot.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ Gas Spot (Market Cache) loaded")
            
            logger.info("⏳ Waiting for CO2 Spot (Market Cache)...")
            co2_spot_data, co2_spot_normalized = future_co2_spot.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ CO2 Spot (Market Cache) loaded")

            logger.info("⏳ Waiting for Coal Spot (Market Cache)...")
            coal_spot_data, coal_spot_normalized = future_coal_spot.result(timeout=FUTURE_TIMEOUT)
            logger.info("✅ Coal Spot (Market Cache) loaded")
            
            # Load FX data sequentially to avoid Bloomberg threading issues
            logger.info("Loading EUR/GBP FX data (sequential)...")
            from datetime import datetime
            from jain_commods.core.interfaces.bloomberg import BBGQuery
            bbg_session = BBGQuery(p_on_server=True)

            try:
                start_date = datetime(2019, 1, 1)  # Match other data start dates
                end_date = datetime.today()
                fx_data = bbg_session.fetch_hist("EURGBP Curncy",
                                          ["PX_LAST"],
                                          start_date,
                                          end_date)
                logger.info(f"Loaded FX data - shape: {fx_data.shape}")
            finally:
                if hasattr(bbg_session, 'close') and callable(bbg_session.close):
                    bbg_session.close()
            
            # Process CSS data in parallel with other operations - no processing needed for precomputed data
            # CSS data is already processed by load_precomputed_css_dss_data
            future_css_processed = None
            
            # Calculate spreads
            base_peak_df = calculator.compute_power_base_peak_spread(base_peak_data)
            combined_spreads = compute_cross_border_spreads(xb_spread_data)
            
            # Process CSS data: compute spot from cache, load futures from database
            logger.info("Processing CSS data: computing spot from cache, loading futures from database...")
            if not CSS_raw.empty:
                try:
                    # Get futures CSS data (DAYS_TO_DELIVERY >= 2) - still from database
                    CSS_futures = CSS_raw[CSS_raw.index.get_level_values('DAYS_TO_DELIVERY') >= 2].copy()
                    logger.debug(f"CSS futures data: {len(CSS_futures)} rows")
                    
                    # Keep raw futures versions for Fuel Comparison tab
                    CSS_raw_futures = CSS_futures.copy()
                    
                    # Process futures
                    CSS_processed = process_precomputed_css_data_with_metrics(CSS_futures)
                    logger.debug(f"Processed CSS futures: {len(CSS_processed)} rows")
                except Exception as e:
                    logger.error(f"Error processing CSS futures data: {e}")
                    CSS_processed = process_precomputed_css_data_with_metrics(CSS_raw)
                    CSS_raw_futures = CSS_raw.copy()
            else:
                CSS_processed = pd.DataFrame()
                CSS_raw_futures = pd.DataFrame()
            
            # Compute CSS spot from cached gas and CO2 spot data
            logger.info("Computing CSS spot from cached gas and CO2 spot data...")
            try:
                CSS_processed_spot = compute_css_spot_from_cache(
                    power_spot_normalized,
                    gas_spot_normalized,
                    co2_spot_normalized,
                    calculator
                )
                logger.debug(f"Computed CSS spot: {len(CSS_processed_spot)} rows")
            except Exception as e:
                logger.error(f"Error computing CSS spot from cache: {e}", exc_info=True)
                CSS_processed_spot = pd.DataFrame()
            
            # Split CDS data similarly
            if not CDS_raw.empty:
                try:
                    CDS_raw_futures = CDS_raw[CDS_raw.index.get_level_values('DAYS_TO_DELIVERY') >= 2].copy()
                    logger.debug(f"CDS futures data: {len(CDS_raw_futures)} rows")
                except Exception as e:
                    logger.error(f"Error splitting CDS data: {e}")
                    CDS_raw_futures = CDS_raw.copy()
            else:
                CDS_raw_futures = pd.DataFrame()

        # Calculate delivered spreads using new spot data classes
        logger.info("Calculating delivered spreads using new spot data classes...")
        try:
            delivered_spreads = calculate_delivered_spreads_new(
                delivered_spot_data,
                gas_spot_normalized,
                co2_spot_normalized,
                fx_data,
                calculator
            )
        except Exception as e:
            logger.error(f"Error calculating delivered spreads: {e}", exc_info=True)
            delivered_spreads = pd.DataFrame()

        logger.info("Data initialization complete")
        

        # Create data dictionary to return
        result_data = {
            'CSS_raw': CSS_raw,
            'CSS_raw_futures': CSS_raw_futures,  # Raw futures only (DAYS_TO_DELIVERY >= 2) for Fuel Comparison
            'CDS_raw': CDS_raw,
            'CDS_raw_futures': CDS_raw_futures,  # Raw futures only (DAYS_TO_DELIVERY >= 2) for Fuel Comparison
            'CSS_processed': CSS_processed,  # Processed futures only (DAYS_TO_DELIVERY >= 2) for css_dss page
            'CSS_processed_spot': CSS_processed_spot,  # Processed spot only (DAYS_TO_DELIVERY == 0) for spot page
            'base_peak_df': base_peak_df,
            'combined_spreads': combined_spreads,
            'delivered_spot_data': delivered_spot_data,  # Original spot data without spreads
            'epex_hourly_spot_data': epex_hourly_spot_data,  # EPEX hourly spot prices (DE, FR, NL, BE, AT, CH, SI, GR, RO, BG, HR, NO2)
            'delivered_spreads': delivered_spreads,
            'block_averages_data': block_averages_data,
            'fx_data': fx_data,
            
            # NEW: Market cache spot data (PricePowerSpot, PriceGasSpot, PriceCO2Spot, PriceCoalSpot)
            'power_spot_data': power_spot_data,  # MultiIndex format (valuedate, zone, exchange, currency, frequency)
            'power_spot_normalized': power_spot_normalized,  # Normalized format (valuedate, zone, exchange, currency, frequency, value)
            'gas_spot_data': gas_spot_data,  # MultiIndex format (valuedate, hub, currency, energy_unit, unit)
            'gas_spot_normalized': gas_spot_normalized,  # Normalized format (valuedate, hub, currency, energy_unit, unit, value)
            'co2_spot_data': co2_spot_data,  # MultiIndex format (valuedate, hub, currency, unit)
            'co2_spot_normalized': co2_spot_normalized,  # Normalized format (valuedate, hub, currency, unit, value)
            'coal_spot_data': coal_spot_data,  # MultiIndex format (valuedate, hub, currency, energy_unit, unit)
            'coal_spot_normalized': coal_spot_normalized,  # Normalized format (valuedate, hub, currency, energy_unit, unit, value)
        }
        
        # Debug logging for market cache data
        logger.info(f"Market cache data loaded:")
        logger.info(f"  - power_spot_data: {power_spot_data.shape if not power_spot_data.empty else 'EMPTY'}")
        logger.info(f"  - power_spot_normalized: {power_spot_normalized.shape if not power_spot_normalized.empty else 'EMPTY'}")
        logger.info(f"  - gas_spot_normalized: {gas_spot_normalized.shape if not gas_spot_normalized.empty else 'EMPTY'}")
        logger.info(f"  - co2_spot_normalized: {co2_spot_normalized.shape if not co2_spot_normalized.empty else 'EMPTY'}")
        
        before = sum(v.memory_usage(deep=True).sum() for v in result_data.values()
                     if isinstance(v, pd.DataFrame))
        result_data = {k: _compact_string_columns(v) for k, v in result_data.items()}
        after = sum(v.memory_usage(deep=True).sum() for v in result_data.values()
                    if isinstance(v, pd.DataFrame))
        logger.info(f"Price bundle memory: {before / 1024**2:,.0f}MB -> {after / 1024**2:,.0f}MB "
                    f"(string columns -> pyarrow)")

        # Cache the data and set the flag
        _cached_data = result_data
        _data_loaded = True
        return result_data
    
    finally:
        # Release the load lock so other waiting threads can proceed (they'll
        # hit the fast-path and return the cached data immediately).
        _load_lock.release()
        # Properly close all connections to avoid Snowflake connection leaks
        logger.info("Closing database connections...")
        try:
            if hasattr(eex, 'close') and callable(eex.close):
                eex.close()
            if hasattr(epex, 'close') and callable(epex.close):
                epex.close()
            if hasattr(calculator, 'close') and callable(calculator.close):
                calculator.close()
            # Also close any snowflake connections directly if exposed
            for obj in [eex, epex, calculator]:
                if hasattr(obj, 'con') and hasattr(obj.con, 'close') and callable(obj.con.close):
                    obj.con.close()
        except Exception as e:
            logger.warning(f"Error while closing connections: {e}")
        logger.info("Database connections closed.")
