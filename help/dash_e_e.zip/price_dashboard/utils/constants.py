# Base metric options
BASE_METRIC_OPTIONS = [
    'CSS_MID_EFF', 'CSS_LOW_EFF', 'CSS_HI_EFF',
    'CDS_LOW_EFF', 'CDS_MID_EFF', 'CDS_HI_EFF',
    'GAS_PRICE', 'POWER_PRICE',
    'ROLLING_CORR_POWER_GAS', 'BETA_POWER_GAS'
]

# Month name to number mapping for chronological ordering
MONTH_TO_NUM = {
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
    'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
}

# Shared dark-theme Plotly layout defaults -- merge into every fig.update_layout()
DARK_LAYOUT = dict(
    template='plotly_dark',
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)',
    font_color='#e0e0e0',
    hoverlabel=dict(
        bgcolor='#22262e',
        font_color='#e0e0e0',
        font_size=12,
        bordercolor='#353a44',
    ),
    xaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
    yaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
)

# Consistent color palette for the entire app
APP_COLORS = {
    # Year colors
    'YEAR_COLORS': [
        "#1f77b4",  # Blue
        "#ff7f0e",  # Orange
        "#2ca02c",  # Green
        "#d62728",  # Red
        "#9467bd",  # Purple
        "#8c564b",  # Brown
        "#e377c2",  # Pink
        "#7f7f7f",  # Gray
        "#17becf",  # Cyan
        "#bcbd22",  # Olive
    ],
    # Base/Peak colors
    'BASE_COLOR': 'rgba(55, 128, 191, 0.7)',  # Blue
    'PEAK_COLOR': 'rgba(219, 64, 82, 0.7)',   # Red
    # CDS/CSS colors
    'CDS_COLORS': {
        'LOW': 'rgba(255, 0, 0, 0.8)',      # Light red
        'MID': 'rgba(200, 0, 0, 0.8)',      # Medium red
        'HIGH': 'rgba(150, 0, 0, 0.8)'      # Dark red
    },
    'CSS_COLORS': {
        'LOW': 'rgba(0, 0, 255, 0.8)',      # Light blue
        'MID': 'rgba(0, 0, 200, 0.8)',      # Medium blue
        'HIGH': 'rgba(0, 0, 150, 0.8)'      # Dark blue
    },
    # Time comparison colors
    'TIME_COLORS': {
        'CURRENT': 'rgb(31, 119, 180)',     # Blue
        'DAY': 'rgb(255, 127, 14)',         # Orange
        'WEEK': 'rgb(44, 160, 44)',         # Green
        'MONTH': 'rgb(214, 39, 40)'         # Red
    }
}

# Custom CSS for the application
CUSTOM_CSS = """
.control-label {
    font-weight: 500;
    margin-bottom: 5px;
    color: #445;
}

.dash-dropdown .Select-control {
    border-radius: 4px;
    border: 1px solid #ddd;
}

.dash-dropdown .Select-control:hover {
    border-color: #80bdff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

/* Custom card styling */
.control-card {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    border: none;
}

/* Custom tab styling - improved for better legibility */
.dash-tab, .nav-pills .nav-link {
    padding: 15px 20px;
    font-weight: 500;
    color: #333 !important;
    text-decoration: none;
    cursor: pointer;
}

.dash-tab--selected, .nav-pills .nav-link.active {
    border-bottom: 3px solid #333 !important;
    color: #333 !important;
    background-color: #f0f0f0 !important;
    font-weight: 600 !important;
}

/* Fix for navbar links */
.navbar .nav-link {
    color: white !important;
    cursor: pointer;
    text-decoration: none;
}

.navbar .nav-link:hover {
    text-decoration: none;
    opacity: 0.8;
}

.navbar .nav-link.active {
    font-weight: bold;
    text-decoration: underline;
}

/* Parent tabs specific styling */
#parent-tabs .nav-link.active {
    background-color: #f0f0f0 !important;
    border-bottom: 3px solid #333 !important;
}

/* Days button styling with hover and active states */
.days-button {
    margin-right: 0.5rem;
    transition: all 0.2s ease;
    font-weight: 500;
    border-radius: 4px;
    padding: 0.375rem 0.75rem;
}

.days-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.days-button.active {
    background-color: transparent !important;
    color: #333 !important;
    border-color: #333 !important;
    border-width: 2px !important;
}

/* Improve heading legibility */
h1, h2, h3, h4, h5, h6 {
    color: #333 !important;
    font-weight: 600;
}

/* Main heading styling */
.text-primary {
    color: #333 !important;
}
""" 