import os
import logging
import pathlib
import sys
import threading
from datetime import datetime

import dash
from dash import html, dcc, Input, Output
import dash_bootstrap_components as dbc

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import install_theme_css, register_health  # noqa: E402

from utils.data_loader import load_data, clear_data_cache

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Shared mutable data container -- starts empty, populated by background thread
# ---------------------------------------------------------------------------
_app_data = {}
_data_ready = threading.Event()


def _background_load():
    """Load all data in a background thread so the server starts immediately."""
    try:
        clear_data_cache()
        result = load_data()
        _app_data.update(result)
        _data_ready.set()
        logger.info("Background data load complete (%d datasets)", len(_app_data))
    except Exception:
        logger.exception("Background data load failed")
        _data_ready.set()  # unblock waiters even on failure


_loader_thread = threading.Thread(target=_background_load, daemon=True)
_loader_thread.start()

# ---------------------------------------------------------------------------
# Dash app initialisation (happens immediately -- no data dependency)
# ---------------------------------------------------------------------------
app = dash.Dash(
    __name__,
    suppress_callback_exceptions=True,
    external_stylesheets=[
        dbc.themes.BOOTSTRAP,
        dbc.icons.FONT_AWESOME,
        "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",
    ],
    title="Electricity Market Analytics Dashboard",
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)

install_theme_css(app)

if os.environ.get("DASH_DEBUG"):
    app.enable_dev_tools(
        debug=True,
        dev_tools_ui=True,
        dev_tools_props_check=True,
        dev_tools_serve_dev_bundles=True,
        dev_tools_hot_reload=True,
        dev_tools_hot_reload_interval=1000,
        dev_tools_hot_reload_watch_interval=500,
        dev_tools_hot_reload_max_retry=30,
        dev_tools_silence_routes_logging=False,
        dev_tools_prune_errors=True,
    )

app.layout = html.Div([
    dcc.Store(id='app-state', data={'days': 180}),
    dcc.Location(id='url', refresh=False),
    # Polling interval -- checks every 2 s while data is loading
    dcc.Interval(id='loading-poll', interval=2000, max_intervals=300),
    html.Div(id='page-content'),
])

# ---------------------------------------------------------------------------
# Page imports (after app init to avoid circular imports)
# ---------------------------------------------------------------------------
from pages.home import register_home_callbacks, get_layout as get_home_layout           # noqa: E402
from pages.css_dss import register_css_dss_callbacks, get_layout as get_css_dss_layout  # noqa: E402
from pages.flat_price import register_flat_price_callbacks, get_layout as get_flat_price_layout  # noqa: E402
from pages.xb_spreads import register_xb_spreads_callbacks, get_layout as get_xb_spreads_layout  # noqa: E402
from pages.base_peak import register_base_peak_callbacks, get_layout as get_base_peak_layout  # noqa: E402
from pages.spot import register_spot_callbacks, get_layout as get_spot_layout            # noqa: E402
from pages.weekly import register_weekly_callbacks, get_layout as get_weekly_layout      # noqa: E402


def _loading_splash():
    """Return a splash screen shown while data is still loading."""
    from pages.components.navbar import get_navbar
    return html.Div([
        get_navbar(active_page='home'),
        html.Div([
            dbc.Spinner(size="lg", color="primary", spinner_class_name="mb-3"),
            html.H3("Loading market data…", className="text-muted"),
            html.P("The dashboard will appear automatically once data is ready.",
                   className="text-muted", style={"fontSize": "0.85rem"}),
        ], className="loading-splash"),
    ])


# ---------------------------------------------------------------------------
# URL routing -- serves splash while data is loading, real pages after
# ---------------------------------------------------------------------------
@app.callback(
    [Output('page-content', 'children'),
     Output('loading-poll', 'disabled')],
    [Input('url', 'pathname'),
     Input('loading-poll', 'n_intervals')],
)
def display_page(pathname, _n):
    if not _data_ready.is_set():
        return _loading_splash(), False  # keep polling

    if pathname:
        if pathname.endswith('/') and pathname != '/':
            pathname = pathname[:-1]
        pathname = pathname.lower()

    routes = {
        '/css-dss': get_css_dss_layout,
        '/flat-price': get_flat_price_layout,
        '/xb-spreads': get_xb_spreads_layout,
        '/base-peak': get_base_peak_layout,
        '/spot': get_spot_layout,
        '/weekly': get_weekly_layout,
    }
    layout_fn = routes.get(pathname, get_home_layout)
    return layout_fn(_app_data), True  # disable polling once data is ready


# ---------------------------------------------------------------------------
# Register all page callbacks (they capture _app_data by reference)
# ---------------------------------------------------------------------------
register_home_callbacks(app, _app_data)
register_css_dss_callbacks(app, _app_data)
register_flat_price_callbacks(app, _app_data)
register_xb_spreads_callbacks(app, _app_data)
register_base_peak_callbacks(app, _app_data)
register_spot_callbacks(app, _app_data)
register_weekly_callbacks(app, _app_data)

# ---------------------------------------------------------------------------
# Health endpoint (shared implementation)
# ---------------------------------------------------------------------------
register_health(
    app,
    name='price',
    ready_flag=lambda: _data_ready.is_set() and bool(_app_data),
)


if __name__ == '__main__':
    # Port is read from the DASH_PORT env var so the same script works locally
    # and on the Linux server without editing code.  Fall back to 9103 to match
    # price_dashboard.sh (the legacy app.sh launcher uses 9003).
    port = int(os.environ.get('DASH_PORT', '9103'))
    host = os.environ.get('DASH_HOST', '0.0.0.0')

    if os.environ.get('DASH_PRODUCTION', '').lower() in ('1', 'true', 'yes'):
        from waitress import serve
        logging.info('Serving via waitress on %s:%s (production mode)', host, port)
        serve(app.server, host=host, port=port, threads=int(os.environ.get('DASH_THREADS', '8')))
    else:
        app.run(debug=False, host=host, port=port, use_reloader=False)
