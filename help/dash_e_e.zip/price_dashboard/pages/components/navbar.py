"""Shared navigation bar component for all dashboard pages."""
import sys
import pathlib
from datetime import datetime
from dash import html
import dash_bootstrap_components as dbc

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[3]))
from common import url_for  # noqa: E402

_data_loaded_at = None


def set_data_loaded_at(ts=None):
    """Record the timestamp when data finished loading."""
    global _data_loaded_at
    _data_loaded_at = ts or datetime.now()


def _freshness_badge():
    """Return a coloured badge showing data staleness."""
    if _data_loaded_at is None:
        return dbc.Badge("No data", color="danger",
                         className="freshness-badge ms-3 align-self-center")

    age_hours = (datetime.now() - _data_loaded_at).total_seconds() / 3600
    ts_str = _data_loaded_at.strftime("%H:%M %d-%b")

    if age_hours < 1:
        color = "success"
    elif age_hours < 4:
        color = "warning"
    else:
        color = "danger"

    return dbc.Badge(f"Data {ts_str}", color=color,
                     className="freshness-badge ms-3 align-self-center")


def get_navbar(active_page=None):
    """
    Get standardized navigation bar for all pages.

    Args:
        active_page: One of 'home', 'css-dss', 'base-peak', 'xb-spreads',
                     'flat-price', 'spot', 'weekly'
    """
    internal_items = [
        {"label": "Home",       "href": "/",           "id": "home"},
        {"label": "CSS / DSS",  "href": "/css-dss",    "id": "css-dss"},
        {"label": "Base-Peak",  "href": "/base-peak",  "id": "base-peak"},
        {"label": "XB Spreads", "href": "/xb-spreads", "id": "xb-spreads"},
        {"label": "Flat Price", "href": "/flat-price",  "id": "flat-price"},
        {"label": "Spot",       "href": "/spot",        "id": "spot"},
        {"label": "Weekly",     "href": "/weekly",      "id": "weekly"},
    ]

    external_items = [
        {"label": "Fundamentals", "href": url_for('fundamental'), "id": "fundamentals"},
        {"label": "Stack",        "href": url_for('stack'),       "id": "stack"},
        {"label": "Portal",       "href": url_for('portal'),      "id": "portal"},
    ]

    def _make_link(item):
        return dbc.NavItem(
            dbc.NavLink(
                item["label"],
                href=item["href"],
                active=(active_page == item["id"]),
                external_link=True,
            )
        )

    return dbc.Navbar(
        dbc.Container([
            html.Div([
                dbc.NavbarBrand(
                    [html.I(className="fas fa-bolt me-2"),
                     "Power Market Dashboard"],
                    href="/",
                    className="me-2",
                ),
                _freshness_badge(),
            ], className="d-flex align-items-center"),
            dbc.NavbarToggler(id="navbar-toggler"),
            dbc.Collapse(
                dbc.Nav([
                    *[_make_link(i) for i in internal_items],
                    dbc.NavItem(html.Span("|", className="nav-link",
                                          style={"opacity": "0.25", "cursor": "default"})),
                    *[_make_link(i) for i in external_items],
                ], navbar=True, className="ms-auto"),
                id="navbar-collapse",
                navbar=True,
            ),
        ], fluid=True),
        className="dashboard-navbar mb-3",
        dark=True,
    )
