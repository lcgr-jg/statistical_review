# Shared Components Guide

This directory contains reusable UI components for the price dashboard.

## Available Components

### 1. Navigation Bar (`navbar.py`)

**Usage:**
```python
from pages.components.navbar import get_navbar

# In your layout function:
layout = html.Div([
    get_navbar(active_page='css-dss'),
    # ... rest of your layout
])
```

**Parameters:**
- `active_page` (optional): One of: `'home'`, `'css-dss'`, `'base-peak'`, `'xb-spreads'`, `'flat-price'`, `'spot'`

**Features:**
- Consistent brand name: "Power Market Dashboard"
- Automatic active state highlighting
- All links use `external_link=True` for proper navigation
- Responsive Bootstrap navbar with primary color scheme

---

### 2. Days Buttons (`days_buttons.py`)

**Usage:**
```python
from pages.components.days_buttons import get_days_buttons

# In your layout function:
layout = html.Div([
    # ...
    get_days_buttons('css'),  # Prefix for button IDs
    # ...
])
```

**Parameters:**
- `button_id_prefix` (required): String prefix for button IDs (e.g., `'css'`, `'basepeak'`, `'xb'`, `'flat'`)

**Generated Button IDs:**
The function creates buttons with pattern IDs like:
```python
{"type": "{prefix}-days-button", "value": 30}
{"type": "{prefix}-days-button", "value": 60}
# ... etc
```

**Available Options:**
- 30D
- 60D  
- 90D
- 180D
- 365D
- All

**Example Callback:**
```python
@app.callback(
    Output('app-state', 'data', allow_duplicate=True),
    [Input({'type': 'css-days-button', 'value': ALL}, 'n_clicks')],
    [State('app-state', 'data'),
     State({'type': 'css-days-button', 'value': ALL}, 'id')],
    prevent_initial_call=True
)
def update_days(button_clicks, current_state, button_ids):
    ctx = callback_context
    if not ctx.triggered:
        return no_update
    
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
    new_state = dict(current_state) if current_state else {}
    
    if 'css-days-button' in trigger_id:
        button_id = eval(trigger_id)['value']
        new_state['days'] = button_id
    
    return new_state
```

---

## Best Practices

### Adding New Shared Components

When creating new shared components:

1. **Create file in this directory**: `pages/components/your_component.py`
2. **Export clear function**: Use descriptive function name like `get_your_component()`
3. **Document parameters**: Add docstring with parameter descriptions
4. **Keep it simple**: Components should be stateless and reusable
5. **Add to this README**: Document usage examples

### Importing Components

Always import from the full path:
```python
from pages.components.navbar import get_navbar
from pages.components.days_buttons import get_days_buttons
```

### Naming Conventions

- **File names**: `snake_case.py`
- **Function names**: `get_component_name()`
- **Parameters**: Descriptive, use type hints if possible

---

## Future Component Ideas

Consider extracting these common patterns:

- [ ] Shared control card layout
- [ ] Shared subplot layout helper
- [ ] Common graph configuration presets
- [ ] Reusable loading spinners
- [ ] Standard error message displays
- [ ] Shared dropdown configurations

---

## Maintenance

When modifying shared components:

1. **Test all pages**: Changes affect multiple pages
2. **Update this README**: Keep documentation current
3. **Consider backwards compatibility**: Many pages may depend on the component
4. **Communicate changes**: Let team know if behavior changes

