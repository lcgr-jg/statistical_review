from dash import html, dcc, Input, Output, State, ALL, callback_context, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
import dash
from plotly.subplots import make_subplots
import re
from utils.constants import APP_COLORS
from pages.components.navbar import get_navbar
from pages.components.days_buttons import get_days_buttons

MONTH_TO_NUM = {
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
    'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
}


def get_layout(data):
    """Get the layout for the XB Spreads page"""
    combined_spreads = data['combined_spreads']
    xb_tenors = sorted(combined_spreads['tenor'].unique())
    
    country_cols = [col for col in combined_spreads.columns 
                    if 'SETTLEMENT_PRICE_' in col and not col.endswith('_spread')]
    xb_countries = sorted([col.split('_')[-1].lower() for col in country_cols])
    
    spread_types = sorted(combined_spreads['SPREAD_TYPE'].unique())
    default_spread = 'DE-FR' if 'DE-FR' in spread_types else (spread_types[0] if spread_types else None)
    
    return html.Div([
        get_navbar(active_page='xb-spreads'),
        
        # Back button
        dbc.Button("← Back to Home", href="/", external_link=True, color="link", className="mb-3"),
        
        # Tenor tabs with better styling
        dbc.Card([
            dbc.CardHeader("Select Tenor"),
            dbc.CardBody([
                dbc.Tabs(
                    id="xb-tenor-tabs",
                    className="nav-pills",
                    children=[
                        dbc.Tab(label=tenor.capitalize(), tab_id=tenor) for tenor in xb_tenors
                    ],
                    active_tab=xb_tenors[0] if xb_tenors else None
                )
            ])
        ], className="control-card mb-4"),
        
        # Control panel
        dbc.Card([
            dbc.CardHeader("Filtering Options"),
            dbc.CardBody([
                dbc.Row([
                    # Country selection
                    dbc.Col([
                        html.Label("Select Countries:", className="control-label"),
                        dcc.Dropdown(
                            id="xb-country-dropdown",
                            options=[{"label": country.upper(), "value": country} for country in xb_countries],
                            value=[],  # No default country
                            multi=True,
                            placeholder="Select countries (optional)"
                        )
                    ], width=3),
                    
                    # Spreads selection
                    dbc.Col([
                        html.Label("Select Spreads:", className="control-label"),
                        dcc.Dropdown(
                            id="xb-spread-dropdown",
                            options=[{"label": spread, "value": spread} for spread in spread_types],
                            value=[default_spread] if default_spread else [spread_types[0]] if spread_types else [],
                            multi=True,
                            placeholder="Select spreads (optional)"
                        )
                    ], width=3),
                    
                    # Profile selector
                    dbc.Col([
                        html.Label("Profile:", className="control-label"),
                        dbc.RadioItems(
                            id="xb-profile-selector",
                            options=[
                                {"label": "Base", "value": "Base"},
                                {"label": "Peak", "value": "Peak"},
                                {"label": "Both", "value": "Both"}
                            ],
                            value="Base",
                            inline=True,
                            className="mt-2"
                        )
                    ], width=3),
                    
                    # Toggle for showing negative days
                    dbc.Col([
                        html.Label("Display Options:", className="control-label"),
                        dbc.Checklist(
                            options=[
                                {"label": "Show Past Delivery", "value": "show_negative"}
                            ],
                            value=[],
                            id="xb-display-options",
                            switch=True,
                            className="mt-2"
                        )
                    ], width=3)
                ])
            ])
        ], className="control-card mb-4"),
        
        # Days buttons
        html.Div(id='xb-days-buttons-container'),
        
        # Graph container
        dbc.Spinner(
            html.Div(id="xb-graph-container"),
            spinner_style={"width": "3rem", "height": "3rem"},
            color="primary",
            type="border"
        )
    ])

def register_xb_spreads_callbacks(app, data):
    """Register callbacks for the xb-spreads page"""
    # NOTE: data is a mutable dict populated asynchronously -- resolve keys
    # inside callbacks, not at registration time.

    def _get_combined_spreads():
        return data.get('combined_spreads', pd.DataFrame())

    def _get_delivered_spot_data():
        return data.get('delivered_spot_data', pd.DataFrame())
    
    @app.callback(
        Output('xb-days-buttons-container', 'children'),
        [Input('xb-tenor-tabs', 'active_tab')],
        [State('app-state', 'data')]
    )
    def render_xb_days_buttons(active_tab, state):
        return get_days_buttons('xb')
    
    @app.callback(
        Output('xb-graph-container', 'children'),
        [
            Input("xb-tenor-tabs", "active_tab"),
            Input("xb-spread-dropdown", "value"),
            Input("xb-country-dropdown", "value"),
            Input("xb-profile-selector", "value"),
            Input("xb-display-options", "value"),
            Input("app-state", "data")
        ]
    )
    def update_xb_container(tenor, spreads, countries, profile, display_options, state):
        # Get days limit value from state
        days_state = state.get('days', 180)  # Default to 180 if not set
        is_all_button = days_state == 'All'
        
        # Check display options
        show_negative = 'show_negative' in display_options if display_options else False
        
        # Ensure values are lists
        if spreads is None:
            # Default to 'DE-FR' if available, otherwise first spread
            combined_spreads = _get_combined_spreads()
            spread_types = sorted(combined_spreads['SPREAD_TYPE'].unique()) if not combined_spreads.empty else []
            default_spread = 'DE-FR' if 'DE-FR' in spread_types else spread_types[0] if spread_types else None
            spreads = [default_spread] if default_spread else []
        elif isinstance(spreads, str):
            spreads = [spreads]
            
        if countries is None:
            countries = []
        elif isinstance(countries, str):
            countries = [countries]
        
        # Ensure we have at least one selection
        combined_spreads = _get_combined_spreads()
        if not countries and not spreads:
            spread_types = sorted(combined_spreads['SPREAD_TYPE'].unique()) if not combined_spreads.empty else []
            if 'DE-FR' in spread_types:
                spreads = ['DE-FR']
            elif spread_types:
                spreads = [spread_types[0]]
            else:
                fig = go.Figure()
                fig.update_layout(
                    title="No Selection",
                    template='plotly_dark',
                    annotations=[dict(
                        text="Please select at least one country or spread",
                        xref="paper", yref="paper",
                        x=0.5, y=0.5, showarrow=False,
                        font=dict(size=16, color="crimson")
                    )]
                )
                return dcc.Graph(
                    id="xb-spreads-graph",
                    figure=fig,
                    style={'height': '80vh'},
                    config={'displayModeBar': True, 'scrollZoom': True}
                )
        
        # Filter data by tenor
        df = combined_spreads.copy()
        tenor_df = df[df['tenor'] == tenor]
        
        # Filter by days if not "All"
        if not is_all_button:
            tenor_df = tenor_df[tenor_df['DAYS_TO_DELIVERY'] <= days_state]
        
        # Filter out negative days if "Show Past Delivery" is not selected
        if not show_negative:
            tenor_df = tenor_df[tenor_df['DAYS_TO_DELIVERY'] >= 0]
        
        # Get unique periods and sort them chronologically
        def get_chronological_key(period):
            """
            Returns a tuple key for chronological sorting of periods.
            Lower tuple values come first in sort order.
            """
            period_lower = period.lower()
            
            # Check for month abbreviations (Jan, Feb, etc.)
            for month, num in MONTH_TO_NUM.items():
                if period_lower.startswith(month):
                    return (1, num, 0)  # (type, month_num, extra)
            
            # Check for "W" followed by numbers (week designations like W01, W02)
            week_match = re.match(r'^w(\d+)', period_lower)
            if week_match:
                week_num = int(week_match.group(1))
                return (2, week_num, 0)
            
            # Check for "Q" followed by numbers (quarters like Q1, Q2)
            quarter_match = re.match(r'^q(\d+)', period_lower)
            if quarter_match:
                quarter_num = int(quarter_match.group(1))
                return (3, quarter_num, 0)
            
            # Check for "Cal" followed by optional numbers
            cal_match = re.match(r'^cal(\d*)', period_lower)
            if cal_match:
                year_part = cal_match.group(1)
                year = int(year_part) if year_part else 0
                return (4, year, 0)
            
            # Check for month numbers (01, 02, etc.)
            if re.match(r'^\d{1,2}$', period_lower):
                try:
                    month_num = int(period_lower)
                    if 1 <= month_num <= 12:
                        return (1, month_num, 0)
                except ValueError:
                    pass
            
            # For any other format, use lexicographical ordering
            return (99, 0, period)

        periods = sorted(tenor_df['period'].unique(), key=get_chronological_key)
        n_periods = len(periods)
        
        # DYNAMIC LAYOUT BASED ON NUMBER OF PERIODS
        if len(periods) == 1:
            rows, cols = 1, 1
            plot_height = 700
        elif len(periods) == 2:
            rows, cols = 1, 2
            plot_height = 600
        elif len(periods) <= 4:
            rows, cols = 2, 2
            plot_height = 800
        elif len(periods) <= 6:
            rows, cols = 2, 3
            plot_height = 800
        else:
            cols = 3
            rows = 4
            plot_height = 1200
        
        # Create subplots with adjusted spacing
        fig = make_subplots(
            rows=rows,
            cols=cols,
            subplot_titles=periods,
            shared_yaxes=False,
            horizontal_spacing=0.06,
            vertical_spacing=0.1
        )
        
        # Color mapping for years
        years = sorted(tenor_df['year'].unique())
        custom_colors = APP_COLORS['YEAR_COLORS']
        year_to_color = {year: custom_colors[i % len(custom_colors)] for i, year in enumerate(years)}
        
        # Add traces for each period
        for idx, period in enumerate(periods):
            row = (idx // cols) + 1
            col = (idx % cols) + 1
            
            period_df = tenor_df[tenor_df['period'] == period]
            
            # Get max days_to_delivery for this period to set line length and axis range
            if not period_df.empty:
                max_days = period_df['DAYS_TO_DELIVERY'].max()
            else:
                max_days = 180  # Default if no data
                
            # Add traces for each spread
            for spread in spreads:
                spread_df = period_df[period_df['SPREAD_TYPE'] == spread]
                
                for year in years:
                    year_df = spread_df[spread_df['year'] == year].sort_values('DAYS_TO_DELIVERY', ascending=False)
                    
                    if year_df.empty:
                        continue
                    
                    # Handle profile selection
                    if profile == "Both":
                        # Add Base trace
                        base_df = year_df[year_df['PROFILE'] == 'Base']
                        if not base_df.empty:
                            fig.add_trace(
                                go.Scatter(
                                    x=base_df['DAYS_TO_DELIVERY'],
                                    y=base_df['SETTLEMENT_PRICE_spread'],
                                    mode='lines',
                                    name=f"{spread} {year} Base",
                                    line=dict(color=year_to_color[year]),
                                    legendgroup=f"{year}",
                                    showlegend=(idx == 0),
                                    hovertemplate='Year: %{text}<br>Days: %{x}<br>Spread: %{y:.2f}<extra></extra>',
                                    text=[str(year)]*len(base_df)
                                ),
                                row=row,
                                col=col
                            )
                        
                        # Add Peak trace
                        peak_df = year_df[year_df['PROFILE'] == 'Peak']
                        if not peak_df.empty:
                            fig.add_trace(
                                go.Scatter(
                                    x=peak_df['DAYS_TO_DELIVERY'],
                                    y=peak_df['SETTLEMENT_PRICE_spread'],
                                    mode='lines',
                                    name=f"{spread} {year} Peak",
                                    line=dict(color=year_to_color[year], dash='dash'),
                                    legendgroup=f"{year}",
                                    showlegend=(idx == 0),
                                    hovertemplate='Year: %{text}<br>Days: %{x}<br>Spread: %{y:.2f}<extra></extra>',
                                    text=[str(year)]*len(peak_df)
                                ),
                                row=row,
                                col=col
                            )
                    else:
                        # Single profile
                        profile_df = year_df[year_df['PROFILE'] == profile]
                        if not profile_df.empty:
                            fig.add_trace(
                                go.Scatter(
                                    x=profile_df['DAYS_TO_DELIVERY'],
                                    y=profile_df['SETTLEMENT_PRICE_spread'],
                                    mode='lines',
                                    name=f"{spread} {year} {profile}",
                                    line=dict(color=year_to_color[year]),
                                    legendgroup=f"{year}",
                                    showlegend=(idx == 0),
                                    hovertemplate='Year: %{text}<br>Days: %{x}<br>Spread: %{y:.2f}<extra></extra>',
                                    text=[str(year)]*len(profile_df)
                                ),
                                row=row,
                                col=col
                            )
            
            # Add country price traces if countries are selected
            if countries:
                for country in countries:
                    price_col = f'SETTLEMENT_PRICE_{country.upper()}'
                    if price_col in period_df.columns:
                        for year in years:
                            # Get the data and make sure it's properly filtered and sorted
                            year_df = period_df[period_df['year'] == year].copy()
                            
                            # Apply the same days filter that was applied to the entire dataset
                            if not show_negative:
                                year_df = year_df[year_df['DAYS_TO_DELIVERY'] >= 0]
                                
                            # Sort by days to delivery to ensure continuous lines
                            year_df = year_df.sort_values('DAYS_TO_DELIVERY', ascending=False)
                            
                            if year_df.empty:
                                continue
                            
                            # Handle profile selection for country prices
                            if profile == "Both":
                                # Add Base trace
                                base_df = year_df[year_df['PROFILE'] == 'Base']
                                if not base_df.empty:
                                    # Ensure there are no duplicate x values by dropping duplicates
                                    base_df = base_df.drop_duplicates('DAYS_TO_DELIVERY')
                                    fig.add_trace(
                                        go.Scatter(
                                            x=base_df['DAYS_TO_DELIVERY'],
                                            y=base_df[price_col],
                                            mode='lines',
                                            name=f"{country.upper()} {year} Base",
                                            line=dict(color=year_to_color[year], dash='dash'),
                                            legendgroup=f"{country}_{year}",  # Separate legend group for countries
                                            showlegend=(idx == 0),
                                            hovertemplate='Year: %{text}<br>Days: %{x}<br>Price: %{y:.2f}<extra></extra>',
                                            text=[str(year)]*len(base_df)
                                        ),
                                        row=row,
                                        col=col
                                    )
                                
                                # Add Peak trace
                                peak_df = year_df[year_df['PROFILE'] == 'Peak']
                                if not peak_df.empty:
                                    # Ensure there are no duplicate x values by dropping duplicates
                                    peak_df = peak_df.drop_duplicates('DAYS_TO_DELIVERY')
                                    fig.add_trace(
                                        go.Scatter(
                                            x=peak_df['DAYS_TO_DELIVERY'],
                                            y=peak_df[price_col],
                                            mode='lines',
                                            name=f"{country.upper()} {year} Peak",
                                            line=dict(color=year_to_color[year], dash='dot'),
                                            legendgroup=f"{country}_{year}",  # Separate legend group for countries
                                            showlegend=(idx == 0),
                                            hovertemplate='Year: %{text}<br>Days: %{x}<br>Price: %{y:.2f}<extra></extra>',
                                            text=[str(year)]*len(peak_df)
                                        ),
                                        row=row,
                                        col=col
                                    )
                            else:
                                # Single profile
                                profile_df = year_df[year_df['PROFILE'] == profile]
                                if not profile_df.empty:
                                    # Ensure there are no duplicate x values by dropping duplicates
                                    profile_df = profile_df.drop_duplicates('DAYS_TO_DELIVERY')
                                    fig.add_trace(
                                        go.Scatter(
                                            x=profile_df['DAYS_TO_DELIVERY'],
                                            y=profile_df[price_col],
                                            mode='lines',
                                            name=f"{country.upper()} {year} {profile}",
                                            line=dict(color=year_to_color[year], dash='dash'),
                                            legendgroup=f"{country}_{year}",  # Separate legend group for countries
                                            showlegend=(idx == 0),
                                            hovertemplate='Year: %{text}<br>Days: %{x}<br>Price: %{y:.2f}<extra></extra>',
                                            text=[str(year)]*len(profile_df)
                                        ),
                                        row=row,
                                        col=col
                                    )
            
            delivered_spot_data = _get_delivered_spot_data()
            if not delivered_spot_data.empty:
                # Get unique years from futures data for this period
                future_years = years
                
                # For countries - add delivered spot horizontal lines if selected
                if countries:
                    for country in countries:
                        for year_val in future_years:
                            spot_price = find_delivered_spot_price(delivered_spot_data, period, year_val, country, is_spread=False)
                            if spot_price is not None:
                                # Create a horizontal line as scatter trace instead of using shapes
                                fig.add_trace(
                                    go.Scatter(
                                        x=[0, max_days],  # From delivery date to max days
                                        y=[spot_price, spot_price],
                                        mode='lines',
                                        line=dict(
                                            color=year_to_color[year_val],
                                            width=2,
                                            dash="solid",
                                        ),
                                        name=f"{country.upper()} {year_val} Spot",
                                        legendgroup=f"spot_{country}_{year_val}",
                                        showlegend=False,  # Don't show in legend (we'll use a separate trace for that)
                                        hovertemplate=f"{country.upper()} {year_val} Spot: {spot_price:.2f}<extra></extra>"
                                    ),
                                    row=row,
                                    col=col
                                )
                                
                                # Add a trace for legend entry and text label
                                fig.add_trace(
                                    go.Scatter(
                                        x=[5],  # Place text near the delivery date
                                        y=[spot_price],
                                        mode='lines+text',
                                        text=[f"{country.upper()} {year_val}: {spot_price:.2f}"],
                                        textposition="middle right",
                                        textfont=dict(
                                            color=year_to_color[year_val],
                                            size=10
                                        ),
                                        line=dict(
                                            color=year_to_color[year_val],
                                            width=2,
                                            dash="solid",
                                        ),
                                        name=f"{country.upper()} {year_val} Spot",
                                        legendgroup=f"spot_{country}_{year_val}",
                                        showlegend=(idx == 0),  # Only show in first subplot
                                        hoverinfo="skip"
                                    ),
                                    row=row,
                                    col=col
                                )
                
                # For spreads - add delivered spot horizontal lines if selected
                if spreads:
                    for spread in spreads:
                        for year_val in future_years:
                            spot_price = find_delivered_spot_price(delivered_spot_data, period, year_val, spread, is_spread=True)
                            if spot_price is not None:
                                # Create a horizontal line as scatter trace instead of using shapes
                                fig.add_trace(
                                    go.Scatter(
                                        x=[0, max_days],  # From delivery date to max days
                                        y=[spot_price, spot_price],
                                        mode='lines',
                                        line=dict(
                                            color=year_to_color[year_val],
                                            width=2,
                                            dash="dot",
                                        ),
                                        name=f"{spread} {year_val} Spot",
                                        legendgroup=f"spot_{spread}_{year_val}",
                                        showlegend=False,  # Don't show in legend (we'll use a separate trace for that)
                                        hovertemplate=f"{spread} {year_val} Spot: {spot_price:.2f}<extra></extra>"
                                    ),
                                    row=row,
                                    col=col
                                )
                                
                                # Add a trace for legend entry and text label
                                fig.add_trace(
                                    go.Scatter(
                                        x=[0],  # Place text at the delivery date
                                        y=[spot_price],
                                        mode='lines+text',
                                        text=[f"{spread} {year_val}: {spot_price:.2f}"],
                                        textposition="middle right",
                                        textfont=dict(
                                            color=year_to_color[year_val],
                                            size=10
                                        ),
                                        line=dict(
                                            color=year_to_color[year_val],
                                            width=2,
                                            dash="dot",
                                        ),
                                        name=f"{spread} {year_val} Spot",
                                        legendgroup=f"spot_{spread}_{year_val}",
                                        showlegend=(idx == 0),  # Only show in first subplot
                                        hoverinfo="skip"
                                    ),
                                    row=row,
                                    col=col
                                )
        
        # Update layout
        days_display = "All" if is_all_button else str(days_state)
        profile_text = f" ({profile})" if profile != "Both" else ""
        
        # Calculate total height based on number of rows
        total_height = plot_height + 100
        
        # Update figure title to indicate it includes delivered spot prices
      
        fig.update_layout(
            hovermode='closest',
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            template='plotly_dark',
            height=total_height,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="center",
                x=0.5,
                bgcolor='rgba(34,38,46,0.95)',
                font=dict(color='#e0e0e0'),
                groupclick="togglegroup"  # This ensures clicking a legend item only toggles that specific item
            ),
            margin=dict(l=40, r=40, t=100, b=60),
            uirevision=f'xb_{tenor}_{profile}'  # Make uirevision dependent on tenor and profile
        )
        
        # Update axes for each subplot
        for i in range(1, rows + 1):
            for j in range(1, cols + 1):
                # Set x-axis range
                fig.update_xaxes(
                    title_text="Days to Delivery",
                    autorange="reversed",  # Always reverse the x-axis
                    row=i,
                    col=j
                )
                
                fig.update_yaxes(
                    title_text="Price / Spread (EUR/MWh)",
                    row=i,
                    col=j
                )
                # Add zero line for spreads
                fig.add_hline(y=0, line_dash="dash", line_color="gray", row=i, col=j)
        
        return dcc.Graph(
            id="xb-spreads-graph",
            figure=fig,
            style={'height': '80vh'},
            config={'displayModeBar': True, 'scrollZoom': True}
        )

    @app.callback(
        Output('app-state', 'data', allow_duplicate=True),
        [Input({'type': 'xb-days-button', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data'),
         State({'type': 'xb-days-button', 'value': ALL}, 'id')],
        prevent_initial_call=True
    )
    def update_xb_days_only(button_clicks, current_state, button_ids):
        ctx = callback_context
        if not ctx.triggered:
            return no_update

        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        new_state = dict(current_state) if current_state else {}

        if 'xb-days-button' in trigger_id:
            button_id = eval(trigger_id)['value']
            if button_id == 'All':
                new_state['days'] = 'All'
            else:
                new_state['days'] = int(button_id)
            
            # Immediately trigger the graph update callback
            return new_state
        
        return no_update

def find_delivered_spot_price(delivered_spot_data, period, year, entity, is_spread=False):
    """Helper function to find delivered spot price with more flexible matching
    
    Args:
        delivered_spot_data: DataFrame with delivered spot prices
        period: Period string to match (e.g. 'Jan', 'Q1', etc.)
        year: Year to match
        entity: Country code or spread to match (e.g. 'DE', 'DE-FR')
        is_spread: Whether entity is a spread (True) or country (False)
    
    Returns:
        Delivered spot price if found, None otherwise
    """
    if delivered_spot_data is None or delivered_spot_data.empty:
        return None
    
    # Normalize inputs
    period = str(period).upper().strip()
    year = int(year)
    entity = str(entity).upper().strip()
    
    # Choose the right column based on whether we're looking for a country or spread
    entity_col = 'Country-Pair' if is_spread else 'Country'
    
    # First try exact match
    match = delivered_spot_data[
        (delivered_spot_data['Period'].str.upper() == period) & 
        (delivered_spot_data['year'] == year) &
        (delivered_spot_data[entity_col] == entity)
    ]
    
    # If no match, try matching just the first part of the period (e.g. 'JAN' from 'JAN-23')
    if match.empty and '-' in period:
        period_prefix = period.split('-')[0]
        match = delivered_spot_data[
            (delivered_spot_data['Period'].str.upper().str.startswith(period_prefix)) & 
            (delivered_spot_data['year'] == year) &
            (delivered_spot_data[entity_col] == entity)
        ]
    
    # If no match with first part, try first 3 chars for month names
    if match.empty and len(period) >= 3:
        match = delivered_spot_data[
            (delivered_spot_data['Period'].str.upper().str.startswith(period[:3])) & 
            (delivered_spot_data['year'] == year) &
            (delivered_spot_data[entity_col] == entity)
        ]
    
    # Try more aggressive matching for quarter and month names
    if match.empty:
        # Check for quarters (Q1, Q2, Q3, Q4)
        if period.startswith('Q') and len(period) >= 2 and period[1].isdigit():
            quarter_num = period[1]
            match = delivered_spot_data[
                (delivered_spot_data['Period'].str.upper().str.contains(f"Q{quarter_num}")) & 
                (delivered_spot_data['year'] == year) &
                (delivered_spot_data[entity_col] == entity)
            ]
        
        # Check for month abbreviations in different formats
        elif len(period) >= 3:
            month_abbr = period[:3]
            match = delivered_spot_data[
                (delivered_spot_data['Period'].str.upper().str.contains(month_abbr)) & 
                (delivered_spot_data['year'] == year) &
                (delivered_spot_data[entity_col] == entity)
            ]
    
    # If we found a match and it has the price column, return the value
    if not match.empty and 'DELIVERED_PRICE' in match.columns:
        spot_value = float(match['DELIVERED_PRICE'].iloc[0])
        return spot_value
    
    return None 