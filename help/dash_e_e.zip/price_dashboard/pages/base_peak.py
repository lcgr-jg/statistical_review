from dash import html, dcc, Input, Output, State, ALL, callback_context, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from plotly.subplots import make_subplots
from utils.constants import APP_COLORS
import dash
from dash import callback
from datetime import datetime
import numpy as np
from pages.components.navbar import get_navbar
from pages.components.days_buttons import get_days_buttons

dash.register_page(__name__,
                   path='/base-peak',
                   title='Base-Peak Spread Dashboard',
                   name='Base-Peak Spreads')


def get_layout(data):
    """Get the layout for the Base/Peak analysis page"""
    base_peak_df = data['base_peak_df']
    block_averages_data = data['block_averages_data']
    
    return html.Div([
        get_navbar(active_page='base-peak'),
        
        # Main content
        html.Div([
            
            # Period tabs
            dbc.Card([
                dbc.CardHeader("Select Period"),
                dbc.CardBody([
                    dbc.Tabs(
                        id='basepeak-tabs',
                        className="nav-pills",
                        children=[
                            dbc.Tab(label="Months", tab_id="Months"),
                            dbc.Tab(label="Quarters", tab_id="Quarters"),
                            dbc.Tab(label="Cal", tab_id="Cal")
                        ],
                        active_tab="Quarters"
                    )
                ])
            ], className="control-card mb-4"),
            
            # Control panel
            dbc.Card([
                dbc.CardHeader("Filtering Options"),
                dbc.CardBody([
                    dbc.Row([
                        # Country selection
                        dbc.Col([
                            html.Label("Select Country:", className="control-label"),
                            dcc.Dropdown(
                                id='basepeak-country-dropdown',
                                options=[{'label': c.upper(), 'value': c.lower()} for c in ['de', 'fr', 'it', 'gb', 'nl', 'be', 'at', 'ch', 'hu', 'no2', 'se4', 'dk2', 'dk1']],
                                value='de',
                                clearable=False,
                                className="mb-3"
                            )
                        ], width=4),
                        # Display options
                        dbc.Col([
                            html.Label("Display Options:", className="control-label"),
                            dbc.Checklist(
                                options=[
                                    {"label": "Show Past Delivery", "value": "show_negative"}
                                ],
                                value=[],
                                id="basepeak-display-options",
                                switch=True,
                                className="mt-2"
                            )
                        ], width=4)
                    ])
                ])
            ], className="control-card mb-4"),
            
            get_days_buttons('basepeak'),
            
            # Graph container
            dbc.Spinner(
                html.Div(id='basepeak-graph-container'),
                spinner_style={"width": "3rem", "height": "3rem"},
                color="primary",
                type="border"
            )
        ])
    ])

def register_base_peak_callbacks(app, data):
    """Register callbacks for the Base/Peak analysis page"""

    def _get_base_peak_df():
        return data.get('base_peak_df', pd.DataFrame())

    def _get_block_averages_data():
        return data.get('block_averages_data', pd.DataFrame())
    
    @app.callback(
        Output('app-state', 'data', allow_duplicate=True),
        [Input({'type': 'basepeak-days-button', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data'),
         State({'type': 'basepeak-days-button', 'value': ALL}, 'id')],
        prevent_initial_call=True
    )
    def update_basepeak_days(button_clicks, current_state, button_ids):
        ctx = callback_context
        if not ctx.triggered:
            return no_update

        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        new_state = dict(current_state)

        if 'basepeak-days-button' in trigger_id:
            button_id = eval(trigger_id)['value']
            new_state['days'] = button_id

        return new_state
    
    @app.callback(
        Output('basepeak-graph-container', 'children'),
        [Input('basepeak-country-dropdown', 'value'),
         Input('basepeak-tabs', 'active_tab'),
         Input('basepeak-display-options', 'value'),
         Input({'type': 'basepeak-days-button', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data')]
    )
    def update_graph(country, period_tab, display_options, days_button_clicks, app_state):
        """Update the Base/Peak graph based on selected filters"""
        print("\n=== Base/Peak Graph Update Debug ===")
        print(f"Country: {country}")
        print(f"Period Tab: {period_tab}")
        
        if not country or not period_tab:
            print("Missing required parameters")
            return []
        
        # Determine days limit from app state
        days_limit = app_state.get('days', 180)  # Default to 180 if not set
        
        # Check if a button was clicked in this callback
        ctx = callback_context
        if ctx.triggered and 'basepeak-days-button' in ctx.triggered[0]['prop_id']:
            trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
            button_value = eval(trigger_id)['value']
            days_limit = button_value
            
        # Check display options
        show_negative = 'show_negative' in display_options if display_options else False
        
        try:
            df = _get_base_peak_df().copy()
            print(f"\nBase/Peak DataFrame shape: {df.shape}")
            print(f"Columns: {df.columns.tolist()}")
            
            # Filter data for the selected country
            df = df[df['COUNTRY_CODE'] == country.lower()]
            
            # Filter by days limit if not 'All'
            if days_limit != 'All':
                df = df[df['DAYS_TO_DELIVERY'] <= days_limit]
                
            # Filter out negative days if "Show Past Delivery" is not selected
            if not show_negative:
                df = df[df['DAYS_TO_DELIVERY'] >= 0]
            
            # Filter periods based on tab
            if period_tab == 'Months':
                periods = sorted([p for p in df['period'].unique() if not p.startswith(('Q', 'C'))],
                               key=lambda x: pd.to_datetime(x, format='%b').month if pd.to_datetime(x, format='%b', errors='coerce') is not pd.NaT else 0)
            elif period_tab == 'Quarters':
                periods = sorted([p for p in df['period'].unique() if p.startswith('Q')])
            elif period_tab == 'Cal':
                periods = sorted([p for p in df['period'].unique() if p.startswith('C')])
            else:
                print(f"Error: Invalid period_tab: {period_tab}")
                return []
            
            print(f"Selected periods: {periods}")
            
            if not periods:
                print("Error: No periods found for selected tab")
                return []
            
            # Calculate subplot layout
            if period_tab == 'Quarters':
                n_cols = 2  # Force 2 columns for quarters
                n_rows = 2  # Force 2 rows for quarters
                plot_height = 800
            else:
                n_cols = min(3, len(periods)) or 1
                n_rows = 4 if period_tab == 'Months' else 1
                plot_height = 1200 if period_tab == 'Months' else 700
            
            # Create figure with subplots
            fig = make_subplots(
                rows=n_rows, 
                cols=n_cols, 
                subplot_titles=periods,
                vertical_spacing=0.1,
                horizontal_spacing=0.1
            )
            
            # Create mapping of periods to subplot positions
            period_positions = {}
            for i, period in enumerate(periods):
                row = (i // n_cols) + 1
                col = (i % n_cols) + 1
                period_positions[period] = (row, col)
            
            # Get unique years
            years = sorted(df['year'].unique())
            colors = APP_COLORS['YEAR_COLORS']
            
            # Track which legend items have been added
            legend_added = set()
            
            # Get spot data once
            block_data = data.get('block_averages_data', None)
            
            # Add traces for each period
            for period in periods:
                row, col = period_positions[period]
                period_df = df[df['period'] == period]
                
                # Add traces for each year
                for i, year in enumerate(years):
                    year_data = period_df[period_df['year'] == year]
                    
                    if year_data.empty:
                        continue
                    
                    # Sort by days to delivery
                    year_data = year_data.sort_values('DAYS_TO_DELIVERY')
                    
                    # Handle legend
                    legend_key = year
                    if legend_key not in legend_added:
                        showlegend = True
                        legend_added.add(legend_key)
                    else:
                        showlegend = False
                    
                    # Add the futures line
                    fig.add_trace(
                        go.Scatter(
                            x=year_data['DAYS_TO_DELIVERY'],
                            y=year_data['SETTLEMENT_PRICE_spread'],
                            mode='lines',
                            name=str(year),
                            legendgroup=str(year),
                            showlegend=showlegend,
                            line=dict(
                                color=colors[i % len(colors)],
                                width=2
                            ),
                            hovertemplate='<b>Days to Delivery</b>: %{x}<br>' +
                                        '<b>Spread</b>: %{y:.2f}<br>' +
                                        f'<b>Year</b>: {year}<br>' +
                                        f'<b>Period</b>: {period}<extra></extra>'
                        ),
                        row=row, col=col
                    )
                    
                    block_averages_data = _get_block_averages_data()
                    if block_averages_data is not None and not block_averages_data.empty:
                        # Find matching spot data
                        # Create proper period string for lookup
                        if period.startswith('Q'):
                            lookup_period = f"{period}-{str(year)[-2:]}"  # e.g. Q1-20
                        elif period.startswith('C'):  
                            lookup_period = f"CAL-{str(year)[-2:]}"  # e.g. CAL-20
                        else:
                            # Handle months - format as MMM-YY
                            try:
                                month_name = period.upper()
                                lookup_period = f"{month_name}-{str(year)[-2:]}"  # e.g. JAN-20
                            except:
                                lookup_period = period.upper()  # Use as-is if conversion fails
                        
                        # Find matching spot data
                        spot_data = block_averages_data[
                            (block_averages_data['Metric'] == 'BASE-PEAK') & 
                            (block_averages_data['Country'] == country.upper()) & 
                            (block_averages_data['Period'] == lookup_period)
                        ]
                        
                        if not spot_data.empty:
                            try:
                                # Get delivered price value (works with both column names)
                                value_col = None
                                for col_name in ['Value', 'VALUE']:
                                    if col_name in spot_data.columns:
                                        value_col = col_name
                                        break
                                        
                                if value_col:
                                    spot_value = float(spot_data.iloc[0][value_col])
                                    
                                    # Calculate line length - match actual futures data range
                                    min_x = 0  # Start at delivery
                                    max_x = year_data['DAYS_TO_DELIVERY'].max() if not year_data.empty else 60
                                    
                                    # Create a proper legend group for this year
                                    legend_group = f"spot_{year}"
                                    
                                    # Only show legend on first subplot where this year appears
                                    # Check if we're the first subplot for this year
                                    is_first_subplot = legend_group not in legend_added
                                    
                                    fig.add_trace(
                                        go.Scatter(
                                            x=[min_x, max_x],  # Line from delivery to max futures point
                                            y=[spot_value, spot_value],
                                            mode='lines',
                                            line=dict(
                                                color=colors[i % len(colors)],  # Match the year's color
                                                width=2,
                                                dash='dot'
                                            ),
                                            name=f"{year} Delivered",
                                            legendgroup=legend_group,  # Group by year
                                            showlegend=is_first_subplot,  # Only show once per year
                                            hovertemplate=f"<b>Year:</b> {year}<br>" +
                                                         f"<b>Period:</b> {period}<br>" +
                                                         f"<b>Delivered BASE-PEAK:</b> {spot_value:.2f} EUR/MWh<extra></extra>"
                                        ),
                                        row=row, col=col
                                    )
                                    
                                    # Add to legend tracking if we showed the legend
                                    if is_first_subplot:
                                        legend_added.add(legend_group)
                            except Exception as e:
                                print(f"Error adding delivery line: {e}")
                
                # Find max days for this period to set proper axis range
                max_days = year_data['DAYS_TO_DELIVERY'].max() if not year_data.empty else 180
                
                # Configure axes - set fixed range to match data
                fig.update_xaxes(
                    title='Days to Delivery',
                    autorange="reversed",
                    gridcolor='rgba(255,255,255,0.06)',
                    range=[max_days*1.05, 0],  # Set explicit range with small padding
                    row=row, col=col
                )
                
                fig.update_yaxes(
                    title='Spread (EUR/MWh)',
                    gridcolor='rgba(255,255,255,0.06)',
                    zeroline=True,
                    zerolinecolor='gray',
                    row=row, col=col
                )
                
                # Add zero line
                fig.add_hline(y=0, line_dash="dash", line_color="gray", row=row, col=col)
            
            # Update layout
            fig.update_layout(
                height=plot_height,
                template='plotly_dark',
                hovermode='closest',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="center",
                    x=0.5,
                    bgcolor='rgba(34,38,46,0.95)',
                    font=dict(color='#e0e0e0'),
                    groupclick="togglegroup",
                ),
                margin=dict(l=40, r=40, t=120, b=60),
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                uirevision=f'basepeak_{period_tab}_{country}'  # Make uirevision dependent on tab and country
            )
            
            return dcc.Graph(
                id='basepeak-graph',
                figure=fig,
                style={'height': '80vh'},
                config={'displayModeBar': True, 'scrollZoom': True}
            )
        except Exception as e:
            print(f"Error updating graph: {str(e)}")
            print(f"Error type: {type(e)}")
            print(f"Error traceback: {e.__traceback__}")
            return []

def generate_basepeak_figure(df, tenor, countries, state):
    """Generate the base-peak figure based on selected filters and state"""
    # Get days limit value from state
    days_state = state.get('days', 180)
    is_all_button = days_state == 'All'
    
    # Ensure countries is a list
    if isinstance(countries, str):
        countries = [countries]
        
    if not countries:
        fig = go.Figure()
        fig.update_layout(
            title="No countries selected",
            template='plotly_dark',
            annotations=[dict(
                text="Please select at least one country",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=16, color="crimson")
            )]
        )
        return fig
    
    # Filter data
    filtered_df = df[(df['tenor'] == tenor) & 
                    (df['COUNTRY_CODE'].isin(countries))]
    
    if filtered_df.empty:
        fig = go.Figure()
        fig.update_layout(
            title="No data available",
            template='plotly_dark',
            annotations=[dict(
                text="No data available for the selected filters",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=16, color="crimson")
            )]
        )
        return fig
    
    # Get unique periods
    periods = sorted(filtered_df['period'].unique())
    
    # Create figure
    fig = go.Figure()
    colors = APP_COLORS['YEAR_COLORS']
    
    # Plot for each country
    for i, country in enumerate(countries):
        country_data = filtered_df[filtered_df['COUNTRY_CODE'] == country]
        
        # Get unique years for this country
        years = sorted(country_data['year'].unique())
        
        # Use a custom color palette with light purple
        custom_colors = APP_COLORS['YEAR_COLORS']
        year_to_color = {year: custom_colors[i % len(custom_colors)] for i, year in enumerate(years)}
        
        # Plot each year's data
        for year in years:
            year_data = country_data[country_data['year'] == year]
            
            if not is_all_button:
                year_data = year_data[year_data['DAYS_TO_DELIVERY'] <= days_state]
            
            if not year_data.empty:
                fig.add_trace(go.Scatter(
                    x=year_data['DAYS_TO_DELIVERY'],
                    y=year_data['SETTLEMENT_PRICE_spread'],
                    mode='lines+markers',
                    name=f"{country.upper()} {year}",
                    line=dict(
                        color=year_to_color[year],
                        width=2
                    ),
                    marker=dict(
                        size=6,
                        symbol='circle'
                    ),
                    hovertemplate='Days: %{x}<br>Spread: %{y:.2f}<extra></extra>'
                ))
    
    # Add zero line
    fig.add_hline(y=0, line_dash="dash", line_color="gray")
    
    # Update layout
    days_display = "All" if is_all_button else str(days_state)
    countries_str = ", ".join(country.upper() for country in countries)
    
    fig.update_layout(
        xaxis_title="Days to Delivery",
        yaxis_title="Base-Peak Spread (EUR/MWh)",
        template='plotly_dark',
        height=800,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="center",
            x=0.5,
            bgcolor='rgba(34,38,46,0.95)',
            font=dict(color='#e0e0e0'),
            groupclick="toggleitem"  # This ensures clicking a legend item only toggles that specific item
        ),
        margin=dict(l=40, r=40, t=100, b=60),
        xaxis=dict(
            autorange="reversed",
            gridcolor='rgba(255,255,255,0.06)'
        ),
        yaxis=dict(
            gridcolor='rgba(255,255,255,0.06)',
            zeroline=True,
            zerolinecolor='rgba(255,255,255,0.15)'
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    
    return fig 