import logging
from dash import html, dcc, Input, Output, State, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pages.components.navbar import get_navbar

logger = logging.getLogger(__name__)

PREFERRED_COUNTRY_ORDER = [
    'DE', 'FR', 'GB', 'NL', 'BE', 'AT', 'CH', 'IT', 'ES', 'HU',
    'CZ', 'SK', 'NO2', 'SE4', 'DK1', 'DK2',
]

COUNTRY_COLORS = {
    'DE': '#4dabf7', 'FR': '#ffa94d', 'GB': '#51cf66', 'NL': '#ff6b6b',
    'BE': '#cc5de8', 'AT': '#e8590c', 'CH': '#f783ac', 'IT': '#868e96',
    'ES': '#fcc419', 'HU': '#22b8cf', 'CZ': '#91a7ff', 'SK': '#ffd8a8',
    'NO2': '#8ce99a', 'SE4': '#ffa8a8', 'DK1': '#b197fc', 'DK2': '#d0bfff',
}

PEAK_HOURS_CET = list(range(8, 20))

CHART_TEMPLATE = "plotly_dark"
CHART_BG = "rgba(0,0,0,0)"
CHART_PAPER_BG = "rgba(0,0,0,0)"
CHART_GRID = "rgba(255,255,255,0.06)"


def _build_weekly_series(data):
    """Build a unified weekly price series from spot (EPEX + BBG) and futures (EEX).

    Returns a DataFrame with columns:
        ISO_YEAR, ISO_WEEK, COUNTRY, PROFILE, PRICE, SOURCE
    where SOURCE is 'spot', 'futures', or 'blend'.
    """
    today = pd.Timestamp.now().normalize()
    rows = []

    # --- Spot: aggregate hourly EPEX + BBG data into weekly base/peak ---
    epex_hourly = data.get('epex_hourly_spot_data', pd.DataFrame())
    bbg_hourly = data.get('bbg_electricity_data', pd.DataFrame())

    spot_frames = []

    if not epex_hourly.empty:
        df = epex_hourly.copy()
        date_col = 'DELIVERY_TIME' if 'DELIVERY_TIME' in df.columns else (
            'TIMESTAMP' if 'TIMESTAMP' in df.columns else df.columns[0])
        country_col = 'COUNTRY' if 'COUNTRY' in df.columns else 'COUNTRY_CODE'
        price_col = 'PRICE' if 'PRICE' in df.columns else 'VALUE'
        df['_dt'] = pd.to_datetime(df[date_col])
        df['_country'] = df[country_col].str.upper()
        df['_price'] = pd.to_numeric(df[price_col], errors='coerce')
        df['_hour'] = df['_dt'].dt.hour
        df['_weekday'] = df['_dt'].dt.weekday
        spot_frames.append(df[['_dt', '_country', '_price', '_hour', '_weekday']].dropna(subset=['_price']))

    if not bbg_hourly.empty:
        df = bbg_hourly.copy()
        df['_dt'] = pd.to_datetime(df['DeliveryTime'], utc=True).dt.tz_convert('CET').dt.tz_localize(None)
        df['_country'] = df['Country'].str.upper()
        df['_price'] = pd.to_numeric(df['Value'], errors='coerce')
        df['_hour'] = df['_dt'].dt.hour
        df['_weekday'] = df['_dt'].dt.weekday
        spot_frames.append(df[['_dt', '_country', '_price', '_hour', '_weekday']].dropna(subset=['_price']))

    if spot_frames:
        spot_all = pd.concat(spot_frames, ignore_index=True)
        spot_all['_date'] = spot_all['_dt'].dt.normalize()
        spot_all['_iso_year'] = spot_all['_dt'].dt.isocalendar().year.astype(int)
        spot_all['_iso_week'] = spot_all['_dt'].dt.isocalendar().week.astype(int)

        is_peak = (spot_all['_hour'].isin(PEAK_HOURS_CET)) & (spot_all['_weekday'] < 5)

        for profile, mask in [('Base', slice(None)), ('Peak', is_peak)]:
            subset = spot_all.loc[mask] if isinstance(mask, pd.Series) else spot_all
            weekly = (
                subset.groupby(['_iso_year', '_iso_week', '_country'])['_price']
                .mean()
                .reset_index()
            )
            weekly.columns = ['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PRICE']
            weekly['PROFILE'] = profile
            weekly['SOURCE'] = 'spot'
            rows.append(weekly)

    # --- Futures: prefer native EEX weekly contracts (WKxx-yy).
    # The default power loader goes through a hardcoded EEX_PRODUCTS whitelist
    # (in jain_commods) that does NOT include weekly product codes, so
    # ``base_peak_df`` has zero weekly rows -- everything showed up as a monthly
    # settle, causing all weeks in a given month to share one price.  We now
    # fetch weekly contracts directly (see data_loader.load_weekly_eex_contracts)
    # and only fall back to monthly spreads for the tail beyond the last
    # published weekly contract.
    current_iso = today.isocalendar()
    current_key = (int(current_iso[0]), int(current_iso[1]))
    today_week_start = today - pd.Timedelta(days=today.weekday())

    futures_rows: list[dict] = []
    weekly_covered: set[tuple] = set()
    n_weekly_contracts_used = 0
    n_monthly_contracts_used = 0

    weekly_df_raw = data.get('weekly_eex_df', pd.DataFrame())
    if not weekly_df_raw.empty:
        try:
            wdf = weekly_df_raw.copy()
            wdf['COUNTRY_CODE'] = wdf['COUNTRY_CODE'].str.upper()
            wdf['TRADING_DAY'] = pd.to_datetime(wdf['TRADING_DAY'])
            wdf['DELIVERY_START'] = pd.to_datetime(wdf['DELIVERY_START'])

            # For each (country, profile, iso_year, iso_week) pair take the
            # most recent TRADING_DAY (freshest settle).  Weekly contracts publish
            # daily up to the week's delivery -- we want the last available
            # print, not an early-in-life quote.
            wdf_forward = wdf[wdf['DELIVERY_START'] >= today_week_start].copy()

            wdf_forward = (
                wdf_forward.sort_values('TRADING_DAY')
                .drop_duplicates(
                    subset=['COUNTRY_CODE', 'PROFILE', 'ISO_YEAR', 'ISO_WEEK'],
                    keep='last',
                )
            )

            for _, row in wdf_forward.iterrows():
                price = row.get('SETTLEMENT_PRICE')
                if pd.isna(price):
                    price = row.get('LAST_PRICE')
                if pd.isna(price):
                    continue
                futures_rows.append({
                    'ISO_YEAR': int(row['ISO_YEAR']),
                    'ISO_WEEK': int(row['ISO_WEEK']),
                    'COUNTRY': row['COUNTRY_CODE'],
                    'PRICE': float(price),
                    'PROFILE': row['PROFILE'],
                    'SOURCE': 'futures',
                })
                weekly_covered.add(
                    (row['COUNTRY_CODE'], row['PROFILE'],
                     int(row['ISO_YEAR']), int(row['ISO_WEEK']))
                )
            n_weekly_contracts_used = len(wdf_forward)
        except Exception as e:
            logger.error("Failed to process weekly_eex_df: %s", e, exc_info=True)
            raise

    # --- Monthly fallback for weeks beyond the last published weekly contract ---
    eex_data = data.get('base_peak_df', pd.DataFrame())
    if not eex_data.empty:
        try:
            eex_df = eex_data.reset_index() if eex_data.index.names[0] is not None else eex_data.copy()

            has_base = 'SETTLEMENT_PRICE_base' in eex_df.columns
            has_peak = 'SETTLEMENT_PRICE_peak' in eex_df.columns
            has_maturity = 'MATURITY' in eex_df.columns
            has_trading_day = 'TRADING_DAY' in eex_df.columns
            has_country = 'COUNTRY_CODE' in eex_df.columns

            if (has_base or has_peak) and has_maturity and has_trading_day and has_country:
                eex_df['TRADING_DAY'] = pd.to_datetime(eex_df['TRADING_DAY'])
                eex_df['MATURITY'] = pd.to_datetime(eex_df['MATURITY'])
                eex_df['COUNTRY_CODE'] = eex_df['COUNTRY_CODE'].str.upper()

                latest_day = eex_df['TRADING_DAY'].max()
                latest = eex_df[eex_df['TRADING_DAY'] == latest_day].copy()
                latest = latest[latest['MATURITY'] >= today_week_start]

                profile_cols = []
                if has_base:
                    profile_cols.append(('Base', 'SETTLEMENT_PRICE_base'))
                if has_peak:
                    profile_cols.append(('Peak', 'SETTLEMENT_PRICE_peak'))

                if 'tenor' in latest.columns:
                    monthly_rows = latest[latest['tenor'].astype(str).str.lower() == 'month']
                else:
                    monthly_rows = latest

                for profile_val, price_col in profile_cols:
                    for _, row in monthly_rows.iterrows():
                        mat = row['MATURITY']
                        country = row['COUNTRY_CODE']
                        price = row[price_col]
                        if pd.isna(price) or pd.isna(mat):
                            continue
                        mat_end = mat + pd.offsets.MonthEnd(0)
                        week_starts = pd.date_range(
                            start=mat - pd.Timedelta(days=mat.weekday()),
                            end=mat_end,
                            freq='W-MON',
                        )
                        for ws in week_starts:
                            iso_cal = ws.isocalendar()
                            key = (country, profile_val, int(iso_cal[0]), int(iso_cal[1]))
                            # Skip if a native weekly contract already covers this week.
                            if key in weekly_covered:
                                continue
                            # Skip past weeks -- hourly spot is always fresher.
                            if (int(iso_cal[0]), int(iso_cal[1])) < current_key:
                                continue
                            futures_rows.append({
                                'ISO_YEAR': int(iso_cal[0]),
                                'ISO_WEEK': int(iso_cal[1]),
                                'COUNTRY': country,
                                'PRICE': float(price),
                                'PROFILE': profile_val,
                                'SOURCE': 'futures',
                            })
                            n_monthly_contracts_used += 1
            else:
                logger.warning("Weekly: base_peak_df missing expected columns. Found: %s",
                               list(eex_df.columns))
        except Exception as e:
            logger.error("Could not process EEX monthly data for weekly view: %s", e, exc_info=True)
            raise

    if futures_rows:
        futures_df = pd.DataFrame(futures_rows)
        rows.append(futures_df)
        logger.info(
            "Weekly futures built: %d rows  (%d from native WK contracts, %d from monthly spread) "
            "for countries: %s",
            len(futures_df),
            n_weekly_contracts_used,
            n_monthly_contracts_used,
            ', '.join(sorted(futures_df['COUNTRY'].unique())),
        )
    else:
        logger.warning("Weekly: no futures rows produced -- weekly_eex_df empty and base_peak_df "
                       "had no usable monthly contracts")

    if not rows:
        return pd.DataFrame(columns=['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PROFILE', 'PRICE', 'SOURCE'])

    result = pd.concat(rows, ignore_index=True)

    # Hard rule: for any week that has ANY spot observation for a country+profile,
    # use the spot value and drop the futures row.  This means delivered/partially-
    # delivered weeks are never represented by an EEX settle, which would be
    # stale by up to a day versus the hourly spot feed.
    result['_sort'] = result['SOURCE'].map({'spot': 0, 'blend': 1, 'futures': 2})
    result = result.sort_values('_sort').drop_duplicates(
        subset=['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PROFILE'], keep='first'
    ).drop(columns=['_sort'])

    # Current week is always a blend (partial delivery + implicit forward expectation)
    current_iso = today.isocalendar()
    current_mask = (result['ISO_YEAR'] == current_iso[0]) & (result['ISO_WEEK'] == current_iso[1])
    result.loc[current_mask & (result['SOURCE'] == 'spot'), 'SOURCE'] = 'blend'

    result = result.sort_values(['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PROFILE'])
    return result


def get_layout(data):
    weekly_df = _build_weekly_series(data)
    available_countries = sorted(
        weekly_df['COUNTRY'].unique(),
        key=lambda c: PREFERRED_COUNTRY_ORDER.index(c) if c in PREFERRED_COUNTRY_ORDER else 999,
    ) if not weekly_df.empty else ['DE', 'FR', 'GB']

    default_countries = [c for c in ['DE', 'FR', 'GB'] if c in available_countries]

    return html.Div([
        get_navbar(active_page='weekly'),

        dbc.Container([
            # Controls row
            dbc.Card([
                dbc.CardBody([
                    dbc.Row([
                        dbc.Col([
                            html.Label("Countries", className="control-label"),
                            dcc.Dropdown(
                                id='weekly-country-dropdown',
                                options=[{'label': c, 'value': c} for c in available_countries],
                                value=default_countries,
                                multi=True,
                                placeholder="Select countries…",
                            ),
                        ], md=5),
                        dbc.Col([
                            html.Label("Profile", className="control-label"),
                            dbc.RadioItems(
                                id='weekly-profile-selector',
                                options=[
                                    {'label': 'Base', 'value': 'Base'},
                                    {'label': 'Peak', 'value': 'Peak'},
                                ],
                                value='Base',
                                inline=True,
                                className="mt-1",
                            ),
                        ], md=3),
                        dbc.Col([
                            html.Label("Lookback", className="control-label"),
                            dbc.Select(
                                id='weekly-lookback',
                                options=[
                                    {'label': '12 wk', 'value': '12'},
                                    {'label': '26 wk', 'value': '26'},
                                    {'label': '52 wk', 'value': '52'},
                                ],
                                value='26',
                            ),
                        ], md=2),
                        dbc.Col([
                            html.Label("Forward", className="control-label"),
                            dbc.Select(
                                id='weekly-forward',
                                options=[
                                    {'label': '4 wk', 'value': '4'},
                                    {'label': '8 wk', 'value': '8'},
                                    {'label': '13 wk', 'value': '13'},
                                    {'label': '26 wk', 'value': '26'},
                                ],
                                value='13',
                            ),
                        ], md=2),
                    ], className="align-items-end"),
                ]),
            ], className="control-card mb-3"),

            # Chart
            dcc.Graph(id='weekly-chart',
                      style={'height': '72vh'},
                      config={'displayModeBar': True, 'scrollZoom': True}),

            # Export
            html.Div([
                dbc.Button(
                    [html.I(className="fas fa-download me-2"), "Export CSV"],
                    id='weekly-export-btn',
                    color="secondary",
                    outline=True,
                    size="sm",
                    className="mt-2",
                ),
            ]),
            dcc.Download(id='weekly-download'),

            dcc.Store(id='weekly-data-store',
                      data=weekly_df.to_json(date_format='iso', orient='split')),
        ], fluid=True, className="px-3"),
    ])


def register_weekly_callbacks(app, data):

    @app.callback(
        Output('weekly-chart', 'figure'),
        [Input('weekly-country-dropdown', 'value'),
         Input('weekly-profile-selector', 'value'),
         Input('weekly-lookback', 'value'),
         Input('weekly-forward', 'value')],
        [State('weekly-data-store', 'data')],
    )
    def update_weekly_chart(countries, profile, lookback_str, forward_str, json_data):
        if not countries or not json_data:
            return _empty_fig("Select at least one country")

        lookback = int(lookback_str)
        forward = int(forward_str)
        df = pd.read_json(json_data, orient='split')
        if df.empty:
            return _empty_fig("No weekly data available")

        df = df[df['PROFILE'] == profile]
        if isinstance(countries, str):
            countries = [countries]
        df = df[df['COUNTRY'].isin(countries)]

        today = pd.Timestamp.now().normalize()

        df['WEEK_START'] = df.apply(
            lambda r: datetime.strptime(f"{int(r['ISO_YEAR'])}-W{int(r['ISO_WEEK']):02d}-1", "%G-W%V-%u"),
            axis=1,
        )

        window_start = today - timedelta(weeks=lookback)
        window_end = today + timedelta(weeks=forward)
        df = df[(df['WEEK_START'] >= window_start) & (df['WEEK_START'] <= window_end)]

        if df.empty:
            return _empty_fig("No data in selected window")

        fig = go.Figure()

        for country in countries:
            cdf = df[df['COUNTRY'] == country].sort_values('WEEK_START')
            if cdf.empty:
                continue

            color = COUNTRY_COLORS.get(country, '#adb5bd')

            spot_mask = cdf['SOURCE'].isin(['spot', 'blend'])
            spot_df = cdf[spot_mask]
            fut_df = cdf[~spot_mask]

            if not spot_df.empty:
                fig.add_trace(go.Scatter(
                    x=spot_df['WEEK_START'], y=spot_df['PRICE'],
                    mode='lines+markers',
                    name=f'{country} spot',
                    line=dict(color=color, width=2.5),
                    marker=dict(size=5),
                    legendgroup=country,
                    hovertemplate=(
                        f'<b>{country}</b> spot<br>'
                        'Week: %{x|%d %b %Y}<br>'
                        'Price: %{y:.2f} EUR/MWh<extra></extra>'
                    ),
                ))

            if not fut_df.empty:
                fig.add_trace(go.Scatter(
                    x=fut_df['WEEK_START'], y=fut_df['PRICE'],
                    mode='lines+markers',
                    name=f'{country} futures',
                    line=dict(color=color, width=2, dash='dash'),
                    marker=dict(size=5, symbol='diamond'),
                    legendgroup=country,
                    hovertemplate=(
                        f'<b>{country}</b> futures<br>'
                        'Week: %{x|%d %b %Y}<br>'
                        'Price: %{y:.2f} EUR/MWh<extra></extra>'
                    ),
                ))

        fig.add_vline(
            x=today.timestamp() * 1000,
            line_dash='dot', line_color='rgba(255,255,255,0.3)',
            annotation_text='Today', annotation_font_color='rgba(255,255,255,0.5)',
            annotation_position='top',
        )

        fig.update_layout(
            title=dict(text=f'Weekly {profile} Prices — Spot vs Futures',
                       font=dict(size=15)),
            xaxis_title='Week starting',
            yaxis_title='EUR / MWh',
            template=CHART_TEMPLATE,
            plot_bgcolor=CHART_BG,
            paper_bgcolor=CHART_PAPER_BG,
            hovermode='x unified',
            hoverlabel=dict(
                bgcolor='#22262e',
                font_color='#e0e0e0',
                font_size=12,
                bordercolor='#353a44',
            ),
            legend=dict(
                orientation='h', yanchor='bottom', y=1.02,
                xanchor='center', x=0.5,
                bgcolor='rgba(34,38,46,0.95)',
                font=dict(size=11, color='#e0e0e0'),
            ),
            margin=dict(l=50, r=20, t=70, b=45),
            xaxis=dict(gridcolor=CHART_GRID, zeroline=False),
            yaxis=dict(gridcolor=CHART_GRID, zeroline=False),
        )

        return fig

    @app.callback(
        Output('weekly-download', 'data'),
        Input('weekly-export-btn', 'n_clicks'),
        [State('weekly-country-dropdown', 'value'),
         State('weekly-profile-selector', 'value'),
         State('weekly-lookback', 'value'),
         State('weekly-forward', 'value'),
         State('weekly-data-store', 'data')],
        prevent_initial_call=True,
    )
    def export_weekly_csv(n_clicks, countries, profile, lookback_str, forward_str, json_data):
        if not n_clicks or not json_data:
            return no_update

        df = pd.read_json(json_data, orient='split')
        if df.empty:
            return no_update

        df = df[df['PROFILE'] == profile]
        if countries:
            if isinstance(countries, str):
                countries = [countries]
            df = df[df['COUNTRY'].isin(countries)]

        lookback = int(lookback_str)
        forward = int(forward_str)
        today = pd.Timestamp.now().normalize()
        df['WEEK_START'] = df.apply(
            lambda r: datetime.strptime(f"{int(r['ISO_YEAR'])}-W{int(r['ISO_WEEK']):02d}-1", "%G-W%V-%u"),
            axis=1,
        )
        window_start = today - timedelta(weeks=lookback)
        window_end = today + timedelta(weeks=forward)
        df = df[(df['WEEK_START'] >= window_start) & (df['WEEK_START'] <= window_end)]

        export_cols = ['WEEK_START', 'COUNTRY', 'PROFILE', 'PRICE', 'SOURCE']
        export_df = df[[c for c in export_cols if c in df.columns]].sort_values(['WEEK_START', 'COUNTRY'])

        return dcc.send_data_frame(export_df.to_csv, f"weekly_{profile.lower()}_prices.csv", index=False)


def _empty_fig(msg):
    fig = go.Figure()
    fig.update_layout(
        title=msg,
        template=CHART_TEMPLATE,
        plot_bgcolor=CHART_BG,
        paper_bgcolor=CHART_PAPER_BG,
    )
    return fig
