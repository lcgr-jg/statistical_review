from dash import html, dcc
import dash_bootstrap_components as dbc
from pages.components.navbar import get_navbar

PAGE_CARDS = [
    {
        "title": "CSS / DSS",
        "icon": "fas fa-fire-flame-curved",
        "text": "Clean Spark & Dark Spark Spread analysis across periods and countries.",
        "href": "/css-dss",
    },
    {
        "title": "Base-Peak",
        "icon": "fas fa-chart-area",
        "text": "Compare baseload and peakload electricity prices and spreads.",
        "href": "/base-peak",
    },
    {
        "title": "XB Spreads",
        "icon": "fas fa-arrows-left-right",
        "text": "Price spreads between neighbouring electricity markets.",
        "href": "/xb-spreads",
    },
    {
        "title": "Flat Price",
        "icon": "fas fa-chart-candlestick",
        "text": "Candlestick charts, volumes and forward curves for EEX power futures.",
        "href": "/flat-price",
    },
    {
        "title": "Spot Prices",
        "icon": "fas fa-clock",
        "text": "Hourly day-ahead prices for DE, FR and neighbouring markets in CET.",
        "href": "/spot",
    },
    {
        "title": "Weekly View",
        "icon": "fas fa-calendar-week",
        "text": "Weekly delivery prices — spot for delivered weeks, futures for upcoming.",
        "href": "/weekly",
    },
]


def _make_card(card):
    return dbc.Col(
        dbc.Card(
            dbc.CardBody([
                html.Div(html.I(className=card["icon"]),
                          className="card-icon"),
                html.H6(card["title"], className="mb-2",
                         style={"fontWeight": "600", "color": "#e0e0e0"}),
                html.P(card["text"], className="mb-3",
                       style={"fontSize": "0.82rem", "lineHeight": "1.45"}),
                dbc.Button("Open", href=card["href"], external_link=True,
                           color="primary", size="sm"),
            ]),
            className="home-card h-100 control-card",
        ),
        xs=12, sm=6, lg=4, className="mb-3",
    )


def get_layout(data):
    """Get the layout for the home page."""
    return html.Div([
        get_navbar(active_page='home'),
        dbc.Container([
            html.H5("Dashboard", className="mb-1",
                     style={"fontWeight": "600"}),
            html.P("European electricity market analytics",
                   className="text-muted mb-3",
                   style={"fontSize": "0.85rem"}),
            dbc.Row([_make_card(c) for c in PAGE_CARDS]),
        ], fluid=True, className="px-3"),
    ])


def register_home_callbacks(app, data):
    pass
