from dash import html, dcc, Input, Output, State, dash_table, callback_context, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import dash
from datetime import datetime, timedelta
import pytz
from utils.constants import APP_COLORS
from pages.components.navbar import get_navbar

AUCTION_CUTOFF = (11, 55)  # day-ahead results available ~11:55 UK time

def _latest_delivery_date():
    """Return the latest delivery date whose prices should already be published.

    Day-ahead auction results for delivery day D are published on D-1.
    The cutoff is 11:55 UK time (Europe/London, i.e. GMT in winter / BST
    in summer).  Before the cutoff the latest delivery day is today;
    after the cutoff tomorrow's prices are also available.
    """
    now_uk = datetime.now(pytz.timezone('Europe/London'))
    today = now_uk.date()
    if (now_uk.hour, now_uk.minute) >= AUCTION_CUTOFF:
        return today + timedelta(days=1)
    return today


def clean_nat_values(dataframe):
    """Remove rows with NaT (Not a Time) values in DeliveryTime column"""
    if dataframe is None or dataframe.empty:
        return dataframe
    
    if 'DeliveryTime' in dataframe.columns:
        before_count = len(dataframe)
        dataframe = dataframe.dropna(subset=['DeliveryTime'])
        after_count = len(dataframe)
        
        if before_count != after_count:
            print(f"Cleaned {before_count - after_count} rows with NaT values")
    
    return dataframe

def get_ordered_countries(countries):
    """Sort countries in the specified order where possible"""
    preferred_order = ['DK1', 'DK2', 'NO2', 'DE', 'CH', 'FR', 'GB', 'NL', 'BE', 'IT', 'IT-NORTH', 'ES', 'AT', 'HU', 'CZ', 'SK', 'SI', 'GR', 'RO', 'BG', 'HR']
    available_countries = [c for c in preferred_order if c in countries]
    remaining_countries = [c for c in countries if c not in preferred_order]
    return available_countries + sorted(remaining_countries)


def extract_css_spot_data(css_processed):
    """Extract CSS spot data (0 days to delivery) and convert to spot format"""
    if css_processed.empty:
        return pd.DataFrame()
    
    try:
        print("Extracting CSS spot data...")
        
        # Reset index to access all columns
        css_reset = css_processed.reset_index()
        
        css_spot = css_reset.copy()
        
        print(f"CSS data shape: {css_spot.shape}")
        
        if css_spot.empty:
            print("No CSS data found")
            return pd.DataFrame()
        
        print(f"Found {len(css_spot)} CSS records")
        
        # Convert to spot format matching the regular spot data structure
        css_spot_converted = css_spot.copy()
        
        css_spot_only = css_spot_converted[css_spot_converted['CONTRACT_TYPE'] == 'SPOT'].copy()
        
        if css_spot_only.empty:
            print("ERROR: No CSS spot data (0 days to delivery) found!")
            return pd.DataFrame()
        
        # Use the spot-only data
        css_spot_converted = css_spot_only
        
        # FIX THE DELIVERYTIME ISSUE: Use RAW column names first
        print(f"Sample CSS data before fixing DeliveryTime (RAW COLUMNS):")
        print(css_spot_converted[['DATE', 'HOUR', 'COUNTRY']].head())
        
        # CHECK ALL HOURS IN THE CSS DATA - not just first 5 records!
        unique_hours = sorted(css_spot_converted['HOUR'].unique())
        print(f"CSS ALL HOURS IN DATASET: {unique_hours}")
        print(f"CSS TOTAL RECORDS: {len(css_spot_converted)}")
        
        # FORCE RECONSTRUCT proper hourly timestamps using RAW column names
        css_spot_converted['DeliveryTime'] = pd.to_datetime(css_spot_converted['DATE']) + pd.to_timedelta(css_spot_converted['HOUR'], unit='h')
        
        # Now map to standard column names
        css_spot_converted['Country'] = css_spot_converted['COUNTRY'] 
        css_spot_converted['Value'] = css_spot_converted['CSS_MID_EFF']
        
        # Show samples from DIFFERENT hours, not just first 3
        print(f"CSS AFTER reconstruction - samples from different hours:")
        for hour in [0, 6, 12, 18, 23]:
            hour_data = css_spot_converted[css_spot_converted['HOUR'] == hour]
            if not hour_data.empty:
                dt = hour_data.iloc[0]['DeliveryTime']
                print(f"  Hour {hour}: {dt}")
        
        # Ensure DeliveryTime is datetime with timezone - CSS data is in UTC, convert to CET
        if css_spot_converted['DeliveryTime'].dt.tz is None:
            css_spot_converted['DeliveryTime'] = css_spot_converted['DeliveryTime'].dt.tz_localize('UTC')
        # Convert to CET for consistency
        css_spot_converted['DeliveryTime'] = css_spot_converted['DeliveryTime'].dt.tz_convert('CET')
        
        
        # Add required columns for preprocessing (convert to JSON-serializable types)
        css_spot_converted['Date'] = css_spot_converted['DeliveryTime'].dt.date.astype(str)  # Convert to string immediately
        css_spot_converted['Hour'] = css_spot_converted['DeliveryTime'].dt.hour.astype(int)
        css_spot_converted['DayOfWeek'] = css_spot_converted['DeliveryTime'].dt.dayofweek.astype(int)
        css_spot_converted['IsWeekend'] = css_spot_converted['DayOfWeek'].isin([5, 6])
        css_spot_converted['IsPeak'] = css_spot_converted['Hour'].between(8, 19)
        css_spot_converted['Year'] = css_spot_converted['DeliveryTime'].dt.year.astype(int)
        css_spot_converted['Month'] = css_spot_converted['DeliveryTime'].dt.month.astype(int)
        css_spot_converted['Week'] = css_spot_converted['DeliveryTime'].dt.isocalendar().week.astype(int)
        
        # Select only the columns we need
        required_columns = ['DeliveryTime', 'Country', 'Value', 'Date', 'Hour', 'DayOfWeek', 
                          'IsWeekend', 'IsPeak', 'Year', 'Month', 'Week']
        
        css_spot_final = css_spot_converted[required_columns].copy()
        
        print(f"Converted CSS spot data shape: {css_spot_final.shape}")
        print(f"Countries in CSS data: {css_spot_final['Country'].unique()}")
        
        # Debug: Show the date range of CSS spot data
        if not css_spot_final.empty:
            min_date = css_spot_final['DeliveryTime'].min()
            max_date = css_spot_final['DeliveryTime'].max()
            print(f"CSS spot data range: {min_date} to {max_date}")
        
        return css_spot_final
        
    except Exception as e:
        print(f"Error extracting CSS spot data: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

def load_and_preprocess_all_data(app_data):
    """
    SIMPLE: Get hourly data, plot it, resample to daily if asked. No bullshit.
    """
    print("Preprocessing spot page data...")
    
    try:
        # Use EPEX hourly spot data already loaded by main app (now includes GB, IT)
        epex_hourly_spot_data = app_data.get('epex_hourly_spot_data', pd.DataFrame())
        css_processed = app_data.get('CSS_processed_spot', pd.DataFrame())  # Use pre-filtered spot CSS data
        bbg_electricity_data = app_data.get('bbg_electricity_data', pd.DataFrame())

        print(f"Using existing EPEX hourly spot data: {epex_hourly_spot_data.shape if not epex_hourly_spot_data.empty else 'Empty'}")
        print(f"Using existing CSS data: {css_processed.shape if not css_processed.empty else 'Empty'}")
        print(f"Using existing BBG hourly electricity data: {bbg_electricity_data.shape if not bbg_electricity_data.empty else 'Empty'}")
        
        # Process EPEX hourly spot data
        epex_hourly_data = pd.DataFrame()
        if not epex_hourly_spot_data.empty:
            # Map EPEX column names to standard format
            epex_data = epex_hourly_spot_data.copy()
            column_mapping = {
                'DELIVERY_TIME': 'DeliveryTime',
                'TIMESTAMP': 'DeliveryTime',
                'COUNTRY_CODE': 'Country', 
                'COUNTRY': 'Country',
                'PRICE': 'Value',
                'VALUE': 'Value'
            }
            
            for old_col, new_col in column_mapping.items():
                if old_col in epex_data.columns and new_col not in epex_data.columns:
                    epex_data.rename(columns={old_col: new_col}, inplace=True)
            
            # Extract required columns
            if all(col in epex_data.columns for col in ['DeliveryTime', 'Country', 'Value']):
                epex_hourly_data = epex_data[['DeliveryTime', 'Country', 'Value']].copy()
                epex_hourly_data['Source'] = 'EPEX'
                
                # Ensure proper datetime handling - EPEX data should be UTC, convert to CET
                epex_hourly_data['DeliveryTime'] = pd.to_datetime(epex_hourly_data['DeliveryTime'])
                if epex_hourly_data['DeliveryTime'].dt.tz is None:
                    # EPEX data is typically in UTC
                    epex_hourly_data['DeliveryTime'] = epex_hourly_data['DeliveryTime'].dt.tz_localize('UTC')
                # Convert to CET for consistency with BBG data
                epex_hourly_data['DeliveryTime'] = epex_hourly_data['DeliveryTime'].dt.tz_convert('CET')
                
                print(f"Processed {len(epex_hourly_data)} EPEX hourly spot records")
                print(f"EPEX timezone: {epex_hourly_data['DeliveryTime'].dt.tz}")
            else:
                print(f"EPEX data missing required columns. Available: {epex_data.columns.tolist()}")
        
        # Process CSS spot data
        css_spot_data = pd.DataFrame()
        if not css_processed.empty:
            css_spot_data = extract_css_spot_data(css_processed)
            if not css_spot_data.empty:
                css_spot_data['Source'] = 'CSS'
                print(f"Extracted {len(css_spot_data)} CSS hourly spot records")

        # Process BBG electricity data (N2EX, Italian PUN)
        bbg_electricity_processed = pd.DataFrame()
        if not bbg_electricity_data.empty:
            bbg_electricity_processed = bbg_electricity_data.copy()
            print(f"BBG data columns: {list(bbg_electricity_processed.columns)}")
            print(f"BBG data countries: {bbg_electricity_processed['Country'].unique() if 'Country' in bbg_electricity_processed.columns else 'No Country column'}")
            print(f"BBG data sample (first 3 rows):")
            print(bbg_electricity_processed.head(3))
            
            # Ensure proper datetime handling - BBG data should already be in CET from data_loader
            bbg_electricity_processed['DeliveryTime'] = pd.to_datetime(bbg_electricity_processed['DeliveryTime'])
            # Check if timezone-aware, if not it means old data loaded - localize to CET
            if bbg_electricity_processed['DeliveryTime'].dt.tz is None:
                print("WARNING: BBG data has no timezone, localizing to CET (should already be converted in data_loader)")
                bbg_electricity_processed['DeliveryTime'] = bbg_electricity_processed['DeliveryTime'].dt.tz_localize('CET', ambiguous='infer')
            # If timezone is present but not CET, convert to CET
            elif str(bbg_electricity_processed['DeliveryTime'].dt.tz) != 'CET':
                print(f"Converting BBG data from {bbg_electricity_processed['DeliveryTime'].dt.tz} to CET")
                bbg_electricity_processed['DeliveryTime'] = bbg_electricity_processed['DeliveryTime'].dt.tz_convert('CET')
            
            print(f"Processed {len(bbg_electricity_processed)} BBG hourly electricity records (N2EX + Italian PUN time series)")
            print(f"BBG countries after processing: {sorted(bbg_electricity_processed['Country'].unique())}")
            print(f"BBG timezone after processing: {bbg_electricity_processed['DeliveryTime'].dt.tz}")

        # Combine EPEX, CSS, and BBG electricity data
        final_hourly_data = pd.DataFrame()
        # We will keep spot prices (EPEX+BBG) separate from spark spreads (CSS)
        
        # DON'T COMBINE - KEEP SPOT PRICES AND SPARK SPREADS SEPARATE!
        
        print("\n" + "="*80)
        print("KEEPING DATASETS SEPARATE - NOT COMBINING SPOT PRICES WITH SPARK SPREADS")
        print("="*80)
        
        # Combine ONLY spot price data (EPEX + BBG)
        spot_data_sources = []
        if not epex_hourly_data.empty:
            spot_data_sources.append(epex_hourly_data)
            print(f"EPEX SPOT: {epex_hourly_data.shape[0]} records")
        if not bbg_electricity_processed.empty:
            spot_data_sources.append(bbg_electricity_processed)
            print(f"BBG SPOT: {bbg_electricity_processed.shape[0]} records")
        
        if spot_data_sources:
            final_hourly_data = pd.concat(spot_data_sources, ignore_index=True)
            print(f"COMBINED SPOT PRICES: {final_hourly_data.shape[0]} records")
        else:
            final_hourly_data = pd.DataFrame()
            print("NO SPOT PRICE DATA AVAILABLE")
        
        # Keep CSS spark spreads SEPARATE
        if not css_spot_data.empty:
            print(f"CSS SPARK SPREADS (SEPARATE): {css_spot_data.shape[0]} records")
        else:
            print("NO CSS SPARK SPREAD DATA AVAILABLE")
        
        # Sort the combined spot price data
        if not final_hourly_data.empty:
            final_hourly_data = final_hourly_data.sort_values(['DeliveryTime', 'Country'])
            print(f"SPOT PRICE SOURCES: {final_hourly_data['Source'].value_counts()}")
            print(f"SPOT PRICE COUNTRIES: {sorted(final_hourly_data['Country'].unique())}")
            print(f"SPOT PRICE SAMPLE (first 5 rows):")
            print(final_hourly_data[['DeliveryTime', 'Country', 'Value', 'Source']].head())
        
        print("="*80)
        
        final_hourly_data = clean_nat_values(final_hourly_data)
        
        print("Preprocessing all views and tables...")
        
        # PRE-CALCULATE ALL VIEWS TO AVOID SLOW CALLBACKS
        # 1. Process combined data as spot prices
        processed_data = preprocess_all_views(final_hourly_data, data_type='spot')
        
        # 2. Process CSS data separately for spark spreads view
        if not css_spot_data.empty:
            print("Preprocessing CSS data for spark spreads view...")
            css_processed = preprocess_all_views(css_spot_data, data_type='css')
            processed_data['css_data'] = css_processed
            print(f"CSS spark spreads data preprocessed: {len(css_spot_data)} records")
        
        # Add metadata about data sources
        if not final_hourly_data.empty and 'Source' in final_hourly_data.columns:
            source_counts = final_hourly_data['Source'].value_counts().to_dict()
            processed_data['data_sources'] = source_counts
            print(f"Data sources in final dataset: {source_counts}")
        
        print("Data preprocessing complete!")
        return processed_data
        
    except Exception as e:
        print(f"ERROR in load_and_preprocess_all_data: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def preprocess_all_views(spot_hourly_data, data_type='spot'):
    """Pre-calculate all views, tables, and analysis to make callbacks fast"""
    
    if spot_hourly_data is None or spot_hourly_data.empty:
        # Define the convert_df_to_json function for empty case
        def convert_df_to_json(df):
            """Convert DataFrame to JSON-serializable format"""
            if df.empty:
                return {'data': [], 'columns': []}
            return df.to_dict('records')
        
        return {
            'raw_data': convert_df_to_json(pd.DataFrame()),
            'countries': [],
            'data_loaded': False
        }
    
    # Adjust labels based on data type
    value_label = "CSS Spread (EUR/MWh)" if data_type == 'css' else "Price (EUR/MWh)"
    print(f"Verifying CET timezone for preprocessing ({data_type} data)...")
    
    # Data should already be in CET from earlier conversion, but verify
    cet_data = spot_hourly_data.copy()
    if cet_data['DeliveryTime'].dt.tz is None:
        print(f"WARNING: {data_type} data has no timezone, localizing to CET")
        cet_data['DeliveryTime'] = cet_data['DeliveryTime'].dt.tz_localize('CET', ambiguous='infer')
    elif str(cet_data['DeliveryTime'].dt.tz) != 'CET':
        print(f"Converting {data_type} data from {cet_data['DeliveryTime'].dt.tz} to CET")
        cet_data['DeliveryTime'] = cet_data['DeliveryTime'].dt.tz_convert('CET')
    else:
        print(f"{data_type} data is already in CET timezone")
    
    # Add time columns once (convert to JSON-serializable types)
    cet_data['Date'] = cet_data['DeliveryTime'].dt.date.astype(str)  # Convert to string immediately
    cet_data['Hour'] = cet_data['DeliveryTime'].dt.hour.astype(int)
    cet_data['DayOfWeek'] = cet_data['DeliveryTime'].dt.dayofweek.astype(int)
    cet_data['IsWeekend'] = cet_data['DayOfWeek'].isin([5, 6])
    cet_data['IsPeak'] = cet_data['Hour'].between(8, 19)
    cet_data['Year'] = cet_data['DeliveryTime'].dt.year.astype(int)
    cet_data['Month'] = cet_data['DeliveryTime'].dt.month.astype(int)
    cet_data['Week'] = cet_data['DeliveryTime'].dt.isocalendar().week.astype(int)
    
    countries = sorted(cet_data['Country'].unique())
    ordered_countries = get_ordered_countries(countries)
    
    print("Pre-calculating hourly tables...")
    
    # Pre-calculate hourly tables for different time ranges
    hourly_tables = {}
    delivery_days = sorted(cet_data['Date'].unique())
    
    if delivery_days:
        expected_latest = _latest_delivery_date().strftime('%Y-%m-%d')
        latest_day = expected_latest if expected_latest in delivery_days else delivery_days[-1]
        
        # Latest day hourly table
        latest_day_data = cet_data[cet_data['Date'] == latest_day].copy()
        latest_day_data['Hour'] = latest_day_data['DeliveryTime'].dt.strftime('%d-%b %H:00')
        
        if not latest_day_data.empty:
            pivoted = latest_day_data.pivot_table(
                index='Hour', columns='Country', values='Value', aggfunc='mean'
            ).reset_index()
            
            # Add average row
            avg_row = {'Hour': 'Average'}
            for col in pivoted.columns:
                if col != 'Hour':
                    avg_row[col] = pivoted[col].mean().round(2)
            
            hourly_tables['latest'] = {
                'data': pivoted.to_dict('records') + [avg_row],
                'date': pd.to_datetime(latest_day).strftime('%d-%b-%Y')
            }
    
    print("Pre-calculating daily averages...")
    
    # Pre-calculate daily averages for base/peak
    daily_base = cet_data.groupby(['Date', 'Country'])['Value'].mean().reset_index()
    daily_peak = cet_data[cet_data['IsPeak']].groupby(['Date', 'Country'])['Value'].mean().reset_index()
    
    print("Pre-calculating summary statistics...")
    
    # "Today" = latest delivery day whose auction has already run
    latest_delivery = _latest_delivery_date()
    today_cet = latest_delivery.strftime('%Y-%m-%d')
    yesterday_cet = (latest_delivery - timedelta(days=1)).strftime('%Y-%m-%d')
    
    summary_stats = {}
    for country in ordered_countries:
        country_data = cet_data[cet_data['Country'] == country]
        if country_data.empty:
            continue
        
        # Today's data
        today_data = country_data[country_data['Date'] == today_cet]
        today_avg = today_data['Value'].mean() if not today_data.empty else None
        today_peak = today_data[today_data['IsPeak']]['Value'].mean() if not today_data.empty else None
        today_offpeak = today_data[~today_data['IsPeak']]['Value'].mean() if not today_data.empty else None
        
        # Yesterday's data  
        yesterday_data = country_data[country_data['Date'] == yesterday_cet]
        yesterday_avg = yesterday_data['Value'].mean() if not yesterday_data.empty else None
        yesterday_peak = yesterday_data[yesterday_data['IsPeak']]['Value'].mean() if not yesterday_data.empty else None
        
        # 7-day average
        week_start = (pd.to_datetime(today_cet).date() - timedelta(days=6)).strftime('%Y-%m-%d')
        week_data = country_data[(country_data['Date'] >= week_start) & (country_data['Date'] <= today_cet)]
        week_avg = week_data['Value'].mean() if not week_data.empty else None
        
        summary_stats[country] = {
            'today_avg': round(today_avg, 2) if today_avg is not None else None,
            'today_peak': round(today_peak, 2) if today_peak is not None else None,
            'today_offpeak': round(today_offpeak, 2) if today_offpeak is not None else None,
            'yesterday_avg': round(yesterday_avg, 2) if yesterday_avg is not None else None,
            'yesterday_peak': round(yesterday_peak, 2) if yesterday_peak is not None else None,
            'week_avg': round(week_avg, 2) if week_avg is not None else None
        }
    
    print("Pre-calculating weekly summary...")
    
    # Pre-calculate weekly summary
    latest_data_date = pd.to_datetime(cet_data['Date'].max()).date()
    latest_week_data = cet_data[cet_data['Date'] == latest_data_date]
    if not latest_week_data.empty:
        latest_week = latest_week_data['Week'].iloc[0]
        latest_year = latest_week_data['Year'].iloc[0]
        
        # Get last 8 weeks
        weeks_to_include = []
        current_year = latest_year
        current_week = latest_week
        
        for i in range(8):
            weeks_to_include.append((current_year, current_week))
            current_week -= 1
            if current_week < 1:
                current_year -= 1
                try:
                    datetime.fromisocalendar(current_year, 53, 1)
                    current_week = 53
                except ValueError:
                    current_week = 52
        
        weekly_summary = {}
        for country in ordered_countries:
            country_data = cet_data[cet_data['Country'] == country]
            country_weekly = {'Country': country}
            
            for year, week in weeks_to_include:
                week_data = country_data[(country_data['Year'] == year) & (country_data['Week'] == week)]
                
                if not week_data.empty:
                    weekend_avg = week_data[week_data['IsWeekend']]['Value'].mean()
                    weekly_avg = week_data['Value'].mean()
                    weekday_avg = week_data[~week_data['IsWeekend']]['Value'].mean()
                    
                    week_label = f"W{week:02d}-{year}"
                    country_weekly[f"{week_label}_Weekend"] = round(weekend_avg, 2) if not pd.isna(weekend_avg) else '-'
                    country_weekly[f"{week_label}_Weekly"] = round(weekly_avg, 2) if not pd.isna(weekly_avg) else '-'
                    country_weekly[f"{week_label}_Weekday"] = round(weekday_avg, 2) if not pd.isna(weekday_avg) else '-'
                else:
                    week_label = f"W{week:02d}-{year}"
                    country_weekly[f"{week_label}_Weekend"] = '-'
                    country_weekly[f"{week_label}_Weekly"] = '-'
                    country_weekly[f"{week_label}_Weekday"] = '-'
            
            weekly_summary[country] = country_weekly
    else:
        weekly_summary = {}
    
    print("Pre-calculating heatmap data...")
    
    # Pre-calculate heatmap data for different time ranges
    heatmap_data = {}
    
    # Use same data as tables (no outlier filtering) for consistent averages
    filtered_df = cet_data.copy()
    filtered_df['DeliveryDate'] = filtered_df['Date']
    
    # Daily heatmaps for different ranges
    for days in [7, 30, 90, 180, 365]:
        daily_heatmap_data = prepare_daily_heatmap_data(filtered_df, days)
        heatmap_data[f'daily_{days}'] = daily_heatmap_data
    
    # Weekly heatmaps for different ranges  
    weekly_base_data = prepare_weekly_heatmap_data(filtered_df)
    for weeks in [4, 13, 26, 52]:
        weekly_heatmap_data = filter_weekly_data(weekly_base_data, weeks)
        heatmap_data[f'weekly_{weeks}'] = weekly_heatmap_data
    
    print("Creating time series data for graphs...")
    
    # Pre-calculate time series data for graphs (last 365 days only to keep it manageable)
    if delivery_days:
        latest_data_date = pd.to_datetime(delivery_days[-1]).date()
        recent_cutoff = latest_data_date - timedelta(days=365)
        recent_cutoff_str = recent_cutoff.strftime('%Y-%m-%d')
        recent_data = cet_data[cet_data['Date'] >= recent_cutoff_str].copy()
    else:
        recent_data = cet_data.copy()  # Use all data if no delivery days
    
    # Create daily aggregates for daily view
    daily_data = recent_data.groupby(['Date', 'Country'])['Value'].mean().reset_index()
    daily_data['DeliveryTime'] = pd.to_datetime(daily_data['Date']).dt.tz_localize('CET').dt.strftime('%Y-%m-%d %H:%M:%S')
    
    print("Preprocessing complete!")
    
    # Convert DataFrames to JSON-serializable format
    def convert_df_to_json(df):
        if df is None or df.empty:
            return []
        # Convert datetime columns to strings WITHOUT timezone info
        df_copy = df.copy()
        for col in df_copy.columns:
            col_dtype = str(df_copy[col].dtype)
            if 'datetime' in col_dtype or 'timestamp' in col_dtype:
                # Handle all datetime types - strip timezone, keep CET hours
                if hasattr(df_copy[col], 'dt'):
                    # If timezone-aware, remove tz (keeping the hours as-is in CET)
                    if df_copy[col].dt.tz is not None:
                        df_copy[col] = df_copy[col].dt.tz_localize(None)
                    df_copy[col] = df_copy[col].dt.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    dt_col = pd.to_datetime(df_copy[col])
                    if dt_col.dt.tz is not None:
                        dt_col = dt_col.dt.tz_localize(None)
                    df_copy[col] = dt_col.dt.strftime('%Y-%m-%d %H:%M:%S')
            elif col == 'DeliveryTime':
                # Special handling for DeliveryTime column - strip timezone
                dt_col = pd.to_datetime(df_copy[col])
                if dt_col.dt.tz is not None:
                    dt_col = dt_col.dt.tz_localize(None)
                df_copy[col] = dt_col.dt.strftime('%Y-%m-%d %H:%M:%S')
            elif df_copy[col].dtype == 'object' and len(df_copy) > 0:
                # Check if object column contains dates
                first_val = df_copy[col].iloc[0]
                if hasattr(first_val, 'date') or hasattr(first_val, 'strftime'):
                    df_copy[col] = df_copy[col].astype(str)
            # Convert numpy integers/floats to regular Python types
            elif 'int' in col_dtype or 'float' in col_dtype:
                df_copy[col] = df_copy[col].astype(float).round(6)  # Round to avoid precision issues
        
        # Convert to records and ensure all values are JSON serializable
        records = df_copy.to_dict('records')
        return convert_numpy_types(records)
    
    # Convert numpy types to regular Python types
    def convert_numpy_types(obj):
        if isinstance(obj, dict):
            return {k: convert_numpy_types(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_numpy_types(item) for item in obj]
        elif hasattr(obj, 'item'):  # numpy types
            return obj.item()
        else:
            return obj
    
    # Convert heatmap data
    heatmap_json = {}
    for key, df in heatmap_data.items():
        heatmap_json[key] = convert_df_to_json(df)
    
    return {
        'raw_data': convert_df_to_json(recent_data),
        'daily_data': convert_df_to_json(daily_data),
        'countries': countries,
        'ordered_countries': ordered_countries,
        'hourly_tables': convert_numpy_types(hourly_tables),
        'daily_base': convert_df_to_json(daily_base),
        'daily_peak': convert_df_to_json(daily_peak),
        'summary_stats': convert_numpy_types(summary_stats),
        'weekly_summary': convert_numpy_types(weekly_summary),
        'heatmap_data': heatmap_json,
        'data_loaded': True,
        'latest_date': latest_data_date.strftime('%Y-%m-%d') if delivery_days else datetime.now().strftime('%Y-%m-%d'),
        'data_type': data_type,
        'value_label': value_label
    }


def prepare_daily_heatmap_data(filtered_df, time_range_days):
    """Prepare data for daily heatmap visualization"""
    if time_range_days:
        latest_date = pd.to_datetime(filtered_df['DeliveryDate'].max()).date()
        start_date = latest_date - timedelta(days=time_range_days - 1)
        start_date_str = start_date.strftime('%Y-%m-%d')
        filtered_df = filtered_df[filtered_df['DeliveryDate'] >= start_date_str]
    
    return filtered_df.groupby(['DeliveryDate', 'Country'])['Value'].mean().reset_index()

def prepare_weekly_heatmap_data(filtered_df):
    """Prepare base data for weekly heatmap visualization"""
    weekly_avg = filtered_df.groupby(['Year', 'Week', 'Country'])['Value'].mean().reset_index()
    
    # Handle invalid weeks (not all years have week 53)
    def safe_isocalendar(year, week):
        try:
            return datetime.fromisocalendar(int(year), int(week), 1)
        except ValueError:
            # If week 53 doesn't exist for this year, use week 52
            return datetime.fromisocalendar(int(year), 52, 1)
    
    weekly_avg['DateSort'] = weekly_avg.apply(
        lambda x: safe_isocalendar(x['Year'], x['Week']), axis=1
    )
    return weekly_avg

def filter_weekly_data(weekly_data, time_range_weeks):
    """Filter weekly data for specific time range"""
    if time_range_weeks and not weekly_data.empty:
        latest_week = weekly_data['DateSort'].max()
        start_week = latest_week - timedelta(weeks=time_range_weeks - 1)
        return weekly_data[weekly_data['DateSort'] >= start_week]
    return weekly_data

def create_fast_graph(processed_data, countries, resampling, time_range_days, data_label="Spot Prices"):
    """Create spot price graph using pre-processed data"""
    
    if not processed_data or not processed_data.get('data_loaded'):
        return html.Div([html.H4(f"No {data_label.lower()} data available", className="text-center text-muted my-5")])
    
    # Set defaults
    if not countries:
        countries = ['DE', 'FR']
    
    # Convert JSON data back to DataFrames
    if resampling == 'daily':
        if not processed_data['daily_data']:
            return html.Div([html.H4("No daily data available", className="text-center text-muted my-5")])
        display_data = pd.DataFrame(processed_data['daily_data'])
        display_data['DeliveryTime'] = pd.to_datetime(display_data['DeliveryTime'])
        # Ensure chronological sorting to prevent line crossing
        display_data = display_data.sort_values(['DeliveryTime', 'Country'])
    else:
        if not processed_data['raw_data']:
            return html.Div([html.H4("No hourly data available", className="text-center text-muted my-5")])
        display_data = pd.DataFrame(processed_data['raw_data'])
        display_data['DeliveryTime'] = pd.to_datetime(display_data['DeliveryTime'])
        # Ensure chronological sorting to prevent line crossing
        display_data = display_data.sort_values(['DeliveryTime', 'Country'])
    
    # Filter by countries
    display_data = display_data[display_data['Country'].isin(countries)]
    
    if display_data.empty:
        return html.Div([html.H4("No data available for selected countries", className="text-center text-muted my-5")])
    
    # Filter by time range
    latest_date_str = processed_data['latest_date']
    latest_date = pd.to_datetime(latest_date_str).date()
    start_date = latest_date - timedelta(days=time_range_days - 1)
    start_date_str = start_date.strftime('%Y-%m-%d')
    
    # Compare string dates to string dates
    if resampling == 'daily':
        display_data = display_data[display_data['Date'] >= start_date_str]
    else:
        display_data = display_data[display_data['Date'] >= start_date_str]
    
    if display_data.empty:
        return html.Div([html.H4("No data available for selected time range", className="text-center text-muted my-5")])
    
    # Set appropriate units and title based on data type (BEFORE creating traces)
    if "CSS" in data_label or "Spark" in data_label:
        y_label = "CSS Spread (EUR/MWh)"
        hover_suffix = " EUR/MWh CSS"
        title_prefix = "CSS Spark Spreads"
    else:
        y_label = "Price (EUR/MWh)"
        hover_suffix = " EUR/MWh"
        title_prefix = "Spot Prices"

    # Create figure
    fig = go.Figure()
    
    # Add weekend background shading (simplified for performance)
    if time_range_days <= 30:  # Only add shading for shorter time ranges
        current_date = start_date
        while current_date <= latest_date:
            if current_date.weekday() in [5, 6]:  # Weekend
                weekend_start = pd.Timestamp(current_date).tz_localize('CET')
                weekend_end = weekend_start + pd.Timedelta(days=1)
                
                fig.add_vrect(
                    x0=weekend_start, x1=weekend_end,
                    fillcolor="rgba(128, 128, 128, 0.1)",
                    layer="below", line_width=0,
                )
            current_date += timedelta(days=1)
    
    # Add traces for each country
    for country in countries:
        country_data = display_data[display_data['Country'] == country].sort_values('DeliveryTime')
        
        if not country_data.empty:
            fig.add_trace(go.Scatter(
                x=country_data['DeliveryTime'],
                y=country_data['Value'],
                mode='lines',
                name=country,
                line=dict(width=2.5, shape='hv'),  # Step-wise plot (horizontal-vertical)
                hovertemplate=f"{country}: %{{y:.2f}}{hover_suffix}<br>%{{x}}<extra></extra>"
            ))
    
    # Configure layout
    time_label = {
        1: "Latest Delivery Day", 3: "3 Delivery Days", 7: "7 Delivery Days", 
        30: "30 Delivery Days", 180: "6 Months", 365: "1 Year"
    }.get(time_range_days, f"{time_range_days} Delivery Days")
    
    sampling_text = "Hourly" if resampling == "hourly" else "Daily Average"
    
    fig.update_layout(
        title=f"{title_prefix} - {sampling_text} - {time_label} (CET)",
        xaxis_title="Delivery Time (CET)",
        yaxis_title=y_label,
        legend_title="Country",
        hovermode="closest",
        hoverlabel=dict(
            bgcolor='#22262e',
            font_color='#e0e0e0',
            font_size=12,
            bordercolor='#353a44',
        ),
        template="plotly_dark",
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
                    bgcolor='rgba(34,38,46,0.95)', font=dict(color='#e0e0e0')),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    
    # Configure x-axis format based on time range
    if time_range_days <= 3:
        fig.update_xaxes(tickformat="%d-%b %H:%M", dtick=3600000, showgrid=True)
    elif time_range_days <= 14:
        fig.update_xaxes(tickformat="%d-%b", dtick="D1", showgrid=True)
    elif time_range_days <= 90:
        fig.update_xaxes(tickformat="%d-%b", dtick="D7", showgrid=True)
    else:
        fig.update_xaxes(tickformat="%b-%Y", dtick="M1", showgrid=True)
    
    return dcc.Graph(
        id="spot-price-graph",
        figure=fig,
        style={'height': '60vh'},
        config={'displayModeBar': True, 'scrollZoom': True}
    )

def create_fast_heatmap(processed_data, heatmap_type, time_range):
    """Create heatmap using pre-processed data"""
    
    if not processed_data or not processed_data.get('data_loaded'):
        return html.Div([html.H4("No data available", className="text-center text-muted my-5")])
    
    heatmap_key = f"{heatmap_type}_{time_range}"
    heatmap_json = processed_data['heatmap_data'].get(heatmap_key)
    
    if not heatmap_json:
        return html.Div([html.H4("No data available for this time range", className="text-center text-muted my-5")])
    
    # Convert JSON back to DataFrame
    heatmap_data = pd.DataFrame(heatmap_json)
    if heatmap_data.empty:
        return html.Div([html.H4("No data available for this time range", className="text-center text-muted my-5")])
    
    # Convert date columns
    if 'DeliveryDate' in heatmap_data.columns:
        heatmap_data['DeliveryDate'] = pd.to_datetime(heatmap_data['DeliveryDate']).dt.date
    if 'DateSort' in heatmap_data.columns:
        heatmap_data['DateSort'] = pd.to_datetime(heatmap_data['DateSort'])
    
    if heatmap_type == 'daily':
        return create_daily_heatmap_figure(heatmap_data, time_range)
    else:
        return create_weekly_heatmap_figure(heatmap_data, time_range)

def create_daily_heatmap_figure(daily_data, time_range_days):
    """Create daily heatmap figure"""
    if daily_data.empty:
        return html.Div([html.H4("No data available", className="text-center text-muted my-5")])
    
    all_countries = daily_data['Country'].unique()
    ordered_countries = get_ordered_countries(all_countries)
    
    pivot_df = daily_data.pivot_table(index='Country', columns='DeliveryDate', values='Value')
    existing_ordered_countries = [c for c in ordered_countries if c in pivot_df.index]
    
    if existing_ordered_countries:
        pivot_df = pivot_df.reindex(existing_ordered_countries)
    
    ordered_dates = sorted(pivot_df.columns)
    date_labels = [pd.to_datetime(d).strftime('%d-%b-%y') for d in ordered_dates]
    
    fig = go.Figure(data=go.Heatmap(
        z=pivot_df.values,
        x=date_labels,
        y=pivot_df.index,
        colorscale='RdBu_r',  # Red (low) to Blue (high)
        colorbar=dict(title='Price (EUR/MWh)'),
        hovertemplate='<b>%{y}</b><br>Date: %{x}<br>Price: %{z:.2f} EUR/MWh<extra></extra>'
    ))
    
    time_label = {
        1: "Latest Day", 3: "3 Days", 7: "7 Days", 
        30: "30 Days", 180: "6 Months", 365: "1 Year"
    }.get(time_range_days, f"{time_range_days} Days")
    
    fig.update_layout(
        title={
            'text': f'Daily Electricity Prices by Country - {time_label} (CET)',
            'y': 0.97, 'x': 0.5, 'xanchor': 'center', 'yanchor': 'top', 'font': {'size': 18}
        },
        xaxis={'title': 'Date', 'tickangle': -45, 'type': 'category'},
        yaxis={
            'title': 'Country', 'type': 'category',
            'categoryorder': 'array', 'categoryarray': existing_ordered_countries
        },
        height=600, autosize=True, margin=dict(l=50, r=50, t=80, b=100),
    )
    
    return dcc.Graph(
        figure=fig,
        style={'height': '75vh', 'width': '100%'},
        config={'displayModeBar': True, 'scrollZoom': False, 'responsive': True}
    )

def create_weekly_heatmap_figure(weekly_data, time_range_weeks):
    """Create weekly heatmap figure"""
    if weekly_data.empty:
        return html.Div([html.H4("No data available", className="text-center text-muted my-5")])
    
    all_countries = weekly_data['Country'].unique()
    ordered_countries = get_ordered_countries(all_countries)
    
    pivot_df = weekly_data.pivot_table(index='Country', columns='DateSort', values='Value')
    existing_ordered_countries = [c for c in ordered_countries if c in pivot_df.index]
    
    if existing_ordered_countries:
        pivot_df = pivot_df.reindex(existing_ordered_countries)
    
    ordered_dates = sorted(pivot_df.columns)
    week_labels = [d.strftime('W%V-%Y') for d in ordered_dates]
    
    fig = go.Figure(data=go.Heatmap(
        z=pivot_df.values,
        x=week_labels,
        y=pivot_df.index,
        colorscale='RdBu_r',  # Red (low) to Blue (high)
        colorbar=dict(title='Price (EUR/MWh)'),
        hovertemplate='<b>%{y}</b><br>Week: %{x}<br>Price: %{z:.2f} EUR/MWh<extra></extra>'
    ))
    
    weeks_to_label = {4: "1 Month", 13: "3 Months", 26: "6 Months", 52: "1 Year"}
    time_label = weeks_to_label.get(time_range_weeks, f"{time_range_weeks} Weeks")
    
    fig.update_layout(
        title={
            'text': f'Weekly Electricity Prices by Country - {time_label} (CET)',
            'y': 0.97, 'x': 0.5, 'xanchor': 'center', 'yanchor': 'top', 'font': {'size': 18}
        },
        xaxis={'title': 'Week', 'tickangle': -45, 'type': 'category'},
        yaxis={
            'title': 'Country', 'type': 'category',
            'categoryorder': 'array', 'categoryarray': existing_ordered_countries
        },
        height=600, autosize=True, margin=dict(l=50, r=50, t=80, b=100),
    )
    
    return dcc.Graph(
        figure=fig,
        style={'height': '75vh', 'width': '100%'},
        config={'displayModeBar': True, 'scrollZoom': False, 'responsive': True}
    )

def get_layout(data):
    """Get the layout for the Spot page with lazy loading"""

    
    # Use default countries for initial render
    countries = ['DE', 'FR', 'GB', 'BE', 'CH', 'NL', 'IT', 'ES', 'HU', 'CZ', 'SK', 'SI', 'GR', 'RO', 'BG', 'HR', 'NO2', 'AT']
    default_countries = ['DE', 'FR', 'GB', 'BE', 'CH', 'NL', 'IT', 'ES', 'HU', 'CZ', 'SK']  
    
    # Define time ranges for buttons
    time_ranges = [
        {"label": "Latest Day", "value": "24h", "days": 1},
        {"label": "3 Days", "value": "3d", "days": 3},
        {"label": "7 Days", "value": "1w", "days": 7},
        {"label": "30 Days", "value": "1m", "days": 30},
        {"label": "6 Months", "value": "6m", "days": 180},
        {"label": "1 Year", "value": "1y", "days": 365}
    ]
    
    # Define heatmap time ranges
    daily_heatmap_ranges = [
        {"label": "7 Days", "value": 7},
        {"label": "30 Days", "value": 30},
        {"label": "90 Days", "value": 90},
        {"label": "180 Days", "value": 180},
        {"label": "365 Days", "value": 365}
    ]
    
    weekly_heatmap_ranges = [
        {"label": "4 Weeks (1 Month)", "value": 4},
        {"label": "13 Weeks (3 Months)", "value": 13},
        {"label": "26 Weeks (6 Months)", "value": 26},
        {"label": "52 Weeks (1 Year)", "value": 52}
    ]
    
    # Create main layout
    layout = html.Div([
        # Store for preprocessed data - starts empty, loaded via callback
        dcc.Store(id='preprocessed-data', data=None),
        dcc.Store(id='app-state', data={'time_range': '24h'}),
        
        # Auto-refresh interval
        dcc.Interval(id='auto-refresh-interval', interval=300000, n_intervals=0),
        
        # Simple interval that triggers data load immediately and on refresh
        dcc.Interval(id='data-load-trigger', interval=1000, n_intervals=0, max_intervals=1),
        
        get_navbar(active_page='spot'),
        
        # Back button
        dbc.Button("← Back to Home", href="/", external_link=True, color="link", className="mb-3"),
        
        # Data source information
        html.Div([
            dbc.Alert(
                [
                    html.H6("Data Sources", className="alert-heading mb-2"),
                    html.P("EPEX: DE, FR, BE, CH, NL, ES, AT", className="mb-1 small"),
                    html.P("Bloomberg Hourly: GB (N2EX01-24), IT (ITPZ01-24)", className="mb-1 small"),
                    html.P("CSS Spark Spreads: CSS_MID_EFF only (precomputed)", className="mb-0 small"),
                ],
                color="info",
                className="mb-3"
            )
        ]),
        
        # Error message container (hidden initially, shown by callbacks if needed)
        html.Div([
            dbc.Alert(
                [
                    html.H4("Data Loading Error", className="alert-heading"),
                    html.P("There was a problem loading the spot price data. Please try refreshing the page."),
                ],
                color="danger",
                dismissable=True
            )
        ], id="data-load-error", style={'display': 'none'}),
        
        # Refresh button row
        dbc.Row([
            dbc.Col([
                dbc.Button("Refresh Spot Data", id="refresh-spot-data", color="primary", className="mb-4")
            ], width={"size": 3}, className="text-left")
        ]),
        
        # Data type selection (Spot vs Spark)
        dbc.Card([
            dbc.CardHeader("Data Type"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col([
                        dbc.RadioItems(
                            id="data-type-toggle",
                            options=[
                                {"label": "Spot Prices", "value": "spot"},
                                {"label": "CSS Spark Spreads", "value": "spark"},
                            ],
                            value="spot",
                            inline=True,
                            className="mb-0"
                        )
                    ], width=12),
                ]),
            ])
        ], className="control-card mb-3"),

        # Control panel
        dbc.Card([
            dbc.CardHeader("Filtering Options"),
            dbc.CardBody([
                dbc.Row([
                    # Country selection
                    dbc.Col([
                        html.Label("Select Countries:", className="control-label"),
                        dcc.Dropdown(
                            id="spot-country-dropdown",
                            options=[{"label": country, "value": country} for country in countries],
                            value=default_countries,
                            multi=True,
                            placeholder="Select countries"
                        )
                    ], width=6),
                    
                    # Resampling options
                    dbc.Col([
                        html.Label("View:", className="control-label"),
                        dbc.RadioItems(
                            id="spot-resampling",
                            options=[
                                {"label": "Hourly", "value": "hourly"},
                                {"label": "Daily Avg", "value": "daily"},
                            ],
                            value="hourly",
                            inline=True,
                            className="mt-2"
                        )
                    ], width=6),
                ]),
            ])
        ], className="control-card mb-4"),
        
        # Time range buttons
        html.Div([
            dbc.ButtonGroup([
                dbc.Button(
                    time_range["label"],
                    id={"type": "time-range-button", "value": time_range["value"]},
                    color="secondary",
                    outline=True,
                    size="sm",
                    className="me-2"
                )
                for time_range in time_ranges
            ], className="d-flex justify-content-center my-3")
        ]),
        
        # Graph container - shows loading spinner initially
        dbc.Spinner(
            html.Div(
                id="spot-graph-container",
                className="mb-5",
                children=html.Div([
                    html.H4("Loading spot price data...", className="text-center text-muted my-5")
                ])
            ),
            spinner_style={"width": "3rem", "height": "3rem"},
            color="primary",
            type="border"
        ),
        
        # Table tabs selector
        html.Div([
            html.H4("Table View", className="mt-5 mb-3"),
            
            
            dbc.Tabs(
                id="spot-table-tabs",
                active_tab="hourly",
                children=[
                    dbc.Tab(label="Hourly", tab_id="hourly"),
                    dbc.Tab(label="Base", tab_id="base"),
                    dbc.Tab(label="Peak", tab_id="peak"),
                    dbc.Tab(label="Averages", tab_id="averages"),
                    dbc.Tab(label="Weekly Summary", tab_id="weekly_summary")
                ],
                className="mb-3"
            ),
            
            # Download button
            dbc.Row([
                dbc.Col([
                    dbc.Button("📥 Download Table Data", id="download-table-btn", color="success", size="sm", className="mb-3"),
                    dcc.Download(id="download-table-data")
                ], width={"size": 3})
            ])
        ]),
        
        # Table container - shows loading initially
        html.Div([
            html.Div(
                id="spot-table-container",
                className="mb-5",
                children=html.Div([
                    html.H4("Loading table data...", className="text-center text-muted my-5")
                ])
            )
        ]),
        
        # Heatmap panel
        html.Div([
            html.H4("Heatmap Visualizations", className="mt-5 mb-3"),
            
            # Heatmap type tabs
            dbc.Tabs(
                id="heatmap-tabs",
                active_tab="daily",
                children=[
                    dbc.Tab(label="Daily Heatmap", tab_id="daily"),
                    dbc.Tab(label="Weekly Heatmap", tab_id="weekly"),
                ],
                className="mb-3"
            ),
            
            # Time range selection for heatmaps
            dbc.Row([
                dbc.Col([
                    # Daily heatmap range selector
                    html.Div([
                        html.Label("Select Time Range:", className="mt-3 mb-2"),
                        dcc.Dropdown(
                            id="daily-heatmap-range",
                            options=daily_heatmap_ranges,
                            value=30,
                            clearable=False,
                            className="mb-3"
                        ),
                    ], id="daily-heatmap-controls", style={'display': 'block'}),
                    
                    # Weekly heatmap range selector
                    html.Div([
                        html.Label("Select Time Range:", className="mt-3 mb-2"),
                        dcc.Dropdown(
                            id="weekly-heatmap-range",
                            options=weekly_heatmap_ranges,
                            value=13,
                            clearable=False,
                            className="mb-3"
                        ),
                    ], id="weekly-heatmap-controls", style={'display': 'none'}),
                ], width=4)
            ]),
            
            # Heatmap container - shows loading initially
            dbc.Spinner(
                html.Div(
                    id="heatmap-container",
                    className="mt-3 mb-5",
                    style={"width": "100%", "maxWidth": "100%", "overflowX": "hidden"},
                    children=html.Div([
                        html.H4("Loading heatmap data...", className="text-center text-muted my-5")
                    ])
                ),
                spinner_style={"width": "3rem", "height": "3rem"},
                color="primary",
                type="border"
            ),
        ]),
        
        # Last refresh timestamp
        html.Div([
            html.P(
                f"Last refresh: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CET", 
                id="refresh-timestamp",
                className="text-muted text-center mt-2 small"
            )
        ])
    ])
    
    return layout

def register_spot_callbacks(app, data):
    """Register FAST callbacks that only filter pre-processed data"""
    
    # data is the mutable _app_data dict -- always keep the same reference
    app_data = data
    
    # Define time ranges for buttons
    time_ranges = [
        {"label": "Latest Day", "value": "24h", "days": 1},
        {"label": "3 Days", "value": "3d", "days": 3},
        {"label": "7 Days", "value": "1w", "days": 7},
        {"label": "30 Days", "value": "1m", "days": 30},
        {"label": "6 Months", "value": "6m", "days": 180},
        {"label": "1 Year", "value": "1y", "days": 365}
    ]
    
    # FAST callback - update graph using pre-processed data, with fallback for initial load
    @app.callback(
        Output('spot-graph-container', 'children'),
        [
            Input('spot-country-dropdown', 'value'),
            Input('spot-resampling', 'value'),
            Input('data-type-toggle', 'value'),  # New input for data type
            Input({'type': 'time-range-button', 'value': dash.ALL}, 'n_clicks'),
            Input('preprocessed-data', 'data')  # React to data changes
        ],
        [State('app-state', 'data')],
        prevent_initial_call=False  # Allow initial render
    )
    def update_spot_graph(countries, resampling, data_type, time_buttons, processed_data, state):
        if not processed_data or not processed_data.get('data_loaded'):
            print("SPOT GRAPH: Data not loaded yet")
            return html.Div([html.H4("Loading data...", className="text-center text-muted my-5")])
        
        if countries is None:
            countries = ['DE', 'FR']
        
        if data_type == 'spark' and 'css_data' in processed_data:
            data_source = processed_data['css_data']
            data_label = "CSS Spark Spreads"
        else:
            data_source = processed_data
            data_label = "Spot Prices"
        
        print(f"SPOT GRAPH: Creating {data_label} graph for {len(countries)} countries: {countries}")
        
        time_range_days = 1
        ctx = callback_context
        if ctx.triggered:
            triggered_id = ctx.triggered[0]['prop_id'].split('.')[0]
            
            if 'time-range-button' in triggered_id:
                if isinstance(triggered_id, str):
                    button_value = eval(triggered_id)['value']
                else:
                    button_value = triggered_id['value']
                    
                time_map = {"24h": 1, "3d": 3, "1w": 7, "1m": 30, "6m": 180, "1y": 365}
                time_range_days = time_map.get(button_value, 1)
            else:
                if state and 'time_range' in state:
                    button_value = state['time_range']
                    time_map = {"24h": 1, "3d": 3, "1w": 7, "1m": 30, "6m": 180, "1y": 365}
                    time_range_days = time_map.get(button_value, 1)
        else:
            if state and 'time_range' in state:
                button_value = state['time_range']
                time_map = {"24h": 1, "3d": 3, "1w": 7, "1m": 30, "6m": 180, "1y": 365}
                time_range_days = time_map.get(button_value, 1)
        
        if resampling == 'daily' and time_range_days < 30:
            time_range_days = 30
        
        return create_fast_graph(data_source, countries, resampling, time_range_days, data_label)
    
    # FAST callback - filter pre-processed table data, with fallback for initial load
    @app.callback(
        Output('spot-table-container', 'children'),
        [Input('spot-country-dropdown', 'value'),
         Input('spot-table-tabs', 'active_tab'),
         Input('data-type-toggle', 'value'),
         Input('preprocessed-data', 'data')],
        prevent_initial_call=False
    )
    def update_spot_table(countries, active_tab, data_type, processed_data):
        if not processed_data or not processed_data.get('data_loaded'):
            print("SPOT TABLE: Data not loaded yet")
            return html.Div([html.H4("Loading table data...", className="text-center text-muted my-5")])
        
        if countries is None:
            countries = ['DE', 'FR']
        
        if data_type == 'spark' and 'css_data' in processed_data:
            data_source = processed_data['css_data']
            data_label = "CSS Spark Spreads"
        else:
            data_source = processed_data
            data_label = "Spot Prices"
        
        print(f"SPOT TABLE: Creating {active_tab} table for {data_label} with {len(countries)} countries: {countries}")
        return create_fast_table(data_source, countries, active_tab, data_label)
    
    # FAST callback - use pre-processed heatmap data, with fallback for initial load
    @app.callback(
        [Output('heatmap-container', 'children'),
         Output('daily-heatmap-controls', 'style'),
         Output('weekly-heatmap-controls', 'style')],
        [Input('heatmap-tabs', 'active_tab'),
         Input('daily-heatmap-range', 'value'),
         Input('weekly-heatmap-range', 'value'),
         Input('data-type-toggle', 'value'),
         Input('preprocessed-data', 'data')],
        prevent_initial_call=False
    )
    def update_heatmap(active_tab, daily_range, weekly_range, data_type, processed_data):
        daily_style = {'display': 'block' if active_tab == 'daily' else 'none'}
        weekly_style = {'display': 'block' if active_tab == 'weekly' else 'none'}
        
        if not processed_data or not processed_data.get('data_loaded'):
            loading_msg = html.Div([html.H4("Loading heatmap data...", className="text-center text-muted my-5")])
            return loading_msg, daily_style, weekly_style
        
        if data_type == 'spark' and 'css_data' in processed_data:
            data_source = processed_data['css_data']
        else:
            data_source = processed_data
        
        if active_tab == 'daily':
            heatmap = create_fast_heatmap(data_source, 'daily', daily_range)
        elif active_tab == 'weekly':
            heatmap = create_fast_heatmap(data_source, 'weekly', weekly_range)
        else:
            heatmap = html.Div([html.H4("Select a heatmap type", className="text-center text-muted my-5")])
        
        return heatmap, daily_style, weekly_style
    
    # Update button styles based on selection
    @app.callback(
        [Output({"type": "time-range-button", "value": button["value"]}, "color") 
         for button in time_ranges] +
        [Output({"type": "time-range-button", "value": button["value"]}, "outline") 
         for button in time_ranges],
        [Input('app-state', 'data')]
    )
    def update_button_styles(data):
        if not data or 'time_range' not in data:
            selected = "24h"
        else:
            selected = data['time_range']
        
        colors = ["secondary"] * len(time_ranges)
        outlines = [True] * len(time_ranges)
        
        for i, button in enumerate(time_ranges):
            if button["value"] == selected:
                colors[i] = "primary"
                outlines[i] = False
        
        return colors + outlines
    
    @app.callback(
        Output('app-state', 'data'),
        [Input({'type': 'time-range-button', 'value': dash.ALL}, 'n_clicks')],
        [State('app-state', 'data')],
        prevent_initial_call=True
    )
    def update_time_range(button_clicks, current_state):
        ctx = callback_context
        if not ctx.triggered:
            return dash.no_update
            
        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        
        if 'time-range-button' in trigger_id:
            if isinstance(trigger_id, str):
                button_id = eval(trigger_id)['value']
            else:
                button_id = trigger_id['value']
                
            new_state = dict(current_state) if current_state else {}
            new_state['time_range'] = button_id
            return new_state
            
        return dash.no_update
    
    # Simplified data load callback - triggers immediately on page load
    @app.callback(
        [Output('preprocessed-data', 'data'),
         Output('refresh-timestamp', 'children')],
        [Input('data-load-trigger', 'n_intervals'),
         Input('refresh-spot-data', 'n_clicks')],
        prevent_initial_call=False  # Allow initial call for page load
    )
    def load_data(n_intervals, refresh_clicks):
        ctx = callback_context
        
        if not ctx.triggered:
            # Initial page load - use existing app data
            print("SPOT PAGE: Initial page load - using existing app data...")
            try:
                new_processed_data = load_and_preprocess_all_data(app_data)
                print(f"SPOT PAGE: Initial load completed! Data loaded: {new_processed_data.get('data_loaded', False) if new_processed_data else False}")
                timestamp = f"Last refresh: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CET"
                return new_processed_data, timestamp
            except Exception as e:
                print(f"SPOT PAGE: ERROR during initial load: {e}")
                timestamp = f"Error at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CET"
                return None, timestamp
        
        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        
        if trigger_id == 'data-load-trigger' and n_intervals > 0:
            print("SPOT PAGE: Automatic initial data load using existing app data...")
            try:
                new_processed_data = load_and_preprocess_all_data(app_data)
                print(f"SPOT PAGE: Data load completed! Data loaded: {new_processed_data.get('data_loaded', False) if new_processed_data else False}")
                timestamp = f"Last refresh: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CET"
                return new_processed_data, timestamp
            except Exception as e:
                print(f"SPOT PAGE: ERROR during data load: {e}")
                timestamp = f"Error at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CET"
                return None, timestamp
        elif trigger_id == 'refresh-spot-data' and refresh_clicks:
            print("SPOT PAGE: Manual refresh requested - reloading app data...")
            try:
                # For manual refresh, we could reload the main app data, but for now use existing
                new_processed_data = load_and_preprocess_all_data(app_data)
                print(f"SPOT PAGE: Manual refresh completed! Data loaded: {new_processed_data.get('data_loaded', False) if new_processed_data else False}")
                timestamp = f"Last refresh: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CET"
                return new_processed_data, timestamp
            except Exception as e:
                print(f"SPOT PAGE: ERROR during manual refresh: {e}")
                timestamp = f"Error at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CET"
                return None, timestamp
        
        return dash.no_update, dash.no_update

def create_fast_table(processed_data, countries, active_tab, data_label="Spot Prices"):
    """Create tables using pre-processed data"""
    
    # Dark-theme table colours
    header_bg = '#1e3a5f'
    header_text = '#e0e0e0'
    highlight_bg = '#2a2e37'
    highlight_text = '#e0e0e0'
    
    if not countries:
        countries = ['DE', 'FR']
    
    ordered_countries = get_ordered_countries(countries)
    
    try:
        if active_tab == "hourly":
            latest = _latest_delivery_date()
            
            raw_data = pd.DataFrame(processed_data.get('raw_data', []))
            if raw_data.empty:
                return html.Div([html.H4("No data available", className="text-center text-muted my-5")])
            
            raw_data['DeliveryTime'] = pd.to_datetime(raw_data['DeliveryTime'])
            if raw_data['DeliveryTime'].dt.tz is not None:
                raw_data['DeliveryTime'] = raw_data['DeliveryTime'].dt.tz_localize(None)
            raw_data['Date'] = raw_data['DeliveryTime'].dt.date
            
            if latest in raw_data['Date'].values:
                end_date = latest
            else:
                end_date = raw_data['Date'].max()
            start_date = end_date
            raw_data = raw_data[(raw_data['Date'] >= start_date) & (raw_data['Date'] <= end_date)]
            
            if raw_data.empty:
                return html.Div([html.H4("No data available for selected date range", className="text-center text-muted my-5")])
            
            # Group by hour and country for table display (average across all days in range)
            table_data = []
            for hour in range(24):
                row = {'Hour': f"{hour:02d}:00"}
                hour_data = raw_data[raw_data['DeliveryTime'].dt.hour == hour]
                
                for country in countries:
                    country_hour_data = hour_data[hour_data['Country'] == country]
                    if not country_hour_data.empty:
                        avg_price = country_hour_data['Value'].mean()
                        row[country] = f"{avg_price:.2f}"
                    else:
                        row[country] = "-"
                table_data.append(row)
            
            if not table_data:
                return html.Div([html.H4("No hourly data available", className="text-center text-muted my-5")])
            
            # Filter for selected countries
            available_columns = ['Hour'] + [col for col in ordered_countries if any(col in row for row in table_data)]
            
            # Create DataTable
            hour_table = dash_table.DataTable(
                id='hourly-price-table',
                columns=[{"name": "Hour (CET)" if col == "Hour" else col, "id": col} for col in available_columns],
                data=table_data,
                cell_selectable=True,
                style_table={
                    'overflowX': 'auto',
                    'border': '1px solid #353a44',
                    'borderRadius': '5px',
                },
                style_cell={
                    'textAlign': 'center',
                    'minWidth': '80px',
                    'padding': '12px 8px',
                    'fontFamily': 'Inter, Arial, sans-serif',
                    'backgroundColor': '#22262e',
                    'color': '#e0e0e0',
                    'border': '1px solid #353a44',
                },
                style_header={
                    'backgroundColor': header_bg,
                    'color': header_text,
                    'fontWeight': 'bold',
                    'padding': '15px 8px',
                    'textAlign': 'center',
                    'borderBottom': '2px solid #4a5568',
                    'border': '1px solid #353a44',
                },
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
                    {'if': {'column_id': 'Hour'}, 'textAlign': 'left', 'fontWeight': 'bold', 
                     'backgroundColor': highlight_bg, 'color': highlight_text},
                    {'if': {'row_index': len(table_data)-1}, 'backgroundColor': highlight_bg, 
                     'fontWeight': 'bold', 'borderTop': '2px solid #4a5568'}
                ]
            )
            
            # Set appropriate units based on data type
            if "CSS" in data_label or "Spark" in data_label:
                table_title = f"Hourly {data_label} - Latest Full Day (CET)"
                units_label = "(EUR/MWh CSS)"
            else:
                table_title = f"Hourly {data_label} - Latest Full Day (CET)"
                units_label = "(EUR/MWh)"
            
            return html.Div([
                html.H4(table_title, className="text-center mb-3"),
                html.P(f"Showing: {end_date.strftime('%d %b %Y')}", className="text-center text-muted mb-3"),
                hour_table
            ], className="mb-5")
            
        elif active_tab == "averages":
            # Use pre-calculated summary stats
            summary_stats = processed_data.get('summary_stats', {})
            
            results = []
            latest_delivery = _latest_delivery_date()
            today_cet = latest_delivery.strftime('%Y-%m-%d')
            yesterday_cet = (latest_delivery - timedelta(days=1)).strftime('%Y-%m-%d')
            
            for country in ordered_countries:
                stats = summary_stats.get(country, {})
                if any(v is not None for v in stats.values()):
                    results.append({
                        'Country': country,
                        'Today Avg': stats.get('today_avg', '-'),
                        'Today Peak': stats.get('today_peak', '-'),
                        'Today Off-Peak': stats.get('today_offpeak', '-'),
                        'Yesterday Avg': stats.get('yesterday_avg', '-'),
                        'Yesterday Peak': stats.get('yesterday_peak', '-'),
                        '7d Avg': stats.get('week_avg', '-')
                    })
            
            if not results:
                return html.Div([html.H4("No average data available", className="text-center text-muted my-5")])
            
            avg_table = dash_table.DataTable(
                id='averages-table',
                columns=[
                    {"name": "Country", "id": "Country"},
                    {"name": f"Latest ({latest_delivery.strftime('%d %b')})", "id": "Today Avg"},
                    {"name": "Latest Peak", "id": "Today Peak"},
                    {"name": "Latest Off-Peak", "id": "Today Off-Peak"},
                    {"name": f"Previous ({(latest_delivery - timedelta(days=1)).strftime('%d %b')})", "id": "Yesterday Avg"},
                    {"name": "Previous Peak", "id": "Yesterday Peak"},
                    {"name": "7d Avg", "id": "7d Avg"}
                ],
                data=results,
                cell_selectable=True,
                style_table={'overflowX': 'auto', 'border': '1px solid #353a44', 'borderRadius': '5px'},
                style_cell={'textAlign': 'center', 'padding': '12px 8px', 'fontFamily': 'Inter, Arial, sans-serif',
                            'backgroundColor': '#22262e', 'color': '#e0e0e0', 'border': '1px solid #353a44'},
                style_header={'backgroundColor': header_bg, 'color': header_text, 'fontWeight': 'bold',
                              'border': '1px solid #353a44'},
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
                    {'if': {'column_id': 'Country'}, 'textAlign': 'left', 'fontWeight': 'bold',
                     'backgroundColor': highlight_bg, 'color': highlight_text}
                ]
            )
            
            # Set appropriate title based on data type
            if "CSS" in data_label or "Spark" in data_label:
                avg_title = f"{data_label} Averages Summary (EUR/MWh)"
            else:
                avg_title = f"{data_label} Averages Summary (EUR/MWh)"
            
            return html.Div([
                html.H4(avg_title, className="text-center mb-4"),
                avg_table
            ], className="mb-5")
            
        elif active_tab == "base":
            end_date = _latest_delivery_date()
            start_date = end_date - timedelta(days=14)
            
            raw_data = pd.DataFrame(processed_data.get('raw_data', []))
            if raw_data.empty:
                return html.Div([html.H4("No data available", className="text-center text-muted my-5")])
            
            # Convert datetime - data is already in CET hours, just strip any timezone info
            raw_data['DeliveryTime'] = pd.to_datetime(raw_data['DeliveryTime'])
            if raw_data['DeliveryTime'].dt.tz is not None:
                raw_data['DeliveryTime'] = raw_data['DeliveryTime'].dt.tz_localize(None)
            raw_data['Date'] = raw_data['DeliveryTime'].dt.date
            raw_data = raw_data[(raw_data['Date'] >= start_date) & (raw_data['Date'] <= end_date)]
            
            if raw_data.empty:
                return html.Div([html.H4("No data available for selected date range", className="text-center text-muted my-5")])
            
            # Calculate daily base load average (all 24 hours)
            base_data = raw_data.groupby(['Date', 'Country'])['Value'].mean().reset_index()
            
            # Pivot to get countries as columns
            base_pivot = base_data.pivot(index='Date', columns='Country', values='Value')
            base_pivot = base_pivot.reset_index()
            base_pivot['Date'] = base_pivot['Date'].apply(lambda x: x.strftime('%Y-%m-%d'))
            
            # Filter for selected countries and create table data
            available_countries = [c for c in ordered_countries if c in base_pivot.columns]
            table_columns = [{"name": "Date", "id": "Date"}] + [{"name": c, "id": c} for c in available_countries]
            table_data = base_pivot[['Date'] + available_countries].to_dict('records')
            
            # Format values to 2 decimal places
            for row in table_data:
                for country in available_countries:
                    if pd.notna(row.get(country)):
                        row[country] = f"{row[country]:.2f}"
                    else:
                        row[country] = "-"
            
            base_table = dash_table.DataTable(
                id='base-price-table',
                columns=table_columns,
                data=table_data,
                cell_selectable=True,
                style_table={'overflowX': 'auto', 'maxHeight': '600px', 'overflowY': 'auto',
                             'border': '1px solid #353a44'},
                style_cell={'textAlign': 'center', 'padding': '12px 8px', 'fontFamily': 'Inter, Arial, sans-serif',
                            'backgroundColor': '#22262e', 'color': '#e0e0e0', 'border': '1px solid #353a44'},
                style_header={'backgroundColor': header_bg, 'color': header_text, 'fontWeight': 'bold',
                              'border': '1px solid #353a44'},
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
                    {'if': {'column_id': 'Date'}, 'textAlign': 'left', 'fontWeight': 'bold',
                     'backgroundColor': highlight_bg, 'color': highlight_text}
                ]
            )
            
            title = f"Base Load {data_label} - Last 14 Days (24-hour average, CET)"
            return html.Div([
                html.H4(title, className="text-center mb-3"),
                html.P(f"Period: {start_date.strftime('%d %b %Y')} to {end_date.strftime('%d %b %Y')}", className="text-center text-muted mb-3"),
                base_table
            ], className="mb-5")
        
        elif active_tab == "peak":
            end_date = _latest_delivery_date()
            start_date = end_date - timedelta(days=14)
            
            raw_data = pd.DataFrame(processed_data.get('raw_data', []))
            if raw_data.empty:
                return html.Div([html.H4("No data available", className="text-center text-muted my-5")])
            
            # Convert datetime - data is already in CET hours, just strip any timezone info
            raw_data['DeliveryTime'] = pd.to_datetime(raw_data['DeliveryTime'])
            if raw_data['DeliveryTime'].dt.tz is not None:
                raw_data['DeliveryTime'] = raw_data['DeliveryTime'].dt.tz_localize(None)
            raw_data['Date'] = raw_data['DeliveryTime'].dt.date
            raw_data['Hour'] = raw_data['DeliveryTime'].dt.hour
            raw_data = raw_data[(raw_data['Date'] >= start_date) & (raw_data['Date'] <= end_date)]
            
            if raw_data.empty:
                return html.Div([html.H4("No data available for selected date range", className="text-center text-muted my-5")])
            
            # Filter for peak hours (8-20)
            peak_data = raw_data[raw_data['Hour'].between(8, 20)]
            
            if peak_data.empty:
                return html.Div([html.H4("No peak hour data available for selected date range", className="text-center text-muted my-5")])
            
            # Calculate daily peak average
            peak_avg = peak_data.groupby(['Date', 'Country'])['Value'].mean().reset_index()
            
            # Pivot to get countries as columns
            peak_pivot = peak_avg.pivot(index='Date', columns='Country', values='Value')
            peak_pivot = peak_pivot.reset_index()
            peak_pivot['Date'] = peak_pivot['Date'].apply(lambda x: x.strftime('%Y-%m-%d'))
            
            # Filter for selected countries and create table data
            available_countries = [c for c in ordered_countries if c in peak_pivot.columns]
            table_columns = [{"name": "Date", "id": "Date"}] + [{"name": c, "id": c} for c in available_countries]
            table_data = peak_pivot[['Date'] + available_countries].to_dict('records')
            
            # Format values to 2 decimal places
            for row in table_data:
                for country in available_countries:
                    if pd.notna(row.get(country)):
                        row[country] = f"{row[country]:.2f}"
                    else:
                        row[country] = "-"
            
            peak_table = dash_table.DataTable(
                id='peak-price-table',
                columns=table_columns,
                data=table_data,
                cell_selectable=True,
                style_table={'overflowX': 'auto', 'maxHeight': '600px', 'overflowY': 'auto',
                             'border': '1px solid #353a44'},
                style_cell={'textAlign': 'center', 'padding': '12px 8px', 'fontFamily': 'Inter, Arial, sans-serif',
                            'backgroundColor': '#22262e', 'color': '#e0e0e0', 'border': '1px solid #353a44'},
                style_header={'backgroundColor': header_bg, 'color': header_text, 'fontWeight': 'bold',
                              'border': '1px solid #353a44'},
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
                    {'if': {'column_id': 'Date'}, 'textAlign': 'left', 'fontWeight': 'bold',
                     'backgroundColor': highlight_bg, 'color': highlight_text}
                ]
            )
            
            title = f"Peak Hours {data_label} - Last 14 Days (hours 8-20 average, CET)"
            return html.Div([
                html.H4(title, className="text-center mb-3"),
                html.P(f"Period: {start_date.strftime('%d %b %Y')} to {end_date.strftime('%d %b %Y')}", className="text-center text-muted mb-3"),
                peak_table
            ], className="mb-5")
            
        elif active_tab == "weekly_summary":
            # Show last 3 full weeks + current week
            now_cet = datetime.now(pytz.timezone('CET'))
            today = now_cet.date()
            
            # Calculate the start of the current week (Monday)
            current_week_start = today - timedelta(days=today.weekday())
            
            # Calculate start date: 3 full weeks before current week
            start_date = current_week_start - timedelta(weeks=3)
            end_date = today
            
            raw_data = pd.DataFrame(processed_data.get('raw_data', []))
            if raw_data.empty:
                return html.Div([html.H4("No data available", className="text-center text-muted my-5")])
            
            # Convert datetime - data is already in CET hours, just strip any timezone info
            raw_data['DeliveryTime'] = pd.to_datetime(raw_data['DeliveryTime'])
            if raw_data['DeliveryTime'].dt.tz is not None:
                raw_data['DeliveryTime'] = raw_data['DeliveryTime'].dt.tz_localize(None)
            raw_data['Date'] = raw_data['DeliveryTime'].dt.date
            raw_data = raw_data[(raw_data['Date'] >= start_date) & (raw_data['Date'] <= end_date)]
            
            if raw_data.empty:
                return html.Div([html.H4("No data available for selected date range", className="text-center text-muted my-5")])
            
            # Add day of week and week number for grouping
            raw_data['DayOfWeek'] = pd.to_datetime(raw_data['Date']).dt.dayofweek  # 0=Monday, 6=Sunday
            raw_data['WeekStart'] = pd.to_datetime(raw_data['Date']) - pd.to_timedelta(raw_data['DayOfWeek'], unit='D')
            raw_data['WeekStart'] = raw_data['WeekStart'].dt.date
            
            # Calculate weekly summaries for each country
            results = []
            for country in ordered_countries:
                country_data = raw_data[raw_data['Country'] == country]
                if country_data.empty:
                    continue
                
                row = {'Country': country}
                
                # Group by week
                weeks = country_data.groupby('WeekStart')
                
                for week_start, week_data in weeks:
                    week_label = week_start.strftime('%d %b')
                    
                    # Weekly average (all 7 days)
                    weekly_avg = week_data['Value'].mean()
                    row[f"{week_label} Weekly"] = f"{weekly_avg:.2f}"
                    
                    # Weekday average (Mon-Fri, days 0-4)
                    weekday_data = week_data[week_data['DayOfWeek'] < 5]
                    if not weekday_data.empty:
                        weekday_avg = weekday_data['Value'].mean()
                        row[f"{week_label} Weekday"] = f"{weekday_avg:.2f}"
                    else:
                        row[f"{week_label} Weekday"] = "-"
                    
                    # Weekend average (Sat-Sun, days 5-6)
                    weekend_data = week_data[week_data['DayOfWeek'] >= 5]
                    if not weekend_data.empty:
                        weekend_avg = weekend_data['Value'].mean()
                        row[f"{week_label} Weekend"] = f"{weekend_avg:.2f}"
                    else:
                        row[f"{week_label} Weekend"] = "-"
                
                results.append(row)
            
            if not results:
                return html.Div([html.H4("No weekly data available for selected countries", className="text-center text-muted my-5")])
            
            # Create table columns dynamically
            all_keys = set()
            for result in results:
                all_keys.update(result.keys())
            
            table_columns = [{"name": "Country", "id": "Country"}]
            # Sort week columns chronologically
            week_columns = sorted([k for k in all_keys if k != 'Country'])
            table_columns.extend([{"name": col, "id": col} for col in week_columns])
            
            weekly_table = dash_table.DataTable(
                id='weekly-summary-table',
                columns=table_columns,
                data=results,
                cell_selectable=True,
                style_table={'overflowX': 'auto', 'maxHeight': '500px', 'overflowY': 'auto',
                             'border': '1px solid #353a44'},
                style_cell={'textAlign': 'center', 'fontSize': '11px', 'padding': '8px',
                            'backgroundColor': '#22262e', 'color': '#e0e0e0', 'border': '1px solid #353a44'},
                style_header={'backgroundColor': header_bg, 'color': header_text, 'fontWeight': 'bold',
                              'fontSize': '11px', 'border': '1px solid #353a44'},
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
                    {'if': {'column_id': 'Country'}, 'textAlign': 'left', 'fontWeight': 'bold',
                     'backgroundColor': highlight_bg, 'color': highlight_text, 'minWidth': '80px'}
                ] + [{'if': {'column_id': col['id']}, 'backgroundColor': '#1e2a3a', 'color': '#b0d4f1'}
                     for col in table_columns if 'Weekend' in col['id']] +
                [{'if': {'column_id': col['id']}, 'backgroundColor': '#1e3a2a', 'color': '#b0e0c0'}
                 for col in table_columns if 'Weekday' in col['id']]
            )
            
            # Set appropriate title based on data type
            if "CSS" in data_label or "Spark" in data_label:
                weekly_title = f"Weekly {data_label} Summary - Last 3 Weeks + Current Week (EUR/MWh)"
            else:
                weekly_title = f"Weekly {data_label} Summary - Last 3 Weeks + Current Week (EUR/MWh)"
            
            return html.Div([
                html.H4(weekly_title, className="text-center mb-3"),
                html.P(f"Period: {start_date.strftime('%d %b %Y')} to {end_date.strftime('%d %b %Y')}", className="text-center text-muted mb-2"),
                html.P("Weekend = Sat+Sun average | Weekly = 7-day average | Weekday = Mon-Fri average", 
                       className="text-center text-muted mb-4 small"),
                weekly_table
            ], className="mb-5")
            
        else:
            # Unknown tab
            return html.Div([
                html.H4(f"Unknown tab: {active_tab}", 
                       className="text-center text-muted my-5")
            ])
            
    except Exception as e:
        print(f"ERROR creating table: {str(e)}")
        return html.Div([
            html.H4(f"Error creating table: {str(e)}", className="text-center text-muted my-5")
        ])
    
    return html.Div([
        html.H4("Select a table tab above to view data", className="text-center text-muted my-5")
    ])