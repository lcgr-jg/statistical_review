#!/bin/bash
 
# Get the directory of the current script
SCRIPT_DIR="$(dirname "$(realpath "$0")")"

# Path to your DashApp application
APP_DIR="$SCRIPT_DIR"

# Log file path
LOG_FILE="$APP_DIR/log/price_dashboard_power.log"

# Command to start your DashApp service
START_CMD="python $APP_DIR/app.py >> $LOG_FILE 2>&1 &"
 
setup_micromamba() {
    # >>> mamba initialize >>>
    # !! Contents within this block are managed by 'mamba init' !!
    export MAMBA_EXE='/jfs/tools/conda/exec/micromamba';
    export MAMBA_ROOT_PREFIX='/jfs/commod/conda/';
    __mamba_setup="$("$MAMBA_EXE" shell hook --shell bash --root-prefix "$MAMBA_ROOT_PREFIX" 2> /dev/null)"
    if [ $? -eq 0 ]; then
        eval "$__mamba_setup"
    else
        alias micromamba="$MAMBA_EXE"  # Fallback on help from mamba activate
    fi
    unset __mamba_setup
    # <<< mamba initialize <<<
 
    micromamba activate commod-24.11.1
 
    echo $(date "+%Y-%m-%d %H:%M:%S") " : micromamba commod-24.11.1 activated."
}
 
# Check if the DashApp service is running
if pgrep -f "python $APP_DIR/app.py" > /dev/null
then
    echo $(date "+%Y-%m-%d %H:%M:%S") " : Power DashApp service is running."
elif [ -e stop ]
then
    echo $(date "+%Y-%m-%d %H:%M:%S") " : stop file exists. will not start service."
else
    echo $(date "+%Y-%m-%d %H:%M:%S") " : Power DashApp service is not running. Starting the service..."
    cd $APP_DIR
    # Check if micromamba is setup and activated
    # if ! command -v micromamba &> /dev/null
    # then
    #     setup_micromamba
    # fi
    setup_micromamba
    eval $START_CMD
fi
 

