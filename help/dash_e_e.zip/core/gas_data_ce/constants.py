"""Configurable Commodity Essentials datasets for the portal cache.

Asset IDs and variables live here so new CE series can be added without
touching the fetch/scheduler wiring.  Each dataset entry describes:

* ``assets``     — label → CE asset id (country codes for storage / demand;
                   site / interconnect labels later)
* ``variables``  — CE variable names requested for those assets
                   (all assets in a dataset share the same variable list
                   for now; per-asset overrides can be added later)
* ``unit``       — ``mcm`` / ``GWh``
* ``date_from``  — CE ``dateFrom`` (year or ``01_Jan_2015`` style)
* ``add_total``  — if False, skip the automatic Total column (default True)
* ``component_assets`` (demand only) — breakdown of total demand into
                   ``ldz`` / ``industrial`` / ``power``.  Values are a single
                   CE asset id or a list of ids to sum.  Countries / segments
                   sourced from the internal DB (DataQuery) are omitted here.

Extend ``CE_DATASETS`` for pipeline flows, LNG regas, site-level series, etc.
"""
from __future__ import annotations

from typing import Any, Final

# ── Dataset registry ──────────────────────────────────────────────────────
# Extend this dict for LNG / flows / site-level / other CE pulls.  The cache
# loader fetches every key and nests results under ``datasets``.

CE_DATASETS: dict[str, dict[str, Any]] = {
    "gas_storage_country": {
        "description": "NWE+IT+ES+PT country-level gas storage (CE operational data)",
        "assets": {
            "AT": 1768,
            "BE": 677,
            "DE": 688,
            "ES": 1910,
            "FR": 458,
            "GB": 468,
            "IT": 1780,
            "NL": 477,
            "PT": 2269,
        },
        "variables": ["netInjection", "stock", "stockCapacity"],
        "unit": "mcm",
        "date_from": "01_Jan_2015",
    },
    "lng_country": {
        "description": "European LNG terminals by country: regas (withdrawal), "
                       "stock and stock capacity (CE operational data)",
        "assets": {
            "BE": 676,
            "DE": 687,
            "ES": 1909,
            "FI": 2884,
            "FR": 457,
            "GB": 467,
            "GR": 2589,
            "HR": 2831,
            "IT": 1779,
            "LT": 2596,
            "NL": 476,
            "PL": 2044,
            "PT": 2268,
            "TR": 2705,
        },
        "variables": ["withdrawal", "stock", "stockCapacity"],
        "unit": "mcm",
        # Aligns with the Kpler PIT snapshot cache (backfilled to Jan-2021).
        "date_from": "01_Jan_2021",
        # Terminals commissioned mid-history (FI 2023, HR 2021…): keep rows
        # where only some countries report stock/capacity.
        "fill_dropna": "all",
    },
    # Key interconnect / production points from the morning_flows "EU Gas Flows"
    # email. Labels are display names (not country codes). No Total — summing
    # TAP + NCS + UKCS etc. is not meaningful.
    # Asset ids are from CE series metadata (Name / Direction). The morning_flows
    # request string is these ids reversed and then labelled by return order.
    "gas_flows_key": {
        "description": "Key EU pipeline imports and indigenous production "
                       "(CE operational netFlow, as in the EU Gas Flows email)",
        "assets": {
            "UA Total Imports": 1969,  # Flows, To UA
            "TAP": 2782,               # Melendugno (AL => IT)
            "Mazara": 1792,            # Mazara del Vallo (TN => IT)
            "Turkstream": 2678,        # Strandzha Malkoclar 2 (TR => BG)
            "Velke": 1871,             # Velke Kapusany (UA => SK)
            "UKCS": 466,               # GB production
            "NL Prodn": 475,           # NL production
            "NCS": 732,                # NO production
        },
        "variables": ["netFlow"],
        "unit": "mcm",
        "date_from": "01_Jan_2018",
        "add_total": False,
    },
    "gas_demand_country": {
        "description": "NWE+IT+ES+PT country-level total gas demand (CE operational data)",
        "assets": {
            "AT": 1765,
            "BE": 674,
            "DE": 685,
            "ES": 1907,
            "FR": 455,
            "GB": 465,
            "IT": 1777,
            "NL": 2042,
            "PT": 2266,
        },
        # Demand assets expose consumption via netflow.
        "variables": ["netflow"],
        "unit": "mcm",
        "date_from": "01_Jan_2015",
        # Sector breakdown (CE). Multiple ids → sum.
        # DE industrial/power: internal DataQuery only (no CE asset yet).
        # NL industrial/power: CE recent + DataQuery history (stitched at read).
        "component_assets": {
            "ldz": {
                "AT": [3272, 3273],
                "BE": 665,
                "DE": [2965, 2967],
                "ES": 3234,
                "FR": 192,
                "GB": 54,
                "IT": 1803,
                "NL": 209,
                "PT": 2261,
            },
            "industrial": {
                "AT": [3276, 3274],
                "BE": 668,
                "ES": 3235,
                "FR": 188,
                "GB": 83,
                "IT": 1801,
                "NL": 3137,  # recent CE; stitch with DataQuery 2238
                "PT": 2263,
                # DE → DataQuery only
            },
            "power": {
                "AT": [3271, 3273],
                "BE": 671,
                "ES": 1904,
                "FR": 185,
                "GB": 103,
                "IT": 1802,
                "NL": 3130,  # recent CE; stitch with DataQuery 2239
                "PT": 2262,
                # DE → DataQuery only
            },
        },
    },
}

# Internal Postgres (DataQuery) implied demand series — not cached (fast).
# Keys mirror CE component names; values are eu_data data_id integers.
# Where the same country also has a CE component asset, series are stitched:
# CE preferred on overlap, DataQuery fills earlier history (NL industrial/power).
DEMAND_INTERNAL_DATA_IDS: dict[str, dict[str, int]] = {
    "industrial": {
        "DE": 2236,
        "NL": 2238,
    },
    "power": {
        "DE": 2237,
        "NL": 2239,
    },
}

DEMAND_COMPONENTS: Final[tuple[str, ...]] = ("ldz", "industrial", "power")

# ── Scheduler / cache knobs for the CE gas data source ────────────────────
SOURCE_NAME: Final[str] = "gas_data_ce"
# Primary storage dataset (also promoted to top-level cache fields for
# Storage Summary back-compat).
DATASET_KEY: Final[str] = "gas_storage_country"
DEMAND_DATASET_KEY: Final[str] = "gas_demand_country"
LNG_DATASET_KEY: Final[str] = "lng_country"
FLOWS_DATASET_KEY: Final[str] = "gas_flows_key"
# 06:00, 08:00, 12:00, 16:00 UK time
CRON: Final[str] = "0 6,8,12,16 * * *"
CRON_TIMEZONE: Final[str] = "Europe/London"
# Cover the overnight gap (16:00 → 06:00) with headroom if a refresh fails.
TTL_SECONDS: Final[int] = 12 * 60 * 60  # 12 h

CE_USER_ENV: Final[str] = "CE_USER"
CE_PASS_ENV: Final[str] = "CE_PASS"

# Freshness popup label (shared across all CE datasets as they are added).
FRESHNESS_SOURCE_NAME: Final[str] = "Commodity Essentials"
# Overnight gap is 16:00 → 06:00 (~14 h); stay "fresh" across that window.
FRESHNESS_EXPECTED_MINUTES: Final[int] = 14 * 60


def as_asset_id_list(value: int | list[int] | tuple[int, ...]) -> list[int]:
    """Normalise a CE asset id or list of ids to ``list[int]``."""
    if isinstance(value, (list, tuple)):
        return [int(v) for v in value]
    return [int(value)]
