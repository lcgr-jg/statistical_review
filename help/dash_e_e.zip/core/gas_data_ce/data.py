"""Commodity Essentials fetch helpers for portal-cached EU gas data."""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.data_freshness import tracker
from core.gas_data_ce.constants import (
    CE_DATASETS,
    CE_PASS_ENV,
    CE_USER_ENV,
    DATASET_KEY,
    DEMAND_DATASET_KEY,
    FRESHNESS_EXPECTED_MINUTES,
    FRESHNESS_SOURCE_NAME,
    as_asset_id_list,
)

logger = logging.getLogger(__name__)

# Datasets successfully loaded this process — shown in freshness metadata.
_loaded_datasets: set[str] = set()


def _ce_credentials() -> tuple[str, str]:
    user = (os.getenv(CE_USER_ENV) or "").strip()
    password = (os.getenv(CE_PASS_ENV) or "").strip()
    if not user or not password:
        raise RuntimeError(
            f"Commodity Essentials credentials missing. "
            f"Set {CE_USER_ENV} and {CE_PASS_ENV} in deploy/prod.env "
            f"(or the local environment) before warming CE gas datasets."
        )
    return user, password


def _get_dataset_config(dataset_key: str) -> dict[str, Any]:
    try:
        return CE_DATASETS[dataset_key]
    except KeyError as exc:
        known = ", ".join(sorted(CE_DATASETS))
        raise KeyError(
            f"Unknown CE dataset '{dataset_key}'. Known: {known}"
        ) from exc


def _register_freshness(
    *,
    state: str | None = None,
    dataset_key: str | None = None,
    assets: int | None = None,
    records: int | None = None,
    error: str | None = None,
    detail: str | None = None,
) -> None:
    """Update the shared CE row in the Data Source Status popup."""
    if dataset_key and state is None and error is None:
        _loaded_datasets.add(dataset_key)

    metadata: dict[str, Any] = {}
    if state:
        metadata["state"] = state
    if detail:
        metadata["detail"] = detail
    if error:
        metadata["error"] = error[:200]
        metadata["state"] = "error"
    if _loaded_datasets:
        metadata["datasets"] = ", ".join(sorted(_loaded_datasets))
    if dataset_key:
        metadata["last_dataset"] = dataset_key
    if assets is not None:
        metadata["assets"] = assets
    if records is not None:
        metadata["records"] = records

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata=metadata,
    )


def _partial_storage_injection(
    ce, *, dataset_key: str, df_inj: pd.DataFrame, unit: str
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Site-level sums, and which sites were missing, for recent unpublished days."""
    from core.gas_data_ce.partial_storage import _empty_coverage

    empty = (pd.DataFrame(), _empty_coverage())
    if dataset_key != DATASET_KEY or not isinstance(df_inj, pd.DataFrame) or df_inj.empty:
        return empty
    try:
        from core.gas_data_ce.constants import CE_DATASETS
        from core.gas_data_ce.partial_storage import fetch_partial_storage_detail

        asset_ids = {code: int(asset_id) for code, asset_id in CE_DATASETS[DATASET_KEY]["assets"].items()}
        partial = fetch_partial_storage_detail(ce, df_inj, asset_ids=asset_ids, unit=unit)
        if not partial.values.empty:
            logger.info(
                "Stored partial storage for %s",
                ", ".join(str(col) for col in partial.values.columns),
            )
        return partial.values, partial.coverage
    except Exception:
        logger.exception("Level-2 storage fallback failed")
        return empty


def mark_ce_freshness_pending(detail: str = "waiting for warm-up") -> None:
    """Show Commodity Essentials in the popup before the first fetch starts."""
    # If a prior run left usable disk cache, don't look "empty" — note that a
    # background refresh is still in progress.
    try:
        from core.cache import dashboard_cache
        from core.gas_data_ce.constants import SOURCE_NAME

        cached = dashboard_cache.get(f"source:{SOURCE_NAME}")
        if cached is not None:
            detail = "serving disk cache · refresh in progress"
    except Exception:
        pass
    _register_freshness(state="pending", detail=detail)


def _fetch_ce_netflow_by_asset_id(
    ce,
    asset_ids: list[int],
    *,
    unit: str,
    date_from: str,
) -> dict[int, pd.Series]:
    """
    Fetch CE ``netflow`` for a list of asset ids.

    Returns ``{asset_id: daily Series}``. Duplicate ids are fetched once.
    """
    unique_ids = sorted({int(a) for a in asset_ids})
    if not unique_ids:
        return {}

    assets_str = ",".join(str(a) for a in unique_ids)
    common = dict(assets=assets_str, unit=unit, dateFrom=date_from)
    df_meta = ce.eugasopdata(**common, variable="netflow", meta=True)
    df_raw = (
        ce.eugasopdata(**common, variable="netflow")
        .set_index("Date")
        .drop(columns=["DateExcel"])
        .pipe(lambda df: df.set_index(pd.to_datetime(df.index)))
    )

    out: dict[int, pd.Series] = {}
    for col in df_raw.columns:
        raw_id = int(df_meta.loc[df_meta["seriesId"] == "assetId", str(col)].iloc[0])
        series = pd.to_numeric(df_raw[col], errors="coerce")
        series.name = str(raw_id)
        out[raw_id] = series
    return out


def _build_component_frames(
    component_assets: dict[str, dict[str, Any]],
    by_asset_id: dict[int, pd.Series],
) -> dict[str, pd.DataFrame]:
    """Sum configured CE asset ids into country columns per component."""
    frames: dict[str, pd.DataFrame] = {}
    for component, countries in (component_assets or {}).items():
        cols: dict[str, pd.Series] = {}
        for country, raw_ids in (countries or {}).items():
            ids = as_asset_id_list(raw_ids)
            parts = [by_asset_id[i] for i in ids if i in by_asset_id]
            if not parts:
                continue
            summed = parts[0].copy()
            for extra in parts[1:]:
                summed = summed.add(extra, fill_value=0.0)
            cols[country] = summed
        if not cols:
            frames[component] = pd.DataFrame()
            continue
        df = pd.DataFrame(cols).sort_index()
        country_cols = list(df.columns)
        df["Total"] = df[country_cols].fillna(0).sum(axis=1)
        frames[component] = df
    return frames


def fetch_ce_opdata(dataset_key: str) -> dict[str, Any]:
    """
    Query Commodity Essentials for a configured dataset.

    Returns a picklable dict suitable for ``dashboard_cache``::

        {
            "dataset": "gas_storage_country",
            "fetched_at": "<ISO UTC>",
            "assets": {...},
            "variables": [...],
            "unit": "mcm",
            "date_from": "01_Jan_2015",
            "injection": DataFrame,   # daily netInjection by country + Total
            "fill": DataFrame,        # stock / stockCapacity by country + Totals
            "demand": DataFrame,      # daily demand (netflow) by country + Total
            "demand_components": {    # optional LDZ / industrial / power frames
                "ldz": DataFrame, ...
            },
            "by_variable": {          # raw per-variable frames (labelled)
                ...
            },
        }
    """
    from jain_commods.core.interfaces.commodityessentials import CElink

    _register_freshness(
        state="loading",
        dataset_key=dataset_key,
        detail=f"fetching {dataset_key}",
    )

    try:
        cfg = _get_dataset_config(dataset_key)
        assets: dict[str, int] = dict(cfg["assets"])
        variables: list[str] = list(cfg["variables"])
        unit = cfg.get("unit", "mcm")
        date_from = cfg.get("date_from", "01_Jan_2015")
        component_assets = cfg.get("component_assets") or {}

        assets_str = ",".join(str(v) for v in assets.values())
        assets_rev = {v: k for k, v in assets.items()}
        common = dict(assets=assets_str, unit=unit, dateFrom=date_from)

        user, password = _ce_credentials()
        ce = CElink(user, password)

        logger.info(
            "CE fetch dataset=%s assets=%d vars=%s from=%s",
            dataset_key,
            len(assets),
            ",".join(variables),
            date_from,
        )

        # Metadata used to map opaque CE columns → country / variable.
        df_meta = ce.eugasopdata(
            **common,
            variable=",".join(variables),
            meta=True,
        )

        def _country(col: str) -> str:
            # CE names columns by series id (string). Integer labels must be
            # looked up as str or pandas treats them as positions.
            raw_id = df_meta.loc[df_meta["seriesId"] == "assetId", str(col)].iloc[0]
            return assets_rev[int(raw_id)]

        def _variable(col: str) -> str:
            return df_meta.loc[df_meta["seriesId"] == "Variable", str(col)].iloc[0]

        def _load(variable: str) -> pd.DataFrame:
            return (
                ce.eugasopdata(**common, variable=variable)
                .set_index("Date")
                .drop(columns=["DateExcel"])
                .pipe(lambda df: df.set_index(pd.to_datetime(df.index)))
            )

        by_variable: dict[str, pd.DataFrame] = {}

        # netInjection → country columns + Total (NaNs preserved on countries)
        if "netInjection" in variables:
            df_inj = _load("netInjection")
            df_inj.columns = [_country(c) for c in df_inj.columns]
            df_inj["Total"] = df_inj.fillna(0).sum(axis=1)
            by_variable["netInjection"] = df_inj
        else:
            df_inj = pd.DataFrame()

        partial_injection, partial_coverage = _partial_storage_injection(
            ce, dataset_key=dataset_key, df_inj=df_inj, unit=unit
        )

        # stock / stockCapacity → "{CC}|{variable}" columns + totals.
        # fill_dropna: "any" (default, complete rows only) or "all" — use
        # "all" when assets start reporting at different dates (e.g. LNG
        # terminals commissioned mid-history) so early rows survive.
        fill_dropna = cfg.get("fill_dropna", "any")
        fill_vars = [v for v in ("stock", "stockCapacity") if v in variables]
        if fill_vars:
            df_fill = _load(",".join(fill_vars)).dropna(how=fill_dropna)
            df_fill.columns = [f"{_country(c)}|{_variable(c)}" for c in df_fill.columns]
            if "stock" in fill_vars:
                df_fill["Total|stock"] = df_fill.filter(regex=r"\|stock$").sum(axis=1)
                by_variable["stock"] = df_fill.filter(regex=r"\|stock$").copy()
            if "stockCapacity" in fill_vars:
                df_fill["Total|stockCapacity"] = df_fill.filter(
                    like="|stockCapacity"
                ).sum(axis=1)
                by_variable["stockCapacity"] = df_fill.filter(
                    like="|stockCapacity"
                ).copy()
        else:
            df_fill = pd.DataFrame()

        # Demand / flow / other labelled frames. Total is on by default;
        # interconnect / production datasets set add_total=False.
        add_total = bool(cfg.get("add_total", True))
        df_demand = pd.DataFrame()
        for var in variables:
            if var in by_variable or var in ("stock", "stockCapacity", "netInjection"):
                continue
            df_var = _load(var)
            df_var.columns = [_country(c) for c in df_var.columns]
            ordered = [k for k in assets if k in df_var.columns]
            rest = [c for c in df_var.columns if c not in ordered]
            df_var = df_var[ordered + rest]
            country_cols = [c for c in df_var.columns if c != "Total"]
            if country_cols and add_total:
                df_var["Total"] = df_var[country_cols].fillna(0).sum(axis=1)
            by_variable[var] = df_var
            # Promote netflow as the demand frame (Total Demand assets).
            if var.lower() == "netflow" and df_demand.empty:
                df_demand = df_var

        # Sector breakdown (LDZ / industrial / power) — extra CE pull.
        demand_components: dict[str, pd.DataFrame] = {}
        if component_assets:
            all_component_ids: list[int] = []
            for countries in component_assets.values():
                for raw in (countries or {}).values():
                    all_component_ids.extend(as_asset_id_list(raw))
            if all_component_ids:
                _register_freshness(
                    state="loading",
                    dataset_key=dataset_key,
                    detail=f"fetching {dataset_key} components",
                )
                logger.info(
                    "CE fetch dataset=%s component assets=%d",
                    dataset_key,
                    len(set(all_component_ids)),
                )
                by_asset = _fetch_ce_netflow_by_asset_id(
                    ce,
                    all_component_ids,
                    unit=unit,
                    date_from=date_from,
                )
                demand_components = _build_component_frames(
                    component_assets, by_asset
                )

        records = 0
        for frame in list(by_variable.values()) + list(demand_components.values()):
            if isinstance(frame, pd.DataFrame) and not frame.empty:
                records = max(records, len(frame))

        _register_freshness(
            dataset_key=dataset_key,
            assets=len(assets),
            records=records,
        )

        return {
            "dataset": dataset_key,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "assets": assets,
            "variables": variables,
            "unit": unit,
            "date_from": date_from,
            "injection": df_inj,
            "partial_injection": partial_injection,
            "partial_coverage": partial_coverage,
            "fill": df_fill,
            "demand": df_demand,
            "demand_components": demand_components,
            "component_assets": component_assets,
            "by_variable": by_variable,
        }
    except Exception as exc:
        logger.exception("CE fetch failed for dataset=%s: %s", dataset_key, exc)
        _register_freshness(
            state="error",
            dataset_key=dataset_key,
            error=str(exc),
            detail=f"failed: {dataset_key}",
        )
        raise


def load_gas_data_ce() -> dict[str, Any]:
    """
    Loader for ``dashboard_cache.register_source('gas_data_ce', ...)``.

    Fetches every entry in ``CE_DATASETS``. Storage fields are promoted to the
    top level for Storage Summary back-compat; demand is also promoted.
    """
    datasets: dict[str, Any] = {}
    for key in CE_DATASETS:
        datasets[key] = fetch_ce_opdata(key)

    storage = datasets.get(DATASET_KEY) or {}
    demand_payload = datasets.get(DEMAND_DATASET_KEY) or {}
    demand_df = demand_payload.get("demand")
    if demand_df is None or not isinstance(demand_df, pd.DataFrame):
        demand_df = pd.DataFrame()
    demand_components = demand_payload.get("demand_components") or {}

    fetched_times = [
        p.get("fetched_at")
        for p in datasets.values()
        if isinstance(p, dict) and p.get("fetched_at")
    ]
    fetched_at = max(fetched_times) if fetched_times else datetime.now(
        timezone.utc
    ).isoformat()

    return {
        "fetched_at": fetched_at,
        "datasets": datasets,
        # Top-level storage aliases (existing Storage Summary readers).
        "dataset": storage.get("dataset", DATASET_KEY),
        "assets": storage.get("assets", {}),
        "variables": storage.get("variables", []),
        "unit": storage.get("unit", "mcm"),
        "date_from": storage.get("date_from", "01_Jan_2015"),
        "injection": storage.get("injection", pd.DataFrame()),
        "partial_injection": storage.get("partial_injection", pd.DataFrame()),
        "partial_coverage": storage.get("partial_coverage", pd.DataFrame()),
        "fill": storage.get("fill", pd.DataFrame()),
        "by_variable": storage.get("by_variable", {}),
        # Country demand (netflow) + Total + sector breakdown.
        "demand": demand_df,
        "demand_components": demand_components,
        **_sefe_tracker_fields(),
    }


def _sefe_tracker_fields() -> dict[str, Any]:
    """SEFE site history and forward outages, stored on the same CE refresh.

    A failure here leaves the country cache intact. The page then loads SEFE
    once in-process until the next successful refresh.
    """
    try:
        from core.gas_storage_summary.sefe import load_sefe_tracker_cache

        fields = load_sefe_tracker_cache()
    except Exception:
        logger.exception("SEFE tracker was not added to the CE cache")
        return {}
    if "sefe_frame" not in fields:
        return {}
    logger.info(
        "Stored SEFE tracker (%s site rows)",
        len(fields["sefe_frame"]) if isinstance(fields["sefe_frame"], pd.DataFrame) else 0,
    )
    return fields


# Back-compat alias (old package / source name).
load_gas_storage_ce = load_gas_data_ce
