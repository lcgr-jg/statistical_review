# Core utilities for EU Dashboard Power
