"""
Shared Styles Module for EU Power Dashboard
Provides consistent styling across all dashboard pages.
"""

# Master color scheme (refined dark chrome + flat content)
COLORS = {
    # Header & navigation — refined dark palette: one calm near-black for the
    # header, one step lighter for the sidebar, so the two surfaces read as
    # layered without needing drop shadows.
    'header_bg': '#0f1419',          # deep neutral (was #2b3a42 slate)
    'header_text': '#ffffff',
    'header_sub': '#9aa0a6',         # higher-contrast inactive (was #b0b0b0)
    'sidebar_bg': '#13181d',         # one shade above header (was #1a1a1a)
    'sidebar_text': '#9aa0a6',       # inactive nav link
    'sidebar_text_active': '#ffffff',
    'sidebar_text_muted': '#6c7480', # group headers
    # Active nav: translucent accent wash instead of a solid block.
    'active_item': 'rgba(78, 115, 138, 0.14)',
    # Hairline borders for the dark chrome — replace box-shadows.
    'border_dark': '#252b32',
    'border_dark_strong': '#363c45',

    'accent': '#4E738A',
    'accent_dark': '#3d5c6f',
    'accent_blue': '#4E738A',
    'accent_green': '#2ea043',
    'accent_yellow': '#d29922',

    # Text colors
    'text_primary': '#231F20',
    'text_secondary': '#495057',
    'text_muted': '#6c757d',
    'text_dark': '#333333',

    # Borders
    'border': '#e1e4e8',
    'border_light': '#eaecef',

    # Background colors
    'background': '#f5f6f8',
    'page_bg': '#f5f6f8',
    'card_bg': '#ffffff',
    'card_bg_alt': '#f8f9fa',
    'chart_bg': '#faf9f6',
    'chart_paper': '#ffffff',
    'table_header_bg': '#f2f2f2',

    # Status colors
    'success': '#4CAF50',
    'warning': '#ff9800',
    'error': '#f44336',
    'info': '#2196F3',
    'danger': '#d9534f',

    # Chart colors (consistent palette)
    'chart_primary': '#4a9eff',
    'chart_secondary': '#50c878',
    'chart_tertiary': '#ff6b6b',
    'chart_quaternary': '#ffd93d',

    # Fuel switching specific
    'gas_primary': '#2171b5',
    'gas_secondary': '#6baed6',
    'coal_primary': '#6c757d',
    'lignite_primary': '#a0522d',
    'power_primary': '#d9534f',
    'power_secondary': '#e27c79',
    'carbon_primary': '#2ea043',

    # Freshness indicators
    'fresh': '#4CAF50',
    'stale': '#ff9800',
    'critical': '#f44336',
}

# Standard chart color sequence
CHART_COLORS = [
    '#4a9eff',  # Blue
    '#50c878',  # Green
    '#ff6b6b',  # Red
    '#ffd93d',  # Yellow
    '#9b59b6',  # Purple
    '#1abc9c',  # Teal
    '#e74c3c',  # Dark red
    '#3498db',  # Light blue
    '#f39c12',  # Orange
    '#2ecc71',  # Emerald
]

# Standard page container style
PAGE_CONTAINER_STYLE = {
    'padding': '20px',
    'minHeight': 'calc(100vh - 90px)',
    'backgroundColor': COLORS['page_bg'],
}

# Standard card style — hairline border, no shadow
CARD_STYLE = {
    'backgroundColor': COLORS['card_bg'],
    'borderRadius': '10px',
    'border': f"1px solid {COLORS['border']}",
    'padding': '20px',
    'marginBottom': '20px',
}

# Standard header style
PAGE_HEADER_STYLE = {
    'fontSize': '24px',
    'fontWeight': '600',
    'color': COLORS['text_dark'],
    'marginBottom': '20px',
    'paddingBottom': '10px',
    'borderBottom': f"2px solid {COLORS['accent']}",
}

# Subheader style
SUBHEADER_STYLE = {
    'fontSize': '18px',
    'fontWeight': '500',
    'color': COLORS['text_dark'],
    'marginBottom': '15px',
}

# Standard button styles
BUTTON_PRIMARY_STYLE = {
    'backgroundColor': COLORS['accent'],
    'color': 'white',
    'border': 'none',
    'borderRadius': '6px',
    'padding': '10px 20px',
    'cursor': 'pointer',
    'fontSize': '14px',
    'fontWeight': '500',
    'transition': 'all 0.2s ease',
}

BUTTON_SECONDARY_STYLE = {
    'backgroundColor': 'transparent',
    'color': COLORS['accent'],
    'border': f"1px solid {COLORS['accent']}",
    'borderRadius': '6px',
    'padding': '10px 20px',
    'cursor': 'pointer',
    'fontSize': '14px',
    'fontWeight': '500',
    'transition': 'all 0.2s ease',
}

BUTTON_DANGER_STYLE = {
    'backgroundColor': COLORS['error'],
    'color': 'white',
    'border': 'none',
    'borderRadius': '6px',
    'padding': '10px 20px',
    'cursor': 'pointer',
    'fontSize': '14px',
    'fontWeight': '500',
}

# Standard dropdown style
DROPDOWN_STYLE = {
    'width': '100%',
    'borderRadius': '6px',
}

# Badge styles
def get_status_badge_style(status: str) -> dict:
    """Get badge style based on status type."""
    base_style = {
        'display': 'inline-block',
        'padding': '4px 12px',
        'borderRadius': '12px',
        'fontSize': '11px',
        'fontWeight': '600',
    }
    
    if status == 'success' or status == 'fresh':
        return {**base_style, 
                'backgroundColor': 'rgba(76, 175, 80, 0.15)',
                'color': COLORS['success'],
                'border': f"1px solid {COLORS['success']}30"}
    elif status == 'warning' or status == 'stale':
        return {**base_style,
                'backgroundColor': 'rgba(255, 152, 0, 0.15)',
                'color': COLORS['warning'],
                'border': f"1px solid {COLORS['warning']}30"}
    elif status == 'error' or status == 'critical':
        return {**base_style,
                'backgroundColor': 'rgba(244, 67, 54, 0.15)',
                'color': COLORS['error'],
                'border': f"1px solid {COLORS['error']}30"}
    else:  # info or default
        return {**base_style,
                'backgroundColor': 'rgba(33, 150, 243, 0.15)',
                'color': COLORS['info'],
                'border': f"1px solid {COLORS['info']}30"}

# Table styles
TABLE_STYLE = {
    'borderCollapse': 'collapse',
    'width': '100%',
    'fontSize': '13px',
    'fontFamily': 'Calibri, Arial, sans-serif',
}

TABLE_HEADER_STYLE = {
    'backgroundColor': COLORS['table_header_bg'],
    'color': COLORS['text_dark'],
    'fontWeight': 'bold',
    'textAlign': 'center',
    'padding': '8px',
    'border': f"1px solid {COLORS['border_light']}",
}

TABLE_CELL_STYLE = {
    'textAlign': 'center',
    'padding': '6px',
    'border': f"1px solid {COLORS['border_light']}",
}

# Loading indicator style
LOADING_STYLE = {
    'display': 'flex',
    'justifyContent': 'center',
    'alignItems': 'center',
    'minHeight': '200px',
    'color': COLORS['text_secondary'],
}

# Info banner style
INFO_BANNER_STYLE = {
    'backgroundColor': 'rgba(33, 150, 243, 0.1)',
    'border': f"1px solid {COLORS['info']}30",
    'borderRadius': '8px',
    'padding': '12px 16px',
    'marginBottom': '20px',
    'display': 'flex',
    'alignItems': 'center',
    'gap': '10px',
}

# Chart layout template
def get_chart_layout(title: str = None, height: int = 400) -> dict:
    """Get standard chart layout configuration."""
    layout = {
        'height': height,
        'margin': {'l': 50, 'r': 30, 't': 50 if title else 30, 'b': 50},
        'paper_bgcolor': COLORS['card_bg'],
        'plot_bgcolor': COLORS['card_bg'],
        'font': {'family': '-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif'},
        'xaxis': {
            'gridcolor': '#eee',
            'zerolinecolor': '#ddd',
        },
        'yaxis': {
            'gridcolor': '#eee',
            'zerolinecolor': '#ddd',
        },
        'legend': {
            'orientation': 'h',
            'yanchor': 'bottom',
            'y': 1.02,
            'xanchor': 'right',
            'x': 1,
        },
    }
    
    if title:
        layout['title'] = {
            'text': title,
            'font': {'size': 16, 'color': COLORS['text_dark']},
            'x': 0.5,
            'xanchor': 'center',
        }
    
    return layout

# Heatmap color scales
HEATMAP_COLORSCALE_PRICE = [
    [0, '#2ecc71'],      # Green (low)
    [0.25, '#27ae60'],
    [0.5, '#f39c12'],    # Yellow (medium)
    [0.75, '#e74c3c'],
    [1, '#c0392b'],      # Red (high)
]

HEATMAP_COLORSCALE_AVAILABILITY = [
    [0, '#e74c3c'],      # Red (low availability)
    [0.25, '#f39c12'],
    [0.5, '#f1c40f'],    # Yellow (medium)
    [0.75, '#27ae60'],
    [1, '#2ecc71'],      # Green (high availability)
]

# Data table styles for Dash DataTable
DATA_TABLE_STYLE_HEADER = {
    'backgroundColor': COLORS['table_header_bg'],
    'fontWeight': 'bold',
    'textAlign': 'center',
    'border': f"1px solid {COLORS['border_light']}",
}

DATA_TABLE_STYLE_CELL = {
    'textAlign': 'center',
    'padding': '8px',
    'border': f"1px solid {COLORS['border_light']}",
    'minWidth': '80px',
}

DATA_TABLE_STYLE_DATA = {
    'backgroundColor': COLORS['card_bg'],
}

DATA_TABLE_CONDITIONAL_STYLES = [
    {
        'if': {'row_index': 'odd'},
        'backgroundColor': 'rgba(0, 0, 0, 0.03)',
    },
    {
        'if': {'state': 'active'},
        'backgroundColor': 'rgba(74, 158, 255, 0.1)',
        'border': f"1px solid {COLORS['accent']}",
    },
]
