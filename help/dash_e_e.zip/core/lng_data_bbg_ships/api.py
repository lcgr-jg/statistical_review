"""Bloomberg BSRCH snapshot of in-service LNG tankers (lat/lon etc)."""
from __future__ import annotations

import logging
import platform

import blpapi
import pandas as pd

from jain_commods.core.interfaces.bloomberg import bsrch_handler

from core.lng_data_bbg_ships.constants import (
    BPIPE_APP,
    BPIPE_HOST,
    OPERATIONAL_STATUS,
    SHIP_OUTPUT_FIELDS,
    VESSEL_TYPE,
)

logger = logging.getLogger(__name__)


def _default_on_server() -> bool:
    return platform.system().lower() != "windows"


def _start_session(on_server: bool) -> blpapi.Session:
    if on_server:
        options = blpapi.SessionOptions()
        options.sessionName = "BBG LNG Ship Snapshot"
        options.setServerAddress(BPIPE_HOST, 8194, 0)
        auth = blpapi.AuthOptions.createWithApp(BPIPE_APP)
        options.setSessionIdentityOptions(auth, blpapi.CorrelationId("authCorrelation"))
        session = blpapi.Session(options)
    else:
        session = blpapi.Session()

    if not session.start():
        raise RuntimeError("Failed to start Bloomberg session")
    if not session.openService("//blp/exrsvc"):
        raise RuntimeError("Failed to open //blp/exrsvc (BSRCH / ExcelGetGridRequest)")
    return session


def _ship_snapshot_request(service: blpapi.Service) -> blpapi.Request:
    request = service.createRequest("ExcelGetGridRequest")
    request.set("Domain", "comdty:ship")
    overrides = request.getElement("Overrides")
    for name, value in (
        ("VESSEL_TYPE", VESSEL_TYPE),
        ("OPERATIONAL_STATUS", OPERATIONAL_STATUS),
        ("OUTPUT", SHIP_OUTPUT_FIELDS),
    ):
        ov = overrides.appendElement()
        ov.setElement("name", name)
        ov.setElement("value", value)
    return request


def _collect_bsrch_response(session: blpapi.Session) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    while True:
        event = session.nextEvent(10_000)
        if event.eventType() not in (
            bsrch_handler.BLP_RESPONSE,
            bsrch_handler.BLP_PARTIAL_RESPONSE,
        ):
            continue
        for msg in event:
            df = bsrch_handler.getBSRCHData(msg)
            if len(df) > 0:
                frames.append(df)
        if event.eventType() == bsrch_handler.BLP_RESPONSE:
            break
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [
        (
            c.lower()
            .replace(" ", "_")
            .replace("(", "")
            .replace(")", "")
            .replace("%", "percent")
            .replace("/", "__")
        )
        for c in out.columns
    ]
    for col in ("latitude", "longitude", "heading", "reported_speed_knots", "imo"):
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    if "last_seen" in out.columns:
        out["last_seen"] = pd.to_datetime(out["last_seen"], errors="coerce", utc=True)
    return out


def fetch_lng_ship_snapshot(*, on_server: bool | None = None) -> pd.DataFrame:
    """Return one row per in-service LNG tanker from Bloomberg BSRCH."""
    if on_server is None:
        on_server = _default_on_server()
    logger.info(
        "Bloomberg LNG ship snapshot via %s",
        "B-PIPE" if on_server else "desktop Terminal",
    )
    session = _start_session(on_server)
    try:
        service = session.getService("//blp/exrsvc")
        session.sendRequest(_ship_snapshot_request(service))
        df = _collect_bsrch_response(session)
    finally:
        session.stop()
    return _normalise_columns(df)
