"""Scheduler / freshness knobs for Bloomberg LNG ship positions."""
from __future__ import annotations

from typing import Final

from core.constants import TTL_HOUR

SOURCE_NAME: Final[str] = "lng_data_bbg_ships"
# Align with Kpler LNG hourly refresh.
CRON: Final[str] = "0 * * * *"
CRON_TIMEZONE: Final[str] = "Europe/London"
TTL_SECONDS: Final[int] = TTL_HOUR

FRESHNESS_SOURCE_NAME: Final[str] = "Bloomberg LNG Ships"
FRESHNESS_EXPECTED_MINUTES: Final[int] = 2 * 60

# Write-once hourly archive (S3 only), parallel to Kpler PIT vessels_daily.
# The dashboard cache still holds only the latest snapshot; these parquets
# keep every hour so an IMO track can be rebuilt.
S3_PREFIX: Final[str] = "commodity-data-cache/bloomberg/lng"
HOURLY_FOLDER: Final[str] = "ships_hourly"
POSITION_HIST_FILENAME: Final[str] = "position_hist_v1.parquet"

# BSRCH comdty:ship snapshot (same fields as bbg_lng_ship_snapshot.py)
SHIP_OUTPUT_FIELDS: Final[str] = (
    "IMO|VESSEL_NAME|LAST_SEEN|ETA|LATITUDE|LONGITUDE|DEPART_TIME|"
    "NAVIGATION_STATUS|NORMALIZED_DESTINATION|NORMALIZED_COUNTRY_REGION|"
    "REPORTED_SPEED|DESTINATION|DELIVERY_DATE|BENEFICIAL_OWNER|VESSEL_TYPE|"
    "GAS_CAPACITY|VESSEL_TYPE_4|DWT|LIQUID_CAPACITY|CARGO_STATUS|CARGO_PRODUCT|"
    "VESSEL_CLASS|BUILD_DATE|LOA|MMSI|CURRENT_DRAFT|FLAG|MAX_DRAFT|DRAFT_PCT|"
    "DEPART_PORT|HEADING|SERVICE_SPEED|OPERATIONAL_STATUS|MOVEMENT_SOURCE|"
    "GRAIN_CAPACITY|"
)
VESSEL_TYPE: Final[str] = "LNG TANKER"
OPERATIONAL_STATUS: Final[str] = "In Service/Commission"
BPIPE_HOST: Final[str] = "Tech1ProdBPipe47537.jainglobal.net"
BPIPE_APP: Final[str] = "JAIN:commoditiespmdashboard"
