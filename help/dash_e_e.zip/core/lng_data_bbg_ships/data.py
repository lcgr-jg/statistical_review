"""Bloomberg LNG ship positions for the portal cache."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.cache import dashboard_cache
from core.data_freshness import tracker
from core.lng_data_bbg_ships.constants import (
    FRESHNESS_EXPECTED_MINUTES,
    FRESHNESS_SOURCE_NAME,
    SOURCE_NAME,
)

logger = logging.getLogger(__name__)


def _register_freshness(
    *,
    state: str | None = None,
    records: int | None = None,
    error: str | None = None,
    detail: str | None = None,
) -> None:
    metadata: dict[str, Any] = {}
    if state:
        metadata["state"] = state
    if detail:
        metadata["detail"] = detail
    if error:
        metadata["error"] = error[:200]
        metadata["state"] = "error"
    if records is not None:
        metadata["records"] = records

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata=metadata,
    )


def mark_bbg_ships_freshness_pending(detail: str = "waiting for warm-up") -> None:
    """Show Bloomberg LNG Ships in Data Source Status before the first fetch."""
    try:
        cached = dashboard_cache.get(f"source:{SOURCE_NAME}")
        if cached is not None:
            detail = "serving disk cache · refresh in progress"
    except Exception:
        pass
    _register_freshness(state="pending", detail=detail)


def load_lng_data_bbg_ships() -> dict[str, Any]:
    """Load the current Bloomberg LNG tanker position snapshot into the cache."""
    try:
        from core.lng_data_bbg_ships.api import fetch_lng_ship_snapshot
        ships = fetch_lng_ship_snapshot()
        fetched_at = datetime.now(timezone.utc).isoformat()
        n = int(len(ships))
        try:
            from core.lng_data_bbg_ships.store import persist_hourly_snapshot
            persist_hourly_snapshot(ships, fetched_at)
        except Exception:
            logger.warning("Bloomberg hourly snapshot archive failed", exc_info=True)
        _register_freshness(state="ok", records=n, detail="fleet snapshot")
        return {"fetched_at": fetched_at, "ships": ships, "n_rows": n}
    except Exception as exc:
        logger.exception("Bloomberg LNG ships load failed: %s", exc)
        _register_freshness(error=str(exc))
        raise


def get_cached_bbg_ships_payload() -> dict[str, Any]:
    data: dict[str, Any] | None = dashboard_cache.get_data(SOURCE_NAME)
    if not data or not isinstance(data, dict):
        raise RuntimeError(
            "Bloomberg LNG ships cache is empty. "
            "Wait for warm-up (Bloomberg Terminal / B-PIPE), or click "
            "Refresh from Kpler API (also refreshes ship positions)."
        )
    return data


def get_bbg_ships() -> pd.DataFrame:
    payload = get_cached_bbg_ships_payload()
    ships = payload.get("ships")
    if ships is None or not isinstance(ships, pd.DataFrame):
        raise RuntimeError("Bloomberg LNG ships cache has no ships DataFrame.")
    try:
        from core.lng_data_bbg_ships.store import persist_hourly_snapshot
        persist_hourly_snapshot(ships, get_bbg_ships_last_refresh(payload))
    except Exception:
        logger.warning("Bloomberg hourly snapshot archive failed", exc_info=True)
    return ships


def get_bbg_ships_last_refresh(
    payload: dict[str, Any] | None = None,
) -> datetime | None:
    if payload is None:
        try:
            payload = get_cached_bbg_ships_payload()
        except RuntimeError:
            payload = None
    raw = payload.get("fetched_at") if payload else None
    if raw is not None:
        if isinstance(raw, datetime):
            return raw
        try:
            return datetime.fromisoformat(str(raw))
        except ValueError:
            pass
    return dashboard_cache.get_last_refresh(SOURCE_NAME)


def force_refresh_bbg_ships() -> dict[str, Any]:
    dashboard_cache.force_refresh(SOURCE_NAME)
    return get_cached_bbg_ships_payload()
