"""Write-once hourly archive of Bloomberg LNG ship snapshots.

The dashboard cache (``lng_data_bbg_ships``) only keeps the *latest* BSRCH
frame.  This store persists each hour permanently to S3 (nothing on local disk),
keyed by UTC hour, and maintains a slim IMO/lat/lon history for track
queries (also on S3, mirrored in memory).  Join to Kpler is always on IMO.
"""
from __future__ import annotations

import logging
import platform
import threading
from datetime import datetime, timedelta, timezone
from io import BytesIO

import pandas as pd

from core.lng_data_bbg_ships.constants import (
    HOURLY_FOLDER,
    POSITION_HIST_FILENAME,
    S3_PREFIX,
)

logger = logging.getLogger(__name__)

SLIM_COLUMNS = [
    "snapshot_at",
    "imo",
    "latitude",
    "longitude",
    "heading",
    "last_seen",
    "speed_knots",
    "cargo_status",
    "destination",
    "vessel_name",
]

_lock = threading.Lock()
_s3_client = None
_s3_bucket_name = None
_hist: pd.DataFrame | None = None
_hist_hours: set[pd.Timestamp] = set()


def _make_parquet_safe(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns[df.dtypes == object]:
        non_null = df[col].dropna()
        if not non_null.empty and not non_null.map(lambda v: isinstance(v, str)).all():
            df[col] = df[col].where(df[col].isna(), df[col].astype(str))
    return df


def _as_utc(value) -> datetime:
    if value is None:
        return datetime.now(timezone.utc)
    ts = pd.Timestamp(value)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    else:
        ts = ts.tz_convert("UTC")
    return ts.to_pydatetime()


def hour_key(value) -> datetime:
    """Floor *value* to the UTC hour used as the archive key."""
    dt = _as_utc(value).replace(minute=0, second=0, microsecond=0)
    return dt.replace(tzinfo=None)


def _filename(hour: datetime) -> str:
    return hour.strftime("%Y%m%d_%H") + ".parquet"


def _s3_key(hour: datetime, s3_prefix: str) -> str:
    return f"{s3_prefix.rstrip('/')}/{HOURLY_FOLDER}/{_filename(hour)}"


def _hist_key(s3_prefix: str) -> str:
    return f"{s3_prefix.rstrip('/')}/{POSITION_HIST_FILENAME}"


def _get_s3():
    global _s3_client, _s3_bucket_name
    if _s3_client is None:
        from jain_commods.core.cache.utils.s3 import AWS_BUCKET_NAME
        if platform.system().lower() == "windows":
            from jain_commods.core.cache.utils.s3 import S3
            _s3_client = S3().get_client()
        else:
            import boto3
            _s3_client = boto3.client("s3")
        _s3_bucket_name = AWS_BUCKET_NAME
    return _s3_client, _s3_bucket_name


def _put_parquet(df: pd.DataFrame, key: str) -> None:
    client, bucket = _get_s3()
    with BytesIO() as buffer:
        df.to_parquet(buffer, engine="pyarrow", compression="snappy")
        client.put_object(Bucket=bucket, Key=key, Body=buffer.getvalue())


def _get_parquet(key: str) -> pd.DataFrame | None:
    """Parquet at *key*, or None when missing/unreadable."""
    try:
        client, bucket = _get_s3()
        body = client.get_object(Bucket=bucket, Key=key)["Body"].read()
    except Exception:
        return None
    try:
        with BytesIO(body) as buffer:
            return pd.read_parquet(buffer, engine="pyarrow")
    except Exception as ex:
        logger.warning("Corrupt S3 Bloomberg parquet %s (%s)", key, ex)
        return None


def extract_position_rows(ships: pd.DataFrame, snapshot_at) -> pd.DataFrame:
    """Slim IMO/lat/lon rows from one BSRCH snapshot (join key = IMO)."""
    if ships is None or ships.empty or "imo" not in ships.columns:
        return pd.DataFrame(columns=SLIM_COLUMNS)

    imo = pd.to_numeric(ships["imo"], errors="coerce")
    lat = pd.to_numeric(ships.get("latitude"), errors="coerce")
    lon = pd.to_numeric(ships.get("longitude"), errors="coerce")
    heading = pd.to_numeric(ships["heading"], errors="coerce") if "heading" in ships.columns else pd.Series(pd.NA, index=ships.index)
    if "reported_speed_knots" in ships.columns:
        speed_src = ships["reported_speed_knots"]
    elif "reported_speed" in ships.columns:
        speed_src = ships["reported_speed"]
    else:
        speed_src = pd.Series(pd.NA, index=ships.index)
    speed = pd.to_numeric(speed_src, errors="coerce")
    last_seen = ships["last_seen"] if "last_seen" in ships.columns else pd.Series(pd.NaT, index=ships.index)
    if "normalized_destination" in ships.columns:
        dest = ships["normalized_destination"]
    elif "destination" in ships.columns:
        dest = ships["destination"]
    else:
        dest = pd.Series(pd.NA, index=ships.index)
    cargo = ships["cargo_status"] if "cargo_status" in ships.columns else pd.NA
    name = ships["vessel_name"] if "vessel_name" in ships.columns else pd.NA

    out = pd.DataFrame({
        "snapshot_at": pd.Timestamp(hour_key(snapshot_at)),
        "imo": imo,
        "latitude": lat,
        "longitude": lon,
        "heading": heading,
        "last_seen": pd.to_datetime(last_seen, errors="coerce", utc=True),
        "speed_knots": speed,
        "cargo_status": cargo,
        "destination": dest,
        "vessel_name": name,
    })
    out = out.dropna(subset=["imo"])
    out["imo"] = out["imo"].astype("int64")
    return out[SLIM_COLUMNS]


def reset_store_state() -> None:
    """Drop in-memory history (used by tests)."""
    global _hist
    _hist = None
    _hist_hours.clear()


def _empty_hist() -> pd.DataFrame:
    return pd.DataFrame(columns=SLIM_COLUMNS)


def _load_hist(s3_prefix: str) -> pd.DataFrame:
    global _hist
    if _hist is None:
        _hist = _get_parquet(_hist_key(s3_prefix))
        if _hist is None:
            _hist = _empty_hist()
        else:
            for col in SLIM_COLUMNS:
                if col not in _hist.columns:
                    _hist[col] = pd.NA
            _hist = _hist[SLIM_COLUMNS]
        if not _hist.empty:
            hours = pd.to_datetime(_hist["snapshot_at"], utc=True, errors="coerce")
            _hist_hours.update(hours.dt.tz_convert("UTC").dt.tz_localize(None).dt.floor("h"))
    return _hist


def _save_hist(hist: pd.DataFrame, s3_prefix: str) -> None:
    try:
        _put_parquet(hist, _hist_key(s3_prefix))
    except Exception as ex:
        logger.warning("Failed to persist Bloomberg position history: %s", ex)


def _append_hist(rows: pd.DataFrame, s3_prefix: str) -> None:
    global _hist
    if rows is None or rows.empty:
        return
    hist = _load_hist(s3_prefix)
    ts = pd.Timestamp(rows["snapshot_at"].iloc[0])
    if ts.tzinfo is not None:
        ts = ts.tz_convert("UTC").tz_localize(None)
    hour = ts.floor("h")
    if hour in _hist_hours:
        return
    if hist.empty:
        hist = rows.copy()
    else:
        hist = pd.concat([hist, rows], ignore_index=True)
    _hist = hist
    _hist_hours.add(hour)
    _save_hist(hist, s3_prefix)


def _s3_exists(hour: datetime, s3_prefix: str) -> bool:
    try:
        client, bucket = _get_s3()
        client.head_object(Bucket=bucket, Key=_s3_key(hour, s3_prefix))
        return True
    except Exception:
        return False


def persist_hourly_snapshot(
    ships: pd.DataFrame,
    fetched_at,
    *,
    s3_prefix: str = S3_PREFIX,
) -> bool:
    """Archive *ships* for its UTC hour.  Write-once; returns True if stored."""
    if ships is None or not isinstance(ships, pd.DataFrame) or ships.empty:
        return False
    hour = hour_key(fetched_at)
    with _lock:
        _load_hist(s3_prefix)
        if pd.Timestamp(hour) in _hist_hours or _s3_exists(hour, s3_prefix):
            _append_hist(extract_position_rows(ships, hour), s3_prefix)
            return False
        key = _s3_key(hour, s3_prefix)
        try:
            _put_parquet(_make_parquet_safe(ships), key)
        except Exception as ex:
            logger.warning("S3 Bloomberg snapshot write failed: %s", ex)
            return False
        logger.info("Stored Bloomberg LNG snapshot %s (%d rows)", key, len(ships))
        _append_hist(extract_position_rows(ships, hour), s3_prefix)
        return True


def _list_s3_hours(s3_prefix: str) -> set[datetime]:
    hours: set[datetime] = set()
    try:
        client, bucket = _get_s3()
        prefix = f"{s3_prefix.rstrip('/')}/{HOURLY_FOLDER}/"
        paginator = client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                name = obj["Key"].rsplit("/", 1)[-1]
                if name.endswith(".parquet"):
                    try:
                        hours.add(datetime.strptime(name[:11], "%Y%m%d_%H"))
                    except ValueError:
                        continue
    except Exception as ex:
        logger.warning("S3 Bloomberg snapshot listing failed: %s", ex)
    return hours


def get_position_history(
    imo: int,
    start: datetime | None = None,
    end: datetime | None = None,
    *,
    s3_prefix: str = S3_PREFIX,
) -> pd.DataFrame:
    """Slim Bloomberg positions for *imo* in [start, end], newest last.

    Joined to Kpler by IMO — this frame has no Kpler columns; callers
    already selected the vessel from the Kpler snapshot.
    """
    global _hist
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    end = hour_key(end or now)
    if start is None:
        start = end - timedelta(days=14)
    else:
        start = hour_key(start)

    with _lock:
        hist = _load_hist(s3_prefix)
        archived = _list_s3_hours(s3_prefix)

        missing_hours = [
            h for h in sorted(archived)
            if start <= h <= end and pd.Timestamp(h) not in _hist_hours
        ]
        new_frames = []
        for hour in missing_hours:
            raw = _get_parquet(_s3_key(hour, s3_prefix))
            if raw is None:
                continue
            rows = extract_position_rows(raw, hour)
            new_frames.append(rows)
            _hist_hours.add(pd.Timestamp(hour))

        if new_frames:
            if hist.empty:
                hist = pd.concat(new_frames, ignore_index=True)
            else:
                hist = pd.concat([hist] + new_frames, ignore_index=True)
            _hist = hist
            _save_hist(hist, s3_prefix)

        if hist.empty:
            return _empty_hist()

        imos = pd.to_numeric(hist["imo"], errors="coerce")
        at = pd.to_datetime(hist["snapshot_at"], errors="coerce")
        if getattr(at.dt, "tz", None) is not None:
            at = at.dt.tz_convert("UTC").dt.tz_localize(None)
        mask = (imos == int(imo)) & (at >= pd.Timestamp(start)) & (at <= pd.Timestamp(end))
        out = hist.loc[mask].copy()
        out["_when"] = pd.to_datetime(out["last_seen"], errors="coerce")
        fallback = pd.to_datetime(out["snapshot_at"], errors="coerce")
        out["_when"] = out["_when"].fillna(fallback)
        out = out.dropna(subset=["latitude", "longitude"])
        return out.sort_values("_when").drop(columns=["_when"], errors="ignore")
