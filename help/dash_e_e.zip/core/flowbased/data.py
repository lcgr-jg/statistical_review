"""
Flow-Based page — data loading.

Strategy: each underlying class (MaxBex, NetCommercialFlowDayAhead,
MinMaxNetPos, JaoNetPosition, DayAheadNTC, NTC) is loaded **once** as a
full-history DataFrame, cached:
  * on disk via ``core.cache.dashboard_cache`` (survives restarts, fast reload), and
  * in memory for the calendar day.

``load_flowbased_data(start, end)`` becomes a pure slice over those frames —
no S3 round-trip on zone/date changes in the UI.

A scheduled refresh is wired in ``portal_app.py`` via
``dashboard_cache.register_source('flowbased_data', refresh_flowbased_cache, …)``.
"""
from __future__ import annotations

import datetime as dt
import logging
from typing import Callable, Optional

import pandas as pd

from core.flowbased.constants import CORE_FBMC_NEIGHBOURS

logger = logging.getLogger(__name__)

# ── jain_commods import guard ────────────────────────────────────────────
try:
    from jain_commods.core.cache.data.fundamentals import (  # type: ignore
        MaxBex,
        NetCommercialFlowDayAhead,
    )
    _COMMODS = True
except ImportError as exc:
    logger.warning("jain_commods not available: %s", exc)
    _COMMODS = False

try:
    from jain_commods.core.cache.data.fundamentals import (  # type: ignore
        JaoNetPosition,
        MinMaxNetPos,
    )
    _JAO_NP = True
except ImportError as exc:
    logger.warning("JaoNetPosition / MinMaxNetPos not available: %s", exc)
    _JAO_NP = False

try:
    from jain_commods.core.cache.data.fundamentals import (  # type: ignore
        NTC,
        DayAheadNTC,
    )
    _NTC = True
except ImportError as exc:
    logger.warning("NTC / DayAheadNTC not available: %s", exc)
    _NTC = False


# ── Caching configuration ────────────────────────────────────────────────
# Disk-cache key prefix and TTL for full-history frames. TTL is generous —
# the scheduled refresh in portal_app pushes fresh data; the TTL is the
# safety net if scheduling is disabled.
_FULL_PREFIX = "flowbased_full:"
_FULL_TTL = 21_600  # 6 hours

# Earliest date we try to pull for full history (JAO publishes from 2022-06-09).
_HISTORY_START = dt.date(2022, 6, 9)
# Forward window for REMIT NTC nominations.
_FUTURE_HORIZON_DAYS = 60

# In-memory mirror keyed by class name: {"date": today, "df": <DataFrame>}.
_FULL_CACHE: dict[str, dict] = {}


def _get_dc():
    try:
        from core.cache import dashboard_cache  # noqa: PLC0415
        return dashboard_cache
    except Exception:
        return None


def _normalize_hourly_index(df: pd.DataFrame) -> pd.DataFrame:
    """Coerce the index to CET-naive hourly timestamps."""
    if df is None or df.empty:
        return df
    out = df.copy()
    ix = pd.to_datetime(out.index)
    if ix.tz is None:
        ix = ix.tz_localize("UTC")
    ix = ix.tz_convert("Europe/Paris").tz_localize(None)
    out.index = ix
    return out


def _load_full(
    name: str,
    ClassObj,
    *,
    available: bool,
    start_date: dt.date,
    end_date: dt.date,
    force: bool = False,
) -> pd.DataFrame:
    """Load full-history frame for one underlying class, two-tier cached.

    Order: in-memory (today only) → disk → S3. ``force=True`` skips both
    caches and refreshes from S3 (used by the scheduled refresh).
    """
    today = dt.date.today()
    if not force:
        mem = _FULL_CACHE.get(name)
        if mem and mem["date"] == today and not mem["df"].empty:
            return mem["df"]

        dc = _get_dc()
        if dc is not None:
            try:
                cached = dc.get(f"{_FULL_PREFIX}{name}", ttl=_FULL_TTL)
                if isinstance(cached, pd.DataFrame) and not cached.empty:
                    _FULL_CACHE[name] = {"date": today, "df": cached}
                    logger.info(
                        "Flow-Based full-history HIT (disk) %s: %d rows, %d cols",
                        name, len(cached), cached.shape[1],
                    )
                    return cached
            except Exception as exc:
                logger.debug("Disk cache get failed for %s: %s", name, exc)

    if not available:
        return pd.DataFrame()

    logger.info("Flow-Based full-history MISS — loading %s from S3", name)
    try:
        obj = ClassObj()
        obj.load(
            from_s3=True,
            show_metadata=False,
            start_date=start_date,
            end_date=end_date,
        )
        df = getattr(obj, "data", None)
    except Exception as exc:
        logger.warning("%s full-history load failed: %s", name, exc)
        return pd.DataFrame()

    if df is None or df.empty:
        return pd.DataFrame()

    df = _normalize_hourly_index(df)
    df.columns = [str(c).lower() for c in df.columns]
    _FULL_CACHE[name] = {"date": today, "df": df}

    dc = _get_dc()
    if dc is not None:
        try:
            dc.set(f"{_FULL_PREFIX}{name}", df, ttl=_FULL_TTL)
        except Exception as exc:
            logger.warning("Disk cache set failed for %s: %s", name, exc)

    logger.info(
        "%s full-history loaded: %d rows, %d cols (%s → %s)",
        name, len(df), df.shape[1], df.index.min(), df.index.max(),
    )
    return df


def _slice(df: pd.DataFrame, start: dt.date, end: dt.date) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    mask = (df.index.date >= start) & (df.index.date <= end)
    return df.loc[mask]


# ── Public: scheduled refresh ────────────────────────────────────────────

def refresh_flowbased_cache() -> dict:
    """Force-refresh every full-history frame from S3 and re-prime the disk cache.

    Wired into ``dashboard_cache.register_source`` so it runs on a cron schedule.
    """
    today = dt.date.today()
    future_end = today + dt.timedelta(days=_FUTURE_HORIZON_DAYS)
    spec = _full_history_spec(today, future_end)
    summary = {}
    for name, (cls, available, start_date, end_date) in spec.items():
        df = _load_full(
            name, cls,
            available=available,
            start_date=start_date,
            end_date=end_date,
            force=True,
        )
        summary[name] = {"rows": len(df), "cols": df.shape[1] if not df.empty else 0}
    logger.info("Flow-Based refresh complete: %s", summary)
    return summary


def clear_flowbased_cache() -> None:
    """Clear both in-memory and disk-backed full-history caches."""
    _FULL_CACHE.clear()
    dc = _get_dc()
    if dc is not None:
        try:
            dc.clear(prefix=_FULL_PREFIX)
            logger.info("Flow-Based disk cache cleared (prefix=%s)", _FULL_PREFIX)
        except Exception as exc:
            logger.warning("Failed to clear flow-based disk cache: %s", exc)


def _full_history_spec(today: dt.date, future_end: dt.date) -> dict:
    """(start, end) per class — NTC needs the forward window, others are historical."""
    return {
        "maxbex": (MaxBex if _COMMODS else None, _COMMODS, _HISTORY_START, today),
        "flow": (NetCommercialFlowDayAhead if _COMMODS else None, _COMMODS, _HISTORY_START, today),
        "minmax_netpos": (MinMaxNetPos if _JAO_NP else None, _JAO_NP, _HISTORY_START, today),
        "jao_net_position": (JaoNetPosition if _JAO_NP else None, _JAO_NP, _HISTORY_START, today),
        "ntc_da": (DayAheadNTC if _NTC else None, _NTC, _HISTORY_START, today),
        "ntc": (NTC if _NTC else None, _NTC, today - dt.timedelta(days=30), future_end),
    }


def _ensure_loaded() -> dict[str, pd.DataFrame]:
    """Return full-history frames, loading any missing class on-demand."""
    today = dt.date.today()
    future_end = today + dt.timedelta(days=_FUTURE_HORIZON_DAYS)
    spec = _full_history_spec(today, future_end)
    out: dict[str, pd.DataFrame] = {}
    for name, (cls, available, start_date, end_date) in spec.items():
        out[name] = _load_full(
            name, cls,
            available=available,
            start_date=start_date,
            end_date=end_date,
        )
    return out


# ── Public: per-request bundle (date-sliced) ─────────────────────────────

def load_flowbased_data(
    start: Optional[dt.date] = None,
    end: Optional[dt.date] = None,
) -> dict[str, pd.DataFrame]:
    """Return a bundle of date-sliced DataFrames for the Flow-Based page.

    The underlying full-history frames are cached on disk and in memory and
    are only re-fetched on the scheduled refresh — so changing the UI's
    zone or date range is an in-memory slice, not an S3 round-trip.
    """
    today = dt.date.today()
    if end is None:
        end = today
    if start is None:
        start = end - dt.timedelta(days=14)

    full = _ensure_loaded()
    return {name: _slice(df, start, end) for name, df in full.items()}


# ── Convenience accessors for a single zone ──────────────────────────────

def get_zone_border_series(
    bundle: dict[str, pd.DataFrame],
    zone: str,
    neighbour: str,
) -> dict[str, pd.Series]:
    """Extract MaxBex + commercial-flow series for a single (zone, neighbour)."""
    mb = bundle.get("maxbex", pd.DataFrame())
    fl = bundle.get("flow", pd.DataFrame())

    def _col(df: pd.DataFrame, name: str) -> pd.Series:
        if df is None or df.empty or name not in df.columns:
            return pd.Series(dtype="float64")
        return df[name].dropna()

    return {
        "maxbex_pos": _col(mb, f"{zone}-{neighbour}"),
        "maxbex_neg": _col(mb, f"{neighbour}-{zone}"),
        "flow_commercial": _col(fl, f"{zone}>{neighbour}"),
    }


def get_zone_net_position_series(
    bundle: dict[str, pd.DataFrame],
    zone: str,
) -> dict[str, pd.Series]:
    """Extract min/max/net-position series for a single zone."""
    mm = bundle.get("minmax_netpos", pd.DataFrame())
    np_df = bundle.get("jao_net_position", pd.DataFrame())

    def _col(df: pd.DataFrame, name: str) -> pd.Series:
        if df is None or df.empty or name not in df.columns:
            return pd.Series(dtype="float64")
        return df[name].dropna()

    return {
        "min": _col(mm, f"{zone}_min"),
        "max": _col(mm, f"{zone}_max"),
        "net_position": _col(np_df, zone),
    }


# ── Full-history accessors (used by the YoY columns) ─────────────────────

def load_minmax_full_history() -> pd.DataFrame:
    """Return the full MinMaxNetPos DataFrame (cached)."""
    today = dt.date.today()
    return _load_full(
        "minmax_netpos", MinMaxNetPos if _JAO_NP else None,
        available=_JAO_NP, start_date=_HISTORY_START, end_date=today,
    )


def load_maxbex_full_history() -> pd.DataFrame:
    """Return the full MaxBex DataFrame (cached)."""
    today = dt.date.today()
    return _load_full(
        "maxbex", MaxBex if _COMMODS else None,
        available=_COMMODS, start_date=_HISTORY_START, end_date=today,
    )


# ── NTC helpers ──────────────────────────────────────────────────────────

def _is_fb_border(zone: str, neighbour: str) -> bool:
    """True if (zone, neighbour) is a flow-based interconnector (CORE FBMC)."""
    if zone == neighbour:
        return False
    z_nb = CORE_FBMC_NEIGHBOURS.get(zone, [])
    nb_z = CORE_FBMC_NEIGHBOURS.get(neighbour, [])
    return neighbour in z_nb or zone in nb_z


def get_ntc_neighbours(bundle: dict[str, pd.DataFrame], zone: str) -> list[str]:
    """Non-FB neighbours of ``zone`` discovered from NTC / DayAheadNTC columns."""
    z = zone.lower()
    found: set[str] = set()
    for key in ("ntc", "ntc_da"):
        df = bundle.get(key, pd.DataFrame())
        if df is None or df.empty:
            continue
        for col in df.columns:
            if ">" not in col:
                continue
            src, _, dst = col.partition(">")
            if src == z:
                found.add(dst)
            elif dst == z:
                found.add(src)
    return sorted(n for n in found if not _is_fb_border(z, n))


def get_zone_ntc_series(
    bundle: dict[str, pd.DataFrame],
    zone: str,
    neighbour: str,
) -> dict[str, pd.Series]:
    """Extract NTC + flow series for a single (zone, neighbour) pair."""
    ntc = bundle.get("ntc", pd.DataFrame())
    ntc_da = bundle.get("ntc_da", pd.DataFrame())
    fl = bundle.get("flow", pd.DataFrame())

    def _col(df: pd.DataFrame, name: str) -> pd.Series:
        if df is None or df.empty or name not in df.columns:
            return pd.Series(dtype="float64")
        return df[name].dropna()

    fwd = f"{zone}>{neighbour}"
    rev = f"{neighbour}>{zone}"
    return {
        "ntc_da_pos": _col(ntc_da, fwd),
        "ntc_da_neg": _col(ntc_da, rev),
        "ntc_pos": _col(ntc, fwd),
        "ntc_neg": _col(ntc, rev),
        "flow_commercial": _col(fl, fwd),
    }
