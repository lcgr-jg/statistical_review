"""
Flow-Based dashboard — Dash callbacks.

Registered via side-effect import in pages/flowbased.py.

Builds the MaxBex tab: one subplot per border (subplot title ``ZONE>NEIGHBOUR``).
Each subplot shows:
  • MaxBex **export** limit (``zone-neighbour``) — positive line, aligned with commercial ``zone>neighbour``
  • MaxBex **import** limit (``neighbour-zone``) — negative line (sign flipped)
  • Blue-shaded regions above export / below import limits (infeasible zones)
  • NetCommercialFlowDayAhead for ``zone>neighbour`` only — signed MW
"""
from __future__ import annotations

import sys
from pathlib import Path

# ``core`` resolves to ``eu_dashboard_power/core``; running this file directly
# (e.g. for a quick import check) must put the app root on sys.path first.
_APP_ROOT = Path(__file__).resolve().parents[2]
if str(_APP_ROOT) not in sys.path:
    sys.path.insert(0, str(_APP_ROOT))

import datetime as dt
import logging
import math
from typing import Optional

import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, callback
from plotly.subplots import make_subplots

from core.flowbased.constants import CORE_FBMC_NEIGHBOURS, JAO_NET_POSITION_ZONES
from core.flowbased.data import (
    get_ntc_neighbours,
    get_zone_border_series,
    get_zone_net_position_series,
    get_zone_ntc_series,
    load_flowbased_data,
    load_maxbex_full_history,
    load_minmax_full_history,
)
from core.styles import COLORS

logger = logging.getLogger(__name__)

# ── Colours / styling ────────────────────────────────────────────────────
_COLOR_MAXBEX = COLORS.get("accent_dark", "#3d5c6f")
_COLOR_FLOW = COLORS.get("accent_yellow", "#d29922")
_COLOR_SHADE = "rgba(78, 115, 138, 0.18)"  # translucent blue (matches accent)
_COLOR_ZERO = "#888888"

_MAX_COLS = 3
_ROW_HEIGHT = 240  # px per row in the figure


def _parse_date(value) -> Optional[dt.date]:
    if value is None:
        return None
    if isinstance(value, dt.date) and not isinstance(value, dt.datetime):
        return value
    try:
        return pd.to_datetime(value).date()
    except Exception:
        return None


def _filter_series(s: pd.Series, start: dt.date, end: dt.date) -> pd.Series:
    if s is None or s.empty:
        return s
    mask = (s.index.date >= start) & (s.index.date <= end)
    return s.loc[mask]


def _empty_figure(message: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        annotations=[
            dict(
                text=message,
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5,
                showarrow=False,
                font=dict(size=14, color=COLORS["text_muted"]),
            )
        ],
        plot_bgcolor=COLORS["chart_bg"],
        paper_bgcolor=COLORS["chart_paper"],
        margin=dict(l=20, r=20, t=30, b=20),
    )
    return fig


def _build_maxbex_figure(
    zone: str,
    neighbours: list[str],
    bundle: dict,
    full_maxbex: pd.DataFrame,
    start: dt.date,
    end: dt.date,
) -> go.Figure:
    """Per-neighbour rows × 3 cols: main chart, export YoY, import YoY."""
    if not neighbours:
        return _empty_figure(f"No CORE FBMC neighbours for {zone.upper()}")

    n_rows = len(neighbours)
    subplot_titles: list[str] = []
    for nb in neighbours:
        z_up, nb_up = zone.upper(), nb.upper()
        subplot_titles.extend(
            [
                f"{z_up}>{nb_up}",
                f"{z_up}>{nb_up} export · 7d MA YoY",
                f"{nb_up}>{z_up} import · 7d MA YoY",
            ]
        )

    v_spacing = min(0.08, 0.9 / max(1, n_rows - 1)) if n_rows > 1 else 0.0
    fig = make_subplots(
        rows=n_rows,
        cols=3,
        subplot_titles=subplot_titles,
        column_widths=[0.5, 0.25, 0.25],
        horizontal_spacing=0.045,
        vertical_spacing=v_spacing,
    )

    # Shared year palette across the YoY columns
    if full_maxbex is not None and not full_maxbex.empty:
        all_years = sorted(set(full_maxbex.index.year.unique().tolist()))
    else:
        all_years = []
    year_colors = _year_color_map(all_years)
    legend_seen: set[str] = set()

    any_main_data = False

    for row_idx, nb in enumerate(neighbours, start=1):
        first_neighbour = row_idx == 1
        series = get_zone_border_series(bundle, zone=zone, neighbour=nb)
        mb_pos = _filter_series(series["maxbex_pos"], start, end)
        mb_neg = _filter_series(series["maxbex_neg"], start, end)
        fl_com = _filter_series(series["flow_commercial"], start, end)

        # ── Column 1: existing main chart ───────────────────────────────
        has_any = not (mb_pos.empty and mb_neg.empty and fl_com.empty)
        any_main_data = any_main_data or has_any

        if not has_any:
            fig.add_annotation(
                text="No data in selected range",
                x=0.5, y=0.5, xref="paper", yref="paper",
                showarrow=False,
                font=dict(size=11, color=COLORS["text_muted"]),
                row=row_idx, col=1,
            )
        else:
            # MaxBex export limit (zone→nb), positive
            if not mb_pos.empty:
                fig.add_trace(
                    go.Scatter(
                        x=mb_pos.index, y=mb_pos.values, mode="lines",
                        name="Export limit", legendgroup="maxbex_pos",
                        showlegend=first_neighbour,
                        line=dict(color=_COLOR_MAXBEX, width=1.5),
                        hovertemplate=(
                            f"<b>{zone.upper()}→{nb.upper()} (export, {zone}-{nb})</b><br>"
                            "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=1,
                )
                y_top_candidates = [float(mb_pos.max())]
                if not fl_com.empty:
                    y_top_candidates.append(float(fl_com.max()))
                y_top = max(y_top_candidates) * 1.05
                fig.add_trace(
                    go.Scatter(
                        x=list(mb_pos.index) + list(mb_pos.index[::-1]),
                        y=list(mb_pos.values) + [y_top] * len(mb_pos),
                        fill="toself", fillcolor=_COLOR_SHADE,
                        line=dict(width=0), hoverinfo="skip",
                        name="Infeasible (above export)", legendgroup="shade_pos",
                        showlegend=first_neighbour,
                    ),
                    row=row_idx, col=1,
                )

            # MaxBex import limit (nb→zone), plotted negative
            if not mb_neg.empty:
                mb_neg_plot = -mb_neg
                fig.add_trace(
                    go.Scatter(
                        x=mb_neg_plot.index, y=mb_neg_plot.values, mode="lines",
                        name="Import limit", legendgroup="maxbex_neg",
                        showlegend=False,
                        line=dict(color=_COLOR_MAXBEX, width=1.5),
                        hovertemplate=(
                            f"<b>{nb.upper()}→{zone.upper()} (import, {nb}-{zone})</b><br>"
                            "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=1,
                )
                y_bot_candidates = [float(mb_neg_plot.min())]
                if not fl_com.empty:
                    y_bot_candidates.append(float(fl_com.min()))
                y_bot = min(y_bot_candidates) * 1.05
                fig.add_trace(
                    go.Scatter(
                        x=list(mb_neg_plot.index) + list(mb_neg_plot.index[::-1]),
                        y=list(mb_neg_plot.values) + [y_bot] * len(mb_neg_plot),
                        fill="toself", fillcolor=_COLOR_SHADE,
                        line=dict(width=0), hoverinfo="skip",
                        name="Infeasible (below import)", legendgroup="shade_neg",
                        showlegend=first_neighbour,
                    ),
                    row=row_idx, col=1,
                )

            # Commercial flow zone>nb (signed)
            if not fl_com.empty:
                fig.add_trace(
                    go.Scatter(
                        x=fl_com.index, y=fl_com.values, mode="lines",
                        name="Commercial flow (DA)", legendgroup="flow",
                        showlegend=first_neighbour,
                        line=dict(color=_COLOR_FLOW, width=1.5),
                        hovertemplate=(
                            f"<b>{zone.upper()}>{nb.upper()} (NetCommercialFlowDayAhead)</b><br>"
                            "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=1,
                )

            fig.add_hline(
                y=0, line=dict(color=_COLOR_ZERO, width=0.8, dash="dash"),
                row=row_idx, col=1,
            )

        fig.update_yaxes(title_text="MW", row=row_idx, col=1)

        # ── Columns 2 & 3: export YoY (zone-nb) and import YoY (nb-zone) ─
        yoy_specs = (
            (2, f"{zone}-{nb}", "export", f"{zone.upper()}→{nb.upper()}"),
            (3, f"{nb}-{zone}", "import", f"{nb.upper()}→{zone.upper()}"),
        )
        for yoy_col_idx, key, side_label, dir_label in yoy_specs:
            if full_maxbex is None or full_maxbex.empty or key not in full_maxbex.columns:
                fig.add_annotation(
                    text="No history",
                    x=0.5, y=0.5, xref="paper", yref="paper",
                    showarrow=False,
                    font=dict(size=10, color=COLORS["text_muted"]),
                    row=row_idx, col=yoy_col_idx,
                )
                continue

            years_dict = _yoy_year_traces(full_maxbex[key])
            if not years_dict:
                fig.add_annotation(
                    text="No history",
                    x=0.5, y=0.5, xref="paper", yref="paper",
                    showarrow=False,
                    font=dict(size=10, color=COLORS["text_muted"]),
                    row=row_idx, col=yoy_col_idx,
                )
                continue

            for year in sorted(years_dict.keys()):
                s = years_dict[year]
                legend_key = f"yoy_{year}"
                show = legend_key not in legend_seen
                legend_seen.add(legend_key)
                fig.add_trace(
                    go.Scatter(
                        x=s.index, y=s.values, mode="lines",
                        name=str(year), legendgroup=legend_key,
                        showlegend=show,
                        line=dict(color=year_colors.get(year), width=1.4),
                        hovertemplate=(
                            f"<b>{dir_label} {side_label} · {year}</b><br>"
                            "%{x|%b %d}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=yoy_col_idx,
                )

            fig.update_xaxes(
                tickformat="%b %d",
                dtick="M2",
                row=row_idx, col=yoy_col_idx,
            )

    if not any_main_data and not all_years:
        return _empty_figure(
            f"No MaxBex / flow data available for {zone.upper()}"
        )

    row_h = 300
    fig.update_layout(
        height=max(700, n_rows * row_h + 160),
        plot_bgcolor=COLORS["chart_bg"],
        paper_bgcolor=COLORS["chart_paper"],
        margin=dict(l=60, r=20, t=72, b=88),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.0 + 30 / (n_rows * row_h + 160),
            yref="paper",
            xanchor="center",
            x=0.5,
            font=dict(size=11),
            bgcolor="rgba(0,0,0,0)",
            borderwidth=0,
        ),
        hovermode="closest",
    )
    fig.update_annotations(font=dict(size=11))
    fig.update_xaxes(
        showgrid=True,
        gridcolor=COLORS["border_light"],
        showline=True,
        linecolor=COLORS["border"],
        ticklabelstandoff=6,
    )
    fig.update_yaxes(
        showgrid=True,
        gridcolor=COLORS["border_light"],
        zeroline=False,
        showline=True,
        linecolor=COLORS["border"],
    )
    return fig


# ── Net Position grid (all zones, YoY columns) ────────────────────────────

# Reference (leap) year used to overlay every year's series on a common axis.
_YOY_REF_YEAR = 2000


def _yoy_year_traces(series: pd.Series, window_days: int = 7) -> dict[int, pd.Series]:
    """7-day rolling daily mean, split by year, indexed by (ref-year) month-day.

    Each year is mapped onto ``_YOY_REF_YEAR`` so multiple years can be plotted
    on a shared x-axis with ``tickformat='%b %d'``.
    """
    if series is None or series.empty:
        return {}
    daily = series.resample("1D").mean()
    rolled = daily.rolling(window_days, min_periods=1).mean()
    out: dict[int, pd.Series] = {}
    for year, group in rolled.groupby(rolled.index.year):
        if group.empty:
            continue
        new_idx = pd.to_datetime(
            [ts.replace(year=_YOY_REF_YEAR) for ts in group.index]
        )
        out[int(year)] = pd.Series(group.values, index=new_idx).sort_index()
    return out


def _year_color_map(years: list[int]) -> dict[int, str]:
    """Sequential palette across the observed years (older → lighter)."""
    if not years:
        return {}
    import plotly.colors as pc

    if len(years) == 1:
        return {years[0]: pc.qualitative.Plotly[0]}
    sampled = pc.sample_colorscale(
        pc.sequential.Viridis,
        [i / (len(years) - 1) for i in range(len(years))],
    )
    return dict(zip(sorted(years), sampled))


def _build_net_position_grid(
    bundle: dict,
    full_minmax: pd.DataFrame,
    zones: list[str],
    start: dt.date,
    end: dt.date,
) -> go.Figure:
    """All CORE zones stacked vertically; cols are (main chart | min YoY | max YoY)."""
    if not zones:
        return _empty_figure("No CORE FBMC zones configured")

    n_rows = len(zones)
    subplot_titles: list[str] = []
    for z in zones:
        z_up = z.upper()
        subplot_titles.extend(
            [
                f"{z_up} net position",
                f"{z_up} import · 7d MA YoY",
                f"{z_up} export · 7d MA YoY",
            ]
        )

    # Pick a vertical_spacing big enough that subplot titles clear the prior
    # row's x-axis labels (Plotly caps it at 1/(rows-1)). Pair with a larger
    # per-row pixel height so the subplots don't shrink to compensate.
    v_spacing = min(0.06, 0.9 / max(1, n_rows - 1)) if n_rows > 1 else 0.0
    fig = make_subplots(
        rows=n_rows,
        cols=3,
        subplot_titles=subplot_titles,
        column_widths=[0.5, 0.25, 0.25],
        horizontal_spacing=0.045,
        vertical_spacing=v_spacing,
    )

    # Determine years present in the full-history frame (once, for shared legend).
    if full_minmax is not None and not full_minmax.empty:
        all_years = sorted(set(full_minmax.index.year.unique().tolist()))
    else:
        all_years = []
    year_colors = _year_color_map(all_years)
    legend_seen: set[str] = set()

    any_main_data = False

    for row_idx, zone in enumerate(zones, start=1):
        first_zone = row_idx == 1
        # ── Column 1: per-zone min/max/net-position chart ───────────────
        series = get_zone_net_position_series(bundle, zone=zone)
        mn = _filter_series(series["min"], start, end)
        mx = _filter_series(series["max"], start, end)
        np_s = _filter_series(series["net_position"], start, end)
        has_any = not (mn.empty and mx.empty and np_s.empty)
        any_main_data = any_main_data or has_any

        if not has_any:
            fig.add_annotation(
                text="No data in selected range",
                x=0.5, y=0.5, xref="paper", yref="paper",
                showarrow=False,
                font=dict(size=11, color=COLORS["text_muted"]),
                row=row_idx, col=1,
            )
        else:
            if not mx.empty:
                fig.add_trace(
                    go.Scatter(
                        x=mx.index, y=mx.values, mode="lines",
                        name="Export limit", legendgroup="export",
                        showlegend=first_zone,
                        line=dict(color=_COLOR_MAXBEX, width=1.5),
                        hovertemplate=(
                            f"<b>{zone.upper()} export</b><br>"
                            "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=1,
                )
                y_top_candidates = [float(mx.max())]
                if not np_s.empty:
                    y_top_candidates.append(float(np_s.max()))
                y_top = max(y_top_candidates) * 1.05
                fig.add_trace(
                    go.Scatter(
                        x=list(mx.index) + list(mx.index[::-1]),
                        y=list(mx.values) + [y_top] * len(mx),
                        fill="toself", fillcolor=_COLOR_SHADE,
                        line=dict(width=0), hoverinfo="skip",
                        name="Infeasible (above export)", legendgroup="shade_export",
                        showlegend=first_zone,
                    ),
                    row=row_idx, col=1,
                )

            if not mn.empty:
                fig.add_trace(
                    go.Scatter(
                        x=mn.index, y=mn.values, mode="lines",
                        name="Import limit", legendgroup="import",
                        showlegend=False,
                        line=dict(color=_COLOR_MAXBEX, width=1.5),
                        hovertemplate=(
                            f"<b>{zone.upper()} import</b><br>"
                            "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=1,
                )
                y_bot_candidates = [float(mn.min())]
                if not np_s.empty:
                    y_bot_candidates.append(float(np_s.min()))
                y_bot = min(y_bot_candidates) * 1.05
                fig.add_trace(
                    go.Scatter(
                        x=list(mn.index) + list(mn.index[::-1]),
                        y=list(mn.values) + [y_bot] * len(mn),
                        fill="toself", fillcolor=_COLOR_SHADE,
                        line=dict(width=0), hoverinfo="skip",
                        name="Infeasible (below import)", legendgroup="shade_import",
                        showlegend=first_zone,
                    ),
                    row=row_idx, col=1,
                )

            if not np_s.empty:
                fig.add_trace(
                    go.Scatter(
                        x=np_s.index, y=np_s.values, mode="lines",
                        name="Net position (JAO)", legendgroup="netpos",
                        showlegend=first_zone,
                        line=dict(color=_COLOR_FLOW, width=1.5),
                        hovertemplate=(
                            f"<b>{zone.upper()} JaoNetPosition</b><br>"
                            "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=1,
                )

            fig.add_hline(
                y=0, line=dict(color=_COLOR_ZERO, width=0.8, dash="dash"),
                row=row_idx, col=1,
            )

        fig.update_yaxes(title_text="MW", row=row_idx, col=1)

        # ── Columns 2 & 3: YoY of {zone}_min (= import) and {zone}_max (= export) ─
        for yoy_col_idx, key, side_label in (
            (2, f"{zone}_min", "import"),
            (3, f"{zone}_max", "export"),
        ):
            if full_minmax is None or full_minmax.empty or key not in full_minmax.columns:
                fig.add_annotation(
                    text="No history",
                    x=0.5, y=0.5, xref="paper", yref="paper",
                    showarrow=False,
                    font=dict(size=10, color=COLORS["text_muted"]),
                    row=row_idx, col=yoy_col_idx,
                )
                continue

            years_dict = _yoy_year_traces(full_minmax[key])
            if not years_dict:
                fig.add_annotation(
                    text="No history",
                    x=0.5, y=0.5, xref="paper", yref="paper",
                    showarrow=False,
                    font=dict(size=10, color=COLORS["text_muted"]),
                    row=row_idx, col=yoy_col_idx,
                )
                continue

            for year in sorted(years_dict.keys()):
                s = years_dict[year]
                legend_key = f"yoy_{year}"
                show = legend_key not in legend_seen
                legend_seen.add(legend_key)
                fig.add_trace(
                    go.Scatter(
                        x=s.index, y=s.values, mode="lines",
                        name=str(year), legendgroup=legend_key,
                        showlegend=show,
                        line=dict(color=year_colors.get(year), width=1.4),
                        hovertemplate=(
                            f"<b>{zone.upper()} {side_label} · {year}</b><br>"
                            "%{x|%b %d}<br>%{y:,.0f} MW<extra></extra>"
                        ),
                    ),
                    row=row_idx, col=yoy_col_idx,
                )

            fig.update_xaxes(
                tickformat="%b %d",
                dtick="M2",
                row=row_idx, col=yoy_col_idx,
            )

    if not any_main_data and not all_years:
        return _empty_figure("No JAO net-position data available")

    # ── Layout ──────────────────────────────────────────────────────────
    row_h = 300  # px per row
    fig.update_layout(
        height=max(700, n_rows * row_h + 160),
        plot_bgcolor=COLORS["chart_bg"],
        paper_bgcolor=COLORS["chart_paper"],
        margin=dict(l=60, r=20, t=72, b=88),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.0 + 30 / (n_rows * row_h + 160),
            yref="paper",
            xanchor="center",
            x=0.5,
            font=dict(size=11),
            bgcolor="rgba(0,0,0,0)",
            borderwidth=0,
        ),
        hovermode="closest",
    )
    fig.update_annotations(font=dict(size=11))
    fig.update_xaxes(
        showgrid=True,
        gridcolor=COLORS["border_light"],
        showline=True,
        linecolor=COLORS["border"],
        ticklabelstandoff=6,
    )
    fig.update_yaxes(
        showgrid=True,
        gridcolor=COLORS["border_light"],
        zeroline=False,
        showline=True,
        linecolor=COLORS["border"],
    )
    return fig


# ── Callbacks ─────────────────────────────────────────────────────────────

@callback(
    Output("flowbased-maxbex-graph", "figure"),
    Input("flowbased-maxbex-zone", "value"),
    Input("flowbased-maxbex-date-range", "start_date"),
    Input("flowbased-maxbex-date-range", "end_date"),
)
def update_maxbex_chart(zone, start_date, end_date):
    zone = (zone or "fr").lower()
    neighbours = CORE_FBMC_NEIGHBOURS.get(zone, [])

    start = _parse_date(start_date) or (dt.date.today() - dt.timedelta(days=14))
    end = _parse_date(end_date) or dt.date.today()
    if start > end:
        start, end = end, start

    try:
        bundle = load_flowbased_data(start=start, end=end)
    except Exception as exc:
        logger.exception("Failed to load flow-based data: %s", exc)
        return _empty_figure(f"Failed to load data: {exc}")

    try:
        full_maxbex = load_maxbex_full_history()
    except Exception as exc:
        logger.exception("Failed to load full MaxBex history: %s", exc)
        full_maxbex = pd.DataFrame()

    return _build_maxbex_figure(zone, neighbours, bundle, full_maxbex, start, end)


@callback(
    Output("flowbased-netpos-graph", "figure"),
    Input("flowbased-netpos-date-range", "start_date"),
    Input("flowbased-netpos-date-range", "end_date"),
)
def update_net_position_chart(start_date, end_date):
    start = _parse_date(start_date) or (dt.date.today() - dt.timedelta(days=14))
    end = _parse_date(end_date) or dt.date.today()
    if start > end:
        start, end = end, start

    try:
        bundle = load_flowbased_data(start=start, end=end)
    except Exception as exc:
        logger.exception("Failed to load flow-based data: %s", exc)
        return _empty_figure(f"Failed to load data: {exc}")

    try:
        full_minmax = load_minmax_full_history()
    except Exception as exc:
        logger.exception("Failed to load full MinMaxNetPos history: %s", exc)
        full_minmax = pd.DataFrame()

    return _build_net_position_grid(
        bundle=bundle,
        full_minmax=full_minmax,
        zones=list(JAO_NET_POSITION_ZONES),
        start=start,
        end=end,
    )


# ── NTC tab ───────────────────────────────────────────────────────────────

# Distinguish historical (DA realised) vs forward (REMIT) limits visually.
_COLOR_NTC_DA = COLORS.get("accent_dark", "#3d5c6f")
_COLOR_NTC = COLORS.get("accent", "#4e738a")


def _build_ntc_figure(
    zone: str,
    neighbours: list[str],
    bundle: dict,
    start: dt.date,
    end: dt.date,
) -> go.Figure:
    """Per-neighbour single-column figure: DA NTC (historical) + NTC (forward)
    on the limit lines, with DA commercial flow overlaid."""
    if not neighbours:
        return _empty_figure(
            f"No non-FB NTC neighbours for {zone.upper()} "
            "(all interconnectors are flow-based, or no NTC data loaded)"
        )

    n_rows = len(neighbours)
    subplot_titles = [f"{zone.upper()}↔{nb.upper()}" for nb in neighbours]
    v_spacing = min(0.06, 0.9 / max(1, n_rows - 1)) if n_rows > 1 else 0.0
    fig = make_subplots(
        rows=n_rows,
        cols=1,
        subplot_titles=subplot_titles,
        vertical_spacing=v_spacing,
    )

    any_data = False
    for row_idx, nb in enumerate(neighbours, start=1):
        first = row_idx == 1
        series = get_zone_ntc_series(bundle, zone=zone, neighbour=nb)
        ntc_da_pos = _filter_series(series["ntc_da_pos"], start, end)
        ntc_da_neg = _filter_series(series["ntc_da_neg"], start, end)
        ntc_pos = _filter_series(series["ntc_pos"], start, end)
        ntc_neg = _filter_series(series["ntc_neg"], start, end)
        fl_com = _filter_series(series["flow_commercial"], start, end)

        has_any = not (
            ntc_da_pos.empty and ntc_da_neg.empty
            and ntc_pos.empty and ntc_neg.empty and fl_com.empty
        )
        any_data = any_data or has_any

        if not has_any:
            fig.add_annotation(
                text="No NTC / flow data in selected range",
                x=0.5, y=0.5, xref="paper", yref="paper",
                showarrow=False,
                font=dict(size=11, color=COLORS["text_muted"]),
                row=row_idx, col=1,
            )
            fig.update_yaxes(title_text="MW", row=row_idx, col=1)
            continue

        # DA NTC (historical) — solid lines.
        if not ntc_da_pos.empty:
            fig.add_trace(
                go.Scatter(
                    x=ntc_da_pos.index, y=ntc_da_pos.values, mode="lines",
                    name="DA NTC (export)", legendgroup="ntc_da_pos",
                    showlegend=first,
                    line=dict(color=_COLOR_NTC_DA, width=1.5),
                    hovertemplate=(
                        f"<b>{zone.upper()}→{nb.upper()} DayAheadNTC</b><br>"
                        "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                    ),
                ),
                row=row_idx, col=1,
            )
        if not ntc_da_neg.empty:
            fig.add_trace(
                go.Scatter(
                    x=ntc_da_neg.index, y=(-ntc_da_neg).values, mode="lines",
                    name="DA NTC (import)", legendgroup="ntc_da_neg",
                    showlegend=first,
                    line=dict(color=_COLOR_NTC_DA, width=1.5),
                    hovertemplate=(
                        f"<b>{nb.upper()}→{zone.upper()} DayAheadNTC</b><br>"
                        "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                    ),
                ),
                row=row_idx, col=1,
            )

        # REMIT NTC (forward-looking) — dashed lines.
        if not ntc_pos.empty:
            fig.add_trace(
                go.Scatter(
                    x=ntc_pos.index, y=ntc_pos.values, mode="lines",
                    name="NTC (export, REMIT)", legendgroup="ntc_pos",
                    showlegend=first,
                    line=dict(color=_COLOR_NTC, width=1.4, dash="dash"),
                    hovertemplate=(
                        f"<b>{zone.upper()}→{nb.upper()} NTC (REMIT)</b><br>"
                        "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                    ),
                ),
                row=row_idx, col=1,
            )
        if not ntc_neg.empty:
            fig.add_trace(
                go.Scatter(
                    x=ntc_neg.index, y=(-ntc_neg).values, mode="lines",
                    name="NTC (import, REMIT)", legendgroup="ntc_neg",
                    showlegend=first,
                    line=dict(color=_COLOR_NTC, width=1.4, dash="dash"),
                    hovertemplate=(
                        f"<b>{nb.upper()}→{zone.upper()} NTC (REMIT)</b><br>"
                        "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                    ),
                ),
                row=row_idx, col=1,
            )

        # DA commercial flow.
        if not fl_com.empty:
            fig.add_trace(
                go.Scatter(
                    x=fl_com.index, y=fl_com.values, mode="lines",
                    name="Commercial flow (DA)", legendgroup="flow",
                    showlegend=first,
                    line=dict(color=_COLOR_FLOW, width=1.5),
                    hovertemplate=(
                        f"<b>{zone.upper()}>{nb.upper()} NetCommercialFlowDayAhead</b><br>"
                        "%{x|%Y-%m-%d %H:%M}<br>%{y:,.0f} MW<extra></extra>"
                    ),
                ),
                row=row_idx, col=1,
            )

        fig.add_hline(
            y=0, line=dict(color=_COLOR_ZERO, width=0.8, dash="dash"),
            row=row_idx, col=1,
        )
        fig.update_yaxes(title_text="MW", row=row_idx, col=1)

    if not any_data:
        return _empty_figure(
            f"No NTC / flow data available for {zone.upper()} in this range"
        )

    row_h = 300
    fig.update_layout(
        height=max(500, n_rows * row_h + 160),
        plot_bgcolor=COLORS["chart_bg"],
        paper_bgcolor=COLORS["chart_paper"],
        margin=dict(l=60, r=20, t=72, b=88),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.0 + 30 / (n_rows * row_h + 160),
            yref="paper",
            xanchor="center",
            x=0.5,
            font=dict(size=11),
            bgcolor="rgba(0,0,0,0)",
            borderwidth=0,
        ),
        hovermode="closest",
    )
    fig.update_annotations(font=dict(size=11))
    fig.update_xaxes(
        showgrid=True,
        gridcolor=COLORS["border_light"],
        showline=True,
        linecolor=COLORS["border"],
        ticklabelstandoff=6,
    )
    fig.update_yaxes(
        showgrid=True,
        gridcolor=COLORS["border_light"],
        zeroline=False,
        showline=True,
        linecolor=COLORS["border"],
    )
    return fig


@callback(
    Output("flowbased-ntc-graph", "figure"),
    Input("flowbased-ntc-zone", "value"),
    Input("flowbased-ntc-date-range", "start_date"),
    Input("flowbased-ntc-date-range", "end_date"),
)
def update_ntc_chart(zone, start_date, end_date):
    zone = (zone or "fr").lower()

    start = _parse_date(start_date) or (dt.date.today() - dt.timedelta(days=14))
    end = _parse_date(end_date) or (dt.date.today() + dt.timedelta(days=14))
    if start > end:
        start, end = end, start

    try:
        bundle = load_flowbased_data(start=start, end=end)
    except Exception as exc:
        logger.exception("Failed to load flow-based data for NTC tab: %s", exc)
        return _empty_figure(f"Failed to load data: {exc}")

    neighbours = get_ntc_neighbours(bundle, zone)
    return _build_ntc_figure(zone, neighbours, bundle, start, end)
