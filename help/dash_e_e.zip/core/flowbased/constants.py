"""Static configuration for the Flow-Based dashboard."""
from __future__ import annotations

# ── Page metadata ─────────────────────────────────────────────────────────
PAGE_PATH = "/power/flowbased"
PAGE_NAME = "Transmission"
PAGE_TITLE = "Transmission | JG Power Dashboard"
PAGE_ORDER = 25

# ── CORE FBMC zones and neighbours ───────────────────────────────────────
# Mirrors CORE_FBMC_NEIGHBOURS in eu_reports/power_flowbased_report/flowbased_report.py
# Keyed by bidding zone, value = list of zones connected via a flow-based border.
CORE_FBMC_NEIGHBOURS: dict[str, list[str]] = {
    "at": ["de", "si", "hu", "cz"],
    "be": ["fr", "de", "nl"],
    "hr": ["si", "hu"],
    "cz": ["de", "pl", "sk", "at"],
    "fr": ["be", "de"],
    "de": ["nl", "be", "fr", "at", "cz", "pl"],
    "hu": ["at", "sk", "si", "hr", "ro"],
    "nl": ["be", "de"],
    "pl": ["de", "cz", "sk"],
    "ro": ["hu"],
    "sk": ["cz", "pl", "hu"],
    "si": ["at", "hu", "hr"],
}

CORE_FBMC_ZONES: list[str] = sorted(CORE_FBMC_NEIGHBOURS.keys())

# ── Default date range ────────────────────────────────────────────────────
DEFAULT_LOOKBACK_DAYS = 14

# ── Net Position zones (CORE FBMC) ────────────────────────────────────────
# All 12 CORE FBMC bidding zones. MinMaxNetPos publishes bounds for all of
# them; JaoNetPosition only has the 5 CWE zones (at, be, de, fr, nl) — for
# the other 7, the chart shows min/max bounds only, no net-position line.
JAO_NET_POSITION_ZONES: list[str] = CORE_FBMC_ZONES

# ── Tab identifiers ───────────────────────────────────────────────────────
TAB_MAXBEX = "tab-maxbex"
TAB_NET_POSITION = "tab-net-position"
TAB_NTC = "tab-ntc"

# ── NTC zones (non-FBMC selectable in the NTC tab) ────────────────────────
# Curated list of bidding zones that appear in EQ NTC borders. The actual
# neighbours per zone are discovered at runtime from the loaded NTC columns;
# borders that overlap with the flow-based set (CORE_FBMC_NEIGHBOURS) are
# filtered out so the NTC tab only shows non-FB interconnectors.
NTC_ZONES: list[str] = sorted({
    "al", "at", "ba", "be", "bg", "ch", "cz", "de",
    "dk1", "dk2", "ee", "es", "fi", "fr", "gb", "gr",
    "hr", "hu", "ie", "it", "it-cnor", "it-csud", "it-nord",
    "it-sard", "it-sici", "it-sud", "it-cala", "lt", "md",
    "me", "mk", "nie", "nl", "no1", "no2", "no3", "no4", "no5",
    "pl", "pt", "ro", "rs", "se1", "se2", "se3", "se4",
    "si", "sk", "tr", "ua", "xk",
})
