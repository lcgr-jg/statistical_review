"""Flow-Based dashboard module (CORE FBMC MaxBex + commercial flows)."""
