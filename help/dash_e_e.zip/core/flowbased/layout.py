"""Layout for the Flow-Based dashboard (pure, no callbacks)."""
from __future__ import annotations

import datetime as dt

import dash_bootstrap_components as dbc
from dash import dcc, html

from core.styles import COLORS

from .constants import (
    CORE_FBMC_ZONES,
    DEFAULT_LOOKBACK_DAYS,
    NTC_ZONES,
    TAB_MAXBEX,
    TAB_NET_POSITION,
    TAB_NTC,
)

_LABEL_STYLE = {"fontSize": "11px"}
_LABEL_CLASS = "small text-muted fw-bold text-uppercase"

_TAB_CONTENT_STYLE = {
    "backgroundColor": COLORS["chart_bg"],
    "borderRadius": "6px",
    "border": f"1px solid {COLORS['border']}",
    "padding": "12px",
}


def _label(text: str) -> html.Label:
    return html.Label(text, className=_LABEL_CLASS, style=_LABEL_STYLE)


def _build_maxbex_tab() -> html.Div:
    today = dt.date.today()
    default_start = today - dt.timedelta(days=DEFAULT_LOOKBACK_DAYS)

    return html.Div(
        style={"padding": "12px 0"},
        children=[
            # Controls row
            dbc.Row(
                [
                    dbc.Col(
                        [
                            _label("Zone (CORE FBMC)"),
                            dcc.Dropdown(
                                id="flowbased-maxbex-zone",
                                options=[
                                    {"label": z.upper(), "value": z}
                                    for z in CORE_FBMC_ZONES
                                ],
                                value="fr",
                                clearable=False,
                                persistence=True,
                                persistence_type="local",
                                style={"minWidth": "160px", "fontSize": "13px"},
                            ),
                        ],
                        width="auto",
                    ),
                    dbc.Col(
                        [
                            _label("Date range"),
                            dcc.DatePickerRange(
                                id="flowbased-maxbex-date-range",
                                start_date=default_start,
                                end_date=today,
                                display_format="DD MMM YY",
                                persistence=True,
                                persistence_type="local",
                                style={"fontSize": "12px"},
                            ),
                        ],
                        width="auto",
                    ),
                ],
                align="start",
                className="g-3 mb-3 flex-wrap",
            ),

            # Chart area
            dcc.Loading(
                type="dot",
                color=COLORS["accent"],
                children=[
                    html.Div(
                        style=_TAB_CONTENT_STYLE,
                        children=[
                            dcc.Graph(
                                id="flowbased-maxbex-graph",
                                config={
                                    "displaylogo": False,
                                    "displayModeBar": "hover",
                                    "scrollZoom": False,
                                    "doubleClick": "reset",
                                },
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )


def _build_net_position_tab() -> html.Div:
    today = dt.date.today()
    default_start = today - dt.timedelta(days=DEFAULT_LOOKBACK_DAYS)

    # Tall stacked figure (n CORE zones × 3 sub-plots). Outer Graph height grows
    # to fit; the page-level scroll handles the overflow.
    return html.Div(
        style={"padding": "12px 0"},
        children=[
            # Controls row — date range only; the figure renders every zone.
            dbc.Row(
                [
                    dbc.Col(
                        [
                            _label("Date range (left column)"),
                            dcc.DatePickerRange(
                                id="flowbased-netpos-date-range",
                                start_date=default_start,
                                end_date=today,
                                display_format="DD MMM YY",
                                persistence=True,
                                persistence_type="local",
                                style={"fontSize": "12px"},
                            ),
                        ],
                        width="auto",
                    ),
                ],
                align="start",
                className="g-3 mb-3 flex-wrap",
            ),

            # Chart area
            dcc.Loading(
                type="dot",
                color=COLORS["accent"],
                children=[
                    html.Div(
                        style=_TAB_CONTENT_STYLE,
                        children=[
                            dcc.Graph(
                                id="flowbased-netpos-graph",
                                config={
                                    "displaylogo": False,
                                    "displayModeBar": "hover",
                                    "scrollZoom": False,
                                    "doubleClick": "reset",
                                },
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )


def _build_ntc_tab() -> html.Div:
    today = dt.date.today()
    default_start = today - dt.timedelta(days=DEFAULT_LOOKBACK_DAYS)
    # Future window so REMIT NTC nominations are visible to the right of "now".
    default_end = today + dt.timedelta(days=14)

    return html.Div(
        style={"padding": "12px 0"},
        children=[
            dbc.Row(
                [
                    dbc.Col(
                        [
                            _label("Zone"),
                            dcc.Dropdown(
                                id="flowbased-ntc-zone",
                                options=[
                                    {"label": z.upper(), "value": z}
                                    for z in NTC_ZONES
                                ],
                                value="fr",
                                clearable=False,
                                persistence=True,
                                persistence_type="local",
                                style={"minWidth": "160px", "fontSize": "13px"},
                            ),
                        ],
                        width="auto",
                    ),
                    dbc.Col(
                        [
                            _label("Date range"),
                            dcc.DatePickerRange(
                                id="flowbased-ntc-date-range",
                                start_date=default_start,
                                end_date=default_end,
                                display_format="DD MMM YY",
                                persistence=True,
                                persistence_type="local",
                                style={"fontSize": "12px"},
                            ),
                        ],
                        width="auto",
                    ),
                ],
                align="start",
                className="g-3 mb-3 flex-wrap",
            ),

            dcc.Loading(
                type="dot",
                color=COLORS["accent"],
                children=[
                    html.Div(
                        style=_TAB_CONTENT_STYLE,
                        children=[
                            dcc.Graph(
                                id="flowbased-ntc-graph",
                                config={
                                    "displaylogo": False,
                                    "displayModeBar": "hover",
                                    "scrollZoom": False,
                                    "doubleClick": "reset",
                                },
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )


def build_layout() -> html.Div:
    return html.Div(
        style={"backgroundColor": COLORS["background"], "minHeight": "100vh"},
        children=[
            # ── Header / breadcrumb ─────────────────────────────────────
            html.Div(
                style={
                    "padding": "16px 22px",
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "backgroundColor": COLORS["card_bg"],
                },
                children=[
                    html.Div(
                        [
                            html.Span("Power", style={"color": "#888", "fontSize": "13px"}),
                            html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                            html.Span(
                                "Transmission",
                                style={"fontWeight": "600", "color": COLORS["text_primary"]},
                            ),
                        ],
                    ),
                ],
            ),

            # ── Tabs ────────────────────────────────────────────────────
            html.Div(
                style={"padding": "12px 22px"},
                children=[
                    dbc.Tabs(
                        id="flowbased-tabs",
                        active_tab=TAB_MAXBEX,
                        children=[
                            dbc.Tab(
                                label="FB MaxBex",
                                tab_id=TAB_MAXBEX,
                                children=_build_maxbex_tab(),
                            ),
                            dbc.Tab(
                                label="FB Net Position",
                                tab_id=TAB_NET_POSITION,
                                children=_build_net_position_tab(),
                            ),
                            dbc.Tab(
                                label="NTC",
                                tab_id=TAB_NTC,
                                children=_build_ntc_tab(),
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )
