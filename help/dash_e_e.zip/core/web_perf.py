"""
web_perf
========
Flask-level performance layer for the EU Power Dashboard portal.

Responsibilities:

1. **Gzip compression** of all JSON / text / HTML responses above a threshold.
   Plotly figure JSON compresses 8-10× which is by far the single biggest
   win for the wall-clock "chart appeared on screen" time.

2. **Aggressive HTTP caching headers** on the parts of the response that
   never change within a deploy:

      * ``/_dash-component-suites/*``  →  ``immutable, max-age=1y``
      * ``/assets/*``                  →  ``max-age=1h``
      * Auth-sensitive routes always tagged ``no-store``.

3. A tiny **/api/fig/<key>** endpoint that streams a pre-built figure's
   JSON bytes straight out of ``figure_cache`` with the same long-lived
   cache headers.  Useful for clientside ``fetch()`` calls and sanity-
   checking via ``curl``.

Attach with one call from ``portal_app.py``:

    from core.web_perf import attach_performance_layer
    attach_performance_layer(app.server)
"""
from __future__ import annotations

import gzip
import io
import logging
from typing import Iterable

from flask import Flask, Response, request

from core.fast_cache import figure_cache
from core.figure_registry import figure_registry

logger = logging.getLogger(__name__)

# Compression kicks in above this size; below it the overhead isn't worth it.
_GZIP_MIN_BYTES = 512

_GZIP_MIME_PREFIXES: tuple = (
    "application/json",
    "application/javascript",
    "text/",
    "image/svg+xml",
)

# Paths tagged with strong browser caching.
_IMMUTABLE_PATH_PREFIXES: tuple = (
    "/_dash-component-suites/",   # Plotly.js / React / Dash renderer bundles
)
_SHORT_CACHE_PATH_PREFIXES: tuple = (
    "/assets/",
)
# Never cache these (auth/live data).
_NEVER_CACHE_PATH_PREFIXES: tuple = (
    "/login",
    "/logout",
    "/api/health",
    "/api/live",
    "/api/cache-status",
    "/api/callback-status",
    "/api/force-refresh",
    "/_dash-update-component",    # callback payloads (may contain session data)
    "/_dash-dependencies",
)


# ----------------------------------------------------------------------
# Compression
# ----------------------------------------------------------------------

def _should_gzip(response: Response) -> bool:
    if response.direct_passthrough:
        return False
    if response.status_code < 200 or response.status_code >= 300:
        return False
    if response.headers.get("Content-Encoding"):
        return False
    accept_encoding = request.headers.get("Accept-Encoding", "")
    if "gzip" not in accept_encoding.lower():
        return False
    mime = (response.mimetype or "").lower()
    if not mime.startswith(_GZIP_MIME_PREFIXES):
        return False
    if response.content_length is not None and response.content_length < _GZIP_MIN_BYTES:
        return False
    return True


def _gzip_response(response: Response) -> Response:
    raw = response.get_data()
    if len(raw) < _GZIP_MIN_BYTES:
        return response
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=5) as gz:
        gz.write(raw)
    compressed = buf.getvalue()
    response.set_data(compressed)
    response.headers["Content-Encoding"] = "gzip"
    response.headers["Content-Length"] = str(len(compressed))
    response.headers.add("Vary", "Accept-Encoding")
    return response


# ----------------------------------------------------------------------
# Cache-Control
# ----------------------------------------------------------------------

def _apply_cache_headers(response: Response) -> Response:
    path = request.path or ""

    if any(path.startswith(p) for p in _NEVER_CACHE_PATH_PREFIXES):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        return response

    if any(path.startswith(p) for p in _IMMUTABLE_PATH_PREFIXES):
        # Dash component suites are fingerprinted per-version, so they can
        # safely be cached forever.
        response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
        return response

    if any(path.startswith(p) for p in _SHORT_CACHE_PATH_PREFIXES):
        response.headers["Cache-Control"] = "public, max-age=3600"
        return response

    # Default for everything else (HTML, login page, etc.): short revalidation
    # so we don't leak stale auth state.
    if "Cache-Control" not in response.headers:
        response.headers["Cache-Control"] = "private, max-age=0, must-revalidate"
    return response


# ----------------------------------------------------------------------
# /api/fig endpoint
# ----------------------------------------------------------------------

def _register_api_routes(server: Flask) -> None:
    @server.route("/api/fig/<path:fig_key>")
    def _api_fig(fig_key: str):  # noqa: D401
        """Stream a pre-built figure JSON by registry key.

        Missing keys return 404.  The route *does not* trigger a rebuild —
        that would defeat the purpose of a pre-computed cache.  Use the
        registry's own ``build()`` method from a management endpoint if you
        need on-demand rebuilds.
        """
        payload = figure_cache.get_json(fig_key)
        if payload is None:
            return {"error": "not_cached", "key": fig_key}, 404
        resp = Response(payload, mimetype="application/json")
        # These are aggressively cached because the payload itself is what
        # moves; clients append a cache-buster query param when they want
        # fresh data.
        resp.headers["Cache-Control"] = "public, max-age=60"
        return resp

    @server.route("/api/fig-status")
    def _api_fig_status():  # noqa: D401
        """Diagnostics for the figure registry."""
        import json
        body = json.dumps(figure_registry.status(), default=str, indent=2)
        return body, 200, {"Content-Type": "application/json"}

    @server.route("/api/fig-keys")
    def _api_fig_keys():  # noqa: D401
        """List currently-cached figure keys for client-side prefetching.

        ``fastcharts.js`` calls this on page load to warm its sessionStorage
        cache in the background.  We only advertise keys that are *actually*
        in the cache — pre-warm in progress → shorter list, that's fine.
        """
        import json
        keys = [k for k in figure_registry.keys() if figure_cache.get_json(k) is not None]
        body = json.dumps(keys)
        return body, 200, {
            "Content-Type": "application/json",
            "Cache-Control": "public, max-age=30",
        }


# ----------------------------------------------------------------------
# Public entry point
# ----------------------------------------------------------------------

def attach_performance_layer(server: Flask) -> None:
    """Attach all performance tweaks to the Flask *server*.

    Call once, after the Dash app has finished registering its own routes.
    """
    if getattr(server, "_perf_layer_attached", False):
        return

    @server.after_request
    def _after(response: Response) -> Response:
        response = _apply_cache_headers(response)
        if _should_gzip(response):
            response = _gzip_response(response)
        return response

    _register_api_routes(server)
    server._perf_layer_attached = True  # type: ignore[attr-defined]
    logger.info("web_perf: performance layer attached (gzip + cache-control + /api/fig)")
