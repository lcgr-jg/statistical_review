"""Qatar Fleet Location zone summary table."""
from __future__ import annotations

import pandas as pd
from dash import html

from core.qatar_monitor.constants import FLEET_ZONE_NO_POSITION
from core.qatar_monitor.table_chrome import (
    SHADE_FLEET,
    SHADE_LADEN,
    SHADE_UNLADEN,
    TABLE_STYLE,
    TABLE_WRAP,
    TD_LEFT,
    TH_LEFT,
    group_th,
    td,
    th,
)
from core.styles import COLORS


def build_fleet_location_table(summary: pd.DataFrame | None) -> html.Div:
    if summary is None or summary.empty:
        return html.Div(
            "No QatarEnergy fleet positions available.",
            style={"fontSize": "13px", "color": COLORS["text_muted"]},
        )

    header = html.Thead(
        [
            html.Tr(
                [
                    html.Th("Zone", rowSpan=2, style=TH_LEFT),
                    html.Th("Days to Ras Laffan", rowSpan=2, style=TH_LEFT),
                    group_th("Fleet", colspan=3, shade=SHADE_FLEET),
                    group_th("Laden", colspan=5, shade=SHADE_LADEN),
                    group_th("Unladen", colspan=2, shade=SHADE_UNLADEN),
                ]
            ),
            html.Tr(
                [
                    th("Vessels", shade=SHADE_FLEET),
                    th("Q-Max", shade=SHADE_FLEET),
                    th("Q-Flex", shade=SHADE_FLEET),
                    th("Count", shade=SHADE_LADEN),
                    th("Vol (mcm)", shade=SHADE_LADEN),
                    th("Non-RL count", shade=SHADE_LADEN),
                    th("Non-RL vol (mcm)", shade=SHADE_LADEN),
                    th(
                        "Other RL",
                        shade=SHADE_LADEN,
                        title=(
                            "Non-QatarEnergy vessels in the Persian Gulf with an "
                            "open Ras Laffan cargo (Gulf row only)"
                        ),
                    ),
                    th("Count", shade=SHADE_UNLADEN),
                    th("Capacity (mcm)", shade=SHADE_UNLADEN),
                ]
            ),
        ]
    )
    body = []
    for _, row in summary.iterrows():
        zone_label = str(row.get("zone") or "—")
        zone_hover = str(row.get("zone_hover") or "").strip()
        if row.get("zone_id") == FLEET_ZONE_NO_POSITION and zone_hover:
            zone_cell = html.Td(
                html.Span(
                    zone_label,
                    title=zone_hover,
                    style={"cursor": "help", "borderBottom": "1px dotted"},
                ),
                style=TD_LEFT,
                title=zone_hover,
            )
        else:
            zone_cell = html.Td(zone_label, style=TD_LEFT)
        laden_hover = str(row.get("laden_hover") or "").strip() or None
        unladen_hover = str(row.get("unladen_hover") or "").strip() or None
        non_rl_hover = str(row.get("non_rl_hover") or "").strip() or None
        other_rl_hover = str(row.get("other_rl_hover") or "").strip() or None
        body.append(
            html.Tr(
                [
                    zone_cell,
                    html.Td(str(row.get("days_to_ras_laffan") or "—"), style=TD_LEFT),
                    td(row.get("vessels"), shade=SHADE_FLEET),
                    td(row.get("q_max"), shade=SHADE_FLEET),
                    td(row.get("q_flex"), shade=SHADE_FLEET),
                    td(row.get("laden"), shade=SHADE_LADEN, hover=laden_hover),
                    td(row.get("laden_mcm"), shade=SHADE_LADEN),
                    td(row.get("non_rl_laden"), shade=SHADE_LADEN, hover=non_rl_hover),
                    td(row.get("non_rl_laden_mcm"), shade=SHADE_LADEN),
                    td(row.get("other_rl"), shade=SHADE_LADEN, hover=other_rl_hover),
                    td(row.get("unladen"), shade=SHADE_UNLADEN, hover=unladen_hover),
                    td(row.get("unladen_capacity_mcm"), shade=SHADE_UNLADEN),
                ]
            )
        )

    return html.Div(
        html.Table(
            [header, html.Tbody(body)],
            style=TABLE_STYLE,
        ),
        style={**TABLE_WRAP, "marginBottom": "16px"},
    )
