"""LNG — Qatar Monitor page constants."""
from __future__ import annotations

import pandas as pd

PAGE_PATH = "/power/lng/qatar_monitor"
PAGE_NAME = "Qatar Monitor"
PAGE_TITLE = "Qatar LNG Monitor | JG Power Dashboard"
PAGE_ORDER = 80

# Chart / gap-table windows (match eu_reports/ras_laffan_loadings)
WAR_START = "2026-02-28"
CHART_START = "2026-02-01"
MISSILE_STRIKE = "2026-03-18"

# Pre/post-Iran summary tables (final cut from the analysis chat)
PRE_WAR_START = "2025-09-01"
PRE_WAR_END = "2026-02-28"  # exclusive
POST_STRIKE_START = "2026-03-18"

N_BERTHS = 6

# Ras Laffan Loadings activity table lookback
LOADINGS_HISTORY_DAYS = 7
LOADINGS_HISTORY_DAYS_MIN = 3
LOADINGS_HISTORY_DAYS_MAX = 60

# Kpler Terminal map deep-link (same pattern as eu_reports/lng_vessels)
KPLER_VESSEL_MAP_URL = (
    "https://terminal.kpler.com/map/search/voyages?fields=vessel&vessels={}"
)

# Persian Gulf destination countries (Kpler ``Country (destination)`` labels)
GULF_KUWAIT = "Kuwait"
GULF_UAE = "United Arab Emirates"
GULF_COUNTRIES = (GULF_KUWAIT, GULF_UAE)

# YoY monthly import charts: lines = current + prior 3 years; band = prior 5 years
GULF_YOY_LINE_YEARS = 3  # number of prior years drawn as lines (excl. current)
GULF_YOY_BAND_YEARS = 5  # prior years used for min–max shade

GULF_SECTION_NOTE = (
    "Exports to countries within the Persian Gulf (e.g. Kuwait and, to a "
    "lesser extent, the UAE) have continued during the Iran war and proved "
    "to be an important outlet for Qatari production. Charts below show "
    "year-on-year monthly imports from Qatar into each market, dated by "
    "arrival at the destination (not loading date at Ras Laffan)."
)

# Nominal journey from Ras Laffan, used to shift arrivals back onto the loading
# date. This assumes the ship sails direct and discharges immediately.
GULF_VOYAGE_LAG_DAYS = {
    GULF_KUWAIT: 1.0,
    GULF_UAE: 0.5,
}

# A standard cargo is ~100 mcm, so the 7d mean is choppy. It is still the
# default because it shows recent changes; longer windows are steadier.
GULF_OUTFLOW_WINDOWS = (7, 14, 21, 30)
GULF_OUTFLOW_WINDOW_DEFAULT = 7
# Kpler's Strait of Hormuz crossing dashboard is not on the LNG API.
KPLER_HORMUZ_DASHBOARD_URL = "https://terminal.kpler.com/dashboard/soh-crossing"
# February loadings were still ~300 mcm/d and flatten this chart. The
# Ras Laffan panel above keeps that collapse; this one starts once rates
# have fallen, so Kuwait vs the residual share a readable scale.
GULF_OUTFLOW_CHART_START = "2026-03-15"
# Share of exports is meaningless while loadings are near zero.
GULF_OUTFLOW_MIN_EXPORTS_FOR_SHARE = 20.0

GULF_OUTFLOW_SECTION_LEAD = (
    "Qatar export rate against arrivals into Kuwait and the UAE. This can "
    "be used to infer Hormuz transits. The "
)
GULF_OUTFLOW_SECTION_LEAD_AFTER = (
    " is not currently exposed via their API, so this outflow has to be implied."
)
GULF_OUTFLOW_SECTION_NOTE = (
    "Arrivals are shifted back onto the loading date by a nominal journey "
    "time (Kuwait 1 day, UAE 0.5 day), assuming a direct voyage and "
    "immediate discharge. The gap is the export rate those countries are "
    "not absorbing, i.e. the volume that exits the Gulf through Hormuz. "
    "The red line is loadings Kpler has not given a destination. A standard "
    "cargo is ~100 mcm, so the 7d MA is very choppy but shows recent changes. "
    "Kuwait discharge has often taken longer than the journey, so the "
    "latest days can still include a Gulf cargo that has not arrived yet. "
    "The chart starts 15 March, once loadings had fallen from the February "
    "rate. A lot of recent activity has been dark (AIS transponder off), "
    "so all cargo activity (loadings, journeys and unloadings) is subject "
    "to changes as and when activity is recorded by Kpler."
)

EVENTS = {
    "2026-02-28": "Iran war<br>started",
    "2026-03-18": "Ras Laffan hit<br>by missiles",
    "2026-06-15": "US/Iran MOU<br>signed",
    "2026-07-06": "Qatari tanker hit<br>(Al Rekayyat)",
    "2026-07-31": "Qatari tanker hit<br>(Gaslog Shanghai)",
}

# Vessel missile strikes — dates aligned with EVENTS on the activity chart
MISSILE_HIT_VESSELS: dict[str, dict[str, str]] = {
    "Al Rekayyat": {
        "date": "2026-07-06",
        "note": "Hit by Iranian missile on 06 Jul 2026",
    },
    "Gaslog Shanghai": {
        "date": "2026-07-31",
        "note": "Hit by Iranian missile on 31 Jul 2026",
    },
}

PRE_WAR_LABEL = "Pre-war (1 Sep – 27 Feb)"
POST_STRIKE_LABEL = "Post-strike (18 Mar – now)"

PERIOD_NOTES = (
    f"Pre-war: {pd.Timestamp(PRE_WAR_START):%d %b %Y} to "
    f"{pd.Timestamp(PRE_WAR_END) - pd.Timedelta(days=1):%d %b %Y}. "
    f"Post-strike: from {pd.Timestamp(POST_STRIKE_START):%d %b %Y} "
    f"(missile strike on Ras Laffan) through now — early-March queue "
    f"clearing after the {pd.Timestamp(WAR_START):%d %b} war start is "
    f"excluded. Concurrency is time-weighted (average vessels at berth "
    f"across every hour). Berth-time stats use completed loadings only. "
    f"Ras Laffan has {N_BERTHS} loading berths."
)

# Qatar fleet (Kpler vessels snapshot)
FLEET_STATUS_ACTIVE = "Active"
# Current controller exact family (Kpler label today is ``QatarEnergy``)
FLEET_CONTROLLER_PATTERN = r"QatarEnergy"
# Beneficial / registered owners under the QatarEnergy / Qatargas umbrella
FLEET_OWNER_PATTERN = r"QatarEnergy|Qatargas|Qatar\s*LNG|Qatar\s*Gas"

FLEET_SECTION_NOTE = (
    "Active LNG carriers from the Kpler vessels snapshot. "
    "The two rows are independent filters, not exclusive partitions — "
    "owned vessels that are also QatarEnergy-controlled appear in both. "
    "Controlled = Current controller is QatarEnergy. "
    "Owned = Owners matches QatarEnergy / Qatargas (and related Qatar LNG "
    "entities). Capacity and cargo volumes are gas-equivalent mcm "
    "(from Capacity (m3) / Volume). Laden = onboard Volume > 0. "
    "Laden vol + unladen capacity will not equal total capacity: for laden "
    "ships we sum reported cargo (Volume), not nameplate capacity, and "
    "carriers are rarely filled to 100% (heel gas retained, operational "
    "fill limits, boil-off, and partial cargoes all leave unused capacity "
    "on laden vessels)."
)

# Qatar fleet location zones (GeoJSON + exclusive priority order)
FLEET_ZONE_PERSIAN_GULF = "persian_gulf_trapped"
FLEET_ZONE_BLOCKADE = "outside_hormuz_inside_blockade"
FLEET_ZONE_ARABIAN_SEA = "arabian_sea_waiting"
FLEET_ZONE_LACCADIVE = "laccadive_sea"
FLEET_ZONE_BAY_OF_BENGAL = "bay_of_bengal"
FLEET_ZONE_INDIAN_OCEAN = "indian_ocean"
FLEET_ZONE_OUTSIDE = "outside_zones"
FLEET_ZONE_NO_POSITION = "no_position"

FLEET_ZONE_ORDER = (
    FLEET_ZONE_PERSIAN_GULF,
    FLEET_ZONE_BLOCKADE,
    FLEET_ZONE_ARABIAN_SEA,
    FLEET_ZONE_LACCADIVE,
    FLEET_ZONE_BAY_OF_BENGAL,
    FLEET_ZONE_INDIAN_OCEAN,
)

FLEET_ZONE_LABELS = {
    FLEET_ZONE_PERSIAN_GULF: "Persian Gulf (inside Hormuz)",
    FLEET_ZONE_BLOCKADE: "Outside Hormuz / inside US blockade",
    FLEET_ZONE_ARABIAN_SEA: "Arabian Sea waiting",
    FLEET_ZONE_LACCADIVE: "Laccadive Sea",
    FLEET_ZONE_BAY_OF_BENGAL: "Bay of Bengal",
    FLEET_ZONE_INDIAN_OCEAN: "Indian Ocean",
    FLEET_ZONE_OUTSIDE: "Outside defined zones",
    FLEET_ZONE_NO_POSITION: "No position",
}

# Indicative unladen steam to Ras Laffan (not shown for the Gulf itself)
FLEET_ZONE_DAYS_TO_RAS_LAFFAN = {
    FLEET_ZONE_BLOCKADE: "<1d",
    FLEET_ZONE_ARABIAN_SEA: "<5d",
    FLEET_ZONE_LACCADIVE: "<6d",
    FLEET_ZONE_BAY_OF_BENGAL: "<7d",
    FLEET_ZONE_INDIAN_OCEAN: "<9d",
    FLEET_ZONE_OUTSIDE: ">10d",
}

FLEET_ZONE_COLORS = {
    FLEET_ZONE_PERSIAN_GULF: "#e67e22",
    FLEET_ZONE_BLOCKADE: "#8e44ad",
    FLEET_ZONE_ARABIAN_SEA: "#16a085",
    FLEET_ZONE_LACCADIVE: "#2980b9",
    FLEET_ZONE_BAY_OF_BENGAL: "#27ae60",
    FLEET_ZONE_INDIAN_OCEAN: "#7f8c8d",
}

FLEET_LOCATION_SECTION_NOTE = (
    "QatarEnergy-controlled vessels (Kpler) joined to Bloomberg LNG ship "
    "positions on IMO. Zones are exclusive (first match): Persian Gulf "
    "inside Hormuz → outside Hormuz / US blockade → Arabian Sea → "
    "Laccadive Sea → Bay of Bengal → Indian Ocean → elsewhere. "
    "Days to Ras Laffan is an indicative unladen steam time for vessels "
    "outside the Gulf. Laden (Ras Laffan) = onboard cargo tied to an open "
    "Kpler Ras Laffan loading; Laden (other origin) = laden but that cargo "
    "was not loaded at Ras Laffan (sublets / third-party offtake). "
    "Other RL (Persian Gulf row only) = non-QatarEnergy vessels inside Hormuz "
    "that still have an open Ras Laffan cargo (e.g. GasLog-controlled offtake). "
    "Markers show current AIS lat/lon from Bloomberg."
)
