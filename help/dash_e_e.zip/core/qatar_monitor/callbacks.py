"""LNG — Qatar Monitor callbacks."""
from __future__ import annotations

import logging
from datetime import datetime

import pandas as pd
from dash import Input, Output, callback, ctx, html

from core.qatar_monitor.charts import build_idle_gap_chart
from core.qatar_monitor.constants import (
    GULF_KUWAIT,
    GULF_UAE,
    LOADINGS_HISTORY_DAYS,
    LOADINGS_HISTORY_DAYS_MAX,
    LOADINGS_HISTORY_DAYS_MIN,
)
from core.qatar_monitor.data import get_monitor_frames, status_line
from core.qatar_monitor.fleet_location_table import build_fleet_location_table
from core.qatar_monitor.fleet_map import build_fleet_location_map
from core.qatar_monitor.fleet_table import build_fleet_table
from core.qatar_monitor.gulf_charts import build_gulf_yoy_import_chart
from core.qatar_monitor.gulf_outflow import (
    build_gulf_outflow_chart,
    gulf_flow_to_records,
    parse_outflow_window,
    records_to_gulf_flow,
)
from core.qatar_monitor.headline import build_headline
from core.qatar_monitor.loadings_table import (
    build_loadings_summary,
    build_loadings_table,
    loadings_to_records,
    records_to_loadings,
)
from core.qatar_monitor.stats import build_period_stats
from core.qatar_monitor.tables import build_iran_stats_tables
from core.styles import get_status_badge_style

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "12px 16px",
            "borderRadius": "8px",
            "fontSize": "13px",
            "width": "100%",
        },
    )


def _parse_history_days(value) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return LOADINGS_HISTORY_DAYS
    return max(LOADINGS_HISTORY_DAYS_MIN, min(LOADINGS_HISTORY_DAYS_MAX, n))


@callback(
    Output("qatar-mon-chart", "figure"),
    Output("qatar-mon-tables", "children"),
    Output("qatar-mon-gulf-kuwait", "figure"),
    Output("qatar-mon-gulf-uae", "figure"),
    Output("qatar-mon-status", "children"),
    Output("qatar-mon-loadings-store", "data"),
    Output("qatar-mon-fleet-table", "children"),
    Output("qatar-mon-fleet-location-table", "children"),
    Output("qatar-mon-fleet-map", "figure"),
    Output("qatar-mon-headline", "children"),
    Output("qatar-mon-gulf-flow-store", "data"),
    Input("qatar-mon-refresh-live", "n_clicks"),
    Input("qatar-mon-refresh-cache", "n_clicks"),
)
def update_qatar_monitor(n_live, n_cache):
    triggered = ctx.triggered_id
    if triggered == "qatar-mon-refresh-live" and n_live:
        source = "live"
        refresh = True
        clicked_at = datetime.now()
    elif triggered == "qatar-mon-refresh-cache" and n_cache:
        source = "cache"
        refresh = False
        clicked_at = datetime.now()
    else:
        source = "initial"
        refresh = False
        clicked_at = None

    try:
        (
            gap,
            exports,
            loadings,
            by_dest,
            gulf,
            fleet,
            fleet_zones,
            fleet_positions,
            last,
            gulf_flow,
        ) = get_monitor_frames(refresh=refresh)
        fig = build_idle_gap_chart(gap, exports, by_dest)
        tables = build_iran_stats_tables(build_period_stats(loadings))
        kuwait_fig = build_gulf_yoy_import_chart(
            gulf.get(GULF_KUWAIT, pd.Series(dtype=float)),
            country_label="Kuwait",
        )
        uae_fig = build_gulf_yoy_import_chart(
            gulf.get(GULF_UAE, pd.Series(dtype=float)),
            country_label="UAE",
        )
        latest = None
        if loadings is not None and not loadings.empty and "berth_arrival" in loadings:
            latest = loadings["berth_arrival"].max()
        status = _alert(
            status_line(
                last,
                latest_data_date=latest,
                button_clicked_at=clicked_at,
                source=source,
            ),
            "success",
        )
        store = loadings_to_records(loadings)
        fleet_table = build_fleet_table(fleet)
        location_table = build_fleet_location_table(fleet_zones)
        fleet_map = build_fleet_location_map(fleet_positions)
        headline = build_headline(loadings, fleet_positions, gap=gap)
        return (
            fig,
            tables,
            kuwait_fig,
            uae_fig,
            status,
            store,
            fleet_table,
            location_table,
            fleet_map,
            headline,
            gulf_flow_to_records(gulf_flow),
        )
    except Exception as exc:
        logger.exception("Qatar Monitor update failed: %s", exc)
        empty = build_idle_gap_chart(pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
        empty_gulf = build_gulf_yoy_import_chart(
            pd.Series(dtype=float), country_label="—"
        )
        empty_map = build_fleet_location_map(pd.DataFrame())
        action = (
            "Live Kpler / Bloomberg pull failed"
            if source == "live"
            else "Cache reload failed"
            if source == "cache"
            else "Failed to load Qatar Monitor data"
        )
        err = _alert(f"{action}: {exc}", level="error")
        return (
            empty,
            err,
            empty_gulf,
            empty_gulf,
            err,
            [],
            err,
            err,
            empty_map,
            err,
            [],
        )


@callback(
    Output("qatar-mon-loadings-summary", "children"),
    Output("qatar-mon-loadings-table", "children"),
    Output("qatar-mon-loadings-days-label", "children"),
    Input("qatar-mon-loadings-store", "data"),
    Input("qatar-mon-loadings-days", "value"),
)
def update_ras_laffan_loadings(store_data, days_value):
    n_days = _parse_history_days(days_value)
    label = f"History ({n_days} days)"
    loadings = records_to_loadings(store_data)
    if loadings.empty:
        empty = html.Div(
            "No Ras Laffan loading data in the Kpler cache.",
            style={"fontSize": "13px", "color": "#6c757d"},
        )
        return empty, empty, label
    summary = build_loadings_summary(loadings, n_days=n_days)
    table = build_loadings_table(loadings, n_days=n_days)
    return summary, table, label


@callback(
    Output("qatar-mon-gulf-outflow", "figure"),
    Input("qatar-mon-gulf-flow-store", "data"),
    Input("qatar-mon-gulf-window", "value"),
)
def update_gulf_outflow(store_data, window_value):
    window = parse_outflow_window(window_value)
    frame = records_to_gulf_flow(store_data)
    return build_gulf_outflow_chart(frame, window=window)
