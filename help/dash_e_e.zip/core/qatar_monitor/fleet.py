"""Qatar LNG fleet classification from the Kpler vessels snapshot."""
from __future__ import annotations

import re
from typing import Any

import pandas as pd

from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table

from core.qatar_monitor.constants import (
    FLEET_CONTROLLER_PATTERN,
    FLEET_OWNER_PATTERN,
    FLEET_STATUS_ACTIVE,
)

KPLER_M3_TO_MCM = get_conversion_factor("cu m", "mcm", unit_conversion_table)

_CTRL_RE = re.compile(FLEET_CONTROLLER_PATTERN, re.IGNORECASE)
_OWN_RE = re.compile(FLEET_OWNER_PATTERN, re.IGNORECASE)


def _match_text(series: pd.Series, pattern: re.Pattern[str]) -> pd.Series:
    text = series.fillna("").astype(str)
    return text.map(lambda s: bool(pattern.search(s)))


def _active_mask(vessels: pd.DataFrame) -> pd.Series:
    if "Status" not in vessels.columns:
        return pd.Series(True, index=vessels.index)
    return vessels["Status"].fillna("").astype(str).str.strip().eq(FLEET_STATUS_ACTIVE)


def _capacity_mcm(vessels: pd.DataFrame) -> pd.Series:
    if "Capacity (m3)" in vessels.columns:
        cap = pd.to_numeric(vessels["Capacity (m3)"], errors="coerce")
    elif "Capacity" in vessels.columns:
        cap = pd.to_numeric(vessels["Capacity"], errors="coerce")
    else:
        cap = pd.Series(0.0, index=vessels.index)
    return cap.fillna(0.0) * KPLER_M3_TO_MCM


def _cargo_mcm(vessels: pd.DataFrame) -> pd.Series:
    if "Volume" not in vessels.columns:
        return pd.Series(0.0, index=vessels.index)
    return pd.to_numeric(vessels["Volume"], errors="coerce").fillna(0.0) * KPLER_M3_TO_MCM


def _vessel_type_series(vessels: pd.DataFrame) -> pd.Series:
    if "Vessel type" not in vessels.columns:
        return pd.Series("", index=vessels.index)
    return vessels["Vessel type"].fillna("").astype(str)


def _count_type(vessels: pd.DataFrame, label: str) -> int:
    types = _vessel_type_series(vessels)
    return int(types.str.strip().eq(label).sum())


def _segment_stats(vessels: pd.DataFrame, *, label: str) -> dict[str, Any]:
    cargo = _cargo_mcm(vessels)
    capacity = _capacity_mcm(vessels)
    laden = cargo > 0
    unladen = ~laden
    return {
        "segment": label,
        "vessels": int(len(vessels)),
        "q_max": _count_type(vessels, "Q-Max"),
        "q_flex": _count_type(vessels, "Q-Flex"),
        "capacity_mcm": float(capacity.sum()),
        "laden": int(laden.sum()),
        "laden_mcm": float(cargo[laden].sum()),
        "unladen": int(unladen.sum()),
        "unladen_capacity_mcm": float(capacity[unladen].sum()),
    }


def qatar_fleet_slices(vessels: pd.DataFrame | None) -> dict[str, pd.DataFrame]:
    """
    Active vessels controlled by QatarEnergy and owned by QatarEnergy/Qatargas.

    These slices are independent filters (not exclusive partitions). Owned
    vessels that are also QatarEnergy-controlled appear in both rows.
    """
    if vessels is None or vessels.empty:
        return {
            "controlled": pd.DataFrame(),
            "owned": pd.DataFrame(),
        }

    active = vessels.loc[_active_mask(vessels)].copy()
    ctrl_col = (
        active["Current controller"]
        if "Current controller" in active.columns
        else pd.Series("", index=active.index)
    )
    own_col = (
        active["Owners"]
        if "Owners" in active.columns
        else pd.Series("", index=active.index)
    )
    controlled = active.loc[_match_text(ctrl_col, _CTRL_RE)]
    owned = active.loc[_match_text(own_col, _OWN_RE)]
    return {"controlled": controlled, "owned": owned}


def summarize_qatar_fleet(vessels: pd.DataFrame | None) -> pd.DataFrame:
    """
    Summary rows for the Qatar Fleet table.

    Columns: segment, vessels, q_max, q_flex, capacity_mcm, laden, laden_mcm,
    unladen, unladen_capacity_mcm.
    """
    slices = qatar_fleet_slices(vessels)
    rows = [
        _segment_stats(
            slices["controlled"],
            label="QatarEnergy controlled",
        ),
        _segment_stats(
            slices["owned"],
            label="QatarEnergy / Qatargas owned",
        ),
    ]
    return pd.DataFrame(rows)
