"""Layout for the LNG — Qatar Monitor page."""
from __future__ import annotations

from dash import dcc, html

from core.qatar_monitor.constants import (
    FLEET_LOCATION_SECTION_NOTE,
    FLEET_SECTION_NOTE,
    GULF_OUTFLOW_SECTION_LEAD,
    GULF_OUTFLOW_SECTION_LEAD_AFTER,
    GULF_OUTFLOW_SECTION_NOTE,
    GULF_OUTFLOW_WINDOW_DEFAULT,
    KPLER_HORMUZ_DASHBOARD_URL,
    GULF_OUTFLOW_WINDOWS,
    GULF_SECTION_NOTE,
    LOADINGS_HISTORY_DAYS,
    LOADINGS_HISTORY_DAYS_MAX,
    LOADINGS_HISTORY_DAYS_MIN,
)
from core.styles import COLORS

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "center",
    "flexWrap": "wrap",
    "gap": "12px",
}

_BTN_PRIMARY = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
    "transition": "all 0.2s",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "hidden",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 12px 0",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}


def build_layout() -> html.Div:
    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1400px"},
        children=[
            dcc.Store(id="qatar-mon-loadings-store"),
            dcc.Store(id="qatar-mon-gulf-flow-store"),
            html.Div(
                children=[
                    html.H1(
                        "Qatar Monitor",
                        style={
                            "fontSize": "22px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "margin": "0 0 4px 0",
                        },
                    ),
                    html.P(
                        "Qatar LNG loadings, fleet and ship positions from Kpler "
                        "and Bloomberg.",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 12px 0",
                        },
                    ),
                ]
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Snapshot", style=_PANEL_TITLE),
                    dcc.Loading(
                        type="circle",
                        children=html.Div(id="qatar-mon-headline"),
                    ),
                ],
            ),
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Button(
                        "Refresh from cache",
                        id="qatar-mon-refresh-cache",
                        n_clicks=0,
                        title="Rebuild charts from the existing local Kpler / Bloomberg caches (no API call)",
                        style=_BTN_PRIMARY,
                    ),
                    html.Button(
                        "Refresh from Kpler / Bloomberg",
                        id="qatar-mon-refresh-live",
                        n_clicks=0,
                        title="Query Kpler LNG and Bloomberg ship positions and rebuild local caches",
                        style=_BTN_PRIMARY,
                    ),
                    html.Div(id="qatar-mon-status"),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Ras Laffan Activity", style=_PANEL_TITLE),
                    dcc.Loading(
                        type="circle",
                        children=dcc.Graph(
                            id="qatar-mon-chart",
                            config={"displayModeBar": True, "displaylogo": False},
                            style={"height": "1520px"},
                        ),
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Ras Laffan Loadings", style=_PANEL_TITLE),
                    html.P(
                        "Current berth occupancy and recent vessel calls at Ras "
                        "Laffan. Vessel names link through to Kpler Terminal.",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "margin": "0 0 14px 0",
                            "maxWidth": "900px",
                        },
                    ),
                    html.Div(id="qatar-mon-loadings-summary"),
                    html.Div(
                        style={"maxWidth": "480px", "marginBottom": "12px"},
                        children=[
                            html.Label(
                                id="qatar-mon-loadings-days-label",
                                children=f"History ({LOADINGS_HISTORY_DAYS} days)",
                                style=_LABEL,
                            ),
                            dcc.Slider(
                                id="qatar-mon-loadings-days",
                                min=LOADINGS_HISTORY_DAYS_MIN,
                                max=LOADINGS_HISTORY_DAYS_MAX,
                                step=1,
                                value=LOADINGS_HISTORY_DAYS,
                                marks={
                                    LOADINGS_HISTORY_DAYS_MIN: str(
                                        LOADINGS_HISTORY_DAYS_MIN
                                    ),
                                    7: "7",
                                    14: "14",
                                    30: "30",
                                    LOADINGS_HISTORY_DAYS_MAX: str(
                                        LOADINGS_HISTORY_DAYS_MAX
                                    ),
                                },
                                tooltip={
                                    "placement": "bottom",
                                    "always_visible": False,
                                },
                                updatemode="mouseup",
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="circle",
                        children=html.Div(id="qatar-mon-loadings-table"),
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Qatar Fleet Stats", style=_PANEL_TITLE),
                    html.P(
                        FLEET_SECTION_NOTE,
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "lineHeight": "1.5",
                            "margin": "0 0 14px 0",
                            "maxWidth": "980px",
                        },
                    ),
                    dcc.Loading(
                        type="circle",
                        children=html.Div(id="qatar-mon-fleet-table"),
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Qatar Fleet Location", style=_PANEL_TITLE),
                    html.P(
                        FLEET_LOCATION_SECTION_NOTE,
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "lineHeight": "1.5",
                            "margin": "0 0 14px 0",
                            "maxWidth": "980px",
                        },
                    ),
                    dcc.Loading(
                        type="circle",
                        children=html.Div(id="qatar-mon-fleet-location-table"),
                    ),
                    dcc.Loading(
                        type="circle",
                        children=dcc.Graph(
                            id="qatar-mon-fleet-map",
                            config={"displayModeBar": True, "displaylogo": False},
                            style={"height": "560px"},
                        ),
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Pre / post Iran comparison", style=_PANEL_TITLE),
                    html.Div(id="qatar-mon-tables"),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Persian Gulf Outflow", style=_PANEL_TITLE),
                    html.P(
                        [
                            GULF_OUTFLOW_SECTION_LEAD,
                            html.A(
                                "Kpler Hormuz Dashboard",
                                href=KPLER_HORMUZ_DASHBOARD_URL,
                                target="_blank",
                                rel="noopener noreferrer",
                                style={
                                    "color": COLORS["accent"],
                                    "fontWeight": "600",
                                    "textDecoration": "none",
                                },
                            ),
                            GULF_OUTFLOW_SECTION_LEAD_AFTER,
                        ],
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "lineHeight": "1.5",
                            "margin": "0 0 8px 0",
                            "maxWidth": "980px",
                        },
                    ),
                    html.P(
                        GULF_OUTFLOW_SECTION_NOTE,
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "lineHeight": "1.5",
                            "margin": "0 0 18px 0",
                            "maxWidth": "980px",
                        },
                    ),
                    html.Div(
                        style={"maxWidth": "480px", "marginBottom": "28px"},
                        children=[
                            html.Label("Moving average", style=_LABEL),
                            dcc.RadioItems(
                                id="qatar-mon-gulf-window",
                                options=[
                                    {"label": f" {n}d", "value": n}
                                    for n in GULF_OUTFLOW_WINDOWS
                                ],
                                value=GULF_OUTFLOW_WINDOW_DEFAULT,
                                inline=True,
                                inputStyle={"marginRight": "4px"},
                                labelStyle={
                                    "marginRight": "16px",
                                    "fontSize": "13px",
                                    "color": COLORS["text_primary"],
                                },
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="circle",
                        children=dcc.Graph(
                            id="qatar-mon-gulf-outflow",
                            config={"displayModeBar": True, "displaylogo": False},
                            style={"height": "740px"},
                        ),
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Persian Gulf Imports", style=_PANEL_TITLE),
                    html.P(
                        GULF_SECTION_NOTE,
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "lineHeight": "1.5",
                            "margin": "0 0 16px 0",
                            "maxWidth": "980px",
                        },
                    ),
                    html.Div(
                        style={
                            "display": "flex",
                            "flexWrap": "wrap",
                            "gap": "20px",
                            "alignItems": "stretch",
                        },
                        children=[
                            html.Div(
                                style={"flex": "1 1 480px", "minWidth": "420px"},
                                children=[
                                    dcc.Loading(
                                        type="circle",
                                        children=dcc.Graph(
                                            id="qatar-mon-gulf-kuwait",
                                            config={
                                                "displayModeBar": True,
                                                "displaylogo": False,
                                            },
                                            style={"height": "400px"},
                                        ),
                                    ),
                                ],
                            ),
                            html.Div(
                                style={"flex": "1 1 480px", "minWidth": "420px"},
                                children=[
                                    dcc.Loading(
                                        type="circle",
                                        children=dcc.Graph(
                                            id="qatar-mon-gulf-uae",
                                            config={
                                                "displayModeBar": True,
                                                "displaylogo": False,
                                            },
                                            style={"height": "400px"},
                                        ),
                                    ),
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )
