"""Qatar Monitor — read Kpler / Bloomberg caches and derive views."""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pandas as pd

from core.lng_data_bbg_ships.data import (
    force_refresh_bbg_ships,
    get_bbg_ships,
)
from core.lng_data_kpler.constants import QATAR_EXPORTS_KEY, VESSELS_KEY
from core.lng_data_kpler.data import (
    force_refresh_kpler,
    format_kpler_refresh_age,
    get_cached_kpler_payload,
    get_dataset_trades,
    get_dataset_vessels,
    get_kpler_last_refresh,
)
from core.lng_data_kpler.qatar_exports import (
    build_gap_table,
    enrich_loadings_with_vessels,
    get_ras_laffan_loadings,
    monthly_imports_by_destination_arrival,
    qatar_daily_exports,
    qatar_monthly_exports_by_destination,
)
from core.qatar_monitor.constants import (
    CHART_START,
    GULF_COUNTRIES,
)
from core.qatar_monitor.gulf_outflow import build_gulf_flow_frame
from core.qatar_monitor.fleet import summarize_qatar_fleet
from core.qatar_monitor.fleet_positions import (
    join_fleet_positions,
    summarize_fleet_by_zone,
)

logger = logging.getLogger(__name__)


def get_qatar_trades() -> pd.DataFrame:
    return get_dataset_trades(QATAR_EXPORTS_KEY)


def _load_vessels(payload: dict[str, Any], *, refresh: bool) -> pd.DataFrame | None:
    try:
        if refresh:
            vessels = (
                (payload.get("datasets") or {}).get(VESSELS_KEY, {}).get("vessels")
            )
            if vessels is None or not isinstance(vessels, pd.DataFrame):
                vessels = get_dataset_vessels()
        else:
            vessels = get_dataset_vessels()
        return vessels
    except Exception as exc:
        logger.warning("Kpler vessels snapshot unavailable: %s", exc)
        return None


def _load_bbg_ships(*, refresh: bool) -> pd.DataFrame | None:
    try:
        if refresh:
            payload = force_refresh_bbg_ships()
            ships = payload.get("ships")
            if ships is None or not isinstance(ships, pd.DataFrame):
                ships = get_bbg_ships()
            return ships
        return get_bbg_ships()
    except Exception as exc:
        logger.warning("Bloomberg LNG ships snapshot unavailable: %s", exc)
        return None


def get_monitor_frames(
    *,
    refresh: bool = False,
) -> tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    dict[str, pd.DataFrame],
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    datetime | None,
    pd.DataFrame,
]:
    """
    Return
    (gap_table, daily_exports, loadings, monthly_by_destination,
     gulf_monthly_imports, fleet_summary, fleet_zone_summary,
     fleet_positions, last_refresh, gulf_flow_daily).
    """
    payload: dict[str, Any]
    if refresh:
        payload = force_refresh_kpler()
        trades = (payload.get("datasets") or {}).get(QATAR_EXPORTS_KEY, {}).get("trades")
        if trades is None or not isinstance(trades, pd.DataFrame):
            trades = get_qatar_trades()
    else:
        payload = get_cached_kpler_payload()
        trades = get_qatar_trades()

    vessels = _load_vessels(payload, refresh=refresh)
    bbg_ships = _load_bbg_ships(refresh=refresh)
    loadings = enrich_loadings_with_vessels(get_ras_laffan_loadings(trades), vessels)
    gap = build_gap_table(loadings, since=CHART_START)
    exports = qatar_daily_exports(trades)
    by_dest = qatar_monthly_exports_by_destination(trades, since=CHART_START)
    gulf = {
        country: monthly_imports_by_destination_arrival(trades, country)
        for country in GULF_COUNTRIES
    }
    fleet = summarize_qatar_fleet(vessels)
    fleet_positions = join_fleet_positions(vessels, bbg_ships, loadings)
    fleet_zones = summarize_fleet_by_zone(fleet_positions)
    gulf_flow = build_gulf_flow_frame(trades, exports)
    last = get_kpler_last_refresh(payload)
    return (
        gap,
        exports,
        loadings,
        by_dest,
        gulf,
        fleet,
        fleet_zones,
        fleet_positions,
        last,
        gulf_flow,
    )


def status_line(
    last_refresh: datetime | None,
    *,
    latest_data_date: datetime | pd.Timestamp | None = None,
    button_clicked_at: datetime | None = None,
    source: str = "initial",
) -> str:
    """
    Status text for the Qatar Monitor control badge.

    *source*:
      - ``live`` — just completed a live Kpler + Bloomberg pull
      - ``cache`` — rebuilt views from the local caches only
      - ``initial`` — first page load (serving whatever is in cache)
    """
    when = last_refresh
    if when is None:
        when = get_kpler_last_refresh()
    age = format_kpler_refresh_age(when)

    if latest_data_date is not None and not pd.isna(latest_data_date):
        through = f" · data through {pd.Timestamp(latest_data_date).strftime('%d-%b-%Y')}"
    else:
        through = ""

    if source == "live":
        action = "Live pull from Kpler + Bloomberg completed (caches updated)"
    elif source == "cache":
        action = "Reloaded from local Kpler / Bloomberg caches (no API call)"
    else:
        action = "Serving local Kpler / Bloomberg caches"

    base = f"{action}{through} · {age}"
    if button_clicked_at is not None:
        click = pd.Timestamp(button_clicked_at)
        if click.tzinfo is not None:
            click = click.astimezone().replace(tzinfo=None)
        label = "requested" if source in ("live", "cache") else "loaded"
        base = f"{base} · {label} at {click.strftime('%d-%b %H:%M')}"
    return base
