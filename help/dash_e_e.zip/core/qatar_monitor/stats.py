"""Pre/post Iran berth utilisation and loading-tempo stats."""
from __future__ import annotations

from typing import Any

import pandas as pd

from core.qatar_monitor.constants import (
    CHART_START,
    POST_STRIKE_LABEL,
    POST_STRIKE_START,
    PRE_WAR_END,
    PRE_WAR_LABEL,
    PRE_WAR_START,
)


def concurrency_stats(
    loadings: pd.DataFrame,
    start: pd.Timestamp,
    end: pd.Timestamp,
    *,
    now: pd.Timestamp | None = None,
) -> dict[str, float]:
    """Time-weighted stats of vessels at berth in ``[start, end)``."""
    now = now or pd.Timestamp.now()
    if loadings is None or loadings.empty:
        return {
            "avg_concurrent": float("nan"),
            "max_concurrent": float("nan"),
            "pct_empty": float("nan"),
            "pct_one": float("nan"),
            "pct_two_plus": float("nan"),
            "pct_three_plus": float("nan"),
        }

    events: list[tuple[pd.Timestamp, int]] = []
    for _, r in loadings.iterrows():
        events.append((r["berth_arrival"], 1))
        dep = r["berth_departure"] if pd.notna(r["berth_departure"]) else now
        events.append((dep, -1))
    events.sort(key=lambda x: x[0])

    hours_at: dict[int, float] = {}
    n = 0
    t_prev = min(events[0][0], start)
    for t, delta in events:
        a, b = max(t_prev, start), min(t, end)
        if b > a:
            hours_at[n] = hours_at.get(n, 0.0) + (b - a).total_seconds() / 3600.0
        n += delta
        t_prev = t
    if end > max(t_prev, start):
        hours_at[n] = hours_at.get(n, 0.0) + (
            end - max(t_prev, start)
        ).total_seconds() / 3600.0

    total = sum(hours_at.values()) or 1.0
    occupied_levels = [k for k, v in hours_at.items() if v > 0]
    return {
        "avg_concurrent": sum(k * v for k, v in hours_at.items()) / total,
        "max_concurrent": float(max(occupied_levels)) if occupied_levels else 0.0,
        "pct_empty": 100.0 * hours_at.get(0, 0.0) / total,
        "pct_one": 100.0 * hours_at.get(1, 0.0) / total,
        "pct_two_plus": 100.0 * sum(v for k, v in hours_at.items() if k >= 2) / total,
        "pct_three_plus": 100.0 * sum(v for k, v in hours_at.items() if k >= 3) / total,
    }


def berth_time_stats(
    loadings: pd.DataFrame,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> dict[str, float]:
    """Stats on completed loadings arriving in ``[start, end)``."""
    if loadings is None or loadings.empty:
        return {
            "loadings_per_week": float("nan"),
            "avg_cargo_mcm": float("nan"),
            "hours_median": float("nan"),
            "hours_mean": float("nan"),
            "hours_p90": float("nan"),
            "hours_max": float("nan"),
            "n_completed": 0.0,
        }

    sub = loadings[
        (loadings["berth_arrival"] >= start)
        & (loadings["berth_arrival"] < end)
        & loadings["berth_departure"].notna()
    ].copy()
    hours = (
        (sub["berth_departure"] - sub["berth_arrival"]).dt.total_seconds() / 3600.0
    )
    weeks = max((end - start).total_seconds() / (168 * 3600.0), 1e-9)
    return {
        "n_completed": float(len(sub)),
        "loadings_per_week": len(sub) / weeks,
        "avg_cargo_mcm": float(sub["volume_mcm"].mean()) if len(sub) else float("nan"),
        "hours_median": float(hours.median()) if len(hours) else float("nan"),
        "hours_mean": float(hours.mean()) if len(hours) else float("nan"),
        "hours_p90": float(hours.quantile(0.9)) if len(hours) else float("nan"),
        "hours_max": float(hours.max()) if len(hours) else float("nan"),
    }


def build_period_stats(
    loadings: pd.DataFrame,
    *,
    now: pd.Timestamp | None = None,
) -> dict[str, dict[str, Any]]:
    """
    Pre-war vs post-strike stats dicts keyed by display column label.

    Uses the post-strike cut (18 Mar) so early-March queue clearing is excluded.
    """
    now = now or pd.Timestamp.now()
    periods = {
        PRE_WAR_LABEL: (pd.Timestamp(PRE_WAR_START), pd.Timestamp(PRE_WAR_END)),
        POST_STRIKE_LABEL: (pd.Timestamp(POST_STRIKE_START), now),
    }
    out: dict[str, dict[str, Any]] = {}
    for label, (start, end) in periods.items():
        out[label] = {
            **concurrency_stats(loadings, start, end, now=now),
            **berth_time_stats(loadings, start, end),
            "start": start,
            "end": end,
        }
    return out


def occupied_intervals(
    loadings: pd.DataFrame,
    *,
    now: pd.Timestamp | None = None,
) -> list[list[pd.Timestamp]]:
    """Merged intervals when at least one vessel is at berth."""
    now = pd.Timestamp(now or pd.Timestamp.now())
    if loadings is None or loadings.empty:
        return []
    intervals: list[list[pd.Timestamp]] = []
    rows = loadings.sort_values("berth_arrival")
    for _, row in rows.iterrows():
        start = pd.Timestamp(row["berth_arrival"])
        end = row["berth_departure"]
        end = now if pd.isna(end) else pd.Timestamp(end)
        if pd.isna(start):
            continue
        if intervals and start <= intervals[-1][1]:
            intervals[-1][1] = max(intervals[-1][1], end)
        else:
            intervals.append([start, end])
    return intervals


def empty_hours_7d_ma(
    loadings: pd.DataFrame,
    *,
    start: str | pd.Timestamp | None = None,
    now: pd.Timestamp | None = None,
    window: int = 7,
) -> pd.Series:
    """
    Rolling mean of hours/day with all Ras Laffan berths empty.

    Daily series runs from ``start`` through yesterday (complete days only).
    """
    now = pd.Timestamp(now or pd.Timestamp.now())
    start = pd.Timestamp(start or CHART_START)
    days = pd.date_range(start, now.normalize() - pd.Timedelta(days=1), freq="D")
    if len(days) == 0:
        return pd.Series(dtype=float)
    intervals = occupied_intervals(loadings, now=now)
    empty_hours: list[float] = []
    for day in days:
        d0, d1 = day, day + pd.Timedelta(days=1)
        occupied = sum(
            (min(end, d1) - max(start_i, d0)).total_seconds()
            for start_i, end in intervals
            if start_i < d1 and end > d0
        ) / 3600.0
        empty_hours.append(max(0.0, 24.0 - occupied))
    return pd.Series(empty_hours, index=days).rolling(int(window)).mean().dropna()
