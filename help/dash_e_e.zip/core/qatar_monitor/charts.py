"""Plotly chart: Ras Laffan idle gaps, vessels at berth, and exports."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.lng_data_kpler.qatar_exports import N_BERTHS, qatar_weekly_exports
from core.qatar_monitor.constants import CHART_START, EVENTS
from core.qatar_monitor.stats import empty_hours_7d_ma, occupied_intervals
from core.styles import COLORS

_HOVERLABEL = dict(
    bgcolor="#ffffff",
    bordercolor="#2c3e50",
    font=dict(color="#231F20", size=13, family="Segoe UI, Arial, sans-serif"),
)

_VESSEL_COUNT_COLORS = {
    1: "#9aa7b0",
    2: "#5dade2",
    3: "#2e86c1",
    4: "#1a5276",
    5: "#6c3483",
    6: "#1b4f72",
}

# Stacked monthly destination palette (top destinations + Other)
_DEST_COLORS = [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b",
    "#e377c2",
    "#17becf",
    "#bcbd22",
    "#7f7f7f",  # Other
]
_MONTH_BAR_WIDTH_MS = 20 * 24 * 60 * 60 * 1000  # ~20 days on a date axis
_WEEK_BAR_WIDTH_MS = 5 * 24 * 60 * 60 * 1000  # ~5 days


def _occupied_intervals(df: pd.DataFrame) -> list[list[pd.Timestamp]]:
    return occupied_intervals(df)


def _concurrency_step(
    loadings: pd.DataFrame,
    *,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> pd.DataFrame:
    """Step series of concurrent vessels at berth over ``[start, end]``."""
    now = pd.Timestamp.now()
    events: list[tuple[pd.Timestamp, int]] = []
    for _, r in loadings.iterrows():
        events.append((pd.Timestamp(r["berth_arrival"]), 1))
        dep = r["berth_departure"]
        events.append((pd.Timestamp(dep) if pd.notna(dep) else now, -1))
    events.sort(key=lambda x: x[0])

    xs: list[pd.Timestamp] = [start]
    ys: list[int] = [0]
    n = 0
    for t, delta in events:
        if t < start:
            n += delta
            ys[0] = max(0, n)
            continue
        if t > end:
            break
        xs.append(t)
        ys.append(n)
        n = max(0, n + delta)
        xs.append(t)
        ys.append(n)
    xs.append(end)
    ys.append(ys[-1] if ys else 0)
    return pd.DataFrame({"time": xs, "n": ys})


def _assign_berth_lanes(
    loadings: pd.DataFrame,
    *,
    now: pd.Timestamp | None = None,
) -> pd.DataFrame:
    """
    Pack concurrent berth stays onto integer y-lanes (Gantt / swimlane).

    Lowest free lane whose previous stay has already ended is reused so
    overlapping calls stack with a clear vertical gap between lines.
    """
    now = pd.Timestamp(now or pd.Timestamp.now())
    if loadings is None or loadings.empty:
        return pd.DataFrame()

    rows = loadings.sort_values("berth_arrival").copy()
    lane_ends: list[pd.Timestamp] = []
    lanes: list[int] = []
    ends: list[pd.Timestamp] = []
    for _, r in rows.iterrows():
        start = pd.Timestamp(r["berth_arrival"])
        end = (
            pd.Timestamp(r["berth_departure"])
            if pd.notna(r["berth_departure"])
            else now
        )
        assigned: int | None = None
        for i, le in enumerate(lane_ends):
            if le <= start:
                lane_ends[i] = end
                assigned = i
                break
        if assigned is None:
            assigned = len(lane_ends)
            lane_ends.append(end)
        lanes.append(assigned)
        ends.append(end)
    rows = rows.reset_index(drop=True)
    rows["lane"] = lanes
    rows["berth_end"] = ends
    return rows


def build_idle_gap_chart(
    gap_df: pd.DataFrame,
    exports_df: pd.DataFrame,
    dest_monthly: pd.DataFrame | None = None,
) -> go.Figure:
    """
    Six-panel chart (shared x-axis from CHART_START):
      1 — idle gaps between loadings + 7d empty-hours MA
      2 — vessels at berth (stems at each arrival + occupancy step)
      3 — per-vessel berth timeline (Gantt-style horizontal stays)
      4 — Qatar LNG exports 7d MA (mcm/d)
      5 — weekly export totals (mcm/week)
      6 — monthly export volume by destination country (stacked bars, mcm)
    """
    fig = make_subplots(
        rows=6,
        cols=1,
        shared_xaxes=True,
        row_heights=[0.22, 0.11, 0.16, 0.13, 0.14, 0.24],
        vertical_spacing=0.085,
        subplot_titles=(
            "Ras Laffan: Breaks between LNG loadings",
            "Vessels at berth",
            "Vessel berth stays",
            "Ras Laffan LNG Exports (7d moving avg)",
            "Ras Laffan LNG Exports (weekly total)",
            "Monthly LNG exports by destination",
        ),
        specs=[
            [{"secondary_y": True}],
            [{"secondary_y": False}],
            [{"secondary_y": False}],
            [{"secondary_y": False}],
            [{"secondary_y": False}],
            [{"secondary_y": False}],
        ],
    )

    if gap_df is None or gap_df.empty:
        fig.add_annotation(
            text="No Ras Laffan loading data in the Kpler cache.",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font={"size": 14, "color": COLORS["text_muted"]},
        )
        fig.update_layout(
            height=1520,
            margin=dict(l=60, r=60, t=50, b=40),
            paper_bgcolor=COLORS["chart_paper"],
            plot_bgcolor=COLORS["chart_bg"],
            hoverlabel=_HOVERLABEL,
        )
        return fig

    df = gap_df.sort_values("berth_arrival").copy()
    gaps = df[(df["idle_gap_hours"] > 0) & df["prev_departure"].notna()].copy()
    intervals = _occupied_intervals(df)
    now = pd.Timestamp.now()
    x_end = now + pd.Timedelta(days=1)
    x0 = pd.Timestamp(CHART_START)
    top = max(24.0, float(df["idle_gap_hours"].max()) if len(df) else 24.0)

    # Ongoing empty spell: all berths free since the last departure, with no
    # subsequent arrival yet — closed gaps only appear on the next arrival.
    still_at_berth = df["berth_departure"].isna().any()
    if not still_at_berth and df["berth_departure"].notna().any():
        last_dep = pd.Timestamp(df["berth_departure"].max())
        if pd.notna(last_dep) and last_dep < now:
            open_hours = (now - last_dep).total_seconds() / 3600.0
            if open_hours > 0:
                open_gap = pd.DataFrame(
                    {
                        "prev_departure": [last_dep],
                        "berth_arrival": [now],
                        "idle_gap_hours": [open_hours],
                        "vessel": [pd.NA],
                    }
                )
                gaps = (
                    open_gap
                    if gaps.empty
                    else pd.concat([gaps, open_gap], ignore_index=True)
                )
                top = max(top, open_hours)

    def _add_occupied_shading(row: int) -> None:
        # Must run after at least one trace exists on this subplot — otherwise
        # Plotly silently drops the shapes (empty figure.layout.shapes).
        for start, end in intervals:
            fig.add_vrect(
                x0=start,
                x1=end,
                fillcolor="rgba(47, 125, 108, 0.12)",
                line_width=0,
                layer="below",
                row=row,
                col=1,
                secondary_y=False,
            )

    # Idle-gap rectangles
    if not gaps.empty:
        xs: list = []
        ys: list = []
        hover_x: list = []
        hover_y: list = []
        hover_text: list = []
        for _, g in gaps.iterrows():
            x_left = pd.Timestamp(g["prev_departure"])
            x_right = pd.Timestamp(g["berth_arrival"])
            h = float(g["idle_gap_hours"])
            xs.extend([x_left, x_right, x_right, x_left, x_left, None])
            ys.extend([0.0, 0.0, h, h, 0.0, None])
            hover_x.append(x_left + (x_right - x_left) / 2)
            hover_y.append(h / 2.0)
            vessel = g["vessel"] if "vessel" in g and pd.notna(g["vessel"]) else ""
            if vessel:
                ended = f"<br>ended by arrival of {vessel}"
            elif x_right >= now - pd.Timedelta(minutes=5):
                ended = "<br>ongoing (terminal empty)"
            else:
                ended = ""
            hover_text.append(
                f"<b style='color:#231F20'>{h:.1f} hours</b>"
                f"<span style='color:#231F20'> with all berths empty<br>"
                f"{x_left:%d %b %Y %H:%M} → {x_right:%d %b %Y %H:%M}"
                + ended
                + "</span>"
            )
        fig.add_trace(
            go.Scatter(
                x=xs,
                y=ys,
                fill="toself",
                fillcolor="rgba(192, 57, 43, 0.80)",
                line=dict(width=0.8, color="#c0392b"),
                mode="lines",
                name=f"break with all {N_BERTHS} berths empty",
                hoverinfo="skip",
                legendgroup="gaps",
                showlegend=True,
            ),
            row=1,
            col=1,
            secondary_y=False,
        )
        # Invisible hover targets only — previous semi-transparent red markers
        # showed up as unexplained light-red circles on the gap bars.
        fig.add_trace(
            go.Scatter(
                x=hover_x,
                y=hover_y,
                mode="markers",
                marker=dict(size=28, color="rgba(0,0,0,0)", line=dict(width=0)),
                name="gap hours",
                text=hover_text,
                hovertemplate="%{text}<extra></extra>",
                hoverlabel=_HOVERLABEL,
                legendgroup="gaps",
                showlegend=False,
            ),
            row=1,
            col=1,
            secondary_y=False,
        )
    else:
        # Ensure the primary y-axis exists even when there are no idle gaps.
        fig.add_trace(
            go.Scatter(
                x=[x0, x_end],
                y=[0, 0],
                mode="lines",
                line=dict(width=0),
                hoverinfo="skip",
                showlegend=False,
            ),
            row=1,
            col=1,
            secondary_y=False,
        )

    # 7d MA empty hours (rhs)
    ma_empty = empty_hours_7d_ma(df, start=x0, now=now, window=7)

    if not ma_empty.empty:
        fig.add_trace(
            go.Scatter(
                x=ma_empty.index,
                y=ma_empty.values,
                mode="lines",
                line=dict(color="#7d3c98", width=2),
                name="hours/day all berths empty (7d MA, rhs)",
                hovertemplate="%{x|%d %b}: %{y:.1f} h/d<extra></extra>",
                hoverlabel=_HOVERLABEL,
            ),
            row=1,
            col=1,
            secondary_y=True,
        )
        fig.add_annotation(
            x=ma_empty.index[-1],
            y=ma_empty.iloc[-1],
            text=f"{ma_empty.iloc[-1]:.1f} h/d",
            showarrow=False,
            xanchor="right",
            yanchor="bottom",
            yshift=8,
            font=dict(size=11, color="#7d3c98", family="Arial Black"),
            xref="x",
            yref="y2",
        )

    # ── Row 2: vessels at berth (stems + occupancy step) ─────────────────
    # Real data traces first — an all-null legend proxy as the first trace
    # on this subplot can leave the panel blank.
    step = _concurrency_step(df, start=x0, end=x_end)
    fig.add_trace(
        go.Scatter(
            x=step["time"],
            y=step["n"],
            mode="lines",
            line=dict(color="rgba(26, 82, 118, 0.55)", width=1.4),
            fill="tozeroy",
            fillcolor="rgba(26, 82, 118, 0.12)",
            name="occupancy (continuous)",
            customdata=step["n"],
            hovertemplate=(
                "%{x|%d %b %Y %H:%M}<br>"
                "<b>%{customdata}</b> vessel(s) at berth"
                "<extra></extra>"
            ),
            hoverlabel=_HOVERLABEL,
            legend="legend2",
        ),
        row=2,
        col=1,
    )

    n_at = [int(n) for n in df["vessels_at_berth"].astype(int).clip(lower=1, upper=N_BERTHS)]
    stem_x: list = []
    stem_y: list = []
    for t, n in zip(df["berth_arrival"], n_at):
        stem_x.extend([t, t, None])
        stem_y.extend([0, n, None])

    fig.add_trace(
        go.Scatter(
            x=stem_x,
            y=stem_y,
            mode="lines",
            line=dict(color="#1a5276", width=1.6),
            name="vessels at berth on arrival",
            hoverinfo="skip",
            legendgroup="stems",
            legend="legend2",
            showlegend=True,
        ),
        row=2,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=list(df["berth_arrival"]),
            y=n_at,
            mode="markers",
            marker=dict(
                symbol="circle",
                size=8,
                color=[_VESSEL_COUNT_COLORS.get(n, "#2c3e50") for n in n_at],
                line=dict(width=0.5, color="#ffffff"),
            ),
            name="arrival count",
            customdata=list(zip(df["vessel"].astype(str), n_at)),
            hovertemplate=(
                "<b>%{customdata[0]}</b><br>"
                "%{x|%d %b %Y %H:%M}<br>"
                "Vessels at berth on arrival: <b>%{customdata[1]}</b>"
                "<extra></extra>"
            ),
            hoverlabel=_HOVERLABEL,
            legendgroup="stems",
            legend="legend2",
            showlegend=False,
        ),
        row=2,
        col=1,
    )
    # Legend-only swatch for occupied shading (after real traces exist)
    fig.add_trace(
        go.Scatter(
            x=[x0],
            y=[0],
            mode="markers",
            marker=dict(size=12, color="rgba(47, 125, 108, 0.4)", symbol="square"),
            name="≥1 vessel at berth (shaded)",
            legend="legend2",
            visible="legendonly",
        ),
        row=2,
        col=1,
    )
    _add_occupied_shading(2)

    # ── Row 3: per-vessel berth stays (Gantt / swimlane) ──────────────────
    now = pd.Timestamp.now()
    stays = _assign_berth_lanes(df, now=now)
    if not stays.empty:
        # Clip visible window slightly for hover clarity
        n_lanes = int(stays["lane"].max()) + 1
        # Completed stays (one multi-segment trace)
        done = stays[stays["berth_departure"].notna()]
        loading = stays[stays["berth_departure"].isna()]

        def _stay_segments(frame: pd.DataFrame) -> tuple[list, list, list]:
            xs: list = []
            ys: list = []
            hover: list = []
            for _, r in frame.iterrows():
                start = pd.Timestamp(r["berth_arrival"])
                end = pd.Timestamp(r["berth_end"])
                lane = int(r["lane"]) + 1  # 1-based for a small axis pad
                hours = (end - start).total_seconds() / 3600.0
                vessel = str(r.get("vessel") or "—")
                status = str(r.get("status") or "—")
                vol = r.get("volume_mcm")
                vol_txt = f"{float(vol):,.0f} mcm" if pd.notna(vol) else "—"
                dest = r.get("destination")
                dest_txt = (
                    str(dest) if dest is not None and pd.notna(dest) and str(dest).strip()
                    else "—"
                )
                dep_txt = (
                    f"{pd.Timestamp(r['berth_departure']):%d %b %Y %H:%M}"
                    if pd.notna(r.get("berth_departure"))
                    else "still loading"
                )
                tip = (
                    f"<b>{vessel}</b><br>"
                    f"Status: {status}<br>"
                    f"Arrival: {start:%d %b %Y %H:%M}<br>"
                    f"Departure: {dep_txt}<br>"
                    f"Time at berth: {hours:.0f} hrs<br>"
                    f"Volume: {vol_txt}<br>"
                    f"Destination: {dest_txt}"
                )
                # Line with markers at both ends; duplicate hover on each point
                xs.extend([start, end, None])
                ys.extend([lane, lane, None])
                hover.extend([tip, tip, ""])
            return xs, ys, hover

        if not done.empty:
            xs, ys, hover = _stay_segments(done)
            fig.add_trace(
                go.Scatter(
                    x=xs,
                    y=ys,
                    mode="lines+markers",
                    line=dict(color="#2c6fbb", width=3.5),
                    marker=dict(
                        size=7,
                        color="#2c6fbb",
                        symbol="circle",
                        line=dict(width=0.5, color="#ffffff"),
                    ),
                    name="completed stay",
                    hovertext=hover,
                    hoverinfo="text",
                    hoverlabel=_HOVERLABEL,
                    legend="legend3",
                    showlegend=True,
                ),
                row=3,
                col=1,
            )
        if not loading.empty:
            xs, ys, hover = _stay_segments(loading)
            fig.add_trace(
                go.Scatter(
                    x=xs,
                    y=ys,
                    mode="lines+markers",
                    line=dict(color="#c0392b", width=3.5),
                    marker=dict(
                        size=8,
                        color="#c0392b",
                        symbol="circle",
                        line=dict(width=0.5, color="#ffffff"),
                    ),
                    name="still loading",
                    hovertext=hover,
                    hoverinfo="text",
                    hoverlabel=_HOVERLABEL,
                    legend="legend3",
                    showlegend=True,
                ),
                row=3,
                col=1,
            )
        fig.update_yaxes(
            title_text="lane",
            range=[0.4, n_lanes + 0.6],
            dtick=1,
            showticklabels=False,
            row=3,
            col=1,
            gridcolor="rgba(0,0,0,0.06)",
            zeroline=False,
        )
    else:
        fig.update_yaxes(
            title_text="lane",
            range=[0, 1],
            showticklabels=False,
            row=3,
            col=1,
        )

    # ── Row 4: exports 7d MA ─────────────────────────────────────────────
    if exports_df is not None and not exports_df.empty:
        ma = (
            exports_df.set_index("date")["value"]
            .sort_index()
            .rolling(7)
            .mean()
            .dropna()
        )
        fig.add_trace(
            go.Scatter(
                x=ma.index,
                y=ma.values,
                mode="lines",
                line=dict(color="#2c6fbb", width=2),
                name="exports 7d MA",
                hovertemplate="%{x|%d %b}: %{y:.0f} mcm/d<extra></extra>",
                hoverlabel=_HOVERLABEL,
                showlegend=False,
            ),
            row=4,
            col=1,
        )

    # ── Row 5: weekly export totals ──────────────────────────────────────
    weekly = qatar_weekly_exports(exports_df, since=CHART_START)
    if weekly is not None and not weekly.empty:
        # Centre bars mid-week (week_start is Monday)
        week_x = pd.DatetimeIndex(weekly["week_start"]) + pd.Timedelta(days=3)
        n_cargoes = (
            weekly["n_cargoes"].astype(int).tolist()
            if "n_cargoes" in weekly.columns
            else [0] * len(weekly)
        )
        fig.add_trace(
            go.Bar(
                x=week_x,
                y=weekly["value"].values,
                name="weekly exports",
                width=_WEEK_BAR_WIDTH_MS,
                marker_color="#2c6fbb",
                opacity=0.85,
                hovertemplate=(
                    "Week of %{customdata[0]}<br>"
                    "<b>%{y:,.0f} mcm</b><br>"
                    "%{customdata[1]} cargoes"
                    "<extra></extra>"
                ),
                customdata=[
                    [pd.Timestamp(d).strftime("%d %b %Y"), n]
                    for d, n in zip(weekly["week_start"], n_cargoes)
                ],
                hoverlabel=_HOVERLABEL,
                showlegend=False,
                offsetgroup="weekly",
            ),
            row=5,
            col=1,
        )

    # ── Row 6: monthly volume by destination (stacked) ───────────────────
    if dest_monthly is not None and not dest_monthly.empty:
        # Place bars at mid-month so they sit under the continuous date axis
        months = pd.DatetimeIndex(dest_monthly.index) + pd.Timedelta(days=14)
        monthly_totals = dest_monthly.sum(axis=1)
        for i, dest in enumerate(dest_monthly.columns):
            color = (
                "#7f7f7f"
                if dest == "Other"
                else _DEST_COLORS[i % (len(_DEST_COLORS) - 1)]
            )
            fig.add_trace(
                go.Bar(
                    x=months,
                    y=dest_monthly[dest].values,
                    name=str(dest),
                    width=_MONTH_BAR_WIDTH_MS,
                    marker_color=color,
                    hovertemplate=(
                        f"<b>{dest}</b><br>"
                        "%{x|%b %Y}<br>"
                        "%{y:,.0f} mcm"
                        "<extra></extra>"
                    ),
                    hoverlabel=_HOVERLABEL,
                    legend="legend4",
                    offsetgroup="monthly",
                ),
                row=6,
                col=1,
            )
        # Total mcm label on top of each stacked bar
        fig.add_trace(
            go.Scatter(
                x=months,
                y=monthly_totals.values,
                mode="text",
                text=[f"{v:,.0f}" for v in monthly_totals.values],
                textposition="top center",
                textfont=dict(size=11, color="#2c3e50", family="Segoe UI, Arial"),
                hoverinfo="skip",
                showlegend=False,
                cliponaxis=False,
            ),
            row=6,
            col=1,
        )

    # Event lines on all panels; labels on top panel only
    prev_when = None
    for date, label in sorted(EVENTS.items()):
        when = pd.Timestamp(date)
        for row in (1, 2, 3, 4, 5, 6):
            fig.add_vline(
                x=when,
                line=dict(color="#2c3e50", width=1, dash="dash"),
                row=row,
                col=1,
            )
        near_edge = when > x_end - pd.Timedelta(days=14)
        y_offset = 0
        if near_edge and prev_when is not None and (when - prev_when).days < 30:
            y_offset = -28
        fig.add_annotation(
            x=when,
            y=top * 1.05,
            text=f"{when:%d-%b}<br>{label}",
            showarrow=False,
            xanchor="right" if near_edge else "left",
            yanchor="top",
            xshift=-4 if near_edge else 4,
            yshift=y_offset,
            font=dict(size=10, color="#2c3e50"),
            align="left" if not near_edge else "right",
            xref="x",
            yref="y",
        )
        prev_when = when

    fig.update_yaxes(
        title_text="hours empty",
        range=[0, top * 1.12],
        row=1,
        col=1,
        secondary_y=False,
        gridcolor="rgba(0,0,0,0.08)",
        zeroline=False,
        dtick=24,
    )
    fig.update_yaxes(
        title_text="h/d empty (7d MA)",
        range=[0, 26],
        row=1,
        col=1,
        secondary_y=True,
        tickfont=dict(color="#7d3c98"),
        title_font=dict(color="#7d3c98", size=11),
        showgrid=False,
    )
    fig.update_yaxes(
        title_text="vessels",
        range=[0, N_BERTHS + 0.4],
        dtick=1,
        row=2,
        col=1,
        gridcolor="rgba(0,0,0,0.08)",
        zeroline=False,
    )
    fig.update_yaxes(
        title_text="mcm/d",
        rangemode="tozero",
        row=4,
        col=1,
        gridcolor="rgba(0,0,0,0.08)",
    )
    fig.update_yaxes(
        title_text="mcm / week",
        rangemode="tozero",
        row=5,
        col=1,
        gridcolor="rgba(0,0,0,0.08)",
    )
    fig.update_yaxes(
        title_text="mcm / month",
        rangemode="tozero",
        row=6,
        col=1,
        gridcolor="rgba(0,0,0,0.08)",
    )
    if dest_monthly is not None and not dest_monthly.empty:
        max_month = float(dest_monthly.sum(axis=1).max())
        if max_month > 0:
            fig.update_yaxes(
                range=[0, max_month * 1.14],
                row=6,
                col=1,
            )

    # Daily calendar labels on the top panels through the berth-stays chart
    for row in (1, 2, 3, 4):
        fig.update_xaxes(
            range=[x0, x_end],
            row=row,
            col=1,
            showticklabels=True,
            tickformat="%d %b",
            ticks="outside",
            tickfont=dict(size=11),
            showgrid=True,
            gridcolor="rgba(0,0,0,0.06)",
        )

    # Weekly labels under the weekly-total panel (Mon week-starts, every other
    # week when the span is long so labels stay readable).
    week_starts = pd.date_range(x0, x_end, freq="W-MON")
    if len(week_starts) == 0 or week_starts[0] > x0:
        first_mon = x0 - pd.Timedelta(days=x0.weekday())
        week_starts = pd.date_range(first_mon, x_end, freq="W-MON")
    week_starts = week_starts[(week_starts >= x0) & (week_starts <= x_end)]
    step = 2 if len(week_starts) > 16 else 1
    week_starts = week_starts[::step]
    # Prefer mid-week positions when bars are centred Thu (week_start + 3d)
    week_tick_x = [ws + pd.Timedelta(days=3) for ws in week_starts]
    week_tick_text = [ws.strftime("%d %b") for ws in week_starts]
    fig.update_xaxes(
        range=[x0, x_end],
        row=5,
        col=1,
        showticklabels=True,
        tickmode="array",
        tickvals=week_tick_x,
        ticktext=week_tick_text,
        ticks="outside",
        tickfont=dict(size=10),
        tickangle=-35,
        showgrid=True,
        gridcolor="rgba(0,0,0,0.06)",
    )

    # Monthly labels under the destination stack (e.g. Feb26)
    month_starts = pd.date_range(x0.to_period("M").to_timestamp(), x_end, freq="MS")
    month_tick_x = [ms + pd.Timedelta(days=14) for ms in month_starts]
    month_tick_text = [ms.strftime("%b%y") for ms in month_starts]
    fig.update_xaxes(
        range=[x0, x_end],
        row=6,
        col=1,
        showticklabels=True,
        tickmode="array",
        tickvals=month_tick_x,
        ticktext=month_tick_text,
        ticks="outside",
        tickfont=dict(size=11),
        showgrid=True,
        gridcolor="rgba(0,0,0,0.06)",
    )

    fig.update_layout(
        height=1520,
        barmode="stack",
        bargap=0.15,
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        font=dict(
            family="Segoe UI, Arial, sans-serif",
            size=12,
            color=COLORS["text_primary"],
        ),
        margin=dict(l=70, r=70, t=40, b=100),
        legend=dict(
            orientation="h",
            yanchor="top",
            y=0.72,
            xanchor="left",
            x=0.0,
            font=dict(size=11),
            bgcolor="rgba(255,255,255,0.9)",
            tracegroupgap=8,
        ),
        legend2=dict(
            orientation="h",
            yanchor="top",
            y=0.50,
            xanchor="left",
            x=0.0,
            font=dict(size=11),
            bgcolor="rgba(255,255,255,0.9)",
            tracegroupgap=8,
        ),
        legend3=dict(
            orientation="h",
            yanchor="top",
            y=0.35,
            xanchor="left",
            x=0.0,
            font=dict(size=11),
            bgcolor="rgba(255,255,255,0.9)",
            tracegroupgap=8,
        ),
        legend4=dict(
            orientation="h",
            yanchor="top",
            y=0.0,
            xanchor="left",
            x=0.0,
            font=dict(size=11),
            bgcolor="rgba(255,255,255,0.9)",
            tracegroupgap=8,
        ),
        hovermode="closest",
        hoverlabel=_HOVERLABEL,
        uirevision="qatar-monitor-v7",
    )
    # Anchor legends just below their subplots
    # axes: y/y2=row1, y3=row2 vessels, y4=row3 stays, y5=row4 exports,
    #       y6=row5 weekly, y7=row6 destinations
    y_top = getattr(fig.layout, "yaxis", None)
    if y_top is not None and getattr(y_top, "domain", None):
        # Below daily x-axis labels on the idle-gap panel
        fig.layout.legend.y = float(y_top.domain[0]) - 0.038
        fig.layout.legend.yanchor = "top"
    y_vessels = getattr(fig.layout, "yaxis3", None)
    if y_vessels is not None and getattr(y_vessels, "domain", None):
        # Below daily x-axis labels on the vessels panel
        fig.layout.legend2.y = float(y_vessels.domain[0]) - 0.038
        fig.layout.legend2.yanchor = "top"
    y_stays = getattr(fig.layout, "yaxis4", None)
    if y_stays is not None and getattr(y_stays, "domain", None):
        # Below the vessel berth-stays panel
        fig.layout.legend3.y = float(y_stays.domain[0]) - 0.038
        fig.layout.legend3.yanchor = "top"
    y_dest = getattr(fig.layout, "yaxis7", None)
    if y_dest is not None and getattr(y_dest, "domain", None):
        # Sit below the monthly x-axis labels (Feb26 etc.), not on top of them
        fig.layout.legend4.y = float(y_dest.domain[0]) - 0.045
        fig.layout.legend4.yanchor = "top"

    for ann in fig.layout.annotations or []:
        text = str(ann.text or "")
        if (
            text.startswith("Ras Laffan")
            or text.startswith("Vessels")
            or text.startswith("Vessel berth")
            or text.startswith("Monthly")
        ):
            ann.font = dict(size=15, color="#2c3e50")
    return fig
