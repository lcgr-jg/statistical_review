"""LNG — Qatar Monitor page package."""
