"""YoY monthly import charts for Persian Gulf destinations."""
from __future__ import annotations

import math
from typing import Sequence

import pandas as pd
import plotly.graph_objects as go

from core.qatar_monitor.constants import (
    GULF_YOY_BAND_YEARS,
    GULF_YOY_LINE_YEARS,
)
from core.styles import COLORS

_HOVERLABEL = dict(
    bgcolor="#ffffff",
    bordercolor="#2c3e50",
    font=dict(color="#231F20", size=13, family="Segoe UI, Arial, sans-serif"),
)

_MONTH_LABELS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]

_YEAR_COLORS = [
    "#9aa7b0",  # oldest prior
    "#5dade2",
    "#2e86c1",
    "#c0392b",  # current (last)
]


def _monthly_total(monthly: pd.Series | pd.DataFrame) -> pd.Series:
    """Total mcm indexed by month-start. Accepts the legacy Series or the split frame."""
    if monthly is None or (isinstance(monthly, pd.DataFrame) and monthly.empty):
        return pd.Series(dtype=float)
    if isinstance(monthly, pd.DataFrame):
        if monthly.empty or "volume_mcm" not in monthly.columns:
            return pd.Series(dtype=float)
        s = monthly["volume_mcm"].copy()
    else:
        if monthly.empty:
            return pd.Series(dtype=float)
        s = monthly.copy()
    s.index = pd.to_datetime(s.index)
    return s.sort_index()


def _month_status_split(
    monthly: pd.Series | pd.DataFrame,
    year: int,
    month: int,
) -> tuple[float, float] | None:
    """Delivered and forecasted mcm for one month, when the frame carries the split."""
    if not isinstance(monthly, pd.DataFrame) or monthly.empty:
        return None
    if "delivered_mcm" not in monthly.columns or "forecast_mcm" not in monthly.columns:
        return None
    idx = pd.to_datetime(monthly.index)
    key = pd.Timestamp(year=year, month=month, day=1)
    hit = monthly.loc[idx == key]
    if hit.empty:
        return 0.0, 0.0
    return float(hit["delivered_mcm"].sum()), float(hit["forecast_mcm"].sum())


def _yearly_month_frame(monthly: pd.Series | pd.DataFrame) -> pd.DataFrame:
    """Pivot month-start Series → columns=year, index=month number 1–12."""
    s = _monthly_total(monthly)
    if s.empty:
        return pd.DataFrame()
    df = pd.DataFrame({
        "year": s.index.year.astype(int),
        "month": s.index.month.astype(int),
        "value": pd.to_numeric(s.values, errors="coerce"),
    }).dropna(subset=["value"])
    if df.empty:
        return pd.DataFrame()
    return (
        df.pivot_table(index="month", columns="year", values="value", aggfunc="sum")
        .reindex(range(1, 13))
        .sort_index()
    )


def _fill_zeros(
    series: pd.Series,
    *,
    through_month: int | None = None,
) -> pd.Series:
    """
    Treat missing months as 0 mcm (no cargoes), so seasonal markets like the
    UAE don't look truncated on Jan–Apr / Nov–Dec.

    If *through_month* is set (current year), only fill Jan…through_month and
    leave later months as NaN so we don't invent future zeros.
    """
    s = series.astype(float).copy()
    if through_month is None:
        return s.fillna(0.0)
    out = s.copy()
    out.loc[out.index <= through_month] = out.loc[out.index <= through_month].fillna(0.0)
    out.loc[out.index > through_month] = float("nan")
    return out


def _y_list(values: Sequence[float]) -> list[float | None]:
    """Plain JSON-safe y values for Dash (NaN → None)."""
    out: list[float | None] = []
    for v in values:
        try:
            x = float(v)
        except (TypeError, ValueError):
            out.append(None)
            continue
        out.append(None if math.isnan(x) else x)
    return out


def build_gulf_yoy_import_chart(
    monthly: pd.Series | pd.DataFrame,
    *,
    country_label: str,
    current_year: int | None = None,
    as_of: pd.Timestamp | None = None,
) -> go.Figure:
    """
    YoY monthly imports (mcm) into one destination.

    Lines: current year + previous ``GULF_YOY_LINE_YEARS`` years.
    Shaded band: min–max across the previous ``GULF_YOY_BAND_YEARS`` years
    (drawn only when at least two prior years are present).
    """
    fig = go.Figure()
    today = pd.Timestamp(as_of) if as_of is not None else pd.Timestamp.now()
    cur = int(current_year or today.year)
    # Open month of the current year. Prior years are complete.
    open_month = int(today.month) if cur == int(today.year) else None

    pivot = _yearly_month_frame(monthly)
    if pivot.empty:
        fig.add_annotation(
            text=f"No Qatar→{country_label} arrival data in the Kpler cache.",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font={"size": 14, "color": COLORS["text_muted"]},
        )
        fig.update_layout(
            height=360,
            margin=dict(l=50, r=30, t=40, b=40),
            paper_bgcolor=COLORS["chart_paper"],
            plot_bgcolor=COLORS["chart_bg"],
            title=dict(
                text=f"{country_label}: monthly imports from Qatar (YoY)",
                font=dict(size=14, color="#2c3e50"),
                x=0,
                xanchor="left",
            ),
        )
        return fig

    # Ensure integer year columns (disk/cache round-trips can widen dtypes).
    pivot.columns = [int(c) for c in pivot.columns]

    band_years = [y for y in range(cur - GULF_YOY_BAND_YEARS, cur) if y in pivot.columns]
    line_years = [y for y in range(cur - GULF_YOY_LINE_YEARS, cur + 1) if y in pivot.columns]

    months = list(range(1, 13))
    total = _monthly_total(monthly)
    if open_month is not None:
        # Extend through the calendar month even when it has no cargoes yet,
        # so a quiet Aug/Sep still draws as zero instead of stopping early.
        last_m = open_month
    elif total.empty:
        last_m = 12
    else:
        last_m = int(pd.Timestamp(total.index.max()).month)

    # Band needs ≥2 prior years; a single year makes min==max (invisible fill)
    # but still polluted the legend as "Prior 5Y range".
    if len(band_years) >= 2:
        band = pivot[band_years].apply(_fill_zeros)
        lo = band.min(axis=1)
        hi = band.max(axis=1)
        fig.add_trace(
            go.Scatter(
                x=months,
                y=_y_list(hi.values),
                mode="lines",
                line=dict(width=0),
                hoverinfo="skip",
                showlegend=False,
            )
        )
        fig.add_trace(
            go.Scatter(
                x=months,
                y=_y_list(lo.values),
                mode="lines",
                line=dict(width=0),
                fill="tonexty",
                fillcolor="rgba(150, 150, 150, 0.28)",
                name=f"Prior {len(band_years)}Y range",
                hovertemplate=(
                    f"Prior {len(band_years)}Y range<br>"
                    "%{customdata}<br>"
                    "min %{y:,.0f} mcm"
                    "<extra></extra>"
                ),
                customdata=[_MONTH_LABELS[m - 1] for m in months],
                hoverlabel=_HOVERLABEL,
            )
        )

    for i, year in enumerate(line_years):
        is_current = year == cur
        # Prior years: full Jan–Dec with 0 for no-cargo months (seasonal UAE).
        # Current year: zeros through the open calendar month, so a run of
        # months with no arrivals (UAE Aug–Sep) still draws at zero.
        series = _fill_zeros(
            pivot[year],
            through_month=last_m if is_current else None,
        )
        if is_current:
            color = "#c0392b"
        else:
            color = _YEAR_COLORS[min(i, len(_YEAR_COLORS) - 2)]
        solid = series
        incomplete = is_current and open_month is not None
        if incomplete:
            # Current month is drawn separately as a dashed segment.
            solid = series.copy()
            solid.loc[solid.index == open_month] = float("nan")
        fig.add_trace(
            go.Scatter(
                x=months,
                y=_y_list(solid.values),
                mode="lines+markers",
                name=str(year),
                connectgaps=False,
                line=dict(width=2.6 if is_current else 1.6, color=color),
                marker=dict(size=6 if is_current else 5),
                hovertemplate=(
                    f"<b>{year}</b><br>"
                    "%{customdata}: %{y:,.0f} mcm"
                    "<extra></extra>"
                ),
                customdata=[_MONTH_LABELS[m - 1] for m in months],
                hoverlabel=_HOVERLABEL,
            )
        )
        if incomplete and open_month >= 1:
            y_open = series.loc[open_month] if open_month in series.index else 0.0
            if open_month > 1 and (open_month - 1) in series.index:
                y_prev = series.loc[open_month - 1]
                fig.add_trace(
                    go.Scatter(
                        x=[open_month - 1, open_month],
                        y=_y_list([y_prev, y_open]),
                        mode="lines",
                        name=f"{year} incomplete",
                        showlegend=False,
                        hoverinfo="skip",
                        line=dict(width=2.6, color=color, dash="dash"),
                    )
                )
            split = _month_status_split(monthly, year, open_month)
            if split is None:
                delivered, forecast = float(y_open), 0.0
            else:
                delivered, forecast = split
            month_label = _MONTH_LABELS[open_month - 1]
            fig.add_trace(
                go.Scatter(
                    x=[open_month],
                    y=_y_list([y_open]),
                    mode="markers",
                    name=f"{year} to date",
                    showlegend=False,
                    marker=dict(size=7, color=color, symbol="circle"),
                    hovertemplate=(
                        f"<b>{year}</b> · {month_label} incomplete<br>"
                        f"%{{y:,.0f}} mcm total<br>"
                        f"Delivered: {delivered:,.0f} mcm<br>"
                        f"Forecasted: {forecast:,.0f} mcm"
                        "<extra></extra>"
                    ),
                    hoverlabel=_HOVERLABEL,
                )
            )

    n_lines = len(line_years)
    if len(band_years) >= 2:
        shade_note = f"· shade: prior {len(band_years)}Y min–max"
    else:
        shade_note = "· shade unavailable (need ≥2 prior years — refresh Kpler)"
    if open_month is not None:
        shade_note += " · dashed: current month, incomplete"

    fig.update_layout(
        height=380,
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        font=dict(
            family="Segoe UI, Arial, sans-serif",
            size=12,
            color=COLORS["text_primary"],
        ),
        margin=dict(l=55, r=30, t=48, b=50),
        title=dict(
            text=(
                f"<b>{country_label}</b>: monthly imports from Qatar (YoY)"
                f"<br><span style='font-size:11px;color:#6c757d'>"
                f"By destination arrival date · lines: {n_lines}Y "
                f"{shade_note}</span>"
            ),
            font=dict(size=14, color="#2c3e50"),
            x=0,
            xanchor="left",
        ),
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="left",
            x=0,
            font=dict(size=11),
        ),
        hovermode="x unified",
        hoverlabel=_HOVERLABEL,
        # Include year span so a short→long cache refresh doesn't keep stale UI.
        uirevision=(
            f"gulf-yoy-{country_label}-"
            f"{min(pivot.columns)}-{max(pivot.columns)}-{n_lines}"
        ),
    )
    fig.update_xaxes(
        tickmode="array",
        tickvals=months,
        ticktext=_MONTH_LABELS,
        title_text=None,
        gridcolor="rgba(0,0,0,0.06)",
        range=[0.5, 12.5],
    )
    fig.update_yaxes(
        title_text="mcm / month",
        rangemode="tozero",
        gridcolor="rgba(0,0,0,0.08)",
    )
    return fig
