"""HTML tables for pre/post Iran Ras Laffan stats."""
from __future__ import annotations

from typing import Any

from dash import html

from core.qatar_monitor.constants import (
    PERIOD_NOTES,
    POST_STRIKE_LABEL,
    PRE_WAR_LABEL,
)
from core.styles import COLORS

_TH = {
    "padding": "8px 12px",
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "backgroundColor": COLORS["table_header_bg"],
    "borderBottom": f"1px solid {COLORS['border']}",
    "textAlign": "right",
    "whiteSpace": "nowrap",
}

_TH_LEFT = {**_TH, "textAlign": "left"}

_TD = {
    "padding": "8px 12px",
    "fontSize": "13px",
    "color": COLORS["text_primary"],
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "textAlign": "right",
    "whiteSpace": "nowrap",
}

_TD_LEFT = {**_TD, "textAlign": "left", "fontWeight": "500"}

_TABLE = {
    "width": "100%",
    "borderCollapse": "collapse",
    "tableLayout": "auto",
}

_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "lineHeight": "1.45",
    "margin": "0 0 14px 0",
}

_SECTION_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 10px 0",
}


def _fmt(value: Any, kind: str) -> str:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "—"
    if v != v:  # NaN
        return "—"
    if kind == "pct":
        return f"{v:.1f}%"
    if kind == "int":
        return f"{v:.0f}"
    if kind == "1dp":
        return f"{v:.1f}"
    if kind == "0dp":
        return f"{v:.0f}"
    return f"{v:.1f}"


def _stats_table(
    title: str,
    rows: list[tuple[str, str, str, str]],
    pre: dict[str, Any],
    post: dict[str, Any],
) -> html.Div:
    """
    *rows*: list of (label, pre_key, post_key, format_kind).
    """
    header = html.Tr(
        [
            html.Th("", style=_TH_LEFT),
            html.Th(PRE_WAR_LABEL, style=_TH),
            html.Th(POST_STRIKE_LABEL, style=_TH),
        ]
    )
    body = []
    for label, key, _, kind in rows:
        body.append(
            html.Tr(
                [
                    html.Td(label, style=_TD_LEFT),
                    html.Td(_fmt(pre.get(key), kind), style=_TD),
                    html.Td(_fmt(post.get(key), kind), style=_TD),
                ]
            )
        )
    return html.Div(
        [
            html.H4(title, style=_SECTION_TITLE),
            html.Table(
                [html.Thead(header), html.Tbody(body)],
                style=_TABLE,
            ),
        ],
        style={"flex": "1 1 360px", "minWidth": "320px"},
    )


def build_iran_stats_tables(period_stats: dict[str, dict[str, Any]]) -> html.Div:
    """Render the two summary tables from ``build_period_stats``."""
    pre = period_stats.get(PRE_WAR_LABEL) or {}
    post = period_stats.get(POST_STRIKE_LABEL) or {}

    concurrency_rows = [
        ("Avg vessels at berth (time-weighted)", "avg_concurrent", "avg_concurrent", "1dp"),
        ("Max concurrent vessels", "max_concurrent", "max_concurrent", "int"),
        ("% of time terminal completely empty", "pct_empty", "pct_empty", "pct"),
        ("% of time exactly 1 at berth", "pct_one", "pct_one", "pct"),
        ("% of time 2+ at berth", "pct_two_plus", "pct_two_plus", "pct"),
        ("% of time 3+ at berth", "pct_three_plus", "pct_three_plus", "pct"),
    ]
    tempo_rows = [
        ("Loadings per week", "loadings_per_week", "loadings_per_week", "1dp"),
        ("Avg cargo size (mcm)", "avg_cargo_mcm", "avg_cargo_mcm", "0dp"),
        ("Hours at berth: median", "hours_median", "hours_median", "1dp"),
        ("Hours at berth: mean", "hours_mean", "hours_mean", "1dp"),
        ("Hours at berth: p90", "hours_p90", "hours_p90", "1dp"),
        ("Hours at berth: max", "hours_max", "hours_max", "1dp"),
    ]

    return html.Div(
        [
            html.P(PERIOD_NOTES, style=_NOTE),
            html.Div(
                style={
                    "display": "flex",
                    "flexWrap": "wrap",
                    "gap": "24px",
                    "alignItems": "flex-start",
                },
                children=[
                    _stats_table(
                        "Concurrent loadings / berth utilisation",
                        concurrency_rows,
                        pre,
                        post,
                    ),
                    _stats_table(
                        "Loading tempo and time at berth",
                        tempo_rows,
                        pre,
                        post,
                    ),
                ],
            ),
        ]
    )
