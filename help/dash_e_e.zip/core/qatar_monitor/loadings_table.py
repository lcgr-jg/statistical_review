"""Ras Laffan recent loadings summary cards + activity table."""
from __future__ import annotations

from typing import Any

import pandas as pd
from dash import html

from core.qatar_monitor.constants import (
    KPLER_VESSEL_MAP_URL,
    MISSILE_HIT_VESSELS,
    N_BERTHS,
)
from core.styles import COLORS

_TH = {
    "padding": "8px 10px",
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "backgroundColor": COLORS["table_header_bg"],
    "borderBottom": f"1px solid {COLORS['border']}",
    "textAlign": "right",
    "whiteSpace": "nowrap",
    "position": "sticky",
    "top": 0,
    "zIndex": 1,
}
_TH_LEFT = {**_TH, "textAlign": "left"}

_TD = {
    "padding": "8px 10px",
    "fontSize": "13px",
    "color": COLORS["text_primary"],
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "textAlign": "right",
    "whiteSpace": "nowrap",
}
_TD_LEFT = {**_TD, "textAlign": "left", "fontWeight": "500"}

_LOADING_ROW_BG = "rgba(44, 111, 187, 0.10)"
_MISSILE_HIT_ROW_BG = "rgba(192, 57, 43, 0.14)"
_MISSILE_HIT_ROW_BG_LOADING = "rgba(192, 57, 43, 0.22)"

# Cap table height so long history scrolls instead of stretching the page
_TABLE_SCROLL = {
    "maxHeight": "350px",
    "overflowY": "auto",
    "overflowX": "auto",
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "8px",
}

_CARD = {
    "flex": "1 1 160px",
    "minWidth": "140px",
    "backgroundColor": COLORS.get("chart_bg", "#f8f9fa"),
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "8px",
    "padding": "12px 14px",
}

_CARD_LABEL = {
    "fontSize": "11px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "textTransform": "uppercase",
    "letterSpacing": "0.4px",
    "marginBottom": "6px",
}

_CARD_VALUE = {
    "fontSize": "18px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "lineHeight": "1.2",
}

_CARD_SUB = {
    "fontSize": "12px",
    "color": COLORS["text_secondary"],
    "marginTop": "4px",
    "lineHeight": "1.35",
}


def _is_loading(row: pd.Series) -> bool:
    if pd.isna(row.get("berth_departure")):
        return True
    status = str(row.get("status") or "")
    return status == "Loading"


def _display_status(row: pd.Series) -> str:
    """Map Kpler trade status to Loading / In Transit / Delivered."""
    if _is_loading(row):
        return "Loading"
    status = str(row.get("status") or "").strip()
    if status == "Delivered":
        return "Delivered"
    return "In Transit"


def _berth_hours(row: pd.Series, *, now: pd.Timestamp) -> float | None:
    arrival = row.get("berth_arrival")
    if pd.isna(arrival):
        return None
    end = row.get("berth_departure")
    if pd.isna(end):
        end = now
    hours = (pd.Timestamp(end) - pd.Timestamp(arrival)).total_seconds() / 3600.0
    return float(hours) if hours == hours else None


def _fmt_dt(value: Any) -> str:
    if value is None or pd.isna(value):
        return "—"
    return pd.Timestamp(value).strftime("%d-%b-%y %H:%M")


def _fmt_hours(value: float | None) -> str:
    if value is None or value != value:
        return "—"
    return f"{value:.0f}"


def _dest_arrival_display(row: pd.Series) -> str:
    """
    Actual discharge arrival, else forecasted / ETA destination time.

    Suffixes: none for delivered actual; ``forecast`` for Kpler Forecasted ETA;
    ``ETA`` for Eta (destination) (or in-transit Date destination fallback).
    """
    status = str(row.get("status") or "").strip()
    dest_arr = row.get("dest_arrival")
    if status == "Delivered" and pd.notna(dest_arr):
        return _fmt_dt(dest_arr)

    forecasted = row.get("forecasted_eta")
    if pd.notna(forecasted):
        return f"{_fmt_dt(forecasted)} forecast"

    eta = row.get("eta_destination")
    if pd.notna(eta):
        return f"{_fmt_dt(eta)} ETA"

    # Some in-transit rows only populate Date/Start (destination) as the ETA
    if status != "Delivered" and pd.notna(dest_arr):
        return f"{_fmt_dt(dest_arr)} ETA"

    return "—"


def _missile_hit_info(row: pd.Series) -> dict[str, str] | None:
    """
    Return missile-hit metadata only for the voyage underway when the vessel
    was struck (not every historical call by the same name).

    Match: vessel name + Ras Laffan departure on/before the strike date and
    within 14 days before it (e.g. Gaslog Shanghai departed 28 Jul, hit 31 Jul).
    """
    name = str(row.get("vessel") or "").strip().lower()
    if not name:
        return None

    arrival = pd.to_datetime(row.get("berth_arrival"), errors="coerce")
    departure = pd.to_datetime(row.get("berth_departure"), errors="coerce")

    for key, meta in MISSILE_HIT_VESSELS.items():
        if key.lower() not in name and name not in key.lower():
            continue
        hit = pd.Timestamp(meta["date"]).normalize()
        # Must have arrived at Ras Laffan on/before the strike
        if pd.isna(arrival) or arrival.normalize() > hit:
            return None
        if pd.isna(departure):
            # Still at berth: only if this call overlaps the strike day
            if arrival.normalize() >= hit - pd.Timedelta(days=14):
                return meta
            return None
        dep_day = departure.normalize()
        # Departed after the strike → not the hit sailing
        if dep_day > hit:
            return None
        # Departed too long before the strike → an earlier voyage
        if dep_day < hit - pd.Timedelta(days=14):
            return None
        return meta
    return None


def _hormuz_label(canal_transit: Any) -> str:
    """Yes / No / — from Kpler ``Zone Canal Transit``."""
    if canal_transit is None or (isinstance(canal_transit, float) and pd.isna(canal_transit)):
        return "—"
    text = str(canal_transit).strip()
    if not text or text.lower() in {"nan", "none", "<na>"}:
        return "—"
    if "strait of hormuz" in text.lower():
        return "Yes"
    return "No"


def _cell_text(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return "—"
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "<na>"}:
        return "—"
    return text


def _vessel_type_display(value: Any) -> tuple[str, str | None]:
    """
    Short vessel-type label for the table.

    Keeps ``Q-Flex`` / ``Q-Max`` unchanged.  Other Kpler values like
    ``XL (Upper Conventional)`` collapse to the leading acronym (``XL``),
    with the full string as hover text.
    """
    text = _cell_text(value)
    if text == "—":
        return text, None
    if text in {"Q-Flex", "Q-Max"}:
        return text, None
    if " (" in text and text.endswith(")"):
        short = text.split(" (", 1)[0].strip()
        if short:
            return short, text
    return text, text


def _vessel_type_cell(row: pd.Series, td_style: dict[str, Any]) -> html.Td:
    label, title = _vessel_type_display(row.get("vessel_type"))
    if title:
        return html.Td(
            html.Span(label, title=title, style={"cursor": "help"}),
            style=td_style,
            title=title,
        )
    return html.Td(label, style=td_style)


def _controller_cell(row: pd.Series, td_style: dict[str, Any]) -> html.Td:
    """Current controller with owners as hover title when available."""
    controller = _cell_text(row.get("current_controller"))
    owners = _cell_text(row.get("owners"))
    if controller == "—":
        return html.Td(controller, style=td_style)
    title = f"Owners: {owners}" if owners != "—" else None
    props: dict[str, Any] = {}
    if title:
        props["title"] = title
    return html.Td(
        html.Span(
            controller,
            style={"cursor": "help"} if title else {},
            **({"title": title} if title else {}),
        ),
        style=td_style,
        **props,
    )


def _kpler_href(vessel_id: Any) -> str | None:
    try:
        if vessel_id is None or pd.isna(vessel_id):
            return None
        vid = int(float(vessel_id))
    except (TypeError, ValueError):
        return None
    return KPLER_VESSEL_MAP_URL.format(vid)


def filter_recent_loadings(
    loadings: pd.DataFrame,
    *,
    n_days: int,
    now: pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Loadings that arrived, departed, or are still at berth within *n_days*."""
    if loadings is None or loadings.empty:
        return pd.DataFrame()
    now = pd.Timestamp(now or pd.Timestamp.now())
    cutoff = now - pd.Timedelta(days=int(n_days))
    df = loadings.copy()
    df["berth_arrival"] = pd.to_datetime(df["berth_arrival"], errors="coerce")
    df["berth_departure"] = pd.to_datetime(df["berth_departure"], errors="coerce")
    still = df["berth_departure"].isna()
    arrived = df["berth_arrival"] >= cutoff
    departed = df["berth_departure"].notna() & (df["berth_departure"] >= cutoff)
    out = df[still | arrived | departed].copy()
    return out.sort_values("berth_arrival", ascending=False).reset_index(drop=True)


def loadings_to_records(loadings: pd.DataFrame) -> list[dict[str, Any]]:
    """JSON-serialisable rows for ``dcc.Store``."""
    if loadings is None or loadings.empty:
        return []
    cols = [
        "vessel",
        "vessel_id",
        "imo",
        "status",
        "berth_arrival",
        "berth_departure",
        "volume_mcm",
        "destination",
        "canal_transit",
        "dest_arrival",
        "forecasted_eta",
        "eta_destination",
        "vessel_type",
        "current_controller",
        "owners",
    ]
    have = [c for c in cols if c in loadings.columns]
    df = loadings[have].copy()
    for c in ("berth_arrival", "berth_departure", "dest_arrival", "forecasted_eta", "eta_destination"):
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors="coerce").dt.strftime("%Y-%m-%dT%H:%M:%S")
            df[c] = df[c].where(df[c].notna(), None)
    if "vessel_id" in df.columns:
        df["vessel_id"] = df["vessel_id"].apply(
            lambda x: int(x) if pd.notna(x) else None
        )
    if "volume_mcm" in df.columns:
        df["volume_mcm"] = pd.to_numeric(df["volume_mcm"], errors="coerce")
    return df.to_dict(orient="records")


def records_to_loadings(records: list[dict[str, Any]] | None) -> pd.DataFrame:
    if not records:
        return pd.DataFrame()
    df = pd.DataFrame(records)
    for c in (
        "berth_arrival",
        "berth_departure",
        "dest_arrival",
        "forecasted_eta",
        "eta_destination",
    ):
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors="coerce")
    return df


def build_loadings_summary(
    loadings: pd.DataFrame,
    *,
    n_days: int,
    now: pd.Timestamp | None = None,
) -> html.Div:
    """KPI cards for current berth state + window totals."""
    now = pd.Timestamp(now or pd.Timestamp.now())
    recent = filter_recent_loadings(loadings, n_days=n_days, now=now)

    loading_mask = (
        loadings["berth_departure"].isna()
        if loadings is not None and not loadings.empty
        else pd.Series(dtype=bool)
    )
    at_berth = loadings[loading_mask] if loadings is not None and not loadings.empty else pd.DataFrame()
    n_loading = int(len(at_berth))
    loading_names = (
        ", ".join(str(v) for v in at_berth["vessel"].tolist())
        if n_loading
        else "None"
    )

    last_dep = None
    if loadings is not None and not loadings.empty:
        departed = loadings[loadings["berth_departure"].notna()].sort_values(
            "berth_departure"
        )
        if not departed.empty:
            last_dep = departed.iloc[-1]

    completed = recent[recent["berth_departure"].notna()] if not recent.empty else recent
    total_mcm = float(recent["volume_mcm"].sum()) if not recent.empty else 0.0
    avg_hours = None
    if completed is not None and not completed.empty:
        hrs = [
            _berth_hours(r, now=now)
            for _, r in completed.iterrows()
        ]
        hrs = [h for h in hrs if h is not None]
        if hrs:
            avg_hours = sum(hrs) / len(hrs)

    cards = [
        html.Div(
            [
                html.Div("Currently loading", style=_CARD_LABEL),
                html.Div(f"{n_loading} / {N_BERTHS} berths", style=_CARD_VALUE),
                html.Div(loading_names, style=_CARD_SUB),
            ],
            style=_CARD,
        ),
        html.Div(
            [
                html.Div("Last departure", style=_CARD_LABEL),
                html.Div(
                    str(last_dep["vessel"]) if last_dep is not None else "—",
                    style=_CARD_VALUE,
                ),
                html.Div(
                    _fmt_dt(last_dep["berth_departure"]) if last_dep is not None else "",
                    style=_CARD_SUB,
                ),
            ],
            style=_CARD,
        ),
        html.Div(
            [
                html.Div(f"Loadings (last {n_days}d)", style=_CARD_LABEL),
                html.Div(str(len(recent)), style=_CARD_VALUE),
                html.Div(
                    f"{total_mcm:,.0f} mcm total",
                    style=_CARD_SUB,
                ),
            ],
            style=_CARD,
        ),
        html.Div(
            [
                html.Div(f"Avg berth time ({n_days}d)", style=_CARD_LABEL),
                html.Div(
                    f"{avg_hours:.0f} hrs" if avg_hours is not None else "—",
                    style=_CARD_VALUE,
                ),
                html.Div("completed loadings only", style=_CARD_SUB),
            ],
            style=_CARD,
        ),
    ]
    return html.Div(
        cards,
        style={
            "display": "flex",
            "flexWrap": "wrap",
            "gap": "12px",
            "marginBottom": "16px",
        },
    )


def build_loadings_table(
    loadings: pd.DataFrame,
    *,
    n_days: int,
    now: pd.Timestamp | None = None,
) -> html.Div:
    """Recent vessel activity table with Kpler vessel links."""
    now = pd.Timestamp(now or pd.Timestamp.now())
    recent = filter_recent_loadings(loadings, n_days=n_days, now=now)
    if recent.empty:
        return html.Div(
            f"No Ras Laffan loadings in the last {n_days} days.",
            style={"fontSize": "13px", "color": COLORS["text_muted"]},
        )

    header = html.Tr(
        [
            html.Th("Vessel", style=_TH_LEFT),
            html.Th("Type", style=_TH_LEFT),
            html.Th("Controller", style=_TH_LEFT),
            html.Th("Volume (mcm)", style=_TH),
            html.Th("Status", style=_TH_LEFT),
            html.Th("Arrival", style=_TH),
            html.Th("Departure", style=_TH),
            html.Th("Time at berth (hrs)", style=_TH),
            html.Th("Hormuz Transit", style=_TH_LEFT),
            html.Th("Destination", style=_TH_LEFT),
            html.Th("Dest. arrival", style=_TH),
        ]
    )
    body = []
    for _, row in recent.iterrows():
        loading = _is_loading(row)
        hit = _missile_hit_info(row)
        if hit is not None:
            bg = _MISSILE_HIT_ROW_BG_LOADING if loading else _MISSILE_HIT_ROW_BG
            row_title = hit["note"]
        elif loading:
            bg = _LOADING_ROW_BG
            row_title = None
        else:
            bg = None
            row_title = None
        td = {**_TD, **({"backgroundColor": bg} if bg else {})}
        td_left = {**_TD_LEFT, **({"backgroundColor": bg} if bg else {})}
        href = _kpler_href(row.get("vessel_id"))
        name = str(row.get("vessel") or "—")
        vessel_children: Any
        if href:
            link = html.A(
                name,
                href=href,
                target="_blank",
                rel="noopener noreferrer",
                style={
                    "color": COLORS.get("accent", "#2c6fbb"),
                    "textDecoration": "none",
                    "fontWeight": "600",
                },
            )
        else:
            link = name
        if hit is not None:
            vessel_children = html.Span(
                [
                    link,
                    html.Span(
                        " ⚑",
                        title=hit["note"],
                        style={
                            "color": "#c0392b",
                            "fontWeight": "700",
                            "cursor": "help",
                            "marginLeft": "2px",
                        },
                    ),
                ],
                title=hit["note"],
            )
        else:
            vessel_children = link
        vol = row.get("volume_mcm")
        vol_txt = f"{float(vol):,.0f}" if pd.notna(vol) else "—"
        dest = row.get("destination")
        dest_txt = str(dest) if pd.notna(dest) and str(dest).strip() else "—"
        dest_arr_txt = _dest_arrival_display(row)
        tr_props: dict[str, Any] = {}
        if row_title:
            tr_props["title"] = row_title
        body.append(
            html.Tr(
                [
                    html.Td(vessel_children, style=td_left),
                    _vessel_type_cell(row, td_left),
                    _controller_cell(row, td_left),
                    html.Td(vol_txt, style=td),
                    html.Td(_display_status(row), style=td_left),
                    html.Td(_fmt_dt(row.get("berth_arrival")), style=td),
                    html.Td(_fmt_dt(row.get("berth_departure")), style=td),
                    html.Td(_fmt_hours(_berth_hours(row, now=now)), style=td),
                    html.Td(_hormuz_label(row.get("canal_transit")), style=td_left),
                    html.Td(dest_txt, style=td_left),
                    html.Td(dest_arr_txt, style=td),
                ],
                **tr_props,
            )
        )

    return html.Div(
        html.Table(
            [html.Thead(header), html.Tbody(body)],
            style={
                "width": "100%",
                "borderCollapse": "collapse",
                "tableLayout": "auto",
            },
        ),
        style=_TABLE_SCROLL,
    )
