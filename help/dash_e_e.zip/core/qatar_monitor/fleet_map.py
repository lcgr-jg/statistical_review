"""Map of QatarEnergy fleet positions with zone polygons."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go

from core.qatar_monitor.constants import FLEET_ZONE_COLORS
from core.qatar_monitor.fleet_zones import _signed_area, load_fleet_zones
from core.styles import COLORS


def _rgba(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def build_fleet_location_map(fleet_positions: pd.DataFrame | None) -> go.Figure:
    """
    OpenStreetMap-style tiles were showing local-language labels (Arabic
    in the Gulf, etc.). Esri World Street Map is English and needs no token.

    Polygon fill is planar on the map, so only the defined rings are shaded.
    Mapbox markers only support filled circles — open-circle symbols are
    dropped, so laden/unladen are distinguished by colour instead.
    """
    fig = go.Figure()
    zones = sorted(
        load_fleet_zones(),
        key=lambda z: abs(_signed_area(z["ring"])),
        reverse=True,
    )

    for zone in zones:
        ring = zone["ring"]
        lons = [p[0] for p in ring]
        lats = [p[1] for p in ring]
        color = FLEET_ZONE_COLORS.get(zone["id"], "#7f7f7f")
        fig.add_trace(
            go.Scattermapbox(
                lon=lons,
                lat=lats,
                mode="lines",
                fill="toself",
                fillcolor=_rgba(color, 0.28),
                line={"width": 2, "color": color},
                name=zone["name"],
                hoverinfo="name",
                showlegend=True,
            )
        )

    if fleet_positions is not None and not fleet_positions.empty:
        placed = fleet_positions.dropna(subset=["latitude", "longitude"]).copy()
        if not placed.empty:
            qe_flag = (
                placed["is_qe_controlled"].fillna(True).astype(bool)
                if "is_qe_controlled" in placed.columns
                else pd.Series(True, index=placed.index)
            )
            qe = placed[qe_flag]
            other_rl = placed[~qe_flag]
            laden = qe["is_laden"].fillna(False).astype(bool)
            rl = (
                qe["is_ras_laffan_cargo"].fillna(False).astype(bool)
                if "is_ras_laffan_cargo" in qe.columns
                else pd.Series(False, index=qe.index)
            )
            groups = (
                (laden & rl, "Laden (Ras Laffan)", "#c0392b"),
                (laden & ~rl, "Laden (other origin)", "#f39c12"),
                (~laden, "Unladen", "#2c6fbb"),
            )
            for mask, label, color in groups:
                sub = qe[mask]
                if sub.empty:
                    continue
                hover = [
                    (
                        f"<b>{row.get('vessel_name') or '—'}</b><br>"
                        f"IMO {int(row['imo']) if pd.notna(row.get('imo')) else '—'}<br>"
                        f"{row.get('zone_name') or '—'}<br>"
                        f"{label}: "
                        f"{float(row.get('cargo_mcm') or 0):,.0f} mcm<br>"
                        f"Capacity: {float(row.get('capacity_mcm') or 0):,.0f} mcm"
                    )
                    for _, row in sub.iterrows()
                ]
                fig.add_trace(
                    go.Scattermapbox(
                        lon=sub["longitude"],
                        lat=sub["latitude"],
                        mode="markers",
                        name=label,
                        marker={
                            "size": 9,
                            "color": color,
                        },
                        text=hover,
                        hovertemplate="%{text}<extra></extra>",
                        showlegend=True,
                    )
                )
            if not other_rl.empty:
                hover = [
                    (
                        f"<b>{row.get('vessel_name') or '—'}</b><br>"
                        f"IMO {int(row['imo']) if pd.notna(row.get('imo')) else '—'}<br>"
                        f"{row.get('zone_name') or '—'}<br>"
                        f"Other RL (not QE-controlled)<br>"
                        f"Controller: {row.get('current_controller') or '—'}<br>"
                        f"Cargo: {float(row.get('cargo_mcm') or 0):,.0f} mcm<br>"
                        f"Capacity: {float(row.get('capacity_mcm') or 0):,.0f} mcm"
                    )
                    for _, row in other_rl.iterrows()
                ]
                fig.add_trace(
                    go.Scattermapbox(
                        lon=other_rl["longitude"],
                        lat=other_rl["latitude"],
                        mode="markers",
                        name="Other RL (not QE-controlled)",
                        marker={
                            "size": 11,
                            "color": "#6c3483",
                        },
                        text=hover,
                        hovertemplate="%{text}<extra></extra>",
                        showlegend=True,
                    )
                )

    fig.update_layout(
        mapbox={
            "style": "white-bg",
            "layers": [
                {
                    "below": "traces",
                    "sourcetype": "raster",
                    "sourceattribution": "Esri",
                    "source": [
                        "https://server.arcgisonline.com/ArcGIS/rest/services/"
                        "World_Street_Map/MapServer/tile/{z}/{y}/{x}"
                    ],
                }
            ],
            "center": {"lat": 12.0, "lon": 68.0},
            "zoom": 3.1,
        },
        margin={"l": 0, "r": 0, "t": 8, "b": 0},
        height=560,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        legend={
            "orientation": "h",
            "yanchor": "bottom",
            "y": 1.02,
            "xanchor": "left",
            "x": 0,
            "font": {"size": 11, "color": COLORS["text_secondary"]},
            "bgcolor": "rgba(255,255,255,0.85)",
        },
        font={"color": COLORS["text_primary"]},
    )
    return fig
