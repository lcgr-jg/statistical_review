"""Join Kpler QatarEnergy fleet to Bloomberg positions and summarise by zone."""
from __future__ import annotations

from typing import Any

import pandas as pd

from core.qatar_monitor.constants import (
    FLEET_ZONE_DAYS_TO_RAS_LAFFAN,
    FLEET_ZONE_LABELS,
    FLEET_ZONE_NO_POSITION,
    FLEET_ZONE_ORDER,
    FLEET_ZONE_OUTSIDE,
    FLEET_ZONE_PERSIAN_GULF,
    MISSILE_HIT_VESSELS,
)
from core.qatar_monitor.fleet import (
    _capacity_mcm,
    _cargo_mcm,
    _count_type,
    qatar_fleet_slices,
)
from core.qatar_monitor.fleet_zones import assign_zones_to_frame


def _missile_note_for_name(name: str) -> str | None:
    n = str(name or "").strip().lower()
    if not n:
        return None
    for key, meta in MISSILE_HIT_VESSELS.items():
        k = key.lower()
        if k in n or n in k:
            return str(meta.get("note") or "")
    return None


def open_ras_laffan_imos(loadings: pd.DataFrame | None) -> set[int]:
    """IMOs with a Ras Laffan cargo still loading or in transit."""
    if loadings is None or loadings.empty or "imo" not in loadings.columns:
        return set()
    status = loadings["status"].astype(str) if "status" in loadings.columns else ""
    still_at_berth = (
        loadings["berth_departure"].isna()
        if "berth_departure" in loadings.columns
        else False
    )
    open_mask = loadings["imo"].notna() & (still_at_berth | (status != "Delivered"))
    return set(
        pd.to_numeric(loadings.loc[open_mask, "imo"], errors="coerce")
        .dropna()
        .astype(int)
    )


def _no_position_hover(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return ""
    names = df["vessel_name"] if "vessel_name" in df.columns else pd.Series(dtype=str)
    lines: list[str] = []
    for name in names.fillna("").astype(str):
        name = name.strip()
        if not name:
            continue
        note = _missile_note_for_name(name)
        lines.append(f"{name} — {note}" if note else name)
    return "\n".join(lines)


# Kpler last port-call → cargo origin country. Transit waypoints are left
# unmapped so the hover shows the waypoint name instead of a fake country.
_LAST_PORT_COUNTRY: list[tuple[str, str]] = sorted(
    [
        ("ras laffan", "Qatar"),
        ("plaquemines", "United States"),
        ("sabine pass", "United States"),
        ("corpus christi", "United States"),
        ("cove point", "United States"),
        ("golden pass", "United States"),
        ("cameron lng", "United States"),
        ("freeport lng", "United States"),
        ("calcasieu", "United States"),
        ("elba island", "United States"),
        ("hackberry", "United States"),
        ("costa azul", "Mexico"),
        ("altamira", "Mexico"),
        ("atlantic lng", "Trinidad and Tobago"),
        ("point fortin", "Trinidad and Tobago"),
        ("bonny lng", "Nigeria"),
        ("brass lng", "Nigeria"),
        ("nlng", "Nigeria"),
        ("png lng", "Papua New Guinea"),
        ("kamchatka", "Russia"),
        ("yamal", "Russia"),
        ("sakhalin", "Russia"),
        ("portovaya", "Russia"),
        ("sabetta", "Russia"),
        ("arun", "Indonesia"),
        ("bontang", "Indonesia"),
        ("tangguh", "Indonesia"),
        ("donggi", "Indonesia"),
        ("gorgon", "Australia"),
        ("wheatstone", "Australia"),
        ("gladstone", "Australia"),
        ("ichthys", "Australia"),
        ("prelude", "Australia"),
        ("darwin lng", "Australia"),
        ("nws venture", "Australia"),
        ("withnell", "Australia"),
        ("qalhat", "Oman"),
        ("oman lng", "Oman"),
        ("das island", "United Arab Emirates"),
        ("adnoc lng", "United Arab Emirates"),
        ("das lng", "United Arab Emirates"),
        ("mlng", "Malaysia"),
        ("pflng", "Malaysia"),
        ("bintulu", "Malaysia"),
        ("snøhvit", "Norway"),
        ("hammerfest", "Norway"),
        ("skikda", "Algeria"),
        ("arzew", "Algeria"),
        ("bethioua", "Algeria"),
        ("idku", "Egypt"),
        ("damietta", "Egypt"),
        ("coral sul", "Mozambique"),
        ("mozambique lng", "Mozambique"),
        ("angola lng", "Angola"),
        ("soyo", "Angola"),
        ("eg lng", "Equatorial Guinea"),
        ("punta europa", "Equatorial Guinea"),
        ("hilli", "Cameroon"),
        ("cameroon", "Cameroon"),
        ("peru lng", "Peru"),
        ("pampa melchorita", "Peru"),
        ("brunei lng", "Brunei"),
        ("lumut", "Brunei"),
        ("sergipe", "Brazil"),
        ("bahia", "Brazil"),
    ],
    key=lambda item: len(item[0]),
    reverse=True,
)


def _origin_label(last_port_call: Any) -> str:
    """Country for a known load terminal, else the last port-call name."""
    port = str(last_port_call or "").strip()
    if not port or port.lower() in ("nan", "none", "—", "-"):
        return ""
    key = port.lower()
    for needle, country in _LAST_PORT_COUNTRY:
        if needle in key:
            return country
    return port


def _vessel_name_list(
    df: pd.DataFrame,
    mask: pd.Series,
    *,
    annotate_origin: bool = False,
    annotate_controller: bool = False,
) -> str:
    """Newline-separated vessel names for a table-cell hover."""
    if df is None or df.empty or mask is None or not len(mask) or not bool(mask.any()):
        return ""
    sub = df.loc[mask]
    if sub.empty or "vessel_name" not in sub.columns:
        return ""
    lines: list[str] = []
    for _, row in sub.iterrows():
        name = str(row.get("vessel_name") or "").strip() or "—"
        bits: list[str] = []
        if annotate_origin and bool(row.get("is_laden")) and not bool(
            row.get("is_ras_laffan_cargo")
        ):
            origin = str(row.get("origin_country") or "").strip()
            bits.append(origin or "unknown origin")
        if annotate_controller:
            ctrl = str(row.get("current_controller") or "").strip()
            if ctrl:
                bits.append(ctrl)
        note = _missile_note_for_name(name)
        if note:
            bits.append(note)
        lines.append(f"{name} ({'; '.join(bits)})" if bits else name)
    return "\n".join(sorted(lines, key=str.lower))


def _attach_bbg_positions(
    fleet: pd.DataFrame,
    bbg_ships: pd.DataFrame | None,
) -> pd.DataFrame:
    pos_cols = ["imo", "latitude", "longitude", "heading", "last_seen"]
    if bbg_ships is None or bbg_ships.empty or "imo" not in bbg_ships.columns:
        for c in ("latitude", "longitude", "heading", "last_seen"):
            fleet[c] = pd.NA
        return fleet
    ships = bbg_ships.copy()
    ships["imo"] = pd.to_numeric(ships["imo"], errors="coerce")
    keep = [c for c in pos_cols if c in ships.columns]
    ships = (
        ships[keep]
        .dropna(subset=["imo"])
        .drop_duplicates(subset=["imo"], keep="first")
    )
    return fleet.merge(ships, on="imo", how="left", suffixes=("", "_bbg"))


def _prepare_position_frame(
    vessels: pd.DataFrame,
    bbg_ships: pd.DataFrame | None,
    loadings: pd.DataFrame | None,
    *,
    is_qe_controlled: bool,
) -> pd.DataFrame:
    fleet = vessels.copy().reset_index(drop=True)
    fleet["imo"] = pd.to_numeric(fleet.get("IMO"), errors="coerce")
    fleet["capacity_mcm"] = _capacity_mcm(fleet)
    fleet["cargo_mcm"] = _cargo_mcm(fleet)
    fleet["is_laden"] = fleet["cargo_mcm"] > 0
    fleet["vessel_name"] = (
        fleet["Name"].astype(str) if "Name" in fleet.columns else ""
    )
    last_port = (
        fleet["Last port-call"] if "Last port-call" in fleet.columns else ""
    )
    fleet["last_port_call"] = (
        last_port.fillna("").astype(str).str.strip()
        if isinstance(last_port, pd.Series)
        else ""
    )
    fleet["origin_country"] = (
        fleet["last_port_call"].map(_origin_label)
        if "last_port_call" in fleet.columns
        else ""
    )
    fleet["vessel_type"] = (
        fleet["Vessel type"].astype(str) if "Vessel type" in fleet.columns else ""
    )
    fleet["current_controller"] = (
        fleet["Current controller"].astype(str)
        if "Current controller" in fleet.columns
        else ""
    )
    fleet = _attach_bbg_positions(fleet, bbg_ships)
    rl_imos = open_ras_laffan_imos(loadings)
    imo_key = pd.to_numeric(fleet["imo"], errors="coerce")
    fleet["is_ras_laffan_cargo"] = fleet["is_laden"] & imo_key.isin(
        pd.Index(list(rl_imos), dtype="float64")
    )
    fleet["is_qe_controlled"] = is_qe_controlled
    return assign_zones_to_frame(fleet)


def _other_open_rl_vessels(
    vessels: pd.DataFrame | None,
    loadings: pd.DataFrame | None,
    controlled_imos: set[int],
) -> pd.DataFrame:
    """Vessels with an open Ras Laffan cargo that are not QE-controlled."""
    if vessels is None or vessels.empty:
        return pd.DataFrame()
    open_imos = open_ras_laffan_imos(loadings)
    if not open_imos:
        return pd.DataFrame()
    imo = pd.to_numeric(vessels.get("IMO"), errors="coerce")
    mask = imo.isin(open_imos) & ~imo.isin(controlled_imos)
    return vessels.loc[mask].copy()


def join_fleet_positions(
    vessels: pd.DataFrame | None,
    bbg_ships: pd.DataFrame | None,
    loadings: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """
    QatarEnergy-controlled active fleet with Bloomberg lat/lon joined on IMO,
    plus non-QE vessels that still have an open Ras Laffan cargo.

    Adds: latitude, longitude, heading, last_seen, zone_id, zone_name,
    capacity_mcm, cargo_mcm, is_laden, is_ras_laffan_cargo, is_qe_controlled.
    """
    slices = qatar_fleet_slices(vessels)
    controlled = slices["controlled"].copy()
    qe_imos: set[int] = set()
    if not controlled.empty and "IMO" in controlled.columns:
        qe_imos = set(
            pd.to_numeric(controlled["IMO"], errors="coerce").dropna().astype(int)
        )

    frames: list[pd.DataFrame] = []
    if not controlled.empty:
        frames.append(
            _prepare_position_frame(
                controlled, bbg_ships, loadings, is_qe_controlled=True
            )
        )

    others_src = _other_open_rl_vessels(vessels, loadings, qe_imos)
    if not others_src.empty:
        others = _prepare_position_frame(
            others_src, bbg_ships, loadings, is_qe_controlled=False
        )
        others["is_ras_laffan_cargo"] = True
        frames.append(others)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def _zone_row(
    df: pd.DataFrame,
    *,
    zone_id: str,
    zone_name: str,
    other_rl: pd.DataFrame | None = None,
) -> dict[str, Any]:
    cargo = df["cargo_mcm"] if "cargo_mcm" in df.columns else pd.Series(dtype=float)
    capacity = (
        df["capacity_mcm"] if "capacity_mcm" in df.columns else pd.Series(dtype=float)
    )
    laden = df["is_laden"] if "is_laden" in df.columns else pd.Series(dtype=bool)
    if laden.dtype != bool and len(laden):
        laden = laden.fillna(False).astype(bool)
    unladen = ~laden if len(laden) else pd.Series(dtype=bool)
    rl = (
        df["is_ras_laffan_cargo"].fillna(False).astype(bool)
        if "is_ras_laffan_cargo" in df.columns and len(df)
        else pd.Series(False, index=df.index)
    )
    non_rl = laden & ~rl if len(laden) else pd.Series(dtype=bool)
    hover = (
        _no_position_hover(df) if zone_id == FLEET_ZONE_NO_POSITION else ""
    )
    is_gulf = zone_id == FLEET_ZONE_PERSIAN_GULF
    extras = pd.DataFrame()
    if is_gulf and other_rl is not None and not other_rl.empty:
        extras = other_rl[other_rl["zone_id"] == zone_id]
    extra_mask = (
        pd.Series(True, index=extras.index) if not extras.empty else pd.Series(dtype=bool)
    )
    return {
        "zone_id": zone_id,
        "zone": zone_name,
        "zone_hover": hover,
        "days_to_ras_laffan": FLEET_ZONE_DAYS_TO_RAS_LAFFAN.get(zone_id, "—"),
        "vessels": int(len(df)),
        "q_max": _count_type(df, "Q-Max") if not df.empty else 0,
        "q_flex": _count_type(df, "Q-Flex") if not df.empty else 0,
        "laden": int(laden.sum()) if len(laden) else 0,
        "laden_mcm": float(cargo[laden].sum()) if len(cargo) else 0.0,
        "laden_hover": _vessel_name_list(df, laden, annotate_origin=True),
        "non_rl_laden": int(non_rl.sum()) if len(non_rl) else 0,
        "non_rl_laden_mcm": float(cargo[non_rl].sum()) if len(cargo) and len(non_rl) else 0.0,
        "non_rl_hover": _vessel_name_list(df, non_rl, annotate_origin=True),
        "other_rl": int(len(extras)) if is_gulf else None,
        "other_rl_hover": _vessel_name_list(
            extras, extra_mask, annotate_controller=True
        )
        if is_gulf
        else "",
        "unladen": int(unladen.sum()) if len(unladen) else 0,
        "unladen_capacity_mcm": float(capacity[unladen].sum()) if len(capacity) else 0.0,
        "unladen_hover": _vessel_name_list(df, unladen),
    }


def summarize_fleet_by_zone(fleet_positions: pd.DataFrame | None) -> pd.DataFrame:
    """One summary row per defined zone + outside + no_position."""
    labels = dict(FLEET_ZONE_LABELS)
    order = list(FLEET_ZONE_ORDER) + [FLEET_ZONE_OUTSIDE, FLEET_ZONE_NO_POSITION]

    if fleet_positions is None or fleet_positions.empty:
        return pd.DataFrame(
            [
                _zone_row(pd.DataFrame(), zone_id=zid, zone_name=labels.get(zid, zid))
                for zid in order
            ]
        )

    qe = fleet_positions
    others = pd.DataFrame()
    if "is_qe_controlled" in fleet_positions.columns:
        flag = fleet_positions["is_qe_controlled"].fillna(True).astype(bool)
        qe = fleet_positions[flag]
        others = fleet_positions[~flag]

    rows = []
    for zid in order:
        sub = qe[qe["zone_id"] == zid] if not qe.empty else pd.DataFrame()
        rows.append(
            _zone_row(
                sub,
                zone_id=zid,
                zone_name=labels.get(zid, zid),
                other_rl=others,
            )
        )
    return pd.DataFrame(rows)
