"""Qatar Fleet summary table (controlled / owned counts and laden status)."""
from __future__ import annotations

import pandas as pd
from dash import html

from core.qatar_monitor.table_chrome import (
    SHADE_FLEET,
    SHADE_LADEN,
    SHADE_UNLADEN,
    TABLE_STYLE,
    TABLE_WRAP,
    TD_LEFT,
    TH_LEFT,
    group_th,
    td,
    th,
)
from core.styles import COLORS


def build_fleet_table(summary: pd.DataFrame | None) -> html.Div:
    """Render the Qatar Fleet summary table from ``summarize_qatar_fleet`` output."""
    if summary is None or summary.empty:
        return html.Div(
            "No Qatar fleet vessels found in the Kpler vessels snapshot.",
            style={"fontSize": "13px", "color": COLORS["text_muted"]},
        )

    header = html.Thead(
        [
            html.Tr(
                [
                    html.Th("Fleet slice", rowSpan=2, style=TH_LEFT),
                    group_th("Fleet", colspan=4, shade=SHADE_FLEET),
                    group_th("Laden", colspan=2, shade=SHADE_LADEN),
                    group_th("Unladen", colspan=2, shade=SHADE_UNLADEN),
                ]
            ),
            html.Tr(
                [
                    th("Vessels", shade=SHADE_FLEET),
                    th("Q-Max", shade=SHADE_FLEET),
                    th("Q-Flex", shade=SHADE_FLEET),
                    th("Total capacity (mcm)", shade=SHADE_FLEET),
                    th("Count", shade=SHADE_LADEN),
                    th("Vol (mcm)", shade=SHADE_LADEN),
                    th("Count", shade=SHADE_UNLADEN),
                    th("Capacity (mcm)", shade=SHADE_UNLADEN),
                ]
            ),
        ]
    )
    body = []
    for _, row in summary.iterrows():
        body.append(
            html.Tr(
                [
                    html.Td(str(row.get("segment") or "—"), style=TD_LEFT),
                    td(row.get("vessels"), shade=SHADE_FLEET),
                    td(row.get("q_max"), shade=SHADE_FLEET),
                    td(row.get("q_flex"), shade=SHADE_FLEET),
                    td(row.get("capacity_mcm"), shade=SHADE_FLEET),
                    td(row.get("laden"), shade=SHADE_LADEN),
                    td(row.get("laden_mcm"), shade=SHADE_LADEN),
                    td(row.get("unladen"), shade=SHADE_UNLADEN),
                    td(row.get("unladen_capacity_mcm"), shade=SHADE_UNLADEN),
                ]
            )
        )

    return html.Div(
        html.Table(
            [header, html.Tbody(body)],
            style=TABLE_STYLE,
        ),
        style=TABLE_WRAP,
    )
