"""GeoJSON zone loading and point-in-polygon assignment for Qatar fleet."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

import pandas as pd
from matplotlib.path import Path as MplPath

from core.qatar_monitor.constants import (
    FLEET_ZONE_ORDER,
    FLEET_ZONE_OUTSIDE,
    FLEET_ZONE_NO_POSITION,
)

_ZONES_PATH = Path(__file__).resolve().parent / "zones" / "qatar_fleet_zones.geojson"


def _signed_area(ring: list[tuple[float, float]]) -> float:
    """Shoelace area; positive ⇒ counterclockwise in lon/lat."""
    area = 0.0
    for (x1, y1), (x2, y2) in zip(ring, ring[1:]):
        area += x1 * y2 - x2 * y1
    return area / 2.0


@lru_cache(maxsize=1)
def load_fleet_zones() -> list[dict[str, Any]]:
    """
    Load zone polygons from GeoJSON.

    Returns a list ordered by assignment priority (first match wins), each with
    ``id``, ``name``, ``ring`` (list of (lon, lat)), and ``path`` (matplotlib Path).
    """
    raw = json.loads(_ZONES_PATH.read_text(encoding="utf-8"))
    by_id: dict[str, dict[str, Any]] = {}
    for feat in raw.get("features") or []:
        props = feat.get("properties") or {}
        zone_id = str(props.get("id") or "").strip()
        if not zone_id:
            continue
        geom = feat.get("geometry") or {}
        if geom.get("type") != "Polygon":
            continue
        coords = (geom.get("coordinates") or [[]])[0]
        ring = [(float(lon), float(lat)) for lon, lat in coords]
        if len(ring) < 3:
            continue
        if ring[0] != ring[-1]:
            ring.append(ring[0])
        # GeoJSON exteriors should be counterclockwise so fills stay inside
        # the ring (clockwise rings make Plotly/Scattergeo shade the globe).
        if _signed_area(ring) < 0:
            ring = list(reversed(ring))
        by_id[zone_id] = {
            "id": zone_id,
            "name": str(props.get("name") or zone_id),
            "ring": ring,
            "path": MplPath(ring, closed=True),
        }

    ordered: list[dict[str, Any]] = []
    for zone_id in FLEET_ZONE_ORDER:
        if zone_id in by_id:
            ordered.append(by_id[zone_id])
    # Any unexpected features after known priority ids
    for zone_id, zone in by_id.items():
        if zone_id not in FLEET_ZONE_ORDER:
            ordered.append(zone)
    return ordered


def assign_zone(
    longitude: float | None,
    latitude: float | None,
    *,
    zones: list[dict[str, Any]] | None = None,
) -> tuple[str, str]:
    """Return ``(zone_id, zone_name)`` for a lon/lat point."""
    if longitude is None or latitude is None:
        return FLEET_ZONE_NO_POSITION, "No position"
    try:
        lon = float(longitude)
        lat = float(latitude)
    except (TypeError, ValueError):
        return FLEET_ZONE_NO_POSITION, "No position"
    if lon != lon or lat != lat:  # NaN
        return FLEET_ZONE_NO_POSITION, "No position"

    zones = zones if zones is not None else load_fleet_zones()
    point = (lon, lat)
    for zone in zones:
        if zone["path"].contains_point(point):
            return zone["id"], zone["name"]
    return FLEET_ZONE_OUTSIDE, "Outside defined zones"


def assign_zones_to_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Add ``zone_id`` / ``zone_name`` columns using longitude/latitude."""
    out = df.copy()
    if out.empty:
        out["zone_id"] = pd.Series(dtype=str)
        out["zone_name"] = pd.Series(dtype=str)
        return out

    zones = load_fleet_zones()
    ids: list[str] = []
    names: list[str] = []
    for _, row in out.iterrows():
        zid, zname = assign_zone(row.get("longitude"), row.get("latitude"), zones=zones)
        ids.append(zid)
        names.append(zname)
    out["zone_id"] = ids
    out["zone_name"] = names
    return out
