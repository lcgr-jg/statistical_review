"""Shared HTML table chrome for Qatar Monitor fleet tables."""
from __future__ import annotations

from typing import Any

from dash import html

from core.styles import COLORS

BORDER = f"1px solid {COLORS['border']}"
SHADE_FLEET = "rgba(108, 117, 125, 0.10)"
SHADE_LADEN = "rgba(192, 57, 43, 0.10)"
SHADE_UNLADEN = "rgba(44, 111, 187, 0.10)"

TH = {
    "padding": "8px 12px",
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "backgroundColor": COLORS["table_header_bg"],
    "borderBottom": BORDER,
    "textAlign": "right",
    "whiteSpace": "nowrap",
}
TH_LEFT = {**TH, "textAlign": "left"}
TH_GROUP = {
    **TH,
    "textAlign": "center",
    "letterSpacing": "0.3px",
    "textTransform": "uppercase",
    "fontSize": "11px",
}

TD = {
    "padding": "8px 12px",
    "fontSize": "13px",
    "color": COLORS["text_primary"],
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "textAlign": "right",
    "whiteSpace": "nowrap",
}
TD_LEFT = {**TD, "textAlign": "left", "fontWeight": "500"}

TABLE_WRAP = {
    "overflowX": "auto",
    "border": BORDER,
    "borderRadius": "8px",
}

TABLE_STYLE = {
    "width": "100%",
    "borderCollapse": "collapse",
    "tableLayout": "auto",
}


def fmt_int(value: Any) -> str:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "—"
    if v != v:
        return "—"
    return f"{v:,.0f}"


def th(text: str, *, shade: str | None = None, left: bool = False, **extra) -> html.Th:
    style = {**(TH_LEFT if left else TH)}
    if shade:
        style["backgroundColor"] = shade
    style.update(extra.pop("style", {}))
    return html.Th(text, style=style, **extra)


def group_th(text: str, *, colspan: int, shade: str) -> html.Th:
    return html.Th(
        text,
        colSpan=colspan,
        style={**TH_GROUP, "backgroundColor": shade},
    )


def td(
    value: Any,
    *,
    shade: str | None = None,
    left: bool = False,
    hover: str | None = None,
) -> html.Td:
    style = {**(TD_LEFT if left else TD)}
    if shade:
        style["backgroundColor"] = shade
    text = value if left else fmt_int(value)
    if hover:
        return html.Td(
            html.Span(
                text,
                title=hover,
                style={"borderBottom": "1px dotted", "cursor": "help"},
            ),
            style=style,
            title=hover,
        )
    return html.Td(text, style=style)
