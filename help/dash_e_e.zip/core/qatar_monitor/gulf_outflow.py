"""Qatar exports vs Kuwait / UAE arrivals — implied Hormuz outflow."""
from __future__ import annotations

import math
from typing import Any

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.lng_data_kpler.qatar_exports import (
    daily_imports_by_destination_arrival,
    daily_unassigned_destination_exports,
)
from core.qatar_monitor.constants import (
    EVENTS,
    GULF_KUWAIT,
    GULF_OUTFLOW_CHART_START,
    GULF_OUTFLOW_MIN_EXPORTS_FOR_SHARE,
    GULF_OUTFLOW_WINDOW_DEFAULT,
    GULF_OUTFLOW_WINDOWS,
    GULF_UAE,
    GULF_VOYAGE_LAG_DAYS,
)
from core.styles import COLORS

_HOVERLABEL = dict(
    bgcolor="#ffffff",
    bordercolor="#2c3e50",
    font=dict(color="#231F20", size=13, family="Segoe UI, Arial, sans-serif"),
)

_FLOW_COLUMNS = ("exports", "kuwait", "uae", "unassigned")


def build_gulf_flow_frame(
    trades: pd.DataFrame,
    exports: pd.DataFrame,
) -> pd.DataFrame:
    """
    Daily mcm on the Qatar export calendar (through yesterday).

    ``kuwait`` / ``uae`` are arrival volumes shifted back by
    ``GULF_VOYAGE_LAG_DAYS``. ``unassigned`` is origin-date volume with no
    destination country. Missing days are 0.
    """
    if exports is None or exports.empty or "date" not in exports.columns:
        return pd.DataFrame(columns=list(_FLOW_COLUMNS))

    idx = pd.DatetimeIndex(pd.to_datetime(exports["date"])).normalize()
    frame = pd.DataFrame(
        {"exports": pd.to_numeric(exports["value"], errors="coerce").fillna(0.0).values},
        index=idx,
    )
    frame.index.name = "date"
    frame = frame[~frame.index.duplicated(keep="last")].sort_index()

    kuwait = daily_imports_by_destination_arrival(
        trades,
        GULF_KUWAIT,
        lag_days=GULF_VOYAGE_LAG_DAYS[GULF_KUWAIT],
    )
    uae = daily_imports_by_destination_arrival(
        trades,
        GULF_UAE,
        lag_days=GULF_VOYAGE_LAG_DAYS[GULF_UAE],
    )
    unassigned = daily_unassigned_destination_exports(trades)
    frame["kuwait"] = kuwait.reindex(frame.index, fill_value=0.0)
    frame["uae"] = uae.reindex(frame.index, fill_value=0.0)
    frame["unassigned"] = unassigned.reindex(frame.index, fill_value=0.0)
    return frame.astype(float)


def gulf_flow_to_records(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """JSON-serialisable rows for ``dcc.Store``."""
    if frame is None or frame.empty:
        return []
    out = frame.reset_index()
    date_col = "date" if "date" in out.columns else out.columns[0]
    out = out.rename(columns={date_col: "date"})
    out["date"] = pd.to_datetime(out["date"], errors="coerce").dt.strftime("%Y-%m-%d")
    records: list[dict[str, Any]] = []
    for row in out.to_dict(orient="records"):
        item: dict[str, Any] = {"date": row.get("date")}
        for col in _FLOW_COLUMNS:
            raw = row.get(col)
            try:
                val = float(raw)
            except (TypeError, ValueError):
                item[col] = None
                continue
            item[col] = None if math.isnan(val) else val
        records.append(item)
    return records


def records_to_gulf_flow(records: list[dict] | None) -> pd.DataFrame:
    if not records:
        return pd.DataFrame(columns=list(_FLOW_COLUMNS))
    df = pd.DataFrame(records)
    if "date" not in df.columns:
        return pd.DataFrame(columns=list(_FLOW_COLUMNS))
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"]).set_index("date").sort_index()
    for col in _FLOW_COLUMNS:
        if col not in df.columns:
            df[col] = 0.0
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    return df[list(_FLOW_COLUMNS)].astype(float)


def parse_outflow_window(value) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return GULF_OUTFLOW_WINDOW_DEFAULT
    if n not in GULF_OUTFLOW_WINDOWS:
        return GULF_OUTFLOW_WINDOW_DEFAULT
    return n


def _smooth(frame: pd.DataFrame, window: int) -> pd.DataFrame:
    """Trailing mean. A full window is required so the start is not a ramp."""
    smoothed = frame.rolling(window, min_periods=window).mean()
    start = pd.Timestamp(GULF_OUTFLOW_CHART_START)
    return smoothed.loc[smoothed.index >= start].dropna(how="all")


def _latest_blurb(smoothed: pd.DataFrame, window: int) -> str:
    if smoothed.empty:
        return f"{window}-day moving average"
    last = smoothed.iloc[-1]
    exports = float(last["exports"])
    gulf = float(last["kuwait"] + last["uae"])
    leaving = exports - gulf
    unassigned = float(last["unassigned"])
    asof = pd.Timestamp(smoothed.index[-1]).strftime("%d %b")
    if exports > 1.0:
        pct = 100.0 * leaving / exports
        pct_txt = f"{pct:.0f}%"
    else:
        pct_txt = "—"
    return (
        f"Latest {window}d average through {asof}: "
        f"exports {exports:.0f} mcm/d · Kuwait+UAE {gulf:.0f} · "
        f"leaving {leaving:.0f} ({pct_txt}) · no destination {unassigned:.0f}"
    )


def _y(values) -> list[float | None]:
    out: list[float | None] = []
    for v in values:
        try:
            x = float(v)
        except (TypeError, ValueError):
            out.append(None)
            continue
        out.append(None if math.isnan(x) else x)
    return out


def build_gulf_outflow_chart(
    frame: pd.DataFrame,
    *,
    window: int | None = None,
) -> go.Figure:
    """
    Two panels sharing a date axis.

    Top: export moving average vs stacked Kuwait and UAE arrival averages.
    Bottom: implied Hormuz outflow (mcm/d and % of exports) and the
    no-destination loading rate.
    """
    window = parse_outflow_window(window)
    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        row_heights=[0.56, 0.44],
        vertical_spacing=0.12,
        subplot_titles=(
            f"Qatar exports vs Kuwait & UAE arrivals ({window}d MA)",
            f"Implied volume leaving the Gulf ({window}d MA)",
        ),
        specs=[
            [{"secondary_y": False}],
            [{"secondary_y": True}],
        ],
    )

    def _empty(message: str) -> go.Figure:
        fig.update_layout(
            height=640,
            paper_bgcolor=COLORS["chart_paper"],
            plot_bgcolor=COLORS["chart_bg"],
            margin=dict(l=60, r=60, t=96, b=40),
            title=dict(
                text=f"{window}d moving average",
                font=dict(size=14, color="#2c3e50"),
                x=0,
                xanchor="left",
                y=1,
                yanchor="top",
                pad=dict(b=28),
            ),
        )
        fig.add_annotation(
            text=message,
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font={"size": 14, "color": COLORS["text_muted"]},
        )
        return fig

    if frame is None or frame.empty or "exports" not in frame.columns:
        return _empty("No Qatar export history in the Kpler cache.")

    smoothed = _smooth(frame, window)
    if smoothed.empty or smoothed["exports"].notna().sum() == 0:
        return _empty(f"Not enough daily history for a {window}-day average.")

    x = list(smoothed.index)
    exports = smoothed["exports"]
    kuwait = smoothed["kuwait"]
    uae = smoothed["uae"]
    unassigned = smoothed["unassigned"]
    leaving = exports - kuwait - uae
    # A near-zero export rate (the spring outage) turns the share into a spike.
    pct = (leaving / exports.where(exports >= GULF_OUTFLOW_MIN_EXPORTS_FOR_SHARE) * 100.0)

    fig.add_trace(
        go.Scatter(
            x=x,
            y=_y(kuwait.values),
            name="Kuwait arrivals",
            mode="lines",
            stackgroup="gulf",
            line=dict(width=0.6, color="#e67e22"),
            fillcolor="rgba(230, 126, 34, 0.55)",
            hovertemplate="%{x|%d %b}: %{y:.0f} mcm/d<extra>Kuwait</extra>",
            hoverlabel=_HOVERLABEL,
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=_y(uae.values),
            name="UAE arrivals",
            mode="lines",
            stackgroup="gulf",
            line=dict(width=0.6, color="#16a085"),
            fillcolor="rgba(22, 160, 133, 0.45)",
            hovertemplate="%{x|%d %b}: %{y:.0f} mcm/d<extra>UAE</extra>",
            hoverlabel=_HOVERLABEL,
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=_y(exports.values),
            name="Qatar exports",
            mode="lines",
            line=dict(color="#2c6fbb", width=2.4),
            hovertemplate="%{x|%d %b}: %{y:.0f} mcm/d<extra>Exports</extra>",
            hoverlabel=_HOVERLABEL,
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=_y(leaving.values),
            name="Leaving the Gulf",
            mode="lines",
            line=dict(color="#5d6d7e", width=1.2),
            fill="tozeroy",
            fillcolor="rgba(93, 109, 126, 0.28)",
            hovertemplate="%{x|%d %b}: %{y:.0f} mcm/d<extra>Leaving</extra>",
            hoverlabel=_HOVERLABEL,
        ),
        row=2,
        col=1,
        secondary_y=False,
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=_y(unassigned.values),
            name="No destination",
            mode="lines",
            line=dict(color="#c0392b", width=2.0, dash="dash"),
            hovertemplate="%{x|%d %b}: %{y:.0f} mcm/d<extra>No destination</extra>",
            hoverlabel=_HOVERLABEL,
        ),
        row=2,
        col=1,
        secondary_y=False,
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=_y(pct.values),
            name="Leaving, % of exports",
            mode="lines",
            connectgaps=False,
            line=dict(color="#6c3483", width=2.0),
            hovertemplate="%{x|%d %b}: %{y:.0f}%<extra>Leaving %</extra>",
            hoverlabel=_HOVERLABEL,
        ),
        row=2,
        col=1,
        secondary_y=True,
    )

    x_end = pd.Timestamp(smoothed.index.max())
    for date in sorted(EVENTS):
        when = pd.Timestamp(date)
        if when < pd.Timestamp(GULF_OUTFLOW_CHART_START) or when > x_end + pd.Timedelta(days=2):
            continue
        for row in (1, 2):
            fig.add_vline(
                x=when,
                line=dict(color="#2c3e50", width=1, dash="dash"),
                row=row,
                col=1,
            )

    fig.update_layout(
        height=740,
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        font=dict(
            family="Segoe UI, Arial, sans-serif",
            size=12,
            color=COLORS["text_primary"],
        ),
        margin=dict(l=60, r=64, t=118, b=48),
        title=dict(
            text=(
                f"<span style='font-size:12px;color:#495057'>"
                f"{_latest_blurb(smoothed, window)}</span>"
            ),
            font=dict(size=13, color="#495057"),
            x=0,
            xanchor="left",
            y=1,
            yanchor="top",
            pad=dict(b=36),
        ),
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.08,
            xanchor="left",
            x=0,
            font=dict(size=11),
        ),
        hovermode="x unified",
        hoverlabel=_HOVERLABEL,
        uirevision=f"gulf-outflow-{window}",
    )
    fig.update_yaxes(
        title_text="mcm/d",
        rangemode="tozero",
        gridcolor="rgba(0,0,0,0.08)",
        row=1,
        col=1,
    )
    fig.update_yaxes(
        title_text="mcm/d",
        gridcolor="rgba(0,0,0,0.08)",
        zeroline=True,
        zerolinecolor="rgba(0,0,0,0.35)",
        row=2,
        col=1,
        secondary_y=False,
    )
    fig.update_yaxes(
        title_text="% of exports",
        showgrid=False,
        tickfont=dict(color="#6c3483"),
        title_font=dict(color="#6c3483", size=11),
        row=2,
        col=1,
        secondary_y=True,
    )
    fig.update_xaxes(
        range=[pd.Timestamp(smoothed.index.min()), x_end + pd.Timedelta(days=2)],
        gridcolor="rgba(0,0,0,0.06)",
        row=2,
        col=1,
    )
    return fig
