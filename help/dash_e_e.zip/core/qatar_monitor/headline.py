"""Headline KPI strip for the top of Qatar Monitor."""
from __future__ import annotations

from typing import Any

import pandas as pd
from dash import html

from core.qatar_monitor.constants import (
    CHART_START,
    FLEET_ZONE_PERSIAN_GULF,
    N_BERTHS,
)
from core.qatar_monitor.loadings_table import filter_recent_loadings
from core.qatar_monitor.stats import empty_hours_7d_ma
from core.styles import COLORS

_CARD = {
    "flex": "1 1 140px",
    "minWidth": "130px",
    "backgroundColor": COLORS.get("chart_bg", "#f8f9fa"),
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "8px",
    "padding": "10px 12px",
}
_CARD_LABEL = {
    "fontSize": "10px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "textTransform": "uppercase",
    "letterSpacing": "0.4px",
    "marginBottom": "4px",
}
_CARD_VALUE = {
    "fontSize": "15px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "lineHeight": "1.2",
}
_CARD_SUB = {
    "fontSize": "11px",
    "color": COLORS["text_secondary"],
    "marginTop": "3px",
    "lineHeight": "1.3",
}


def _fmt_dt(value: Any) -> str:
    if value is None or pd.isna(value):
        return "—"
    return pd.Timestamp(value).strftime("%d-%b %H:%M")


def _fmt_elapsed(hours: float) -> str:
    if hours < 48:
        return f"{hours:.1f} hrs"
    return f"{hours / 24.0:.1f} days"


def _card(label: str, value: str, sub: str = "") -> html.Div:
    children = [
        html.Div(label, style=_CARD_LABEL),
        html.Div(value, style=_CARD_VALUE),
    ]
    if sub:
        children.append(html.Div(sub, style=_CARD_SUB))
    return html.Div(children, style=_CARD)


def _at_berth(loadings: pd.DataFrame | None) -> pd.DataFrame:
    if loadings is None or loadings.empty or "berth_departure" not in loadings.columns:
        return pd.DataFrame()
    return loadings[loadings["berth_departure"].isna()].copy()


def _last_departure(loadings: pd.DataFrame | None) -> pd.Series | None:
    if loadings is None or loadings.empty or "berth_departure" not in loadings.columns:
        return None
    departed = loadings[loadings["berth_departure"].notna()].sort_values(
        "berth_departure"
    )
    if departed.empty:
        return None
    return departed.iloc[-1]


def _gulf_slice(
    fleet_positions: pd.DataFrame | None, *, laden: bool
) -> tuple[float, int]:
    """Laden cargo mcm, or unladen nameplate capacity, inside Hormuz."""
    if fleet_positions is None or fleet_positions.empty:
        return 0.0, 0
    gulf = fleet_positions[fleet_positions["zone_id"] == FLEET_ZONE_PERSIAN_GULF]
    if gulf.empty:
        return 0.0, 0
    is_laden = gulf["is_laden"].fillna(False).astype(bool)
    sub = gulf[is_laden if laden else ~is_laden]
    col = "cargo_mcm" if laden else "capacity_mcm"
    vol = float(sub[col].sum()) if col in sub.columns else 0.0
    return vol, int(len(sub))


def build_headline(
    loadings: pd.DataFrame | None,
    fleet_positions: pd.DataFrame | None = None,
    *,
    gap: pd.DataFrame | None = None,
    now: pd.Timestamp | None = None,
) -> html.Div:
    """Compact snapshot of the highest-signal Ras Laffan / Gulf stats."""
    now = pd.Timestamp(now or pd.Timestamp.now())
    at_berth = _at_berth(loadings)
    n_loading = int(len(at_berth))
    loading_names = (
        ", ".join(str(v) for v in at_berth["vessel"].tolist())
        if n_loading and "vessel" in at_berth.columns
        else "None"
    )

    last_dep = _last_departure(loadings)
    empty_hours: float | None = None
    if n_loading == 0 and last_dep is not None:
        last_t = pd.Timestamp(last_dep["berth_departure"])
        if pd.notna(last_t) and last_t < now:
            empty_hours = (now - last_t).total_seconds() / 3600.0

    recent = filter_recent_loadings(loadings, n_days=7, now=now)
    recent_mcm = float(recent["volume_mcm"].sum()) if not recent.empty else 0.0
    recent_n = int(len(recent))

    gulf_laden_mcm, gulf_laden_n = _gulf_slice(fleet_positions, laden=True)
    gulf_unladen_mcm, gulf_unladen_n = _gulf_slice(fleet_positions, laden=False)

    ma_src = gap if gap is not None and not gap.empty else loadings
    ma = empty_hours_7d_ma(ma_src, start=CHART_START, now=now, window=7)
    ma_latest = float(ma.iloc[-1]) if not ma.empty else None
    ma_when = ma.index[-1].strftime("%d-%b") if not ma.empty else ""

    last_value = "—"
    last_sub = ""
    if last_dep is not None:
        last_value = str(last_dep.get("vessel") or "—")
        dest = str(last_dep.get("destination") or "").strip()
        vol = last_dep.get("volume_mcm")
        vol_txt = f"{float(vol):,.0f} mcm" if pd.notna(vol) else ""
        bits = [_fmt_dt(last_dep.get("berth_departure"))]
        if dest and dest.lower() not in ("none", "nan"):
            bits.append(dest)
        if vol_txt:
            bits.append(vol_txt)
        last_sub = " · ".join(bits)

    cards = [
        _card(
            "Berths occupied",
            f"{n_loading} / {N_BERTHS}",
            loading_names,
        ),
        _card(
            "Hours empty",
            _fmt_elapsed(empty_hours) if empty_hours is not None else "—",
            "since last cargo departed"
            if empty_hours is not None
            else "berths currently occupied",
        ),
        _card("Last cargo departure", last_value, last_sub),
        _card(
            "Loadings (last 7d)",
            f"{recent_mcm:,.0f} mcm",
            f"{recent_n} cargoes",
        ),
        _card(
            "Empty hours (7d MA)",
            f"{ma_latest:.1f} h/d" if ma_latest is not None else "—",
            f"hours/day all berths empty · to {ma_when}" if ma_when else "",
        ),
        _card(
            "Laden in Persian Gulf",
            f"{gulf_laden_mcm:,.0f} mcm",
            f"{gulf_laden_n} cargoes inside Hormuz",
        ),
        _card(
            "Unladen in Persian Gulf",
            f"{gulf_unladen_mcm:,.0f} mcm",
            f"{gulf_unladen_n} vessels of spare capacity",
        ),
    ]
    return html.Div(
        cards,
        style={
            "display": "flex",
            "flexWrap": "wrap",
            "gap": "10px",
        },
    )
