"""Dash callbacks for the Iberia / OMIE page (global @callback registration).

Cross-panel model: the heatmap (or Navigator) pins a (day, QH) into ``ib-pin``;
the readout, sub-strip and panels 2–4 all react to it, with a shared cursor band
at the pinned quarter-hour.
"""
from __future__ import annotations

import pandas as pd
import dash_bootstrap_components as dbc
from dash import Input, Output, State, callback, ctx, html
from dash.exceptions import PreventUpdate

from core.styles import COLORS

from . import data as D
from . import figures as F
from .layout import TAB_BUILDERS
from .constants import DEFAULT_TAB, TEXT, HELPER


@callback(Output("iberia-content", "children"), Input("iberia-tabs", "active_tab"))
def _render_tab(active):
    return TAB_BUILDERS.get(active or DEFAULT_TAB, TAB_BUILDERS[DEFAULT_TAB])()


# ── Unit Explorer ─────────────────────────────────────────────────────────────
@callback(Output("ib-unit", "options"), Output("ib-unit", "value"),
          Input("ib-start", "date"), State("ib-unit", "value"))
def _ib_units(start, current):
    if not start:
        raise PreventUpdate
    units = D.list_units(*D.month_window(start))
    opts = D.unit_options(units)
    value = current if current in units else (opts[0]["value"] if opts else None)
    return opts, value


@callback(Output("ib-start", "date"), Output("ib-end", "date"),
          Input("ib-presets", "value"), prevent_initial_call=True)
def _ib_presets(preset):
    dates = D.available_unit_dates()
    if not preset or not dates:
        raise PreventUpdate
    last = pd.Timestamp(dates[-1])
    if preset == "all":
        return dates[0], dates[-1]
    if preset == "month":
        return last.replace(day=1).strftime("%Y-%m-%d"), dates[-1]
    if preset == "d7":
        return (last - pd.Timedelta(days=6)).strftime("%Y-%m-%d"), dates[-1]
    if preset == "d30":
        return (last - pd.Timedelta(days=29)).strftime("%Y-%m-%d"), dates[-1]
    raise PreventUpdate


@callback(Output("ib-pin", "data"),
          Input("ib-heatmap", "clickData"), Input("ib-nav", "value"),
          Input("ib-unit", "value"), Input("ib-end", "date"),
          State("ib-pin", "data"))
def _ib_pin(click, nav, unit, end, cur):
    cur = cur or {}
    qh = cur.get("qh", "20:00")
    if ctx.triggered_id == "ib-heatmap" and click:
        p = click["points"][0]
        return {"date": str(p["y"]), "qh": str(p["x"])}
    return {"date": nav or end, "qh": qh}


@callback(Output("ib-pin", "data", allow_duplicate=True), Output("ib-presets", "value"),
          Input("ib-clear", "n_clicks"), State("ib-nav", "value"), prevent_initial_call=True)
def _ib_clear(n, nav):
    return {"date": nav, "qh": "20:00"}, None


@callback(Output("ib-readout", "children"), Input("ib-pin", "data"))
def _ib_readout(pin):
    if not pin or not pin.get("date"):
        return "— pin a period —"
    d, qh = pin["date"], pin.get("qh", "")
    px = ""
    ds, de = D.day_window(d)
    s = F._es_day_ahead(D.get_day_ahead_price(ds, de, ("ES",)))
    if s is not None and not s.empty and qh:
        tod = D.to_madrid(s.index).strftime("%H:%M")
        m = s[tod == qh]
        if len(m):
            px = f"  ·  {float(m.iloc[0]):.1f} €/MWh"
    hh = qh.split(":")[0] if qh else ""
    return f"{d}  {hh}h{px}"


@callback(Output("ib-heatmap", "figure"),
          Input("ib-unit", "value"), Input("ib-start", "date"), Input("ib-end", "date"),
          Input("ib-measure", "value"), Input("ib-program", "value"))
def _ib_heatmap(unit, start, end, measure, program):
    return F.heatmap(unit, start, end, measure, program)


@callback(Output("ib-substrip", "figure"),
          Input("ib-unit", "value"), Input("ib-start", "date"), Input("ib-end", "date"),
          Input("ib-pin", "data"))
def _ib_substrip(unit, start, end, pin):
    return F.substrip(unit, start, end, (pin or {}).get("qh"))


@callback(Output("ib-candles", "figure"), Output("ib-volume", "figure"), Output("ib-price", "figure"),
          Input("ib-unit", "value"), Input("ib-pin", "data"))
def _ib_panels(unit, pin):
    pin = pin or {}
    d, qh = pin.get("date"), pin.get("qh")
    return F.candles(unit, d, qh), F.volume(unit, d, qh), F.price(unit, d, qh)


# ── Bid-offer & Merit ─────────────────────────────────────────────────────────
@callback(Output("ib-cross", "figure"), Input("ib-cv-date", "date"), Input("ib-cv-hour", "value"))
def _ib_cross(date, hour):
    return F.cross(date, hour)


# ── Redispatch ────────────────────────────────────────────────────────────────
def _stat(value, label):
    return dbc.Card(dbc.CardBody([
        html.Div(value, style={"fontSize": "1.3rem", "fontWeight": 700, "color": TEXT}),
        html.Div(label, style={"color": HELPER, "fontSize": "0.8rem"}),
    ]), className="iberia-card", style={"marginBottom": 0})


def _kpi_cards(k):
    if not k:
        return html.Div()
    gwh = lambda v: f"{v / 1000:,.1f} GWh"
    cost = "—" if (k.get("cost") != k.get("cost")) else f"€{k['cost'] / 1e6:,.2f} m"
    return dbc.Row([
        dbc.Col(_stat(gwh(k.get("RT_MD_up", 0)), "RT day-ahead ↑"), md=2),
        dbc.Col(_stat(gwh(k.get("RT_MD_dn", 0)), "RT day-ahead ↓"), md=2),
        dbc.Col(_stat(gwh(k.get("RTR_up", 0)), "RT real-time ↑"), md=2),
        dbc.Col(_stat(gwh(k.get("RTR_dn", 0)), "RT real-time ↓"), md=2),
        dbc.Col(_stat(cost, "Redispatch cost (pay-as-bid)"), md=4),
    ], className="g-3 mb-3")


@callback(Output("ib-rd-kpis", "children"), Output("ib-rd-profile", "figure"),
          Output("ib-rd-top", "figure"), Output("ib-rd-tech", "figure"),
          Input("ib-rd-date", "date"))
def _ib_redispatch(date):
    return (_kpi_cards(F.redispatch_kpis(date)), F.redispatch_profile(date),
            F.redispatch_top_units(date), F.redispatch_by_tech(date))
