"""Light-theme figure builders for the Iberia / OMIE page.

Unit-Explorer panels share the pinned day's time-of-day x-axis and a translucent
vertical cursor band at the pinned quarter-hour. Heatmap spans the selected date
range (many days at once); clicking a cell pins a (day, QH). Themed off the
registered "dashboard" template with the desk palette (MD blue, Turbo heatmap).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from core.theme import PLOTLY_TEMPLATE_NAME

from . import data as D
from .constants import (
    CATEGORY_COLORS, CATEGORY_SHORT, REDISPATCH_COLORS, SESSION_COLORS,
    PRICE_CATEGORIES, VOLUME_ORDER, SESSION_KEYS, SESSION_LABELS,
    HEATMAP_SCALE, CANDLE_UP, CANDLE_DOWN, CURSOR_RGBA, MD_BLUE,
    TEXT, HELPER, GRID,
)

TEMPLATE = PLOTLY_TEMPLATE_NAME
_HOUR_TICKS = [f"{h:02d}:00" for h in range(0, 24, 2)]


def _lay(title="", ytitle="", height=380, novgrid=True, legend=True):
    lay = dict(
        template=TEMPLATE, height=height,
        title=dict(text=title, font=dict(size=14, color=TEXT)) if title else None,
        margin=dict(l=58, r=18, t=44 if title else 16, b=40),
        showlegend=legend,
        legend=dict(orientation="h", yanchor="bottom", y=-0.22, x=0,
                    font=dict(size=10, color="#5A6169")),
        hovermode="x unified",
    )
    return {k: v for k, v in lay.items() if v is not None}


def _grid(fig, novgrid=True):
    fig.update_yaxes(gridcolor=GRID, zerolinecolor="#D9DEE3", zeroline=True)
    fig.update_xaxes(showgrid=not novgrid, gridcolor=GRID, zeroline=False)


def _empty(msg, height=380):
    fig = go.Figure()
    fig.update_layout(template=TEMPLATE, height=height, margin=dict(l=30, r=18, t=20, b=20))
    fig.add_annotation(text=msg, showarrow=False, font=dict(color=HELPER, size=13),
                       xref="paper", yref="paper", x=0.5, y=0.5)
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    return fig


def _cursor(fig, pin_dt):
    if pin_dt is not None:
        fig.add_vrect(x0=pin_dt - pd.Timedelta(minutes=7), x1=pin_dt + pd.Timedelta(minutes=8),
                      fillcolor=CURSOR_RGBA, line_width=0, layer="below")


def _pin_dt(pin_date, pin_qh):
    if not pin_date or not pin_qh:
        return None
    return pd.Timestamp(f"{pin_date} {pin_qh}", tz=D.MADRID)


def _qend(end):
    """End date is exclusive in the readers; bump by a day to include it."""
    return (pd.Timestamp(end) + pd.Timedelta(days=1)).strftime("%Y-%m-%d")


def _es_day_ahead(px):
    if px is None or getattr(px, "empty", True):
        return None
    if isinstance(px.columns, pd.MultiIndex):
        cols = [c for c in px.columns if c[0] == "ES"]
        return px[cols[0]] if cols else None
    return px.iloc[:, 0]


# ── Panel 1: month/range heatmap (days × QH) ─────────────────────────────────
def heatmap(unit, start, end, measure, program) -> go.Figure:
    if not unit or not start:
        return _empty("Select a unit and date range", 440)
    if measure == "price":
        s = _es_day_ahead(D.get_day_ahead_price(start, _qend(end), ("ES",)))
        if s is None or s.empty:
            return _empty("No day-ahead price for this range", 440)
        dt = D.to_madrid(s.index)
        frame = pd.DataFrame({"day": dt.strftime("%Y-%m-%d"), "tod": dt.strftime("%H:%M"), "v": s.values})
        title, unit_lbl = f"Day-ahead price · ES (€/MWh)", "€/MWh"
    else:
        facts = D.get_unit_facts(start, _qend(end), unit=unit, categories=(program,), measure="energy_mwh")
        if facts is None or facts.empty:
            return _empty(f"No {program} data for {unit} — I90 backfill in progress", 440)
        dt = D.to_madrid(facts["datetime"])
        frame = pd.DataFrame({"day": dt.strftime("%Y-%m-%d"), "tod": dt.strftime("%H:%M"),
                              "v": facts["value"].to_numpy()})
        title, unit_lbl = f"{program} · {unit} ({'€/MWh' if measure == 'price' else 'MWh'})", "MWh"
    mat = frame.pivot_table(index="day", columns="tod", values="v", aggfunc="sum").sort_index(ascending=False)
    fig = go.Figure(go.Heatmap(
        z=mat.values, x=list(mat.columns), y=list(mat.index), colorscale=HEATMAP_SCALE,
        xgap=1.5, ygap=1.5, hoverongaps=False, colorbar=dict(title=unit_lbl, thickness=10),
        hovertemplate="%{y} %{x}<br>%{z:.1f} " + unit_lbl + "<extra></extra>"))
    fig.update_layout(**_lay("", height=440, legend=False))
    fig.update_xaxes(side="top", showgrid=False, type="category",
                     tickmode="array", tickvals=_HOUR_TICKS, ticktext=[h.replace(":00", "h") for h in _HOUR_TICKS])
    fig.update_yaxes(showgrid=False, title="", tickfont=dict(size=9), type="category")
    return fig


def substrip(unit, start, end, pin_qh) -> go.Figure:
    """Per-session price across days, at the pinned quarter-hour."""
    if not pin_qh:
        return _empty("Pin a period in the heatmap to see its price path", 150)
    px = D.get_session_prices(start, _qend(end), "ES")
    if px is None or px.empty:
        return _empty("No session prices for this range", 150)
    tod = D.to_madrid(px.index).strftime("%H:%M")
    sub = px[tod == pin_qh]
    if sub.empty:
        return _empty(f"No prices at {pin_qh} in this range", 150)
    day = D.to_madrid(sub.index)
    fig = go.Figure()
    for key in SESSION_KEYS:
        if key in sub.columns and sub[key].notna().any():
            fig.add_scatter(x=list(day), y=list(sub[key].to_numpy()), mode="lines+markers",
                            name=SESSION_LABELS[key], line=dict(color=SESSION_COLORS[key], width=1.6),
                            marker=dict(size=4))
    fig.update_layout(**_lay(f"Pinned-period price across days · {pin_qh}", "€/MWh", height=170))
    _grid(fig)
    return fig


# ── Panel 2: intraday candles across sessions ────────────────────────────────
def candles(unit, pin_date, pin_qh) -> go.Figure:
    if not pin_date:
        return _empty("Pin a day in the heatmap", 360)
    ds, de = D.day_window(pin_date)
    px = D.get_session_prices(ds, de, "ES")
    if px is None or px.empty or "price_day_ahead" not in px.columns:
        return _empty("Intraday session prices not loaded for this date", 360)
    cols = [c for c in SESSION_KEYS if c in px.columns]
    aligned = px[cols].copy().sort_index()
    for c in cols:
        if c != "price_day_ahead":
            aligned[c] = aligned[c].ffill(limit=3)
    arr = aligned.to_numpy(dtype="float64")
    md = aligned["price_day_ahead"].to_numpy(dtype="float64")
    high = np.nanmax(arr, axis=1)
    low = np.nanmin(arr, axis=1)
    close = np.array([row[~np.isnan(row)][-1] if np.any(~np.isnan(row)) else np.nan for row in arr])
    x = D.to_madrid(aligned.index)
    ladder = [" · ".join(f"{SESSION_LABELS[c]} {row[i]:.1f}" for i, c in enumerate(cols) if not np.isnan(row[i]))
              for row in arr]
    fig = go.Figure(go.Candlestick(x=list(x), open=list(md), high=list(high), low=list(low), close=list(close),
                                   increasing_line_color=CANDLE_UP, decreasing_line_color=CANDLE_DOWN,
                                   increasing_fillcolor=CANDLE_UP, decreasing_fillcolor=CANDLE_DOWN,
                                   line=dict(width=1), name="MD→S1→S2→S3", text=ladder, whiskerwidth=0.2))
    fig.update_layout(**_lay(f"Intraday price candles · {pin_date}", "€/MWh", 360, legend=False))
    fig.update_layout(xaxis_rangeslider_visible=False, hovermode="x")
    _grid(fig)
    _cursor(fig, _pin_dt(pin_date, pin_qh))
    return fig


# ── Panel 3: signed volume by category ───────────────────────────────────────
def volume(unit, pin_date, pin_qh) -> go.Figure:
    if not unit or not pin_date:
        return _empty("Pin a day in the heatmap", 320)
    ds, de = D.day_window(pin_date)
    facts = D.get_unit_facts(ds, de, unit=unit, measure="energy_mwh")
    if facts is None or facts.empty:
        return _empty(f"No programme data for {unit} on {pin_date}", 320)
    facts = facts.assign(dt=D.to_madrid(facts["datetime"]))
    fig = go.Figure()
    for cat in [c for c in VOLUME_ORDER if c in set(facts["category"])]:
        g = facts[facts["category"] == cat].groupby("dt")["value"].sum().sort_index()
        fig.add_bar(x=list(g.index), y=list(g.values), name=CATEGORY_SHORT.get(cat, cat),
                    marker_color=CATEGORY_COLORS.get(cat, "#868e96"), marker_line_width=0)
    fig.update_layout(barmode="relative", **_lay(f"Volume by category · {unit}", "MWh", 320))
    _grid(fig)
    _cursor(fig, _pin_dt(pin_date, pin_qh))
    return fig


# ── Panel 4: unit price by adjustment category ───────────────────────────────
def price(unit, pin_date, pin_qh) -> go.Figure:
    if not unit or not pin_date:
        return _empty("Pin a day in the heatmap", 320)
    ds, de = D.day_window(pin_date)
    pr = D.get_unit_prices(unit, ds, de)
    fig = go.Figure()
    traces = 0
    if pr is not None and not pr.empty:
        idx = D.to_madrid(pr.index)
        for cat in PRICE_CATEGORIES:
            if cat in pr.columns and pr[cat].notna().any():
                fig.add_scatter(x=list(idx), y=list(pr[cat].to_numpy()), mode="lines",
                                name=CATEGORY_SHORT.get(cat, cat),
                                line=dict(color=CATEGORY_COLORS.get(cat, "#868e96"), width=2))
                traces += 1
    s = _es_day_ahead(D.get_day_ahead_price(ds, de, ("ES",)))
    if s is not None and not s.empty:
        fig.add_scatter(x=list(D.to_madrid(s.index)), y=list(s.to_numpy()), mode="lines",
                        name="MD «med»", line=dict(color=MD_BLUE, width=1.4, dash="dash"))
        traces += 1
    if traces == 0:
        return _empty(f"No adjustment prices for {unit} on {pin_date}", 320)
    fig.update_layout(**_lay(f"Unit price by adjustment category · {unit}", "€/MWh", 320))
    _grid(fig)
    _cursor(fig, _pin_dt(pin_date, pin_qh))
    return fig


# ── Bid-offer & Merit (unchanged tab) ─────────────────────────────────────────
def cross(date, hour) -> go.Figure:
    if not date:
        return _empty("Select a date and hour", 520)
    hour = int(hour) if hour is not None else 12
    sd = D.get_supply_demand(date, hour, "day_ahead")
    sell, buy = sd.get("sell"), sd.get("buy")
    has_sell = sell is not None and not sell.empty
    has_buy = buy is not None and not buy.empty
    if not has_sell and not has_buy:
        return _empty(f"No curve data for {date} {hour:02d}:00 — OMIE day-ahead curves cover 2021 → present", 520)
    fig = go.Figure()
    if has_sell:
        fig.add_scatter(x=sell["cum_mwh"], y=sell["price_eur_mwh"], name="Supply · sell offers",
                        mode="lines", line=dict(color=CANDLE_UP, width=2, shape="hv"))
    if has_buy:
        fig.add_scatter(x=buy["cum_mwh"], y=buy["price_eur_mwh"], name="Demand · buy bids",
                        mode="lines", line=dict(color=MD_BLUE, width=2, shape="hv"))
    ds, de = D.day_window(date)
    px = D.get_session_prices(ds, de, "ES")
    if px is not None and not px.empty and "price_day_ahead" in px.columns:
        tod = D.to_madrid(px.index)
        match = px[tod.hour == hour]
        if len(match) and match["price_day_ahead"].notna().any():
            p = float(match["price_day_ahead"].dropna().iloc[0])
            fig.add_hline(y=p, line=dict(color=HELPER, dash="dash"),
                          annotation_text=f"MD clearing ≈ {p:.1f} €/MWh", annotation_position="top left")
    fig.update_layout(**_lay(f"Supply / demand · day-ahead · {date} {hour:02d}:00 (Madrid)", "€/MWh", 520))
    fig.update_xaxes(title="Cumulative offered energy (MWh)")
    _grid(fig, novgrid=False)
    return fig


# ── Redispatch (unchanged tab) ────────────────────────────────────────────────
def _redispatch_facts(date):
    ds, de = D.day_window(date)
    return D.get_unit_facts(ds, de, categories=("RT_MD", "RTR"))


def redispatch_profile(date) -> go.Figure:
    f = _redispatch_facts(date)
    e = f[f["measure"] == "energy_mwh"].copy() if not f.empty else f
    if e is None or e.empty:
        return _empty(f"No redispatch on {date}", 360)
    e["tod"] = D.to_madrid(e["datetime"]).strftime("%H:%M")
    e["dir"] = np.where(e["value"] >= 0, "up", "down")
    fig = go.Figure()
    for cat in ("RT_MD", "RTR"):
        for d in ("up", "down"):
            g = e[(e["category"] == cat) & (e["dir"] == d)].groupby("tod")["value"].sum().sort_index()
            if len(g):
                fig.add_bar(x=list(g.index), y=list(g.values),
                            name=f"{CATEGORY_SHORT.get(cat, cat)} {'↑' if d == 'up' else '↓'}",
                            marker_color=REDISPATCH_COLORS[(cat, d)], marker_line_width=0)
    fig.update_layout(barmode="relative", **_lay(f"System redispatch volume by QH · {date}", "MWh", 360))
    _grid(fig)
    return fig


def redispatch_top_units(date, n=15) -> go.Figure:
    f = _redispatch_facts(date)
    e = f[f["measure"] == "energy_mwh"].copy() if not f.empty else f
    if e is None or e.empty:
        return _empty(f"No redispatch on {date}", 460)
    e["abs"] = e["value"].abs()
    order = list(e.groupby("unit")["abs"].sum().nlargest(n).index)[::-1]
    fig = go.Figure()
    for cat in ("RT_MD", "RTR"):
        g = e[e["category"] == cat].groupby("unit")["abs"].sum().reindex(order).fillna(0)
        fig.add_bar(y=order, x=list(g.values), name=CATEGORY_SHORT.get(cat, cat), orientation="h",
                    marker_color=REDISPATCH_COLORS[(cat, "up")], marker_line_width=0)
    fig.update_layout(barmode="stack", **_lay(f"Most-redispatched units · {date}", "", 460))
    fig.update_layout(margin=dict(l=110, r=18, t=44, b=40))
    fig.update_xaxes(title="Redispatch energy |MWh|", showgrid=True, gridcolor=GRID)
    return fig


def redispatch_by_tech(date) -> go.Figure:
    f = _redispatch_facts(date)
    e = f[f["measure"] == "energy_mwh"].copy() if not f.empty else f
    if e is None or e.empty:
        return _empty(f"No redispatch on {date}", 460)
    e["tech"] = e["unit"].map(D.classify_unit)
    e["dir"] = np.where(e["value"] >= 0, "up", "down")
    fig = go.Figure()
    for d, color in (("up", "#E8932A"), ("down", MD_BLUE)):
        g = e[e["dir"] == d].groupby("tech")["value"].sum().sort_values()
        if len(g):
            fig.add_bar(x=list(g.index), y=list(g.values),
                        name=f"Constrained {'up ↑' if d == 'up' else 'down ↓'}", marker_color=color, marker_line_width=0)
    fig.update_layout(barmode="relative", **_lay(f"Redispatch by technology · {date}", "MWh", 460))
    _grid(fig)
    return fig


def redispatch_kpis(date) -> dict:
    f = _redispatch_facts(date)
    if f is None or f.empty:
        return {}
    e = f[f["measure"] == "energy_mwh"]
    out = {}
    for cat in ("RT_MD", "RTR"):
        c = e[e["category"] == cat]["value"]
        out[f"{cat}_up"] = float(c[c > 0].sum())
        out[f"{cat}_dn"] = float(c[c < 0].sum())
    piv = f.pivot_table(index=["unit", "datetime", "category"], columns="measure", values="value", aggfunc="first")
    if "price_eur_mwh" in piv.columns and "energy_mwh" in piv.columns:
        out["cost"] = float((piv["energy_mwh"].abs() * piv["price_eur_mwh"]).sum(skipna=True))
    else:
        out["cost"] = float("nan")
    return out
