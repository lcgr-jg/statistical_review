"""Layout for the Iberia / OMIE page — light "terminal-rebuilt" analytics.

Unit Explorer: a shared filter/control row + a pinned-period 4-panel stack
(heatmap over many days → drill to one day's intraday/volume/price, with a
synchronized cursor). Bid-offer and Redispatch are simpler standalone tabs.
"""
from __future__ import annotations

import pandas as pd
import dash_bootstrap_components as dbc
from dash import dcc, html

from . import data as D
from .constants import (TABS, DEFAULT_TAB, DEFAULT_DATE, TEXT, HELPER)


def _seg(gid, options, value):
    return dbc.RadioItems(id=gid, options=options, value=value, inline=True, className="iberia-seg")


def _graph(gid, height):
    return dcc.Graph(id=gid, config={"displaylogo": False,
                                     "modeBarButtonsToRemove": ["select2d", "lasso2d"]},
                     style={"height": f"{height}px"})


def _label(text):
    return html.Div(text, className="form-label")


def _panel(title, helper, *children, topright=None):
    head = html.Div(style={"display": "flex", "justifyContent": "space-between", "alignItems": "flex-start"},
                    children=[
                        html.Div([html.Div(title, className="iberia-title"),
                                  html.Div(helper, className="iberia-helper") if helper else None]),
                        html.Div(topright or [], style={"display": "flex", "gap": "10px", "alignItems": "center"}),
                    ])
    return html.Div([head, *children], className="iberia-card")


def _date_bounds():
    """Default to the last available month (fast per-day reads); 'All data' preset
    opens the full span. Returns (default_start, end, all_dates)."""
    dates = D.available_unit_dates()
    if not dates:
        return DEFAULT_DATE, DEFAULT_DATE, []
    last = pd.Timestamp(dates[-1])
    start = max(pd.Timestamp(dates[0]), last.replace(day=1))
    return start.strftime("%Y-%m-%d"), dates[-1], list(dates)


def unit_content():
    start, end, dates = _date_bounds()
    opts = D.unit_options(D.list_units(*D.month_window(end))) if dates else []
    du = opts[0]["value"] if opts else None
    nav_opts = [{"label": d, "value": d} for d in dates]

    control_row = html.Div(className="iberia-controls", children=[
        html.Div([_label("Unit"),
                  dcc.Dropdown(id="ib-unit", options=opts, value=du, clearable=False,
                               style={"width": "260px"})]),
        html.Div([_label("Start"),
                  dcc.DatePickerSingle(id="ib-start", date=start, display_format="MMM DD, YYYY")]),
        html.Div([_label("Presets"),
                  dcc.Dropdown(id="ib-presets", placeholder="Presets…", clearable=True, style={"width": "150px"},
                               options=[{"label": "All data", "value": "all"},
                                        {"label": "This month", "value": "month"},
                                        {"label": "Last 7 days", "value": "d7"},
                                        {"label": "Last 30 days", "value": "d30"}])]),
        html.Div([_label("End"),
                  dcc.DatePickerSingle(id="ib-end", date=end, display_format="MMM DD, YYYY")]),
        html.Button("✕ Clear", id="ib-clear", n_clicks=0, className="btn btn-sm btn-outline-secondary"),
        html.Div(style={"marginLeft": "auto", "display": "flex", "gap": "10px", "alignItems": "center"}, children=[
            html.Span(id="ib-readout", className="iberia-pin", children="— pin a period —"),
            _seg("ib-rep", [{"label": "Map", "value": "map"}, {"label": "Bars", "value": "bars"}], "map"),
            html.Div([_label("Navigator"),
                      dcc.Dropdown(id="ib-nav", options=nav_opts, value=(dates[-1] if dates else None),
                                   clearable=False, style={"width": "150px"})]),
        ]),
    ])

    panel1 = _panel(
        "Days (rows) × QH periods (columns)", "Hover or click a period to pin it.",
        _graph("ib-heatmap", 440), _graph("ib-substrip", 170),
        topright=[
            dcc.Dropdown(id="ib-program", clearable=False, style={"width": "130px"},
                         options=[{"label": "PDBF (P48)", "value": "P48"},
                                  {"label": "PBF", "value": "PBF"},
                                  {"label": "PVP", "value": "PVP"}], value="P48"),
            _seg("ib-measure", [{"label": "€/MWh", "value": "price"}, {"label": "MWh", "value": "mwh"}], "mwh"),
        ])

    panel2 = _panel("Intraday price candles by session (QH)",
                    "OHLC across sessions per QH: open = day-ahead (MD), close = last session, "
                    "range = spread across sessions. Green if it closes above the open.",
                    _graph("ib-candles", 360))
    panel3 = _panel("Volume by category (MWh)",
                    "Signed: positive = scheduled up, negative = down. Hover for detail · drag to zoom.",
                    _graph("ib-volume", 320))
    panel4 = _panel("Unit price by adjustment category (€/MWh)",
                    "Solid = unit matched price (pay-as-bid) · dashed «med» = system average. "
                    "RT = day-ahead constraints · RTR = real-time · Sec/Ter = reserve bands.",
                    _graph("ib-price", 320))

    return html.Div([dcc.Store(id="ib-pin"), control_row, panel1, panel2, panel3, panel4])


def curves_content():
    hours = [{"label": f"{h:02d}:00", "value": h} for h in range(24)]
    controls = html.Div(className="iberia-controls", children=[
        html.Div([_label("Delivery date"),
                  dcc.DatePickerSingle(id="ib-cv-date", date=DEFAULT_DATE, display_format="MMM DD, YYYY")]),
        html.Div([_label("Hour (Madrid)"),
                  dcc.Dropdown(id="ib-cv-hour", options=hours, value=20, clearable=False, style={"width": "120px"})]),
    ])
    return html.Div([controls, _panel("Supply / demand cross",
                                      "OMIE day-ahead offer stack and where the market clears.",
                                      _graph("ib-cross", 520))])


def redispatch_content():
    controls = html.Div(className="iberia-controls", children=[
        html.Div([_label("Delivery date"),
                  dcc.DatePickerSingle(id="ib-rd-date", date=DEFAULT_DATE, display_format="MMM DD, YYYY")]),
    ])
    return html.Div([
        controls,
        html.Div(id="ib-rd-kpis", className="mb-2"),
        _panel("System redispatch volume by QH", "Day-ahead (RT) and real-time (RTR), up/down.",
               _graph("ib-rd-profile", 360)),
        dbc.Row([
            dbc.Col(_panel("Most-redispatched units", "", _graph("ib-rd-top", 460)), lg=6),
            dbc.Col(_panel("Redispatch by technology", "", _graph("ib-rd-tech", 460)), lg=6),
        ], className="g-3"),
    ])


TAB_BUILDERS = {
    "tab-unit": unit_content,
    "tab-curves": curves_content,
    "tab-redispatch": redispatch_content,
}


def build_layout():
    header = html.Div(style={"padding": "18px 24px 0"}, children=[
        html.Div([html.Span("Power  /  ", style={"color": HELPER}),
                  html.Span("Iberia · OMIE", style={"color": TEXT, "fontWeight": 600})],
                 style={"fontSize": "12px"}),
        html.H4("Iberian power · OMIE / ESIOS", style={"color": TEXT, "margin": "4px 0 0"}),
    ])
    tabs = dbc.Tabs(id="iberia-tabs", active_tab=DEFAULT_TAB,
                    children=[dbc.Tab(label=lbl, tab_id=tid) for tid, lbl in TABS],
                    style={"padding": "8px 24px 0"})
    return html.Div(className="iberia-page", style={"minHeight": "100vh", "paddingBottom": "40px"}, children=[
        header, tabs, html.Div(id="iberia-content", style={"padding": "12px 24px 0"}),
    ])
