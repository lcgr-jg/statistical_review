"""Static config for the Iberia / OMIE portal page (import-safe, no data deps)."""
from __future__ import annotations

# ── Page registration ────────────────────────────────────────────────────────
PAGE_PATH = "/power/iberia"
PAGE_NAME = "Iberia / OMIE"
PAGE_TITLE = "Iberia / OMIE | JG Power Dashboard"
PAGE_ORDER = 60

# ── Sub-tabs (Convergence folded into Unit Explorer) ──────────────────────────
TABS: list[tuple[str, str]] = [
    ("tab-unit", "Unit Explorer"),
    ("tab-curves", "Bid-offer & Merit"),
    ("tab-redispatch", "Redispatch"),
]
DEFAULT_TAB = "tab-unit"

# ── Market-category metadata (per-unit decomposition) ─────────────────────────
CATEGORY_LABELS = {
    "PBF": "PBF · base program", "P48": "P48 · final program", "PVP": "PVP · viability",
    "PHF1": "Intraday S1", "PHF2": "Intraday S2", "PHF3": "Intraday S3", "PHFC": "Intraday · continuous",
    "BILATERAL": "Bilateral",
    "RT_MD": "Restrictions · day-ahead", "RTR": "Restrictions · real-time",
    "TERTIARY": "Tertiary (mFRR)", "RR": "Replacement reserve",
    "SECONDARY": "Secondary band", "SECONDARY_E": "Secondary energy",
}
# Short legend labels matching the desk vernacular (MD / S1-3 / RT / RTR / Ter / BT).
CATEGORY_SHORT = {
    "PBF": "PBF", "P48": "MD", "PVP": "PVP",
    "PHF1": "S1", "PHF2": "S2", "PHF3": "S3", "PHFC": "Sc",
    "BILATERAL": "BT",
    "RT_MD": "RT2", "RTR": "RTR", "TERTIARY": "Ter", "RR": "RR",
    "SECONDARY": "Sec", "SECONDARY_E": "SecE",
}
PROGRAM_CATEGORIES = ["PBF", "P48", "PVP", "PHF1", "PHF2", "PHF3", "PHFC", "BILATERAL"]
ADJUSTMENT_CATEGORIES = ["RT_MD", "RTR", "TERTIARY", "RR", "SECONDARY", "SECONDARY_E"]
PRICE_CATEGORIES = ["RT_MD", "RTR", "TERTIARY", "RR"]
VOLUME_ORDER = ["P48", "PBF", "PVP", "PHF1", "PHF2", "PHF3", "PHFC",
                "RT_MD", "RTR", "TERTIARY", "RR", "SECONDARY", "SECONDARY_E", "BILATERAL"]

SESSION_KEYS = ["price_day_ahead", "price_intraday_1", "price_intraday_2", "price_intraday_3"]
SESSION_LABELS = {"price_day_ahead": "MD", "price_intraday_1": "S1",
                  "price_intraday_2": "S2", "price_intraday_3": "S3"}

# ── Palette (keyed off MD blue; consistent across panels) ─────────────────────
MD_BLUE = "#2E6FD6"
TEAL1, TEAL2, TEAL3 = "#17A2B8", "#1592A6", "#0F7C88"
ORANGE = "#E8932A"
RED = "#E2483D"
GREEN = "#2EA85C"
AMBER = "#F5B942"
PURPLE = "#9C36B5"
TEAL_GREEN = "#0CA678"

CATEGORY_COLORS = {
    "PBF": "#6C8AA0", "P48": MD_BLUE, "PVP": "#9AA7B4",
    "PHF1": TEAL1, "PHF2": TEAL2, "PHF3": TEAL3, "PHFC": "#0B6470",
    "BILATERAL": AMBER,
    "RT_MD": ORANGE, "RTR": RED, "TERTIARY": PURPLE, "RR": TEAL_GREEN,
    "SECONDARY": "#2F9E44", "SECONDARY_E": "#37B24D",
}
# Session-price line palette (panels 2/4 ladder + sub-strip).
SESSION_COLORS = {"price_day_ahead": MD_BLUE, "price_intraday_1": TEAL1,
                  "price_intraday_2": TEAL2, "price_intraday_3": TEAL3}
# Redispatch up/down diverging (warm up, cool down).
REDISPATCH_COLORS = {("RT_MD", "up"): "#F0A868", ("RT_MD", "down"): "#74B3D6",
                     ("RTR", "up"): ORANGE, ("RTR", "down"): MD_BLUE}

# ── Visual tokens ─────────────────────────────────────────────────────────────
HEATMAP_SCALE = "Turbo"          # perceptual blue→cyan→green→yellow→orange→red
CANDLE_UP = GREEN
CANDLE_DOWN = RED
CURSOR_RGBA = "rgba(15,23,42,0.08)"   # shared pinned-QH vertical band
TEXT = "#1A1D21"
HELPER = "#8A9099"
GRID = "#EFF1F3"

DEFAULT_DATE = "2025-01-15"
MADRID = "Europe/Madrid"
