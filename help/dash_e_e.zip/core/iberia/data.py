"""Data accessors for the Iberia / OMIE page.

Thin ``lru_cache``-wrapped readers over the jain_commods ``iberia`` adapters
(``IberiaUnits`` / ``OMIECurves`` / ``IberiaPower``) — I90 gold + OMIE curves +
ESIOS/OMIE prices. Adapters are imported lazily so importing this module is cheap.

Per-unit data is on-demand (can't pre-cache ~2,300 units), so we use a process
``lru_cache`` rather than the portal's scheduled ``DashboardCache``. Only
hashable args are passed (str / tuple).

The unit technology/label classifier is a v1 heuristic pending the authoritative
UOF/UP reference scrape.
"""
from __future__ import annotations

import re
from functools import lru_cache

import pandas as pd

from .constants import MADRID, SESSION_KEYS, CATEGORY_LABELS


# ── Lazy adapter handles ─────────────────────────────────────────────────────
def _units():
    from jain_commods.core.cache.data.iberia import IberiaUnits
    return IberiaUnits()


def _power():
    from jain_commods.core.cache.data.iberia import IberiaPower
    return IberiaPower()


def _curves():
    from jain_commods.core.cache.data.iberia import OMIECurves
    return OMIECurves()


def cat_label(cat: str) -> str:
    return CATEGORY_LABELS.get(cat, cat)


# ── Time helpers ─────────────────────────────────────────────────────────────
def to_madrid(idx):
    s = pd.DatetimeIndex(idx)
    if s.tz is None:
        s = s.tz_localize("UTC")
    return s.tz_convert(MADRID)


def month_window(date_str: str):
    d = pd.Timestamp(date_str)
    start = d.replace(day=1).normalize()
    end = start + pd.offsets.MonthBegin(1)
    return start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")


def day_window(date_str: str):
    d = pd.Timestamp(date_str).normalize()
    return d.strftime("%Y-%m-%d"), (d + pd.Timedelta(days=1)).strftime("%Y-%m-%d")


# ── Cached accessors (hashable args only) ────────────────────────────────────
@lru_cache(maxsize=256)
def get_unit_facts(start: str, end: str, unit: str = None,
                   categories: tuple = None, measure: str = None) -> pd.DataFrame:
    cats = list(categories) if categories else None
    return _units().read(start, end, units=unit, categories=cats, measure=measure)


@lru_cache(maxsize=256)
def get_unit_program(unit: str, start: str, end: str) -> pd.DataFrame:
    return _units().get_unit_program(unit, start, end)


@lru_cache(maxsize=256)
def get_unit_prices(unit: str, start: str, end: str) -> pd.DataFrame:
    return _units().get_unit_prices(unit, start, end)


@lru_cache(maxsize=32)
def list_units(start: str, end: str) -> tuple:
    return tuple(_units().list_units(start, end))


@lru_cache(maxsize=64)
def get_day_ahead_price(start: str, end: str, geos: tuple = ("ES",)) -> pd.DataFrame:
    return _power().prices(geos=list(geos), start=start, end=end)


@lru_cache(maxsize=64)
def get_session_prices(start: str, end: str, geo: str = "ES") -> pd.DataFrame:
    px = _power().get(SESSION_KEYS, geos=[geo], start=start, end=end)
    if px is None or px.empty:
        return pd.DataFrame()
    if hasattr(px.columns, "nlevels") and px.columns.nlevels > 1:
        px = px.xs(geo, axis=1, level="geo")
    return px


@lru_cache(maxsize=256)
def get_supply_demand(date: str, hour: int, market: str = "day_ahead") -> dict:
    midnight_utc = pd.Timestamp(date, tz=MADRID).tz_convert("UTC")
    ts = midnight_utc + pd.Timedelta(hours=int(hour))
    return _curves().supply_demand(market, ts)


@lru_cache(maxsize=1)
def available_unit_dates() -> tuple:
    """Delivery dates present in the I90 gold dataset (from S3 keys)."""
    from jain_commods.core.cache.utils.s3 import S3, AWS_BUCKET_NAME
    s3 = S3().get_client()
    rx = re.compile(r"data_date=(\d{4}-\d{2}-\d{2})")
    dates = set()
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=AWS_BUCKET_NAME, Prefix="esios/i90/gold/"):
        for obj in page.get("Contents", []):
            m = rx.search(obj["Key"])
            if m:
                dates.add(m.group(1))
    return tuple(sorted(dates))


# ── Unit technology / label classifier — v1 heuristic ────────────────────────
_NUCLEAR_PREFIX = {"ALM": "Almaraz", "ASC": "Ascó", "COF": "Cofrentes",
                   "TRI": "Trillo", "VAN": "Vandellós", "GAR": "Garoña"}
TECH_ORDER = ["CCGT", "Hydro", "Pumped storage", "Coal", "Nuclear",
              "Wind", "Solar", "Cogeneration", "Other"]


def classify_unit(up: str) -> str:
    if not up or up == "SYSTEM":
        return "Other"
    u = str(up).upper()
    for pfx in _NUCLEAR_PREFIX:
        if u.startswith(pfx):
            return "Nuclear"
    if u.endswith("B") or "BOMBEO" in u:
        return "Pumped storage"
    if u.startswith(("EOL", "PARQ")) or u.endswith("EOL"):
        return "Wind"
    if u.startswith(("FV", "SOL", "SF")):
        return "Solar"
    if u.startswith(("CTG", "CT")) or u.endswith("CC"):
        return "CCGT"
    if u.startswith(("HID", "H")) or u.endswith("H"):
        return "Hydro"
    if u.startswith("COG"):
        return "Cogeneration"
    return "Other"


def unit_label(up: str) -> str:
    if not up:
        return up
    u = str(up).upper()
    for pfx, site in _NUCLEAR_PREFIX.items():
        if u.startswith(pfx):
            return f"{up} · {site} (Nuclear)"
    tech = classify_unit(up)
    return f"{up} · {tech}" if tech != "Other" else str(up)


def unit_options(units) -> list:
    """Dropdown options; flexible techs (CCGT/hydro) first so the default is lively."""
    units = list(units)
    opts = sorted(units, key=lambda u: (TECH_ORDER.index(classify_unit(u))
                                        if classify_unit(u) in TECH_ORDER else 99, u))
    return [{"label": unit_label(u), "value": u} for u in opts]
