"""Qatar / Ras Laffan transforms on raw Kpler LNG trade rows."""
from __future__ import annotations

import pandas as pd

from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table

# Kpler cargo volumes are m3 of LNG (liquid); convert to gas-equivalent mcm
KPLER_M3_TO_MCM = get_conversion_factor("cu m", "mcm", unit_conversion_table)

INSTALLATION = "Ras Laffan"
N_BERTHS = 6


def enrich_loadings_with_vessels(
    loadings: pd.DataFrame,
    vessels: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Left-join vessel attributes onto loadings by IMO.

    Adds ``vessel_type``, ``current_controller``, ``owners``.
    Missing vessels cache / unmatched IMOs leave those columns empty.
    """
    out = loadings.copy()
    for col in ("vessel_type", "current_controller", "owners"):
        if col not in out.columns:
            out[col] = pd.NA

    if vessels is None or vessels.empty or out.empty or "imo" not in out.columns:
        return out

    imo_col = "IMO" if "IMO" in vessels.columns else None
    if imo_col is None:
        return out

    keep = {imo_col: "imo"}
    if "Vessel type" in vessels.columns:
        keep["Vessel type"] = "vessel_type"
    if "Current controller" in vessels.columns:
        keep["Current controller"] = "current_controller"
    if "Owners" in vessels.columns:
        keep["Owners"] = "owners"

    attrs = (
        vessels[list(keep.keys())]
        .rename(columns=keep)
        .assign(imo=lambda d: pd.to_numeric(d["imo"], errors="coerce"))
        .dropna(subset=["imo"])
        .drop_duplicates(subset=["imo"], keep="first")
    )
    out = out.drop(columns=["vessel_type", "current_controller", "owners"], errors="ignore")
    out = out.merge(attrs, on="imo", how="left")
    return out


def get_ras_laffan_loadings(trades: pd.DataFrame) -> pd.DataFrame:
    """
    One row per actual loading (port call) at Ras Laffan from raw Qatar trades,
    sorted by berth arrival.

    Columns: vessel, vessel_id, imo, status, berth_arrival, berth_departure
    (NaT while still loading), volume_m3, volume_mcm, destination,
    canal_transit, dest_arrival, forecasted_eta, eta_destination.
    """
    trades = trades[trades["Installation origin"] == INSTALLATION]
    trades = trades[trades["Trade status"] != "Scheduled"]

    vessel_id = (
        pd.to_numeric(trades["Id (vessel)"], errors="coerce")
        if "Id (vessel)" in trades.columns
        else pd.Series(pd.NA, index=trades.index)
    )
    imo = (
        pd.to_numeric(trades["IMO (vessel)"], errors="coerce")
        if "IMO (vessel)" in trades.columns
        else pd.Series(pd.NA, index=trades.index)
    )
    dest = (
        trades["Country (destination)"]
        if "Country (destination)" in trades.columns
        else pd.Series(pd.NA, index=trades.index)
    )
    canal = (
        trades["Zone Canal Transit"]
        if "Zone Canal Transit" in trades.columns
        else pd.Series(pd.NA, index=trades.index)
    )
    if "Start (destination)" in trades.columns:
        dest_arrival = pd.to_datetime(trades["Start (destination)"], errors="coerce")
    elif "Date (destination)" in trades.columns:
        dest_arrival = pd.to_datetime(trades["Date (destination)"], errors="coerce")
    else:
        dest_arrival = pd.Series(pd.NaT, index=trades.index)

    forecasted_eta = (
        pd.to_datetime(trades["Forecasted ETA"], errors="coerce")
        if "Forecasted ETA" in trades.columns
        else pd.Series(pd.NaT, index=trades.index)
    )
    eta_destination = (
        pd.to_datetime(trades["Eta (destination)"], errors="coerce")
        if "Eta (destination)" in trades.columns
        else pd.Series(pd.NaT, index=trades.index)
    )

    loadings = pd.DataFrame({
        "portcall": trades["Origin PortCall Id"],
        "vessel": trades["Vessel"],
        "vessel_id": vessel_id,
        "imo": imo,
        "status": trades["Trade status"],
        "berth_arrival": pd.to_datetime(trades["Start (origin)"], errors="coerce"),
        "berth_departure": pd.to_datetime(trades["End (origin)"], errors="coerce"),
        "volume_m3": pd.to_numeric(trades["Volume (origin m3)"], errors="coerce"),
        "destination": dest,
        "canal_transit": canal,
        "dest_arrival": dest_arrival,
        "forecasted_eta": forecasted_eta,
        "eta_destination": eta_destination,
    }).dropna(subset=["berth_arrival"])

    loadings = loadings.groupby("portcall", as_index=False).agg({
        "vessel": "first",
        "vessel_id": "first",
        "imo": "first",
        "status": "first",
        "berth_arrival": "first",
        "berth_departure": "first",
        "volume_m3": "sum",
        "destination": "first",
        "canal_transit": "first",
        "dest_arrival": "first",
        "forecasted_eta": "first",
        "eta_destination": "first",
    })
    loadings["volume_mcm"] = loadings["volume_m3"] * KPLER_M3_TO_MCM

    return (
        loadings.drop(columns="portcall")
        .sort_values("berth_arrival")
        .reset_index(drop=True)
    )


def qatar_daily_exports(trades: pd.DataFrame) -> pd.DataFrame:
    """
    Daily Qatar LNG exports (gas-equivalent mcm/d) and cargo counts.

    Scheduled trades excluded; days without a loading filled with zeros.
    Series stops at yesterday (current day incomplete).  ``n_cargoes`` is the
    count of distinct origin port calls that day.
    """
    trades = trades[trades["Trade status"] != "Scheduled"]
    portcall = (
        trades["Origin PortCall Id"]
        if "Origin PortCall Id" in trades.columns
        else pd.Series(trades.index, index=trades.index)
    )
    daily = (
        pd.DataFrame({
            "date": pd.to_datetime(trades["Date (origin)"], errors="coerce").dt.normalize(),
            "value": pd.to_numeric(trades["Volume (origin m3)"], errors="coerce")
            * KPLER_M3_TO_MCM,
            "portcall": portcall,
        })
        .dropna(subset=["date", "value"])
        .groupby("date")
        .agg(value=("value", "sum"), n_cargoes=("portcall", "nunique"))
    )
    yesterday = pd.Timestamp.now().normalize() - pd.Timedelta(days=1)
    if daily.empty:
        return pd.DataFrame({
            "date": pd.DatetimeIndex([]),
            "value": [],
            "n_cargoes": [],
        })
    idx = pd.date_range(daily.index.min(), yesterday, freq="D")
    daily = daily.reindex(idx, fill_value=0)
    return pd.DataFrame({
        "date": daily.index,
        "value": daily["value"].astype(float).values,
        "n_cargoes": daily["n_cargoes"].astype(int).values,
    })


def qatar_weekly_exports(
    daily_exports: pd.DataFrame,
    *,
    since: str | pd.Timestamp | None = None,
) -> pd.DataFrame:
    """
    Weekly Qatar LNG export totals (mcm/week) and cargo counts.

    Weeks are Monday-start (``W-MON``, left-labelled). Optional *since*
    filters to weeks whose Monday is on/after that date.
    """
    empty = pd.DataFrame({
        "week_start": pd.DatetimeIndex([]),
        "value": [],
        "n_cargoes": [],
    })
    if daily_exports is None or daily_exports.empty:
        return empty

    cols = ["value"]
    if "n_cargoes" in daily_exports.columns:
        cols.append("n_cargoes")
    s = (
        daily_exports.set_index("date")[cols]
        .sort_index()
        .astype(float)
    )
    if since is not None:
        s = s.loc[pd.Timestamp(since):]
    if s.empty:
        return empty

    weekly = s.resample("W-MON", label="left", closed="left").sum()
    out = pd.DataFrame({
        "week_start": weekly.index,
        "value": weekly["value"].values,
    })
    if "n_cargoes" in weekly.columns:
        out["n_cargoes"] = weekly["n_cargoes"].round().astype(int).values
    else:
        out["n_cargoes"] = 0
    return out


def qatar_monthly_exports_by_destination(
    trades: pd.DataFrame,
    *,
    since: str | pd.Timestamp | None = None,
    top_n: int = 8,
) -> pd.DataFrame:
    """
    Monthly Qatar LNG export volumes (mcm) stacked by destination country.

    Uses ``Date (origin)`` for the export month and ``Country (destination)``
    for the stack. Scheduled trades are excluded. Destinations outside the
    top *top_n* by total volume in the window are rolled into ``Other``.

    Returns a DataFrame indexed by month-start Timestamp with one column per
    destination (ordered largest→smallest, ``Other`` last if present).
    """
    if trades is None or trades.empty:
        return pd.DataFrame()

    t = trades[trades["Trade status"] != "Scheduled"].copy()
    t["month"] = (
        pd.to_datetime(t["Date (origin)"], errors="coerce")
        .dt.to_period("M")
        .dt.to_timestamp()
    )
    t["volume_mcm"] = (
        pd.to_numeric(t["Volume (origin m3)"], errors="coerce") * KPLER_M3_TO_MCM
    )
    dest_col = "Country (destination)"
    if dest_col not in t.columns:
        return pd.DataFrame()
    t["destination"] = (
        t[dest_col].astype("string").fillna("Unknown").replace({"": "Unknown"})
    )
    # Clean a few verbose Kpler country labels
    t["destination"] = t["destination"].replace({
        "Singapore Republic": "Singapore",
        "Korea, Republic of": "South Korea",
        "United States of America": "United States",
    })
    t = t.dropna(subset=["month", "volume_mcm"])
    if since is not None:
        t = t[t["month"] >= pd.Timestamp(since).to_period("M").to_timestamp()]
    if t.empty:
        return pd.DataFrame()

    totals = t.groupby("destination")["volume_mcm"].sum().sort_values(ascending=False)
    keep = list(totals.head(top_n).index)
    t["destination"] = t["destination"].where(
        t["destination"].isin(keep), other="Other"
    )

    pivot = (
        t.groupby(["month", "destination"])["volume_mcm"]
        .sum()
        .unstack(fill_value=0.0)
    )
    # Column order: top destinations by total, Other last
    ordered = [c for c in keep if c in pivot.columns]
    if "Other" in pivot.columns:
        ordered.append("Other")
    for c in pivot.columns:
        if c not in ordered:
            ordered.append(c)
    return pivot.reindex(columns=ordered)


def build_gap_table(
    loadings: pd.DataFrame,
    since: str | pd.Timestamp,
) -> pd.DataFrame:
    """
    Per-loading berth occupancy / idle-gap table.

    Occupancy and gaps are computed on the full input first, then filtered to
    berth arrivals from ``since``.
    """
    df = loadings.sort_values("berth_arrival").reset_index(drop=True)
    now = pd.Timestamp.now()
    occupied_until = df["berth_departure"].fillna(now)

    prev_departures, idle_gaps, at_berth = [], [], []
    for i, row in df.iterrows():
        arrival = row["berth_arrival"]
        earlier = df.iloc[:i]
        prev_dep = earlier["berth_departure"].max() if i else pd.NaT
        prev_departures.append(prev_dep)
        prev_occupied = occupied_until.iloc[:i].max() if i else pd.NaT
        if pd.isna(prev_occupied):
            idle_gaps.append(float("nan"))
        else:
            gap = (arrival - prev_occupied).total_seconds() / 3600.0
            idle_gaps.append(max(0.0, gap))
        n = ((df["berth_arrival"] <= arrival) & (occupied_until > arrival)).sum()
        at_berth.append(int(n))

    df["hours_at_berth"] = (
        (df["berth_departure"] - df["berth_arrival"]).dt.total_seconds() / 3600.0
    )
    df["prev_departure"] = prev_departures
    df["idle_gap_hours"] = idle_gaps
    df["vessels_at_berth"] = at_berth

    df = df[df["berth_arrival"] >= pd.Timestamp(since)]
    return df.reset_index(drop=True)


def _destination_volume_mcm(trades: pd.DataFrame) -> pd.Series:
    """Gas-equivalent mcm, preferring split destination volume over origin volume."""
    dest_vol = pd.to_numeric(trades.get("Volume (destination m3)"), errors="coerce")
    origin_vol = pd.to_numeric(trades["Volume (origin m3)"], errors="coerce")
    vol_m3 = dest_vol.where(dest_vol.notna() & (dest_vol > 0), origin_vol)
    return vol_m3 * KPLER_M3_TO_MCM


def _active_destination_trades(
    trades: pd.DataFrame,
    destination_country: str,
) -> pd.DataFrame:
    """Non-scheduled rows whose destination country matches exactly."""
    if trades is None or trades.empty:
        return pd.DataFrame()
    dest_col = "Country (destination)"
    if dest_col not in trades.columns or "Volume (origin m3)" not in trades.columns:
        return pd.DataFrame()
    t = trades[trades["Trade status"] != "Scheduled"]
    t = t[t[dest_col].astype("string") == destination_country]
    return t


def monthly_imports_by_destination_arrival(
    trades: pd.DataFrame,
    destination_country: str,
) -> pd.DataFrame:
    """
    Monthly import volumes (mcm) into *destination_country* from Qatar trades,
    dated by destination arrival (``Date (destination)``), not loading date.

    Uses ``Volume (destination m3)`` when present (multi-discharge splits),
    otherwise falls back to ``Volume (origin m3)``. Scheduled trades excluded.

    Columns: ``volume_mcm`` (total), ``delivered_mcm`` (Trade status Delivered),
    ``forecast_mcm`` (still in transit). Indexed by month-start Timestamp.
    """
    empty = pd.DataFrame(columns=["volume_mcm", "delivered_mcm", "forecast_mcm"])
    t = _active_destination_trades(trades, destination_country)
    if t.empty or "Date (destination)" not in t.columns:
        return empty

    month = (
        pd.to_datetime(t["Date (destination)"], errors="coerce")
        .dt.to_period("M")
        .dt.to_timestamp()
    )
    volume = _destination_volume_mcm(t)
    delivered = t["Trade status"].astype("string").str.lower().eq("delivered")
    out = (
        pd.DataFrame({
            "month": month,
            "volume_mcm": volume,
            "delivered_mcm": volume.where(delivered, 0.0),
            "forecast_mcm": volume.where(~delivered, 0.0),
        })
        .dropna(subset=["month", "volume_mcm"])
        .groupby("month")[["volume_mcm", "delivered_mcm", "forecast_mcm"]]
        .sum()
        .sort_index()
    )
    return out


def daily_imports_by_destination_arrival(
    trades: pd.DataFrame,
    destination_country: str,
    *,
    lag_days: float = 0.0,
) -> pd.Series:
    """
    Daily import volumes (mcm) into *destination_country*.

    Dated by destination arrival, then shifted back by *lag_days* (nominal
    steam time) so the bucket sits on the implied loading date. Scheduled
    trades are excluded. Days with no arrival are omitted.
    """
    t = _active_destination_trades(trades, destination_country)
    if t.empty or "Date (destination)" not in t.columns:
        return pd.Series(dtype=float)

    arrival = pd.to_datetime(t["Date (destination)"], errors="coerce")
    aligned = (arrival - pd.Timedelta(days=float(lag_days))).dt.normalize()
    out = (
        pd.DataFrame({"date": aligned, "volume_mcm": _destination_volume_mcm(t)})
        .dropna()
        .groupby("date")["volume_mcm"]
        .sum()
        .sort_index()
    )
    out.name = destination_country
    return out


def daily_unassigned_destination_exports(trades: pd.DataFrame) -> pd.Series:
    """
    Daily origin-date export volume (mcm) with no destination country.

    These are loadings Kpler has not assigned a discharge market (still on
    the water with AIS dark, or not yet matched). Scheduled trades excluded.
    Days with no such cargo are omitted.
    """
    if trades is None or trades.empty or "Date (origin)" not in trades.columns:
        return pd.Series(dtype=float)
    dest_col = "Country (destination)"
    if dest_col not in trades.columns or "Volume (origin m3)" not in trades.columns:
        return pd.Series(dtype=float)

    t = trades[trades["Trade status"] != "Scheduled"]
    dest = t[dest_col].astype("string")
    blank = dest.isna() | dest.str.strip().eq("") | dest.str.lower().isin(
        ["<na>", "nan", "none", "unknown"]
    )
    t = t.loc[blank]
    if t.empty:
        return pd.Series(dtype=float)

    day = pd.to_datetime(t["Date (origin)"], errors="coerce").dt.normalize()
    volume = pd.to_numeric(t["Volume (origin m3)"], errors="coerce") * KPLER_M3_TO_MCM
    out = (
        pd.DataFrame({"date": day, "volume_mcm": volume})
        .dropna()
        .groupby("date")["volume_mcm"]
        .sum()
        .sort_index()
    )
    out.name = "unassigned"
    return out
