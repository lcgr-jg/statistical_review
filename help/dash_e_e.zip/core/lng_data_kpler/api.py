"""Low-level Kpler LNG API client (login + trades / vessels CSV)."""
from __future__ import annotations

import io
import logging
import os

import pandas as pd
import requests

from core.lng_data_kpler.constants import (
    KPLER_EMAIL_ENV,
    KPLER_LNG_BASE_URL,
    KPLER_PASSWORD_ENV,
)

logger = logging.getLogger(__name__)


def kpler_credentials() -> tuple[str, str]:
    email = (os.getenv(KPLER_EMAIL_ENV) or "").strip()
    password = (os.getenv(KPLER_PASSWORD_ENV) or "").strip()
    if not email or not password:
        raise RuntimeError(
            f"Kpler LNG credentials missing. "
            f"Set {KPLER_EMAIL_ENV} and {KPLER_PASSWORD_ENV} in deploy/prod.env "
            f"(or scripts/local.env) before warming the Kpler LNG cache."
        )
    return email, password


def kpler_lng_token(email: str, password: str) -> str:
    """Log in to the Kpler LNG API and return an access token."""
    response = requests.post(
        KPLER_LNG_BASE_URL + "login",
        json={"email": email, "password": password},
        timeout=60,
    )
    response.raise_for_status()
    return response.json()["token"]


def kpler_lng_trades(token: str, **params) -> pd.DataFrame:
    """One Kpler LNG trades query (semicolon-separated CSV) as a DataFrame."""
    response = requests.get(
        KPLER_LNG_BASE_URL + "trades",
        params={"size": 10000, "columns": "all", **params},
        headers={"Authorization": token},
        timeout=120,
    )
    response.raise_for_status()
    return pd.read_csv(io.StringIO(response.text), delimiter=";", low_memory=False)


def kpler_lng_vessels(token: str, **params) -> pd.DataFrame:
    """Kpler LNG vessels snapshot (semicolon-separated CSV) as a DataFrame."""
    response = requests.get(
        KPLER_LNG_BASE_URL + "vessels",
        params={"columns": "all", **params},
        headers={"Authorization": token},
        timeout=120,
    )
    response.raise_for_status()
    return pd.read_csv(io.StringIO(response.text), delimiter=";", low_memory=False)


def fetch_trades(
    *,
    start_date: str,
    from_zones: str,
    email: str | None = None,
    password: str | None = None,
    token: str | None = None,
) -> pd.DataFrame:
    """Fetch Kpler LNG trades for *from_zones* from *start_date*."""
    if token is None:
        if email is None or password is None:
            email, password = kpler_credentials()
        token = kpler_lng_token(email, password)
    logger.info(
        "Kpler LNG trades fetch start_date=%s from_zones=%s",
        start_date,
        from_zones,
    )
    return kpler_lng_trades(token, startDate=start_date, fromZones=from_zones)


def fetch_vessels(
    *,
    email: str | None = None,
    password: str | None = None,
    token: str | None = None,
) -> pd.DataFrame:
    """Fetch the full Kpler LNG vessels snapshot (global fleet)."""
    if token is None:
        if email is None or password is None:
            email, password = kpler_credentials()
        token = kpler_lng_token(email, password)
    logger.info("Kpler LNG vessels fetch columns=all")
    return kpler_lng_vessels(token)
