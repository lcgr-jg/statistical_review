"""Scheduler / freshness knobs for Kpler LNG API cache sources."""
from __future__ import annotations

from typing import Any, Final

from core.constants import TTL_HOUR

# ── Dataset registry ──────────────────────────────────────────────────────
# Extend this dict for additional Kpler LNG pulls.  The cache loader fetches
# every key and nests results under ``datasets``.

KPLER_DATASETS: dict[str, dict[str, Any]] = {
    "qatar_exports": {
        "kind": "trades",
        "description": "Kpler LNG trades loading in Qatar (cargo-level)",
        "from_zones": "Qatar",
        # Long history for Persian Gulf YoY import charts (5Y band needs
        # destination arrivals back to ~2021; buffer loadings from 2020).
        "start_date": "2020-01-01",
    },
    "vessels": {
        "kind": "vessels",
        "description": "Kpler LNG global fleet snapshot (vessel attributes)",
    },
}

# ── Scheduler / cache knobs ───────────────────────────────────────────────
SOURCE_NAME: Final[str] = "lng_data_kpler"
CRON: Final[str] = "0 * * * *"  # hourly
CRON_TIMEZONE: Final[str] = "Europe/London"
TTL_SECONDS: Final[int] = TTL_HOUR

KPLER_EMAIL_ENV: Final[str] = "KPLER_LNG_EMAIL"
KPLER_PASSWORD_ENV: Final[str] = "KPLER_LNG_PASSWORD"

FRESHNESS_SOURCE_NAME: Final[str] = "Kpler LNG"
# Hourly source — stay "fresh" for ~2 h across a missed tick.
FRESHNESS_EXPECTED_MINUTES: Final[int] = 2 * 60

KPLER_LNG_BASE_URL: Final[str] = "https://api-lng.kpler.com/v1/"
QATAR_EXPORTS_KEY: Final[str] = "qatar_exports"
VESSELS_KEY: Final[str] = "vessels"
