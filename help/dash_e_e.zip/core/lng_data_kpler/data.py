"""Kpler LNG fetch helpers for the portal cache."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.cache import dashboard_cache
from core.data_freshness import tracker
from core.lng_data_kpler.api import (
    fetch_trades,
    fetch_vessels,
    kpler_credentials,
    kpler_lng_token,
)
from core.lng_data_kpler.constants import (
    FRESHNESS_EXPECTED_MINUTES,
    FRESHNESS_SOURCE_NAME,
    KPLER_DATASETS,
    SOURCE_NAME,
    VESSELS_KEY,
)

logger = logging.getLogger(__name__)

_loaded_datasets: set[str] = set()


def _register_freshness(
    *,
    state: str | None = None,
    dataset_key: str | None = None,
    records: int | None = None,
    error: str | None = None,
    detail: str | None = None,
) -> None:
    if dataset_key and state is None and error is None:
        _loaded_datasets.add(dataset_key)

    metadata: dict[str, Any] = {}
    if state:
        metadata["state"] = state
    if detail:
        metadata["detail"] = detail
    if error:
        metadata["error"] = error[:200]
        metadata["state"] = "error"
    if _loaded_datasets:
        metadata["datasets"] = ", ".join(sorted(_loaded_datasets))
    if dataset_key:
        metadata["last_dataset"] = dataset_key
    if records is not None:
        metadata["records"] = records

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata=metadata,
    )


def mark_kpler_freshness_pending(detail: str = "waiting for warm-up") -> None:
    """Show Kpler LNG in Data Source Status before the first fetch starts."""
    try:
        cached = dashboard_cache.get(f"source:{SOURCE_NAME}")
        if cached is not None:
            detail = "serving disk cache · refresh in progress"
    except Exception:
        pass
    _register_freshness(state="pending", detail=detail)


def _fetch_dataset(
    dataset_key: str,
    cfg: dict[str, Any],
    *,
    token: str,
) -> dict[str, Any]:
    kind = str(cfg.get("kind") or "trades")
    if kind == "vessels":
        vessels = fetch_vessels(token=token)
        return {
            "description": cfg.get("description", dataset_key),
            "kind": "vessels",
            "vessels": vessels,
            "n_rows": int(len(vessels)),
        }
    if kind == "trades":
        trades = fetch_trades(
            start_date=str(cfg["start_date"]),
            from_zones=str(cfg["from_zones"]),
            token=token,
        )
        return {
            "description": cfg.get("description", dataset_key),
            "kind": "trades",
            "from_zones": cfg["from_zones"],
            "start_date": cfg["start_date"],
            "trades": trades,
            "n_rows": int(len(trades)),
        }
    raise ValueError(f"Unknown Kpler dataset kind '{kind}' for '{dataset_key}'")


def load_lng_data_kpler() -> dict[str, Any]:
    """
    Load every registered Kpler LNG dataset into a cache payload.

    Returns
    -------
    dict
        ``fetched_at``, ``datasets`` keyed by dataset name.  Each dataset
        holds either a trades or vessels DataFrame plus query metadata.
    """
    datasets: dict[str, Any] = {}
    total_rows = 0

    try:
        email, password = kpler_credentials()
        token = kpler_lng_token(email, password)
        for key, cfg in KPLER_DATASETS.items():
            logger.info("Kpler LNG loading dataset=%s kind=%s", key, cfg.get("kind"))
            payload = _fetch_dataset(key, cfg, token=token)
            datasets[key] = payload
            total_rows += int(payload.get("n_rows") or 0)
            _register_freshness(dataset_key=key, records=payload.get("n_rows"))

        fetched_at = datetime.now(timezone.utc).isoformat()
        _register_freshness(
            state="ok",
            records=total_rows,
            detail=f"{len(datasets)} dataset(s)",
        )
        return {
            "fetched_at": fetched_at,
            "datasets": datasets,
        }
    except Exception as exc:
        logger.exception("Kpler LNG load failed: %s", exc)
        _register_freshness(error=str(exc))
        raise


def get_cached_kpler_payload() -> dict[str, Any]:
    """Return the full ``lng_data_kpler`` cache dict (raises if empty)."""
    data: dict[str, Any] | None = dashboard_cache.get_data(SOURCE_NAME)
    if not data or not isinstance(data, dict):
        raise RuntimeError(
            "Kpler LNG cache is empty. "
            "Wait for warm-up to finish, or check KPLER_LNG_EMAIL / "
            "KPLER_LNG_PASSWORD and restart."
        )
    return data


def get_dataset_trades(dataset_key: str) -> pd.DataFrame:
    """Return the raw trades DataFrame for *dataset_key* from the cache."""
    payload = get_cached_kpler_payload()
    datasets = payload.get("datasets") or {}
    ds = datasets.get(dataset_key)
    if not ds or not isinstance(ds, dict):
        raise RuntimeError(
            f"Kpler LNG dataset '{dataset_key}' is missing from the cache."
        )
    trades = ds.get("trades")
    if trades is None or not isinstance(trades, pd.DataFrame):
        raise RuntimeError(
            f"Kpler LNG dataset '{dataset_key}' has no trades DataFrame."
        )
    return trades


def get_dataset_vessels(dataset_key: str = VESSELS_KEY) -> pd.DataFrame:
    """Return the vessels snapshot DataFrame from the cache."""
    payload = get_cached_kpler_payload()
    datasets = payload.get("datasets") or {}
    ds = datasets.get(dataset_key)
    if not ds or not isinstance(ds, dict):
        raise RuntimeError(
            f"Kpler LNG dataset '{dataset_key}' is missing from the cache. "
            "Click 'Refresh from Kpler API' to pull the vessels snapshot."
        )
    vessels = ds.get("vessels")
    if vessels is None or not isinstance(vessels, pd.DataFrame):
        raise RuntimeError(
            f"Kpler LNG dataset '{dataset_key}' has no vessels DataFrame."
        )
    return vessels


def get_kpler_last_refresh(payload: dict[str, Any] | None = None) -> datetime | None:
    """When the Kpler LNG cache was last successfully refreshed."""
    if payload is None:
        try:
            payload = get_cached_kpler_payload()
        except RuntimeError:
            payload = None

    raw = payload.get("fetched_at") if payload else None
    if raw is not None:
        if isinstance(raw, datetime):
            return raw
        try:
            return datetime.fromisoformat(str(raw))
        except ValueError:
            pass

    return dashboard_cache.get_last_refresh(SOURCE_NAME)


def format_kpler_refresh_age(
    when: datetime | None,
    *,
    now: datetime | None = None,
) -> str:
    """Human age string matching Storage Summary / CE style (e.g. ``2h 15m ago``)."""
    if when is None:
        return "Kpler cache time unknown"

    if when.tzinfo is not None:
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        age_min = max(
            0,
            int(
                (
                    now.astimezone(timezone.utc) - when.astimezone(timezone.utc)
                ).total_seconds()
                // 60
            ),
        )
        when_local = when.astimezone()
    else:
        now = now or datetime.now()
        age_min = max(0, int((now - when).total_seconds() // 60))
        when_local = when

    if age_min < 60:
        age_str = f"{age_min}m ago"
    elif age_min < 1440:
        age_str = f"{age_min // 60}h {age_min % 60}m ago"
    else:
        age_str = f"{age_min // 1440}d ago"

    return f"Kpler cache {age_str} ({when_local.strftime('%d-%b %H:%M')})"


def force_refresh_kpler() -> dict[str, Any]:
    """Force an immediate Kpler LNG cache refresh and return the new payload."""
    dashboard_cache.force_refresh(SOURCE_NAME)
    return get_cached_kpler_payload()
