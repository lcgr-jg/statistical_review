"""
Design tokens + a single Plotly template for the whole dashboard.

Why this module exists
----------------------
Before this refactor every page repeated the same ``update_layout`` block
(paper bg, plot bg, font family, gridcolor, hovermode, legend...).  That
made it impossible to retheme the dashboard from one place and bloated
every chart builder.

This module:

1.  Exposes :data:`TOKENS` — a small, semantic dictionary of design
    tokens (colour, spacing, radii, typography).  Only this dict (and the
    legacy :mod:`core.styles` it wraps) should hard-code values.
2.  Builds and registers a Plotly template named ``"dashboard"`` from
    those tokens, and sets it as the **default** template at import time
    so every ``go.Figure`` automatically inherits the look-and-feel.
3.  Exports :data:`PLOTLY_TEMPLATE_NAME` so chart builders that want to
    be explicit can pass ``template=PLOTLY_TEMPLATE_NAME``.

Usage
-----

>>> import core.theme  # noqa: F401  -- side-effect: registers template
>>> # ...all subsequent go.Figure() instances pick it up.

Or explicitly:

>>> from core.theme import PLOTLY_TEMPLATE_NAME
>>> fig.update_layout(template=PLOTLY_TEMPLATE_NAME)

Importing this module is idempotent; calling :func:`apply` again is safe.
"""
from __future__ import annotations

from typing import Final

import plotly.graph_objects as go
import plotly.io as pio

from core.styles import COLORS as _LEGACY_COLORS


# -----------------------------------------------------------------------------
# Design tokens (single source of truth)
# -----------------------------------------------------------------------------
# Colours intentionally match ``core.styles.COLORS`` so existing pages keep
# working until they migrate.  Add new tokens here, not in pages.
TOKENS: Final[dict] = {
    "colors": {
        "page_bg": _LEGACY_COLORS["page_bg"],            # outer page background
        "card_bg": _LEGACY_COLORS["card_bg"],            # cards / containers
        "chart_bg": _LEGACY_COLORS["chart_bg"],          # plot area
        "chart_paper": _LEGACY_COLORS["chart_paper"],    # outside the plot
        "border": _LEGACY_COLORS["border"],
        "border_light": _LEGACY_COLORS["border_light"],
        "text_primary": _LEGACY_COLORS["text_primary"],
        "text_secondary": _LEGACY_COLORS["text_secondary"],
        "text_muted": _LEGACY_COLORS["text_muted"],
        "accent": _LEGACY_COLORS["accent"],
        "accent_dark": _LEGACY_COLORS["accent_dark"],
        "success": _LEGACY_COLORS["success"],
        "warning": _LEGACY_COLORS["warning"],
        "error": _LEGACY_COLORS["error"],
        "info": _LEGACY_COLORS["info"],
        "grid": "#eaeaea",
    },
    "spacing": {
        "xs": "4px",
        "sm": "8px",
        "md": "16px",
        "lg": "24px",
        "xl": "32px",
    },
    "radius": {
        "sm": "4px",
        "md": "6px",
        "lg": "8px",
        "card": "12px",
    },
    "typography": {
        "family": (
            '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
        ),
        "size_xs": 10,
        "size_sm": 11,
        "size_md": 13,
        "size_lg": 16,
    },
}


# -----------------------------------------------------------------------------
# Plotly template registration
# -----------------------------------------------------------------------------
PLOTLY_TEMPLATE_NAME: Final[str] = "dashboard"


def _build_template() -> go.layout.Template:
    """Build the unified Plotly template from :data:`TOKENS`."""
    c = TOKENS["colors"]
    typo = TOKENS["typography"]

    return go.layout.Template(
        layout=go.Layout(
            paper_bgcolor=c["chart_paper"],
            plot_bgcolor=c["chart_bg"],
            font=dict(family=typo["family"], color=c["text_primary"]),
            margin=dict(l=60, r=20, t=50, b=40),
            colorway=[
                c["accent"],
                c["success"],
                c["warning"],
                c["error"],
                c["info"],
                "#9b59b6",
                "#1abc9c",
                "#e74c3c",
            ],
            xaxis=dict(
                gridcolor=c["grid"],
                zerolinecolor=c["grid"],
                tickfont=dict(size=typo["size_sm"], color=c["text_secondary"]),
                showgrid=True,
                zeroline=False,
            ),
            yaxis=dict(
                gridcolor=c["grid"],
                zerolinecolor=c["grid"],
                tickfont=dict(size=typo["size_sm"], color=c["text_secondary"]),
                showgrid=True,
                zeroline=False,
            ),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1,
                font=dict(size=typo["size_sm"], color=c["text_primary"]),
                bgcolor="rgba(255,255,255,0.95)",
            ),
            hoverlabel=dict(
                font=dict(family=typo["family"], size=typo["size_sm"]),
                bgcolor="#ffffff",
                bordercolor=c["border"],
            ),
            hovermode="x unified",
        )
    )


def apply() -> None:
    """Register the template under :data:`PLOTLY_TEMPLATE_NAME` and make it default.

    Idempotent — safe to call multiple times.
    """
    pio.templates[PLOTLY_TEMPLATE_NAME] = _build_template()
    pio.templates.default = PLOTLY_TEMPLATE_NAME


# Register on import so consumers don't need to remember to call ``apply``.
apply()


__all__ = ["TOKENS", "PLOTLY_TEMPLATE_NAME", "apply"]
