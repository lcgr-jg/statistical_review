"""
Dash callbacks for the Heatmap Balance dashboard.

Importing this module registers the callbacks via the global ``@callback``
decorator (same pattern as ``core.fuel_switching.callbacks``).
"""
from __future__ import annotations

import datetime as dt
import hashlib
import io
import logging
from typing import Any, Callable, Dict, List, Tuple

import dash
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, State, callback, dcc, html, no_update
from plotly.subplots import make_subplots

from .constants import DEFAULT_FORWARD_DAYS, DEFAULT_HISTORY_DAYS, HTML_CACHE_MAX
from .data import build_balance_matrix
from .table import BalanceTableGenerator, display_table_for_export

logger = logging.getLogger(__name__)

_table_generator = BalanceTableGenerator()
_HTML_CACHE: Dict[str, str] = {}


def _parse_date(s: str | None, fallback: dt.date) -> dt.date:
    if not s:
        return fallback
    try:
        return dt.datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return fallback


def _primary_and_compare_zones(
    primary: str | None, zone_b: str | None, zone_c: str | None
) -> tuple[str, list[str]]:
    """Primary zone plus up to two distinct compare zones (order: B then C)."""
    z0 = (primary or "FR").strip().upper()
    extras: list[str] = []
    seen: set[str] = {z0}
    for raw in (zone_b, zone_c):
        z = (raw or "").strip().upper()
        if not z or z in seen:
            continue
        seen.add(z)
        extras.append(z)
    return z0, extras


def _mat_fingerprint(mat: pd.DataFrame) -> str:
    if mat is None or mat.empty:
        return "empty"
    return hashlib.md5(pd.util.hash_pandas_object(mat, index=True).values.tobytes()).hexdigest()[:16]


def _cached_html(cache_key: str, factory: Callable[[], str]) -> str:
    if cache_key in _HTML_CACHE:
        return _HTML_CACHE[cache_key]
    html_str = factory()
    if len(_HTML_CACHE) >= HTML_CACHE_MAX:
        _HTML_CACHE.pop(next(iter(_HTML_CACHE)))
    _HTML_CACHE[cache_key] = html_str
    return html_str


def _build_iframe(table_html: str) -> html.Iframe:
    return html.Iframe(
        srcDoc=table_html,
        style={
            "width": "100%",
            "height": "calc(100vh - 220px)",
            "minHeight": "560px",
            "border": "1px solid #dee2e6",
            "borderRadius": "4px",
            "backgroundColor": "white",
        },
        sandbox="allow-same-origin",
    )


@callback(
    Output("hb-range", "data"),
    Input("hb-zone", "value"),
    Input("hb-issue", "date"),
    Input("hb-zone-b", "value"),
    Input("hb-zone-c", "value"),
    Input("hb-hist", "value"),
    Input("hb-fwd", "value"),
    State("hb-range", "data"),
    prevent_initial_call=False,
)
def _commit_window_range(_z, _issue, _zb, _zc, hist, fwd, cur):
    """Update hb-range store whenever any control changes."""
    hist_i = int(hist) if hist is not None else DEFAULT_HISTORY_DAYS
    fwd_i = int(fwd) if fwd is not None else DEFAULT_FORWARD_DAYS
    if not dash.callback_context.triggered:
        return cur if isinstance(cur, dict) else {"hist": hist_i, "fwd": fwd_i}
    return {"hist": hist_i, "fwd": fwd_i}


@callback(
    Output("hb-table-container", "children"),
    Output("hb-meta", "children"),
    Output("hb-alert-row", "children"),
    Output("hb-cache-scope", "data"),
    Input("hb-range", "data"),
    Input("hb-zone", "value"),
    Input("hb-issue", "date"),
    Input("hb-compare", "date"),
    Input("hb-zone-b", "value"),
    Input("hb-zone-c", "value"),
)
def _update(range_data, zone, issue_s, compare_s, zone_b, zone_c):
    zone, compare_list = _primary_and_compare_zones(zone, zone_b, zone_c)

    issue_d = _parse_date(issue_s, dt.date.today())
    split_d = issue_d  # split is always the same as forecast issue date

    # Parse optional comparison date — when set, switch to Δ-mode
    compare_d: dt.date | None = None
    if compare_s:
        try:
            compare_d = dt.datetime.strptime(compare_s, "%Y-%m-%d").date()
        except Exception:
            pass
    delta_mode = compare_d is not None and compare_d != issue_d

    rd = range_data if isinstance(range_data, dict) else {}
    hist_days = int(rd.get("hist", DEFAULT_HISTORY_DAYS))
    fwd_days = int(rd.get("fwd", DEFAULT_FORWARD_DAYS))

    cal_today = dt.date.today()
    meta_line = ""

    alerts: list = []
    days_behind = (cal_today - split_d).days
    if days_behind > 60 and hist_days < 28:
        alerts.append(
            dbc.Alert(
                "Split D is far in the past and the history window is short — most of the grid is forward ST; "
                "the calendar-today rule still applies for today and future delivery rows.",
                color="warning",
                className="py-2 mb-2",
            )
        )

    scope_payload: Dict[str, Any] = {
        "delivery_start": (split_d - dt.timedelta(days=hist_days)).isoformat(),
        "delivery_end": (split_d + dt.timedelta(days=fwd_days)).isoformat(),
        "forecast_issue": issue_d.isoformat(),
        "compare_date": compare_d.isoformat() if compare_d else None,
        "split_d": split_d.isoformat(),
        "hist_days": hist_days,
        "fwd_days": fwd_days,
        "cached": "server_wide_frames",
    }

    alert_children: Any = alerts if alerts else html.Span("", style={"display": "none"})

    def _one_table(z: str) -> Tuple[pd.DataFrame, Dict[str, Any], str]:
        try:
            mat, meta = build_balance_matrix(
                z,
                history_days=hist_days,
                forward_days=fwd_days,
                split_date=split_d,
                issue_date=issue_d,
            )
        except Exception as e:
            logger.exception("heatmap balance build failed")
            raise e
        fp = _mat_fingerprint(mat)
        cache_key = f"{z}|{split_d}|{issue_d}|{hist_days}|{fwd_days}|{fp}"
        table_html = _cached_html(
            cache_key,
            lambda m=mat: _table_generator.generate(
                m,
                zone=z,
                split_date=split_d,
                issue_date=issue_d,
                hist_days=hist_days,
                fwd_days=fwd_days,
            ),
        )
        return mat, meta, table_html

    def _one_delta_table(z: str) -> Tuple[pd.DataFrame, Dict[str, Any], str]:
        """Build Δ table: mat(issue_d) − mat(compare_d) for fundamentals only."""
        try:
            mat_issue, _ = build_balance_matrix(
                z,
                history_days=hist_days,
                forward_days=fwd_days,
                split_date=split_d,
                issue_date=issue_d,
            )
        except Exception as e:
            logger.exception("heatmap balance build failed for issue date")
            raise e
        try:
            mat_compare, _ = build_balance_matrix(
                z,
                history_days=hist_days,
                forward_days=fwd_days,
                split_date=compare_d,
                issue_date=compare_d,
            )
        except Exception as e:
            logger.exception("heatmap balance build failed for compare date")
            raise e

        fp = _mat_fingerprint(mat_issue) + _mat_fingerprint(mat_compare)
        cache_key = f"delta|{z}|{issue_d}|{compare_d}|{hist_days}|{fwd_days}|{fp}"
        table_html = _cached_html(
            cache_key,
            lambda mi=mat_issue, mc=mat_compare: _table_generator.generate_delta(
                mi,
                mc,
                zone=z,
                issue_date=issue_d,
                compare_date=compare_d,
                hist_days=hist_days,
                fwd_days=fwd_days,
            ),
        )
        return mat_issue, {}, table_html

    table_fn = _one_delta_table if delta_mode else _one_table

    try:
        mat_a, _meta_a, html_a = table_fn(zone)
    except Exception as e:
        return (
            html.Div(
                style={"padding": "40px", "textAlign": "center"},
                children=[
                    html.H3("Error loading balance matrix", style={"color": "#e74c3c"}),
                    html.Pre(
                        str(e),
                        style={
                            "backgroundColor": "#f8f9fa",
                            "padding": "15px",
                            "borderRadius": "6px",
                            "fontSize": "13px",
                            "whiteSpace": "pre-wrap",
                            "textAlign": "left",
                            "maxWidth": "720px",
                            "margin": "16px auto",
                        },
                    ),
                ],
            ),
            f"Error: {e}",
            alert_children,
            no_update,
        )

    primary = _build_iframe(html_a)

    if not compare_list:
        return (
            primary,
            meta_line,
            alert_children,
            scope_payload,
        )

    panes: List[Any] = [
        html.Div(
            style={"flex": "1 1 300px", "minWidth": "260px"},
            children=[
                html.Div(f"{zone}", style={"fontSize": "12px", "fontWeight": "600", "marginBottom": "4px"}),
                primary,
            ],
        )
    ]
    for z_cmp in compare_list:
        try:
            _mat_i, _meta_i, html_i = table_fn(z_cmp)
            panes.append(
                html.Div(
                    style={"flex": "1 1 300px", "minWidth": "260px"},
                    children=[
                        html.Div(f"{z_cmp}", style={"fontSize": "12px", "fontWeight": "600", "marginBottom": "4px"}),
                        _build_iframe(html_i),
                    ],
                )
            )
        except Exception as e:
            panes.append(
                html.Div(
                    style={"flex": "1 1 300px", "minWidth": "260px"},
                    children=[
                        html.Div(f"{z_cmp}", style={"fontSize": "12px", "fontWeight": "600", "marginBottom": "4px"}),
                        html.P(f"Compare zone error: {e}", style={"color": "#c0392b", "fontSize": "13px"}),
                    ],
                )
            )

    compare_block = html.Div(
        style={
            "display": "flex",
            "flexWrap": "wrap",
            "gap": "12px",
            "alignItems": "stretch",
        },
        children=panes,
    )

    return compare_block, meta_line, alert_children, scope_payload


def _excel_display_tables_bytes(
    zones: list[str],
    split_d: dt.date,
    issue_d: dt.date,
    hist_days: int,
    fwd_days: int,
) -> bytes:
    buf = io.BytesIO()
    used_sheet_names: set[str] = set()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for z in zones:
            mat, _ = build_balance_matrix(
                z,
                history_days=hist_days,
                forward_days=fwd_days,
                split_date=split_d,
                issue_date=issue_d,
            )
            df = display_table_for_export(mat)
            sheet = str(z)[:31]
            base = sheet
            n = 1
            while sheet in used_sheet_names:
                suffix = f"_{n}"
                sheet = f"{base[:31 - len(suffix)]}{suffix}"[:31]
                n += 1
            used_sheet_names.add(sheet)
            df.to_excel(writer, sheet_name=sheet, index=True, merge_cells=True)
    buf.seek(0)
    return buf.read()


@callback(
    Output("hb-download", "data"),
    Input("hb-download-xlsx", "n_clicks"),
    State("hb-zone", "value"),
    State("hb-zone-b", "value"),
    State("hb-zone-c", "value"),
    State("hb-issue", "date"),
    State("hb-range", "data"),
    prevent_initial_call=True,
)
def _download_excel(_n, zone, zone_b, zone_c, issue_s, range_data):
    ctx = dash.callback_context
    if not ctx.triggered:
        return no_update
    z0, extras = _primary_and_compare_zones(zone, zone_b, zone_c)
    zones_export = [z0] + extras
    issue_d = _parse_date(issue_s, dt.date.today())
    split_d = issue_d
    rd = range_data if isinstance(range_data, dict) else {}
    hist_days = int(rd.get("hist", DEFAULT_HISTORY_DAYS))
    fwd_days = int(rd.get("fwd", DEFAULT_FORWARD_DAYS))

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")

    try:
        raw = _excel_display_tables_bytes(zones_export, split_d, issue_d, hist_days, fwd_days)
        return dcc.send_bytes(raw, filename=f"heatmap_balance_{stamp}.xlsx")
    except Exception as e:
        logger.exception("heatmap balance Excel export failed: %s", e)
        return no_update


# ── Region tab ─────────────────────────────────────────────────────────────
@callback(
    Output("hb-region-container", "children"),
    Input("hb-tabs", "active_tab"),
    Input("hb-region-zones", "value"),
    Input("hb-issue", "date"),
    Input("hb-range", "data"),
)
def _update_region(active_tab, zones_selected, issue_s, range_data):
    """Render the region-aggregated table for the user-chosen zones."""
    if active_tab != "tab-region":
        return no_update

    if not zones_selected:
        return html.Div(
            "Select at least one zone above to build the region view.",
            style={"padding": "20px", "color": "#888"},
        )

    # Normalize + dedupe zone codes while preserving user order
    seen: set[str] = set()
    zones: list[str] = []
    for raw in zones_selected:
        z = (raw or "").strip().upper()
        if not z or z in seen:
            continue
        seen.add(z)
        zones.append(z)
    if not zones:
        return html.Div(
            "Select at least one zone above to build the region view.",
            style={"padding": "20px", "color": "#888"},
        )

    issue_d = _parse_date(issue_s, dt.date.today())
    split_d = issue_d
    rd = range_data if isinstance(range_data, dict) else {}
    hist_days = int(rd.get("hist", DEFAULT_HISTORY_DAYS))
    fwd_days = int(rd.get("fwd", DEFAULT_FORWARD_DAYS))

    mats: Dict[str, pd.DataFrame] = {}
    errors: list[tuple[str, str]] = []
    for z in zones:
        try:
            mat, _meta = build_balance_matrix(
                z,
                history_days=hist_days,
                forward_days=fwd_days,
                split_date=split_d,
                issue_date=issue_d,
            )
            mats[z] = mat
        except Exception as e:
            logger.exception("region build failed for %s", z)
            errors.append((z, str(e)))

    if not mats:
        msg = "Failed to build balance matrices for any selected zone."
        if errors:
            msg += " " + "; ".join(f"{z}: {err}" for z, err in errors)
        return html.Div(msg, style={"padding": "20px", "color": "#c0392b"})

    # Cache key: zones + issue + window + per-zone matrix fingerprints
    fp = "|".join(f"{z}:{_mat_fingerprint(m)}" for z, m in mats.items())
    cache_key = f"region|{','.join(mats.keys())}|{issue_d}|{hist_days}|{fwd_days}|{fp}"

    table_html = _cached_html(
        cache_key,
        lambda mz=mats: _table_generator.generate_region(
            mz,
            issue_date=issue_d,
            hist_days=hist_days,
            fwd_days=fwd_days,
        ),
    )

    children: List[Any] = [_build_iframe(table_html)]
    if errors:
        children.append(
            html.Div(
                [html.Div(f"Note: skipped {z} ({err})") for z, err in errors],
                style={
                    "marginTop": "8px",
                    "fontSize": "11px",
                    "color": "#a64b00",
                    "fontFamily": "monospace",
                },
            )
        )
    return children


# ── Graphs tab ─────────────────────────────────────────────────────────────
def _subplot_refs(row: int) -> tuple[str, str]:
    """Get (xref, yref) for shapes in row-th subplot when using secondary_y=True per row.

    With ``specs=[[{'secondary_y': True}], ...]`` plotly assigns axes
    row 1 → (x, y, y2)   row 2 → (x2, y3, y4)   row 3 → (x3, y5, y6) ...
    We anchor shapes to the LEFT (primary) yaxis of each row using ``y domain``.
    """
    xref = "x" if row == 1 else f"x{row}"
    primary_y_index = 1 + 2 * (row - 1)
    yref = "y domain" if primary_y_index == 1 else f"y{primary_y_index} domain"
    return xref, yref


def _add_weekend_shading(fig: go.Figure, dates: pd.DatetimeIndex, row: int, col: int) -> None:
    if dates is None or len(dates) == 0:
        return
    xref, yref = _subplot_refs(row)
    for d in dates:
        if d.weekday() >= 5:  # 5=Sat, 6=Sun
            fig.add_shape(
                type="rect",
                xref=xref, yref=yref,
                x0=d - pd.Timedelta(hours=12),
                x1=d + pd.Timedelta(hours=12),
                y0=0, y1=1,
                fillcolor="rgba(120,120,120,0.18)",
                line=dict(width=0),
                layer="below",
            )


def _add_today_marker(fig: go.Figure, today: dt.date, row: int, col: int) -> None:
    xref, yref = _subplot_refs(row)
    fig.add_shape(
        type="line",
        xref=xref, yref=yref,
        x0=pd.Timestamp(today), x1=pd.Timestamp(today),
        y0=0, y1=1,
        line=dict(color="#444", width=1.5, dash="dash"),
        layer="above",
    )


@callback(
    Output("hb-graphs-container", "children"),
    Input("hb-tabs", "active_tab"),
    Input("hb-graph-var-a", "value"),
    Input("hb-graph-var-b", "value"),
    Input("hb-zone", "value"),
    Input("hb-zone-b", "value"),
    Input("hb-zone-c", "value"),
    Input("hb-issue", "date"),
    Input("hb-range", "data"),
)
def _update_graphs(active_tab, var_a, var_b, zone, zone_b, zone_c, issue_s, range_data):
    if active_tab != "tab-graphs":
        return no_update
    if not var_a or not var_b:
        return html.Div("Select two variables.", style={"padding": "20px", "color": "#888"})

    z0, extras = _primary_and_compare_zones(zone, zone_b, zone_c)
    zones = [z0] + extras
    issue_d = _parse_date(issue_s, dt.date.today())
    rd = range_data if isinstance(range_data, dict) else {}
    hist_days = int(rd.get("hist", DEFAULT_HISTORY_DAYS))
    fwd_days = int(rd.get("fwd", DEFAULT_FORWARD_DAYS))
    today = dt.date.today()

    n = len(zones)
    fig = make_subplots(
        rows=n,
        cols=1,
        shared_xaxes=True,
        subplot_titles=[f"{z}" for z in zones],
        vertical_spacing=0.08 if n > 1 else 0.0,
        specs=[[{"secondary_y": True}] for _ in zones],
    )

    color_a = "#1f77b4"  # blue
    color_b = "#d62728"  # red

    for i, z in enumerate(zones, start=1):
        try:
            mat, _meta = build_balance_matrix(
                z,
                history_days=hist_days,
                forward_days=fwd_days,
                split_date=issue_d,
                issue_date=issue_d,
            )
        except Exception as e:
            logger.exception("graphs build failed for %s", z)
            fig.add_annotation(
                text=f"Error loading {z}: {e}",
                xref=f"x{i}", yref=f"y{i}",
                showarrow=False, row=i, col=1,
            )
            continue

        if mat.empty or var_a not in mat.index or var_b not in mat.index:
            continue

        dates = pd.to_datetime(mat.columns)
        sa = pd.to_numeric(mat.loc[var_a], errors="coerce")
        sb = pd.to_numeric(mat.loc[var_b], errors="coerce")

        _add_weekend_shading(fig, dates, row=i, col=1)
        _add_today_marker(fig, today, row=i, col=1)

        fig.add_trace(
            go.Scatter(
                x=dates, y=sa.values, name=var_a,
                line=dict(color=color_a, width=2),
                mode="lines+markers", marker=dict(size=4),
                showlegend=(i == 1),
                legendgroup=var_a,
            ),
            row=i, col=1, secondary_y=False,
        )
        fig.add_trace(
            go.Scatter(
                x=dates, y=sb.values, name=var_b,
                line=dict(color=color_b, width=2, dash="dot"),
                mode="lines+markers", marker=dict(size=4),
                showlegend=(i == 1),
                legendgroup=var_b,
            ),
            row=i, col=1, secondary_y=True,
        )

        fig.update_yaxes(title_text=var_a, row=i, col=1, secondary_y=False, color=color_a)
        fig.update_yaxes(title_text=var_b, row=i, col=1, secondary_y=True, color=color_b)

    fig.update_layout(
        height=320 * n,
        margin=dict(l=60, r=60, t=50, b=40),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        plot_bgcolor="white",
    )
    fig.update_xaxes(showgrid=True, gridcolor="rgba(200,200,200,0.3)")

    return dcc.Graph(figure=fig, config={"displaylogo": False})
