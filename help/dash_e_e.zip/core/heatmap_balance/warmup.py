"""
Warm-up loader for the Heatmap Balance dashboard.

Registered with ``core.cache.dashboard_cache`` from ``portal_app._setup_scheduler``
so the first user visit hits warm wide-frame caches inside
``pages.heatmap_balance_data`` (spot bundles, forward bundles, ST/backcast
zonal frames). Mirrors the pattern used by ``pages.fuel_switching`` and
``pages.fundamentals``.

Each scheduled or parallel warm-up call clears those in-process frame caches
first so ``build_balance_matrix`` re-reads market and fundamentals from S3
instead of reusing LRU slices for hours.
"""
from __future__ import annotations

import datetime as dt
import logging
from typing import Any, Dict, List

from .constants import DEFAULT_FORWARD_DAYS, DEFAULT_HISTORY_DAYS, WARM_ZONES
from .data import build_balance_matrix, clear_heatmap_balance_data_cache

logger = logging.getLogger(__name__)


def load_heatmap_balance_data(
    zones: List[str] | None = None,
    history_days: int = DEFAULT_HISTORY_DAYS,
    forward_days: int = DEFAULT_FORWARD_DAYS,
    split_date: dt.date | None = None,
    issue_date: dt.date | None = None,
) -> Dict[str, Any]:
    """
    Pre-build balance matrices for the most-used zones so the first user
    visit reuses the wide-frame caches inside ``heatmap_balance_data``.

    At entry, clears in-process S3-backed wide-frame caches so this run (and
    thus each dashboard-cache refresh) always reloads from S3 before filling
    those caches again.

    Returns a small status payload (sizes / errors). Heavy frames live in
    the per-module ``OrderedDict`` caches, not here, so this stays small
    enough to satisfy ``dashboard_cache.get(...)`` non-None checks.
    """
    clear_heatmap_balance_data_cache()
    logger.info("heatmap_balance: cleared wide-frame caches before warm-up")

    zones = list(zones or WARM_ZONES)
    split_date = split_date or dt.date.today()
    issue_date = issue_date or split_date

    results: Dict[str, Dict[str, Any]] = {}
    for z in zones:
        try:
            mat, meta = build_balance_matrix(
                z,
                history_days=history_days,
                forward_days=forward_days,
                split_date=split_date,
                issue_date=issue_date,
            )
            results[z] = {
                "rows": int(mat.shape[0]) if mat is not None else 0,
                "cols": int(mat.shape[1]) if mat is not None else 0,
                "split_date": meta.get("split_date"),
                "issue_date": meta.get("issue_date"),
                "forward_curve_trade_date": meta.get("forward_curve_trade_date"),
            }
        except Exception as exc:
            logger.warning("heatmap_balance warm-up failed for %s: %s", z, exc)
            results[z] = {"error": str(exc)}

    return {
        "warmed_at": dt.datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "zones": results,
        "history_days": history_days,
        "forward_days": forward_days,
    }
