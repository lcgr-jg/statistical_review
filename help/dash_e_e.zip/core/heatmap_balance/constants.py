"""Static configuration for the Heatmap Balance dashboard."""
from __future__ import annotations

PAGE_PATH = "/power/heatmap_balance"
PAGE_NAME = "Heatmap Balance"
PAGE_TITLE = "Heatmap Balance | JG Power Dashboard"
PAGE_ORDER = 18

ZONE_OPTIONS = [
    {"label": "DE", "value": "DE"},
    {"label": "FR", "value": "FR"},
    {"label": "NL", "value": "NL"},
    {"label": "BE", "value": "BE"},
    {"label": "AT", "value": "AT"},
    {"label": "CH", "value": "CH"},
    {"label": "IT", "value": "IT"},
    {"label": "ES", "value": "ES"},
    {"label": "UK", "value": "UK"},
    {"label": "HU", "value": "HU"},
    {"label": "RO", "value": "RO"},
    {"label": "BG", "value": "BG"},
]

COMPARE_ZONE_OPTIONS = [{"label": "— none —", "value": ""}] + ZONE_OPTIONS

DEFAULT_HISTORY_DAYS = 21
DEFAULT_FORWARD_DAYS = 15
HISTORY_SLIDER_MIN = 7
HISTORY_SLIDER_MAX = 180
FORWARD_SLIDER_MIN = 7
FORWARD_SLIDER_MAX = 45

HTML_CACHE_MAX = 48

WARM_ZONES = ["FR", "DE", "NL", "BE", "UK"]
