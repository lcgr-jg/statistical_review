"""Layout for the Heatmap Balance dashboard (pure, no callbacks)."""
from __future__ import annotations

import datetime as dt

import dash_bootstrap_components as dbc
from dash import dcc, html

from core.styles import COLORS

from .constants import (
    COMPARE_ZONE_OPTIONS,
    DEFAULT_FORWARD_DAYS,
    DEFAULT_HISTORY_DAYS,
    FORWARD_SLIDER_MAX,
    FORWARD_SLIDER_MIN,
    HISTORY_SLIDER_MAX,
    HISTORY_SLIDER_MIN,
    ZONE_OPTIONS,
)

# All metric rows produced by build_balance_matrix (kept in sync with
# PRICE_ROWS + FUND_ROWS in heatmap_balance_data.py).
ALL_METRICS = [
    "Spot", "CSS", "CDS", "Heat rate", "TTF", "EUA",
    "ResL", "ResL - Nuke", "ResL - Nuke - Hyd", "Consumption",
    "Solar", "Wind", "Hydro total", "Nuclear",
    "Coal gen", "Lignite gen", "Gas gen", "Net Export",
]
METRIC_OPTIONS = [{"label": m, "value": m} for m in ALL_METRICS]


# ── Reusable styles for the top control bar ──────────────────────────────────
_LABEL_STYLE = {
    "fontSize": "11px",
    "fontWeight": "600",
    "color": "#6c757d",
    "textTransform": "uppercase",
    "letterSpacing": "0.3px",
    "marginBottom": "4px",
    "display": "block",
    "whiteSpace": "nowrap",
}

_FIELD_STYLE = {
    "display": "flex",
    "flexDirection": "column",
}

_GROUP_STYLE = {
    "display": "flex",
    "gap": "16px",
    "alignItems": "flex-start",
    "padding": "8px 14px",
    "border": "1px solid #e5e7eb",
    "borderRadius": "6px",
    "backgroundColor": "#fafbfc",
}

_SELECT_STYLE = {"width": "130px", "fontSize": "13px"}


def _field(label: str, control) -> html.Div:
    """A label + control pair stacked vertically with consistent spacing."""
    return html.Div(
        [html.Label(label, style=_LABEL_STYLE), control],
        style=_FIELD_STYLE,
    )


def _build_control_bar(today: dt.date) -> html.Div:
    """Top control bar — grouped into Zones · Dates · Window · Export."""
    zones_group = html.Div(
        [
            _field(
                "Zone",
                dbc.Select(
                    id="hb-zone",
                    options=ZONE_OPTIONS,
                    value="FR",
                    persistence=True,
                    persistence_type="local",
                    style=_SELECT_STYLE,
                ),
            ),
            _field(
                "Compare zone 1",
                dbc.Select(
                    id="hb-zone-b",
                    options=COMPARE_ZONE_OPTIONS,
                    value="",
                    persistence=True,
                    persistence_type="local",
                    style=_SELECT_STYLE,
                ),
            ),
            _field(
                "Compare zone 2",
                dbc.Select(
                    id="hb-zone-c",
                    options=COMPARE_ZONE_OPTIONS,
                    value="",
                    persistence=True,
                    persistence_type="local",
                    style=_SELECT_STYLE,
                ),
            ),
        ],
        style=_GROUP_STYLE,
    )

    dates_group = html.Div(
        [
            _field(
                "Forecast issue date",
                dcc.DatePickerSingle(
                    id="hb-issue",
                    date=today,
                    display_format="YYYY-MM-DD",
                    first_day_of_week=1,
                    persistence=True,
                    persistence_type="local",
                ),
            ),
            _field(
                "Compare date (Δ mode)",
                dcc.DatePickerSingle(
                    id="hb-compare",
                    date=None,
                    display_format="YYYY-MM-DD",
                    first_day_of_week=1,
                    clearable=True,
                    placeholder="None",
                    persistence=True,
                    persistence_type="local",
                ),
            ),
        ],
        style=_GROUP_STYLE,
    )

    window_group = html.Div(
        [
            _field(
                "History days",
                html.Div(
                    dcc.Slider(
                        id="hb-hist",
                        min=HISTORY_SLIDER_MIN,
                        max=HISTORY_SLIDER_MAX,
                        step=1,
                        value=DEFAULT_HISTORY_DAYS,
                        marks=None,
                        persistence=True,
                        persistence_type="local",
                        tooltip={"placement": "bottom", "always_visible": False},
                    ),
                    style={"width": "220px"},
                ),
            ),
            _field(
                "Forward days",
                html.Div(
                    dcc.Slider(
                        id="hb-fwd",
                        min=FORWARD_SLIDER_MIN,
                        max=FORWARD_SLIDER_MAX,
                        step=1,
                        value=DEFAULT_FORWARD_DAYS,
                        marks=None,
                        persistence=True,
                        persistence_type="local",
                        tooltip={"placement": "bottom", "always_visible": False},
                    ),
                    style={"width": "220px"},
                ),
            ),
        ],
        style={**_GROUP_STYLE, "minWidth": "500px"},
    )

    export_group = html.Div(
        [
            _field(
                "Export",
                dbc.Button(
                    "Download Excel",
                    id="hb-download-xlsx",
                    color="outline-secondary",
                    size="sm",
                    title="Spreadsheet in the same layout as the table (dates as rows, Price | Fundamental columns).",
                ),
            ),
        ],
        style=_GROUP_STYLE,
    )

    return html.Div(
        [zones_group, dates_group, window_group, export_group],
        style={
            "display": "flex",
            "flexWrap": "wrap",
            "gap": "12px",
            "alignItems": "stretch",
        },
    )


def build_layout() -> html.Div:
    today = dt.date.today()
    return html.Div(
        style={"backgroundColor": COLORS["background"], "minHeight": "100vh"},
        children=[
            html.Div(
                style={
                    "padding": "16px 22px",
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "backgroundColor": COLORS["card_bg"],
                },
                children=[
                    html.Div(
                        [
                            html.Span("Power", style={"color": "#888", "fontSize": "13px"}),
                            html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                            html.Span(
                                "Heatmap Balance",
                                style={"fontWeight": "600", "color": COLORS["text_primary"]},
                            ),
                        ],
                        style={"marginBottom": "14px"},
                    ),
                    _build_control_bar(today),
                    dcc.Markdown(
                        id="hb-meta",
                        style={"marginTop": "12px", "fontSize": "12px", "color": COLORS["text_secondary"]},
                    ),
                    html.Div(id="hb-alert-row", style={"marginTop": "8px", "maxWidth": "960px"}),
                    dcc.Store(
                        id="hb-range",
                        data={"hist": DEFAULT_HISTORY_DAYS, "fwd": DEFAULT_FORWARD_DAYS},
                        storage_type="local",
                    ),
                    dcc.Store(
                        id="hb-cache-scope",
                        data=None,
                    ),
                    dcc.Download(id="hb-download"),
                ],
            ),
            dbc.Tabs(
                id="hb-tabs",
                active_tab="tab-tables",
                style={"padding": "0 16px", "marginTop": "8px"},
                children=[
                    dbc.Tab(
                        label="Zone",
                        tab_id="tab-tables",
                        children=dcc.Loading(
                            type="circle",
                            color=COLORS["accent"],
                            children=html.Div(
                                id="hb-table-container",
                                style={"padding": "8px 16px 16px"},
                            ),
                        ),
                    ),
                    dbc.Tab(
                        label="Region",
                        tab_id="tab-region",
                        children=html.Div(
                            style={"padding": "12px 16px"},
                            children=[
                                html.Div(
                                    [
                                        html.Label(
                                            "Region zones (multi-select)",
                                            style=_LABEL_STYLE,
                                        ),
                                        dcc.Dropdown(
                                            id="hb-region-zones",
                                            options=ZONE_OPTIONS,
                                            value=["DE", "FR"],
                                            multi=True,
                                            clearable=False,
                                            persistence=True,
                                            persistence_type="local",
                                            style={"minWidth": "320px", "fontSize": "13px"},
                                        ),
                                        html.Div(
                                            "Fundamentals are summed across the selected zones. "
                                            "Spot, CSS, CDS and Heat rate are shown per zone; "
                                            "TTF and EUA are shown once (zonal-independent).",
                                            className="text-muted",
                                            style={
                                                "fontSize": "11px",
                                                "marginTop": "6px",
                                                "lineHeight": "1.4",
                                                "maxWidth": "640px",
                                            },
                                        ),
                                    ],
                                    style={"marginBottom": "12px"},
                                ),
                                dcc.Loading(
                                    type="circle",
                                    color=COLORS["accent"],
                                    children=html.Div(id="hb-region-container"),
                                ),
                            ],
                        ),
                    ),
                    dbc.Tab(
                        label="Graphs",
                        tab_id="tab-graphs",
                        children=html.Div(
                            style={"padding": "16px"},
                            children=[
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                html.Label(
                                                    "Variable A",
                                                    className="small text-muted fw-bold",
                                                ),
                                                dbc.Select(
                                                    id="hb-graph-var-a",
                                                    options=METRIC_OPTIONS,
                                                    value="ResL - Nuke",
                                                    persistence=True,
                                                    persistence_type="local",
                                                    style={"maxWidth": "220px"},
                                                ),
                                            ],
                                            width="auto",
                                        ),
                                        dbc.Col(
                                            [
                                                html.Label(
                                                    "Variable B",
                                                    className="small text-muted fw-bold",
                                                ),
                                                dbc.Select(
                                                    id="hb-graph-var-b",
                                                    options=METRIC_OPTIONS,
                                                    value="Heat rate",
                                                    persistence=True,
                                                    persistence_type="local",
                                                    style={"maxWidth": "220px"},
                                                ),
                                            ],
                                            width="auto",
                                        ),
                                    ],
                                    className="g-3 align-items-end mb-3",
                                ),
                                dcc.Loading(
                                    type="circle",
                                    color=COLORS["accent"],
                                    children=html.Div(id="hb-graphs-container"),
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ],
    )
