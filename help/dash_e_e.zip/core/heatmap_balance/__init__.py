"""
Heatmap Balance dashboard package.

Sub-modules (import explicitly to avoid pulling heavy deps in tests):

    * ``constants``  -- zone options, slider defaults, page metadata
    * ``data``       -- ``build_balance_matrix`` + balance/price helpers
                       (depends on ``jain_commods`` / S3)
    * ``table``      -- ``BalanceTableGenerator`` + Excel display helper
    * ``layout``     -- ``build_layout()`` (pure)
    * ``callbacks``  -- Dash callbacks (registered on import)

This file is intentionally side-effect-free: importing
``core.heatmap_balance`` does not import ``data`` (which pulls the heavy
commodity-data deps).
"""
