"""Figure builder for the Arrivals vs Regas scatters."""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.arrivals_regas.constants import STORAGE_BUCKETS
from core.styles import COLORS

# Month colouring: light → dark blue, as in the lng_vessels report.
_MONTH_BLUES = [
    "#EBF5FB", "#D4E6F1", "#A9CCE3", "#7FB3D5", "#5499C7", "#2980B9",
    "#2471A3", "#1F618D", "#1A5276", "#154360", "#0F3C5A", "#0A2942",
]
_MONTH_COLORSCALE = [
    [i / 11, colour] for i, colour in enumerate(_MONTH_BLUES)
]
_MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

_TREND_COLOR = "#e67e22"
_RECENT_COLOR = "red"
_MIN_TREND_POINTS = 10

# Seasonal chart colours (as in the lng_vessels email report)
_PREV_YEAR_COLOR = "#5499C7"
_CURR_YEAR_COLOR = "#1A5276"
_HIST_BAND_COLOR = "rgba(128, 128, 128, 0.3)"
_SEASONAL_MA_DAYS = 7


def empty_scatter_figure(message: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        height=480,
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        xaxis={"visible": False},
        yaxis={"visible": False},
        annotations=[{
            "text": message, "showarrow": False,
            "font": {"size": 14, "color": COLORS["text_muted"]},
        }],
    )
    return fig


def _bucket_mask(df: pd.DataFrame, lo: float | None,
                 hi: float | None) -> pd.Series:
    mask = pd.Series(True, index=df.index)
    if lo is not None:
        mask &= df["fill_pc"] >= lo
    if hi is not None:
        mask &= df["fill_pc"] < hi
    return mask


def _bucket_index(fill_pc: float) -> int:
    for i, (_, lo, hi) in enumerate(STORAGE_BUCKETS):
        if (lo is None or fill_pc >= lo) and (hi is None or fill_pc < hi):
            return i
    return len(STORAGE_BUCKETS) - 1


def _fit_trend(data: pd.DataFrame) -> tuple[float, float, float] | None:
    """OLS fit of regas_fwd on arrivals -> (slope, intercept, r2)."""
    x = data["arrivals"].to_numpy(dtype=float)
    y = data["regas_fwd"].to_numpy(dtype=float)
    if len(x) < _MIN_TREND_POINTS or np.ptp(x) == 0:
        return None
    slope, intercept = np.polyfit(x, y, 1)
    r = np.corrcoef(x, y)[0, 1]
    return float(slope), float(intercept), float(r ** 2)


def _rgba(hex_color: str, alpha: float) -> str:
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (1, 3, 5))
    return f"rgba({r}, {g}, {b}, {alpha})"


def _by_doy(year_data: pd.Series, max_doy: int = 366) -> pd.Series:
    """Series re-indexed on day-of-year 1..max_doy, gaps interpolated."""
    mapped = pd.Series(index=year_data.index.dayofyear,
                       data=year_data.to_numpy(dtype=float))
    mapped = mapped[~mapped.index.duplicated(keep="last")]
    return mapped.reindex(range(1, max_doy + 1)).interpolate(method="linear")


def _add_seasonal_panel(fig: go.Figure, col: int, series: pd.Series,
                        hover_fmt: str, show_legend: bool) -> None:
    """One seasonal (Jan–Dec) panel: grey hist min/max band of 7d MAs,
    previous year (faint daily + 7d MA) and current year (faint daily +
    7d MA) — the same construction as the lng_vessels email charts."""
    series = series.dropna()
    current_year = int(series.index.max().year)
    previous_year = current_year - 1
    hist_years = sorted({y for y in series.index.year
                         if y < previous_year})
    days_in_year = pd.date_range(f"{current_year}-01-01",
                                 f"{current_year}-12-31", freq="D")
    n_days = len(days_in_year)

    def _x(values: pd.Series):
        return days_in_year[:min(len(values), n_days)]

    # Historical min/max band of per-year 7d moving averages
    if hist_years:
        mas = []
        for year in hist_years:
            doy = _by_doy(series[series.index.year == year])
            mas.append(doy.rolling(_SEASONAL_MA_DAYS, min_periods=1).mean())
        hist = pd.concat(mas, axis=1)
        lo = hist.min(axis=1).interpolate(method="linear")[:n_days]
        hi = hist.max(axis=1).interpolate(method="linear")[:n_days]
        band_label = (f"Hist range {hist_years[0]}–{hist_years[-1]} "
                      f"({_SEASONAL_MA_DAYS}d MA)")
        fig.add_trace(go.Scatter(
            x=_x(lo), y=lo.values[:n_days], mode="lines",
            line={"width": 0}, hoverinfo="skip",
            legendgroup="hist", showlegend=False,
        ), row=1, col=col)
        fig.add_trace(go.Scatter(
            x=_x(hi), y=hi.values[:n_days], mode="lines",
            line={"width": 0}, fill="tonexty",
            fillcolor=_HIST_BAND_COLOR, hoverinfo="skip",
            name=band_label, legendgroup="hist",
            showlegend=show_legend,
        ), row=1, col=col)

    # Previous and current year: faint daily line + bold 7d MA
    for year, color in ((previous_year, _PREV_YEAR_COLOR),
                        (current_year, _CURR_YEAR_COLOR)):
        year_data = series[series.index.year == year]
        if year_data.empty:
            continue
        max_doy = 366 if year == previous_year else \
            int(year_data.index.dayofyear.max())
        daily = _by_doy(year_data, max_doy)
        ma = daily.rolling(_SEASONAL_MA_DAYS, min_periods=1).mean()
        dash = "dash" if year == previous_year else "solid"
        fig.add_trace(go.Scatter(
            x=_x(daily), y=daily.values[:n_days], mode="lines",
            name=f"{year} (daily)", legendgroup=f"{year}d",
            showlegend=show_legend,
            line={"color": _rgba(color, 0.45), "width": 1, "dash": dash},
            hovertemplate=("%{x|%d %b} " + str(year) + ": %{y:" + hover_fmt
                           + "}<extra></extra>"),
        ), row=1, col=col)
        fig.add_trace(go.Scatter(
            x=_x(ma), y=ma.values[:n_days], mode="lines",
            name=f"{year} ({_SEASONAL_MA_DAYS}d MA)",
            legendgroup=f"{year}ma", showlegend=show_legend,
            line={"color": color, "width": 2.5},
            hovertemplate=("%{x|%d %b} " + str(year) + " MA: %{y:"
                           + hover_fmt + "}<extra></extra>"),
        ), row=1, col=col)

    fig.update_xaxes(tickformat="%b", dtick="M1", gridcolor="#eee",
                     row=1, col=col)
    fig.update_yaxes(gridcolor="#eee", row=1, col=col)


def build_seasonal_figure(ce: dict[str, pd.Series],
                          zone_label: str) -> go.Figure:
    """Two seasonal panels — LNG regas (mcm/d) and LNG stock fill % — as in
    the lng_vessels email report, for the selected country perimeter."""
    regas = ce["regas"].dropna()
    fill_pc = ce["fill_pc"].dropna()
    stock_bcm = ce["stock"].dropna().iloc[-1] / 1000
    capa_bcm = ce["capacity"].dropna().iloc[-1] / 1000

    titles = [
        (f"LNG Regas ({_SEASONAL_MA_DAYS}d MA) | today "
         f"{regas.iloc[-1]:,.0f} mcm/d"),
        (f"LNG Stock Fill % | stock {stock_bcm:.1f} bcm, capa "
         f"{capa_bcm:.1f} bcm, fill {fill_pc.iloc[-1]:.0%}"),
    ]
    fig = make_subplots(rows=1, cols=2, subplot_titles=titles,
                        horizontal_spacing=0.07)

    _add_seasonal_panel(fig, 1, regas, ",.0f", show_legend=True)
    _add_seasonal_panel(fig, 2, fill_pc, ".0%", show_legend=False)

    fig.update_yaxes(title_text="mcm/d", row=1, col=1)
    fig.update_yaxes(title_text="Fill %", tickformat=".0%", row=1, col=2)

    fig.update_layout(
        height=480,
        margin={"l": 60, "r": 30, "t": 70, "b": 70},
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        font={"family": "-apple-system, BlinkMacSystemFont, Segoe UI, "
                        "Roboto, sans-serif", "size": 12},
        legend={"orientation": "h", "yanchor": "top", "y": -0.12,
                "xanchor": "center", "x": 0.5},
        title={
            "text": f"CE LNG regas and stock fill — {zone_label}",
            "x": 0.5, "xanchor": "center",
            "font": {"size": 15, "color": COLORS["text_dark"]},
        },
        hovermode="x unified",
    )
    return fig


def build_scatter_figure(df: pd.DataFrame,
                         latest: dict[str, Any],
                         arrival_window: int,
                         regas_days: int,
                         zone_label: str,
                         x_label: str,
                         x_fmt: str,
                         partial_cutoff: pd.Timestamp,
                         recent_days: int) -> go.Figure:
    """Three storage-bucketed scatters of arrivals vs forward regas.

    Points coloured by calendar month; each bucket gets an OLS trend line
    (slope / R² in the panel title) fitted on settled points only — rows
    with a partial forward regas window or within the recent-trajectory
    highlight are plotted but excluded from the fit.  The last *recent_days*
    days are red-ringed; today's point is a solid red marker.  A red dashed
    vertical line marks the current lineup on the bucket containing the
    latest storage fill level.
    """
    latest_fill = latest.get("fill_pc")
    recent_cutoff = df.index.max() - pd.Timedelta(days=recent_days)
    fit_cutoff = min(partial_cutoff, recent_cutoff)

    # Panel titles with per-bucket trend stats
    titles = []
    trends = []
    for label, lo, hi in STORAGE_BUCKETS:
        data = df[_bucket_mask(df, lo, hi)]
        fit = _fit_trend(data[data.index < fit_cutoff])
        trends.append((data, fit))
        sub = (f"slope {fit[0]:+.2f} · R² {fit[2]:.2f}" if fit
               else "too few settled points for a trend")
        titles.append(f"{label}  ({len(data):,} days)"
                      f"<br><sub>{sub}</sub>")

    fig = make_subplots(rows=1, cols=3, subplot_titles=titles,
                        shared_yaxes=True, horizontal_spacing=0.05)

    show_recent_legend = True
    show_today_legend = True
    latest_date = df.index.max()
    for i, ((label, lo, hi), (data, fit)) in enumerate(
            zip(STORAGE_BUCKETS, trends), start=1):
        marker = {
            "color": data.index.month,
            "colorscale": _MONTH_COLORSCALE,
            "cmin": 1, "cmax": 12,
            "size": 8,
            "opacity": 0.75,
            "line": {"width": 0.5, "color": "#888"},
            "showscale": False,
        }
        if i == len(STORAGE_BUCKETS):
            # One shared month colorbar (attached to the last panel)
            marker["showscale"] = True
            marker["colorbar"] = {
                "title": "Month",
                "tickvals": list(range(1, 13)),
                "ticktext": _MONTH_NAMES,
                "len": 0.85,
            }
        fig.add_trace(go.Scatter(
            x=data["arrivals"],
            y=data["regas_fwd"],
            mode="markers",
            name=label,
            showlegend=False,
            marker=marker,
            customdata=[d.strftime("%d-%b-%Y") for d in data.index],
            hovertemplate=("%{customdata}<br>Arrivals: %{x:" + x_fmt
                           + "}<br>Regas: %{y:,.0f} mcm/d<extra></extra>"),
        ), row=1, col=i)

        # Trend line over the fitted x-range
        if fit is not None:
            slope, intercept, _ = fit
            fitted = data[data.index < fit_cutoff]["arrivals"]
            x_line = np.array([fitted.min(), fitted.max()])
            fig.add_trace(go.Scatter(
                x=x_line, y=slope * x_line + intercept,
                mode="lines", name="Trend (settled points)",
                legendgroup="trend", showlegend=(i == 1),
                line={"color": _TREND_COLOR, "width": 2, "dash": "dot"},
                hoverinfo="skip",
            ), row=1, col=i)

        # Recent-trajectory highlight (red-ringed points)
        recent = data[data.index >= recent_cutoff]
        if len(recent):
            fig.add_trace(go.Scatter(
                x=recent["arrivals"],
                y=recent["regas_fwd"],
                mode="markers",
                name=f"Last {recent_days}d",
                legendgroup="recent", showlegend=show_recent_legend,
                marker={
                    "color": recent.index.month,
                    "colorscale": _MONTH_COLORSCALE,
                    "cmin": 1, "cmax": 12,
                    "size": 10,
                    "showscale": False,
                    "line": {"width": 1.8, "color": _RECENT_COLOR},
                },
                customdata=[d.strftime("%d-%b-%Y") for d in recent.index],
                hovertemplate=("%{customdata} (recent)<br>Arrivals: %{x:"
                               + x_fmt + "}<br>Regas: %{y:,.0f} mcm/d"
                               "<extra></extra>"),
            ), row=1, col=i)
            show_recent_legend = False

        today = data[data.index == latest_date]
        if len(today):
            fig.add_trace(go.Scatter(
                x=today["arrivals"],
                y=today["regas_fwd"],
                mode="markers",
                name="Today",
                legendgroup="today",
                showlegend=show_today_legend,
                marker={
                    "color": _RECENT_COLOR,
                    "size": 12,
                    "line": {"width": 1.5, "color": "#7b0000"},
                },
                customdata=[d.strftime("%d-%b-%Y") for d in today.index],
                hovertemplate=("%{customdata} (today)<br>Arrivals: %{x:"
                               + x_fmt + "}<br>Regas: %{y:,.0f} mcm/d"
                               "<extra></extra>"),
            ), row=1, col=i)
            show_today_legend = False

        fig.update_xaxes(title_text=x_label, gridcolor="#eee", row=1, col=i)
        fig.update_yaxes(gridcolor="#eee", row=1, col=i)

    fig.update_yaxes(title_text=f"Avg regas next {regas_days}d (mcm/d)",
                     row=1, col=1)

    # Current-arrivals marker on the bucket holding today's fill level
    if latest and latest_fill == latest_fill:  # not NaN
        col = _bucket_index(latest_fill) + 1
        x = latest.get("arrivals")
        fig.add_vline(
            x=x, line={"color": _RECENT_COLOR, "dash": "dash", "width": 2},
            row=1, col=col,
            annotation_text=f"Current: {x:{x_fmt}}",
            annotation_position="top right",
            annotation_font={"color": _RECENT_COLOR, "size": 11},
        )

    fill_txt = (f" | Stock today {latest_fill:.0%}"
                if latest_fill == latest_fill else "")
    fig.update_layout(
        height=540,
        margin={"l": 60, "r": 30, "t": 100, "b": 60},
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        font={"family": "-apple-system, BlinkMacSystemFont, Segoe UI, "
                        "Roboto, sans-serif", "size": 12},
        legend={"orientation": "h", "yanchor": "top", "y": -0.15,
                "xanchor": "center", "x": 0.5},
        title={
            "text": (f"Arrivals due in {arrival_window}d vs avg regas next "
                     f"{regas_days}d — {zone_label}, bucketed by LNG stock "
                     f"level (coloured by month){fill_txt}"),
            "x": 0.5, "xanchor": "center",
            "font": {"size": 15, "color": COLORS["text_dark"]},
        },
    )
    return fig
