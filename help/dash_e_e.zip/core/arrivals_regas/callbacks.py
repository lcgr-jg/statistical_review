"""Callbacks for the LNG — Arrivals vs Regas page."""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from dash import Input, Output, callback, html

from core.arrivals_regas.constants import (
    ARRIVAL_WINDOW_OPTIONS,
    DEFAULT_ARRIVAL_WINDOW,
    DEFAULT_METRIC,
    DEFAULT_REGAS_DAYS,
    METRIC_CARGOES,
    METRIC_LABELS,
    RECENT_DAYS,
)
from core.arrivals_regas.data import build_scatter_data, get_ce_country_series
from core.arrivals_regas.render import (
    build_scatter_figure,
    build_seasonal_figure,
    empty_scatter_figure,
)
from core.cargo_dod.constants import NWE_COUNTRIES
from core.styles import COLORS

logger = logging.getLogger(__name__)


def _zone_label(countries: list[str]) -> str:
    if set(countries) == set(NWE_COUNTRIES):
        return "NWE"
    if len(countries) <= 3:
        return ", ".join(countries)
    return f"{len(countries)} countries"


@callback(
    Output("ar-scatter", "figure"),
    Output("ar-status", "children"),
    Input("ar-countries", "value"),
    Input("ar-sources", "value"),
    Input("ar-window", "value"),
    Input("ar-regas-days", "value"),
    Input("ar-metric", "value"),
    Input("ar-from-year", "value"),
)
def update_scatter(countries, sources, window, regas_days, metric,
                   from_year):
    if not countries or not sources:
        return (empty_scatter_figure("Select at least one country and one "
                                     "ETA source."), "")

    window = int(window or DEFAULT_ARRIVAL_WINDOW)
    if window not in ARRIVAL_WINDOW_OPTIONS:
        window = DEFAULT_ARRIVAL_WINDOW
    try:
        regas_days = max(1, min(30, int(regas_days)))
    except (TypeError, ValueError):
        regas_days = DEFAULT_REGAS_DAYS
    metric = metric if metric in METRIC_LABELS else DEFAULT_METRIC

    try:
        result = build_scatter_data(countries, sources, window, regas_days,
                                    value_col=metric, from_year=from_year)
    except Exception as ex:
        logger.exception("Arrivals vs Regas build failed")
        return (empty_scatter_figure("Data unavailable — see server logs."),
                html.Span(str(ex), style={"color": COLORS["error"]}))

    df = result["df"]
    if df.empty:
        return (empty_scatter_figure("No overlapping arrivals / regas / "
                                     "storage history for this selection."),
                "")

    if metric == METRIC_CARGOES:
        x_label = f"Cargoes due in next {window}d"
        x_fmt = ".0f"
        latest_unit = "cargoes"
    else:
        x_label = f"Volume due in next {window}d (mcm)"
        x_fmt = ",.0f"
        latest_unit = "mcm"

    fig = build_scatter_figure(df, result["latest"], window, regas_days,
                               _zone_label(countries), x_label, x_fmt,
                               result["partial_cutoff"], RECENT_DAYS)

    latest = result["latest"]
    bits = [
        f"{len(df):,} days from {df.index[0]:%d-%b-%Y} to "
        f"{df.index[-1]:%d-%b-%Y}."
    ]
    if latest:
        bits.append(
            f"Latest ({latest['date']:%d-%b-%Y}): "
            f"{latest['arrivals']:{x_fmt}} {latest_unit} due in {window}d, "
            f"stock {latest['fill_pc']:.0%}.")
    if result["missing_snapshots"]:
        bits.append(f"{result['missing_snapshots']} snapshot days missing "
                    "from the Kpler cache (excluded).")
    refreshed = datetime.now(timezone.utc).strftime("%H:%M UTC")
    bits.append(f"Updated {refreshed}.")
    return fig, html.Span(" ".join(bits),
                          style={"color": COLORS["text_muted"]})


# Deliberately a separate callback with its own countries input so the
# seasonal charts never redraw when the scatter controls change (and
# vice versa).
@callback(
    Output("ar-seasonal", "figure"),
    Output("ar-seasonal-status", "children"),
    Input("ar-seasonal-countries", "value"),
)
def update_seasonal(countries):
    if not countries:
        return (empty_scatter_figure("Select at least one country."), "")

    try:
        ce = get_ce_country_series(countries)
    except Exception as ex:
        logger.exception("Seasonal regas/stock build failed")
        return (empty_scatter_figure("CE data unavailable — see server "
                                     "logs."),
                html.Span(str(ex), style={"color": COLORS["error"]}))

    regas = ce["regas"].dropna()
    fill_pc = ce["fill_pc"].dropna()
    if regas.empty or fill_pc.empty:
        return (empty_scatter_figure("No CE regas / storage history for "
                                     "this selection."), "")

    fig = build_seasonal_figure(ce, _zone_label(countries))
    refreshed = datetime.now(timezone.utc).strftime("%H:%M UTC")
    status = (f"Regas to {regas.index[-1]:%d-%b-%Y}, fill to "
              f"{fill_pc.index[-1]:%d-%b-%Y}. Updated {refreshed}.")
    return fig, html.Span(status, style={"color": COLORS["text_muted"]})
