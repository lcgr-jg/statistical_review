"""LNG — Arrivals vs Regas page package.

Port of the eu_reports/lng_vessels forecast-vs-regas scatters: cargoes due
within an N-day arrival window (Kpler PIT snapshot cache) vs the average
regas/sendout in the following days (Commodity Essentials withdrawal),
bucketed by the LNG storage fill level on each date.
"""
