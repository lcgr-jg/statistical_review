"""Data access for the Arrivals vs Regas page.

Combines two sources:
    * cargo counts due within an N-day arrival window per snapshot date —
      from the Arrivals Analysis aggregates (Kpler PIT snapshot cache,
      cache-only);
    * daily LNG regas (withdrawal) and storage fill % — from the Commodity
      Essentials ``lng_country`` dataset in the portal cache, with an
      on-demand fetch fallback until the scheduled warm-up has run.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.arrivals_history.data import daily_total, filter_agg, get_arrivals
from core.arrivals_regas.constants import KPLER_TO_CE, LNG_DATASET_KEY
from core.cargo_dod.constants import COVERAGE_DEFAULT_START
from core.cargo_dod.data import max_selectable_date
from core.gas_data_ce.constants import SOURCE_NAME as CE_SOURCE_NAME

logger = logging.getLogger(__name__)

# On-demand CE fallback memo (used until the scheduled cache warm-up first
# includes the lng_country dataset).
_ce_lock = threading.Lock()
_ce_payload: dict[str, Any] | None = None
_ce_fetched_at: float | None = None
_CE_TTL_S = 6 * 60 * 60


def get_lng_ce_payload() -> dict[str, Any]:
    """The ``lng_country`` CE dataset payload (portal cache preferred)."""
    global _ce_payload, _ce_fetched_at

    try:
        from core.cache import dashboard_cache
        cached = dashboard_cache.get_data(CE_SOURCE_NAME)
        if isinstance(cached, dict):
            payload = (cached.get("datasets") or {}).get(LNG_DATASET_KEY)
            if payload:
                return payload
    except Exception as ex:
        logger.warning("Portal CE cache unavailable: %s", ex)

    with _ce_lock:
        now = time.monotonic()
        if (_ce_payload is not None and _ce_fetched_at is not None
                and now - _ce_fetched_at < _CE_TTL_S):
            return _ce_payload
        logger.info("lng_country not in portal cache yet — fetching from "
                    "Commodity Essentials directly")
        from core.gas_data_ce.data import fetch_ce_opdata
        _ce_payload = fetch_ce_opdata(LNG_DATASET_KEY)
        _ce_fetched_at = now
        return _ce_payload


def _ce_codes(countries: list[str]) -> list[str]:
    return [KPLER_TO_CE[c] for c in countries if c in KPLER_TO_CE]


def get_ce_country_series(countries: list[str]) -> dict[str, pd.Series]:
    """Daily CE series summed over *countries*.

    Returns ``{"regas", "stock", "capacity", "fill_pc"}`` — regas
    (withdrawal, mcm/d) trimmed to today; stock and capacity (mcm)
    forward-filled per country before summing (missing current-day prints).
    """
    payload = get_lng_ce_payload()
    by_variable: dict[str, pd.DataFrame] = payload.get("by_variable") or {}
    codes = _ce_codes(countries)

    df_withdrawal = by_variable.get("withdrawal", pd.DataFrame())
    regas_cols = [c for c in codes if c in df_withdrawal.columns]
    if not regas_cols:
        raise RuntimeError(
            "No CE withdrawal series for the selected countries — has the "
            "gas_data_ce cache warmed with the lng_country dataset?")
    regas = df_withdrawal[regas_cols].sum(axis=1, min_count=1)
    # Skip days after today (defensive) — the current day can hold partial,
    # erroneously low nominations but is kept, as in the lng_vessels report.
    today = pd.Timestamp(datetime.now(timezone.utc).date())
    regas = regas[regas.index <= today].rename("regas")

    stock_frame = by_variable.get("stock", pd.DataFrame())
    capa_frame = by_variable.get("stockCapacity", pd.DataFrame())
    stock_cols = [f"{c}|stock" for c in codes
                  if f"{c}|stock" in stock_frame.columns]
    capa_cols = [f"{c}|stockCapacity" for c in codes
                 if f"{c}|stockCapacity" in capa_frame.columns]
    if not stock_cols or not capa_cols:
        raise RuntimeError(
            "No CE stock / capacity series for the selected countries.")
    stock = stock_frame[stock_cols].ffill().sum(axis=1, min_count=1)
    capacity = capa_frame[capa_cols].ffill().sum(axis=1, min_count=1)
    stock = stock[stock.index <= today].rename("stock")
    capacity = capacity[capacity.index <= today].rename("capacity")
    fill_pc = (stock / capacity).rename("fill_pc")

    return {"regas": regas, "stock": stock, "capacity": capacity,
            "fill_pc": fill_pc}


def build_scatter_data(countries: list[str],
                       sources: list[str],
                       arrival_window: int,
                       regas_days: int,
                       value_col: str = "cargoes",
                       from_year: int | None = None) -> dict[str, Any]:
    """Build the combined daily frame behind the scatters.

    *value_col* selects the x metric from the aggregates (``cargoes`` count
    or ``volume_mcm``); *from_year* truncates history (regime filter).

    Returns::

        {
            "df":       DataFrame(index=date, columns=[arrivals, regas_fwd,
                        fill_pc]) — rows where all three are known,
            "latest":   last row as a dict (for the current-value marker),
            "partial_cutoff": Timestamp,  # rows >= this use a partial
                                          # forward regas window
            "missing_snapshots": int,   # uncached snapshot days in range
        }
    """
    start = COVERAGE_DEFAULT_START
    if from_year is not None:
        start = max(start, start.replace(year=int(from_year), month=1, day=1))
    end = max_selectable_date()

    # ── Arrivals within the window (cache-only Kpler aggregates) ─────────
    agg, available, missing = get_arrivals(start, end)
    arrivals = daily_total(
        filter_agg(agg, arrival_window, sources, countries=countries),
        available, start, end, value_col=value_col)
    arrivals.name = "arrivals"

    # ── CE regas + storage fill for the same country perimeter ───────────
    ce = get_ce_country_series(countries)
    regas = ce["regas"]
    fill_pc = ce["fill_pc"]
    today = pd.Timestamp(datetime.now(timezone.utc).date())

    # Forward-looking N-day average of regas from each date
    indexer = pd.api.indexers.FixedForwardWindowIndexer(
        window_size=int(regas_days))
    regas_fwd = regas.rolling(window=indexer, min_periods=1).mean()
    regas_fwd.name = "regas_fwd"

    # ── Combine ───────────────────────────────────────────────────────────
    df = pd.concat([arrivals, regas_fwd, fill_pc], axis=1)
    df = df.dropna()

    latest = df.iloc[-1].to_dict() if len(df) else {}
    if len(df):
        latest["date"] = df.index[-1]

    # Rows from here on have fewer than *regas_days* printed days in their
    # forward window — plotted, but excluded from trend fits.
    partial_cutoff = today - pd.Timedelta(days=int(regas_days) - 1)

    return {
        "df": df,
        "latest": latest,
        "partial_cutoff": partial_cutoff,
        "missing_snapshots": len(missing),
    }
