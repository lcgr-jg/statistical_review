"""LNG — Arrivals vs Regas page constants."""
from __future__ import annotations

from core.cargo_dod.constants import NWE_COUNTRIES

PAGE_PATH = "/power/lng/arrivals_regas"
PAGE_NAME = "Arrivals vs Regas"
PAGE_TITLE = "LNG Arrivals vs Regas | JG Power Dashboard"
PAGE_ORDER = 83

# Kpler ``Country (destination)`` label → Commodity Essentials country code.
# Only countries with a CE LNG asset (see gas_data_ce ``lng_country``) are
# selectable, since the regas / storage side needs CE data.
KPLER_TO_CE = {
    "Belgium": "BE",
    "Croatia": "HR",
    "Finland": "FI",
    "France": "FR",
    "Germany": "DE",
    "Greece": "GR",
    "Italy": "IT",
    "Lithuania": "LT",
    "Netherlands": "NL",
    "Poland": "PL",
    "Portugal": "PT",
    "Spain": "ES",
    "Turkey": "TR",
    "United Kingdom": "GB",
}
COUNTRY_OPTIONS = sorted(KPLER_TO_CE)
DEFAULT_COUNTRIES = list(NWE_COUNTRIES)

# Arrival window (days) for the cargo count — must be one of the windows
# pre-aggregated by the Arrivals Analysis store (7 / 14 / 21).
ARRIVAL_WINDOW_OPTIONS = [7, 14, 21]
DEFAULT_ARRIVAL_WINDOW = 14

# Forward-looking average window for regas (days ahead of each date).
DEFAULT_REGAS_DAYS = 7

# X-axis metric: cargo count or total volume (aggregate column names).
METRIC_CARGOES = "cargoes"
METRIC_VOLUME = "volume_mcm"
METRIC_LABELS = {
    METRIC_CARGOES: "Cargo count",
    METRIC_VOLUME: "Volume (mcm)",
}
DEFAULT_METRIC = METRIC_CARGOES

# Points within this many days of today are highlighted as the recent
# trajectory (and excluded, along with partial regas windows, from trends).
RECENT_DAYS = 30

# Storage fill-level buckets (report used <55 / 55-70 / >70; the top bucket
# was sparsely populated so the boundary is now 65%).
STORAGE_BUCKETS: list[tuple[str, float | None, float | None]] = [
    ("Stock <55%", None, 0.55),
    ("Stock 55\u201365%", 0.55, 0.65),
    ("Stock >65%", 0.65, None),
]

# gas_data_ce dataset holding the LNG withdrawal / stock / capacity series
LNG_DATASET_KEY = "lng_country"
