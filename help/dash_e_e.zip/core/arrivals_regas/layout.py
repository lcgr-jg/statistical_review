"""Layout for the LNG — Arrivals vs Regas page."""
from __future__ import annotations

from dash import dcc, html

from datetime import date

from core.arrivals_history.constants import DEFAULT_SOURCES, SOURCE_OPTIONS
from core.arrivals_regas.constants import (
    ARRIVAL_WINDOW_OPTIONS,
    COUNTRY_OPTIONS,
    DEFAULT_ARRIVAL_WINDOW,
    DEFAULT_COUNTRIES,
    DEFAULT_METRIC,
    DEFAULT_REGAS_DAYS,
    METRIC_LABELS,
)
from core.cargo_dod.constants import COVERAGE_DEFAULT_START
from core.styles import COLORS

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "flex-end",
    "flexWrap": "wrap",
    "gap": "18px",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}

_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "margin": "8px 0 0 0",
    "lineHeight": "1.5",
}


def build_layout() -> html.Div:
    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1500px"},
        children=[
            html.Div([
                html.H1("Arrivals vs Regas", style={
                    "fontSize": "22px", "fontWeight": "600",
                    "color": COLORS["text_primary"], "margin": "0 0 4px 0"}),
                html.P(
                    "Relationship between the LNG lineup and realised "
                    "sendout (as in the lng_vessels report): cargoes due "
                    "within the arrival window on each day's ~06:00 UTC "
                    "Kpler snapshot vs the average regas in the days that "
                    "followed, bucketed by the LNG storage fill level at "
                    "the time. Regas and storage come from Commodity "
                    "Essentials; arrivals from the permanent snapshot "
                    "cache.",
                    style={"fontSize": "13px", "color": COLORS["text_muted"],
                           "margin": "0 0 12px 0"}),
            ]),

            # ── Controls ────────────────────────────────────────────────
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Div(
                        style={"flex": "1 1 320px", "minWidth": "280px"},
                        children=[
                            html.Label("Countries (default: NWE zone)",
                                       style=_LABEL),
                            dcc.Dropdown(
                                id="ar-countries",
                                options=[{"label": c, "value": c}
                                         for c in COUNTRY_OPTIONS],
                                value=list(DEFAULT_COUNTRIES),
                                multi=True,
                                placeholder="Pick countries…",
                            ),
                        ],
                    ),
                    html.Div(
                        style={"flex": "1 1 220px", "minWidth": "200px"},
                        children=[
                            html.Label("Forecast type (Kpler ETA source)",
                                       style=_LABEL),
                            dcc.Dropdown(
                                id="ar-sources",
                                options=[{"label": s, "value": s}
                                         for s in SOURCE_OPTIONS],
                                value=list(DEFAULT_SOURCES),
                                multi=True,
                                placeholder="Pick ETA sources…",
                            ),
                        ],
                    ),
                    html.Div([
                        html.Label("Arrival window", style=_LABEL),
                        dcc.Dropdown(
                            id="ar-window",
                            options=[{"label": f"{w} days", "value": w}
                                     for w in ARRIVAL_WINDOW_OPTIONS],
                            value=DEFAULT_ARRIVAL_WINDOW,
                            clearable=False,
                            style={"width": "120px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Regas avg (days ahead)", style=_LABEL),
                        dcc.Input(
                            id="ar-regas-days",
                            type="number",
                            value=DEFAULT_REGAS_DAYS,
                            min=1, max=30, step=1,
                            style={"width": "90px", "padding": "6px 8px",
                                   "border":
                                       f"1px solid {COLORS['border']}",
                                   "borderRadius": "6px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Arrivals metric", style=_LABEL),
                        dcc.RadioItems(
                            id="ar-metric",
                            options=[{"label": f" {label}", "value": v}
                                     for v, label in METRIC_LABELS.items()],
                            value=DEFAULT_METRIC,
                            style={"fontSize": "13px",
                                   "color": COLORS["text_secondary"]},
                            labelStyle={"display": "block",
                                        "marginBottom": "2px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("From year", style=_LABEL),
                        dcc.Dropdown(
                            id="ar-from-year",
                            options=[{"label": str(y), "value": y}
                                     for y in range(
                                         COVERAGE_DEFAULT_START.year,
                                         date.today().year + 1)],
                            value=COVERAGE_DEFAULT_START.year,
                            clearable=False,
                            style={"width": "100px"},
                        ),
                    ]),
                ],
            ),

            # ── Scatters ────────────────────────────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="ar-scatter", config={"displayModeBar": False})),
                html.Div(id="ar-status", style=_NOTE),
                html.P(
                    "Each point is one day. x = arrivals (count or mcm, "
                    "from the selected ETA sources) forecast into the "
                    "selected countries within the arrival window; "
                    "y = average CE regas (withdrawal) over the following "
                    "days; panel = LNG storage fill level (stock / "
                    "capacity, CE) on that day. The red dashed line marks "
                    "the current lineup on the panel matching today's fill "
                    "level; red-ringed points are the last 30 days; the "
                    "solid red marker is today's point. "
                    "Trend lines are fitted on settled points only — the "
                    "recent tail (partial forward regas windows) is "
                    "plotted but excluded. Use \"From year\" to fit on the "
                    "current infrastructure regime (pre-2022 had far less "
                    "regas capacity).",
                    style=_NOTE),
            ]),

            # ── Seasonal regas & stock fill (CE) ────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.Div(
                    style={"display": "flex", "alignItems": "flex-end",
                           "flexWrap": "wrap", "gap": "18px",
                           "marginBottom": "8px"},
                    children=[
                        html.Div(
                            style={"flex": "1 1 320px",
                                   "minWidth": "280px",
                                   "maxWidth": "560px"},
                            children=[
                                html.Label(
                                    "Countries — these two charts only "
                                    "(default: NWE zone)", style=_LABEL),
                                dcc.Dropdown(
                                    id="ar-seasonal-countries",
                                    options=[{"label": c, "value": c}
                                             for c in COUNTRY_OPTIONS],
                                    value=list(DEFAULT_COUNTRIES),
                                    multi=True,
                                    placeholder="Pick countries…",
                                ),
                            ],
                        ),
                    ],
                ),
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="ar-seasonal", config={"displayModeBar": False})),
                html.Div(id="ar-seasonal-status", style=_NOTE),
                html.P(
                    "Same charts as the lng_vessels email report: total CE "
                    "LNG regas (withdrawal) and LNG stock fill % (stock / "
                    "capacity, stocks forward-filled) for the selected "
                    "countries, laid out Jan–Dec. Grey band is the min/max "
                    "of the 7d moving average across earlier years; the "
                    "previous and current years show a faint daily line "
                    "plus a bold 7d MA. History starts Jan-2021 (CE "
                    "dataset).",
                    style=_NOTE),
            ]),
        ],
    )
