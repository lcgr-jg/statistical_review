"""Storage Summary charts (Plotly ports of eu_gas_storage report visuals)."""
from __future__ import annotations

from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.gas_storage_summary.constants import (
    COUNTRIES,
    COUNTRY_COLORS,
    RANGE_POST_UKRAINE,
    SEASON_OCT,
    YEAR_BASIS_CALENDAR,
    YEAR_BASIS_GAS,
    is_post_ukraine_year,
    resolve_chart_countries,
    season_chart_title,
    season_end,
    season_start,
    year_label,
    yoy_current_year,
    yoy_year_line_style,
)
from core.styles import COLORS


def build_daily_storage_action_chart(
    df_inj: pd.DataFrame,
    start_date: date | datetime | pd.Timestamp,
    to_date: datetime | pd.Timestamp | None = None,
    country: str = "Total",
) -> go.Figure:
    """
    Bars = daily netInjection for *country* (or Total); overlay 5Y range / avg and 7-day MA.

    *start_date* controls the left edge of the chart (picker default Oct 2025).
    """
    to_date = pd.Timestamp(to_date or datetime.now()).normalize()
    start = pd.Timestamp(start_date).normalize()
    current_year = int(to_date.year)
    col = country if country in getattr(df_inj, "columns", []) else "Total"

    if col not in getattr(df_inj, "columns", []):
        return _empty_fig(f"No {col} injection series in CE cache")

    df_current = df_inj.loc[start:to_date, col].dropna()
    if df_current.empty:
        return _empty_fig("No injection data in the selected date range")

    def _hist_stats(day_of_year: int) -> tuple[float | None, float | None, float | None]:
        values: list[float] = []
        for year_offset in range(1, 6):
            year = current_year - year_offset
            try:
                if day_of_year == 366 and not (
                    year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
                ):
                    continue
                target = pd.Timestamp(f"{year}-01-01") + pd.Timedelta(days=day_of_year - 1)
                if target in df_inj.index:
                    val = df_inj.loc[target, col]
                    if pd.notna(val):
                        values.append(float(val))
            except Exception:
                continue
        if not values:
            return None, None, None
        return float(np.mean(values)), float(np.min(values)), float(np.max(values))

    stats_rows = []
    for dt in df_current.index:
        avg, min_v, max_v = _hist_stats(int(dt.dayofyear))
        stats_rows.append({"date": dt, "avg": avg, "min": min_v, "max": max_v})
    df_stats = pd.DataFrame(stats_rows).set_index("date")

    df_smoothed = df_current.rolling(window=7, min_periods=1, center=True).mean()

    fig = go.Figure()

    for year in range(start.year, to_date.year + 1):
        season_start_ts = max(pd.Timestamp(f"{year}-04-01"), start)
        season_end_ts = min(pd.Timestamp(f"{year}-10-31"), to_date)
        if season_end_ts >= season_start_ts:
            fig.add_vrect(
                x0=season_start_ts,
                x1=season_end_ts,
                fillcolor="#e8f4e8",
                opacity=0.45,
                layer="below",
                line_width=0,
            )

    fig.add_trace(
        go.Scatter(
            x=df_stats.index,
            y=df_stats["max"],
            mode="lines",
            line=dict(width=0),
            showlegend=False,
            hoverinfo="skip",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=df_stats.index,
            y=df_stats["min"],
            mode="lines",
            line=dict(width=0),
            fill="tonexty",
            fillcolor="rgba(253, 235, 208, 0.65)",
            name="5Y Range",
            hovertemplate="5Y min %{y:.0f}<extra></extra>",
        )
    )

    fig.add_trace(
        go.Bar(
            x=df_current.index,
            y=df_current.values,
            name="Daily Action",
            marker_color="#f5a623",
            opacity=0.75,
            hovertemplate="%{x|%d %b %Y}<br>%{y:,.0f} mcm/d<extra></extra>",
        )
    )

    fig.add_trace(
        go.Scatter(
            x=df_stats.index,
            y=df_stats["avg"],
            mode="lines",
            name="5Y AVG",
            line=dict(color="#e67e22", width=1.8),
            hovertemplate="5Y avg %{y:,.0f}<extra></extra>",
        )
    )

    fig.add_trace(
        go.Scatter(
            x=df_smoothed.index,
            y=df_smoothed.values,
            mode="lines",
            name="7-Day Avg",
            line=dict(color="#3b7dd8", width=2.2),
            hovertemplate="7d avg %{y:,.0f}<extra></extra>",
        )
    )

    fig.add_hline(y=0, line_width=1, line_color="#888888", opacity=0.7)

    title_scope = "All countries" if col == "Total" else col
    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=f"Daily Storage Action · {title_scope}",
            x=0.5,
            xanchor="center",
            font=dict(size=14),
        ),
        yaxis_title="mcm/d",
        barmode="overlay",
        bargap=0,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="center",
            x=0.5,
        ),
        margin=dict(l=50, r=20, t=50, b=90),
        height=500,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        hovermode="x unified",
    )
    fig.update_xaxes(showgrid=True, gridcolor="#eee", tickformat="%d %b %Y")
    fig.update_yaxes(showgrid=True, gridcolor="#eee", zeroline=False)

    return fig


def calculate_season_comparison(
    df_inj: pd.DataFrame,
    kind: str,
    anchor_year: int,
    to_date: datetime | pd.Timestamp | None = None,
) -> tuple[pd.DataFrame, date, str]:
    """
    Year-on-year cumulative totals from a season start through a matched as-of day.

    Apr → net injection (bcm). Oct → withdrawals as ``-netInjection`` (bcm).
    Returns ``(df_bcm, as_of, title)``.
    """
    today = pd.Timestamp(to_date or datetime.now()).normalize().date()
    start = season_start(kind, anchor_year)
    end_cap = season_end(kind, anchor_year)
    as_of = min(today, end_cap)
    if as_of < start:
        as_of = end_cap

    elapsed = (as_of - start).days
    cols = [c for c in COUNTRIES if c in df_inj.columns]
    if not cols:
        return pd.DataFrame(), as_of, season_chart_title(kind, anchor_year, as_of)

    rows = []
    min_year = int(df_inj.index.min().year)
    for year in range(min_year, anchor_year + 1):
        y_start = season_start(kind, year)
        y_end = y_start + timedelta(days=elapsed)
        try:
            period = df_inj.loc[pd.Timestamp(y_start) : pd.Timestamp(y_end), cols]
        except Exception:
            continue
        if period.empty:
            continue
        totals = period.sum(numeric_only=True)
        if kind == SEASON_OCT:
            totals = -totals
        row = totals.to_dict()
        row["Year"] = year
        rows.append(row)

    if not rows:
        return pd.DataFrame(), as_of, season_chart_title(kind, anchor_year, as_of)

    df = pd.DataFrame(rows).set_index("Year").sort_index()
    df_bcm = df / 1000.0
    return df_bcm, as_of, season_chart_title(kind, anchor_year, as_of)


def build_season_comparison_chart(
    df_inj: pd.DataFrame,
    kind: str,
    anchor_year: int,
    to_date: datetime | pd.Timestamp | None = None,
    countries: list[str] | None = None,
) -> go.Figure:
    """Bar chart: top panel + optional country subplots, YoY (bcm).

    *countries*: individual countries to show as subplots. When exactly one
    country is selected upstream, pass ``top_panel`` via treating that country
    as the only column in the top panel (see ``resolve_chart_countries``):
    pass ``countries=[]`` and set data via ``top_country``.
    """
    top_panel, country_cols = resolve_chart_countries(countries)

    df_bcm, as_of, title = calculate_season_comparison(
        df_inj, kind, anchor_year, to_date=to_date
    )
    if df_bcm.empty:
        return _empty_fig("No season comparison data for the selected anchor")

    # Restrict to requested panels that exist in the frame.
    country_cols = [c for c in country_cols if c in df_bcm.columns]
    if top_panel not in df_bcm.columns:
        return _empty_fig(f"No season data for {top_panel}")

    n_country_rows = (len(country_cols) + 1) // 2
    n_rows = 1 + n_country_rows
    fig_height = 280 + max(n_country_rows, 0) * 230
    if n_country_rows == 0:
        fig_height = 420

    years = df_bcm.index.astype(int).tolist()
    x_labels = [str(y) for y in years]
    latest_year = max(years)
    prior_years = [y for y in years if y < latest_year]
    avg_windows = (3, 5, 7)

    def _prior_avgs(series: pd.Series) -> dict[int, float]:
        out: dict[int, float] = {}
        for n in avg_windows:
            sample = [float(series.loc[y]) for y in prior_years[-n:] if y in series.index]
            if sample:
                out[n] = float(np.mean(sample))
        return out

    def _avg_title_suffix(series: pd.Series) -> str:
        avgs = _prior_avgs(series)
        if not avgs:
            return ""
        parts = [f"{n}Y {avgs[n]:.1f}" for n in avg_windows if n in avgs]
        return "  ·  " + "  ·  ".join(parts) + " bcm"

    top_label = title if top_panel == "Total" else f"{top_panel} · {title}"
    subplot_titles: list[str] = [
        f"{top_label}{_avg_title_suffix(df_bcm[top_panel])}"
    ]
    for country in country_cols:
        subplot_titles.append(f"{country}{_avg_title_suffix(df_bcm[country])}")
    while len(subplot_titles) < 1 + max(n_country_rows, 0) * 2:
        subplot_titles.append("")

    if n_country_rows == 0:
        specs = [[{"colspan": 2}, None]]
        fig = make_subplots(
            rows=1,
            cols=2,
            specs=specs,
            subplot_titles=subplot_titles[:1],
            vertical_spacing=0.11,
            horizontal_spacing=0.08,
        )
    else:
        specs = [[{"colspan": 2}, None]] + [[{}, {}] for _ in range(n_country_rows)]
        fig = make_subplots(
            rows=n_rows,
            cols=2,
            specs=specs,
            subplot_titles=subplot_titles,
            vertical_spacing=0.11,
            horizontal_spacing=0.08,
        )

    def _y_pad(series: pd.Series) -> tuple[float, float]:
        vals = pd.to_numeric(series, errors="coerce").dropna()
        if vals.empty:
            return -0.5, 0.5
        ymin = float(vals.min())
        ymax = float(vals.max())
        span = max(abs(ymax), abs(ymin), 0.1)
        pad = span * 0.22
        lo = min(0.0, ymin) - (pad if ymin < 0 else 0.0)
        hi = max(0.0, ymax) + (pad if ymax > 0 else 0.0)
        if lo == hi:
            lo, hi = lo - 0.5, hi + 0.5
        return lo, hi

    def _add_bars(row: int, col: int, series: pd.Series, color: str):
        fig.add_trace(
            go.Bar(
                x=x_labels,
                y=series.values,
                marker_color=color,
                text=[f"{v:.1f}" for v in series.values],
                textposition="outside",
                textfont=dict(size=9),
                cliponaxis=False,
                showlegend=False,
                hovertemplate="%{x}: %{y:.2f} bcm<extra></extra>",
            ),
            row=row,
            col=col,
        )
        fig.add_hline(
            y=0,
            line_width=0.6,
            line_color="#888888",
            opacity=0.5,
            row=row,
            col=col,
        )
        lo, hi = _y_pad(series)
        fig.update_yaxes(range=[lo, hi], row=row, col=col)

    _add_bars(
        1,
        1,
        df_bcm[top_panel],
        COUNTRY_COLORS.get(top_panel, COLORS["accent"]),
    )

    for i, country in enumerate(country_cols):
        r = 2 + i // 2
        c = 1 + i % 2
        _add_bars(r, c, df_bcm[country], COUNTRY_COLORS.get(country, COLORS["accent"]))

    metric = "Withdrawals" if kind == SEASON_OCT else "Injection"
    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=(
                f"{metric} since season start — YoY (bcm)  ·  "
                f"3/5/7Y avgs = prior seasons before {latest_year}"
            ),
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        height=fig_height,
        autosize=True,
        uirevision=f"season-{kind}-{anchor_year}-{top_panel}-{','.join(country_cols)}",
        margin=dict(l=50, r=24, t=70, b=50),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        showlegend=False,
    )
    fig.update_yaxes(title_text="bcm", showgrid=True, gridcolor="#eee")
    fig.update_xaxes(showgrid=True, gridcolor="#f0f0f0")
    for ann in fig.layout.annotations:
        if ann.text:
            ann.font = dict(size=12)

    return fig


_YEAR_COLORS = [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b",
    "#e377c2",
    "#7f7f7f",
    "#bcbd22",
    "#17becf",
]

# Gazprom outlier year — excluded from 3Y/5Y averages (matches email report).
_AVG_EXCLUDE_YEARS = {2021}


def _month_ticks(kind: str, year: int) -> tuple[int, list[int], list[str]]:
    """Full-season day count and month-start tick marks (day-of-season, label)."""
    start = season_start(kind, year)
    end = season_end(kind, year)
    max_days = (end - start).days + 1
    ticks: list[int] = []
    labels: list[str] = []
    d = start
    while d <= end:
        ticks.append((d - start).days + 1)
        labels.append(d.strftime("%b"))
        if d.month == 12:
            d = date(d.year + 1, 1, 1)
        else:
            d = date(d.year, d.month + 1, 1)
    return max_days, ticks, labels


def _cumulative_by_year(
    df_inj: pd.DataFrame,
    column: str,
    kind: str,
    anchor_year: int,
    to_date: date,
) -> dict[int, pd.Series]:
    """
    Day-of-season cumulative series (bcm) for each year up to *anchor_year*.

    Withdrawal mode uses ``-netInjection`` so withdrawals plot as positive.
    The anchor year is truncated at *to_date*; earlier years cover the full season.
    """
    sign = -1.0 if kind == SEASON_OCT else 1.0
    season_len = (season_end(kind, anchor_year) - season_start(kind, anchor_year)).days + 1
    out: dict[int, pd.Series] = {}

    if column not in df_inj.columns or df_inj.empty:
        return out

    min_year = int(df_inj.index.min().year)
    for year in range(min_year, anchor_year + 1):
        start = season_start(kind, year)
        end = season_end(kind, year)
        if year == anchor_year:
            end = min(end, to_date)
        if end < start:
            continue
        try:
            period = df_inj.loc[pd.Timestamp(start) : pd.Timestamp(end), column]
        except Exception:
            continue
        if period.empty:
            continue
        cum = (period.astype(float) * sign).cumsum() / 1000.0
        # Index as 1..N day-of-season
        day_index = pd.Index(range(1, len(cum) + 1), name="day")
        series = pd.Series(cum.values, index=day_index, name=year)
        # Cap length to season (safety)
        out[year] = series.iloc[:season_len]

    return out


def _avg_curve(
    yearly: dict[int, pd.Series],
    years: list[int],
) -> pd.Series | None:
    filtered = [y for y in years if y not in _AVG_EXCLUDE_YEARS and y in yearly]
    if not filtered:
        return None
    arrays = [yearly[y].values.astype(float) for y in filtered]
    max_len = max(len(a) for a in arrays)
    padded = np.full((len(arrays), max_len), np.nan, dtype=float)
    for i, a in enumerate(arrays):
        padded[i, : len(a)] = a
    avg = np.nanmean(padded, axis=0)
    return pd.Series(avg, index=range(1, len(avg) + 1))


def build_cumulative_season_chart(
    df_inj: pd.DataFrame,
    kind: str,
    anchor_year: int,
    to_date: datetime | pd.Timestamp | None = None,
    countries: list[str] | None = None,
) -> go.Figure:
    """
    Cumulative daily injection/withdrawal through the full season window.

    X-axis spans the whole season (1 Apr→31 Oct or 1 Oct→31 Mar). The current
    season line stops at the latest available date; prior years are full.
    Top panel includes 3Y and 5Y average curves (2021 excluded).
    """
    today = pd.Timestamp(to_date or datetime.now()).normalize().date()
    top_panel, country_cols = resolve_chart_countries(countries)
    country_cols = [
        c for c in country_cols if c in getattr(df_inj, "columns", [])
    ]
    if top_panel not in getattr(df_inj, "columns", []):
        return _empty_fig(f"No {top_panel} injection series in CE cache")

    n_country_rows = (len(country_cols) + 1) // 2
    n_rows = 1 + n_country_rows
    fig_height = 520 + n_country_rows * 200
    if n_country_rows == 0:
        fig_height = 520
    row_heights = [2.2] + [1.0] * n_country_rows if n_country_rows else None

    max_days, tick_vals, tick_text = _month_ticks(kind, anchor_year)
    start = season_start(kind, anchor_year)
    end = season_end(kind, anchor_year)
    metric = "Withdrawals" if kind == SEASON_OCT else "Injection"
    xlabel = (
        "Days from 1 Oct" if kind == SEASON_OCT else "Days from 1 Apr"
    )
    top_scope = "Total" if top_panel == "Total" else top_panel
    total_title = (
        f"Cumulative {top_scope} {metric} "
        f"({start.strftime('%d %b')} – {end.strftime('%d %b')})"
    )

    subplot_titles = [total_title] + country_cols
    while len(subplot_titles) < 1 + max(n_country_rows, 0) * 2:
        subplot_titles.append("")

    if n_country_rows == 0:
        fig = make_subplots(
            rows=1,
            cols=2,
            specs=[[{"colspan": 2}, None]],
            subplot_titles=subplot_titles[:1],
            vertical_spacing=0.08,
            horizontal_spacing=0.08,
        )
    else:
        specs = [[{"colspan": 2}, None]] + [[{}, {}] for _ in range(n_country_rows)]
        fig = make_subplots(
            rows=n_rows,
            cols=2,
            specs=specs,
            subplot_titles=subplot_titles,
            row_heights=row_heights,
            vertical_spacing=0.08,
            horizontal_spacing=0.08,
        )

    def _plot_panel(
        row: int,
        col: int,
        column: str,
        *,
        show_averages: bool,
        show_legend: bool,
    ) -> None:
        yearly = _cumulative_by_year(df_inj, column, kind, anchor_year, today)
        years = sorted(yearly.keys())
        for i, year in enumerate(years):
            series = yearly[year]
            is_current = year == anchor_year
            day_labels = [
                season_day_hover_label(kind, int(d), anchor_year)
                for d in series.index
            ]
            fig.add_trace(
                go.Scatter(
                    x=series.index.tolist(),
                    y=series.values,
                    customdata=day_labels,
                    mode="lines",
                    name=str(year),
                    legendgroup=str(year),
                    showlegend=show_legend,
                    line=dict(
                        color=_YEAR_COLORS[i % len(_YEAR_COLORS)],
                        width=2.6 if is_current else 1.2,
                    ),
                    opacity=1.0 if is_current else 0.65,
                    hovertemplate=(
                        f"{year} · %{{customdata}}<br>%{{y:.2f}} bcm<extra></extra>"
                    ),
                ),
                row=row,
                col=col,
            )

        if show_averages:
            avg_5 = _avg_curve(yearly, list(range(anchor_year - 5, anchor_year)))
            avg_3 = _avg_curve(yearly, list(range(anchor_year - 3, anchor_year)))
            if avg_5 is not None:
                day_labels = [
                    season_day_hover_label(kind, int(d), anchor_year)
                    for d in avg_5.index
                ]
                fig.add_trace(
                    go.Scatter(
                        x=avg_5.index.tolist(),
                        y=avg_5.values,
                        customdata=day_labels,
                        mode="lines",
                        name="5yr Avg",
                        line=dict(color="#333333", width=2.0, dash="dash"),
                        hovertemplate=(
                            "5yr avg · %{customdata}<br>%{y:.2f} bcm<extra></extra>"
                        ),
                        showlegend=show_legend,
                    ),
                    row=row,
                    col=col,
                )
            if avg_3 is not None:
                day_labels = [
                    season_day_hover_label(kind, int(d), anchor_year)
                    for d in avg_3.index
                ]
                fig.add_trace(
                    go.Scatter(
                        x=avg_3.index.tolist(),
                        y=avg_3.values,
                        customdata=day_labels,
                        mode="lines",
                        name="3yr Avg",
                        line=dict(color="#666666", width=2.0, dash="dot"),
                        hovertemplate=(
                            "3yr avg · %{customdata}<br>%{y:.2f} bcm<extra></extra>"
                        ),
                        showlegend=show_legend,
                    ),
                    row=row,
                    col=col,
                )

        fig.add_hline(
            y=0,
            line_width=0.6,
            line_color="#888888",
            opacity=0.5,
            row=row,
            col=col,
        )
        fig.update_xaxes(
            range=[1, max_days],
            tickmode="array",
            tickvals=tick_vals,
            ticktext=tick_text,
            row=row,
            col=col,
        )

    _plot_panel(1, 1, top_panel, show_averages=True, show_legend=True)
    for i, country in enumerate(country_cols):
        r = 2 + i // 2
        c = 1 + i % 2
        _plot_panel(r, c, country, show_averages=False, show_legend=False)

    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=(
                f"Cumulative {metric} · full season "
                f"({start.strftime('%d %b %Y')} – {end.strftime('%d %b %Y')})  ·  "
                f"{anchor_year} stops at available data"
            ),
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        height=fig_height,
        autosize=True,
        uirevision=f"cum-{kind}-{anchor_year}-{top_panel}-{','.join(country_cols)}",
        margin=dict(l=50, r=24, t=70, b=90),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.04,
            xanchor="center",
            x=0.5,
        ),
        hovermode="x unified",
    )
    fig.update_yaxes(title_text="bcm", showgrid=True, gridcolor="#eee")
    fig.update_xaxes(title_text=xlabel, showgrid=True, gridcolor="#f0f0f0", row=1, col=1)
    fig.add_annotation(
        text="Note: 2021 excluded from 3Y/5Y avgs (Gazprom / DE storage)",
        xref="paper",
        yref="paper",
        x=1.0,
        y=1.02,
        showarrow=False,
        font=dict(size=10, color="#666666"),
        xanchor="right",
        yanchor="bottom",
    )
    for ann in fig.layout.annotations:
        if ann.text and not ann.text.startswith("Note:"):
            ann.font = dict(size=12)

    return fig


_MONTH_TICK_DOY = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
_MONTH_TICK_LABELS = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
]

# Gas-year month ticks relative to 1 Oct of a non-leap Feb window (GY2021).
_GAS_YEAR_TICK_DOY: list[int] = []
_GAS_YEAR_TICK_LABELS = [
    "Oct",
    "Nov",
    "Dec",
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
]
_gy_tick_start = date(2021, 10, 1)
for _m, _y in zip(
    [10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [2021, 2021, 2021, 2022, 2022, 2022, 2022, 2022, 2022, 2022, 2022, 2022],
):
    _GAS_YEAR_TICK_DOY.append((date(_y, _m, 1) - _gy_tick_start).days + 1)


def calendar_day_hover_label(doy: int) -> str:
    """Map calendar day-of-year → ``1 Jan (1)`` (non-leap; DOY 366 → 31 Dec leap)."""
    doy = int(doy)
    if doy <= 0:
        return str(doy)
    if doy >= 366:
        d = date(2020, 12, 31)
        return f"{d.day} {d.strftime('%b')} ({doy})"
    d = date(2021, 1, 1) + timedelta(days=doy - 1)
    return f"{d.day} {d.strftime('%b')} ({doy})"


def gas_year_day_hover_label(day: int) -> str:
    """Map day-of-gas-year (from 1 Oct) → ``1 Oct (1)``."""
    day = int(day)
    if day <= 0:
        return str(day)
    d = date(2021, 10, 1) + timedelta(days=day - 1)
    return f"{d.day} {d.strftime('%b')} ({day})"


def season_day_hover_label(kind: str, day: int, anchor_year: int) -> str:
    """Map day-from-season-start → ``1 Apr (1)`` / ``1 Oct (1)``."""
    day = int(day)
    if day <= 0:
        return str(day)
    d = season_start(kind, anchor_year) + timedelta(days=day - 1)
    return f"{d.day} {d.strftime('%b')} ({day})"


def yoy_day_hover_labels(days, basis: str) -> list[str]:
    """Hover labels for YoY charts (calendar DOY or gas-year day index)."""
    if basis == YEAR_BASIS_GAS:
        return [gas_year_day_hover_label(d) for d in days]
    return [calendar_day_hover_label(d) for d in days]


def _fill_pct_by_year(
    df_fill: pd.DataFrame,
    country: str,
    year: int,
    to_date: date,
    basis: str = YEAR_BASIS_CALENDAR,
) -> pd.Series | None:
    """
    Return fill % indexed by day-of-year (calendar) or day-of-gas-year.

    Gas year *year* runs 1 Oct *year* → 30 Sep *year*+1.
    """
    if basis == YEAR_BASIS_GAS:
        start = pd.Timestamp(f"{year}-10-01")
        end = pd.Timestamp(f"{year + 1}-09-30")
        if year == yoy_current_year(YEAR_BASIS_GAS, to_date):
            end = min(end, pd.Timestamp(to_date))
    else:
        start = pd.Timestamp(f"{year}-01-01")
        end = pd.Timestamp(f"{year}-12-31")
        if year == to_date.year:
            end = min(end, pd.Timestamp(to_date))

    stock_col = "Total|stock" if country == "Total" else f"{country}|stock"
    cap_col = (
        "Total|stockCapacity" if country == "Total" else f"{country}|stockCapacity"
    )
    if stock_col not in df_fill.columns or cap_col not in df_fill.columns:
        return None
    try:
        stock = df_fill.loc[start:end, stock_col]
        capacity = df_fill.loc[start:end, cap_col]
    except Exception:
        return None
    if stock.empty:
        return None
    pct = (stock.astype(float) / capacity.astype(float).replace(0, np.nan)) * 100.0
    pct = pct.dropna()
    if pct.empty:
        return None

    if basis == YEAR_BASIS_GAS:
        idx = ((pct.index.normalize() - start).days + 1).astype(int)
    else:
        idx = pct.index.dayofyear.astype(int)
    out = pd.Series(pct.values, index=idx, name=year)
    out = out[~out.index.duplicated(keep="last")].sort_index()
    return out


def _range_band(
    yearly: dict[int, pd.Series],
    years: list[int],
) -> tuple[pd.Series, pd.Series] | tuple[None, None]:
    sample = [yearly[y] for y in years if y in yearly]
    if not sample:
        return None, None
    all_days = sorted(set().union(*(s.index.tolist() for s in sample)))
    mins, maxs = [], []
    for d in all_days:
        vals = [float(s.loc[d]) for s in sample if d in s.index and pd.notna(s.loc[d])]
        if not vals:
            continue
        mins.append((d, min(vals)))
        maxs.append((d, max(vals)))
    if not mins:
        return None, None
    return (
        pd.Series([v for _, v in mins], index=[d for d, _ in mins]),
        pd.Series([v for _, v in maxs], index=[d for d, _ in maxs]),
    )


def build_yoy_fill_chart(
    df_fill: pd.DataFrame,
    selected_years: list[int] | None = None,
    range_years: int | str = 0,
    to_date: datetime | pd.Timestamp | None = None,
    countries: list[str] | None = None,
    year_basis: str = YEAR_BASIS_CALENDAR,
) -> go.Figure:
    """
    YoY storage fill % — top panel + optional country subplots.

    *year_basis*: ``calendar`` (Jan–Dec) or ``gas`` (Oct–Sep, labels GY####).
    *selected_years*: prior years to plot as lines (current year/GY always shown).
    *range_years*: if 3/5/7, shade min–max band from that many prior years;
    if ``post_ukraine``, emphasise calendar 2022+ / GY2023+ lines.
    """
    today = pd.Timestamp(to_date or datetime.now()).normalize().date()
    basis = (
        YEAR_BASIS_GAS if year_basis == YEAR_BASIS_GAS else YEAR_BASIS_CALENDAR
    )
    current_year = yoy_current_year(basis, today)
    selected = sorted({int(y) for y in (selected_years or []) if int(y) < current_year})
    band_years_n = (
        int(range_years)
        if isinstance(range_years, int) and range_years > 0
        else 0
    )
    highlight_post_ukraine = range_years == RANGE_POST_UKRAINE

    if df_fill is None or df_fill.empty:
        return _empty_fig("No fill data in CE cache")

    top_panel, country_cols = resolve_chart_countries(countries)

    def _has_fill(country: str) -> bool:
        stock_col = "Total|stock" if country == "Total" else f"{country}|stock"
        cap_col = (
            "Total|stockCapacity"
            if country == "Total"
            else f"{country}|stockCapacity"
        )
        return stock_col in df_fill.columns and cap_col in df_fill.columns

    country_cols = [c for c in country_cols if _has_fill(c)]
    if not _has_fill(top_panel):
        return _empty_fig(f"No fill data for {top_panel}")

    n_country_rows = (len(country_cols) + 1) // 2
    n_rows = 1 + n_country_rows
    fig_height = 520 + n_country_rows * 200
    if n_country_rows == 0:
        fig_height = 520
    row_heights = [2.2] + [1.0] * n_country_rows if n_country_rows else None

    top_title = (
        "Total Storage Fill" if top_panel == "Total" else f"{top_panel} Storage Fill"
    )
    subplot_titles = [top_title] + country_cols
    while len(subplot_titles) < 1 + max(n_country_rows, 0) * 2:
        subplot_titles.append("")

    if n_country_rows == 0:
        fig = make_subplots(
            rows=1,
            cols=2,
            specs=[[{"colspan": 2}, None]],
            subplot_titles=subplot_titles[:1],
            vertical_spacing=0.08,
            horizontal_spacing=0.08,
        )
    else:
        specs = [[{"colspan": 2}, None]] + [[{}, {}] for _ in range(n_country_rows)]
        fig = make_subplots(
            rows=n_rows,
            cols=2,
            specs=specs,
            subplot_titles=subplot_titles,
            row_heights=row_heights,
            vertical_spacing=0.08,
            horizontal_spacing=0.08,
        )

    tick_vals = _GAS_YEAR_TICK_DOY if basis == YEAR_BASIS_GAS else _MONTH_TICK_DOY
    tick_text = (
        _GAS_YEAR_TICK_LABELS if basis == YEAR_BASIS_GAS else _MONTH_TICK_LABELS
    )
    basis_title = (
        "gas year (Oct–Sep)" if basis == YEAR_BASIS_GAS else "calendar year"
    )

    def _plot_panel(row: int, col: int, country: str, *, show_legend: bool) -> None:
        years_to_load = sorted(set(selected) | {current_year})
        if band_years_n:
            years_to_load = sorted(
                set(years_to_load)
                | set(range(current_year - band_years_n, current_year))
            )

        yearly: dict[int, pd.Series] = {}
        for year in years_to_load:
            series = _fill_pct_by_year(df_fill, country, year, today, basis=basis)
            if series is not None and not series.empty:
                yearly[year] = series

        if band_years_n:
            band_years = list(range(current_year - band_years_n, current_year))
            lo, hi = _range_band(yearly, band_years)
            if lo is not None and hi is not None:
                fig.add_trace(
                    go.Scatter(
                        x=hi.index.tolist(),
                        y=hi.values,
                        mode="lines",
                        line=dict(width=0),
                        showlegend=False,
                        hoverinfo="skip",
                    ),
                    row=row,
                    col=col,
                )
                fig.add_trace(
                    go.Scatter(
                        x=lo.index.tolist(),
                        y=lo.values,
                        customdata=yoy_day_hover_labels(lo.index.tolist(), basis),
                        mode="lines",
                        line=dict(width=0),
                        fill="tonexty",
                        fillcolor="rgba(150, 150, 150, 0.25)",
                        name=f"{band_years_n}Y range",
                        legendgroup="range",
                        showlegend=show_legend,
                        hovertemplate=(
                            f"{band_years_n}Y range<br>%{{customdata}} · %{{y:.1f}}%"
                            "<extra></extra>"
                        ),
                    ),
                    row=row,
                    col=col,
                )

        plot_years = [y for y in selected if y in yearly] + (
            [current_year] if current_year in yearly else []
        )
        color_by_year = {
            y: _YEAR_COLORS[i % len(_YEAR_COLORS)] for i, y in enumerate(plot_years)
        }
        if highlight_post_ukraine:
            pre = [
                y
                for y in plot_years
                if y != current_year and not is_post_ukraine_year(y, basis)
            ]
            post = [
                y
                for y in plot_years
                if y != current_year and is_post_ukraine_year(y, basis)
            ]
            cur = [current_year] if current_year in yearly else []
            draw_years = pre + post + cur
        else:
            draw_years = plot_years

        for year in draw_years:
            series = yearly[year]
            label = year_label(year, basis)
            width, opacity = yoy_year_line_style(
                year,
                current_year=current_year,
                basis=basis,
                highlight_post_ukraine=highlight_post_ukraine,
            )
            fig.add_trace(
                go.Scatter(
                    x=series.index.tolist(),
                    y=series.values,
                    customdata=yoy_day_hover_labels(series.index.tolist(), basis),
                    mode="lines",
                    name=label,
                    legendgroup=label,
                    showlegend=show_legend,
                    line=dict(
                        color=color_by_year[year],
                        width=width,
                    ),
                    opacity=opacity,
                    hovertemplate=(
                        f"{label}<br>%{{customdata}} · %{{y:.1f}}%<extra></extra>"
                    ),
                ),
                row=row,
                col=col,
            )

        fig.update_xaxes(
            range=[1, 366],
            tickmode="array",
            tickvals=tick_vals,
            ticktext=tick_text,
            row=row,
            col=col,
        )
        fig.update_yaxes(range=[0, 105], row=row, col=col)

    _plot_panel(1, 1, top_panel, show_legend=True)
    for i, country in enumerate(country_cols):
        r = 2 + i // 2
        c = 1 + i % 2
        _plot_panel(r, c, country, show_legend=False)

    prior_label = (
        ", ".join(year_label(y, basis) for y in selected) if selected else "none"
    )
    if highlight_post_ukraine:
        range_note = " · post-Ukraine years highlighted"
    elif band_years_n:
        range_note = f" · {band_years_n}Y min–max band"
    else:
        range_note = ""
    current_label = year_label(current_year, basis)
    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=(
                f"Storage Fill % by {basis_title}  ·  "
                f"{current_label} + selected priors{range_note}"
            ),
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        height=fig_height,
        autosize=True,
        uirevision=(
            f"fill-yoy-{basis}-{current_year}-{prior_label}-{range_years}-"
            f"{top_panel}-{','.join(country_cols)}"
        ),
        margin=dict(l=50, r=24, t=70, b=90),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.04,
            xanchor="center",
            x=0.5,
        ),
        hovermode="x unified",
    )
    fig.update_yaxes(title_text="%", showgrid=True, gridcolor="#eee")
    fig.update_xaxes(showgrid=True, gridcolor="#f0f0f0")
    for ann in fig.layout.annotations:
        if ann.text:
            ann.font = dict(size=12)

    return fig


def _empty_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
        font={"size": 14, "color": "#888"},
    )
    fig.update_layout(
        height=400,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        margin=dict(t=30, b=30, l=30, r=30),
    )
    return fig
