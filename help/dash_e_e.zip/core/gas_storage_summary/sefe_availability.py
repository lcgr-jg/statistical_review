"""Upcoming SEFE injection and withdrawal: Storage Sites curves vs CE outages."""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from dash import html

from core.gas_data_ce.partial_storage import PARTIAL_CELL_BG, PARTIAL_CELL_COLOR
from core.gas_storage_summary.constants import (
    SEFE_AVAIL_DAYS,
    SEFE_AVAIL_DAYS_MAX,
    SEFE_SITES,
    UNIT_MCM,
    UNIT_TWH,
    SefeSite,
)
from core.gas_storage_summary.sefe import (
    LOGINTYPE,
    MCM_TO_TWH,
    fill_snapshot,
)
from core.styles import COLORS
from jain_commods.fundamental.gas.storage_params import capability_from_fill

logger = logging.getLogger(__name__)

_MAINT_MIN = 0.05

# Used only when a warmed CE payload has no SEFE outage bundle yet.
_FALLBACK_INPUTS: dict[str, tuple[pd.DataFrame, pd.DataFrame, dict[int, float]] | None] = {
    "bundle": None
}
_CACHE_LOCK = threading.Lock()

_TH = {
    "padding": "6px 8px",
    "textAlign": "center",
    "backgroundColor": COLORS["table_header_bg"],
    "color": COLORS["text_dark"],
    "fontWeight": "600",
    "border": f"1px solid {COLORS['border_light']}",
    "fontSize": "11px",
    "whiteSpace": "nowrap",
}

_TD = {
    "padding": "4px 8px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "color": COLORS["text_primary"],
    "whiteSpace": "nowrap",
    "textAlign": "right",
    "verticalAlign": "top",
}

def scale_curve_params(row: pd.Series, ratio: float) -> dict:
    """Scale a Storage Sites fit. Exponents stay; rates scale with capacity."""
    factor = float(ratio)

    def _scaled(name: str) -> float | None:
        if name not in row.index:
            return None
        val = row[name]
        if val is None or pd.isna(val):
            return None
        return float(val) * factor

    return {
        "p_inj": float(row["p_inj"]),
        "q_wdr": float(row["q_wdr"]),
        "max_inj": float(row["max_inj"]) * factor,
        "max_wdr": float(row["max_wdr"]) * factor,
        "max_inj_cap": _scaled("max_inj_cap"),
        "max_wdr_cap": _scaled("max_wdr_cap"),
    }


def rates_at_fill(params: dict, fill_frac: float) -> tuple[float, float]:
    """Max injection and withdrawal (mcm/d) from the Storage Sites power laws."""
    inj, wdr = capability_from_fill(
        float(fill_frac),
        float(params["p_inj"]),
        float(params["q_wdr"]),
        float(params["max_inj"]),
        float(params["max_wdr"]),
        params.get("max_inj_cap"),
        params.get("max_wdr_cap"),
    )
    return float(np.ravel(inj)[0]), float(np.ravel(wdr)[0])


def available_rate(
    curve: float | None,
    outage: float | None,
    restricted: float | None = None,
) -> float | None:
    """Curve capability minus published maintenance. Floor at zero.

    With no curve, fall back to CE restricted capacity.
    """
    curve_ok = curve is not None and not pd.isna(curve)
    if not curve_ok:
        if restricted is None or pd.isna(restricted):
            return None
        return float(restricted)
    maint = 0.0 if outage is None or pd.isna(outage) else max(0.0, float(outage))
    return max(0.0, float(curve) - maint)


def maintenance_spans(
    dates,
    values,
    *,
    min_out: float = _MAINT_MIN,
) -> list[dict]:
    """Collapse consecutive days that share the same outage, rounded to 0.1."""
    spans: list[dict] = []
    current: dict | None = None
    for day, raw in zip(dates, values):
        val = 0.0 if raw is None or pd.isna(raw) else float(raw)
        ts = pd.Timestamp(day).normalize()
        if val < min_out:
            if current is not None:
                spans.append(current)
                current = None
            continue
        key = round(val, 1)
        if (
            current is not None
            and current["key"] == key
            and ts == current["end"] + pd.Timedelta(days=1)
        ):
            current["end"] = ts
            continue
        if current is not None:
            spans.append(current)
        current = {"start": ts, "end": ts, "value": val, "key": key}
    if current is not None:
        spans.append(current)
    return spans


def outage_frame_from_ce(raw: pd.DataFrame | None) -> pd.DataFrame:
    """CE ``eugasout`` rows → daily outage and restricted capacity by site."""
    columns = pd.MultiIndex.from_tuples(
        [
            (site.key, field)
            for site in SEFE_SITES
            for field in ("inj_out", "inj_restr", "wdr_out", "wdr_restr")
        ],
        names=["site", "field"],
    )
    if raw is None or not isinstance(raw, pd.DataFrame) or raw.empty:
        return pd.DataFrame(columns=columns)

    work = raw.copy()
    work["Date"] = pd.to_datetime(work["Date"], format="%d-%b-%Y", errors="coerce")
    if work["Date"].isna().all():
        work["Date"] = pd.to_datetime(raw["Date"], errors="coerce")
    work["Date"] = work["Date"].dt.normalize()
    asset_to_key = {int(site.asset_id): site.key for site in SEFE_SITES}
    work["_key"] = pd.to_numeric(work["assetId"], errors="coerce").map(
        lambda v: asset_to_key.get(int(v)) if pd.notna(v) else None
    )
    var_map = {"injection": "inj", "withdrawal": "wdr"}
    work["_side"] = work["Variable"].astype(str).str.lower().map(var_map)
    work = work.dropna(subset=["Date", "_key", "_side"])
    for col in ("Out.Total", "Restr.Cap"):
        work[col] = pd.to_numeric(work[col], errors="coerce")

    pieces: dict[tuple[str, str], pd.Series] = {}
    for (key, side), block in work.groupby(["_key", "_side"], sort=False):
        daily = block.groupby("Date", sort=True)[["Out.Total", "Restr.Cap"]].last()
        pieces[(key, f"{side}_out")] = daily["Out.Total"]
        pieces[(key, f"{side}_restr")] = daily["Restr.Cap"]
    if not pieces:
        return pd.DataFrame(columns=columns)
    frame = pd.DataFrame(pieces).sort_index()
    frame.columns = pd.MultiIndex.from_tuples(frame.columns, names=["site", "field"])
    return frame.reindex(columns=columns)


def curves_at_latest_fill(
    params: pd.DataFrame,
    fills: list[dict],
    parent_caps: dict[int, float] | None = None,
) -> dict[str, dict]:
    """One curve rate per site at the latest reported fill."""
    by_id = _params_by_id(params)
    fill_by_key = {row["key"]: row for row in fills if not row.get("is_total")}
    parent_caps = parent_caps or {}
    out: dict[str, dict] = {}
    for site in SEFE_SITES:
        out[site.key] = _curve_for_site(site, by_id, fill_by_key.get(site.key), parent_caps)
    return out


def _params_by_id(params: pd.DataFrame) -> dict[int, pd.Series]:
    if params is None or params.empty or "data_id" not in params.columns:
        return {}
    work = params.copy()
    work["data_id"] = pd.to_numeric(work["data_id"], errors="coerce")
    return {
        int(row["data_id"]): row
        for _, row in work.dropna(subset=["data_id"]).iterrows()
    }


def _curve_for_site(
    site: SefeSite,
    by_id: dict[int, pd.Series],
    fill: dict | None,
    parent_caps: dict[int, float],
) -> dict:
    stock = None if not fill else fill.get("stock_mcm")
    capacity = None if not fill else fill.get("capacity_mcm")
    fill_pct = None if not fill else fill.get("fill_pct")
    base = {
        "label": site.label,
        "inj": None,
        "wdr": None,
        "fill_pct": fill_pct,
        "scaled": False,
    }
    if stock is None or not capacity:
        return base
    frac = float(stock) / float(capacity)
    own = by_id.get(int(site.data_id))
    if own is not None:
        inj, wdr = rates_at_fill(scale_curve_params(own, 1.0), frac)
        base["inj"], base["wdr"] = inj, wdr
        return base
    parent_id = site.curve_data_id
    parent = by_id.get(int(parent_id)) if parent_id else None
    parent_cap = parent_caps.get(int(parent_id)) if parent_id else None
    if parent is None or not parent_cap:
        return base
    inj, wdr = rates_at_fill(
        scale_curve_params(parent, float(capacity) / float(parent_cap)),
        frac,
    )
    base["inj"], base["wdr"] = inj, wdr
    base["scaled"] = True
    return base


def render_availability(
    curves: dict[str, dict],
    outages: pd.DataFrame,
    *,
    unit: str,
    as_of,
    n_days: int = SEFE_AVAIL_DAYS,
) -> html.Div:
    """Day table of available injection and withdrawal, with maintenance overlaid."""
    unit = UNIT_TWH if unit == UNIT_TWH else UNIT_MCM
    today = pd.Timestamp(as_of).normalize()
    if getattr(today, "tzinfo", None) is not None:
        today = today.tz_localize(None)
    days = pd.date_range(today, periods=int(n_days), freq="D")
    flow = "TWh/d" if unit == UNIT_TWH else "mcm/d"
    return _availability_table(curves, outages, days, unit, flow)


_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_secondary"],
    "margin": "8px 0 0 0",
    "maxWidth": "920px",
    "lineHeight": "1.45",
}


def _fmt(mcm: float | None, unit: str) -> str:
    if mcm is None or pd.isna(mcm):
        return "–"
    if unit == UNIT_TWH:
        return f"{float(mcm) * MCM_TO_TWH:,.2f}"
    return f"{float(mcm):,.1f}"


def _availability_table(
    curves: dict[str, dict],
    outages: pd.DataFrame,
    days: pd.DatetimeIndex,
    unit: str,
    flow: str,
) -> html.Div:
    group = html.Tr(
        [
            html.Th("Date", rowSpan=2, style={**_TH, "textAlign": "left"}),
            *[
                html.Th(site.label, colSpan=2, style=_TH)
                for site in SEFE_SITES
            ],
            html.Th("Total", colSpan=2, style=_TH),
        ]
    )
    sub = html.Tr(
        [html.Th(side, style=_TH) for _site in (*SEFE_SITES, None) for side in ("Inj", "Wdr")]
    )
    body = []
    for day in days:
        is_weekend = day.dayofweek >= 5
        bg = COLORS["card_bg_alt"] if is_weekend else COLORS["card_bg"]
        cells = [html.Td(day.strftime("%d-%b-%Y"), style={**_TD, "textAlign": "left"})]
        inj_vals: list[float] = []
        wdr_vals: list[float] = []
        for site in SEFE_SITES:
            curve = curves.get(site.key) or {}
            inj_cell, inj_val = _rate_cell(
                curve.get("inj"),
                _out_value(outages, day, site.key, "inj_out"),
                _out_value(outages, day, site.key, "inj_restr"),
                unit,
            )
            wdr_cell, wdr_val = _rate_cell(
                curve.get("wdr"),
                _out_value(outages, day, site.key, "wdr_out"),
                _out_value(outages, day, site.key, "wdr_restr"),
                unit,
            )
            if inj_val is not None:
                inj_vals.append(inj_val)
            if wdr_val is not None:
                wdr_vals.append(wdr_val)
            cells.extend([inj_cell, wdr_cell])
        cells.append(_plain_cell(sum(inj_vals) if inj_vals else None, unit))
        cells.append(_plain_cell(sum(wdr_vals) if wdr_vals else None, unit))
        body.append(html.Tr(cells, style={"backgroundColor": bg}))

    return html.Div(
        [
            html.Table(
                [html.Thead([group, sub]), html.Tbody(body)],
                style={
                    "borderCollapse": "collapse",
                    "width": "auto",
                    "fontSize": "12px",
                    "fontFamily": "Calibri, Arial, sans-serif",
                },
            ),
            _constraint_key(flow),
            html.P(
                "Each day is the sites inj/wdr curve at the current fill, minus "
                "Commodity Essentials maintenance. The result is floored at zero. "
                "Jemgum uses the Jemgum site curve scaled by the Astora share of capacity.",
                style=_NOTE,
            ),
        ],
        style={"overflowX": "auto"},
    )


def _out_value(outages: pd.DataFrame, day, site_key: str, field: str) -> float | None:
    col = (site_key, field)
    if outages is None or outages.empty or col not in outages.columns:
        return None
    if day not in outages.index:
        return None
    val = outages.at[day, col]
    if isinstance(val, pd.Series):
        val = val.iloc[-1]
    if pd.isna(val):
        return None
    return float(val)


def _constraint_key(flow: str) -> html.Div:
    return html.Div(
        [
            html.Span(
                style={
                    "display": "inline-block",
                    "width": "14px",
                    "height": "14px",
                    "backgroundColor": PARTIAL_CELL_BG,
                    "border": f"1px solid {PARTIAL_CELL_COLOR}",
                    "marginRight": "8px",
                    "verticalAlign": "middle",
                }
            ),
            html.Span(
                f"Yellow cell: maintenance or a constraint that day. "
                f"The number is available {flow}. Hover a cell for the curve and the outage.",
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "verticalAlign": "middle",
                },
            ),
        ],
        style={"marginTop": "8px"},
    )


def _rate_cell(
    curve: float | None,
    outage: float | None,
    restricted: float | None,
    unit: str,
) -> tuple[html.Td, float | None]:
    avail = available_rate(curve, outage, restricted)
    maint = outage if outage is not None and outage >= _MAINT_MIN else None
    flow = "TWh/d" if unit == UNIT_TWH else "mcm/d"
    style = dict(_TD)
    if maint is not None:
        style["backgroundColor"] = PARTIAL_CELL_BG
        style["color"] = PARTIAL_CELL_COLOR
        title = "\n".join(
            [
                f"Available: {_fmt(avail, unit)} {flow}",
                f"Curve at latest fill: {_fmt(curve, unit)} {flow}",
                f"Maintenance: {_fmt(maint, unit)} {flow}",
                "Available = curve − maintenance",
            ]
        )
    else:
        title = "\n".join(
            [
                f"Available: {_fmt(avail, unit)} {flow}",
                f"Curve at latest fill: {_fmt(curve, unit)} {flow}",
                "No maintenance published",
            ]
        )
    return html.Td(_fmt(avail, unit), style=style, title=title), avail


def _plain_cell(mcm: float | None, unit: str) -> html.Td:
    return html.Td(_fmt(mcm, unit), style={**_TD, "fontWeight": "600"})


def build_availability_section(
    frame: pd.DataFrame,
    *,
    unit: str,
    as_of,
    n_days: int = SEFE_AVAIL_DAYS,
    refresh_token: int = 0,
) -> html.Div:
    """Load curves and CE outages, then render the forward availability table."""
    fills = fill_snapshot(frame, as_of)
    params, outages, parent_caps = get_cached_availability_inputs(refresh_token)
    curves = curves_at_latest_fill(params, fills, parent_caps)
    return render_availability(
        curves, outages, unit=unit, as_of=as_of, n_days=n_days
    )


def availability_inputs_from_payload(
    payload: dict | None,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[int, float]] | None:
    """Copy curves and outages stored on a ``gas_data_ce`` payload."""
    if not payload or "sefe_curve_params" not in payload:
        return None
    params = payload.get("sefe_curve_params")
    outages = payload.get("sefe_outages")
    caps = payload.get("sefe_parent_caps") or {}
    if not isinstance(params, pd.DataFrame):
        return None
    if not isinstance(outages, pd.DataFrame):
        outages = pd.DataFrame()
    if not isinstance(caps, dict):
        caps = {}
    return (
        params.copy(),
        outages.copy(),
        {int(k): float(v) for k, v in caps.items()},
    )


def get_cached_availability_inputs(
    refresh_token: int = 0,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[int, float]]:
    """Curves and CE outages from the CE cache.

    ``refresh_token`` is ignored. A page refresh re-reads the scheduled cache.
    """
    del refresh_token
    cached = _availability_from_ce_cache()
    if cached is not None:
        return cached
    with _CACHE_LOCK:
        fallback = _FALLBACK_INPUTS["bundle"]
        if fallback is not None:
            params, outages, caps = fallback
            return params.copy(), outages.copy(), dict(caps)
    bundle = _load_availability_inputs()
    with _CACHE_LOCK:
        _FALLBACK_INPUTS["bundle"] = bundle
    params, outages, caps = bundle
    return params.copy(), outages.copy(), dict(caps)


def _availability_from_ce_cache():
    try:
        from core.gas_storage_summary.data import get_cached_ce_payload

        payload = get_cached_ce_payload()
    except RuntimeError:
        return None
    return availability_inputs_from_payload(payload)


def _load_availability_inputs() -> tuple[pd.DataFrame, pd.DataFrame, dict[int, float]]:
    from jain_commods.fundamental.gas.storage_params import (
        load_latest_params,
        load_sites_timeseries,
    )

    curve_ids = sorted(
        {
            int(site.curve_data_id or site.data_id)
            for site in SEFE_SITES
        }
        | {int(site.data_id) for site in SEFE_SITES}
    )
    params = load_latest_params(data_ids=curve_ids, logintype=LOGINTYPE)
    parent_caps = _parent_capacities(load_sites_timeseries)
    try:
        outages = outage_frame_from_ce(_fetch_ce_outages())
    except Exception:
        logger.exception("SEFE CE outage query failed")
        outages = outage_frame_from_ce(None)
    return params, outages, parent_caps


def _parent_capacities(load_sites_timeseries) -> dict[int, float]:
    """Latest working capacity for curves that are scaled onto a smaller site."""
    parent_ids = sorted(
        {
            int(site.curve_data_id)
            for site in SEFE_SITES
            if site.curve_data_id and int(site.curve_data_id) != int(site.data_id)
        }
    )
    if not parent_ids:
        return {}
    start = datetime.now() - timedelta(days=21)
    raw = load_sites_timeseries(parent_ids, start_date=start, logintype=LOGINTYPE)
    caps: dict[int, float] = {}
    for parent_id, df in (raw or {}).items():
        if df is None or df.empty:
            continue
        work = df.copy()
        work.columns = [str(c).lower() for c in work.columns]
        if "stockcapacity" not in work.columns:
            continue
        series = pd.to_numeric(work["stockcapacity"], errors="coerce").dropna()
        if not series.empty:
            caps[int(parent_id)] = float(series.iloc[-1])
    return caps


def _fetch_ce_outages() -> pd.DataFrame:
    import os

    from jain_commods.core.interfaces.commodityessentials import CElink

    from core.gas_data_ce.constants import CE_PASS_ENV, CE_USER_ENV

    user = (os.getenv(CE_USER_ENV) or "").strip()
    password = (os.getenv(CE_PASS_ENV) or "").strip()
    if not user or not password:
        raise RuntimeError(
            f"Commodity Essentials credentials missing ({CE_USER_ENV} / {CE_PASS_ENV})."
        )
    today = pd.Timestamp.now().normalize()
    end = today + pd.Timedelta(days=SEFE_AVAIL_DAYS_MAX + 5)
    assets = ",".join(str(site.asset_id) for site in SEFE_SITES)
    ce = CElink(user, password)
    return ce.eugasout(
        assets=assets,
        unit="mcm",
        variable="injection,withdrawal",
        dateFrom=today.strftime("%d_%b_%Y"),
        dateTo=end.strftime("%d_%b_%Y"),
    )
