"""Daily storage activity table (ported from eu_gas_storage report)."""
from __future__ import annotations

from datetime import datetime

import numpy as np
import pandas as pd
from dash import html

from core.gas_data_ce.partial_storage import (
    PARTIAL_CELL_BG,
    PARTIAL_CELL_COLOR,
    PARTIAL_STORAGE_NOTE,
    apply_partial_storage,
    coverage_tooltip,
)
from core.gas_storage_summary.constants import (
    COUNTRY_CODES,
    DEFAULT_MULTI_COUNTRIES,
    TABLE_N_DAYS,
)
from core.styles import COLORS


def _resolve_table_countries(countries: list[str] | None) -> list[str]:
    """Selected country codes + trailing Total for summary tables."""
    codes = [c for c in (countries or []) if c in COUNTRY_CODES]
    if not codes:
        codes = list(DEFAULT_MULTI_COUNTRIES)
    # Preserve canonical COUNTRY_CODES order.
    ordered = [c for c in COUNTRY_CODES if c in codes]
    return ordered + ["Total"]


def _injection_total(df_inj: pd.DataFrame, dt, codes: list[str]) -> float | None:
    """Sum selected country injection columns for one date."""
    vals = []
    for country in codes:
        if country not in df_inj.columns:
            continue
        try:
            val = df_inj.loc[dt, country]
        except KeyError:
            continue
        if pd.notna(val):
            vals.append(float(val))
    if not vals:
        return None
    return float(sum(vals))


def _fill_stock_capacity(
    df_fill: pd.DataFrame,
    dt,
    country: str,
    codes: list[str],
) -> tuple[float | None, float | None]:
    """Return (stock, capacity) for a country or filtered Total."""
    try:
        if country == "Total":
            stocks: list[float] = []
            caps: list[float] = []
            for code in codes:
                stock_col = f"{code}|stock"
                cap_col = f"{code}|stockCapacity"
                if stock_col not in df_fill.columns or cap_col not in df_fill.columns:
                    continue
                stock = df_fill.loc[dt, stock_col]
                capacity = df_fill.loc[dt, cap_col]
                if pd.notna(stock):
                    stocks.append(float(stock))
                if pd.notna(capacity):
                    caps.append(float(capacity))
            if not stocks and not caps:
                return None, None
            stock_sum = float(sum(stocks)) if stocks else None
            cap_sum = float(sum(caps)) if caps else None
            return stock_sum, cap_sum

        stock = df_fill.loc[dt, f"{country}|stock"]
        capacity = df_fill.loc[dt, f"{country}|stockCapacity"]
        return (
            float(stock) if pd.notna(stock) else None,
            float(capacity) if pd.notna(capacity) else None,
        )
    except KeyError:
        return None, None


def _lookup_coverage(coverage: pd.DataFrame | None, day, country: str):
    if coverage is None or coverage.empty or not isinstance(coverage.index, pd.MultiIndex):
        return None
    key = (pd.Timestamp(day).normalize(), country)
    if key not in coverage.index:
        return None
    row = coverage.loc[key]
    if isinstance(row, pd.DataFrame):
        row = row.iloc[0]
    missing = row["missing_sites"]
    if missing is None or (not isinstance(missing, (tuple, list)) and pd.isna(missing)):
        missing = ()
    return int(row["n_sites"]), tuple(missing)


def _partial_tooltip(
    coverage: pd.DataFrame | None,
    day,
    country: str,
    codes: list[str],
) -> str | None:
    """Hover text listing sites that have not reported yet."""
    if country == "Total":
        blocks = []
        for code in codes:
            found = _lookup_coverage(coverage, day, code)
            if not found:
                continue
            blocks.append(f"{code}\n{coverage_tooltip(*found)}")
        return "\n\n".join(blocks) if blocks else None
    found = _lookup_coverage(coverage, day, country)
    if not found:
        return None
    return coverage_tooltip(*found)


def build_daily_activity_table(
    df_inj: pd.DataFrame,
    to_date: datetime | pd.Timestamp | None = None,
    n_days: int = TABLE_N_DAYS,
    countries: list[str] | None = None,
    partial: pd.DataFrame | None = None,
    coverage: pd.DataFrame | None = None,
) -> html.Div:
    """Build a portal-styled HTML table of the last *n_days* of net injection."""
    to_date = pd.Timestamp(to_date or datetime.now()).normalize()
    current_year = to_date.year
    display_countries = _resolve_table_countries(countries)
    codes = [c for c in display_countries if c != "Total"]

    if df_inj is None or df_inj.empty:
        return html.Div(
            "No injection data available.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )

    latest_date = df_inj.index.max()
    if pd.isna(latest_date):
        return html.Div(
            "No injection data available.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )
    if latest_date > to_date:
        clipped = df_inj.loc[:to_date]
        if clipped.empty:
            return html.Div(
                "No injection data on or before today.",
                style={"color": COLORS["text_muted"], "fontSize": "13px"},
            )
        latest_date = clipped.index.max()

    df_inj = df_inj.copy()
    filled = apply_partial_storage(df_inj, partial)
    partial_cells: set[tuple[pd.Timestamp, str]] = set()
    for country in filled.columns:
        flagged = filled.index[filled[country].fillna(False).astype(bool)]
        for dt in flagged:
            partial_cells.add((pd.Timestamp(dt).normalize(), str(country)))

    start_date = latest_date - pd.Timedelta(days=n_days - 1)
    date_range = pd.date_range(start=start_date, end=latest_date, freq="D")

    def _avg_5yr(day_of_year: int) -> float | None:
        values = []
        for year_offset in range(1, 6):
            year = current_year - year_offset
            try:
                target = pd.Timestamp(f"{year}-01-01") + pd.Timedelta(days=day_of_year - 1)
                if target in df_inj.index:
                    val = _injection_total(df_inj, target, codes)
                    if val is not None:
                        values.append(val)
            except Exception:
                continue
        return float(np.mean(values)) if values else None

    header = html.Tr(
        [
            html.Th("Date", style=_TH),
            *[html.Th(c, style=_TH) for c in display_countries],
            html.Th("5yr Avg", style=_TH),
            html.Th("Δ vs Avg", style=_TH),
        ]
    )

    rows = []
    for date in date_range:
        if date not in df_inj.index:
            continue

        is_weekend = date.dayofweek >= 5
        bg = COLORS["card_bg_alt"] if is_weekend else COLORS["card_bg"]

        cells = [
            html.Td(date.strftime("%d-%b-%Y"), style={**_TD, "whiteSpace": "nowrap", "textAlign": "left"}),
        ]
        row_vals: dict[str, float | None] = {}
        for country in display_countries:
            if country == "Total":
                row_vals[country] = _injection_total(df_inj, date, codes)
            else:
                try:
                    val = df_inj.loc[date, country]
                    row_vals[country] = float(val) if pd.notna(val) else None
                except KeyError:
                    row_vals[country] = None

            display = f"{row_vals[country]:,.0f}" if row_vals[country] is not None else ""
            weight = "600" if country == "Total" else "400"
            day = pd.Timestamp(date).normalize()
            is_partial = (day, country) in partial_cells or (
                country == "Total" and any((day, code) in partial_cells for code in codes)
            )
            cell_style = {**_TD, "fontWeight": weight, "textAlign": "right"}
            tooltip = None
            if is_partial:
                cell_style["color"] = PARTIAL_CELL_COLOR
                cell_style["backgroundColor"] = PARTIAL_CELL_BG
                cell_style["fontWeight"] = "600"
                cell_style["cursor"] = "help"
                tooltip = _partial_tooltip(coverage, day, country, codes)
            cell_kwargs = {"title": tooltip} if tooltip else {}
            cells.append(html.Td(display, style=cell_style, **cell_kwargs))

        avg_5yr = _avg_5yr(int(date.dayofyear))
        avg_str = f"{avg_5yr:,.0f}" if avg_5yr is not None else ""
        cells.append(html.Td(avg_str, style={**_TD, "textAlign": "right", "color": COLORS["text_muted"]}))

        total_val = row_vals.get("Total")
        if total_val is not None and avg_5yr is not None:
            delta = total_val - avg_5yr
            delta_str = f"{delta:+,.0f}"
            if delta > 0:
                delta_color = COLORS["accent_green"]
            elif delta < 0:
                delta_color = COLORS["danger"]
            else:
                delta_color = COLORS["text_primary"]
        else:
            delta_str = ""
            delta_color = COLORS["text_primary"]

        cells.append(
            html.Td(
                delta_str,
                style={**_TD, "textAlign": "right", "color": delta_color, "fontWeight": "600"},
            )
        )

        rows.append(html.Tr(cells, style={"backgroundColor": bg}))

    return html.Div(
        [
            html.Table(
                [html.Thead(header), html.Tbody(rows)],
                style={
                    "borderCollapse": "collapse",
                    "width": "auto",
                    "tableLayout": "auto",
                    "fontSize": "12px",
                    "fontFamily": "Calibri, Arial, sans-serif",
                },
            ),
            html.P(
                "Values in mcm. Positive = injections, negative = withdrawals. "
                "Shaded rows = weekends. Empty cells = data not yet published.",
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "marginTop": "8px",
                    "marginBottom": "4px",
                    "fontStyle": "italic",
                    "maxWidth": "720px",
                },
            ),
            html.P(
                PARTIAL_STORAGE_NOTE + " Hover an amber cell to see which sites are still missing.",
                style={
                    "fontSize": "11px",
                    "color": PARTIAL_CELL_COLOR,
                    "marginTop": "0",
                    "fontStyle": "italic",
                    "maxWidth": "720px",
                },
            ),
        ],
        style={"overflowX": "auto", "display": "inline-block", "maxWidth": "100%"},
    )


def build_fill_pct_table(
    df_fill: pd.DataFrame,
    to_date: datetime | pd.Timestamp | None = None,
    countries: list[str] | None = None,
) -> html.Div:
    """
    Current fill % vs 3/5/7yr same-day averages (ported from eu_gas_storage report).
    """
    to_date = pd.Timestamp(to_date or datetime.now()).normalize()
    current_year = to_date.year
    display_countries = _resolve_table_countries(countries)
    codes = [c for c in display_countries if c != "Total"]

    if df_fill is None or df_fill.empty:
        return html.Div(
            "No fill data available.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )

    latest_date = df_fill.index.max()
    if pd.isna(latest_date):
        return html.Div(
            "No fill data available.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )
    if latest_date > to_date:
        clipped = df_fill.loc[:to_date]
        if clipped.empty:
            return html.Div(
                "No fill data on or before today.",
                style={"color": COLORS["text_muted"], "fontSize": "13px"},
            )
        latest_date = clipped.index.max()

    latest_doy = int(latest_date.dayofyear)

    def _fill_pct(dt, country: str) -> float | None:
        stock, capacity = _fill_stock_capacity(df_fill, dt, country, codes)
        if stock is None or capacity is None or capacity == 0:
            return None
        return float(stock) / float(capacity) * 100.0

    def _avg_fill(country: str, n_years: int) -> float | None:
        values = []
        for year_offset in range(1, n_years + 1):
            year = current_year - year_offset
            try:
                target = pd.Timestamp(f"{year}-01-01") + pd.Timedelta(days=latest_doy - 1)
                if target in df_fill.index:
                    pct = _fill_pct(target, country)
                    if pct is not None:
                        values.append(pct)
            except Exception:
                continue
        return float(np.mean(values)) if values else None

    def _avg_color(current: float | None, avg: float | None) -> str:
        if current is None or avg is None:
            return COLORS["text_primary"]
        diff = current - avg
        if diff > 2:
            return COLORS["accent_green"]
        if diff < -2:
            return COLORS["danger"]
        return COLORS["text_primary"]

    date_str = latest_date.strftime("%d %b")
    header = html.Tr(
        [
            html.Th("Country", style={**_TH, "textAlign": "left"}),
            html.Th(f"Current ({date_str})", style=_TH),
            html.Th("3yr Avg", style=_TH),
            html.Th("5yr Avg", style=_TH),
            html.Th("7yr Avg", style=_TH),
        ]
    )

    rows = []
    for i, country in enumerate(display_countries):
        current = _fill_pct(latest_date, country)
        avg3 = _avg_fill(country, 3)
        avg5 = _avg_fill(country, 5)
        avg7 = _avg_fill(country, 7)
        is_total = country == "Total"
        weight = "600" if is_total else "400"
        bg = COLORS["card_bg_alt"] if i % 2 else COLORS["card_bg"]

        def _fmt(v: float | None) -> str:
            return f"{v:.0f}%" if v is not None else "–"

        rows.append(
            html.Tr(
                [
                    html.Td(
                        country,
                        style={**_TD, "textAlign": "left", "fontWeight": weight},
                    ),
                    html.Td(
                        _fmt(current),
                        style={**_TD, "textAlign": "center", "fontWeight": weight},
                    ),
                    html.Td(
                        _fmt(avg3),
                        style={
                            **_TD,
                            "textAlign": "center",
                            "color": _avg_color(current, avg3),
                        },
                    ),
                    html.Td(
                        _fmt(avg5),
                        style={
                            **_TD,
                            "textAlign": "center",
                            "color": _avg_color(current, avg5),
                        },
                    ),
                    html.Td(
                        _fmt(avg7),
                        style={
                            **_TD,
                            "textAlign": "center",
                            "color": _avg_color(current, avg7),
                        },
                    ),
                ],
                style={"backgroundColor": bg},
            )
        )

    return html.Div(
        [
            html.Table(
                [html.Thead(header), html.Tbody(rows)],
                style={
                    "borderCollapse": "collapse",
                    "width": "auto",
                    "tableLayout": "auto",
                    "fontSize": "12px",
                    "fontFamily": "Calibri, Arial, sans-serif",
                },
            ),
            html.Div(
                [
                    html.P(
                        "Fill % vs same calendar day in prior years.",
                        style={
                            "fontSize": "11px",
                            "color": COLORS["text_muted"],
                            "marginTop": "8px",
                            "marginBottom": "0",
                            "fontStyle": "italic",
                            "maxWidth": "420px",
                        },
                    ),
                    html.P(
                        "Green / red = current more than 2pp above / below that average.",
                        style={
                            "fontSize": "11px",
                            "color": COLORS["text_muted"],
                            "marginTop": "2px",
                            "marginBottom": "0",
                            "fontStyle": "italic",
                            "maxWidth": "420px",
                        },
                    ),
                ]
            ),
        ],
        style={"overflowX": "auto", "display": "inline-block", "maxWidth": "100%"},
    )


def _latest_fill_date(
    df_fill: pd.DataFrame,
    to_date: pd.Timestamp,
) -> pd.Timestamp | None:
    if df_fill is None or df_fill.empty:
        return None
    latest_date = df_fill.index.max()
    if pd.isna(latest_date):
        return None
    if latest_date > to_date:
        clipped = df_fill.loc[:to_date]
        if clipped.empty:
            return None
        latest_date = clipped.index.max()
    return latest_date


def build_fill_bcm_table(
    df_fill: pd.DataFrame,
    to_date: datetime | pd.Timestamp | None = None,
    countries: list[str] | None = None,
) -> html.Div:
    """Absolute stock (bcm) vs 3/5/7yr same-day averages for each country + Total."""
    to_date = pd.Timestamp(to_date or datetime.now()).normalize()
    current_year = to_date.year
    display_countries = _resolve_table_countries(countries)
    codes = [c for c in display_countries if c != "Total"]

    if df_fill is None or df_fill.empty:
        return html.Div(
            "No fill data available.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )

    latest_date = _latest_fill_date(df_fill, to_date)
    if latest_date is None:
        return html.Div(
            "No fill data on or before today.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )

    latest_doy = int(latest_date.dayofyear)

    def _stock_bcm(dt, country: str) -> float | None:
        stock, _capacity = _fill_stock_capacity(df_fill, dt, country, codes)
        if stock is None:
            return None
        return float(stock) / 1000.0

    def _avg_stock(country: str, n_years: int) -> float | None:
        values = []
        for year_offset in range(1, n_years + 1):
            year = current_year - year_offset
            try:
                target = pd.Timestamp(f"{year}-01-01") + pd.Timedelta(days=latest_doy - 1)
                if target in df_fill.index:
                    bcm = _stock_bcm(target, country)
                    if bcm is not None:
                        values.append(bcm)
            except Exception:
                continue
        return float(np.mean(values)) if values else None

    def _avg_color(current: float | None, avg: float | None) -> str:
        if current is None or avg is None or avg == 0:
            return COLORS["text_primary"]
        # Same spirit as fill %: >2pp equivalent ≈ ~2% relative for levels
        rel = (current - avg) / abs(avg) * 100.0
        if rel > 2:
            return COLORS["accent_green"]
        if rel < -2:
            return COLORS["danger"]
        return COLORS["text_primary"]

    date_str = latest_date.strftime("%d %b")
    header = html.Tr(
        [
            html.Th("Country", style={**_TH, "textAlign": "left"}),
            html.Th(f"Current ({date_str})", style=_TH),
            html.Th("3yr Avg", style=_TH),
            html.Th("5yr Avg", style=_TH),
            html.Th("7yr Avg", style=_TH),
        ]
    )

    rows = []
    for i, country in enumerate(display_countries):
        current = _stock_bcm(latest_date, country)
        avg3 = _avg_stock(country, 3)
        avg5 = _avg_stock(country, 5)
        avg7 = _avg_stock(country, 7)
        is_total = country == "Total"
        weight = "600" if is_total else "400"
        bg = COLORS["card_bg_alt"] if i % 2 else COLORS["card_bg"]

        def _fmt(v: float | None) -> str:
            return f"{v:.1f}" if v is not None else "–"

        rows.append(
            html.Tr(
                [
                    html.Td(
                        country,
                        style={**_TD, "textAlign": "left", "fontWeight": weight},
                    ),
                    html.Td(
                        _fmt(current),
                        style={**_TD, "textAlign": "right", "fontWeight": weight},
                    ),
                    html.Td(
                        _fmt(avg3),
                        style={
                            **_TD,
                            "textAlign": "right",
                            "color": _avg_color(current, avg3),
                        },
                    ),
                    html.Td(
                        _fmt(avg5),
                        style={
                            **_TD,
                            "textAlign": "right",
                            "color": _avg_color(current, avg5),
                        },
                    ),
                    html.Td(
                        _fmt(avg7),
                        style={
                            **_TD,
                            "textAlign": "right",
                            "color": _avg_color(current, avg7),
                        },
                    ),
                ],
                style={"backgroundColor": bg},
            )
        )

    return html.Div(
        [
            html.Table(
                [html.Thead(header), html.Tbody(rows)],
                style={
                    "borderCollapse": "collapse",
                    "width": "auto",
                    "tableLayout": "auto",
                    "fontSize": "12px",
                    "fontFamily": "Calibri, Arial, sans-serif",
                },
            ),
            html.Div(
                [
                    html.P(
                        "Stock (bcm) vs same calendar day in prior years.",
                        style={
                            "fontSize": "11px",
                            "color": COLORS["text_muted"],
                            "marginTop": "8px",
                            "marginBottom": "0",
                            "fontStyle": "italic",
                            "maxWidth": "420px",
                        },
                    ),
                    html.P(
                        "Green / red = current more than 2% above / below that average.",
                        style={
                            "fontSize": "11px",
                            "color": COLORS["text_muted"],
                            "marginTop": "2px",
                            "marginBottom": "0",
                            "fontStyle": "italic",
                            "maxWidth": "420px",
                        },
                    ),
                ]
            ),
        ],
        style={"overflowX": "auto", "display": "inline-block", "maxWidth": "100%"},
    )


_TH = {
    "padding": "6px 8px",
    "textAlign": "center",
    "backgroundColor": COLORS["table_header_bg"],
    "color": COLORS["text_dark"],
    "fontWeight": "600",
    "border": f"1px solid {COLORS['border_light']}",
    "fontSize": "11px",
    "whiteSpace": "nowrap",
}

_TD = {
    "padding": "4px 8px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "color": COLORS["text_primary"],
    "whiteSpace": "nowrap",
}
