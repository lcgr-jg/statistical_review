"""EU Gas Balance — Storage Summary callbacks."""
from __future__ import annotations

import logging
from datetime import datetime

import pandas as pd
from dash import Input, Output, callback, html

from core.gas_storage_summary.charts import (
    build_cumulative_season_chart,
    build_daily_storage_action_chart,
    build_season_comparison_chart,
    build_yoy_fill_chart,
)
from core.gas_storage_summary.constants import (
    COUNTRY_CODES,
    DEFAULT_GAS_YEAR,
    DEFAULT_MULTI_COUNTRIES,
    FILL_HISTORY_YEAR_MIN,
    GAS_YEAR_MIN,
    RANGE_POST_UKRAINE,
    SEASON_INJECTION,
    TABLE_N_DAYS,
    TABLE_N_DAYS_MAX,
    TABLE_N_DAYS_MIN,
    UNIT_MCM,
    YEAR_BASIS_CALENDAR,
    YEAR_BASIS_GAS,
    current_gas_year,
    default_fill_years,
    default_sefe_cum_start,
    fill_year_options,
    gas_year_start,
    resolve_season_mode,
    season_end,
    season_start,
    year_label,
    yoy_current_year,
)
from core.gas_storage_summary.data import (
    format_ce_refresh_age,
    get_cached_partial_bundle,
    get_cached_fill,
    get_cached_injection,
    get_ce_last_refresh,
)
from core.gas_storage_summary.sefe import (
    build_sefe_tracker_parts,
    get_cached_sefe_frame,
    latest_data_date,
    sefe_subtitle,
)
from core.gas_storage_summary.sefe_availability import build_availability_section
from core.gas_storage_summary.table import (
    build_daily_activity_table,
    build_fill_bcm_table,
    build_fill_pct_table,
)
from core.styles import get_status_badge_style

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "12px 16px",
            "borderRadius": "8px",
            "fontSize": "13px",
            "width": "100%",
        },
    )


def _status_message(latest_data_date) -> str:
    refresh = get_ce_last_refresh()
    return (
        f"Loaded CE gas data through {latest_data_date.strftime('%d-%b-%Y')} · "
        f"{format_ce_refresh_age(refresh)}"
    )


def _parse_gas_year(value) -> int:
    try:
        year = int(value)
    except (TypeError, ValueError):
        return DEFAULT_GAS_YEAR
    end = max(current_gas_year(), DEFAULT_GAS_YEAR)
    return max(GAS_YEAR_MIN, min(end, year))


def _parse_n_days(value) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return TABLE_N_DAYS
    return max(TABLE_N_DAYS_MIN, min(TABLE_N_DAYS_MAX, n))


def _parse_daily_action_country(value) -> str:
    if value in COUNTRY_CODES:
        return value
    return "Total"


def _parse_multi_countries(value) -> list[str]:
    if isinstance(value, str):
        value = [value]
    codes = [c for c in (value or []) if c in COUNTRY_CODES]
    return codes or list(DEFAULT_MULTI_COUNTRIES)


def _load_injection():
    return get_cached_injection()


@callback(
    Output("gas-stor-sum-table", "children"),
    Output("gas-stor-sum-table-subtitle", "children"),
    Output("gas-stor-sum-fill-table", "children"),
    Output("gas-stor-sum-fill-subtitle", "children"),
    Output("gas-stor-sum-fill-bcm-table", "children"),
    Output("gas-stor-sum-fill-bcm-subtitle", "children"),
    Output("gas-stor-sum-status", "children"),
    Input("gas-stor-sum-refresh", "n_clicks"),
    Input("gas-stor-sum-table-days", "value"),
    Input("gas-stor-sum-table-countries", "value"),
    prevent_initial_call=False,
)
def update_activity_table(_n_clicks, table_days, table_countries):
    n_days = _parse_n_days(table_days)
    countries = _parse_multi_countries(table_countries)
    try:
        df_inj = _load_injection()
        df_fill = get_cached_fill()
        partial, coverage = get_cached_partial_bundle()
    except Exception as exc:
        logger.exception("Storage Summary tables: %s", exc)
        err = _alert(str(exc), "error")
        return (
            err,
            f"Last {n_days} days · mcm/d",
            err,
            "vs prior-year same day",
            err,
            "vs prior-year same day",
            err,
        )

    to_date = datetime.now()
    table = build_daily_activity_table(
        df_inj,
        to_date=to_date,
        n_days=n_days,
        countries=countries,
        partial=partial,
        coverage=coverage,
    )
    fill_table = build_fill_pct_table(df_fill, to_date=to_date, countries=countries)
    fill_bcm_table = build_fill_bcm_table(df_fill, to_date=to_date, countries=countries)
    latest = df_inj.index.max()
    fill_latest = df_fill.index.max()
    if fill_latest > pd.Timestamp(to_date):
        fill_latest = df_fill.loc[: pd.Timestamp(to_date)].index.max()
    status = _alert(_status_message(latest), "success")
    subtitle = f"Last {n_days} days · through {latest.strftime('%d-%b-%Y')} · mcm/d"
    as_of = f"as of {fill_latest.strftime('%d-%b-%Y')}"
    fill_sub = f"{as_of} · vs same day prior years"
    fill_bcm_sub = f"{as_of} · vs same day prior years"
    return table, subtitle, fill_table, fill_sub, fill_bcm_table, fill_bcm_sub, status


def _parse_sefe_start(value):
    if value:
        try:
            return pd.Timestamp(value).date()
        except (TypeError, ValueError):
            pass
    return default_sefe_cum_start()


@callback(
    Output("gas-stor-sum-sefe-daily", "children"),
    Output("gas-stor-sum-sefe-cum", "children"),
    Output("gas-stor-sum-sefe-fill", "children"),
    Output("gas-stor-sum-sefe-avail", "children"),
    Output("gas-stor-sum-sefe-subtitle", "children"),
    Input("gas-stor-sum-refresh", "n_clicks"),
    Input("gas-stor-sum-sefe-start", "date"),
    Input("gas-stor-sum-sefe-days", "value"),
    Input("gas-stor-sum-sefe-avail-days", "value"),
    prevent_initial_call=False,
)
def update_sefe_tracker(_n_clicks, start_value, days_value, avail_days_value):
    unit = UNIT_MCM
    n_days = _parse_n_days(days_value)
    n_forward = _parse_n_days(avail_days_value)
    start = _parse_sefe_start(start_value)
    blank = html.Div()
    try:
        frame = get_cached_sefe_frame(_n_clicks or 0)
    except Exception as exc:
        logger.exception("Storage Summary SEFE tracker: %s", exc)
        err = _alert(str(exc), "error")
        return err, blank, blank, blank, sefe_subtitle(None, unit, n_days)

    to_date = datetime.now()
    daily, cumulative, fill = build_sefe_tracker_parts(
        frame,
        unit=unit,
        start=start,
        n_days=n_days,
        as_of=to_date,
    )
    try:
        availability = build_availability_section(
            frame,
            unit=unit,
            as_of=to_date,
            n_days=n_forward,
            refresh_token=_n_clicks or 0,
        )
    except Exception as exc:
        logger.exception("Storage Summary SEFE availability: %s", exc)
        availability = _alert(str(exc), "warning")
    latest = latest_data_date(frame, to_date)
    return daily, cumulative, fill, availability, sefe_subtitle(latest, unit, n_days)


@callback(
    Output("gas-stor-sum-chart", "figure"),
    Output("gas-stor-sum-chart-subtitle", "children"),
    Input("gas-stor-sum-refresh", "n_clicks"),
    Input("gas-stor-sum-gas-year", "value"),
    Input("gas-stor-sum-action-country", "value"),
    prevent_initial_call=False,
)
def update_daily_action_chart(_n_clicks, gas_year_value, country_value):
    gas_year = _parse_gas_year(gas_year_value)
    start = gas_year_start(gas_year)
    country = _parse_daily_action_country(country_value)
    try:
        df_inj = _load_injection()
    except Exception as exc:
        logger.exception("Storage Summary daily chart: %s", exc)
        return build_daily_storage_action_chart(pd.DataFrame(), start, country=country), ""

    to_date = datetime.now()
    fig = build_daily_storage_action_chart(
        df_inj, start_date=start, to_date=to_date, country=country
    )
    scope = "All" if country == "Total" else country
    subtitle = (
        f"{scope} · GY {gas_year} (from {start.strftime('%d-%b-%Y')}) → "
        f"{to_date.strftime('%d-%b-%Y')} · mcm/d"
    )
    return fig, subtitle


@callback(
    Output("gas-stor-sum-season-chart", "figure"),
    Output("gas-stor-sum-season-title", "children"),
    Output("gas-stor-sum-season-subtitle", "children"),
    Input("gas-stor-sum-refresh", "n_clicks"),
    Input("gas-stor-sum-season-mode", "value"),
    Input("gas-stor-sum-season-countries", "value"),
    prevent_initial_call=False,
)
def update_season_chart(_n_clicks, season_mode, countries_value):
    kind, anchor_year = resolve_season_mode(season_mode)
    is_injection = (season_mode or SEASON_INJECTION) == SEASON_INJECTION
    title = "Injection Since 1 Apr" if is_injection else "Withdrawals Since 1 Oct"
    window_start = season_start(kind, anchor_year)
    window_end = season_end(kind, anchor_year)
    countries = _parse_multi_countries(countries_value)

    try:
        df_inj = _load_injection()
    except Exception as exc:
        logger.exception("Storage Summary season chart: %s", exc)
        return (
            build_season_comparison_chart(
                pd.DataFrame(), kind, anchor_year, countries=countries
            ),
            title,
            "",
        )

    to_date = datetime.now()
    fig = build_season_comparison_chart(
        df_inj, kind, anchor_year, to_date=to_date, countries=countries
    )
    subtitle = (
        f"{window_start.strftime('%d %b %Y')} → "
        f"{min(to_date.date(), window_end).strftime('%d %b %Y')} · "
        f"YoY · bcm · "
        f"{'positive = injections' if is_injection else 'positive = withdrawals'}"
    )
    return fig, title, subtitle


@callback(
    Output("gas-stor-sum-cum-chart", "figure"),
    Output("gas-stor-sum-cum-title", "children"),
    Output("gas-stor-sum-cum-subtitle", "children"),
    Input("gas-stor-sum-refresh", "n_clicks"),
    Input("gas-stor-sum-cum-mode", "value"),
    Input("gas-stor-sum-cum-countries", "value"),
    prevent_initial_call=False,
)
def update_cumulative_chart(_n_clicks, season_mode, countries_value):
    kind, anchor_year = resolve_season_mode(season_mode)
    is_injection = (season_mode or SEASON_INJECTION) == SEASON_INJECTION
    title = (
        "Cumulative Injection Path"
        if is_injection
        else "Cumulative Withdrawal Path"
    )
    window_start = season_start(kind, anchor_year)
    window_end = season_end(kind, anchor_year)
    countries = _parse_multi_countries(countries_value)

    try:
        df_inj = _load_injection()
    except Exception as exc:
        logger.exception("Storage Summary cumulative chart: %s", exc)
        return (
            build_cumulative_season_chart(
                pd.DataFrame(), kind, anchor_year, countries=countries
            ),
            title,
            "",
        )

    to_date = datetime.now()
    fig = build_cumulative_season_chart(
        df_inj, kind, anchor_year, to_date=to_date, countries=countries
    )
    subtitle = (
        f"{window_start.strftime('%d %b %Y')} → {window_end.strftime('%d %b %Y')} · "
        f"{anchor_year} through {min(to_date.date(), window_end).strftime('%d %b %Y')} · "
        f"bcm · 3Y/5Y avgs on top panel (excl. 2021)"
    )
    return fig, title, subtitle


def _parse_fill_years(value, basis: str = YEAR_BASIS_CALENDAR) -> list[int]:
    if not value:
        return default_fill_years(basis=basis)
    if isinstance(value, (int, float, str)):
        value = [value]
    current = yoy_current_year(basis)
    out = []
    for v in value:
        try:
            y = int(v)
        except (TypeError, ValueError):
            continue
        if FILL_HISTORY_YEAR_MIN <= y < current:
            out.append(y)
    return sorted(set(out))


def _parse_range_years(value) -> int | str:
    if value == RANGE_POST_UKRAINE:
        return RANGE_POST_UKRAINE
    try:
        n = int(value)
    except (TypeError, ValueError):
        return 0
    return n if n in (0, 3, 5, 7) else 0


def _range_subtitle(range_mode: int | str) -> str:
    if range_mode == RANGE_POST_UKRAINE:
        return "post-Ukraine highlight"
    if isinstance(range_mode, int) and range_mode > 0:
        return f"{range_mode}Y range band"
    return "no range band"


def _parse_year_basis(value) -> str:
    return YEAR_BASIS_GAS if value == YEAR_BASIS_GAS else YEAR_BASIS_CALENDAR


@callback(
    Output("gas-stor-sum-fill-years", "options"),
    Output("gas-stor-sum-fill-years", "value"),
    Input("gas-stor-sum-fill-basis", "value"),
    prevent_initial_call=False,
)
def sync_fill_year_options(basis_value):
    basis = _parse_year_basis(basis_value)
    return fill_year_options(basis=basis), default_fill_years(basis=basis)


@callback(
    Output("gas-stor-sum-fill-yoy-chart", "figure"),
    Output("gas-stor-sum-fill-yoy-subtitle", "children"),
    Input("gas-stor-sum-refresh", "n_clicks"),
    Input("gas-stor-sum-fill-years", "value"),
    Input("gas-stor-sum-fill-range", "value"),
    Input("gas-stor-sum-fill-countries", "value"),
    Input("gas-stor-sum-fill-basis", "value"),
    prevent_initial_call=False,
)
def update_yoy_fill_chart(
    _n_clicks, selected_years, range_years_value, countries_value, basis_value
):
    basis = _parse_year_basis(basis_value)
    years = _parse_fill_years(selected_years, basis=basis)
    range_n = _parse_range_years(range_years_value)
    countries = _parse_multi_countries(countries_value)
    try:
        df_fill = get_cached_fill()
    except Exception as exc:
        logger.exception("Storage Summary YoY fill chart: %s", exc)
        return (
            build_yoy_fill_chart(
                pd.DataFrame(),
                years,
                range_n,
                countries=countries,
                year_basis=basis,
            ),
            "",
        )

    to_date = datetime.now()
    fig = build_yoy_fill_chart(
        df_fill,
        selected_years=years,
        range_years=range_n,
        to_date=to_date,
        countries=countries,
        year_basis=basis,
    )
    year_txt = (
        ", ".join(year_label(y, basis) for y in years) if years else "none"
    )
    range_txt = _range_subtitle(range_n)
    current = year_label(yoy_current_year(basis, to_date.date()), basis)
    basis_txt = "gas year" if basis == YEAR_BASIS_GAS else "calendar"
    subtitle = f"{current} + priors [{year_txt}] · {range_txt} · {basis_txt} · fill %"
    return fig, subtitle
