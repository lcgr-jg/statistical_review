"""Storage Summary — read country injection frames from the CE cache."""
from __future__ import annotations

import logging
import os
import threading
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.cache import dashboard_cache
from core.gas_data_ce.constants import SOURCE_NAME

logger = logging.getLogger(__name__)

# One live site query per cache generation when an older payload has no
# partial values and site-coverage frame yet.
_PARTIAL_MEMO: dict[str, tuple[pd.DataFrame, pd.DataFrame]] = {}
_PARTIAL_LOCK = threading.Lock()


def _parse_fetched_at(raw: Any) -> datetime | None:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw
    try:
        return datetime.fromisoformat(str(raw))
    except ValueError:
        return None


def get_cached_ce_payload() -> dict[str, Any]:
    """Return the full ``gas_data_ce`` cache dict (raises if empty)."""
    data: dict[str, Any] | None = dashboard_cache.get_data(SOURCE_NAME)

    if not data or not isinstance(data, dict):
        raise RuntimeError(
            "Commodity Essentials storage cache is empty. "
            "Wait for warm-up to finish, or check CE_USER / CE_PASS and restart."
        )
    return data


def get_ce_last_refresh(payload: dict[str, Any] | None = None) -> datetime | None:
    """
    When the CE cache was last successfully refreshed.

    Prefers ``fetched_at`` stored in the payload (survives process restart via
    disk cache); falls back to in-memory scheduler metadata.
    """
    if payload is None:
        try:
            payload = get_cached_ce_payload()
        except RuntimeError:
            payload = None

    fetched = _parse_fetched_at(payload.get("fetched_at") if payload else None)
    if fetched is not None:
        return fetched

    return dashboard_cache.get_last_refresh(SOURCE_NAME)


def format_ce_refresh_age(
    when: datetime | None,
    *,
    now: datetime | None = None,
) -> str:
    """Human age string matching the Data Source Status style (e.g. ``2h 15m ago``)."""
    if when is None:
        return "CE refresh time unknown"

    if when.tzinfo is not None:
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        age_min = max(
            0,
            int(
                (
                    now.astimezone(timezone.utc) - when.astimezone(timezone.utc)
                ).total_seconds()
                // 60
            ),
        )
        when_local = when.astimezone()
    else:
        now = now or datetime.now()
        age_min = max(0, int((now - when).total_seconds() // 60))
        when_local = when

    if age_min < 60:
        age_str = f"{age_min}m ago"
    elif age_min < 1440:
        age_str = f"{age_min // 60}h {age_min % 60}m ago"
    else:
        age_str = f"{age_min // 1440}d ago"

    return f"CE refresh {age_str} ({when_local.strftime('%d-%b %H:%M')})"


def get_cached_injection() -> pd.DataFrame:
    """
    Return the CE country netInjection frame (columns AT…NL + Total).

    Raises
    ------
    RuntimeError
        If the ``gas_data_ce`` cache source has not warmed yet or failed.
    """
    data = get_cached_ce_payload()

    df_inj = data.get("injection")
    if df_inj is None or not isinstance(df_inj, pd.DataFrame) or df_inj.empty:
        raise RuntimeError(
            "CE storage cache has no injection data. "
            "Check the Commodity Essentials entry in Data Source Status."
        )

    out = df_inj.copy()
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def _as_partial_frame(raw: pd.DataFrame) -> pd.DataFrame:
    if raw.empty:
        return pd.DataFrame()
    out = raw.apply(pd.to_numeric, errors="coerce")
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def _as_coverage(raw: pd.DataFrame) -> pd.DataFrame:
    if raw is None or not isinstance(raw, pd.DataFrame) or raw.empty:
        return pd.DataFrame()
    out = raw.copy()
    if isinstance(out.index, pd.MultiIndex) and out.index.nlevels >= 2:
        dates = pd.to_datetime(out.index.get_level_values(0)).normalize()
        countries = out.index.get_level_values(1).astype(str)
        out.index = pd.MultiIndex.from_arrays([dates, countries], names=["date", "country"])
    return out


def _live_partial(injection: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Query CE level-2 sites when this cache generation has no coverage yet."""
    from jain_commods.core.interfaces.commodityessentials import CElink

    from core.gas_data_ce.constants import CE_DATASETS, CE_PASS_ENV, CE_USER_ENV, DATASET_KEY
    from core.gas_data_ce.partial_storage import fetch_partial_storage_detail

    user = (os.getenv(CE_USER_ENV) or "").strip()
    password = (os.getenv(CE_PASS_ENV) or "").strip()
    if not user or not password:
        logger.warning(
            "Skipping site-level storage fallback: %s / %s are not set",
            CE_USER_ENV,
            CE_PASS_ENV,
        )
        return pd.DataFrame(), pd.DataFrame()
    ce = CElink(user, password)
    asset_ids = {code: int(asset_id) for code, asset_id in CE_DATASETS[DATASET_KEY]["assets"].items()}
    partial = fetch_partial_storage_detail(ce, injection, asset_ids=asset_ids)
    return partial.values, partial.coverage


def get_cached_partial_bundle() -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Site-level sums and the sites still missing on those days.

    Uses the CE cache when both frames are present. Otherwise one live level-2
    query fills them, reused until the next refresh.
    """
    try:
        data = get_cached_ce_payload()
    except RuntimeError:
        return pd.DataFrame(), pd.DataFrame()

    values = data.get("partial_injection")
    coverage = data.get("partial_coverage")
    if isinstance(values, pd.DataFrame) and isinstance(coverage, pd.DataFrame):
        return _as_partial_frame(values), _as_coverage(coverage)

    injection = data.get("injection")
    if not isinstance(injection, pd.DataFrame) or injection.empty:
        return pd.DataFrame(), pd.DataFrame()

    key = str(data.get("fetched_at") or id(injection))
    with _PARTIAL_LOCK:
        cached = _PARTIAL_MEMO.get(key)
        if cached is not None:
            return cached
        try:
            bundle = _live_partial(injection)
        except Exception:
            logger.exception("Level-2 storage fallback failed")
            bundle = (pd.DataFrame(), pd.DataFrame())
        _PARTIAL_MEMO[key] = bundle
        return bundle


def get_cached_partial() -> pd.DataFrame:
    """Site-level netInjection for recent days a country total is missing."""
    return get_cached_partial_bundle()[0]


def get_cached_fill() -> pd.DataFrame:
    """
    Return the CE stock / stockCapacity frame (``CC|stock``, ``Total|stock``, …).

    Raises
    ------
    RuntimeError
        If fill data is missing from the CE cache.
    """
    data = get_cached_ce_payload()

    df_fill = data.get("fill")
    if df_fill is None or not isinstance(df_fill, pd.DataFrame) or df_fill.empty:
        raise RuntimeError(
            "CE storage cache has no fill (stock/capacity) data. "
            "Check the Commodity Essentials entry in Data Source Status."
        )

    out = df_fill.copy()
    out.index = pd.to_datetime(out.index)
    return out.sort_index()
