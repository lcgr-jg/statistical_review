"""SEFE storage tracker: site flows, fill, and cumulative injection."""
from __future__ import annotations

import datetime as dt
import logging
import threading
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal

import pandas as pd
import plotly.graph_objects as go
from dash import dcc, html

from core.gas_storage_summary.constants import (
    SEFE_HISTORY_START,
    SEFE_SITES,
    SEFE_TARGET_TWH,
    UNIT_MCM,
    UNIT_TWH,
    SefeSite,
)
from core.styles import COLORS
from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table

logger = logging.getLogger(__name__)

LOGINTYPE = "prod"

# 1 mcm = 1/90 TWh (corelib ``twh/mcm`` = 90).
MCM_TO_TWH = float(get_conversion_factor("mcm", "twh", unit_conversion_table))
TWH_TO_MCM = float(get_conversion_factor("twh", "mcm", unit_conversion_table))

# Distinct fills for the four SEFE sites on the cumulative-injection plot.
_SITE_COLORS = {
    "jemgum": "#4E738A",
    "rehden": "#c47b4a",
    "vsp_nord": "#2ea043",
    "haidach": "#7b6bb5",
}
_CUM_PLOT_HEIGHT = 156

_FLOW_VARS = ("netinjection", "injection", "withdrawal", "stock", "stockcapacity")

# Used only when a warmed CE payload has no SEFE frame yet.
_FALLBACK_FRAME: dict[str, pd.DataFrame | None] = {"frame": None}
_CACHE_LOCK = threading.Lock()

_TH = {
    "padding": "6px 8px",
    "textAlign": "center",
    "backgroundColor": COLORS["table_header_bg"],
    "color": COLORS["text_dark"],
    "fontWeight": "600",
    "border": f"1px solid {COLORS['border_light']}",
    "fontSize": "11px",
    "whiteSpace": "nowrap",
}

_TD = {
    "padding": "4px 8px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "color": COLORS["text_primary"],
    "whiteSpace": "nowrap",
}

_TABLE = {
    "borderCollapse": "collapse",
    "width": "auto",
    "tableLayout": "auto",
    "fontSize": "12px",
    "fontFamily": "Calibri, Arial, sans-serif",
}

def _as_day(value) -> pd.Timestamp:
    ts = pd.Timestamp(value)
    if ts.tzinfo is not None:
        ts = ts.tz_convert(None)
    return ts.normalize()


def assemble_sefe_frame(raw: dict | None) -> pd.DataFrame:
    """Wide frame indexed by day, columns ``(site_key, variable)`` in mcm."""
    by_id: dict[int, pd.DataFrame] = {}
    for key, frame in (raw or {}).items():
        try:
            by_id[int(key)] = frame
        except (TypeError, ValueError):
            continue

    blocks = [_site_block(site, by_id.get(site.data_id)) for site in SEFE_SITES]
    frame = pd.concat(blocks, axis=1)
    frame = frame.sort_index()
    if not frame.empty:
        frame = frame[~frame.index.duplicated(keep="last")]
    return frame


def _site_block(site: SefeSite, df: pd.DataFrame | None) -> pd.DataFrame:
    columns = pd.MultiIndex.from_product([[site.key], _FLOW_VARS])
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        return pd.DataFrame(columns=columns)

    work = df.copy()
    work.columns = [str(c).lower() for c in work.columns]
    if "date" in work.columns and not isinstance(work.index, pd.DatetimeIndex):
        work = work.set_index("date")
    work.index = pd.to_datetime(work.index)
    if getattr(work.index, "tz", None) is not None:
        work.index = work.index.tz_convert(None)
    work.index = work.index.normalize()
    work = work.sort_index()
    work = work[~work.index.duplicated(keep="last")]

    out = pd.DataFrame(index=work.index)
    for var in _FLOW_VARS:
        if var in work.columns:
            out[var] = pd.to_numeric(work[var], errors="coerce")
        else:
            out[var] = pd.NA
    out.columns = columns
    return out


def clip_through(frame: pd.DataFrame, as_of) -> pd.DataFrame:
    if frame is None or frame.empty:
        return frame if isinstance(frame, pd.DataFrame) else pd.DataFrame()
    return frame.loc[: _as_day(as_of)]


def latest_data_date(frame: pd.DataFrame, as_of) -> pd.Timestamp | None:
    clipped = clip_through(frame, as_of)
    if clipped.empty:
        return None
    cols = [c for c in clipped.columns if c[1] in ("netinjection", "stock")]
    if not cols:
        return None
    mask = clipped[cols].notna().any(axis=1)
    if not mask.any():
        return None
    return _as_day(clipped.index[mask].max())


def cumulative_mcm(
    frame: pd.DataFrame,
    start,
    end,
) -> tuple[float | None, float | None]:
    """Gross injection and withdrawal (mcm) from *start* through *end*, all sites."""
    if frame is None or frame.empty:
        return None, None
    window = frame.loc[_as_day(start) : _as_day(end)]
    return _sum_var(window, "injection"), _sum_var(window, "withdrawal")


def cumulative_injection_by_site(
    frame: pd.DataFrame,
    start,
    end,
) -> pd.DataFrame:
    """Cumulative gross injection (mcm) by SEFE site from *start* through *end*.

    Columns are site keys, in tracker order. The last row sums to the same
    injection total as ``cumulative_mcm``.
    """
    if frame is None or frame.empty:
        return pd.DataFrame()
    window = frame.loc[_as_day(start) : _as_day(end)]
    if window.empty:
        return pd.DataFrame()

    parts: dict[str, pd.Series] = {}
    for site in SEFE_SITES:
        col = (site.key, "injection")
        if col not in window.columns:
            continue
        daily = pd.to_numeric(window[col], errors="coerce").dropna()
        if daily.empty:
            continue
        parts[site.key] = daily.cumsum()
    if not parts:
        return pd.DataFrame()

    index = pd.DatetimeIndex([])
    for series in parts.values():
        index = index.union(series.index)
    index = index.sort_values()

    out = pd.DataFrame(index=index)
    for site in SEFE_SITES:
        series = parts.get(site.key)
        if series is None:
            out[site.key] = 0.0
        else:
            out[site.key] = series.reindex(index).ffill().fillna(0.0)
    return out


def _sum_var(window: pd.DataFrame, variable: str) -> float | None:
    cols = [c for c in window.columns if c[1] == variable]
    if not cols or window.empty:
        return None
    daily = window[cols].apply(pd.to_numeric, errors="coerce").sum(axis=1, min_count=1)
    if not daily.notna().any():
        return None
    return float(daily.sum(min_count=1))


def fill_snapshot(frame: pd.DataFrame, as_of) -> list[dict]:
    """Latest stock, capacity (mcm) and fill % per site, plus a total row."""
    clipped = clip_through(frame, as_of)
    rows = []
    stocks: list[float] = []
    caps: list[float] = []
    for site in SEFE_SITES:
        stock, capacity = _latest_stock(clipped, site.key)
        pct = None
        if stock is not None and capacity not in (None, 0):
            pct = stock / capacity * 100.0
        if stock is not None:
            stocks.append(stock)
        if capacity is not None:
            caps.append(capacity)
        rows.append(
            {
                "key": site.key,
                "label": site.label,
                "where": site.where,
                "stock_mcm": stock,
                "capacity_mcm": capacity,
                "fill_pct": pct,
                "is_total": False,
            }
        )
    stock_sum = float(sum(stocks)) if stocks else None
    cap_sum = float(sum(caps)) if caps else None
    total_pct = (
        stock_sum / cap_sum * 100.0
        if stock_sum is not None and cap_sum not in (None, 0)
        else None
    )
    rows.append(
        {
            "key": "total",
            "label": "Total",
            "where": "",
            "stock_mcm": stock_sum,
            "capacity_mcm": cap_sum,
            "fill_pct": total_pct,
            "is_total": True,
        }
    )
    return rows


def _latest_stock(frame: pd.DataFrame, site_key: str) -> tuple[float | None, float | None]:
    if frame is None or frame.empty or (site_key, "stock") not in frame.columns:
        return None, None
    stock = pd.to_numeric(frame[(site_key, "stock")], errors="coerce")
    valid = stock.dropna()
    if valid.empty:
        return None, None
    day = valid.index[-1]
    stock_val = float(valid.loc[day])
    capacity = None
    if (site_key, "stockcapacity") in frame.columns:
        cap_series = pd.to_numeric(frame[(site_key, "stockcapacity")], errors="coerce")
        cap_at = cap_series.loc[day] if day in cap_series.index else pd.NA
        if pd.notna(cap_at):
            capacity = float(cap_at)
        else:
            prior = cap_series.loc[:day].dropna()
            if not prior.empty:
                capacity = float(prior.iloc[-1])
    return stock_val, capacity


def sefe_frame_from_payload(payload: dict | None) -> pd.DataFrame | None:
    """Copy the site history stored on a ``gas_data_ce`` payload."""
    if not payload or "sefe_frame" not in payload:
        return None
    frame = payload.get("sefe_frame")
    if not isinstance(frame, pd.DataFrame):
        return None
    return frame.copy()


def get_cached_sefe_frame(refresh_token: int = 0) -> pd.DataFrame:
    """Site history from the CE cache.

    The page Refresh button does not query again. The frame is loaded with
    the scheduled ``gas_data_ce`` refresh. ``refresh_token`` is ignored.
    """
    del refresh_token
    cached = _sefe_frame_from_ce_cache()
    if cached is not None:
        return cached
    with _CACHE_LOCK:
        fallback = _FALLBACK_FRAME["frame"]
        if fallback is not None:
            return fallback.copy()
    frame = _load_sefe_frame()
    with _CACHE_LOCK:
        _FALLBACK_FRAME["frame"] = frame
    return frame.copy()


def _sefe_frame_from_ce_cache() -> pd.DataFrame | None:
    try:
        from core.gas_storage_summary.data import get_cached_ce_payload

        payload = get_cached_ce_payload()
    except RuntimeError:
        return None
    return sefe_frame_from_payload(payload)


def load_sefe_tracker_cache() -> dict:
    """Site history, curves, and forward outages for the ``gas_data_ce`` cache."""
    from core.gas_storage_summary.sefe_availability import _load_availability_inputs

    frame = _load_sefe_frame()
    params, outages, parent_caps = _load_availability_inputs()
    return {
        "sefe_frame": frame,
        "sefe_curve_params": params if isinstance(params, pd.DataFrame) else pd.DataFrame(),
        "sefe_outages": outages if isinstance(outages, pd.DataFrame) else pd.DataFrame(),
        "sefe_parent_caps": {int(k): float(v) for k, v in (parent_caps or {}).items()},
    }


def _load_sefe_frame() -> pd.DataFrame:
    from jain_commods.fundamental.gas.storage_params import load_sites_timeseries

    raw = load_sites_timeseries(
        [site.data_id for site in SEFE_SITES],
        start_date=datetime.combine(SEFE_HISTORY_START, datetime.min.time()),
        logintype=LOGINTYPE,
    )
    return assemble_sefe_frame(raw)


def build_sefe_tracker_body(
    frame: pd.DataFrame,
    *,
    unit: str,
    start,
    n_days: int,
    as_of: datetime | pd.Timestamp | None = None,
) -> html.Div:
    """Fill table, cumulative totals, and daily net-injection table."""
    unit = UNIT_TWH if unit == UNIT_TWH else UNIT_MCM
    today = _as_day(as_of or datetime.now())
    latest = latest_data_date(frame, today)
    if latest is None:
        return html.Div(
            "No SEFE storage data on or before today.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )

    daily, cumulative, fill = build_sefe_tracker_parts(
        frame,
        unit=unit,
        start=start,
        n_days=n_days,
        as_of=as_of,
    )
    return html.Div([daily, cumulative, fill])


def build_sefe_tracker_parts(
    frame: pd.DataFrame,
    *,
    unit: str,
    start,
    n_days: int,
    as_of: datetime | pd.Timestamp | None = None,
) -> tuple[html.Div, html.Div, html.Div]:
    """Daily table, stacked cumulative cards, and fill table plus injection plot."""
    unit = UNIT_TWH if unit == UNIT_TWH else UNIT_MCM
    today = _as_day(as_of or datetime.now())
    latest = latest_data_date(frame, today)
    empty = html.Div(
        "No SEFE storage data on or before today.",
        style={"color": COLORS["text_muted"], "fontSize": "13px"},
    )
    if latest is None:
        return empty, html.Div(), html.Div()

    start_day = _as_day(start)
    inj_mcm, wdr_mcm = cumulative_mcm(frame, start_day, latest)
    fills = fill_snapshot(frame, latest)
    return (
        _daily_table(frame, latest, n_days, unit),
        _cumulative_stack(inj_mcm, wdr_mcm, start_day, latest),
        html.Div(
            [
                _fill_table(fills, latest, unit),
                _cumulative_injection_plot(frame, start_day, latest),
            ]
        ),
    )


def _fmt_flow(mcm: float | None, unit: str) -> str:
    if mcm is None or pd.isna(mcm):
        return ""
    if unit == UNIT_TWH:
        return f"{mcm * MCM_TO_TWH:,.2f}"
    return f"{mcm:,.1f}"


def _fmt_stock(mcm: float | None, unit: str) -> str:
    if mcm is None or pd.isna(mcm):
        return "–"
    if unit == UNIT_TWH:
        return f"{mcm * MCM_TO_TWH:,.2f}"
    return f"{mcm / 1000.0:,.2f}"


def _whole(mcm: float, *, signed: bool = False) -> str:
    number = int(Decimal(str(float(mcm))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return f"{number:+,}" if signed else f"{number:,}"


def _mcm_with_twh(mcm: float | None, *, signed: bool = False, value_color: str | None = None) -> html.Span:
    """Whole mcm, with TWh in smaller type in brackets."""
    if mcm is None or pd.isna(mcm):
        return html.Span("–", style={"color": value_color or COLORS["text_primary"]})
    twh = float(mcm) * MCM_TO_TWH
    return html.Span(
        [
            html.Span(
                f"{_whole(mcm, signed=signed)} mcm",
                style={"color": value_color or COLORS["text_primary"]},
            ),
            html.Span(
                f" ({_whole(twh, signed=signed)} TWh)",
                style={
                    "fontSize": "12px",
                    "fontWeight": "500",
                    "color": COLORS["text_muted"],
                },
            ),
        ]
    )


def _unit_word(unit: str, *, stock: bool) -> str:
    if unit == UNIT_TWH:
        return "TWh"
    return "bcm" if stock else "mcm"


def _net_mcm(inj_mcm: float | None, wdr_mcm: float | None) -> float | None:
    """Injections positive, withdrawals negative."""
    if inj_mcm is None and wdr_mcm is None:
        return None
    return float(inj_mcm or 0.0) - float(wdr_mcm or 0.0)


def _cumulative_stack(inj_mcm, wdr_mcm, start: pd.Timestamp, latest: pd.Timestamp) -> html.Div:
    since = start.strftime("%d %b %Y")
    through = latest.strftime("%d %b %Y")
    net = _net_mcm(inj_mcm, wdr_mcm)
    mandate_mcm = SEFE_TARGET_TWH * TWH_TO_MCM
    cards = [
        _kpi("Injection", _mcm_with_twh(inj_mcm), f"since {since}"),
        _kpi("Withdrawal", _mcm_with_twh(wdr_mcm), f"since {since}"),
        _kpi(
            "Net",
            _mcm_with_twh(net, signed=True, value_color=_net_color(net)),
            "injection − withdrawal",
        ),
        _kpi(
            "Mandate",
            _mcm_with_twh(mandate_mcm),
            "DE gov request on 29 Sep26 by 15 Dec26. "
            "Haidach (AT) is connected to the DE grid.",
        ),
    ]
    return html.Div(
        [
            html.Div(
                f"Through {through}",
                style={"fontSize": "11px", "color": COLORS["text_muted"], "marginBottom": "8px"},
            ),
            html.Div(
                style={"display": "flex", "flexDirection": "column", "gap": "8px"},
                children=cards,
            ),
        ]
    )


def _net_color(net: float | None) -> str:
    if net is None or net == 0:
        return COLORS["text_primary"]
    if net > 0:
        return COLORS["accent_green"]
    return COLORS["danger"]


def _kpi(label: str, value, hint: str) -> html.Div:
    return html.Div(
        [
            html.Div(
                label,
                style={
                    "fontSize": "11px",
                    "fontWeight": "600",
                    "color": COLORS["text_muted"],
                    "letterSpacing": "0.4px",
                    "textTransform": "uppercase",
                },
            ),
            html.Div(
                value,
                style={
                    "fontSize": "16px",
                    "fontWeight": "600",
                    "color": COLORS["text_primary"],
                    "marginTop": "4px",
                    "lineHeight": "1.3",
                },
            ),
            html.Div(
                hint,
                style={"fontSize": "11px", "color": COLORS["text_muted"], "marginTop": "2px"},
            ),
        ],
        style={
            "backgroundColor": COLORS["card_bg_alt"],
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "8px",
            "padding": "10px 14px",
        },
    )


def _daily_table(frame: pd.DataFrame, latest: pd.Timestamp, n_days: int, unit: str) -> html.Div:
    start = latest - pd.Timedelta(days=int(n_days) - 1)
    dates = pd.date_range(start=start, end=latest, freq="D")
    flow_unit = "TWh/d" if unit == UNIT_TWH else "mcm/d"
    header = html.Tr(
        [
            html.Th("Date", style={**_TH, "textAlign": "left"}),
            *[html.Th(site.label, style=_TH) for site in SEFE_SITES],
            html.Th("Total", style=_TH),
        ]
    )
    rows = []
    for day in dates:
        if day not in frame.index:
            continue
        is_weekend = day.dayofweek >= 5
        bg = COLORS["card_bg_alt"] if is_weekend else COLORS["card_bg"]
        cells = [
            html.Td(
                day.strftime("%d-%b-%Y"),
                style={**_TD, "textAlign": "left"},
            )
        ]
        values: list[float] = []
        for site in SEFE_SITES:
            val = _cell(frame, day, site.key, "netinjection")
            if val is not None:
                values.append(val)
            cells.append(html.Td(_fmt_flow(val, unit), style={**_TD, "textAlign": "right"}))
        total = float(sum(values)) if values else None
        cells.append(
            html.Td(
                _fmt_flow(total, unit),
                style={**_TD, "textAlign": "right", "fontWeight": "600"},
            )
        )
        rows.append(html.Tr(cells, style={"backgroundColor": bg}))

    return html.Div(
        [
            html.Table([html.Thead(header), html.Tbody(rows)], style=_TABLE),
            html.P(
                f"Net injection, {flow_unit}. Positive = injections, negative = withdrawals. "
                "Shaded rows = weekends.",
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "marginTop": "8px",
                    "marginBottom": "0",
                    "fontStyle": "italic",
                    "maxWidth": "640px",
                },
            ),
        ],
        style={"overflowX": "auto"},
    )


def _cell(frame: pd.DataFrame, day, site_key: str, variable: str) -> float | None:
    col = (site_key, variable)
    if col not in frame.columns or day not in frame.index:
        return None
    val = frame.at[day, col]
    if isinstance(val, pd.Series):
        val = val.iloc[-1]
    if pd.isna(val):
        return None
    return float(val)


def _fill_table(rows: list[dict], latest: pd.Timestamp, unit: str) -> html.Div:
    stock_unit = _unit_word(unit, stock=True)
    as_of = latest.strftime("%d %b")
    header = html.Tr(
        [
            html.Th("Site", style={**_TH, "textAlign": "left"}),
            html.Th("Where", style={**_TH, "textAlign": "left"}),
            html.Th(f"Fill % ({as_of})", style=_TH),
            html.Th(f"Stock {stock_unit}", style=_TH),
            html.Th(f"Capacity {stock_unit}", style=_TH),
        ]
    )
    body = []
    for i, row in enumerate(rows):
        weight = "600" if row["is_total"] else "400"
        bg = COLORS["card_bg_alt"] if i % 2 else COLORS["card_bg"]
        pct = row["fill_pct"]
        pct_txt = f"{pct:,.1f}" if pct is not None else "–"
        body.append(
            html.Tr(
                [
                    html.Td(row["label"], style={**_TD, "textAlign": "left", "fontWeight": weight}),
                    html.Td(row["where"], style={**_TD, "textAlign": "left", "color": COLORS["text_muted"]}),
                    html.Td(pct_txt, style={**_TD, "textAlign": "right", "fontWeight": weight}),
                    html.Td(
                        _fmt_stock(row["stock_mcm"], unit),
                        style={**_TD, "textAlign": "right", "fontWeight": weight},
                    ),
                    html.Td(
                        _fmt_stock(row["capacity_mcm"], unit),
                        style={**_TD, "textAlign": "right", "fontWeight": weight},
                    ),
                ],
                style={"backgroundColor": bg},
            )
        )
    return html.Div(
        [
            html.Table([html.Thead(header), html.Tbody(body)], style=_TABLE),
            html.P(
                f"Stock and capacity in {stock_unit}. Fill % is stock divided by capacity.",
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "marginTop": "8px",
                    "marginBottom": "0",
                    "fontStyle": "italic",
                    "maxWidth": "480px",
                },
            ),
        ],
        style={"overflowX": "auto"},
    )


def _cumulative_injection_plot(
    frame: pd.DataFrame,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> html.Div:
    """Small stacked chart of cumulative SEFE injections since *start*."""
    path = cumulative_injection_by_site(frame, start, end)
    if path.empty:
        return html.Div()

    total = float(path.sum(axis=1).iloc[-1])
    fig = go.Figure()
    for site in SEFE_SITES:
        if site.key not in path.columns:
            continue
        color = _SITE_COLORS[site.key]
        y = path[site.key]
        fig.add_trace(
            go.Scatter(
                x=path.index,
                y=y,
                name=site.label,
                mode="lines",
                stackgroup="inj",
                line=dict(width=0.6, color=color),
                fillcolor=color,
                customdata=(y * MCM_TO_TWH).to_numpy(),
                hovertemplate=(
                    f"{site.label}: %{{y:,.1f}} mcm (%{{customdata:.2f}} TWh)<extra></extra>"
                ),
            )
        )
    fig.update_layout(
        template="plotly_white",
        height=_CUM_PLOT_HEIGHT,
        margin=dict(l=40, r=6, t=4, b=26),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        hovermode="x unified",
        hoverlabel=dict(font_size=11),
        showlegend=False,
    )
    fig.update_xaxes(
        automargin=True,
        showgrid=False,
        tickformat="%d %b",
        nticks=4,
        tickfont=dict(size=10, color=COLORS["text_muted"]),
    )
    fig.update_yaxes(
        automargin=True,
        rangemode="tozero",
        showgrid=True,
        gridcolor="#eee",
        zeroline=False,
        tickformat=",.0f",
        nticks=4,
        tickfont=dict(size=10, color=COLORS["text_muted"]),
        title=dict(
            text="mcm",
            font=dict(size=10, color=COLORS["text_muted"]),
            standoff=2,
        ),
    )
    return html.Div(
        [
            html.Div(
                style={
                    "display": "flex",
                    "justifyContent": "space-between",
                    "alignItems": "baseline",
                    "gap": "8px",
                    "marginTop": "14px",
                },
                children=[
                    html.Span(
                        f"Cumulative injection since {start.strftime('%d %b %Y')}",
                        style={
                            "fontSize": "11px",
                            "fontWeight": "600",
                            "color": COLORS["text_muted"],
                            "letterSpacing": "0.3px",
                        },
                    ),
                    html.Span(
                        f"{_whole(total)} mcm",
                        style={
                            "fontSize": "12px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "whiteSpace": "nowrap",
                        },
                    ),
                ],
            ),
            html.Div(
                [
                    html.Span(
                        site.label,
                        style={
                            "color": _SITE_COLORS[site.key],
                            "fontSize": "10px",
                            "fontWeight": "600",
                            "marginRight": "10px",
                        },
                    )
                    for site in SEFE_SITES
                ],
                style={"margin": "2px 0 0 0", "lineHeight": "1.2"},
            ),
            dcc.Graph(
                figure=fig,
                config={"displayModeBar": False, "responsive": True},
                style={"height": f"{_CUM_PLOT_HEIGHT}px", "margin": "0"},
            ),
        ]
    )


def sefe_subtitle(latest: pd.Timestamp | None, unit: str, n_days: int) -> str:
    flow = "TWh/d" if unit == UNIT_TWH else "mcm/d"
    if latest is None:
        return f"Last {n_days} days · {flow}"
    return f"Last {n_days} days · through {latest.strftime('%d-%b-%Y')} · {flow}"
