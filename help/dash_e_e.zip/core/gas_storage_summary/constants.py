"""EU Gas Balance — Storage Summary page constants."""
from __future__ import annotations

import datetime as dt
from typing import NamedTuple

PAGE_PATH = "/power/gas_balance/storage_summary"
PAGE_NAME = "Storage Summary"
PAGE_TITLE = "EU Gas Storage Summary | JG Power Dashboard"
PAGE_ORDER = 71

# Gas year starts 1 October. Selecting year Y → chart from 1 Oct Y.
GAS_YEAR_MONTH = 10
GAS_YEAR_DAY = 1
GAS_YEAR_MIN = 2015  # CE date_from
DEFAULT_GAS_YEAR = 2025


def gas_year_start(year: int) -> dt.date:
    """Return the calendar start date of gas year *year* (1 October)."""
    return dt.date(int(year), GAS_YEAR_MONTH, GAS_YEAR_DAY)


def current_gas_year(today: dt.date | None = None) -> int:
    """Gas year in force on *today* (Oct–Dec → calendar year; Jan–Sep → prior year)."""
    today = today or dt.date.today()
    return today.year if today.month >= GAS_YEAR_MONTH else today.year - 1


def gas_year_options(today: dt.date | None = None) -> list[dict]:
    """Dropdown options from ``GAS_YEAR_MIN`` through the current gas year."""
    end = max(current_gas_year(today), DEFAULT_GAS_YEAR)
    return [{"label": str(y), "value": y} for y in range(GAS_YEAR_MIN, end + 1)]


# Daily activity table lookback (matches eu_gas_storage report).
TABLE_N_DAYS = 14
TABLE_N_DAYS_MIN = 7
TABLE_N_DAYS_MAX = 60

COUNTRIES = ["AT", "BE", "DE", "ES", "FR", "GB", "IT", "NL", "PT", "Total"]

# Individual countries (no Total) for chart country pickers.
COUNTRY_CODES = ["AT", "BE", "DE", "ES", "FR", "GB", "IT", "NL", "PT"]

# Daily Storage Action: single-select All | country.
DAILY_ACTION_ALL = "All"
DAILY_ACTION_COUNTRY_OPTIONS = (
    [{"label": "All", "value": DAILY_ACTION_ALL}]
    + [{"label": c, "value": c} for c in COUNTRY_CODES]
)

MULTI_COUNTRY_OPTIONS = [{"label": c, "value": c} for c in COUNTRY_CODES]
# ES/PT available in pickers but not pre-selected (legacy NWE+IT default).
_OPTIONAL_COUNTRIES = frozenset({"ES", "PT"})
DEFAULT_MULTI_COUNTRIES = [c for c in COUNTRY_CODES if c not in _OPTIONAL_COUNTRIES]

COUNTRY_COLORS = {
    "AT": "#1f77b4",
    "BE": "#ff7f0e",
    "DE": "#2ca02c",
    "ES": "#bcbd22",
    "FR": "#d62728",
    "GB": "#9467bd",
    "IT": "#8c564b",
    "NL": "#e377c2",
    "PT": "#7f7f7f",
    "Total": "#17becf",
}


def resolve_chart_countries(
    selected: list[str] | str | None,
) -> tuple[str, list[str]]:
    """
    Map a multi-select country picker to chart panels.

    Returns ``(top_panel, country_subplots)``:
      * one country selected → that country in the top panel, no subplots
      * otherwise → Total on top + selected countries as subplots
      * empty / invalid → Total on top + all countries
    """
    if isinstance(selected, str):
        selected = [selected]
    codes = [c for c in (selected or []) if c in COUNTRY_CODES]
    if not codes:
        codes = list(DEFAULT_MULTI_COUNTRIES)
    # Preserve canonical order
    codes = [c for c in COUNTRY_CODES if c in codes]
    if len(codes) == 1:
        return codes[0], []
    return "Total", codes

# YoY fill % chart: CE history from 2015; default show prior 7 calendar years.
FILL_HISTORY_YEAR_MIN = 2015
FILL_DEFAULT_PRIOR_YEARS = 7
# Historic range modes: numeric N → N-year min–max band; string → special styling.
RANGE_POST_UKRAINE = "post_ukraine"
# Calendar 2022+ / gas year GY2023+ (gas year starting Oct 2022).
POST_UKRAINE_CALENDAR_YEAR = 2022
POST_UKRAINE_GAS_YEAR = 2023
FILL_RANGE_OPTIONS = [
    {"label": "No range band", "value": 0},
    {"label": "3yr range", "value": 3},
    {"label": "5yr range", "value": 5},
    {"label": "7yr range", "value": 7},
    {"label": "Highlight post Ukraine", "value": RANGE_POST_UKRAINE},
]
FILL_DEFAULT_RANGE_YEARS = 0

# YoY x-axis alignment: calendar year (Jan–Dec) vs gas year (Oct–Sep).
YEAR_BASIS_CALENDAR = "calendar"
YEAR_BASIS_GAS = "gas"
YEAR_BASIS_OPTIONS = [
    {"label": "Calendar year (Jan–Dec)", "value": YEAR_BASIS_CALENDAR},
    {"label": "Gas year (Oct–Sep)", "value": YEAR_BASIS_GAS},
]
DEFAULT_YEAR_BASIS = YEAR_BASIS_CALENDAR


def year_label(year: int, basis: str = YEAR_BASIS_CALENDAR) -> str:
    """Legend / hover label: ``2025`` or ``GY2025``."""
    if basis == YEAR_BASIS_GAS:
        return f"GY{int(year)}"
    return str(int(year))


def is_post_ukraine_year(year: int, basis: str = YEAR_BASIS_CALENDAR) -> bool:
    """True for calendar 2022+ or gas year GY2023+."""
    cutoff = (
        POST_UKRAINE_GAS_YEAR
        if basis == YEAR_BASIS_GAS
        else POST_UKRAINE_CALENDAR_YEAR
    )
    return int(year) >= cutoff


def yoy_year_line_style(
    year: int,
    *,
    current_year: int,
    basis: str = YEAR_BASIS_CALENDAR,
    highlight_post_ukraine: bool = False,
) -> tuple[float, float]:
    """Return ``(line_width, opacity)`` for a YoY year series."""
    if int(year) == int(current_year):
        return 2.6, 1.0
    if highlight_post_ukraine:
        if is_post_ukraine_year(year, basis):
            return 2.2, 0.95
        return 0.9, 0.28
    return 1.2, 0.7


def yoy_current_year(basis: str, today: dt.date | None = None) -> int:
    """Current year key for the selected basis (calendar year or gas year)."""
    today = today or dt.date.today()
    if basis == YEAR_BASIS_GAS:
        return current_gas_year(today)
    return today.year


def fill_year_options(
    today: dt.date | None = None,
    basis: str = YEAR_BASIS_CALENDAR,
) -> list[dict]:
    """Selectable prior years for YoY charts (excludes the current year/GY)."""
    today = today or dt.date.today()
    current = yoy_current_year(basis, today)
    end = current - 1
    start = FILL_HISTORY_YEAR_MIN
    if end < start:
        return []
    return [
        {"label": year_label(y, basis), "value": y}
        for y in range(end, start - 1, -1)
    ]


def default_fill_years(
    today: dt.date | None = None,
    basis: str = YEAR_BASIS_CALENDAR,
) -> list[int]:
    """Most recent ``FILL_DEFAULT_PRIOR_YEARS`` prior years for the basis."""
    today = today or dt.date.today()
    current = yoy_current_year(basis, today)
    end = current - 1
    start = max(FILL_HISTORY_YEAR_MIN, end - FILL_DEFAULT_PRIOR_YEARS + 1)
    if end < FILL_HISTORY_YEAR_MIN:
        return []
    return list(range(start, end + 1))

# Season modes for the YoY injection / withdrawal bar chart.
# Injection season: 1 Apr – 31 Oct. Withdrawal season: 1 Oct – 31 Mar.
SEASON_INJECTION = "injection"
SEASON_WITHDRAWAL = "withdrawal"
SEASON_APR = "apr"
SEASON_OCT = "oct"

SEASON_MODE_OPTIONS = [
    {"label": "Injection", "value": SEASON_INJECTION},
    {"label": "Withdrawal", "value": SEASON_WITHDRAWAL},
]


def season_start(kind: str, year: int) -> dt.date:
    if kind == SEASON_OCT:
        return dt.date(int(year), 10, 1)
    return dt.date(int(year), 4, 1)


def season_end(kind: str, year: int) -> dt.date:
    """Last day of the selected season window."""
    if kind == SEASON_OCT:
        return dt.date(int(year) + 1, 3, 31)
    return dt.date(int(year), 10, 31)


def resolve_season_mode(
    mode: str | None,
    today: dt.date | None = None,
) -> tuple[str, int]:
    """
    Map Injection/Withdrawal to the most recent season start ``(kind, year)``.

    Examples (today = 29 Jul 2026):
      * Injection   → 1 Apr 2026
      * Withdrawal  → 1 Oct 2025 (through 31 Mar 2026)
    """
    today = today or dt.date.today()
    mode = (mode or default_season_mode(today)).lower()

    if mode == SEASON_WITHDRAWAL:
        # Oct 1 this year if that date has begun; else prior Oct 1.
        if today >= dt.date(today.year, 10, 1):
            return SEASON_OCT, today.year
        return SEASON_OCT, today.year - 1

    # Injection: Apr 1 this year if begun; else prior Apr 1.
    if today >= dt.date(today.year, 4, 1):
        return SEASON_APR, today.year
    return SEASON_APR, today.year - 1


def default_season_mode(today: dt.date | None = None) -> str:
    """Injection during Apr–Oct; Withdrawal during Nov–Mar."""
    today = today or dt.date.today()
    if 4 <= today.month <= 10:
        return SEASON_INJECTION
    return SEASON_WITHDRAWAL


# SEFE Storage sites on the Storage Summary tracker.
# data_ids are CE level-2 series in commod_research.eu_data_metadata.
# Haidach is the Astora facility (data_id 549), in Austria and connected to
# the German grid. Haidach GSA (data_id 605) is a different, retired site.
# Jemgum is the Astora share only (data_id 425); the level-2 Jemgum total
# also includes EWE and VNG.
class SefeSite(NamedTuple):
    key: str
    label: str
    where: str
    data_id: int
    asset_id: int
    # Storage Sites fits level-2 sites. Jemgum Astora has no fit of its own;
    # scale the Jemgum level-2 curve by Astora's share of working capacity.
    curve_data_id: int | None = None


SEFE_SITES: tuple[SefeSite, ...] = (
    SefeSite("jemgum", "Jemgum", "Germany, Astora", 425, 590, 424),
    SefeSite("rehden", "Rehden", "Germany", 448, 617, None),
    SefeSite("vsp_nord", "VSP Nord", "Germany", 1774, 3395, None),
    SefeSite("haidach", "Haidach", "Austria, DE grid", 549, 1760, None),
)

SEFE_HISTORY_START = dt.date(2015, 1, 1)
# Forward window for curve capability vs CE maintenance.
SEFE_AVAIL_DAYS = 14
SEFE_AVAIL_DAYS_MIN = 7
SEFE_AVAIL_DAYS_MAX = 60
SEFE_TARGET_TWH = 8.0
SEFE_TARGET_DATE = dt.date(2026, 12, 15)
SEFE_CUM_START = dt.date(2026, 9, 29)

UNIT_MCM = "mcm"
UNIT_TWH = "twh"
SEFE_UNIT_OPTIONS = [
    {"label": "mcm", "value": UNIT_MCM},
    {"label": "TWh", "value": UNIT_TWH},
]


def default_sefe_cum_start(today: dt.date | None = None) -> dt.date:
    """Default start for SEFE cumulative injection and withdrawal."""
    del today
    return SEFE_CUM_START


def season_chart_title(kind: str, year: int, as_of: dt.date) -> str:
    start = season_start(kind, year)
    start_s = start.strftime("%d %b %Y")
    as_of_s = as_of.strftime("%d %b %Y")
    if kind == SEASON_OCT:
        return f"Withdrawals {start_s} – {as_of_s}"
    return f"Injection {start_s} – {as_of_s}"
