"""Layout for the EU Gas Balance — Storage Summary page."""
from __future__ import annotations

from dash import dcc, html

from core.gas_storage_summary.constants import (
    DAILY_ACTION_ALL,
    DAILY_ACTION_COUNTRY_OPTIONS,
    DEFAULT_GAS_YEAR,
    DEFAULT_MULTI_COUNTRIES,
    DEFAULT_YEAR_BASIS,
    FILL_DEFAULT_RANGE_YEARS,
    FILL_RANGE_OPTIONS,
    MULTI_COUNTRY_OPTIONS,
    SEASON_MODE_OPTIONS,
    SEFE_AVAIL_DAYS,
    SEFE_AVAIL_DAYS_MAX,
    SEFE_AVAIL_DAYS_MIN,
    SEFE_HISTORY_START,
    TABLE_N_DAYS,
    TABLE_N_DAYS_MAX,
    TABLE_N_DAYS_MIN,
    YEAR_BASIS_OPTIONS,
    default_fill_years,
    default_sefe_cum_start,
    default_season_mode,
    fill_year_options,
    gas_year_options,
)
from core.styles import COLORS

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "center",
    "flexWrap": "wrap",
    "gap": "12px",
}

_BTN_PRIMARY = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
    "transition": "all 0.2s",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    # visible: outside bar labels + Plotly resize must not be clipped to 0
    "overflow": "visible",
    "marginBottom": "20px",
}

_PANEL_HEADER = {
    "padding": "16px 20px 8px 20px",
    "display": "flex",
    "alignItems": "baseline",
    "flexWrap": "nowrap",
    "gap": "8px",
}

_PANEL_CONTROLS = {
    "padding": "0 20px 12px 20px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "whiteSpace": "nowrap",
    "flexShrink": "0",
}

_PANEL_SUBTITLE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "whiteSpace": "nowrap",
    "overflow": "hidden",
    "textOverflow": "ellipsis",
}

_YOY_CONTROLS_ROW = {
    "display": "flex",
    "flexWrap": "wrap",
    "gap": "20px",
    "alignItems": "flex-start",
}

_SEFE_COL_TITLE = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "letterSpacing": "0.4px",
    "textTransform": "uppercase",
    "margin": "0 0 8px 0",
}


def build_layout() -> html.Div:
    return html.Div(
        style={
            "minHeight": "100vh",
            "backgroundColor": COLORS["background"],
            "padding": "20px",
        },
        children=[
            html.Div(
                [
                    html.H1(
                        "Storage Summary",
                        style={
                            "fontSize": "22px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "margin": "0 0 4px 0",
                        },
                    ),
                    html.P(
                        "Daily country storage action from Commodity Essentials "
                        "(AT, BE, DE, ES, FR, GB, IT, NL, PT).",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 20px 0",
                        },
                    ),
                ]
            ),
            # Page-level refresh
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Button(
                        "Refresh",
                        id="gas-stor-sum-refresh",
                        n_clicks=0,
                        style=_BTN_PRIMARY,
                    ),
                    html.Div(id="gas-stor-sum-status"),
                ],
            ),
            # Shared country filter for summary tables
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Div(
                        [
                            html.Label("Countries (tables)", style=_LABEL),
                            html.Div(
                                dcc.Dropdown(
                                    id="gas-stor-sum-table-countries",
                                    options=MULTI_COUNTRY_OPTIONS,
                                    value=DEFAULT_MULTI_COUNTRIES,
                                    multi=True,
                                    placeholder="Select countries…",
                                    style={"fontSize": "13px"},
                                ),
                                style={"width": "520px", "minWidth": "280px"},
                            ),
                        ]
                    ),
                ],
            ),
            # Daily activity + fill % side by side
            html.Div(
                style={
                    "display": "flex",
                    "flexWrap": "wrap",
                    "gap": "20px",
                    "alignItems": "stretch",
                    "marginBottom": "20px",
                },
                children=[
                    html.Div(
                        style={**_CONTENT_PANEL, "flex": "1 1 520px", "marginBottom": "0"},
                        children=[
                            html.Div(
                                style=_PANEL_HEADER,
                                children=[
                                    html.Span("Daily Storage Activity", style=_PANEL_TITLE),
                                    html.Span(
                                        f"Last {TABLE_N_DAYS} days · mcm/d",
                                        id="gas-stor-sum-table-subtitle",
                                        style=_PANEL_SUBTITLE,
                                    ),
                                ],
                            ),
                            html.Div(
                                style={**_PANEL_CONTROLS, "maxWidth": "420px"},
                                children=[
                                    html.Label("History (days)", style=_LABEL),
                                    dcc.Slider(
                                        id="gas-stor-sum-table-days",
                                        min=TABLE_N_DAYS_MIN,
                                        max=TABLE_N_DAYS_MAX,
                                        step=1,
                                        value=TABLE_N_DAYS,
                                        marks={
                                            TABLE_N_DAYS_MIN: str(TABLE_N_DAYS_MIN),
                                            14: "14",
                                            30: "30",
                                            45: "45",
                                            TABLE_N_DAYS_MAX: str(TABLE_N_DAYS_MAX),
                                        },
                                        tooltip={
                                            "placement": "bottom",
                                            "always_visible": False,
                                        },
                                        updatemode="mouseup",
                                    ),
                                ],
                            ),
                            html.Div(
                                id="gas-stor-sum-table",
                                style={"padding": "16px 20px"},
                                children=[
                                    html.Div(
                                        "Click Refresh to load storage data.",
                                        style={
                                            "color": COLORS["text_muted"],
                                            "fontSize": "13px",
                                        },
                                    )
                                ],
                            ),
                        ],
                    ),
                    html.Div(
                        style={**_CONTENT_PANEL, "flex": "0 1 420px", "marginBottom": "0"},
                        children=[
                            html.Div(
                                style=_PANEL_HEADER,
                                children=[
                                    html.Span("Storage Fill %", style=_PANEL_TITLE),
                                    html.Span(
                                        "vs prior-year same day",
                                        id="gas-stor-sum-fill-subtitle",
                                        style=_PANEL_SUBTITLE,
                                    ),
                                ],
                            ),
                            html.Div(
                                id="gas-stor-sum-fill-table",
                                style={"padding": "16px 20px"},
                                children=[
                                    html.Div(
                                        "Click Refresh to load storage data.",
                                        style={
                                            "color": COLORS["text_muted"],
                                            "fontSize": "13px",
                                        },
                                    )
                                ],
                            ),
                        ],
                    ),
                    html.Div(
                        style={**_CONTENT_PANEL, "flex": "0 1 420px", "marginBottom": "0"},
                        children=[
                            html.Div(
                                style=_PANEL_HEADER,
                                children=[
                                    html.Span("Storage Fill bcm", style=_PANEL_TITLE),
                                    html.Span(
                                        "vs prior-year same day",
                                        id="gas-stor-sum-fill-bcm-subtitle",
                                        style=_PANEL_SUBTITLE,
                                    ),
                                ],
                            ),
                            html.Div(
                                id="gas-stor-sum-fill-bcm-table",
                                style={"padding": "16px 20px"},
                                children=[
                                    html.Div(
                                        "Click Refresh to load storage data.",
                                        style={
                                            "color": COLORS["text_muted"],
                                            "fontSize": "13px",
                                        },
                                    )
                                ],
                            ),
                        ],
                    ),
                ],
            ),
            # SEFE site tracker (above Daily Storage Action)
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("SEFE Tracker", style=_PANEL_TITLE),
                            html.Span(
                                id="gas-stor-sum-sefe-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style={"padding": "0 20px 8px 20px"},
                        children=[
                            html.P(
                                "Sites: Jemgum (SEFE Astora share), Rehden and VSP Nord "
                                "(Germany) and Haidach (Austria, SEFE Astora facility).",
                                style={
                                    "fontSize": "12px",
                                    "color": COLORS["text_secondary"],
                                    "margin": "0",
                                    "maxWidth": "920px",
                                    "lineHeight": "1.45",
                                },
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=html.Div(
                            style={
                                "display": "flex",
                                "flexWrap": "wrap",
                                "gap": "20px",
                                "alignItems": "flex-start",
                                "padding": "16px 20px",
                            },
                            children=[
                                html.Div(
                                    style={"flex": "1 1 460px", "minWidth": "280px"},
                                    children=[
                                        html.Div("Daily activity", style=_SEFE_COL_TITLE),
                                        html.Div(
                                            style={
                                                "maxWidth": "420px",
                                                "marginBottom": "4px",
                                                "paddingBottom": "22px",
                                            },
                                            children=[
                                                html.Label("History (days)", style=_LABEL),
                                                dcc.Slider(
                                                    id="gas-stor-sum-sefe-days",
                                                    min=TABLE_N_DAYS_MIN,
                                                    max=TABLE_N_DAYS_MAX,
                                                    step=1,
                                                    value=TABLE_N_DAYS,
                                                    marks={
                                                        TABLE_N_DAYS_MIN: str(TABLE_N_DAYS_MIN),
                                                        14: "14",
                                                        30: "30",
                                                        45: "45",
                                                        TABLE_N_DAYS_MAX: str(TABLE_N_DAYS_MAX),
                                                    },
                                                    tooltip={
                                                        "placement": "bottom",
                                                        "always_visible": False,
                                                    },
                                                    updatemode="mouseup",
                                                ),
                                            ],
                                        ),
                                        html.Div(id="gas-stor-sum-sefe-daily"),
                                    ],
                                ),
                                html.Div(
                                    style={"flex": "0 1 240px", "minWidth": "200px"},
                                    children=[
                                        html.Div("Cumulative summary", style=_SEFE_COL_TITLE),
                                        html.Div(
                                            style={"marginBottom": "8px"},
                                            children=[
                                                html.Label("Cumulative from", style=_LABEL),
                                                dcc.DatePickerSingle(
                                                    id="gas-stor-sum-sefe-start",
                                                    date=default_sefe_cum_start().isoformat(),
                                                    min_date_allowed=SEFE_HISTORY_START.isoformat(),
                                                    display_format="DD-MMM-YYYY",
                                                    first_day_of_week=1,
                                                ),
                                            ],
                                        ),
                                        html.Div(id="gas-stor-sum-sefe-cum"),
                                    ],
                                ),
                                html.Div(
                                    style={"flex": "1 1 360px", "minWidth": "280px"},
                                    children=[
                                        html.Div("Current fill", style=_SEFE_COL_TITLE),
                                        html.Div(id="gas-stor-sum-sefe-fill"),
                                    ],
                                ),
                                html.Div(
                                    style={"flex": "1 1 680px", "minWidth": "320px"},
                                    children=[
                                        html.Div(
                                            "Available injection and withdrawal",
                                            style=_SEFE_COL_TITLE,
                                        ),
                                        html.Div(
                                            style={
                                                "maxWidth": "420px",
                                                "marginBottom": "4px",
                                                "paddingBottom": "22px",
                                            },
                                            children=[
                                                html.Label("Forward (days)", style=_LABEL),
                                                dcc.Slider(
                                                    id="gas-stor-sum-sefe-avail-days",
                                                    min=SEFE_AVAIL_DAYS_MIN,
                                                    max=SEFE_AVAIL_DAYS_MAX,
                                                    step=1,
                                                    value=SEFE_AVAIL_DAYS,
                                                    marks={
                                                        SEFE_AVAIL_DAYS_MIN: str(SEFE_AVAIL_DAYS_MIN),
                                                        14: "14",
                                                        30: "30",
                                                        45: "45",
                                                        SEFE_AVAIL_DAYS_MAX: str(SEFE_AVAIL_DAYS_MAX),
                                                    },
                                                    tooltip={
                                                        "placement": "bottom",
                                                        "always_visible": False,
                                                    },
                                                    updatemode="mouseup",
                                                ),
                                            ],
                                        ),
                                        html.Div(id="gas-stor-sum-sefe-avail"),
                                    ],
                                ),
                            ],
                        ),
                    ),
                ],
            ),
            # Daily Storage Action chart
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("Daily Storage Action", style=_PANEL_TITLE),
                            html.Span(
                                id="gas-stor-sum-chart-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style=_PANEL_CONTROLS,
                        children=[
                            html.Div(
                                style={
                                    "display": "flex",
                                    "flexWrap": "wrap",
                                    "gap": "20px",
                                    "alignItems": "flex-end",
                                },
                                children=[
                                    html.Div(
                                        [
                                            html.Label("Start gas year", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-gas-year",
                                                    options=gas_year_options(),
                                                    value=DEFAULT_GAS_YEAR,
                                                    clearable=False,
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "120px"},
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Country", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-action-country",
                                                    options=DAILY_ACTION_COUNTRY_OPTIONS,
                                                    value=DAILY_ACTION_ALL,
                                                    clearable=False,
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "140px"},
                                            ),
                                        ]
                                    ),
                                ],
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=dcc.Graph(
                            id="gas-stor-sum-chart",
                            config={"displayModeBar": True, "responsive": True},
                            style={"height": "500px"},
                        ),
                    ),
                ],
            ),
            # Season YoY injection / withdrawal comparison
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span(
                                id="gas-stor-sum-season-title",
                                children="Season Storage Change",
                                style=_PANEL_TITLE,
                            ),
                            html.Span(
                                id="gas-stor-sum-season-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style=_PANEL_CONTROLS,
                        children=[
                            html.Div(
                                style={
                                    "display": "flex",
                                    "flexWrap": "wrap",
                                    "gap": "20px",
                                    "alignItems": "flex-end",
                                },
                                children=[
                                    html.Div(
                                        [
                                            html.Label("Mode", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-season-mode",
                                                    options=SEASON_MODE_OPTIONS,
                                                    value=default_season_mode(),
                                                    clearable=False,
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "180px"},
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Countries", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-season-countries",
                                                    options=MULTI_COUNTRY_OPTIONS,
                                                    value=DEFAULT_MULTI_COUNTRIES,
                                                    multi=True,
                                                    placeholder="Select countries…",
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "420px"},
                                            ),
                                        ]
                                    ),
                                ],
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=dcc.Graph(
                            id="gas-stor-sum-season-chart",
                            config={
                                "displayModeBar": True,
                                "responsive": True,
                            },
                            style={
                                "width": "100%",
                                "minHeight": "1200px",
                            },
                        ),
                    ),
                ],
            ),
            # Cumulative season path (Total + countries)
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span(
                                id="gas-stor-sum-cum-title",
                                children="Cumulative Season Path",
                                style=_PANEL_TITLE,
                            ),
                            html.Span(
                                id="gas-stor-sum-cum-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style=_PANEL_CONTROLS,
                        children=[
                            html.Div(
                                style={
                                    "display": "flex",
                                    "flexWrap": "wrap",
                                    "gap": "20px",
                                    "alignItems": "flex-end",
                                },
                                children=[
                                    html.Div(
                                        [
                                            html.Label("Mode", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-cum-mode",
                                                    options=SEASON_MODE_OPTIONS,
                                                    value=default_season_mode(),
                                                    clearable=False,
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "180px"},
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Countries", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-cum-countries",
                                                    options=MULTI_COUNTRY_OPTIONS,
                                                    value=DEFAULT_MULTI_COUNTRIES,
                                                    multi=True,
                                                    placeholder="Select countries…",
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "420px"},
                                            ),
                                        ]
                                    ),
                                ],
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=dcc.Graph(
                            id="gas-stor-sum-cum-chart",
                            config={
                                "displayModeBar": True,
                                "responsive": True,
                            },
                            style={
                                "width": "100%",
                                "minHeight": "1400px",
                            },
                        ),
                    ),
                ],
            ),
            # YoY storage fill %
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("YoY Storage Fill %", style=_PANEL_TITLE),
                            html.Span(
                                id="gas-stor-sum-fill-yoy-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style=_PANEL_CONTROLS,
                        children=[
                            html.Div(
                                style=_YOY_CONTROLS_ROW,
                                children=[
                                    html.Div(
                                        [
                                            html.Label("Year basis", style=_LABEL),
                                            dcc.RadioItems(
                                                id="gas-stor-sum-fill-basis",
                                                options=YEAR_BASIS_OPTIONS,
                                                value=DEFAULT_YEAR_BASIS,
                                                inline=False,
                                                style={"fontSize": "13px"},
                                                labelStyle={
                                                    "display": "block",
                                                    "marginBottom": "4px",
                                                },
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label(
                                                "Historic range band",
                                                style=_LABEL,
                                            ),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-fill-range",
                                                    options=FILL_RANGE_OPTIONS,
                                                    value=FILL_DEFAULT_RANGE_YEARS,
                                                    clearable=False,
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "140px"},
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label(
                                                "Prior years to display",
                                                style=_LABEL,
                                            ),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-fill-years",
                                                    options=fill_year_options(),
                                                    value=default_fill_years(),
                                                    multi=True,
                                                    placeholder="Select years…",
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "280px"},
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Countries", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-sum-fill-countries",
                                                    options=MULTI_COUNTRY_OPTIONS,
                                                    value=DEFAULT_MULTI_COUNTRIES,
                                                    multi=True,
                                                    placeholder="Select countries…",
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "280px"},
                                            ),
                                        ]
                                    ),
                                ],
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=dcc.Graph(
                            id="gas-stor-sum-fill-yoy-chart",
                            config={
                                "displayModeBar": True,
                                "responsive": True,
                            },
                            style={
                                "width": "100%",
                                "minHeight": "1400px",
                            },
                        ),
                    ),
                ],
            ),
        ],
    )
