"""EU Gas Balance — Storage vs Demand page package."""
from .layout import build_layout

__all__ = ["build_layout"]
