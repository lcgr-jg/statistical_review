"""Storage vs Demand — read stock + demand frames from the CE cache."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.cache import dashboard_cache
from core.gas_data_ce.constants import DEMAND_DATASET_KEY, SOURCE_NAME

logger = logging.getLogger(__name__)


def _parse_fetched_at(raw: Any) -> datetime | None:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw
    try:
        return datetime.fromisoformat(str(raw))
    except ValueError:
        return None


def _payload_has_demand_components(data: dict[str, Any]) -> bool:
    """True if this CE cache payload includes sector demand frames."""
    comps = data.get("demand_components")
    if isinstance(comps, dict) and comps:
        return True
    datasets = data.get("datasets")
    if isinstance(datasets, dict):
        dem = datasets.get(DEMAND_DATASET_KEY) or {}
        nested = dem.get("demand_components")
        if isinstance(nested, dict) and nested:
            return True
    return False


def get_cached_ce_payload() -> dict[str, Any]:
    """Return the full ``gas_data_ce`` cache dict (raises if empty)."""
    data: dict[str, Any] | None = dashboard_cache.get_data(SOURCE_NAME)

    if not data or not isinstance(data, dict):
        raise RuntimeError(
            "Commodity Essentials gas cache is empty. "
            "Wait for warm-up to finish, or check CE_USER / CE_PASS and restart."
        )

    # Old disk payloads (pre sector breakdown) still have totals/storage but
    # lack demand_components. Invalidate and re-fetch once so LDZ / industrial /
    # power selectors work after a code upgrade.
    if not _payload_has_demand_components(data):
        logger.warning(
            "CE cache is missing demand_components — forcing gas_data_ce refresh"
        )
        try:
            dashboard_cache.force_refresh(SOURCE_NAME)
        except Exception as exc:
            raise RuntimeError(
                "Commodity Essentials cache is outdated (no sector demand yet) "
                "and refresh failed. Check CE_USER / CE_PASS and Data Source Status."
            ) from exc
        data = dashboard_cache.get_data(SOURCE_NAME)
        if (
            not data
            or not isinstance(data, dict)
            or not _payload_has_demand_components(data)
        ):
            raise RuntimeError(
                "Commodity Essentials is still warming or refresh did not return "
                "sector demand (LDZ / industrial / power). Wait for "
                "'Commodity Essentials' in Data Source Status to go fresh, then retry."
            )

    return data


def get_ce_last_refresh(payload: dict[str, Any] | None = None) -> datetime | None:
    """When the CE cache was last successfully refreshed."""
    if payload is None:
        try:
            payload = get_cached_ce_payload()
        except RuntimeError:
            payload = None

    fetched = _parse_fetched_at(payload.get("fetched_at") if payload else None)
    if fetched is not None:
        return fetched

    return dashboard_cache.get_last_refresh(SOURCE_NAME)


def format_ce_refresh_age(
    when: datetime | None,
    *,
    now: datetime | None = None,
) -> str:
    """Human age string (e.g. ``2h 15m ago``)."""
    if when is None:
        return "CE refresh time unknown"

    if when.tzinfo is not None:
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        age_min = max(
            0,
            int(
                (
                    now.astimezone(timezone.utc) - when.astimezone(timezone.utc)
                ).total_seconds()
                // 60
            ),
        )
        when_local = when.astimezone()
    else:
        now = now or datetime.now()
        age_min = max(0, int((now - when).total_seconds() // 60))
        when_local = when

    if age_min < 60:
        age_str = f"{age_min}m ago"
    elif age_min < 1440:
        age_str = f"{age_min // 60}h {age_min % 60}m ago"
    else:
        age_str = f"{age_min // 1440}d ago"

    return f"CE refresh {age_str} ({when_local.strftime('%d-%b %H:%M')})"


def get_cached_fill() -> pd.DataFrame:
    """Return stock / stockCapacity frame (``CC|stock``, ``Total|stock``, …)."""
    data = get_cached_ce_payload()

    df_fill = data.get("fill")
    if (
        (df_fill is None or not isinstance(df_fill, pd.DataFrame) or df_fill.empty)
        and isinstance(data.get("datasets"), dict)
    ):
        storage = data["datasets"].get("gas_storage_country") or {}
        df_fill = storage.get("fill")

    if df_fill is None or not isinstance(df_fill, pd.DataFrame) or df_fill.empty:
        raise RuntimeError(
            "CE cache has no fill (stock/capacity) data. "
            "Check the Commodity Essentials entry in Data Source Status."
        )

    out = df_fill.copy()
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def get_cached_demand() -> pd.DataFrame:
    """
    Return country total-demand frame (columns AT…NL + Total), mcm/d.

    Sourced from CE ``netflow`` on Total Demand assets.
    """
    data = get_cached_ce_payload()

    df_demand = data.get("demand")
    if (
        (df_demand is None or not isinstance(df_demand, pd.DataFrame) or df_demand.empty)
        and isinstance(data.get("datasets"), dict)
    ):
        demand_payload = data["datasets"].get(DEMAND_DATASET_KEY) or {}
        df_demand = demand_payload.get("demand")
        if df_demand is None or (
            isinstance(df_demand, pd.DataFrame) and df_demand.empty
        ):
            by_var = demand_payload.get("by_variable") or {}
            df_demand = by_var.get("netflow") or by_var.get("netFlow")

    if df_demand is None or not isinstance(df_demand, pd.DataFrame) or df_demand.empty:
        raise RuntimeError(
            "CE cache has no demand data. "
            "Check CE_USER / CE_PASS and that gas_demand_country warmed successfully."
        )

    out = df_demand.copy()
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def _get_cached_ce_components() -> dict[str, pd.DataFrame]:
    """CE-only sector frames from the cache (may omit DE/NL industrial & power)."""
    data = get_cached_ce_payload()
    components = data.get("demand_components")
    if not isinstance(components, dict) and isinstance(data.get("datasets"), dict):
        demand_payload = data["datasets"].get(DEMAND_DATASET_KEY) or {}
        components = demand_payload.get("demand_components")
    if not isinstance(components, dict):
        return {}
    out: dict[str, pd.DataFrame] = {}
    for key, frame in components.items():
        if isinstance(frame, pd.DataFrame) and not frame.empty:
            df = frame.copy()
            df.index = pd.to_datetime(df.index)
            out[str(key)] = df.sort_index()
    return out


def _fetch_internal_demand_series(data_id: int) -> pd.Series:
    """Load one implied demand series from Postgres via DataQuery (mcm/d)."""
    from datetime import datetime

    from jain_commods.core.interfaces.sqldb import DataQuery

    dq = DataQuery(logintype="prod")
    results = dq.get_data(
        by="id",
        data_id=int(data_id),
        start_date=datetime(2015, 1, 1),
    )
    df = results.get(int(data_id))
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        return pd.Series(dtype=float, name=str(data_id))
    series = pd.Series(
        pd.to_numeric(df["value"], errors="coerce").values,
        index=pd.to_datetime(df["date"]),
        name=str(data_id),
    )
    if getattr(series.index, "tz", None) is not None:
        series.index = series.index.tz_convert("UTC").tz_localize(None)
    series.index = pd.DatetimeIndex(series.index).normalize()
    return series[~series.index.duplicated(keep="last")].sort_index().astype(float)


def _normalize_demand_series(series: pd.Series) -> pd.Series:
    out = pd.to_numeric(series, errors="coerce").astype(float).copy()
    out.index = pd.to_datetime(out.index)
    if getattr(out.index, "tz", None) is not None:
        out.index = out.index.tz_convert("UTC").tz_localize(None)
    out.index = pd.DatetimeIndex(out.index).normalize()
    return out[~out.index.duplicated(keep="last")].sort_index()


def _stitch_ce_and_internal(
    ce: pd.Series | None,
    internal: pd.Series,
) -> pd.Series:
    """
    Concatenate older internal history with newer CE values.

    On overlapping dates CE wins (typically the live/recent publication).
    Dates present only in the internal series are kept as the back-history.
    """
    internal_n = _normalize_demand_series(internal)
    if ce is None or (isinstance(ce, pd.Series) and ce.dropna().empty):
        return internal_n

    ce_n = _normalize_demand_series(ce).dropna()
    if internal_n.empty:
        return ce_n
    if ce_n.empty:
        return internal_n

    combined = internal_n.reindex(internal_n.index.union(ce_n.index))
    combined.loc[internal_n.index] = internal_n
    combined.loc[ce_n.index] = ce_n
    return combined.sort_index()


def _overlay_internal_demand(component: str, frame: pd.DataFrame) -> pd.DataFrame:
    """
    Merge DataQuery DE/NL industrial & power onto a CE component frame.

    * DE — DataQuery only (no CE industrial/power asset yet)
    * NL — stitch DataQuery history under CE recent (CE preferred on overlap)
    """
    from core.gas_data_ce.constants import DEMAND_INTERNAL_DATA_IDS
    from core.gas_storage_summary.constants import COUNTRY_CODES

    ids = DEMAND_INTERNAL_DATA_IDS.get(component) or {}
    if not ids:
        return frame

    out = frame.copy() if isinstance(frame, pd.DataFrame) else pd.DataFrame()
    for country, data_id in ids.items():
        try:
            internal = _fetch_internal_demand_series(int(data_id))
        except Exception as exc:
            logger.warning(
                "DataQuery demand id=%s (%s/%s) failed: %s",
                data_id,
                component,
                country,
                exc,
            )
            continue
        if internal.empty:
            logger.warning(
                "DataQuery demand id=%s (%s/%s) returned no rows",
                data_id,
                component,
                country,
            )
            continue

        ce_series = None
        if country in out.columns:
            ce_series = out[country]
        stitched = _stitch_ce_and_internal(ce_series, internal)
        out[country] = stitched
        if ce_series is not None and not _normalize_demand_series(ce_series).dropna().empty:
            ce_n = _normalize_demand_series(ce_series).dropna()
            logger.info(
                "Stitched %s/%s: internal %s→%s + CE %s→%s → %s→%s",
                component,
                country,
                internal.index.min().date(),
                internal.index.max().date(),
                ce_n.index.min().date(),
                ce_n.index.max().date(),
                stitched.dropna().index.min().date(),
                stitched.dropna().index.max().date(),
            )

    if out.empty:
        return out

    country_cols = [c for c in COUNTRY_CODES if c in out.columns]
    if country_cols:
        out["Total"] = out[country_cols].sum(axis=1, min_count=1)
    return out.sort_index()


def _drop_unreliable_sector_countries(frame: pd.DataFrame) -> pd.DataFrame:
    """Remove AT from sector frames and rebuild Total without it."""
    from core.gas_storage_vs_demand.constants import (
        SECTOR_COUNTRY_CODES,
        SECTOR_EXCLUDED_COUNTRIES,
    )

    if frame is None or not isinstance(frame, pd.DataFrame) or frame.empty:
        return frame if isinstance(frame, pd.DataFrame) else pd.DataFrame()

    out = frame.copy()
    drop_cols = [c for c in SECTOR_EXCLUDED_COUNTRIES if c in out.columns]
    if drop_cols:
        out = out.drop(columns=drop_cols)
    country_cols = [c for c in SECTOR_COUNTRY_CODES if c in out.columns]
    if country_cols:
        out["Total"] = out[country_cols].sum(axis=1, min_count=1)
    elif "Total" in out.columns:
        out = out.drop(columns=["Total"])
    return out


def get_demand_frame(demand_item: str = "total") -> pd.DataFrame:
    """
    Demand frame for the selected item: ``total`` | ``ldz`` | ``industrial`` | ``power``.

    * total — CE total-demand assets (existing)
    * ldz — CE component assets
    * industrial / power — CE component assets, with DE from DataQuery and NL
      stitched (DataQuery history + CE recent)

    Austria is excluded from sector (non-total) frames — CE breakdown looks wrong.
    """
    item = (demand_item or "total").lower()
    if item in ("", "total"):
        return get_cached_demand()

    components = _get_cached_ce_components()
    base = components.get(item, pd.DataFrame())
    if item in ("industrial", "power"):
        return _drop_unreliable_sector_countries(
            _overlay_internal_demand(item, base)
        )

    if base is None or not isinstance(base, pd.DataFrame) or base.empty:
        raise RuntimeError(
            f"CE cache has no '{item}' demand component. "
            "Refresh Commodity Essentials / wait for warm-up."
        )
    return _drop_unreliable_sector_countries(base)
