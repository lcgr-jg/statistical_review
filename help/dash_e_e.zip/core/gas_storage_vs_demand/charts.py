"""Storage vs Demand charts — YoY stock as % of annual consumption."""
from __future__ import annotations

from datetime import date, datetime

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.gas_storage_summary.charts import yoy_day_hover_labels
from core.gas_storage_vs_demand.constants import (
    RANGE_POST_UKRAINE,
    YEAR_BASIS_CALENDAR,
    YEAR_BASIS_GAS,
    is_post_ukraine_year,
    resolve_chart_countries,
    year_label,
    yoy_current_year,
)
from core.gas_storage_summary.constants import yoy_year_line_style
from core.styles import COLORS

_DEMAND_WINDOW_DAYS = 365
_DEMAND_MIN_PERIODS = 180

_YEAR_COLORS = [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b",
    "#e377c2",
    "#7f7f7f",
    "#bcbd22",
    "#17becf",
]

_MONTH_TICK_DOY = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
_MONTH_TICK_LABELS = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
]

_GAS_YEAR_TICK_DOY: list[int] = []
_GAS_YEAR_TICK_LABELS = [
    "Oct",
    "Nov",
    "Dec",
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
]
_gy_tick_start = date(2021, 10, 1)
for _m, _y in zip(
    [10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [2021, 2021, 2021, 2022, 2022, 2022, 2022, 2022, 2022, 2022, 2022, 2022],
):
    _GAS_YEAR_TICK_DOY.append((date(_y, _m, 1) - _gy_tick_start).days + 1)


def _empty_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
        font=dict(size=14, color="#666666"),
    )
    fig.update_layout(
        template="plotly_white",
        height=400,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
    )
    return fig


def _stock_col(country: str) -> str:
    return "Total|stock" if country == "Total" else f"{country}|stock"


def _demand_col(country: str) -> str:
    return "Total" if country == "Total" else country


def _storage_vs_demand_series(
    df_fill: pd.DataFrame,
    df_demand: pd.DataFrame,
    country: str,
) -> pd.Series | None:
    """
    Full-history series: stock ÷ annual consumption × 100.

    Annual consumption is the trailing 365-day sum of daily demand (same idea as
    the LinkedIn / GIE-style "gas in storage / annual consumption" chart).
    """
    stock_col = _stock_col(country)
    dem_col = _demand_col(country)
    if stock_col not in df_fill.columns or dem_col not in df_demand.columns:
        return None

    stock = df_fill[stock_col].astype(float)
    demand = df_demand[dem_col].astype(float).abs()
    aligned = pd.concat({"stock": stock, "demand": demand}, axis=1, join="inner")
    aligned = aligned[~aligned.index.duplicated(keep="last")].sort_index()
    if aligned.empty:
        return None

    annual_consumption = (
        aligned["demand"]
        .rolling(_DEMAND_WINDOW_DAYS, min_periods=_DEMAND_MIN_PERIODS)
        .sum()
        .replace(0, np.nan)
    )
    pct = (aligned["stock"] / annual_consumption) * 100.0
    return pct.dropna()


def _pct_by_year(
    full_pct: pd.Series,
    year: int,
    to_date: date,
    basis: str = YEAR_BASIS_CALENDAR,
) -> pd.Series | None:
    """Slice *full_pct* to calendar or gas *year* and reindex by day-of-(gas)-year."""
    if basis == YEAR_BASIS_GAS:
        start = pd.Timestamp(f"{year}-10-01")
        end = pd.Timestamp(f"{year + 1}-09-30")
        if year == yoy_current_year(YEAR_BASIS_GAS, to_date):
            end = min(end, pd.Timestamp(to_date))
    else:
        start = pd.Timestamp(f"{year}-01-01")
        end = pd.Timestamp(f"{year}-12-31")
        if year == to_date.year:
            end = min(end, pd.Timestamp(to_date))

    try:
        slice_ = full_pct.loc[start:end]
    except Exception:
        return None
    if slice_.empty:
        return None

    if basis == YEAR_BASIS_GAS:
        idx = ((slice_.index.normalize() - start).days + 1).astype(int)
    else:
        idx = slice_.index.dayofyear.astype(int)

    out = pd.Series(slice_.values, index=idx, name=year)
    out = out[~out.index.duplicated(keep="last")].sort_index()
    return out if not out.empty else None


def _range_band(
    yearly: dict[int, pd.Series],
    years: list[int],
) -> tuple[pd.Series, pd.Series] | tuple[None, None]:
    sample = [yearly[y] for y in years if y in yearly]
    if not sample:
        return None, None
    all_days = sorted(set().union(*(s.index.tolist() for s in sample)))
    mins, maxs = [], []
    for d in all_days:
        vals = [float(s.loc[d]) for s in sample if d in s.index and pd.notna(s.loc[d])]
        if not vals:
            continue
        mins.append((d, min(vals)))
        maxs.append((d, max(vals)))
    if not mins:
        return None, None
    return (
        pd.Series([v for _, v in mins], index=[d for d, _ in mins]),
        pd.Series([v for _, v in maxs], index=[d for d, _ in maxs]),
    )


def build_yoy_storage_demand_chart(
    df_fill: pd.DataFrame,
    df_demand: pd.DataFrame,
    selected_years: list[int] | None = None,
    range_years: int | str = 0,
    to_date: datetime | pd.Timestamp | None = None,
    countries: list[str] | None = None,
    year_basis: str = YEAR_BASIS_CALENDAR,
    demand_mode: str = "observed",
    demand_item: str = "total",
) -> go.Figure:
    """
    YoY storage / demand % — top panel + optional country subplots.

    Metric: ``stock / annual_consumption × 100`` (annual = trailing 365d sum).
    *year_basis*: ``calendar`` (Jan–Dec) or ``gas`` (Oct–Sep, labels GY####).
    *range_years*: if 3/5/7, shade min–max band; if ``post_ukraine``, emphasise
    calendar 2022+ / GY2023+ lines.
    *demand_mode*: ``observed`` or ``weather_norm``.
    *demand_item*: ``total`` / ``ldz`` / ``industrial`` / ``power``.
    """
    today = pd.Timestamp(to_date or datetime.now()).normalize().date()
    basis = (
        YEAR_BASIS_GAS if year_basis == YEAR_BASIS_GAS else YEAR_BASIS_CALENDAR
    )
    current_year = yoy_current_year(basis, today)
    selected = sorted({int(y) for y in (selected_years or []) if int(y) < current_year})
    band_years_n = (
        int(range_years)
        if isinstance(range_years, int) and range_years > 0
        else 0
    )
    highlight_post_ukraine = range_years == RANGE_POST_UKRAINE
    wx_norm = demand_mode == "weather_norm"
    item = (demand_item or "total").lower()
    item_title = {
        "total": "Demand",
        "ldz": "LDZ",
        "industrial": "Industrial",
        "power": "Power",
    }.get(item, item.title())

    if df_fill is None or df_fill.empty:
        return _empty_fig("No fill (stock) data in CE cache")
    if df_demand is None or df_demand.empty:
        return _empty_fig("No demand data in CE cache")

    top_panel, country_cols = resolve_chart_countries(countries)
    country_cols = [
        c
        for c in country_cols
        if _stock_col(c) in df_fill.columns and _demand_col(c) in df_demand.columns
    ]
    if not (
        _stock_col(top_panel) in df_fill.columns
        and _demand_col(top_panel) in df_demand.columns
    ):
        return _empty_fig(f"No storage/demand data for {top_panel}")

    n_country_rows = (len(country_cols) + 1) // 2
    n_rows = 1 + n_country_rows
    fig_height = 520 + n_country_rows * 200
    if n_country_rows == 0:
        fig_height = 520
    row_heights = [2.2] + [1.0] * n_country_rows if n_country_rows else None

    top_title = (
        f"Total Storage / {item_title}"
        if top_panel == "Total"
        else f"{top_panel} Storage / {item_title}"
    )
    if wx_norm:
        top_title = f"{top_title} (wx-norm)"
    subplot_titles = [top_title] + [
        f"{c} (wx-norm)" if wx_norm else c for c in country_cols
    ]
    while len(subplot_titles) < 1 + max(n_country_rows, 0) * 2:
        subplot_titles.append("")

    if n_country_rows == 0:
        fig = make_subplots(
            rows=1,
            cols=2,
            specs=[[{"colspan": 2}, None]],
            subplot_titles=subplot_titles[:1],
            vertical_spacing=0.08,
            horizontal_spacing=0.08,
        )
    else:
        specs = [[{"colspan": 2}, None]] + [[{}, {}] for _ in range(n_country_rows)]
        fig = make_subplots(
            rows=n_rows,
            cols=2,
            specs=specs,
            subplot_titles=subplot_titles,
            row_heights=row_heights,
            vertical_spacing=0.08,
            horizontal_spacing=0.08,
        )

    tick_vals = _GAS_YEAR_TICK_DOY if basis == YEAR_BASIS_GAS else _MONTH_TICK_DOY
    tick_text = (
        _GAS_YEAR_TICK_LABELS if basis == YEAR_BASIS_GAS else _MONTH_TICK_LABELS
    )
    basis_title = (
        "gas year (Oct–Sep)" if basis == YEAR_BASIS_GAS else "calendar year"
    )

    def _plot_panel(row: int, col: int, country: str, *, show_legend: bool) -> None:
        full_pct = _storage_vs_demand_series(df_fill, df_demand, country)
        if full_pct is None or full_pct.empty:
            return

        years_to_load = sorted(set(selected) | {current_year})
        if band_years_n:
            years_to_load = sorted(
                set(years_to_load)
                | set(range(current_year - band_years_n, current_year))
            )

        yearly: dict[int, pd.Series] = {}
        for year in years_to_load:
            series = _pct_by_year(full_pct, year, today, basis=basis)
            if series is not None and not series.empty:
                yearly[year] = series

        if band_years_n:
            band_years = list(range(current_year - band_years_n, current_year))
            lo, hi = _range_band(yearly, band_years)
            if lo is not None and hi is not None:
                fig.add_trace(
                    go.Scatter(
                        x=hi.index.tolist(),
                        y=hi.values,
                        mode="lines",
                        line=dict(width=0),
                        showlegend=False,
                        hoverinfo="skip",
                    ),
                    row=row,
                    col=col,
                )
                fig.add_trace(
                    go.Scatter(
                        x=lo.index.tolist(),
                        y=lo.values,
                        customdata=yoy_day_hover_labels(lo.index.tolist(), basis),
                        mode="lines",
                        line=dict(width=0),
                        fill="tonexty",
                        fillcolor="rgba(150, 150, 150, 0.25)",
                        name=f"{band_years_n}Y range",
                        legendgroup="range",
                        showlegend=show_legend,
                        hovertemplate=(
                            f"{band_years_n}Y range<br>%{{customdata}} · %{{y:.1f}}%"
                            "<extra></extra>"
                        ),
                    ),
                    row=row,
                    col=col,
                )

        plot_years = [y for y in selected if y in yearly] + (
            [current_year] if current_year in yearly else []
        )
        color_by_year = {
            y: _YEAR_COLORS[i % len(_YEAR_COLORS)] for i, y in enumerate(plot_years)
        }
        if highlight_post_ukraine:
            pre = [
                y
                for y in plot_years
                if y != current_year and not is_post_ukraine_year(y, basis)
            ]
            post = [
                y
                for y in plot_years
                if y != current_year and is_post_ukraine_year(y, basis)
            ]
            cur = [current_year] if current_year in yearly else []
            draw_years = pre + post + cur
        else:
            draw_years = plot_years

        for year in draw_years:
            series = yearly[year]
            label = year_label(year, basis)
            width, opacity = yoy_year_line_style(
                year,
                current_year=current_year,
                basis=basis,
                highlight_post_ukraine=highlight_post_ukraine,
            )
            fig.add_trace(
                go.Scatter(
                    x=series.index.tolist(),
                    y=series.values,
                    customdata=yoy_day_hover_labels(series.index.tolist(), basis),
                    mode="lines",
                    name=label,
                    legendgroup=label,
                    showlegend=show_legend,
                    line=dict(
                        color=color_by_year[year],
                        width=width,
                    ),
                    opacity=opacity,
                    hovertemplate=(
                        f"{label}<br>%{{customdata}} · %{{y:.1f}}%<extra></extra>"
                    ),
                ),
                row=row,
                col=col,
            )

        fig.update_xaxes(
            range=[1, 366],
            tickmode="array",
            tickvals=tick_vals,
            ticktext=tick_text,
            row=row,
            col=col,
        )
        fig.update_yaxes(rangemode="tozero", row=row, col=col)

    _plot_panel(1, 1, top_panel, show_legend=True)
    for i, country in enumerate(country_cols):
        r = 2 + i // 2
        c = 1 + i % 2
        _plot_panel(r, c, country, show_legend=False)

    prior_label = (
        ", ".join(year_label(y, basis) for y in selected) if selected else "none"
    )
    if highlight_post_ukraine:
        range_note = " · post-Ukraine years highlighted"
    elif band_years_n:
        range_note = f" · {band_years_n}Y min–max band"
    else:
        range_note = ""
    demand_note = (
        f" · weather-normalised {item_title.lower()}"
        if wx_norm
        else f" · observed {item_title.lower()}"
    )
    current_label = year_label(current_year, basis)
    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=(
                f"Storage / annual {item_title.lower()} % by {basis_title}  ·  "
                f"{current_label} + selected priors{range_note}{demand_note}"
            ),
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        height=fig_height,
        autosize=True,
        uirevision=(
            f"stor-dem-yoy-{basis}-{current_year}-{prior_label}-{range_years}-"
            f"{demand_mode}-{item}-{top_panel}-{','.join(country_cols)}"
        ),
        margin=dict(l=50, r=24, t=70, b=90),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.04,
            xanchor="center",
            x=0.5,
        ),
        hovermode="x unified",
    )
    y_title = (
        f"% of annual {item_title.lower()} (wx-norm)"
        if wx_norm
        else f"% of annual {item_title.lower()}"
    )
    fig.update_yaxes(
        title_text=y_title,
        showgrid=True,
        gridcolor="#eee",
    )
    fig.update_xaxes(showgrid=True, gridcolor="#f0f0f0")
    for ann in fig.layout.annotations:
        if ann.text:
            ann.font = dict(size=12)

    return fig
