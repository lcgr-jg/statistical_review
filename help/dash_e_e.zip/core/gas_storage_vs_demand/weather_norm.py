"""Weather-normalise country gas demand using HDD, wind speed, and wind gen."""
from __future__ import annotations

import logging
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

from core.gas_storage_summary.constants import COUNTRY_CODES
from core.weather_bbg.data import get_country_weather, get_wind_generation_daily

logger = logging.getLogger(__name__)

# Fit betas on pre-Ukraine history so structural demand loss is not absorbed
# into weather coefficients.
_FIT_START = "2016-01-01"
_FIT_END = "2021-12-31"
_MIN_FIT_ROWS = 365


def _naive_day_index(idx) -> pd.DatetimeIndex:
    out = pd.to_datetime(idx)
    if getattr(out, "tz", None) is not None:
        out = out.tz_localize(None)
    return pd.DatetimeIndex(out).normalize()


def _doy_climate_lookup(series: pd.Series, index: pd.DatetimeIndex) -> pd.Series:
    """
    Long-run mean by day-of-year, mapped onto *index*.

    Climate is built from non-null *series* values, then applied to every date
    in *index* via day-of-year (so dates with missing observations still get a
    climate value when that DOY exists in history).
    """
    s = series.astype(float).dropna()
    if s.empty:
        return pd.Series(np.nan, index=index, dtype=float)
    clim = s.groupby(s.index.dayofyear).mean()
    return pd.Series(index.dayofyear.map(clim), index=index, dtype=float)


def _weekday_dummies(index: pd.DatetimeIndex) -> pd.DataFrame:
    # Drop Monday (0) as baseline.
    wd = pd.Series(index.dayofweek, index=index, name="wd")
    dummies = pd.get_dummies(wd, prefix="wd", drop_first=True).astype(float)
    return dummies


def _feature_plan(demand_item: str) -> tuple[list[str], bool]:
    """
    Return ``(base_features, allow_wgen)`` for the demand sector.

    * total — HDD + wind speed; wind gen if available
    * ldz — HDD + wind speed (heating-led; no wind gen)
    * industrial — HDD + wind speed
    * power — wind gen + wind speed (+ HDD if available); wind gen preferred
    """
    item = (demand_item or "total").lower()
    if item == "power":
        return ["wspd", "hdd"], True
    if item == "ldz":
        return ["hdd", "wspd"], False
    if item == "industrial":
        return ["hdd", "wspd"], False
    return ["hdd", "wspd"], True


def weather_normalise_country_demand(
    demand: pd.Series,
    weather: pd.DataFrame,
    wind_gen: pd.Series | None = None,
    demand_item: str = "total",
) -> pd.Series:
    """
    Remove weather-driven demand anomalies.

    ``D_norm = D - β · (X - X_climate)`` with sector-specific drivers (HDD,
    wind speed, wind generation) plus weekday dummies. Climate = long-run
    day-of-year means. Betas fit on 2016–2021.
    """
    if demand is None or demand.empty:
        return pd.Series(dtype=float)

    dem = demand.astype(float).abs().copy()
    dem.index = _naive_day_index(dem.index)
    dem = dem[~dem.index.duplicated(keep="last")].sort_index()

    wx = weather.copy()
    wx.index = _naive_day_index(wx.index)
    wx = wx[~wx.index.duplicated(keep="last")].sort_index()

    frame = pd.DataFrame({"demand": dem})
    if "hdd_c" in wx.columns:
        frame["hdd"] = pd.to_numeric(wx["hdd_c"], errors="coerce")
    else:
        frame["hdd"] = np.nan
    if "w_ms" in wx.columns:
        frame["wspd"] = pd.to_numeric(wx["w_ms"], errors="coerce")
    else:
        frame["wspd"] = np.nan

    if wind_gen is not None and not wind_gen.empty:
        wg = pd.to_numeric(wind_gen, errors="coerce").copy()
        wg.index = _naive_day_index(wg.index)
        wg = wg[~wg.index.duplicated(keep="last")].sort_index()
        frame["wgen"] = wg
    else:
        frame["wgen"] = np.nan

    frame = frame.sort_index()
    frame["hdd_clim"] = _doy_climate_lookup(frame["hdd"], frame.index)
    frame["wspd_clim"] = _doy_climate_lookup(frame["wspd"], frame.index)
    frame["wgen_clim"] = _doy_climate_lookup(frame["wgen"], frame.index)

    base_features, allow_wgen = _feature_plan(demand_item)
    # Keep only features that have enough non-null history to be useful.
    feature_cols = [
        f for f in base_features if int(frame[f].notna().sum()) >= _MIN_FIT_ROWS
    ]
    if not feature_cols:
        logger.warning(
            "Weather-norm: no usable weather features for item=%s — observed",
            demand_item,
        )
        return dem
    clim_cols = [f"{f}_clim" for f in feature_cols]

    fit_window = (
        (frame.index >= pd.Timestamp(_FIT_START))
        & (frame.index <= pd.Timestamp(_FIT_END))
        & frame["demand"].notna()
        & frame[feature_cols].notna().all(axis=1)
        & frame[clim_cols].notna().all(axis=1)
    )

    wgen_fit_ok = False
    if allow_wgen:
        wgen_fit_ok = (
            int(
                (
                    fit_window
                    & frame["wgen"].notna()
                    & frame["wgen_clim"].notna()
                ).sum()
            )
            >= _MIN_FIT_ROWS
        )
        if wgen_fit_ok:
            feature_cols = list(feature_cols) + ["wgen"]
            clim_cols = list(clim_cols) + ["wgen_clim"]

    # Power sector: require wind gen when that is the main driver.
    if (demand_item or "").lower() == "power" and not wgen_fit_ok:
        logger.warning(
            "Weather-norm power: insufficient wind-gen history — returning observed"
        )
        return dem

    fit_mask = fit_window & frame[feature_cols].notna().all(axis=1)
    if wgen_fit_ok:
        fit_mask = fit_mask & frame["wgen_clim"].notna()

    fit = frame.loc[fit_mask].copy()
    if len(fit) < _MIN_FIT_ROWS:
        logger.warning(
            "Weather-norm fit sample too small (%d rows, item=%s) — observed",
            len(fit),
            demand_item,
        )
        return dem

    wd_fit = _weekday_dummies(fit.index)
    x_fit = pd.concat([fit[feature_cols], wd_fit], axis=1).astype(float)
    y_fit = fit["demand"].astype(float)
    complete_fit = x_fit.notna().all(axis=1) & y_fit.notna()
    x_fit = x_fit.loc[complete_fit]
    y_fit = y_fit.loc[complete_fit]
    if len(x_fit) < _MIN_FIT_ROWS:
        logger.warning(
            "Weather-norm complete fit rows too few (%d) — returning observed",
            len(x_fit),
        )
        return dem

    model = LinearRegression()
    model.fit(x_fit.to_numpy(), y_fit.to_numpy())

    # Core features excluding optional wgen (filled as zero-anomaly when missing).
    core_feats = [f for f in feature_cols if f != "wgen"]
    core_clim = [f"{f}_clim" for f in core_feats]
    apply_mask = (
        frame["demand"].notna()
        & frame[core_feats].notna().all(axis=1)
        & frame[core_clim].notna().all(axis=1)
    )
    apply = frame.loc[apply_mask].copy()
    if apply.empty:
        return dem

    if wgen_fit_ok:
        missing_wgen = apply["wgen"].isna()
        apply.loc[missing_wgen, "wgen"] = apply.loc[missing_wgen, "wgen_clim"]
        still_bad = apply["wgen"].isna() | apply["wgen_clim"].isna()
        apply = apply.loc[~still_bad].copy()
        if apply.empty:
            return dem

    wd_apply = _weekday_dummies(apply.index)
    for col in x_fit.columns:
        if col.startswith("wd_") and col not in wd_apply.columns:
            wd_apply[col] = 0.0
    wd_apply = wd_apply.reindex(
        columns=[c for c in x_fit.columns if c.startswith("wd_")],
        fill_value=0.0,
    )

    x_obs = pd.concat([apply[feature_cols], wd_apply], axis=1).astype(float)
    clim_features = apply[clim_cols].copy()
    clim_features.columns = feature_cols
    x_clim_df = pd.concat([clim_features, wd_apply], axis=1).astype(float)
    x_clim_df = x_clim_df[x_obs.columns]

    complete_apply = x_obs.notna().all(axis=1) & x_clim_df.notna().all(axis=1)
    x_obs = x_obs.loc[complete_apply]
    x_clim_df = x_clim_df.loc[complete_apply]
    dem_apply = apply.loc[complete_apply, "demand"]
    if x_obs.empty:
        return dem

    pred_obs = model.predict(x_obs.to_numpy())
    pred_clim = model.predict(x_clim_df.to_numpy())
    adjustment = pred_obs - pred_clim
    normalised = dem_apply - adjustment

    out = dem.copy()
    out.loc[normalised.index] = normalised
    return out.clip(lower=0.0)


def build_weather_normalised_demand(
    df_demand: pd.DataFrame,
    countries: Iterable[str] | None = None,
    demand_item: str = "total",
) -> pd.DataFrame:
    """
    Return a demand frame (same columns as *df_demand*) weather-normalised
    per country; ``Total`` is the sum of available country series.
    """
    codes = [c for c in (countries or COUNTRY_CODES) if c in COUNTRY_CODES]
    if not codes:
        codes = list(COUNTRY_CODES)

    try:
        wind_daily = get_wind_generation_daily()
    except Exception as exc:
        logger.warning("Wind generation unavailable for weather-norm: %s", exc)
        wind_daily = pd.DataFrame()

    out: dict[str, pd.Series] = {}
    for country in codes:
        if country not in df_demand.columns:
            continue
        try:
            weather = get_country_weather(country)
        except Exception as exc:
            logger.warning("Weather missing for %s: %s — using observed", country, exc)
            out[country] = df_demand[country].astype(float).abs()
            continue

        wind_col = (
            wind_daily[country]
            if (not wind_daily.empty and country in wind_daily.columns)
            else None
        )
        try:
            out[country] = weather_normalise_country_demand(
                df_demand[country],
                weather,
                wind_gen=wind_col,
                demand_item=demand_item,
            )
        except Exception as exc:
            logger.exception("Weather-norm failed for %s: %s", country, exc)
            out[country] = df_demand[country].astype(float).abs()

    if not out:
        return pd.DataFrame()

    result = pd.DataFrame(out).sort_index()
    total_codes = [c for c in COUNTRY_CODES if c in result.columns]
    if total_codes:
        result["Total"] = result[total_codes].sum(axis=1, min_count=1)
    elif "Total" in df_demand.columns:
        result["Total"] = df_demand["Total"].astype(float).abs()

    return result
