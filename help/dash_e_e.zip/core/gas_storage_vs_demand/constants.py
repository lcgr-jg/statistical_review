"""EU Gas Balance — Storage vs Demand page constants."""
from __future__ import annotations

import datetime as dt

from core.gas_storage_summary.constants import (
    COUNTRY_CODES,
    DEFAULT_MULTI_COUNTRIES,
    DEFAULT_YEAR_BASIS,
    FILL_DEFAULT_PRIOR_YEARS,
    FILL_HISTORY_YEAR_MIN,
    FILL_RANGE_OPTIONS,
    MULTI_COUNTRY_OPTIONS,
    RANGE_POST_UKRAINE,
    YEAR_BASIS_CALENDAR,
    YEAR_BASIS_GAS,
    YEAR_BASIS_OPTIONS,
    default_fill_years,
    fill_year_options,
    is_post_ukraine_year,
    resolve_chart_countries,
    year_label,
    yoy_current_year,
)

PAGE_PATH = "/power/gas_balance/storage_vs_demand"
PAGE_NAME = "Storage vs Demand"
PAGE_TITLE = "EU Gas Storage vs Demand | JG Power Dashboard"
PAGE_ORDER = 72

COUNTRIES = ["AT", "BE", "DE", "ES", "FR", "GB", "IT", "NL", "PT", "Total"]

# YoY chart history / prior-year defaults (shared with Storage Summary fill YoY).
HISTORY_YEAR_MIN = FILL_HISTORY_YEAR_MIN
DEFAULT_PRIOR_YEARS = FILL_DEFAULT_PRIOR_YEARS
RANGE_OPTIONS = list(FILL_RANGE_OPTIONS)
DEFAULT_RANGE_YEARS = 0

# Demand basis for the YoY storage / demand % chart.
DEMAND_MODE_OBSERVED = "observed"
DEMAND_MODE_WEATHER_NORM = "weather_norm"
DEMAND_MODE_OPTIONS = [
    {"label": "Observed demand", "value": DEMAND_MODE_OBSERVED},
    {"label": "Weather-normalised", "value": DEMAND_MODE_WEATHER_NORM},
]
DEFAULT_DEMAND_MODE = DEMAND_MODE_OBSERVED

# Which demand series feeds the annual-consumption denominator.
DEMAND_ITEM_TOTAL = "total"
DEMAND_ITEM_LDZ = "ldz"
DEMAND_ITEM_INDUSTRIAL = "industrial"
DEMAND_ITEM_POWER = "power"
DEMAND_ITEM_OPTIONS = [
    {"label": "Total demand", "value": DEMAND_ITEM_TOTAL},
    {"label": "LDZ", "value": DEMAND_ITEM_LDZ},
    {"label": "Industrial", "value": DEMAND_ITEM_INDUSTRIAL},
    {"label": "Power (CCGT)", "value": DEMAND_ITEM_POWER},
]
DEFAULT_DEMAND_ITEM = DEMAND_ITEM_TOTAL

# Austria sector CE series look unreliable — exclude from non-total demand views.
SECTOR_EXCLUDED_COUNTRIES = ("AT",)
SECTOR_COUNTRY_CODES = [c for c in COUNTRY_CODES if c not in SECTOR_EXCLUDED_COUNTRIES]
SECTOR_MULTI_COUNTRY_OPTIONS = [{"label": c, "value": c} for c in SECTOR_COUNTRY_CODES]
# Match Storage Summary: ES/PT optional (not pre-selected).
DEFAULT_SECTOR_MULTI_COUNTRIES = [
    c for c in SECTOR_COUNTRY_CODES if c in DEFAULT_MULTI_COUNTRIES
]

def countries_for_demand_item(
    demand_item: str,
    selected: list[str] | str | None = None,
) -> list[str]:
    """
    Country list for charts / aggregation.

    For sector demand (LDZ / industrial / power), Austria is dropped because
    the CE breakdown series look wrong.
    """
    item = (demand_item or DEMAND_ITEM_TOTAL).lower()
    if isinstance(selected, str):
        selected = [selected]
    codes = [c for c in (selected or []) if c in COUNTRY_CODES]
    if item != DEMAND_ITEM_TOTAL:
        codes = [c for c in codes if c not in SECTOR_EXCLUDED_COUNTRIES]
        if not codes:
            codes = list(DEFAULT_SECTOR_MULTI_COUNTRIES)
    elif not codes:
        codes = list(DEFAULT_MULTI_COUNTRIES)
    # Preserve canonical order
    allowed = COUNTRY_CODES if item == DEMAND_ITEM_TOTAL else SECTOR_COUNTRY_CODES
    return [c for c in allowed if c in codes]


def year_options(
    today: dt.date | None = None,
    basis: str = YEAR_BASIS_CALENDAR,
) -> list[dict]:
    """Selectable prior years for the YoY chart (excludes current year/GY)."""
    return fill_year_options(today=today, basis=basis)


def default_years(
    today: dt.date | None = None,
    basis: str = YEAR_BASIS_CALENDAR,
) -> list[int]:
    """Most recent prior years for the selected basis."""
    return default_fill_years(today=today, basis=basis)
