"""Charts / tables for demand pattern analysis on Storage vs Demand."""
from __future__ import annotations

from datetime import date, datetime

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.gas_storage_summary.charts import yoy_day_hover_labels
from core.gas_storage_summary.constants import (
    YEAR_BASIS_CALENDAR,
    YEAR_BASIS_GAS,
    is_post_ukraine_year,
    year_label,
    yoy_current_year,
    yoy_year_line_style,
)
from core.gas_storage_vs_demand.charts import (
    _GAS_YEAR_TICK_DOY,
    _GAS_YEAR_TICK_LABELS,
    _MONTH_TICK_DOY,
    _MONTH_TICK_LABELS,
    _YEAR_COLORS,
    _pct_by_year,
)
from core.styles import COLORS

_COLD = "#1f4e79"
_MILD = "#c47a2c"
_NORMAL = "#7f7f7f"
_OBS = "#2ca02c"
_WX = "#1f77b4"
_DELTA = "#d62728"
_PRE = "#9467bd"
_POST = "#e377c2"


def empty_pattern_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
        font=dict(size=13, color="#888"),
    )
    fig.update_layout(
        template="plotly_white",
        height=280,
        margin=dict(l=40, r=20, t=40, b=40),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
    )
    return fig


def build_winter_severity_chart(
    winter_df: pd.DataFrame,
    *,
    title_suffix: str = "",
) -> go.Figure:
    """Bar chart: mean winter demand (observed vs wx-norm) coloured by severity."""
    if winter_df is None or winter_df.empty:
        return empty_pattern_fig("No winter demand history")

    df = winter_df.copy()
    colors = df["severity"].map(
        {"cold": _COLD, "mild": _MILD, "normal": _NORMAL}
    ).fillna(_NORMAL)

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            name="Observed",
            x=df["winter"],
            y=df["demand_obs_mean"],
            marker_color=colors,
            opacity=0.85,
            hovertemplate=(
                "%{x}<br>observed %{y:.1f} mcm/d<br>"
                "severity=%{customdata}<extra></extra>"
            ),
            customdata=df["severity"],
        )
    )
    if df["demand_wx_mean"].notna().any():
        fig.add_trace(
            go.Bar(
                name="Weather-normalised",
                x=df["winter"],
                y=df["demand_wx_mean"],
                marker_color=_WX,
                opacity=0.55,
                hovertemplate="%{x}<br>wx-norm %{y:.1f} mcm/d<extra></extra>",
            )
        )

    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=f"Winter demand by season (Nov–Mar){title_suffix}",
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        barmode="group",
        height=380,
        margin=dict(l=50, r=20, t=50, b=60),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(orientation="h", y=-0.18, x=0.5, xanchor="center"),
        yaxis_title="Mean demand (mcm/d)",
        annotations=[
            dict(
                text="Bar colour = winter severity from HDD (cold / mild / normal)",
                xref="paper",
                yref="paper",
                x=0,
                y=1.08,
                showarrow=False,
                font=dict(size=11, color="#666"),
            )
        ],
    )
    fig.update_xaxes(tickangle=-35)
    return fig


def build_regime_comparison_chart(
    regime_df: pd.DataFrame,
    *,
    title_suffix: str = "",
) -> go.Figure:
    """Side-by-side: cold vs mild winters, and pre vs post Ukraine."""
    if regime_df is None or regime_df.empty:
        return empty_pattern_fig("No regime summary")

    fig = make_subplots(
        rows=1,
        cols=2,
        subplot_titles=(
            "Cold vs mild winters",
            "Pre vs post Ukraine",
        ),
        horizontal_spacing=0.1,
    )

    sev = regime_df.loc[regime_df["group"] == "winter_severity"].copy()
    sev = sev[sev["regime"].isin(["cold", "mild"])]
    if not sev.empty:
        order = {"cold": 0, "mild": 1}
        sev = sev.sort_values("regime", key=lambda s: s.map(order))
        fig.add_trace(
            go.Bar(
                name="Observed",
                x=sev["regime"],
                y=sev["demand_obs_mean"],
                marker_color=[_COLD if r == "cold" else _MILD for r in sev["regime"]],
                legendgroup="obs",
                hovertemplate="%{x}<br>obs %{y:.1f} mcm/d<extra></extra>",
            ),
            row=1,
            col=1,
        )
        if sev["demand_wx_mean"].notna().any():
            fig.add_trace(
                go.Bar(
                    name="Wx-norm",
                    x=sev["regime"],
                    y=sev["demand_wx_mean"],
                    marker_color=_WX,
                    opacity=0.7,
                    legendgroup="wx",
                    hovertemplate="%{x}<br>wx-norm %{y:.1f} mcm/d<extra></extra>",
                ),
                row=1,
                col=1,
            )

    ukr = regime_df.loc[regime_df["group"] == "ukraine"].copy()
    if not ukr.empty:
        order = {"pre-Ukraine": 0, "post-Ukraine": 1}
        ukr = ukr.sort_values("regime", key=lambda s: s.map(order))
        fig.add_trace(
            go.Bar(
                name="Observed",
                x=ukr["regime"],
                y=ukr["demand_obs_mean"],
                marker_color=[_PRE if "pre" in r else _POST for r in ukr["regime"]],
                legendgroup="obs",
                showlegend=False,
                hovertemplate="%{x}<br>obs %{y:.1f} mcm/d<extra></extra>",
            ),
            row=1,
            col=2,
        )
        if ukr["demand_wx_mean"].notna().any():
            fig.add_trace(
                go.Bar(
                    name="Wx-norm",
                    x=ukr["regime"],
                    y=ukr["demand_wx_mean"],
                    marker_color=_WX,
                    opacity=0.7,
                    legendgroup="wx",
                    showlegend=False,
                    hovertemplate="%{x}<br>wx-norm %{y:.1f} mcm/d<extra></extra>",
                ),
                row=1,
                col=2,
            )

    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=f"Demand regimes — observed vs weather-normalised{title_suffix}",
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        barmode="group",
        height=360,
        margin=dict(l=50, r=20, t=70, b=50),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(orientation="h", y=-0.15, x=0.5, xanchor="center"),
    )
    fig.update_yaxes(title_text="Mean winter demand (mcm/d)", row=1, col=1)
    fig.update_yaxes(title_text="Mean winter demand (mcm/d)", row=1, col=2)
    return fig


def build_wx_impact_chart(
    monthly: pd.DataFrame,
    *,
    title_suffix: str = "",
) -> go.Figure:
    """Monthly observed vs wx-norm and the weather adjustment (obs − wx)."""
    if monthly is None or monthly.empty:
        return empty_pattern_fig("No weather-normalisation history")

    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        row_heights=[0.62, 0.38],
        vertical_spacing=0.08,
        subplot_titles=(
            "Monthly demand — observed vs weather-normalised",
            "Weather adjustment (observed − wx-norm)",
        ),
    )
    x = pd.to_datetime(monthly["month"])
    fig.add_trace(
        go.Scatter(
            x=x,
            y=monthly["obs"],
            name="Observed",
            line=dict(color=_OBS, width=1.6),
            hovertemplate="%{x|%b %Y}<br>obs %{y:.1f}<extra></extra>",
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=monthly["wx"],
            name="Wx-norm",
            line=dict(color=_WX, width=1.6),
            hovertemplate="%{x|%b %Y}<br>wx %{y:.1f}<extra></extra>",
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Bar(
            x=x,
            y=monthly["delta"],
            name="Obs − wx",
            marker_color=_DELTA,
            opacity=0.65,
            hovertemplate="%{x|%b %Y}<br>Δ %{y:.1f}<extra></extra>",
            showlegend=True,
        ),
        row=2,
        col=1,
    )
    fig.add_hline(y=0, line_width=0.6, line_color="#888", row=2, col=1)

    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=f"Impact of weather normalisation{title_suffix}",
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        height=520,
        margin=dict(l=50, r=20, t=60, b=40),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(orientation="h", y=-0.08, x=0.5, xanchor="center"),
        hovermode="x unified",
    )
    fig.update_yaxes(title_text="mcm/d", row=1, col=1)
    fig.update_yaxes(title_text="mcm/d", row=2, col=1)
    return fig


def winter_summary_table(winter_df: pd.DataFrame) -> list[dict]:
    """Dash DataTable rows for per-winter stats."""
    if winter_df is None or winter_df.empty:
        return []

    rows = []
    for _, r in winter_df.iterrows():
        obs = r["demand_obs_mean"]
        wx = r["demand_wx_mean"]
        delta = r["wx_delta_mean"]
        rows.append(
            {
                "Winter": r["winter"],
                "Severity": str(r.get("severity", "")),
                "Era": "post-Ukraine" if r.get("post_ukraine") else "pre-Ukraine",
                "HDD mean": None if pd.isna(r["hdd_mean"]) else round(float(r["hdd_mean"]), 2),
                "Obs mcm/d": None if pd.isna(obs) else round(float(obs), 1),
                "Wx-norm mcm/d": None if pd.isna(wx) else round(float(wx), 1),
                "Obs − wx": None if pd.isna(delta) else round(float(delta), 1),
            }
        )
    return rows


def regime_insight_text(regime_df: pd.DataFrame) -> str:
    """One-line insight comparing cold/mild and pre/post Ukraine (obs & wx)."""
    if regime_df is None or regime_df.empty:
        return ""

    parts: list[str] = []
    sev = {
        r["regime"]: r
        for _, r in regime_df.loc[regime_df["group"] == "winter_severity"].iterrows()
    }
    if "cold" in sev and "mild" in sev:
        cold_obs = sev["cold"]["demand_obs_mean"]
        mild_obs = sev["mild"]["demand_obs_mean"]
        cold_wx = sev["cold"]["demand_wx_mean"]
        mild_wx = sev["mild"]["demand_wx_mean"]
        if mild_obs and not np.isnan(mild_obs):
            parts.append(
                f"Cold winters run {cold_obs - mild_obs:+.1f} mcm/d vs mild on observed"
            )
        if (
            mild_wx
            and cold_wx
            and not np.isnan(mild_wx)
            and not np.isnan(cold_wx)
        ):
            parts.append(
                f"and {cold_wx - mild_wx:+.1f} mcm/d after weather-normalising"
            )

    ukr = {
        r["regime"]: r
        for _, r in regime_df.loc[regime_df["group"] == "ukraine"].iterrows()
    }
    if "pre-Ukraine" in ukr and "post-Ukraine" in ukr:
        pre_o = ukr["pre-Ukraine"]["demand_obs_mean"]
        post_o = ukr["post-Ukraine"]["demand_obs_mean"]
        pre_w = ukr["pre-Ukraine"]["demand_wx_mean"]
        post_w = ukr["post-Ukraine"]["demand_wx_mean"]
        if pre_o and not np.isnan(pre_o) and pre_o != 0:
            pct_o = 100.0 * (post_o - pre_o) / pre_o
            parts.append(f"Post-Ukraine observed winter demand {pct_o:+.1f}% vs pre")
        if (
            pre_w
            and post_w
            and not np.isnan(pre_w)
            and pre_w != 0
            and not np.isnan(post_w)
        ):
            pct_w = 100.0 * (post_w - pre_w) / pre_w
            parts.append(f"({pct_w:+.1f}% on wx-norm)")

    return " · ".join(parts)


def _add_yoy_demand_traces(
    fig: go.Figure,
    series: pd.Series,
    *,
    row: int,
    col: int,
    selected_years: list[int],
    basis: str,
    to_date: date,
    show_legend: bool,
    highlight_post_ukraine: bool = True,
) -> None:
    """Add YoY day-of-year demand lines for one panel."""
    if series is None or series.empty:
        return

    current = yoy_current_year(basis, to_date)
    years = sorted({int(y) for y in selected_years if int(y) < current})
    plot_years = [y for y in years]
    if current not in plot_years:
        plot_years.append(current)

    yearly: dict[int, pd.Series] = {}
    for year in plot_years:
        sliced = _pct_by_year(series, year, to_date, basis=basis)
        if sliced is not None and not sliced.empty:
            yearly[year] = sliced

    draw = [y for y in plot_years if y in yearly]
    if highlight_post_ukraine:
        pre = [y for y in draw if y != current and not is_post_ukraine_year(y, basis)]
        post = [y for y in draw if y != current and is_post_ukraine_year(y, basis)]
        cur = [current] if current in yearly else []
        draw = pre + post + cur

    color_by_year = {
        y: _YEAR_COLORS[i % len(_YEAR_COLORS)] for i, y in enumerate(plot_years)
    }
    for year in draw:
        s = yearly[year]
        label = year_label(year, basis)
        width, opacity = yoy_year_line_style(
            year,
            current_year=current,
            basis=basis,
            highlight_post_ukraine=highlight_post_ukraine,
        )
        fig.add_trace(
            go.Scatter(
                x=s.index.tolist(),
                y=s.values,
                customdata=yoy_day_hover_labels(s.index.tolist(), basis),
                mode="lines",
                name=label,
                legendgroup=label,
                showlegend=show_legend,
                line=dict(color=color_by_year.get(year, "#888"), width=width),
                opacity=opacity,
                hovertemplate=(
                    f"{label}<br>%{{customdata}} · %{{y:.1f}} mcm/d<extra></extra>"
                ),
            ),
            row=row,
            col=col,
        )

    tick_vals = _GAS_YEAR_TICK_DOY if basis == YEAR_BASIS_GAS else _MONTH_TICK_DOY
    tick_text = (
        _GAS_YEAR_TICK_LABELS if basis == YEAR_BASIS_GAS else _MONTH_TICK_LABELS
    )
    fig.update_xaxes(
        range=[1, 366],
        tickmode="array",
        tickvals=tick_vals,
        ticktext=tick_text,
        row=row,
        col=col,
    )
    fig.update_yaxes(title_text="mcm/d", rangemode="tozero", row=row, col=col)


def build_yoy_obs_wx_demand_charts(
    demand_obs: pd.Series,
    demand_wx: pd.Series,
    *,
    selected_years: list[int] | None = None,
    year_basis: str = YEAR_BASIS_CALENDAR,
    to_date: date | datetime | None = None,
    title_suffix: str = "",
) -> go.Figure:
    """
    Side-by-side YoY demand charts: observed (left) and weather-normalised (right).

    Uses the same calendar / gas-year day-of-year alignment as the main YoY plot.
    """
    today = pd.Timestamp(to_date or datetime.now()).normalize().date()
    basis = YEAR_BASIS_GAS if year_basis == YEAR_BASIS_GAS else YEAR_BASIS_CALENDAR
    current = yoy_current_year(basis, today)
    selected = list(selected_years or [])
    if not selected:
        # Fall back to recent priors so the chart is never empty of context.
        end = current - 1
        selected = list(range(max(2015, end - 6), end + 1))

    if (demand_obs is None or demand_obs.empty) and (
        demand_wx is None or demand_wx.empty
    ):
        return empty_pattern_fig("No demand series for YoY charts")

    basis_title = (
        "gas year (Oct–Sep)" if basis == YEAR_BASIS_GAS else "calendar year"
    )
    fig = make_subplots(
        rows=1,
        cols=2,
        subplot_titles=(
            f"Observed demand by {basis_title}",
            f"Weather-normalised demand by {basis_title}",
        ),
        horizontal_spacing=0.08,
        shared_yaxes=True,
    )

    _add_yoy_demand_traces(
        fig,
        demand_obs,
        row=1,
        col=1,
        selected_years=selected,
        basis=basis,
        to_date=today,
        show_legend=True,
    )
    _add_yoy_demand_traces(
        fig,
        demand_wx,
        row=1,
        col=2,
        selected_years=selected,
        basis=basis,
        to_date=today,
        show_legend=False,
    )

    fig.update_layout(
        template="plotly_white",
        title=dict(
            text=f"YoY demand — observed vs weather-normalised{title_suffix}",
            x=0.5,
            xanchor="center",
            font=dict(size=13),
        ),
        height=420,
        margin=dict(l=50, r=20, t=70, b=70),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(orientation="h", y=-0.18, x=0.5, xanchor="center"),
        hovermode="x unified",
        uirevision=f"dem-yoy-pair-{basis}-{current}-{','.join(map(str, selected))}",
    )
    fig.update_xaxes(showgrid=True, gridcolor="#f0f0f0")
    fig.update_yaxes(showgrid=True, gridcolor="#eee")
    for ann in fig.layout.annotations:
        if ann.text:
            ann.font = dict(size=12)
    return fig
