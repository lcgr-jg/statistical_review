"""Demand pattern analytics — winter severity, pre/post Ukraine, wx-norm deltas."""
from __future__ import annotations

import logging
from typing import Iterable

import numpy as np
import pandas as pd

from core.gas_storage_summary.constants import (
    COUNTRY_CODES,
    POST_UKRAINE_CALENDAR_YEAR,
)
from core.weather_bbg.data import get_country_weather

logger = logging.getLogger(__name__)

# Heating-season winter: 1 Nov Y → 31 Mar Y+1, labelled W{Y}/{Y+1 short}.
_WINTER_START_MONTH = 11
_WINTER_END_MONTH = 3


def winter_label(start_year: int) -> str:
    return f"W{start_year}/{(start_year + 1) % 100:02d}"


def winter_start_year(ts: pd.Timestamp) -> int | None:
    """Return the winter start year for a date, or None if outside Nov–Mar."""
    t = pd.Timestamp(ts)
    if t.month >= _WINTER_START_MONTH:
        return int(t.year)
    if t.month <= _WINTER_END_MONTH:
        return int(t.year) - 1
    return None


def _naive_day(s: pd.Series | pd.DataFrame):
    idx = pd.to_datetime(s.index if hasattr(s, "index") else s)
    if getattr(idx, "tz", None) is not None:
        idx = idx.tz_convert("UTC").tz_localize(None)
    return pd.DatetimeIndex(idx).normalize()


def aggregate_demand_series(
    df_demand: pd.DataFrame,
    countries: Iterable[str] | None = None,
) -> pd.Series:
    """
    Single daily demand series (mcm/d) for analysis.

    One country → that column; otherwise sum selected countries (prefer Total
    when all countries are selected and Total exists).
    """
    codes = [c for c in (countries or COUNTRY_CODES) if c in COUNTRY_CODES]
    if not codes:
        codes = list(COUNTRY_CODES)

    if len(codes) == 1 and codes[0] in df_demand.columns:
        s = pd.to_numeric(df_demand[codes[0]], errors="coerce")
    elif (
        set(codes) == set(COUNTRY_CODES)
        and "Total" in df_demand.columns
    ):
        s = pd.to_numeric(df_demand["Total"], errors="coerce")
    else:
        present = [c for c in codes if c in df_demand.columns]
        if not present:
            return pd.Series(dtype=float)
        s = df_demand[present].apply(pd.to_numeric, errors="coerce").sum(
            axis=1, min_count=1
        )

    s = s.copy()
    s.index = _naive_day(s)
    s = s[~s.index.duplicated(keep="last")].sort_index().astype(float)
    return s.abs()


def aggregate_hdd_series(
    countries: Iterable[str] | None = None,
) -> pd.Series:
    """Mean population-weighted country HDD (°C) across selected countries."""
    codes = [c for c in (countries or COUNTRY_CODES) if c in COUNTRY_CODES]
    if not codes:
        codes = list(COUNTRY_CODES)

    frames: list[pd.Series] = []
    for country in codes:
        try:
            wx = get_country_weather(country)
        except Exception as exc:
            logger.warning("HDD weather missing for %s: %s", country, exc)
            continue
        if wx is None or wx.empty or "hdd_c" not in wx.columns:
            continue
        hdd = pd.to_numeric(wx["hdd_c"], errors="coerce")
        hdd.index = _naive_day(hdd)
        hdd = hdd[~hdd.index.duplicated(keep="last")].sort_index()
        frames.append(hdd.rename(country))

    if not frames:
        return pd.Series(dtype=float)
    mat = pd.concat(frames, axis=1)
    return mat.mean(axis=1, skipna=True).sort_index()


def build_winter_summary(
    demand_obs: pd.Series,
    demand_wx: pd.Series,
    hdd: pd.Series,
) -> pd.DataFrame:
    """
    One row per winter with mean demand (obs / wx-norm), HDD, and severity.

    Severity: cold / mild / normal from HDD z-score vs other winters
    (|z|≥0.75 → cold/mild).
    """
    if demand_obs is None or demand_obs.empty:
        return pd.DataFrame()

    frame = pd.DataFrame(
        {
            "demand_obs": demand_obs,
            "demand_wx": demand_wx.reindex(demand_obs.index) if demand_wx is not None else np.nan,
            "hdd": hdd.reindex(demand_obs.index) if hdd is not None else np.nan,
        }
    ).sort_index()
    frame["winter"] = [winter_start_year(t) for t in frame.index]
    frame = frame.dropna(subset=["winter"])
    if frame.empty:
        return pd.DataFrame()

    rows = []
    for wy, g in frame.groupby("winter"):
        wy = int(wy)
        rows.append(
            {
                "winter_start": wy,
                "winter": winter_label(wy),
                "n_days": int(len(g)),
                "hdd_mean": float(g["hdd"].mean()) if g["hdd"].notna().any() else np.nan,
                "hdd_sum": float(g["hdd"].sum()) if g["hdd"].notna().any() else np.nan,
                "demand_obs_mean": float(g["demand_obs"].mean()),
                "demand_wx_mean": (
                    float(g["demand_wx"].mean())
                    if g["demand_wx"].notna().any()
                    else np.nan
                ),
                "wx_delta_mean": float(
                    (g["demand_obs"] - g["demand_wx"]).mean()
                )
                if g["demand_wx"].notna().any()
                else np.nan,
                "post_ukraine": wy + 1 >= POST_UKRAINE_CALENDAR_YEAR,
            }
        )

    out = pd.DataFrame(rows).sort_values("winter_start").reset_index(drop=True)
    if out.empty or out["hdd_mean"].notna().sum() < 3:
        out["severity"] = "unknown"
        out["hdd_z"] = np.nan
        return out

    mu = float(out["hdd_mean"].mean())
    sig = float(out["hdd_mean"].std(ddof=0)) or 1.0
    out["hdd_z"] = (out["hdd_mean"] - mu) / sig
    out["severity"] = np.where(
        out["hdd_z"] >= 0.75,
        "cold",
        np.where(out["hdd_z"] <= -0.75, "mild", "normal"),
    )
    return out


def build_regime_summary(winter_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate winters into cold / mild / normal and pre / post Ukraine."""
    if winter_df is None or winter_df.empty:
        return pd.DataFrame()

    rows = []

    def _agg(mask, label: str, group: str) -> None:
        sub = winter_df.loc[mask]
        if sub.empty:
            return
        rows.append(
            {
                "group": group,
                "regime": label,
                "n_winters": int(len(sub)),
                "hdd_mean": float(sub["hdd_mean"].mean()),
                "demand_obs_mean": float(sub["demand_obs_mean"].mean()),
                "demand_wx_mean": float(sub["demand_wx_mean"].mean())
                if sub["demand_wx_mean"].notna().any()
                else np.nan,
                "wx_delta_mean": float(sub["wx_delta_mean"].mean())
                if sub["wx_delta_mean"].notna().any()
                else np.nan,
            }
        )

    for sev in ("cold", "mild", "normal"):
        _agg(winter_df["severity"] == sev, sev, "winter_severity")

    _agg(~winter_df["post_ukraine"], "pre-Ukraine", "ukraine")
    _agg(winter_df["post_ukraine"], "post-Ukraine", "ukraine")

    return pd.DataFrame(rows)


def build_wx_impact_monthly(
    demand_obs: pd.Series,
    demand_wx: pd.Series,
) -> pd.DataFrame:
    """Monthly mean observed, wx-norm, and delta (obs − wx)."""
    if demand_obs is None or demand_obs.empty:
        return pd.DataFrame()
    frame = pd.DataFrame(
        {
            "obs": demand_obs,
            "wx": demand_wx.reindex(demand_obs.index) if demand_wx is not None else np.nan,
        }
    ).dropna(subset=["obs"])
    if frame.empty:
        return pd.DataFrame()
    frame["delta"] = frame["obs"] - frame["wx"]
    monthly = frame.resample("MS").mean()
    monthly["month"] = monthly.index
    return monthly.reset_index(drop=True)
