"""Layout for the EU Gas Balance — Storage vs Demand page."""
from __future__ import annotations

from dash import dash_table, dcc, html

from core.gas_storage_vs_demand.constants import (
    DEFAULT_DEMAND_ITEM,
    DEFAULT_DEMAND_MODE,
    DEFAULT_MULTI_COUNTRIES,
    DEFAULT_RANGE_YEARS,
    DEFAULT_YEAR_BASIS,
    DEMAND_ITEM_OPTIONS,
    DEMAND_MODE_OPTIONS,
    MULTI_COUNTRY_OPTIONS,
    RANGE_OPTIONS,
    YEAR_BASIS_OPTIONS,
    default_years,
    year_options,
)
from core.styles import COLORS

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "center",
    "flexWrap": "wrap",
    "gap": "12px",
}

_BTN_PRIMARY = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
    "transition": "all 0.2s",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "visible",
    "marginBottom": "20px",
}

_PANEL_HEADER = {
    "padding": "16px 20px 8px 20px",
    "display": "flex",
    "alignItems": "baseline",
    "flexWrap": "nowrap",
    "gap": "8px",
}

_PANEL_CONTROLS = {
    "padding": "0 20px 12px 20px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "whiteSpace": "nowrap",
    "flexShrink": "0",
}

_PANEL_SUBTITLE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "whiteSpace": "nowrap",
    "overflow": "hidden",
    "textOverflow": "ellipsis",
}

_YOY_CONTROLS_ROW = {
    "display": "flex",
    "flexWrap": "wrap",
    "gap": "20px",
    "alignItems": "flex-start",
}


def build_layout() -> html.Div:
    return html.Div(
        style={
            "minHeight": "100vh",
            "backgroundColor": COLORS["background"],
            "padding": "20px",
        },
        children=[
            html.Div(
                [
                    html.H1(
                        "Storage vs Demand",
                        style={
                            "fontSize": "22px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "margin": "0 0 4px 0",
                        },
                    ),
                    html.P(
                        "Gas in storage / annual consumption (percent) — "
                        "stock ÷ trailing 365-day demand × 100. Choose total "
                        "demand or a sector (LDZ / industrial / power). "
                        "Optional weather-normalised demand removes HDD / wind "
                        "anomalies (drivers vary by sector).",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 20px 0",
                        },
                    ),
                ]
            ),
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Button(
                        "Refresh",
                        id="gas-stor-dem-refresh",
                        n_clicks=0,
                        style=_BTN_PRIMARY,
                    ),
                    html.Div(id="gas-stor-dem-status"),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("YoY Storage / Demand %", style=_PANEL_TITLE),
                            html.Span(
                                id="gas-stor-dem-yoy-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style=_PANEL_CONTROLS,
                        children=[
                            html.Div(
                                style=_YOY_CONTROLS_ROW,
                                children=[
                                    html.Div(
                                        [
                                            html.Label("Year basis", style=_LABEL),
                                            dcc.RadioItems(
                                                id="gas-stor-dem-basis",
                                                options=YEAR_BASIS_OPTIONS,
                                                value=DEFAULT_YEAR_BASIS,
                                                inline=False,
                                                style={"fontSize": "13px"},
                                                labelStyle={
                                                    "display": "block",
                                                    "marginBottom": "4px",
                                                },
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Demand item", style=_LABEL),
                                            dcc.Dropdown(
                                                id="gas-stor-dem-item",
                                                options=DEMAND_ITEM_OPTIONS,
                                                value=DEFAULT_DEMAND_ITEM,
                                                clearable=False,
                                                style={"fontSize": "13px"},
                                            ),
                                        ],
                                        style={"minWidth": "160px"},
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Demand", style=_LABEL),
                                            dcc.RadioItems(
                                                id="gas-stor-dem-mode",
                                                options=DEMAND_MODE_OPTIONS,
                                                value=DEFAULT_DEMAND_MODE,
                                                inline=False,
                                                style={"fontSize": "13px"},
                                                labelStyle={
                                                    "display": "block",
                                                    "marginBottom": "4px",
                                                },
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label(
                                                "Historic range band",
                                                style=_LABEL,
                                            ),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-dem-range",
                                                    options=RANGE_OPTIONS,
                                                    value=DEFAULT_RANGE_YEARS,
                                                    clearable=False,
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "140px"},
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label(
                                                "Prior years to display",
                                                style=_LABEL,
                                            ),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-dem-years",
                                                    options=year_options(),
                                                    value=default_years(),
                                                    multi=True,
                                                    placeholder="Select years…",
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "280px"},
                                            ),
                                        ]
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Countries", style=_LABEL),
                                            html.Div(
                                                dcc.Dropdown(
                                                    id="gas-stor-dem-countries",
                                                    options=MULTI_COUNTRY_OPTIONS,
                                                    value=DEFAULT_MULTI_COUNTRIES,
                                                    multi=True,
                                                    placeholder="Select countries…",
                                                    style={"fontSize": "13px"},
                                                ),
                                                style={"width": "280px"},
                                            ),
                                        ]
                                    ),
                                ],
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=dcc.Graph(
                            id="gas-stor-dem-yoy-chart",
                            config={
                                "displayModeBar": True,
                                "responsive": True,
                            },
                            style={
                                "width": "100%",
                                "minHeight": "1400px",
                            },
                        ),
                    ),
                ],
            ),
            # Demand pattern analysis (winters / Ukraine / wx-norm)
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("Demand pattern analysis", style=_PANEL_TITLE),
                            html.Span(
                                id="gas-stor-dem-pattern-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style={
                            **_PANEL_CONTROLS,
                            "borderBottom": "none",
                            "paddingBottom": "4px",
                        },
                        children=[
                            html.P(
                                "Uses the same demand item and countries as above. "
                                "Winters are Nov–Mar; cold/mild from HDD z-score. "
                                "Pre-Ukraine = winters ending before 2022; "
                                "weather-normalised series removes HDD/wind anomalies.",
                                style={
                                    "fontSize": "12px",
                                    "color": COLORS["text_muted"],
                                    "margin": "0 0 8px 0",
                                },
                            ),
                            html.Div(
                                id="gas-stor-dem-pattern-insight",
                                style={
                                    "fontSize": "13px",
                                    "color": COLORS["text_primary"],
                                    "marginBottom": "8px",
                                },
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=[
                            dcc.Graph(
                                id="gas-stor-dem-winter-chart",
                                config={"displayModeBar": True, "responsive": True},
                                style={"width": "100%", "minHeight": "380px"},
                            ),
                            dcc.Graph(
                                id="gas-stor-dem-regime-chart",
                                config={"displayModeBar": True, "responsive": True},
                                style={"width": "100%", "minHeight": "360px"},
                            ),
                            dcc.Graph(
                                id="gas-stor-dem-wx-impact-chart",
                                config={"displayModeBar": True, "responsive": True},
                                style={"width": "100%", "minHeight": "520px"},
                            ),
                            dcc.Graph(
                                id="gas-stor-dem-yoy-pair-chart",
                                config={"displayModeBar": True, "responsive": True},
                                style={"width": "100%", "minHeight": "420px"},
                            ),
                            html.Div(
                                style={"padding": "8px 20px 20px 20px"},
                                children=[
                                    html.Div(
                                        "Winter detail",
                                        style={
                                            **_PANEL_TITLE,
                                            "marginBottom": "8px",
                                            "fontSize": "12px",
                                        },
                                    ),
                                    dash_table.DataTable(
                                        id="gas-stor-dem-winter-table",
                                        columns=[
                                            {"name": c, "id": c}
                                            for c in (
                                                "Winter",
                                                "Severity",
                                                "Era",
                                                "HDD mean",
                                                "Obs mcm/d",
                                                "Wx-norm mcm/d",
                                                "Obs − wx",
                                            )
                                        ],
                                        data=[],
                                        style_table={
                                            "overflowX": "auto",
                                            "maxHeight": "360px",
                                            "overflowY": "auto",
                                        },
                                        style_header={
                                            "backgroundColor": COLORS.get(
                                                "border_light", "#f0f0f0"
                                            ),
                                            "fontWeight": "600",
                                            "fontSize": "12px",
                                        },
                                        style_cell={
                                            "fontSize": "12px",
                                            "padding": "6px 10px",
                                            "textAlign": "center",
                                        },
                                        style_data_conditional=[
                                            {
                                                "if": {
                                                    "filter_query": '{Severity} = "cold"'
                                                },
                                                "backgroundColor": "rgba(31,78,121,0.08)",
                                            },
                                            {
                                                "if": {
                                                    "filter_query": '{Severity} = "mild"'
                                                },
                                                "backgroundColor": "rgba(196,122,44,0.10)",
                                            },
                                        ],
                                        page_size=20,
                                    ),
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )
