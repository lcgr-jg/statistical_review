"""EU Gas Balance — Storage vs Demand callbacks."""
from __future__ import annotations

import logging
from datetime import datetime

import pandas as pd
from dash import Input, Output, State, callback, html

from core.gas_storage_vs_demand.charts import build_yoy_storage_demand_chart
from core.gas_storage_vs_demand.constants import (
    COUNTRY_CODES,
    DEFAULT_DEMAND_ITEM,
    DEFAULT_DEMAND_MODE,
    DEFAULT_MULTI_COUNTRIES,
    DEFAULT_SECTOR_MULTI_COUNTRIES,
    DEMAND_ITEM_INDUSTRIAL,
    DEMAND_ITEM_LDZ,
    DEMAND_ITEM_POWER,
    DEMAND_ITEM_TOTAL,
    DEMAND_MODE_OBSERVED,
    DEMAND_MODE_WEATHER_NORM,
    HISTORY_YEAR_MIN,
    MULTI_COUNTRY_OPTIONS,
    RANGE_POST_UKRAINE,
    SECTOR_COUNTRY_CODES,
    SECTOR_MULTI_COUNTRY_OPTIONS,
    YEAR_BASIS_CALENDAR,
    YEAR_BASIS_GAS,
    countries_for_demand_item,
    default_years,
    year_label,
    year_options,
    yoy_current_year,
)
from core.gas_storage_vs_demand.data import (
    format_ce_refresh_age,
    get_cached_fill,
    get_ce_last_refresh,
    get_demand_frame,
)
from core.gas_storage_vs_demand.weather_norm import build_weather_normalised_demand
from core.styles import get_status_badge_style

logger = logging.getLogger(__name__)

_DEMAND_ITEM_LABELS = {
    DEMAND_ITEM_TOTAL: "total demand",
    DEMAND_ITEM_LDZ: "LDZ demand",
    DEMAND_ITEM_INDUSTRIAL: "industrial demand",
    DEMAND_ITEM_POWER: "power (CCGT) demand",
}


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "12px 16px",
            "borderRadius": "8px",
            "fontSize": "13px",
            "width": "100%",
        },
    )


def _parse_year_basis(value) -> str:
    return YEAR_BASIS_GAS if value == YEAR_BASIS_GAS else YEAR_BASIS_CALENDAR


def _parse_demand_mode(value) -> str:
    return (
        DEMAND_MODE_WEATHER_NORM
        if value == DEMAND_MODE_WEATHER_NORM
        else DEMAND_MODE_OBSERVED
    )


def _parse_demand_item(value) -> str:
    allowed = {
        DEMAND_ITEM_TOTAL,
        DEMAND_ITEM_LDZ,
        DEMAND_ITEM_INDUSTRIAL,
        DEMAND_ITEM_POWER,
    }
    return value if value in allowed else DEFAULT_DEMAND_ITEM


def _parse_years(value, basis: str = YEAR_BASIS_CALENDAR) -> list[int]:
    if value is None:
        return default_years(basis=basis)
    if isinstance(value, (int, float, str)):
        value = [value]
    out: list[int] = []
    current = yoy_current_year(basis)
    for item in value:
        try:
            year = int(item)
        except (TypeError, ValueError):
            continue
        if HISTORY_YEAR_MIN <= year < current:
            out.append(year)
    return sorted(set(out))


def _parse_range_years(value) -> int | str:
    if value == RANGE_POST_UKRAINE:
        return RANGE_POST_UKRAINE
    try:
        n = int(value)
    except (TypeError, ValueError):
        return 0
    return n if n in (0, 3, 5, 7) else 0


def _range_subtitle(range_mode: int | str) -> str:
    if range_mode == RANGE_POST_UKRAINE:
        return "post-Ukraine highlight"
    if isinstance(range_mode, int) and range_mode > 0:
        return f"{range_mode}Y range band"
    return "no range band"


def _parse_multi_countries(value) -> list[str]:
    if isinstance(value, str):
        value = [value]
    codes = [c for c in (value or []) if c in COUNTRY_CODES]
    return codes or list(DEFAULT_MULTI_COUNTRIES)


@callback(
    Output("gas-stor-dem-countries", "options"),
    Output("gas-stor-dem-countries", "value"),
    Input("gas-stor-dem-item", "value"),
    State("gas-stor-dem-countries", "value"),
    prevent_initial_call=False,
)
def sync_countries_for_demand_item(demand_item_value, countries_value):
    """Drop AT from the country picker when a sector demand item is selected."""
    item = _parse_demand_item(demand_item_value or DEFAULT_DEMAND_ITEM)
    if item == DEMAND_ITEM_TOTAL:
        options = MULTI_COUNTRY_OPTIONS
        value = _parse_multi_countries(countries_value)
        # Restore full default set when returning from a sector view that had
        # all non-AT countries selected.
        if set(value) == set(DEFAULT_SECTOR_MULTI_COUNTRIES):
            value = list(DEFAULT_MULTI_COUNTRIES)
    else:
        options = SECTOR_MULTI_COUNTRY_OPTIONS
        value = countries_for_demand_item(item, countries_value)
    return options, value


@callback(
    Output("gas-stor-dem-years", "options"),
    Output("gas-stor-dem-years", "value"),
    Input("gas-stor-dem-basis", "value"),
    prevent_initial_call=False,
)
def sync_demand_year_options(basis_value):
    basis = _parse_year_basis(basis_value)
    return year_options(basis=basis), default_years(basis=basis)


@callback(
    Output("gas-stor-dem-yoy-chart", "figure"),
    Output("gas-stor-dem-yoy-subtitle", "children"),
    Output("gas-stor-dem-status", "children"),
    Input("gas-stor-dem-refresh", "n_clicks"),
    Input("gas-stor-dem-years", "value"),
    Input("gas-stor-dem-range", "value"),
    Input("gas-stor-dem-countries", "value"),
    Input("gas-stor-dem-basis", "value"),
    Input("gas-stor-dem-mode", "value"),
    Input("gas-stor-dem-item", "value"),
    prevent_initial_call=False,
)
def update_yoy_storage_demand_chart(
    _n_clicks,
    selected_years,
    range_years_value,
    countries_value,
    basis_value,
    demand_mode_value,
    demand_item_value,
):
    basis = _parse_year_basis(basis_value)
    demand_mode = _parse_demand_mode(demand_mode_value or DEFAULT_DEMAND_MODE)
    demand_item = _parse_demand_item(demand_item_value or DEFAULT_DEMAND_ITEM)
    years = _parse_years(selected_years, basis=basis)
    range_n = _parse_range_years(range_years_value)
    countries = countries_for_demand_item(demand_item, countries_value)
    to_date = datetime.now()
    item_label = _DEMAND_ITEM_LABELS.get(demand_item, demand_item)
    norm_countries = (
        list(COUNTRY_CODES)
        if demand_item == DEMAND_ITEM_TOTAL
        else list(SECTOR_COUNTRY_CODES)
    )

    try:
        df_fill = get_cached_fill()
        df_demand = get_demand_frame(demand_item)
    except Exception as exc:
        logger.exception("Storage vs Demand YoY chart: %s", exc)
        return (
            build_yoy_storage_demand_chart(
                pd.DataFrame(),
                pd.DataFrame(),
                years,
                range_n,
                countries=countries,
                year_basis=basis,
                demand_mode=demand_mode,
                demand_item=demand_item,
            ),
            "",
            _alert(str(exc)),
        )

    demand_note = f"observed {item_label}"
    if demand_mode == DEMAND_MODE_WEATHER_NORM:
        try:
            df_demand = build_weather_normalised_demand(
                df_demand,
                countries=norm_countries,
                demand_item=demand_item,
            )
            demand_note = f"weather-normalised {item_label}"
        except Exception as exc:
            logger.exception("Weather-normalised demand failed: %s", exc)
            return (
                build_yoy_storage_demand_chart(
                    df_fill,
                    pd.DataFrame(),
                    years,
                    range_n,
                    countries=countries,
                    year_basis=basis,
                    demand_mode=demand_mode,
                    demand_item=demand_item,
                ),
                "",
                _alert(f"Weather-normalised demand failed: {exc}"),
            )

    fig = build_yoy_storage_demand_chart(
        df_fill,
        df_demand,
        selected_years=years,
        range_years=range_n,
        to_date=to_date,
        countries=countries,
        year_basis=basis,
        demand_mode=demand_mode,
        demand_item=demand_item,
    )

    latest = None
    if not df_fill.empty:
        latest = df_fill.index.max()
    if not df_demand.empty:
        dem_max = df_demand.index.max()
        latest = dem_max if latest is None else min(latest, dem_max)

    year_txt = (
        ", ".join(year_label(y, basis) for y in years) if years else "none"
    )
    range_txt = _range_subtitle(range_n)
    current = year_label(yoy_current_year(basis, to_date.date()), basis)
    basis_txt = "gas year" if basis == YEAR_BASIS_GAS else "calendar"
    subtitle = (
        f"{current} + priors [{year_txt}] · {range_txt} · {basis_txt} · "
        f"stock ÷ annual ({demand_note})"
    )

    refresh = get_ce_last_refresh()
    if latest is not None:
        status = (
            f"Loaded CE gas data through {pd.Timestamp(latest).strftime('%d-%b-%Y')} · "
            f"{item_label} · {format_ce_refresh_age(refresh)}"
        )
    else:
        status = f"Loaded CE gas data · {item_label} · {format_ce_refresh_age(refresh)}"

    return fig, subtitle, _alert(status, "success")


@callback(
    Output("gas-stor-dem-winter-chart", "figure"),
    Output("gas-stor-dem-regime-chart", "figure"),
    Output("gas-stor-dem-wx-impact-chart", "figure"),
    Output("gas-stor-dem-yoy-pair-chart", "figure"),
    Output("gas-stor-dem-winter-table", "data"),
    Output("gas-stor-dem-pattern-subtitle", "children"),
    Output("gas-stor-dem-pattern-insight", "children"),
    Input("gas-stor-dem-refresh", "n_clicks"),
    Input("gas-stor-dem-countries", "value"),
    Input("gas-stor-dem-item", "value"),
    Input("gas-stor-dem-basis", "value"),
    Input("gas-stor-dem-years", "value"),
    prevent_initial_call=False,
)
def update_demand_pattern_analysis(
    _n_clicks,
    countries_value,
    demand_item_value,
    basis_value,
    selected_years,
):
    from core.gas_storage_vs_demand.pattern_charts import (
        build_regime_comparison_chart,
        build_winter_severity_chart,
        build_wx_impact_chart,
        build_yoy_obs_wx_demand_charts,
        empty_pattern_fig,
        regime_insight_text,
        winter_summary_table,
    )
    from core.gas_storage_vs_demand.pattern_data import (
        aggregate_demand_series,
        aggregate_hdd_series,
        build_regime_summary,
        build_winter_summary,
        build_wx_impact_monthly,
    )

    demand_item = _parse_demand_item(demand_item_value or DEFAULT_DEMAND_ITEM)
    countries = countries_for_demand_item(demand_item, countries_value)
    basis = _parse_year_basis(basis_value)
    years = _parse_years(selected_years, basis=basis)
    item_label = _DEMAND_ITEM_LABELS.get(demand_item, demand_item)
    sector_codes = (
        list(COUNTRY_CODES)
        if demand_item == DEMAND_ITEM_TOTAL
        else list(SECTOR_COUNTRY_CODES)
    )
    country_txt = (
        "Total"
        if set(countries) == set(sector_codes)
        else ", ".join(countries)
    )
    suffix = f"  ·  {item_label}  ·  {country_txt}"
    basis_txt = "gas year" if basis == YEAR_BASIS_GAS else "calendar"

    empty = empty_pattern_fig("No data")
    try:
        df_obs = get_demand_frame(demand_item)
        df_wx = build_weather_normalised_demand(
            df_obs,
            countries=sector_codes,
            demand_item=demand_item,
        )
    except Exception as exc:
        logger.exception("Demand pattern analysis failed: %s", exc)
        msg = str(exc)
        return empty, empty, empty, empty, [], "", _alert(msg)

    obs = aggregate_demand_series(df_obs, countries)
    wx = aggregate_demand_series(df_wx, countries)
    hdd = aggregate_hdd_series(countries)

    winter = build_winter_summary(obs, wx, hdd)
    regime = build_regime_summary(winter)
    monthly = build_wx_impact_monthly(obs, wx)

    winter_fig = build_winter_severity_chart(winter, title_suffix=suffix)
    regime_fig = build_regime_comparison_chart(regime, title_suffix=suffix)
    wx_fig = build_wx_impact_chart(monthly, title_suffix=suffix)
    yoy_pair = build_yoy_obs_wx_demand_charts(
        obs,
        wx,
        selected_years=years,
        year_basis=basis,
        title_suffix=suffix,
    )
    table = winter_summary_table(winter)
    insight = regime_insight_text(regime)
    subtitle = (
        f"{len(winter)} winters · {item_label} · {country_txt} · "
        f"{basis_txt} YoY · obs vs wx-norm"
    )
    return winter_fig, regime_fig, wx_fig, yoy_pair, table, subtitle, insight
