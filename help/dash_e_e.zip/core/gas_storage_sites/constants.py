"""EU Gas Balance — Storage Sites inspector constants."""
from __future__ import annotations

from core.gas_storage_summary.constants import COUNTRY_CODES, MULTI_COUNTRY_OPTIONS

PAGE_PATH = "/power/gas_balance/storage_sites"
PAGE_NAME = "Storage Sites"
PAGE_TITLE = "EU Gas Storage Sites | JG Power Dashboard"
PAGE_ORDER = 75

DEFAULT_COUNTRY = "DE"

CLASS_COLORS = {
    "SRS": "#2ea043",
    "MRS": "#d29922",
    "LRS": "#2171b5",
}

__all__ = [
    "CLASS_COLORS",
    "COUNTRY_CODES",
    "DEFAULT_COUNTRY",
    "MULTI_COUNTRY_OPTIONS",
    "PAGE_NAME",
    "PAGE_ORDER",
    "PAGE_PATH",
    "PAGE_TITLE",
]
