"""Storage Sites inspector charts."""
from __future__ import annotations

from datetime import datetime

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from core.gas_storage_summary.constants import yoy_current_year
from core.styles import COLORS
from jain_commods.fundamental.gas.storage import injection_model
from jain_commods.fundamental.gas.storage_params import withdrawal_rate

RECENT_YEARS = 5
YEAR_COLORS = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
_H_LEGEND = dict(
    orientation="h",
    x=0.5,
    xanchor="center",
    yanchor="top",
)


def site_chart_title(base: str, meta: dict | None = None) -> str:
    meta = meta or {}
    site = str(meta.get("site_name") or "").strip()
    country = str(meta.get("country") or "").strip()
    if site and country:
        return f"{base} — {site} ({country})"
    if site:
        return f"{base} — {site}"
    if country:
        return f"{base} — {country}"
    return base


def _empty_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
        font={"size": 14, "color": "#888"},
    )
    fig.update_layout(
        height=360,
        autosize=True,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        margin=dict(t=40, b=40, l=50, r=20),
    )
    return fig


def _prep(ts: pd.DataFrame) -> pd.DataFrame:
    if ts is None or ts.empty:
        return pd.DataFrame()
    df = ts.copy()
    df.columns = [str(c).lower() for c in df.columns]
    df.index = pd.to_datetime(df.index)
    if "stockcapacity" in df.columns and "stock" in df.columns:
        capa = pd.to_numeric(df["stockcapacity"], errors="coerce")
        stock = pd.to_numeric(df["stock"], errors="coerce")
        df["fill_pct"] = np.where(capa > 0, 100.0 * stock / capa, np.nan)
    return df


def build_yoy_series_chart(
    ts: pd.DataFrame,
    column: str,
    title: str,
    yaxis_title: str,
    *,
    scale: float = 1.0,
) -> go.Figure:
    df = _prep(ts)
    if df.empty or column not in df.columns:
        return _empty_fig(f"No {column} series")
    series = pd.to_numeric(df[column], errors="coerce") * scale
    current_year = yoy_current_year("calendar")
    years = sorted(series.dropna().index.year.unique())
    recent = [y for y in years if y >= current_year - RECENT_YEARS + 1]
    fig = go.Figure()
    for i, year in enumerate(years):
        ydf = series[series.index.year == year]
        if ydf.empty:
            continue
        doy = ydf.index.dayofyear
        is_recent = year in recent
        color = (
            YEAR_COLORS[(year - recent[0]) % len(YEAR_COLORS)]
            if is_recent and recent
            else "#c5c5c5"
        )
        fig.add_trace(
            go.Scatter(
                x=doy,
                y=ydf.values,
                mode="lines",
                name=str(year),
                line=dict(
                    color=color,
                    width=2.4 if year == current_year else (1.6 if is_recent else 1.0),
                ),
                opacity=1.0 if is_recent else 0.45,
                hovertemplate=f"{year} d%{{x}}<br>%{{y:.2f}}<extra></extra>",
            )
        )
    fig.update_layout(
        title=title,
        xaxis_title=None,
        yaxis_title=yaxis_title,
        height=360,
        autosize=True,
        legend={**_H_LEGEND, "y": -0.12},
        margin=dict(t=50, b=50, l=50, r=20),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
    )
    fig.update_xaxes(showticklabels=False, ticks="", title=None)
    return fig


def build_scatter_chart(
    ts: pd.DataFrame,
    rate_col: str,
    title: str,
    yaxis_title: str,
    *,
    curve_x: np.ndarray | None = None,
    curve_y: np.ndarray | None = None,
    curve_name: str = "Fitted",
    cap: float | None = None,
    excluded_dates: list[str] | None = None,
) -> go.Figure:
    df = _prep(ts)
    if df.empty or "fill_pct" not in df.columns or rate_col not in df.columns:
        return _empty_fig(f"No {rate_col} vs fill data")
    df["year"] = df.index.year
    current_year = datetime.now().year
    recent = list(range(current_year - RECENT_YEARS + 1, current_year + 1))
    color_map = {year: YEAR_COLORS[i % len(YEAR_COLORS)] for i, year in enumerate(recent)}
    excl = set()
    if excluded_dates:
        excl = {pd.Timestamp(d).normalize() for d in excluded_dates}

    fig = go.Figure()
    older = df[~df["year"].isin(recent)]
    if not older.empty:
        fig.add_trace(
            go.Scatter(
                x=older["fill_pct"],
                y=pd.to_numeric(older[rate_col], errors="coerce"),
                mode="markers",
                name="Older",
                marker=dict(size=5, opacity=0.35, color="#c5c5c5"),
                customdata=older.index.strftime("%Y-%m-%d"),
                hovertemplate="Date: %{customdata}<br>Fill: %{x:.1f}%<br>Rate: %{y:.2f}<extra></extra>",
            )
        )
    for year in recent:
        ydf = df[df["year"] == year]
        if ydf.empty:
            continue
        fig.add_trace(
            go.Scatter(
                x=ydf["fill_pct"],
                y=pd.to_numeric(ydf[rate_col], errors="coerce"),
                mode="markers",
                name=str(year),
                marker=dict(size=6, opacity=0.65, color=color_map[year]),
                customdata=ydf.index.strftime("%Y-%m-%d"),
                hovertemplate="Date: %{customdata}<br>Fill: %{x:.1f}%<br>Rate: %{y:.2f}<extra></extra>",
            )
        )
    if excl:
        mask = pd.DatetimeIndex(df.index).normalize().isin(list(excl))
        hit = df.loc[mask]
        if not hit.empty:
            fig.add_trace(
                go.Scatter(
                    x=hit["fill_pct"],
                    y=pd.to_numeric(hit[rate_col], errors="coerce"),
                    mode="markers",
                    name="Excluded",
                    marker=dict(size=9, symbol="x", color="#f44336"),
                    customdata=hit.index.strftime("%Y-%m-%d"),
                    hovertemplate="Excluded %{customdata}<extra></extra>",
                )
            )
    if curve_x is not None and curve_y is not None:
        fig.add_trace(
            go.Scatter(
                x=curve_x,
                y=curve_y,
                mode="lines",
                name=curve_name,
                line=dict(color="#d62728", width=2.4),
            )
        )
    if cap is not None and np.isfinite(cap):
        fig.add_hline(
            y=float(cap),
            line=dict(color="#333", dash="dash", width=1),
            annotation_text=f"cap {cap:.1f}",
            annotation_position="top left",
        )
    fig.update_layout(
        title=title,
        xaxis_title=None,
        yaxis_title=yaxis_title,
        height=420,
        autosize=True,
        legend={**_H_LEGEND, "y": -0.16},
        margin=dict(t=50, b=110, l=50, r=20),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        clickmode="event+select",
    )
    fig.add_annotation(
        text="Fill level %",
        xref="paper",
        yref="paper",
        x=0.5,
        y=-0.30,
        showarrow=False,
        xanchor="center",
        yanchor="top",
        font={"size": 12, "color": COLORS["text_secondary"]},
    )
    return fig


def fitted_curve_xy(
    kind: str,
    p_or_q: float,
    rate_max: float,
    cap: float | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    x_pct = np.linspace(0, 100, 200)
    fill = x_pct / 100.0
    if kind == "injection":
        y = injection_model(fill, 1.0, p_or_q, rate_max, unit="%")
    else:
        y = withdrawal_rate(fill, 1.0, p_or_q, rate_max, unit="%")
    if cap is not None and np.isfinite(cap):
        y = np.minimum(y, cap)
    return x_pct, np.asarray(y, dtype=float)
