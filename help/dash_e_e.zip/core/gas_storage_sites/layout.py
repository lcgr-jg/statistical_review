"""Layout for the EU Gas Balance — Storage Sites inspector."""
from __future__ import annotations

from dash import dcc, html

from core.gas_storage_sites.constants import (
    COUNTRY_CODES,
    DEFAULT_COUNTRY,
    PAGE_NAME,
)
from core.styles import COLORS

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}
_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "display": "flex",
    "alignItems": "flex-end",
    "flexWrap": "wrap",
    "gap": "16px",
}
_BTN = {
    "padding": "10px 18px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
}
_BTN_SECONDARY = {
    **_BTN,
    "backgroundColor": COLORS["text_muted"],
}
_CONTENT = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "marginBottom": "20px",
    "padding": "16px 20px",
}
_SLIDER_WRAP = {"width": "220px", "minWidth": "180px"}
_GRAPH_CFG = {
    "displayModeBar": True,
    "displaylogo": False,
    "responsive": True,
}


def _graph(graph_id: str) -> dcc.Graph:
    return dcc.Graph(
        id=graph_id,
        config=_GRAPH_CFG,
        responsive=True,
        style={"width": "100%"},
    )


def build_layout() -> html.Div:
    return html.Div(
        style={"minHeight": "100vh", "backgroundColor": COLORS["background"], "padding": "20px"},
        children=[
            dcc.Store(id="gas-sites-ts"),
            dcc.Store(id="gas-sites-meta"),
            dcc.Store(id="gas-sites-excluded", data=[]),
            html.Div(
                [
                    html.H1(
                        PAGE_NAME,
                        style={
                            "fontSize": "22px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "margin": "0 0 4px 0",
                        },
                    ),
                    html.P(
                        "Inspect per-site fill, injection and withdrawal, fit the "
                        "injectability / withdrawability curve, and save overrides.",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 20px 0",
                        },
                    ),
                ]
            ),
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Div(
                        [
                            html.Label("Country", style=_LABEL),
                            dcc.Dropdown(
                                id="gas-sites-country",
                                options=[{"label": c, "value": c} for c in COUNTRY_CODES],
                                value=DEFAULT_COUNTRY,
                                clearable=False,
                                style={"width": "120px", "fontSize": "13px"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Label("Storage site", style=_LABEL),
                            dcc.Dropdown(
                                id="gas-sites-site",
                                placeholder="Select a site…",
                                style={"width": "320px", "fontSize": "13px"},
                            ),
                        ]
                    ),
                    html.Button("Load", id="gas-sites-load", n_clicks=0, style=_BTN),
                    html.Div(id="gas-sites-status"),
                ],
            ),
            html.Div(id="gas-sites-kpi", style=_CONTENT),
            html.Div(
                style=_CONTENT,
                children=[
                    html.Div(
                        "Curve editor",
                        style={
                            "fontSize": "14px",
                            "fontWeight": "600",
                            "marginBottom": "12px",
                            "color": COLORS["text_primary"],
                        },
                    ),
                    html.Div(
                        style={"display": "flex", "flexWrap": "wrap", "gap": "20px", "alignItems": "flex-end"},
                        children=[
                            html.Div(
                                [
                                    html.Label("p (injection exponent)", style=_LABEL),
                                    dcc.Slider(
                                        id="gas-sites-p",
                                        min=0.05,
                                        max=5,
                                        step=0.05,
                                        value=1.0,
                                        marks={0.05: "0.05", 1: "1", 2: "2", 5: "5"},
                                    ),
                                ],
                                style=_SLIDER_WRAP,
                            ),
                            html.Div(
                                [
                                    html.Label("q (withdrawal exponent)", style=_LABEL),
                                    dcc.Slider(
                                        id="gas-sites-q",
                                        min=0.05,
                                        max=5,
                                        step=0.05,
                                        value=1.0,
                                        marks={0.05: "0.05", 1: "1", 2: "2", 5: "5"},
                                    ),
                                ],
                                style=_SLIDER_WRAP,
                            ),
                            html.Div(
                                [
                                    html.Label("max inj (mcm/d)", style=_LABEL),
                                    dcc.Input(
                                        id="gas-sites-max-inj",
                                        type="number",
                                        debounce=True,
                                        style={"width": "110px", "fontSize": "13px"},
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    html.Label("max wdr (mcm/d)", style=_LABEL),
                                    dcc.Input(
                                        id="gas-sites-max-wdr",
                                        type="number",
                                        debounce=True,
                                        style={"width": "110px", "fontSize": "13px"},
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    html.Label("Class", style=_LABEL),
                                    dcc.Dropdown(
                                        id="gas-sites-class",
                                        options=[
                                            {"label": "SRS", "value": "SRS"},
                                            {"label": "MRS", "value": "MRS"},
                                            {"label": "LRS", "value": "LRS"},
                                        ],
                                        clearable=False,
                                        style={"width": "100px", "fontSize": "13px"},
                                    ),
                                ]
                            ),
                            dcc.Checklist(
                                id="gas-sites-lock-class",
                                options=[{"label": " Lock class", "value": "lock"}],
                                value=[],
                                style={"fontSize": "13px", "color": COLORS["text_secondary"]},
                            ),
                            html.Button("Re-fit (drop excluded)", id="gas-sites-refit", n_clicks=0, style=_BTN_SECONDARY),
                            html.Button("Save", id="gas-sites-save", n_clicks=0, style=_BTN),
                        ],
                    ),
                    html.Div(
                        "Power-law: injection = max_inj × (1 − fill)^p, "
                        "withdrawal = max_wdr × fill^q. Click scatter points to "
                        "exclude outliers, then Re-fit.",
                        style={"fontSize": "12px", "color": COLORS["text_muted"], "marginTop": "10px"},
                    ),
                    html.Div(id="gas-sites-save-msg", style={"marginTop": "8px"}),
                ],
            ),
            html.Div(
                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "16px"},
                children=[
                    html.Div(style=_CONTENT, children=[_graph("gas-sites-yoy-stock")]),
                    html.Div(style=_CONTENT, children=[_graph("gas-sites-yoy-fill")]),
                    html.Div(style=_CONTENT, children=[_graph("gas-sites-yoy-inj")]),
                    html.Div(style=_CONTENT, children=[_graph("gas-sites-yoy-wdr")]),
                ],
            ),
            html.Div(
                style={**_CONTENT, "marginBottom": "12px"},
                children=[
                    html.Div(
                        "Scatter caps (dashed lines)",
                        style={
                            "fontSize": "14px",
                            "fontWeight": "600",
                            "marginBottom": "6px",
                            "color": COLORS["text_primary"],
                        },
                    ),
                    html.P(
                        "max_inj_cap and max_wdr_cap are the 99th percentile of that "
                        "site’s observed positive injection and withdrawal rates in "
                        "the CE history (mcm/d). They are a technical ceiling, not the "
                        "fitted curve. The solid red line is the power-law "
                        "(inj = max_inj × (1 − fill)^p, wdr = max_wdr × fill^q); "
                        "the dashed grey line is the cap, and the modelled rate is "
                        "clipped at it.",
                        style={
                            "fontSize": "12px",
                            "color": COLORS["text_muted"],
                            "margin": "0",
                            "lineHeight": "1.45",
                        },
                    ),
                ],
            ),
            html.Div(
                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "16px"},
                children=[
                    html.Div(style=_CONTENT, children=[_graph("gas-sites-scatter-inj")]),
                    html.Div(style=_CONTENT, children=[_graph("gas-sites-scatter-wdr")]),
                ],
            ),
            html.Div(
                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "16px"},
                children=[
                    html.Div(style=_CONTENT, children=[html.Div("Days to fill targets"), html.Div(id="gas-sites-fill-table")]),
                    html.Div(style=_CONTENT, children=[html.Div("Days to empty targets"), html.Div(id="gas-sites-empty-table")]),
                ],
            ),
        ],
    )
