"""Storage Sites inspector callbacks."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from dash import Input, Output, State, callback, html, no_update
from dash.dash_table import DataTable

from core.gas_storage_sites.charts import (
    build_scatter_chart,
    build_yoy_series_chart,
    fitted_curve_xy,
    site_chart_title,
)
from core.gas_storage_sites.constants import CLASS_COLORS
from core.gas_storage_sites.data import (
    catalog_or_error,
    characteristic_days,
    fit_from_records,
    frame_from_records,
    latest_inventory,
    live_days_tables,
    load_site_bundle,
    save_manual_params,
    sites_for_country,
    timeseries_records,
)
from core.styles import COLORS, get_status_badge_style
from jain_commods.fundamental.gas.storage_params import classify_site

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "10px 14px",
            "borderRadius": "8px",
            "fontSize": "13px",
        },
    )


def _empty_outputs(status, save_msg=None):
    from core.gas_storage_sites.charts import _empty_fig

    empty = _empty_fig("Select a site and click Load")
    return (
        no_update,
        no_update,
        [],
        status,
        html.Div(),
        no_update,
        no_update,
        no_update,
        no_update,
        no_update,
        empty,
        empty,
        empty,
        empty,
        empty,
        empty,
        html.Div(),
        html.Div(),
        save_msg or html.Div(),
    )


def _table(df: pd.DataFrame):
    if df is None or df.empty:
        return html.Div("No table", style={"color": COLORS["text_muted"], "fontSize": "13px"})
    view = df.copy()
    if "Date Reached" in view.columns:
        view["Date Reached"] = view["Date Reached"].astype(str)
    return DataTable(
        data=view.to_dict("records"),
        columns=[{"name": c, "id": c} for c in view.columns],
        style_table={"overflowX": "auto"},
        style_cell={"fontSize": "13px", "padding": "6px 8px", "fontFamily": "Calibri, Arial, sans-serif"},
        style_header={"fontWeight": "600", "backgroundColor": COLORS["table_header_bg"]},
    )


def _kpi(meta: dict, inventory: dict, days_0_100: float | None) -> html.Div:
    cls = meta.get("classification") or "—"
    color = CLASS_COLORS.get(cls, COLORS["text_muted"])
    fill = inventory.get("fill_frac")
    stock = inventory.get("stock_mcm")
    capa = inventory.get("capacity_mcm")
    as_of = inventory.get("as_of")
    as_of_s = pd.Timestamp(as_of).strftime("%d-%b-%Y") if as_of is not None else "—"
    fill_s = f"{fill * 100:.1f}%" if fill is not None else "—"
    stock_s = f"{(stock or 0) / 1000:.2f} bcm" if stock is not None else "—"
    capa_s = f"{(capa or 0) / 1000:.2f} bcm" if capa is not None else "—"
    days_s = f"{days_0_100:.0f} d empty→full" if days_0_100 is not None and np.isfinite(days_0_100) else "—"
    source = meta.get("source") or "—"
    return html.Div(
        [
            html.Span(
                cls,
                style={
                    **get_status_badge_style("info"),
                    "backgroundColor": f"{color}22",
                    "color": color,
                    "border": f"1px solid {color}55",
                    "marginRight": "10px",
                },
            ),
            html.Span(
                f"{meta.get('site_name', '')} · {as_of_s} · fill {fill_s} · "
                f"{stock_s} / {capa_s} · {days_s} · source {source}",
                style={"fontSize": "13px", "color": COLORS["text_secondary"]},
            ),
        ]
    )


@callback(
    Output("gas-sites-site", "options"),
    Output("gas-sites-site", "value"),
    Output("gas-sites-status", "children", allow_duplicate=True),
    Input("gas-sites-country", "value"),
    prevent_initial_call="initial_duplicate",
)
def update_site_dropdown(country):
    if not country:
        return [], None, _alert("Pick a country")
    try:
        sites = sites_for_country(country)
    except Exception as exc:
        logger.exception("Site list failed")
        return [], None, _alert(str(exc), "error")
    if sites.empty:
        return [], None, _alert(f"No storage sites for {country} (run the SQL + Dagster fit job)")
    options = [
        {
            "label": f"{row.site_name}",
            "value": int(row.data_id),
        }
        for row in sites.itertuples()
        if pd.notna(row.data_id)
    ]
    value = options[0]["value"] if options else None
    return options, value, html.Div()


@callback(
    Output("gas-sites-ts", "data"),
    Output("gas-sites-meta", "data"),
    Output("gas-sites-excluded", "data"),
    Output("gas-sites-status", "children"),
    Output("gas-sites-kpi", "children"),
    Output("gas-sites-p", "value"),
    Output("gas-sites-q", "value"),
    Output("gas-sites-max-inj", "value"),
    Output("gas-sites-max-wdr", "value"),
    Output("gas-sites-class", "value"),
    Output("gas-sites-yoy-stock", "figure"),
    Output("gas-sites-yoy-fill", "figure"),
    Output("gas-sites-yoy-inj", "figure"),
    Output("gas-sites-yoy-wdr", "figure"),
    Output("gas-sites-scatter-inj", "figure"),
    Output("gas-sites-scatter-wdr", "figure"),
    Output("gas-sites-fill-table", "children"),
    Output("gas-sites-empty-table", "children"),
    Output("gas-sites-save-msg", "children"),
    Input("gas-sites-load", "n_clicks"),
    State("gas-sites-site", "value"),
    State("gas-sites-site", "options"),
    prevent_initial_call=False,
)
def load_site(n_clicks, data_id, site_options):
    if not data_id:
        return _empty_outputs(_alert("Select a country and site"))
    try:
        bundle = load_site_bundle(int(data_id))
    except Exception as exc:
        logger.exception("Load site failed")
        return _empty_outputs(_alert(str(exc), "error"))

    catalog, _ = catalog_or_error()
    cat_row = None
    if catalog is not None and not catalog.empty:
        hit = catalog[pd.to_numeric(catalog["data_id"], errors="coerce") == int(data_id)]
        if not hit.empty:
            cat_row = hit.iloc[0]

    ts = bundle["timeseries"]
    params = bundle["params"]
    if ts is None or ts.empty:
        return _empty_outputs(_alert("No timeseries for this site", "error"))

    site_name = ""
    country = ""
    asset_id = None
    if cat_row is not None:
        site_name = str(cat_row.get("site_name") or "")
        country = str(cat_row.get("country") or "")
        if pd.notna(cat_row.get("asset_id")):
            asset_id = int(cat_row["asset_id"])
    if site_options:
        for opt in site_options:
            if opt.get("value") == data_id:
                site_name = site_name or (opt.get("label") or "")
                break
    if params:
        site_name = params.get("site_name") or site_name
        country = params.get("country") or country
        asset_id = params.get("asset_id")
        p = float(params["p_inj"])
        q = float(params["q_wdr"])
        max_inj = float(params["max_inj"])
        max_wdr = float(params["max_wdr"])
        cls = params.get("classification") or "MRS"
        max_inj_cap = params.get("max_inj_cap")
        max_wdr_cap = params.get("max_wdr_cap")
    else:
        p = q = 1.0
        max_inj = max_wdr = None
        cls = "MRS"
        max_inj_cap = max_wdr_cap = None

    inv = latest_inventory(ts)
    meta = {
        "data_id": int(data_id),
        "asset_id": int(asset_id) if asset_id is not None else None,
        "country": country,
        "site_name": site_name,
        "p_inj": p,
        "q_wdr": q,
        "max_inj": max_inj,
        "max_wdr": max_wdr,
        "max_inj_cap": max_inj_cap,
        "max_wdr_cap": max_wdr_cap,
        "classification": cls,
        "source": (params or {}).get("source"),
        "storage_capacity_mcm": inv.get("capacity_mcm"),
    }
    days_0_100 = None
    if max_inj:
        days_0_100 = characteristic_days(meta, inv.get("capacity_mcm"))

    records = timeseries_records(ts)
    figs = _figures(ts, meta, [])
    tables = _tables(meta, inv) if max_inj else (html.Div("No saved curve yet — Re-fit"), html.Div())
    status = _alert("Loaded from v2 table" if params else "No v2 row yet — Re-fit to create one", "success" if params else "warning")
    return (
        records,
        meta,
        [],
        status,
        _kpi(meta, inv, days_0_100),
        p,
        q,
        max_inj,
        max_wdr,
        cls,
        *figs,
        tables[0],
        tables[1],
        html.Div(),
    )


def _figures(ts, meta, excluded):
    p = meta.get("p_inj") or 1.0
    q = meta.get("q_wdr") or 1.0
    max_inj = meta.get("max_inj")
    max_wdr = meta.get("max_wdr")
    inj_x = inj_y = wdr_x = wdr_y = None
    if max_inj:
        inj_x, inj_y = fitted_curve_xy("injection", p, max_inj, meta.get("max_inj_cap"))
    if max_wdr:
        wdr_x, wdr_y = fitted_curve_xy("withdrawal", q, max_wdr, meta.get("max_wdr_cap"))
    def title(base: str) -> str:
        return site_chart_title(base, meta)

    return (
        build_yoy_series_chart(ts, "stock", title("Working gas (mcm)"), "mcm"),
        build_yoy_series_chart(ts, "fill_pct", title("Fill %"), "%"),
        build_yoy_series_chart(ts, "injection", title("Injection (mcm/d)"), "mcm/d"),
        build_yoy_series_chart(ts, "withdrawal", title("Withdrawal (mcm/d)"), "mcm/d"),
        build_scatter_chart(
            ts,
            "injection",
            title("Injection vs fill"),
            "mcm/d",
            curve_x=inj_x,
            curve_y=inj_y,
            curve_name=f"Fitted p={p:.2f}",
            cap=meta.get("max_inj_cap"),
            excluded_dates=excluded,
        ),
        build_scatter_chart(
            ts,
            "withdrawal",
            title("Withdrawal vs fill"),
            "mcm/d",
            curve_x=wdr_x,
            curve_y=wdr_y,
            curve_name=f"Fitted q={q:.2f}",
            cap=meta.get("max_wdr_cap"),
            excluded_dates=excluded,
        ),
    )


def _tables(meta, inv):
    if not meta.get("max_inj"):
        return html.Div(), html.Div()
    inj, wdr = live_days_tables(meta, inv)
    return _table(inj), _table(wdr)


@callback(
    Output("gas-sites-scatter-inj", "figure", allow_duplicate=True),
    Output("gas-sites-scatter-wdr", "figure", allow_duplicate=True),
    Output("gas-sites-fill-table", "children", allow_duplicate=True),
    Output("gas-sites-empty-table", "children", allow_duplicate=True),
    Output("gas-sites-kpi", "children", allow_duplicate=True),
    Output("gas-sites-class", "value", allow_duplicate=True),
    Input("gas-sites-p", "value"),
    Input("gas-sites-q", "value"),
    Input("gas-sites-max-inj", "value"),
    Input("gas-sites-max-wdr", "value"),
    State("gas-sites-ts", "data"),
    State("gas-sites-meta", "data"),
    State("gas-sites-excluded", "data"),
    State("gas-sites-lock-class", "value"),
    State("gas-sites-class", "value"),
    prevent_initial_call=True,
)
def preview_curve(p, q, max_inj, max_wdr, records, meta, excluded, lock_class, current_class):
    if not records or not meta:
        return no_update, no_update, no_update, no_update, no_update, no_update
    ts = frame_from_records(records)
    inv = latest_inventory(ts)
    preview = dict(meta)
    preview["p_inj"] = float(p or 1)
    preview["q_wdr"] = float(q or 1)
    preview["max_inj"] = float(max_inj or 0) or meta.get("max_inj")
    preview["max_wdr"] = float(max_wdr or 0) or meta.get("max_wdr")
    if not preview.get("max_inj") or not preview.get("max_wdr"):
        return no_update, no_update, no_update, no_update, no_update, no_update
    locked = "lock" in (lock_class or [])
    days = characteristic_days(preview, inv.get("capacity_mcm"))
    cls = current_class or preview.get("classification")
    if not locked:
        cls = classify_site(days)
        preview["classification"] = cls
    figs = _figures(ts, preview, excluded or [])
    tables = _tables(preview, inv)
    return figs[4], figs[5], tables[0], tables[1], _kpi(preview, inv, days), cls


@callback(
    Output("gas-sites-excluded", "data", allow_duplicate=True),
    Input("gas-sites-scatter-inj", "clickData"),
    Input("gas-sites-scatter-wdr", "clickData"),
    State("gas-sites-excluded", "data"),
    prevent_initial_call=True,
)
def exclude_point(inj_click, wdr_click, excluded):
    from dash import ctx

    excluded = list(excluded or [])
    trigger = ctx.triggered_id
    click = inj_click if trigger == "gas-sites-scatter-inj" else wdr_click
    if not click or not click.get("points"):
        return no_update
    date = click["points"][0].get("customdata")
    if not date:
        return no_update
    date = str(date)
    if date in excluded:
        excluded = [d for d in excluded if d != date]
    else:
        excluded = excluded + [date]
    return excluded


@callback(
    Output("gas-sites-scatter-inj", "figure", allow_duplicate=True),
    Output("gas-sites-scatter-wdr", "figure", allow_duplicate=True),
    Input("gas-sites-excluded", "data"),
    State("gas-sites-ts", "data"),
    State("gas-sites-meta", "data"),
    State("gas-sites-p", "value"),
    State("gas-sites-q", "value"),
    State("gas-sites-max-inj", "value"),
    State("gas-sites-max-wdr", "value"),
    prevent_initial_call=True,
)
def redraw_excluded(excluded, records, meta, p, q, max_inj, max_wdr):
    if not records or not meta:
        return no_update, no_update
    ts = frame_from_records(records)
    preview = dict(meta)
    preview["p_inj"] = float(p or preview.get("p_inj") or 1)
    preview["q_wdr"] = float(q or preview.get("q_wdr") or 1)
    if max_inj:
        preview["max_inj"] = float(max_inj)
    if max_wdr:
        preview["max_wdr"] = float(max_wdr)
    figs = _figures(ts, preview, excluded or [])
    return figs[4], figs[5]


@callback(
    Output("gas-sites-p", "value", allow_duplicate=True),
    Output("gas-sites-q", "value", allow_duplicate=True),
    Output("gas-sites-max-inj", "value", allow_duplicate=True),
    Output("gas-sites-max-wdr", "value", allow_duplicate=True),
    Output("gas-sites-class", "value", allow_duplicate=True),
    Output("gas-sites-meta", "data", allow_duplicate=True),
    Output("gas-sites-save-msg", "children", allow_duplicate=True),
    Input("gas-sites-refit", "n_clicks"),
    State("gas-sites-ts", "data"),
    State("gas-sites-meta", "data"),
    State("gas-sites-excluded", "data"),
    State("gas-sites-lock-class", "value"),
    State("gas-sites-class", "value"),
    prevent_initial_call=True,
)
def refit(n_clicks, records, meta, excluded, lock_class, current_class):
    if not records or not meta:
        return no_update, no_update, no_update, no_update, no_update, no_update, _alert("Load a site first")
    try:
        fitted = fit_from_records(records, excluded_dates=excluded)
    except Exception as exc:
        logger.exception("Re-fit failed")
        return no_update, no_update, no_update, no_update, no_update, no_update, _alert(str(exc), "error")
    updated = dict(meta)
    updated.update(
        {
            "p_inj": fitted["p_inj"],
            "q_wdr": fitted["q_wdr"],
            "max_inj": fitted["max_inj"],
            "max_wdr": fitted["max_wdr"],
            "max_inj_cap": fitted.get("max_inj_cap"),
            "max_wdr_cap": fitted.get("max_wdr_cap"),
            "storage_capacity_mcm": fitted.get("storage_capacity_mcm"),
        }
    )
    if "lock" not in (lock_class or []):
        updated["classification"] = fitted["classification"]
    else:
        updated["classification"] = current_class or fitted["classification"]
    return (
        fitted["p_inj"],
        fitted["q_wdr"],
        fitted["max_inj"],
        fitted["max_wdr"],
        updated["classification"],
        updated,
        _alert(f"Re-fit ok · {fitted['n_obs']} obs · {updated['classification']}", "success"),
    )


@callback(
    Output("gas-sites-save-msg", "children", allow_duplicate=True),
    Input("gas-sites-save", "n_clicks"),
    State("gas-sites-meta", "data"),
    State("gas-sites-p", "value"),
    State("gas-sites-q", "value"),
    State("gas-sites-max-inj", "value"),
    State("gas-sites-max-wdr", "value"),
    State("gas-sites-class", "value"),
    State("gas-sites-excluded", "data"),
    prevent_initial_call=True,
)
def save_params(n_clicks, meta, p, q, max_inj, max_wdr, cls, excluded):
    if not meta or not meta.get("data_id") or not meta.get("asset_id"):
        return _alert("Load a site that has a CE asset id before saving", "error")
    if not max_inj or not max_wdr:
        return _alert("Need max inj and max wdr to save", "error")
    row = {
        "data_id": int(meta["data_id"]),
        "asset_id": int(meta["asset_id"]),
        "country": meta.get("country") or "",
        "site_name": meta.get("site_name") or "",
        "p_inj": float(p),
        "q_wdr": float(q),
        "max_inj": float(max_inj),
        "max_wdr": float(max_wdr),
        "max_inj_cap": meta.get("max_inj_cap"),
        "max_wdr_cap": meta.get("max_wdr_cap"),
        "classification": cls or "MRS",
        "excluded_dates": excluded or [],
    }
    try:
        save_manual_params(row)
    except Exception as exc:
        logger.exception("Save failed")
        return _alert(str(exc), "error")
    return _alert("Saved to eu_storage_modelling_v2", "success")
