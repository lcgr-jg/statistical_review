"""Storage Sites — load CE timeseries and v2 curve params."""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd

from jain_commods.fundamental.gas.storage_params import (
    COUNTRY_CODES,
    StorageParamsTableMissing,
    days_empty_to_full,
    days_to_empty_targets,
    days_to_fill_targets,
    fit_site_curves,
    list_storage_sites,
    load_latest_params,
    load_site_timeseries,
    save_site_params,
)

logger = logging.getLogger(__name__)

LOGINTYPE = "prod"


def _current_user_id() -> str:
    try:
        from flask_login import current_user

        if getattr(current_user, "is_authenticated", False):
            return str(current_user.id)
    except Exception:
        pass
    return "anonymous"


def catalog_or_error(
    countries: list[str] | None = None,
) -> tuple[pd.DataFrame, str | None]:
    try:
        df = list_storage_sites(countries=countries or COUNTRY_CODES, logintype=LOGINTYPE)
        return df, None
    except StorageParamsTableMissing as exc:
        return pd.DataFrame(), str(exc)
    except Exception as exc:
        logger.exception("Storage site catalog failed")
        return pd.DataFrame(), str(exc)


def sites_for_country(country: str) -> pd.DataFrame:
    catalog, err = catalog_or_error([country] if country else None)
    if err:
        raise RuntimeError(err)
    if catalog.empty:
        return catalog
    return catalog[catalog["country"] == country].copy()


def load_site_bundle(data_id: int) -> dict[str, Any]:
    """Timeseries + latest params for one site."""
    ts = load_site_timeseries(int(data_id), logintype=LOGINTYPE)
    param_row = None
    try:
        params = load_latest_params(data_ids=[int(data_id)], logintype=LOGINTYPE)
        param_row = params.iloc[0].to_dict() if not params.empty else None
    except StorageParamsTableMissing:
        param_row = None
    return {"timeseries": ts, "params": param_row}


def latest_inventory(ts: pd.DataFrame) -> dict[str, Any]:
    if ts is None or ts.empty:
        return {}
    work = ts.copy()
    work.columns = [str(c).lower() for c in work.columns]
    capa_col = "stockcapacity" if "stockcapacity" in work.columns else None
    if capa_col is None or "stock" not in work.columns:
        return {}
    valid = work.dropna(subset=["stock", capa_col])
    if valid.empty:
        return {}
    last = valid.iloc[-1]
    capa = float(last[capa_col] or 0)
    stock = float(last["stock"] or 0)
    fill = (stock / capa) if capa else 0.0
    return {
        "as_of": pd.Timestamp(valid.index[-1]),
        "stock_mcm": stock,
        "capacity_mcm": capa,
        "fill_frac": fill,
    }


def timeseries_records(ts: pd.DataFrame) -> list[dict[str, Any]]:
    if ts is None or ts.empty:
        return []
    work = ts.copy()
    work.columns = [str(c).lower() for c in work.columns]
    work = work.reset_index()
    date_col = work.columns[0]
    work = work.rename(columns={date_col: "date"})
    work["date"] = pd.to_datetime(work["date"]).dt.strftime("%Y-%m-%d")
    cols = [c for c in ("date", "stock", "stockcapacity", "injection", "withdrawal") if c in work.columns]
    return work[cols].replace({np.nan: None}).to_dict("records")


def frame_from_records(records: list[dict[str, Any]] | None) -> pd.DataFrame:
    if not records:
        return pd.DataFrame()
    df = pd.DataFrame(records)
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date")
    return df.sort_index()


def fit_from_records(
    records: list[dict[str, Any]],
    excluded_dates: list[str] | None = None,
) -> dict[str, Any]:
    df = frame_from_records(records)
    return fit_site_curves(df, excluded_dates=excluded_dates)


def save_manual_params(row: dict[str, Any]) -> None:
    payload = dict(row)
    payload["source"] = "manual"
    payload["updated_by"] = _current_user_id()
    save_site_params(payload, logintype=LOGINTYPE)


def live_days_tables(params: dict[str, Any], inventory: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame]:
    stock = float(inventory.get("stock_mcm") or 0)
    capa = float(inventory.get("capacity_mcm") or params.get("storage_capacity_mcm") or 0)
    as_of = inventory.get("as_of") or datetime.now()
    inj = days_to_fill_targets(
        stock,
        capa,
        float(params["p_inj"]),
        float(params["max_inj"]),
        params.get("max_inj_cap"),
        start_date=pd.Timestamp(as_of).to_pydatetime(),
    )
    wdr = days_to_empty_targets(
        stock,
        capa,
        float(params["q_wdr"]),
        float(params["max_wdr"]),
        params.get("max_wdr_cap"),
        start_date=pd.Timestamp(as_of).to_pydatetime(),
    )
    return inj, wdr


def characteristic_days(params: dict[str, Any], capacity_mcm: float | None) -> float:
    capa = float(capacity_mcm or params.get("storage_capacity_mcm") or 0)
    return days_empty_to_full(
        capa,
        float(params["p_inj"]),
        float(params["max_inj"]),
        params.get("max_inj_cap"),
    )
