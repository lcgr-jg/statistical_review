"""Build the trade-data pivot table.

The pivot tab lets a trader slice trade-level microstructure data along any
combination of derived attributes (contract type, time-to-expiry, broker,
hour-of-day, …) without writing code.  Heavy DataFrames are summarised into a
flat list-of-lists which ``dash_pivottable.PivotTable`` consumes directly.

We deliberately cap the number of rows shipped to the front-end (the React
component re-renders the whole grid on each interaction) and pre-compute a
fixed set of categorical buckets so the dropdowns are responsive even on a
year of trades.
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


# Soft ceiling on rows sent to the JS pivot component.  Set to a very large
# value so by default we ship every trade in the window — the user explicitly
# asked for no cap.  Kept as a safety valve for absurd payloads only.
MAX_PIVOT_ROWS = 5_000_000


# Columns surfaced to the user in the pivot dropdowns.  The order is the
# default left-to-right order shown in the "Available fields" panel.
PIVOT_COLUMNS: list[str] = [
    "trade_date",
    "weekday_name",
    "hour",
    "minute_of_hour",
    "session",
    "venue_label",
    "venue_code",
    "product_type",
    "broker_group",
    "tp_route",
    "is_sleeved",
    "tenor",
    "tenor_family",
    "contract_type",
    "days_to_expiry",
    "tte_start_bucket",
    "contract_length_bucket",
    "size_bucket",
    "side",
    "vwap_premium_bucket",
]


# Numeric values offered as the pivot's `vals` field (aggregated by
# Sum/Mean/Median in the renderer).
PIVOT_VALUES: list[str] = [
    "trade_count",
    "volume_mw",
    "notional",
    "vwap_premium",
    "price",
    "signed_volume",
    # NB: ``days_to_expiry`` is exposed via ``PIVOT_COLUMNS`` only.  The
    # pivottable lets you aggregate any column as a value (Sum / Mean /
    # Median / Count), so listing it once is enough — listing it twice
    # creates a duplicated header that silently breaks the row label.
]


_WEEKDAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


_MONTH_ABBR = {
    "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
    "JUL", "AUG", "SEP", "SEPT", "OCT", "NOV", "DEC",
}


def _classify_tenor(tenor: str) -> str:
    """Map a Trayport TENOR_NAME to a coarse contract bucket.

    Handles both the **labelled** form Trayport returns for fetched tenors
    (e.g. ``Jun-26``, ``Q3-26``, ``Cal-27``, ``Sum-26``, ``Win-26/27``) and
    the **relative** form occasionally seen (``M+1``, ``Q+2``, ``WkEnd+0``).
    Pipeline currently fetches Month/Quarter/Year only, so most rows resolve
    to one of those three buckets — anything else falls through to "Other".
    """
    if not isinstance(tenor, str):
        return "Other"
    t = tenor.upper().strip()
    if not t:
        return "Other"

    # ── Year / Cal contracts ──────────────────────────────────────────────
    if t.startswith(("CAL", "Y+", "YR", "20")):
        return "Year"

    # ── Quarter (Q1-26, Q+1) ──────────────────────────────────────────────
    if t.startswith("Q") and (len(t) > 1 and (t[1].isdigit() or t[1] == "+")):
        return "Quarter"

    # ── Season (Sum-26, Win-26/27, Spr-27, Aut-26, SEAS-26) ────────────────
    if t.startswith(("SUM", "WIN", "SPR", "AUT", "SEAS")):
        return "Season"

    # ── Balance-of contracts ──────────────────────────────────────────────
    if t.startswith("BOM"):
        return "BalMonth"
    if t.startswith(("BOY", "BOQ")):
        return "BalOther"

    # ── Day / Weekend / Week ──────────────────────────────────────────────
    if t.startswith("WKE") or t.startswith("WEEKEND") or t.startswith("WND"):
        return "Weekend"
    if t.startswith("WK") or t.startswith("W+") or t.startswith("WEEK"):
        return "Week"
    if t.startswith("DA") or t.startswith("D+") or t == "SD" or t.startswith("SAT") or t.startswith("SUN"):
        return "Day"

    # ── Month: labelled (Jun-26) or relative (M+1) ────────────────────────
    head = t.split("-", 1)[0].split("+", 1)[0].split(" ", 1)[0]
    if head in _MONTH_ABBR:
        return "Month"
    if t.startswith("M") and (len(t) > 1 and (t[1].isdigit() or t[1] == "+")):
        return "Month"

    # Bare 4-digit year (e.g. "2027") or Cal-27.
    if (len(t) == 4 and t.isdigit()) or t.startswith("CAL") or t.startswith("YR"):
        return "Year"

    return "Other"


def _broker_group(venue_code: Any, product_type: Any) -> str:
    """Bucket venue codes into broker / exchange groups."""
    if not isinstance(venue_code, str):
        return "Unknown"
    v = venue_code.upper()
    if product_type == "Exchange":
        return f"EXCH:{v}"
    return f"OTC:{v}"


def _expiry_bucket(tte_days: float) -> str:
    if pd.isna(tte_days):
        return "Unknown"
    d = float(tte_days)
    if d < 0:
        return "Expired"
    if d < 1:
        return "Prompt (<1d)"
    if d < 7:
        return "1d–1w"
    if d < 31:
        return "1w–1m"
    if d < 92:
        return "1m–3m"
    if d < 183:
        return "3m–6m"
    if d < 366:
        return "6m–1y"
    return "1y+"


def _size_bucket(qty: float) -> str:
    if pd.isna(qty):
        return "Unknown"
    q = float(qty)
    if q < 5:
        return "<5 MW"
    if q < 25:
        return "5–25"
    if q < 50:
        return "25–50"
    if q < 100:
        return "50–100"
    if q < 250:
        return "100–250"
    return "250+ MW"


def _session(hour: int) -> str:
    if hour < 7:
        return "Pre-market"
    if hour < 11:
        return "Morning"
    if hour < 14:
        return "Midday"
    if hour < 17:
        return "Afternoon"
    return "Late"


def _contract_length_bucket(days: float) -> str:
    if pd.isna(days):
        return "Unknown"
    d = float(days)
    if d <= 1:
        return "Day"
    if d <= 3:
        return "Weekend"
    if d <= 7:
        return "Week"
    if d <= 32:
        return "Month"
    if d <= 93:
        return "Quarter"
    if d <= 185:
        return "Season"
    return "Year"


def _is_trading_day(dt: pd.Timestamp) -> bool:
    """True if dt is a weekday (Mon-Fri)."""
    return dt.dayofweek < 5


def _count_trading_days(start: pd.Timestamp, end: pd.Timestamp) -> int:
    """Count trading days (Mon-Fri) between start and end inclusive.

    If start > end, returns 0.
    """
    if start > end:
        return 0
    # Use numpy busday_count for speed.
    return int(np.busday_count(start.date(), (end + pd.Timedelta(days=1)).date()))


def enrich_for_pivot(
    df: pd.DataFrame, tenor_metadata: dict[str, dict[str, Any]] | None = None,
) -> pd.DataFrame:
    """Add derived analytical columns used by the pivot view.

    Parameters
    ----------
    df:
        Cleaned trades DataFrame as produced by :func:`clean_trades`.
    tenor_metadata:
        Optional mapping ``TENOR_NAME -> {start, end, family}``.
    """
    if df.empty:
        return df.copy()

    out = pd.DataFrame(index=df.index)
    deal_time = pd.to_datetime(df["DEAL_TIME_UK"]).dt.tz_localize(None)
    out["trade_date"] = deal_time.dt.date.astype(str)
    out["weekday_name"] = deal_time.dt.dayofweek.map(
        {i: n for i, n in enumerate(_WEEKDAY_NAMES)}
    )
    out["hour"] = deal_time.dt.hour.astype(int)
    out["minute_of_hour"] = (deal_time.dt.minute // 15 * 15).astype(int)
    out["session"] = out["hour"].map(_session)

    out["venue_label"] = df.get("venue_label", df.get("VENUE_CODE", "")).astype(str)
    out["venue_code"] = df.get("VENUE_CODE", "").astype(str)
    out["product_type"] = df.get("product_type", "Unknown").astype(str)
    out["broker_group"] = [
        _broker_group(v, p)
        for v, p in zip(out["venue_code"], out["product_type"])
    ]
    out["tp_route"] = df.get("TP_ROUTE", "Unknown").astype(str)
    out["is_sleeved"] = df.get("INITIATOR_SLEEVE", False).astype(bool)

    out["tenor"] = df.get("TENOR_NAME", "").astype(str)
    out["contract_type"] = out["tenor"].map(_classify_tenor)

    if tenor_metadata:
        # Build a normalized lookup map to handle variants like Q127 vs Q1-27.
        # We strip dashes, spaces and uppercase everything.
        norm_meta = {str(k).replace("-", "").replace(" ", "").upper(): v 
                     for k, v in tenor_metadata.items() if isinstance(v, dict)}

        # Extract metadata components.
        starts = {k: v["start"] for k, v in tenor_metadata.items() if isinstance(v, dict)}
        ends = {k: v["end"] for k, v in tenor_metadata.items() if isinstance(v, dict)}
        families = {k: v["family"] for k, v in tenor_metadata.items() if isinstance(v, dict)}

        out["tenor_family"] = out["tenor"].map(families).fillna("Unknown")
        
        t_start = out["tenor"].map(starts)
        t_end = out["tenor"].map(ends)

        # Fallback to normalized lookup if direct mapping failed.
        null_mask = t_start.isna()
        if null_mask.any():
            # Create a temporary series of normalized tenor names for lookup.
            norm_tenors = out.loc[null_mask, "tenor"].str.replace("-", "").str.replace(" ", "").str.upper()
            
            # Map using the normalized dictionary.
            fixed_starts = norm_tenors.map({k: v["start"] for k, v in norm_meta.items()})
            fixed_ends = norm_tenors.map({k: v["end"] for k, v in norm_meta.items()})
            fixed_families = norm_tenors.map({k: v["family"] for k, v in norm_meta.items()})
            
            # Fill in the missing values.
            t_start = t_start.fillna(fixed_starts)
            t_end = t_end.fillna(fixed_ends)
            out["tenor_family"] = out["tenor_family"].where(~null_mask, fixed_families.fillna("Unknown"))

        # TTE to delivery start (trading days to expiry).
        # We define "trading days to expiry" as the number of business days
        # between trade_date and delivery_start.
        # e.g. if delivery_start is Mon Jun-01:
        #   Fri May-29 -> 1 day to expiry
        #   Mon Jun-01 -> 0 days to expiry (already expired/prompt)
        # We use a vectorized approach where possible, but for business days
        # we'll use a list comp over unique pairs to be safe.
        trade_dates = pd.to_datetime(out["trade_date"])
        delivery_starts = pd.to_datetime(t_start)
        
        # Calculate raw calendar days first as a fallback.
        cal_days = (delivery_starts - trade_dates).dt.days
        
        # For business days, we need to handle the "Thu -> 1, Fri -> 0" logic.
        # np.busday_count(beg, end) returns days in [beg, end).
        # If beg=Thu, end=Mon -> 2 (Thu, Fri).
        # If beg=Fri, end=Mon -> 1 (Fri).
        # If beg=Mon, end=Mon -> 0.
        # This matches your requirement: Thu -> 1, Fri -> 0 (for a Mon expiry).
        def _get_bdays(row):
            if pd.isna(row.trade) or pd.isna(row.expiry):
                return np.nan
            t, e = row.trade.date(), row.expiry.date()
            if t >= e:
                return 0
            return int(np.busday_count(t, e))

        temp_df = pd.DataFrame({"trade": trade_dates, "expiry": delivery_starts})
        # Optimization: only compute for unique pairs.
        unique_pairs = temp_df.dropna().drop_duplicates()
        unique_pairs["bdays"] = [
            # Subtract 1 so Thu→Mon = 1 (not 2) and Fri→Mon = 0 (not 1).
            max(0, int(np.busday_count(r.trade.date(), r.expiry.date())) - 1)
            for r in unique_pairs.itertuples()
        ]

        # Map back.  Use a left-merge keyed on (trade, expiry) so we keep the
        # original row order.  Result is a float column (NaN where merge missed).
        merged = temp_df.merge(unique_pairs, on=["trade", "expiry"], how="left")
        # Convert to nullable Int64 -> plain Python ints / None on iteration,
        # which dash_pivottable displays cleanly as row labels.
        out["days_to_expiry"] = merged["bdays"].astype("Int64").values

        out["tte_start_bucket"] = merged["bdays"].map(
            lambda d: _expiry_bucket(d) if pd.notna(d) else "Unknown"
        ).values

        # Contract length.
        length = (pd.to_datetime(t_end) - pd.to_datetime(t_start)).dt.days + 1
        out["contract_length_bucket"] = length.map(_contract_length_bucket)
    else:
        out["tenor_family"] = "Unknown"
        out["days_to_expiry"] = np.nan
        out["tte_start_bucket"] = "Unknown"
        out["contract_length_bucket"] = "Unknown"

    qty = df["QUANTITY"].astype(float)
    out["size_bucket"] = qty.map(_size_bucket)

    if "AGGRESSOR_BUY" in df.columns:
        out["side"] = np.where(df["AGGRESSOR_BUY"].astype(bool), "BUY", "SELL")
    else:
        out["side"] = "Unknown"

    # Numeric values.
    out["trade_count"] = 1
    out["volume_mw"] = qty
    out["notional"] = df.get("dollar_volume", df["PRICE"].astype(float) * qty)
    out["price"] = df["PRICE"].astype(float)
    out["signed_volume"] = df.get("signed_qty", qty * np.where(out["side"] == "BUY", -1, 1))

    # VWAP premium per (trade_date, tenor): trade price minus per-day-tenor VWAP.
    grp = out.groupby(["trade_date", "tenor"], observed=True)
    vwap = (
        (out["price"] * out["volume_mw"]).groupby([out["trade_date"], out["tenor"]]).transform("sum")
        / out["volume_mw"].groupby([out["trade_date"], out["tenor"]]).transform("sum")
    )
    out["vwap_premium"] = out["price"] - vwap
    out["vwap_premium_bucket"] = pd.cut(
        out["vwap_premium"],
        bins=[-np.inf, -1.0, -0.25, -0.05, 0.05, 0.25, 1.0, np.inf],
        labels=["≤-1", "-1..-0.25", "-0.25..-0.05", "±0.05", "0.05..0.25", "0.25..1", ">1"],
    ).astype(str)

    return out


def build_pivot_payload(
    df_cleaned: pd.DataFrame,
    tenor_metadata: dict[str, dict[str, Any]] | None = None,
) -> tuple[list[list[Any]], int]:
    """Return ``(data, n_rows)`` ready for ``dash_pivottable.PivotTable``.

    The first row is the header.  We always include both the categorical and
    numeric columns so the user can freely drag any field into rows / cols /
    vals.  Rows are capped at :data:`MAX_PIVOT_ROWS` (newest first).
    """
    if df_cleaned.empty:
        header = PIVOT_COLUMNS + PIVOT_VALUES
        return [header], 0

    enriched = enrich_for_pivot(df_cleaned, tenor_metadata=tenor_metadata)

    cols = PIVOT_COLUMNS + PIVOT_VALUES
    enriched = enriched.reindex(columns=cols)

    if len(enriched) > MAX_PIVOT_ROWS:
        # Take the most recent N trades — most useful for trader analysis.
        enriched = enriched.sort_values("trade_date").tail(MAX_PIVOT_ROWS)
        logger.info(
            "[microstructure pivot] capped %d -> %d rows",
            len(df_cleaned), MAX_PIVOT_ROWS,
        )

    # ``dash_pivottable`` is a thin React wrapper that JSON-serialises every
    # cell.  Numpy scalars (np.int64, np.float64, np.bool_) and pd.Timestamp
    # don't round-trip cleanly: integer-valued floats sometimes render blank
    # as row labels, and NaN becomes the literal string "NaN".  We coerce
    # everything to plain Python types up-front and replace NaN with None
    # (which the JS side drops from the row-label dropdown).
    def _coerce(v: Any) -> Any:
        if v is None:
            return None
        # pandas NA / numpy NaN.
        try:
            if pd.isna(v):
                return None
        except (TypeError, ValueError):
            pass
        if isinstance(v, (np.integer,)):
            return int(v)
        if isinstance(v, (np.floating,)):
            f = float(v)
            # Render integer-valued floats as ints so the pivot row labels
            # show "17" instead of "17.0".
            if f.is_integer():
                return int(f)
            return f
        if isinstance(v, np.bool_):
            return bool(v)
        if isinstance(v, (pd.Timestamp,)):
            return v.strftime("%Y-%m-%d")
        return v

    data: list[list[Any]] = [cols]
    for row in enriched.itertuples(index=False, name=None):
        data.append([_coerce(v) for v in row])
    return data, len(enriched)
