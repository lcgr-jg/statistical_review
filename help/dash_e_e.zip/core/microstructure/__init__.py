"""
Trade Microstructure dashboard package.

Sub-modules (import explicitly to avoid pulling Snowflake / Trayport deps in tests):

    * ``constants``     -- zone / shape / tenor enums, page metadata, cache TTLs
    * ``signal_engine`` -- daily panel construction + statistical alpha tests (pure)
    * ``figures``       -- Plotly figure builders (light "dashboard" theme)
    * ``data_pipeline`` -- Snowflake / Trayport fetchers; backed by ``DashboardCache``
                           (TTL + size-capped) so the server's disk cannot grow
                           unbounded.  See ``CACHE_PREFIX_*`` and the on-startup
                           ``_register_microstructure_cleanup`` helper.
    * ``layout``        -- ``build_layout()`` (pure)
    * ``callbacks``     -- Dash callbacks (registered on import)

Importing this package is side-effect-free.
"""
