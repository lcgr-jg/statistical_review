"""Layout for the Trade Microstructure page.

Re-themed for ``eu_dashboard_power``: light card-on-grey background, breadcrumb
header (``Power / Microstructure``) matching :mod:`core.heatmap_balance.layout`,
``dbc.Tabs`` with the dashboard accent colour.

Pure: ``build_layout()`` returns an ``html.Div`` with no callbacks attached.
"""
from __future__ import annotations

from datetime import date, datetime

import dash_bootstrap_components as dbc
from dash import dcc, html

from core.styles import COLORS

from .constants import (
    COMMODITY_LABELS,
    POWER_ZONES_LABELS,
    SHAPE_LABELS,
)

# ── Shared field styling ─────────────────────────────────────────────────────
_LABEL_STYLE = {
    "fontSize": "11px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "4px",
    "textTransform": "uppercase",
    "letterSpacing": "0.04em",
}
_FIELD_STYLE = {
    "minWidth": "0",
    "flex": "1 1 auto",
}
_GROUP_STYLE = {
    "display": "flex",
    "gap": "10px",
    "alignItems": "flex-end",
    "padding": "10px 14px",
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "8px",
    "backgroundColor": COLORS["card_bg_alt"],
}


def _field(label: str, control: html.Div | dcc.Dropdown | dbc.Select, *, width: str = "auto") -> html.Div:
    return html.Div(
        style={**_FIELD_STYLE, "width": width} if width != "auto" else _FIELD_STYLE,
        children=[
            html.Div(label, style=_LABEL_STYLE),
            control,
        ],
    )


# ── Tab definitions ──────────────────────────────────────────────────────────
TAB_IDS: list[tuple[str, str]] = [
    ("tab-overview", "Overview"),
    ("tab-flow", "Flow Analysis"),
    ("tab-intraday", "Intraday"),
    ("tab-micro", "Microstructure"),
    ("tab-pivot", "Pivot"),
    ("tab-otc", "OTC Levels"),
]


# ── Top control bar ──────────────────────────────────────────────────────────
def _build_control_bar(today: date) -> html.Div:
    default_start = date(2026, 1, 1)

    # ── Group 1: Market selection ─────────────────────────────────────────
    market_group = html.Div(
        style=_GROUP_STYLE,
        children=[
            _field(
                "Commodity",
                dbc.Select(
                    id="ms-commodity",
                    options=[{"label": c, "value": c} for c in COMMODITY_LABELS],
                    value="Power",
                    size="sm",
                ),
                width="110px",
            ),
            _field(
                "Market",
                dbc.Select(
                    id="ms-zone",
                    options=[{"label": z, "value": z} for z in POWER_ZONES_LABELS],
                    value="France",
                    size="sm",
                ),
                width="150px",
            ),
            _field(
                "Shape",
                dbc.Select(
                    id="ms-shape",
                    options=[{"label": s, "value": s} for s in SHAPE_LABELS],
                    value="Baseload",
                    size="sm",
                ),
                width="110px",
            ),
            _field(
                "Contract",
                dcc.RadioItems(
                    id="ms-product",
                    options=[
                        {"label": " Outright", "value": "outright"},
                        {"label": " Spread", "value": "spread"},
                    ],
                    value="outright",
                    inline=True,
                    inputClassName="me-1",
                    labelClassName="me-3 small",
                    style={"paddingTop": "4px"},
                ),
                width="180px",
            ),
        ],
    )

    # ── Group 2: Tenor + venues ───────────────────────────────────────────
    select_group = html.Div(
        style=_GROUP_STYLE,
        children=[
            _field(
                "Tenor",
                dbc.Select(id="ms-tenor", size="sm"),
                width="160px",
            ),
            _field(
                "Venues",
                dcc.Dropdown(
                    id="ms-venues",
                    multi=True,
                    placeholder="Select venues...",
                    style={"minWidth": "260px"},
                ),
                width="280px",
            ),
        ],
    )

    # ── Group 3: Date range ───────────────────────────────────────────────
    date_group = html.Div(
        style=_GROUP_STYLE,
        children=[
            _field(
                "Date range",
                dcc.DatePickerRange(
                    id="ms-date-range",
                    start_date=default_start,
                    end_date=today,
                    display_format="YYYY-MM-DD",
                    style={"fontSize": "12px"},
                ),
                width="280px",
            ),
        ],
    )

    # ── Group 4: Load ─────────────────────────────────────────────────────
    action_group = html.Div(
        style=_GROUP_STYLE,
        children=[
            html.Div(
                style={"display": "flex", "gap": "10px", "alignItems": "center"},
                children=[
                    dcc.Loading(
                        id="ms-refresh-loading",
                        type="default",
                        color=COLORS["accent"],
                        children=dbc.Button(
                            [html.I(className="fas fa-sync-alt me-1"), " Load"],
                            id="ms-refresh",
                            color="primary",
                            size="sm",
                        ),
                    ),
                    html.Span(
                        id="ms-refresh-status",
                        className="small",
                        style={
                            "color": COLORS["text_muted"],
                            "maxWidth": "320px",
                            "overflow": "hidden",
                            "textOverflow": "ellipsis",
                            "whiteSpace": "nowrap",
                        },
                    ),
                ],
            ),
        ],
    )

    return html.Div(
        style={
            "display": "flex",
            "flexWrap": "wrap",
            "gap": "12px",
            "alignItems": "stretch",
        },
        children=[market_group, select_group, date_group, action_group],
    )


# ── Public layout entry-point ────────────────────────────────────────────────
def build_layout() -> html.Div:
    today = datetime.now().date()
    return html.Div(
        style={"backgroundColor": COLORS["background"], "minHeight": "100vh"},
        children=[
            # ── Header card with breadcrumb + control bar ────────────────
            html.Div(
                style={
                    "padding": "16px 22px",
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "backgroundColor": COLORS["card_bg"],
                },
                children=[
                    html.Div(
                        [
                            html.Span("Power", style={"color": "#888", "fontSize": "13px"}),
                            html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                            html.Span(
                                "Trade Data",
                                style={
                                    "fontWeight": "600",
                                    "color": COLORS["text_primary"],
                                },
                            ),
                            html.Span(
                                "  EU Power -- trade-flow & microstructure alpha analysis",
                                style={
                                    "marginLeft": "16px",
                                    "color": COLORS["text_muted"],
                                    "fontSize": "12px",
                                },
                            ),
                        ],
                        style={"marginBottom": "14px"},
                    ),
                    _build_control_bar(today),
                    html.Div(
                        id="ms-kpi-strip",
                        style={
                            "display": "flex",
                            "gap": "24px",
                            "marginTop": "14px",
                            "alignItems": "center",
                        },
                    ),
                    # Module-level data store: holds Snowflake-fetched DataFrames
                    # serialised as records.  TTL/eviction is handled by the
                    # shared DashboardCache, but we also use a Dash dcc.Store
                    # so the figure callbacks don't have to re-fetch from cache
                    # on every venue/tenor change within a single browser tab.
                    dcc.Store(id="ms-data-version", data=0),
                ],
            ),
            # ── Tabs ──────────────────────────────────────────────────────
            dbc.Tabs(
                id="ms-tabs",
                active_tab="tab-overview",
                style={"padding": "0 16px", "marginTop": "8px"},
                children=[
                    dbc.Tab(label=label, tab_id=tid)
                    for tid, label in TAB_IDS
                ],
            ),
            dcc.Loading(
                id="ms-tab-loading",
                type="cube",
                color=COLORS["accent"],
                fullscreen=False,
                style={
                    "minHeight": "400px",
                },
                parent_style={
                    "minHeight": "400px",
                },
                children=html.Div(
                    id="ms-tab-content",
                    style={"padding": "16px", "minHeight": "400px"},
                ),
            ),
        ],
    )
