"""
Signal Engine
=============

Daily panel construction, statistical tests, and alpha-signal metrics.
All functions are pure (DataFrame in, DataFrame/Series out) with no
side-effects or I/O.

Ported verbatim from ``adhoc/trade_data/microstructure_dashboard/signal_engine.py``;
the only behavioural change is that ``EXCHANGE_VENUES`` / ``FORWARD_HORIZONS``
are now imported from :mod:`core.microstructure.constants` so this module
has no Snowflake dependency.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats as sp_stats

from .constants import EXCHANGE_VENUES, FORWARD_HORIZONS

SIGNAL_COLS: dict[str, str] = {
    "broker_net_flow": "Net Initiator Flow (MW)",
    "broker_premium_bps": "VWAP Premium (bps)",
    "broker_volume_share": "Volume Share",
    "broker_avg_size": "Avg Trade Size (MW)",
}


# ---------------------------------------------------------------------------
# Daily panel builder
# ---------------------------------------------------------------------------


def build_daily_panel(
    df: pd.DataFrame,
    selected_venues: list[str],
    tenor_name: str | None = None,
    comparison_mode: str = "rest",
) -> pd.DataFrame:
    """
    Build a daily panel of market vs selected-venue metrics.

    Reference VWAP is always computed on all cleaned trades (all venues).
    comparison_mode is kept for backwards-compatibility but defaults to "all":
        "all"      -> every venue including selected (recommended)
        "rest"     -> all venues *except* selected
        "exchange" -> EEX7 direct trades only
    """
    sub = df.copy()
    if tenor_name:
        sub = sub[sub["TENOR_NAME"] == tenor_name]
    if sub.empty:
        return pd.DataFrame()

    vcol = "venue_label" if "venue_label" in sub.columns else "VENUE_CODE"
    sub["is_selected"] = sub[vcol].isin(selected_venues)

    if comparison_mode == "exchange":
        ref = sub[sub["VENUE_CODE"].isin(EXCHANGE_VENUES)]
    elif comparison_mode == "rest":
        ref = sub[~sub["is_selected"]]
    else:
        ref = sub

    if ref.empty:
        ref = sub

    daily_ref = ref.groupby("trade_date").agg(
        market_vwap=("dollar_volume", "sum"),
        total_volume=("QUANTITY", "sum"),
    )
    daily_ref["market_vwap"] = daily_ref["market_vwap"] / daily_ref["total_volume"]

    daily_total_vol = sub.groupby("trade_date")["QUANTITY"].sum().rename("all_volume")

    sel = sub[sub["is_selected"]]
    if sel.empty:
        panel = daily_ref.copy()
        panel = panel.join(daily_total_vol, how="left")
        for c in [
            "broker_vwap", "broker_volume", "broker_net_flow",
            "broker_trade_count", "broker_avg_size",
        ]:
            panel[c] = 0 if "count" in c or "volume" in c or "flow" in c else np.nan
    else:
        daily_sel = sel.groupby("trade_date").agg(
            bv_num=("dollar_volume", "sum"),
            broker_volume=("QUANTITY", "sum"),
            broker_net_flow=("signed_qty", "sum"),
            broker_trade_count=("PRICE", "count"),
        )
        daily_sel["broker_vwap"] = daily_sel["bv_num"] / daily_sel["broker_volume"]
        daily_sel["broker_avg_size"] = (
            daily_sel["broker_volume"] / daily_sel["broker_trade_count"]
        )
        daily_sel = daily_sel.drop(columns=["bv_num"])
        panel = daily_ref.join(daily_sel, how="left")
        panel = panel.join(daily_total_vol, how="left")
        panel["broker_volume"] = panel["broker_volume"].fillna(0)
        panel["broker_net_flow"] = panel["broker_net_flow"].fillna(0)
        panel["broker_trade_count"] = panel["broker_trade_count"].fillna(0)

    panel["broker_volume_share"] = panel["broker_volume"] / panel["all_volume"].replace(0, np.nan)
    panel["broker_premium_bps"] = (
        (panel["broker_vwap"] - panel["market_vwap"])
        / panel["market_vwap"].replace(0, np.nan)
        * 10_000
    )

    panel = panel.sort_index()
    for h in FORWARD_HORIZONS:
        panel[f"fwd_ret_{h}d"] = panel["market_vwap"].pct_change(h).shift(-h)
    return panel


# ---------------------------------------------------------------------------
# Statistical test tables
# ---------------------------------------------------------------------------


def spearman_table(
    panel: pd.DataFrame,
    horizons: list[int] | None = None,
) -> pd.DataFrame:
    if horizons is None:
        horizons = FORWARD_HORIZONS
    rows = []
    for sig, label in SIGNAL_COLS.items():
        for h in horizons:
            ret = f"fwd_ret_{h}d"
            v = panel[[sig, ret]].dropna()
            if len(v) < 15:
                continue
            rho, p = sp_stats.spearmanr(v[sig], v[ret])
            rows.append({
                "Signal": label, "Horizon": f"{h}d",
                "Rho": round(rho, 4), "p-value": round(p, 4),
                "N": len(v), "Sig": "Yes" if p < 0.05 else "",
            })
    return pd.DataFrame(rows)


def conditional_table(
    panel: pd.DataFrame,
    horizons: list[int] | None = None,
) -> pd.DataFrame:
    if horizons is None:
        horizons = FORWARD_HORIZONS
    rows = []
    for sig, label in SIGNAL_COLS.items():
        for h in horizons:
            ret = f"fwd_ret_{h}d"
            v = panel[[sig, ret]].dropna()
            if len(v) < 20:
                continue
            med = v[sig].median()
            high = v.loc[v[sig] >= med, ret]
            low = v.loc[v[sig] < med, ret]
            if len(high) < 5 or len(low) < 5:
                continue
            _, p = sp_stats.mannwhitneyu(high, low, alternative="two-sided")
            rows.append({
                "Signal": label, "Horizon": f"{h}d",
                "High Mean": f"{high.mean():.5f}",
                "Low Mean": f"{low.mean():.5f}",
                "Diff (bps)": round((high.mean() - low.mean()) * 1e4, 1),
                "p-value": round(p, 4),
                "Sig": "Yes" if p < 0.05 else "",
            })
    return pd.DataFrame(rows)


def granger_table(panel: pd.DataFrame) -> pd.DataFrame:
    try:
        from statsmodels.tsa.stattools import grangercausalitytests
    except ImportError:
        return pd.DataFrame()
    rows = []
    for sig, label in SIGNAL_COLS.items():
        v = panel[[sig, "fwd_ret_1d"]].dropna()
        if len(v) < 20:
            continue
        try:
            res = grangercausalitytests(
                v[["fwd_ret_1d", sig]].values, maxlag=5, verbose=False
            )
        except Exception:
            continue
        for lag, r in res.items():
            f_stat, p, _, _ = r[0]["ssr_ftest"]
            rows.append({
                "Signal": label, "Lag": lag, "F": round(f_stat, 3),
                "p-value": round(p, 4), "Sig": "Yes" if p < 0.05 else "",
            })
    return pd.DataFrame(rows)


def cross_tenor_table(
    df: pd.DataFrame,
    selected_venues: list[str],
    horizon: int = 1,
    comparison_mode: str = "rest",
) -> pd.DataFrame:
    top_tenors = df["TENOR_NAME"].value_counts().head(10).index.tolist()
    rows = []
    for tn in top_tenors:
        p = build_daily_panel(df, selected_venues, tenor_name=tn,
                              comparison_mode=comparison_mode)
        if p.empty or len(p) < 20:
            continue
        ret = f"fwd_ret_{horizon}d"
        for sig, label in SIGNAL_COLS.items():
            v = p[[sig, ret]].dropna()
            if len(v) < 15:
                continue
            rho, pv = sp_stats.spearmanr(v[sig], v[ret])
            rows.append({
                "Tenor": tn, "Signal": label, "Rho": round(rho, 4),
                "p-value": round(pv, 4), "N": len(v),
                "Sig": "Yes" if pv < 0.05 else "",
            })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Rolling signal strength
# ---------------------------------------------------------------------------


def rolling_signal_strength(
    panel: pd.DataFrame,
    signal_col: str,
    horizon: int = 1,
    window: int = 60,
) -> pd.DataFrame:
    """
    Compute rolling Spearman correlation between a signal and forward return.
    Returns DataFrame with columns [date, rho, p_value].
    """
    ret_col = f"fwd_ret_{horizon}d"
    v = panel[[signal_col, ret_col]].dropna()
    if len(v) < window:
        return pd.DataFrame(columns=["date", "rho", "p_value"])

    results = []
    for i in range(window, len(v) + 1):
        chunk = v.iloc[i - window: i]
        rho, p = sp_stats.spearmanr(chunk[signal_col], chunk[ret_col])
        results.append({"date": chunk.index[-1], "rho": rho, "p_value": p})

    return pd.DataFrame(results)


# ---------------------------------------------------------------------------
# Regime analysis
# ---------------------------------------------------------------------------


def regime_split_analysis(
    panel: pd.DataFrame,
    vol_window: int = 20,
    horizons: list[int] | None = None,
) -> pd.DataFrame:
    """
    Split into high-vol / low-vol regimes using rolling 20d realized
    volatility, then re-run Spearman within each regime.
    """
    if horizons is None:
        horizons = FORWARD_HORIZONS

    daily_ret = panel["market_vwap"].pct_change()
    panel = panel.copy()
    panel["realized_vol"] = daily_ret.rolling(vol_window).std()
    vol_med = panel["realized_vol"].median()
    panel["vol_regime"] = np.where(
        panel["realized_vol"] >= vol_med, "High Vol", "Low Vol"
    )

    rows = []
    for regime in ["High Vol", "Low Vol"]:
        regime_panel = panel[panel["vol_regime"] == regime]
        if len(regime_panel) < 20:
            continue
        for sig, label in SIGNAL_COLS.items():
            for h in horizons:
                ret = f"fwd_ret_{h}d"
                v = regime_panel[[sig, ret]].dropna()
                if len(v) < 10:
                    continue
                rho, p = sp_stats.spearmanr(v[sig], v[ret])
                rows.append({
                    "Regime": regime, "Signal": label, "Horizon": f"{h}d",
                    "Rho": round(rho, 4), "p-value": round(p, 4),
                    "N": len(v), "Sig": "Yes" if p < 0.05 else "",
                })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Signal heatmap (signal x tenor)
# ---------------------------------------------------------------------------


def signal_heatmap_data(
    df: pd.DataFrame,
    selected_venues: list[str],
    horizon: int = 1,
    comparison_mode: str = "rest",
) -> pd.DataFrame:
    """
    Cross (signal x tenor) Spearman rho matrix for quick screening.
    Returns wide DataFrame: rows = tenors, cols = signal labels.
    """
    top_tenors = df["TENOR_NAME"].value_counts().head(10).index.tolist()
    records: dict[str, dict[str, float]] = {}

    for tn in top_tenors:
        p = build_daily_panel(df, selected_venues, tenor_name=tn,
                              comparison_mode=comparison_mode)
        if p.empty or len(p) < 20:
            continue
        ret = f"fwd_ret_{horizon}d"
        row: dict[str, float] = {}
        for sig, label in SIGNAL_COLS.items():
            v = p[[sig, ret]].dropna()
            if len(v) < 15:
                row[label] = np.nan
                continue
            rho, _ = sp_stats.spearmanr(v[sig], v[ret])
            row[label] = round(rho, 4)
        records[tn] = row

    if not records:
        return pd.DataFrame()
    return pd.DataFrame(records).T
