"""
Data Pipeline -- Trayport / Snowflake fetchers backed by ``DashboardCache``.

Disk-space safety
-----------------
The original adhoc dashboard wrote one parquet file per (zone, shape, date-window,
spreads) tuple under ``adhoc/trade_data/cache/`` with no eviction.  That folder
was unbounded -- every fresh trade-date or new venue selection added a new file
and old ones were never removed.

This server-side port instead routes every cache operation through the shared
:data:`core.cache.dashboard_cache`:

* The **disk tier** is a `diskcache.Cache` with a hard size cap (set at server
  startup in ``portal_app.py`` -- typically 10 GB across the whole dashboard).
  When the cap is hit, ``diskcache`` automatically evicts least-recently-used
  entries.
* Every entry is written with an explicit **TTL** (see ``CACHE_TTL_*`` in
  :mod:`.constants`).  ``DashboardCache`` calls ``diskcache.expire()`` and
  ``cull()`` on its hourly maintenance loop, so stale parquet blobs are
  proactively removed even if the cap hasn't been reached yet.
* :func:`cleanup_microstructure_cache` adds an extra per-prefix cap (default
  1 GB across all microstructure data) to keep this page from monopolising the
  shared budget.  It runs every ``CLEANUP_INTERVAL_HOURS`` from a background
  thread that ``register_microstructure_cleanup_job`` schedules at startup.

In other words: nothing this module writes can stay on disk indefinitely.
"""
from __future__ import annotations

import hashlib
import logging
import threading
import time
from datetime import datetime, timedelta
from typing import Any, Optional

import numpy as np
import pandas as pd

from core.cache import dashboard_cache

from .constants import (
    CACHE_PREFIX_ACTIVITY,
    CACHE_PREFIX_OB,
    CACHE_PREFIX_TRADES,
    CACHE_TTL_ACTIVITY_HISTORICAL,
    CACHE_TTL_ACTIVITY_LIVE,
    CACHE_TTL_OB_HISTORICAL,
    CACHE_TTL_OB_LIVE,
    CACHE_TTL_TRADES_HISTORICAL,
    CACHE_TTL_TRADES_LIVE,
    CLEANUP_INTERVAL_HOURS,
    EXCHANGE_VENUES,  # noqa: F401  (re-exported for callers that imported it from here)
    MAX_DISK_MB,
    POWER_ZONES_LABELS,
    SHAPE_LABELS,
    SHAPED_COMMODITIES,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy-loaded Snowflake / Trayport handles
# ---------------------------------------------------------------------------
# Importing ``snowflake.connector`` and ``jain_commods.core.interfaces.snowflake.trayportquery``
# is expensive (and pulls a lot of optional deps).  We defer them to first call so
# the rest of ``eu_dashboard_power`` can import this module in environments
# where Snowflake isn't configured -- the page just won't be able to fetch data.
_SNOWFLAKE_PATCHED = False
_TRAYPORT_HANDLE: dict = {}


def _bootstrap_trayport() -> dict:
    """Lazy-init Snowflake OCSP bypass + Trayport enums.  Cached after first call."""
    if _TRAYPORT_HANDLE:
        return _TRAYPORT_HANDLE

    global _SNOWFLAKE_PATCHED
    if not _SNOWFLAKE_PATCHED:
        try:
            import snowflake.connector  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "snowflake-connector-python is required for the microstructure "
                "page.  Install it (or set up the jain_commods environment) and "
                "restart the dashboard."
            ) from exc

        _orig = snowflake.connector.connect

        def _insecure(*args, **kwargs):
            kwargs["insecure_mode"] = True
            return _orig(*args, **kwargs)

        snowflake.connector.connect = _insecure
        _SNOWFLAKE_PATCHED = True

    from jain_commods.core.interfaces.snowflake.trayportquery import (  # type: ignore
        TrayportCommodity,
        TrayportQuery,
        TrayportShape,
        TrayportTenor,
        TrayportZone,
    )

    power_zones = {
        "Germany": TrayportZone.GERMANY,
        "France": TrayportZone.FRANCE,
        "Spain": TrayportZone.SPAIN,
        "Italy": TrayportZone.ITALY,
        "Belgium": TrayportZone.BELGIUM,
        "UK": TrayportZone.UK,
        "Nordic": TrayportZone.NORDIC,
        "Austria": TrayportZone.AUSTRIA,
        "Holland": TrayportZone.HOLLAND,
        "Swiss": TrayportZone.SWISS,
        "Czech": TrayportZone.CZECH,
        "Hungary": TrayportZone.HUNGARY,
        "Denmark": TrayportZone.DENMARK,
        "Finland": TrayportZone.FINLAND,
        "Sweden": TrayportZone.SWEDEN,
        "Greece": TrayportZone.GREECE,
        "Romania": TrayportZone.ROMANIA,
        "Slovakia": TrayportZone.SLOVAKIA,
        "Slovenia": TrayportZone.SLOVENIA,
        "Croatia": TrayportZone.CROATIA,
        "Bulgaria": TrayportZone.BULGARIA,
    }
    gas_zones = {
        "TTF": TrayportZone.TTF,
        "THE": TrayportZone.THE,
        "NBP": TrayportZone.NBP,
        "PEG": TrayportZone.PEG,
        "PSV": TrayportZone.PSV,
        "ZTP": TrayportZone.ZTP,
        "CEGH VTP": TrayportZone.CEGH_VTP,
        "PVB": TrayportZone.PVB,
    }
    carbon_zones = {
        "EUA": TrayportZone.EUA,
        "UKA": TrayportZone.UKA,
    }

    _TRAYPORT_HANDLE.update({
        "TrayportQuery": TrayportQuery,
        "TrayportCommodity": TrayportCommodity,
        "COMMODITIES": {
            "Power": TrayportCommodity.POWER,
            "Gas": TrayportCommodity.GAS,
            "Carbon": TrayportCommodity.CARBON,
        },
        "POWER_ZONES": power_zones,
        # Flat label → TrayportZone map across every commodity.  The label set
        # mirrors ``constants.COMMODITY_ZONES``.
        "ZONES": {**power_zones, **gas_zones, **carbon_zones},
        "SHAPES": {
            "Baseload": TrayportShape.BASELOAD,
            "Peakload": TrayportShape.PEAKLOAD,
            "Offpeak": TrayportShape.OFFPEAK,
        },
        "ALL_TENORS": [TrayportTenor.MONTH, TrayportTenor.QUARTER, TrayportTenor.YEAR],
    })
    return _TRAYPORT_HANDLE


def _resolve(handle: dict, commodity: str, zone: str, shape: str | None):
    """Map UI labels → Trayport enums.

    ``shape`` only applies to shaped commodities (Power).  For Gas / Carbon the
    Trayport query ignores shape entirely, so we pass ``None`` and skip the
    shape lookup.  Raises ``ValueError`` on an unknown commodity / zone (or an
    unknown shape when the commodity is shaped).
    """
    commodity_enum = handle["COMMODITIES"].get(commodity)
    if commodity_enum is None:
        raise ValueError(f"Unknown commodity: {commodity}")
    zone_enum = handle["ZONES"].get(zone)
    if zone_enum is None:
        raise ValueError(f"Unknown zone: {zone}")
    shape_enum = None
    if commodity in SHAPED_COMMODITIES:
        shape_enum = handle["SHAPES"].get(shape)
        if shape_enum is None:
            raise ValueError(f"Unknown shape: {shape}")
    return commodity_enum, zone_enum, shape_enum


# Public dictionaries that the layout consumes (label-only, no enum).
# These are kept as plain dicts so importing this module never triggers
# ``_bootstrap_trayport`` (which would fail without Snowflake creds).
POWER_ZONES = {label: label for label in POWER_ZONES_LABELS}
SHAPES = {label: label for label in SHAPE_LABELS}


# ---------------------------------------------------------------------------
# Cache key helpers (route through DashboardCache)
# ---------------------------------------------------------------------------


def _cache_key(prefix: str, **kwargs) -> str:
    raw = f"{prefix}|" + "|".join(f"{k}={v}" for k, v in sorted(kwargs.items()))
    digest = hashlib.md5(raw.encode()).hexdigest()[:16]
    return f"{prefix}:{digest}"


def _is_live(end_date: datetime | None) -> bool:
    return (end_date or datetime.now()).date() == datetime.now().date()


# ---------------------------------------------------------------------------
# Fetch functions
# ---------------------------------------------------------------------------


def fetch_trades(
    zone: str = "France",
    shape: str = "Baseload",
    start_date: datetime | None = None,
    end_date: datetime | None = None,
    include_spreads: bool = False,
    force_refresh: bool = False,
    commodity: str = "Power",
) -> pd.DataFrame:
    """Fetch raw trades from Snowflake, cached in ``DashboardCache``."""
    if start_date is None:
        start_date = datetime.now() - timedelta(days=365)

    key = _cache_key(
        CACHE_PREFIX_TRADES,
        commodity=commodity,
        zone=zone,
        shape=shape,
        start=start_date.strftime("%Y%m%d"),
        end=(end_date or datetime.now()).strftime("%Y%m%d"),
        spreads=str(include_spreads),
    )
    ttl = CACHE_TTL_TRADES_LIVE if _is_live(end_date) else CACHE_TTL_TRADES_HISTORICAL

    if not force_refresh:
        cached = dashboard_cache.get(key, ttl=ttl)
        if cached is not None:
            logger.info("[microstructure] trades cache hit (%d rows)", len(cached))
            return cached

    handle = _bootstrap_trayport()
    commodity_enum, zone_enum, shape_enum = _resolve(handle, commodity, zone, shape)

    logger.info(
        "[microstructure] fetching %s %s %s trades %s..%s spreads=%s",
        commodity, zone, shape,
        start_date.strftime("%Y-%m-%d"),
        (end_date or datetime.now()).strftime("%Y-%m-%d"),
        include_spreads,
    )
    tq = handle["TrayportQuery"]()
    df = tq.get_trades(
        commodity=commodity_enum,
        zone=zone_enum,
        shape=shape_enum,
        tenors=handle["ALL_TENORS"],
        start_date=start_date,
        end_date=end_date,
        include_private=False,
        include_spreads=include_spreads,
    )
    logger.info("[microstructure] raw trades: %d", len(df))

    dashboard_cache.set(key, df, ttl=ttl)
    return df


def fetch_order_book(
    zone: str = "France",
    shape: str = "Baseload",
    start_date: datetime | None = None,
    end_date: datetime | None = None,
    force_refresh: bool = False,
    commodity: str = "Power",
) -> pd.DataFrame:
    """Fetch L1 order-book snapshots."""
    if start_date is None:
        start_date = datetime.now() - timedelta(days=30)

    key = _cache_key(
        CACHE_PREFIX_OB,
        commodity=commodity,
        zone=zone,
        shape=shape,
        start=start_date.strftime("%Y%m%d"),
        end=(end_date or datetime.now()).strftime("%Y%m%d"),
    )
    ttl = CACHE_TTL_OB_LIVE if _is_live(end_date) else CACHE_TTL_OB_HISTORICAL

    if not force_refresh:
        cached = dashboard_cache.get(key, ttl=ttl)
        if cached is not None:
            return cached

    handle = _bootstrap_trayport()
    commodity_enum, zone_enum, shape_enum = _resolve(handle, commodity, zone, shape)

    logger.info("[microstructure] fetching %s %s %s L1 order book", commodity, zone, shape)
    tq = handle["TrayportQuery"]()
    df = tq.get_orders(
        commodity=commodity_enum,
        zone=zone_enum,
        shape=shape_enum,
        level=1,
        start_date=start_date,
        end_date=end_date,
    )
    logger.info("[microstructure] order-book rows: %d", len(df))
    dashboard_cache.set(key, df, ttl=ttl)
    return df


def fetch_activity(
    zone: str = "France",
    shape: str = "Baseload",
    start_date: datetime | None = None,
    end_date: datetime | None = None,
    force_refresh: bool = False,
    commodity: str = "Power",
) -> pd.DataFrame:
    """Fetch market activity counts."""
    if start_date is None:
        start_date = datetime.now() - timedelta(days=90)

    key = _cache_key(
        CACHE_PREFIX_ACTIVITY,
        commodity=commodity,
        zone=zone,
        shape=shape,
        start=start_date.strftime("%Y%m%d"),
        end=(end_date or datetime.now()).strftime("%Y%m%d"),
    )
    ttl = CACHE_TTL_ACTIVITY_LIVE if _is_live(end_date) else CACHE_TTL_ACTIVITY_HISTORICAL

    if not force_refresh:
        cached = dashboard_cache.get(key, ttl=ttl)
        if cached is not None:
            return cached

    handle = _bootstrap_trayport()
    commodity_enum, zone_enum, shape_enum = _resolve(handle, commodity, zone, shape)

    logger.info("[microstructure] fetching %s %s %s activity", commodity, zone, shape)
    tq = handle["TrayportQuery"]()
    df = tq.get_activity(
        commodity=commodity_enum,
        zone=zone_enum,
        shape=shape_enum,
        start_date=start_date,
        end_date=end_date,
    )
    logger.info("[microstructure] activity rows: %d", len(df))
    dashboard_cache.set(key, df, ttl=ttl)
    return df


# ---------------------------------------------------------------------------
# Tenor → expiry-date metadata
# ---------------------------------------------------------------------------


def fetch_tenor_metadata(
    zone: str = "France",
    shape: str = "Baseload",
    force_refresh: bool = False,
    commodity: str = "Power",
) -> dict[str, dict[str, Any]]:
    """Return ``{TENOR_NAME: {start, end, family}}`` for the given zone / shape.

    "Expiry" is taken as the end of the delivery period (PERIOD_END).
    The mapping is essentially static, so we cache it on disk for a day.
    """
    from .constants import CACHE_PREFIX_EXPIRY, CACHE_TTL_EXPIRY

    # ``v2`` suffix invalidates the legacy ``{TENOR_NAME: Timestamp}`` cache
    # that was written by the old ``fetch_tenor_expiry`` implementation.
    key = _cache_key(CACHE_PREFIX_EXPIRY, commodity=commodity, zone=zone, shape=shape, v="v2")
    if not force_refresh:
        cached = dashboard_cache.get(key, ttl=CACHE_TTL_EXPIRY)
        # Defensive shape check — if the cache contains the legacy flat
        # mapping, ignore it and re-fetch.
        if (
            isinstance(cached, dict)
            and cached
            and isinstance(next(iter(cached.values())), dict)
        ):
            return cached

    handle = _bootstrap_trayport()
    try:
        commodity_enum, zone_enum, shape_enum = _resolve(handle, commodity, zone, shape)
    except ValueError:
        return {}

    logger.info("[microstructure] fetching tenor metadata for %s %s %s", commodity, zone, shape)
    try:
        tq = handle["TrayportQuery"]()
        df = tq.get_tenor_metadata(
            commodity=commodity_enum,
            zone=zone_enum,
            shape=shape_enum,
            tenors=handle["ALL_TENORS"],
        )
    except Exception as exc:
        logger.warning("[microstructure] metadata fetch failed (%s)", exc)
        return {}

    if df.empty:
        return {}

    df.columns = [c.upper() for c in df.columns]
    mapping = {}
    for row in df.itertuples(index=False):
        # row: (TENOR_NAME, TENOR_FAMILY, PERIOD_START, PERIOD_END)
        mapping[str(row.TENOR_NAME)] = {
            "family": str(row.TENOR_FAMILY),
            "start": pd.to_datetime(row.PERIOD_START).tz_localize(None) if pd.notna(row.PERIOD_START) else None,
            "end": pd.to_datetime(row.PERIOD_END).tz_localize(None) if pd.notna(row.PERIOD_END) else None,
        }

    dashboard_cache.set(key, mapping, ttl=CACHE_TTL_EXPIRY)
    return mapping


# ---------------------------------------------------------------------------
# Cleaning
# ---------------------------------------------------------------------------


def clean_trades(df: pd.DataFrame, include_spreads: bool = False) -> pd.DataFrame:
    """Filter, remove mistrades, add derived columns.

    Mistrade removal uses a built-in 15-min rolling-window outlier filter
    (n_sigma=3.5 OR pct change > 10%) per tenor.  This avoids the previous
    dependency on the external ``systematic`` repo, which is not available on
    the dashboard server.
    """
    if df.empty:
        return df

    n_raw = len(df)

    if not include_spreads and "CONTRACT_TYPE" in df.columns:
        df = df[df["CONTRACT_TYPE"] == "SinglePeriod"].copy()

    df = df.dropna(subset=["PRICE"])
    df = df[df["QUANTITY"] > 0]
    if "AGGRESSOR_BUY" in df.columns:
        df = df.dropna(subset=["AGGRESSOR_BUY"])

    utc_ts = pd.to_datetime(df["DEAL_TIME_UTC"], utc=True)
    df["DEAL_TIME_UK"] = utc_ts.dt.tz_convert("Europe/London")

    try:
        df = _remove_mistrades_inplace(
            df,
            price_col="PRICE",
            time_col="DEAL_TIME_UK",
            group_cols=[c for c in ["TENOR_NAME"] if c in df.columns],
            window_min=15,
            n_sigma=3.5,
            pct_threshold=0.10,
        )
    except Exception as exc:
        logger.warning(
            "[microstructure] mistrade filter failed (%s); keeping all trades", exc,
        )

    df["trade_date"] = pd.to_datetime(df["DEAL_TIME_UK"]).dt.normalize().dt.tz_localize(None)
    df["signed_qty"] = np.where(
        df["AGGRESSOR_BUY"].astype(bool), -df["QUANTITY"], df["QUANTITY"]
    )
    df["dollar_volume"] = df["PRICE"] * df["QUANTITY"]

    if "MARKET_NAME" in df.columns:
        df["product_type"] = np.where(
            df["MARKET_NAME"].str.upper().str.startswith("EEX"), "Exchange", "OTC"
        )
    else:
        df["product_type"] = "Unknown"

    if "VENUE_CODE" in df.columns:
        eex_mask = df["VENUE_CODE"].str.upper() == "EEX7"
        df.loc[eex_mask, "product_type"] = "Exchange"

    df["venue_label"] = df["VENUE_CODE"].astype(str) + " [" + df["product_type"] + "]"

    deal_time = pd.to_datetime(df["DEAL_TIME_UK"])
    df["hour"] = deal_time.dt.hour
    df["weekday"] = deal_time.dt.dayofweek

    n_otc = (df["product_type"] == "OTC").sum()
    n_exc = (df["product_type"] == "Exchange").sum()
    logger.info(
        "[microstructure] cleaned %d trades (removed %d) | OTC=%d Exch=%d",
        len(df), n_raw - len(df), n_otc, n_exc,
    )
    return df


def _remove_mistrades_inplace(
    df: pd.DataFrame,
    *,
    price_col: str,
    time_col: str,
    group_cols: list[str] | None,
    window_min: int = 15,
    n_sigma: float = 3.5,
    pct_threshold: float = 0.10,
) -> pd.DataFrame:
    """Light, dependency-free port of ``systematic.data.cleaning.mistrades.remove_mistrades``.

    Within each ``group_cols`` partition (defaulting to the whole frame), keeps
    a row only if its price is within ``n_sigma`` standard deviations of the
    rolling mean of the surrounding ``window_min`` minutes **and** its
    percentage deviation from the rolling median is ≤ ``pct_threshold``.
    """
    if df.empty:
        return df

    keep_mask = pd.Series(True, index=df.index)

    def _filter_partition(part: pd.DataFrame) -> pd.Series:
        s = part.sort_values(time_col)[price_col].astype(float)
        ts = pd.to_datetime(part.sort_values(time_col)[time_col])
        s.index = ts
        rmean = s.rolling(f"{window_min}min", min_periods=3).mean()
        rstd = s.rolling(f"{window_min}min", min_periods=3).std()
        rmed = s.rolling(f"{window_min}min", min_periods=3).median()
        sigma_ok = (s - rmean).abs() <= n_sigma * rstd.replace(0, np.nan).fillna(s.std() or 1.0)
        pct_ok = ((s - rmed).abs() / rmed.replace(0, np.nan)) <= pct_threshold
        ok = sigma_ok.fillna(True) & pct_ok.fillna(True)
        ok.index = part.sort_values(time_col).index
        return ok.reindex(part.index, fill_value=True)

    if group_cols:
        for _, part in df.groupby(group_cols, sort=False):
            keep_mask.loc[part.index] = _filter_partition(part)
    else:
        keep_mask = _filter_partition(df)

    return df.loc[keep_mask].copy()


# ---------------------------------------------------------------------------
# Venue / tenor helpers
# ---------------------------------------------------------------------------


def get_all_venues(df: pd.DataFrame) -> list[str]:
    """Return sorted list of all venue labels (broker + market type)."""
    col = "venue_label" if "venue_label" in df.columns else "VENUE_CODE"
    return sorted(df[col].dropna().unique())


def get_tenor_names(df: pd.DataFrame) -> list[str]:
    """Return tenor names sorted by trade count (most active first)."""
    return df["TENOR_NAME"].value_counts().index.tolist()


# ---------------------------------------------------------------------------
# Cache cleanup -- enforce a per-prefix disk budget on top of DashboardCache's
# global cap.  Runs every CLEANUP_INTERVAL_HOURS from a daemon thread.
# ---------------------------------------------------------------------------


_PREFIXES = (
    f"{CACHE_PREFIX_TRADES}:",
    f"{CACHE_PREFIX_OB}:",
    f"{CACHE_PREFIX_ACTIVITY}:",
    "ms_expiry:",
)

_cleanup_thread: Optional[threading.Thread] = None
_cleanup_stop = threading.Event()


def cleanup_microstructure_cache(force_clear: bool = False) -> dict:
    """Enforce ``MAX_DISK_MB`` across all microstructure cache prefixes.

    Strategy
    --------
    1. Ask diskcache for an estimated total size (``volume()``).
    2. If we are under-budget *and* not ``force_clear``: only run the cheap
       expire pass (``DashboardCache._run_disk_maintenance`` already does this,
       but we trigger it explicitly so the next ``set`` doesn't have to).
    3. If we are over-budget, drop the **oldest** prefix entirely (trades →
       ob → activity in priority order) until we are back under budget.

    Returns a dict of stats useful for logging / monitoring.
    """
    disk = getattr(dashboard_cache, "_disk", None)
    if disk is None:
        return {"skipped": "no diskcache"}

    try:
        total_bytes = disk.volume()
    except Exception:
        total_bytes = 0
    budget = MAX_DISK_MB * 1024 * 1024

    # ── Count microstructure-only entries ────────────────────────────────
    ms_keys = [
        k for k in list(disk)
        if isinstance(k, str) and any(k.startswith(p) for p in _PREFIXES)
    ]
    stats = {
        "total_disk_bytes": total_bytes,
        "ms_keys": len(ms_keys),
        "budget_mb": MAX_DISK_MB,
        "force_clear": force_clear,
    }

    if force_clear:
        for prefix in _PREFIXES:
            dashboard_cache.clear(prefix=prefix.rstrip(":"))
        stats["action"] = "force_clear_all"
        logger.info("[microstructure] cache force-cleared (%s)", stats)
        return stats

    # Always do an expire pass first.  This silently removes entries whose
    # TTL has elapsed but which haven't yet been touched.
    try:
        n_expired = disk.expire()
        stats["expired"] = n_expired
    except Exception as exc:
        stats["expire_error"] = str(exc)

    # Only proceed to prefix-eviction if global cache is over budget.
    if total_bytes <= budget:
        stats["action"] = "ok_within_budget"
        return stats

    # Over-budget: drop trades / ob / activity in that order until we fit.
    for prefix in _PREFIXES:
        if total_bytes <= budget:
            break
        try:
            dashboard_cache.clear(prefix=prefix.rstrip(":"))
            new_total = disk.volume()
            stats[f"cleared_{prefix.rstrip(':')}"] = total_bytes - new_total
            total_bytes = new_total
        except Exception as exc:
            stats[f"clear_error_{prefix}"] = str(exc)

    stats["action"] = "evicted"
    stats["final_total_bytes"] = total_bytes
    logger.info("[microstructure] cache cleanup: %s", stats)
    return stats


def register_microstructure_cleanup_job() -> None:
    """Schedule :func:`cleanup_microstructure_cache` to run every N hours.

    Prefers the shared ``DashboardCache`` APScheduler (already started by
    ``portal_app.py``).  If APScheduler is unavailable, falls back to a
    daemon thread driven by :class:`threading.Event` so the job is still
    cancellable on shutdown.
    """
    global _cleanup_thread
    sched = getattr(dashboard_cache, "_sched", None)

    if sched is not None:
        try:
            from apscheduler.triggers.interval import IntervalTrigger  # type: ignore
            sched.add_job(
                cleanup_microstructure_cache,
                trigger=IntervalTrigger(hours=CLEANUP_INTERVAL_HOURS),
                id="microstructure_cache_cleanup",
                replace_existing=True,
            )
            logger.info(
                "[microstructure] cache cleanup scheduled every %dh (APScheduler)",
                CLEANUP_INTERVAL_HOURS,
            )
            return
        except Exception as exc:
            logger.warning("[microstructure] APScheduler unavailable: %s", exc)

    if _cleanup_thread is not None and _cleanup_thread.is_alive():
        return

    def _loop() -> None:
        interval_s = CLEANUP_INTERVAL_HOURS * 3600
        while not _cleanup_stop.wait(interval_s):
            try:
                cleanup_microstructure_cache()
            except Exception as exc:
                logger.exception("[microstructure] cleanup loop error: %s", exc)

    _cleanup_thread = threading.Thread(
        target=_loop, name="microstructure-cache-cleanup", daemon=True,
    )
    _cleanup_thread.start()
    logger.info(
        "[microstructure] cache cleanup running on daemon thread (every %dh)",
        CLEANUP_INTERVAL_HOURS,
    )


def stop_microstructure_cleanup_job() -> None:
    """Signal the daemon-thread cleanup loop to exit (best-effort)."""
    _cleanup_stop.set()
    if _cleanup_thread is not None:
        _cleanup_thread.join(timeout=1.0)
