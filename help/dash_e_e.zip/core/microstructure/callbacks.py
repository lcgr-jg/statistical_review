"""
Dash callbacks for the Trade Microstructure page.

Importing this module registers the callbacks via the global ``@callback``
decorator -- same pattern as ``core.heatmap_balance.callbacks``.

Server-side data store
----------------------
Snowflake DataFrames returned by :mod:`.data_pipeline` (often hundreds of
thousands of rows) are far too large to round-trip through a ``dcc.Store``.
Instead we keep the latest fetch in a module-level ``_DATA`` dict on the
server.  The Trayport result itself is also cached in ``DashboardCache`` (see
``data_pipeline``), so even if a worker process restarts the next ``Load``
click rehydrates from disk in milliseconds rather than re-querying Snowflake.

This is the same pattern the original adhoc dashboard used, but here the
underlying disk cache is bounded (TTL + size cap) so stale data cannot
accumulate.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

import dash_bootstrap_components as dbc
import pandas as pd
from dash import Input, Output, State, callback, dcc, html, no_update

from core.otc_levels.tab import build_otc_tab
from core.styles import COLORS

from . import figures as F
from . import pivot as P
from .constants import COMMODITY_ZONES, POWER_ZONES_LABELS, SHAPED_COMMODITIES
from .data_pipeline import (
    clean_trades,
    fetch_trades,
    get_all_venues,
    get_tenor_names,
)
from .signal_engine import build_daily_panel

try:  # PivotTable JS component (already in eu_dashboard_power deps).
    import dash_pivottable
except Exception:  # pragma: no cover -- defensive
    dash_pivottable = None

logger = logging.getLogger(__name__)

# Module-level data store (single-process; safe under waitress/gunicorn-sync).
_DATA: dict[str, pd.DataFrame] = {}

# Sentinel value used in the venue dropdown.  When selected it expands
# server-side to all venues whose ``product_type == "Exchange"``.
ALL_EXCHANGE_SENTINEL = "__ALL_EXCHANGE__"
ALL_EXCHANGE_LABEL = "All Exchange"


def _expand_venues(selected: list[str], df: pd.DataFrame) -> list[str]:
    """Resolve the ``All Exchange`` sentinel to the underlying venue labels.

    If the sentinel is in *selected*, it is replaced by every venue label
    whose ``product_type == "Exchange"`` in *df*.  Other selections are kept
    as-is and de-duplicated.
    """
    if not selected:
        return []
    out: list[str] = []
    seen: set[str] = set()
    for v in selected:
        if v == ALL_EXCHANGE_SENTINEL:
            if "product_type" in df.columns:
                exch_labels = (
                    df.loc[df["product_type"] == "Exchange", "venue_label"]
                    .dropna()
                    .unique()
                    .tolist()
                )
                for ev in sorted(exch_labels):
                    if ev not in seen:
                        out.append(ev)
                        seen.add(ev)
        elif v not in seen:
            out.append(v)
            seen.add(v)
    return out


def _venue_label_for_display(selected: list[str]) -> str:
    """Pretty broker-label string used in chart titles / KPIs."""
    if not selected:
        return ""
    if ALL_EXCHANGE_SENTINEL in selected:
        return ALL_EXCHANGE_LABEL
    if len(selected) <= 3:
        return ", ".join(selected)
    return f"{len(selected)} venues"


# ---------------------------------------------------------------------------
# KPI helpers
# ---------------------------------------------------------------------------


def _kpi(title: str, value: str) -> html.Div:
    return html.Div(
        style={"minWidth": "120px"},
        children=[
            html.Div(
                title,
                style={
                    "fontSize": "11px",
                    "fontWeight": "600",
                    "color": COLORS["text_muted"],
                    "textTransform": "uppercase",
                    "letterSpacing": "0.04em",
                },
            ),
            html.Div(
                value,
                style={
                    "fontSize": "16px",
                    "fontWeight": "600",
                    "color": COLORS["text_primary"],
                },
            ),
        ],
    )


def _no_data_message(msg: str) -> html.Div:
    return html.Div(
        msg,
        style={
            "padding": "24px",
            "textAlign": "center",
            "color": COLORS["text_muted"],
            "fontSize": "14px",
        },
    )


def _ctx_label(commodity: str | None, zone: str | None, shape: str | None, tenor: str) -> str:
    """Chart-title context string.  Shape is only meaningful for Power."""
    parts = [zone or ""]
    if (commodity in SHAPED_COMMODITIES) and shape:
        parts.append(shape)
    parts.append(tenor or "")
    return " ".join(p for p in parts if p).strip()


# ---------------------------------------------------------------------------
# Commodity → Market list / Shape availability
# ---------------------------------------------------------------------------


@callback(
    Output("ms-zone", "options"),
    Output("ms-zone", "value"),
    Output("ms-shape", "disabled"),
    Input("ms-commodity", "value"),
    prevent_initial_call=True,
)
def _update_markets(commodity):
    """Swap the Market dropdown to the selected commodity's hubs and disable the
    Shape control for Gas / Carbon (which have no Baseload/Peakload/Offpeak)."""
    zones = COMMODITY_ZONES.get(commodity, POWER_ZONES_LABELS)
    opts = [{"label": z, "value": z} for z in zones]
    value = zones[0] if zones else None
    shape_disabled = commodity not in SHAPED_COMMODITIES
    return opts, value, shape_disabled


# ---------------------------------------------------------------------------
# Refresh / Load Data
# ---------------------------------------------------------------------------


@callback(
    Output("ms-venues", "options"),
    Output("ms-venues", "value"),
    Output("ms-tenor", "options"),
    Output("ms-tenor", "value"),
    Output("ms-refresh-status", "children"),
    Output("ms-data-version", "data"),
    Input("ms-refresh", "n_clicks"),
    State("ms-commodity", "value"),
    State("ms-zone", "value"),
    State("ms-shape", "value"),
    State("ms-product", "value"),
    State("ms-date-range", "start_date"),
    State("ms-date-range", "end_date"),
    State("ms-data-version", "data"),
    prevent_initial_call=False,
)
def _refresh_data(n_clicks, commodity, zone, shape, product, start_str, end_str, data_version):
    start = (
        datetime.fromisoformat(start_str)
        if start_str
        else datetime.now() - timedelta(days=365)
    )
    end = datetime.fromisoformat(end_str) if end_str else datetime.now()
    if end.hour == 0 and end.minute == 0:
        end = end.replace(hour=23, minute=59, second=59)
    include_spreads = product == "spread"

    try:
        raw = fetch_trades(
            commodity=commodity, zone=zone, shape=shape,
            start_date=start, end_date=end,
            include_spreads=include_spreads,
            force_refresh=(n_clicks or 0) > 0,
        )
        df = clean_trades(raw, include_spreads=include_spreads)
        _DATA["trades"] = df
    except ImportError as exc:
        logger.error("[microstructure] missing data dependency: %s", exc)
        return [], [], [], None, f"Data backend unavailable: {exc}", no_update
    except Exception as exc:
        logger.exception("[microstructure] trade fetch failed: %s", exc)
        msg = str(exc)
        if len(msg) > 200:
            msg = msg[:200] + "…"
        return [], [], [], None, f"Error: {msg}", no_update

    if df.empty:
        return [], [], [], None, "No data", (data_version or 0) + 1

    venues = get_all_venues(df)
    venue_opts = [
        {"label": ALL_EXCHANGE_LABEL, "value": ALL_EXCHANGE_SENTINEL},
        *[{"label": v, "value": v} for v in venues],
    ]
    default_venues = [ALL_EXCHANGE_SENTINEL]

    tenors = get_tenor_names(df)
    tenor_opts = [{"label": t, "value": t} for t in tenors]
    default_tenor = tenors[0] if tenors else None

    n_otc = (df["product_type"] == "OTC").sum() if "product_type" in df.columns else 0
    n_exc = (df["product_type"] == "Exchange").sum() if "product_type" in df.columns else 0
    status = f"{len(df):,} trades  (OTC: {n_otc:,} | Exch: {n_exc:,})"

    return venue_opts, default_venues, tenor_opts, default_tenor, status, (data_version or 0) + 1


# ---------------------------------------------------------------------------
# Tab dispatcher (content + KPI strip)
# ---------------------------------------------------------------------------


@callback(
    Output("ms-tab-content", "children"),
    Output("ms-kpi-strip", "children"),
    Input("ms-tabs", "active_tab"),
    Input("ms-venues", "value"),
    Input("ms-tenor", "value"),
    Input("ms-data-version", "data"),
    State("ms-zone", "value"),
    State("ms-shape", "value"),
    State("ms-commodity", "value"),
    State("ms-date-range", "start_date"),
    State("ms-date-range", "end_date"),
)
def _render_tab(active_tab, venues, tenor, _data_version, zone, shape, commodity,
                start_date=None, end_date=None):
    if active_tab == "tab-otc":
        # OTC Levels has its own (cached) outright-tape fetch keyed on the
        # page's Market / Shape / Date range; it does not need venues / tenor.
        return build_otc_tab(zone, shape, commodity, start_date, end_date), []

    df = _DATA.get("trades", pd.DataFrame())
    if df.empty or not venues or not tenor:
        return _no_data_message("Click Load and select venues / tenor."), []

    broker_label = _venue_label_for_display(venues)
    venues = _expand_venues(venues, df)
    if not venues:
        return _no_data_message("No matching venues for this selection."), []

    compare = "all"
    panel = build_daily_panel(df, venues, tenor_name=tenor, comparison_mode=compare)
    if panel.empty:
        return _no_data_message("No panel data for this selection."), []

    ctx = _ctx_label(commodity, zone, shape, tenor)
    active_days = int((panel["broker_trade_count"] > 0).sum())
    total_days = len(panel)

    kpis = [
        _kpi("Trading Days", str(total_days)),
        _kpi("Active Days", f"{active_days} ({active_days / max(total_days, 1):.0%})"),
        _kpi("Selected Vol", f"{panel['broker_volume'].sum():,.0f} MW"),
        _kpi("Vol Share", f"{panel['broker_volume_share'].mean():.1%}"),
    ]

    content = _build_tab_content(active_tab, df, panel, venues, tenor,
                                 compare, ctx, broker_label, zone, shape, commodity)
    return content, kpis


def _build_tab_content(
    active_tab: str,
    df: pd.DataFrame,
    panel: pd.DataFrame,
    venues: list[str],
    tenor: str,
    compare: str,
    ctx: str,
    broker_label: str,
    zone: str | None = None,
    shape: str | None = None,
    commodity: str | None = None,
) -> Any:
    if active_tab == "tab-overview":
        all_venues = get_all_venues(df)
        return html.Div([
            dcc.Graph(figure=F.fig_overview(panel, broker_label, tenor, ctx=ctx),
                      config=F.CFG, className="mb-4"),
            dcc.Graph(figure=F.fig_venue_volume_stack(df, tenor, all_venues, ctx=ctx),
                      config=F.CFG),
        ])

    if active_tab == "tab-flow":
        return html.Div([
            dcc.Graph(figure=F.fig_cumul_flow_vs_vwap(panel, broker_label, ctx=ctx),
                      config=F.CFG, className="mb-4"),
            dcc.Graph(figure=F.fig_flow(panel, broker_label, tenor, ctx=ctx),
                      config=F.CFG, className="mb-4"),
            dcc.Graph(figure=F.fig_rolling_corr(panel, window=20, ctx=ctx),
                      config=F.CFG, className="mb-4"),
        ])

    if active_tab == "tab-intraday":
        vcol = "venue_label" if "venue_label" in df.columns else "VENUE_CODE"
        broker_trades = df[
            (df[vcol].isin(venues)) & (df["TENOR_NAME"] == tenor)
        ]
        active_dates = sorted(broker_trades["trade_date"].dropna().unique())
        if not active_dates:
            return _no_data_message("No venue trades for this tenor.")
        date_opts = [
            {"label": pd.Timestamp(d).strftime("%Y-%m-%d (%a)"),
             "value": str(pd.Timestamp(d).date())}
            for d in active_dates
        ]
        default_date = str(pd.Timestamp(active_dates[-1]).date())
        return html.Div([
            html.Div(
                style={
                    "display": "flex",
                    "alignItems": "flex-end",
                    "gap": "12px",
                    "marginBottom": "12px",
                    "maxWidth": "320px",
                },
                children=[
                    html.Div(
                        style={"flex": "1 1 auto"},
                        children=[
                            html.Div(
                                "Trade date",
                                style={
                                    "fontSize": "11px",
                                    "fontWeight": "600",
                                    "color": COLORS["text_secondary"],
                                    "marginBottom": "4px",
                                    "textTransform": "uppercase",
                                },
                            ),
                            dbc.Select(
                                id="ms-intraday-date",
                                options=date_opts,
                                value=default_date,
                                size="sm",
                            ),
                        ],
                    ),
                ],
            ),
            html.Div(id="ms-intraday-charts"),
        ])

    if active_tab == "tab-micro":
        return html.Div([
            dbc.Row([
                dbc.Col(dcc.Graph(
                    figure=F.fig_trade_size_dist(df, venues, tenor, ctx=ctx),
                    config=F.CFG,
                ), width=6),
                dbc.Col(dcc.Graph(
                    figure=F.fig_vwap_premium_by_venue(df, tenor, ctx=ctx),
                    config=F.CFG,
                ), width=6),
            ], className="mb-4"),
            dbc.Row([
                dbc.Col(dcc.Graph(
                    figure=F.fig_tod_heatmap(df, venues, tenor, ctx=ctx),
                    config=F.CFG,
                ), width=6),
                dbc.Col(dcc.Graph(
                    figure=F.fig_tod_volume_heatmap(df, venues, tenor, ctx=ctx),
                    config=F.CFG,
                ), width=6),
            ], className="mb-4"),
            dbc.Row([
                dbc.Col(dcc.Graph(
                    figure=F.fig_aggressor_ratio(df, tenor, ctx=ctx),
                    config=F.CFG,
                ), width=12),
            ], className="mb-4"),
            dcc.Graph(
                figure=F.fig_trade_clustering(df, venues, tenor, ctx=ctx),
                config=F.CFG,
                className="mb-4",
            ),
            dcc.Graph(
                figure=F.fig_volume_clustering(df, venues, tenor, ctx=ctx),
                config=F.CFG,
                className="mb-4",
            ),
            html.Hr(),
            dbc.Row([
                dbc.Col([
                    html.Div(
                        "Lookback (business days)",
                        style={
                            "fontSize": "11px",
                            "fontWeight": "600",
                            "color": COLORS["text_secondary"],
                            "marginBottom": "4px",
                            "textTransform": "uppercase",
                        },
                    ),
                    dcc.Input(
                        id="ms-intraday-pattern-n",
                        type="number", min=1, max=60, step=1, value=10,
                        className="form-control form-control-sm",
                        style={"width": "120px"},
                    ),
                ], width="auto"),
            ], className="mb-3"),
            html.Div(id="ms-intraday-pattern-container"),
        ])

    if active_tab == "tab-pivot":
        return _build_pivot_tab(df, zone, shape, commodity)

    return html.Div()


def _build_pivot_tab(
    df: pd.DataFrame,
    zone: str | None = None,
    shape: str | None = None,
    commodity: str | None = None,
) -> Any:
    """Render the trader-driven pivot table view."""
    if dash_pivottable is None:
        return _no_data_message(
            "dash_pivottable is not installed on this server."
        )

    # Look up tenor → expiry-date mapping (one cached Snowflake call per
    # zone/shape per day).  Falls back to {} on any failure, in which case
    # the pivot's tte_bucket stays "Unknown" — exactly the previous
    # behaviour, so the tab is still useful even if the metadata query
    # is unavailable.
    tenor_metadata: dict = {}
    if zone and (shape or commodity != "Power"):
        try:
            from .data_pipeline import fetch_tenor_metadata
            tenor_metadata = fetch_tenor_metadata(
                zone=zone, shape=shape or "Baseload", commodity=commodity or "Power",
            )
        except Exception as exc:
            logger.warning(
                "[microstructure pivot] metadata fetch failed (%s); "
                "tte_bucket will show 'Unknown'", exc,
            )

    try:
        data, n_rows = P.build_pivot_payload(df, tenor_metadata=tenor_metadata)
    except Exception as exc:  # pragma: no cover -- defensive
        logger.exception("[microstructure] pivot build failed: %s", exc)
        return _no_data_message(f"Pivot build failed: {exc}")

    cap_note = f"Showing {n_rows:,} trades"

    # Unique id forces React to remount when the underlying data changes,
    # otherwise the JS component keeps stale internal state.
    import uuid
    pivot_id = f"ms-pivot-{uuid.uuid4().hex[:8]}"

    # NB: ``Table Heatmap`` is *not* used as the default renderer.  Its
    # internal ``redColorScaleGenerator`` recurses unboundedly on large grids
    # and blows the browser's JS call stack.  Plain ``Table`` is safe at any
    # size; the user can switch to ``Table Heatmap`` / ``Table Col Heatmap``
    # via the renderer dropdown once they've narrowed the pivot dimensions.
    pivot = dash_pivottable.PivotTable(
        id=pivot_id,
        data=data,
        cols=["contract_type"],
        rows=["broker_group"],
        vals=["volume_mw"],
        aggregatorName="Sum",
        rendererName="Table",
    )

    return html.Div([
        html.Div(
            cap_note,
            style={
                "fontSize": "12px",
                "color": COLORS["text_secondary"],
                "marginBottom": "8px",
            },
        ),
        html.Div(
            "Drag fields between Rows / Columns / Values; switch aggregator "
            "(Sum, Mean, Median, Count) and renderer (Table, Heatmap, Bar, "
            "Line) from the dropdowns above the grid.  Heatmap renderers can "
            "stack-overflow on very wide grids — narrow the dimensions first.",
            style={
                "fontSize": "12px",
                "color": COLORS["text_secondary"],
                "marginBottom": "12px",
            },
        ),
        html.Div(
            children=[pivot],
            style={
                "padding": "12px",
                "background": COLORS.get("surface", "#fff"),
                "border": f"1px solid {COLORS.get('border', '#dee2e6')}",
                "borderRadius": "6px",
                "overflow": "auto",
            },
        ),
    ])


# ---------------------------------------------------------------------------
# Intraday sub-callbacks
# ---------------------------------------------------------------------------


@callback(
    Output("ms-intraday-charts", "children"),
    Input("ms-intraday-date", "value"),
    State("ms-venues", "value"),
    State("ms-tenor", "value"),
    State("ms-zone", "value"),
    State("ms-shape", "value"),
    State("ms-commodity", "value"),
    prevent_initial_call=False,
)
def _render_intraday(trade_date, venues, tenor, zone, shape, commodity):
    df = _DATA.get("trades", pd.DataFrame())
    if df.empty or not venues or not tenor or not trade_date:
        return no_update

    ctx = _ctx_label(commodity, zone, shape, tenor)
    broker_label = _venue_label_for_display(venues)
    venues = _expand_venues(venues, df)
    if not venues:
        return no_update

    vcol = "venue_label" if "venue_label" in df.columns else "VENUE_CODE"
    dt = pd.Timestamp(trade_date)
    day_trades = df[(df["trade_date"] == dt) & (df["TENOR_NAME"] == tenor)]
    broker_day = day_trades[day_trades[vcol].isin(venues)]
    n_total = len(day_trades)
    n_broker = len(broker_day)
    broker_vol = broker_day["QUANTITY"].sum()
    total_vol = day_trades["QUANTITY"].sum()
    net_flow = broker_day["signed_qty"].sum() if not broker_day.empty else 0
    vol_share = broker_vol / total_vol if total_vol > 0 else 0

    stats_row = html.Div(
        style={"display": "flex", "gap": "24px", "marginBottom": "16px"},
        children=[
            _kpi("Total Trades", f"{n_total:,}"),
            _kpi("Venue Trades", f"{n_broker:,}"),
            _kpi("Venue Volume", f"{broker_vol:,.0f} MW"),
            _kpi("Volume Share", f"{vol_share:.1%}"),
            _kpi("Net Flow", f"{net_flow:+,.0f} MW"),
        ],
    )

    return html.Div([
        stats_row,
        dcc.Graph(
            figure=F.fig_intraday(df, venues, tenor, trade_date, broker_label, ctx=ctx),
            config=F.CFG, className="mb-4",
        ),
        dcc.Graph(
            figure=F.fig_intraday_vwap_flow(df, venues, tenor, trade_date, broker_label, ctx=ctx),
            config=F.CFG, className="mb-4",
        ),
        dcc.Graph(
            figure=F.fig_intraday_volume_profile(df, venues, tenor, trade_date, broker_label, ctx=ctx),
            config=F.CFG,
        ),
    ])


@callback(
    Output("ms-intraday-pattern-container", "children"),
    Input("ms-intraday-pattern-n", "value"),
    State("ms-tenor", "value"),
    State("ms-zone", "value"),
    State("ms-shape", "value"),
    State("ms-commodity", "value"),
    prevent_initial_call=False,
)
def _render_intraday_pattern(n_days, tenor, zone, shape, commodity):
    df = _DATA.get("trades", pd.DataFrame())
    if df.empty or not tenor:
        return no_update

    n_days = int(n_days or 10)
    ctx = _ctx_label(commodity, zone, shape, tenor)
    return dcc.Graph(
        figure=F.fig_intraday_pattern(df, tenor, n_days=n_days, ctx=ctx),
        config=F.CFG,
    )
