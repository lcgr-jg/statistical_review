"""Static configuration for the Trade Microstructure dashboard.

These values are deliberately import-safe (no Snowflake / Trayport dependency)
so :mod:`core.microstructure.signal_engine` and the Dash layout/callback
modules can use them without dragging the heavy data layer along.
"""
from __future__ import annotations

# ── Page registration ────────────────────────────────────────────────────────
PAGE_PATH = "/power/microstructure"
PAGE_NAME = "Trade Data"
PAGE_TITLE = "Trade Data | JG Power Dashboard"
PAGE_ORDER = 21  # appears after Flows (20)

# ── UI option lists (string labels — actual Trayport enums looked up lazily
#    in data_pipeline.POWER_ZONES / SHAPES / TENORS) ──────────────────────────
POWER_ZONES_LABELS: list[str] = [
    "Germany", "France", "Spain", "Italy", "Belgium", "UK", "Nordic",
    "Austria", "Holland", "Swiss", "Czech", "Hungary", "Denmark",
    "Finland", "Sweden", "Greece", "Romania", "Slovakia", "Slovenia",
    "Croatia", "Bulgaria",
]
SHAPE_LABELS: list[str] = ["Baseload", "Peakload", "Offpeak"]

# Commodity selector — Power (default), Gas, Carbon.  Gas / Carbon hubs do not
# use a Baseload/Peakload/Offpeak shape (the Trayport query ignores shape for
# them — see ``trayportquery._build_where_clause``), so the Shape control is
# disabled when one of those is selected.
COMMODITY_LABELS: list[str] = ["Power", "Gas", "Carbon"]

# Gas hubs / carbon instruments exposed in the Market dropdown.  Every label
# here must have a matching entry in ``data_pipeline._bootstrap_trayport`` →
# ``ZONES`` so it resolves to a ``TrayportZone`` enum.
GAS_ZONES_LABELS: list[str] = [
    "TTF", "THE", "NBP", "PEG", "PSV", "ZTP", "CEGH VTP", "PVB",
]
CARBON_ZONES_LABELS: list[str] = ["EUA", "UKA"]

# Commodity → market-label list consumed by the layout / commodity callback.
COMMODITY_ZONES: dict[str, list[str]] = {
    "Power": POWER_ZONES_LABELS,
    "Gas": GAS_ZONES_LABELS,
    "Carbon": CARBON_ZONES_LABELS,
}

# Only these commodities use the Shape (Baseload/Peakload/Offpeak) control.
SHAPED_COMMODITIES: frozenset[str] = frozenset({"Power"})

# Forward-return horizons exposed in the Signal Analysis tab
FORWARD_HORIZONS = [1, 2, 5, 10]

# Venue codes that are always classified as "Exchange" (used by signal_engine
# so it does not need to import data_pipeline → keeps it pure / cheap to test).
EXCHANGE_VENUES = frozenset({"EEX7"})

# ── Cache parameters ─────────────────────────────────────────────────────────
# All caches are stored in the shared ``DashboardCache`` (TTL-bound, with a
# global disk size cap and LRU eviction).  TTLs are short on the live edge
# (when ``end_date`` includes today) and longer for fully-historical pulls.
CACHE_PREFIX_TRADES = "ms_trades"
CACHE_PREFIX_OB = "ms_orderbook"
CACHE_PREFIX_ACTIVITY = "ms_activity"
CACHE_PREFIX_PANEL = "ms_panel"  # signal-engine daily panel
CACHE_PREFIX_FIG = "ms_fig"      # serialised figures
CACHE_PREFIX_EXPIRY = "ms_expiry"  # tenor → expiry-date mapping

# TTLs in seconds.  ``_LIVE`` applies when end_date is today.
CACHE_TTL_TRADES_HISTORICAL = 12 * 3600   # 12h
CACHE_TTL_TRADES_LIVE = 15 * 60           # 15min
CACHE_TTL_OB_HISTORICAL = 6 * 3600
CACHE_TTL_OB_LIVE = 15 * 60
CACHE_TTL_ACTIVITY_HISTORICAL = 6 * 3600
CACHE_TTL_ACTIVITY_LIVE = 15 * 60
CACHE_TTL_PANEL = 30 * 60                 # 30min
CACHE_TTL_FIG = 30 * 60
# Tenor expiry metadata is essentially static (only changes when new contracts
# are listed), so we cache it for a full day.
CACHE_TTL_EXPIRY = 24 * 3600

# Microstructure-specific disk-size budget (MB).  The shared dashboard cache
# enforces a global cap, but we additionally run a per-prefix cleanup so a
# runaway query history (many venue/shape/date combinations) cannot starve
# the rest of the dashboard.  See ``data_pipeline.cleanup_microstructure_cache``.
MAX_DISK_MB = 1024  # 1 GB total across all microstructure prefixes
CLEANUP_INTERVAL_HOURS = 6  # how often the background cleaner runs
