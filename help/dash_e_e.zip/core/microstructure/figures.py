"""
Figure Builders -- light theme for the eu_dashboard_power portal.

Pure functions: ``(DataFrame, options) -> go.Figure``.

Ported from ``adhoc/trade_data/microstructure_dashboard/figures.py`` but
re-themed for the light dashboard:

* ``DARK = "plotly_dark"`` is replaced with the registered ``"dashboard"``
  Plotly template (see :mod:`core.theme`).  The template makes the paper /
  plot backgrounds white-ish, text dark, and grids light grey -- so plotting
  this on the light dashboard looks native instead of jet-black.
* The "other trades" / threshold grey ``#555`` (which was for dark mode) is
  swapped to ``#9aa1a8`` (visible on white) and the dashed white "Mean" line
  in :func:`fig_intraday_pattern` becomes dark grey.
* :func:`df_to_table` now produces a light Bootstrap table.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats as sp_stats

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.theme import PLOTLY_TEMPLATE_NAME

from .signal_engine import SIGNAL_COLS, FORWARD_HORIZONS  # noqa: F401  (re-exported)

VCOL = "venue_label"

# Use the global "dashboard" template.  All update_layout calls below pass
# ``template=DARK`` for backward-compat with the original code; the value
# really points at the light theme now.
DARK = PLOTLY_TEMPLATE_NAME

# Distinct chart colours that work on a light background.
GRN = "#26a69a"
RED = "#ef5350"
ORG = "#ff7043"
YLW = "#f5b042"   # darker yellow than the dark-mode original (#ffca28) so it stays readable on white
BLU = "#42a5f5"
PRP = "#ab47bc"

# Light-theme replacement for the various ``"#555"`` greys used as "other / neutral".
NEUTRAL = "#9aa1a8"

# Dark colour used where the original drew a dashed white line (mean overlay).
MEAN_DARK = "#212529"

# Marker outline contrast colour: white on dark theme, near-white on light theme
# is fine for tiny markers but a thin dark hairline reads better on a light bg.
MARKER_OUTLINE = "#212529"

_VENUE_PALETTE = [
    GRN, ORG, BLU, PRP, YLW, RED,
    "#78909c", "#8d6e63", "#66bb6a", "#ec407a", "#5c6bc0", "#29b6f6",
]


def _vc(idx: int) -> str:
    return _VENUE_PALETTE[idx % len(_VENUE_PALETTE)]


CFG = {"displaylogo": False}


def _t(ctx: str, subtitle: str) -> str:
    """Build a consistent title: 'France Baseload Jun-26 | subtitle'."""
    return f"{ctx} | {subtitle}" if ctx else subtitle


def empty_fig(msg: str = "No data") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=msg, showarrow=False, font=dict(size=16, color="#888"),
        xref="paper", yref="paper", x=0.5, y=0.5,
    )
    fig.update_layout(template=DARK, height=400)
    return fig


# ===================================================================
# 1  Overview
# ===================================================================


def fig_overview(panel: pd.DataFrame, broker_label: str, tenor: str,
                 ctx: str = "") -> go.Figure:
    if panel.empty:
        return empty_fig()
    fig = make_subplots(
        rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.08,
        row_heights=[0.65, 0.35],
        subplot_titles=[_t(ctx, "Market VWAP"), _t(ctx, f"{broker_label} Volume (MW)")],
    )
    fig.add_trace(go.Scatter(
        x=panel.index, y=panel["market_vwap"], mode="lines",
        name="Market VWAP", line=dict(width=1.5, color=GRN),
    ), row=1, col=1)

    colors = np.where(panel["broker_net_flow"] >= 0, GRN, RED)
    fig.add_trace(go.Bar(
        x=panel.index, y=panel["broker_volume"],
        name=f"{broker_label} Vol", marker_color=colors, opacity=0.85,
    ), row=2, col=1)

    fig.update_layout(
        template=DARK, height=620, showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.15,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
        margin=dict(t=80, b=120, l=60, r=30),
    )
    fig.update_yaxes(title_text="EUR/MWh", row=1, col=1)
    fig.update_yaxes(title_text="MW", row=2, col=1)
    return fig


def fig_venue_volume_stack(
    df: pd.DataFrame, tenor: str, venues: list[str],
    ctx: str = "",
) -> go.Figure:
    """Daily volume stacked by venue."""
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    if sub.empty:
        return empty_fig()
    fig = go.Figure()
    for i, vc in enumerate(venues):
        daily = sub[sub[VCOL] == vc].groupby("trade_date")["QUANTITY"].sum()
        fig.add_trace(go.Bar(
            x=daily.index, y=daily.values, name=vc,
            marker_color=_vc(i), opacity=0.85,
        ))
    fig.update_layout(
        template=DARK, height=600, barmode="stack",
        title=dict(text=_t(ctx, "Daily Volume by Venue"), y=0.98),
        margin=dict(t=60, b=120, l=60, r=30),
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.15,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
    )
    fig.update_yaxes(title_text="MW")
    return fig


# ===================================================================
# 2  Flow Analysis
# ===================================================================


def fig_flow(panel: pd.DataFrame, broker_label: str, tenor: str,
             ctx: str = "") -> go.Figure:
    if panel.empty:
        return empty_fig()
    fig = make_subplots(
        rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.08,
        row_heights=[0.35, 0.35, 0.30],
        subplot_titles=[
            _t(ctx, "Market VWAP"),
            _t(ctx, f"{broker_label} Net Initiator Flow (MW)"),
            _t(ctx, f"{broker_label} Volume Share (%)"),
        ],
    )
    fig.add_trace(go.Scatter(
        x=panel.index, y=panel["market_vwap"], name="VWAP",
        line=dict(width=1.5, color=GRN),
    ), row=1, col=1)

    cumul = panel["broker_net_flow"].cumsum()
    fig.add_trace(go.Scatter(
        x=panel.index, y=cumul, name="Cumul. Flow",
        line=dict(width=1, color=YLW, dash="dot"),
    ), row=1, col=1)

    colors = np.where(panel["broker_net_flow"] >= 0, GRN, RED)
    fig.add_trace(go.Bar(
        x=panel.index, y=panel["broker_net_flow"],
        name="Daily Net Flow", marker_color=colors, opacity=0.85,
    ), row=2, col=1)

    fig.add_trace(go.Bar(
        x=panel.index, y=panel["broker_volume_share"] * 100,
        name="Vol Share", marker_color=ORG, opacity=0.7,
    ), row=3, col=1)

    fig.update_layout(
        template=DARK, height=780, showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.12,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
        margin=dict(t=80, b=120, l=60, r=30),
    )
    fig.update_yaxes(title_text="EUR/MWh", row=1, col=1)
    fig.update_yaxes(
        title_text="Daily Net Flow (MW)<br><sup>+ve = aggressor selling, −ve = aggressor buying</sup>",
        row=2, col=1,
    )
    fig.update_yaxes(title_text="Volume Share (%)", row=3, col=1)
    return fig


def fig_cumul_flow_vs_vwap(panel: pd.DataFrame, broker_label: str,
                           ctx: str = "") -> go.Figure:
    if panel.empty:
        return empty_fig()
    cumul = panel["broker_net_flow"].cumsum()
    fig = make_subplots(
        rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.12,
        row_heights=[0.5, 0.5],
        subplot_titles=[
            _t(ctx, f"Cumulative Net Initiator Flow -- {broker_label}"),
            _t(ctx, "Market VWAP (all venues)"),
        ],
    )
    fig.add_trace(go.Scatter(
        x=panel.index, y=cumul, name="Cumul. Flow",
        fill="tozeroy", line=dict(width=1.5, color=GRN),
    ), row=1, col=1)
    fig.add_trace(go.Scatter(
        x=panel.index, y=panel["market_vwap"], name="VWAP",
        line=dict(width=1.5, color=ORG),
    ), row=2, col=1)
    fig.update_yaxes(
        title_text="Cumul. Net Flow (MW)<br><sup>+ve = net aggressor selling, −ve = net aggressor buying</sup>",
        row=1, col=1,
    )
    fig.update_yaxes(title_text="EUR/MWh", row=2, col=1)
    fig.update_layout(
        template=DARK, height=620, margin=dict(t=70, b=120, l=60, r=30),
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.15,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
    )
    return fig


def fig_broker_breakdown(
    df: pd.DataFrame, brokers: list[str], tenor: str,
    ctx: str = "",
) -> go.Figure:
    fig = go.Figure()
    for i, vc in enumerate(brokers):
        sub = df[(df[VCOL] == vc) & (df["TENOR_NAME"] == tenor)]
        daily = sub.groupby("trade_date")["QUANTITY"].sum()
        fig.add_trace(go.Bar(
            x=daily.index, y=daily.values, name=vc,
            marker_color=_vc(i), opacity=0.8,
        ))
    fig.update_layout(
        template=DARK, height=420, barmode="stack",
        title=_t(ctx, "Daily Volume by Selected Venue"), margin=dict(t=60, b=40, l=60, r=30),
    )
    return fig


def fig_rolling_corr(
    panel: pd.DataFrame, window: int = 20,
    ctx: str = "",
) -> go.Figure:
    """Rolling correlation between daily net flow and daily price change."""
    if panel.empty or len(panel) < window:
        return empty_fig("Insufficient data for rolling correlation")
    price_chg = panel["market_vwap"].pct_change()
    rolling_rho = panel["broker_net_flow"].rolling(window).corr(price_chg)
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=panel.index, y=rolling_rho, mode="lines",
        name=f"{window}d Rolling Corr", line=dict(width=1.5, color=BLU),
    ))
    fig.add_hline(y=0, line_dash="dash", line_color=NEUTRAL)
    fig.update_layout(
        template=DARK, height=370,
        title=_t(ctx, f"Rolling {window}d Corr: Net Flow vs Price Change"),
        margin=dict(t=60, b=40, l=60, r=30), yaxis_title="Pearson r",
    )
    return fig


# ===================================================================
# 3  Intraday
# ===================================================================


def fig_intraday(
    df: pd.DataFrame, selected_venues: list[str],
    tenor_name: str, trade_date: str, broker_label: str,
    ctx: str = "",
) -> go.Figure:
    dt = pd.Timestamp(trade_date)
    day_df = df[
        (df["trade_date"] == dt) & (df["TENOR_NAME"] == tenor_name)
    ].sort_values("DEAL_TIME_UK").copy()
    if day_df.empty:
        return empty_fig(f"No trades on {trade_date}")

    day_df["time"] = pd.to_datetime(day_df["DEAL_TIME_UK"]).dt.tz_localize(None)
    is_broker = day_df[VCOL].isin(selected_venues)
    broker_trades = day_df[is_broker]
    other_trades = day_df[~is_broker]

    broker_cumvol = broker_trades["signed_qty"].cumsum()
    broker_absvol = broker_trades["QUANTITY"].cumsum()

    fig = make_subplots(
        rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.08,
        row_heights=[0.45, 0.30, 0.25],
        subplot_titles=[
            _t(ctx, f"Trades on {trade_date}"),
            _t(ctx, f"Cumulative {broker_label} Volume (MW)"),
            _t(ctx, f"Cumulative {broker_label} Net Flow (MW)"),
        ],
    )

    fig.add_trace(go.Scatter(
        x=other_trades["time"], y=other_trades["PRICE"],
        mode="markers", name="Other trades",
        marker=dict(size=3, color=NEUTRAL, opacity=0.5),
    ), row=1, col=1)

    bc = np.where(broker_trades["AGGRESSOR_BUY"].astype(bool), RED, GRN)
    fig.add_trace(go.Scatter(
        x=broker_trades["time"], y=broker_trades["PRICE"],
        mode="markers", name=f"{broker_label} trades",
        marker=dict(size=7, color=bc, opacity=0.95,
                    line=dict(width=0.5, color=MARKER_OUTLINE)),
    ), row=1, col=1)

    if not broker_absvol.empty:
        fig.add_trace(go.Scatter(
            x=broker_trades["time"], y=broker_absvol.values,
            mode="lines", name="Cumul. Volume",
            line=dict(width=2, color=ORG, shape="hv"),
            fill="tozeroy", fillcolor="rgba(255,112,67,0.15)",
        ), row=2, col=1)

    if not broker_cumvol.empty:
        fig.add_trace(go.Scatter(
            x=broker_trades["time"], y=broker_cumvol.values,
            mode="lines", name="Cumul. Net Flow",
            line=dict(width=2, color=GRN, shape="hv"), fill="tozeroy",
        ), row=3, col=1)
        fig.add_hline(y=0, line_dash="dash", line_color=NEUTRAL, row=3, col=1)

    fig.update_layout(
        template=DARK, height=820, margin=dict(t=70, b=120, l=60, r=30),
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.08,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
    )
    fig.update_yaxes(title_text="EUR/MWh", row=1, col=1)
    fig.update_yaxes(title_text="MW", row=2, col=1)
    fig.update_yaxes(title_text="MW", row=3, col=1)
    return fig


def fig_intraday_vwap_flow(
    df: pd.DataFrame, selected_venues: list[str],
    tenor_name: str, trade_date: str, broker_label: str,
    ctx: str = "",
) -> go.Figure:
    dt = pd.Timestamp(trade_date)
    day_df = df[
        (df["trade_date"] == dt) & (df["TENOR_NAME"] == tenor_name)
    ].sort_values("DEAL_TIME_UK").copy()
    if day_df.empty:
        return empty_fig(f"No trades on {trade_date}")

    day_df["time"] = pd.to_datetime(day_df["DEAL_TIME_UK"]).dt.tz_localize(None)
    day_df = day_df.set_index("time").sort_index()
    dv = (day_df["PRICE"] * day_df["QUANTITY"]).rolling("1h").sum()
    qr = day_df["QUANTITY"].rolling("1h").sum()
    day_df["rolling_vwap"] = dv / qr.replace(0, np.nan)

    is_broker = day_df[VCOL].isin(selected_venues)
    broker_df = day_df[is_broker].copy()
    broker_df["cumul_net"] = broker_df["signed_qty"].cumsum()

    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Scatter(
        x=day_df.index, y=day_df["rolling_vwap"],
        mode="lines", name="1h Rolling VWAP (all trades)",
        line=dict(width=1.5, color=GRN),
    ), secondary_y=False)

    if not broker_df.empty:
        fig.add_trace(go.Scatter(
            x=broker_df.index, y=broker_df["cumul_net"],
            mode="lines", name=f"{broker_label} Cumul. Net Flow",
            line=dict(width=2, color=ORG, shape="hv"),
        ), secondary_y=True)

    fig.update_layout(
        template=DARK, height=480, margin=dict(t=60, b=120, l=60, r=30),
        title=_t(ctx, f"1h Rolling VWAP (all trades) vs {broker_label} Cumul. Flow -- {trade_date}"),
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
    )
    fig.update_yaxes(title_text="EUR/MWh", secondary_y=False)
    fig.update_yaxes(title_text="Cumul. MW", secondary_y=True)
    return fig


def fig_intraday_volume_profile(
    df: pd.DataFrame, selected_venues: list[str],
    tenor_name: str, trade_date: str, broker_label: str,
    ctx: str = "",
) -> go.Figure:
    """Volume histogram by 30-min bucket, split selected vs rest."""
    dt = pd.Timestamp(trade_date)
    day_df = df[
        (df["trade_date"] == dt) & (df["TENOR_NAME"] == tenor_name)
    ].copy()
    if day_df.empty:
        return empty_fig("No trades")

    deal_time = pd.to_datetime(day_df["DEAL_TIME_UK"])
    day_df["bucket"] = deal_time.dt.floor("30min").dt.strftime("%H:%M")
    day_df["is_sel"] = day_df[VCOL].isin(selected_venues)

    sel_vol = day_df[day_df["is_sel"]].groupby("bucket")["QUANTITY"].sum()
    oth_vol = day_df[~day_df["is_sel"]].groupby("bucket")["QUANTITY"].sum()

    buckets = sorted(set(sel_vol.index) | set(oth_vol.index))
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=buckets, y=[oth_vol.get(b, 0) for b in buckets],
        name="Other", marker_color=NEUTRAL, opacity=0.7,
    ))
    fig.add_trace(go.Bar(
        x=buckets, y=[sel_vol.get(b, 0) for b in buckets],
        name=broker_label, marker_color=GRN, opacity=0.85,
    ))
    fig.update_layout(
        template=DARK, height=380, barmode="stack",
        title=_t(ctx, f"Intraday Volume Profile (30min) -- {trade_date}"),
        margin=dict(t=60, b=40, l=60, r=30),
        xaxis_title="Time", yaxis_title="MW",
    )
    return fig


# ===================================================================
# 4  Microstructure
# ===================================================================


def fig_trade_size_dist(
    df: pd.DataFrame, selected_venues: list[str], tenor: str,
    ctx: str = "",
) -> go.Figure:
    """Trade-size distribution coloured by venue.

    Renders one histogram per **Exchange** venue plus an aggregate ``All``
    histogram (every trade in the tenor, regardless of venue).  ``selected_venues``
    is no longer used to split selected-vs-other; the chart is venue-comparative.
    """
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    if sub.empty:
        return empty_fig()

    fig = go.Figure()

    # ── 1) "All" full distribution (in neutral grey, behind everything) ──
    fig.add_trace(go.Histogram(
        x=sub["QUANTITY"], name="All", marker_color=NEUTRAL,
        opacity=0.55, nbinsx=50,
    ))

    # ── 2) One trace per Exchange venue, coloured from the palette ──
    if "product_type" in sub.columns:
        exch = sub[sub["product_type"] == "Exchange"]
    else:
        exch = sub.iloc[0:0]

    exch_venues = sorted(exch[VCOL].dropna().unique().tolist()) if not exch.empty else []
    for i, vc in enumerate(exch_venues):
        v_qty = exch.loc[exch[VCOL] == vc, "QUANTITY"]
        if v_qty.empty:
            continue
        fig.add_trace(go.Histogram(
            x=v_qty, name=vc, marker_color=_vc(i),
            opacity=0.7, nbinsx=50,
        ))

    fig.update_layout(
        template=DARK, height=520, barmode="overlay",
        title=_t(ctx, "Trade Size Distribution by Venue (MW)"),
        margin=dict(t=60, b=120, l=60, r=30),
        xaxis_title="MW", yaxis_title="Count",
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
    )
    return fig


def fig_vwap_premium_by_venue(
    df: pd.DataFrame, tenor: str,
    ctx: str = "",
) -> go.Figure:
    """Bar chart: each venue's avg VWAP premium over market VWAP (EUR/MWh)."""
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    if sub.empty:
        return empty_fig()

    daily_mkt = sub.groupby("trade_date").apply(
        lambda g: (g["PRICE"] * g["QUANTITY"]).sum() / g["QUANTITY"].sum()
    ).rename("mkt_vwap")

    venues = sub[VCOL].dropna().unique()
    rows = []
    for vc in venues:
        vc_df = sub[sub[VCOL] == vc]
        daily_vc = vc_df.groupby("trade_date").apply(
            lambda g: (g["PRICE"] * g["QUANTITY"]).sum() / g["QUANTITY"].sum()
        ).rename("vc_vwap")
        merged = pd.concat([daily_mkt, daily_vc], axis=1).dropna()
        if merged.empty:
            continue
        prem = merged["vc_vwap"] - merged["mkt_vwap"]
        rows.append({"Venue": vc, "Premium": prem.mean(), "N": len(merged)})

    if not rows:
        return empty_fig()
    rdf = pd.DataFrame(rows).sort_values("Premium")
    colors = [GRN if v >= 0 else RED for v in rdf["Premium"]]
    fig = go.Figure(go.Bar(
        x=rdf["Venue"], y=rdf["Premium"],
        marker_color=colors, text=[f"{v:+.3f}" for v in rdf["Premium"]],
        textposition="outside",
    ))
    fig.update_layout(
        template=DARK, height=420,
        title=_t(ctx, "Avg VWAP Premium by Venue (EUR/MWh)"), margin=dict(t=60, b=40, l=60, r=30),
        yaxis_title="EUR/MWh",
    )
    return fig


def fig_tod_heatmap(
    df: pd.DataFrame, selected_venues: list[str], tenor: str,
    ctx: str = "",
) -> go.Figure:
    """Heatmap: trade count by hour-of-day vs day-of-week for selected venues."""
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    sub = sub[sub[VCOL].isin(selected_venues)]
    if sub.empty:
        return empty_fig("No selected-venue trades")

    pivot = sub.groupby(["weekday", "hour"])["PRICE"].count().unstack(fill_value=0)
    day_labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    for d in range(7):
        if d not in pivot.index:
            pivot.loc[d] = 0
    pivot = pivot.sort_index()

    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=[f"{h:02d}:00" for h in pivot.columns],
        y=[day_labels[i] for i in pivot.index],
        colorscale="Viridis", showscale=True,
    ))
    fig.update_layout(
        template=DARK, height=370,
        title=_t(ctx, "Trade Count: Hour vs Day-of-Week"), margin=dict(t=60, b=40, l=60, r=30),
    )
    return fig


def fig_tod_volume_heatmap(
    df: pd.DataFrame, selected_venues: list[str], tenor: str,
    ctx: str = "",
) -> go.Figure:
    """Heatmap: total traded volume (MW) by hour-of-day vs day-of-week."""
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    sub = sub[sub[VCOL].isin(selected_venues)]
    if sub.empty:
        return empty_fig("No selected-venue trades")

    pivot = (
        sub.groupby(["weekday", "hour"])["QUANTITY"].sum().unstack(fill_value=0)
    )
    day_labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    for d in range(7):
        if d not in pivot.index:
            pivot.loc[d] = 0
    pivot = pivot.sort_index()

    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=[f"{h:02d}:00" for h in pivot.columns],
        y=[day_labels[i] for i in pivot.index],
        colorscale="Viridis", showscale=True,
        colorbar=dict(title="MW"),
    ))
    fig.update_layout(
        template=DARK, height=370,
        title=_t(ctx, "Trade Volume: Hour vs Day-of-Week (MW)"),
        margin=dict(t=60, b=40, l=60, r=30),
    )
    return fig


def fig_trade_clustering(
    df: pd.DataFrame, selected_venues: list[str], tenor: str,
    ctx: str = "", n_days: int = 14,
) -> go.Figure:
    """Per-day rolling 15-min trade count, x = time-of-day, colour = trading day.

    Shows the last *n_days* trading days for the selected venues so bursts
    can be compared across days at the same wall-clock time.
    """
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    sel = sub[sub[VCOL].isin(selected_venues)].copy()
    if sel.empty:
        return empty_fig()

    sel["_dt"] = pd.to_datetime(sel["DEAL_TIME_UK"]).dt.tz_localize(None)
    sel = sel.dropna(subset=["_dt"]).sort_values("_dt")
    sel["_date"] = sel["_dt"].dt.normalize()

    all_days = sorted(sel["_date"].unique())
    days = all_days[-n_days:]
    actual_n = len(days)
    if actual_n == 0:
        return empty_fig("No trades in window")

    palette = (
        _VENUE_PALETTE * ((actual_n // len(_VENUE_PALETTE)) + 1)
    )[:actual_n]

    fig = go.Figure()
    for i, d in enumerate(days):
        day = sel[sel["_date"] == d]
        if day.empty:
            continue
        # 15-min fixed-bin trade count.
        s = day.set_index("_dt")["PRICE"].resample("15min").count()
        # Re-anchor x-axis to a common reference date so colours overlay by
        # time-of-day rather than wall-clock date.
        anchor = pd.Timestamp("2000-01-01")
        x_tod = anchor + (s.index - s.index.normalize())
        fig.add_trace(go.Scatter(
            x=x_tod, y=s.values, mode="lines+markers",
            name=pd.Timestamp(d).strftime("%Y-%m-%d (%a)"),
            line=dict(width=1.4, color=palette[i]),
            marker=dict(size=4),
            opacity=0.85,
        ))

    fig.update_layout(
        template=DARK, height=480,
        title=_t(ctx, f"Trade Clustering -- 15min bin count (last {actual_n} days)"),
        margin=dict(t=60, b=120, l=60, r=30),
        xaxis_title="Time of day",
        yaxis_title="Trades per 15min",
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
    )
    fig.update_xaxes(tickformat="%H:%M")
    return fig


def fig_volume_clustering(
    df: pd.DataFrame, selected_venues: list[str], tenor: str,
    ctx: str = "", n_days: int = 14,
) -> go.Figure:
    """Per-day fixed 15-min volume buckets, x = time-of-day, colour = trading day.

    Volume analogue of :func:`fig_trade_clustering`.  For each of the last
    *n_days* trading days, sums ``QUANTITY`` into 15-minute bins and overlays
    them on a common time-of-day axis.
    """
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    sel = sub[sub[VCOL].isin(selected_venues)].copy()
    if sel.empty:
        return empty_fig()

    sel["_dt"] = pd.to_datetime(sel["DEAL_TIME_UK"]).dt.tz_localize(None)
    sel = sel.dropna(subset=["_dt"]).sort_values("_dt")
    sel["_date"] = sel["_dt"].dt.normalize()

    all_days = sorted(sel["_date"].unique())
    days = all_days[-n_days:]
    actual_n = len(days)
    if actual_n == 0:
        return empty_fig("No trades in window")

    palette = (
        _VENUE_PALETTE * ((actual_n // len(_VENUE_PALETTE)) + 1)
    )[:actual_n]

    fig = go.Figure()
    for i, d in enumerate(days):
        day = sel[sel["_date"] == d]
        if day.empty:
            continue
        s = day.set_index("_dt")["QUANTITY"].resample("15min").sum()
        anchor = pd.Timestamp("2000-01-01")
        x_tod = anchor + (s.index - s.index.normalize())
        fig.add_trace(go.Scatter(
            x=x_tod, y=s.values, mode="lines+markers",
            name=pd.Timestamp(d).strftime("%Y-%m-%d (%a)"),
            line=dict(width=1.4, color=palette[i]),
            marker=dict(size=4),
            opacity=0.85,
        ))

    fig.update_layout(
        template=DARK, height=480,
        title=_t(ctx, f"Volume Clustering -- 15min bin volume (last {actual_n} days)"),
        margin=dict(t=60, b=120, l=60, r=30),
        xaxis_title="Time of day",
        yaxis_title="Volume per 15min (MW)",
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="center",
            x=0.5,
            font=dict(size=10),
        ),
    )
    fig.update_xaxes(tickformat="%H:%M")
    return fig


def fig_aggressor_ratio(df: pd.DataFrame, tenor: str,
                        ctx: str = "") -> go.Figure:
    """Per-venue aggressor buy ratio."""
    sub = df[df["TENOR_NAME"] == tenor] if tenor else df
    if sub.empty or "AGGRESSOR_BUY" not in sub.columns:
        return empty_fig()

    venues = sub[VCOL].dropna().unique()
    rows = []
    for vc in venues:
        vc_df = sub[sub[VCOL] == vc]
        n = len(vc_df)
        if n < 5:
            continue
        buy_pct = vc_df["AGGRESSOR_BUY"].astype(bool).mean() * 100
        rows.append({"Venue": vc, "Aggressor Buy %": buy_pct, "N": n})

    if not rows:
        return empty_fig()
    rdf = pd.DataFrame(rows).sort_values("Aggressor Buy %")
    colors = [GRN if v >= 50 else RED for v in rdf["Aggressor Buy %"]]
    fig = go.Figure(go.Bar(
        x=rdf["Venue"], y=rdf["Aggressor Buy %"],
        marker_color=colors,
        text=[f"{v:.1f}%" for v in rdf["Aggressor Buy %"]],
        textposition="outside",
    ))
    fig.add_hline(y=50, line_dash="dash", line_color=NEUTRAL)
    fig.update_layout(
        template=DARK, height=420,
        title=_t(ctx, "Aggressor Buy Ratio by Venue (%)"), margin=dict(t=60, b=40, l=60, r=30),
        yaxis_title="%", yaxis_range=[0, 100],
    )
    return fig


def fig_intraday_pattern(
    df: pd.DataFrame, tenor_name: str, n_days: int = 10,
    ctx: str = "",
) -> go.Figure:
    """Overlay of hourly VWAP delta from the first candle across last N days."""
    sub = df[df["TENOR_NAME"] == tenor_name] if tenor_name else df
    if sub.empty:
        return empty_fig("No trades for this tenor")

    all_dates = sorted(sub["trade_date"].dropna().unique())
    if not all_dates:
        return empty_fig("No trade dates")

    dates = all_dates[-n_days:]
    actual_n = len(dates)

    sub = sub[sub["trade_date"].isin(dates)].copy()
    deal_time = pd.to_datetime(sub["DEAL_TIME_UK"])
    sub["hour_bucket"] = deal_time.dt.floor("h")
    sub["hour_label"] = deal_time.dt.floor("h").dt.strftime("%H:%M")

    hourly = (
        sub.groupby(["trade_date", "hour_label"])
        .apply(
            lambda g: pd.Series({
                "vwap": (g["PRICE"] * g["QUANTITY"]).sum() / g["QUANTITY"].sum(),
            })
        )
        .reset_index()
    )

    fig = go.Figure()
    palette = (
        _VENUE_PALETTE * ((actual_n // len(_VENUE_PALETTE)) + 1)
    )[:actual_n]
    all_deltas = []

    for i, dt in enumerate(dates):
        day = hourly[hourly["trade_date"] == dt].sort_values("hour_label")
        if day.empty:
            continue
        first_vwap = day["vwap"].iloc[0]
        day = day.copy()
        day["delta"] = day["vwap"] - first_vwap
        date_str = pd.Timestamp(dt).strftime("%Y-%m-%d")
        fig.add_trace(go.Scatter(
            x=day["hour_label"],
            y=day["delta"],
            mode="lines+markers",
            name=date_str,
            line=dict(width=1.5, color=palette[i]),
            marker=dict(size=4),
            opacity=0.8,
        ))
        all_deltas.append(day[["hour_label", "delta"]])

    if all_deltas:
        combined = pd.concat(all_deltas)
        mean_delta = combined.groupby("hour_label")["delta"].mean().sort_index()
        fig.add_trace(go.Scatter(
            x=mean_delta.index,
            y=mean_delta.values,
            mode="lines+markers",
            name="Mean",
            line=dict(width=3, color=MEAN_DARK, dash="dash"),
            marker=dict(size=6, symbol="diamond"),
        ))

    sorted_hours = sorted(hourly["hour_label"].unique())
    fig.update_layout(
        template=DARK, height=550,
        title=_t(ctx, f"Intraday VWAP Pattern (last {actual_n} days)"),
        margin=dict(t=60, b=120, l=60, r=30),
        xaxis_title="Time of Day",
        xaxis_categoryorder="array",
        xaxis_categoryarray=sorted_hours,
        yaxis_title="VWAP Delta from First Candle (EUR/MWh)",
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            xanchor="center",
            x=0.5,
            font=dict(size=9),
        ),
    )
    return fig


# ===================================================================
# 5  Order Book
# ===================================================================


def fig_ob_spread(ob_df: pd.DataFrame, tenor: str | None,
                  ctx: str = "") -> go.Figure:
    if ob_df.empty:
        return empty_fig("No order-book data")
    sub = ob_df
    if tenor and "TENOR_NAME" in sub.columns:
        sub = sub[sub["TENOR_NAME"] == tenor]
    if sub.empty:
        return empty_fig("No OB data for this tenor")

    sub = sub.sort_values("EVENT_TIME_UTC").copy()
    sub["spread"] = sub["ASK_PRICE"] - sub["BID_PRICE"]
    sub["time"] = pd.to_datetime(sub["EVENT_TIME_UTC"])

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=sub["time"], y=sub["spread"], mode="lines",
        name="Bid-Ask Spread", line=dict(width=1, color=ORG),
    ))
    fig.update_layout(
        template=DARK, height=420,
        title=_t(ctx, "Bid-Ask Spread Evolution"), margin=dict(t=60, b=40, l=60, r=30),
        yaxis_title="EUR/MWh",
    )
    return fig


def fig_ob_imbalance(ob_df: pd.DataFrame, tenor: str | None,
                     ctx: str = "") -> go.Figure:
    if ob_df.empty:
        return empty_fig("No order-book data")
    sub = ob_df
    if tenor and "TENOR_NAME" in sub.columns:
        sub = sub[sub["TENOR_NAME"] == tenor]
    if sub.empty:
        return empty_fig("No OB data for this tenor")

    sub = sub.sort_values("EVENT_TIME_UTC").copy()
    bid_q = sub["BID_QUANTITY"].fillna(0)
    ask_q = sub["ASK_QUANTITY"].fillna(0)
    total = bid_q + ask_q
    sub["imbalance"] = (bid_q - ask_q) / total.replace(0, np.nan)
    sub["mid"] = (sub["BID_PRICE"] + sub["ASK_PRICE"]) / 2
    sub["time"] = pd.to_datetime(sub["EVENT_TIME_UTC"])

    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Scatter(
        x=sub["time"], y=sub["imbalance"], mode="lines",
        name="OB Imbalance", line=dict(width=1, color=BLU),
    ), secondary_y=False)
    fig.add_trace(go.Scatter(
        x=sub["time"], y=sub["mid"], mode="lines",
        name="Mid Price", line=dict(width=1, color=GRN, dash="dot"),
    ), secondary_y=True)
    fig.add_hline(y=0, line_dash="dash", line_color=NEUTRAL)
    fig.update_layout(
        template=DARK, height=450,
        title=_t(ctx, "Order Book Imbalance vs Mid Price"), margin=dict(t=60, b=40, l=60, r=30),
        showlegend=True, legend=dict(x=0, y=1.15, orientation="h"),
    )
    fig.update_yaxes(title_text="Imbalance", secondary_y=False)
    fig.update_yaxes(title_text="EUR/MWh", secondary_y=True)
    return fig


def fig_ob_vs_flow(
    ob_df: pd.DataFrame, panel: pd.DataFrame, tenor: str | None,
    ctx: str = "",
) -> go.Figure:
    """Scatter: daily OB imbalance vs daily broker net flow."""
    if ob_df.empty or panel.empty:
        return empty_fig("Insufficient data")
    sub = ob_df
    if tenor and "TENOR_NAME" in sub.columns:
        sub = sub[sub["TENOR_NAME"] == tenor]
    if sub.empty:
        return empty_fig()

    sub = sub.copy()
    bid_q = sub["BID_QUANTITY"].fillna(0)
    ask_q = sub["ASK_QUANTITY"].fillna(0)
    total = bid_q + ask_q
    sub["imbalance"] = (bid_q - ask_q) / total.replace(0, np.nan)
    sub["date"] = pd.to_datetime(sub["EVENT_TIME_UTC"]).dt.normalize()
    daily_imb = sub.groupby("date")["imbalance"].mean()

    merged = pd.DataFrame({
        "ob_imbalance": daily_imb,
        "net_flow": panel["broker_net_flow"],
    }).dropna()
    if len(merged) < 10:
        return empty_fig("Insufficient overlapping data")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=merged["ob_imbalance"], y=merged["net_flow"], mode="markers",
        marker=dict(size=5, opacity=0.6, color=BLU), name="Obs",
    ))
    slope, intercept, r, p, _ = sp_stats.linregress(
        merged["ob_imbalance"], merged["net_flow"]
    )
    xf = np.linspace(merged["ob_imbalance"].min(), merged["ob_imbalance"].max(), 50)
    fig.add_trace(go.Scatter(
        x=xf, y=slope * xf + intercept, mode="lines",
        name=f"OLS R={r:.3f} p={p:.3f}", line=dict(color=RED, width=2),
    ))
    fig.update_layout(
        template=DARK, height=420,
        title=_t(ctx, "OB Imbalance vs Broker Net Flow"), margin=dict(t=60, b=40, l=60, r=30),
        xaxis_title="Avg Daily OB Imbalance", yaxis_title="Broker Net Flow (MW)",
    )
    return fig


def fig_activity(act_df: pd.DataFrame, tenor: str | None,
                 ctx: str = "") -> go.Figure:
    if act_df.empty:
        return empty_fig("No activity data")
    sub = act_df
    if tenor and "TENOR_NAME" in sub.columns:
        sub = sub[sub["TENOR_NAME"] == tenor]
    if sub.empty:
        return empty_fig()
    sub = sub.sort_values("SNAPSHOT_TIME_UTC").copy()
    sub["time"] = pd.to_datetime(sub["SNAPSHOT_TIME_UTC"])
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=sub["time"], y=sub["COUNT_TP"], mode="lines",
        name="Quote Activity", line=dict(width=1, color=PRP),
    ))
    fig.update_layout(
        template=DARK, height=370,
        title=_t(ctx, "Quote Activity Count"), margin=dict(t=60, b=40, l=60, r=30),
        yaxis_title="Count",
    )
    return fig


# ===================================================================
# 6  Signal Analysis
# ===================================================================


def fig_scatter(
    panel: pd.DataFrame, signal_col: str, horizon: int,
    ctx: str = "",
) -> go.Figure:
    ret_col = f"fwd_ret_{horizon}d"
    v = panel[[signal_col, ret_col]].dropna()
    if len(v) < 10:
        return empty_fig("Insufficient data")
    slope, intercept, r, p, _ = sp_stats.linregress(v[signal_col], v[ret_col])
    xf = np.linspace(v[signal_col].min(), v[signal_col].max(), 100)
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=v[signal_col], y=v[ret_col], mode="markers",
        marker=dict(size=5, opacity=0.6, color=GRN), name="Obs",
    ))
    fig.add_trace(go.Scatter(
        x=xf, y=slope * xf + intercept, mode="lines",
        name=f"OLS R={r:.3f} p={p:.3f}",
        line=dict(color=RED, width=2),
    ))
    label = SIGNAL_COLS.get(signal_col, signal_col)
    fig.update_layout(
        template=DARK, height=420,
        title=_t(ctx, f"{label} vs {horizon}d Fwd Return"),
        xaxis_title=label, yaxis_title=f"{horizon}d return",
        margin=dict(t=60, b=40, l=60, r=30),
    )
    return fig


def fig_quintile(
    panel: pd.DataFrame, signal_col: str, horizon: int,
    ctx: str = "",
) -> go.Figure:
    ret_col = f"fwd_ret_{horizon}d"
    v = panel[[signal_col, ret_col]].dropna()
    if len(v) < 10:
        return empty_fig("Insufficient data")

    try:
        v["q"] = pd.qcut(v[signal_col], 5, labels=False, duplicates="drop")
    except ValueError:
        return empty_fig("Cannot form quintiles")

    n_bins = v["q"].nunique()
    labels = {i: f"Q{i+1}" for i in range(n_bins)}
    labels[0] = "Q1(low)"
    labels[n_bins - 1] = f"Q{n_bins}(high)"
    v["q_label"] = v["q"].map(labels)

    qm = v.groupby("q_label", sort=False)[ret_col].mean().reindex(
        [labels[i] for i in range(n_bins)]
    )
    colors = [GRN if x >= 0 else RED for x in qm.values]
    fig = go.Figure(go.Bar(
        x=qm.index.astype(str), y=qm.values,
        text=[f"{x:.4f}" for x in qm.values],
        textposition="outside", marker_color=colors,
    ))
    label = SIGNAL_COLS.get(signal_col, signal_col)
    fig.update_layout(
        template=DARK, height=420,
        title=_t(ctx, f"Mean {horizon}d Return by {label} Quintile"),
        yaxis_title=f"Mean {horizon}d return", margin=dict(t=60, b=40, l=60, r=30),
    )
    return fig


def fig_rolling_signal(
    rolling_df: pd.DataFrame, signal_label: str, horizon: int,
    ctx: str = "",
) -> go.Figure:
    """Time series of rolling Spearman rho."""
    if rolling_df.empty:
        return empty_fig("Insufficient data for rolling signal")
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=rolling_df["date"], y=rolling_df["rho"], mode="lines",
        name="Spearman rho", line=dict(width=1.5, color=BLU),
    ))
    fig.add_hline(y=0, line_dash="dash", line_color=NEUTRAL)
    fig.update_layout(
        template=DARK, height=340,
        title=_t(ctx, f"Rolling 60d Spearman: {signal_label} vs {horizon}d Return"),
        margin=dict(t=60, b=40, l=60, r=30), yaxis_title="rho",
    )
    return fig


def fig_signal_heatmap(hm_df: pd.DataFrame, horizon: int,
                       ctx: str = "") -> go.Figure:
    """Heatmap of Spearman rho across (tenor x signal)."""
    if hm_df.empty:
        return empty_fig("No heatmap data")
    fig = go.Figure(go.Heatmap(
        z=hm_df.values,
        x=hm_df.columns.tolist(),
        y=hm_df.index.tolist(),
        colorscale="RdYlGn", zmid=0, showscale=True,
        text=np.round(hm_df.values, 3).astype(str),
        texttemplate="%{text}",
    ))
    fig.update_layout(
        template=DARK, height=max(250, 40 * len(hm_df)),
        title=_t(ctx, f"Spearman Rho Heatmap ({horizon}d Horizon)"),
        margin=dict(t=60, b=40, l=60, r=30),
    )
    return fig


# ===================================================================
# 7  Statistics tables
# ===================================================================


def df_to_table(df: pd.DataFrame):
    """Convert DataFrame to a light-themed Dash bootstrap table."""
    from dash import html
    import dash_bootstrap_components as dbc

    if df.empty:
        return html.P("No data", className="text-muted")
    return dbc.Table.from_dataframe(
        df, striped=True, bordered=True, hover=True,
        size="sm", className="small",
    )
