"""
Data Quality Validator
──────────────────────
Automated checks that run before data reaches the UI.
Catches semantically wrong data (correct shape but wrong content)
such as stale forecasts cached under today's date.
"""

import datetime
import logging
from typing import Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


class DataQualityResult:
    """Result of a data quality check."""

    __slots__ = ('passed', 'failed_checks', 'warnings', 'source_label')

    def __init__(self, source_label: str):
        self.source_label = source_label
        self.passed = True
        self.failed_checks: List[str] = []
        self.warnings: List[str] = []

    def fail(self, check_name: str, detail: str = ''):
        self.passed = False
        msg = f"{check_name}: {detail}" if detail else check_name
        self.failed_checks.append(msg)
        logger.warning(f"DQ FAIL [{self.source_label}] {msg}")

    def warn(self, check_name: str, detail: str = ''):
        msg = f"{check_name}: {detail}" if detail else check_name
        self.warnings.append(msg)
        logger.info(f"DQ WARN [{self.source_label}] {msg}")

    @property
    def summary(self) -> str:
        if self.passed and not self.warnings:
            return 'OK'
        parts = []
        if self.failed_checks:
            parts.append(f"{len(self.failed_checks)} failed")
        if self.warnings:
            parts.append(f"{len(self.warnings)} warnings")
        return ', '.join(parts)


def validate_forecast(
    df: pd.DataFrame,
    expected_issue_date: datetime.date,
    variable: str,
    model: str,
    zones: List[str] = None,
) -> DataQualityResult:
    """
    Validate a forecast DataFrame before it is used in the dashboard.

    Checks
    ------
    1. not_empty          – DataFrame has rows
    2. index_date_check   – Index starts on or after expected_issue_date
                            (catches stale data cached under wrong date)
    3. has_expected_zones  – At least the core zones (DE, FR, GB) are present
    4. not_all_nan         – At least some non-NaN values exist
    5. reasonable_magnitude – Values are within a sane MW range (< 200,000 MW)
    6. no_duplicate_index  – No duplicate timestamps
    """
    label = f"{variable}/{model}/{expected_issue_date}"
    result = DataQualityResult(label)

    # 1. Not empty
    if df is None or df.empty:
        result.fail('not_empty', 'DataFrame is None or empty')
        return result  # No point running further checks

    # 2. Index date check (the check that would have caught today's bug)
    try:
        idx = df.index
        if hasattr(idx, 'tz') and idx.tz is not None:
            idx_naive = idx.tz_localize(None)
        else:
            idx_naive = idx

        first_date = idx_naive.min().date() if hasattr(idx_naive.min(), 'date') else None
        if first_date is not None:
            # The data should start on or after the issue date (or day before for
            # models that include the previous day's late hours in CET)
            earliest_acceptable = expected_issue_date - datetime.timedelta(days=1)
            if first_date < earliest_acceptable:
                result.fail(
                    'index_date_stale',
                    f"Data starts {first_date}, expected >= {earliest_acceptable}. "
                    f"Likely stale cache from a previous issue date."
                )
    except Exception as e:
        result.warn('index_date_check', f"Could not verify index dates: {e}")

    # 3. Has expected zones
    cols_upper = [str(c).upper() for c in df.columns]
    core_zones = {'DE', 'FR', 'GB'}
    if zones:
        core_zones = set(z.upper() for z in zones[:3])  # Check first 3 requested
    missing_core = core_zones - set(cols_upper)
    if missing_core:
        result.warn('missing_core_zones', f"Missing: {missing_core}")

    # 4. Not all NaN
    numeric_cols = df.select_dtypes(include='number')
    if numeric_cols.empty or numeric_cols.isna().all().all():
        result.fail('all_nan', 'All numeric values are NaN')

    # 5. Reasonable magnitude (MW values should be < 200,000)
    if not numeric_cols.empty:
        max_val = numeric_cols.abs().max().max()
        if max_val > 200_000:
            result.warn(
                'extreme_magnitude',
                f"Max absolute value {max_val:,.0f} MW exceeds 200,000 MW threshold"
            )

    # 6. No duplicate index
    if df.index.duplicated().any():
        n_dupes = df.index.duplicated().sum()
        result.warn('duplicate_index', f"{n_dupes} duplicate timestamps")

    return result


def validate_spot_price(
    df: pd.DataFrame,
    source_name: str,
    max_age_hours: int = 48,
) -> DataQualityResult:
    """
    Validate spot price data.

    Checks
    ------
    1. not_empty
    2. recency   – Latest timestamp within max_age_hours of now
    3. not_all_nan
    4. reasonable_price – Prices within -500 to 5000 EUR/MWh
    """
    result = DataQualityResult(source_name)

    if df is None or df.empty:
        result.fail('not_empty', 'DataFrame is None or empty')
        return result

    # Recency check
    try:
        idx = df.index
        if hasattr(idx, 'tz') and idx.tz is not None:
            latest = idx.max().tz_localize(None)
        else:
            latest = idx.max()

        now = pd.Timestamp.now()
        age_hours = (now - latest).total_seconds() / 3600
        if age_hours > max_age_hours:
            result.fail(
                'stale_data',
                f"Latest data is {age_hours:.0f}h old (threshold: {max_age_hours}h)"
            )
    except Exception as e:
        result.warn('recency_check', f"Could not verify recency: {e}")

    # Not all NaN
    numeric_cols = df.select_dtypes(include='number')
    if numeric_cols.empty or numeric_cols.isna().all().all():
        result.fail('all_nan', 'All numeric values are NaN')

    # Reasonable price range
    if not numeric_cols.empty:
        min_val = numeric_cols.min().min()
        max_val = numeric_cols.max().max()
        if min_val < -500:
            result.warn('extreme_low_price', f"Min price {min_val:.1f} EUR/MWh")
        if max_val > 5000:
            result.warn('extreme_high_price', f"Max price {max_val:.1f} EUR/MWh")

    return result
