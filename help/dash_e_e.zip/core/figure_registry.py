"""
figure_registry
===============
A registry of *pre-computable default figures*.  Each page tells the registry
"here is the chart you'd build when a user first lands on me" and the
registry builds them once at startup (and again whenever their upstream data
sources refresh), stashing the serialised JSON in ``figure_cache``.

Result: the first time a user opens any page, their main chart is already
waiting in memory as ready-to-ship bytes.  The Dash callback just looks it
up and returns it — typical response time < 50 ms including network.

Usage
-----
    from core.figure_registry import figure_registry

    def _build_fuel_switching_default():
        return build_chart(power_hub="DE", gas_hub="TTF", ...)

    figure_registry.register(
        key="fuel_switching:DE:TTF:default",
        builder=_build_fuel_switching_default,
        sources=["fuel_switching_data"],
        ttl=3600,
    )

Then in the Dash callback:

    from core.fast_cache import figure_cache

    prebuilt = figure_cache.get_figure("fuel_switching:DE:TTF:default")
    if prebuilt is not None:
        return prebuilt
    # ... fall through to slow path ...
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from core.fast_cache import figure_cache

logger = logging.getLogger(__name__)


@dataclass
class _FigureSpec:
    key: str
    builder: Callable[[], Any]
    sources: Tuple[str, ...] = ()
    ttl: int = 3600
    last_built: Optional[float] = None
    last_error: Optional[str] = None
    build_count: int = 0
    build_time_ms: Optional[float] = None


class FigureRegistry:
    """Registry + builder for pre-computed default figures."""

    def __init__(self) -> None:
        self._specs: Dict[str, _FigureSpec] = {}
        self._lock = threading.RLock()

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(
        self,
        key: str,
        builder: Callable[[], Any],
        sources: Iterable[str] = (),
        ttl: int = 3600,
    ) -> None:
        """Register a default figure.  *sources* are logical data-source names
        (matching ``dashboard_cache.register_source(name=…)``); when any of
        them refreshes, this figure is rebuilt automatically."""
        spec = _FigureSpec(
            key=key,
            builder=builder,
            sources=tuple(sources),
            ttl=int(ttl),
        )
        with self._lock:
            self._specs[key] = spec
        logger.info("figure_registry: registered '%s' (sources=%s)", key, spec.sources)

    # ------------------------------------------------------------------
    # Build / warm
    # ------------------------------------------------------------------

    def build(self, key: str) -> bool:
        """Build one figure synchronously.  Returns True on success."""
        with self._lock:
            spec = self._specs.get(key)
        if spec is None:
            logger.warning("figure_registry: unknown key '%s'", key)
            return False
        t0 = time.time()
        try:
            fig = spec.builder()
            if fig is None:
                raise RuntimeError("builder returned None")
            figure_cache.set(key, fig, ttl=spec.ttl)
            elapsed_ms = (time.time() - t0) * 1000
            spec.last_built = time.time()
            spec.last_error = None
            spec.build_count += 1
            spec.build_time_ms = elapsed_ms
            logger.info("figure_registry: built '%s' in %.0f ms", key, elapsed_ms)
            return True
        except Exception as exc:
            spec.last_error = str(exc)
            logger.error("figure_registry: failed to build '%s': %s", key, exc, exc_info=True)
            return False

    def warm_all(self, max_workers: int = 4) -> None:
        """Rebuild every registered figure in parallel."""
        with self._lock:
            keys = list(self._specs.keys())
        if not keys:
            return
        logger.info("figure_registry: warming %d figures …", len(keys))
        t0 = time.time()
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="fig-warm") as pool:
            futures = {pool.submit(self.build, k): k for k in keys}
            for fut in as_completed(futures):
                pass  # errors are already logged
        logger.info("figure_registry: warmed %d figures in %.1fs",
                    len(keys), time.time() - t0)

    def warm_all_async(self, max_workers: int = 4) -> threading.Thread:
        """Kick off :meth:`warm_all` in a background thread.  Returns the thread."""
        t = threading.Thread(
            target=self.warm_all,
            kwargs={"max_workers": max_workers},
            daemon=True,
            name="fig-registry-warmup",
        )
        t.start()
        return t

    def rebuild_for_source(self, source_name: str) -> List[str]:
        """Rebuild every figure whose *sources* tuple includes *source_name*."""
        with self._lock:
            affected = [spec.key for spec in self._specs.values() if source_name in spec.sources]
        if not affected:
            return []
        logger.info("figure_registry: source '%s' changed → rebuilding %d figures",
                    source_name, len(affected))
        # Run sequentially inside a background thread pool so we don't
        # swamp the scheduler thread.
        for key in affected:
            self.build(key)
        return affected

    def rebuild_for_source_async(self, source_name: str) -> None:
        """Fire :meth:`rebuild_for_source` on a background thread."""
        threading.Thread(
            target=self.rebuild_for_source,
            args=(source_name,),
            daemon=True,
            name=f"fig-rebuild-{source_name}",
        ).start()

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def status(self) -> Dict[str, Any]:
        with self._lock:
            specs = {
                spec.key: {
                    "sources": list(spec.sources),
                    "ttl": spec.ttl,
                    "last_built": spec.last_built,
                    "last_error": spec.last_error,
                    "build_count": spec.build_count,
                    "build_time_ms": spec.build_time_ms,
                    "cached": figure_cache.get_json(spec.key) is not None,
                }
                for spec in self._specs.values()
            }
        return {"figures": specs, "cache_stats": figure_cache.stats()}

    def keys(self) -> List[str]:
        with self._lock:
            return list(self._specs.keys())


# ----------------------------------------------------------------------
# Singleton
# ----------------------------------------------------------------------
figure_registry = FigureRegistry()
