"""
Flows dashboard — Dash callbacks.

Registered via side-effect import in pages/flows.py.

Builds TWO Cytoscape graphs side-by-side:
  • Left  — Net Commercial Flow: edges sized/coloured by flow MW,
            nodes sized by net export, coloured by mean price.
  • Right — Price Spread: edges coloured by price spread EUR/MWh,
            nodes all the same size, coloured by mean price.
"""
from __future__ import annotations

import datetime as dt
import logging
from typing import Any

import numpy as np
import pandas as pd
from dash import Input, Output, callback, no_update

from core.flows.constants import (
    COORD_X_OFFSET,
    COORD_X_SCALE,
    COORD_Y_OFFSET,
    COORD_Y_SCALE,
    EDGE_WIDTH_MAX,
    EDGE_WIDTH_MIN,
    EXCLUDED_ZONES,
    NODE_SIZE_MAX,
    NODE_SIZE_MIN,
    REGION_COORDS,
    REGIONS,
    VARIABLE_FLOW,
    VARIABLE_SPREAD,
    VIEW_REGION,
    VIEW_ZONE,
    ZONE_COORDS,
    ZONE_TO_REGION,
)
from core.flows.data import aggregate_flows, load_flows_data

logger = logging.getLogger(__name__)

# Fixed node size used for the spread graph (uniform, independent of net export)
_UNIFORM_NODE_SIZE = (NODE_SIZE_MIN + NODE_SIZE_MAX) / 2   # ≈ 21 px

# ── Edge styling thresholds ──────────────────────────────────────────────
# Drop edges below this absolute MW threshold to remove zero-flow clutter
# (especially around hubs like DE).
_MIN_EDGE_FLOW_MW = 10.0
# Magnitude tiers (as fraction of max |flow|) drive opacity to give the
# largest flows visual prominence over secondary flows.
_OPACITY_BACKBONE = 0.95   # top tier (>40 % of max)
_OPACITY_SECONDARY = 0.55  # mid tier (10–40 %)
_OPACITY_TRACE = 0.30      # bottom tier (< 10 %)

# Curve offset (in px) for bidirectional pairs.  +ve bows one way, -ve the other.
_BIDIR_CURVE_DISTANCE = 55.0


# ── Geometry helpers ──────────────────────────────────────────────────────

def _coord_to_xy(zone_or_region: str, view_mode: str) -> dict[str, float]:
    """Convert (lon, lat) for a zone/region into Cytoscape x/y pixel coords."""
    coords = REGION_COORDS if view_mode == VIEW_REGION else ZONE_COORDS
    lonlat = coords.get(zone_or_region.lower())
    if lonlat is None:
        # Fallback: stack unknowns in a cluster on the far right of the canvas
        return {"x": COORD_X_OFFSET + 750.0, "y": COORD_Y_OFFSET + 350.0}
    lon, lat = lonlat
    # x increases east; y increases southward (screen coords)
    return {
        "x": COORD_X_OFFSET + lon * COORD_X_SCALE,
        "y": COORD_Y_OFFSET + (75.0 - lat) * COORD_Y_SCALE,
    }


# ── Scaling helpers ──────────────────────────────────────────────────────

def _log_scale_widths(values: np.ndarray) -> np.ndarray:
    abs_v = np.abs(values.astype(float))
    abs_v = np.where(np.isnan(abs_v), 0.0, abs_v)
    log_v = np.log1p(abs_v)
    lo, hi = log_v.min(), log_v.max()
    span = max(hi - lo, 1e-9)
    return EDGE_WIDTH_MIN + (EDGE_WIDTH_MAX - EDGE_WIDTH_MIN) * (log_v - lo) / span


def _log_scale_node_sizes(values: np.ndarray) -> np.ndarray:
    abs_v = np.abs(values.astype(float))
    abs_v = np.where(np.isnan(abs_v), 0.0, abs_v)
    log_v = np.log1p(abs_v)
    lo, hi = log_v.min(), log_v.max()
    span = max(hi - lo, 1e-9)
    return NODE_SIZE_MIN + (NODE_SIZE_MAX - NODE_SIZE_MIN) * (log_v - lo) / span


def _price_to_colour(price: float, vmin: float, vmax: float) -> str:
    """
    Green (cheap) → amber → red (expensive).
    Matches the EPEX day-ahead price heatmap convention.
    """
    if not np.isfinite(price):
        return "#bdbdbd"
    span = max(vmax - vmin, 1e-9)
    t = float(np.clip((price - vmin) / span, 0.0, 1.0))
    if t < 0.5:
        s = t * 2.0
        r = int(46  + (210 - 46)  * s)
        g = int(160 + (153 - 160) * s)
        b = int(67  + (34  - 67)  * s)
    else:
        s = (t - 0.5) * 2.0
        r = int(210 + (207 - 210) * s)
        g = int(153 + (34  - 153) * s)
        b = int(34  + (46  - 34)  * s)
    return f"rgb({r},{g},{b})"


def _flow_colour_pair(magnitude: float, abs_max: float) -> tuple[str, str]:
    """
    Return a (light-source, dark-target) colour pair encoding flow magnitude.
    Used for the linear-gradient on flow edges.  Larger flows → deeper blue.
    """
    if not np.isfinite(magnitude) or abs_max <= 0:
        return "#dfe7ee", "#9aa6b1"
    t = float(np.clip(np.log1p(abs(magnitude)) / np.log1p(abs_max), 0.0, 1.0))
    light_r = int(220 + (148 - 220) * t)
    light_g = int(232 + (185 - 232) * t)
    light_b = int(245 + (224 - 245) * t)
    dark_r  = int(120 + (15  - 120) * t)
    dark_g  = int(160 + (76  - 160) * t)
    dark_b  = int(210 + (160 - 210) * t)
    return (f"rgb({light_r},{light_g},{light_b})",
            f"rgb({dark_r},{dark_g},{dark_b})")


def _spread_colour_pair(spread: float, abs_max: float) -> tuple[str, str]:
    """Diverging gradient pair (light → dark) for spread edges."""
    if not np.isfinite(spread) or abs_max <= 0:
        return "#dddddd", "#888888"
    t = float(np.clip(spread / abs_max, -1.0, 1.0))
    if t >= 0:
        light = (245, 220, 220)
        dark  = (int(220 + (180 - 220) * t),
                 int(150 + (45  - 150) * t),
                 int(150 + (50  - 150) * t))
    else:
        s = -t
        light = (220, 230, 245)
        dark  = (int(150 + (40  - 150) * s),
                 int(180 + (105 - 180) * s),
                 int(220 + (200 - 220) * s))
    return (f"rgb({light[0]},{light[1]},{light[2]})",
            f"rgb({dark[0]},{dark[1]},{dark[2]})")


def _spread_to_colour(spread: float, abs_max: float) -> str:
    """Diverging blue (negative) → grey (zero) → red (positive)."""
    if not np.isfinite(spread) or abs_max <= 0:
        return "#888888"
    t = float(np.clip(spread / abs_max, -1.0, 1.0))
    if t >= 0:
        r = int(204 + (207 - 204) * t)
        g = int(204 + (34  - 204) * t)
        b = int(204 + (46  - 204) * t)
    else:
        s = -t
        r = int(204 + (31  - 204) * s)
        g = int(204 + (111 - 204) * s)
        b = int(204 + (235 - 204) * s)
    return f"rgb({r},{g},{b})"


# ── Element builders ──────────────────────────────────────────────────────

def _build_nodes(
    edges_df: pd.DataFrame,
    nodes_df: pd.DataFrame,
    view_mode: str,
    uniform_size: bool = False,
    annotate: str = "price",
) -> tuple[list[dict], list[dict]]:
    """
    Build Cytoscape node elements + per-node stylesheet rules.

    Args:
        uniform_size: If True all nodes are drawn at ``_UNIFORM_NODE_SIZE``
                      (used for the spread graph so size encodes nothing).
        annotate: What to show on the second line of the node label.
                  ``"price"``      → zone price (EUR/MWh, e.g. "46")
                  ``"net_export"`` → mean net export (MW, e.g. "+1 250")
    Returns ``(node_elements, node_style_rules)``.
    """
    if edges_df.empty:
        return [], []

    ids = sorted(set(edges_df["src"].tolist()) | set(edges_df["dst"].tolist()))

    # ── Net export & price per node ──────────────────────────────────────
    if view_mode == VIEW_ZONE and not nodes_df.empty:
        nd = nodes_df.set_index("zone")
        ne_vals    = np.array([float(nd["mean_net_export"].get(z, np.nan)) for z in ids])
        price_vals = np.array([float(nd["mean_price"].get(z, np.nan))      for z in ids])

    elif view_mode == VIEW_REGION:
        # Net export = sum(outbound) − sum(inbound) across inter-region edges
        ne_map: dict[str, float] = {rid: 0.0 for rid in ids}
        for row in edges_df.itertuples(index=False):
            if row.src in ne_map:
                ne_map[row.src] += float(row.flow_mw)
            if row.dst in ne_map:
                ne_map[row.dst] -= float(row.flow_mw)
        ne_vals    = np.array([ne_map.get(rid, 0.0) for rid in ids])
        price_vals = np.array([np.nan] * len(ids))

    else:
        ne_vals    = np.array([1.0]   * len(ids))
        price_vals = np.array([np.nan] * len(ids))

    # ── Node sizes ───────────────────────────────────────────────────────
    if uniform_size:
        sizes = np.full(len(ids), _UNIFORM_NODE_SIZE)
    else:
        sizes = _log_scale_node_sizes(ne_vals)

    # ── Price colour range ───────────────────────────────────────────────
    finite_prices = price_vals[np.isfinite(price_vals)]
    if finite_prices.size > 0:
        pmin = float(np.nanpercentile(finite_prices, 5))
        pmax = float(np.nanpercentile(finite_prices, 95))
    else:
        pmin, pmax = 0.0, 1.0

    elements:    list[dict] = []
    style_rules: list[dict] = []

    for i, node_id in enumerate(ids):
        size    = float(sizes[i])
        colour  = _price_to_colour(float(price_vals[i]), pmin, pmax)
        ne_val    = float(ne_vals[i])
        price_val = float(price_vals[i])
        ne_str    = f"{ne_val:+,.0f} MW" if np.isfinite(ne_val) else "n/a"
        price_str = f"{price_val:.1f} EUR/MWh" if np.isfinite(price_val) else "n/a"

        base_label = node_id.upper() if view_mode == VIEW_ZONE else node_id
        tooltip = (
            f"{base_label}  ·  Net export: {ne_str}"
            + (f"  ·  Price: {price_str}" if view_mode == VIEW_ZONE else "")
        )

        # Second-line annotation: price for the spread graph, net export for the flow graph.
        if view_mode == VIEW_ZONE:
            if annotate == "net_export" and np.isfinite(ne_val):
                ne_k = ne_val / 1000.0
                display_label = f"{base_label}\n{ne_k:+.1f}GW"
            elif annotate == "price" and np.isfinite(price_val):
                display_label = f"{base_label}\n{price_val:.0f}"
            else:
                display_label = base_label
        else:
            display_label = base_label

        elements.append({
            "data": {"id": node_id, "label": display_label, "tooltip": tooltip},
            "position": _coord_to_xy(node_id, view_mode),
        })
        style_rules.append({
            "selector": f"node[id = '{node_id}']",
            "style": {
                "width":            size,
                "height":           size,
                "background-color": colour,
                "text-wrap":        "wrap",
                "text-max-width":   "60px",
            },
        })

    return elements, style_rules


def _detect_bidirectional_pairs(edges_df: pd.DataFrame) -> dict[tuple[str, str], int]:
    """
    Identify bidirectional pairs and assign each edge a curve sign (+1 / -1 / 0).

    Returns a mapping {(src, dst): sign}.  Sign 0 means single-direction edge.
    For a bidirectional pair, the lexically smaller node→larger node direction
    gets +1 and the reverse gets -1, ensuring stable layout across re-renders.
    """
    seen: dict[frozenset, list[tuple[str, str]]] = {}
    for _, row in edges_df.iterrows():
        key = frozenset([row["src"], row["dst"]])
        seen.setdefault(key, []).append((row["src"], row["dst"]))

    sign_map: dict[tuple[str, str], int] = {}
    for key, pairs in seen.items():
        if len(pairs) <= 1:
            sign_map[pairs[0]] = 0
            continue
        a, b = sorted(key)   # lexical order
        for src, dst in pairs:
            sign_map[(src, dst)] = +1 if src == a else -1
    return sign_map


def _build_edges(
    edges_df: pd.DataFrame,
    variable: str,
) -> tuple[list[dict], list[dict]]:
    """
    Build Cytoscape edge elements + per-edge stylesheet rules.

    Applies the directional-clarity styling pack:
      • Drops edges below ``_MIN_EDGE_FLOW_MW`` (zero-clutter filter).
      • Per-edge gradient (light source → dark target) encoding direction by colour.
      • Dashed line style ready for the clientside dash-flow animation.
      • Curved unbundled-bezier separation of bidirectional pairs.
      • Opacity tiers so the largest flows form a visual backbone.
    """
    if edges_df.empty:
        return [], []

    edges_df = edges_df.copy()

    if "flow_mw" in edges_df.columns:
        # Drop zero/near-zero clutter edges.
        edges_df = edges_df[edges_df["flow_mw"].abs() >= _MIN_EDGE_FLOW_MW].reset_index(drop=True)

    if edges_df.empty:
        return [], []

    # ── Direction normalisation ──────────────────────────────────────────
    # ALL edges must have positive flow_mw before rendering so labels are never
    # negative.  The aggregation layer should already ensure this, but slip-
    # throughs (region view, edge cases) are caught here.
    if "flow_mw" in edges_df.columns:
        neg_flow = edges_df["flow_mw"] < 0
        if neg_flow.any():
            edges_df.loc[neg_flow, ["src", "dst"]] = (
                edges_df.loc[neg_flow, ["dst", "src"]].values
            )
            edges_df.loc[neg_flow, "flow_mw"] = -edges_df.loc[neg_flow, "flow_mw"]
            if "price_spread" in edges_df.columns:
                edges_df.loc[neg_flow, "price_spread"] = (
                    -edges_df.loc[neg_flow, "price_spread"]
                )

    # For the spread graph, additionally ensure price_spread ≥ 0 so the arrow
    # always points from the cheaper zone to the more expensive zone.
    # Any edge where spread < 0 is flipped so its label reads as a positive
    # differential with the arrow reversed.
    if variable == VARIABLE_SPREAD and "price_spread" in edges_df.columns:
        neg_spread = edges_df["price_spread"].fillna(0) < 0
        if neg_spread.any():
            edges_df.loc[neg_spread, ["src", "dst"]] = (
                edges_df.loc[neg_spread, ["dst", "src"]].values
            )
            edges_df.loc[neg_spread, "price_spread"] = (
                -edges_df.loc[neg_spread, "price_spread"]
            )
            if "flow_mw" in edges_df.columns:
                edges_df.loc[neg_spread, "flow_mw"] = (
                    -edges_df.loc[neg_spread, "flow_mw"]
                )

    if variable == VARIABLE_SPREAD:
        magnitudes = np.array([
            v if np.isfinite(v) else 0.0 for v in edges_df["price_spread"]
        ])
        finite_abs = np.abs(magnitudes[np.isfinite(magnitudes)])
        abs_max = float(np.nanpercentile(finite_abs, 95)) if finite_abs.size > 0 else 1.0
    else:
        magnitudes = np.array([
            v if np.isfinite(v) else 0.0 for v in edges_df["flow_mw"]
        ])
        abs_max = float(np.abs(magnitudes).max()) if magnitudes.size > 0 else 1.0
        abs_max = max(abs_max, 1.0)

    widths = _log_scale_widths(magnitudes)
    flow_max_for_opacity = float(np.abs(edges_df["flow_mw"]).max()) if "flow_mw" in edges_df.columns else 1.0
    flow_max_for_opacity = max(flow_max_for_opacity, 1.0)

    pair_signs = _detect_bidirectional_pairs(edges_df)

    elements:    list[dict] = []
    style_rules: list[dict] = []

    for i, row in enumerate(edges_df.itertuples(index=False)):
        src, dst = row.src, row.dst
        flow_mw  = float(row.flow_mw)
        spread   = float(row.price_spread) if np.isfinite(row.price_spread) else float("nan")
        edge_id  = f"e_{src}__{dst}"

        # ── Gradient endpoints ──────────────────────────────────────────
        if variable == VARIABLE_SPREAD:
            # Spread is guaranteed ≥ 0 after the normalisation above.
            # Label shows the positive differential (arrow encodes direction).
            label = f"{spread:.1f}" if np.isfinite(spread) else "—"
            light_c, dark_c = _spread_colour_pair(spread, abs_max)
        else:
            label = f"{flow_mw:,.0f}"
            light_c, dark_c = _flow_colour_pair(flow_mw, abs_max)

        # ── Opacity tier (relative to max flow) ─────────────────────────
        rel = abs(flow_mw) / flow_max_for_opacity
        if rel >= 0.40:
            opacity = _OPACITY_BACKBONE
        elif rel >= 0.10:
            opacity = _OPACITY_SECONDARY
        else:
            opacity = _OPACITY_TRACE

        # ── Bidirectional curve offset ──────────────────────────────────
        sign = pair_signs.get((src, dst), 0)
        curve_distance = float(sign) * _BIDIR_CURVE_DISTANCE

        elements.append({
            "data": {
                "id":              edge_id,
                "source":          src,
                "target":          dst,
                "label":           label,
                "edge_width":      float(widths[i]),
                "edge_opacity":    float(opacity),
                "curve_distance":  curve_distance,
                "gradient_src":    light_c,
                "gradient_dst":    dark_c,
                "tooltip": (
                    f"{src.upper()} → {dst.upper()}  ·  "
                    f"Flow: {flow_mw:,.0f} MW  ·  "
                    f"Spread: {('—' if not np.isfinite(spread) else f'{spread:+.2f} EUR/MWh')}"
                ),
            },
        })

        style: dict[str, Any] = {
            "width":              float(widths[i]),
            "opacity":            float(opacity),
            "line-fill":          "linear-gradient",
            "line-gradient-stop-colors":    f"{light_c} {dark_c}",
            "line-gradient-stop-positions": "0 100",
            "target-arrow-color": dark_c,
            "source-arrow-color": light_c,
        }
        if sign != 0:
            # Bidirectional pair → bow apart into a clean lens.
            style["curve-style"]            = "unbundled-bezier"
            style["control-point-distances"] = curve_distance
            style["control-point-weights"]  = 0.5

        style_rules.append({
            "selector": f"edge[id = '{edge_id}']",
            "style":    style,
        })

    return elements, style_rules


def _base_stylesheet() -> list[dict]:
    """Default selectors that apply to every node/edge."""
    return [
        {
            "selector": "node",
            "style": {
                "label":              "data(label)",
                "text-valign":        "center",
                "text-halign":        "center",
                "color":              "#ffffff",
                "font-size":          "8px",
                "font-weight":        600,
                "border-color":       "#222",
                "border-width":       1,
                "text-outline-color": "#222",
                "text-outline-width": 1,
                "text-wrap":          "wrap",
                "text-max-width":     "60px",
                "line-height":        1.3,
            },
        },
        {
            "selector": "edge",
            "style": {
                "curve-style":              "bezier",
                "target-arrow-shape":       "triangle-backcurve",
                "target-arrow-fill":        "filled",
                "arrow-scale":              1.8,
                "target-distance-from-node": 4,
                "source-distance-from-node": 2,
                "line-style":               "dashed",
                "line-dash-pattern":        [10, 6],
                "line-cap":                 "round",
                "label":                    "data(label)",
                "font-size":                "8px",
                "color":                    "#333",
                "text-background-color":    "#ffffff",
                "text-background-opacity":  0.70,
                "text-background-padding":  "1px",
                "text-background-shape":    "round-rectangle",
                "text-rotation":            "autorotate",
                "control-point-step-size":  30,
            },
        },
    ]


# ── Date parsing helper ──────────────────────────────────────────────────

def _parse_date(s: Any, fallback: dt.date) -> dt.date:
    if not s:
        return fallback
    try:
        if isinstance(s, dt.date) and not isinstance(s, dt.datetime):
            return s
        return dt.datetime.fromisoformat(str(s)[:10]).date()
    except Exception:
        return fallback


# ── Helper to compute (edges_df, nodes_df) with weekend filter ───────────

def _filtered_edges_nodes(
    bundle: dict,
    hour_block: str,
    weekday: str,
    view_mode: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Aggregate the raw bundle, handling all three weekday filter modes.
    Returns ``(edges_df, nodes_df)``.
    """
    from core.flows.data import (  # noqa: PLC0415
        _aggregate_region_view,
        _aggregate_zone_view,
        _drop_excluded_borders,
        _filter_index,
        _hour_block_to_range,
    )

    weekday_only = weekday == "wd"
    weekend_only = weekday == "we"

    if not weekend_only:
        return aggregate_flows(
            bundle, hour_block, weekday_only=weekday_only, view_mode=view_mode
        )

    # Weekend-only filter (manual, not in aggregate_flows)
    flow = _drop_excluded_borders(bundle.get("flow", pd.DataFrame()))
    if flow.empty:
        return aggregate_flows(bundle, hour_block, weekday_only=False, view_mode=view_mode)

    hb = _hour_block_to_range(hour_block)
    flow_we = flow.loc[flow.index.dayofweek >= 5]
    if hb is not None:
        h0, h1 = hb
        flow_we = flow_we.loc[(flow_we.index.hour >= h0) & (flow_we.index.hour < h1)]

    price = bundle.get("price", pd.DataFrame())

    if view_mode == VIEW_REGION:
        edges_df = _aggregate_region_view(flow_we)
        nodes_df = pd.DataFrame(columns=["zone", "mean_price", "mean_net_export"])
        return edges_df, nodes_df

    # Zone view
    price_we = price.loc[price.index.dayofweek >= 5] if not price.empty else price
    if hb is not None and not price_we.empty:
        price_we = price_we.loc[
            (price_we.index.hour >= hb[0]) & (price_we.index.hour < hb[1])
        ]
    edges_df = _aggregate_zone_view(flow_we, price_we)

    zone_set: set[str] = set()
    if not edges_df.empty:
        zone_set.update(edges_df["src"].tolist())
        zone_set.update(edges_df["dst"].tolist())

    ne = bundle.get("net_export", pd.DataFrame())
    ne_we = ne.loc[ne.index.dayofweek >= 5] if not ne.empty else ne
    if hb is not None and not ne_we.empty:
        ne_we = ne_we.loc[(ne_we.index.hour >= hb[0]) & (ne_we.index.hour < hb[1])]

    node_rows = []
    for z in sorted(zone_set):
        mp = (
            float(price_we[z].mean(skipna=True))
            if (not price_we.empty and z in price_we.columns) else float("nan")
        )
        mn = (
            float(ne_we[z].mean(skipna=True))
            if (not ne_we.empty and z in ne_we.columns) else float("nan")
        )
        node_rows.append({"zone": z, "mean_price": mp, "mean_net_export": mn})
    nodes_df = pd.DataFrame(node_rows)

    return edges_df, nodes_df


# ── Region filter helper ─────────────────────────────────────────────────

def _apply_region_filter(
    edges_df: pd.DataFrame,
    nodes_df: pd.DataFrame,
    view_mode: str,
    region_filter: list[str] | None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Drop edges (and consequently nodes) that fall outside the selected regions.

    Zone view: a zone is included iff it belongs to a selected region, OR it
    doesn't belong to any region in ZONE_TO_REGION (e.g. UA, MD, TR — keep them).
    Region view: only edges between two selected regions are retained.
    """
    if not region_filter or len(region_filter) == len(REGIONS):
        return edges_df, nodes_df   # no region filter — excluded zones already dropped at data layer

    selected = set(region_filter)

    if view_mode == VIEW_REGION:
        mask = edges_df["src"].isin(selected) & edges_df["dst"].isin(selected)
        return edges_df[mask].reset_index(drop=True), nodes_df

    allowed_zones: set[str] = {z for r in selected for z in REGIONS.get(r, [])}
    # Zones not in any named region (UA, MD, TR…) always pass through
    all_in_edges = set(edges_df["src"]) | set(edges_df["dst"])
    allowed_zones |= {z for z in all_in_edges if z not in ZONE_TO_REGION}

    mask = edges_df["src"].isin(allowed_zones) & edges_df["dst"].isin(allowed_zones)
    filtered_edges = edges_df[mask].reset_index(drop=True)

    if nodes_df.empty or filtered_edges.empty:
        return filtered_edges, nodes_df

    remaining_zones = set(filtered_edges["src"]) | set(filtered_edges["dst"])
    filtered_nodes = nodes_df[nodes_df["zone"].isin(remaining_zones)].reset_index(drop=True)
    return filtered_edges, filtered_nodes


# ── Main callback ────────────────────────────────────────────────────────

_EMPTY = ([], _base_stylesheet(), [], _base_stylesheet())


@callback(
    Output("flows-graph-flow",   "elements"),
    Output("flows-graph-flow",   "stylesheet"),
    Output("flows-graph-spread", "elements"),
    Output("flows-graph-spread", "stylesheet"),
    Input("flows-date-range",     "start_date"),
    Input("flows-date-range",     "end_date"),
    Input("flows-hour-block",     "value"),
    Input("flows-weekday",        "value"),
    Input("flows-view",           "value"),
    Input("flows-region-filter",  "value"),
    prevent_initial_call=False,
)
def _update_graphs(
    start_date: Any,
    end_date: Any,
    hour_block: str,
    weekday: str,
    view_mode: str,
    region_filter: list[str] | None,
) -> tuple[list, list, list, list]:
    today = dt.date.today()
    start = _parse_date(start_date, today - dt.timedelta(days=30))
    end   = _parse_date(end_date,   today)
    if end < start:
        start, end = end, start

    try:
        bundle = load_flows_data(start, end)
    except Exception:
        logger.exception("load_flows_data failed")
        return _EMPTY

    edges_df, nodes_df = _filtered_edges_nodes(bundle, hour_block, weekday, view_mode)

    if edges_df is None or edges_df.empty:
        return _EMPTY

    edges_df, nodes_df = _apply_region_filter(edges_df, nodes_df, view_mode, region_filter)

    if edges_df.empty:
        return _EMPTY

    # For region view the spread graph falls back to flow colouring on edges
    # (no per-zone prices to compute spread against).
    spread_var = VARIABLE_FLOW if view_mode == VIEW_REGION else VARIABLE_SPREAD

    # ── Flow graph (left) — nodes annotated with net export ──────────────
    nodes_el_f,  node_ss_f  = _build_nodes(edges_df, nodes_df, view_mode, uniform_size=False, annotate="net_export")
    edges_el_f,  edge_ss_f  = _build_edges(edges_df, VARIABLE_FLOW)
    elements_f   = nodes_el_f + edges_el_f
    stylesheet_f = _base_stylesheet() + node_ss_f + edge_ss_f

    # ── Spread / price graph (right) — nodes annotated with spot price ───
    nodes_el_s,  node_ss_s  = _build_nodes(edges_df, nodes_df, view_mode, uniform_size=True, annotate="price")
    edges_el_s,  edge_ss_s  = _build_edges(edges_df, spread_var)
    elements_s   = nodes_el_s + edges_el_s
    stylesheet_s = _base_stylesheet() + node_ss_s + edge_ss_s

    return elements_f, stylesheet_f, elements_s, stylesheet_s
