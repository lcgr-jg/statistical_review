"""Flows page — core package."""
