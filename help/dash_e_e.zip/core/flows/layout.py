"""Layout for the Flows network dashboard (pure, no callbacks)."""
from __future__ import annotations

import datetime as dt

import dash_bootstrap_components as dbc
import dash_cytoscape as cyto
from dash import dcc, html

from core.styles import COLORS

from .constants import (
    DEFAULT_LOOKBACK_DAYS,
    HOUR_BLOCKS,
    REGIONS,
    VIEW_REGION,
    VIEW_ZONE,
)

_LABEL_STYLE = {"fontSize": "11px"}
_LABEL_CLASS = "small text-muted fw-bold text-uppercase"

_GRAPH_STYLE = {
    "backgroundColor": COLORS["chart_bg"],
    "borderRadius": "6px",
    "border": f"1px solid {COLORS['border']}",
    "padding": "4px",
}

_GRAPH_TITLE_STYLE = {
    "fontSize": "12px",
    "fontWeight": 600,
    "color": COLORS["text_primary"],
    "marginBottom": "6px",
    "paddingLeft": "4px",
}


def _label(text: str) -> html.Label:
    return html.Label(text, className=_LABEL_CLASS, style=_LABEL_STYLE)


def _cytoscape(graph_id: str) -> cyto.Cytoscape:
    # zoom=0.60 shows all of Europe in a half-width panel (~600 px wide).
    # wheelSensitivity=0.15 gives fine-grained scroll-zoom steps.
    return cyto.Cytoscape(
        id=graph_id,
        layout={"name": "preset", "fit": False},
        zoom=0.60,
        pan={"x": 20, "y": 10},
        style={
            "width": "100%",
            "height": "800px",
            "backgroundColor": COLORS["chart_bg"],
        },
        elements=[],
        stylesheet=[],
        responsive=True,
        autoungrabify=False,
        userPanningEnabled=True,
        userZoomingEnabled=True,
        minZoom=0.15,
        maxZoom=4.0,
        wheelSensitivity=0.15,
    )


def build_layout() -> html.Div:
    today = dt.date.today()
    default_start = today - dt.timedelta(days=DEFAULT_LOOKBACK_DAYS)
    all_regions = list(REGIONS.keys())
    return html.Div(
        style={"backgroundColor": COLORS["background"], "minHeight": "100vh"},
        children=[
            # ── Header / breadcrumb ─────────────────────────────────────
            html.Div(
                style={
                    "padding": "16px 22px",
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "backgroundColor": COLORS["card_bg"],
                },
                children=[
                    html.Div(
                        [
                            html.Span("Power", style={"color": "#888", "fontSize": "13px"}),
                            html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                            html.Span(
                                "Flows",
                                style={"fontWeight": "600", "color": COLORS["text_primary"]},
                            ),
                        ],
                    ),
                ],
            ),

            # ── Controls + charts ───────────────────────────────────────
            html.Div(
                style={"padding": "16px 22px"},
                children=[
                    # Controls row
                    dbc.Row(
                        [
                            # Date range
                            dbc.Col(
                                [
                                    _label("Date range"),
                                    dcc.DatePickerRange(
                                        id="flows-date-range",
                                        start_date=default_start,
                                        end_date=today,
                                        display_format="DD MMM YY",
                                        persistence=True,
                                        persistence_type="local",
                                        style={"fontSize": "12px"},
                                    ),
                                ],
                                width="auto",
                            ),
                            # Hour block / individual hour
                            dbc.Col(
                                [
                                    _label("Hour"),
                                    dcc.Dropdown(
                                        id="flows-hour-block",
                                        options=HOUR_BLOCKS,
                                        value="all",
                                        clearable=False,
                                        searchable=True,
                                        persistence=True,
                                        persistence_type="local",
                                        style={"minWidth": "200px", "fontSize": "13px"},
                                        optionHeight=28,
                                    ),
                                ],
                                width="auto",
                            ),
                            # Weekday filter
                            dbc.Col(
                                [
                                    _label("Days"),
                                    dbc.RadioItems(
                                        id="flows-weekday",
                                        options=[
                                            {"label": "All",     "value": "all"},
                                            {"label": "Weekday", "value": "wd"},
                                            {"label": "Weekend", "value": "we"},
                                        ],
                                        value="all",
                                        inline=True,
                                        persistence=True,
                                        persistence_type="local",
                                        className="mt-1",
                                    ),
                                ],
                                width="auto",
                            ),
                            # View mode
                            dbc.Col(
                                [
                                    _label("View"),
                                    dbc.RadioItems(
                                        id="flows-view",
                                        options=[
                                            {"label": "Zone",   "value": VIEW_ZONE},
                                            {"label": "Region", "value": VIEW_REGION},
                                        ],
                                        value=VIEW_ZONE,
                                        inline=True,
                                        persistence=True,
                                        persistence_type="local",
                                        className="mt-1",
                                    ),
                                ],
                                width="auto",
                            ),
                            # Region filter (multi-select)
                            dbc.Col(
                                [
                                    _label("Show regions"),
                                    dcc.Dropdown(
                                        id="flows-region-filter",
                                        options=[
                                            {"label": r, "value": r}
                                            for r in all_regions
                                        ],
                                        value=all_regions,   # all on by default
                                        multi=True,
                                        clearable=False,
                                        placeholder="All regions",
                                        persistence=True,
                                        persistence_type="local",
                                        style={
                                            "minWidth": "320px",
                                            "fontSize": "12px",
                                        },
                                    ),
                                ],
                                width="auto",
                            ),
                        ],
                        align="start",
                        className="g-3 mb-3 flex-wrap",
                    ),

                    # ── Side-by-side network graphs ─────────────────────
                    dbc.Row(
                        [
                            # Left: Net Commercial Flow
                            dbc.Col(
                                [
                                    html.Div(
                                        "Net Commercial Flow (MW)",
                                        style=_GRAPH_TITLE_STYLE,
                                    ),
                                    dcc.Loading(
                                        type="dot",
                                        color=COLORS["accent"],
                                        children=[
                                            html.Div(
                                                style=_GRAPH_STYLE,
                                                children=[_cytoscape("flows-graph-flow")],
                                            ),
                                        ],
                                    ),
                                ],
                                width=6,
                            ),
                            # Right: Price Spread
                            dbc.Col(
                                [
                                    html.Div(
                                        "Price Spread (EUR/MWh)",
                                        style=_GRAPH_TITLE_STYLE,
                                    ),
                                    dcc.Loading(
                                        type="dot",
                                        color=COLORS["accent"],
                                        children=[
                                            html.Div(
                                                style=_GRAPH_STYLE,
                                                children=[_cytoscape("flows-graph-spread")],
                                            ),
                                        ],
                                    ),
                                ],
                                width=6,
                            ),
                        ],
                        className="g-2",
                    ),
                ],
            ),
        ],
    )
