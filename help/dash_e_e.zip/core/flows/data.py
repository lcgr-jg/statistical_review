"""
Flows page — data loading and aggregation.

Loads three series for a date range:
  - NetCommercialFlowDayAhead  (hourly MW per directed border, columns 'de>fr', 'fr>de', ...)
  - PricePowerSpot             (hourly EUR/MWh, MultiIndex columns by zone)
  - NetExportDayAhead          (hourly MW per zone — for node sizing)

Caches the raw bundle (3-tier) and provides ``aggregate_flows`` to filter
and aggregate by hour-block / weekday / view-mode for the Cytoscape graph.
"""
from __future__ import annotations

import datetime as dt
import logging
from collections import OrderedDict
from typing import Any, Optional

import numpy as np
import pandas as pd

from core.flows.constants import (
    DC_PREFIX,
    DC_TTL,
    DEFAULT_LOOKBACK_DAYS,
    EXCLUDED_BORDER_PAIRS,
    EXCLUDED_ZONES,
    MAX_FLOWS_CACHE_ENTRIES,
    REGIONS,
    VIEW_REGION,
    VIEW_ZONE,
    ZONE_TO_REGION,
)

logger = logging.getLogger(__name__)

# ── jain_commods import guard ────────────────────────────────────────────
try:
    from jain_commods.core.cache.data.fundamentals import (  # type: ignore
        NetCommercialFlowDayAhead,
        NetExportDayAhead,
    )
    from jain_commods.core.cache.data.market import PricePowerSpot  # type: ignore
    _COMMODS = True
except ImportError as exc:
    logger.warning("jain_commods not available: %s", exc)
    _COMMODS = False

# ── Tier 1: in-memory LRU ────────────────────────────────────────────────
_FLOWS_CACHE: OrderedDict[str, dict] = OrderedDict()


def _cache_key(start: dt.date, end: dt.date) -> str:
    return f"{start.isoformat()}|{end.isoformat()}"


def _cache_put(key: str, bundle: dict) -> None:
    _FLOWS_CACHE[key] = bundle
    _FLOWS_CACHE.move_to_end(key)
    while len(_FLOWS_CACHE) > MAX_FLOWS_CACHE_ENTRIES:
        _FLOWS_CACHE.popitem(last=False)


# ── Tier 2: dashboard_cache (disk-backed) ────────────────────────────────

def _get_dc():
    """Lazy import of the shared dashboard_cache to avoid circular deps."""
    try:
        from core.cache import dashboard_cache  # noqa: PLC0415
        return dashboard_cache
    except Exception:
        return None


def _dc_key(start: dt.date, end: dt.date) -> str:
    return f"{DC_PREFIX}{start.isoformat()}_{end.isoformat()}"


def clear_flows_cache() -> None:
    """Clear both the in-memory LRU and the disk-backed dashboard_cache tier."""
    _FLOWS_CACHE.clear()
    dc = _get_dc()
    if dc is not None:
        try:
            dc.clear(prefix=DC_PREFIX)
            logger.info("Flows disk cache cleared (prefix=%s)", DC_PREFIX)
        except Exception as exc:
            logger.warning("Failed to clear flows disk cache: %s", exc)


# ── Helpers ───────────────────────────────────────────────────────────────

def _normalize_hourly_index(df: pd.DataFrame) -> pd.DataFrame:
    """
    Coerce the index to CET-naive hourly timestamps.

    Hour filtering (H00–H23, blocks) is expressed in CET/CEST — the standard
    market clock for European power.  Converting to UTC-naive (the old default)
    would mis-align selected hours by +1 h in winter or +2 h in summer.
    """
    if df is None or df.empty:
        return df
    out = df.copy()
    ix = pd.to_datetime(out.index)
    if ix.tz is None:
        # Assume UTC if tz-naive (jain_commods sometimes returns UTC-naive)
        ix = ix.tz_localize("UTC")
    ix = ix.tz_convert("Europe/Paris").tz_localize(None)  # CET/CEST naive
    out.index = ix
    return out


def _split_border_col(col: str) -> Optional[tuple[str, str]]:
    """Parse a 'src>dst' column name to (src, dst); returns None on failure."""
    if not isinstance(col, str) or ">" not in col:
        return None
    parts = col.split(">", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        return None
    return parts[0].strip().lower(), parts[1].strip().lower()


def _flatten_price_to_zone(price_df: pd.DataFrame) -> pd.DataFrame:
    """
    Reduce a multi-index PricePowerSpot frame to a single column per zone,
    averaging over exchange/currency/frequency dimensions if multiple exist.
    """
    if price_df is None or price_df.empty:
        return pd.DataFrame()
    if isinstance(price_df.columns, pd.MultiIndex):
        # First level is 'zone'
        zone_level = price_df.columns.get_level_values(0).astype(str).str.lower()
        out = pd.DataFrame(index=price_df.index)
        for zone in pd.unique(zone_level):
            mask = zone_level == zone
            sub = price_df.loc[:, mask]
            out[zone] = sub.mean(axis=1) if sub.shape[1] > 1 else sub.iloc[:, 0]
        return out
    out = price_df.copy()
    out.columns = [str(c).lower() for c in out.columns]
    return out


# ── Public loader ────────────────────────────────────────────────────────

def load_flows_data(
    start: Optional[dt.date] = None,
    end: Optional[dt.date] = None,
) -> dict[str, pd.DataFrame]:
    """
    Load and cache the raw hourly bundle for the Flows page.

    Returns a dict with keys:
        ``flow``       — DataFrame, columns 'src>dst', values MW (hourly)
        ``price``      — DataFrame, columns = zone, values EUR/MWh (hourly)
        ``net_export`` — DataFrame, columns = zone, values MW (hourly)
    """
    if end is None:
        end = dt.date.today()
    if start is None:
        start = end - dt.timedelta(days=DEFAULT_LOOKBACK_DAYS)

    key = _cache_key(start, end)

    # Tier 1: in-memory
    if key in _FLOWS_CACHE:
        _FLOWS_CACHE.move_to_end(key)
        logger.debug("Flows cache HIT (memory) %s", key)
        return _FLOWS_CACHE[key]

    # Tier 2: dashboard_cache (disk)
    dc = _get_dc()
    if dc is not None:
        try:
            cached = dc.get(_dc_key(start, end), ttl=DC_TTL)
            if cached is not None:
                logger.info("Flows cache HIT (disk) %s", key)
                _cache_put(key, cached)
                return cached
        except Exception as exc:
            logger.debug("Flows disk cache get failed: %s", exc)

    # Tier 3: S3
    logger.info("Flows cache MISS — loading from S3 (%s – %s)", start, end)

    bundle: dict[str, pd.DataFrame] = {
        "flow": pd.DataFrame(),
        "price": pd.DataFrame(),
        "net_export": pd.DataFrame(),
    }

    if not _COMMODS:
        logger.warning("jain_commods unavailable; returning empty flows bundle")
        return bundle

    # Day-ahead commercial flows
    try:
        ncf = NetCommercialFlowDayAhead()
        ncf.load(from_s3=True, show_metadata=False, start_date=start, end_date=end)
        flow_df = getattr(ncf, "data", None)
        if flow_df is not None and not flow_df.empty:
            bundle["flow"] = _normalize_hourly_index(flow_df)
    except Exception as exc:
        logger.warning("NetCommercialFlowDayAhead load failed: %s", exc)

    # Power spot prices
    try:
        pwr = PricePowerSpot(freq="h")
        pwr.load(from_s3=True, show_metadata=False, start_date=start, end_date=end)
        price_raw = getattr(pwr, "data", None)
        if price_raw is not None and not price_raw.empty:
            bundle["price"] = _normalize_hourly_index(_flatten_price_to_zone(price_raw))
    except Exception as exc:
        logger.warning("PricePowerSpot load failed: %s", exc)

    # Per-zone net export (for node sizing)
    try:
        ne = NetExportDayAhead()
        ne.load(from_s3=True, show_metadata=False, start_date=start, end_date=end)
        ne_df = getattr(ne, "data", None)
        if ne_df is not None and not ne_df.empty:
            ne_df = _normalize_hourly_index(ne_df)
            ne_df.columns = [str(c).lower() for c in ne_df.columns]
            bundle["net_export"] = ne_df
    except Exception as exc:
        logger.warning("NetExportDayAhead load failed: %s", exc)

    logger.info(
        "Flows data ready: flow=%d cols, price=%d zones, net_export=%d zones",
        bundle["flow"].shape[1] if not bundle["flow"].empty else 0,
        bundle["price"].shape[1] if not bundle["price"].empty else 0,
        bundle["net_export"].shape[1] if not bundle["net_export"].empty else 0,
    )

    # Store in both cache tiers
    _cache_put(key, bundle)
    if dc is not None and bundle["flow"].shape[1] > 0:
        try:
            dc.set(_dc_key(start, end), bundle, ttl=DC_TTL)
            logger.debug("Flows data written to disk cache %s ttl=%ds", key, DC_TTL)
        except Exception as exc:
            logger.warning("Flows disk cache set failed: %s", exc)

    return bundle


# ── Aggregation ──────────────────────────────────────────────────────────

def _hour_block_to_range(hour_block: str) -> Optional[tuple[int, int]]:
    """
    Parse an hour-selection value into an inclusive/exclusive (start, end) pair.

    Formats accepted:
        "all"   → None (no filter)
        "A-B"   → (A, B) — hours in [A, B)   e.g. "8-12"
        "hN"    → (N, N+1) — single hour N   e.g. "h14" → hours == 14 only
    Returns None if the value cannot be parsed (treated as "all").
    """
    if not hour_block or hour_block in ("all", "_sep_"):
        return None
    val = str(hour_block).strip()
    # Individual hour format: h0, h1, … h23
    if val.startswith("h") and not val[1:].startswith("-"):
        try:
            h = int(val[1:])
            return h, h + 1
        except (ValueError, IndexError):
            return None
    # Hour block format: "0-4", "8-12", etc.
    try:
        a, b = val.split("-", 1)
        return int(a), int(b)
    except Exception:
        return None


def _filter_index(
    df: pd.DataFrame, hour_block: str, weekday_only: bool
) -> pd.DataFrame:
    """Return a copy of df with index filtered by hour-block and weekday."""
    if df is None or df.empty:
        return df
    out = df
    hb = _hour_block_to_range(hour_block)
    if hb is not None:
        h0, h1 = hb
        out = out.loc[(out.index.hour >= h0) & (out.index.hour < h1)]
    if weekday_only:
        out = out.loc[out.index.dayofweek < 5]
    return out


def _drop_excluded_borders(flow_df: pd.DataFrame) -> pd.DataFrame:
    """
    Drop columns corresponding to:
    - Non-physical / phantom border pairs listed in ``EXCLUDED_BORDER_PAIRS``.
    - Any border that touches a zone listed in ``EXCLUDED_ZONES`` (e.g. the
      legacy aggregate "it" zone, superseded by IT subzones).
    Columns are removed at the source so other connected zones remain in the graph.
    """
    if flow_df is None or flow_df.empty:
        return flow_df
    keep_cols = []
    for col in flow_df.columns:
        parsed = _split_border_col(str(col))
        if parsed is None:
            keep_cols.append(col)
            continue
        src, dst = parsed
        if frozenset(parsed) in EXCLUDED_BORDER_PAIRS:
            continue
        if src in EXCLUDED_ZONES or dst in EXCLUDED_ZONES:
            continue
        keep_cols.append(col)
    return flow_df[keep_cols] if len(keep_cols) != flow_df.shape[1] else flow_df


def _aggregate_zone_view(
    flow_df: pd.DataFrame, price_df: pd.DataFrame
) -> pd.DataFrame:
    """
    Build a long-format DataFrame at zone granularity.
    Columns: src, dst, flow_mw, price_spread, n_obs

    Each bilateral border pair (A, B) produces exactly ONE edge in the dominant
    flow direction.  If the data supplies both A>B and B>A columns (as ENTSO-E
    often does with mirrored signs), the two are netted and only the positive
    direction is kept.
    """
    if flow_df is None or flow_df.empty:
        return pd.DataFrame(columns=["src", "dst", "flow_mw", "price_spread", "n_obs"])

    means = flow_df.mean(axis=0, skipna=True)
    counts = flow_df.notna().sum(axis=0)

    rows = []
    for col, mw in means.items():
        if pd.isna(mw):
            continue
        parsed = _split_border_col(col)
        if parsed is None:
            continue
        src, dst = parsed
        spread = np.nan
        if not price_df.empty and src in price_df.columns and dst in price_df.columns:
            ps = price_df[dst] - price_df[src]
            spread = float(ps.mean(skipna=True))
        rows.append({
            "src": src,
            "dst": dst,
            "flow_mw": float(mw),
            "price_spread": spread,
            "n_obs": int(counts.get(col, 0)),
        })

    # ── Net each border pair into a single directed edge ─────────────────
    # Sort descending so the larger (more positive) side of each pair is seen
    # first.  For each frozenset{A, B} we keep exactly one row; if the
    # representative row has negative flow we flip the direction.
    rows_sorted = sorted(rows, key=lambda r: r["flow_mw"], reverse=True)
    seen_pairs: set[frozenset] = set()
    deduped: list[dict] = []
    for row in rows_sorted:
        pair: frozenset = frozenset([row["src"], row["dst"]])
        if pair in seen_pairs:
            continue
        seen_pairs.add(pair)
        if row["flow_mw"] >= 0:
            deduped.append(row)
        else:
            # Only one direction present and it's negative → flip src/dst
            deduped.append({
                "src": row["dst"],
                "dst": row["src"],
                "flow_mw": -row["flow_mw"],
                "price_spread": (
                    -row["price_spread"]
                    if np.isfinite(row["price_spread"])
                    else np.nan
                ),
                "n_obs": row["n_obs"],
            })

    return pd.DataFrame(deduped)


def _aggregate_region_view(
    flow_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Aggregate hourly bilateral flows to inter-region totals, then take the
    mean over the filtered hours.

    Drops intra-region flows (e.g., no2>no5 within Nordics).
    """
    cols = ["src", "dst", "flow_mw", "price_spread", "n_obs"]
    if flow_df is None or flow_df.empty:
        return pd.DataFrame(columns=cols)

    # Sum hourly flows per inter-region pair
    region_flow = pd.DataFrame(index=flow_df.index)
    for col in flow_df.columns:
        parsed = _split_border_col(str(col))
        if parsed is None:
            continue
        src_z, dst_z = parsed
        src_r = ZONE_TO_REGION.get(src_z)
        dst_r = ZONE_TO_REGION.get(dst_z)
        if src_r is None or dst_r is None or src_r == dst_r:
            continue
        rkey = f"{src_r}>{dst_r}"
        if rkey in region_flow.columns:
            region_flow[rkey] = region_flow[rkey].add(flow_df[col], fill_value=0.0)
        else:
            region_flow[rkey] = flow_df[col].astype(float)

    if region_flow.empty:
        return pd.DataFrame(columns=cols)

    means = region_flow.mean(axis=0, skipna=True)
    counts = region_flow.notna().sum(axis=0)

    rows = []
    for rk, mw in means.items():
        if pd.isna(mw):
            continue
        parsed = _split_border_col(rk)
        if parsed is None:
            continue
        src, dst = parsed
        rows.append({
            "src": src,
            "dst": dst,
            "flow_mw": float(mw),
            "price_spread": np.nan,   # spreads not meaningful at region level
            "n_obs": int(counts.get(rk, 0)),
        })

    # Net each region pair into a single directed edge (same logic as zone view)
    rows_sorted = sorted(rows, key=lambda r: r["flow_mw"], reverse=True)
    seen_pairs: set[frozenset] = set()
    deduped: list[dict] = []
    for row in rows_sorted:
        pair: frozenset = frozenset([row["src"], row["dst"]])
        if pair in seen_pairs:
            continue
        seen_pairs.add(pair)
        if row["flow_mw"] >= 0:
            deduped.append(row)
        else:
            deduped.append({
                "src": row["dst"],
                "dst": row["src"],
                "flow_mw": -row["flow_mw"],
                "price_spread": np.nan,
                "n_obs": row["n_obs"],
            })
    return pd.DataFrame(deduped)


def aggregate_flows(
    bundle: dict[str, pd.DataFrame],
    hour_block: str,
    weekday_only: bool,
    view_mode: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Filter the raw bundle and aggregate to a per-edge DataFrame.

    Returns ``(edges_df, node_df)`` where:
      * edges_df has columns: src, dst, flow_mw, price_spread, n_obs
      * node_df  has columns: zone, mean_price, mean_net_export
        (zone view only — empty for region view)
    """
    raw_flow = _drop_excluded_borders(bundle.get("flow", pd.DataFrame()))
    flow_filt = _filter_index(raw_flow, hour_block, weekday_only)
    price_filt = _filter_index(bundle.get("price", pd.DataFrame()), hour_block, weekday_only)
    ne_filt = _filter_index(bundle.get("net_export", pd.DataFrame()), hour_block, weekday_only)

    if view_mode == VIEW_REGION:
        edges = _aggregate_region_view(flow_filt)
        nodes = pd.DataFrame(columns=["zone", "mean_price", "mean_net_export"])
    else:
        edges = _aggregate_zone_view(flow_filt, price_filt)
        # Build node-level stats
        zone_set: set[str] = set()
        if not edges.empty:
            zone_set.update(edges["src"].tolist())
            zone_set.update(edges["dst"].tolist())
        node_rows = []
        for z in sorted(zone_set):
            mp = float(price_filt[z].mean(skipna=True)) if (not price_filt.empty and z in price_filt.columns) else np.nan
            mn = float(ne_filt[z].mean(skipna=True)) if (not ne_filt.empty and z in ne_filt.columns) else np.nan
            node_rows.append({"zone": z, "mean_price": mp, "mean_net_export": mn})
        nodes = pd.DataFrame(node_rows)

    return edges, nodes
