"""Static configuration for the Flows network dashboard."""
from __future__ import annotations

# ── Page metadata ─────────────────────────────────────────────────────────
PAGE_PATH = "/power/flows"
PAGE_NAME = "Flows"
PAGE_TITLE = "Flows | JG Power Dashboard"
PAGE_ORDER = 20

# ── Regional groupings (mirrors EPEX Day-Ahead auction page) ─────────────
REGIONS = {
    "CWE":     ["de", "fr", "nl", "be", "at", "ch", "lu"],
    "Iberia":  ["es", "pt"],
    "UK+IE":   ["gb", "nie", "ie"],
    "Nordics": ["no1", "no2", "no3", "no4", "no5",
                "se1", "se2", "se3", "se4",
                "fi", "dk1", "dk2"],
    "CEE":     ["pl", "cz", "hu", "sk"],
    "SEE":     ["ro", "gr", "rs", "bg", "hr", "si", "ba", "me", "al", "mk", "xk"],
    "Italy":   ["it-nord", "it-cnor", "it-csud", "it-sud",
                "it-cala", "it-sici", "it-sard"],
}

# Reverse lookup: zone -> region
ZONE_TO_REGION: dict[str, str] = {
    z: region for region, zones in REGIONS.items() for z in zones
}

# ── Geographic coordinates (lon, lat) ─────────────────────────────────────
# Used to position nodes on the Cytoscape graph in a map-like layout.
# Dense clusters (Balkans, Nordics, Baltics, Italian zones) have been manually
# spread beyond true centroids to prevent node overlap at the chosen scale.
ZONE_COORDS: dict[str, tuple[float, float]] = {
    # CWE
    "de":  (10.4,  51.2),  "fr":  (2.2,   46.2),  "nl":  (5.3,   52.4),
    "be":  (4.5,   50.5),  "at":  (14.5,  47.5),  "ch":  (8.2,   47.0),
    "lu":  (6.1,   49.8),
    # CEE
    "pl":  (19.1,  52.0),  "cz":  (15.5,  49.8),
    "hu":  (19.5,  47.2),  "sk":  (19.1,  48.7),
    # SEE / Balkans — manually spread to prevent overlap
    "si":  (14.5,  46.5),  "hr":  (16.5,  46.0),
    "ba":  (17.5,  44.5),  "rs":  (22.0,  45.8),
    "me":  (19.0,  43.2),  "xk":  (21.5,  42.5),
    "al":  (19.5,  40.8),  "mk":  (24.0,  42.0),
    "bg":  (26.5,  43.0),  "ro":  (25.5,  46.5),
    "gr":  (22.5,  39.5),
    # Eastern neighbours
    "md":  (29.0,  47.5),                           # Moldova
    "ua":  (31.5,  49.0),                           # Ukraine
    "tr":  (34.0,  39.5),                           # Turkey
    "by":  (27.5,  53.5),                           # Belarus
    # Iberia
    "es":  (-3.7,  40.5),  "pt":  (-8.5,  39.4),
    # UK + IE + NIE (Northern Ireland sits between GB and IE)
    "gb":  (-2.5,  53.5),  "nie": (-6.0,  54.6),  "ie":  (-8.2,  53.3),
    # Nordic price areas — spread to eliminate overlap
    "no1": (10.5,  59.9),   # Oslo / South-East
    "no2": (5.5,   58.5),   # Stavanger / South-West  (separated from NO5)
    "no3": (10.0,  63.5),   # Trondheim / Central
    "no4": (18.5,  68.5),   # Tromsø / North
    "no5": (4.0,   61.5),   # Bergen / West           (separated from NO2)
    "se1": (21.5,  67.5),   # Luleå / North Sweden
    "se2": (17.0,  64.0),   # Sundsvall / North-Central
    "se3": (18.5,  59.5),   # Stockholm / Central
    "se4": (15.5,  56.5),   # Malmö / South Sweden    (separated from DK2)
    # SE aliases sometimes used in older data sources
    "sf1": (21.5,  67.5),  "sf2": (17.0,  64.0),
    "sf3": (18.5,  59.5),  "sf4": (15.5,  56.5),
    "fi":  (26.5,  63.0),   # Finland
    "dk1": (9.0,   56.5),   # West Denmark
    "dk2": (11.5,  55.5),   # East Denmark / Zealand  (separated from SE4)
    # Baltics — staggered to avoid overlap
    "ee":  (25.5,  59.2),   # Estonia
    "lv":  (25.0,  57.0),   # Latvia
    "lt":  (24.0,  55.0),   # Lithuania
    # Italian price areas — spread along the peninsula with extra separation.
    # Each variant (hyphen, underscore, space, no-separator) maps to the same position
    # so any naming convention used by the underlying ENTSO-E data will resolve.
    "it-nord": (10.5, 45.5),   # Northern Italy (Milan / Po Valley)
    "it-cnor": (11.5, 43.8),   # Central-North  (Florence / Tuscany)
    "it-csud": (13.5, 41.2),   # Central-South  (Rome / Lazio)
    "it-sud":  (15.8, 40.5),   # Southern Italy (Naples / Puglia)
    "it-cala": (16.2, 38.5),   # Calabria       (Reggio Calabria — toe of Italy)
    "it-bri":  (18.0, 40.6),   # Brindisi / Puglia tip
    "it-sici": (13.5, 37.5),   # Sicily
    "it-sard": (8.5,  40.0),   # Sardinia
    # Underscore variants
    "it_nord": (10.5, 45.5),   "it_cnor": (11.5, 43.8),
    "it_csud": (13.5, 41.2),   "it_sud":  (15.8, 40.5),
    "it_cala": (16.2, 38.5),   "it_bri":  (18.0, 40.6),
    "it_sici": (13.5, 37.5),   "it_sard": (8.5,  40.0),
    # Short-form and no-separator variants sometimes seen in older exports
    "it-cal":  (16.2, 38.5),   "it_cal":  (16.2, 38.5),
    "itcala":  (16.2, 38.5),   "itnord":  (10.5, 45.5),
    "itcnor":  (11.5, 43.8),   "itcsud":  (13.5, 41.2),
    "itsud":   (15.8, 40.5),   "itsici":  (13.5, 37.5),
    "itsard":  (8.5,  40.0),
    # Italy as a whole (some data uses plain "it")
    "it": (12.5, 43.0),
}

# Region centroids — for the aggregated region view.
# Deliberately spread so no two labels/nodes overlap at the chosen scale.
REGION_COORDS: dict[str, tuple[float, float]] = {
    "Nordics": (14.0,  65.0),   # Scandinavia / Nordic countries (north)
    "UK+IE":   (-3.0,  54.5),   # British Isles (west, mid-latitude)
    "CWE":     (7.5,   49.5),   # Central-West Europe (France/Germany/Benelux)
    "Iberia":  (-5.0,  40.0),   # Iberian Peninsula (south-west)
    "CEE":     (20.0,  51.0),   # Central-East Europe (Poland/CZ/HU/SK)
    "SEE":     (23.0,  43.5),   # South-East Europe / Balkans
    "Italy":   (12.5,  42.5),   # Italian peninsula
}

# Coordinate-to-pixel scaling for the Cytoscape preset layout.
# Tuned so the full ENTSO-E zone extent fits within roughly 1050 × 800 px
# (graph canvas is 820 px tall; users can pan left/right for eastern zones).
#   x = COORD_X_OFFSET + lon * COORD_X_SCALE
#   y = COORD_Y_OFFSET + (75 - lat) * COORD_Y_SCALE   (lat→screen, north=top)
COORD_X_SCALE = 26      # px per degree of longitude
COORD_Y_SCALE = 17      # px per degree of latitude
COORD_X_OFFSET = 240    # left-margin offset  (lon ≈ -10° → x ≈ 0)
COORD_Y_OFFSET = 15     # top-margin offset   (lat ≈ 72° → y ≈ 66)

# ── Hour-block options ───────────────────────────────────────────────────
# Encoded as:
#   "all"   → no filter
#   "A-B"   → hours in [A, B)  e.g. "0-4" = hours 0,1,2,3
#   "hN"    → single hour N    e.g. "h14" = hour 14 only
HOUR_BLOCKS = [
    # ── blocks ────────────────────────────────────────────────────────
    {"label": "All hours",          "value": "all"},
    {"label": "Night    H00–H04",   "value": "0-4"},
    {"label": "Early    H04–H08",   "value": "4-8"},
    {"label": "Morning  H08–H12",   "value": "8-12"},
    {"label": "Midday   H12–H16",   "value": "12-16"},
    {"label": "Evening  H16–H20",   "value": "16-20"},
    {"label": "Late     H20–H24",   "value": "20-24"},
    # ── individual hours (disabled header) ────────────────────────────
    {"label": "─── Individual hours ───", "value": "_sep_", "disabled": True},
] + [
    {"label": f"H{h:02d}  ({h:02d}:00 – {(h+1):02d}:00)", "value": f"h{h}"}
    for h in range(24)
]

# ── Variable options ──────────────────────────────────────────────────────
VARIABLE_FLOW = "flow"
VARIABLE_SPREAD = "spread"

# ── View mode options ─────────────────────────────────────────────────────
VIEW_ZONE = "zone"
VIEW_REGION = "region"

# ── Default date range ────────────────────────────────────────────────────
DEFAULT_LOOKBACK_DAYS = 30

# ── Cache configuration ───────────────────────────────────────────────────
MAX_FLOWS_CACHE_ENTRIES = 6
DC_PREFIX = "flows_data:"
DC_TTL = 14_400  # 4 hours

# ── Edge / node visual scaling ────────────────────────────────────────────
EDGE_WIDTH_MIN = 1.5
EDGE_WIDTH_MAX = 10.0
NODE_SIZE_MIN = 12.0
NODE_SIZE_MAX = 30.0

# ── Hardcoded border exclusions ──────────────────────────────────────────
# ENTSO-E declares columns for non-physical / decommissioned border pairs
# that carry ~0 MW.  List them here as frozensets so both directions are
# covered.  Add extra entries if new phantom edges appear in the data.
EXCLUDED_BORDER_PAIRS: frozenset[frozenset] = frozenset(
    [
        frozenset(["no4", "no5"]),   # not physically connected
        frozenset(["se1", "dk1"]),   # SE1 connects to SE2/NO4/NO3/FI, not DK1
    ]
)

# Zones to suppress entirely from the graph.
# "it" is the legacy aggregate Italy zone — now replaced by subzones (it-nord … it-sard).
EXCLUDED_ZONES: frozenset[str] = frozenset(["it"])
