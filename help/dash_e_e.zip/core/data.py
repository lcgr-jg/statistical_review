"""
Single data-service entry point for every page.

All pages should call ``core.data.get_<name>()`` instead of:
    - importing loader functions from ``pages.*`` directly,
    - calling ``dashboard_cache.get_data(...)`` with a stringly-typed name,
    - reaching into module-level globals like ``_shared_data`` or
      ``_data_loaded``.

Underneath, every accessor is a thin wrapper around
``dashboard_cache.get_data(name)`` so:
    - the central scheduler in ``portal_app._setup_scheduler`` owns refresh
      cadence + TTL,
    - there is exactly one cache (``dashboard_cache``) for raw data and one
      cache (``fast_cache``) for pre-built figure bytes.

Source-name table (must stay in sync with ``portal_app._setup_scheduler``):

    price_data            - Prices dashboard bundle (~60 s)
    fuel_switching_data   - MarketDataCache populated from S3 (~7 s)
    french_nuclear_data   - EDF availability (~4 s)
    fundamentals_data     - Availability + generation (~30 s)
    forecast_data         - Weather/SCI forecast pre-cache marker
    epex_spot             - Today's EPEX spot prices
    ttf_spreads_data      - TTF spreads rolling histories + stats (~30-60 s)
    low_beta_spreads_data - Low-beta spread universe + FM regressions (~30-60 s)
    lng_netbacks_data     - US LNG netbacks panel (ICE + Platts, ~15-30 s)
"""

from __future__ import annotations

from typing import Any, Optional

from core.cache import dashboard_cache


# Canonical source names. Centralising avoids typos at call sites.
SOURCE_PRICES = "price_data"
SOURCE_FUEL_SWITCHING = "fuel_switching_data"
SOURCE_FRENCH_NUCLEAR = "french_nuclear_data"
SOURCE_FUNDAMENTALS = "fundamentals_data"
SOURCE_FORECASTS = "forecast_data"
SOURCE_EPEX = "epex_spot"
SOURCE_TTF_SPREADS = "ttf_spreads_data"
SOURCE_LOW_BETA_SPREADS = "low_beta_spreads_data"
SOURCE_LNG_NETBACKS = "lng_netbacks_data"

ALL_SOURCES = (
    SOURCE_PRICES,
    SOURCE_FUEL_SWITCHING,
    SOURCE_FRENCH_NUCLEAR,
    SOURCE_FUNDAMENTALS,
    SOURCE_FORECASTS,
    SOURCE_EPEX,
    SOURCE_TTF_SPREADS,
    SOURCE_LOW_BETA_SPREADS,
    SOURCE_LNG_NETBACKS,
)


# ---------------------------------------------------------------------------
# Typed accessors
# ---------------------------------------------------------------------------

def get_prices() -> Optional[Any]:
    """Prices dashboard bundle (CSS/DSS, flat price, XB spreads, base/peak, spot)."""
    return dashboard_cache.get_data(SOURCE_PRICES)


def get_fuel_switching() -> Optional[Any]:
    """``MarketDataCache`` instance for the Fuel Switching page.

    Returned object exposes ``.last_refresh``, ``.is_loading``,
    ``.get_forward_data(...)``, ``.get_spot_data(...)`` etc.
    """
    return dashboard_cache.get_data(SOURCE_FUEL_SWITCHING)


def get_french_nuclear() -> Optional[Any]:
    """French nuclear availability bundle (model + base_df)."""
    return dashboard_cache.get_data(SOURCE_FRENCH_NUCLEAR)


def get_fundamentals() -> Optional[Any]:
    """Fundamentals (availability, generation, weather) data handler."""
    return dashboard_cache.get_data(SOURCE_FUNDAMENTALS)


def get_forecasts() -> Optional[Any]:
    """Forecast pre-cache marker (data lives in the underlying forecast caches)."""
    return dashboard_cache.get_data(SOURCE_FORECASTS)


def get_epex() -> Optional[Any]:
    """Today's EPEX day-ahead auction prices."""
    return dashboard_cache.get_data(SOURCE_EPEX)


def get_ttf_spreads() -> Optional[Any]:
    """TTF spreads payload (per-spread rolling histories + default stats).

    See ``core.ttf_spreads.data.load_ttf_spreads_data`` for the dict schema.
    """
    return dashboard_cache.get_data(SOURCE_TTF_SPREADS)


def get_low_beta_spreads() -> Optional[Any]:
    """Low-beta spreads payload (spread universe histories + FM regressors).

    See ``core.low_beta_spreads.data.load_low_beta_spreads_data`` for the
    dict schema.
    """
    return dashboard_cache.get_data(SOURCE_LOW_BETA_SPREADS)


def get_lng_netbacks() -> Optional[Any]:
    """US LNG netbacks payload (forward/spot panels + Platts history).

    See ``core.lng_netbacks.data.load_lng_netbacks_data`` for the dict schema.
    """
    return dashboard_cache.get_data(SOURCE_LNG_NETBACKS)


# ---------------------------------------------------------------------------
# Lifecycle helpers
# ---------------------------------------------------------------------------

def is_loaded(source_name: str) -> bool:
    """Return True if *source_name* has data in the cache right now."""
    return dashboard_cache.get_data(source_name) is not None


def force_refresh(source_name: str) -> None:
    """Trigger an immediate refresh for *source_name* (synchronous)."""
    dashboard_cache.force_refresh(source_name)


def last_refresh(source_name: str):
    """Datetime of last successful refresh, or None."""
    return dashboard_cache.get_last_refresh(source_name)


__all__ = [
    "SOURCE_PRICES",
    "SOURCE_FUEL_SWITCHING",
    "SOURCE_FRENCH_NUCLEAR",
    "SOURCE_FUNDAMENTALS",
    "SOURCE_FORECASTS",
    "SOURCE_EPEX",
    "SOURCE_TTF_SPREADS",
    "SOURCE_LOW_BETA_SPREADS",
    "SOURCE_LNG_NETBACKS",
    "ALL_SOURCES",
    "get_prices",
    "get_fuel_switching",
    "get_french_nuclear",
    "get_fundamentals",
    "get_forecasts",
    "get_epex",
    "get_ttf_spreads",
    "get_low_beta_spreads",
    "get_lng_netbacks",
    "is_loaded",
    "force_refresh",
    "last_refresh",
]
