"""
Pure analytics over the EDF v2 nuclear outage versions.

Every function takes DataFrames / timestamps and returns DataFrames; no I/O
or Dash.  Timestamps in the store are tz-aware UTC; outputs meant for charts
use naive Europe/Paris local time, which is how the market quotes delivery.

Availability of a unit at an hour = its capacity, or the lowest available MW
among the outage versions valid at the as-of time that cover that hour.
Versions whose current status is cancelled/deleted contribute nothing.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from core.french_nuclear.unit_delta import PALIER_ORDER, classify_palier

PARIS = "Europe/Paris"
HOUR = pd.Timedelta(hours=1)
DAY = pd.Timedelta(days=1)
REMOVED_STATUSES = ("cancelled", "deleted")
# An outage counts as offline when less than this share of capacity is available.
OFFLINE_SHARE = 0.1


# -----------------------------------------------------------------------------
# Units and time helpers
# -----------------------------------------------------------------------------
def palier(unit: str) -> str:
    """Reactor series; Flamanville 3 is the EPR (classify_palier maps the site to P4)."""
    if str(unit).upper().startswith("FLAMANVILLE 3"):
        return "EPR"
    return classify_palier(unit)


def unit_order(units: Iterable[str]) -> List[str]:
    """Units grouped by palier (fleet order), then by name."""
    rank = {p: i for i, p in enumerate(PALIER_ORDER)}
    return sorted(units, key=lambda u: (rank.get(palier(u), len(rank)), u))


def paris_day_start_utc(d: date) -> pd.Timestamp:
    return pd.Timestamp(d).tz_localize(PARIS).tz_convert("UTC")


def to_paris_naive(ts: pd.Series | pd.Timestamp):
    if isinstance(ts, pd.Series):
        return ts.dt.tz_convert(PARIS).dt.tz_localize(None)
    return ts.tz_convert(PARIS).tz_localize(None)


def as_of_for_day(d: date, now_utc: pd.Timestamp) -> pd.Timestamp:
    """As-of instant for a calendar day: end of that Paris day, capped at now."""
    return min(paris_day_start_utc(d + timedelta(days=1)), now_utc)


# -----------------------------------------------------------------------------
# Snapshots
# -----------------------------------------------------------------------------
def snapshot(versions: pd.DataFrame, as_of_utc: pd.Timestamp) -> pd.DataFrame:
    """One row per outage: the version current at ``as_of_utc``, removed outages dropped."""
    v = versions
    live = (v["valid_from_utc"] <= as_of_utc) & (
        v["valid_to_utc"].isna() | (v["valid_to_utc"] > as_of_utc)
    )
    snap = v.loc[live]
    return snap.loc[~snap["status"].isin(REMOVED_STATUSES)]


def _unavailable_mw(df: pd.DataFrame, capacity: pd.Series) -> pd.Series:
    cap = df["unit_name"].map(capacity)
    avail = df["capacity_available_mw"].fillna(0.0).clip(lower=0.0)
    return (cap - avail.clip(upper=cap)).clip(lower=0.0)


# -----------------------------------------------------------------------------
# Availability grid
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class DailyAvailability:
    """Daily mean MW per unit (index = Paris-local day, columns = units)."""

    avail: pd.DataFrame
    planned_unavail: pd.DataFrame
    forced_unavail: pd.DataFrame
    capacity: pd.Series
    as_of_utc: pd.Timestamp

    @property
    def total_gw(self) -> pd.Series:
        return self.avail.sum(axis=1) / 1e3

    def window_mean_gw(self, start: date, end: date) -> float:
        """Mean fleet availability over Paris days [start, end)."""
        s = self.total_gw
        s = s[(s.index >= pd.Timestamp(start)) & (s.index < pd.Timestamp(end))]
        return float(s.mean()) if len(s) else float("nan")


def daily_availability(
    versions: pd.DataFrame,
    capacity: pd.Series,
    as_of_utc: pd.Timestamp,
    start_day: date,
    end_day: date,
) -> DailyAvailability:
    """Availability as known at ``as_of_utc`` for Paris days [start_day, end_day]."""
    start = paris_day_start_utc(start_day)
    end = paris_day_start_utc(end_day + timedelta(days=1))
    hours = pd.date_range(start, end, freq="h", inclusive="left")
    units = list(capacity.index)
    cap = capacity.to_numpy(dtype=float)
    n = len(hours)

    avail = np.repeat(cap[:, None], n, axis=1)
    cause = np.zeros(avail.shape, dtype=np.int8)  # 0 none, 1 planned, 2 forced

    snap = snapshot(versions, as_of_utc)
    snap = snap[
        (snap["end_utc"] > start) & (snap["start_utc"] < end) & snap["unit_name"].isin(units)
    ]
    if len(snap):
        uidx = pd.Index(units).get_indexer(snap["unit_name"])
        a = np.floor((snap["start_utc"] - start) / HOUR).to_numpy().clip(0, n).astype(int)
        b = np.ceil((snap["end_utc"] - start) / HOUR).to_numpy().clip(0, n).astype(int)
        mw = snap["capacity_available_mw"].fillna(0.0).to_numpy().clip(0.0, cap[uidx])
        code = np.where(snap["outage_type_norm"].str.startswith("forced"), 2, 1).astype(np.int8)
        for i, lo, hi, m, c in zip(uidx, a, b, mw, code):
            if lo >= hi:
                continue
            seg, cseg = avail[i, lo:hi], cause[i, lo:hi]
            lower = m < seg
            seg[lower] = m
            cseg[lower] = c

    unav = cap[:, None] - avail
    day = hours.tz_convert(PARIS).tz_localize(None).normalize()

    def _daily(arr: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(arr.T, index=day, columns=units).groupby(level=0).mean()

    return DailyAvailability(
        avail=_daily(avail),
        planned_unavail=_daily(np.where(cause == 1, unav, 0.0)),
        forced_unavail=_daily(np.where(cause == 2, unav, 0.0)),
        capacity=capacity,
        as_of_utc=as_of_utc,
    )


def fleet_status_at(versions: pd.DataFrame, capacity: pd.Series, t_utc: pd.Timestamp) -> dict:
    """Instantaneous fleet picture at ``t_utc`` as known at ``t_utc``."""
    snap = snapshot(versions, t_utc)
    on = snap[(snap["start_utc"] <= t_utc) & (snap["end_utc"] > t_utc)]
    on = on.assign(unav=_unavailable_mw(on, capacity))
    per_unit = on.sort_values("unav").groupby("unit_name").last()
    unav = per_unit["unav"].reindex(capacity.index).fillna(0.0)
    forced = per_unit.loc[per_unit["outage_type_norm"].str.startswith("forced"), "unav"].sum()
    offline = int(((capacity - unav) < capacity * OFFLINE_SHARE).sum())
    return {
        "available_gw": float((capacity - unav).sum() / 1e3),
        "capacity_gw": float(capacity.sum() / 1e3),
        "forced_gw": float(forced / 1e3),
        "units_offline": offline,
        "units_total": int(len(capacity)),
    }


# -----------------------------------------------------------------------------
# Delivery buckets
# -----------------------------------------------------------------------------
def _month_add(d: date, n: int) -> date:
    y, m = divmod(d.month - 1 + n, 12)
    return date(d.year + y, m + 1, 1)


def delivery_buckets(today: date) -> List[Tuple[str, date, date]]:
    """Traded delivery periods as (label, first day, day after last), Paris days."""
    tomorrow = today + timedelta(days=1)
    next_monday = today + timedelta(days=7 - today.weekday())
    m1 = _month_add(today, 1)
    q_start = date(today.year, 3 * ((today.month - 1) // 3) + 1, 1)
    out = [("DA", tomorrow, tomorrow + timedelta(days=1)),
           ("WkA", next_monday, next_monday + timedelta(days=7))]
    if tomorrow < m1:
        out.append(("BOM", tomorrow, m1))
    for k in range(1, 4):
        s = _month_add(today, k)
        out.append((s.strftime("%b-%y"), s, _month_add(s, 1)))
    for k in (1, 2):
        s = _month_add(q_start, 3 * k)
        out.append((f"Q{(s.month - 1) // 3 + 1}-{s:%y}", s, _month_add(s, 3)))
    cal = date(today.year + 1, 1, 1)
    out.append((f"Cal-{cal:%y}", cal, date(cal.year + 1, 1, 1)))
    return out


def bucket_changes(
    new: DailyAvailability, ref: DailyAvailability, buckets: List[Tuple[str, date, date]]
) -> pd.DataFrame:
    """Mean MW change per unit and bucket (rows = bucket labels, columns = units)."""
    diff = new.avail.sub(ref.avail, fill_value=0.0)
    rows = {}
    for label, s, e in buckets:
        part = diff[(diff.index >= pd.Timestamp(s)) & (diff.index < pd.Timestamp(e))]
        if len(part):
            rows[label] = part.mean()
    return pd.DataFrame(rows).T


# -----------------------------------------------------------------------------
# What changed between two as-of times
# -----------------------------------------------------------------------------
def _future_gwh(start, end, unav_mw, from_utc, to_utc) -> pd.Series:
    lo = start.where(start > from_utc, from_utc)
    hi = end.where(end < to_utc, to_utc)
    hours = ((hi - lo) / HOUR).clip(lower=0.0).fillna(0.0)
    return hours * unav_mw.fillna(0.0) / 1e3


def outage_changes(
    versions: pd.DataFrame,
    capacity: pd.Series,
    ref_utc: pd.Timestamp,
    new_utc: pd.Timestamp,
    horizon_utc: pd.Timestamp,
) -> pd.DataFrame:
    """
    Net change per outage between the versions current at ``ref_utc`` and
    ``new_utc``, for outages with at least one publication in between.

    ``delta_gwh`` is the change in unavailable energy still to be delivered
    in [new_utc, horizon_utc]; positive means less nuclear (bullish power).
    """
    pub = versions["published_utc"]
    touched = versions.loc[(pub > ref_utc) & (pub <= new_utc)]
    if touched.empty:
        return pd.DataFrame()
    ids = touched["outage_id"].unique()
    n_rev = touched.groupby("outage_id").size()
    cols = ["outage_id", "unit_name", "outage_type_norm", "cause", "status", "start_utc",
            "end_utc", "capacity_available_mw", "version", "published_utc", "comment"]
    old = snapshot(versions, ref_utc)
    old = old.loc[old["outage_id"].isin(ids), cols].set_index("outage_id")
    new = snapshot(versions, new_utc)
    new = new.loc[new["outage_id"].isin(ids), cols].set_index("outage_id")
    last = touched.sort_values("version").groupby("outage_id").last()

    df = pd.DataFrame(index=pd.Index(ids, name="outage_id"))
    df = df.join(old.add_suffix("_old")).join(new.add_suffix("_new"))
    df["unit_name"] = df["unit_name_new"].fillna(df["unit_name_old"]).fillna(last["unit_name"])
    df["outage_type_norm"] = (
        df["outage_type_norm_new"].fillna(df["outage_type_norm_old"]).fillna(last["outage_type_norm"])
    )
    df["cause"] = df["cause_new"].fillna(df["cause_old"]).fillna(last["cause"])
    df["comment"] = last["comment"]
    df["status_latest"] = last["status"]
    df["published_utc"] = last["published_utc"]
    df["version"] = last["version"]
    df["n_revisions"] = n_rev
    df["palier"] = df["unit_name"].map(palier)

    for side in ("old", "new"):
        tmp = pd.DataFrame({
            "unit_name": df["unit_name"],
            "capacity_available_mw": df[f"capacity_available_mw_{side}"],
        })
        unav = _unavailable_mw(tmp, capacity).where(df[f"start_utc_{side}"].notna(), 0.0)
        df[f"unav_mw_{side}"] = unav
        df[f"gwh_{side}"] = _future_gwh(df[f"start_utc_{side}"], df[f"end_utc_{side}"],
                                        unav, new_utc, horizon_utc)
    df["delta_gwh"] = df["gwh_new"] - df["gwh_old"]
    df["end_shift_days"] = (df["end_utc_new"] - df["end_utc_old"]) / DAY
    df["start_shift_days"] = (df["start_utc_new"] - df["start_utc_old"]) / DAY
    df["mw_change"] = df["unav_mw_new"] - df["unav_mw_old"]

    is_new = df["start_utc_old"].isna() & df["start_utc_new"].notna()
    removed = df["start_utc_new"].isna() & df["start_utc_old"].notna()
    ext = df["end_shift_days"] > 1 / 24
    short = df["end_shift_days"] < -1 / 24
    moved = df["start_shift_days"].abs() > 1 / 24
    mw = df["mw_change"].abs() >= 1
    df["change"] = np.select(
        [is_new, removed, ext, short, moved, mw],
        ["New", "Withdrawn", "Extended", "Shortened", "Rescheduled", "MW change"],
        default="Update",
    )
    df = df[df["start_utc_old"].notna() | df["start_utc_new"].notna()]
    return df.reset_index().sort_values("delta_gwh", key=lambda s: -s.abs()).reset_index(drop=True)


# -----------------------------------------------------------------------------
# Gantt and overrun statistics
# -----------------------------------------------------------------------------
def first_versions(versions: pd.DataFrame) -> pd.DataFrame:
    """First stored version of each outage (as first announced)."""
    return (
        versions.sort_values(["outage_id", "version"])
        .groupby("outage_id", sort=False)
        .first()[["start_utc", "end_utc", "published_utc", "capacity_available_mw"]]
        .add_suffix("_first")
    )


def announced_at(versions: pd.DataFrame, rows: pd.DataFrame, at_col: str) -> pd.DataFrame:
    """
    For each row (``outage_id`` + timestamp column ``at_col``), the start/end
    of the outage as announced at that instant (last version published at or
    before it). NaT where nothing had been published yet.
    """
    left = rows[["outage_id", at_col]].reset_index().dropna(subset=[at_col]).sort_values(at_col)
    right = (
        versions[["outage_id", "published_utc", "start_utc", "end_utc"]]
        .sort_values("published_utc")
        .rename(columns={"start_utc": "start_announced_utc", "end_utc": "end_announced_utc"})
    )
    m = pd.merge_asof(left, right, left_on=at_col, right_on="published_utc",
                      by="outage_id", direction="backward")
    return m.set_index("index")[["start_announced_utc", "end_announced_utc"]].reindex(rows.index)


def gantt_rows(
    versions: pd.DataFrame,
    capacity: pd.Series,
    as_of_utc: pd.Timestamp,
    ref_utc: Optional[pd.Timestamp],
    window_start_utc: pd.Timestamp,
    window_end_utc: pd.Timestamp,
    min_mw: float = 0.0,
) -> pd.DataFrame:
    """Outages current at ``as_of_utc`` overlapping the window, with announcement drift."""
    snap = snapshot(versions, as_of_utc)
    snap = snap[(snap["end_utc"] > window_start_utc) & (snap["start_utc"] < window_end_utc)].copy()
    if snap.empty:
        return snap
    snap["unav_mw"] = _unavailable_mw(snap, capacity)
    snap = snap[snap["unav_mw"] >= min_mw]
    snap = snap.join(first_versions(versions), on="outage_id")
    known = versions[versions["published_utc"] <= as_of_utc]
    snap["n_versions"] = snap["outage_id"].map(known.groupby("outage_id").size())
    if ref_utc is not None:
        ref = snapshot(versions, ref_utc).set_index("outage_id")
        snap["end_ref_utc"] = snap["outage_id"].map(ref["end_utc"])
    else:
        snap["end_ref_utc"] = pd.NaT
    snap = snap.reset_index(drop=True)
    at_start = announced_at(versions, snap, "start_utc")
    snap["end_at_start_utc"] = at_start["end_announced_utc"]
    since_start = (snap["start_utc"] <= as_of_utc) & snap["end_at_start_utc"].notna()
    # Running outages: end slippage since they started. Upcoming ones:
    # change in planned duration versus the first announcement, so a
    # window that was merely rescheduled does not read as an extension.
    duration_change = (
        (snap["end_utc"] - snap["start_utc"])
        - (snap["end_utc_first"] - snap["start_utc_first"])
    ) / DAY
    snap["ext_total_days"] = ((snap["end_utc"] - snap["end_at_start_utc"]) / DAY).where(
        since_start, duration_change
    )
    snap["ext_basis"] = np.where(since_start, "since start", "duration vs first")
    snap["ext_window_days"] = (snap["end_utc"] - snap["end_ref_utc"]) / DAY
    snap["palier"] = snap["unit_name"].map(palier)
    return snap


def overrun_history(
    versions: pd.DataFrame,
    now_utc: pd.Timestamp,
    min_days: float = 7.0,
    since_utc: pd.Timestamp = pd.Timestamp("2019-01-01", tz="UTC"),
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Planned outages that were announced before they started and were
    planned to last at least ``min_days`` at that point.

    overrun = current end − end announced at the actual start, in days, so
    rescheduling before the outage begins is not counted as an overrun.
    Returns (completed outages, running outages).
    """
    snap = snapshot(versions, now_utc)
    snap = snap[(snap["outage_type_norm"] == "planned") & ~snap["end_is_placeholder"]].copy()
    snap = snap.reset_index(drop=True)
    at_start = announced_at(versions, snap, "start_utc")
    snap["start_at_start_utc"] = at_start["start_announced_utc"]
    snap["end_at_start_utc"] = at_start["end_announced_utc"]
    planned_days = (snap["end_at_start_utc"] - snap["start_utc"]) / DAY
    snap = snap[snap["end_at_start_utc"].notna() & (planned_days >= min_days)].copy()
    snap["planned_days"] = planned_days.reindex(snap.index)
    snap["overrun_days"] = (snap["end_utc"] - snap["end_at_start_utc"]) / DAY
    snap["palier"] = snap["unit_name"].map(palier)
    done = snap[(snap["end_utc"] <= now_utc) & (snap["start_utc"] >= since_utc)]
    running = snap[(snap["start_utc"] <= now_utc) & (snap["end_utc"] > now_utc)]
    return done.reset_index(drop=True), running.reset_index(drop=True)


__all__ = [
    "PARIS",
    "DailyAvailability",
    "palier",
    "unit_order",
    "paris_day_start_utc",
    "to_paris_naive",
    "as_of_for_day",
    "snapshot",
    "daily_availability",
    "fleet_status_at",
    "delivery_buckets",
    "bucket_changes",
    "outage_changes",
    "first_versions",
    "gantt_rows",
    "overrun_history",
]
