"""
Pure plotly figure builders for the French Nuclear page.

These functions take *DataFrames + scalars only* and never touch global
state, the network, or Dash. Time axes are naive Europe/Paris local time.
Sign convention everywhere: a positive availability change means more
nuclear (bearish power); unavailable-energy deltas (GWh) are the reverse.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.french_nuclear import compute
from core.french_nuclear.constants import (
    AVAILABILITY_COLORSCALE,
    CHART_FONT_FAMILY,
    COLORS,
    DOWN_COLOR,
    NEUTRAL_COLOR,
    TYPE_COLORS,
    UP_COLOR,
)
from core.french_nuclear.unit_delta import PALIER_COLOR, PALIER_ORDER
from core.theme import PLOTLY_TEMPLATE_NAME

_TEXT = "#231F20"
_MUTED = "#6c757d"
_GRID = "#eef0f2"
_ACCENT = COLORS["accent"]
_UNIT_PALETTE = [
    "#4E738A", "#d9480f", "#2f9e44", "#7048e8", "#f08c00", "#1098ad",
    "#c2255c", "#5c940d", "#364fc7", "#e8590c", "#0b7285", "#862e9c",
]


def _title(text: str, subtitle: Optional[str] = None) -> dict:
    # Leave y unset: pinning yanchor="top" near the paper edge clips ascenders
    # (an "h" renders as an "n"). automargin grows the top margin to fit both lines.
    out = dict(
        text=f"<b>{text}</b>",
        x=0, xanchor="left", xref="paper",
        font=dict(size=15, color=_TEXT),
        automargin=True,
        pad=dict(t=6, b=10),
    )
    if subtitle:
        out["subtitle"] = dict(text=subtitle, font=dict(size=12, color=_MUTED))
    return out


def _style(fig: go.Figure, title: str, subtitle: Optional[str] = None, **layout) -> go.Figure:
    fig.update_layout(
        template=PLOTLY_TEMPLATE_NAME,
        title=_title(title, subtitle),
        paper_bgcolor="#ffffff",
        plot_bgcolor="#ffffff",
        font=dict(family=CHART_FONT_FAMILY, size=12, color=_TEXT),
        margin=dict(l=60, r=24, t=28, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="right", x=1,
                    bgcolor="rgba(0,0,0,0)", font=dict(size=11)),
        hoverlabel=dict(bgcolor="#ffffff", bordercolor="#d0d5da", font=dict(size=12)),
    )
    fig.update_xaxes(gridcolor=_GRID, linecolor="#d0d5da", showline=True, ticks="outside",
                     tickcolor="#d0d5da", zeroline=False)
    fig.update_yaxes(gridcolor=_GRID, zeroline=False)
    if layout:
        fig.update_layout(**layout)
    return fig


def _today_line(fig: go.Figure, today: datetime, label: str = "today", **kw) -> None:
    fig.add_vline(x=today, line_dash="dot", line_color="#495057", line_width=1, opacity=0.7, **kw)
    fig.add_annotation(x=today, y=1, yref="paper", text=label, showarrow=False, yanchor="bottom",
                       font=dict(size=10, color=_MUTED), **kw)


def _rgba(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{alpha})"


def _days(s: pd.Series | pd.DataFrame, x_start: datetime, x_end: datetime):
    return s[(s.index >= pd.Timestamp(x_start)) & (s.index <= pd.Timestamp(x_end))]


# -----------------------------------------------------------------------------
# Empty / placeholder
# -----------------------------------------------------------------------------
def make_empty_chart(xaxis_start: datetime, xaxis_end: datetime, message: str = "No data available") -> go.Figure:
    """Placeholder figure shown when no data is available."""
    fig = go.Figure()
    fig.update_layout(
        template=PLOTLY_TEMPLATE_NAME,
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        xaxis=dict(range=[xaxis_start, xaxis_end]),
        annotations=[
            dict(
                text=message,
                showarrow=False,
                font=dict(size=16, color="#323E48"),
            )
        ],
    )
    return fig


def empty_figure(message: str, height: int = 320) -> go.Figure:
    fig = go.Figure()
    _style(fig, "")
    fig.update_layout(height=height, xaxis=dict(visible=False), yaxis=dict(visible=False),
                      annotations=[dict(text=message, showarrow=False, font=dict(size=14, color=_MUTED),
                                        xref="paper", yref="paper", x=0.5, y=0.5)])
    return fig


# -----------------------------------------------------------------------------
# Overview: fleet availability forecast
# -----------------------------------------------------------------------------
def build_forecast_chart(
    current: pd.Series,
    history: pd.DataFrame,
    refs: Dict[str, pd.Series],
    capacity_gw: float,
    as_of_label: str,
    x_start: datetime,
    x_end: datetime,
    today: datetime,
) -> go.Figure:
    """
    Fleet availability (GW, daily mean) as known at the selected as-of, the
    min-max range of the last 30 daily forecasts, and reference forecasts.
    """
    fig = go.Figure()
    cur = _days(current, x_start, x_end)
    if not history.empty:
        hist = _days(history, x_start, x_end)
        lo, hi = hist.min(axis=1), hist.max(axis=1)
        fig.add_trace(go.Scatter(x=lo.index, y=lo.values, mode="lines", line=dict(width=0),
                                 hoverinfo="skip", showlegend=False))
        fig.add_trace(go.Scatter(x=hi.index, y=hi.values, mode="lines", line=dict(width=0),
                                 fill="tonexty", fillcolor=_rgba(_ACCENT, 0.14),
                                 name=f"Range of last {history.shape[1]} daily forecasts",
                                 hoverinfo="skip"))
    ref_styles = [("dash", "#868e96", 1.4), ("dot", "#adb5bd", 1.4), ("dashdot", "#ced4da", 1.2)]
    for (label, series), (dash, color, width) in zip(refs.items(), ref_styles):
        s = _days(series, x_start, x_end)
        fig.add_trace(go.Scatter(x=s.index, y=s.values, mode="lines", name=label,
                                 line=dict(color=color, width=width, dash=dash),
                                 hovertemplate=f"{label}: %{{y:.1f}} GW<extra></extra>"))
    fig.add_trace(go.Scatter(x=cur.index, y=cur.values, mode="lines", name=f"As of {as_of_label}",
                             line=dict(color=_ACCENT, width=2.8),
                             hovertemplate="<b>%{y:.1f} GW</b><extra>as of " + as_of_label + "</extra>"))
    fig.add_hline(y=capacity_gw, line_dash="dot", line_color="#adb5bd", line_width=1,
                  annotation_text=f"Installed {capacity_gw:.1f} GW", annotation_position="top left",
                  annotation_font=dict(size=10, color=_MUTED))
    fig.add_vrect(x0=x_start, x1=today, fillcolor="#f1f3f5", opacity=0.5, line_width=0, layer="below")
    _today_line(fig, today)
    ymin = float(np.nanmin(cur.values)) if len(cur) else 0.0
    _style(fig, "Fleet availability forecast",
           "Daily mean GW · shaded band = range of the last 30 daily forecasts · grey area = past (as reported)",
           height=460, hovermode="x unified")
    fig.update_yaxes(title_text="GW", range=[max(0.0, ymin - 6), capacity_gw + 3])
    fig.update_xaxes(range=[x_start, x_end])
    return fig


def build_unavailability_chart(
    daily: compute.DailyAvailability, x_start: datetime, x_end: datetime, today: datetime
) -> go.Figure:
    """Stacked planned vs forced unavailability (GW, daily mean)."""
    planned = _days(daily.planned_unavail.sum(axis=1) / 1e3, x_start, x_end)
    forced = _days(daily.forced_unavail.sum(axis=1) / 1e3, x_start, x_end)
    fig = go.Figure()
    for name, s, key in (("Planned", planned, "planned"), ("Forced", forced, "forced")):
        fig.add_trace(go.Scatter(
            x=s.index, y=s.values, name=name, mode="lines", stackgroup="unav",
            line=dict(width=0.8, color=TYPE_COLORS[key]), fillcolor=_rgba(TYPE_COLORS[key], 0.55),
            hovertemplate=f"{name}: %{{y:.1f}} GW<extra></extra>",
        ))
    _today_line(fig, today)
    _style(fig, "Unavailability by type", "Daily mean GW offline", height=300, hovermode="x unified")
    fig.update_yaxes(title_text="GW", rangemode="tozero")
    fig.update_xaxes(range=[x_start, x_end])
    return fig


def build_unit_heatmap(
    daily: compute.DailyAvailability, x_start: datetime, x_end: datetime, today: datetime
) -> go.Figure:
    """Per-unit availability (% of capacity), units grouped by reactor series."""
    avail = _days(daily.avail, x_start, x_end)
    units = compute.unit_order(avail.columns)
    avail = avail[units]
    cap = daily.capacity.reindex(units)
    pct = (avail / cap * 100.0).clip(0, 100)
    z = pct.T.values
    mw = avail.T.values
    fig = go.Figure(go.Heatmap(
        z=z, x=avail.index, y=units, customdata=mw,
        colorscale=AVAILABILITY_COLORSCALE, zmin=0, zmax=100, xgap=0, ygap=1,
        colorbar=dict(title=dict(text="% avail", font=dict(size=11)), thickness=10, len=0.3,
                      x=1.06, xanchor="left", y=1, yanchor="top", ticksuffix="%"),
        hovertemplate="<b>%{y}</b> · %{x|%a %d %b %Y}<br>%{customdata:,.0f} MW (%{z:.0f}%)<extra></extra>",
    ))
    groups = [compute.palier(u) for u in units]
    start = 0
    for i in range(1, len(units) + 1):
        if i == len(units) or groups[i] != groups[start]:
            if start > 0:
                fig.add_hline(y=start - 0.5, line_color="#495057", line_width=1)
            fig.add_annotation(
                x=1.005, xref="paper", xanchor="left", y=(start + i - 1) / 2, text=f"<b>{groups[start]}</b>",
                showarrow=False, font=dict(size=11, color=PALIER_COLOR.get(groups[start], _MUTED)),
            )
            start = i
    _today_line(fig, today)
    _style(fig, "Unit availability", "Daily mean availability as % of unit capacity, grouped by reactor series",
           height=max(500, 17 * len(units) + 120), hovermode="closest")
    fig.update_layout(margin=dict(l=110, r=110, t=78, b=40))
    fig.update_yaxes(autorange="reversed", showgrid=False, tickfont=dict(size=10))
    fig.update_xaxes(showgrid=False, range=[x_start, x_end])
    return fig


# -----------------------------------------------------------------------------
# Market movers
# -----------------------------------------------------------------------------
def build_bucket_delta_chart(bc: pd.DataFrame, lookback_label: str, top_n: int = 10) -> go.Figure:
    """Mean availability change per delivery bucket, stacked by unit."""
    if bc.empty or not np.any(np.abs(bc.values) >= 1):
        return empty_figure(f"No change in availability over the last {lookback_label}")
    movers = bc.abs().max().sort_values(ascending=False)
    movers = movers[movers >= 1]
    keep = list(movers.index[:top_n])
    stacked = bc[keep].copy()
    rest = bc.drop(columns=keep).sum(axis=1)
    if (rest.abs() >= 1).any():
        stacked["Other units"] = rest
    fig = go.Figure()
    for i, unit in enumerate(stacked.columns):
        color = "#ced4da" if unit == "Other units" else _UNIT_PALETTE[i % len(_UNIT_PALETTE)]
        fig.add_trace(go.Bar(x=stacked.index, y=stacked[unit], name=unit, marker_color=color,
                             hovertemplate=f"{unit}: %{{y:+,.0f}} MW<extra></extra>"))
    total = bc.sum(axis=1)
    fig.add_trace(go.Scatter(
        x=total.index, y=total.values, mode="markers+text", name="Net",
        marker=dict(symbol="diamond", size=11, color=_TEXT, line=dict(color="#fff", width=1)),
        text=[f"{v / 1e3:+.2f} GW" if abs(v) >= 1 else "" for v in total.values],
        textposition=["top center" if v >= 0 else "bottom center" for v in total.values],
        textfont=dict(size=11, color=_TEXT),
        hovertemplate="<b>Net %{y:+,.0f} MW</b><extra></extra>",
    ))
    _style(fig, f"Availability change by delivery period — last {lookback_label}",
           "Bucket-average MW, new forecast − forecast at the start of the lookback · + = more nuclear",
           height=420, barmode="relative", hovermode="x unified")
    fig.add_hline(y=0, line_color="#495057", line_width=1)
    fig.update_yaxes(title_text="Δ MW (bucket avg)", tickformat="+,.0f")
    fig.update_layout(legend=dict(orientation="v", x=1.01, xanchor="left", y=1, yanchor="top"),
                      margin=dict(r=140))
    return fig


def build_bucket_waterfall(bc: pd.DataFrame, bucket: str, ref_gw: float, new_gw: float,
                           ref_label: str) -> go.Figure:
    """Waterfall from the reference to the new bucket-average availability, by unit."""
    if bucket not in bc.index:
        return empty_figure(f"No changes in {bucket}")
    steps = bc.loc[bucket]
    steps = steps[steps.abs() >= 5].sort_values(key=lambda s: -s.abs())
    if steps.empty:
        return empty_figure(f"No changes in {bucket} over the lookback")
    if len(steps) > 12:
        steps = pd.concat([steps.iloc[:11], pd.Series({"Other units": steps.iloc[11:].sum()})])
    x = [ref_label] + list(steps.index) + ["Now"]
    y = [ref_gw] + list(steps.values / 1e3) + [new_gw]
    measure = ["absolute"] + ["relative"] * len(steps) + ["total"]
    text = [f"{ref_gw:.2f}"] + [f"{v:+.2f}" for v in steps.values / 1e3] + [f"{new_gw:.2f}"]
    fig = go.Figure(go.Waterfall(
        x=x, y=y, measure=measure, text=text, textposition="outside",
        increasing=dict(marker=dict(color=UP_COLOR)), decreasing=dict(marker=dict(color=DOWN_COLOR)),
        totals=dict(marker=dict(color=_ACCENT)), connector=dict(line=dict(color="#ced4da", width=1)),
        hovertemplate="%{x}: %{text} GW<extra></extra>",
    ))
    lo = min(np.cumsum(y[:-1]).min(), new_gw)
    hi = max(np.cumsum(y[:-1]).max(), new_gw)
    pad = max(0.5, (hi - lo) * 0.4)
    _style(fig, f"{bucket}: what moved the forecast", "Bucket-average GW, contribution per unit",
           height=420, showlegend=False, hovermode="closest")
    fig.update_yaxes(title_text="GW", range=[lo - pad, hi + pad])
    return fig


def build_slippage_gantt(
    g: pd.DataFrame, today: datetime, x_start: datetime, x_end: datetime, ref_label: str
) -> go.Figure:
    """
    Current and upcoming outages per unit. Hatched segments are extensions
    since the outage started; diamonds mark the end as published at the
    reference time when it has moved since.
    """
    if g is None or g.empty:
        return empty_figure("No outages in the window")
    g = g.copy()
    for col in ("start_utc", "end_utc", "end_at_start_utc", "end_ref_utc", "published_utc"):
        g[col] = compute.to_paris_naive(g[col])
    units = compute.unit_order(g["unit_name"].unique())
    fig = go.Figure()
    ms = lambda a, b: (b - a).dt.total_seconds() * 1000.0  # noqa: E731

    ext_mask = (g["ext_basis"] == "since start") & (g["ext_total_days"] > 1 / 24)
    solid_end = g["end_utc"].where(~ext_mask, g["end_at_start_utc"])
    hover = (
        "<b>%{y}</b> · %{customdata[0]}<br>%{customdata[1]} → %{customdata[2]}"
        "<br>%{customdata[3]:,.0f} MW unavailable · %{customdata[4]} versions"
        "<br>Extension: %{customdata[5]}<br>vs " + ref_label + ": %{customdata[6]}<extra></extra>"
    )

    def _fmt_days(v, basis=None):
        if pd.isna(v) or abs(v) < 1 / 24:
            return "—"
        suffix = f" ({basis})" if basis else ""
        return f"{v:+.1f} d{suffix}"

    custom = np.stack([
        g["outage_type_norm"].str.title(),
        g["start_utc"].dt.strftime("%d %b %H:%M"),
        g["end_utc"].dt.strftime("%d %b %Y %H:%M"),
        g["unav_mw"],
        g["n_versions"].fillna(1).astype(int),
        [_fmt_days(v, b) for v, b in zip(g["ext_total_days"], g["ext_basis"])],
        [_fmt_days(v) for v in g["ext_window_days"]],
    ], axis=-1)

    for kind in ("planned", "forced"):
        m = g["outage_type_norm"].str.startswith(kind)
        if not m.any():
            continue
        sub = g[m]
        fig.add_trace(go.Bar(
            y=sub["unit_name"], base=sub["start_utc"], x=ms(sub["start_utc"], solid_end[m]),
            orientation="h", name=kind.title(), marker=dict(color=TYPE_COLORS[kind], line=dict(width=0)),
            opacity=0.9, customdata=custom[m.to_numpy()], hovertemplate=hover, width=0.62,
        ))
    if ext_mask.any():
        sub = g[ext_mask]
        fig.add_trace(go.Bar(
            y=sub["unit_name"], base=sub["end_at_start_utc"], x=ms(sub["end_at_start_utc"], sub["end_utc"]),
            orientation="h", name="Extension since start",
            marker=dict(color=_rgba(DOWN_COLOR, 0.25), line=dict(color=DOWN_COLOR, width=1),
                        pattern=dict(shape="/", fgcolor=DOWN_COLOR, size=6, solidity=0.3)),
            customdata=custom[ext_mask.to_numpy()], hovertemplate=hover, width=0.62,
        ))
    moved = g["ext_window_days"].abs() > 1 / 24
    if moved.any():
        sub = g[moved]
        color = np.where(sub["ext_window_days"] > 0, DOWN_COLOR, UP_COLOR)
        fig.add_trace(go.Scatter(
            y=sub["unit_name"], x=sub["end_ref_utc"], mode="markers", name=f"End as of {ref_label}",
            marker=dict(symbol="diamond-open", size=10, color=list(color), line=dict(width=2)),
            hovertemplate="<b>%{y}</b><br>End as of " + ref_label + ": %{x|%d %b %H:%M}<extra></extra>",
        ))
        fig.add_trace(go.Scatter(
            y=sub["unit_name"], x=sub["end_utc"], mode="text", showlegend=False,
            text=[f"  {v:+.1f}d" for v in sub["ext_window_days"]], textposition="middle right",
            textfont=dict(size=11, color=list(color)), hoverinfo="skip",
        ))
    _today_line(fig, today, label="now")
    _style(fig, "Outage schedule and slippage",
           f"Current outages ≥ threshold · hatched = extension since start · ◇ = end as of {ref_label}",
           height=max(420, 22 * len(units) + 140), barmode="overlay", hovermode="closest")
    fig.update_layout(margin=dict(l=110, r=40, t=78, b=40))
    fig.update_xaxes(type="date", range=[x_start, x_end])
    fig.update_yaxes(categoryorder="array", categoryarray=units, autorange="reversed",
                     showgrid=True, tickfont=dict(size=10))
    return fig


def build_overrun_chart(done: pd.DataFrame, running: pd.DataFrame) -> go.Figure:
    """Distribution of planned-outage overruns by reactor series, with running outages."""
    if done.empty:
        return empty_figure("No completed planned outages")
    fig = go.Figure()
    present = [p for p in PALIER_ORDER if p in set(done["palier"]) | set(running["palier"])]
    for p in present:
        d = done[done["palier"] == p]
        if d.empty:
            continue
        share = (d["overrun_days"] > 1).mean() * 100
        med = d["overrun_days"].median()
        fig.add_trace(go.Box(
            y=d["overrun_days"], x=[p] * len(d), name=p, boxpoints="all", jitter=0.45, pointpos=0,
            marker=dict(size=4, color=PALIER_COLOR.get(p, _MUTED), opacity=0.35),
            line=dict(color=PALIER_COLOR.get(p, _MUTED), width=1.5),
            fillcolor=_rgba(PALIER_COLOR.get(p, "#8c97a3"), 0.12),
            customdata=np.stack([d["unit_name"], compute.to_paris_naive(d["start_utc"]).dt.strftime("%b %Y"),
                                 d["planned_days"].round(0)], axis=-1),
            hovertemplate="%{customdata[0]} · %{customdata[1]}<br>planned %{customdata[2]:.0f} d · "
                          "overrun %{y:+.1f} d<extra></extra>",
            showlegend=False,
        ))
        fig.add_annotation(x=p, y=1, yref="paper", yanchor="bottom", showarrow=False,
                           text=f"{share:.0f}% overrun · med {med:+.0f}d",
                           font=dict(size=10, color=_MUTED))
    if not running.empty:
        late = running["overrun_days"] >= 5
        fig.add_trace(go.Scatter(
            x=running["palier"], y=running["overrun_days"], mode="markers+text", showlegend=False,
            marker=dict(symbol="diamond", size=12, color=np.where(late, DOWN_COLOR, NEUTRAL_COLOR),
                        line=dict(color="#fff", width=1)),
            text=running["unit_name"].where(late, ""), textposition="middle right",
            textfont=dict(size=10, color=DOWN_COLOR),
            customdata=np.stack([running["unit_name"],
                                 compute.to_paris_naive(running["end_utc"]).dt.strftime("%d %b %Y")], axis=-1),
            hovertemplate="<b>%{customdata[0]}</b> (running)<br>overrun so far %{y:+.1f} d"
                          "<br>current end %{customdata[1]}<extra></extra>",
        ))
    ys = pd.concat([done["overrun_days"], running["overrun_days"]])
    hi = max(float(done["overrun_days"].quantile(0.95)), float(running["overrun_days"].max() if len(running) else 0))
    _style(fig, "Planned outage overruns by reactor series",
           "End announced at outage start → actual end, completed outages since 2019 · ◆ = running now "
           "(labelled if ≥ 5 d late) · axis clipped at the 95th percentile",
           height=460, hovermode="closest", showlegend=False)
    fig.update_layout(margin=dict(t=96))
    fig.update_yaxes(title_text="Overrun (days)", range=[min(-15.0, float(ys.quantile(0.01))), hi * 1.1 + 5],
                     zeroline=True, zerolinecolor="#adb5bd")
    fig.update_xaxes(categoryorder="array", categoryarray=present, showline=False)
    return fig


# -----------------------------------------------------------------------------
# Outage explorer
# -----------------------------------------------------------------------------
def build_unit_outage_timeline(snap: pd.DataFrame, unit: str, today: datetime,
                               selected: Optional[str] = None) -> go.Figure:
    """All current-version outages of one unit as a timeline, one row per outage type."""
    if snap.empty:
        return empty_figure(f"No outages for {unit}")
    s = snap.copy()
    s["start"] = compute.to_paris_naive(s["start_utc"])
    s["end"] = compute.to_paris_naive(s["end_utc"])
    s["row"] = s["outage_type_norm"].str.title()
    fig = go.Figure()
    for kind in ("planned", "forced"):
        sub = s[s["outage_type_norm"].str.startswith(kind)]
        if sub.empty:
            continue
        line_w = np.where(sub["outage_id"] == selected, 2.5, 0)
        fig.add_trace(go.Bar(
            y=sub["row"], base=sub["start"], x=(sub["end"] - sub["start"]).dt.total_seconds() * 1000,
            orientation="h", name=kind.title(), width=0.6,
            marker=dict(color=TYPE_COLORS[kind], line=dict(color=_TEXT, width=line_w)),
            customdata=np.stack([sub["start"].dt.strftime("%d %b %Y %H:%M"), sub["end"].dt.strftime("%d %b %Y %H:%M"),
                                 sub["capacity_available_mw"].fillna(0), sub["cause"].fillna(""),
                                 sub["outage_id"]], axis=-1),
            hovertemplate="%{customdata[0]} → %{customdata[1]}<br>available %{customdata[2]:,.0f} MW"
                          "<br>%{customdata[3]}<br><span style='color:#868e96'>%{customdata[4]}</span><extra></extra>",
        ))
    _today_line(fig, today)
    _style(fig, f"{unit} — outage history", "Current version of every outage · click a bar to inspect it",
           height=260, barmode="overlay", hovermode="closest")
    fig.update_xaxes(type="date", rangeslider=dict(visible=False),
                     range=[today - timedelta(days=730), today + timedelta(days=400)])
    return fig


def build_announcement_drift(ov: pd.DataFrame, now: datetime) -> go.Figure:
    """How the announced window and available MW of one outage evolved, per publication."""
    if ov.empty:
        return empty_figure("Select an outage")
    v = ov.sort_values("version").copy()
    pub = compute.to_paris_naive(v["published_utc"])
    start = compute.to_paris_naive(v["start_utc"])
    end = compute.to_paris_naive(v["end_utc"])
    # Extend each step line to "now" so the latest announcement stays visible.
    x = pd.DatetimeIndex(list(pub) + [pd.Timestamp(now)])
    ext = lambda s: pd.concat([s, s.iloc[-1:]], ignore_index=True)  # noqa: E731
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.72, 0.28], vertical_spacing=0.06)
    fig.add_trace(go.Scatter(x=x, y=ext(start), mode="lines", line=dict(shape="hv", color=_ACCENT, width=1.5),
                             name="Announced start", hovertemplate="start %{y|%d %b %Y %H:%M}<extra></extra>"),
                  row=1, col=1)
    fig.add_trace(go.Scatter(x=x, y=ext(end), mode="lines", line=dict(shape="hv", color=DOWN_COLOR, width=2.2),
                             fill="tonexty", fillcolor=_rgba(_ACCENT, 0.10), name="Announced end",
                             hovertemplate="end %{y|%d %b %Y %H:%M}<extra></extra>"), row=1, col=1)
    status = v["status"].fillna("")
    shift = (v["end_utc"].diff() / compute.DAY).fillna(0.0)
    fig.add_trace(go.Scatter(
        x=pub, y=end, mode="markers", showlegend=False,
        marker=dict(size=8, color=[DOWN_COLOR if d > 1 / 24 else UP_COLOR if d < -1 / 24 else NEUTRAL_COLOR
                                   for d in shift],
                    symbol=["x" if st in compute.REMOVED_STATUSES else "circle" for st in status],
                    line=dict(color="#fff", width=1)),
        customdata=np.stack([v["version"], status, shift.round(2), v["comment"].fillna("").str.slice(0, 160)],
                            axis=-1),
        hovertemplate="<b>v%{customdata[0]}</b> · %{x|%d %b %Y %H:%M} · %{customdata[1]}"
                      "<br>end %{y|%d %b %Y %H:%M} (%{customdata[2]:+.2f} d)<br>%{customdata[3]}<extra></extra>",
    ), row=1, col=1)
    fig.add_trace(go.Scatter(x=x, y=ext(v["capacity_available_mw"].fillna(0)), mode="lines",
                             line=dict(shape="hv", color="#495057", width=1.5), name="Available MW",
                             hovertemplate="%{y:,.0f} MW available<extra></extra>"), row=2, col=1)
    fig.add_vline(x=now, line_dash="dot", line_color="#495057", line_width=1)
    first, last = v.iloc[0], v.iloc[-1]
    total = (last["end_utc"] - first["end_utc"]) / compute.DAY
    _style(fig, "Announcement drift",
           f"{len(v)} versions · end moved {total:+.1f} d since first announcement · "
           f"x = publication time, y = announced dates",
           height=520, hovermode="x unified")
    fig.update_yaxes(title_text="Announced date", type="date", row=1, col=1)
    cap = float(v["capacity_max_mw"].max()) if v["capacity_max_mw"].notna().any() else None
    fig.update_yaxes(title_text="MW available", range=[0, cap * 1.05] if cap else None, row=2, col=1)
    return fig


# -----------------------------------------------------------------------------
# Per-unit availability delta heatmap (latest as-of − reference as-of)
# -----------------------------------------------------------------------------
def build_unit_delta_heatmap(
    delta: pd.DataFrame,
    *,
    latest_label: str,
    reference_label: str,
    area: str,
    fuel: str,
) -> go.Figure:
    """Heatmap of per-unit availability change between two publication times.

    ``delta`` is wide: index = delivery date, columns = unit, value = MW
    (``latest_avail − reference_avail``).  Uses a diverging colour scale centred
    at zero so a forecast upgrade (more capacity now) reads green and a
    downgrade reads red.
    """
    if delta is None or delta.empty:
        return make_empty_chart(datetime.now(), datetime.now() + timedelta(days=1))

    # Units on the y-axis, delivery dates on the x-axis.
    pivot = delta.T  # rows = unit, cols = date
    max_abs = float(pd.to_numeric(pivot.stack(), errors="coerce").abs().max())
    if not max_abs or max_abs != max_abs:  # 0 or NaN
        max_abs = 1.0

    fig = go.Figure(
        data=go.Heatmap(
            z=pivot.values,
            x=pivot.columns,
            y=pivot.index,
            colorscale="RdYlGn",
            zmid=0,
            zmin=-max_abs,
            zmax=max_abs,
            xgap=1,
            ygap=1,
            hovertemplate=(
                "<b>%{y}</b><br>Date: %{x|%d %b %Y}"
                "<br>Δ Availability: %{z:+,.0f} MW<extra></extra>"
            ),
            colorbar=dict(
                title=dict(text="Δ MW", font=dict(size=11, color="#323E48")),
                tickfont=dict(size=10, color="#323E48"),
                len=0.6,
            ),
        )
    )

    # Today marker (delivery axis).
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    if pivot.columns.min() <= today <= pivot.columns.max():
        fig.add_vline(
            x=today, line_dash="dot", line_color="#4E738A", line_width=2, opacity=0.8
        )

    fig.update_layout(
        title=dict(
            text=(
                f"{area} {fuel.title()} — Per-Unit Availability Δ"
                f"<br><sub>latest {latest_label} − reference {reference_label}</sub>"
            ),
            font=dict(size=14, color="#231F20"),
            x=0,
        ),
        template=PLOTLY_TEMPLATE_NAME,
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        margin=dict(l=160, r=20, t=70, b=50),
        xaxis=dict(
            tickformat="%b %d",
            tickfont=dict(size=11, color="#231F20"),
            gridcolor="#e1e4e8",
            showgrid=False,
        ),
        yaxis=dict(
            tickfont=dict(size=10, color="#231F20"),
            showgrid=False,
            autorange="reversed",
        ),
        font=dict(family=CHART_FONT_FAMILY),
    )
    return fig


__all__ = [
    "make_empty_chart",
    "empty_figure",
    "build_forecast_chart",
    "build_unavailability_chart",
    "build_unit_heatmap",
    "build_bucket_delta_chart",
    "build_bucket_waterfall",
    "build_slippage_gantt",
    "build_overrun_chart",
    "build_unit_outage_timeline",
    "build_announcement_drift",
    "build_unit_delta_heatmap",
]
