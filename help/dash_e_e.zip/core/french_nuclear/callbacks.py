"""
Dash callbacks for the French Nuclear Availability page.

Importing this module **registers** all callbacks against the active Dash
app via the ``@callback`` decorator (no factory function needed).

Data flow: ``data-refresh-interval`` polls the EDF v2 store; when its ETag
changes, ``last-refresh-time`` is updated and every chart callback that takes
it as an Input re-renders.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

import dash
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, State, callback, html

from core.french_nuclear import charts
from core.french_nuclear import compute
from core.french_nuclear import data as fn_data
from core.french_nuclear.charts import build_unit_delta_heatmap
from core.french_nuclear.constants import (
    LOOKBACK_OPTIONS,
    PARIS_TZ,
    SLIDER_DAYS_RANGE,
    axis_day,
    paris_today,
    slider_day,
)
from core.french_nuclear.layout import (
    URL_LOCATION_ID,
    changes_table,
    kpi_card,
    live_status,
    outage_option_label,
    render_availability_tab,
    render_movers_tab,
    render_outages_tab,
    render_unit_delta_tab,
    render_unit_eq_delta_tab,
    versions_table,
)
from core.french_nuclear import unit_delta as _unit_delta
from core.french_nuclear import unit_eq_delta as _unit_eq_delta
from core.other_nuclear import callbacks as _other_nuclear_callbacks  # noqa: F401
from core.other_nuclear.layout import build_layout as build_other_nuclear_layout
from core.state import (
    UrlControl,
    encode_list,
    parse_int_list,
    register as register_url_sync,
)


logger = logging.getLogger(__name__)

_NO_DATA = "EDF outage store unavailable — check S3 access"
_overrun_cache: dict = {}


# -----------------------------------------------------------------------------
# URL-state sync
# -----------------------------------------------------------------------------
# ``date-slider.value`` is intentionally excluded -- it is already an Output of
# :func:`advance_slider` (the play/pause animation). Controls inside tab
# content are lazy: the URL restores them when their tab opens, but their
# changes do not update the URL (see ``UrlControl.lazy``).
URL_CONTROLS = [
    UrlControl("main-tabs", "value"),
    UrlControl(
        "date-range-slider",
        "value",
        parse=parse_int_list,
        encode=encode_list,
        lazy=True,
    ),
    UrlControl("plant-dropdown", "value", lazy=True),
    UrlControl("fn-lookback", "value", lazy=True),
    UrlControl("fn-min-mw", "value", parse=int, encode=str, lazy=True),
    UrlControl("unit-delta-horizon", "value", parse=int, encode=str, lazy=True),
    UrlControl("unit-delta-color-by", "value", lazy=True),
    UrlControl("unit-eq-country", "value", lazy=True),
    UrlControl("unit-eq-fuel", "value", lazy=True),
]
register_url_sync(URL_LOCATION_ID, URL_CONTROLS)


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def _paris(ts: pd.Timestamp) -> datetime:
    return ts.tz_convert(PARIS_TZ).to_pydatetime().replace(tzinfo=None)


def _paris_now() -> datetime:
    return _paris(fn_data.now_utc())


def _fmt_delta(v: float, unit: str = "GW", digits: int = 2) -> str:
    if v != v:  # NaN
        return "–"
    return f"{v:+.{digits}f} {unit}"


def _tone(v: float, threshold: float = 0.05) -> str:
    """Availability up = bearish power (green), down = bullish (red)."""
    if v != v or abs(v) < threshold:
        return "neutral"
    return "up" if v > 0 else "down"


def _bucket(buckets, label_pred):
    return next(((l, s, e) for l, s, e in buckets if label_pred(l)), None)


def _overruns(data):
    hit = _overrun_cache.get(data.etag)
    if hit is None:
        hit = compute.overrun_history(data.versions, fn_data.now_utc())
        _overrun_cache.clear()
        _overrun_cache[data.etag] = hit
    return hit


# -----------------------------------------------------------------------------
# Tab content
# -----------------------------------------------------------------------------
@callback(Output("tab-content", "children"), Input("main-tabs", "value"))
def render_tab_content(tab):
    if tab == "tab-availability":
        return render_availability_tab()
    if tab == "tab-movers":
        return render_movers_tab()
    if tab == "tab-outages":
        return render_outages_tab(fn_data.get_units())
    if tab == "tab-unit-delta":
        return render_unit_delta_tab()
    if tab == "tab-unit-eq-delta":
        return render_unit_eq_delta_tab()
    if tab == "tab-other-nuclear":
        return build_other_nuclear_layout()
    return html.Div()


# -----------------------------------------------------------------------------
# Overview
# -----------------------------------------------------------------------------
@callback(
    [
        Output("availability-line-chart", "figure"),
        Output("fn-unavail-chart", "figure"),
        Output("availability-heatmap", "figure"),
        Output("fn-kpis", "children"),
        Output("selected-date-display", "children"),
        Output("current-date-badge", "children"),
        Output("date-range-display", "children"),
        Output("fn-capacity-note", "children"),
    ],
    [
        Input("date-slider", "value"),
        Input("date-range-slider", "value"),
        Input("last-refresh-time", "data"),
    ],
)
def update_charts(day_offset, date_range, _refresh):
    today = paris_today()
    as_of_day = slider_day(day_offset if day_offset is not None else SLIDER_DAYS_RANGE, today)
    x_start = datetime.combine(axis_day(date_range[0]), datetime.min.time())
    x_end = datetime.combine(axis_day(date_range[1]), datetime.min.time())
    range_label = f"{x_start:%d %b %Y} → {x_end:%d %b %Y}"

    data = fn_data.get_data()
    if data is None:
        empty = charts.empty_figure(_NO_DATA)
        return empty, empty, empty, [], f"{as_of_day:%d %b %Y}", "", range_label, ""

    now = fn_data.now_utc()
    as_of_utc = compute.as_of_for_day(as_of_day, now)
    is_live = as_of_day >= today
    as_of_label = f"{_paris(as_of_utc):%d %b %H:%M}" if is_live else f"{as_of_day:%d %b}"
    cur = fn_data.availability_at(as_of_utc)
    d1 = fn_data.availability_at(as_of_utc - pd.Timedelta(days=1))
    d7 = fn_data.availability_at(as_of_utc - pd.Timedelta(days=7))
    history = fn_data.history_totals(SLIDER_DAYS_RANGE, until=as_of_day)
    today_dt = _paris(min(as_of_utc, now)) if is_live else datetime.combine(as_of_day, datetime.min.time())
    cap_gw = data.fleet_capacity_mw / 1e3

    forecast = charts.build_forecast_chart(
        cur.total_gw, history, {"D-1": d1.total_gw, "D-7": d7.total_gw},
        cap_gw, as_of_label, x_start, x_end, today_dt,
    )
    unavail = charts.build_unavailability_chart(cur, x_start, x_end, today_dt)
    heatmap = charts.build_unit_heatmap(cur, x_start, x_end, today_dt)

    status = compute.fleet_status_at(data.versions, data.capacity_mw, min(as_of_utc, now))
    buckets = compute.delivery_buckets(as_of_day)
    kpis = [
        kpi_card(
            "Available now" if is_live else f"Available {as_of_day:%d %b}",
            f"{status['available_gw']:.1f} GW",
            f"{status['available_gw'] / status['capacity_gw']:.0%} of {status['capacity_gw']:.1f} GW · "
            f"{status['units_offline']}/{status['units_total']} units offline",
        ),
        kpi_card("Forced outages", f"{status['forced_gw']:.1f} GW", "unplanned unavailability now",
                 "warn" if status["forced_gw"] >= 3 else "neutral"),
    ]
    for pick in (lambda l: l == "DA", lambda l: l == "WkA",
                 lambda l: "-" in l and not l.startswith(("Q", "Cal")),
                 lambda l: l.startswith("Q")):
        b = _bucket(buckets, pick)
        if b is None:
            continue
        label, s, e = b
        v = cur.window_mean_gw(s, e)
        dv1 = v - d1.window_mean_gw(s, e)
        dv7 = v - d7.window_mean_gw(s, e)
        kpis.append(kpi_card(label, f"{v:.1f} GW", f"1d {_fmt_delta(dv1)} · 7d {_fmt_delta(dv7)}",
                             _tone(dv1 if label in ("DA", "WkA") else dv7)))
    pub = data.versions["published_utc"]
    recent = data.versions[(pub > as_of_utc - pd.Timedelta(hours=24)) & (pub <= as_of_utc)]
    kpis.append(kpi_card("Publications 24h", f"{len(recent)}",
                         f"{recent['outage_id'].nunique()} outages touched"))

    cap_note = [html.B("Fleet capacity: "),
                f"{cap_gw:.2f} GW across {len(data.capacity_mw)} units (Fessenheim excluded)."]
    pill = f"As of {as_of_label}" + (" · live" if is_live else "")
    return (forecast, unavail, heatmap, kpis, pill, f"{_paris(as_of_utc):%d %b %Y %H:%M} Paris",
            range_label, cap_note)


# -----------------------------------------------------------------------------
# Market movers
# -----------------------------------------------------------------------------
@callback(
    [
        Output("fn-movers-kpis", "children"),
        Output("fn-bucket-chart", "figure"),
        Output("fn-waterfall", "figure"),
        Output("fn-changes-table", "children"),
        Output("fn-changes-caption", "children"),
        Output("fn-gantt", "figure"),
        Output("fn-overrun", "figure"),
    ],
    [
        Input("fn-lookback", "value"),
        Input("fn-min-mw", "value"),
        Input("fn-wf-bucket", "value"),
        Input("last-refresh-time", "data"),
    ],
)
def update_movers(lookback, min_mw, wf_bucket, _refresh):
    data = fn_data.get_data()
    if data is None:
        empty = charts.empty_figure(_NO_DATA)
        return [], empty, empty, html.Div(_NO_DATA), "", empty, empty
    lookback = lookback if lookback in LOOKBACK_OPTIONS else "24h"
    min_mw = float(min_mw or 0)
    now = fn_data.now_utc()
    ref_utc = now - pd.Timedelta(hours=LOOKBACK_OPTIONS[lookback])
    ref_label = f"{lookback} ago"
    today = paris_today()

    new_av = fn_data.availability_at(now)
    ref_av = fn_data.availability_at(ref_utc)
    buckets = compute.delivery_buckets(today)
    bc = compute.bucket_changes(new_av, ref_av, buckets)
    bucket_chart = charts.build_bucket_delta_chart(bc, lookback)
    if (wf_bucket in (None, "auto")) and not bc.empty:
        wf_bucket = bc.sum(axis=1).abs().idxmax()
    wf = _bucket(buckets, lambda l: l == wf_bucket) or buckets[0]
    waterfall = charts.build_bucket_waterfall(
        bc, wf[0], ref_av.window_mean_gw(wf[1], wf[2]), new_av.window_mean_gw(wf[1], wf[2]), ref_label,
    )

    ch = compute.outage_changes(data.versions, data.capacity_mw, ref_utc, now, now + pd.Timedelta(days=450))
    if not ch.empty:
        ch = ch[ch[["unav_mw_old", "unav_mw_new"]].max(axis=1) >= min_mw]
    n_pub = int(((data.versions["published_utc"] > ref_utc) & (data.versions["published_utc"] <= now)).sum())
    caption = (f" · {len(ch)} outages ≥ {min_mw:,.0f} MW revised in the last {lookback} "
               f"({n_pub} publications in total) · Δ GWh = change in unavailable energy still to come, "
               f"+ = less nuclear")

    def _net(label):
        return float(bc.loc[label].sum() / 1e3) if label in bc.index else 0.0

    counts = ch["change"].value_counts() if not ch.empty else pd.Series(dtype=int)
    gwh = float(ch["delta_gwh"].sum()) if not ch.empty else 0.0
    month = next((l for l, _, _ in buckets if l not in ("DA", "WkA", "BOM")), None)
    kpis = [
        kpi_card("DA Δ", _fmt_delta(_net("DA")), f"vs {ref_label}", _tone(_net("DA"))),
        kpi_card("WkA Δ", _fmt_delta(_net("WkA")), f"vs {ref_label}", _tone(_net("WkA"))),
    ]
    if month:
        kpis.append(kpi_card(f"{month} Δ", _fmt_delta(_net(month)), f"vs {ref_label}", _tone(_net(month))))
    kpis += [
        kpi_card("Net energy Δ", f"{gwh:+,.0f} GWh", "unavailable energy, next 15 months",
                 "down" if gwh > 50 else "up" if gwh < -50 else "neutral"),
        kpi_card("Extended", f"{counts.get('Extended', 0)}", f"{counts.get('Shortened', 0)} shortened",
                 "down" if counts.get("Extended", 0) else "neutral"),
        kpi_card("New outages", f"{counts.get('New', 0)}", f"{counts.get('Withdrawn', 0)} withdrawn",
                 "warn" if counts.get("New", 0) else "neutral"),
    ]

    now_paris = _paris(now)
    g_start, g_end = now - pd.Timedelta(days=14), now + pd.Timedelta(days=150)
    g = compute.gantt_rows(data.versions, data.capacity_mw, now, ref_utc, g_start, g_end, min_mw=min_mw)
    gantt = charts.build_slippage_gantt(g, now_paris, _paris(g_start), _paris(g_end), ref_label)

    done, running = _overruns(data)
    overrun = charts.build_overrun_chart(done, running)
    return kpis, bucket_chart, waterfall, changes_table(ch), caption, gantt, overrun


# -----------------------------------------------------------------------------
# Outage explorer
# -----------------------------------------------------------------------------
@callback(
    [Output("fn-outage-dropdown", "options"), Output("fn-outage-dropdown", "value")],
    [Input("plant-dropdown", "value"), Input("fn-unit-timeline", "clickData"),
     Input("last-refresh-time", "data")],
    [State("fn-outage-dropdown", "value")],
)
def update_outage_options(unit, click, _refresh, current):
    if not unit:
        return [], None
    v = fn_data.unit_versions(unit)
    if v.empty:
        return [], None
    latest = v.sort_values("version").groupby("outage_id").last()
    latest["n_versions"] = v.groupby("outage_id").size()
    latest = latest.sort_values("start_utc", ascending=False)
    options = [{"label": outage_option_label(r), "value": oid} for oid, r in latest.iterrows()]
    ids = set(latest.index)

    trigger = dash.ctx.triggered_id
    if trigger == "fn-unit-timeline" and click:
        try:
            oid = click["points"][0]["customdata"][4]
            if oid in ids:
                return options, oid
        except (KeyError, IndexError, TypeError):
            pass
    if trigger != "plant-dropdown" and current in ids:
        return options, current
    now = fn_data.now_utc()
    live = latest[~latest["status"].isin(compute.REMOVED_STATUSES) & (latest["end_utc"] > now)]
    pick = live.sort_values("start_utc").index[0] if not live.empty else latest.index[0]
    return options, pick


@callback(
    [Output("fn-unit-timeline", "figure"), Output("fn-drift-chart", "figure"),
     Output("fn-version-table", "children"), Output("fn-unit-kpis", "children")],
    [Input("fn-outage-dropdown", "value")],
    [State("plant-dropdown", "value")],
)
def update_outage_detail(outage_id, unit):
    data = fn_data.get_data()
    if data is None or not unit:
        empty = charts.empty_figure(_NO_DATA if data is None else "Select a unit")
        return empty, empty, html.Div(), []
    v = fn_data.unit_versions(unit)
    now = fn_data.now_utc()
    now_paris = _paris(now)
    snap = compute.snapshot(v, now)
    timeline = charts.build_unit_outage_timeline(snap, unit, now_paris, selected=outage_id)
    ov = v[v["outage_id"] == outage_id]
    drift = charts.build_announcement_drift(ov, now_paris)

    cap = float(data.capacity_mw.get(unit, float("nan")))
    on = snap[(snap["start_utc"] <= now) & (snap["end_utc"] > now)]
    avail_now = float(on["capacity_available_mw"].min()) if not on.empty else cap
    done, running = _overruns(data)
    mine = done[done["unit_name"] == unit]
    kpis = [
        kpi_card("Unit", unit, f"{compute.palier(unit)} · {cap:,.0f} MW"),
        kpi_card("Available now", f"{avail_now:,.0f} MW",
                 "on outage" if not on.empty else "no current outage",
                 "down" if avail_now < cap * 0.5 else "neutral"),
        kpi_card("Planned outages since 2019", f"{len(mine)}",
                 f"median overrun {mine['overrun_days'].median():+.0f} d" if len(mine) else "–"),
    ]
    if not ov.empty:
        o = ov.sort_values("version")
        first, last = o.iloc[0], o.iloc[-1]
        moved = (last["end_utc"] - first["end_utc"]) / compute.DAY
        kpis.append(kpi_card("Selected outage", f"{len(o)} versions",
                             f"end moved {moved:+.1f} d since first announcement", _tone(-moved, 0.5)))
    return timeline, drift, versions_table(ov), kpis


# -----------------------------------------------------------------------------
# Animation controls
# -----------------------------------------------------------------------------
@callback(
    [
        Output("interval-component", "disabled"),
        Output("play-pause-button", "children"),
    ],
    [Input("play-pause-button", "n_clicks")],
    [State("interval-component", "disabled")],
)
def toggle_interval(n_clicks, disabled):
    if n_clicks:
        return not disabled, "⏸ Pause" if disabled else "▶ Play"
    return True, "▶ Play"


@callback(
    Output("date-slider", "value"),
    [Input("interval-component", "n_intervals")],
    [State("date-slider", "value")],
)
def advance_slider(n_intervals, current_value):
    if current_value is None:
        return SLIDER_DAYS_RANGE
    if current_value < SLIDER_DAYS_RANGE:
        return current_value + 1
    return 0


# -----------------------------------------------------------------------------
# Unit Δ vs Today (per-unit availability from corelib cache)
# -----------------------------------------------------------------------------
@callback(
    [Output("unit-delta-chart", "figure"),
     Output("unit-delta-info", "children")],
    [Input("unit-delta-refresh", "n_clicks"),
     Input("unit-delta-horizon", "value"),
     Input("unit-delta-color-by", "value"),
     Input("main-tabs", "value")],
)
def update_unit_delta(_n_clicks, horizon_days, color_by, current_tab):
    """Render the per-unit availability delta vs today, stacked by palier."""
    if current_tab != "tab-unit-delta":
        return go.Figure(), ""

    horizon = int(horizon_days) if horizon_days else 90
    today = datetime.now().date()
    start = today - timedelta(days=14)
    end = today + timedelta(days=horizon + 1)

    try:
        daily = _unit_delta.load_fr_nuclear_per_unit_daily(start, end, zone="FR")
    except Exception as exc:
        logger.exception("Failed to load FR per-unit availability: %s", exc)
        return go.Figure(), html.Div(
            f"Error loading per-unit availability: {exc}",
            style={"color": "#de350b"},
        )

    if daily is None or daily.empty:
        return go.Figure(), html.Div(
            "No FR per-unit nuclear availability returned from corelib cache "
            "(jain_commods.core.cache.data.fundamentals.GenAvailPerUnitNuclear).",
            style={"color": "#de350b"},
        )

    delta_wide, baseline = _unit_delta.compute_delta_vs_today(
        daily, today=today, forecast_days=horizon,
    )
    if delta_wide is None or delta_wide.empty:
        return go.Figure(), html.Div(
            "Cache loaded but no forward data after today — check cache freshness.",
            style={"color": "#d94f00"},
        )

    fig = _unit_delta.build_delta_figure(
        delta_wide,
        today=today,
        color_by=color_by or "palier",
    )

    n_units = int(delta_wide.shape[1])
    base_total = (
        float(baseline.sum())
        if baseline is not None and not baseline.empty
        else float("nan")
    )
    info = html.Div([
        html.Span(
            f"Today's baseline ({today:%d-%b-%Y}): {base_total:,.0f} MW "
            f"across {n_units} units · ",
            style={"fontWeight": "600"},
        ),
        html.Span(
            f"horizon: {delta_wide.index.min():%d-%b} → "
            f"{delta_wide.index.max():%d-%b} ({len(delta_wide)} days)"
        ),
    ])
    return fig, info


# -----------------------------------------------------------------------------
# Unit Delta (per-unit EQ availability change: latest as-of − reference as-of)
# -----------------------------------------------------------------------------
@callback(
    Output("unit-eq-fuel", "options"),
    Output("unit-eq-fuel", "value"),
    Input("unit-eq-country", "value"),
    State("unit-eq-fuel", "value"),
)
def update_unit_eq_fuel_options(country, current_fuel):
    """Keep the fuel dropdown in sync with the selected country's catalogue."""
    fuels = _unit_eq_delta.list_fuels(country) if country else []
    options = [{"label": f.title(), "value": f} for f in fuels]
    if current_fuel in fuels:
        value = current_fuel
    elif _unit_eq_delta.DEFAULT_FUEL in fuels:
        value = _unit_eq_delta.DEFAULT_FUEL
    else:
        value = fuels[0] if fuels else None
    return options, value


def _as_of_datetime(date_str, hour):
    """Combine a 'YYYY-MM-DD' date string and an integer hour into a datetime."""
    d = datetime.strptime(str(date_str)[:10], "%Y-%m-%d").date()
    return datetime(d.year, d.month, d.day, int(hour or 0))


@callback(
    [Output("unit-eq-delta-heatmap", "figure"),
     Output("unit-eq-delta-info", "children")],
    [Input("unit-eq-refresh", "n_clicks"),
     Input("unit-eq-country", "value"),
     Input("unit-eq-fuel", "value"),
     Input("unit-eq-latest-date", "date"),
     Input("unit-eq-latest-hour", "value"),
     Input("unit-eq-ref-date", "date"),
     Input("unit-eq-ref-hour", "value"),
     Input("unit-eq-range", "value"),
     Input("main-tabs", "value")],
)
def update_unit_eq_delta(
    _n_clicks, country, fuel, latest_date, latest_hour, ref_date, ref_hour,
    range_value, current_tab,
):
    """Render the per-unit availability Δ heatmap for the chosen country/fuel."""
    if current_tab != "tab-unit-eq-delta":
        return go.Figure(), ""

    if not country or not fuel:
        return go.Figure(), html.Div("Select a country and fuel.")

    if not latest_date or not ref_date:
        return go.Figure(), html.Div("Select both a latest and a reference date.")

    try:
        latest_as_of = _as_of_datetime(latest_date, latest_hour)
        reference_as_of = _as_of_datetime(ref_date, ref_hour)
    except Exception:
        return go.Figure(), html.Div("Invalid date/time selection.")

    # Default "latest" = now: when the latest picker is left on today + the
    # current hour, use the precise current timestamp instead of the top of the
    # hour so the most recent REMIT publication is included.
    now = datetime.now()
    if latest_as_of.date() == now.date() and int(latest_hour or 0) == now.hour:
        latest_as_of = now

    # Delivery window is anchored on the latest as-of date and is identical for
    # both snapshots, so the two forecasts are compared over the same dates.
    if range_value and len(range_value) == 2:
        off_start, off_end = int(range_value[0]), int(range_value[1])
    else:
        off_start, off_end = -14, 90
    anchor = latest_as_of.replace(hour=0, minute=0, second=0, microsecond=0)
    begin = anchor + timedelta(days=off_start)
    end = anchor + timedelta(days=off_end + 1)  # EQ end is exclusive

    try:
        unit_curves = _unit_eq_delta.discover_unit_curves(country, fuel)
    except Exception as exc:
        logger.exception("Unit Delta: curve discovery failed")
        return go.Figure(), html.Div(
            f"EQ curve search failed: {exc}", style={"color": "#de350b"},
        )

    if not unit_curves:
        return go.Figure(), html.Div(
            f"No per-unit REMIT availability curves found for {country} / {fuel}.",
            style={"color": "#d94f00"},
        )

    try:
        latest_wide = _unit_eq_delta.fetch_unit_snapshot(
            country, fuel, latest_as_of, begin, end, unit_curves=unit_curves,
        )
        reference_wide = _unit_eq_delta.fetch_unit_snapshot(
            country, fuel, reference_as_of, begin, end, unit_curves=unit_curves,
        )
    except Exception as exc:
        logger.exception("Unit Delta: EQ snapshot fetch failed")
        return go.Figure(), html.Div(
            f"EQ snapshot fetch failed: {exc}", style={"color": "#de350b"},
        )

    delta = _unit_eq_delta.compute_unit_delta(latest_wide, reference_wide)
    latest_label = latest_as_of.strftime("%d %b %Y %H:%M")
    reference_label = reference_as_of.strftime("%d %b %Y %H:%M")

    if delta is None or delta.empty:
        return go.Figure(), html.Div(
            "No overlapping availability data between the two snapshots "
            "for the selected window.",
            style={"color": "#d94f00"},
        )

    fig = build_unit_delta_heatmap(
        delta,
        latest_label=latest_label,
        reference_label=reference_label,
        area=country,
        fuel=fuel,
    )

    n_units = int(delta.shape[1])
    n_changed = int((delta.abs() > 1e-6).any(axis=0).sum())
    info = html.Div([
        html.Span(
            f"{country} {fuel.title()} · {n_units} units · "
            f"{n_changed} with a forecast change · ",
            style={"fontWeight": "600"},
        ),
        html.Span(
            f"delivery {delta.index.min():%d-%b-%Y} → {delta.index.max():%d-%b-%Y} "
            f"({len(delta)} days)"
        ),
    ])
    return fig, info


# -----------------------------------------------------------------------------
# Background data refresh
# -----------------------------------------------------------------------------
@callback(
    [Output("last-refresh-time", "data"), Output("fn-live-status", "children")],
    [Input("data-refresh-interval", "n_intervals")],
    [State("last-refresh-time", "data")],
)
def refresh_data_in_background(n_intervals, last_refresh_data):
    """Poll the S3 store; push a new ``last-refresh-time`` only when its ETag changed."""
    data = fn_data.get_data(force=bool(n_intervals))
    now_paris = _paris_now()
    if data is None:
        return dash.no_update, live_status(None, None, now_paris)
    status = live_status(_paris(data.latest_published_utc), _paris(data.last_modified_utc), now_paris)
    if (last_refresh_data or {}).get("etag") == data.etag:
        return dash.no_update, status
    return {"timestamp": datetime.now().isoformat(), "etag": data.etag}, status
