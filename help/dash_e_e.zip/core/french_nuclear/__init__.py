"""
French Nuclear Availability dashboard package.

Sub-modules (import them explicitly to avoid pulling heavy deps for tests):

    * ``constants``  -- magic numbers, colour palettes, date / slider ranges
    * ``data``       -- model + ``DATA_CACHE`` singletons, scheduler-registered
                       loader (depends on the ``french_nuclear_availability``
                       package + S3)
    * ``charts``     -- pure plotly figure builders
    * ``layout``     -- ``build_layout()`` and tab content factories
    * ``callbacks``  -- Dash callbacks (registered on import)

This file is intentionally side-effect-free: importing
``core.french_nuclear`` *does not* import ``data`` (which would pull in
the heavy availability-model deps).
"""
