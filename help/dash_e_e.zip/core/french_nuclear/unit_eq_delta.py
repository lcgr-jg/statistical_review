"""
Per-unit availability *change* (delta) from the Energy Quantified (EQ) API.

This backs the **Unit Delta** subtab of the Nuclear Availability page.  For a
user-chosen ``(country, fuel)`` it fetches REMIT "Capacity Available MW"
availability **per generation unit**, as known at two publication datetimes:

    latest_avail[unit, delivery_date]      issued_at_latest = <latest as-of>
    reference_avail[unit, delivery_date]   issued_at_latest = <reference as-of>

and exposes the per-unit, per-day **delta** ``latest - reference`` for a heatmap
(y = unit, x = delivery date).

EQ specifics (confirmed against ``jain_commods`` ``EQClient``):

* Fleet curves live in
  ``jain_commods.core.interfaces.energyquantified.curves.AVAILABILITY`` as
  ``{AREA: {fuel: "AREA <Tech> Capacity Available MW REMIT"}}``.
* Per-unit curves share that suffix but carry an ``@place`` token, e.g.
  ``"FR @Golfech Nuclear Capacity Available MW REMIT"`` — discovered via
  :meth:`EQClient.search_curves` and filtered by name pattern (the wrapper's
  curve DataFrame has no ``place`` column, so the unit label is parsed from the
  ``@`` token).
* A snapshot as-of a *datetime* comes from
  :meth:`EQClient.get_latest_period_instance(curve, begin, end,
  issued_at_latest=<datetime>, as_timeseries_frequency="P1D")`.
"""
from __future__ import annotations

import datetime as dt
import logging
import os
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Country / fuel catalogue (drives the dropdowns + fleet-curve resolution)
# ---------------------------------------------------------------------------
#: Minimal fallback used only if ``jain_commods`` is not importable at import
#: time (keeps the dashboard layout building).  The real catalogue is richer.
_FALLBACK_AVAILABILITY: Dict[str, Dict[str, str]] = {
    "FR": {"nuclear": "FR Nuclear Capacity Available MW REMIT"},
}


def _load_catalogue() -> Dict[str, Dict[str, str]]:
    try:
        from jain_commods.core.interfaces.energyquantified.curves import (
            AVAILABILITY,
        )
        return AVAILABILITY
    except Exception as exc:  # pragma: no cover - depends on env
        logger.warning("Could not import EQ AVAILABILITY catalogue: %s", exc)
        return _FALLBACK_AVAILABILITY


#: ``{AREA: {fuel: fleet_curve_name}}`` — resolved once at import.
AVAILABILITY: Dict[str, Dict[str, str]] = _load_catalogue()

#: Default selection.
DEFAULT_AREA = "FR"
DEFAULT_FUEL = "nuclear"


def list_countries() -> List[str]:
    """Sorted area tags, with the default area first."""
    areas = sorted(AVAILABILITY.keys())
    if DEFAULT_AREA in areas:
        areas.remove(DEFAULT_AREA)
        areas.insert(0, DEFAULT_AREA)
    return areas


def list_fuels(area: str) -> List[str]:
    """Sorted fuel keys available for ``area`` (nuclear first when present)."""
    fuels = sorted(AVAILABILITY.get(area, {}).keys())
    if DEFAULT_FUEL in fuels:
        fuels.remove(DEFAULT_FUEL)
        fuels.insert(0, DEFAULT_FUEL)
    return fuels


def fleet_curve_name(area: str, fuel: str) -> Optional[str]:
    """Resolve the fleet REMIT availability curve for ``(area, fuel)`` or None."""
    return AVAILABILITY.get(area, {}).get(fuel)


def _tech_suffix(area: str, fleet_curve: str) -> str:
    """The part of the fleet curve name after the leading ``"{AREA} "``.

    e.g. ``("FR", "FR Nuclear Capacity Available MW REMIT")`` ->
    ``"Nuclear Capacity Available MW REMIT"``.
    """
    prefix = f"{area} "
    return fleet_curve[len(prefix):] if fleet_curve.startswith(prefix) else fleet_curve


# ---------------------------------------------------------------------------
# EQ client (lazy module-singleton)
# ---------------------------------------------------------------------------
_eq_client = None
_eq_lock = threading.Lock()


def _eq_api_key() -> Optional[str]:
    """Resolve the EQ API key, bridging the server's ``EQ_API`` -> ``EQ_API_KEY``."""
    if not os.environ.get("EQ_API_KEY") and os.environ.get("EQ_API"):
        os.environ["EQ_API_KEY"] = os.environ["EQ_API"]
    key = os.environ.get("EQ_API_KEY")
    if key:
        return key
    try:  # jain_commods exposes the resolved key as a constant
        from jain_commods.core.cache.utils.eq import EQ_API_KEY
        return EQ_API_KEY
    except Exception:  # pragma: no cover - depends on env
        return None


def _get_eq_client():
    """Return a cached ``EQClient`` (raises with a clear message if unavailable)."""
    global _eq_client
    if _eq_client is not None:
        return _eq_client
    with _eq_lock:
        if _eq_client is None:
            from jain_commods.core.interfaces.energyquantified import EQClient

            key = _eq_api_key()
            if not key:
                raise RuntimeError(
                    "EQ_API_KEY is not set (and EQ_API fallback is empty); "
                    "cannot query the Energy Quantified API."
                )
            _eq_client = EQClient(api_key=key, timeout=60.0)
    return _eq_client


# ---------------------------------------------------------------------------
# Per-unit curve discovery
# ---------------------------------------------------------------------------
#: ``{(area, fuel): {unit_label: curve_name}}`` — discovery is a metadata call,
#: so cache it for the process lifetime.
_unit_curve_cache: Dict[Tuple[str, str], Dict[str, str]] = {}
_discovery_lock = threading.Lock()


def discover_unit_curves(area: str, fuel: str) -> Dict[str, str]:
    """Return ``{unit_label: curve_name}`` for per-unit REMIT availability curves.

    Returns an empty dict when ``(area, fuel)`` has no per-unit curves (the
    caller renders an empty-state instead of erroring).
    """
    area = area.upper()
    fuel = fuel.lower()
    key = (area, fuel)
    cached = _unit_curve_cache.get(key)
    if cached is not None:
        return cached

    fleet = fleet_curve_name(area, fuel)
    if not fleet:
        logger.info("No fleet availability curve for %s/%s", area, fuel)
        _unit_curve_cache[key] = {}
        return {}

    suffix = _tech_suffix(area, fleet)  # "Nuclear Capacity Available MW REMIT"
    unit_prefix = f"{area} @"

    with _discovery_lock:
        cached = _unit_curve_cache.get(key)
        if cached is not None:
            return cached
        # EQ caps page-size at 250; page through until a short page so we don't
        # silently truncate a large fleet.
        names: List[str] = []
        try:
            client = _get_eq_client()
            page_size = 250
            for page in range(1, 21):  # hard ceiling of 5000 curves
                df = client.search_curves(
                    query=suffix,
                    area=area,
                    as_dataframe=True,
                    page=page,
                    page_size=page_size,
                )
                if df is None or df.empty or "name" not in df.columns:
                    break
                names.extend(df["name"].astype(str).tolist())
                if len(df) < page_size:
                    break
        except Exception as exc:
            logger.exception("EQ curve search failed for %s/%s: %s", area, fuel, exc)
            raise

        units: Dict[str, str] = {}
        for name in names:
            if name.startswith(unit_prefix) and name.endswith(suffix):
                label = name[len(unit_prefix):-len(suffix)].strip()
                if label:
                    units[label] = name
        units = dict(sorted(units.items()))
        _unit_curve_cache[key] = units
        logger.info(
            "Discovered %d per-unit curves for %s/%s", len(units), area, fuel
        )
        return units


# ---------------------------------------------------------------------------
# Snapshot fetch + delta
# ---------------------------------------------------------------------------
def _normalise_daily(df: pd.DataFrame) -> pd.Series:
    """Collapse an EQ daily frame to a tz-naive, date-normalised MW Series."""
    if df is None or df.empty:
        return pd.Series(dtype="float64")
    series = df.iloc[:, 0]
    idx = pd.DatetimeIndex(pd.to_datetime(series.index))
    if idx.tz is not None:
        idx = idx.tz_localize(None)
    out = pd.Series(
        pd.to_numeric(series.to_numpy(), errors="coerce"),
        index=idx.normalize(),
    )
    return out[~out.index.duplicated(keep="last")].sort_index()


def fetch_unit_snapshot(
    area: str,
    fuel: str,
    as_of: dt.datetime,
    begin: dt.datetime,
    end: dt.datetime,
    *,
    unit_curves: Optional[Dict[str, str]] = None,
    max_workers: int = 8,
) -> pd.DataFrame:
    """Wide daily MW frame (index = delivery date, columns = unit) as-of ``as_of``.

    ``unit_curves`` may be passed to reuse a prior :func:`discover_unit_curves`
    result (avoids a second metadata call for the reference snapshot).
    """
    curves = unit_curves if unit_curves is not None else discover_unit_curves(area, fuel)
    if not curves:
        return pd.DataFrame()

    client = _get_eq_client()

    def _fetch(item: Tuple[str, str]) -> Tuple[str, pd.Series]:
        label, curve = item
        try:
            df = client.get_latest_period_instance(
                curve,
                begin=begin,
                end=end,
                issued_at_latest=as_of,
                as_timeseries_frequency="P1D",
            )
            return label, _normalise_daily(df)
        except Exception as exc:  # noqa: BLE001 - one bad unit shouldn't kill the grid
            logger.warning("EQ snapshot failed for %s (%s): %s", label, curve, exc)
            return label, pd.Series(dtype="float64")

    cols: Dict[str, pd.Series] = {}
    workers = max(1, min(max_workers, len(curves)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_fetch, item) for item in curves.items()]
        for fut in as_completed(futures):
            label, series = fut.result()
            if not series.empty:
                cols[label] = series

    if not cols:
        return pd.DataFrame()
    wide = pd.DataFrame(cols).sort_index()
    return wide


def compute_unit_delta(
    latest_wide: pd.DataFrame,
    reference_wide: pd.DataFrame,
) -> pd.DataFrame:
    """``latest - reference`` aligned on the common (delivery date x unit) grid."""
    if latest_wide is None or latest_wide.empty:
        return pd.DataFrame()
    if reference_wide is None or reference_wide.empty:
        return pd.DataFrame()

    common_idx = latest_wide.index.intersection(reference_wide.index)
    common_cols = latest_wide.columns.intersection(reference_wide.columns)
    if len(common_idx) == 0 or len(common_cols) == 0:
        return pd.DataFrame()

    delta = (
        latest_wide.loc[common_idx, common_cols]
        - reference_wide.loc[common_idx, common_cols]
    )
    return delta


__all__ = [
    "AVAILABILITY",
    "DEFAULT_AREA",
    "DEFAULT_FUEL",
    "list_countries",
    "list_fuels",
    "fleet_curve_name",
    "discover_unit_curves",
    "fetch_unit_snapshot",
    "compute_unit_delta",
]
