"""
Constants for the French Nuclear Availability page.

Centralised so the data, chart, layout and callback modules can all import
from one place (no magic numbers scattered through the page). Anything that
depends on "today" is a function so a long-running server never goes stale.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

from core.styles import COLORS  # re-exported


PARIS_TZ = ZoneInfo("Europe/Paris")

# Units to drop from displays (decommissioned reactors)
DECOMMISSIONED_UNITS: tuple[str, ...] = ("FESSENHEIM 1", "FESSENHEIM 2")

# -----------------------------------------------------------------------------
# Date axes
# -----------------------------------------------------------------------------
# Fixed origin of the chart date-range slider (offsets are in days from here,
# which keeps URL-encoded ranges stable from one day to the next).
AXIS_START = date(2025, 1, 1)

# As-of slider: today and the previous N days.
SLIDER_DAYS_RANGE = 30

# Default chart window relative to today.
DEFAULT_WINDOW_BACK_DAYS = 30
DEFAULT_WINDOW_FORWARD_DAYS = 180

# Market-movers lookbacks: label -> hours.
LOOKBACK_OPTIONS = {"2h": 2, "24h": 24, "48h": 48, "7d": 168, "30d": 720}
DEFAULT_LOOKBACK = "24h"


def paris_now() -> datetime:
    return datetime.now(PARIS_TZ)


def paris_today() -> date:
    return paris_now().date()


def axis_end(today: date | None = None) -> date:
    """Last day computed / shown: end of next calendar year (covers Cal+1)."""
    today = today or paris_today()
    return date(today.year + 1, 12, 31)


def days_in_axis(today: date | None = None) -> int:
    return (axis_end(today) - AXIS_START).days + 1


def axis_day(offset: int) -> date:
    return AXIS_START + timedelta(days=int(offset))


def axis_offset(d: date) -> int:
    return (d - AXIS_START).days


def slider_day(offset: int, today: date | None = None) -> date:
    """As-of slider position -> calendar day (offset SLIDER_DAYS_RANGE = today)."""
    today = today or paris_today()
    return today - timedelta(days=SLIDER_DAYS_RANGE - int(offset))


# -----------------------------------------------------------------------------
# Visual constants
# -----------------------------------------------------------------------------
# Availability as % of unit capacity: offline -> partial -> fully available.
AVAILABILITY_COLORSCALE = [
    [0.0, "#b42318"],
    [0.25, "#e8590c"],
    [0.5, "#f5b83d"],
    [0.75, "#a9d4c4"],
    [1.0, "#e9f3ef"],
]

TYPE_COLORS = {
    "planned": "#4E738A",
    "forced": "#d9480f",
}

# Change direction for availability: up = more nuclear, down = less.
UP_COLOR = "#2f9e44"
DOWN_COLOR = "#c92a2a"
NEUTRAL_COLOR = "#868e96"

CHART_FONT_FAMILY = (
    'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
)


__all__ = [
    "COLORS",
    "PARIS_TZ",
    "DECOMMISSIONED_UNITS",
    "AXIS_START",
    "SLIDER_DAYS_RANGE",
    "DEFAULT_WINDOW_BACK_DAYS",
    "DEFAULT_WINDOW_FORWARD_DAYS",
    "LOOKBACK_OPTIONS",
    "DEFAULT_LOOKBACK",
    "paris_now",
    "paris_today",
    "axis_end",
    "days_in_axis",
    "axis_day",
    "axis_offset",
    "slider_day",
    "AVAILABILITY_COLORSCALE",
    "TYPE_COLORS",
    "UP_COLOR",
    "DOWN_COLOR",
    "NEUTRAL_COLOR",
    "CHART_FONT_FAMILY",
]
