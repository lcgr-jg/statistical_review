"""
Reader for the EDF unit-unavailability v2 store on S3 (``remit/edf/``).

The store is written by ``eu_data_scrapes.edf_loader`` (5-minute polls of
EDF's live export plus a 4-hourly data-fair update and reconciliation).
Only the curated nuclear table is read here: one row per
``(outage_id, version)`` with ``valid_from_utc`` / ``valid_to_utc``, so an
as-of snapshot is a single filter.

The S3 object's ETag is re-checked at most every ``REVALIDATE_SECONDS``;
the Parquet is downloaded again only when it changed.
"""
from __future__ import annotations

import io
import json
import logging
import platform
import threading
import time
from dataclasses import dataclass
from typing import Optional

import pandas as pd
import pyarrow.dataset as ds
import pyarrow.parquet as pq

logger = logging.getLogger(__name__)

VERSIONS_KEY = "remit/edf/curated/outage_versions/fuel_type=nuclear/data.parquet"
UNITS_KEY = "remit/edf/curated/units.parquet"
RECONCILE_KEY = "remit/edf/_state/reconcile.json"

REVALIDATE_SECONDS = 120

DECOMMISSIONED_UNITS = ("FESSENHEIM 1", "FESSENHEIM 2")

_VERSION_COLUMNS = [
    "unit_name", "site", "outage_id", "version", "outage_type_norm", "cause", "status",
    "start_utc", "end_utc", "published_utc", "valid_from_utc", "valid_to_utc",
    "is_latest", "capacity_max_mw", "capacity_available_mw", "comment",
    "end_is_placeholder", "source_dataset",
]


@dataclass(frozen=True)
class NuclearOutageData:
    """Planned/forced nuclear outage versions plus fleet capacity."""

    versions: pd.DataFrame
    capacity_mw: pd.Series
    etag: str
    last_modified_utc: pd.Timestamp
    loaded_utc: pd.Timestamp

    @property
    def latest_published_utc(self) -> pd.Timestamp:
        return self.versions["published_utc"].max()

    @property
    def fleet_capacity_mw(self) -> float:
        return float(self.capacity_mw.sum())


_lock = threading.Lock()
_state: dict = {"data": None, "checked": 0.0}
_s3 = None


def _client():
    global _s3
    if _s3 is None:
        from jain_commods.core.cache.utils.s3 import AWS_BUCKET_NAME
        if platform.system().lower() == "windows":
            from jain_commods.core.cache.utils.s3 import S3
            client = S3().get_client()
        else:
            import boto3
            client = boto3.client("s3")
        _s3 = (client, AWS_BUCKET_NAME)
    return _s3


def _head(key: str) -> tuple[str, pd.Timestamp]:
    client, bucket = _client()
    head = client.head_object(Bucket=bucket, Key=key)
    return head["ETag"].strip('"'), pd.Timestamp(head["LastModified"]).tz_convert("UTC")


def _get(key: str) -> bytes:
    client, bucket = _client()
    return client.get_object(Bucket=bucket, Key=key)["Body"].read()


def _load(etag: str, last_modified: pd.Timestamp) -> NuclearOutageData:
    t0 = time.monotonic()
    # Chronicle rows (daily PMIN/aFRR modulation profiles) are ~75% of the
    # file and do not affect availability; skip them at read time.
    versions = pq.read_table(
        io.BytesIO(_get(VERSIONS_KEY)),
        columns=_VERSION_COLUMNS,
        filters=ds.field("event_class") == "outage",
    ).to_pandas()
    versions = versions[~versions["unit_name"].isin(DECOMMISSIONED_UNITS)].reset_index(drop=True)

    units = pd.read_parquet(io.BytesIO(_get(UNITS_KEY)))
    units = units[(units["fuel_type"] == "nuclear") & ~units["unit_name"].isin(DECOMMISSIONED_UNITS)]
    capacity = units.set_index("unit_name")["capacity_max_mw"].dropna().sort_index()

    logger.info("EDF v2 nuclear store loaded: %d outage versions, %d units, %.1fs",
                len(versions), len(capacity), time.monotonic() - t0)
    return NuclearOutageData(versions=versions, capacity_mw=capacity, etag=etag,
                             last_modified_utc=last_modified, loaded_utc=pd.Timestamp.now(tz="UTC"))


def get_data(force: bool = False) -> Optional[NuclearOutageData]:
    """
    Current store contents; re-downloads only when the S3 ETag changed.
    ``force`` re-checks the ETag now instead of waiting for REVALIDATE_SECONDS.
    """
    with _lock:
        now = time.monotonic()
        cached: Optional[NuclearOutageData] = _state["data"]
        if cached is not None and not force and now - _state["checked"] < REVALIDATE_SECONDS:
            return cached
        try:
            etag, last_modified = _head(VERSIONS_KEY)
            if cached is None or etag != cached.etag:
                _state["data"] = _load(etag, last_modified)
            _state["checked"] = now
        except Exception as exc:  # noqa: BLE001 - serve the last good copy
            logger.warning("EDF v2 store refresh failed: %s", exc)
            if cached is None:
                raise
        return _state["data"]


def get_reconcile_report() -> dict:
    """Latest reconciliation of the store against EDF's full export (may be empty)."""
    try:
        return json.loads(_get(RECONCILE_KEY).decode("utf-8"))
    except Exception:  # noqa: BLE001
        return {}


__all__ = [
    "NuclearOutageData",
    "DECOMMISSIONED_UNITS",
    "get_data",
    "get_reconcile_report",
]
