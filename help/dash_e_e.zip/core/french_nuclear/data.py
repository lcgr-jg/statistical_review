"""
French Nuclear data layer.

Source: the EDF unit-unavailability v2 store on S3 (``remit/edf/``), read by
:mod:`core.french_nuclear.edf_store`, which re-checks the S3 ETag every two
minutes. Availability is computed on demand by
:mod:`core.french_nuclear.compute` (a full snapshot takes well under a second)
and memoised.

A snapshot only changes when a publication is crossed, so availability
results are keyed by the number of validity changes at or before the as-of
rather than by wall-clock time: "now" and "24h ago" stay cache hits until
EDF publishes something new, and past days survive new publications. The
cache is cleared on each scheduler reload so in-place corrections of old
versions are picked up.
"""
from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from datetime import date, datetime, timedelta
from typing import List, Optional

import numpy as np
import pandas as pd

from core.data_freshness import tracker
from core.french_nuclear import compute
from core.french_nuclear import edf_store
from core.french_nuclear.constants import (
    AXIS_START,
    SLIDER_DAYS_RANGE,
    axis_end,
    paris_today,
)

logger = logging.getLogger(__name__)

_CACHE_SIZE = 96
_avail_cache: "OrderedDict[tuple, compute.DailyAvailability]" = OrderedDict()
_cache_lock = threading.Lock()
_change_points: dict = {"etag": None, "times": None}


# -----------------------------------------------------------------------------
# Store access
# -----------------------------------------------------------------------------
def get_data(force: bool = False) -> Optional[edf_store.NuclearOutageData]:
    """Current store contents (None if S3 has never been reachable)."""
    try:
        return edf_store.get_data(force=force)
    except Exception as exc:  # noqa: BLE001 - the page shows an empty state
        logger.error("EDF v2 nuclear store unavailable: %s", exc)
        return None


def load_french_nuclear_data() -> Optional[edf_store.NuclearOutageData]:
    """Entry point for the central DataScheduler: refresh and warm the cache."""
    data = get_data(force=True)
    if data is None:
        return None
    with _cache_lock:
        _avail_cache.clear()
    tracker.register_data_source(
        "French Nuclear EDF Data",
        datetime.now(),
        expected_frequency_minutes=15,
        metadata={
            "source": f"s3://.../{edf_store.VERSIONS_KEY}",
            "latest_publication_utc": str(data.latest_published_utc),
            "outage_versions": len(data.versions),
        },
    )
    now = now_utc()
    for t in (now, now - pd.Timedelta(days=1), now - pd.Timedelta(days=7)):
        availability_at(t)
    return data


def _ensure_loaded() -> Optional[edf_store.NuclearOutageData]:
    return get_data()


def now_utc() -> pd.Timestamp:
    return pd.Timestamp.now(tz="UTC")


# -----------------------------------------------------------------------------
# Availability (memoised)
# -----------------------------------------------------------------------------
def _publication_key(data: edf_store.NuclearOutageData, t: pd.Timestamp) -> int:
    """Index of the last validity change at or before ``t`` (snapshot identity)."""
    if _change_points["etag"] != data.etag:
        v = data.versions
        times = pd.concat([v["valid_from_utc"], v["valid_to_utc"]]).dropna().unique()
        _change_points.update(etag=data.etag, times=np.sort(pd.DatetimeIndex(times).asi8))
    return int(np.searchsorted(_change_points["times"], t.value, side="right"))


def availability_at(as_of_utc: pd.Timestamp) -> Optional[compute.DailyAvailability]:
    """Daily availability per unit, as known at ``as_of_utc``, over the chart axis."""
    data = get_data()
    if data is None:
        return None
    today = paris_today()
    key = (_publication_key(data, as_of_utc), today)
    with _cache_lock:
        hit = _avail_cache.get(key)
        if hit is not None:
            _avail_cache.move_to_end(key)
            return hit
    result = compute.daily_availability(
        data.versions, data.capacity_mw, as_of_utc, AXIS_START, axis_end(today)
    )
    with _cache_lock:
        _avail_cache[key] = result
        while len(_avail_cache) > _CACHE_SIZE:
            _avail_cache.popitem(last=False)
    return result


def availability_for_day(d: date) -> Optional[compute.DailyAvailability]:
    """Availability as known at the end of Paris day ``d`` (or now, for today)."""
    return availability_at(compute.as_of_for_day(d, now_utc()))


def history_totals(days: int = SLIDER_DAYS_RANGE, until: Optional[date] = None) -> pd.DataFrame:
    """Fleet GW forecast per as-of day (columns = as-of days, oldest first)."""
    until = until or paris_today()
    out = {}
    for k in range(days, -1, -1):
        d = until - timedelta(days=k)
        res = availability_for_day(d)
        if res is not None:
            out[pd.Timestamp(d)] = res.total_gw
    return pd.DataFrame(out)


# -----------------------------------------------------------------------------
# Convenience accessors
# -----------------------------------------------------------------------------
def get_units() -> List[str]:
    """Nuclear units in fleet order (by reactor series, then name)."""
    data = get_data()
    return compute.unit_order(data.capacity_mw.index) if data is not None else []


def unit_versions(unit: str) -> pd.DataFrame:
    data = get_data()
    if data is None:
        return pd.DataFrame()
    return data.versions[data.versions["unit_name"] == unit]


__all__ = [
    "get_data",
    "load_french_nuclear_data",
    "_ensure_loaded",
    "now_utc",
    "availability_at",
    "availability_for_day",
    "history_totals",
    "get_units",
    "unit_versions",
]
