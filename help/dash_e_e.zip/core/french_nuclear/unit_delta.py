"""
Per-unit French nuclear availability delta vs today.

Loads ``GenAvailPerUnitNuclear`` for FR from the corelib cache
(``jain_commods.core.cache.data.fundamentals.GenAvailPerUnitNuclear``),
resamples to daily means, and computes:

    delta[unit, t] = avail[unit, t] - avail[unit, today]

for the next ``forecast_days`` days.

The module exposes:

* :func:`load_fr_nuclear_per_unit_daily` – wide DataFrame of daily MW per unit.
* :func:`compute_delta_vs_today`           – wide DataFrame of MW deltas vs today.
* :func:`classify_palier`                  – maps a unit_id to its reactor series
  (``CP0``, ``CP1``, ``CP2``, ``CPY``, ``P4``, ``P'4``, ``N4``).
* :func:`build_delta_figure`               – Plotly stacked-area chart with
  positive (green family) and negative (red family) stacks coloured by palier
  plus a thick net-delta line on top.

The classification table is hard-coded from the well-known 56-reactor French
fleet; if a unit_id can't be matched it falls back to ``"Other"`` so the chart
never breaks when naming conventions change.
"""
from __future__ import annotations

import datetime as dt
import logging
import re
from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Reactor series (palier) classification
# ---------------------------------------------------------------------------
# Source: well-known French nuclear fleet structure.
# CP0 (Bugey 2-5, Fessenheim 1-2 – decommissioned), CP1, CP2, CPY (CP1+CP2
# are sometimes lumped as "900 MW CP1/CP2/CPY"), P4 / P'4 (1300 MW),
# N4 (1450 MW).  Kept granular so the legend reads as a trader expects.
_SITE_TO_PALIER: dict[str, str] = {
    # ── 900 MW CP0 ─────────────────────────────────────────────────────────
    "BUGEY":        "CP0",          # Bugey 2-5
    "FESSENHEIM":   "CP0",          # decommissioned but still appears in some caches

    # ── 900 MW CP1 ─────────────────────────────────────────────────────────
    "TRICASTIN":    "CP1",
    "GRAVELINES":   "CP1",
    "DAMPIERRE":    "CP1",
    "BLAYAIS":      "CP1",

    # ── 900 MW CP2 / CPY ───────────────────────────────────────────────────
    # CP2 = Saint-Laurent B, Chinon B, Cruas
    "SAINT-LAURENT": "CP2",
    "ST-LAURENT":    "CP2",
    "ST LAURENT":    "CP2",
    "SAINT LAURENT": "CP2",
    "CHINON":        "CP2",
    "CRUAS":         "CP2",

    # ── 1300 MW P4 ─────────────────────────────────────────────────────────
    "PALUEL":        "P4",
    "FLAMANVILLE":   "P4",          # F1 & F2 are P4; F3 is EPR
    "SAINT-ALBAN":   "P4",
    "ST-ALBAN":      "P4",
    "ST ALBAN":      "P4",

    # ── 1300 MW P'4 ────────────────────────────────────────────────────────
    "CATTENOM":      "P'4",
    "BELLEVILLE":    "P'4",
    "NOGENT":        "P'4",
    "PENLY":         "P'4",
    "GOLFECH":       "P'4",

    # ── 1450 MW N4 ─────────────────────────────────────────────────────────
    "CHOOZ":         "N4",
    "CIVAUX":        "N4",
}

#: Display order (left-to-right in legend / stacking).
PALIER_ORDER: list[str] = ["CP0", "CP1", "CP2", "P4", "P'4", "N4", "EPR", "Other"]

#: Palier → colour (positive stack = bright, negative stack = darker; both
#: use the same hue per palier so a viewer can track the same series across
#: positive ↔ negative regions).
PALIER_COLOR: dict[str, str] = {
    "CP0":   "#4E738A",   # muted blue
    "CP1":   "#36b37e",   # green
    "CP2":   "#5ba37f",   # darker green
    "P4":    "#ff8c42",   # orange
    "P'4":   "#de350b",   # red-orange
    "N4":    "#7A4FAB",   # purple
    "EPR":   "#FFC400",   # gold (Flamanville 3, future)
    "Other": "#8c97a3",
}


def classify_palier(unit_id: str) -> str:
    """Return the reactor series (``palier``) for a French nuclear unit_id.

    Matches by stripping numbers/punctuation and looking up the leading site
    name. Returns ``"Other"`` if no match is found.

    Examples
    --------
    >>> classify_palier("GRAVELINES 4")
    'CP1'
    >>> classify_palier("CHOOZ B1")
    'N4'
    >>> classify_palier("Saint-Alban-2")
    'P4'
    """
    if unit_id is None:
        return "Other"
    s = str(unit_id).upper()
    # Strip trailing reactor numbers / suffixes ("GRAVELINES 4" -> "GRAVELINES")
    s_clean = re.sub(r"[\s\-_]*\b[A-Z]?\d+\b\s*$", "", s).strip()
    # Try direct match
    if s_clean in _SITE_TO_PALIER:
        return _SITE_TO_PALIER[s_clean]
    # Try fuzzy contains (handles "FR_GRAVELINES_4", "Gravelines-4" etc.)
    for site, palier in _SITE_TO_PALIER.items():
        if site in s:
            return palier
    # Special case: Flamanville 3 (EPR) vs Flamanville 1/2 (P4)
    if "FLAMANVILLE" in s and re.search(r"\b3\b", s):
        return "EPR"
    return "Other"


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def load_fr_nuclear_per_unit_daily(
    start: dt.date,
    end: dt.date,
    *,
    zone: str = "FR",
) -> pd.DataFrame:
    """Load FR nuclear per-unit availability from the corelib cache.

    Returns a wide DataFrame indexed by date (DatetimeIndex, naive) with one
    column per unit_id and values in MW (daily mean).  Empty DataFrame on
    failure / no data.
    """
    try:
        from jain_commods.core.cache.data.fundamentals import GenAvailPerUnitNuclear
    except Exception as exc:  # pragma: no cover - depends on env
        logger.error("Could not import GenAvailPerUnitNuclear from jain_commods: %s", exc)
        return pd.DataFrame()

    try:
        instance = GenAvailPerUnitNuclear(zone=zone)
        try:
            instance.load(from_s3=True, start_date=start, end_date=end, show_metadata=False)
        except TypeError:
            # Older signature
            instance.load(from_s3=True, show_metadata=False)
        if instance.data is None or instance.data.empty:
            instance.load(from_s3=False, show_metadata=False)
    except Exception as exc:
        logger.exception("Failed to load GenAvailPerUnitNuclear(%s): %s", zone, exc)
        return pd.DataFrame()

    if instance.data is None or instance.data.empty:
        logger.warning("GenAvailPerUnitNuclear(%s) returned empty data", zone)
        return pd.DataFrame()

    df = instance.data.copy()
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    if df.index.tz is not None:
        df.index = df.index.tz_localize(None)

    # Resample to daily mean (cache is hourly).
    df_daily = df.resample("D").mean()
    df_daily = df_daily.loc[
        (df_daily.index >= pd.Timestamp(start)) & (df_daily.index <= pd.Timestamp(end))
    ]
    return df_daily


def compute_delta_vs_today(
    daily_wide: pd.DataFrame,
    *,
    today: Optional[dt.date] = None,
    forecast_days: int = 90,
) -> tuple[pd.DataFrame, pd.Series]:
    """Compute per-unit delta vs today's availability.

    Parameters
    ----------
    daily_wide
        Output of :func:`load_fr_nuclear_per_unit_daily`. Columns = unit_id.
    today
        Reference day. Defaults to the last available date that is ≤ today.
    forecast_days
        Number of forward days to keep (today + 1 … today + forecast_days).

    Returns
    -------
    delta_wide
        DataFrame indexed by date (today+1 … today+forecast_days), one column
        per unit_id, value in MW = avail[t] - avail[today].
    today_avail
        Series of today's availability per unit (the baseline).
    """
    if daily_wide is None or daily_wide.empty:
        return pd.DataFrame(), pd.Series(dtype=float)

    today = today or dt.date.today()
    today_ts = pd.Timestamp(today).normalize()

    # Pick "today" row: prefer exact match, else last available <= today.
    if today_ts in daily_wide.index:
        baseline = daily_wide.loc[today_ts]
    else:
        prior = daily_wide.loc[daily_wide.index <= today_ts]
        if prior.empty:
            logger.warning("No availability data on or before %s", today_ts)
            return pd.DataFrame(), pd.Series(dtype=float)
        baseline = prior.iloc[-1]
        logger.info(
            "Today (%s) not in cache, using last available %s as baseline",
            today_ts.date(), prior.index[-1].date(),
        )

    horizon_end = today_ts + pd.Timedelta(days=forecast_days)
    fwd = daily_wide.loc[
        (daily_wide.index > today_ts) & (daily_wide.index <= horizon_end)
    ]
    if fwd.empty:
        return pd.DataFrame(), baseline

    delta_wide = fwd.subtract(baseline, axis=1)
    return delta_wide, baseline


# ---------------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------------
#: Categorical palette used when colouring by individual unit (~56 reactors).
#: Plotly's ``Light24`` is the only built-in 24-hue palette; we cycle if we
#: need more.  Order is stable so the same unit gets the same colour across
#: refreshes for the same DataFrame layout.
_UNIT_PALETTE = [
    "#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F",
    "#EDC948", "#B07AA1", "#FF9DA7", "#9C755F", "#BAB0AC",
    "#1F77B4", "#FF7F0E", "#2CA02C", "#D62728", "#9467BD",
    "#8C564B", "#E377C2", "#7F7F7F", "#BCBD22", "#17BECF",
    "#393B79", "#637939", "#8C6D31", "#843C39", "#7B4173",
    "#5254A3", "#8CA252", "#BD9E39", "#AD494A", "#A55194",
    "#6B6ECF", "#B5CF6B", "#E7BA52", "#D6616B", "#CE6DBD",
    "#9C9EDE", "#CEDB9C", "#E7CB94", "#E7969C", "#DE9ED6",
    "#3182BD", "#E6550D", "#31A354", "#756BB1", "#636363",
    "#6BAED6", "#FD8D3C", "#74C476", "#9E9AC8", "#969696",
    "#9ECAE1", "#FDAE6B", "#A1D99B", "#BCBDDC", "#BDBDBD",
    "#C6DBEF",
]


def build_delta_figure(
    delta_wide: pd.DataFrame,
    *,
    today: Optional[dt.date] = None,
    color_by: str = "palier",
) -> go.Figure:
    """Build the stacked-area + net-line figure.

    Parameters
    ----------
    delta_wide
        Output of :func:`compute_delta_vs_today`.
    today
        Reference date for the title.
    color_by
        ``"palier"`` (default) – stack and colour by reactor series, or
        ``"unit"`` – stack and colour by individual reactor unit.
    """
    if delta_wide is None or delta_wide.empty:
        fig = go.Figure()
        fig.update_layout(
            template="plotly_white",
            annotations=[dict(
                text="No per-unit availability data available for the requested window",
                showarrow=False, font=dict(size=14, color="#323E48"),
            )],
        )
        return fig

    color_by = (color_by or "palier").lower()
    if color_by not in {"palier", "unit"}:
        color_by = "palier"

    units = list(delta_wide.columns)
    pos = delta_wide.clip(lower=0)
    neg = delta_wide.clip(upper=0)

    fig = go.Figure()

    if color_by == "unit":
        _add_unit_stacks(fig, delta_wide, pos, neg, units)
    else:
        _add_palier_stacks(fig, delta_wide, pos, neg, units)

    # ── Net line on top ───────────────────────────────────────────────────────
    net = delta_wide.sum(axis=1)
    fig.add_trace(go.Scatter(
        x=delta_wide.index,
        y=net.values,
        mode="lines",
        name="Net Δ (fleet)",
        line=dict(color="#231F20", width=3),
        hovertemplate="<b>Net fleet Δ</b><br>%{x|%d-%b-%Y}<br>%{y:+,.0f} MW<extra></extra>",
    ))

    # Zero baseline
    fig.add_hline(y=0, line=dict(color="#323E48", width=1, dash="solid"))

    today_str = (today or dt.date.today()).strftime("%d-%b-%Y")
    fig.update_layout(
        title=f"FR Nuclear — Availability Δ vs today ({today_str})",
        template="plotly_white",
        paper_bgcolor="#ffffff",
        plot_bgcolor="#faf9f6",
        xaxis=dict(title="Delivery date", tickformat="%d-%b", gridcolor="#eaeaea"),
        yaxis=dict(title="MW (Δ vs today)", gridcolor="#eaeaea", zeroline=False),
        hovermode="x unified",
        legend=dict(
            title=("Reactor unit" if color_by == "unit" else "Reactor series (palier)"),
            orientation="v",
            x=1.01, y=1.0,
            font=dict(size=10),
            bgcolor="rgba(255,255,255,0.9)",
        ),
        margin=dict(l=70, r=180, t=70, b=60),
        height=560,
    )
    return fig


# ---------------------------------------------------------------------------
# Stacking helpers
# ---------------------------------------------------------------------------
def _add_palier_stacks(
    fig: go.Figure,
    delta_wide: pd.DataFrame,
    pos: pd.DataFrame,
    neg: pd.DataFrame,
    units: list[str],
) -> None:
    """Stack the deltas grouped/coloured by reactor series (palier)."""
    # Drop units that are all-zero across the whole window (no legend entry needed)
    active_units = [u for u in units if (delta_wide[u].abs() > 1e-6).any()]
    unit_palier = {u: classify_palier(u) for u in active_units}
    paliers_present = [p for p in PALIER_ORDER if any(unit_palier[u] == p for u in active_units)]

    def _palier_hover(stack_df: pd.DataFrame, palier: str, sign_label: str) -> list[str]:
        cols = [u for u in stack_df.columns if u in unit_palier and unit_palier[u] == palier]
        if not cols:
            return [""] * len(stack_df.index)
        rows: list[str] = []
        for ts, row in stack_df[cols].iterrows():
            active = row[row.abs() > 1e-6].sort_values(ascending=(sign_label == "negative"))
            if active.empty:
                rows.append(f"{ts:%d-%b-%Y} · {palier}<br>(no active units this side)")
                continue
            lines = [f"<b>{ts:%d-%b-%Y}</b> · {palier} ({sign_label})"]
            for u, v in active.items():
                lines.append(f"  {u}: {v:+,.0f} MW")
            total = active.sum()
            lines.append(f"  <b>{palier} subtotal: {total:+,.0f} MW</b>")
            rows.append("<br>".join(lines))
        return rows

    # Negative stack first (so it draws below)
    for palier in paliers_present:
        cols = [u for u in active_units if unit_palier[u] == palier]
        if not cols:
            continue
        y_neg = neg[cols].sum(axis=1)
        if (y_neg.abs() < 1e-6).all():
            continue
        fig.add_trace(go.Scatter(
            x=delta_wide.index,
            y=y_neg.values,
            mode="lines",
            name=f"{palier} (losing)",
            stackgroup="negative",
            line=dict(width=0.5, color=PALIER_COLOR.get(palier, "#888")),
            fillcolor=_with_alpha(PALIER_COLOR.get(palier, "#888"), 0.55),
            hovertext=_palier_hover(neg, palier, "negative"),
            hoverinfo="text",
            legendgroup=palier,
            showlegend=True,
        ))

    # Positive stack
    for palier in paliers_present:
        cols = [u for u in active_units if unit_palier[u] == palier]
        if not cols:
            continue
        y_pos = pos[cols].sum(axis=1)
        if (y_pos.abs() < 1e-6).all():
            continue
        fig.add_trace(go.Scatter(
            x=delta_wide.index,
            y=y_pos.values,
            mode="lines",
            name=f"{palier} (returning)",
            stackgroup="positive",
            line=dict(width=0.5, color=PALIER_COLOR.get(palier, "#888")),
            fillcolor=_with_alpha(PALIER_COLOR.get(palier, "#888"), 0.85),
            hovertext=_palier_hover(pos, palier, "positive"),
            hoverinfo="text",
            legendgroup=palier,
            showlegend=False,  # one legend entry per palier (the negative trace)
        ))


def _add_unit_stacks(
    fig: go.Figure,
    delta_wide: pd.DataFrame,
    pos: pd.DataFrame,
    neg: pd.DataFrame,
    units: list[str],
) -> None:
    """Stack the deltas grouped/coloured by individual reactor unit.

    * Units with zero delta across the whole window are skipped entirely
      (including from the legend).
    * Legend is split into two groups: "Returning capacity (Δ > 0)" and
      "Losing capacity (Δ < 0)".  A unit that flips sign day-to-day appears
      in both groups.
    * Units are ordered by absolute total contribution so the biggest movers
      sit nearest the zero line.
    """
    # Drop units that are all-zero across the entire window
    nonzero_units = [u for u in units if (delta_wide[u].abs() > 1e-6).any()]
    abs_total = delta_wide[nonzero_units].abs().sum(axis=0).sort_values(ascending=False)
    unit_order = list(abs_total.index)
    unit_color = {u: _UNIT_PALETTE[i % len(_UNIT_PALETTE)] for i, u in enumerate(unit_order)}

    # Track whether each unit has already received a legend entry in each group
    # so we emit exactly one entry per (unit, group) pair.
    legend_pos_done: set[str] = set()
    legend_neg_done: set[str] = set()

    # ── Negative stack first (draws below zero) ───────────────────────────────
    for u in unit_order:
        y_neg = neg[u]
        if (y_neg.abs() < 1e-6).all():
            continue
        col = unit_color[u]
        show = u not in legend_neg_done
        if show:
            legend_neg_done.add(u)
        fig.add_trace(go.Scatter(
            x=delta_wide.index,
            y=y_neg.values,
            mode="lines",
            name=u,
            stackgroup="negative",
            line=dict(width=0.3, color=col),
            fillcolor=_with_alpha(col, 0.55),
            legendgroup="neg",
            legendgrouptitle=dict(text="Losing capacity (Δ < 0)") if not legend_neg_done - {u} else {},
            showlegend=show,
            hovertemplate=(
                f"<b>{u}</b><br>%{{x|%d-%b-%Y}}<br>%{{y:+,.0f}} MW<extra></extra>"
            ),
        ))

    # ── Positive stack ────────────────────────────────────────────────────────
    for u in unit_order:
        y_pos = pos[u]
        if (y_pos.abs() < 1e-6).all():
            continue
        col = unit_color[u]
        show = u not in legend_pos_done
        if show:
            legend_pos_done.add(u)
        fig.add_trace(go.Scatter(
            x=delta_wide.index,
            y=y_pos.values,
            mode="lines",
            name=u,
            stackgroup="positive",
            line=dict(width=0.3, color=col),
            fillcolor=_with_alpha(col, 0.85),
            legendgroup="pos",
            legendgrouptitle=dict(text="Returning capacity (Δ > 0)") if not legend_pos_done - {u} else {},
            showlegend=show,
            hovertemplate=(
                f"<b>{u}</b><br>%{{x|%d-%b-%Y}}<br>%{{y:+,.0f}} MW<extra></extra>"
            ),
        ))


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------
def _with_alpha(hex_color: str, alpha: float) -> str:
    """Return ``rgba(...)`` string for a #rrggbb colour with given alpha."""
    h = hex_color.lstrip("#")
    if len(h) != 6:
        return hex_color
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{alpha:.2f})"
