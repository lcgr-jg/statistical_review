"""
French Nuclear page layout (pure-function builders).

``build_layout()`` is the page entry point. The ``render_*_tab()`` functions
are used by the tab-content callback to swap the active panel, and the small
component helpers (KPI cards, tables) are filled in by callbacks.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional, Sequence

import pandas as pd
from dash import dash_table, dcc, html

from core.french_nuclear import compute
from core.french_nuclear.constants import (
    DEFAULT_LOOKBACK,
    DEFAULT_WINDOW_BACK_DAYS,
    DEFAULT_WINDOW_FORWARD_DAYS,
    DOWN_COLOR,
    LOOKBACK_OPTIONS,
    SLIDER_DAYS_RANGE,
    UP_COLOR,
    axis_day,
    axis_offset,
    days_in_axis,
    paris_today,
    slider_day,
)
from core.french_nuclear.unit_eq_delta import (
    DEFAULT_AREA,
    DEFAULT_FUEL,
    list_countries,
    list_fuels,
)
from core.state import build_location


# id of the dcc.Location that backs URL-state sync for this page
URL_LOCATION_ID = "fn-url"

# Background poll of the S3 store (the reader revalidates its ETag at most
# every two minutes, so this is cheap when nothing changed).
REFRESH_INTERVAL_MS = 5 * 60 * 1000

_GRAPH_CONFIG = {"displaylogo": False, "modeBarButtonsToRemove": ["lasso2d", "select2d"]}


def _graph(id_: str, height: Optional[int] = None) -> dcc.Graph:
    style = {"height": f"{height}px"} if height else {}
    return dcc.Graph(id=id_, config=_GRAPH_CONFIG, style=style)


def build_layout() -> html.Div:
    """Top-level page layout with tabs and shared hidden stores."""
    tabs = [
        ("Overview", "tab-availability"),
        ("Market Movers", "tab-movers"),
        ("Outage Explorer", "tab-outages"),
        ("Unit Δ vs Today", "tab-unit-delta"),
        ("Unit Delta", "tab-unit-eq-delta"),
        ("Other Nuclear", "tab-other-nuclear"),
    ]
    return html.Div(
        [
            build_location(URL_LOCATION_ID),
            html.Div(
                [
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H2("French Nuclear Availability", className="fn-title"),
                                    html.Span("EDF REMIT unit unavailabilities", className="fn-subtitle"),
                                ]
                            ),
                            html.Div(id="fn-live-status", className="fn-live"),
                        ],
                        className="fn-header",
                    ),
                    dcc.Tabs(
                        id="main-tabs",
                        value="tab-availability",
                        className="fn-tabs",
                        children=[
                            dcc.Tab(label=label, value=value, className="fn-tab",
                                    selected_className="fn-tab--selected")
                            for label, value in tabs
                        ],
                    ),
                    html.Div(id="tab-content", className="fn-panel"),
                ],
                className="dashboard-container fn-page",
            ),
            # Play animation of the as-of slider; disabled by default.
            dcc.Interval(id="interval-component", interval=1333, n_intervals=0, disabled=True),
            dcc.Interval(id="data-refresh-interval", interval=REFRESH_INTERVAL_MS, n_intervals=0),
            dcc.Store(id="last-refresh-time", data={"timestamp": datetime.now().isoformat()}),
        ],
        className="fn-root",
    )


# -----------------------------------------------------------------------------
# Shared components
# -----------------------------------------------------------------------------
def kpi_card(label: str, value: str, sub: str = "", tone: str = "neutral") -> html.Div:
    """Compact KPI tile; ``tone`` is one of neutral / up / down / warn."""
    return html.Div(
        [
            html.Div(label, className="fn-kpi__label"),
            html.Div(value, className="fn-kpi__value"),
            html.Div(sub, className="fn-kpi__sub"),
        ],
        className=f"fn-kpi fn-kpi--{tone}",
    )


def live_status(latest_pub_paris: Optional[datetime], store_updated_paris: Optional[datetime],
                checked_paris: datetime) -> list:
    """Header pill: last nuclear publication, last store write, last check (all Paris time)."""
    if latest_pub_paris is None:
        return [html.Span(className="fn-dot fn-dot--down"), "EDF store unavailable"]
    return [
        html.Span(className="fn-dot fn-dot--up"),
        html.Span("Latest nuclear publication "),
        html.B(f"{latest_pub_paris:%d %b %H:%M}"),
        html.Span(f" · store updated {store_updated_paris:%H:%M} · checked {checked_paris:%H:%M} Paris",
                  className="fn-muted"),
    ]


def _card(children, **kw) -> html.Div:
    return html.Div(children, className="fn-card", **kw)


def _control(label: str, control, grow: bool = False) -> html.Div:
    return html.Div(
        [html.Div(label, className="fn-control__label"), control],
        className="fn-control" + (" fn-control--grow" if grow else ""),
    )


# -----------------------------------------------------------------------------
# Overview tab
# -----------------------------------------------------------------------------
def render_availability_tab() -> html.Div:
    """KPIs, as-of controls, forecast with history band, unavailability split, heatmap."""
    today = paris_today()
    n_days = days_in_axis(today)
    window = [
        max(0, axis_offset(today - timedelta(days=DEFAULT_WINDOW_BACK_DAYS))),
        min(n_days - 1, axis_offset(today + timedelta(days=DEFAULT_WINDOW_FORWARD_DAYS))),
    ]
    month_marks = {}
    for i in range(n_days):
        d = axis_day(i)
        if d.day == 1 and d.month in (1, 4, 7, 10):
            month_marks[i] = {"label": d.strftime("%b %y"), "style": {"fontSize": "10px"}}
    slider_marks = {
        i: {"label": slider_day(i, today).strftime("%d %b"), "style": {"fontSize": "10px"}}
        for i in range(0, SLIDER_DAYS_RANGE + 1, 5)
    }
    return html.Div(
        [
            html.Div(id="fn-kpis", className="fn-kpis"),
            _card(
                [
                    html.Div(
                        [
                            html.Button("▶ Play", id="play-pause-button", n_clicks=0,
                                        className="fn-btn"),
                            _control(
                                "As-of date",
                                dcc.Slider(
                                    id="date-slider", min=0, max=SLIDER_DAYS_RANGE, step=1,
                                    value=SLIDER_DAYS_RANGE, marks=slider_marks, included=False,
                                ),
                                grow=True,
                            ),
                            html.Div(id="selected-date-display", className="fn-pill"),
                        ],
                        className="fn-controls",
                    ),
                    html.Div(
                        [
                            _control(
                                "Delivery window",
                                dcc.RangeSlider(
                                    id="date-range-slider", min=0, max=n_days - 1, step=1,
                                    value=window, marks=month_marks, allowCross=False,
                                ),
                                grow=True,
                            ),
                            html.Div(id="date-range-display", className="fn-pill fn-pill--muted"),
                        ],
                        className="fn-controls",
                    ),
                    _build_info_banner(),
                ]
            ),
            _card(dcc.Loading(_graph("availability-line-chart"), type="dot")),
            _card(_graph("fn-unavail-chart")),
            _card(_graph("availability-heatmap")),
        ]
    )


def _build_info_banner() -> html.Details:
    return html.Details(
        [
            html.Summary("About this data", className="fn-details__summary"),
            html.Div(
                [
                    html.Div([html.B("As-of: "), html.Span(id="current-date-badge")]),
                    html.Div([
                        html.B("Source: "),
                        "EDF unit unavailabilities (REMIT), every published version, "
                        "stored on S3 under remit/edf/ and polled every 5 minutes.",
                    ]),
                    html.Div([
                        html.B("Method: "),
                        "for each hour, a unit's availability is the lowest available MW among the "
                        "outages valid at the as-of time; cancelled or deleted outages are ignored. "
                        "Past as-of dates use what was known at the end of that Paris day.",
                    ]),
                    html.Div(id="fn-capacity-note"),
                ],
                className="fn-details__body",
            ),
        ],
        className="fn-details",
    )


# -----------------------------------------------------------------------------
# Market movers tab
# -----------------------------------------------------------------------------
def render_movers_tab() -> html.Div:
    """What changed over the lookback: by delivery bucket, by outage, slippage and overrun context."""
    buckets = [{"label": "Largest move", "value": "auto"}] + [
        {"label": label, "value": label} for label, _, _ in compute.delivery_buckets(paris_today())
    ]
    return html.Div(
        [
            _card(
                html.Div(
                    [
                        _control(
                            "Lookback",
                            dcc.RadioItems(
                                id="fn-lookback",
                                options=[{"label": k, "value": k} for k in LOOKBACK_OPTIONS],
                                value=DEFAULT_LOOKBACK, inline=True, className="fn-segmented",
                            ),
                        ),
                        _control(
                            "Minimum outage size",
                            dcc.Dropdown(
                                id="fn-min-mw",
                                options=[{"label": f"{v:,} MW", "value": v} for v in (0, 100, 300, 600, 900)],
                                value=300, clearable=False, style={"width": "130px"},
                            ),
                        ),
                        _control(
                            "Waterfall period",
                            dcc.Dropdown(id="fn-wf-bucket", options=buckets, value="auto",
                                         clearable=False, style={"width": "150px"}),
                        ),
                    ],
                    className="fn-controls",
                )
            ),
            html.Div(id="fn-movers-kpis", className="fn-kpis"),
            html.Div(
                [
                    _card(dcc.Loading(_graph("fn-bucket-chart"), type="dot"), style={"flex": "3 1 560px"}),
                    _card(_graph("fn-waterfall"), style={"flex": "2 1 380px"}),
                ],
                className="fn-row",
            ),
            _card(
                [
                    html.Div(
                        [
                            html.Span("Outage revisions", className="fn-card__title"),
                            html.Span(id="fn-changes-caption", className="fn-muted"),
                        ],
                        className="fn-card__header",
                    ),
                    html.Div(id="fn-changes-table"),
                ]
            ),
            _card(dcc.Loading(_graph("fn-gantt"), type="dot")),
            _card(_graph("fn-overrun")),
        ]
    )


_CHANGE_COLORS = {
    "Extended": "rgba(201, 42, 42, 0.10)",
    "New": "rgba(240, 140, 0, 0.12)",
    "Shortened": "rgba(47, 158, 68, 0.10)",
    "Withdrawn": "rgba(47, 158, 68, 0.10)",
}


def _table_style(numeric_cols: Sequence[str]) -> dict:
    return dict(
        style_table={"overflowX": "auto"},
        style_header={"backgroundColor": "#f8f9fa", "fontWeight": "600", "border": "none",
                      "borderBottom": "1px solid #dee2e6", "fontSize": "12px", "color": "#495057"},
        style_cell={"fontFamily": "inherit", "fontSize": "12px", "padding": "6px 10px",
                    "border": "none", "borderBottom": "1px solid #f1f3f5", "textAlign": "left",
                    "whiteSpace": "nowrap", "maxWidth": "420px", "overflow": "hidden",
                    "textOverflow": "ellipsis"},
        style_cell_conditional=[{"if": {"column_id": c}, "textAlign": "right"} for c in numeric_cols],
    )


def changes_table(ch: pd.DataFrame) -> dash_table.DataTable | html.Div:
    """Revisions table: one row per outage touched in the lookback, biggest energy impact first."""
    if ch is None or ch.empty:
        return html.Div("No outage publications in the lookback.", className="fn-empty")
    t = pd.DataFrame({
        "published": compute.to_paris_naive(ch["published_utc"]).dt.strftime("%d %b %H:%M"),
        "unit": ch["unit_name"],
        "type": ch["outage_type_norm"].str.title(),
        "change": ch["change"],
        "start": compute.to_paris_naive(ch["start_utc_new"].fillna(ch["start_utc_old"])).dt.strftime("%d %b %y %H:%M"),
        "end": compute.to_paris_naive(ch["end_utc_new"].fillna(ch["end_utc_old"])).dt.strftime("%d %b %y %H:%M"),
        "end_shift": ch["end_shift_days"].round(1),
        "mw": ch["unav_mw_new"].where(ch["start_utc_new"].notna(), ch["unav_mw_old"]).round(0),
        "delta_gwh": ch["delta_gwh"].round(0),
        "revs": ch["n_revisions"],
        "comment": ch["comment"].fillna("").str.replace(r"\s+", " ", regex=True),
    })
    cols = [
        ("Published", "published", "text"), ("Unit", "unit", "text"), ("Type", "type", "text"),
        ("Change", "change", "text"), ("Start", "start", "text"), ("End", "end", "text"),
        ("End shift (d)", "end_shift", "numeric"), ("MW off", "mw", "numeric"),
        ("Δ GWh", "delta_gwh", "numeric"), ("Revs", "revs", "numeric"), ("Comment", "comment", "text"),
    ]
    numeric = [c for _, c, kind in cols if kind == "numeric"]
    cond = [
        {"if": {"filter_query": f'{{change}} = "{k}"'}, "backgroundColor": v}
        for k, v in _CHANGE_COLORS.items()
    ] + [
        {"if": {"filter_query": "{delta_gwh} > 0", "column_id": "delta_gwh"}, "color": DOWN_COLOR, "fontWeight": "600"},
        {"if": {"filter_query": "{delta_gwh} < 0", "column_id": "delta_gwh"}, "color": UP_COLOR, "fontWeight": "600"},
        {"if": {"filter_query": "{end_shift} > 0", "column_id": "end_shift"}, "color": DOWN_COLOR},
        {"if": {"filter_query": "{end_shift} < 0", "column_id": "end_shift"}, "color": UP_COLOR},
    ]
    return dash_table.DataTable(
        id="fn-changes-datatable",
        columns=[
            {"name": n, "id": c, "type": kind,
             **({"format": {"specifier": "+,.1f" if c == "end_shift" else "+,.0f" if c == "delta_gwh" else ",.0f"}}
                if kind == "numeric" else {})}
            for n, c, kind in cols
        ],
        data=t.to_dict("records"),
        tooltip_data=[{"comment": {"value": c, "type": "text"}} for c in t["comment"]],
        tooltip_duration=None,
        sort_action="native",
        filter_action="native",
        page_size=15,
        style_data_conditional=cond,
        **_table_style(numeric),
    )


# -----------------------------------------------------------------------------
# Outage explorer tab
# -----------------------------------------------------------------------------
def render_outages_tab(units: Sequence[str]) -> html.Div:
    """Unit and outage pickers, unit timeline, announcement drift and version table."""
    return html.Div(
        [
            _card(
                html.Div(
                    [
                        _control(
                            "Unit",
                            dcc.Dropdown(
                                id="plant-dropdown",
                                options=[{"label": u, "value": u} for u in units],
                                value=units[0] if units else None,
                                clearable=False, style={"width": "220px"},
                            ),
                        ),
                        _control(
                            "Outage",
                            dcc.Dropdown(id="fn-outage-dropdown", clearable=False, style={"minWidth": "520px"}),
                            grow=True,
                        ),
                    ],
                    className="fn-controls",
                )
            ),
            html.Div(id="fn-unit-kpis", className="fn-kpis"),
            _card(_graph("fn-unit-timeline")),
            _card(dcc.Loading(_graph("fn-drift-chart"), type="dot")),
            _card(
                [
                    html.Div(html.Span("Published versions", className="fn-card__title"),
                             className="fn-card__header"),
                    html.Div(id="fn-version-table"),
                ]
            ),
        ]
    )


def outage_option_label(row: pd.Series) -> str:
    start = compute.to_paris_naive(row["start_utc"])
    end = compute.to_paris_naive(row["end_utc"])
    status = "" if row["status"] == "active" else f" · {row['status']}"
    return (f"{start:%d %b %Y} → {end:%d %b %Y} · {row['outage_type_norm']} · "
            f"{row['n_versions']} versions{status}")


def versions_table(ov: pd.DataFrame) -> dash_table.DataTable | html.Div:
    if ov is None or ov.empty:
        return html.Div("No versions.", className="fn-empty")
    v = ov.sort_values("version", ascending=False)
    t = pd.DataFrame({
        "version": v["version"],
        "published": compute.to_paris_naive(v["published_utc"]).dt.strftime("%d %b %Y %H:%M"),
        "status": v["status"],
        "start": compute.to_paris_naive(v["start_utc"]).dt.strftime("%d %b %Y %H:%M"),
        "end": compute.to_paris_naive(v["end_utc"]).dt.strftime("%d %b %Y %H:%M"),
        "end_shift": (-(v["end_utc"].diff(-1)) / compute.DAY).round(2),
        "avail": v["capacity_available_mw"].round(0),
        "cause": v["cause"].fillna(""),
        "source": v["source_dataset"].fillna(""),
        "comment": v["comment"].fillna("").str.replace(r"\s+", " ", regex=True),
    })
    cols = [("v", "version", "numeric"), ("Published", "published", "text"), ("Status", "status", "text"),
            ("Start", "start", "text"), ("End", "end", "text"), ("End shift (d)", "end_shift", "numeric"),
            ("Avail MW", "avail", "numeric"), ("Cause", "cause", "text"), ("Source", "source", "text"),
            ("Comment", "comment", "text")]
    numeric = [c for _, c, kind in cols if kind == "numeric"]
    return dash_table.DataTable(
        columns=[{"name": n, "id": c, "type": kind} for n, c, kind in cols],
        data=t.to_dict("records"),
        tooltip_data=[{"comment": {"value": c, "type": "text"}} for c in t["comment"]],
        tooltip_duration=None,
        page_size=20,
        style_data_conditional=[
            {"if": {"filter_query": "{end_shift} > 0", "column_id": "end_shift"}, "color": DOWN_COLOR, "fontWeight": "600"},
            {"if": {"filter_query": "{end_shift} < 0", "column_id": "end_shift"}, "color": UP_COLOR, "fontWeight": "600"},
            {"if": {"filter_query": '{status} = "cancelled" || {status} = "deleted"'}, "color": "#868e96"},
        ],
        **_table_style(numeric),
    )


def render_unit_delta_tab() -> html.Div:
    """Per-unit availability delta vs today (next N days)."""
    return html.Div(
        [
            html.Div(
                [
                    html.Div(
                        [
                            html.Span(
                                "Forecast horizon (days):",
                                className="control-label",
                            ),
                            dcc.Slider(
                                id="unit-delta-horizon",
                                min=14,
                                max=180,
                                step=7,
                                value=90,
                                marks={d: str(d) for d in (14, 30, 60, 90, 120, 180)},
                                tooltip={
                                    "placement": "bottom",
                                    "always_visible": False,
                                },
                            ),
                        ],
                        style={
                            "flex": "1 1 320px",
                            "minWidth": "280px",
                            "paddingRight": "20px",
                        },
                    ),
                    html.Div(
                        [
                            html.Span("Color by:", className="control-label"),
                            dcc.RadioItems(
                                id="unit-delta-color-by",
                                options=[
                                    {"label": "Reactor series (palier)", "value": "palier"},
                                    {"label": "Reactor unit", "value": "unit"},
                                ],
                                value="palier",
                                inline=True,
                                inputStyle={"marginRight": "4px"},
                                labelStyle={
                                    "marginRight": "12px",
                                    "fontSize": "13px",
                                    "color": "#323E48",
                                },
                            ),
                        ],
                        style={
                            "flex": "0 1 auto",
                            "paddingRight": "20px",
                            "alignSelf": "center",
                        },
                    ),
                    html.Div(
                        [
                            html.Button(
                                "Refresh",
                                id="unit-delta-refresh",
                                n_clicks=0,
                                className="btn btn-primary",
                                style={"marginTop": "20px"},
                            ),
                        ],
                        style={"flex": "0 0 auto"},
                    ),
                ],
                className="controls-row",
                style={
                    "display": "flex",
                    "gap": "12px",
                    "flexWrap": "wrap",
                    "alignItems": "flex-end",
                    "padding": "0 20px",
                    "marginBottom": "16px",
                },
            ),
            dcc.Loading(
                id="unit-delta-loading",
                type="circle",
                children=[
                    html.Div(
                        id="unit-delta-info",
                        style={
                            "padding": "0 20px",
                            "fontSize": "12px",
                            "color": "#323E48",
                        },
                    ),
                    dcc.Graph(id="unit-delta-chart", style={"height": "600px"}),
                ],
            ),
        ]
    )


def render_unit_eq_delta_tab() -> html.Div:
    """Per-unit availability Δ between two EQ publication datetimes.

    For a chosen ``(country, fuel)`` the heatmap shows, per generation unit and
    per delivery date, ``latest_avail − reference_avail`` — i.e. how the REMIT
    forecast changed between the *reference* as-of and the *latest* as-of.
    """
    today = datetime.now().replace(minute=0, second=0, microsecond=0)
    yesterday = today - timedelta(days=1)
    hour_options = [{"label": f"{h:02d}:00", "value": h} for h in range(24)]

    countries = list_countries()
    fuels = list_fuels(DEFAULT_AREA)

    _ctl = {"flex": "0 0 auto", "paddingRight": "16px"}
    _lbl = {"marginBottom": "4px", "display": "block"}

    def _datetime_picker(date_id, hour_id, date_value, hour_value, label):
        return html.Div(
            [
                html.Span(label, className="control-label", style=_lbl),
                html.Div(
                    [
                        dcc.DatePickerSingle(
                            id=date_id,
                            date=date_value.date(),
                            display_format="YYYY-MM-DD",
                            first_day_of_week=1,
                        ),
                        dcc.Dropdown(
                            id=hour_id,
                            options=hour_options,
                            value=hour_value,
                            clearable=False,
                            style={"width": "110px", "marginLeft": "8px"},
                        ),
                    ],
                    style={"display": "flex", "alignItems": "center"},
                ),
            ],
            style=_ctl,
        )

    return html.Div(
        [
            html.Div(
                [
                    html.Div(
                        [
                            html.Span("Country:", className="control-label", style=_lbl),
                            dcc.Dropdown(
                                id="unit-eq-country",
                                options=[{"label": c, "value": c} for c in countries],
                                value=DEFAULT_AREA,
                                clearable=False,
                                style={"width": "120px"},
                            ),
                        ],
                        style=_ctl,
                    ),
                    html.Div(
                        [
                            html.Span("Fuel:", className="control-label", style=_lbl),
                            dcc.Dropdown(
                                id="unit-eq-fuel",
                                options=[{"label": f.title(), "value": f} for f in fuels],
                                value=DEFAULT_FUEL if DEFAULT_FUEL in fuels else (fuels[0] if fuels else None),
                                clearable=False,
                                style={"width": "160px"},
                            ),
                        ],
                        style=_ctl,
                    ),
                    _datetime_picker(
                        "unit-eq-latest-date", "unit-eq-latest-hour",
                        today, today.hour, "Latest as-of:",
                    ),
                    _datetime_picker(
                        "unit-eq-ref-date", "unit-eq-ref-hour",
                        yesterday, yesterday.hour, "Reference as-of:",
                    ),
                    html.Div(
                        [
                            html.Button(
                                "Refresh",
                                id="unit-eq-refresh",
                                n_clicks=0,
                                className="btn btn-primary",
                                style={"marginTop": "20px"},
                            ),
                        ],
                        style={"flex": "0 0 auto"},
                    ),
                ],
                className="controls-row",
                style={
                    "display": "flex",
                    "gap": "8px",
                    "flexWrap": "wrap",
                    "alignItems": "flex-end",
                    "padding": "0 20px",
                    "marginBottom": "16px",
                },
            ),
            html.Div(
                [
                    html.Span(
                        "Delivery date range (days relative to latest as-of):",
                        className="control-label",
                        style={"marginBottom": "8px", "display": "block"},
                    ),
                    dcc.RangeSlider(
                        id="unit-eq-range",
                        min=-180,
                        max=365,
                        step=5,
                        value=[-14, 90],
                        marks={
                            i: {"label": str(i), "style": {"color": "#323E48", "fontSize": "10px"}}
                            for i in range(-180, 366, 60)
                        },
                        tooltip={"placement": "bottom", "always_visible": True},
                        allowCross=False,
                    ),
                ],
                style={"padding": "0 30px", "marginBottom": "16px"},
            ),
            dcc.Loading(
                id="unit-eq-loading",
                type="circle",
                children=[
                    html.Div(
                        id="unit-eq-delta-info",
                        style={"padding": "0 20px", "fontSize": "12px", "color": "#323E48"},
                    ),
                    dcc.Graph(id="unit-eq-delta-heatmap", style={"height": "1000px"}),
                ],
            ),
        ]
    )


__all__ = [
    "URL_LOCATION_ID",
    "build_layout",
    "kpi_card",
    "live_status",
    "changes_table",
    "versions_table",
    "outage_option_label",
    "render_availability_tab",
    "render_movers_tab",
    "render_outages_tab",
    "render_unit_delta_tab",
    "render_unit_eq_delta_tab",
]
