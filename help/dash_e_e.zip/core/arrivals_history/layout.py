"""Layout for the LNG — Arrivals History page."""
from __future__ import annotations

from dash import dcc, html

from core.arrivals_history.constants import (
    ARRIVAL_WINDOWS,
    ASIA_DEST_GROUPS,
    COUNTRY_OPTIONS,
    DEFAULT_ASIA_DEST,
    DEFAULT_COUNTRIES,
    DEFAULT_HISTORY_MONTHS,
    DEFAULT_METRIC,
    DEFAULT_ORIGIN_GROUPS,
    DEFAULT_SOURCES,
    DEFAULT_WINDOW,
    DISPLAY_HISTORY,
    DISPLAY_YOY,
    HISTORY_MONTHS_OPTIONS,
    METRIC_LABELS,
    ORIGIN_GROUP_LABELS,
    SOURCE_OPTIONS,
    WINDOW_LABELS,
)
from core.styles import COLORS

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "flex-end",
    "flexWrap": "wrap",
    "gap": "18px",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}

_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "margin": "8px 0 0 0",
    "lineHeight": "1.5",
}


def build_layout() -> html.Div:
    country_options = [{"label": c, "value": c} for c in COUNTRY_OPTIONS]

    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1400px"},
        children=[
            html.Div([
                html.H1("Arrivals Analysis", style={
                    "fontSize": "22px", "fontWeight": "600",
                    "color": COLORS["text_primary"], "margin": "0 0 4px 0"}),
                html.P(
                    "History of LNG signalling into the zone on each day's "
                    "~06:00 UTC Kpler snapshot (as in the lng_vessels "
                    "report). Switch the Y axis between volume (mcm) and "
                    "cargo count. Reads only from the permanent snapshot "
                    "cache — missing days show as gaps and are never "
                    "fetched from Kpler here.",
                    style={"fontSize": "13px", "color": COLORS["text_muted"],
                           "margin": "0 0 12px 0"}),
            ]),

            # ── Controls (shared by all charts) ─────────────────────────
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Div(
                        style={"flex": "1 1 320px", "minWidth": "280px"},
                        children=[
                            html.Label("Destination countries "
                                       "(default: NWE zone)", style=_LABEL),
                            dcc.Dropdown(
                                id="ah-countries",
                                options=country_options,
                                value=list(DEFAULT_COUNTRIES),
                                multi=True,
                                placeholder="Pick destination countries…",
                            ),
                        ],
                    ),
                    html.Div(
                        style={"flex": "1 1 240px", "minWidth": "220px"},
                        children=[
                            html.Label("Forecast type (Kpler ETA source)",
                                       style=_LABEL),
                            dcc.Dropdown(
                                id="ah-sources",
                                options=[{"label": s, "value": s}
                                         for s in SOURCE_OPTIONS],
                                value=list(DEFAULT_SOURCES),
                                multi=True,
                                placeholder="Pick ETA sources…",
                            ),
                        ],
                    ),
                    html.Div([
                        html.Label("Arrival window", style=_LABEL),
                        dcc.Dropdown(
                            id="ah-window",
                            options=[{"label": WINDOW_LABELS[w], "value": w}
                                     for w in ARRIVAL_WINDOWS],
                            value=DEFAULT_WINDOW,
                            clearable=False,
                            style={"width": "130px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Y axis", style=_LABEL),
                        dcc.Dropdown(
                            id="ah-metric",
                            options=[{"label": label, "value": value}
                                     for value, label in METRIC_LABELS.items()],
                            value=DEFAULT_METRIC,
                            clearable=False,
                            style={"width": "150px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Display", style=_LABEL),
                        dcc.RadioItems(
                            id="ah-display",
                            options=[
                                {"label": " History window",
                                 "value": DISPLAY_HISTORY},
                                {"label": " Year-on-year (Jan–Dec)",
                                 "value": DISPLAY_YOY},
                            ],
                            value=DISPLAY_HISTORY,
                            style={"fontSize": "13px",
                                   "color": COLORS["text_secondary"]},
                            labelStyle={"display": "block",
                                        "marginBottom": "2px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("History", style=_LABEL),
                        dcc.Dropdown(
                            id="ah-months",
                            options=[{"label": f"{m} months", "value": m}
                                     for m in HISTORY_MONTHS_OPTIONS],
                            value=DEFAULT_HISTORY_MONTHS,
                            clearable=False,
                            style={"width": "140px"},
                        ),
                    ]),
                ],
            ),

            # ── Chart 1: zone arrivals ──────────────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="ah-chart", config={"displayModeBar": False})),
                html.Div(id="ah-status", style=_NOTE),
                html.P(
                    "Y axis is destination volume (mcm) or cargo count of "
                    "In Transit / Loading cargoes — same definition as "
                    "the lng_vessels report series. The arrival window "
                    "keeps only cargoes forecast to arrive within N days "
                    "of each snapshot. To fill gaps, backfill snapshots "
                    "from the Cargo DoD Changes page (Snapshot cache "
                    "status) or via "
                    "eu_corelib/scripts/backfill_kpler_snapshots.py.",
                    style=_NOTE),
            ]),

            # ── Chart 2: Europe, no specific country ────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.Div(
                    style={"maxWidth": "420px", "marginBottom": "10px"},
                    children=[
                        html.Label("Forecast type (Kpler ETA source)",
                                   style=_LABEL),
                        dcc.Dropdown(
                            id="ah-eu-sources",
                            options=[{"label": s, "value": s}
                                     for s in SOURCE_OPTIONS],
                            value=list(SOURCE_OPTIONS),
                            multi=True,
                            placeholder="Pick ETA sources…",
                        ),
                    ],
                ),
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="ah-chart-eu", config={"displayModeBar": False})),
                html.P(
                    "Cargoes whose Kpler destination is only the generic "
                    "\"Europe\" continent with no specific country assigned "
                    "yet. These are almost always Model/Analyst forecasts "
                    "(a Port or AIS signal implies a specific port), hence "
                    "the separate ETA source selector defaulting to all "
                    "sources. Arrival window and display settings from the "
                    "top controls apply; the country selector does not.",
                    style=_NOTE),
            ]),

            # ── Chart 3: Asia destinations (any origin) ─────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.Div(
                    style={"maxWidth": "360px", "marginBottom": "10px"},
                    children=[
                        html.Label("Destination", style=_LABEL),
                        dcc.Dropdown(
                            id="ah-asia-dest",
                            options=[{"label": g, "value": g}
                                     for g in sorted(ASIA_DEST_GROUPS)],
                            value=DEFAULT_ASIA_DEST,
                            clearable=False,
                        ),
                    ],
                ),
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="ah-chart-asia", config={"displayModeBar": False})),
                html.P(
                    "Total LNG from any origin signalling the selected "
                    "destination (volume or cargo count, per the Y axis "
                    "control). ETA source, arrival window and display "
                    "settings from the top controls apply; the country "
                    "selector does not.",
                    style=_NOTE),
            ]),

            # ── Chart 4: US/WAF exports Europe vs Asia ──────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.Div(
                    style={"display": "flex", "gap": "24px",
                           "flexWrap": "wrap", "alignItems": "flex-end",
                           "marginBottom": "10px"},
                    children=[
                        html.Div([
                            html.Label("Origin", style=_LABEL),
                            dcc.Checklist(
                                id="ah-origins",
                                options=[{"label": f" {label}", "value": v}
                                         for v, label
                                         in ORIGIN_GROUP_LABELS.items()],
                                value=list(DEFAULT_ORIGIN_GROUPS),
                                inline=True,
                                inputStyle={"marginLeft": "12px"},
                                style={"fontSize": "13px",
                                       "color": COLORS["text_secondary"]},
                            ),
                        ]),
                        html.Div(
                            style={"flex": "1 1 420px", "minWidth": "320px",
                                   "maxWidth": "560px"},
                            children=[
                                html.Label(
                                    "Europe = these destination countries "
                                    "(default: NWE zone)", style=_LABEL),
                                dcc.Dropdown(
                                    id="ah-us-countries",
                                    options=country_options,
                                    value=list(DEFAULT_COUNTRIES),
                                    multi=True,
                                    placeholder="Pick destination countries…",
                                ),
                            ],
                        ),
                    ],
                ),
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="ah-chart-us", config={"displayModeBar": False})),
                html.P(
                    "Share of the selected origins' on-water volume "
                    "signalling to the selected European countries vs the "
                    "Asia continent, as a percentage of all In Transit / "
                    "Loading volume from those origins (any destination, "
                    "including unassigned — so the two lines do not sum to "
                    "100%). WAF = Nigeria, Angola, Equatorial Guinea, "
                    "Cameroon, Republic of the Congo, Mauritania, Senegal. "
                    "ETA source, arrival window and display settings from "
                    "the top controls apply. In year-on-year mode only the "
                    "Europe share is shown.",
                    style=_NOTE),
            ]),

            # ── Chart 5: US origin, NWE vs other named Europe ───────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.Div(
                    style={"maxWidth": "420px", "marginBottom": "10px"},
                    children=[
                        html.Label("Forecast type (Kpler ETA source)",
                                   style=_LABEL),
                        dcc.Dropdown(
                            id="ah-us-nwe-sources",
                            options=[{"label": s, "value": s}
                                     for s in SOURCE_OPTIONS],
                            value=list(SOURCE_OPTIONS),
                            multi=True,
                            placeholder="Pick ETA sources…",
                        ),
                    ],
                ),
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="ah-chart-us-nwe",
                    config={"displayModeBar": False})),
                html.P(
                    "Share of US-origin cargoes signalling the NWE zone "
                    "(Belgium, Germany, France, United Kingdom, Italy, "
                    "Netherlands) vs all other named European countries. "
                    "Generic \"Europe\" (no country assigned) is excluded "
                    "from both series and the denominator, so the two "
                    "lines sum to 100% of US cargoes with a named "
                    "European destination. Arrival window, Y axis and "
                    "display settings from the top controls apply; the "
                    "country selector does not. In year-on-year mode "
                    "only the NWE share is shown.",
                    style=_NOTE),
            ]),
        ],
    )
