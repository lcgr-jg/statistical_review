"""Callbacks for the LNG — Arrivals History page.

One callback per chart so that chart-specific controls (e.g. the exports
chart's origin checklist) only redraw their own figure.  The shared controls
(sources, arrival window, display mode, history length) feed every callback
and therefore redraw all charts.  The heavy lifting — aggregating cached
snapshots — is shared: ``get_arrivals`` memoises aggregates and the
cached-dates listing, so concurrent callbacks only filter an in-memory frame.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone

import pandas as pd
from dash import Input, Output, callback, html
from dateutil.relativedelta import relativedelta

from core.arrivals_history.constants import (
    ASIA_CONTINENT,
    ASIA_DEST_GROUPS,
    DEFAULT_ASIA_DEST,
    DEFAULT_METRIC,
    DISPLAY_YOY,
    EUROPE_CONTINENT,
    MA_WINDOW_DAYS,
    METRIC_LABELS,
    METRIC_VOLUME,
    METRIC_Y_TITLE,
    ORIGIN_GROUP_US,
    WINDOW_LABELS,
    WINDOW_UNLIMITED,
)
from core.arrivals_history.data import daily_total, filter_agg, get_arrivals
from core.arrivals_history.render import (
    build_history_figure,
    build_yoy_figure,
    empty_figure,
)
from core.cargo_dod.constants import COVERAGE_DEFAULT_START, NWE_COUNTRIES
from core.cargo_dod.data import max_selectable_date
from core.styles import COLORS

logger = logging.getLogger(__name__)

_SHARED_INPUTS = [
    Input("ah-sources", "value"),
    Input("ah-window", "value"),
    Input("ah-display", "value"),
    Input("ah-months", "value"),
]


class _ChartContext:
    """Date range + aggregates + display settings shared by the charts."""

    def __init__(self, sources, window, display, months, metric=None):
        self.sources = sources or []
        self.window = int(window or WINDOW_UNLIMITED)
        self.yoy = display == DISPLAY_YOY
        self.months = int(months or 6)
        self.metric = metric if metric in METRIC_LABELS else DEFAULT_METRIC
        self.value_col = self.metric
        self.y_title = METRIC_Y_TITLE[self.metric]
        self.quantity = ("volume" if self.metric == METRIC_VOLUME
                         else "cargoes")

        self.end = max_selectable_date()
        if self.yoy:
            start = COVERAGE_DEFAULT_START
        else:
            # Extra lookback so the MA is fully formed at the window start
            start = (self.end - relativedelta(months=self.months)
                     - relativedelta(days=MA_WINDOW_DAYS))
        self.start = max(start, COVERAGE_DEFAULT_START)

        self.agg, self.available, self.missing = get_arrivals(
            self.start, self.end)

    def total(self, src=None, **filters) -> pd.Series:
        sources = src if src is not None else self.sources
        return daily_total(
            filter_agg(self.agg, self.window, sources, **filters),
            self.available, self.start, self.end,
            value_col=self.value_col)

    def trim(self, series: pd.Series) -> pd.Series:
        cutoff = str(self.end - relativedelta(months=self.months))
        return series[series.index >= cutoff]

    def volume_figure(self, series: pd.Series, label: str, title: str):
        if self.yoy:
            return build_yoy_figure(series, title, y_title=self.y_title)
        return build_history_figure(
            {label: self.trim(series)}, title, y_title=self.y_title)

    @property
    def suffix(self) -> str:
        if self.window == WINDOW_UNLIMITED:
            return ""
        return f", arriving within {WINDOW_LABELS[self.window]}"


def _context(sources, window, display, months, metric=None) -> _ChartContext | None:
    """Build the shared context; None means the cache read failed."""
    try:
        return _ChartContext(sources, window, display, months, metric)
    except Exception:
        logger.exception("Arrivals aggregation failed")
        return None


_FAIL_FIG = "Failed to read the snapshot cache — see server logs."
_EMPTY_FIG = "No cached snapshots in the requested range."


def _zone_label(countries: list[str]) -> str:
    if set(countries) == set(NWE_COUNTRIES):
        return "NWE"
    if len(countries) <= 3:
        return ", ".join(countries)
    return f"{len(countries)} countries"


@callback(
    Output("ah-months", "disabled"),
    Input("ah-display", "value"),
)
def toggle_months(display):
    return display == DISPLAY_YOY


@callback(
    Output("ah-chart", "figure"),
    Output("ah-status", "children"),
    Input("ah-countries", "value"),
    Input("ah-metric", "value"),
    *_SHARED_INPUTS,
)
def update_zone_chart(countries, metric, sources, window, display, months):
    if not countries or not sources:
        return (empty_figure("Select at least one country and one "
                             "ETA source."), "")
    ctx = _context(sources, window, display, months, metric)
    if ctx is None:
        return empty_figure(_FAIL_FIG), html.Span(
            "Cache read failed — see server logs.",
            style={"color": COLORS["error"]})
    status = _status_line(ctx)
    if not ctx.available:
        return empty_figure(_EMPTY_FIG), status

    series = ctx.total(countries=countries)
    title = (f"LNG {ctx.quantity} signalling {_zone_label(countries)} "
             f"({'+'.join(sources)}{ctx.suffix})")
    return ctx.volume_figure(series, "Zone", title), status


@callback(
    Output("ah-chart-eu", "figure"),
    Input("ah-eu-sources", "value"),
    Input("ah-metric", "value"),
    *_SHARED_INPUTS,
)
def update_europe_chart(eu_sources, metric, sources, window, display, months):
    if not eu_sources:
        return empty_figure("Select at least one ETA source for the "
                            "Europe chart.")
    ctx = _context(sources or [], window, display, months, metric)
    if ctx is None:
        return empty_figure(_FAIL_FIG)
    if not ctx.available:
        return empty_figure(_EMPTY_FIG)

    series = ctx.total(src=eu_sources, continent=EUROPE_CONTINENT,
                       country_unspecified=True)
    title = (f"LNG {ctx.quantity} signalling Europe with no country assigned "
             f"({'+'.join(eu_sources)}{ctx.suffix})")
    return ctx.volume_figure(series, "Europe (no country)", title)


@callback(
    Output("ah-chart-asia", "figure"),
    Input("ah-asia-dest", "value"),
    Input("ah-metric", "value"),
    *_SHARED_INPUTS,
)
def update_asia_chart(asia_dest, metric, sources, window, display, months):
    if not sources:
        return empty_figure("Select at least one ETA source.")
    ctx = _context(sources, window, display, months, metric)
    if ctx is None:
        return empty_figure(_FAIL_FIG)
    if not ctx.available:
        return empty_figure(_EMPTY_FIG)

    asia_dest = (asia_dest if asia_dest in ASIA_DEST_GROUPS
                 else DEFAULT_ASIA_DEST)
    dest_group = ASIA_DEST_GROUPS[asia_dest]
    series = ctx.total(countries=dest_group.get("countries"),
                       continent=dest_group.get("continent"))
    title = (f"LNG {ctx.quantity} signalling {asia_dest} — any origin "
             f"({'+'.join(sources)}{ctx.suffix})")
    return ctx.volume_figure(series, asia_dest, title)


@callback(
    Output("ah-chart-us", "figure"),
    Input("ah-origins", "value"),
    Input("ah-us-countries", "value"),
    *_SHARED_INPUTS,
)
def update_exports_chart(origins, us_countries, sources, window, display,
                         months):
    origins = origins or []
    us_countries = us_countries or []
    if not origins:
        return empty_figure("Tick at least one origin (US / WAF) for the "
                            "exports chart.")
    if not us_countries:
        return empty_figure("Select at least one European country for the "
                            "exports chart.")
    if not sources:
        return empty_figure("Select at least one ETA source.")
    ctx = _context(sources, window, display, months)
    if ctx is None:
        return empty_figure(_FAIL_FIG)
    if not ctx.available:
        return empty_figure(_EMPTY_FIG)

    origin_total = ctx.total(origin_groups=origins)
    to_europe = ctx.total(origin_groups=origins, countries=us_countries)
    to_asia = ctx.total(origin_groups=origins, continent=ASIA_CONTINENT)
    denom = origin_total.where(origin_total > 0)
    pct_europe = to_europe / denom * 100
    pct_asia = to_asia / denom * 100

    title = (f"{'+'.join(origins)}-origin cargoes: % signalling "
             f"{_zone_label(us_countries)} vs Asia "
             f"({'+'.join(sources)}{ctx.suffix})")

    if ctx.yoy:
        return build_yoy_figure(pct_europe, title + " — Europe share only",
                                y_title="%", y_fmt=".0f")
    return build_history_figure(
        {"% to Europe": ctx.trim(pct_europe),
         "% to Asia": ctx.trim(pct_asia)},
        title, y_title="%", y_fmt=".0f")


@callback(
    Output("ah-chart-us-nwe", "figure"),
    Input("ah-us-nwe-sources", "value"),
    Input("ah-metric", "value"),
    *_SHARED_INPUTS,
)
def update_us_nwe_chart(us_nwe_sources, metric, sources, window, display,
                        months):
    if not us_nwe_sources:
        return empty_figure("Select at least one ETA source for the "
                            "US NWE share chart.")
    ctx = _context(sources or [], window, display, months, metric)
    if ctx is None:
        return empty_figure(_FAIL_FIG)
    if not ctx.available:
        return empty_figure(_EMPTY_FIG)

    to_nwe = ctx.total(src=us_nwe_sources, origin_groups=[ORIGIN_GROUP_US],
                       countries=list(NWE_COUNTRIES))
    other = filter_agg(
        ctx.agg, ctx.window, us_nwe_sources,
        continent=EUROPE_CONTINENT, origin_groups=[ORIGIN_GROUP_US])
    other = other[other["country"].notna()
                  & ~other["country"].isin(NWE_COUNTRIES)]
    to_other = daily_total(other, ctx.available, ctx.start, ctx.end,
                           value_col=ctx.value_col)

    named_europe = to_nwe + to_other
    denom = named_europe.where(named_europe > 0)
    pct_nwe = to_nwe / denom * 100
    pct_other = to_other / denom * 100

    title = (f"US-origin cargoes: % signalling NWE vs other named Europe "
             f"({'+'.join(us_nwe_sources)}{ctx.suffix})")

    if ctx.yoy:
        return build_yoy_figure(pct_nwe, title + " — NWE share only",
                                y_title="%", y_fmt=".0f")
    return build_history_figure(
        {"% to NWE": ctx.trim(pct_nwe),
         "% to other Europe": ctx.trim(pct_other)},
        title, y_title="%", y_fmt=".0f")


def _status_line(ctx: _ChartContext) -> html.Span:
    available, missing = ctx.available, ctx.missing
    total = len(available) + len(missing)
    text = (f"Snapshot cache: {len(available)}/{total} days available for "
            f"{ctx.start:%d-%b-%Y} → {ctx.end:%d-%b-%Y}.")
    if missing:
        text += (f" {len(missing)} missing days shown as gaps "
                 "(not fetched from Kpler).")
        color = COLORS["warning"]
    else:
        color = COLORS["text_muted"]
    refreshed = datetime.now(timezone.utc).strftime("%H:%M UTC")
    return html.Span(f"{text} Updated {refreshed}.",
                     style={"color": color})
