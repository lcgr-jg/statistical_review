"""Data access for the Arrivals History page.

Builds and maintains a small derived-aggregates parquet: for every cached
snapshot date, the total forecast arrival volume (mcm) and cargo count per
(destination country, destination continent, ETA source, US-origin flag,
arrival window).  Snapshots are immutable so each date is aggregated once;
afterwards any filter combination is served instantly without re-reading
hundreds of snapshot files.

Strictly cache-only: uses ``KplerPITStore.read_trades_snapshot`` (local ->
S3 -> None) and never calls the Kpler API.  Dates missing from the store are
reported back to the caller as gaps.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from datetime import date

import pandas as pd

from core.arrivals_history.constants import (
    AGG_FILENAME,
    ARRIVAL_WINDOWS,
    ORIGIN_GROUP_OTHER,
    ORIGIN_GROUP_US,
    ORIGIN_GROUP_WAF,
    TRADE_STATUSES,
    US_ORIGIN_COUNTRY,
    WAF_ORIGIN_COUNTRIES,
    WINDOW_UNLIMITED,
)
from core.cargo_dod.constants import M3_LNG_TO_MCM, PIT_LOCAL_CACHE_DIR
from core.cargo_dod.data import get_store

logger = logging.getLogger(__name__)

# Raw (API-native) column names as stored in the snapshot parquets
_COL_STATUS = "Trade status"
_COL_SOURCE = "Eta source (destination)"
_COL_COUNTRY = "Country (destination)"
_COL_CONTINENT = "Continent Destination"
_COL_VOLUME = "Volume (destination m3)"
_COL_DEST_DATE = "Date (destination)"
_COL_ORIGIN_COUNTRY = "Country (origin)"

_AGG_COLUMNS = ["date", "country", "continent", "source", "origin_group",
                "window", "volume_mcm", "cargoes"]

_lock = threading.Lock()
_agg: pd.DataFrame | None = None       # loaded/derived aggregates
_agg_dates: set[date] = set()          # dates already aggregated this session

# Short-lived cache of the store's cached-dates listing: the per-chart
# callbacks run concurrently and would otherwise each pay an S3 LIST.
_CACHED_DATES_TTL_S = 60.0
_cached_dates: set[date] = set()
_cached_dates_ts: float | None = None


def _list_cached_dates() -> set[date]:
    global _cached_dates, _cached_dates_ts
    now = time.monotonic()
    if (_cached_dates_ts is not None
            and now - _cached_dates_ts < _CACHED_DATES_TTL_S):
        return set(_cached_dates)
    try:
        _cached_dates = set(get_store().list_cached_dates())
        _cached_dates_ts = now
    except Exception as ex:
        logger.warning("Cached-dates listing failed (%s); using local "
                       "aggregates only", ex)
    return set(_cached_dates)


def _agg_path() -> str:
    return os.path.join(PIT_LOCAL_CACHE_DIR, AGG_FILENAME)


def _empty_agg() -> pd.DataFrame:
    return pd.DataFrame(columns=_AGG_COLUMNS)


def _load_agg() -> pd.DataFrame:
    """In-memory aggregates, loading the persisted parquet on first use."""
    global _agg
    if _agg is None:
        path = _agg_path()
        if os.path.exists(path):
            try:
                _agg = pd.read_parquet(path)[_AGG_COLUMNS]
            except Exception as ex:
                logger.warning("Corrupt/outdated arrivals aggregates %s "
                               "(%s); rebuilding", path, ex)
                _agg = _empty_agg()
        else:
            _agg = _empty_agg()
        _agg_dates.update(pd.to_datetime(_agg["date"]).dt.date)
    return _agg


def _aggregate_snapshot(raw: pd.DataFrame,
                        snapshot_date: date) -> pd.DataFrame:
    """Arrivals totals for one raw snapshot, per (country, continent,
    source, US-origin flag, arrival window).

    Mirrors eu_models/lng_stats.calculate_lng_arrivals: statuses In
    Transit/Loading, volume = Volume (destination m3) -> mcm, no minimum
    cargo size.  Window filters keep cargoes with a destination date up to
    N+1 days after the snapshot (lng_stats' inclusive window); window 0 is
    unlimited.  Cargoes with no destination country still carry their
    destination continent, so "Europe (unspecified)" flows are queryable.
    """
    needed = [_COL_STATUS, _COL_SOURCE, _COL_COUNTRY, _COL_VOLUME]
    if any(col not in raw.columns for col in needed):
        logger.warning("Snapshot %s missing arrivals columns; skipping",
                       snapshot_date)
        return _empty_agg()

    on_water = raw[raw[_COL_STATUS].isin(TRADE_STATUSES)].copy()
    on_water["_continent"] = (
        raw[_COL_CONTINENT] if _COL_CONTINENT in raw.columns else pd.NA)
    if _COL_ORIGIN_COUNTRY in raw.columns:
        origin = on_water[_COL_ORIGIN_COUNTRY]
        on_water["_origin_group"] = ORIGIN_GROUP_OTHER
        on_water.loc[origin.eq(US_ORIGIN_COUNTRY),
                     "_origin_group"] = ORIGIN_GROUP_US
        on_water.loc[origin.isin(WAF_ORIGIN_COUNTRIES),
                     "_origin_group"] = ORIGIN_GROUP_WAF
    else:
        on_water["_origin_group"] = ORIGIN_GROUP_OTHER
    dest_date = (pd.to_datetime(on_water[_COL_DEST_DATE], errors="coerce")
                 if _COL_DEST_DATE in on_water.columns else None)

    frames = []
    for window in ARRIVAL_WINDOWS:
        if window == WINDOW_UNLIMITED or dest_date is None:
            subset = on_water
        else:
            cutoff = pd.Timestamp(snapshot_date) + pd.Timedelta(
                days=window + 1)
            subset = on_water[dest_date <= cutoff]
        grouped = (
            subset.groupby([_COL_COUNTRY, "_continent", _COL_SOURCE,
                            "_origin_group"], dropna=False)
            .agg(volume_m3=(_COL_VOLUME, "sum"),
                 cargoes=(_COL_VOLUME, "size"))
            .reset_index()
            .rename(columns={_COL_COUNTRY: "country",
                             "_continent": "continent",
                             _COL_SOURCE: "source",
                             "_origin_group": "origin_group"})
        )
        grouped["window"] = window
        frames.append(grouped)

    out = pd.concat(frames, ignore_index=True)
    out = out[out["source"].notna()]
    out["volume_mcm"] = out["volume_m3"] * M3_LNG_TO_MCM
    out["date"] = pd.Timestamp(snapshot_date)
    return out[_AGG_COLUMNS]


def get_arrivals(start: date, end: date) -> tuple[pd.DataFrame, list[date],
                                                  list[date]]:
    """Aggregates for [start, end], built from cached snapshots only.

    Returns ``(agg, available, missing)``:
        * agg       -- long frame (see _AGG_COLUMNS)
        * available -- dates in range with a cached snapshot
        * missing   -- dates in range with no cached snapshot (never fetched)
    """
    global _agg
    want = [d.date() for d in pd.date_range(start, end, freq="D")]

    store = get_store()
    cached = _list_cached_dates()

    with _lock:
        agg = _load_agg()
        cached |= _agg_dates  # aggregated implies it was cached at some point
        to_build = [d for d in want if d in cached and d not in _agg_dates]

        new_frames = []
        for snapshot_date in to_build:
            try:
                raw = store.read_trades_snapshot(snapshot_date)
            except Exception as ex:
                logger.warning("Cache read failed for %s: %s",
                               snapshot_date, ex)
                cached.discard(snapshot_date)
                continue
            if raw is None:
                cached.discard(snapshot_date)
                continue
            new_frames.append(_aggregate_snapshot(raw, snapshot_date))
            _agg_dates.add(snapshot_date)

        if new_frames:
            agg = pd.concat([agg] + new_frames, ignore_index=True)
            agg = agg.sort_values(["date", "country", "source", "window"],
                                  ignore_index=True)
            _agg = agg
            try:
                os.makedirs(PIT_LOCAL_CACHE_DIR, exist_ok=True)
                agg.to_parquet(_agg_path(), engine="pyarrow",
                               compression="snappy")
            except Exception as ex:
                logger.warning("Failed to persist arrivals aggregates: %s", ex)

        available = [d for d in want if d in cached and d in _agg_dates]
        missing = [d for d in want if d not in cached]

        dates = pd.to_datetime(agg["date"]).dt.date
        in_range = agg[(dates >= start) & (dates <= end)].copy()

    return in_range, available, missing


def filter_agg(agg: pd.DataFrame,
               window: int,
               sources: list[str],
               countries: list[str] | None = None,
               continent: str | None = None,
               country_unspecified: bool = False,
               origin_groups: list[str] | None = None) -> pd.DataFrame:
    """Slice the aggregates frame on the chart filters."""
    f = agg[(agg["window"] == window) & agg["source"].isin(sources)]
    if origin_groups is not None:
        f = f[f["origin_group"].isin(origin_groups)]
    if continent is not None:
        f = f[f["continent"] == continent]
    if country_unspecified:
        f = f[f["country"].isna()]
    if countries is not None:
        f = f[f["country"].isin(countries)]
    return f


def daily_total(frame: pd.DataFrame,
                available: list[date],
                start: date,
                end: date,
                value_col: str = "volume_mcm") -> pd.Series:
    """Daily total of *value_col* (volume mcm or cargo count), indexed on
    [start, end].

    Cached dates with no matching cargoes are 0; uncached dates are NaN so
    they render as gaps.
    """
    daily = frame.groupby("date")[value_col].sum()
    daily.index = pd.to_datetime(daily.index)

    series = daily.reindex(pd.to_datetime(sorted(available))).fillna(0.0)
    return series.reindex(pd.date_range(start, end, freq="D"))
