"""LNG — Arrivals History page package.

Recreates the eu_reports/lng_vessels arrivals-history chart (per-snapshot
total volume of cargoes signalling into the zone, Port+AIS by default) from
the permanently cached Kpler point-in-time snapshots.  Strictly cache-only:
missing snapshot dates are shown as gaps and never trigger Kpler API calls.
"""
