"""LNG — Arrivals History page constants."""
from __future__ import annotations

from core.cargo_dod.constants import NWE_COUNTRIES

PAGE_PATH = "/power/lng/arrivals_history"
PAGE_NAME = "Arrivals Analysis"
PAGE_TITLE = "LNG Arrivals Analysis | JG Power Dashboard"
PAGE_ORDER = 82

# Destination-country options (alphabetical): the NWE zone (the default
# selection) plus the other European LNG importers we track.  Names are
# Kpler ``Country (destination)`` labels.
DEFAULT_COUNTRIES = list(NWE_COUNTRIES)
COUNTRY_OPTIONS = sorted(set(NWE_COUNTRIES) | {
    "Spain",
    "Portugal",
    "Poland",
    "Greece",
    "Croatia",
    "Finland",
    "Lithuania",
    "Turkey",
})

# Kpler destination-ETA source (forecast confidence) options.  The report's
# ``port_ais`` series = Port + AIS; ``kpler`` = Analyst + Market + Model.
SOURCE_OPTIONS = ["Port", "AIS", "Analyst", "Market", "Model"]
DEFAULT_SOURCES = ["Port", "AIS"]

# Cargoes counted towards the arrivals signal (mirrors eu_models/lng_stats:
# everything on the water or loading, all delivery dates, volume =
# Volume (destination m3), no minimum-size filter).
TRADE_STATUSES = ["In Transit", "Loading"]

# Arrival windows: only count cargoes forecast to arrive within N days of
# the snapshot (inclusive, mirroring eu_models/lng_stats' offset windows).
# 0 = unlimited (everything on the water, the original chart logic).
WINDOW_UNLIMITED = 0
ARRIVAL_WINDOWS = [7, 14, 21, WINDOW_UNLIMITED]
DEFAULT_WINDOW = WINDOW_UNLIMITED
WINDOW_LABELS = {7: "7 days", 14: "14 days", 21: "21 days",
                 WINDOW_UNLIMITED: "Unlimited"}

# Origin groups (exports % chart).  Kpler ``Country (origin)`` labels.
US_ORIGIN_COUNTRY = "United States"
WAF_ORIGIN_COUNTRIES = [
    "Nigeria",
    "Angola",
    "Equatorial Guinea",
    "Cameroon",
    "Republic of the Congo",
    "Mauritania",
    "Senegal",
]
ORIGIN_GROUP_US = "US"
ORIGIN_GROUP_WAF = "WAF"
ORIGIN_GROUP_OTHER = "Other"
ORIGIN_GROUP_LABELS = {
    ORIGIN_GROUP_US: "US",
    ORIGIN_GROUP_WAF: "WAF (West Africa)",
}
DEFAULT_ORIGIN_GROUPS = [ORIGIN_GROUP_US]

EUROPE_CONTINENT = "Europe"
ASIA_CONTINENT = "Asia"

# Asia destinations chart: single-select destination groups (any origin).
ASIA_DEST_GROUPS: dict[str, dict] = {
    "Asia (continent)": {"continent": ASIA_CONTINENT},
    "China": {"countries": ["China"]},
    "India": {"countries": ["India"]},
    "JKTC (Japan, Korea, Taiwan, China)": {
        "countries": ["Japan", "South Korea", "Taiwan", "China"]},
}
DEFAULT_ASIA_DEST = "China"

# Y-axis for the volume charts (zone / Europe-unspecified / Asia).
METRIC_VOLUME = "volume_mcm"
METRIC_CARGOES = "cargoes"
METRIC_LABELS = {
    METRIC_VOLUME: "Volume (mcm)",
    METRIC_CARGOES: "Cargo count",
}
DEFAULT_METRIC = METRIC_VOLUME
METRIC_Y_TITLE = {
    METRIC_VOLUME: "mcm",
    METRIC_CARGOES: "cargoes",
}

# Display parameters
DISPLAY_HISTORY = "history"
DISPLAY_YOY = "yoy"
HISTORY_MONTHS_OPTIONS = [3, 6, 12, 24]
DEFAULT_HISTORY_MONTHS = 6
MA_WINDOW_DAYS = 14

# Derived per-date aggregates parquet (lives alongside the local snapshot
# cache; cheap to rebuild from the snapshot store at any time).  v2: added
# destination continent, US-origin flag and arrival-window dimensions.
# v3: US-origin flag replaced by origin_group (US / WAF / Other).
# v4: added the 21-day arrival window bucket.
AGG_FILENAME = "arrivals_agg_v4.parquet"
