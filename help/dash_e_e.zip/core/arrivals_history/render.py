"""Figure builders for the Arrivals History page."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go

from core.arrivals_history.constants import MA_WINDOW_DAYS
from core.styles import CHART_COLORS, COLORS

# Report palette (#1A5276) for single-series charts; standard chart colors
# for multi-series ones.
_SINGLE_COLOR = "#1A5276"

_BASE_LAYOUT = dict(
    height=560,
    margin={"l": 60, "r": 30, "t": 70, "b": 90},
    paper_bgcolor=COLORS["chart_paper"],
    plot_bgcolor=COLORS["chart_bg"],
    font={"family": "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, "
                    "sans-serif", "size": 12},
    # Below the plot: with many series (e.g. six YoY years) a top legend
    # grows into the title.
    legend={"orientation": "h", "yanchor": "top", "y": -0.12,
            "xanchor": "center", "x": 0.5},
    hovermode="x unified",
)

_AXIS = {"gridcolor": "#eee", "zerolinecolor": "#ddd"}


def _rolling_ma(series: pd.Series) -> pd.Series:
    """14d MA over the available (non-gap) days.

    min_periods=1 so a sparsely backfilled cache still charts; early points
    average over fewer days.
    """
    return series.rolling(window=MA_WINDOW_DAYS, min_periods=1).mean()


def _faded(hex_color: str, alpha: float = 0.35) -> str:
    hex_color = hex_color.lstrip("#")
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r}, {g}, {b}, {alpha})"


def empty_figure(message: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        **_BASE_LAYOUT,
        xaxis={"visible": False},
        yaxis={"visible": False},
        annotations=[{
            "text": message, "showarrow": False,
            "font": {"size": 14, "color": COLORS["text_muted"]},
        }],
    )
    return fig


def build_history_figure(series_map: dict[str, pd.Series],
                         title: str,
                         y_title: str = "mcm",
                         y_fmt: str = ",.0f") -> go.Figure:
    """Raw daily line(s) + 14d MA over the selected history window.

    Mirrors eu_reports/lng_vessels ``create_arrivals_chart``: thin raw
    series, bold moving average.  With multiple series each gets its own
    colour; the subtitle shows the latest value and day-on-day change per
    series.
    """
    single = len(series_map) == 1

    subtitles = []
    fig = go.Figure()
    for i, (label, series) in enumerate(series_map.items()):
        color = _SINGLE_COLOR if single else CHART_COLORS[i % len(CHART_COLORS)]
        ma = _rolling_ma(series)

        valid = series.dropna()
        if len(valid) >= 2:
            latest, previous = valid.iloc[-1], valid.iloc[-2]
            dod = latest - previous
            prefix = "" if single else f"{label} "
            subtitles.append(f"{prefix}latest: {latest:{y_fmt}}{y_title} "
                             f"(DoD {dod:+{y_fmt}})")

        raw_name = "Daily" if single else f"{label} daily"
        ma_name = (f"{MA_WINDOW_DAYS}d MA" if single
                   else f"{label} {MA_WINDOW_DAYS}d MA")
        fig.add_trace(go.Scatter(
            x=series.index, y=series.values, mode="lines", name=raw_name,
            line={"color": _faded(color), "width": 1}, connectgaps=False,
            hovertemplate="%{y:" + y_fmt + "} " + y_title
                          + "<extra>" + raw_name + "</extra>"))
        fig.add_trace(go.Scatter(
            x=ma.index, y=ma.values, mode="lines", name=ma_name,
            line={"color": color, "width": 2.5}, connectgaps=False,
            hovertemplate="%{y:" + y_fmt + "} " + y_title
                          + "<extra>" + ma_name + "</extra>"))

    subtitle = " | ".join(subtitles)
    fig.update_layout(
        **_BASE_LAYOUT,
        title={"text": title
                       + (f"<br><sub>{subtitle}</sub>" if subtitle else ""),
               "x": 0.5, "xanchor": "center",
               "font": {"size": 15, "color": COLORS["text_dark"]}},
        xaxis={**_AXIS, "tickformat": "%d %b-%y"},
        yaxis={**_AXIS, "title": y_title, "rangemode": "tozero"},
    )
    return fig


def build_yoy_figure(series: pd.Series,
                     title: str,
                     y_title: str = "mcm",
                     y_fmt: str = ",.0f") -> go.Figure:
    """Year-on-year (Jan-Dec) overlay of the 14d MA, one line per year.

    The current (latest) year is emphasised and also shows its raw daily
    series faintly.  Data are mapped onto a common leap year (2000) so
    Feb-29 aligns.
    """
    valid = series.dropna()
    if valid.empty:
        return empty_figure("No cached data for the current selection.")

    ma = _rolling_ma(series)
    years = sorted({ts.year for ts in valid.index})
    latest_year = years[-1]

    fig = go.Figure()
    for i, year in enumerate(years):
        year_ma = ma[ma.index.year == year].dropna()
        if year_ma.empty:
            continue
        common_x = [ts.replace(year=2000) for ts in year_ma.index]
        is_latest = year == latest_year
        color = CHART_COLORS[i % len(CHART_COLORS)]
        fig.add_trace(go.Scatter(
            x=common_x, y=year_ma.values, mode="lines", name=str(year),
            line={"color": color, "width": 3 if is_latest else 1.5},
            opacity=1.0 if is_latest else 0.75,
            hovertemplate="%{y:" + y_fmt + "} " + y_title
                          + "<extra>" + str(year) + "</extra>"))
        if is_latest:
            year_raw = series[series.index.year == year].dropna()
            fig.add_trace(go.Scatter(
                x=[ts.replace(year=2000) for ts in year_raw.index],
                y=year_raw.values, mode="lines",
                name=f"{year} daily", showlegend=False,
                line={"color": color, "width": 1}, opacity=0.3,
                hovertemplate="%{y:" + y_fmt + "} " + y_title
                              + "<extra>" + f"{year} daily</extra>"))

    fig.update_layout(
        **_BASE_LAYOUT,
        title={"text": f"{title} — year-on-year"
                       f"<br><sub>{MA_WINDOW_DAYS}d moving average</sub>",
               "x": 0.5, "xanchor": "center",
               "font": {"size": 15, "color": COLORS["text_dark"]}},
        xaxis={**_AXIS, "tickformat": "%b", "dtick": "M1",
               "range": ["2000-01-01", "2000-12-31"]},
        yaxis={**_AXIS, "title": y_title, "rangemode": "tozero"},
    )
    return fig
