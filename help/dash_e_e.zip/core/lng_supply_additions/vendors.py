"""Live S&P Platts adapter.

A missing login or warehouse leaves an empty frame and a status message.
The dated Goldman and Energy Aspects snapshots still render.
Platts is tried through the ``spgci`` SDK first and then through Snowflake.
"""
from __future__ import annotations

import logging
import re
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from datetime import date
from typing import Any

import pandas as pd

from core.lng_supply_additions.constants import (
    HORIZON_YEAR,
    PLATTS_TIMEOUT_SECONDS,
    SOURCE_PLATTS,
)
from core.lng_supply_additions.schema import (
    empty_frame,
    finalize,
    parse_when,
)

logger = logging.getLogger(__name__)

_ALIASES: dict[str, tuple[str, ...]] = {
    "country": (
        "country", "country_name", "countryname", "supply_market",
        "liquefaction_country", "asset_country", "plant_country",
    ),
    "project": (
        "liquefaction_project", "project_name", "project", "asset_name",
        "plant_name", "name",
    ),
    "train": (
        "train_name", "liquefaction_train", "train", "train_number",
    ),
    "operator": (
        "operator", "operator_name", "owners", "owner", "equity_owners",
    ),
    "n_trains": (
        "number_of_trains", "n_trains", "train_count", "no_of_trains",
    ),
    "mtpa": (
        "capacity_mtpa", "nominal_capacity_mtpa", "nameplate_capacity_mtpa",
        "capacity_mt", "mtpa", "nominal_capacity", "nameplate_capacity",
        "capacity",
    ),
    "bcm": ("capacity_bcma", "capacity_bcm", "bcm_y", "bcma"),
    "start": (
        "estimated_start_date", "startup_date", "start_date",
        "expected_startup_date", "expected_startup",
        "commercial_operation_date", "online_date",
        "in_service_date", "assumed_start_date",
    ),
    "first_cargo": (
        "estimated_first_cargo_date", "first_cargo_date", "first_lng_date",
    ),
    "fid": (
        "latest_announced_final_investment_decision_date",
        "fid_date", "final_investment_decision_date", "fid_year",
    ),
    "status": ("train_status", "project_status", "status"),
}

_START_NEEDLES = (
    "startup", "startdate", "firstlng", "onlinedate", "commercialoperation",
    "inservicedate", "expectedstart",
)
_FUTURE_STATUS = (
    "construct", "plan", "propos", "develop", "feed", "fid", "approved", "sanction",
)
_OPERATING_STATUS = (
    "exist", "operat", "decommiss", "cancel", "abandon", "mothbal",
)


def _public_error(exc: Exception) -> str:
    text = str(exc).split("?", 1)[0]
    text = re.sub(r"(?i)(api_key|password|pwd|secret)=([^\s&]+)", r"\1=***", text)
    return f"{type(exc).__name__}: {text[:160]}"


def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def _pick(columns: list[str], aliases: tuple[str, ...], used: set[str]) -> str | None:
    lookup = {_norm(col): col for col in columns if col not in used}
    for alias in aliases:
        col = lookup.get(_norm(alias))
        if col:
            return col
    return None


def _pick_contains(columns: list[str], needles: tuple[str, ...], used: set[str]) -> str | None:
    for col in columns:
        if col in used:
            continue
        norm = _norm(col)
        if any(needle in norm for needle in needles):
            return col
    return None


def _map_columns(columns: list[str]) -> dict[str, str]:
    used: set[str] = set()
    found: dict[str, str] = {}
    for field, aliases in _ALIASES.items():
        col = _pick(columns, aliases, used)
        if col:
            found[field] = col
            used.add(col)
    if "start" not in found:
        col = _pick_contains(columns, _START_NEEDLES, used)
        if col:
            found["start"] = col
            used.add(col)
    if "mtpa" not in found:
        col = _pick_contains(columns, ("mtpa", "capacitymt"), used)
        if col:
            found["mtpa"] = col
    return found


def _cell(row: pd.Series, column: str | None) -> Any:
    if not column or column not in row.index:
        return None
    value = row[column]
    if isinstance(value, str):
        return value.strip()
    return value


def _join_project(project: Any, train: Any) -> str:
    project_text = "" if project is None or (isinstance(project, float) and pd.isna(project)) else str(project).strip()
    train_text = "" if train is None or (isinstance(train, float) and pd.isna(train)) else str(train).strip()
    if project_text.lower() == "nan":
        project_text = ""
    if train_text.lower() == "nan":
        train_text = ""
    if not train_text or train_text.lower() in project_text.lower():
        return project_text
    if project_text and train_text.lower().startswith(project_text.lower()):
        return train_text
    return f"{project_text} {train_text}".strip()


def _keep_train(start: pd.Timestamp | None, status: str) -> bool:
    text = (status or "").lower()
    if any(token in text for token in ("decommiss", "cancel", "abandon")):
        return False
    future = any(token in text for token in _FUTURE_STATUS)
    operating = any(token in text for token in _OPERATING_STATUS)
    if start is not None and start.year >= HORIZON_YEAR:
        return True
    if start is not None:
        return False
    return bool(future and not operating)


def trains_to_additions(
    raw: pd.DataFrame,
    *,
    backend: str,
    as_of: str | None = None,
) -> tuple[pd.DataFrame, dict]:
    """Map a Platts trains or projects table onto the canonical frame."""
    info: dict[str, Any] = {
        "backend": backend,
        "n_in": 0 if raw is None else int(len(raw)),
        "n_out": 0,
        "warning": "",
        "columns": [] if raw is None else [str(c) for c in list(raw.columns)[:24]],
    }
    if raw is None or raw.empty:
        return empty_frame(), info

    columns = _map_columns([str(c) for c in raw.columns])
    if "start" not in columns:
        shown = ", ".join(info["columns"])
        info["warning"] = (
            "Startup date column was not recognised"
            + (f" (columns: {shown})" if shown else "")
        )

    as_of = as_of or date.today().isoformat()
    rows = []
    for _, row in raw.iterrows():
        start, precision = parse_when(_cell(row, columns.get("start")))
        # First cargo is when the train actually starts. Estimated start is
        # often a later commercial date and stays in the future after the
        # train has already shipped.
        cargo, cargo_precision = parse_when(_cell(row, columns.get("first_cargo")))
        if cargo is not None:
            start, precision = cargo, cargo_precision
        status = _cell(row, columns.get("status"))
        status_text = "" if status is None or (isinstance(status, float) and pd.isna(status)) else str(status)
        if not _keep_train(start, status_text):
            continue
        fid_raw = _cell(row, columns.get("fid"))
        fid_note = ""
        if isinstance(fid_raw, str) and fid_raw.strip().endswith("*"):
            fid_note = "*"
        fid_ts, fid_precision = parse_when(fid_raw)
        fid_year = None if fid_ts is None else int(fid_ts.year)
        if fid_precision == "year":
            fid_year = int(fid_ts.year) if fid_ts is not None else None
        n_trains = _cell(row, columns.get("n_trains"))
        train = _cell(row, columns.get("train"))
        if n_trains is None or (isinstance(n_trains, float) and pd.isna(n_trains)):
            n_trains = 1 if train else None
        rows.append({
            "source": SOURCE_PLATTS,
            "source_kind": "live",
            "as_of": as_of,
            "country": _cell(row, columns.get("country")),
            "project": _join_project(_cell(row, columns.get("project")), train),
            "operator": _cell(row, columns.get("operator")),
            "n_trains": n_trains,
            "mtpa": _cell(row, columns.get("mtpa")),
            "bcm_y": _cell(row, columns.get("bcm")),
            "start_date": start,
            "start_precision": precision,
            "fid_year": fid_year,
            "fid_note": fid_note,
            "status": status_text,
            "note": "",
        })
    frame = finalize(rows)
    info["n_out"] = int(len(frame))
    return frame, info


def _platts_via_api() -> pd.DataFrame:
    import inspect

    import spgci as ci

    lng = ci.LNGGlobalAnalytics()
    fn = getattr(lng, "get_assets_contracts_liquefaction_trains", None)
    if fn is None:
        fn = getattr(lng, "get_liquefaction_projects", None)
    if fn is None:
        raise RuntimeError("spgci has no liquefaction trains or projects method")
    sig = inspect.signature(fn)
    kwargs: dict[str, Any] = {}
    if "paginate" in sig.parameters:
        kwargs["paginate"] = True
    if "train_status" in sig.parameters:
        kwargs["train_status"] = [
            "Under Construction", "Planned", "Proposed", "FID",
            "Pre-FID", "In Development",
        ]
    try:
        frame = fn(**kwargs)
    except Exception:
        if "train_status" not in kwargs:
            raise
        kwargs.pop("train_status")
        frame = fn(**kwargs)
    if not isinstance(frame, pd.DataFrame):
        raise RuntimeError("Platts API did not return a table")
    return frame


_PLATTS_TRAINS_SQL = """
SELECT DISTINCT
    t.LIQUEFACTION_PROJECT AS PROJECT,
    t.LIQUEFACTION_TRAIN AS TRAIN,
    t.TRAIN_STATUS AS STATUS,
    t.ESTIMATED_START_DATE AS STARTUP_DATE,
    t.ESTIMATED_FIRST_CARGO_DATE AS ESTIMATED_FIRST_CARGO_DATE,
    t.LATEST_ANNOUNCED_FINAL_INVESTMENT_DECISION_DATE AS FID_DATE,
    t.NUMBER_OF_TRAINS AS NUMBER_OF_TRAINS,
    p.SUPPLY_MARKET AS COUNTRY
FROM LIQUEFACTION_TRAINS t
LEFT JOIN LIQUEFACTION_PROJECTS p
    ON t.LIQUEFACTION_PROJECT_ID = p.LIQUEFACTION_PROJECT_ID
WHERE t.ESTIMATED_START_DATE >= '2024-01-01'
   OR t.TRAIN_STATUS ILIKE '%construct%'
   OR t.TRAIN_STATUS ILIKE '%commission%'
   OR t.TRAIN_STATUS ILIKE '%fid%'
   OR t.TRAIN_STATUS ILIKE '%propos%'
"""


def _platts_via_snowflake() -> pd.DataFrame:
    """Distinct trains, with supply market and nameplate mtpa.

    Startup is ``ESTIMATED_FIRST_CARGO_DATE`` when Platts has one, otherwise
    ``ESTIMATED_START_DATE``. Capacity is million tonnes per
    year (``mmtpa``) on the monthly buildout table, one figure per train.
    """
    from jain_commods.core.interfaces.snowflake import PlattsQuery

    pq = PlattsQuery(querytype="analytics", warehouse="EU_COMMOD_RESEARCH_M_WH")
    trains = pq._execute_query(_PLATTS_TRAINS_SQL)
    if trains is None or trains.empty or "PROJECT" not in trains.columns:
        return trains
    projects = sorted({str(name) for name in trains["PROJECT"].dropna().unique()})
    if not projects:
        return trains
    quoted = ",".join("'" + name.replace("'", "''") + "'" for name in projects)
    try:
        capacity = pq._execute_query(
            f"""
            SELECT LIQUEFACTION_PROJECT AS PROJECT,
                   LIQUEFACTION_TRAIN AS TRAIN,
                   MAX(INITIAL_CAPACITY) AS CAPACITY_MTPA
            FROM LIQUEFACTION_CAPACITY_MONTHLY_ESTIMATED_BUILDOUT
            WHERE INITIAL_CAPACITY_UOM = 'mmtpa'
              AND LIQUEFACTION_PROJECT IN ({quoted})
            GROUP BY 1, 2
            """
        )
    except Exception as exc:
        logger.info("Platts capacity pull skipped: %s", type(exc).__name__)
        return trains
    if capacity is None or capacity.empty:
        return trains
    return trains.merge(capacity, on=["PROJECT", "TRAIN"], how="left")


def fetch_platts() -> tuple[pd.DataFrame, dict]:
    """S&P API first, Snowflake liquefaction trains if the API is unavailable."""
    errors: list[str] = []
    frame: pd.DataFrame | None = None
    backend = ""
    try:
        frame = _platts_via_api()
        backend = "S&P API"
    except Exception as exc:
        errors.append(f"API {_public_error(exc)}")
        logger.info("Platts API liquefaction pull failed: %s", type(exc).__name__)
    if frame is None or frame.empty:
        try:
            frame = _platts_via_snowflake()
            backend = "Snowflake"
        except Exception as exc:
            errors.append(f"Snowflake {_public_error(exc)}")
            logger.info("Platts Snowflake liquefaction pull failed: %s", type(exc).__name__)
            frame = None
    if frame is None or frame.empty:
        detail = "; ".join(errors) or "no rows"
        return empty_frame(), _live_status(
            SOURCE_PLATTS, "error",
            "Platts API and Snowflake were both unavailable "
            f"({detail}). Install spgci with SPGCI_USERNAME/SPGCI_PASSWORD, "
            "or sign the analytics PlattsQuery login in.",
        )
    mapped, info = trains_to_additions(frame, backend=backend)
    message = f"{info['n_out']} trains via {backend} (from {info['n_in']} rows)."
    if info.get("warning"):
        message = f"{message} {info['warning']}"
    state = "ok" if info["n_out"] else "empty"
    if not info["n_out"]:
        message = (
            f"{backend} returned {info['n_in']} rows and none are upcoming "
            f"additions (startup from {HORIZON_YEAR}, or still planned). {info.get('warning', '')}"
        ).strip()
    return mapped, _live_status(SOURCE_PLATTS, state, message, n=info["n_out"])


def _live_status(label: str, state: str, message: str, n: int = 0, as_of: str = "") -> dict:
    return {
        "label": label,
        "state": state,
        "kind": "live",
        "as_of": as_of or date.today().isoformat(),
        "n": int(n),
        "message": message,
    }


def fetch_live_sources() -> list[tuple[pd.DataFrame, dict]]:
    """Query Platts. Energy Aspects is a dated snapshot, not a live pull.

    ``shutdown(wait=False)`` so a stuck Snowflake login cannot hold the page
    after the timeout. The worker thread is left to finish on its own.
    """
    pool = ThreadPoolExecutor(max_workers=1)
    platts = pool.submit(fetch_platts)
    results = []
    for future, label, seconds in (
        (platts, SOURCE_PLATTS, PLATTS_TIMEOUT_SECONDS),
    ):
        try:
            results.append(future.result(timeout=seconds))
        except FuturesTimeoutError:
            results.append((
                empty_frame(),
                _live_status(label, "error", f"{label} timed out after {seconds}s."),
            ))
        except Exception as exc:
            results.append((
                empty_frame(),
                _live_status(label, "error", f"{label} failed ({_public_error(exc)})."),
            ))
    pool.shutdown(wait=False, cancel_futures=True)
    return results
