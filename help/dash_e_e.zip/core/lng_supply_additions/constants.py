"""LNG — Supply Additions page constants."""
from __future__ import annotations

from datetime import date
from typing import Final

PAGE_PATH: Final[str] = "/power/lng/supply-additions"
PAGE_NAME: Final[str] = "Supply Additions"
PAGE_TITLE: Final[str] = "LNG Supply Additions | JG Power Dashboard"
PAGE_ORDER: Final[int] = 79

SOURCE_GS: Final[str] = "Goldman Sachs"
SOURCE_EA: Final[str] = "Energy Aspects"
EA_FILE_URL: Final[str] = (
    "https://my.energyaspects.com/explorer/catalogue/explore/package/blt818cf2f1eb6f45b6"
)
EA_FILE_LABEL: Final[str] = "LNG liquefaction projects"
SOURCE_PLATTS: Final[str] = "S&P Platts"
SOURCE_ORDER: Final[tuple[str, ...]] = (SOURCE_GS, SOURCE_EA, SOURCE_PLATTS)

# Trains already operating before this year are dropped from live pulls.
# The year control can still look back to the start of the window we keep.
HORIZON_YEAR: Final[int] = 2024
YEAR_MIN: Final[int] = 2024
YEAR_MAX: Final[int] = 2045
_THIS_YEAR = date.today().year
DEFAULT_YEAR_FROM: Final[int] = min(max(_THIS_YEAR, YEAR_MIN), YEAR_MAX)
DEFAULT_YEAR_TO: Final[int] = min(max(_THIS_YEAR + 3, YEAR_MIN), YEAR_MAX)

# GS prints roughly 1.36–1.38 bcm per mtpa (8.0 mtpa → 11.0 bcm).
# Used only when a vendor publishes a single unit.
MTPA_TO_BCM: Final[float] = 1.38

LIVE_TTL_SECONDS: Final[int] = 30 * 60
EA_META_LIMIT: Final[int] = 30
EA_SERIES_LIMIT: Final[int] = 12
PLATTS_TIMEOUT_SECONDS: Final[int] = 50
EA_TIMEOUT_SECONDS: Final[int] = 45

SOURCE_COLORS: Final[dict[str, str]] = {
    SOURCE_GS: "#16324f",
    SOURCE_EA: "#c47b2b",
    SOURCE_PLATTS: "#2f6f4e",
}

COUNTRY_COLORS: Final[dict[str, str]] = {
    "US": "#4E738A",
    "Qatar": "#8B1E3F",
    "Australia": "#C4A35A",
    "Canada": "#D4764E",
    "Nigeria": "#2E7D4F",
    "Mexico": "#6B4C9A",
    "Argentina": "#3D7EA6",
    "Malaysia": "#C47B4A",
    "Oman": "#7A8B3A",
    "UAE": "#B85C38",
    "Mozambique": "#3E6B5A",
    "Gabon": "#5C6B7A",
    "Norway": "#5B7C99",
    "Russia": "#8C4A4A",
    "Indonesia": "#3F6F8C",
}

# Lower-case keys, dots already removed. Two-letter keys are ISO codes.
COUNTRY_ALIASES: Final[dict[str, str]] = {
    "us": "US",
    "usa": "US",
    "united states": "US",
    "united states of america": "US",
    "qa": "Qatar",
    "au": "Australia",
    "ca": "Canada",
    "mx": "Mexico",
    "ng": "Nigeria",
    "ar": "Argentina",
    "my": "Malaysia",
    "om": "Oman",
    "ae": "UAE",
    "uae": "UAE",
    "united arab emirates": "UAE",
    "mz": "Mozambique",
    "ga": "Gabon",
    "gb": "United Kingdom",
    "uk": "United Kingdom",
    "united kingdom": "United Kingdom",
    "no": "Norway",
    "ru": "Russia",
    "id": "Indonesia",
    "pg": "Papua New Guinea",
    "tt": "Trinidad and Tobago",
    "pe": "Peru",
    "eg": "Egypt",
    "dz": "Algeria",
    "ao": "Angola",
    "cm": "Cameroon",
    "sn": "Senegal",
    "mr": "Mauritania",
    "br": "Brazil",
    "cn": "China",
    "in": "India",
}
