"""Plotly figures for LNG supply additions."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go

import core.theme  # noqa: F401  — registers the dashboard template
from core.lng_supply_additions.constants import (
    COUNTRY_COLORS,
    SOURCE_COLORS,
    SOURCE_EA,
    SOURCE_GS,
    SOURCE_PLATTS,
)
from core.lng_supply_additions.schema import format_start, source_sort
from core.styles import CHART_COLORS, COLORS
from core.theme import PLOTLY_TEMPLATE_NAME

_TIMELINE_CAP = 40
_SOURCE_SYMBOLS = {
    SOURCE_GS: "circle",
    SOURCE_EA: "square",
    SOURCE_PLATTS: "triangle-up",
}
_SYMBOL_CYCLE = ("circle", "square", "triangle-up", "star", "hexagon", "cross")


def _blank(title: str, message: str, height: int = 320) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        template=PLOTLY_TEMPLATE_NAME,
        height=height,
        margin=dict(l=24, r=16, t=28, b=24),
        annotations=[dict(
            text=message,
            showarrow=False,
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            font=dict(size=13, color=COLORS["text_muted"]),
        )],
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
    )
    fig.update_layout(title=dict(text=title, font=dict(size=14)))
    return fig


def _style(fig: go.Figure, height: int, unified: bool = True) -> go.Figure:
    fig.update_layout(
        template=PLOTLY_TEMPLATE_NAME,
        height=height,
        margin=dict(l=52, r=16, t=36, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0, xanchor="left", title=None),
        hovermode="x unified" if unified else "closest",
        bargap=0.28,
    )
    return fig


def _bottom_legend(fig: go.Figure, n_items: int) -> go.Figure:
    """Legend under the x-axis, one row of items stretched across the plot."""
    count = max(int(n_items), 1)
    per_row = min(count, 6)
    rows = (count + per_row - 1) // per_row
    fig.update_layout(
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.22,
            xanchor="left",
            x=0,
            entrywidthmode="fraction",
            entrywidth=1 / per_row,
            itemsizing="constant",
            title=None,
            font=dict(size=12),
        ),
        margin=dict(l=56, r=16, t=28, b=12 + 26 * rows),
    )
    fig.update_xaxes(automargin=True)
    return fig


def _country_color(country: str, index: int) -> str:
    return COUNTRY_COLORS.get(country) or CHART_COLORS[index % len(CHART_COLORS)]


def _source_color(source: str, index: int) -> str:
    return SOURCE_COLORS.get(source) or CHART_COLORS[index % len(CHART_COLORS)]


def _add_today(fig: go.Figure, *, year_axis: bool, bar: bool = False) -> go.Figure:
    today = pd.Timestamp.today().normalize()
    if year_axis:
        frac = (today.dayofyear - 1) / 365.25
        if bar:
            # Bars are centered on the year and almost touch the next year.
            # A raw fraction in October lands inside the following year's group.
            half = (1 - 0.28) / 2
            x = today.year + (frac - 0.5) * (2 * half)
        else:
            x = today.year + frac
        fig.add_vline(
            x=x,
            line_dash="dash",
            line_width=1,
            line_color="#6c757d",
            annotation_text="Today",
            annotation_position="top right",
            annotation_font=dict(size=11, color="#6c757d"),
        )
        return fig
    # A date axis cannot go through add_vline's annotation maths on this Plotly build.
    x = today.strftime("%Y-%m-%d")
    fig.add_shape(
        type="line",
        x0=x,
        x1=x,
        y0=0,
        y1=1,
        yref="paper",
        line=dict(dash="dash", width=1, color="#6c757d"),
    )
    fig.add_annotation(
        x=x,
        y=1,
        yref="paper",
        text="Today",
        showarrow=False,
        yanchor="bottom",
        font=dict(size=11, color="#6c757d"),
    )
    return fig


def _fid_bits(year: Any, note: str = "") -> str:
    if year is None or pd.isna(year):
        return ""
    mark = note if isinstance(note, str) else ""
    return f"GS FID {int(year)}{mark}"


def _after_fid(start: pd.Timestamp, year: Any) -> str:
    if year is None or pd.isna(year):
        return ""
    months = (start.year - int(year)) * 12 + (start.month - 1)
    if months < 0:
        return ""
    years, rem = divmod(months, 12)
    if years and rem:
        return f"<br>{years}y {rem}m after GS FID"
    if years:
        return f"<br>{years}y after GS FID"
    return f"<br>{rem}m after GS FID"


def _dated(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty or "start_date" not in df.columns:
        return df.iloc[0:0] if df is not None else pd.DataFrame()
    out = df.dropna(subset=["start_date"]).copy()
    if out.empty:
        return out
    out["year"] = out["start_date"].dt.year.astype(int)
    return out


def _drop_past_this_year(dated: pd.DataFrame) -> pd.DataFrame:
    """Current-year bars only include startups after today."""
    if dated.empty:
        return dated
    today = pd.Timestamp.today().normalize()
    return dated[(dated["year"] != today.year) | (dated["start_date"] > today)]


def fig_by_country(df: pd.DataFrame) -> go.Figure:
    """Stacked annual Mtpa for a single source, coloured by country."""
    dated = _drop_past_this_year(_dated(df))
    if dated.empty:
        return _blank("By country", "No dated additions for this source in the filter.")
    totals = dated.groupby("country")["mtpa"].sum().sort_values(ascending=False)
    fig = go.Figure()
    for index, country in enumerate(totals.index):
        part = dated[dated["country"] == country]
        annual = part.groupby("year")["mtpa"].sum().sort_index()
        names = []
        for year in annual.index:
            rows = part[part["year"] == year].sort_values("mtpa", ascending=False)
            lines = []
            for row in rows.itertuples():
                if pd.isna(row.mtpa):
                    continue
                lines.append(f"{row.project} ({row.mtpa:.1f})")
            lines = lines[:12]
            if len(rows) > 12:
                lines.append(f"… {len(rows) - 12} more")
            names.append("<br>".join(lines))
        fig.add_bar(
            x=annual.index.astype(int),
            y=annual.values,
            name=str(country),
            marker_color=_country_color(str(country), index),
            customdata=names,
            hovertemplate="%{x}<br>%{fullData.name}: %{y:.1f} mtpa<br>%{customdata}<extra></extra>",
        )
    fig.update_layout(barmode="stack")
    fig.update_yaxes(title="Mtpa")
    fig.update_xaxes(dtick=1, title="")
    fig = _bottom_legend(_add_today(_style(fig, 460), year_axis=True, bar=True), len(totals))
    return fig


def _annual_mtpa(part: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    if part is None or part.empty:
        empty = pd.Series(dtype=float)
        return empty, empty
    annual = part.groupby("year")["mtpa"].sum().sort_index()
    counts = part.groupby("year").size()
    return annual, counts


def _add_vendor_bar(
    fig: go.Figure,
    *,
    name: str,
    annual: pd.Series,
    counts: pd.Series,
    color: str,
    offsetgroup: str,
    base: pd.Series | None = None,
    hatch: bool = False,
) -> None:
    marker: dict = {"color": color}
    if hatch:
        marker["pattern"] = {
            "shape": "/",
            "solidity": 0.45,
            "fgcolor": "#143326",
            "size": 8,
        }
    kwargs = dict(
        x=annual.index.astype(int),
        y=annual.values,
        name=name,
        marker=marker,
        offsetgroup=offsetgroup,
        customdata=counts.reindex(annual.index).fillna(0).astype(int),
        hovertemplate="%{x}<br>%{fullData.name}: %{y:.1f} mtpa<br>%{customdata} projects<extra></extra>",
    )
    if base is not None:
        kwargs["base"] = base.reindex(annual.index).fillna(0).to_numpy()
    fig.add_bar(**kwargs)


def fig_by_source(df: pd.DataFrame) -> go.Figure:
    """Grouped annual Mtpa, one colour per vendor.

    The current calendar year only includes startups after today. Earlier
    months in that year have already come online. Unmapped Platts trains,
    when the filter includes them, sit on top of the mapped Platts bar.
    """
    dated = _drop_past_this_year(_dated(df))
    if dated.empty:
        return _blank("By vendor", "No dated additions in this filter.")
    fig = go.Figure()
    legend_items = 0
    for index, source in enumerate(source_sort(dated["source"].unique())):
        part = dated[dated["source"] == source]
        unmapped = part.iloc[0:0]
        if source == SOURCE_PLATTS and "on_goldman" in part.columns:
            flag = part["on_goldman"].fillna(False).astype(bool)
            unmapped = part[~flag]
            part = part[flag]
        color = _source_color(str(source), index)
        annual, counts = _annual_mtpa(part)
        if not annual.empty:
            _add_vendor_bar(
                fig,
                name=str(source),
                annual=annual,
                counts=counts,
                color=color,
                offsetgroup=str(source),
            )
            legend_items += 1
        extra, extra_counts = _annual_mtpa(unmapped)
        if not extra.empty:
            _add_vendor_bar(
                fig,
                name=f"{SOURCE_PLATTS} (unmapped)",
                annual=extra,
                counts=extra_counts,
                color=color,
                offsetgroup=str(source),
                base=annual,
                hatch=True,
            )
            legend_items += 1
    fig.update_layout(barmode="group")
    fig.update_yaxes(title="Mtpa")
    fig.update_xaxes(dtick=1, title="")
    fig = _bottom_legend(
        _add_today(_style(fig, 440), year_axis=True, bar=True),
        legend_items,
    )
    return fig


def fig_cumulative(df: pd.DataFrame) -> go.Figure:
    """Cumulative nameplate by startup month, one line per vendor.

    Months between the first and last startup are filled so a country filter
    shows when capacity actually steps up, rather than one point per year.
    """
    dated = _dated(df)
    if dated.empty:
        return _blank("Cumulative", "No dated additions in this filter.")
    dated = dated.copy()
    dated["month"] = dated["start_date"].dt.to_period("M").dt.to_timestamp()
    first = dated["month"].min()
    # A first startup still ahead of this month leaves a gap back to the
    # today line. Fill that gap at zero so each series steps up off the axis.
    today_month = pd.Timestamp.today().to_period("M").to_timestamp()
    start = today_month if first > today_month else first
    months = pd.date_range(start, dated["month"].max(), freq="MS")
    fig = go.Figure()
    for index, source in enumerate(source_sort(dated["source"].unique())):
        monthly = (
            dated[dated["source"] == source]
            .groupby("month")["mtpa"].sum()
            .reindex(months, fill_value=0)
            .cumsum()
        )
        fig.add_scatter(
            x=months,
            y=monthly.values,
            name=str(source),
            mode="lines+markers" if len(months) == 1 else "lines",
            line=dict(color=_source_color(str(source), index), width=2, shape="hv"),
            marker=dict(size=7),
            hovertemplate=(
                "%{x|%b %Y}<br>%{fullData.name}: %{y:.1f} mtpa cumulative<extra></extra>"
            ),
        )
    span = len(months)
    if span <= 18:
        dtick = "M1"
    elif span <= 48:
        dtick = "M3"
    else:
        dtick = "M6"
    fig.update_yaxes(title="Cumulative mtpa", rangemode="tozero")
    fig.update_xaxes(title="", dtick=dtick, tickformat="%b %Y", hoverformat="%b %Y")
    sources = source_sort(dated["source"].unique())
    fig = _bottom_legend(_add_today(_style(fig, 420), year_axis=False), len(sources))
    return fig


def _source_symbol(source: str, index: int) -> str:
    return _SOURCE_SYMBOLS.get(source) or _SYMBOL_CYCLE[index % len(_SYMBOL_CYCLE)]


def _timeline_keys(dated: pd.DataFrame) -> pd.Series:
    """Match the same project across vendors, and keep unmatched names apart."""
    fallback = dated["country"].astype(str) + "\n" + dated["project"].astype(str)
    if "match_key" not in dated.columns:
        return fallback
    keys = dated["match_key"].map(lambda value: "" if pd.isna(value) else str(value).strip())
    return keys.where(~keys.isin({"", "nan", "None"}), fallback)


def _preferred_label(group: pd.DataFrame) -> str:
    pick = group.iloc[0]
    if "source" in group.columns:
        for source in source_sort(group["source"].dropna().unique()):
            part = group[group["source"] == source]
            if not part.empty:
                pick = part.iloc[0]
                break
    return f"{pick['country']}  ·  {pick['project']}"


def _overlay_hover(row) -> str:
    start = pd.Timestamp(row.start_date)
    size = "—" if pd.isna(row.mtpa) else f"{float(row.mtpa):.1f} mtpa"
    operator = getattr(row, "operator", "")
    operator = operator if isinstance(operator, str) and operator and operator != "nan" else "—"
    start_label = getattr(row, "start_label", "") or ""
    if not isinstance(start_label, str) or not start_label or start_label == "nan":
        start_label = start.strftime("%Y-%m-%d")
    source = getattr(row, "source", "") or ""
    hover = f"{source}<br>{row.project}<br>{operator}<br>{size} · startup {start_label}"
    gs_year = getattr(row, "gs_fid_year", None)
    fid_dt = getattr(row, "fid_date", None)
    fid_note = getattr(row, "fid_note", "") if source == SOURCE_GS else ""
    fid_text = _fid_bits(gs_year, fid_note if isinstance(fid_note, str) else "")
    if fid_text:
        hover += f"<br>{fid_text}" + _after_fid(start, gs_year)
    elif fid_dt is not None and pd.notna(fid_dt):
        stamp = pd.Timestamp(fid_dt)
        shown = format_start(stamp, "month" if stamp.day == 1 else "day")
        hover += f"<br>FID {shown}" + _after_fid(start, stamp.year)
    return hover


def _fig_timeline_overlay(
    dated: pd.DataFrame,
    sources: list[str],
    *,
    show_fid: bool,
) -> go.Figure:
    """One row per project, with each selected source in its own colour and shape."""
    if dated.empty or not sources:
        return _blank("Timeline", "No dated additions for these sources in the filter.", height=360)
    dated = dated.copy()
    dated["row_key"] = _timeline_keys(dated)
    earliest = (
        dated.groupby("row_key")["start_date"].min().sort_values().head(_TIMELINE_CAP)
    )
    dated = dated[dated["row_key"].isin(set(earliest.index))]
    labels: dict[str, str] = {}
    used: dict[str, int] = {}
    order: list[str] = []
    for key in earliest.index:
        base = _preferred_label(dated[dated["row_key"] == key])
        used[base] = used.get(base, 0) + 1
        label = base if used[base] == 1 else f"{base} ({used[base]})"
        labels[str(key)] = label
        order.append(label)

    fig = go.Figure()
    fid_x: list[pd.Timestamp] = []
    fid_y: list[str] = []
    fid_hover: list[str] = []
    for index, source in enumerate(sources):
        part = dated[dated["source"] == source]
        if part.empty:
            continue
        xs: list[pd.Timestamp] = []
        ys: list[str] = []
        hovers: list[str] = []
        for row in part.itertuples():
            label = labels[str(row.row_key)]
            start = pd.Timestamp(row.start_date)
            xs.append(start)
            ys.append(label)
            hovers.append(_overlay_hover(row))
            if not show_fid:
                continue
            gs_year = getattr(row, "gs_fid_year", None)
            fid_dt = getattr(row, "fid_date", None)
            fid_note = getattr(row, "fid_note", "") if source == SOURCE_GS else ""
            fid_text = _fid_bits(gs_year, fid_note if isinstance(fid_note, str) else "")
            if gs_year is not None and pd.notna(gs_year):
                fid_x.append(pd.Timestamp(year=int(gs_year), month=1, day=1))
                fid_y.append(label)
                fid_hover.append(f"{source}<br>{row.project}<br>{fid_text} · reference")
            elif fid_dt is not None and pd.notna(fid_dt):
                stamp = pd.Timestamp(fid_dt)
                shown = format_start(stamp, "month" if stamp.day == 1 else "day")
                fid_x.append(stamp)
                fid_y.append(label)
                fid_hover.append(f"{source}<br>{row.project}<br>FID {shown}")
        fig.add_scatter(
            x=xs,
            y=ys,
            mode="markers",
            marker=dict(
                size=12,
                color=_source_color(str(source), index),
                symbol=_source_symbol(str(source), index),
            ),
            name=str(source),
            legendgroup=str(source),
            hovertemplate="%{customdata}<extra></extra>",
            customdata=hovers,
        )
    if fid_x:
        fig.add_scatter(
            x=fid_x,
            y=fid_y,
            mode="markers",
            marker=dict(size=9, color="#5c6b7a", symbol="diamond"),
            name="FID",
            hovertemplate="%{customdata}<extra></extra>",
            customdata=fid_hover,
        )
    fig.update_yaxes(
        categoryorder="array",
        categoryarray=list(reversed(order)),
        automargin=True,
    )
    fig.update_xaxes(title="")
    height = min(760, 120 + 22 * len(order))
    fig = _add_today(_style(fig, height, unified=False), year_axis=False)
    fig.update_layout(
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.18,
            x=0,
            xanchor="left",
            font=dict(size=12),
            title=None,
        ),
        margin=dict(l=8, r=24, t=36, b=64),
    )
    return fig


def fig_timeline(df: pd.DataFrame, *, show_fid: bool = True, overlay: bool = False) -> go.Figure:
    """Startup circles, with a Goldman FID diamond on the same row.

    The diamond is 1 January of the Goldman FID year. There is no line
    between FID and startup. ``gs_fid_year`` is the reference date for
    every source. With more than one source, each project is one row and
    each source keeps its own colour and shape.
    """
    if df is None or df.empty:
        return _blank("Timeline", "No additions for this source in the filter.", height=360)
    dated = df.dropna(subset=["start_date"]).sort_values("start_date")
    if dated.empty:
        return _blank("Timeline", "These rows have no startup date.", height=360)
    if overlay:
        sources = source_sort(dated["source"].dropna().unique()) if "source" in dated.columns else []
        return _fig_timeline_overlay(dated, sources, show_fid=show_fid)
    dated = dated.head(_TIMELINE_CAP)
    countries = list(dict.fromkeys(dated["country"].tolist()))
    fig = go.Figure()
    labels: list[str] = []
    fid_x: list[pd.Timestamp] = []
    fid_y: list[str] = []
    fid_hover: list[str] = []
    for index, country in enumerate(countries):
        part = dated[dated["country"] == country]
        color = _country_color(str(country), index)
        xs: list[pd.Timestamp] = []
        ys: list[str] = []
        hovers: list[str] = []
        for row_i, row in enumerate(part.itertuples()):
            label = f"{row.country}  ·  {row.project}"
            if label in labels or label in ys:
                label = f"{label} ({row_i + 1})"
            labels.append(label)
            start = pd.Timestamp(row.start_date)
            size = "—" if pd.isna(row.mtpa) else f"{float(row.mtpa):.1f} mtpa"
            operator = row.operator if isinstance(row.operator, str) and row.operator else "—"
            gs_year = getattr(row, "gs_fid_year", None)
            fid_dt = getattr(row, "fid_date", None)
            fid_text = _fid_bits(gs_year, getattr(row, "fid_note", "") if row.source == "Goldman Sachs" else "")
            hover = f"{row.project}<br>{operator}<br>{size} · startup {row.start_label}"
            if fid_text:
                hover += f"<br>{fid_text}" + _after_fid(start, gs_year)
            elif fid_dt is not None and pd.notna(fid_dt):
                stamp = pd.Timestamp(fid_dt)
                shown = format_start(stamp, "month" if stamp.day == 1 else "day")
                hover += f"<br>FID {shown}" + _after_fid(start, stamp.year)
            xs.append(start)
            ys.append(label)
            hovers.append(hover)
            if show_fid and gs_year is not None and pd.notna(gs_year):
                fid_x.append(pd.Timestamp(year=int(gs_year), month=1, day=1))
                fid_y.append(label)
                fid_hover.append(f"{row.project}<br>{fid_text} · reference")
            elif show_fid and fid_dt is not None and pd.notna(fid_dt):
                stamp = pd.Timestamp(fid_dt)
                shown = format_start(stamp, "month" if stamp.day == 1 else "day")
                fid_x.append(stamp)
                fid_y.append(label)
                fid_hover.append(f"{row.project}<br>FID {shown}")
        fig.add_scatter(
            x=xs,
            y=ys,
            mode="markers",
            marker=dict(size=12, color=color, symbol="circle"),
            name=str(country),
            legendgroup=str(country),
            hovertemplate="%{customdata}<extra></extra>",
            customdata=hovers,
        )
    if fid_x:
        fig.add_scatter(
            x=fid_x,
            y=fid_y,
            mode="markers",
            marker=dict(size=9, color="#16324f", symbol="diamond"),
            name="GS FID" if any("reference" in text for text in fid_hover) else "FID",
            hovertemplate="%{customdata}<extra></extra>",
            customdata=fid_hover,
        )
    # categoryarray is bottom-to-top; reverse so the soonest startup is on top.
    fig.update_yaxes(
        categoryorder="array",
        categoryarray=list(reversed(labels)),
        automargin=True,
    )
    fig.update_xaxes(title="")
    fig = _add_today(_style(fig, min(760, 100 + 22 * len(labels)), unified=False), year_axis=False)
    fig.update_layout(showlegend=False, margin=dict(l=8, r=24, t=36, b=40))
    return fig
