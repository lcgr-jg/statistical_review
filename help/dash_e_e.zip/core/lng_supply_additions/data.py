"""Load dated snapshots and, on refresh, the Platts pull.

Snapshots are the source of truth for Goldman and Energy Aspects. Drop a
CSV in ``snapshots/`` and list it in ``manifest.json``. Columns: country,
project, operator, n_trains, mtpa, bcm_y, start, and either fid_year plus
fid_note or a fid_date. Optional status and note. ``start`` is YYYY-MM,
YYYY-MM-DD, or ``Mon YYYY``.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from datetime import date
from pathlib import Path

import pandas as pd

from core.lng_supply_additions.constants import LIVE_TTL_SECONDS, SOURCE_GS, SOURCE_PLATTS
from core.lng_supply_additions.schema import (
    align_vendors,
    empty_frame,
    finalize,
    frame_to_records,
    parse_when,
)
from core.lng_supply_additions.vendors import fetch_live_sources

logger = logging.getLogger(__name__)

SNAP_DIR = Path(__file__).resolve().parent / "snapshots"

_LOCK = threading.Lock()
_CACHE: dict = {"at": 0.0, "payload": None}


def _status(label: str, *, state: str, kind: str, as_of: str = "", n: int = 0, message: str = "") -> dict:
    return {
        "label": label,
        "state": state,
        "kind": kind,
        "as_of": as_of,
        "n": int(n),
        "message": message,
    }


def _snapshot_frame(raw: pd.DataFrame, source: str, as_of: str) -> pd.DataFrame:
    rows = []
    for rec in raw.to_dict(orient="records"):
        start, precision = parse_when(rec.get("start"))
        note = rec.get("fid_note")
        fid_date, _fid_prec = parse_when(rec.get("fid_date"))
        fid_year = rec.get("fid_year")
        if fid_date is not None:
            fid_year = int(fid_date.year)
        status = rec.get("status")
        detail = rec.get("note")
        rows.append({
            "source": source,
            "source_kind": "snapshot",
            "as_of": as_of,
            "country": rec.get("country"),
            "project": rec.get("project"),
            "operator": rec.get("operator"),
            "n_trains": rec.get("n_trains"),
            "mtpa": rec.get("mtpa"),
            "bcm_y": rec.get("bcm_y"),
            "start_date": start,
            "start_precision": precision,
            "fid_year": fid_year,
            "fid_note": "" if note is None or (isinstance(note, float) and pd.isna(note)) else note,
            "fid_date": fid_date,
            "gs_fid_year": fid_year if source == SOURCE_GS else None,
            "status": "" if status is None or (isinstance(status, float) and pd.isna(status)) else status,
            "note": "" if detail is None or (isinstance(detail, float) and pd.isna(detail)) else detail,
            "on_goldman": True,
        })
    return finalize(rows)


def load_snapshots() -> tuple[pd.DataFrame, list[dict]]:
    manifest_path = SNAP_DIR / "manifest.json"
    if not manifest_path.is_file():
        return empty_frame(), [
            _status("Snapshots", state="error", kind="snapshot", message="manifest.json is missing."),
        ]
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return empty_frame(), [
            _status("Snapshots", state="error", kind="snapshot", message=f"manifest.json could not be read ({exc})."),
        ]

    frames: list[pd.DataFrame] = []
    statuses: list[dict] = []
    for entry in manifest:
        source = str(entry.get("source") or "Snapshot")
        as_of = str(entry.get("as_of") or "")
        filename = str(entry.get("file") or "")
        path = SNAP_DIR / filename
        if not filename or not path.is_file():
            statuses.append(_status(
                source, state="error", kind="snapshot", as_of=as_of,
                message=f"Snapshot file {filename or '(blank)'} was not found.",
            ))
            continue
        try:
            frame = _snapshot_frame(pd.read_csv(path), source=source, as_of=as_of)
        except Exception as exc:
            logger.warning("Snapshot %s failed: %s", filename, exc)
            statuses.append(_status(
                source, state="error", kind="snapshot", as_of=as_of,
                message=f"Could not read {filename} ({type(exc).__name__}).",
            ))
            continue
        frames.append(frame)
        statuses.append(_status(
            source, state="ok" if len(frame) else "empty", kind="snapshot",
            as_of=as_of, n=len(frame), message=str(entry.get("note") or ""),
        ))
    combined = pd.concat(frames, ignore_index=True) if frames else empty_frame()
    return combined, statuses


def _payload(frame: pd.DataFrame, statuses: list[dict], *, live: bool) -> dict:
    return {
        "rows": frame_to_records(frame),
        "sources": statuses,
        "loaded_at": date.today().isoformat(),
        "live": live,
    }


def snapshot_payload() -> dict:
    """Dated snapshots plus a pending badge while Platts is queried."""
    frame, statuses = load_snapshots()
    frame, _note = align_vendors(frame)
    statuses = list(statuses) + [
        _status(SOURCE_PLATTS, state="pending", kind="live", message="Querying S&P Platts…"),
    ]
    return _payload(frame, statuses, live=False)


def _build_full() -> dict:
    frame, statuses = load_snapshots()
    try:
        live = fetch_live_sources()
    except Exception as exc:
        logger.warning("Live supply-addition pulls failed: %s", type(exc).__name__)
        live = []
        statuses.append(_status(
            "Live sources", state="error", kind="live",
            message=f"Live queries failed ({type(exc).__name__}).",
        ))
    frames = [frame] if frame is not None else []
    for live_frame, live_status in live:
        if live_frame is not None and not live_frame.empty:
            frames.append(live_frame)
        statuses.append(live_status)
    combined = pd.concat(frames, ignore_index=True) if frames else empty_frame()
    combined, link_note = align_vendors(combined)
    if link_note:
        for item in statuses:
            if item.get("label") == SOURCE_PLATTS and item.get("state") in {"ok", "empty"}:
                item["message"] = f"{item.get('message', '')} {link_note}".strip()
                if not combined.empty and "on_goldman" in combined.columns:
                    matched = combined["source"].eq(SOURCE_PLATTS) & combined["on_goldman"].astype(bool)
                    item["n"] = int(matched.sum())
    return _payload(combined, statuses, live=True)


def full_payload(*, force: bool = False) -> dict:
    """Snapshots plus Platts. Cached for half an hour."""
    with _LOCK:
        now = time.monotonic()
        cached = _CACHE["payload"]
        if not force and cached is not None and now - _CACHE["at"] < LIVE_TTL_SECONDS:
            return cached
        payload = _build_full()
        _CACHE["at"] = time.monotonic()
        _CACHE["payload"] = payload
        return payload
