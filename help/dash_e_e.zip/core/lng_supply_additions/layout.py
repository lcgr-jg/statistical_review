"""Layout for the LNG — Supply Additions page."""
from __future__ import annotations

from dash import dash_table, dcc, html
from dash.dash_table.Format import Format, Scheme

from core.lng_supply_additions.constants import (
    DEFAULT_YEAR_FROM,
    DEFAULT_YEAR_TO,
    SOURCE_EA,
    SOURCE_ORDER,
    YEAR_MAX,
    YEAR_MIN,
)
from core.styles import BUTTON_SECONDARY_STYLE, COLORS, DATA_TABLE_STYLE_CELL, DATA_TABLE_STYLE_HEADER

_YEARS = [{"label": str(year), "value": year} for year in range(YEAR_MIN, YEAR_MAX + 1)]
_SOURCE_OPTIONS = [{"label": s, "value": s} for s in sorted(SOURCE_ORDER)]

_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "padding": "16px 18px 12px 18px",
    "marginBottom": "16px",
}

_LABEL = {
    "fontSize": "11px",
    "fontWeight": "600",
    "letterSpacing": "0.4px",
    "textTransform": "uppercase",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}

_CHART_SUBTITLE = {
    "fontSize": "12px",
    "fontWeight": "500",
    "color": COLORS["text_secondary"],
    "textTransform": "none",
    "letterSpacing": "0",
    "lineHeight": "1.4",
    "margin": "2px 0 8px 0",
}

_GRAPH = {"displayModeBar": "hover", "displaylogo": False, "responsive": True}

TIMELINE_NOTE = (
    "Circles are the startup. Diamonds are the FID: 1 January of the Goldman "
    "year, or the Energy Aspects date from the 2 Oct 2026 file. The dashed line is today."
)
TIMELINE_NOTE_OVERLAY = (
    "Each source has its own colour and shape. Diamonds are the FID: 1 January of the Goldman "
    "year, or the Energy Aspects date from the 2 Oct 2026 file. The dashed line is today."
)

FMT_1 = Format(precision=1, scheme=Scheme.fixed)
FMT_0 = Format(precision=0, scheme=Scheme.fixed)

TABLE_COLUMNS = [
    {"name": "Source", "id": "source"},
    {"name": "As of", "id": "as_of"},
    {"name": "Country", "id": "country"},
    {"name": "Project", "id": "project"},
    {"name": "Operator", "id": "operator"},
    {"name": "Trains", "id": "trains_display"},
    {"name": "Mtpa", "id": "mtpa", "type": "numeric", "format": FMT_1},
    {"name": "Bcm/y", "id": "bcm_y", "type": "numeric", "format": FMT_1},
    {"name": "Start", "id": "start_label"},
    {"name": "GS FID", "id": "gs_fid_display"},
    {"name": "Source FID", "id": "fid_display"},
    {"name": "Status", "id": "status"},
    {"name": "Note", "id": "note"},
]

_NUM_COLS = ["trains_display", "mtpa", "bcm_y"]

_HEADER = {
    **DATA_TABLE_STYLE_HEADER,
    "backgroundColor": "#16324f",
    "color": "#ffffff",
    "textAlign": "left",
    "border": "1px solid #16324f",
    "whiteSpace": "normal",
    "height": "auto",
}

_CELL = {
    **DATA_TABLE_STYLE_CELL,
    "textAlign": "left",
    "fontSize": "13px",
    "padding": "7px 10px",
    "minWidth": "64px",
    "maxWidth": "240px",
    "whiteSpace": "normal",
    "height": "auto",
    "border": f"1px solid {COLORS['border_light']}",
}


def _field(label: str, control) -> html.Div:
    return html.Div(
        [html.Label(label, style=_LABEL), control],
        style={"minWidth": "140px"},
    )


def _table(table_id: str, columns: list[dict]) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=table_id,
        columns=columns,
        data=[],
        sort_action="native",
        filter_action="native",
        page_action="native",
        page_size=20,
        style_table={"overflowX": "auto"},
        style_header=_HEADER,
        style_cell=_CELL,
        style_data={"backgroundColor": COLORS["card_bg"], "color": COLORS["text_primary"]},
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": "#f4f7f8"},
        ],
        style_cell_conditional=[
            {"if": {"column_id": col}, "textAlign": "right"} for col in _NUM_COLS
        ],
        style_header_conditional=[
            {"if": {"column_id": col}, "textAlign": "right"} for col in _NUM_COLS
        ],
    )


def build_layout() -> html.Div:
    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1680px"},
        children=[
            dcc.Store(id="lsa-store"),
            dcc.Store(id="lsa-view"),
            dcc.Interval(id="lsa-live-once", interval=800, max_intervals=1),
            html.Div([
                html.Div([
                    html.H1("Supply Additions", style={
                        "fontSize": "22px", "fontWeight": "600",
                        "color": COLORS["text_primary"], "margin": "0 0 4px 0",
                    }),
                    html.P(
                        "When new liquefaction capacity is due online, across "
                        "Goldman Sachs, Energy Aspects and S&P Platts.",
                        style={
                            "margin": "0", "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                        },
                    ),
                ]),
                html.Button(
                    "Refresh live sources",
                    id="lsa-refresh",
                    n_clicks=0,
                    title="Re-query S&P Platts",
                    style={**BUTTON_SECONDARY_STYLE, "height": "36px"},
                ),
            ], style={
                "display": "flex", "justifyContent": "space-between",
                "alignItems": "flex-end", "gap": "16px", "marginBottom": "14px",
            }),
            html.Div(id="lsa-status", style={
                "display": "flex", "flexWrap": "wrap", "gap": "8px", "marginBottom": "12px",
            }),
            html.Div(style=_PANEL, children=[
                html.Div(style={
                    "display": "flex", "flexWrap": "wrap", "gap": "16px", "alignItems": "flex-end",
                }, children=[
                    _field("Sources", dcc.Checklist(
                        id="lsa-sources",
                        options=[{"label": s, "value": s} for s in SOURCE_ORDER],
                        value=list(SOURCE_ORDER),
                        inline=True,
                        inputStyle={"marginRight": "6px"},
                        labelStyle={
                            "marginRight": "16px", "fontSize": "13px", "cursor": "pointer",
                        },
                    )),
                    _field("Country", dcc.Dropdown(
                        id="lsa-country",
                        options=[],
                        value=[],
                        multi=True,
                        placeholder="All countries",
                        style={"minWidth": "240px"},
                    )),
                    _field("Start from", dcc.Dropdown(
                        id="lsa-year-from",
                        options=_YEARS,
                        value=DEFAULT_YEAR_FROM,
                        clearable=False,
                        style={"width": "110px"},
                    )),
                    _field("Start to", dcc.Dropdown(
                        id="lsa-year-to",
                        options=_YEARS,
                        value=DEFAULT_YEAR_TO,
                        clearable=False,
                        style={"width": "110px"},
                    )),
                    html.Div(
                        [
                            dcc.Checklist(
                                id="lsa-undated",
                                options=[{"label": " Include undated", "value": "yes"}],
                                value=[],
                                style={"fontSize": "13px", "marginBottom": "4px"},
                            ),
                            dcc.Checklist(
                                id="lsa-other-platts",
                                options=[{"label": " Show unmapped Platts trains", "value": "yes"}],
                                value=[],
                                style={"fontSize": "13px", "marginBottom": "8px"},
                            ),
                        ],
                        style={"alignSelf": "flex-end"},
                    ),
                ]),
            ]),
            dcc.Loading(type="circle", children=[
                html.Div(id="lsa-scope-note", style={
                    "fontSize": "12px", "color": COLORS["text_secondary"],
                    "margin": "0 0 14px 0", "lineHeight": "1.45",
                }),
                html.Div(style={
                    "display": "grid",
                    "gridTemplateColumns": "1fr 1fr",
                    "gap": "12px",
                }, children=[
                    html.Div(style=_PANEL, children=[
                        html.Div(
                            style={
                                "display": "flex",
                                "justifyContent": "space-between",
                                "alignItems": "flex-end",
                                "gap": "12px",
                            },
                            children=[
                                html.Div("Additions by country", style={**_LABEL, "marginBottom": "6px"}),
                                html.Div([
                                    html.Label("Source", style=_LABEL),
                                    dcc.Dropdown(
                                        id="lsa-country-source",
                                        options=_SOURCE_OPTIONS,
                                        value=SOURCE_EA,
                                        clearable=False,
                                        style={"width": "180px"},
                                    ),
                                ]),
                            ],
                        ),
                        dcc.Graph(id="lsa-country-chart", config=_GRAPH, style={"height": "460px", "width": "100%"}),
                    ]),
                    html.Div(style=_PANEL, children=[
                        html.Div("Additions by vendor", style=_LABEL),
                        dcc.Graph(id="lsa-vendor-chart", config=_GRAPH, style={"height": "440px", "width": "100%"}),
                    ]),
                    html.Div(style=_PANEL, children=[
                        html.Div("Cumulative nameplate", style={**_LABEL, "marginBottom": "0"}),
                        html.Div(
                            "All Countries",
                            id="lsa-cum-subtitle",
                            style=_CHART_SUBTITLE,
                        ),
                        dcc.Graph(id="lsa-cum-chart", config=_GRAPH, style={"height": "420px", "width": "100%"}),
                    ]),
                    html.Div(style=_PANEL, children=[
                        html.Div(
                            style={
                                "display": "flex",
                                "justifyContent": "space-between",
                                "alignItems": "flex-end",
                                "gap": "16px",
                                "flexWrap": "wrap",
                            },
                            children=[
                                html.Div([
                                    html.Div("Startup timeline", style={**_LABEL, "marginBottom": "0"}),
                                    html.Div(
                                        "All Countries",
                                        id="lsa-timeline-subtitle",
                                        style={**_CHART_SUBTITLE, "marginBottom": "0"},
                                    ),
                                ]),
                                html.Div(
                                    style={"display": "flex", "alignItems": "flex-end", "gap": "16px"},
                                    children=[
                                        html.Div([
                                            html.Label("Source", style=_LABEL),
                                            dcc.Dropdown(
                                                id="lsa-chart-source",
                                                options=_SOURCE_OPTIONS,
                                                value=[SOURCE_EA],
                                                multi=True,
                                                clearable=False,
                                                placeholder="Select sources",
                                                style={"width": "320px"},
                                            ),
                                        ]),
                                        dcc.Checklist(
                                            id="lsa-show-fid",
                                            options=[{"label": " Show Project FID", "value": "yes"}],
                                            value=[],
                                            style={"fontSize": "13px", "marginBottom": "8px"},
                                        ),
                                    ],
                                ),
                            ],
                        ),
                        html.Div(
                            TIMELINE_NOTE,
                            id="lsa-timeline-note",
                            style={"fontSize": "12px", "color": COLORS["text_muted"], "marginTop": "6px"},
                        ),
                        dcc.Graph(id="lsa-timeline-chart", config=_GRAPH, style={"height": "820px"}),
                    ]),
                ]),
                html.Div(style=_PANEL, children=[
                    html.Div("Projects", style={**_LABEL, "marginBottom": "10px"}),
                    _table("lsa-table", TABLE_COLUMNS),
                ]),
                html.Div(style=_PANEL, children=[
                    html.Div("Same project, different calendars", style={
                        **_LABEL, "marginBottom": "6px",
                    }),
                    html.Div(id="lsa-compare-note", style={
                        "fontSize": "12px", "color": COLORS["text_secondary"],
                        "marginBottom": "10px",
                    }),
                    _table("lsa-compare", [
                        {"name": "Country", "id": "country"},
                        {"name": "Project", "id": "project"},
                        {"name": "Spread (months)", "id": "spread_months", "type": "numeric", "format": FMT_0},
                    ]),
                ]),
            ]),
            html.P(
                "Goldman is a one-off snapshot (the rows in the 6 Oct 2026 crop, "
                "through 2029). Its FID year is the reference date on Goldman rows. "
                "Energy Aspects is the October 2026 liquefaction file, published "
                "2 Oct 2026. Cancelled, retired, and trains already active before "
                "2024 are left out. Platts trains come from the Snowflake LNG analytics "
                "share and are matched onto the Goldman project list; unmapped trains stay "
                "hidden until Show unmapped Platts trains is ticked. Start dates are "
                "year-month when the source only gives a month. 1 mtpa is filled as "
                "1.38 bcm/y only when a vendor publishes a single unit.",
                style={
                    "fontSize": "12px", "color": COLORS["text_muted"],
                    "lineHeight": "1.5", "margin": "4px 0 24px 0",
                },
            ),
        ],
    )
