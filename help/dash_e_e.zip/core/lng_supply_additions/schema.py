"""Normalised LNG supply-addition rows, filters, and vendor matching.

Every source (a dated CSV snapshot, or a live Energy Aspects / Platts pull)
is reduced to the same columns before it hits the table or the charts.
"""
from __future__ import annotations

import json
import re
from typing import Any

import pandas as pd

from core.lng_supply_additions.constants import (
    COUNTRY_ALIASES,
    MTPA_TO_BCM,
    SOURCE_EA,
    SOURCE_GS,
    SOURCE_ORDER,
    SOURCE_PLATTS,
)

COLUMNS: tuple[str, ...] = (
    "source",
    "source_kind",
    "as_of",
    "country",
    "project",
    "operator",
    "n_trains",
    "mtpa",
    "bcm_y",
    "start_date",
    "start_precision",
    "start_label",
    "fid_year",
    "fid_note",
    "fid_date",
    "gs_fid_year",
    "status",
    "note",
    "match_key",
    "on_goldman",
)

_MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

_STOP = {"lng", "flng", "the", "project", "plant"}


def empty_frame() -> pd.DataFrame:
    df = pd.DataFrame({col: pd.Series(dtype="object") for col in COLUMNS})
    df["start_date"] = pd.to_datetime(df["start_date"])
    df["mtpa"] = pd.Series(dtype="float64")
    df["bcm_y"] = pd.Series(dtype="float64")
    df["n_trains"] = pd.Series(dtype="float64")
    df["fid_year"] = pd.Series(dtype="float64")
    df["fid_date"] = pd.to_datetime(df["fid_date"])
    df["gs_fid_year"] = pd.Series(dtype="float64")
    df["on_goldman"] = pd.Series(dtype="bool")
    return df


def canonical_country(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return ""
    key = re.sub(r"\s+", " ", text.lower().replace(".", ""))
    return COUNTRY_ALIASES.get(key, text)


def project_key(country: Any, project: Any) -> str:
    """Loose key so 'North Field East T1' and 'North Field East Train 1' meet."""
    text = f"{country} {project}".lower().replace("'", "")
    text = re.sub(r"\bt\s*(\d+)\b", r"train \1", text)
    text = re.sub(r"\btrain\s*0*(\d+)\b", r"train \1", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    tokens = [tok for tok in text.split() if tok not in _STOP]
    return " ".join(tokens)


def plant_identity(project: Any) -> str:
    """Goldman plant slug. Existing Calcasieu Pass stays distinct from CP2."""
    text = str(project or "").lower().replace("'", "").replace("’", "")
    text = re.sub(r"[^a-z0-9]+", " ", text).strip()
    if not text:
        return ""
    if "cp2" in text or "pass 2" in text or "passs 2" in text:
        return "cp2"
    if "calcasieu" in text:
        return "calcasieu"
    if "brega" in text:
        return "marsa brega"
    if "north field south" in text:
        return "north field south"
    if "north field west" in text:
        return "north field west"
    if "north field east" in text:
        return "north field east"
    if "louisiana flng" in text or ("fast lng" in text and "gom" in text):
        return "fast gom"
    if "woodside louisiana" in text or "louisiana" in text or "driftwood" in text:
        return "louisiana"
    if "corpus christi" in text or "corpus" in text:
        return "corpus"
    if "golden pass" in text:
        return "golden pass"
    if "rio grande" in text:
        return "rio grande"
    if "port arthur" in text:
        return "port arthur"
    if "pluto" in text:
        return "pluto"
    if "woodfibre" in text or "wood fiber" in text:
        return "woodfibre"
    if "nigeria" in text:
        return "nigeria"
    if "marsa" in text:
        return "marsa"
    if "cedar" in text:
        return "cedar"
    if "ruwais" in text:
        return "ruwais"
    if "coral north" in text or "coral norte" in text:
        return "coral north"
    if "cap lopez" in text or "gabon lng" in text:
        return "cap lopez"
    if "hilli" in text:
        return "hilli"
    if "tiga" in text:
        return "tiga"
    return ""


def train_ids(project: Any) -> frozenset[int]:
    """Train numbers named on a project. Ranges such as T1-2 expand."""
    text = str(project or "").lower().replace("'", "").replace("’", "")
    nums: list[int] = []

    def _range(match: re.Match) -> str:
        start_n, end_n = int(match.group(1)), int(match.group(2))
        if end_n >= start_n and end_n - start_n <= 40:
            nums.extend(range(start_n, end_n + 1))
        return " "

    text = re.sub(r"\bt\s*(\d+)\s*[-–]\s*(\d+)\b", _range, text)
    for number in re.findall(r"\b(?:train|t)\s*0*(\d+)\b", text):
        nums.append(int(number))
    return frozenset(nums)


def phase_number(project: Any) -> int | None:
    match = re.search(r"phase\s*(\d+)", str(project or "").lower())
    return int(match.group(1)) if match else None


def is_addon_train(project: Any) -> bool:
    text = str(project or "").lower()
    return any(token in text for token in ("debottleneck", "uprate", "decommission"))


def source_slug(source: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(source).lower()).strip("_")


def source_sort(names) -> list[str]:
    seen = list(dict.fromkeys(str(n) for n in names if n))
    head = [s for s in SOURCE_ORDER if s in seen]
    tail = sorted(s for s in seen if s not in SOURCE_ORDER)
    return head + tail


def parse_when(value: Any) -> tuple[pd.Timestamp | None, str]:
    """Return ``(timestamp, precision)`` where precision is year, month, or day."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None, ""
    if isinstance(value, pd.Timestamp):
        if pd.isna(value):
            return None, ""
        precision = "day" if value.day != 1 else "month"
        return value.normalize(), precision
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        year = int(value)
        if 1990 <= year <= 2100:
            return pd.Timestamp(year=year, month=1, day=1), "year"
        return None, ""
    text = str(value).strip()
    if not text or text.lower() in {"nat", "none", "nan", "na"}:
        return None, ""
    text = text.rstrip("*").strip()
    if re.fullmatch(r"\d{4}", text):
        return pd.Timestamp(year=int(text), month=1, day=1), "year"
    month_match = re.fullmatch(r"([A-Za-z]{3,9})\s+(\d{4})", text)
    if month_match:
        month = _MONTHS.get(month_match.group(1).lower())
        if month:
            return pd.Timestamp(year=int(month_match.group(2)), month=month, day=1), "month"
    ym = re.fullmatch(r"(\d{4})-(\d{2})", text)
    if ym:
        month = int(ym.group(2))
        if 1 <= month <= 12:
            return pd.Timestamp(year=int(ym.group(1)), month=month, day=1), "month"
    ts = pd.to_datetime(text, errors="coerce")
    if pd.isna(ts):
        return None, ""
    ts = pd.Timestamp(ts).normalize()
    return ts, "month" if ts.day == 1 else "day"


def format_start(ts: Any, precision: str) -> str:
    if ts is None or pd.isna(ts):
        return ""
    ts = pd.Timestamp(ts)
    if precision == "year":
        return str(ts.year)
    if precision == "month":
        return ts.strftime("%Y-%m")
    return ts.strftime("%Y-%m-%d")


def _blank(value: Any) -> str:
    try:
        missing = value is None or pd.isna(value)
    except (TypeError, ValueError):
        missing = False
    if missing:
        return ""
    text = str(value).strip()
    return "" if text.lower() in {"nan", "<na>", "none"} else text


def finalize(rows: list[dict]) -> pd.DataFrame:
    """Coerce a list of partial rows into the canonical frame."""
    if not rows:
        return empty_frame()
    df = pd.DataFrame(rows)
    for col in COLUMNS:
        if col not in df.columns:
            df[col] = pd.NA
    df = df[list(COLUMNS)].copy()

    df["country"] = df["country"].map(canonical_country)
    df["project"] = df["project"].map(_blank)
    df["operator"] = df["operator"].map(_blank)
    df["status"] = df["status"].map(_blank)
    df["note"] = df["note"].map(_blank)
    df["source"] = df["source"].map(_blank)
    df["source_kind"] = df["source_kind"].map(_blank)
    df["as_of"] = df["as_of"].map(_blank)
    df["fid_note"] = df["fid_note"].map(_blank)

    parsed = df["start_date"].map(lambda v: parse_when(v) if not isinstance(v, pd.Timestamp) else (None if pd.isna(v) else (pd.Timestamp(v).normalize(), "")))
    # Timestamps already parsed by the caller keep their precision column.
    starts = []
    precisions = []
    for raw, prec, parsed_pair in zip(df["start_date"], df["start_precision"], parsed):
        if isinstance(raw, pd.Timestamp) and not pd.isna(raw):
            precision = _blank(prec) or ("month" if raw.day == 1 else "day")
            starts.append(pd.Timestamp(raw).normalize())
            precisions.append(precision)
        else:
            starts.append(parsed_pair[0])
            precisions.append(_blank(prec) or parsed_pair[1])
    df["start_date"] = pd.to_datetime(pd.Series(starts, index=df.index))
    df["start_precision"] = precisions
    df["start_label"] = [
        format_start(ts, prec) for ts, prec in zip(df["start_date"], df["start_precision"])
    ]
    fid_dates = []
    for raw in df["fid_date"]:
        if isinstance(raw, pd.Timestamp) and not pd.isna(raw):
            fid_dates.append(pd.Timestamp(raw).normalize())
        else:
            fid_dates.append(parse_when(raw)[0])
    df["fid_date"] = pd.to_datetime(pd.Series(fid_dates, index=df.index))

    for col in ("mtpa", "bcm_y", "n_trains", "fid_year", "gs_fid_year"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    dated_fid = df["fid_year"].isna() & df["fid_date"].notna()
    df.loc[dated_fid, "fid_year"] = df.loc[dated_fid, "fid_date"].dt.year
    own_fid = df["source"].eq(SOURCE_GS) & df["gs_fid_year"].isna()
    df.loc[own_fid, "gs_fid_year"] = df.loc[own_fid, "fid_year"]
    df["on_goldman"] = [
        (source != SOURCE_PLATTS) if pd.isna(value) else bool(value)
        for value, source in zip(df["on_goldman"], df["source"])
    ]

    missing_bcm = df["bcm_y"].isna() & df["mtpa"].notna()
    df.loc[missing_bcm, "bcm_y"] = df.loc[missing_bcm, "mtpa"] * MTPA_TO_BCM
    missing_mt = df["mtpa"].isna() & df["bcm_y"].notna()
    df.loc[missing_mt, "mtpa"] = df.loc[missing_mt, "bcm_y"] / MTPA_TO_BCM

    df["match_key"] = [
        project_key(country, project)
        for country, project in zip(df["country"], df["project"])
    ]
    df = df[df["project"] != ""].reset_index(drop=True)
    return df


def capacity_from_peak(peak: float, unit: str) -> tuple[float | None, float | None]:
    """Convert a vendor's capacity unit into ``(mtpa, bcm/y)``."""
    u = re.sub(r"[^a-z0-9/]", "", (unit or "").strip().lower())
    if u in {"mtpa", "mt/y", "mtpy", "mt/year", "mt/yr", "mt"} or "mtpa" in u:
        return float(peak), float(peak) * MTPA_TO_BCM
    if u in {"bcm", "bcma", "bcm/y", "bcm/year", "bcmy"}:
        return float(peak) / MTPA_TO_BCM, float(peak)
    if u in {"mcm/d", "mcmd", "mmcm/d"}:
        bcm = float(peak) * 365.0 / 1000.0
        return bcm / MTPA_TO_BCM, bcm
    if u in {"mt/month", "mt/m", "mtpm"}:
        mtpa = float(peak) * 12.0
        return mtpa, mtpa * MTPA_TO_BCM
    if 0.2 <= float(peak) <= 40:
        return float(peak), float(peak) * MTPA_TO_BCM
    return None, None


def addition_from_series(
    values: pd.Series,
    *,
    description: str,
    country: str,
    unit: str,
    as_of: str | None,
    today: pd.Timestamp | None = None,
    source: str = "Energy Aspects",
    dataset_id: str | int | None = None,
) -> dict | None:
    """Turn a quiet-then-ramping supply series into one addition row.

    Energy Aspects publishes paths, not a startup table. A series counts as
    new capacity when history is small relative to the forward peak. The
    start month is the first point above halfway from that history to the peak.
    """
    if values is None or len(values) == 0:
        return None
    series = pd.to_numeric(values, errors="coerce").dropna()
    if series.empty:
        return None
    series.index = pd.to_datetime(series.index).normalize()
    series = series.sort_index()
    today = (today or pd.Timestamp.today()).normalize()
    hist = series[series.index < today]
    fut = series[series.index >= today]
    if fut.empty:
        return None
    peak = float(fut.max())
    hist_level = float(hist.iloc[-1]) if len(hist) else 0.0
    delta = peak - hist_level
    if peak < 0.2 or delta < 0.2 or hist_level > 0.35 * peak:
        return None
    threshold = hist_level + 0.5 * delta
    crossed = series[series >= threshold]
    if crossed.empty:
        return None
    start = pd.Timestamp(crossed.index[0])
    if start < today - pd.DateOffset(months=18):
        return None
    mtpa, bcm = capacity_from_peak(delta, unit)
    if mtpa is None:
        return None
    note = "Inferred from a forward supply ramp"
    if dataset_id is not None:
        note = f"{note} (EA dataset {dataset_id})"
    return {
        "source": source,
        "source_kind": "live",
        "as_of": (as_of or "")[:10],
        "country": country,
        "project": (description or "").strip(),
        "operator": "",
        "n_trains": None,
        "mtpa": mtpa,
        "bcm_y": bcm,
        "start_date": start,
        "start_precision": "month",
        "fid_year": None,
        "fid_note": "",
        "status": "Inferred ramp",
        "note": note,
    }


def _gs_catalog(reference: pd.DataFrame) -> list[dict]:
    catalog = []
    for row in reference.itertuples(index=False):
        catalog.append({
            "match_key": row.match_key,
            "project": row.project,
            "country": row.country,
            "operator": row.operator,
            "fid_year": None if pd.isna(row.gs_fid_year) else float(row.gs_fid_year),
            "fid_note": row.fid_note,
            "plant": plant_identity(row.project),
            "trains": train_ids(row.project),
            "phase": phase_number(row.project),
            "n_trains": None if pd.isna(row.n_trains) else int(row.n_trains),
        })
    return catalog


def _attach_goldman_keys(part: pd.DataFrame, catalog: list[dict]) -> pd.DataFrame:
    """Point Energy Aspects rows at the Goldman project without renaming them.

    Platts is rewritten onto the Goldman name. Energy Aspects keeps the name
    from its file, so the timeline still shows each train. The comparison
    table groups on ``match_key``, which is what this updates.
    """
    out = part.copy()
    if out.empty or not catalog:
        return out
    phased_plants = {item["plant"] for item in catalog if item["phase"]}
    assignments: dict[int, dict] = {}
    phase_rows: dict[str, list[int]] = {plant: [] for plant in phased_plants}
    for idx, project in out["project"].items():
        project = "" if project is None or (isinstance(project, float) and pd.isna(project)) else str(project)
        if is_addon_train(project):
            continue
        plant = plant_identity(project)
        if plant in phased_plants:
            phase_rows[plant].append(idx)
            continue
        spec = _match_catalog(project, catalog)
        if spec is not None:
            assignments[idx] = spec
    for plant, indexes in phase_rows.items():
        phases = sorted(
            (item for item in catalog if item["plant"] == plant and item["phase"]),
            key=lambda item: item["phase"],
        )
        ordered = sorted(
            indexes,
            key=lambda idx: min(train_ids(out.at[idx, "project"]) or {10_000}),
        )
        cursor = 0
        for spec in phases:
            count = spec.get("n_trains") or 0
            for idx in ordered[cursor:cursor + count]:
                assignments[idx] = spec
            cursor += count
    for idx, spec in assignments.items():
        out.at[idx, "match_key"] = spec["match_key"]
    return out


def _match_catalog(project: str, catalog: list[dict]) -> dict | None:
    if is_addon_train(project):
        return None
    plant = plant_identity(project)
    if not plant:
        return None
    candidates = [item for item in catalog if item["plant"] == plant]
    if not candidates:
        return None
    if any(item["phase"] for item in candidates):
        return None
    trains = train_ids(project)
    with_trains = [item for item in candidates if item["trains"]]
    if with_trains:
        hits = [item for item in with_trains if trains & item["trains"]]
        return hits[0] if len(hits) == 1 else None
    return candidates[0] if len(candidates) == 1 else None


def _collapse_match(rows: list[dict], spec: dict, source: str) -> dict:
    ordered = sorted(
        rows,
        key=lambda row: pd.Timestamp(row["start_date"]) if pd.notna(row["start_date"]) else pd.Timestamp.max,
    )
    first = ordered[0]
    names = list(dict.fromkeys(str(row["project"]) for row in ordered if row.get("project")))
    shown = ", ".join(names[:6])
    if len(names) > 6:
        shown += f" +{len(names) - 6} more"
    vendor = "Platts" if source == SOURCE_PLATTS else source
    mtpa = [float(row["mtpa"]) for row in ordered if pd.notna(row.get("mtpa"))]
    trains = [float(row["n_trains"]) for row in ordered if pd.notna(row.get("n_trains"))]
    return {
        "source": source,
        "source_kind": first.get("source_kind") or "live",
        "as_of": first.get("as_of") or "",
        "country": spec["country"],
        "project": spec["project"],
        "operator": spec["operator"] or first.get("operator") or "",
        "n_trains": sum(trains) if trains else None,
        "mtpa": sum(mtpa) if mtpa else None,
        "bcm_y": None,
        "start_date": first.get("start_date"),
        "start_precision": first.get("start_precision") or "",
        "fid_year": first.get("fid_year"),
        "fid_note": spec.get("fid_note") or "",
        "fid_date": first.get("fid_date"),
        "gs_fid_year": spec.get("fid_year"),
        "status": first.get("status") or "",
        "note": f"{vendor} trains: {shown}",
        "on_goldman": True,
    }


def align_vendors(frame: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    """Rename vendor rows onto the Goldman project list and attach GS FID.

    Platts trains that do not match a Goldman project stay in the frame with
    ``on_goldman`` false so the page can hide them. One Goldman phase, such
    as CP2, takes the earliest Platts start cluster; the next phase takes
    the next cluster. Debottlenecks and uprates are left unmatched.
    """
    if frame is None or frame.empty:
        return empty_frame(), ""
    work = frame.copy()
    if "gs_fid_year" not in work.columns:
        work["gs_fid_year"] = pd.NA
    if "on_goldman" not in work.columns:
        work["on_goldman"] = ~work["source"].eq(SOURCE_PLATTS)
    gs = work[work["source"].eq(SOURCE_GS)].copy()
    if not gs.empty:
        missing = gs["gs_fid_year"].isna()
        gs.loc[missing, "gs_fid_year"] = gs.loc[missing, "fid_year"]
        gs["on_goldman"] = True
    catalog = _gs_catalog(gs) if not gs.empty else []
    pieces = [gs] if not gs.empty else []
    note = ""
    for source, part in work[~work["source"].eq(SOURCE_GS)].groupby("source", sort=False):
        if str(source) == SOURCE_EA:
            kept = _attach_goldman_keys(part, catalog)
            kept["on_goldman"] = True
            pieces.append(kept)
            continue
        aligned, source_note = _align_source(part, catalog, str(source))
        pieces.append(aligned)
        if source == SOURCE_PLATTS:
            note = source_note
    combined = pd.concat(pieces, ignore_index=True) if pieces else empty_frame()
    return combined.reset_index(drop=True), note


def _align_source(part: pd.DataFrame, catalog: list[dict], source: str) -> tuple[pd.DataFrame, str]:
    if part.empty:
        return part, ""
    phased_plants = {item["plant"] for item in catalog if item["phase"]}
    buckets: dict[str, list[dict]] = {}
    phase_rows: dict[str, list[dict]] = {plant: [] for plant in phased_plants}
    unmatched: list[dict] = []
    for rec in part.to_dict(orient="records"):
        project = str(rec.get("project") or "")
        if is_addon_train(project):
            unmatched.append(rec)
            continue
        plant = plant_identity(project)
        if plant in phased_plants:
            phase_rows[plant].append(rec)
            continue
        spec = _match_catalog(project, catalog)
        if spec is None:
            unmatched.append(rec)
            continue
        buckets.setdefault(spec["match_key"], []).append(rec)

    by_key = {item["match_key"]: item for item in catalog}
    for plant, rows in phase_rows.items():
        phases = sorted(
            (item for item in catalog if item["plant"] == plant and item["phase"]),
            key=lambda item: item["phase"],
        )
        dated = [row for row in rows if pd.notna(row.get("start_date"))]
        undated = [row for row in rows if pd.isna(row.get("start_date"))]
        unmatched.extend(undated)
        clusters: dict[pd.Period, list[dict]] = {}
        for row in dated:
            month = pd.Timestamp(row["start_date"]).to_period("M")
            clusters.setdefault(month, []).append(row)
        for month, spec in zip(sorted(clusters), phases):
            buckets.setdefault(spec["match_key"], []).extend(clusters[month])
        for month in list(sorted(clusters))[len(phases):]:
            unmatched.extend(clusters[month])

    matched_rows = [
        _collapse_match(rows, by_key[key], source)
        for key, rows in buckets.items()
        if key in by_key
    ]
    for rec in unmatched:
        rec["on_goldman"] = source != SOURCE_PLATTS
        rec["gs_fid_year"] = pd.NA
    built = finalize(matched_rows + unmatched)
    matched_keys = {row["project"] for row in matched_rows}
    if source != SOURCE_PLATTS:
        return built, ""
    gs_projects = [item["project"] for item in catalog]
    missed = [name for name in gs_projects if name not in matched_keys]
    if built.empty:
        other = 0
    else:
        flag = pd.Series(built["on_goldman"], dtype="boolean").fillna(False).astype(bool)
        other = int((built["source"].eq(SOURCE_PLATTS) & ~flag).sum())
    missed_text = ", ".join(missed) if missed else "none"
    note = (
        f"Matched {len(matched_rows)} of {len(gs_projects)} Goldman projects. "
        f"No Platts train for: {missed_text}. "
        f"{other} unmapped Platts trains stay hidden until Show unmapped Platts trains is ticked."
    )
    return built, note


def apply_filters(
    df: pd.DataFrame,
    *,
    sources: list[str] | None = None,
    countries: list[str] | None = None,
    year_from: int | None = None,
    year_to: int | None = None,
    search: str = "",
    min_mtpa: float | None = 0,
    include_undated: bool = False,
    include_unmatched_platts: bool = False,
) -> pd.DataFrame:
    if df is None or df.empty:
        return empty_frame()
    out = df.copy()
    out["start_date"] = pd.to_datetime(out["start_date"], errors="coerce")
    if not include_unmatched_platts and "on_goldman" in out.columns and "source" in out.columns:
        hide = out["source"].eq(SOURCE_PLATTS) & ~out["on_goldman"].fillna(False).astype(bool)
        out = out[~hide]
    if sources is not None:
        out = out[out["source"].isin(list(sources))]
    if countries:
        out = out[out["country"].isin(countries)]
    query = (search or "").strip().lower()
    if query:
        blob = (
            out["project"].fillna("").astype(str) + " "
            + out["operator"].fillna("").astype(str) + " "
            + out["country"].fillna("").astype(str)
        ).str.lower()
        out = out[blob.str.contains(re.escape(query), regex=True)]
    if min_mtpa:
        out = out[out["mtpa"].fillna(0) >= float(min_mtpa)]
    years = out["start_date"].dt.year
    undated = out["start_date"].isna()
    in_window = pd.Series(True, index=out.index)
    if year_from is not None:
        in_window = in_window & (years >= int(year_from))
    if year_to is not None:
        in_window = in_window & (years <= int(year_to))
    in_window = in_window.fillna(False)
    out = out[in_window | undated] if include_undated else out[in_window]
    if out.empty:
        return empty_frame()
    return out.sort_values(
        ["start_date", "country", "project"], na_position="last"
    ).reset_index(drop=True)


def for_source(df: pd.DataFrame, source: str | None) -> pd.DataFrame:
    if df is None or df.empty or not source:
        return empty_frame()
    out = df[df["source"] == source]
    return out.reset_index(drop=True) if not out.empty else empty_frame()


def annual_totals(df: pd.DataFrame, column: str = "mtpa") -> dict[int, float]:
    if df is None or df.empty:
        return {}
    dated = df.dropna(subset=["start_date"])
    if dated.empty:
        return {}
    grouped = dated.groupby(dated["start_date"].dt.year)[column].sum()
    return {int(year): float(value) for year, value in grouped.items()}


def summarise(df: pd.DataFrame) -> dict[str, Any]:
    if df is None or df.empty:
        return {
            "n": 0, "mtpa": 0.0, "bcm_y": 0.0,
            "next_project": "", "next_start": "", "n_sources": 0,
        }
    dated = df.dropna(subset=["start_date"]).sort_values("start_date")
    nxt = dated.iloc[0] if not dated.empty else None
    return {
        "n": int(len(df)),
        "mtpa": float(df["mtpa"].sum(skipna=True)),
        "bcm_y": float(df["bcm_y"].sum(skipna=True)),
        "next_project": "" if nxt is None else str(nxt["project"]),
        "next_start": "" if nxt is None else str(nxt["start_label"]),
        "n_sources": int(df["source"].nunique()),
    }


def present(df: pd.DataFrame) -> pd.DataFrame:
    """Display columns for the browse table. Does not change filter totals."""
    if df is None or df.empty:
        out = empty_frame()
    else:
        out = df.copy()
    fid = []
    gs_fid = []
    trains = []
    years = out.get("fid_year", pd.Series(dtype="float64"))
    notes = out.get("fid_note", pd.Series(dtype="object"))
    counts = out.get("n_trains", pd.Series(dtype="float64"))
    gs_years = out.get("gs_fid_year", pd.Series(dtype="float64"))
    sources = out.get("source", pd.Series(dtype="object"))
    fid_dates = out.get("fid_date", pd.Series(dtype="object"))
    for year, note, n, gs_year, source, fid_dt in zip(
        years, notes, counts, gs_years, sources, fid_dates,
    ):
        mark = _blank(note)
        if pd.notna(fid_dt):
            stamp = pd.Timestamp(fid_dt)
            fid.append(format_start(stamp, "month" if stamp.day == 1 else "day"))
        else:
            fid.append("" if pd.isna(year) else f"{int(year)}{mark}")
        gs_mark = mark if source == SOURCE_GS else ""
        gs_fid.append("" if pd.isna(gs_year) else f"{int(gs_year)}{gs_mark}")
        if pd.isna(n):
            trains.append("")
        else:
            number = float(n)
            trains.append(str(int(number)) if number.is_integer() else f"{number:g}")
    out["fid_display"] = fid
    out["gs_fid_display"] = gs_fid
    out["trains_display"] = trains
    if "mtpa" in out.columns:
        out["mtpa"] = pd.to_numeric(out["mtpa"], errors="coerce").round(2)
    if "bcm_y" in out.columns:
        out["bcm_y"] = pd.to_numeric(out["bcm_y"], errors="coerce").round(2)
    return out


def frame_to_records(df: pd.DataFrame) -> list[dict]:
    if df is None or df.empty:
        return []
    out = df.copy()
    if "start_date" in out.columns:
        out["start_date"] = pd.to_datetime(out["start_date"], errors="coerce").dt.strftime("%Y-%m-%d")
    if "fid_date" in out.columns:
        out["fid_date"] = pd.to_datetime(out["fid_date"], errors="coerce").dt.strftime("%Y-%m-%d")
    return json.loads(out.to_json(orient="records"))


def records_to_frame(records: list[dict] | None) -> pd.DataFrame:
    if not records:
        return empty_frame()
    df = pd.DataFrame(records)
    for col in COLUMNS:
        if col not in df.columns:
            df[col] = pd.NA
    df["start_date"] = pd.to_datetime(df["start_date"], errors="coerce")
    if "fid_date" in df.columns:
        df["fid_date"] = pd.to_datetime(df["fid_date"], errors="coerce")
    for col in ("mtpa", "bcm_y", "n_trains", "fid_year", "gs_fid_year"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if "on_goldman" in df.columns:
        df["on_goldman"] = [
            False if pd.isna(value) else bool(value) for value in df["on_goldman"]
        ]
    return df


def vendor_comparison(df: pd.DataFrame) -> list[dict]:
    """One row per project that shows up in at least two sources.

    Spread is the gap, in months, between the earliest and latest startup.
    Zero means the vendors agree on the month.
    """
    if df is None or df.empty or df["source"].nunique() < 2:
        return []
    sources = source_sort(df["source"].unique())
    records = []
    for key, group in df.groupby("match_key", dropna=False):
        if not key or group["source"].nunique() < 2:
            continue
        gs_years = group["gs_fid_year"].dropna() if "gs_fid_year" in group.columns else pd.Series(dtype="float64")
        gs_names = group.loc[group["source"].eq(SOURCE_GS), "project"]
        project = (
            str(gs_names.iloc[0])
            if not gs_names.empty
            else max(group["project"].astype(str).tolist(), key=len)
        )
        rec: dict[str, Any] = {
            "country": group["country"].iloc[0],
            "project": project,
            "gs_fid": "" if gs_years.empty else str(int(gs_years.iloc[0])),
        }
        dates = []
        for source in sources:
            slug = source_slug(source)
            subset = group[group["source"] == source].sort_values(
                "start_date", na_position="last"
            )
            if subset.empty:
                rec[f"start__{slug}"] = ""
                rec[f"mtpa__{slug}"] = None
                continue
            first = subset.iloc[0]
            rec[f"start__{slug}"] = _blank(first.get("start_label"))
            rec[f"mtpa__{slug}"] = (
                None if subset["mtpa"].isna().all() else round(float(subset["mtpa"].sum(skipna=True)), 2)
            )
            if pd.notna(first["start_date"]):
                dates.append(pd.Timestamp(first["start_date"]))
        if len(dates) >= 2:
            rec["spread_months"] = int(round((max(dates) - min(dates)).days / 30.437))
        else:
            rec["spread_months"] = None
        records.append(rec)
    records.sort(key=lambda r: (-(r["spread_months"] or 0), r["country"], r["project"]))
    return records
