"""Callbacks for the LNG — Supply Additions page.

The first paint is the dated snapshots (Goldman and Energy Aspects). A
one-shot interval then queries Platts. Filters and charts read the store,
so changing a dropdown does not hit Platts again.
"""
from __future__ import annotations

import logging

from dash import Input, Output, State, callback, ctx, html, no_update

from core.lng_supply_additions.charts import (
    fig_by_country,
    fig_by_source,
    fig_cumulative,
    fig_timeline,
)
from core.lng_supply_additions.constants import (
    EA_FILE_LABEL,
    EA_FILE_URL,
    SOURCE_EA,
    SOURCE_ORDER,
)
from core.lng_supply_additions.data import full_payload, snapshot_payload
from core.lng_supply_additions.layout import TIMELINE_NOTE, TIMELINE_NOTE_OVERLAY
from core.lng_supply_additions.schema import (
    apply_filters,
    empty_frame,
    for_source,
    frame_to_records,
    present,
    records_to_frame,
    source_slug,
    source_sort,
    vendor_comparison,
)
from core.styles import COLORS, get_status_badge_style

logger = logging.getLogger(__name__)

_BADGE_LEVEL = {"ok": "success", "pending": "info", "error": "warning", "empty": "warning"}

_COMPARE_BASE = [
    {"name": "Country", "id": "country"},
    {"name": "Project", "id": "project"},
    {"name": "GS FID", "id": "gs_fid"},
]


def _badge(item: dict) -> html.Div:
    level = _BADGE_LEVEL.get(item.get("state") or "", "info")
    bits = [item.get("label") or "Source"]
    if item.get("kind"):
        bits.append(str(item["kind"]))
    if item.get("as_of"):
        bits.append(str(item["as_of"])[:10])
    if item.get("n"):
        bits.append(f"{int(item['n'])} rows")
    note_style = {
        "fontSize": "12px",
        "color": COLORS["text_secondary"],
        "marginTop": "4px",
        "lineHeight": "1.4",
    }
    message = item.get("message") or ""
    if item.get("label") == SOURCE_EA:
        note = html.Div([
            message,
            " File: ",
            html.A(
                EA_FILE_LABEL,
                href=EA_FILE_URL,
                target="_blank",
                rel="noopener noreferrer",
                style={"color": COLORS["accent"], "fontWeight": "600"},
            ),
            ".",
        ], style=note_style)
    else:
        note = html.Div(message, style=note_style)
    return html.Div([
        html.Span(" · ".join(bits), style=get_status_badge_style(level)),
        note,
    ], style={"maxWidth": "520px"})


def _chart_sources(chart_source) -> list[str]:
    if chart_source is None:
        return []
    if isinstance(chart_source, str):
        return [chart_source] if chart_source else []
    return [str(item) for item in chart_source if item]


def _country_subtitle(countries) -> str:
    """Dropdown selection, or every country when the filter is empty."""
    names = [str(name).strip() for name in (countries or []) if str(name).strip()]
    if not names:
        return "All Countries"
    return ", ".join(names)


def _compare_columns(sources: list[str]) -> list[dict]:
    columns = list(_COMPARE_BASE)
    for source in sources:
        slug = source_slug(source)
        columns.append({"name": f"{source} start", "id": f"start__{slug}"})
        columns.append({
            "name": f"{source} Mtpa",
            "id": f"mtpa__{slug}",
            "type": "numeric",
            "format": {"specifier": ".1f"},
        })
    columns.append({
        "name": "Spread (months)",
        "id": "spread_months",
        "type": "numeric",
        "format": {"specifier": ".0f"},
    })
    return columns


@callback(
    Output("lsa-store", "data"),
    Input("lsa-refresh", "n_clicks"),
    Input("lsa-live-once", "n_intervals"),
)
def load_store(n_clicks, n_intervals):
    triggered = ctx.triggered_id
    try:
        if triggered == "lsa-refresh" and n_clicks:
            return full_payload(force=True)
        if triggered == "lsa-live-once" and n_intervals:
            return full_payload(force=False)
        return snapshot_payload()
    except Exception as exc:
        logger.exception("Supply additions load failed")
        payload = snapshot_payload()
        payload["sources"] = [
            item for item in payload["sources"] if item.get("state") != "pending"
        ]
        payload["sources"].append({
            "label": "Live sources",
            "state": "error",
            "kind": "live",
            "as_of": "",
            "n": 0,
            "message": f"Live queries failed ({type(exc).__name__}).",
        })
        return payload


@callback(
    Output("lsa-sources", "options"),
    Output("lsa-sources", "value"),
    Output("lsa-country", "options"),
    Output("lsa-country", "value"),
    Output("lsa-chart-source", "options"),
    Output("lsa-chart-source", "value"),
    Output("lsa-country-source", "options"),
    Output("lsa-country-source", "value"),
    Input("lsa-store", "data"),
    Input("lsa-sources", "value"),
    State("lsa-sources", "options"),
    State("lsa-country", "value"),
    State("lsa-chart-source", "value"),
    State("lsa-country-source", "value"),
)
def sync_filters(data, selected, prev_options, country_value, chart_value, country_source):
    if not data:
        return (no_update,) * 8
    row_sources = [row.get("source") for row in data.get("rows") or []]
    labels = source_sort(list(SOURCE_ORDER) + row_sources)
    source_options = [{"label": label, "value": label} for label in labels]
    prev = [opt["value"] for opt in (prev_options or [])]
    # None means the checklist has not been touched; [] means the user cleared it.
    chosen = list(labels) if selected is None else list(selected)
    added = [label for label in labels if label not in prev and label not in chosen]
    new_selected = [label for label in chosen if label in labels] + added

    countries = sorted({row.get("country") for row in data.get("rows") or [] if row.get("country")})
    country_options = [{"label": country, "value": country} for country in countries]
    kept_countries = [country for country in (country_value or []) if country in countries]

    chart_labels = sorted(label for label in labels if label in new_selected)
    chart_options = [{"label": label, "value": label} for label in chart_labels]

    def _keep(current):
        if current in chart_labels:
            return current
        if SOURCE_EA in chart_labels:
            return SOURCE_EA
        return chart_labels[0] if chart_labels else None

    def _keep_many(current):
        if not chart_labels:
            return []
        if current is None:
            return [SOURCE_EA] if SOURCE_EA in chart_labels else [chart_labels[0]]
        picked = [current] if isinstance(current, str) else list(current or [])
        kept = [label for label in picked if label in chart_labels]
        if picked and not kept:
            return [SOURCE_EA] if SOURCE_EA in chart_labels else [chart_labels[0]]
        return kept

    new_chart = _keep_many(chart_value)
    new_country_source = _keep(country_source)

    return (
        source_options if source_options != (prev_options or []) else no_update,
        new_selected if new_selected != chosen else no_update,
        country_options,
        kept_countries if kept_countries != (country_value or []) else no_update,
        chart_options,
        new_chart if new_chart != chart_value else no_update,
        chart_options,
        new_country_source if new_country_source != country_source else no_update,
    )


def _filtered_frame(data, sources, countries, year_from, year_to, undated, other_platts):
    frame = records_to_frame((data or {}).get("rows"))
    return frame, apply_filters(
        frame,
        sources=sources,
        countries=countries or None,
        year_from=year_from,
        year_to=year_to,
        include_undated="yes" in (undated or []),
        include_unmatched_platts="yes" in (other_platts or []),
    )


@callback(
    Output("lsa-view", "data"),
    Output("lsa-status", "children"),
    Output("lsa-scope-note", "children"),
    Output("lsa-table", "data"),
    Output("lsa-compare", "data"),
    Output("lsa-compare", "columns"),
    Output("lsa-compare-note", "children"),
    Output("lsa-vendor-chart", "figure"),
    Output("lsa-cum-chart", "figure"),
    Output("lsa-cum-subtitle", "children"),
    Output("lsa-timeline-subtitle", "children"),
    Input("lsa-store", "data"),
    Input("lsa-sources", "value"),
    Input("lsa-country", "value"),
    Input("lsa-year-from", "value"),
    Input("lsa-year-to", "value"),
    Input("lsa-undated", "value"),
    Input("lsa-other-platts", "value"),
)
def render_shared(data, sources, countries, year_from, year_to, undated, other_platts):
    country_label = _country_subtitle(countries)
    if not data:
        blank = empty_frame()
        return (
            None,
            [],
            "Loading the Goldman snapshot…",
            [],
            [],
            no_update,
            "",
            fig_by_source(blank),
            fig_cumulative(blank),
            country_label,
            country_label,
        )

    frame, filtered = _filtered_frame(
        data, sources, countries, year_from, year_to, undated, other_platts,
    )
    n_sources = 0 if filtered.empty else int(filtered["source"].nunique())
    notes = []
    if year_from is not None and year_to is not None and int(year_from) > int(year_to):
        notes.append("Start year is after the end year.")
    if "yes" not in (undated or []):
        with_undated = apply_filters(
            frame,
            sources=sources,
            countries=countries or None,
            year_from=year_from,
            year_to=year_to,
            include_undated=True,
            include_unmatched_platts="yes" in (other_platts or []),
        )
        hidden = len(with_undated) - len(filtered)
        if hidden > 0:
            notes.append(
                f"{hidden} rows have no startup date and are hidden. "
                "Tick Include undated to see them."
            )
    if n_sources > 1:
        notes.append(
            "The country chart uses one source, so it is not the sum of the vendor bars. "
            "Bars for the current year only include startups still ahead."
        )
    if filtered.empty and not notes:
        notes.append("Nothing matches this filter.")

    in_view = source_sort(filtered["source"].dropna().unique()) if not filtered.empty else []
    if len(in_view) < 2:
        compare_rows: list[dict] = []
        compare_note = "Check two or more sources to compare startup dates on the same project."
        compare_columns = list(_COMPARE_BASE)
    else:
        compare_rows = vendor_comparison(filtered)
        compare_columns = _compare_columns(in_view)
        if compare_rows:
            compare_note = (
                f"{len(compare_rows)} projects appear in more than one source. "
                "Spread is the gap between the earliest and latest startup; zero means they agree on the month."
            )
        else:
            compare_note = (
                "No project names line up yet across these sources. Annual totals still compare "
                "the schedules in aggregate. A dated CSV with the other vendor's project names "
                "can be dropped in beside the Goldman file."
            )

    return (
        {"rows": frame_to_records(filtered)},
        [_badge(item) for item in data.get("sources") or []],
        " ".join(notes),
        frame_to_records(present(filtered)),
        compare_rows,
        compare_columns,
        compare_note,
        fig_by_source(filtered),
        fig_cumulative(filtered),
        country_label,
        country_label,
    )


@callback(
    Output("lsa-country-chart", "figure"),
    Input("lsa-view", "data"),
    Input("lsa-country-source", "value"),
)
def render_country(view, country_source):
    frame = records_to_frame((view or {}).get("rows"))
    return fig_by_country(for_source(frame, country_source))


@callback(
    Output("lsa-timeline-chart", "figure"),
    Output("lsa-timeline-note", "children"),
    Input("lsa-view", "data"),
    Input("lsa-chart-source", "value"),
    Input("lsa-show-fid", "value"),
)
def render_timeline(view, chart_source, show_fid):
    frame = records_to_frame((view or {}).get("rows"))
    sources = _chart_sources(chart_source)
    if sources and not frame.empty and "source" in frame.columns:
        frame = frame[frame["source"].isin(sources)].reset_index(drop=True)
    else:
        frame = empty_frame()
    note = TIMELINE_NOTE_OVERLAY if len(sources) > 1 else TIMELINE_NOTE
    return fig_timeline(
        frame,
        show_fid="yes" in (show_fid or []),
        overlay=len(sources) > 1,
    ), note
