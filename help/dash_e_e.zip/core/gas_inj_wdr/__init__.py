"""EU Gas Balance — Injectability / Withdrawability."""
