"""Injectability / withdrawability capability charts."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.gas_inj_wdr.constants import COUNTRY_COLORS, VIEW_PCT, resolve_chart_countries
from core.gas_inj_wdr.data import utilisation_pct
from core.styles import COLORS

_H_LEGEND = dict(
    orientation="h",
    xanchor="center",
    yanchor="top",
    bgcolor="rgba(255,255,255,0.75)",
    borderwidth=0,
    font=dict(size=11),
    itemsizing="constant",
    xref="paper",
    yref="paper",
)
SINGLE_FIG_HEIGHT = 560
TOP_PANEL_HEIGHT = 440
COUNTRY_ROW_MIN_HEIGHT = 340


def figure_height(n_country_rows: int) -> int:
    """Pixel height so each country row stays readable when several are selected."""
    if n_country_rows <= 0:
        return SINGLE_FIG_HEIGHT
    return TOP_PANEL_HEIGHT + n_country_rows * COUNTRY_ROW_MIN_HEIGHT


def _vertical_spacing(n_rows: int) -> float:
    if n_rows <= 1:
        return 0.08
    return min(0.07, 0.28 / (n_rows - 1))


def _empty_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
        font={"size": 14, "color": "#888"},
    )
    fig.update_layout(
        height=420,
        autosize=False,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        margin=dict(t=40, b=40, l=50, r=20),
    )
    return fig


def _has_series(frame: pd.DataFrame | None) -> bool:
    return frame is not None and isinstance(frame, pd.DataFrame) and not frame.empty


def _legend_key(index: int) -> str:
    return "legend" if index == 0 else f"legend{index + 1}"


def _selection_frames(
    df: pd.DataFrame,
    actual: pd.DataFrame | None,
    top_panel: str,
    country_cols: list[str],
) -> tuple[pd.DataFrame, pd.DataFrame | None]:
    """Keep selected countries; Total is the sum of those countries, not the catalog."""
    keep = [c for c in country_cols if c in df.columns]
    if top_panel == "Total":
        out = df.copy()
        if keep:
            out["Total"] = out[keep].sum(axis=1, min_count=1)
        plot_df = out
        actual_df = None
        if _has_series(actual):
            actual_df = actual.copy()
            present = [c for c in keep if c in actual_df.columns]
            if present:
                actual_df["Total"] = actual_df[present].sum(axis=1, min_count=1)
        return plot_df, actual_df
    return df, actual if _has_series(actual) else None


def _legend_layout(fig: go.Figure, n_subplots: int, n_country_rows: int) -> dict:
    """Center a legend below each subplot, clear of x-axis tick labels.

    Tick labels sit just below the axis (paper y0). A small pad lands on those
    labels; the last row / single-panel case therefore uses a larger pad and
    the figure keeps a matching bottom margin.
    """
    layout: dict = {}
    for i in range(n_subplots):
        axis = "xaxis" if i == 0 else f"xaxis{i + 1}"
        yaxis = "yaxis" if i == 0 else f"yaxis{i + 1}"
        xaxis = fig.layout[axis]
        yax = fig.layout[yaxis]
        if xaxis.domain is None or yax.domain is None:
            continue
        x0, x1 = xaxis.domain
        y0, _y1 = yax.domain
        on_last_row = n_country_rows == 0 or (i > 0 and (i - 1) // 2 == n_country_rows - 1)
        pad = 0.20 if on_last_row else 0.09
        layout[_legend_key(i)] = dict(
            **_H_LEGEND,
            x=(x0 + x1) / 2.0,
            y=y0 - pad,
        )
    return layout


def build_capability_chart(
    df: pd.DataFrame,
    title: str,
    yaxis_title: str,
    countries: list[str] | None = None,
    color: str = COLORS["chart_primary"],
    actual: pd.DataFrame | None = None,
    mode: str = "mcm",
) -> go.Figure:
    if df is None or df.empty:
        return _empty_fig("No capability series -- run the fit job")

    top_panel, country_cols = resolve_chart_countries(countries)
    plot_df, actual_df = _selection_frames(df, actual, top_panel, country_cols)
    pct_mode = mode == VIEW_PCT
    hover_y = "%{y:.1f} mcm/d"
    if pct_mode:
        plot_df = utilisation_pct(actual_df if _has_series(actual_df) else actual, plot_df)
        actual_df = None
        yaxis_title = "% of max"
        hover_y = "%{y:.0f}%"
        title = f"{title} % of max"
        if plot_df is None or plot_df.empty:
            return _empty_fig("No actual vs max series -- force-refresh the cache")

    country_cols = [c for c in country_cols if c in plot_df.columns]
    if top_panel not in plot_df.columns:
        if "Total" in plot_df.columns:
            top_panel = "Total"
        else:
            return _empty_fig(f"No series for {top_panel}")

    n_country_rows = (len(country_cols) + 1) // 2
    n_rows = 1 + n_country_rows
    n_subplots = 1 + len(country_cols)
    fig_height = figure_height(n_country_rows)
    row_heights = [2.0] + [1.0] * n_country_rows if n_country_rows else None
    subplot_titles = [f"{title} - {top_panel}"] + country_cols
    while len(subplot_titles) < 1 + max(n_country_rows, 0) * 2:
        subplot_titles.append("")

    if n_country_rows == 0:
        fig = make_subplots(
            rows=1,
            cols=2,
            specs=[[{"colspan": 2}, None]],
            subplot_titles=subplot_titles[:1],
        )
    else:
        specs = [[{"colspan": 2}, None]] + [[{}, {}] for _ in range(n_country_rows)]
        fig = make_subplots(
            rows=n_rows,
            cols=2,
            specs=specs,
            subplot_titles=subplot_titles,
            row_heights=row_heights,
            vertical_spacing=_vertical_spacing(n_rows),
            horizontal_spacing=0.08,
        )

    def _add(
        row: int,
        col: int,
        series_name: str,
        source: pd.DataFrame,
        *,
        legend: str,
        legend_key: str,
        show_legend: bool,
        dash: str | None = None,
        width: float = 1.5,
    ) -> None:
        if source is None or series_name not in source.columns:
            return
        s = source[series_name].dropna()
        if s.empty:
            return
        fig.add_trace(
            go.Scatter(
                x=s.index,
                y=s.values,
                mode="lines",
                name=legend,
                legend=legend_key,
                line=dict(
                    color=COUNTRY_COLORS.get(series_name, color),
                    width=width,
                    dash=dash or "solid",
                ),
                showlegend=show_legend,
                hovertemplate="%{x|%d-%b-%Y}<br>" + hover_y + "<extra>" + legend + "</extra>",
            ),
            row=row,
            col=col,
        )

    overlay = actual_df is not None
    cap_legend = "Max" if overlay else top_panel
    top_key = _legend_key(0)
    _add(
        1,
        1,
        top_panel,
        plot_df,
        legend=cap_legend,
        legend_key=top_key,
        show_legend=True,
        width=2.2,
    )
    if overlay:
        _add(
            1,
            1,
            top_panel,
            actual_df,
            legend="Actual",
            legend_key=top_key,
            show_legend=True,
            dash="dot",
            width=1.8,
        )
    if pct_mode:
        fig.add_hline(y=100, line_dash="dash", line_color="#888", line_width=1, row=1, col=1)

    for i, country in enumerate(country_cols):
        r = 2 + i // 2
        c = 1 + i % 2
        key = _legend_key(i + 1)
        _add(
            r,
            c,
            country,
            plot_df,
            legend="Max" if overlay else country,
            legend_key=key,
            show_legend=overlay,
            width=1.5,
        )
        if overlay:
            _add(
                r,
                c,
                country,
                actual_df,
                legend="Actual",
                legend_key=key,
                show_legend=True,
                dash="dot",
                width=1.3,
            )
        if pct_mode:
            fig.add_hline(y=100, line_dash="dash", line_color="#888", line_width=1, row=r, col=c)

    fig.update_layout(
        height=fig_height,
        autosize=False,
        uirevision=f"{title}-{top_panel}-{','.join(country_cols)}-{mode}",
        yaxis_title=yaxis_title,
        margin=dict(t=50, b=120, l=50, r=20),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        **_legend_layout(fig, n_subplots, n_country_rows),
    )
    fig.update_yaxes(title_text=yaxis_title, row=1, col=1)
    fig.update_xaxes(ticks="outside", ticklabelstandoff=4, automargin=False)
    return fig
