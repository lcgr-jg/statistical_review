"""Injectability / Withdrawability callbacks."""
from __future__ import annotations

import logging

import pandas as pd
from dash import Input, Output, callback, dcc, html

from core.gas_inj_wdr.charts import build_capability_chart
from core.gas_inj_wdr.constants import VIEW_MCM, VIEW_PCT, withdraw_first
from core.gas_inj_wdr.data import get_cached_payload, parse_countries
from core.styles import COLORS, get_status_badge_style

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "10px 14px",
            "borderRadius": "8px",
            "fontSize": "13px",
        },
    )


def _as_frame(value) -> pd.DataFrame:
    if isinstance(value, pd.DataFrame):
        return value
    if isinstance(value, list):
        return pd.DataFrame(value)
    return pd.DataFrame()


def _util_label(actual: float, cap: float) -> str:
    if cap and abs(cap) > 1e-9 and pd.notna(actual) and pd.notna(cap):
        return f"{100.0 * float(actual) / float(cap):.0f}%"
    return "—"


def _kpi(latest: pd.DataFrame, countries: list[str], class_wg: dict) -> html.Div:
    if latest is None or latest.empty:
        return html.Div("No latest site snapshot", style={"color": COLORS["text_muted"]})
    sub = latest[latest["country"].isin(countries)] if "country" in latest.columns else latest
    inj = float(pd.to_numeric(sub["inj"], errors="coerce").sum()) if "inj" in sub.columns else 0.0
    wdr = float(pd.to_numeric(sub["wdr"], errors="coerce").sum()) if "wdr" in sub.columns else 0.0
    stock = float(pd.to_numeric(sub["stock"], errors="coerce").sum()) if "stock" in sub.columns else 0.0
    capa = float(pd.to_numeric(sub["capacity"], errors="coerce").sum()) if "capacity" in sub.columns else 0.0
    actual_inj = (
        float(pd.to_numeric(sub["actual_inj"], errors="coerce").sum())
        if "actual_inj" in sub.columns
        else float("nan")
    )
    actual_wdr = (
        float(pd.to_numeric(sub["actual_wdr"], errors="coerce").sum())
        if "actual_wdr" in sub.columns
        else float("nan")
    )
    fill = (100.0 * stock / capa) if capa else 0.0
    as_of = pd.to_datetime(sub["as_of"], errors="coerce").min() if "as_of" in sub.columns else None
    as_of_s = pd.Timestamp(as_of).strftime("%d-%b-%Y") if pd.notna(as_of) else "—"
    wg = class_wg or {}
    total_wg = sum(float(v or 0) for v in wg.values()) or 1.0
    mix = " · ".join(
        f"{k} {100.0 * float(wg.get(k) or 0) / total_wg:.0f}%"
        for k in ("SRS", "MRS", "LRS")
    )
    return html.Div(
        [
            html.Div(
                f"As of {as_of_s} · {', '.join(countries)}",
                style={"fontSize": "12px", "color": COLORS["text_muted"], "marginBottom": "8px"},
            ),
            html.Div(
                style={"display": "flex", "flexWrap": "wrap", "gap": "24px"},
                children=[
                    _metric("Injectability", f"{inj:.0f} mcm/d"),
                    _metric("Withdrawability", f"{wdr:.0f} mcm/d"),
                    _metric("Inj vs max", _util_label(actual_inj, inj)),
                    _metric("Wdr vs max", _util_label(actual_wdr, wdr)),
                    _metric("Fill", f"{fill:.1f}%"),
                    _metric("Working gas mix", mix),
                ],
            ),
        ]
    )


def _metric(label: str, value: str) -> html.Div:
    return html.Div(
        [
            html.Div(label, style={"fontSize": "11px", "color": COLORS["text_muted"], "fontWeight": "600"}),
            html.Div(value, style={"fontSize": "18px", "fontWeight": "600", "color": COLORS["text_primary"]}),
        ]
    )


def _chart_block(fig, title: str) -> html.Div:
    height = int(getattr(fig.layout, "height", None) or 560)
    return html.Div(
        [
            html.Div(
                title,
                style={
                    "fontSize": "14px",
                    "fontWeight": "600",
                    "color": COLORS["text_primary"],
                    "textTransform": "uppercase",
                    "letterSpacing": "0.4px",
                    "padding": "4px 4px 0 4px",
                },
            ),
            dcc.Graph(
                figure=fig,
                config={"displaylogo": False, "responsive": True},
                responsive=True,
                style={"width": "100%", "height": f"{height}px"},
            ),
        ],
        style={
            "backgroundColor": COLORS["card_bg"],
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "12px",
            "marginBottom": "16px",
            "padding": "8px 8px 0 8px",
        },
    )


@callback(
    Output("gas-inj-wdr-blurb", "children"),
    Output("gas-inj-wdr-kpi", "children"),
    Output("gas-inj-wdr-charts", "children"),
    Output("gas-inj-wdr-status", "children"),
    Input("gas-inj-wdr-refresh", "n_clicks"),
    Input("gas-inj-wdr-countries", "value"),
    Input("gas-inj-wdr-view", "value"),
    Input("gas-inj-wdr-overlay", "value"),
    prevent_initial_call=False,
)
def update_inj_wdr(_n_clicks, countries_value, view_value, overlay_value):
    countries = parse_countries(countries_value)
    mode = view_value if view_value in (VIEW_MCM, VIEW_PCT) else VIEW_MCM
    overlay = mode == VIEW_MCM and "actual" in (overlay_value or [])
    lead = "Withdrawability" if withdraw_first() else "Injectability"
    blurb = (
        "Max injectable / withdrawable gas given current site fills "
        f"(sum of site curves). Overlay actual CE flows, or switch to % of max "
        f"to spot days at or above the modelled cap. {lead} is shown first this season."
    )
    try:
        payload = get_cached_payload()
    except Exception as exc:
        logger.exception("inj/wdr cache")
        err = _alert(str(exc), "error")
        return blurb, err, err, err

    if payload.get("error"):
        err = _alert(str(payload["error"]), "error")
        return blurb, err, err, err

    inj = payload.get("injectability")
    wdr = payload.get("withdrawability")
    actual_inj = payload.get("actual_injection")
    actual_wdr = payload.get("actual_withdrawal")
    latest = _as_frame(payload.get("latest_sites"))
    class_wg = payload.get("class_working_gas_mcm") or {}

    inj_fig = build_capability_chart(
        inj,
        "Injectability",
        "mcm/d",
        countries,
        actual=actual_inj if overlay or mode == VIEW_PCT else None,
        mode=mode,
    )
    wdr_fig = build_capability_chart(
        wdr,
        "Withdrawability",
        "mcm/d",
        countries,
        color=COLORS["chart_tertiary"],
        actual=actual_wdr if overlay or mode == VIEW_PCT else None,
        mode=mode,
    )
    inj_title = "Injectability % of max" if mode == VIEW_PCT else "Injectability"
    wdr_title = "Withdrawability % of max" if mode == VIEW_PCT else "Withdrawability"
    inj_block = _chart_block(inj_fig, inj_title)
    wdr_block = _chart_block(wdr_fig, wdr_title)
    charts = [wdr_block, inj_block] if withdraw_first() else [inj_block, wdr_block]

    n_sites = payload.get("n_with_ts") or 0
    fetched = payload.get("fetched_at")
    fetched_s = ""
    if fetched:
        try:
            fetched_s = pd.Timestamp(fetched).strftime("%d-%b %H:%M")
        except Exception:
            fetched_s = str(fetched)
    complete_map = payload.get("last_complete") or {}
    complete_dates = [
        pd.Timestamp(complete_map[c]) for c in countries if c in complete_map
    ]
    complete_s = ""
    if complete_dates:
        complete_s = pd.Timestamp(min(complete_dates)).strftime("%d-%b-%Y")
    status_txt = f"{n_sites} sites"
    if complete_s:
        status_txt += f" · complete through {complete_s}"
    if fetched_s:
        status_txt += f" · cache {fetched_s}"
    status = _alert(status_txt, "success")
    kpi = _kpi(latest, countries, class_wg)
    return blurb, kpi, charts, status
