"""Layout for Injectability / Withdrawability."""
from __future__ import annotations

from dash import dcc, html

from core.gas_inj_wdr.constants import (
    DEFAULT_MULTI_COUNTRIES,
    MULTI_COUNTRY_OPTIONS,
    PAGE_NAME,
    VIEW_MCM,
    VIEW_OPTIONS,
    withdraw_first,
)
from core.styles import COLORS

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}
_CONTROL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "display": "flex",
    "alignItems": "center",
    "flexWrap": "wrap",
    "gap": "16px",
}
_BTN = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
}
_CONTENT = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "marginBottom": "16px",
    "padding": "12px 16px 8px 16px",
}
_RADIO = {"fontSize": "13px", "color": COLORS["text_primary"]}
_RADIO_LABEL = {"marginRight": "14px", "cursor": "pointer"}


def build_layout() -> html.Div:
    lead = "Withdrawability" if withdraw_first() else "Injectability"
    return html.Div(
        style={"minHeight": "100vh", "backgroundColor": COLORS["background"], "padding": "20px"},
        children=[
            html.Div(
                [
                    html.H1(
                        PAGE_NAME,
                        style={
                            "fontSize": "22px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "margin": "0 0 4px 0",
                        },
                    ),
                    html.P(
                        id="gas-inj-wdr-blurb",
                        children=(
                            "Max injectable / withdrawable gas given current site fills "
                            f"(site curves summed). Overlay actual CE flows, or switch to "
                            f"% of max to spot days at or above the modelled cap. "
                            f"{lead} is shown first this season."
                        ),
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 20px 0",
                        },
                    ),
                ]
            ),
            html.Div(
                style=_CONTROL,
                children=[
                    html.Button("Refresh", id="gas-inj-wdr-refresh", n_clicks=0, style=_BTN),
                    html.Div(
                        [
                            html.Label("Countries", style=_LABEL),
                            html.Div(
                                dcc.Dropdown(
                                    id="gas-inj-wdr-countries",
                                    options=MULTI_COUNTRY_OPTIONS,
                                    value=DEFAULT_MULTI_COUNTRIES,
                                    multi=True,
                                    placeholder="Select countries…",
                                    style={"fontSize": "13px"},
                                ),
                                style={"width": "420px", "minWidth": "240px"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Label("View", style=_LABEL),
                            dcc.RadioItems(
                                id="gas-inj-wdr-view",
                                options=VIEW_OPTIONS,
                                value=VIEW_MCM,
                                inline=True,
                                style=_RADIO,
                                labelStyle=_RADIO_LABEL,
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Label("Series", style=_LABEL),
                            dcc.Checklist(
                                id="gas-inj-wdr-overlay",
                                options=[{"label": "Overlay actuals", "value": "actual"}],
                                value=[],
                                inline=True,
                                style=_RADIO,
                                labelStyle=_RADIO_LABEL,
                            ),
                        ]
                    ),
                    html.Div(id="gas-inj-wdr-status"),
                ],
            ),
            html.Div(id="gas-inj-wdr-kpi", style=_CONTENT),
            html.Div(id="gas-inj-wdr-charts"),
        ],
    )
