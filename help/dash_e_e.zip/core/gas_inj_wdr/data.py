"""Injectability / withdrawability capability cache and aggregates."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

from core.cache import dashboard_cache
from core.gas_inj_wdr.constants import (
    COUNTRY_CODES,
    DEFAULT_MULTI_COUNTRIES,
    HISTORY_START_YEAR,
    SOURCE_NAME,
)
from jain_commods.fundamental.gas.storage_params import (
    CLASS_LRS,
    CLASS_MRS,
    CLASS_SRS,
    StorageParamsTableMissing,
    capability_from_fill,
    list_storage_sites,
    load_latest_params,
    load_sites_timeseries,
)

logger = logging.getLogger(__name__)

LOGINTYPE = "prod"


def parse_countries(value: list[str] | str | None) -> list[str]:
    if isinstance(value, str):
        value = [value]
    codes = [c for c in (value or []) if c in COUNTRY_CODES]
    if not codes:
        codes = list(DEFAULT_MULTI_COUNTRIES)
    return [c for c in COUNTRY_CODES if c in codes]


def _site_fill(df: pd.DataFrame) -> pd.Series:
    work = df.copy()
    work.columns = [str(c).lower() for c in work.columns]
    if "stock" not in work.columns:
        return pd.Series(dtype=float)
    capa = None
    for col in ("stockcapacity", "stock_capacity"):
        if col in work.columns:
            capa = pd.to_numeric(work[col], errors="coerce")
            break
    if capa is None:
        return pd.Series(dtype=float)
    stock = pd.to_numeric(work["stock"], errors="coerce")
    fill = np.where(capa > 0, stock / capa, np.nan)
    return pd.Series(fill, index=work.index, name="fill")


# Sites whose last observation is more than this far before the country's
# median end date are treated as inactive and do not delay the cutoff.
_INACTIVE_SITE_DAYS = 21


def _site_flow(df: pd.DataFrame, *names: str) -> pd.Series:
    cols = {str(c).lower(): c for c in df.columns}
    for name in names:
        if name in cols:
            return pd.to_numeric(df[cols[name]], errors="coerce")
    return pd.Series(np.nan, index=df.index)


def site_frame(parts: list[pd.Series]) -> pd.DataFrame:
    if not parts:
        return pd.DataFrame()
    frame = pd.concat(parts, axis=1)
    frame.columns = pd.MultiIndex.from_tuples(frame.columns, names=["country", "data_id"])
    frame.index = pd.to_datetime(frame.index)
    return frame.sort_index()


def last_complete_by_country(
    frame: pd.DataFrame,
    inactive_days: int = _INACTIVE_SITE_DAYS,
) -> dict[str, pd.Timestamp]:
    """Last date where every *active* site in a country still has a value.

    CE often returns a few days of nominations for a subset of sites. Those
    extra days must not be summed. Sites that stopped reporting well before
    the rest of the country are ignored so they do not pin history to an
    old date.
    """
    if frame is None or frame.empty:
        return {}
    work = frame
    if not isinstance(work.columns, pd.MultiIndex):
        work = work.copy()
        work.columns = pd.MultiIndex.from_tuples(
            [("UNK", c) for c in work.columns],
            names=["country", "data_id"],
        )
    out: dict[str, pd.Timestamp] = {}
    slack = pd.Timedelta(days=int(inactive_days))
    for country, block in work.T.groupby(level="country"):
        wide = block.T
        last_valid = pd.to_datetime(wide.apply(lambda s: s.last_valid_index())).dropna()
        if last_valid.empty:
            continue
        median_end = last_valid.median()
        active = last_valid[last_valid >= median_end - slack]
        if active.empty:
            active = last_valid
        out[str(country)] = pd.Timestamp(active.min()).normalize()
    return out


def apply_complete_cutoff(
    by_country: pd.DataFrame,
    cutoffs: dict[str, pd.Timestamp] | None,
) -> pd.DataFrame:
    if by_country is None or by_country.empty or not cutoffs:
        return by_country
    out = by_country.copy()
    out.index = pd.to_datetime(out.index)
    for country, cutoff in cutoffs.items():
        if country not in out.columns:
            continue
        out.loc[out.index > cutoff, country] = np.nan
    if "Total" in out.columns:
        total_cut = min(cutoffs.values())
        out.loc[out.index > total_cut, "Total"] = np.nan
    nonempty = out.dropna(how="all")
    if nonempty.empty:
        return out.iloc[0:0]
    return out.loc[: nonempty.index.max()]


def sum_by_country(
    parts: list[pd.Series],
    cutoffs: dict[str, pd.Timestamp] | None = None,
) -> pd.DataFrame:
    frame = site_frame(parts)
    if frame.empty:
        return pd.DataFrame()
    by_country = frame.T.groupby(level="country").sum(min_count=1).T
    ordered = [c for c in COUNTRY_CODES if c in by_country.columns]
    by_country = by_country[ordered]
    by_country["Total"] = by_country.sum(axis=1, min_count=1)
    if cutoffs is None:
        cutoffs = last_complete_by_country(frame)
    return apply_complete_cutoff(by_country.sort_index(), cutoffs)


def _ts_value(ts: pd.DataFrame, as_of, *names: str) -> float:
    if ts is None or ts.empty or as_of is None or as_of not in ts.index:
        return np.nan
    cols = {str(c).lower(): c for c in ts.columns}
    for name in names:
        if name in cols:
            return float(pd.to_numeric(ts.loc[as_of, cols[name]], errors="coerce"))
    return np.nan


def _series_value(series: pd.Series, as_of) -> float:
    if series is None or series.empty or as_of is None or as_of not in series.index:
        return np.nan
    val = series.loc[as_of]
    if isinstance(val, pd.Series):
        val = val.iloc[-1]
    return float(pd.to_numeric(val, errors="coerce"))


def utilisation_pct(actual: pd.DataFrame, capability: pd.DataFrame) -> pd.DataFrame:
    """Actual flow as a % of modelled max (100 = at the cap)."""
    if actual is None or actual.empty or capability is None or capability.empty:
        return pd.DataFrame()
    cap = capability.copy()
    cap = cap.where(cap.abs() > 1e-9)
    aligned = actual.reindex(index=cap.index, columns=cap.columns)
    return 100.0 * aligned / cap


def params_for_catalog(params: pd.DataFrame, sites: pd.DataFrame) -> pd.DataFrame:
    """Keep only v2 rows that belong to the current CE level-2 catalog."""
    if params is None or params.empty:
        return pd.DataFrame()
    work = params.dropna(subset=["data_id"]).copy()
    if work.empty:
        return work
    work["data_id"] = pd.to_numeric(work["data_id"], errors="coerce")
    work = work.dropna(subset=["data_id"])
    work["data_id"] = work["data_id"].astype(int)
    if sites is None or sites.empty:
        return work.iloc[0:0]
    catalog = sites.dropna(subset=["data_id"]).copy()
    catalog["data_id"] = pd.to_numeric(catalog["data_id"], errors="coerce")
    catalog = catalog.dropna(subset=["data_id"])
    catalog["data_id"] = catalog["data_id"].astype(int)
    keep_cols = [c for c in ("data_id", "country", "site_name") if c in catalog.columns]
    merged = work.merge(
        catalog[keep_cols],
        on="data_id",
        how="inner",
        suffixes=("", "_cat"),
    )
    if "country_cat" in merged.columns:
        merged["country"] = merged["country"].fillna(merged["country_cat"])
    if "site_name_cat" in merged.columns:
        merged["site_name"] = merged["site_name"].fillna(merged["site_name_cat"])
    return merged


def load_inj_wdr_capability() -> dict[str, Any]:
    """Dashboard cache loader: site-level capability summed to countries."""
    fetched_at = datetime.now(timezone.utc)
    try:
        sites = list_storage_sites(logintype=LOGINTYPE)
        params = load_latest_params(logintype=LOGINTYPE)
    except StorageParamsTableMissing as exc:
        return {"error": str(exc), "fetched_at": fetched_at.isoformat()}
    except Exception as exc:
        logger.exception("inj/wdr catalog/params failed")
        return {"error": str(exc), "fetched_at": fetched_at.isoformat()}

    if params is None or params.empty:
        return {
            "error": "No rows in eu_storage_modelling_v2. Materialize the Dagster fit job.",
            "fetched_at": fetched_at.isoformat(),
        }

    params = params_for_catalog(params, sites)
    if params.empty:
        return {
            "error": "No level-2 catalog sites have v2 params yet. Materialize the Dagster fit job.",
            "fetched_at": fetched_at.isoformat(),
        }

    data_ids = [int(x) for x in params["data_id"].tolist()]
    start = datetime(HISTORY_START_YEAR, 1, 1)
    try:
        ts_map = load_sites_timeseries(data_ids, start_date=start, logintype=LOGINTYPE)
    except Exception as exc:
        logger.exception("inj/wdr timeseries failed")
        return {"error": str(exc), "fetched_at": fetched_at.isoformat()}

    inj_parts: list[pd.Series] = []
    wdr_parts: list[pd.Series] = []
    actual_inj_parts: list[pd.Series] = []
    actual_wdr_parts: list[pd.Series] = []
    built: list[dict[str, Any]] = []

    for _, prow in params.iterrows():
        did = int(prow["data_id"])
        ts = ts_map.get(did)
        if ts is None or ts.empty:
            continue
        fill = _site_fill(ts)
        if fill.empty:
            continue
        inj, wdr = capability_from_fill(
            fill.to_numpy(),
            float(prow["p_inj"]),
            float(prow["q_wdr"]),
            float(prow["max_inj"]),
            float(prow["max_wdr"]),
            prow.get("max_inj_cap"),
            prow.get("max_wdr_cap"),
        )
        country = str(prow.get("country") or "")
        inj_s = pd.Series(inj, index=fill.index, name=(country, did))
        wdr_s = pd.Series(wdr, index=fill.index, name=(country, did))
        inj_parts.append(inj_s)
        wdr_parts.append(wdr_s)
        actual_inj_parts.append(
            _site_flow(ts, "injection").reindex(fill.index).rename((country, did))
        )
        actual_wdr_parts.append(
            _site_flow(ts, "withdrawal").reindex(fill.index).rename((country, did))
        )
        built.append(
            {
                "prow": prow,
                "ts": ts,
                "inj_s": inj_s,
                "wdr_s": wdr_s,
                "country": country,
                "did": did,
            }
        )

    cutoffs = last_complete_by_country(site_frame(inj_parts))
    inj_df = sum_by_country(inj_parts, cutoffs=cutoffs)
    wdr_df = sum_by_country(wdr_parts, cutoffs=cutoffs)
    actual_inj_df = sum_by_country(actual_inj_parts, cutoffs=cutoffs)
    actual_wdr_df = sum_by_country(actual_wdr_parts, cutoffs=cutoffs)

    latest_rows = []
    class_wg = {CLASS_SRS: 0.0, CLASS_MRS: 0.0, CLASS_LRS: 0.0}
    for item in built:
        country = item["country"]
        inj_s = item["inj_s"]
        cutoff = cutoffs.get(country)
        as_of = inj_s.last_valid_index()
        if cutoff is not None:
            as_of = inj_s.loc[:cutoff].last_valid_index()
        if as_of is None:
            continue
        ts = item["ts"]
        prow = item["prow"]
        capa = _ts_value(ts, as_of, "stockcapacity", "stock_capacity")
        cls = str(prow.get("classification") or CLASS_MRS)
        if cls in class_wg and np.isfinite(capa):
            class_wg[cls] += capa
        latest_rows.append(
            {
                "country": country,
                "data_id": item["did"],
                "classification": cls,
                "inj": _series_value(inj_s, as_of),
                "wdr": _series_value(item["wdr_s"], as_of),
                "actual_inj": _ts_value(ts, as_of, "injection"),
                "actual_wdr": _ts_value(ts, as_of, "withdrawal"),
                "stock": _ts_value(ts, as_of, "stock"),
                "capacity": capa,
                "as_of": as_of,
            }
        )

    latest = pd.DataFrame(latest_rows)
    return {
        "injectability": inj_df,
        "withdrawability": wdr_df,
        "actual_injection": actual_inj_df,
        "actual_withdrawal": actual_wdr_df,
        "latest_sites": latest,
        "class_working_gas_mcm": class_wg,
        "last_complete": {c: ts.isoformat() for c, ts in cutoffs.items()},
        "n_sites": int(len(params)),
        "n_with_ts": int(len(inj_parts)),
        "fetched_at": fetched_at.isoformat(),
        "error": None,
    }


def get_cached_payload() -> dict[str, Any]:
    data = dashboard_cache.get_data(SOURCE_NAME)
    if not data or not isinstance(data, dict):
        raise RuntimeError(
            "Injectability / withdrawability cache is empty. "
            "Wait for warm-up, or check eu_storage_modelling_v2."
        )
    return data
