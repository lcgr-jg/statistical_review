"""EU Gas Balance — Injectability / Withdrawability constants."""
from __future__ import annotations

from datetime import date

from core.gas_storage_summary.constants import (
    COUNTRY_CODES,
    COUNTRY_COLORS,
    DEFAULT_MULTI_COUNTRIES,
    MULTI_COUNTRY_OPTIONS,
    resolve_chart_countries,
)

PAGE_PATH = "/power/gas_balance/inj_wdr"
PAGE_NAME = "Injectability / Withdrawability"
PAGE_TITLE = "EU Gas Injectability / Withdrawability | JG Power Dashboard"
PAGE_ORDER = 74

SOURCE_NAME = "gas_inj_wdr"
CRON = "15 6,8,12,16 * * *"
CRON_TIMEZONE = "Europe/London"
TTL_SECONDS = 12 * 60 * 60
HISTORY_START_YEAR = 2018
VIEW_MCM = "mcm"
VIEW_PCT = "pct"
VIEW_OPTIONS = [
    {"label": "mcm/d", "value": VIEW_MCM},
    {"label": "% of max", "value": VIEW_PCT},
]


def withdraw_first(today: date | None = None) -> bool:
    """True in Nov–Mar so winter withdrawability is the lead chart."""
    today = today or date.today()
    return today.month >= 11 or today.month <= 3


__all__ = [
    "COUNTRY_CODES",
    "COUNTRY_COLORS",
    "CRON",
    "CRON_TIMEZONE",
    "DEFAULT_MULTI_COUNTRIES",
    "HISTORY_START_YEAR",
    "MULTI_COUNTRY_OPTIONS",
    "PAGE_NAME",
    "PAGE_ORDER",
    "PAGE_PATH",
    "PAGE_TITLE",
    "SOURCE_NAME",
    "TTL_SECONDS",
    "VIEW_MCM",
    "VIEW_OPTIONS",
    "VIEW_PCT",
    "resolve_chart_countries",
    "withdraw_first",
]
