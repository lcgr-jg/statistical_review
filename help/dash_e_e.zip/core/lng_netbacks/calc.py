"""Pure netback / occupancy maths. Frame in, frame out — no Snowflake.

Ported from ``eu_reports/lng_netbacks/util.py`` (``get_freight_costs``,
``generate_netbacks``, ``build_jkm_tfu_occupancy``) and vectorized over a
``(TRADE_DATE, DELIVERY_START)`` panel so the dashboard can slice history
without looping ``get_curve``.
"""
from __future__ import annotations

import calendar
from typing import Iterable

import numpy as np
import pandas as pd

from core.lng_netbacks.constants import (
    COL_ASIA_VS_EU,
    COL_FRT_ASIA,
    COL_FRT_ATLANTIC,
    COL_FRT_NL,
    COL_FRT_PANAMA,
    COL_FRT_SK,
    COL_FRT_SUEZ,
    COL_JKM_SHIFTED,
    COL_JKM_TFU,
    COL_NL_PROFIT,
    COL_NL_TOTAL,
    COL_PANAMA_PROFIT,
    COL_PANAMA_TOTAL,
    COL_PANAMA_VS_EU,
    COL_SK_PROFIT,
    COL_SK_TOTAL,
    COL_SUEZ_PROFIT,
    COL_SUEZ_TOTAL,
    COL_SUEZ_VS_EU,
    DEFAULT_VESSEL,
    FREIGHT_CONSTANTS,
    FREIGHT_FORWARD,
    FREIGHT_SUNK,
    HH_SLOPE,
    HORIZON_MONTHS,
    OCC_BUCKET_SIZE,
    OCC_N_EXPIRED,
    OCC_N_TENORS,
    PANAMA_CANAL_FEE,
    PORT_COSTS,
    SUEZ_CANAL_FEE,
    VESSEL_SIZES,
    VOYAGES,
)


def hh_liq_col(hh_slope: float = HH_SLOPE) -> str:
    """Column name for hub gas + liquefaction, matching the email report."""
    return f"HH + {hh_slope:.2f}"


def freight_route_coeffs(
    voyage_days: float,
    port_cost: float = 0.0,
    canal_toll: float = 0.0,
    vessel_type: str = DEFAULT_VESSEL,
) -> tuple[float, float, float]:
    """Return ``(k_boiloff, k_charter, k_fixed)`` for one route.

    ``total_freight = hub_price * k_boiloff + dayrate * k_charter + k_fixed``
    in $/mmbtu, matching ``get_freight_costs`` in the email report.
    """
    fc = FREIGHT_CONSTANTS
    loaded = (
        VESSEL_SIZES[vessel_type]
        * fc["energy_content"]
        * fc["fillable_volume"]
    )
    total_days = voyage_days + fc["days_in_port"]
    total_days2 = total_days + fc["days_in_port"]

    heel_gas = loaded * total_days * fc["boiloffrate_ballast"]
    delivered = loaded * (1 - fc["boiloffrate_laden"]) ** total_days - heel_gas
    laden_boiloff = loaded - heel_gas - delivered

    bunker_qty = (
        fc["bunker_consumption_rate"] * total_days2
        - heel_gas / fc["bunker_fuel_energy_content"]
    )
    bunker_cost = bunker_qty * fc["bunker_price"] / delivered

    k_boiloff = (heel_gas + laden_boiloff) / delivered
    k_charter = 2 * total_days / delivered
    insurance = fc["insurance_usd_per_day"] * k_charter
    k_fixed = bunker_cost + insurance + canal_toll + port_cost
    return float(k_boiloff), float(k_charter), float(k_fixed)


def total_freight(
    hub_price: pd.Series,
    dayrate: pd.Series | float,
    voyage_days: float,
    port_cost: float = 0.0,
    canal_toll: float = 0.0,
    vessel_type: str = DEFAULT_VESSEL,
) -> pd.Series:
    """Vectorized $/mmbtu freight for one route."""
    k_b, k_c, k_f = freight_route_coeffs(
        voyage_days, port_cost, canal_toll, vessel_type)
    return hub_price * k_b + dayrate * k_c + k_f


_ROUTES: tuple[tuple[str, int, float, float], ...] = (
    ("us>nl", VOYAGES["us>nl"], PORT_COSTS["nl"], 0.0),
    ("us>sk", VOYAGES["us>sk"], PORT_COSTS["sk"], 0.0),
    ("us>panama>sk", VOYAGES["us>panama>sk"], PORT_COSTS["sk"], PANAMA_CANAL_FEE),
    ("us>suez>sk", VOYAGES["us>suez>sk"], PORT_COSTS["sk"], SUEZ_CANAL_FEE),
)

_ROUTE_FREIGHT_COLS = {
    "us>nl": COL_FRT_NL,
    "us>sk": COL_FRT_SK,
    "us>panama>sk": COL_FRT_PANAMA,
    "us>suez>sk": COL_FRT_SUEZ,
}


def _apply_route_freight(df: pd.DataFrame, hub, dayrate, vessel_type: str) -> None:
    for label, days, port, canal in _ROUTES:
        df[_ROUTE_FREIGHT_COLS[label]] = total_freight(
            hub, dayrate, days, port, canal, vessel_type)


def compute_netbacks(
    panel: pd.DataFrame,
    *,
    freight_mode: str = FREIGHT_FORWARD,
    hh_slope: float = HH_SLOPE,
    horizon_months: int = HORIZON_MONTHS,
    vessel_type: str = DEFAULT_VESSEL,
) -> pd.DataFrame:
    """Build route totals/profits on a ``(TRADE_DATE, DELIVERY_START)`` panel.

    ``panel`` must include ``TRADE_DATE``, ``DELIVERY_START``, ``HH``,
    ``JKM``, ``TFU``. Forward freight uses ``Spark30S`` (Atlantic, applied
    to every USGC route — same as the report). Spot freight uses
    ``platts_atlantic`` / ``platts_asia`` (day-rate per trade date).
    Sunk freight sets every route and day-rate column to zero, so netbacks
    depend only on the destination price minus HH × the liquefaction slope.

    JKM is lagged one delivery month *within each trade date* for voyage time.
    """
    if panel is None or panel.empty:
        return pd.DataFrame()

    df = panel.copy()
    df["TRADE_DATE"] = pd.to_datetime(df["TRADE_DATE"])
    df["DELIVERY_START"] = pd.to_datetime(df["DELIVERY_START"])
    df = df.sort_values(["TRADE_DATE", "DELIVERY_START"])

    horizon_days = int(horizon_months * 31)
    df = df.loc[
        df["DELIVERY_START"] <= df["TRADE_DATE"] + pd.Timedelta(days=horizon_days)
    ]
    if df.empty:
        return df

    df[COL_JKM_SHIFTED] = df.groupby("TRADE_DATE", sort=False)["JKM"].shift(-1)
    liq = hh_liq_col(hh_slope)
    df[liq] = df["HH"] * hh_slope

    if freight_mode == FREIGHT_SUNK:
        for col in (
            COL_FRT_ASIA, COL_FRT_ATLANTIC, COL_FRT_NL, COL_FRT_SK,
            COL_FRT_PANAMA, COL_FRT_SUEZ,
        ):
            df[col] = 0.0
    elif freight_mode == FREIGHT_FORWARD:
        if "Spark30S" not in df.columns or "Spark25S" not in df.columns:
            raise KeyError("Forward freight requires Spark25S and Spark30S")
        dayrate = df["Spark30S"]
        df[COL_FRT_ASIA] = df["Spark25S"]
        df[COL_FRT_ATLANTIC] = df["Spark30S"]
        _apply_route_freight(df, df[liq], dayrate, vessel_type)
    else:
        if "platts_atlantic" not in df.columns:
            raise KeyError("Spot freight requires platts_atlantic")
        dayrate = df["platts_atlantic"]
        if "platts_asia" in df.columns:
            df[COL_FRT_ASIA] = df["platts_asia"]
        else:
            df[COL_FRT_ASIA] = np.nan
        df[COL_FRT_ATLANTIC] = df["platts_atlantic"]
        _apply_route_freight(df, df[liq], dayrate, vessel_type)

    df[COL_SK_TOTAL] = df[liq] + df[COL_FRT_SK]
    df[COL_SK_PROFIT] = df[COL_JKM_SHIFTED] - df[COL_SK_TOTAL]
    df[COL_PANAMA_TOTAL] = df[liq] + df[COL_FRT_PANAMA]
    df[COL_PANAMA_PROFIT] = df[COL_JKM_SHIFTED] - df[COL_PANAMA_TOTAL]
    df[COL_SUEZ_TOTAL] = df[liq] + df[COL_FRT_SUEZ]
    df[COL_SUEZ_PROFIT] = df[COL_JKM_SHIFTED] - df[COL_SUEZ_TOTAL]
    df[COL_NL_TOTAL] = df[liq] + df[COL_FRT_NL]
    df[COL_NL_PROFIT] = df["TFU"] - df[COL_NL_TOTAL]
    df[COL_ASIA_VS_EU] = df[COL_SK_PROFIT] - df[COL_NL_PROFIT]
    df[COL_SUEZ_VS_EU] = df[COL_SUEZ_PROFIT] - df[COL_NL_PROFIT]
    df[COL_PANAMA_VS_EU] = df[COL_PANAMA_PROFIT] - df[COL_NL_PROFIT]
    df[COL_JKM_TFU] = df["JKM"] - df["TFU"]

    required = [COL_JKM_SHIFTED, "TFU", liq, COL_FRT_NL, COL_FRT_SK, COL_FRT_PANAMA]
    if freight_mode == FREIGHT_FORWARD:
        required.append("Spark30S")
    elif freight_mode != FREIGHT_SUNK:
        required.append("platts_atlantic")
    return df.dropna(subset=required).reset_index(drop=True)


def snap_to_trade_date(
    requested,
    trade_dates: Iterable,
) -> pd.Timestamp | None:
    """Last available trade date on or before *requested*. None if none exist."""
    if requested is None:
        return None
    dates = pd.DatetimeIndex(pd.to_datetime(list(trade_dates))).sort_values()
    if dates.empty:
        return None
    req = pd.Timestamp(requested).normalize()
    dates = dates.normalize()
    eligible = dates[dates <= req]
    if eligible.empty:
        return None
    return pd.Timestamp(eligible.max())


def overlay_trade_dates(
    as_of,
    trade_dates: Iterable,
    offsets: Iterable[int] = (1, 7, 14, 28),
) -> list[pd.Timestamp]:
    """Settle dates for T-* overlays, snapped onto the trade calendar."""
    as_of_ts = pd.Timestamp(as_of).normalize()
    out: list[pd.Timestamp] = []
    seen = {as_of_ts}
    for offset in offsets:
        snapped = snap_to_trade_date(as_of_ts - pd.Timedelta(days=int(offset)),
                                     trade_dates)
        if snapped is None or snapped in seen:
            continue
        seen.add(snapped)
        out.append(snapped)
    return out


def curve_on_date(panel: pd.DataFrame, trade_date) -> pd.DataFrame:
    """One settle date's forward curve, indexed by ``DELIVERY_START``."""
    if panel is None or panel.empty:
        return pd.DataFrame()
    dt = pd.Timestamp(trade_date).normalize()
    td = pd.to_datetime(panel["TRADE_DATE"]).dt.normalize()
    sl = panel.loc[td == dt].copy()
    if sl.empty:
        return sl
    sl["DELIVERY_START"] = pd.to_datetime(sl["DELIVERY_START"])
    return sl.sort_values("DELIVERY_START").set_index("DELIVERY_START")


def aggregate_curve(df: pd.DataFrame) -> pd.DataFrame:
    """Equal-weight average of a monthly delivery curve into calendar quarters.

    The index is the quarter start, so Q4 2026 is ``2026-10-01``. A quarter
    that only has one or two months uses those months.
    """
    if df is None or df.empty or not isinstance(df.index, pd.DatetimeIndex):
        return df
    idx = pd.DatetimeIndex(pd.to_datetime(df.index))
    if idx.tz is not None:
        idx = idx.tz_localize(None)
    num = df.select_dtypes(include="number")
    if num.empty:
        return df
    out = num.groupby(idx.to_period("Q"), sort=True).mean()
    out.index = pd.DatetimeIndex(out.index.to_timestamp())
    out.index.name = df.index.name
    return out


def aggregate_panel_quarters(panel: pd.DataFrame) -> pd.DataFrame:
    """One row per trade date and calendar quarter.

    Each numeric column is the equal-weight mean of the delivery months in
    that quarter.
    """
    if panel is None or panel.empty:
        return panel
    df = panel.copy()
    df["TRADE_DATE"] = pd.to_datetime(df["TRADE_DATE"])
    df["DELIVERY_START"] = pd.to_datetime(df["DELIVERY_START"])
    df["_quarter"] = df["DELIVERY_START"].dt.to_period("Q")
    num_cols = [
        c for c in df.select_dtypes(include="number").columns
        if c != "tenor_rank"
    ]
    grouped = (
        df.groupby(["TRADE_DATE", "_quarter"], sort=True)[num_cols]
        .mean()
        .reset_index()
    )
    grouped["DELIVERY_START"] = grouped["_quarter"].dt.to_timestamp()
    grouped["STRIP"] = grouped["_quarter"].map(
        lambda p: f"Q{p.quarter}-{p.year % 100:02d}"
    )
    return grouped.drop(columns=["_quarter"])


def front_month_ranks(panel: pd.DataFrame, n_tenors: int = 1) -> pd.DataFrame:
    """Keep the first *n_tenors* deliveries per trade date (0 = front)."""
    if panel is None or panel.empty:
        return pd.DataFrame()
    df = panel.copy()
    df["TRADE_DATE"] = pd.to_datetime(df["TRADE_DATE"])
    df["DELIVERY_START"] = pd.to_datetime(df["DELIVERY_START"])
    df = df.sort_values(["TRADE_DATE", "DELIVERY_START"])
    df["tenor_rank"] = df.groupby("TRADE_DATE", sort=False).cumcount()
    return df.loc[df["tenor_rank"] < int(n_tenors)].copy()


def _bucket_edges(values: pd.Series, bucket_size: float) -> np.ndarray:
    lo = np.floor(float(values.min()) / bucket_size) * bucket_size
    hi = np.ceil(float(values.max()) / bucket_size) * bucket_size
    if np.isclose(lo, hi):
        hi = lo + bucket_size
    return np.arange(lo, hi + bucket_size * 0.5, bucket_size)


def _bucket_label(left: float, right: float) -> str:
    return f"[{left:.2f}, {right:.2f}]"


def build_occupancy(
    df: pd.DataFrame,
    value_col: str,
    *,
    lookback_days: int = 90,
    bucket_size: float = OCC_BUCKET_SIZE,
    n_tenors: int = OCC_N_TENORS,
    n_expired: int = OCC_N_EXPIRED,
    as_of=None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Count days each tenor spent in each *value_col* bucket.

    Same construction as the report's JKM/TFU occupancy heatmap.
    Returns ``(occupancy, summary)``. Both empty if there is nothing to count.
    """
    empty = pd.DataFrame(), pd.DataFrame()
    if df is None or df.empty or value_col not in df.columns:
        return empty

    work = df.dropna(subset=[value_col]).copy()
    if work.empty:
        return empty

    work["TRADE_DATE"] = pd.to_datetime(work["TRADE_DATE"])
    work["DELIVERY_START"] = pd.to_datetime(work["DELIVERY_START"])
    if "STRIP" not in work.columns:
        work["STRIP"] = work["DELIVERY_START"].dt.strftime("%b%y")

    latest = (
        pd.Timestamp(as_of).normalize()
        if as_of is not None
        else work["TRADE_DATE"].max()
    )
    work = work.loc[work["TRADE_DATE"] <= latest]
    if work.empty:
        return empty

    window_start = latest - pd.Timedelta(days=int(lookback_days))
    hist_all = work.loc[work["TRADE_DATE"] >= window_start].copy()
    if hist_all.empty:
        return empty

    latest_curve = (
        hist_all.loc[hist_all["TRADE_DATE"] == hist_all["TRADE_DATE"].max()]
        .sort_values("DELIVERY_START")
        .head(int(n_tenors))
    )
    if latest_curve.empty:
        return empty

    active = latest_curve[["STRIP", "DELIVERY_START"]].drop_duplicates()
    front_delivery = active["DELIVERY_START"].min()

    expired = (
        hist_all.loc[hist_all["DELIVERY_START"] < front_delivery]
        .groupby("STRIP", as_index=False)
        .agg(DELIVERY_START=("DELIVERY_START", "first"))
        .sort_values("DELIVERY_START", ascending=False)
        .head(int(n_expired))
        .sort_values("DELIVERY_START")
    )

    tenors = pd.concat([expired, active], ignore_index=True)
    tenors["expired"] = tenors["STRIP"].isin(set(expired["STRIP"]))
    hist = hist_all.loc[hist_all["STRIP"].isin(tenors["STRIP"])].copy()
    if hist.empty:
        return empty

    edges = _bucket_edges(hist[value_col], bucket_size)
    labels = [_bucket_label(edges[i], edges[i + 1]) for i in range(len(edges) - 1)]
    hist["bucket"] = pd.cut(
        hist[value_col],
        bins=edges,
        labels=labels,
        right=False,
        include_lowest=True,
    )

    counts = (
        hist.groupby(["STRIP", "bucket"], observed=False)
        .size()
        .unstack(fill_value=0)
        .reindex(columns=labels, fill_value=0)
    )

    tenor_order = tenors.set_index("STRIP")["DELIVERY_START"]
    expired_flag = tenors.set_index("STRIP")["expired"]
    counts = counts.reindex(tenor_order.index).fillna(0).astype(int)
    counts.index = [pd.Timestamp(d).strftime("%b-%y") for d in tenor_order.values]
    counts.index.name = "TENOR"
    counts.columns.name = f"{value_col} bucket ($/mmbtu)"

    summary = (
        hist.groupby("STRIP")
        .agg(
            n_obs=(value_col, "size"),
            mean=(value_col, "mean"),
            min=(value_col, "min"),
            max=(value_col, "max"),
        )
        .reindex(tenor_order.index)
    )
    last_settle = (
        hist.sort_values("TRADE_DATE")
        .groupby("STRIP")
        .tail(1)
        .set_index("STRIP")[value_col]
    )
    summary.insert(0, "DELIVERY_START", tenor_order.values)
    summary.insert(1, "expired", expired_flag.reindex(tenor_order.index).astype(bool).values)
    summary.insert(2, "latest", last_settle.reindex(tenor_order.index).values)
    summary["latest_bucket"] = pd.cut(
        summary["latest"],
        bins=edges,
        labels=labels,
        right=False,
        include_lowest=True,
    ).astype(str)
    summary.index = counts.index
    summary.index.name = "TENOR"
    return counts, summary


def _days_in_month(dt) -> int:
    ts = pd.Timestamp(dt)
    return calendar.monthrange(ts.year, ts.month)[1]


def _weighted_avg(values, dates) -> float:
    weights = np.array([_days_in_month(d) for d in dates], dtype=float)
    vals = np.array(values, dtype=float)
    mask = ~np.isnan(vals)
    if mask.sum() == 0:
        return float("nan")
    return float(np.dot(vals[mask], weights[mask]) / weights[mask].sum())


def _quarter_num(month: int) -> int:
    return (month - 1) // 3 + 1


def _winter_months(win_yr: int) -> list[tuple[int, int]]:
    return ([(win_yr, m) for m in (10, 11, 12)]
            + [(win_yr + 1, m) for m in (1, 2, 3)])


def aggregate_jkm_tfu(df_nb: pd.DataFrame, settle_dt) -> dict[str, float]:
    """Front 6 months + 3 quarters + 2 seasons + 1 calendar of JKM/TFU.

    *df_nb* is indexed by ``DELIVERY_START`` (a single settle-date curve).
    """
    if df_nb is None or df_nb.empty or COL_JKM_TFU not in df_nb.columns:
        return {}
    jkm_tfu = df_nb[COL_JKM_TFU]
    dates = list(pd.to_datetime(df_nb.index))
    settle = pd.Timestamp(settle_dt)
    today_year, today_month = settle.year, settle.month
    rows: dict[str, float] = {}

    for dt in dates[:6]:
        rows[pd.Timestamp(dt).strftime("%b-%y")] = float(jkm_tfu.loc[dt])

    cur_q = _quarter_num(today_month)
    front_q, front_q_yr = cur_q + 1, today_year
    if front_q > 4:
        front_q, front_q_yr = 1, today_year + 1

    quarters_added = 0
    q, q_yr = front_q, front_q_yr
    while quarters_added < 3:
        q_dates = [d for d in dates
                   if d.year == q_yr and _quarter_num(d.month) == q]
        if q_dates:
            rows[f"Q{q}-{str(q_yr)[2:]}"] = _weighted_avg(
                [jkm_tfu.loc[d] for d in q_dates], q_dates)
            quarters_added += 1
        q += 1
        if q > 4:
            q, q_yr = 1, q_yr + 1
        if q_yr > today_year + 8:
            break

    if today_month < 4:
        s_name, s_yr = "Sum", today_year
    elif today_month < 10:
        s_name, s_yr = "Win", today_year
    else:
        s_name, s_yr = "Sum", today_year + 1

    seasons_added = 0
    while seasons_added < 2:
        if s_name == "Sum":
            s_dates = [d for d in dates if d.year == s_yr and 4 <= d.month <= 9]
            label = f"Sum-{str(s_yr)[2:]}"
            next_season = ("Win", s_yr)
        else:
            wm = _winter_months(s_yr)
            s_dates = [d for d in dates if (d.year, d.month) in wm]
            label = f"Win-{str(s_yr)[2:]}"
            next_season = ("Sum", s_yr + 1)
        if s_dates:
            rows[label] = _weighted_avg([jkm_tfu.loc[d] for d in s_dates], s_dates)
            seasons_added += 1
        s_name, s_yr = next_season
        if s_yr > today_year + 8:
            break

    yr = today_year + 1
    for _ in range(4):
        cal_dates = [d for d in dates if d.year == yr]
        if cal_dates:
            rows[f"Cal-{str(yr)[2:]}"] = _weighted_avg(
                [jkm_tfu.loc[d] for d in cal_dates], cal_dates)
            break
        yr += 1
    return rows


def build_jkm_tfu_table(
    snapshots: dict,
) -> pd.DataFrame:
    """Latest JKM/TFU structure plus deltas vs overlay dates.

    *snapshots* maps settle date → curve DataFrame (DELIVERY_START index).
    """
    if not snapshots:
        return pd.DataFrame()
    sorted_dates = sorted(snapshots.keys(), reverse=True)
    settle_date = sorted_dates[0]
    latest_rows = aggregate_jkm_tfu(snapshots[settle_date], settle_date)
    out = pd.DataFrame({pd.Timestamp(settle_date).strftime("%d %b"): latest_rows})
    for d in sorted_dates[1:]:
        hist = pd.Series(aggregate_jkm_tfu(snapshots[d], d))
        out[f"vs {pd.Timestamp(d).strftime('%d %b')}"] = out.iloc[:, 0] - hist
    return out
