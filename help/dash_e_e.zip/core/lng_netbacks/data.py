"""LNG Netbacks cache loader and payload slicing.

``load_lng_netbacks_data`` is the scheduler loader: one ICE strip pull plus
one Platts LNG spot pull, then vectorized netbacks for Spark-forward and
Platts-spot freight. Callbacks only slice the cached panels.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

import pandas as pd

from core.cache import dashboard_cache
from core.data_freshness import tracker
from core.lng_netbacks.calc import (
    compute_netbacks,
    curve_on_date,
    overlay_trade_dates,
    snap_to_trade_date,
)
from core.lng_netbacks.constants import (
    DEFAULT_HISTORY_START_YEAR,
    FRESHNESS_EXPECTED_MINUTES,
    FRESHNESS_SOURCE_NAME,
    FREIGHT_FORWARD,
    FREIGHT_SPOT,
    FREIGHT_SUNK,
    HISTORY_START_YEAR,
    HH_SLOPE,
    HORIZON_MONTHS,
    ICE_PRODUCTS,
    OVERLAY_OFFSETS,
    PLATTS_ASIA,
    PLATTS_ATLANTIC,
    PLATTS_SPOT_COLS,
    SOURCE_NAME,
    SPOT_FREIGHT_START,
    SPOT_FREIGHT_SYMBOLS,
)

logger = logging.getLogger(__name__)


def _register_freshness(
    *,
    state: str | None = None,
    error: str | None = None,
    detail: str | None = None,
    as_of: str | None = None,
    n_rows: int | None = None,
) -> None:
    metadata: dict[str, Any] = {}
    if state:
        metadata["state"] = state
    if error:
        metadata["error"] = error
    if detail:
        metadata["detail"] = detail
    if as_of:
        metadata["as_of"] = as_of
    if n_rows is not None:
        metadata["rows"] = n_rows
    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata=metadata,
    )


def mark_lng_netbacks_freshness_pending(
    detail: str = "waiting for warm-up",
) -> None:
    """Show LNG Netbacks in Data Source Status before the first fetch."""
    try:
        cached = dashboard_cache.get(f"source:{SOURCE_NAME}")
        if cached is not None:
            detail = "serving disk cache · refresh in progress"
    except Exception:
        pass
    _register_freshness(state="pending", detail=detail)


def _monthly_strips(df: pd.DataFrame) -> pd.DataFrame:
    """Keep monthly strips (drop Q/Sum/Cal names that contain a hyphen)."""
    if df.empty:
        return df
    out = df.copy()
    out = out.loc[~out["STRIP"].astype(str).str.contains("-", regex=False)]
    if "STRIP_TYPE" in out.columns:
        out = out.loc[out["STRIP_TYPE"] == "Month"]
    return out


def pivot_ice_strips(df: pd.DataFrame) -> pd.DataFrame:
    """Long ICE settles → one row per (TRADE_DATE, STRIP, DELIVERY_START)."""
    if df is None or df.empty:
        return pd.DataFrame()
    monthly = _monthly_strips(df)
    if monthly.empty:
        return pd.DataFrame()
    monthly = monthly.copy()
    monthly["TRADE_DATE"] = pd.to_datetime(monthly["TRADE_DATE"]).dt.normalize()
    monthly["DELIVERY_START"] = pd.to_datetime(monthly["DELIVERY_START"])
    pivoted = (
        monthly.pivot_table(
            index=["TRADE_DATE", "STRIP", "DELIVERY_START"],
            columns="COMMODITY",
            values="SETTLEMENT_PRICE",
            aggfunc="first",
        )
        .reset_index()
    )
    pivoted.columns.name = None
    return pivoted


def pivot_platts_spot(df: pd.DataFrame) -> pd.DataFrame:
    """Platts long frame → daily columns for freight + LNG spot markers."""
    if df is None or df.empty:
        return pd.DataFrame()
    keep = df.loc[df["DESCRIPTION"].isin(PLATTS_SPOT_COLS)].copy()
    if keep.empty:
        return pd.DataFrame()
    keep["ASSESSDATE"] = pd.to_datetime(keep["ASSESSDATE"])
    spot = keep.pivot_table(
        index="ASSESSDATE",
        columns="DESCRIPTION",
        values="VALUE",
        aggfunc="first",
    ).sort_index()
    spot.columns.name = None
    return spot


def extend_spot_freight(platts: pd.DataFrame, raw_freight: pd.DataFrame) -> pd.DataFrame:
    """Replace the two carrier-rate columns with the longer freight pull."""
    long = pivot_platts_spot(raw_freight)
    if long.empty:
        return platts
    if platts is None or platts.empty:
        return long
    out = platts.reindex(platts.index.union(long.index)).sort_index()
    for col in (PLATTS_ASIA, PLATTS_ATLANTIC):
        if col in long.columns:
            out[col] = long[col].combine_first(out[col])
    return out


def attach_spot_freight(ice_panel: pd.DataFrame, platts: pd.DataFrame) -> pd.DataFrame:
    """Map last-available Platts day rates onto each ICE trade date."""
    if ice_panel.empty:
        return ice_panel
    out = ice_panel.copy()
    out["TRADE_DATE"] = pd.to_datetime(out["TRADE_DATE"]).dt.normalize()
    if platts is None or platts.empty:
        out["platts_asia"] = float("nan")
        out["platts_atlantic"] = float("nan")
        return out

    daily = pd.DataFrame(index=platts.index)
    daily["platts_asia"] = platts[PLATTS_ASIA] if PLATTS_ASIA in platts.columns else float("nan")
    daily["platts_atlantic"] = (
        platts[PLATTS_ATLANTIC] if PLATTS_ATLANTIC in platts.columns else float("nan")
    )
    daily.index = pd.to_datetime(daily.index).normalize()
    daily = daily.sort_index()

    trade_dates = pd.DatetimeIndex(out["TRADE_DATE"].unique()).sort_values()
    union = daily.reindex(daily.index.union(trade_dates)).sort_index().ffill()
    aligned = union.reindex(trade_dates)
    out["platts_asia"] = out["TRADE_DATE"].map(aligned["platts_asia"])
    out["platts_atlantic"] = out["TRADE_DATE"].map(aligned["platts_atlantic"])
    return out


def load_lng_netbacks_data() -> dict[str, Any]:
    """Loader for ``dashboard_cache.register_source('lng_netbacks_data', ...)``."""
    from jain_commods.core.interfaces.snowflake import ICEFuturesQuery, PlattsQuery

    _register_freshness(state="loading")

    today = datetime.now()
    start = datetime(HISTORY_START_YEAR, 1, 1)

    ice = ICEFuturesQuery()
    raw = ice.get_strip_prices(
        product=list(ICE_PRODUCTS),
        start_date=start,
    )
    if raw is None or raw.empty:
        raise RuntimeError("LNG netbacks: no ICE strip prices returned")

    ice_panel = pivot_ice_strips(raw)
    if ice_panel.empty:
        raise RuntimeError("LNG netbacks: no monthly ICE strips after pivot")

    platts = pd.DataFrame()
    try:
        pq = PlattsQuery(querytype="spot prices", warehouse="EU_COMMOD_RESEARCH_M_WH")
        raw_platts = pq.get_spot_prices("lng", start_date=start)
        platts = pivot_platts_spot(raw_platts)
        raw_freight = pq._get_prices_by_symbols(
            list(SPOT_FREIGHT_SYMBOLS),
            start_date=datetime.fromisoformat(SPOT_FREIGHT_START),
        )
        platts = extend_spot_freight(platts, raw_freight)
    except Exception as exc:
        logger.warning("LNG netbacks: Platts spot pull failed (%s)", exc)

    ice_panel = attach_spot_freight(ice_panel, platts)

    netbacks_fwd = compute_netbacks(
        ice_panel, freight_mode=FREIGHT_FORWARD, hh_slope=HH_SLOPE,
        horizon_months=HORIZON_MONTHS,
    )
    netbacks_spot = compute_netbacks(
        ice_panel, freight_mode=FREIGHT_SPOT, hh_slope=HH_SLOPE,
        horizon_months=HORIZON_MONTHS,
    )
    netbacks_sunk = compute_netbacks(
        ice_panel, freight_mode=FREIGHT_SUNK, hh_slope=HH_SLOPE,
        horizon_months=HORIZON_MONTHS,
    )
    if netbacks_fwd.empty:
        raise RuntimeError("LNG netbacks: forward-freight panel is empty")

    as_of = pd.Timestamp(netbacks_fwd["TRADE_DATE"].max()).normalize()
    data_start = pd.Timestamp(netbacks_fwd["TRADE_DATE"].min()).normalize()
    n_trade_dates = int(netbacks_fwd["TRADE_DATE"].nunique())

    payload = {
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "as_of": as_of,
        "data_start": data_start,
        "n_trade_dates": n_trade_dates,
        "history_start_year": HISTORY_START_YEAR,
        "netbacks_fwd": netbacks_fwd,
        "netbacks_spot": netbacks_spot,
        "netbacks_sunk": netbacks_sunk,
        "platts": platts,
    }

    _register_freshness(
        as_of=str(as_of.date()),
        n_rows=len(netbacks_fwd),
        detail=f"{n_trade_dates} trade dates",
    )
    logger.info(
        "LNG netbacks loaded: %d fwd rows, %d spot rows, %d sunk rows, "
        "%d trade dates, as of %s",
        len(netbacks_fwd), len(netbacks_spot), len(netbacks_sunk),
        n_trade_dates, as_of.date(),
    )
    return payload


def get_payload() -> Optional[dict[str, Any]]:
    """Cached netbacks payload, or None while the source is still warming."""
    try:
        return dashboard_cache.get_data(SOURCE_NAME)
    except Exception as exc:
        logger.warning("LNG netbacks payload unavailable: %s", exc)
        return None


def history_start_years() -> tuple[list[dict], int]:
    """Dropdown options and default for the history chart start year.

    Years run from the earliest cached trade date through the latest settle.
    The default is 2025 when that year is inside the loaded window.
    """
    payload = get_payload()
    if not payload:
        year = DEFAULT_HISTORY_START_YEAR
        return [{"label": str(year), "value": year}], year
    start_year = pd.Timestamp(payload["data_start"]).year
    end_year = pd.Timestamp(payload["as_of"]).year
    for key in ("netbacks_fwd", "netbacks_spot", "netbacks_sunk"):
        df = payload.get(key)
        if df is None or getattr(df, "empty", True):
            continue
        start_year = min(start_year, int(pd.to_datetime(df["TRADE_DATE"]).dt.year.min()))
        end_year = max(end_year, int(pd.to_datetime(df["TRADE_DATE"]).dt.year.max()))
    if end_year < start_year:
        end_year = start_year
    options = [{"label": str(year), "value": year} for year in range(start_year, end_year + 1)]
    default = DEFAULT_HISTORY_START_YEAR
    if default < start_year or default > end_year:
        default = start_year
    return options, default


def picker_bounds() -> tuple[date, date, date]:
    """(min, max, default) dates for the as-of picker."""
    payload = get_payload()
    if not payload:
        today = date.today()
        return today - timedelta(days=365), today, today
    as_of = pd.Timestamp(payload["as_of"]).date()
    start = pd.Timestamp(payload["data_start"]).date()
    return start, as_of, as_of


def panel_for(payload: dict[str, Any], freight_mode: str) -> pd.DataFrame:
    key = {
        FREIGHT_FORWARD: "netbacks_fwd",
        FREIGHT_SPOT: "netbacks_spot",
        FREIGHT_SUNK: "netbacks_sunk",
    }.get(freight_mode, "netbacks_spot")
    df = payload.get(key)
    if df is None:
        return pd.DataFrame()
    return df


def trade_dates(payload: dict[str, Any], freight_mode: str = FREIGHT_FORWARD) -> pd.DatetimeIndex:
    panel = panel_for(payload, freight_mode)
    if panel.empty:
        return pd.DatetimeIndex([])
    return pd.DatetimeIndex(
        pd.to_datetime(panel["TRADE_DATE"]).dt.normalize().unique()
    ).sort_values()


def resolve_as_of(payload: dict[str, Any], requested, freight_mode: str = FREIGHT_FORWARD):
    dates = trade_dates(payload, freight_mode)
    snapped = snap_to_trade_date(requested, dates)
    if snapped is not None:
        return snapped
    if dates.empty:
        return None
    return pd.Timestamp(dates.max())


def snapshot_curves(
    payload: dict[str, Any],
    as_of,
    freight_mode: str,
    offsets: tuple[int, ...] = OVERLAY_OFFSETS,
) -> dict:
    """As-of curve plus T-* overlays. Values are DELIVERY_START-indexed frames."""
    panel = panel_for(payload, freight_mode)
    dates = trade_dates(payload, freight_mode)
    as_of_ts = pd.Timestamp(as_of).normalize()
    overlays = overlay_trade_dates(as_of_ts, dates, offsets)
    curves = {as_of_ts: curve_on_date(panel, as_of_ts)}
    for dt in overlays:
        curves[dt] = curve_on_date(panel, dt)
    return curves
