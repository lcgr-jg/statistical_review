"""Layout for the LNG — Netbacks page."""
from __future__ import annotations

from dash import dcc, html

from core.lng_netbacks.constants import (
    DEFAULT_FREIGHT_BASIN,
    DEFAULT_FREIGHT_MODE,
    DEFAULT_FREIGHT_VIEW,
    DEFAULT_FREIGHT_YOY,
    DEFAULT_GRANULARITY,
    DEFAULT_HISTORY_TENORS,
    DEFAULT_OCC_LOOKBACK,
    DEFAULT_OCC_METRIC,
    FREIGHT_BASIN_ASIA,
    FREIGHT_BASIN_ATLANTIC,
    FREIGHT_FORWARD,
    FREIGHT_SPOT,
    FREIGHT_SUNK,
    FREIGHT_VIEW_HISTORY,
    FREIGHT_VIEW_YOY,
    FREIGHT_YOY_LINES,
    FREIGHT_YOY_RANGE,
    GRANULARITY_OPTIONS,
    HISTORY_TENOR_OPTIONS,
    OCC_LOOKBACK_OPTIONS,
    OCC_METRIC_OPTIONS,
)
from core.lng_netbacks.data import history_start_years, picker_bounds
from core.lng_netbacks.tables import assumptions_table
from core.styles import COLORS

_INLINE_CONTROLS = {
    "display": "flex",
    "alignItems": "flex-end",
    "flexWrap": "wrap",
    "gap": "18px",
    "marginBottom": "12px",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "hidden",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 12px 0",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}

_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "margin": "8px 0 0 0",
    "lineHeight": "1.5",
}

_GRAPH_CONFIG = {
    "displayModeBar": "hover",
    "displaylogo": False,
    "responsive": True,
}

_RADIO_LABEL = {"marginRight": "14px", "cursor": "pointer", "fontSize": "13px"}


def _graph(graph_id: str, height: str = "380px") -> dcc.Loading:
    return dcc.Loading(
        type="circle",
        children=dcc.Graph(
            id=graph_id,
            config=_GRAPH_CONFIG,
            style={"height": height},
        ),
    )


def _pair_row(*children) -> html.Div:
    return html.Div(
        style={
            "display": "grid",
            "gridTemplateColumns": "1fr 1fr 1fr",
            "gap": "12px",
            "marginBottom": "12px",
        },
        children=list(children),
    )


def build_layout() -> html.Div:
    min_date, max_date, default_date = picker_bounds()
    history_years, history_year = history_start_years()

    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1900px"},
        children=[
            html.Div([
                html.H1("LNG Netbacks", style={
                    "fontSize": "22px", "fontWeight": "600",
                    "color": COLORS["text_primary"], "margin": "0 0 4px 0"}),
                html.P(
                    "USGC netbacks into Asia and Europe using ICE settlement "
                    "prices (HH, JKM, TFU) plus Spark freight futures or "
                    "Platts carrier day rates.",
                    style={"fontSize": "13px", "color": COLORS["text_muted"],
                           "margin": "0 0 12px 0"}),
            ]),

            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("US LNG Netbacks (as-of)", style=_PANEL_TITLE),
                html.Div(
                    style={
                        "display": "flex",
                        "alignItems": "flex-end",
                        "flexWrap": "wrap",
                        "gap": "16px",
                        "marginBottom": "12px",
                    },
                    children=[
                        html.Div([
                            html.Label("As-of settle date", style=_LABEL),
                            dcc.DatePickerSingle(
                                id="nb-as-of",
                                date=default_date,
                                min_date_allowed=min_date,
                                max_date_allowed=max_date,
                                display_format="DD-MMM-YYYY",
                                first_day_of_week=1,
                            ),
                        ]),
                        html.Div([
                            html.Label("Granularity", style=_LABEL),
                            dcc.RadioItems(
                                id="nb-granularity",
                                options=GRANULARITY_OPTIONS,
                                value=DEFAULT_GRANULARITY,
                                inline=True,
                                labelStyle=_RADIO_LABEL,
                            ),
                        ]),
                        html.Div(id="nb-status", style={"flex": "1 1 280px"}),
                    ],
                ),
                html.P(
                    "Spark futures freight on the left, Platts spot freight "
                    "in the middle, sunk freight on the right. Quarterly is the "
                    "equal-weight average of the delivery months in each quarter "
                    "(Q4-26, Q1-27). Dashed overlays are T-1 / T-7 / T-14 / "
                    "T-28 versus the selected settle date.",
                    style={**_NOTE, "marginTop": "0"},
                ),
                _pair_row(
                    _graph("nb-premium-fwd", "420px"),
                    _graph("nb-premium-spot", "420px"),
                    _graph("nb-premium-sunk", "420px"),
                ),
                _pair_row(
                    _graph("nb-margins-fwd", "420px"),
                    _graph("nb-margins-spot", "420px"),
                    _graph("nb-margins-sunk", "420px"),
                ),
                _pair_row(
                    _graph("nb-stack-fwd", "500px"),
                    _graph("nb-stack-spot", "500px"),
                    _graph("nb-stack-sunk", "500px"),
                ),
            ]),

            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Netback history", style=_PANEL_TITLE),
                html.Div(style=_INLINE_CONTROLS, children=[
                    html.Div([
                        html.Label("Netback history freight", style=_LABEL),
                        dcc.RadioItems(
                            id="nb-history-freight",
                            options=[
                                {"label": "Spark futures", "value": FREIGHT_FORWARD},
                                {"label": "Platts spot", "value": FREIGHT_SPOT},
                                {"label": "Sunk shipping", "value": FREIGHT_SUNK},
                            ],
                            value=DEFAULT_FREIGHT_MODE,
                            inline=True,
                            labelStyle=_RADIO_LABEL,
                        ),
                    ]),
                    html.Div([
                        html.Label("Granularity", style=_LABEL),
                        dcc.RadioItems(
                            id="nb-history-granularity",
                            options=GRANULARITY_OPTIONS,
                            value=DEFAULT_GRANULARITY,
                            inline=True,
                            labelStyle=_RADIO_LABEL,
                        ),
                    ]),
                    html.Div([
                        html.Label("Start year", style=_LABEL),
                        dcc.Dropdown(
                            id="nb-history-start-year",
                            options=history_years,
                            value=history_year,
                            clearable=False,
                            style={"width": "110px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("History tenors", style=_LABEL),
                        dcc.RadioItems(
                            id="nb-hist-tenors",
                            options=HISTORY_TENOR_OPTIONS,
                            value=DEFAULT_HISTORY_TENORS,
                            inline=True,
                            labelStyle=_RADIO_LABEL,
                        ),
                    ]),
                ]),
                html.P(
                    "Asia vs EU premiums (Cape of Good Hope and Panama) versus "
                    "trade date, from 1 January of the start year. Quarterly "
                    "points average the delivery months in each quarter. The "
                    "as-of date is marked with a vertical line.",
                    style={**_NOTE, "marginTop": "0"},
                ),
                _graph("nb-history", "400px"),
            ]),

            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Netback strength vs persistence", style=_PANEL_TITLE),
                html.Div(style=_INLINE_CONTROLS, children=[
                    html.Div([
                        html.Label("Occupancy freight", style=_LABEL),
                        dcc.RadioItems(
                            id="nb-freight-mode",
                            options=[
                                {"label": "Spark futures", "value": FREIGHT_FORWARD},
                                {"label": "Platts spot", "value": FREIGHT_SPOT},
                                {"label": "Sunk shipping", "value": FREIGHT_SUNK},
                            ],
                            value=DEFAULT_FREIGHT_MODE,
                            inline=True,
                            labelStyle=_RADIO_LABEL,
                        ),
                    ]),
                    html.Div([
                        html.Label("Occupancy metric", style=_LABEL),
                        dcc.Dropdown(
                            id="nb-occ-metric",
                            options=OCC_METRIC_OPTIONS,
                            value=DEFAULT_OCC_METRIC,
                            clearable=False,
                            style={"width": "240px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Occupancy lookback", style=_LABEL),
                        dcc.Dropdown(
                            id="nb-occ-lookback",
                            options=OCC_LOOKBACK_OPTIONS,
                            value=DEFAULT_OCC_LOOKBACK,
                            clearable=False,
                            style={"width": "110px"},
                        ),
                    ]),
                ]),
                html.P(
                    "Same occupancy construction as the JKM/TFU heatmap: "
                    "x = strength buckets, y = monthly tenors, cell = days "
                    "the tenor settled in that bucket over the lookback. "
                    "Outlined cell is the latest (or final) settle. Expired "
                    "tenors are marked *.",
                    style={**_NOTE, "marginTop": "0"},
                ),
                _graph("nb-occupancy", "720px"),
            ]),

            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("LNG freight rates", style=_PANEL_TITLE),
                _graph("nb-freight-fwd", "340px"),
                html.Div(style={**_INLINE_CONTROLS, "marginTop": "8px"}, children=[
                    html.Div([
                        html.Label("Spot freight chart", style=_LABEL),
                        dcc.RadioItems(
                            id="nb-freight-view",
                            options=[
                                {"label": "Full history", "value": FREIGHT_VIEW_HISTORY},
                                {"label": "Year on year", "value": FREIGHT_VIEW_YOY},
                            ],
                            value=DEFAULT_FREIGHT_VIEW,
                            inline=True,
                            labelStyle=_RADIO_LABEL,
                        ),
                    ]),
                    html.Div([
                        html.Label("Basin", style=_LABEL),
                        dcc.RadioItems(
                            id="nb-freight-basin",
                            options=[
                                {"label": "Asia Pacific", "value": FREIGHT_BASIN_ASIA},
                                {"label": "Atlantic", "value": FREIGHT_BASIN_ATLANTIC},
                            ],
                            value=DEFAULT_FREIGHT_BASIN,
                            inline=True,
                            labelStyle=_RADIO_LABEL,
                        ),
                    ]),
                    html.Div([
                        html.Label("Year on year", style=_LABEL),
                        dcc.RadioItems(
                            id="nb-freight-yoy-style",
                            options=[
                                {"label": "Historic range", "value": FREIGHT_YOY_RANGE},
                                {"label": "All years", "value": FREIGHT_YOY_LINES},
                            ],
                            value=DEFAULT_FREIGHT_YOY,
                            inline=True,
                            labelStyle=_RADIO_LABEL,
                        ),
                    ]),
                ]),
                _graph("nb-freight-spot", "340px"),
            ]),

            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("LNG prices", style=_PANEL_TITLE),
                _graph("nb-price-curves", "380px"),
                html.H4("JKM/TFU spread", style={
                    "fontSize": "12px", "color": COLORS["text_secondary"],
                    "fontWeight": "500", "margin": "14px 0 6px 0"}),
                dcc.Loading(type="circle",
                            children=html.Div(id="nb-jkm-table")),
                _graph("nb-jkm-occupancy", "720px"),
                html.P(
                    "Expired tenors (*) stop trading mid-month of the prior "
                    "month. Into that last trading window the contract "
                    "behaves more like spot, so the outlined final settle "
                    "may sit in an extreme bucket relative to the rest of "
                    "the lookback distribution.",
                    style=_NOTE,
                ),
                html.Div(style={"marginTop": "16px"},
                         children=_graph("nb-spot-prices", "560px")),
            ]),

            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Netback Assumptions", style=_PANEL_TITLE),
                assumptions_table(),
            ]),
        ],
    )
