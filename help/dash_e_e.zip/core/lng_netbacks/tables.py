"""HTML tables for the LNG Netbacks page (JKM/TFU structure + assumptions)."""
from __future__ import annotations

import pandas as pd
from dash import html

from core.lng_netbacks.constants import (
    DEFAULT_VESSEL,
    FREIGHT_CONSTANTS,
    PANAMA_CANAL_FEE,
    PORT_COSTS,
    SUEZ_CANAL_FEE,
    VESSEL_SIZES,
    VOYAGES,
)
from core.styles import COLORS

_TH = {
    "textAlign": "center",
    "padding": "5px 8px",
    "backgroundColor": "#2c3e50",
    "color": "#ffffff",
    "fontSize": "11px",
    "fontWeight": "500",
    "border": "1px solid #2c3e50",
}
_TH_IDX = {
    **_TH,
    "textAlign": "left",
    "backgroundColor": "#1f2d3a",
}
_TD = {
    "textAlign": "center",
    "padding": "3px 8px",
    "fontSize": "11px",
    "borderBottom": "1px solid #eee",
    "color": COLORS["text_primary"],
}
_TD_IDX = {
    **_TD,
    "textAlign": "left",
    "fontWeight": "500",
    "backgroundColor": "#f0f1f2",
    "borderBottom": "1px solid #ddd",
}


def jkm_tfu_table(df: pd.DataFrame) -> html.Table | html.Div:
    """Render the JKM/TFU structure table (latest + overlay deltas)."""
    if df is None or df.empty:
        return html.Div(
            "JKM/TFU table unavailable for this date.",
            style={"fontSize": "12px", "color": COLORS["text_muted"]},
        )

    header = html.Tr(
        [html.Th("", style=_TH_IDX)]
        + [html.Th(str(c), style=_TH) for c in df.columns]
    )
    body = []
    for i, (idx, row) in enumerate(df.iterrows()):
        bg = "#f8f9fa" if i % 2 else "#ffffff"
        cells = [html.Td(str(idx), style=_TD_IDX)]
        for j, val in enumerate(row):
            style = {**_TD, "backgroundColor": bg}
            if pd.isna(val):
                text = ""
                style["color"] = COLORS["text_muted"]
            elif j == 0:
                text = f"{float(val):.2f}"
                style["fontWeight"] = "700"
            else:
                text = f"{float(val):+.2f}"
                if val > 0:
                    style["color"] = "#27ae60"
                    style["fontWeight"] = "700"
                elif val < 0:
                    style["color"] = "#e74c3c"
                    style["fontWeight"] = "700"
                else:
                    style["color"] = COLORS["text_muted"]
            cells.append(html.Td(text, style=style))
        body.append(html.Tr(cells))

    return html.Table(
        [html.Thead(header), html.Tbody(body)],
        style={
            "borderCollapse": "collapse",
            "fontSize": "11px",
            "width": "100%",
            "fontFamily": "-apple-system, BlinkMacSystemFont, Segoe UI, Arial, sans-serif",
        },
    )


def _kv_table(title: str, rows: list[tuple[str, str]]) -> html.Table:
    th = {
        "textAlign": "left",
        "padding": "3px 12px 3px 0",
        "borderBottom": "1px solid #ccc",
        "fontWeight": "600",
        "color": "#2c3e50",
        "fontSize": "12px",
    }
    td_k = {"padding": "2px 12px 2px 0", "color": "#555", "fontSize": "12px"}
    td_v = {"padding": "2px 0", "color": "#333", "fontSize": "12px"}
    body = [html.Tr(html.Th(title, colSpan=2, style=th))]
    for k, v in rows:
        body.append(html.Tr([
            html.Td(k, style=td_k),
            html.Td(v, style=td_v),
        ]))
    return html.Table(body, style={"borderCollapse": "collapse", "margin": "0 24px 12px 0"})


def assumptions_table() -> html.Div:
    pct_keys = {"fillable_volume", "boiloffrate_laden", "boiloffrate_ballast"}
    const_rows = []
    for key, value in FREIGHT_CONSTANTS.items():
        label = key.replace("_", " ").title()
        formatted = f"{value * 100:.2f}%" if key in pct_keys else str(value)
        const_rows.append((label, formatted))

    return html.Div(
        style={"display": "flex", "flexWrap": "wrap", "alignItems": "flex-start"},
        children=[
            _kv_table("Vessel & Route", [
                ("Default vessel size (Platts)",
                 f"{VESSEL_SIZES[DEFAULT_VESSEL]:,.0f} m³"),
                ("Journey days from the US (16 kts)", ""),
                ("US → NL", f"{VOYAGES['us>nl']}d"),
                ("US → SK via CoGH", f"{VOYAGES['us>sk']}d"),
                ("US → SK via Panama", f"{VOYAGES['us>panama>sk']}d"),
                ("US → SK via Suez", f"{VOYAGES['us>suez>sk']}d"),
            ]),
            _kv_table("Freight Constants", const_rows),
            _kv_table("Canal & Port Fees", [
                ("Panama Canal", f"${PANAMA_CANAL_FEE}/mmbtu"),
                ("Suez Canal", f"${SUEZ_CANAL_FEE}/mmbtu"),
                ("Port fee NL", f"${PORT_COSTS['nl']}/mmbtu"),
                ("Port fee SK", f"${PORT_COSTS['sk']}/mmbtu"),
            ]),
        ],
    )
