"""Plotly figure builders for the LNG Netbacks page."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.lng_netbacks.calc import hh_liq_col
from core.lng_netbacks.constants import (
    COL_ASIA_VS_EU,
    COL_FRT_ASIA,
    COL_FRT_ATLANTIC,
    COL_FRT_NL,
    COL_FRT_PANAMA,
    COL_FRT_SK,
    COL_JKM_TFU,
    COL_NL_PROFIT,
    COL_PANAMA_PROFIT,
    COL_PANAMA_VS_EU,
    COL_SK_PROFIT,
    FREIGHT_STACK_COLORS,
    HH_SLOPE,
    PLATTS_ASIA,
    PLATTS_ATLANTIC,
    PLATTS_JKM,
    PLATTS_MED,
    PLATTS_NWE,
    PLATTS_WIM,
    ROUTE_COLORS,
)
from core.styles import COLORS
from core.theme import PLOTLY_TEMPLATE_NAME

C = ROUTE_COLORS

_PROFIT_COLS = (COL_NL_PROFIT, COL_SK_PROFIT, COL_PANAMA_PROFIT)
_PROFIT_COLORS = {
    COL_NL_PROFIT: C["us_nl"],
    COL_SK_PROFIT: C["us_sk"],
    COL_PANAMA_PROFIT: C["us_panama"],
}
_PROFIT_LABELS = {
    COL_NL_PROFIT: "US → NL",
    COL_SK_PROFIT: "US → SK (via CoGH)",
    COL_PANAMA_PROFIT: "US → SK (via Panama)",
}

_BAR_COLS = (COL_ASIA_VS_EU, COL_PANAMA_VS_EU)
_BAR_LABELS = ("US → Asia (via CoGH)", "US → Asia (via Panama)")
_BAR_POS = (C["positive"], C["positive_alt"])
_BAR_NEG = (C["negative"], C["negative_alt"])

_ROUTES_STACK = (
    ("US → NL", COL_FRT_NL, "TFU", C["us_nl"]),
    ("US → SK (CoGH)", COL_FRT_SK, "JKM", C["us_sk"]),
    ("US → SK (Panama)", COL_FRT_PANAMA, "JKM", C["us_panama"]),
)

_GRAPH_FONT = (
    '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
)

_BASE = dict(
    template=PLOTLY_TEMPLATE_NAME,
    paper_bgcolor=COLORS["chart_paper"],
    plot_bgcolor=COLORS["chart_bg"],
    font={"family": _GRAPH_FONT, "size": 12},
    legend={"orientation": "h", "yanchor": "top", "y": -0.18,
            "xanchor": "center", "x": 0.5},
    hovermode="x unified",
    margin={"l": 55, "r": 50, "t": 48, "b": 70},
)

# Snapshot 3x2: extra top/bottom margin so centered titles and below-plot
# legends do not collide with the modebar or quarterly x-tick labels.
_SNAPSHOT_MARGIN = {"l": 55, "r": 40, "t": 62, "b": 118}
_SNAPSHOT_LEGEND = {
    "orientation": "h",
    "yanchor": "top",
    "y": -0.32,
    "xanchor": "center",
    "x": 0.5,
    "font": {"size": 11},
    "bgcolor": "rgba(255,255,255,0)",
    "tracegroupgap": 4,
}


def _layout(**kwargs) -> dict:
    """Merge page defaults with per-figure overrides."""
    out = dict(_BASE)
    # Template hoverlabel has a white background but no font colour, so Plotly
    # infers a pale grey from the heatmap. Force dark text on every figure.
    out["hoverlabel"] = {
        "bgcolor": "#ffffff",
        "bordercolor": COLORS["border"],
        "font": {"family": _GRAPH_FONT, "size": 12, "color": COLORS["text_primary"]},
    }
    out.update(kwargs)
    return out


def _axis_x(index, quarterly: bool):
    """Delivery axis: month dates, or labels such as ``Q4-26``."""
    ts = pd.to_datetime(index)
    if not quarterly:
        return ts
    return [f"Q{t.quarter}-{t.strftime('%y')}" for t in ts]


def _apply_delivery_xaxis(
    fig: go.Figure,
    *,
    quarterly: bool = False,
    categoryarray=None,
) -> None:
    """Month axis is %b-%y every 3 months. Quarter axis is Q4-26, Q1-27, …"""
    if quarterly:
        fig.update_xaxes(
            type="category",
            categoryorder="array",
            categoryarray=list(categoryarray or []),
            tickangle=0,
            ticks="outside",
            automargin=False,
            showgrid=True,
            title_text=None,
        )
        return
    fig.update_xaxes(
        tickformat="%b-%y",
        dtick="M3",
        tickangle=0,
        ticks="outside",
        automargin=False,
        showgrid=True,
        title_text=None,
    )


def _faded(hex_color: str, alpha: float = 0.35) -> str:
    hex_color = hex_color.lstrip("#")
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r}, {g}, {b}, {alpha})"


def empty_figure(message: str = "No data", height: int = 360) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        **_BASE,
        height=height,
        xaxis={"visible": False},
        yaxis={"visible": False},
        annotations=[{
            "text": message, "showarrow": False,
            "font": {"size": 14, "color": COLORS["text_muted"]},
        }],
    )
    return fig


def _t_label(as_of, hist_date) -> str:
    days = int((pd.Timestamp(as_of).normalize()
                - pd.Timestamp(hist_date).normalize()).days)
    return f"T-{days}"


def _add_premium_side_labels(fig: go.Figure) -> None:
    """Mark the positive side as Asia premium and the negative side as Europe."""
    font = {
        "size": 11,
        "color": COLORS["text_muted"],
        "family": _GRAPH_FONT,
    }
    fig.add_annotation(
        text="<i>Asia Premium</i>",
        xref="paper", yref="paper",
        x=0.985, y=0.97,
        xanchor="right", yanchor="top",
        showarrow=False,
        font=font,
        bgcolor="rgba(255,255,255,0.72)",
    )
    fig.add_annotation(
        text="<i>Europe Premium</i>",
        xref="paper", yref="paper",
        x=0.985, y=0.03,
        xanchor="right", yanchor="bottom",
        showarrow=False,
        font=font,
        bgcolor="rgba(255,255,255,0.72)",
    )


def fig_netback_premium(
    df: pd.DataFrame,
    overlays: dict,
    as_of,
    title: str,
    *,
    quarterly: bool = False,
) -> go.Figure:
    if df is None or df.empty:
        return empty_figure("No netbacks for this date")
    x = _axis_x(df.index, quarterly)
    hover_x = "%{x}" if quarterly else "%{x|%b-%y}"
    fig = go.Figure()
    for i, (col, label, cp, cn) in enumerate(
            zip(_BAR_COLS, _BAR_LABELS, _BAR_POS, _BAR_NEG)):
        if col not in df.columns:
            continue
        vals = df[col].astype(float).to_numpy()
        colors = [cp if v >= 0 else cn for v in vals]
        fig.add_bar(
            x=x, y=vals, name=label, marker_color=colors,
            offsetgroup=str(i),
            hovertemplate=f"{hover_x}<br>%{{y:.2f}}<extra>%{{fullData.name}}</extra>",
        )
    if COL_JKM_TFU in df.columns:
        fig.add_scatter(
            x=x, y=df[COL_JKM_TFU].to_numpy(), name="JKM/TFU",
            mode="lines+markers",
            line={"color": "#505A64", "width": 1.6, "dash": "dash"},
            marker={"size": 5},
        )
    for hist_dt, hist_df in overlays.items():
        if hist_df is None or hist_df.empty or COL_JKM_TFU not in hist_df.columns:
            continue
        aligned = hist_df[COL_JKM_TFU].reindex(df.index)
        fig.add_scatter(
            x=x, y=aligned.to_numpy(), name=_t_label(as_of, hist_dt),
            mode="lines",
            line={"color": _faded("#888888", 0.55), "width": 1, "dash": "dash"},
            showlegend=False,
            hovertemplate="%{y:.2f}<extra>%{fullData.name}</extra>",
        )
    fig.add_hline(y=0, line_color=C["zero_line"], line_width=0.6)
    fig.update_layout(**_layout(
        height=420, title=title, barmode="group",
        bargap=0.25, bargroupgap=0.08,
        yaxis_title="$/mmbtu",
        margin=_SNAPSHOT_MARGIN, legend=_SNAPSHOT_LEGEND,
    ))
    _apply_delivery_xaxis(fig, quarterly=quarterly, categoryarray=x)
    _add_premium_side_labels(fig)
    return fig


def fig_profit_margins(
    df: pd.DataFrame,
    overlays: dict,
    as_of,
    title: str,
    *,
    quarterly: bool = False,
) -> go.Figure:
    if df is None or df.empty:
        return empty_figure("No netbacks for this date")
    fig = go.Figure()
    x = _axis_x(df.index, quarterly)
    for hist_dt, hist_df in overlays.items():
        if hist_df is None or hist_df.empty:
            continue
        clipped = hist_df.reindex(df.index)
        for col in _PROFIT_COLS:
            if col not in clipped.columns:
                continue
            fig.add_scatter(
                x=x, y=clipped[col].to_numpy(),
                name=_t_label(as_of, hist_dt),
                mode="lines",
                line={"color": _faded(_PROFIT_COLORS[col], 0.4),
                      "width": 1, "dash": "dash"},
                showlegend=False,
                hovertemplate="%{y:.2f}<extra>%{fullData.name}</extra>",
            )
    for col in _PROFIT_COLS:
        if col not in df.columns:
            continue
        fig.add_scatter(
            x=x, y=df[col].to_numpy(), name=_PROFIT_LABELS[col],
            mode="lines+markers",
            line={"color": _PROFIT_COLORS[col], "width": 1.8},
            marker={"size": 5},
        )
    fig.add_hline(y=0, line_color=C["zero_line"], line_width=0.5)
    fig.update_layout(**_layout(
        height=420, title=title, yaxis_title="$/mmbtu",
        margin=_SNAPSHOT_MARGIN, legend=_SNAPSHOT_LEGEND,
    ))
    _apply_delivery_xaxis(fig, quarterly=quarterly, categoryarray=x)
    return fig


def fig_cost_stack(
    df: pd.DataFrame,
    title: str,
    *,
    use_forward_freight: bool = True,
    show_day_rates: bool = True,
    quarterly: bool = False,
) -> go.Figure:
    if df is None or df.empty:
        return empty_figure("No netbacks for this date")
    x = _axis_x(df.index, quarterly)
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    liq_col = hh_liq_col(HH_SLOPE)
    hh = (df["HH"] if "HH" in df.columns else pd.Series(0.0, index=df.index)).to_numpy()
    if liq_col in df.columns:
        liq = df[liq_col].to_numpy() - hh
    else:
        liq = hh * 0.15

    for i, (route_label, frt_col, _dest, _color) in enumerate(_ROUTES_STACK):
        frt = (df[frt_col] if frt_col in df.columns
               else pd.Series(0.0, index=df.index)).to_numpy()
        fig.add_bar(
            x=x, y=hh, name="HH", offsetgroup=route_label,
            marker_color=C["hh"], legendgroup="hh",
            showlegend=(i == 0), secondary_y=False,
        )
        fig.add_bar(
            x=x, y=liq, name="Liquefaction (15%)", offsetgroup=route_label,
            base=hh, marker_color=C["hh_liq"], legendgroup="liq",
            showlegend=(i == 0), secondary_y=False,
        )
        fig.add_bar(
            x=x, y=frt, name=f"Freight — {route_label}",
            offsetgroup=route_label, base=hh + liq,
            marker_color=FREIGHT_STACK_COLORS[i],
            secondary_y=False,
        )

    if "TFU" in df.columns:
        fig.add_scatter(
            x=x, y=df["TFU"].to_numpy(), name="TFU", mode="lines+markers",
            line={"color": C["tfu"], "width": 1.6}, marker={"size": 5},
            secondary_y=False,
        )
    if "JKM" in df.columns:
        fig.add_scatter(
            x=x, y=df["JKM"].to_numpy(), name="JKM", mode="lines+markers",
            line={"color": C["jkm"], "width": 1.6}, marker={"size": 5},
            secondary_y=False,
        )

    if show_day_rates:
        asia_label = "Spark25S — Asia" if use_forward_freight else "Platts Spot — Asia"
        atl_label = "Spark30S — Atlantic" if use_forward_freight else "Platts Spot — Atlantic"
        if COL_FRT_ASIA in df.columns:
            fig.add_scatter(
                x=x, y=df[COL_FRT_ASIA].to_numpy(), name=asia_label,
                mode="lines+markers",
                line={"color": C["freight_asia"], "width": 1.2, "dash": "dot"},
                marker={"size": 5, "symbol": "triangle-up"},
                secondary_y=True,
            )
        if COL_FRT_ATLANTIC in df.columns:
            fig.add_scatter(
                x=x, y=df[COL_FRT_ATLANTIC].to_numpy(), name=atl_label,
                mode="lines+markers",
                line={"color": C["freight_atlantic"], "width": 1.2, "dash": "dot"},
                marker={"size": 5, "symbol": "triangle-down"},
                secondary_y=True,
            )

    stack_legend = {**_SNAPSHOT_LEGEND, "y": -0.38}
    stack_margin = {**_SNAPSHOT_MARGIN, "b": 150}
    fig.update_layout(**_layout(
        height=500, title=title, barmode="group",
        bargap=0.3, bargroupgap=0.08,
        legend=stack_legend, margin=stack_margin,
    ))
    fig.update_yaxes(title_text="$/mmbtu", secondary_y=False)
    _apply_delivery_xaxis(fig, quarterly=quarterly, categoryarray=x)
    if show_day_rates:
        fig.update_yaxes(title_text="Freight rate ($/day)", secondary_y=True,
                         showgrid=False)
    else:
        fig.update_yaxes(visible=False, secondary_y=True)
    return fig


def fig_price_curves(
    df: pd.DataFrame,
    overlays: dict,
    as_of,
    title: str,
) -> go.Figure:
    if df is None or df.empty:
        return empty_figure("No prices for this date")
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    px_cols = {"HH": C["hh"], "TFU": C["tfu"], "JKM": C["jkm"]}
    for hist_dt, hist_df in overlays.items():
        if hist_df is None or hist_df.empty:
            continue
        clipped = hist_df.reindex(df.index)
        for col, color in px_cols.items():
            if col not in clipped.columns:
                continue
            fig.add_scatter(
                x=clipped.index, y=clipped[col],
                mode="lines",
                line={"color": _faded(color, 0.35), "width": 1, "dash": "dash"},
                showlegend=False, secondary_y=False,
                name=_t_label(as_of, hist_dt),
            )
        if COL_JKM_TFU in clipped.columns:
            fig.add_scatter(
                x=clipped.index, y=clipped[COL_JKM_TFU],
                mode="lines",
                line={"color": _faded(C["spread"], 0.35), "width": 1, "dash": "dot"},
                showlegend=False, secondary_y=True,
                name=_t_label(as_of, hist_dt),
            )
    for col, color in px_cols.items():
        if col not in df.columns:
            continue
        fig.add_scatter(
            x=df.index, y=df[col], name=col, mode="lines+markers",
            line={"color": color, "width": 1.8}, marker={"size": 5},
            secondary_y=False,
        )
    if COL_JKM_TFU in df.columns:
        fig.add_scatter(
            x=df.index, y=df[COL_JKM_TFU], name="JKM/TFU spread",
            mode="lines+markers",
            line={"color": C["spread"], "width": 1.6},
            marker={"size": 5, "symbol": "square"},
            secondary_y=True,
        )
    fig.update_layout(**_BASE, height=380, title=title)
    fig.update_yaxes(title_text="$/mmbtu", secondary_y=False)
    fig.update_yaxes(title_text="JKM/TFU spread", secondary_y=True,
                     color=C["spread"], showgrid=False)
    fig.update_xaxes(tickformat="%b-%y", tickangle=40)
    return fig


def fig_forward_freight(
    df: pd.DataFrame,
    overlays: dict,
    as_of,
    title: str,
) -> go.Figure:
    if df is None or df.empty:
        return empty_figure("No forward freight for this date")
    fig = go.Figure()
    series = (
        (COL_FRT_ASIA, "Asia Pacific (Spark25S)", C["freight_asia"]),
        (COL_FRT_ATLANTIC, "Atlantic (Spark30S)", C["freight_atlantic"]),
    )
    for hist_dt, hist_df in overlays.items():
        if hist_df is None or hist_df.empty:
            continue
        aligned = hist_df.reindex(df.index)
        for col, _label, color in series:
            if col not in aligned.columns:
                continue
            fig.add_scatter(
                x=df.index, y=aligned[col],
                mode="lines",
                line={"color": _faded(color, 0.4), "width": 1, "dash": "dash"},
                showlegend=False, name=_t_label(as_of, hist_dt),
            )
    for col, label, color in series:
        if col not in df.columns:
            continue
        fig.add_scatter(
            x=df.index, y=df[col], name=label, mode="lines+markers",
            line={"color": color, "width": 1.8}, marker={"size": 5},
        )
    fig.update_layout(**_BASE, height=340, title=title, yaxis_title="$/day")
    fig.update_xaxes(tickformat="%b-%y", tickangle=40)
    fig.update_yaxes(tickprefix="$", tickformat=",.0f")
    return fig


def fig_spot_freight(platts: pd.DataFrame, as_of=None) -> go.Figure:
    if platts is None or platts.empty:
        return empty_figure("No Platts freight history")
    fig = go.Figure()
    cfg = (
        (PLATTS_ASIA, "Asia Pacific", C["freight_asia"]),
        (PLATTS_ATLANTIC, "Atlantic", C["freight_atlantic"]),
    )
    cutoff = pd.Timestamp(as_of).normalize() if as_of is not None else None
    latest_lines = ["<b>Latest values (DoD)</b>"]
    for col, label, color in cfg:
        if col not in platts.columns:
            continue
        s = platts[col].dropna().sort_index()
        if s.empty:
            continue
        s.index = pd.to_datetime(s.index)
        fig.add_scatter(
            x=s.index, y=s.values, name=label, mode="lines",
            line={"color": color, "width": 1.6},
        )
        snapped = s if cutoff is None else s.loc[s.index.normalize() <= cutoff]
        if snapped.empty:
            continue
        current = float(snapped.iloc[-1])
        day = pd.Timestamp(snapped.index[-1])
        day_lbl = f"{day.day} {day.strftime('%b')}"
        if len(snapped) >= 2:
            delta = current - float(snapped.iloc[-2])
            sign = "+" if delta >= 0 else ""
            latest_lines.append(
                f"{label}, {day_lbl}: ${current:,.0f} ({sign}{delta:,.0f})"
            )
        else:
            latest_lines.append(f"{label}, {day_lbl}: ${current:,.0f}")
    if as_of is not None:
        fig.add_vline(
            x=pd.Timestamp(as_of), line_dash="dot",
            line_color=COLORS["text_muted"], line_width=1,
        )
    if len(latest_lines) > 1:
        fig.add_annotation(
            text="<br>".join(latest_lines),
            xref="paper", yref="paper",
            x=0.99, y=0.98,
            xanchor="right", yanchor="top",
            showarrow=False,
            align="left",
            bgcolor="rgba(255,255,255,0.92)",
            bordercolor="#cccccc",
            borderwidth=1,
            borderpad=6,
            font={"size": 11, "family": _GRAPH_FONT, "color": COLORS["text_primary"]},
        )
    fig.update_layout(
        **_BASE, height=340,
        title="Platts Spot LNG Freight Rate History ($/day)",
    )
    fig.update_xaxes(hoverformat="%d %b %Y")
    fig.update_yaxes(tickprefix="$", tickformat=",.0f", title_text=None)
    return fig


def _seasonal_range_band(frame: pd.DataFrame) -> pd.DataFrame:
    """Min, max, and median by calendar day after carrying each year's last quote.

    Platts does not print on weekends, and those weekdays fall on different
    dates each year. A raw day-of-year envelope therefore spikes on the days a
    high year happened to print and collapses where it did not.
    """
    columns = []
    for year, sl in frame.groupby("year", sort=True):
        sl = sl.sort_values("x").drop_duplicates("x")
        if sl.empty:
            continue
        daily = pd.date_range(sl["x"].min(), sl["x"].max(), freq="D")
        filled = sl.set_index("x")["value"].reindex(daily).ffill()
        filled.name = int(year)
        columns.append(filled)
    if not columns:
        return pd.DataFrame(columns=["min", "max", "median"])
    wide = pd.concat(columns, axis=1)
    return pd.DataFrame({
        "min": wide.min(axis=1, skipna=True),
        "max": wide.max(axis=1, skipna=True),
        "median": wide.median(axis=1, skipna=True),
    }).dropna(subset=["min", "max"])


def _seasonal_frame(series: pd.Series, as_of=None) -> pd.DataFrame:
    """Map a daily series onto a leap-year axis so years can share an x-axis."""
    s = series.dropna().sort_index()
    idx = pd.to_datetime(s.index)
    if getattr(idx, "tz", None) is not None:
        idx = idx.tz_localize(None)
    s.index = idx
    if as_of is not None:
        s = s.loc[s.index.normalize() <= pd.Timestamp(as_of).normalize()]
    if s.empty:
        return pd.DataFrame(columns=["value", "year", "x"])
    x = pd.to_datetime({
        "year": np.full(len(s), 2024),
        "month": s.index.month.to_numpy(),
        "day": s.index.day.to_numpy(),
    }).to_numpy()
    return pd.DataFrame(
        {"value": s.to_numpy(), "year": s.index.year, "x": x},
        index=s.index,
    )


def fig_spot_freight_yoy(
    series: pd.Series,
    *,
    label: str,
    color: str,
    style: str,
    as_of=None,
) -> go.Figure:
    """Year-on-year Platts freight for one basin.

    ``style`` is ``range`` (min–max band of earlier years plus this year)
    or ``lines`` (one line per year).
    """
    frame = _seasonal_frame(series, as_of)
    if frame.empty:
        return empty_figure(f"No {label} freight history", height=400)
    current = int(frame["year"].max())
    legend = {
        "orientation": "h",
        "yanchor": "top",
        "y": -0.18,
        "xanchor": "center",
        "x": 0.5,
    }
    fig = go.Figure()
    if style == "lines":
        years = sorted(int(y) for y in frame["year"].unique())
        n_prior = max(len(years) - 1, 1)
        for i, year in enumerate(years):
            sl = frame.loc[frame["year"] == year]
            is_cur = year == current
            line_color = color if is_cur else _faded(color, 0.28 + 0.55 * (i / n_prior))
            fig.add_scatter(
                x=sl["x"], y=sl["value"], name=str(year),
                mode="lines",
                line={"color": line_color, "width": 2.4 if is_cur else 1.15},
                hovertemplate=(
                    f"{year}<br>%{{x|%d %b}}<br>%{{y:,.0f}} $/day<extra></extra>"
                ),
            )
        extra_rows = max(0, (len(years) - 1) // 8)
        height = 420 + 18 * extra_rows
        margin_b = 78 + 16 * extra_rows
    else:
        hist = frame.loc[frame["year"] < current]
        cur = frame.loc[frame["year"] == current]
        if not hist.empty:
            band = _seasonal_range_band(hist)
            fig.add_scatter(
                x=band.index, y=band["max"], name="Historic max",
                mode="lines", line={"width": 0},
                showlegend=False, hoverinfo="skip",
            )
            fig.add_scatter(
                x=band.index, y=band["min"], name="Historic range",
                mode="lines", line={"width": 0},
                fill="tonexty", fillcolor=_faded(color, 0.22),
                hovertemplate=(
                    "%{x|%d %b}<br>%{y:,.0f}<extra>Historic range</extra>"
                ),
            )
            fig.add_scatter(
                x=band.index, y=band["median"], name="Historic median",
                mode="lines",
                line={"color": _faded(color, 0.75), "width": 1.2, "dash": "dot"},
                hovertemplate="%{x|%d %b}<br>median %{y:,.0f}<extra></extra>",
            )
        if not cur.empty:
            fig.add_scatter(
                x=cur["x"], y=cur["value"], name=str(current),
                mode="lines",
                line={"color": color, "width": 2.4},
                hovertemplate=(
                    f"{current}<br>%{{x|%d %b}}<br>%{{y:,.0f}} $/day<extra></extra>"
                ),
            )
        height = 400
        margin_b = 78
    if as_of is not None and not frame.empty:
        stamp = pd.Timestamp(as_of)
        fig.add_vline(
            x=pd.Timestamp(year=2024, month=int(stamp.month), day=int(stamp.day)),
            line_dash="dot", line_color=COLORS["text_muted"], line_width=1,
        )
    fig.update_layout(**_layout(
        height=height,
        title=f"{label} spot freight, year on year ($/day)",
        yaxis_title="$/day",
        legend=legend,
        margin={"l": 55, "r": 24, "t": 48, "b": margin_b},
    ))
    fig.update_xaxes(tickformat="%b", dtick="M1", range=["2024-01-01", "2024-12-31"])
    fig.update_yaxes(tickprefix="$", tickformat=",.0f")
    return fig


def fig_spot_prices(platts: pd.DataFrame, as_of=None) -> go.Figure:
    if platts is None or platts.empty:
        return empty_figure("No Platts LNG spot history", height=480)
    fig = make_subplots(
        rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.12,
        row_heights=[0.58, 0.42],
        subplot_titles=("Platts LNG Spot Prices ($/MMBtu)",
                        "JKM/NWE Spread ($/MMBtu)"),
    )
    cfg = (
        (PLATTS_JKM, "JKM", C["jkm"]),
        (PLATTS_MED, "Med DES", C["us_panama"]),
        (PLATTS_NWE, "NWE DES", C["tfu"]),
        (PLATTS_WIM, "WIM", C["us_suez"]),
    )
    for col, label, color in cfg:
        if col not in platts.columns:
            continue
        s = platts[col].dropna()
        fig.add_scatter(
            x=s.index, y=s.values, name=label, mode="lines",
            line={"color": color, "width": 1.6}, row=1, col=1,
        )
    if PLATTS_JKM in platts.columns and PLATTS_NWE in platts.columns:
        spread = (platts[PLATTS_JKM] - platts[PLATTS_NWE]).dropna()
        colors = [C["positive"] if v >= 0 else C["negative"] for v in spread]
        fig.add_bar(
            x=spread.index, y=spread.values, name="JKM − NWE",
            marker_color=colors, showlegend=False, row=2, col=1,
        )
    fig.add_hline(y=0, line_color=C["zero_line"], line_width=0.6, row=2, col=1)
    if as_of is not None:
        fig.add_vline(
            x=pd.Timestamp(as_of), line_dash="dot",
            line_color=COLORS["text_muted"], line_width=1, row=1, col=1,
        )
        fig.add_vline(
            x=pd.Timestamp(as_of), line_dash="dot",
            line_color=COLORS["text_muted"], line_width=1, row=2, col=1,
        )
    fig.update_layout(**_layout(
        height=560,
        legend={"orientation": "h", "yanchor": "top", "y": -0.08,
                "xanchor": "center", "x": 0.5},
    ))
    fig.update_yaxes(title_text="$/MMBtu", row=1, col=1)
    fig.update_yaxes(title_text="$/MMBtu", row=2, col=1)
    return fig


_HISTORY_SERIES = (
    (COL_ASIA_VS_EU, "Asia vs EU (CoGH)", C["spread"]),
    (COL_PANAMA_VS_EU, "Asia vs EU (Panama)", C["us_panama"]),
)
_TENOR_DASH = {0: "solid", 1: "dash", 2: "dot"}
_TENOR_LABEL = {0: "FM", 1: "M+1", 2: "M+2"}


def fig_netback_history(
    ranked: pd.DataFrame,
    as_of=None,
    title: str = "Netback history",
    *,
    quarterly: bool = False,
) -> go.Figure:
    if ranked is None or ranked.empty:
        return empty_figure("No netback history")
    tenor_label = (
        {0: "FQ", 1: "Q+1", 2: "Q+2"} if quarterly else _TENOR_LABEL
    )
    fig = go.Figure()
    for col, label, color in _HISTORY_SERIES:
        if col not in ranked.columns:
            continue
        for rank, g in ranked.groupby("tenor_rank"):
            rank = int(rank)
            name = label if rank == 0 else f"{label} {tenor_label.get(rank, f'+{rank}')}"
            fig.add_scatter(
                x=g["TRADE_DATE"], y=g[col], name=name,
                mode="lines",
                line={"color": color, "width": 1.8 if rank == 0 else 1.2,
                      "dash": _TENOR_DASH.get(rank, "dot")},
            )
    if as_of is not None:
        fig.add_vline(
            x=pd.Timestamp(as_of), line_dash="dot",
            line_color=COLORS["text_muted"], line_width=1,
        )
    fig.add_hline(y=0, line_color=C["zero_line"], line_width=0.5)
    fig.update_layout(**_BASE, height=400, title=title, yaxis_title="$/mmbtu")
    _add_premium_side_labels(fig)
    return fig


def fig_occupancy(
    occupancy: pd.DataFrame,
    summary: pd.DataFrame | None,
    title: str,
) -> go.Figure:
    if occupancy is None or occupancy.empty:
        return empty_figure("No occupancy history", height=480)

    if summary is not None and not summary.empty and "expired" in summary.columns:
        expired = [
            bool(summary.loc[t, "expired"]) if t in summary.index else False
            for t in occupancy.index
        ]
    else:
        expired = [False] * len(occupancy.index)

    y_labels = [
        f"{t}*" if exp else str(t)
        for t, exp in zip(occupancy.index, expired)
    ]
    y_pos = list(range(len(y_labels)))
    x_labels = list(occupancy.columns)
    z = occupancy.values.astype(float)
    text = np.where(z > 0, z.astype(int).astype(str), "")

    latest_cells: list[tuple[int, int, float, int, bool]] = []
    if summary is not None and not summary.empty and "latest" in summary.columns:
        col_index = {c: j for j, c in enumerate(x_labels)}
        for i, tenor in enumerate(occupancy.index):
            if tenor not in summary.index:
                continue
            row = summary.loc[tenor]
            bucket = row.get("latest_bucket")
            latest_px = row.get("latest")
            if pd.isna(bucket) or bucket not in col_index or pd.isna(latest_px):
                continue
            j = col_index[bucket]
            days = int(z[i, j]) if np.isfinite(z[i, j]) else 0
            text[i, j] = ""
            latest_cells.append((i, j, float(latest_px), days, expired[i]))

    fig = go.Figure(data=go.Heatmap(
        z=z,
        x=x_labels,
        y=y_pos,
        colorscale="YlOrRd",
        colorbar={"title": "Days in bucket", "thickness": 14},
        text=text,
        texttemplate="%{text}",
        textfont={"size": 10, "color": "#333333"},
        customdata=np.tile(
            np.array(y_labels, dtype=object)[:, None],
            (1, max(len(x_labels), 1)),
        ),
        hovertemplate="%{customdata}<br>bucket %{x}<br>%{z:.0f} days<extra></extra>",
        xgap=1, ygap=1,
        hoverongaps=False,
        hoverlabel={
            "bgcolor": "#ffffff",
            "bordercolor": COLORS["border"],
            "font": {"color": COLORS["text_primary"], "size": 12,
                     "family": _GRAPH_FONT},
        },
    ))

    # Grey wash over expired tenors, matching the email heatmap.
    for i, is_exp in enumerate(expired):
        if not is_exp:
            continue
        fig.add_shape(
            type="rect",
            xref="paper",
            yref="y",
            x0=0,
            x1=1,
            y0=i - 0.5,
            y1=i + 0.5,
            fillcolor="rgba(107, 114, 128, 0.28)",
            line_width=0,
            layer="above",
        )

    for i, j, latest_px, days, is_exp in latest_cells:
        edge = "#6b7280" if is_exp else "#1a1a1a"
        fig.add_annotation(
            x=x_labels[j],
            y=i,
            text=f"<b>{latest_px:.2f}</b>",
            showarrow=False,
            font={
                "size": 10,
                "color": "#374151" if is_exp else "#111111",
                "family": _GRAPH_FONT,
            },
            bgcolor="rgba(243,244,246,0.96)" if is_exp else "rgba(255,255,255,0.96)",
            bordercolor=edge,
            borderwidth=1.4,
            borderpad=4,
            align="center",
            hovertext=(
                f"{y_labels[i]} · {x_labels[j]}<br>"
                f"latest {latest_px:.2f} $/mmbtu · {days} days in bucket"
            ),
            hoverlabel={
                "bgcolor": "#ffffff",
                "bordercolor": COLORS["border"],
                "font": {"color": COLORS["text_primary"], "size": 12,
                         "family": _GRAPH_FONT},
            },
        )

    n = len(y_labels)
    # Title, one band per tenor, and room for the angled bucket labels.
    height = 72 + 34 * n + 140
    fig.update_layout(**_layout(
        height=height,
        title=title,
        xaxis_title="Strength ($/mmbtu buckets)",
        yaxis_title="Tenor",
        margin={"l": 90, "r": 50, "t": 64, "b": 130},
        hovermode="closest",
        showlegend=False,
    ))
    # Explicit range keeps the first and last tenor cells inside the axes.
    # Range is [bottom, top], so the earliest tenor (index 0) stays at the top.
    fig.update_xaxes(tickangle=45, type="category", automargin=True)
    fig.update_yaxes(
        type="linear",
        range=[n - 0.5, -0.5],
        tickmode="array",
        tickvals=y_pos,
        ticktext=y_labels,
        automargin=True,
    )
    return fig
