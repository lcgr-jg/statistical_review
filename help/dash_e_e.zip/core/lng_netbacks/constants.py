"""LNG — Netbacks page constants.

Voyage / vessel / bunker numbers match ``eu_reports/lng_netbacks/util.py``.
"""
from __future__ import annotations

from typing import Final

# ── Page registration ──────────────────────────────────────────────────────
PAGE_PATH: Final[str] = "/power/lng/netbacks"
PAGE_NAME: Final[str] = "Netbacks"
PAGE_TITLE: Final[str] = "LNG Netbacks | JG Power Dashboard"
PAGE_ORDER: Final[int] = 85

# ── Scheduler / cache knobs ────────────────────────────────────────────────
SOURCE_NAME: Final[str] = "lng_netbacks_data"
# Settles are daily; offset from low-beta (25) so Snowflake is not hit at once.
CRON: Final[str] = "35 6,12,18 * * 1-5"
TTL_SECONDS: Final[int] = 72 * 60 * 60
# ICE strip pull for the netback panel. The history chart cannot start
# earlier than this, nor earlier than the products themselves: TFU for every
# case, and Spark30S for Spark futures freight.
HISTORY_START_YEAR: Final[int] = 2016
DEFAULT_HISTORY_START_YEAR: Final[int] = 2025
# Platts carrier day rates (standard, not two-stroke) in the spot-prices table.
SPOT_FREIGHT_START: Final[str] = "2010-01-01"
SPOT_FREIGHT_SYMBOLS: Final[tuple[str, ...]] = (
    "AARXT00",  # LNG Asia Pacific Carrier Day Rate
    "AASYC00",  # LNG Atlantic Carrier Day Rate
)
# Drop deliveries further out than this from each trade date (Spark is ~2y).
HORIZON_MONTHS: Final[int] = 24

FRESHNESS_SOURCE_NAME: Final[str] = "LNG Netbacks (ICE / Platts)"
FRESHNESS_EXPECTED_MINUTES: Final[int] = 14 * 60

ICE_PRODUCTS: Final[tuple[str, ...]] = (
    "HH", "JKM", "TFU", "TTF", "Spark25S", "Spark30S",
)

# ── Freight / netback assumptions (report parity) ──────────────────────────
HH_SLOPE: Final[float] = 1.15
DEFAULT_VESSEL: Final[str] = "platts"

VESSEL_SIZES: Final[dict[str, int]] = {
    "platts": 165000,
    "standard": 150000,
    "qflex": 216200,
    "qmax": 266000,
}

FREIGHT_CONSTANTS: Final[dict[str, float]] = {
    "energy_content": 23,  # m3 to mmbtu
    "boiloffrate_laden": 0.0012,
    "boiloffrate_ballast": 0.0009,
    "fillable_volume": 0.985,
    "days_in_port": 1.5,
    "bunker_consumption_rate": 100,
    "bunker_fuel_energy_content": 40.26,
    "insurance_usd_per_day": 2600,
    "bunker_price": 842,
}

# Assume 16 knots
VOYAGES: Final[dict[str, int]] = {
    "us>panama>sk": 26,
    "us>suez>sk": 37,
    "us>sk": 40,
    "us>nl": 13,
}

PORT_COSTS: Final[dict[str, float]] = {
    "nl": 0.28,
    "sk": 0.12,
}

PANAMA_CANAL_FEE: Final[float] = 0.34
SUEZ_CANAL_FEE: Final[float] = 0.45

# ── Column names (report parity) ───────────────────────────────────────────
COL_JKM_SHIFTED: Final[str] = "JKM_shifted"
COL_JKM_TFU: Final[str] = "JKM/TFU"
COL_NL_PROFIT: Final[str] = "US>NL [Profit]"
COL_SK_PROFIT: Final[str] = "US>SK [Profit]"
COL_PANAMA_PROFIT: Final[str] = "US>Panama>SK [Profit]"
COL_SUEZ_PROFIT: Final[str] = "US>Suez>SK [Profit]"
COL_ASIA_VS_EU: Final[str] = "US>Asia vs US>EU [Profit]"
COL_PANAMA_VS_EU: Final[str] = "US>Panama>Asia vs US>EU [Profit]"
COL_SUEZ_VS_EU: Final[str] = "US>Suez>Asia vs US>EU [Profit]"
COL_NL_TOTAL: Final[str] = "US>NL [Total]"
COL_SK_TOTAL: Final[str] = "US>SK [Total]"
COL_PANAMA_TOTAL: Final[str] = "US>Panama>SK [Total]"
COL_SUEZ_TOTAL: Final[str] = "US>Suez>SK [Total]"
COL_FRT_NL: Final[str] = "total_freight_us>nl"
COL_FRT_SK: Final[str] = "total_freight_us>sk"
COL_FRT_PANAMA: Final[str] = "total_freight_us>panama>sk"
COL_FRT_SUEZ: Final[str] = "total_freight_us>suez>sk"
COL_FRT_ASIA: Final[str] = "freight_asia"
COL_FRT_ATLANTIC: Final[str] = "freight_atlantic"

PLATTS_ASIA: Final[str] = "LNG Asia Pacific Carrier Day Rate"
PLATTS_ATLANTIC: Final[str] = "LNG Atlantic Carrier Day Rate"
PLATTS_JKM: Final[str] = "LNG Japan/Korea DES Spot Crg"
PLATTS_MED: Final[str] = "LNG Med DES $/MMBtu"
PLATTS_NWE: Final[str] = "LNG NWE DES $/MMBtu"
PLATTS_WIM: Final[str] = "LNG West India Marker"

PLATTS_SPOT_COLS: Final[tuple[str, ...]] = (
    PLATTS_ASIA, PLATTS_ATLANTIC, PLATTS_JKM, PLATTS_MED, PLATTS_NWE, PLATTS_WIM,
)

# ── UI defaults ────────────────────────────────────────────────────────────
OVERLAY_OFFSETS: Final[tuple[int, ...]] = (1, 7, 14, 28)
FREIGHT_FORWARD: Final[str] = "forward"
FREIGHT_SPOT: Final[str] = "spot"
FREIGHT_SUNK: Final[str] = "sunk"
DEFAULT_FREIGHT_MODE: Final[str] = FREIGHT_FORWARD

DEFAULT_OCC_LOOKBACK: Final[int] = 90
OCC_LOOKBACK_OPTIONS: Final[list[dict]] = [
    {"label": "60 d", "value": 60},
    {"label": "90 d", "value": 90},
    {"label": "180 d", "value": 180},
]
OCC_BUCKET_SIZE: Final[float] = 0.25
OCC_N_TENORS: Final[int] = 18
OCC_N_EXPIRED: Final[int] = 3
DEFAULT_OCC_METRIC: Final[str] = COL_ASIA_VS_EU

OCC_METRIC_OPTIONS: Final[list[dict]] = [
    {"label": "Asia vs EU profit (CoGH)", "value": COL_ASIA_VS_EU},
    {"label": "US → NL profit", "value": COL_NL_PROFIT},
    {"label": "US → SK profit (CoGH)", "value": COL_SK_PROFIT},
    {"label": "Panama vs EU profit", "value": COL_PANAMA_VS_EU},
    {"label": "JKM/TFU", "value": COL_JKM_TFU},
]

HISTORY_TENOR_OPTIONS: Final[list[dict]] = [
    {"label": "Front month", "value": "fm"},
    {"label": "Front month +1", "value": "m1"},
    {"label": "Front month +2", "value": "m2"},
    {"label": "Front 3 months", "value": "front3"},
]
HISTORY_TENOR_OPTIONS_QUARTER: Final[list[dict]] = [
    {"label": "Front quarter", "value": "fm"},
    {"label": "Front quarter +1", "value": "m1"},
    {"label": "Front quarter +2", "value": "m2"},
    {"label": "Front 3 quarters", "value": "front3"},
]
DEFAULT_HISTORY_TENORS: Final[str] = "fm"

GRANULARITY_MONTH: Final[str] = "month"
GRANULARITY_QUARTER: Final[str] = "quarter"
DEFAULT_GRANULARITY: Final[str] = GRANULARITY_MONTH
GRANULARITY_OPTIONS: Final[list[dict]] = [
    {"label": "Monthly", "value": GRANULARITY_MONTH},
    {"label": "Quarterly", "value": GRANULARITY_QUARTER},
]

# Platts spot freight chart. Year-on-year is one basin at a time.
FREIGHT_VIEW_HISTORY: Final[str] = "history"
FREIGHT_VIEW_YOY: Final[str] = "yoy"
DEFAULT_FREIGHT_VIEW: Final[str] = FREIGHT_VIEW_HISTORY
FREIGHT_BASIN_ASIA: Final[str] = "asia"
FREIGHT_BASIN_ATLANTIC: Final[str] = "atlantic"
DEFAULT_FREIGHT_BASIN: Final[str] = FREIGHT_BASIN_ASIA
FREIGHT_YOY_RANGE: Final[str] = "range"
FREIGHT_YOY_LINES: Final[str] = "lines"
DEFAULT_FREIGHT_YOY: Final[str] = FREIGHT_YOY_RANGE

# Snapshot overlay history relative to the as-of date.
SNAPSHOT_OFFSETS: Final[tuple[int, ...]] = OVERLAY_OFFSETS

# Report palette
ROUTE_COLORS: Final[dict[str, str]] = {
    "us_nl": "#4A90A4",
    "us_sk": "#5B9A6F",
    "us_panama": "#D4864A",
    "us_suez": "#9B7CB4",
    "jkm": "#E8A54B",
    "tfu": "#5A9BD4",
    "hh": "#C45B5B",
    "hh_liq": "#D98080",
    "freight_asia": "#8E6BAD",
    "freight_atlantic": "#4BA3A3",
    "positive": "#5A9BD4",
    "negative": "#A8C8E8",
    "positive_alt": "#E8A54B",
    "negative_alt": "#F5D5A0",
    "zero_line": "#333333",
    "spread": "#7B68A0",
}
FREIGHT_STACK_COLORS: Final[tuple[str, ...]] = ("#7A8B8B", "#9FAFAF", "#5A6A6A")
