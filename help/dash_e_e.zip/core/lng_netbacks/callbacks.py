"""Callbacks for the LNG — Netbacks page.

All figures are sliced from the cached ICE/Platts netback panels. Snowflake
is not queried on click.
"""
from __future__ import annotations

import logging

import pandas as pd
from dash import Input, Output, callback, html

from core.lng_netbacks.calc import (
    aggregate_curve,
    aggregate_panel_quarters,
    build_jkm_tfu_table,
    build_occupancy,
    front_month_ranks,
)
from core.lng_netbacks.charts import (
    empty_figure,
    fig_cost_stack,
    fig_forward_freight,
    fig_netback_history,
    fig_netback_premium,
    fig_occupancy,
    fig_price_curves,
    fig_profit_margins,
    fig_spot_freight,
    fig_spot_freight_yoy,
    fig_spot_prices,
)
from core.lng_netbacks.constants import (
    COL_JKM_TFU,
    DEFAULT_FREIGHT_BASIN,
    DEFAULT_FREIGHT_MODE,
    DEFAULT_FREIGHT_VIEW,
    DEFAULT_FREIGHT_YOY,
    DEFAULT_GRANULARITY,
    DEFAULT_HISTORY_START_YEAR,
    DEFAULT_HISTORY_TENORS,
    DEFAULT_OCC_LOOKBACK,
    DEFAULT_OCC_METRIC,
    FREIGHT_BASIN_ASIA,
    FREIGHT_BASIN_ATLANTIC,
    FREIGHT_FORWARD,
    FREIGHT_SPOT,
    FREIGHT_SUNK,
    GRANULARITY_QUARTER,
    HISTORY_TENOR_OPTIONS,
    HISTORY_TENOR_OPTIONS_QUARTER,
    FREIGHT_VIEW_YOY,
    FREIGHT_YOY_LINES,
    FREIGHT_YOY_RANGE,
    OCC_BUCKET_SIZE,
    OCC_METRIC_OPTIONS,
    OCC_N_EXPIRED,
    OCC_N_TENORS,
    OVERLAY_OFFSETS,
    PLATTS_ASIA,
    PLATTS_ATLANTIC,
    ROUTE_COLORS,
)
from core.lng_netbacks.data import (
    get_payload,
    panel_for,
    resolve_as_of,
    snapshot_curves,
)
from core.lng_netbacks.tables import jkm_tfu_table
from core.styles import COLORS, get_status_badge_style

logger = logging.getLogger(__name__)

_NO_DATA = (
    "LNG netbacks data is not loaded yet — the cache warms in the "
    "background shortly after start-up. Refresh the page in a minute."
)

_METRIC_LABELS = {opt["value"]: opt["label"] for opt in OCC_METRIC_OPTIONS}


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(message, style={
        **get_status_badge_style(level),
        "padding": "10px 14px",
        "borderRadius": "8px",
        "fontSize": "13px",
        "width": "100%",
    })


def _parse_date(value):
    if not value:
        return None
    try:
        return pd.Timestamp(value).normalize()
    except Exception:
        return None


def _quarter_overlays(overlays: dict) -> dict:
    return {
        dt: aggregate_curve(df)
        for dt, df in overlays.items()
        if df is not None and not df.empty
    }


def _asof_label(prefix: str, as_of) -> str:
    return f"{prefix}: {pd.Timestamp(as_of).strftime('%d %b')}"


def _overlays(curves: dict, as_of) -> dict:
    as_of_ts = pd.Timestamp(as_of).normalize()
    return {
        dt: df for dt, df in curves.items()
        if pd.Timestamp(dt).normalize() != as_of_ts and df is not None and not df.empty
    }


def _occ_style(fig) -> dict:
    """Match the graph div to the figure so the last tenor is not clipped."""
    height = getattr(fig.layout, "height", None) or 720
    return {"height": f"{int(height)}px"}


def _empty_snapshot():
    empty = empty_figure("Waiting for netbacks cache")
    return (
        empty, empty, empty, empty, empty, empty, empty, empty, empty,
        empty, empty, html.Div(), empty, _occ_style(empty),
        empty,
        _alert(_NO_DATA),
    )


@callback(
    Output("nb-premium-fwd", "figure"),
    Output("nb-premium-spot", "figure"),
    Output("nb-premium-sunk", "figure"),
    Output("nb-margins-fwd", "figure"),
    Output("nb-margins-spot", "figure"),
    Output("nb-margins-sunk", "figure"),
    Output("nb-stack-fwd", "figure"),
    Output("nb-stack-spot", "figure"),
    Output("nb-stack-sunk", "figure"),
    Output("nb-freight-fwd", "figure"),
    Output("nb-price-curves", "figure"),
    Output("nb-jkm-table", "children"),
    Output("nb-jkm-occupancy", "figure"),
    Output("nb-jkm-occupancy", "style"),
    Output("nb-spot-prices", "figure"),
    Output("nb-status", "children"),
    Input("nb-as-of", "date"),
    Input("nb-occ-lookback", "value"),
    Input("nb-granularity", "value"),
)
def update_snapshot(as_of_value, lookback, granularity):
    payload = get_payload()
    if not payload:
        return _empty_snapshot()

    as_of = resolve_as_of(payload, _parse_date(as_of_value) or payload["as_of"])
    if as_of is None:
        return _empty_snapshot()

    lookback = int(lookback or DEFAULT_OCC_LOOKBACK)
    fwd_curves = snapshot_curves(payload, as_of, FREIGHT_FORWARD, OVERLAY_OFFSETS)
    spot_as_of = resolve_as_of(payload, as_of, FREIGHT_SPOT) or as_of
    spot_curves = snapshot_curves(
        payload, spot_as_of, FREIGHT_SPOT, OVERLAY_OFFSETS)
    df_fwd = fwd_curves.get(as_of, pd.DataFrame())
    df_spot = spot_curves.get(spot_as_of, pd.DataFrame())
    sunk_as_of = resolve_as_of(payload, as_of, FREIGHT_SUNK)
    if sunk_as_of is None:
        sunk_curves: dict = {}
        df_sunk = pd.DataFrame()
    else:
        sunk_curves = snapshot_curves(
            payload, sunk_as_of, FREIGHT_SUNK, OVERLAY_OFFSETS)
        df_sunk = sunk_curves.get(sunk_as_of, pd.DataFrame())
    ov_fwd = _overlays(fwd_curves, as_of)
    ov_spot = _overlays(spot_curves, spot_as_of)
    ov_sunk = _overlays(sunk_curves, sunk_as_of) if sunk_as_of is not None else {}
    quarterly = (granularity or DEFAULT_GRANULARITY) == GRANULARITY_QUARTER
    if quarterly:
        df_fwd, ov_fwd = aggregate_curve(df_fwd), _quarter_overlays(ov_fwd)
        df_spot, ov_spot = aggregate_curve(df_spot), _quarter_overlays(ov_spot)
        df_sunk, ov_sunk = aggregate_curve(df_sunk), _quarter_overlays(ov_sunk)

    as_of_fmt = as_of.strftime("%d %b %Y")
    requested = _parse_date(as_of_value)
    snap_note = ""
    if requested is not None and requested.normalize() != as_of:
        snap_note = (
            f" Requested {requested.strftime('%d %b %Y')} has no ICE settle; "
            f"using {as_of_fmt}."
        )
    overlay_lbl = ", ".join(
        f"T-{(as_of - pd.Timestamp(d).normalize()).days} "
        f"({pd.Timestamp(d).strftime('%d %b')})"
        for d in sorted(ov_fwd.keys(), reverse=True)
    ) or "none"

    status = _alert(
        f"Settlements from {as_of_fmt}.{snap_note} Overlays: {overlay_lbl}.",
        level="success",
    )

    premium_fwd = fig_netback_premium(
        df_fwd, ov_fwd, as_of,
        _asof_label("Netback Premium — Spark freight", as_of),
        quarterly=quarterly,
    )
    premium_spot = fig_netback_premium(
        df_spot, ov_spot, as_of,
        _asof_label("Netback Premium — Platts spot", as_of),
        quarterly=quarterly,
    )
    premium_sunk = fig_netback_premium(
        df_sunk, ov_sunk, sunk_as_of or as_of,
        _asof_label("Netback Premium — Sunk freight", sunk_as_of or as_of),
        quarterly=quarterly,
    )
    margins_fwd = fig_profit_margins(
        df_fwd, ov_fwd, as_of,
        _asof_label("Profit Margins — Spark freight", as_of),
        quarterly=quarterly,
    )
    margins_spot = fig_profit_margins(
        df_spot, ov_spot, as_of,
        _asof_label("Profit Margins — Platts spot", as_of),
        quarterly=quarterly,
    )
    margins_sunk = fig_profit_margins(
        df_sunk, ov_sunk, sunk_as_of or as_of,
        _asof_label("Profit Margins — Sunk freight", sunk_as_of or as_of),
        quarterly=quarterly,
    )
    stack_fwd = fig_cost_stack(
        df_fwd,
        _asof_label("Cost Stack — Spark freight", as_of),
        use_forward_freight=True,
        quarterly=quarterly,
    )
    stack_spot = fig_cost_stack(
        df_spot,
        _asof_label("Cost Stack — Platts spot", as_of),
        use_forward_freight=False,
        quarterly=quarterly,
    )
    stack_sunk = fig_cost_stack(
        df_sunk,
        _asof_label("Cost Stack — Sunk freight", sunk_as_of or as_of),
        show_day_rates=False,
        quarterly=quarterly,
    )
    freight_fwd = fig_forward_freight(
        df_fwd, ov_fwd, as_of,
        _asof_label("LNG Forward Freight Rates ($/day)", as_of),
    )
    prices = fig_price_curves(
        df_fwd, ov_fwd, as_of,
        _asof_label("HH, TFU & JKM Forward Curves ($/MMBtu)", as_of),
    )
    table = jkm_tfu_table(build_jkm_tfu_table(fwd_curves))

    occ, summary = build_occupancy(
        panel_for(payload, FREIGHT_FORWARD),
        COL_JKM_TFU,
        lookback_days=lookback,
        bucket_size=OCC_BUCKET_SIZE,
        n_tenors=OCC_N_TENORS,
        n_expired=OCC_N_EXPIRED,
        as_of=as_of,
    )
    window_start = as_of - pd.Timedelta(days=lookback)
    jkm_occ = fig_occupancy(
        occ, summary,
        title=(
            f"JKM/TFU strength vs persistence — last {lookback}d "
            f"({window_start.date()} → {as_of.date()}), "
            f"{OCC_BUCKET_SIZE:.2f} $/mmbtu buckets"
        ),
    )

    platts = payload.get("platts")
    spot_prices = fig_spot_prices(platts, as_of)

    return (
        premium_fwd, premium_spot, premium_sunk,
        margins_fwd, margins_spot, margins_sunk,
        stack_fwd, stack_spot, stack_sunk,
        freight_fwd, prices, table,
        jkm_occ, _occ_style(jkm_occ),
        spot_prices, status,
    )


_FREIGHT_BASINS = {
    FREIGHT_BASIN_ASIA: (PLATTS_ASIA, "Asia Pacific", ROUTE_COLORS["freight_asia"]),
    FREIGHT_BASIN_ATLANTIC: (
        PLATTS_ATLANTIC, "Atlantic", ROUTE_COLORS["freight_atlantic"],
    ),
}


@callback(
    Output("nb-freight-spot", "figure"),
    Output("nb-freight-spot", "style"),
    Input("nb-as-of", "date"),
    Input("nb-freight-view", "value"),
    Input("nb-freight-basin", "value"),
    Input("nb-freight-yoy-style", "value"),
)
def update_spot_freight(as_of_value, view, basin, yoy_style):
    payload = get_payload()
    empty = empty_figure("Waiting for netbacks cache")
    if not payload:
        return empty, _occ_style(empty)
    as_of = resolve_as_of(payload, _parse_date(as_of_value) or payload["as_of"])
    platts = payload.get("platts")
    view = view or DEFAULT_FREIGHT_VIEW
    if view != FREIGHT_VIEW_YOY:
        fig = fig_spot_freight(platts, as_of)
        return fig, _occ_style(fig)
    col, label, color = _FREIGHT_BASINS.get(
        basin or DEFAULT_FREIGHT_BASIN, _FREIGHT_BASINS[FREIGHT_BASIN_ASIA],
    )
    series = pd.Series(dtype=float)
    if platts is not None and col in getattr(platts, "columns", []):
        series = platts[col]
    fig = fig_spot_freight_yoy(
        series, label=label, color=color,
        style=yoy_style or DEFAULT_FREIGHT_YOY,
        as_of=as_of,
    )
    return fig, _occ_style(fig)


def _history_ranks(selection) -> tuple[int, ...]:
    """Tenor ranks for the history radio. 0 is the front month."""
    key = str(selection or DEFAULT_HISTORY_TENORS)
    return {
        "fm": (0,),
        "1": (0,),
        "m1": (1,),
        "m2": (2,),
        "front3": (0, 1, 2),
        "3": (0, 1, 2),
    }.get(key, (0,))


def _freight_label(freight_mode: str) -> str:
    if freight_mode == FREIGHT_FORWARD:
        return "Spark futures"
    if freight_mode == FREIGHT_SUNK:
        return "Sunk shipping"
    return "Platts spot"


@callback(
    Output("nb-hist-tenors", "options"),
    Input("nb-history-granularity", "value"),
)
def update_history_tenor_labels(granularity):
    if (granularity or DEFAULT_GRANULARITY) == GRANULARITY_QUARTER:
        return HISTORY_TENOR_OPTIONS_QUARTER
    return HISTORY_TENOR_OPTIONS


@callback(
    Output("nb-history", "figure"),
    Input("nb-as-of", "date"),
    Input("nb-history-freight", "value"),
    Input("nb-hist-tenors", "value"),
    Input("nb-history-granularity", "value"),
    Input("nb-history-start-year", "value"),
)
def update_history(as_of_value, history_freight, n_tenors, granularity, start_year):
    payload = get_payload()
    empty = empty_figure("Waiting for netbacks cache")
    if not payload:
        return empty

    history_freight = history_freight or DEFAULT_FREIGHT_MODE
    quarterly = (granularity or DEFAULT_GRANULARITY) == GRANULARITY_QUARTER
    ranks = _history_ranks(n_tenors)
    requested = _parse_date(as_of_value) or payload["as_of"]
    hist_as_of = resolve_as_of(payload, requested, history_freight)
    if hist_as_of is None:
        return empty_figure("No netbacks for this freight mode")

    hist_panel = panel_for(payload, history_freight)
    hist = hist_panel.loc[pd.to_datetime(hist_panel["TRADE_DATE"]) <= hist_as_of]
    year = int(start_year or DEFAULT_HISTORY_START_YEAR)
    hist = hist.loc[pd.to_datetime(hist["TRADE_DATE"]) >= pd.Timestamp(year, 1, 1)]
    if quarterly:
        hist = aggregate_panel_quarters(hist)
    ranked = front_month_ranks(hist, n_tenors=max(ranks) + 1)
    if not ranked.empty:
        ranked = ranked.loc[ranked["tenor_rank"].isin(ranks)]
    grain = "quarterly" if quarterly else "monthly"
    return fig_netback_history(
        ranked, as_of=hist_as_of, quarterly=quarterly,
        title=(
            f"Netback history ({_freight_label(history_freight)}, {grain}, "
            f"from {year}, through {hist_as_of.strftime('%d %b %Y')})"
        ),
    )


@callback(
    Output("nb-occupancy", "figure"),
    Output("nb-occupancy", "style"),
    Input("nb-as-of", "date"),
    Input("nb-freight-mode", "value"),
    Input("nb-occ-metric", "value"),
    Input("nb-occ-lookback", "value"),
)
def update_occupancy(as_of_value, freight_mode, metric, lookback):
    payload = get_payload()
    empty = empty_figure("Waiting for netbacks cache", height=480)
    if not payload:
        return empty, _occ_style(empty)

    freight_mode = freight_mode or DEFAULT_FREIGHT_MODE
    metric = metric or DEFAULT_OCC_METRIC
    lookback = int(lookback or DEFAULT_OCC_LOOKBACK)
    requested = _parse_date(as_of_value) or payload["as_of"]
    occ_as_of = resolve_as_of(payload, requested, freight_mode)
    if occ_as_of is None:
        empty = empty_figure("No netbacks for this freight mode", height=480)
        return empty, _occ_style(empty)

    occ_panel = panel_for(payload, freight_mode)
    occ_hist = occ_panel.loc[
        pd.to_datetime(occ_panel["TRADE_DATE"]) <= occ_as_of
    ]
    mode_lbl = _freight_label(freight_mode)
    occ, summary = build_occupancy(
        occ_hist, metric,
        lookback_days=lookback,
        bucket_size=OCC_BUCKET_SIZE,
        n_tenors=OCC_N_TENORS,
        n_expired=OCC_N_EXPIRED,
        as_of=occ_as_of,
    )
    window_start = occ_as_of - pd.Timedelta(days=lookback)
    occ_fig = fig_occupancy(
        occ, summary,
        title=(
            f"{_METRIC_LABELS.get(metric, metric)} strength vs persistence — "
            f"last {lookback}d ({window_start.date()} → {occ_as_of.date()}), "
            f"{OCC_BUCKET_SIZE:.2f} $/mmbtu buckets ({mode_lbl})"
        ),
    )
    return occ_fig, _occ_style(occ_fig)
