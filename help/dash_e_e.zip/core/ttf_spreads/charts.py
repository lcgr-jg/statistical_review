"""Plotly figure builders for the TTF Spreads Monitor page."""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from core.styles import COLORS
from core.ttf_spreads.constants import CRISIS_YEARS

# Match the email's rich/cheap palette.
RICH_COLOR = "#b23a48"
CHEAP_COLOR = "#3d7a5a"
BAND_FILL = "rgba(52, 152, 219, 0.10)"
MEAN_COLOR = "#7f8c8d"

# One tooltip for the nearest point only.  Default Plotly ``x`` / ``x unified``
# compare mode also pulls in the sparse ICE/BBG markers (their only points),
# so hovering mid-September still shows the 16-Sep BBG diamond in the same box.
# Explicit hoverlabel keeps text dark — the dashboard template's unified-hover
# styling alone can leave closest-mode tooltips looking washed out.
_HOVER_LAYOUT = {
    "hovermode": "closest",
    "hoverdistance": 12,
    "hoverlabel": {
        "bgcolor": "#ffffff",
        "bordercolor": COLORS["border"],
        "font": {
            "family": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
            "size": 13,
            "color": COLORS["text_primary"],
        },
    },
}


def build_empty_chart(message: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        xaxis={"visible": False},
        yaxis={"visible": False},
        annotations=[{
            "text": message,
            "xref": "paper", "yref": "paper",
            "x": 0.5, "y": 0.5,
            "showarrow": False,
            "font": {"size": 13, "color": COLORS["text_muted"]},
        }],
        height=420,
    )
    return fig


def _filtered_hist(series: pd.Series,
                   exclude_crisis: bool,
                   history_start: Optional[pd.Timestamp],
                   live_date: pd.Timestamp) -> pd.Series:
    """The same stats sample the table uses (live value always retained)."""
    hist = series
    if history_start is not None:
        hist = hist[(hist.index >= history_start) | (hist.index == live_date)]
    if exclude_crisis:
        hist = hist[~hist.index.year.isin(CRISIS_YEARS)]
    return hist


def _add_crisis_shading(fig: go.Figure, series: pd.Series, excluded: bool):
    """Shade the crisis years so it is visible what is in/out of the stats."""
    for year in CRISIS_YEARS:
        y0, y1 = pd.Timestamp(year, 1, 1), pd.Timestamp(year + 1, 1, 1)
        if series.index.max() < y0 or series.index.min() > y1:
            continue
        fig.add_vrect(
            x0=y0, x1=y1,
            fillcolor="rgba(178, 58, 72, 0.06)" if excluded else "rgba(178, 58, 72, 0.12)",
            line_width=0,
            layer="below",
        )
    label = ("crisis years shaded (excluded from stats)" if excluded
             else "crisis years shaded (included in stats)")
    fig.add_annotation(
        text=label,
        xref="paper", yref="paper", x=0, y=1.08,
        showarrow=False,
        font={"size": 10, "color": COLORS["text_muted"]},
    )


def build_history_chart(entry: dict,
                        exclude_crisis: bool,
                        history_start: Optional[pd.Timestamp],
                        live_date: pd.Timestamp,
                        live_mark: Optional[float] = None,
                        mark_date: Optional[pd.Timestamp] = None) -> go.Figure:
    """Full rolling generic history with mean / percentile band under the
    currently selected options, crisis shading and the live settle marker.

    ``live_mark`` (optional Bloomberg mid) is plotted as a distinct marker at
    ``mark_date`` (default: today) alongside the ICE settle on ``live_date``.
    """
    series = entry["series"].sort_index()
    hist = _filtered_hist(series, exclude_crisis, history_start, live_date)

    settle = series.loc[live_date] if live_date in series.index else np.nan
    mean = hist.mean()
    p10, p90 = hist.quantile(0.10), hist.quantile(0.90)

    fig = go.Figure()

    # 10-90 percentile band of the stats sample.
    fig.add_trace(go.Scatter(
        x=[series.index.min(), series.index.max()],
        y=[p90, p90],
        mode="lines", line={"width": 0},
        hoverinfo="skip", showlegend=False,
    ))
    fig.add_trace(go.Scatter(
        x=[series.index.min(), series.index.max()],
        y=[p10, p10],
        mode="lines", line={"width": 0},
        fill="tonexty", fillcolor=BAND_FILL,
        name="10-90 %ile",
        hoverinfo="skip",
    ))

    fig.add_trace(go.Scatter(
        x=series.index, y=series.values,
        mode="lines",
        name=entry["legs"],
        line={"width": 1.4, "color": COLORS["accent"]},
        hovertemplate=(
            "<b>ICE history</b><br>"
            "%{x|%d %b %Y}<br>"
            "%{y:.3f} €/MWh"
            "<extra></extra>"
        ),
    ))

    fig.add_hline(
        y=mean, line={"color": MEAN_COLOR, "width": 1, "dash": "dash"},
        annotation_text=f"mean {mean:.3f}",
        annotation_font={"size": 10, "color": MEAN_COLOR},
    )

    if not np.isnan(settle):
        marker_color = RICH_COLOR if settle >= mean else CHEAP_COLOR
        fig.add_trace(go.Scatter(
            x=[live_date], y=[settle],
            mode="markers",
            name=f"ICE {settle:.3f}",
            marker={"size": 10, "color": marker_color,
                    "line": {"width": 1.5, "color": "#ffffff"}},
            hovertemplate=(
                f"<b>ICE settle</b><br>"
                f"{live_date:%d %b %Y}<br>"
                f"%{{y:.3f}} €/MWh"
                f"<extra></extra>"
            ),
        ))

    if live_mark is not None and not (isinstance(live_mark, float)
                                      and np.isnan(live_mark)):
        bbg_date = pd.Timestamp(mark_date).normalize() if mark_date is not None \
            else pd.Timestamp.now().normalize()
        fig.add_trace(go.Scatter(
            x=[bbg_date], y=[float(live_mark)],
            mode="markers",
            name=f"BBG {float(live_mark):.3f}",
            marker={"size": 12, "symbol": "diamond",
                    "color": "#e67e22",
                    "line": {"width": 1.5, "color": "#ffffff"}},
            hovertemplate=(
                f"<b>BBG live</b><br>"
                f"{bbg_date:%d %b %Y}<br>"
                f"%{{y:.3f}} €/MWh"
                f"<extra></extra>"
            ),
        ))

    _add_crisis_shading(fig, series, excluded=exclude_crisis)

    if history_start is not None and history_start > series.index.min():
        # add_vline(annotation_text=...) chokes on Timestamp x in this plotly
        # version; draw the line + label manually instead.
        fig.add_shape(
            type="line",
            x0=history_start, x1=history_start,
            yref="paper", y0=0, y1=1,
            line={"color": COLORS["text_muted"], "width": 1, "dash": "dot"},
        )
        fig.add_annotation(
            x=history_start, yref="paper", y=1.02,
            text="stats window start",
            showarrow=False,
            font={"size": 9, "color": COLORS["text_muted"]},
        )

    fig.update_layout(
        title={
            "text": f"{entry['cadence']}  ·  {entry['legs']}  ·  rolling generic history",
            "font": {"size": 14},
        },
        yaxis_title="Spread (€/MWh)",
        height=420,
        margin={"l": 60, "r": 20, "t": 70, "b": 70},
        legend={"orientation": "h", "yanchor": "top", "y": -0.12,
                "xanchor": "left", "x": 0},
        **_HOVER_LAYOUT,
    )
    return fig


def build_ytd_chart(entry: dict, live_date: pd.Timestamp,
                    live_mark: Optional[float] = None,
                    mark_date: Optional[pd.Timestamp] = None) -> go.Figure:
    """Current-year view of the same rolling series."""
    series = entry["series"].sort_index()
    ytd = series[series.index.year == pd.Timestamp(live_date).year]

    fig = go.Figure()
    if ytd.empty:
        return build_empty_chart("No trades this year yet.")

    fig.add_trace(go.Scatter(
        x=ytd.index, y=ytd.values,
        mode="lines",
        name=entry["legs"],
        line={"width": 1.6, "color": COLORS["accent"]},
        hovertemplate=(
            "<b>ICE history</b><br>"
            "%{x|%d %b %Y}<br>"
            "%{y:.3f} €/MWh"
            "<extra></extra>"
        ),
    ))

    hi, lo = float(ytd.max()), float(ytd.min())
    fig.add_hline(y=hi, line={"color": RICH_COLOR, "width": 1, "dash": "dot"},
                  annotation_text=f"YTD high {hi:.3f}",
                  annotation_font={"size": 10, "color": RICH_COLOR})
    fig.add_hline(y=lo, line={"color": CHEAP_COLOR, "width": 1, "dash": "dot"},
                  annotation_text=f"YTD low {lo:.3f}",
                  annotation_font={"size": 10, "color": CHEAP_COLOR})

    if live_date in ytd.index:
        settle = ytd.loc[live_date]
        fig.add_trace(go.Scatter(
            x=[live_date], y=[settle],
            mode="markers",
            name=f"ICE {settle:.3f}",
            marker={"size": 10, "color": COLORS["accent"],
                    "line": {"width": 1.5, "color": "#ffffff"}},
            hovertemplate=(
                f"<b>ICE settle</b><br>"
                f"{live_date:%d %b %Y}<br>"
                f"%{{y:.3f}} €/MWh"
                f"<extra></extra>"
            ),
        ))

    if live_mark is not None and not (isinstance(live_mark, float)
                                      and np.isnan(live_mark)):
        bbg_date = pd.Timestamp(mark_date).normalize() if mark_date is not None \
            else pd.Timestamp.now().normalize()
        fig.add_trace(go.Scatter(
            x=[bbg_date], y=[float(live_mark)],
            mode="markers",
            name=f"BBG {float(live_mark):.3f}",
            marker={"size": 12, "symbol": "diamond",
                    "color": "#e67e22",
                    "line": {"width": 1.5, "color": "#ffffff"}},
            hovertemplate=(
                f"<b>BBG live</b><br>"
                f"{bbg_date:%d %b %Y}<br>"
                f"%{{y:.3f}} €/MWh"
                f"<extra></extra>"
            ),
        ))

    fig.update_layout(
        title={"text": "Year to date", "font": {"size": 14}},
        yaxis_title="Spread (€/MWh)",
        height=420,
        margin={"l": 60, "r": 20, "t": 70, "b": 70},
        legend={"orientation": "h", "yanchor": "top", "y": -0.12,
                "xanchor": "left", "x": 0},
        **_HOVER_LAYOUT,
    )
    return fig
