"""TTF Spreads Monitor page package."""
