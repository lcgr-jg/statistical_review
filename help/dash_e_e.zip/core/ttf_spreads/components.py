"""Cards + stats-table builders for the TTF Spreads Monitor page."""
from __future__ import annotations

import pandas as pd
from dash import html
from dash.dash_table.Format import Format, Scheme, Sign

from core.bbg_spreads.highlights import dod_highlight_styles
from core.styles import COLORS
from core.ttf_spreads.constants import N_CARDS

# Email palette: pink = rich/high, green = cheap/low.
_WHITE = (255, 255, 255)
_PINK = (224, 150, 166)
_GREEN = (193, 208, 178)

FLAG_COLORS = {
    "RICH": ("#b23a48", "#ffffff"),
    "CHEAP": ("#3d7a5a", "#ffffff"),
    "NEUTRAL": ("#9aa0a6", "#ffffff"),
}


def _lerp(c1, c2, t):
    return tuple(int(round(a + (b - a) * t)) for a, b in zip(c1, c2))


def _heat(t: float) -> str:
    """t in [-1, 1]: negative -> green, 0 -> white, positive -> pink."""
    t = max(-1.0, min(1.0, t))
    r, g, b = _lerp(_WHITE, _PINK, t) if t >= 0 else _lerp(_WHITE, _GREEN, -t)
    return f"rgb({r},{g},{b})"


def heat_pct(pct: float) -> str:
    return _heat((pct - 50.0) / 50.0)


def heat_z(z: float) -> str:
    return _heat(z / 2.0)


# ---------------------------------------------------------------------------
# Headline cards
# ---------------------------------------------------------------------------

def _badge(flag: str) -> html.Span:
    bg, fg = FLAG_COLORS[flag]
    return html.Span(
        flag,
        style={
            "backgroundColor": bg,
            "color": fg,
            "padding": "4px 12px",
            "borderRadius": "4px",
            "fontSize": "11px",
            "fontWeight": "700",
            "letterSpacing": "0.5px",
        },
    )


def _card(row: pd.Series, live_mode: bool = False) -> html.Div:
    level_label = "Live" if live_mode and row.get("price_source") == "bbg" else "Settle"
    level_line = f"{level_label} {row['live']:.3f} €/MWh · %ile {row['pct']:.0f}"
    if live_mode and "settle" in row.index and pd.notna(row.get("settle")):
        level_line += f" · ICE {row['settle']:.3f}"
    return html.Div(
        style={
            "flex": "1 1 260px",
            "minWidth": "240px",
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "8px",
            "padding": "14px 16px",
            "backgroundColor": COLORS["card_bg"],
        },
        children=[
            html.Div(
                row["cadence"],
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "textTransform": "uppercase",
                    "letterSpacing": "0.5px",
                },
            ),
            html.Div(
                style={
                    "display": "flex",
                    "justifyContent": "space-between",
                    "alignItems": "baseline",
                    "marginTop": "4px",
                },
                children=[
                    html.Div(
                        row["legs"],
                        style={
                            "fontSize": "17px",
                            "fontWeight": "700",
                            "color": COLORS["text_primary"],
                        },
                    ),
                    html.Div(
                        f"z {row['z']:+.2f}",
                        style={
                            "fontSize": "17px",
                            "fontWeight": "700",
                            "color": COLORS["text_primary"],
                            "whiteSpace": "nowrap",
                        },
                    ),
                ],
            ),
            html.Div(_badge(row["flag"]), style={"marginTop": "10px"}),
            html.Div(
                level_line,
                style={
                    "fontSize": "13px",
                    "color": COLORS["text_secondary"],
                    "marginTop": "10px",
                },
            ),
            html.Div(
                f"n={row['n']:,}",
                style={
                    "fontSize": "12px",
                    "color": COLORS["text_muted"],
                    "marginTop": "2px",
                },
            ),
        ],
    )


def build_cards(res: pd.DataFrame, live_mode: bool = False) -> html.Div:
    """Top-N extreme spreads by |z| (already sorted by the stats table)."""
    if res.empty:
        return html.Div(
            "No spreads with sufficient history.",
            style={"fontSize": "13px", "color": COLORS["text_muted"]},
        )
    return html.Div(
        style={"display": "flex", "flexWrap": "wrap", "gap": "14px"},
        children=[_card(row, live_mode=live_mode)
                  for _, row in res.head(N_CARDS).iterrows()],
    )


# ---------------------------------------------------------------------------
# Stats table
# ---------------------------------------------------------------------------

_SETTLE_COLUMNS = [
    {"name": "Granularity", "id": "cadence"},
    {"name": "Legs (front / back)", "id": "legs"},
    {"name": "Settle", "id": "live", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "DoD Δ", "id": "dod", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "YTD High", "id": "ytd_high", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "YTD Low", "id": "ytd_low", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "ATH", "id": "ath", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "ATL", "id": "atl", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "%ile", "id": "pct", "type": "numeric",
     "format": Format(precision=0, scheme=Scheme.fixed)},
    {"name": "z", "id": "z", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "Mean", "id": "mean", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "n", "id": "n", "type": "numeric"},
    {"name": "Flag", "id": "flag"},
]

_LIVE_COLUMNS = [
    {"name": "Granularity", "id": "cadence"},
    {"name": "Legs (front / back)", "id": "legs"},
    {"name": "Live", "id": "live", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "ICE settle", "id": "settle", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "Δ vs settle", "id": "dod", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "Δ z", "id": "dod_z", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "YTD High", "id": "ytd_high", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "YTD Low", "id": "ytd_low", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "ATH", "id": "ath", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "ATL", "id": "atl", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "%ile", "id": "pct", "type": "numeric",
     "format": Format(precision=0, scheme=Scheme.fixed)},
    {"name": "z", "id": "z", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "Mean", "id": "mean", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "n", "id": "n", "type": "numeric"},
    {"name": "Flag", "id": "flag"},
]

# Default export for layout first paint (settlement mode).
TABLE_COLUMNS = _SETTLE_COLUMNS

TABLE_HEADER_TOOLTIPS = {
    "live": "Latest settlement of the rolling generic spread (€/MWh). "
            "Highlighted when it sets the YTD or all-time high/low. "
            "In Bloomberg live mode this is the live mid/last.",
    "settle": "Last ICE settlement for the same rolling generic spread.",
    "dod": "Settlement mode: change vs the previous settle. "
           "Live mode: live mark minus last ICE settle.",
    "dod_z": "Intraday move (live − settle) divided by the std of historical "
             "daily changes of this spread. |Δz| ≥ 1.5 = outsized.",
    "ytd_high": "Highest settle of the rolling series this calendar year.",
    "ytd_low": "Lowest settle of the rolling series this calendar year.",
    "ath": "All-time high of the rolling generic series over the full loaded "
           "history (unaffected by the stats options).",
    "atl": "All-time low of the rolling generic series over the full loaded "
           "history (unaffected by the stats options).",
    "pct": "Percentile of the latest level vs the selected stats history.",
    "z": "(level − mean) / std over the selected stats history.",
    "mean": "Mean of the selected stats history.",
    "n": "Observations in the selected stats history.",
    "flag": "RICH = sell-bias, CHEAP = buy-bias vs own history.",
}


def table_columns(live_mode: bool = False) -> list[dict]:
    return list(_LIVE_COLUMNS if live_mode else _SETTLE_COLUMNS)


# Backgrounds for at-extreme highlights (soft pastels; bold text carries the
# emphasis).
AT_HIGH_BG = "rgb(249, 224, 229)"   # pastel pink — settle printing a new high
AT_LOW_BG = "rgb(228, 238, 223)"    # pastel green — settle printing a new low
SELECTED_ROW_BG = "rgba(52, 152, 219, 0.12)"

_EPS = 1e-9


def build_table_records(res: pd.DataFrame, key_fn,
                        live_mode: bool = False) -> list[dict]:
    """DataTable ``data`` records; each row carries its spread key as ``id``.

    The ``at_*`` fields are hidden flags (0/1) consumed by the conditional
    styles to highlight settles printing at a YTD / all-time extreme.
    """
    records = []
    for _, row in res.iterrows():
        live = row["live"]
        rec = {
            "id": key_fn(row),
            "cadence": row["cadence"],
            "legs": row["legs"],
            "live": live,
            "dod": None if pd.isna(row["dod"]) else row["dod"],
            "ytd_high": row["ytd_high"],
            "ytd_low": row["ytd_low"],
            "ath": row["ath"],
            "atl": row["atl"],
            "pct": row["pct"],
            "z": row["z"],
            "mean": row["mean"],
            "n": row["n"],
            "flag": row["flag"],
            "at_ytd_high": int(live >= row["ytd_high"] - _EPS),
            "at_ytd_low": int(live <= row["ytd_low"] + _EPS),
            "at_ath": int(live >= row["ath"] - _EPS),
            "at_atl": int(live <= row["atl"] + _EPS),
            "dod_extreme": False,
        }
        if "dod_extreme" in row.index and pd.notna(row.get("dod_extreme")):
            rec["dod_extreme"] = bool(row["dod_extreme"])
        if live_mode:
            settle = row.get("settle", live)
            rec["settle"] = None if pd.isna(settle) else settle
            dod_z = row.get("dod_z", float("nan"))
            rec["dod_z"] = None if pd.isna(dod_z) else dod_z
        records.append(rec)
    return records


def _heat_rules(rec: dict) -> list[dict]:
    """%ile / z heat cells + at-extreme highlights for one row."""
    row_filter = f'{{id}} = "{rec["id"]}"'
    rules = [
        {"if": {"filter_query": row_filter, "column_id": "pct"},
         "backgroundColor": heat_pct(rec["pct"])},
        {"if": {"filter_query": row_filter, "column_id": "z"},
         "backgroundColor": heat_z(rec["z"])},
    ]
    # Level printing at a YTD extreme: highlight the level cell and the
    # matched YTD cell.  An all-time extreme additionally lights up ATH/ATL.
    if rec["at_ytd_high"]:
        for col in ("live", "ytd_high"):
            rules.append({"if": {"filter_query": row_filter, "column_id": col},
                          "backgroundColor": AT_HIGH_BG, "fontWeight": "700"})
    elif rec["at_ytd_low"]:
        for col in ("live", "ytd_low"):
            rules.append({"if": {"filter_query": row_filter, "column_id": col},
                          "backgroundColor": AT_LOW_BG, "fontWeight": "700"})
    if rec["at_ath"]:
        rules.append({"if": {"filter_query": row_filter, "column_id": "ath"},
                      "backgroundColor": AT_HIGH_BG, "fontWeight": "700"})
    if rec["at_atl"]:
        rules.append({"if": {"filter_query": row_filter, "column_id": "atl"},
                      "backgroundColor": AT_LOW_BG, "fontWeight": "700"})
    return rules


def build_table_styles(records: list[dict], selected_key: str = None) -> list[dict]:
    """Conditional styles: zebra rows, heat cells, extreme highlights and the
    whole-row selection tint (heat cells re-applied on top so they survive)."""
    styles = [
        {"if": {"row_index": "odd"}, "backgroundColor": "#fafafa"},
        # DoD colouring
        {"if": {"filter_query": "{dod} > 0", "column_id": "dod"},
         "color": "#3d7a5a", "fontWeight": "600"},
        {"if": {"filter_query": "{dod} < 0", "column_id": "dod"},
         "color": "#b23a48", "fontWeight": "600"},
        {"if": {"filter_query": "{dod_z} > 0", "column_id": "dod_z"},
         "color": "#3d7a5a", "fontWeight": "600"},
        {"if": {"filter_query": "{dod_z} < 0", "column_id": "dod_z"},
         "color": "#b23a48", "fontWeight": "600"},
    ]
    for flag, (bg, fg) in FLAG_COLORS.items():
        styles.append({
            "if": {"filter_query": f'{{flag}} = "{flag}"', "column_id": "flag"},
            "backgroundColor": bg, "color": fg,
            "fontWeight": "700", "textAlign": "center",
        })
    for rec in records:
        styles.extend(_heat_rules(rec))
    styles.extend(dod_highlight_styles(records))

    # Whole-row selection: tint every cell of the active row, then re-apply
    # its heat/extreme cells so they stay visible on top of the tint.
    selected = next((r for r in records if r["id"] == selected_key), None)
    if selected is not None:
        styles.append({
            "if": {"filter_query": f'{{id}} = "{selected["id"]}"'},
            "backgroundColor": SELECTED_ROW_BG,
        })
        styles.extend(_heat_rules(selected))
        styles.extend(dod_highlight_styles([selected]))

    # Neutralise the default single-cell selection box so the row tint reads
    # as the selection (the clicked cell keeps a subtle matching outline).
    styles.append({
        "if": {"state": "active"},
        "backgroundColor": SELECTED_ROW_BG,
        "border": "1px solid rgba(52, 152, 219, 0.45)",
    })
    return styles
