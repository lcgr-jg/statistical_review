"""Constants for the TTF Spreads Monitor page.

The spread engine itself lives in ``jain_commods.core.analytics.spreads``
(shared with the eu_reports spreads_monitor email).  This module holds the
page/scheduler wiring plus the interactive option defaults.
"""
from __future__ import annotations

from typing import Final

# ── Page registration ──────────────────────────────────────────────────────
PAGE_PATH: Final[str] = "/gas/ttf_spreads"
PAGE_NAME: Final[str] = "TTF Spreads Monitor"
PAGE_TITLE: Final[str] = "TTF Spreads Monitor | JG Power Dashboard"
PAGE_ORDER: Final[int] = 2

# ── Scheduler / cache knobs ────────────────────────────────────────────────
SOURCE_NAME: Final[str] = "ttf_spreads_data"
# Settles are daily; refresh alongside the other price sources on weekdays.
CRON: Final[str] = "15 6,12,18 * * 1-5"
# Long TTL so the Friday-evening snapshot still serves the page over the
# weekend (the cron refresh simply overwrites it on weekdays).
TTL_SECONDS: Final[int] = 72 * 60 * 60

# How many years of settlement history to fetch (matches the email report).
HISTORY_YEARS: Final[int] = 10

# ── Freshness popup ────────────────────────────────────────────────────────
FRESHNESS_SOURCE_NAME: Final[str] = "TTF Spreads (ICE settles)"
# Overnight gap is 18:15 -> 06:15 (~12 h); stay "fresh" across it.
FRESHNESS_EXPECTED_MINUTES: Final[int] = 14 * 60

# ── Interactive option defaults (email report parity) ──────────────────────
# Energy-crisis years excluded from the stats history by default; the page
# exposes a toggle to include them.
CRISIS_YEARS: Final[tuple[int, ...]] = (2021, 2022)
DEFAULT_EXCLUDE_CRISIS: Final[bool] = True

# History-window lookback options for the stats (None = full history).
HISTORY_WINDOW_OPTIONS: Final[list[dict]] = [
    {"label": "Full history", "value": "all"},
    {"label": "5 years", "value": "5y"},
    {"label": "3 years", "value": "3y"},
]
DEFAULT_HISTORY_WINDOW: Final[str] = "all"
HISTORY_WINDOW_YEARS: Final[dict[str, int]] = {"5y": 5, "3y": 3}

# Spread cadences in display order (matches the email's universe).
CADENCES: Final[list[str]] = ["M/M", "Q/Q", "Sum/Win", "Win/Win", "Sum/Sum", "Cal/Cal"]

# How many headline cards to show.
N_CARDS: Final[int] = 3
