"""Data loading + stats recomputation for the TTF Spreads Monitor page.

``load_ttf_spreads_data`` is the scheduler loader: it does the expensive work
(Snowflake fetch + generic spread-history construction) once per refresh and
returns a picklable payload for ``dashboard_cache``.  Callbacks then recompute
the statistics from the cached per-spread histories under user-selected
options via ``compute_stats`` -- pure pandas over ~25 short series, so option
changes are effectively instant.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Optional

import pandas as pd

from core.data_freshness import tracker
from core.ttf_spreads.constants import (
    CRISIS_YEARS,
    DEFAULT_EXCLUDE_CRISIS,
    DEFAULT_HISTORY_WINDOW,
    FRESHNESS_EXPECTED_MINUTES,
    FRESHNESS_SOURCE_NAME,
    HISTORY_WINDOW_YEARS,
    HISTORY_YEARS,
)

logger = logging.getLogger(__name__)


def spread_key(entry: dict) -> str:
    """Stable identifier for one monitored spread (used as the table row id)."""
    return (f"{entry['front_label']}|{entry['front_year']}|"
            f"{entry['back_label']}|{entry['back_year']}")


def load_ttf_spreads_data() -> dict[str, Any]:
    """Loader for ``dashboard_cache.register_source('ttf_spreads_data', ...)``.

    Returns a picklable dict::

        {
            "fetched_at": "<ISO UTC>",
            "as_of": Timestamp,        # latest settle date
            "data_start": Timestamp,   # first trade date in the history
            "n_trade_dates": int,
            "history_years": int,
            "histories": [             # one entry per monitored spread
                {cadence, front_label, front_year, back_label, back_year,
                 year_offset, rank, legs, series: pd.Series},
                ...
            ],
            "stats_default": DataFrame,  # email-default options, for first paint
        }
    """
    from jain_commods.core.analytics.spreads import (
        INTERNAL_HISTORY_START,
        SpreadEngine,
        build_spread_histories,
        classify_strips,
        compute_spread_stats_from_histories,
        get_ice_settles,
    )

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata={"state": "loading"},
    )

    today = datetime.now()
    start = today.replace(year=today.year - HISTORY_YEARS)

    try:
        # Pre-2019 history comes from the immutable S3 snapshot of the
        # Bloomberg backfill (the dashboard host has no BPipe access).
        df_prices = get_ice_settles(start_date=start, backfill='snapshot')
    except Exception as exc:
        logger.warning(
            "TTF spreads: pre-2019 snapshot unavailable (%s); "
            "falling back to internal history from %s",
            exc, INTERNAL_HISTORY_START.date(),
        )
        df_prices = get_ice_settles(
            start_date=max(start, INTERNAL_HISTORY_START), backfill=None)

    df = classify_strips(df_prices)
    engine = SpreadEngine(df)
    histories = build_spread_histories(df, engine)

    # Default stats (email parity: crisis years excluded, full window) so the
    # first page paint needs no recomputation.
    stats_default = compute_spread_stats_from_histories(
        histories, engine.live_date,
        exclude_crisis_years=DEFAULT_EXCLUDE_CRISIS,
        crisis_years=CRISIS_YEARS,
    )

    payload = {
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "as_of": engine.live_date,
        "data_start": pd.Timestamp(engine.dates.min()),
        "n_trade_dates": int(len(engine.dates)),
        "history_years": HISTORY_YEARS,
        "histories": histories,
        "stats_default": stats_default,
    }

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata={
            "as_of": str(engine.live_date.date()),
            "spreads": len(histories),
            "trade_dates": payload["n_trade_dates"],
        },
    )

    logger.info(
        "TTF spreads loaded: %d spreads, %d trade dates, as of %s",
        len(histories), payload["n_trade_dates"], engine.live_date.date(),
    )
    return payload


def history_start_for_window(as_of: pd.Timestamp, window: str) -> Optional[pd.Timestamp]:
    """Earliest stats date for a history-window option ('all' -> None)."""
    years = HISTORY_WINDOW_YEARS.get(window)
    if years is None:
        return None
    return pd.Timestamp(as_of) - pd.DateOffset(years=years)


def compute_stats(payload: dict,
                  exclude_crisis: bool = DEFAULT_EXCLUDE_CRISIS,
                  window: str = DEFAULT_HISTORY_WINDOW) -> pd.DataFrame:
    """Recompute the stats table from cached histories under page options."""
    from jain_commods.core.analytics.spreads import compute_spread_stats_from_histories

    stats_default = payload.get("stats_default")
    if (exclude_crisis == DEFAULT_EXCLUDE_CRISIS
            and window == DEFAULT_HISTORY_WINDOW
            and stats_default is not None
            # Cached payload may predate newer stats columns (e.g. ath/atl);
            # recompute from histories if so rather than serving a stale schema.
            and "ath" in stats_default.columns):
        return stats_default

    return compute_spread_stats_from_histories(
        payload["histories"], payload["as_of"],
        exclude_crisis_years=exclude_crisis,
        crisis_years=CRISIS_YEARS,
        history_start=history_start_for_window(payload["as_of"], window),
    )


def find_history(payload: dict, key: str) -> Optional[dict]:
    """Look up one spread's history entry by its ``spread_key``."""
    for entry in payload["histories"]:
        if spread_key(entry) == key:
            return entry
    return None
