"""Layout for the TTF Spreads Monitor page."""
from __future__ import annotations

from dash import dcc, html
from dash.dash_table import DataTable

from core.styles import COLORS
from core.bbg_spreads.highlights import DOD_MOVE_BG, DOD_Z_EXTREME
from core.ttf_spreads.components import (
    AT_HIGH_BG,
    AT_LOW_BG,
    TABLE_COLUMNS,
    TABLE_HEADER_TOOLTIPS,
)
from core.ttf_spreads.constants import (
    CADENCES,
    CRISIS_YEARS,
    DEFAULT_HISTORY_WINDOW,
    HISTORY_WINDOW_OPTIONS,
)

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "hidden",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 12px 0",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}

_OPTION_BLOCK = {"minWidth": "220px"}

_RADIO_STYLE = {"fontSize": "13px", "color": COLORS["text_primary"]}
_RADIO_LABEL_STYLE = {"marginRight": "16px", "cursor": "pointer"}

_BTN_PRIMARY = {
    "padding": "8px 16px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
}


def _swatch(bg: str, text: str) -> html.Span:
    """Small inline sample of a table highlight colour."""
    return html.Span(
        text,
        style={
            "backgroundColor": bg,
            "fontWeight": "700",
            "padding": "1px 6px",
            "borderRadius": "3px",
        },
    )


def build_layout() -> html.Div:
    crisis_label = "\u2013".join(str(y % 100) for y in
                                 (CRISIS_YEARS[0], CRISIS_YEARS[-1]))
    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1500px"},
        children=[
            dcc.Store(id="ttf-spreads-live-store"),
            html.Div(children=[
                html.H1(
                    "TTF Spreads Monitor",
                    style={
                        "fontSize": "22px",
                        "fontWeight": "600",
                        "color": COLORS["text_primary"],
                        "margin": "0 0 4px 0",
                    },
                ),
                html.P(
                    "Every TTF calendar-style spread (month, quarter, seasonal, "
                    "cal-year) vs its own rolling generic history. "
                    "RICH = sell-bias, CHEAP = buy-bias, ranked by z-score.",
                    style={
                        "fontSize": "13px",
                        "color": COLORS["text_muted"],
                        "margin": "0 0 4px 0",
                    },
                ),
                html.Div(
                    id="ttf-spreads-status",
                    style={
                        "fontSize": "12px",
                        "color": COLORS["text_muted"],
                        "margin": "0 0 12px 0",
                    },
                ),
            ]),

            # ── Options panel ────────────────────────────────────────────
            html.Div(
                style={**_CONTENT_PANEL,
                       "display": "flex", "flexWrap": "wrap",
                       "gap": "28px", "alignItems": "flex-start"},
                children=[
                    html.Div(style=_OPTION_BLOCK, children=[
                        html.Label(
                            f"Energy-crisis years (20{crisis_label})",
                            style=_LABEL,
                        ),
                        dcc.RadioItems(
                            id="ttf-spreads-crisis",
                            options=[
                                {"label": "Excluded from stats", "value": "exclude"},
                                {"label": "Included in stats", "value": "include"},
                            ],
                            value="exclude",
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                    ]),
                    html.Div(style=_OPTION_BLOCK, children=[
                        html.Label("Stats history window", style=_LABEL),
                        dcc.RadioItems(
                            id="ttf-spreads-window",
                            options=HISTORY_WINDOW_OPTIONS,
                            value=DEFAULT_HISTORY_WINDOW,
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                    ]),
                    html.Div(style={"minWidth": "320px"}, children=[
                        html.Label("Granularity", style=_LABEL),
                        dcc.Checklist(
                            id="ttf-spreads-granularity",
                            options=[{"label": c, "value": c} for c in CADENCES],
                            value=list(CADENCES),
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                    ]),
                    html.Div(style=_OPTION_BLOCK, children=[
                        html.Label("Price source", style=_LABEL),
                        dcc.RadioItems(
                            id="ttf-spreads-price-source",
                            options=[
                                {"label": "ICE settlement", "value": "settle"},
                                {"label": "Bloomberg live", "value": "live"},
                            ],
                            value="settle",
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                        html.Div(
                            style={"marginTop": "10px"},
                            children=html.Button(
                                "Fetch live prices",
                                id="ttf-spreads-fetch-live",
                                n_clicks=0,
                                title="Query Bloomberg BPIPE for the latest "
                                      "intraday marks and recompute z / %ile",
                                style=_BTN_PRIMARY,
                            ),
                        ),
                    ]),
                ],
            ),

            # ── Bloomberg live query time (prominent when live selected) ─
            html.Div(id="ttf-spreads-live-banner"),

            # ── Headline cards ───────────────────────────────────────────
            html.Div(
                style={"marginBottom": "20px"},
                children=dcc.Loading(
                    type="circle",
                    children=html.Div(id="ttf-spreads-cards"),
                ),
            ),

            # ── Full spreads table ───────────────────────────────────────
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("All monitored spreads", style=_PANEL_TITLE),
                    html.P(
                        "Click a row to chart that spread's rolling history below. "
                        "%ile and z are computed against the options selected above.",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "margin": "0 0 6px 0",
                        },
                    ),
                    html.P(
                        children=[
                            "Highlighting: cells shown ",
                            _swatch(AT_HIGH_BG, "pink"),
                            " when the latest level prints the YTD high (or "
                            "all-time high on the ATH column) and ",
                            _swatch(AT_LOW_BG, "green"),
                            " when it prints the YTD low (or all-time low on "
                            "ATL).",
                        ],
                        style={
                            "fontSize": "12px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 6px 0",
                        },
                    ),
                    html.P(
                        children=[
                            "Bloomberg live mode: ",
                            _swatch(DOD_MOVE_BG, "amber"),
                            f" on Δ vs settle / Δ z when the intraday move "
                            f"vs the last ICE settle is outsized "
                            f"(|Δ z| ≥ {DOD_Z_EXTREME:g} vs that spread's own "
                            "daily-change history). The orange banner above "
                            "shows when BPIPE was last queried.",
                        ],
                        style={
                            "fontSize": "12px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 14px 0",
                        },
                    ),
                    dcc.Loading(
                        type="circle",
                        children=DataTable(
                            id="ttf-spreads-table",
                            columns=TABLE_COLUMNS,
                            data=[],
                            sort_action="native",
                            cell_selectable=True,
                            tooltip_header=TABLE_HEADER_TOOLTIPS,
                            tooltip_delay=400,
                            tooltip_duration=None,
                            style_as_list_view=True,
                            style_table={"overflowX": "auto"},
                            style_header={
                                "backgroundColor": COLORS["card_bg"],
                                "color": COLORS["text_muted"],
                                "fontWeight": "600",
                                "fontSize": "12px",
                                "borderBottom": f"1px solid {COLORS['border']}",
                            },
                            style_cell={
                                "fontFamily": (
                                    '-apple-system, BlinkMacSystemFont, '
                                    '"Segoe UI", Roboto, sans-serif'
                                ),
                                "fontSize": "13px",
                                "padding": "8px 10px",
                                "textAlign": "center",
                                "border": "none",
                            },
                            style_data={
                                "borderBottom": f"1px solid {COLORS['border_light']}",
                                "cursor": "pointer",
                            },
                        ),
                    ),
                ],
            ),

            # ── Selected-spread history charts ───────────────────────────
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Spread history", style=_PANEL_TITLE),
                    html.Div(
                        style={
                            "display": "flex",
                            "flexWrap": "wrap",
                            "gap": "20px",
                            "alignItems": "stretch",
                        },
                        children=[
                            html.Div(
                                style={"flex": "2 1 620px", "minWidth": "480px"},
                                children=dcc.Loading(
                                    type="circle",
                                    children=dcc.Graph(
                                        id="ttf-spreads-history-chart",
                                        config={"displayModeBar": True,
                                                "displaylogo": False},
                                        style={"height": "440px"},
                                    ),
                                ),
                            ),
                            html.Div(
                                style={"flex": "1 1 380px", "minWidth": "340px"},
                                children=dcc.Loading(
                                    type="circle",
                                    children=dcc.Graph(
                                        id="ttf-spreads-ytd-chart",
                                        config={"displayModeBar": True,
                                                "displaylogo": False},
                                        style={"height": "440px"},
                                    ),
                                ),
                            ),
                        ],
                    ),
                ],
            ),

            # ── Methodology footnote ─────────────────────────────────────
            html.Div(
                id="ttf-spreads-footnote",
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "lineHeight": "1.6",
                },
            ),
        ],
    )
