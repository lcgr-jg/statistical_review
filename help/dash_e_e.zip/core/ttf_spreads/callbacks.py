"""Dash callbacks for the TTF Spreads Monitor page.

Settlement statistics are recomputed in-process from the cached per-spread
histories.  Bloomberg live marks are fetched on demand (Fetch live prices)
and overlaid without touching Snowflake/S3.
"""
from __future__ import annotations

import logging
import pandas as pd
from dash import Input, Output, callback, html, no_update

from core.bbg_spreads.highlights import (
    build_live_banner,
    mark_date_from_store,
    top_dod_movers,
)
from core.bbg_spreads.snapshot import fetch_live_marks
from core.bbg_spreads.stats import overlay_live_marks_ttf
from core.bbg_spreads.tickers import build_ttf_spread_requests
from core.data import get_ttf_spreads
from core.styles import COLORS
from core.ttf_spreads.charts import (
    build_empty_chart,
    build_history_chart,
    build_ytd_chart,
)
from core.ttf_spreads.components import (
    build_cards,
    build_table_records,
    build_table_styles,
    table_columns,
)
from core.ttf_spreads.constants import (
    CRISIS_YEARS,
    HISTORY_WINDOW_OPTIONS,
)
from core.ttf_spreads.data import (
    compute_stats,
    find_history,
    history_start_for_window,
    spread_key,
)

logger = logging.getLogger(__name__)

_NO_DATA_MSG = (
    "TTF spreads data is not loaded yet — the cache warms in the background "
    "shortly after start-up. Refresh the page in a minute."
)


def _window_label(window: str) -> str:
    for opt in HISTORY_WINDOW_OPTIONS:
        if opt["value"] == window:
            return opt["label"]
    return window


def _crisis_note(exclude_crisis: bool) -> str:
    years = ", ".join(str(y) for y in CRISIS_YEARS)
    return (f"Energy-crisis years ({years}) excluded from the stats history."
            if exclude_crisis
            else f"Energy-crisis years ({years}) included in the stats history.")


@callback(
    Output("ttf-spreads-live-store", "data"),
    Input("ttf-spreads-fetch-live", "n_clicks"),
    prevent_initial_call=True,
)
def fetch_ttf_live_prices(n_clicks):
    if not n_clicks:
        return no_update

    payload = get_ttf_spreads()
    if payload is None:
        return {"marks": {}, "error": _NO_DATA_MSG, "fetched_at": None}

    try:
        requests = build_ttf_spread_requests(payload["histories"], spread_key)
        return fetch_live_marks(requests)
    except Exception as exc:
        logger.exception("TTF spreads live fetch failed: %s", exc)
        return {
            "marks": {},
            "error": f"Live fetch failed: {exc}",
            "fetched_at": None,
        }


@callback(
    Output("ttf-spreads-cards", "children"),
    Output("ttf-spreads-table", "data"),
    Output("ttf-spreads-table", "columns"),
    Output("ttf-spreads-table", "style_data_conditional"),
    Output("ttf-spreads-status", "children"),
    Output("ttf-spreads-live-banner", "children"),
    Output("ttf-spreads-footnote", "children"),
    Input("ttf-spreads-crisis", "value"),
    Input("ttf-spreads-window", "value"),
    Input("ttf-spreads-granularity", "value"),
    Input("ttf-spreads-price-source", "value"),
    Input("ttf-spreads-live-store", "data"),
    Input("ttf-spreads-table", "active_cell"),
)
def update_spreads_table(crisis_value, window, granularities, price_source,
                         live_store, active_cell):
    exclude_crisis = crisis_value != "include"
    want_live = price_source == "live"

    payload = get_ttf_spreads()
    if payload is None:
        msg = html.Div(_NO_DATA_MSG,
                       style={"fontSize": "13px", "color": COLORS["text_muted"]})
        return (msg, [], table_columns(False), [], _NO_DATA_MSG,
                build_live_banner(price_source, live_store, live_mode=False), "")

    try:
        res = compute_stats(payload, exclude_crisis=exclude_crisis, window=window)
    except Exception as exc:
        logger.exception("TTF spreads stats recompute failed: %s", exc)
        err = html.Div(f"Failed to compute spread statistics: {exc}",
                       style={"fontSize": "13px", "color": COLORS["error"]})
        return (err, [], table_columns(False), [], "",
                build_live_banner(price_source, live_store, live_mode=False), "")

    live_mode = False
    live_note = ""
    if want_live:
        marks = (live_store or {}).get("marks") or {}
        err = (live_store or {}).get("error")
        if marks:
            res = overlay_live_marks_ttf(
                res, payload["histories"], payload["as_of"], marks, spread_key,
                exclude_crisis=exclude_crisis,
                crisis_years=CRISIS_YEARS,
                history_start=history_start_for_window(
                    payload["as_of"], window),
            )
            live_mode = True
            movers = top_dod_movers(res, n=3)
            if movers:
                live_note = " · outsized: " + "; ".join(movers)
        elif err:
            live_note = f" · Live fetch error (showing ICE settles)"

    if granularities:
        res = res[res["cadence"].isin(granularities)]

    records = build_table_records(res, key_fn=spread_key, live_mode=live_mode)
    columns = table_columns(live_mode)

    selected_key = None
    if active_cell and active_cell.get("row_id"):
        selected_key = active_cell["row_id"]
    if selected_key is None and records:
        selected_key = records[0]["id"]

    styles = build_table_styles(records, selected_key=selected_key)
    cards = build_cards(res, live_mode=live_mode)
    banner = build_live_banner(price_source, live_store, live_mode=live_mode)

    as_of = pd.Timestamp(payload["as_of"])
    n_extreme = int(res["extreme"].sum()) if (
        not res.empty and "extreme" in res.columns) else 0
    n_dod = int(res["dod_extreme"].sum()) if (
        live_mode and not res.empty and "dod_extreme" in res.columns) else 0
    status = (
        f"Settles as of {as_of:%d %b %Y} · {len(res)} spreads monitored · "
        f"{n_extreme} at an extreme (|z| ≥ 1.5 or %ile ≥ 90 / ≤ 10)"
        + (f" · {n_dod} outsized Δ vs settle" if live_mode else "")
        + live_note
    )

    data_start = pd.Timestamp(payload["data_start"])
    footnote_lines = [
        "Standard z (mean / std) vs each spread's own rolling generic history.",
        _crisis_note(exclude_crisis),
        (f"Stats window: {_window_label(window)} · settlement data "
         f"{data_start:%d %b %Y} – {as_of:%d %b %Y} "
         f"({payload['n_trade_dates']:,} trading days)."),
        ("Live mode: Bloomberg mid/last overlays the settle for z / %ile; "
         "Δ vs settle = live − last ICE print; |Δz| ≥ 1.5 highlighted amber. "
         "Native calendar tickers preferred, with outright fallback."
         if live_mode else
         "Settle cells highlighted pink/green when the latest settle prints the "
         "YTD high/low; ATH / ATL cells light up when it is also an all-time "
         "extreme over the loaded history."),
        ("History rolled on a generic basis (front-leg seasonal label + year rank) "
         "relative to each trade date; quarter/season/year legs are reconstructed "
         "from their constituent monthly contracts (day-weighted)."),
    ]
    footnote = [html.Div(line) for line in footnote_lines]

    return cards, records, columns, styles, status, banner, footnote


@callback(
    Output("ttf-spreads-history-chart", "figure"),
    Output("ttf-spreads-ytd-chart", "figure"),
    Input("ttf-spreads-table", "active_cell"),
    Input("ttf-spreads-table", "data"),
    Input("ttf-spreads-crisis", "value"),
    Input("ttf-spreads-window", "value"),
    Input("ttf-spreads-price-source", "value"),
    Input("ttf-spreads-live-store", "data"),
)
def update_history_charts(active_cell, table_data, crisis_value, window,
                          price_source, live_store):
    exclude_crisis = crisis_value != "include"

    payload = get_ttf_spreads()
    if payload is None or not table_data:
        empty = build_empty_chart(_NO_DATA_MSG)
        return empty, empty

    key = None
    if active_cell and active_cell.get("row_id"):
        key = active_cell["row_id"]
    if key is None:
        key = table_data[0]["id"]

    entry = find_history(payload, key)
    if entry is None:
        empty = build_empty_chart("Spread not found in the cached history.")
        return empty, empty

    as_of = pd.Timestamp(payload["as_of"])
    history_start = history_start_for_window(as_of, window)

    live_mark = None
    mark_date = None
    if price_source == "live" and live_store and live_store.get("marks"):
        live_mark = live_store["marks"].get(key)
        if live_mark is not None:
            mark_date = mark_date_from_store(live_store)

    fig_hist = build_history_chart(
        entry,
        exclude_crisis=exclude_crisis,
        history_start=history_start,
        live_date=as_of,
        live_mark=live_mark,
        mark_date=mark_date,
    )
    fig_ytd = build_ytd_chart(
        entry, live_date=as_of, live_mark=live_mark, mark_date=mark_date,
    )
    return fig_hist, fig_ytd
