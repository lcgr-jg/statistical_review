"""
Toast Notification Manager
───────────────────────────
Provides a global toast notification system for displaying errors, warnings,
and info messages to users via a stacked toast container.

Usage in callbacks:
    from core.toast_manager import make_toast

    # Return a toast as part of your callback output
    return ..., make_toast("Data load failed for DE Wind", level="error")
"""

from dash import html, dcc, Input, Output, State, ALL, callback_context, no_update
import uuid
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


# ── Toast level config ─────────────────────────────────────────────────────
_LEVEL_CONFIG = {
    'error': {
        'icon': 'fa-circle-exclamation',
        'bg': '#2d1215',
        'border': '#f44336',
        'title_color': '#ff6b6b',
        'text_color': '#ffb3b3',
        'label': 'ERROR',
    },
    'warning': {
        'icon': 'fa-triangle-exclamation',
        'bg': '#2d2512',
        'border': '#ff9800',
        'title_color': '#ffc107',
        'text_color': '#ffe0b3',
        'label': 'WARNING',
    },
    'success': {
        'icon': 'fa-circle-check',
        'bg': '#122d15',
        'border': '#4CAF50',
        'title_color': '#66bb6a',
        'text_color': '#b3ffb3',
        'label': 'SUCCESS',
    },
    'info': {
        'icon': 'fa-circle-info',
        'bg': '#12202d',
        'border': '#2196F3',
        'title_color': '#64b5f6',
        'text_color': '#b3d9ff',
        'label': 'INFO',
    },
}


def create_toast_container():
    """
    Create the toast container element to include in the app layout.
    Toasts are rendered in a fixed stack in the top-right corner.
    """
    return html.Div([
        # Store for toast messages (list of {message, level, timestamp})
        dcc.Store(id='toast-store', data=[]),

        # Toast container
        html.Div(
            id='toast-container',
            style={
                'position': 'fixed',
                'top': '80px',
                'right': '20px',
                'zIndex': '10000',
                'display': 'flex',
                'flexDirection': 'column',
                'gap': '8px',
                'maxWidth': '420px',
                'fontFamily': '-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif',
            },
        ),
    ])


def make_toast(message: str, level: str = 'info', source: str = None) -> dict:
    """
    Create a toast data dict to be appended to the toast-store.

    Parameters
    ----------
    message : str
        The notification message.
    level : str
        One of 'error', 'warning', 'success', 'info'.
    source : str, optional
        The data source or component that triggered this.

    Returns
    -------
    dict  to append to the toast-store list
    """
    return {
        'id': str(uuid.uuid4()),
        'message': message,
        'level': level,
        'source': source or '',
        'timestamp': datetime.now().strftime('%H:%M:%S'),
    }


def render_toast(toast_data: dict) -> html.Div:
    """Render a single toast notification element."""
    level = toast_data.get('level', 'info')
    cfg = _LEVEL_CONFIG.get(level, _LEVEL_CONFIG['info'])
    message = toast_data.get('message', '')
    source = toast_data.get('source', '')
    timestamp = toast_data.get('timestamp', '')

    return html.Div(
        style={
            'backgroundColor': cfg['bg'],
            'border': f"1px solid {cfg['border']}40",
            'borderLeft': f"3px solid {cfg['border']}",
            'borderRadius': '8px',
            'padding': '12px 16px',
            'boxShadow': '0 4px 12px rgba(0,0,0,0.3)',
            'animation': 'slideInRight 0.3s ease-out',
            'minWidth': '300px',
        },
        children=[
            # Header line: level label + timestamp
            html.Div(
                style={
                    'display': 'flex',
                    'justifyContent': 'space-between',
                    'alignItems': 'center',
                    'marginBottom': '4px',
                },
                children=[
                    html.Span(
                        [
                            html.I(className=f"fa-solid {cfg['icon']}",
                                   style={'marginRight': '6px', 'fontSize': '11px'}),
                            cfg['label'],
                        ],
                        style={
                            'fontSize': '10px',
                            'fontWeight': '700',
                            'color': cfg['title_color'],
                            'letterSpacing': '0.8px',
                        },
                    ),
                    html.Div(
                        [
                            html.Span(
                                timestamp,
                                style={
                                    'fontSize': '10px',
                                    'color': '#888',
                                    'marginRight': '10px',
                                },
                            ),
                            html.I(
                                className="fa-solid fa-xmark",
                                id={'type': 'toast-close', 'index': toast_data.get('id')},
                                style={
                                    'cursor': 'pointer',
                                    'color': '#888',
                                    'fontSize': '12px',
                                    'padding': '2px',
                                },
                            ),
                        ],
                        style={'display': 'flex', 'alignItems': 'center'},
                    ),
                ],
            ),
            # Message
            html.Div(
                message,
                style={
                    'fontSize': '12px',
                    'color': cfg['text_color'],
                    'lineHeight': '1.4',
                },
            ),
            # Source (optional)
            html.Div(
                source,
                style={
                    'fontSize': '10px',
                    'color': '#666',
                    'marginTop': '4px',
                },
            ) if source else None,
        ],
    )


def register_toast_callbacks(app):
    """Register callbacks for rendering toasts from the store."""

    @app.callback(
        Output('toast-container', 'children'),
        Input('toast-store', 'data'),
    )
    def render_toasts(toasts):
        if not toasts:
            return []
        # Show max 5 most recent toasts
        recent = toasts[-5:]
        return [render_toast(t) for t in recent]

    @app.callback(
        Output('toast-store', 'data', allow_duplicate=True),
        Input({'type': 'toast-close', 'index': ALL}, 'n_clicks'),
        State('toast-store', 'data'),
        prevent_initial_call=True
    )
    def handle_close_toast(n_clicks, toasts):
        """Remove a toast from the store when its close button is clicked."""
        ctx = callback_context
        if not ctx.triggered or not any(n_clicks):
            return no_update

        # Find which toast index was clicked
        triggered_id_str = ctx.triggered[0]['prop_id'].split('.')[0]
        try:
            # Need to evaluate the string as a dict safely
            import ast
            triggered_id = ast.literal_eval(triggered_id_str)
            clicked_id = triggered_id['index']
        except Exception:
            return no_update

        # Filter out the clicked toast
        new_toasts = [t for t in toasts if t.get('id') != clicked_id]
        return new_toasts
