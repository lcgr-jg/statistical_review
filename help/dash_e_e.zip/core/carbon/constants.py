"""Static configuration for the Carbon desk pages (Vol Monitor, Timespreads).

Page metadata mirrors the old iframe registrars so the sidebar wiring in
``portal_app.SIDEBAR_GROUPS`` ("Carbon" group) keeps working unchanged:
the ``name=`` values must stay "Vol Monitor" / "Timespreads".
"""
from __future__ import annotations

# ── Page metadata ─────────────────────────────────────────────────────────
VOL_PAGE_PATH = "/carbon/vol"
VOL_PAGE_NAME = "Vol Monitor"
VOL_PAGE_TITLE = "Carbon Vol Monitor | JG Power Dashboard"
VOL_PAGE_ORDER = 60

TS_PAGE_PATH = "/carbon/timespreads"
TS_PAGE_NAME = "Timespreads"
TS_PAGE_TITLE = "Carbon Timespreads | JG Power Dashboard"
TS_PAGE_ORDER = 61

# ── S3 contract (published by eu_carbon scripts/publish_carbon_s3.py) ──────
S3_BUCKET = "jg-tech1prod-s3-eu-gas-power"
S3_PREFIX = "carbon"

# Vol: one JSON payload, nested per commodity (eua, ttf, …).
VOL_PAYLOAD_KEY = f"{S3_PREFIX}/vol/payload.json"

# Timespreads: computed frames + a portal payload. Product EUA today; the
# structure generalises if the desk adds UKA etc.
TS_PRODUCT = "EUA"
TS_CARRY_KEY = f"{S3_PREFIX}/timespreads/{TS_PRODUCT}/carry.parquet"
TS_BANK_KEY = f"{S3_PREFIX}/timespreads/{TS_PRODUCT}/bank_funding_latest.parquet"
TS_META_KEY = f"{S3_PREFIX}/timespreads/{TS_PRODUCT}/meta.json"
TS_PAYLOAD_KEY = f"{S3_PREFIX}/timespreads/{TS_PRODUCT}/payload.json"

# ── dashboard_cache source names (registered in portal_app._setup_scheduler) ─
VOL_SOURCE = "carbon_vol_data"
TS_SOURCE = "carbon_timespreads_data"

# 4h TTL: the monitors publish once daily post-settlement, so anything fresher
# is wasted S3 round-trips; 4h lines up with the other daily dashboard sources.
CACHE_TTL = 14_400

# ── Chart palette (matches eu_carbon desk.vol/desk.curves plots) ───────────
TEMPLATE = "plotly_white"
VOL_COLORS = {
    "iv": "#1565c0", "rv": "#ef6c00", "spread": "#1b5e20", "vrp": "#6a1b9a",
    "put": "#c62828", "call": "#1565c0", "atm": "#212121", "zero": "#9e9e9e",
}
CONTRACT_LINE_COLORS = ["#1565c0", "#ef6c00", "#1b5e20", "#6a1b9a", "#c62828"]
TS_COLORS = {
    "spread": "#1b5e20", "rf": "#455a64", "cds": "#ef6c00",
    "net": "#1565c0", "zero": "#9e9e9e",
}
REGION_COLORS = {
    "US": "#1565c0", "EU": "#1b5e20", "UK": "#6a1b9a",
    "CA": "#c62828", "AU": "#ef6c00", "global": "#212121",
}

# Smile overlay order/colours (vol Skew + Surface tabs)
SMILE_ORDER = ["today", "-1d", "-7d", "-30d", "-60d"]
SMILE_COLORS = {
    "today": "#212121", "-1d": "#1565c0", "-7d": "#00838f",
    "-30d": "#ef6c00", "-60d": "#bdbdbd",
}

VERDICT_COLORS = {
    "cheap": "#c62828", "fair": "#616161", "rich": "#1b5e20", "unknown": "#9e9e9e",
}
