"""Timespreads page — layout + callbacks (native Dash).

Renders the eu_carbon desk.curves timespread monitor: Overview / CDS from the
published ``carry`` frame, and Signals / Explorer / Mean reversion / Banks from
the published ``payload.json`` (see ``core.carbon.data.load_timespreads_data``).
Registered via side-effect import in ``pages/carbon_timespreads.py``.
"""
from __future__ import annotations

import logging

import dash_bootstrap_components as dbc
from dash import Input, Output, callback, dcc, html

from core.carbon import charts_ts as ct
from core.carbon.data import load_timespreads_data
from core.styles import COLORS

logger = logging.getLogger(__name__)

_TAB_STYLE = {"fontWeight": "500", "fontSize": "13px", "color": COLORS["text_secondary"],
              "borderBottom": "2px solid transparent", "padding": "8px 16px"}
_TAB_ACTIVE = {**_TAB_STYLE, "color": COLORS["accent"],
               "borderBottom": f"2px solid {COLORS['accent']}", "backgroundColor": "transparent"}
_CHART = {"backgroundColor": COLORS["chart_bg"], "borderRadius": "6px",
          "border": f"1px solid {COLORS['border']}", "padding": "4px", "marginBottom": "14px"}

_TABS = [
    ("cts-ov", "Overview"),
    ("cts-sig", "Signals"),
    ("cts-ex", "Spread explorer"),
    ("cts-mr", "Mean reversion"),
    ("cts-bk", "Banks"),
    ("cts-cds", "CDS panel"),
]
_LBL = {"className": "small text-muted fw-bold text-uppercase", "style": {"fontSize": "11px"}}


def _graph(fig, height: int = 420) -> html.Div:
    return html.Div(dcc.Graph(figure=fig, config={"displayModeBar": False, "responsive": True},
                              style={"height": f"{height}px"}), style=_CHART)


def _panel(children) -> html.Div:
    return html.Div(children, style={**_CHART, "padding": "12px"})


def _leg_list(payload: dict, hist: bool) -> list:
    legs = payload.get("legs", [])
    if not hist:
        return legs
    hist_legs = list(reversed(payload.get("legsHist", [])))
    return ([legs[0]] + hist_legs + legs[1:]) if legs else hist_legs


def build_layout() -> html.Div:
    bundle = load_timespreads_data()
    payload = bundle.get("payload") or {}
    meta = bundle.get("meta") or {}
    empty = not payload and (bundle.get("carry") is None or bundle["carry"].empty)

    default = payload.get("default") or {}
    legs = payload.get("legs", [])
    default_leg = default.get("leg") or (legs[0] if legs else None)
    pairs = payload.get("pairsByLeg", {}).get(default_leg, [])
    default_pair = default.get("pair") or (pairs[0] if pairs else None)
    bank_order = payload.get("bankOrder", [])
    generated = meta.get("last_run_at") or meta.get("last_trade_date") or ""

    return html.Div(style={"backgroundColor": COLORS["background"], "minHeight": "100vh"}, children=[
        html.Div(style={"padding": "16px 22px 0 22px", "borderBottom": f"1px solid {COLORS['border']}",
                        "backgroundColor": COLORS["card_bg"]}, children=[
            html.Div([
                html.Span("Carbon", style={"color": "#888", "fontSize": "13px"}),
                html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                html.Span("Timespreads", style={"fontWeight": "600", "color": COLORS["text_primary"]}),
                html.Span(f"  ·  {generated}" if generated else "",
                          style={"color": COLORS["text_muted"], "fontSize": "12px", "marginLeft": "8px"}),
            ], style={"marginBottom": "10px"}),
            dbc.Row([
                dbc.Col(html.Div(id="cts-cascade-wrap", children=[
                    dbc.Row([
                        dbc.Col([html.Label("Near leg", **_LBL),
                                 dcc.Dropdown(id="cts-leg",
                                              options=[{"label": l, "value": l} for l in _leg_list(payload, False)],
                                              value=default_leg, clearable=False, style={"width": "190px"})],
                                width="auto"),
                        dbc.Col([html.Label("Spread", **_LBL),
                                 dcc.Dropdown(id="cts-pair",
                                              options=[{"label": p, "value": p} for p in pairs],
                                              value=default_pair, clearable=False, style={"width": "200px"})],
                                width="auto"),
                        dbc.Col([html.Label("\u00a0", **_LBL),
                                 dbc.Checklist(id="cts-hist", options=[{"label": " include expired legs", "value": "y"}],
                                               value=[], switch=True, style={"marginTop": "4px"})],
                                width="auto"),
                    ], className="g-2"),
                ]), width="auto"),
                dbc.Col(html.Div(id="cts-mr-wrap", style={"display": "none"}, children=[
                    dbc.Row([
                        dbc.Col([html.Label("Metric", **_LBL),
                                 dcc.Dropdown(id="cts-metric", clearable=False, style={"width": "200px"},
                                              options=[{"label": "Net yield (bp)", "value": "net"},
                                                       {"label": "Nominal net yield (ccy/t)", "value": "nomnet"},
                                                       {"label": "Nominal spread (ccy/t)", "value": "nom"},
                                                       {"label": "Carry (% ann)", "value": "pct"}],
                                              value="net")], width="auto"),
                        dbc.Col([html.Label("Window", **_LBL),
                                 dcc.Dropdown(id="cts-window", clearable=False, style={"width": "110px"},
                                              options=[{"label": "60d", "value": 60},
                                                       {"label": "120d", "value": 120},
                                                       {"label": "250d", "value": 250}], value=250)],
                                width="auto"),
                    ], className="g-2"),
                ]), width="auto"),
                dbc.Col(html.Div(id="cts-bk-wrap", style={"display": "none"}, children=[
                    html.Label("Pairing", **_LBL),
                    dcc.Dropdown(id="cts-bank", options=[{"label": p, "value": p} for p in bank_order],
                                 value=(bank_order[0] if bank_order else None), clearable=False,
                                 style={"width": "200px"}),
                ]), width="auto"),
            ], className="g-3", style={"padding": "4px 0 12px 0"}),
            dbc.Tabs(id="cts-tabs", active_tab="cts-ov", style={"borderBottom": "none"},
                     className="border-0",
                     children=[dbc.Tab(label=lbl, tab_id=tid, tab_style=_TAB_STYLE,
                                       active_tab_style=_TAB_ACTIVE) for tid, lbl in _TABS]),
        ]),
        html.Div(id="cts-content", style={"padding": "16px 22px 22px 22px"},
                 children=(_missing() if empty else None)),
    ])


def _missing() -> html.Div:
    return dbc.Alert([
        html.B("No carbon timespread data published yet. "),
        "Once the eu_carbon timespread monitor runs and publishes carbon/timespreads/EUA/* to S3, "
        "this page will populate automatically.",
    ], color="secondary", style={"margin": "20px"})


# ── Cascade + visibility callbacks ──────────────────────────────────────────

@callback(
    Output("cts-leg", "options"),
    Output("cts-leg", "value"),
    Input("cts-hist", "value"),
)
def _legs(hist_value):
    payload = load_timespreads_data().get("payload") or {}
    legs = _leg_list(payload, bool(hist_value))
    default = (payload.get("default") or {}).get("leg") or (legs[0] if legs else None)
    return [{"label": l, "value": l} for l in legs], default


@callback(
    Output("cts-pair", "options"),
    Output("cts-pair", "value"),
    Input("cts-leg", "value"),
)
def _pairs(leg):
    payload = load_timespreads_data().get("payload") or {}
    pairs = (payload.get("pairsByLeg") or {}).get(leg or "", [])
    default = (payload.get("default") or {}).get("pair")
    value = default if default in pairs else (pairs[0] if pairs else None)
    return [{"label": p, "value": p} for p in pairs], value


@callback(Output("cts-cascade-wrap", "style"), Input("cts-tabs", "active_tab"))
def _cascade_vis(active_tab):
    return {} if active_tab in ("cts-ex", "cts-mr") else {"display": "none"}


@callback(Output("cts-mr-wrap", "style"), Input("cts-tabs", "active_tab"))
def _mr_vis(active_tab):
    return {} if active_tab == "cts-mr" else {"display": "none"}


@callback(Output("cts-bk-wrap", "style"), Input("cts-tabs", "active_tab"))
def _bk_vis(active_tab):
    return {} if active_tab == "cts-bk" else {"display": "none"}


# ── Content callback ─────────────────────────────────────────────────────────

@callback(
    Output("cts-content", "children"),
    Input("cts-tabs", "active_tab"),
    Input("cts-pair", "value"),
    Input("cts-metric", "value"),
    Input("cts-window", "value"),
    Input("cts-bank", "value"),
)
def _content(active_tab, pair, metric, window, bank):
    bundle = load_timespreads_data()
    payload = bundle.get("payload") or {}
    carry = bundle.get("carry")
    if not payload and (carry is None or carry.empty):
        return _missing()

    if active_tab == "cts-ov":
        if carry is None or carry.empty:
            return dbc.Alert("Overview needs the carry frame (not published yet).",
                             color="secondary", style={"margin": "20px"})
        return html.Div([
            ct.overview_cards(carry),
            _graph(ct.fig_net_yield_history(carry)),
            _graph(ct.fig_latest_term_structure(carry), 380),
            _graph(ct.fig_curve_heatmap(carry), 480),
        ])

    if active_tab == "cts-cds":
        if carry is None or carry.empty:
            return dbc.Alert("CDS panel needs the carry frame (not published yet).",
                             color="secondary", style={"margin": "20px"})
        return _graph(ct.fig_regional_cds(carry))

    if active_tab == "cts-sig":
        sig = payload.get("signals") or {}
        note = html.Div("Board: every live, liquid, bankable pair within the 3y horizon. "
                        "Gap = spread − funding-implied fair carry. z against a 250-day window.",
                        style={"fontSize": "12px", "color": "#757575", "margin": "2px 0 12px"})
        return html.Div([
            ct.signals_cards(sig), note,
            _panel(ct.signals_board_table(sig)),
            _graph(ct.fig_regime(sig)),
            _graph(ct.fig_event_paths(sig)),
            _panel(ct.event_summary_table(sig)),
        ])

    series = (payload.get("series") or {}).get(pair or "")

    if active_tab == "cts-ex":
        if not series:
            return dbc.Alert("Select a spread.", color="secondary", style={"margin": "20px"})
        n = len(series["dates"])
        info = html.Div(f"{n} observations, {series['dates'][0]} → {series['dates'][-1]}",
                        style={"fontSize": "12px", "color": "#757575", "marginBottom": "8px"})
        return html.Div([
            info,
            _graph(ct.fig_ex_pct(pair, series)),
            _graph(ct.fig_ex_nom(pair, series)),
            _graph(ct.fig_ex_net(pair, series), 340),
        ])

    if active_tab == "cts-mr":
        if not series:
            return dbc.Alert("Select a spread.", color="secondary", style={"margin": "20px"})
        mr = ct.mr_compute(series, metric or "net", int(window or 250))
        return html.Div([
            ct.mr_cards(mr, metric or "net", int(window or 250)),
            _graph(ct.fig_mr_band(pair, mr, metric or "net", int(window or 250)), 440),
            _panel(ct.mr_episodes_table(mr, metric or "net")),
            _graph(ct.fig_mr_z(pair, mr, int(window or 250)), 320),
            _graph(ct.fig_mr_hist(pair, mr, metric or "net"), 320),
        ])

    if active_tab == "cts-bk":
        rows = (payload.get("banks") or {}).get(bank or "", [])
        region_colors = payload.get("regionColors") or ct.REGION_COLORS
        return _graph(ct.fig_banks(bank or "", rows, region_colors), max(400, 60 + len(rows) * 28))

    return html.Div()
