"""Vol Monitor page — layout + callbacks (native Dash).

Renders the seven-tab eu_carbon desk.vol dashboard from the S3 ``payload.json``
(see ``core.carbon.data.load_vol_data``). A commodity dropdown switches every
tab; a contract dropdown drives the five per-contract tabs. Registered via
side-effect import in ``pages/carbon_vol.py``.
"""
from __future__ import annotations

import logging

import dash_bootstrap_components as dbc
from dash import Input, Output, State, callback, dcc, html

from core.carbon import charts_vol as cv
from core.carbon.data import load_vol_data
from core.styles import COLORS

logger = logging.getLogger(__name__)

_TAB_STYLE = {"fontWeight": "500", "fontSize": "13px", "color": COLORS["text_secondary"],
              "borderBottom": "2px solid transparent", "padding": "8px 16px"}
_TAB_ACTIVE = {**_TAB_STYLE, "color": COLORS["accent"],
               "borderBottom": f"2px solid {COLORS['accent']}", "backgroundColor": "transparent"}
_CHART = {"backgroundColor": COLORS["chart_bg"], "borderRadius": "6px",
          "border": f"1px solid {COLORS['border']}", "padding": "4px", "marginBottom": "14px"}

_TABS = [
    ("cvol-ov", "Overview"),
    ("cvol-ivrv", "Implied vs realized"),
    ("cvol-skew", "Skew"),
    ("cvol-surf", "Surface"),
    ("cvol-term", "Term structure"),
    ("cvol-be", "Breakevens"),
    ("cvol-wb", "Structure workbench"),
]


def _graph(fig, height: int = 420) -> html.Div:
    return html.Div(dcc.Graph(figure=fig, config={"displayModeBar": False, "responsive": True},
                              style={"height": f"{height}px"}), style=_CHART)


def build_layout() -> html.Div:
    data = load_vol_data()
    commodities = data.get("commodities", [])
    default_c = data.get("default") or (commodities[0] if commodities else None)
    generated = data.get("generatedAt", "")
    empty = not commodities

    return html.Div(style={"backgroundColor": COLORS["background"], "minHeight": "100vh"}, children=[
        html.Div(style={"padding": "16px 22px 0 22px", "borderBottom": f"1px solid {COLORS['border']}",
                        "backgroundColor": COLORS["card_bg"]}, children=[
            html.Div([
                html.Span("Carbon", style={"color": "#888", "fontSize": "13px"}),
                html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                html.Span("Vol Monitor", style={"fontWeight": "600", "color": COLORS["text_primary"]}),
                html.Span(f"  ·  generated {generated}" if generated else "",
                          style={"color": COLORS["text_muted"], "fontSize": "12px", "marginLeft": "8px"}),
            ], style={"marginBottom": "10px"}),
            dbc.Row([
                dbc.Col([html.Label("Commodity", className="small text-muted fw-bold text-uppercase",
                                    style={"fontSize": "11px"}),
                         dcc.Dropdown(id="cvol-commodity",
                                      options=[{"label": c.upper(), "value": c} for c in commodities],
                                      value=default_c, clearable=False,
                                      style={"width": "150px"})], width="auto"),
                dbc.Col([html.Label("Contract", className="small text-muted fw-bold text-uppercase",
                                    style={"fontSize": "11px"}),
                         dcc.Dropdown(id="cvol-contract", options=[], value=None, clearable=False,
                                      style={"width": "170px"})], width="auto"),
                dbc.Col(html.Div(id="cvol-wb-view-wrap", style={"display": "none"}, children=[
                    html.Label("Price view", className="small text-muted fw-bold text-uppercase",
                               style={"fontSize": "11px"}),
                    dcc.Dropdown(id="cvol-wb-view", options=[], value=None, clearable=False,
                                 style={"width": "150px"}),
                ]), width="auto"),
            ], className="g-3", style={"padding": "4px 0 12px 0"}),
            dbc.Tabs(id="cvol-tabs", active_tab="cvol-ov", style={"borderBottom": "none"},
                     className="border-0",
                     children=[dbc.Tab(label=lbl, tab_id=tid, tab_style=_TAB_STYLE,
                                       active_tab_style=_TAB_ACTIVE) for tid, lbl in _TABS]),
        ]),
        html.Div(id="cvol-content", style={"padding": "16px 22px 22px 22px"},
                 children=(_missing() if empty else None)),
    ])


def _missing() -> html.Div:
    return dbc.Alert([
        html.B("No carbon vol data published yet. "),
        "Once the eu_carbon vol monitor runs and publishes carbon/vol/payload.json to S3, "
        "this page will populate automatically.",
    ], color="secondary", style={"margin": "20px"})


# ── Callbacks ────────────────────────────────────────────────────────────────

@callback(
    Output("cvol-contract", "options"),
    Output("cvol-contract", "value"),
    Input("cvol-commodity", "value"),
)
def _contracts(commodity):
    pc = (load_vol_data().get("byCommodity") or {}).get(commodity or "", {})
    contracts = pc.get("contracts", [])
    default = pc.get("default") or (contracts[0] if contracts else None)
    return [{"label": c, "value": c} for c in contracts], default


@callback(
    Output("cvol-wb-view", "options"),
    Output("cvol-wb-view", "value"),
    Input("cvol-commodity", "value"),
    Input("cvol-contract", "value"),
)
def _wb_views(commodity, contract):
    pc = (load_vol_data().get("byCommodity") or {}).get(commodity or "", {})
    w = (pc.get("workbench") or {}).get(contract or "", {})
    views = list((w.get("byPriceView") or {}).keys())
    return [{"label": v, "value": v} for v in views], (views[0] if views else None)


@callback(
    Output("cvol-wb-view-wrap", "style"),
    Input("cvol-tabs", "active_tab"),
)
def _wb_view_visible(active_tab):
    return {"display": "block"} if active_tab == "cvol-wb" else {"display": "none"}


@callback(
    Output("cvol-content", "children"),
    Input("cvol-commodity", "value"),
    Input("cvol-contract", "value"),
    Input("cvol-tabs", "active_tab"),
)
def _content(commodity, contract, active_tab):
    pc = (load_vol_data().get("byCommodity") or {}).get(commodity or "", {})
    if not pc:
        return _missing()

    if active_tab == "cvol-ov":
        ov = pc.get("overview") or {}
        blocks = [cv.overview_cards(s, ov.get(s, {})) for s in pc.get("contracts", [])]
        return html.Div(blocks + [_graph(cv.fig_atm_iv_comparison(pc))])

    if active_tab == "cvol-term":
        term = pc.get("term") or {}
        return html.Div([
            _graph(cv.fig_term_structure_latest(term), 380),
            _graph(cv.fig_forward_vol_history(term)),
            _graph(cv.fig_term_slope_history(term)),
        ])

    if active_tab == "cvol-surf":
        skew = (pc.get("skew") or {}).get(contract or "", {})
        surf = (pc.get("surf") or {}).get(contract or "", {})
        return html.Div([
            _graph(cv.fig_surface_all(pc)),
            _graph(cv.fig_surf_change(contract, skew), 340),
            _graph(cv.fig_smile(contract, skew), 380),
            _graph(cv.fig_surf_history(contract, surf)),
        ])

    if not contract:
        return dbc.Alert("Select a contract.", color="secondary", style={"margin": "20px"})

    if active_tab == "cvol-ivrv":
        s = (pc.get("ivrv") or {}).get(contract, {})
        if not s:
            return dbc.Alert("No data for this contract.", color="secondary", style={"margin": "20px"})
        return html.Div([
            _graph(cv.fig_iv_rv_hist(contract, s)),
            _graph(cv.fig_iv_rv_spread(contract, s), 300),
            _graph(cv.fig_iv_rv_vrp(contract, s), 300),
            _graph(cv.fig_iv_rv_pctile(contract, s), 280),
            _graph(cv.fig_iv_rv_cone(contract, s), 360),
        ])

    if active_tab == "cvol-skew":
        s = (pc.get("skew") or {}).get(contract, {})
        return html.Div([
            _graph(cv.fig_skew_hist(contract, s)),
            _graph(cv.fig_skew_rr_fly(contract, s), 340),
            _graph(cv.fig_smile(contract, s), 380),
        ])

    if active_tab == "cvol-be":
        s = (pc.get("be") or {}).get(contract, {})
        if not s:
            return dbc.Alert("No data for this contract.", color="secondary", style={"margin": "20px"})
        return html.Div([
            _graph(cv.fig_be_price(contract, s), 380),
            _graph(cv.fig_be_pct(contract, s), 320),
            _graph(cv.fig_be_moves(contract, s), 420),
            _graph(cv.fig_be_hit(contract, s), 320),
            html.Div(cv.be_table(s), style={**_CHART, "padding": "12px"}),
        ])

    if active_tab == "cvol-wb":
        w = (pc.get("workbench") or {}).get(contract, {})
        ivrv = (pc.get("ivrv") or {}).get(contract, {})
        return html.Div([
            html.Div(cv.workbench_verdict(contract, w, ivrv), style={**_CHART, "padding": "12px"}),
            html.Div(id="cvol-wb-body"),
        ])
    return html.Div()


@callback(
    Output("cvol-wb-body", "children"),
    Input("cvol-wb-view", "value"),
    State("cvol-commodity", "value"),
    State("cvol-contract", "value"),
)
def _wb_body(view, commodity, contract):
    pc = (load_vol_data().get("byCommodity") or {}).get(commodity or "", {})
    w = (pc.get("workbench") or {}).get(contract or "", {})
    structs = (w.get("byPriceView") or {}).get(view or "", [])
    return html.Div([
        cv.workbench_cards(contract, structs),
        _graph(cv.fig_wb_payoff(contract, view or "", structs), 380),
    ])
