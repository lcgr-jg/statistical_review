"""Vol Monitor — Plotly figure + component builders.

Native port of ``eu_carbon`` ``desk.vol.plots`` (the seven-tab static
dashboard). Each function consumes a slice of the vol ``payload.json`` (see
``core.carbon.data.load_vol_data``) and returns either a ``go.Figure`` or a
Dash component. No data access here — pure presentation.
"""
from __future__ import annotations

from typing import Any

import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from dash import html

from core.carbon.constants import (
    CONTRACT_LINE_COLORS,
    SMILE_COLORS,
    SMILE_ORDER,
    TEMPLATE,
    VERDICT_COLORS,
    VOL_COLORS as C,
)

_LOGN_REF = 31.7  # ≈32% lognormal-consistent daily-breakeven hit rate, P(|z|>1)


# ── layout helpers ──────────────────────────────────────────────────────────

def _layout(fig: go.Figure, title: str, y_title: str = "", height: int = 420) -> go.Figure:
    fig.update_layout(
        template=TEMPLATE,
        title={"text": title, "font": {"size": 14}},
        height=height,
        margin={"l": 60, "r": 30, "t": 60, "b": 40},
        yaxis_title=y_title,
        legend={"orientation": "h", "yanchor": "bottom", "y": 1.0, "xanchor": "right", "x": 1.0},
        hovermode="x unified",
    )
    return fig


def _with_range(fig: go.Figure, s: dict) -> go.Figure:
    """Tenor-aware default window + 3m/6m/1y/all range buttons."""
    xaxis: dict[str, Any] = {"rangeselector": {"buttons": [
        {"count": 3, "label": "3m", "step": "month", "stepmode": "backward"},
        {"count": 6, "label": "6m", "step": "month", "stepmode": "backward"},
        {"count": 12, "label": "1y", "step": "month", "stepmode": "backward"},
        {"step": "all", "label": "all"},
    ]}}
    if s.get("rangeStart"):
        xaxis["range"] = [s["rangeStart"], s.get("rangeEnd")]
    fig.update_xaxes(**xaxis)
    return fig


def empty_fig(msg: str = "No data") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=msg, xref="paper", yref="paper", x=0.5, y=0.5,
                       showarrow=False, font={"size": 14, "color": "#888"})
    return _layout(fig, "", height=300)


def _zero_line(fig: go.Figure) -> go.Figure:
    fig.add_hline(y=0, line={"color": C["zero"], "width": 1, "dash": "dot"})
    return fig


# ── Overview tab ─────────────────────────────────────────────────────────────

def _fmt(v, nd=2, suffix=""):
    return "–" if v is None else f"{float(v):.{nd}f}{suffix}"


def _fmt_signed(v, nd=2):
    return "–" if v is None else f"{float(v):+.{nd}f}"


def _card(k: str, v: str) -> html.Div:
    return html.Div([
        html.Div(k, style={"fontSize": "11px", "color": "#757575",
                           "textTransform": "uppercase", "letterSpacing": ".4px"}),
        html.Div(v, style={"fontSize": "18px", "fontWeight": "600", "marginTop": "2px"}),
    ], style={"background": "#fff", "border": "1px solid #e0e0e0", "borderRadius": "8px",
              "padding": "8px 14px", "minWidth": "120px"})


def _pctile_label(base: str, lb, configured) -> str:
    if not lb:
        return base
    star = "*" if (configured and lb < configured) else ""
    return f"{base} (vs {lb}d{star})"


def overview_cards(strip: str, ov: dict) -> html.Div:
    """Headline card block for one contract (mirrors _headline_card_html)."""
    liq = ov.get("liquidity") or {}
    live_tag = " (settle)"
    if ov.get("fLive"):
        snap = (ov.get("liveAsOf") or "")[-5:]
        live_tag = f" (live {snap})" if snap else " (live)"

    cards = [
        ("Contract", strip),
        ("IV as of", ov.get("asOf", "–")),
        ("Days to expiry", str(ov.get("daysToExpiry", "–"))),
        ("Underlying", f"{_fmt(ov.get('F'))}{live_tag}"),
    ]
    if liq:
        cards.append(("Quotes / OI / Vol",
                      f"{liq.get('quotes', 0)} / {liq.get('open_interest', 0):,.0f} / {liq.get('volume', 0):,.0f}"))
        if liq.get("total_buckets"):
            cards.append(("Fallback buckets", f"{liq.get('fallback_buckets', 0)}/{liq['total_buckets']}"))
    conf = ov.get("pctileConfigured")
    cards += [
        ("ATM IV", _fmt(ov.get("atmIv"))),
        (_pctile_label("ATM IV pctile", ov.get("atmPctileLb"), conf), _fmt(ov.get("atmPctile"), 0, "%")),
        ("Put skew (25DP-50D)", _fmt_signed(ov.get("putSkew"))),
        ("Call skew (25DC-50D)", _fmt_signed(ov.get("callSkew"))),
        ("RR25", _fmt_signed(ov.get("rr25"))),
        (_pctile_label("|RR25| pctile", ov.get("rrPctileLb"), conf), _fmt(ov.get("rrPctile"), 0, "%")),
        ("Fly25", _fmt_signed(ov.get("fly25"))),
    ]
    cards += [(f"RV {w}d", _fmt(v)) for w, v in sorted((ov.get("rvLatest") or {}).items(),
                                                       key=lambda kv: int(kv[0]))]
    cards += [
        (f"Ex-post VRP ({ov.get('vrpWindow', '?')}d)", _fmt_signed(ov.get("vrpLatest"))),
        (_pctile_label("VRP pctile", ov.get("vrpPctileLb"), conf), _fmt(ov.get("vrpPctile"), 0, "%")),
        ("Term slope (pts/yr)", _fmt(ov.get("termSlope"))),
        ("Fwd vol → next", _fmt(ov.get("fwdVol"))),
    ]
    verdict = (ov.get("verdict") or "unknown")
    header = html.H5([
        f"{strip} — vol verdict: ",
        html.Span(verdict.upper(), style={"color": VERDICT_COLORS.get(verdict, "#616161"),
                                          "fontWeight": "700"}),
        html.Span(f"  (composite percentile {_fmt(ov.get('composite'), 0, '%')})",
                  style={"fontSize": "12px", "color": "#757575", "fontWeight": "400"}),
    ], style={"fontSize": "14px", "margin": "10px 0 8px"})
    return html.Div([
        header,
        html.Div(cards_to_row(cards), style={"display": "flex", "flexWrap": "wrap", "gap": "8px"}),
    ], style={"marginBottom": "10px"})


def cards_to_row(cards):
    return [_card(k, v) for k, v in cards]


def fig_atm_iv_comparison(pc: dict) -> go.Figure:
    """Cross-contract ATM IV history (built from each contract's ivrv slice)."""
    fig = go.Figure()
    for i, strip in enumerate(pc.get("contracts", [])):
        s = (pc.get("ivrv") or {}).get(strip)
        if not s:
            continue
        fig.add_trace(go.Scatter(
            x=s["dates"], y=s["atmIv"], name=strip, mode="lines",
            line={"width": 1.5, "color": CONTRACT_LINE_COLORS[i % len(CONTRACT_LINE_COLORS)]},
        ))
    return _layout(fig, "ATM implied vol history — all tracked contracts", "vol points")


# ── Implied vs realized tab ─────────────────────────────────────────────────

def fig_iv_rv_hist(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["atmIv"], name="ATM IV", mode="lines",
                   line={"color": C["iv"], "width": 1.6}),
        go.Scatter(x=s["dates"], y=s["rv"], name=f"RV {s['rvWindow']}d (close-close)",
                   mode="lines", line={"color": C["rv"], "width": 1.3}),
    ])
    return _with_range(_layout(fig, f"{strip} — ATM implied vol vs realized vol", "vol points"), s)


def fig_iv_rv_spread(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([go.Scatter(x=s["dates"], y=s["ivRvSpread"], name="spot-vol gap",
                                mode="lines", line={"color": C["spread"], "width": 1.4})])
    fig = _layout(fig, f"{strip} — spot-vol gap: ATM IV − trailing RV{s['rvWindow']} (regime gauge)",
                  "vol points", 300)
    return _zero_line(_with_range(fig, s))


def fig_iv_rv_vrp(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([go.Scatter(x=s["dates"], y=s["vrp"], name="ex-post VRP",
                                mode="lines", line={"color": C["vrp"], "width": 1.4})])
    fig = _layout(fig, f"{strip} — ex-post VRP: IV(t) − RV over [t, t+{s['vrpWindow']}d]",
                  "vol points", 300)
    return _zero_line(_with_range(fig, s))


def fig_iv_rv_pctile(strip: str, s: dict) -> go.Figure:
    lb = ""
    if s.get("atmLb"):
        lb = f" (vs trailing {s['atmLb']}d"
        if s.get("pctConfigured") and s["atmLb"] < s["pctConfigured"]:
            lb += f", configured {s['pctConfigured']}d"
        lb += ")"
    fig = go.Figure([go.Scatter(x=s.get("pctDates", []), y=s.get("pctVals", []),
                                name="ATM IV %ile", mode="lines+markers",
                                marker={"size": 4}, line={"color": C["iv"], "width": 1.3})])
    fig = _layout(fig, f"{strip} — ATM IV percentile rank{lb}", "percentile", 280)
    fig.update_yaxes(range=[0, 100])
    return _with_range(fig, s)


def fig_iv_rv_cone(strip: str, s: dict) -> go.Figure:
    cones = s.get("cones") or {}
    windows = sorted((int(w) for w in cones), key=int)
    fig = go.Figure()
    for p in ("p5", "p25", "p50", "p75", "p95"):
        fig.add_trace(go.Scatter(
            x=windows, y=[cones[str(w)].get(p) for w in windows], name=p, mode="lines+markers",
            marker={"size": 5, "color": "#90a4ae"},
            line={"color": "#90a4ae", "width": 2 if p == "p50" else 1,
                  "dash": "solid" if p == "p50" else "dot"},
        ))
    rv_latest = s.get("rvLatest") or {}
    fig.add_trace(go.Scatter(
        x=windows, y=[rv_latest.get(str(w)) for w in windows], name="current RV",
        mode="lines+markers", marker={"size": 9, "color": C["rv"]}, line={"color": C["rv"], "width": 2},
    ))
    fig = _layout(fig, f"{strip} — realized-vol cone (trailing {s.get('coneLookback', '?')} obs)",
                  "vol points", 360)
    fig.update_xaxes(title_text="RV window (days)")
    atm = s.get("atmLatest")
    if atm is not None:
        fig.add_hline(y=atm, line={"color": C["iv"], "width": 2, "dash": "dash"},
                      annotation_text="ATM IV", annotation_position="top left")
    return fig


# ── Skew tab ─────────────────────────────────────────────────────────────────

def fig_skew_hist(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["putSkew"], name="put skew (25DP-50D)",
                   mode="lines", line={"color": C["put"], "width": 1.4}),
        go.Scatter(x=s["dates"], y=s["callSkew"], name="call skew (25DC-50D)",
                   mode="lines", line={"color": C["call"], "width": 1.4}),
    ])
    return _layout(fig, f"{strip} — per-side skew history", "vol points")


def fig_skew_rr_fly(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["rr25"], name="RR25 (25DC-25DP)",
                   mode="lines", line={"color": "#6a1b9a", "width": 1.4}),
        go.Scatter(x=s["dates"], y=s["fly25"], name="Fly25",
                   mode="lines", line={"color": "#00838f", "width": 1.4}),
    ])
    return _layout(fig, f"{strip} — risk reversal / fly history", "vol points", 340)


def fig_smile(strip: str, s: dict) -> go.Figure:
    """Latest smile vs 1/7/30/60d ago; open markers = nearest-quote fallback."""
    cols = s.get("smileColumns", [])
    smiles = s.get("smiles") or {}
    fig = go.Figure()
    for label in SMILE_ORDER:
        sm = smiles.get(label)
        if not sm:
            continue
        fb = sm.get("fallback") or []
        vals = sm["values"]
        symbols = ["circle-open" if (i < len(fb) and fb[i]) else "circle" for i in range(len(vals))]
        fig.add_trace(go.Scatter(
            x=cols, y=vals, name=f"{label} ({sm['date']})", mode="lines+markers",
            line={"color": SMILE_COLORS.get(label, "#90a4ae"), "width": 2.2 if label == "today" else 1.3},
            marker={"size": 7 if label == "today" else 5, "symbol": symbols},
        ))
    fig = _layout(fig, f"{strip} — smile: latest vs 1d/7d/30d/60d ago (tick strikes = today)",
                  "vol points", 380)
    today = smiles.get("today")
    if today and today.get("strikes"):
        ticktext = [f"{c}<br>{k:.1f}" if k is not None else str(c)
                    for c, k in zip(cols, today["strikes"])]
        fig.update_xaxes(tickmode="array", tickvals=cols, ticktext=ticktext)
    return fig


# ── Surface tab ──────────────────────────────────────────────────────────────

def fig_surface_all(pc: dict) -> go.Figure:
    """Cross-contract latest surface heatmap (contract × delta bucket)."""
    skew = pc.get("skew") or {}
    strips = [c for c in pc.get("contracts", [])
              if skew.get(c, {}).get("smiles", {}).get("today")]
    if not strips:
        return empty_fig("Latest vol surface (no data)")
    cols = skew[strips[0]]["smileColumns"]
    z = [skew[c]["smiles"]["today"]["values"] for c in strips]
    y = [f"{c} ({skew[c]['smiles']['today']['date']})" for c in strips]
    fig = go.Figure(go.Heatmap(
        x=cols, y=y, z=z, colorscale="Viridis", texttemplate="%{z:.1f}",
        colorbar={"title": {"text": "IV"}},
    ))
    return _layout(fig, "Latest vol surface — all tracked contracts (IV, vol points)", "",
                   max(300, 150 + 42 * len(strips)))


def fig_surf_change(strip: str, s: dict) -> go.Figure:
    """IV change by bucket: today minus 1/7/30/60d ago."""
    cols = s.get("smileColumns", [])
    smiles = s.get("smiles") or {}
    today = smiles.get("today")
    rows = [lbl for lbl in SMILE_ORDER[1:] if smiles.get(lbl)]
    if not (today and rows):
        return empty_fig(f"{strip} — IV change by bucket (not enough history yet)")
    z, ylab = [], []
    for lbl in rows:
        vals = smiles[lbl]["values"]
        z.append([None if (v is None or today["values"][i] is None)
                  else round(today["values"][i] - v, 2) for i, v in enumerate(vals)])
        ylab.append(f"vs {lbl[1:]} ago ({smiles[lbl]['date']})")
    fig = go.Figure(go.Heatmap(
        x=cols, y=ylab, z=z, colorscale="RdBu", reversescale=True, zmid=0,
        texttemplate="%{z:+.2f}", colorbar={"title": {"text": "ΔIV"}},
    ))
    return _layout(fig, f"{strip} — IV change by bucket: today − 1d/7d/30d/60d ago", "", 340)


def fig_surf_history(strip: str, surf: dict) -> go.Figure:
    if not surf or not surf.get("dates"):
        return empty_fig(f"{strip} — surface history (no data)")
    cols = surf["columns"]
    zt = [[row[j] for row in surf["z"]] for j in range(len(cols))]
    fig = go.Figure(go.Heatmap(
        x=surf["dates"], y=cols, z=zt, colorscale="Viridis", colorbar={"title": {"text": "IV"}},
    ))
    return _layout(fig, f"{strip} — surface history (IV by delta bucket)", "", 420)


# ── Term structure tab ───────────────────────────────────────────────────────

def fig_term_structure_latest(term: dict) -> go.Figure:
    rows = sorted(term.get("latest", []), key=lambda r: r["dte"])
    fig = go.Figure()
    if rows:
        fig.add_trace(go.Scatter(
            x=[r["dte"] for r in rows], y=[r["atmIv"] for r in rows],
            mode="lines+markers+text", text=[r["strip"] for r in rows],
            textposition="top center", line={"color": C["atm"], "width": 1.5}, marker={"size": 9},
        ))
    fig = _layout(fig, "Term structure — ATM IV by days-to-expiry (latest date)", "vol points", 380)
    fig.update_xaxes(title_text="days to expiry")
    return fig


def _term_multi(series: dict, title: str, connectgaps: bool) -> go.Figure:
    fig = go.Figure()
    for i, (strip, sv) in enumerate(series.items()):
        fig.add_trace(go.Scatter(
            x=sv["dates"], y=sv["vals"], name=f"{strip} → next", mode="lines",
            line={"width": 1.3, "color": CONTRACT_LINE_COLORS[i % len(CONTRACT_LINE_COLORS)]},
            connectgaps=connectgaps,
        ))
    fig = _layout(fig, title, "vol points")
    return fig


def fig_term_slope_history(term: dict) -> go.Figure:
    fig = _term_multi(term.get("slope", {}),
                      "Term-structure slope history (vol points per year of tenor gap)", True)
    return _zero_line(fig)


def fig_forward_vol_history(term: dict) -> go.Figure:
    return _term_multi(term.get("fwdVol", {}),
                       "Forward vol between adjacent expiries (gaps = calendar inconsistency)", False)


# ── Breakevens tab ───────────────────────────────────────────────────────────

def fig_be_moves(strip: str, s: dict) -> go.Figure:
    cc_abs = [None if v is None else abs(v) for v in s["ccMove"]]
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["impliedBe"], name="implied daily BE",
                   mode="lines", line={"color": "#212121", "width": 1.6}),
        go.Bar(x=s["dates"], y=cc_abs, name="|close-close move|", marker={"color": "rgba(21,101,192,0.55)"}),
        go.Bar(x=s["dates"], y=s["hlMove"], name="high-low range", marker={"color": "rgba(239,108,0,0.45)"}),
    ])
    fig = _layout(fig, f"{strip} — implied daily breakeven vs realized moves", "price units", 420)
    fig.update_layout(hovermode="x unified", barmode="overlay")
    return _with_range(fig, s)


def fig_be_price(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["impliedBe"], name="implied daily BE",
                   mode="lines", line={"color": "#212121", "width": 1.6}),
        go.Scatter(x=s["dates"], y=s["close"], name="underlying close", mode="lines",
                   yaxis="y2", line={"color": C["iv"], "width": 1.2, "dash": "dot"}),
    ])
    fig = _layout(fig, f"{strip} — implied daily BE vs underlying flat price", "BE, price units", 380)
    fig.update_layout(yaxis2={"title": {"text": "underlying"}, "overlaying": "y", "side": "right",
                              "gridcolor": "rgba(0,0,0,0)"})
    return _with_range(fig, s)


def fig_be_pct(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([go.Scatter(x=s["dates"], y=s["bePct"], name="BE % of price",
                                mode="lines", line={"color": C["vrp"], "width": 1.5})])
    fig = _layout(fig, f"{strip} — implied daily BE as % of price", "% of price", 320)
    return _with_range(fig, s)


def fig_be_hit(strip: str, s: dict) -> go.Figure:
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["hitRollCc"], name="close-close",
                   mode="lines", line={"color": C["call"], "width": 1.4}),
        go.Scatter(x=s["dates"], y=s["hitRollHl"], name="high-low",
                   mode="lines", line={"color": C["rv"], "width": 1.4}),
    ])
    fig = _layout(fig, f"{strip} — rolling {s['hitWindow']}d hit rate: realized move cleared the BE",
                  "% of days", 320)
    fig.add_hline(y=_LOGN_REF, line={"color": C["zero"], "width": 1, "dash": "dot"},
                  annotation_text="≈32% lognormal-consistent", annotation_position="top right")
    return _with_range(fig, s)


def be_table(s: dict) -> Any:
    rows = s.get("hitTable") or []
    if not rows:
        return html.Div("Not enough history for any configured window yet.",
                        style={"fontSize": "12px", "color": "#757575", "padding": "8px 4px"})
    header = html.Thead(html.Tr([html.Th(h) for h in
                                 ["Window", "Hit rate (CoC)", "Hit rate (H-L)",
                                  "P&L proxy (CoC)", "P&L proxy (H-L)"]]))

    def _c(v, pct=False, nd=0):
        if v is None:
            return "–"
        return f"{v:.{nd}f}%" if pct else f"{v:.2f}"

    body = html.Tbody([
        html.Tr([
            html.Td(f"{r['window']}d"),
            html.Td(_c(r["hitCc"], pct=True)), html.Td(_c(r["hitHl"], pct=True)),
            html.Td(_c(r["pnlCc"])), html.Td(_c(r["pnlHl"])),
        ]) for r in rows
    ])
    return dbc.Table([header, body], bordered=False, hover=True, size="sm",
                     style={"fontSize": "13px"})


# ── Structure workbench tab ──────────────────────────────────────────────────

def _payoff_stats(payoff: dict) -> dict:
    f, pnl = payoff.get("F", []), payoff.get("pnl", [])
    if not pnl:
        return {"maxG": None, "maxL": None, "bes": []}
    max_g, max_l = max(pnl), min(pnl)
    bes = []
    for i in range(1, len(pnl)):
        a, b = pnl[i - 1], pnl[i]
        if (a <= 0 < b) or (a >= 0 > b):
            t = 0 if a == b else a / (a - b)
            bes.append(round(f[i - 1] + t * (f[i] - f[i - 1]), 2))
    return {"maxG": max_g, "maxL": max_l, "bes": bes}


def workbench_verdict(strip: str, w: dict, ivrv: dict) -> html.Div:
    def pct(v):
        return "–" if v is None else f"{v}%"
    pricing = (f"Structures priced off F={w.get('F')} "
               + (f"(LIVE snap{(' ' + w['liveAsOf']) if w.get('liveAsOf') else ''}) "
                  "against LAST-SETTLEMENT vols — premiums indicative, not executable"
                  if w.get("fLive") else "(last settle) against same-day settlement vols"))
    return html.Div([
        html.Div([
            "Vol verdict: ", html.B((w.get("verdict") or "?").upper()),
            f" (composite percentile {pct(w.get('compositePctile'))}) ",
            html.Span(f"ATM IV %ile {pct(w.get('atmPctile'))}, VRP %ile {pct(w.get('vrpPctile'))}, "
                      f"|RR25| %ile {pct(w.get('rrPctile'))}",
                      style={"fontSize": "12px", "color": "#757575"}),
        ]),
        html.Div(pricing, style={"fontSize": "12px", "color": "#757575", "marginTop": "4px"}),
    ])


def workbench_cards(strip: str, structs: list) -> html.Div:
    if not structs:
        return html.Div("No candidate structures for this price view.",
                        style={"fontSize": "12px", "color": "#757575", "padding": "8px 4px"})
    cards = []
    for st in structs:
        stats = _payoff_stats(st.get("payoff", {}))
        legs = [html.Tr([html.Td(lg["put_call"]), html.Td(f"K={lg['strike']}"),
                         html.Td(f"qty {lg['qty']}"), html.Td(f"σ={lg['sigma_pct']:.1f}%")])
                for lg in st.get("legs", [])]
        if st.get("future_qty"):
            legs.append(html.Tr([html.Td("FUT"), html.Td(f"qty {st['future_qty']}", colSpan=3)]))
        cards.append(html.Div([
            html.H6(st["name"].replace("_", " "), style={"margin": "0 0 6px"}),
            html.Div(f"premium {st['premium']:.3f} · delta {st['delta']:.3f} · "
                     f"gamma {st['gamma']:.5f} · vega/pt {st['vega'] / 100:.4f} · theta/day {st['theta']:.4f}",
                     style={"fontSize": "12.5px"}),
            html.Div(f"max gain {_fmt(stats['maxG'])} · max loss {_fmt(stats['maxL'])} · "
                     f"expiry BE {' / '.join(str(b) for b in stats['bes']) if stats['bes'] else '–'}",
                     style={"fontSize": "12px", "color": "#757575"}),
            dbc.Table(html.Tbody(legs), borderless=True, size="sm",
                      style={"fontSize": "12.5px", "marginTop": "4px", "width": "auto"}),
        ], style={"background": "#fff", "border": "1px solid #e0e0e0", "borderRadius": "8px",
                  "padding": "12px 16px", "marginBottom": "12px"}))
    return html.Div(cards)


def fig_wb_payoff(strip: str, view: str, structs: list) -> go.Figure:
    fig = go.Figure()
    for i, st in enumerate(structs):
        po = st.get("payoff", {})
        fig.add_trace(go.Scatter(
            x=po.get("F", []), y=po.get("pnl", []), name=st["name"].replace("_", " "),
            mode="lines", line={"width": 1.8, "color": CONTRACT_LINE_COLORS[i % len(CONTRACT_LINE_COLORS)]},
        ))
    fig = _layout(fig, f"{strip} — payoff at expiry ({view} price view)", "P&L, price units", 380)
    return _zero_line(fig)
