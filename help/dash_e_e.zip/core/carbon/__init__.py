"""Carbon desk pages (Vol Monitor, Timespreads).

Native Dash reimplementation of the eu_carbon desk dashboards. The heavy
compute (ICE settlements, Bloomberg, Snowflake) runs on the carbon PM's
machine in the ``eu_carbon`` repo, which publishes small computed payloads to
the shared S3 cache (bucket ``jg-tech1prod-s3-eu-gas-power``, prefix
``carbon/``). This package reads those payloads and renders the charts here,
so the portal owns the presentation without owning the model.

See ``core/carbon/data.py`` for the S3 contract.
"""
