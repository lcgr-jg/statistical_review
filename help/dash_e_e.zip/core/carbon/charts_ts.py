"""Timespreads — Plotly figure + component builders.

Native port of ``eu_carbon`` ``desk.curves.plots`` (+ the client-side
mean-reversion stats from its embedded JS, reimplemented in numpy here).
Overview / CDS figures are built from the published ``carry`` frame; the
interactive tabs (Explorer, Mean reversion, Banks) and the Signals tab are
built from the published ``payload.json``.
"""
from __future__ import annotations

import math
from typing import Any

import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import html

from core.carbon.constants import REGION_COLORS, TEMPLATE, TS_COLORS as C

_BP = 10_000.0
MAX_YEARS_OUT = 3


def _layout(fig: go.Figure, title: str, y_title: str = "", height: int = 420) -> go.Figure:
    fig.update_layout(
        template=TEMPLATE,
        title={"text": title, "font": {"size": 14}},
        height=height,
        margin={"l": 60, "r": 30, "t": 60, "b": 40},
        yaxis_title=y_title,
        legend={"orientation": "h", "yanchor": "bottom", "y": 1.0, "xanchor": "right", "x": 1.0},
        hovermode="x unified",
    )
    return fig


def empty_fig(msg: str = "No data") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=msg, xref="paper", yref="paper", x=0.5, y=0.5,
                       showarrow=False, font={"size": 14, "color": "#888"})
    return _layout(fig, "", height=300)


def _dates(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series.astype(str))


def _card(k: str, v: str) -> html.Div:
    return html.Div([
        html.Div(k, style={"fontSize": "11px", "color": "#757575",
                           "textTransform": "uppercase", "letterSpacing": ".4px"}),
        html.Div(v, style={"fontSize": "18px", "fontWeight": "600", "marginTop": "2px"}),
    ], style={"background": "#fff", "border": "1px solid #e0e0e0", "borderRadius": "8px",
              "padding": "8px 14px", "minWidth": "120px"})


def _cards_row(cards) -> html.Div:
    return html.Div([_card(k, v) for k, v in cards],
                    style={"display": "flex", "flexWrap": "wrap", "gap": "8px", "marginBottom": "12px"})


# ── Overview ────────────────────────────────────────────────────────────────

def _latest_frame(carry: pd.DataFrame) -> tuple[pd.DataFrame, Any]:
    latest_date = carry["trade_date"].max()
    return carry[carry["trade_date"] == latest_date], latest_date


def overview_cards(carry: pd.DataFrame) -> html.Div:
    if carry.empty:
        return html.Div()
    latest, latest_date = _latest_frame(carry)
    cards = [("Latest date", str(latest_date))]
    front = latest[latest["rank"] == 1]
    if not front.empty:
        r = front.iloc[0]
        pair = f"{r['leg1']}/{r['leg2']}"
        fair = r["leg1_settle"] * ((1.0 + r["funding_ann"]) ** (r["tenor_days"] / 365.0) - 1.0)
        cards += [
            (f"Front spread ({pair})", f"{r['spread']:.2f} /t"),
            ("Fair carry (OIS+CDS)", f"{fair:.2f} /t"),
            (f"Front carry ({pair})", f"{r['spread_pct_ann'] * 100:.2f}% ann"),
            ("Forward OIS", f"{r['rf_fwd_ann'] * 100:.2f}%"),
            ("CDS add-on (median)", f"{r['cds_global_bp']:.0f} bp"),
            ("Net yield", f"{r['net_yield_ann'] * _BP:.0f} bp"),
            ("Banks in composite", f"{int(r['n_banks'])}"),
        ]
        r1 = carry[carry["rank"] == 1].dropna(subset=["net_yield_ann"])
        if len(r1) > 250:
            pct = (r1["net_yield_ann"] < r["net_yield_ann"]).mean() * 100
            cards.append(("Net yield percentile", f"{pct:.0f}%"))
    return _cards_row(cards)


def fig_net_yield_history(carry: pd.DataFrame, ranks=(1, 2, 3)) -> go.Figure:
    fig = go.Figure()
    shades = {1: "#1565c0", 2: "#64b5f6", 3: "#bbdefb"}
    for rank in ranks:
        sel = carry[carry["rank"] == rank].sort_values("trade_date")
        if sel.empty:
            continue
        fig.add_trace(go.Scatter(
            x=_dates(sel["trade_date"]), y=sel["net_yield_ann"] * _BP,
            name=f"rank {rank} (Dec{rank}/Dec{rank + 1})", mode="lines",
            line={"width": 1.4, "color": shades.get(rank, "#90a4ae")},
        ))
    fig.add_hline(y=0, line={"color": C["zero"], "width": 1, "dash": "dot"})
    return _layout(fig, "Net yield (residual over bank funding) — chained Dec–Dec generics",
                   "bp, annualised")


def _cutoff(carry: pd.DataFrame):
    return pd.Timestamp(carry["trade_date"].max()) + pd.DateOffset(years=MAX_YEARS_OUT)


def fig_latest_term_structure(carry: pd.DataFrame) -> go.Figure:
    latest, _ = _latest_frame(carry)
    cutoff = _cutoff(carry)
    chain = latest[latest["rank"].notna() & (latest["rank"] > 0)].sort_values("rank")
    chain = chain[chain["expiry_leg2"].map(pd.Timestamp) <= cutoff]
    if chain.empty:
        return empty_fig("Latest decomposition — no data")
    labels = (chain["leg1"] + "/" + chain["leg2"]).tolist()
    fig = go.Figure([
        go.Bar(x=labels, y=chain["rf_fwd_ann"] * 100, name="forward OIS", marker_color=C["rf"]),
        go.Bar(x=labels, y=chain["cds_global_bp"] / 100, name="CDS add-on (global median)",
               marker_color=C["cds"]),
        go.Bar(x=labels, y=chain["net_yield_ann"] * 100, name="net yield", marker_color=C["net"]),
        go.Scatter(x=labels, y=chain["spread_pct_ann"] * 100, name="observed carry",
                   mode="markers", marker={"symbol": "diamond", "size": 10, "color": C["spread"]}),
    ])
    fig.update_layout(barmode="relative")
    return _layout(fig, "Latest decomposition — adjacent Dec–Dec pairs (stack = OIS + CDS + net yield)",
                   "% annualised", 380)


def fig_curve_heatmap(carry: pd.DataFrame) -> go.Figure:
    latest, _ = _latest_frame(carry)
    cutoff = _cutoff(carry)
    liquid = latest.dropna(subset=["net_yield_ann"]).copy()
    liquid = liquid[liquid["expiry_leg2"].map(pd.Timestamp) <= cutoff]
    if liquid.empty:
        return empty_fig("Whole-curve net yield — no data")
    leg_order = (
        pd.concat([
            liquid[["leg1", "expiry_leg1"]].rename(columns={"leg1": "leg", "expiry_leg1": "exp"}),
            liquid[["leg2", "expiry_leg2"]].rename(columns={"leg2": "leg", "expiry_leg2": "exp"}),
        ]).drop_duplicates("leg").sort_values("exp")["leg"].tolist()
    )
    grid = liquid.pivot_table(index="leg1", columns="leg2", values="net_yield_ann",
                              aggfunc="first") * _BP
    grid = grid.reindex(index=[l for l in leg_order if l in grid.index],
                        columns=[l for l in leg_order if l in grid.columns])
    fig = go.Figure(go.Heatmap(
        z=grid.values, x=list(grid.columns), y=list(grid.index),
        colorscale="RdBu", zmid=0.0, colorbar={"title": "bp"},
        hovertemplate="%{y} → %{x}: %{z:.1f} bp<extra></extra>",
    ))
    fig.update_layout(yaxis={"autorange": "reversed"})
    return _layout(fig, "Whole-curve net yield, latest date (near leg ↓, far leg →)", "", 480)


def fig_regional_cds(carry: pd.DataFrame, rank: int = 1) -> go.Figure:
    sel = carry[carry["rank"] == rank].sort_values("trade_date")
    if sel.empty:
        return empty_fig("CDS panel — no data")
    x = _dates(sel["trade_date"])
    fig = go.Figure()
    region_cols = [c for c in sel.columns
                   if c.startswith("cds_") and c.endswith("_bp") and c != "cds_global_bp"]
    for col in region_cols:
        region = col[len("cds_"):-len("_bp")].upper()
        fig.add_trace(go.Scatter(x=x, y=sel[col], name=region, mode="lines",
                                 line={"width": 1.1, "color": REGION_COLORS.get(region, "#90a4ae")}))
    fig.add_trace(go.Scatter(x=x, y=sel["cds_global_bp"], name="global median", mode="lines",
                             line={"width": 2.0, "color": REGION_COLORS["global"]}))
    return _layout(fig, "Bank CDS composites at the carry-window tenor — regional medians", "bp")


# ── Signals tab ──────────────────────────────────────────────────────────────

_SIGNAL_COLORS = {"RICH": "#1b5e20", "CHEAP": "#c62828", "watch+": "#e65100", "watch-": "#e65100"}


def signals_cards(sig: dict) -> html.Div:
    c = sig.get("cards") or {}
    cards = [
        ("Rich signals live", str(c.get("nRich", 0))),
        ("Cheap signals live", str(c.get("nCheap", 0))),
        ("On watch (|z| ≥ 1.5)", str(c.get("nWatch", 0))),
    ]
    if c.get("curveMedianBp") is not None:
        cards.append(("Curve median net yield", f"{c['curveMedianBp']:.0f} bp"))
    if c.get("regimePctile") is not None:
        cards.append(("Regime percentile (since 2008)", f"{c['regimePctile']:.0f}%"))
    return _cards_row(cards)


def signals_board_table(sig: dict) -> Any:
    board = sig.get("board") or []
    if not board:
        return html.Div("No live pairs with enough history.",
                        style={"fontSize": "12px", "color": "#757575", "padding": "8px 4px"})
    head = html.Thead(html.Tr([html.Th(h) for h in
                               ["Pair", "Near expiry", "Tenor (d)", "Spread /t", "Fair carry /t",
                                "Gap /t", "Net yield bp", "z (250d)", "Own-hist %ile", "Signal",
                                "Days in signal"]]))
    rows = []
    for r in board:
        sig_txt = r.get("signal") or ""
        color = _SIGNAL_COLORS.get(sig_txt)
        badge = html.Span(sig_txt, style={"color": color, "fontWeight": "600"}) if color else ""
        style = {"background": "#fffde7"} if sig_txt in ("RICH", "CHEAP") else {}
        rows.append(html.Tr([
            html.Td(r["pair"]), html.Td(r["expiryNear"]), html.Td(r["tenorDays"]),
            html.Td(f"{r['spread']:.2f}"), html.Td(f"{r['fairCarry']:.2f}"),
            html.Td(html.B(f"{r['gap']:+.2f}")), html.Td(f"{r['netBp']:.0f}"),
            html.Td(f"{r['z']:+.2f}"), html.Td(f"{r['pctile']:.0f}%"), html.Td(badge),
            html.Td(str(r["daysInSignal"]) if r["daysInSignal"] else ""),
        ], style=style))
    return dbc.Table([head, html.Tbody(rows)], bordered=False, hover=True, size="sm",
                     style={"fontSize": "13px"})


def fig_regime(sig: dict) -> go.Figure:
    r = sig.get("regime") or {}
    fig = go.Figure()
    if r.get("dates"):
        fig.add_trace(go.Scatter(x=r["dates"], y=r["q75"], mode="lines", line={"width": 0},
                                 showlegend=False, hoverinfo="skip"))
        fig.add_trace(go.Scatter(x=r["dates"], y=r["q25"], mode="lines", line={"width": 0},
                                 fill="tonexty", fillcolor="rgba(21,101,192,0.12)", name="cross-curve IQR"))
        fig.add_trace(go.Scatter(x=r["dates"], y=r["median"], mode="lines",
                                 line={"color": C["net"], "width": 1.6}, name="median net yield"))
        fig.add_hline(y=0, line={"color": C["zero"], "width": 1, "dash": "dot"})
    return _layout(fig, "Carry regime — cross-curve net yield median + IQR", "bp, annualised")


def fig_event_paths(sig: dict) -> go.Figure:
    paths = sig.get("eventPaths") or {}
    styles = {
        "rich": ("#1b5e20", "rgba(27,94,32,0.12)", "rich (+2σ): fade the richness"),
        "cheap": ("#c62828", "rgba(198,40,40,0.12)", "cheap (−2σ): own the carry"),
    }
    fig = go.Figure()
    for side, (color, fill, label) in styles.items():
        p = paths.get(side)
        if not p:
            continue
        fig.add_trace(go.Scatter(x=p["offset"], y=p["q75"], mode="lines", line={"width": 0},
                                 showlegend=False, hoverinfo="skip"))
        fig.add_trace(go.Scatter(x=p["offset"], y=p["q25"], mode="lines", line={"width": 0},
                                 fill="tonexty", fillcolor=fill, showlegend=False, hoverinfo="skip"))
        fig.add_trace(go.Scatter(x=p["offset"], y=p["median"], mode="lines",
                                 line={"color": color, "width": 2}, name=label))
    fig.add_hline(y=0, line={"color": C["zero"], "width": 1, "dash": "dot"})
    fig.update_xaxes(title_text="trading days after ±2σ trigger")
    return _layout(fig, "Event study — median forward net-yield change after a signal",
                   "Δ net yield vs trigger day, bp")


def event_summary_table(sig: dict) -> Any:
    summary = sig.get("eventSummary") or []
    if not summary:
        return html.Div()
    head = html.Thead(html.Tr([html.Th(h) for h in
                               ["Side", "Episodes", "Reverted", "Median days to revert",
                                "20d: hit / move", "60d: hit / move", "120d: hit / move"]]))
    rows = []
    for r in summary:
        color = "#1b5e20" if r["side"] == "rich" else "#c62828"
        cells = [
            html.Td(html.Span(r["side"].upper(), style={"color": color, "fontWeight": "600"})),
            html.Td(r["nEpisodes"]),
            html.Td("–" if r["pctReverted"] is None else f"{r['pctReverted']:.0f}%"),
            html.Td("–" if r["medianDaysToRevert"] is None else f"{r['medianDaysToRevert']:.0f}"),
        ]
        for h in (20, 60, 120):
            hit, move = r.get(f"hit{h}"), r.get(f"move{h}")
            cells.append(html.Td(f"{hit:.0f}% / {move:+.0f}bp" if hit is not None else "–"))
        rows.append(html.Tr(cells))
    return dbc.Table([head, html.Tbody(rows)], bordered=False, hover=True, size="sm",
                     style={"fontSize": "13px"})


# ── Spread explorer tab ──────────────────────────────────────────────────────

def fig_ex_pct(key: str, s: dict) -> go.Figure:
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["pct"], name="carry (spread % ann)", mode="lines",
                   line={"color": C["spread"], "width": 1.6}),
        go.Scatter(x=s["dates"], y=s["rf"], name="forward OIS", mode="lines",
                   line={"color": C["rf"], "width": 1.2}),
        go.Scatter(x=s["dates"], y=s["fund"], name="bank funding (OIS + CDS median)", mode="lines",
                   line={"color": C["cds"], "width": 1.2}),
    ])
    return _layout(fig, f"{key} — carry vs funding (% annualised)", "% annualised")


def fig_ex_nom(key: str, s: dict) -> go.Figure:
    fig = go.Figure([
        go.Scatter(x=s["dates"], y=s["nom"], name="observed spread", mode="lines",
                   line={"color": C["spread"], "width": 1.6}),
        go.Scatter(x=s["dates"], y=s["nomfund"], name="fair carry: OIS + CDS (breakeven)",
                   mode="lines", line={"color": C["cds"], "width": 1.2}),
        go.Scatter(x=s["dates"], y=s["nomrf"], name="fair carry: OIS only", mode="lines",
                   line={"color": C["rf"], "width": 1.0, "dash": "dot"}),
    ])
    return _layout(fig, f"{key} — nominal: observed spread vs funding-implied fair carry", "ccy/t")


def fig_ex_net(key: str, s: dict) -> go.Figure:
    fig = go.Figure([go.Scatter(x=s["dates"], y=s["net"], name="net yield", mode="lines",
                                line={"color": C["net"], "width": 1.4})])
    fig = _layout(fig, f"{key} — net yield (carry − funding)", "bp, annualised", 340)
    fig.add_hline(y=0, line={"color": C["zero"], "width": 1, "dash": "dot"})
    return fig


# ── Mean reversion tab (numpy port of the client-side stats) ─────────────────

MR_METRICS = {
    "net": {"label": "Net yield", "unit": "bp, annualised", "nd": 1, "suffix": " bp"},
    "nomnet": {"label": "Nominal net yield (spread − fair carry)", "unit": "ccy/t", "nd": 2, "suffix": " /t"},
    "nom": {"label": "Nominal spread", "unit": "ccy/t", "nd": 2, "suffix": " /t"},
    "pct": {"label": "Carry", "unit": "% annualised", "nd": 2, "suffix": "%"},
}


def _mr_fmt(v, metric: str) -> str:
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "–"
    m = MR_METRICS[metric]
    return f"{v:.{m['nd']}f}{m['suffix']}"


def _metric_values(s: dict, metric: str):
    dates, vals = [], []
    for i, d in enumerate(s["dates"]):
        if metric == "nomnet":
            a, b = s["nom"][i], s["nomfund"][i]
            v = (a - b) if (a is not None and b is not None) else None
        else:
            v = s[metric][i]
        if v is not None:
            dates.append(d)
            vals.append(float(v))
    return dates, np.array(vals, dtype=float)


def _rolling_stats(ys: np.ndarray, w: int):
    n = len(ys)
    mean = np.full(n, np.nan)
    sd = np.full(n, np.nan)
    min_pts = min(w, 40)
    ssum = ssq = 0.0
    for i in range(n):
        ssum += ys[i]
        ssq += ys[i] * ys[i]
        if i >= w:
            ssum -= ys[i - w]
            ssq -= ys[i - w] * ys[i - w]
        cnt = min(i + 1, w)
        if cnt >= min_pts:
            m = ssum / cnt
            mean[i] = m
            sd[i] = math.sqrt(max(ssq / cnt - m * m, 0.0))
    return mean, sd


def _half_life(ys: np.ndarray):
    if len(ys) < 61:
        return None
    x = ys[:-1]
    dy = np.diff(ys)
    n = len(x)
    sx, sy = x.sum(), dy.sum()
    sxx, sxy = (x * x).sum(), (x * dy).sum()
    denom = n * sxx - sx * sx
    if denom == 0:
        return None
    b = (n * sxy - sx * sy) / denom
    rho = 1 + b
    if rho <= 0 or rho >= 1:
        return None
    return math.log(0.5) / math.log(rho)


def _episodes(dates, ys, z):
    eps = []
    cur = None
    for i, v in enumerate(z):
        if v is None or math.isnan(v):
            continue
        if cur is None:
            if abs(v) >= 2:
                cur = {"si": i, "dir": 1 if v > 0 else -1, "pz": v, "pi": i}
        else:
            if v * cur["dir"] > cur["pz"] * cur["dir"]:
                cur["pz"], cur["pi"] = v, i
            if v * cur["dir"] <= 0:
                eps.append({"start": dates[cur["si"]], "end": dates[i], "dir": cur["dir"],
                            "peakZ": cur["pz"], "entry": ys[cur["si"]], "peak": ys[cur["pi"]],
                            "peakDate": dates[cur["pi"]], "exit": ys[i],
                            "days": i - cur["si"], "reverted": True})
                cur = None
    if cur is not None:
        i = len(z) - 1
        eps.append({"start": dates[cur["si"]], "end": dates[i], "dir": cur["dir"],
                    "peakZ": cur["pz"], "entry": ys[cur["si"]], "peak": ys[cur["pi"]],
                    "peakDate": dates[cur["pi"]], "exit": ys[i],
                    "days": i - cur["si"], "reverted": False})
    return eps


def mr_compute(s: dict, metric: str, window: int) -> dict:
    dates, ys = _metric_values(s, metric)
    if len(ys) < 30:
        return {"ok": False, "dates": dates, "ys": ys}
    mean, sd = _rolling_stats(ys, window)
    with np.errstate(invalid="ignore", divide="ignore"):
        z = np.where((~np.isnan(mean)) & (sd != 0), (ys - mean) / sd, np.nan)
    up2 = mean + 2 * sd
    dn2 = mean - 2 * sd
    p10, p50, p90 = np.nanpercentile(ys, [10, 50, 90])
    cur = ys[-1]
    cur_z = z[-1] if not math.isnan(z[-1]) else None
    pctile = 100.0 * np.mean(ys < cur)
    hl = _half_life(ys)
    eps = _episodes(dates, ys, z.tolist())
    revert_days = sorted(e["days"] for e in eps if e["reverted"])
    med_revert = float(np.median(revert_days)) if revert_days else None
    return {
        "ok": True, "dates": dates, "ys": ys, "mean": mean, "sd": sd, "z": z,
        "up2": up2, "dn2": dn2, "p10": p10, "p50": p50, "p90": p90,
        "cur": cur, "curZ": cur_z, "pctile": pctile, "hl": hl,
        "episodes": eps, "medRevert": med_revert,
    }


def mr_cards(mr: dict, metric: str, window: int) -> html.Div:
    if not mr.get("ok"):
        return _cards_row([("Data", "too few observations")])
    live = mr["episodes"] and not mr["episodes"][-1]["reverted"]
    last_mean = mr["mean"][-1]
    cards = [
        ("Current", _mr_fmt(mr["cur"], metric)),
        (f"Rolling mean ({window}d)", "–" if math.isnan(last_mean) else _mr_fmt(last_mean, metric)),
        ("Z-score", "–" if mr["curZ"] is None else f"{mr['curZ']:.2f}"),
        ("Full-history percentile", f"{mr['pctile']:.0f}%"),
        ("AR(1) half-life", "no reversion" if mr["hl"] is None else f"{mr['hl']:.0f} days"),
        ("Signal episodes", f"{len(mr['episodes'])}{' (1 live now)' if live else ''}"),
        ("Median days to revert", "–" if mr["medRevert"] is None else f"{mr['medRevert']:.0f} days"),
    ]
    return _cards_row(cards)


def fig_mr_band(key: str, mr: dict, metric: str, window: int) -> go.Figure:
    if not mr.get("ok"):
        return empty_fig(f"{key} — too few observations")
    m = MR_METRICS[metric]
    xs, ys = mr["dates"], mr["ys"]
    fig = go.Figure([
        go.Scatter(x=xs, y=mr["up2"], name="+2σ", mode="lines", line={"width": 0},
                   showlegend=False, hoverinfo="skip"),
        go.Scatter(x=xs, y=mr["dn2"], name="±2σ band", mode="lines", line={"width": 0},
                   fill="tonexty", fillcolor="rgba(21,101,192,0.10)"),
        go.Scatter(x=xs, y=mr["mean"], name=f"rolling mean ({window}d)", mode="lines",
                   line={"color": "#90a4ae", "width": 1.2, "dash": "dot"}),
        go.Scatter(x=xs, y=ys, name=m["label"], mode="lines", line={"color": C["net"], "width": 1.5}),
    ])
    fig = _layout(fig, f"{key} — {m['label']} with rolling ±2σ band + signal episodes", m["unit"], 440)
    for lvl, lab, col in [(mr["p10"], "P10", "#9e9e9e"), (mr["p50"], "P50", "#616161"),
                          (mr["p90"], "P90", "#9e9e9e")]:
        fig.add_hline(y=lvl, line={"color": col, "width": 1, "dash": "dash"},
                      annotation_text=lab, annotation_position="right")
    for e in mr["episodes"]:
        fig.add_vrect(x0=e["start"], x1=e["end"], line_width=0, layer="below",
                      fillcolor="rgba(27,94,32,0.08)" if e["dir"] > 0 else "rgba(198,40,40,0.08)")
    return fig


def fig_mr_z(key: str, mr: dict, window: int) -> go.Figure:
    if not mr.get("ok"):
        return empty_fig(f"{key} — too few observations")
    xs, z = mr["dates"], mr["z"]
    sx = [xs[i] for i, v in enumerate(z) if not math.isnan(v) and abs(v) >= 2]
    sy = [v for v in z if not math.isnan(v) and abs(v) >= 2]
    fig = go.Figure([
        go.Scatter(x=xs, y=z, name="z-score", mode="lines", line={"color": "#455a64", "width": 1.2}),
        go.Scatter(x=sx, y=sy, name="|z|≥2", mode="markers", marker={"color": "#c62828", "size": 4}),
    ])
    fig = _layout(fig, f"{key} — rolling z-score ({window}d): |z|≥2 = stretched", "z", 320)
    for y in (2, -2):
        fig.add_hline(y=y, line={"color": "#c62828", "width": 1, "dash": "dash"})
    fig.add_hline(y=0, line={"color": C["zero"], "width": 1, "dash": "dot"})
    return fig


def fig_mr_hist(key: str, mr: dict, metric: str) -> go.Figure:
    if not mr.get("ok"):
        return empty_fig(f"{key} — too few observations")
    m = MR_METRICS[metric]
    fig = go.Figure([go.Histogram(x=mr["ys"], nbinsx=60, marker={"color": "rgba(21,101,192,0.55)"},
                                  name=m["label"])])
    fig = _layout(fig, f"{key} — full-history distribution (red line = today)", "count", 320)
    fig.update_layout(hovermode="closest")
    fig.update_xaxes(title_text=m["unit"])
    fig.add_vline(x=mr["cur"], line={"color": "#c62828", "width": 2},
                  annotation_text=f"today ({mr['pctile']:.0f}%ile)", annotation_position="top")
    return fig


def mr_episodes_table(mr: dict, metric: str) -> Any:
    if not mr.get("ok") or not mr["episodes"]:
        return html.Div("No |z|≥2 episodes in this history/window.",
                        style={"fontSize": "12px", "color": "#757575", "padding": "8px 4px"})
    head = html.Thead(html.Tr([html.Th(h) for h in
                               ["Signal start", "Side", "Entry", "Peak", "Reverted to mean",
                                "Peak→mean move"]]))
    rows = []
    for e in reversed(mr["episodes"]):
        color = "#1b5e20" if e["dir"] > 0 else "#c62828"
        side = html.Span("rich" if e["dir"] > 0 else "cheap", style={"color": color, "fontWeight": "600"})
        status = f"{e['end']} ({e['days']}d)" if e["reverted"] else html.B("still open")
        move = _mr_fmt(abs(e["peak"] - e["exit"]), metric)
        rows.append(html.Tr([
            html.Td(e["start"]), html.Td(side), html.Td(_mr_fmt(e.get("entry", e["peak"]), metric)),
            html.Td([_mr_fmt(e["peak"], metric),
                     html.Span(f" (z {e['peakZ']:.1f}, {e['peakDate']})",
                               style={"fontSize": "11px", "color": "#757575"})]),
            html.Td(status), html.Td(move),
        ]))
    return dbc.Table([head, html.Tbody(rows)], bordered=False, hover=True, size="sm",
                     style={"fontSize": "13px"})


# ── Banks tab ────────────────────────────────────────────────────────────────

def fig_banks(key: str, rows: list, region_colors: dict) -> go.Figure:
    if not rows:
        return empty_fig(f"{key} — no bank data")
    banks = [r["bank"] for r in rows]
    fig = go.Figure([
        go.Bar(y=banks, x=[r["cds"] for r in rows], name="CDS add-on (bp)", orientation="h",
               marker={"color": [region_colors.get(r["region"], "#90a4ae") for r in rows]}),
        go.Scatter(y=banks, x=[r["net"] for r in rows], name="net yield after funding (bp)",
                   mode="markers", marker={"symbol": "diamond", "size": 9, "color": "#212121"}),
    ])
    fig = _layout(fig, f"{key} — funding add-on (bars, by region) + residual net yield (diamonds)",
                  "", max(380, 60 + len(rows) * 28))
    fig.update_layout(hovermode="y unified")
    fig.update_xaxes(title_text="bp, annualised")
    return fig
