"""Carbon desk pages — S3 data loading.

The ``eu_carbon`` repo publishes small computed payloads to the shared S3
cache after each settlement run (``scripts/publish_carbon_s3.py``). This
module reads them, using the same ``jain_commods`` S3 interface (and therefore
the same credentials / bucket) the rest of the dashboard already uses.

S3 keys consumed (see ``core.carbon.constants``):

    carbon/vol/payload.json                         (vol, all tabs)
    carbon/timespreads/EUA/payload.json             (timespreads interactive tabs + signals)
    carbon/timespreads/EUA/carry.parquet            (timespreads overview + CDS figures)
    carbon/timespreads/EUA/bank_funding_latest.parquet
    carbon/timespreads/EUA/meta.json

Both loaders are disk-cache-backed via ``core.cache.dashboard_cache`` so the
first page visit is fast and S3 is only hit on a miss / scheduled refresh.
"""
from __future__ import annotations

import json
import logging
from io import BytesIO
from typing import Any

import pandas as pd

from core.carbon import constants as C

logger = logging.getLogger(__name__)

_S3_SINGLETON: Any = None


def _s3():
    """Lazily construct and cache the jain_commods S3 interface."""
    global _S3_SINGLETON
    if _S3_SINGLETON is None:
        from jain_commods.core.interfaces.aws.s3 import S3  # noqa: PLC0415
        _S3_SINGLETON = S3(bucket_name=C.S3_BUCKET)
    return _S3_SINGLETON


def _get_dc():
    try:
        from core.cache import dashboard_cache  # noqa: PLC0415
        return dashboard_cache
    except Exception:
        return None


def _read_json(key: str) -> dict:
    """Read a JSON object from S3 → dict ({} on any failure)."""
    s3 = _s3()
    try:
        obj = s3._s3_client.get_object(Bucket=s3._bucket, Key=key)
        return json.loads(obj["Body"].read())
    except Exception as exc:
        logger.warning("Carbon S3 JSON read failed (%s): %s", key, exc)
        return {}


def _read_parquet(key: str) -> pd.DataFrame:
    """Read a parquet frame from S3 → DataFrame (empty on any failure)."""
    s3 = _s3()
    try:
        obj = s3._s3_client.get_object(Bucket=s3._bucket, Key=key)
        return pd.read_parquet(BytesIO(obj["Body"].read()))
    except Exception as exc:
        logger.warning("Carbon S3 parquet read failed (%s): %s", key, exc)
        return pd.DataFrame()


# ── Source loaders (registered with dashboard_cache in portal_app) ─────────
# These are the raw S3 fetchers. dashboard_cache.register_source(...) wraps
# each one, caching under "source:<name>" and re-running it on the scheduled
# refresh. Pages read via load_*_data() below, which routes through
# get_data(name) (memory → disk → loader) and falls back to a direct fetch
# when the source is not registered (e.g. tests, or import before startup).

def _fetch_vol() -> dict:
    payload = _read_json(C.VOL_PAYLOAD_KEY)
    if not payload:
        logger.warning("Carbon vol payload empty/missing at %s", C.VOL_PAYLOAD_KEY)
    return payload


def _fetch_timespreads() -> dict:
    return {
        "payload": _read_json(C.TS_PAYLOAD_KEY),
        "carry": _read_parquet(C.TS_CARRY_KEY),
        "bank": _read_parquet(C.TS_BANK_KEY),
        "meta": _read_json(C.TS_META_KEY),
    }


def _via_cache(source: str, fetch):
    dc = _get_dc()
    if dc is not None:
        try:
            data = dc.get_data(source)  # memory → disk → registered loader
            if data is not None:
                return data
        except Exception as exc:
            logger.debug("Carbon get_data(%s) failed: %s", source, exc)
    return fetch()


def load_vol_data() -> dict:
    """Return the vol ``payload.json`` dict.

    Shape: ``{commodities, default, byCommodity: {<name>: {contracts, default,
    ivrv, skew, surf, be, workbench, overview, term}}, colors}``.
    """
    return _via_cache(C.VOL_SOURCE, _fetch_vol) or {}


def load_timespreads_data() -> dict:
    """Return the timespreads bundle.

    ``{payload: dict, carry: DataFrame, bank: DataFrame, meta: dict}``.
    ``payload`` drives the interactive tabs + Signals; ``carry`` drives the
    Overview / CDS figures (pure-pandas ports of desk.curves.plots).
    """
    return _via_cache(C.TS_SOURCE, _fetch_timespreads) or _fetch_timespreads()


def clear_carbon_cache() -> None:
    """Drop both carbon bundles from the disk cache (forces a fresh S3 pull)."""
    dc = _get_dc()
    if dc is None:
        return
    for name in (C.VOL_SOURCE, C.TS_SOURCE):
        try:
            dc.delete(f"source:{name}")
        except Exception:
            pass
