"""
Carbon section — static dashboard hosting.

The EU carbon desk's dashboards (vol, timespreads, factors, switching,
positioning, auctions, balance, balance-lab) are generated as single self-contained Plotly HTML files by
scheduled jobs in the `eu_carbon` repo (they run on the carbon PM's machine
after each ICE settlement). This module lets the portal host them without
owning their build:

* ``POST /api/carbon/upload/<slug>``  — the carbon jobs push a fresh HTML
  file after every run (HTTP Basic against the portal's ``DASH_LOGIN_USERS``).
* ``GET /carbon-static/<slug>.html``  — serves the latest pushed file to the
  logged-in browser (protected by the app's global login redirect).
* ``iframe_page_layout(slug)``        — full-height iframe layout used by the
  ``pages/carbon_*.py`` registrars.

Files live under ``<repo>/cache/carbon`` which in production is the
``/var/lib/eu-dashboard/cache`` host volume — they survive container
rebuilds and redeploys, so a redeploy never blanks the carbon pages.
"""
from __future__ import annotations

import base64
import logging
import os
import tempfile
from datetime import datetime
from pathlib import Path

from dash import html
from flask import request

logger = logging.getLogger(__name__)

# slug -> sidebar display name; pages/carbon_*.py and the upload endpoint
# both key off this dict, so adding another carbon dashboard is one entry
# here plus one registrar file.
CARBON_PAGES: dict[str, str] = {
    "vol": "Vol Monitor",
    "timespreads": "Timespreads",
    "factors": "Factors",
    "switching": "Switching",
    "positioning": "Positioning (COT)",
    "auctions": "Auctions",
    "balance": "Balance",
    "balance-lab": "Balance lab",
}

# Cap only guards against a runaway payload (timespreads ~7 MB today).
_MAX_UPLOAD_BYTES = 50 * 1024 * 1024

_CARBON_DIR = Path(__file__).resolve().parents[1] / "cache" / "carbon"


def _carbon_file(slug: str) -> Path:
    return _CARBON_DIR / f"{slug}.html"


def _placeholder_html(slug: str) -> str:
    name = CARBON_PAGES.get(slug, slug)
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{name}</title></head>
<body style="font-family:-apple-system,'Segoe UI',Roboto,sans-serif;
             display:grid;place-items:center;height:95vh;color:#6b778c;">
  <div style="text-align:center;">
    <div style="font-size:18px;font-weight:600;color:#172b4d;">{name}: no dashboard published yet</div>
    <div style="margin-top:8px;font-size:13px;">The carbon desk job pushes a fresh file after each
    settlement run. If this persists, check the eu_carbon scheduled tasks.</div>
  </div>
</body></html>"""


def iframe_page_layout(slug: str) -> html.Div:
    """Full-height iframe onto the served static file (70px header offset)."""
    return html.Div(
        html.Iframe(
            src=f"/carbon-static/{slug}.html",
            style={
                "width": "100%",
                "height": "calc(100vh - 70px)",
                "border": "none",
                "display": "block",
            },
        ),
        style={"margin": "0", "padding": "0"},
    )


def _basic_auth_ok(login_users: dict, password_matches) -> bool:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Basic "):
        return False
    try:
        decoded = base64.b64decode(header[6:]).decode("utf-8")
        username, _, password = decoded.partition(":")
    except Exception:
        return False
    stored = login_users.get(username)
    return bool(stored) and password_matches(stored, password)


def attach_carbon_routes(server, login_users: dict, password_matches) -> None:
    """Register the serve + upload routes on the Flask server.

    ``login_users`` / ``password_matches`` are the portal's own auth
    primitives (portal_app._LOGIN_USERS / _password_matches) so the upload
    endpoint accepts exactly the same credentials as the login page — no
    second secret to manage. When auth is disabled (local dev), uploads are
    accepted without credentials, mirroring the rest of the app.
    """

    @server.route("/carbon-static/<slug>.html", methods=["GET"])
    def carbon_static_file(slug: str):
        if slug not in CARBON_PAGES:
            return "Unknown carbon page", 404
        path = _carbon_file(slug)
        if not path.exists():
            return _placeholder_html(slug), 200, {"Content-Type": "text/html"}
        stamp = datetime.fromtimestamp(path.stat().st_mtime)
        return (
            path.read_bytes(),
            200,
            {
                "Content-Type": "text/html; charset=utf-8",
                "Last-Modified": stamp.strftime("%a, %d %b %Y %H:%M:%S GMT"),
                # always revalidate: the file changes daily and browsers must
                # not pin yesterday's dashboard
                "Cache-Control": "no-cache",
            },
        )

    @server.route("/api/carbon/upload/<slug>", methods=["POST", "PUT"])
    def carbon_upload(slug: str):
        if login_users and not _basic_auth_ok(login_users, password_matches):
            return (
                '{"error": "unauthorized"}',
                401,
                {"Content-Type": "application/json", "WWW-Authenticate": "Basic"},
            )
        if slug not in CARBON_PAGES:
            return '{"error": "unknown page slug"}', 404, {"Content-Type": "application/json"}
        if request.content_length and request.content_length > _MAX_UPLOAD_BYTES:
            return '{"error": "payload too large"}', 413, {"Content-Type": "application/json"}

        body = request.get_data(cache=False)
        if not body:
            return '{"error": "empty body"}', 400, {"Content-Type": "application/json"}

        _CARBON_DIR.mkdir(parents=True, exist_ok=True)
        target = _carbon_file(slug)
        # atomic replace so a browser never reads a half-written dashboard
        fd, tmp_name = tempfile.mkstemp(dir=str(_CARBON_DIR), suffix=".tmp")
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(body)
            os.replace(tmp_name, target)
        except Exception:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass
            raise
        logger.info("Carbon upload: %s (%d bytes)", target.name, len(body))
        return (
            f'{{"status": "ok", "page": "{slug}", "bytes": {len(body)}}}',
            200,
            {"Content-Type": "application/json"},
        )
