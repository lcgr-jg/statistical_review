"""Layout for the Hydro dashboard (pure, no callbacks)."""
from __future__ import annotations

import dash_bootstrap_components as dbc
from dash import dcc, html

from core.styles import COLORS

from .constants import (
    DEFAULT_ZONE,
    DOY_DEFAULT_END,
    DOY_DEFAULT_START,
    DOY_MARKS,
    DOY_SLIDER_MAX,
    DOY_SLIDER_MIN,
    HYDRO_TYPE_OPTIONS,
    HYDRO_TYPE_RES,
    ZONE_OPTIONS,
)

_LABEL_STYLE = {"fontSize": "11px"}
_LABEL_CLASS = "small text-muted fw-bold text-uppercase"

_CHART_STYLE = {
    "backgroundColor": COLORS["chart_bg"],
    "borderRadius": "6px",
    "border": f"1px solid {COLORS['border']}",
    "padding": "4px",
}

_CONTROLS_STYLE = {
    "padding": "14px 0 12px 0",
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "marginBottom": "16px",
}

_TAB_STYLE = {
    "fontWeight": "500",
    "fontSize": "13px",
    "color": COLORS["text_secondary"],
    "borderBottom": "2px solid transparent",
    "padding": "8px 18px",
}

_TAB_ACTIVE_STYLE = {
    **_TAB_STYLE,
    "color": COLORS["accent"],
    "borderBottom": f"2px solid {COLORS['accent']}",
    "backgroundColor": "transparent",
}


def _label(text: str) -> html.Label:
    return html.Label(text, className=_LABEL_CLASS, style=_LABEL_STYLE)


def _reservoir_pricing_tab() -> html.Div:
    """Full content for the Reservoir Pricing tab: controls + charts."""
    return html.Div(
        children=[
            # ── Controls ─────────────────────────────────────────────────
            html.Div(
                style=_CONTROLS_STYLE,
                children=[
                    dbc.Row(
                        [
                            # Country
                            dbc.Col(
                                [
                                    _label("Country"),
                                    dbc.Select(
                                        id="hydro-zone",
                                        options=ZONE_OPTIONS,
                                        value=DEFAULT_ZONE,
                                        persistence=True,
                                        persistence_type="local",
                                        style={"maxWidth": "120px"},
                                    ),
                                ],
                                width="auto",
                            ),
                            # Hydro Type
                            dbc.Col(
                                [
                                    _label("Hydro Type"),
                                    dbc.RadioItems(
                                        id="hydro-type",
                                        options=HYDRO_TYPE_OPTIONS,
                                        value=HYDRO_TYPE_RES,
                                        inline=True,
                                        persistence=True,
                                        persistence_type="local",
                                        className="mt-1",
                                    ),
                                ],
                                width="auto",
                            ),
                            # Y-axis toggle
                            dbc.Col(
                                [
                                    _label("Y-axis"),
                                    dbc.RadioItems(
                                        id="hydro-y-axis",
                                        options=[
                                            {"label": "Spot price", "value": "price"},
                                            {"label": "Heat rate", "value": "heat_rate"},
                                        ],
                                        value="heat_rate",
                                        inline=True,
                                        persistence=True,
                                        persistence_type="local",
                                        className="mt-1",
                                    ),
                                ],
                                width="auto",
                            ),
                            # Color variable
                            dbc.Col(
                                [
                                    _label("Color by"),
                                    dbc.Select(
                                        id="hydro-color-var",
                                        options=[
                                            {"label": "Year", "value": "year"},
                                            {"label": "Hydro balance", "value": "hydro_bal_mwh"},
                                        ],
                                        value="hydro_bal_mwh",
                                        persistence=True,
                                        persistence_type="local",
                                        style={"maxWidth": "180px"},
                                    ),
                                ],
                                width="auto",
                            ),
                            # Date range slider (day of year)
                            dbc.Col(
                                [
                                    _label("Day-of-year window"),
                                    html.Div(
                                        id="hydro-doy-display",
                                        style={
                                            "fontSize": "12px",
                                            "color": COLORS["text_secondary"],
                                            "marginBottom": "4px",
                                        },
                                    ),
                                    dcc.RangeSlider(
                                        id="hydro-doy-range",
                                        min=DOY_SLIDER_MIN,
                                        max=DOY_SLIDER_MAX,
                                        step=1,
                                        value=[DOY_DEFAULT_START, DOY_DEFAULT_END],
                                        marks=DOY_MARKS,
                                        tooltip={"placement": "bottom", "always_visible": False},
                                        allowCross=False,
                                        persistence=True,
                                        persistence_type="local",
                                    ),
                                ],
                                style={"minWidth": "360px"},
                            ),
                        ],
                        align="start",
                        className="g-3",
                    ),
                ],
            ),

            # ── Charts ───────────────────────────────────────────────────
            dcc.Loading(
                type="dot",
                color=COLORS["accent"],
                children=[
                    # Scatter
                    html.Div(
                        [
                            html.Div(
                                id="hydro-scatter-title",
                                style={
                                    "fontWeight": "600",
                                    "fontSize": "13px",
                                    "color": COLORS["text_primary"],
                                    "marginBottom": "4px",
                                },
                            ),
                            dcc.Graph(
                                id="hydro-scatter",
                                config={"displayModeBar": "hover", "scrollZoom": True},
                                style={"height": "520px"},
                            ),
                        ],
                        style={**_CHART_STYLE, "marginBottom": "0px"},
                    ),
                ],
            ),

            # ── Hydro balance filter (outside loading — instant interaction) ──
            html.Div(
                style={
                    "backgroundColor": COLORS["card_bg"],
                    "border": f"1px solid {COLORS['border']}",
                    "borderTop": "none",
                    "borderRadius": "0 0 6px 6px",
                    "padding": "10px 14px 12px 14px",
                    "marginBottom": "16px",
                },
                children=[
                    dbc.Row(
                        [
                            # Toggle button
                            dbc.Col(
                                dbc.Button(
                                    "Balance Filter: OFF",
                                    id="hydro-bal-active",
                                    n_clicks=0,
                                    size="sm",
                                    color="secondary",
                                    outline=True,
                                    style={"whiteSpace": "nowrap", "fontSize": "11px"},
                                ),
                                width="auto",
                                className="d-flex align-items-center",
                            ),
                            # Slider
                            dbc.Col(
                                dcc.RangeSlider(
                                    id="hydro-bal-range",
                                    min=0,
                                    max=100,
                                    step=1,
                                    value=[25, 75],
                                    marks={
                                        0: "0th",
                                        25: "25th",
                                        50: "50th",
                                        75: "75th",
                                        100: "100th",
                                    },
                                    tooltip={"placement": "bottom", "always_visible": False},
                                    allowCross=False,
                                    persistence=True,
                                    persistence_type="local",
                                ),
                                style={"paddingTop": "6px"},
                            ),
                            # Display label
                            dbc.Col(
                                html.Div(
                                    id="hydro-bal-display",
                                    style={
                                        "fontSize": "11px",
                                        "color": COLORS["text_muted"],
                                        "whiteSpace": "nowrap",
                                    },
                                ),
                                width="auto",
                                className="d-flex align-items-center",
                            ),
                        ],
                        align="center",
                        className="g-2",
                    ),
                ],
            ),

            dcc.Loading(
                type="dot",
                color=COLORS["accent"],
                children=[
                    # Ridgeline
                    html.Div(
                        [
                            html.Div(
                                "Distribution by Year (Ridgeline)",
                                style={
                                    "fontWeight": "600",
                                    "fontSize": "13px",
                                    "color": COLORS["text_primary"],
                                    "marginBottom": "4px",
                                },
                            ),
                            dcc.Graph(
                                id="hydro-violin",
                                config={"displayModeBar": "hover"},
                                style={"height": "860px"},
                            ),
                        ],
                        style=_CHART_STYLE,
                    ),
                    # Status bar
                    html.Div(
                        id="hydro-status-bar",
                        style={
                            "marginTop": "8px",
                            "fontSize": "11px",
                            "color": COLORS["text_muted"],
                        },
                    ),
                ],
            ),
        ],
    )


def _short_term_tab() -> html.Div:
    """Content for the Short-Term tab: its own controls + bucket chart."""
    return html.Div(
        children=[
            # ── Controls ─────────────────────────────────────────────────
            html.Div(
                style=_CONTROLS_STYLE,
                children=[
                    dbc.Row(
                        [
                            # Country
                            dbc.Col(
                                [
                                    _label("Country"),
                                    dbc.Select(
                                        id="hydro-st-zone",
                                        options=ZONE_OPTIONS,
                                        value=DEFAULT_ZONE,
                                        persistence=True,
                                        persistence_type="local",
                                        style={"maxWidth": "120px"},
                                    ),
                                ],
                                width="auto",
                            ),
                            # Hydro Type
                            dbc.Col(
                                [
                                    _label("Hydro Type"),
                                    dbc.RadioItems(
                                        id="hydro-st-type",
                                        options=HYDRO_TYPE_OPTIONS,
                                        value=HYDRO_TYPE_RES,
                                        inline=True,
                                        persistence=True,
                                        persistence_type="local",
                                        className="mt-1",
                                    ),
                                ],
                                width="auto",
                            ),
                            # Y-axis toggle
                            dbc.Col(
                                [
                                    _label("Y-axis"),
                                    dbc.RadioItems(
                                        id="hydro-st-y-axis",
                                        options=[
                                            {"label": "Spot price", "value": "price"},
                                            {"label": "Heat rate", "value": "heat_rate"},
                                        ],
                                        value="heat_rate",
                                        inline=True,
                                        persistence=True,
                                        persistence_type="local",
                                        className="mt-1",
                                    ),
                                ],
                                width="auto",
                            ),
                            # Info badge
                            dbc.Col(
                                html.Span(
                                    "Last 10 weeks · 10 generation buckets",
                                    className="text-muted",
                                    style={"fontSize": "12px", "marginTop": "28px", "display": "block"},
                                ),
                                width="auto",
                            ),
                        ],
                        align="start",
                        className="g-3",
                    ),
                ],
            ),

            # ── Chart ────────────────────────────────────────────────────
            dcc.Loading(
                type="dot",
                color=COLORS["accent"],
                children=[
                    html.Div(
                        [
                            html.Div(
                                id="hydro-st-title",
                                style={
                                    "fontWeight": "600",
                                    "fontSize": "13px",
                                    "color": COLORS["text_primary"],
                                    "marginBottom": "4px",
                                },
                            ),
                            dcc.Graph(
                                id="hydro-st-chart",
                                config={"displayModeBar": "hover", "scrollZoom": True},
                                style={"height": "520px"},
                            ),
                        ],
                        style=_CHART_STYLE,
                    ),
                ],
            ),
        ],
    )


def build_layout() -> html.Div:
    return html.Div(
        style={"backgroundColor": COLORS["background"], "minHeight": "100vh"},
        children=[
            # ── Page header: breadcrumb + tab bar only ───────────────────
            html.Div(
                style={
                    "padding": "16px 22px 0 22px",
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "backgroundColor": COLORS["card_bg"],
                },
                children=[
                    # Breadcrumb
                    html.Div(
                        [
                            html.Span("Power", style={"color": "#888", "fontSize": "13px"}),
                            html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                            html.Span(
                                "Hydro",
                                style={"fontWeight": "600", "color": COLORS["text_primary"]},
                            ),
                        ],
                        style={"marginBottom": "12px"},
                    ),
                    # Sub-tabs flush at the bottom of the header card
                    dbc.Tabs(
                        id="hydro-tabs",
                        active_tab="hydro-tab-pricing",
                        children=[
                            dbc.Tab(
                                label="Reservoir Pricing",
                                tab_id="hydro-tab-pricing",
                                tab_style=_TAB_STYLE,
                                active_tab_style=_TAB_ACTIVE_STYLE,
                            ),
                            dbc.Tab(
                                label="Short-Term",
                                tab_id="hydro-tab-st",
                                tab_style=_TAB_STYLE,
                                active_tab_style=_TAB_ACTIVE_STYLE,
                            ),
                        ],
                        style={"borderBottom": "none"},
                        className="border-0",
                    ),
                ],
            ),

            # ── Tab content area ─────────────────────────────────────────
            html.Div(
                id="hydro-tab-content",
                style={"padding": "0 22px 22px 22px"},
                children=[_reservoir_pricing_tab()],  # rendered server-side on first load
            ),
        ],
    )
