"""
Hydro dashboard — Dash callbacks.

Registered via side-effect import in pages/hydro.py.
"""
from __future__ import annotations

import datetime as dt
import logging
from typing import Any

import numpy as np
import plotly.graph_objects as go
from dash import Input, Output, State, callback, html, no_update
from plotly.subplots import make_subplots

from core.hydro.data import filter_doy_window, load_hydro_data

logger = logging.getLogger(__name__)

# ── Colour palette for years (discrete, up to ~15 years) ──────────────────
_YEAR_COLOURS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd",
    "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf",
    "#aec7e8", "#ffbb78", "#98df8a", "#ff9896", "#c5b0d5",
]

_MONTH_ABBR = [
    "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]


def _doy_to_label(doy: int) -> str:
    """Convert a day-of-year integer to a readable month-day string (cross-platform)."""
    try:
        d = dt.date(2024, 1, 1) + dt.timedelta(days=doy - 1)  # 2024 is leap year
        return f"{d.strftime('%b')} {d.day}"
    except Exception:
        return f"Day {doy}"


def _empty_fig(message: str = "No data available") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper", yref="paper",
        x=0.5, y=0.5,
        showarrow=False,
        font={"size": 14, "color": "#888"},
    )
    fig.update_layout(
        paper_bgcolor="#fafafa",
        plot_bgcolor="#fafafa",
        margin={"t": 30, "b": 30, "l": 30, "r": 30},
    )
    return fig


def _apply_theme(fig: go.Figure) -> go.Figure:
    fig.update_layout(
        paper_bgcolor="#faf9f6",
        plot_bgcolor="#ffffff",
        font={"family": "Inter, Arial, sans-serif", "size": 11, "color": "#333"},
        legend={"bgcolor": "rgba(255,255,255,0.85)", "borderwidth": 0, "font": {"size": 10}},
        margin={"t": 40, "b": 50, "l": 60, "r": 20},
    )
    fig.update_xaxes(showgrid=True, gridcolor="#eee", gridwidth=1, zeroline=False)
    fig.update_yaxes(showgrid=True, gridcolor="#eee", gridwidth=1, zeroline=False)
    return fig


def _smooth_line(
    x: np.ndarray,
    y: np.ndarray,
    n_grid: int = 80,
    bandwidth_frac: float = 0.4,
) -> tuple[np.ndarray, np.ndarray]:
    """
    LOWESS smooth line via vectorised local linear regression with
    tricubic weights.

    For each of `n_grid` evenly-spaced evaluation points the weighted
    OLS problem  min Σ w_j (y_j − a − b·x_j)²  is solved analytically.
    Bandwidth = `bandwidth_frac` × x-range (fraction of data span within
    which neighbours contribute).  Points outside the bandwidth window
    receive zero weight (true tricubic / LOWESS kernel).

    Subsamples to 4,000 points when the dataset is larger so the
    (n_grid × n_subsample) weight matrix stays cheap to compute.
    Returns (x_eval, y_hat) with NaN rows omitted.
    """
    if len(x) < 20:
        return x, y

    if len(x) > 4000:
        rng = np.random.default_rng(0)
        idx = rng.choice(len(x), 4000, replace=False)
        xs, ys = x[idx], y[idx]
    else:
        xs, ys = x, y

    x_min, x_max = xs.min(), xs.max()
    if x_max <= x_min:
        return xs[:1], ys[:1]

    bw = (x_max - x_min) * bandwidth_frac
    grid = np.linspace(x_min, x_max, n_grid)

    # Tricubic LOWESS weights: w = (1 − |u|³)³  for |u| ≤ 1, else 0
    u = np.abs(grid[:, None] - xs[None, :]) / bw   # (n_grid, n_sub)
    u = np.clip(u, 0.0, 1.0)
    W = (1.0 - u ** 3) ** 3                         # (n_grid, n_sub)

    # Weighted normal equations (solved analytically for y = a + b·x):
    #   [sw   swx ] [a]   [swy ]
    #   [swx  swx2] [b] = [swxy]
    sw   = W.sum(axis=1)
    swx  = (W * xs).sum(axis=1)
    swx2 = (W * (xs ** 2)).sum(axis=1)
    swy  = (W * ys).sum(axis=1)
    swxy = (W * xs * ys).sum(axis=1)

    det = sw * swx2 - swx ** 2
    valid = (sw > 1e-10) & (np.abs(det) > 1e-20)

    safe_det = np.where(valid, det, 1.0)
    safe_sw  = np.where(valid & (sw > 0), sw, 1.0)

    b     = np.where(valid, (sw * swxy - swx * swy) / safe_det, 0.0)
    a     = np.where(valid, (swy - b * swx) / safe_sw, np.nan)
    y_hat = np.where(valid, a + b * grid, np.nan)

    mask = ~np.isnan(y_hat)
    return grid[mask], y_hat[mask]


# ── Callback: update DOY window display label ─────────────────────────────

@callback(
    Output("hydro-doy-display", "children"),
    Input("hydro-doy-range", "value"),
)
def _update_doy_display(doy_range: list[int]) -> str:
    if not doy_range or len(doy_range) != 2:
        return ""
    s, e = doy_range
    return f"{_doy_to_label(s)} → {_doy_to_label(e)}"


# ── Callback: balance filter button toggle label + style ─────────────────

@callback(
    Output("hydro-bal-active", "children"),
    Output("hydro-bal-active", "color"),
    Output("hydro-bal-active", "outline"),
    Input("hydro-bal-active", "n_clicks"),
)
def _update_bal_button(n_clicks: int):
    active = (n_clicks or 0) % 2 == 1
    if active:
        return "Balance Filter: ON", "primary", False
    return "Balance Filter: OFF", "secondary", True


# ── Callback: balance range display label ────────────────────────────────

@callback(
    Output("hydro-bal-display", "children"),
    Input("hydro-bal-range", "value"),
    Input("hydro-bal-active", "n_clicks"),
    Input("hydro-zone", "value"),
    Input("hydro-type", "value"),
    Input("hydro-doy-range", "value"),
    prevent_initial_call=False,
)
def _update_bal_display(bal_range, n_clicks, zone, hydro_type, doy_range):
    active = (n_clicks or 0) % 2 == 1
    if not active:
        return "drag slider then toggle ON to filter"
    if not bal_range or not zone or not doy_range:
        return ""
    try:
        df_all = load_hydro_data(zone, hydro_type=hydro_type)
        df = filter_doy_window(df_all, int(doy_range[0]), int(doy_range[1]))
        bal = df["hydro_bal_mwh"].dropna()
        if bal.empty:
            return ""
        lo = np.nanpercentile(bal, bal_range[0])
        hi = np.nanpercentile(bal, bal_range[1])
        return f"pct {bal_range[0]}–{bal_range[1]} · {lo:+,.0f} to {hi:+,.0f} MWh"
    except Exception:
        return ""


# ── Main callback: scatter + violin ──────────────────────────────────────

@callback(
    Output("hydro-scatter", "figure"),
    Output("hydro-violin", "figure"),
    Output("hydro-scatter-title", "children"),
    Output("hydro-status-bar", "children"),
    Input("hydro-zone", "value"),
    Input("hydro-type", "value"),
    Input("hydro-doy-range", "value"),
    Input("hydro-y-axis", "value"),
    Input("hydro-color-var", "value"),
    Input("hydro-bal-range", "value"),
    Input("hydro-bal-active", "n_clicks"),
    prevent_initial_call=False,
)
def _update_charts(
    zone: str,
    hydro_type: str,
    doy_range: list[int],
    y_axis: str,
    color_var: str,
    bal_range: list[int],
    bal_n_clicks: int,
) -> tuple[go.Figure, go.Figure, str, str]:
    bal_active = (bal_n_clicks or 0) % 2 == 1

    if not zone:
        empty = _empty_fig("Select a country")
        return empty, empty, "", ""

    if not doy_range or len(doy_range) != 2:
        empty = _empty_fig("Adjust the date-of-year slider")
        return empty, empty, "", ""

    start_doy, end_doy = int(doy_range[0]), int(doy_range[1])

    # ── Load data ────────────────────────────────────────────────────────
    try:
        df_all = load_hydro_data(zone, hydro_type=hydro_type)
    except Exception as exc:
        logger.exception("load_hydro_data failed for zone=%s hydro_type=%s", zone, hydro_type)
        err = _empty_fig(f"Data load error: {exc}")
        return err, err, "", str(exc)

    if df_all is None or df_all.empty:
        empty = _empty_fig(f"No data found for {zone} ({hydro_type})")
        return empty, empty, f"{zone} — no data", ""

    # ── Filter to DOY window ──────────────────────────────────────────────
    df = filter_doy_window(df_all, start_doy, end_doy)

    if df.empty:
        empty = _empty_fig("No data in selected window")
        return empty, empty, "", ""

    # ── Axis labels ──────────────────────────────────────────────────────
    y_col = "price" if y_axis == "price" else "heat_rate"
    y_label = "Spot Price (EUR/MWh)" if y_axis == "price" else "Heat Rate (MWh/MWh)"
    window_str = f"{_doy_to_label(start_doy)} → {_doy_to_label(end_doy)}"
    
    from core.hydro.constants import HYDRO_TYPE_RES
    type_label = "Reservoir" if hydro_type == HYDRO_TYPE_RES else "Run of River"
    title_str = f"{zone} — {y_label.split('(')[0].strip()} vs {type_label} Generation · {window_str}"

    # Drop rows where either axis is NaN
    plot_df = df.dropna(subset=["gen_mw", y_col])

    # ── Build scatter ─────────────────────────────────────────────────────
    scatter_fig = _build_scatter(
        plot_df, y_col, y_label, color_var, zone, hydro_type,
        bal_range=bal_range if bal_active else None,
    )

    # ── Build ridgeline ───────────────────────────────────────────────────
    violin_fig = _build_ridgeline(df, zone, hydro_type, window_str)

    # ── Status bar ────────────────────────────────────────────────────────
    n_years = df["year"].nunique()
    n_pts = len(plot_df)
    years_range = f"{df['year'].min()}–{df['year'].max()}" if n_years > 0 else "—"
    status = f"{n_pts:,} hourly data points · {n_years} years ({years_range}) · window: {window_str}"

    return scatter_fig, violin_fig, title_str, status


def _build_scatter(
    df: "Any",  # pd.DataFrame
    y_col: str,
    y_label: str,
    color_var: str,
    zone: str,
    hydro_type: str,
    bal_range: list[int] | None = None,
) -> go.Figure:
    """
    Build the scatter chart with gen_mw on X and price/heat_rate on Y.

    When ``bal_range`` is provided (a [lo_pct, hi_pct] list), points outside
    the hydro-balance percentile window are faded (opacity 0.08) and a smooth
    trend line (Gaussian kernel regression) is added over the in-range points.
    """
    import pandas as pd
    from core.hydro.constants import HYDRO_TYPE_RES

    fig = go.Figure()

    if df.empty:
        return _apply_theme(_empty_fig("No data after filtering"))
    
    type_label = "Reservoir" if hydro_type == HYDRO_TYPE_RES else "Run of River"

    # ── Compute balance filter mask ───────────────────────────────────────
    in_mask = None
    if bal_range is not None and "hydro_bal_mwh" in df.columns:
        bal = df["hydro_bal_mwh"].values.astype(float)
        lo = np.nanpercentile(bal, bal_range[0])
        hi = np.nanpercentile(bal, bal_range[1])
        in_mask = (df["hydro_bal_mwh"] >= lo) & (df["hydro_bal_mwh"] <= hi)

    def _opacity(base: float, in_range: bool | None) -> float:
        """Return full opacity for in-range points, very faded for out-of-range."""
        if in_range is None:
            return base        # no filter active
        return base if in_range else 0.08

    if color_var == "year":
        years = sorted(df["year"].unique())
        for i, yr in enumerate(years):
            sub = df[df["year"] == yr]
            colour = _YEAR_COLOURS[i % len(_YEAR_COLOURS)]
            ts = sub.index.strftime("%Y-%m-%d %H:%M") if hasattr(sub.index, "strftime") else None

            if in_mask is not None:
                # Split each year into in/out groups to allow different opacities
                for grp_mask, grp_opacity, show_legend in [
                    (in_mask[sub.index], 0.75, True),
                    (~in_mask[sub.index], 0.08, False),
                ]:
                    grp = sub[grp_mask]
                    if grp.empty:
                        continue
                    fig.add_trace(
                        go.Scattergl(
                            x=grp["gen_mw"],
                            y=grp[y_col],
                            mode="markers",
                            name=str(yr),
                            legendgroup=str(yr),
                            showlegend=show_legend,
                            marker={"color": colour, "size": 4, "opacity": grp_opacity},
                            text=ts[grp_mask] if ts is not None else None,
                            hovertemplate=(
                                f"<b>%{{text}}</b><br>Gen: %{{x:.0f}} MW<br>"
                                f"{y_label.split('(')[0]}: %{{y:.2f}}<extra>{yr}</extra>"
                            ),
                        )
                    )
            else:
                fig.add_trace(
                    go.Scattergl(
                        x=sub["gen_mw"],
                        y=sub[y_col],
                        mode="markers",
                        name=str(yr),
                        marker={"color": colour, "size": 4, "opacity": 0.65},
                        text=ts,
                        hovertemplate=(
                            f"<b>%{{text}}</b><br>Gen: %{{x:.0f}} MW<br>"
                            f"{y_label.split('(')[0]}: %{{y:.2f}}<extra>{yr}</extra>"
                        ),
                    )
                )

    else:
        # Continuous color by hydro_bal_mwh
        bal = df["hydro_bal_mwh"]
        bal_min, bal_max = bal.min(), bal.max()
        ts = df.index.strftime("%Y-%m-%d %H:%M") if hasattr(df.index, "strftime") else None

        if in_mask is not None:
            # Out-of-range: faded, no colorbar
            out_df = df[~in_mask]
            if not out_df.empty:
                fig.add_trace(
                    go.Scattergl(
                        x=out_df["gen_mw"],
                        y=out_df[y_col],
                        mode="markers",
                        showlegend=False,
                        marker={
                            "color": "#cccccc",
                            "size": 4,
                            "opacity": 0.12,
                        },
                        hoverinfo="skip",
                    )
                )
            # In-range: full colour + colorbar
            in_df = df[in_mask]
            if not in_df.empty:
                fig.add_trace(
                    go.Scattergl(
                        x=in_df["gen_mw"],
                        y=in_df[y_col],
                        mode="markers",
                        marker={
                            "color": in_df["hydro_bal_mwh"],
                            "colorscale": "RdYlGn",
                            "cmin": bal_min,
                            "cmax": bal_max,
                            "size": 4,
                            "opacity": 0.8,
                            "colorbar": {
                                "title": "Hydro Balance (MWh)",
                                "thickness": 12,
                                "len": 0.8,
                                "x": 1.02,
                            },
                            "showscale": True,
                        },
                        text=ts[in_mask] if ts is not None else None,
                        hovertemplate=(
                            "<b>%{text}</b><br>Gen: %{x:.0f} MW<br>"
                            f"{y_label.split('(')[0]}: %{{y:.2f}}<br>"
                            "Hydro Bal: %{marker.color:.0f} MWh<extra></extra>"
                        ),
                        name="",
                        showlegend=False,
                    )
                )
        else:
            fig.add_trace(
                go.Scattergl(
                    x=df["gen_mw"],
                    y=df[y_col],
                    mode="markers",
                    marker={
                        "color": bal,
                        "colorscale": "RdYlGn",
                        "cmin": bal_min,
                        "cmax": bal_max,
                        "size": 4,
                        "opacity": 0.7,
                        "colorbar": {
                            "title": "Hydro Balance (MWh)",
                            "thickness": 12,
                            "len": 0.8,
                            "x": 1.02,
                        },
                        "showscale": True,
                    },
                    text=ts,
                    hovertemplate=(
                        "<b>%{text}</b><br>Gen: %{x:.0f} MW<br>"
                        f"{y_label.split('(')[0]}: %{{y:.2f}}<br>"
                        "Hydro Bal: %{marker.color:.0f} MWh<extra></extra>"
                    ),
                    name="",
                    showlegend=False,
                )
            )

    # ── LOWESS smooth line over in-range points ───────────────────────────
    if in_mask is not None:
        fit_df = df[in_mask].dropna(subset=["gen_mw", y_col])
        if len(fit_df) >= 20:
            x_arr = fit_df["gen_mw"].values.astype(float)
            y_arr = fit_df[y_col].values.astype(float)
            x_s, y_s = _smooth_line(x_arr, y_arr)
            if len(x_s) >= 2:
                fig.add_trace(
                    go.Scatter(
                        x=x_s,
                        y=y_s,
                        mode="lines",
                        name="Smooth trend",
                        line={"color": "#e55", "width": 2.5, "dash": "solid"},
                        hovertemplate=(
                            "Smooth (balance filter)<br>"
                            "Gen: %{x:.0f} MW<br>"
                            f"{y_label.split('(')[0]}: %{{y:.2f}}<extra></extra>"
                        ),
                        showlegend=True,
                    )
                )

    fig.update_layout(
        xaxis_title=f"{type_label} Hydro Generation (MW)",
        yaxis_title=y_label,
        legend={"title": "Year", "itemsizing": "constant"},
        hovermode="closest",
    )
    return _apply_theme(fig)


def _hex_to_rgba(hex_colour: str, alpha: float) -> str:
    """Convert a 6-digit hex colour string to an rgba() string Plotly accepts."""
    h = hex_colour.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha:.2f})"


def _kde(data: np.ndarray, n_points: int = 150) -> tuple[np.ndarray, np.ndarray]:
    """
    Compute a smooth KDE over the middle 98 % of *data*.

    Uses scipy.stats.gaussian_kde when available, falls back to a
    normalised numpy histogram so the function works without scipy.
    """
    d = data[~np.isnan(data)]
    if len(d) < 5:
        return np.array([]), np.array([])
    lo, hi = np.nanpercentile(d, 1.0), np.nanpercentile(d, 99.0)
    if lo >= hi:
        return np.array([lo, hi]), np.array([0.5, 0.5])
    x = np.linspace(lo, hi, n_points)
    try:
        from scipy.stats import gaussian_kde  # noqa: PLC0415
        y = gaussian_kde(d, bw_method="scott")(x)
    except Exception:
        counts, edges = np.histogram(d, bins=min(60, max(10, len(d) // 10)), density=True, range=(lo, hi))
        x = (edges[:-1] + edges[1:]) / 2.0
        y = counts.astype(float)
    # Normalise to 0..1 so ridge heights are comparable across years
    peak = y.max()
    if peak > 0:
        y = y / peak
    return x, y


def _build_ridgeline(df: "Any", zone: str, hydro_type: str, window_str: str) -> go.Figure:
    """
    Two-subplot ridgeline (joy-division) chart:
      Row 1 — Hydro Balance (MWh) distribution by year
      Row 2 — Hydro Generation (MW) distribution by year

    Each year's KDE is drawn as a filled area offset vertically, so years
    "stack" like mountain ridges.  The most-recent year sits at the top.
    X-axis = the measured value; Y-axis = years (implicit in offset).
    """
    if df.empty:
        return _apply_theme(_empty_fig("No data"))

    from core.hydro.constants import HYDRO_TYPE_RES
    type_label = "Reservoir" if hydro_type == HYDRO_TYPE_RES else "Run of River"

    years = sorted(df["year"].unique())          # oldest first → lowest ridge
    n_years = len(years)
    RIDGE_SCALE = 0.75   # max ridge height as a fraction of the inter-year gap
    FILL_OPACITY = 0.55  # fill transparency for ridgeline polygons

    panels = [
        ("hydro_bal_mwh", "Hydro Balance (MWh)", True),   # deduplicate to daily
        ("gen_mw",        f"{type_label} Generation (MW)", False),
    ]

    subplot_titles = [p[1] for p in panels]
    fig = make_subplots(
        rows=2,
        cols=1,
        subplot_titles=subplot_titles,
        shared_xaxes=False,
        vertical_spacing=0.18,
    )

    for row, (col, label, dedupe_daily) in enumerate(panels, start=1):
        if not df[col].notna().any():
            fig.add_annotation(
                text=f"No {label} data",
                xref=f"x{row}", yref=f"y{row}",
                x=0.5, y=0.5, showarrow=False, font={"color": "#888"},
                row=row, col=1,
            )
            continue

        ytick_vals, ytick_text = [], []

        for i, yr in enumerate(years):
            sub = df[df["year"] == yr]

            if dedupe_daily:
                # Hydro balance is daily data broadcast to hourly — deduplicate
                if hasattr(sub.index, "normalize"):
                    vals = sub.groupby(sub.index.normalize())[col].first()
                else:
                    vals = sub[col].drop_duplicates()
            else:
                vals = sub[col]

            arr = np.asarray(vals.dropna(), dtype=float)
            x_kde, y_kde = _kde(arr)
            if len(x_kde) == 0:
                continue

            colour = _YEAR_COLOURS[i % len(_YEAR_COLOURS)]
            y_offset = float(i)
            ytick_vals.append(y_offset)
            ytick_text.append(str(yr))

            # Build closed polygon: baseline → KDE → baseline
            x_poly = np.concatenate([[x_kde[0]], x_kde, [x_kde[-1]]])
            y_poly = np.concatenate(
                [[y_offset], y_kde * RIDGE_SCALE + y_offset, [y_offset]]
            )

            fig.add_trace(
                go.Scatter(
                    x=x_poly,
                    y=y_poly,
                    mode="lines",
                    fill="toself",
                    fillcolor=_hex_to_rgba(colour, FILL_OPACITY),
                    line={"color": colour, "width": 1.2},
                    name=str(yr),
                    legendgroup=str(yr),
                    showlegend=(row == 1),
                    hovertemplate=(
                        f"<b>{yr}</b><br>{label}: %{{x:.1f}}<extra></extra>"
                    ),
                ),
                row=row,
                col=1,
            )

        # Y-axis: show year labels at each ridge baseline
        fig.update_yaxes(
            tickvals=ytick_vals,
            ticktext=ytick_text,
            showgrid=False,
            zeroline=False,
            row=row,
            col=1,
        )
        fig.update_xaxes(
            title_text=label,
            showgrid=True,
            gridcolor="#eee",
            row=row,
            col=1,
        )

    fig.update_layout(
        legend={
            "title": {"text": "Year", "side": "left"},
            "orientation": "h",
            "x": 0,
            "y": 1.04,
            "xanchor": "left",
            "yanchor": "bottom",
            "itemsizing": "constant",
            "bgcolor": "rgba(255,255,255,0.85)",
        },
        hovermode="x unified",
        margin={"t": 80, "b": 40, "l": 60, "r": 20},
    )
    return _apply_theme(fig)


# ── Short-Term: bucketed generation vs price/heat-rate ───────────────────

# Colour ramp for 10 weeks (blue → red gradient, oldest to most recent)
_WEEK_COLOURS = [
    "#1a78c2", "#2e8bc0", "#3d9fc0", "#4db3be", "#5ec4b8",
    "#7ccca4", "#9ed48e", "#c2d97a", "#e3d86b", "#f4a04a",
]


@callback(
    Output("hydro-st-chart", "figure"),
    Output("hydro-st-title", "children"),
    Input("hydro-st-zone", "value"),
    Input("hydro-st-type", "value"),
    Input("hydro-st-y-axis", "value"),
    prevent_initial_call=False,
)
def _update_st_chart(zone: str, hydro_type: str, y_axis: str) -> tuple[go.Figure, str]:
    from core.hydro.data import compute_st_bucket_series

    if not zone:
        return _empty_fig("Select a country"), ""

    try:
        df = compute_st_bucket_series(zone, hydro_type=hydro_type, n_weeks=10, n_buckets=10)
    except Exception as exc:
        logger.exception("compute_st_bucket_series failed for zone=%s hydro_type=%s", zone, hydro_type)
        return _empty_fig(f"Data error: {exc}"), ""

    if df is None or df.empty:
        return _empty_fig(f"No short-term data for {zone} ({hydro_type})"), ""

    y_col = "mean_price" if y_axis == "price" else "mean_hr"
    y_label = "Mean Spot Price (EUR/MWh)" if y_axis == "price" else "Mean Heat Rate"

    fig = go.Figure()
    weeks = sorted(df["week_start"].unique())  # oldest first

    for i, ws in enumerate(weeks):
        wdf = df[df["week_start"] == ws].sort_values("bucket_mid")
        lbl = wdf["week_label"].iloc[0]
        colour = _WEEK_COLOURS[i % len(_WEEK_COLOURS)]
        valid = wdf.dropna(subset=[y_col])
        if valid.empty:
            continue

        # Boldest line for most-recent week
        line_width = 1.5 + (i / max(len(weeks) - 1, 1)) * 1.5  # 1.5 → 3.0
        opacity = 0.55 + (i / max(len(weeks) - 1, 1)) * 0.45   # 0.55 → 1.0

        fig.add_trace(
            go.Scatter(
                x=valid["bucket_mid"],
                y=valid[y_col],
                mode="lines+markers",
                name=lbl,
                line={"color": colour, "width": line_width},
                marker={"color": colour, "size": 6, "opacity": opacity},
                opacity=opacity,
                customdata=valid[["bucket_label", "count"]],
                hovertemplate=(
                    f"<b>{lbl}</b><br>"
                    "Bucket: %{customdata[0]}<br>"
                    f"{y_label.split('(')[0].strip()}: %{{y:.2f}}<br>"
                    "Hours: %{customdata[1]}<extra></extra>"
                ),
            )
        )

    from core.hydro.constants import HYDRO_TYPE_RES
    type_label = "Reservoir" if hydro_type == HYDRO_TYPE_RES else "Run of River"

    fig.update_layout(
        xaxis_title=f"{type_label} Hydro Generation (MW) — bucket midpoint",
        yaxis_title=y_label,
        legend={"title": "Week (Mon)", "traceorder": "normal"},
        hovermode="x unified",
    )
    title = (
        f"{zone} — {y_label.split('(')[0].strip()} by {type_label} Generation Bucket"
        " · Last 10 Weeks"
    )
    return _apply_theme(fig), title


# ── Tab-switching callback ────────────────────────────────────────────────

@callback(
    Output("hydro-tab-content", "children"),
    Input("hydro-tabs", "active_tab"),
    prevent_initial_call=True,
)
def _switch_tab(active_tab: str) -> html.Div:
    """Swap the main content area when the user changes sub-tab."""
    from core.hydro.layout import _reservoir_pricing_tab, _short_term_tab

    if active_tab == "hydro-tab-pricing":
        return _reservoir_pricing_tab()
    if active_tab == "hydro-tab-st":
        return _short_term_tab()
    return no_update
