"""Static configuration for the Hydro dashboard."""
from __future__ import annotations

import datetime as dt

PAGE_PATH = "/power/hydro"
PAGE_NAME = "Hydro Pricing"
PAGE_TITLE = "Hydro Pricing | JG Power Dashboard"
PAGE_ORDER = 19

# ── Zone options (hydro-relevant countries first) ────────────────────────
ZONE_OPTIONS = [
    {"label": "NO1", "value": "NO1"},
    {"label": "NO2", "value": "NO2"},
    {"label": "NO3", "value": "NO3"},
    {"label": "NO4", "value": "NO4"},
    {"label": "NO5", "value": "NO5"},
    {"label": "SE1", "value": "SE1"},
    {"label": "SE2", "value": "SE2"},
    {"label": "SE3", "value": "SE3"},
    {"label": "SE4", "value": "SE4"},
    {"label": "FI", "value": "FI"},
    {"label": "ES", "value": "ES"},
    {"label": "FR", "value": "FR"},
    {"label": "IT", "value": "IT"},
    {"label": "AT", "value": "AT"},
    {"label": "CH", "value": "CH"},
    {"label": "PT", "value": "PT"},
    {"label": "DE", "value": "DE"},
    {"label": "NL", "value": "NL"},
    {"label": "BE", "value": "BE"},
    {"label": "UK", "value": "UK"},
]

DEFAULT_ZONE = "ES"

# ── Hydro types ──────────────────────────────────────────────────────────
HYDRO_TYPE_RES = "reservoir"
HYDRO_TYPE_ROR = "run_of_river"

HYDRO_TYPE_OPTIONS = [
    {"label": "Reservoir", "value": HYDRO_TYPE_RES},
    {"label": "Run of River", "value": HYDRO_TYPE_ROR},
]

# ── Heat rate constants (same as heatmap_balance_data.py) ─────────────────
GAS_EFF = 0.5
GAS_EMISSIONS = 0.1821
UK_CARBON_TAX = 18.0  # GBP/t adder for UK carbon cost

# ── Day-of-year slider defaults (15 days either side of today) ─────────────
_TODAY_DOY = dt.date.today().timetuple().tm_yday
DOY_SLIDER_MIN = 1
DOY_SLIDER_MAX = 365
DOY_DEFAULT_START = max(DOY_SLIDER_MIN, _TODAY_DOY - 15)
DOY_DEFAULT_END = min(DOY_SLIDER_MAX, _TODAY_DOY + 15)

# ── Month boundary marks for the RangeSlider ─────────────────────────────
_MONTH_LABELS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]
_MONTH_STARTS = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
DOY_MARKS = {d: lbl for d, lbl in zip(_MONTH_STARTS, _MONTH_LABELS)}

# ── LRU cache limits ─────────────────────────────────────────────────────
MAX_HYDRO_CACHE_ENTRIES = 12

# ── Data load window — always fetch all available years ──────────────────
HISTORY_START_YEAR = 2015
