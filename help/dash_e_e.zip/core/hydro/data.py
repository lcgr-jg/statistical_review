"""
Hydro page — data loading and preparation.

Loads five series for a given zone and date range:
  - GenHydroResActual  (hourly MW  — reservoir hydro generation)
  - PricePowerSpot     (hourly EUR/MWh — spot power price)
  - PriceGasSpot       (daily  EUR/MWh — TTF gas price)
  - PriceCO2Spot       (daily  EUR/t   — EUA carbon price)
  - HydroBalActual     (daily  MWh     — hydrological balance)

Returns a single hourly DataFrame with columns:
  gen_mw, price, heat_rate, hydro_bal_mwh, year, doy

Daily gas/carbon are broadcast to hourly via ffill.
Daily hydro balance is broadcast to hourly via ffill.
"""
from __future__ import annotations

import datetime as dt
import logging
from collections import OrderedDict
from typing import Optional

import numpy as np
import pandas as pd

from core.hydro.constants import (
    GAS_EMISSIONS,
    HISTORY_START_YEAR,
    MAX_HYDRO_CACHE_ENTRIES,
    UK_CARBON_TAX,
)

logger = logging.getLogger(__name__)

# ── jain_commods import guard ────────────────────────────────────────────
try:
    from jain_commods.core.cache.data.fundamentals import (  # type: ignore
        GenHydroResActual,
        GenHydroRoRActual,
        HydroBalActual,
    )
    from jain_commods.core.cache.data.market import (  # type: ignore
        PriceCO2Spot,
        PriceGasSpot,
        PricePowerSpot,
    )
    _COMMODS = True
except ImportError as exc:
    logger.warning("jain_commods not available: %s", exc)
    _COMMODS = False

# ── In-memory LRU cache (tier 1 — fastest, in-process) ───────────────────
_HYDRO_CACHE: OrderedDict[str, pd.DataFrame] = OrderedDict()

# ── dashboard_cache integration (tier 2 — disk-backed, survives restarts) ─
# Lazy import so we don't create a circular dependency at module load time.
_DC_PREFIX = "hydro_data_v2:"   # keys: "hydro_data_v2:ES:reservoir", …
_DC_TTL = 14_400             # 4 hours, matches the scheduled refresh interval


def _get_dc():
    """Return the shared dashboard_cache singleton (lazy import)."""
    try:
        from core.cache import dashboard_cache  # noqa: PLC0415
        return dashboard_cache
    except Exception:
        return None


def _dc_key(zone: str, hydro_type: str) -> str:
    return f"{_DC_PREFIX}{zone.upper()}:{hydro_type}"


def _cache_key(zone: str, hydro_type: str, start: dt.date, end: dt.date) -> str:
    return f"{zone.upper()}|{hydro_type}|{start.isoformat()}|{end.isoformat()}"


def _cache_put(key: str, df: pd.DataFrame) -> None:
    _HYDRO_CACHE[key] = df
    _HYDRO_CACHE.move_to_end(key)
    while len(_HYDRO_CACHE) > MAX_HYDRO_CACHE_ENTRIES:
        _HYDRO_CACHE.popitem(last=False)


def clear_hydro_cache() -> None:
    """Clear both the in-memory LRU and the disk-backed dashboard_cache tier."""
    _HYDRO_CACHE.clear()
    dc = _get_dc()
    if dc is not None:
        try:
            dc.clear(prefix=_DC_PREFIX)
            logger.info("Hydro disk cache cleared (prefix=%s)", _DC_PREFIX)
        except Exception as exc:
            logger.warning("Failed to clear hydro disk cache: %s", exc)


# ── Low-level helpers ─────────────────────────────────────────────────────

def _pick_zone_col(df: pd.DataFrame, zone_lc: str) -> pd.Series:
    """Extract a single-zone series from a wide (possibly MultiIndex-column) DataFrame."""
    if df is None or df.empty:
        return pd.Series(dtype=float)
    aliases = {zone_lc}
    if zone_lc in ("gb", "uk"):
        aliases = {"gb", "uk"}
    if isinstance(df.columns, pd.MultiIndex):
        for level_i in range(df.columns.nlevels):
            zlev = df.columns.get_level_values(level_i).astype(str).str.lower()
            for want in aliases:
                mask = zlev == want
                if mask.any():
                    sub = df.loc[:, mask]
                    return sub.iloc[:, 0] if sub.shape[1] == 1 else sub.mean(axis=1)
    else:
        zlev = df.columns.astype(str).str.lower()
        for want in aliases:
            mask = zlev == want
            if mask.any():
                sub = df.loc[:, mask]
                return sub.iloc[:, 0] if sub.shape[1] == 1 else sub.mean(axis=1)
    # Fallback: first numeric column
    num = df.select_dtypes(include=[np.number])
    if not num.empty:
        return num.iloc[:, 0]
    return pd.Series(dtype=float)


def _col_prefer_name(df: pd.DataFrame, *names: str) -> Optional[pd.Series]:
    """
    Pick a column by name match; ALWAYS returns a Series (never a sub-DataFrame).

    For MultiIndex-column DataFrames (e.g. PriceGasSpot.data has levels
    hub/currency/energy_unit/unit), ``df["TTF"]`` returns a sub-DataFrame, not a
    Series. We avoid that by iterating over full column tuples so we always use a
    tuple key → guaranteed Series.
    """
    if df is None or df.empty:
        return None
    if isinstance(df.columns, pd.MultiIndex):
        # Iterate full tuple keys so df[tuple] always returns a Series
        for n in names:
            nu = n.upper()
            for c in df.columns:
                if nu in [str(x).upper() for x in c]:
                    return df[c]
    else:
        for n in names:
            if n in df.columns:
                return df[n]
        for n in names:
            nu = n.upper()
            for c in df.columns:
                if nu in str(c).upper():
                    return df[c]
    return None


def _normalize_index_utc_naive(s: pd.Series) -> pd.Series:
    """Convert any tz-aware index to UTC-naive."""
    ix = pd.to_datetime(s.index)
    if ix.tz is not None:
        ix = ix.tz_convert("UTC").tz_localize(None)
    s = s.copy()
    s.index = ix
    return s


def _normalize_index_date(s: pd.Series) -> pd.Series:
    """Collapse any hourly/tz index to midnight-normalised date keys."""
    ix = pd.to_datetime(s.index)
    if ix.tz is not None:
        ix = ix.tz_convert("UTC").tz_localize(None)
    s = s.copy()
    s.index = ix.normalize()
    return s.groupby(level=0).mean()


def _broadcast_daily_to_hourly(daily: "pd.Series | pd.DataFrame", hourly_index: pd.DatetimeIndex) -> pd.Series:
    """
    For each hour in hourly_index assign the value from the matching calendar day.
    Uses a date-keyed daily series, left-merges on date, then ffill/bfill.
    """
    if daily is None or (hasattr(daily, "empty") and daily.empty):
        return pd.Series(np.nan, index=hourly_index)
    # Collapse to a scalar-per-row Series if a DataFrame slipped through
    if isinstance(daily, pd.DataFrame):
        daily = daily.mean(axis=1)
    daily_norm = _normalize_index_date(daily)
    # Build a mapping from date -> value
    daily_norm.index = pd.to_datetime(daily_norm.index)
    date_vals = daily_norm.groupby(daily_norm.index.normalize()).mean()
    hourly_dates = hourly_index.normalize()
    mapped = date_vals.reindex(hourly_dates.unique()).reindex(hourly_dates)
    mapped.index = hourly_index
    return mapped.ffill(limit=48).bfill(limit=48)


# ── Data loaders ──────────────────────────────────────────────────────────

def _load_hydro_gen(zone: str, hydro_type: str, start: dt.date, end: dt.date) -> pd.Series:
    """Hydro generation for a single zone — returns hourly MW series (UTC-naive index)."""
    if not _COMMODS:
        return pd.Series(dtype=float, name="gen_mw")
    
    from core.hydro.constants import HYDRO_TYPE_RES
    
    zone_lc = zone.lower() if zone.upper() != "UK" else "gb"
    try:
        if hydro_type == HYDRO_TYPE_RES:
            obj = GenHydroResActual()
        else:
            obj = GenHydroRoRActual()
            
        obj.load(
            from_s3=True,
            show_metadata=False,
            zones=[zone_lc],
            start_date=start,
            end_date=end,
        )
    except Exception as exc:
        logger.warning("Hydro generation load failed for %s (%s): %s", zone, hydro_type, exc)
        return pd.Series(dtype=float, name="gen_mw")
    df = getattr(obj, "data", None)
    if df is None or df.empty:
        return pd.Series(dtype=float, name="gen_mw")
    s = _pick_zone_col(df, zone_lc)
    s = _normalize_index_utc_naive(s)
    s.name = "gen_mw"
    return s


def _load_hydro_bal(zone: str, start: dt.date, end: dt.date) -> pd.Series:
    """HydroBalActual for a single zone — returns daily MWh series (date-normalised)."""
    if not _COMMODS:
        return pd.Series(dtype=float, name="hydro_bal_mwh")
    zone_lc = zone.lower() if zone.upper() != "UK" else "gb"
    try:
        obj = HydroBalActual()
        obj.load(
            from_s3=True,
            show_metadata=False,
            zones=[zone_lc],
            start_date=start,
            end_date=end,
        )
    except Exception as exc:
        logger.warning("HydroBalActual load failed for %s: %s", zone, exc)
        return pd.Series(dtype=float, name="hydro_bal_mwh")
    df = getattr(obj, "data", None)
    if df is None or df.empty:
        return pd.Series(dtype=float, name="hydro_bal_mwh")
    s = _pick_zone_col(df, zone_lc)
    s = _normalize_index_date(s)
    s.name = "hydro_bal_mwh"
    return s


def _load_market_bundle(start: dt.date, end: dt.date) -> dict:
    """Load power spot, gas spot, and CO2 spot in one pass."""
    bundle = {"pwr": None, "gas": None, "co2": None}
    if not _COMMODS:
        return bundle
    try:
        pwr = PricePowerSpot(freq="h")
        pwr.load(from_s3=True, show_metadata=False, start_date=start, end_date=end)
        bundle["pwr"] = getattr(pwr, "data", None)
    except Exception as exc:
        logger.warning("PricePowerSpot load failed: %s", exc)
    try:
        gas = PriceGasSpot()
        gas.load(from_s3=True, show_metadata=False, start_date=start, end_date=end)
        bundle["gas"] = getattr(gas, "data", None)
    except Exception as exc:
        logger.warning("PriceGasSpot load failed: %s", exc)
    try:
        co2 = PriceCO2Spot()
        co2.load(from_s3=True, show_metadata=False, start_date=start, end_date=end)
        bundle["co2"] = getattr(co2, "data", None)
    except Exception as exc:
        logger.warning("PriceCO2Spot load failed: %s", exc)
    return bundle


# ── Public API ────────────────────────────────────────────────────────────

def load_hydro_data(zone: str, hydro_type: str = "reservoir") -> pd.DataFrame:
    """
    Load and merge all hydro + price series for ``zone`` across all available years.

    Returns a UTC-naive hourly DataFrame with columns:
      gen_mw         — hydro generation (MW)
      price          — spot power price (EUR/MWh)
      heat_rate      — Power / (Gas + GAS_EMISSIONS * Carbon_Total)
      hydro_bal_mwh  — daily hydrological balance (MWh), broadcast to hourly
      year           — calendar year of the timestamp
      doy            — day-of-year of the timestamp
    """
    start = dt.date(HISTORY_START_YEAR, 1, 1)
    end = dt.date.today() + dt.timedelta(days=1)

    key = _cache_key(zone, hydro_type, start, end)

    # ── Tier 1: in-memory LRU ─────────────────────────────────────────────
    if key in _HYDRO_CACHE:
        _HYDRO_CACHE.move_to_end(key)
        logger.debug("Hydro cache HIT (memory) zone=%s hydro_type=%s", zone, hydro_type)
        return _HYDRO_CACHE[key]

    # ── Tier 2: disk-backed dashboard_cache ──────────────────────────────
    dc = _get_dc()
    if dc is not None:
        try:
            cached = dc.get(_dc_key(zone, hydro_type), ttl=_DC_TTL)
            if cached is not None:
                logger.info("Hydro cache HIT (disk) zone=%s hydro_type=%s", zone, hydro_type)
                _cache_put(key, cached)   # promote to in-memory
                return cached
        except Exception as exc:
            logger.debug("Hydro disk cache get failed: %s", exc)

    is_uk = zone.upper() in ("UK", "GB")
    zone_lc = "gb" if is_uk else zone.lower()

    logger.info("Hydro cache MISS — loading from S3  zone=%s hydro_type=%s (%s – %s)", zone, hydro_type, start, end)

    # ── Load raw series ───────────────────────────────────────────────────
    gen_s = _load_hydro_gen(zone, hydro_type, start, end)
    bal_d = _load_hydro_bal(zone, start, end)
    mkt = _load_market_bundle(start, end)

    pwr_df = mkt.get("pwr")
    gas_df = mkt.get("gas")
    co2_df = mkt.get("co2")

    # ── Extract zone series from market dataframes ────────────────────────
    pwr_s: pd.Series = (
        _pick_zone_col(pwr_df, zone_lc)
        if pwr_df is not None and not pwr_df.empty
        else pd.Series(dtype=float)
    )
    if not pwr_s.empty:
        pwr_s = _normalize_index_utc_naive(pwr_s)

    gas_raw: Optional[pd.Series] = _col_prefer_name(gas_df, "TTF")
    if gas_raw is None and gas_df is not None and not gas_df.empty:
        gas_raw = gas_df.iloc[:, 0]

    co2_raw: Optional[pd.Series] = _col_prefer_name(co2_df, "EUA")
    if co2_raw is None and co2_df is not None and not co2_df.empty:
        co2_raw = co2_df.iloc[:, 0]

    # ── Build hourly index from generation series (primary) ───────────────
    if not gen_s.empty:
        hourly_idx = pd.DatetimeIndex(sorted(gen_s.index.union(pwr_s.index if not pwr_s.empty else gen_s.index)))
    elif not pwr_s.empty:
        hourly_idx = pd.DatetimeIndex(sorted(pwr_s.index))
    else:
        logger.warning("No hourly data available for zone=%s", zone)
        return pd.DataFrame()

    # Restrict to valid hourly grid
    hourly_idx = pd.date_range(
        start=hourly_idx.min().normalize(),
        end=hourly_idx.max().normalize() + pd.Timedelta(hours=23),
        freq="h",
    )

    # ── Assemble base DataFrame ───────────────────────────────────────────
    out = pd.DataFrame(index=hourly_idx)
    out["gen_mw"] = gen_s.reindex(hourly_idx)
    out["price"] = pwr_s.reindex(hourly_idx)

    # ── Broadcast daily gas/carbon to hourly ──────────────────────────────
    gas_h = _broadcast_daily_to_hourly(gas_raw, hourly_idx) if gas_raw is not None else pd.Series(np.nan, index=hourly_idx)
    co2_h = _broadcast_daily_to_hourly(co2_raw, hourly_idx) if co2_raw is not None else pd.Series(np.nan, index=hourly_idx)

    # Use numpy arrays for the heat-rate arithmetic to avoid any index-alignment
    # errors that arise when Series carry different index names or MultiIndex types.
    gas_arr = np.asarray(gas_h, dtype=float)
    co2_arr = np.asarray(co2_h, dtype=float)
    carbon_arr = co2_arr + (UK_CARBON_TAX if is_uk else 0.0)
    denom_arr = gas_arr + GAS_EMISSIONS * carbon_arr
    denom_arr = np.where(denom_arr == 0, np.nan, denom_arr)
    price_arr = np.asarray(out["price"], dtype=float)
    out["heat_rate"] = price_arr / denom_arr

    # ── Broadcast daily hydro balance to hourly ───────────────────────────
    out["hydro_bal_mwh"] = _broadcast_daily_to_hourly(bal_d, hourly_idx)

    # ── Metadata columns ─────────────────────────────────────────────────
    out["year"] = out.index.year
    out["doy"] = out.index.dayofyear

    # ── Drop rows with no generation AND no price (completely empty hours) ─
    out = out.dropna(subset=["gen_mw", "price"], how="all")

    logger.info(
        "Hydro data ready for zone=%s: %d hourly rows, %d years",
        zone,
        len(out),
        out["year"].nunique() if not out.empty else 0,
    )

    # ── Store in both cache tiers ─────────────────────────────────────────
    _cache_put(key, out)
    if dc is not None and not out.empty:
        try:
            dc.set(_dc_key(zone, hydro_type), out, ttl=_DC_TTL)
            logger.debug("Hydro data written to disk cache  zone=%s hydro_type=%s  ttl=%ds", zone, hydro_type, _DC_TTL)
        except Exception as exc:
            logger.warning("Hydro disk cache set failed for zone=%s: %s", zone, exc)

    return out


def compute_st_bucket_series(
    zone: str,
    hydro_type: str = "reservoir",
    n_weeks: int = 10,
    n_buckets: int = 10,
) -> pd.DataFrame:
    """
    Short-Term analysis: mean price / heat-rate per generation bucket per week.

    Algorithm
    ---------
    1. Load all cached hourly data for *zone*.
    2. Slice the last *n_weeks* ISO weeks (Mon–Sun).
    3. Divide the generation range into *n_buckets* equally-spaced bins,
       defined once over the full window so the X-axis is consistent.
    4. For each (week, bucket) compute the mean price and mean heat-rate
       over all hours in that bucket during that week.

    Returns a DataFrame with columns:
        week_label   — human-readable week label, e.g. "Apr 14"
        week_start   — pd.Timestamp (Monday of that ISO week)
        bucket_idx   — 0-based bucket index
        bucket_mid   — midpoint of the generation bin (MW)
        bucket_label — e.g. "0–500 MW"
        mean_price   — mean spot price (EUR/MWh) for that cell
        mean_hr      — mean heat rate (MWh/MWh) for that cell
        count        — number of hourly observations in the cell
    """
    df_all = load_hydro_data(zone, hydro_type=hydro_type)
    if df_all is None or df_all.empty:
        return pd.DataFrame()

    # ── Filter to last n_weeks ────────────────────────────────────────────
    end_dt = df_all.index.max()
    start_dt = end_dt - pd.Timedelta(weeks=n_weeks)
    df = df_all.loc[df_all.index >= start_dt].dropna(subset=["gen_mw"]).copy()
    if df.empty:
        return pd.DataFrame()

    # ── Assign ISO week start (Monday) ───────────────────────────────────
    df["week_start"] = (
        df.index - pd.to_timedelta(df.index.dayofweek, unit="D")
    ).normalize()

    # Keep only the most recent n_weeks ISO weeks
    all_weeks = sorted(df["week_start"].unique())
    keep_weeks = all_weeks[-n_weeks:]
    df = df[df["week_start"].isin(keep_weeks)]
    if df.empty:
        return pd.DataFrame()

    # ── Build generation buckets across the entire window ────────────────
    gen_min = df["gen_mw"].min()
    gen_max = df["gen_mw"].max()
    if gen_min >= gen_max:
        return pd.DataFrame()

    edges = np.linspace(gen_min, gen_max, n_buckets + 1)
    mids = (edges[:-1] + edges[1:]) / 2.0
    bucket_labels = [
        f"{int(edges[i]):,}–{int(edges[i + 1]):,} MW" for i in range(n_buckets)
    ]

    df["bucket_idx"] = pd.cut(
        df["gen_mw"], bins=edges, labels=False, include_lowest=True
    ).astype("Int64")

    # ── Week labels (cross-platform date formatting) ──────────────────────
    week_label_map = {
        ws: f"{pd.Timestamp(ws).strftime('%b')} {pd.Timestamp(ws).day}"
        for ws in keep_weeks
    }
    df["week_label"] = df["week_start"].map(week_label_map)

    # ── Aggregate per (week, bucket) ─────────────────────────────────────
    rows = []
    for ws in keep_weeks:
        wdf = df[df["week_start"] == ws]
        lbl = week_label_map[ws]
        for b_idx in range(n_buckets):
            bdf = wdf[wdf["bucket_idx"] == b_idx]
            if bdf.empty:
                continue
            rows.append({
                "week_label": lbl,
                "week_start": ws,
                "bucket_idx": b_idx,
                "bucket_mid": float(mids[b_idx]),
                "bucket_label": bucket_labels[b_idx],
                "mean_price": float(bdf["price"].mean()) if bdf["price"].notna().any() else np.nan,
                "mean_hr": float(bdf["heat_rate"].mean()) if bdf["heat_rate"].notna().any() else np.nan,
                "count": len(bdf),
            })

    return pd.DataFrame(rows) if rows else pd.DataFrame()


def filter_doy_window(df: pd.DataFrame, start_doy: int, end_doy: int) -> pd.DataFrame:
    """
    Filter ``df`` to rows whose day-of-year falls in [start_doy, end_doy].

    Handles year-wrap: if start_doy > end_doy the window crosses 1 Jan
    (e.g. Dec 15 – Jan 15 → start_doy=349, end_doy=15).
    For year-wrap rows the "year" label is assigned to the year of the
    December portion (i.e. year of the start of the window).
    """
    if df.empty:
        return df
    doy = df["doy"]
    if start_doy <= end_doy:
        mask = (doy >= start_doy) & (doy <= end_doy)
        return df.loc[mask].copy()
    else:
        # Wrap: include days >= start OR days <= end
        mask = (doy >= start_doy) | (doy <= end_doy)
        out = df.loc[mask].copy()
        # Re-label years for Jan portion: treat them as belonging to the prior year's window
        jan_mask = out["doy"] <= end_doy
        out.loc[jan_mask, "year"] = out.loc[jan_mask, "year"] - 1
        return out
