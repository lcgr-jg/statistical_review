"""
Data Freshness Footer Widget
─────────────────────────────
A small collapsible indicator in the bottom-right corner showing the
health of all data sources. Clicking it expands a detailed panel.

Colour coding:
    Green  – all sources fresh
    Amber  – one or more sources stale
    Red    – one or more sources critical
"""

from dash import html, dcc, Input, Output, State, no_update
from datetime import datetime
import logging

from core.data_freshness import tracker

logger = logging.getLogger(__name__)

# ── Status colours ─────────────────────────────────────────────────────────
_STATUS_COLORS = {
    'fresh': '#4CAF50',
    'stale': '#ff9800',
    'critical': '#f44336',
    'loading': '#42a5f5',
    'unknown': '#9e9e9e',
}

_STATUS_ICONS = {
    'fresh': '\u2714',      # ✔
    'stale': '\u25CF',      # ●
    'critical': '\u2716',   # ✖
    'loading': '\u2026',    # …
    'unknown': '\u25CB',    # ○
}


def create_freshness_widget():
    """
    Return the layout elements for the freshness widget.

    Components
    ----------
    - A persistent bottom-right pill showing aggregate status
    - A slide-up panel with per-source details
    - A 30-second interval to auto-refresh
    """
    return html.Div([
        # -- Interval to auto-refresh freshness data (every 30s) --
        dcc.Interval(
            id='freshness-widget-interval',
            interval=30_000,
            n_intervals=0,
        ),

        # -- Hidden store for panel open/close state --
        dcc.Store(id='freshness-panel-open', data=False),

        # -- Collapsed pill (bottom-right corner) --
        html.Div(
            id='freshness-pill',
            n_clicks=0,
            style={
                'position': 'fixed',
                'bottom': '20px',
                'right': '20px',
                'zIndex': '9999',
                'cursor': 'pointer',
                'display': 'flex',
                'alignItems': 'center',
                'gap': '8px',
                'padding': '8px 16px',
                'borderRadius': '20px',
                'backgroundColor': '#1a1a1a',
                'border': '1px solid #333',
                'boxShadow': '0 4px 12px rgba(0,0,0,0.3)',
                'transition': 'all 0.2s ease',
                'fontFamily': '-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif',
            },
            children=[
                # Status dot
                html.Div(
                    id='freshness-pill-dot',
                    style={
                        'width': '8px',
                        'height': '8px',
                        'borderRadius': '50%',
                        'backgroundColor': _STATUS_COLORS['unknown'],
                    },
                ),
                # Summary text
                html.Span(
                    id='freshness-pill-text',
                    children='Data Status',
                    style={
                        'fontSize': '12px',
                        'fontWeight': '500',
                        'color': '#ccc',
                    },
                ),
            ],
        ),

        # -- Expanded detail panel --
        html.Div(
            id='freshness-panel',
            style={
                'position': 'fixed',
                'bottom': '60px',
                'right': '20px',
                'width': '380px',
                'maxHeight': '400px',
                'overflowY': 'auto',
                'zIndex': '9998',
                'backgroundColor': '#1e1e1e',
                'border': '1px solid #333',
                'borderRadius': '12px',
                'boxShadow': '0 8px 24px rgba(0,0,0,0.4)',
                'padding': '0',
                'display': 'none',
                'fontFamily': '-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif',
            },
            children=[
                # Panel header
                html.Div(
                    style={
                        'padding': '14px 18px',
                        'borderBottom': '1px solid #333',
                        'display': 'flex',
                        'justifyContent': 'space-between',
                        'alignItems': 'center',
                    },
                    children=[
                        html.Span(
                            'Data Source Status',
                            style={
                                'fontSize': '13px',
                                'fontWeight': '600',
                                'color': '#fff',
                                'letterSpacing': '0.3px',
                            },
                        ),
                        html.Span(
                            id='freshness-panel-timestamp',
                            style={
                                'fontSize': '11px',
                                'color': '#888',
                            },
                        ),
                    ],
                ),
                # Panel body (rows per source)
                html.Div(id='freshness-panel-body', style={'padding': '8px 0'}),
            ],
        ),
    ])


def register_freshness_callbacks(app):
    """Register all callbacks for the freshness widget."""

    @app.callback(
        Output('freshness-panel', 'style'),
        Output('freshness-panel-open', 'data'),
        Input('freshness-pill', 'n_clicks'),
        State('freshness-panel', 'style'),
        State('freshness-panel-open', 'data'),
        prevent_initial_call=True,
    )
    def toggle_panel(n_clicks, current_style, is_open):
        if n_clicks is None:
            return no_update, no_update
        new_open = not is_open
        style = dict(current_style)
        style['display'] = 'block' if new_open else 'none'
        return style, new_open

    @app.callback(
        Output('freshness-pill-dot', 'style'),
        Output('freshness-pill-text', 'children'),
        Output('freshness-panel-body', 'children'),
        Output('freshness-panel-timestamp', 'children'),
        Input('freshness-widget-interval', 'n_intervals'),
    )
    def refresh_freshness_data(_n):
        all_data = tracker.get_all_freshness()
        summary = tracker.get_summary()
        now_str = datetime.now().strftime('%H:%M:%S')

        # ── Determine aggregate status ──
        if summary['total_sources'] == 0:
            agg_status = 'unknown'
            pill_text = 'No sources'
        elif summary['critical'] > 0:
            agg_status = 'critical'
            pill_text = f"{summary['critical']} critical"
        elif summary.get('loading', 0) > 0:
            agg_status = 'loading'
            pill_text = f"{summary['loading']} loading"
        elif summary['stale'] > 0:
            agg_status = 'stale'
            pill_text = f"{summary['stale']} stale / {summary['total_sources']}"
        else:
            agg_status = 'fresh'
            pill_text = f"{summary['fresh']}/{summary['total_sources']} OK"

        dot_style = {
            'width': '8px',
            'height': '8px',
            'borderRadius': '50%',
            'backgroundColor': _STATUS_COLORS[agg_status],
            'boxShadow': f"0 0 6px {_STATUS_COLORS[agg_status]}80",
        }

        # ── Build detail rows ──
        rows = []
        if not all_data:
            rows.append(
                html.Div(
                    'No data sources registered yet.',
                    style={
                        'padding': '16px 18px',
                        'color': '#888',
                        'fontSize': '12px',
                        'fontStyle': 'italic',
                    },
                )
            )
        else:
            # Sort: critical first, then loading, then stale, then fresh
            priority = {'critical': 0, 'loading': 1, 'stale': 2, 'fresh': 3}
            sorted_sources = sorted(
                all_data.items(),
                key=lambda x: (priority.get(x[1]['status'], 4), x[0]),
            )

            for source_name, info in sorted_sources:
                status = info['status']
                age = info.get('age_minutes', 0)
                last_update = info['last_update']
                metadata = info.get('metadata', {})

                # Human-readable age
                if status == 'loading':
                    age_str = metadata.get('state', 'loading')
                elif age < 60:
                    age_str = f"{age}m ago"
                elif age < 1440:
                    age_str = f"{age // 60}h {age % 60}m ago"
                else:
                    age_str = f"{age // 1440}d ago"

                color = _STATUS_COLORS.get(status, _STATUS_COLORS['unknown'])
                icon = _STATUS_ICONS.get(status, _STATUS_ICONS['unknown'])

                # Metadata line
                meta_parts = []
                if metadata.get('state') in ('pending', 'loading'):
                    meta_parts.append(str(metadata.get('detail') or metadata['state']))
                if metadata.get('error'):
                    meta_parts.append(f"error: {metadata['error']}")
                if metadata.get('datasets'):
                    meta_parts.append(f"datasets: {metadata['datasets']}")
                if metadata.get('records'):
                    meta_parts.append(f"{metadata['records']:,} records")
                if metadata.get('issue_date'):
                    meta_parts.append(f"issue: {metadata['issue_date']}")
                if metadata.get('index_start'):
                    meta_parts.append(f"from: {metadata['index_start']}")
                meta_str = ' | '.join(meta_parts)

                rows.append(
                    html.Div(
                        style={
                            'padding': '10px 18px',
                            'borderBottom': '1px solid #2a2a2a',
                            'display': 'flex',
                            'alignItems': 'flex-start',
                            'gap': '10px',
                        },
                        children=[
                            # Status icon
                            html.Span(
                                icon,
                                style={
                                    'color': color,
                                    'fontSize': '12px',
                                    'marginTop': '2px',
                                    'flexShrink': '0',
                                },
                            ),
                            # Source details
                            html.Div(
                                style={'flex': '1', 'minWidth': '0'},
                                children=[
                                    html.Div(
                                        source_name,
                                        style={
                                            'fontSize': '12px',
                                            'fontWeight': '500',
                                            'color': '#e0e0e0',
                                            'whiteSpace': 'nowrap',
                                            'overflow': 'hidden',
                                            'textOverflow': 'ellipsis',
                                        },
                                    ),
                                    html.Div(
                                        meta_str,
                                        style={
                                            'fontSize': '10px',
                                            'color': '#777',
                                            'marginTop': '2px',
                                        },
                                    ) if meta_str else None,
                                ],
                            ),
                            # Age badge
                            html.Div(
                                age_str,
                                style={
                                    'fontSize': '11px',
                                    'fontWeight': '500',
                                    'color': color,
                                    'whiteSpace': 'nowrap',
                                    'flexShrink': '0',
                                },
                            ),
                        ],
                    )
                )

        return dot_style, pill_text, rows, f"Updated {now_str}"
