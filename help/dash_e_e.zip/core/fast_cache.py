"""
fast_cache
==========
A tiny, memory-only cache that stores Plotly figures as *pre-serialised JSON
bytes*.  It is designed to sit next to the existing ``core.cache.dashboard_cache``
(which owns raw data + scheduling) and does one thing extremely well: hand
finished figure bytes to the HTTP layer without touching ``json.dumps`` again.

Why a second cache?
-------------------
The existing ``DashboardCache`` stores pickled Python objects.  Returning a
Plotly ``Figure`` from a Dash callback means Dash re-serialises the whole
object graph on *every single response*, which for a 10 k-point candlestick
takes 200-800 ms.

Here we pay that cost **once** at warm-up time, store the resulting bytes,
and return them directly from the callback via ``Figure(dict_from_json)`` —
which is essentially free because Plotly's JSON round-trip is orders of
magnitude faster than Dash's default serialiser.

Public API
----------
    from core.fast_cache import figure_cache

    figure_cache.set("fuel_switching:default", my_fig, ttl=3600)
    bytes_payload = figure_cache.get_json("fuel_switching:default")
    fig           = figure_cache.get_figure("fuel_switching:default")
    figure_cache.invalidate(prefix="fuel_switching:")
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable, Dict, Iterable, Optional

logger = logging.getLogger(__name__)

try:
    import plotly.graph_objects as go
    import plotly.io as pio
    _PLOTLY = True
except ImportError:  # pragma: no cover
    _PLOTLY = False


class FigureCache:
    """Memory-only cache for pre-serialised Plotly figures.

    Stores one entry per (key) pair: the figure's JSON string encoded as
    UTF-8 bytes, plus an expiry timestamp.  All access is thread-safe.
    """

    __slots__ = ("_store", "_lock", "_hits", "_misses", "_builds")

    def __init__(self) -> None:
        self._store: Dict[str, tuple] = {}  # key -> (bytes, expiry_epoch)
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0
        self._builds = 0

    # ------------------------------------------------------------------
    # Low-level get / set
    # ------------------------------------------------------------------

    def set(self, key: str, figure: Any, ttl: int = 3600) -> None:
        """Serialise *figure* to JSON bytes and store under *key*."""
        payload = self._to_bytes(figure)
        expiry = time.time() + ttl
        with self._lock:
            self._store[key] = (payload, expiry)
            self._builds += 1

    def set_json(self, key: str, payload: bytes, ttl: int = 3600) -> None:
        """Store already-serialised JSON bytes under *key*."""
        if not isinstance(payload, (bytes, bytearray)):
            payload = str(payload).encode("utf-8")
        expiry = time.time() + ttl
        with self._lock:
            self._store[key] = (bytes(payload), expiry)

    def get_json(self, key: str) -> Optional[bytes]:
        """Return raw JSON bytes for *key* or ``None`` on miss/expiry."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None
            payload, expiry = entry
            if time.time() >= expiry:
                self._store.pop(key, None)
                self._misses += 1
                return None
            self._hits += 1
            return payload

    def get_figure(self, key: str) -> Optional[Any]:
        """Reconstruct a Plotly Figure from cached JSON, or ``None``."""
        payload = self.get_json(key)
        if payload is None:
            return None
        if not _PLOTLY:
            return None
        try:
            return pio.from_json(payload.decode("utf-8"))
        except Exception as exc:
            logger.warning("fast_cache: failed to decode figure %s: %s", key, exc)
            return None

    # ------------------------------------------------------------------
    # Get-or-build (synchronous)
    # ------------------------------------------------------------------

    def get_or_build(
        self,
        key: str,
        builder: Callable[[], Any],
        ttl: int = 3600,
    ) -> Any:
        """Return cached figure; if absent, call *builder* and cache the result."""
        fig = self.get_figure(key)
        if fig is not None:
            return fig
        fig = builder()
        if fig is not None:
            self.set(key, fig, ttl=ttl)
        return fig

    # ------------------------------------------------------------------
    # Invalidation
    # ------------------------------------------------------------------

    def invalidate(self, key: Optional[str] = None, prefix: Optional[str] = None) -> int:
        """Remove a key, or all keys starting with *prefix*.  Returns count removed."""
        removed = 0
        with self._lock:
            if key is not None:
                if self._store.pop(key, None) is not None:
                    removed += 1
            elif prefix is not None:
                for k in [k for k in self._store if k.startswith(prefix)]:
                    self._store.pop(k, None)
                    removed += 1
            else:
                removed = len(self._store)
                self._store.clear()
        if removed:
            logger.info("fast_cache: invalidated %d entries (prefix=%s key=%s)",
                        removed, prefix, key)
        return removed

    # ------------------------------------------------------------------
    # Stats / introspection
    # ------------------------------------------------------------------

    def keys(self) -> Iterable[str]:
        with self._lock:
            return list(self._store.keys())

    def stats(self) -> Dict[str, Any]:
        total = self._hits + self._misses
        with self._lock:
            size_bytes = sum(len(v[0]) for v in self._store.values())
            return {
                "entries": len(self._store),
                "size_bytes": size_bytes,
                "size_mb": round(size_bytes / 1024 / 1024, 2),
                "hits": self._hits,
                "misses": self._misses,
                "builds": self._builds,
                "hit_rate": f"{self._hits / total:.1%}" if total else "N/A",
            }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_bytes(figure: Any) -> bytes:
        """Serialise a Plotly Figure or plain dict to compact JSON bytes."""
        if _PLOTLY and isinstance(figure, go.Figure):
            return pio.to_json(figure, validate=False, remove_uids=True).encode("utf-8")
        if isinstance(figure, dict):
            import json
            return json.dumps(figure, default=str, separators=(",", ":")).encode("utf-8")
        if isinstance(figure, (bytes, bytearray)):
            return bytes(figure)
        if isinstance(figure, str):
            return figure.encode("utf-8")
        raise TypeError(f"fast_cache: cannot serialise {type(figure).__name__}")


# ----------------------------------------------------------------------
# Singleton
# ----------------------------------------------------------------------
figure_cache = FigureCache()
