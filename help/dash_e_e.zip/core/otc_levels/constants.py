"""Static configuration for the OTC Levels tab (import-safe, no Snowflake)."""
from __future__ import annotations

# ── Tab registration (lives inside the Trade Data / microstructure page) ─────
TAB_ID = "tab-otc"
TAB_LABEL = "OTC Levels"

# Trayport market-name suffix per Trade Data shape label
SHAPE_TO_MARKET_SUFFIX = {"Baseload": "Baseload", "Peakload": "Peaks", "Offpeak": "Offpeak"}

# ── Venue classification ─────────────────────────────────────────────────────
# Prints on these venue codes are exchange (screen); everything else is a
# brokered / OTC print.  EEX7 = EEX T7, ICE = ICE Endex.
EXCHANGE_VENUES = frozenset({"EEX7", "ICE"})
# Fixed display order for brokers; anything else folds into "Other".
VENUE_ORDER: list[str] = ["BGC", "ICAP", "GFI", "SPEC", "PREB", "GRFN", "TFS", "MGFI", "Other"]

# ── Analysis defaults ────────────────────────────────────────────────────────
DEFAULT_BIG_CLIP_MW = 5.0
LADDER_STEP = 1.0            # €/MWh per ladder bucket
SCREEN_TOLERANCE_MIN = 60    # max age of the EEX print used as screen reference
STRIP_WINDOW = "5s"          # Q2/Q3 legs printed within this window form a Summer strip
RECENT_PRINTS_N = 60

# ── Cache ────────────────────────────────────────────────────────────────────
CACHE_PREFIX = "otc_levels"
CACHE_TTL_LIVE = 15 * 60        # today's tape refreshes every 15 min
CACHE_TTL_HISTORICAL = 12 * 3600
