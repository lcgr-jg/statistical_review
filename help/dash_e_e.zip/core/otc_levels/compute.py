"""Pure pandas transforms for the OTC Levels tab (no Dash, no Snowflake).

Core idea
---------
A brokered print reveals a *resting* level:

* ``AGGRESSOR_BUY = False`` -> a seller hit a resting **bid**   -> buyer's level
* ``AGGRESSOR_BUY = True``  -> a buyer lifted a resting **offer** -> seller's level

On France Baseload the resting bids in size are mostly industrial hedgers and
the resting offers mostly EDF, so tracking these prints by contract, venue,
clip size and price level shows where each side is prepared to transact.

Summer contracts are not listed in most markets; ``Sum YY`` is rebuilt from
Q2/Q3 legs that print together (same venue, size, side, within a few seconds)
and priced as the day-weighted average of the two legs.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from .constants import (
    EXCHANGE_VENUES,
    LADDER_STEP,
    SCREEN_TOLERANCE_MIN,
    STRIP_WINDOW,
    VENUE_ORDER,
)

Q2_DAYS, Q3_DAYS = 91, 92
LOCAL_TZ = "Europe/Paris"

# ── Contract labels ──────────────────────────────────────────────────────────


def contract_label(tenor_name: str, family: str) -> str | None:
    """'2027'/'Years' -> 'Cal 27'; 'Q227'/'Quarters' -> 'Q2 27'."""
    t = str(tenor_name)
    if family == "Years" and re.fullmatch(r"\d{4}", t):
        return f"Cal {t[2:]}"
    m = re.fullmatch(r"Q([1-4])(\d{2})", t)
    if family == "Quarters" and m:
        return f"Q{m.group(1)} {m.group(2)}"
    return None


def _sort_key(label: str) -> tuple:
    kind, yy = label.split()
    rank = {"Cal": 0, "Sum": 1, "Q1": 2, "Q2": 3, "Q3": 4, "Q4": 5}.get(kind, 9)
    return (int(yy), rank)


def available_contracts(df: pd.DataFrame) -> list[str]:
    labels = set(df["contract"].dropna().unique())
    years = {l.split()[1] for l in labels}
    for yy in years:
        if f"Q2 {yy}" in labels and f"Q3 {yy}" in labels:
            labels.add(f"Sum {yy}")
    return sorted(labels, key=_sort_key)


def default_contracts(options: list[str], today: datetime | None = None) -> list[str]:
    today = today or datetime.now()
    y1, y2 = (today.year + 1) % 100, (today.year + 2) % 100
    wanted = [f"Cal {y1:02d}", f"Sum {y1:02d}", f"Cal {y2:02d}"]
    picked = [c for c in wanted if c in options]
    return picked or options[:3]


# ── Preparation ──────────────────────────────────────────────────────────────


def prepare(raw: pd.DataFrame) -> pd.DataFrame:
    """Clean the raw tape and add contract / venue / resting-side columns."""
    if raw is None or raw.empty:
        return pd.DataFrame()
    df = raw.copy()
    if "FROM_BROKEN_SPREAD" in df.columns:
        df = df[~df["FROM_BROKEN_SPREAD"].astype(bool)]
    if "CONTRACT_TYPE" in df.columns:
        df = df[df["CONTRACT_TYPE"] == "SinglePeriod"]
    df = df.dropna(subset=["PRICE"])
    df = df[df["QUANTITY"] > 0].copy()

    df["contract"] = [contract_label(t, f) for t, f in zip(df["TENOR_NAME"], df["TENOR_FAMILY"])]
    df = df.dropna(subset=["contract"])

    t = pd.to_datetime(df["DEAL_TIME_UTC"])
    if t.dt.tz is None:
        t = t.dt.tz_localize("UTC")
    df["t"] = t
    df["t_local"] = t.dt.tz_convert(LOCAL_TZ)
    df["date"] = df["t_local"].dt.tz_localize(None).dt.normalize()
    vc = df["VENUE_CODE"].fillna("?").astype(str)
    df["is_otc"] = ~vc.isin(EXCHANGE_VENUES)
    df["venue"] = np.where(vc.isin(VENUE_ORDER), vc, "Other")
    df.loc[~df["is_otc"], "venue"] = vc[~df["is_otc"]]
    df["resting"] = np.where(df["AGGRESSOR_BUY"].astype(bool), "offer", "bid")
    return df.sort_values("t").reset_index(drop=True)


def add_screen_reference(otc: pd.DataFrame, eex: pd.DataFrame) -> pd.DataFrame:
    """Attach the last EEX print (same contract, <= tolerance earlier) and the basis to it."""
    if otc.empty:
        otc = otc.copy()
        otc["eex_ref"] = np.nan
        otc["basis"] = np.nan
        return otc
    tol = pd.Timedelta(minutes=SCREEN_TOLERANCE_MIN)
    parts = []
    for c, g in otc.groupby("contract", sort=False):
        e = eex[eex["contract"] == c][["t", "PRICE"]].rename(columns={"PRICE": "eex_ref"}).sort_values("t")
        if e.empty:
            g = g.copy()
            g["eex_ref"] = np.nan
        else:
            g = pd.merge_asof(g.sort_values("t"), e, on="t", direction="backward", tolerance=tol)
        parts.append(g)
    out = pd.concat(parts, ignore_index=True)
    out["basis"] = out["PRICE"] - out["eex_ref"]
    return out


# ── Summer strips ────────────────────────────────────────────────────────────


def build_strips(otc: pd.DataFrame, yy: str) -> pd.DataFrame:
    """Pair Q2/Q3 legs of year ``yy`` into ``Sum yy`` prints."""
    q2 = otc[otc["contract"] == f"Q2 {yy}"].copy()
    q3 = otc[otc["contract"] == f"Q3 {yy}"].copy()
    if q2.empty or q3.empty:
        return pd.DataFrame()
    q2["ts"] = q2["t"].dt.floor(STRIP_WINDOW)
    q3["ts"] = q3["t"].dt.floor(STRIP_WINDOW)
    m = q2.merge(q3, on=["ts", "venue", "QUANTITY", "resting"], suffixes=("_q2", "_q3"))
    m = m.drop_duplicates("TRADE_ID_q2").drop_duplicates("TRADE_ID_q3")
    if m.empty:
        return pd.DataFrame()
    w2, w3 = Q2_DAYS / (Q2_DAYS + Q3_DAYS), Q3_DAYS / (Q2_DAYS + Q3_DAYS)
    out = pd.DataFrame({
        "TRADE_ID": m["TRADE_ID_q2"] + "+" + m["TRADE_ID_q3"],
        "t": m["t_q2"], "t_local": m["t_local_q2"], "date": m["date_q2"],
        "venue": m["venue"], "resting": m["resting"], "QUANTITY": m["QUANTITY"],
        "PRICE": m["PRICE_q2"] * w2 + m["PRICE_q3"] * w3,
        "leg_q2": m["PRICE_q2"], "leg_q3": m["PRICE_q3"],
        "eex_ref": m["eex_ref_q2"] * w2 + m["eex_ref_q3"] * w3,
    })
    out["basis"] = out["PRICE"] - out["eex_ref"]
    out["contract"] = f"Sum {yy}"
    out["is_otc"] = True
    return out.sort_values("t").reset_index(drop=True)


def synthetic_summer_eex(eex_daily: pd.DataFrame, yy: str) -> pd.DataFrame:
    q2 = eex_daily[eex_daily["contract"] == f"Q2 {yy}"].set_index("date")
    q3 = eex_daily[eex_daily["contract"] == f"Q3 {yy}"].set_index("date")
    idx = q2.index.intersection(q3.index)
    if len(idx) == 0:
        return pd.DataFrame()
    w2, w3 = Q2_DAYS / (Q2_DAYS + Q3_DAYS), Q3_DAYS / (Q2_DAYS + Q3_DAYS)
    d = pd.DataFrame(index=idx)
    for c in ("vwap", "low", "high", "close"):
        d[c] = q2.loc[idx, c] * w2 + q3.loc[idx, c] * w3
    d["mw"] = np.minimum(q2.loc[idx, "mw"], q3.loc[idx, "mw"])
    d["contract"] = f"Sum {yy}"
    return d.reset_index()


# ── Aggregates ───────────────────────────────────────────────────────────────


def _vwap(g: pd.DataFrame) -> float:
    return float(np.average(g["PRICE"], weights=g["QUANTITY"]))


def eex_daily(eex: pd.DataFrame) -> pd.DataFrame:
    if eex.empty:
        return pd.DataFrame(columns=["contract", "date", "vwap", "low", "high", "close", "mw"])
    e = eex.sort_values("t").assign(_pq=lambda x: x["PRICE"] * x["QUANTITY"])
    g = e.groupby(["contract", "date"])
    d = pd.DataFrame({
        "vwap": g["_pq"].sum() / g["QUANTITY"].sum(),
        "low": g["PRICE"].min(),
        "high": g["PRICE"].max(),
        "close": g["PRICE"].last(),
        "mw": g["QUANTITY"].sum(),
    })
    return d.reset_index()


def otc_daily(prints: pd.DataFrame) -> pd.DataFrame:
    """Per contract/day: MW and best level by resting side."""
    if prints.empty:
        return pd.DataFrame(columns=["contract", "date", "bid_mw", "offer_mw", "bid_max", "offer_min"])
    rows = []
    for (c, d), g in prints.groupby(["contract", "date"]):
        b, o = g[g["resting"] == "bid"], g[g["resting"] == "offer"]
        rows.append({
            "contract": c, "date": d,
            "bid_mw": b["QUANTITY"].sum(), "offer_mw": o["QUANTITY"].sum(),
            "bid_max": b["PRICE"].max() if len(b) else np.nan,
            "offer_min": o["PRICE"].min() if len(o) else np.nan,
            "bid_vwap": _vwap(b) if len(b) else np.nan,
            "offer_vwap": _vwap(o) if len(o) else np.nan,
        })
    return pd.DataFrame(rows)


def ladder(big: pd.DataFrame, step: float = LADDER_STEP) -> pd.DataFrame:
    if big.empty:
        return pd.DataFrame(columns=["contract", "resting", "bucket", "mw", "n"])
    b = big.copy()
    b["bucket"] = np.floor(b["PRICE"] / step) * step
    out = b.groupby(["contract", "resting", "bucket"]).agg(mw=("QUANTITY", "sum"), n=("QUANTITY", "size"))
    return out.reset_index()


def venue_summary(prints: pd.DataFrame, big_clip: float) -> pd.DataFrame:
    if prints.empty:
        return pd.DataFrame()
    rows = []
    for (v, side), g in prints.groupby(["venue", "resting"]):
        rows.append({
            "venue": v, "resting": side, "n": len(g), "mw": g["QUANTITY"].sum(),
            "avg_clip": g["QUANTITY"].mean(),
            "big_mw": g.loc[g["QUANTITY"] >= big_clip, "QUANTITY"].sum(),
            "basis_med": g["basis"].median(),
        })
    return pd.DataFrame(rows)


def hour_profile(prints: pd.DataFrame) -> pd.DataFrame:
    if prints.empty:
        return pd.DataFrame(columns=["resting", "hour", "mw"])
    p = prints.copy()
    p["hour"] = p["t_local"].dt.hour
    return p.groupby(["resting", "hour"])["QUANTITY"].sum().rename("mw").reset_index()


def last_prices(eex: pd.DataFrame, contracts: list[str]) -> dict[str, float | None]:
    out: dict[str, float | None] = {}
    last = eex.sort_values("t").groupby("contract")["PRICE"].last() if not eex.empty else pd.Series(dtype=float)
    w2, w3 = Q2_DAYS / (Q2_DAYS + Q3_DAYS), Q3_DAYS / (Q2_DAYS + Q3_DAYS)
    for c in contracts:
        if c.startswith("Sum "):
            yy = c.split()[1]
            a, b = last.get(f"Q2 {yy}"), last.get(f"Q3 {yy}")
            out[c] = float(a * w2 + b * w3) if a is not None and b is not None else None
        else:
            v = last.get(c)
            out[c] = float(v) if v is not None else None
    return out


# ── Master builder ───────────────────────────────────────────────────────────


def _utc(ts) -> pd.Timestamp:
    t = pd.Timestamp(ts)
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


def build_dataset(
    raw: pd.DataFrame,
    contracts: list[str],
    start,
    end,
    big_clip: float,
) -> dict:
    """Everything the tab renders, for the selected contracts and the [start, end] date window."""
    df = prepare(raw)
    if df.empty:
        return {"empty": True}

    cutoff = _utc(pd.Timestamp(start).normalize())
    now_ts = _utc(pd.Timestamp(end).normalize() + timedelta(days=1))
    df = df[df["t"] < now_ts]

    eex_all = df[~df["is_otc"]]
    otc_all = add_screen_reference(df[df["is_otc"]], eex_all)

    # Summer strips for every selected Sum contract
    summer_years = [c.split()[1] for c in contracts if c.startswith("Sum ")]
    strips = pd.concat([build_strips(otc_all, yy) for yy in summer_years], ignore_index=True) if summer_years else pd.DataFrame()

    real = [c for c in contracts if not c.startswith("Sum ")]
    prints = pd.concat([otc_all[otc_all["contract"].isin(real)], strips], ignore_index=True)
    prints = prints[prints["t"] >= cutoff].sort_values("t").reset_index(drop=True)

    eex_d = eex_daily(eex_all[eex_all["t"] >= cutoff])
    if summer_years:
        eex_d = pd.concat([eex_d] + [synthetic_summer_eex(eex_d, yy) for yy in summer_years], ignore_index=True)
    eex_d = eex_d[eex_d["contract"].isin(contracts)]

    big = prints[prints["QUANTITY"] >= big_clip].copy()
    eex_win = eex_all[(eex_all["t"] >= cutoff) & (eex_all["contract"].isin(real))]

    # ── KPIs ──
    otc_mw = float(prints["QUANTITY"].sum())
    eex_mw = float(eex_win["QUANTITY"].sum())
    big_bid = float(big.loc[big["resting"] == "bid", "QUANTITY"].sum())
    big_off = float(big.loc[big["resting"] == "offer", "QUANTITY"].sum())
    bid_by_venue = prints[prints["resting"] == "bid"].groupby("venue")["QUANTITY"].sum()
    off_by_venue = prints[prints["resting"] == "offer"].groupby("venue")["QUANTITY"].sum()

    def _last(side: str) -> dict | None:
        g = big[big["resting"] == side]
        if g.empty:
            return None
        r = g.iloc[-1]
        return {"contract": r["contract"], "price": float(r["PRICE"]), "mw": float(r["QUANTITY"]),
                "venue": r["venue"], "time": r["t_local"].strftime("%d %b %H:%M")}

    kpis = {
        "otc_share": otc_mw / (otc_mw + eex_mw) if (otc_mw + eex_mw) else np.nan,
        "otc_mw": otc_mw, "eex_mw": eex_mw,
        "big_bid_mw": big_bid, "big_offer_mw": big_off,
        "top_bid_venue": bid_by_venue.idxmax() if len(bid_by_venue) else "–",
        "top_bid_venue_share": float(bid_by_venue.max() / bid_by_venue.sum()) if len(bid_by_venue) else np.nan,
        "top_offer_venue": off_by_venue.idxmax() if len(off_by_venue) else "–",
        "basis_med": float(prints["basis"].median()) if prints["basis"].notna().any() else np.nan,
        "last_big_bid": _last("bid"), "last_big_offer": _last("offer"),
    }

    return {
        "empty": prints.empty and eex_d.empty,
        "contracts": contracts,
        "prints": prints,
        "big": big,
        "eex_daily": eex_d,
        "otc_daily": otc_daily(prints),
        "ladder": ladder(big),
        "venue": venue_summary(prints, big_clip),
        "hours": hour_profile(prints),
        "last_px": last_prices(eex_all, contracts),
        "kpis": kpis,
        "window": (cutoff, now_ts),
    }
