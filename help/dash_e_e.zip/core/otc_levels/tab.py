"""OTC Levels tab inside the Trade Data (microstructure) page.

``build_otc_tab()`` is called by :func:`core.microstructure.callbacks._render_tab`
when the tab is active.  It fetches the outright tape for the page's Market /
Shape / Date range, fills the contract selector, and returns the tab shell.
The sub-callback below renders the KPI row and the selected sub-tab whenever
the contract set, clip threshold or sub-tab changes.
"""
from __future__ import annotations

import logging

import dash_bootstrap_components as dbc
import pandas as pd
from dash import Input, Output, State, callback, dcc, html

from core.styles import COLORS

from . import figures as F
from .compute import available_contracts, build_dataset, default_contracts, prepare
from .constants import DEFAULT_BIG_CLIP_MW, RECENT_PRINTS_N
from .data import fetch_trades, fetched_at_text

logger = logging.getLogger(__name__)

SUBTABS: list[tuple[str, str]] = [
    ("otc-levels", "Levels"),
    ("otc-ladder", "Hedge ladder"),
    ("otc-prints", "Recent prints"),
    ("otc-venues", "Venues & timing"),
]

_LABEL = {"fontSize": "11px", "fontWeight": "600", "color": COLORS["text_secondary"],
          "marginBottom": "4px", "textTransform": "uppercase", "letterSpacing": "0.04em"}
_NOTE = {"fontSize": "12px", "color": COLORS["text_muted"], "marginBottom": "10px"}


# ── Small UI helpers ─────────────────────────────────────────────────────────

def _msg(text: str) -> html.Div:
    return html.Div(text, style={"padding": "24px", "textAlign": "center", "color": COLORS["text_muted"], "fontSize": "14px"})


def _kpi(title: str, value: str, sub: str = "") -> html.Div:
    return html.Div(style={"minWidth": "130px"}, children=[
        html.Div(title, style={"fontSize": "11px", "fontWeight": "600", "color": COLORS["text_muted"], "textTransform": "uppercase", "letterSpacing": "0.04em"}),
        html.Div(value, style={"fontSize": "17px", "fontWeight": "600", "color": COLORS["text_primary"], "fontVariantNumeric": "tabular-nums"}),
        html.Div(sub, style={"fontSize": "11px", "color": COLORS["text_muted"]}) if sub else None,
    ])


def _card(children, title: str | None = None) -> html.Div:
    kids = []
    if title:
        kids.append(html.Div(title, style={"fontSize": "13px", "fontWeight": "600", "color": COLORS["text_secondary"], "marginBottom": "6px"}))
    kids.append(children)
    return html.Div(kids, style={"backgroundColor": COLORS["card_bg"], "border": f"1px solid {COLORS['border']}", "borderRadius": "8px", "padding": "12px 14px"})


def _mw(x: float) -> str:
    return f"{x:,.0f}"


def _print_kpi(title: str, p: dict | None) -> html.Div:
    if not p:
        return _kpi(title, "–")
    return _kpi(title, f"{p['contract']}  {p['price']:.2f}", f"{p['mw']:.0f} MW · {p['venue']} · {p['time']}")


# ── Tab shell (called from the microstructure render callback) ───────────────

def build_otc_tab(zone: str | None, shape: str | None, commodity: str | None,
                  start_date, end_date) -> html.Div:
    if (commodity or "Power") != "Power":
        return _msg("OTC Levels is available for Power markets only.")
    if not zone or not shape or not start_date:
        return _msg("Select a market, shape and date range, then open this tab.")
    try:
        raw = fetch_trades(zone, shape, start_date, end_date)
    except Exception as exc:  # pragma: no cover - network / creds
        logger.exception("[otc_levels] fetch failed")
        return _msg(f"Load failed: {exc}")
    df = prepare(raw)
    if df.empty:
        return _msg(f"No outright Year/Quarter prints for {zone} {shape} in this date range.")
    options = available_contracts(df)
    value = default_contracts(options)

    controls = html.Div(
        style={"display": "flex", "flexWrap": "wrap", "gap": "16px", "alignItems": "flex-end", "marginBottom": "12px"},
        children=[
            html.Div(style={"width": "380px"}, children=[
                html.Div("Contracts", style=_LABEL),
                dcc.Dropdown(id="ms-otc-contracts", multi=True, options=[{"label": c, "value": c} for c in options],
                             value=value, style={"fontSize": "13px"}),
            ]),
            html.Div(style={"width": "120px"}, children=[
                html.Div("Big clip ≥ MW", style=_LABEL),
                dbc.Input(id="ms-otc-bigclip", type="number", min=1, step=1, value=DEFAULT_BIG_CLIP_MW, size="sm"),
            ]),
            html.Div(f"{zone} {shape} · {fetched_at_text(raw)} · Sum = Q2+Q3 legs printed together",
                     style={"fontSize": "12px", "color": COLORS["text_muted"], "paddingBottom": "6px"}),
        ],
    )
    subtabs = dbc.Tabs(id="ms-otc-subtabs", active_tab="otc-levels", style={"marginBottom": "12px"},
                       children=[dbc.Tab(label=label, tab_id=tid) for tid, label in SUBTABS])
    body = dcc.Loading(type="default", color=COLORS["accent"], children=html.Div(id="ms-otc-body", style={"minHeight": "300px"}))
    return html.Div([controls, subtabs, body])


# ── Sub-callback: KPI row + selected sub-tab ─────────────────────────────────

@callback(
    Output("ms-otc-body", "children"),
    Input("ms-otc-subtabs", "active_tab"),
    Input("ms-otc-contracts", "value"),
    Input("ms-otc-bigclip", "value"),
    State("ms-zone", "value"),
    State("ms-shape", "value"),
    State("ms-date-range", "start_date"),
    State("ms-date-range", "end_date"),
)
def _render_otc(subtab, contracts, big_clip, zone, shape, start_date, end_date):
    if not contracts:
        return _msg("Select at least one contract.")
    big_clip = float(big_clip or DEFAULT_BIG_CLIP_MW)
    try:
        raw = fetch_trades(zone, shape, start_date, end_date)  # cache hit after the shell built
    except Exception as exc:  # pragma: no cover
        return _msg(f"Load failed: {exc}")
    ds = build_dataset(raw, list(contracts), start_date, end_date or pd.Timestamp.today(), big_clip)
    if ds.get("empty"):
        return _msg("No prints in this window.")

    k = ds["kpis"]
    kpi_row = html.Div(
        style={"display": "flex", "gap": "28px", "flexWrap": "wrap", "marginBottom": "14px"},
        children=[
            _kpi("Off-screen share", f"{k['otc_share']*100:.0f}%" if pd.notna(k["otc_share"]) else "–",
                 f"{_mw(k['otc_mw'])} MW OTC · {_mw(k['eex_mw'])} MW EEX"),
            _kpi(f"≥{big_clip:g} MW  bid hit / offer lifted", f"{_mw(k['big_bid_mw'])} / {_mw(k['big_offer_mw'])} MW"),
            _kpi("Top bid-side broker", k["top_bid_venue"],
                 f"{k['top_bid_venue_share']*100:.0f}% of OTC bid MW · offers: {k['top_offer_venue']}" if pd.notna(k["top_bid_venue_share"]) else ""),
            _print_kpi("Last big bid hit", k["last_big_bid"]),
            _print_kpi("Last big offer lifted", k["last_big_offer"]),
            _kpi("OTC vs screen (median)", f"{k['basis_med']:+.2f}" if pd.notna(k["basis_med"]) else "–", "€/MWh, print vs last EEX ≤ 60 min"),
        ],
    )
    if subtab == "otc-ladder":
        content = _tab_ladder(ds, big_clip)
    elif subtab == "otc-prints":
        content = _tab_prints(ds, big_clip)
    elif subtab == "otc-venues":
        content = _tab_venues(ds)
    else:
        content = _tab_levels(ds, big_clip)
    return html.Div([kpi_row, content])


# ── Sub-tab bodies ───────────────────────────────────────────────────────────

def _tab_levels(ds: dict, big_clip: float):
    cards = [_card(dcc.Graph(figure=F.fig_levels(ds["eex_daily"], ds["big"], ds["otc_daily"], c, ds["last_px"].get(c), big_clip), config=F.CFG))
             for c in ds["contracts"]]
    note = html.Div(
        "Grey: EEX daily VWAP and low–high range. Dots: OTC prints at or above the clip threshold, area ∝ MW; blue = a resting bid was hit "
        "(buyer's level), orange = a resting offer was lifted (seller's level). Lower panel: all OTC MW that day by side.", style=_NOTE)
    return html.Div([note, html.Div(cards, style={"display": "grid", "gap": "14px"})])


def _tab_ladder(ds: dict, big_clip: float):
    n = len(ds["contracts"])
    cols = "repeat(auto-fit, minmax(340px, 1fr))" if n > 1 else "1fr"
    cards = [_card(dcc.Graph(figure=F.fig_ladder(ds["ladder"], c, ds["last_px"].get(c)), config=F.CFG)) for c in ds["contracts"]]
    note = html.Div(
        f"MW of OTC prints ≥ {big_clip:g} MW per 1 €/MWh bucket over the date range. Bids hit extend left, offers lifted extend right; "
        "the dotted line is the last EEX print. Buckets below the current price with bid volume are levels where hedgers have absorbed size.", style=_NOTE)
    return html.Div([note, html.Div(cards, style={"display": "grid", "gridTemplateColumns": cols, "gap": "14px"})])


def _tab_prints(ds: dict, big_clip: float):
    big = ds["big"].sort_values("t", ascending=False).head(RECENT_PRINTS_N)
    if big.empty:
        return _msg(f"No OTC prints ≥ {big_clip:g} MW in the window.")
    head = ["Time (Paris)", "Contract", "Side", "Broker", "MW", "Price", "vs screen", "Legs (Q2 / Q3)"]
    rows = []
    for r in big.itertuples(index=False):
        side = "bid hit" if r.resting == "bid" else "offer lifted"
        col = F.BID if r.resting == "bid" else F.OFFER
        q2 = getattr(r, "leg_q2", None)
        legs = f"{q2:.2f} / {r.leg_q3:.2f}" if q2 is not None and pd.notna(q2) else ""
        rows.append(html.Tr([
            html.Td(r.t_local.strftime("%d %b %H:%M:%S")),
            html.Td(r.contract),
            html.Td(side, style={"color": col, "fontWeight": "600"}),
            html.Td(r.venue),
            html.Td(f"{r.QUANTITY:.0f}", style={"textAlign": "right"}),
            html.Td(f"{r.PRICE:.2f}", style={"textAlign": "right", "fontVariantNumeric": "tabular-nums"}),
            html.Td("" if pd.isna(r.basis) else f"{r.basis:+.2f}", style={"textAlign": "right"}),
            html.Td(legs, style={"color": COLORS["text_muted"]}),
        ]))
    table = dbc.Table([html.Thead(html.Tr([html.Th(h) for h in head])), html.Tbody(rows)],
                      bordered=False, hover=True, size="sm", style={"fontSize": "12.5px", "backgroundColor": COLORS["card_bg"]})
    return _card(table, f"Last {len(big)} OTC prints ≥ {big_clip:g} MW")


def _tab_venues(ds: dict):
    vs = ds["venue"]
    left = _card(dcc.Graph(figure=F.fig_venues(vs), config=F.CFG), "OTC MW by broker and resting side")
    right = _card(dcc.Graph(figure=F.fig_hours(ds["hours"]), config=F.CFG), "OTC MW by hour of day")
    grid = html.Div([left, right], style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit, minmax(420px, 1fr))", "gap": "14px", "marginBottom": "14px"})
    if vs.empty:
        return grid
    head = ["Broker", "Bid hit MW", "Offer lifted MW", "Bid share", "Avg clip (bid)", "Big-clip bid MW", "Big-clip offer MW", "Bid vs screen", "Offer vs screen"]
    by = {(r.venue, r.resting): r for r in vs.itertuples(index=False)}
    venues = sorted({r.venue for r in vs.itertuples(index=False)},
                    key=lambda v: -(getattr(by.get((v, "bid")), "mw", 0) + getattr(by.get((v, "offer")), "mw", 0)))
    rows = []
    for v in venues:
        b, o = by.get((v, "bid")), by.get((v, "offer"))
        bm, om = getattr(b, "mw", 0.0), getattr(o, "mw", 0.0)
        rows.append(html.Tr([
            html.Td(v),
            html.Td(_mw(bm), style={"textAlign": "right"}),
            html.Td(_mw(om), style={"textAlign": "right"}),
            html.Td(f"{100*bm/(bm+om):.0f}%" if bm + om else "–", style={"textAlign": "right"}),
            html.Td(f"{b.avg_clip:.1f}" if b is not None else "–", style={"textAlign": "right"}),
            html.Td(_mw(getattr(b, "big_mw", 0.0)), style={"textAlign": "right"}),
            html.Td(_mw(getattr(o, "big_mw", 0.0)), style={"textAlign": "right"}),
            html.Td(f"{b.basis_med:+.2f}" if b is not None and pd.notna(b.basis_med) else "–", style={"textAlign": "right"}),
            html.Td(f"{o.basis_med:+.2f}" if o is not None and pd.notna(o.basis_med) else "–", style={"textAlign": "right"}),
        ]))
    table = _card(dbc.Table([html.Thead(html.Tr([html.Th(h) for h in head])), html.Tbody(rows)],
                            bordered=False, hover=True, size="sm", style={"fontSize": "12.5px"}),
                  "Broker summary, selected contracts, date range")
    return html.Div([grid, table])
