"""Plotly figure builders for the OTC Levels page (light dashboard theme)."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.theme import PLOTLY_TEMPLATE_NAME

from .constants import LADDER_STEP, VENUE_ORDER

BID = "#2a78d6"      # resting bid hit  -> buyer's level
OFFER = "#eb6834"    # resting offer lifted -> seller's level
SCREEN = "#6b7078"   # EEX
BAND = "rgba(107,112,120,0.14)"
LAST = "#231F20"
CFG = {"displaylogo": False, "displayModeBar": False}
MONO = "IBM Plex Mono, Consolas, monospace"


def _side_name(side: str) -> str:
    return "Bid hit (buyer's level)" if side == "bid" else "Offer lifted (seller's level)"


def fig_levels(eex_d: pd.DataFrame, big: pd.DataFrame, otc_d: pd.DataFrame,
               contract: str, last_px: float | None, big_clip: float) -> go.Figure:
    """EEX daily VWAP + range, big OTC prints, daily OTC MW by side."""
    e = eex_d[eex_d["contract"] == contract].sort_values("date")
    b = big[big["contract"] == contract]
    d = otc_d[otc_d["contract"] == contract].sort_values("date") if not otc_d.empty else otc_d

    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.72, 0.28], vertical_spacing=0.04)
    if not e.empty:
        fig.add_trace(go.Scatter(x=e["date"], y=e["high"], mode="lines", line=dict(width=0), hoverinfo="skip", showlegend=False), 1, 1)
        fig.add_trace(go.Scatter(x=e["date"], y=e["low"], mode="lines", line=dict(width=0), fill="tonexty", fillcolor=BAND, hoverinfo="skip", showlegend=False), 1, 1)
        fig.add_trace(go.Scatter(
            x=e["date"], y=e["vwap"], mode="lines", name="EEX daily VWAP", line=dict(color=SCREEN, width=1.6),
            customdata=np.c_[e["low"], e["high"], e["mw"]],
            hovertemplate="%{x|%d %b}<br>VWAP %{y:.2f} (%{customdata[0]:.2f}–%{customdata[1]:.2f})<br>%{customdata[2]:.0f} MW on screen<extra></extra>",
        ), 1, 1)
    for side, col in (("bid", BID), ("offer", OFFER)):
        g = b[b["resting"] == side]
        basis_txt = g["basis"].map(lambda v: "" if pd.isna(v) else f"{v:+.2f} vs screen")
        fig.add_trace(go.Scatter(
            x=g["t_local"].dt.tz_localize(None), y=g["PRICE"], mode="markers", name=f"{_side_name(side)} ≥ {big_clip:g} MW",
            marker=dict(color=col, size=np.maximum(8, 3.2 * np.sqrt(g["QUANTITY"])), opacity=0.85, line=dict(color="#ffffff", width=1.2)),
            customdata=np.c_[g["venue"], g["QUANTITY"], basis_txt],
            hovertemplate="%{x|%d %b %H:%M}<br>%{y:.2f} €/MWh · %{customdata[1]:.0f} MW · %{customdata[0]}<br>%{customdata[2]}<extra></extra>",
        ), 1, 1)
    if last_px is not None:
        fig.add_hline(y=last_px, line=dict(color=LAST, width=1, dash="dot"), row=1, col=1,
                      annotation_text=f"last {last_px:.2f}", annotation_position="top left",
                      annotation_font=dict(size=11, color=LAST))
    if not d.empty:
        fig.add_trace(go.Bar(x=d["date"], y=d["bid_mw"], name="OTC MW bids hit", marker_color=BID,
                             hovertemplate="%{x|%d %b}<br>%{y:.0f} MW bids hit<extra></extra>"), 2, 1)
        fig.add_trace(go.Bar(x=d["date"], y=-d["offer_mw"], name="OTC MW offers lifted", marker_color=OFFER,
                             customdata=d["offer_mw"], hovertemplate="%{x|%d %b}<br>%{customdata:.0f} MW offers lifted<extra></extra>"), 2, 1)
    fig.update_layout(
        template=PLOTLY_TEMPLATE_NAME, height=460, barmode="relative", bargap=0.15,
        margin=dict(l=56, r=20, t=40, b=30), hovermode="closest",
        legend=dict(orientation="h", y=1.08, x=0, font=dict(size=11)),
        title=dict(text=f"{contract}", x=0.0, xanchor="left", font=dict(size=14)),
    )
    fig.update_yaxes(title_text="€/MWh", row=1, col=1, tickfont=dict(family=MONO, size=11))
    fig.update_yaxes(title_text="MW / day", row=2, col=1, zeroline=True, zerolinecolor="#9aa0a6", tickfont=dict(family=MONO, size=11))
    fig.update_xaxes(tickfont=dict(family=MONO, size=11))
    return fig


def fig_ladder(lad: pd.DataFrame, contract: str, last_px: float | None, step: float = LADDER_STEP) -> go.Figure:
    """Diverging horizontal bars: bids hit to the left, offers lifted to the right, per price bucket."""
    l = lad[lad["contract"] == contract]
    fig = go.Figure()
    if l.empty:
        fig.update_layout(template=PLOTLY_TEMPLATE_NAME, height=420, title=dict(text=f"{contract} · no prints ≥ threshold", font=dict(size=13)))
        return fig
    lo, hi = l["bucket"].min(), l["bucket"].max()
    if last_px is not None:
        lo, hi = min(lo, np.floor(last_px / step) * step), max(hi, np.floor(last_px / step) * step)
    buckets = np.arange(lo, hi + step, step)
    y = buckets + step / 2

    def series(side):
        s = l[l["resting"] == side].set_index("bucket")
        return np.array([s["mw"].get(b, 0.0) for b in buckets]), np.array([s["n"].get(b, 0) for b in buckets])

    bid_mw, bid_n = series("bid")
    off_mw, off_n = series("offer")
    maxv = max(bid_mw.max(), off_mw.max(), 1.0)
    labels = [f"{b:.0f}–{b + step:.0f}" for b in buckets]
    fig.add_trace(go.Bar(y=y, x=-bid_mw, orientation="h", name="Bids hit", marker_color=BID, width=step * 0.85,
                         customdata=np.c_[labels, bid_mw, bid_n],
                         hovertemplate="%{customdata[0]} €/MWh<br>%{customdata[1]:.0f} MW in %{customdata[2]} prints, bids hit<extra></extra>"))
    fig.add_trace(go.Bar(y=y, x=off_mw, orientation="h", name="Offers lifted", marker_color=OFFER, width=step * 0.85,
                         customdata=np.c_[labels, off_mw, off_n],
                         hovertemplate="%{customdata[0]} €/MWh<br>%{customdata[1]:.0f} MW in %{customdata[2]} prints, offers lifted<extra></extra>"))
    if last_px is not None:
        fig.add_hline(y=last_px, line=dict(color=LAST, width=1.2, dash="dot"),
                      annotation_text=f"last {last_px:.2f}", annotation_position="top right",
                      annotation_font=dict(size=11, color=LAST))
    ticks = [-maxv, -maxv / 2, 0, maxv / 2, maxv]
    fig.update_layout(
        template=PLOTLY_TEMPLATE_NAME, height=max(360, min(720, 40 + 22 * len(buckets))),
        barmode="relative", bargap=0.1, margin=dict(l=56, r=20, t=40, b=36),
        legend=dict(orientation="h", y=1.06, x=0, font=dict(size=11)),
        title=dict(text=contract, x=0.0, xanchor="left", font=dict(size=14)),
        xaxis=dict(title="MW", tickvals=ticks, ticktext=[f"{abs(t):.0f}" for t in ticks], range=[-maxv * 1.15, maxv * 1.15], tickfont=dict(family=MONO, size=11)),
        yaxis=dict(title="€/MWh", tickfont=dict(family=MONO, size=11), dtick=max(step, round((hi - lo) / 12 / step) * step or step)),
    )
    return fig


def fig_venues(vs: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    if vs.empty:
        fig.update_layout(template=PLOTLY_TEMPLATE_NAME, height=300)
        return fig
    order = [v for v in VENUE_ORDER if v in set(vs["venue"])]
    tot = vs.groupby("venue")["mw"].sum()
    order = sorted(order, key=lambda v: -tot.get(v, 0))
    for side, col in (("bid", BID), ("offer", OFFER)):
        s = vs[vs["resting"] == side].set_index("venue")
        fig.add_trace(go.Bar(
            y=order, x=[s["mw"].get(v, 0.0) for v in order], orientation="h", name=_side_name(side), marker_color=col,
            customdata=[[s["avg_clip"].get(v, np.nan), s["big_mw"].get(v, 0.0)] for v in order],
            hovertemplate="%{y}<br>%{x:.0f} MW · avg clip %{customdata[0]:.1f} MW · %{customdata[1]:.0f} MW in big clips<extra></extra>",
        ))
    fig.update_layout(template=PLOTLY_TEMPLATE_NAME, height=max(260, 60 + 34 * len(order)), barmode="group", bargap=0.3,
                      margin=dict(l=56, r=20, t=30, b=36), legend=dict(orientation="h", y=1.08, x=0, font=dict(size=11)),
                      xaxis=dict(title="MW in window", tickfont=dict(family=MONO, size=11)),
                      yaxis=dict(autorange="reversed", tickfont=dict(family=MONO, size=12)))
    return fig


def fig_hours(h: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    hrs = list(range(7, 19))
    for side, col in (("bid", BID), ("offer", OFFER)):
        s = h[h["resting"] == side].set_index("hour")["mw"] if not h.empty else pd.Series(dtype=float)
        fig.add_trace(go.Bar(x=[f"{x:02d}:00" for x in hrs], y=[s.get(x, 0.0) for x in hrs], name=_side_name(side), marker_color=col,
                             hovertemplate="%{x} Paris<br>%{y:.0f} MW<extra></extra>"))
    fig.update_layout(template=PLOTLY_TEMPLATE_NAME, height=280, barmode="group", bargap=0.25,
                      margin=dict(l=56, r=20, t=30, b=36), legend=dict(orientation="h", y=1.1, x=0, font=dict(size=11)),
                      yaxis=dict(title="MW", tickfont=dict(family=MONO, size=11)), xaxis=dict(tickfont=dict(family=MONO, size=11)))
    return fig
