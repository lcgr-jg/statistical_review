"""Snowflake / Trayport fetch for the OTC Levels tab, cached in ``DashboardCache``.

One query per (market, shape, window): outright prints of Years and Quarters
whose delivery has not started, market scope only (so EEX trades are not
double counted via the ``EEX <market> Anon`` instrument-scope rows).
"""
from __future__ import annotations

import hashlib
import logging
from datetime import date, datetime, timedelta

import pandas as pd

from core.cache import dashboard_cache

from .constants import (
    CACHE_PREFIX,
    CACHE_TTL_HISTORICAL,
    CACHE_TTL_LIVE,
    SHAPE_TO_MARKET_SUFFIX,
)

logger = logging.getLogger(__name__)

_SQL = """
SELECT
    d.TRADE_ID,
    d.DEAL_TIME_UTC,
    d.PRICE,
    d.QUANTITY,
    d.VENUE_CODE,
    d.AGGRESSOR_BUY,
    d.FROM_BROKEN_SPREAD,
    d.CONTRACT_TYPE,
    s.SEQUENCE_DISPLAY_NAME AS TENOR_FAMILY,
    si.SEQUENCE_ITEM_NAME   AS TENOR_NAME,
    si.PERIOD_START_UTC     AS DELIVERY_START,
    si.PERIOD_END_UTC       AS DELIVERY_END
FROM MARKET_DATA.TRADES d
JOIN REF_MARKETS.MARKETS m         ON d.MARKET_ID = m.MARKET_ID
JOIN REF_MARKETS.SEQUENCES s       ON d.MARKET_ID = s.MARKET_ID AND d.SEQUENCE_ID = s.SEQUENCE_ID
JOIN REF_MARKETS.SEQUENCE_ITEMS si ON d.MARKET_ID = si.MARKET_ID AND d.SEQUENCE_ID = si.SEQUENCE_ID
                                   AND d.SEQUENCE_ITEM_ID = si.SEQUENCE_ITEM_ID
WHERE m.MARKET_NAME = '{market}'
  AND d.SCOPE = 'market'
  AND d.CONTRACT_TYPE = 'SinglePeriod'
  AND s.SEQUENCE_DISPLAY_NAME IN ('Years', 'Quarters')
  AND si.PERIOD_START_UTC >= '{min_delivery}'
  AND d.DEAL_TIME_UTC >= '{start}'
  AND d.DEAL_TIME_UTC <  '{end}'
ORDER BY d.DEAL_TIME_UTC
"""


def market_name(zone: str, shape: str) -> str:
    """UI labels -> Trayport market name, e.g. ('France', 'Baseload') -> 'France Baseload'."""
    from jain_commods.core.interfaces.snowflake.trayportquery import ZONE_TO_MARKET_NAME  # type: ignore

    return f"{ZONE_TO_MARKET_NAME.get(zone, zone)} {SHAPE_TO_MARKET_SUFFIX.get(shape, shape)}"


def _key(**kw) -> str:
    raw = "|".join(f"{k}={v}" for k, v in sorted(kw.items()))
    return f"{CACHE_PREFIX}:{hashlib.md5(raw.encode()).hexdigest()[:16]}"


def _as_date(v) -> date:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    return pd.Timestamp(v).date()


def fetch_trades(
    zone: str,
    shape: str,
    start_date,
    end_date=None,
    force_refresh: bool = False,
) -> pd.DataFrame:
    """Return the raw outright tape for ``zone``/``shape`` between two dates (inclusive)."""
    end_date = _as_date(end_date) if end_date else date.today()
    start_date = _as_date(start_date)
    market = market_name(zone, shape)
    is_live = end_date >= date.today()
    ttl = CACHE_TTL_LIVE if is_live else CACHE_TTL_HISTORICAL
    key = _key(market=market, start=start_date.isoformat(), end=end_date.isoformat())

    if not force_refresh:
        cached = dashboard_cache.get(key, ttl=ttl)
        if cached is not None:
            logger.info("[otc_levels] cache hit %s (%d rows)", market, len(cached))
            return cached

    from jain_commods.core.interfaces.snowflake.trayportquery import TrayportQuery  # type: ignore

    sql = _SQL.format(
        market=market.replace("'", "''"),
        min_delivery=end_date.replace(day=1).isoformat(),
        start=start_date.isoformat(),
        end=(end_date + timedelta(days=1)).isoformat(),
    )
    logger.info("[otc_levels] querying %s %s..%s", market, start_date, end_date)
    tq = TrayportQuery()
    df = pd.read_sql(sql, tq._conn)
    df.columns = [c.upper() for c in df.columns]
    df["DEAL_TIME_UTC"] = pd.to_datetime(df["DEAL_TIME_UTC"])
    for c in ("PRICE", "QUANTITY"):
        df[c] = df[c].astype(float)
    for c in ("AGGRESSOR_BUY", "FROM_BROKEN_SPREAD"):
        df[c] = df[c].fillna(False).astype(bool)
    df["MARKET_NAME"] = market
    logger.info("[otc_levels] %d rows", len(df))
    dashboard_cache.set(key, df, ttl=ttl)
    return df


def fetched_at_text(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "no prints"
    last = pd.to_datetime(df["DEAL_TIME_UTC"]).max()
    return f"{len(df):,} prints · last {last.strftime('%d %b %H:%M')} UTC"


__all__ = ["fetch_trades", "market_name", "fetched_at_text"]
