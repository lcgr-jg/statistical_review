"""OTC Levels tab (Trade Data page): where resting broker bids/offers get filled on power forwards."""
