"""Layout for the TTF Low-Beta Spreads page."""
from __future__ import annotations

from dash import dcc, html
from dash.dash_table import DataTable

from core.bbg_spreads.highlights import DOD_MOVE_BG, DOD_Z_EXTREME
from core.styles import COLORS
from core.low_beta_spreads.components import (
    TABLE_COLUMNS,
    TABLE_HEADER_TOOLTIPS,
)
from core.low_beta_spreads.constants import (
    CRISIS_YEARS,
    DEFAULT_MIN_Z,
    DEFAULT_REG_WINDOW,
    MIN_Z_OPTIONS,
    REG_WINDOW_OPTIONS,
    SPREAD_TYPES,
)

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "hidden",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 12px 0",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}

_OPTION_BLOCK = {"minWidth": "220px"}

_RADIO_STYLE = {"fontSize": "13px", "color": COLORS["text_primary"]}
_RADIO_LABEL_STYLE = {"marginRight": "16px", "cursor": "pointer"}

_BTN_PRIMARY = {
    "padding": "8px 16px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
}

_CHART_BOX = {"flex": "1 1 420px", "minWidth": "380px"}


def _swatch(bg: str, text: str) -> html.Span:
    """Small inline sample of a table highlight colour."""
    return html.Span(
        text,
        style={
            "backgroundColor": bg,
            "fontWeight": "700",
            "padding": "1px 6px",
            "borderRadius": "3px",
        },
    )


def build_layout() -> html.Div:
    crisis_label = "\u2013".join(str(y % 100) for y in
                                 (CRISIS_YEARS[0], CRISIS_YEARS[-1]))
    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1500px"},
        children=[
            dcc.Store(id="lb-selected"),
            dcc.Store(id="lb-live-store"),

            html.Div(children=[
                html.H1(
                    "TTF Low-Beta Spreads",
                    style={
                        "fontSize": "22px",
                        "fontWeight": "600",
                        "color": COLORS["text_primary"],
                        "margin": "0 0 4px 0",
                    },
                ),
                html.P(
                    "TTF / JKM / TFU spreads (tenor pairs, flies, "
                    "spread-of-spreads, cross-hub bases) regressed against "
                    "front-month flat-price moves. Low |corr| + extreme z = "
                    "mispriced but immune to flat-price chop.",
                    style={
                        "fontSize": "13px",
                        "color": COLORS["text_muted"],
                        "margin": "0 0 4px 0",
                    },
                ),
                html.Div(
                    id="lb-status",
                    style={
                        "fontSize": "12px",
                        "color": COLORS["text_muted"],
                        "margin": "0 0 12px 0",
                    },
                ),
            ]),

            # ── Options panel ────────────────────────────────────────────
            html.Div(
                style={**_CONTENT_PANEL,
                       "display": "flex", "flexWrap": "wrap",
                       "gap": "28px", "alignItems": "flex-start"},
                children=[
                    html.Div(style=_OPTION_BLOCK, children=[
                        html.Label("Regression window", style=_LABEL),
                        dcc.RadioItems(
                            id="lb-window",
                            options=REG_WINDOW_OPTIONS,
                            value=DEFAULT_REG_WINDOW,
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                    ]),
                    html.Div(style=_OPTION_BLOCK, children=[
                        html.Label("Min mispricing", style=_LABEL),
                        dcc.RadioItems(
                            id="lb-minz",
                            options=MIN_Z_OPTIONS,
                            value=DEFAULT_MIN_Z,
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                    ]),
                    html.Div(style=_OPTION_BLOCK, children=[
                        html.Label(
                            f"Energy-crisis years (20{crisis_label})",
                            style=_LABEL,
                        ),
                        dcc.RadioItems(
                            id="lb-crisis",
                            options=[
                                {"label": "Excluded from z stats", "value": "exclude"},
                                {"label": "Included in z stats", "value": "include"},
                            ],
                            value="exclude",
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                    ]),
                    html.Div(style={"minWidth": "420px"}, children=[
                        html.Label("Spread types", style=_LABEL),
                        dcc.Checklist(
                            id="lb-types",
                            options=[{"label": t, "value": t} for t in SPREAD_TYPES],
                            value=list(SPREAD_TYPES),
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                    ]),
                    html.Div(style=_OPTION_BLOCK, children=[
                        html.Label("Price source", style=_LABEL),
                        dcc.RadioItems(
                            id="lb-price-source",
                            options=[
                                {"label": "ICE settlement", "value": "settle"},
                                {"label": "Bloomberg live", "value": "live"},
                            ],
                            value="settle",
                            style=_RADIO_STYLE,
                            labelStyle=_RADIO_LABEL_STYLE,
                            inline=True,
                        ),
                        html.Div(
                            style={"marginTop": "10px"},
                            children=html.Button(
                                "Fetch live prices",
                                id="lb-fetch-live",
                                n_clicks=0,
                                title="Query Bloomberg BPIPE for the latest "
                                      "intraday marks and recompute z / %ile",
                                style=_BTN_PRIMARY,
                            ),
                        ),
                    ]),
                ],
            ),

            # ── Bloomberg live query time (prominent when live selected) ─
            html.Div(id="lb-live-banner"),

            # ── Headline scatter ─────────────────────────────────────────
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Flat-price dependence vs mispricing", style=_PANEL_TITLE),
                    html.P(
                        "Each point is one monitored spread. The top-left "
                        "quadrant (low |corr| to the front month, extreme |z|) "
                        "holds the trades that are rich or cheap without being "
                        "a disguised flat-price position. Click a point (or a "
                        "table row below) to drill into it.",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "margin": "0 0 6px 0",
                        },
                    ),
                    dcc.Loading(
                        type="circle",
                        children=dcc.Graph(
                            id="lb-scatter",
                            config={"displayModeBar": True, "displaylogo": False},
                            style={"height": "440px"},
                        ),
                    ),
                ],
            ),

            # ── Full spreads table ───────────────────────────────────────
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("All monitored spreads", style=_PANEL_TITLE),
                    html.P(
                        "Sorted by |corr| ascending — the most flat-price-"
                        "independent spreads first. β is in native units "
                        "(EUR spreads vs TTF FM in €/MWh, USD spreads vs TFU "
                        "FM in $/mmbtu); corr is unit-free and comparable "
                        "across the board.",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "margin": "0 0 6px 0",
                        },
                    ),
                    html.P(
                        children=[
                            "Bloomberg live mode: ",
                            _swatch(DOD_MOVE_BG, "amber"),
                            f" on Δ vs settle / Δ z when the intraday move "
                            f"vs the last ICE settle is outsized "
                            f"(|Δ z| ≥ {DOD_Z_EXTREME:g} vs that spread's own "
                            "daily-change history). The orange banner above "
                            "shows when BPIPE was last queried.",
                        ],
                        style={
                            "fontSize": "12px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 14px 0",
                        },
                    ),
                    dcc.Loading(
                        type="circle",
                        children=DataTable(
                            id="lb-table",
                            columns=TABLE_COLUMNS,
                            data=[],
                            sort_action="native",
                            cell_selectable=True,
                            tooltip_header=TABLE_HEADER_TOOLTIPS,
                            tooltip_delay=400,
                            tooltip_duration=None,
                            page_size=25,
                            style_as_list_view=True,
                            style_table={"overflowX": "auto"},
                            style_header={
                                "backgroundColor": COLORS["card_bg"],
                                "color": COLORS["text_muted"],
                                "fontWeight": "600",
                                "fontSize": "12px",
                                "borderBottom": f"1px solid {COLORS['border']}",
                            },
                            style_cell={
                                "fontFamily": (
                                    '-apple-system, BlinkMacSystemFont, '
                                    '"Segoe UI", Roboto, sans-serif'
                                ),
                                "fontSize": "13px",
                                "padding": "8px 10px",
                                "textAlign": "center",
                                "border": "none",
                            },
                            style_data={
                                "borderBottom": f"1px solid {COLORS['border_light']}",
                                "cursor": "pointer",
                            },
                        ),
                    ),
                ],
            ),

            # ── Selected-spread drilldown ────────────────────────────────
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.H3("Selected spread", style=_PANEL_TITLE),
                    html.Div(
                        style={
                            "display": "flex",
                            "flexWrap": "wrap",
                            "gap": "20px",
                            "alignItems": "stretch",
                        },
                        children=[
                            html.Div(
                                style={"flex": "2 1 620px", "minWidth": "480px"},
                                children=dcc.Loading(
                                    type="circle",
                                    children=dcc.Graph(
                                        id="lb-history-chart",
                                        config={"displayModeBar": True,
                                                "displaylogo": False},
                                        style={"height": "400px"},
                                    ),
                                ),
                            ),
                            html.Div(
                                style=_CHART_BOX,
                                children=dcc.Loading(
                                    type="circle",
                                    children=dcc.Graph(
                                        id="lb-beta-chart",
                                        config={"displayModeBar": True,
                                                "displaylogo": False},
                                        style={"height": "400px"},
                                    ),
                                ),
                            ),
                            html.Div(
                                style=_CHART_BOX,
                                children=dcc.Loading(
                                    type="circle",
                                    children=dcc.Graph(
                                        id="lb-reg-chart",
                                        config={"displayModeBar": True,
                                                "displaylogo": False},
                                        style={"height": "400px"},
                                    ),
                                ),
                            ),
                        ],
                    ),
                ],
            ),

            # ── Methodology footnote ─────────────────────────────────────
            html.Div(
                id="lb-footnote",
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "lineHeight": "1.6",
                },
            ),
        ],
    )
