"""Dash callbacks for the TTF Low-Beta Spreads page.

Settlement statistics are recomputed in-process from the cached per-spread
change series.  Bloomberg live marks are fetched on demand and overlay only
the level stats (z / %ile / DoD); β / corr stay settlement-based.
Selection flows through the ``lb-selected`` store so both the scatter and
the table can drive the drilldown.
"""
from __future__ import annotations

import logging

import pandas as pd
from dash import Input, Output, State, callback, ctx, html, no_update

from core.bbg_spreads.highlights import (
    build_live_banner,
    mark_date_from_store,
    top_dod_movers,
)
from core.bbg_spreads.snapshot import fetch_live_marks
from core.bbg_spreads.stats import overlay_live_marks_low_beta
from core.bbg_spreads.tickers import (
    build_low_beta_requests,
    fm_outright_tickers,
    outright_ticker,
)
from core.data import get_low_beta_spreads
from core.low_beta_spreads.charts import (
    build_empty_chart,
    build_history_chart,
    build_regression_chart,
    build_rolling_beta_chart,
    build_scatter_chart,
)
from core.low_beta_spreads.components import (
    build_table_records,
    build_table_styles,
    table_columns,
)
from core.low_beta_spreads.constants import CRISIS_YEARS
from core.low_beta_spreads.data import compute_stats, find_history

logger = logging.getLogger(__name__)

_NO_DATA_MSG = (
    "Low-beta spreads data is not loaded yet — the cache warms in the "
    "background shortly after start-up. Refresh the page in a minute."
)


def _crisis_note(exclude_crisis: bool) -> str:
    years = ", ".join(str(y) for y in CRISIS_YEARS)
    return (f"Energy-crisis years ({years}) excluded from the z/percentile "
            f"history."
            if exclude_crisis
            else f"Energy-crisis years ({years}) included in the z/percentile "
                 f"history.")


def _resolve_selection(records: list[dict], active_cell, click_data,
                       previous: str | None) -> str | None:
    """Pick the selected spread key from whichever input fired last."""
    trigger = ctx.triggered_id
    key = None
    if trigger == "lb-scatter" and click_data:
        try:
            key = click_data["points"][0]["customdata"][0]
        except (KeyError, IndexError, TypeError):
            key = None
    elif trigger == "lb-table" and active_cell:
        key = active_cell.get("row_id")

    valid = {rec["id"] for rec in records}
    if key not in valid:
        key = previous if previous in valid else None
    if key is None and records:
        key = records[0]["id"]
    return key


@callback(
    Output("lb-live-store", "data"),
    Input("lb-fetch-live", "n_clicks"),
    prevent_initial_call=True,
)
def fetch_lb_live_prices(n_clicks):
    if not n_clicks:
        return no_update

    payload = get_low_beta_spreads()
    if payload is None:
        return {"marks": {}, "error": _NO_DATA_MSG, "fetched_at": None}

    try:
        requests = build_low_beta_requests(
            payload["histories"], payload["as_of"])
        extra = fm_outright_tickers(
            payload["as_of"], include_usd=bool(payload.get("has_usd")))
        return fetch_live_marks(requests, extra_tickers=extra)
    except Exception as exc:
        logger.exception("Low-beta live fetch failed: %s", exc)
        return {
            "marks": {},
            "error": f"Live fetch failed: {exc}",
            "fetched_at": None,
        }


@callback(
    Output("lb-scatter", "figure"),
    Output("lb-table", "data"),
    Output("lb-table", "columns"),
    Output("lb-table", "style_data_conditional"),
    Output("lb-selected", "data"),
    Output("lb-status", "children"),
    Output("lb-live-banner", "children"),
    Output("lb-footnote", "children"),
    Input("lb-crisis", "value"),
    Input("lb-window", "value"),
    Input("lb-types", "value"),
    Input("lb-minz", "value"),
    Input("lb-price-source", "value"),
    Input("lb-live-store", "data"),
    Input("lb-table", "active_cell"),
    Input("lb-scatter", "clickData"),
    State("lb-selected", "data"),
)
def update_overview(crisis_value, window, spread_types, min_z,
                    price_source, live_store,
                    active_cell, click_data, previous_key):
    exclude_crisis = crisis_value != "include"
    want_live = price_source == "live"

    payload = get_low_beta_spreads()
    if payload is None:
        empty = build_empty_chart(_NO_DATA_MSG)
        return (empty, [], table_columns(False), [], None, _NO_DATA_MSG,
                build_live_banner(price_source, live_store, live_mode=False), "")

    try:
        res = compute_stats(payload, exclude_crisis=exclude_crisis,
                            window=window)
    except Exception as exc:
        logger.exception("Low-beta spreads stats recompute failed: %s", exc)
        empty = build_empty_chart(f"Failed to compute statistics: {exc}")
        return (empty, [], table_columns(False), [], None, "",
                build_live_banner(price_source, live_store, live_mode=False), "")

    live_mode = False
    live_note = ""
    if want_live:
        marks = (live_store or {}).get("marks") or {}
        err = (live_store or {}).get("error")
        if marks:
            res = overlay_live_marks_low_beta(
                res, payload["histories"], payload["as_of"], marks,
                exclude_crisis=exclude_crisis,
                crisis_years=CRISIS_YEARS,
            )
            live_mode = True
            movers = top_dod_movers(res, n=3)
            if movers:
                live_note = " · outsized: " + "; ".join(movers)
        elif err:
            live_note = " · Live fetch error (showing ICE settles)"

    n_universe = len(res)
    if spread_types:
        res = res[res["spread_type"].isin(spread_types)]
    if min_z:
        res = res[res["absz"] >= float(min_z)]

    records = build_table_records(res, live_mode=live_mode)
    columns = table_columns(live_mode)
    selected_key = _resolve_selection(records, active_cell, click_data,
                                      previous_key)
    styles = build_table_styles(records, selected_key=selected_key)
    fig_scatter = build_scatter_chart(res, selected_key=selected_key)
    banner = build_live_banner(price_source, live_store, live_mode=live_mode)

    as_of = pd.Timestamp(payload["as_of"])
    n_candidates = int(((res["abs_corr"] < 0.3) & (res["absz"] >= 1.5)).sum()) \
        if not res.empty else 0
    n_dod = int(res["dod_extreme"].sum()) if (
        live_mode and not res.empty and "dod_extreme" in res.columns) else 0
    usd_note = "" if payload.get("has_usd") else \
        " · JKM/TFU unavailable (TTF-only universe)"
    status = (
        f"Settles as of {as_of:%d %b %Y} · {len(res)} of {n_universe} "
        f"spreads shown · {n_candidates} mispriced + flat-price-immune "
        f"(|corr| < 0.3 and |z| ≥ 1.5)"
        + (f" · {n_dod} outsized Δ vs settle" if live_mode else "")
        + usd_note
        + live_note
    )

    data_start = pd.Timestamp(payload["data_start"])
    footnote_lines = [
        ("β / corr / R²: OLS of the spread's roll-adjusted daily changes on "
         "roll-adjusted front-month daily changes over the last "
         f"{window} joined trading days (EUR spreads vs TTF FM, USD spreads "
         "vs TFU FM = TTF in $/mmbtu). Always from ICE settlements."),
        ("Daily changes are computed within the contracts selected on each "
         "date (settle minus the same contracts' previous settle), so "
         "generic rolls never contaminate the regressions."),
        ("z / %ile: latest level vs the spread's own rolling generic "
         "history (front legs keyed on seasonal label + year rank per trade "
         "date). " + _crisis_note(exclude_crisis)),
        ("Live mode: Bloomberg mid/last overlays the settle for z / %ile; "
         "Δ vs settle = live − last ICE print; |Δz| ≥ 1.5 amber-highlighted. "
         "Pairs use native calendar tickers where possible; flies / SoS / "
         "basis are implied from outrights."
         if live_mode else
         (f"Settlement data {data_start:%d %b %Y} – {as_of:%d %b %Y} "
          f"({payload['n_trade_dates']:,} trading days). USD structures start "
          "where JKM/TFU liquidity allows; rows need enough joined "
          "observations inside the regression window to qualify.")),
    ]
    footnote = [html.Div(line) for line in footnote_lines]

    return (fig_scatter, records, columns, styles, selected_key,
            status, banner, footnote)


@callback(
    Output("lb-history-chart", "figure"),
    Output("lb-beta-chart", "figure"),
    Output("lb-reg-chart", "figure"),
    Input("lb-selected", "data"),
    Input("lb-crisis", "value"),
    Input("lb-window", "value"),
    Input("lb-price-source", "value"),
    Input("lb-live-store", "data"),
)
def update_drilldown(selected_key, crisis_value, window,
                     price_source, live_store):
    exclude_crisis = crisis_value != "include"

    payload = get_low_beta_spreads()
    if payload is None or not selected_key:
        empty = build_empty_chart(_NO_DATA_MSG)
        return empty, empty, empty

    entry = find_history(payload, selected_key)
    if entry is None:
        empty = build_empty_chart("Spread not found in the cached history.")
        return empty, empty, empty

    fm_block = payload["fm"].get(entry["currency"])
    if fm_block is None:
        empty = build_empty_chart("No front-month series for this currency.")
        return empty, empty, empty
    fm_change = fm_block["change"]

    as_of = pd.Timestamp(payload["as_of"])
    live_mark = None
    mark_date = None
    fm_live = None
    if price_source == "live" and live_store and live_store.get("marks"):
        live_mark = live_store["marks"].get(selected_key)
        if live_mark is not None:
            mark_date = mark_date_from_store(live_store)
            prices = live_store.get("prices") or {}
            product = "TTF" if entry["currency"] == "EUR" else "TFU"
            # Front month on the settle as-of date (same convention as the
            # low-beta universe builder).
            import calendar
            m0 = pd.Period(as_of, freq="M")
            fm_label = calendar.month_abbr[(m0 + 1).month]
            fm_year = int((m0 + 1).year)
            fm_ticker = outright_ticker(product, fm_label, fm_year)
            if fm_ticker:
                fm_live = prices.get(fm_ticker)

    fm_level = fm_block.get("level")

    fig_hist = build_history_chart(
        entry, exclude_crisis=exclude_crisis, live_date=as_of,
        live_mark=live_mark, mark_date=mark_date,
    )
    fig_beta = build_rolling_beta_chart(entry, fm_change, window)
    fig_reg = build_regression_chart(
        entry, fm_change, window,
        live_mark=live_mark, mark_date=mark_date,
        fm_level=fm_level, fm_live=fm_live,
    )
    return fig_hist, fig_beta, fig_reg
