"""Data loading + stats recomputation for the TTF Low-Beta Spreads page.

``load_low_beta_spreads_data`` is the scheduler loader: it does the expensive
work (Snowflake fetches for TTF / JKM / TFU + spread-universe construction)
once per refresh and returns a picklable payload for ``dashboard_cache``.
Callbacks then recompute the statistics (z / percentile + FM regressions)
from the cached per-spread change series under user-selected options via
``compute_stats`` -- pure pandas over ~180 series, effectively instant.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Optional

import pandas as pd

from core.data_freshness import tracker
from core.low_beta_spreads.constants import (
    CRISIS_YEARS,
    DEFAULT_EXCLUDE_CRISIS,
    DEFAULT_REG_WINDOW,
    FRESHNESS_EXPECTED_MINUTES,
    FRESHNESS_SOURCE_NAME,
    HISTORY_YEARS,
)

logger = logging.getLogger(__name__)


def load_low_beta_spreads_data() -> dict[str, Any]:
    """Loader for ``dashboard_cache.register_source('low_beta_spreads_data', ...)``.

    Returns a picklable dict::

        {
            "fetched_at": "<ISO UTC>",
            "as_of": Timestamp,          # latest TTF settle date
            "data_start": Timestamp,     # first trade date in the history
            "n_trade_dates": int,
            "history_years": int,
            "has_usd": bool,             # JKM/TFU legs available
            "fm": {                      # front-month regressor series
                "EUR": {"level": Series, "change": Series},   # TTF FM
                "USD": {"level": Series, "change": Series},   # TFU FM
            },
            "histories": [               # one entry per monitored spread
                {key, spread_type, cadence, currency, legs, legs_display,
                 anchor_label, rank, series: Series, changes: Series},
                ...
            ],
            "stats_default": DataFrame,  # default options, for first paint
        }
    """
    from jain_commods.core.analytics.spread_beta import (
        build_engines,
        build_front_month_history,
        build_low_beta_histories,
        build_low_beta_universe,
        compute_low_beta_stats,
    )
    from jain_commods.core.analytics.spreads import (
        INTERNAL_HISTORY_START,
        get_ice_settles,
    )
    from jain_commods.core.interfaces.snowflake import ICEFuturesQuery

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata={"state": "loading"},
    )

    today = datetime.now()
    start = today.replace(year=today.year - HISTORY_YEARS)

    # ── TTF settles (EUR legs + EUR FM regressor) ────────────────────────
    try:
        # Pre-2019 history (if the window ever reaches back that far) comes
        # from the immutable S3 snapshot; the dashboard host has no BPipe.
        df_ttf = get_ice_settles(start_date=start, backfill='snapshot')
    except Exception as exc:
        logger.warning(
            "Low-beta spreads: pre-2019 snapshot unavailable (%s); "
            "falling back to internal history from %s",
            exc, INTERNAL_HISTORY_START.date(),
        )
        df_ttf = get_ice_settles(
            start_date=max(start, INTERNAL_HISTORY_START), backfill=None)

    # ── JKM + TFU settles (USD legs + USD FM regressor) ──────────────────
    df_jkm = df_tfu = None
    try:
        ice = ICEFuturesQuery()
        df_usd = ice.get_strip_prices(product=['JKM', 'TFU'], start_date=start)
        if df_usd is not None and not df_usd.empty:
            df_jkm = df_usd[df_usd['COMMODITY'] == 'JKM']
            df_tfu = df_usd[df_usd['COMMODITY'] == 'TFU']
    except Exception as exc:
        logger.warning(
            "Low-beta spreads: JKM/TFU fetch failed (%s); "
            "continuing with the TTF-only universe", exc,
        )

    engines = build_engines({'TTF': df_ttf, 'JKM': df_jkm, 'TFU': df_tfu})
    if 'TTF' not in engines:
        raise RuntimeError("Low-beta spreads: no TTF settles loaded")
    has_usd = 'JKM' in engines and 'TFU' in engines

    fm = {'EUR': build_front_month_history(engines['TTF'])}
    if has_usd:
        fm['USD'] = build_front_month_history(engines['TFU'])

    live_date = engines['TTF'].live_date
    specs = build_low_beta_universe(live_date, include_usd=has_usd)
    histories = build_low_beta_histories(engines, specs)

    # Default stats so the first page paint needs no recomputation.
    stats_default = compute_low_beta_stats(
        histories, fm_changes(fm), live_date,
        window=DEFAULT_REG_WINDOW,
        exclude_crisis_years=DEFAULT_EXCLUDE_CRISIS,
        crisis_years=CRISIS_YEARS,
    )

    n_trade_dates = int(len(engines['TTF'].dates))
    payload = {
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "as_of": pd.Timestamp(live_date),
        "data_start": pd.Timestamp(engines['TTF'].dates.min()),
        "n_trade_dates": n_trade_dates,
        "history_years": HISTORY_YEARS,
        "has_usd": has_usd,
        "fm": fm,
        "histories": histories,
        "stats_default": stats_default,
    }

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata={
            "as_of": str(pd.Timestamp(live_date).date()),
            "spreads": len(histories),
            "usd_universe": has_usd,
            "trade_dates": n_trade_dates,
        },
    )

    logger.info(
        "Low-beta spreads loaded: %d spreads (USD universe: %s), "
        "%d trade dates, as of %s",
        len(histories), has_usd, n_trade_dates,
        pd.Timestamp(live_date).date(),
    )
    return payload


def fm_changes(fm: dict) -> dict[str, pd.Series]:
    """FM daily-change series per currency from the payload's ``fm`` block."""
    return {ccy: block["change"] for ccy, block in fm.items()}


def compute_stats(payload: dict,
                  exclude_crisis: bool = DEFAULT_EXCLUDE_CRISIS,
                  window: int = DEFAULT_REG_WINDOW) -> pd.DataFrame:
    """Recompute the stats table from cached histories under page options."""
    from jain_commods.core.analytics.spread_beta import compute_low_beta_stats

    stats_default = payload.get("stats_default")
    if (exclude_crisis == DEFAULT_EXCLUDE_CRISIS
            and window == DEFAULT_REG_WINDOW
            and stats_default is not None):
        return stats_default

    return compute_low_beta_stats(
        payload["histories"], fm_changes(payload["fm"]), payload["as_of"],
        window=window,
        exclude_crisis_years=exclude_crisis,
        crisis_years=CRISIS_YEARS,
    )


def find_history(payload: dict, key: str) -> Optional[dict]:
    """Look up one spread's history entry by its spec key."""
    for entry in payload["histories"]:
        if entry["key"] == key:
            return entry
    return None
