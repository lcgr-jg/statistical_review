"""Plotly figure builders for the TTF Low-Beta Spreads page."""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from core.styles import COLORS
from core.low_beta_spreads.constants import CRISIS_YEARS, TYPE_COLORS
from core.ttf_spreads.charts import (  # shared with the sibling page
    BAND_FILL,
    CHEAP_COLOR,
    MEAN_COLOR,
    RICH_COLOR,
    _HOVER_LAYOUT,
    _add_crisis_shading,
    build_empty_chart,
)

__all__ = [
    "build_empty_chart",
    "build_scatter_chart",
    "build_history_chart",
    "build_rolling_beta_chart",
    "build_regression_chart",
]

_UNITS = {"EUR": "\u20ac/MWh", "USD": "$/mmbtu"}


def _unit(entry_or_row) -> str:
    return _UNITS.get(entry_or_row["currency"], "")


# --------------------------------------------------------------------------- #
# Headline scatter: |corr to FM| vs |z|
# --------------------------------------------------------------------------- #

def build_scatter_chart(res: pd.DataFrame,
                        selected_key: Optional[str] = None) -> go.Figure:
    """|corr to FM| (x) vs |z| (y); the interesting trades sit top-left
    (mispriced and independent of flat price).  Click a point to select."""
    if res.empty:
        return build_empty_chart("No spreads pass the current filters.")

    fig = go.Figure()
    for spread_type, sub in res.groupby("spread_type", sort=False):
        fig.add_trace(go.Scatter(
            x=sub["abs_corr"], y=sub["absz"],
            mode="markers",
            name=spread_type,
            # dtype=object keeps floats as floats (np.stack on mixed str/float
            # columns would coerce everything to strings and break the
            # numeric hover formatting below).
            customdata=sub[["key", "legs", "z", "corr", "beta"]]
            .to_numpy(dtype=object),
            marker={
                "size": 9,
                "color": TYPE_COLORS.get(spread_type, COLORS["accent"]),
                "opacity": 0.75,
                "line": {"width": 0.5, "color": "#ffffff"},
            },
            hovertemplate=("%{customdata[1]}<br>"
                           "z %{customdata[2]:+.2f} · "
                           "corr %{customdata[3]:+.2f} · "
                           "β %{customdata[4]:+.3f}"
                           "<extra>" + spread_type + "</extra>"),
        ))

    if selected_key is not None:
        sel = res[res["key"] == selected_key]
        if not sel.empty:
            fig.add_trace(go.Scatter(
                x=sel["abs_corr"], y=sel["absz"],
                mode="markers",
                name="selected",
                showlegend=False,
                hoverinfo="skip",
                marker={"size": 16, "color": "rgba(0,0,0,0)",
                        "line": {"width": 2.5, "color": "#231F20"}},
            ))

    # Quadrant guides: |z| = 1.5 (extreme) and |corr| = 0.3 (low FM beta).
    fig.add_hline(y=1.5, line={"color": COLORS["text_muted"], "width": 1,
                               "dash": "dot"})
    fig.add_vline(x=0.3, line={"color": COLORS["text_muted"], "width": 1,
                               "dash": "dot"})
    fig.add_annotation(
        text="mispriced + flat-price-immune",
        xref="x", yref="y", x=0.02, y=res["absz"].max() * 1.02,
        xanchor="left", showarrow=False,
        font={"size": 10, "color": COLORS["text_muted"]},
    )

    fig.update_layout(
        xaxis_title="|corr| of daily changes vs front month",
        yaxis_title="|z| vs own history",
        xaxis={"range": [-0.02, 1.02]},
        height=420,
        margin={"l": 60, "r": 20, "t": 30, "b": 60},
        legend={"orientation": "h", "yanchor": "bottom", "y": 1.02,
                "xanchor": "left", "x": 0},
        clickmode="event",
    )
    return fig


# --------------------------------------------------------------------------- #
# Drilldown: spread history
# --------------------------------------------------------------------------- #

def build_history_chart(entry: dict,
                        exclude_crisis: bool,
                        live_date: pd.Timestamp,
                        live_mark: Optional[float] = None,
                        mark_date: Optional[pd.Timestamp] = None) -> go.Figure:
    """Rolling generic history with mean / 10-90 band and the live marker."""
    series = entry["series"].sort_index()
    unit = _unit(entry)

    hist = series
    if exclude_crisis:
        hist = hist[~hist.index.year.isin(CRISIS_YEARS)]

    settle = float(series.iloc[-1])
    settle_date = series.index[-1]
    mean = hist.mean()
    p10, p90 = hist.quantile(0.10), hist.quantile(0.90)

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=[series.index.min(), series.index.max()], y=[p90, p90],
        mode="lines", line={"width": 0}, hoverinfo="skip", showlegend=False,
    ))
    fig.add_trace(go.Scatter(
        x=[series.index.min(), series.index.max()], y=[p10, p10],
        mode="lines", line={"width": 0},
        fill="tonexty", fillcolor=BAND_FILL,
        name="10-90 %ile", hoverinfo="skip",
    ))

    fig.add_trace(go.Scatter(
        x=series.index, y=series.values,
        mode="lines",
        name=entry["legs_display"],
        line={"width": 1.4, "color": COLORS["accent"]},
        hovertemplate=(
            "<b>ICE history</b><br>"
            "%{x|%d %b %Y}<br>"
            "%{y:.3f} " + unit +
            "<extra></extra>"
        ),
    ))

    fig.add_hline(
        y=mean, line={"color": MEAN_COLOR, "width": 1, "dash": "dash"},
        annotation_text=f"mean {mean:.3f}",
        annotation_font={"size": 10, "color": MEAN_COLOR},
    )

    marker_color = RICH_COLOR if settle >= mean else CHEAP_COLOR
    fig.add_trace(go.Scatter(
        x=[settle_date], y=[settle],
        mode="markers",
        name=f"ICE {settle:.3f}",
        marker={"size": 10, "color": marker_color,
                "line": {"width": 1.5, "color": "#ffffff"}},
        hovertemplate=(
            f"<b>ICE settle</b><br>"
            f"{settle_date:%d %b %Y}<br>"
            f"%{{y:.3f}} {unit}"
            f"<extra></extra>"
        ),
    ))

    if live_mark is not None and not (isinstance(live_mark, float)
                                      and np.isnan(live_mark)):
        bbg_date = pd.Timestamp(mark_date).normalize() if mark_date is not None \
            else pd.Timestamp.now().normalize()
        fig.add_trace(go.Scatter(
            x=[bbg_date], y=[float(live_mark)],
            mode="markers",
            name=f"BBG {float(live_mark):.3f}",
            marker={"size": 12, "symbol": "diamond",
                    "color": "#e67e22",
                    "line": {"width": 1.5, "color": "#ffffff"}},
            hovertemplate=(
                f"<b>BBG live</b><br>"
                f"{bbg_date:%d %b %Y}<br>"
                f"%{{y:.3f}} {unit}"
                f"<extra></extra>"
            ),
        ))

    _add_crisis_shading(fig, series, excluded=exclude_crisis)

    fig.update_layout(
        title={
            "text": (f"{entry['spread_type']}  ·  {entry['legs_display']}"
                     "  ·  rolling generic history"),
            "font": {"size": 14},
        },
        yaxis_title=f"Spread ({unit})",
        height=400,
        margin={"l": 60, "r": 20, "t": 70, "b": 70},
        legend={"orientation": "h", "yanchor": "top", "y": -0.12,
                "xanchor": "left", "x": 0},
        **_HOVER_LAYOUT,
    )
    return fig


# --------------------------------------------------------------------------- #
# Drilldown: rolling beta / correlation
# --------------------------------------------------------------------------- #

def build_rolling_beta_chart(entry: dict,
                             fm_change: pd.Series,
                             window: int) -> go.Figure:
    """Rolling beta (left axis) + rolling correlation (right axis) vs FM."""
    from jain_commods.core.analytics.spread_beta import rolling_beta_series

    rb = rolling_beta_series(entry["changes"], fm_change, window).dropna(how="all")
    if rb.empty or rb["beta"].notna().sum() == 0:
        return build_empty_chart("Not enough joined observations for a "
                                 "rolling regression.")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=rb.index, y=rb["beta"],
        mode="lines", name=f"β ({window}d)",
        line={"width": 1.5, "color": COLORS["accent"]},
        hovertemplate="%{x|%d %b %Y}<br>β %{y:+.3f}<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=rb.index, y=rb["corr"],
        mode="lines", name=f"corr ({window}d)",
        yaxis="y2",
        line={"width": 1.2, "color": "#d29922", "dash": "dot"},
        hovertemplate="%{x|%d %b %Y}<br>corr %{y:+.2f}<extra></extra>",
    ))
    fig.add_hline(y=0, line={"color": COLORS["text_muted"], "width": 1})

    fig.update_layout(
        title={"text": f"Rolling {window}d regression vs front month",
               "font": {"size": 14}},
        yaxis={"title": "β (native units)"},
        yaxis2={"title": "corr", "overlaying": "y", "side": "right",
                "range": [-1, 1], "showgrid": False},
        height=400,
        margin={"l": 60, "r": 60, "t": 70, "b": 70},
        legend={"orientation": "h", "yanchor": "top", "y": -0.12,
                "xanchor": "left", "x": 0},
    )
    return fig


# --------------------------------------------------------------------------- #
# Drilldown: daily-change regression scatter
# --------------------------------------------------------------------------- #

_RECENT_DAYS = 7


def build_regression_chart(entry: dict,
                           fm_change: pd.Series,
                           window: int,
                           live_mark: Optional[float] = None,
                           mark_date: Optional[pd.Timestamp] = None,
                           fm_level: Optional[pd.Series] = None,
                           fm_live: Optional[float] = None) -> go.Figure:
    """Spread daily changes vs FM daily changes with the fitted OLS line.

    Emphasises the most recent ``_RECENT_DAYS`` observations and the latest
    ICE settle-day point (matching the history-chart ICE marker).  When a
    Bloomberg live mark is available, an orange diamond shows the intraday
    (ΔFM, Δspread) move vs the last ICE settles.
    """
    from jain_commods.core.analytics.spread_beta import (
        latest_regression,
        regression_sample,
    )

    sample = regression_sample(entry["changes"], fm_change, window)
    reg = latest_regression(entry["changes"], fm_change, window)
    if sample.empty or reg is None:
        return build_empty_chart("Not enough joined observations for a "
                                 "regression.")

    unit = _unit(entry)
    fm_unit = "\u20ac/MWh" if entry["currency"] == "EUR" else "$/mmbtu"
    fm_name = "TTF FM" if entry["currency"] == "EUR" else "TFU FM"

    n = len(sample)
    older = sample.iloc[:-_RECENT_DAYS] if n > _RECENT_DAYS else sample.iloc[0:0]
    recent = sample.iloc[-_RECENT_DAYS:] if n > 1 else sample
    # Latest ICE settle-day observation (last joined change).
    latest = sample.iloc[[-1]]
    # Recent window excluding the latest point (avoid double-drawing).
    recent_rest = recent.iloc[:-1] if len(recent) > 1 else recent.iloc[0:0]

    fig = go.Figure()

    if not older.empty:
        fig.add_trace(go.Scatter(
            x=older["x"], y=older["y"],
            mode="markers",
            name=f"earlier ({len(older)}d)",
            customdata=older.index.strftime("%d %b %Y"),
            marker={"size": 6, "color": COLORS["accent"], "opacity": 0.35},
            hovertemplate=("%{customdata}<br>FM Δ %{x:+.3f}<br>"
                           "spread Δ %{y:+.3f}<extra></extra>"),
        ))

    if not recent_rest.empty:
        fig.add_trace(go.Scatter(
            x=recent_rest["x"], y=recent_rest["y"],
            mode="markers",
            name=f"last {_RECENT_DAYS}d",
            customdata=recent_rest.index.strftime("%d %b %Y"),
            marker={"size": 9, "color": COLORS["accent"], "opacity": 0.9,
                    "line": {"width": 1, "color": "#ffffff"}},
            hovertemplate=("%{customdata}<br>FM Δ %{x:+.3f}<br>"
                           "spread Δ %{y:+.3f}<extra></extra>"),
        ))

    latest_date = pd.Timestamp(latest.index[-1])
    latest_y = float(latest["y"].iloc[-1])
    ice_color = RICH_COLOR if latest_y >= 0 else CHEAP_COLOR
    fig.add_trace(go.Scatter(
        x=latest["x"], y=latest["y"],
        mode="markers",
        name=f"ICE {latest_date:%d %b}",
        customdata=latest.index.strftime("%d %b %Y"),
        marker={"size": 11, "color": ice_color,
                "line": {"width": 1.5, "color": "#ffffff"}},
        hovertemplate=(
            "<b>ICE settle day</b><br>"
            "%{customdata}<br>"
            "FM Δ %{x:+.3f}<br>"
            "spread Δ %{y:+.3f}"
            "<extra></extra>"
        ),
    ))

    # Bloomberg intraday point: (FM live − FM settle, spread live − spread settle).
    if live_mark is not None and not (isinstance(live_mark, float)
                                      and np.isnan(live_mark)):
        series = entry["series"].dropna()
        if not series.empty and fm_level is not None and not fm_level.dropna().empty:
            spread_settle = float(series.iloc[-1])
            fm_settle = float(fm_level.dropna().iloc[-1])
            y_intra = float(live_mark) - spread_settle
            if fm_live is not None and not (isinstance(fm_live, float)
                                            and np.isnan(fm_live)):
                x_intra = float(fm_live) - fm_settle
                bbg_date = pd.Timestamp(mark_date).normalize() \
                    if mark_date is not None else pd.Timestamp.now().normalize()
                fig.add_trace(go.Scatter(
                    x=[x_intra], y=[y_intra],
                    mode="markers",
                    name=f"BBG {bbg_date:%d %b}",
                    marker={"size": 12, "symbol": "diamond",
                            "color": "#e67e22",
                            "line": {"width": 1.5, "color": "#ffffff"}},
                    hovertemplate=(
                        f"<b>BBG live</b><br>"
                        f"{bbg_date:%d %b %Y}<br>"
                        f"FM Δ %{{x:+.3f}}<br>"
                        f"spread Δ %{{y:+.3f}}"
                        f"<extra></extra>"
                    ),
                ))

    x_line = np.array([sample["x"].min(), sample["x"].max()])
    fig.add_trace(go.Scatter(
        x=x_line, y=reg["alpha"] + reg["beta"] * x_line,
        mode="lines",
        name=(f"β {reg['beta']:+.3f} · corr {reg['corr']:+.2f} · "
              f"R² {reg['r2']:.2f}"),
        line={"width": 2, "color": RICH_COLOR},
        hoverinfo="skip",
    ))

    fig.update_layout(
        title={"text": f"Daily changes vs {fm_name} · last {window}d window",
               "font": {"size": 14}},
        xaxis_title=f"{fm_name} daily change ({fm_unit})",
        yaxis_title=f"Spread daily change ({unit})",
        height=400,
        margin={"l": 60, "r": 20, "t": 70, "b": 70},
        legend={"orientation": "h", "yanchor": "top", "y": -0.15,
                "xanchor": "left", "x": 0},
        **_HOVER_LAYOUT,
    )
    return fig
