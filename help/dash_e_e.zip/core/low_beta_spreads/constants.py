"""Constants for the TTF Low-Beta Spreads page.

The spread universe + regression engine lives in
``jain_commods.core.analytics.spread_beta`` (sibling of the spreads-monitor
engine).  This module holds the page/scheduler wiring plus the interactive
option defaults.
"""
from __future__ import annotations

from typing import Final

# ── Page registration ──────────────────────────────────────────────────────
PAGE_PATH: Final[str] = "/gas/ttf_low_beta_spreads"
PAGE_NAME: Final[str] = "TTF Low-Beta Spreads"
PAGE_TITLE: Final[str] = "TTF Low-Beta Spreads | JG Power Dashboard"
PAGE_ORDER: Final[int] = 3

# ── Scheduler / cache knobs ────────────────────────────────────────────────
SOURCE_NAME: Final[str] = "low_beta_spreads_data"
# Settles are daily; refresh alongside the other price sources on weekdays
# (offset from ttf_spreads_data at :15 to avoid hammering Snowflake at once).
CRON: Final[str] = "25 6,12,18 * * 1-5"
# Long TTL so the Friday-evening snapshot still serves the page over the
# weekend (the cron refresh simply overwrites it on weekdays).
TTL_SECONDS: Final[int] = 72 * 60 * 60

# Years of settlement history to fetch.  The regressions only need the last
# ~250 trading days; 5y gives the z/percentile stats a decent sample while
# keeping the JKM/TFU pull light.
HISTORY_YEARS: Final[int] = 5

# ── Freshness popup ────────────────────────────────────────────────────────
FRESHNESS_SOURCE_NAME: Final[str] = "TTF Low-Beta Spreads (ICE settles)"
# Overnight gap is 18:25 -> 06:25 (~12 h); stay "fresh" across it.
FRESHNESS_EXPECTED_MINUTES: Final[int] = 14 * 60

# ── Interactive option defaults ────────────────────────────────────────────
CRISIS_YEARS: Final[tuple[int, ...]] = (2021, 2022)
DEFAULT_EXCLUDE_CRISIS: Final[bool] = True

# Regression window (trading days of joined daily changes).
REG_WINDOW_OPTIONS: Final[list[dict]] = [
    {"label": "60 d", "value": 60},
    {"label": "120 d", "value": 120},
    {"label": "250 d", "value": 250},
]
DEFAULT_REG_WINDOW: Final[int] = 120

# Minimum |z| filter (0 = show everything).  Default to the "extreme"
# threshold so the page opens focused on actually-mispriced spreads.
MIN_Z_OPTIONS: Final[list[dict]] = [
    {"label": "All", "value": 0},
    {"label": "|z| \u2265 0.5", "value": 0.5},
    {"label": "|z| \u2265 1.0", "value": 1.0},
    {"label": "|z| \u2265 1.5", "value": 1.5},
]
DEFAULT_MIN_Z: Final[float] = 1.5

# Spread types in display order (values must match
# jain_commods.core.analytics.spread_beta.SPREAD_TYPES).
SPREAD_TYPES: Final[list[str]] = [
    "TTF pair",
    "TTF fly",
    "TTF spread-of-spreads",
    "JKM-TFU basis",
    "JKM pair",
    "Basis-of-basis",
]

# Scatter colour per spread type.
TYPE_COLORS: Final[dict[str, str]] = {
    "TTF pair": "#4E738A",
    "TTF fly": "#9b59b6",
    "TTF spread-of-spreads": "#1abc9c",
    "JKM-TFU basis": "#e67e22",
    "JKM pair": "#d29922",
    "Basis-of-basis": "#c0392b",
}
