"""Stats-table builders for the TTF Low-Beta Spreads page.

Reuses the TTF Spreads Monitor's heat palette so the two pages read the same:
pink = rich / flat-price-driven, green = cheap.  The corr column gets its own
heat -- whiter = lower |corr| = more independent of flat price (the point of
the page).
"""
from __future__ import annotations

import pandas as pd
from dash.dash_table.Format import Format, Scheme, Sign

from core.bbg_spreads.highlights import dod_highlight_styles
from core.ttf_spreads.components import (  # shared palette / helpers
    FLAG_COLORS,
    SELECTED_ROW_BG,
    _heat,
    heat_pct,
    heat_z,
)

__all__ = [
    "FLAG_COLORS",
    "SELECTED_ROW_BG",
    "TABLE_COLUMNS",
    "TABLE_HEADER_TOOLTIPS",
    "build_table_records",
    "build_table_styles",
    "table_columns",
]


def heat_abs_corr(corr: float) -> str:
    """|corr| heat: white (independent of FM) -> pink (flat-price proxy)."""
    return _heat(abs(corr))


_SETTLE_COLUMNS = [
    {"name": "Type", "id": "spread_type"},
    {"name": "Structure", "id": "cadence"},
    {"name": "Legs", "id": "legs"},
    {"name": "Ccy", "id": "currency"},
    {"name": "Settle", "id": "live", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "DoD Δ", "id": "dod", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "β to FM", "id": "beta", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "Corr", "id": "corr", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "R²", "id": "r2", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed)},
    {"name": "Vol", "id": "vol", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "z", "id": "z", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "%ile", "id": "pct", "type": "numeric",
     "format": Format(precision=0, scheme=Scheme.fixed)},
    {"name": "n reg", "id": "n_reg", "type": "numeric"},
    {"name": "Flag", "id": "flag"},
]

_LIVE_COLUMNS = [
    {"name": "Type", "id": "spread_type"},
    {"name": "Structure", "id": "cadence"},
    {"name": "Legs", "id": "legs"},
    {"name": "Ccy", "id": "currency"},
    {"name": "Live", "id": "live", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "ICE settle", "id": "settle", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "Δ vs settle", "id": "dod", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "Δ z", "id": "dod_z", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "β to FM", "id": "beta", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "Corr", "id": "corr", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "R²", "id": "r2", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed)},
    {"name": "Vol", "id": "vol", "type": "numeric",
     "format": Format(precision=3, scheme=Scheme.fixed)},
    {"name": "z", "id": "z", "type": "numeric",
     "format": Format(precision=2, scheme=Scheme.fixed, sign=Sign.positive)},
    {"name": "%ile", "id": "pct", "type": "numeric",
     "format": Format(precision=0, scheme=Scheme.fixed)},
    {"name": "n reg", "id": "n_reg", "type": "numeric"},
    {"name": "Flag", "id": "flag"},
]

TABLE_COLUMNS = _SETTLE_COLUMNS


def table_columns(live_mode: bool = False) -> list[dict]:
    return list(_LIVE_COLUMNS if live_mode else _SETTLE_COLUMNS)


TABLE_HEADER_TOOLTIPS = {
    "spread_type": "Spread family: first-order TTF pairs, second-order TTF "
                   "flies / spread-of-spreads, and USD cross-hub structures.",
    "cadence": "Tenor structure relative to the live date (M+1 = front "
               "month, Q+1 = front quarter, ...).",
    "currency": "EUR spreads are €/MWh vs the TTF front month; USD spreads "
                "are $/mmbtu vs the TFU front month (TTF in $/mmbtu).",
    "live": "Latest settlement of the rolling generic spread. In Bloomberg "
            "live mode this is the live mid/last.",
    "settle": "Last ICE settlement for the same structure.",
    "dod": "Settlement mode: change vs the previous settle. "
           "Live mode: live mark minus last ICE settle.",
    "dod_z": "Intraday move (live − settle) / std of historical daily "
             "changes. |Δz| ≥ 1.5 = outsized.",
    "beta": "OLS slope of the spread's daily changes on front-month daily "
            "changes over the selected regression window (native units). "
            "Always from settlement history.",
    "corr": "Correlation of daily changes with the front month over the "
            "window. Unit-free, so comparable across EUR and USD spreads — "
            "the ranking metric. Low |corr| = independent of flat price.",
    "r2": "Share of the spread's daily variance explained by the front "
          "month (corr squared).",
    "vol": "Daily volatility (std of daily changes) of the spread over the "
           "regression window, in native units.",
    "z": "(level − mean) / std vs the spread's own rolling generic history "
         "under the crisis option.",
    "pct": "Percentile of the latest level vs the same history.",
    "n_reg": "Joined daily observations inside the regression window.",
    "flag": "RICH = sell-bias, CHEAP = buy-bias vs own history.",
}


def build_table_records(res: pd.DataFrame,
                        live_mode: bool = False) -> list[dict]:
    """DataTable ``data`` records; each row carries its spec key as ``id``."""
    records = []
    for _, row in res.iterrows():
        rec = {
            "id": row["key"],
            "spread_type": row["spread_type"],
            "cadence": row["cadence"],
            "legs": row["legs"],
            "currency": row["currency"],
            "live": row["live"],
            "dod": None if pd.isna(row["dod"]) else row["dod"],
            "beta": row["beta"],
            "corr": row["corr"],
            "r2": row["r2"],
            "vol": row["vol"],
            "z": row["z"],
            "pct": row["pct"],
            "n_reg": row["n_reg"],
            "flag": row["flag"],
            "dod_extreme": False,
        }
        if "dod_extreme" in row.index and pd.notna(row.get("dod_extreme")):
            rec["dod_extreme"] = bool(row["dod_extreme"])
        if live_mode:
            settle = row.get("settle", row["live"])
            rec["settle"] = None if pd.isna(settle) else settle
            dod_z = row.get("dod_z", float("nan"))
            rec["dod_z"] = None if pd.isna(dod_z) else dod_z
        records.append(rec)
    return records


def _heat_rules(rec: dict) -> list[dict]:
    """Per-row heat cells: %ile / z (rich-cheap) + |corr| (FM dependence)."""
    row_filter = f'{{id}} = "{rec["id"]}"'
    return [
        {"if": {"filter_query": row_filter, "column_id": "pct"},
         "backgroundColor": heat_pct(rec["pct"])},
        {"if": {"filter_query": row_filter, "column_id": "z"},
         "backgroundColor": heat_z(rec["z"])},
        {"if": {"filter_query": row_filter, "column_id": "corr"},
         "backgroundColor": heat_abs_corr(rec["corr"])},
    ]


def build_table_styles(records: list[dict], selected_key: str = None) -> list[dict]:
    """Conditional styles: zebra rows, heat cells, flag badges and the
    whole-row selection tint (heat cells re-applied on top so they survive)."""
    styles = [
        {"if": {"row_index": "odd"}, "backgroundColor": "#fafafa"},
        {"if": {"filter_query": "{dod} > 0", "column_id": "dod"},
         "color": "#3d7a5a", "fontWeight": "600"},
        {"if": {"filter_query": "{dod} < 0", "column_id": "dod"},
         "color": "#b23a48", "fontWeight": "600"},
        {"if": {"filter_query": "{dod_z} > 0", "column_id": "dod_z"},
         "color": "#3d7a5a", "fontWeight": "600"},
        {"if": {"filter_query": "{dod_z} < 0", "column_id": "dod_z"},
         "color": "#b23a48", "fontWeight": "600"},
    ]
    for flag, (bg, fg) in FLAG_COLORS.items():
        styles.append({
            "if": {"filter_query": f'{{flag}} = "{flag}"', "column_id": "flag"},
            "backgroundColor": bg, "color": fg,
            "fontWeight": "700", "textAlign": "center",
        })
    for rec in records:
        styles.extend(_heat_rules(rec))
    styles.extend(dod_highlight_styles(records))

    selected = next((r for r in records if r["id"] == selected_key), None)
    if selected is not None:
        styles.append({
            "if": {"filter_query": f'{{id}} = "{selected["id"]}"'},
            "backgroundColor": SELECTED_ROW_BG,
        })
        styles.extend(_heat_rules(selected))
        styles.extend(dod_highlight_styles([selected]))

    styles.append({
        "if": {"state": "active"},
        "backgroundColor": SELECTED_ROW_BG,
        "border": "1px solid rgba(52, 152, 219, 0.45)",
    })
    return styles
