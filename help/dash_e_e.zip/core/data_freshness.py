"""
Data freshness tracking for enterprise dashboards
Monitors when data sources were last updated and their staleness
"""

import logging
from datetime import datetime
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class DataFreshnessTracker:
    """
    Track data freshness across all dashboards
    Critical for trading applications where stale data = bad decisions
    """
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize tracker"""
        if self._initialized:
            return
        
        self._freshness_data: Dict[str, Dict] = {}
        self._initialized = True
        logger.info("DataFreshnessTracker initialized")
    
    def register_data_source(
        self, 
        source_name: str, 
        update_time: datetime, 
        expected_frequency_minutes: int = 60,
        metadata: Optional[Dict] = None
    ):
        """
        Register when a data source was last updated
        
        Args:
            source_name: Name of the data source (e.g., "EDF Nuclear Outages")
            update_time: When the data was last updated
            expected_frequency_minutes: Expected update frequency in minutes
            metadata: Additional metadata (e.g., record count, file size)
        """
        self._freshness_data[source_name] = {
            'last_update': update_time,
            'expected_frequency_minutes': expected_frequency_minutes,
            'status': self._calculate_status(update_time, expected_frequency_minutes),
            'metadata': metadata or {}
        }
        logger.info(f"Data source '{source_name}' registered: {update_time}")
    
    def _calculate_status(self, update_time: datetime, expected_freq: int) -> str:
        """
        Calculate freshness status based on age vs expected frequency
        
        Returns:
            "fresh" (green), "stale" (yellow), or "critical" (red)
        """
        age_minutes = (datetime.now() - update_time).total_seconds() / 60
        
        if age_minutes < expected_freq:
            return "fresh"  # Within expected frequency
        elif age_minutes < expected_freq * 2:
            return "stale"  # Up to 2x expected frequency
        else:
            return "critical"  # More than 2x expected frequency
    
    def get_all_freshness(self) -> Dict:
        """
        Get freshness status for all data sources
        Recalculates status on each call to reflect current time
        """
        # Recalculate status for all sources
        for source in self._freshness_data:
            update_time = self._freshness_data[source]['last_update']
            expected_freq = self._freshness_data[source]['expected_frequency_minutes']
            metadata = self._freshness_data[source].get('metadata') or {}
            # Explicit lifecycle states (e.g. CE pending / loading / error)
            if metadata.get('state') == 'loading':
                status = 'loading'
            elif metadata.get('state') == 'pending':
                status = 'loading'
            elif metadata.get('error'):
                status = 'critical'
            else:
                status = self._calculate_status(update_time, expected_freq)
            self._freshness_data[source]['status'] = status
            self._freshness_data[source]['age_minutes'] = int(
                (datetime.now() - update_time).total_seconds() / 60
            )
        
        return self._freshness_data
    
    def get_freshness(self, source_name: str) -> Optional[Dict]:
        """Get freshness status for specific source"""
        if source_name not in self._freshness_data:
            return None
        
        # Reuse get_all_freshness logic for a single source
        all_data = self.get_all_freshness()
        return all_data.get(source_name)
    
    def is_fresh(self, source_name: str) -> bool:
        """Check if a specific source is fresh"""
        freshness = self.get_freshness(source_name)
        return freshness and freshness['status'] == 'fresh'
    
    def get_summary(self) -> Dict:
        """Get summary statistics"""
        all_freshness = self.get_all_freshness()
        
        return {
            'total_sources': len(all_freshness),
            'fresh': sum(1 for f in all_freshness.values() if f['status'] == 'fresh'),
            'stale': sum(1 for f in all_freshness.values() if f['status'] == 'stale'),
            'critical': sum(1 for f in all_freshness.values() if f['status'] == 'critical'),
            'loading': sum(1 for f in all_freshness.values() if f['status'] == 'loading'),
        }


# Global tracker instance
tracker = DataFreshnessTracker()
