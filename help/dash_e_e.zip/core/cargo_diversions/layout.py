"""Layout for the LNG — Cargo Diversions page."""
from __future__ import annotations

from dash import dcc, html

from core.cargo_dod.constants import (
    CUSTOM_ZONE,
    DEFAULT_ZONE,
    EARLIEST_SNAPSHOT_DATE,
    ZONE_PRESETS,
)
from core.cargo_dod.data import max_selectable_date
from core.cargo_diversions.constants import (
    WINDOW_DEFAULT_DAYS,
    WINDOW_MAX_DAYS,
    WINDOW_MIN_DAYS,
)
from core.styles import COLORS

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "display": "flex",
    "alignItems": "flex-end",
    "flexWrap": "wrap",
    "gap": "18px",
}
_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}
_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 12px 0",
}
_PANEL_SUBTITLE = {
    "fontSize": "13px",
    "color": COLORS["text_secondary"],
    "margin": "4px 0 12px 0",
    "lineHeight": "1.4",
}
_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}
_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "margin": "8px 0 0 0",
    "lineHeight": "1.5",
}


def build_layout() -> html.Div:
    max_date = max_selectable_date()
    zone_options = [{"label": z, "value": z} for z in ZONE_PRESETS]
    zone_options.append({"label": CUSTOM_ZONE, "value": CUSTOM_ZONE})
    marks = {
        WINDOW_MIN_DAYS: str(WINDOW_MIN_DAYS),
        30: "30",
        60: "60",
        90: "90",
        WINDOW_MAX_DAYS: str(WINDOW_MAX_DAYS),
    }

    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1400px"},
        children=[
            html.Div([
                html.H1("Cargo Diversions", style={
                    "fontSize": "22px", "fontWeight": "600",
                    "color": COLORS["text_primary"], "margin": "0 0 4px 0"}),
                html.P(
                    "A diversion is a cargo whose Kpler destination country "
                    "moved into or out of the zone between two snapshots. "
                    "That is a change in the destination Kpler reports, "
                    "not a physical change in the vessel's heading. "
                    "The previous snapshot must show an AIS or Port destination. "
                    "The source and confidence of the new forecast are ignored. "
                    "Into the zone is a supply gain (green). Out is a loss (red). "
                    "Each day uses the cached 06:00 UTC snapshot.",
                    style={"fontSize": "13px", "color": COLORS["text_muted"],
                           "margin": "0 0 8px 0"}),
                html.P(
                    "Query live Kpler snapshot applies only when the window "
                    "ends today. It replaces today's 06:00 UTC cache with the "
                    "latest Kpler snapshot, still compared with the previous "
                    "cached day, so destination changes later in the day are "
                    "included. On any other end date the page shows a warning "
                    "and stays on the 06:00 UTC cache.",
                    style={"fontSize": "13px", "color": COLORS["text_muted"],
                           "margin": "0 0 12px 0"}),
            ]),
            html.Div(
                style={**_CONTROL_PANEL, "flexDirection": "column",
                       "alignItems": "stretch"},
                children=[
                    html.Div(
                        style={"display": "flex", "alignItems": "flex-start",
                               "flexWrap": "wrap", "gap": "18px"},
                        children=[
                            html.Div([
                                html.Label("Window ends", style=_LABEL),
                                dcc.DatePickerSingle(
                                    id="cd-date-end",
                                    date=max_date,
                                    min_date_allowed=EARLIEST_SNAPSHOT_DATE,
                                    max_date_allowed=max_date,
                                    display_format="DD-MMM-YYYY",
                                    first_day_of_week=1,
                                ),
                            ]),
                            html.Div(
                                style={"paddingBottom": "8px"},
                                children=[
                                    html.Label("Snapshot", style=_LABEL),
                                    dcc.Checklist(
                                        id="cd-live",
                                        options=[{
                                            "label": " Query live Kpler snapshot",
                                            "value": "live",
                                        }],
                                        value=[],
                                        style={"fontSize": "13px",
                                               "color": COLORS["text_primary"]},
                                        inputStyle={"marginRight": "6px"},
                                    ),
                                ],
                            ),
                            html.Div(
                                style={"width": "170px"},
                                children=[
                                    html.Label("Zone", style=_LABEL),
                                    dcc.Dropdown(
                                        id="cd-zone-preset",
                                        options=zone_options,
                                        value=DEFAULT_ZONE,
                                        clearable=False,
                                    ),
                                ],
                            ),
                            html.Div(
                                style={"flex": "1 1 0", "minWidth": "280px"},
                                children=[
                                    html.Label("Destination countries", style=_LABEL),
                                    dcc.Dropdown(
                                        id="cd-countries",
                                        options=[{"label": c, "value": c}
                                                 for c in ZONE_PRESETS[DEFAULT_ZONE]],
                                        value=list(ZONE_PRESETS[DEFAULT_ZONE]),
                                        multi=True,
                                        placeholder="Pick destination countries…",
                                    ),
                                ],
                            ),
                        ],
                    ),
                    html.Div(
                        style={"display": "flex", "alignItems": "flex-start",
                               "flexWrap": "wrap", "gap": "18px"},
                        children=[
                            html.Div(
                                style={"width": "340px", "maxWidth": "100%",
                                       "paddingBottom": "6px"},
                                children=[
                                    html.Label("Days in window", style=_LABEL),
                                    dcc.Slider(
                                        id="cd-window",
                                        min=WINDOW_MIN_DAYS,
                                        max=WINDOW_MAX_DAYS,
                                        step=1,
                                        value=WINDOW_DEFAULT_DAYS,
                                        marks=marks,
                                        tooltip={"placement": "bottom",
                                                 "always_visible": True},
                                    ),
                                ],
                            ),
                            html.Div([
                                html.Label("Bars", style=_LABEL),
                                dcc.RadioItems(
                                    id="cd-metric",
                                    options=[
                                        {"label": " mcm", "value": "volume"},
                                        {"label": " cargoes", "value": "cargoes"},
                                    ],
                                    value="volume",
                                    inline=True,
                                    style={"fontSize": "13px", "marginTop": "6px"},
                                    inputStyle={"marginRight": "4px"},
                                    labelStyle={"marginRight": "14px"},
                                ),
                            ]),
                        ],
                    ),
                    html.Div(id="cd-status"),
                ],
            ),
            dcc.Store(id="cd-events"),
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Window summary", style={**_PANEL_TITLE, "margin": "0"}),
                html.Div(id="cd-summary-subtitle", style=_PANEL_SUBTITLE),
                dcc.Loading(type="circle", children=html.Div(id="cd-cards")),
            ]),
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Daily diversions", style=_PANEL_TITLE),
                html.P(
                    "Click a bar to filter the table to that day. "
                    "The load charts stay on the full window.",
                    style={"fontSize": "13px", "color": COLORS["text_secondary"],
                           "margin": "0 0 8px 0"}),
                dcc.Loading(type="circle", children=dcc.Graph(
                    id="cd-daily-chart",
                    config={"displayModeBar": False},
                )),
                html.Div(id="cd-missing", style=_NOTE),
            ]),
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Diverted cargoes origin", style=_PANEL_TITLE),
                dcc.Loading(type="circle", children=html.Div(id="cd-pies")),
            ]),
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Diversions", style=_PANEL_TITLE),
                html.Div(id="cd-table-caption", style={
                    "fontSize": "13px", "color": COLORS["text_secondary"],
                    "marginBottom": "8px"}),
                dcc.Loading(type="circle", children=html.Div(id="cd-table")),
            ]),
        ],
    )
