"""LNG — Cargo Diversions page constants."""
from __future__ import annotations

PAGE_PATH = "/power/lng/cargo_diversions"
PAGE_NAME = "Cargo Diversions"
PAGE_TITLE = "LNG Cargo Diversions | JG Power Dashboard"
PAGE_ORDER = 82

WINDOW_MIN_DAYS = 7
WINDOW_MAX_DAYS = 180
WINDOW_DEFAULT_DAYS = 30

# Columns kept after cleaning. Origin country is where the cargo loaded.
SLIM_COLUMNS = [
    "Vessel",
    "KplerVesselId",
    "FromCountry",
    "ToCountry",
    "ToTerminal",
    "Source",
    "Volume(mcm)",
]
