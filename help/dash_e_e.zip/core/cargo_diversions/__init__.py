"""LNG — Cargo Diversions page package.

Hard-signal (AIS/Port) moves into and out of a destination zone, walked
across the cached daily Kpler snapshots used by Cargo DoD.
"""
