"""Cache-only diversion history over consecutive Kpler snapshots.

A cargo is a diversion when it enters or leaves the zone and yesterday's
destination source was AIS or Port. Today's source and confidence are ignored.
"""
from __future__ import annotations

import logging
import threading
from datetime import date, datetime, timedelta, timezone
from typing import Any

import pandas as pd

from jain_commods.core.interfaces.kpler.mappings import trades_mapping

from core.cargo_dod.compare import _HARD_SOURCES, create_clean_data
from core.cargo_dod.constants import SNAPSHOT_HOUR_UTC, VOLUME_FILTER_M3
from core.cargo_dod.data import get_store
from core.cargo_diversions.constants import SLIM_COLUMNS

logger = logging.getLogger(__name__)

_slim_lock = threading.Lock()
# date -> slim cleaned frame. Misses are not stored, so a later backfill appears.
_slim_cache: dict[date, pd.DataFrame] = {}


def window_pairs(
    cached_dates: list[date],
    end: date,
    window_days: int,
) -> tuple[list[tuple[date, date]], list[date]]:
    """Pairs whose current date falls in the window, plus missing calendar days.

    Previous snapshot is the latest cached date strictly before the current
    one, which may sit just before the window. A gap is kept as one pair and
    labelled with both dates rather than dropped.
    """
    cached = sorted(d for d in cached_dates if d <= end)
    start = end - timedelta(days=window_days - 1)
    cached_set = set(cached)
    missing = [
        d.date()
        for d in pd.date_range(start, end, freq="D")
        if d.date() not in cached_set
    ]
    pairs: list[tuple[date, date]] = []
    for current in cached:
        if current < start:
            continue
        earlier = [d for d in cached if d < current]
        if not earlier:
            continue
        pairs.append((current, earlier[-1]))
    return pairs, missing


def diversion_events(
    curr: pd.DataFrame,
    prev: pd.DataFrame,
    curr_date: date,
    prev_date: date,
    countries: list[str],
) -> list[dict[str, Any]]:
    """Hard-signal moves into and out of *countries* between two slim frames."""
    if curr.empty or prev.empty:
        return []
    zone = set(countries)
    curr_zone = set(curr.loc[curr["ToCountry"].isin(zone), "Vessel"])
    prev_zone = set(prev.loc[prev["ToCountry"].isin(zone), "Vessel"])
    curr_ix = curr.drop_duplicates("Vessel").set_index("Vessel")
    prev_ix = prev.drop_duplicates("Vessel").set_index("Vessel")

    events: list[dict[str, Any]] = []
    for vessel in sorted(curr_zone - prev_zone):
        if vessel not in prev_ix.index:
            continue
        events.extend(_maybe_event(
            "in", curr_ix.loc[vessel], prev_ix.loc[vessel],
            curr_date, prev_date))
    for vessel in sorted(prev_zone - curr_zone):
        if vessel not in curr_ix.index:
            continue
        events.extend(_maybe_event(
            "out", curr_ix.loc[vessel], prev_ix.loc[vessel],
            curr_date, prev_date))
    return events


def _maybe_event(direction, curr_row, prev_row, curr_date, prev_date):
    if prev_row["Source"] not in _HARD_SOURCES:
        return []
    load = curr_row["FromCountry"]
    if load is None or (isinstance(load, float) and pd.isna(load)) or str(load).strip() == "":
        load = "Unknown"
    volume = curr_row["Volume(mcm)"]
    try:
        volume_f = float(volume)
    except (TypeError, ValueError):
        volume_f = 0.0
    if pd.isna(volume_f):
        volume_f = 0.0
    return [{
        "curr_date": curr_date.isoformat(),
        "prev_date": prev_date.isoformat(),
        "vessel": str(curr_row.name),
        "kpler_vessel_id": curr_row["KplerVesselId"],
        "direction": direction,
        "load_country": str(load),
        "prev_country": _text(prev_row["ToCountry"]),
        "prev_source": _text(prev_row["Source"]),
        "to_country": _text(curr_row["ToCountry"]),
        "to_terminal": _text(curr_row["ToTerminal"]),
        "volume_mcm": volume_f,
    }]


def _text(value) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return "?"
    text = str(value).strip()
    return text if text and text.lower() != "nan" else "?"


def summarise(events: list[dict[str, Any]]) -> dict[str, Any]:
    """Window totals, a daily frame, and load-country volume by direction."""
    inbound = [e for e in events if e["direction"] == "in"]
    outbound = [e for e in events if e["direction"] == "out"]
    vol_in = sum(e["volume_mcm"] for e in inbound)
    vol_out = sum(e["volume_mcm"] for e in outbound)

    if events:
        daily = pd.DataFrame(events)
        daily["curr_date"] = pd.to_datetime(daily["curr_date"])
        grouped = daily.groupby(["curr_date", "direction"]).agg(
            volume=("volume_mcm", "sum"),
            cargoes=("volume_mcm", "size"),
        ).unstack("direction")
        grouped.columns = [f"{metric}_{direction}" for metric, direction in grouped.columns]
        for col in ("volume_in", "volume_out", "cargoes_in", "cargoes_out"):
            if col not in grouped.columns:
                grouped[col] = 0.0
        grouped = grouped.fillna(0).sort_index()
    else:
        grouped = pd.DataFrame(
            columns=["volume_in", "volume_out", "cargoes_in", "cargoes_out"])

    return {
        "n_in": len(inbound),
        "n_out": len(outbound),
        "volume_in": vol_in,
        "volume_out": vol_out,
        "net_cargoes": len(inbound) - len(outbound),
        "net_volume": vol_in - vol_out,
        "daily": grouped,
        "origin_in": _origin(inbound),
        "origin_out": _origin(outbound),
    }


def _origin(events: list[dict[str, Any]]) -> pd.Series:
    if not events:
        return pd.Series(dtype=float)
    frame = pd.DataFrame(events)
    return frame.groupby("load_country")["volume_mcm"].sum().sort_values(ascending=False)


_STAMP_FMT = "%Y-%m-%dT%H0000"


def utc_today() -> date:
    return datetime.now(timezone.utc).date()


def live_only_today_message(today: date) -> str:
    """Shown when the live box is ticked but the window does not end today."""
    return (
        "Live Kpler snapshot is only used when the window ends today "
        f"({today.strftime('%d-%b-%Y')} UTC). Showing the 06:00 UTC cache."
    )


def apply_live_frame(
    pairs: list[tuple[date, date]],
    frames: dict[date, pd.DataFrame],
    end: date,
    live_frame: pd.DataFrame,
) -> tuple[list[tuple[date, date]], dict[date, pd.DataFrame]]:
    """Use *live_frame* as the current snapshot on *end*.

    An existing pair for *end* keeps its previous date. If *end* was not
    cached, it is paired with the latest frame already loaded before it.
    """
    frames = dict(frames)
    frames[end] = live_frame
    if any(curr == end for curr, _prev in pairs):
        return list(pairs), frames
    earlier = [day for day in frames if day < end]
    if not earlier:
        return list(pairs), frames
    return list(pairs) + [(end, max(earlier))], frames


def _slim_frame(raw: pd.DataFrame) -> pd.DataFrame:
    cleaned = create_clean_data(
        raw.rename(columns=trades_mapping), VOLUME_FILTER_M3, None)
    present = [c for c in SLIM_COLUMNS if c in cleaned.columns]
    return cleaned[present].copy()


def fetch_live_frame(snapshot_date: date) -> tuple[pd.DataFrame | None, str]:
    """Latest PIT snapshot for *snapshot_date*, without writing the 06:00 cache.

    Returns ``(frame, time label)`` when a snapshot later than 06:00 UTC
    exists, or ``(None, reason)`` when the cache should be kept.
    """
    store = get_store()
    stamp = store.latest_snapshot_stamp(snapshot_date)
    if not stamp:
        return None, "Kpler returned no snapshot for today. Showing the 06:00 UTC cache."
    try:
        hour = datetime.strptime(stamp, _STAMP_FMT).hour
    except ValueError:
        hour = None
    if hour is not None and hour <= SNAPSHOT_HOUR_UTC:
        return None, (
            "The latest Kpler snapshot is still 06:00 UTC, the same as the cache."
        )
    raw = store.fetch_trades_at(stamp)
    label = f"{hour:02d}:00 UTC" if hour is not None else stamp
    return _slim_frame(raw), label


def slim_snapshot(snapshot_date: date) -> pd.DataFrame | None:
    """One cleaned trades snapshot from the local/S3 cache. Never calls Kpler."""
    with _slim_lock:
        cached = _slim_cache.get(snapshot_date)
    if cached is not None:
        return cached

    raw = get_store().read_trades_snapshot(snapshot_date)
    if raw is None:
        return None
    slim = _slim_frame(raw)
    with _slim_lock:
        _slim_cache[snapshot_date] = slim
    return slim


def load_history(
    end: date,
    window_days: int,
    countries: list[str],
    live: bool = False,
    today: date | None = None,
) -> dict[str, Any]:
    """Events for cached pairs in the window ending on *end*.

    When *live* is set and *end* is today (UTC), the end date uses the latest
    Kpler snapshot instead of the 06:00 cache. The previous day stays cached.
    """
    cached = get_store().list_cached_dates()
    pairs, missing = window_pairs(cached, end, window_days)
    events: list[dict[str, Any]] = []
    unread: list[date] = []
    frames: dict[date, pd.DataFrame] = {}
    for snapshot_date in sorted({d for pair in pairs for d in pair}):
        frame = slim_snapshot(snapshot_date)
        if frame is None:
            unread.append(snapshot_date)
        else:
            frames[snapshot_date] = frame

    live_time = None
    live_warning = None
    if live:
        today = today or utc_today()
        if end != today:
            live_warning = live_only_today_message(today)
        else:
            try:
                live_frame, note = fetch_live_frame(end)
            except Exception as ex:
                logger.exception("Live Kpler snapshot failed")
                live_frame, note = None, (
                    f"Live Kpler snapshot failed ({ex}). Showing the 06:00 UTC cache."
                )
            if live_frame is None:
                live_warning = note
            else:
                pairs, frames = apply_live_frame(pairs, frames, end, live_frame)
                missing = [day for day in missing if day != end]
                live_time = note

    for curr_date, prev_date in pairs:
        curr = frames.get(curr_date)
        prev = frames.get(prev_date)
        if curr is None or prev is None:
            continue
        batch = diversion_events(curr, prev, curr_date, prev_date, countries)
        if live_time and curr_date == end:
            for event in batch:
                event["snapshot_time"] = live_time
        events.extend(batch)
    events.sort(key=lambda e: (e["curr_date"], e["direction"], e["vessel"]),
                reverse=True)
    seen: set[str] = set()
    for frame in frames.values():
        if "ToCountry" not in frame.columns:
            continue
        seen.update(
            c for c in frame["ToCountry"].dropna().astype(str)
            if c.strip() and c.lower() != "nan")
    return {
        "events": events,
        "missing": missing,
        "unread": unread,
        "countries": sorted(seen),
        "live_time": live_time,
        "live_warning": live_warning,
        "n_pairs": sum(
            1 for curr_date, prev_date in pairs
            if curr_date in frames and prev_date in frames),
    }
