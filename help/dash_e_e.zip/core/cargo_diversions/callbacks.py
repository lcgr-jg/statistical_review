"""Callbacks for the LNG — Cargo Diversions page."""
from __future__ import annotations

import logging
from datetime import date, timedelta

import pandas as pd
from dash import Input, Output, State, callback, ctx, html, no_update

from core.cargo_dod.constants import CUSTOM_ZONE, ZONE_PRESETS
from core.cargo_diversions.constants import WINDOW_DEFAULT_DAYS
from core.cargo_diversions.history import load_history, summarise
from core.cargo_diversions.render import (
    build_daily_chart,
    build_event_table,
    build_origin_charts,
    build_summary_cards,
    missing_note,
)
from core.styles import COLORS, get_status_badge_style

logger = logging.getLogger(__name__)


def _parse_date(value) -> date | None:
    if not value:
        return None
    try:
        return pd.Timestamp(value).date()
    except Exception:
        return None


def _stored(payload) -> tuple[list, str | None, str | None]:
    """Events plus the window the chart axis should span."""
    if isinstance(payload, list):
        return payload, None, None
    payload = payload or {}
    return payload.get("events") or [], payload.get("start"), payload.get("end")


def _window_subtitle(start: date, end: date, zone: str | None) -> str:
    """Start date, end date, and the zone selected in the control bar."""
    label = zone if zone else "Custom"
    return f"{start.strftime('%d-%b-%Y')} – {end.strftime('%d-%b-%Y')} · {label}"


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(message, style={
        **get_status_badge_style(level),
        "padding": "10px 14px",
        "borderRadius": "8px",
        "fontSize": "13px",
        "width": "100%",
    })


@callback(
    Output("cd-countries", "value"),
    Input("cd-zone-preset", "value"),
    State("cd-countries", "value"),
)
def apply_zone_preset(preset, current_value):
    if preset == CUSTOM_ZONE or preset not in ZONE_PRESETS:
        return current_value or []
    return list(ZONE_PRESETS[preset])


@callback(
    Output("cd-cards", "children"),
    Output("cd-summary-subtitle", "children"),
    Output("cd-pies", "children"),
    Output("cd-missing", "children"),
    Output("cd-events", "data"),
    Output("cd-status", "children"),
    Output("cd-countries", "options"),
    Output("cd-daily-chart", "clickData"),
    Input("cd-date-end", "date"),
    Input("cd-window", "value"),
    Input("cd-countries", "value"),
    Input("cd-live", "value"),
    State("cd-zone-preset", "value"),
)
def load_window(end_value, window_days, countries, live_value, zone_preset):
    """Read cached snapshots. A ticked live box reloads today's end date."""
    end = _parse_date(end_value)
    countries = countries or []
    blanks = (html.Div(), "", html.Div(), "", None)

    if end is None:
        return (*blanks, _alert("Pick the day the window ends."), no_update, None)
    if not countries:
        return (*blanks, _alert("Pick at least one destination country."),
                no_update, None)
    try:
        window_days = int(window_days)
    except (TypeError, ValueError):
        window_days = WINDOW_DEFAULT_DAYS

    try:
        loaded = load_history(
            end, window_days, countries, live="live" in (live_value or []))
    except Exception as ex:
        logger.exception("Diversion history failed")
        return (*blanks, _alert(f"History load failed: {ex}", "error"),
                no_update, None)

    events = loaded["events"]
    summary = summarise(events)
    start = end - timedelta(days=window_days - 1)
    zone_label = next(
        (name for name, preset in ZONE_PRESETS.items()
         if set(preset) == set(countries)),
        "zone")
    status_text = (
        f"{loaded['n_pairs']} snapshot pairs through "
        f"{end.strftime('%d-%b-%y')} — zone: {zone_label}"
    )
    if loaded.get("live_warning"):
        status = _alert(f"{loaded['live_warning']} {status_text}.", "warning")
    elif loaded.get("live_time"):
        status = _alert(
            f"{status_text}. Today uses the live {loaded['live_time']} "
            "Kpler snapshot instead of the 06:00 UTC cache.",
            "success")
    else:
        status = _alert(status_text, "success")
    option_names = sorted(set(countries) | set(loaded.get("countries") or []))
    options = [{"label": c, "value": c} for c in option_names if c.strip()]
    return (
        build_summary_cards(summary),
        _window_subtitle(start, end, zone_preset),
        build_origin_charts(summary["origin_in"], summary["origin_out"]),
        missing_note(loaded["missing"], loaded["unread"]),
        {"events": events, "start": start.isoformat(), "end": end.isoformat()},
        status,
        options,
        None,
    )


@callback(
    Output("cd-daily-chart", "figure"),
    Input("cd-events", "data"),
    Input("cd-metric", "value"),
)
def update_chart(payload, metric):
    events, start, end = _stored(payload)
    summary = summarise(events)
    return build_daily_chart(
        summary["daily"], metric or "volume", start, end, events)


@callback(
    Output("cd-table", "children"),
    Output("cd-table-caption", "children"),
    Input("cd-events", "data"),
    Input("cd-daily-chart", "clickData"),
)
def update_table(payload, click_data):
    events, _start, _end = _stored(payload)
    day_filter = None
    if ctx.triggered_id == "cd-daily-chart" and click_data:
        points = click_data.get("points") or []
        if points:
            raw = points[0].get("customdata")
            day_filter = raw[0] if isinstance(raw, (list, tuple)) else raw

    shown = events
    caption = (f"{len(events)} diversion"
               f"{'s' if len(events) != 1 else ''} in the window")
    if day_filter:
        shown = [e for e in events if e["curr_date"] == day_filter]
        label = pd.Timestamp(day_filter).strftime("%d-%b-%y")
        caption = (f"{len(shown)} on {label} "
                   f"(of {len(events)} in the window)")
    return build_event_table(shown), caption
