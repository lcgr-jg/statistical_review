"""Dash components for the Cargo Diversions page."""
from __future__ import annotations

from typing import Any

import pandas as pd
import plotly.graph_objects as go
from dash import dcc, html

from core.cargo_dod.constants import KPLER_VESSEL_MAP_URL
from core.styles import COLORS

_IN = COLORS["accent_green"]
_OUT = COLORS["danger"]

_TABLE_STYLE = {
    "borderCollapse": "collapse",
    "fontSize": "13px",
    "color": COLORS["text_primary"],
    "width": "100%",
}
_TH = {
    "backgroundColor": COLORS["table_header_bg"],
    "border": f"1px solid {COLORS['border']}",
    "padding": "6px 10px",
    "textAlign": "left",
    "fontWeight": "600",
}
_TD = {
    "border": f"1px solid {COLORS['border']}",
    "padding": "5px 10px",
    "textAlign": "left",
}


def _signed(value: float, fmt: str) -> html.Span:
    color = _IN if value >= 0 else _OUT
    return html.Span(fmt.format(value), style={"color": color, "fontWeight": "700"})


def build_summary_cards(summary: dict[str, Any]) -> html.Div:
    """In is a supply gain (green). Out is a loss (red). Net follows the sign."""
    def card(title: str, body, accent: str) -> html.Div:
        return html.Div(
            style={
                "flex": "1 1 180px",
                "minWidth": "180px",
                "padding": "12px 16px",
                "borderRadius": "10px",
                "border": f"1px solid {COLORS['border']}",
                "borderTop": f"3px solid {accent}",
                "backgroundColor": COLORS["card_bg_alt"],
            },
            children=[
                html.Div(title, style={
                    "fontSize": "11px", "fontWeight": "600",
                    "textTransform": "uppercase",
                    "color": COLORS["text_muted"], "letterSpacing": "0.4px"}),
                html.Div(body, style={"marginTop": "6px", "fontSize": "20px",
                                      "fontWeight": "700",
                                      "color": COLORS["text_primary"]}),
            ],
        )

    n_in, n_out = summary["n_in"], summary["n_out"]
    return html.Div(
        style={"display": "flex", "gap": "14px", "flexWrap": "wrap"},
        children=[
            card("Diverted in",
                 [f"{n_in}  ", html.Span(
                     f"{summary['volume_in']:,.0f} mcm",
                     style={"color": _IN, "fontSize": "14px"})],
                 _IN),
            card("Diverted out",
                 [f"{n_out}  ", html.Span(
                     f"{summary['volume_out']:,.0f} mcm",
                     style={"color": _OUT, "fontSize": "14px"})],
                 _OUT),
            card("Net cargoes", _signed(summary["net_cargoes"], "{:+,.0f}"),
                 _IN if summary["net_cargoes"] >= 0 else _OUT),
            card("Net volume", _signed(summary["net_volume"], "{:+,.0f} mcm"),
                 _IN if summary["net_volume"] >= 0 else _OUT),
        ],
    )


_DAY_MS = 24 * 60 * 60 * 1000


def build_daily_chart(
    daily: pd.DataFrame,
    metric: str,
    start=None,
    end=None,
    events: list[dict[str, Any]] | None = None,
) -> go.Figure:
    """Diverging bars on a date axis so quiet days stay visible as gaps."""
    fig = go.Figure()
    unit = "mcm" if metric == "volume" else "cargoes"
    up_col = f"{metric}_in"
    down_col = f"{metric}_out"
    if daily.empty or up_col not in daily.columns:
        fig.update_layout(annotations=[{
            "text": "No diversions in this window",
            "showarrow": False,
            "xref": "paper", "yref": "paper", "x": 0.5, "y": 0.5,
        }])
        return _style_chart(fig, unit, start, end)

    vessels = _vessels_by_day(events)
    _add_direction_bar(fig, daily, up_col, "in", "Into zone", _IN, unit, vessels, sign=1)
    _add_direction_bar(fig, daily, down_col, "out", "Out of zone", _OUT, unit, vessels, sign=-1)
    return _style_chart(fig, unit, start, end)


def _vessels_by_day(events: list[dict[str, Any]] | None) -> dict[str, dict[str, list[str]]]:
    grouped: dict[str, dict[str, list[str]]] = {}
    for event in events or []:
        day = pd.Timestamp(event["curr_date"]).strftime("%Y-%m-%d")
        direction = event.get("direction")
        if direction not in ("in", "out"):
            continue
        grouped.setdefault(day, {"in": [], "out": []})
        grouped[day][direction].append(str(event.get("vessel") or ""))
    return grouped


def _add_direction_bar(fig, daily, column, direction, name, color, unit, vessels, sign):
    """One direction. The shared hover header already shows the date."""
    xs = []
    ys = []
    custom = []
    for day, amount in daily[column].items():
        amount_f = float(amount)
        if amount_f == 0:
            continue
        day_key = pd.Timestamp(day).strftime("%Y-%m-%d")
        names = [v for v in vessels.get(day_key, {}).get(direction, []) if v]
        label = f"{amount_f:.0f} {unit}"
        if names:
            label += f" ({', '.join(names)})"
        xs.append(pd.Timestamp(day))
        ys.append(sign * abs(amount_f))
        custom.append([day_key, label])
    if not xs:
        return
    fig.add_bar(
        x=xs, y=ys, name=name,
        marker_color=color, customdata=custom, width=_DAY_MS * 0.72,
        hovertemplate="%{customdata[1]}<extra></extra>",
    )


def _style_chart(fig: go.Figure, unit: str, start=None, end=None) -> go.Figure:
    fig.update_layout(
        barmode="relative",
        height=360,
        margin={"l": 48, "r": 16, "t": 24, "b": 48},
        yaxis_title=unit,
        plot_bgcolor=COLORS["chart_bg"],
        paper_bgcolor=COLORS["chart_paper"],
        legend={"orientation": "h", "y": 1.12},
        font={"size": 12},
        hovermode="x unified",
    )
    xaxis: dict[str, Any] = {
        "type": "date",
        "tickformat": "%d %b",
        "hoverformat": "%d %b %Y",
        "showgrid": True,
        "gridcolor": COLORS["border"],
    }
    if start is not None and end is not None:
        start_ts = pd.Timestamp(start)
        end_ts = pd.Timestamp(end)
        xaxis["range"] = [
            (start_ts - pd.Timedelta(hours=12)).isoformat(),
            (end_ts + pd.Timedelta(hours=12)).isoformat(),
        ]
        every = _tick_every(start_ts, end_ts)
        xaxis["tick0"] = start_ts.isoformat()
        xaxis["dtick"] = every * _DAY_MS
        if every == 1:
            xaxis["tickangle"] = -40
            fig.update_layout(margin={"b": 72})
    fig.update_xaxes(**xaxis)
    fig.update_yaxes(zeroline=True, zerolinewidth=1, zerolinecolor=COLORS["border"])
    return fig


def _tick_every(start: pd.Timestamp, end: pd.Timestamp) -> int:
    """Days between x-axis labels. Short windows get a label on every day."""
    days = (end - start).days + 1
    if days <= 31:
        return 1
    if days <= 62:
        return 2
    if days <= 120:
        return 3
    return 7


def build_origin_charts(origin_in: pd.Series, origin_out: pd.Series) -> html.Div:
    """Window totals of diverted volume by the country the cargo loaded in."""
    net = _net_series(origin_in, origin_out)
    height = max(
        200,
        36 * max(len(origin_in), len(origin_out), len(net), 1) + 72,
    )
    chart = {"flex": "1 1 280px", "minWidth": "260px"}
    return html.Div(
        style={"display": "flex", "gap": "16px", "flexWrap": "wrap"},
        children=[
            html.Div(dcc.Graph(
                figure=_origin_bar(origin_in, "Diverted in", _IN, height),
                config={"displayModeBar": False}), style=chart),
            html.Div(dcc.Graph(
                figure=_origin_bar(origin_out, "Diverted out", _OUT, height),
                config={"displayModeBar": False}), style=chart),
            html.Div(dcc.Graph(
                figure=_net_bar(net, height),
                config={"displayModeBar": False}), style=chart),
        ],
    )


def _net_series(origin_in: pd.Series, origin_out: pd.Series) -> pd.Series:
    """In minus out by load country. A zero net is dropped."""
    net = origin_in.sub(origin_out, fill_value=0.0)
    net = net[net != 0]
    return net.sort_values(ascending=True)


def _origin_bar(series: pd.Series, title: str, color: str, height: int) -> go.Figure:
    """Horizontal bars. Country names sit on the axis, clear of the title."""
    fig = go.Figure()
    if series.empty or float(series.sum()) <= 0:
        fig.update_layout(
            height=height,
            title={"text": title, "font": {"size": 14, "color": color},
                   "x": 0, "xanchor": "left"},
            annotations=[{
                "text": "None in this window",
                "showarrow": False,
                "xref": "paper", "yref": "paper", "x": 0.5, "y": 0.5,
            }],
            margin={"l": 16, "r": 16, "t": 40, "b": 16},
        )
    else:
        ordered = series.sort_values(ascending=True)
        total = float(ordered.sum())
        labels = [
            f"{value:,.0f} mcm ({value / total * 100:.0f}%)"
            for value in ordered
        ]
        fig.add_bar(
            y=list(ordered.index),
            x=list(ordered.values),
            orientation="h",
            marker_color=color,
            text=labels,
            textposition="outside",
            cliponaxis=False,
            hovertemplate="%{y}<br>%{x:,.0f} mcm<extra></extra>",
        )
        fig.update_layout(
            height=height,
            title={"text": f"{title} ({total:,.0f} mcm)",
                   "font": {"size": 14, "color": color},
                   "x": 0, "xanchor": "left"},
            margin={"l": 8, "r": 130, "t": 44, "b": 36},
            xaxis_title="mcm",
            xaxis_range=[0, float(ordered.max()) * 1.55],
            yaxis_automargin=True,
            showlegend=False,
        )
    fig.update_layout(
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        font={"size": 12},
    )
    return fig


def _net_bar(net: pd.Series, height: int) -> go.Figure:
    """In minus out. Green is a supply gain from that origin, red a loss."""
    fig = go.Figure()
    total = float(net.sum()) if not net.empty else 0.0
    color = _IN if total >= 0 else _OUT
    title = f"Net ({total:+,.0f} mcm)"
    if net.empty:
        fig.update_layout(
            height=height,
            title={"text": "Net", "font": {"size": 14, "color": COLORS["text_muted"]},
                   "x": 0, "xanchor": "left"},
            annotations=[{
                "text": "None in this window",
                "showarrow": False,
                "xref": "paper", "yref": "paper", "x": 0.5, "y": 0.5,
            }],
            margin={"l": 16, "r": 16, "t": 40, "b": 16},
        )
    else:
        lo = min(0.0, float(net.min()))
        hi = max(0.0, float(net.max()))
        label_room = max(abs(lo), hi, 1.0) * 0.55
        if lo < 0 and hi > 0:
            x_range = [lo * 1.08, hi + label_room]
        elif hi > 0:
            x_range = [0, hi + label_room]
        else:
            x_range = [lo * 1.08, label_room]
        fig.add_bar(
            y=list(net.index),
            x=list(net.values),
            orientation="h",
            marker_color=[_IN if value >= 0 else _OUT for value in net],
            hovertemplate="%{y}<br>net %{x:+,.0f} mcm<extra></extra>",
        )
        for country, value in net.items():
            fig.add_annotation(
                x=value if value >= 0 else 0,
                y=country,
                text=f"{value:+,.0f} mcm",
                xanchor="left",
                yanchor="middle",
                showarrow=False,
                xshift=6,
                font={"size": 12, "color": COLORS["text_primary"]},
            )
        fig.update_layout(
            height=height,
            title={"text": title, "font": {"size": 14, "color": color},
                   "x": 0, "xanchor": "left"},
            margin={"l": 8, "r": 16, "t": 44, "b": 36},
            xaxis_title="mcm",
            xaxis_range=x_range,
            xaxis_zeroline=True,
            xaxis_zerolinewidth=1,
            xaxis_zerolinecolor=COLORS["border"],
            yaxis_automargin=True,
            showlegend=False,
        )
    fig.update_layout(
        paper_bgcolor=COLORS["chart_paper"],
        plot_bgcolor=COLORS["chart_bg"],
        font={"size": 12},
    )
    return fig


def build_event_table(events: list[dict[str, Any]]) -> html.Div:
    if not events:
        return html.Div("No diversions in this window.", style={
            "fontSize": "13px", "color": COLORS["text_muted"], "padding": "8px 0"})
    header = html.Tr([
        html.Th(col, style=_TH)
        for col in ("Date", "Vs", "Vessel", "Direction", "Loaded in",
                    "Was", "Now", "Terminal", "mcm")
    ])
    rows = []
    for event in events:
        inbound = event["direction"] == "in"
        direction = html.Span(
            "In" if inbound else "Out",
            style={"color": _IN if inbound else _OUT, "fontWeight": "700"},
        )
        vessel = html.A(
            event["vessel"],
            href=KPLER_VESSEL_MAP_URL.format(event["kpler_vessel_id"]),
            target="_blank",
            style={"color": COLORS["accent"], "fontWeight": "600",
                   "textDecoration": "none"},
        )
        curr = pd.Timestamp(event["curr_date"]).strftime("%d-%b-%y")
        if event.get("snapshot_time"):
            curr = f"{curr} {event['snapshot_time']}"
        prev = pd.Timestamp(event["prev_date"]).strftime("%d-%b-%y")
        rows.append(html.Tr([
            html.Td(curr, style=_TD),
            html.Td(prev, style=_TD),
            html.Td(vessel, style=_TD),
            html.Td(direction, style=_TD),
            html.Td(event["load_country"], style=_TD),
            html.Td(f"{event['prev_country']} ({event['prev_source']})", style=_TD),
            html.Td(event["to_country"], style=_TD),
            html.Td(event["to_terminal"], style=_TD),
            html.Td(f"{event['volume_mcm']:,.0f}", style={**_TD, "textAlign": "right"}),
        ]))
    return html.Table([html.Thead(header), html.Tbody(rows)], style=_TABLE_STYLE)


def missing_note(missing: list, unread: list) -> str:
    parts = []
    if missing:
        shown = ", ".join(pd.Timestamp(d).strftime("%d-%b") for d in missing[:8])
        extra = f" (+{len(missing) - 8} more)" if len(missing) > 8 else ""
        parts.append(
            f"No cached snapshot for {len(missing)} day"
            f"{'' if len(missing) == 1 else 's'} in the window"
            f" ({shown}{extra}). Those days are skipped, not fetched live.")
    if unread:
        parts.append(
            f"{len(unread)} cached date"
            f"{'' if len(unread) == 1 else 's'} could not be read.")
    return " ".join(parts)
