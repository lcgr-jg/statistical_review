"""On-demand BPIPE live snapshot for spread tickers."""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any, Optional

import numpy as np
import pandas as pd

from core.bbg_spreads.tickers import (
    SpreadPriceRequest,
    collect_tickers,
)

logger = logging.getLogger(__name__)

_LIVE_FIELDS = [
    "PX_MID",
    "PX_BID",
    "PX_ASK",
    "PX_LAST",
    "PX_SETTLE",
    "LAST_UPDATE_DT",
    "TIME",
]

_BBG_AVAILABLE: Optional[bool] = None
_BBG_ERROR: str = ""
_BBG_SESSION = None
_BBG_LAST_TRY: float = 0.0
_BBG_BACKOFF_SEC: float = 60.0
_BBG_LOCK = threading.Lock()


def _try_session():
    """Open a shared BPIPE session (throttled on failure)."""
    global _BBG_AVAILABLE, _BBG_ERROR, _BBG_SESSION, _BBG_LAST_TRY

    if _BBG_AVAILABLE is True:
        return _BBG_SESSION
    if (_BBG_AVAILABLE is False
            and (time.time() - _BBG_LAST_TRY) < _BBG_BACKOFF_SEC):
        return None

    with _BBG_LOCK:
        if _BBG_AVAILABLE is True:
            return _BBG_SESSION
        if (_BBG_AVAILABLE is False
                and (time.time() - _BBG_LAST_TRY) < _BBG_BACKOFF_SEC):
            return None
        _BBG_LAST_TRY = time.time()

        try:
            from jain_commods.core.interfaces.bloomberg import BBGQuery
        except Exception as exc:
            _BBG_AVAILABLE = False
            _BBG_ERROR = f"jain_commods import failed: {exc}"
            logger.warning("BBG spreads: %s", _BBG_ERROR)
            return None

        try:
            sess = BBGQuery(p_on_server=True)
            smoke = sess.fetch_live(tickers=["USGG10YR Index"], fields=["PX_LAST"])
            if smoke is None or smoke.empty:
                _BBG_AVAILABLE = False
                _BBG_ERROR = "BPIPE smoke-test returned no rows"
                logger.warning("BBG spreads: %s", _BBG_ERROR)
                return None
            _BBG_SESSION = sess
            _BBG_AVAILABLE = True
            _BBG_ERROR = ""
            logger.info("BBG spreads: BPIPE session ready")
            return sess
        except Exception as exc:
            _BBG_AVAILABLE = False
            _BBG_ERROR = f"BPIPE connect failed: {exc}"
            logger.warning("BBG spreads: %s", _BBG_ERROR)
            try:
                from jain_commods.core.interfaces.bloomberg import BBGQuery
                BBGQuery._instance = None  # type: ignore[attr-defined]
            except Exception:
                pass
            return None


def _cell(row: pd.Series, field: str) -> float:
    if field not in row.index:
        return np.nan
    val = row[field]
    if val is None or (isinstance(val, float) and np.isnan(val)):
        return np.nan
    try:
        return float(val)
    except (TypeError, ValueError):
        return np.nan


def _mid_from_row(row: pd.Series) -> float:
    """Prefer PX_MID → (BID+ASK)/2 → PX_LAST → PX_SETTLE."""
    mid = _cell(row, "PX_MID")
    if not np.isnan(mid):
        return mid
    bid, ask = _cell(row, "PX_BID"), _cell(row, "PX_ASK")
    if not np.isnan(bid) and not np.isnan(ask):
        return 0.5 * (bid + ask)
    last = _cell(row, "PX_LAST")
    if not np.isnan(last):
        return last
    return _cell(row, "PX_SETTLE")


def _price_map(df: pd.DataFrame) -> dict[str, float]:
    out: dict[str, float] = {}
    if df is None or df.empty:
        return out
    for ticker, row in df.iterrows():
        px = _mid_from_row(row)
        if not np.isnan(px):
            out[str(ticker)] = px
    return out


def _resolve_request(req: SpreadPriceRequest,
                     prices: dict[str, float]) -> tuple[Optional[float], str]:
    """Return (mark, source) where source is 'primary' | 'implied' | 'missing'."""
    if req.primary and req.primary in prices:
        return prices[req.primary], "primary"
    if req.legs:
        total = 0.0
        for leg in req.legs:
            if leg.ticker not in prices:
                return None, "missing"
            total += leg.weight * prices[leg.ticker]
        return total, "implied"
    return None, "missing"


def fetch_live_marks(requests: list[SpreadPriceRequest],
                     extra_tickers: list[str] | None = None) -> dict[str, Any]:
    """Bulk-fetch BPIPE mids and map them onto spread keys.

    Returns a picklable payload suitable for ``dcc.Store``::

        {
            "marks": {key: float, ...},
            "sources": {key: "primary"|"implied", ...},
            "prices": {ticker: float, ...},   # raw outright/calendar mids
            "fetched_at": ISO UTC,
            "n_tickers": int,
            "n_priced": int,
            "n_missing": int,
            "missing_keys": [...],
            "error": str | None,
            "tickers": [...],
        }
    """
    tickers = collect_tickers(requests)
    if extra_tickers:
        for t in extra_tickers:
            if t and t not in tickers:
                tickers.append(t)
    payload: dict[str, Any] = {
        "marks": {},
        "sources": {},
        "prices": {},
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "n_tickers": len(tickers),
        "n_priced": 0,
        "n_missing": 0,
        "missing_keys": [],
        "error": None,
        "tickers": tickers,
    }
    if not requests:
        payload["error"] = "No spread ticker requests to fetch"
        return payload
    if not tickers:
        payload["error"] = "Could not construct any Bloomberg tickers"
        payload["n_missing"] = len(requests)
        payload["missing_keys"] = [r.key for r in requests]
        return payload

    sess = _try_session()
    if sess is None:
        payload["error"] = _BBG_ERROR or "Bloomberg BPIPE unavailable"
        payload["n_missing"] = len(requests)
        payload["missing_keys"] = [r.key for r in requests]
        return payload

    try:
        df = sess.fetch_live(tickers=tickers, fields=_LIVE_FIELDS)
    except Exception as exc:
        logger.exception("BBG spreads fetch_live failed: %s", exc)
        payload["error"] = f"fetch_live failed: {exc}"
        payload["n_missing"] = len(requests)
        payload["missing_keys"] = [r.key for r in requests]
        return payload

    prices = _price_map(df if df is not None else pd.DataFrame())
    marks: dict[str, float] = {}
    sources: dict[str, str] = {}
    missing: list[str] = []

    for req in requests:
        # Prefer native calendar; fall back to implied outrights if blank.
        mark, source = _resolve_request(req, prices)
        if mark is None:
            missing.append(req.key)
            continue
        marks[req.key] = float(mark)
        sources[req.key] = source

    payload["marks"] = marks
    payload["sources"] = sources
    payload["prices"] = prices
    payload["n_priced"] = len(marks)
    payload["n_missing"] = len(missing)
    payload["missing_keys"] = missing
    if not marks:
        payload["error"] = (
            f"No live prices returned for {len(tickers)} tickers"
        )
    return payload
