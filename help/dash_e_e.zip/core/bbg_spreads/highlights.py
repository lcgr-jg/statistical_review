"""Outsized intraday-move highlighting for live spread stats."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

import numpy as np
import pandas as pd

# |dod_z| threshold for an "outsized" move vs own daily-change history.
DOD_Z_EXTREME = 1.5

# Soft amber highlight — distinct from RICH/CHEAP pink/green heat.
DOD_MOVE_BG = "rgb(255, 236, 200)"
DOD_MOVE_BORDER = "rgba(180, 120, 20, 0.55)"

_BANNER_LIVE = {
    "display": "flex",
    "flexWrap": "wrap",
    "alignItems": "center",
    "gap": "10px 16px",
    "padding": "12px 16px",
    "marginBottom": "16px",
    "borderRadius": "8px",
    "border": "1px solid rgba(230, 126, 34, 0.45)",
    "backgroundColor": "rgba(230, 126, 34, 0.12)",
    "fontSize": "14px",
    "fontWeight": "600",
    "color": "#9a3412",
}

_BANNER_WAIT = {
    **_BANNER_LIVE,
    "border": "1px solid rgba(148, 163, 184, 0.55)",
    "backgroundColor": "rgba(148, 163, 184, 0.12)",
    "color": "#475569",
}

_BANNER_ERR = {
    **_BANNER_LIVE,
    "border": "1px solid rgba(178, 58, 72, 0.45)",
    "backgroundColor": "rgba(178, 58, 72, 0.10)",
    "color": "#b23a48",
}


def parse_fetched_at(live_store: Optional[dict]) -> Optional[str]:
    if not live_store or not live_store.get("fetched_at"):
        return None
    try:
        ts = datetime.fromisoformat(
            str(live_store["fetched_at"]).replace("Z", "+00:00"))
        return ts.strftime("%H:%M UTC")
    except Exception:
        return str(live_store["fetched_at"])


def mark_date_from_store(live_store: Optional[dict]) -> pd.Timestamp:
    """Calendar date for plotting the BBG live marker (fetch day, else today)."""
    if live_store and live_store.get("fetched_at"):
        try:
            ts = datetime.fromisoformat(
                str(live_store["fetched_at"]).replace("Z", "+00:00"))
            return pd.Timestamp(ts).normalize()
        except Exception:
            pass
    return pd.Timestamp.now().normalize()


def build_live_banner(
    price_source: str,
    live_store: Optional[dict[str, Any]],
    live_mode: bool = False,
) -> Any:
    """Prominent Bloomberg query-time banner for the spreads pages.

    Shown only when Bloomberg live is selected; empty otherwise.
    """
    from dash import html

    if price_source != "live":
        return None

    err = (live_store or {}).get("error")
    marks = (live_store or {}).get("marks") or {}
    if live_mode and marks:
        fetched = parse_fetched_at(live_store) or "?"
        n_priced = (live_store or {}).get("n_priced", len(marks))
        n_missing = (live_store or {}).get("n_missing", 0)
        detail = f"{n_priced} spreads priced"
        if n_missing:
            detail += f" · {n_missing} missing"
        return html.Div(
            style=_BANNER_LIVE,
            children=[
                html.Span("Bloomberg live"),
                html.Span(
                    f"as of {fetched}",
                    style={"fontSize": "18px", "fontWeight": "700",
                           "letterSpacing": "0.02em"},
                ),
                html.Span(detail, style={"fontWeight": "500"}),
            ],
        )

    if err:
        return html.Div(
            style=_BANNER_ERR,
            children=[
                html.Span("Bloomberg live fetch failed"),
                html.Span(str(err), style={"fontWeight": "500"}),
            ],
        )

    return html.Div(
        style=_BANNER_WAIT,
        children=[
            html.Span("Bloomberg live selected"),
            html.Span(
                "Click Fetch live prices to query BPIPE",
                style={"fontWeight": "500"},
            ),
        ],
    )


def apply_dod_highlight_flags(df: pd.DataFrame,
                              threshold: float = DOD_Z_EXTREME) -> pd.DataFrame:
    """Add ``dod_extreme`` (bool) from ``dod_z``."""
    if df is None or df.empty:
        return df
    out = df.copy()
    if "dod_z" not in out.columns:
        out["dod_z"] = np.nan
        out["dod_extreme"] = False
        return out
    out["dod_extreme"] = out["dod_z"].abs() >= threshold
    return out


def dod_highlight_styles(records: list[dict]) -> list[dict]:
    """Conditional DataTable styles for outsized Δ-vs-settle cells."""
    styles: list[dict] = []
    for rec in records:
        if not rec.get("dod_extreme"):
            continue
        row_filter = f'{{id}} = "{rec["id"]}"'
        for col in ("dod", "dod_z"):
            if col not in rec or rec.get(col) is None:
                continue
            styles.append({
                "if": {"filter_query": row_filter, "column_id": col},
                "backgroundColor": DOD_MOVE_BG,
                "fontWeight": "700",
                "border": f"1px solid {DOD_MOVE_BORDER}",
            })
    return styles


def top_dod_movers(res: pd.DataFrame, n: int = 3) -> list[str]:
    """Short labels for the largest |dod_z| movers (for the status line)."""
    if res is None or res.empty or "dod_z" not in res.columns:
        return []
    sub = res.dropna(subset=["dod_z"]).copy()
    if sub.empty:
        return []
    sub = sub.reindex(sub["dod_z"].abs().sort_values(ascending=False).index)
    labels = []
    for _, row in sub.head(n).iterrows():
        legs = row.get("legs", "")
        dod = row.get("dod", np.nan)
        dz = row.get("dod_z", np.nan)
        if pd.isna(dod) or pd.isna(dz):
            continue
        labels.append(f"{legs} {dod:+.2f} (Δz {dz:+.1f})")
    return labels
