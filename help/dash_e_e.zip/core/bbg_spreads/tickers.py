"""Bloomberg ticker construction for TTF / JKM / TFU spreads.

Native calendar codes are preferred for first-order same-product pairs
(e.g. May-27/Jun-27 -> ``TZTK7M7 Comdty``).  Flies, spread-of-spreads,
basis and basis-of-basis are always implied from weighted outrights.
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd

# Bloomberg futures month codes (standard CME/ICE convention).
MONTH_CODES = {
    1: "F", 2: "G", 3: "H", 4: "J", 5: "K", 6: "M",
    7: "N", 8: "Q", 9: "U", 10: "V", 11: "X", 12: "Z",
}

_MONTH_ABBR_TO_NUM = {m: i for i, m in enumerate(calendar.month_abbr) if m}

# Anchor month for coarse strips (quarter / season / calendar).
_LABEL_ANCHOR_MONTH = {
    "Q1": 1, "Q2": 4, "Q3": 7, "Q4": 10,
    "Summer": 4, "Winter": 10,
    "Cal": 1,
}
_LABEL_ANCHOR_MONTH.update({abbr: num for abbr, num in _MONTH_ABBR_TO_NUM.items()})

# Product + granularity -> BBG root.
_OUTRIGHT_ROOTS = {
    ("TTF", "Month"): "TZT",
    ("TTF", "Quarter"): "QZT",
    ("TTF", "Season"): "QQT",
    ("TTF", "Year"): "QTT",
    ("JKM", "Month"): "JKM",
    ("TFU", "Month"): "TFU",
}

# Cadence -> root for native TTF calendar-spread tickers on the monitor page.
_CADENCE_ROOT = {
    "M/M": "TZT",
    "Q/Q": "QZT",
    "Sum/Win": "QQT",
    "Win/Win": "QQT",
    "Sum/Sum": "QQT",
    "Cal/Cal": "QTT",
}

# Low-beta first-order pair types that may use a native calendar ticker.
_NATIVE_PAIR_TYPES = frozenset({"TTF pair", "JKM pair"})


@dataclass
class LegRequest:
    """One Bloomberg security with a signed weight in a structure."""
    ticker: str
    weight: float = 1.0


@dataclass
class SpreadPriceRequest:
    """How to obtain a live mark for one monitored spread."""
    key: str
    # Preferred: native calendar (or single) ticker queried directly.
    primary: Optional[str] = None
    # Fallback / implied: weighted sum of outrights.
    legs: list[LegRequest] = field(default_factory=list)
    # All tickers that must be fetched for this request.
    tickers: list[str] = field(default_factory=list)

    def __post_init__(self):
        seen: list[str] = []
        for t in ([self.primary] if self.primary else []) + [leg.ticker for leg in self.legs]:
            if t and t not in seen:
                seen.append(t)
        self.tickers = seen


def year_digit(year: int) -> str:
    """Bloomberg TTF-style year code: 1 digit from 2025 onward, else 2."""
    return str(year)[-1:] if year >= 2025 else str(year)[-2:]


def granularity_of(label: str) -> Optional[str]:
    if label in _MONTH_ABBR_TO_NUM:
        return "Month"
    if label in ("Q1", "Q2", "Q3", "Q4"):
        return "Quarter"
    if label in ("Summer", "Winter"):
        return "Season"
    if label == "Cal":
        return "Year"
    return None


def anchor_month(label: str) -> Optional[int]:
    return _LABEL_ANCHOR_MONTH.get(label)


def outright_ticker(product: str, label: str, year: int) -> Optional[str]:
    """Build an outright BBG ticker, e.g. ``TZTK7 Comdty``."""
    gran = granularity_of(label)
    if gran is None:
        return None
    root = _OUTRIGHT_ROOTS.get((product, gran))
    month = anchor_month(label)
    if root is None or month is None:
        return None
    return f"{root}{MONTH_CODES[month]}{year_digit(year)} Comdty"


def calendar_ticker(root: str, label1: str, year1: int,
                    label2: str, year2: int) -> Optional[str]:
    """Native calendar-spread ticker, e.g. ``TZTK7M7 Comdty``."""
    m1, m2 = anchor_month(label1), anchor_month(label2)
    if m1 is None or m2 is None:
        return None
    return (f"{root}{MONTH_CODES[m1]}{year_digit(year1)}"
            f"{MONTH_CODES[m2]}{year_digit(year2)} Comdty")


def _pair_request(key: str, product: str, label1: str, year1: int,
                  label2: str, year2: int,
                  root: Optional[str] = None) -> SpreadPriceRequest:
    """First-order pair: prefer native calendar, fall back to two outrights."""
    gran = granularity_of(label1)
    if root is None and gran is not None:
        root = _OUTRIGHT_ROOTS.get((product, gran))
    primary = calendar_ticker(root, label1, year1, label2, year2) if root else None
    front = outright_ticker(product, label1, year1)
    back = outright_ticker(product, label2, year2)
    legs: list[LegRequest] = []
    if front:
        legs.append(LegRequest(front, 1.0))
    if back:
        legs.append(LegRequest(back, -1.0))
    return SpreadPriceRequest(key=key, primary=primary, legs=legs)


def build_ttf_spread_requests(histories: list[dict], key_fn) -> list[SpreadPriceRequest]:
    """One request per TTF Spreads Monitor history entry."""
    out: list[SpreadPriceRequest] = []
    for entry in histories:
        key = key_fn(entry)
        root = _CADENCE_ROOT.get(entry["cadence"])
        out.append(_pair_request(
            key, "TTF",
            entry["front_label"], int(entry["front_year"]),
            entry["back_label"], int(entry["back_year"]),
            root=root,
        ))
    return out


def _anchor_year(label: str, as_of: pd.Timestamp, rank: int) -> int:
    """Delivery year of the ``rank``-th still-to-deliver ``label`` on ``as_of``."""
    from jain_commods.core.analytics.spread_beta import _base_years
    idx = pd.DatetimeIndex([pd.Timestamp(as_of)])
    return int(_base_years(label, idx, rank=rank)[0])


def _resolve_weighted_legs(entry: dict, as_of: pd.Timestamp) -> list[tuple[str, str, int, float]]:
    """Expand history legs to absolute (product, label, year, weight)."""
    anchor_label = entry["anchor_label"]
    rank = int(entry.get("rank") or 1)
    base_year = _anchor_year(anchor_label, as_of, rank)
    resolved = []
    for product, label, year_offset, weight in entry["legs"]:
        resolved.append((product, label, int(base_year + year_offset), float(weight)))
    return resolved


def _is_simple_pair(resolved: list[tuple[str, str, int, float]]) -> bool:
    """True if exactly two legs of the same product with weights +1 / -1."""
    if len(resolved) != 2:
        return False
    (p1, _, _, w1), (p2, _, _, w2) = resolved
    if p1 != p2:
        return False
    weights = sorted([w1, w2])
    return weights == [-1.0, 1.0]


def build_low_beta_requests(histories: list[dict],
                            as_of: pd.Timestamp) -> list[SpreadPriceRequest]:
    """One request per Low-Beta history entry (native calendar or implied)."""
    as_of = pd.Timestamp(as_of)
    out: list[SpreadPriceRequest] = []

    for entry in histories:
        key = entry["key"]
        resolved = _resolve_weighted_legs(entry, as_of)
        spread_type = entry.get("spread_type")

        if (spread_type in _NATIVE_PAIR_TYPES
                and _is_simple_pair(resolved)):
            # Orient so weight +1 is front of the calendar ticker.
            by_weight = {w: (p, lab, yr) for p, lab, yr, w in resolved}
            product, lab1, yr1 = by_weight[1.0]
            _, lab2, yr2 = by_weight[-1.0]
            out.append(_pair_request(key, product, lab1, yr1, lab2, yr2))
            continue

        legs: list[LegRequest] = []
        for product, label, year, weight in resolved:
            ticker = outright_ticker(product, label, year)
            if ticker is None:
                legs = []
                break
            legs.append(LegRequest(ticker, weight))
        out.append(SpreadPriceRequest(key=key, primary=None, legs=legs))

    return out


def collect_tickers(requests: list[SpreadPriceRequest]) -> list[str]:
    """Unique tickers across all requests, stable order."""
    seen: list[str] = []
    for req in requests:
        for t in req.tickers:
            if t not in seen:
                seen.append(t)
    return seen


def fm_outright_tickers(as_of, include_usd: bool = True) -> list[str]:
    """Bloomberg outright tickers for TTF (and TFU) front-month on ``as_of``."""
    import calendar

    live = pd.Timestamp(as_of)
    m0 = pd.Period(live, freq="M")
    label = calendar.month_abbr[(m0 + 1).month]
    year = int((m0 + 1).year)
    out: list[str] = []
    for product in ("TTF", "TFU") if include_usd else ("TTF",):
        ticker = outright_ticker(product, label, year)
        if ticker:
            out.append(ticker)
    return out
