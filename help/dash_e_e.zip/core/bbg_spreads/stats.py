"""Overlay Bloomberg live marks onto settlement-based spread stats."""
from __future__ import annotations

from typing import Callable, Optional

import numpy as np
import pandas as pd

from core.bbg_spreads.highlights import apply_dod_highlight_flags

CRISIS_YEARS_DEFAULT = (2021, 2022)


def _filtered_hist(series: pd.Series,
                   as_of: pd.Timestamp,
                   exclude_crisis: bool,
                   crisis_years,
                   history_start: Optional[pd.Timestamp]) -> pd.Series:
    hist = series
    if history_start is not None:
        hist = hist[(hist.index >= pd.Timestamp(history_start))
                    | (hist.index == as_of)]
    if exclude_crisis:
        hist = hist[~hist.index.year.isin(crisis_years)]
    return hist


def _level_stats(hist: pd.Series, live: float, z_method: str = "standard"):
    from jain_commods.core.analytics.spreads import _z_scores, classify_flag

    z_standard, z_robust, center = _z_scores(hist, live, z_method=z_method)
    z = z_robust if z_method == "robust" else z_standard
    pct = float((hist <= live).mean() * 100.0)
    return {
        "z": z,
        "z_standard": z_standard,
        "z_robust": z_robust,
        "pct": pct,
        "mean": center,
        "flag": classify_flag(z, pct),
        "n": int(hist.count()),
    }


def _dod_z(hist: pd.Series, dod: float) -> float:
    changes = hist.diff().dropna()
    if changes.empty:
        return np.nan
    std = float(changes.std(ddof=1))
    if not std or np.isnan(std):
        return np.nan
    return float(dod) / std


def _histories_by_key(histories: list[dict], key_fn: Callable) -> dict[str, dict]:
    return {key_fn(entry): entry for entry in histories}


def overlay_live_marks_ttf(
    stats: pd.DataFrame,
    histories: list[dict],
    as_of,
    live_marks: dict[str, float],
    key_fn: Callable,
    exclude_crisis: bool = True,
    crisis_years=CRISIS_YEARS_DEFAULT,
    history_start: Optional[pd.Timestamp] = None,
) -> pd.DataFrame:
    """Replace settle ``live`` with BBG marks; DoD = live − last settle.

    Rows without a mark keep settlement values.  Adds ``settle``, ``dod_z``,
    ``price_source`` columns and recomputes level z / %ile / flag.
    """
    if stats is None or stats.empty:
        return stats

    as_of = pd.Timestamp(as_of)
    by_key = _histories_by_key(histories, key_fn)
    rows = []

    for _, row in stats.iterrows():
        rec = row.to_dict()
        key = key_fn(row)
        settle = float(rec["live"])
        rec["settle"] = settle
        rec["price_source"] = "settle"

        mark = live_marks.get(key)
        entry = by_key.get(key)
        if mark is None or entry is None:
            rec["dod_z"] = np.nan
            rows.append(rec)
            continue

        series = entry["series"]
        if as_of in series.index:
            settle = float(series.loc[as_of])
            rec["settle"] = settle

        live = float(mark)
        dod = live - settle
        hist = _filtered_hist(
            series, as_of, exclude_crisis, crisis_years, history_start,
        )
        level = _level_stats(hist, live)
        rec.update(level)
        rec["live"] = live
        rec["dod"] = dod
        rec["dod_z"] = _dod_z(hist, dod)
        rec["price_source"] = "bbg"
        # YTD / ATH / ATL stay settlement-series extrema; extreme flag uses
        # the live-level z / percentile.
        rec["extreme"] = (
            abs(rec["z"]) >= 1.5
            or rec["pct"] >= 90
            or rec["pct"] <= 10
        )
        rows.append(rec)

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["absz"] = out["z"].abs()
    out = out.sort_values("absz", ascending=False).reset_index(drop=True)
    return apply_dod_highlight_flags(out)


def overlay_live_marks_low_beta(
    stats: pd.DataFrame,
    histories: list[dict],
    as_of,
    live_marks: dict[str, float],
    exclude_crisis: bool = True,
    crisis_years=CRISIS_YEARS_DEFAULT,
) -> pd.DataFrame:
    """Overlay live marks on low-beta level stats; keep beta/corr/r2/vol."""
    if stats is None or stats.empty:
        return stats

    as_of = pd.Timestamp(as_of)
    by_key = {entry["key"]: entry for entry in histories}
    rows = []

    for _, row in stats.iterrows():
        rec = row.to_dict()
        key = rec["key"]
        settle = float(rec["live"])
        rec["settle"] = settle
        rec["price_source"] = "settle"

        mark = live_marks.get(key)
        entry = by_key.get(key)
        if mark is None or entry is None:
            rec["dod_z"] = np.nan
            rows.append(rec)
            continue

        series = entry["series"]
        # Prefer the settle on as_of; else last available settle in series.
        if as_of in series.index:
            settle = float(series.loc[as_of])
        else:
            settle = float(series.iloc[-1])
        rec["settle"] = settle

        live = float(mark)
        dod = live - settle
        hist = _filtered_hist(
            series, as_of if as_of in series.index else series.index[-1],
            exclude_crisis, crisis_years, history_start=None,
        )
        level = _level_stats(hist, live)
        rec.update(level)
        rec["live"] = live
        rec["dod"] = dod
        rec["dod_z"] = _dod_z(hist, dod)
        rec["price_source"] = "bbg"
        # beta / corr / r2 / vol / n_reg left untouched from settlement OLS.
        rows.append(rec)

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["abs_corr"] = out["corr"].abs()
    out["absz"] = out["z"].abs()
    out = out.sort_values("abs_corr", ascending=True).reset_index(drop=True)
    return apply_dod_highlight_flags(out)
