"""Dash callbacks for the fuel-switching page.

Importing this module registers all callbacks against the global Dash app via
the ``@callback`` decorator. Component IDs are intentionally identical to the
pre-split values.
"""

from __future__ import annotations

import logging
import threading

import dash
import pandas as pd
from dash import Input, Output, State, callback, html

from core import data as data_service
from core.toast_manager import make_toast
from core.fuel_switching.charts import (
    build_fuels_chart,
    build_main_switching_chart,
    build_srmc_spread_chart,
    make_empty_chart,
)
from core.fuel_switching.compute import calculator, compute_historical_srmc
from core.fuel_switching.constants import (
    DEFAULT_COAL_EFFS,
    DEFAULT_GAS_EFFS,
    DEFAULT_LIGNITE_EFFS,
)
from core.fuel_switching.data import market_cache
from core.fuel_switching.layout import URL_LOCATION_ID
from core.state import (
    UrlControl,
    encode_list,
    parse_float_list,
    register as register_url_sync,
)

logger = logging.getLogger(__name__)


# -----------------------------------------------------------------------------
# URL-state sync
# -----------------------------------------------------------------------------
# ``settlement-date-dropdown.value`` is intentionally NOT URL-synced because
# it is already an Output of :func:`update_settlement_dates`; round-tripping
# it would require coordinated ``allow_duplicate=True`` flags across both
# callbacks.  The four controls below cover the high-value bookmarkable state
# (chosen hubs + the three efficiency bands).
URL_CONTROLS = [
    UrlControl("power-hub-dropdown", "value"),
    UrlControl("gas-hub-dropdown", "value"),
    UrlControl(
        "gas-eff-slider", "value", parse=parse_float_list, encode=encode_list
    ),
    UrlControl(
        "coal-eff-slider", "value", parse=parse_float_list, encode=encode_list
    ),
    UrlControl(
        "lignite-eff-slider", "value", parse=parse_float_list, encode=encode_list
    ),
]
register_url_sync(URL_LOCATION_ID, URL_CONTROLS)


def _ensure_data_loaded():
    """Lazily trigger the central scheduler load on first page visit."""
    if market_cache.last_refresh is not None:
        return
    if market_cache.is_loading:
        return
    data_service.get_fuel_switching()


# ---------------------------------------------------------------------------
# Display callbacks (efficiency labels, UK banner)
# ---------------------------------------------------------------------------

@callback(Output('gas-eff-display', 'children'), Input('gas-eff-slider', 'value'))
def update_gas_eff_display(values):
    if len(values) == 3:
        return f"{int(values[0]*100)}%, {int(values[1]*100)}%, {int(values[2]*100)}%"
    return f"{int(min(values)*100)}% - {int(max(values)*100)}%"


@callback(Output('coal-eff-display', 'children'), Input('coal-eff-slider', 'value'))
def update_coal_eff_display(values):
    return f"{int(values[0]*100)}%, {int(values[1]*100)}%"


@callback(Output('lignite-eff-display', 'children'), Input('lignite-eff-slider', 'value'))
def update_lignite_eff_display(values):
    return f"{int(values[0]*100)}%, {int(values[1]*100)}%"


@callback(Output('uk-info-banner', 'children'), Input('gas-hub-dropdown', 'value'))
def update_uk_banner(gas_hub):
    if gas_hub == 'NBP':
        return html.Div([
            "🇬🇧 UK Mode: NBP gas, UKA carbon + £18/t CPF. Values in £/MWh."
        ], className="info-banner")
    return None


# ---------------------------------------------------------------------------
# Cache status badge + refresh button
# ---------------------------------------------------------------------------

@callback(
    Output('cache-status-badge', 'children'),
    Output('cache-status-badge', 'style'),
    [Input('refresh-btn', 'n_clicks'),
     Input('status-interval', 'n_intervals')],
)
def update_cache_status(n_clicks, n_intervals):
    """Handle refresh button and update status badge."""
    ctx = dash.callback_context
    triggered = ctx.triggered[0]['prop_id'] if ctx.triggered else ''

    base_style = {
        'display': 'inline-block',
        'padding': '8px 14px',
        'borderRadius': '20px',
        'fontSize': '12px',
        'fontWeight': '500',
    }

    if 'refresh-btn' in triggered and n_clicks > 0:
        threading.Thread(
            target=data_service.force_refresh,
            args=(data_service.SOURCE_FUEL_SWITCHING,),
            daemon=True,
        ).start()
        return "⟳ Loading...", {**base_style, 'backgroundColor': 'rgba(210, 153, 34, 0.1)', 'color': '#b08800', 'border': '1px solid rgba(210, 153, 34, 0.3)'}

    if market_cache.is_loading:
        return "⟳ Loading...", {**base_style, 'backgroundColor': 'rgba(210, 153, 34, 0.1)', 'color': '#b08800', 'border': '1px solid rgba(210, 153, 34, 0.3)'}

    if market_cache.last_refresh:
        time_str = market_cache.last_refresh.strftime('%H:%M:%S')
        return f"✓ Loaded at {time_str}", {**base_style, 'backgroundColor': '#e6f4ea', 'color': '#2ea043', 'border': '1px solid rgba(46, 160, 67, 0.3)'}

    return "○ Not loaded", {**base_style, 'backgroundColor': 'rgba(210, 153, 34, 0.1)', 'color': '#b08800', 'border': '1px solid rgba(210, 153, 34, 0.3)'}


# ---------------------------------------------------------------------------
# Settlement-date dropdown
# ---------------------------------------------------------------------------

@callback(
    Output('settlement-date-dropdown', 'options'),
    Output('settlement-date-dropdown', 'value'),
    Input('refresh-btn', 'n_clicks'),
    Input('status-interval', 'n_intervals'),
    State('settlement-date-dropdown', 'value'),
)
def update_settlement_dates(_n_clicks, _n_intervals, current_value):
    """Populate settlement-date options from complete forward bundles."""
    _ensure_data_loaded()
    options, default_settlement = market_cache.get_settlement_date_options()
    if not options:
        return [], None
    valid_values = {opt['value'] for opt in options}
    selected = current_value if current_value in valid_values else default_settlement
    if selected not in valid_values:
        selected = options[0]['value']
    return options, selected


# ---------------------------------------------------------------------------
# Main chart callback
# ---------------------------------------------------------------------------

def _is_default_view(power_hub, gas_hub, gas_effs, coal_effs, lignite_effs, settlement_date):
    return (
        power_hub == 'DE' and gas_hub == 'TTF'
        and list(gas_effs or []) == DEFAULT_GAS_EFFS
        and list(coal_effs or []) == DEFAULT_COAL_EFFS
        and list(lignite_effs or []) == DEFAULT_LIGNITE_EFFS
        and market_cache.is_complete_settlement_date(settlement_date)
    )


@callback(
    [Output('switching-graph', 'figure'),
     Output('fuels-graph', 'figure'),
     Output('srmc-spread-graph', 'figure'),
     Output('fx-rate-display', 'children'),
     Output('chart-subtitle', 'children'),
     Output('toast-store', 'data', allow_duplicate=True)],
    [Input('settlement-date-dropdown', 'value'),
     Input('power-hub-dropdown', 'value'),
     Input('gas-hub-dropdown', 'value'),
     Input('gas-eff-slider', 'value'),
     Input('coal-eff-slider', 'value'),
     Input('lignite-eff-slider', 'value'),
     Input('refresh-btn', 'n_clicks')],
    State('toast-store', 'data'),
    prevent_initial_call=True,
)
def update_graphs(settlement_date, power_hub, gas_hub, gas_effs, coal_effs, lignite_effs, _refresh_clicks, current_toasts):
    """Update charts from cached data (no S3 reads)."""
    _ensure_data_loaded()
    current_toasts = current_toasts or []

    # ── Fast path: pre-built default figure from fast_cache ──
    if _is_default_view(power_hub, gas_hub, gas_effs, coal_effs, lignite_effs, settlement_date):
        try:
            from core.fast_cache import figure_cache as _fc
            prebuilt = _fc.get_figure("fuel_switching:DE:TTF:default")
            if prebuilt is not None:
                usd_local = market_cache.get_fx_rate('USD/EUR') or 0.96
                subtitle = (
                    f"Settlement: {settlement_date} | Power: DE | Gas: TTF | Carbon: EUA"
                )
                df = market_cache.get_forward_data('DE', 'TTF', settlement_date=settlement_date)
                hist_df = market_cache.get_spot_data('DE', 'TTF')
                fig_fuels = build_fuels_chart(df, hist_df, 'TTF', currency='€')
                df_srmc = calculator.calculate_srmc(
                    df.copy(), DEFAULT_GAS_EFFS, DEFAULT_COAL_EFFS, DEFAULT_LIGNITE_EFFS,
                    lignite_fuel_cost=1.5,
                )
                if hist_df is not None and not hist_df.empty:
                    _h = hist_df.copy()
                    _d_col = 'date' if 'date' in _h.columns else 'DATE'
                    _h['date'] = pd.to_datetime(_h[_d_col])
                    _h = _h[_h['date'] >= pd.Timestamp('2023-01-01')]
                    hist_srmc = compute_historical_srmc(
                        _h, DEFAULT_GAS_EFFS, DEFAULT_COAL_EFFS, DEFAULT_LIGNITE_EFFS,
                        lignite_fuel_cost=1.5,
                    )
                else:
                    hist_srmc = hist_df
                fig_spread = build_srmc_spread_chart(
                    df_srmc, hist_srmc, DEFAULT_GAS_EFFS, DEFAULT_COAL_EFFS, DEFAULT_LIGNITE_EFFS,
                )
                logger.debug("fuel_switching: serving default figure from fast_cache")
                return (
                    prebuilt,
                    fig_fuels,
                    fig_spread,
                    f"USD/EUR: {usd_local:.4f}",
                    subtitle,
                    dash.no_update,
                )
        except Exception as _exc:  # never break the slow path
            logger.debug("fuel_switching fast-path miss: %s", _exc)

    def _push_toast(message: str, level: str = 'warning'):
        if current_toasts:
            last = current_toasts[-1]
            if last.get('message') == message and last.get('level') == level and last.get('source') == 'Fuel Switching':
                return current_toasts
        return current_toasts + [make_toast(message, level=level, source='Fuel Switching')]

    is_uk_mode = gas_hub == 'NBP'
    currency = '£' if is_uk_mode else '€'

    if not market_cache.is_complete_settlement_date(settlement_date):
        msg = (
            f"No complete forward bundle for settlement date {settlement_date}. "
            "Choose another settlement date or refresh from S3."
            if settlement_date
            else "No settlement date selected."
        )
        empty_fig = make_empty_chart(msg)
        return (
            empty_fig,
            empty_fig,
            empty_fig,
            "No data",
            f"{power_hub} | {gas_hub} | Settlement: {settlement_date or 'N/A'}",
            _push_toast(msg, level='warning'),
        )

    effective_settlement = settlement_date
    df = market_cache.get_forward_data(power_hub, gas_hub, settlement_date=effective_settlement)
    hist_df = market_cache.get_spot_data(power_hub, gas_hub)

    if df.empty:
        msg = f"No forward data available for settlement date {settlement_date} ({power_hub}/{gas_hub})."
        empty_fig = make_empty_chart(msg)
        return (
            empty_fig,
            empty_fig,
            empty_fig,
            "No data",
            f"{power_hub} | {gas_hub} | Settlement: {settlement_date or 'N/A'}",
            _push_toast(msg, level='warning'),
        )

    # Forward SRMC bands (mutates df in-place per existing semantics)
    df = calculator.calculate_srmc(df.copy(), gas_effs, coal_effs, lignite_effs, lignite_fuel_cost=1.5)

    toasts = dash.no_update
    if 'Power' not in df.columns:
        toasts = _push_toast(
            f"No forward power curve for {power_hub} at settlement {effective_settlement} — "
            "showing fuel SRMC bands only.",
            level='warning',
        )

    # Historical: filter to 2023+, smooth power, recompute SRMC bands at user effs
    if not hist_df.empty:
        hist_df = hist_df.copy()
        d_col = 'date' if 'date' in hist_df.columns else 'DATE'
        hist_df['date'] = pd.to_datetime(hist_df[d_col])
        hist_df = hist_df[hist_df['date'] >= pd.Timestamp('2023-01-01')]
        if 'Power' in hist_df.columns:
            hist_df['Power_Rolling'] = hist_df['Power'].rolling(14).mean()
        hist_df = compute_historical_srmc(
            hist_df, gas_effs, coal_effs, lignite_effs,
            lignite_fuel_cost=1.5, is_uk_mode=is_uk_mode,
        )

    fig = build_main_switching_chart(
        df, hist_df, power_hub, gas_hub, gas_effs, coal_effs, lignite_effs, currency=currency,
    )
    fig_fuels = build_fuels_chart(df, hist_df, gas_hub, currency=currency, is_uk_mode=is_uk_mode)
    fig_spread = build_srmc_spread_chart(
        df, hist_df, gas_effs, coal_effs, lignite_effs, currency=currency,
    )

    usd_local = df['USD_TO_LOCAL'].iloc[-1] if 'USD_TO_LOCAL' in df.columns else (1.37 if is_uk_mode else 0.96)
    fx_display = f"USD/{'GBP' if is_uk_mode else 'EUR'}: {usd_local:.4f}"
    carbon_label = "UKA + £18 CPF" if is_uk_mode else "EUA"
    chart_subtitle = (
        f"Settlement: {effective_settlement} | Power: {power_hub} | "
        f"Gas: {gas_hub} | Carbon: {carbon_label}"
    )

    return fig, fig_fuels, fig_spread, fx_display, chart_subtitle, toasts
