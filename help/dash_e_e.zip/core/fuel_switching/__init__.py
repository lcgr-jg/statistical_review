"""
Fuel-switching dashboard package.

Sub-modules (import them explicitly to avoid pulling heavy deps for tests):

    * ``constants``  -- magic numbers, colour palette, default control values
    * ``data``       -- ``MarketDataCache`` data model + ``market_cache``
                       singleton (depends on ``jain_commods`` / S3)
    * ``compute``    -- pure SRMC math (``FuelSwitchingCalculator``); no I/O
    * ``charts``     -- pure Plotly figure builders
    * ``layout``     -- ``build_layout()`` (pure)
    * ``callbacks``  -- Dash callbacks (registered on import)

This file is intentionally side-effect-free: importing
``core.fuel_switching`` *does not* import ``data`` (which would pull in
the heavy commodity-data deps).  Tests targeting ``compute`` can import
it directly without needing the production data stack installed.
"""
