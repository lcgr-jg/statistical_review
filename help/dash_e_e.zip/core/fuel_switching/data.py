"""Fuel-switching data layer.

Owns ``MarketDataCache`` (a typed data model, not a separate cache layer)
and the ``market_cache`` singleton + ``load_market_data`` loader function
that the central ``DataScheduler`` registers.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta
from typing import Optional

import pandas as pd
from dateutil.relativedelta import relativedelta

from jain_commods.fundamental.power.price_functions import FuelSpreadsCalculator
from jain_commods.core.cache.data.market import (
    PricePowerForward,
    PriceGasForward,
    PriceCoalForward,
    PriceCO2Forward,
    ForexSpot,
    PricePowerSpot,
    PriceGasSpot,
    PriceCO2Spot,
    PriceCoalSpot,
)

from core.data_freshness import tracker
from core.fuel_switching.constants import (
    API2_TO_MWH,
    GAS_HUBS,
    MAX_SETTLEMENT_LOOKBACK_DAYS,
    NBP_TO_GBP_MWH,
    POWER_HUBS,
    UK_CARBON_PRICE_FLOOR,
    GAS_EMISSIONS,
    COAL_EMISSIONS,
    LIG_EMISSION_FACTOR,
    LIG_FUEL_COST,
)

logger = logging.getLogger(__name__)


class MarketDataCache:
    """
    Thread-safe server-side store for all fuel-switching market data.
    Loads ALL hubs at once, so hub switching is instant.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._data = {
            'forward': {},
            'spot': {},
            'fx_rates': {},
            'raw': {
                'power_forward': None,
                'gas_forward': None,
                'coal_forward': None,
                'co2_forward': None,
                'power_spot': None,
                'gas_spot': None,
                'coal_spot': None,
                'co2_spot': None,
                'fx_spot': None,
            },
            'forward_by_settlement': {},
            'default_settlement_date': None,
            'last_refresh': None,
            'refresh_status': 'Not loaded',
            'is_loading': False,
        }
        # Defer FuelSpreadsCalculator creation to avoid import-time failures
        # that silently prevent callback registration in Dash multi-page apps.
        self._calc = None

    # ------------------------------------------------------------------
    # Pickle support
    # ------------------------------------------------------------------
    # ``threading.RLock`` objects can't be pickled, which is what diskcache
    # uses under the hood when persisting the cache tier.  Without custom
    # ``__getstate__`` / ``__setstate__`` the disk write fails on every
    # refresh and we lose cache persistence across process restarts.
    # Strip the lock (and the lazy-built calculator) on pickle and rebuild
    # them on unpickle.
    def __getstate__(self):
        state = self.__dict__.copy()
        state.pop('_lock', None)
        state.pop('_calc', None)
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._lock = threading.RLock()
        self._calc = None

    @property
    def calc(self):
        if self._calc is None:
            self._calc = FuelSpreadsCalculator()
        return self._calc

    @property
    def last_refresh(self) -> Optional[datetime]:
        with self._lock:
            return self._data['last_refresh']

    @property
    def refresh_status(self) -> str:
        with self._lock:
            return self._data['refresh_status']

    @property
    def is_loading(self) -> bool:
        with self._lock:
            return self._data['is_loading']

    def get_fx_rate(self, pair: str) -> float:
        with self._lock:
            return self._data['fx_rates'].get(pair, 1.0)

    def _get_last_business_day(self):
        today = datetime.now().date()
        if today.weekday() == 0:
            return today - timedelta(days=3)
        elif today.weekday() == 6:
            return today - timedelta(days=2)
        elif today.weekday() == 5:
            return today - timedelta(days=1)
        else:
            return today - timedelta(days=1)

    @staticmethod
    def _business_days_back(start_date, max_days: int):
        candidate = start_date
        produced = 0
        while produced < max_days:
            if candidate.weekday() < 5:
                yield candidate
                produced += 1
            candidate -= timedelta(days=1)

    def _load_forward_bundle_for_date(self, trade_date) -> Optional[dict]:
        """Load ALL forward curves for one settlement date; return None if any is missing."""
        specs = [
            ('power_forward', lambda: PricePowerForward(country_code='DE'), 'Power forward'),
            ('gas_forward', lambda: PriceGasForward(), 'Gas forward'),
            ('coal_forward', lambda: PriceCoalForward(), 'Coal forward'),
            ('co2_forward', lambda: PriceCO2Forward(), 'CO2 forward'),
        ]
        bundle = {}
        missing = []
        for key, make_obj, label in specs:
            loaded = False
            attempts = (trade_date, None) if trade_date is not None else (None,)
            for td in attempts:
                try:
                    fwd_obj = make_obj()
                    fwd_obj.load(from_s3=True, trade_date=td, show_metadata=False)
                    if fwd_obj.data is not None and not fwd_obj.data.empty:
                        bundle[key] = fwd_obj.data.copy()
                        if td is None and trade_date is not None:
                            logger.info(
                                "  %s: dated load failed for %s, used latest cache instead",
                                label, trade_date,
                            )
                        loaded = True
                        break
                except Exception:
                    continue
            if not loaded:
                missing.append(label)
        if missing:
            logger.warning(
                "Incomplete forward bundle for %s — missing: %s",
                trade_date, ", ".join(missing),
            )
            return None
        return bundle

    def _load_common_forward_settlements(self, last_bday) -> dict:
        bundles = {}
        for candidate in self._business_days_back(last_bday, MAX_SETTLEMENT_LOOKBACK_DAYS):
            loaded = self._load_forward_bundle_for_date(candidate)
            if loaded is not None:
                bundles[candidate.strftime('%Y-%m-%d')] = loaded

        if not bundles:
            logger.warning(
                "No dated forward bundles found in the last %d business days. "
                "Attempting to load latest (undated) cache as fallback.",
                MAX_SETTLEMENT_LOOKBACK_DAYS,
            )
            fallback = self._load_forward_bundle_for_date(None)
            if fallback is not None:
                key = last_bday.strftime('%Y-%m-%d')
                bundles[key] = fallback
                logger.info("  Fallback loaded successfully under key %s", key)

        return bundles

    def load_all_from_s3(self) -> bool:
        """Load ALL market data from S3 once (called by the scheduler)."""
        with self._lock:
            if self._data['is_loading']:
                logger.info("Data load already in progress, skipping...")
                return False
            self._data['is_loading'] = True
            self._data['refresh_status'] = 'Loading...'

        try:
            start_time = time.time()
            logger.info("=" * 60)
            logger.info("STARTING FULL DATA LOAD FROM S3")
            logger.info("=" * 60)

            today = datetime.now().date()
            last_bday = self._get_last_business_day()
            logger.info(f"Today: {today} ({today.strftime('%A')})")
            logger.info(f"Using trade_date for forwards: {last_bday} ({last_bday.strftime('%A')})")

            # 1. FX Rates
            logger.info("Loading FX rates...")
            try:
                fx_spot = ForexSpot()
                fx_spot.load(from_s3=True, show_metadata=False)
                if fx_spot.data is not None and not fx_spot.data.empty:
                    with self._lock:
                        self._data['raw']['fx_spot'] = fx_spot.data.copy()
                        for col in fx_spot.data.columns:
                            valid = fx_spot.data[col].dropna()
                            if not valid.empty:
                                self._data['fx_rates'][col] = valid.iloc[-1]
                            else:
                                logger.warning(f"  FX pair '{col}' has no valid data")
                    if not self._data['fx_rates']:
                        self._set_fallback_fx()
                    logger.info(f"  FX rates: {list(self._data['fx_rates'].keys())}")
                else:
                    self._set_fallback_fx()
            except Exception as e:
                logger.error(f"  Error loading FX: {e}")
                self._set_fallback_fx()

            # 2. Forward Curves
            logger.info("Loading forward curves...")
            forward_by_settlement = self._load_common_forward_settlements(last_bday)
            default_settlement = last_bday.strftime('%Y-%m-%d')
            if default_settlement not in forward_by_settlement and forward_by_settlement:
                logger.warning(
                    "  No complete forward bundle for default settlement_date=%s; latest available is %s",
                    default_settlement,
                    sorted(forward_by_settlement.keys(), reverse=True)[0],
                )
            with self._lock:
                self._data['forward_by_settlement'] = forward_by_settlement
                self._data['default_settlement_date'] = default_settlement
                if default_settlement in forward_by_settlement:
                    selected = forward_by_settlement[default_settlement]
                    for key in ('power_forward', 'gas_forward', 'coal_forward', 'co2_forward'):
                        self._data['raw'][key] = selected[key].copy()
                elif forward_by_settlement:
                    latest_available = sorted(forward_by_settlement.keys(), reverse=True)[0]
                    selected = forward_by_settlement[latest_available]
                    for key in ('power_forward', 'gas_forward', 'coal_forward', 'co2_forward'):
                        self._data['raw'][key] = selected[key].copy()
                else:
                    for key in ('power_forward', 'gas_forward', 'coal_forward', 'co2_forward'):
                        self._data['raw'][key] = None
            logger.info(
                "  Forward settlement dates available (complete bundles): %s",
                ", ".join(sorted(forward_by_settlement.keys(), reverse=True)) or "none",
            )

            # 3. Spot Data
            logger.info("Loading spot data...")
            for label, cls, key in (
                ('Power spot', PricePowerSpot, 'power_spot'),
                ('Gas spot', PriceGasSpot, 'gas_spot'),
                ('Coal spot', PriceCoalSpot, 'coal_spot'),
                ('CO2 spot', PriceCO2Spot, 'co2_spot'),
            ):
                try:
                    obj = cls()
                    obj.load(from_s3=True, show_metadata=False)
                    with self._lock:
                        self._data['raw'][key] = obj.data.copy() if obj.data is not None else None
                    logger.info(f"  {label}: {obj.data.shape if obj.data is not None else 'None'}")
                except Exception as e:
                    logger.error(f"  Error loading {label}: {e}")

            # 4. Pre-compute common hub combinations
            logger.info("Pre-computing hub combinations...")
            with self._lock:
                self._data['forward'].clear()
                self._data['spot'].clear()

            for power_hub in POWER_HUBS:
                for gas_hub in GAS_HUBS[:2]:
                    self._compute_forward_data(power_hub, gas_hub)
                    self._compute_spot_data(power_hub, gas_hub)

            elapsed = time.time() - start_time
            with self._lock:
                self._data['last_refresh'] = datetime.now()
                self._data['refresh_status'] = (
                    f"Loaded at {datetime.now().strftime('%H:%M:%S')} ({elapsed:.1f}s)"
                )
                self._data['is_loading'] = False

            tracker.register_data_source(
                "Fuel Switching - Forward Curves",
                datetime.now(),
                expected_frequency_minutes=360,
                metadata={
                    'power_hubs': len([k for k in self._data['forward'].keys()]),
                    'spot_hubs': len([k for k in self._data['spot'].keys()]),
                    'load_time': f'{elapsed:.1f}s',
                },
            )
            tracker.register_data_source(
                "Fuel Switching - FX Rates",
                datetime.now(),
                expected_frequency_minutes=60,
                metadata={'rates': list(self._data['fx_rates'].keys())},
            )

            logger.info("=" * 60)
            logger.info(f"DATA LOAD COMPLETE in {elapsed:.1f} seconds")
            logger.info("=" * 60)
            return True

        except Exception as e:
            logger.error(f"Error during data load: {e}")
            import traceback
            traceback.print_exc()
            with self._lock:
                self._data['is_loading'] = False
                self._data['refresh_status'] = f'Error: {str(e)[:50]}'
            return False

    def _set_fallback_fx(self):
        with self._lock:
            self._data['fx_rates'] = {
                'EUR/USD': 1.04, 'USD/EUR': 0.96,
                'GBP/EUR': 0.86, 'EUR/GBP': 1.16,
                'USD/GBP': 1.37, 'GBP/USD': 0.73,
            }

    def _find_column(self, df, hub_name: str):
        if df is None:
            return None
        for col in df.columns:
            if isinstance(col, tuple):
                if hub_name.lower() in [str(c).lower() for c in col]:
                    return col
            elif hub_name.lower() == str(col).lower():
                return col
        return None

    def _resolve_settlement_date(self, settlement_date: Optional[str]) -> Optional[str]:
        with self._lock:
            available = sorted(self._data['forward_by_settlement'].keys(), reverse=True)
            default_settlement = self._data.get('default_settlement_date')
        if not available:
            return None
        if settlement_date:
            return settlement_date if settlement_date in available else None
        if default_settlement in available:
            return default_settlement
        return available[0]

    def get_settlement_date_options(self):
        with self._lock:
            available = sorted(self._data['forward_by_settlement'].keys(), reverse=True)
            default_settlement = self._data.get('default_settlement_date')
        options = []
        if default_settlement and default_settlement not in available:
            options.append({'label': f"{default_settlement} (Default, incomplete)", 'value': default_settlement})
        options.extend(
            {'label': f"{d}{' (Default)' if d == default_settlement else ''}", 'value': d}
            for d in available
        )
        return options, default_settlement

    def is_complete_settlement_date(self, settlement_date: Optional[str]) -> bool:
        if not settlement_date:
            return False
        with self._lock:
            return settlement_date in self._data['forward_by_settlement']

    def _compute_forward_data(self, power_hub: str, gas_hub: str, settlement_date: Optional[str] = None) -> pd.DataFrame:
        settlement_key = self._resolve_settlement_date(settlement_date)
        if settlement_key is None:
            return pd.DataFrame()
        is_uk_mode = gas_hub == 'NBP'
        curves = {}

        with self._lock:
            raw_bundle = self._data['forward_by_settlement'].get(settlement_key, {})

            if raw_bundle.get('power_forward') is not None:
                power_col = self._find_column(raw_bundle['power_forward'], power_hub.lower())
                if power_col is not None:
                    power_ts = raw_bundle['power_forward'][power_col].copy()
                    if is_uk_mode:
                        power_ts = power_ts * self.get_fx_rate('GBP/EUR')
                    curves['Power'] = power_ts

            if raw_bundle.get('gas_forward') is not None:
                gas_col = self._find_column(raw_bundle['gas_forward'], gas_hub)
                if gas_col is not None:
                    gas_ts = raw_bundle['gas_forward'][gas_col].copy()
                    if gas_hub == 'NBP':
                        gas_ts = gas_ts * NBP_TO_GBP_MWH
                    curves['Gas'] = gas_ts

            if raw_bundle.get('coal_forward') is not None:
                coal_col = self._find_column(raw_bundle['coal_forward'], 'API2')
                if coal_col is not None:
                    curves['Coal'] = raw_bundle['coal_forward'][coal_col].copy()

            if raw_bundle.get('co2_forward') is not None:
                carbon_scheme = 'UKA' if is_uk_mode else 'EUA'
                co2_col = self._find_column(raw_bundle['co2_forward'], carbon_scheme)
                if co2_col is not None:
                    co2_ts = raw_bundle['co2_forward'][co2_col].copy()
                    if is_uk_mode:
                        co2_ts = co2_ts + UK_CARBON_PRICE_FLOOR
                    curves['Carbon'] = co2_ts

        if not curves:
            return pd.DataFrame()

        monthly_data = {}
        for comm, series in curves.items():
            if not series.empty:
                if not isinstance(series.index, pd.DatetimeIndex):
                    series.index = pd.to_datetime(series.index)
                monthly_data[comm] = series.resample('MS').mean()

        df = pd.DataFrame(monthly_data)
        if df.empty:
            return df

        if 'Carbon' in df.columns:
            df['Carbon'] = df['Carbon'].interpolate(method='linear', limit_direction='both')

        today = datetime.now()
        start_date = (today + relativedelta(months=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end_year = today.year + 1 if today.month < 11 else today.year + 2
        end_date = datetime(end_year, 12, 31)

        df = df[(df.index >= start_date) & (df.index <= end_date)].copy()

        if not df.empty:
            df['Month'] = df.index.month
            df['Year'] = df.index.year
            df['STRIP'] = df.index.strftime('%b-%y').str.upper()
            df['USD_TO_LOCAL'] = self.get_fx_rate('USD/GBP' if is_uk_mode else 'USD/EUR')

        with self._lock:
            self._data['forward'][(power_hub, gas_hub, settlement_key)] = df

        return df

    def _compute_spot_data(self, power_hub: str, gas_hub: str) -> pd.DataFrame:
        is_uk_mode = gas_hub == 'NBP'
        power_spot_code = 'GB' if power_hub == 'GB' else power_hub.upper()
        data_frames = {}

        with self._lock:
            raw = self._data['raw']
            fx_rates = self._data['fx_rates']

            if raw['power_spot'] is not None:
                cols = raw['power_spot'].columns
                power_col = None
                for col in cols:
                    if isinstance(col, tuple) and len(col) >= 1:
                        zone = str(col[0]).upper()
                        if zone == power_spot_code and 'H' in col:
                            if is_uk_mode and 'GBP' in col:
                                power_col = col
                                break
                            elif not is_uk_mode and 'EUR' in col:
                                power_col = col
                                break
                if power_col is None:
                    for col in cols:
                        if isinstance(col, tuple) and str(col[0]).upper() == power_spot_code and 'H' in col:
                            power_col = col
                            break
                if power_col is not None:
                    power_ts = raw['power_spot'][power_col].copy()
                    if hasattr(power_ts.index, 'tz') and power_ts.index.tz is not None:
                        power_ts.index = power_ts.index.tz_convert('UTC').tz_localize(None)
                    if is_uk_mode and 'EUR' in str(power_col):
                        power_ts = power_ts * fx_rates.get('GBP/EUR', 0.86)
                    elif not is_uk_mode and 'GBP' in str(power_col):
                        power_ts = power_ts * fx_rates.get('EUR/GBP', 1.16)
                    data_frames['Power'] = power_ts.resample('D').mean()

            if raw['gas_spot'] is not None:
                gas_col = None
                for col in raw['gas_spot'].columns:
                    if isinstance(col, tuple) and col[0] == gas_hub:
                        gas_col = col
                        break
                if gas_col is not None:
                    gas_ts = raw['gas_spot'][gas_col].copy()
                    gas_ts.index = pd.to_datetime(gas_ts.index)
                    if is_uk_mode:
                        gas_ts = gas_ts * fx_rates.get('GBP/EUR', 0.86)
                    data_frames['Gas'] = gas_ts

            if raw['co2_spot'] is not None:
                carbon_scheme = 'UKA' if is_uk_mode else 'EUA'
                co2_col = self._find_column(raw['co2_spot'], carbon_scheme)
                if co2_col is not None:
                    co2_ts = raw['co2_spot'][co2_col].copy()
                    co2_ts.index = pd.to_datetime(co2_ts.index)
                    if is_uk_mode:
                        co2_ts = co2_ts + UK_CARBON_PRICE_FLOOR
                    data_frames['Carbon'] = co2_ts
                    logger.debug(
                        f"  Loaded Carbon ({carbon_scheme}) data: {len(co2_ts)} values, "
                        f"date range: {co2_ts.index.min()} to {co2_ts.index.max()}, "
                        f"non-null: {co2_ts.notna().sum()}"
                    )
                else:
                    logger.warning(
                        f"  Could not find Carbon column '{carbon_scheme}' in CO2 spot data. "
                        f"Available columns: {list(raw['co2_spot'].columns)}"
                    )

            if raw['coal_spot'] is not None:
                coal_col = None
                for col in raw['coal_spot'].columns:
                    if isinstance(col, tuple) and len(col) >= 1:
                        if str(col[0]).upper() == 'API2':
                            coal_col = col
                            break
                if coal_col is not None:
                    coal_ts = raw['coal_spot'][coal_col].copy()
                    coal_ts.index = pd.to_datetime(coal_ts.index)
                    data_frames['Coal'] = coal_ts

            if raw['fx_spot'] is not None:
                fx_pair = 'USD/GBP' if is_uk_mode else 'USD/EUR'
                if fx_pair in raw['fx_spot'].columns:
                    fx_ts = raw['fx_spot'][fx_pair].copy()
                elif fx_pair[::-1].replace('/', '') in raw['fx_spot'].columns:
                    inverse_pair = fx_pair[4:7] + '/' + fx_pair[0:3]
                    fx_ts = (1 / raw['fx_spot'][inverse_pair]).copy()
                else:
                    fx_ts = pd.Series(0.96 if not is_uk_mode else 1.37)

                fx_ts.index = pd.to_datetime(fx_ts.index)
                data_frames['USD_TO_LOCAL'] = fx_ts

        required = ['Power', 'Gas', 'Coal', 'Carbon']
        missing = [c for c in required if c not in data_frames]
        if missing:
            logger.warning(f"Missing spot data for {power_hub}/{gas_hub}: {missing}")
            return pd.DataFrame()

        logger.info(f"✓ All required data found for {power_hub}/{gas_hub}: {list(data_frames.keys())}")

        for key in data_frames:
            data = data_frames[key]
            if isinstance(data, pd.DataFrame):
                data = data.iloc[:, 0]
            if isinstance(data, pd.Series):
                data = data.rename(key)
            data_frames[key] = data

        hist_data = pd.concat(data_frames.values(), axis=1, join='outer')
        hist_data.columns = data_frames.keys()

        logger.info(f"  Combined hist_data shape before filtering: {hist_data.shape}")

        if logger.isEnabledFor(logging.DEBUG):
            for col in hist_data.columns:
                col_data = hist_data[col]
                non_null = col_data.notna().sum()
                if non_null > 0:
                    first_val = col_data.first_valid_index()
                    last_val = col_data.last_valid_index()
                    logger.debug(
                        f"    {col}: {non_null}/{len(col_data)} non-null, "
                        f"range: {first_val} to {last_val}"
                    )
                else:
                    logger.debug(f"    {col}: 0/{len(col_data)} non-null (all NaN)")

        if not isinstance(hist_data.index, pd.DatetimeIndex):
            hist_data.index = pd.to_datetime(hist_data.index)

        hist_data = hist_data.sort_index()
        hist_data = hist_data.ffill()

        hist_data = hist_data[hist_data.index >= datetime(2023, 1, 1)]
        required_cols = ['Power', 'Gas', 'Carbon', 'Coal']
        available_required = [c for c in required_cols if c in hist_data.columns]
        if available_required:
            hist_data = hist_data.dropna(subset=available_required, how='all')

        logger.info(f"  hist_data shape after filtering: {hist_data.shape}, columns: {list(hist_data.columns)}")

        if hist_data.empty:
            logger.warning(f"hist_data is empty after filtering for {power_hub}/{gas_hub}")
            return pd.DataFrame()

        if 'Carbon' in hist_data.columns:
            carbon_before_fill = hist_data['Carbon'].notna().sum()
            hist_data['Carbon'] = hist_data['Carbon'].ffill()
            if hist_data['Carbon'].isna().any():
                hist_data['Carbon'] = hist_data['Carbon'].bfill()
            carbon_after_fill = hist_data['Carbon'].notna().sum()
            if carbon_before_fill < carbon_after_fill:
                logger.info(
                    f"  Carbon data filled: {carbon_before_fill} -> {carbon_after_fill} non-null values "
                    f"({carbon_after_fill - carbon_before_fill} values filled)"
                )
            if hist_data['Carbon'].isna().any():
                nan_count = hist_data['Carbon'].isna().sum()
                logger.warning(
                    f"  Carbon still has {nan_count} NaN values after fill operations. "
                    f"First non-null Carbon at: {hist_data['Carbon'].first_valid_index()}, "
                    f"Last non-null Carbon at: {hist_data['Carbon'].last_valid_index()}"
                )

        # Calculate baseline SRMC bands using shared emission constants.
        gas_eff_min, gas_eff_max = 0.49, 0.59
        coal_eff_min, coal_eff_max = 0.36, 0.45
        lig_eff_min, lig_eff_max = 0.34, 0.40

        hist_data['Gas_SRMC_Min'] = (hist_data['Gas'] / gas_eff_max) + (GAS_EMISSIONS / gas_eff_max) * hist_data['Carbon']
        hist_data['Gas_SRMC_Max'] = (hist_data['Gas'] / gas_eff_min) + (GAS_EMISSIONS / gas_eff_min) * hist_data['Carbon']

        coal_local_mwh = hist_data['Coal'] * hist_data['USD_TO_LOCAL'] / API2_TO_MWH
        hist_data['Coal_SRMC_Min'] = (coal_local_mwh / coal_eff_max) + (COAL_EMISSIONS / coal_eff_max) * hist_data['Carbon']
        hist_data['Coal_SRMC_Max'] = (coal_local_mwh / coal_eff_min) + (COAL_EMISSIONS / coal_eff_min) * hist_data['Carbon']

        hist_data['Lig_SRMC_Min'] = (LIG_FUEL_COST / lig_eff_max) + (LIG_EMISSION_FACTOR / lig_eff_max) * hist_data['Carbon']
        hist_data['Lig_SRMC_Max'] = (LIG_FUEL_COST / lig_eff_min) + (LIG_EMISSION_FACTOR / lig_eff_min) * hist_data['Carbon']

        result = hist_data.reset_index()
        if 'index' in result.columns:
            result = result.rename(columns={'index': 'date'})
        elif result.columns[0] not in list(data_frames.keys()):
            result = result.rename(columns={result.columns[0]: 'date'})

        if 'date' in result.columns:
            result['date'] = pd.to_datetime(result['date'])

        with self._lock:
            self._data['spot'][(power_hub, gas_hub)] = result

        return result

    def get_forward_data(self, power_hub: str, gas_hub: str, settlement_date: Optional[str] = None) -> pd.DataFrame:
        settlement_key = self._resolve_settlement_date(settlement_date)
        if settlement_key is None:
            return pd.DataFrame()
        with self._lock:
            cached = self._data['forward'].get((power_hub, gas_hub, settlement_key))
            if cached is not None:
                return cached.copy()
        return self._compute_forward_data(power_hub, gas_hub, settlement_key)

    def get_spot_data(self, power_hub: str, gas_hub: str) -> pd.DataFrame:
        with self._lock:
            cached = self._data['spot'].get((power_hub, gas_hub))
            if cached is not None:
                return cached.copy()
        return self._compute_spot_data(power_hub, gas_hub)


# ---------------------------------------------------------------------------
# Singleton + scheduler-facing loader
# ---------------------------------------------------------------------------
# Refreshes are driven by the central DataScheduler registered in
# portal_app.py under the source name "fuel_switching_data".
market_cache = MarketDataCache()


def load_market_data():
    """Loader registered with the central DataScheduler.

    Triggers a populate of the module-level ``market_cache`` and returns it
    so the scheduler can store the loaded data model.
    """
    market_cache.load_all_from_s3()
    return market_cache


__all__ = ["MarketDataCache", "market_cache", "load_market_data"]
