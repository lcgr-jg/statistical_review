"""Plotly figure builders for the fuel-switching page.

All builders are pure functions that take prepared DataFrames in and return
``go.Figure`` instances. Callbacks own the orchestration; charts own the
visual encoding.
"""

from __future__ import annotations

import logging
from typing import Iterable

import pandas as pd
import plotly.graph_objects as go

from core.fuel_switching.constants import (
    CHART_FONT,
    CHART_TEMPLATE,
    COLORS,
)

logger = logging.getLogger(__name__)


def make_empty_chart(message: str) -> go.Figure:
    """Empty placeholder figure shown while data is loading or missing."""
    fig = go.Figure()
    fig.update_layout(
        template=CHART_TEMPLATE,
        paper_bgcolor=COLORS['card_bg'],
        plot_bgcolor=COLORS['chart_bg'],
        font=dict(family=CHART_FONT, color=COLORS['text_secondary']),
        annotations=[dict(
            text=message,
            showarrow=False,
            font=dict(size=14, color=COLORS['text_muted']),
        )],
    )
    return fig


def build_fuels_chart(
    df: pd.DataFrame,
    hist_df: pd.DataFrame,
    gas_hub: str,
    currency: str = '€',
    is_uk_mode: bool = False,
) -> go.Figure:
    """Build the secondary 'Underlying Fuel Curves' chart."""
    fig_fuels = go.Figure()
    if hist_df is not None and not hist_df.empty:
        hist_df = hist_df.copy()
        d_col = 'date' if 'date' in hist_df.columns else 'DATE'
        hist_df['date'] = pd.to_datetime(hist_df[d_col])
        hist_df = hist_df[hist_df['date'] >= pd.Timestamp('2023-01-01')]
        if 'Gas' in hist_df.columns:
            fig_fuels.add_trace(go.Scatter(
                x=hist_df['date'], y=hist_df['Gas'], mode='lines',
                name=f'Spot {gas_hub}',
                line=dict(color=COLORS['gas_secondary'], width=1, dash='dot'),
            ))
        if 'Carbon' in hist_df.columns:
            fig_fuels.add_trace(go.Scatter(
                x=hist_df['date'], y=hist_df['Carbon'], mode='lines',
                name=f'Spot {"UKA+CPF" if is_uk_mode else "EUA"}',
                line=dict(color='rgba(46, 160, 67, 0.5)', width=1, dash='dot'),
            ))
        if 'Coal' in hist_df.columns:
            fig_fuels.add_trace(go.Scatter(
                x=hist_df['date'], y=hist_df['Coal'], mode='lines',
                name='Spot Coal $/t',
                line=dict(color=COLORS['coal_primary'], width=2),
            ))

    if df is not None and not df.empty:
        x_fc = df.index
        if 'Gas' in df.columns:
            fig_fuels.add_trace(go.Scatter(
                x=x_fc, y=df['Gas'], mode='lines+markers',
                name=f'{gas_hub} {currency}/MWh',
                line=dict(color=COLORS['gas_primary'], width=2),
                marker=dict(size=7),
            ))
        if 'Coal' in df.columns:
            fig_fuels.add_trace(go.Scatter(
                x=x_fc, y=df['Coal'], mode='lines+markers',
                name='Coal $/t',
                line=dict(color=COLORS['coal_primary'], width=2),
                marker=dict(size=7),
            ))
        if 'Carbon' in df.columns:
            fig_fuels.add_trace(go.Scatter(
                x=x_fc, y=df['Carbon'], mode='lines+markers',
                name=f'{"UKA+£18" if is_uk_mode else "EUA"} {currency}/t',
                line=dict(color=COLORS['carbon_primary'], width=2),
                marker=dict(size=7),
            ))

    today = pd.Timestamp.now()
    fig_fuels.add_shape(
        type="line", x0=today, x1=today, y0=0, y1=1, yref="paper",
        line=dict(color=COLORS['text_muted'], width=2, dash="dot"),
    )
    fig_fuels.update_layout(
        template=CHART_TEMPLATE, paper_bgcolor=COLORS['card_bg'], plot_bgcolor=COLORS['chart_bg'],
        margin=dict(l=60, r=30, t=20, b=50),
        font=dict(family=CHART_FONT, color=COLORS['text_secondary']),
        xaxis=dict(tickformat="%b %Y", gridcolor='#e8e6e1'),
        yaxis=dict(title=dict(text="Price"), gridcolor='#e8e6e1'),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
                    bgcolor='rgba(250,249,246,0.95)'),
        hovermode='x unified',
        hoverlabel=dict(bgcolor='#ffffff', bordercolor=COLORS['border'],
                        font=dict(color=COLORS['text_primary'])),
    )
    return fig_fuels


def build_main_switching_chart(
    df: pd.DataFrame,
    hist_df: pd.DataFrame,
    power_hub: str,
    gas_hub: str,
    gas_effs: Iterable[float],
    coal_effs: Iterable[float],
    lignite_effs: Iterable[float],
    currency: str = '€',
) -> go.Figure:
    """Build the main fuel-switching analysis chart.

    Expects ``df`` to already contain the ``Gas_SRMC_<eff>``, ``Coal_SRMC_<eff>``
    and ``Lignite_SRMC_<eff>`` columns produced by ``FuelSwitchingCalculator``,
    and ``hist_df`` (optional) to already contain the historical
    ``Gas_SRMC_Min/Max``, ``Coal_SRMC_Min/Max`` and ``Lig_SRMC_Min/Max`` bands.
    """
    gas_effs = list(gas_effs)
    coal_effs = list(coal_effs)
    lignite_effs = list(lignite_effs)

    fig = go.Figure()
    df = df.copy()
    df['Date_Start'] = df.index

    coal_fc_min = df[f'Coal_SRMC_{max(coal_effs)}']
    coal_fc_max = df[f'Coal_SRMC_{min(coal_effs)}']
    lig_fc_min = df[f'Lignite_SRMC_{max(lignite_effs)}']
    lig_fc_max = df[f'Lignite_SRMC_{min(lignite_effs)}']

    if hist_df is not None and not hist_df.empty:
        x_coal = pd.concat([hist_df['date'], df['Date_Start']])
        y_coal_min = pd.concat([hist_df['Coal_SRMC_Min'], coal_fc_min])
        y_coal_max = pd.concat([hist_df['Coal_SRMC_Max'], coal_fc_max])
        x_lig = pd.concat([hist_df['date'], df['Date_Start']])
        y_lig_min = pd.concat([hist_df['Lig_SRMC_Min'], lig_fc_min])
        y_lig_max = pd.concat([hist_df['Lig_SRMC_Max'], lig_fc_max])
        logger.debug(
            "SRMC ranges %s/%s: coal %.1f-%.1f %s/MWh, gas %.1f-%.1f %s/MWh",
            power_hub, gas_hub,
            y_coal_min.min(), y_coal_max.max(), currency,
            hist_df['Gas_SRMC_Min'].min(), hist_df['Gas_SRMC_Max'].max(), currency,
        )
    else:
        x_coal, y_coal_min, y_coal_max = df['Date_Start'], coal_fc_min, coal_fc_max
        x_lig, y_lig_min, y_lig_max = df['Date_Start'], lig_fc_min, lig_fc_max

    # Lignite band
    fig.add_trace(go.Scatter(x=x_lig, y=y_lig_max, mode='lines', line=dict(width=0), showlegend=False, hoverinfo='skip'))
    fig.add_trace(go.Scatter(
        x=x_lig, y=y_lig_min, mode='lines', line=dict(width=0), fill='tonexty',
        fillcolor='rgba(160, 82, 45, 0.18)', name='Lignite SRMC',
        hovertemplate=f'Lignite: %{{y:.1f}} {currency}/MWh<extra></extra>',
    ))

    # Coal band
    fig.add_trace(go.Scatter(x=x_coal, y=y_coal_max, mode='lines', line=dict(width=0), showlegend=False, hoverinfo='skip'))
    fig.add_trace(go.Scatter(
        x=x_coal, y=y_coal_min, mode='lines', line=dict(width=0), fill='tonexty',
        fillcolor='rgba(108, 117, 125, 0.25)', name='Coal SRMC',
        hovertemplate=f'Coal: %{{y:.1f}} {currency}/MWh<extra></extra>',
    ))

    # Historical gas range + power
    if hist_df is not None and not hist_df.empty:
        fig.add_trace(go.Scatter(x=hist_df['date'], y=hist_df['Gas_SRMC_Max'], mode='lines',
                                 line=dict(width=0), showlegend=False, hoverinfo='skip'))
        fig.add_trace(go.Scatter(
            x=hist_df['date'], y=hist_df['Gas_SRMC_Min'], mode='lines', line=dict(width=0), fill='tonexty',
            fillcolor='rgba(33, 113, 181, 0.15)', name='Gas SRMC (Hist)',
            hovertemplate=f'Gas SRMC: %{{y:.1f}} {currency}/MWh<extra></extra>',
        ))
        if 'Power_Rolling' in hist_df.columns:
            fig.add_trace(go.Scatter(
                x=hist_df['date'], y=hist_df['Power_Rolling'], mode='lines',
                name=f'{power_hub} Spot (14D)', line=dict(width=2, color=COLORS['power_primary']),
                hovertemplate=f'Spot: %{{y:.1f}} {currency}/MWh<extra></extra>',
            ))

    # Forward gas lines
    x_fc = df['Date_Start']
    gas_colors = ['#08519c', '#2171b5', '#4292c6', '#6baed6', '#9ecae1']
    for i, eff in enumerate(sorted(gas_effs)):
        fig.add_trace(go.Scatter(
            x=x_fc, y=df[f'Gas_SRMC_{eff}'], mode='lines+markers',
            name=f'Gas {int(eff*100)}%', line=dict(width=2, color=gas_colors[i % len(gas_colors)]),
            marker=dict(size=6),
            hovertemplate=f'Gas {int(eff*100)}%: %{{y:.1f}} {currency}/MWh<extra></extra>',
        ))

    # Power forward (may be absent when the settlement bundle has no forward
    # power curve for this hub — render the fuel bands anyway).
    if 'Power' in df.columns:
        fig.add_trace(go.Scatter(
            x=x_fc, y=df['Power'], mode='lines+markers', name=f'{power_hub} Power',
            line=dict(width=3, color=COLORS['power_primary']), marker=dict(size=8, symbol='diamond'),
            hovertemplate=f'Power: %{{y:.1f}} {currency}/MWh<extra></extra>',
        ))

    # Today line
    today = pd.Timestamp.now()
    fig.add_shape(type="line", x0=today, x1=today, y0=0, y1=1, yref="paper",
                  line=dict(color=COLORS['text_muted'], width=2, dash="dot"))
    fig.add_annotation(
        x=today, y=1.02, yref="paper", text="Today", showarrow=False,
        font=dict(size=11, color=COLORS['text_secondary']),
    )

    fig.update_layout(
        template=CHART_TEMPLATE, paper_bgcolor=COLORS['card_bg'], plot_bgcolor=COLORS['chart_bg'],
        margin=dict(l=60, r=30, t=30, b=50),
        font=dict(family=CHART_FONT, color=COLORS['text_secondary']),
        xaxis=dict(title="", tickformat="%b %Y", gridcolor='#e8e6e1'),
        yaxis=dict(title=dict(text=f"Price ({currency}/MWh)"), gridcolor='#e8e6e1'),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
                    bgcolor='rgba(250,249,246,0.95)'),
        hovermode='x unified',
        hoverlabel=dict(bgcolor='#ffffff', bordercolor=COLORS['border'],
                        font=dict(color=COLORS['text_primary'])),
    )
    return fig


def build_srmc_spread_chart(
    df: pd.DataFrame,
    hist_df: pd.DataFrame,
    gas_effs: Iterable[float],
    coal_effs: Iterable[float],
    lignite_effs: Iterable[float],
    currency: str = '€',
) -> go.Figure:
    """Build a chart showing Coal-vs-Gas and Lignite-vs-Gas SRMC spreads.

    For each fuel, the "mid" SRMC is the average across all user-selected
    efficiency columns (forward) or the average of the Min/Max bands
    (historical).  A negative spread means the alternative fuel is cheaper
    than gas at mid efficiency; positive means gas is cheaper.
    """
    gas_effs = list(gas_effs)
    coal_effs = list(coal_effs)
    lignite_effs = list(lignite_effs)

    fig = go.Figure()

    # ── Historical spreads ──────────────────────────────────────────────────
    if hist_df is not None and not hist_df.empty:
        hdf = hist_df.copy()

        gas_mid_h = None
        coal_mid_h = None
        lig_mid_h = None

        if 'Gas_SRMC_Min' in hdf.columns and 'Gas_SRMC_Max' in hdf.columns:
            gas_mid_h = (hdf['Gas_SRMC_Min'] + hdf['Gas_SRMC_Max']) / 2
        if 'Coal_SRMC_Min' in hdf.columns and 'Coal_SRMC_Max' in hdf.columns:
            coal_mid_h = (hdf['Coal_SRMC_Min'] + hdf['Coal_SRMC_Max']) / 2
        if 'Lig_SRMC_Min' in hdf.columns and 'Lig_SRMC_Max' in hdf.columns:
            lig_mid_h = (hdf['Lig_SRMC_Min'] + hdf['Lig_SRMC_Max']) / 2

        if gas_mid_h is not None and coal_mid_h is not None:
            coal_spread_h = coal_mid_h - gas_mid_h
            fig.add_trace(go.Scatter(
                x=hdf['date'], y=coal_spread_h, mode='lines',
                name='Coal − Gas SRMC (hist)',
                line=dict(color=COLORS['coal_primary'], width=1.5, dash='dot'),
                hovertemplate=f'Coal−Gas: %{{y:.1f}} {currency}/MWh<extra></extra>',
            ))

        if gas_mid_h is not None and lig_mid_h is not None:
            lig_spread_h = lig_mid_h - gas_mid_h
            fig.add_trace(go.Scatter(
                x=hdf['date'], y=lig_spread_h, mode='lines',
                name='Lignite − Gas SRMC (hist)',
                line=dict(color='rgba(160, 82, 45, 0.6)', width=1.5, dash='dot'),
                hovertemplate=f'Lignite−Gas: %{{y:.1f}} {currency}/MWh<extra></extra>',
            ))

    # ── Forward spreads ─────────────────────────────────────────────────────
    if df is not None and not df.empty:
        fdf = df.copy()
        fdf['_date'] = fdf.index

        gas_cols = [f'Gas_SRMC_{e}' for e in gas_effs if f'Gas_SRMC_{e}' in fdf.columns]
        coal_cols = [f'Coal_SRMC_{e}' for e in coal_effs if f'Coal_SRMC_{e}' in fdf.columns]
        lig_cols = [f'Lignite_SRMC_{e}' for e in lignite_effs if f'Lignite_SRMC_{e}' in fdf.columns]

        if gas_cols and coal_cols:
            gas_mid_f = fdf[gas_cols].mean(axis=1)
            coal_mid_f = fdf[coal_cols].mean(axis=1)
            coal_spread_f = coal_mid_f - gas_mid_f
            fig.add_trace(go.Scatter(
                x=fdf['_date'], y=coal_spread_f, mode='lines+markers',
                name='Coal − Gas SRMC',
                line=dict(color=COLORS['coal_primary'], width=2.5),
                marker=dict(size=6),
                hovertemplate=f'Coal−Gas: %{{y:.1f}} {currency}/MWh<extra></extra>',
            ))

        if gas_cols and lig_cols:
            gas_mid_f = fdf[gas_cols].mean(axis=1)
            lig_mid_f = fdf[lig_cols].mean(axis=1)
            lig_spread_f = lig_mid_f - gas_mid_f
            fig.add_trace(go.Scatter(
                x=fdf['_date'], y=lig_spread_f, mode='lines+markers',
                name='Lignite − Gas SRMC',
                line=dict(color='rgba(160, 82, 45, 1.0)', width=2.5),
                marker=dict(size=6),
                hovertemplate=f'Lignite−Gas: %{{y:.1f}} {currency}/MWh<extra></extra>',
            ))

    # Zero reference line
    fig.add_hline(y=0, line=dict(color=COLORS['text_muted'], width=1.5, dash='dash'))

    # Today marker
    today = pd.Timestamp.now()
    fig.add_shape(type="line", x0=today, x1=today, y0=0, y1=1, yref="paper",
                  line=dict(color=COLORS['text_muted'], width=2, dash="dot"))

    fig.update_layout(
        template=CHART_TEMPLATE, paper_bgcolor=COLORS['card_bg'], plot_bgcolor=COLORS['chart_bg'],
        margin=dict(l=60, r=30, t=20, b=50),
        font=dict(family=CHART_FONT, color=COLORS['text_secondary']),
        xaxis=dict(tickformat="%b %Y", gridcolor='#e8e6e1'),
        yaxis=dict(title=dict(text=f"Spread ({currency}/MWh)"), gridcolor='#e8e6e1', zeroline=False),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
                    bgcolor='rgba(250,249,246,0.95)'),
        hovermode='x unified',
        hoverlabel=dict(bgcolor='#ffffff', bordercolor=COLORS['border'],
                        font=dict(color=COLORS['text_primary'])),
    )
    return fig


__all__ = [
    "make_empty_chart",
    "build_fuels_chart",
    "build_main_switching_chart",
    "build_srmc_spread_chart",
]
