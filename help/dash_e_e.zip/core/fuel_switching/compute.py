"""Pure SRMC math for the fuel-switching page.

No I/O, no Dash, no plotly. Functions here take DataFrames in and return
DataFrames; they're trivial to unit test.
"""

from __future__ import annotations

from typing import Iterable

import pandas as pd

from core.fuel_switching.constants import (
    API2_TO_MWH,
    GAS_EMISSIONS,
    COAL_EMISSIONS,
    LIG_EMISSION_FACTOR,
)


class FuelSwitchingCalculator:
    """Computes per-efficiency SRMC columns on a forward-curve DataFrame."""

    def calculate_srmc(
        self,
        df: pd.DataFrame,
        gas_effs: Iterable[float],
        coal_effs: Iterable[float],
        lignite_effs: Iterable[float],
        lignite_fuel_cost: float,
    ) -> pd.DataFrame:
        if df.empty:
            return df

        if 'USD_TO_LOCAL' not in df.columns:
            df['USD_TO_LOCAL'] = 0.96

        if 'Gas' in df.columns and 'Carbon' in df.columns:
            for eff in gas_effs:
                df[f'Gas_SRMC_{eff}'] = (df['Gas'] / eff) + (GAS_EMISSIONS / eff) * df['Carbon']

        if 'Coal' in df.columns and 'Carbon' in df.columns:
            coal_local_mwh = df['Coal'] * df['USD_TO_LOCAL'] / API2_TO_MWH
            for eff in coal_effs:
                df[f'Coal_SRMC_{eff}'] = (coal_local_mwh / eff) + (COAL_EMISSIONS / eff) * df['Carbon']

        if 'Carbon' in df.columns:
            for eff in lignite_effs:
                df[f'Lignite_SRMC_{eff}'] = (
                    (lignite_fuel_cost / eff)
                    + (LIG_EMISSION_FACTOR / eff) * df['Carbon']
                )

        return df


calculator = FuelSwitchingCalculator()


def compute_historical_srmc(
    hist_df: pd.DataFrame,
    gas_effs: Iterable[float],
    coal_effs: Iterable[float],
    lignite_effs: Iterable[float],
    lignite_fuel_cost: float = 1.5,
    is_uk_mode: bool = False,
) -> pd.DataFrame:
    """Recompute the historical SRMC bands for the user-supplied efficiencies.

    Mirrors the inline SRMC math that used to live inside ``update_graphs`` so
    the callback can stay declarative.
    """
    if hist_df is None or hist_df.empty:
        return hist_df

    out = hist_df.copy()
    if 'USD_TO_LOCAL' not in out.columns:
        out['USD_TO_LOCAL'] = 1.37 if is_uk_mode else 0.96

    gas_effs = list(gas_effs)
    coal_effs = list(coal_effs)
    lignite_effs = list(lignite_effs)

    out['Gas_SRMC_Min'] = (out['Gas'] / max(gas_effs)) + (GAS_EMISSIONS / max(gas_effs)) * out['Carbon']
    out['Gas_SRMC_Max'] = (out['Gas'] / min(gas_effs)) + (GAS_EMISSIONS / min(gas_effs)) * out['Carbon']

    coal_local = out['Coal'] * out['USD_TO_LOCAL'] / API2_TO_MWH
    out['Coal_SRMC_Min'] = (coal_local / max(coal_effs)) + (COAL_EMISSIONS / max(coal_effs)) * out['Carbon']
    out['Coal_SRMC_Max'] = (coal_local / min(coal_effs)) + (COAL_EMISSIONS / min(coal_effs)) * out['Carbon']

    out['Lig_SRMC_Min'] = (lignite_fuel_cost / max(lignite_effs)) + (LIG_EMISSION_FACTOR / max(lignite_effs)) * out['Carbon']
    out['Lig_SRMC_Max'] = (lignite_fuel_cost / min(lignite_effs)) + (LIG_EMISSION_FACTOR / min(lignite_effs)) * out['Carbon']

    return out


__all__ = ["FuelSwitchingCalculator", "calculator", "compute_historical_srmc"]
