"""Constants for the fuel-switching page.

Every magic number used by the page lives here so it can be sourced from one
place (e.g. unit tests for the compute module).
"""

from core.styles import COLORS
from core.theme import PLOTLY_TEMPLATE_NAME

# UK Carbon Price Floor (Support Price) [£/tonne]
UK_CARBON_PRICE_FLOOR = 18.0

# NBP conversion: GBp/therm to £/MWh
NBP_TO_GBP_MWH = 0.3412

# API2 coal energy content [MWh / tonne]
API2_TO_MWH = 6.97

# Available hubs
POWER_HUBS = ["DE", "FR", "NL", "IT", "ES", "BE", "AT", "HU", "CH"]
GAS_HUBS = ["TTF", "NBP", "THE", "PSV"]
CARBON_SCHEMES = ["EUA", "UKA"]
MAX_SETTLEMENT_LOOKBACK_DAYS = 20

# Plotly template tokens.  ``CHART_TEMPLATE`` is the registered "dashboard"
# template defined in ``core.theme`` so all pages share the same visual
# language; the constant is re-exported for backwards compatibility.
CHART_TEMPLATE = PLOTLY_TEMPLATE_NAME
CHART_FONT = "Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif"

# Default control values (used both in the layout and in the fast-path)
DEFAULT_GAS_EFFS = [0.49, 0.52, 0.59]
DEFAULT_COAL_EFFS = [0.36, 0.45]
DEFAULT_LIGNITE_EFFS = [0.34, 0.40]

# SRMC emission factors
GAS_EMISSIONS = 0.185        # tCO2 / MWh fuel
COAL_EMISSIONS = 0.34        # tCO2 / MWh fuel
LIG_EMISSION_FACTOR = 0.40   # tCO2 / MWh fuel
LIG_FUEL_COST = 1.5          # €/MWh fuel (configurable upstream)

# Re-export the shared color palette for backwards-compatibility with callers
# that did ``from pages.fuel_switching import COLORS``.
__all__ = [
    "UK_CARBON_PRICE_FLOOR",
    "NBP_TO_GBP_MWH",
    "API2_TO_MWH",
    "POWER_HUBS",
    "GAS_HUBS",
    "CARBON_SCHEMES",
    "MAX_SETTLEMENT_LOOKBACK_DAYS",
    "CHART_TEMPLATE",
    "CHART_FONT",
    "DEFAULT_GAS_EFFS",
    "DEFAULT_COAL_EFFS",
    "DEFAULT_LIGNITE_EFFS",
    "GAS_EMISSIONS",
    "COAL_EMISSIONS",
    "LIG_EMISSION_FACTOR",
    "LIG_FUEL_COST",
    "COLORS",
]
