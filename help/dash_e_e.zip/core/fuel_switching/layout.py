"""Dash layout for the fuel-switching page.

The layout is rebuilt on every ``dash.register_page`` import so it must remain
deterministic and side-effect-free. Component IDs are intentionally identical
to the pre-split values; ``callbacks.py`` binds to them by string.
"""

from dash import dcc, html

from core.fuel_switching.constants import (
    COLORS,
    DEFAULT_COAL_EFFS,
    DEFAULT_GAS_EFFS,
    DEFAULT_LIGNITE_EFFS,
    POWER_HUBS,
)
from core.state import build_location


# id of the dcc.Location that backs URL-state sync for this page
URL_LOCATION_ID = "fs-url"


def build_layout() -> html.Div:
    """Construct the page layout. Pure function — safe to call repeatedly."""
    return html.Div([
        # URL state sync.  Must be inside the page's own layout so it gets
        # mounted/unmounted with the page (one Location per page).
        build_location(URL_LOCATION_ID),
        html.Div([
            # Top row: Market selection + Refresh button
            html.Div([
                html.Div([
                    html.Label("Power Hub", style={'fontSize': '12px', 'fontWeight': '600', 'color': '#6c757d', 'marginBottom': '6px', 'display': 'block'}),
                    dcc.Dropdown(
                        id='power-hub-dropdown',
                        options=[{'label': h, 'value': h} for h in POWER_HUBS],
                        value='DE',
                        clearable=False,
                        style={'width': '140px'},
                    ),
                ], style={'display': 'inline-block', 'marginRight': '20px'}),

                html.Div([
                    html.Label("Gas Hub", style={'fontSize': '12px', 'fontWeight': '600', 'color': '#6c757d', 'marginBottom': '6px', 'display': 'block'}),
                    dcc.Dropdown(
                        id='gas-hub-dropdown',
                        options=[
                            {'label': 'TTF (EUR/MWh)', 'value': 'TTF'},
                            {'label': 'NBP (GBP/MWh)', 'value': 'NBP'},
                        ],
                        value='TTF',
                        clearable=False,
                        style={'width': '180px'},
                    ),
                ], style={'display': 'inline-block', 'marginRight': '20px'}),

                html.Div([
                    html.Label("Settlement Date", style={'fontSize': '12px', 'fontWeight': '600', 'color': '#6c757d', 'marginBottom': '6px', 'display': 'block'}),
                    dcc.Dropdown(
                        id='settlement-date-dropdown',
                        options=[],
                        value=None,
                        clearable=False,
                        placeholder="Loading dates...",
                        style={'width': '190px'},
                    ),
                ], style={'display': 'inline-block', 'marginRight': '20px'}),

                html.Div([
                    html.Button(
                        [html.Span("↻", style={'fontSize': '16px', 'marginRight': '6px'}), "Refresh from S3"],
                        id='refresh-btn',
                        n_clicks=0,
                        style={
                            'padding': '10px 20px',
                            'backgroundColor': '#4E738A',
                            'color': '#ffffff',
                            'border': 'none',
                            'borderRadius': '6px',
                            'fontSize': '13px',
                            'fontWeight': '600',
                            'cursor': 'pointer',
                            'transition': 'all 0.2s',
                            'marginTop': '24px',
                        },
                    ),
                ], style={'display': 'inline-block', 'marginRight': '20px'}),

                html.Div([
                    html.Div(id='cache-status-badge', style={
                        'display': 'inline-block',
                        'padding': '8px 14px',
                        'backgroundColor': '#e6f4ea',
                        'color': '#2ea043',
                        'border': '1px solid rgba(46, 160, 67, 0.3)',
                        'borderRadius': '20px',
                        'fontSize': '12px',
                        'fontWeight': '500',
                        'marginTop': '24px',
                    }),
                ], style={'display': 'inline-block', 'float': 'right'}),
            ], style={'marginBottom': '20px', 'paddingBottom': '20px', 'borderBottom': '1px solid #e1e4e8'}),

            # Efficiency sliders
            html.Div([
                html.Div([
                    html.Div([
                        html.Label("Gas CCGT Efficiency", style={'fontSize': '13px', 'fontWeight': '600', 'color': '#231F20', 'marginBottom': '8px'}),
                        html.Div(id='gas-eff-display', style={'fontSize': '12px', 'color': '#4E738A', 'fontWeight': '500'}),
                    ], style={'display': 'flex', 'justifyContent': 'space-between', 'alignItems': 'center', 'marginBottom': '10px'}),
                    dcc.RangeSlider(
                        id='gas-eff-slider',
                        min=0.40,
                        max=0.65,
                        step=0.01,
                        value=DEFAULT_GAS_EFFS,
                        marks={0.40: {'label': '40%', 'style': {'fontSize': '11px', 'color': '#6c757d'}},
                               0.50: {'label': '50%', 'style': {'fontSize': '11px', 'color': '#6c757d'}},
                               0.60: {'label': '60%', 'style': {'fontSize': '11px', 'color': '#6c757d'}}},
                        tooltip={'placement': 'bottom', 'always_visible': False},
                    ),
                ], style={'flex': '1', 'minWidth': '280px', 'padding': '16px', 'backgroundColor': '#f8f9fa', 'borderRadius': '8px', 'border': '1px solid #e1e4e8'}),

                html.Div([
                    html.Div([
                        html.Label("Coal Efficiency", style={'fontSize': '13px', 'fontWeight': '600', 'color': '#231F20', 'marginBottom': '8px'}),
                        html.Div(id='coal-eff-display', style={'fontSize': '12px', 'color': '#4E738A', 'fontWeight': '500'}),
                    ], style={'display': 'flex', 'justifyContent': 'space-between', 'alignItems': 'center', 'marginBottom': '10px'}),
                    dcc.RangeSlider(
                        id='coal-eff-slider',
                        min=0.30,
                        max=0.50,
                        step=0.01,
                        value=DEFAULT_COAL_EFFS,
                        marks={0.30: {'label': '30%', 'style': {'fontSize': '11px', 'color': '#6c757d'}},
                               0.40: {'label': '40%', 'style': {'fontSize': '11px', 'color': '#6c757d'}},
                               0.50: {'label': '50%', 'style': {'fontSize': '11px', 'color': '#6c757d'}}},
                        tooltip={'placement': 'bottom', 'always_visible': False},
                    ),
                ], style={'flex': '1', 'minWidth': '280px', 'padding': '16px', 'backgroundColor': '#f8f9fa', 'borderRadius': '8px', 'border': '1px solid #e1e4e8'}),

                html.Div([
                    html.Div([
                        html.Label("Lignite Efficiency", style={'fontSize': '13px', 'fontWeight': '600', 'color': '#231F20', 'marginBottom': '8px'}),
                        html.Div(id='lignite-eff-display', style={'fontSize': '12px', 'color': '#4E738A', 'fontWeight': '500'}),
                    ], style={'display': 'flex', 'justifyContent': 'space-between', 'alignItems': 'center', 'marginBottom': '10px'}),
                    dcc.RangeSlider(
                        id='lignite-eff-slider',
                        min=0.30,
                        max=0.45,
                        step=0.01,
                        value=DEFAULT_LIGNITE_EFFS,
                        marks={0.30: {'label': '30%', 'style': {'fontSize': '11px', 'color': '#6c757d'}},
                               0.40: {'label': '40%', 'style': {'fontSize': '11px', 'color': '#6c757d'}}},
                        tooltip={'placement': 'bottom', 'always_visible': False},
                    ),
                ], style={'flex': '1', 'minWidth': '280px', 'padding': '16px', 'backgroundColor': '#f8f9fa', 'borderRadius': '8px', 'border': '1px solid #e1e4e8'}),
            ], style={'display': 'flex', 'gap': '16px', 'flexWrap': 'wrap'}),
        ], style={
            'backgroundColor': '#ffffff',
            'padding': '24px',
            'borderRadius': '12px',
            'border': '1px solid #e1e4e8',
            'marginBottom': '20px',
            'boxShadow': 'none',
        }),

        html.Div(id='uk-info-banner'),

        # Charts
        html.Div([
            html.Div([
                html.Div([
                    html.Span("Fuel Switching Analysis", style={'fontSize': '14px', 'fontWeight': '600', 'color': '#231F20', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    html.Span(id='chart-subtitle', style={'fontSize': '12px', 'color': '#6c757d', 'marginLeft': '12px'}),
                ], style={'padding': '16px 20px', 'borderBottom': '1px solid #eaecef'}),
                dcc.Loading(dcc.Graph(id='switching-graph', style={'height': '550px'}), type="circle", color="#4E738A"),
            ], style={'backgroundColor': '#ffffff', 'border': '1px solid #e1e4e8', 'borderRadius': '12px', 'marginBottom': '16px', 'boxShadow': 'none'}),

            html.Div([
                html.Div([
                    html.Span("Underlying Fuel Curves", style={'fontSize': '14px', 'fontWeight': '600', 'color': '#231F20', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    html.Span(id='fx-rate-display', style={'fontSize': '12px', 'color': '#6c757d', 'marginLeft': '12px'}),
                ], style={'padding': '16px 20px', 'borderBottom': '1px solid #eaecef'}),
                dcc.Loading(dcc.Graph(id='fuels-graph', style={'height': '400px'}), type="circle", color="#4E738A"),
            ], style={'backgroundColor': '#ffffff', 'border': '1px solid #e1e4e8', 'borderRadius': '12px', 'marginBottom': '16px', 'boxShadow': 'none'}),

            html.Div([
                html.Div([
                    html.Span("SRMC Spreads vs Gas (Mid Efficiency)", style={'fontSize': '14px', 'fontWeight': '600', 'color': '#231F20', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    html.Span("Coal − Gas  |  Lignite − Gas", style={'fontSize': '12px', 'color': '#6c757d', 'marginLeft': '12px'}),
                ], style={'padding': '16px 20px', 'borderBottom': '1px solid #eaecef'}),
                dcc.Loading(dcc.Graph(id='srmc-spread-graph', style={'height': '380px'}), type="circle", color="#4E738A"),
            ], style={'backgroundColor': '#ffffff', 'border': '1px solid #e1e4e8', 'borderRadius': '12px', 'boxShadow': 'none'}),
        ]),

        # Auto-refresh interval (checks cache status every 30s)
        dcc.Interval(id='status-interval', interval=30 * 1000, n_intervals=0),

    ], style={'minHeight': '100vh', 'backgroundColor': COLORS['background'], 'padding': '20px'})


__all__ = ["build_layout"]
