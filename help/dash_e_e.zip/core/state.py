"""
URL-state synchronisation for Dash pages.

Why
---
Refreshing a Dash page (or sharing its URL) used to lose every filter
the user had set, because all state lived in the in-memory component
tree.  This utility round-trips the values of a small set of "URL
controls" through the page's address bar so:

* refreshing a page restores the same view;
* a URL pasted to a colleague reproduces the same view;
* deep-links into specific filter combinations are possible.

How
---
Each page declares a list of :class:`UrlControl` specs (component id,
prop name, parser, optional encoder), drops a ``dcc.Location`` into its
layout and calls :func:`register` once::

    from core.state import UrlControl, register, build_location

    URL_LOCATION_ID = "fs-url"

    URL_CONTROLS = [
        UrlControl("power-hub-dropdown", "value", parse=str),
        UrlControl("gas-eff-slider", "value", parse=parse_floats, encode=encode_floats),
        ...
    ]

    # In layout.py:
    layout.children.insert(0, build_location(URL_LOCATION_ID))

    # At import time of callbacks.py:
    register(URL_LOCATION_ID, URL_CONTROLS)

Two callbacks are wired:

1. **URL → controls** (one-shot on first page navigation): reads the
   query string from the ``dcc.Location.search`` and writes any
   recognised values onto the matching controls' ``value`` props.
2. **controls → URL** (debounced via Dash's natural batching): every
   change in the listed controls is encoded back into the query
   string, leaving the path unchanged.

Both callbacks are robust against missing values (uses
:data:`dash.no_update`) and against malformed query strings (any decode
error is logged and the URL is ignored).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Sequence
from urllib.parse import parse_qsl, urlencode

import dash
from dash import Input, Output, State, callback, dcc


logger = logging.getLogger(__name__)


# -----------------------------------------------------------------------------
# Public types
# -----------------------------------------------------------------------------
@dataclass
class UrlControl:
    """Spec for one Dash component whose value should be synced to the URL.

    Attributes
    ----------
    component_id:
        Dash ``id`` of the component.
    prop:
        Property to round-trip (typically ``"value"``).
    parse:
        Function that converts the *raw string* from the query parameter
        back into the prop's native type.  Defaults to :class:`str`.
    encode:
        Function that converts the prop's native value into the string
        stored in the query parameter.  Defaults to :class:`str`.
    query_key:
        Optional override for the query-string key.  Defaults to the
        component id.
    """

    component_id: str
    prop: str = "value"
    parse: Callable[[str], Any] = field(default=str)
    encode: Callable[[Any], str] = field(default=str)
    query_key: str | None = None
    lazy: bool = False
    """If True, the control is conditionally rendered (e.g. lives inside a
    tab that may not be open) and is therefore **excluded from URL sync
    entirely** — it neither reads from nor writes to the query string.

    Dash raises ``NonExistentIdException`` whenever a callback ``Input``
    references a missing component, and refuses duplicate ``Output``
    writes (``allow_duplicate=True``) to missing components as well.  Since
    there's no reliable way to wire a lazily-mounted component into the
    URL-sync callbacks, we keep the spec for documentation / future use
    but skip it at registration time.  Pages that want per-tab control
    restoration should do it from their tab-render callback using
    ``State("<url>", "search")`` instead."""

    @property
    def key(self) -> str:
        return self.query_key or self.component_id


# -----------------------------------------------------------------------------
# Common parser / encoder helpers
# -----------------------------------------------------------------------------
def parse_int(s: str) -> int:
    return int(s)


def parse_float(s: str) -> float:
    return float(s)


def parse_int_list(s: str) -> list[int]:
    return [int(x) for x in s.split(",") if x]


def parse_float_list(s: str) -> list[float]:
    return [float(x) for x in s.split(",") if x]


def encode_list(values: Sequence[Any]) -> str:
    return ",".join(str(v) for v in (values or []))


# -----------------------------------------------------------------------------
# Encode / decode (pure functions, easily unit-tested)
# -----------------------------------------------------------------------------
def decode(search: str | None, controls: Sequence[UrlControl]) -> dict[str, Any]:
    """Parse a ``?a=1&b=2,3`` style query string against ``controls``.

    Returns a dict mapping ``component_id -> parsed value``.  Unknown
    keys are ignored; values whose ``parse`` raises are dropped (and a
    warning is logged) rather than crashing the page.
    """
    if not search:
        return {}

    qs = search.lstrip("?")
    pairs = parse_qsl(qs, keep_blank_values=False)

    by_key = {c.key: c for c in controls}
    out: dict[str, Any] = {}
    for raw_key, raw_val in pairs:
        ctrl = by_key.get(raw_key)
        if ctrl is None:
            continue
        try:
            out[ctrl.component_id] = ctrl.parse(raw_val)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "URL state: failed to parse %r=%r for control %s: %s",
                raw_key, raw_val, ctrl.component_id, exc,
            )
    return out


def encode(state: dict[str, Any], controls: Sequence[UrlControl]) -> str:
    """Build a ``?a=1&b=2,3`` query string from a state dict.

    ``None`` values are omitted (so empty controls produce a clean URL).
    """
    pairs: list[tuple[str, str]] = []
    by_id = {c.component_id: c for c in controls}
    for cid, value in state.items():
        ctrl = by_id.get(cid)
        if ctrl is None or value is None:
            continue
        try:
            pairs.append((ctrl.key, ctrl.encode(value)))
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "URL state: failed to encode value for %s: %s", cid, exc
            )
    if not pairs:
        return ""
    return "?" + urlencode(pairs)


# -----------------------------------------------------------------------------
# Layout helper
# -----------------------------------------------------------------------------
def build_location(location_id: str) -> dcc.Location:
    """Return a ``dcc.Location`` configured for URL state.

    ``refresh=False`` is critical so that updating the URL doesn't reload
    the page (and lose all in-memory state).
    """
    return dcc.Location(id=location_id, refresh=False)


# -----------------------------------------------------------------------------
# Callback registration
# -----------------------------------------------------------------------------
def register(location_id: str, controls: Sequence[UrlControl]) -> None:
    """Register the two sync callbacks against the given ``dcc.Location``.

    Must be called *exactly once per page*, e.g. at the bottom of that
    page's ``callbacks.py``.

    Notes
    -----
    * The "URL → controls" callback fires on every Location change, but
      only writes ``no_update`` for any control absent from the query
      string, so the existing widget state is preserved.
    * The "controls → URL" callback updates ``Location.search`` only,
      leaving ``pathname`` alone (Dash routing is unaffected).
    """
    if not controls:
        return

    # Lazy controls live inside conditionally-rendered sub-trees (e.g. a tab
    # body that isn't mounted yet).  Dash can't safely wire either an Input
    # or a duplicate Output to a component that may not exist at callback-
    # resolution time, so we exclude them from URL sync entirely.  Pages
    # that need per-tab restoration can do it from their own tab-render
    # callback using ``State(location_id, "search")`` + ``decode``.
    eager = [c for c in controls if not c.lazy]
    if not eager:
        return

    # ---- URL → controls -----------------------------------------------------
    @callback(
        [Output(c.component_id, c.prop, allow_duplicate=True) for c in eager],
        Input(location_id, "search"),
        prevent_initial_call="initial_duplicate",
    )
    def _url_to_controls(search):  # noqa: ANN001
        decoded = decode(search, eager)
        return [
            decoded.get(c.component_id, dash.no_update) for c in eager
        ]

    # ---- controls → URL -----------------------------------------------------
    @callback(
        Output(location_id, "search"),
        [Input(c.component_id, c.prop) for c in eager],
        State(location_id, "search"),
        prevent_initial_call=True,
    )
    def _controls_to_url(*args):  # noqa: ANN001
        *values, current_search = args
        state = {c.component_id: v for c, v in zip(eager, values)}
        new_search = encode(state, eager)
        if new_search == (current_search or ""):
            return dash.no_update
        return new_search


__all__ = [
    "UrlControl",
    "build_location",
    "register",
    "decode",
    "encode",
    "parse_int",
    "parse_float",
    "parse_int_list",
    "parse_float_list",
    "encode_list",
]
