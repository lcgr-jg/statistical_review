"""Bloomberg weather actuals + daily wind generation for portal cache."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import pandas as pd

from core.cache import dashboard_cache
from core.data_freshness import tracker
from core.weather_bbg.constants import (
    BBG_DATA_TYPE,
    COUNTRIES,
    FRESHNESS_EXPECTED_MINUTES,
    FRESHNESS_SOURCE_NAME,
    SOURCE_NAME,
    WEATHER_CSV_SOURCE,
    WEATHER_PROVIDER,
)

logger = logging.getLogger(__name__)


def _register_freshness(
    *,
    state: str | None = None,
    records: int | None = None,
    countries: int | None = None,
    error: str | None = None,
    detail: str | None = None,
) -> None:
    metadata: dict[str, Any] = {}
    if state:
        metadata["state"] = state
    if detail:
        metadata["detail"] = detail
    if error:
        metadata["error"] = error[:200]
        metadata["state"] = "error"
    if records is not None:
        metadata["records"] = records
    if countries is not None:
        metadata["countries"] = countries

    tracker.register_data_source(
        FRESHNESS_SOURCE_NAME,
        datetime.now(),
        expected_frequency_minutes=FRESHNESS_EXPECTED_MINUTES,
        metadata=metadata,
    )


def mark_weather_bbg_freshness_pending(
    detail: str = "waiting for warm-up",
) -> None:
    """Show Bloomberg Weather in Data Source Status before first fetch."""
    _register_freshness(state="pending", detail=detail)


def _normalize_weather_index(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.index = pd.to_datetime(out.index)
    if getattr(out.index, "tz", None) is not None:
        out.index = out.index.tz_localize(None)
    out.index = out.index.normalize()
    out = out[~out.index.duplicated(keep="last")].sort_index()
    return out


def _fetch_bbg_since(country: str, start: datetime, end: datetime) -> pd.DataFrame:
    from jain_commods.core.interfaces.bloomberg import weather

    if start.date() > end.date():
        return pd.DataFrame()
    raw = weather.get_bbg_data(
        data_type=BBG_DATA_TYPE,
        location=country,
        start_date=start,
        end_date=end,
        standard_col_names=True,
    )
    if raw is None or not isinstance(raw, pd.DataFrame) or raw.empty:
        return pd.DataFrame()
    return _normalize_weather_index(raw)


def _csv_history_end(country: str) -> datetime | None:
    from jain_commods.fundamental.weather import utils

    history = utils.get_weather_actuals(
        source=WEATHER_CSV_SOURCE,
        provider=WEATHER_PROVIDER,
        country=country,
        standard_col_names=True,
    )
    if history is None or history.empty:
        return None
    hist = _normalize_weather_index(history)
    return pd.Timestamp(hist.index.max()).to_pydatetime()


def _load_wind_generation_daily() -> pd.DataFrame:
    """
    Daily mean wind generation (MW) by country from GenWindActual (S3).

    Columns: AT…NL (uppercase). Index: naive daily timestamps.
    """
    from jain_commods.core.cache.data.fundamentals import GenWindActual

    zones = [c.lower() for c in COUNTRIES]
    obj = GenWindActual()
    obj.load(from_s3=True, show_metadata=False, zones=zones)
    if obj.data is None or obj.data.empty:
        return pd.DataFrame()

    hourly = obj.data.copy()
    hourly.index = pd.to_datetime(hourly.index)
    if getattr(hourly.index, "tz", None) is not None:
        hourly.index = hourly.index.tz_convert("UTC").tz_localize(None)
    hourly.columns = [str(c).upper() for c in hourly.columns]
    daily = hourly.resample("D").mean()
    keep = [c for c in COUNTRIES if c in daily.columns]
    return daily[keep].sort_index()


def load_weather_bbg() -> dict[str, Any]:
    """
    Cache loader: Bloomberg incremental weather actuals + daily wind gen.

    CSV history via ``get_weather_actuals`` is *not* cached (fast local read);
    consumers call :func:`get_country_weather` to stitch CSV + BBG.
    """
    _register_freshness(state="loading", detail="fetching Bloomberg weather")
    end = datetime.now()
    by_country: dict[str, pd.DataFrame] = {}
    errors: list[str] = []
    total_rows = 0

    for country in COUNTRIES:
        try:
            hist_end = _csv_history_end(country)
            start = (
                hist_end + timedelta(days=1)
                if hist_end is not None
                else datetime(2010, 1, 1)
            )
            df = _fetch_bbg_since(country, start, end)
            by_country[country] = df
            total_rows += int(len(df))
            logger.info(
                "BBG weather %s: %d rows from %s",
                country,
                len(df),
                start.date(),
            )
        except Exception as exc:
            logger.exception("BBG weather fetch failed for %s", country)
            errors.append(f"{country}: {exc}")
            by_country[country] = pd.DataFrame()

    wind_daily = pd.DataFrame()
    try:
        _register_freshness(
            state="loading",
            detail="loading GenWindActual (S3)",
            countries=len(COUNTRIES),
        )
        wind_daily = _load_wind_generation_daily()
    except Exception as exc:
        logger.exception("GenWindActual load failed")
        errors.append(f"wind: {exc}")

    payload: dict[str, Any] = {
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "by_country": by_country,
        "wind_generation_mw_d": wind_daily,
        "countries": list(COUNTRIES),
        "errors": errors,
    }

    if errors and total_rows == 0 and wind_daily.empty:
        _register_freshness(
            state="error",
            error="; ".join(errors)[:200],
            countries=len(COUNTRIES),
            records=0,
        )
        raise RuntimeError(
            "Bloomberg weather / wind load failed: " + "; ".join(errors)
        )

    detail = None
    if errors:
        detail = f"partial: {'; '.join(errors)[:120]}"
    _register_freshness(
        state="ok",
        countries=len(COUNTRIES),
        records=total_rows + int(wind_daily.size),
        detail=detail,
    )
    return payload


def get_cached_bbg_weather() -> dict[str, Any]:
    """Return the ``weather_bbg`` cache dict (raises if empty)."""
    data = dashboard_cache.get_data(SOURCE_NAME)
    if not data or not isinstance(data, dict):
        raise RuntimeError(
            "Bloomberg weather cache is empty. "
            "Wait for warm-up, or check Data Source Status for "
            f"'{FRESHNESS_SOURCE_NAME}'."
        )
    return data


def get_country_weather(country: str) -> pd.DataFrame:
    """
    Full weather history for *country*: CSV actuals + cached BBG tail.

    Columns include ``t_celsius``, ``w_ms``, ``hdd_c``, …
    """
    from jain_commods.fundamental.weather import utils

    country = country.upper()
    if country not in COUNTRIES:
        raise KeyError(f"Unsupported weather country '{country}'")

    history = utils.get_weather_actuals(
        source=WEATHER_CSV_SOURCE,
        provider=WEATHER_PROVIDER,
        country=country,
        standard_col_names=True,
    )
    hist = (
        _normalize_weather_index(history)
        if history is not None and isinstance(history, pd.DataFrame) and not history.empty
        else pd.DataFrame()
    )

    try:
        cached = get_cached_bbg_weather()
        bbg = cached.get("by_country", {}).get(country)
        if isinstance(bbg, pd.DataFrame) and not bbg.empty:
            bbg = _normalize_weather_index(bbg)
            if hist.empty:
                return bbg
            combined = pd.concat([hist, bbg])
            return combined[~combined.index.duplicated(keep="last")].sort_index()
    except RuntimeError:
        logger.warning("weather_bbg cache empty — returning CSV history only")

    return hist


def get_wind_generation_daily() -> pd.DataFrame:
    """Daily mean wind generation (MW) by country from the weather_bbg cache."""
    cached = get_cached_bbg_weather()
    wind = cached.get("wind_generation_mw_d")
    if wind is None or not isinstance(wind, pd.DataFrame) or wind.empty:
        raise RuntimeError(
            "No GenWindActual daily series in weather_bbg cache. "
            "Check Data Source Status for Bloomberg Weather Actuals."
        )
    out = wind.copy()
    out.index = pd.to_datetime(out.index).tz_localize(None)
    out.index = out.index.normalize()
    out.columns = [str(c).upper() for c in out.columns]
    return out[~out.index.duplicated(keep="last")].sort_index()
