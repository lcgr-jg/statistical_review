"""Scheduler / freshness knobs for Bloomberg weather actuals."""
from __future__ import annotations

from typing import Final

from core.constants import TTL_DAY

SOURCE_NAME: Final[str] = "weather_bbg"
# Once daily at 06:30 UK — BBG actuals settle overnight.
CRON: Final[str] = "30 6 * * *"
CRON_TIMEZONE: Final[str] = "Europe/London"
TTL_SECONDS: Final[int] = TTL_DAY

COUNTRIES: Final[tuple[str, ...]] = ("AT", "BE", "DE", "FR", "GB", "IT", "NL")

FRESHNESS_SOURCE_NAME: Final[str] = "Bloomberg Weather Actuals"
# Daily source — stay "fresh" for ~30 h to cover weekend / failed refresh.
FRESHNESS_EXPECTED_MINUTES: Final[int] = 30 * 60

# CSV history + BBG location codes (ISO country).
WEATHER_PROVIDER: Final[str] = "bloomberg"
WEATHER_CSV_SOURCE: Final[str] = "csv"
BBG_DATA_TYPE: Final[str] = "actual-weather"
