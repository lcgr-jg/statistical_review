"""
Unified caching + scheduling for the EU Power Dashboard.

Replaces the previous three-module approach (cache_manager, plot_cache,
data_scheduler) with a single DashboardCache class.

Provides:
    1. Two-tier cache (memory dict + diskcache SQLite on disk) with TTL
    2. Decorators: @cached_figure, @cached_result
    3. Background data-source scheduling via APScheduler
    4. Stats + monitoring API for the /api/cache-status endpoint

Usage:
    from core.cache import dashboard_cache, cached_figure, cached_result

    # Caching a data-loading function
    @cached_result(ttl=3600, prefix="prices_power_spot")
    def load_power_spot():
        ...

    # Caching a chart-building function
    @cached_figure(ttl=900, prefix="flat_candlestick")
    def create_chart(zone, date):
        ...
        return fig

    # Scheduling a data source for periodic refresh
    dashboard_cache.register_source("price_data", loader_fn, cron="0 6,12 * * *")
    data = dashboard_cache.get_data("price_data")
"""

import hashlib
import json
import logging
import os
import threading
import time
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Anchored to the repo root (``/app`` in the container, where the cache volume
# is mounted) so launching from another working directory doesn't scatter
# stray cache trees around the checkout.  ``DASHBOARD_CACHE_DIR`` overrides it
# (tests point it at a temp dir so they never touch a real cache).
_DEFAULT_CACHE_DIR = os.environ.get(
    "DASHBOARD_CACHE_DIR",
    str(Path(__file__).resolve().parents[1] / "cache" / "dashboard"),
)

# ---------------------------------------------------------------------------
# Optional dependency: diskcache (SQLite-backed, crash-safe)
# ---------------------------------------------------------------------------
try:
    import diskcache
    _DISKCACHE = True
except ImportError:
    _DISKCACHE = False
    logger.warning("diskcache not installed – falling back to in-memory-only cache")

# ---------------------------------------------------------------------------
# Optional dependency: APScheduler (background cron jobs)
# ---------------------------------------------------------------------------
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger
    _APSCHEDULER = True
except ImportError:
    _APSCHEDULER = False
    logger.warning("APScheduler not installed – scheduled refreshes disabled")


# ═══════════════════════════════════════════════════════════════════════════
# DashboardCache
# ═══════════════════════════════════════════════════════════════════════════

class DashboardCache:
    """Unified cache + scheduler for the EU Power Dashboard.

    Cache tier
    ----------
    Two-level: a fast in-memory ``dict`` (capped at *max_mem_items*) in
    front of a persistent ``diskcache.Cache`` (capped at *size_limit_gb*).
    Both levels honour per-key TTL.

    Scheduler tier
    --------------
    If APScheduler is installed, data sources registered with a cron or
    interval expression are refreshed automatically in background threads.
    Data is stored directly in the cache tier (no separate store).
    """

    def __init__(
        self,
        cache_dir: str = _DEFAULT_CACHE_DIR,
        size_limit_gb: float = 10.0,
        max_mem_items: int = 500,
    ):
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._max_mem = max_mem_items

        # ── In-memory tier: {key: (value, expiry_epoch)} ──
        self._mem: Dict[str, tuple] = {}
        self._lock = threading.Lock()

        # ── Disk tier ──
        if _DISKCACHE:
            self._disk = diskcache.Cache(
                str(self._cache_dir),
                size_limit=int(size_limit_gb * 1024**3),
                eviction_policy="least-recently-stored",
            )
        else:
            self._disk = None

        # ── Scheduler ──
        self._sched = None
        self._sched_started = False
        if _APSCHEDULER:
            self._sched = BackgroundScheduler(
                job_defaults={"coalesce": True, "max_instances": 1},
            )

        # ── Registered data sources ──
        self._sources: Dict[str, _SourceMeta] = {}

        # ── Stats ──
        self._stats = {
            "hits": 0, "misses": 0,
            "mem_hits": 0, "disk_hits": 0,
            "sets": 0, "evictions": 0,
        }
        self._last_disk_maintenance = 0.0
        self._disk_maintenance_interval = 3600  # seconds

        logger.info(
            f"DashboardCache ready  dir={self._cache_dir}  "
            f"disk={'yes' if _DISKCACHE else 'no'}  "
            f"scheduler={'yes' if _APSCHEDULER else 'no'}  "
            f"mem_cap={max_mem_items}  disk_cap={size_limit_gb}GB"
        )

    # ──────────────────────────────────────────────────────────────────────
    # Cache: low-level get / set / delete / clear
    # ──────────────────────────────────────────────────────────────────────

    def get(self, key: str, ttl: int = 3600) -> Optional[Any]:
        """Retrieve *key*, checking memory then disk.  Returns ``None`` on miss."""
        now = time.time()

        # 1) Memory
        with self._lock:
            if key in self._mem:
                value, expiry = self._mem[key]
                if now < expiry:
                    self._stats["hits"] += 1
                    self._stats["mem_hits"] += 1
                    return value
                self._mem.pop(key, None)

        # 2) Disk (outside lock — IO-bound)
        if self._disk is not None:
            result = self._disk.get(key, default=None)
            if result is not None:
                self._stats["hits"] += 1
                self._stats["disk_hits"] += 1
                with self._lock:
                    self._mem[key] = (result, now + ttl)
                return result

        self._stats["misses"] += 1
        return None

    def set(self, key: str, value: Any, ttl: int = 3600):
        """Store *value* under *key* in both tiers with the given TTL."""
        now = time.time()

        with self._lock:
            self._evict_expired(now)
            self._enforce_mem_limit()
            self._mem[key] = (value, now + ttl)

        if self._disk is not None:
            try:
                self._disk.set(key, value, expire=ttl)
            except Exception as exc:
                logger.warning(f"Disk cache set failed for {key[:24]}…: {exc}")

        self._stats["sets"] += 1
        self._run_disk_maintenance()

    def delete(self, key: str):
        """Remove *key* from both tiers."""
        with self._lock:
            self._mem.pop(key, None)
        if self._disk is not None:
            try:
                self._disk.delete(key)
            except Exception:
                pass

    def clear(self, prefix: Optional[str] = None):
        """Clear all keys, or only those starting with *prefix*."""
        with self._lock:
            if prefix:
                for k in [k for k in self._mem if k.startswith(prefix)]:
                    self._mem.pop(k, None)
            else:
                self._mem.clear()

        if self._disk is not None:
            if prefix:
                for k in list(self._disk):
                    if isinstance(k, str) and k.startswith(prefix):
                        try:
                            self._disk.delete(k)
                        except Exception:
                            pass
            else:
                self._disk.clear()

        logger.info(f"Cache cleared  prefix={prefix or '*'}")

    # ── Memory-tier bookkeeping (must hold self._lock) ──────────────────

    def _evict_expired(self, now: float):
        expired = [k for k, (_, exp) in self._mem.items() if now >= exp]
        for k in expired:
            self._mem.pop(k, None)
            self._stats["evictions"] += 1

    def _enforce_mem_limit(self):
        over = len(self._mem) - self._max_mem + 1
        if over <= 0:
            return
        by_expiry = sorted(self._mem.items(), key=lambda kv: kv[1][1])
        for k, _ in by_expiry[:over]:
            self._mem.pop(k, None)
            self._stats["evictions"] += 1

    # ──────────────────────────────────────────────────────────────────────
    # Scheduler: register / get_data / refresh
    # ──────────────────────────────────────────────────────────────────────

    def register_source(
        self,
        name: str,
        loader: Callable,
        cron: Optional[str] = None,
        interval_minutes: Optional[int] = None,
        ttl: int = 86_400,
        run_immediately: bool = True,
        timezone: Optional[str] = None,
    ):
        """Register a data source for caching and optional scheduled refresh.

        Args:
            name:             Unique key, e.g. ``"price_data"``.
            loader:           Callable returning the data (DataFrame, dict, …).
            cron:             Crontab string, e.g. ``"0 6,12 * * *"``.
            interval_minutes: Alternative to cron — refresh every N minutes.
            ttl:              Cache TTL in seconds (default: 24 h).
            run_immediately:  Call *loader* right now on registration.
            timezone:         IANA timezone for cron triggers
                              (e.g. ``"Europe/London"``).  ``None`` uses the
                              scheduler default (typically the host local TZ).
        """
        meta = _SourceMeta(name, loader, ttl)
        self._sources[name] = meta

        # Schedule background refresh
        if self._sched is not None:
            job_fn = lambda: self._refresh_source(name)  # noqa: E731
            if cron:
                trigger_kwargs = {}
                if timezone:
                    trigger_kwargs["timezone"] = timezone
                self._sched.add_job(
                    job_fn,
                    trigger=CronTrigger.from_crontab(cron, **trigger_kwargs),
                    id=f"refresh_{name}",
                    replace_existing=True,
                )
                tz_note = f" tz={timezone}" if timezone else ""
                logger.info(f"Scheduled '{name}'  cron={cron}{tz_note}")
            elif interval_minutes:
                self._sched.add_job(
                    job_fn,
                    trigger=IntervalTrigger(minutes=interval_minutes),
                    id=f"refresh_{name}",
                    replace_existing=True,
                )
                logger.info(f"Scheduled '{name}'  every {interval_minutes}min")

        if run_immediately:
            self._refresh_source(name)

    def get_data(self, name: str) -> Any:
        """Return latest data for *name*.

        Lookup order: memory → disk → synchronous call to loader.
        """
        meta = self._sources.get(name)
        ttl = meta.ttl if meta else 86_400
        cache_key = f"source:{name}"

        # 1) Cache (memory + disk)
        cached = self.get(cache_key, ttl=ttl)
        if cached is not None:
            return cached

        # 2) Direct call (slow path)
        if meta is not None:
            try:
                data = meta.loader()
                self.set(cache_key, data, ttl=ttl)
                meta.last_refresh = datetime.now()
                meta.error = None
                meta.refresh_count += 1
                return data
            except Exception as exc:
                meta.error = str(exc)
                logger.error(f"Direct load for '{name}' failed: {exc}")

        return None

    def force_refresh(self, name: str):
        """Trigger an immediate refresh for *name*."""
        self._refresh_source(name)

    def force_refresh_all(self):
        """Refresh every registered source."""
        for name in list(self._sources):
            self._refresh_source(name)

    def _refresh_source(self, name: str):
        """Internal: call the loader, store result in cache."""
        meta = self._sources.get(name)
        if meta is None:
            return
        try:
            logger.info(f"Refreshing '{name}'…")
            t0 = time.time()
            data = meta.loader()
            elapsed = time.time() - t0

            self.set(f"source:{name}", data, ttl=meta.ttl)
            meta.last_refresh = datetime.now()
            meta.error = None
            meta.refresh_count += 1

            logger.info(f"'{name}' refreshed in {elapsed:.1f}s")
        except Exception as exc:
            meta.error = str(exc)
            logger.error(f"Failed to refresh '{name}': {exc}", exc_info=True)

    # ──────────────────────────────────────────────────────────────────────
    # Lifecycle
    # ──────────────────────────────────────────────────────────────────────

    def start(self, warm: bool = False):
        """Start the background scheduler (idempotent).

        Args:
            warm: If True, call ``force_refresh_all()`` in a background thread.
        """
        if self._sched_started:
            return
        if self._sched is not None:
            self._sched.start()
            self._sched.add_job(
                self._run_disk_maintenance,
                trigger=IntervalTrigger(minutes=60),
                kwargs={"force": True},
                id="diskcache_maintenance",
                replace_existing=True,
            )
            self._sched_started = True
            logger.info("Scheduler started")
        else:
            logger.info("No APScheduler — running without scheduled jobs")

        self._run_disk_maintenance(force=True)

        if warm:
            threading.Thread(
                target=self.force_refresh_all, daemon=True, name="cache-warm"
            ).start()

    def shutdown(self):
        """Gracefully stop the scheduler."""
        if self._sched is not None and self._sched_started:
            self._sched.shutdown(wait=False)
            self._sched_started = False
            logger.info("Scheduler stopped")

    def _run_disk_maintenance(self, force: bool = False):
        """Prune expired entries and enforce disk size limits."""
        if self._disk is None:
            return

        now = time.time()
        if not force and (now - self._last_disk_maintenance) < self._disk_maintenance_interval:
            return

        try:
            expired = self._disk.expire()
            self._disk.cull()
            orphans, freed = self._sweep_orphan_files()
            self._last_disk_maintenance = now
            logger.info(
                f"Disk cache maintenance complete  expired={expired}  "
                f"orphans_removed={orphans}  freed={freed / 1024**2:.0f}MB"
            )
        except Exception as exc:
            logger.warning(f"Disk cache maintenance failed: {exc}")

    # Value files younger than this are left alone: diskcache writes the file
    # before committing its row, so a brand-new file may not be indexed yet.
    _ORPHAN_MIN_AGE_S = 3600

    def _sweep_orphan_files(self) -> tuple:
        """Delete ``.val`` files no Cache row references.

        diskcache ignores failures when removing a replaced/evicted value file
        (e.g. a file locked on Windows/OneDrive), and those orphans are not
        counted against ``size_limit`` — so they would otherwise pile up
        forever.  Returns ``(files_removed, bytes_freed)``.
        """
        rows = self._disk._sql(
            "SELECT filename FROM Cache WHERE filename IS NOT NULL"
        ).fetchall()
        referenced = {str(Path(name)) for (name,) in rows}
        cutoff = time.time() - self._ORPHAN_MIN_AGE_S
        removed = freed = 0
        for path in self._cache_dir.rglob("*.val"):
            rel = str(path.relative_to(self._cache_dir))
            if rel in referenced:
                continue
            try:
                stat = path.stat()
                if stat.st_mtime > cutoff:
                    continue
                path.unlink()
                removed += 1
                freed += stat.st_size
            except OSError:
                pass  # locked / already gone — retry next sweep
        return removed, freed

    # ──────────────────────────────────────────────────────────────────────
    # Monitoring
    # ──────────────────────────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Any]:
        """Cache hit/miss statistics."""
        total = self._stats["hits"] + self._stats["misses"]
        return {
            **self._stats,
            "hit_rate": f"{self._stats['hits'] / total:.1%}" if total else "N/A",
            "mem_items": len(self._mem),
            "disk_items": len(self._disk) if self._disk is not None else 0,
        }

    def get_status(self) -> Dict[str, Any]:
        """Full status dict for the ``/api/cache-status`` endpoint."""
        sources = {}
        for name, meta in self._sources.items():
            sources[name] = {
                "last_refresh": meta.last_refresh.isoformat() if meta.last_refresh else None,
                "has_data": self.get(f"source:{name}") is not None,
                "error": meta.error,
                "refresh_count": meta.refresh_count,
            }

        jobs = []
        if self._sched is not None and self._sched_started:
            for job in self._sched.get_jobs():
                jobs.append({"id": job.id, "next_run": str(job.next_run_time)})

        return {
            "scheduler_running": self._sched_started,
            "cache": self.get_stats(),
            "data_sources": sources,
            "jobs": jobs,
        }

    @property
    def registered_sources(self) -> List[str]:
        return list(self._sources.keys())

    def get_last_refresh(self, name: str) -> Optional[datetime]:
        meta = self._sources.get(name)
        return meta.last_refresh if meta else None


# ═══════════════════════════════════════════════════════════════════════════
# Internal: source metadata
# ═══════════════════════════════════════════════════════════════════════════

class _SourceMeta:
    """Bookkeeping for a registered data source."""
    __slots__ = ("name", "loader", "ttl", "last_refresh", "error", "refresh_count")

    def __init__(self, name: str, loader: Callable, ttl: int = 86_400):
        self.name = name
        self.loader = loader
        self.ttl = ttl
        self.last_refresh: Optional[datetime] = None
        self.error: Optional[str] = None
        self.refresh_count: int = 0


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _compact_repr(obj) -> str:
    """Return a fast, stable string for cache-key hashing.

    For large objects like DataFrames and ndarrays, avoids a full repr()
    which can be extremely slow and memory-intensive.
    """
    try:
        import pandas as pd
        if isinstance(obj, pd.DataFrame):
            # Do not use id(): S3 price loads can fill the same frame in place or
            # replace values while shape/id stay equal — figure cache would stay stale.
            if obj.empty:
                return "DF(EMPTY)"
            parts = [obj.shape, tuple(obj.columns)]
            n = len(obj)
            for c in ("valuedate", "valuedate ", "DeliveryTime", "DATE"):
                if c in obj.columns:
                    s = obj[c]
                    try:
                        parts.append((c, str(s.iloc[0]), str(s.iloc[-1])))
                    except Exception:
                        parts.append((c, "x"))
                    break
            else:
                try:
                    parts.append(("row0", str(obj.iloc[0].to_numpy()[:5])))
                except Exception:
                    parts.append((n,))
            h = hashlib.sha256(repr(parts).encode("utf-8", errors="replace")).hexdigest()[:16]
            return f"DF(n={n},sig={h})"
        if isinstance(obj, pd.Series):
            return f"Ser({len(obj)},{id(obj)})"
    except ImportError:
        pass
    try:
        import numpy as np
        if isinstance(obj, np.ndarray):
            return f"ndarray({obj.shape},{obj.dtype},{id(obj)})"
    except ImportError:
        pass
    return repr(obj)


def _stable_key(*args, **kwargs) -> str:
    """Hash function arguments into a short, deterministic key string."""
    raw = json.dumps(
        {
            "a": [_compact_repr(a) for a in args],
            "k": {k: _compact_repr(v) for k, v in sorted(kwargs.items())},
        },
        sort_keys=True,
    )
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _fig_to_dict(fig):
    """Convert a Plotly Figure to a plain dict for serialization."""
    try:
        import plotly.graph_objects as go
        if isinstance(fig, go.Figure):
            return fig.to_dict()
    except ImportError:
        pass
    return fig


def _dict_to_fig(d):
    """Reconstruct a Plotly Figure from its dict representation."""
    try:
        import plotly.graph_objects as go
        if isinstance(d, dict) and ("data" in d or "layout" in d):
            return go.Figure(d)
    except ImportError:
        pass
    return d


# ═══════════════════════════════════════════════════════════════════════════
# Singleton
# ═══════════════════════════════════════════════════════════════════════════
dashboard_cache = DashboardCache()


# ═══════════════════════════════════════════════════════════════════════════
# Decorators
# ═══════════════════════════════════════════════════════════════════════════

def cached_figure(ttl: int = 3600, prefix: str = "", ttl_seconds: int = None, key_prefix: str = None):
    """Decorator that caches Plotly Figure objects.

    Figures are stored as plain dicts (smaller, faster) and reconstructed
    on cache hit.

    Args:
        ttl:    Time-to-live in seconds.
        prefix: Cache key prefix (e.g. ``"wind_chart"``).
    """
    # Support legacy keyword args for backward compatibility during migration
    _ttl = ttl_seconds if ttl_seconds is not None else ttl
    _pfx = key_prefix if key_prefix is not None else prefix

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            p = _pfx or func.__name__
            key = f"fig:{p}:{_stable_key(*args, **kwargs)}"

            cached = dashboard_cache.get(key, ttl=_ttl)
            if cached is not None:
                logger.debug(f"Figure cache HIT  {key[:32]}")
                return _dict_to_fig(cached)

            logger.debug(f"Figure cache MISS {key[:32]}")
            fig = func(*args, **kwargs)
            dashboard_cache.set(key, _fig_to_dict(fig), ttl=_ttl)
            return fig

        wrapper.invalidate = lambda *a, **kw: dashboard_cache.delete(
            f"fig:{_pfx or func.__name__}:{_stable_key(*a, **kw)}"
        )
        wrapper.invalidate_all = lambda: dashboard_cache.clear(
            prefix=f"fig:{_pfx or func.__name__}:"
        )
        return wrapper

    return decorator


def cached_result(ttl: int = 3600, prefix: str = "", ttl_seconds: int = None, key_prefix: str = None):
    """Decorator that caches any picklable return value.

    Args:
        ttl:    Time-to-live in seconds.
        prefix: Cache key prefix.
    """
    # Support legacy keyword args for backward compatibility during migration
    _ttl = ttl_seconds if ttl_seconds is not None else ttl
    _pfx = key_prefix if key_prefix is not None else prefix

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            p = _pfx or func.__name__
            key = f"res:{p}:{_stable_key(*args, **kwargs)}"

            cached = dashboard_cache.get(key, ttl=_ttl)
            if cached is not None:
                return cached

            result = func(*args, **kwargs)
            dashboard_cache.set(key, result, ttl=_ttl)
            return result

        wrapper.invalidate = lambda *a, **kw: dashboard_cache.delete(
            f"res:{_pfx or func.__name__}:{_stable_key(*a, **kw)}"
        )
        wrapper.invalidate_all = lambda: dashboard_cache.clear(
            prefix=f"res:{_pfx or func.__name__}:"
        )
        return wrapper

    return decorator
