"""Layout for the LNG — Cargo Forecast History page."""
from __future__ import annotations

from dash import dcc, html

from core.cargo_forecast_history.render import empty_map_figure
from core.styles import COLORS

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "flex-end",
    "flexWrap": "wrap",
    "gap": "18px",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "hidden",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 12px 0",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}

_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "margin": "8px 0 0 0",
    "lineHeight": "1.5",
}

_MAP_GRAPH_CONFIG = {
    "displayModeBar": True,
    "displaylogo": False,
    "scrollZoom": True,
    "modeBarButtonsToRemove": ["select2d", "lasso2d"],
}


def build_layout() -> html.Div:
    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1600px"},
        children=[
            html.Div([
                html.H1("Cargo Forecast History", style={
                    "fontSize": "22px", "fontWeight": "600",
                    "color": COLORS["text_primary"], "margin": "0 0 4px 0"}),
                html.P(
                    "Inspect how Kpler’s destination forecast for a single "
                    "vessel has changed since it last loaded. Daily rows are "
                    "the ~06:00 UTC point-in-time snapshots (same store as "
                    "Cargo DoD / Arrivals Analysis); the top row is the live "
                    "vessels snapshot. The map is the Bloomberg AIS track "
                    "joined on IMO (hourly snapshots, same source as Qatar "
                    "Monitor).",
                    style={"fontSize": "13px", "color": COLORS["text_muted"],
                           "margin": "0 0 12px 0"}),
            ]),

            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Div(
                        style={"flex": "1 1 420px", "minWidth": "280px"},
                        children=[
                            html.Label("Vessel", style=_LABEL),
                            dcc.Dropdown(
                                id="cfh-vessel",
                                options=[],
                                value=None,
                                placeholder="Select a vessel…",
                                searchable=True,
                                clearable=True,
                            ),
                        ],
                    ),
                    html.Div(id="cfh-location-links",
                             style={"paddingBottom": "2px"}),
                    html.Div(id="cfh-status", style={"flexBasis": "100%"}),
                ],
            ),

            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Current cargo", style=_PANEL_TITLE),
                dcc.Loading(type="circle",
                            children=html.Div(id="cfh-headline")),
            ]),

            html.Div(
                style={
                    "display": "flex",
                    "gap": "20px",
                    "flexWrap": "wrap",
                    "alignItems": "stretch",
                },
                children=[
                    html.Div(
                        style={**_CONTENT_PANEL, "flex": "1 1 640px",
                               "minWidth": "480px", "marginBottom": "20px"},
                        children=[
                            html.H3("Forecast history", style=_PANEL_TITLE),
                            dcc.Loading(
                                type="circle",
                                children=html.Div(id="cfh-table"),
                            ),
                            html.P([
                                "Yellow cells changed versus the previous "
                                "snapshot (destination, ETA or source).  ",
                                html.Span("Live row", style={
                                    "backgroundColor": "#e8f1f6",
                                    "padding": "1px 6px",
                                    "borderRadius": "3px"}),
                                " is the current Kpler vessels snapshot, "
                                "not the daily 06:00 UTC PIT file. Source is "
                                "Kpler’s ETA source (Port, AIS, Model, "
                                "Market, Analyst). History is cache-only — "
                                "uncached snapshot days are skipped.",
                            ], style=_NOTE),
                        ],
                    ),
                    html.Div(
                        style={**_CONTENT_PANEL, "flex": "1 1 420px",
                               "minWidth": "360px", "marginBottom": "20px"},
                        children=[
                            html.H3("Bloomberg position", style=_PANEL_TITLE),
                            dcc.Loading(
                                type="circle",
                                children=dcc.Graph(
                                    id="cfh-map",
                                    figure=empty_map_figure(),
                                    config=_MAP_GRAPH_CONFIG,
                                ),
                            ),
                            html.P(
                                "Bloomberg AIS lat/lon joined to the Kpler "
                                "vessel on IMO. Hourly snapshots are archived "
                                "write-once (local + S3) so the map can draw "
                                "the track since last load. History starts "
                                "from this change — earlier hours were not "
                                "kept. Scroll to zoom, drag to pan, or use "
                                "the toolbar (+ / − / reset).",
                                style=_NOTE,
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )
