"""Callbacks for the LNG — Cargo Forecast History page."""
from __future__ import annotations

import logging

import pandas as pd
from dash import Input, Output, callback, html

from core.cargo_dod.data import max_selectable_date
from core.cargo_forecast_history.data import (
    flag_forecast_changes,
    get_bbg_position,
    get_bbg_track,
    list_vessels,
    live_forecast_row,
    slice_since_last_load,
    vessel_dropdown_options,
)
from core.cargo_forecast_history.render import (
    ballast_message,
    build_forecast_table,
    build_headline,
    build_location_links,
    build_position_map,
    empty_map_figure,
)
from core.styles import COLORS, get_status_badge_style

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(message, style={
        **get_status_badge_style(level),
        "padding": "10px 14px",
        "borderRadius": "8px",
        "fontSize": "13px",
        "width": "100%",
    })


def _empty_selection(options, status):
    return (
        options,
        html.Div(
            "Select a laden vessel to inspect its forecast history.",
            style={"fontSize": "13px", "color": COLORS["text_muted"]},
        ),
        html.Div(),
        empty_map_figure(),
        None,
        status,
    )


@callback(
    Output("cfh-vessel", "options"),
    Output("cfh-headline", "children"),
    Output("cfh-table", "children"),
    Output("cfh-map", "figure"),
    Output("cfh-location-links", "children"),
    Output("cfh-status", "children"),
    Input("cfh-vessel", "value"),
)
def update_vessel(imo_value):
    try:
        vessels = list_vessels()
    except Exception as ex:
        logger.exception("Failed to load Kpler vessels snapshot")
        return _empty_selection(
            [], _alert(f"Kpler vessels snapshot unavailable: {ex}", "error"))

    if vessels.empty:
        return _empty_selection([], _alert(
            "Kpler vessels snapshot is empty. Wait for cache warm-up, or "
            "refresh Kpler from Qatar Monitor."))

    options = vessel_dropdown_options(vessels)
    n_laden = int(vessels["is_laden"].sum())
    n = int(len(vessels))
    idle_status = _alert(
        f"{n:,} vessels in the latest Kpler snapshot "
        f"({n_laden:,} laden). Ballast ships have no cargo forecast.",
        "success",
    )

    if not imo_value:
        return _empty_selection(options, idle_status)

    try:
        imo = int(imo_value)
    except (TypeError, ValueError):
        return _empty_selection(
            options, _alert("Invalid vessel selection.", "error"))

    match = vessels[vessels["imo"] == imo]
    if match.empty:
        return _empty_selection(
            options,
            _alert(f"IMO {imo} is not in the latest vessels snapshot.",
                   "warning"),
        )

    vessel = match.iloc[0]
    name = str(vessel.get("name") or f"IMO {imo}")
    location_links = build_location_links(vessel.get("kpler_vessel_id"), imo)
    bbg = get_bbg_position(imo)

    load_hint = None
    dep = pd.to_datetime(vessel.get("departure_date"), errors="coerce")
    if pd.notna(dep):
        load_hint = dep.date()

    def _map(start=None):
        track = get_bbg_track(imo, start=start)
        return build_position_map(bbg, track=track, vessel_name=name)

    if not bool(vessel.get("is_laden")):
        fmap = _map(start=load_hint)
        return (
            options,
            ballast_message(name),
            html.Div(),
            fmap,
            location_links,
            _alert(f"{name} is ballast / unladen — no cargo forecast.",
                   "warning"),
        )

    try:
        hist, load_date, missing = slice_since_last_load(
            imo, as_of=max_selectable_date(), load_date=load_hint)
    except Exception as ex:
        logger.exception("Forecast history load failed")
        fmap = _map(start=load_hint)
        return (
            options,
            _alert(f"Forecast history failed: {ex}", "error"),
            html.Div(),
            fmap,
            location_links,
            _alert(f"Forecast history failed: {ex}", "error"),
        )

    live = pd.DataFrame([live_forecast_row(vessel)])
    combined = pd.concat([hist, live], ignore_index=True)
    combined["is_live"] = combined["is_live"].fillna(False).astype(bool)
    combined = flag_forecast_changes(combined)
    track = get_bbg_track(imo, start=load_date or load_hint)
    fmap = build_position_map(bbg, track=track, vessel_name=name)

    n_hist = int((~combined["is_live"]).sum())
    n_track = int(len(track))
    status = (
        f"{name}  ·  {n_hist:,} daily snapshot"
        f"{'' if n_hist == 1 else 's'} since last load"
    )
    if load_date:
        status += f" ({load_date:%d-%b-%Y})"
    if missing:
        status += f"  ·  {len(missing):,} uncached day(s) skipped"
    if bbg is None:
        status += "  ·  no Bloomberg AIS match on IMO"
    elif n_track:
        status += f"  ·  {n_track:,} Bloomberg AIS fix(es)"

    return (
        options,
        build_headline(vessel, combined, load_date, len(missing)),
        build_forecast_table(combined),
        fmap,
        location_links,
        _alert(status, "success"),
    )
