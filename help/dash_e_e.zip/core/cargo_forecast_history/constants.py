"""LNG — Cargo Forecast History page constants."""
from __future__ import annotations

from core.cargo_dod.constants import (
    KPLER_VESSEL_MAP_URL,
    M3_LNG_TO_MCM,
    SNAPSHOT_HOUR_UTC,
)

PAGE_PATH = "/power/lng/cargo_forecast_history"
PAGE_NAME = "Cargo Forecast History"
PAGE_TITLE = "LNG Cargo Forecast History | JG Power Dashboard"
PAGE_ORDER = 84

# Cargoes on the water (same statuses as Arrivals Analysis / Cargo DoD).
TRADE_STATUSES = ["In Transit", "Loading"]

# Cap the per-vessel lookback so a floating-storage sit does not walk
# years of parquets on first selection.  180d covers any plausible voyage.
MAX_LOOKBACK_DAYS = 180

# Derived per-snapshot on-water cargo rows (lives next to the PIT cache).
HIST_FILENAME = "vessel_forecast_hist_v1.parquet"

# Bloomberg Terminal map deep-link (opens the MAP screen for an IMO).
BBG_VESSEL_MAP_URL = "bbg://screens/MAP IMO {}"

# Re-export shared knobs so the page package is self-contained.
__all__ = [
    "BBG_VESSEL_MAP_URL",
    "HIST_FILENAME",
    "KPLER_VESSEL_MAP_URL",
    "M3_LNG_TO_MCM",
    "MAX_LOOKBACK_DAYS",
    "PAGE_NAME",
    "PAGE_ORDER",
    "PAGE_PATH",
    "PAGE_TITLE",
    "SNAPSHOT_HOUR_UTC",
    "TRADE_STATUSES",
]
