"""Data access for the Cargo Forecast History page.

Builds a small derived parquet of on-water cargo rows (one per vessel per
~06:00 UTC Kpler snapshot) from the PIT store, then slices it to a single
IMO since that vessel's last load.

Strictly cache-only for history: ``read_trades_snapshot`` never calls the
Kpler API.  The live vessels / Bloomberg snapshots come from the existing
dashboard caches.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from datetime import date, datetime, timedelta
from typing import Any

import pandas as pd

from core.cargo_dod.constants import PIT_LOCAL_CACHE_DIR
from core.cargo_forecast_history.constants import (
    HIST_FILENAME,
    M3_LNG_TO_MCM,
    MAX_LOOKBACK_DAYS,
    SNAPSHOT_HOUR_UTC,
    TRADE_STATUSES,
)

logger = logging.getLogger(__name__)

# Raw (API-native) column names as stored in the snapshot parquets
_COL_VESSEL = "Vessel"
_COL_IMO = "IMO (vessel)"
_COL_ID = "Id (vessel)"
_COL_STATUS = "Trade status"
_COL_FROM_TERM = "Installation origin"
_COL_FROM_COUNTRY = "Country (origin)"
_COL_DATE_ORIGIN = "Date (origin)"
_COL_VOL = "Volume (origin m3)"
_COL_TO_COUNTRY = "Country (destination)"
_COL_TO_TERM = "Installation Destination"
_COL_TO_CONTINENT = "Continent Destination"
_COL_FORECAST_DEST = "Forecasted destination"
_COL_ETA = "Date (destination)"
_COL_SOURCE = "Eta source (destination)"
_COL_CONF = "Forecasted confidence"
_COL_VOYAGE = "Id (Voyage)"

HIST_COLUMNS = [
    "snapshot_date",
    "imo",
    "vessel",
    "kpler_vessel_id",
    "status",
    "from_terminal",
    "from_country",
    "departure_date",
    "volume_m3",
    "to_country",
    "to_terminal",
    "to_continent",
    "forecasted_destination",
    "eta",
    "source",
    "confidence",
    "voyage_id",
    "is_live",
]

_lock = threading.Lock()
_hist: pd.DataFrame | None = None
_hist_dates: set[date] = set()

_CACHED_DATES_TTL_S = 60.0
_cached_dates: set[date] = set()
_cached_dates_ts: float | None = None


def _empty_hist() -> pd.DataFrame:
    return pd.DataFrame(columns=HIST_COLUMNS)


def _hist_path() -> str:
    return os.path.join(PIT_LOCAL_CACHE_DIR, HIST_FILENAME)


def _get_store():
    from core.cargo_dod.data import get_store
    return get_store()


def _max_selectable_date() -> date:
    from core.cargo_dod.data import max_selectable_date
    return max_selectable_date()


def _get_dataset_vessels() -> pd.DataFrame:
    from core.lng_data_kpler.data import get_dataset_vessels
    return get_dataset_vessels()


def _get_kpler_last_refresh():
    from core.lng_data_kpler.data import get_kpler_last_refresh
    return get_kpler_last_refresh()


def _get_bbg_ships() -> pd.DataFrame:
    from core.lng_data_bbg_ships.data import get_bbg_ships
    return get_bbg_ships()


def _list_cached_dates() -> set[date]:
    global _cached_dates, _cached_dates_ts
    now = time.monotonic()
    if (_cached_dates_ts is not None
            and now - _cached_dates_ts < _CACHED_DATES_TTL_S):
        return set(_cached_dates)
    try:
        _cached_dates = set(_get_store().list_cached_dates())
        _cached_dates_ts = now
    except Exception as ex:
        logger.warning("Cached-dates listing failed (%s); using local "
                       "history parquet only", ex)
    return set(_cached_dates)


def _load_hist() -> pd.DataFrame:
    global _hist
    if _hist is None:
        path = _hist_path()
        if os.path.exists(path):
            try:
                _hist = pd.read_parquet(path)
                missing = [c for c in HIST_COLUMNS if c not in _hist.columns]
                for col in missing:
                    _hist[col] = pd.NA
                _hist = _hist[HIST_COLUMNS]
            except Exception as ex:
                logger.warning("Corrupt/outdated vessel forecast history %s "
                               "(%s); rebuilding", path, ex)
                _hist = _empty_hist()
        else:
            _hist = _empty_hist()
        if not _hist.empty:
            _hist_dates.update(pd.to_datetime(_hist["snapshot_date"]).dt.date)
    return _hist


def _col(df: pd.DataFrame, *names: str) -> str | None:
    for name in names:
        if name in df.columns:
            return name
    return None


def _series(df: pd.DataFrame, *names: str, default: Any = pd.NA) -> pd.Series:
    name = _col(df, *names)
    if name is None:
        return pd.Series(default, index=df.index)
    return df[name]


def extract_on_water_rows(raw: pd.DataFrame, snapshot_date: date) -> pd.DataFrame:
    """On-water (In Transit / Loading) cargo rows from one raw PIT snapshot."""
    if raw is None or raw.empty:
        return _empty_hist()
    status_col = _col(raw, _COL_STATUS, "trade_status")
    imo_col = _col(raw, _COL_IMO, "imo_vessel")
    if status_col is None or imo_col is None:
        logger.warning("Snapshot %s missing status/IMO columns; skipping",
                       snapshot_date)
        return _empty_hist()

    on_water = raw[raw[status_col].isin(TRADE_STATUSES)].copy()
    if on_water.empty:
        return _empty_hist()

    imo = pd.to_numeric(on_water[imo_col], errors="coerce")
    volume = pd.to_numeric(
        _series(on_water, _COL_VOL, "volume_origin_m3"), errors="coerce")
    kpler_id = pd.to_numeric(
        _series(on_water, _COL_ID, "id_vessel"), errors="coerce")
    confidence = pd.to_numeric(
        _series(on_water, _COL_CONF, "forecasted_confidence"), errors="coerce")

    out = pd.DataFrame({
        "snapshot_date": pd.Timestamp(snapshot_date),
        "imo": imo,
        "vessel": _series(on_water, _COL_VESSEL, "vessel").astype(str),
        "kpler_vessel_id": kpler_id,
        "status": on_water[status_col].astype(str),
        "from_terminal": _series(on_water, _COL_FROM_TERM,
                                 "installation_origin"),
        "from_country": _series(on_water, _COL_FROM_COUNTRY, "country_origin"),
        "departure_date": pd.to_datetime(
            _series(on_water, _COL_DATE_ORIGIN, "date_origin"),
            errors="coerce"),
        "volume_m3": volume,
        "to_country": _series(on_water, _COL_TO_COUNTRY,
                              "country_destination"),
        "to_terminal": _series(on_water, _COL_TO_TERM,
                               "installation_destination"),
        "to_continent": _series(on_water, _COL_TO_CONTINENT,
                                "continent_destination"),
        "forecasted_destination": _series(
            on_water, _COL_FORECAST_DEST, "forecasted_destination"),
        "eta": pd.to_datetime(
            _series(on_water, _COL_ETA, "date_destination"), errors="coerce"),
        "source": _series(on_water, _COL_SOURCE, "eta_source_destination"),
        "confidence": confidence,
        "voyage_id": _series(on_water, _COL_VOYAGE, "id_voyage"),
        "is_live": False,
    })
    out = out.dropna(subset=["imo"])
    out["imo"] = out["imo"].astype("int64")
    return out[HIST_COLUMNS]


def _blank(value: Any) -> bool:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return True
    text = str(value).strip()
    return (not text) or text.lower() in ("nan", "none", "<na>", "nat")


def _text(value: Any) -> str:
    return "" if _blank(value) else str(value).strip()


def flag_forecast_changes(history: pd.DataFrame) -> pd.DataFrame:
    """Mark rows where destination or ETA-source changed vs the prior snapshot.

    Input is expected to be a single-vessel frame.  Comparison is in
    chronological order; the returned frame keeps that order.
    """
    if history is None or history.empty:
        return _empty_hist() if history is None else history.copy()

    df = history.sort_values(["snapshot_date", "is_live"]).copy()
    dest_key = (
        df["to_country"].map(_text) + "|"
        + df["to_terminal"].map(_text) + "|"
        + df["forecasted_destination"].map(_text)
    )
    source_key = df["source"].map(_text)
    eta_key = df["eta"].map(
        lambda v: "" if _blank(v) else pd.Timestamp(v).strftime("%Y-%m-%d"))

    prev_dest = dest_key.shift(1)
    prev_source = source_key.shift(1)
    prev_eta = eta_key.shift(1)
    has_prev = prev_dest.notna()

    df["dest_changed"] = has_prev & (dest_key != prev_dest)
    df["source_changed"] = has_prev & (source_key != prev_source)
    df["eta_changed"] = has_prev & (eta_key != prev_eta)
    return df


def cargo_volume_mcm(volume_m3: Any) -> float:
    vol = pd.to_numeric(volume_m3, errors="coerce")
    if pd.isna(vol):
        return 0.0
    return float(vol) * M3_LNG_TO_MCM


def is_laden_volume(volume: Any) -> bool:
    """True when Kpler vessels ``Volume`` (m3 LNG) is strictly positive."""
    vol = pd.to_numeric(volume, errors="coerce")
    return bool(pd.notna(vol) and vol > 0)


def _ensure_hist(start: date, end: date) -> tuple[pd.DataFrame, list[date],
                                                  list[date]]:
    """Return history rows covering [start, end], building missing dates."""
    global _hist
    want = [d.date() for d in pd.date_range(start, end, freq="D")]
    store = _get_store()
    cached = _list_cached_dates()

    with _lock:
        hist = _load_hist()
        cached |= _hist_dates
        to_build = [d for d in want if d in cached and d not in _hist_dates]

        new_frames = []
        for snapshot_date in to_build:
            try:
                raw = store.read_trades_snapshot(snapshot_date)
            except Exception as ex:
                logger.warning("Cache read failed for %s: %s",
                               snapshot_date, ex)
                cached.discard(snapshot_date)
                continue
            if raw is None:
                cached.discard(snapshot_date)
                continue
            new_frames.append(extract_on_water_rows(raw, snapshot_date))
            _hist_dates.add(snapshot_date)

        if new_frames:
            hist = pd.concat([hist] + new_frames, ignore_index=True)
            hist = hist.sort_values(
                ["snapshot_date", "imo"], ignore_index=True)
            _hist = hist
            try:
                os.makedirs(PIT_LOCAL_CACHE_DIR, exist_ok=True)
                hist.to_parquet(_hist_path(), engine="pyarrow",
                                compression="snappy")
            except Exception as ex:
                logger.warning("Failed to persist vessel forecast history: %s",
                               ex)

        available = [d for d in want if d in cached and d in _hist_dates]
        missing = [d for d in want if d not in cached]
        dates = pd.to_datetime(hist["snapshot_date"]).dt.date
        in_range = hist[(dates >= start) & (dates <= end)].copy()

    return in_range, available, missing


def last_load_date(rows: pd.DataFrame) -> date | None:
    """Earliest plausible load date from on-water rows for one cargo."""
    if rows is None or rows.empty or "departure_date" not in rows.columns:
        return None
    dep = pd.to_datetime(rows["departure_date"], errors="coerce").dropna()
    if dep.empty:
        return None
    # The current cargo's origin date — use the latest non-null departure
    # so a re-load is not mixed with a prior voyage still in the window.
    latest = dep.max()
    return latest.date() if hasattr(latest, "date") else pd.Timestamp(latest).date()


def slice_since_last_load(
    imo: int,
    *,
    as_of: date | None = None,
    load_date: date | None = None,
    max_lookback_days: int = MAX_LOOKBACK_DAYS,
) -> tuple[pd.DataFrame, date | None, list[date]]:
    """History for *imo* from last load (capped) through *as_of*.

    Returns ``(rows, load_date, missing_dates)``.  When *load_date* is
    known (e.g. from the live vessels snapshot) only that window is read
    from the PIT store; otherwise the capped lookback is scanned first.
    """
    as_of = as_of or _max_selectable_date()
    earliest = as_of - timedelta(days=max_lookback_days)
    start = earliest
    if load_date is not None:
        # Two-day buffer: vessels "Departure date" can sit slightly after
        # the Kpler trade origin date.
        start = max(load_date - timedelta(days=2), earliest)
    if start > as_of:
        start = as_of

    window, _available, missing = _ensure_hist(start, as_of)

    vessel = window[window["imo"] == int(imo)].copy()
    if vessel.empty:
        return vessel, load_date, missing

    inferred = last_load_date(vessel)
    load = inferred or load_date
    if load is not None:
        dates = pd.to_datetime(vessel["snapshot_date"]).dt.date
        vessel = vessel[dates >= load]
        missing = [d for d in missing if d >= load]
    return vessel.sort_values(["snapshot_date", "is_live"]), load, missing


def _vessels_frame() -> pd.DataFrame:
    vessels = _get_dataset_vessels()
    if vessels is None or vessels.empty:
        return pd.DataFrame()
    return vessels


def list_vessels() -> pd.DataFrame:
    """Latest Kpler vessels snapshot, normalised for the dropdown."""
    raw = _vessels_frame()
    if raw.empty:
        return pd.DataFrame(columns=[
            "imo", "name", "kpler_vessel_id", "status", "volume_m3",
            "is_laden", "last_port_call", "departure_date", "destination",
            "destination_source", "forecasted_destination", "eta",
        ])

    imo = pd.to_numeric(_series(raw, "IMO", "imo"), errors="coerce")
    volume = pd.to_numeric(_series(raw, "Volume", "volume"), errors="coerce")
    kpler_id = pd.to_numeric(
        _series(raw, "Vessel id", "vessel_id"), errors="coerce")
    status = _series(raw, "Status", "status").fillna("").astype(str)
    name = _series(raw, "Name", "vessel_name", "Vessel").fillna("").astype(str)

    out = pd.DataFrame({
        "imo": imo,
        "name": name.str.strip(),
        "kpler_vessel_id": kpler_id,
        "status": status.str.strip(),
        "volume_m3": volume,
        "is_laden": volume.fillna(0) > 0,
        "last_port_call": _series(raw, "Last port-call", "last_port_call"),
        "departure_date": pd.to_datetime(
            _series(raw, "Departure date", "departure_date"), errors="coerce"),
        "destination": _series(raw, "Destination", "destination"),
        "destination_source": _series(
            raw, "Destination source", "destination_source"),
        "forecasted_destination": _series(
            raw, "Forecasted destination", "forecasted_destination"),
        "eta": pd.to_datetime(_series(raw, "ETA", "eta"), errors="coerce"),
    })
    out = out.dropna(subset=["imo"])
    out["imo"] = out["imo"].astype("int64")
    out = out[out["name"].str.len() > 0]
    # Keep active fleet plus any laden ship that is not tagged Active.
    keep = out["status"].eq("Active") | out["is_laden"]
    out = out[keep]
    return out.sort_values(["is_laden", "name"], ascending=[False, True],
                           ignore_index=True)


def live_forecast_row(vessel: pd.Series) -> dict[str, Any]:
    """One 'live' row from the current Kpler vessels snapshot."""
    fetched = _get_kpler_last_refresh()
    snapshot_ts = pd.Timestamp(fetched) if fetched else pd.Timestamp.utcnow()
    if snapshot_ts.tzinfo is not None:
        snapshot_ts = snapshot_ts.tz_convert("UTC").tz_localize(None)
    volume_m3 = pd.to_numeric(vessel.get("volume_m3"), errors="coerce")
    kpler_id = pd.to_numeric(vessel.get("kpler_vessel_id"), errors="coerce")
    return {
        "snapshot_date": snapshot_ts,
        "imo": int(vessel["imo"]),
        "vessel": _text(vessel.get("name")),
        "kpler_vessel_id": kpler_id if pd.notna(kpler_id) else pd.NA,
        "status": "Live",
        "from_terminal": vessel.get("last_port_call"),
        "from_country": pd.NA,
        "departure_date": pd.NaT,
        "volume_m3": volume_m3,
        "to_country": vessel.get("destination"),
        "to_terminal": pd.NA,
        "to_continent": pd.NA,
        "forecasted_destination": vessel.get("forecasted_destination"),
        "eta": vessel.get("eta"),
        "source": vessel.get("destination_source"),
        "confidence": pd.NA,
        "voyage_id": pd.NA,
        "is_live": True,
    }


def snapshot_datetime(snapshot_date) -> datetime:
    ts = pd.Timestamp(snapshot_date)
    if ts.hour or ts.minute or ts.second or getattr(ts, "nanosecond", 0):
        return ts.to_pydatetime()
    return datetime(ts.year, ts.month, ts.day, SNAPSHOT_HOUR_UTC)


def get_bbg_position(imo: int) -> pd.Series | None:
    """Current Bloomberg AIS row for *imo*, or None."""
    try:
        ships = _get_bbg_ships()
    except Exception as ex:
        logger.warning("Bloomberg LNG ships cache unavailable: %s", ex)
        return None
    if ships is None or ships.empty or "imo" not in ships.columns:
        return None
    imos = pd.to_numeric(ships["imo"], errors="coerce")
    match = ships[imos == int(imo)]
    if match.empty:
        return None
    return match.iloc[0]


def get_bbg_track(
    imo: int,
    start=None,
) -> pd.DataFrame:
    """Archived Bloomberg positions for *imo* since *start*, joined on IMO."""
    try:
        from core.lng_data_bbg_ships.store import get_position_history
        return get_position_history(int(imo), start=start)
    except Exception as ex:
        logger.warning("Bloomberg position history unavailable: %s", ex)
        return pd.DataFrame()


def vessel_dropdown_options(vessels: pd.DataFrame) -> list[dict[str, Any]]:
    options = []
    for _, row in vessels.iterrows():
        imo = int(row["imo"])
        name = _text(row.get("name")) or f"IMO {imo}"
        if row.get("is_laden"):
            vol = cargo_volume_mcm(row.get("volume_m3"))
            tag = f"laden {vol:,.0f} mcm" if vol else "laden"
        else:
            tag = "ballast"
        options.append({
            "label": f"{name} (IMO {imo}, {tag})",
            "value": imo,
        })
    return options
