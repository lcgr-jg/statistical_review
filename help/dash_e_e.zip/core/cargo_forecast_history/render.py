"""Dash component builders for the Cargo Forecast History page."""
from __future__ import annotations

from typing import Any

import pandas as pd
import plotly.graph_objects as go
from dash import html

from core.cargo_forecast_history.constants import (
    BBG_VESSEL_MAP_URL,
    KPLER_VESSEL_MAP_URL,
)
from core.cargo_forecast_history.data import cargo_volume_mcm, snapshot_datetime
from core.styles import COLORS

_CHANGE_BG = "#fff3bf"
_LIVE_BG = "#e8f1f6"

_TABLE_STYLE = {
    "borderCollapse": "collapse",
    "fontSize": "13px",
    "color": COLORS["text_primary"],
    "width": "100%",
}
_TH_STYLE = {
    "backgroundColor": COLORS["table_header_bg"],
    "border": f"1px solid {COLORS['border']}",
    "padding": "6px 10px",
    "textAlign": "left",
    "fontWeight": "600",
    "position": "sticky",
    "top": "0",
    "zIndex": 1,
}
_TD_STYLE = {
    "border": f"1px solid {COLORS['border']}",
    "padding": "5px 10px",
    "textAlign": "left",
    "whiteSpace": "nowrap",
}

_MAPBOX = {
    "style": "white-bg",
    "layers": [
        {
            "below": "traces",
            "sourcetype": "raster",
            "sourceattribution": "Esri",
            "source": [
                "https://server.arcgisonline.com/ArcGIS/rest/services/"
                "World_Street_Map/MapServer/tile/{z}/{y}/{x}"
            ],
        }
    ],
}


def _blank(value: Any) -> bool:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return True
    text = str(value).strip()
    return (not text) or text.lower() in ("nan", "none", "<na>", "nat")


def _fmt(value: Any, fallback: str = "—") -> str:
    return fallback if _blank(value) else str(value).strip()


def _fmt_dt(value: Any, fmt: str = "%d-%b-%y") -> str:
    if _blank(value):
        return "—"
    try:
        return pd.Timestamp(value).strftime(fmt)
    except Exception:
        return _fmt(value)


def _fmt_forecast_when(row: pd.Series) -> str:
    if bool(row.get("is_live")):
        return _fmt_dt(row.get("snapshot_date"), "%d-%b-%y %H:%M") + " UTC live"
    return _fmt_dt(snapshot_datetime(row.get("snapshot_date")),
                   "%d-%b-%y %H:%M") + " UTC"


def kpler_map_url(kpler_vessel_id: Any) -> str | None:
    try:
        if _blank(kpler_vessel_id):
            return None
        vid = int(float(kpler_vessel_id))
    except (TypeError, ValueError):
        return None
    return KPLER_VESSEL_MAP_URL.format(vid)


def bloomberg_map_url(imo: Any) -> str | None:
    try:
        if _blank(imo):
            return None
        vid = int(float(imo))
    except (TypeError, ValueError):
        return None
    return BBG_VESSEL_MAP_URL.format(vid)


_LINK_STYLE = {
    "fontSize": "13px",
    "fontWeight": "600",
    "color": COLORS["accent"],
    "textDecoration": "none",
    "padding": "8px 12px",
    "border": f"1px solid {COLORS['accent']}",
    "borderRadius": "6px",
    "whiteSpace": "nowrap",
}


def _link_button(label: str, href: str, *, new_tab: bool = True) -> html.A:
    props = {
        "href": href,
        "style": _LINK_STYLE,
    }
    if new_tab:
        props["target"] = "_blank"
        props["rel"] = "noopener noreferrer"
    return html.A(label, **props)


def build_kpler_link(kpler_vessel_id: Any, label: str = "Open in Kpler") -> html.A | html.Span:
    href = kpler_map_url(kpler_vessel_id)
    if not href:
        return html.Span(
            "Kpler vessel id unavailable",
            style={"fontSize": "12px", "color": COLORS["text_muted"]},
        )
    return _link_button(label, href)


def build_bloomberg_link(imo: Any, label: str = "Open in Bloomberg") -> html.A | html.Span:
    href = bloomberg_map_url(imo)
    if not href:
        return html.Span(
            "IMO unavailable",
            style={"fontSize": "12px", "color": COLORS["text_muted"]},
        )
    # bbg:// is handled by the Bloomberg Terminal; a new tab would swallow it.
    return _link_button(label, href, new_tab=False)


def build_location_links(kpler_vessel_id: Any, imo: Any) -> html.Div:
    return html.Div(
        [
            build_kpler_link(kpler_vessel_id,
                             label="Open current location in Kpler"),
            build_bloomberg_link(imo,
                                 label="Open current location in Bloomberg"),
        ],
        style={"display": "flex", "gap": "8px", "flexWrap": "wrap",
               "alignItems": "center"},
    )


def build_headline(
    vessel: pd.Series,
    history: pd.DataFrame,
    load_date,
    n_missing: int,
) -> html.Div:
    name = _fmt(vessel.get("name"), "Vessel")
    vol = cargo_volume_mcm(vessel.get("volume_m3"))
    latest = history.iloc[-1] if history is not None and not history.empty else None

    dest = "—"
    source = "—"
    from_term = _fmt(vessel.get("last_port_call"))
    if latest is not None:
        dest_bits = [
            _fmt(latest.get("to_terminal"), ""),
            _fmt(latest.get("to_country"), ""),
        ]
        dest = ", ".join(b for b in dest_bits if b and b != "—") or _fmt(
            latest.get("forecasted_destination"))
        source = _fmt(latest.get("source"))
        from_term = _fmt(latest.get("from_terminal"), from_term)

    load_label = _fmt_dt(load_date, "%d-%b-%Y") if load_date else "unknown"

    def _card(title: str, value: str) -> html.Div:
        return html.Div(
            style={
                "flex": "1 1 160px",
                "minWidth": "140px",
                "padding": "12px 16px",
                "borderRadius": "10px",
                "border": f"1px solid {COLORS['border']}",
                "backgroundColor": COLORS["card_bg_alt"],
            },
            children=[
                html.Div(title, style={
                    "fontSize": "11px", "fontWeight": "600",
                    "textTransform": "uppercase",
                    "color": COLORS["text_muted"],
                    "letterSpacing": "0.5px"}),
                html.Div(value, style={
                    "fontSize": "16px", "fontWeight": "700",
                    "marginTop": "4px", "color": COLORS["text_primary"]}),
            ],
        )

    note = (
        f"{int(len(history)):,} snapshot"
        f"{'' if len(history) == 1 else 's'} since last load"
    )
    if n_missing:
        note += f"  ·  {n_missing:,} day(s) missing from the PIT cache"

    return html.Div([
        html.Div(
            style={"display": "flex", "gap": "12px", "flexWrap": "wrap"},
            children=[
                _card("Vessel", name),
                _card("Last load", load_label),
                _card("Loading terminal", from_term),
                _card("Volume", f"{vol:,.0f} mcm"),
                _card("Forecast destination", dest),
                _card("ETA source", source),
            ],
        ),
        html.Div(note, style={
            "marginTop": "10px", "fontSize": "12px",
            "color": COLORS["text_muted"]}),
    ])


def _td(value: str, *, changed: bool = False, live: bool = False,
        align: str = "left") -> html.Td:
    style = {**_TD_STYLE, "textAlign": align}
    if live:
        style["backgroundColor"] = _LIVE_BG
        style["fontWeight"] = "600"
    if changed:
        style["backgroundColor"] = _CHANGE_BG
        style["fontWeight"] = "600"
    return html.Td(value, style=style)


def build_forecast_table(history: pd.DataFrame) -> html.Div:
    if history is None or history.empty:
        return html.Div(
            "No cached Kpler snapshots found for this vessel since last load.",
            style={"fontSize": "13px", "color": COLORS["text_muted"]},
        )

    # Newest first for inspection; change flags were computed chronologically.
    display = history.sort_values(
        ["snapshot_date", "is_live"], ascending=[False, False])

    header = html.Thead(html.Tr([
        html.Th("Forecast as-of", style=_TH_STYLE),
        html.Th("Loading terminal", style=_TH_STYLE),
        html.Th("Volume (mcm)", style={**_TH_STYLE, "textAlign": "right"}),
        html.Th("Destination country", style=_TH_STYLE),
        html.Th("Destination terminal", style=_TH_STYLE),
        html.Th("Forecasted destination", style=_TH_STYLE),
        html.Th("ETA", style=_TH_STYLE),
        html.Th("Source", style=_TH_STYLE),
        html.Th("Status", style=_TH_STYLE),
    ]))

    rows = []
    for _, row in display.iterrows():
        live = bool(row.get("is_live"))
        vol = cargo_volume_mcm(row.get("volume_m3"))
        vol_txt = f"{vol:,.1f}" if vol else "—"
        rows.append(html.Tr([
            _td(_fmt_forecast_when(row), live=live),
            _td(_fmt(row.get("from_terminal")), live=live),
            _td(vol_txt, live=live, align="right"),
            _td(_fmt(row.get("to_country")),
                changed=bool(row.get("dest_changed")), live=live),
            _td(_fmt(row.get("to_terminal")),
                changed=bool(row.get("dest_changed")), live=live),
            _td(_fmt(row.get("forecasted_destination")),
                changed=bool(row.get("dest_changed")), live=live),
            _td(_fmt_dt(row.get("eta"), "%d-%b-%y"),
                changed=bool(row.get("eta_changed")), live=live),
            _td(_fmt(row.get("source")),
                changed=bool(row.get("source_changed")), live=live),
            _td(_fmt(row.get("status")), live=live),
        ]))

    return html.Div(
        html.Table([header, html.Tbody(rows)], style=_TABLE_STYLE),
        style={"maxHeight": "560px", "overflow": "auto"},
    )


def empty_map_figure(message: str = "Select a vessel to show its Bloomberg position.") -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        mapbox={**_MAPBOX, "center": {"lat": 20.0, "lon": 10.0}, "zoom": 1.2},
        margin={"l": 0, "r": 0, "t": 8, "b": 0},
        height=560,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        annotations=[{
            "text": message,
            "xref": "paper", "yref": "paper",
            "x": 0.5, "y": 0.5, "showarrow": False,
            "font": {"size": 13, "color": COLORS["text_muted"]},
        }],
        font={"color": COLORS["text_primary"]},
        dragmode="pan",
        hovermode="closest",
    )
    return fig


def _hover_for_point(row: pd.Series, *, vessel_name: str, current: bool) -> str:
    last_seen = row.get("last_seen", row.get("snapshot_at"))
    heading = pd.to_numeric(row.get("heading"), errors="coerce")
    speed = pd.to_numeric(
        row.get("speed_knots", row.get("reported_speed_knots", row.get("reported_speed"))),
        errors="coerce",
    )
    dest = _fmt(row.get("destination", row.get("normalized_destination")))
    cargo_status = _fmt(row.get("cargo_status"))
    nav = _fmt(row.get("navigation_status"))
    imo_txt = str(int(row["imo"])) if pd.notna(row.get("imo")) else "—"
    label = "Current" if current else "Track"
    hover_lines = [
        f"<b>{vessel_name or _fmt(row.get('vessel_name'))}</b> ({label})",
        f"IMO {imo_txt}",
        f"As-of: {_fmt_dt(row.get('snapshot_at'), '%d-%b-%y %H:%M')} UTC",
        f"Last seen: {_fmt_dt(last_seen, '%d-%b-%y %H:%M')} UTC",
    ]
    if pd.notna(heading):
        hover_lines.append(f"Heading: {heading:.0f}°")
    if pd.notna(speed):
        hover_lines.append(f"Speed: {speed:.1f} kn")
    if cargo_status != "—":
        hover_lines.append(f"Cargo status: {cargo_status}")
    if dest != "—":
        hover_lines.append(f"AIS dest: {dest}")
    if nav != "—":
        hover_lines.append(f"Nav: {nav}")
    return "<br>".join(hover_lines)


def _fit_mapbox(lats: list[float], lons: list[float]) -> dict:
    lat_c = sum(lats) / len(lats)
    lon_c = sum(lons) / len(lons)
    span = max(max(lats) - min(lats), abs(max(lons) - min(lons)))
    if span < 0.4:
        zoom = 6.2
    elif span < 2:
        zoom = 5.0
    elif span < 8:
        zoom = 3.8
    elif span < 25:
        zoom = 2.8
    else:
        zoom = 2.0
    return {"center": {"lat": lat_c, "lon": lon_c}, "zoom": zoom}


def build_position_map(
    position: pd.Series | None,
    *,
    track: pd.DataFrame | None = None,
    vessel_name: str = "",
) -> go.Figure:
    placed = pd.DataFrame()
    if track is not None and not track.empty:
        placed = track.dropna(subset=["latitude", "longitude"]).copy()

    current_lat = current_lon = None
    if position is not None:
        current_lat = pd.to_numeric(position.get("latitude"), errors="coerce")
        current_lon = pd.to_numeric(position.get("longitude"), errors="coerce")
        if pd.isna(current_lat) or pd.isna(current_lon):
            current_lat = current_lon = None

    if placed.empty and current_lat is None:
        return empty_map_figure("No Bloomberg position for this vessel.")

    fig = go.Figure()
    if len(placed) >= 2:
        fig.add_trace(go.Scattermapbox(
            lon=placed["longitude"],
            lat=placed["latitude"],
            mode="lines",
            name="AIS track",
            line={"width": 2, "color": COLORS["accent"]},
            hoverinfo="skip",
            showlegend=False,
        ))
    if not placed.empty:
        hovers = [
            _hover_for_point(row, vessel_name=vessel_name, current=False)
            for _, row in placed.iterrows()
        ]
        fig.add_trace(go.Scattermapbox(
            lon=placed["longitude"],
            lat=placed["latitude"],
            mode="markers",
            name="Hourly snapshots",
            marker={"size": 7, "color": "#9bb8c9"},
            text=hovers,
            hovertemplate="%{text}<extra></extra>",
            showlegend=False,
        ))

    if current_lat is not None:
        hover = _hover_for_point(position, vessel_name=vessel_name, current=True)
        fig.add_trace(go.Scattermapbox(
            lon=[float(current_lon)],
            lat=[float(current_lat)],
            mode="markers",
            name="Current",
            marker={"size": 14, "color": COLORS["accent"]},
            text=[hover],
            hovertemplate="%{text}<extra></extra>",
            showlegend=False,
        ))

    lats = list(pd.to_numeric(placed["latitude"], errors="coerce").dropna()) if not placed.empty else []
    lons = list(pd.to_numeric(placed["longitude"], errors="coerce").dropna()) if not placed.empty else []
    if current_lat is not None:
        lats.append(float(current_lat))
        lons.append(float(current_lon))
    mapbox = {**_MAPBOX, **_fit_mapbox(lats, lons)}

    fig.update_layout(
        mapbox=mapbox,
        margin={"l": 0, "r": 0, "t": 8, "b": 0},
        height=560,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font={"color": COLORS["text_primary"]},
        dragmode="pan",
        hovermode="closest",
    )
    return fig


def ballast_message(vessel_name: str) -> html.Div:
    return html.Div(
        f"{vessel_name} is currently ballast / unladen — there is no cargo "
        f"forecast to display. Select a laden vessel to inspect destination "
        f"forecast changes since last load.",
        style={
            "fontSize": "13px",
            "color": COLORS["text_secondary"],
            "padding": "8px 0",
        },
    )
