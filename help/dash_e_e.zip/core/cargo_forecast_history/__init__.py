"""LNG — Cargo Forecast History page package.

Per-vessel Kpler forecast lineage since last cargo load, from the same
point-in-time snapshot store used by Cargo DoD / Arrivals Analysis, plus
the current Bloomberg AIS position (Qatar Monitor source).
"""
