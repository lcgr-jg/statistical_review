"""EU Gas Balance — Storage Scenarios callbacks."""
from __future__ import annotations

import logging
from datetime import datetime

from dash import Input, Output, callback, html

from core.gas_storage_scenarios.charts import build_projected_fill_chart
from core.gas_storage_scenarios.constants import (
    DEFAULT_PATH_BASIS,
    DEFAULT_TARGET_PCT,
    PATH_BASIS_RECENT_MA,
    parse_path_basis,
    resolve_season,
)
from core.gas_storage_scenarios.data import (
    format_ce_refresh_age,
    get_cached_fill,
    get_cached_injection,
    get_ce_last_refresh,
    injection_needed,
    parse_countries,
    project_scenarios,
    recent_ma_rates,
)
from core.gas_storage_scenarios.table import (
    build_path_summary_table,
    build_target_kpi_panel,
)
from core.styles import get_status_badge_style

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "12px 16px",
            "borderRadius": "8px",
            "fontSize": "13px",
            "width": "100%",
        },
    )


def _status_message(as_of) -> str:
    refresh = get_ce_last_refresh()
    as_of_str = as_of.strftime("%d-%b-%Y") if as_of is not None else "—"
    return (
        f"Loaded CE storage through {as_of_str} · "
        f"{format_ce_refresh_age(refresh)}"
    )


def _parse_target_pct(value) -> float:
    try:
        pct = float(value)
    except (TypeError, ValueError):
        return float(DEFAULT_TARGET_PCT)
    if pct < 65 or pct > 100:
        return float(DEFAULT_TARGET_PCT)
    return pct


@callback(
    Output("gas-stor-scen-page-blurb", "children"),
    Output("gas-stor-scen-kpi-title", "children"),
    Output("gas-stor-scen-kpi", "children"),
    Output("gas-stor-scen-kpi-subtitle", "children"),
    Output("gas-stor-scen-chart-title", "children"),
    Output("gas-stor-scen-chart", "figure"),
    Output("gas-stor-scen-chart-subtitle", "children"),
    Output("gas-stor-scen-table", "children"),
    Output("gas-stor-scen-table-subtitle", "children"),
    Output("gas-stor-scen-status", "children"),
    Input("gas-stor-scen-refresh", "n_clicks"),
    Input("gas-stor-scen-countries", "value"),
    Input("gas-stor-scen-target-pct", "value"),
    Input("gas-stor-scen-path-basis", "value"),
    prevent_initial_call=False,
)
def update_scenarios(_n_clicks, countries_value, target_pct_value, path_basis_value):
    countries = parse_countries(countries_value)
    target_pct = _parse_target_pct(target_pct_value)
    path_basis_value = path_basis_value or DEFAULT_PATH_BASIS
    basis_kind = parse_path_basis(path_basis_value)

    to_date = datetime.now()
    season = resolve_season(to_date.date())
    target_label = season["target_date"].strftime("%d-%b-%Y")
    flow = season["flow_noun"]
    gap_label = season["gap_label"]

    blurb = (
        f"Fill-target gap and {flow} path scenarios to {target_label} "
        f"({season['season']} season · Commodity Essentials storage)."
    )
    kpi_title = f"{gap_label} by {target_label}"

    if basis_kind == PATH_BASIS_RECENT_MA:
        chart_title = f"Recent MA {flow} paths"
    else:
        chart_title = f"Prior-year {flow} path outcomes"

    try:
        df_fill = get_cached_fill()
        df_inj = get_cached_injection()
    except Exception as exc:
        logger.exception("Storage Scenarios load: %s", exc)
        err = _alert(str(exc), "error")
        empty_fig = build_projected_fill_chart(
            {"season_info": season}, target_pct=target_pct
        )
        return (
            blurb,
            kpi_title,
            err,
            f"target {target_pct:.0f}% by {target_label}",
            chart_title,
            empty_fig,
            "current & prior season actuals · historic range · path forecast",
            err,
            "end fill by path",
            err,
        )

    kpi = injection_needed(
        df_fill,
        countries,
        target_pct,
        to_date=to_date,
        season_info=season,
    )
    projected = project_scenarios(
        df_fill,
        df_inj,
        countries,
        path_basis=path_basis_value,
        to_date=to_date,
        season_info=season,
    )
    kpi["ma_rates_mcm_d"] = recent_ma_rates(
        df_inj,
        countries,
        as_of=kpi.get("as_of") or projected.get("as_of"),
    )

    kpi_panel = build_target_kpi_panel(kpi)
    fig = build_projected_fill_chart(projected, target_pct=target_pct)
    table = build_path_summary_table(
        projected["summary"],
        flow_noun=flow,
        path_basis=projected.get("path_basis") or path_basis_value,
    )

    as_of = kpi.get("as_of") or projected.get("as_of")
    status = _alert(_status_message(as_of), "success")
    country_label = "+".join(countries) if countries else "—"
    kpi_sub = f"{country_label} · target {target_pct:.0f}% by {target_label}"

    if basis_kind == PATH_BASIS_RECENT_MA:
        n_paths = len(projected["paths"])
        chart_sub = (
            f"{country_label} · 7/14/21/28d MA forecasts · to {target_label}"
        )
        table_sub = f"{n_paths} MA windows · end fill bcm and %"
    else:
        n_paths = len(projected["paths"])
        chart_sub = (
            f"{country_label} · current & prior season actuals · "
            f"historic range · path forecast to {target_label}"
        )
        table_sub = f"{n_paths} years · end fill bcm and %"

    return (
        blurb,
        kpi_title,
        kpi_panel,
        kpi_sub,
        chart_title,
        fig,
        chart_sub,
        table,
        table_sub,
        status,
    )
