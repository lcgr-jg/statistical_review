"""Layout for the EU Gas Balance — Storage Scenarios page."""
from __future__ import annotations

from dash import dcc, html

from core.gas_storage_scenarios.constants import (
    DEFAULT_MULTI_COUNTRIES,
    DEFAULT_PATH_BASIS,
    DEFAULT_TARGET_PCT,
    MULTI_COUNTRY_OPTIONS,
    PATH_BASIS_OPTIONS,
    TARGET_PCT_OPTIONS,
    resolve_season,
)
from core.styles import COLORS

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "center",
    "flexWrap": "wrap",
    "gap": "16px",
}

_BTN_PRIMARY = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
    "transition": "all 0.2s",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "visible",
    "marginBottom": "20px",
}

_PANEL_HEADER = {
    "padding": "16px 20px 8px 20px",
    "display": "flex",
    "alignItems": "baseline",
    "flexWrap": "nowrap",
    "gap": "8px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "whiteSpace": "nowrap",
    "flexShrink": "0",
}

_PANEL_SUBTITLE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "whiteSpace": "nowrap",
    "overflow": "hidden",
    "textOverflow": "ellipsis",
}


def build_layout() -> html.Div:
    season = resolve_season()
    target_label = season["target_date"].strftime("%d %b %Y")
    flow = season["flow_noun"]
    return html.Div(
        style={
            "minHeight": "100vh",
            "backgroundColor": COLORS["background"],
            "padding": "20px",
        },
        children=[
            html.Div(
                [
                    html.H1(
                        "Storage Scenarios",
                        style={
                            "fontSize": "22px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "margin": "0 0 4px 0",
                        },
                    ),
                    html.P(
                        id="gas-stor-scen-page-blurb",
                        children=(
                            f"Fill-target gap and {flow} path scenarios to "
                            f"{target_label} (Commodity Essentials storage)."
                        ),
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 20px 0",
                        },
                    ),
                ]
            ),
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Button(
                        "Refresh",
                        id="gas-stor-scen-refresh",
                        n_clicks=0,
                        style=_BTN_PRIMARY,
                    ),
                    html.Div(
                        [
                            html.Label("Countries", style=_LABEL),
                            html.Div(
                                dcc.Dropdown(
                                    id="gas-stor-scen-countries",
                                    options=MULTI_COUNTRY_OPTIONS,
                                    value=DEFAULT_MULTI_COUNTRIES,
                                    multi=True,
                                    placeholder="Select countries…",
                                    style={"fontSize": "13px"},
                                ),
                                style={"width": "420px", "minWidth": "240px"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Label("Target fill %", style=_LABEL),
                            html.Div(
                                dcc.Dropdown(
                                    id="gas-stor-scen-target-pct",
                                    options=TARGET_PCT_OPTIONS,
                                    value=DEFAULT_TARGET_PCT,
                                    clearable=False,
                                    style={"fontSize": "13px"},
                                ),
                                style={"width": "110px"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Label("Path basis", style=_LABEL),
                            html.Div(
                                dcc.Dropdown(
                                    id="gas-stor-scen-path-basis",
                                    options=PATH_BASIS_OPTIONS,
                                    value=DEFAULT_PATH_BASIS,
                                    clearable=False,
                                    style={"fontSize": "13px"},
                                ),
                                style={"width": "200px"},
                            ),
                        ]
                    ),
                    html.Div(id="gas-stor-scen-status"),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span(
                                id="gas-stor-scen-kpi-title",
                                children=f"{season['gap_label']} by {target_label}",
                                style=_PANEL_TITLE,
                            ),
                            html.Span(
                                "aggregated stock vs target fill %",
                                id="gas-stor-scen-kpi-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        id="gas-stor-scen-kpi",
                        style={"padding": "16px 20px 20px 20px"},
                        children=[
                            html.Div(
                                "Click Refresh to load storage data.",
                                style={
                                    "color": COLORS["text_muted"],
                                    "fontSize": "13px",
                                },
                            )
                        ],
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span(
                                id="gas-stor-scen-chart-title",
                                children=f"Prior-year {flow} path outcomes",
                                style=_PANEL_TITLE,
                            ),
                            html.Span(
                                f"projected fill % to {target_label}",
                                id="gas-stor-scen-chart-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=dcc.Graph(
                            id="gas-stor-scen-chart",
                            config={
                                "displayModeBar": True,
                                "responsive": True,
                            },
                            style={"width": "100%", "minHeight": "480px"},
                        ),
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("Path summary", style=_PANEL_TITLE),
                            html.Span(
                                "end fill by path",
                                id="gas-stor-scen-table-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        id="gas-stor-scen-table",
                        style={"padding": "16px 20px 20px 20px"},
                        children=[
                            html.Div(
                                "Click Refresh to load storage data.",
                                style={
                                    "color": COLORS["text_muted"],
                                    "fontSize": "13px",
                                },
                            )
                        ],
                    ),
                ],
            ),
        ],
    )
