"""EU Gas Balance — Storage Scenarios page package."""
from .layout import build_layout

__all__ = ["build_layout"]
