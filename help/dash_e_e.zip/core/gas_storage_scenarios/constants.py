"""EU Gas Balance — Storage Scenarios page constants."""
from __future__ import annotations

import datetime as dt
from typing import Any

from core.gas_storage_summary.constants import (
    COUNTRY_CODES,
    DEFAULT_MULTI_COUNTRIES,
    FILL_DEFAULT_PRIOR_YEARS,
    FILL_HISTORY_YEAR_MIN,
    MULTI_COUNTRY_OPTIONS,
)

PAGE_PATH = "/power/gas_balance/storage_scenarios"
PAGE_NAME = "Storage Scenarios"
PAGE_TITLE = "EU Gas Storage Scenarios | JG Power Dashboard"
PAGE_ORDER = 73

# Seasons: Apr–Oct inject toward 31 Oct; Nov–Mar withdraw toward 31 Mar.
SEASON_INJECTION = "injection"
SEASON_WITHDRAWAL = "withdrawal"

TARGET_PCT_OPTIONS = [
    {"label": f"{p}%", "value": p} for p in range(65, 101, 5)
]
DEFAULT_TARGET_PCT = 75

# Path basis: prior-year seasonal paths vs all recent MA windows together.
PATH_BASIS_PRIOR = "prior_year"
PATH_BASIS_RECENT_MA = "recent_ma"
PATH_MA_WINDOWS = (7, 14, 21, 28)
PATH_BASIS_OPTIONS = [
    {"label": "Prior-year paths", "value": PATH_BASIS_PRIOR},
    {"label": "Recent MA", "value": PATH_BASIS_RECENT_MA},
]
DEFAULT_PATH_BASIS = PATH_BASIS_PRIOR

# Prior-year path window (calendar / season labels with CE history).
PATH_HISTORY_YEAR_MIN = FILL_HISTORY_YEAR_MIN
PATH_DEFAULT_PRIOR_YEARS = FILL_DEFAULT_PRIOR_YEARS

# Back-compat alias (injection-season default used at import time).
TARGET_DATE = dt.date(dt.date.today().year, 10, 31)


def resolve_season(today: dt.date | None = None) -> dict[str, Any]:
    """
    Pick injection vs withdrawal horizon from *today*.

    * Apr–Oct → injection to 31 Oct of the same year
    * Nov–Dec → withdrawal to 31 Mar of next year
    * Jan–Mar → withdrawal to 31 Mar of the same year
    """
    today = today or dt.date.today()
    y = int(today.year)
    m = int(today.month)

    if m >= 11:  # Nov–Dec
        season = SEASON_WITHDRAWAL
        target = dt.date(y + 1, 3, 31)
        season_start = dt.date(y, 11, 1)
    elif m <= 3:  # Jan–Mar
        season = SEASON_WITHDRAWAL
        target = dt.date(y, 3, 31)
        season_start = dt.date(y - 1, 11, 1)
    else:  # Apr–Oct
        season = SEASON_INJECTION
        target = dt.date(y, 10, 31)
        season_start = dt.date(y, 4, 1)

    if season == SEASON_INJECTION:
        # Chart context: full calendar year of the Oct target.
        chart_start = dt.date(target.year, 1, 1)
        chart_end = dt.date(target.year, 12, 31)
        flow_noun = "injection"
        gap_label = "Injection needed"
    else:
        chart_start = season_start
        chart_end = target
        flow_noun = "withdrawal"
        gap_label = "Withdrawal needed"

    return {
        "season": season,
        "target_date": target,
        "season_start": season_start,
        "chart_start": chart_start,
        "chart_end": chart_end,
        "flow_noun": flow_noun,
        "gap_label": gap_label,
        "is_injection": season == SEASON_INJECTION,
    }


def parse_path_basis(value: str | None) -> str:
    """Return ``PATH_BASIS_PRIOR`` or ``PATH_BASIS_RECENT_MA``."""
    raw = (value or DEFAULT_PATH_BASIS).strip().lower()
    if raw in {PATH_BASIS_RECENT_MA, "ma", "recent_ma", "recent"}:
        return PATH_BASIS_RECENT_MA
    # Legacy single-window values still map to the combined Recent MA view.
    if raw.startswith("ma_") or raw in {str(n) for n in PATH_MA_WINDOWS}:
        return PATH_BASIS_RECENT_MA
    return PATH_BASIS_PRIOR


__all__ = [
    "COUNTRY_CODES",
    "DEFAULT_MULTI_COUNTRIES",
    "DEFAULT_PATH_BASIS",
    "DEFAULT_TARGET_PCT",
    "MULTI_COUNTRY_OPTIONS",
    "PAGE_NAME",
    "PAGE_ORDER",
    "PAGE_PATH",
    "PAGE_TITLE",
    "PATH_BASIS_OPTIONS",
    "PATH_BASIS_PRIOR",
    "PATH_BASIS_RECENT_MA",
    "PATH_DEFAULT_PRIOR_YEARS",
    "PATH_HISTORY_YEAR_MIN",
    "PATH_MA_WINDOWS",
    "SEASON_INJECTION",
    "SEASON_WITHDRAWAL",
    "TARGET_DATE",
    "TARGET_PCT_OPTIONS",
    "parse_path_basis",
    "resolve_season",
]
