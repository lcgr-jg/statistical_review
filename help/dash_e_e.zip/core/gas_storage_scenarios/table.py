"""Storage Scenarios HTML tables / KPI panels."""
from __future__ import annotations

from typing import Any

import pandas as pd
from dash import html

from core.styles import COLORS


def build_target_kpi_panel(kpi: dict[str, Any]) -> html.Div:
    """Compact metrics for the fill-target gap section."""
    if kpi.get("stock_mcm") is None or kpi.get("capacity_mcm") is None:
        return html.Div(
            "No fill data available for the selected countries.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )

    stock_bcm = float(kpi["stock_mcm"]) / 1000.0
    cap_bcm = float(kpi["capacity_mcm"]) / 1000.0
    target_bcm = float(kpi["target_stock_mcm"]) / 1000.0
    needed_mcm = float(kpi["needed_mcm"])
    needed_bcm = needed_mcm / 1000.0
    current_pct = float(kpi["current_fill_pct"])
    target_pct = float(kpi["target_pct"])
    as_of = kpi.get("as_of")
    as_of_str = as_of.strftime("%d-%b-%Y") if as_of is not None else "—"
    countries = ", ".join(kpi.get("countries") or [])

    gap_label = kpi.get("gap_label") or "Injection needed"
    flow_noun = kpi.get("flow_noun") or "injection"

    ma_bits = []
    ma_rates = kpi.get("ma_rates_mcm_d") or {}
    for window in sorted(ma_rates):
        ma_bits.append(f"{int(window)}d {float(ma_rates[window]):+.0f}")
    ma_suffix = f" · recent MA {', '.join(ma_bits)} mcm/d" if ma_bits else ""

    if kpi.get("past_target"):
        pace = "Past target date — gap is illustrative only." + ma_suffix
    elif kpi.get("avg_mcm_d") is not None and kpi.get("days_remaining"):
        pace = (
            f"{kpi['days_remaining']} days to "
            f"{kpi['target_date'].strftime('%d-%b-%Y')} · "
            f"need {kpi['avg_mcm_d']:,.0f} mcm/d {flow_noun} on average "
            f"to hit {target_pct:.0f}%"
            f"{ma_suffix}"
        )
    elif ma_bits:
        pace = f"Recent MA {', '.join(ma_bits)} mcm/d"
    else:
        pace = "—"

    cards = [
        _metric("As of", as_of_str),
        _metric("Countries", countries or "—"),
        _metric("Current fill", f"{current_pct:.1f}%"),
        _metric("Current stock", f"{stock_bcm:.2f} bcm"),
        _metric("Capacity", f"{cap_bcm:.2f} bcm"),
        _metric(f"Target ({target_pct:.0f}%)", f"{target_bcm:.2f} bcm"),
        _metric(
            gap_label,
            f"{needed_bcm:.2f} bcm",
            accent=needed_mcm > 0,
        ),
    ]

    return html.Div(
        [
            html.Div(
                cards,
                style={
                    "display": "grid",
                    "gridTemplateColumns": "repeat(auto-fill, minmax(140px, 1fr))",
                    "gap": "12px",
                },
            ),
            html.P(
                pace,
                style={
                    "fontSize": "12px",
                    "color": COLORS["text_muted"],
                    "margin": "14px 0 0 0",
                },
            ),
        ]
    )


def build_path_summary_table(
    summary: pd.DataFrame,
    *,
    flow_noun: str = "injection",
    path_basis: str = "prior_year",
) -> html.Div:
    """End fill bcm / % and cumulative net flow by path."""
    if summary is None or summary.empty:
        return html.Div(
            "No path outcomes for this selection.",
            style={"color": COLORS["text_muted"], "fontSize": "13px"},
        )

    path_col = (
        "MA window"
        if str(path_basis) in {"recent_ma"} or str(path_basis).startswith("ma")
        else "Year path"
    )
    flow_col = f"{flow_noun.title()} applied (bcm)"
    show_rate = "ma_rate_mcm_d" in summary.columns

    header_cells = [
        html.Th(path_col, style={**_TH, "textAlign": "left"}),
        html.Th("End stock (bcm)", style=_TH),
        html.Th("End fill %", style=_TH),
        html.Th(flow_col, style=_TH),
    ]
    if show_rate:
        header_cells.insert(1, html.Th("MA pace (mcm/d)", style=_TH))
    header = html.Tr(header_cells)

    rows = []
    for i, row in summary.iterrows():
        bg = COLORS["card_bg_alt"] if int(i) % 2 else COLORS["card_bg"]
        label = (
            row["label"]
            if "label" in row and pd.notna(row["label"])
            else str(int(row["year"]))
        )
        cells = [
            html.Td(
                label,
                style={**_TD, "textAlign": "left", "fontWeight": "600"},
            ),
        ]
        if show_rate:
            cells.append(
                html.Td(
                    f"{float(row['ma_rate_mcm_d']):+.1f}",
                    style={**_TD, "textAlign": "right"},
                )
            )
        cells.extend(
            [
                html.Td(
                    f"{float(row['end_stock_bcm']):.2f}",
                    style={**_TD, "textAlign": "right"},
                ),
                html.Td(
                    f"{float(row['end_fill_pct']):.1f}%",
                    style={**_TD, "textAlign": "right"},
                ),
                html.Td(
                    f"{float(row['cum_inj_bcm']):.2f}",
                    style={**_TD, "textAlign": "right"},
                ),
            ]
        )
        rows.append(html.Tr(cells, style={"backgroundColor": bg}))

    if str(path_basis) in {"recent_ma"} or str(path_basis).startswith("ma"):
        footnote = (
            "Each row holds that trailing moving-average daily net "
            f"{flow_noun} rate constant through the seasonal target date "
            "(stock capped at capacity / zero)."
        )
    else:
        footnote = (
            f"Table: each year replays that season's daily net {flow_noun} from "
            "the same calendar point through the target date onto today's stock. "
            "The chart shows current/prior-season actuals, a historic fill range, "
            "and a path-forecast envelope with the prior-season path highlighted."
        )

    return html.Div(
        [
            html.Table(
                [html.Thead(header), html.Tbody(rows)],
                style={
                    "borderCollapse": "collapse",
                    "width": "auto",
                    "fontSize": "12px",
                    "fontFamily": "Calibri, Arial, sans-serif",
                },
            ),
            html.P(
                footnote,
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "marginTop": "8px",
                    "fontStyle": "italic",
                    "maxWidth": "640px",
                },
            ),
        ],
        style={"overflowX": "auto", "display": "inline-block", "maxWidth": "100%"},
    )


def _metric(label: str, value: str, *, accent: bool = False) -> html.Div:
    return html.Div(
        [
            html.Div(
                label,
                style={
                    "fontSize": "11px",
                    "fontWeight": "600",
                    "color": COLORS["text_muted"],
                    "textTransform": "uppercase",
                    "letterSpacing": "0.4px",
                    "marginBottom": "4px",
                },
            ),
            html.Div(
                value,
                style={
                    "fontSize": "18px",
                    "fontWeight": "600",
                    "color": COLORS["accent"] if accent else COLORS["text_primary"],
                },
            ),
        ],
        style={
            "backgroundColor": COLORS["card_bg_alt"],
            "border": f"1px solid {COLORS['border_light']}",
            "borderRadius": "8px",
            "padding": "12px 14px",
        },
    )


_TH = {
    "padding": "6px 10px",
    "textAlign": "center",
    "backgroundColor": COLORS["table_header_bg"],
    "color": COLORS["text_dark"],
    "fontWeight": "600",
    "border": f"1px solid {COLORS['border_light']}",
    "fontSize": "11px",
    "whiteSpace": "nowrap",
}

_TD = {
    "padding": "5px 10px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "color": COLORS["text_primary"],
    "whiteSpace": "nowrap",
}
