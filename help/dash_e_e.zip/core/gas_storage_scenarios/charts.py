﻿"""Storage Scenarios charts."""
from __future__ import annotations

from typing import Any

import pandas as pd
import plotly.graph_objects as go

from core.gas_storage_scenarios.constants import resolve_season
from core.styles import COLORS

_HIST_BAND = "rgba(78, 115, 138, 0.18)"
_PATH_BAND = "rgba(46, 160, 67, 0.20)"
_PREV_YEAR = "#ff7f0e"
_CURR_YEAR = "#1f77b4"
_PATH_DASH = "#2ea043"


_MA_COLORS = ["#2ea043", "#d62728", "#9467bd", "#8c564b"]


def build_projected_fill_chart(
    projected: dict[str, Any] | None = None,
    *,
    paths: dict[int, Any] | None = None,
    target_pct: float | None = None,
) -> go.Figure:
    """
    Seasonal fill chart: historic actual band, current/previous season actuals,
    and either prior-year path envelope or all recent MA forecast lines.
    """
    if projected is None:
        projected = {}
    if paths and not projected.get("paths"):
        projected = {**projected, "paths": paths}

    actuals = projected.get("actuals") or {}
    historic_band = actuals.get("historic_band")
    current = actuals.get("current_year")
    previous = actuals.get("previous_year")
    cur_label = actuals.get("current_year_label")
    prev_label = actuals.get("previous_year_label")
    path_band = projected.get("path_band")
    prev_path = projected.get("prev_year_path")
    prev_path_label = projected.get("prev_year_path_label")
    path_basis = str(projected.get("path_basis") or "")
    is_ma = path_basis == "recent_ma" or path_basis.startswith("ma")
    forecast_paths = projected.get("paths") or {}

    has_actuals = (
        (current is not None and not getattr(current, "empty", True))
        or (previous is not None and not getattr(previous, "empty", True))
        or (
            historic_band is not None
            and isinstance(historic_band, pd.DataFrame)
            and not historic_band.empty
        )
    )
    has_forecast = bool(forecast_paths) or (
        prev_path is not None and not getattr(prev_path, "empty", True)
    )
    if not has_actuals and not has_forecast:
        return _empty_fig("No fill / path data available for this selection.")

    fig = go.Figure()

    # Historic actual min/max band
    if (
        historic_band is not None
        and isinstance(historic_band, pd.DataFrame)
        and not historic_band.empty
        and "min" in historic_band.columns
        and "max" in historic_band.columns
    ):
        band = historic_band.dropna(how="all")
        if not band.empty:
            fig.add_trace(
                go.Scatter(
                    x=band.index.tolist(),
                    y=band["max"].tolist(),
                    mode="lines",
                    line=dict(width=0),
                    name="Historic range (max)",
                    showlegend=False,
                    hoverinfo="skip",
                )
            )
            fig.add_trace(
                go.Scatter(
                    x=band.index.tolist(),
                    y=band["min"].tolist(),
                    mode="lines",
                    line=dict(width=0),
                    fill="tonexty",
                    fillcolor=_HIST_BAND,
                    name="Historic range",
                    hovertemplate=(
                        "Historic range<br>%{x|%d-%b} · "
                        "%{y:.1f}–%{customdata[0]:.1f}%<extra></extra>"
                    ),
                    customdata=band[["max"]].to_numpy(),
                )
            )

    if previous is not None and not getattr(previous, "empty", True):
        label = f"{prev_label} actual" if prev_label else "Previous year"
        fig.add_trace(
            go.Scatter(
                x=previous.index.tolist(),
                y=previous.values.tolist(),
                mode="lines",
                name=label,
                line=dict(color=_PREV_YEAR, width=1.6),
                opacity=0.85,
                hovertemplate=f"{label}<br>%{{x|%d-%b}} · %{{y:.1f}}%<extra></extra>",
            )
        )

    if current is not None and not getattr(current, "empty", True):
        label = f"{cur_label} actual" if cur_label else "Current year"
        fig.add_trace(
            go.Scatter(
                x=current.index.tolist(),
                y=current.values.tolist(),
                mode="lines",
                name=label,
                line=dict(color=_CURR_YEAR, width=2.6),
                hovertemplate=f"{label}<br>%{{x|%d-%b}} · %{{y:.1f}}%<extra></extra>",
            )
        )

    if is_ma:
        # Plot every MA window as its own dashed forecast line.
        labels = list(forecast_paths.keys())
        for i, label in enumerate(labels):
            path = forecast_paths[label]
            if path is None or getattr(path, "empty", True):
                continue
            y = path["fill_pct"] if "fill_pct" in path.columns else path.iloc[:, 0]
            color = _MA_COLORS[i % len(_MA_COLORS)]
            fig.add_trace(
                go.Scatter(
                    x=path.index.tolist(),
                    y=y.tolist(),
                    mode="lines",
                    name=label,
                    line=dict(color=color, width=2.0, dash="dash"),
                    hovertemplate=(
                        f"{label}<br>%{{x|%d-%b}} · %{{y:.1f}}%<extra></extra>"
                    ),
                )
            )
    else:
        # Prior-year: envelope + highlighted previous-season path.
        if (
            path_band is not None
            and isinstance(path_band, pd.DataFrame)
            and not path_band.empty
            and "min" in path_band.columns
            and "max" in path_band.columns
        ):
            pband = path_band.dropna(how="all")
            if not pband.empty:
                fig.add_trace(
                    go.Scatter(
                        x=pband.index.tolist(),
                        y=pband["max"].tolist(),
                        mode="lines",
                        line=dict(width=0),
                        name="Path range (max)",
                        showlegend=False,
                        hoverinfo="skip",
                    )
                )
                fig.add_trace(
                    go.Scatter(
                        x=pband.index.tolist(),
                        y=pband["min"].tolist(),
                        mode="lines",
                        line=dict(width=0),
                        fill="tonexty",
                        fillcolor=_PATH_BAND,
                        name="Path forecast range",
                        hovertemplate=(
                            "Path forecast range<br>%{x|%d-%b} · "
                            "%{y:.1f}–%{customdata[0]:.1f}%<extra></extra>"
                        ),
                        customdata=pband[["max"]].to_numpy(),
                    )
                )

        if prev_path is not None and not getattr(prev_path, "empty", True):
            y = (
                prev_path["fill_pct"]
                if "fill_pct" in prev_path.columns
                else prev_path.iloc[:, 0]
            )
            label = (
                f"Forecast ({prev_path_label})"
                if prev_path_label
                else "Forecast path"
            )
            fig.add_trace(
                go.Scatter(
                    x=prev_path.index.tolist(),
                    y=y.tolist(),
                    mode="lines",
                    name=label,
                    line=dict(color=_PATH_DASH, width=2.2, dash="dash"),
                    hovertemplate=(
                        f"{label}<br>%{{x|%d-%b}} · %{{y:.1f}}%<extra></extra>"
                    ),
                )
            )

    if target_pct is not None:
        fig.add_hline(
            y=float(target_pct),
            line_dash="dot",
            line_color=COLORS["accent"],
            annotation_text=f"Target {float(target_pct):.0f}%",
            annotation_position="top left",
            annotation_font=dict(size=11, color=COLORS["accent"]),
        )

    season_info = projected.get("season_info") or {}
    actuals_meta = projected.get("actuals") or {}
    chart_start = actuals_meta.get("chart_start") or season_info.get("chart_start")
    chart_end = actuals_meta.get("chart_end") or season_info.get("chart_end")
    if chart_start is None or chart_end is None:
        info = resolve_season()
        chart_start = info["chart_start"]
        chart_end = info["chart_end"]
    x_start = pd.Timestamp(chart_start).normalize()
    x_end = pd.Timestamp(chart_end).normalize()

    fig.update_layout(
        height=480,
        margin=dict(t=50, b=40, l=50, r=20),
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
            font=dict(size=11),
        ),
        xaxis=dict(
            title=None,
            range=[x_start, x_end],
            showgrid=True,
            gridcolor=COLORS["border_light"],
            tickformat="%b",
            dtick="M1",
        ),
        yaxis=dict(
            title="Fill %",
            range=[0, 105],
            showgrid=True,
            gridcolor=COLORS["border_light"],
        ),
        hovermode="x unified",
        font=dict(color=COLORS["text_primary"], size=12),
    )
    return fig


def _empty_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
        font={"size": 14, "color": "#888"},
    )
    fig.update_layout(
        height=400,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        margin=dict(t=30, b=30, l=30, r=30),
    )
    return fig
