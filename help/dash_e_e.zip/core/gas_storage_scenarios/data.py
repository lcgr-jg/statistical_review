"""Storage Scenarios — aggregate CE fill/injection and project paths."""
from __future__ import annotations

import datetime as dt
from typing import Any

import pandas as pd

from core.gas_storage_scenarios.constants import (
    COUNTRY_CODES,
    DEFAULT_MULTI_COUNTRIES,
    PATH_BASIS_PRIOR,
    PATH_BASIS_RECENT_MA,
    PATH_DEFAULT_PRIOR_YEARS,
    PATH_HISTORY_YEAR_MIN,
    PATH_MA_WINDOWS,
    SEASON_INJECTION,
    parse_path_basis,
    resolve_season,
)
from core.gas_storage_summary.data import (
    format_ce_refresh_age,
    get_cached_fill,
    get_cached_injection,
    get_ce_last_refresh,
)


def parse_countries(value: list[str] | str | None) -> list[str]:
    """Filter to known codes; fall back to page defaults."""
    if isinstance(value, str):
        value = [value]
    codes = [c for c in (value or []) if c in COUNTRY_CODES]
    if not codes:
        codes = list(DEFAULT_MULTI_COUNTRIES)
    return [c for c in COUNTRY_CODES if c in codes]


def _latest_fill_date(
    df_fill: pd.DataFrame,
    to_date: pd.Timestamp,
) -> pd.Timestamp | None:
    if df_fill is None or df_fill.empty:
        return None
    latest = df_fill.index.max()
    if pd.isna(latest):
        return None
    if latest > to_date:
        clipped = df_fill.loc[:to_date]
        if clipped.empty:
            return None
        latest = clipped.index.max()
    return pd.Timestamp(latest)


def aggregate_stock_capacity(
    df_fill: pd.DataFrame,
    countries: list[str],
    as_of: pd.Timestamp,
) -> tuple[float | None, float | None, pd.Timestamp | None]:
    """Sum stock and capacity across *countries* on the latest fill date ≤ *as_of*."""
    codes = parse_countries(countries)
    latest = _latest_fill_date(df_fill, as_of)
    if latest is None:
        return None, None, None

    stocks: list[float] = []
    caps: list[float] = []
    for code in codes:
        stock_col = f"{code}|stock"
        cap_col = f"{code}|stockCapacity"
        if stock_col not in df_fill.columns or cap_col not in df_fill.columns:
            continue
        try:
            stock = df_fill.loc[latest, stock_col]
            capacity = df_fill.loc[latest, cap_col]
        except KeyError:
            continue
        if pd.notna(stock):
            stocks.append(float(stock))
        if pd.notna(capacity):
            caps.append(float(capacity))

    if not stocks or not caps:
        return None, None, latest
    return float(sum(stocks)), float(sum(caps)), latest


def aggregate_injection_series(
    df_inj: pd.DataFrame,
    countries: list[str],
) -> pd.Series:
    """Daily netInjection summed across selected countries (mcm/d)."""
    codes = parse_countries(countries)
    cols = [c for c in codes if c in df_inj.columns]
    if not cols:
        return pd.Series(dtype=float)
    return df_inj[cols].fillna(0.0).sum(axis=1).sort_index()


def recent_ma_rates(
    df_inj: pd.DataFrame,
    countries: list[str],
    *,
    as_of: pd.Timestamp | None = None,
    windows: tuple[int, ...] = PATH_MA_WINDOWS,
) -> dict[int, float]:
    """Trailing netInjection moving averages (mcm/d) for each window ending at *as_of*."""
    flow = aggregate_injection_series(df_inj, countries)
    if flow.empty:
        return {}
    if as_of is not None:
        flow = flow.loc[: pd.Timestamp(as_of).normalize()]
    flow = flow.dropna()
    if flow.empty:
        return {}
    out: dict[int, float] = {}
    for window in windows:
        window = int(window)
        tail = flow.iloc[-window:] if len(flow) >= window else flow
        if tail.empty:
            continue
        out[window] = float(tail.mean())
    return out


def injection_needed(
    df_fill: pd.DataFrame,
    countries: list[str],
    target_pct: float,
    *,
    to_date: dt.date | dt.datetime | pd.Timestamp | None = None,
    target_date: dt.date | None = None,
    season_info: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Gap from current stock to *target_pct* by the seasonal target date.

    Injection season: needed = max(0, target − current).
    Withdrawal season: needed = max(0, current − target).
    """
    to_ts = pd.Timestamp(to_date or dt.datetime.now()).normalize()
    info = season_info or resolve_season(to_ts.date())
    target_ts = pd.Timestamp(target_date or info["target_date"]).normalize()
    is_injection = bool(info.get("is_injection", True))
    stock, capacity, as_of = aggregate_stock_capacity(df_fill, countries, to_ts)

    out: dict[str, Any] = {
        "as_of": as_of,
        "target_date": target_ts,
        "countries": parse_countries(countries),
        "target_pct": float(target_pct),
        "stock_mcm": None,
        "capacity_mcm": None,
        "current_fill_pct": None,
        "target_stock_mcm": None,
        "needed_mcm": None,
        "days_remaining": None,
        "avg_mcm_d": None,
        "past_target": False,
        "gap_label": info.get("gap_label", "Injection needed"),
        "flow_noun": info.get("flow_noun", "injection"),
        "is_injection": is_injection,
        "season": info.get("season"),
    }
    if stock is None or capacity is None or capacity <= 0:
        return out

    target_stock = capacity * (float(target_pct) / 100.0)
    if is_injection:
        needed = max(0.0, target_stock - stock)
    else:
        needed = max(0.0, stock - target_stock)
    days = int((target_ts - (as_of or to_ts)).days)
    past = days <= 0

    out.update(
        {
            "stock_mcm": stock,
            "capacity_mcm": capacity,
            "current_fill_pct": (stock / capacity) * 100.0,
            "target_stock_mcm": target_stock,
            "needed_mcm": needed,
            "days_remaining": max(0, days),
            "avg_mcm_d": (needed / days) if days > 0 else None,
            "past_target": past,
        }
    )
    return out


def _month_day_date(year: int, month: int, day: int) -> pd.Timestamp | None:
    try:
        return pd.Timestamp(year=year, month=month, day=day)
    except ValueError:
        return None


def _forward_calendar(
    as_of: pd.Timestamp,
    target_date: pd.Timestamp,
) -> list[pd.Timestamp]:
    start = (as_of + pd.Timedelta(days=1)).normalize()
    end = target_date.normalize()
    if start > end:
        return []
    return list(pd.date_range(start=start, end=end, freq="D"))


def _chart_calendar(season_info: dict[str, Any]) -> pd.DatetimeIndex:
    start = pd.Timestamp(season_info["chart_start"]).normalize()
    end = pd.Timestamp(season_info["chart_end"]).normalize()
    return pd.date_range(start=start, end=end, freq="D")


def aggregate_fill_pct_series(
    df_fill: pd.DataFrame,
    countries: list[str],
) -> pd.Series:
    """Daily fill % from summed stock / capacity across selected countries."""
    codes = parse_countries(countries)
    if df_fill is None or df_fill.empty:
        return pd.Series(dtype=float)

    stock_cols = [f"{c}|stock" for c in codes if f"{c}|stock" in df_fill.columns]
    cap_cols = [
        f"{c}|stockCapacity" for c in codes if f"{c}|stockCapacity" in df_fill.columns
    ]
    if not stock_cols or not cap_cols:
        return pd.Series(dtype=float)

    stock = df_fill[stock_cols].sum(axis=1, min_count=1)
    capacity = df_fill[cap_cols].sum(axis=1, min_count=1)
    pct = (stock / capacity) * 100.0
    pct = pct.where(capacity > 0)
    pct.index = pd.to_datetime(pct.index)
    return pct.sort_index().astype(float)


def _shift_years(dt: pd.Timestamp, years: int) -> pd.Timestamp | None:
    """Shift *dt* by *years*, returning None if the calendar day is invalid."""
    try:
        return dt + pd.DateOffset(years=int(years))
    except Exception:
        return None


def _map_series_by_year_shift(
    series: pd.Series,
    calendar: pd.DatetimeIndex,
    year_shift: int,
) -> pd.Series:
    """Map *series* onto *calendar* by shifting each calendar date by -year_shift."""
    out = pd.Series(index=calendar, dtype=float)
    if series is None or series.empty:
        return out
    for dt in calendar:
        src = _shift_years(dt, -int(year_shift))
        if src is None or src not in series.index:
            continue
        val = series.loc[src]
        if pd.notna(val):
            out.loc[dt] = float(val)
    return out


def actual_fill_context(
    df_fill: pd.DataFrame,
    countries: list[str],
    *,
    as_of: pd.Timestamp,
    season_info: dict[str, Any],
    history_year_min: int = PATH_HISTORY_YEAR_MIN,
) -> dict[str, Any]:
    """Actual fill series for the chart: current, previous, historic band."""
    calendar = _chart_calendar(season_info)
    empty_band = pd.DataFrame(columns=["min", "max"])
    empty = {
        "current_year": None,
        "previous_year": None,
        "current_year_label": None,
        "previous_year_label": None,
        "historic_band": empty_band,
        "chart_start": season_info["chart_start"],
        "chart_end": season_info["chart_end"],
    }
    if as_of is None:
        return empty

    pct = aggregate_fill_pct_series(df_fill, countries)
    if pct.empty:
        return empty

    as_of = pd.Timestamp(as_of).normalize()
    # Anchor year for "current season" labelling.
    if season_info["season"] == SEASON_INJECTION:
        cur_label = int(pd.Timestamp(season_info["target_date"]).year)
    else:
        cur_label = int(pd.Timestamp(season_info["season_start"]).year)
    prev_label = cur_label - 1

    cur_mapped = _map_series_by_year_shift(pct, calendar, year_shift=0)
    if as_of in calendar:
        cur_mapped = cur_mapped.loc[:as_of]
    else:
        # Map as_of onto chart calendar by month-day within chart years.
        matches = [
            dt
            for dt in calendar
            if dt.month == as_of.month and dt.day == as_of.day
        ]
        if matches:
            # Prefer the match closest to as_of.
            as_of_on_cal = min(matches, key=lambda d: abs((d - as_of).days))
            cur_mapped = cur_mapped.loc[:as_of_on_cal]
    cur_mapped = cur_mapped.dropna()

    prev_mapped = _map_series_by_year_shift(pct, calendar, year_shift=1).dropna()

    band_years_shifts = list(range(2, cur_label - history_year_min + 1))
    frames = []
    for shift in band_years_shifts:
        mapped = _map_series_by_year_shift(pct, calendar, year_shift=shift)
        if not mapped.dropna().empty:
            frames.append(mapped.rename(cur_label - shift))
    if frames:
        mat = pd.concat(frames, axis=1)
        historic_band = pd.DataFrame(
            {"min": mat.min(axis=1), "max": mat.max(axis=1)},
            index=calendar,
        )
    else:
        historic_band = empty_band

    return {
        "current_year": cur_mapped if not cur_mapped.empty else None,
        "previous_year": prev_mapped if not prev_mapped.empty else None,
        "current_year_label": cur_label,
        "previous_year_label": prev_label,
        "historic_band": historic_band,
        "chart_start": season_info["chart_start"],
        "chart_end": season_info["chart_end"],
    }


def _path_envelope(paths: dict[Any, pd.DataFrame]) -> pd.DataFrame:
    if not paths:
        return pd.DataFrame(columns=["min", "max"])
    frames = []
    for key, path in paths.items():
        if path is None or path.empty or "fill_pct" not in path.columns:
            continue
        frames.append(path["fill_pct"].rename(key))
    if not frames:
        return pd.DataFrame(columns=["min", "max"])
    mat = pd.concat(frames, axis=1)
    return pd.DataFrame({"min": mat.min(axis=1), "max": mat.max(axis=1)}).sort_index()


def _simulate_path(
    *,
    stock0: float,
    capacity: float,
    as_of: pd.Timestamp,
    forward_dates: list[pd.Timestamp],
    daily_flow: list[float],
) -> tuple[pd.DataFrame, float]:
    stock = float(stock0)
    rows = [
        {
            "date": as_of,
            "stock_mcm": stock,
            "fill_pct": (stock / capacity) * 100.0,
            "inj_mcm": 0.0,
        }
    ]
    cum = 0.0
    for fwd, flow in zip(forward_dates, daily_flow):
        stock = min(capacity, max(0.0, stock + flow))
        cum += flow
        rows.append(
            {
                "date": fwd,
                "stock_mcm": stock,
                "fill_pct": (stock / capacity) * 100.0,
                "inj_mcm": flow,
            }
        )
    return pd.DataFrame(rows).set_index("date"), cum


def project_prior_year_paths(
    df_fill: pd.DataFrame,
    df_inj: pd.DataFrame,
    countries: list[str],
    *,
    to_date: dt.date | dt.datetime | pd.Timestamp | None = None,
    season_info: dict[str, Any] | None = None,
    history_year_min: int = PATH_HISTORY_YEAR_MIN,
    max_prior_years: int = PATH_DEFAULT_PRIOR_YEARS,
) -> dict[str, Any]:
    """Replay prior seasons' netInjection from as-of through the seasonal target."""
    to_ts = pd.Timestamp(to_date or dt.datetime.now()).normalize()
    info = season_info or resolve_season(to_ts.date())
    target_ts = pd.Timestamp(info["target_date"]).normalize()
    codes = parse_countries(countries)

    stock0, capacity, as_of = aggregate_stock_capacity(df_fill, codes, to_ts)
    flow = aggregate_injection_series(df_inj, codes)
    actuals = actual_fill_context(
        df_fill,
        codes,
        as_of=as_of if as_of is not None else to_ts,
        season_info=info,
        history_year_min=history_year_min,
    )

    empty = {
        "as_of": as_of,
        "capacity_mcm": capacity,
        "start_stock_mcm": stock0,
        "countries": codes,
        "paths": {},
        "summary": pd.DataFrame(),
        "path_band": pd.DataFrame(columns=["min", "max"]),
        "prev_year_path": None,
        "prev_year_path_label": None,
        "actuals": actuals,
        "season_info": info,
        "path_basis": PATH_BASIS_PRIOR,
        "ma_window": None,
        "ma_rate_mcm_d": None,
    }
    if (
        stock0 is None
        or capacity is None
        or capacity <= 0
        or as_of is None
        or flow.empty
    ):
        return empty

    forward_dates = _forward_calendar(as_of, target_ts)
    if not forward_dates:
        return empty

    # Label years by season start year (injection: target year; withdrawal: Nov year).
    if info["season"] == SEASON_INJECTION:
        cur_season_year = int(target_ts.year)
    else:
        cur_season_year = int(pd.Timestamp(info["season_start"]).year)

    end_year = cur_season_year - 1
    start_year = max(history_year_min, end_year - max_prior_years + 1)
    candidate_years = list(range(end_year, start_year - 1, -1))

    paths: dict[int, pd.DataFrame] = {}
    summary_rows: list[dict[str, Any]] = []

    for year in candidate_years:
        year_shift = cur_season_year - year
        daily_flow: list[float] = []
        hist_dates: list[pd.Timestamp] = []
        for fwd in forward_dates:
            hist_dt = _shift_years(fwd, -year_shift)
            if hist_dt is not None:
                hist_dates.append(hist_dt)
            if hist_dt is not None and hist_dt in flow.index:
                val = flow.loc[hist_dt]
                daily_flow.append(float(val) if pd.notna(val) else 0.0)
            else:
                daily_flow.append(0.0)

        valid_hist = [d for d in hist_dates if d is not None]
        if not valid_hist:
            continue
        hist_range = pd.date_range(start=min(valid_hist), end=max(valid_hist), freq="D")
        available = flow.index.intersection(hist_range)
        if len(available) < max(1, int(0.8 * len(hist_range))):
            continue

        path_df, cum = _simulate_path(
            stock0=stock0,
            capacity=capacity,
            as_of=as_of,
            forward_dates=forward_dates,
            daily_flow=daily_flow,
        )
        paths[year] = path_df
        end_stock = float(path_df["stock_mcm"].iloc[-1])
        summary_rows.append(
            {
                "year": year,
                "label": str(year),
                "end_stock_bcm": end_stock / 1000.0,
                "end_fill_pct": (end_stock / capacity) * 100.0,
                "cum_inj_bcm": cum / 1000.0,
            }
        )

    summary = pd.DataFrame(summary_rows)
    if not summary.empty:
        summary = summary.sort_values("year", ascending=False).reset_index(drop=True)

    path_band = _path_envelope(paths)
    prev_year = end_year
    prev_year_path = paths.get(prev_year)

    return {
        "as_of": as_of,
        "capacity_mcm": capacity,
        "start_stock_mcm": stock0,
        "countries": codes,
        "paths": paths,
        "summary": summary,
        "path_band": path_band,
        "prev_year_path": prev_year_path,
        "prev_year_path_label": prev_year if prev_year_path is not None else None,
        "actuals": actuals,
        "season_info": info,
        "path_basis": PATH_BASIS_PRIOR,
        "ma_window": None,
        "ma_rate_mcm_d": None,
    }


def project_ma_paths(
    df_fill: pd.DataFrame,
    df_inj: pd.DataFrame,
    countries: list[str],
    *,
    windows: tuple[int, ...] = PATH_MA_WINDOWS,
    to_date: dt.date | dt.datetime | pd.Timestamp | None = None,
    season_info: dict[str, Any] | None = None,
    history_year_min: int = PATH_HISTORY_YEAR_MIN,
) -> dict[str, Any]:
    """Project fill for each recent MA window (7/14/21/28d) on one chart/table."""
    to_ts = pd.Timestamp(to_date or dt.datetime.now()).normalize()
    info = season_info or resolve_season(to_ts.date())
    target_ts = pd.Timestamp(info["target_date"]).normalize()
    codes = parse_countries(countries)

    stock0, capacity, as_of = aggregate_stock_capacity(df_fill, codes, to_ts)
    flow = aggregate_injection_series(df_inj, codes)
    actuals = actual_fill_context(
        df_fill,
        codes,
        as_of=as_of if as_of is not None else to_ts,
        season_info=info,
        history_year_min=history_year_min,
    )

    empty = {
        "as_of": as_of,
        "capacity_mcm": capacity,
        "start_stock_mcm": stock0,
        "countries": codes,
        "paths": {},
        "summary": pd.DataFrame(),
        "path_band": pd.DataFrame(columns=["min", "max"]),
        "prev_year_path": None,
        "prev_year_path_label": None,
        "actuals": actuals,
        "season_info": info,
        "path_basis": PATH_BASIS_RECENT_MA,
        "ma_window": None,
        "ma_rates_mcm_d": {},
    }
    if (
        stock0 is None
        or capacity is None
        or capacity <= 0
        or as_of is None
        or flow.empty
    ):
        return empty

    forward_dates = _forward_calendar(as_of, target_ts)
    if not forward_dates:
        return empty

    hist = flow.loc[:as_of].dropna()
    if hist.empty:
        return empty

    paths: dict[str, pd.DataFrame] = {}
    summary_rows: list[dict[str, Any]] = []
    rates: dict[str, float] = {}

    for window in windows:
        window = int(window)
        tail = hist.iloc[-window:] if len(hist) >= window else hist
        rate = float(tail.mean()) if not tail.empty else 0.0
        label = f"{window}d MA"
        rates[label] = rate
        path_df, cum = _simulate_path(
            stock0=stock0,
            capacity=capacity,
            as_of=as_of,
            forward_dates=forward_dates,
            daily_flow=[rate] * len(forward_dates),
        )
        paths[label] = path_df
        end_stock = float(path_df["stock_mcm"].iloc[-1])
        summary_rows.append(
            {
                "year": window,
                "label": label,
                "end_stock_bcm": end_stock / 1000.0,
                "end_fill_pct": (end_stock / capacity) * 100.0,
                "cum_inj_bcm": cum / 1000.0,
                "ma_rate_mcm_d": rate,
            }
        )

    summary = pd.DataFrame(summary_rows)
    if not summary.empty:
        summary = summary.sort_values("year", ascending=True).reset_index(drop=True)

    return {
        "as_of": as_of,
        "capacity_mcm": capacity,
        "start_stock_mcm": stock0,
        "countries": codes,
        "paths": paths,
        "summary": summary,
        "path_band": _path_envelope(paths),
        "prev_year_path": None,
        "prev_year_path_label": None,
        "actuals": actuals,
        "season_info": info,
        "path_basis": PATH_BASIS_RECENT_MA,
        "ma_window": None,
        "ma_rates_mcm_d": rates,
    }


def project_scenarios(
    df_fill: pd.DataFrame,
    df_inj: pd.DataFrame,
    countries: list[str],
    *,
    path_basis: str | None = PATH_BASIS_PRIOR,
    to_date: dt.date | dt.datetime | pd.Timestamp | None = None,
    season_info: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Dispatch prior-year vs recent-MA path projections."""
    to_ts = pd.Timestamp(to_date or dt.datetime.now()).normalize()
    info = season_info or resolve_season(to_ts.date())
    basis = parse_path_basis(path_basis)
    if basis == PATH_BASIS_RECENT_MA:
        return project_ma_paths(
            df_fill,
            df_inj,
            countries,
            to_date=to_ts,
            season_info=info,
        )
    return project_prior_year_paths(
        df_fill,
        df_inj,
        countries,
        to_date=to_ts,
        season_info=info,
    )


# Back-compat name used by older callbacks.
def project_fill_paths(*args, **kwargs):
    """Alias for prior-year / scenario projection."""
    if "path_basis" in kwargs:
        return project_scenarios(*args, **kwargs)
    target_date = kwargs.pop("target_date", None)
    if target_date is not None and "season_info" not in kwargs:
        to_date = kwargs.get("to_date") or dt.datetime.now()
        info = dict(resolve_season(pd.Timestamp(to_date).date()))
        info["target_date"] = pd.Timestamp(target_date).date()
        kwargs["season_info"] = info
    return project_prior_year_paths(*args, **kwargs)
