"""Fundamentals-vs-heat-rate regression data for the Clean Spreads page.

Historical x-axis values come from the jain_commods climate weather-year
panels (hourly MW per zone, one column per weather year ``y1980``..``yNNNN``,
calendar spanning ~2020-2029). The "diagonal" (calendar date d taken from
column ``y{d.year}``) gives a capacity-consistent realised history; the full
panel over a future month gives the weather-year distribution used to
project forward heat rates through the fitted regression.

The y-axis (daily gas heat rate) reuses ``daily_spot_metrics`` from
``core.clean_spreads.data``.
"""
from __future__ import annotations

import logging
import threading

import numpy as np
import pandas as pd

from core.clean_spreads import data as cs_data

logger = logging.getLogger(__name__)

# variable key -> (display label, jain_commods climate class name)
FUND_VARS: dict[str, tuple[str, str]] = {
    "RESIDUAL_LOAD": ("Residual Load", "ResLoadClimate"),
    "WIND": ("Wind", "GenWindClimate"),
    "SOLAR": ("Solar", "GenSolarClimate"),
    "DEMAND": ("Demand", "ConsClimate"),
}

# variable key -> jain_commods actuals class (realised outturn, used to
# extend history past the last weather-year column, e.g. 2025-2026)
FUND_ACTUAL_CLASSES: dict[str, str] = {
    "RESIDUAL_LOAD": "ResLoadActual",
    "WIND": "GenWindActual",
    "SOLAR": "GenSolarActual",
    "DEMAND": "ConsActual",
}

# How far back to fetch actuals; only dates after the last weather-year
# column are actually used, so a few years is plenty.
ACTUAL_LOOKBACK_DAYS = 3 * 366

MIN_POINTS_PER_FIT = 10

_CLIMATE_CACHE: dict[tuple[str, str], pd.DataFrame] = {}
_ACTUAL_CACHE: dict[tuple[str, str], pd.Series] = {}
_CACHE_LOCK = threading.Lock()


def _zone(country: str) -> str:
    """Portal country code -> climate cache zone (lowercase, GB stays gb)."""
    return country.strip().lower()


def _climate_class(var: str):
    """Lazily resolve the jain_commods climate class for a variable key."""
    from jain_commods.core.cache.data import fundamentals as jc_fund

    _label, cls_name = FUND_VARS[var.upper()]
    return getattr(jc_fund, cls_name), jc_fund.DataSource


def load_climate_daily(var: str, country: str) -> pd.DataFrame:
    """Daily-mean climate panel in GW for one variable/country.

    Columns ``y1980``..``yNNNN`` (weather years), tz-naive daily index.
    Cached in-process; the first call per (var, country) hits S3.
    Returns an empty frame on failure.
    """
    key = (var.upper(), country.upper())
    with _CACHE_LOCK:
        if key in _CLIMATE_CACHE:
            return _CLIMATE_CACHE[key]

    try:
        cls, data_source = _climate_class(var)
        obj = cls(zone=_zone(country), data_source=data_source.EQ)
        obj.load(from_s3=True, show_metadata=False, normalized=False)
        raw = obj.data
    except Exception:
        logger.warning("Climate panel load failed for %s/%s", var, country,
                       exc_info=True)
        raw = None

    if raw is None or raw.empty:
        daily = pd.DataFrame()
    else:
        daily = raw.resample("D").mean() / 1000.0  # MW -> GW
        if daily.index.tz is not None:
            daily.index = daily.index.tz_localize(None)
        daily = daily[[c for c in daily.columns
                       if str(c).startswith("y")]]

    with _CACHE_LOCK:
        _CLIMATE_CACHE[key] = daily
    return daily


def load_actual_daily(var: str, country: str) -> pd.Series:
    """Daily-mean realised fundamental (GW) for one variable/country.

    Loaded from the jain_commods ``*Actual`` caches (wide frame, lowercase
    zone columns, hourly MW). Cached in-process; empty Series on failure.
    """
    key = (var.upper(), country.upper())
    with _CACHE_LOCK:
        if key in _ACTUAL_CACHE:
            return _ACTUAL_CACHE[key]

    series = pd.Series(dtype=float)
    try:
        from jain_commods.core.cache.data import fundamentals as jc_fund

        cls = getattr(jc_fund, FUND_ACTUAL_CLASSES[var.upper()])
        zone = _zone(country)
        end = pd.Timestamp.today().normalize() + pd.Timedelta(days=1)
        start = end - pd.Timedelta(days=ACTUAL_LOOKBACK_DAYS)
        obj = cls()
        obj.load(from_s3=True, show_metadata=False, zones=[zone],
                 start_date=start, end_date=end)
        raw = obj.data
        if raw is not None and not raw.empty and zone in raw.columns:
            daily = raw[zone].resample("D").mean() / 1000.0  # MW -> GW
            if daily.index.tz is not None:
                daily.index = daily.index.tz_localize(None)
            series = daily.dropna()
    except Exception:
        logger.warning("Actuals load failed for %s/%s", var, country,
                       exc_info=True)

    with _CACHE_LOCK:
        _ACTUAL_CACHE[key] = series
    return series


def climate_diagonal(panel: pd.DataFrame) -> pd.Series:
    """Realised history from the panel: date d <- column ``y{d.year}``.

    Only calendar years with a matching weather-year column are covered
    (i.e. full years up to the last available weather year).
    """
    if panel is None or panel.empty:
        return pd.Series(dtype=float)
    pieces = []
    for col in panel.columns:
        try:
            year = int(str(col)[1:])
        except ValueError:
            continue
        mask = panel.index.year == year
        if mask.any():
            pieces.append(panel.loc[mask, col])
    if not pieces:
        return pd.Series(dtype=float)
    return pd.concat(pieces).sort_index()


def historical_series(var: str, country: str,
                      panel: pd.DataFrame) -> pd.Series:
    """Realised daily fundamental history (GW).

    Weather-year diagonal for years covered by the climate panel columns,
    extended with realised actuals for later dates (e.g. 2025-2026, which
    have no ``yYYYY`` column yet).
    """
    diag = climate_diagonal(panel)
    actual = load_actual_daily(var, country)
    if actual.empty:
        return diag
    if not diag.empty:
        actual = actual[actual.index > diag.index.max()]
    return pd.concat([diag, actual]).sort_index()


def regression_dataset(bundle: dict, country: str, var: str) -> pd.DataFrame:
    """Daily FUND (GW) + GAS_HR joined on date, with year/month columns."""
    panel = load_climate_daily(var, country)
    if panel.empty:
        return pd.DataFrame()
    fund = historical_series(var, country, panel).rename("FUND")
    if fund.empty:
        return pd.DataFrame()

    daily = cs_data.daily_spot_metrics(bundle, country, days=None)
    if daily.empty or "GAS_HR" not in daily.columns:
        return pd.DataFrame()
    hr = daily["GAS_HR"].dropna().rename("GAS_HR")

    df = pd.concat([fund, hr], axis=1).dropna()
    if df.empty:
        return df
    df["year"] = df.index.year
    df["month"] = df.index.month
    return df


def available_years(dataset: pd.DataFrame) -> list[int]:
    if dataset is None or dataset.empty:
        return []
    return sorted(int(y) for y in dataset["year"].unique())


# Winsorization only kicks in with a reasonable sample; drops spike days
# outside the 1st-99th HR percentiles.
_WINSOR_MIN_SAMPLE = 50
_ANCHOR_DAYS = 365          # intercept anchor window for year fixed effects
_DIST_DRAWS_PER_WY = 400    # deterministic MC draws per weather year


def fit_month(dataset: pd.DataFrame, month: int,
              years: list[int] | None,
              pool_adjacent: bool = True,
              year_fe: bool = True) -> dict | None:
    """Regression GAS_HR ~ FUND for one calendar month.

    - ``pool_adjacent``: also fit on the neighbouring months (m-1, m+1) for
      a steadier seasonal slope (the scatter shown stays month-only).
    - ``year_fe``: year fixed effects - the slope is estimated on
      within-year anomalies (so regime-level shifts like 2021-22 don't
      contaminate it) and the intercept is re-anchored to the most recent
      365 days of data.
    - Spike days outside the 1st-99th HR percentile are dropped.

    Returns slope/intercept/r2/n plus ``sigma_m`` - the std-dev of
    monthly-mean residuals, used to widen the forward distribution.
    """
    if dataset is None or dataset.empty:
        return None
    months = {month}
    if pool_adjacent:
        months |= {(month - 2) % 12 + 1, month % 12 + 1}
    sub = dataset[dataset["month"].isin(months)]
    if years:
        sub = sub[sub["year"].isin(years)]
    sub = sub.dropna(subset=["FUND", "GAS_HR"])
    if len(sub) >= _WINSOR_MIN_SAMPLE:
        lo, hi = sub["GAS_HR"].quantile([0.01, 0.99])
        sub = sub[(sub["GAS_HR"] >= lo) & (sub["GAS_HR"] <= hi)]
    if len(sub) < MIN_POINTS_PER_FIT or sub["FUND"].nunique() < 2:
        return None

    x = sub["FUND"].to_numpy(dtype=float)
    y = sub["GAS_HR"].to_numpy(dtype=float)

    if year_fe:
        x_anom = x - sub.groupby("year")["FUND"].transform("mean").to_numpy()
        y_anom = y - sub.groupby("year")["GAS_HR"].transform("mean").to_numpy()
        sxx = float((x_anom ** 2).sum())
        if sxx <= 0:
            return None
        slope = float((x_anom * y_anom).sum() / sxx)
        resid = y_anom - slope * x_anom
        ss_tot = float((y_anom ** 2).sum())
        # Anchor the level to the current regime (last 365 days, all months)
        cutoff = dataset.index.max() - pd.Timedelta(days=_ANCHOR_DAYS)
        recent = dataset.loc[dataset.index > cutoff].dropna(
            subset=["FUND", "GAS_HR"])
        if recent.empty:
            recent = sub
        intercept = float(recent["GAS_HR"].mean()
                          - slope * recent["FUND"].mean())
    else:
        slope, intercept = np.polyfit(x, y, 1)
        slope, intercept = float(slope), float(intercept)
        resid = y - (slope * x + intercept)
        ss_tot = float(((y - y.mean()) ** 2).sum())

    r2 = 1.0 - float((resid ** 2).sum()) / ss_tot if ss_tot > 0 else np.nan

    # Residual uncertainty at the monthly-mean level
    monthly_resid = (pd.Series(resid, index=sub.index)
                     .groupby([sub["year"], sub["month"]]).mean())
    if len(monthly_resid) >= 3:
        sigma_m = float(monthly_resid.std(ddof=1))
    else:
        sigma_m = float(np.std(resid) / np.sqrt(28.0))
    if not np.isfinite(sigma_m):
        sigma_m = 0.0

    return {"slope": slope, "intercept": intercept, "r2": r2,
            "n": int(len(sub)), "sigma_m": sigma_m}


def projection_distribution(fit: dict | None, wy: pd.Series | None,
                            seed: int = 42) -> dict | None:
    """Forward heat-rate distribution: weather-year spread in x mapped
    through the regression, convolved with the fit's monthly residual
    sigma (deterministic seeded draws).

    Returns {'preds': Series by weather year, 'median', 'p10', 'p25',
    'p75', 'p90', 'sigma_m'}.
    """
    if fit is None or wy is None or wy.empty:
        return None
    preds = fit["slope"] * wy.to_numpy(dtype=float) + fit["intercept"]
    sigma = float(fit.get("sigma_m", 0.0) or 0.0)
    if sigma > 0:
        rng = np.random.default_rng(seed)
        draws = (np.repeat(preds, _DIST_DRAWS_PER_WY)
                 + sigma * rng.standard_normal(preds.size
                                               * _DIST_DRAWS_PER_WY))
    else:
        draws = preds
    p10, p25, p50, p75, p90 = np.percentile(draws, [10, 25, 50, 75, 90])
    return {
        "preds": pd.Series(preds, index=wy.index),
        "median": float(p50), "p10": float(p10), "p25": float(p25),
        "p75": float(p75), "p90": float(p90), "sigma_m": sigma,
    }


def forward_target_year(month: int,
                        today: pd.Timestamp | None = None) -> int:
    """Year of the next future delivery of a calendar month."""
    today = pd.Timestamp.today() if today is None else pd.Timestamp(today)
    return today.year + (1 if month <= today.month else 0)


def wy_monthly_means(panel: pd.DataFrame, month: int,
                     year: int) -> pd.Series:
    """Weather-year monthly means of the fundamental for one target month.

    Returns a Series indexed by weather year (int), values in GW.
    """
    if panel is None or panel.empty:
        return pd.Series(dtype=float)
    mask = (panel.index.year == year) & (panel.index.month == month)
    if not mask.any():
        return pd.Series(dtype=float)
    means = panel.loc[mask].mean()
    means.index = [int(str(c)[1:]) for c in means.index]
    return means.dropna().sort_index()


def market_forward_hr(bundle: dict, country: str) -> dict:
    """Market forward gas heat rate per future month.

    Returns {(year, month): {'value': float, 'strip': str}}.
    """
    curve = cs_data.heat_rate_curve(bundle, country)
    if curve.empty or "GAS_HR" not in curve.columns:
        return {}
    proj = cs_data.expand_curve_monthly(curve.dropna(subset=["GAS_HR"]),
                                        "GAS_HR")
    out = {}
    for _, row in proj.iterrows():
        month = pd.Timestamp(row["month"])
        out[(month.year, month.month)] = {
            "value": float(row["value"]),
            "strip": str(row["STRIP"]),
        }
    return out


def build_regression_view(bundle: dict, country: str, var: str,
                          years: list[int] | None,
                          pool_adjacent: bool = True,
                          year_fe: bool = True) -> dict:
    """Everything the grid chart and summary table need, in one pass.

    Returns dict with:
      dataset      - daily regression frame (selected years only)
      all_years    - available history years (for the year checklist)
      fits         - {month: fit dict | None}
      wy_means     - {month: Series (weather year -> GW)}
      dist         - {month: projection distribution dict | None}
      targets      - {month: target year}
      market       - {month: {'value', 'strip'} | None}
      var_label    - display label
    """
    panel = load_climate_daily(var, country)
    dataset = regression_dataset(bundle, country, var)
    all_years = available_years(dataset)
    selected = [y for y in (years or all_years) if y in all_years] \
        or all_years

    fits, wy_means, targets, market, dist = {}, {}, {}, {}, {}
    market_all = market_forward_hr(bundle, country)
    for month in range(1, 13):
        fits[month] = fit_month(dataset, month, selected,
                                pool_adjacent=pool_adjacent,
                                year_fe=year_fe)
        target = forward_target_year(month)
        targets[month] = target
        wy_means[month] = wy_monthly_means(panel, month, target)
        market[month] = market_all.get((target, month))
        dist[month] = projection_distribution(fits[month], wy_means[month])

    view_data = dataset[dataset["year"].isin(selected)] \
        if not dataset.empty else dataset
    return {
        "dataset": view_data,
        "all_years": all_years,
        "selected_years": selected,
        "fits": fits,
        "wy_means": wy_means,
        "dist": dist,
        "targets": targets,
        "market": market,
        "var_label": FUND_VARS[var.upper()][0],
    }
