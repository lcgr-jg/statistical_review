"""Change-table builders for the Clean Spreads page.

The snapshot table mirrors the price_report 'Clean Spark' tables: one row
per delivery strip with the outright level plus DoD / WoW / MoM changes,
heat-shaded red/green by sign and magnitude.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from core.styles import COLORS

CHANGE_COLS = ["DoD", "WoW", "MoM"]

def _columns(mode: str) -> list[dict]:
    if mode == "heat_rate":
        value_fmt, change_fmt, unit = ".3f", "+.3f", "(x)"
    else:
        value_fmt, change_fmt, unit = ".2f", "+.2f", "(€/MWh)"
    return [
        {"name": "Strip", "id": "STRIP"},
        {"name": "Type", "id": "CONTRACT_TYPE"},
        {"name": f"Outright {unit}", "id": "Outright", "type": "numeric",
         "format": {"specifier": value_fmt}},
        {"name": "DoD", "id": "DoD", "type": "numeric",
         "format": {"specifier": change_fmt}},
        {"name": "WoW", "id": "WoW", "type": "numeric",
         "format": {"specifier": change_fmt}},
        {"name": "MoM", "id": "MoM", "type": "numeric",
         "format": {"specifier": change_fmt}},
    ]


TABLE_COLUMNS = _columns("spread")

_TYPE_LABEL = {"MONTHLY": "M", "QUARTERLY": "Q", "YEARLY": "CAL"}

# Shading buckets (absolute change -> background alpha)
_BUCKETS = {
    # EUR/MWh spread changes
    "spread": [(0.25, 0.10), (1.0, 0.22), (2.5, 0.38), (np.inf, 0.55)],
    # heat-rate (ratio) changes are an order of magnitude smaller
    "heat_rate": [(0.01, 0.10), (0.03, 0.22), (0.08, 0.38), (np.inf, 0.55)],
}
_GREEN = "46, 160, 67"
_RED = "218, 54, 51"


def _shade(value: float, mode: str = "spread") -> str:
    buckets = _BUCKETS.get(mode, _BUCKETS["spread"])
    alpha = buckets[-1][1]
    for threshold, bucket_alpha in buckets:
        if abs(value) <= threshold:
            alpha = bucket_alpha
            break
    rgb = _GREEN if value > 0 else _RED
    return f"rgba({rgb}, {alpha})"


def _band_styles(columns: list[str], mode: str = "spread") -> list[dict]:
    """Heat shading as value-band rules rather than one rule per cell.

    A row-index rule per shaded cell makes the payload grow with the table
    (a 64-row screener shipped 100 rules / 12 KB) and is the slow path in
    DataTable rendering. These filter_query bands are a fixed handful and
    reproduce exactly the same colours as :func:`_shade`.
    """
    buckets = _BUCKETS.get(mode, _BUCKETS["spread"])
    styles: list[dict] = []
    for column in columns:
        field = f"{{{column}}}"
        lower = 0.0
        for threshold, alpha in buckets:
            finite = np.isfinite(threshold)
            for rgb, sign in ((_GREEN, "+"), (_RED, "-")):
                if sign == "+":
                    query = f"{field} > {lower}"
                    if finite:
                        query += f" && {field} <= {threshold}"
                else:
                    query = f"{field} < {-lower}"
                    if finite:
                        query += f" && {field} >= {-threshold}"
                styles.append({
                    "if": {"column_id": column, "filter_query": query},
                    "backgroundColor": f"rgba({rgb}, {alpha})",
                    "color": COLORS["text_primary"],
                    "fontWeight": "600",
                })
            if finite:
                lower = threshold
    return styles


def _screener_columns(mode: str) -> list[dict]:
    if mode == "heat_rate":
        value_fmt, change_fmt, unit = ".3f", "+.3f", "(x)"
    else:
        value_fmt, change_fmt, unit = ".2f", "+.2f", "(€/MWh)"
    return [
        {"name": "Country", "id": "Country"},
        {"name": "Strip", "id": "STRIP"},
        {"name": "Type", "id": "Type"},
        # Issue (trade) date of that row's price, so a lagging country is
        # visible without leaving the screener.
        {"name": "Issued", "id": "Issued"},
        {"name": f"Outright {unit}", "id": "Outright", "type": "numeric",
         "format": {"specifier": value_fmt}},
        {"name": "DoD", "id": "DoD", "type": "numeric",
         "format": {"specifier": change_fmt}},
        {"name": "z(DoD)", "id": "zDoD", "type": "numeric",
         "format": {"specifier": "+.1f"}},
        {"name": "WoW", "id": "WoW", "type": "numeric",
         "format": {"specifier": change_fmt}},
        {"name": "MoM", "id": "MoM", "type": "numeric",
         "format": {"specifier": change_fmt}},
        {"name": "Pctile", "id": "Pctile", "type": "numeric",
         "format": {"specifier": ".0f"}},
        {"name": "Obs", "id": "Obs", "type": "numeric"},
    ]


SCREENER_COLUMNS = _screener_columns("spread")

# z-score shading buckets (|z| -> alpha)
_Z_BUCKETS = [(0.5, 0.0), (1.0, 0.12), (2.0, 0.28), (np.inf, 0.5)]


def _z_shade(z: float) -> str | None:
    alpha = _Z_BUCKETS[-1][1]
    for threshold, bucket_alpha in _Z_BUCKETS:
        if abs(z) <= threshold:
            alpha = bucket_alpha
            break
    if alpha == 0:
        return None
    rgb = _GREEN if z > 0 else _RED
    return f"rgba({rgb}, {alpha})"


def _z_band_styles() -> list[dict]:
    """z(DoD) shading as bands (see :func:`_band_styles`)."""
    styles: list[dict] = []
    lower = 0.0
    for threshold, alpha in _Z_BUCKETS:
        finite = np.isfinite(threshold)
        if alpha > 0:
            for rgb, sign in ((_GREEN, "+"), (_RED, "-")):
                if sign == "+":
                    query = f"{{zDoD}} > {lower}"
                    if finite:
                        query += f" && {{zDoD}} <= {threshold}"
                else:
                    query = f"{{zDoD}} < {-lower}"
                    if finite:
                        query += f" && {{zDoD}} >= {-threshold}"
                styles.append({
                    "if": {"column_id": "zDoD", "filter_query": query},
                    "backgroundColor": f"rgba({rgb}, {alpha})",
                    "color": COLORS["text_primary"],
                    "fontWeight": "600",
                })
        if finite:
            lower = threshold
    # Level extremes: rich at the top of its own history, cheap at the bottom
    styles += [
        {"if": {"column_id": "Pctile", "filter_query": "{Pctile} >= 90"},
         "backgroundColor": f"rgba({_RED}, 0.30)", "fontWeight": "600"},
        {"if": {"column_id": "Pctile", "filter_query": "{Pctile} <= 10"},
         "backgroundColor": f"rgba({_GREEN}, 0.30)", "fontWeight": "600"},
    ]
    return styles


def make_screener_table(screener_df: pd.DataFrame,
                        mode: str = "spread") -> dict:
    """DataTable kwargs for the rich/cheap screener.

    Shades z(DoD) by magnitude and Pctile at the extremes (>=90 red-hot
    rich, <=10 green cheap in level terms). ``mode``: 'spread' or
    'heat_rate' (heat rates are ratios, shown to 3 decimals).
    """
    columns = _screener_columns(mode)
    if screener_df is None or screener_df.empty:
        return {"data": [], "columns": columns,
                "style_data_conditional": []}
    decimals = 4 if mode == "heat_rate" else 2
    cols = [c["id"] for c in columns]
    table = screener_df.reindex(columns=cols).round(decimals)
    if "Issued" in table.columns:
        # ISO dates so the column sorts chronologically in the DataTable
        table["Issued"] = pd.to_datetime(
            table["Issued"], errors="coerce").dt.strftime("%Y-%m-%d")
    records = table.to_dict("records")

    styles: list[dict] = [
        {"if": {"row_index": "odd"},
         "backgroundColor": "rgba(0, 0, 0, 0.02)"},
    ] + _z_band_styles()
    return {"data": records, "columns": columns,
            "style_data_conditional": styles}


def make_snapshot_table(snapshot: pd.DataFrame, mode: str = "spread") -> dict:
    """Build DataTable kwargs (data, columns, style_data_conditional).

    ``snapshot`` comes from ``data.curve_snapshot`` or
    ``data.heat_rate_snapshot``; ``mode`` is 'spread' or 'heat_rate'.
    """
    columns = _columns(mode)
    if snapshot is None or snapshot.empty:
        return {"data": [], "columns": columns,
                "style_data_conditional": []}

    df = snapshot.copy()
    df["CONTRACT_TYPE"] = df["CONTRACT_TYPE"].astype(str).str.upper().map(
        _TYPE_LABEL
    ).fillna(df["CONTRACT_TYPE"])

    decimals = 4 if mode == "heat_rate" else 2
    records = df[["STRIP", "CONTRACT_TYPE", "Outright"] + CHANGE_COLS].round(
        decimals
    ).to_dict("records")

    styles: list[dict] = [
        {"if": {"row_index": "odd"},
         "backgroundColor": "rgba(0, 0, 0, 0.02)"},
    ] + _band_styles(CHANGE_COLS, mode)
    return {"data": records, "columns": columns,
            "style_data_conditional": styles}
