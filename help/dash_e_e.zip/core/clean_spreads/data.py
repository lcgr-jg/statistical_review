"""Data helpers for the Clean Spreads page.

All functions operate on the warm ``price_data`` bundle (see
``price_dashboard.utils.data_loader.load_data``); no new scheduler source.

Key frames used:
    CSS_raw / CDS_raw   multi-index (DATE, COUNTRY, DELIVERY_PERIOD,
                        DAYS_TO_DELIVERY); columns include
                        {CSS|CDS}_{LOW|MID|HI}_EFF, CONTRACT_TYPE
                        ('SPOT'|'MONTHLY'|'QUARTERLY'|'YEARLY'),
                        DELIVERY_START, Period ('JAN'..'DEC','Q1'..'Q4','CAL'),
                        Year.
    delivered_spreads   flat frame: Country, Period ('JAN-25','Q1-25',
                        'CAL-25','WKnn-25'), YEAR, CSS_MID_EFF (EUR/MWh;
                        GB legs already NBP + (UKA+18)/EURGBP).
"""
from __future__ import annotations

import hashlib
import logging
import re
import threading
from collections import OrderedDict
from pathlib import Path

import numpy as np
import pandas as pd

from core.cache import dashboard_cache
from core.clean_spreads.constants import (
    API2_TO_MWH,
    COAL_EF,
    COAL_EFFS,
    EFF_BAND,
    EFF_DEFAULTS,
    EFF_MAX,
    EFF_MIN,
    GAS_EF,
    GAS_EFFS,
    ISSUE_FRESH_DAYS,
    ISSUE_STALE_DAYS,
    LEG_RATIO_MAX,
    LEG_RATIO_MIN,
    LIGNITE_EF,
    LIGNITE_FUEL_COST,
    LOOKBACKS,
    METRIC_LAG_TOLERANCE,
    METRICS,
    MONTH_NUM,
    SEASON_HOURS,
    SPREAD_METRICS,
    THERM_TO_MWH,
    UK_CARBON_RATIO,
    UK_CPS_GBP,
    UK_GAS_EFF,
    UKA_LOT_TONNES,
    USD_TO_EUR_FALLBACK,
)

logger = logging.getLogger(__name__)

_MONTHLY_PERIOD_RE = re.compile(
    r"^(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)-(\d{2})$"
)

_CONTRACT_MONTHS = {"MONTHLY": 1, "QUARTERLY": 3, "YEARLY": 12}


# ── Bundle access ──────────────────────────────────────────────────────────
def get_bundle(effs: dict | None = None) -> dict:
    """Warm price_data bundle re-efficiencied to the user's inputs.

    ``effs`` is the page efficiency store (percentages, see normalize_effs);
    None keeps every precomputed convention untouched. May be empty on a
    cold start.
    """
    try:
        from core import data as data_service

        bundle = data_service.get_prices() or {}
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("clean_spreads: price bundle unavailable: %s", exc)
        return {}
    if not bundle:
        return {}
    return apply_effs(bundle, effs)


# ── User-selected efficiencies ────────────────────────────────────────────
# The chosen efficiencies travel with the bundle view under EFF_KEY, so any
# function that already takes ``bundle`` can price at them without a new
# argument (see bundle_effs / spread_eff).
EFF_KEY = "_clean_spread_effs"

_EFF_CACHE: OrderedDict[tuple, pd.DataFrame] = OrderedDict()
_EFF_SOURCES: dict[str, pd.DataFrame] = {}
_EFF_CACHE_MAX = 6
_EFF_LOCK = threading.Lock()


def normalize_effs(store: dict | None) -> dict:
    """Coerce the efficiency store into fractions plus 'is default' flags.

    Accepts percentages as typed in the UI ({'gas': 55}) or fractions
    ({'gas': 0.55}); missing or unparseable values fall back to the page
    defaults and anything outside [EFF_MIN, EFF_MAX] is clamped.
    Returns e.g. {'gas': 0.55, 'gas_default': False, 'coal': 0.40, ...}.
    """
    out: dict = {}
    for fuel, default in EFF_DEFAULTS.items():
        raw = (store or {}).get(fuel)
        eff = default
        if raw is not None and raw != "":
            try:
                eff = float(raw)
            except (TypeError, ValueError):
                eff = default
        if not np.isfinite(eff):
            eff = default
        if eff > 1.0:  # typed as a percentage
            eff = eff / 100.0
        eff = min(max(eff, EFF_MIN), EFF_MAX)
        out[fuel] = eff
        out[f"{fuel}_default"] = abs(eff - default) < 1e-9
    return out


def bundle_effs(bundle: dict | None) -> dict:
    """Efficiencies attached to a bundle view (page defaults if absent)."""
    effs = (bundle or {}).get(EFF_KEY)
    if isinstance(effs, dict) and "gas_default" in effs:
        return effs
    return normalize_effs(effs if isinstance(effs, dict) else None)


def spread_eff(bundle: dict | None, country: str, fuel: str = "gas") -> float:
    """Efficiency to use for one country's spread math.

    GB gas keeps the 49.13% UK market convention while the gas input sits at
    its 50% default -- that is what the spot-based views (daily calendar,
    hedge ratios, scenario grid, hourly capture) have always used. Any
    efficiency the user types applies to GB too.
    """
    effs = bundle_effs(bundle)
    if fuel == "gas" and str(country).upper() == "GB" \
            and effs.get("gas_default"):
        return UK_GAS_EFF
    return float(effs.get(fuel, EFF_DEFAULTS[fuel]))


def apply_effs(bundle: dict, effs: dict | None = None) -> dict:
    """Bundle view whose spread columns follow the chosen efficiencies.

    Rewrites ``{CSS,CDS}_MID_EFF`` (plus a +/-EFF_BAND band in
    ``*_BAND_LO/_BAND_HI``) whenever a fuel is moved off its default, and
    always adds the ``CLS_*`` clean lignite columns where GAS_PRICE allows.
    A fuel left at its default is not recomputed at all, so the precomputed
    MID columns are passed through untouched.

    Neither the cached bundle nor its frames are mutated: new frames come
    from .assign, so untouched columns stay shared.
    """
    if not isinstance(effs, dict) or "gas_default" not in effs:
        effs = normalize_effs(effs)
    if not bundle:
        return {EFF_KEY: effs}

    out = {**bundle, EFF_KEY: effs}
    css_raw = bundle.get("CSS_raw")
    if css_raw is not None:
        out["CSS_raw"] = _css_with_effs(css_raw, effs)
    cds_raw = bundle.get("CDS_raw")
    if cds_raw is not None:
        out["CDS_raw"] = _cds_with_effs(cds_raw, effs)
    return out


def _cached_frame(name: str, source: pd.DataFrame, key: tuple, build):
    """Memoize derived frames per (raw frame, name, efficiency key).

    Every callback re-derives the same columns, so a handful of slots keeps
    a page interaction to one pass over the raw history. Entries are dropped
    as soon as the bundle hands over a different frame object (a refresh),
    so stale histories are not kept alive.
    """
    cache_key = (name, key)
    with _EFF_LOCK:
        if _EFF_SOURCES.get(name) is not source:
            _EFF_SOURCES[name] = source
            for stale in [k for k in _EFF_CACHE if k[0] == name]:
                del _EFF_CACHE[stale]
        hit = _EFF_CACHE.get(cache_key)
        if hit is not None:
            _EFF_CACHE.move_to_end(cache_key)
            return hit
    built = build()
    with _EFF_LOCK:
        _EFF_CACHE[cache_key] = built
        _EFF_CACHE.move_to_end(cache_key)
        while len(_EFF_CACHE) > _EFF_CACHE_MAX:
            _EFF_CACHE.popitem(last=False)
    return built


def _reefficiency_cols(p: pd.Series, x: pd.Series, prefix: str,
                       eta: float) -> dict:
    """MID + band columns for one metric at efficiency ``eta``."""
    return {
        f"{prefix}_MID_EFF": p - x / eta,
        f"{prefix}_BAND_LO": p - x / (eta - EFF_BAND),
        f"{prefix}_BAND_HI": p - x / (eta + EFF_BAND),
    }


def _css_with_effs(css_raw: pd.DataFrame, effs: dict) -> pd.DataFrame:
    """CSS frame re-efficiencied for gas, with the lignite spread added."""
    if css_raw.empty:
        return css_raw
    if not {"CSS_LOW_EFF", "CSS_HI_EFF"}.issubset(css_raw.columns):
        if not effs["gas_default"]:
            logger.warning(
                "clean_spreads: CSS LOW/HI columns missing - cannot "
                "re-efficiency to %.4g", effs["gas"])
        return css_raw
    key = (round(effs["gas"], 8), round(effs["lignite"], 8),
           bool(effs["gas_default"]))
    return _cached_frame("CSS_raw", css_raw, key,
                         lambda: _build_css_effs(css_raw, effs))


def _build_css_effs(css_raw: pd.DataFrame, effs: dict) -> pd.DataFrame:
    p, x = _implied_p_x(css_raw, "CSS", GAS_EFFS)
    new: dict = {}
    if not effs["gas_default"]:
        new.update(_reefficiency_cols(p, x, "CSS", effs["gas"]))
    if "GAS_PRICE" in css_raw.columns:
        carbon = (x - css_raw["GAS_PRICE"]) / GAS_EF
        lig_x = LIGNITE_FUEL_COST + LIGNITE_EF * carbon
        valid = (carbon > 0) & (lig_x > 0)
        for col, value in _reefficiency_cols(p, lig_x, "CLS",
                                             effs["lignite"]).items():
            new[col] = value.where(valid)
    return css_raw.assign(**new) if new else css_raw


def _cds_with_effs(cds_raw: pd.DataFrame, effs: dict) -> pd.DataFrame:
    """CDS frame re-efficiencied for coal."""
    if cds_raw.empty or effs["coal_default"]:
        return cds_raw
    if not {"CDS_LOW_EFF", "CDS_HI_EFF"}.issubset(cds_raw.columns):
        logger.warning(
            "clean_spreads: CDS LOW/HI columns missing - cannot "
            "re-efficiency to %.4g", effs["coal"])
        return cds_raw
    key = (round(effs["coal"], 8),)

    def _build() -> pd.DataFrame:
        p, x = _implied_p_x(cds_raw, "CDS", COAL_EFFS)
        return cds_raw.assign(
            **_reefficiency_cols(p, x, "CDS", effs["coal"]))

    return _cached_frame("CDS_raw", cds_raw, key, _build)


# ── Issue date of the forward curves ──────────────────────────────────────
# Every forward frame is indexed by its trade date (DATE, renamed from the
# ETL's TRADE_DATE), which is the issue date of that curve. build_curve
# always takes the newest DATE available, so the numbers on screen can be
# days old without anything else on the page saying so.
def curve_issue_dates(bundle: dict | None,
                      metric: str = "CSS") -> dict[str, pd.Timestamp]:
    """Newest trade (issue) date per country in a raw forward frame.

    Only rows with a value in the metric's MID column count, so a country
    whose latest trade date carries nothing but NaNs reports the last date
    a curve could actually be built from.
    """
    metric = str(metric).upper()
    spec = METRICS.get(metric)
    if spec is None:
        return {}
    raw = (bundle or {}).get(spec["source"])
    if raw is None or raw.empty:
        return {}
    if not {"DATE", "COUNTRY"}.issubset(raw.index.names):
        return {}
    col = f"{spec['prefix']}_MID_EFF"
    if col not in raw.columns:
        # The metric does not exist in this bundle (e.g. CLS before
        # apply_effs, or where GAS_PRICE is missing) - report nothing
        # rather than borrowing the host frame's dates.
        return {}
    return _cached_frame(f"{metric}_issue_dates", raw, (col,),
                         lambda: _issue_dates(raw, col))


def _issue_dates(raw: pd.DataFrame, col: str) -> dict[str, pd.Timestamp]:
    dates = pd.to_datetime(raw.index.get_level_values("DATE"))
    countries = raw.index.get_level_values("COUNTRY").astype(str)
    frame = pd.DataFrame({"DATE": dates, "COUNTRY": countries})
    frame = frame[np.asarray(raw[col].notna())]
    if frame.empty:
        return {}
    grouped = frame.groupby("COUNTRY")["DATE"].max()
    return {str(k): pd.Timestamp(v) for k, v in grouped.items()}


def _business_days_between(start: pd.Timestamp, end: pd.Timestamp) -> int:
    """Business days from ``start`` to ``end`` (0 when end <= start)."""
    if start is None or end is None or pd.isna(start) or pd.isna(end):
        return 0
    days = int(np.busday_count(pd.Timestamp(start).date(),
                               pd.Timestamp(end).date()))
    return max(days, 0)


_STATUS_RANK = {"unknown": 0, "fresh": 1, "stale": 2, "critical": 3}


def _age_status(age: int) -> str:
    """Status of a curve that is ``age`` business days behind today."""
    if age <= ISSUE_FRESH_DAYS:
        return "fresh"
    if age <= ISSUE_STALE_DAYS:
        return "stale"
    return "critical"


def _lag_status(lag: int) -> str:
    """Status of a frame trailing the freshest one by ``lag`` trade days.

    Up to METRIC_LAG_TOLERANCE is normal publishing cadence (the dark curve
    lands later in the day than the spark curve), so it is reported without
    escalating the strip.
    """
    if lag <= METRIC_LAG_TOLERANCE:
        return "fresh"
    if lag <= METRIC_LAG_TOLERANCE + ISSUE_STALE_DAYS:
        return "stale"
    return "critical"


def _worst(*statuses: str) -> str:
    return max(statuses, key=lambda s: _STATUS_RANK.get(s, 0))


def forward_issue_summary(bundle: dict | None,
                          countries: list[str] | None = None,
                          today: pd.Timestamp | None = None) -> dict:
    """Issue-date health of the forward curves behind the page.

    Two independent questions are answered, because either one can mislead:
    has the whole feed stopped (absolute age vs today), and is one metric or
    country trailing the rest (relative lag, which would silently mix trade
    dates across the page).

    Returns::

        {"latest": Timestamp|None,      # newest curve issue date on file
         "per_country": {c: Timestamp},     # newest per country, any metric
         "per_metric": {"CSS": {"latest":…, "age":…, "status":…,
                                "behind":…, "per_country": {…}}, …},
         "age": int,                    # business days from latest to today
         "absolute_status": str,        # age vs today alone
         "status": str,                 # worst of absolute + lag
         "behind": {c: trade days that country lags ``latest``},
         "metrics_behind": {metric: trade days behind ``latest``}}

    Statuses follow the app-wide convention (see core.data_freshness):
    fresh / stale / critical, or unknown with no forward prices at all.
    """
    wanted = {c.upper() for c in countries} if countries else None
    per_metric: dict[str, dict] = {}
    for metric in SPREAD_METRICS:
        dates = curve_issue_dates(bundle, metric)
        if wanted:
            dates = {c: d for c, d in dates.items() if c in wanted}
        if dates:
            per_metric[metric] = {"latest": max(dates.values()),
                                  "per_country": dates}
    if not per_metric:
        return {"latest": None, "per_country": {}, "per_metric": {},
                "age": 0, "absolute_status": "unknown", "status": "unknown",
                "behind": {}, "metrics_behind": {}}

    per_country: dict[str, pd.Timestamp] = {}
    for info in per_metric.values():
        for country, stamp in info["per_country"].items():
            if country not in per_country or stamp > per_country[country]:
                per_country[country] = stamp

    latest = max(per_country.values())
    today = pd.Timestamp(today) if today is not None \
        else pd.Timestamp.today().normalize()
    age = _business_days_between(latest, today)
    absolute_status = _age_status(age)

    metrics_behind: dict[str, int] = {}
    for metric, info in per_metric.items():
        lag = _business_days_between(info["latest"], latest)
        info["behind"] = lag
        info["age"] = _business_days_between(info["latest"], today)
        # Judged on its lag alone: a metric's absolute age is the page's age
        # plus its normal publishing lag, so scoring that again would flag
        # the routine one-day gap between the dark and spark curves.
        info["status"] = _lag_status(lag)
        if lag > 0:
            metrics_behind[metric] = lag

    behind = {c: _business_days_between(d, latest)
              for c, d in per_country.items()
              if _business_days_between(d, latest) > 0}
    worst_lag = max(list(metrics_behind.values()) + list(behind.values())
                    + [0])
    return {"latest": latest, "per_country": per_country,
            "per_metric": per_metric, "age": age,
            "absolute_status": absolute_status,
            "status": _worst(absolute_status, _lag_status(worst_lag)),
            "behind": behind, "metrics_behind": metrics_behind}


# ── Rendered-view cache ───────────────────────────────────────────────────
# Every figure and table on this page is a pure function of (raw frames,
# efficiencies, controls), and the raw frames only change when a new curve
# is published. Keying on the curve issue date therefore invalidates itself:
# a new issue date is a new key, and nothing goes stale in between.
VIEW_TTL = 3600


def _code_fingerprint() -> str:
    """Short digest of this package's source mtimes.

    A cached view holds whatever shape its callback expected when it was
    written, so a code change has to invalidate it -- otherwise the first
    request after a deploy unpacks yesterday's value into today's outputs.
    Keying on the source mtimes does that automatically.
    """
    try:
        folder = Path(__file__).parent
        stamps = sorted(f"{p.name}:{int(p.stat().st_mtime)}"
                        for p in folder.glob("*.py"))
        return hashlib.sha1("|".join(stamps).encode()).hexdigest()[:8]
    except Exception:  # pragma: no cover - defensive
        return "dev"


_CODE_FINGERPRINT = _code_fingerprint()


def view_key(bundle: dict | None, *parts) -> str:
    """Cache key for a derived view: code + curve issue date + effs + controls."""
    effs = bundle_effs(bundle)
    latest = forward_issue_summary(bundle).get("latest")
    stamp = f"{pd.Timestamp(latest):%Y%m%d}" if latest is not None else "na"
    eff_bits = "-".join(f"{effs.get(f, 0):.4f}"
                        for f in ("gas", "coal", "lignite"))
    tail = "|".join("" if p is None else str(p) for p in parts)
    return f"{_CODE_FINGERPRINT}:{stamp}:{eff_bits}:{tail}"


def cached_view(bundle: dict | None, name: str, builder, *parts,
                ttl: int = VIEW_TTL):
    """Memoize one rendered view (figures, table payloads) for this page.

    ``builder`` is called only on a miss. A cache failure (an unpicklable
    component, a full disk) degrades to recomputing rather than erroring.
    """
    key = f"res:cs_view_{name}:{view_key(bundle, *parts)}"
    try:
        hit = dashboard_cache.get(key, ttl=ttl)
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("view cache read failed for %s: %s", name, exc)
        hit = None
    if hit is not None:
        return hit
    value = builder()
    try:
        dashboard_cache.set(key, value, ttl=ttl)
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("view cache write failed for %s: %s", name, exc)
    return value


def metric_cols(metric: str) -> list[str]:
    """Value + band columns to pull off a raw frame for a spread metric."""
    prefix = METRICS[str(metric).upper()]["prefix"]
    return [f"{prefix}_LOW_EFF", f"{prefix}_MID_EFF", f"{prefix}_HI_EFF",
            f"{prefix}_BAND_LO", f"{prefix}_BAND_HI"]


def metric_band(metric: str, effs: dict) -> tuple[float, float] | None:
    """(low, high) efficiency of the band drawn around a metric's curve."""
    spec = METRICS[str(metric).upper()]
    eff = effs.get(spec["fuel"])
    if effs.get(f"{spec['fuel']}_default") and spec["effs"] is not None:
        return spec["effs"]["low"], spec["effs"]["hi"]
    if eff is None:
        return None
    return eff - EFF_BAND, eff + EFF_BAND


# ── Frame slicing / curve construction ─────────────────────────────────────
def _country_frame(df: pd.DataFrame | None, country: str) -> pd.DataFrame:
    """Futures-only flat frame for one country from a CSS/CDS multi-index."""
    if df is None or df.empty:
        return pd.DataFrame()
    try:
        cdf = df.xs(country.upper(), level="COUNTRY")
    except KeyError:
        return pd.DataFrame()
    out = cdf.reset_index()
    if "DAYS_TO_DELIVERY" in out.columns:
        out = out[out["DAYS_TO_DELIVERY"] >= 2]
    if "DELIVERY_START" in out.columns:
        out["DELIVERY_START"] = pd.to_datetime(out["DELIVERY_START"])
    out["DATE"] = pd.to_datetime(out["DATE"])
    return out


def _next_quarter_start(ts: pd.Timestamp) -> pd.Timestamp:
    quarter = (ts.month - 1) // 3 + 1
    end_month = quarter * 3
    if end_month == 12:
        return pd.Timestamp(year=ts.year + 1, month=1, day=1)
    return pd.Timestamp(year=ts.year, month=end_month + 1, day=1)


def strip_label(period: str, year: int | float) -> str:
    """'JAN', 2026 -> 'JAN-26'; 'CAL', 2027 -> 'CAL-27'."""
    yy = int(year) % 100
    return f"{period}-{yy:02d}"


def build_curve(
    df: pd.DataFrame | None,
    country: str,
    cols: list[str],
    asof: pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Stitch a clean forward curve for one trade date.

    Months until the end of the current quarter, quarters afterwards, then
    calendar years beyond the last quarter (same convention as the CSS/DSS
    Fuel Comparison view and price_report strips).

    Returns a flat frame sorted by DELIVERY_START with columns:
    DELIVERY_PERIOD, STRIP, DELIVERY_START, CONTRACT_TYPE, Period, Year,
    DATE (curve date) + requested value cols.
    """
    return curve_from_flat(_country_frame(df, country), cols, asof=asof)


def curve_from_flat(
    cdf: pd.DataFrame,
    cols: list[str],
    asof: pd.Timestamp | None = None,
) -> pd.DataFrame:
    """:func:`build_curve` on a frame already sliced to one country.

    Slicing the country out of the raw multi-index is the expensive half, so
    callers that need several as-of curves for the same country (the curve
    ridge) slice once and call this in a loop.
    """
    if cdf is None or cdf.empty:
        return pd.DataFrame()

    cols = [c for c in cols if c in cdf.columns]
    if not cols:
        return pd.DataFrame()
    cdf = cdf.dropna(subset=cols, how="all")
    if cdf.empty:
        return pd.DataFrame()

    dates = np.sort(cdf["DATE"].unique())
    if asof is not None:
        dates = dates[dates <= np.datetime64(pd.Timestamp(asof))]
    if len(dates) == 0:
        return pd.DataFrame()
    curve_date = pd.Timestamp(dates[-1])

    day = cdf[cdf["DATE"] == curve_date].copy()
    if day.empty:
        return pd.DataFrame()
    day["CONTRACT_TYPE"] = day["CONTRACT_TYPE"].astype(str).str.upper()
    # One row per delivery period per contract type
    day = day.sort_values("DAYS_TO_DELIVERY").drop_duplicates(
        subset=["DELIVERY_PERIOD", "CONTRACT_TYPE"], keep="first"
    )

    next_q = _next_quarter_start(curve_date)
    rows: list[pd.Series] = []
    added: set[str] = set()

    months = day[day["CONTRACT_TYPE"] == "MONTHLY"].sort_values("DELIVERY_START")
    for _, row in months.iterrows():
        if curve_date <= row["DELIVERY_START"] < next_q:
            key = row["DELIVERY_START"].strftime("%Y-%m")
            if key not in added:
                rows.append(row)
                added.add(key)

    quarters = day[day["CONTRACT_TYPE"] == "QUARTERLY"].sort_values("DELIVERY_START")
    for _, row in quarters.iterrows():
        if row["DELIVERY_START"] >= next_q:
            key = row["DELIVERY_START"].strftime("%Y-%m")
            if key not in added:
                rows.append(row)
                added.add(key)

    years = day[day["CONTRACT_TYPE"] == "YEARLY"].sort_values("DELIVERY_START")
    quarter_years = {r["DELIVERY_START"].year for r in rows
                     if r["CONTRACT_TYPE"] == "QUARTERLY"}
    for _, row in years.iterrows():
        yr = row["DELIVERY_START"].year
        if yr not in quarter_years and str(yr) not in added:
            rows.append(row)
            added.add(str(yr))

    if not rows:
        return pd.DataFrame()

    curve = pd.DataFrame(rows).sort_values("DELIVERY_START").reset_index(drop=True)
    curve["DATE"] = curve_date
    curve["STRIP"] = [
        strip_label(p, y) for p, y in zip(curve["Period"], curve["Year"])
    ]
    keep = ["DELIVERY_PERIOD", "STRIP", "DELIVERY_START", "CONTRACT_TYPE",
            "Period", "Year", "DATE"] + cols
    return curve[[c for c in keep if c in curve.columns]]


# ── Snapshot with DoD / WoW / MoM changes ─────────────────────────────────
def curve_snapshot(df: pd.DataFrame | None, country: str, col: str) -> pd.DataFrame:
    """Current curve + changes vs 1D / 1W / 1M-ago curves for one metric col.

    Returns columns: STRIP, DELIVERY_START, CONTRACT_TYPE, Outright,
    DoD, WoW, MoM (changes in EUR/MWh), CURVE_DATE.
    """
    cur = build_curve(df, country, [col])
    if cur.empty:
        return pd.DataFrame()
    curve_date = pd.Timestamp(cur["DATE"].iloc[0])

    out = cur[["DELIVERY_PERIOD", "STRIP", "DELIVERY_START",
               "CONTRACT_TYPE", col]].rename(columns={col: "Outright"})
    for label, days in LOOKBACKS.items():
        hist = build_curve(df, country, [col],
                           asof=curve_date - pd.Timedelta(days=days))
        if hist.empty or pd.Timestamp(hist["DATE"].iloc[0]) == curve_date:
            out[label] = np.nan
            continue
        prev = hist.set_index("DELIVERY_PERIOD")[col]
        out[label] = out["Outright"] - out["DELIVERY_PERIOD"].map(prev)

    out["CURVE_DATE"] = curve_date
    return out.drop(columns=["DELIVERY_PERIOD"])


# ── Monthly projection & delivered history ────────────────────────────────
def expand_curve_monthly(curve: pd.DataFrame, col: str) -> pd.DataFrame:
    """Expand a stitched curve frame into a flat monthly series.

    Monthly contracts map 1:1; quarters repeat across their 3 months; cal
    years across 12. Returns columns: month (Timestamp, month start), value,
    STRIP.
    """
    if curve is None or curve.empty or col not in curve.columns:
        return pd.DataFrame()
    rows = []
    for _, row in curve.iterrows():
        n_months = _CONTRACT_MONTHS.get(str(row["CONTRACT_TYPE"]).upper(), 1)
        start = pd.Timestamp(row["DELIVERY_START"]).normalize().replace(day=1)
        for i in range(n_months):
            rows.append({
                "month": start + pd.DateOffset(months=i),
                "value": row[col],
                "STRIP": row["STRIP"],
            })
    proj = pd.DataFrame(rows)
    proj = proj.drop_duplicates(subset="month", keep="first")
    return proj.sort_values("month").reset_index(drop=True)


def monthly_projection(df: pd.DataFrame | None, country: str, col: str,
                       asof: pd.Timestamp | None = None) -> pd.DataFrame:
    """Monthly series from the stitched curve for one country/metric."""
    curve = build_curve(df, country, [col], asof=asof)
    return expand_curve_monthly(curve, col)


def delivered_monthly(delivered_spreads: pd.DataFrame | None,
                      country: str) -> pd.DataFrame:
    """Monthly delivered CSS outturn for one country.

    Returns columns: month (Timestamp, month start), value.
    """
    if delivered_spreads is None or delivered_spreads.empty:
        return pd.DataFrame()
    sub = delivered_spreads[
        delivered_spreads["Country"].astype(str).str.upper() == country.upper()
    ]
    rows = []
    for _, row in sub.iterrows():
        match = _MONTHLY_PERIOD_RE.match(str(row["Period"]).upper())
        if not match:
            continue
        month_num = MONTH_NUM[match.group(1)]
        year = int(row["YEAR"])
        value = row.get("CSS_MID_EFF")
        if pd.isna(value):
            continue
        rows.append({"month": pd.Timestamp(year, month_num, 1),
                     "value": float(value)})
    if not rows:
        return pd.DataFrame()
    out = pd.DataFrame(rows).drop_duplicates(subset="month", keep="last")
    return out.sort_values("month").reset_index(drop=True)


def delivered_value(delivered_spreads: pd.DataFrame | None, country: str,
                    period: str, year: int) -> float | None:
    """Delivered CSS for e.g. period='Q1', year=2025 -> Period 'Q1-25'."""
    if delivered_spreads is None or delivered_spreads.empty:
        return None
    label = strip_label(period.upper(), year)
    match = delivered_spreads[
        (delivered_spreads["Country"].astype(str).str.upper() == country.upper())
        & (delivered_spreads["Period"].astype(str).str.upper() == label)
    ]
    if match.empty:
        return None
    value = match["CSS_MID_EFF"].iloc[0]
    return float(value) if pd.notna(value) else None


def _strip_months(period: str, year) -> list[pd.Timestamp]:
    """Delivery months covered by a strip label ('Q1', 2026 -> Jan-Mar 26)."""
    period = str(period).upper()
    year = int(year)
    if period in MONTH_NUM:
        return [pd.Timestamp(year, MONTH_NUM[period], 1)]
    if period.startswith("Q") and period[1:].isdigit():
        first = (int(period[1:]) - 1) * 3 + 1
        return [pd.Timestamp(year, first + i, 1) for i in range(3)]
    if period == "CAL":
        return [pd.Timestamp(year, m, 1) for m in range(1, 13)]
    return []


def delivered_spread_monthly(bundle: dict, country: str,
                             metric: str = "CSS") -> pd.DataFrame:
    """Monthly delivered outturn for a spread metric at the current effs.

    CSS comes from the precomputed ``delivered_spreads`` frame while the gas
    input sits at its default (that frame is fixed at 50%, GB legs included);
    a typed efficiency, CDS and CLS are recomputed from realised daily spot.
    """
    metric = str(metric).upper()
    if metric == "CSS" and bundle_effs(bundle).get("gas_default"):
        return delivered_monthly(bundle.get("delivered_spreads"), country)
    return delivered_spot_monthly(bundle, country, metric)


def delivered_strip_value(bundle: dict, country: str, period: str, year,
                          metric: str = "CSS") -> float | None:
    """Delivered outturn for a strip ('Q1', 2026) at the current effs.

    Partly delivered strips return None rather than a misleading part-mean.
    """
    metric = str(metric).upper()
    if metric == "CSS" and bundle_effs(bundle).get("gas_default"):
        return delivered_value(bundle.get("delivered_spreads"), country,
                               period, year)
    monthly = delivered_spot_monthly(bundle, country, metric)
    months = _strip_months(period, year)
    if monthly.empty or not months:
        return None
    values = monthly[monthly["month"].isin(months)]["value"].dropna()
    if len(values) < len(months):
        return None
    return float(values.mean())


def delivered_and_forward(bundle: dict, country: str,
                          metric: str = "CSS") -> dict:
    """Combined monthly delivered history + current forward projection.

    ``metric``: CSS | CDS | CLS (CLS rides along on the CSS frame).
    """
    metric = str(metric).upper()
    spec = METRICS[metric]
    delivered = delivered_spread_monthly(bundle, country, metric)
    forward = monthly_projection(bundle.get(spec["source"]), country,
                                 f"{spec['prefix']}_MID_EFF")
    if not delivered.empty and not forward.empty:
        # Forward months strictly after the last delivered month
        forward = forward[forward["month"] > delivered["month"].max()]
    return {"delivered": delivered, "forward": forward}


def seasonality_matrix(delivered: pd.DataFrame,
                       forward: pd.DataFrame) -> dict:
    """Year x Month pivot of delivered history with forward-filled future.

    Returns {'values': pivot DataFrame (index=year, cols=1..12),
             'is_forward': same-shape bool DataFrame}.
    """
    frames = []
    if delivered is not None and not delivered.empty:
        frames.append(delivered.assign(kind="hist"))
    if forward is not None and not forward.empty:
        frames.append(forward[["month", "value"]].assign(kind="fwd"))
    if not frames:
        return {"values": pd.DataFrame(), "is_forward": pd.DataFrame()}

    allm = pd.concat(frames, ignore_index=True)
    allm = allm.drop_duplicates(subset="month", keep="first")
    allm["year"] = allm["month"].dt.year
    allm["month_num"] = allm["month"].dt.month

    values = allm.pivot_table(index="year", columns="month_num",
                              values="value", aggfunc="mean")
    fwd_flag = allm.assign(flag=(allm["kind"] == "fwd").astype(int)).pivot_table(
        index="year", columns="month_num", values="flag", aggfunc="max"
    ).fillna(0).astype(bool)
    values = values.reindex(columns=range(1, 13))
    fwd_flag = fwd_flag.reindex(index=values.index,
                                columns=range(1, 13), fill_value=False)
    return {"values": values, "is_forward": fwd_flag}


# ── Contract history (same seasonal contract across years) ────────────────
def _overlays_from_flat(flat: pd.DataFrame, col: str, period: str,
                        max_days: int | None = 365) -> pd.DataFrame:
    """Overlay rows for one strip label from a flat country frame."""
    if flat is None or flat.empty or col not in flat.columns \
            or "Period" not in flat.columns:
        return pd.DataFrame()
    sub = flat[flat["Period"].astype(str).str.upper() == period.upper()].copy()
    sub = sub.dropna(subset=[col])
    if max_days is not None:
        sub = sub[sub["DAYS_TO_DELIVERY"] <= max_days]
    if sub.empty:
        return pd.DataFrame()
    sub = sub.rename(columns={col: "value"})
    return sub[["Year", "DAYS_TO_DELIVERY", "DATE", "value"]].sort_values(
        ["Year", "DAYS_TO_DELIVERY"]
    )


def contract_overlays(df: pd.DataFrame | None, country: str, col: str,
                      period: str, max_days: int | None = 365) -> pd.DataFrame:
    """History of a strip (e.g. all Q1 contracts) vs days-to-delivery.

    Returns flat frame: Year, DAYS_TO_DELIVERY, DATE, value.
    """
    return _overlays_from_flat(_country_frame(df, country), col, period,
                               max_days=max_days)


# ── Heat rates (carbon-inclusive, efficiency-free ratios) ─────────────────
def _implied_p_x(frame: pd.DataFrame, prefix: str,
                 effs: dict) -> tuple[pd.Series, pd.Series]:
    """Recover implied power P and fuel+carbon cost X from LOW/HI spreads.

    Spread_eta = P - X/eta  =>  X = (HI - LOW) / (1/eta_lo - 1/eta_hi),
    P = LOW + X/eta_lo. Works for both CSS (gas effs) and CDS (coal effs).
    """
    lo_col, hi_col = f"{prefix}_LOW_EFF", f"{prefix}_HI_EFF"
    lo, hi = effs["low"], effs["hi"]
    x = (frame[hi_col] - frame[lo_col]) / (1.0 / lo - 1.0 / hi)
    p = frame[lo_col] + x / lo
    return p, x


def _add_heat_rate_cols(css_frame: pd.DataFrame | None,
                        cds_frame: pd.DataFrame | None) -> tuple[
                            pd.DataFrame, pd.DataFrame]:
    """Add GAS_HR / LIGNITE_HR to a CSS frame and COAL_HR to a CDS frame.

    Clean heat rate = P / X (power over per-MWh-fuel cost incl. carbon).
    Lignite needs the carbon price, backed out of the gas leg via GAS_PRICE.
    Frames may be curve frames or full country histories (flat).
    """
    css_out = pd.DataFrame() if css_frame is None else css_frame.copy()
    cds_out = pd.DataFrame() if cds_frame is None else cds_frame.copy()

    if not css_out.empty and {"CSS_LOW_EFF", "CSS_HI_EFF"}.issubset(
            css_out.columns):
        p, x = _implied_p_x(css_out, "CSS", GAS_EFFS)
        with np.errstate(divide="ignore", invalid="ignore"):
            css_out["GAS_HR"] = np.where(x > 0, p / x, np.nan)
            if "GAS_PRICE" in css_out.columns:
                carbon = (x - css_out["GAS_PRICE"]) / GAS_EF
                lign_cost = LIGNITE_FUEL_COST + LIGNITE_EF * carbon
                css_out["LIGNITE_HR"] = np.where(
                    (carbon > 0) & (lign_cost > 0), p / lign_cost, np.nan)

    if not cds_out.empty and {"CDS_LOW_EFF", "CDS_HI_EFF"}.issubset(
            cds_out.columns):
        p, x = _implied_p_x(cds_out, "CDS", COAL_EFFS)
        with np.errstate(divide="ignore", invalid="ignore"):
            cds_out["COAL_HR"] = np.where(x > 0, p / x, np.nan)

    return css_out, cds_out


def heat_rate_curve(bundle: dict, country: str,
                    asof: pd.Timestamp | None = None) -> pd.DataFrame:
    """Stitched forward curve of clean heat rates for one country.

    Returns curve frame with STRIP, DELIVERY_START, CONTRACT_TYPE, DATE and
    GAS_HR / COAL_HR / LIGNITE_HR (lignite only when GAS_PRICE is present).
    """
    css_cols = ["CSS_LOW_EFF", "CSS_MID_EFF", "CSS_HI_EFF", "GAS_PRICE"]
    cds_cols = ["CDS_LOW_EFF", "CDS_MID_EFF", "CDS_HI_EFF"]
    css_curve = build_curve(bundle.get("CSS_raw"), country, css_cols,
                            asof=asof)
    cds_curve = build_curve(bundle.get("CDS_raw"), country, cds_cols,
                            asof=asof)
    css_curve, cds_curve = _add_heat_rate_cols(css_curve, cds_curve)

    if css_curve.empty and cds_curve.empty:
        return pd.DataFrame()
    if css_curve.empty:
        return cds_curve
    if not cds_curve.empty and "COAL_HR" in cds_curve.columns:
        coal = cds_curve.set_index("DELIVERY_PERIOD")["COAL_HR"]
        css_curve["COAL_HR"] = css_curve["DELIVERY_PERIOD"].map(coal)
    return css_curve


def heat_rate_snapshot(bundle: dict, country: str, hr_col: str) -> pd.DataFrame:
    """Current heat-rate curve + DoD/WoW/MoM changes for one HR column."""
    cur = heat_rate_curve(bundle, country)
    if cur.empty or hr_col not in cur.columns:
        return pd.DataFrame()
    cur = cur.dropna(subset=[hr_col])
    if cur.empty:
        return pd.DataFrame()
    curve_date = pd.Timestamp(cur["DATE"].iloc[0])

    out = cur[["DELIVERY_PERIOD", "STRIP", "DELIVERY_START",
               "CONTRACT_TYPE", hr_col]].rename(columns={hr_col: "Outright"})
    for label, days in LOOKBACKS.items():
        hist = heat_rate_curve(bundle, country,
                               asof=curve_date - pd.Timedelta(days=days))
        if hist.empty or hr_col not in hist.columns or \
                pd.Timestamp(hist["DATE"].iloc[0]) == curve_date:
            out[label] = np.nan
            continue
        prev = hist.set_index("DELIVERY_PERIOD")[hr_col]
        out[label] = out["Outright"] - out["DELIVERY_PERIOD"].map(prev)

    out["CURVE_DATE"] = curve_date
    return out.drop(columns=["DELIVERY_PERIOD"])


def heat_rate_overlays(bundle: dict, country: str, fuel: str, period: str,
                       max_days: int | None = 365) -> pd.DataFrame:
    """Contract-history overlays for a heat-rate fuel (GAS/COAL/LIGNITE)."""
    fuel = fuel.upper()
    if fuel in ("GAS", "LIGNITE"):
        flat = _country_frame(bundle.get("CSS_raw"), country)
        flat, _ = _add_heat_rate_cols(flat, None)
        col = "GAS_HR" if fuel == "GAS" else "LIGNITE_HR"
    else:  # COAL
        flat = _country_frame(bundle.get("CDS_raw"), country)
        _, flat = _add_heat_rate_cols(None, flat)
        col = "COAL_HR"
    return _overlays_from_flat(flat, col, period, max_days=max_days)


# ── UK market-efficiency (49.13%) re-efficiency ───────────────────────────
def add_uk_market_css(gb_frame: pd.DataFrame) -> pd.DataFrame:
    """Re-efficiency GB CSS columns to the 49.13% UK market convention.

    With CSS_eta = P - X/eta (X = gas + EF x carbon cost per MWh fuel), the
    LOW (0.48) and HI (0.52) columns pin down X and P exactly:

        X = (CSS_HI - CSS_LOW) / (1/0.48 - 1/0.52)
        P = CSS_LOW + X / 0.48
        CSS_UK_MKT = P - X / 0.4913

    Adds columns: FUEL_CARBON_COST (X), POWER_IMPLIED (P), CSS_UK_MKT and
    CSS_MID_CHECK (algebra sanity: should equal CSS_MID_EFF).
    """
    out = gb_frame.copy()
    if out.empty or not {"CSS_LOW_EFF", "CSS_HI_EFF"}.issubset(out.columns):
        return out
    lo, hi = GAS_EFFS["low"], GAS_EFFS["hi"]
    x = (out["CSS_HI_EFF"] - out["CSS_LOW_EFF"]) / (1.0 / lo - 1.0 / hi)
    p = out["CSS_LOW_EFF"] + x / lo
    out["FUEL_CARBON_COST"] = x
    out["POWER_IMPLIED"] = p
    out["CSS_UK_MKT"] = p - x / UK_GAS_EFF
    out["CSS_MID_CHECK"] = p - x / GAS_EFFS["mid"]
    return out


def uk_market_curve(bundle: dict) -> pd.DataFrame:
    """GB forward curve with the CSS_UK_MKT (49.13%) column added."""
    css_raw = bundle.get("CSS_raw")
    curve = build_curve(css_raw, "GB",
                        ["CSS_LOW_EFF", "CSS_MID_EFF", "CSS_HI_EFF"])
    if curve.empty:
        return curve
    return add_uk_market_css(curve)


def uk_season_strips(monthly_proj: pd.DataFrame) -> pd.DataFrame:
    """Aggregate a GB monthly projection into Winter/Summer season strips.

    Winter-YY = Oct(YY)..Mar(YY+1); Summer-YY = Apr..Sep(YY).
    Returns: STRIP, season_start, value (simple mean of covered months),
    n_months.
    """
    if monthly_proj is None or monthly_proj.empty:
        return pd.DataFrame()
    proj = monthly_proj.copy()

    def _season(ts: pd.Timestamp) -> tuple[str, int]:
        if ts.month in (10, 11, 12):
            return "WIN", ts.year
        if ts.month in (1, 2, 3):
            return "WIN", ts.year - 1
        return "SUM", ts.year

    seasons = proj["month"].apply(_season)
    proj["season"] = [s for s, _ in seasons]
    proj["season_year"] = [y for _, y in seasons]

    grouped = proj.groupby(["season", "season_year"]).agg(
        value=("value", "mean"), n_months=("value", "size")
    ).reset_index()
    grouped["STRIP"] = [
        f"{s}-{int(y) % 100:02d}" for s, y in
        zip(grouped["season"], grouped["season_year"])
    ]
    grouped["season_start"] = [
        pd.Timestamp(int(y), 10, 1) if s == "WIN" else pd.Timestamp(int(y), 4, 1)
        for s, y in zip(grouped["season"], grouped["season_year"])
    ]
    return grouped.sort_values("season_start").reset_index(drop=True)


# ── UKA hedge-ratio math ──────────────────────────────────────────────────
def hedge_uka(mw: float, season: str) -> dict:
    """Carbon (UKA) + gas volumes implied by a UK CSS clip at 49.13% eff.

    Uses the theoretical carbon ratio 0.1821/0.4913 = 0.3706 tCO2/MWh(el).
    """
    hours = SEASON_HOURS.get(season, SEASON_HOURS["Winter"])
    power_mwh = float(mw) * hours
    tonnes = power_mwh * UK_CARBON_RATIO
    lots = tonnes / UKA_LOT_TONNES
    gas_mwh = power_mwh / UK_GAS_EFF
    therms = gas_mwh / THERM_TO_MWH
    return {
        "season": season,
        "hours": hours,
        "power_mwh": power_mwh,
        "carbon_ratio": UK_CARBON_RATIO,
        "tonnes": tonnes,
        "lots": lots,
        "lots_per_mw": (tonnes / UKA_LOT_TONNES) / float(mw) if mw else np.nan,
        "gas_mwh": gas_mwh,
        "therms": therms,
    }


# ── Daily calendar metrics (price_report page-1 replica) ──────────────────
def _naive_days(values) -> pd.Series | pd.DatetimeIndex:
    """to_datetime + strip any timezone + normalize to midnight.

    Some market-cache frames carry tz-aware timestamps (hourly power) while
    others are tz-naive; mixing them breaks pd.concat, so everything is
    coerced to naive local dates here.
    """
    dt = pd.to_datetime(values)
    if isinstance(dt, pd.Series):
        if dt.dt.tz is not None:
            dt = dt.dt.tz_localize(None)
        return dt.dt.normalize()
    if getattr(dt, "tz", None) is not None:
        dt = dt.tz_localize(None)
    return dt.normalize()


def _fx_daily_series(fx_data, token: str) -> pd.Series:
    """Extract a daily FX series (e.g. 'EURGBP') from the bundle fx frame."""
    if fx_data is None or getattr(fx_data, "empty", True):
        return pd.Series(dtype=float)
    flat = fx_data.reset_index()
    date_col = None
    for cand in ("date", "DATE"):
        if cand in flat.columns:
            date_col = cand
            break
    value_col = None
    for col in flat.columns:
        if token.upper() in str(col).upper():
            value_col = col
            break
    if value_col is None:
        return pd.Series(dtype=float)
    values = pd.to_numeric(flat[value_col], errors="coerce")
    if date_col is not None:
        idx = _naive_days(flat[date_col])
    else:
        idx = _naive_days(flat.index)
    return pd.Series(values.values, index=pd.Index(idx)).dropna().sort_index()


def _hub_currency(frame: pd.DataFrame | None, key_col: str,
                  key: str) -> str:
    """Currency the cache stores one hub in ('EUR' / 'GBP' / 'USD' / '').

    The normalized spot frames carry the unit alongside the value, and the
    GB hubs do not agree (NBP in EUR/MWh, UKA in GBP/t), so conversions
    must read this rather than assume a convention.
    """
    if frame is None or frame.empty or key_col not in frame.columns \
            or "currency" not in frame.columns:
        return ""
    sub = frame[frame[key_col].astype(str).str.upper() == key.upper()]
    if sub.empty:
        return ""
    values = sub["currency"].astype(str).str.upper().dropna()
    return str(values.iloc[-1]) if not values.empty else ""


def _spot_daily(frame: pd.DataFrame | None, key_col: str, key: str,
                name: str) -> pd.Series:
    """Daily mean of a normalized spot frame filtered on hub/zone."""
    if frame is None or frame.empty or key_col not in frame.columns:
        return pd.Series(dtype=float, name=name)
    sub = frame[frame[key_col].astype(str).str.upper() == key.upper()]
    if sub.empty:
        return pd.Series(dtype=float, name=name)
    dates = _naive_days(sub["valuedate"])
    out = sub.groupby(dates)["value"].mean()
    out.name = name
    return out


_HR_DAILY_COLS = {"GAS": "GAS_HR", "COAL": "COAL_HR", "LIGNITE": "LIGNITE_HR"}


def daily_spot_metrics(bundle: dict, country: str,
                       days: int = 450) -> pd.DataFrame:
    """Daily spot metrics for the calendar view, price_report conventions.

    Power / CDS / CSS / CLS / HeatRate / Gas / Carbon / Coal, all EUR-based
    (GB legs converted from GBP; Coal column stays API2 USD/t for display,
    CDS uses the EUR/MWh conversion).

    GB: NBP (GBP->EUR), UKA + GBP18 CPS (->EUR), gas eff 49.13%.
    EU: TTF, EUA, gas eff 50%. Coal eff 40%, lignite eff 37%, EF gas 0.1821
    / coal 0.34 / lignite 0.40 -- the spread efficiencies follow the page
    inputs carried on ``bundle`` (see spread_eff).
    """
    country = country.upper()
    is_gb = country == "GB"

    power = _spot_daily(bundle.get("power_spot_normalized"), "zone",
                        country, "Power")
    gas = _spot_daily(bundle.get("gas_spot_normalized"), "hub",
                      "NBP" if is_gb else "TTF", "Gas")
    carbon = _spot_daily(bundle.get("co2_spot_normalized"), "hub",
                         "UKA" if is_gb else "EUA", "Carbon")
    coal = _spot_daily(bundle.get("coal_spot_normalized"), "hub",
                       "API2", "Coal")
    if coal.empty and bundle.get("coal_spot_normalized") is not None:
        # Some caches label the coal hub differently; fall back to everything
        frame = bundle["coal_spot_normalized"]
        if not frame.empty:
            dates = _naive_days(frame["valuedate"])
            coal = frame.groupby(dates)["value"].mean()
            coal.name = "Coal"

    if power.empty or gas.empty or carbon.empty:
        return pd.DataFrame()

    df = pd.concat([power, gas, carbon, coal], axis=1).sort_index()

    # FX
    eurgbp = _fx_daily_series(bundle.get("fx_data"), "EURGBP")
    if not eurgbp.empty:
        df["EURGBP"] = eurgbp.reindex(df.index)
    else:
        df["EURGBP"] = np.nan
    df["EURGBP"] = df["EURGBP"].ffill(limit=5).fillna(0.85)

    eurusd = _fx_daily_series(bundle.get("fx_data"), "EURUSD")
    if not eurusd.empty:
        usd_to_eur = (1.0 / eurusd).reindex(df.index).ffill(limit=5)
        df["USD_TO_EUR"] = usd_to_eur.fillna(USD_TO_EUR_FALLBACK)
    else:
        df["USD_TO_EUR"] = USD_TO_EUR_FALLBACK

    # Forward-fill fuels over non-trading days (same limit as the report)
    df[["Gas", "Carbon", "Coal"]] = df[["Gas", "Carbon", "Coal"]].ffill(
        limit=5)

    if is_gb:
        # Convert per the cache's own currency metadata rather than by
        # convention: NBP is stored in EUR/MWh while UKA is stored in
        # GBP/t, so assuming both are GBP overstated GB gas by ~17%.
        # The GBP 18/t CPS is added in GBP, then converted with the leg.
        if _hub_currency(bundle.get("gas_spot_normalized"), "hub",
                         "NBP") == "GBP":
            df["Gas"] = df["Gas"] / df["EURGBP"]
        if _hub_currency(bundle.get("co2_spot_normalized"), "hub",
                         "UKA") == "GBP":
            df["Carbon"] = (df["Carbon"] + UK_CPS_GBP) / df["EURGBP"]
        else:  # already EUR: only the CPS needs converting
            df["Carbon"] = df["Carbon"] + UK_CPS_GBP / df["EURGBP"]

    gas_eff = spread_eff(bundle, country, "gas")
    coal_eff = spread_eff(bundle, country, "coal")
    lignite_eff = spread_eff(bundle, country, "lignite")
    coal_eur_mwh = df["Coal"] * df["USD_TO_EUR"] / API2_TO_MWH
    lig_x = LIGNITE_FUEL_COST + LIGNITE_EF * df["Carbon"]

    df["CSS"] = (df["Power"] - df["Gas"] / gas_eff
                 - (GAS_EF / gas_eff) * df["Carbon"])
    df["CDS"] = (df["Power"] - coal_eur_mwh / coal_eff
                 - (COAL_EF / coal_eff) * df["Carbon"])
    df["CLS"] = df["Power"] - lig_x / lignite_eff
    # Fuel + carbon cost per MWh fuel (heat-rate denominators)
    df["GAS_X"] = df["Gas"] + GAS_EF * df["Carbon"]
    df["COAL_X"] = coal_eur_mwh + COAL_EF * df["Carbon"]
    df["LIGNITE_X"] = lig_x
    with np.errstate(divide="ignore", invalid="ignore"):
        for fuel, hr_col in _HR_DAILY_COLS.items():
            x = df[f"{fuel}_X"]
            df[hr_col] = np.where(x > 0, df["Power"] / x, np.nan)
        df["HeatRate"] = df["GAS_HR"]

    df = df.dropna(subset=["Power"])
    if days is not None and not df.empty:
        cutoff = df.index.max() - pd.Timedelta(days=days)
        df = df[df.index >= cutoff]
    return df[["Power", "CDS", "CSS", "CLS", "HeatRate", "Gas", "Carbon",
               "Coal", "GAS_HR", "COAL_HR", "LIGNITE_HR",
               "GAS_X", "COAL_X", "LIGNITE_X"]]


def _monthly_spot_mean(bundle: dict, country: str, col: str,
                       days: int) -> pd.DataFrame:
    """Monthly mean of one realised daily spot column.

    Returns columns: month (Timestamp, month start), value.
    """
    daily = daily_spot_metrics(bundle, country, days=days)
    if daily.empty or col not in daily.columns:
        return pd.DataFrame()
    series = daily[col].dropna()
    if series.empty:
        return pd.DataFrame()
    monthly = series.groupby(series.index.to_period("M")).mean()
    return pd.DataFrame({
        "month": monthly.index.to_timestamp(),
        "value": monthly.values,
    })


def delivered_spot_monthly(bundle: dict, country: str, metric: str = "CSS",
                           days: int = 1830) -> pd.DataFrame:
    """Monthly delivered CSS / CDS / CLS recomputed from realised spot."""
    metric = str(metric).upper()
    if metric not in ("CSS", "CDS", "CLS"):
        return pd.DataFrame()
    return _monthly_spot_mean(bundle, country, metric, days)


def delivered_heat_rate_monthly(bundle: dict, country: str, fuel: str,
                                days: int = 1830) -> pd.DataFrame:
    """Monthly delivered clean heat rate from realised spot prices.

    Returns columns: month (Timestamp, month start), value.
    """
    col = _HR_DAILY_COLS.get(str(fuel).upper())
    if col is None:
        return pd.DataFrame()
    return _monthly_spot_mean(bundle, country, col, days)


def delivered_heat_rate_strips(bundle: dict, country: str, fuel: str,
                               period: str, years) -> dict[int, dict]:
    """Delivered clean heat rate for one strip label across delivery years.

    A forward HR is strip-average power over strip-average fuel+carbon cost,
    so the like-for-like outturn is the ratio of means, mean(P) / mean(X).
    The mean of daily P/X ratios differs from it by a Jensen / covariance
    term (either sign: fuel-cost variance pushes it up, P-X co-movement
    pulls it down), so both are returned and the gap is the band a forward
    is fairly compared within.

    Only fully delivered strips are included. Returns
    {year: {'ratio': mean(P)/mean(X), 'daily_mean': mean(P/X), 'days': n}}.
    """
    fuel = str(fuel).upper()
    hr_col = _HR_DAILY_COLS.get(fuel)
    if hr_col is None:
        return {}
    daily = daily_spot_metrics(bundle, country, days=None)
    if daily.empty:
        return {}
    x_col = f"{fuel}_X"
    daily = daily[(daily[x_col] > 0) & daily["Power"].notna()]
    if daily.empty:
        return {}
    last_day = daily.index.max()
    month_idx = daily.index.to_period("M").to_timestamp()

    out: dict[int, dict] = {}
    for year in years:
        months = _strip_months(period, year)
        if not months:
            continue
        strip_end = months[-1] + pd.offsets.MonthEnd(0)
        if last_day < strip_end:
            continue  # not fully delivered yet
        sub = daily[month_idx.isin(months)]
        if set(sub.index.to_period("M").to_timestamp()) != set(months):
            continue  # spot history does not cover the whole strip
        out[int(year)] = {
            "ratio": float(sub["Power"].mean() / sub[x_col].mean()),
            "daily_mean": float(sub[hr_col].mean()),
            "days": int(len(sub)),
        }
    return out


def delivered_and_forward_hr(bundle: dict, country: str, fuel: str) -> dict:
    """Monthly delivered heat-rate history + current forward HR projection."""
    delivered = delivered_heat_rate_monthly(bundle, country, fuel)
    col = _HR_DAILY_COLS.get(str(fuel).upper())
    hr_curve = heat_rate_curve(bundle, country)
    if hr_curve.empty or col is None or col not in hr_curve.columns:
        forward = pd.DataFrame()
    else:
        forward = expand_curve_monthly(hr_curve.dropna(subset=[col]), col)
    if not delivered.empty and not forward.empty:
        forward = forward[forward["month"] > delivered["month"].max()]
    return {"delivered": delivered, "forward": forward}


# ── CPS-inclusion diagnostic (UK Focus tab) ───────────────────────────────
def uk_cps_diagnostic(bundle: dict) -> dict | None:
    """Compare the fuel+carbon cost implied by the precomputed GB curve
    against a direct spot computation from the cached NBP / UKA / FX data.

    Verifies whether the precomputed CSS ETL includes the GBP 18/t CPS.
    Returns dict with implied_x, direct_x_cps, direct_x_no_cps, verdict.
    """
    try:
        curve = uk_market_curve(bundle)
        if curve.empty or "FUEL_CARBON_COST" not in curve.columns:
            return None
        # Front strip is closest to spot conditions
        implied_x = float(curve["FUEL_CARBON_COST"].iloc[0])

        gas = bundle.get("gas_spot_normalized")
        co2 = bundle.get("co2_spot_normalized")
        fx = bundle.get("fx_data")
        if gas is None or gas.empty or co2 is None or co2.empty:
            return None

        gas = gas.copy()
        gas["hub"] = gas["hub"].astype(str).str.upper()
        nbp = gas[gas["hub"] == "NBP"].sort_values("valuedate")
        co2 = co2.copy()
        co2["hub"] = co2["hub"].astype(str).str.upper()
        uka = co2[co2["hub"] == "UKA"].sort_values("valuedate")
        if nbp.empty or uka.empty:
            return None
        nbp_raw = float(nbp["value"].iloc[-1])
        uka_raw = float(uka["value"].iloc[-1])
        nbp_ccy = _hub_currency(bundle.get("gas_spot_normalized"), "hub",
                                "NBP")
        uka_ccy = _hub_currency(bundle.get("co2_spot_normalized"), "hub",
                                "UKA")

        eurgbp = None
        if fx is not None and not getattr(fx, "empty", True):
            fx_flat = fx.reset_index()
            for col_name in fx_flat.columns:
                if "EURGBP" in str(col_name).upper():
                    series = pd.to_numeric(fx_flat[col_name], errors="coerce").dropna()
                    if not series.empty:
                        eurgbp = float(series.iloc[-1])
                    break
        if not eurgbp:
            eurgbp = 0.85  # defensive fallback, same as price_report

        # Each leg is converted only if the cache stores it in GBP
        nbp_eur = nbp_raw / eurgbp if nbp_ccy == "GBP" else nbp_raw
        uka_eur = uka_raw / eurgbp if uka_ccy == "GBP" else uka_raw
        cps_eur = UK_CPS_GBP / eurgbp

        direct_x_cps = nbp_eur + GAS_EF * (uka_eur + cps_eur)
        direct_x_no_cps = nbp_eur + GAS_EF * uka_eur

        gap_cps = abs(implied_x - direct_x_cps)
        gap_no_cps = abs(implied_x - direct_x_no_cps)
        # Before reading anything into CPS inclusion, check the leg is the
        # right size at all: CPS is worth a few EUR/MWh of fuel, so a leg
        # off by tens of percent means the two candidates are both wrong
        # and whichever sits "closer" says nothing.
        ratio = (implied_x / direct_x_cps
                 if direct_x_cps else float("nan"))
        consistent = bool(np.isfinite(ratio)
                          and LEG_RATIO_MIN <= ratio <= LEG_RATIO_MAX)
        if not consistent:
            verdict = (
                f"WARNING: the precomputed GB fuel+carbon leg is "
                f"{ratio:.2f}x the cost implied by NBP + UKA + CPS "
                f"({implied_x:.2f} vs {direct_x_cps:.2f} EUR/MWh fuel). "
                "GB spreads on this page are not trustworthy until the "
                "upstream CSS table is fixed; CPS inclusion cannot be "
                "determined while the leg is this far out."
            )
        elif gap_cps <= gap_no_cps:
            verdict = "Precomputed GB curve appears to INCLUDE the GBP 18/t CPS."
        else:
            verdict = (
                "Precomputed GB curve appears to EXCLUDE the GBP 18/t CPS "
                f"(would add ~{GAS_EF * cps_eur / UK_GAS_EFF:.2f} EUR/MWh "
                "of cost to UK CSS)."
            )
        return {
            "implied_x": implied_x,
            "direct_x_cps": direct_x_cps,
            "direct_x_no_cps": direct_x_no_cps,
            "eurgbp": eurgbp,
            "ratio": ratio,
            "consistent": consistent,
            "verdict": verdict,
        }
    except Exception as exc:  # pragma: no cover - diagnostic only
        logger.warning("uk_cps_diagnostic failed: %s", exc)
        return None
