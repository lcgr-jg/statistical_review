"""Constants for the Clean Spark / Clean Dark Spreads page."""
from __future__ import annotations

# ── Page wiring ───────────────────────────────────────────────────────────
PAGE_PATH = "/power/clean-spreads"
PAGE_NAME = "Clean Spreads"
PAGE_TITLE = "Clean Spreads | JG Power Dashboard"
PAGE_ORDER = 3

# ── Countries (precomputed CSS/CDS coverage) ──────────────────────────────
COUNTRIES = ["DE", "FR", "NL", "GB", "BE", "IT", "ES", "AT"]
DEFAULT_COUNTRY = "DE"

# ── Efficiency conventions of the precomputed CSS/CDS frames ──────────────
# (FuelSpreadsCalculator defaults: eff1/eff2/eff3 -> LOW/MID/HI)
GAS_EFFS = {"low": 0.48, "mid": 0.50, "hi": 0.52}
COAL_EFFS = {"low": 0.36, "mid": 0.40, "hi": 0.42}

# ── User-selectable plant efficiencies ────────────────────────────────────
# The LOW/HI columns pin down implied power P and fuel+carbon cost X exactly
# (see data._implied_p_x), so any efficiency the user types is recovered as
# spread(eta) = P - X/eta. Leaving a fuel at its default reproduces the
# precomputed MID column byte-for-byte (nothing is recomputed).
DEFAULT_GAS_EFF = GAS_EFFS["mid"]        # 0.50  clean spark
DEFAULT_COAL_EFF = COAL_EFFS["mid"]      # 0.40  clean dark
DEFAULT_LIGNITE_EFF = 0.37               # clean lignite (34-40% fleet band)
EFF_DEFAULTS = {"gas": DEFAULT_GAS_EFF, "coal": DEFAULT_COAL_EFF,
                "lignite": DEFAULT_LIGNITE_EFF}
EFF_MIN, EFF_MAX = 0.10, 0.75            # accepted typed range (fractions)
EFF_BAND = 0.02                          # +/-2pp band drawn around a typed eff

# ── Issue-date tolerances ─────────────────────────────────────────────────
# Trade days a metric (or country) may trail the freshest forward frame
# before the issue-date strip escalates from "reported" to "warned about".
# Measured over 12 months of cached CSS/CDS: the two frames carry identical
# trade-date sets bar the newest day, i.e. the dark curve routinely lands
# later in the day than the spark curve, so one day of lag is normal.
METRIC_LAG_TOLERANCE = 1
# Business days the freshest curve may be behind today before escalating
# (a forward curve is normally yesterday's close).
ISSUE_FRESH_DAYS = 1
ISSUE_STALE_DAYS = 5

# ── Leg sanity band ───────────────────────────────────────────────────────
# A precomputed fuel+carbon leg should sit within this band of the cost the
# spot fuels imply; the front contract carries a forward/spot basis, so the
# band is wide. Outside it the spread is not a market view: measured on the
# cached data, DE/FR/NL sit at 1.00-1.06 while GB sits at 1.7-2.0.
LEG_RATIO_MIN, LEG_RATIO_MAX = 0.75, 1.35

# ── UK market conventions (price_report.py convention) ────────────────────
# UK CSS = Power - NBP/0.4913 - (0.1821/0.4913) * (UKA + 18 CPS)
UK_GAS_EFF = 0.4913          # UK market efficiency
GAS_EF = 0.1821              # tCO2 per MWh of gas burned (fuel input)
UK_CPS_GBP = 18.0            # UK Carbon Price Support, GBP/t, added to UKA
UKA_LOT_TONNES = 1000.0      # ICE UKA futures: 1,000 allowances per lot
THERM_TO_MWH = 0.029307      # 1 therm in MWh

# Theoretical carbon intensity per MWh of power at UK market efficiency.
# 0.1821 / 0.4913 = 0.3706 tCO2/MWh(el)  ->  ~1.62 UKA lots per MW-season.
UK_CARBON_RATIO = GAS_EF / UK_GAS_EFF

# ── Seasons (UK convention: Winter = Oct-Mar, Summer = Apr-Sep) ───────────
WINTER_MONTHS = (10, 11, 12, 1, 2, 3)
SUMMER_MONTHS = (4, 5, 6, 7, 8, 9)
# Nominal season hours (182 x 24 winter incl. clock changes netting out;
# 183 x 24 summer).
SEASON_HOURS = {"Winter": 4368, "Summer": 4392}

# ── Month helpers ─────────────────────────────────────────────────────────
MONTH_ABBR = {
    1: "JAN", 2: "FEB", 3: "MAR", 4: "APR", 5: "MAY", 6: "JUN",
    7: "JUL", 8: "AUG", 9: "SEP", 10: "OCT", 11: "NOV", 12: "DEC",
}
MONTH_NUM = {v: k for k, v in MONTH_ABBR.items()}

# ── Lignite convention (price_report monthly tables) ──────────────────────
# There is no precomputed lignite frame: the clean lignite spread is built
# from the gas leg as CLS = P - (LIGNITE_FUEL_COST + LIGNITE_EF x C) / eta,
# with P and C (carbon) backed out of the CSS LOW/HI columns + GAS_PRICE.
LIGNITE_FUEL_COST = 3.0   # EUR/MWh fuel input (fixed assumption)
LIGNITE_EF = 0.40         # tCO2 per MWh fuel input

# ── Daily calendar (price_report page-1 conventions) ───────────────────────
COAL_EF = 0.34             # tCO2 per MWh coal fuel input
COAL_EFF_REPORT = 0.40     # coal efficiency used in the report tables
GAS_EFF_REPORT = 0.50      # EU gas efficiency in the report tables
API2_TO_MWH = 6.97         # API2 USD/t -> per-MWh fuel divisor
USD_TO_EUR_FALLBACK = 1 / 1.10  # if no EURUSD series available

# Calendar metric specs: column -> (title template, colorscale, reversescale,
# decimals). {gas_hub}/{carbon_hub}/{eff} filled per country.
CAL_METRICS = {
    "Power": ("Power Price (€/MWh)", "YlOrRd", False, 0),
    "CDS": ("Clean Dark Spread (€/MWh) — Coal Eff {coal_eff}", "RdYlGn",
            False, 0),
    "CSS": ("Clean Spark Spread (€/MWh) — Gas Eff {eff}", "RdYlGn", False, 0),
    "CLS": ("Clean Lignite Spread (€/MWh) — Lignite Eff {lignite_eff}",
            "RdYlGn", False, 0),
    "HeatRate": ("Heat Rate (x)", "Viridis", False, 2),
    "Gas": ("Gas Price ({gas_hub} €/MWh)", "YlOrRd", False, 1),
    "Carbon": ("Carbon Price ({carbon_hub} €/t)", "Reds", False, 1),
    "Coal": ("Coal Price (API2 $/t)", "YlOrBr", False, 0),
}
CAL_METRIC_ORDER = ["Power", "CDS", "CSS", "CLS", "HeatRate", "Gas", "Carbon",
                    "Coal"]

# ── Snapshot change lookbacks (calendar days) ─────────────────────────────
LOOKBACKS = {"DoD": 1, "WoW": 7, "MoM": 30}

# ── Chart palette ─────────────────────────────────────────────────────────
CSS_COLOR = "#1f8a4c"                 # clean spark - green family
CSS_BAND = "rgba(31, 138, 76, 0.14)"
CDS_COLOR = "#c0392b"                 # clean dark - red family
CDS_BAND = "rgba(192, 57, 43, 0.12)"
CLS_COLOR = "#a0522d"                 # clean lignite - brown family
CLS_BAND = "rgba(160, 82, 45, 0.12)"
GHOST_1W_COLOR = "#8a93a0"
GHOST_1M_COLOR = "#c4cad3"
FORWARD_COLOR = "#2b6cb0"             # forward curve on timelines
DELIVERED_COLOR = "#6c7480"           # delivered outturn bars
UK_MKT_COLOR = "#7c3aed"              # UK 49.13% market-efficiency series

# Spread metrics. ``fuel`` keys into the user efficiency inputs; ``source``
# is the raw bundle frame the metric is computed from (CLS is derived from
# the gas leg, so it rides along on CSS_raw); ``effs`` is the precomputed
# LOW/MID/HI convention, or None for metrics that only exist at the typed
# efficiency (CLS).
METRICS = {
    "CSS": {"label": "Clean Spark (CSS)", "prefix": "CSS", "fuel": "gas",
            "source": "CSS_raw", "effs": GAS_EFFS,
            "color": CSS_COLOR, "band": CSS_BAND},
    "CDS": {"label": "Clean Dark (CDS)", "prefix": "CDS", "fuel": "coal",
            "source": "CDS_raw", "effs": COAL_EFFS,
            "color": CDS_COLOR, "band": CDS_BAND},
    "CLS": {"label": "Clean Lignite (CLS)", "prefix": "CLS",
            "fuel": "lignite", "source": "CSS_raw", "effs": None,
            "color": CLS_COLOR, "band": CLS_BAND},
}
SPREAD_METRICS = ("CSS", "CDS", "CLS")

# ── Heat-rate view ─────────────────────────────────────────────────────────
# Clean (carbon-inclusive) heat rate = implied Power / (Fuel + EF x Carbon),
# i.e. the efficiency-free ratio P / X recovered from the spread algebra.
# Lignite backs the carbon price out of the gas leg (needs GAS_PRICE col):
#   C = (X_gas - GAS_PRICE) / 0.1821
#   LIGNITE_HR = P / (3.0 + 0.40 x C)
HEAT_RATES = {
    "GAS": {"label": "Gas heat rate", "col": "GAS_HR", "color": "#2171b5"},
    "COAL": {"label": "Coal heat rate", "col": "COAL_HR", "color": "#6c757d"},
    "LIGNITE": {"label": "Lignite heat rate", "col": "LIGNITE_HR",
                "color": "#a0522d"},
}
HEAT_RATE_FUEL_OPTIONS = ["COMBINED", "GAS", "COAL", "LIGNITE"]
