"""Trader-pack analytics for the Clean Spreads page.

Screener stats, cross-country RV, switching carbon, scenario shocks,
risk premium, vol cone, rolling betas, hedge ratios, hourly capture and
season strips / rolldown. Pure-pandas; operates on the price_data bundle
via the primitives in core.clean_spreads.data.
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from core.clean_spreads import data as cs_data
from core.clean_spreads.constants import (
    COAL_EF,
    COAL_EFFS,
    GAS_EF,
    GAS_EFFS,
    METRICS,
    MONTH_ABBR,
    MONTH_NUM,
    UK_CPS_GBP,
    UKA_LOT_TONNES,
)

logger = logging.getLogger(__name__)

# Default shock ladders for the scenario grid (EUR)
GAS_SHOCKS = [-10.0, -5.0, -2.0, 0.0, 2.0, 5.0, 10.0]
CARBON_SHOCKS = [-20.0, -10.0, -5.0, 0.0, 5.0, 10.0, 20.0]


# Heat-rate metrics: selector value -> column produced by
# data._add_heat_rate_cols / data.heat_rate_curve
HR_METRIC_COLS = {"HR_GAS": "GAS_HR", "HR_COAL": "COAL_HR",
                  "HR_LIGNITE": "LIGNITE_HR"}


def is_hr_metric(metric: str) -> bool:
    return str(metric).upper() in HR_METRIC_COLS


def _metric_frame(bundle: dict, metric: str):
    spec = METRICS.get(str(metric).upper())
    return bundle.get(spec["source"] if spec else "CSS_raw")


def _mid_col(metric: str) -> str:
    return f"{metric.upper()}_MID_EFF"


def _metric_flat(bundle: dict, country: str,
                 metric: str) -> tuple[pd.DataFrame, str]:
    """Flat country history + value column for any pack metric.

    metric: 'CSS' | 'CDS' | 'CLS' | 'HR_GAS' | 'HR_COAL' | 'HR_LIGNITE'.
    Spread metrics read the MID column of their raw frame, which the bundle
    view has already re-efficiencied to the user's inputs.
    """
    metric = str(metric).upper()
    if metric in HR_METRIC_COLS:
        fuel = metric[3:]
        if fuel in ("GAS", "LIGNITE"):
            flat = cs_data._country_frame(bundle.get("CSS_raw"), country)
            flat, _ = cs_data._add_heat_rate_cols(flat, None)
        else:  # COAL
            flat = cs_data._country_frame(bundle.get("CDS_raw"), country)
            _, flat = cs_data._add_heat_rate_cols(None, flat)
        return flat, HR_METRIC_COLS[metric]
    return (cs_data._country_frame(_metric_frame(bundle, metric), country),
            _mid_col(metric))


def _metric_curve(bundle: dict, country: str, metric: str,
                  asof: pd.Timestamp | None = None
                  ) -> tuple[pd.DataFrame, str]:
    """Stitched forward curve + value column for any pack metric."""
    metric = str(metric).upper()
    if metric in HR_METRIC_COLS:
        col = HR_METRIC_COLS[metric]
        curve = cs_data.heat_rate_curve(bundle, country, asof=asof)
        if curve.empty or col not in curve.columns:
            return pd.DataFrame(), col
        return curve.dropna(subset=[col]), col
    col = _mid_col(metric)
    return (cs_data.build_curve(_metric_frame(bundle, metric), country,
                                [col], asof=asof), col)


def _contract_series(flat: pd.DataFrame, delivery_period,
                     contract_type: str, col: str) -> pd.Series:
    """One contract's trade history (DATE-indexed values)."""
    sub = flat[(flat["DELIVERY_PERIOD"] == delivery_period)
               & (flat["CONTRACT_TYPE"].astype(str).str.upper()
                  == str(contract_type).upper())]
    sub = sub.dropna(subset=[col]).sort_values("DATE")
    sub = sub.drop_duplicates(subset="DATE", keep="last")
    return pd.Series(sub[col].values, index=pd.DatetimeIndex(sub["DATE"]))


# ── Screener ────────────────────────────────────────────────────────────────
def screener(bundle: dict, countries: list[str],
             metric: str = "CSS") -> pd.DataFrame:
    """Rich/cheap stats for every live contract across countries.

    Columns: Country, STRIP, Type, Issued, Outright, DoD, zDoD, WoW, MoM,
    Pctile, Obs. Issued is that contract's last trade date, so a country
    whose curve lags the rest is visible row by row. zDoD = DoD / std of
    the contract's own daily changes; Pctile = percentile of the current
    level within the contract's full history.
    ``metric``: CSS | CDS | CLS | HR_GAS | HR_COAL | HR_LIGNITE.
    """
    rows = []
    for country in countries:
        flat, col = _metric_flat(bundle, country, metric)
        if flat.empty or col not in flat.columns:
            continue
        curve, _ = _metric_curve(bundle, country, metric)
        if curve.empty:
            continue
        for _, crow in curve.iterrows():
            series = _contract_series(flat, crow["DELIVERY_PERIOD"],
                                      crow["CONTRACT_TYPE"], col)
            if series.empty:
                continue
            outright = float(series.iloc[-1])
            last_date = series.index[-1]
            changes = series.diff().dropna()
            dod = float(changes.iloc[-1]) if len(changes) else np.nan
            std = float(changes.std(ddof=1)) if len(changes) >= 20 else np.nan
            z = dod / std if std and np.isfinite(std) and std > 0 else np.nan

            def _chg(days: int) -> float:
                past = series[series.index
                              <= last_date - pd.Timedelta(days=days)]
                return outright - float(past.iloc[-1]) if len(past) \
                    else np.nan

            pctile = float((series <= outright).mean() * 100.0)
            rows.append({
                "Country": country,
                "STRIP": crow["STRIP"],
                "Type": str(crow["CONTRACT_TYPE"]).title(),
                "DELIVERY_START": crow["DELIVERY_START"],
                "Issued": pd.Timestamp(last_date),
                "Outright": outright,
                "DoD": dod,
                "zDoD": z,
                "WoW": _chg(7),
                "MoM": _chg(30),
                "Pctile": pctile,
                "Obs": int(len(series)),
            })
    if not rows:
        return pd.DataFrame()
    return (pd.DataFrame(rows)
            .sort_values(["Country", "DELIVERY_START"])
            .reset_index(drop=True))


# ── Cross-country RV matrix ─────────────────────────────────────────────────
def rv_matrix(bundle: dict, countries: list[str], metric: str = "CSS",
              contract_type: str = "QUARTERLY",
              z_window: int = 252) -> dict:
    """Pairwise front-contract differentials with z-scores.

    Uses each country's front contract of ``contract_type``; pairs are
    aligned on the most common front DELIVERY_START so we compare the same
    delivery window. Returns {'diff': df, 'z': df, 'strip': str,
    'countries': [..]} (row minus column).
    ``metric``: CSS | CDS | CLS | HR_GAS | HR_COAL | HR_LIGNITE.
    """
    ctype = contract_type.upper()

    col = ""
    fronts: dict[str, pd.Timestamp] = {}
    flats: dict[str, pd.DataFrame] = {}
    for country in countries:
        flat, col = _metric_flat(bundle, country, metric)
        if flat.empty or col not in flat.columns:
            continue
        curve, _ = _metric_curve(bundle, country, metric)
        if curve.empty:
            continue
        sub = curve[curve["CONTRACT_TYPE"].astype(str).str.upper() == ctype]
        if sub.empty:
            continue
        fronts[country] = pd.Timestamp(sub["DELIVERY_START"].iloc[0])
        flats[country] = flat
    if len(fronts) < 2:
        return {}

    # Align everyone on the most common front delivery start
    target = pd.Series(list(fronts.values())).mode().iloc[0]
    strip = ""
    series: dict[str, pd.Series] = {}
    for country, flat in flats.items():
        sub = flat[(flat["CONTRACT_TYPE"].astype(str).str.upper() == ctype)
                   & (pd.to_datetime(flat["DELIVERY_START"]) == target)]
        sub = sub.dropna(subset=[col]).sort_values("DATE")
        sub = sub.drop_duplicates(subset="DATE", keep="last")
        if len(sub) < 5:
            continue
        series[country] = pd.Series(sub[col].values,
                                    index=pd.DatetimeIndex(sub["DATE"]))
        if not strip:
            strip = cs_data.strip_label(str(sub["Period"].iloc[-1]),
                                        int(sub["Year"].iloc[-1]))
    names = sorted(series)
    if len(names) < 2:
        return {}

    diff = pd.DataFrame(np.nan, index=names, columns=names)
    zmat = pd.DataFrame(np.nan, index=names, columns=names)
    for a in names:
        for b in names:
            if a == b:
                continue
            joined = pd.concat([series[a].rename("a"),
                                series[b].rename("b")], axis=1).dropna()
            if len(joined) < 20:
                continue
            d = (joined["a"] - joined["b"]).tail(z_window)
            now = float(d.iloc[-1])
            std = float(d.std(ddof=1))
            diff.loc[a, b] = now
            zmat.loc[a, b] = (now - float(d.mean())) / std \
                if std > 0 else np.nan
    return {"diff": diff, "z": zmat, "strip": strip, "countries": names}


# ── Implied switching carbon price ─────────────────────────────────────────
def switching_carbon_curve(bundle: dict, country: str) -> pd.DataFrame:
    """Per curve tenor: implied EUA vs the coal<->gas switching price C*.

    From the gas leg: G = GAS_PRICE, C = (X_gas - G)/0.1821. From the coal
    leg: K = X_coal - 0.34*C. With the chosen gas/coal efficiencies
    (default 50% / 40%), C* solves
        (G + 0.1821*C*)/eta_gas = (K + 0.34*C*)/eta_coal.
    For C > C* coal costs rise faster -> gas in merit.

    Returns STRIP, DELIVERY_START, implied_carbon, switching_carbon,
    gas_in_merit, gas_cost, coal_cost.
    """
    effs = cs_data.bundle_effs(bundle)
    gas_eta, coal_eta = effs["gas"], effs["coal"]
    css = cs_data.build_curve(
        bundle.get("CSS_raw"), country,
        ["CSS_LOW_EFF", "CSS_MID_EFF", "CSS_HI_EFF", "GAS_PRICE"])
    cds = cs_data.build_curve(
        bundle.get("CDS_raw"), country,
        ["CDS_LOW_EFF", "CDS_MID_EFF", "CDS_HI_EFF"])
    if css.empty or cds.empty or "GAS_PRICE" not in css.columns:
        return pd.DataFrame()

    _p_g, x_gas = cs_data._implied_p_x(css, "CSS", GAS_EFFS)
    gas_price = css["GAS_PRICE"]
    carbon = (x_gas - gas_price) / GAS_EF

    _p_c, x_coal = cs_data._implied_p_x(cds, "CDS", COAL_EFFS)
    x_coal_map = pd.Series(x_coal.values,
                           index=cds["DELIVERY_PERIOD"].values)
    x_coal_aligned = css["DELIVERY_PERIOD"].map(x_coal_map)
    coal_fuel = x_coal_aligned - COAL_EF * carbon  # K

    denom = GAS_EF / gas_eta - COAL_EF / coal_eta
    switching = (coal_fuel / coal_eta - gas_price / gas_eta) / denom

    out = css[["STRIP", "DELIVERY_START", "CONTRACT_TYPE"]].copy()
    out["implied_carbon"] = carbon
    out["switching_carbon"] = switching
    out["gas_in_merit"] = carbon > switching
    out["gas_cost"] = (gas_price + GAS_EF * carbon) / gas_eta
    out["coal_cost"] = (coal_fuel + COAL_EF * carbon) / coal_eta
    return out.dropna(subset=["implied_carbon", "switching_carbon"])


# ── Gas/carbon scenario grid ────────────────────────────────────────────────
def scenario_grid(bundle: dict, country: str, strip: str,
                  gas_shocks: list[float] | None = None,
                  carbon_shocks: list[float] | None = None) -> dict:
    """CSS for one contract under gas x carbon shocks (power held fixed).

    Priced at the chosen gas efficiency (see data.spread_eff).
    Returns {'grid': DataFrame(index=carbon shocks, cols=gas shocks),
    'base': {...decomposition...}, 'strip': str}.
    """
    gas_shocks = gas_shocks or GAS_SHOCKS
    carbon_shocks = carbon_shocks or CARBON_SHOCKS
    eff = cs_data.spread_eff(bundle, country, "gas")

    curve = cs_data.build_curve(
        bundle.get("CSS_raw"), country,
        ["CSS_LOW_EFF", "CSS_MID_EFF", "CSS_HI_EFF", "GAS_PRICE"])
    if curve.empty or "GAS_PRICE" not in curve.columns:
        return {}
    row = curve[curve["STRIP"] == strip]
    if row.empty:
        row = curve.iloc[[0]]
    row = row.iloc[0]

    frame = pd.DataFrame([row])
    p, x = cs_data._implied_p_x(frame, "CSS", GAS_EFFS)
    p, x = float(p.iloc[0]), float(x.iloc[0])
    gas = float(row["GAS_PRICE"])
    carbon = (x - gas) / GAS_EF
    if not np.isfinite(carbon):
        return {}

    grid = pd.DataFrame(
        [[p - (gas + dg) / eff - (GAS_EF / eff) * (carbon + dc)
          for dg in gas_shocks] for dc in carbon_shocks],
        index=carbon_shocks, columns=gas_shocks)
    base_css = p - gas / eff - (GAS_EF / eff) * carbon
    return {
        "grid": grid,
        "strip": str(row["STRIP"]),
        "base": {"power": p, "gas": gas, "carbon": carbon,
                 "eff": eff, "css": base_css},
    }


def curve_strips(bundle: dict, country: str) -> list[str]:
    """Available strip labels on the current CSS curve (for dropdowns)."""
    curve = cs_data.build_curve(bundle.get("CSS_raw"), country,
                                ["CSS_MID_EFF"])
    return list(curve["STRIP"]) if not curve.empty else []


# ── Forward risk premium ────────────────────────────────────────────────────
def _delivered_months(bundle: dict, country: str,
                      metric: str) -> list[tuple[str, int, float]]:
    """(month_abbr, year, delivered value) per delivered month for a metric.

    CSS at the default gas efficiency comes from the precomputed
    delivered_spreads frame; CSS at a typed efficiency, CDS and CLS are
    monthly means of the realised daily spread, and HR_* of the realised
    daily clean heat rate (all from daily_spot_metrics).
    """
    metric = str(metric).upper()
    out: list[tuple[str, int, float]] = []
    if metric == "CSS" and cs_data.bundle_effs(bundle).get("gas_default"):
        ds = bundle.get("delivered_spreads")
        if ds is None or ds.empty:
            return out
        sub = ds[ds["Country"].astype(str).str.upper() == country.upper()]
        for _, drow in sub.iterrows():
            match = cs_data._MONTHLY_PERIOD_RE.match(
                str(drow["Period"]).upper())
            if not match or pd.isna(drow.get("CSS_MID_EFF")):
                continue
            out.append((match.group(1), int(drow["YEAR"]),
                        float(drow["CSS_MID_EFF"])))
        return out

    if metric in HR_METRIC_COLS:
        monthly = cs_data.delivered_heat_rate_monthly(
            bundle, country, metric[3:])
    else:  # CSS / CDS / CLS from realised daily spot metrics
        monthly = cs_data.delivered_spot_monthly(bundle, country, metric)
    if monthly is None or monthly.empty:
        return out
    # Drop the current, incomplete month
    last_full = pd.Timestamp.today().normalize().replace(day=1)
    for _, mrow in monthly.iterrows():
        month = pd.Timestamp(mrow["month"])
        if month >= last_full or pd.isna(mrow["value"]):
            continue
        out.append((MONTH_ABBR[month.month], month.year,
                    float(mrow["value"])))
    return out


def risk_premium(bundle: dict, country: str, metric: str = "CSS",
                 lookbacks: tuple[int, ...] = (30, 60, 90),
                 tolerance: int = 10) -> pd.DataFrame:
    """Forward at D-k minus delivered outturn for past monthly contracts.

    Returns one row per delivered month: year, month_num, Period,
    delivered, fwd_{k} and prem_{k} per lookback.
    ``metric``: CSS | CDS | CLS | HR_GAS | HR_COAL | HR_LIGNITE.
    """
    flat, col = _metric_flat(bundle, country, metric)
    if flat.empty or col not in flat.columns:
        return pd.DataFrame()

    rows = []
    for mon, year, delivered in _delivered_months(bundle, country, metric):
        hist = flat[(flat["Period"].astype(str).str.upper() == mon)
                    & (flat["Year"] == year)
                    & (flat["CONTRACT_TYPE"].astype(str).str.upper()
                       == "MONTHLY")].dropna(subset=[col])
        if hist.empty:
            continue
        row = {"year": year, "month_num": MONTH_NUM[mon], "Period": mon,
               "delivered": delivered}
        found = False
        for k in lookbacks:
            near = hist[(hist["DAYS_TO_DELIVERY"] - k).abs() <= tolerance]
            if near.empty:
                row[f"fwd_{k}"] = np.nan
                row[f"prem_{k}"] = np.nan
                continue
            best = near.iloc[(near["DAYS_TO_DELIVERY"] - k).abs().argmin()]
            row[f"fwd_{k}"] = float(best[col])
            row[f"prem_{k}"] = float(best[col]) - row["delivered"]
            found = True
        if found:
            rows.append(row)
    if not rows:
        return pd.DataFrame()
    return (pd.DataFrame(rows)
            .sort_values(["year", "month_num"]).reset_index(drop=True))


def risk_premium_summary(premiums: pd.DataFrame,
                         lookbacks: tuple[int, ...] = (30, 60, 90)
                         ) -> pd.DataFrame:
    """Per calendar month: mean premium and hit rate per lookback."""
    if premiums is None or premiums.empty:
        return pd.DataFrame()
    rows = []
    for month_num, grp in premiums.groupby("month_num"):
        row = {"month_num": int(month_num), "n": int(len(grp))}
        for k in lookbacks:
            vals = grp[f"prem_{k}"].dropna()
            row[f"mean_{k}"] = float(vals.mean()) if len(vals) else np.nan
            row[f"hit_{k}"] = float((vals > 0).mean() * 100.0) \
                if len(vals) else np.nan
        rows.append(row)
    return pd.DataFrame(rows).sort_values("month_num").reset_index(drop=True)


# ── Volatility cone ─────────────────────────────────────────────────────────
def vol_cone(bundle: dict, country: str, period: str,
             metric: str = "CSS", window: int = 20,
             max_days: int = 400, bin_size: int = 10) -> dict:
    """Realized vol vs days-to-delivery percentile cone for one tenor.

    Vol = rolling std of daily changes (window obs), annualized (x sqrt252).
    Cone = percentiles across historical contract years per DTD bin;
    'current' = the live (nearest-delivery future) contract's vol path.
    ``metric``: CSS | CDS | CLS | HR_GAS | HR_COAL | HR_LIGNITE.
    """
    if is_hr_metric(metric):
        overlays = cs_data.heat_rate_overlays(
            bundle, country, str(metric).upper()[3:], period,
            max_days=max_days)
    else:
        raw = _metric_frame(bundle, metric)
        col = _mid_col(metric)
        overlays = cs_data.contract_overlays(raw, country, col, period,
                                             max_days=max_days)
    if overlays.empty:
        return {}

    vols = []
    for year, grp in overlays.groupby("Year"):
        grp = grp.sort_values("DATE")
        vol = grp["value"].diff().rolling(window).std(ddof=1) * np.sqrt(252)
        vols.append(pd.DataFrame({
            "Year": year,
            "DAYS_TO_DELIVERY": grp["DAYS_TO_DELIVERY"].values,
            "vol": vol.values,
        }))
    voldf = pd.concat(vols, ignore_index=True).dropna(subset=["vol"])
    if voldf.empty:
        return {}

    current_year = int(voldf["Year"].max())
    hist = voldf[voldf["Year"] < current_year]
    cur = voldf[voldf["Year"] == current_year].sort_values(
        "DAYS_TO_DELIVERY", ascending=False)

    bins = {}
    if not hist.empty:
        binned = (hist["DAYS_TO_DELIVERY"] // bin_size) * bin_size \
            + bin_size / 2
        grp = hist.groupby(binned)["vol"]
        bins = pd.DataFrame({
            "dtd": grp.mean().index,
            "p10": grp.quantile(0.10).values,
            "p25": grp.quantile(0.25).values,
            "p50": grp.quantile(0.50).values,
            "p75": grp.quantile(0.75).values,
            "p90": grp.quantile(0.90).values,
        }).sort_values("dtd", ascending=False)
    return {"cone": bins if isinstance(bins, pd.DataFrame) else
            pd.DataFrame(), "current": cur, "current_year": current_year}


# ── Rolling gas/carbon betas ────────────────────────────────────────────────
def _front_contract(flat: pd.DataFrame, period: str,
                    col: str) -> pd.DataFrame:
    """Trade history of the nearest not-yet-delivered contract of a tenor."""
    sub = flat[flat["Period"].astype(str).str.upper() == period.upper()]
    sub = sub.dropna(subset=[col])
    if sub.empty:
        return pd.DataFrame()
    live = sub[pd.to_datetime(sub["DELIVERY_START"])
               > sub["DATE"].max()]
    target_year = int((live if not live.empty else sub)["Year"].min())
    out = sub[sub["Year"] == target_year].sort_values("DATE")
    return out.drop_duplicates(subset="DATE", keep="last")


def rolling_betas(bundle: dict, country: str, period: str,
                  window: int = 60) -> pd.DataFrame:
    """Rolling 2-factor betas of CSS changes on gas and implied-carbon
    changes for the front contract of a tenor.

    CSS is the curve column at the chosen gas efficiency, so the betas
    scale with it (theoretically -1/eta and -EF/eta).
    Returns DATE, BETA_GAS, BETA_CARBON, R2, STRIP.
    """
    flat = cs_data._country_frame(bundle.get("CSS_raw"), country)
    needed = {"CSS_LOW_EFF", "CSS_HI_EFF", "CSS_MID_EFF", "GAS_PRICE"}
    if flat.empty or not needed.issubset(flat.columns):
        return pd.DataFrame()
    hist = _front_contract(flat, period, "CSS_MID_EFF")
    hist = hist.dropna(subset=["GAS_PRICE"])
    if len(hist) < window + 5:
        return pd.DataFrame()

    _p, x = cs_data._implied_p_x(hist, "CSS", GAS_EFFS)
    carbon = (x - hist["GAS_PRICE"]) / GAS_EF
    frame = pd.DataFrame({
        "css": hist["CSS_MID_EFF"].values,
        "gas": hist["GAS_PRICE"].values,
        "carbon": carbon.values,
    }, index=pd.DatetimeIndex(hist["DATE"])).diff().dropna()
    if len(frame) < window:
        return pd.DataFrame()

    dates, bg, bc, r2s = [], [], [], []
    y_all = frame["css"].to_numpy()
    x_all = frame[["gas", "carbon"]].to_numpy()
    for i in range(window, len(frame) + 1):
        y = y_all[i - window:i]
        x_mat = np.column_stack([np.ones(window), x_all[i - window:i]])
        try:
            coef, _res, _rank, _sv = np.linalg.lstsq(x_mat, y, rcond=None)
        except np.linalg.LinAlgError:
            continue
        pred = x_mat @ coef
        ss_tot = float(((y - y.mean()) ** 2).sum())
        r2 = 1 - float(((y - pred) ** 2).sum()) / ss_tot \
            if ss_tot > 0 else np.nan
        dates.append(frame.index[i - 1])
        bg.append(float(coef[1]))
        bc.append(float(coef[2]))
        r2s.append(r2)
    if not dates:
        return pd.DataFrame()
    strip = cs_data.strip_label(str(hist["Period"].iloc[-1]),
                                int(hist["Year"].iloc[-1]))
    return pd.DataFrame({"DATE": dates, "BETA_GAS": bg,
                         "BETA_CARBON": bc, "R2": r2s, "STRIP": strip})


# ── Hedge ratios / Greeks ───────────────────────────────────────────────────
def _delivery_hours(start: pd.Timestamp, contract_type: str) -> float:
    months = cs_data._CONTRACT_MONTHS.get(str(contract_type).upper(), 1)
    end = pd.Timestamp(start) + pd.DateOffset(months=months)
    return float((end - pd.Timestamp(start)) / pd.Timedelta(hours=1))


def hedge_ratios(bundle: dict, country: str, strip: str,
                 mw: float) -> dict:
    """Fuel/carbon legs of a CSS clip for any country.

    Gas MWh = MW*hours/eta; carbon tonnes = MW*hours*EF/eta; EUA/UKA lots
    = tonnes/1000. eta is the chosen gas efficiency (GB defaults to the
    49.13% market efficiency, and to UKA + CPS conventions in the priced
    legs).
    """
    is_gb = country.upper() == "GB"
    eff = cs_data.spread_eff(bundle, country, "gas")
    curve = cs_data.build_curve(
        bundle.get("CSS_raw"), country,
        ["CSS_LOW_EFF", "CSS_MID_EFF", "CSS_HI_EFF", "GAS_PRICE"])
    if curve.empty:
        return {}
    row = curve[curve["STRIP"] == strip]
    if row.empty:
        row = curve.iloc[[0]]
    row = row.iloc[0]

    hours = _delivery_hours(row["DELIVERY_START"], row["CONTRACT_TYPE"])
    power_mwh = float(mw) * hours
    gas_mwh = power_mwh / eff
    tonnes = power_mwh * GAS_EF / eff
    result = {
        "strip": str(row["STRIP"]),
        "hours": hours,
        "power_mwh": power_mwh,
        "gas_mwh": gas_mwh,
        "carbon_tonnes": tonnes,
        "carbon_lots": tonnes / UKA_LOT_TONNES,
        "eff": eff,
        "carbon_unit": "UKA" if is_gb else "EUA",
        # Hide the CSS level when the curve column is on a different
        # efficiency than the legs (GB curve at 50%, legs at 49.13%).
        "css": None if (is_gb and cs_data.bundle_effs(bundle).get(
            "gas_default")) else float(row.get("CSS_MID_EFF", np.nan)),
    }
    if "GAS_PRICE" in curve.columns and pd.notna(row.get("GAS_PRICE")):
        frame = pd.DataFrame([row])
        _p, x = cs_data._implied_p_x(frame, "CSS", GAS_EFFS)
        carbon = (float(x.iloc[0]) - float(row["GAS_PRICE"])) / GAS_EF
        result["gas_price"] = float(row["GAS_PRICE"])
        result["carbon_price"] = carbon
    if is_gb:
        result["cps_note"] = (f"GB carbon leg includes the "
                              f"\u00a3{UK_CPS_GBP:.0f}/t CPS on top of UKA.")
    return result


# ── Hourly capture ──────────────────────────────────────────────────────────
def hourly_capture(bundle: dict, country: str,
                   months_back: int = 12) -> dict:
    """Hour x month average spark spread + monthly capture factors.

    CSS_h = hourly power - (daily gas + EF*carbon cost)/eff at the chosen
    gas efficiency, using the EUR-converted daily fuel legs from
    daily_spot_metrics (GB handled).
    Capture factor = mean(max(CSS_h, 0)) / |baseload CSS| per month.
    """
    eff = cs_data.spread_eff(bundle, country, "gas")

    daily = cs_data.daily_spot_metrics(bundle, country,
                                       days=months_back * 31)
    if daily.empty:
        return {}
    cost = daily["Gas"] / eff + (GAS_EF / eff) * daily["Carbon"]

    power = bundle.get("power_spot_normalized")
    if power is None or power.empty:
        return {}
    sub = power[power["zone"].astype(str).str.upper() == country.upper()]
    if sub.empty:
        return {}
    stamps = cs_data._naive_days(sub["valuedate"])  # date part
    hours_dt = pd.to_datetime(sub["valuedate"])
    if getattr(hours_dt.dt, "tz", None) is not None:
        hours_dt = hours_dt.dt.tz_localize(None)
    hourly = pd.DataFrame({
        "date": stamps.values,
        "hour": hours_dt.dt.hour.values,
        "power": sub["value"].values,
    })
    hourly = hourly[hourly["date"] >= cost.index.min()]
    hourly["cost"] = hourly["date"].map(cost)
    hourly = hourly.dropna(subset=["cost"])
    if hourly.empty:
        return {}
    hourly["css_h"] = hourly["power"] - hourly["cost"]
    hourly["month"] = pd.to_datetime(hourly["date"]).dt.to_period("M")

    pivot = hourly.pivot_table(index="hour", columns="month",
                               values="css_h", aggfunc="mean")
    monthly = hourly.groupby("month")["css_h"].agg(
        baseload="mean",
        captured=lambda s: s.clip(lower=0).mean(),
    )
    monthly["capture_factor"] = np.where(
        monthly["baseload"].abs() > 1e-9,
        monthly["captured"] / monthly["baseload"].abs(), np.nan)
    return {"pivot": pivot, "monthly": monthly.reset_index()}


# ── Season strips + rolldown ────────────────────────────────────────────────
def season_strips(bundle: dict, country: str,
                  metric: str = "CSS") -> pd.DataFrame:
    """Winter/Summer strips for any country (mean of the monthly proj).

    ``metric``: CSS | CDS | CLS | HR_GAS | HR_COAL | HR_LIGNITE.
    """
    curve, col = _metric_curve(bundle, country, metric)
    proj = cs_data.expand_curve_monthly(curve, col)
    return cs_data.uk_season_strips(proj)


def winsum_spreads(strips: pd.DataFrame) -> pd.DataFrame:
    """WIN-yy minus SUM-yy (summer preceding that winter)."""
    if strips is None or strips.empty:
        return pd.DataFrame()
    win = strips[strips["season"] == "WIN"].set_index("season_year")
    sum_ = strips[strips["season"] == "SUM"].set_index("season_year")
    years = sorted(set(win.index) & set(sum_.index))
    rows = [{
        "year": int(y),
        "label": f"Win-Sum {int(y) % 100:02d}",
        "win": float(win.loc[y, "value"]),
        "sum": float(sum_.loc[y, "value"]),
        "spread": float(win.loc[y, "value"] - sum_.loc[y, "value"]),
    } for y in years]
    return pd.DataFrame(rows)


def rolldown_table(bundle: dict, country: str,
                   metric: str = "CSS") -> pd.DataFrame:
    """Static-curve rolldown: nearer-contract value minus contract value.

    Positive = the position marks up as it ages if the curve is unchanged.
    ``metric``: CSS | CDS | CLS | HR_GAS | HR_COAL | HR_LIGNITE.
    """
    curve, col = _metric_curve(bundle, country, metric)
    if curve.empty:
        return pd.DataFrame()
    out = curve[["STRIP", "DELIVERY_START", "CONTRACT_TYPE", col]].rename(
        columns={col: "Outright"})
    out["NearerValue"] = out["Outright"].shift(1)
    out["Rolldown"] = out["NearerValue"] - out["Outright"]
    return out
