"""Callbacks for the Clean Spreads page (registered on import)."""
from __future__ import annotations

import logging

import dash
import pandas as pd
from dash import Input, Output, State, callback, dcc, html

from core.clean_spreads import analytics as cs_analytics
from core.clean_spreads import charts_analytics as cs_charts2
from core.clean_spreads import data as cs_data
from core.clean_spreads import charts as cs_charts
from core.clean_spreads import fundamentals as cs_fundamentals
from core.clean_spreads.constants import (
    CAL_METRIC_ORDER,
    CAL_METRICS,
    COUNTRIES,
    EFF_DEFAULTS,
    EFF_MAX,
    EFF_MIN,
    HEAT_RATES,
    LIGNITE_EF,
    LIGNITE_FUEL_COST,
    LOOKBACKS,
    METRICS,
    MONTH_ABBR,
    SPREAD_METRICS,
    UK_GAS_EFF,
    UKA_LOT_TONNES,
)
from core.clean_spreads.tables import make_screener_table, make_snapshot_table
from core.styles import COLORS

logger = logging.getLogger(__name__)

_EMPTY_TABLE = make_snapshot_table(pd.DataFrame())


def _loading_placeholder(country: str = ""):
    return cs_charts.placeholder_figure(
        "Price data is still loading \u2014 revisit in a moment."
    )


def _pct(eff: float) -> str:
    """0.5 -> '50%', 0.4913 -> '49.13%'."""
    return f"{eff * 100:g}%"


# ── Forward-curve issue date ──────────────────────────────────────────────
# Same colour semantics as the app-wide freshness footer
# (core.freshness_widget): green fresh, amber stale, red critical.
_ISSUE_COLORS = {"fresh": "#4CAF50", "stale": "#ff9800",
                 "critical": "#f44336", "unknown": "#9e9e9e"}


def _issue_age_text(age: int) -> str:
    if age <= 0:
        return "today's curve"
    if age == 1:
        return "1 business day old"
    return f"{age} business days old"


def _leg_warning(diag: dict, detail: str):
    """Red alert for a country whose precomputed legs do not reconcile."""
    return html.Div(
        style={"backgroundColor": "rgba(244, 67, 54, 0.08)",
               "border": f"1px solid {_ISSUE_COLORS['critical']}",
               "borderLeft": f"4px solid {_ISSUE_COLORS['critical']}",
               "borderRadius": "10px", "padding": "12px 16px",
               "marginBottom": "12px"},
        children=[
            html.Div(
                f"GB spreads look wrong — fuel+carbon leg is "
                f"{diag['ratio']:.2f}x the NBP + UKA + CPS cost",
                style={"fontSize": "13px", "fontWeight": "700",
                       "color": _ISSUE_COLORS["critical"],
                       "marginBottom": "4px"},
            ),
            html.Div(
                "The precomputed GB CSS columns disagree with the cash "
                "fuels, so the curve on this tab (and every GB spread on "
                "the page) is far too negative. This is an upstream data "
                "issue, not a display one — the same check passes for the "
                "EU countries. Treat GB numbers as unusable until the "
                "source CSS table is corrected.",
                style={"fontSize": "11.5px",
                       "color": COLORS["text_secondary"],
                       "marginBottom": "6px"},
            ),
            html.Div(detail, style={"fontSize": "11px",
                                    "color": COLORS["text_muted"]}),
        ],
    )


def _metric_issue_chips(summary: dict) -> list:
    """One chip per spread metric showing its own issue date and any lag.

    CSS and CDS come from separate frames that publish at different times,
    so a single page-level date would hide a metric sitting a trade day
    behind the rest.
    """
    chips = []
    for metric, info in summary.get("per_metric", {}).items():
        lag = info.get("behind", 0)
        beyond_cadence = info.get("status", "fresh") != "fresh"
        parts = [f"{METRICS[metric]['prefix']} {info['latest']:%d %b}"]
        if lag:
            plural = "" if lag == 1 else "s"
            parts.append(f" ({lag} trade day{plural} behind)")
        chips.append(html.Span(
            "".join(parts),
            style={
                "fontSize": "11.5px",
                "padding": "2px 8px",
                "borderRadius": "6px",
                "backgroundColor": ("rgba(255, 152, 0, 0.14)"
                                    if beyond_cadence
                                    else "rgba(0, 0, 0, 0.04)"),
                "color": (_ISSUE_COLORS["stale"] if beyond_cadence
                          else COLORS["text_secondary"]),
                "fontWeight": "600" if beyond_cadence else "500",
            },
        ))
    return chips


@callback(
    Output("cs-issue-banner", "children"),
    Input("cs-issue-poll", "n_intervals"),
    Input("cs-tabs", "active_tab"),
    Input("cs-eff-store", "data"),
)
def update_issue_banner(_poll, _active_tab, effs):
    """Show which forward-curve issue date the whole page is priced off."""
    summary = cs_data.forward_issue_summary(cs_data.get_bundle(effs),
                                            COUNTRIES)
    status = summary["status"]
    color = _ISSUE_COLORS.get(status, _ISSUE_COLORS["unknown"])
    latest = summary["latest"]

    if latest is None:
        headline = "Forward curve issue date unavailable"
        detail = ("No forward prices in the cache yet — revisit once the "
                  "price bundle has loaded.")
    else:
        headline = f"{latest:%a %d %b %Y}"
        detail = _issue_age_text(summary["age"])
        if summary["absolute_status"] != "fresh":
            detail = f"{detail} — you are NOT looking at today's curve"

    behind = summary.get("behind") or {}
    lag_note = ""
    if behind:
        listed = ", ".join(
            f"{country} {summary['per_country'][country]:%d %b}"
            f" ({days}bd behind)"
            for country, days in sorted(behind.items(),
                                        key=lambda kv: -kv[1]))
        lag_note = f"Countries lagging the rest: {listed}."

    return html.Div(
        style={"display": "flex", "alignItems": "center", "gap": "14px",
               "flexWrap": "wrap",
               "backgroundColor": COLORS["card_bg"],
               "border": f"1px solid {COLORS['border']}",
               "borderLeft": f"4px solid {color}",
               "borderRadius": "10px",
               "padding": "10px 16px", "marginBottom": "14px"},
        children=[
            html.Span(style={"width": "10px", "height": "10px",
                             "borderRadius": "50%",
                             "backgroundColor": color,
                             "flex": "0 0 auto"}),
            html.Div([
                html.Div("Forward curve issue date",
                         style={"fontSize": "10px", "fontWeight": "600",
                                "letterSpacing": "0.6px",
                                "textTransform": "uppercase",
                                "color": COLORS["text_secondary"]}),
                html.Div([
                    html.Span(headline, style={"fontSize": "15px",
                                               "fontWeight": "600",
                                               "color": color}),
                    html.Span(f" · {detail}",
                              style={"fontSize": "12px",
                                     "color": COLORS["text_secondary"]}),
                ]),
            ]),
            html.Div(_metric_issue_chips(summary),
                     style={"display": "flex", "gap": "6px",
                            "flexWrap": "wrap"}),
            html.Div(
                " ".join(filter(None, [
                    "Trade date of every forward number on this page "
                    "(spreads, curves, screener, strips); the Daily "
                    "Calendar and delivered bars are realised spot.",
                    lag_note,
                ])),
                style={"fontSize": "11px", "color": COLORS["text_muted"],
                       "maxWidth": "620px"},
            ),
        ],
    )


# ── Global efficiency inputs ─────────────────────────────────────────────
@callback(
    Output("cs-eff-store", "data"),
    Output("cs-eff-note", "children"),
    Input("cs-eff-gas", "value"),
    Input("cs-eff-coal", "value"),
    Input("cs-eff-lignite", "value"),
)
def update_efficiencies(gas, coal, lignite):
    """Sanitize the typed efficiencies into the store every tab reads."""
    effs = cs_data.normalize_effs({"gas": gas, "coal": coal,
                                   "lignite": lignite})
    store = {fuel: round(effs[fuel] * 100, 4) for fuel in EFF_DEFAULTS}
    note = (
        f"Pricing at gas {_pct(effs['gas'])} \u00b7 coal "
        f"{_pct(effs['coal'])} \u00b7 lignite {_pct(effs['lignite'])} "
        f"(clamped to {_pct(EFF_MIN)}\u2013{_pct(EFF_MAX)}). CSS/CDS are "
        "re-efficiencied off the precomputed legs; CLS = implied power "
        f"\u2212 ({LIGNITE_FUEL_COST:g} \u20ac/MWh + {LIGNITE_EF:g} \u00d7 "
        "carbon) / eff, with carbon backed out of the gas leg. GB keeps "
        f"the {_pct(UK_GAS_EFF)} market efficiency in the spot-based views "
        f"while gas sits at {_pct(EFF_DEFAULTS['gas'])}."
    )
    return store, note


# ── Tab 1: control visibility (Spreads vs Heat rates) ─────────────────────
@callback(
    Output("cs-snap-metric-wrap", "style"),
    Output("cs-snap-fuel-wrap", "style"),
    Input("cs-snap-view", "value"),
)
def toggle_snapshot_controls(view):
    if view == "HEATRATES":
        return {"display": "none"}, {"display": "block"}
    return {"display": "block"}, {"display": "none"}


# ── Tab 1: Curve Snapshot ─────────────────────────────────────────────────
_SNAP_TITLES = ("Clean Spark table", "Clean Dark table",
                "Clean Lignite table")


@callback(
    Output("cs-snap-curve-chart", "figure"),
    Output("cs-snap-css-table", "data"),
    Output("cs-snap-css-table", "columns"),
    Output("cs-snap-css-table", "style_data_conditional"),
    Output("cs-snap-cds-table", "data"),
    Output("cs-snap-cds-table", "columns"),
    Output("cs-snap-cds-table", "style_data_conditional"),
    Output("cs-snap-cls-table", "data"),
    Output("cs-snap-cls-table", "columns"),
    Output("cs-snap-cls-table", "style_data_conditional"),
    Output("cs-snap-css-title", "children"),
    Output("cs-snap-cds-title", "children"),
    Output("cs-snap-cls-title", "children"),
    Output("cs-snap-footnote", "children"),
    Input("cs-snap-country", "value"),
    Input("cs-snap-metric", "value"),
    Input("cs-snap-view", "value"),
    Input("cs-snap-fuel", "value"),
    Input("cs-eff-store", "data"),
)
def update_snapshot(country, metric, view, fuel, effs):
    country = (country or "DE").upper()
    metric = (metric or "ALL").upper()
    view = view or "SPREADS"
    fuel = (fuel or "COMBINED").upper()
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        empty = _EMPTY_TABLE
        return ((_loading_placeholder(),)
                + (empty["data"], empty["columns"],
                   empty["style_data_conditional"]) * 3
                + _SNAP_TITLES + ("",))

    if view == "HEATRATES":
        return cs_data.cached_view(
            bundle, "snap_hr",
            lambda: _snapshot_heat_rates(bundle, country, fuel),
            country, fuel)
    return cs_data.cached_view(
        bundle, "snap_spreads",
        lambda: _snapshot_spreads(bundle, country, metric),
        country, metric)


def _snapshot_spreads(bundle, country, metric):
    effs = cs_data.bundle_effs(bundle)

    # Curve chart with ghosts
    wanted = [metric] if metric in METRICS else list(SPREAD_METRICS)
    curves: dict = {}
    curve_date = None
    for key in wanted:
        raw = bundle.get(METRICS[key]["source"])
        cols = cs_data.metric_cols(key)
        current = cs_data.build_curve(raw, country, cols)
        if current.empty:
            continue
        curve_date = pd.Timestamp(current["DATE"].iloc[0])
        curves[key] = {
            "current": current,
            "ghost_1w": cs_data.build_curve(
                raw, country, cols,
                asof=curve_date - pd.Timedelta(days=LOOKBACKS["WoW"])),
            "ghost_1m": cs_data.build_curve(
                raw, country, cols,
                asof=curve_date - pd.Timedelta(days=LOOKBACKS["MoM"])),
        }
    fig = cs_charts.curve_chart(curves, country, effs)

    # Change tables (always all three, mirroring the price_report layout)
    tables = []
    for key in SPREAD_METRICS:
        tables.append(make_snapshot_table(cs_data.curve_snapshot(
            bundle.get(METRICS[key]["source"]), country,
            f"{METRICS[key]['prefix']}_MID_EFF")))

    footnote = ""
    if curve_date is not None:
        gb_note = ""
        if country == "GB" and effs["gas_default"]:
            gb_note = (f" GB curves are precomputed at "
                       f"{_pct(effs['gas'])}; see UK Focus for "
                       f"{_pct(UK_GAS_EFF)}.")
        cls_note = ""
        if "CLS" in wanted and "CLS" not in curves:
            cls_note = (" Clean lignite unavailable — the gas leg carries "
                        "no GAS_PRICE column, so carbon cannot be backed "
                        "out.")
        footnote = (
            f"Curve issue date: {curve_date:%d %b %Y}. Efficiencies: gas "
            f"{_pct(effs['gas'])}, coal {_pct(effs['coal'])}, lignite "
            f"{_pct(effs['lignite'])}.{gb_note} Changes vs closest prior "
            f"curve at 1/7/30 calendar days.{cls_note}"
        )

    outputs = (fig,)
    for table in tables:
        outputs += (table["data"], table["columns"],
                    table["style_data_conditional"])
    return outputs + _SNAP_TITLES + (footnote,)


def _snapshot_heat_rates(bundle, country, fuel):
    fuels = ["GAS", "COAL", "LIGNITE"] if fuel == "COMBINED" else [fuel]

    current = cs_data.heat_rate_curve(bundle, country)
    curve_set = {"current": current}
    curve_date = None
    if not current.empty:
        curve_date = pd.Timestamp(current["DATE"].iloc[0])
        curve_set["ghost_1w"] = cs_data.heat_rate_curve(
            bundle, country,
            asof=curve_date - pd.Timedelta(days=LOOKBACKS["WoW"]))
        curve_set["ghost_1m"] = cs_data.heat_rate_curve(
            bundle, country,
            asof=curve_date - pd.Timedelta(days=LOOKBACKS["MoM"]))
    fig = cs_charts.heat_rate_curve_chart(curve_set, fuels, country)

    # One table per fuel, in the same order as the spread tables
    table_fuels = ["GAS", "COAL", "LIGNITE"]
    tables = [
        make_snapshot_table(
            cs_data.heat_rate_snapshot(bundle, country,
                                       HEAT_RATES[hr_fuel]["col"]),
            mode="heat_rate")
        for hr_fuel in table_fuels
    ]

    footnote = ""
    if curve_date is not None:
        lignite_available = ("LIGNITE_HR" in current.columns
                             and current["LIGNITE_HR"].notna().any())
        footnote = (
            f"Curve issue date: {curve_date:%d %b %Y}. Clean heat rate = "
            "implied power / (fuel + EF x carbon), efficiency-free; "
            "breakeven at "
            f"1.0x (= the CLS/CSS sign flip at your efficiency). Lignite "
            f"assumes {LIGNITE_FUEL_COST:g} €/MWh fuel, EF "
            f"{LIGNITE_EF:g}, carbon backed out of the gas leg"
            + ("." if lignite_available
               else " — unavailable (no GAS_PRICE column in this dataset).")
        )

    outputs = (fig,)
    for table in tables:
        outputs += (table["data"], table["columns"],
                    table["style_data_conditional"])
    titles = tuple(f"{HEAT_RATES[hr_fuel]['label']} table"
                   for hr_fuel in table_fuels)
    return outputs + titles + (footnote,)


# ── Tab 2: Delivered vs Forward ───────────────────────────────────────────
@callback(
    Output("cs-dvf-timeline", "figure"),
    Output("cs-dvf-heatmap", "figure"),
    Input("cs-dvf-country", "value"),
    Input("cs-dvf-metric", "value"),
    Input("cs-eff-store", "data"),
)
def update_delivered_vs_forward(country, metric, effs):
    country = (country or "DE").upper()
    metric = (metric or "CSS").upper()
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        placeholder = _loading_placeholder()
        return placeholder, placeholder

    def build():
        if metric.startswith("HR_"):
            fuel = metric.split("_", 1)[1]
            label = f"{fuel.title()} clean heat rate"
            combo = cs_data.delivered_and_forward_hr(bundle, country, fuel)
            timeline = cs_charts.delivered_vs_forward_chart(
                combo["delivered"], combo["forward"], country, label,
                y_title="Heat rate (x)", unit="x",
                zero_line=False, bar_threshold=1.0,
            )
            matrix = cs_data.seasonality_matrix(combo["delivered"],
                                                combo["forward"])
            return timeline, cs_charts.seasonality_heatmap(
                matrix, country, label, unit="x", zmid=1.0, decimals=2)

        label = _spread_label(bundle, metric)
        combo = cs_data.delivered_and_forward(bundle, country, metric)
        timeline = cs_charts.delivered_vs_forward_chart(
            combo["delivered"], combo["forward"], country, label
        )
        matrix = cs_data.seasonality_matrix(combo["delivered"],
                                            combo["forward"])
        return timeline, cs_charts.seasonality_heatmap(matrix, country, label)

    return cs_data.cached_view(bundle, "dvf", build, country, metric)


# ── Tab: Daily Calendar ───────────────────────────────────────────────────
@callback(
    Output("cs-cal-content", "children"),
    Output("cs-cal-footnote", "children"),
    Input("cs-cal-country", "value"),
    Input("cs-cal-metric", "value"),
    Input("cs-cal-days", "value"),
    Input("cs-eff-store", "data"),
)
def update_calendar(country, metric, days, effs):
    country = (country or "DE").upper()
    metric = metric or "CSS"
    try:
        days = int(days)
    except (TypeError, ValueError):
        days = 180

    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return dcc.Graph(figure=_loading_placeholder()), ""

    return cs_data.cached_view(bundle, "calendar",
                               lambda: _calendar_view(bundle, country, metric,
                                                      days),
                               country, metric, days)


def _calendar_view(bundle, country, metric, days):
    """Calendar heatmaps + footnote for one country/metric/window."""
    daily = cs_data.daily_spot_metrics(bundle, country, days=days)
    if daily.empty:
        return dcc.Graph(figure=cs_charts.placeholder_figure(
            f"No daily spot data for {country}")), ""

    is_gb = country == "GB"
    gas_eff = cs_data.spread_eff(bundle, country, "gas")
    coal_eff = cs_data.spread_eff(bundle, country, "coal")
    lignite_eff = cs_data.spread_eff(bundle, country, "lignite")
    fmt = {
        "gas_hub": "NBP" if is_gb else "TTF",
        "carbon_hub": "UKA + CPS" if is_gb else "EUA",
        "eff": _pct(gas_eff),
        "coal_eff": _pct(coal_eff),
        "lignite_eff": _pct(lignite_eff),
    }

    metric_keys = CAL_METRIC_ORDER if metric == "ALL" else [metric]
    graphs = []
    for key in metric_keys:
        if key not in daily.columns or daily[key].dropna().empty:
            continue
        title_tpl, colorscale, reverse, decimals = CAL_METRICS[key]
        fig = cs_charts.calendar_heatmap(
            daily[key], title_tpl.format(**fmt),
            colorscale=colorscale, reversescale=reverse, decimals=decimals,
        )
        graphs.append(dcc.Graph(
            figure=fig,
            config={"displayModeBar": False},
            style={"marginBottom": "14px"},
        ))

    if not graphs:
        return dcc.Graph(figure=cs_charts.placeholder_figure(
            f"No calendar metrics available for {country}")), ""

    last_day = daily.index.max()
    footnote = (
        f"Spot outturn through {last_day:%d %b %Y}. Daily power = mean of "
        "hourly spot; fuels forward-filled up to 5 days over non-trading "
        "days. "
        + ("GB: NBP and UKA + \u00a318 CPS converted to EUR at daily "
           "EURGBP. " if is_gb else "")
        + f"Gas eff {_pct(gas_eff)}, coal eff {_pct(coal_eff)}, lignite "
        f"eff {_pct(lignite_eff)}. "
        + "Coal shown in API2 $/t (CDS uses the EUR/MWh conversion at "
        "6.97 t/MWh)."
    )
    return graphs, footnote


# ── Tab 3: Contract History ───────────────────────────────────────────────
@callback(
    Output("cs-hist-chart", "figure"),
    Input("cs-hist-country", "value"),
    Input("cs-hist-metric", "value"),
    Input("cs-hist-tenor", "value"),
    Input("cs-hist-days", "value"),
    Input("cs-hist-envelope", "value"),
    Input("cs-eff-store", "data"),
)
def update_contract_history(country, metric, tenor, days, envelope, effs):
    country = (country or "DE").upper()
    metric = (metric or "CSS").upper()
    tenor = tenor or "Q1"
    show_env = "ENV" in (envelope or [])
    if days == "ALL":
        max_days = None
    else:
        try:
            max_days = int(days)
        except (TypeError, ValueError):
            max_days = 365

    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return _loading_placeholder()

    return cs_data.cached_view(
        bundle, "history",
        lambda: _contract_history_view(bundle, country, metric, tenor,
                                       max_days, show_env),
        country, metric, tenor, max_days, show_env)


@callback(
    Output("cs-hist-days", "value"),
    Input("cs-hist-tenor", "value"),
    State("cs-hist-days", "value"),
    prevent_initial_call=True,
)
def widen_lookback_for_cal(tenor, days):
    """Cal strips list 2-4 years out, so a 365d window hides the back cals."""
    if tenor != "CAL" or days == "ALL":
        return dash.no_update
    try:
        if int(days) >= 1095:
            return dash.no_update
    except (TypeError, ValueError):
        pass
    return "1095"


def _contract_history_view(bundle, country, metric, tenor, max_days,
                           show_env):
    """Contract-history overlays for one metric/tenor."""
    # Heat-rate metrics (HR_GAS / HR_COAL / HR_LIGNITE)
    if metric.startswith("HR_"):
        fuel = metric[3:]
        overlays = cs_data.heat_rate_overlays(bundle, country, fuel, tenor,
                                              max_days=max_days)
        strips = {}
        if not overlays.empty:
            strips = cs_data.delivered_heat_rate_strips(
                bundle, country, fuel, tenor, overlays["Year"].unique())
        return cs_charts.contract_history_chart(
            overlays, {y: s["ratio"] for y, s in strips.items()},
            country, tenor,
            HEAT_RATES[fuel]["label"],
            y_title="Heat rate (x)", value_suffix="x", zero_line=False,
            show_envelope=show_env,
            delivered_band={y: s["daily_mean"] for y, s in strips.items()},
        )

    raw = bundle.get(METRICS[metric]["source"])
    col = f"{METRICS[metric]['prefix']}_MID_EFF"
    overlays = cs_data.contract_overlays(raw, country, col, tenor,
                                         max_days=max_days)

    delivered_by_year: dict[int, float] = {}
    if not overlays.empty:
        for year in overlays["Year"].unique():
            value = cs_data.delivered_strip_value(
                bundle, country, tenor, int(year), metric)
            if value is not None:
                delivered_by_year[int(year)] = value

    return cs_charts.contract_history_chart(
        overlays, delivered_by_year, country, tenor,
        _spread_label(bundle, metric), show_envelope=show_env,
    )


# ── Tab 4: UK Focus ───────────────────────────────────────────────────────
@callback(
    Output("cs-uk-hedge-output", "children"),
    Input("cs-uk-mw", "value"),
    Input("cs-uk-season", "value"),
)
def update_uk_hedge(mw, season):
    try:
        mw = float(mw)
    except (TypeError, ValueError):
        mw = 0.0
    season = season or "Winter"
    result = cs_data.hedge_uka(mw, season)

    row_style = {"display": "flex", "justifyContent": "space-between",
                 "fontSize": "13px", "padding": "4px 0",
                 "borderBottom": f"1px solid {COLORS['border_light']}"}
    value_style = {"fontWeight": "600", "color": COLORS["text_primary"]}

    return html.Div([
        html.Div(style=row_style, children=[
            html.Span(f"{season} hours"),
            html.Span(f"{result['hours']:,}", style=value_style),
        ]),
        html.Div(style=row_style, children=[
            html.Span("Power volume"),
            html.Span(f"{result['power_mwh']:,.0f} MWh", style=value_style),
        ]),
        html.Div(style=row_style, children=[
            html.Span("CO2 to hedge"),
            html.Span(f"{result['tonnes']:,.0f} t", style=value_style),
        ]),
        html.Div(style=row_style, children=[
            html.Span(f"UKA lots ({UKA_LOT_TONNES:,.0f} t/lot)"),
            html.Span(f"{result['lots']:,.1f} lots",
                      style={**value_style, "color": COLORS["accent"]}),
        ]),
        html.Div(style=row_style, children=[
            html.Span("Gas leg (49.13% eff)"),
            html.Span(f"{result['gas_mwh']:,.0f} MWh "
                      f"(\u2248 {result['therms'] / 1e6:,.2f}m therms)",
                      style=value_style),
        ]),
    ])


# ── Tab: HR vs Fundamentals ────────────────────────────────────────────────
@callback(
    Output("cs-fund-grid", "figure"),
    Output("cs-fund-summary", "children"),
    Input("cs-tabs", "active_tab"),
    Input("cs-fund-country", "value"),
    Input("cs-fund-var", "value"),
    Input("cs-fund-years", "value"),
    Input("cs-fund-opts", "value"),
)
def update_fund_regression(active_tab, country, var, years, opts):
    if active_tab != "fundamentals":
        # Don't touch S3 climate panels until the tab is opened
        return cs_charts.placeholder_figure(
            "Open the HR vs Fundamentals tab"), ""

    country = (country or "DE").upper()
    var = (var or "RESIDUAL_LOAD").upper()
    years = [int(y) for y in (years or [])]
    opts = opts or []

    bundle = cs_data.get_bundle()
    if not bundle:
        return _loading_placeholder(), ""

    try:
        view = cs_fundamentals.build_regression_view(
            bundle, country, var, years,
            pool_adjacent="POOL" in opts,
            year_fe="FE" in opts,
        )
    except Exception:
        logger.exception("HR vs Fundamentals view failed for %s/%s",
                         country, var)
        return cs_charts.placeholder_figure(
            f"Failed to build regression view for {country}"), ""

    fig = cs_charts.hr_fundamentals_grid(view, country)
    summary = _fund_summary_table(view)
    return fig, summary


def _fund_summary_table(view: dict):
    """Per-month table: market fwd HR vs weather-year model distribution."""
    rows = []
    for month in range(1, 13):
        fit = view["fits"].get(month)
        dist = view.get("dist", {}).get(month)
        mkt = view["market"].get(month)
        target = view["targets"][month]
        label = f"{MONTH_ABBR[month].title()}-{target}"
        if fit is None or dist is None:
            rows.append({"Month": label, "Market HR": _fmt(mkt),
                         "Model median": "-", "P10": "-", "P25": "-",
                         "P75": "-", "P90": "-", "Gap": "-", "R2": "-",
                         "Days": "-"})
            continue
        gap = (dist["median"] - mkt["value"]) if mkt else None
        rows.append({
            "Month": label,
            "Market HR": _fmt(mkt),
            "Model median": f"{dist['median']:.3f}",
            "P10": f"{dist['p10']:.3f}",
            "P25": f"{dist['p25']:.3f}",
            "P75": f"{dist['p75']:.3f}",
            "P90": f"{dist['p90']:.3f}",
            "Gap": f"{gap:+.3f}" if gap is not None else "-",
            "R2": f"{fit['r2']:.2f}",
            "Days": str(fit["n"]),
        })

    header = html.Thead(html.Tr([
        html.Th(col, style={"fontSize": "12px", "padding": "6px 12px"})
        for col in rows[0].keys()
    ]))
    body = html.Tbody([
        html.Tr([
            html.Td(row[col], style={"fontSize": "12px",
                                     "padding": "5px 12px"})
            for col in row.keys()
        ]) for row in rows
    ])
    return html.Table([header, body], style={"width": "100%"})


def _fmt(mkt: dict | None) -> str:
    return f"{mkt['value']:.3f} ({mkt['strip']})" if mkt else "-"


@callback(
    Output("cs-uk-curve-chart", "figure"),
    Output("cs-uk-history-chart", "figure"),
    Output("cs-uk-diagnostic", "children"),
    Input("cs-tabs", "active_tab"),
    Input("cs-eff-store", "data"),
)
def update_uk_charts(active_tab, effs):
    if active_tab != "uk":
        # Cheap no-op figures until the tab is opened
        placeholder = cs_charts.placeholder_figure("Open the UK Focus tab")
        return placeholder, placeholder, ""

    bundle = cs_data.get_bundle(effs)
    if not bundle:
        placeholder = _loading_placeholder()
        return placeholder, placeholder, ""

    curve = cs_data.uk_market_curve(bundle)
    monthly_uk = cs_data.expand_curve_monthly(curve, "CSS_UK_MKT")
    seasons = cs_data.uk_season_strips(monthly_uk)
    curve_fig = cs_charts.uk_curve_chart(curve, seasons)

    delivered_gb = cs_data.delivered_monthly(
        bundle.get("delivered_spreads"), "GB")
    history_fig = cs_charts.uk_history_chart(monthly_uk, delivered_gb)

    diag = cs_data.uk_cps_diagnostic(bundle)
    diag_text = ""
    if diag:
        diag_text = (
            f"CPS diagnostic \u2014 implied fuel+carbon cost (front strip): "
            f"{diag['implied_x']:.2f} \u20ac/MWh fuel; direct spot calc with "
            f"CPS: {diag['direct_x_cps']:.2f}; without CPS: "
            f"{diag['direct_x_no_cps']:.2f} (EURGBP {diag['eurgbp']:.4f}). "
            f"{diag['verdict']}"
        )
        if not diag.get("consistent", True):
            # The GB legs do not reconcile with NBP + UKA: say so loudly
            # rather than presenting the curve as a market view.
            return curve_fig, history_fig, _leg_warning(diag, diag_text)
    # Algebra sanity: re-efficiency at 50% must reproduce CSS_MID_EFF.
    # Only meaningful while the gas input is at its 50% default -- a typed
    # efficiency has already rewritten CSS_MID_EFF.
    if (not curve.empty
            and cs_data.bundle_effs(bundle).get("gas_default")
            and {"CSS_MID_CHECK", "CSS_MID_EFF"}.issubset(curve.columns)):
        gap = float((curve["CSS_MID_CHECK"] - curve["CSS_MID_EFF"]).abs().max())
        if gap > 0.05:
            diag_text += (
                f" WARNING: re-efficiency check off by up to {gap:.2f} "
                "\u20ac/MWh \u2014 precomputed GB efficiencies may not be "
                "0.48/0.50/0.52."
            )
            logger.warning("clean_spreads UK re-efficiency check gap=%.3f", gap)

    return curve_fig, history_fig, diag_text


# ── Shared: pack-metric labels/units ────────────────────────────────────────
def _pack_metric_info(metric, effs=None) -> tuple[str, str, str]:
    """(label, unit, table_mode) for CSS/CDS/CLS/HR_* pack metrics.

    Spread labels carry the efficiency they are priced at when ``effs``
    (the page store or a normalized dict) is supplied.
    """
    metric = (metric or "CSS").upper()
    if metric.startswith("HR_"):
        return HEAT_RATES[metric[3:]]["label"], "x", "heat_rate"
    spec = METRICS[metric]
    label = spec["label"]
    if effs is not None:
        eff = cs_data.normalize_effs(effs)[spec["fuel"]]
        label = f"{label} @ {_pct(eff)} eff"
    return label, "€/MWh", "spread"


def _spread_label(bundle, metric) -> str:
    """Spread label with the efficiency carried on a bundle view."""
    return _pack_metric_info(metric, cs_data.bundle_effs(bundle))[0]


# ── Shared: compact html table for analytics summaries ─────────────────────
def _html_table(rows: list[dict]):
    if not rows:
        return html.Div("No data", style={"fontSize": "12px",
                                          "color": COLORS["text_muted"]})
    header = html.Thead(html.Tr([
        html.Th(col, style={"fontSize": "12px", "padding": "6px 12px"})
        for col in rows[0].keys()
    ]))
    body = html.Tbody([
        html.Tr([
            html.Td(row[col], style={"fontSize": "12px",
                                     "padding": "5px 12px"})
            for col in row.keys()
        ]) for row in rows
    ])
    return html.Table([header, body], style={"width": "100%"})


# ── Curve Snapshot: weekly curve ridge ──────────────────────────────────────
@callback(
    Output("cs-snap-ridge", "figure"),
    Input("cs-tabs", "active_tab"),
    Input("cs-snap-country", "value"),
    Input("cs-eff-store", "data"),
)
def update_curve_ridge(active_tab, country, effs):
    if active_tab != "snapshot":
        return cs_charts.placeholder_figure("Open the Curve Snapshot tab")
    country = (country or "DE").upper()
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return _loading_placeholder()

    def build():
        # One country slice for all 13 snapshots: re-slicing the raw frame
        # per as-of was the whole cost of this view.
        flat = cs_data._country_frame(bundle.get("CSS_raw"), country)
        col = "CSS_MID_EFF"
        latest = cs_data.curve_from_flat(flat, [col])
        if latest.empty:
            return cs_charts.placeholder_figure(
                f"No curve data for {country}")
        curve_date = pd.Timestamp(latest["DATE"].iloc[0])

        snapshots = []
        seen_dates = set()
        for weeks_back in range(12, 0, -1):
            asof = curve_date - pd.Timedelta(weeks=weeks_back)
            curve = cs_data.curve_from_flat(flat, [col], asof=asof)
            if curve.empty:
                continue
            snap_date = pd.Timestamp(curve["DATE"].iloc[0])
            if snap_date in seen_dates:
                continue
            seen_dates.add(snap_date)
            snapshots.append((snap_date, curve))
        snapshots.append((curve_date, latest))
        gas_eff = cs_data.bundle_effs(bundle)["gas"]
        return cs_charts.curve_ridge(snapshots, country, col,
                                     f"CSS @ {_pct(gas_eff)} (€/MWh)")

    return cs_data.cached_view(bundle, "ridge", build, country)


# ── Tab: Screener ───────────────────────────────────────────────────────────
@callback(
    Output("cs-scr-table", "data"),
    Output("cs-scr-table", "columns"),
    Output("cs-scr-table", "style_data_conditional"),
    Output("cs-rv-matrix", "figure"),
    Input("cs-tabs", "active_tab"),
    Input("cs-scr-metric", "value"),
    Input("cs-rv-type", "value"),
    Input("cs-eff-store", "data"),
)
def update_screener(active_tab, metric, rv_type, effs):
    empty = make_screener_table(pd.DataFrame())
    if active_tab != "screener":
        return (empty["data"], empty["columns"],
                empty["style_data_conditional"],
                cs_charts.placeholder_figure("Open the Screener tab"))
    metric = metric or "CSS"
    label, unit, mode = _pack_metric_info(metric, effs)
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return (empty["data"], empty["columns"],
                empty["style_data_conditional"], _loading_placeholder())

    def build():
        table = make_screener_table(
            cs_analytics.screener(bundle, COUNTRIES, metric), mode=mode)
        rv = cs_analytics.rv_matrix(bundle, COUNTRIES, metric,
                                    rv_type or "QUARTERLY")
        fig = cs_charts2.rv_matrix_heatmap(
            rv, label, unit=unit, decimals=2 if mode == "heat_rate" else 1)
        return (table["data"], table["columns"],
                table["style_data_conditional"], fig)

    return cs_data.cached_view(bundle, "screener", build, metric, rv_type)


# ── Tab: Carbon & Scenarios ─────────────────────────────────────────────────
@callback(
    Output("cs-scen-strip", "options"),
    Output("cs-scen-strip", "value"),
    Input("cs-tabs", "active_tab"),
    Input("cs-carb-country", "value"),
    State("cs-scen-strip", "value"),
)
def populate_scenario_strips(active_tab, country, current):
    if active_tab != "carbon":
        return dash.no_update, dash.no_update
    bundle = cs_data.get_bundle()
    strips = cs_analytics.curve_strips(bundle, (country or "DE").upper()) \
        if bundle else []
    options = [{"label": s, "value": s} for s in strips]
    value = current if current in strips else (strips[0] if strips else None)
    return options, value


@callback(
    Output("cs-carb-chart", "figure"),
    Output("cs-scen-grid", "figure"),
    Input("cs-tabs", "active_tab"),
    Input("cs-carb-country", "value"),
    Input("cs-scen-strip", "value"),
    Input("cs-eff-store", "data"),
)
def update_carbon(active_tab, country, strip, effs):
    if active_tab != "carbon":
        placeholder = cs_charts.placeholder_figure(
            "Open the Carbon & Scenarios tab")
        return placeholder, placeholder
    country = (country or "DE").upper()
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return _loading_placeholder(), _loading_placeholder()

    switching = cs_analytics.switching_carbon_curve(bundle, country)
    carb_fig = cs_charts2.switching_carbon_chart(switching, country)

    scen = cs_analytics.scenario_grid(bundle, country, strip or "")
    scen_fig = cs_charts2.scenario_heatmap(scen, country)
    return carb_fig, scen_fig


# ── Tab: Risk Premium ───────────────────────────────────────────────────────
@callback(
    Output("cs-prem-chart", "figure"),
    Output("cs-prem-summary", "children"),
    Input("cs-tabs", "active_tab"),
    Input("cs-prem-country", "value"),
    Input("cs-prem-metric", "value"),
    Input("cs-eff-store", "data"),
)
def update_premium(active_tab, country, metric, effs):
    if active_tab != "premium":
        return cs_charts.placeholder_figure(
            "Open the Risk Premium tab"), ""
    country = (country or "DE").upper()
    metric = metric or "CSS"
    label, unit, mode = _pack_metric_info(metric, effs)
    mean_fmt = "+.3f" if mode == "heat_rate" else "+.2f"
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return _loading_placeholder(), ""

    def build():
        premiums = cs_analytics.risk_premium(bundle, country, metric)
        fig = cs_charts2.risk_premium_chart(premiums, country,
                                            metric_label=label, unit=unit)

        summary = cs_analytics.risk_premium_summary(premiums)
        rows = []
        for _, srow in summary.iterrows():
            row = {"Month": MONTH_ABBR[int(srow["month_num"])],
                   "Years": int(srow["n"])}
            for k in (30, 60, 90):
                mean = srow.get(f"mean_{k}")
                hit = srow.get(f"hit_{k}")
                row[f"D-{k} mean"] = f"{mean:{mean_fmt}}" \
                    if pd.notna(mean) else "-"
                row[f"D-{k} hit%"] = f"{hit:.0f}%" if pd.notna(hit) else "-"
            rows.append(row)
        return fig, _html_table(rows)

    return cs_data.cached_view(bundle, "premium", build, country, metric)


# ── Tab: Vol & Betas ────────────────────────────────────────────────────────
@callback(
    Output("cs-vb-cone", "figure"),
    Output("cs-vb-betas", "figure"),
    Input("cs-tabs", "active_tab"),
    Input("cs-vb-country", "value"),
    Input("cs-vb-tenor", "value"),
    Input("cs-vb-metric", "value"),
    Input("cs-eff-store", "data"),
)
def update_volbeta(active_tab, country, tenor, metric, effs):
    if active_tab != "volbeta":
        placeholder = cs_charts.placeholder_figure(
            "Open the Vol & Betas tab")
        return placeholder, placeholder
    country = (country or "DE").upper()
    tenor = tenor or "Q1"
    metric = metric or "CSS"
    label, unit, _mode = _pack_metric_info(metric, effs)
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return _loading_placeholder(), _loading_placeholder()

    def build():
        cone = cs_analytics.vol_cone(bundle, country, tenor, metric=metric)
        cone_fig = cs_charts2.vol_cone_chart(cone, country, tenor,
                                             metric_label=label, unit=unit)
        betas = cs_analytics.rolling_betas(bundle, country, tenor)
        return cone_fig, cs_charts2.betas_chart(betas, country, tenor)

    return cs_data.cached_view(bundle, "volbeta", build, country, tenor,
                               metric)


@callback(
    Output("cs-vb-strip", "options"),
    Output("cs-vb-strip", "value"),
    Input("cs-tabs", "active_tab"),
    Input("cs-vb-country", "value"),
    State("cs-vb-strip", "value"),
)
def populate_hedge_strips(active_tab, country, current):
    if active_tab != "volbeta":
        return dash.no_update, dash.no_update
    bundle = cs_data.get_bundle()
    strips = cs_analytics.curve_strips(bundle, (country or "DE").upper()) \
        if bundle else []
    options = [{"label": s, "value": s} for s in strips]
    value = current if current in strips else (strips[0] if strips else None)
    return options, value


@callback(
    Output("cs-vb-hedge", "children"),
    Input("cs-tabs", "active_tab"),
    Input("cs-vb-country", "value"),
    Input("cs-vb-strip", "value"),
    Input("cs-vb-mw", "value"),
    Input("cs-eff-store", "data"),
)
def update_hedge_card(active_tab, country, strip, mw, effs):
    if active_tab != "volbeta":
        return ""
    country = (country or "DE").upper()
    try:
        mw = float(mw)
    except (TypeError, ValueError):
        mw = 0.0
    bundle = cs_data.get_bundle(effs)
    if not bundle or not strip:
        return ""
    hedge = cs_analytics.hedge_ratios(bundle, country, strip, mw)
    if not hedge:
        return html.Div("No curve data",
                        style={"fontSize": "12px",
                               "color": COLORS["text_muted"]})
    rows = [{
        "Contract": hedge["strip"],
        "Hours": f"{hedge['hours']:,.0f}",
        "Power (MWh)": f"{hedge['power_mwh']:,.0f}",
        f"Gas (MWh @ \u03b7={hedge['eff']:.4g})":
            f"{hedge['gas_mwh']:,.0f}",
        "Carbon (t)": f"{hedge['carbon_tonnes']:,.0f}",
        f"{hedge['carbon_unit']} lots": f"{hedge['carbon_lots']:,.1f}",
    }]
    children = [_html_table(rows)]
    extras = []
    if "gas_price" in hedge:
        extras.append(f"Implied legs: gas {hedge['gas_price']:.2f} €/MWh, "
                      f"carbon {hedge['carbon_price']:.2f} €/t.")
    if "cps_note" in hedge:
        extras.append(hedge["cps_note"])
    if extras:
        children.append(html.P(" ".join(extras),
                               style={"fontSize": "11px",
                                      "color": COLORS["text_muted"],
                                      "margin": "8px 0 0 0"}))
    return html.Div(children)


# ── Tab: Shape & Strips ─────────────────────────────────────────────────────
@callback(
    Output("cs-shape-capture", "figure"),
    Output("cs-shape-strips", "figure"),
    Output("cs-shape-rolldown", "children"),
    Input("cs-tabs", "active_tab"),
    Input("cs-shape-country", "value"),
    Input("cs-shape-metric", "value"),
    Input("cs-eff-store", "data"),
)
def update_shape(active_tab, country, metric, effs):
    if active_tab != "shape":
        placeholder = cs_charts.placeholder_figure(
            "Open the Shape & Strips tab")
        return placeholder, placeholder, ""
    country = (country or "DE").upper()
    metric = metric or "CSS"
    label, unit, mode = _pack_metric_info(metric, effs)
    value_fmt = ".3f" if mode == "heat_rate" else ".2f"
    change_fmt = "+.3f" if mode == "heat_rate" else "+.2f"
    bundle = cs_data.get_bundle(effs)
    if not bundle:
        return _loading_placeholder(), _loading_placeholder(), ""

    def build():
        capture = cs_analytics.hourly_capture(bundle, country)
        capture_fig = cs_charts2.capture_heatmap(capture, country)

        strips = cs_analytics.season_strips(bundle, country, metric)
        winsum = cs_analytics.winsum_spreads(strips)
        strips_fig = cs_charts2.strips_chart(strips, winsum, country,
                                             metric_label=label, unit=unit)

        roll = cs_analytics.rolldown_table(bundle, country, metric)
        rows = [{
            "Strip": r["STRIP"],
            "Type": str(r["CONTRACT_TYPE"]).title(),
            f"Outright ({unit})": f"{r['Outright']:{value_fmt}}",
            "Nearer contract": (f"{r['NearerValue']:{value_fmt}}"
                                if pd.notna(r["NearerValue"]) else "-"),
            "Rolldown": (f"{r['Rolldown']:{change_fmt}}"
                         if pd.notna(r["Rolldown"]) else "-"),
        } for _, r in roll.iterrows()] if not roll.empty else []
        return capture_fig, strips_fig, _html_table(rows)

    return cs_data.cached_view(bundle, "shape", build, country, metric)
