"""Clean Spark / Clean Dark Spreads page package.

Modules:
    constants -- page wiring, efficiencies, UK market conventions
    data      -- curve building, change snapshots, UK 49.13% re-efficiency,
                 delivered + forward merges, hedge-ratio math
    tables    -- DoD/WoW/MoM heat-shaded change table
    charts    -- forward curve, delivered-vs-forward timeline, seasonality
                 heatmap, contract history, UK focus figures
    layout    -- build_layout() with 4 sub-tabs
    callbacks -- registered on import
"""
