"""Figures for the Clean Spreads trader-pack tabs."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from core.clean_spreads.charts import _base_layout, placeholder_figure
from core.clean_spreads.constants import (
    CSS_COLOR,
    CDS_COLOR,
    FORWARD_COLOR,
    MONTH_ABBR,
    UK_MKT_COLOR,
)
from core.styles import COLORS

_CARBON_COLOR = "#6a3d9a"
_SWITCH_COLOR = "#e08214"


# ── RV matrix ───────────────────────────────────────────────────────────────
def rv_matrix_heatmap(result: dict, metric_label: str,
                      unit: str = "€/MWh",
                      decimals: int = 1) -> go.Figure:
    if not result:
        return placeholder_figure("Not enough overlapping contract history "
                                  "for the RV matrix")
    diff: pd.DataFrame = result["diff"]
    zmat: pd.DataFrame = result["z"]
    names = result["countries"]

    text = np.empty(diff.shape, dtype=object)
    for i, a in enumerate(names):
        for j, b in enumerate(names):
            d, z = diff.iloc[i, j], zmat.iloc[i, j]
            text[i, j] = "" if pd.isna(d) \
                else f"{d:+.{decimals}f}<br>({z:+.1f}z)"

    fig = go.Figure(go.Heatmap(
        z=zmat.values.astype(float),
        x=names, y=names,
        colorscale="RdBu", zmid=0, reversescale=True,
        text=text, texttemplate="%{text}", textfont=dict(size=10),
        hovertemplate=("%{y} minus %{x}: z=%{z:.2f}<extra></extra>"),
        colorbar=dict(title="z", thickness=12),
        xgap=2, ygap=2,
    ))
    fig.update_layout(**_base_layout(
        f"Cross-country {metric_label} RV \u2014 front {result['strip']} "
        f"(row minus column, cell = diff {unit} and 1y z-score)",
        height=90 + 62 * len(names)))
    fig.update_layout(hovermode="closest")
    fig.update_yaxes(autorange="reversed", type="category")
    fig.update_xaxes(type="category", side="top")
    return fig


# ── Switching carbon ────────────────────────────────────────────────────────
def switching_carbon_chart(df: pd.DataFrame, country: str) -> go.Figure:
    if df is None or df.empty:
        return placeholder_figure(f"No switching-carbon data for {country}")
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["STRIP"], y=df["implied_carbon"],
        mode="lines+markers", name="Implied EUA (from gas leg)",
        line=dict(color=_CARBON_COLOR, width=2.4), marker=dict(size=6),
        hovertemplate="%{x}: EUA %{y:.1f} €/t<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=df["STRIP"], y=df["switching_carbon"],
        mode="lines+markers", name="Switching price C* (gas=coal)",
        line=dict(color=_SWITCH_COLOR, width=2.4, dash="dash"),
        marker=dict(size=6),
        hovertemplate="%{x}: C* %{y:.1f} €/t<extra></extra>",
    ))
    # Shade the gap where gas is in merit (carbon above switching)
    merit = df["implied_carbon"] > df["switching_carbon"]
    fig.add_trace(go.Scatter(
        x=df["STRIP"], y=np.where(merit, df["implied_carbon"], np.nan),
        mode="markers", marker=dict(size=11, symbol="circle-open",
                                    color=CSS_COLOR, line=dict(width=2)),
        name="Gas in merit",
        hoverinfo="skip",
    ))
    fig.update_layout(**_base_layout(
        f"Coal\u2194gas switching carbon price \u2014 {country} "
        "(EUA above C* \u21d2 gas in merit)", height=470))
    fig.update_yaxes(title="€/t CO2")
    fig.update_xaxes(title="Contract")
    return fig


# ── Scenario grid ───────────────────────────────────────────────────────────
def scenario_heatmap(result: dict, country: str) -> go.Figure:
    if not result:
        return placeholder_figure(f"No scenario data for {country}")
    grid: pd.DataFrame = result["grid"]
    base = result["base"]
    text = np.round(grid.values, 1).astype(str)

    fig = go.Figure(go.Heatmap(
        z=grid.values,
        x=[f"{g:+.0f}" if g else "0" for g in grid.columns],
        y=[f"{c:+.0f}" if c else "0" for c in grid.index],
        colorscale="RdYlGn", zmid=0,
        text=text, texttemplate="%{text}", textfont=dict(size=11),
        hovertemplate=("gas %{x} €/MWh, carbon %{y} €/t: "
                       "CSS %{z:.2f} €/MWh<extra></extra>"),
        colorbar=dict(title="€/MWh", thickness=12),
        xgap=2, ygap=2,
    ))
    fig.update_layout(**_base_layout(
        f"{result['strip']} CSS under gas x carbon shocks \u2014 {country} "
        f"(base: P {base['power']:.1f}, gas {base['gas']:.1f}, "
        f"EUA {base['carbon']:.1f}, \u03b7 {base['eff']:.4g}, "
        f"CSS {base['css']:.2f}; power held fixed)",
        height=440))
    fig.update_layout(hovermode="closest")
    fig.update_xaxes(title="Gas shock (€/MWh)", type="category")
    fig.update_yaxes(title="Carbon shock (€/t)", type="category")
    return fig


# ── Risk premium ────────────────────────────────────────────────────────────
def risk_premium_chart(premiums: pd.DataFrame, country: str,
                       metric_label: str = "CSS",
                       unit: str = "€/MWh",
                       lookbacks: tuple[int, ...] = (30, 60, 90)
                       ) -> go.Figure:
    if premiums is None or premiums.empty:
        return placeholder_figure(f"No delivered history for {country}")
    palette = {30: FORWARD_COLOR, 60: UK_MKT_COLOR, 90: CDS_COLOR}
    fig = go.Figure()
    for k in lookbacks:
        col = f"prem_{k}"
        if col not in premiums.columns:
            continue
        sub = premiums.dropna(subset=[col])
        fig.add_trace(go.Box(
            x=[MONTH_ABBR[m] for m in sub["month_num"]],
            y=sub[col],
            name=f"D-{k}",
            marker_color=palette.get(k, "#666666"),
            boxpoints="all", jitter=0.4, pointpos=0,
            marker=dict(size=4, opacity=0.6),
            customdata=sub["year"],
            hovertemplate=(f"%{{x}} %{{customdata}}: %{{y:+.2f}} {unit}"
                           f" (D-{k})<extra></extra>"),
        ))
    fig.add_hline(y=0, line_width=1, line_color="#666666")
    fig.update_layout(**_base_layout(
        f"Forward risk premium \u2014 {country} "
        f"(forward {metric_label} at D-k minus delivered outturn; "
        "positive = market overpriced the month)", height=520))
    fig.update_layout(boxmode="group", hovermode="closest")
    fig.update_xaxes(categoryorder="array",
                     categoryarray=[MONTH_ABBR[m] for m in range(1, 13)],
                     title="Delivery month")
    fig.update_yaxes(title=f"Premium ({unit})")
    return fig


# ── Volatility cone ─────────────────────────────────────────────────────────
def vol_cone_chart(result: dict, country: str, period: str,
                   metric_label: str = "CSS",
                   unit: str = "€/MWh") -> go.Figure:
    if not result or result.get("cone") is None or result["cone"].empty:
        return placeholder_figure(
            f"Not enough contract history for a {period} vol cone")
    cone: pd.DataFrame = result["cone"]
    cur: pd.DataFrame = result.get("current", pd.DataFrame())

    fig = go.Figure()
    band_color = "rgba(31, 119, 180, {a})"
    fig.add_trace(go.Scatter(
        x=cone["dtd"], y=cone["p90"], mode="lines",
        line=dict(width=0), showlegend=False, hoverinfo="skip"))
    fig.add_trace(go.Scatter(
        x=cone["dtd"], y=cone["p10"], mode="lines", line=dict(width=0),
        fill="tonexty", fillcolor=band_color.format(a=0.12),
        name="P10-P90", hoverinfo="skip"))
    fig.add_trace(go.Scatter(
        x=cone["dtd"], y=cone["p75"], mode="lines",
        line=dict(width=0), showlegend=False, hoverinfo="skip"))
    fig.add_trace(go.Scatter(
        x=cone["dtd"], y=cone["p25"], mode="lines", line=dict(width=0),
        fill="tonexty", fillcolor=band_color.format(a=0.25),
        name="P25-P75", hoverinfo="skip"))
    fig.add_trace(go.Scatter(
        x=cone["dtd"], y=cone["p50"], mode="lines",
        line=dict(color="#1f77b4", width=1.8, dash="dot"),
        name="Median (history)",
        hovertemplate="DTD %{x}: %{y:.2f}<extra>median</extra>"))
    if cur is not None and not cur.empty:
        fig.add_trace(go.Scatter(
            x=cur["DAYS_TO_DELIVERY"], y=cur["vol"],
            mode="lines", name=f"Live contract ({result['current_year']})",
            line=dict(color=CDS_COLOR, width=2.6),
            hovertemplate="DTD %{x}: %{y:.2f}<extra>live</extra>"))
    fig.update_layout(**_base_layout(
        f"{period} {metric_label} realized vol cone \u2014 {country} "
        f"(20d vol of daily changes, annualized {unit})", height=470))
    fig.update_xaxes(title="Days to delivery", autorange="reversed")
    fig.update_yaxes(title=f"Realized vol ({unit}, ann.)")
    return fig


# ── Rolling betas ───────────────────────────────────────────────────────────
def betas_chart(betas: pd.DataFrame, country: str,
                period: str) -> go.Figure:
    if betas is None or betas.empty:
        return placeholder_figure(
            f"Not enough front-{period} history for rolling betas")
    strip = betas["STRIP"].iloc[-1]
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=betas["DATE"], y=betas["BETA_GAS"], mode="lines",
        name="\u03b2 gas (per €/MWh TTF)",
        line=dict(color="#2171b5", width=2.2),
        hovertemplate="%{x|%d %b %y}: %{y:.2f}<extra>gas</extra>"))
    fig.add_trace(go.Scatter(
        x=betas["DATE"], y=betas["BETA_CARBON"], mode="lines",
        name="\u03b2 carbon (per €/t EUA)",
        line=dict(color=_CARBON_COLOR, width=2.2),
        hovertemplate="%{x|%d %b %y}: %{y:.3f}<extra>carbon</extra>"))
    fig.add_trace(go.Scatter(
        x=betas["DATE"], y=betas["R2"], mode="lines", name="R\u00b2",
        line=dict(color="#999999", width=1.2, dash="dot"), yaxis="y2",
        hovertemplate="%{x|%d %b %y}: %{y:.2f}<extra>R2</extra>"))
    fig.add_hline(y=0, line_width=1, line_color="#666666")
    layout = _base_layout(
        f"Rolling 60d betas of {strip} CSS changes \u2014 {country} "
        "(theoretical: \u03b2 gas = -1/\u03b7 = -2.0, "
        "\u03b2 carbon = -EF/\u03b7 = -0.36)", height=470)
    fig.update_layout(**layout)
    fig.update_layout(yaxis2=dict(overlaying="y", side="right",
                                  range=[0, 1], showgrid=False,
                                  title="R\u00b2"))
    fig.update_yaxes(title="Beta")
    return fig


# ── Hourly capture ──────────────────────────────────────────────────────────
def capture_heatmap(result: dict, country: str) -> go.Figure:
    if not result or result.get("pivot") is None or result["pivot"].empty:
        return placeholder_figure(f"No hourly spot data for {country}")
    pivot: pd.DataFrame = result["pivot"]
    monthly: pd.DataFrame = result["monthly"]
    months = [str(m) for m in pivot.columns]

    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=months, y=[f"{h:02d}" for h in pivot.index],
        colorscale="RdYlGn", zmid=0,
        hovertemplate=("%{x} h%{y}: CSS %{z:.1f} €/MWh<extra></extra>"),
        colorbar=dict(title="€/MWh", thickness=12),
    ))
    # Capture-factor annotations along the top
    for _, row in monthly.iterrows():
        month_key = str(row["month"])
        if month_key in months and np.isfinite(row["capture_factor"]):
            fig.add_annotation(
                x=month_key, y=1.045,
                yref="paper", showarrow=False,
                text=f"{row['capture_factor']:.2f}x",
                font=dict(size=10, color=COLORS["text_secondary"]))
    fig.update_layout(**_base_layout(
        f"Hourly spark spread by month \u2014 {country} (spot outturn, "
        "mid eff; top row = capture factor mean(max(CSS,0)) / |baseload|)",
        height=620))
    fig.update_layout(hovermode="closest",
                      margin=dict(l=55, r=25, t=95, b=45))
    fig.update_xaxes(type="category")
    fig.update_yaxes(title="Hour of day", autorange="reversed",
                     type="category")
    return fig


# ── Season strips ───────────────────────────────────────────────────────────
def strips_chart(strips: pd.DataFrame, winsum: pd.DataFrame,
                 country: str, metric_label: str = "CSS",
                 unit: str = "€/MWh") -> go.Figure:
    if strips is None or strips.empty:
        return placeholder_figure(f"No season strips for {country}")
    colors = ["#4575b4" if s == "WIN" else "#f4a582"
              for s in strips["season"]]
    fig = go.Figure(go.Bar(
        x=strips["STRIP"], y=strips["value"], marker_color=colors,
        name=f"Strip {metric_label}",
        customdata=strips["n_months"],
        hovertemplate=(f"%{{x}}: %{{y:.2f}} {unit} "
                       "(%{customdata} months)<extra></extra>"),
    ))
    if winsum is not None and not winsum.empty:
        fig.add_trace(go.Scatter(
            x=[f"WIN-{int(y) % 100:02d}" for y in winsum["year"]],
            y=winsum["spread"], mode="markers+text",
            marker=dict(symbol="diamond", size=10, color=UK_MKT_COLOR),
            text=[f"W-S {v:+.1f}" for v in winsum["spread"]],
            textposition="top center", textfont=dict(size=10),
            name="Win\u2212Sum spread",
            hovertemplate=f"Win\u2212Sum %{{y:+.2f}} {unit}<extra></extra>",
        ))
    fig.add_hline(y=0, line_width=1, line_color="#666666")
    fig.update_layout(**_base_layout(
        f"Winter / Summer {metric_label} strips \u2014 {country}",
        height=440))
    fig.update_yaxes(title=f"{metric_label} ({unit})")
    return fig
