"""Layout for the Clean Spreads page (sub-tabs)."""
from __future__ import annotations

from datetime import date

import dash_bootstrap_components as dbc
from dash import dcc, html
from dash.dash_table import DataTable

from core.clean_spreads.constants import (
    COUNTRIES,
    DEFAULT_COUNTRY,
    EFF_DEFAULTS,
    EFF_MAX,
    EFF_MIN,
    METRICS,
    MONTH_ABBR,
    UK_CARBON_RATIO,
)
from core.clean_spreads.tables import TABLE_COLUMNS
from core.styles import COLORS

_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_LABEL = {
    "fontSize": "11px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
}

_CONTROL = {"minWidth": "160px"}

_GRAPH_CONFIG = {"displayModeBar": True, "displaylogo": False}

_TENOR_OPTIONS = (
    [{"label": MONTH_ABBR[m], "value": MONTH_ABBR[m]} for m in range(1, 13)]
    + [{"label": f"Q{q}", "value": f"Q{q}"} for q in range(1, 5)]
    + [{"label": "CAL", "value": "CAL"}]
)


def _country_dropdown(component_id: str) -> dbc.Select:
    return dbc.Select(
        id=component_id,
        options=[{"label": c, "value": c} for c in COUNTRIES],
        value=DEFAULT_COUNTRY,
        # Selections survive a reload or a redeploy: a trader should not
        # have to re-pick their zone and assumptions every morning.
        persistence=True, persistence_type="local",
        style={"fontSize": "13px"},
    )


def _metric_radio(component_id: str, include_both: bool = False) -> dcc.RadioItems:
    options = [{"label": METRICS[m]["label"], "value": m}
               for m in ("CSS", "CDS", "CLS")]
    if include_both:
        options.append({"label": "All", "value": "ALL"})
    return dcc.RadioItems(
        id=component_id,
        options=options,
        value="ALL" if include_both else "CSS",
        persistence=True, persistence_type="local",
        inline=True,
        style={"fontSize": "13px", "color": COLORS["text_primary"]},
        labelStyle={"marginRight": "16px", "cursor": "pointer"},
    )


# Trader-pack metric selector: spreads + clean heat rates
_PACK_METRIC_OPTIONS = [
    {"label": "CSS", "value": "CSS"},
    {"label": "CDS", "value": "CDS"},
    {"label": "CLS", "value": "CLS"},
    {"label": "Gas HR", "value": "HR_GAS"},
    {"label": "Coal HR", "value": "HR_COAL"},
    {"label": "Lignite HR", "value": "HR_LIGNITE"},
]


# ── Forward-curve issue date (applies to every tab) ───────────────────────
# Polled so a tab left open notices a new curve; the callback fills in the
# date, staleness colour and any country lagging the rest.
_ISSUE_POLL_MS = 60_000


def _issue_date_banner() -> html.Div:
    """Placeholder for the issue-date strip, filled by the callback."""
    return html.Div([
        dcc.Interval(id="cs-issue-poll", interval=_ISSUE_POLL_MS,
                     n_intervals=0),
        dcc.Loading(type="circle", children=html.Div(id="cs-issue-banner")),
    ])


# ── Global efficiency inputs (apply to every tab) ─────────────────────────
_EFF_FIELDS = [
    ("cs-eff-gas", "gas", "Gas — CSS"),
    ("cs-eff-coal", "coal", "Coal — CDS"),
    ("cs-eff-lignite", "lignite", "Lignite — CLS"),
]


def _efficiency_bar() -> html.Div:
    """Typed plant efficiencies, in percent, shared by all sub-tabs."""
    fields = []
    for component_id, fuel, label in _EFF_FIELDS:
        fields.append(html.Div(children=[
            html.Label(label, style={**_LABEL, "marginBottom": "4px"}),
            dbc.InputGroup([
                dbc.Input(
                    id=component_id, type="number",
                    value=round(EFF_DEFAULTS[fuel] * 100, 2),
                    min=round(EFF_MIN * 100, 2), max=round(EFF_MAX * 100, 2),
                    step=0.01, debounce=True,
                    persistence=True, persistence_type="local",
                    style={"fontSize": "13px", "width": "88px"},
                ),
                dbc.InputGroupText("%", style={"fontSize": "12px",
                                               "padding": "0 8px"}),
            ], size="sm"),
        ]))
    return html.Div(
        style={**_PANEL, "display": "flex", "gap": "22px",
               "flexWrap": "wrap", "alignItems": "flex-end",
               "padding": "12px 20px 14px 20px"},
        children=[
            html.Div(style={"maxWidth": "150px"}, children=[
                html.Label("Plant efficiency", style=_LABEL),
                html.Span("Applies to every tab",
                          style={"fontSize": "11px",
                                 "color": COLORS["text_muted"]}),
            ]),
            *fields,
            html.Div(id="cs-eff-note",
                     style={"fontSize": "11px",
                            "color": COLORS["text_muted"],
                            "maxWidth": "620px", "alignSelf": "center"}),
        ],
    )


def _pack_metric_radio(component_id: str) -> dcc.RadioItems:
    return dcc.RadioItems(
        id=component_id,
        options=_PACK_METRIC_OPTIONS,
        value="CSS",
        persistence=True, persistence_type="local",
        inline=True,
        style={"fontSize": "13px", "color": COLORS["text_primary"]},
        labelStyle={"marginRight": "14px", "cursor": "pointer"},
    )


# ── Tab 1: Curve Snapshot ─────────────────────────────────────────────────
def _snapshot_table_panel(table_id: str, title_id: str,
                          title: str) -> html.Div:
    """One change table (outright + DoD/WoW/MoM) in its own panel."""
    return html.Div(style={**_PANEL, "flex": "1 1 330px",
                           "minWidth": "310px"}, children=[
        html.H3(title, id=title_id,
                style={"fontSize": "14px", "fontWeight": "600",
                       "margin": "0 0 10px 0"}),
        dcc.Loading(type="circle", children=DataTable(
            id=table_id,
            columns=TABLE_COLUMNS, data=[],
            style_as_list_view=True,
            style_table={"overflowX": "auto"},
            style_header={
                "backgroundColor": COLORS["card_bg"],
                "color": COLORS["text_muted"],
                "fontWeight": "600", "fontSize": "12px",
            },
            style_cell={"fontSize": "13px", "padding": "7px 10px",
                        "textAlign": "center", "border": "none"},
        )),
    ])


def _tab_snapshot() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-snap-country"),
                     ]),
                     html.Div(children=[
                         html.Label("View", style=_LABEL),
                         dcc.RadioItems(
                             id="cs-snap-view",
                             options=[
                                 {"label": "Spreads (€/MWh)",
                                  "value": "SPREADS"},
                                 {"label": "Heat rates (x)",
                                  "value": "HEATRATES"},
                             ],
                             value="SPREADS",
                             inline=True,
                             style={"fontSize": "13px",
                                    "color": COLORS["text_primary"]},
                             labelStyle={"marginRight": "16px",
                                         "cursor": "pointer"},
                         ),
                     ]),
                     html.Div(id="cs-snap-metric-wrap", children=[
                         html.Label("Metric", style=_LABEL),
                         _metric_radio("cs-snap-metric", include_both=True),
                     ]),
                     html.Div(id="cs-snap-fuel-wrap",
                              style={"display": "none"}, children=[
                         html.Label("Fuel", style=_LABEL),
                         dcc.RadioItems(
                             id="cs-snap-fuel",
                             options=[
                                 {"label": "Combined", "value": "COMBINED"},
                                 {"label": "Gas", "value": "GAS"},
                                 {"label": "Coal", "value": "COAL"},
                                 {"label": "Lignite", "value": "LIGNITE"},
                             ],
                             value="COMBINED",
                             inline=True,
                             style={"fontSize": "13px",
                                    "color": COLORS["text_primary"]},
                             labelStyle={"marginRight": "16px",
                                         "cursor": "pointer"},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-snap-curve-chart", config=_GRAPH_CONFIG,
                style={"height": "500px"},
            )),
        ]),
        html.Div(style={"display": "flex", "gap": "20px",
                        "flexWrap": "wrap", "alignItems": "flex-start"},
                 children=[
                     _snapshot_table_panel("cs-snap-css-table",
                                           "cs-snap-css-title",
                                           "Clean Spark table"),
                     _snapshot_table_panel("cs-snap-cds-table",
                                           "cs-snap-cds-title",
                                           "Clean Dark table"),
                     _snapshot_table_panel("cs-snap-cls-table",
                                           "cs-snap-cls-title",
                                           "Clean Lignite table"),
                 ]),
        html.Div(id="cs-snap-footnote",
                 style={"fontSize": "11px", "color": COLORS["text_muted"]}),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-snap-ridge", config=_GRAPH_CONFIG,
                style={"height": "470px"},
            )),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab 2: Delivered vs Forward ───────────────────────────────────────────
def _tab_delivered() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-dvf-country"),
                     ]),
                     html.Div(style={"minWidth": "220px"}, children=[
                         html.Label("Metric", style=_LABEL),
                         dbc.Select(
                             id="cs-dvf-metric",
                             options=[
                                 {"label": "Clean Spark Spread (CSS)",
                                  "value": "CSS"},
                                 {"label": "Clean Dark Spread (CDS)",
                                  "value": "CDS"},
                                 {"label": "Clean Lignite Spread (CLS)",
                                  "value": "CLS"},
                                 {"label": "Gas Heat Rate",
                                  "value": "HR_GAS"},
                                 {"label": "Coal Heat Rate",
                                  "value": "HR_COAL"},
                                 {"label": "Lignite Heat Rate",
                                  "value": "HR_LIGNITE"},
                             ],
                             value="CSS",
                             style={"fontSize": "13px"},
                         ),
                     ]),
                     html.Div(style={"maxWidth": "560px"}, children=[
                         html.P(
                             "Delivered outturn (bars, from realised spot "
                             "power/gas/carbon/coal) against the current "
                             "forward curve (line). Outlined heatmap cells "
                             "are forward-curve months.",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-dvf-timeline", config=_GRAPH_CONFIG,
                style={"height": "520px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-dvf-heatmap", config=_GRAPH_CONFIG,
            )),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab: Daily Calendar (price_report page-1 replica) ─────────────────────
def _tab_calendar() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-cal-country"),
                     ]),
                     html.Div(style={"minWidth": "220px"}, children=[
                         html.Label("Metric", style=_LABEL),
                         dbc.Select(
                             id="cs-cal-metric",
                             options=[
                                 {"label": "All metrics (stacked)",
                                  "value": "ALL"},
                                 {"label": "Power", "value": "Power"},
                                 {"label": "Clean Dark Spread",
                                  "value": "CDS"},
                                 {"label": "Clean Spark Spread",
                                  "value": "CSS"},
                                 {"label": "Clean Lignite Spread",
                                  "value": "CLS"},
                                 {"label": "Heat Rate", "value": "HeatRate"},
                                 {"label": "Gas", "value": "Gas"},
                                 {"label": "Carbon", "value": "Carbon"},
                                 {"label": "Coal", "value": "Coal"},
                             ],
                             value="CSS",
                             style={"fontSize": "13px"},
                         ),
                     ]),
                     html.Div(children=[
                         html.Label("Window", style=_LABEL),
                         dcc.RadioItems(
                             id="cs-cal-days",
                             options=[
                                 {"label": "90d", "value": 90},
                                 {"label": "180d", "value": 180},
                                 {"label": "365d", "value": 365},
                             ],
                             value=180,
                             inline=True,
                             style={"fontSize": "13px",
                                    "color": COLORS["text_primary"]},
                             labelStyle={"marginRight": "14px",
                                         "cursor": "pointer"},
                         ),
                     ]),
                     html.Div(style={"maxWidth": "480px"}, children=[
                         html.P(
                             "Daily spot outturn as calendar heatmaps "
                             "(weeks across, weekdays down) with week and "
                             "month averages \u2014 the price_report daily "
                             "page, interactive.",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        dcc.Loading(type="circle",
                    children=html.Div(id="cs-cal-content")),
        html.Div(id="cs-cal-footnote",
                 style={"fontSize": "11px", "color": COLORS["text_muted"],
                        "marginTop": "8px"}),
    ], style={"paddingTop": "18px"})


# ── Tab: HR vs Fundamentals (climate weather-year regression) ─────────────
# History years: climate panels run from 2020; years past the last
# weather-year column (e.g. 2025-2026) are filled from realised actuals.
_FUND_YEARS = list(range(2020, date.today().year + 1))


def _tab_fundamentals() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-fund-country"),
                     ]),
                     html.Div(style={"minWidth": "200px"}, children=[
                         html.Label("Fundamental", style=_LABEL),
                         dbc.Select(
                             id="cs-fund-var",
                             options=[
                                 {"label": "Residual Load",
                                  "value": "RESIDUAL_LOAD"},
                                 {"label": "Wind", "value": "WIND"},
                                 {"label": "Solar", "value": "SOLAR"},
                                 {"label": "Demand", "value": "DEMAND"},
                             ],
                             value="RESIDUAL_LOAD",
                             style={"fontSize": "13px"},
                         ),
                     ]),
                     html.Div(children=[
                         html.Label("Model options", style=_LABEL),
                         dcc.Checklist(
                             id="cs-fund-opts",
                             options=[
                                 {"label": "Year fixed effects",
                                  "value": "FE"},
                                 {"label": "Pool \u00b11 month",
                                  "value": "POOL"},
                             ],
                             value=["FE", "POOL"],
                             inline=True,
                             style={"fontSize": "13px",
                                    "color": COLORS["text_primary"]},
                             labelStyle={"marginRight": "14px",
                                         "cursor": "pointer"},
                             inputStyle={"marginRight": "4px"},
                         ),
                     ]),
                     html.Div(children=[
                         html.Label("Regression years", style=_LABEL),
                         dcc.Checklist(
                             id="cs-fund-years",
                             options=[{"label": str(y), "value": y}
                                      for y in _FUND_YEARS],
                             value=list(_FUND_YEARS),
                             inline=True,
                             style={"fontSize": "13px",
                                    "color": COLORS["text_primary"]},
                             labelStyle={"marginRight": "14px",
                                         "cursor": "pointer"},
                             inputStyle={"marginRight": "4px"},
                         ),
                     ]),
                     html.Div(style={"maxWidth": "460px"}, children=[
                         html.P(
                             "Daily gas heat rate vs fundamental (GW); "
                             "history = climate weather-year diagonal + "
                             "realised actuals for 2025+. Spike days "
                             "(HR outside 1st-99th pct) are excluded. "
                             "Year fixed effects fit the slope on "
                             "within-year anomalies and anchor the level "
                             "to the last 12 months. Diamonds = weather-"
                             "year forward means through the regression; "
                             "star + whiskers = model median and P10-P90 "
                             "(incl. residual noise); dashed = market "
                             "forward HR. First load per country/variable "
                             "fetches from S3 (a few seconds).",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-fund-grid", config=_GRAPH_CONFIG,
                style={"height": "1200px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            html.Label("Forward month summary", style=_LABEL),
            dcc.Loading(type="circle",
                        children=html.Div(id="cs-fund-summary")),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab 3: Contract History ───────────────────────────────────────────────
def _tab_contract() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-hist-country"),
                     ]),
                     html.Div(children=[
                         html.Label("Metric", style=_LABEL),
                         dcc.RadioItems(
                             id="cs-hist-metric",
                             options=_PACK_METRIC_OPTIONS,
                             value="CSS",
                             inline=True,
                             style={"fontSize": "13px",
                                    "color": COLORS["text_primary"]},
                             labelStyle={"marginRight": "14px",
                                         "cursor": "pointer"},
                         ),
                     ]),
                     html.Div(style=_CONTROL, children=[
                         html.Label("Contract", style=_LABEL),
                         dbc.Select(
                             id="cs-hist-tenor",
                             options=_TENOR_OPTIONS,
                             value="Q1",
                             style={"fontSize": "13px"},
                         ),
                     ]),
                     html.Div(style=_CONTROL, children=[
                         html.Label("Lookback (days to delivery)",
                                    style=_LABEL),
                         dbc.Select(
                             id="cs-hist-days",
                             options=[{"label": v, "value": v}
                                      for v in ["90", "180", "365", "730",
                                                "1095", "1460"]]
                             + [{"label": "All", "value": "ALL"}],
                             value="365",
                             style={"fontSize": "13px"},
                         ),
                     ]),
                     html.Div(children=[
                         html.Label("Envelope", style=_LABEL),
                         dcc.Checklist(
                             id="cs-hist-envelope",
                             options=[{"label": "Show P10-P90 cone "
                                       "(past years)", "value": "ENV"}],
                             value=["ENV"],
                             style={"fontSize": "13px",
                                    "color": COLORS["text_primary"]},
                             inputStyle={"marginRight": "4px"},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-hist-chart", config=_GRAPH_CONFIG,
                style={"height": "520px"},
            )),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab: Screener ──────────────────────────────────────────────────────────
def _tab_screener() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(children=[
                         html.Label("Metric", style=_LABEL),
                         _pack_metric_radio("cs-scr-metric"),
                     ]),
                     html.Div(style=_CONTROL, children=[
                         html.Label("RV matrix tenor", style=_LABEL),
                         dbc.Select(
                             id="cs-rv-type",
                             options=[
                                 {"label": "Front month",
                                  "value": "MONTHLY"},
                                 {"label": "Front quarter",
                                  "value": "QUARTERLY"},
                                 {"label": "Front cal year",
                                  "value": "YEARLY"},
                             ],
                             value="QUARTERLY",
                             style={"fontSize": "13px"},
                         ),
                     ]),
                     html.Div(style={"maxWidth": "560px"}, children=[
                         html.P(
                             "Every live contract across countries: z(DoD) "
                             "= today's move vs the contract's own daily "
                             "vol; Pctile = current level within the "
                             "contract's full history (>=90 shaded rich, "
                             "<=10 cheap). RV matrix: row minus column "
                             "front-contract differential with 1y z-score.",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=DataTable(
                id="cs-scr-table",
                sort_action="native",
                style_table={"overflowX": "auto"},
                style_cell={"fontSize": "12px", "padding": "6px 10px",
                            "fontFamily": "inherit"},
                style_header={"fontWeight": "600",
                              "backgroundColor": "rgba(0,0,0,0.03)",
                              "border": "none"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-rv-matrix", config=_GRAPH_CONFIG,
            )),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab: Carbon & Scenarios ────────────────────────────────────────────────
def _tab_carbon() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-carb-country"),
                     ]),
                     html.Div(style=_CONTROL, children=[
                         html.Label("Scenario contract", style=_LABEL),
                         dbc.Select(id="cs-scen-strip",
                                    style={"fontSize": "13px"}),
                     ]),
                     html.Div(style={"maxWidth": "560px"}, children=[
                         html.P(
                             "Switching price C* = EUA level equalising the "
                             "gas and coal marginal cost per tenor at the "
                             "selected efficiencies (default 50% / 40%); "
                             "implied EUA above C* puts gas in merit. The "
                             "scenario grid re-prices one contract's CSS "
                             "under gas x carbon shocks with implied power "
                             "held fixed (cost-side only).",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-carb-chart", config=_GRAPH_CONFIG,
                style={"height": "470px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-scen-grid", config=_GRAPH_CONFIG,
                style={"height": "440px"},
            )),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab: Risk Premium ──────────────────────────────────────────────────────
def _tab_premium() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-prem-country"),
                     ]),
                     html.Div(children=[
                         html.Label("Metric", style=_LABEL),
                         _pack_metric_radio("cs-prem-metric"),
                     ]),
                     html.Div(style={"maxWidth": "620px"}, children=[
                         html.P(
                             "For every delivered month: forward value at "
                             "D-30/60/90 minus the delivered outturn. "
                             "Positive premium = the market overpriced the "
                             "month (selling forward was paid). Boxes pool "
                             "all delivery years per calendar month. CSS "
                             "outturn from delivered_spreads; CDS and heat "
                             "rates from realised daily spot metrics.",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-prem-chart", config=_GRAPH_CONFIG,
                style={"height": "520px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            html.Label("Mean premium and hit rate by delivery month",
                       style=_LABEL),
            dcc.Loading(type="circle",
                        children=html.Div(id="cs-prem-summary")),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab: Vol & Betas ───────────────────────────────────────────────────────
def _tab_volbeta() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-vb-country"),
                     ]),
                     html.Div(style=_CONTROL, children=[
                         html.Label("Tenor", style=_LABEL),
                         dbc.Select(
                             id="cs-vb-tenor",
                             options=_TENOR_OPTIONS,
                             value="Q1",
                             style={"fontSize": "13px"},
                         ),
                     ]),
                     html.Div(children=[
                         html.Label("Cone metric", style=_LABEL),
                         _pack_metric_radio("cs-vb-metric"),
                     ]),
                     html.Div(style={"maxWidth": "560px"}, children=[
                         html.P(
                             "Vol cone: 20d realized vol of daily changes "
                             "of the selected metric vs days-to-delivery, "
                             "banded across past contract years, live "
                             "contract overlaid. Betas: rolling 60d "
                             "two-factor fit of CSS changes on gas and "
                             "implied-carbon changes (front contract of the "
                             "tenor; always CSS, at the selected gas "
                             "efficiency, so they scale with it).",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-vb-cone", config=_GRAPH_CONFIG,
                style={"height": "470px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-vb-betas", config=_GRAPH_CONFIG,
                style={"height": "470px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            html.H3("Hedge ratios", style={"fontSize": "14px",
                                           "fontWeight": "600",
                                           "margin": "0 0 10px 0"}),
            html.Div(style={"display": "flex", "gap": "16px",
                            "alignItems": "flex-end", "flexWrap": "wrap",
                            "marginBottom": "10px"},
                     children=[
                         html.Div(style=_CONTROL, children=[
                             html.Label("Contract", style=_LABEL),
                             dbc.Select(id="cs-vb-strip",
                                        style={"fontSize": "13px"}),
                         ]),
                         html.Div(style={"width": "120px"}, children=[
                             html.Label("Clip (MW)", style=_LABEL),
                             dbc.Input(id="cs-vb-mw", type="number",
                                       value=15, min=0, step=1,
                                       style={"fontSize": "13px"}),
                         ]),
                     ]),
            dcc.Loading(type="circle",
                        children=html.Div(id="cs-vb-hedge")),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab: Shape & Strips ────────────────────────────────────────────────────
def _tab_shape() -> html.Div:
    return html.Div([
        html.Div(style={**_PANEL, "display": "flex", "gap": "28px",
                        "flexWrap": "wrap", "alignItems": "flex-end"},
                 children=[
                     html.Div(style=_CONTROL, children=[
                         html.Label("Country", style=_LABEL),
                         _country_dropdown("cs-shape-country"),
                     ]),
                     html.Div(children=[
                         html.Label("Strips / rolldown metric",
                                    style=_LABEL),
                         _pack_metric_radio("cs-shape-metric"),
                     ]),
                     html.Div(style={"maxWidth": "620px"}, children=[
                         html.P(
                             "Hourly spark spread from spot outturn (hour "
                             "x month; top row = capture factor; always "
                             "CSS). Below: Winter/Summer strips off the "
                             "current curve with the Win-Sum calendar "
                             "spread, and the static-curve rolldown per "
                             "contract, in the selected metric.",
                             style={"fontSize": "12px", "margin": "0",
                                    "color": COLORS["text_muted"]},
                         ),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-shape-capture", config=_GRAPH_CONFIG,
                style={"height": "620px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-shape-strips", config=_GRAPH_CONFIG,
                style={"height": "440px"},
            )),
        ]),
        html.Div(style=_PANEL, children=[
            html.Label("Static-curve rolldown", style=_LABEL),
            dcc.Loading(type="circle",
                        children=html.Div(id="cs-shape-rolldown")),
        ]),
    ], style={"paddingTop": "18px"})


# ── Tab 4: UK Focus ───────────────────────────────────────────────────────
def _tab_uk() -> html.Div:
    ratio_pct = f"{UK_CARBON_RATIO:.4f}"
    return html.Div([
        html.Div(style={"display": "flex", "gap": "20px", "flexWrap": "wrap",
                        "alignItems": "stretch"},
                 children=[
                     # Hedge ratio card
                     html.Div(style={**_PANEL, "flex": "1 1 340px",
                                     "maxWidth": "460px"}, children=[
                         html.H3("UKA hedge ratio",
                                 style={"fontSize": "14px",
                                        "fontWeight": "600",
                                        "margin": "0 0 10px 0"}),
                         html.P([
                             "Theoretical carbon intensity at 49.13% market "
                             "efficiency: ",
                             html.B(f"{ratio_pct} tCO2/MWh"),
                             " (= 0.1821 / 0.4913). This tab stays pinned to "
                             "the UK market convention — the efficiency "
                             "inputs above drive every other tab.",
                         ], style={"fontSize": "12px",
                                   "color": COLORS["text_secondary"],
                                   "margin": "0 0 12px 0"}),
                         html.Div(style={"display": "flex", "gap": "16px",
                                         "alignItems": "flex-end",
                                         "flexWrap": "wrap"},
                                  children=[
                                      html.Div(children=[
                                          html.Label("Clip size (MW)",
                                                     style=_LABEL),
                                          dbc.Input(id="cs-uk-mw",
                                                    type="number", value=15,
                                                    min=0, step=1,
                                                    style={"width": "110px"}),
                                      ]),
                                      html.Div(children=[
                                          html.Label("Season", style=_LABEL),
                                          dbc.Select(
                                              id="cs-uk-season",
                                              options=[
                                                  {"label": "Winter (Oct\u2013Mar)",
                                                   "value": "Winter"},
                                                  {"label": "Summer (Apr\u2013Sep)",
                                                   "value": "Summer"},
                                              ],
                                              value="Winter",
                                              style={"fontSize": "13px",
                                                     "width": "170px"},
                                          ),
                                      ]),
                                  ]),
                         html.Div(id="cs-uk-hedge-output",
                                  style={"marginTop": "14px"}),
                         html.P(
                             "Reference: a 15 MW winter clip filled with 50 "
                             "UKA lots implies 0.763 t/MWh \u2014 2x the "
                             "theoretical ratio (check the confirm's lot "
                             "size; 25 lots at 1,000 t matches theory).",
                             style={"fontSize": "11px",
                                    "color": COLORS["text_muted"],
                                    "marginTop": "12px",
                                    "marginBottom": "0"},
                         ),
                     ]),
                     # UK curve chart
                     html.Div(style={**_PANEL, "flex": "2 1 560px",
                                     "minWidth": "480px"}, children=[
                         dcc.Loading(type="circle", children=dcc.Graph(
                             id="cs-uk-curve-chart", config=_GRAPH_CONFIG,
                             style={"height": "520px"},
                         )),
                     ]),
                 ]),
        html.Div(style=_PANEL, children=[
            dcc.Loading(type="circle", children=dcc.Graph(
                id="cs-uk-history-chart", config=_GRAPH_CONFIG,
                style={"height": "480px"},
            )),
        ]),
        html.Div(id="cs-uk-diagnostic",
                 style={"fontSize": "11px", "color": COLORS["text_muted"],
                        "marginBottom": "12px"}),
    ], style={"paddingTop": "18px"})


def build_layout() -> html.Div:
    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1500px"},
        children=[
            html.H1("Clean Spark / Clean Dark / Clean Lignite Spreads",
                    style={"fontSize": "22px", "fontWeight": "600",
                           "color": COLORS["text_primary"],
                           "margin": "0 0 4px 0"}),
            html.P(
                "Forward CSS/CDS/CLS curves at your own plant efficiencies "
                "with day/week/month changes (toggleable to gas/coal/lignite "
                "clean heat rates), delivered outturn vs the live curve, "
                "contract histories into delivery, and the UK market view "
                "(49.13% efficiency, UKA + \u00a318 CPS). Spreads in "
                "\u20ac/MWh; heat rates as power/fuel-cost multiples.",
                style={"fontSize": "13px", "color": COLORS["text_muted"],
                       "margin": "0 0 16px 0"},
            ),
            dcc.Store(id="cs-eff-store", storage_type="local",
                      data={fuel: round(eff * 100, 2)
                            for fuel, eff in EFF_DEFAULTS.items()}),
            _issue_date_banner(),
            _efficiency_bar(),
            dbc.Tabs(
                id="cs-tabs",
                active_tab="snapshot",
                children=[
                    dbc.Tab(_tab_snapshot(), label="Curve Snapshot",
                            tab_id="snapshot"),
                    dbc.Tab(_tab_screener(), label="Screener",
                            tab_id="screener"),
                    dbc.Tab(_tab_delivered(), label="Delivered vs Forward",
                            tab_id="delivered"),
                    dbc.Tab(_tab_calendar(), label="Daily Calendar",
                            tab_id="calendar"),
                    dbc.Tab(_tab_fundamentals(), label="HR vs Fundamentals",
                            tab_id="fundamentals"),
                    dbc.Tab(_tab_contract(), label="Contract History",
                            tab_id="contract"),
                    dbc.Tab(_tab_carbon(), label="Carbon & Scenarios",
                            tab_id="carbon"),
                    dbc.Tab(_tab_premium(), label="Risk Premium",
                            tab_id="premium"),
                    dbc.Tab(_tab_volbeta(), label="Vol & Betas",
                            tab_id="volbeta"),
                    dbc.Tab(_tab_shape(), label="Shape & Strips",
                            tab_id="shape"),
                    dbc.Tab(_tab_uk(), label="UK Focus", tab_id="uk"),
                ],
            ),
        ],
    )
