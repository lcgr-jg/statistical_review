"""Plotly figures for the Clean Spreads page."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.clean_spreads import data as cs_data
from core.clean_spreads.constants import (
    CSS_COLOR,
    DELIVERED_COLOR,
    FORWARD_COLOR,
    GHOST_1M_COLOR,
    GHOST_1W_COLOR,
    HEAT_RATES,
    METRICS,
    MONTH_ABBR,
    UK_MKT_COLOR,
)
from core.styles import COLORS

_FONT = dict(
    family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    size=12,
    color=COLORS["text_primary"],
)


def _base_layout(title: str, height: int = 480) -> dict:
    return dict(
        title=dict(text=title, font=dict(size=15), x=0.01, xanchor="left"),
        height=height,
        template="plotly_white",
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        font=_FONT,
        margin=dict(l=55, r=25, t=55, b=55),
        legend=dict(orientation="h", yanchor="bottom", y=1.01,
                    xanchor="right", x=1, font=dict(size=11)),
        hovermode="x unified",
        uirevision="constant",
    )


def placeholder_figure(message: str = "Loading price data…") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=message, xref="paper", yref="paper",
                       x=0.5, y=0.5, showarrow=False,
                       font=dict(size=14, color=COLORS["text_muted"]))
    fig.update_layout(height=420, template="plotly_white",
                      xaxis=dict(visible=False), yaxis=dict(visible=False),
                      paper_bgcolor=COLORS["card_bg"],
                      plot_bgcolor=COLORS["card_bg"])
    return fig


def _zero_line(fig: go.Figure) -> go.Figure:
    fig.add_hline(y=0, line_width=1, line_color="#666666")
    return fig


# ── Tab 1: forward curve with efficiency band + ghost curves ──────────────
def _eff_pct(eff: float) -> str:
    """0.5 -> '50', 0.4913 -> '49.13' (no trailing zeros)."""
    return f"{eff * 100:g}"


def issued_suffix(date, label: str = "issued") -> str:
    """' — issued 14 Sep 2026', or '' when the date is unknown.

    Stamped into figure titles so an exported image still says which
    forward-curve issue date it came from.
    """
    if date is None or pd.isna(date):
        return ""
    return f" — {label} {pd.Timestamp(date):%d %b %Y}"


def _frame_issue_date(frame) -> pd.Timestamp | None:
    """Issue (trade) date carried by a curve frame from data.build_curve."""
    if frame is None or getattr(frame, "empty", True) \
            or "DATE" not in frame.columns:
        return None
    stamp = pd.Timestamp(frame["DATE"].iloc[0])
    if pd.isna(stamp):
        return None
    return stamp  # type: ignore[return-value]


def curve_trace_name(metric_key: str, effs: dict | None) -> str:
    """Legend name for a spread curve, e.g. 'CSS mid (band 48-52%)'."""
    spec = METRICS[metric_key]
    effs = effs or {}
    prefix = spec["prefix"]
    if effs.get(f"{spec['fuel']}_default") and spec["effs"] is not None:
        level = "mid"
    else:
        level = f"{_eff_pct(effs.get(spec['fuel'], 0.0))}% eff"
    band = cs_data.metric_band(metric_key, effs)
    if band is None:
        return f"{prefix} {level}"
    return (f"{prefix} {level} (band {_eff_pct(band[0])}"
            f"–{_eff_pct(band[1])}%)")


def curve_chart(curves: dict, country: str,
                effs: dict | None = None) -> go.Figure:
    """Forward curve(s) with an efficiency band + 1W/1M ghost lines.

    ``curves``: {metric_key: {'current': df, 'ghost_1w': df, 'ghost_1m': df}}
    where each df comes from data.build_curve with the metric's MID + band
    columns; ``effs`` are the normalized page efficiencies (data.bundle_effs)
    driving the band and the legend labels.
    """
    fig = go.Figure()
    has_data = False
    issue_date = None

    for metric_key, curve_set in curves.items():
        spec = METRICS[metric_key]
        prefix, color, band = spec["prefix"], spec["color"], spec["band"]
        mid_col = f"{prefix}_MID_EFF"
        cur = curve_set.get("current")
        if cur is None or cur.empty:
            continue
        has_data = True
        issue_date = issue_date or _frame_issue_date(cur)
        x = cur["STRIP"].tolist()

        # Efficiency band: +/-2pp around a typed efficiency where those
        # columns exist, else the precomputed LOW/HI convention.
        low_col, hi_col = f"{prefix}_BAND_LO", f"{prefix}_BAND_HI"
        if not {low_col, hi_col}.issubset(cur.columns):
            low_col, hi_col = f"{prefix}_LOW_EFF", f"{prefix}_HI_EFF"
        if low_col in cur.columns and hi_col in cur.columns:
            fig.add_trace(go.Scatter(
                x=x + x[::-1],
                y=list(cur[low_col]) + list(cur[hi_col])[::-1],
                fill="toself", fillcolor=band,
                line=dict(color="rgba(0,0,0,0)"),
                hoverinfo="skip", showlegend=False,
            ))

        # Ghost curves (1M behind 1W behind current)
        for ghost_key, ghost_color, ghost_name in (
            ("ghost_1m", GHOST_1M_COLOR, f"{prefix} 1M ago"),
            ("ghost_1w", GHOST_1W_COLOR, f"{prefix} 1W ago"),
        ):
            ghost = curve_set.get(ghost_key)
            if ghost is None or ghost.empty or mid_col not in ghost.columns:
                continue
            ghost_map = ghost.set_index("STRIP")[mid_col]
            fig.add_trace(go.Scatter(
                x=x, y=[ghost_map.get(s) for s in x],
                mode="lines", name=ghost_name,
                line=dict(color=ghost_color, width=1.4, dash="dot"),
            ))

        # Current curve at the selected efficiency
        fig.add_trace(go.Scatter(
            x=x, y=cur[mid_col], mode="lines+markers",
            name=curve_trace_name(metric_key, effs),
            line=dict(color=color, width=2.4),
            marker=dict(size=6),
        ))

    if not has_data:
        return placeholder_figure(f"No curve data for {country}")

    fig.update_layout(**_base_layout(
        f"Forward curve \u2014 {country}{issued_suffix(issue_date)}",
        height=500))
    fig.update_xaxes(title="Delivery strip", type="category", tickangle=-40)
    fig.update_yaxes(title="Spread (€/MWh)")
    return _zero_line(fig)


def heat_rate_curve_chart(curve_set: dict, fuels: list[str],
                          country: str) -> go.Figure:
    """Forward clean heat-rate curves (P / fuel+carbon cost) per fuel.

    ``curve_set``: {'current': df, 'ghost_1w': df, 'ghost_1m': df} from
    data.heat_rate_curve; ``fuels``: subset of ['GAS','COAL','LIGNITE'].
    """
    current = curve_set.get("current")
    if current is None or current.empty:
        return placeholder_figure(f"No heat-rate data for {country}")

    fig = go.Figure()
    x = current["STRIP"].tolist()
    has_data = False
    missing: list[str] = []

    for fuel in fuels:
        spec = HEAT_RATES[fuel]
        col, color = spec["col"], spec["color"]
        if col not in current.columns or current[col].isna().all():
            missing.append(spec["label"])
            continue
        has_data = True

        for ghost_key, ghost_color, suffix in (
            ("ghost_1m", GHOST_1M_COLOR, "1M ago"),
            ("ghost_1w", GHOST_1W_COLOR, "1W ago"),
        ):
            ghost = curve_set.get(ghost_key)
            if ghost is None or ghost.empty or col not in ghost.columns:
                continue
            ghost_map = ghost.set_index("STRIP")[col]
            fig.add_trace(go.Scatter(
                x=x, y=[ghost_map.get(s) for s in x],
                mode="lines", name=f"{spec['label']} {suffix}",
                line=dict(color=ghost_color, width=1.2, dash="dot"),
                showlegend=(fuel == fuels[0]),
                legendgroup=f"ghost_{suffix}",
            ))

        fig.add_trace(go.Scatter(
            x=x, y=current[col], mode="lines+markers",
            name=spec["label"],
            line=dict(color=color, width=2.4), marker=dict(size=6),
            hovertemplate="%{x}: %{y:.3f}x<extra>" + spec["label"] + "</extra>",
        ))

    if not has_data:
        return placeholder_figure(
            f"No heat-rate columns available for {country}"
            + (f" (missing: {', '.join(missing)})" if missing else ""))

    subtitle = "clean heat rate = implied power / (fuel + EF x carbon)"
    if missing:
        subtitle += f" \u2014 unavailable: {', '.join(missing)}"
    fig.update_layout(**_base_layout(
        f"Clean heat rates \u2014 {country} ({subtitle})"
        + issued_suffix(_frame_issue_date(current)), height=500))
    fig.update_xaxes(title="Delivery strip", type="category", tickangle=-40)
    fig.update_yaxes(title="Heat rate (x)")
    fig.add_hline(y=1.0, line_width=1, line_dash="dash", line_color="#999999",
                  annotation_text="breakeven (1.0x)",
                  annotation_font_size=10)
    return fig


# ── Tab 2: delivered history vs forward curve timeline ────────────────────
def delivered_vs_forward_chart(delivered: pd.DataFrame, forward: pd.DataFrame,
                               country: str, metric_label: str,
                               y_title: str = "Spread (€/MWh)",
                               unit: str = "€/MWh",
                               zero_line: bool = True,
                               bar_threshold: float = 0.0) -> go.Figure:
    if (delivered is None or delivered.empty) and (
            forward is None or forward.empty):
        return placeholder_figure(f"No delivered/forward data for {country}")

    fig = go.Figure()
    if delivered is not None and not delivered.empty:
        fig.add_trace(go.Bar(
            x=delivered["month"], y=delivered["value"],
            name="Delivered outturn",
            marker_color=[
                DELIVERED_COLOR if v >= bar_threshold else "#b08968"
                for v in delivered["value"]
            ],
            opacity=0.75,
        ))
    if forward is not None and not forward.empty:
        fig.add_trace(go.Scatter(
            x=forward["month"], y=forward["value"],
            mode="lines+markers", name="Current forward curve",
            line=dict(color=FORWARD_COLOR, width=2.4),
            marker=dict(size=5),
            customdata=forward["STRIP"],
            hovertemplate="%{x|%b %Y} \u2014 %{y:.2f} " + unit
                          + " (%{customdata})<extra></extra>",
        ))

    today = pd.Timestamp.today().normalize()
    fig.add_vline(x=today, line_width=1.5, line_dash="dash",
                  line_color=COLORS["accent"])
    fig.add_annotation(x=today, y=1.02, yref="paper", text="today",
                       showarrow=False,
                       font=dict(size=11, color=COLORS["accent"]))

    fig.update_layout(**_base_layout(
        f"{metric_label}: delivered history vs current forward \u2014 "
        f"{country}", height=520))
    fig.update_xaxes(title="Delivery month")
    fig.update_yaxes(title=y_title)
    return _zero_line(fig) if zero_line else fig


def seasonality_heatmap(matrix: dict, country: str,
                        metric_label: str,
                        unit: str = "€/MWh",
                        zmid: float | None = 0.0,
                        decimals: int = 1) -> go.Figure:
    values: pd.DataFrame = matrix.get("values", pd.DataFrame())
    is_fwd: pd.DataFrame = matrix.get("is_forward", pd.DataFrame())
    if values is None or values.empty:
        return placeholder_figure(f"No seasonality data for {country}")

    years = [int(y) for y in values.index]
    month_labels = [MONTH_ABBR[m] for m in values.columns]
    # Transposed layout: years across the x-axis, months down the y-axis
    z = values.values.astype(float).T
    fwd = (is_fwd.values.T if not is_fwd.empty
           else np.zeros_like(z, dtype=bool))

    text = np.where(np.isnan(z), "", np.round(z, decimals).astype(str))

    fig = go.Figure(go.Heatmap(
        z=z, x=[str(y) for y in years], y=month_labels,
        colorscale="RdYlGn", zmid=zmid,
        text=text, texttemplate="%{text}", textfont=dict(size=10),
        hovertemplate="%{y} %{x}: %{z:.2f} " + unit + "<extra></extra>",
        colorbar=dict(title=unit, thickness=12),
    ))

    # Outline forward cells so history vs curve is unambiguous
    for row_idx in range(len(month_labels)):
        for col_idx in range(len(years)):
            if fwd[row_idx, col_idx] and not np.isnan(z[row_idx, col_idx]):
                fig.add_shape(
                    type="rect",
                    x0=col_idx - 0.5, x1=col_idx + 0.5,
                    y0=row_idx - 0.5, y1=row_idx + 0.5,
                    line=dict(color=COLORS["accent"], width=1.6),
                )

    fig.update_layout(**_base_layout(
        f"{metric_label} seasonality \u2014 {country} "
        "(outlined cells = forward curve)", height=90 + 38 * len(month_labels)))
    fig.update_yaxes(autorange="reversed", type="category")
    fig.update_xaxes(type="category", side="top")
    return fig


# ── Curve ridge (weekly curve history on the Snapshot tab) ─────────────────
def curve_ridge(snapshots: list[tuple[pd.Timestamp, pd.DataFrame]],
                country: str, col: str, metric_label: str) -> go.Figure:
    """Overlay of weekly curve snapshots, colored by age (old = faded).

    ``snapshots``: [(curve_date, curve_frame), ...] oldest first; frames
    from data.build_curve with ``col`` present.
    """
    snapshots = [(d, c) for d, c in snapshots
                 if c is not None and not c.empty and col in c.columns]
    if not snapshots:
        return placeholder_figure(f"No curve history for {country}")

    n = len(snapshots)
    # Explicit category order: union of strips sorted by delivery start
    strip_starts: dict[str, pd.Timestamp] = {}
    for _, curve in snapshots:
        for strip, start in zip(curve["STRIP"], curve["DELIVERY_START"]):
            prev = strip_starts.get(strip)
            if prev is None or pd.Timestamp(start) < prev:
                strip_starts[strip] = pd.Timestamp(start)
    ordered = sorted(strip_starts, key=strip_starts.get)

    fig = go.Figure()
    for i, (date, curve) in enumerate(snapshots):
        is_latest = i == n - 1
        # age fade: oldest very light, latest full strength
        alpha = 0.25 + 0.75 * (i / max(n - 1, 1))
        color = (COLORS["accent"] if is_latest
                 else f"rgba(31, 119, 180, {alpha * 0.7:.2f})")
        fig.add_trace(go.Scatter(
            x=curve["STRIP"], y=curve[col],
            mode="lines+markers" if is_latest else "lines",
            name=f"{pd.Timestamp(date):%d %b}"
                 + (" (latest)" if is_latest else ""),
            line=dict(color=color, width=2.6 if is_latest else 1.3),
            marker=dict(size=5),
            showlegend=is_latest or i == 0 or i == n // 2,
            hovertemplate=("%{x}: %{y:.2f} €/MWh "
                           f"<extra>{pd.Timestamp(date):%d %b %y}</extra>"),
        ))
    fig.update_layout(**_base_layout(
        f"{metric_label} curve evolution \u2014 {country} "
        f"(weekly snapshots, last {n} weeks; faded = older)"
        + issued_suffix(snapshots[-1][0], label="latest issue"),
        height=470))
    fig.update_layout(hovermode="closest")
    fig.update_yaxes(title=metric_label)
    fig.update_xaxes(title="Contract", type="category",
                     categoryorder="array", categoryarray=ordered)
    return _zero_line(fig)


# ── HR vs Fundamentals regression grid ─────────────────────────────────────
_YEAR_PALETTE = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd",
                 "#8c564b", "#e377c2", "#17becf", "#bcbd22", "#7f7f7f"]
_FIT_COLOR = "#333333"
_WY_COLOR = "#8d99ae"
_WY_MEDIAN_COLOR = UK_MKT_COLOR


def hr_fundamentals_grid(view: dict, country: str) -> go.Figure:
    """4x3 monthly grid: daily fundamental (GW) vs gas heat rate, colored by
    year, with the fitted regression, weather-year forward means mapped
    through it, and the market forward heat rate as a dashed line.

    ``view`` comes from fundamentals.build_regression_view.
    """
    dataset: pd.DataFrame = view.get("dataset", pd.DataFrame())
    if dataset is None or dataset.empty:
        return placeholder_figure(
            f"No regression data for {country} (climate panel or spot "
            "heat-rate history unavailable)")

    var_label = view["var_label"]
    fits, wy_means = view["fits"], view["wy_means"]
    targets, market = view["targets"], view["market"]
    years = view["selected_years"]
    year_color = {y: _YEAR_PALETTE[i % len(_YEAR_PALETTE)]
                  for i, y in enumerate(sorted(years))}

    fwd_labels = {m: f"{MONTH_ABBR[m].title()}-{targets[m]}"
                  for m in range(1, 13)}
    titles = []
    for month in range(1, 13):
        title = f"{MONTH_ABBR[month]} \u00b7 fwd {fwd_labels[month]}"
        fit = fits.get(month)
        if fit is not None and np.isfinite(fit.get("r2", np.nan)):
            title += f" \u00b7 R\u00b2={fit['r2']:.2f}"
        titles.append(title)

    fig = make_subplots(rows=4, cols=3, subplot_titles=titles,
                        vertical_spacing=0.055, horizontal_spacing=0.06)

    shown: set[str] = set()

    def _legend_once(key: str) -> bool:
        if key in shown:
            return False
        shown.add(key)
        return True

    for month in range(1, 13):
        row, col = (month - 1) // 3 + 1, (month - 1) % 3 + 1
        sub = dataset[dataset["month"] == month]

        for year in sorted(years):
            pts = sub[sub["year"] == year]
            if pts.empty:
                continue
            fig.add_trace(go.Scatter(
                x=pts["FUND"], y=pts["GAS_HR"], mode="markers",
                marker=dict(size=4.5, color=year_color[year], opacity=0.65),
                name=str(year), legendgroup=str(year),
                showlegend=_legend_once(str(year)),
                customdata=pts.index.strftime("%d %b %Y"),
                hovertemplate=("%{customdata}: " + var_label
                               + " %{x:.1f} GW \u00b7 HR %{y:.2f}x"
                               + f"<extra>{year}</extra>"),
            ), row=row, col=col)

        fit = fits.get(month)
        wy = wy_means.get(month, pd.Series(dtype=float))
        if fit is not None:
            xs = [sub["FUND"].min(), sub["FUND"].max()]
            if not wy.empty:
                xs += [float(wy.min()), float(wy.max())]
            x0, x1 = float(np.nanmin(xs)), float(np.nanmax(xs))
            fig.add_trace(go.Scatter(
                x=[x0, x1],
                y=[fit["slope"] * x0 + fit["intercept"],
                   fit["slope"] * x1 + fit["intercept"]],
                mode="lines",
                line=dict(color=_FIT_COLOR, width=1.4),
                name="Regression fit", legendgroup="fit",
                showlegend=_legend_once("fit"), hoverinfo="skip",
            ), row=row, col=col)

            if not wy.empty:
                preds = fit["slope"] * wy.values + fit["intercept"]
                fig.add_trace(go.Scatter(
                    x=wy.values, y=preds, mode="markers",
                    marker=dict(symbol="diamond", size=6, color=_WY_COLOR,
                                opacity=0.85),
                    name="Weather-year fwd means", legendgroup="wy",
                    showlegend=_legend_once("wy"),
                    customdata=[str(w) for w in wy.index],
                    hovertemplate=(fwd_labels[month]
                                   + " \u00b7 WY %{customdata}: %{x:.1f} GW"
                                   " \u2192 HR %{y:.2f}x<extra></extra>"),
                ), row=row, col=col)
                med_x = float(np.median(wy.values))
                dist = view.get("dist", {}).get(month)
                if dist is not None:
                    med_y = dist["median"]
                    error_y = dict(
                        type="data", symmetric=False,
                        array=[dist["p90"] - med_y],
                        arrayminus=[med_y - dist["p10"]],
                        color=_WY_MEDIAN_COLOR, thickness=1.3, width=7,
                    )
                    hover = (fwd_labels[month]
                             + " \u00b7 model median %{y:.2f}x "
                             + f"(P10 {dist['p10']:.2f} / "
                             + f"P90 {dist['p90']:.2f})<extra></extra>")
                else:
                    med_y = fit["slope"] * med_x + fit["intercept"]
                    error_y = None
                    hover = (fwd_labels[month]
                             + " \u00b7 WY median: %{x:.1f} GW \u2192"
                             " HR %{y:.2f}x<extra></extra>")
                fig.add_trace(go.Scatter(
                    x=[med_x], y=[med_y], mode="markers",
                    marker=dict(symbol="star", size=13,
                                color=_WY_MEDIAN_COLOR,
                                line=dict(width=1, color="#ffffff")),
                    error_y=error_y,
                    name="Model median (P10-P90)", legendgroup="wy-med",
                    showlegend=_legend_once("wy-med"),
                    hovertemplate=hover,
                ), row=row, col=col)

        mkt = market.get(month)
        if mkt is not None:
            fig.add_hline(y=mkt["value"], row=row, col=col,
                          line_dash="dash", line_color=FORWARD_COLOR,
                          line_width=1.6)
            if _legend_once("mkt"):
                fig.add_trace(go.Scatter(
                    x=[None], y=[None], mode="lines",
                    line=dict(color=FORWARD_COLOR, dash="dash", width=1.6),
                    name="Market fwd HR", legendgroup="mkt",
                    showlegend=True,
                ), row=1, col=1)

    fig.update_layout(**_base_layout(
        f"Gas heat rate vs {var_label} \u2014 {country} (daily by month; "
        "star = weather-year median projection, dashed = market forward)",
        height=1200))
    fig.update_layout(hovermode="closest",
                      margin=dict(l=55, r=25, t=130, b=45))
    fig.update_annotations(font_size=11)
    for col in range(1, 4):
        fig.update_xaxes(title_text=f"{var_label} (GW)", title_font_size=11,
                         row=4, col=col)
    for row in range(1, 5):
        fig.update_yaxes(title_text="HR (x)", title_font_size=11,
                         row=row, col=1)
    return fig


# ── Daily calendar heatmap (july-style, price_report page 1) ──────────────
_WEEKDAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun",
                   "Wk avg", "Mo avg"]


def calendar_heatmap(series: pd.Series, title: str,
                     colorscale: str = "RdYlGn",
                     reversescale: bool = False,
                     decimals: int = 1) -> go.Figure:
    """GitHub/july-style daily calendar: weeks across, weekdays down,
    plus week-average and month-average rows, with value labels and
    month separators. Replicates price_report's _create_calendar_heatmap.
    """
    s = series.dropna().sort_index()
    if s.empty:
        return placeholder_figure(f"No data for {title}")
    s.index = pd.to_datetime(s.index).normalize()

    week_starts = s.index - pd.to_timedelta(s.index.weekday, unit="D")
    weeks = sorted(pd.unique(week_starts))
    week_pos = {pd.Timestamp(w): i for i, w in enumerate(weeks)}
    n_weeks = len(weeks)

    z = np.full((9, n_weeks), np.nan)
    hover = np.full((9, n_weeks), "", dtype=object)
    for date, value in s.items():
        col = week_pos[date - pd.Timedelta(days=int(date.weekday()))]
        z[date.weekday(), col] = value
        hover[date.weekday(), col] = f"{date:%a %d %b %Y}"

    # Week averages (row 7)
    for week, col in week_pos.items():
        day_vals = z[0:7, col]
        if not np.isnan(day_vals).all():
            z[7, col] = np.nanmean(day_vals)
            hover[7, col] = f"week of {week:%d %b %Y}"

    # Month averages (row 8) - month decided by the week's Thursday
    month_of_week = [
        (pd.Timestamp(w) + pd.Timedelta(days=3)).to_period("M") for w in weeks
    ]
    month_means = s.groupby(s.index.to_period("M")).mean()
    for col, month in enumerate(month_of_week):
        if month in month_means.index:
            z[8, col] = month_means[month]
            hover[8, col] = f"{month.strftime('%b %Y')} average"

    # Cell text
    def _fmt(value: float) -> str:
        if np.isnan(value):
            return ""
        return f"{value:.{decimals}f}"

    text = np.vectorize(_fmt)(z)

    cmin = float(np.nanpercentile(s.values, 5))
    cmax = float(np.nanpercentile(s.values, 95))
    if cmin == cmax:
        cmin, cmax = cmin - 1, cmax + 1

    fig = go.Figure(go.Heatmap(
        z=z,
        x=list(range(n_weeks)),
        y=_WEEKDAY_LABELS,
        zmin=cmin, zmax=cmax,
        colorscale=colorscale, reversescale=reversescale,
        xgap=1.5, ygap=1.5,
        text=text, texttemplate="%{text}", textfont=dict(size=8),
        customdata=hover,
        hovertemplate="%{customdata}: %{z:.2f}<extra></extra>",
        colorbar=dict(thickness=10, len=0.9),
    ))

    # Month boundaries + centered month tick labels
    tickvals, ticktext = [], []
    run_start = 0
    for col in range(1, n_weeks + 1):
        boundary = (col == n_weeks
                    or month_of_week[col] != month_of_week[col - 1])
        if boundary:
            tickvals.append((run_start + col - 1) / 2.0)
            ticktext.append(month_of_week[col - 1].strftime("%b %y"))
            if col < n_weeks:
                fig.add_shape(type="line", x0=col - 0.5, x1=col - 0.5,
                              y0=-0.5, y1=8.5,
                              line=dict(color="#ffffff", width=3))
            run_start = col

    # Hairline above the average rows
    fig.add_shape(type="line", x0=-0.5, x1=n_weeks - 0.5, y0=6.5, y1=6.5,
                  line=dict(color="#ffffff", width=4))

    fig.update_layout(**_base_layout(title, height=340))
    fig.update_layout(hovermode="closest",
                      margin=dict(l=60, r=25, t=45, b=30))
    fig.update_xaxes(tickvals=tickvals, ticktext=ticktext, side="bottom",
                     showgrid=False, zeroline=False)
    fig.update_yaxes(autorange="reversed", showgrid=False, zeroline=False,
                     tickfont=dict(size=10))
    return fig


# ── Tab 3: contract history overlays ──────────────────────────────────────
def _rgba(hex_color: str, alpha: float) -> str:
    """'#4a9eff', 0.2 -> 'rgba(74, 158, 255, 0.2)'."""
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r}, {g}, {b}, {alpha})"


def contract_history_chart(overlays: pd.DataFrame, delivered_by_year: dict,
                           country: str, period: str,
                           metric_label: str,
                           y_title: str = "Spread (€/MWh)",
                           value_suffix: str = " €/MWh",
                           zero_line: bool = True,
                           show_envelope: bool = False,
                           delivered_band: dict | None = None) -> go.Figure:
    """Same strip across delivery years vs days to delivery.

    ``delivered_by_year`` draws a dotted outturn line per year. For heat
    rates ``delivered_band`` gives each year's mean of daily ratios: the
    band between it and the dotted ratio-of-means line is the range a
    forward heat rate is fairly compared within.
    """
    delivered_band = delivered_band or {}
    if overlays is None or overlays.empty:
        return placeholder_figure(
            f"No history for {period} contracts in {country}")

    years = sorted(overlays["Year"].unique())
    palette = ["#4a9eff", "#50c878", "#ff6b6b", "#ffd93d", "#9b59b6",
               "#1abc9c", "#e67e22", "#3498db", "#f39c12", "#2ecc71"]
    year_colors = {y: palette[i % len(palette)] for i, y in enumerate(years)}

    fig = go.Figure()
    max_days = float(overlays["DAYS_TO_DELIVERY"].max())

    # Convergence cone: P10-P90 band across historical years. Contracts
    # still trading on the last trade date are live and excluded from the
    # percentiles (several at once for cals, e.g. Cal-27 and Cal-28).
    if show_envelope and len(years) >= 3:
        if "DATE" in overlays.columns:
            last_by_year = overlays.groupby("Year")["DATE"].max()
            live = set(last_by_year[last_by_year >= overlays["DATE"].max()]
                       .index)
        else:
            live = {max(years)}
        hist = overlays[~overlays["Year"].isin(live)]
        if not hist.empty and hist["Year"].nunique() >= 3:
            bin_size = 10
            binned = ((hist["DAYS_TO_DELIVERY"] // bin_size) * bin_size
                      + bin_size / 2)
            grp = hist.groupby(binned)["value"]
            env = pd.DataFrame({
                "dtd": grp.mean().index,
                "p10": grp.quantile(0.10).values,
                "p90": grp.quantile(0.90).values,
            }).sort_values("dtd")
            fig.add_trace(go.Scatter(
                x=env["dtd"], y=env["p90"], mode="lines",
                line=dict(width=0), showlegend=False, hoverinfo="skip"))
            fig.add_trace(go.Scatter(
                x=env["dtd"], y=env["p10"], mode="lines",
                line=dict(width=0), fill="tonexty",
                fillcolor="rgba(128, 128, 128, 0.18)",
                name="P10-P90 (past years)", hoverinfo="skip"))
    for year in years:
        year_data = overlays[overlays["Year"] == year]
        fig.add_trace(go.Scatter(
            x=year_data["DAYS_TO_DELIVERY"], y=year_data["value"],
            mode="lines", name=str(int(year)),
            legendgroup=f"y{year}",
            line=dict(color=year_colors[year], width=2),
        ))
        delivered = delivered_by_year.get(int(year))
        band_edge = delivered_band.get(int(year))
        if delivered is not None and band_edge is not None:
            lo, hi = sorted((delivered, band_edge))
            fig.add_trace(go.Scatter(
                x=[0, max_days, max_days, 0, 0], y=[lo, lo, hi, hi, lo],
                mode="lines", fill="toself", line=dict(width=0),
                fillcolor=_rgba(year_colors[year], 0.14),
                legendgroup=f"y{year}", showlegend=False,
                hoveron="fills",
                hovertemplate=(f"{int(year)} delivered: "
                               f"{delivered:.3f}{value_suffix} "
                               "(mean P / mean fuel cost)<br>"
                               f"mean of daily HR: {band_edge:.3f}"
                               f"{value_suffix}<extra></extra>"),
            ))
        if delivered is not None:
            fig.add_trace(go.Scatter(
                x=[0, max_days], y=[delivered, delivered],
                mode="lines", name=f"{int(year)} delivered",
                legendgroup=f"y{year}", showlegend=False,
                line=dict(color=year_colors[year], width=1.6, dash="dot"),
                hovertemplate=(f"{int(year)} delivered: "
                               f"{delivered:.2f}{value_suffix}"
                               "<extra></extra>"),
            ))

    if delivered_band:
        subtitle = (" (dotted = delivered mean P / mean fuel cost, "
                    "band to mean of daily HR)")
    elif delivered_by_year:
        subtitle = " (dotted = delivered outturn)"
    else:
        subtitle = ""
    last_trade = (pd.Timestamp(overlays["DATE"].max())
                  if "DATE" in overlays.columns else None)
    fig.update_layout(**_base_layout(
        f"{metric_label} {period} \u2014 {country}: contract history into "
        f"delivery{subtitle}"
        + issued_suffix(last_trade, label="last trade"), height=520))
    fig.update_xaxes(title="Days to delivery", autorange="reversed")
    fig.update_yaxes(title=y_title)
    return _zero_line(fig) if zero_line else fig


# ── Tab 4: UK focus ───────────────────────────────────────────────────────
def uk_curve_chart(curve: pd.DataFrame, seasons: pd.DataFrame) -> go.Figure:
    if curve is None or curve.empty or "CSS_UK_MKT" not in curve.columns:
        return placeholder_figure("No GB curve data")

    x = curve["STRIP"].tolist()
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=x, y=curve["CSS_MID_EFF"], mode="lines+markers",
        name="CSS 50% (standard)",
        line=dict(color=CSS_COLOR, width=1.8, dash="dash"),
        marker=dict(size=5),
    ))
    fig.add_trace(go.Scatter(
        x=x, y=curve["CSS_UK_MKT"], mode="lines+markers",
        name="CSS 49.13% (UK market)",
        line=dict(color=UK_MKT_COLOR, width=2.6),
        marker=dict(size=6),
    ))
    if seasons is not None and not seasons.empty:
        fig.add_trace(go.Bar(
            x=seasons["STRIP"], y=seasons["value"],
            name="Season strip (49.13%)",
            marker_color="rgba(124, 58, 237, 0.30)",
            marker_line=dict(color=UK_MKT_COLOR, width=1),
            width=0.5,
            hovertemplate="%{x}: %{y:.2f} €/MWh<extra></extra>",
        ))

    fig.update_layout(**_base_layout(
        "UK Clean Spark Spread \u2014 49.13% market efficiency, UKA + CPS"
        + issued_suffix(_frame_issue_date(curve)), height=520))
    fig.update_xaxes(title="Delivery strip", type="category", tickangle=-40)
    fig.update_yaxes(title="CSS (€/MWh)")
    return _zero_line(fig)


def uk_history_chart(overlays: pd.DataFrame,
                     delivered_gb: pd.DataFrame) -> go.Figure:
    """GB CSS history: delivered monthly outturn + re-efficiency evolution."""
    if (overlays is None or overlays.empty) and (
            delivered_gb is None or delivered_gb.empty):
        return placeholder_figure("No GB CSS history")

    fig = go.Figure()
    if delivered_gb is not None and not delivered_gb.empty:
        fig.add_trace(go.Bar(
            x=delivered_gb["month"], y=delivered_gb["value"],
            name="GB delivered CSS (50% eff)",
            marker_color=DELIVERED_COLOR, opacity=0.7,
        ))
    if overlays is not None and not overlays.empty:
        fig.add_trace(go.Scatter(
            x=overlays["month"], y=overlays["value"],
            mode="lines+markers", name="GB forward CSS (49.13% eff)",
            line=dict(color=UK_MKT_COLOR, width=2.4), marker=dict(size=5),
        ))
    today = pd.Timestamp.today().normalize()
    fig.add_vline(x=today, line_width=1.5, line_dash="dash",
                  line_color=COLORS["accent"])

    fig.update_layout(**_base_layout(
        "GB CSS \u2014 delivered history vs UK-market forward", height=480))
    fig.update_xaxes(title="Delivery month")
    fig.update_yaxes(title="CSS (€/MWh)")
    return _zero_line(fig)
