"""Layout for Other Nuclear (EQ REMIT heatmap)."""
from __future__ import annotations

import datetime as dt

from dash import dcc, html

from core.styles import COLORS

from .constants import (
    DEFAULT_DAYS_BACK,
    DEFAULT_DAYS_FORWARD,
    RANGE_SLIDER_MAX,
    RANGE_SLIDER_MIN,
    RANGE_SLIDER_STEP,
)


def build_layout() -> html.Div:
    today = dt.date.today()
    return html.Div(
        style={"backgroundColor": COLORS["background"], "minHeight": "100vh"},
        children=[
            html.Div(
                style={
                    "padding": "16px 22px",
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "backgroundColor": COLORS["card_bg"],
                },
                children=[
                    html.Div(
                        [
                            html.Span("Power", style={"color": "#888", "fontSize": "13px"}),
                            html.Span(" / ", style={"margin": "0 8px", "color": "#666"}),
                            html.Span(
                                "Other Nuclear",
                                style={"fontWeight": "600", "color": COLORS["text_primary"]},
                            ),
                        ],
                        style={"marginBottom": "14px"},
                    ),
                    html.Div(
                        style={
                            "display": "flex",
                            "flexWrap": "wrap",
                            "gap": "16px",
                            "alignItems": "flex-end",
                            "marginTop": "12px",
                        },
                        children=[
                            html.Div(
                                [
                                    html.Label(
                                        "Issue date",
                                        style={
                                            "fontSize": "11px",
                                            "fontWeight": "600",
                                            "color": "#6c757d",
                                            "display": "block",
                                            "marginBottom": "4px",
                                        },
                                    ),
                                    dcc.DatePickerSingle(
                                        id="on-issue-date",
                                        date=today,
                                        display_format="YYYY-MM-DD",
                                        first_day_of_week=1,
                                    ),
                                ],
                            ),
                            html.Div(
                                [
                                    html.Label(
                                        "Reference date",
                                        style={
                                            "fontSize": "11px",
                                            "fontWeight": "600",
                                            "color": "#6c757d",
                                            "display": "block",
                                            "marginBottom": "4px",
                                        },
                                    ),
                                    dcc.DatePickerSingle(
                                        id="on-reference-date",
                                        date=None,
                                        display_format="YYYY-MM-DD",
                                        first_day_of_week=1,
                                        clearable=True,
                                        placeholder="Optional",
                                    ),
                                ],
                            ),
                        ],
                    ),
                    html.Div(
                        style={"marginTop": "20px"},
                        children=[
                            html.Label(
                                "Date range (days relative to issue date)",
                                style={
                                    "fontSize": "11px",
                                    "fontWeight": "600",
                                    "color": "#6c757d",
                                    "display": "block",
                                    "marginBottom": "8px",
                                },
                            ),
                            dcc.RangeSlider(
                                id="on-range-slider",
                                min=RANGE_SLIDER_MIN,
                                max=RANGE_SLIDER_MAX,
                                step=RANGE_SLIDER_STEP,
                                value=[-DEFAULT_DAYS_BACK, DEFAULT_DAYS_FORWARD],
                                marks={
                                    i: {"label": str(i), "style": {"color": "#6c757d", "fontSize": "10px"}}
                                    for i in range(RANGE_SLIDER_MIN, RANGE_SLIDER_MAX + 1, 60)
                                },
                                tooltip={"placement": "bottom", "always_visible": True},
                                allowCross=False,
                            ),
                        ],
                    ),
                    dcc.Markdown(
                        id="on-meta",
                        style={"marginTop": "12px", "fontSize": "12px", "color": COLORS["text_secondary"]},
                    ),
                ],
            ),
            dcc.Loading(
                id="on-loading",
                type="circle",
                color=COLORS["accent"],
                children=html.Div(
                    id="on-table-container",
                    style={"padding": "12px 16px 24px"},
                ),
            ),
        ],
    )
