"""Other Nuclear dashboard (EQ REMIT period instances, live)."""
