"""Fetch nuclear REMIT availability from Energy Quantified, with dashboard cache."""
from __future__ import annotations

import datetime as dt
import logging
from typing import Any, Dict, Optional, Tuple

import pandas as pd

from .constants import COUNTRY_EQ_ZONES, DEFAULT_DAYS_BACK, DEFAULT_DAYS_FORWARD

logger = logging.getLogger(__name__)

# Module-level cache populated by ``load_other_nuclear_data`` (via the
# central DataScheduler) and consumed by ``get_cached_default_matrix``.
# Stores the default-window matrix for the current calendar day so that
# the Other Nuclear page loads instantly on first visit.
_DEFAULT_CACHE: Dict[str, Any] = {"issue_date": None, "matrix": None, "meta": None}


def _curve_name(eq_zone: str) -> str:
    return f"{eq_zone.upper()} Nuclear Capacity Available MW REMIT"


def fetch_remit_nuclear_matrix(
    issue_date: dt.date,
    days_back: int = DEFAULT_DAYS_BACK,
    days_forward: int = DEFAULT_DAYS_FORWARD,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Build a matrix: index = calendar date (delivery), columns = country,
    values = mean hourly available MW for that day.

    Uses ``period_instances.latest(..., issued_at_latest=end of issue_date CET)``
    via ``jain_commods.core.cache.data.connectors``.
    """
    from jain_commods.core.cache.data.connectors import (
        get_eq_data_period_instances_issued_as_of,
    )

    begin = issue_date - dt.timedelta(days=days_back)
    end = issue_date + dt.timedelta(days=days_forward)
    meta: Dict[str, Any] = {
        "issue_date": issue_date.isoformat(),
        "delivery_begin": begin.isoformat(),
        "delivery_end": end.isoformat(),
        "errors": {},
    }

    cols: Dict[str, pd.Series] = {}
    for display, eq_tag in COUNTRY_EQ_ZONES:
        curve = _curve_name(eq_tag)
        try:
            df = get_eq_data_period_instances_issued_as_of(
                curve, begin, end, issue_date
            )
            if df is None or df.empty:
                cols[display] = pd.Series(dtype=float)
                meta["errors"][display] = "empty"
                continue
            s = pd.to_numeric(df.iloc[:, 0], errors="coerce")
            ix = pd.to_datetime(s.index)
            if ix.tz is None:
                ix = ix.tz_localize("Europe/Paris")
            else:
                ix = ix.tz_convert("Europe/Paris")
            s.index = ix.tz_localize(None)
            daily = s.resample("1D").mean()
            daily.index = daily.index.normalize()
            cols[display] = daily
        except Exception as exc:
            logger.warning("EQ REMIT nuclear failed for %s: %s", display, exc)
            meta["errors"][display] = str(exc)
            cols[display] = pd.Series(dtype=float)

    mat = pd.DataFrame(cols)
    mat = mat.sort_index()
    if not mat.empty:
        mat.index = pd.to_datetime(mat.index)
        m = (mat.index.date >= begin) & (mat.index.date <= end)
        mat = mat.loc[m]
    return mat, meta


def load_other_nuclear_data() -> Dict[str, Any]:
    """Refresh the cached default-window REMIT matrix for today.

    Called by the central DataScheduler on the cron cadence registered in
    ``portal_app._setup_scheduler``. Populates ``_DEFAULT_CACHE`` so the
    page's first render hits the cache instead of waiting on the EQ API.
    """
    issue = dt.date.today()
    logger.info(
        "Other Nuclear: refreshing REMIT matrix for issue=%s (days_back=%s, days_forward=%s)",
        issue, DEFAULT_DAYS_BACK, DEFAULT_DAYS_FORWARD,
    )
    mat, meta = fetch_remit_nuclear_matrix(
        issue, days_back=DEFAULT_DAYS_BACK, days_forward=DEFAULT_DAYS_FORWARD
    )
    _DEFAULT_CACHE["issue_date"] = issue
    _DEFAULT_CACHE["matrix"] = mat
    _DEFAULT_CACHE["meta"] = meta
    logger.info("Other Nuclear: cached %d delivery dates for %s", len(mat), issue)
    return {"issue_date": issue.isoformat(), "rows": int(len(mat))}


def get_cached_default_matrix(
    issue_date: dt.date,
    days_back: int,
    days_forward: int,
) -> Optional[Tuple[pd.DataFrame, Dict[str, Any]]]:
    """Return the cached matrix only when the request matches the default window for today."""
    if (
        _DEFAULT_CACHE["matrix"] is None
        or _DEFAULT_CACHE["issue_date"] != issue_date
        or days_back != DEFAULT_DAYS_BACK
        or days_forward != DEFAULT_DAYS_FORWARD
    ):
        return None
    return _DEFAULT_CACHE["matrix"], _DEFAULT_CACHE["meta"]
