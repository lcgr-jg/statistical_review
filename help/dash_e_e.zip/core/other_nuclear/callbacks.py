"""Dash callbacks — Other Nuclear EQ REMIT heatmap."""
from __future__ import annotations

import datetime as dt
import logging

import dash_bootstrap_components as dbc
import pandas as pd
from dash import Input, Output, callback, html

from core.styles import COLORS

from .constants import DEFAULT_DAYS_BACK, DEFAULT_DAYS_FORWARD
from .data import fetch_remit_nuclear_matrix, get_cached_default_matrix

logger = logging.getLogger(__name__)

# Country column excluded from the heatmap (FR has its own dedicated page).
EXCLUDED_COLUMNS = ("FR",)


def _parse_date(s: str | None) -> dt.date | None:
    if not s:
        return None
    try:
        return dt.datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None


def _is_weekend(label: object) -> bool:
    try:
        return dt.datetime.strptime(str(label), "%Y-%m-%d").weekday() >= 5
    except Exception:
        return False


def _weekend_index_styles(idx: pd.Index) -> list[str]:
    """Blue band on the delivery-date row labels for Sat/Sun (mirrors Heatmap Balance)."""
    weekend_css = (
        "background-color: #b8c5df !important;"
        "color: #1a1a1a !important;"
        "font-weight: 700 !important;"
        "border-left: 4px solid #5c6bc0 !important;"
        "box-shadow: inset 0 0 0 1px rgba(92,107,192,0.35) !important;"
    )
    return [weekend_css if _is_weekend(x) else "" for x in idx]


def _first_label_after(idx: pd.Index, today: dt.date) -> str | None:
    """First delivery-date label strictly after ``today`` (used for the past/future rule)."""
    for label in idx:
        try:
            d = dt.datetime.strptime(str(label), "%Y-%m-%d").date()
        except ValueError:
            continue
        if d > today:
            return str(label)
    return None


def _past_future_row_border(rule_label: str | None):
    """Styler row callback: dashed border above the first future delivery row."""
    def _apply(row: pd.Series) -> list[str]:
        if rule_label is not None and str(row.name) == rule_label:
            return ["border-top: 3px dashed #333 !important"] * len(row)
        return [""] * len(row)
    return _apply


_TABLE_STYLES = [
    {"selector": "table", "props": [
        ("border-collapse", "collapse"),
        ("font-family", "Calibri, Arial, sans-serif"),
        ("font-size", "13px"),
        ("width", "100%"),
        ("border", "1px solid #ddd"),
    ]},
    {"selector": "th", "props": [
        ("background-color", "#f2f2f2"),
        ("color", "#333"),
        ("border", "1px solid #999"),
        ("padding", "4px 2px"),
        ("text-align", "center"),
        ("font-weight", "bold"),
        ("font-size", "10px"),
    ]},
    {"selector": "td", "props": [
        ("border", "1px solid #ddd"),
        ("padding", "2px"),
        ("text-align", "center"),
        ("font-size", "11px"),
    ]},
    {"selector": "tr:hover", "props": [("background-color", "#f5f5f5")]},
]

_CUSTOM_CSS = """
<style>
    .price-table-container {
        font-family: Calibri, Arial, sans-serif;
        padding: 20px;
        background-color: white;
    }
    .table-row {
        display: flex;
        flex-wrap: wrap;
        gap: 24px;
        align-items: flex-start;
    }
    .table-cell {
        flex: 1 1 480px;
        min-width: 0;
        overflow-x: auto;
    }
    caption {
        caption-side: top;
        font-size: 16px;
        font-weight: bold;
        padding: 10px;
        color: #333;
    }
</style>
"""


def _highlight_nan(val):
    return "background-color: #e0e0e0 !important" if pd.isna(val) else ""


def _drop_excluded(df: pd.DataFrame) -> pd.DataFrame:
    drop = [c for c in EXCLUDED_COLUMNS if c in df.columns]
    return df.drop(columns=drop) if drop else df


def _matrix_to_styled_html(mat: pd.DataFrame, issue_d: dt.date) -> str:
    """Issue-date matrix: per-column ``RdYlGn`` gradient (high availability = green)."""
    if mat is None or mat.empty:
        return ""
    disp = _drop_excluded(mat.copy())
    if disp.empty or len(disp.columns) == 0:
        return ""
    disp.index = disp.index.strftime("%Y-%m-%d")
    rule_label = _first_label_after(disp.index, dt.date.today())

    styler = (
        disp.style
        .apply_index(_weekend_index_styles, axis=0)
        .background_gradient(cmap="RdYlGn", axis=0, vmin=0)
        .apply(_past_future_row_border(rule_label), axis=1)
        .map(_highlight_nan)
        .format("{:,.0f}", na_rep="")
        .set_table_styles(_TABLE_STYLES)
        .set_caption(f"Nuclear Capacity Available (MW) — issue {issue_d}")
        .set_properties(**{"min-width": "35px", "max-width": "50px"})
    )
    return styler.to_html()


def _delta_to_styled_html(
    mat_issue: pd.DataFrame,
    mat_ref: pd.DataFrame,
    issue_d: dt.date,
    ref_d: dt.date,
) -> str:
    """Δ = issue − reference. Per-column diverging gradient centred at 0."""
    if mat_issue is None or mat_issue.empty or mat_ref is None or mat_ref.empty:
        return "<p>Delta unavailable — one of the matrices is empty.</p>"

    common_idx = mat_issue.index.intersection(mat_ref.index)
    common_cols = mat_issue.columns.intersection(mat_ref.columns)
    if len(common_idx) == 0 or len(common_cols) == 0:
        return "<p>No overlapping delivery dates / countries between issue and reference.</p>"

    delta = (
        mat_issue.loc[common_idx, common_cols]
        - mat_ref.loc[common_idx, common_cols]
    )
    delta = _drop_excluded(delta)
    if delta.empty or len(delta.columns) == 0:
        return ""

    disp = delta.copy()
    disp.index = disp.index.strftime("%Y-%m-%d")
    rule_label = _first_label_after(disp.index, dt.date.today())

    styler = disp.style.apply_index(_weekend_index_styles, axis=0)
    for col in disp.columns:
        vals = pd.to_numeric(disp[col], errors="coerce").dropna()
        if vals.empty:
            continue
        max_abs = float(vals.abs().max())
        if max_abs < 1e-6:
            continue
        # Positive Δ = more capacity on issue date = green.
        styler = styler.background_gradient(
            cmap="RdYlGn",
            subset=[col],
            vmin=-max_abs,
            vmax=max_abs,
        )

    styler = (
        styler
        .apply(_past_future_row_border(rule_label), axis=1)
        .map(_highlight_nan)
        .format("{:+,.0f}", na_rep="")
        .set_table_styles(_TABLE_STYLES)
        .set_caption(f"Δ Nuclear Capacity (MW) — issue {issue_d} − reference {ref_d}")
        .set_properties(**{"min-width": "35px", "max-width": "50px"})
    )
    return styler.to_html()


def _wrap_tables(*table_htmls: str) -> str:
    """Assemble one or more rendered tables side-by-side in a single HTML document."""
    cells = "\n".join(
        f'<div class="table-cell">{t}</div>' for t in table_htmls if t
    )
    return f"""
    {_CUSTOM_CSS}
    <div class="price-table-container">
        <div class="table-row">{cells}</div>
    </div>
    """


def _fetch_matrix_with_cache(
    issue_d: dt.date,
    days_back: int,
    days_forward: int,
):
    """Try the in-process default-window cache first, otherwise hit the EQ API."""
    cached = get_cached_default_matrix(issue_d, days_back, days_forward)
    if cached is not None:
        logger.info("Other Nuclear: cache hit for %s (default window)", issue_d)
        return cached
    return fetch_remit_nuclear_matrix(
        issue_d, days_back=days_back, days_forward=days_forward
    )


@callback(
    Output("on-table-container", "children"),
    Output("on-meta", "children"),
    Input("on-issue-date", "date"),
    Input("on-reference-date", "date"),
    Input("on-range-slider", "value"),
)
def _update_other_nuclear(
    issue_s: str | None,
    ref_s: str | None,
    range_value: list[int] | None,
):
    issue_d = _parse_date(issue_s) or dt.date.today()
    ref_d = _parse_date(ref_s)

    if range_value and len(range_value) == 2:
        days_back = max(0, -int(range_value[0]))
        days_forward = max(0, int(range_value[1]))
    else:
        days_back, days_forward = DEFAULT_DAYS_BACK, DEFAULT_DAYS_FORWARD

    try:
        mat_issue, meta = _fetch_matrix_with_cache(issue_d, days_back, days_forward)
    except Exception as exc:
        logger.exception("Other Nuclear fetch failed")
        return (
            dbc.Alert(f"Failed to load EQ data: {exc}", color="danger"),
            f"**Issue date:** `{issue_d}` — error",
        )

    mat_ref: pd.DataFrame | None = None
    ref_error: str | None = None
    if ref_d is not None:
        # Reference window must cover the same delivery dates as the issue
        # window, so we shift the (back, forward) offsets by ``issue - ref``.
        # Total window length stays the same; only the anchor moves.
        shift = (issue_d - ref_d).days
        ref_back = days_back - shift
        ref_fwd = days_forward + shift
        try:
            mat_ref, _ = _fetch_matrix_with_cache(ref_d, ref_back, ref_fwd)
        except Exception as exc:
            logger.exception("Other Nuclear reference fetch failed")
            ref_error = str(exc)

    err = meta.get("errors") or {}
    err_parts = [f"- **{k}:** {v}" for k, v in err.items() if v and v != "empty"]
    meta_md = (
        f"**Issue date:** `{issue_d}` · **Delivery window:** `{meta.get('delivery_begin')}` → "
        f"`{meta.get('delivery_end')}` · **Rows:** {len(mat_issue)}"
    )
    if ref_d is not None:
        if ref_error:
            meta_md += f" · **Reference date:** `{ref_d}` — error: {ref_error}"
        else:
            meta_md += f" · **Reference date:** `{ref_d}`"
    if err_parts:
        meta_md += "\n\n**Zone notes:**\n" + "\n".join(err_parts[:12])

    issue_table = _matrix_to_styled_html(mat_issue, issue_d)
    tables = [issue_table]
    if ref_d is not None and mat_ref is not None:
        tables.append(_delta_to_styled_html(mat_issue, mat_ref, issue_d, ref_d))

    iframe = html.Iframe(
        srcDoc=_wrap_tables(*tables),
        style={
            "width": "100%",
            "height": "calc(100vh - 320px)",
            "minHeight": "480px",
            "border": f"1px solid {COLORS.get('border', '#dee2e6')}",
            "borderRadius": "4px",
            "backgroundColor": "white",
        },
        sandbox="allow-same-origin",
    )
    return iframe, meta_md
