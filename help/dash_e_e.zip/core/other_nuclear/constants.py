"""Other Nuclear — EQ REMIT nuclear availability heatmap (live API)."""

PAGE_PATH = "/power/other_nuclear"
PAGE_NAME = "Other Nuclear"
PAGE_TITLE = "Other Nuclear | JG Power Dashboard"
PAGE_ORDER = 22  # after Microstructure (21); Hydro also uses 19 in this repo

# (column label, EQ / REMIT zone tag for curve name "{TAG} Nuclear Capacity Available MW REMIT")
# GB uses EQ tag GB (not UK) per jain_commods.get_zone_eq convention.
# Order matches the region grouping CWE → UK → Iberia → CEE → SEE → Nordics.
# FR is intentionally excluded (it has its own dedicated dashboard).
COUNTRY_EQ_ZONES: tuple[tuple[str, str], ...] = (
    # CWE (DE excluded — last reactors shut down April 2023)
    ("BE", "be"),
    ("NL", "nl"),
    ("CH", "ch"),
    # UK
    ("GB", "gb"),
    # Iberia
    ("ES", "es"),
    # CEE
    ("CZ", "cz"),
    ("HU", "hu"),
    ("SK", "sk"),
    # SEE
    ("BG", "bg"),
    ("RO", "ro"),
    # Nordics
    ("FI", "fi"),
    ("SE", "se"),
)

DEFAULT_DAYS_BACK = 14
DEFAULT_DAYS_FORWARD = 30

# Date-range slider bounds (offsets from issue date, in days).
RANGE_SLIDER_MIN = -180
RANGE_SLIDER_MAX = 365
RANGE_SLIDER_STEP = 5
