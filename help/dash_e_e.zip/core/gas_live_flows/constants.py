"""EU Gas Balance — Live Flows page constants."""
from __future__ import annotations

PAGE_PATH = "/power/gas_balance/live_flows"
PAGE_NAME = "Live Flows"
PAGE_TITLE = "EU Live Gas Flows | JG Power Dashboard"
PAGE_ORDER = 74

# Daily table lookback (matches Storage Summary).
TABLE_N_DAYS = 14
TABLE_N_DAYS_MIN = 7
TABLE_N_DAYS_MAX = 60

# NWE+UK+IT LNG withdrawal subset of ``lng_country`` — same assets as the
# morning_flows REGAS table. Labels follow CE metadata (GB, not the email's
# positional UK/IT swap).
REGAS_COUNTRIES: tuple[str, ...] = ("BE", "DE", "FR", "GB", "IT", "NL")

# Display order for the FLOWS table (CE netFlow points).
FLOW_COLUMNS: tuple[str, ...] = (
    "UA Total Imports",
    "TAP",
    "Mazara",
    "Turkstream",
    "Velke",
    "UKCS",
    "NL Prodn",
    "NCS",
)

US_LIQ_COL = "US Liq [bcf/d]"
CA_LIQ_COL = "CA Liq [bcf/d]"

# Bloomberg liquefaction feedgas (PX_LAST is cubic feet; divide by 1e6 → bcf/d).
US_TERMINALS: dict[str, str] = {
    "GSLIQCLC Index": "Calcasieu",
    "GSLIQCAM Index": "Cameron",
    "GSLIQCCH Index": "Corpus",
    "GSLIQCOV Index": "Cove",
    "GSLIQELB Index": "Elba",
    "GSLIQGLF Index": "Golden",
    "GSLIQFPT Index": "Freeport",
    "GSLIQPLQ Index": "Plaq",
    "GSLIQSPI Index": "Sabine",
    "GSLIQTOT Index": "Total",
}
CANADA_TERMINAL = "GSLIQLNC Index"
BBG_HIST_START = (2017, 10, 1)
# Fallback if jain_commods unit table is unavailable (~bcf/d → mcm).
BCF_TO_MCM_FALLBACK = 28.316846592

# Column-click history panel.
COL_CLICK_TYPE = "gas-live-flows-col"
SECTION_TITLES: dict[str, str] = {
    "regas": "Regas",
    "flows": "Flows",
    "uslng": "US LNG Feedgas Breakdown",
}
GRANULARITY_DAILY = "daily"
GRANULARITY_MONTHLY = "monthly"
GRANULARITY_OPTIONS = [
    {"label": "Daily", "value": GRANULARITY_DAILY},
    {"label": "Monthly", "value": GRANULARITY_MONTHLY},
]
DEFAULT_GRANULARITY = GRANULARITY_DAILY
MA_WINDOWS: tuple[int, ...] = (7, 14, 21, 28)
DEFAULT_MA_WINDOW = 7
MONTHLY_HISTORY_MONTHS = 18
YOY_MAX_YEARS = 8
