"""Live Flows — CE cache readers plus on-demand Bloomberg US/CA feedgas."""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.cache import dashboard_cache
from core.gas_data_ce.constants import (
    CE_DATASETS,
    FLOWS_DATASET_KEY,
    LNG_DATASET_KEY,
    SOURCE_NAME,
)
from core.gas_live_flows.constants import (
    BBG_HIST_START,
    BCF_TO_MCM_FALLBACK,
    CA_LIQ_COL,
    CANADA_TERMINAL,
    FLOW_COLUMNS,
    MONTHLY_HISTORY_MONTHS,
    REGAS_COUNTRIES,
    US_LIQ_COL,
    US_TERMINALS,
)
from core.gas_storage_summary.data import format_ce_refresh_age, get_ce_last_refresh

logger = logging.getLogger(__name__)

_flows_lock = threading.Lock()
_flows_fallback: dict[str, Any] | None = None

_bbg_lock = threading.Lock()
_bbg_payload: dict[str, Any] | None = None
_bbg_fetched_at: float | None = None
_BBG_TTL_S = 6 * 60 * 60


def get_cached_ce_payload() -> dict[str, Any]:
    """Return the full ``gas_data_ce`` cache dict (raises if empty)."""
    data: dict[str, Any] | None = dashboard_cache.get_data(SOURCE_NAME)
    if not data or not isinstance(data, dict):
        raise RuntimeError(
            "Commodity Essentials gas cache is empty. "
            "Wait for warm-up to finish, or check CE_USER / CE_PASS and restart."
        )
    return data


def _dataset_payload(dataset_key: str) -> dict[str, Any] | None:
    try:
        cached = get_cached_ce_payload()
    except RuntimeError:
        return None
    payload = (cached.get("datasets") or {}).get(dataset_key)
    return payload if isinstance(payload, dict) else None


def _variable_frame(payload: dict[str, Any], *names: str) -> pd.DataFrame:
    by_var = payload.get("by_variable") or {}
    wanted = {n.lower() for n in names}
    for key, frame in by_var.items():
        if str(key).lower() in wanted and isinstance(frame, pd.DataFrame):
            out = frame.copy()
            out.index = pd.to_datetime(out.index)
            return out.sort_index()
    return pd.DataFrame()


def get_cached_regas() -> pd.DataFrame:
    """NWE+UK+IT LNG withdrawal (mcm/d) with a recomputed Total."""
    payload = _dataset_payload(LNG_DATASET_KEY)
    if not payload:
        raise RuntimeError(
            "CE cache has no LNG country (regas) dataset. "
            "Wait for Commodity Essentials warm-up, then click Refresh."
        )
    df = _variable_frame(payload, "withdrawal")
    cols = [c for c in REGAS_COUNTRIES if c in df.columns]
    if not cols:
        raise RuntimeError(
            "CE LNG cache has no withdrawal series for BE/DE/FR/GB/IT/NL."
        )
    out = df[cols].fillna(0)
    out["Total"] = out.sum(axis=1)
    return out


def _expected_flow_assets() -> dict[str, int]:
    return dict(CE_DATASETS[FLOWS_DATASET_KEY]["assets"])


def _flows_payload_current(payload: dict[str, Any] | None) -> bool:
    """False if missing or fetched with the old reversed asset-id map."""
    if not payload:
        return False
    return payload.get("assets") == _expected_flow_assets()


def _fetch_flows_fallback() -> dict[str, Any]:
    """Pull just the key-flows dataset if the scheduled cache is stale."""
    global _flows_fallback
    with _flows_lock:
        if _flows_payload_current(_flows_fallback):
            return _flows_fallback
        logger.info(
            "gas_flows_key missing or using stale asset ids — fetching from Commodity Essentials"
        )
        from core.gas_data_ce.data import fetch_ce_opdata

        _flows_fallback = fetch_ce_opdata(FLOWS_DATASET_KEY)
        return _flows_fallback


def get_cached_flows() -> pd.DataFrame:
    """Key EU pipeline / production netFlow frame (mcm/d, no Total)."""
    payload = _dataset_payload(FLOWS_DATASET_KEY)
    if not _flows_payload_current(payload):
        try:
            payload = _fetch_flows_fallback()
        except Exception as exc:
            raise RuntimeError(
                "CE cache has no current key-flows dataset and on-demand fetch failed. "
                "Wait for Commodity Essentials warm-up, or check CE_USER / CE_PASS."
            ) from exc

    df = _variable_frame(payload, "netFlow", "netflow")
    if df.empty:
        raise RuntimeError(
            "CE key-flows cache has no netFlow data. "
            "Check the Commodity Essentials entry in Data Source Status."
        )
    cols = [c for c in FLOW_COLUMNS if c in df.columns]
    if not cols:
        raise RuntimeError(
            "CE key-flows cache is missing expected interconnect columns."
        )
    return df[cols].fillna(0)


def _bcf_to_mcm() -> float:
    try:
        from jain_commods.fundamental.units import (
            get_conversion_factor,
            unit_conversion_table,
        )

        return float(
            get_conversion_factor("bcf/d", "mcm", unit_conversion_table)
        )
    except Exception:
        logger.warning(
            "unit conversion table unavailable — using bcf/d→mcm fallback %s",
            BCF_TO_MCM_FALLBACK,
        )
        return BCF_TO_MCM_FALLBACK


def _fetch_bbg_feedgas() -> dict[str, Any]:
    """Bloomberg US terminal + Canada liquefaction, bcf/d, full history."""
    from jain_commods.core.interfaces.bloomberg import BBGQuery

    start_date = datetime(*BBG_HIST_START)
    end_date = datetime.today()
    session = BBGQuery(p_on_server=True)
    us_liq = session.fetch_hist(
        list(US_TERMINALS.keys()), ["PX_LAST"], start_date, end_date
    )
    canada_liq = session.fetch_hist(
        [CANADA_TERMINAL], ["PX_LAST"], start_date, end_date
    )
    if us_liq is None or us_liq.empty:
        raise RuntimeError("Bloomberg returned no US liquefaction history.")

    us_liq = us_liq.copy()
    us_liq.columns = [
        US_TERMINALS.get(str(c).replace("_PX_LAST", ""), str(c))
        for c in us_liq.columns
    ]
    us_liq.index = pd.to_datetime(us_liq.index)
    us_liq = us_liq / 1_000_000.0

    terminals = [c for c in us_liq.columns if c != "Total"]
    ordered = sorted(terminals) + (["Total"] if "Total" in us_liq.columns else [])
    us_liq = us_liq[ordered]

    ca = None
    if canada_liq is not None and not canada_liq.empty:
        ca = canada_liq.copy()
        ca.columns = ["CA"]
        ca.index = pd.to_datetime(ca.index)
        ca = ca["CA"] / 1_000_000.0
        ca.name = "CA"

    return {
        "us_liq": us_liq.sort_index(),
        "ca_liq": ca.sort_index() if ca is not None else None,
        "bcf_to_mcm": _bcf_to_mcm(),
        "fetched_at": datetime.now(timezone.utc),
        "error": None,
    }


def get_bbg_feedgas(*, force: bool = False) -> dict[str, Any]:
    """Memoised Bloomberg feedgas (does not close the shared BPIPE session)."""
    global _bbg_payload, _bbg_fetched_at
    now = time.monotonic()
    with _bbg_lock:
        if (
            not force
            and _bbg_payload is not None
            and _bbg_fetched_at is not None
            and now - _bbg_fetched_at < _BBG_TTL_S
            and _bbg_payload.get("error") is None
        ):
            return _bbg_payload
        try:
            _bbg_payload = _fetch_bbg_feedgas()
            _bbg_fetched_at = now
        except Exception as exc:
            logger.warning("Bloomberg US/CA feedgas fetch failed: %s", exc)
            _bbg_payload = {
                "us_liq": None,
                "ca_liq": None,
                "bcf_to_mcm": _bcf_to_mcm(),
                "fetched_at": None,
                "error": str(exc),
            }
            _bbg_fetched_at = now
        return _bbg_payload


def monthly_history(
    series: pd.Series,
    n_months: int | None = None,
) -> pd.DataFrame:
    """Average daily rate by calendar month, oldest first.

    The latest month is flagged ``is_mtd`` when it is not a complete month.
    ``mom`` is the change vs the previous calendar month's average.
    """
    empty = pd.DataFrame(
        columns=["label", "value", "mom", "is_mtd", "n_days"]
    )
    if series is None:
        return empty
    s = pd.to_numeric(series, errors="coerce")
    s.index = pd.to_datetime(s.index)
    s = s.sort_index().dropna()
    if s.empty:
        return empty
    if n_months is None:
        n_months = MONTHLY_HISTORY_MONTHS

    monthly = s.resample("MS").mean()
    counts = s.resample("MS").count()
    latest = pd.Timestamp(s.index.max()).normalize()
    month_start = pd.Timestamp(latest.year, latest.month, 1)
    month_end = month_start + pd.offsets.MonthEnd(0)
    incomplete = latest < pd.Timestamp(month_end).normalize()

    out = pd.DataFrame({"value": monthly, "n_days": counts})
    out["mom"] = out["value"].diff()
    out["is_mtd"] = False
    if incomplete and month_start in out.index:
        out.loc[month_start, "is_mtd"] = True
    out = out.dropna(subset=["value"]).sort_index(ascending=True)
    if n_months:
        out = out.tail(int(n_months))
    out["label"] = [
        f"{idx.strftime('%b-%Y')} MTD" if bool(row["is_mtd"]) else idx.strftime("%b-%Y")
        for idx, row in out.iterrows()
    ]
    return out


def load_series(
    source: str,
    column: str,
    unit: str = "mcm",
) -> tuple[pd.Series, str]:
    """Daily series for a clicked Live Flows column, plus a unit label."""
    source = (source or "").strip().lower()
    unit = (unit or "mcm").strip().lower()
    column = str(column)

    if source == "regas":
        df = get_cached_regas()
        if column not in df.columns:
            raise KeyError(f"No regas series named {column!r}")
        return df[column].astype(float), "mcm/d"

    if source == "flows":
        if column == US_LIQ_COL:
            bbg = get_bbg_feedgas()
            us_liq = bbg.get("us_liq")
            if us_liq is None or "Total" not in us_liq.columns:
                raise RuntimeError("Bloomberg US liquefaction is not available.")
            return us_liq["Total"].astype(float), "bcf/d"
        if column == CA_LIQ_COL:
            bbg = get_bbg_feedgas()
            ca = bbg.get("ca_liq")
            if ca is None or getattr(ca, "empty", True):
                raise RuntimeError("Bloomberg Canada liquefaction is not available.")
            return ca.astype(float), "bcf/d"
        df = get_cached_flows()
        if column not in df.columns:
            raise KeyError(f"No flows series named {column!r}")
        return df[column].astype(float), "mcm/d"

    if source == "uslng":
        bbg = get_bbg_feedgas()
        us_liq = bbg.get("us_liq")
        if us_liq is None or us_liq.empty or column not in us_liq.columns:
            raise KeyError(f"No US LNG series named {column!r}")
        series = us_liq[column].astype(float)
        if unit == "mcm":
            factor = float(bbg.get("bcf_to_mcm") or BCF_TO_MCM_FALLBACK)
            return series * factor, "mcm/d"
        return series, "bcf/d"

    raise KeyError(f"Unknown Live Flows source {source!r}")


def us_liq_ath(us_liq: pd.DataFrame) -> pd.Series | None:
    """Per-terminal ATH excluding the latest published day.

    Bloomberg feedgas prints are negative; the all-time high is the column
    minimum (most negative), matching the EU Gas Flows email.
    """
    if us_liq is None or us_liq.empty or len(us_liq) < 2:
        return None
    ath = us_liq.iloc[:-1].min(numeric_only=True)
    ath.name = "ATH"
    return ath


__all__ = [
    "format_ce_refresh_age",
    "get_bbg_feedgas",
    "get_cached_ce_payload",
    "get_cached_flows",
    "get_cached_regas",
    "get_ce_last_refresh",
    "load_series",
    "monthly_history",
    "us_liq_ath",
]
