"""Year-on-year Live Flows chart (calendar Jan–Dec overlay)."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
import plotly.graph_objects as go

from core.gas_live_flows.constants import (
    DEFAULT_MA_WINDOW,
    GRANULARITY_DAILY,
    GRANULARITY_MONTHLY,
    YOY_MAX_YEARS,
)
from core.styles import CHART_COLORS, COLORS

_MONTH_TICKS = list(range(1, 13))
_MONTH_LABELS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]
_DOY_TICKS = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]


def _empty_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
        font={"size": 14, "color": "#888"},
    )
    fig.update_layout(
        height=420,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["card_bg"],
        margin=dict(t=30, b=40, l=50, r=20),
    )
    return fig


def _year_color(offset_from_current: int) -> str:
    palette = CHART_COLORS or ["#4a9eff"]
    return palette[offset_from_current % len(palette)]


def build_yoy_chart(
    series: pd.Series,
    *,
    granularity: str = GRANULARITY_DAILY,
    ma_window: int = DEFAULT_MA_WINDOW,
    unit_label: str = "mcm/d",
    title: str = "",
    to_date: datetime | pd.Timestamp | None = None,
) -> go.Figure:
    """Overlay calendar years on a Jan–Dec x-axis (daily or monthly)."""
    if series is None or series.empty:
        return _empty_fig("Click a column to plot history.")

    s = pd.to_numeric(series, errors="coerce")
    s.index = pd.to_datetime(s.index)
    s = s.sort_index().dropna()
    if s.empty:
        return _empty_fig("No history for this series.")

    cap = pd.Timestamp(to_date or datetime.now()).normalize()
    s = s.loc[:cap]
    if s.empty:
        return _empty_fig("No history on or before today.")

    current_year = int(s.index.max().year)
    years = sorted({int(y) for y in s.index.year.unique()})
    years = [y for y in years if current_year - YOY_MAX_YEARS < y <= current_year]
    if not years:
        return _empty_fig("No history for this series.")

    daily = granularity != GRANULARITY_MONTHLY
    try:
        window = int(ma_window)
    except (TypeError, ValueError):
        window = DEFAULT_MA_WINDOW
    window = max(1, window)

    fig = go.Figure()
    ma_full = (
        s.rolling(window=window, min_periods=max(1, window // 2)).mean()
        if daily
        else None
    )

    for year in years:
        is_current = year == current_year
        offset = current_year - year
        color = _year_color(offset)
        width = 2.6 if is_current else 1.3
        opacity = 1.0 if is_current else 0.7
        year_s = s[s.index.year == year]
        if year_s.empty:
            continue

        if daily:
            x = year_s.index.dayofyear.astype(int)
            fig.add_trace(
                go.Scatter(
                    x=x,
                    y=year_s.values,
                    mode="lines",
                    name=str(year),
                    legendgroup=str(year),
                    showlegend=False,
                    line=dict(color=color, width=0.9),
                    opacity=0.28,
                    customdata=year_s.index.strftime("%d-%b"),
                    hovertemplate=(
                        f"{year} %{{customdata}} · %{{y:.1f}} {unit_label}"
                        "<extra></extra>"
                    ),
                )
            )
            if ma_full is not None:
                year_ma = ma_full[ma_full.index.year == year].dropna()
                if not year_ma.empty:
                    fig.add_trace(
                        go.Scatter(
                            x=year_ma.index.dayofyear.astype(int),
                            y=year_ma.values,
                            mode="lines",
                            name=str(year),
                            legendgroup=str(year),
                            line=dict(color=color, width=width),
                            opacity=opacity,
                            customdata=year_ma.index.strftime("%d-%b"),
                            hovertemplate=(
                                f"{year} {window}d MA · %{{customdata}} · "
                                f"%{{y:.1f}} {unit_label}<extra></extra>"
                            ),
                        )
                    )
        else:
            monthly = year_s.resample("MS").mean()
            fig.add_trace(
                go.Scatter(
                    x=monthly.index.month.astype(int),
                    y=monthly.values,
                    mode="lines+markers",
                    name=str(year),
                    legendgroup=str(year),
                    line=dict(color=color, width=width),
                    opacity=opacity,
                    marker=dict(size=6 if is_current else 5),
                    customdata=monthly.index.strftime("%b-%Y"),
                    hovertemplate=(
                        f"%{{customdata}} · %{{y:.1f}} {unit_label}<extra></extra>"
                    ),
                )
            )

    fig.update_layout(
        title=dict(text=title, font=dict(size=13, color=COLORS["text_primary"])),
        height=460,
        paper_bgcolor=COLORS["card_bg"],
        plot_bgcolor=COLORS["chart_bg"],
        margin=dict(t=36, b=84, l=52, r=16),
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.22,
            x=0.5,
            xanchor="center",
        ),
        xaxis=dict(
            tickmode="array",
            tickvals=_DOY_TICKS if daily else _MONTH_TICKS,
            ticktext=_MONTH_LABELS,
            range=[1, 366] if daily else [0.5, 12.5],
            showgrid=True,
            gridcolor=COLORS["border_light"],
            zeroline=False,
        ),
        yaxis=dict(
            title=unit_label,
            showgrid=True,
            gridcolor=COLORS["border_light"],
            zeroline=False,
        ),
        hovermode="closest",
    )
    return fig
