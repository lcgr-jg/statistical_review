"""EU Gas Balance — Live Flows page package."""
from .layout import build_layout

__all__ = ["build_layout"]
