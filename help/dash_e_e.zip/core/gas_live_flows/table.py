"""HTML tables for the Live Flows page (REGAS / FLOWS / US LNG feedgas)."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
from dash import html

from core.gas_live_flows.constants import (
    CA_LIQ_COL,
    COL_CLICK_TYPE,
    FLOW_COLUMNS,
    REGAS_COUNTRIES,
    TABLE_N_DAYS,
    US_LIQ_COL,
)
from core.styles import COLORS

_TH = {
    "padding": "6px 8px",
    "textAlign": "center",
    "backgroundColor": COLORS["table_header_bg"],
    "color": COLORS["text_dark"],
    "fontWeight": "600",
    "border": f"1px solid {COLORS['border_light']}",
    "fontSize": "11px",
    "whiteSpace": "nowrap",
}

_TD = {
    "padding": "4px 8px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "color": COLORS["text_primary"],
    "whiteSpace": "nowrap",
}


def _col_id(source: str, series: str, unit: str, row: str) -> dict:
    return {
        "type": COL_CLICK_TYPE,
        "src": str(source),
        "col": str(series),
        "unit": str(unit),
        "row": str(row),
    }


def _is_selected(
    selected: dict | None, source: str, series: str, unit: str
) -> bool:
    if not selected:
        return False
    return (
        selected.get("src") == source
        and selected.get("col") == series
        and selected.get("unit") == unit
    )


def slice_last_n_days(
    df: pd.DataFrame,
    n_days: int = TABLE_N_DAYS,
    to_date: datetime | pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Keep rows in the last *n_days* calendar days through the latest print."""
    if df is None or df.empty:
        return pd.DataFrame()
    out = df.copy()
    out.index = pd.to_datetime(out.index)
    out = out.sort_index()
    latest = out.index.max()
    if to_date is not None:
        cap = pd.Timestamp(to_date).normalize()
        if latest > cap:
            clipped = out.loc[:cap]
            if clipped.empty:
                return pd.DataFrame()
            latest = clipped.index.max()
            out = clipped
    start = latest - pd.Timedelta(days=int(n_days) - 1)
    return out.loc[start:latest]


def _fmt(value, precision: int) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    try:
        num = float(value)
    except (TypeError, ValueError):
        return str(value)
    if precision <= 0:
        return f"{num:,.0f}"
    return f"{num:,.{precision}f}"


def _empty(message: str) -> html.Div:
    return html.Div(
        message,
        style={"color": COLORS["text_muted"], "fontSize": "13px"},
    )


def build_history_table(
    df: pd.DataFrame,
    *,
    columns: list[str] | None = None,
    n_days: int = TABLE_N_DAYS,
    default_precision: int = 0,
    col_precision: dict[str, int] | None = None,
    leading_rows: list[tuple[str, pd.Series]] | None = None,
    index_label: str = "Date",
    bold_cols: list[str] | None = None,
    footnote: str = "",
    to_date: datetime | pd.Timestamp | None = None,
    highlight_weekends: bool = True,
    click_source: str | None = None,
    click_unit: str = "mcm",
    selected: dict | None = None,
    col_units: dict[str, str] | None = None,
) -> html.Div:
    """Portal-styled daily history table with optional leading summary rows."""
    if df is None or df.empty:
        return _empty("No data available.")

    sliced = slice_last_n_days(df, n_days=n_days, to_date=to_date)
    if sliced.empty:
        return _empty("No data in the selected history window.")

    cols = list(columns) if columns else [c for c in sliced.columns]
    cols = [c for c in cols if c in sliced.columns]
    if not cols:
        return _empty("No columns to display.")

    precision = col_precision or {}
    bold = set(bold_cols or [])
    units = col_units or {}

    def _unit_for(col: str) -> str:
        return units.get(col, click_unit)

    def _th_style(col: str) -> dict:
        style = {**_TH, "cursor": "pointer"} if click_source else dict(_TH)
        if click_source and _is_selected(selected, click_source, col, _unit_for(col)):
            style = {
                **style,
                "backgroundColor": COLORS["accent"],
                "color": "#ffffff",
            }
        return style

    def _td_style(col: str, *, weight: str, extra: dict | None = None) -> dict:
        style = {**_TD, "fontWeight": weight, "textAlign": "right"}
        if click_source:
            style["cursor"] = "pointer"
        if click_source and _is_selected(selected, click_source, col, _unit_for(col)):
            style["backgroundColor"] = "rgba(78, 115, 138, 0.12)"
        if extra:
            style.update(extra)
        return style

    header = html.Tr(
        [
            html.Th(index_label, style={**_TH, "textAlign": "left"}),
            *[
                html.Th(
                    c,
                    id=_col_id(click_source, c, _unit_for(c), "hdr"),
                    n_clicks=0,
                    title="Click to view monthly history",
                    style=_th_style(c),
                )
                if click_source
                else html.Th(c, style=_TH)
                for c in cols
            ],
        ]
    )

    rows: list = []

    for label, series in leading_rows or []:
        cells = [
            html.Td(
                label,
                style={
                    **_TD,
                    "textAlign": "left",
                    "fontWeight": "600",
                    "color": COLORS["text_muted"],
                },
            )
        ]
        for col in cols:
            prec = precision.get(col, default_precision)
            val = series[col] if col in series.index else None
            extra = {"fontWeight": "600" if col in bold else "400", "color": COLORS["text_muted"]}
            td_kwargs: dict = {
                "children": _fmt(val, prec),
                "style": _td_style(col, weight=extra["fontWeight"], extra={"color": extra["color"]}),
            }
            if click_source:
                td_kwargs["id"] = _col_id(
                    click_source, col, _unit_for(col), f"lead-{label}"
                )
                td_kwargs["n_clicks"] = 0
            cells.append(html.Td(**td_kwargs))
        rows.append(
            html.Tr(
                cells,
                style={"backgroundColor": COLORS["card_bg_alt"]},
            )
        )

    for date, row in sliced.iterrows():
        is_weekend = bool(highlight_weekends and pd.Timestamp(date).dayofweek >= 5)
        bg = COLORS["card_bg_alt"] if is_weekend else COLORS["card_bg"]
        cells = [
            html.Td(
                pd.Timestamp(date).strftime("%d-%b-%Y"),
                style={**_TD, "whiteSpace": "nowrap", "textAlign": "left"},
            )
        ]
        for col in cols:
            prec = precision.get(col, default_precision)
            weight = "600" if col in bold else "400"
            td_kwargs = {
                "children": _fmt(row.get(col), prec),
                "style": _td_style(col, weight=weight),
            }
            if click_source:
                td_kwargs["id"] = _col_id(
                    click_source,
                    col,
                    _unit_for(col),
                    pd.Timestamp(date).strftime("%Y-%m-%d"),
                )
                td_kwargs["n_clicks"] = 0
            cells.append(html.Td(**td_kwargs))
        rows.append(html.Tr(cells, style={"backgroundColor": bg}))

    children: list = [
        html.Table(
            [html.Thead(header), html.Tbody(rows)],
            style={
                "borderCollapse": "collapse",
                "width": "auto",
                "tableLayout": "auto",
                "fontSize": "12px",
                "fontFamily": "Calibri, Arial, sans-serif",
            },
        )
    ]
    if footnote:
        children.append(
            html.P(
                footnote,
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "marginTop": "8px",
                    "fontStyle": "italic",
                    "maxWidth": "720px",
                },
            )
        )
    return html.Div(
        children,
        style={"overflowX": "auto", "display": "inline-block", "maxWidth": "100%"},
    )


def build_regas_table(
    df: pd.DataFrame,
    n_days: int = TABLE_N_DAYS,
    to_date: datetime | pd.Timestamp | None = None,
    selected: dict | None = None,
) -> html.Div:
    cols = [c for c in (*REGAS_COUNTRIES, "Total") if c in (df.columns if df is not None else [])]
    return build_history_table(
        df,
        columns=cols,
        n_days=n_days,
        default_precision=0,
        bold_cols=["Total"],
        footnote="Values in mcm/d. Shaded rows = weekends. "
        "Click a column to view monthly history and a year-on-year chart. "
        "If today's noms = 0 they are likely not nominated yet.",
        to_date=to_date,
        click_source="regas",
        click_unit="mcm",
        selected=selected,
    )


def build_flows_table(
    df_flows: pd.DataFrame,
    *,
    us_liq: pd.Series | None = None,
    ca_liq: pd.Series | None = None,
    n_days: int = TABLE_N_DAYS,
    to_date: datetime | pd.Timestamp | None = None,
    selected: dict | None = None,
) -> html.Div:
    df = df_flows.copy() if df_flows is not None else pd.DataFrame()
    if us_liq is not None and not us_liq.empty:
        aligned = us_liq.copy()
        aligned.index = pd.to_datetime(aligned.index)
        aligned.name = US_LIQ_COL
        df = df.join(aligned, how="left")
    if ca_liq is not None and not ca_liq.empty:
        aligned = ca_liq.copy()
        aligned.index = pd.to_datetime(aligned.index)
        aligned.name = CA_LIQ_COL
        df = df.join(aligned, how="left")

    cols = [c for c in FLOW_COLUMNS if c in df.columns]
    if US_LIQ_COL in df.columns:
        cols.append(US_LIQ_COL)
    if CA_LIQ_COL in df.columns:
        cols.append(CA_LIQ_COL)

    return build_history_table(
        df,
        columns=cols,
        n_days=n_days,
        default_precision=0,
        col_precision={US_LIQ_COL: 1, CA_LIQ_COL: 1},
        footnote="CE flows in mcm/d. US / CA liquefaction in bcf/d from Bloomberg. "
        "Click a column to view monthly history. Shaded rows = weekends.",
        to_date=to_date,
        click_source="flows",
        click_unit="mcm",
        selected=selected,
        col_units={US_LIQ_COL: "bcf", CA_LIQ_COL: "bcf"},
    )


def build_us_lng_tables(
    us_liq: pd.DataFrame | None,
    *,
    bcf_to_mcm: float,
    n_days: int = TABLE_N_DAYS,
    to_date: datetime | pd.Timestamp | None = None,
    ath: pd.Series | None = None,
    selected: dict | None = None,
) -> html.Div:
    if us_liq is None or us_liq.empty:
        return _empty("Bloomberg US liquefaction data is not available.")

    leading = [("ATH", ath)] if ath is not None and not ath.empty else None
    bcf_table = build_history_table(
        us_liq,
        n_days=n_days,
        default_precision=1,
        leading_rows=leading,
        index_label="bcf/d",
        bold_cols=["Total"],
        to_date=to_date,
        click_source="uslng",
        click_unit="bcf",
        selected=selected,
        footnote="Click a terminal column for monthly history (bcf/d).",
    )
    mcm = us_liq * float(bcf_to_mcm)
    ath_mcm = (ath * float(bcf_to_mcm)) if ath is not None else None
    leading_mcm = (
        [("ATH", ath_mcm)] if ath_mcm is not None and not ath_mcm.empty else None
    )
    mcm_table = build_history_table(
        mcm,
        n_days=n_days,
        default_precision=0,
        leading_rows=leading_mcm,
        index_label="mcm/d",
        bold_cols=["Total"],
        to_date=to_date,
        click_source="uslng",
        click_unit="mcm",
        selected=selected,
        footnote="Click a terminal column for monthly history (mcm/d).",
    )
    return html.Div(
        [
            html.Div(bcf_table, style={"flex": "0 1 auto"}),
            html.Div(style={"width": "16px"}),
            html.Div(mcm_table, style={"flex": "0 1 auto"}),
        ],
        style={
            "display": "flex",
            "flexWrap": "wrap",
            "alignItems": "flex-start",
            "gap": "0",
        },
    )


def build_monthly_history_table(
    history: pd.DataFrame,
    *,
    unit_label: str = "mcm/d",
    precision: int = 0,
) -> html.Div:
    """Recent monthly averages with MTD and month-on-month change."""
    if history is None or history.empty:
        return _empty("No monthly history for this series.")

    header = html.Tr(
        [
            html.Th("Month", style={**_TH, "textAlign": "left"}),
            html.Th(unit_label, style=_TH),
            html.Th("delta", style=_TH),
        ]
    )
    rows = []
    for i, (_, row) in enumerate(history.iterrows()):
        bg = COLORS["card_bg_alt"] if i % 2 else COLORS["card_bg"]
        mom = row.get("mom")
        if mom is None or (isinstance(mom, float) and pd.isna(mom)):
            mom_txt = "–"
            mom_color = COLORS["text_muted"]
        else:
            mom_txt = f"{float(mom):+.{precision}f}" if precision else f"{float(mom):+,.0f}"
            if float(mom) > 0:
                mom_color = COLORS["accent_green"]
            elif float(mom) < 0:
                mom_color = COLORS["danger"]
            else:
                mom_color = COLORS["text_primary"]
        weight = "600" if bool(row.get("is_mtd")) else "400"
        rows.append(
            html.Tr(
                [
                    html.Td(
                        str(row.get("label") or ""),
                        style={**_TD, "textAlign": "left", "fontWeight": weight},
                    ),
                    html.Td(
                        _fmt(row.get("value"), precision),
                        style={**_TD, "textAlign": "right", "fontWeight": weight},
                    ),
                    html.Td(
                        mom_txt,
                        style={**_TD, "textAlign": "right", "color": mom_color},
                    ),
                ],
                style={"backgroundColor": bg},
            )
        )
    return html.Div(
        [
            html.Table(
                [html.Thead(header), html.Tbody(rows)],
                style={
                    "borderCollapse": "collapse",
                    "width": "auto",
                    "tableLayout": "auto",
                    "fontSize": "12px",
                    "fontFamily": "Calibri, Arial, sans-serif",
                },
            ),
            html.P(
                "Monthly figures are the average daily rate. "
                "MTD uses days published so far this month.",
                style={
                    "fontSize": "11px",
                    "color": COLORS["text_muted"],
                    "marginTop": "8px",
                    "fontStyle": "italic",
                    "maxWidth": "360px",
                },
            ),
        ],
        style={"overflowX": "auto", "display": "inline-block", "maxWidth": "100%"},
    )
