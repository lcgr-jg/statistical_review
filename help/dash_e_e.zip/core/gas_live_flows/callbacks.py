"""EU Gas Balance — Live Flows callbacks."""
from __future__ import annotations

import logging

import pandas as pd
from dash import ALL, Input, Output, callback, ctx, html
from dash.exceptions import PreventUpdate

from core.gas_live_flows.charts import build_yoy_chart
from core.gas_live_flows.constants import (
    BCF_TO_MCM_FALLBACK,
    COL_CLICK_TYPE,
    DEFAULT_MA_WINDOW,
    GRANULARITY_DAILY,
    GRANULARITY_MONTHLY,
    SECTION_TITLES,
    TABLE_N_DAYS,
    TABLE_N_DAYS_MAX,
    TABLE_N_DAYS_MIN,
)
from core.gas_live_flows.data import (
    format_ce_refresh_age,
    get_bbg_feedgas,
    get_cached_flows,
    get_cached_regas,
    get_ce_last_refresh,
    load_series,
    monthly_history,
    us_liq_ath,
)
from core.gas_live_flows.table import (
    build_flows_table,
    build_monthly_history_table,
    build_regas_table,
    build_us_lng_tables,
)
from core.styles import get_status_badge_style

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "12px 16px",
            "borderRadius": "8px",
            "fontSize": "13px",
            "width": "100%",
        },
    )


def _parse_n_days(value) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return TABLE_N_DAYS
    return max(TABLE_N_DAYS_MIN, min(TABLE_N_DAYS_MAX, n))


def _parse_ma(value) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return DEFAULT_MA_WINDOW
    return n if n in (7, 14, 21, 28) else DEFAULT_MA_WINDOW


def _parse_grain(value) -> str:
    return GRANULARITY_MONTHLY if value == GRANULARITY_MONTHLY else GRANULARITY_DAILY


def _status_message(latest_data_date, bbg_error: str | None) -> tuple[str, str]:
    refresh = get_ce_last_refresh()
    msg = (
        f"Loaded CE gas data through {latest_data_date.strftime('%d-%b-%Y')} · "
        f"{format_ce_refresh_age(refresh)}"
    )
    if bbg_error:
        msg += f" · Bloomberg feedgas unavailable ({bbg_error})"
        return msg, "warning"
    return msg, "success"


@callback(
    Output("gas-live-flows-regas", "children"),
    Output("gas-live-flows-regas-subtitle", "children"),
    Output("gas-live-flows-flows", "children"),
    Output("gas-live-flows-flows-subtitle", "children"),
    Output("gas-live-flows-uslng", "children"),
    Output("gas-live-flows-uslng-subtitle", "children"),
    Output("gas-live-flows-status", "children"),
    Input("gas-live-flows-refresh", "n_clicks"),
    Input("gas-live-flows-days", "value"),
    Input("gas-live-flows-selection", "data"),
    prevent_initial_call=False,
)
def update_live_flows_tables(_n_clicks, table_days, selected):
    n_days = _parse_n_days(table_days)
    default_sub = f"Last {n_days} days · mcm/d"
    uslng_sub = f"Last {n_days} days · bcf/d and mcm/d"

    try:
        df_regas = get_cached_regas()
    except Exception as exc:
        logger.exception("Live Flows regas: %s", exc)
        err = _alert(str(exc), "error")
        return err, default_sub, err, default_sub, err, uslng_sub, err

    try:
        df_flows = get_cached_flows()
    except Exception as exc:
        logger.exception("Live Flows flows: %s", exc)
        err = _alert(str(exc), "error")
        regas_table = build_regas_table(df_regas, n_days=n_days, selected=selected)
        latest = df_regas.index.max()
        regas_sub = (
            f"Last {n_days} days · through {latest.strftime('%d-%b-%Y')} · mcm/d"
        )
        return regas_table, regas_sub, err, default_sub, err, uslng_sub, err

    bbg = get_bbg_feedgas()
    us_liq = bbg.get("us_liq")
    ca_liq = bbg.get("ca_liq")
    bbg_error = bbg.get("error")

    us_total = None
    if isinstance(us_liq, pd.DataFrame) and "Total" in us_liq.columns:
        us_total = us_liq["Total"]

    regas_table = build_regas_table(
        df_regas, n_days=n_days, selected=selected
    )
    flows_table = build_flows_table(
        df_flows,
        us_liq=us_total,
        ca_liq=ca_liq,
        n_days=n_days,
        selected=selected,
    )
    uslng_table = build_us_lng_tables(
        us_liq if isinstance(us_liq, pd.DataFrame) else None,
        bcf_to_mcm=float(bbg.get("bcf_to_mcm") or BCF_TO_MCM_FALLBACK),
        n_days=n_days,
        ath=us_liq_ath(us_liq) if isinstance(us_liq, pd.DataFrame) else None,
        selected=selected,
    )

    latest = df_regas.index.max()
    flows_latest = df_flows.index.max()
    if pd.notna(flows_latest) and (pd.isna(latest) or flows_latest > latest):
        latest = flows_latest
    if pd.isna(latest):
        latest = pd.Timestamp.now()
    status_txt, status_level = _status_message(latest, bbg_error)
    status = _alert(status_txt, status_level)
    through = latest.strftime("%d-%b-%Y")
    regas_sub = f"Last {n_days} days · through {through} · mcm/d · BE DE FR GB IT NL"
    flows_sub = f"Last {n_days} days · through {through} · mcm/d"
    if isinstance(us_liq, pd.DataFrame) and not us_liq.empty:
        us_through = us_liq.index.max().strftime("%d-%b-%Y")
        uslng_sub = f"Last {n_days} days · through {us_through} · bcf/d and mcm/d"
    return (
        regas_table,
        regas_sub,
        flows_table,
        flows_sub,
        uslng_table,
        uslng_sub,
        status,
    )


@callback(
    Output("gas-live-flows-selection", "data"),
    Input(
        {
            "type": COL_CLICK_TYPE,
            "src": ALL,
            "col": ALL,
            "unit": ALL,
            "row": ALL,
        },
        "n_clicks",
    ),
    prevent_initial_call=True,
)
def select_live_flows_column(n_clicks):
    triggered = ctx.triggered_id
    if not isinstance(triggered, dict):
        raise PreventUpdate
    if not n_clicks or max((n or 0) for n in n_clicks) < 1:
        raise PreventUpdate
    if ctx.triggered and ctx.triggered[0]["value"] in (None, 0):
        raise PreventUpdate
    return {
        "src": triggered.get("src"),
        "col": triggered.get("col"),
        "unit": triggered.get("unit"),
    }


@callback(
    Output("gas-live-flows-detail-title", "children"),
    Output("gas-live-flows-detail-subtitle", "children"),
    Output("gas-live-flows-monthly", "children"),
    Output("gas-live-flows-chart", "figure"),
    Output("gas-live-flows-ma-wrap", "style"),
    Input("gas-live-flows-selection", "data"),
    Input("gas-live-flows-grain", "value"),
    Input("gas-live-flows-ma", "value"),
    Input("gas-live-flows-refresh", "n_clicks"),
    prevent_initial_call=False,
)
def update_series_history(selected, grain_value, ma_value, _n_clicks):
    grain = _parse_grain(grain_value)
    ma_window = _parse_ma(ma_value)
    ma_style = (
        {"display": "flex", "alignItems": "center", "gap": "10px"}
        if grain == GRANULARITY_DAILY
        else {"display": "none"}
    )
    empty_fig = build_yoy_chart(pd.Series(dtype=float))

    if not selected or not selected.get("col"):
        return (
            "Series history",
            "Click a column above",
            html.Div(
                "Click a column in Regas, Flows, or US LNG to load monthly history.",
                style={"color": "#6c757d", "fontSize": "13px"},
            ),
            empty_fig,
            ma_style,
        )

    col = str(selected.get("col"))
    src = str(selected.get("src") or "")
    unit = str(selected.get("unit") or "mcm")
    title = f"{SECTION_TITLES.get(src, src.title() or 'Series')}: {col}"
    try:
        series, unit_label = load_series(src, col, unit)
    except Exception as exc:
        logger.exception("Live Flows history for %s/%s: %s", src, col, exc)
        err = _alert(str(exc), "error")
        return title, "history unavailable", err, empty_fig, ma_style

    precision = 1 if unit_label.startswith("bcf") else 0
    history = monthly_history(series)
    monthly_table = build_monthly_history_table(
        history, unit_label=unit_label, precision=precision
    )
    grain_txt = "daily" if grain == GRANULARITY_DAILY else "monthly"
    ma_txt = f" · {ma_window}d MA" if grain == GRANULARITY_DAILY else ""
    fig = build_yoy_chart(
        series,
        granularity=grain,
        ma_window=ma_window,
        unit_label=unit_label,
        title=title,
    )
    latest = series.index.max()
    through = (
        pd.Timestamp(latest).strftime("%d-%b-%Y") if pd.notna(latest) else ""
    )
    subtitle = f"{unit_label} · {grain_txt}{ma_txt} · through {through}"
    return title, subtitle, monthly_table, fig, ma_style
