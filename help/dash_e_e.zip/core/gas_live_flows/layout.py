"""Layout for the EU Gas Balance — Live Flows page."""
from __future__ import annotations

from dash import dcc, html

from core.gas_live_flows.constants import (
    DEFAULT_GRANULARITY,
    DEFAULT_MA_WINDOW,
    GRANULARITY_OPTIONS,
    MA_WINDOWS,
    TABLE_N_DAYS,
    TABLE_N_DAYS_MAX,
    TABLE_N_DAYS_MIN,
)
from core.styles import COLORS

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}

_LABEL_INLINE = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "margin": "0",
    "whiteSpace": "nowrap",
}

_MA_WRAP = {
    "display": "flex",
    "alignItems": "center",
    "gap": "10px",
    "flexWrap": "nowrap",
}

_ROW_PANEL = {
    "display": "flex",
    "flexWrap": "wrap",
    "alignItems": "stretch",
    "gap": "20px",
    "marginBottom": "20px",
}

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "center",
    "flexWrap": "wrap",
    "gap": "24px",
}

_BTN_PRIMARY = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
    "transition": "all 0.2s",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "visible",
    "marginBottom": "20px",
}

_HALF_PANEL = {
    **_CONTENT_PANEL,
    "flex": "1 1 420px",
    "minWidth": "360px",
    "marginBottom": "0",
    "overflow": "auto",
}

_PANEL_HEADER = {
    "padding": "16px 20px 8px 20px",
    "display": "flex",
    "alignItems": "baseline",
    "flexWrap": "nowrap",
    "gap": "8px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "whiteSpace": "nowrap",
    "flexShrink": "0",
}

_PANEL_SUBTITLE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "whiteSpace": "nowrap",
    "overflow": "hidden",
    "textOverflow": "ellipsis",
}


def build_layout() -> html.Div:
    return html.Div(
        style={
            "minHeight": "100vh",
            "backgroundColor": COLORS["background"],
            "padding": "20px",
        },
        children=[
            html.Div(
                [
                    html.H1(
                        "Live Flows",
                        style={
                            "fontSize": "22px",
                            "fontWeight": "600",
                            "color": COLORS["text_primary"],
                            "margin": "0 0 4px 0",
                        },
                    ),
                    html.P(
                        "Key EU pipeline flows, NWE+UK+IT LNG regas, and US LNG "
                        "feedgas — the same view as the EU Gas Flows morning email. "
                        "Click any column to open monthly history and a year-on-year chart.",
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_muted"],
                            "margin": "0 0 20px 0",
                        },
                    ),
                ]
            ),
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Button(
                        "Refresh",
                        id="gas-live-flows-refresh",
                        n_clicks=0,
                        style=_BTN_PRIMARY,
                    ),
                    html.Div(id="gas-live-flows-status"),
                    html.Div(
                        [
                            html.Label("History (days)", style=_LABEL),
                            html.Div(
                                dcc.Slider(
                                    id="gas-live-flows-days",
                                    min=TABLE_N_DAYS_MIN,
                                    max=TABLE_N_DAYS_MAX,
                                    step=1,
                                    value=TABLE_N_DAYS,
                                    marks={
                                        TABLE_N_DAYS_MIN: str(TABLE_N_DAYS_MIN),
                                        14: "14",
                                        30: "30",
                                        45: "45",
                                        TABLE_N_DAYS_MAX: str(TABLE_N_DAYS_MAX),
                                    },
                                    tooltip={
                                        "placement": "bottom",
                                        "always_visible": False,
                                    },
                                    updatemode="mouseup",
                                ),
                                style={"width": "360px", "minWidth": "240px"},
                            ),
                        ]
                    ),
                ],
            ),
            html.Div(
                style=_ROW_PANEL,
                children=[
                    html.Div(
                        style=_HALF_PANEL,
                        children=[
                            html.Div(
                                style=_PANEL_HEADER,
                                children=[
                                    html.Span("Regas", style=_PANEL_TITLE),
                                    html.Span(
                                        f"Last {TABLE_N_DAYS} days · mcm/d",
                                        id="gas-live-flows-regas-subtitle",
                                        style=_PANEL_SUBTITLE,
                                    ),
                                ],
                            ),
                            dcc.Loading(
                                type="default",
                                children=html.Div(
                                    id="gas-live-flows-regas",
                                    style={"padding": "16px 20px", "overflowX": "auto"},
                                    children=[
                                        html.Div(
                                            "Loading Commodity Essentials regas…",
                                            style={
                                                "color": COLORS["text_muted"],
                                                "fontSize": "13px",
                                            },
                                        )
                                    ],
                                ),
                            ),
                        ],
                    ),
                    html.Div(
                        style=_HALF_PANEL,
                        children=[
                            html.Div(
                                style=_PANEL_HEADER,
                                children=[
                                    html.Span("Flows", style=_PANEL_TITLE),
                                    html.Span(
                                        f"Last {TABLE_N_DAYS} days · mcm/d",
                                        id="gas-live-flows-flows-subtitle",
                                        style=_PANEL_SUBTITLE,
                                    ),
                                ],
                            ),
                            dcc.Loading(
                                type="default",
                                children=html.Div(
                                    id="gas-live-flows-flows",
                                    style={"padding": "16px 20px", "overflowX": "auto"},
                                    children=[
                                        html.Div(
                                            "Loading Commodity Essentials flows…",
                                            style={
                                                "color": COLORS["text_muted"],
                                                "fontSize": "13px",
                                            },
                                        )
                                    ],
                                ),
                            ),
                        ],
                    ),
                ],
            ),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("US LNG Feedgas Breakdown", style=_PANEL_TITLE),
                            html.Span(
                                f"Last {TABLE_N_DAYS} days · bcf/d and mcm/d",
                                id="gas-live-flows-uslng-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="default",
                        children=html.Div(
                            id="gas-live-flows-uslng",
                            style={"padding": "16px 20px"},
                            children=[
                                html.Div(
                                    "Loading Bloomberg US liquefaction…",
                                    style={
                                        "color": COLORS["text_muted"],
                                        "fontSize": "13px",
                                    },
                                )
                            ],
                        ),
                    ),
                ],
            ),
            dcc.Store(id="gas-live-flows-selection"),
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span(
                                "Series history",
                                id="gas-live-flows-detail-title",
                                style=_PANEL_TITLE,
                            ),
                            html.Span(
                                "Click a column above",
                                id="gas-live-flows-detail-subtitle",
                                style=_PANEL_SUBTITLE,
                            ),
                        ],
                    ),
                    html.Div(
                        style={
                            "padding": "8px 20px",
                            "borderBottom": f"1px solid {COLORS['border_light']}",
                            "display": "flex",
                            "flexWrap": "nowrap",
                            "gap": "28px",
                            "alignItems": "center",
                        },
                        children=[
                            html.Div(
                                style=_MA_WRAP,
                                children=[
                                    html.Label("Chart", style=_LABEL_INLINE),
                                    dcc.RadioItems(
                                        id="gas-live-flows-grain",
                                        options=GRANULARITY_OPTIONS,
                                        value=DEFAULT_GRANULARITY,
                                        inline=True,
                                        style={
                                            "fontSize": "13px",
                                            "display": "flex",
                                            "alignItems": "center",
                                        },
                                        labelStyle={
                                            "marginRight": "12px",
                                            "marginBottom": "0",
                                            "cursor": "pointer",
                                            "whiteSpace": "nowrap",
                                        },
                                    ),
                                ],
                            ),
                            html.Div(
                                id="gas-live-flows-ma-wrap",
                                style=_MA_WRAP,
                                children=[
                                    html.Label(
                                        "Moving average",
                                        style=_LABEL_INLINE,
                                    ),
                                    html.Div(
                                        dcc.Dropdown(
                                            id="gas-live-flows-ma",
                                            options=[
                                                {
                                                    "label": f"{n} days",
                                                    "value": n,
                                                }
                                                for n in MA_WINDOWS
                                            ],
                                            value=DEFAULT_MA_WINDOW,
                                            clearable=False,
                                            style={"fontSize": "13px"},
                                        ),
                                        style={"width": "120px"},
                                    ),
                                ],
                            ),
                        ],
                    ),
                    html.Div(
                        style={
                            "display": "flex",
                            "flexWrap": "wrap",
                            "gap": "20px",
                            "alignItems": "flex-start",
                            "padding": "16px 20px",
                        },
                        children=[
                            html.Div(
                                id="gas-live-flows-monthly",
                                style={"flex": "0 1 320px"},
                                children=[
                                    html.Div(
                                        "Click a column in Regas, Flows, or US LNG "
                                        "to load monthly history.",
                                        style={
                                            "color": COLORS["text_muted"],
                                            "fontSize": "13px",
                                        },
                                    )
                                ],
                            ),
                            html.Div(
                                style={"flex": "1 1 520px", "minWidth": "360px"},
                                children=[
                                    dcc.Loading(
                                        type="default",
                                        children=dcc.Graph(
                                            id="gas-live-flows-chart",
                                            config={
                                                "displayModeBar": True,
                                                "responsive": True,
                                            },
                                            style={"height": "460px"},
                                        ),
                                    )
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )
