"""Static configuration for the EU Gas Balance overview page."""
from __future__ import annotations

import datetime as dt

PAGE_PATH = "/power/gas_balance/overview"
PAGE_NAME = "Overview"
PAGE_TITLE = "EU Gas Balance Overview | JG Power Dashboard"
PAGE_ORDER = 70

DEFAULT_SCENARIO = "Basecase"
DEFAULT_START_YEAR = 2022
DEFAULT_OUTPUT = "Table"
DEFAULT_GRANULARITY = "Months (mcm/d)"

# Saved balance scenario variants (mirrors eu_dashboard_gas).
BALANCE_SCENARIOS = sorted([
    "Basecase", "EA", "Platts", "HighLNG", "LowLNG", "UkraineHigh",
    "EALNG", "PlattsCCGT", "PlattsLNG", "NCS_max_monthly", "NCS_max_seasonal",
    "NCS_max_q425", "NCS_max_q126", "ALNG2", "CCGT_JG_DEFR",
    "HormuzAug26", "HormuzOct26",
])

SCENARIO_OPTIONS = [{"label": s, "value": s} for s in BALANCE_SCENARIOS]

START_YEAR_OPTIONS = [
    {"label": str(y), "value": y}
    for y in range(2019, dt.datetime.now().year + 1)
]

OUTPUT_OPTIONS = ["Table", "Charts"]
GRANULARITY_OPTIONS = [
    "Days", "Weeks", "Months (bcm)", "Months (mcm/d)", "Seasons",
]

CACHE_TTL_SECONDS = 7200  # 2 hours — matches legacy gas dashboard
CACHE_PREFIX = "gas_balance"

DB_SCHEMA = "commod_research"
DB_TABLE_BALANCES = "eu_gas_balances"

CHART_END_CUTOFF = dt.datetime(2027, 12, 1)
