"""EU Gas Balance overview — Dash callbacks."""
from __future__ import annotations

import logging
from datetime import datetime

import dash_bootstrap_components as dbc
from dash import Input, Output, State, callback, dcc, html, no_update

from core.gas_balance.charts import create_seag_plots
from core.gas_balance.data import forecast_date_options, load_gas_balance
from core.gas_balance.format import format_balance_table, prepare_balance_chart_df
from core.styles import get_status_badge_style

logger = logging.getLogger(__name__)

_BADGE_OK = {
    **get_status_badge_style("success"),
    "display": "inline-block",
    "padding": "8px 14px",
    "borderRadius": "20px",
    "fontSize": "12px",
    "fontWeight": "500",
}


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(
        message,
        style={
            **get_status_badge_style(level),
            "padding": "12px 16px",
            "borderRadius": "8px",
            "fontSize": "13px",
            "width": "100%",
        },
    )


def _cache_badge(res: dict) -> html.Div:
    return html.Div(
        [
            html.Span(
                f"{res['scenario']} · {res['ref_date'].strftime('%Y-%m-%d')}",
                style={"fontWeight": "600"},
            ),
            html.Span(
                f" · saved {res['saved_date_utc'].strftime('%Y-%m-%d %H:%M')} UTC",
                style={"opacity": 0.85},
            ),
        ],
        style=_BADGE_OK,
        title=(
            f"Range {res['balance_start'].strftime('%Y-%m-%d')} – "
            f"{res['balance_end'].strftime('%Y-%m-%d')} · "
            f"{', '.join(res['countries'])}"
        ),
    )


def _content_subtitle(scenario: str, forecast_date: str, granularity: str, output: str) -> str:
    return f"{scenario} · {forecast_date} · {granularity} · {output}"


@callback(
    Output("gas-bal-forecast-date", "options"),
    Output("gas-bal-forecast-date", "value"),
    Input("gas-bal-scenario", "value"),
)
def update_forecast_dates(scenario):
    if not scenario:
        return [], None
    try:
        return forecast_date_options(scenario)
    except Exception as exc:
        logger.exception("Failed to load forecast dates for %s: %s", scenario, exc)
        return [], None


@callback(
    Output("gas-bal-container", "children"),
    Output("gas-bal-cache-summary", "children"),
    Output("gas-bal-content-subtitle", "children"),
    Input("gas-bal-display-btn", "n_clicks"),
    State("gas-bal-scenario", "value"),
    State("gas-bal-forecast-date", "value"),
    State("gas-bal-granularity", "value"),
    State("gas-bal-output", "value"),
    State("gas-bal-start-year", "value"),
    prevent_initial_call=True,
)
def display_balance(n_clicks, scenario, forecast_date, granularity, output, start_year):
    if not n_clicks:
        return no_update, no_update, no_update

    if not scenario:
        return _alert("Please select a scenario."), "", ""
    if not forecast_date:
        return _alert("Please select a forecast date."), "", ""
    if output == "Charts" and granularity == "Seasons":
        return (
            _alert('Charts with "Seasons" granularity is not supported — choose Table or another granularity.'),
            "",
            "",
        )

    ref_date = datetime.strptime(forecast_date, "%Y-%m-%d")
    subtitle = _content_subtitle(scenario, forecast_date, granularity, output)

    try:
        res = load_gas_balance(forecast_date, scenario)
    except Exception as exc:
        logger.exception("Failed to load gas balance: %s", exc)
        return _alert(f"Failed to load balance: {exc}", "error"), "", subtitle

    cache_summary = _cache_badge(res)

    if output == "Table":
        formatted_df = format_balance_table(res, ref_date, granularity, start_year)
        content = html.Div(
            dbc.Table.from_dataframe(
                formatted_df,
                striped=True,
                bordered=True,
                hover=True,
                responsive=True,
                index=True,
                className="mb-0",
                style={"fontSize": "12px", "fontFamily": "Calibri, Arial, sans-serif"},
            ),
            style={"overflowX": "auto", "maxWidth": "100%"},
        )
    else:
        df_plot = prepare_balance_chart_df(res, ref_date, granularity, start_year)
        fig = create_seag_plots(ref_date, df_plot, granularity)
        content = dcc.Graph(
            id="gas-bal-charts",
            figure=fig,
            style={"height": "900px"},
            config={"responsive": True, "displayModeBar": True},
        )

    return content, cache_summary, subtitle
