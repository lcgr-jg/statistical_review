"""Seasonal balance charts (ported from eu_dashboard_gas balance_viewer)."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def create_seag_plots(ref_date: datetime, df: pd.DataFrame, granularity: str) -> go.Figure:
    """Build the 12-panel year-over-year seasonal chart grid."""
    data = df.copy()
    data.index = pd.to_datetime(data.index)
    data["year"] = data.index.year

    if granularity in ("Months (mcm/d)", "Months (bcm)"):
        col_groupby = "month"
        data["month"] = data.index.month
        current_period = ref_date.month
    elif granularity == "Weeks":
        col_groupby = "week"
        data["week"] = [idx.isocalendar()[1] for idx in data.index]
        current_period = ref_date.isocalendar()[1]
    elif granularity == "Days":
        col_groupby = "day"
        data["day"] = data.index.dayofyear
        current_period = pd.to_datetime(ref_date).dayofyear
    else:
        raise ValueError(f"Charts not supported for granularity: {granularity}")

    years = sorted(data["year"].unique())
    current_year = ref_date.year

    reqd_balance_items = [
        [
            ("Demand", "LDZ"), ("Demand", "CCGT"), ("Demand", "Industrial"), ("Demand", "Total"),
        ],
        [
            ("Supply", "Regas"), ("Supply", "Mazara"), ("Supply", "TAP"), ("Storage", "StB"),
        ],
        [
            ("Production", "NCS"), ("Production", "UKCS"), ("Production", "Other"), ("Production", "Total"),
        ],
    ]
    plot_titles = [f"{c[0]}: {c[1]}" for col_names in reqd_balance_items for c in col_names]

    fig = make_subplots(
        rows=3,
        cols=4,
        subplot_titles=plot_titles,
        horizontal_spacing=0.02,
        vertical_spacing=0.1,
    )

    colors = px.colors.qualitative.Plotly
    year_in_legend = {year: False for year in years}

    for r, col_names in enumerate(reqd_balance_items):
        for c, col_name in enumerate(col_names):
            for i, year in enumerate(years):
                color = colors[i % len(colors)]
                year_data = data[data["year"] == year].sort_values(col_groupby)

                if year < current_year:
                    _add_trace(fig, year_data, col_groupby, col_name, str(year), color, False, r + 1, c + 1, year_in_legend, year)
                elif year > current_year:
                    _add_trace(fig, year_data, col_groupby, col_name, str(year), color, True, r + 1, c + 1, year_in_legend, year)
                else:
                    past = year_data[year_data[col_groupby] <= current_period]
                    future = year_data[year_data[col_groupby] > current_period]
                    if not past.empty:
                        _add_trace(fig, past, col_groupby, col_name, f"{year}", color, False, r + 1, c + 1, year_in_legend, year)
                    if not future.empty:
                        _add_trace(
                            fig, future, col_groupby, col_name,
                            f"{year} (forecast)", color, True, r + 1, c + 1, year_in_legend, year,
                        )

    fig.update_layout(
        template="dashboard",
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
        plot_bgcolor="white",
        paper_bgcolor="white",
        margin=dict(l=10, r=10, t=30, b=10),
        autosize=True,
    )

    if granularity in ("Months (mcm/d)", "Months (bcm)"):
        month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                       "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        fig.update_xaxes(
            tickvals=list(range(1, 13)),
            ticktext=month_names,
            showgrid=True,
            gridwidth=0.75,
            gridcolor="#EEEEEE",
            zeroline=False,
            showline=True,
            linewidth=1,
            linecolor="#CCCCCC",
            rangemode="tozero",
        )
    else:
        fig.update_xaxes(
            showgrid=True,
            gridwidth=0.75,
            gridcolor="#EEEEEE",
            zeroline=False,
            showline=True,
            linewidth=1,
            linecolor="#CCCCCC",
            rangemode="tozero",
        )

    fig.update_yaxes(
        showgrid=True,
        gridwidth=0.75,
        gridcolor="#EEEEEE",
        zeroline=False,
        showline=True,
        linewidth=1,
        linecolor="#CCCCCC",
    )
    return fig


def _add_trace(
    fig: go.Figure,
    year_data: pd.DataFrame,
    col_groupby: str,
    col_name: tuple,
    name: str,
    color: str,
    dashed: bool,
    row: int,
    col: int,
    year_in_legend: dict,
    year: int,
) -> None:
    line = dict(color=color, width=2)
    if dashed:
        line["dash"] = "dash"
    fig.add_trace(
        go.Scatter(
            x=year_data[col_groupby],
            y=year_data[col_name],
            mode="lines+markers",
            name=name,
            line=line,
            marker=dict(color=color, size=6),
            showlegend=not year_in_legend[year],
        ),
        row=row,
        col=col,
    )
    year_in_legend[year] = True
