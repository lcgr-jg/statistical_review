"""Format EU gas balance DataFrames for table display."""
from __future__ import annotations

import calendar
from datetime import datetime

import pandas as pd

from jain_commods.core.util.dateutils import get_season

from .constants import CHART_END_CUTOFF
from .data import balances_apply_dt_filter_monthly, balances_remove_monthly_mtd_bom


def format_balance_table(
    res: dict,
    ref_date: datetime,
    granularity: str,
    start_year: int,
) -> pd.DataFrame:
    """Return a display-ready balance DataFrame for ``dbc.Table``."""
    start_dt = datetime(start_year, 1, 1)
    formatted_df = _select_granularity_frame(res, ref_date, granularity, for_chart=False)
    formatted_df = _apply_start_year_filter(formatted_df, ref_date, granularity, start_dt)
    formatted_df = _format_index(formatted_df, granularity)
    formatted_df = _format_numeric_columns(formatted_df, granularity)
    formatted_df.index.name = "Date"
    return formatted_df


def prepare_balance_chart_df(
    res: dict,
    ref_date: datetime,
    granularity: str,
    start_year: int,
) -> pd.DataFrame:
    """Return a balance DataFrame ready for seasonal chart plotting."""
    start_dt = datetime(start_year, 1, 1)
    df_plot = _select_granularity_frame(res, ref_date, granularity, for_chart=True)
    df_plot = df_plot[df_plot.index >= start_dt]
    df_plot = df_plot[df_plot.index < CHART_END_CUTOFF]
    return df_plot


def _select_granularity_frame(
    res: dict,
    ref_date: datetime,
    granularity: str,
    *,
    for_chart: bool,
) -> pd.DataFrame:
    if granularity == "Days":
        df = res["balance_daily"].copy()
        df.index = pd.to_datetime(df.index)
        return df

    if granularity == "Weeks":
        df = res["balance_weekly"].copy()
        df.index = pd.to_datetime(df.index)
        return df

    if granularity == "Months (mcm/d)":
        if for_chart:
            return balances_remove_monthly_mtd_bom(ref_date, res["balance_monthly"])
        return res["balance_monthly"].copy()

    if granularity == "Months (bcm)":
        df = balances_remove_monthly_mtd_bom(ref_date, res["balance_monthly"])
        return _convert_monthly_to_bcm(df)

    if granularity == "Seasons":
        return res["balance_seasonal"].copy()

    raise ValueError(f"Unknown granularity: {granularity}")


def _apply_start_year_filter(
    df: pd.DataFrame,
    ref_date: datetime,
    granularity: str,
    start_dt: datetime,
) -> pd.DataFrame:
    if granularity == "Months (mcm/d)":
        return balances_apply_dt_filter_monthly(df, start_dt)
    if granularity == "Seasons":
        return df[df.index >= start_dt]
    return df[df.index >= start_dt]


def _format_index(df: pd.DataFrame, granularity: str) -> pd.DataFrame:
    out = df.copy()
    if granularity == "Days":
        out.index = pd.to_datetime(out.index).strftime("%d-%b-%Y")
    elif granularity == "Weeks":
        out.index = [
            f"Wk{idx.isocalendar()[1]} ({idx.strftime('%d-%b-%y')})"
            for idx in pd.to_datetime(out.index)
        ]
    elif granularity in ("Months (mcm/d)", "Months (bcm)"):
        out.index = [
            idx.strftime("%b-%y") if hasattr(idx, "strftime") else str(idx)
            for idx in out.index
        ]
    elif granularity == "Seasons":
        out.index = [get_season(idx, return_label=True) for idx in out.index]
    return out


def _convert_monthly_to_bcm(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    days_in_month = pd.Series(
        [calendar.monthrange(idx.year, idx.month)[1] for idx in out.index],
        index=out.index,
    )
    for col in out.columns:
        if col[0] in ["Demand", "Production", "Supply", "Exports"]:
            out[col] = out[col] * days_in_month / 1000
        elif col[1] in ["Imbalance", "StB", "Storage"]:
            out[col] = out[col] * days_in_month / 1000
    return out


def _format_numeric_columns(df: pd.DataFrame, granularity: str) -> pd.DataFrame:
    out = df.copy()
    pct_cols = {
        ("Storage", "Fill Start %"),
        ("Storage", "Fill End %"),
        ("Storage", "Fill %"),
    }
    fmt = "{:,.1f}" if granularity == "Months (bcm)" else "{:,.0f}"

    for col in out.select_dtypes(include=["float", "int"]).columns:
        if col in pct_cols:
            out[col] = out[col].map("{:.0%}".format)
        else:
            out[col] = out[col].map(fmt.format)
    return out
