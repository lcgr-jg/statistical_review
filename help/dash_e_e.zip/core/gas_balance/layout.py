"""Layout for the EU Gas Balance overview page (pure, no callbacks)."""
from __future__ import annotations

from dash import dcc, html

from core.styles import COLORS

from .constants import (
    DEFAULT_GRANULARITY,
    DEFAULT_OUTPUT,
    DEFAULT_SCENARIO,
    DEFAULT_START_YEAR,
    GRANULARITY_OPTIONS,
    OUTPUT_OPTIONS,
    SCENARIO_OPTIONS,
    START_YEAR_OPTIONS,
)

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_muted"],
    "marginBottom": "6px",
    "display": "block",
}

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
}

_OPTION_BOX = {
    "flex": "1",
    "minWidth": "240px",
    "padding": "16px",
    "backgroundColor": COLORS["card_bg_alt"],
    "borderRadius": "8px",
    "border": f"1px solid {COLORS['border']}",
}

_BTN_PRIMARY = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
    "transition": "all 0.2s",
    "marginTop": "24px",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "hidden",
}

_PANEL_HEADER = {
    "padding": "16px 20px",
    "borderBottom": f"1px solid {COLORS['border_light']}",
    "display": "flex",
    "alignItems": "baseline",
    "flexWrap": "wrap",
    "gap": "8px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
}

_PANEL_SUBTITLE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
}

_RADIO = {
    "display": "flex",
    "flexWrap": "wrap",
    "gap": "12px",
    "fontSize": "13px",
    "color": COLORS["text_primary"],
}


def _dropdown(id_: str, **kwargs) -> dcc.Dropdown:
    defaults = {"clearable": False, "style": {"fontSize": "13px"}}
    defaults.update(kwargs)
    return dcc.Dropdown(id=id_, **defaults)


def _control_block(label: str, control, *, width: str = "180px") -> html.Div:
    return html.Div(
        [
            html.Label(label, style=_LABEL),
            html.Div(control, style={"width": width, "maxWidth": "100%"}),
        ],
        style={"display": "inline-block", "marginRight": "20px", "verticalAlign": "top"},
    )


def build_layout() -> html.Div:
    return html.Div(
        style={
            "minHeight": "100vh",
            "backgroundColor": COLORS["background"],
            "padding": "20px",
        },
        children=[
            # ── Controls ────────────────────────────────────────────────
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Div(
                        style={
                            "marginBottom": "20px",
                            "paddingBottom": "20px",
                            "borderBottom": f"1px solid {COLORS['border']}",
                        },
                        children=[
                            _control_block(
                                "Scenario",
                                _dropdown(
                                    "gas-bal-scenario",
                                    options=SCENARIO_OPTIONS,
                                    value=DEFAULT_SCENARIO,
                                    style={"width": "200px", "fontSize": "13px"},
                                ),
                                width="200px",
                            ),
                            _control_block(
                                "Forecast Date",
                                _dropdown(
                                    "gas-bal-forecast-date",
                                    placeholder="Select forecast date…",
                                    style={"width": "190px", "fontSize": "13px"},
                                ),
                                width="190px",
                            ),
                            html.Div(
                                html.Button(
                                    [
                                        html.Span("↻", style={"fontSize": "16px", "marginRight": "6px"}),
                                        "Display Balance",
                                    ],
                                    id="gas-bal-display-btn",
                                    n_clicks=0,
                                    style=_BTN_PRIMARY,
                                ),
                                style={"display": "inline-block", "marginRight": "20px"},
                            ),
                            html.Div(
                                id="gas-bal-cache-summary",
                                style={"display": "inline-block", "float": "right", "marginTop": "18px"},
                            ),
                        ],
                    ),
                    html.Div(
                        style={"display": "flex", "gap": "16px", "flexWrap": "wrap", "marginBottom": "16px"},
                        children=[
                            html.Div(
                                style={**_OPTION_BOX, "maxWidth": "160px"},
                                children=[
                                    html.Label("Start Year", style={**_LABEL, "color": COLORS["text_primary"]}),
                                    _dropdown(
                                        "gas-bal-start-year",
                                        options=START_YEAR_OPTIONS,
                                        value=DEFAULT_START_YEAR,
                                        style={"width": "100%", "fontSize": "13px"},
                                    ),
                                ],
                            ),
                            html.Div(
                                style={**_OPTION_BOX, "marginRight": 0},
                                children=[
                                    html.Label("Output Display", style={**_LABEL, "color": COLORS["text_primary"]}),
                                    dcc.RadioItems(
                                        id="gas-bal-output",
                                        options=[{"label": o, "value": o} for o in OUTPUT_OPTIONS],
                                        value=DEFAULT_OUTPUT,
                                        inline=True,
                                        inputStyle={"marginRight": "6px"},
                                        labelStyle={"marginRight": "16px", "fontSize": "13px"},
                                        style=_RADIO,
                                    ),
                                ],
                            ),
                            html.Div(
                                style=_OPTION_BOX,
                                children=[
                                    html.Label("Granularity", style={**_LABEL, "color": COLORS["text_primary"]}),
                                    dcc.RadioItems(
                                        id="gas-bal-granularity",
                                        options=[{"label": g, "value": g} for g in GRANULARITY_OPTIONS],
                                        value=DEFAULT_GRANULARITY,
                                        inline=True,
                                        inputStyle={"marginRight": "6px"},
                                        labelStyle={"marginRight": "14px", "fontSize": "13px"},
                                        style=_RADIO,
                                    ),
                                ],
                            ),
                        ],
                    ),
                    html.Details(
                        style={
                            "fontSize": "13px",
                            "color": COLORS["text_secondary"],
                            "lineHeight": "1.5",
                        },
                        children=[
                            html.Summary(
                                "About this balance",
                                style={
                                    "cursor": "pointer",
                                    "fontWeight": "600",
                                    "color": COLORS["accent"],
                                    "marginBottom": "8px",
                                },
                            ),
                            html.P(
                                "View a saved EU gas balance by scenario and forecast date. "
                                "EU perimeter: GB, FR, DE, NL, BE, IT, NWE (NWE aggregates perimeter flows such as NCS from EA)."
                            ),
                            html.P(
                                "Basecase combines Jain forecasts (regas, LDZ ECENS + EC46, CCGT ECENS), "
                                "Platts (NCS) and Energy Aspects (everything else)."
                            ),
                            html.P(
                                "StB = Storage To Balance (net supply minus demand, excl. storage). "
                                "Storage is observed action; Imbalance is the difference vs StB."
                            ),
                        ],
                    ),
                ],
            ),
            # ── Content ─────────────────────────────────────────────────
            html.Div(
                style=_CONTENT_PANEL,
                children=[
                    html.Div(
                        style=_PANEL_HEADER,
                        children=[
                            html.Span("EU Gas Balance", style=_PANEL_TITLE),
                            html.Span(id="gas-bal-content-subtitle", style=_PANEL_SUBTITLE),
                        ],
                    ),
                    html.Div(
                        style={"padding": "16px 20px", "minHeight": "120px"},
                        children=[
                            dcc.Loading(
                                id="gas-bal-loading",
                                type="circle",
                                color=COLORS["accent"],
                                children=html.Div(
                                    id="gas-bal-container",
                                    children=html.P(
                                        "Select a scenario and forecast date, then click Display Balance.",
                                        style={
                                            "color": COLORS["text_muted"],
                                            "fontSize": "13px",
                                            "margin": "24px 0",
                                            "textAlign": "center",
                                        },
                                    ),
                                ),
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )
