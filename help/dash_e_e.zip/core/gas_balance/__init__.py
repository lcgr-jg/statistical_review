"""EU Gas Balance overview page module."""
