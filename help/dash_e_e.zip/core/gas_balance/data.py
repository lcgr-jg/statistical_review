"""
EU Gas Balance — data loading and caching.

Wraps ``jain_commods.fundamental.gas.util`` with the portal ``dashboard_cache``
(``@cached_result``) instead of Flask-Caching memoize used in eu_dashboard_gas.
"""
from __future__ import annotations

import logging
from datetime import datetime
from functools import lru_cache
from typing import Any

import pandas as pd

from jain_commods.core.interfaces.sqldb import SQLdb

from core.cache import cached_result, dashboard_cache

from .constants import (
    CACHE_PREFIX,
    CACHE_TTL_SECONDS,
    DB_SCHEMA,
    DB_TABLE_BALANCES,
)

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def _gas_util():
    """Lazy import — ``jain_commods.fundamental.gas`` package init pulls in sklearn."""
    from jain_commods.fundamental.gas import util

    return util


@cached_result(ttl=CACHE_TTL_SECONDS, prefix=f"{CACHE_PREFIX}_forecasts")
def get_balance_forecasts(scenario: str) -> pd.DataFrame:
    """Available forecast dates for a saved balance scenario."""
    query = f"""
        SELECT * FROM {DB_SCHEMA}.{DB_TABLE_BALANCES}
        WHERE scenario = '{scenario}'
        ORDER BY ref_date DESC
    """
    db = SQLdb(logintype="prod")
    with db.engine.begin() as conn:
        return pd.read_sql(query, conn)


@cached_result(ttl=CACHE_TTL_SECONDS, prefix=f"{CACHE_PREFIX}_part1")
def _load_gas_balance_part1(ref_date_str: str, scenario: str) -> tuple:
    """Expensive DB + S3 load (part1), cached by forecast date and scenario."""
    ref_date = datetime.strptime(ref_date_str, "%Y-%m-%d")
    return _gas_util().get_eu_gas_balance_part1(ref_date, scenario, use_cache=True)


@cached_result(ttl=CACHE_TTL_SECONDS, prefix=f"{CACHE_PREFIX}_full")
def load_gas_balance(ref_date_str: str, scenario: str) -> dict[str, Any]:
    """
    Load and process a saved EU gas balance (no dynamic scenarios).

    Returns the same dict as ``util.get_eu_gas_balance_part2`` / legacy wrapper.
    """
    ref_date = datetime.strptime(ref_date_str, "%Y-%m-%d")
    (
        df_balance_raw,
        balance_items,
        _ref_date,
        df_storages_raw,
        saved_date_utc,
        ref_date_used,
        countries,
        start_date,
        end_date,
    ) = _load_gas_balance_part1(ref_date_str, scenario)

    return _gas_util().get_eu_gas_balance_part2(
        df_balance_raw,
        balance_items,
        ref_date,
        {},  # no dynamic scenarios in portal v1
        df_storages_raw,
        saved_date_utc,
        ref_date_used,
        countries,
        start_date,
        end_date,
        scenario,
        country_agg="item",
    )


def forecast_date_options(scenario: str) -> tuple[list[dict[str, str]], str]:
    """Build dropdown options and default value for forecast dates."""
    forecasts = get_balance_forecasts(scenario)
    if forecasts.empty:
        return [], ""

    dates_only = pd.Series(forecasts["ref_date"].values).dt.floor("D").unique()
    options = [
        {
            "label": pd.to_datetime(dt_val).strftime("%Y-%m-%d"),
            "value": pd.to_datetime(dt_val).strftime("%Y-%m-%d"),
        }
        for dt_val in dates_only
    ]
    default = pd.to_datetime(dates_only[0]).strftime("%Y-%m-%d")
    return options, default


def balances_apply_dt_filter_monthly(df_monthly: pd.DataFrame, start_dt: datetime) -> pd.DataFrame:
    """Filter monthly balance rows while preserving MTD/BoM string index rows."""
    df = df_monthly.copy()
    datetime_mask = pd.to_datetime(df.index, errors="coerce").notnull()
    date_filter_mask = pd.to_datetime(df.index, errors="coerce") >= start_dt
    string_rows_mask = ~datetime_mask
    restore_mask = string_rows_mask | date_filter_mask
    return df.loc[restore_mask]


def balances_remove_monthly_mtd_bom(ref_date: datetime, df_monthly: pd.DataFrame) -> pd.DataFrame:
    """Replace MTD/BoM rows with a single averaged row for the forecast month."""
    df = df_monthly.copy()
    curr_month = datetime(ref_date.year, ref_date.month, 1)

    if "MTD" in df.index:
        pos = df.index.get_loc("MTD")
    else:
        pos = df.index.get_loc("BoM")

    if "MTD" in df.index and "BoM" in df.index:
        curr_month_avg_row = df.loc[["MTD", "BoM"]].mean()
    elif "MTD" in df.index:
        curr_month_avg_row = df.loc[["MTD"]].mean()
    else:
        curr_month_avg_row = df.loc[["BoM"]].mean()

    curr_month_avg_df = pd.DataFrame([curr_month_avg_row], index=[curr_month])

    if "MTD" in df.index:
        df = df.drop(["MTD"])
    if "BoM" in df.index:
        df = df.drop(["BoM"])

    idx_list = df.index.tolist()
    idx_list.insert(pos, curr_month)
    return pd.concat([df, curr_month_avg_df]).reindex(idx_list)


def clear_gas_balance_cache() -> None:
    """Invalidate all gas balance cache entries (memory + disk)."""
    for suffix in ("forecasts", "part1", "full"):
        dashboard_cache.clear(prefix=f"res:{CACHE_PREFIX}_{suffix}:")
    logger.info("Gas balance cache cleared")
