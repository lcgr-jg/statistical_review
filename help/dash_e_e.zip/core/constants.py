"""
Cross-cutting application constants.

Page-specific magic numbers live in their own ``core.<page>.constants``
modules.  This file is for values that apply to *the whole dashboard*:
network/server tuning, cache TTL "bands", and other knobs that more
than one module reads.

Two design rules:

1.  Anything backed by an environment variable is exposed as a small
    helper (e.g. :func:`get_port`) so callers stay env-aware and tests
    can override via ``monkeypatch.setenv``.
2.  Every TTL is given a *semantic* name (``TTL_HOUR``, ``TTL_6H``)
    rather than a raw second count at the call site.  Update one
    constant -> updates everywhere that means "an hour".
"""
from __future__ import annotations

import os
from typing import Final


# -----------------------------------------------------------------------------
# Network / server defaults
# -----------------------------------------------------------------------------
DEFAULT_PORT: Final[int] = 8080
DEFAULT_HOST_PROD: Final[str] = "0.0.0.0"
DEFAULT_HOST_DEV: Final[str] = "localhost"

# Waitress production-server defaults.  These are sized for the small (1-5
# concurrent users) deployment described in README; tune via env vars.
WAITRESS_THREADS_DEFAULT: Final[int] = 16
WAITRESS_CONNECTION_LIMIT_DEFAULT: Final[int] = 200
WAITRESS_CHANNEL_TIMEOUT_DEFAULT: Final[int] = 120


def get_port() -> int:
    """Resolve the HTTP port (env ``PORT``, fallback :data:`DEFAULT_PORT`)."""
    return int(os.getenv("PORT", DEFAULT_PORT))


def get_host(*, is_dev: bool) -> str:
    """Resolve the bind host (env ``HOST``, fallback by mode)."""
    fallback = DEFAULT_HOST_DEV if is_dev else DEFAULT_HOST_PROD
    return (os.getenv("HOST", fallback) or "").strip() or DEFAULT_HOST_PROD


def get_waitress_threads() -> int:
    return int(os.getenv("WAITRESS_THREADS", str(WAITRESS_THREADS_DEFAULT)))


def get_waitress_connection_limit() -> int:
    return int(
        os.getenv(
            "WAITRESS_CONNECTION_LIMIT", str(WAITRESS_CONNECTION_LIMIT_DEFAULT)
        )
    )


def get_waitress_channel_timeout() -> int:
    return int(
        os.getenv(
            "WAITRESS_CHANNEL_TIMEOUT", str(WAITRESS_CHANNEL_TIMEOUT_DEFAULT)
        )
    )


# -----------------------------------------------------------------------------
# Cache TTL bands (in seconds)
# -----------------------------------------------------------------------------
# Bands are named for the *meaning* of the freshness, not the raw value.  Use
# these instead of bare numbers so a single change here propagates to every
# call site.
TTL_15_MIN: Final[int] = 15 * 60          # 900   - very fresh, e.g. spot prices
TTL_30_MIN: Final[int] = 30 * 60          # 1_800 - intra-hour data
TTL_HOUR: Final[int]   = 60 * 60          # 3_600 - default
TTL_2H: Final[int]     = 2 * 60 * 60      # 7_200 - moderately fresh
TTL_4H: Final[int]     = 4 * 60 * 60      # 14_400
TTL_6H: Final[int]     = 6 * 60 * 60      # 21_600
TTL_DAY: Final[int]    = 24 * 60 * 60     # 86_400


# -----------------------------------------------------------------------------
# Refresh cadence (minutes) -- used with ``data_freshness.tracker``
# -----------------------------------------------------------------------------
FRESHNESS_HOURLY_MINUTES: Final[int] = 60
FRESHNESS_6H_MINUTES: Final[int] = 360
FRESHNESS_DAILY_MINUTES: Final[int] = 24 * 60


# -----------------------------------------------------------------------------
# Cache filesystem locations
# -----------------------------------------------------------------------------
DEFAULT_CACHE_ROOT: Final[str] = "/app/cache"


__all__ = [
    "DEFAULT_PORT",
    "DEFAULT_HOST_PROD",
    "DEFAULT_HOST_DEV",
    "WAITRESS_THREADS_DEFAULT",
    "WAITRESS_CONNECTION_LIMIT_DEFAULT",
    "WAITRESS_CHANNEL_TIMEOUT_DEFAULT",
    "get_port",
    "get_host",
    "get_waitress_threads",
    "get_waitress_connection_limit",
    "get_waitress_channel_timeout",
    "TTL_15_MIN",
    "TTL_30_MIN",
    "TTL_HOUR",
    "TTL_2H",
    "TTL_4H",
    "TTL_6H",
    "TTL_DAY",
    "FRESHNESS_HOURLY_MINUTES",
    "FRESHNESS_6H_MINUTES",
    "FRESHNESS_DAILY_MINUTES",
    "DEFAULT_CACHE_ROOT",
]
