"""LNG — Cargo DoD Changes page constants."""
from __future__ import annotations

from datetime import date

PAGE_PATH = "/power/lng/cargo_dod"
PAGE_NAME = "Cargo DoD Changes"
PAGE_TITLE = "LNG Cargo Day-on-Day Changes | JG Power Dashboard"
PAGE_ORDER = 81

# Snapshot reference point: one Kpler point-in-time snapshot per day at
# ~06:00 UTC (mirrors the eu_reports/lng_vessels report which compares the
# 06:00 snapshots saved by KplerLoader).
SNAPSHOT_HOUR_UTC = 6

# Earliest Kpler LNG snapshot (per Kpler API docs / pit_store)
EARLIEST_SNAPSHOT_DATE = date(2020, 10, 27)

# Minimum cargo size to include (filters small/coastal vessels) — same as
# the lng_vessels report default.
VOLUME_FILTER_M3 = 10_000

# 1 m3 of LNG = 0.0006 mcm of natural gas
# (jain_commods.fundamental.units unit_conversion_table: 'cu m/mcm')
M3_LNG_TO_MCM = 0.0006

# Destination-country zone presets.  Country names are Kpler
# ``Country (destination)`` labels.  NWE matches eu_reports/lng_vessels.
NWE_COUNTRIES = [
    "Belgium",
    "Germany",
    "France",
    "United Kingdom",
    "Italy",
    "Netherlands",
]

ZONE_PRESETS: dict[str, list[str]] = {
    "NWE": NWE_COUNTRIES,
    "Iberia": ["Spain", "Portugal"],
    "NWE + Iberia": NWE_COUNTRIES + ["Spain", "Portugal"],
}
DEFAULT_ZONE = "NWE"
CUSTOM_ZONE = "Custom"

# Kpler terminal map deep-link (same pattern as eu_reports/lng_vessels)
KPLER_VESSEL_MAP_URL = (
    "https://terminal.kpler.com/map/search/voyages?fields=vessel&vessels={}"
)

# Local parquet cache dir for the PIT snapshot store (inside the repo's
# ./cache tree, alongside the diskcache used by dashboard_cache).
PIT_LOCAL_CACHE_DIR = "cache/kpler_snapshots"

# Coverage panel / history charts default start — the snapshot cache is
# backfilled to Jan-2021, so report coverage and chart history from there.
COVERAGE_DEFAULT_START = date(2021, 1, 1)
