"""Callbacks for the LNG — Cargo DoD Changes page."""
from __future__ import annotations

import logging
from datetime import date

import pandas as pd
from dash import Input, Output, State, callback, ctx, html, no_update

from core.cargo_dod.compare import compare_snapshots, create_clean_data
from core.cargo_dod.constants import (
    CUSTOM_ZONE,
    VOLUME_FILTER_M3,
    ZONE_PRESETS,
)
from core.cargo_dod.data import (
    comparison_date,
    get_backfill_state,
    get_coverage,
    get_trades_snapshot,
    get_vessels_for,
    snapshot_datetime,
    start_backfill,
)
from core.cargo_dod.render import (
    build_cargo_list,
    build_coverage_figure,
    build_diversion_boxes,
    build_headline,
    build_origin_chart,
    build_origin_table,
    build_volume_by_source_table,
)
from core.styles import COLORS, get_status_badge_style

logger = logging.getLogger(__name__)


def _alert(message: str, level: str = "warning") -> html.Div:
    return html.Div(message, style={
        **get_status_badge_style(level),
        "padding": "10px 14px",
        "borderRadius": "8px",
        "fontSize": "13px",
        "width": "100%",
    })


def _parse_date(value) -> date | None:
    if not value:
        return None
    try:
        return pd.Timestamp(value).date()
    except Exception:
        return None


@callback(
    Output("cf-countries", "value"),
    Input("cf-zone-preset", "value"),
    State("cf-countries", "value"),
)
def apply_zone_preset(preset, current_value):
    if preset == CUSTOM_ZONE or preset not in ZONE_PRESETS:
        return current_value or []
    return list(ZONE_PRESETS[preset])


@callback(
    Output("cf-date-prev", "date"),
    Input("cf-date-curr", "date"),
    Input("cf-date-prev", "date"),
)
def sync_comparison_date(curr_value, prev_value):
    """Keep compare-against behind the current snapshot.

    Changing the current date resets compare-against to the previous day,
    or to Friday when the new current date is a Monday. A compare-against
    on or after the current snapshot is pulled back the same way.
    """
    curr = _parse_date(curr_value)
    prev = _parse_date(prev_value)
    if curr is None:
        return no_update
    triggered = ctx.triggered_id
    if triggered not in ("cf-date-curr", "cf-date-prev"):
        return no_update
    if triggered == "cf-date-prev" and prev is not None and prev < curr:
        return no_update
    target = comparison_date(curr).isoformat()
    if prev == comparison_date(curr):
        return no_update
    return target


@callback(
    Output("cf-headline", "children"),
    Output("cf-volume-tables", "children"),
    Output("cf-origin-table", "children"),
    Output("cf-origin-chart", "figure"),
    Output("cf-list-loaded", "children"),
    Output("cf-list-relocated-in", "children"),
    Output("cf-list-relocated-out", "children"),
    Output("cf-list-updated", "children"),
    Output("cf-list-discharged", "children"),
    Output("cf-list-missing", "children"),
    Output("cf-countries", "options"),
    Output("cf-status", "children"),
    Output("cf-vessels-note", "children"),
    Output("cf-diversion-in", "children"),
    Input("cf-date-curr", "date"),
    Input("cf-date-prev", "date"),
    Input("cf-countries", "value"),
)
def update_comparison(curr_value, prev_value, countries):
    blanks = [no_update] * 10

    curr_date = _parse_date(curr_value)
    prev_date = _parse_date(prev_value)
    countries = countries or []

    if curr_date is None or prev_date is None:
        return (*blanks, no_update,
                _alert("Pick both snapshot dates."), no_update, html.Div())
    if not countries:
        return (*blanks, no_update,
                _alert("Pick at least one destination country."), no_update,
                html.Div())

    try:
        trades_curr = get_trades_snapshot(curr_date)
        trades_prev = get_trades_snapshot(prev_date)
    except Exception as ex:
        logger.exception("Snapshot load failed")
        return (*blanks, no_update,
                _alert(f"Snapshot load failed: {ex}", "error"), no_update,
                html.Div())

    vessels_curr, curr_as_of = get_vessels_for(curr_date)
    vessels_prev, prev_as_of = get_vessels_for(prev_date)

    try:
        clean_curr = create_clean_data(trades_curr, VOLUME_FILTER_M3,
                                       vessels_curr)
        clean_prev = create_clean_data(trades_prev, VOLUME_FILTER_M3,
                                       vessels_prev)
        clean_curr_inc_hist = create_clean_data(
            trades_curr, VOLUME_FILTER_M3, vessels_curr, inc_history=True)

        result = compare_snapshots(
            clean_curr, clean_prev, clean_curr_inc_hist,
            countries=countries,
            prev_snapshot_dt=snapshot_datetime(prev_date),
        )
    except Exception as ex:
        logger.exception("Comparison failed")
        return (*blanks, no_update,
                _alert(f"Comparison failed: {ex}", "error"), no_update,
                html.Div())

    zone_label = next(
        (name for name, preset in ZONE_PRESETS.items()
         if set(preset) == set(countries)),
        "Zone")

    curr_label = curr_date.strftime("%d-%b-%y")
    prev_label = prev_date.strftime("%d-%b-%y")

    headline = build_headline(result["summary"], zone_label)

    volume_tables = [
        html.Div([
            html.Div(zone_label, style={
                "fontSize": "12px", "fontWeight": "700",
                "marginBottom": "6px", "color": COLORS["text_secondary"]}),
            build_volume_by_source_table(result["volume_by_source"],
                                         zone_label),
        ]),
        html.Div([
            html.Div("Europe (no country)", style={
                "fontSize": "12px", "fontWeight": "700",
                "marginBottom": "6px", "color": COLORS["text_secondary"]}),
            build_volume_by_source_table(
                result["volume_europe_no_country"], "Europe (no country)"),
        ]),
    ]

    origin_table = build_origin_table(result["origin_breakdown"])
    origin_chart = build_origin_chart(result["origin_breakdown"],
                                      curr_label, prev_label)

    country_options = sorted(
        set(clean_curr["ToCountry"].dropna().astype(str))
        | set(clean_prev["ToCountry"].dropna().astype(str))
        | set(countries))
    options = [{"label": c, "value": c} for c in country_options if c.strip()]

    status_msg = (
        f"Comparing {curr_label} vs {prev_label} (~06:00 UTC snapshots) — "
        f"zone: {', '.join(countries)}")
    if curr_date <= prev_date:
        status_msg += "  ·  note: 'current' date is not after comparison date"
    status = _alert(status_msg, "success")

    vessels_bits = []
    if vessels_curr is None:
        vessels_bits.append(
            "Vessels data unavailable — floating-storage tags and "
            "destination backfill skipped.")
    else:
        if not curr_as_of or not prev_as_of:
            vessels_bits.append(
                "Floating-storage tags / destination backfill use the "
                "current fleet state where no stored daily vessels pull "
                "exists for the selected date(s) — Kpler has no historical "
                "vessels endpoint; the store saves one pull per day from "
                "first use onwards.")
        else:
            vessels_bits.append(
                "Floating-storage tags / destination backfill use the "
                "stored daily vessels pulls for both selected dates.")
    vessels_note = " ".join(vessels_bits)

    return (
        headline,
        volume_tables,
        origin_table,
        origin_chart,
        build_cargo_list(result["loaded"]),
        build_cargo_list(result["relocated_in"]),
        build_cargo_list(result["relocated_out"]),
        build_cargo_list(result["updated"]),
        build_cargo_list(result["discharged"]),
        build_cargo_list(result["missing"]),
        options,
        status,
        vessels_note,
        build_diversion_boxes(
            result["relocated_in"], result["relocated_out"], zone_label),
    )


# ---------------------------------------------------------------------------
# Snapshot cache status / backfill
# ---------------------------------------------------------------------------

@callback(
    Output("cf-coverage-chart", "figure"),
    Output("cf-coverage-summary", "children"),
    Input("cf-date-curr", "date"),          # refresh on page interaction
    Input("cf-backfill-poll", "disabled"),  # refresh when a backfill ends
)
def update_coverage(_curr_date, _poll_disabled):
    try:
        cover = get_coverage()
    except Exception as ex:
        logger.exception("Coverage read failed")
        return {"data": [], "layout": {"height": 120}}, f"Coverage unavailable: {ex}"

    n_total = len(cover)
    n_cached = int(cover["cached"].sum())
    cached_dates = cover.index[cover["cached"]]
    if len(cached_dates):
        summary = (
            f"{n_cached:,} of {n_total:,} days cached on S3 "
            f"({cover.index[0]:%d-%b-%Y} → {cover.index[-1]:%d-%b-%Y}); "
            f"earliest cached {cached_dates[0]:%d-%b-%Y}, "
            f"latest {cached_dates[-1]:%d-%b-%Y}, "
            f"{n_total - n_cached:,} missing.")
    else:
        summary = (
            f"No snapshots cached yet in the default window "
            f"({cover.index[0]:%d-%b-%Y} → {cover.index[-1]:%d-%b-%Y}). "
            f"Viewing a date fetches and stores it; use backfill for bulk.")
    return build_coverage_figure(cover), summary


@callback(
    Output("cf-backfill-poll", "disabled", allow_duplicate=True),
    Output("cf-backfill-status", "children", allow_duplicate=True),
    Input("cf-backfill-start-btn", "n_clicks"),
    State("cf-backfill-start", "date"),
    State("cf-backfill-end", "date"),
    prevent_initial_call=True,
)
def kick_backfill(n_clicks, start_value, end_value):
    if not n_clicks:
        return no_update, no_update
    start = _parse_date(start_value)
    end = _parse_date(end_value)
    if start is None or end is None:
        return True, "Pick a start and end date for the backfill."
    if end < start:
        return True, "Backfill end date is before the start date."
    if not start_backfill(start, end):
        return False, "A backfill is already running."
    return False, f"Backfill started: {start} → {end}"


@callback(
    Output("cf-backfill-poll", "disabled", allow_duplicate=True),
    Output("cf-backfill-status", "children", allow_duplicate=True),
    Input("cf-backfill-poll", "n_intervals"),
    prevent_initial_call=True,
)
def poll_backfill(_n):
    state = get_backfill_state()
    errors = state["errors"]
    err_txt = f"  ·  {len(errors)} error(s)" if errors else ""

    if state["running"]:
        if state["total"]:
            msg = (f"Backfilling… {state['done']}/{state['total']} "
                   f"(current: {state['current']}){err_txt}")
        else:
            msg = "Backfilling… checking coverage"
        return False, msg

    summary = state.get("summary")
    if summary:
        msg = (f"Backfill finished: {summary['fetched']} fetched, "
               f"{summary['already_cached']} already cached, "
               f"{summary['failed']} failed.")
        return True, msg
    if errors:
        return True, f"Backfill stopped{err_txt}: {errors[-1]}"
    return True, no_update
