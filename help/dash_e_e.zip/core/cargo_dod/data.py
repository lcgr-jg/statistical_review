"""Data access for the Cargo DoD Changes page.

Wraps ``jain_commods.core.interfaces.kpler.pit_store.KplerPITStore`` with the
dashboard's own Kpler credentials (env vars), a repo-local parquet cache and
a small in-memory cache of cleaned snapshots (they are immutable).

Also owns the background backfill state used by the cache-status panel.
"""
from __future__ import annotations

import logging
import threading
from datetime import date, datetime, timedelta, timezone
from typing import Any

import pandas as pd

from jain_commods.core.interfaces.kpler.mappings import (
    trades_mapping,
    vessels_mapping,
)
from jain_commods.core.interfaces.kpler.pit_store import KplerPITStore

from core.cargo_dod.constants import (
    COVERAGE_DEFAULT_START,
    PIT_LOCAL_CACHE_DIR,
    SNAPSHOT_HOUR_UTC,
)
from core.lng_data_kpler.api import kpler_credentials
from core.lng_data_kpler.data import get_dataset_vessels

logger = logging.getLogger(__name__)

_store: KplerPITStore | None = None
_store_lock = threading.Lock()

# Immutable snapshots -> simple bounded in-memory cache keyed by date
_snapshot_cache: dict[date, pd.DataFrame] = {}
_snapshot_cache_lock = threading.Lock()
_SNAPSHOT_CACHE_MAX = 16


def get_store() -> KplerPITStore:
    """Singleton PIT store using the dashboard's Kpler env credentials."""
    global _store
    with _store_lock:
        if _store is None:
            try:
                email, password = kpler_credentials()
            except RuntimeError:
                # Fall back to jain_commods.login inside the store
                email = password = None
            _store = KplerPITStore(
                api_user=email,
                api_pw=password,
                local_dir=PIT_LOCAL_CACHE_DIR,
                snapshot_hour_utc=SNAPSHOT_HOUR_UTC,
            )
        return _store


def max_selectable_date() -> date:
    """Latest date whose ~06:00 UTC snapshot should exist."""
    now_utc = datetime.now(timezone.utc)
    if now_utc.hour < SNAPSHOT_HOUR_UTC:
        return now_utc.date() - timedelta(days=1)
    return now_utc.date()


def comparison_date(curr: date) -> date:
    """Snapshot to compare against: previous day, or Friday when *curr* is Monday."""
    days_offset = 3 if curr.weekday() == 0 else 1
    return curr - timedelta(days=days_offset)


def default_dates() -> tuple[date, date]:
    """Default comparison pair, replicating the report's ``get_dates``:

    current = latest available day; comparison = previous business day
    (Friday when current is a Monday).
    """
    curr = max_selectable_date()
    return curr, comparison_date(curr)


def get_trades_snapshot(snapshot_date: date) -> pd.DataFrame:
    """One trades snapshot with DB-style column names (immutable, cached)."""
    with _snapshot_cache_lock:
        cached = _snapshot_cache.get(snapshot_date)
    if cached is not None:
        return cached

    raw = get_store().get_trades_snapshot(snapshot_date)
    df = raw.rename(columns=trades_mapping)

    with _snapshot_cache_lock:
        if len(_snapshot_cache) >= _SNAPSHOT_CACHE_MAX:
            oldest = next(iter(_snapshot_cache))
            _snapshot_cache.pop(oldest, None)
        _snapshot_cache[snapshot_date] = df
    return df


def get_vessels_for(snapshot_date: date) -> tuple[pd.DataFrame | None, bool]:
    """Best-available vessels state for *snapshot_date*.

    Returns ``(vessels_df, as_of)`` with DB-style column names.  *as_of* is
    True when the frame is the stored daily pull for that exact date; False
    when we had to fall back to the current fleet (Kpler has no historical
    vessels endpoint).
    """
    try:
        stored = get_store().get_daily_vessels(snapshot_date)
    except Exception as ex:
        logger.warning("Daily vessels read failed for %s: %s", snapshot_date, ex)
        stored = None
    if stored is not None:
        return stored.rename(columns=vessels_mapping), True

    try:
        current = get_dataset_vessels()
    except Exception as ex:
        logger.warning("Cached current vessels unavailable: %s", ex)
        return None, False
    return current.rename(columns=vessels_mapping), False


def snapshot_datetime(snapshot_date: date) -> datetime:
    return datetime(snapshot_date.year, snapshot_date.month,
                    snapshot_date.day, SNAPSHOT_HOUR_UTC)


# ---------------------------------------------------------------------------
# Coverage / backfill (cache-status panel)
# ---------------------------------------------------------------------------

def get_coverage(start: date | None = None,
                 end: date | None = None) -> pd.DataFrame:
    start = start or COVERAGE_DEFAULT_START
    return get_store().coverage(start=start, end=end)


_backfill_lock = threading.Lock()
_backfill_state: dict[str, Any] = {
    "running": False,
    "done": 0,
    "total": 0,
    "current": None,
    "errors": [],
    "summary": None,
    "started_at": None,
}


def get_backfill_state() -> dict[str, Any]:
    with _backfill_lock:
        return dict(_backfill_state)


def _run_backfill(start: date, end: date) -> None:
    def progress(done, total, snapshot_date, error):
        with _backfill_lock:
            _backfill_state["done"] = done
            _backfill_state["total"] = total
            _backfill_state["current"] = str(snapshot_date)
            if error is not None:
                _backfill_state["errors"].append(
                    f"{snapshot_date}: {error}")

    try:
        summary = get_store().backfill(
            start, end, progress_callback=progress, throttle_seconds=1.0)
        with _backfill_lock:
            _backfill_state["summary"] = summary
    except Exception as ex:
        logger.exception("Backfill thread failed: %s", ex)
        with _backfill_lock:
            _backfill_state["errors"].append(f"fatal: {ex}")
    finally:
        with _backfill_lock:
            _backfill_state["running"] = False


def start_backfill(start: date, end: date) -> bool:
    """Kick off a background backfill; returns False if one is running."""
    with _backfill_lock:
        if _backfill_state["running"]:
            return False
        _backfill_state.update({
            "running": True,
            "done": 0,
            "total": 0,
            "current": None,
            "errors": [],
            "summary": None,
            "started_at": datetime.now().isoformat(timespec="seconds"),
        })
    thread = threading.Thread(
        target=_run_backfill, args=(start, end),
        name="kpler-pit-backfill", daemon=True)
    thread.start()
    return True
