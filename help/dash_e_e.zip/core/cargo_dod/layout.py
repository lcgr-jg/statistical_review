﻿"""Layout for the LNG — Cargo DoD Changes page."""
from __future__ import annotations

from dash import dcc, html

from core.cargo_dod.constants import (
    CUSTOM_ZONE,
    DEFAULT_ZONE,
    EARLIEST_SNAPSHOT_DATE,
    ZONE_PRESETS,
)
from core.cargo_dod.data import default_dates, max_selectable_date
from core.styles import COLORS

_CONTROL_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "padding": "16px 24px",
    "borderRadius": "12px",
    "border": f"1px solid {COLORS['border']}",
    "marginBottom": "20px",
    "boxShadow": "none",
    "display": "flex",
    "alignItems": "flex-end",
    "flexWrap": "wrap",
    "gap": "18px",
}

_CONTENT_PANEL = {
    "backgroundColor": COLORS["card_bg"],
    "border": f"1px solid {COLORS['border']}",
    "borderRadius": "12px",
    "boxShadow": "none",
    "overflow": "hidden",
    "marginBottom": "20px",
    "padding": "16px 20px 20px 20px",
}

_PANEL_TITLE = {
    "fontSize": "14px",
    "fontWeight": "600",
    "color": COLORS["text_primary"],
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "margin": "0 0 12px 0",
}

_LABEL = {
    "fontSize": "12px",
    "fontWeight": "600",
    "color": COLORS["text_secondary"],
    "marginBottom": "6px",
    "display": "block",
}

_BTN_PRIMARY = {
    "padding": "10px 20px",
    "backgroundColor": COLORS["accent"],
    "color": "#ffffff",
    "border": "none",
    "borderRadius": "6px",
    "fontSize": "13px",
    "fontWeight": "600",
    "cursor": "pointer",
}

_NOTE = {
    "fontSize": "12px",
    "color": COLORS["text_muted"],
    "margin": "8px 0 0 0",
    "lineHeight": "1.5",
}


def _change_section(title: str, container_id: str) -> html.Div:
    return html.Div([
        html.H4(title, style={
            "fontSize": "13px", "fontWeight": "700",
            "color": COLORS["text_primary"], "margin": "14px 0 4px 0"}),
        html.Div(id=container_id),
    ])


def build_layout() -> html.Div:
    curr_default, prev_default = default_dates()
    max_date = max_selectable_date()

    zone_options = [{"label": z, "value": z} for z in ZONE_PRESETS]
    zone_options.append({"label": CUSTOM_ZONE, "value": CUSTOM_ZONE})

    return html.Div(
        style={"padding": "24px 28px", "maxWidth": "1400px"},
        children=[
            html.Div([
                html.H1("Cargo DoD Changes", style={
                    "fontSize": "22px", "fontWeight": "600",
                    "color": COLORS["text_primary"], "margin": "0 0 4px 0"}),
                html.P(
                    "Inspect day-on-day changes in expected LNG arrivals by "
                    "comparing two Kpler point-in-time snapshots (~06:00 UTC "
                    "each day), queried direct from the Kpler API and cached "
                    "permanently on S3.",
                    style={"fontSize": "13px", "color": COLORS["text_muted"],
                           "margin": "0 0 4px 0"}),
                html.P(
                    "Everything is anchored to the daily 06:00 UTC snapshot, "
                    "so before 06:00 UTC today's date is not yet selectable "
                    "— the latest available snapshot is yesterday's.",
                    style={"fontSize": "12px", "color": COLORS["text_muted"],
                           "fontStyle": "italic", "margin": "0 0 12px 0"}),
            ]),

            # ── Controls ────────────────────────────────────────────────
            html.Div(
                style=_CONTROL_PANEL,
                children=[
                    html.Div([
                        html.Label("Current snapshot", style=_LABEL),
                        dcc.DatePickerSingle(
                            id="cf-date-curr",
                            date=curr_default,
                            min_date_allowed=EARLIEST_SNAPSHOT_DATE,
                            max_date_allowed=max_date,
                            display_format="DD-MMM-YYYY",
                            first_day_of_week=1,
                        ),
                    ]),
                    html.Div([
                        html.Label(
                            "Compare against (prev business day; Fri when "
                            "Mon)", style=_LABEL),
                        dcc.DatePickerSingle(
                            id="cf-date-prev",
                            date=prev_default,
                            min_date_allowed=EARLIEST_SNAPSHOT_DATE,
                            max_date_allowed=max_date,
                            display_format="DD-MMM-YYYY",
                            first_day_of_week=1,
                        ),
                    ]),
                    html.Div([
                        html.Label("Zone", style=_LABEL),
                        dcc.Dropdown(
                            id="cf-zone-preset",
                            options=zone_options,
                            value=DEFAULT_ZONE,
                            clearable=False,
                            style={"width": "170px"},
                        ),
                    ]),
                    html.Div(
                        style={"flex": "1 1 340px", "minWidth": "300px"},
                        children=[
                            html.Label("Destination countries", style=_LABEL),
                            dcc.Dropdown(
                                id="cf-countries",
                                options=[],
                                value=list(ZONE_PRESETS[DEFAULT_ZONE]),
                                multi=True,
                                placeholder="Pick destination countries…",
                            ),
                        ],
                    ),
                    html.Div(id="cf-status", style={"flexBasis": "100%"}),
                ],
            ),

            # ── Diversions in and out (only rendered when there are any) ──
            html.Div(id="cf-diversion-in"),

            # ── Headline summary ────────────────────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Summary", style=_PANEL_TITLE),
                dcc.Loading(type="circle",
                            children=html.Div(id="cf-headline")),
            ]),

            # ── Volume by source ────────────────────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Cargo volume by ETA source (mcm)",
                        style=_PANEL_TITLE),
                dcc.Loading(type="circle", children=html.Div(
                    id="cf-volume-tables",
                    style={"display": "flex", "gap": "40px",
                           "flexWrap": "wrap"})),
                html.P(
                    "\"Europe (no country)\" = destination continent Europe "
                    "but no country assigned (global, not zone-filtered). "
                    "Weighted = volume × confidence "
                    "(Port 1, AIS 0.9, Market/Analyst 0.75, Model per "
                    "Kpler).", style=_NOTE),
            ]),

            # ── Origin breakdown ────────────────────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Current lineup by origin", style=_PANEL_TITLE),
                html.P(
                    "Where the zone-bound cargoes loaded, and how that mix "
                    "changed between the two snapshots — a jump from a "
                    "single origin stands out here.",
                    style={"fontSize": "13px",
                           "color": COLORS["text_secondary"],
                           "margin": "0 0 14px 0"}),
                dcc.Loading(type="circle", children=html.Div(
                    style={"display": "flex", "gap": "30px",
                           "flexWrap": "wrap", "alignItems": "flex-start"},
                    children=[
                        html.Div(id="cf-origin-table",
                                 style={"flex": "0 0 auto"}),
                        html.Div(
                            dcc.Graph(
                                id="cf-origin-chart",
                                config={"displayModeBar": False},
                            ),
                            style={"flex": "1 1 480px", "minWidth": "420px"}),
                    ])),
            ]),

            # ── Change detail ───────────────────────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.H3("Cargo changes", style=_PANEL_TITLE),
                dcc.Loading(type="circle", children=html.Div([
                    _change_section("New / recently loaded", "cf-list-loaded"),
                    _change_section("Reallocated into zone",
                                    "cf-list-relocated-in"),
                    _change_section("Reallocated out of zone",
                                    "cf-list-relocated-out"),
                    _change_section("Updated within zone", "cf-list-updated"),
                    _change_section("Discharged between snapshots",
                                    "cf-list-discharged"),
                    _change_section("Missing (left zone, no longer tracked)",
                                    "cf-list-missing"),
                ])),
                html.P([
                    "Key: ",
                    html.Span("floating storage", style={
                        "backgroundColor": "#fff3bf", "padding": "1px 6px",
                        "borderRadius": "3px"}),
                    "  ·  ",
                    html.Span("potential diversion into zone", style={
                        "backgroundColor": "#d3f9d8", "padding": "1px 6px",
                        "borderRadius": "3px", "color": "#1b7f37"}),
                    "  ·  ",
                    html.Span("potential diversion out of zone", style={
                        "backgroundColor": "#ffe3e3", "padding": "1px 6px",
                        "borderRadius": "3px"}),
                    "  ·  vessel names link to the Kpler terminal map. "
                    "Minimum cargo size 10,000 m³ LNG. All cargoes on the "
                    "water are considered irrespective of delivery date.",
                ], style=_NOTE),
                html.Div(id="cf-vessels-note", style=_NOTE),
            ]),

            # ── Snapshot cache status ───────────────────────────────────
            html.Div(style=_CONTENT_PANEL, children=[
                html.Details([
                    html.Summary("Snapshot cache status", style={
                        **_PANEL_TITLE, "cursor": "pointer",
                        "display": "list-item"}),
                    html.Div(id="cf-coverage-summary",
                             style={"fontSize": "13px",
                                    "color": COLORS["text_secondary"],
                                    "margin": "10px 0"}),
                    dcc.Loading(type="circle", children=dcc.Graph(
                        id="cf-coverage-chart",
                        config={"displayModeBar": False})),
                    html.Div(
                        style={"display": "flex", "gap": "16px",
                               "alignItems": "flex-end", "flexWrap": "wrap",
                               "marginTop": "12px"},
                        children=[
                            html.Div([
                                html.Label("Backfill from", style=_LABEL),
                                dcc.DatePickerSingle(
                                    id="cf-backfill-start",
                                    min_date_allowed=EARLIEST_SNAPSHOT_DATE,
                                    max_date_allowed=max_date,
                                    display_format="DD-MMM-YYYY",
                                    first_day_of_week=1,
                                    # Open in a centered portal: these sit at
                                    # the bottom of the page inside an
                                    # overflow-hidden panel, so a dropdown
                                    # calendar gets clipped.
                                    with_portal=True,
                                ),
                            ]),
                            html.Div([
                                html.Label("to", style=_LABEL),
                                dcc.DatePickerSingle(
                                    id="cf-backfill-end",
                                    min_date_allowed=EARLIEST_SNAPSHOT_DATE,
                                    max_date_allowed=max_date,
                                    display_format="DD-MMM-YYYY",
                                    first_day_of_week=1,
                                    with_portal=True,
                                ),
                            ]),
                            html.Button("Backfill missing",
                                        id="cf-backfill-start-btn",
                                        n_clicks=0, style=_BTN_PRIMARY),
                            html.Div(id="cf-backfill-status",
                                     style={"fontSize": "13px",
                                            "color":
                                                COLORS["text_secondary"]}),
                        ],
                    ),
                    html.P(
                        "Snapshots are immutable: each date is fetched from "
                        "Kpler once and stored permanently on S3 "
                        "(commodity-data-cache/kpler/lng/). Missing days "
                        "here can be filled with the control above; "
                        "multi-year builds are better run via "
                        "eu_corelib/scripts/backfill_kpler_snapshots.py.",
                        style=_NOTE),
                ], open=False),
            ]),

            dcc.Interval(id="cf-backfill-poll", interval=2000,
                         disabled=True),
        ],
    )
