"""LNG — Cargo DoD Changes page package.

Day-on-day LNG cargo lineup comparison between two user-selected Kpler
point-in-time snapshots, sourced direct from the Kpler API via the shared
``KplerPITStore`` (eu_corelib) with permanent parquet caching on S3.
"""
