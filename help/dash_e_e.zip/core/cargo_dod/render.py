"""Dash component builders for the Cargo DoD Changes page."""
from __future__ import annotations

from typing import Any

import pandas as pd
import plotly.graph_objects as go
from dash import html

from core.cargo_dod.constants import KPLER_VESSEL_MAP_URL
from core.styles import COLORS

_POSITIVE = COLORS["accent_green"]
_NEGATIVE = COLORS["danger"]
_FLOATING_BG = "#fff3bf"   # floating-storage highlight (report used yellow)
_DIVERSION_BG = "#ffe3e3"  # potential diversion out of zone
_DIVERSION_IN_BG = "#d3f9d8"  # potential diversion into zone
_DIVERSION_IN_TEXT = "#1b7f37"

_TABLE_STYLE = {
    "borderCollapse": "collapse",
    "fontSize": "13px",
    "color": COLORS["text_primary"],
}
_TH_STYLE = {
    "backgroundColor": COLORS["table_header_bg"],
    "border": f"1px solid {COLORS['border']}",
    "padding": "6px 12px",
    "textAlign": "right",
    "fontWeight": "600",
}
_TD_STYLE = {
    "border": f"1px solid {COLORS['border']}",
    "padding": "5px 12px",
    "textAlign": "right",
}


def _delta_span(value: float, fmt: str = "{:+,.0f}") -> html.Span:
    color = _POSITIVE if value >= 0 else _NEGATIVE
    return html.Span(fmt.format(value), style={"color": color,
                                               "fontWeight": "600"})


def build_headline(summary: dict[str, Any], zone_label: str) -> html.Div:
    """Summary cards: cargo count and volume with DoD deltas + bucket counts."""
    def _card(title: str, value: str, delta: float) -> html.Div:
        return html.Div(
            style={
                "flex": "0 0 auto",
                "minWidth": "180px",
                "padding": "12px 18px",
                "borderRadius": "10px",
                "border": f"1px solid {COLORS['border']}",
                "backgroundColor": COLORS["card_bg_alt"],
            },
            children=[
                html.Div(title, style={
                    "fontSize": "11px", "fontWeight": "600",
                    "textTransform": "uppercase",
                    "color": COLORS["text_muted"],
                    "letterSpacing": "0.5px"}),
                html.Div(
                    [html.Span(value, style={
                        "fontSize": "22px", "fontWeight": "700",
                        "marginRight": "8px"}),
                     _delta_span(delta)],
                    style={"marginTop": "4px"}),
            ],
        )

    s = summary
    detail_bits = [
        f"{s['n_loaded']} new loaded ({s['volume_loaded']:,.0f}mcm)",
        f"{s['n_relocated_in']} reallocated in ({s['volume_relocated_in']:,.0f}mcm)",
        f"{s['n_relocated_out']} reallocated out ({s['volume_relocated_out']:,.0f}mcm)",
        f"{s['n_discharged']} discharged ({s['volume_discharged']:,.0f}mcm)",
        f"{s['n_missing']} missing ({s['volume_missing']:,.0f}mcm)",
        f"{s['n_updated']} updated in zone ({s['volume_updated']:,.0f}mcm)",
    ]

    children: list = [
        html.Div(
            style={"display": "flex", "gap": "16px", "flexWrap": "wrap"},
            children=[
                _card(f"{zone_label} cargoes", f"{s['cargo_curr']:,}",
                      s["cargo_change"]),
                _card(f"{zone_label} volume (mcm)", f"{s['volume_curr']:,.0f}",
                      s["volume_change"]),
            ],
        ),
        html.Div(
            " · ".join(detail_bits),
            style={"marginTop": "10px", "fontSize": "13px",
                   "color": COLORS["text_secondary"]},
        ),
    ]

    return html.Div(children)


def _vessel_link(record: dict[str, Any]) -> html.A:
    return html.A(
        record["vessel"],
        href=KPLER_VESSEL_MAP_URL.format(record["kpler_vessel_id"]),
        target="_blank",
        style={"fontWeight": "600", "color": COLORS["accent"],
               "textDecoration": "none"},
    )


def build_cargo_list(records: list[dict[str, Any]],
                     show_destination: bool = True) -> html.Div:
    """Bullet list of cargo records, mirroring the report's change lists."""
    if not records:
        return html.Div("No change", style={
            "fontSize": "13px", "color": COLORS["text_muted"],
            "padding": "2px 0 8px 0"})

    items = []
    for record in records:
        bg = None
        if record.get("diversion") == "in":
            bg = _DIVERSION_IN_BG
        elif record.get("diversion") == "out":
            bg = _DIVERSION_BG
        elif record.get("floating"):
            bg = _FLOATING_BG

        intro = (f" ({record['volume_mcm']:.0f}mcm) loaded in "
                 f"{record['from_country']} on {record['departure_date']}")

        if record["changes"]:
            detail = ": " + ", ".join(record["changes"])
        elif show_destination:
            detail = (f": ToCountry: {record['to_country']}, "
                      f"ToTerminal: {record['to_terminal']}, "
                      f"ETA: {record['eta']}, Source/Confidence: "
                      f"{record['source']}/{record['confidence']}")
        else:
            detail = ""

        items.append(html.Li(
            [html.Span([_vessel_link(record)],
                       style={"backgroundColor": bg} if bg else {}),
             html.Span(intro + detail)],
            style={"marginBottom": "4px", "fontSize": "13px",
                   "lineHeight": "1.5"},
        ))
    return html.Ul(items, style={"paddingLeft": "22px", "margin": "4px 0 8px 0"})


def _diversion_box(records: list[dict[str, Any]], title: str, note: str,
                   background: str, foreground: str) -> html.Div | None:
    if not records:
        return None
    return html.Div(
        style={
            "backgroundColor": background,
            "border": f"1px solid {foreground}",
            "borderRadius": "12px",
            "padding": "14px 18px 8px 18px",
            "marginBottom": "20px",
        },
        children=[
            html.Div(title, style={
                "fontSize": "14px", "fontWeight": "700",
                "color": foreground,
                "textTransform": "uppercase",
                "letterSpacing": "0.4px",
            }),
            html.Div(note, style={
                "fontSize": "12px", "color": foreground, "marginTop": "4px"}),
            build_cargo_list(records),
        ],
    )


def build_diversion_boxes(relocated_in: list[dict[str, Any]],
                          relocated_out: list[dict[str, Any]],
                          zone_label: str) -> html.Div:
    """Matching banners at the top of the page for diversions in and out."""
    inbound = [r for r in relocated_in if r.get("diversion") == "in"]
    outbound = [r for r in relocated_out if r.get("diversion") == "out"]
    n_in, n_out = len(inbound), len(outbound)
    boxes = [
        _diversion_box(
            inbound,
            f"{n_in} possible diversion{'' if n_in == 1 else 's'} "
            f"into {zone_label}",
            "Previously an AIS or Port destination outside the zone, "
            "now pointing inside.",
            _DIVERSION_IN_BG,
            _DIVERSION_IN_TEXT,
        ),
        _diversion_box(
            outbound,
            f"{n_out} possible diversion{'' if n_out == 1 else 's'} "
            f"out of {zone_label}",
            "Previously an AIS or Port destination inside the zone, "
            "now pointing outside.",
            _DIVERSION_BG,
            COLORS["danger"],
        ),
    ]
    return html.Div([box for box in boxes if box is not None])


def build_volume_by_source_table(df: pd.DataFrame, zone_label: str) -> html.Table:
    """'1,234 (+56)' style volume-per-source table (raw + weighted)."""
    header = html.Tr([
        html.Th("Source", style={**_TH_STYLE, "textAlign": "left"}),
        html.Th(f"{zone_label} (\u0394)", style=_TH_STYLE),
        html.Th("Weighted (\u0394)", style=_TH_STYLE),
    ])
    rows = []
    for source, row in df.iterrows():
        is_total = source == "Total"
        weight = {"fontWeight": "700"} if is_total else {}
        rows.append(html.Tr([
            html.Td(source, style={**_TD_STYLE, "textAlign": "left", **weight}),
            html.Td([f"{row['volume']:,.0f} (",
                     _delta_span(row["volume_diff"]), ")"],
                    style={**_TD_STYLE, **weight}),
            html.Td([f"{row['weighted']:,.0f} (",
                     _delta_span(row["weighted_diff"]), ")"],
                    style={**_TD_STYLE, **weight}),
        ]))
    return html.Table([html.Thead(header), html.Tbody(rows)],
                      style=_TABLE_STYLE)


def build_origin_table(df: pd.DataFrame) -> html.Table:
    header = html.Tr([
        html.Th("Origin", style={**_TH_STYLE, "textAlign": "left"}),
        html.Th("Cargoes (\u0394)", style=_TH_STYLE),
        html.Th("Volume mcm (\u0394)", style=_TH_STYLE),
    ])
    rows = []
    for origin, row in df.iterrows():
        is_total = origin == "Total"
        weight = {"fontWeight": "700"} if is_total else {}
        rows.append(html.Tr([
            html.Td(str(origin),
                    style={**_TD_STYLE, "textAlign": "left", **weight}),
            html.Td([f"{row['cargoes']:,.0f} (",
                     _delta_span(row["cargoes_diff"]), ")"],
                    style={**_TD_STYLE, **weight}),
            html.Td([f"{row['volume']:,.0f} (",
                     _delta_span(row["volume_diff"]), ")"],
                    style={**_TD_STYLE, **weight}),
        ]))
    return html.Table([html.Thead(header), html.Tbody(rows)],
                      style=_TABLE_STYLE)


def build_origin_chart(df: pd.DataFrame, curr_label: str,
                       prev_label: str) -> go.Figure:
    """Grouped bars of zone-bound volume by origin country, current vs prev."""
    plot_df = df.drop(index="Total", errors="ignore")
    fig = go.Figure()
    fig.add_bar(x=plot_df.index, y=plot_df["volume_prev"], name=prev_label,
                marker_color=COLORS["text_muted"])
    fig.add_bar(x=plot_df.index, y=plot_df["volume"], name=curr_label,
                marker_color=COLORS["accent"])
    fig.update_layout(
        barmode="group",
        margin={"l": 40, "r": 20, "t": 30, "b": 60},
        height=360,
        yaxis_title="Volume (mcm)",
        plot_bgcolor=COLORS["chart_bg"],
        paper_bgcolor=COLORS["chart_paper"],
        legend={"orientation": "h", "y": 1.12},
        font={"size": 12},
    )
    return fig


def build_coverage_figure(cover: pd.DataFrame) -> go.Figure:
    """Calendar-style coverage strip: one row per year, day-of-year on x."""
    df = cover.copy()
    df["year"] = df.index.year
    df["doy"] = df.index.dayofyear

    years = sorted(df["year"].unique(), reverse=True)
    z, text = [], []
    for year in years:
        year_df = df[df["year"] == year]
        row = [None] * 366
        hover = [""] * 366
        for ts, doy, cached in zip(year_df.index, year_df["doy"],
                                   year_df["cached"]):
            row[doy - 1] = 1 if cached else 0
            hover[doy - 1] = (ts.strftime("%d-%b-%Y")
                              + (" — cached" if cached else " — missing"))
        z.append(row)
        text.append(hover)

    fig = go.Figure(go.Heatmap(
        z=z,
        y=[str(y) for y in years],
        x=list(range(1, 367)),
        text=text,
        hoverinfo="text",
        colorscale=[[0, COLORS["danger"]], [1, COLORS["accent_green"]]],
        zmin=0, zmax=1,
        showscale=False,
        xgap=1, ygap=3,
    ))
    month_starts = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
    month_labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    fig.update_layout(
        height=60 + 34 * len(years),
        margin={"l": 50, "r": 20, "t": 10, "b": 30},
        xaxis={"tickvals": month_starts, "ticktext": month_labels,
               "showgrid": False},
        yaxis={"showgrid": False},
        plot_bgcolor=COLORS["card_bg"],
        paper_bgcolor=COLORS["card_bg"],
        font={"size": 11},
    )
    return fig
