"""Snapshot cleaning + day-on-day comparison logic for the Cargo DoD Changes page.

Ported from ``eu_reports/lng_vessels/util.py`` (create_clean_data + the
comparison section of get_report), adapted to:

* work on Kpler API-native snapshots renamed to DB-style columns via
  ``jain_commods.core.interfaces.kpler.mappings.trades_mapping``;
* take an arbitrary destination-country list (zone) instead of hardcoded NWE;
* return structured data (dicts/DataFrames) instead of HTML strings;
* classify "new to zone" against zone membership first, then against the
  global previous snapshot — the report compared against the global set
  directly, which dropped vessels redirected into the zone from elsewhere.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd

from core.cargo_dod.constants import M3_LNG_TO_MCM

# Clean-column mapping: DB-style names (post trades_mapping rename) -> the
# friendly names used by the report's comparison logic.
CLEAN_COLUMNS = {
    "vessel": "Vessel",
    "imo_vessel": "IMO",
    "id_vessel": "KplerVesselId",
    "date_origin": "DepartureDate",
    "date_destination": "DestinationDate",
    "trade_status": "Status",
    "installation_origin": "FromTerminal",
    "country_origin": "FromCountry",
    "continent_origin": "FromContinent",
    "installation_destination": "ToTerminal",
    "country_destination": "ToCountry",
    "ToContinent": "ToContinent",
    "eta_source_destination": "Source",
    "forecasted_confidence": "Confidence",
    "volume_origin_m3": "Volume(m3)",
    "FloatingStorage": "FloatingStorage",
}


def _blank(series: pd.Series) -> pd.Series:
    """True where a value is missing or an empty/whitespace string."""
    return series.isna() | (series.astype(str).str.strip() == "")


def create_clean_data(
    df_trades: pd.DataFrame,
    volume_filter_m3: float,
    df_vessels: pd.DataFrame | None = None,
    inc_history: bool = False,
) -> pd.DataFrame:
    """Filter and normalise one trades snapshot (DB-style column names).

    Mirrors the report's ``create_clean_data``: volume filter, status filter
    (In Transit / Loading, + Delivered when *inc_history*), destination
    continent backfill, floating-storage tag from the vessels frame, source
    confidence weights and volume in mcm.
    """
    df = df_trades[df_trades["volume_origin_m3"] >= volume_filter_m3]

    reqd_status = ["In Transit", "Loading"]
    if inc_history:
        reqd_status = reqd_status + ["Delivered"]
    df = df[df["trade_status"].isin(reqd_status)].copy()

    # ToContinent: continent_destination -> forecasted_destination ->
    # zone_destination -> vessels.destination (joined on IMO)
    to_continent = df["continent_destination"].copy()
    for fallback_col in ("forecasted_destination", "zone_destination"):
        if fallback_col in df.columns:
            blank = _blank(to_continent)
            to_continent = to_continent.where(~blank, df[fallback_col])

    vessel_dest = None
    floating_imos: set = set()
    if df_vessels is not None and not df_vessels.empty:
        vs = df_vessels[["imo", "destination", "floating_storage"]].copy()
        vs["imo"] = pd.to_numeric(vs["imo"], errors="coerce")
        vs = vs.dropna(subset=["imo"]).drop_duplicates(subset=["imo"])
        vessel_dest = dict(zip(vs["imo"], vs["destination"]))
        floating = vs[vs["floating_storage"].fillna(False).astype(bool)]
        floating_imos = set(floating["imo"])

    imo = pd.to_numeric(df["imo_vessel"], errors="coerce")
    if vessel_dest:
        blank = _blank(to_continent)
        to_continent = to_continent.where(~blank, imo.map(vessel_dest))
    df["ToContinent"] = to_continent

    df["FloatingStorage"] = imo.isin(floating_imos).astype(int)

    df = df[list(CLEAN_COLUMNS.keys())].rename(columns=CLEAN_COLUMNS)

    # Parse dates (parquet stores API strings)
    for col in ("DepartureDate", "DestinationDate"):
        df[col] = pd.to_datetime(df[col], errors="coerce")

    # Confidence: Port 1, AIS 0.9, Market/Analyst 0.75, Model = Kpler value
    source = df["Source"].astype(str)
    model_conf = pd.to_numeric(df["Confidence"], errors="coerce")
    df["Confidence"] = np.select(
        [
            source == "Port",
            source == "AIS",
            source.isin(["Market", "Analyst"]),
            source == "Model",
        ],
        [1.0, 0.9, 0.75, model_conf],
        default=np.nan,
    )

    df["Volume(mcm)"] = df["Volume(m3)"] * M3_LNG_TO_MCM

    return df


# ---------------------------------------------------------------------------
# Comparison
# ---------------------------------------------------------------------------

def _fmt_dt(value) -> str:
    try:
        return pd.Timestamp(value).strftime("%d-%b-%y")
    except Exception:
        return str(value)


def _fmt_val(value) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "?"
    if isinstance(value, float):
        return f"{value:g}"
    text = str(value).strip()
    return text if text and text.lower() != "nan" else "?"


def _cargo_record(cargo: pd.Series, floating: bool = False) -> dict[str, Any]:
    return {
        "vessel": cargo["Vessel"],
        "imo": cargo["IMO"],
        "kpler_vessel_id": cargo["KplerVesselId"],
        "volume_mcm": float(cargo["Volume(mcm)"]),
        "from_country": _fmt_val(cargo["FromCountry"]),
        "departure_date": _fmt_dt(cargo["DepartureDate"]),
        "to_country": _fmt_val(cargo["ToCountry"]),
        "to_terminal": _fmt_val(cargo["ToTerminal"]),
        "eta": _fmt_dt(cargo["DestinationDate"]),
        "source": _fmt_val(cargo["Source"]),
        "confidence": cargo["Confidence"],
        "floating": bool(floating),
        "diversion": None,
        "changes": [],
    }


def _eta_change(curr_eta, prev_eta) -> str | None:
    """Report-style ETA change: only flag day-level moves."""
    if pd.isnull(prev_eta) and pd.isnull(curr_eta):
        return None
    if pd.isnull(prev_eta) or pd.isnull(curr_eta):
        return f"ETA was {_fmt_dt(prev_eta)} now {_fmt_dt(curr_eta)}"
    if curr_eta == prev_eta:
        return None
    seconds = abs((curr_eta - prev_eta).total_seconds())
    if seconds >= 86400 or curr_eta.day != prev_eta.day:
        direction = "back" if curr_eta > prev_eta else "forward"
        return (
            f"ETA was {_fmt_dt(prev_eta)} now {_fmt_dt(curr_eta)} "
            f"(moved {direction})"
        )
    return None


# Hard destination signals. A cargo that was AIS/Port and then moves
# zone is a potential diversion; Model/Market/Analyst are not.
_HARD_SOURCES = ("AIS", "Port")


def _diversion_direction(
    curr_cargo: pd.Series,
    prev_cargo: pd.Series,
    direction: str | None,
) -> str | None:
    """Return ``"in"``, ``"out"``, or None.

    Either direction: yesterday's destination source was AIS or Port, and
    the cargo has since moved into or out of the zone. Today's source and
    confidence are not part of the test.
    """
    del curr_cargo  # today's source is intentionally unused
    if direction not in ("in", "out"):
        return None
    if prev_cargo["Source"] not in _HARD_SOURCES:
        return None
    return direction


def _diff_record(
    curr_cargo: pd.Series,
    prev_cargo: pd.Series,
    floating: bool,
    diversion_direction: str | None = None,
) -> dict[str, Any]:
    """Structured change record between two states of the same vessel."""
    record = _cargo_record(curr_cargo, floating=floating)
    changes: list[str] = []

    possible_diversion = _diversion_direction(
        curr_cargo, prev_cargo, diversion_direction)

    if _fmt_val(curr_cargo["ToContinent"]) != _fmt_val(prev_cargo["ToContinent"]):
        changes.append(
            f"ToContinent was {_fmt_val(prev_cargo['ToContinent'])} "
            f"now {_fmt_val(curr_cargo['ToContinent'])}"
        )
    if _fmt_val(curr_cargo["ToCountry"]) != _fmt_val(prev_cargo["ToCountry"]):
        changes.append(
            f"ToCountry was {_fmt_val(prev_cargo['ToCountry'])} "
            f"now {_fmt_val(curr_cargo['ToCountry'])}"
        )
    if _fmt_val(curr_cargo["ToTerminal"]) != _fmt_val(prev_cargo["ToTerminal"]):
        changes.append(
            f"ToTerminal was {_fmt_val(prev_cargo['ToTerminal'])} "
            f"now {_fmt_val(curr_cargo['ToTerminal'])}"
        )

    eta_msg = _eta_change(curr_cargo["DestinationDate"],
                          prev_cargo["DestinationDate"])
    if eta_msg:
        changes.append(eta_msg)

    if curr_cargo["Source"] != prev_cargo["Source"]:
        changes.append(
            f"Source was {_fmt_val(prev_cargo['Source'])} "
            f"now {_fmt_val(curr_cargo['Source'])}"
        )

    curr_conf, prev_conf = curr_cargo["Confidence"], prev_cargo["Confidence"]
    conf_equal = (curr_conf == prev_conf) or (
        pd.isnull(curr_conf) and pd.isnull(prev_conf))
    if not conf_equal:
        changes.append(
            f"Confidence was {_fmt_val(prev_conf)} now {_fmt_val(curr_conf)}"
        )

    record["changes"] = changes
    record["diversion"] = possible_diversion
    return record


def _volume_by_source(curr: pd.DataFrame, prev: pd.DataFrame) -> pd.DataFrame:
    """Volume + confidence-weighted volume per ETA source with DoD deltas."""
    def _agg(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["Weighted"] = df["Volume(mcm)"] * df["Confidence"]
        out = df.groupby("Source")[["Volume(mcm)", "Weighted"]].sum()
        out.loc["Total"] = out.sum(numeric_only=True)
        return out

    curr_agg = _agg(curr).rename(
        columns={"Volume(mcm)": "volume", "Weighted": "weighted"})
    prev_agg = _agg(prev).rename(
        columns={"Volume(mcm)": "volume_prev", "Weighted": "weighted_prev"})
    combined = pd.concat([curr_agg, prev_agg], axis=1).fillna(0)
    combined["volume_diff"] = combined["volume"] - combined["volume_prev"]
    combined["weighted_diff"] = combined["weighted"] - combined["weighted_prev"]

    # Keep Total last, other sources alphabetical
    sources = sorted(i for i in combined.index if i != "Total")
    return combined.reindex(sources + ["Total"])


def _origin_breakdown(curr: pd.DataFrame, prev: pd.DataFrame) -> pd.DataFrame:
    """Cargo count + volume per origin country with DoD deltas."""
    def _agg(df: pd.DataFrame, suffix: str) -> pd.DataFrame:
        grouped = df.groupby("FromCountry").agg(
            cargoes=("Vessel", "count"),
            volume=("Volume(mcm)", "sum"),
        )
        return grouped.rename(columns={
            "cargoes": f"cargoes{suffix}", "volume": f"volume{suffix}"})

    combined = pd.concat([_agg(curr, ""), _agg(prev, "_prev")], axis=1).fillna(0)
    combined["cargoes_diff"] = combined["cargoes"] - combined["cargoes_prev"]
    combined["volume_diff"] = combined["volume"] - combined["volume_prev"]
    combined = combined.sort_values("volume", ascending=False)
    combined.loc["Total"] = combined.sum(numeric_only=True)
    return combined


def compare_snapshots(
    clean_curr: pd.DataFrame,
    clean_prev: pd.DataFrame,
    clean_curr_inc_hist: pd.DataFrame,
    countries: list[str],
    prev_snapshot_dt: datetime,
    curr_floating_imos: set | None = None,
) -> dict[str, Any]:
    """Full day-on-day comparison between two cleaned snapshots.

    Returns a dict of headline stats, per-bucket cargo records, the
    volume-by-source tables and the origin breakdown.
    """
    curr_floating_imos = curr_floating_imos or set(
        clean_curr.loc[clean_curr["FloatingStorage"] == 1, "IMO"])

    curr2zone = clean_curr[clean_curr["ToCountry"].isin(countries)]
    prev2zone = clean_prev[clean_prev["ToCountry"].isin(countries)]
    recentlydelivered_inzone = clean_curr_inc_hist[
        (clean_curr_inc_hist["ToCountry"].isin(countries))
        & (clean_curr_inc_hist["Status"] == "Delivered")
        & (clean_curr_inc_hist["DestinationDate"] >= pd.Timestamp(prev_snapshot_dt))
    ]

    curr_vessels = set(curr2zone["Vessel"])
    prev_vessels = set(prev2zone["Vessel"])
    prev_global = set(clean_prev["Vessel"])
    curr_global = set(clean_curr["Vessel"])

    # Into zone: not in the zone previously; loaded = brand new globally,
    # relocated_in = existed globally with a different destination.
    new_to_zone = curr_vessels - prev_vessels
    loaded = sorted(v for v in new_to_zone if v not in prev_global)
    relocated_in = sorted(v for v in new_to_zone if v in prev_global)

    # Out of zone: discharged / relocated out / missing
    left_zone = prev_vessels - curr_vessels
    delivered_vessels = set(recentlydelivered_inzone["Vessel"])
    discharged = sorted(v for v in left_zone if v in delivered_vessels)
    relocated_out = sorted(
        v for v in left_zone if v in curr_global and v not in discharged)
    missing = sorted(
        v for v in left_zone if v not in discharged and v not in relocated_out)

    common = sorted(curr_vessels & prev_vessels)

    def _is_floating(cargo: pd.Series) -> bool:
        return cargo["IMO"] in curr_floating_imos

    def _first(df: pd.DataFrame, vessel: str) -> pd.Series:
        return df[df["Vessel"] == vessel].iloc[0]

    records_loaded = []
    for v in loaded:
        cargo = _first(curr2zone, v)
        records_loaded.append(_cargo_record(cargo, floating=_is_floating(cargo)))

    records_relocated_in = []
    for v in relocated_in:
        curr_cargo = _first(curr2zone, v)
        prev_cargo = _first(clean_prev, v)
        records_relocated_in.append(_diff_record(
            curr_cargo, prev_cargo,
            floating=_is_floating(curr_cargo), diversion_direction="in"))

    records_relocated_out = []
    for v in relocated_out:
        curr_cargo = _first(clean_curr, v)
        prev_cargo = _first(prev2zone, v)
        records_relocated_out.append(_diff_record(
            curr_cargo, prev_cargo,
            floating=_is_floating(curr_cargo), diversion_direction="out"))

    records_missing = []
    for v in missing:
        cargo = _first(prev2zone, v)
        records_missing.append(_cargo_record(cargo, floating=_is_floating(cargo)))

    records_discharged = []
    for v in discharged:
        cargo = _first(recentlydelivered_inzone, v)
        record = _cargo_record(cargo, floating=_is_floating(cargo))
        record["changes"] = [
            f"discharged in {record['to_country']} on "
            f"{_fmt_dt(cargo['DestinationDate'])}"
        ]
        records_discharged.append(record)

    records_updated = []
    for v in common:
        curr_cargo = _first(curr2zone, v)
        prev_cargo = _first(prev2zone, v)
        record = _diff_record(curr_cargo, prev_cargo,
                              floating=_is_floating(curr_cargo))
        if record["changes"]:
            records_updated.append(record)

    def _vol(df: pd.DataFrame, vessels: list[str]) -> float:
        return float(df.loc[df["Vessel"].isin(vessels), "Volume(mcm)"].sum())

    summary = {
        "cargo_curr": int(len(curr2zone)),
        "cargo_prev": int(len(prev2zone)),
        "cargo_change": int(len(curr2zone) - len(prev2zone)),
        "volume_curr": float(curr2zone["Volume(mcm)"].sum()),
        "volume_prev": float(prev2zone["Volume(mcm)"].sum()),
        "volume_change": float(curr2zone["Volume(mcm)"].sum()
                               - prev2zone["Volume(mcm)"].sum()),
        "n_loaded": len(records_loaded),
        "volume_loaded": _vol(curr2zone, loaded),
        "n_relocated_in": len(records_relocated_in),
        "volume_relocated_in": _vol(curr2zone, relocated_in),
        "n_relocated_out": len(records_relocated_out),
        "volume_relocated_out": _vol(clean_curr, relocated_out),
        "n_missing": len(records_missing),
        "volume_missing": _vol(prev2zone, missing),
        "n_discharged": len(records_discharged),
        "volume_discharged": _vol(recentlydelivered_inzone, discharged),
        "n_updated": len(records_updated),
        "volume_updated": _vol(
            curr2zone, [r["vessel"] for r in records_updated]),
        "n_diversions_in": sum(
            r["diversion"] == "in" for r in records_relocated_in),
        "n_diversions_out": sum(
            r["diversion"] == "out" for r in records_relocated_out),
    }

    # Europe tagged but no destination country (global, not zone-filtered)
    eu_nc_curr = clean_curr[(clean_curr["ToContinent"] == "Europe")
                            & _blank(clean_curr["ToCountry"])]
    eu_nc_prev = clean_prev[(clean_prev["ToContinent"] == "Europe")
                            & _blank(clean_prev["ToCountry"])]

    return {
        "summary": summary,
        "loaded": records_loaded,
        "relocated_in": records_relocated_in,
        "relocated_out": records_relocated_out,
        "missing": records_missing,
        "discharged": records_discharged,
        "updated": records_updated,
        "volume_by_source": _volume_by_source(curr2zone, prev2zone),
        "volume_europe_no_country": _volume_by_source(eu_nc_curr, eu_nc_prev),
        "origin_breakdown": _origin_breakdown(curr2zone, prev2zone),
    }
