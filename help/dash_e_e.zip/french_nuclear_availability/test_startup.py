"""
Quick test to see if the dashboard can start without errors.
This simulates what run_all_local.py does.
"""

import sys
import os

# Set the port
os.environ['DASH_PORT'] = '9007'

print("=" * 70)
print("TESTING DASHBOARD STARTUP")
print("=" * 70)

try:
    print("\n1. Testing imports...")
    from availability_model_class import AvailabilityModel
    print("   ✓ AvailabilityModel imported")
    
    from data_utils.data_loader import EDFDataLoader
    print("   ✓ EDFDataLoader imported")
    
    print("\n2. Testing data loader initialization...")
    loader = EDFDataLoader()
    print("   ✓ EDFDataLoader initialized")
    
    print("\n3. Checking S3 availability...")
    print(f"   S3 available: {loader.s3_available}")
    
    print("\n4. Checking cache status...")
    cache_info = loader.get_cache_info()
    for key, value in cache_info.items():
        print(f"   {key}: {value}")
    
    print("\n5. Testing data path retrieval...")
    data_path = loader.get_data_path(force_refresh=False)
    print(f"   ✓ Data path: {data_path}")
    
    print("\n6. Testing AvailabilityModel initialization...")
    model = AvailabilityModel(data_path)
    print(f"   ✓ Model initialized")
    
    print("\n" + "=" * 70)
    print("✓ ALL STARTUP CHECKS PASSED")
    print("=" * 70)
    print("\nThe dashboard should be able to start successfully.")
    print("If run_all_local.py still fails, check:")
    print("  1. Port 9007 is not already in use")
    print("  2. Python environment is correct")
    print("  3. All dependencies are installed")
    
except Exception as e:
    print("\n" + "=" * 70)
    print("✗ STARTUP CHECK FAILED")
    print("=" * 70)
    print(f"\nError: {e}")
    import traceback
    print("\nFull traceback:")
    traceback.print_exc()
    print("\n" + "=" * 70)
    sys.exit(1)
