RULES = [

    # ========= 1) OUTAGE DURATION / SCHEDULE UNCERTAINTY =========

    ("OUTAGE_MAY_BE_EXTENDED",
     # If the message is explicitly about a strike / social movement, let the STRIKE rule classify it.
     # We keep rule order unchanged by preventing this pattern from matching those messages.
     r"(?is)^(?!.*\bgr[èe]ve\b|.*\bstrike\b|.*mouvement social).*?(?:arr[êe]t\s+susceptible\s+d['’]?(?:[êe]tre|[eé])\s+prolong[eé]|"
     r"(?:cet\s+)?arr[êe]t\s+est\s+susceptible\s+de\s+se\s+prolonger|"
     r"arr[êe]t\s+susceptible\s+de\s+se\s+prolonger|"
     r"limitation\s+à\s+\d+\s*MW\s+susceptible\s+de\s+se\s+prolonger|"
     r"susceptible d['’]être prolong|likely to be extended|likely to continue|"
     r"stop likely to be (?:extended|prolonged|continued)|"
     r"outage duration may be (?:extended|prolonged|modified)|"
     r"duration .* susceptible .* prolong|"
     r"duration .* may (?:extend|increase)|"
     r"may last \d+\s*more days|"
     r"retour.*susceptible d['’]être modifi|"
     r"date.*susceptible d['’]être modifi|"
     r"the (?:stop|shutdown|outage) could be postponed|"
     r"return is likely to be postponed|"
     r"prudence est à prendre sur cette date|"
     r"susceptible d['’]être reprogrammé|"
     r"re-scheduled and extended|"
    
     r"END .* likely to extend outage|"
     r"la durée indiquée .* susceptible d['’]évoluer|"
     r"subject to change depending on .* analysis|"
     r"expertises réalisées durant l'arrêt.*susceptible|"
     r"a technical issue .* may lead .* increase the duration|"
     r"results of diagnostics.*may affect the duration|"
     r"outage is likely to (?:continue|be prolonged))"),

    # ========= 2) CORROSION (CSC/SCC) =========
    ("CORROSION_RISK_CSC",
     r"corrosion sous contrainte|"
     r"\bCSC\b|\bSCC\b|"
     r"stress corrosion cracking|"
     r"indépendamment .* \bCSC\b .* susceptible d['’]?(?:être|etre) prolong"
     ),

    # ========= 3) TECHNICAL INVESTIGATION =========
    ("TECHNICAL_INVESTIGATION",
     r"analyses? techniques? en cours|"
     r"résultats? de diagnostics?|"
     r"contr[oô]les? en cours|"
     r"investigations? techniques?|"
     r"pending technical test schedules?|"
     r"examens? non destructifs|"
     r"dossier de conformité|"
     r"instruction technique|"
     r"technical investigation|"
     r"END .* (extend|impact)|"
     r"mise en service .* procédés|"
     r"commissioning .* technical process"),

    # ========= 4) MAINTENANCE COMPLEXITY =========
    ("MAINTENANCE_COMPLEXITY",
     r"travaux complexes|"
     r"programme maintenance chargé|"
     r"busy maintenance plan|"
     r" includes new activities|"
     r"retard lié aux ressources|"
     r"dépend du programme de maintenance|"
     r"activités nouvelles.*VD\d|"
     r"programme.*intégrant des activités nouvelles"),

    # ========= 4b) TESTS / ESSAIS =========
    ("TEST_RUN",
     r"\bessai(?:s)?\b|"
     r"\btest(?:s)?\b|"
     r"\btest\s*runs?\b|"
     r"\brequalification\b|"
     r"\bqualification tests?\b|"
     r"\bongoing check tests?\b|"
     r"\btests?\s+(?:planned|programmed)\b|"
     r"\btest\s+at\s+stable\s+power\b|"
     r"\btests?\s+with\s+load\s+variations\b|"
     r"\bISB\b"),

    # ========= 5) RAMP PROFILES (COMPLEX / UP / DOWN) =========

    # EDF boilerplate "default" restart message (generic ramp-up, not a live ramp schedule)
    ("DEFAULT",
     r"(?is)^(?!.*\b\d+\s*MW\b)(?!.*premier palier)(?!.*next step)(?!.*next load threshold)(?!.*threshold at).*?"
     r"(?:after its restart, the plant will gradually return by various load thresholds to full power|"
     r"apr[èe]s son recouplage, la tranche remontera progressivement par palier de charge à sa pleine puissance).*?"
     r"(?:the ramp-?up period will take at least \d+\s*hours?|la remont[ée]e durera au moins \d+\s*h)"),

    ("RAMP_UP",
     r"remont[ée]e? par paliers?|"
     r"remont[ée]e? par palier|"
     r"parliers?\s+en cours|"
     r"unit .* ramping up by steps|"
     r"unit is currently ramping up|"
     r"next step|next load threshold|"
     r"premier palier|"
     r"au palier\s+\d+\s*MW|"
     r"montée à \d+ MW|"
     r"mont[ée]e progressive à \d+\s*MW|"
     r"remontée à puissance maximale|"
     r"ramp-?up to .* MW|"
     r"après son recouplage.*remontera progressivement|"
     r"the ramp-?up period.*(take|may take)|"
     r"la remontée (?:durera|peut prendre)|"
     r"la mont[ée]e de charge.*(prendra|peut prendre)|"
     r"remontée lente|"
     r"planning de remontée en cours de recalage"),

    ("RAMP_DOWN",
     r"baisse avant arrêt|ramping down before outage|"
     r"baisse par paliers|unit ramping down|"
     r"threshold at .* MW.*baisse|"
     r"ramp down to .* MW|"
     r"la baisse.*(prendra|peut prendre)|"
     r"ramp-down period"),

    ("RAMP_PROFILE_COMPLEX",
     r"prochain palier|next step|next load threshold|"
     r"palier à \d+|threshold at \d+|"
     r"durée minimale de palier|"
     r"duration is the shortest for the load step|"
     r"les durées indiquées peuvent varier|"
     r"currently ramping|"
     r"montée à .* \d+ MW|"
     r"temps restant au palier|"
     r"arrival time .* PMD uncertain|"
     r"palier .* : \d+h"),

    ("FUEL_STOCK_CONSTRAINT",
     r"stock de combustible|fuel stock constraint|"
     r"constrained by its fuel stock"),

    ("FUEL_SAVING_OUTAGE",
     r"économie combustible|fuel saving outage|"
     r"arrêt pour économie combustible"),

    ("ECONOMIC_MODULATION",
     r"conditions économiques|market conditions|"
     r"may be anticipated.*market|"
     r"horaire.*anticipé|"
     r"reassessed .* economic conditions"),

    ("MODULATION_ECONOMIC",
     r"arrêt pour modulation|baisse pour modulation|"
     r"unavailability for modulation|"
     r"modulation supply"),


    # ========= 6) ECONOMIC / MARKET / OPERATIONAL =========

    ("FORCED_UNAVAILABILITY",
     r"indisponibilit[eé] fortuite|forced unavailability|"
     r"forced unavaill?ability|"
     r"forced unavaibility|"
     r"\bpanne\b|\bfailure\b|"
     r"fortuit.*défaut réseau"),

    ("PLANNED_MAINTENANCE",
     r"arrêt planifié|planned maintenance|scheduled outage|"
     r"maintenance stop|arrêt prévu"),

    ("OUTAGE_CONDITIONAL_ON_OTHER_UNIT",
     r"sera possible only when|"
     r"conditionné .* retour sur le réseau"),

    ("TSO_DEPENDENT_OPERATION",
     r"sous réserve d'accord du gestionnaire de réseau|"
     r"subject to TSO agreement|"
     r"maintenue couplée .* gestionnaire de réseau|"
     r"imposée .* par le gestionnaire de réseau|"
     r"subject to RTE approval|"
     r"tranche maintenue couplée"),

    ("GRID_CONSTRAINT",
     r"réseau amont|failure on the grid upstream|"
     r"cause réseau|"
     r"réseau transport|transmission grid|"
     r"transmission line issue|"
     r"al[ée]a ligne d['’]évacuation|"
     r"ne doit pas dépasser .* MW"),

    ("LIMITED_POWER_LEVEL",
     r"imposée à \d+ MW|imposed at \d+ MW|"
     r"impos[ée] à PMD|"
     r"forced to run at full load|"
     r"puissance limitée|"
     r"maintained at \d+ MW|"
     r"sera limitée à \d+ MW|"
     r"limitation .* MW"),


    ("STRIKE",
     r"\bgr[èe]ve\b|strike|mouvement social|"
     r"fin du mouvement social|"
     r"jusqu['’]à la fin du mouvement social|"
     r"mouvement social annonc[ée]|"
     r"production .* susceptible .* prolonger .* grève|"
     r"local strike|"
     r"likely to continue until the end of the (?:national|local)? ?strike"
     ),

    ("ENVIRONMENTAL_ISSUES",
     r"causes externes liées à l'environnement|"
     r"environmental issues?|"
     r"baisse.*contraintes environnementales|"
     r"grandes mar[ée]es|high tides?|"
     r"weather forecast"),

    ("REGULATOR_ASN_DECISION",
     r"décision ASN|ASN numéro|"
     r"arrêt suite .* ASN"),

    # ========= 7) OTHER TECHNICAL / MISC =========

    ("ON_GOING_STRETCH",
     r"prolongation de campagne|ongoing stretch"),

    ("NUCLEAR_FLEET_24H_GENERIC",
     r"durée forfaitaire de 24h|pre-defined 24 hours period"),

    # ========= FALLBACK =========

    ("OTHER", r".*"),
]
