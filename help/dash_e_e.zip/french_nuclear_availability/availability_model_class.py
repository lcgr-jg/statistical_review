"""
Class-packaged version of `availability_model.py`.

Important:
- This file intentionally keeps the logic of `calculate_availability` identical
  to the original implementation, only packaged into a class.
- `eu_power_models/availability_model.py` is NOT modified.
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta, date
from pathlib import Path
from typing import List, Optional, Dict

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import numpy as np

from french_nuclear_availability.utils import RULES

# Regex patterns for economic outage classification
_ECONOMIC_MODULATION_PATTERN = re.compile(
    r"conditions économiques|market conditions|"
    r"may be anticipated.*market|"
    r"horaire.*anticipé|"
    r"reassessed .* economic conditions",
    re.IGNORECASE
)

_MODULATION_ECONOMIC_PATTERN = re.compile(
    r"arrêt pour modulation|baisse pour modulation|"
    r"unavailability for modulation|"
    r"modulation supply",
    re.IGNORECASE
)

def _is_economic_outage(info: Optional[str]) -> bool:
    """Check if an outage message is classified as economic (modulation)."""
    if not info:
        return False
    return bool(
        _ECONOMIC_MODULATION_PATTERN.search(info) or
        _MODULATION_ECONOMIC_PATTERN.search(info)
    )


# Default cache directory (relative to this file)
_CACHE_DIR = Path(__file__).parent / "cache"
_REALIZED_CACHE_PATH = _CACHE_DIR / "realized_availability.parquet"
_FORECAST_CACHE_PATH = _CACHE_DIR / "forecast_availability.parquet"


def clear_realized_cache() -> bool:
    """Remove the cached realized availability file. Returns True if file was deleted."""
    if _REALIZED_CACHE_PATH.exists():
        _REALIZED_CACHE_PATH.unlink()
        print(f"[Cache] Deleted: {_REALIZED_CACHE_PATH}")
        return True
    print(f"[Cache] No cache file to delete")
    return False


def clear_forecast_cache() -> bool:
    """Remove the cached forecast availability file. Returns True if file was deleted."""
    if _FORECAST_CACHE_PATH.exists():
        _FORECAST_CACHE_PATH.unlink()
        print(f"[Cache] Deleted: {_FORECAST_CACHE_PATH}")
        return True
    print(f"[Cache] No cache file to delete")
    return False


def clear_all_caches() -> None:
    """Remove all cache files."""
    clear_realized_cache()
    clear_forecast_cache()



class AvailabilityModel:
    """
    Class wrapper around EDF UMM outage parsing and availability reconstruction.

    Parameters
    ----------
    edf_outages_path
        Default path to EDF export CSV (e.g. 'data/edf_outages.csv').
    """

    def __init__(self, edf_outages_path: str):
        self.edf_outages_path = edf_outages_path
        self.base_df = self._load_edf_outages(edf_outages_path)
        self.model = None
        self.scaler = None
        self._feature_names = None
        self.best_params = None

    # -----------------------------
    # Info classification utilities
    # -----------------------------
    @staticmethod
    def clean_info(text: object) -> str:
        if not isinstance(text, str):
            return ""

        t = text.lower()

        # Remove URLs
        t = re.sub(r"http\S+", " ", t)

        # Replace odd punctuation separators
        t = re.sub(r"[-_]{3,}|#{3,}", " ", t)

        # Fix common encoding issues
        t = t.replace("'", "'").replace("?", "'")

        # Canonicalise whitespace
        t = re.sub(r"\s+", " ", t).strip()

        return t

    @classmethod
    def classify_message(cls, text: object) -> str:
        """Return the first matched category for a given info string."""
        if not isinstance(text, str):
            return "OTHER"

        cleaned = cls.clean_info(text)
        for category, pattern in RULES:
            if re.search(pattern, cleaned, flags=re.IGNORECASE):
                return category

        return "OTHER"

    @classmethod
    def classify_info_column(
        cls, df: pd.DataFrame, col: str = "info", out_col: str = "category"
    ) -> pd.DataFrame:
        """
        Adds a category column to a pandas DataFrame based on pattern classification.

        Parameters
        ----------
        df
            pandas DataFrame containing an info column.
        col
            Column to classify (default: 'info').
        out_col
            Output column name (default: 'category').
        """
        df = df.copy()
        df[out_col] = df[col].apply(cls.classify_message)
        return df

    @staticmethod
    def add_time_since_last_update(
        df: pd.DataFrame,
        ident_col: str = "identifiant",
        version_col: str = "version",
        ts_col: str = "publication_ts",
        out_col: str = "time_since_last_update",
        as_days: bool = False,
    ) -> pd.DataFrame:
        """
        For each outage identifiant, compute the time delta between successive
        publication timestamps (ordered by version then publication_ts) and
        store it in `out_col`.

        Notes
        -----
        - The first row per identifiant will have a NaT delta.
        - Output type is a pandas Timedelta by default.
          If `as_days=True`, the output is a float number of days.
        - Original row order is preserved.
        """
        df = df.copy()
        df["__row_idx__"] = range(len(df))
        
        # Sort by identifiant, version, publication_ts
        df_sorted = df.sort_values(
            [ident_col, version_col, ts_col],
            na_position='first'
        )
        
        # Compute diff within each group
        df_sorted[out_col] = df_sorted.groupby(ident_col)[ts_col].diff()
        
        if as_days:
            df_sorted[out_col] = df_sorted[out_col].dt.total_seconds() / 86400
        
        # Restore original order
        df_sorted = df_sorted.sort_values("__row_idx__").drop(columns=["__row_idx__"])
        
        return df_sorted

    @staticmethod
    def add_time_to_outage_bounds(
        df: pd.DataFrame,
        publication_col: str = "publication_ts",
        start_col: str = "start",
        end_col: str = "end",
        out_start_col: str = "time_to_outage_start",
        out_end_col: str = "time_to_outage_end",
        as_days: bool = False,
    ) -> pd.DataFrame:
        """
        Add time deltas from `publication_col` to outage `start_col`/`end_col`.

        Output columns:
        - `out_start_col` = start - publication_ts
        - `out_end_col`   = end   - publication_ts

        Notes
        -----
        - Output type is a pandas Timedelta by default.
          If `as_days=True`, outputs are float number of days.
        - Null inputs remain null.
        """
        df = df.copy()
        df[out_start_col] = df[start_col] - df[publication_col]
        df[out_end_col] = df[end_col] - df[publication_col]
        
        if as_days:
            df[out_start_col] = df[out_start_col].dt.total_seconds() / 86400
            df[out_end_col] = df[out_end_col].dt.total_seconds() / 86400
        
        return df

    @staticmethod
    def _load_edf_outages(edf_outages_path: str, file_format: str = "auto") -> pd.DataFrame:
        """
        Load the raw EDF UMM outage file and normalise column names.

        Notes
        -----
        Supports two input formats:
        - "export"  : historical export with a leading comment row and FR headers
                     (e.g. `edf_outages.csv`)
        - "latest"  : latest snapshot export with ISO-8601 timestamps and different headers
                     (e.g. `edf_outages_latest.csv`)

        file_format:
        - "auto" (default): detect based on the header row
        - "export": force old format
        - "latest": force latest format
        """
        fmt = (file_format or "auto").lower().strip()
        if fmt not in {"auto", "export", "latest"}:
            raise ValueError("file_format must be one of: 'auto', 'export', 'latest'")

        # Detect format by peeking at the first non-empty line
        detected = None
        if fmt == "auto":
            try:
                with open(edf_outages_path, "r", encoding="utf-8", errors="ignore") as f:
                    for _ in range(5):
                        line = f.readline()
                        if not line:
                            break
                        if line.strip():
                            # latest starts with "Id;Status;Type;..."
                            if line.lstrip().startswith("Id;Status;Type;"):
                                detected = "latest"
                            # export has comment then "Status;Identifiant;..."
                            elif line.lstrip().startswith("Status;Identifiant;"):
                                detected = "export"
                            break
            except OSError:
                detected = None
            fmt = detected or "export"

        if fmt == "latest":
            df = pd.read_csv(
                edf_outages_path,
                sep=";",
                encoding="utf-8",
                quotechar='"',
                dtype={
                    "Maximum Power (MW)": float,
                    "Available Power (MW)": float,
                    "Numéro de version": "Int32",
                },
            )

            # Rename by explicit header names (more robust than position for this format)
            rename_map = {
                "Id": "identifiant",
                "Status": "status",
                "Numéro de version": "version",
                "Nom": "unit_name",
                "Filière": "fuel",
                "start date and time": "start",
                "end date and time": "end",
                "Type": "type",
                "Cause": "cause",
                "Information complémentaire": "info",
                "Maximum Power (MW)": "pmax_mw",
                "Available Power (MW)": "pavail_mw",
                "Publication date": "publication_ts",
            }
            missing = [k for k in rename_map.keys() if k not in df.columns]
            if missing:
                raise ValueError(
                    f"edf_outages_latest format missing expected columns: {missing}"
                )
            df = df.rename(columns=rename_map)

            # Parse ISO timestamps (often with +00:00). Convert to timezone-naive UTC.
            for col in ("start", "end", "publication_ts"):
                df[col] = pd.to_datetime(df[col], utc=True, errors='coerce').dt.tz_localize(None)

            # Coerce numeric fields where present
            df["version"] = pd.to_numeric(df["version"], errors='coerce').astype("Int32")
            df["pmax_mw"] = pd.to_numeric(df["pmax_mw"], errors='coerce')
            df["pavail_mw"] = pd.to_numeric(df["pavail_mw"], errors='coerce')

        else:
            # "export" (historical) format: leading comment row + FR headers
            import io
            
            # Peek at first few lines to detect format
            with open(edf_outages_path, "r", encoding="latin1") as f:
                first_line = f.readline()  # Comment line
                second_line = f.readline()  # Header line
                third_line = f.readline()   # First data line
            
            # Check format:
            # - Old format: entire line wrapped in quotes, ends with ", followed by commas
            # - New format (export): line starts with "Active;" or "Inactive;" (not wrapped in quotes)
            stripped_third = third_line.strip() if third_line else ""
            
            # New format: starts with "Active;" or "Inactive;" (not a quote)
            is_new_format = (
                stripped_third.startswith('Active;') or 
                stripped_third.startswith('Inactive;')
            )
            
            # Old format: starts with quote and ends with quote (after removing trailing commas)
            is_old_format = (
                stripped_third.startswith('"') and 
                stripped_third.rstrip(',').endswith('"') and
                len(stripped_third) > 2  # Not just `""`
            )
            
            # Use preprocessing only if it's clearly the old format AND not the new format
            needs_preprocessing = is_old_format and not is_new_format
            
            df = None
            if needs_preprocessing:
                # Old format: preprocess to remove outer quotes and trailing commas
                try:
                    with open(edf_outages_path, "r", encoding="latin1") as f:
                        lines = f.readlines()
                    
                    processed_lines = []
                    for i, line in enumerate(lines):
                        if i == 0:
                            continue  # Skip comment line
                        
                        line = line.rstrip('\r\n')
                        if not line.strip():
                            continue
                        
                        # Remove trailing commas
                        while line.endswith(','):
                            line = line[:-1]
                        
                        # Remove outer quotes if present
                        if line.startswith('"') and line.endswith('"'):
                            line = line[1:-1]
                        
                        # Unescape double-double-quotes to single quotes
                        line = line.replace('""', '"')
                        
                        processed_lines.append(line)
                    
                    csv_content = '\n'.join(processed_lines)
                    df = pd.read_csv(
                        io.StringIO(csv_content),
                        sep=";",
                        encoding="latin1",
                        quotechar='"',
                        decimal=',',  # Handle French decimal format
                    )
                except Exception:
                    # If preprocessing fails, try new format instead
                    needs_preprocessing = False
            
            if not needs_preprocessing or df is None:
                # New format: read directly, skipping first comment line
                try:
                    df = pd.read_csv(
                        edf_outages_path,
                        sep=";",
                        skiprows=1,  # Skip comment line
                        encoding="latin1",
                        quotechar='"',
                        decimal=',',  # Handle French decimal format
                    )
                except Exception as e1:
                    # If parsing fails, try with error handling
                    try:
                        print(f"Warning: CSV parsing failed, retrying with on_bad_lines='skip'. Original error: {str(e1)[:200]}")
                        df = pd.read_csv(
                            edf_outages_path,
                            sep=";",
                            skiprows=1,  # Skip comment line
                            encoding="latin1",
                            quotechar='"',
                            decimal=',',
                            on_bad_lines='skip',  # Skip rows with parsing errors
                        )
                        print(f"Warning: Some rows were skipped due to parsing errors. Loaded {len(df)} rows.")
                    except Exception as e2:
                        # If that also fails, try using Python's csv module for robust multiline handling
                        print(f"Warning: Pandas parsing failed even with on_bad_lines='skip'. Trying Python csv module. Error: {str(e2)[:200]}")
                        try:
                            import csv
                            
                            # Use Python's csv module which properly handles multiline quoted fields
                            rows = []
                            with open(edf_outages_path, "r", encoding="latin1") as f:
                                # Skip first line (comment)
                                f.readline()
                                
                                # Read header
                                header_reader = csv.reader(f, delimiter=';', quotechar='"')
                                header = next(header_reader)
                                
                                # Read data rows
                                for row in header_reader:
                                    # Handle decimal comma in numeric fields
                                    processed_row = []
                                    for i, val in enumerate(row):
                                        if i < len(header):
                                            col_name = header[i]
                                            # Check if this is a numeric column
                                            if 'Puissance' in col_name or 'MW' in col_name:
                                                # Replace comma with dot for decimal
                                                val = val.replace(',', '.') if val else val
                                            processed_row.append(val)
                                        else:
                                            processed_row.append(val)
                                    
                                    # Pad or truncate to match header length
                                    while len(processed_row) < len(header):
                                        processed_row.append('')
                                    rows.append(processed_row[:len(header)])
                            
                            # Convert to pandas DataFrame
                            df = pd.DataFrame(rows, columns=header)
                            print(f"Successfully loaded {len(df)} rows using Python csv module.")
                        except Exception as e3:
                            raise Exception(f"All CSV parsing methods failed. Last error: {str(e3)[:500]}")

            cols = df.columns.tolist()
            if len(cols) < 13:
                raise ValueError(
                    f"Expected at least 13 columns in EDF outages CSV, got {len(cols)}"
                )

            # Rename positionally to avoid brittle accent handling
            rename_map = {
                cols[0]: "status",  # Status
                cols[1]: "identifiant",  # Identifiant
                cols[2]: "version",  # Numéro de version
                cols[3]: "unit_name",  # Nom
                cols[4]: "fuel",  # Filière
                cols[5]: "start",  # Date de début
                cols[6]: "end",  # Date de fin
                cols[7]: "type",  # Type
                cols[8]: "cause",  # Cause
                cols[9]: "info",  # Information complémentaire
                cols[10]: "pmax_mw",  # Puissance maximale (MW)
                cols[11]: "pavail_mw",  # Puissance disponible (MW)
                cols[12]: "publication_ts",  # Date de publication
            }
            df = df.rename(columns=rename_map)

            # Parse datetimes explicitly (naive)
            for col in ("start", "end", "publication_ts"):
                df[col] = pd.to_datetime(df[col], format="%Y-%m-%d %H:%M:%S", errors='coerce')

            # Coerce numeric fields where present
            df["version"] = pd.to_numeric(df["version"], errors='coerce').astype("Int32")
            df["pmax_mw"] = pd.to_numeric(df["pmax_mw"], errors='coerce')
            df["pavail_mw"] = pd.to_numeric(df["pavail_mw"], errors='coerce')

        # Keep only nuclear planned/forced outages, consistent with downstream logic.
        df = df[df["fuel"] == "Nucléaire"].copy()
        df["type_norm"] = df["type"].str.strip()
        df = df[
            (df["fuel"] == "Nucléaire") & df["type_norm"].isin(["Planifiée", "Fortuite"])
        ]
        return df

    @staticmethod
    def _select_versions_as_of(df: pd.DataFrame, as_of: datetime) -> pd.DataFrame:
        """
        Snapshot selection for calculate_availability: for each outage
        identifiant, pick the latest version *as of* a given publication
        timestamp, then:
        - if that latest version is 'Annulée' or 'Supprimée' → drop the outage entirely
        - if it is 'Active' or 'Inactive'                    → keep it and use its data
        This is intentionally simpler than the "latest active version" selection
        because for historical as_of dates we rely on 'Inactive' rows that
        would have been 'Active' at the time but were later superseded.
        """
        df_asof = df[df["publication_ts"] <= as_of].copy()
        if len(df_asof) == 0:
            return df_asof

        # Sort by identifiant, version, publication_ts
        df_asof["_version_fill"] = df_asof["version"].fillna(-1)
        df_asof["_pub_fill"] = df_asof["publication_ts"].fillna(pd.Timestamp("1970-01-01"))
        df_sorted = df_asof.sort_values(
            ["identifiant", "_version_fill", "_pub_fill"]
        ).reset_index(drop=True)
        df_sorted["row_idx"] = range(len(df_sorted))

        # For each identifiant, keep the last row (highest version/pub time)
        idx = df_sorted.groupby("identifiant")["row_idx"].idxmax()
        latest = df_sorted.loc[idx].copy()

        # Drop outages whose latest version is Annulée or Supprimée
        latest = latest[~latest["status"].str.contains("Annul|Supprim", case=False, na=False)]

        # Drop helper columns
        latest = latest.drop(columns=["_version_fill", "_pub_fill", "row_idx"], errors='ignore')

        return latest

    def calculate_availability(
        self,
        as_of: datetime,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
        freq: str = "1h",
        edf_outages_path: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Calculate a snapshot of unit-level availability as of a given
        publication timestamp.

        For each unit:
        - Start from a flat base series equal to the inferred unit capacity.
        - Gather all nuclear planned/forced outage messages with
          publication_ts <= as_of.
        - For each outage identifiant, select the latest version as of
          that time using _select_versions_as_of (preferring 'Active',
          dropping fully cancelled outages).
        - Within each (unit, hour), combine the selected outages by
          taking the minimum pavail_mw implied by the messages; outside
          any outage, availability is equal to capacity.

        Returns
        -------
        pd.DataFrame with columns:
        - 'ts'         : hourly timestamp
        - 'unit'       : unit name
        - 'p_avail_mw' : available MW at that as_of snapshot
        - 'capacity_mw': inferred nominal capacity
        """
        if freq != "1h":
            raise ValueError("Only hourly frequency ('1h') is currently supported.")

        if edf_outages_path:
            base = self._load_edf_outages(edf_outages_path)
        else:
            base = self.base_df

        # Restrict to messages known as of the given timestamp and
        # select one version per identifiant with proper cancellation rules.
        latest = self._select_versions_as_of(base, as_of=as_of)

        if len(latest) == 0:
            raise ValueError(
                "No nuclear 'Planifiée' or 'Fortuite' outages found as of this date."
            )

        # Determine default global window if not supplied
        min_start = latest["start"].min()
        max_end = latest["end"].max()
        if pd.isna(min_start) or pd.isna(max_end):
            raise ValueError("Cannot infer overall time window from outage data.")

        if start is None:
            start = min_start.to_pydatetime() if hasattr(min_start, "to_pydatetime") else min_start
        if end is None:
            end = max_end.to_pydatetime() if hasattr(max_end, "to_pydatetime") else max_end

        if isinstance(start, date) and not isinstance(start, datetime):
            start = datetime.combine(start, datetime.min.time())
        if isinstance(end, date) and not isinstance(end, datetime):
            end = datetime.combine(end, datetime.min.time())

        # Align start/end to whole hours so the grid and outage hours match.
        start = start.replace(minute=0, second=0, microsecond=0)
        end = end.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)

        hourly_delta = timedelta(hours=1)

        # Infer a nominal capacity per unit from the maximum of pmax/pavail
        latest["capacity_candidate"] = latest[["pmax_mw", "pavail_mw"]].bfill(axis=1).iloc[:, 0]
        capacity_df = latest.groupby("unit_name").agg(
            capacity_mw=("capacity_candidate", "max")
        ).reset_index().rename(columns={"unit_name": "unit"})

        # Expand outages to hourly resolution (as-of filtered versions only).
        outage_records: List[Dict[str, object]] = []
        for _, row in latest.iterrows():
            unit = row["unit_name"]
            msg_start: Optional[datetime] = row["start"]
            msg_end: Optional[datetime] = row["end"]
            pavail: Optional[float] = row.get("pavail_mw")

            if pd.isna(msg_start) or pd.isna(msg_end):
                continue

            # Convert to datetime if needed
            if hasattr(msg_start, 'to_pydatetime'):
                msg_start = msg_start.to_pydatetime()
            if hasattr(msg_end, 'to_pydatetime'):
                msg_end = msg_end.to_pydatetime()

            # Skip messages entirely outside the requested window
            if msg_end <= start or msg_start >= end:
                continue

            # Effective window for this message
            window_start = max(start, msg_start)
            window_end = min(end, msg_end)
            if window_start >= window_end:
                continue

            # If pavail_mw is missing, treat as full outage for that window.
            pavail_eff = float(pavail) if pd.notna(pavail) else 0.0

            # Align window_start DOWN to the hour so timestamps match the grid.
            # E.g., if outage starts at 19:04, we mark the 19:00 hour as affected.
            window_start_aligned = window_start.replace(minute=0, second=0, microsecond=0)

            ts = window_start_aligned
            while ts < window_end:
                outage_records.append(
                    {
                        "unit": unit,
                        "ts": ts,
                        "pavail_mw": pavail_eff,
                    }
                )
                ts += hourly_delta

        if outage_records:
            outage_hours = pd.DataFrame(outage_records)
            outage_hours = outage_hours.groupby(["unit", "ts"]).agg(
                pavail_mw=("pavail_mw", "min")
            ).reset_index()
        else:
            outage_hours = pd.DataFrame({
                "unit": pd.Series([], dtype=str),
                "ts": pd.Series([], dtype="datetime64[ns]"),
                "pavail_mw": pd.Series([], dtype=float),
            })

        # Build the full unit-hour grid over the requested window
        n_hours = int((end - start).total_seconds() // 3600)
        if n_hours <= 0:
            raise ValueError("Empty time window after applying start/end bounds.")

        ts_list = [start + i * hourly_delta for i in range(n_hours)]
        grid = pd.DataFrame({"ts": ts_list})

        # Cross join: units x timestamps
        units = capacity_df[["unit", "capacity_mw"]]
        full_grid = units.merge(grid, how="cross")

        # Join in outage information, then compute p_avail as:
        # - pavail_mw during outages (minimum across overlapping messages)
        # - capacity_mw otherwise
        result = full_grid.merge(outage_hours, on=["unit", "ts"], how="left")
        result["p_avail_mw"] = result["pavail_mw"].where(
            result["pavail_mw"].notna(),
            result["capacity_mw"]
        )
        result = result[["ts", "unit", "p_avail_mw", "capacity_mw"]].sort_values(
            ["unit", "ts"]
        ).reset_index(drop=True)

        fessenheim1_shutdown = datetime(2020, 2, 22, 2, 0)
        fessenheim2_shutdown = datetime(2020, 6, 27, 20, 0)

        result.loc[
            (result["unit"] == "FESSENHEIM 1") & (result["ts"] >= fessenheim1_shutdown),
            "p_avail_mw"
        ] = 0.0
        result.loc[
            (result["unit"] == "FESSENHEIM 2") & (result["ts"] >= fessenheim2_shutdown),
            "p_avail_mw"
        ] = 0.0

        return result

    def calculate_economic_unavailability(
        self,
        as_of: datetime,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
        freq: str = "1h",
    ) -> pd.DataFrame:
        """
        Calculate the economic unavailability (reduction from capacity) per unit
        due to economic/modulation outages only.

        This filters outages to only those classified as ECONOMIC_MODULATION or
        MODULATION_ECONOMIC based on the 'info' field content.

        Parameters
        ----------
        as_of : datetime
            The publication timestamp to use for version selection.
        start, end : Optional[datetime]
            Optional time window. If omitted, inferred from outage bounds.
        freq : str
            Currently only '1h' is supported.

        Returns
        -------
        pd.DataFrame with columns:
        - 'ts'                    : hourly timestamp
        - 'unit'                  : unit name
        - 'economic_reduction_mw' : MW reduction due to economic outages (capacity - p_avail)
        - 'capacity_mw'           : inferred nominal capacity
        """
        if freq != "1h":
            raise ValueError("Only hourly frequency ('1h') is currently supported.")

        # Restrict to messages known as of the given timestamp
        latest = self._select_versions_as_of(self.base_df, as_of=as_of)

        if len(latest) == 0:
            raise ValueError("No nuclear 'Planifiée' or 'Fortuite' outages found as of this date.")

        # Filter to only economic outages based on the 'info' field
        economic_outages = latest[latest["info"].apply(_is_economic_outage)].copy()

        # Determine default global window if not supplied (from all outages, not just economic)
        min_start = latest["start"].min()
        max_end = latest["end"].max()
        if pd.isna(min_start) or pd.isna(max_end):
            raise ValueError("Cannot infer overall time window from outage data.")

        if start is None:
            start = min_start.to_pydatetime() if hasattr(min_start, "to_pydatetime") else min_start
        if end is None:
            end = max_end.to_pydatetime() if hasattr(max_end, "to_pydatetime") else max_end

        if isinstance(start, date) and not isinstance(start, datetime):
            start = datetime.combine(start, datetime.min.time())
        if isinstance(end, date) and not isinstance(end, datetime):
            end = datetime.combine(end, datetime.min.time())

        # Align start/end to whole hours
        start = start.replace(minute=0, second=0, microsecond=0)
        end = end.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)

        hourly_delta = timedelta(hours=1)

        # Infer a nominal capacity per unit from the full outage set (not just economic)
        latest["capacity_candidate"] = latest[["pmax_mw", "pavail_mw"]].bfill(axis=1).iloc[:, 0]
        capacity_df = latest.groupby("unit_name").agg(
            capacity_mw=("capacity_candidate", "max")
        ).reset_index().rename(columns={"unit_name": "unit"})

        # Expand economic outages to hourly resolution
        outage_records: List[Dict[str, object]] = []
        for _, row in economic_outages.iterrows():
            unit = row["unit_name"]
            msg_start: Optional[datetime] = row["start"]
            msg_end: Optional[datetime] = row["end"]
            pavail: Optional[float] = row.get("pavail_mw")

            if pd.isna(msg_start) or pd.isna(msg_end):
                continue

            # Convert to datetime if needed
            if hasattr(msg_start, 'to_pydatetime'):
                msg_start = msg_start.to_pydatetime()
            if hasattr(msg_end, 'to_pydatetime'):
                msg_end = msg_end.to_pydatetime()

            # Skip messages entirely outside the requested window
            if msg_end <= start or msg_start >= end:
                continue

            # Effective window for this message
            window_start = max(start, msg_start)
            window_end = min(end, msg_end)
            if window_start >= window_end:
                continue

            # If pavail_mw is missing, treat as full outage
            pavail_eff = float(pavail) if pd.notna(pavail) else 0.0

            # Align window_start DOWN to the hour
            window_start_aligned = window_start.replace(minute=0, second=0, microsecond=0)

            ts = window_start_aligned
            while ts < window_end:
                outage_records.append(
                    {
                        "unit": unit,
                        "ts": ts,
                        "pavail_mw": pavail_eff,
                    }
                )
                ts += hourly_delta

        if outage_records:
            outage_hours = pd.DataFrame(outage_records)
            outage_hours = outage_hours.groupby(["unit", "ts"]).agg(
                pavail_mw=("pavail_mw", "min")
            ).reset_index()
        else:
            outage_hours = pd.DataFrame({
                "unit": pd.Series([], dtype=str),
                "ts": pd.Series([], dtype="datetime64[ns]"),
                "pavail_mw": pd.Series([], dtype=float),
            })

        # Build the full unit-hour grid over the requested window
        n_hours = int((end - start).total_seconds() // 3600)
        if n_hours <= 0:
            raise ValueError("Empty time window after applying start/end bounds.")

        ts_list = [start + i * hourly_delta for i in range(n_hours)]
        grid = pd.DataFrame({"ts": ts_list})

        units = capacity_df[["unit", "capacity_mw"]]
        full_grid = units.merge(grid, how="cross")

        # Join in economic outage information, then compute reduction as:
        # - (capacity_mw - pavail_mw) during economic outages
        # - 0.0 otherwise (no economic reduction)
        result = full_grid.merge(outage_hours, on=["unit", "ts"], how="left")
        result["economic_reduction_mw"] = (
            result["capacity_mw"] - result["pavail_mw"]
        ).where(result["pavail_mw"].notna(), 0.0)
        result = result[["ts", "unit", "economic_reduction_mw", "capacity_mw"]].sort_values(
            ["unit", "ts"]
        ).reset_index(drop=True)

        # Handle Fessenheim shutdown - no economic reduction after shutdown
        fessenheim1_shutdown = datetime(2020, 2, 22, 2, 0)
        fessenheim2_shutdown = datetime(2020, 6, 27, 20, 0)

        result.loc[
            (result["unit"] == "FESSENHEIM 1") & (result["ts"] >= fessenheim1_shutdown),
            "economic_reduction_mw"
        ] = 0.0
        result.loc[
            (result["unit"] == "FESSENHEIM 2") & (result["ts"] >= fessenheim2_shutdown),
            "economic_reduction_mw"
        ] = 0.0

        return result

    def _get_realized_availability_cached(
        self,
        start: datetime,
        end: datetime,
        cache_path: Optional[Path] = None,
    ) -> Dict[datetime, float]:
        """
        Get realized availability with disk caching.
        
        - If cache exists and covers [start, end], load from cache.
        - If cache exists but doesn't fully cover, extend it with missing ranges.
        - If no cache, compute from scratch and save.
        
        Returns a dict mapping hourly timestamps to total fleet availability (MW).
        """
        cache_path = cache_path or _REALIZED_CACHE_PATH
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        
        today = datetime.now().replace(minute=0, second=0, microsecond=0)
        # Realized availability can only be known up to today
        end = min(end, today)
        
        cached_df: Optional[pd.DataFrame] = None
        cached_min: Optional[datetime] = None
        cached_max: Optional[datetime] = None
        
        # Try to load existing cache
        if cache_path.exists():
            try:
                cached_df = pd.read_parquet(cache_path)
                if "ts" in cached_df.columns and len(cached_df) > 0:
                    cached_min = cached_df["ts"].min()
                    cached_max = cached_df["ts"].max()
                    # Convert to Python datetime if needed
                    if hasattr(cached_min, "to_pydatetime"):
                        cached_min = cached_min.to_pydatetime()
                    if hasattr(cached_max, "to_pydatetime"):
                        cached_max = cached_max.to_pydatetime()
                    print(f"  [Cache] Loaded existing cache: {cached_min.date()} to {cached_max.date()}")
            except Exception as e:
                print(f"  [Cache] Could not load cache ({e}), will recompute")
                cached_df = None
        
        # Determine what ranges need to be computed
        ranges_to_compute: List[tuple] = []
        
        if cached_df is None or cached_min is None or cached_max is None:
            # No usable cache, compute full range
            ranges_to_compute.append((start, end))
        else:
            # Check if we need to extend backwards
            if start < cached_min:
                ranges_to_compute.append((start, cached_min - timedelta(hours=1)))
            # Check if we need to extend forwards
            if end > cached_max:
                ranges_to_compute.append((cached_max + timedelta(hours=1), end))
        
        # Compute any missing ranges
        new_dfs: List[pd.DataFrame] = []
        for range_start, range_end in ranges_to_compute:
            if range_start >= range_end:
                continue
            print(f"  [Cache] Computing realized availability: {range_start.date()} to {range_end.date()}...")
            new_avail = self.calculate_availability(
                as_of=today,
                start=range_start,
                end=range_end,
            )
            # Aggregate to total availability per hour
            new_agg = new_avail.groupby("ts").agg(
                total_avail=("p_avail_mw", "sum")
            ).reset_index()
            new_dfs.append(new_agg)
        
        # Merge with existing cache
        if cached_df is not None and len(cached_df) > 0:
            # Aggregate cached_df if it has unit-level data
            if "unit" in cached_df.columns:
                cached_agg = cached_df.groupby("ts").agg(
                    total_avail=("p_avail_mw", "sum")
                ).reset_index()
            elif "total_avail" in cached_df.columns:
                cached_agg = cached_df[["ts", "total_avail"]]
            else:
                cached_agg = None
            
            if cached_agg is not None:
                new_dfs.append(cached_agg)
        
        # Combine all data
        if new_dfs:
            combined = pd.concat(new_dfs, ignore_index=True)
            # Dedupe by ts (keep last in case of overlaps)
            combined = combined.drop_duplicates(subset=["ts"], keep="last").sort_values("ts").reset_index(drop=True)
        else:
            combined = pd.DataFrame({"ts": [], "total_avail": []})
        
        # Save updated cache
        if len(combined) > 0:
            combined.to_parquet(cache_path, index=False)
            new_min = combined["ts"].min()
            new_max = combined["ts"].max()
            if hasattr(new_min, "to_pydatetime"):
                new_min = new_min.to_pydatetime()
            if hasattr(new_max, "to_pydatetime"):
                new_max = new_max.to_pydatetime()
            print(f"  [Cache] Saved cache: {new_min.date()} to {new_max.date()} ({len(combined):,} hours)")
        
        # Convert to dict for fast lookup
        result = {row["ts"]: row["total_avail"] for _, row in combined.iterrows()}
        return result

    def _get_forecast_availability_cached(
        self,
        as_of_dates: List[datetime],
        max_horizon: int,
        cache_path: Optional[Path] = None,
    ) -> pd.DataFrame:
        """
        Get forecast availability for multiple as_of dates with disk caching.
        
        Returns a DataFrame with columns: [as_of_date, target_ts, forecast_total]
        
        On first run, computes forecasts for all requested dates.
        On subsequent runs, loads from cache and only computes missing as_of_dates.
        """
        cache_path = cache_path or _FORECAST_CACHE_PATH
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        
        as_of_set = set(as_of_dates)
        cached_df: Optional[pd.DataFrame] = None
        cached_as_of_dates: set = set()
        
        # Try to load existing cache
        if cache_path.exists():
            try:
                cached_df = pd.read_parquet(cache_path)
                if "as_of_date" in cached_df.columns and len(cached_df) > 0:
                    cached_as_of_dates = set(cached_df["as_of_date"].unique())
                    print(f"  [Forecast Cache] Loaded {len(cached_as_of_dates):,} cached as_of dates")
            except Exception as e:
                print(f"  [Forecast Cache] Could not load cache ({e}), will recompute")
                cached_df = None
        
        # Determine which as_of_dates need to be computed
        missing_dates = sorted(as_of_set - cached_as_of_dates)
        
        if not missing_dates:
            print(f"  [Forecast Cache] All {len(as_of_dates):,} dates found in cache")
            # Filter to requested dates and return
            return cached_df[cached_df["as_of_date"].isin(list(as_of_set))]
        
        print(f"  [Forecast Cache] Computing forecasts for {len(missing_dates):,} new dates...")
        
        # Compute missing dates
        new_records: List[Dict] = []
        
        for idx, as_of in enumerate(missing_dates):
            if idx % 100 == 0:
                print(f"    Progress: {idx:,}/{len(missing_dates):,} dates")
            
            try:
                forecast_avail = self.calculate_availability(
                    as_of=as_of,
                    start=as_of,
                    end=as_of + timedelta(days=max_horizon + 1),
                )
                
                # Aggregate to total per hour
                forecast_agg = forecast_avail.groupby("ts").agg(
                    forecast_total=("p_avail_mw", "sum")
                ).reset_index()
                
                for _, row in forecast_agg.iterrows():
                    new_records.append({
                        "as_of_date": as_of,
                        "target_ts": row["ts"],
                        "forecast_total": row["forecast_total"],
                    })
            except Exception:
                # Skip dates that fail (e.g., no data available)
                continue
        
        print(f"    Progress: {len(missing_dates):,}/{len(missing_dates):,} dates")
        
        # Build DataFrame from new records
        if new_records:
            new_df = pd.DataFrame(new_records)
        else:
            new_df = pd.DataFrame({
                "as_of_date": pd.Series([], dtype="datetime64[ns]"),
                "target_ts": pd.Series([], dtype="datetime64[ns]"),
                "forecast_total": pd.Series([], dtype=float),
            })
        
        # Merge with existing cache
        if cached_df is not None and len(cached_df) > 0:
            combined = pd.concat([cached_df, new_df], ignore_index=True)
        else:
            combined = new_df
        
        # Save updated cache
        if len(combined) > 0:
            combined.to_parquet(cache_path, index=False)
            n_as_of = combined["as_of_date"].nunique()
            print(f"  [Forecast Cache] Saved cache: {n_as_of:,} as_of dates, {len(combined):,} rows")
        
        # Filter to requested dates and return
        return combined[combined["as_of_date"].isin(list(as_of_set))]

    @staticmethod
    def _extract_path_features(avail_series) -> Optional[Dict[str, float]]:
        """
        Extract features from availability path (daily values from as_of to target).
        
        Args:
            avail_series: numpy array of daily availability values from as_of to target
            
        Returns:
            Dict of path features, or None if series too short
        """
        if len(avail_series) < 2:
            return None
        
        path_mean = np.mean(avail_series)
        mid_idx = len(avail_series) // 2
        
        return {
            # Central tendency
            'path_mean': path_mean,
            'path_min': np.min(avail_series),
            'path_max': np.max(avail_series),
            
            # Volatility
            'path_std': np.std(avail_series),
            'path_range': np.max(avail_series) - np.min(avail_series),
            
            # Gradient/Trend
            'path_slope': (avail_series[-1] - avail_series[0]) / len(avail_series),
            'path_max_daily_jump': np.max(np.abs(np.diff(avail_series))),
            
            # Shape
            'path_end_vs_mean': avail_series[-1] - path_mean,  # Target above/below path avg?
            'path_curvature': avail_series[-1] - 2 * avail_series[mid_idx] + avail_series[0],  # Concave/convex
        }

    def forecast(
        self,
        as_of: datetime | date | str,
        start_date: datetime | date | str,
        end_date: datetime | date | str,
        plot: bool = True,
        save_plot: bool = False,
    ) -> pd.DataFrame:
        """
        Generate a forecast of realized French nuclear availability.
        
        Uses the trained ML model to predict what the realized availability 
        will be for each day between start_date and end_date, based on the
        EDF UMM outage information available as of the as_of date.
        
        Args:
            as_of: Date as of which to make the forecast (what information we have)
            start_date: First day of the forecast period
            end_date: Last day of the forecast period
            plot: Whether to display a plot of the forecast
            save_plot: Whether to save the plot to a file
            
        Returns:
            pd.DataFrame with columns:
            - 'date': target date
            - 'edf_umm_forecast': EDF UMM forecast availability (MW)
            - 'model_prediction': ML model predicted realized availability (MW)
            - 'horizon_days': days from as_of to target date
        """
        import warnings
        warnings.filterwarnings('ignore', message='.*X does not have valid feature names.*')
        
        if self.model is None:
            raise ValueError("Model not trained. Call train_model() first or load a saved model.")
        
        # Parse dates
        if isinstance(as_of, str):
            as_of = datetime.strptime(as_of, "%Y-%m-%d")
        elif isinstance(as_of, date) and not isinstance(as_of, datetime):
            as_of = datetime.combine(as_of, datetime.min.time())
            
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, "%Y-%m-%d")
        elif isinstance(start_date, date) and not isinstance(start_date, datetime):
            start_date = datetime.combine(start_date, datetime.min.time())
            
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, "%Y-%m-%d")
        elif isinstance(end_date, date) and not isinstance(end_date, datetime):
            end_date = datetime.combine(end_date, datetime.min.time())
        
        print(f"\n{'='*70}")
        print("Generating Availability Forecast")
        print(f"{'='*70}")
        print(f"As-of date: {as_of.date()}")
        print(f"Forecast period: {start_date.date()} to {end_date.date()}")
        
        # Generate target dates
        target_dates = []
        current = start_date
        while current <= end_date:
            target_dates.append(current)
            current += timedelta(days=1)
        
        max_horizon = (end_date - as_of).days + 1
        print(f"Horizon range: 1 to {max_horizon} days")
        
        # Lookback periods for historical forecast features
        lookback_days = [7, 30, 90]
        
        # Prepare as_of dates for lookback
        all_as_of_dates = [as_of]
        for lb in lookback_days:
            all_as_of_dates.append(as_of - timedelta(days=lb))
        all_as_of_dates = sorted(set(all_as_of_dates))
        
        # Get realized availability as of now (for the as_of date itself)
        print("Loading realized availability (as of today)...")
        realized_dict = self._get_realized_availability_cached(
            start=as_of - timedelta(days=max(lookback_days)),
            end=datetime.now(),
        )
        realized_on_as_of = realized_dict.get(as_of)
        if realized_on_as_of is None:
            # Use a recent date if as_of is in the future
            for i in range(1, 10):
                realized_on_as_of = realized_dict.get(as_of - timedelta(days=i))
                if realized_on_as_of is not None:
                    break
        if realized_on_as_of is None:
            realized_on_as_of = 50000  # Fallback to approximate avg
            print(f"  Warning: No realized data for {as_of.date()}, using fallback")
        
        # Get forecast snapshots for all lookback dates
        print("Loading forecast snapshots...")
        forecast_df = self._get_forecast_availability_cached(
            as_of_dates=all_as_of_dates,
            max_horizon=max_horizon + max(lookback_days),
        )
        
        # Build forecast lookup dict
        forecast_lookup: Dict[tuple, float] = {}
        for _, row in forecast_df.iterrows():
            key = (row["as_of_date"], row["target_ts"])
            forecast_lookup[key] = row["forecast_total"]
        
        # Build daily path lookup for path features
        path_lookup: Dict = {}
        for _, row in forecast_df.iterrows():
            if row["as_of_date"] == as_of:
                target = row["target_ts"]
                target_date = target.date() if hasattr(target, 'date') else target
                if target_date not in path_lookup:
                    path_lookup[target_date] = []
                path_lookup[target_date].append(row["forecast_total"])
        # Average multiple hours into daily values
        for dt in path_lookup:
            vals = path_lookup[dt]
            path_lookup[dt] = np.mean(vals) if isinstance(vals, list) else vals
        
        # Generate predictions for each target date
        print("Generating predictions...")
        results = []
        
        for target_date in target_dates:
            horizon_days = (target_date - as_of).days
            if horizon_days < 1:
                continue
            
            # Seasonality for target date
            target_day_of_year = target_date.timetuple().tm_yday
            target_day_of_year_rad = 2 * np.pi * target_day_of_year / 365.25
            target_sin_doy = np.sin(target_day_of_year_rad)
            target_cos_doy = np.cos(target_day_of_year_rad)
            
            # Get EDF UMM forecast
            forecast_val = forecast_lookup.get((as_of, target_date))
            if forecast_val is None:
                # Try matching with datetime
                forecast_val = forecast_lookup.get((as_of, target_date.date() if hasattr(target_date, 'date') else target_date))
            
            if forecast_val is None:
                continue
            
            # Get historical forecasts
            forecast_7d_ago = forecast_lookup.get((as_of - timedelta(days=7), target_date), forecast_val)
            forecast_30d_ago = forecast_lookup.get((as_of - timedelta(days=30), target_date), forecast_val)
            forecast_90d_ago = forecast_lookup.get((as_of - timedelta(days=90), target_date), forecast_val)
            
            # Compute deltas
            delta_7d = forecast_val - forecast_7d_ago
            delta_30d = forecast_val - forecast_30d_ago
            delta_90d = forecast_val - forecast_90d_ago
            
            # Build path from as_of to target
            path_values = []
            for d in range(horizon_days + 1):
                dt = (as_of + timedelta(days=d)).date()
                if dt in path_lookup:
                    path_values.append(path_lookup[dt])
            
            # Extract path features
            if len(path_values) >= 2:
                path_feats = self._extract_path_features(np.array(path_values))
            else:
                path_feats = None
            
            if path_feats is None:
                # Use fallback path features
                path_feats = {
                    'path_mean': forecast_val, 'path_min': forecast_val, 'path_max': forecast_val,
                    'path_std': 0, 'path_range': 0, 'path_slope': 0, 'path_max_daily_jump': 0,
                    'path_end_vs_mean': 0, 'path_curvature': 0
                }
            
            # Build feature vector (same order as training)
            X = np.array([[
                forecast_val, realized_on_as_of, horizon_days,
                target_sin_doy, target_cos_doy,
                forecast_7d_ago, forecast_30d_ago, forecast_90d_ago,
                delta_7d, delta_30d, delta_90d,
                path_feats['path_mean'], path_feats['path_min'], path_feats['path_max'],
                path_feats['path_std'], path_feats['path_range'],
                path_feats['path_slope'], path_feats['path_max_daily_jump'],
                path_feats['path_end_vs_mean'], path_feats['path_curvature']
            ]])
            
            # Predict
            prediction = self.model.predict(X)[0]
            
            results.append({
                'date': target_date.date() if hasattr(target_date, 'date') else target_date,
                'edf_umm_forecast': forecast_val,
                'model_prediction': prediction,
                'horizon_days': horizon_days,
            })
        
        print(f"Generated {len(results)} daily predictions")
        
        # Convert to pandas DataFrame
        result_df = pd.DataFrame(results)
        
        # Print summary statistics
        if len(results) > 0:
            print(f"\n{'='*70}")
            print("Forecast Summary")
            print(f"{'='*70}")
            print(f"EDF UMM avg: {result_df['edf_umm_forecast'].mean():,.0f} MW")
            print(f"Model prediction avg: {result_df['model_prediction'].mean():,.0f} MW")
            print(f"EDF UMM min/max: {result_df['edf_umm_forecast'].min():,.0f} / {result_df['edf_umm_forecast'].max():,.0f} MW")
            print(f"Model min/max: {result_df['model_prediction'].min():,.0f} / {result_df['model_prediction'].max():,.0f} MW")
        
        # Plot if requested
        if plot and len(results) > 0:
            result_pd = result_df.copy()
            result_pd['date'] = pd.to_datetime(result_pd['date'])
            
            fig, ax = plt.subplots(figsize=(14, 6))
            
            ax.fill_between(result_pd['date'], 0, result_pd['model_prediction'] / 1000, 
                            alpha=0.3, color='steelblue', label='Model Prediction')
            ax.plot(result_pd['date'], result_pd['model_prediction'] / 1000, 
                    color='steelblue', linewidth=1.5)
            ax.plot(result_pd['date'], result_pd['edf_umm_forecast'] / 1000, 
                    color='orange', linewidth=1.5, linestyle='--', label='EDF UMM Forecast')
            
            # Add capacity line (approx)
            capacity_gw = 61.4  # Approximate French nuclear capacity
            ax.axhline(y=capacity_gw, color='red', linestyle=':', linewidth=1, alpha=0.7, label='Capacity (~61.4 GW)')
            
            ax.set_xlabel("Date", fontweight='bold')
            ax.set_ylabel("Availability (GW)", fontweight='bold')
            ax.set_title(f"French Nuclear Availability Forecast\n(as of {as_of.date()})", 
                         fontweight='bold', fontsize=14)
            ax.legend(loc='upper right')
            ax.grid(True, alpha=0.3)
            
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%d %b %Y'))
            ax.xaxis.set_major_locator(mdates.DayLocator(interval=max(1, len(target_dates) // 10)))
            plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
            
            ax.set_ylim(0, capacity_gw * 1.05)
            
            plt.tight_layout()
            
            if save_plot:
                plot_path = f"plots/forecast_{as_of.date()}_to_{start_date.date()}_{end_date.date()}.png"
                plt.savefig(plot_path, dpi=150, bbox_inches='tight')
                print(f"\nPlot saved to {plot_path}")
            
            plt.show()
        
        return result_df

    def train_model(
        self,
        start_date: str | datetime = "2020-01-01",
        end_date: str | datetime = "2024-12-31",
        max_horizon_days: int = 365 * 2,
        horizon_step: int = 1,
        sample_frequency: int = 7
    ):
        """
        Train model to predict realized availability from as-of forecasts.
        
        For each training date, we:
        1. Get forecasted availability as-of that date for future horizons
        2. Get realized availability for those future dates (as-of today)
        3. Build features: [forecasted_avail, realized_now, horizon_days, seasonality]
        4. Target: realized_avail
        
        Args:
            start_date: Start of training period
            end_date: End of training period
            max_horizon_days: Maximum lookahead in days (default 730 = 2 years)
            horizon_step: Sample every Nth horizon day (1=daily, 7=weekly). 
                          Use higher values to reduce dataset size.
            sample_frequency: Sample every N training dates to reduce dataset size
        """
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, "%Y-%m-%d")
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, "%Y-%m-%d")
        
        # Generate horizon list based on step
        horizons = list(range(1, max_horizon_days + 1, horizon_step))
        
        print(f"Building training dataset from {start_date.date()} to {end_date.date()}...")
        print(f"Max horizon: {max_horizon_days} days, step: {horizon_step} ({len(horizons)} horizons)")
        print(f"Sample frequency: every {sample_frequency} days")
        
        # Generate training dates
        training_dates = []
        current = start_date
        while current <= end_date:
            training_dates.append(current)
            current += timedelta(days=sample_frequency)
        
        print(f"Training on {len(training_dates)} dates...")
        print(f"Estimated samples: ~{len(training_dates) * len(horizons):,}")
        
        # Lookback periods for historical forecast features
        lookback_days = [7, 30, 90]
        
        # Expand as_of_dates to include lookback dates for historical forecast features
        all_as_of_dates = set(training_dates)
        for td in training_dates:
            for lb in lookback_days:
                all_as_of_dates.add(td - timedelta(days=lb))
        all_as_of_dates = sorted(all_as_of_dates)
        print(f"Including {len(all_as_of_dates)} as_of dates (with {lookback_days} day lookbacks)")
        
        # Pre-compute realized availability (as-of today, up to today) with caching
        print("Loading/computing realized availability (cached)...")
        today = datetime.now()
        realized_dict = self._get_realized_availability_cached(
            start=start_date - timedelta(days=max(lookback_days)),
            end=today,
        )
        
        # Pre-compute all forecast snapshots with caching (including lookback dates)
        print("Loading/computing forecast availability (cached)...")
        forecast_df = self._get_forecast_availability_cached(
            as_of_dates=all_as_of_dates,
            max_horizon=max_horizon_days + max(lookback_days),  # Need longer horizon for lookback dates
        )
        
        # Build forecast lookup dict: {(as_of_date, target_ts): forecast_total}
        print("Building forecast lookup...")
        forecast_lookup: Dict[tuple, float] = {}
        for _, row in forecast_df.iterrows():
            key = (row["as_of_date"], row["target_ts"])
            forecast_lookup[key] = row["forecast_total"]
        
        # Build daily path lookup: {as_of_date: {target_date: daily_avg}}
        print("Building daily path lookup for path features...")
        path_lookup: Dict[datetime, Dict[datetime, float]] = {}
        for as_of in training_dates:
            path_lookup[as_of] = {}
        for _, row in forecast_df.iterrows():
            as_of = row["as_of_date"]
            target = row["target_ts"]
            if as_of in path_lookup:
                # Use date (not datetime) as key for daily aggregation
                target_date = target.date() if hasattr(target, 'date') else target
                if target_date not in path_lookup[as_of]:
                    path_lookup[as_of][target_date] = []
                path_lookup[as_of][target_date].append(row["forecast_total"])
        # Average multiple hours into daily values
        for as_of in path_lookup:
            for dt in path_lookup[as_of]:
                vals = path_lookup[as_of][dt]
                path_lookup[as_of][dt] = np.mean(vals) if isinstance(vals, list) else vals
        
        # Build training data (now fast - just dict lookups)
        print("Assembling training samples...")
        X_list = []
        y_list = []
        skipped_no_path = 0
        
        # Define feature names for later reference
        self._feature_names = [
            'forecast_val', 'realized_now', 'horizon_days',
            'target_sin_doy', 'target_cos_doy',  # Target date seasonality
            'forecast_7d_ago', 'forecast_30d_ago', 'forecast_90d_ago',
            'delta_7d', 'delta_30d', 'delta_90d',  # Forecast revisions
            'path_mean', 'path_min', 'path_max', 'path_std', 'path_range',
            'path_slope', 'path_max_daily_jump', 'path_end_vs_mean', 'path_curvature'
        ]
        
        for forecast_date in training_dates:
            # Realized availability on the forecast date itself (what we know "now")
            realized_on_forecast_date = realized_dict.get(forecast_date)
            if realized_on_forecast_date is None:
                continue  # Skip if we don't know realized availability on forecast date
            
            # Get path data for this as_of_date
            as_of_path = path_lookup.get(forecast_date, {})
            
            for horizon_days in horizons:
                target_date = forecast_date + timedelta(days=horizon_days)
                
                # Compute target date seasonality (not forecast date)
                target_day_of_year = target_date.timetuple().tm_yday
                target_day_of_year_rad = 2 * np.pi * target_day_of_year / 365.25
                target_sin_doy = np.sin(target_day_of_year_rad)
                target_cos_doy = np.cos(target_day_of_year_rad)
                
                # Look up forecast and realized values
                forecast_val = forecast_lookup.get((forecast_date, target_date))
                realized_val = realized_dict.get(target_date)
                
                if forecast_val is not None and realized_val is not None:
                    # Look up historical forecasts for the same target date
                    # (what was EDF forecasting 7/30/90 days ago for this target?)
                    forecast_7d_ago = forecast_lookup.get((forecast_date - timedelta(days=7), target_date))
                    forecast_30d_ago = forecast_lookup.get((forecast_date - timedelta(days=30), target_date))
                    forecast_90d_ago = forecast_lookup.get((forecast_date - timedelta(days=90), target_date))
                    
                    # Use current forecast as fallback if historical not available
                    if forecast_7d_ago is None:
                        forecast_7d_ago = forecast_val
                    if forecast_30d_ago is None:
                        forecast_30d_ago = forecast_val
                    if forecast_90d_ago is None:
                        forecast_90d_ago = forecast_val
                    
                    # Compute forecast revision deltas (how much has the forecast changed?)
                    delta_7d = forecast_val - forecast_7d_ago
                    delta_30d = forecast_val - forecast_30d_ago
                    delta_90d = forecast_val - forecast_90d_ago
                    
                    # Build path from as_of to target
                    path_values = []
                    for d in range(horizon_days + 1):
                        dt = (forecast_date + timedelta(days=d)).date()
                        if dt in as_of_path:
                            path_values.append(as_of_path[dt])
                    
                    # Extract path features
                    if len(path_values) >= 2:
                        path_feats = self._extract_path_features(np.array(path_values))
                    else:
                        path_feats = None
                    
                    if path_feats is None:
                        skipped_no_path += 1
                        continue
                    
                    # Features: base + target seasonality + lookbacks + deltas + path
                    X_list.append([
                        forecast_val, realized_on_forecast_date, horizon_days,
                        target_sin_doy, target_cos_doy,
                        forecast_7d_ago, forecast_30d_ago, forecast_90d_ago,
                        delta_7d, delta_30d, delta_90d,
                        path_feats['path_mean'], path_feats['path_min'], path_feats['path_max'],
                        path_feats['path_std'], path_feats['path_range'],
                        path_feats['path_slope'], path_feats['path_max_daily_jump'],
                        path_feats['path_end_vs_mean'], path_feats['path_curvature']
                    ])
                    y_list.append(realized_val)
        
        if skipped_no_path > 0:
            print(f"  (Skipped {skipped_no_path:,} samples with insufficient path data)")
        
        print(f"\nTotal training samples: {len(X_list)}")
        
        # Convert to numpy arrays
        X = np.array(X_list, dtype=np.float32)
        y = np.array(y_list, dtype=np.float32)
        
        # Store forecast_dates for temporal split (we'll track via index)
        # For temporal validation, use last 20% of data (sorted by forecast_date)
        val_split_idx = int(len(X) * 0.8)
        X_train, X_val = X[:val_split_idx], X[val_split_idx:]
        y_train, y_val = y[:val_split_idx], y[val_split_idx:]
        
        print(f"Train samples: {len(y_train):,}, Validation samples: {len(y_val):,}")
        
        # LightGBM doesn't require feature scaling, but we keep scaler for compatibility
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        scaler.fit(X_train)  # Fit only on training data
        self.scaler = scaler
        
        # Import LightGBM and Optuna
        try:
            from lightgbm import LGBMRegressor
            import optuna
            import warnings
            optuna.logging.set_verbosity(optuna.logging.WARNING)
            # Suppress the feature names warning from sklearn validation
            warnings.filterwarnings('ignore', message='.*X does not have valid feature names.*')
        except ImportError as e:
            raise ImportError(
                "lightgbm and optuna are required for training. "
                "Install with: pip install lightgbm optuna"
            ) from e
        
        print("\nRunning Optuna hyperparameter search (20 trials)...")
        
        def objective(trial):
            params = {
                'n_estimators': trial.suggest_int('n_estimators', 200, 1000),
                'max_depth': trial.suggest_int('max_depth', 4, 10),
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.1, log=True),
                'num_leaves': trial.suggest_int('num_leaves', 15, 127),
                'min_child_samples': trial.suggest_int('min_child_samples', 50, 300),
                'subsample': trial.suggest_float('subsample', 0.6, 0.95),
                'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 0.95),
                'reg_alpha': trial.suggest_float('reg_alpha', 1e-3, 10.0, log=True),
                'reg_lambda': trial.suggest_float('reg_lambda', 1e-3, 10.0, log=True),
            }
            
            model = LGBMRegressor(
                **params,
                random_state=42,
                n_jobs=-1,
                verbose=-1,
            )
            
            model.fit(
                X_train, y_train,
                eval_set=[(X_val, y_val)],
            )
            
            val_pred = model.predict(X_val)
            val_mae = np.mean(np.abs(val_pred - y_val))
            return val_mae
        
        study = optuna.create_study(direction='minimize')
        study.optimize(objective, n_trials=20, show_progress_bar=True)
        
        print(f"\nBest trial MAE: {study.best_trial.value:.2f} MW")
        print(f"Best parameters:")
        for key, value in study.best_params.items():
            print(f"  {key}: {value}")
        
        # Train final model with best parameters on full training data
        print("\nTraining final LightGBM model with best parameters...")
        self.model = LGBMRegressor(
            **study.best_params,
            random_state=42,
            n_jobs=-1,
            verbose=-1,
        )
        
        # Train on full dataset (train + val) for final model
        self.model.fit(X, y)
        
        # Calculate metrics on validation set
        y_pred_val = self.model.predict(X_val)
        mae = np.mean(np.abs(y_val - y_pred_val))
        rmse = np.sqrt(np.mean((y_val - y_pred_val)**2))
        
        print(f"\nTraining complete!")
        print(f"  Best trees: {self.model.n_estimators}")
        print(f"  Validation MAE: {mae:.2f} MW")
        print(f"  Validation RMSE: {rmse:.2f} MW")
        print(f"  Feature importance (sorted):")
        
        # Sort features by importance
        importance_pairs = list(zip(self._feature_names, self.model.feature_importances_))
        importance_pairs.sort(key=lambda x: x[1], reverse=True)
        for name, importance in importance_pairs:
            print(f"    {name}: {importance:.3f}")
        
        # Store best params for reference
        self.best_params = study.best_params
        
        return self.model

    def evaluate_model(
        self,
        test_start_date: str | datetime = "2024-01-01",
        test_end_date: str | datetime = "2024-12-31",
        max_horizon_days: int = 365 * 2,
        horizon_step: int = 1,
        report_horizons: list[int] | None = None,
        sample_frequency: int = 7,
        save_plots: bool = True
    ):
        """
        Evaluate trained model on test set and generate plots.
        
        Args:
            test_start_date: Start of test period
            test_end_date: End of test period
            max_horizon_days: Maximum lookahead in days
            horizon_step: Sample every Nth horizon day
            report_horizons: Specific horizons to report metrics for (default: [1,7,30,90,180,365])
            sample_frequency: Sample every N test dates
            save_plots: Whether to save plots to files
        """
        from matplotlib.dates import DateFormatter
        import warnings
        
        # Suppress the feature names warning from sklearn validation
        warnings.filterwarnings('ignore', message='.*X does not have valid feature names.*')
        
        if self.model is None:
            raise ValueError("Model not trained. Call train_model() first.")
        
        if isinstance(test_start_date, str):
            test_start_date = datetime.strptime(test_start_date, "%Y-%m-%d")
        if isinstance(test_end_date, str):
            test_end_date = datetime.strptime(test_end_date, "%Y-%m-%d")
        
        # Generate horizon list based on step
        horizons = list(range(1, max_horizon_days + 1, horizon_step))
        
        # Default report horizons for metrics breakdown
        if report_horizons is None:
            report_horizons = [1, 7, 30, 90, 180, 365]
        # Only include report horizons that are in our horizons list
        report_horizons = [h for h in report_horizons if h <= max_horizon_days]
        
        print(f"\n{'='*70}")
        print("Evaluating Model on Test Set")
        print(f"{'='*70}")
        print(f"Test period: {test_start_date.date()} to {test_end_date.date()}")
        print(f"Max horizon: {max_horizon_days} days, step: {horizon_step} ({len(horizons)} horizons)")
        
        # Generate test dates
        test_dates = []
        current = test_start_date
        while current <= test_end_date:
            test_dates.append(current)
            current += timedelta(days=sample_frequency)
        
        # Lookback periods for historical forecast features
        lookback_days = [7, 30, 90]
        
        # Expand as_of_dates to include lookback dates
        all_as_of_dates = set(test_dates)
        for td in test_dates:
            for lb in lookback_days:
                all_as_of_dates.add(td - timedelta(days=lb))
        all_as_of_dates = sorted(all_as_of_dates)
        
        # Get realized availability (cached)
        today = datetime.now()
        print("Loading/computing realized availability (cached)...")
        realized_dict = self._get_realized_availability_cached(
            start=test_start_date - timedelta(days=max(lookback_days)),
            end=today,
        )
        
        # Pre-compute all forecast snapshots with caching (including lookback dates)
        print("Loading/computing forecast availability (cached)...")
        forecast_df = self._get_forecast_availability_cached(
            as_of_dates=all_as_of_dates,
            max_horizon=max_horizon_days + max(lookback_days),
        )
        
        # Build forecast lookup dict
        print("Building forecast lookup...")
        forecast_lookup: Dict[tuple, float] = {}
        for _, row in forecast_df.iterrows():
            key = (row["as_of_date"], row["target_ts"])
            forecast_lookup[key] = row["forecast_total"]
        
        # Build daily path lookup: {as_of_date: {target_date: daily_avg}}
        print("Building daily path lookup for path features...")
        path_lookup: Dict[datetime, Dict] = {}
        for as_of in test_dates:
            path_lookup[as_of] = {}
        for _, row in forecast_df.iterrows():
            as_of = row["as_of_date"]
            target = row["target_ts"]
            if as_of in path_lookup:
                target_date = target.date() if hasattr(target, 'date') else target
                if target_date not in path_lookup[as_of]:
                    path_lookup[as_of][target_date] = []
                path_lookup[as_of][target_date].append(row["forecast_total"])
        # Average multiple hours into daily values
        for as_of in path_lookup:
            for dt in path_lookup[as_of]:
                vals = path_lookup[as_of][dt]
                path_lookup[as_of][dt] = np.mean(vals) if isinstance(vals, list) else vals
        
        # Build test data (now fast - just dict lookups + model predictions)
        print("Building test predictions...")
        results = []
        skipped_no_path = 0
        
        for forecast_date in test_dates:
            # Realized availability on the forecast date itself (what we know "now")
            realized_on_forecast_date = realized_dict.get(forecast_date)
            if realized_on_forecast_date is None:
                continue  # Skip if we don't know realized availability on forecast date
            
            # Get path data for this as_of_date
            as_of_path = path_lookup.get(forecast_date, {})
            
            for horizon_days in horizons:
                target_date = forecast_date + timedelta(days=horizon_days)
                
                # Compute target date seasonality (not forecast date)
                target_day_of_year = target_date.timetuple().tm_yday
                target_day_of_year_rad = 2 * np.pi * target_day_of_year / 365.25
                target_sin_doy = np.sin(target_day_of_year_rad)
                target_cos_doy = np.cos(target_day_of_year_rad)
                
                forecast_val = forecast_lookup.get((forecast_date, target_date))
                realized_val = realized_dict.get(target_date)
                
                if forecast_val is not None and realized_val is not None:
                    # Look up historical forecasts for the same target date
                    forecast_7d_ago = forecast_lookup.get((forecast_date - timedelta(days=7), target_date))
                    forecast_30d_ago = forecast_lookup.get((forecast_date - timedelta(days=30), target_date))
                    forecast_90d_ago = forecast_lookup.get((forecast_date - timedelta(days=90), target_date))
                    
                    # Use current forecast as fallback if historical not available
                    if forecast_7d_ago is None:
                        forecast_7d_ago = forecast_val
                    if forecast_30d_ago is None:
                        forecast_30d_ago = forecast_val
                    if forecast_90d_ago is None:
                        forecast_90d_ago = forecast_val
                    
                    # Compute forecast revision deltas
                    delta_7d = forecast_val - forecast_7d_ago
                    delta_30d = forecast_val - forecast_30d_ago
                    delta_90d = forecast_val - forecast_90d_ago
                    
                    # Build path from as_of to target
                    path_values = []
                    for d in range(horizon_days + 1):
                        dt = (forecast_date + timedelta(days=d)).date()
                        if dt in as_of_path:
                            path_values.append(as_of_path[dt])
                    
                    # Extract path features
                    if len(path_values) >= 2:
                        path_feats = self._extract_path_features(np.array(path_values))
                    else:
                        path_feats = None
                    
                    if path_feats is None:
                        skipped_no_path += 1
                        continue
                    
                    # Generate features (same order as training)
                    X = np.array([[
                        forecast_val, realized_on_forecast_date, horizon_days,
                        target_sin_doy, target_cos_doy,
                        forecast_7d_ago, forecast_30d_ago, forecast_90d_ago,
                        delta_7d, delta_30d, delta_90d,
                        path_feats['path_mean'], path_feats['path_min'], path_feats['path_max'],
                        path_feats['path_std'], path_feats['path_range'],
                        path_feats['path_slope'], path_feats['path_max_daily_jump'],
                        path_feats['path_end_vs_mean'], path_feats['path_curvature']
                    ]])
                    
                    # LightGBM doesn't need scaling, but apply for consistency
                    prediction = self.model.predict(X)[0]
                    
                    results.append({
                        'forecast_date': forecast_date,
                        'target_date': target_date,
                        'horizon': horizon_days,
                        'forecast': forecast_val,
                        'realized_now': realized_on_forecast_date,
                        'prediction': prediction,
                        'realized': realized_val,
                        'error': prediction - realized_val,
                        'naive_error': forecast_val - realized_val
                    })
        
        if skipped_no_path > 0:
            print(f"  (Skipped {skipped_no_path:,} samples with insufficient path data)")
        
        print(f"\nTotal test samples: {len(results)}")
        
        # Calculate metrics
        results_arr = np.array([[r['prediction'], r['realized'], r['forecast'], r['naive_error']] 
                                for r in results])
        
        mae_model = np.mean(np.abs(results_arr[:, 0] - results_arr[:, 1]))
        mae_naive = np.mean(np.abs(results_arr[:, 2] - results_arr[:, 1]))
        rmse_model = np.sqrt(np.mean((results_arr[:, 0] - results_arr[:, 1])**2))
        rmse_naive = np.sqrt(np.mean((results_arr[:, 2] - results_arr[:, 1])**2))
        
        improvement = (mae_naive - mae_model) / mae_naive * 100
        
        print(f"\n{'='*70}")
        print("Test Set Metrics (All Horizons)")
        print(f"{'='*70}")
        print(f"Model MAE:  {mae_model:.2f} MW")
        print(f"EDF UMM MAE:  {mae_naive:.2f} MW")
        print(f"Model RMSE: {rmse_model:.2f} MW")
        print(f"EDF UMM RMSE: {rmse_naive:.2f} MW")
        print(f"Improvement: {improvement:.1f}%")
        
        # Calculate metrics for 15-45 day horizon range
        h_min, h_max = 15, 45
        results_15_45 = [r for r in results if h_min <= r['horizon'] <= h_max]
        if results_15_45:
            errors_15_45 = np.array([r['error'] for r in results_15_45])
            naive_errors_15_45 = np.array([r['naive_error'] for r in results_15_45])
            
            mae_model_15_45 = np.mean(np.abs(errors_15_45))
            mae_naive_15_45 = np.mean(np.abs(naive_errors_15_45))
            std_model_15_45 = np.std(errors_15_45)
            std_naive_15_45 = np.std(naive_errors_15_45)
            bias_model_15_45 = np.mean(errors_15_45)  # Positive = over-predict, Negative = under-predict
            bias_naive_15_45 = np.mean(naive_errors_15_45)
            improvement_15_45 = (mae_naive_15_45 - mae_model_15_45) / mae_naive_15_45 * 100
            
            print(f"\n{'='*70}")
            print(f"Test Set Metrics ({h_min}-{h_max} Day Horizons)")
            print(f"{'='*70}")
            print(f"Model MAE:  {mae_model_15_45:.2f} MW")
            print(f"EDF UMM MAE:  {mae_naive_15_45:.2f} MW")
            print(f"Model Std Dev: {std_model_15_45:.2f} MW")
            print(f"EDF UMM Std Dev: {std_naive_15_45:.2f} MW")
            print(f"Model Bias: {bias_model_15_45:+.2f} MW")
            print(f"EDF UMM Bias: {bias_naive_15_45:+.2f} MW")
            print(f"Improvement: {improvement_15_45:.1f}%")
        
        # Generate plots
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle("French Nuclear Availability Forecast", fontsize=16, fontweight='bold', y=1.02)
        
        # Plot 1: Predicted vs Realized
        ax = axes[0, 0]
        sample_idx = np.random.choice(len(results), min(1000, len(results)), replace=False)
        sample_results = [results[i] for i in sample_idx]
        
        pred_vals = [r['prediction'] for r in sample_results]
        real_vals = [r['realized'] for r in sample_results]
        
        ax.scatter(real_vals, pred_vals, alpha=0.3, s=20, c='blue', label='Model')
        
        mx = max(max(pred_vals), max(real_vals))
        mn = min(min(pred_vals), min(real_vals))
        ax.plot([mn, mx], [mn, mx], 'r--', linewidth=2, label='Perfect')
        
        ax.set_xlabel("Realized Availability (MW)", fontweight='bold')
        ax.set_ylabel("Predicted Availability (MW)", fontweight='bold')
        ax.set_title(f"Model: Predicted vs Realized\nMAE={mae_model:.1f} MW", fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Plot 2: Error Distribution (for 15-45 day horizons)
        ax = axes[0, 1]
        error_horizon_min, error_horizon_max = 15, 45
        filtered_results = [r for r in results if error_horizon_min <= r['horizon'] <= error_horizon_max]
        errors = [r['error'] for r in filtered_results]
        naive_errors = [r['naive_error'] for r in filtered_results]
        
        # Calculate MAE for this horizon range
        mae_model_filtered = np.mean(np.abs(errors)) if errors else 0
        mae_naive_filtered = np.mean(np.abs(naive_errors)) if naive_errors else 0
        
        bins = np.linspace(-7000, 7000, 50)
        ax.hist(errors, bins=bins, alpha=0.5, label=f'Model (MAE={mae_model_filtered:.0f})', color='blue')
        ax.hist(naive_errors, bins=bins, alpha=0.5, label=f'EDF UMM (MAE={mae_naive_filtered:.0f})', color='gray')
        ax.axvline(0, color='red', linestyle='--', linewidth=2)
        
        ax.set_xlabel("Prediction Error (MW)", fontweight='bold')
        ax.set_ylabel("Frequency", fontweight='bold')
        ax.set_title(f"Error Distribution (Horizons: {error_horizon_min}-{error_horizon_max} days)", fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Plot 3: Time Series Example - 30 and 90 day horizons
        ax = axes[1, 0]
        horizons_to_plot = [30, 90]
        colors_umm = {'30': 'orange', '90': 'gray'}
        colors_model = {'30': 'red', '90': 'blue'}
        
        # Get realized availability for the FULL test period (from test_start_date)
        realized_dates = []
        realized_vals = []
        current_date = test_start_date
        while current_date <= test_end_date:
            realized_val = realized_dict.get(current_date)
            if realized_val is not None:
                realized_dates.append(current_date)
                realized_vals.append(realized_val)
            current_date += timedelta(days=1)
        
        if realized_dates:
            # Plot realized availability first (green) - full period from Jan 1
            ax.plot(realized_dates, realized_vals, 'g-', linewidth=2, label='Realized', alpha=0.8)
            
            # Plot each horizon
            for h in horizons_to_plot:
                ts_h = [
                    r for r in results 
                    if r['horizon'] == h 
                    and r['target_date'] <= test_end_date
                ]
                ts_h.sort(key=lambda x: x['target_date'])
                
                if ts_h:
                    dates_h = [r['target_date'] for r in ts_h]
                    forecasts_h = [r['forecast'] for r in ts_h]
                    predictions_h = [r['prediction'] for r in ts_h]
                    
                    ax.plot(dates_h, forecasts_h, colors_umm[str(h)], alpha=0.4, linewidth=1, 
                            label=f'EDF UMM {h}d')
                    ax.plot(dates_h, predictions_h, colors_model[str(h)], linewidth=1.5, alpha=0.8,
                            label=f'Model {h}d')
            
            ax.set_xlabel("Date", fontweight='bold')
            ax.set_ylabel("Availability (MW)", fontweight='bold')
            ax.set_title("Time Series: 30 & 90-Day Ahead Forecasts", fontweight='bold')
            ax.legend(loc='upper left', fontsize=8)
            ax.grid(True, alpha=0.3)
            ax.xaxis.set_major_formatter(DateFormatter('%Y-%m'))
        
        # Plot 4: Performance by Horizon (using report_horizons for breakdown)
        ax = axes[1, 1]
        horizon_stats = {}
        for h in report_horizons:
            # Find results closest to this horizon (within ±horizon_step/2)
            h_results = [r for r in results if abs(r['horizon'] - h) <= max(1, horizon_step // 2)]
            if h_results:
                h_mae = np.mean([abs(r['error']) for r in h_results])
                h_naive_mae = np.mean([abs(r['naive_error']) for r in h_results])
                horizon_stats[h] = {'model': h_mae, 'naive': h_naive_mae}
        
        if horizon_stats:
            horizons_sorted = sorted(horizon_stats.keys())
            model_maes = [horizon_stats[h]['model'] for h in horizons_sorted]
            naive_maes = [horizon_stats[h]['naive'] for h in horizons_sorted]
            
            x = np.arange(len(horizons_sorted))
            width = 0.35
            
            ax.bar(x - width/2, model_maes, width, label='Model', color='blue')
            ax.bar(x + width/2, naive_maes, width, label='EDF UMM', color='gray')
            
            ax.set_xlabel('Forecast Horizon (days)', fontweight='bold')
            ax.set_ylabel('MAE (MW)', fontweight='bold')
            ax.set_title('Model Performance by Horizon', fontweight='bold')
            ax.set_xticks(x)
            ax.set_xticklabels(horizons_sorted)
            ax.legend()
            ax.grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        if save_plots:
            plot_path = "availability_model_evaluation.png"
            plt.savefig(plot_path, dpi=150, bbox_inches='tight')
            print(f"\nPlots saved to {plot_path}")
        
        plt.show()
        
        return results





if __name__ == '__main__':
    print("="*70)
    print("Training Availability Forecast Model")
    print("="*70)
    import datetime as dt
    # Initialize model
    m = AvailabilityModel("data/edf_outages.csv")

    m.train_model(
        start_date="2017-01-01",
        end_date="2025-12-20",
        max_horizon_days=365,
    )

    # Generate forecast for May 2026
    forecast_df = m.forecast(
        as_of=date.today(),
        start_date=date(2026, 5, 1),
        end_date=date(2026, 5, 31),
        plot=True
    )


    as_of_date = dt.datetime.now()
    start_date = dt.datetime(2023, 1, 1)
    end_date = dt.datetime(2025, 12, 14)  # Stop before Dec 15, 2025

    # Get total availability for 2024-2025
    avail_df = m.calculate_availability(
        as_of=as_of_date,
        start=start_date,
        end=end_date
    )
    total_avail = (
        avail_df.groupby("ts")
        .agg(total_avail_mw=("p_avail_mw", "sum"))
        .reset_index()
        .sort_values("ts")
    )

    # Get economic reduction for 2024-2025
    econ_df = m.calculate_economic_unavailability(
        as_of=as_of_date,
        start=start_date,
        end=end_date
    )
    total_econ = (
        econ_df.groupby("ts")
        .agg(total_econ_reduction_mw=("economic_reduction_mw", "sum"))
        .reset_index()
        .sort_values("ts")
    )

    # Join and compute availability without economic modulation
    combined = total_avail.merge(total_econ, on="ts", how="left").fillna(0)
    combined["avail_without_econ_mw"] = combined["total_avail_mw"] + combined["total_econ_reduction_mw"]

    # Convert to pandas for plotting (already pandas now)
    plot_df = combined.copy()
    plot_df['ts'] = pd.to_datetime(plot_df['ts'])
    
    # Calculate economic reduction in GW
    plot_df['econ_reduction_gw'] = (plot_df['avail_without_econ_mw'] - plot_df['total_avail_mw']) / 1000

    # Create the plot with twin y-axis
    fig, ax = plt.subplots(figsize=(16, 6))
    ax2 = ax.twinx()

    # Primary y-axis: Availability lines
    line1 = ax.plot(plot_df['ts'], plot_df['total_avail_mw'] / 1000,
                    color='blue', linewidth=1.5, label='Total Availability (EDF UMM)', alpha=0.9)
    line2 = ax.plot(plot_df['ts'], plot_df['avail_without_econ_mw'] / 1000,
                    color='green', linewidth=1.5, label='Availability excl. Economic Modulation', alpha=0.9)

    # Secondary y-axis: Economic modulation as shaded area
    ax2.fill_between(plot_df['ts'], 0, plot_df['econ_reduction_gw'],
                     alpha=0.4, color='orange', label='Economic Modulation (GW)')
    ax2.set_ylabel("Economic Modulation (GW)", fontweight='bold', color='orange')
    ax2.tick_params(axis='y', labelcolor='orange')
    ax2.set_ylim(0, max(plot_df['econ_reduction_gw'].max() * 1.2, 1))  # Set y-limit with some headroom

    ax.set_xlabel("Date", fontweight='bold')
    ax.set_ylabel("Availability (GW)", fontweight='bold')
    ax.set_title("French Nuclear Availability: Impact of Economic Modulation (2023-2025)", fontweight='bold')
    
    # Combine legends from both axes - position inside plot at upper left
    lines1, labels1 = ax.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax.legend(lines1 + lines2, labels1 + labels2, loc='upper left', frameon=True, fontsize=9)
    
    ax.grid(True, alpha=0.3)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))  # Every 3 months for 3-year span
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    plt.tight_layout()
    
    #
    # print("\nTraining model to predict realized availability from forecasts...")
    # model = m.train_model(
    #     start_date="2017-01-01",  # Exclude 2016 for data quality
    #     end_date="2024-12-31",
    #     max_horizon_days=365 * 2,  # 2 years out
    #     horizon_step=1,            # Every day (set to 7 for weekly to speed up)
    #     sample_frequency=1
    # )
    #
    # import pickle
    # import os
    #
    # model_path = "models/availability_forecast_model.pkl"
    # os.makedirs("models", exist_ok=True)
    #
    # with open(model_path, 'wb') as f:
    #     pickle.dump({
    #         'model': model,
    #         'scaler': m.scaler,
    #         'best_params': getattr(m, 'best_params', {}),
    #         'feature_names': m._feature_names,
    #     }, f)
    # print(f"\nModel and scaler saved to {model_path}")
    #
    # # Evaluate on test set
    # print("\n" + "="*70)
    # print("Evaluating Model on Test Set (2024)")
    # print("="*70)
    #
    # m.evaluate_model(
    #     test_start_date="2025-01-01",
    #     test_end_date="2025-12-10",
    #     max_horizon_days=365 * 2,  # Match training
    #     horizon_step=1,            # Every day
    #     report_horizons=[1, 7, 30, 90, 180, 365],  # Specific horizons for metrics
    #     sample_frequency=1,
    #     save_plots=True
    # )
    #
    # print("\n" + "="*70)
    # print("Training & Evaluation Complete!")
    # print("="*70)
    #
    # # Plot: Total Availability vs Availability minus Economic Reduction for 2025
    # print("\n" + "="*70)
    # print("Plotting: Availability vs Economic Modulation Impact (2025)")
    # print("="*70)
    

    

    
    # Save plot
    os.makedirs("plots", exist_ok=True)
    plt.savefig("plots/availability_vs_economic_modulation_2023_2025.png", dpi=150, bbox_inches='tight')
    print("Plot saved to plots/availability_vs_economic_modulation_2023_2025.png")
    plt.show()
    
    # =========================================================================
    # Regression: FR EPEX Price vs Economic Modulation
    # =========================================================================
    print("\n" + "="*70)
    print("Regression: FR EPEX Price vs Economic Modulation")
    print("="*70)
    
    from entsoe import EntsoePandasClient
    from scipy import stats
    
    # Get FR day-ahead prices for 2025 using ENTSOE
    API_KEY = '98c0eeb9-19cf-4664-8bb6-5dad7a3ac105'
    client = EntsoePandasClient(api_key=API_KEY)
    
    # Prepare dates for ENTSOE (requires Timestamp with timezone)
    s_ts = pd.Timestamp(start_date).tz_localize('UTC')
    e_ts = pd.Timestamp(end_date).tz_localize('UTC')
    
    # Fetch FR prices in monthly chunks to avoid pagination issues
    print("Fetching FR day-ahead prices from ENTSOE...")
    all_series = []
    current_start = s_ts
    
    while current_start < e_ts:
        next_month = current_start + pd.offsets.MonthBegin(1)
        chunk_end = min(next_month, e_ts)
        
        if current_start >= chunk_end:
            break
            
        try:
            chunk = client.query_day_ahead_prices('FR', start=current_start, end=chunk_end)
            if not chunk.empty:
                all_series.append(chunk)
        except Exception as chunk_e:
            print(f"  Warning: Failed to fetch chunk {current_start.date()}: {chunk_e}")
        
        current_start = chunk_end
    
    if all_series:
        fr_prices_raw = pd.concat(all_series)
        fr_prices_raw = fr_prices_raw[~fr_prices_raw.index.duplicated(keep='first')]
        
        # Convert to DataFrame, resample to hourly mean, and prepare
        fr_prices = fr_prices_raw.to_frame(name='price_eur_mwh')
        fr_prices.index = fr_prices.index.tz_convert('Europe/Paris').tz_localize(None)
        fr_prices = fr_prices.resample('h').mean()  # Resample to hourly mean
        fr_prices = fr_prices.reset_index().rename(columns={'index': 'ts'})
        fr_prices = fr_prices.dropna()
        
        print(f"  Fetched {len(fr_prices)} hourly price points")
        
        # Get economic reduction data (already computed above as total_econ)
        econ_hourly = total_econ.copy()
        econ_hourly['ts'] = pd.to_datetime(econ_hourly['ts'])
        
        # Merge price and economic modulation
        merged = pd.merge(fr_prices, econ_hourly, on='ts', how='inner')
        merged = merged.sort_values('ts').reset_index(drop=True)
        
        print(f"\nTotal matched hours: {len(merged)}")
        print(f"Hours with economic modulation > 0: {(merged['total_econ_reduction_mw'] > 0).sum()}")
        
        # Find contiguous blocks with the same modulation level
        # Create a block identifier when the modulation value changes
        merged['mod_changed'] = merged['total_econ_reduction_mw'].ne(merged['total_econ_reduction_mw'].shift())
        merged['block_id'] = merged['mod_changed'].cumsum()
        
        # For each block, calculate mean price and the modulation level
        block_stats = merged.groupby('block_id').agg({
            'price_eur_mwh': 'mean',
            'total_econ_reduction_mw': 'first',  # All values in block are the same
            'ts': ['first', 'last', 'count']  # Block start, end, and duration
        }).reset_index()
        block_stats.columns = ['block_id', 'mean_price', 'modulation_mw', 'block_start', 'block_end', 'block_hours']
        
        # Filter to blocks with modulation > 0 for regression
        blocks_with_modulation = block_stats[block_stats['modulation_mw'] > 0].copy()
        print(f"Total contiguous blocks: {len(block_stats)}")
        print(f"Blocks with modulation > 0: {len(blocks_with_modulation)}")
        print(f"Using {len(blocks_with_modulation)} blocks for regression (excluding zero modulation)")
        
        # Linear regression: Block Mean Price (X) vs Modulation Level (Y)
        X = blocks_with_modulation['mean_price'].values
        Y = blocks_with_modulation['modulation_mw'].values
        
        # Remove NaNs
        mask = ~(np.isnan(X) | np.isnan(Y))
        X_clean = X[mask]
        Y_clean = Y[mask]
        
        # Get block metadata for coloring
        block_starts = blocks_with_modulation['block_start'].values[mask]
        block_hours = blocks_with_modulation['block_hours'].values[mask]
        
        if len(X_clean) > 10:
            # Create 3-panel plot
            fig, axes = plt.subplots(1, 3, figsize=(18, 5))
            
            # Plot 1: Simple scatter plot (no regression lines)
            ax1 = axes[0]
            ax1.scatter(X_clean, Y_clean, alpha=0.5, s=20, c='steelblue', edgecolors='none')
            
            ax1.set_xlabel("Block Mean Price (EUR/MWh)", fontweight='bold')
            ax1.set_ylabel("Economic Modulation Level (MW)", fontweight='bold')
            ax1.set_title("Scatter: Price vs Modulation", fontweight='bold')
            ax1.grid(True, alpha=0.3)
            
            # Plot 2: Time series of both
            ax2 = axes[1]
            merged_sorted = merged.sort_values('ts')
            
            # Resample to daily for cleaner visualization
            daily = merged_sorted.set_index('ts')[['price_eur_mwh', 'total_econ_reduction_mw']].resample('D').mean().reset_index()
            
            ax2_twin = ax2.twinx()
            
            line1 = ax2.plot(daily['ts'], daily['price_eur_mwh'], 'b-', 
                            alpha=0.7, linewidth=1, label='FR Price')
            line2 = ax2_twin.plot(daily['ts'], daily['total_econ_reduction_mw'] / 1000, 'orange', 
                                  alpha=0.7, linewidth=1, label='Modulation (GW)')
            
            ax2.set_xlabel("Date", fontweight='bold')
            ax2.set_ylabel("FR Price (EUR/MWh)", fontweight='bold', color='blue')
            ax2_twin.set_ylabel("Modulation (GW)", fontweight='bold', color='orange')
            ax2.set_title("Time Series: Price & Modulation", fontweight='bold')
            
            lines = line1 + line2
            labels = [l.get_label() for l in lines]
            ax2.legend(lines, labels, loc='upper right', fontsize=8)
            
            ax2.grid(True, alpha=0.3)
            ax2.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
            ax2.xaxis.set_major_locator(mdates.MonthLocator(interval=6))
            plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45, ha='right')
            
            # Plot 3: Candlestick-style boxplot by price bins
            # One bin for < 0, then 5 EUR bins for positive values
            ax3 = axes[2]
            
            bin_width = 5
            price_max = np.ceil(X_clean.max() / bin_width) * bin_width
            
            # Create custom bins: one bin for < 0, then 5 EUR bins from 0 onwards
            negative_bin = [X_clean.min() - 1, 0]  # All negative values in one bin
            positive_bins = list(np.arange(0, price_max + bin_width, bin_width))
            bins = negative_bin + positive_bins[1:]  # Avoid duplicate 0
            bins = sorted(list(set(bins)))  # Remove duplicates and sort
            
            # Assign each point to a bin
            bin_labels = pd.cut(X_clean, bins=bins, include_lowest=True)
            
            # Create DataFrame for boxplot
            boxplot_df = pd.DataFrame({
                'price_bin': bin_labels,
                'modulation': Y_clean / 1000  # Convert to GW
            })
            
            # Get unique bins and their midpoints for positioning
            unique_bins = boxplot_df['price_bin'].dropna().unique()
            unique_bins = sorted(unique_bins, key=lambda x: x.left)
            
            # Create positions and labels
            bin_positions = []
            bin_tick_labels = []
            for i, b in enumerate(unique_bins):
                if b.right <= 0:
                    # Negative bin - position at -5
                    bin_positions.append(-5)
                    bin_tick_labels.append('<0')
                else:
                    # Positive bins - use midpoint
                    bin_positions.append((b.left + b.right) / 2)
                    bin_tick_labels.append(f'{int(b.left)}-{int(b.right)}')
            
            # Create box plot data
            boxplot_data = [boxplot_df[boxplot_df['price_bin'] == b]['modulation'].dropna().values 
                           for b in unique_bins]
            
            # Filter out empty bins
            non_empty = [(pos, data, lbl) for pos, data, lbl in zip(bin_positions, boxplot_data, bin_tick_labels) if len(data) > 0]
            if non_empty:
                positions, data, tick_labels = zip(*non_empty)
                
                # Determine box widths (narrower for negative bin, standard for others)
                widths = [3 if pos < 0 else bin_width * 0.7 for pos in positions]
                
                # Create boxplot
                bp = ax3.boxplot(data, positions=positions, widths=widths,
                                patch_artist=True, showfliers=False)
                
                # Style the boxplot
                for patch in bp['boxes']:
                    patch.set_facecolor('orange')
                    patch.set_alpha(0.6)
                for median in bp['medians']:
                    median.set_color('darkred')
                    median.set_linewidth(2)
                for whisker in bp['whiskers']:
                    whisker.set_color('gray')
                for cap in bp['caps']:
                    cap.set_color('gray')
                
                # Set x-ticks at box positions with nice labels
                ax3.set_xticks(positions)
                ax3.set_xticklabels(tick_labels, rotation=45, ha='right', fontsize=9)
            
            ax3.set_xlabel("Price Bin (EUR/MWh)", fontweight='bold')
            ax3.set_ylabel("Economic Modulation (GW)", fontweight='bold')
            ax3.set_title("Modulation by Price Level", fontweight='bold')
            ax3.grid(True, alpha=0.3, axis='y')
            ax3.set_xlim(-10, price_max + bin_width)
            
            plt.tight_layout()
            plt.savefig("plots/price_vs_economic_modulation_regression_2023_2025.png", dpi=150, bbox_inches='tight')
            print("\nPlot saved to plots/price_vs_economic_modulation_regression_2023_2025.png")
            plt.show()
        else:
            print("Not enough data points for regression")
    else:
        print("No FR day-ahead price data available from ENTSOE for the period")

    # ======================================================================
    # Forecast for May 2026 as of today (using trained ML model)
    # ======================================================================
    
    # First, train the model if not already trained
    print("\n" + "=" * 70)
    print("Training Model for May 2026 Forecast")
    print("=" * 70)
    
    print("\nTraining model to predict realized availability from forecasts...")
    m.train_model(
        start_date="2017-01-01",
        end_date="2024-12-31",
        max_horizon_days=365 * 2,  # 2 years out
        horizon_step=1,
        sample_frequency=1,
    )
    
    # Now generate the May 2026 forecast
    from datetime import date as date_type
    today = date_type.today()
    
    may_forecast_df = m.forecast(
        as_of=today,
        start_date=date_type(2026, 5, 1),
        end_date=date_type(2026, 5, 31),
        plot=True,
        save_plot=True,
    )
