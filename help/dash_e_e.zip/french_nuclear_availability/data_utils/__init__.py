"""
Data utility modules for French Nuclear Availability Dashboard

Note: This package is named 'data_utils' to avoid conflict with the existing
'utils.py' file which contains RULES for the AvailabilityModel.
"""

from .data_loader import EDFDataLoader

__all__ = ['EDFDataLoader']
