"""
Data loader for French Nuclear Availability Dashboard.

This module handles loading EDF outage data from S3, with local caching
and automatic refresh mechanisms for production deployment.
"""

import os
import time
import json
import logging
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Tuple
import pandas as pd

# Use corelib S3 connection
try:
    from jain_commods.core.cache.utils.s3 import S3, AWS_BUCKET_NAME
    S3_AVAILABLE = True
except ImportError:
    S3_AVAILABLE = False
    logging.warning("jain_commods.core.cache not available - S3 loading disabled")


class EDFDataLoader:
    """
    Handles loading EDF nuclear outage data from S3 with local caching.
    
    Features:
    - Downloads from S3 (much faster than EDF portal)
    - Local file caching with TTL
    - Automatic refresh in background
    - Fallback to direct download if S3 unavailable
    """
    
    # S3 configuration (matches edf_loader)
    S3_PREFIX = "raw_data/french_nuclear_outages/"
    S3_FILE_KEY = f"{S3_PREFIX}edf_outages_latest.csv"
    S3_METADATA_KEY = f"{S3_PREFIX}metadata.json"
    
    # Local cache configuration (prefer persistent container mount)
    CACHE_DIR = Path(os.getenv("FRENCH_NUCLEAR_CACHE_DIR", "/app/cache/french_nuclear_availability"))
    CACHE_FILE = CACHE_DIR / "edf_outages_cache.csv"
    CACHE_METADATA_FILE = CACHE_DIR / "cache_metadata.json"
    CACHE_TTL_HOURS = 6  # Refresh every 6 hours (matches scraper schedule)
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Initialize the data loader.
        
        Args:
            logger: Optional logger instance. If None, creates a default logger.
        """
        self.logger = logger or self._create_default_logger()
        
        # Initialize S3 connection if available
        self.s3_available = S3_AVAILABLE
        if self.s3_available:
            try:
                self.s3 = S3()
                self.s3_client = self.s3.get_client()
                self.bucket_name = AWS_BUCKET_NAME
                self.logger.info(f"✓ S3 connection initialized (bucket: {self.bucket_name})")
            except Exception as e:
                self.logger.warning(f"Failed to initialize S3 connection: {e}")
                self.s3_available = False
        
        # Ensure cache directory exists
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    
    def _create_default_logger(self) -> logging.Logger:
        """Create a default logger for the data loader."""
        logger = logging.getLogger("EDFDataLoader")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def get_data_path(self, force_refresh: bool = False) -> str:
        """
        Get the path to the EDF outage data file.
        
        This method:
        1. Checks if cached data is fresh (< CACHE_TTL_HOURS old)
        2. If cache is stale or force_refresh=True, downloads from S3
        3. Returns path to the local cached file
        
        Args:
            force_refresh: If True, bypass cache and download fresh data
            
        Returns:
            Path to the local data file
            
        Raises:
            RuntimeError: If data cannot be loaded from any source
        """
        # Check if cache is valid and fresh
        if not force_refresh and self._is_cache_valid():
            self.logger.info(f"✓ Using cached data: {self.CACHE_FILE}")
            return str(self.CACHE_FILE)
        
        # Cache is stale or doesn't exist - refresh from S3
        self.logger.info("Cache is stale or missing - refreshing from S3...")
        
        if self.s3_available:
            try:
                self._download_from_s3()
                return str(self.CACHE_FILE)
            except Exception as e:
                self.logger.error(f"Failed to download from S3: {e}")
                
                # If cache exists (even if stale), use it as fallback
                if self.CACHE_FILE.exists():
                    self.logger.warning("Using stale cache as fallback")
                    return str(self.CACHE_FILE)
                else:
                    raise RuntimeError(f"Cannot load data: S3 download failed and no cache available: {e}")
        else:
            # S3 not available - check if cache exists
            if self.CACHE_FILE.exists():
                self.logger.warning("S3 not available - using existing cache")
                return str(self.CACHE_FILE)
            else:
                raise RuntimeError("Cannot load data: S3 not available and no cache exists")
    
    def _is_cache_valid(self) -> bool:
        """
        Check if the cached data is valid and fresh.
        
        Returns:
            True if cache exists and is fresh, False otherwise
        """
        if not self.CACHE_FILE.exists() or not self.CACHE_METADATA_FILE.exists():
            return False
        
        try:
            with open(self.CACHE_METADATA_FILE, 'r') as f:
                metadata = json.load(f)
            
            cache_time = datetime.fromisoformat(metadata['cache_timestamp'])
            age_hours = (datetime.now() - cache_time).total_seconds() / 3600
            
            if age_hours < self.CACHE_TTL_HOURS:
                self.logger.info(f"Cache is fresh (age: {age_hours:.1f} hours)")
                return True
            else:
                self.logger.info(f"Cache is stale (age: {age_hours:.1f} hours, TTL: {self.CACHE_TTL_HOURS} hours)")
                return False
                
        except Exception as e:
            self.logger.warning(f"Error reading cache metadata: {e}")
            return False
    
    def _download_from_s3(self) -> None:
        """
        Download the EDF outage data from S3 and save to local cache.
        
        Raises:
            Exception: If download fails
        """
        start_time = time.time()
        self.logger.info(f"Downloading from S3: s3://{self.bucket_name}/{self.S3_FILE_KEY}")
        
        try:
            # Download the CSV file
            self.s3_client.download_file(
                self.bucket_name,
                self.S3_FILE_KEY,
                str(self.CACHE_FILE)
            )
            
            # Get S3 metadata
            s3_metadata = self._get_s3_metadata()
            
            # Save local cache metadata
            cache_metadata = {
                'cache_timestamp': datetime.now().isoformat(),
                's3_scrape_timestamp': s3_metadata.get('scrape_timestamp', 'unknown'),
                's3_file_size_mb': s3_metadata.get('file_size_mb', 0),
                'cache_file_size_bytes': self.CACHE_FILE.stat().st_size,
            }
            
            with open(self.CACHE_METADATA_FILE, 'w') as f:
                json.dump(cache_metadata, f, indent=2)
            
            elapsed = time.time() - start_time
            file_size_mb = self.CACHE_FILE.stat().st_size / (1024 * 1024)
            
            self.logger.info(f"✓ Downloaded from S3 in {elapsed:.1f}s ({file_size_mb:.1f} MB)")
            self.logger.info(f"  S3 scrape time: {s3_metadata.get('scrape_timestamp', 'unknown')}")
            
        except Exception as e:
            self.logger.error(f"S3 download failed: {e}")
            raise
    
    def _get_s3_metadata(self) -> Dict:
        """
        Get metadata about the S3 file (scrape timestamp, etc.)
        
        Returns:
            Dictionary with metadata, or empty dict if not available
        """
        try:
            # Download metadata JSON
            metadata_path = self.CACHE_DIR / "s3_metadata.json"
            self.s3_client.download_file(
                self.bucket_name,
                self.S3_METADATA_KEY,
                str(metadata_path)
            )
            
            with open(metadata_path, 'r') as f:
                return json.load(f)
                
        except Exception as e:
            self.logger.warning(f"Could not retrieve S3 metadata: {e}")
            return {}
    
    def get_cache_info(self) -> Dict:
        """
        Get information about the current cache state.
        
        Returns:
            Dictionary with cache information
        """
        info = {
            'cache_exists': self.CACHE_FILE.exists(),
            'cache_valid': self._is_cache_valid(),
            's3_available': self.s3_available,
        }
        
        if self.CACHE_FILE.exists():
            info['cache_size_mb'] = self.CACHE_FILE.stat().st_size / (1024 * 1024)
            info['cache_modified'] = datetime.fromtimestamp(
                self.CACHE_FILE.stat().st_mtime
            ).isoformat()
        
        if self.CACHE_METADATA_FILE.exists():
            try:
                with open(self.CACHE_METADATA_FILE, 'r') as f:
                    metadata = json.load(f)
                info.update(metadata)
            except Exception:
                pass
        
        return info
    
    def clear_cache(self) -> None:
        """Clear the local cache files."""
        try:
            if self.CACHE_FILE.exists():
                self.CACHE_FILE.unlink()
                self.logger.info(f"✓ Cleared cache file: {self.CACHE_FILE}")
            
            if self.CACHE_METADATA_FILE.exists():
                self.CACHE_METADATA_FILE.unlink()
                self.logger.info(f"✓ Cleared metadata file: {self.CACHE_METADATA_FILE}")
                
        except Exception as e:
            self.logger.error(f"Error clearing cache: {e}")


# Convenience function for simple usage
def load_edf_data(force_refresh: bool = False, logger: Optional[logging.Logger] = None) -> str:
    """
    Convenience function to load EDF data.
    
    Args:
        force_refresh: If True, bypass cache and download fresh data
        logger: Optional logger instance
        
    Returns:
        Path to the local data file
    """
    loader = EDFDataLoader(logger=logger)
    return loader.get_data_path(force_refresh=force_refresh)
