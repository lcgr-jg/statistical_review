import dash
from dash import dcc, html, Input, Output, State
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta, date
from functools import lru_cache
import os
import logging

from availability_model_class import AvailabilityModel
from data_utils.data_loader import EDFDataLoader
try:
    # Both standalone and portal: unit_delta lives in core/french_nuclear/.
    from core.french_nuclear import unit_delta as _unit_delta
except ImportError:
    _unit_delta = None  # noqa: F841 - tab will surface a clear error message

# -----------------------------------------------------------------------------
# Configuration & Setup
# -----------------------------------------------------------------------------

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# Skip data loading if we're in Flask's reloader parent process
is_main_process = os.environ.get('WERKZEUG_RUN_MAIN') == 'true' or os.environ.get('WERKZEUG_RUN_MAIN') is None

if is_main_process:
    logger.info("=" * 70)
    logger.info("FRENCH NUCLEAR AVAILABILITY DASHBOARD - STARTING")
    logger.info("=" * 70)
            
    # Load data from S3 (with local caching)
    # Note: data_loader is global so background refresh callback can access it
    try:
        data_loader = EDFDataLoader(logger=logger)
        
        # Show cache info
        cache_info = data_loader.get_cache_info()
        logger.info(f"Cache status: exists={cache_info.get('cache_exists')}, valid={cache_info.get('cache_valid')}")
            
        # Get data path (will use cache if fresh, otherwise download from S3)
        DATA_PATH = data_loader.get_data_path(force_refresh=False)
        
        logger.info(f"✓ Data loaded successfully: {DATA_PATH}")
        
    except Exception as e:
        logger.error(f"Failed to load data: {e}")
        raise RuntimeError(f"Cannot start dashboard: {e}")
else:
    # In reloader parent process, skip data loading
    logger.info("Skipping data load in reloader parent process...")
    DATA_PATH = None

TOTAL_CAPACITY_GW = 62.97  # French nuclear installed capacity

# Color Palette - Professional Light Theme (matching fuel_switch_dashboard)
COLORS = {
    'background': '#f5f6f8',         # Light gray page background (like fuel_switch)
    'card_bg': '#ffffff',            # White cards
    'chart_bg': '#faf9f6',           # Light beige/cream for chart backgrounds (distinguishes from white)
    'chart_paper': '#ffffff',        # White paper background around charts
    'border': '#e1e4e8',             # Subtle borders
    'text_primary': '#231F20',       # Black - primary text
    'text_secondary': '#323E48',     # Muted Blue - secondary text
    'text_muted': '#4E738A',         # Blue - muted text
    'accent': '#4E738A',             # Blue accent
    'accent_secondary': '#00875a',   # Success green
    'warning': '#d94f00',            # Deep orange
    'danger': '#f85149',             # Red
    'success': '#00875a',            # Green
}

# Initialize Model
if DATA_PATH is None:
    raise RuntimeError("DATA_PATH is None. This should not happen in the main process. Check download logic.")

if not os.path.exists(DATA_PATH):
    raise FileNotFoundError(f"Data file not found: {DATA_PATH}. Please ensure the download completed successfully.")

if is_main_process:
    print(f"Initializing AvailabilityModel with data file: {DATA_PATH}")
    try:
        model = AvailabilityModel(DATA_PATH)
        print("Model initialized successfully")
    except Exception as e:
        print(f"ERROR: Failed to initialize AvailabilityModel: {e}")
        import traceback
        traceback.print_exc()
        raise
else:
    # In reloader parent process, create a dummy model (will be recreated in child)
    model = None

# Date range constants
START_YEAR = datetime(2025, 1, 1)
END_YEAR = datetime(2026, 6, 30)
TODAY = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
DAYS_IN_RANGE = (END_YEAR - START_YEAR).days + 1
# Slider only goes up to today (or START_YEAR if today is before start)
DAYS_TO_TODAY = max(0, min((TODAY - START_YEAR).days, DAYS_IN_RANGE - 1))
# Slider start date: today - 30 days
SLIDER_START_DATE = TODAY - timedelta(days=30)
SLIDER_DAYS_RANGE = 30  # Slider shows 30 days (today - 30 to today)

# Default date range for charts: T-30 to T+60 days (as day offsets from START_YEAR)
DEFAULT_DATE_RANGE_START_OFFSET = max(0, (TODAY - timedelta(days=30) - START_YEAR).days)
DEFAULT_DATE_RANGE_END_OFFSET = min(DAYS_IN_RANGE - 1, (TODAY + timedelta(days=60) - START_YEAR).days)

# -----------------------------------------------------------------------------
# Pre-calculation / Caching
# -----------------------------------------------------------------------------
DATA_CACHE = {}

def precompute_data():
    """Pre-calculate availability for slider range (today - 30 days to today)."""
    print(f"Pre-computing availability data for slider range ({SLIDER_START_DATE.strftime('%Y-%m-%d')} to {TODAY.strftime('%Y-%m-%d')})...")
    
    # Calculate for slider range only (today - 30 days to today)
    computed_count = 0
    failed_count = 0
    
    for i in range(SLIDER_DAYS_RANGE + 1):
        as_of = SLIDER_START_DATE + timedelta(days=i)
        as_of_str = as_of.strftime("%Y-%m-%d")
        
        try:
            df_hourly = model.calculate_availability(
                as_of=as_of,
                start=START_YEAR,
                end=END_YEAR,
                freq="1h"
            )
            
            if len(df_hourly) == 0:
                print(f"  Warning: Empty result for {as_of_str}")
                DATA_CACHE[as_of_str] = pd.DataFrame()
                failed_count += 1
                continue
                
        except Exception as e:
            print(f"  Error calculating {as_of_str}: {e}")
            DATA_CACHE[as_of_str] = pd.DataFrame()
            failed_count += 1
            continue

        # Convert to daily by truncating to date and aggregating
        df_hourly = df_hourly.copy()
        df_hourly["date"] = pd.to_datetime(df_hourly["ts"]).dt.floor("D")
        df_daily = (
            df_hourly
            .groupby(["unit", "date"])
            .agg(
                p_avail_mean=("p_avail_mw", "mean"),
                capacity=("capacity_mw", "first")
            )
            .reset_index()
            .sort_values(["unit", "date"])
        )
        
        DATA_CACHE[as_of_str] = df_daily
        computed_count += 1
        
        if (i + 1) % 10 == 0:
            print(f"  Processed {i + 1}/{SLIDER_DAYS_RANGE + 1} days...")

    print(f"Pre-computation complete: {computed_count} successful, {failed_count} failed out of {SLIDER_DAYS_RANGE + 1} total dates.")

def get_daily_availability(as_of_date_str: str) -> pd.DataFrame:
    """Retrieve pre-calculated daily availability."""
    return DATA_CACHE.get(as_of_date_str, pd.DataFrame())

# Run pre-computation on startup (only in main process)
if is_main_process and model is not None:
    precompute_data()

# -----------------------------------------------------------------------------
# Dash App with Professional Styling
# -----------------------------------------------------------------------------
app = dash.Dash(
    __name__, 
    title="French Nuclear Availability",
    suppress_callback_exceptions=True,
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}]
)

# Get list of unique units for dropdown
unique_units = sorted(model.base_df["unit_name"].unique().tolist())

# Custom CSS for professional light theme (matching fuel_switch_dashboard)
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
                background-color: #f5f6f8;
                color: #231F20;
                font-size: 14px;
                -webkit-font-smoothing: antialiased;
            }
            .dashboard-container {
                max-width: 1800px;
                margin: 0 auto;
                padding: 20px;
            }
            .header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 16px 20px;
                background: #ffffff;
                border-bottom: 1px solid #e1e4e8;
                margin-bottom: 20px;
            }
            .header-title {
                font-size: 20px;
                font-weight: 600;
                color: #231F20;
                letter-spacing: -0.3px;
            }
            .header-subtitle {
                font-size: 13px;
                color: #323E48;
                margin-top: 4px;
            }
            .card {
                background: #ffffff;
                border: 1px solid #e1e4e8;
                border-radius: 8px;
                padding: 16px;
                margin-bottom: 16px;
            }
            .card-title {
                font-size: 12px;
                font-weight: 600;
                color: #323E48;
                text-transform: uppercase;
                letter-spacing: 0.8px;
                margin-bottom: 12px;
            }
            .controls-row {
                display: flex;
                align-items: center;
                gap: 16px;
                flex-wrap: wrap;
            }
            .control-group {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .control-label {
                font-size: 11px;
                font-weight: 600;
                color: #323E48;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            .btn {
                padding: 8px 16px;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s ease;
                border: 1px solid #e1e4e8;
                background: #ffffff;
                color: #231F20;
            }
            .btn:hover {
                background: #f5f6f8;
                border-color: #4E738A;
            }
            .btn-primary {
                background: #4E738A;
                border-color: #4E738A;
                color: #ffffff;
            }
            .btn-primary:hover {
                background: #323E48;
            }
            .status-indicator {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 6px 14px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 500;
                background: #e6f4ea;
                color: #1e7e34;
                border: 1px solid #c3e6cb;
            }
            .tab-container {
                margin-top: 16px;
            }
            
            /* Slider styling - muted blue */
            .rc-slider-track { background-color: #4E738A !important; }
            .rc-slider-handle { 
                border-color: #4E738A !important; 
                background-color: #ffffff !important;
                box-shadow: 0 1px 3px rgba(0,0,0,0.15) !important;
            }
            .rc-slider-rail { background-color: #dfe1e6 !important; }
            .rc-slider-mark-text { color: #323E48 !important; font-size: 11px !important; }
            
            /* Dropdown styling - clean light theme */
            .Select-control { 
                background-color: #ffffff !important; 
                border: 1px solid #dfe1e6 !important;
                border-radius: 4px !important;
                min-height: 36px !important;
            }
            .Select-control:hover {
                border-color: #4E738A !important;
            }
            .Select-menu-outer { 
                background-color: #ffffff !important; 
                border: 1px solid #dfe1e6 !important;
                border-radius: 4px !important;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
            }
            .Select-value-label { 
                color: #172b4d !important; 
                font-weight: 500 !important; 
                font-size: 13px !important;
            }
            .Select-placeholder { color: #6b778c !important; }
            .Select-menu { background-color: #ffffff !important; }
            .Select-option { 
                background-color: #ffffff !important; 
                color: #172b4d !important;
                padding: 8px 12px !important;
            }
            .Select-option.is-focused { background-color: #f4f5f7 !important; }
            .Select-option.is-selected { background-color: #e6f0ff !important; color: #4E738A !important; }
            .Select-arrow-zone { color: #6b778c !important; }
            .Select-input input { color: #172b4d !important; }
            
            /* Loading spinner */
            ._dash-loading { color: #4E738A !important; }
        </style>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# App Layout
app.layout = html.Div([
    # Header
    html.Div([
        html.Div([
            html.Div("French Nuclear Availability", className="header-title"),
            html.Div("Real-time outage tracking and availability forecasting", className="header-subtitle"),
        ]),
        html.Div([
            html.Span(id='current-date-badge', className="status-indicator"),
        ]),
    ], className="header"),
    
    # Main Content
    html.Div([
        dcc.Tabs(
            id="main-tabs",
            value='tab-availability',
            children=[
                dcc.Tab(
                    label='Availability Overview',
                    value='tab-availability',
                    style={'backgroundColor': '#ffffff', 'color': '#323E48', 'border': '1px solid #e1e4e8', 'borderRadius': '6px 6px 0 0', 'padding': '12px 24px'},
                    selected_style={'backgroundColor': '#f5f6f8', 'color': '#231F20', 'border': '1px solid #4E738A', 'borderBottom': 'none', 'borderRadius': '6px 6px 0 0', 'padding': '12px 24px', 'fontWeight': '600'},
                ),
                dcc.Tab(
                    label='Outage Explorer',
                    value='tab-outages',
                    style={'backgroundColor': '#ffffff', 'color': '#323E48', 'border': '1px solid #e1e4e8', 'borderRadius': '6px 6px 0 0', 'padding': '12px 24px'},
                    selected_style={'backgroundColor': '#f5f6f8', 'color': '#231F20', 'border': '1px solid #4E738A', 'borderBottom': 'none', 'borderRadius': '6px 6px 0 0', 'padding': '12px 24px', 'fontWeight': '600'},
                ),
                dcc.Tab(
                    label='Unit Δ vs Today',
                    value='tab-unit-delta',
                    style={'backgroundColor': '#ffffff', 'color': '#323E48', 'border': '1px solid #e1e4e8', 'borderRadius': '6px 6px 0 0', 'padding': '12px 24px'},
                    selected_style={'backgroundColor': '#f5f6f8', 'color': '#231F20', 'border': '1px solid #4E738A', 'borderBottom': 'none', 'borderRadius': '6px 6px 0 0', 'padding': '12px 24px', 'fontWeight': '600'},
                ),
            ],
            style={'marginBottom': '0'},
        ),
        
        html.Div(id='tab-content', className="card", style={'borderRadius': '0 0 8px 8px', 'marginTop': '0'}),
    ], className="dashboard-container"),
    
    # Hidden components
    dcc.Interval(id='interval-component', interval=1333, n_intervals=0, disabled=True),  # ~1.33 seconds per step (1.5x faster)
    dcc.Interval(id='data-refresh-interval', interval=6*60*60*1000, n_intervals=0),  # Check for data refresh every 6 hours
    dcc.Store(id='last-refresh-time', data={'timestamp': datetime.now().isoformat()}),
    
], style={'minHeight': '100vh', 'backgroundColor': '#f5f6f8'})


# -----------------------------------------------------------------------------
# Tab Content Callback
# -----------------------------------------------------------------------------
@app.callback(
    Output('tab-content', 'children'),
    Input('main-tabs', 'value')
)
def render_tab_content(tab):
    if tab == 'tab-availability':
        return html.Div([
            # Controls Row
            html.Div([
                html.Div([
                    html.Button('▶ Play', id='play-pause-button', n_clicks=0, className="btn btn-primary"),
                ], className="control-group"),
                
                html.Div([
                    html.Span("As-Of Date:", className="control-label"),
                    html.Div(id='selected-date-display', style={'color': '#4E738A', 'fontWeight': '600', 'fontSize': '14px'}),
                ], className="control-group"),
            ], className="controls-row", style={'marginBottom': '16px'}),
            
            # As-Of Date Slider (shows only last 30 days: today - 30 to today)
            html.Div([
            html.Div([
                    html.Span("As-Of Date Range:", className="control-label", style={'marginBottom': '8px', 'display': 'block'}),
                dcc.Slider(
                    min=0,
                        max=SLIDER_DAYS_RANGE,  # 0 = today - 30 days, 30 = today
                    step=1,
                        value=SLIDER_DAYS_RANGE,  # Default to today (day 30)
                    id='date-slider',
                        marks={i: {'label': (SLIDER_START_DATE + timedelta(days=i)).strftime('%b %d'), 'style': {'color': '#323E48'}} 
                               for i in range(0, SLIDER_DAYS_RANGE + 1, 5)},  # Mark every 5 days
                        tooltip={"placement": "bottom", "always_visible": True},
                ),
                ], style={'marginBottom': '24px'}),
                
                # Date Range Slider for Chart Display
                html.Div([
                    html.Div([
                        html.Span("Chart Date Range:", className="control-label", style={'marginBottom': '8px', 'display': 'block'}),
                        html.Div(id='date-range-display', style={'color': '#323E48', 'fontSize': '12px', 'marginBottom': '8px'}),
                        dcc.RangeSlider(
                            min=0,
                            max=DAYS_IN_RANGE - 1,
                            step=1,
                            value=[DEFAULT_DATE_RANGE_START_OFFSET, DEFAULT_DATE_RANGE_END_OFFSET],
                            id='date-range-slider',
                            marks={
                                i: {'label': (START_YEAR + timedelta(days=i)).strftime('%b %Y'), 'style': {'color': '#323E48', 'fontSize': '10px'}}
                                for i in range(0, DAYS_IN_RANGE, max(1, DAYS_IN_RANGE // 10))  # ~10 marks
                            },
                            tooltip={"placement": "bottom", "always_visible": False},
                        ),
                    ]),
                ], style={'padding': '0 20px', 'marginBottom': '24px'}),
            ], style={'padding': '0 20px', 'marginBottom': '24px'}),

            # Charts
            dcc.Graph(id='availability-line-chart', style={'height': '600px'}),
            dcc.Graph(id='availability-heatmap', style={'height': '1200px'}),
        ])
    
    elif tab == 'tab-outages':
        return html.Div([
            html.Div([
                html.Span("Select Plant:", className="control-label"),
                dcc.Dropdown(
                    id='plant-dropdown',
                    options=[{'label': u, 'value': u} for u in unique_units],
                    value=unique_units[0] if unique_units else None,
                    clearable=False,
                    style={'width': '300px', 'backgroundColor': '#21262d'},
                ),
            ], className="control-group", style={'marginBottom': '20px'}),
            
            html.Div(id='version-graphs-container', style={'maxHeight': '80vh', 'overflowY': 'auto'}),
])

    elif tab == 'tab-unit-delta':
        return html.Div([
            html.Div([
                html.Div([
                    html.Span("Forecast horizon (days):", className="control-label"),
                    dcc.Slider(
                        id='unit-delta-horizon',
                        min=14, max=180, step=7, value=90,
                        marks={d: str(d) for d in (14, 30, 60, 90, 120, 180)},
                        tooltip={"placement": "bottom", "always_visible": False},
                    ),
                ], style={'flex': '1 1 320px', 'minWidth': '280px', 'paddingRight': '20px'}),
                html.Div([
                    html.Span("Color by:", className="control-label"),
                    dcc.RadioItems(
                        id='unit-delta-color-by',
                        options=[
                            {'label': 'Reactor series (palier)', 'value': 'palier'},
                            {'label': 'Reactor unit', 'value': 'unit'},
                        ],
                        value='palier',
                        inline=True,
                        inputStyle={'marginRight': '4px'},
                        labelStyle={'marginRight': '12px', 'fontSize': '13px', 'color': '#323E48'},
                    ),
                ], style={'flex': '0 1 auto', 'paddingRight': '20px', 'alignSelf': 'center'}),
                html.Div([
                    html.Button('Refresh', id='unit-delta-refresh', n_clicks=0,
                                className="btn btn-primary",
                                style={'marginTop': '20px'}),
                ], style={'flex': '0 0 auto'}),
            ], className="controls-row",
               style={'display': 'flex', 'gap': '12px', 'flexWrap': 'wrap',
                      'alignItems': 'flex-end', 'padding': '0 20px', 'marginBottom': '16px'}),

            dcc.Loading(
                id='unit-delta-loading',
                type='circle',
                children=[
                    html.Div(id='unit-delta-info',
                             style={'padding': '0 20px', 'fontSize': '12px', 'color': '#323E48'}),
                    dcc.Graph(id='unit-delta-chart', style={'height': '600px'}),
                ],
            ),
        ])


# -----------------------------------------------------------------------------
# Availability Charts Callback
# -----------------------------------------------------------------------------
@app.callback(
    [Output('availability-heatmap', 'figure'),
     Output('availability-line-chart', 'figure'),
     Output('selected-date-display', 'children'),
     Output('current-date-badge', 'children'),
     Output('date-range-display', 'children')],
    [Input('date-slider', 'value'),
     Input('date-range-slider', 'value')]
)
def update_charts(day_offset, date_range):
    # Calculate Date from Slider Value
    # Slider value: 0 = today - 30 days, 30 = today
    # So: as_of_date = SLIDER_START_DATE + day_offset
    as_of_date = SLIDER_START_DATE + timedelta(days=int(day_offset))
    as_of_str = as_of_date.strftime("%Y-%m-%d")
    as_of_display = as_of_date.strftime("%d %b %Y")
    
    # Calculate x-axis display range from date range slider
    # date_range is [start_offset, end_offset] where offset is days from START_YEAR
    xaxis_start = START_YEAR + timedelta(days=int(date_range[0]))
    xaxis_end = START_YEAR + timedelta(days=int(date_range[1]))
    date_range_display = f"{xaxis_start.strftime('%d %b %Y')} to {xaxis_end.strftime('%d %b %Y')}"
    
    # Fetch Data for current date
    df = get_daily_availability(as_of_str)
    
    if len(df) == 0:
        empty_fig = go.Figure()
        empty_fig.update_layout(
            template='plotly_white',
            paper_bgcolor=COLORS['chart_paper'],
            plot_bgcolor=COLORS['chart_bg'],
            xaxis=dict(range=[xaxis_start, xaxis_end]),
            annotations=[dict(text="No data available", showarrow=False, font=dict(size=16, color='#323E48'))]
        )
        return empty_fig, empty_fig, as_of_display, f"📅 {as_of_display}", date_range_display

    df = df.sort_values(["unit", "date"])
    pdf = df  # Already pandas
    
    # Filter out decommissioned units (FESSENHEIM 1 and FESSENHEIM 2)
    decommissioned_units = ["FESSENHEIM 1", "FESSENHEIM 2"]
    pdf = pdf[~pdf["unit"].isin(decommissioned_units)]
    
    # --- Heatmap with Row-Normalized Color Scale ---
    pivot_df = pdf.pivot(index="unit", columns="date", values="p_avail_mean")
    
    # Normalize each row: 0 = offline, max = full availability
    row_max = pivot_df.max(axis=1)
    normalized_df = pivot_df.div(row_max, axis=0)  # Now 0-1 scale per row
    
    # Professional color palette (muted tones inspired by screenshots)
    soft_colorscale = [
        [0.0, '#de350b'],    # Red for offline
        [0.15, '#ff8c42'],   # Coral/orange
        [0.35, '#ffab00'],   # Amber
        [0.5, '#ffd666'],    # Light amber
        [0.65, '#79c0a3'],   # Soft teal green
        [0.85, '#5ba37f'],   # Medium green
        [1.0, '#36b37e'],    # Full green for full availability
    ]
    
    fig_heatmap = go.Figure(data=go.Heatmap(
        z=normalized_df.values,
        x=pivot_df.columns,
        y=pivot_df.index,
        colorscale=soft_colorscale,
        zmin=0,
        zmax=1,
        xgap=1,  # Small gap between cells for visual separation
        ygap=1,  # Small gap between rows
        customdata=pivot_df.values,  # Original MW values for hover
        hovertemplate='<b>%{y}</b><br>Date: %{x|%d %b %Y}<br>Availability: %{customdata:.0f} MW<extra></extra>',
        colorbar=dict(
            title=dict(text="Availability", font=dict(size=11, color='#323E48')),
            tickfont=dict(size=10, color='#323E48'),
            tickvals=[0, 0.5, 1],
            ticktext=['Offline', '50%', 'Full'],
            len=0.6,
        ),
    ))
    
    # Add vertical dotted line for as-of date
    fig_heatmap.add_vline(
        x=as_of_date,
        line_dash="dot",
        line_color="#ffffff",
        line_width=2,
        opacity=0.8,
    )
    
    # Add annotation for as-of date
    fig_heatmap.add_annotation(
        x=as_of_date,
        y=1.02,
        yref="paper",
        text=f"As-of: {as_of_display}",
        showarrow=False,
        font=dict(size=10, color='#ffffff'),
        bgcolor='#323E48',
        borderpad=4,
    )
    
    # Add vertical dotted lines for month boundaries
    month_starts = []
    current_month = START_YEAR.replace(day=1)
    while current_month <= END_YEAR:
        if current_month >= START_YEAR:
            month_starts.append(current_month)
        # Move to next month
        if current_month.month == 12:
            current_month = current_month.replace(year=current_month.year + 1, month=1)
        else:
            current_month = current_month.replace(month=current_month.month + 1)
    
    for month_start in month_starts:
        fig_heatmap.add_vline(
            x=month_start,
            line_dash="dot",
            line_color="#4a5568",
            line_width=1,
            opacity=0.5,
    )
    
    fig_heatmap.update_layout(
        title=dict(text="Unit-Level Availability", font=dict(size=14, color='#231F20'), x=0),
        template='plotly_white',
        paper_bgcolor=COLORS['chart_paper'],
        plot_bgcolor=COLORS['chart_bg'],  # Light beige background for heatmap
        margin=dict(l=130, r=20, t=50, b=50),
        xaxis=dict(
            tickformat="%b %d", 
            tickfont=dict(size=11, color='#231F20'), 
            gridcolor='#e1e4e8',
            showgrid=False,
            dtick="M1",  # Tick every month
            range=[xaxis_start, xaxis_end],  # Display range: today - 30 to today + 90 days
        ),
        yaxis=dict(
            tickfont=dict(size=10, color='#231F20'), 
            showgrid=False,
            autorange='reversed',
        ),
        font=dict(family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'),
    )
    
    # --- Line Chart with Last 14 As-Of Dates ---
    NUM_LOOKBACK_DAYS = 30
    fig_line = go.Figure()
    
    def get_line_style(idx, total):
        """Color and width gradient - older = faded, newer = bold"""
        opacity = 0.15 + (0.85 * idx / max(total - 1, 1))
        width = 0.8 + (2.2 * idx / max(total - 1, 1))
        # Magenta gradient
        intensity = int(100 + (155 * idx / max(total - 1, 1)))
        return f'rgba(255,{255-intensity},{200-int(intensity*0.5)},{opacity})', width
    
    # Collect data for last 30 as-of dates (within slider range)
    lookback_dates = []
    for i in range(NUM_LOOKBACK_DAYS):
        lookback_offset = day_offset - (NUM_LOOKBACK_DAYS - 1 - i)
        if lookback_offset >= 0 and lookback_offset <= SLIDER_DAYS_RANGE:
            lookback_as_of = SLIDER_START_DATE + timedelta(days=int(lookback_offset))
            lookback_dates.append(lookback_as_of)
    
    # Add traces for each as-of date
    for idx, lb_date in enumerate(lookback_dates):
        lb_str = lb_date.strftime("%Y-%m-%d")
        lb_df = get_daily_availability(lb_str)
        
        if len(lb_df) == 0:
            continue
        
        lb_pdf = lb_df  # Already pandas
        # Filter out decommissioned units
        lb_pdf = lb_pdf[~lb_pdf["unit"].isin(decommissioned_units)]
        agg_df = lb_pdf.groupby("date")["p_avail_mean"].sum().reset_index()
        agg_df = agg_df.sort_values("date")
        agg_df["p_avail_gw"] = agg_df["p_avail_mean"] / 1000
        
        color, width = get_line_style(idx, len(lookback_dates))
        is_current = (lb_str == as_of_str)
        
        fig_line.add_trace(go.Scatter(
            x=agg_df["date"],
            y=agg_df["p_avail_gw"],
            mode='lines',
            name='Forecast History' if is_current else '',
            line=dict(color=color, width=width),
            hovertemplate=f"As-of: {lb_str}<br>Date: %{{x|%d %b}}<br>Avail: %{{y:.1f}} GW<extra></extra>",
            showlegend=is_current,
        ))
    
    # Current as-of highlighted in yellow
    agg_current = pdf.groupby("date")["p_avail_mean"].sum().reset_index()
    agg_current["p_avail_gw"] = agg_current["p_avail_mean"] / 1000
    
    fig_line.add_trace(go.Scatter(
        x=agg_current["date"],
        y=agg_current["p_avail_gw"],
        mode='lines',
        name='Current',
        line=dict(color='#fbbf24', width=2.5),
        hovertemplate=f"Current: {as_of_str}<br>Date: %{{x|%d %b}}<br>Avail: %{{y:.1f}} GW<extra></extra>",
    ))
    
    # Capacity reference line
    fig_line.add_hline(
        y=TOTAL_CAPACITY_GW, 
        line_dash="dot", 
        line_color="#de350b", 
        opacity=0.6,
        annotation_text=f"Capacity ({TOTAL_CAPACITY_GW} GW)",
        annotation_position="top right",
        annotation_font=dict(size=11, color='#de350b'),
    )
    
    # Vertical as-of date indicator line
    fig_line.add_vline(
        x=as_of_date,
        line_dash="dot",
        line_color="#ffffff",
        line_width=2,
        opacity=0.7,
    )
    
    fig_line.update_layout(
        title=dict(
            text=f"French Nuclear Availability — As of {as_of_display}",
            font=dict(size=16, color='#231F20', family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'),
            x=0,
        ),
        template='plotly_white',
        paper_bgcolor=COLORS['chart_paper'],
        plot_bgcolor=COLORS['chart_bg'],  # Light beige background for chart area
        margin=dict(l=60, r=20, t=50, b=40),
        xaxis=dict(
            tickformat="%b %d",
            tickfont=dict(size=11, color='#323E48'),
            gridcolor='#eaeaea',
            showgrid=True,
            zeroline=False,
            range=[xaxis_start, xaxis_end],  # Display range: today - 30 to today + 90 days
        ),
        yaxis=dict(
            title=dict(text="Availability (GW)", font=dict(size=12, color='#323E48')),
            tickfont=dict(size=11, color='#323E48'),
            gridcolor='#eaeaea',
            showgrid=True,
            range=[0, 70],
            zeroline=False,
        ),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1,
            font=dict(size=11, color='#231F20'),
            bgcolor='rgba(250,249,246,0.95)',  # Semi-transparent beige matching chart background
        ),
        font=dict(family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'),
        hovermode='x unified',
    )
    
    return fig_heatmap, fig_line, as_of_display, f"📅 {as_of_display}", date_range_display


# -----------------------------------------------------------------------------
# Outage Version Explorer Callback
# -----------------------------------------------------------------------------
@app.callback(
    Output('version-graphs-container', 'children'),
    [Input('plant-dropdown', 'value')]
)
def update_version_chart(selected_unit):
    if not selected_unit:
        return [html.Div("Select a unit", style={'color': '#323E48', 'padding': '40px', 'textAlign': 'center'})]
        
    df = model.base_df[
        (model.base_df["unit_name"] == selected_unit) &
        (model.base_df["end"] >= START_YEAR) &
        (model.base_df["start"] <= END_YEAR)
    ]
    
    if len(df) == 0:
        return [html.Div(f"No outages found for {selected_unit}", style={'color': '#323E48', 'padding': '40px', 'textAlign': 'center'})]

    pdf_all = df[["identifiant", "version", "start", "end", "pavail_mw", "publication_ts", "type_norm", "info"]].sort_values(
        ["identifiant", "version"]
    )
    
    durations = pdf_all.groupby("identifiant").apply(
        lambda x: (x["end"].max() - x["start"].min())
    ).sort_values(ascending=False)
    
    sorted_identifiants = durations.index.tolist()
    pdf_all = pdf_all.copy()
    pdf_all["category"] = pdf_all["info"].apply(AvailabilityModel.classify_message)
    unique_categories = sorted(pdf_all["category"].unique())
    
    # Professional color palette (muted tones from screenshots)
    palette = ['#4E738A', '#de350b', '#36b37e', '#ff8c42', '#7A97AB', '#323E48', '#5ba37f', '#ffab00']
    category_color_map = {cat: palette[i % len(palette)] for i, cat in enumerate(unique_categories)}
    
    graphs = []
    
    for identifiant in sorted_identifiants:
        group = pdf_all[pdf_all["identifiant"] == identifiant].copy()
        is_forced = group["type_norm"].eq("Fortuite").any()
        title_prefix = "⚠️ FORCED — " if is_forced else ""
        
        group = group.sort_values("version", ascending=True)
        group["y_label"] = group["version"].apply(lambda v: f"v{v}")
        y_axis_order = group["y_label"].tolist()

        min_date = min(group["start"].min(), group["publication_ts"].min())
        max_date = max(group["end"].max(), group["publication_ts"].max())
        padding = timedelta(days=30)
        range_x = [min_date - padding, max_date + padding]

        fig = px.timeline(
            group,
            x_start="start",
            x_end="end",
            y="y_label",
            color="category",
            hover_data=["version", "pavail_mw", "publication_ts", "type_norm", "category"],
            height=180 + (len(group) * 40),
            category_orders={"y_label": y_axis_order},
            color_discrete_map=category_color_map
        )
        
        fig.add_trace(
            go.Scatter(
                x=group["publication_ts"],
                y=group["y_label"],
                mode='markers',
                marker=dict(color='#de350b', size=8, symbol='circle'),
                name='Publication',
                hovertemplate='Published: %{x}<extra></extra>',
                showlegend=True
            )
        )
        
        fig.update_yaxes(autorange="reversed", title="")
        fig.update_xaxes(range=range_x, title="")
        
        fig.update_layout(
            title=dict(
                text=f"{title_prefix}Outage: {identifiant}",
                font=dict(size=13, color='#231F20'),
                x=0,
            ),
            template='plotly_white',
            paper_bgcolor=COLORS['chart_paper'],
            plot_bgcolor=COLORS['chart_bg'],  # Light beige background for outage charts
            margin=dict(l=60, r=20, t=40, b=30),
            xaxis=dict(tickfont=dict(size=10, color='#323E48'), gridcolor='#eaeaea'),
            yaxis=dict(tickfont=dict(size=10, color='#323E48'), gridcolor='#eaeaea'),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1,
                font=dict(size=10, color='#323E48'),
                bgcolor='rgba(250,249,246,0.95)',  # Semi-transparent beige matching chart background
            ),
            font=dict(family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'),
        )
        
        graphs.append(dcc.Graph(figure=fig, style={'marginBottom': '16px'}))

    return graphs


# -----------------------------------------------------------------------------
# Unit Delta vs Today (per-unit availability)
# -----------------------------------------------------------------------------
@app.callback(
    [Output('unit-delta-chart', 'figure'),
     Output('unit-delta-info', 'children')],
    [Input('unit-delta-refresh', 'n_clicks'),
     Input('unit-delta-horizon', 'value'),
     Input('unit-delta-color-by', 'value'),
     Input('main-tabs', 'value')],
)
def update_unit_delta(_n_clicks, horizon_days, color_by, current_tab):
    """Render the per-unit availability delta vs today, stacked by palier."""
    if current_tab != 'tab-unit-delta':
        # Return empty fig to avoid recomputing on other tabs (Dash will discard).
        return go.Figure(), ""

    horizon = int(horizon_days) if horizon_days else 90
    today = datetime.now().date()
    # Pull a small history window so we have a "today" baseline even if the
    # cache hasn't been updated for the literal current calendar day.
    start = today - timedelta(days=14)
    end = today + timedelta(days=horizon + 1)

    try:
        daily = _unit_delta.load_fr_nuclear_per_unit_daily(start, end, zone="FR")
    except Exception as exc:
        logger.exception("Failed to load FR per-unit availability: %s", exc)
        return go.Figure(), html.Div(
            f"Error loading per-unit availability: {exc}",
            style={'color': '#de350b'},
        )

    if daily is None or daily.empty:
        return go.Figure(), html.Div(
            "No FR per-unit nuclear availability returned from corelib cache "
            "(jain_commods.core.cache.data.fundamentals.GenAvailPerUnitNuclear).",
            style={'color': '#de350b'},
        )

    delta_wide, baseline = _unit_delta.compute_delta_vs_today(
        daily, today=today, forecast_days=horizon,
    )
    if delta_wide is None or delta_wide.empty:
        return go.Figure(), html.Div(
            "Cache loaded but no forward data after today — check cache freshness.",
            style={'color': '#d94f00'},
        )

    fig = _unit_delta.build_delta_figure(
        delta_wide,
        today=today,
        color_by=color_by or 'palier',
    )

    n_units = int(delta_wide.shape[1])
    base_total = float(baseline.sum()) if baseline is not None and not baseline.empty else float("nan")
    info = html.Div([
        html.Span(f"Today's baseline ({today:%d-%b-%Y}): {base_total:,.0f} MW across {n_units} units · ",
                  style={'fontWeight': '600'}),
        html.Span(f"horizon: {delta_wide.index.min():%d-%b} → {delta_wide.index.max():%d-%b} "
                  f"({len(delta_wide)} days)"),
    ])
    return fig, info


# -----------------------------------------------------------------------------
# Animation Callbacks
# -----------------------------------------------------------------------------
@app.callback(
    [Output('interval-component', 'disabled'),
     Output('play-pause-button', 'children')],
    [Input('play-pause-button', 'n_clicks')],
    [State('interval-component', 'disabled')]
)
def toggle_interval(n_clicks, disabled):
    if n_clicks:
        return not disabled, "⏸ Pause" if disabled else "▶ Play"
    return True, "▶ Play"


@app.callback(
    Output('date-slider', 'value'),
    [Input('interval-component', 'n_intervals')],
    [State('date-slider', 'value')]
)
def advance_slider(n_intervals, current_value):
    if current_value is None:
        return SLIDER_DAYS_RANGE  # Default to today
    if current_value < SLIDER_DAYS_RANGE:  # Stop at today (end of slider range)
        return current_value + 1
    return 0  # Loop back to start


# -----------------------------------------------------------------------------
# Background Data Refresh
# -----------------------------------------------------------------------------
@app.callback(
    Output('last-refresh-time', 'data'),
    [Input('data-refresh-interval', 'n_intervals')],
    [State('last-refresh-time', 'data')]
)
def refresh_data_in_background(n_intervals, last_refresh_data):
    """
    Periodically check if data needs refreshing from S3.
    
    This runs every 6 hours and checks if the cache is stale.
    If stale, it triggers a refresh from S3 in the background.
    
    Note: This doesn't reload the entire dashboard, just refreshes the cache.
    The dashboard will use the new data on the next user interaction.
    """
    if n_intervals == 0:
        # First load - don't refresh
        return last_refresh_data
    
    try:
        logger.info("Background data refresh check triggered...")
        
        # Check if cache needs refresh
        cache_info = data_loader.get_cache_info()
        
        if not cache_info.get('cache_valid', False):
            logger.info("Cache is stale - triggering background refresh from S3...")
            
            # Refresh data from S3 (this updates the cache file)
            new_data_path = data_loader.get_data_path(force_refresh=True)
            
            logger.info(f"✓ Background refresh complete: {new_data_path}")
            
            return {'timestamp': datetime.now().isoformat(), 'status': 'refreshed'}
        else:
            logger.info("Cache is still fresh - no refresh needed")
            return {'timestamp': last_refresh_data.get('timestamp'), 'status': 'fresh'}
            
    except Exception as e:
        logger.error(f"Background refresh failed: {e}")
        return {'timestamp': last_refresh_data.get('timestamp'), 'status': 'error', 'error': str(e)}


# -----------------------------------------------------------------------------
# Run Server
# -----------------------------------------------------------------------------
if __name__ == '__main__':
    # Port can be configured via environment variable (for run_all_local.py)
    port = int(os.environ.get('DASH_PORT', 9007))
    app.run(debug=False, port=port)
