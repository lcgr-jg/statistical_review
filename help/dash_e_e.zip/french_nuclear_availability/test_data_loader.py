"""
Quick test script to verify the data loader works correctly.
"""

import sys
import logging
from data_utils.data_loader import EDFDataLoader

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

def main():
    logger.info("=" * 70)
    logger.info("TESTING EDF DATA LOADER")
    logger.info("=" * 70)
    
    try:
        # Initialize data loader
        loader = EDFDataLoader(logger=logger)
        
        # Show cache info
        logger.info("\n--- Cache Info ---")
        cache_info = loader.get_cache_info()
        for key, value in cache_info.items():
            logger.info(f"  {key}: {value}")
        
        # Get data path (will download from S3 if needed)
        logger.info("\n--- Loading Data ---")
        data_path = loader.get_data_path(force_refresh=False)
        
        logger.info(f"\n✓ SUCCESS: Data available at: {data_path}")
        
        # Try loading with AvailabilityModel
        logger.info("\n--- Testing AvailabilityModel Integration ---")
        from availability_model_class import AvailabilityModel
        
        model = AvailabilityModel(data_path)
        logger.info(f"✓ AvailabilityModel initialized successfully")
        logger.info(f"  Data shape: {model.df_outages.shape if hasattr(model, 'df_outages') else 'N/A'}")
        
        logger.info("\n" + "=" * 70)
        logger.info("✓ ALL TESTS PASSED")
        logger.info("=" * 70)
        
        return 0
        
    except Exception as e:
        logger.error(f"\n✗ TEST FAILED: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return 1

if __name__ == "__main__":
    sys.exit(main())
