/*
 * fastcharts.js
 * ==============
 * Tiny client-side figure cache.  It does two things:
 *
 *   1. Exposes `window.fastCharts.get(key) / .set(key, fig)` — a dead-simple
 *      sessionStorage-backed cache that pages (or clientside callbacks) can
 *      use to short-circuit another server round-trip when a user navigates
 *      back to a page they've already visited in the same tab.
 *
 *   2. When `<body>` first loads it kicks off a *prefetch* of every key
 *      listed in `window.__FAST_PREFETCH_KEYS` (the portal app injects this
 *      list into the page at render time).  Figures are fetched in the
 *      background via `/api/fig/<key>` so they are already sitting in the
 *      HTTP cache by the time the user clicks the relevant nav item.
 *
 * Storage shape:
 *     sessionStorage["fastchart:" + key] = JSON.stringify({ t: epoch, fig })
 *
 * A 5-minute TTL and 8 MB cap keep it bounded.
 */
(function () {
    "use strict";

    var PREFIX = "fastchart:";
    var TTL_MS = 5 * 60 * 1000;       // 5 minutes
    var MAX_BYTES = 8 * 1024 * 1024;  // ~8 MB total

    function _now() { return Date.now(); }

    function _size() {
        var total = 0;
        for (var i = 0; i < sessionStorage.length; i++) {
            var k = sessionStorage.key(i);
            if (k && k.indexOf(PREFIX) === 0) {
                total += (sessionStorage.getItem(k) || "").length;
            }
        }
        return total;
    }

    function _evictOldest() {
        var oldest = null, oldestTs = Infinity;
        for (var i = 0; i < sessionStorage.length; i++) {
            var k = sessionStorage.key(i);
            if (!k || k.indexOf(PREFIX) !== 0) continue;
            try {
                var rec = JSON.parse(sessionStorage.getItem(k));
                if (rec && rec.t < oldestTs) { oldestTs = rec.t; oldest = k; }
            } catch (e) { sessionStorage.removeItem(k); }
        }
        if (oldest) sessionStorage.removeItem(oldest);
    }

    var api = {
        get: function (key) {
            try {
                var raw = sessionStorage.getItem(PREFIX + key);
                if (!raw) return null;
                var rec = JSON.parse(raw);
                if (!rec || !rec.fig) return null;
                if (_now() - rec.t > TTL_MS) {
                    sessionStorage.removeItem(PREFIX + key);
                    return null;
                }
                return rec.fig;
            } catch (e) { return null; }
        },

        set: function (key, fig) {
            try {
                while (_size() > MAX_BYTES) _evictOldest();
                var payload = JSON.stringify({ t: _now(), fig: fig });
                sessionStorage.setItem(PREFIX + key, payload);
            } catch (e) {
                // Quota error — drop a few old entries and give up silently.
                try { _evictOldest(); _evictOldest(); } catch (ee) { /* noop */ }
            }
        },

        clear: function () {
            var toRemove = [];
            for (var i = 0; i < sessionStorage.length; i++) {
                var k = sessionStorage.key(i);
                if (k && k.indexOf(PREFIX) === 0) toRemove.push(k);
            }
            toRemove.forEach(function (k) { sessionStorage.removeItem(k); });
        },

        /**
         * Fetch a figure via /api/fig/<key>.  Uses session cache first, then
         * hits the network.  Returns a Plotly figure object (plain JSON).
         */
        fetch: function (key) {
            var cached = api.get(key);
            if (cached) return Promise.resolve(cached);
            return fetch("/api/fig/" + encodeURIComponent(key), {
                credentials: "same-origin"
            }).then(function (r) {
                if (!r.ok) throw new Error("fig " + key + " not ready: " + r.status);
                return r.json();
            }).then(function (fig) {
                api.set(key, fig);
                return fig;
            });
        },

        /**
         * Best-effort background prefetch.  Errors are swallowed so a missing
         * figure never breaks page navigation.
         */
        prefetch: function (keys) {
            if (!keys || !keys.length) return;
            keys.forEach(function (k) {
                api.fetch(k).catch(function () { /* ignore */ });
            });
        }
    };

    window.fastCharts = api;

    /**
     * Ask the server for the list of currently-cached figure keys and
     * prefetch them.  Swallows all errors — a missing endpoint just means
     * the feature is disabled.
     */
    function autoPrefetch() {
        // Honour an optional pre-injected list first (fast-path on page one).
        var inline = window.__FAST_PREFETCH_KEYS || [];
        if (inline.length) api.prefetch(inline);

        // Then hit /api/fig-keys for the authoritative list.  We delay this
        // a little so we don't compete with the initial Dash render.
        setTimeout(function () {
            fetch("/api/fig-keys", { credentials: "same-origin" })
                .then(function (r) { return r.ok ? r.json() : []; })
                .then(function (keys) { api.prefetch(keys || []); })
                .catch(function () { /* ignore */ });
        }, 1500);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", autoPrefetch);
    } else {
        autoPrefetch();
    }
})();
