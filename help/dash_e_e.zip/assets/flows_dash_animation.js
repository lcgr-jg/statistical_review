/* Animated dash-flow for Cytoscape edges on the Flows dashboard.
 *
 * Decrements `line-dash-offset` on every visible edge each animation frame so
 * the dashed line pattern appears to flow from source to target.  Negative
 * offset makes the dashes move toward the target end (i.e. "flow direction").
 *
 * The script is auto-loaded by Dash because it lives in `/assets/`.  It
 * attaches to the Cytoscape graph instances `flows-graph-flow` and
 * `flows-graph-spread` once they appear in the DOM, and uses a single
 * requestAnimationFrame loop guarded by a window-level flag to avoid
 * duplicate timers on hot reload.
 */
(function () {
  if (window.__flowsDashAnimationInstalled) {
    return;
  }
  window.__flowsDashAnimationInstalled = true;

  var GRAPH_IDS = ["flows-graph-flow", "flows-graph-spread"];
  var DASH_LEN = 10;   // matches `line-dash-pattern` first value in stylesheet
  var GAP_LEN = 6;     // matches second value
  var CYCLE = DASH_LEN + GAP_LEN;
  var SPEED_DIVISOR = 55;   // smaller = faster.  ~55 yields a calm pace.

  function findCy(id) {
    var node = document.getElementById(id);
    if (!node) return null;
    // dash_cytoscape attaches the Cytoscape instance to the wrapper div as
    // `_cyreg.cy`.  Walk up a couple of levels in case React inserted a
    // wrapper.  Fallback: scan children.
    if (node._cyreg && node._cyreg.cy) return node._cyreg.cy;
    var inner = node.querySelector("[data-id]");
    if (inner && inner._cyreg && inner._cyreg.cy) return inner._cyreg.cy;
    // dash_cytoscape ≥ 0.3 stores cy on a child div with class .__________cytoscape_container
    var container = node.querySelector(".__________cytoscape_container") ||
                    node.querySelector("[class*='cytoscape']");
    if (container && container._cyreg && container._cyreg.cy) return container._cyreg.cy;
    return null;
  }

  function applyOffset(cy, offset) {
    if (!cy) return;
    try {
      cy.batch(function () {
        cy.edges().style("line-dash-offset", offset);
      });
    } catch (e) { /* swallow; cy may be mid-update */ }
  }

  function tick() {
    var offset = -((Date.now() / SPEED_DIVISOR) % CYCLE);
    GRAPH_IDS.forEach(function (id) {
      var cy = findCy(id);
      if (cy) applyOffset(cy, offset);
    });
    window.requestAnimationFrame(tick);
  }

  // Kick off once the page is ready.  RAF will simply no-op until the
  // Cytoscape instances mount.
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      window.requestAnimationFrame(tick);
    });
  } else {
    window.requestAnimationFrame(tick);
  }
})();
