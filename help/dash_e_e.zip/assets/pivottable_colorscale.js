/**
 * Custom color scale override for dash-pivottable heatmaps.
 *
 * Replaces the default red-only heatmap with a diverging Red-White-Green scale:
 *   - Negative values → Red  (intensity relative to column max-abs)
 *   - Zero / null    → White
 *   - Positive values → Green (intensity relative to column max-abs)
 *
 * Approach: compute colors directly from cell numeric values so there is no
 * dependency on react-pivottable having already painted its own heatmap first.
 * This eliminates the race condition that caused the colormap to disappear on
 * reload (reference-date changes).
 */

(function () {
    'use strict';

    // -- Color endpoints --------------------------------------------------
    var RED_FULL   = [215, 48,  39];   // #d73027
    var GREEN_FULL = [26,  152, 80];   // #1a9850
    var WHITE      = [255, 255, 255];

    function lerp(a, b, t) {
        return Math.round(a + (b - a) * t);
    }

    function makeRgb(from, to, intensity) {
        return 'rgb(' +
            lerp(WHITE[0], from[0] === to[0] ? to[0] : (intensity >= 0 ? to[0] : from[0]), Math.abs(intensity)) + ',' +
            lerp(WHITE[1], from[1] === to[1] ? to[1] : (intensity >= 0 ? to[1] : from[1]), Math.abs(intensity)) + ',' +
            lerp(WHITE[2], from[2] === to[2] ? to[2] : (intensity >= 0 ? to[2] : from[2]), Math.abs(intensity)) +
        ')';
    }

    function colorForValue(value, maxAbs) {
        if (isNaN(value) || maxAbs === 0) return 'rgb(255,255,255)';
        var intensity = Math.min(Math.abs(value) / maxAbs, 1);
        if (value > 0) {
            var r = lerp(WHITE[0], GREEN_FULL[0], intensity);
            var g = lerp(WHITE[1], GREEN_FULL[1], intensity);
            var b = lerp(WHITE[2], GREEN_FULL[2], intensity);
        } else if (value < 0) {
            var r = lerp(WHITE[0], RED_FULL[0], intensity);
            var g = lerp(WHITE[1], RED_FULL[1], intensity);
            var b = lerp(WHITE[2], RED_FULL[2], intensity);
        } else {
            return 'rgb(255,255,255)';
        }
        return 'rgb(' + r + ',' + g + ',' + b + ')';
    }

    // ---------------------------------------------------------------------

    var isProcessing = false;

    /**
     * Recolor all heatmap cells using a diverging Red-White-Green scale.
     * Colors are computed directly from cell numeric values — no dependency
     * on react-pivottable's own heatmap colors.
     */
    function recolorHeatmapCells() {
        if (isProcessing) return;
        isProcessing = true;

        try {
            var tables = document.querySelectorAll('.pvtTable');
            if (!tables.length) return;

            tables.forEach(function (table) {
                // Gather all data cells grouped by column index
                var colValues = {};   // colIdx → array of parsed numbers
                var cellMap   = [];   // [{cell, colIdx, value}]

                var rows = table.querySelectorAll('tr');
                rows.forEach(function (row) {
                    var colIdx = 0;
                    row.querySelectorAll('td.pvtVal, td.pvtTotal').forEach(function (cell) {
                        // Advance colIdx past row-header cells at the front
                        // (pvtRowLabel cells precede pvtVal cells in the DOM)
                        var raw = cell.textContent.trim().replace(/,/g, '');
                        var value = parseFloat(raw);

                        if (!isNaN(value)) {
                            if (!colValues[colIdx]) colValues[colIdx] = [];
                            colValues[colIdx].push(Math.abs(value));
                            cellMap.push({ cell: cell, colIdx: colIdx, value: value });
                        }
                        colIdx++;
                    });
                });

                // Compute max-abs per column for intensity scaling
                var colMaxAbs = {};
                Object.keys(colValues).forEach(function (idx) {
                    colMaxAbs[idx] = Math.max.apply(null, colValues[idx]);
                });

                // Apply colors
                cellMap.forEach(function (entry) {
                    var maxAbs = colMaxAbs[entry.colIdx] || 0;
                    entry.cell.style.backgroundColor = colorForValue(entry.value, maxAbs);
                });
            });

        } finally {
            isProcessing = false;
        }
    }

    // ---- Monitoring -----------------------------------------------------

    function setupMutationObserver() {
        var debounceTimer = null;

        var observer = new MutationObserver(function (mutations) {
            var hasNewNodes = mutations.some(function (m) { return m.addedNodes.length > 0; });

            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(recolorHeatmapCells, 50);

            // When new pivot nodes are injected, schedule generous retries so
            // we catch react-pivottable finishing its own render cycle.
            if (hasNewNodes) {
                setTimeout(recolorHeatmapCells, 200);
                setTimeout(recolorHeatmapCells, 500);
                setTimeout(recolorHeatmapCells, 1000);
            }
        });

        observer.observe(document.body, {
            childList:  true,
            subtree:    true,
            attributes: true,
            attributeFilter: ['style', 'class'],
        });
    }

    function setupContinuousMonitoring() {
        var lastCheck = 0;
        var checkInterval = 200;

        function check(timestamp) {
            if (timestamp - lastCheck >= checkInterval) {
                recolorHeatmapCells();
                lastCheck = timestamp;
            }
            requestAnimationFrame(check);
        }

        requestAnimationFrame(check);
    }

    function init() {
        setupMutationObserver();
        setupContinuousMonitoring();

        recolorHeatmapCells();
        setTimeout(recolorHeatmapCells, 100);
        setTimeout(recolorHeatmapCells, 500);
        setTimeout(recolorHeatmapCells, 1000);
        setTimeout(recolorHeatmapCells, 2000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
