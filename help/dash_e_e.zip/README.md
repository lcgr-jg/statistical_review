# EU Dashboard Power

Dash-based EU power/commodities portal run with Docker Compose.

## Server deployment (step-by-step)

1. Clone and enter the repo on the Linux server.

```bash
cd ~
git clone <AZURE_DEVOPS_REPO_URL> dashboard
cd dashboard
```

2. Configure production environment in `deploy/prod.env`.

```bash
nano deploy/prod.env
```

Set at least:

```env
# App runtime
DASH_ENV=prod
PORT=8071
HOST=0.0.0.0
DASH_DEBUG=0
PYTHONUNBUFFERED=1
FLASK_SECRET_KEY=<long-random-secret>
DASH_LOGIN_USERS=admin:<strong-password>
DASH_REMEMBER_DAYS=14
COOKIE_SECURE=0
DASH_AUTH_ALLOW_EMPTY_IN_PROD=0
```

3. Start the app with production compose.

> **Note:** This server has `docker-compose` v1 (hyphenated) at
> `~/.local/bin/docker-compose`. Use `docker-compose`, **not** `docker compose`.

```bash
docker-compose --env-file=deploy/prod.env -f deploy/production.yaml up -d --build
docker-compose --env-file=deploy/prod.env -f deploy/production.yaml ps
docker-compose --env-file=deploy/prod.env -f deploy/production.yaml logs -f --tail=200
```

4. Verify health and login endpoint.

```bash
curl -i http://127.0.0.1:8071/api/live
curl -i http://127.0.0.1:8071/api/health
curl -i http://127.0.0.1:8071/login
```

5. Configure custom internal URL in nginx.

```bash
bash deploy/install_nginx.sh power-dashboard.jainglobal.internal 8071
sudo nginx -t
sudo systemctl reload nginx
```

Where this URL is defined:
- `deploy/nginx-eu-dashboard.conf.template`
- `server_name __SERVER_NAME__;`
- `proxy_pass http://127.0.0.1:__APP_PORT__;`

6. Validate through custom internal URL.

```bash
curl -i http://power-dashboard.jainglobal.internal/login
```

## Updates

### Recommended: use the deploy script

From your laptop in the repo root:

```powershell
# Windows (PowerShell) — deploy main branch:
.\scripts\deploy-dashboard.ps1

# Windows — deploy current dev branch directly (skip main merge):
.\scripts\deploy-dashboard.ps1 -Direct
```

```bash
# Linux / macOS / Git Bash:
./scripts/deploy-dashboard.sh          # standard main-branch deploy
./scripts/deploy-dashboard.sh --direct # direct dev-branch deploy
```

The script pushes the branch, SSH's to `10.115.0.70`, hard-resets the
checkout, rebuilds, restarts, and health-checks the container.

### Manual update on the server

```bash
cd ~/eu_dashboard_power
git fetch origin mk_dev
git reset --hard origin/mk_dev   # hard reset, don't pull — server shouldn't accumulate local commits
docker-compose --env-file=deploy/prod.env -f deploy/production.yaml build dashboard
docker-compose --env-file=deploy/prod.env -f deploy/production.yaml up -d --force-recreate dashboard
curl -fsS http://127.0.0.1:8071/api/live && echo
```

## Package installation strategy (important)

The prod server (`10.115.0.70`) has an **egress firewall** that blocks outbound
HTTPS to `*.blob.core.windows.net`. Because Azure DevOps Artifacts (`pkgs.dev.azure.com`)
redirects every wheel download through Azure Blob Storage, **no pip package
can be installed from the Azure `JGCommodities` feed at Docker build time**.

The container therefore installs Python packages from two places — both
reachable from the server:

| Package | Source | Why |
|---|---|---|
| `jain_commods` | Pre-downloaded wheel in `wheels/` | Only published on Azure DevOps → Azure Blob download would fail |
| `blpapi` (transitive) | Artifactory `pypi/blpapi/simple` | Not on public PyPI; internal Artifactory mirrors Bloomberg's repo |
| Everything else (`dash`, `pandas`, etc.) | Artifactory `pypi/pypi/simple` | Internal PyPI mirror, bypasses Azure infra |

The Dockerfile hard-codes these as `ENV PIP_*` vars so `pip` uses them on
every invocation:

```
PIP_INDEX_URL=https://artifactory.tech1ci.jainglobal.net/artifactory/api/pypi/pypi/simple
PIP_EXTRA_INDEX_URL=https://artifactory.tech1ci.jainglobal.net/artifactory/api/pypi/blpapi/simple
PIP_TRUSTED_HOST=artifactory.tech1ci.jainglobal.net
```

`PIP_TRUSTED_HOST` is required because Artifactory serves a **self-signed
(internal corporate CA) certificate** that the slim base image doesn't trust.

### Snowflake credentials (`deploy/jain_commods_login.py`)

The price dashboard's data loader uses `jain_commods.EEXQuery()`, which needs
Snowflake credentials. `jain_commods` resolves them like this
(`jain_commods/core/interfaces/snowflake/_credentials.py`):

```python
try:
    from ....login import snowflake_login   # jain_commods/login.py
except Exception:
    snowflake_login = {'account': os.getenv('SNOWFLAKE_ACCOUNT'), ...}
```

The CI-built `jain_commods` wheel on Artifactory does **not** ship
`login.py` (it's gitignored in `eu_corelib`), so the first import fails
and the fallback to env vars runs. If `SNOWFLAKE_ACCOUNT` isn't set, the
connector blows up deep inside `snowflake.connector` with:

```
AttributeError: 'NoneType' object has no attribute 'find'
```

To make this work permanently without per-server env var edits, the
Dockerfile **injects `deploy/jain_commods_login.py` into the installed
`jain_commods` package** after `pip install`. The file is committed to this
repo, so every `git pull` and every Docker build picks it up automatically.

If credentials ever change, edit `deploy/jain_commods_login.py`, commit,
push, and redeploy. No env vars, no server-side config.

### Updating `jain_commods`

The prod Docker build **cannot** download `jain_commods` (Azure Artifacts is
blocked). `pip install .` only succeeds if `wheels/jain_commods-<ver>-*.whl`
already matches the pin in `pyproject.toml`. Bumping the pin without
replacing the wheel will fail at `Collecting jain_commods==…`.
`scripts/deploy-dashboard.ps1` refuses to start if they disagree.

Pin and wheel must land in the **same commit**.

```bash
# On your laptop (which CAN reach Azure Blob Storage):
pip download --no-deps -d wheels/ \
    --index-url "https://<AZURE_PAT>@pkgs.dev.azure.com/JainGlobal/Commodities%20Research/_packaging/JGCommodities/pypi/simple/" \
    --extra-index-url https://pypi.org/simple/ \
    jain_commods==<new-version>

# Remove the old wheel so Docker doesn't ship both:
git rm wheels/jain_commods-<old-version>-py3-none-any.whl

# Update pyproject.toml to the same version, then:
git add wheels/jain_commods-<new-version>-py3-none-any.whl pyproject.toml
git commit -m "bump jain_commods to <new-version>"
git push origin mk_dev
# and deploy (see above).
```

### If the firewall is later opened

If IT whitelists `*.blob.core.windows.net` from `10.115.0.70`, you can drop
the local-wheel workaround entirely:

1. Delete the `wheels/` directory and its entry in `.gitignore`
2. Revert the Dockerfile to install `jain_commods` via pip from the Azure feed
3. Add `PIP_INDEX_URL=<azure-feed-url-with-pat>` to build args

Until then, the current setup is the only working approach.

## Performance layer

Charts used to be slow because figure JSON was rebuilt on every page view,
shipped uncompressed, and Plotly.js was re-downloaded each time.  The portal
now has a lightweight performance stack that fixes all three:

| Layer                      | What it does                                                                 | Files |
|----------------------------|------------------------------------------------------------------------------|-------|
| `core/fast_cache.py`       | In-memory cache of **pre-serialised** figure JSON bytes (50 ms lookups).     | `FigureCache` |
| `core/figure_registry.py`  | Registry of "default view" builders; pre-warms at startup and on refresh.    | `figure_registry` |
| `core/web_perf.py`         | Gzip compression + `Cache-Control: immutable` on Plotly.js bundles + `/api/fig/*` endpoint. | `attach_performance_layer` |
| `assets/fastcharts.js`     | Client-side sessionStorage cache + background prefetch of known figures.    | `window.fastCharts` |

### Adding a pre-warmed figure for a new page

Inside `portal_app.py`, in the function `_register_default_figures`, register
a builder whose output is cached as JSON bytes:

```python
def _build_my_page_default():
    from pages.my_page import market_cache, build_chart
    if not market_cache.ready():
        return None
    return build_chart(zone="DE", range="6M")   # a Plotly Figure

figure_registry.register(
    key="my_page:DE:6M:default",
    builder=_build_my_page_default,
    sources=["my_page_data"],          # rebuild when this source refreshes
    ttl=3600,
)
```

Then, in the page's main Dash callback, return the pre-built figure whenever
the user's inputs match the defaults:

```python
from core.fast_cache import figure_cache

prebuilt = figure_cache.get_figure("my_page:DE:6M:default")
if prebuilt is not None and inputs_are_defaults:
    return prebuilt
# … otherwise fall through to the normal slow path …
```

### Tuning knobs (env vars)

| Variable                       | Default | Effect                                      |
|--------------------------------|---------|---------------------------------------------|
| `WAITRESS_THREADS`             | 16      | Waitress worker threads.                    |
| `WAITRESS_CONNECTION_LIMIT`    | 200     | Max open sockets.                           |
| `WAITRESS_CHANNEL_TIMEOUT`     | 120     | Seconds before idle sockets are closed.     |

### Diagnostics

| Endpoint             | Purpose                                                 |
|----------------------|---------------------------------------------------------|
| `/api/fig-status`    | JSON of every registered figure + build stats.          |
| `/api/fig-keys`      | List of currently cached figure keys (used by client).  |
| `/api/fig/<key>`     | Stream a specific pre-built figure's JSON directly.     |
| `/api/cache-status`  | Unchanged — raw data-source scheduler status.           |

