#!/bin/bash
#
# portal_app_renew.sh — Force restart the Power Portal Dashboard
# Use this for scheduled daily restarts (e.g., 05:00 UTC) to clear
# in-memory caches and ensure fresh data at start of trading day.
#

SCRIPT_DIR="$(dirname "$(realpath "$0")")"
PYTHON_SCRIPT="$SCRIPT_DIR/portal_app.py"
SHELL_SCRIPT="$SCRIPT_DIR/portal_app.sh"
LOG_DIR="$SCRIPT_DIR/log"
LOG_FILE="$LOG_DIR/portal_app.log"

mkdir -p "$LOG_DIR"

echo "$(date '+%Y-%m-%d %H:%M:%S')  : ===== PORTAL RENEW START =====" >> "$LOG_FILE"

# Find and kill running portal process
PIDS=$(pgrep -f "python $PYTHON_SCRIPT")
if [ -n "$PIDS" ]; then
    for PID in $PIDS; do
        kill -9 "$PID" 2>/dev/null
        echo "$(date '+%Y-%m-%d %H:%M:%S')  : Killed process $PID" >> "$LOG_FILE"
    done
else
    echo "$(date '+%Y-%m-%d %H:%M:%S')  : No running portal process found." >> "$LOG_FILE"
fi

sleep 2

# Restart via the startup script
echo "$(date '+%Y-%m-%d %H:%M:%S')  : Restarting portal..." >> "$LOG_FILE"
bash "$SHELL_SCRIPT" >> "$LOG_FILE" 2>&1 &

echo "$(date '+%Y-%m-%d %H:%M:%S')  : ===== PORTAL RENEW COMPLETE =====" >> "$LOG_FILE"
