#!/bin/bash
#
# portal_app.sh — Start the Power Portal Dashboard (portal_app.py)
# Called by cron every 5 minutes to ensure it stays alive.
# Uses a 'stop' file to prevent restart when intentionally stopped.
#

SCRIPT_DIR="$(dirname "$(realpath "$0")")"
APP_DIR="$SCRIPT_DIR"
LOG_DIR="$APP_DIR/log"
LOG_FILE="$LOG_DIR/portal_app.log"
PYTHON_SCRIPT="$APP_DIR/portal_app.py"

# Ensure log directory exists
mkdir -p "$LOG_DIR"

# Production environment
export DASH_ENV="prod"
export PORT="8071"

START_CMD="python $PYTHON_SCRIPT >> $LOG_FILE 2>&1 &"

setup_micromamba() {
    export MAMBA_EXE='/jfs/tools/conda/exec/micromamba';
    export MAMBA_ROOT_PREFIX='/jfs/commod/conda/';
    __mamba_setup="$("$MAMBA_EXE" shell hook --shell bash --root-prefix "$MAMBA_ROOT_PREFIX" 2> /dev/null)"
    if [ $? -eq 0 ]; then
        eval "$__mamba_setup"
    else
        alias micromamba="$MAMBA_EXE"
    fi
    unset __mamba_setup

    micromamba activate commod-24.11.1
    echo "$(date '+%Y-%m-%d %H:%M:%S')  : micromamba commod-24.11.1 activated."
}

# Health check: hit the /api/health endpoint before declaring "running"
health_check() {
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:${PORT}/api/health" 2>/dev/null)
    if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "503" ]; then
        return 0  # Process is responding (503 = degraded but alive)
    fi
    return 1
}

# --- Main ---

if [ -e "$APP_DIR/stop" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S')  : stop file exists. Will not start portal." >> "$LOG_FILE"
    exit 0
fi

if pgrep -f "python $PYTHON_SCRIPT" > /dev/null; then
    # Process exists — verify it's actually responding
    if health_check; then
        echo "$(date '+%Y-%m-%d %H:%M:%S')  : Portal is running and healthy." >> "$LOG_FILE"
    else
        echo "$(date '+%Y-%m-%d %H:%M:%S')  : Portal process exists but NOT responding. Restarting..." >> "$LOG_FILE"
        # Kill the zombie process
        PIDS=$(pgrep -f "python $PYTHON_SCRIPT")
        for PID in $PIDS; do
            kill -9 "$PID" 2>/dev/null
        done
        sleep 2
        cd "$APP_DIR"
        setup_micromamba
        eval "$START_CMD"
        echo "$(date '+%Y-%m-%d %H:%M:%S')  : Portal restarted after unresponsive state." >> "$LOG_FILE"
    fi
else
    echo "$(date '+%Y-%m-%d %H:%M:%S')  : Portal is NOT running. Starting..." >> "$LOG_FILE"
    cd "$APP_DIR"
    setup_micromamba
    eval "$START_CMD"
    echo "$(date '+%Y-%m-%d %H:%M:%S')  : Portal started." >> "$LOG_FILE"
fi
