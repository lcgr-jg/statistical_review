"""Debug script for the Trade Data Pivot Table.

This script simulates the data enrichment process and checks for unexpected
NaNs, Nones, or misclassifications in the pivot payload.
"""

import pandas as pd
import numpy as np
from core.microstructure.pivot import enrich_for_pivot, _classify_tenor
from datetime import datetime

def run_debug():
    print("=== Microstructure Pivot Debug ===")
    
    # 1. Create mock trade data
    now = datetime(2026, 5, 8, 10, 30)
    mock_trades = pd.DataFrame({
        "DEAL_TIME_UK": [
            now, 
            now - pd.Timedelta(days=10),
            now - pd.Timedelta(days=1), # Thu May 7
        ],
        "TENOR_NAME": ["Jun-26", "Q3-26", "Cal-27"],
        "QUANTITY": [10.0, 25.0, 5.0],
        "PRICE": [55.5, 60.2, 75.0],
        "VENUE_CODE": ["EEX7", "GFI", "ICAP"],
        "AGGRESSOR_BUY": [True, False, True],
        "TP_ROUTE": ["R1", "R2", "R3"],
        "INITIATOR_SLEEVE": [False, True, False],
        "MARKET_NAME": ["France Baseload", "France Baseload", "France Baseload"]
    })
    
    # Add columns that clean_trades normally adds
    mock_trades["trade_date"] = pd.to_datetime(mock_trades["DEAL_TIME_UK"]).dt.normalize().dt.tz_localize(None)
    mock_trades["product_type"] = "Exchange"
    mock_trades["venue_label"] = mock_trades["VENUE_CODE"] + " [Exchange]"
    
    # 2. Create mock metadata
    # June-26 starts Mon Jun 1 2026
    # Q3-26 starts Jul 1 2026
    # Cal-27 starts Jan 1 2027
    mock_metadata = {
        "Jun-26": {
            "start": pd.Timestamp("2026-06-01"),
            "end": pd.Timestamp("2026-06-30"),
            "family": "Months"
        },
        "Q3-26": {
            "start": pd.Timestamp("2026-07-01"),
            "end": pd.Timestamp("2026-09-30"),
            "family": "Quarters"
        },
        "Cal-27": {
            "start": pd.Timestamp("2027-01-01"),
            "end": pd.Timestamp("2027-12-31"),
            "family": "Years"
        }
    }

    print(f"\nProcessing {len(mock_trades)} mock trades...")
    
    # 3. Enrich
    try:
        enriched = enrich_for_pivot(mock_trades, tenor_metadata=mock_metadata)
    except Exception as e:
        print(f"CRITICAL: enrich_for_pivot failed with error: {e}")
        import traceback
        traceback.print_exc()
        return

    # 4. Validation Checks
    print("\n--- Validation Results ---")
    
    cols_to_check = [
        "trade_date", "tenor", "contract_type", "tenor_family", 
        "days_to_expiry", "tte_start_bucket", "contract_length_bucket",
        "vwap_premium", "vwap_premium_bucket"
    ]
    
    for col in cols_to_check:
        if col not in enriched.columns:
            print(f"[FAIL] Column '{col}' is MISSING from enriched data.")
            continue
            
        null_count = enriched[col].isna().sum()
        none_count = (enriched[col] == "None").sum() # Check for string "None"
        
        if null_count > 0 or none_count > 0:
            print(f"[WARN] Column '{col}' has {null_count} NaNs and {none_count} 'None' strings.")
            # Show the rows with issues
            bad_rows = enriched[enriched[col].isna() | (enriched[col] == "None")]
            print(f"      Affected tenors: {bad_rows['tenor'].tolist()}")
        else:
            print(f"[OK]   Column '{col}' is clean.")

    # 5. Check specific logic (Trading Days)
    print("\n--- Logic Verification ---")
    # Thu May 7 -> Mon Jun 1 should be 17 trading days? 
    # Let's check the actual values.
    for i, row in enriched.iterrows():
        print(f"Trade: {row['trade_date']} | Tenor: {row['tenor']} ({row['contract_type']})")
        print(f"  -> Days to Expiry: {row['days_to_expiry']}")
        print(f"  -> Bucket: {row['tte_start_bucket']}")
        print(f"  -> Length: {row['contract_length_bucket']}")

    # 6. Test Classifier directly with tricky strings
    print("\n--- Classifier Test ---")
    test_strings = ["Jun-26", "Jun 26", "Q3-26", "Cal-27", "YR-28", "2029", "BOM Jun-26", "WkEnd+1"]
    for ts in test_strings:
        res = _classify_tenor(ts)
        print(f"  '{ts}' -> {res}")

if __name__ == "__main__":
    run_debug()
