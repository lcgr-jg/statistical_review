"""Tests for Cargo Forecast History helpers."""
from __future__ import annotations

from datetime import date

import pandas as pd
import pytest

from core.cargo_forecast_history.constants import (
    BBG_VESSEL_MAP_URL,
    KPLER_VESSEL_MAP_URL,
)
from core.cargo_forecast_history.data import (
    cargo_volume_mcm,
    extract_on_water_rows,
    flag_forecast_changes,
    is_laden_volume,
    last_load_date,
)


def _snapshot(**overrides):
    row = {
        "Vessel": "Al Hamla",
        "IMO (vessel)": 9373745,
        "Id (vessel)": 12345,
        "Trade status": "In Transit",
        "Installation origin": "Ras Laffan",
        "Country (origin)": "Qatar",
        "Date (origin)": "2026-07-01",
        "Volume (origin m3)": 200_000,
        "Country (destination)": "Belgium",
        "Installation Destination": "Zeebrugge",
        "Continent Destination": "Europe",
        "Forecasted destination": "Europe",
        "Date (destination)": "2026-08-01",
        "Eta source (destination)": "Model",
        "Forecasted confidence": 0.4,
        "Id (Voyage)": 99,
    }
    row.update(overrides)
    return row


def test_extract_keeps_on_water_and_drops_delivered():
    raw = pd.DataFrame([
        _snapshot(),
        _snapshot(**{"Trade status": "Delivered", "IMO (vessel)": 1}),
        _snapshot(**{"Trade status": "Loading", "IMO (vessel)": 2,
                     "Vessel": "Loader"}),
    ])
    out = extract_on_water_rows(raw, date(2026, 7, 15))
    assert set(out["imo"]) == {9373745, 2}
    assert list(out["status"]) == ["In Transit", "Loading"]
    assert out.iloc[0]["from_terminal"] == "Ras Laffan"
    assert out.iloc[0]["source"] == "Model"
    assert float(out.iloc[0]["volume_m3"]) == 200_000


def test_extract_empty_and_missing_columns():
    assert extract_on_water_rows(pd.DataFrame(), date(2026, 1, 1)).empty
    assert extract_on_water_rows(
        pd.DataFrame({"Vessel": ["x"]}), date(2026, 1, 1)).empty


def test_flag_forecast_changes_destination_and_source():
    rows = pd.concat([
        extract_on_water_rows(pd.DataFrame([_snapshot()]), date(2026, 7, 10)),
        extract_on_water_rows(pd.DataFrame([_snapshot(**{
            "Country (destination)": "France",
            "Installation Destination": "Dunkirk",
            "Eta source (destination)": "AIS",
            "Date (destination)": "2026-08-05",
        })]), date(2026, 7, 11)),
    ], ignore_index=True)
    flagged = flag_forecast_changes(rows)
    assert not bool(flagged.iloc[0]["dest_changed"])
    assert bool(flagged.iloc[1]["dest_changed"])
    assert bool(flagged.iloc[1]["source_changed"])
    assert bool(flagged.iloc[1]["eta_changed"])


def test_last_load_date_uses_latest_origin():
    raw = pd.DataFrame([
        _snapshot(**{"Date (origin)": "2026-06-01"}),
        _snapshot(**{"Date (origin)": "2026-07-01"}),
    ])
    rows = extract_on_water_rows(raw, date(2026, 7, 15))
    assert last_load_date(rows) == date(2026, 7, 1)
    assert last_load_date(pd.DataFrame()) is None


def test_laden_and_volume_helpers():
    assert is_laden_volume(150_000)
    assert not is_laden_volume(0)
    assert not is_laden_volume(None)
    assert cargo_volume_mcm(10_000) == pytest.approx(6.0)


def test_kpler_map_url():
    url = KPLER_VESSEL_MAP_URL.format(12345)
    assert url.endswith("vessels=12345")


def test_bloomberg_map_url():
    url = BBG_VESSEL_MAP_URL.format(9373745)
    assert url == "bbg://screens/MAP IMO 9373745"
