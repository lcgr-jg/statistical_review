"""
Tests for core.cache – the unified DashboardCache.

Run:
    python -m pytest tests/test_cache.py -v
"""
import time
import pytest
import pandas as pd


class TestDashboardCacheUnit:
    """Unit tests for the DashboardCache two-tier cache."""

    @pytest.fixture
    def cache(self, tmp_path):
        from core.cache import DashboardCache
        return DashboardCache(cache_dir=str(tmp_path / "test_cache"), max_mem_items=10)

    def test_set_and_get(self, cache):
        cache.set("key1", "value1", ttl=60)
        assert cache.get("key1", ttl=60) == "value1"

    def test_ttl_expiry(self, cache):
        cache.set("key2", "value2", ttl=1)
        time.sleep(1.5)
        assert cache.get("key2", ttl=1) is None

    def test_delete(self, cache):
        cache.set("key3", "value3", ttl=60)
        cache.delete("key3")
        assert cache.get("key3", ttl=60) is None

    def test_sweep_removes_only_old_orphan_files(self, cache):
        import os
        big = "x" * 100_000  # large enough for diskcache to use a .val file
        cache.set("live", big, ttl=60)
        cache_dir = cache._cache_dir
        live = {p for p in cache_dir.rglob("*.val")}
        assert live

        old_orphan = cache_dir / "ab" / "cd" / "old_orphan.val"
        new_orphan = cache_dir / "ab" / "cd" / "new_orphan.val"
        old_orphan.parent.mkdir(parents=True, exist_ok=True)
        old_orphan.write_bytes(b"0" * 10)
        new_orphan.write_bytes(b"0" * 10)
        stale = time.time() - 2 * cache._ORPHAN_MIN_AGE_S
        for p in live | {old_orphan}:  # referenced files must survive by index, not age
            os.utime(p, (stale, stale))

        removed, freed = cache._sweep_orphan_files()
        assert (removed, freed) == (1, 10)
        assert not old_orphan.exists()
        assert new_orphan.exists()  # too young — may be mid-write
        assert all(p.exists() for p in live)
        assert cache.get("live", ttl=60) == big

    def test_clear_all(self, cache):
        cache.set("a", 1, ttl=60)
        cache.set("b", 2, ttl=60)
        cache.clear()
        assert cache.get("a", ttl=60) is None
        assert cache.get("b", ttl=60) is None

    def test_clear_with_prefix(self, cache):
        cache.set("prices:a", 1, ttl=60)
        cache.set("prices:b", 2, ttl=60)
        cache.set("charts:c", 3, ttl=60)
        cache.clear(prefix="prices:")
        assert cache.get("prices:a", ttl=60) is None
        assert cache.get("charts:c", ttl=60) == 3

    def test_stats(self, cache):
        cache.set("s1", "v1", ttl=60)
        cache.get("s1", ttl=60)  # hit
        cache.get("missing", ttl=60)  # miss
        stats = cache.get_stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1

    def test_mem_eviction_at_limit(self, cache):
        for i in range(15):
            cache.set(f"k{i}", i, ttl=60)
        # Should have evicted some to stay at max_mem_items=10
        assert len(cache._mem) <= 10


class TestCachedResultDecorator:
    """Tests for the @cached_result decorator."""

    @pytest.fixture(autouse=True)
    def _patch_cache(self, tmp_path, monkeypatch):
        from core.cache import DashboardCache
        import core.cache as cache_mod
        mgr = DashboardCache(cache_dir=str(tmp_path / "dec_cache"))
        monkeypatch.setattr(cache_mod, "dashboard_cache", mgr)

    def test_caches_result(self):
        from core.cache import cached_result
        call_count = 0

        @cached_result(ttl=60, prefix="test_res")
        def expensive(x):
            nonlocal call_count
            call_count += 1
            return x * 2

        assert expensive(5) == 10
        assert expensive(5) == 10
        assert call_count == 1  # second call served from cache

    def test_invalidate(self):
        from core.cache import cached_result
        call_count = 0

        @cached_result(ttl=60, prefix="test_inv")
        def compute(x):
            nonlocal call_count
            call_count += 1
            return x + 1

        compute(3)
        compute.invalidate(3)
        compute(3)
        assert call_count == 2

    def test_caches_dataframe(self):
        from core.cache import cached_result

        @cached_result(ttl=60, prefix="test_df")
        def make_df():
            return pd.DataFrame({"a": [1, 2, 3]})

        df1 = make_df()
        df2 = make_df()
        assert df1.equals(df2)


class TestCachedFigureDecorator:
    """Tests for the @cached_figure decorator."""

    @pytest.fixture(autouse=True)
    def _patch_cache(self, tmp_path, monkeypatch):
        from core.cache import DashboardCache
        import core.cache as cache_mod
        mgr = DashboardCache(cache_dir=str(tmp_path / "fig_cache"))
        monkeypatch.setattr(cache_mod, "dashboard_cache", mgr)

    def test_caches_figure(self):
        from core.cache import cached_figure
        import plotly.graph_objects as go
        call_count = 0

        @cached_figure(ttl=60, prefix="test_fig")
        def make_fig(title):
            nonlocal call_count
            call_count += 1
            fig = go.Figure()
            fig.update_layout(title=title)
            return fig

        fig1 = make_fig("test")
        fig2 = make_fig("test")
        assert isinstance(fig2, go.Figure)
        assert call_count == 1


class TestSchedulerTier:
    """Tests for data source registration + get_data."""

    @pytest.fixture
    def cache(self, tmp_path):
        from core.cache import DashboardCache
        return DashboardCache(cache_dir=str(tmp_path / "sched_cache"))

    def test_register_and_get_data(self, cache):
        cache.register_source("my_src", lambda: {"val": 42}, ttl=300, run_immediately=True)
        data = cache.get_data("my_src")
        assert data == {"val": 42}

    def test_force_refresh(self, cache):
        counter = {"n": 0}
        def loader():
            counter["n"] += 1
            return counter["n"]

        cache.register_source("counter", loader, ttl=300, run_immediately=True)
        assert cache.get_data("counter") == 1
        cache.force_refresh("counter")
        assert cache.get_data("counter") == 2

    def test_get_status(self, cache):
        cache.register_source("s", lambda: "data", ttl=60, run_immediately=True)
        status = cache.get_status()
        assert "data_sources" in status
        assert "s" in status["data_sources"]
        assert status["data_sources"]["s"]["has_data"]

    def test_registered_sources(self, cache):
        cache.register_source("a", lambda: 1, run_immediately=False)
        cache.register_source("b", lambda: 2, run_immediately=False)
        assert set(cache.registered_sources) == {"a", "b"}
