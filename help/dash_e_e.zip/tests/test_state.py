"""
Unit tests for :mod:`core.state`.

Only the *pure* helpers (encode/decode + parser primitives) are exercised
here.  The Dash callback-registration side of ``register()`` requires a
running app and is covered indirectly by the page-level smoke tests.
"""
from __future__ import annotations

import pytest

from core.state import (
    UrlControl,
    decode,
    encode,
    encode_list,
    parse_float_list,
    parse_int,
    parse_int_list,
)


# -----------------------------------------------------------------------------
# Parser / encoder primitives
# -----------------------------------------------------------------------------
class TestParsers:
    def test_parse_int(self):
        assert parse_int("42") == 42

    def test_parse_int_list_skips_empty_segments(self):
        assert parse_int_list("1,,3,") == [1, 3]

    def test_parse_float_list(self):
        assert parse_float_list("0.5,0.6,0.7") == [0.5, 0.6, 0.7]

    def test_encode_list_handles_none(self):
        assert encode_list(None) == ""

    def test_encode_list_roundtrips_with_parse_int_list(self):
        assert parse_int_list(encode_list([1, 2, 3])) == [1, 2, 3]


# -----------------------------------------------------------------------------
# decode()
# -----------------------------------------------------------------------------
CONTROLS = [
    UrlControl("hub", "value"),
    UrlControl("effs", "value", parse=parse_float_list, encode=encode_list),
    UrlControl("year", "value", parse=parse_int),
]


class TestDecode:
    def test_empty_search_returns_empty_dict(self):
        assert decode("", CONTROLS) == {}
        assert decode(None, CONTROLS) == {}

    def test_decodes_simple_string_value(self):
        assert decode("?hub=DE", CONTROLS) == {"hub": "DE"}

    def test_decodes_list_value(self):
        assert decode("?effs=0.5,0.6", CONTROLS) == {"effs": [0.5, 0.6]}

    def test_decodes_int_value(self):
        assert decode("?year=2026", CONTROLS) == {"year": 2026}

    def test_unknown_keys_are_ignored(self):
        assert decode("?nope=x&hub=DE", CONTROLS) == {"hub": "DE"}

    def test_search_without_question_mark_works(self):
        assert decode("hub=DE", CONTROLS) == {"hub": "DE"}

    def test_malformed_value_does_not_raise(self, caplog):
        # "abc" can't be parsed as int -> dropped, warning logged.
        out = decode("?year=abc&hub=DE", CONTROLS)
        assert out == {"hub": "DE"}


# -----------------------------------------------------------------------------
# encode()
# -----------------------------------------------------------------------------
class TestEncode:
    def test_empty_state_returns_empty_string(self):
        assert encode({}, CONTROLS) == ""

    def test_none_values_omitted(self):
        assert encode({"hub": None}, CONTROLS) == ""

    def test_encodes_simple_value(self):
        assert encode({"hub": "DE"}, CONTROLS) == "?hub=DE"

    def test_encodes_list_value(self):
        assert encode({"effs": [0.5, 0.6]}, CONTROLS) == "?effs=0.5%2C0.6"

    def test_unknown_key_ignored(self):
        assert encode({"nope": "x", "hub": "DE"}, CONTROLS) == "?hub=DE"


# -----------------------------------------------------------------------------
# Round-trip property
# -----------------------------------------------------------------------------
@pytest.mark.parametrize(
    "state",
    [
        {"hub": "DE"},
        {"hub": "FR", "year": 2025},
        {"effs": [0.49, 0.52, 0.59]},
        {"hub": "DE", "effs": [0.4, 0.5], "year": 2026},
    ],
)
def test_encode_then_decode_is_identity(state):
    assert decode(encode(state, CONTROLS), CONTROLS) == state


# -----------------------------------------------------------------------------
# UrlControl
# -----------------------------------------------------------------------------
def test_urlcontrol_query_key_defaults_to_component_id():
    assert UrlControl("foo").key == "foo"


def test_urlcontrol_query_key_override():
    assert UrlControl("foo", query_key="f").key == "f"
