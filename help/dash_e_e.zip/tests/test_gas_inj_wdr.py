"""Tests for injectability / withdrawability page helpers."""
from datetime import date

from core.gas_inj_wdr.constants import withdraw_first
from core.gas_inj_wdr.data import params_for_catalog, parse_countries, utilisation_pct
from core.gas_storage_summary.constants import DEFAULT_MULTI_COUNTRIES


def test_withdraw_first_winter():
    assert withdraw_first(date(2026, 1, 15)) is True
    assert withdraw_first(date(2026, 11, 1)) is True
    assert withdraw_first(date(2026, 3, 31)) is True


def test_withdraw_first_summer():
    assert withdraw_first(date(2026, 4, 1)) is False
    assert withdraw_first(date(2026, 10, 31)) is False


def test_parse_countries_default_and_order():
    assert parse_countries(None) == list(DEFAULT_MULTI_COUNTRIES)
    assert parse_countries(["NL", "DE"]) == ["DE", "NL"]
    assert parse_countries(["XX", "FR"]) == ["FR"]


def test_params_for_catalog_inner_join_drops_split_rows():
    import pandas as pd

    params = pd.DataFrame(
        [
            {"data_id": 1, "country": "DE", "site_name": "Rehden", "p_inj": 1.0},
            {"data_id": 2, "country": "DE", "site_name": "Etzel Crystal Gts", "p_inj": 1.0},
        ]
    )
    sites = pd.DataFrame(
        [{"data_id": 1, "country": "DE", "site_name": "Rehden"}]
    )
    out = params_for_catalog(params, sites)
    assert list(out["data_id"]) == [1]
    assert "Rehden" in set(out["site_name"])


def test_params_for_catalog_empty_sites_drops_all():
    import pandas as pd

    params = pd.DataFrame([{"data_id": 1, "country": "DE", "site_name": "Rehden"}])
    out = params_for_catalog(params, pd.DataFrame())
    assert out.empty


def test_utilisation_pct_includes_over_100():
    import pandas as pd

    idx = pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-03"])
    actual = pd.DataFrame({"DE": [50.0, 100.0, 120.0], "Total": [50.0, 100.0, 120.0]}, index=idx)
    cap = pd.DataFrame({"DE": [100.0, 100.0, 100.0], "Total": [100.0, 100.0, 100.0]}, index=idx)
    pct = utilisation_pct(actual, cap)
    assert pct.loc[idx[0], "DE"] == 50.0
    assert pct.loc[idx[1], "DE"] == 100.0
    assert pct.loc[idx[2], "DE"] == 120.0


def test_utilisation_pct_masks_zero_capability():
    import pandas as pd

    idx = pd.to_datetime(["2024-01-01"])
    actual = pd.DataFrame({"DE": [10.0]}, index=idx)
    cap = pd.DataFrame({"DE": [0.0]}, index=idx)
    pct = utilisation_pct(actual, cap)
    assert pd.isna(pct.loc[idx[0], "DE"])


def test_utilisation_pct_empty_inputs():
    import pandas as pd

    assert utilisation_pct(pd.DataFrame(), pd.DataFrame()).empty
    cap = pd.DataFrame({"DE": [100.0]}, index=pd.to_datetime(["2024-01-01"]))
    assert utilisation_pct(None, cap).empty


def test_sum_by_country_orders_and_totals():
    import pandas as pd

    from core.gas_inj_wdr.data import sum_by_country

    idx = pd.to_datetime(["2024-01-01", "2024-01-02"])
    parts = [
        pd.Series([1.0, 2.0], index=idx, name=("NL", 1)),
        pd.Series([3.0, 4.0], index=idx, name=("DE", 2)),
        pd.Series([10.0, 20.0], index=idx, name=("DE", 3)),
    ]
    out = sum_by_country(parts)
    assert list(out.columns) == ["DE", "NL", "Total"]
    assert out.loc[idx[0], "DE"] == 13.0
    assert out.loc[idx[0], "Total"] == 14.0


def _site_series(country: str, data_id: int, start: str, end: str, value: float = 1.0):
    import pandas as pd

    idx = pd.date_range(start, end, freq="D")
    return pd.Series(value, index=idx, name=(country, data_id))


def test_last_complete_truncates_nomination_tail():
    import pandas as pd

    from core.gas_inj_wdr.data import last_complete_by_country, site_frame, sum_by_country

    parts = [
        _site_series("DE", 1, "2026-09-01", "2026-09-20"),
        _site_series("DE", 2, "2026-09-01", "2026-09-20"),
        _site_series("DE", 3, "2026-09-01", "2026-09-20"),
        _site_series("DE", 4, "2026-09-01", "2026-09-24"),
    ]
    cut = last_complete_by_country(site_frame(parts))
    assert cut["DE"] == pd.Timestamp("2026-09-20")
    out = sum_by_country(parts)
    assert out["DE"].last_valid_index() == pd.Timestamp("2026-09-20")
    assert pd.isna(out.loc[pd.Timestamp("2026-09-21"):, "DE"]).all()
    assert out.loc[pd.Timestamp("2026-09-20"), "DE"] == 4.0


def test_last_complete_ignores_stale_site():
    import pandas as pd

    from core.gas_inj_wdr.data import last_complete_by_country, site_frame

    parts = [
        _site_series("DE", 1, "2026-09-01", "2026-09-20"),
        _site_series("DE", 2, "2026-09-01", "2026-09-20"),
        _site_series("DE", 3, "2026-09-01", "2026-09-20"),
        _site_series("DE", 99, "2024-01-01", "2024-06-01"),
    ]
    cut = last_complete_by_country(site_frame(parts))
    assert cut["DE"] == pd.Timestamp("2026-09-20")


def test_last_complete_total_uses_earliest_country():
    import pandas as pd

    from core.gas_inj_wdr.data import sum_by_country

    parts = [
        _site_series("DE", 1, "2026-09-01", "2026-09-20"),
        _site_series("DE", 2, "2026-09-01", "2026-09-20"),
        _site_series("NL", 3, "2026-09-01", "2026-09-22"),
        _site_series("NL", 4, "2026-09-01", "2026-09-22"),
    ]
    out = sum_by_country(parts)
    assert out["DE"].last_valid_index() == pd.Timestamp("2026-09-20")
    assert out["NL"].last_valid_index() == pd.Timestamp("2026-09-22")
    assert out["Total"].last_valid_index() == pd.Timestamp("2026-09-20")


def test_capability_chart_overlay_and_pct_over_100():
    import pandas as pd

    from core.gas_inj_wdr.charts import build_capability_chart

    idx = pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-03"])
    cap = pd.DataFrame({"Total": [100.0, 100.0, 100.0], "DE": [100.0, 100.0, 100.0]}, index=idx)
    act = pd.DataFrame({"Total": [50.0, 100.0, 120.0], "DE": [50.0, 100.0, 120.0]}, index=idx)
    overlay = build_capability_chart(cap, "Inj", "mcm/d", countries=["DE"], actual=act)
    assert "Max" in [t.name for t in overlay.data]
    assert "Actual" in [t.name for t in overlay.data]
    assert overlay.layout.legend.x == 0.5
    assert overlay.layout.legend.xanchor == "center"
    assert overlay.layout.legend.yanchor == "top"
    assert overlay.layout.legend.y <= -0.15

    pct = build_capability_chart(
        cap, "Inj", "mcm/d", countries=["DE"], actual=act, mode="pct"
    )
    top = next(t for t in pct.data if t.name in ("Total", "DE", "Max"))
    assert max(top.y) == 120.0


def test_capability_chart_total_is_sum_of_selected():
    import pandas as pd

    from core.gas_inj_wdr.charts import build_capability_chart

    idx = pd.to_datetime(["2024-01-01"])
    cap = pd.DataFrame(
        {"DE": [10.0], "NL": [20.0], "FR": [100.0], "Total": [130.0]},
        index=idx,
    )
    fig = build_capability_chart(cap, "Inj", "mcm/d", countries=["DE", "NL"])
    total = next(t for t in fig.data if t.name == "Total")
    assert list(total.y) == [30.0]


def test_capability_chart_country_overlay_uses_own_legend():
    import pandas as pd

    from core.gas_inj_wdr.charts import build_capability_chart

    idx = pd.to_datetime(["2024-01-01", "2024-01-02"])
    cap = pd.DataFrame(
        {"DE": [10.0, 11.0], "NL": [20.0, 21.0], "Total": [30.0, 32.0]},
        index=idx,
    )
    act = pd.DataFrame(
        {"DE": [1.0, 2.0], "NL": [3.0, 4.0], "Total": [4.0, 6.0]},
        index=idx,
    )
    fig = build_capability_chart(cap, "Inj", "mcm/d", countries=["DE", "NL"], actual=act)
    legend_ids = {getattr(t, "legend", "legend") for t in fig.data}
    assert "legend" in legend_ids
    assert "legend2" in legend_ids
    assert fig.layout.legend.xanchor == "center"
    assert fig.layout.legend2.xanchor == "center"
    assert fig.layout.legend2.y < fig.layout.legend.y


def test_capability_chart_multi_country_min_height():
    import pandas as pd

    from core.gas_inj_wdr.charts import COUNTRY_ROW_MIN_HEIGHT, TOP_PANEL_HEIGHT, build_capability_chart

    idx = pd.to_datetime(["2024-01-01"])
    cap = pd.DataFrame(
        {
            "AT": [1.0],
            "BE": [1.0],
            "DE": [1.0],
            "FR": [1.0],
            "GB": [1.0],
            "IT": [1.0],
            "NL": [1.0],
            "Total": [7.0],
        },
        index=idx,
    )
    fig = build_capability_chart(cap, "Inj", "mcm/d", countries=["AT", "BE", "DE", "FR", "GB", "IT", "NL"])
    n_country_rows = 4
    assert fig.layout.height >= TOP_PANEL_HEIGHT + n_country_rows * COUNTRY_ROW_MIN_HEIGHT
    assert fig.layout.autosize is False
