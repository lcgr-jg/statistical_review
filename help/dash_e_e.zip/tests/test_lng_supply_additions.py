"""Supply Additions: Goldman snapshot, filters, and vendor row mapping."""
from __future__ import annotations

import pandas as pd
import pytest

from core.lng_supply_additions.charts import fig_by_country, fig_by_source, fig_cumulative, fig_timeline
from core.lng_supply_additions.data import load_snapshots
from core.lng_supply_additions.schema import (
    addition_from_series,
    align_vendors,
    annual_totals,
    apply_filters,
    canonical_country,
    parse_when,
    plant_identity,
    present,
    project_key,
    summarise,
    vendor_comparison,
)
from core.lng_supply_additions.constants import SOURCE_EA, SOURCE_GS
from core.lng_supply_additions.vendors import trains_to_additions


def _goldman():
    frame, statuses = load_snapshots()
    gs_status = next(item for item in statuses if item["label"] == SOURCE_GS)
    assert gs_status["state"] == "ok"
    assert gs_status["as_of"] == "2026-10-06"
    return frame[frame["source"] == SOURCE_GS].reset_index(drop=True)


def test_goldman_snapshot_matches_the_table_totals():
    frame = _goldman()
    assert len(frame) == 27
    assert frame["country"].eq("US").sum() == 12
    totals = annual_totals(frame)
    assert totals[2026] == pytest.approx(0.7)
    assert totals[2027] == pytest.approx(44.8)
    assert totals[2028] == pytest.approx(58.2)
    assert totals[2029] == pytest.approx(44.2)
    assert summarise(frame)["mtpa"] == pytest.approx(147.9)
    assert summarise(frame)["next_project"] == "Cap Lopez LNG"
    assert summarise(frame)["next_start"] == "2026-12"

    fast = present(frame[frame["project"].str.contains("Fast LNG")])
    assert fast["fid_display"].iloc[0] == "2024*"
    phase = frame[frame["project"].str.contains("Phase 1")].iloc[0]
    assert phase["n_trains"] == 9
    assert phase["bcm_y"] == pytest.approx(27.9)


def test_filters_country_search_and_size():
    frame = _goldman()
    us_2027 = apply_filters(frame, countries=["US"], year_from=2027, year_to=2027)
    assert len(us_2027) == 3
    assert us_2027["mtpa"].sum() == pytest.approx(18.2)

    sempra = apply_filters(frame, search="sempra", year_from=2026, year_to=2035)
    assert set(sempra["project"]) == {"Port Arthur LNG T1", "Port Arthur LNG T2"}

    big = apply_filters(frame, year_from=2027, year_to=2027, min_mtpa=5)
    assert "Fast LNG GoM Mod. 2" not in set(big["project"])
    assert big["mtpa"].min() >= 5


def test_project_keys_line_up_train_spellings():
    assert project_key("Qatar", "North Field East T1") == project_key(
        "Qatar", "North Field East Train 1"
    )
    assert canonical_country("United States") == "US"
    assert canonical_country("QA") == "Qatar"
    start, precision = parse_when("Dec 2026")
    assert precision == "month"
    assert start == pd.Timestamp("2026-12-01")


def test_platts_rows_drop_old_trains_and_match_goldman():
    raw = pd.DataFrame([
        {
            "LIQUEFACTION_PROJECT": "Golden Pass",
            "TRAIN_NAME": "T2",
            "COUNTRY": "United States",
            "OPERATOR": "QatarEnergy/Exxon",
            "CAPACITY_MTPA": 6.0,
            "STARTUP_DATE": "2027-06-01",
            "TRAIN_STATUS": "Under Construction",
            "FID_DATE": "2019-02-01",
        },
        {
            "LIQUEFACTION_PROJECT": "Sabine Pass",
            "TRAIN_NAME": "T1",
            "COUNTRY": "United States",
            "CAPACITY_MTPA": 4.5,
            "STARTUP_DATE": "2016-05-01",
            "TRAIN_STATUS": "Existing",
        },
        {
            "LIQUEFACTION_PROJECT": "Mystery LNG",
            "COUNTRY": "Qatar",
            "CAPACITY_MTPA": 8.0,
            "TRAIN_STATUS": "Planned",
        },
        {
            "LIQUEFACTION_PROJECT": "Old LNG",
            "COUNTRY": "Qatar",
            "TRAIN_STATUS": "Existing",
        },
    ])
    mapped, info = trains_to_additions(raw, backend="test", as_of="2026-10-06")
    assert info["n_out"] == 2
    names = set(mapped["project"])
    assert "Golden Pass T2" in names
    assert "Mystery LNG" in names
    assert "Sabine Pass T1" not in names

    golden = mapped[mapped["project"] == "Golden Pass T2"].iloc[0]
    assert golden["country"] == "US"
    assert golden["start_label"] == "2027-06"
    assert golden["fid_year"] == 2019
    assert pd.isna(golden["bcm_y"]) or golden["bcm_y"] == pytest.approx(6.0 * 1.38)

    gs = _goldman()
    gs_row = gs[gs["project"] == "Golden Pass T2"].iloc[0]
    assert golden["match_key"] == gs_row["match_key"]
    platts_row = mapped[mapped["project"] == "Golden Pass T2"]
    compared = vendor_comparison(pd.concat(
        [gs[gs["project"] == "Golden Pass T2"], platts_row], ignore_index=True,
    ))
    assert len(compared) == 1
    assert compared[0]["spread_months"] == 2


def test_platts_startup_uses_first_cargo_not_the_later_commercial_date():
    raw = pd.DataFrame([
        {
            "LIQUEFACTION_PROJECT": "Plaquemines LNG",
            "TRAIN_NAME": "T1-6",
            "COUNTRY": "United States",
            "CAPACITY_MTPA": 4.0,
            "STARTUP_DATE": "2026-10-31",
            "ESTIMATED_FIRST_CARGO_DATE": "2025-01-11",
            "TRAIN_STATUS": "Commissioning",
        },
        {
            "LIQUEFACTION_PROJECT": "Golden Pass LNG",
            "TRAIN_NAME": "T1",
            "COUNTRY": "United States",
            "CAPACITY_MTPA": 5.2,
            "STARTUP_DATE": "2026-11-15",
            "ESTIMATED_FIRST_CARGO_DATE": "2026-05-08",
            "TRAIN_STATUS": "Commissioning",
        },
    ])
    mapped, info = trains_to_additions(raw, backend="test", as_of="2026-10-09")
    assert info["n_out"] == 2
    by_name = {row.project: row for row in mapped.itertuples()}
    assert pd.Timestamp(by_name["Plaquemines LNG T1-6"].start_date) == pd.Timestamp("2025-01-11")
    assert pd.Timestamp(by_name["Golden Pass LNG T1"].start_date) == pd.Timestamp("2026-05-08")

    in_window = apply_filters(
        mapped, year_from=2026, year_to=2029, include_unmatched_platts=True,
    )
    assert set(in_window["project"]) == {"Golden Pass LNG T1"}
    chart = fig_by_source(in_window)
    plotted = 0.0 if not chart.data else float(sum(chart.data[0].y))
    assert plotted == 0.0


def test_energy_aspects_ramp_becomes_one_addition():
    index = pd.date_range("2024-01-01", "2029-12-01", freq="MS")
    ramp = pd.Series(0.0, index=index)
    ramp.loc[ramp.index >= "2028-03-01"] = 5.0
    today = pd.Timestamp("2026-10-06")
    row = addition_from_series(
        ramp,
        description="North Field East T1",
        country="QA",
        unit="mtpa",
        as_of="2026-10-01",
        today=today,
        dataset_id=15507,
    )
    assert row is not None
    assert row["mtpa"] == pytest.approx(5.0)
    assert pd.Timestamp(row["start_date"]) == pd.Timestamp("2028-03-01")
    assert "15507" in row["note"]

    flat = pd.Series(8.0, index=index)
    assert addition_from_series(
        flat, description="Qatar exports", country="QA", unit="mtpa",
        as_of="2026-10-01", today=today,
    ) is None


def _platts_row(project, start, mtpa=1.0, status="Under Construction", country="United States"):
    return {
        "source": "S&P Platts",
        "source_kind": "live",
        "as_of": "2026-10-06",
        "country": country,
        "project": project,
        "operator": "",
        "n_trains": 1,
        "mtpa": mtpa,
        "bcm_y": None,
        "start_date": pd.Timestamp(start) if start else pd.NaT,
        "start_precision": "day",
        "fid_year": 2025,
        "fid_note": "",
        "status": status,
        "note": "",
        "on_goldman": False,
    }


def test_platts_trains_map_onto_goldman_projects():
    assert plant_identity("Calcasieu Pass LNG T1-2") == "calcasieu"
    assert plant_identity("CP2 LNG T1-2") == "cp2"
    assert plant_identity("Calcasieu Pass's 2 Phase 1") == "cp2"
    assert plant_identity("Marsa El Brega LNG") == "marsa brega"
    assert plant_identity("North Field South T1") == "north field south"

    raw = [
        _platts_row("CP2 LNG T1-2", "2029-07-01", 1.11),
        _platts_row("CP2 LNG T3-4", "2029-07-01", 1.11),
        _platts_row("CP2 LNG T27-28", "2030-07-01", 1.11),
        _platts_row("CP2 LNG T1-26 Uprate 1", "2029-07-01", 2.9),
        _platts_row("Calcasieu Pass LNG T1-2", "2025-04-03", 4.0, status="Existing"),
        _platts_row("North Field South T1", "2030-01-01", 8.0, country="Qatar"),
        _platts_row("Nigeria LNG T1-6 Debottleneck", "2027-10-01", 1.0, country="Nigeria"),
        _platts_row("Nigeria LNG T7", "2027-12-01", 8.0, country="Nigeria"),
        _platts_row("Pluto LNG T2", "2026-12-01", 5.0, country="Australia"),
        _platts_row("Marsa El Brega LNG T1", "1970-01-01", 2.0, country="Libya", status="Decommissioned"),
        _platts_row("Marsa LNG T1", "2029-01-01", 1.0, country="Oman"),
        _platts_row("Golden Pass LNG T1", "2026-11-15", 5.2),
        _platts_row("Golden Pass LNG T2", "2027-06-01", 5.2),
        _platts_row("Corpus Christi LNG Midscale T8", "2028-07-01", 1.5),
    ]
    from core.lng_supply_additions.schema import finalize

    platts = finalize(raw)
    aligned, note = align_vendors(pd.concat([_goldman(), platts], ignore_index=True))
    view = apply_filters(
        aligned, sources=["S&P Platts"], year_from=2024, year_to=2040,
    )
    names = set(view["project"])
    assert "Pluto LNG T2" in names
    assert "Nigeria LNG T7" in names
    assert "Golden Pass T2" in names
    assert "Marsa LNG" in names
    assert "Corpus Christi Stage 4 T8" in names
    assert "Calcasieu Pass's 2 Phase 1" in names
    assert "Calcasieu Pass's 2 Phase 2" in names
    assert "Calcasieu Pass LNG T1-2" not in names
    assert "Golden Pass LNG T1" not in names
    assert "North Field South T1" not in names

    phase1 = view[view["project"] == "Calcasieu Pass's 2 Phase 1"].iloc[0]
    phase2 = view[view["project"] == "Calcasieu Pass's 2 Phase 2"].iloc[0]
    assert pd.Timestamp(phase1["start_date"]) == pd.Timestamp("2029-07-01")
    assert pd.Timestamp(phase2["start_date"]) == pd.Timestamp("2030-07-01")
    assert phase1["gs_fid_year"] == 2022
    assert phase2["gs_fid_year"] == 2026
    assert phase1["mtpa"] == pytest.approx(2.22)

    golden = view[view["project"] == "Golden Pass T2"].iloc[0]
    assert golden["gs_fid_year"] == 2019
    gs = _goldman()
    compared = vendor_comparison(pd.concat(
        [gs[gs["project"] == "Golden Pass T2"], view[view["project"] == "Golden Pass T2"]],
        ignore_index=True,
    ))
    assert compared[0]["spread_months"] == 2
    assert compared[0]["gs_fid"] == "2019"

    wider = apply_filters(
        aligned, sources=["S&P Platts"], year_from=2024, year_to=2040,
        include_unmatched_platts=True,
    )
    assert len(wider) > len(view)
    assert "FLNG Hilli Episeyo" in note
    assert "Pluto LNG T2" not in note.split("No Platts train for:", 1)[-1]


def test_energy_aspects_snapshot_is_the_october_file():
    frame, statuses = load_snapshots()
    status = next(item for item in statuses if item["label"] == SOURCE_EA)
    assert status["state"] == "ok"
    assert status["as_of"] == "2026-10-02"
    assert "2 Oct 2026" in status["message"]
    ea = frame[frame["source"] == SOURCE_EA]
    assert len(ea) > 200
    assert "Cancelled" not in set(ea["status"])
    gabon = ea[ea["project"] == "Gabon LNG Terminal Train 1"].iloc[0]
    assert gabon["country"] == "Gabon"
    assert gabon["mtpa"] == pytest.approx(0.7)
    assert gabon["bcm_y"] == pytest.approx(0.9499)
    assert gabon["start_label"] == "2027-10"
    assert pd.Timestamp(gabon["fid_date"]) == pd.Timestamp("2023-02-16")
    assert present(ea[ea["project"] == "Gabon LNG Terminal Train 1"])["fid_display"].iloc[0] == "2023-02-16"
    assert "Bintulu LNG Terminal Train 1" not in set(ea["project"])


def test_energy_aspects_joins_goldman_names_in_the_comparison():
    frame, _statuses = load_snapshots()
    linked, _note = align_vendors(frame)
    gs = linked[linked["source"] == SOURCE_GS]
    ea = linked[linked["source"] == SOURCE_EA]
    nfe = gs[gs["project"] == "North Field East T1"].iloc[0]
    ea_nfe = ea[ea["project"] == "North Field East LNG Terminal Train 1"].iloc[0]
    assert ea_nfe["match_key"] == nfe["match_key"]

    fast = ea[ea["project"] == "Louisiana FLNG Train 1"].iloc[0]
    woodside = gs[gs["project"] == "Louisiana LNG T1"].iloc[0]
    assert fast["match_key"] != woodside["match_key"]

    compared = vendor_comparison(linked[linked["match_key"] == nfe["match_key"]])
    assert compared[0]["project"] == "North Field East T1"
    assert compared[0]["start__energy_aspects"] == "2027-08-22"
    assert compared[0]["mtpa__energy_aspects"] == pytest.approx(8.0)

    cap = gs[gs["project"] == "Cap Lopez LNG"].iloc[0]
    gabon = ea[ea["project"] == "Gabon LNG Terminal Train 1"].iloc[0]
    assert gabon["match_key"] == cap["match_key"]


def test_unmapped_platts_stacks_on_the_vendor_bar():
    rows = []
    for source, project, mtpa, mapped in (
        ("Goldman Sachs", "Pluto LNG T2", 5.0, True),
        ("S&P Platts", "Pluto LNG T2", 5.0, True),
        ("S&P Platts", "Kasuri FLNG", 1.2, False),
        ("S&P Platts", "LNG Canada T3", 7.0, False),
    ):
        rows.append({
            "source": source,
            "country": "Australia",
            "project": project,
            "mtpa": mtpa,
            "start_date": pd.Timestamp("2027-06-01"),
            "on_goldman": mapped,
        })
    fig = fig_by_source(pd.DataFrame(rows))
    by_name = {trace.name: trace for trace in fig.data}
    mapped = by_name["S&P Platts"]
    extra = by_name["S&P Platts (unmapped)"]
    assert float(mapped.y[0]) == pytest.approx(5.0)
    assert float(extra.y[0]) == pytest.approx(8.2)
    assert list(extra.base) == pytest.approx(list(mapped.y))
    assert extra.offsetgroup == mapped.offsetgroup
    assert extra.marker.pattern.shape == "/"


def test_country_subtitle_names_the_selection():
    from core.lng_supply_additions.callbacks import _country_subtitle

    assert _country_subtitle(None) == "All Countries"
    assert _country_subtitle([]) == "All Countries"
    assert _country_subtitle(["US", "Qatar"]) == "US, Qatar"


def test_cumulative_steps_up_in_the_startup_month():
    frame = pd.DataFrame([
        {
            "source": "Goldman Sachs",
            "country": "US",
            "mtpa": 5.0,
            "start_date": pd.Timestamp("2027-03-01"),
        },
        {
            "source": "Goldman Sachs",
            "country": "Qatar",
            "mtpa": 8.0,
            "start_date": pd.Timestamp("2027-06-15"),
        },
        {
            "source": "Energy Aspects",
            "country": "US",
            "mtpa": 4.0,
            "start_date": pd.Timestamp("2027-03-15"),
        },
    ])
    fig = fig_cumulative(frame)
    by_name = {trace.name: trace for trace in fig.data}

    def _by_month(trace) -> dict[str, float]:
        return {
            pd.Timestamp(x).strftime("%Y-%m"): float(y)
            for x, y in zip(trace.x, trace.y)
        }

    gs = _by_month(by_name["Goldman Sachs"])
    assert gs["2027-03"] == pytest.approx(5.0)
    assert gs["2027-04"] == pytest.approx(5.0)
    assert gs["2027-05"] == pytest.approx(5.0)
    assert gs["2027-06"] == pytest.approx(13.0)
    this_month = pd.Timestamp.today().strftime("%Y-%m")
    if this_month < "2027-03":
        assert min(gs) == this_month
        assert gs[this_month] == pytest.approx(0.0)
        assert gs["2027-02"] == pytest.approx(0.0)
    assert _by_month(by_name["Energy Aspects"])["2027-03"] == pytest.approx(4.0)


def test_cumulative_holds_zero_until_a_future_startup():
    ahead = (pd.Timestamp.today().normalize() + pd.DateOffset(months=8)).to_period("M").to_timestamp()
    later = ahead + pd.DateOffset(months=2)
    frame = pd.DataFrame([
        {
            "source": "Goldman Sachs",
            "country": "Qatar",
            "mtpa": 8.0,
            "start_date": ahead,
        },
        {
            "source": "Energy Aspects",
            "country": "Qatar",
            "mtpa": 8.0,
            "start_date": later,
        },
    ])
    fig = fig_cumulative(frame)
    this_month = pd.Timestamp.today().strftime("%Y-%m")
    startup = ahead.strftime("%Y-%m")
    before = (ahead - pd.DateOffset(months=1)).strftime("%Y-%m")

    def _by_month(trace) -> dict[str, float]:
        return {
            pd.Timestamp(x).strftime("%Y-%m"): float(y)
            for x, y in zip(trace.x, trace.y)
        }

    gs = _by_month(next(trace for trace in fig.data if trace.name == "Goldman Sachs"))
    ea = _by_month(next(trace for trace in fig.data if trace.name == "Energy Aspects"))
    assert min(gs) == this_month
    assert gs[this_month] == pytest.approx(0.0)
    assert gs[before] == pytest.approx(0.0)
    assert gs[startup] == pytest.approx(8.0)
    assert ea[startup] == pytest.approx(0.0)
    assert ea[later.strftime("%Y-%m")] == pytest.approx(8.0)


def test_cumulative_does_not_invent_a_zero_before_a_past_startup():
    started = (pd.Timestamp.today().normalize() - pd.DateOffset(months=3)).to_period("M").to_timestamp()
    frame = pd.DataFrame([
        {
            "source": "Goldman Sachs",
            "country": "Qatar",
            "mtpa": 8.0,
            "start_date": started,
        },
    ])
    fig = fig_cumulative(frame)
    months = [pd.Timestamp(x).strftime("%Y-%m") for x in fig.data[0].x]
    assert months[0] == started.strftime("%Y-%m")
    assert float(fig.data[0].y[0]) == pytest.approx(8.0)


def test_timeline_overlays_sources_on_the_same_project():
    frame = pd.DataFrame([
        {
            "source": "Goldman Sachs",
            "country": "Qatar",
            "project": "North Field East T1",
            "operator": "QatarEnergy",
            "mtpa": 8.0,
            "start_date": pd.Timestamp("2027-08-01"),
            "start_label": "2027-08",
            "match_key": "qatar|nfe-t1",
            "gs_fid_year": 2021,
        },
        {
            "source": "Energy Aspects",
            "country": "Qatar",
            "project": "NFE Train 1",
            "operator": "",
            "mtpa": 7.8,
            "start_date": pd.Timestamp("2027-11-15"),
            "start_label": "2027-11-15",
            "match_key": "qatar|nfe-t1",
        },
        {
            "source": "S&P Platts",
            "country": "Qatar",
            "project": "North Field East T1",
            "operator": "QatarEnergy",
            "mtpa": 8.0,
            "start_date": pd.Timestamp("2028-01-01"),
            "start_label": "2028-01",
            "match_key": "qatar|nfe-t1",
        },
    ])
    fig = fig_timeline(frame, show_fid=True, overlay=True)
    by_name = {trace.name: trace for trace in fig.data}
    assert set(by_name) == {"Goldman Sachs", "Energy Aspects", "S&P Platts", "FID"}
    row = "Qatar  ·  North Field East T1"
    for source in ("Goldman Sachs", "Energy Aspects", "S&P Platts"):
        assert list(by_name[source].y) == [row]
    assert by_name["Goldman Sachs"].marker.symbol == "circle"
    assert by_name["Energy Aspects"].marker.symbol == "square"
    assert by_name["S&P Platts"].marker.symbol == "triangle-up"
    assert by_name["FID"].marker.symbol == "diamond"
    assert fig.layout.showlegend is True
    assert pd.Timestamp(by_name["Goldman Sachs"].x[0]) == pd.Timestamp("2027-08-01")
    assert pd.Timestamp(by_name["Energy Aspects"].x[0]) == pd.Timestamp("2027-11-15")


def test_charts_and_layout_build_from_the_snapshot():
    frame = _goldman()
    country = fig_by_country(frame)
    assert "US" in [trace.name for trace in country.data]
    vendor = fig_by_source(frame)
    cumulative = fig_cumulative(frame)
    timeline = fig_timeline(frame)
    assert len(vendor.data) == 1
    assert len(cumulative.data) == 1
    assert all(trace.mode == "markers" for trace in timeline.data)
    fid = [trace for trace in timeline.data if trace.name == "GS FID"]
    assert fid and "diamond" in str(fid[0].marker.symbol)
    for fig in (country, vendor, cumulative, timeline):
        assert any(getattr(shape.line, "dash", None) == "dash" for shape in fig.layout.shapes)
    pytest.importorskip("dash")
    from core.lng_supply_additions.layout import build_layout
    assert build_layout() is not None
