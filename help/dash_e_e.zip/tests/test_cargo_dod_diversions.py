"""Inbound vs outbound diversion tagging for Cargo DoD."""
from __future__ import annotations

from datetime import date, datetime

import pandas as pd

from core.cargo_dod.compare import _diff_record, compare_snapshots
from core.cargo_dod.data import comparison_date


def _cargo(**overrides) -> pd.Series:
    row = {
        "Vessel": "AL KHARRARAH",
        "IMO": 1,
        "KplerVesselId": 10,
        "Volume(mcm)": 100.0,
        "FromCountry": "Qatar",
        "DepartureDate": pd.Timestamp("2026-10-01"),
        "ToCountry": "Bangladesh",
        "ToTerminal": "Maheshkhali",
        "ToContinent": "Asia",
        "DestinationDate": pd.Timestamp("2026-10-20"),
        "Source": "AIS",
        "Confidence": 0.9,
        "Status": "In Transit",
        "FloatingStorage": 0,
    }
    row.update(overrides)
    return pd.Series(row)


def _frame(*rows: pd.Series) -> pd.DataFrame:
    return pd.DataFrame(list(rows))


def test_comparison_date_is_previous_day_or_friday_on_monday():
    assert comparison_date(date(2026, 10, 9)) == date(2026, 10, 8)
    assert comparison_date(date(2026, 10, 12)) == date(2026, 10, 9)


def test_ais_country_change_into_zone_is_inbound_diversion():
    prev = _cargo(ToCountry="Bangladesh", Source="AIS")
    curr = _cargo(ToCountry="Belgium", ToTerminal="Zeebrugge",
                  ToContinent="Europe", Source="AIS")
    record = _diff_record(curr, prev, floating=False, diversion_direction="in")
    assert record["diversion"] == "in"


def test_model_move_into_zone_is_not_a_diversion():
    prev = _cargo(ToCountry="Bangladesh", Source="Model")
    curr = _cargo(ToCountry="Belgium", Source="AIS")
    record = _diff_record(curr, prev, floating=False, diversion_direction="in")
    assert record["diversion"] is None


def test_outbound_ais_move_is_a_diversion_even_if_source_stays_ais():
    prev = _cargo(ToCountry="Belgium", Source="AIS")
    stayed_ais = _cargo(ToCountry="Bangladesh", Source="AIS")
    became_model = _cargo(ToCountry="Bangladesh", Source="Model", Confidence=0.2)
    was_model = _cargo(ToCountry="Bangladesh", Source="Model")
    assert _diff_record(
        stayed_ais, prev, floating=False, diversion_direction="out"
    )["diversion"] == "out"
    assert _diff_record(
        became_model, prev, floating=False, diversion_direction="out"
    )["diversion"] == "out"
    assert _diff_record(
        was_model, _cargo(ToCountry="Belgium", Source="Model"),
        floating=False, diversion_direction="out",
    )["diversion"] is None


def test_compare_counts_kharrarah_style_move_as_into_zone():
    prev = _frame(_cargo(
        Vessel="AL KHARRARAH", ToCountry="Bangladesh", Source="AIS"))
    curr = _frame(_cargo(
        Vessel="AL KHARRARAH", ToCountry="Belgium", ToTerminal="Zeebrugge",
        ToContinent="Europe", Source="AIS"))
    empty_hist = curr.iloc[0:0].copy()
    result = compare_snapshots(
        curr, prev, empty_hist,
        countries=["Belgium", "Netherlands"],
        prev_snapshot_dt=datetime(2026, 10, 8, 6, 0),
    )
    assert result["summary"]["n_diversions_in"] == 1
    assert result["summary"]["n_diversions_out"] == 0
    assert result["relocated_in"][0]["diversion"] == "in"
    assert result["relocated_in"][0]["vessel"] == "AL KHARRARAH"
