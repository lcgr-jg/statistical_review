"""YoY Persian Gulf import charts: zero months and the open month."""
from __future__ import annotations

import pandas as pd

from core.lng_data_kpler.qatar_exports import monthly_imports_by_destination_arrival
from core.qatar_monitor.gulf_charts import build_gulf_yoy_import_chart


def _trace(fig, name):
    return next(t for t in fig.data if t.name == name)


def test_current_year_zero_months_extend_to_the_open_month():
    monthly = pd.DataFrame(
        {
            "volume_mcm": [144.0, 90.0],
            "delivered_mcm": [144.0, 90.0],
            "forecast_mcm": [0.0, 0.0],
        },
        index=pd.to_datetime(["2026-06-01", "2026-07-01"]),
    )
    fig = build_gulf_yoy_import_chart(
        monthly,
        country_label="UAE",
        as_of=pd.Timestamp("2026-10-15"),
    )
    y = list(_trace(fig, "2026").y)
    # Aug and Sep had no arrivals; the line stays at zero through them.
    assert y[7] == 0.0
    assert y[8] == 0.0
    # October is the incomplete month, drawn on the dashed segment only.
    assert y[9] is None
    dashed = _trace(fig, "2026 incomplete")
    assert list(dashed.x) == [9, 10]
    assert dashed.line.dash == "dash"
    assert list(dashed.y) == [0.0, 0.0]


def test_open_month_hover_splits_delivered_and_forecast():
    monthly = pd.DataFrame(
        {
            "volume_mcm": [1085.0, 397.0],
            "delivered_mcm": [1085.0, 0.0],
            "forecast_mcm": [0.0, 397.0],
        },
        index=pd.to_datetime(["2026-09-01", "2026-10-01"]),
    )
    fig = build_gulf_yoy_import_chart(
        monthly,
        country_label="Kuwait",
        as_of=pd.Timestamp("2026-10-01"),
    )
    hover = _trace(fig, "2026 to date").hovertemplate
    assert "Delivered: 0 mcm" in hover
    assert "Forecasted: 397 mcm" in hover
    assert "Oct incomplete" in hover


def test_monthly_imports_split_in_transit_as_forecast():
    trades = pd.DataFrame([
        {
            "Trade status": "Delivered",
            "Country (destination)": "Kuwait",
            "Date (destination)": "2026-09-20",
            "Volume (origin m3)": 100_000,
            "Volume (destination m3)": 100_000,
        },
        {
            "Trade status": "In Transit",
            "Country (destination)": "Kuwait",
            "Date (destination)": "2026-10-06",
            "Volume (origin m3)": 50_000,
            "Volume (destination m3)": 50_000,
        },
        {
            "Trade status": "Scheduled",
            "Country (destination)": "Kuwait",
            "Date (destination)": "2026-10-20",
            "Volume (origin m3)": 80_000,
            "Volume (destination m3)": 80_000,
        },
    ])
    out = monthly_imports_by_destination_arrival(trades, "Kuwait")
    october = out.loc[pd.Timestamp("2026-10-01")]
    assert october["delivered_mcm"] == 0.0
    assert october["forecast_mcm"] > 0
    assert october["volume_mcm"] == october["forecast_mcm"]
    assert pd.Timestamp("2026-09-01") in out.index
