"""Gulf outflow: lag-aligned Kuwait/UAE arrivals vs Qatar exports."""
from __future__ import annotations

import pandas as pd

from core.lng_data_kpler.qatar_exports import (
    KPLER_M3_TO_MCM,
    daily_imports_by_destination_arrival,
    daily_unassigned_destination_exports,
)
from core.qatar_monitor.gulf_outflow import (
    build_gulf_flow_frame,
    build_gulf_outflow_chart,
    gulf_flow_to_records,
    records_to_gulf_flow,
)


def _trades(rows: list[dict]) -> pd.DataFrame:
    base = {
        "Trade status": "Delivered",
        "Volume (origin m3)": 100_000,
        "Volume (destination m3)": 100_000,
        "Country (destination)": "Kuwait",
        "Date (origin)": "2026-06-01 12:00",
        "Date (destination)": "2026-06-02 12:00",
    }
    return pd.DataFrame([{**base, **row} for row in rows])


def test_kuwait_arrival_shifts_back_one_day():
    trades = _trades([
        {
            "Date (destination)": "2026-06-03 15:00",
            "Country (destination)": "Kuwait",
        }
    ])
    series = daily_imports_by_destination_arrival(trades, "Kuwait", lag_days=1.0)
    assert list(series.index) == [pd.Timestamp("2026-06-02")]
    assert series.iloc[0] == 100_000 * KPLER_M3_TO_MCM


def test_uae_half_day_lag_can_land_on_previous_day():
    trades = _trades([
        {
            "Date (destination)": "2026-06-02 06:00",
            "Country (destination)": "United Arab Emirates",
        }
    ])
    series = daily_imports_by_destination_arrival(
        trades, "United Arab Emirates", lag_days=0.5
    )
    # 06:00 minus 12 hours is the previous evening.
    assert list(series.index) == [pd.Timestamp("2026-06-01")]


def test_scheduled_and_named_destinations_are_not_unassigned():
    trades = _trades([
        {"Trade status": "Scheduled", "Country (destination)": None},
        {
            "Country (destination)": None,
            "Date (origin)": "2026-06-04 08:00",
            "Volume (origin m3)": 50_000,
        },
        {"Country (destination)": "Kuwait", "Date (origin)": "2026-06-04 18:00"},
    ])
    series = daily_unassigned_destination_exports(trades)
    assert list(series.index) == [pd.Timestamp("2026-06-04")]
    assert series.iloc[0] == 50_000 * KPLER_M3_TO_MCM


def test_flow_frame_remainder_and_roundtrip():
    day = pd.date_range("2026-02-01", periods=40, freq="D")
    exports = pd.DataFrame({"date": day, "value": 100.0})
    trades = _trades([
        {
            "Date (origin)": "2026-02-10 12:00",
            "Date (destination)": "2026-02-11 12:00",
            "Country (destination)": "Kuwait",
            "Volume (origin m3)": 1 / KPLER_M3_TO_MCM,  # 1 mcm
            "Volume (destination m3)": 1 / KPLER_M3_TO_MCM,
        },
        {
            "Date (origin)": "2026-02-10 12:00",
            "Date (destination)": None,
            "Country (destination)": None,
            "Volume (origin m3)": 2 / KPLER_M3_TO_MCM,
            "Volume (destination m3)": None,
        },
    ])
    frame = build_gulf_flow_frame(trades, exports)
    assert frame.loc[pd.Timestamp("2026-02-10"), "exports"] == 100.0
    # Arrival 11th minus 1 day lands on the 10th.
    assert frame.loc[pd.Timestamp("2026-02-10"), "kuwait"] == 1.0
    assert frame.loc[pd.Timestamp("2026-02-10"), "unassigned"] == 2.0
    assert frame.loc[pd.Timestamp("2026-02-11"), "kuwait"] == 0.0

    restored = records_to_gulf_flow(gulf_flow_to_records(frame))
    pd.testing.assert_series_equal(
        restored["kuwait"],
        frame["kuwait"],
        check_names=False,
        check_freq=False,
    )


def test_chart_title_uses_selected_window():
    day = pd.date_range("2026-01-01", periods=80, freq="D")
    frame = pd.DataFrame(
        {
            "exports": 40.0,
            "kuwait": 10.0,
            "uae": 0.0,
            "unassigned": 15.0,
        },
        index=day,
    )
    frame.index.name = "date"
    fig = build_gulf_outflow_chart(frame, window=14)
    title = fig.layout.title.text
    assert "14d average" in title
    subplot_titles = [a.text for a in fig.layout.annotations if a.text]
    assert any("14d MA" in text and "Kuwait" in text for text in subplot_titles)
    assert any("14d MA" in text and "leaving the Gulf" in text for text in subplot_titles)
    assert "exports 40 mcm/d" in title
    assert "Kuwait+UAE 10" in title
    assert "leaving 30 (75%)" in title
    assert "no destination 15" in title
    names = [t.name for t in fig.data]
    assert "Qatar exports" in names
    assert "Leaving, % of exports" in names
