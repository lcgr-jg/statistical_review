"""Tests for LNG netbacks calc, occupancy, and date snapping."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from core.lng_netbacks.calc import (
    aggregate_curve,
    aggregate_panel_quarters,
    build_jkm_tfu_table,
    build_occupancy,
    compute_netbacks,
    curve_on_date,
    freight_route_coeffs,
    front_month_ranks,
    overlay_trade_dates,
    snap_to_trade_date,
    total_freight,
)
from core.lng_netbacks.constants import (
    COL_ASIA_VS_EU,
    COL_FRT_NL,
    COL_FRT_PANAMA,
    COL_FRT_SK,
    COL_FRT_SUEZ,
    COL_JKM_SHIFTED,
    COL_JKM_TFU,
    COL_NL_PROFIT,
    COL_PANAMA_VS_EU,
    FREIGHT_CONSTANTS,
    FREIGHT_FORWARD,
    FREIGHT_SPOT,
    FREIGHT_SUNK,
    PORT_COSTS,
    VOYAGES,
)
from core.lng_netbacks.data import attach_spot_freight, pivot_ice_strips


def test_freight_coeffs_match_hand_calculation():
    voyage_days = VOYAGES["us>nl"]
    k_b, k_c, k_f = freight_route_coeffs(
        voyage_days, port_cost=PORT_COSTS["nl"], canal_toll=0.0)

    fc = FREIGHT_CONSTANTS
    loaded = 165000 * fc["energy_content"] * fc["fillable_volume"]
    total_days = voyage_days + fc["days_in_port"]
    total_days2 = total_days + fc["days_in_port"]
    heel = loaded * total_days * fc["boiloffrate_ballast"]
    delivered = loaded * (1 - fc["boiloffrate_laden"]) ** total_days - heel
    laden = loaded - heel - delivered
    bunker_qty = (
        fc["bunker_consumption_rate"] * total_days2
        - heel / fc["bunker_fuel_energy_content"]
    )
    bunker_cost = bunker_qty * fc["bunker_price"] / delivered
    expect_b = (heel + laden) / delivered
    expect_c = 2 * total_days / delivered
    expect_f = bunker_cost + fc["insurance_usd_per_day"] * expect_c + PORT_COSTS["nl"]

    assert k_b == pytest.approx(expect_b)
    assert k_c == pytest.approx(expect_c)
    assert k_f == pytest.approx(expect_f)

    hub = pd.Series([4.0, 5.0])
    dayrate = pd.Series([80_000.0, 90_000.0])
    got = total_freight(hub, dayrate, voyage_days, PORT_COSTS["nl"])
    expect = hub * expect_b + dayrate * expect_c + expect_f
    pd.testing.assert_series_equal(got, expect, check_names=False)


def _panel_two_dates() -> pd.DataFrame:
    """Two trade dates, four delivery months. Distinct JKM so a global shift fails."""
    deliveries = pd.to_datetime(["2026-10-01", "2026-11-01", "2026-12-01", "2027-01-01"])
    rows = []
    for trade, jkm0, tfu0, hh0, spark in (
        ("2026-09-01", 12.0, 10.0, 3.0, 70_000.0),
        ("2026-09-02", 22.0, 11.0, 3.5, 72_000.0),
    ):
        for i, d in enumerate(deliveries):
            rows.append({
                "TRADE_DATE": pd.Timestamp(trade),
                "STRIP": d.strftime("%b%y"),
                "DELIVERY_START": d,
                "HH": hh0 + 0.1 * i,
                "JKM": jkm0 + i,
                "TFU": tfu0 + 0.2 * i,
                "TTF": 30.0,
                "Spark25S": spark + 500 * i,
                "Spark30S": spark + 400 * i,
                "platts_asia": 75_000.0,
                "platts_atlantic": 68_000.0,
            })
    return pd.DataFrame(rows)


def test_jkm_shift_is_per_trade_date():
    panel = _panel_two_dates()
    out = compute_netbacks(panel, freight_mode=FREIGHT_FORWARD)
    d1 = out.loc[out["TRADE_DATE"] == pd.Timestamp("2026-09-01")]
    oct_row = d1.loc[d1["DELIVERY_START"] == pd.Timestamp("2026-10-01")].iloc[0]
    # Next month on the SAME trade date is JKM 13, not 22 from the next day.
    assert oct_row[COL_JKM_SHIFTED] == pytest.approx(13.0)


def test_vectorized_panel_matches_single_date_slice():
    panel = _panel_two_dates()
    full = compute_netbacks(panel, freight_mode=FREIGHT_FORWARD)
    one = compute_netbacks(
        panel.loc[panel["TRADE_DATE"] == pd.Timestamp("2026-09-01")],
        freight_mode=FREIGHT_FORWARD,
    )
    cols = [COL_NL_PROFIT, COL_ASIA_VS_EU, COL_JKM_TFU]
    a = (full.loc[full["TRADE_DATE"] == pd.Timestamp("2026-09-01")]
         .set_index("DELIVERY_START")[cols].sort_index())
    b = one.set_index("DELIVERY_START")[cols].sort_index()
    pd.testing.assert_frame_equal(a, b)


def test_spot_freight_uses_platts_not_spark():
    panel = _panel_two_dates()
    fwd = compute_netbacks(panel, freight_mode=FREIGHT_FORWARD)
    spot = compute_netbacks(panel, freight_mode=FREIGHT_SPOT)
    # Same prices, different freight → profits should differ.
    assert not np.allclose(
        fwd[COL_NL_PROFIT].to_numpy(), spot[COL_NL_PROFIT].to_numpy())


def test_sunk_freight_is_zero_and_premium_is_shifted_jkm_minus_tfu():
    panel = _panel_two_dates()
    sunk = compute_netbacks(panel, freight_mode=FREIGHT_SUNK)
    freight_cols = [COL_FRT_NL, COL_FRT_SK, COL_FRT_PANAMA, COL_FRT_SUEZ]
    assert (sunk[freight_cols] == 0).all().all()
    expected = sunk[COL_JKM_SHIFTED] - sunk["TFU"]
    pd.testing.assert_series_equal(
        sunk[COL_ASIA_VS_EU].reset_index(drop=True),
        expected.reset_index(drop=True),
        check_names=False,
    )
    pd.testing.assert_series_equal(
        sunk[COL_PANAMA_VS_EU].reset_index(drop=True),
        expected.reset_index(drop=True),
        check_names=False,
    )


def test_snap_to_trade_date_weekend_and_empty():
    dates = pd.to_datetime(["2026-09-17", "2026-09-18", "2026-09-21"])  # Thu Fri Mon
    assert snap_to_trade_date("2026-09-20", dates) == pd.Timestamp("2026-09-18")
    assert snap_to_trade_date("2026-09-18", dates) == pd.Timestamp("2026-09-18")
    assert snap_to_trade_date("2026-09-16", dates) is None
    assert snap_to_trade_date("2026-09-20", []) is None


def test_overlay_trade_dates_skips_as_of_and_duplicates():
    dates = pd.to_datetime(["2026-09-01", "2026-09-02", "2026-09-08", "2026-09-15"])
    ov = overlay_trade_dates("2026-09-15", dates, offsets=(1, 7, 14, 28))
    assert pd.Timestamp("2026-09-15") not in ov
    assert len(ov) == len(set(ov))
    assert pd.Timestamp("2026-09-08") in ov
    assert pd.Timestamp("2026-09-01") in ov


def test_occupancy_empty_history():
    occ, summary = build_occupancy(pd.DataFrame(), COL_JKM_TFU)
    assert occ.empty and summary.empty


def test_occupancy_buckets_tenors_and_expired():
    # 4 tenors, last 5 days. Front 2 on latest date; 1 expired tenor.
    tenors = pd.to_datetime(["2026-07-01", "2026-08-01", "2026-09-01", "2026-10-01"])
    strips = ["Jul26", "Aug26", "Sep26", "Oct26"]
    rows = []
    for i, trade in enumerate(pd.date_range("2026-09-01", periods=5, freq="D")):
        for j, (d, s) in enumerate(zip(tenors, strips)):
            # Sep/Oct still on the curve on last day; Jul expired relative to Sep front.
            if trade == pd.Timestamp("2026-09-05") and d < pd.Timestamp("2026-09-01"):
                continue
            rows.append({
                "TRADE_DATE": trade,
                "STRIP": s,
                "DELIVERY_START": d,
                COL_JKM_TFU: 0.1 * j + (0.4 if i >= 3 else 0.0),
            })
    df = pd.DataFrame(rows)
    occ, summary = build_occupancy(
        df, COL_JKM_TFU,
        lookback_days=90, bucket_size=0.25, n_tenors=2, n_expired=1,
        as_of="2026-09-05",
    )
    assert not occ.empty
    labels = list(occ.index)
    assert any(lbl.startswith("Sep") for lbl in labels)
    assert any(lbl.startswith("Oct") for lbl in labels)
    assert bool(summary["expired"].any())
    assert (occ.values >= 0).all()
    assert summary["latest"].notna().all()


def test_curve_on_date_indexes_delivery_start():
    panel = compute_netbacks(_panel_two_dates(), freight_mode=FREIGHT_FORWARD)
    sl = curve_on_date(panel, "2026-09-01")
    assert sl.index.name == "DELIVERY_START"
    assert pd.Timestamp("2026-10-01") in sl.index


def test_jkm_tfu_table_has_latest_and_delta():
    panel = compute_netbacks(_panel_two_dates(), freight_mode=FREIGHT_FORWARD)
    snapshots = {
        pd.Timestamp("2026-09-02"): curve_on_date(panel, "2026-09-02"),
        pd.Timestamp("2026-09-01"): curve_on_date(panel, "2026-09-01"),
    }
    table = build_jkm_tfu_table(snapshots)
    assert not table.empty
    assert table.shape[1] == 2
    assert table.columns[0] == "02 Sep"
    assert table.columns[1].startswith("vs ")


def test_pivot_ice_strips_drops_hyphen_strips():
    raw = pd.DataFrame({
        "TRADE_DATE": ["2026-09-01"] * 3,
        "STRIP": ["Oct26", "Q4-26", "Sum-26"],
        "DELIVERY_START": pd.to_datetime(["2026-10-01", "2026-10-01", "2026-04-01"]),
        "COMMODITY": ["JKM", "JKM", "JKM"],
        "SETTLEMENT_PRICE": [10.0, 11.0, 12.0],
        "STRIP_TYPE": ["Month", "Month", "Month"],
    })
    pivoted = pivot_ice_strips(raw)
    assert list(pivoted["STRIP"]) == ["Oct26"]
    assert "JKM" in pivoted.columns


def test_attach_spot_freight_ffills_prior_day():
    ice = pd.DataFrame({
        "TRADE_DATE": pd.to_datetime(["2026-09-02", "2026-09-02"]),
        "STRIP": ["Oct26", "Nov26"],
        "DELIVERY_START": pd.to_datetime(["2026-10-01", "2026-11-01"]),
        "HH": [3.0, 3.1],
    })
    platts = pd.DataFrame({
        "LNG Asia Pacific Carrier Day Rate": [80_000.0],
        "LNG Atlantic Carrier Day Rate": [70_000.0],
    }, index=pd.to_datetime(["2026-09-01"]))
    out = attach_spot_freight(ice, platts)
    assert (out["platts_atlantic"] == 70_000.0).all()
    assert (out["platts_asia"] == 80_000.0).all()


def test_aggregate_curve_averages_months_into_quarters():
    idx = pd.to_datetime(["2026-10-01", "2026-11-01", "2026-12-01", "2027-01-01"])
    df = pd.DataFrame({"premium": [1.0, 2.0, 3.0, 10.0]}, index=idx)
    out = aggregate_curve(df)
    assert list(out.index) == [pd.Timestamp("2026-10-01"), pd.Timestamp("2027-01-01")]
    assert out.loc[pd.Timestamp("2026-10-01"), "premium"] == pytest.approx(2.0)
    assert out.loc[pd.Timestamp("2027-01-01"), "premium"] == pytest.approx(10.0)


def test_panel_quarters_front_quarter_is_mean_of_its_months():
    rows = []
    for trade in ("2026-09-01", "2026-09-02"):
        for i, delivery in enumerate(pd.date_range("2026-10-01", periods=4, freq="MS")):
            rows.append({
                "TRADE_DATE": pd.Timestamp(trade),
                "DELIVERY_START": delivery,
                "premium": float(i + 1),
            })
    ranked = front_month_ranks(aggregate_panel_quarters(pd.DataFrame(rows)), n_tenors=2)
    front = ranked.loc[ranked["tenor_rank"] == 0]
    assert set(front["STRIP"]) == {"Q4-26"}
    assert front["premium"].iloc[0] == pytest.approx(2.0)
    nxt = ranked.loc[ranked["tenor_rank"] == 1]
    assert set(nxt["STRIP"]) == {"Q1-27"}
    assert nxt["premium"].iloc[0] == pytest.approx(4.0)


def test_seasonal_range_carries_last_quote_across_missing_days():
    from core.lng_netbacks.charts import _seasonal_range_band

    # 2022 prints 400 only on Mondays. 2023 prints 50 on the Wednesday between them.
    # Without carrying the last quote forward, Wednesday's max would be 50.
    frame = pd.DataFrame({
        "value": [400.0, 50.0, 400.0],
        "year": [2022, 2023, 2022],
        "x": pd.to_datetime(["2024-10-07", "2024-10-09", "2024-10-14"]),
    })
    band = _seasonal_range_band(frame)
    wed = pd.Timestamp("2024-10-09")
    assert band.loc[wed, "max"] == pytest.approx(400.0)
    assert band.loc[wed, "min"] == pytest.approx(50.0)
    assert band.loc[pd.Timestamp("2024-10-08"), "max"] == pytest.approx(400.0)
