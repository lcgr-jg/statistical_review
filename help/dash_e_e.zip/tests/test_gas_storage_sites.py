"""Tests for storage site curve preview helpers."""
import pandas as pd

from core.gas_storage_sites.charts import fitted_curve_xy, site_chart_title
from core.gas_storage_sites.data import frame_from_records, timeseries_records
from jain_commods.fundamental.gas.storage_params import classify_site


def test_fitted_curve_injection_declines():
    x, y = fitted_curve_xy("injection", p_or_q=1.0, rate_max=10.0)
    assert y[0] > y[-1]


def test_fitted_curve_withdrawal_rises():
    x, y = fitted_curve_xy("withdrawal", p_or_q=1.0, rate_max=10.0)
    assert y[0] < y[-1]


def test_timeseries_roundtrip():
    df = pd.DataFrame(
        {
            "stock": [10.0, 11.0],
            "stockcapacity": [100.0, 100.0],
            "injection": [1.0, 0.5],
            "withdrawal": [0.0, 0.2],
        },
        index=pd.to_datetime(["2024-01-01", "2024-01-02"]),
    )
    records = timeseries_records(df)
    back = frame_from_records(records)
    assert list(back.columns) == ["stock", "stockcapacity", "injection", "withdrawal"]
    assert len(back) == 2


def test_classify_used_by_page():
    assert classify_site(10) == "SRS"
    assert classify_site(80) == "LRS"


def test_site_chart_title_includes_name_and_country():
    assert site_chart_title("Fill %") == "Fill %"
    assert site_chart_title("Fill %", {"site_name": "Rehden"}) == "Fill % — Rehden"
    assert (
        site_chart_title("Fill %", {"site_name": "Rehden", "country": "DE"})
        == "Fill % — Rehden (DE)"
    )
