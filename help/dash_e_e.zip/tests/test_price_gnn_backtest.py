"""Tests for the Price GNN backtest readers and derived views.

Everything runs against a local mirror of the S3 layout (``PRICE_GNN_LOCAL``),
so the real read path -- key construction, index-first run resolution, optional
tables, missing files -- is exercised without touching S3.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from portal_pages.price_gnn import compute, figures, store

ZONES = ("de", "fr", "gb")


def _hourly(start="2025-01-01", end="2025-02-01", zones=ZONES,
            walk_forward=False) -> pd.DataFrame:
    """hourly.parquet-shaped frame: one row per (hour, zone), naive UTC."""
    idx = pd.date_range(start, end, freq="h", inclusive="left")
    rng = np.random.default_rng(4)
    frames = []
    for i, zone in enumerate(zones):
        true = 80 + 20 * np.sin(np.arange(len(idx)) / 24 * 2 * np.pi) + 5 * i
        pred = true + rng.normal(0, 6, len(idx))
        frame = pd.DataFrame({
            "timestamp": idx,
            "border": zone,
            "split": "test",
            "y_true": true,
            "y_pred": pred,
            "regime": 4,
            "denom": 70.0,
        })
        if walk_forward:
            origin = idx.floor("D").to_series().dt.to_period("W").dt.start_time
            frame["origin"] = origin.values
            frame["lead_days"] = (idx.floor("D") - origin.values).days
        else:
            frame["y_baseline"] = true + rng.normal(0, 9, len(idx))
            frame["y_persist"] = np.roll(true, 24)
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def _metrics(zones=ZONES) -> pd.DataFrame:
    rows = []
    for model in ("gnn", "baseline"):
        for split in ("train", "test"):
            for i, zone in enumerate(zones):
                rows.append({
                    "split": split, "border": zone, "n": 744,
                    "rmse": 6.0 + i + (2 if model == "baseline" else 0),
                    "mae": 4.5 + i, "r2": 0.7 - 0.05 * i,
                    "sign_accuracy": 0.8, "mean_abs_flow": 80.0,
                    "rmse_norm": 0.09, "mae_norm": 0.06,
                    "skill_vs_persistence": 0.3, "skill_vs_baseline": 0.1,
                    "model": model,
                })
    return pd.DataFrame(rows)


def _meta(run_id: str, kind: str = "fixed_split", zones=ZONES) -> dict:
    return {
        "run_id": run_id, "kind": kind, "component": "flow_gnn_price_research",
        "published_at": "2026-09-17T13:24:45", "target_kind": "price",
        "preset": "v6", "graph": "PRICE_EXTENDED", "zones": list(zones),
        "window": {"start": "2019-01-01 00:00:00", "end": "2026-06-01 00:00:00"},
        "train": {"test_start": "2025-01-01", "epochs": 30, "seed": 42},
        "git": {"sha": "9f32151dfc1a", "branch": "master", "dirty": True},
        "command": "flow-gnn train-price --v6", "trained_at": "2026-07-28T14:24:34",
        "python": "3.11.15", "splits": ["test"], "n_rows": 2232,
        "test_start": "2025-01-01 00:00:00", "test_end": "2025-02-01 00:00:00",
        "headline": {
            "gnn": {"n": 2232, "rmse": 6.0, "mae": 4.6, "r2": 0.70,
                    "mean_zone_r2": 0.66},
            "baseline": {"n": 2232, "rmse": 9.0, "mae": 7.0, "r2": 0.55},
            "persistence": {"n": 2232, "rmse": 12.0, "mae": 9.0, "r2": 0.30},
        },
        "zone_r2": {z: 0.7 - 0.05 * i for i, z in enumerate(zones)},
        "files": ["metrics.parquet", "hourly.parquet", "run_meta.json"],
        "note": "Single train/test split scored on realised fundamentals.",
    }


@pytest.fixture(autouse=True)
def no_s3(monkeypatch):
    """Keep every test on the local mirror; never reach for real S3."""
    monkeypatch.setattr(store, "_s3_client", lambda: None)


@pytest.fixture
def mirror(tmp_path, monkeypatch):
    """Local mirror with two runs: a fixed split and a walk-forward."""
    root = tmp_path / "flow_gnn_price_research"
    bt = root / "backtest"

    fixed = bt / "run_id=price_v6_new"
    fixed.mkdir(parents=True)
    _hourly().to_parquet(fixed / "hourly.parquet")
    (fixed / "run_meta.json").write_text(json.dumps(_meta("price_v6_new")))
    _metrics().to_parquet(fixed / "metrics.parquet")

    wf = bt / "run_id=v6_wf14"
    wf.mkdir(parents=True)
    _hourly(walk_forward=True).to_parquet(wf / "hourly.parquet")
    wf_meta = _meta("v6_wf14", kind="walk_forward")
    wf_meta.pop("note")          # exercise the page's own framing fallback
    wf_meta["backtest"] = {
        "overall": {"pooled_r2": 0.71, "rmse": 6.4, "n_origins": 5,
                    "n_days": 31, "n_zones_scored": 3},
        "config": {"cadence_days": 14, "block_days": 14, "window": "expanding"},
    }
    (wf / "run_meta.json").write_text(json.dumps(wf_meta))
    pd.DataFrame({"lead_days": [0, 1, 2, 3], "n": [72, 72, 72, 72],
                  "r2": [0.74, 0.72, 0.68, 0.61],
                  "rmse": [5.8, 6.1, 6.6, 7.4], "mae": [4.2, 4.4, 4.9, 5.5],
                  "rmse_norm": [0.08, 0.09, 0.09, 0.10]}
                 ).to_parquet(wf / "by_lead.parquet")

    index = {
        "component": "flow_gnn_price_research",
        "updated_at": "2026-09-17T13:24:45",
        "runs": {
            "price_v6_new": {
                "run_id": "price_v6_new", "kind": "fixed_split", "preset": "v6",
                "graph": "PRICE_EXTENDED", "n_zones": 3,
                "test_start": "2025-01-01 00:00:00",
                "test_end": "2025-02-01 00:00:00", "n_rows": 2232,
                "rmse": 6.0, "r2": 0.70, "mean_zone_r2": 0.66,
                "trained_at": "2026-07-28T14:24:34",
                "published_at": "2026-09-01T09:00:00", "git_sha": "9f32151dfc1a",
            },
            "v6_wf14": {
                "run_id": "v6_wf14", "kind": "walk_forward", "preset": "v6",
                "graph": "PRICE_EXTENDED", "n_zones": 3,
                "test_start": "2025-01-01 00:00:00",
                "test_end": "2025-02-01 00:00:00", "n_rows": 2232,
                "rmse": 6.4, "r2": 0.71, "mean_zone_r2": 0.67,
                "trained_at": "2026-09-10T10:00:00",
                "published_at": "2026-09-17T13:24:45", "git_sha": "abc123def456",
            },
        },
    }
    (bt / "index.json").write_text(json.dumps(index))

    monkeypatch.setenv("PRICE_GNN_LOCAL", str(root))
    for fn in (store.backtest_index, store._load_backtest_hourly,
               store._backtest_meta, store._load_backtest_table,
               compute._backtest_contracts):
        fn.invalidate_all()
    yield root
    for fn in (store.backtest_index, store._load_backtest_hourly,
               store._backtest_meta, store._load_backtest_table,
               compute._backtest_contracts):
        fn.invalidate_all()


# ---------------------------------------------------------------------------
# Index and run resolution
# ---------------------------------------------------------------------------

class TestIndex:
    def test_runs_are_listed_newest_published_first(self, mirror):
        runs = store.list_backtest_runs()
        assert [r["run_id"] for r in runs] == ["v6_wf14", "price_v6_new"]

    def test_default_run_is_the_newest_not_the_old_constant(self, mirror):
        assert store.resolve_backtest_run() == "v6_wf14"
        assert store.resolve_backtest_run("price_v6_new") == "price_v6_new"

    def test_missing_index_falls_back_without_raising(self, tmp_path,
                                                      monkeypatch):
        monkeypatch.setenv("PRICE_GNN_LOCAL", str(tmp_path))
        store.backtest_index.invalidate_all()
        assert store.backtest_index() == {"runs": {}}
        assert store.list_backtest_runs() == []
        assert store.resolve_backtest_run() == store.FALLBACK_BACKTEST_RUN
        store.backtest_index.invalidate_all()

    def test_run_entry_carries_index_fields(self, mirror):
        entry = store.backtest_run_entry("price_v6_new")
        assert entry["kind"] == "fixed_split"
        assert entry["n_rows"] == 2232
        assert store.backtest_run_entry("nope") == {}


class TestReaders:
    def test_hourly_and_meta_default_to_the_newest_run(self, mirror):
        meta = store.backtest_meta()
        assert meta["run_id"] == "v6_wf14"
        hourly = store.load_backtest_hourly()
        assert set(hourly["border"]) == set(ZONES)
        # walk-forward run: lead columns present, baseline absent
        assert {"origin", "lead_days"} <= set(hourly.columns)
        assert "y_baseline" not in hourly.columns

    def test_named_table_reader(self, mirror):
        metrics = store.load_backtest_table("price_v6_new", "metrics")
        assert set(metrics["model"]) == {"gnn", "baseline"}
        by_lead = store.load_backtest_table("v6_wf14", "by_lead")
        assert list(by_lead["lead_days"]) == [0, 1, 2, 3]

    def test_absent_optional_table_is_none_not_an_error(self, mirror):
        assert store.load_backtest_table("price_v6_new", "by_lead") is None
        assert store.load_backtest_table("price_v6_new", "coverage") is None


# ---------------------------------------------------------------------------
# Derived views
# ---------------------------------------------------------------------------

class TestZoneMetrics:
    def test_prefers_metrics_parquet_test_rows_for_one_model(self, mirror):
        zm = compute.zone_metrics("price_v6_new")
        assert list(zm["zone"]) == ["DE", "FR", "GB"]
        # test split only, gnn only -> one row per zone
        assert len(zm) == 3
        assert zm["rmse"].iloc[0] == pytest.approx(6.0)
        assert "skill_vs_baseline" in zm.columns

    def test_baseline_model_selectable(self, mirror):
        zm = compute.zone_metrics("price_v6_new", model="baseline")
        assert zm["rmse"].iloc[0] == pytest.approx(8.0)

    def test_falls_back_to_zone_r2_when_metrics_absent(self, mirror):
        zm = compute.zone_metrics("v6_wf14")           # no metrics.parquet
        assert list(zm.columns) == ["zone", "r2"]
        assert list(zm["zone"]) == ["DE", "FR", "GB"]
        assert zm["r2"].iloc[0] == pytest.approx(0.70)


class TestHourlyViews:
    def test_zone_slice_adds_cet_stamps(self, mirror):
        df = compute.backtest_hourly("price_v6_new", "de")
        assert set(df["border"]) == {"de"}
        # January: CET is UTC+1
        offset = (df["ts_cet"] - df["timestamp"]).unique()
        assert list(offset) == [pd.Timedelta(hours=1)]

    def test_resample_averages_available_columns(self, mirror):
        df = compute.backtest_hourly("price_v6_new", "de")
        daily = compute.resample_hourly(df, "D")
        assert {"y_true", "y_pred", "y_baseline", "y_persist"} <= set(
            daily.columns)
        assert len(daily) == 32           # 31 days + the CET-shifted tail hour
        hourly = compute.resample_hourly(df, "h")
        assert len(hourly) == len(df)

    def test_error_by_hour_covers_the_clock(self, mirror):
        df = compute.backtest_hourly("price_v6_new", "de")
        prof = compute.error_by_hour(df)
        assert list(prof["hour"]) == list(range(24))
        assert prof["mae"].gt(0).all()

    def test_pooled_metrics_scores_every_published_model(self, mirror):
        df = compute.backtest_hourly("price_v6_new", "de")
        pooled = compute.pooled_metrics(df)
        assert list(pooled["model"]) == ["GNN", "Anchored baseline",
                                         "24h persistence"]
        gnn = pooled.set_index("model").loc["GNN"]
        # synthetic noise is ~6 EUR/MWh on the GNN and ~9 on the baseline
        assert 4.0 < gnn["rmse"] < 8.0
        assert gnn["rmse"] < pooled.set_index("model").loc[
            "Anchored baseline"]["rmse"]

    def test_walk_forward_run_has_no_baseline_columns(self, mirror):
        df = compute.backtest_hourly("v6_wf14", "de")
        pooled = compute.pooled_metrics(df)
        assert list(pooled["model"]) == ["GNN"]


class TestRunSelectorAndSkill:
    def test_run_options_label_kind_and_preset(self, mirror):
        options = compute.run_options()
        assert options[0]["value"] == "v6_wf14"
        assert "WF" in options[0]["label"]
        assert "fixed" in options[1]["label"]

    def test_headline_skill_against_each_reference(self, mirror):
        meta = store.backtest_meta("price_v6_new")
        assert compute.headline_skill(meta, "baseline") == pytest.approx(
            1 - 6.0 / 9.0)
        assert compute.headline_skill(meta, "persistence") == pytest.approx(
            1 - 6.0 / 12.0)
        assert compute.headline_skill(meta, "nope") is None
        assert compute.headline_skill(None, "baseline") is None

    def test_contracts_are_built_for_the_selected_run(self, mirror):
        contracts = compute.backtest_contracts("price_v6_new")
        assert not contracts.empty
        assert set(contracts["kind"]) <= {"day", "weekend", "week", "month"}
        card = compute.backtest_scorecard(contracts, shape="base")
        assert set(card["zone"]) == {"DE", "FR", "GB"}
        assert (card["mae"] > 0).all()


class TestTabCallbacks:
    """Drive the tab's callbacks through a stub app (no Dash server)."""

    @staticmethod
    def _registered():
        from portal_pages.price_gnn import backtest as bt

        class StubApp:
            def __init__(self):
                self.registered = []

            def callback(self, *args, **kwargs):
                def decorator(fn):
                    ids = [getattr(a, "component_id", None) for a in args]
                    self.registered.append(([i for i in ids if i], fn))
                    return fn
                return decorator

        app = StubApp()
        bt.register_callbacks(app)
        return {ids[0]: fn for ids, fn in app.registered if ids}

    def test_every_callback_is_registered(self, mirror):
        outputs = self._registered()
        assert set(outputs) == {
            "pgnn-bt-note", "pgnn-bt-zonechart", "pgnn-bt-hzone",
            "pgnn-bt-series", "pgnn-bt-wfchart", "pgnn-bt-scorecard",
            "pgnn-bt-scatter",
        }

    def test_header_tiles_and_walk_forward_visibility(self, mirror):
        cb = self._registered()["pgnn-bt-note"]

        note, tiles, runinfo, prov, wf_style = cb("price_v6_new")
        # the publisher's own note wins over the page's fallback
        assert "realised fundamentals" in str(note)
        assert len(tiles) == 7          # window, R2, RMSE, MAE, 2 skills, zones
        assert "preset v6" in runinfo
        assert wf_style == {"display": "none"}    # fixed split hides WF
        assert prov is not None

        # this run publishes no note, so the page supplies the framing
        note_wf, _tiles, _info, _prov, wf_on = cb("v6_wf14")
        assert "Walk-forward run" in str(note_wf)
        assert wf_on == {"display": "block"}

    def test_header_is_graceful_with_no_runs(self, tmp_path, monkeypatch):
        monkeypatch.setenv("PRICE_GNN_LOCAL", str(tmp_path))
        store.backtest_index.invalidate_all()
        store._backtest_meta.invalidate_all()
        note, tiles, runinfo, prov, wf_style = self._registered()[
            "pgnn-bt-note"]("nothing-here")
        assert "No backtest runs found" in str(note)
        assert tiles == [] and prov is None
        assert wf_style == {"display": "none"}
        store.backtest_index.invalidate_all()
        store._backtest_meta.invalidate_all()

    def test_selectors_zone_and_regime_options(self, mirror):
        opts, default, contract_opts, contract_default, regimes = (
            self._registered()["pgnn-bt-hzone"]("price_v6_new"))
        assert [o["value"] for o in opts] == ["de", "fr", "gb"]
        assert default == "de"
        assert [o["value"] for o in contract_opts] == ["DE", "FR", "GB"]
        assert contract_default == "DE"
        # UK, not GB, in the labels; regimes come back named
        assert "UK" in [o["label"] for o in opts]
        assert regimes[0]["value"] == "all"
        assert "2025 onward" in [o["label"] for o in regimes]

    def test_hourly_explorer_returns_four_figures_and_a_summary(self, mirror):
        series, scatter, hist, byhour, pooled = self._registered()[
            "pgnn-bt-series"]("price_v6_new", "de", "D")
        assert len(series.data) == 4          # realised + 3 predictions
        assert len(scatter.data) == 2         # identity line + points
        assert len(hist.data) == 1
        assert len(byhour.data) == 2          # bias bars + MAE line
        assert "GNN RMSE" in pooled

    def test_zone_section_and_scorecard_render(self, mirror):
        fig, rows, cols, page, styles, msg = (
            self._registered()["pgnn-bt-zonechart"]("price_v6_new", "rmse"))
        assert len(fig.data) == 1
        assert len(rows) == 3
        assert rows[0]["Zone"] in ("DE", "FR", "UK")
        assert [c["id"] for c in cols][0] == "Zone"
        assert page == 3                      # no pagination for 3 rows
        assert styles[0]["if"]["column_id"] == "Zone"
        assert msg == ""

        rows, cols, page, _styles, msg = (
            self._registered()["pgnn-bt-scorecard"](
                "price_v6_new", "day", "base", "all"))
        assert len(rows) == 3
        assert cols and page == 3 and msg == ""

    def test_tables_are_fed_props_not_injected_components(self, mirror):
        """A DataTable returned into a children slot has no tracked path,
        so its derived_* write-back can corrupt the parent's children."""
        from portal_pages.price_gnn import backtest as bt

        tables, seen = [], []

        def walk(node):
            if isinstance(node, (list, tuple)):
                for item in node:
                    walk(item)
                return
            props = getattr(node, "_prop_names", None)
            if props is None:
                return
            if type(node).__name__ == "DataTable":
                tables.append(node)
                seen.append(getattr(node, "id", None))
            walk(getattr(node, "children", None))

        walk(bt.get_layout())
        assert sorted(seen) == ["pgnn-bt-scorecard", "pgnn-bt-zonetable"]
        assert all(t.data == [] for t in tables)   # filled by callbacks
        assert all(t.sort_action == "native" for t in tables)
        # Nothing returns a DataTable out of a callback any more.
        source = Path(bt.__file__).read_text(encoding="utf-8")
        assert "dash_table.DataTable(" in source      # only in _table_panel
        assert source.count("dash_table.DataTable(") == 1

    def test_missing_zone_metrics_reports_through_the_message_slot(self, mirror):
        fig, rows, cols, page, styles, msg = (
            self._registered()["pgnn-bt-zonechart"]("no_such_run", "r2"))
        assert fig.layout.annotations
        assert rows == [] and cols == [] and styles == []
        assert page == 1
        assert "metrics.parquet" in msg

    def test_walk_forward_chart_only_for_wf_runs(self, mirror):
        cb = self._registered()["pgnn-bt-wfchart"]
        fig = cb("v6_wf14", "by_lead", "r2")
        assert list(fig.data[0].x) == [0, 1, 2, 3]
        absent = cb("price_v6_new", "by_lead", "r2")
        assert absent.layout.annotations      # "not published for this run"


class TestFigures:
    def test_series_scatter_and_profile_build(self, mirror):
        df = compute.backtest_hourly("price_v6_new", "de")
        wide = compute.resample_hourly(df, "D")
        fig = figures.fig_backtest_series(wide, "DE")
        names = [t.name for t in fig.data]
        assert "Realised" in names and "GNN" in names
        prof = figures.fig_error_by_hour(compute.error_by_hour(df), "DE")
        assert len(prof.data) == 2

    def test_zone_metric_chart_sorts_and_handles_missing_metric(self, mirror):
        zm = compute.zone_metrics("price_v6_new")
        fig = figures.fig_zone_metric(zm, "r2", "R2")
        assert list(fig.data[0].y) == ["DE", "FR", "GB"][::-1] or len(
            fig.data[0].y) == 3
        empty = figures.fig_zone_metric(zm, "not_a_column", "x")
        assert empty.layout.annotations  # styled_empty_figure has a message

    def test_walk_forward_chart(self, mirror):
        by_lead = store.load_backtest_table("v6_wf14", "by_lead")
        fig = figures.fig_walk_forward(by_lead, "lead_days", "r2", "decay")
        assert list(fig.data[0].x) == [0, 1, 2, 3]
        missing = figures.fig_walk_forward(by_lead, "origin", "r2", "x")
        assert missing.layout.annotations
