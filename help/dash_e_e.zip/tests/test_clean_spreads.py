"""Tests for core.clean_spreads.data (synthetic frames, no external data)."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from core.clean_spreads import data as cs_data
from core.clean_spreads.constants import (
    DEFAULT_LIGNITE_EFF,
    EFF_BAND,
    EFF_MAX,
    GAS_EF,
    GAS_EFFS,
    LIGNITE_EF,
    LIGNITE_FUEL_COST,
    UK_CARBON_RATIO,
    UK_GAS_EFF,
)


# ── Helpers to build a synthetic CSS_raw-style frame ───────────────────────
def _css_row(trade_date, delivery_start, contract_type, power, fuel_carbon_x):
    """One synthetic contract row priced off P and X = gas + EF*carbon."""
    period_map = {
        "MONTHLY": delivery_start.strftime("%b").upper()[:3],
        "QUARTERLY": f"Q{(delivery_start.month - 1) // 3 + 1}",
        "YEARLY": "CAL",
    }
    month_abbr = {
        1: "JAN", 2: "FEB", 3: "MAR", 4: "APR", 5: "MAY", 6: "JUN",
        7: "JUL", 8: "AUG", 9: "SEP", 10: "OCT", 11: "NOV", 12: "DEC",
    }
    period = (month_abbr[delivery_start.month]
              if contract_type == "MONTHLY" else period_map[contract_type])
    return {
        "DATE": pd.Timestamp(trade_date),
        "COUNTRY": "GB",
        "DELIVERY_PERIOD": delivery_start.strftime("%Y-%m-%d"),
        "DAYS_TO_DELIVERY": max(
            (delivery_start - pd.Timestamp(trade_date)).days, 2),
        "DELIVERY_START": delivery_start,
        "CONTRACT_TYPE": contract_type,
        "Period": period,
        "Year": delivery_start.year,
        "CSS_LOW_EFF": power - fuel_carbon_x / GAS_EFFS["low"],
        "CSS_MID_EFF": power - fuel_carbon_x / GAS_EFFS["mid"],
        "CSS_HI_EFF": power - fuel_carbon_x / GAS_EFFS["hi"],
    }


def _make_css_raw(trade_dates=None):
    """Small GB CSS frame: 2 months, 3 quarters, 1 cal across trade dates."""
    trade_dates = trade_dates or [pd.Timestamp("2026-09-10")]
    rows = []
    for i, td in enumerate(trade_dates):
        bump = i * 0.5  # curves shift slightly between trade dates
        rows += [
            _css_row(td, pd.Timestamp("2026-10-01"), "MONTHLY", 90 + bump, 30),
            _css_row(td, pd.Timestamp("2026-11-01"), "MONTHLY", 95 + bump, 32),
            _css_row(td, pd.Timestamp("2026-12-01"), "MONTHLY", 99 + bump, 33),
            _css_row(td, pd.Timestamp("2027-01-01"), "QUARTERLY", 100 + bump, 35),
            _css_row(td, pd.Timestamp("2027-04-01"), "QUARTERLY", 80 + bump, 28),
            _css_row(td, pd.Timestamp("2027-07-01"), "QUARTERLY", 75 + bump, 26),
            _css_row(td, pd.Timestamp("2027-10-01"), "QUARTERLY", 95 + bump, 33),
            _css_row(td, pd.Timestamp("2028-01-01"), "YEARLY", 85 + bump, 30),
        ]
    df = pd.DataFrame(rows)
    return df.set_index(["DATE", "COUNTRY", "DELIVERY_PERIOD",
                         "DAYS_TO_DELIVERY"])


# ── UK re-efficiency algebra ───────────────────────────────────────────────
def test_uk_reefficiency_recovers_power_and_x():
    power, x = 100.0, 40.0
    frame = pd.DataFrame({
        "CSS_LOW_EFF": [power - x / GAS_EFFS["low"]],
        "CSS_MID_EFF": [power - x / GAS_EFFS["mid"]],
        "CSS_HI_EFF": [power - x / GAS_EFFS["hi"]],
    })
    out = cs_data.add_uk_market_css(frame)
    assert out["POWER_IMPLIED"].iloc[0] == pytest.approx(power, abs=1e-9)
    assert out["FUEL_CARBON_COST"].iloc[0] == pytest.approx(x, abs=1e-9)
    assert out["CSS_MID_CHECK"].iloc[0] == pytest.approx(
        out["CSS_MID_EFF"].iloc[0], abs=1e-9)
    # CSS at 49.13% sits between the LOW (48%) and MID (50%) columns
    assert out["CSS_UK_MKT"].iloc[0] == pytest.approx(
        power - x / UK_GAS_EFF, abs=1e-9)
    assert (out["CSS_LOW_EFF"].iloc[0]
            < out["CSS_UK_MKT"].iloc[0]
            < out["CSS_MID_EFF"].iloc[0])


# ── Hedge-ratio math ───────────────────────────────────────────────────────
def test_hedge_uka_winter_15mw():
    result = cs_data.hedge_uka(15, "Winter")
    assert result["hours"] == 4368
    assert result["power_mwh"] == pytest.approx(15 * 4368)
    assert result["carbon_ratio"] == pytest.approx(GAS_EF / UK_GAS_EFF)
    # ~24.3 lots for a 15 MW winter clip at the theoretical ratio
    assert result["lots"] == pytest.approx(
        15 * 4368 * UK_CARBON_RATIO / 1000.0)
    assert 23.5 < result["lots"] < 25.5
    # Gas leg = power / efficiency
    assert result["gas_mwh"] == pytest.approx(15 * 4368 / UK_GAS_EFF)


def test_hedge_uka_zero_mw():
    result = cs_data.hedge_uka(0, "Summer")
    assert result["tonnes"] == 0
    assert result["lots"] == 0


# ── Curve stitching ────────────────────────────────────────────────────────
def test_build_curve_stitches_months_quarters_cal():
    df = _make_css_raw()
    curve = cs_data.build_curve(df, "GB", ["CSS_MID_EFF"])
    assert not curve.empty
    # Trade date 2026-09-10 (Q3): months Oct-Dec are next quarter ->
    # quarters from 2026-10? No: months until end of current quarter (Sep),
    # so no monthly rows survive; quarters from Q4-26 via monthly? Our
    # synthetic months start Oct which is >= next_q (2026-10-01), so they
    # are excluded and quarters take over from 2027-01.
    types = set(curve["CONTRACT_TYPE"])
    assert "QUARTERLY" in types
    # CAL-28 only included because no 2028 quarters exist
    assert "CAL-28" in set(curve["STRIP"])
    # Sorted by delivery start
    starts = curve["DELIVERY_START"].tolist()
    assert starts == sorted(starts)


def test_build_curve_asof_picks_older_date():
    dates = [pd.Timestamp("2026-09-01"), pd.Timestamp("2026-09-10")]
    df = _make_css_raw(trade_dates=dates)
    latest = cs_data.build_curve(df, "GB", ["CSS_MID_EFF"])
    older = cs_data.build_curve(df, "GB", ["CSS_MID_EFF"],
                                asof=pd.Timestamp("2026-09-05"))
    assert pd.Timestamp(latest["DATE"].iloc[0]) == dates[1]
    assert pd.Timestamp(older["DATE"].iloc[0]) == dates[0]
    # Newer curve is 0.5 higher by construction
    merged = latest.merge(older, on="DELIVERY_PERIOD",
                          suffixes=("_new", "_old"))
    diffs = merged["CSS_MID_EFF_new"] - merged["CSS_MID_EFF_old"]
    assert np.allclose(diffs, 0.5)


def test_curve_snapshot_changes():
    dates = [pd.Timestamp("2026-09-01"), pd.Timestamp("2026-09-09"),
             pd.Timestamp("2026-09-10")]
    df = _make_css_raw(trade_dates=dates)
    snapshot = cs_data.curve_snapshot(df, "GB", "CSS_MID_EFF")
    assert not snapshot.empty
    assert {"STRIP", "Outright", "DoD", "WoW", "MoM"}.issubset(
        snapshot.columns)
    # DoD: 2026-09-10 vs 09-09 -> +0.5 bump between consecutive trade dates
    assert np.allclose(snapshot["DoD"].dropna(), 0.5)
    # WoW: vs 09-03 or earlier -> closest is 09-01 -> +1.0
    assert np.allclose(snapshot["WoW"].dropna(), 1.0)


# ── Monthly projection + seasons ───────────────────────────────────────────
def test_expand_curve_monthly_and_seasons():
    df = _make_css_raw()
    curve = cs_data.build_curve(df, "GB", ["CSS_MID_EFF"])
    proj = cs_data.expand_curve_monthly(curve, "CSS_MID_EFF")
    assert not proj.empty
    # Quarters expand to 3 months each; months unique
    assert proj["month"].is_unique
    # Q1-27 value repeated over Jan/Feb/Mar 2027
    q1_months = proj[(proj["month"] >= "2027-01-01")
                     & (proj["month"] < "2027-04-01")]
    assert len(q1_months) == 3
    assert q1_months["value"].nunique() == 1

    seasons = cs_data.uk_season_strips(proj)
    assert not seasons.empty
    # Winter-26 = Oct26..Mar27 built from Q4-26(none->months?)+Q1-27 etc.
    assert any(s.startswith("WIN-") for s in seasons["STRIP"])
    assert any(s.startswith("SUM-") for s in seasons["STRIP"])
    # Winter-26 strip should average Q1-27 months and any Oct-Dec 26 months
    win26 = seasons[seasons["STRIP"] == "WIN-26"]
    if not win26.empty:
        assert win26["n_months"].iloc[0] <= 6


# ── Delivered helpers ──────────────────────────────────────────────────────
def _delivered_frame():
    return pd.DataFrame([
        {"Country": "GB", "Period": "JAN-26", "YEAR": 2026,
         "CSS_MID_EFF": 12.5},
        {"Country": "GB", "Period": "Q1-26", "YEAR": 2026,
         "CSS_MID_EFF": 11.0},
        {"Country": "GB", "Period": "WK05-26", "YEAR": 2026,
         "CSS_MID_EFF": 14.0},
        {"Country": "DE", "Period": "JAN-26", "YEAR": 2026,
         "CSS_MID_EFF": -3.0},
    ])


def test_delivered_monthly_filters_country_and_periods():
    monthly = cs_data.delivered_monthly(_delivered_frame(), "GB")
    # Only JAN-26 is a monthly period for GB (WK/Q filtered out)
    assert len(monthly) == 1
    assert monthly["month"].iloc[0] == pd.Timestamp(2026, 1, 1)
    assert monthly["value"].iloc[0] == 12.5


def test_delivered_value_lookup():
    frame = _delivered_frame()
    assert cs_data.delivered_value(frame, "GB", "Q1", 2026) == 11.0
    assert cs_data.delivered_value(frame, "GB", "Q2", 2026) is None
    assert cs_data.delivered_value(frame, "DE", "JAN", 2026) == -3.0


def test_heat_rate_algebra_gas_and_coal():
    from core.clean_spreads.constants import COAL_EFFS

    power, x_gas = 100.0, 40.0
    css = pd.DataFrame({
        "CSS_LOW_EFF": [power - x_gas / GAS_EFFS["low"]],
        "CSS_MID_EFF": [power - x_gas / GAS_EFFS["mid"]],
        "CSS_HI_EFF": [power - x_gas / GAS_EFFS["hi"]],
        "GAS_PRICE": [30.0],  # -> carbon = (40 - 30) / 0.1821
    })
    power_c, x_coal = 100.0, 25.0
    cds = pd.DataFrame({
        "CDS_LOW_EFF": [power_c - x_coal / COAL_EFFS["low"]],
        "CDS_HI_EFF": [power_c - x_coal / COAL_EFFS["hi"]],
    })

    css_out, cds_out = cs_data._add_heat_rate_cols(css, cds)
    # Clean heat rate = P / X, exactly
    assert css_out["GAS_HR"].iloc[0] == pytest.approx(power / x_gas, abs=1e-9)
    assert cds_out["COAL_HR"].iloc[0] == pytest.approx(
        power_c / x_coal, abs=1e-9)

    # Lignite: carbon backed out of the gas leg
    carbon = (x_gas - 30.0) / GAS_EF
    expected_lignite = power / (3.0 + 0.40 * carbon)
    assert css_out["LIGNITE_HR"].iloc[0] == pytest.approx(
        expected_lignite, abs=1e-9)


def test_heat_rate_lignite_requires_gas_price():
    power, x_gas = 100.0, 40.0
    css = pd.DataFrame({
        "CSS_LOW_EFF": [power - x_gas / GAS_EFFS["low"]],
        "CSS_HI_EFF": [power - x_gas / GAS_EFFS["hi"]],
    })
    css_out, _ = cs_data._add_heat_rate_cols(css, None)
    assert "GAS_HR" in css_out.columns
    assert "LIGNITE_HR" not in css_out.columns


def test_heat_rate_curve_merges_coal():
    df = _make_css_raw()
    # Build a CDS frame from the same synthetic structure by renaming cols
    cds = df.rename(columns={
        "CSS_LOW_EFF": "CDS_LOW_EFF",
        "CSS_MID_EFF": "CDS_MID_EFF",
        "CSS_HI_EFF": "CDS_HI_EFF",
    })
    # Re-derive CDS levels off coal efficiencies so algebra is consistent:
    # keep it simple - values just need to be finite for the merge test.
    bundle = {"CSS_raw": df, "CDS_raw": cds}
    curve = cs_data.heat_rate_curve(bundle, "GB")
    assert not curve.empty
    assert "GAS_HR" in curve.columns
    assert "COAL_HR" in curve.columns
    assert curve["GAS_HR"].notna().all()


def _spot_bundle():
    """Synthetic normalized spot frames mimicking the price_data bundle."""
    dates = pd.date_range("2026-08-01", "2026-09-10", freq="D")
    hours = pd.date_range("2026-08-01", "2026-09-10 23:00", freq="h")
    power = pd.DataFrame({
        "valuedate": hours, "zone": "DE", "exchange": "EPEX",
        "currency": "EUR", "frequency": "H", "value": 80.0,
    })
    power_gb = power.assign(zone="GB", value=90.0)
    gas = pd.DataFrame({
        "valuedate": dates, "hub": "TTF", "currency": "EUR",
        "energy_unit": "MWh", "unit": "EUR/MWh", "value": 30.0,
    })
    # Mirrors the real cache: NBP is stored in EUR/MWh, UKA in GBP/t
    gas_nbp = gas.assign(hub="NBP", value=25.0)
    co2 = pd.DataFrame({
        "valuedate": dates, "hub": "EUA", "currency": "EUR",
        "unit": "EUR/t", "value": 70.0,
    })
    co2_uka = co2.assign(hub="UKA", value=40.0, currency="GBP",
                         unit="GBP/t")
    coal = pd.DataFrame({
        "valuedate": dates, "hub": "API2", "currency": "USD",
        "energy_unit": "t", "unit": "USD/t", "value": 100.0,
    })
    fx = pd.DataFrame({
        "date": dates, "EURGBP Curncy PX_LAST": 0.85,
    }).set_index("date")
    return {
        "power_spot_normalized": pd.concat([power, power_gb],
                                           ignore_index=True),
        "gas_spot_normalized": pd.concat([gas, gas_nbp], ignore_index=True),
        "co2_spot_normalized": pd.concat([co2, co2_uka], ignore_index=True),
        "coal_spot_normalized": coal,
        "fx_data": fx,
    }


def test_daily_spot_metrics_de():
    from core.clean_spreads.constants import (
        API2_TO_MWH, COAL_EF, USD_TO_EUR_FALLBACK,
    )

    daily = cs_data.daily_spot_metrics(_spot_bundle(), "DE", days=450)
    assert not daily.empty
    row = daily.iloc[-1]
    # CSS = 80 - 30/0.5 - (0.1821/0.5)*70
    assert row["CSS"] == pytest.approx(80 - 60 - 0.3642 * 70, abs=1e-6)
    # CDS = 80 - coal_eur/0.4 - (0.34/0.4)*70
    coal_eur = 100.0 * USD_TO_EUR_FALLBACK / API2_TO_MWH
    assert row["CDS"] == pytest.approx(
        80 - coal_eur / 0.4 - (COAL_EF / 0.4) * 70, abs=1e-6)
    # HeatRate = 80 / (30 + 0.1821*70)
    assert row["HeatRate"] == pytest.approx(80 / (30 + 0.1821 * 70), abs=1e-9)
    assert row["Coal"] == 100.0  # display stays USD/t


def test_daily_spot_metrics_gb_uses_uka_cps_and_market_eff():
    daily = cs_data.daily_spot_metrics(_spot_bundle(), "GB", days=450)
    assert not daily.empty
    row = daily.iloc[-1]
    # NBP is cached in EUR/MWh, so it must NOT be divided by EURGBP;
    # UKA is cached in GBP/t, so it is converted with the GBP 18/t CPS
    nbp_eur = 25.0
    uka_eur = (40.0 + 18.0) / 0.85
    expected_css = (90 - nbp_eur / UK_GAS_EFF
                    - (GAS_EF / UK_GAS_EFF) * uka_eur)
    assert row["CSS"] == pytest.approx(expected_css, abs=1e-6)
    assert row["Gas"] == pytest.approx(nbp_eur, abs=1e-9)
    assert row["Carbon"] == pytest.approx(uka_eur, abs=1e-9)


def test_daily_spot_metrics_converts_gb_legs_stored_in_gbp():
    """The conversion follows the cache's currency metadata, not a rule."""
    bundle = _spot_bundle()
    gas = bundle["gas_spot_normalized"].copy()
    nbp = gas["hub"].astype(str).str.upper() == "NBP"
    gas.loc[nbp, "currency"] = "GBP"       # feed switches to GBP/MWh
    gas.loc[nbp, "unit"] = "GBP/MWh"
    bundle["gas_spot_normalized"] = gas

    row = cs_data.daily_spot_metrics(bundle, "GB", days=450).iloc[-1]
    assert row["Gas"] == pytest.approx(25.0 / 0.85, abs=1e-9)

    # A UKA leg already in EUR only needs the CPS converting
    co2 = bundle["co2_spot_normalized"].copy()
    uka = co2["hub"].astype(str).str.upper() == "UKA"
    co2.loc[uka, "currency"] = "EUR"
    co2.loc[uka, "unit"] = "EUR/t"
    bundle["co2_spot_normalized"] = co2
    row = cs_data.daily_spot_metrics(bundle, "GB", days=450).iloc[-1]
    assert row["Carbon"] == pytest.approx(40.0 + 18.0 / 0.85, abs=1e-9)


def test_daily_spot_metrics_handles_tz_aware_power():
    """Hourly power from the market cache is tz-aware; fuels are naive."""
    bundle = _spot_bundle()
    power = bundle["power_spot_normalized"].copy()
    power["valuedate"] = (pd.to_datetime(power["valuedate"])
                          .dt.tz_localize("Europe/Berlin"))
    bundle["power_spot_normalized"] = power

    daily = cs_data.daily_spot_metrics(bundle, "DE", days=450)
    assert not daily.empty
    assert daily.index.tz is None
    assert daily["CSS"].notna().any()


def test_daily_spot_metrics_heat_rate_columns():
    from core.clean_spreads.constants import (
        API2_TO_MWH, COAL_EF, LIGNITE_EF, LIGNITE_FUEL_COST,
        USD_TO_EUR_FALLBACK,
    )

    daily = cs_data.daily_spot_metrics(_spot_bundle(), "DE", days=450)
    row = daily.iloc[-1]
    assert row["GAS_HR"] == pytest.approx(row["HeatRate"], abs=1e-12)
    coal_x = 100.0 * USD_TO_EUR_FALLBACK / API2_TO_MWH + COAL_EF * 70.0
    assert row["COAL_HR"] == pytest.approx(80.0 / coal_x, abs=1e-9)
    lig_x = LIGNITE_FUEL_COST + LIGNITE_EF * 70.0
    assert row["LIGNITE_HR"] == pytest.approx(80.0 / lig_x, abs=1e-9)


def test_delivered_heat_rate_strips_ratio_of_means_vs_daily_mean():
    bundle = _spot_bundle()
    gas = bundle["gas_spot_normalized"]
    # TTF 20 for the first half of August, 40 after: X varies, power flat 80
    early = (gas["hub"] == "TTF") & (gas["valuedate"] < "2026-08-16")
    bundle["gas_spot_normalized"] = gas.assign(
        value=np.where(early, 20.0, np.where(gas["hub"] == "TTF", 40.0,
                                             gas["value"])))
    carbon = 0.1821 * 70.0
    xs = np.array([20.0] * 15 + [40.0] * 16) + carbon

    out = cs_data.delivered_heat_rate_strips(bundle, "DE", "GAS", "AUG",
                                             [2026])
    assert out[2026]["ratio"] == pytest.approx(80.0 / xs.mean(), abs=1e-9)
    assert out[2026]["daily_mean"] == pytest.approx(
        (80.0 / xs).mean(), abs=1e-9)
    assert out[2026]["daily_mean"] > out[2026]["ratio"]  # Jensen gap
    # September is only delivered to the 10th -> excluded
    assert cs_data.delivered_heat_rate_strips(
        bundle, "DE", "GAS", "SEP", [2026]) == {}
    # Strip with no spot history -> excluded
    assert cs_data.delivered_heat_rate_strips(
        bundle, "DE", "GAS", "JUL", [2026]) == {}


def test_contract_history_chart_draws_delivered_hr_band():
    overlays = pd.DataFrame({
        "Year": [2024, 2024, 2025, 2025],
        "DAYS_TO_DELIVERY": [100, 10, 100, 10],
        "DATE": pd.to_datetime(["2023-09-01", "2023-12-20",
                                "2024-09-01", "2024-12-20"]),
        "value": [1.8, 1.9, 1.7, 1.75],
    })
    from core.clean_spreads import charts as cs_charts

    fig = cs_charts.contract_history_chart(
        overlays, {2024: 1.85}, "FR", "CAL", "Gas HR",
        zero_line=False, delivered_band={2024: 1.95})
    bands = [t for t in fig.data if t.fill == "toself"]
    assert len(bands) == 1
    assert min(bands[0].y) == pytest.approx(1.85)
    assert max(bands[0].y) == pytest.approx(1.95)


def test_delivered_heat_rate_monthly():
    monthly = cs_data.delivered_heat_rate_monthly(_spot_bundle(), "DE", "GAS")
    assert not monthly.empty
    # Constant synthetic prices -> constant HR = 80 / (30 + 0.1821*70)
    expected = 80.0 / (30.0 + 0.1821 * 70.0)
    assert monthly["value"].iloc[0] == pytest.approx(expected, abs=1e-9)
    # Aug + Sep 2026 in the synthetic window
    assert len(monthly) == 2

    combo = cs_data.delivered_and_forward_hr(_spot_bundle(), "DE", "GAS")
    assert not combo["delivered"].empty
    # No CSS_raw in the spot-only bundle -> forward leg empty
    assert combo["forward"].empty


# ── HR vs Fundamentals (climate weather-year regression) ───────────────────
def _climate_panel(start="2025-01-01", end="2027-12-31",
                   wy_values=None) -> pd.DataFrame:
    """Synthetic daily climate panel in GW, columns y2025/y2026."""
    dates = pd.date_range(start, end, freq="D")
    if wy_values is None:
        wy_values = {"y2025": 40.0, "y2026": 50.0}
    data = {}
    for col, base in wy_values.items():
        # deterministic daily variation so regressions have x-spread
        data[col] = base + (np.arange(len(dates)) % 20) * 0.5
    return pd.DataFrame(data, index=dates)


def test_climate_diagonal():
    from core.clean_spreads import fundamentals as cs_fund

    panel = _climate_panel()
    diag = cs_fund.climate_diagonal(panel)
    # 2025 dates come from y2025, 2026 from y2026, 2027 has no column
    assert diag.index.min() == pd.Timestamp("2025-01-01")
    assert diag.index.max() == pd.Timestamp("2026-12-31")
    assert diag.loc[pd.Timestamp("2025-01-01")] == panel.loc[
        pd.Timestamp("2025-01-01"), "y2025"]
    assert diag.loc[pd.Timestamp("2026-06-15")] == panel.loc[
        pd.Timestamp("2026-06-15"), "y2026"]


def test_fit_month_recovers_linear_relationship():
    from core.clean_spreads import fundamentals as cs_fund

    dates = pd.date_range("2024-03-01", "2025-03-31", freq="D")
    fund = pd.Series(30 + (np.arange(len(dates)) % 15) * 1.0, index=dates)
    df = pd.DataFrame({
        "FUND": fund,
        "GAS_HR": 2.0 + 0.05 * fund,  # exact linear
        "year": dates.year,
        "month": dates.month,
    }, index=dates)

    # Defaults (year FE + adjacent-month pooling) recover an exact linear
    # relationship: anomaly slope is exact and the recent-365d anchor
    # reproduces the true intercept.
    fit = cs_fund.fit_month(df, month=3, years=[2024, 2025])
    assert fit is not None
    assert fit["slope"] == pytest.approx(0.05, abs=1e-9)
    assert fit["intercept"] == pytest.approx(2.0, abs=1e-7)
    assert fit["r2"] == pytest.approx(1.0, abs=1e-9)
    assert fit["sigma_m"] == pytest.approx(0.0, abs=1e-9)

    # Plain pooled OLS (both options off) recovers the same exact fit
    plain = cs_fund.fit_month(df, month=3, years=[2024, 2025],
                              pool_adjacent=False, year_fe=False)
    assert plain["slope"] == pytest.approx(0.05, abs=1e-9)
    assert plain["intercept"] == pytest.approx(2.0, abs=1e-7)
    assert plain["n"] < fit["n"]  # pooling adds neighbouring months

    # Subselecting years changes the sample size
    fit_2024 = cs_fund.fit_month(df, month=3, years=[2024])
    assert fit_2024["n"] < fit["n"]

    # Too few points -> None
    assert cs_fund.fit_month(df, month=3, years=[1999]) is None


def test_year_fixed_effects_remove_level_shift():
    from core.clean_spreads import fundamentals as cs_fund

    # Two years, same slope 0.05, but a big level shift (+1.0 in 2024)
    # and different fundamental means (so pooled OLS slope is biased).
    d24 = pd.date_range("2024-03-01", "2024-03-31", freq="D")
    d25 = pd.date_range("2025-03-01", "2025-03-31", freq="D")
    f24 = pd.Series(50 + (np.arange(len(d24)) % 10) * 1.0, index=d24)
    f25 = pd.Series(30 + (np.arange(len(d25)) % 10) * 1.0, index=d25)
    fund = pd.concat([f24, f25])
    hr = pd.concat([2.0 + 1.0 + 0.05 * f24, 2.0 + 0.05 * f25])
    dates = fund.index
    df = pd.DataFrame({"FUND": fund, "GAS_HR": hr,
                       "year": dates.year, "month": dates.month},
                      index=dates)

    fe = cs_fund.fit_month(df, month=3, years=[2024, 2025],
                           pool_adjacent=False, year_fe=True)
    assert fe["slope"] == pytest.approx(0.05, abs=1e-9)
    # Anchor = last 365 days = 2025 regime -> intercept ~= 2.0
    assert fe["intercept"] == pytest.approx(2.0, abs=1e-7)

    # Pooled OLS is contaminated by the level shift across years
    ols = cs_fund.fit_month(df, month=3, years=[2024, 2025],
                            pool_adjacent=False, year_fe=False)
    assert abs(ols["slope"] - 0.05) > 0.01


def test_projection_distribution():
    from core.clean_spreads import fundamentals as cs_fund

    wy = pd.Series([40.0, 45.0, 50.0, 55.0, 60.0],
                   index=[2000, 2001, 2002, 2003, 2004])
    fit = {"slope": 0.02, "intercept": 1.0, "sigma_m": 0.0}
    dist = cs_fund.projection_distribution(fit, wy)
    assert dist["median"] == pytest.approx(1.0 + 0.02 * 50.0, abs=1e-9)
    assert dist["preds"][2000] == pytest.approx(1.8, abs=1e-9)
    width_no_noise = dist["p90"] - dist["p10"]

    # Residual sigma widens the distribution
    fit_noisy = {"slope": 0.02, "intercept": 1.0, "sigma_m": 0.2}
    dist_noisy = cs_fund.projection_distribution(fit_noisy, wy)
    assert (dist_noisy["p90"] - dist_noisy["p10"]) > width_no_noise

    assert cs_fund.projection_distribution(None, wy) is None
    assert cs_fund.projection_distribution(
        fit, pd.Series(dtype=float)) is None


def test_forward_target_year():
    from core.clean_spreads import fundamentals as cs_fund

    today = pd.Timestamp("2026-09-11")
    assert cs_fund.forward_target_year(9, today) == 2027   # Sep passed
    assert cs_fund.forward_target_year(10, today) == 2026  # Oct upcoming
    assert cs_fund.forward_target_year(1, today) == 2027


def test_wy_monthly_means():
    from core.clean_spreads import fundamentals as cs_fund

    panel = _climate_panel()
    means = cs_fund.wy_monthly_means(panel, month=10, year=2026)
    assert list(means.index) == [2025, 2026]
    expected = panel.loc[(panel.index.year == 2026)
                         & (panel.index.month == 10), "y2025"].mean()
    assert means[2025] == pytest.approx(expected, abs=1e-9)
    # Month outside the panel calendar -> empty
    assert cs_fund.wy_monthly_means(panel, month=1, year=2035).empty


def test_historical_series_extends_diagonal_with_actuals(monkeypatch):
    from core.clean_spreads import fundamentals as cs_fund

    # Panel with weather years only through 2025 -> diagonal ends 2025-12-31
    panel = _climate_panel(wy_values={"y2024": 40.0, "y2025": 50.0},
                           start="2024-01-01", end="2027-12-31")
    actual_dates = pd.date_range("2025-06-01", "2026-09-10", freq="D")
    actuals = pd.Series(99.0, index=actual_dates)
    monkeypatch.setattr(cs_fund, "load_actual_daily",
                        lambda var, country: actuals)

    hist = cs_fund.historical_series("RESIDUAL_LOAD", "DE", panel)
    # Diagonal covers 2024-2025; actuals only used strictly after it
    assert hist.loc[pd.Timestamp("2025-06-15")] == panel.loc[
        pd.Timestamp("2025-06-15"), "y2025"]
    assert hist.loc[pd.Timestamp("2026-03-01")] == 99.0
    assert hist.index.max() == pd.Timestamp("2026-09-10")
    assert hist.index.is_monotonic_increasing


def test_build_regression_view(monkeypatch):
    from core.clean_spreads import fundamentals as cs_fund

    panel = _climate_panel()
    monkeypatch.setattr(cs_fund, "load_climate_daily",
                        lambda var, country: panel)
    monkeypatch.setattr(cs_fund, "load_actual_daily",
                        lambda var, country: pd.Series(dtype=float))

    view = cs_fund.build_regression_view(_spot_bundle(), "DE",
                                         "RESIDUAL_LOAD", years=None)
    # Spot bundle covers Aug-Sep 2026 -> regression points exist there
    assert not view["dataset"].empty
    assert view["all_years"] == [2026]
    assert view["selected_years"] == [2026]
    assert set(view["dataset"]["month"].unique()) <= {8, 9}
    # Aug 2026 has >= 10 days with x-spread -> fit exists
    assert view["fits"][8] is not None
    # Distribution computed wherever fit + weather-year means exist
    assert view["dist"][8] is not None
    # Forward weather-year means available for target months in the panel
    assert not view["wy_means"][10].empty
    # No CSS_raw in the spot-only bundle -> no market forward HR
    assert all(v is None for v in view["market"].values())


# ── Trader pack (analytics.py) ──────────────────────────────────────────────
from core.clean_spreads import analytics as cs_analytics  # noqa: E402
from core.clean_spreads.constants import COAL_EFFS, COAL_EF, GAS_EF  # noqa: E402


def _pack_row(country, trade_date, delivery_start, ctype, period, power, x,
              metric="CSS", effs=None, gas_price=None):
    """Generic synthetic contract row priced off P and X."""
    effs = effs or (GAS_EFFS if metric == "CSS" else COAL_EFFS)
    row = {
        "DATE": pd.Timestamp(trade_date),
        "COUNTRY": country,
        "DELIVERY_PERIOD": pd.Timestamp(delivery_start).strftime("%Y-%m-%d"),
        "DAYS_TO_DELIVERY": max(
            (pd.Timestamp(delivery_start) - pd.Timestamp(trade_date)).days,
            2),
        "DELIVERY_START": pd.Timestamp(delivery_start),
        "CONTRACT_TYPE": ctype,
        "Period": period,
        "Year": pd.Timestamp(delivery_start).year,
        f"{metric}_LOW_EFF": power - x / effs["low"],
        f"{metric}_MID_EFF": power - x / effs["mid"],
        f"{metric}_HI_EFF": power - x / effs["hi"],
    }
    if gas_price is not None:
        row["GAS_PRICE"] = gas_price
    return row


def _pack_raw(rows):
    return pd.DataFrame(rows).set_index(
        ["DATE", "COUNTRY", "DELIVERY_PERIOD", "DAYS_TO_DELIVERY"])


def test_switching_carbon_solver():
    td = pd.Timestamp("2026-09-10")
    ds = pd.Timestamp("2027-01-01")
    power, gas, carbon, coal_fuel = 100.0, 30.0, 70.0, 10.0
    x_gas = gas + GAS_EF * carbon
    x_coal = coal_fuel + COAL_EF * carbon
    bundle = {
        "CSS_raw": _pack_raw([_pack_row("DE", td, ds, "QUARTERLY", "Q1",
                                        power, x_gas, gas_price=gas)]),
        "CDS_raw": _pack_raw([_pack_row("DE", td, ds, "QUARTERLY", "Q1",
                                        power, x_coal, metric="CDS")]),
    }
    out = cs_analytics.switching_carbon_curve(bundle, "DE")
    assert len(out) == 1
    row = out.iloc[0]
    assert row["implied_carbon"] == pytest.approx(carbon, abs=1e-6)
    expected = (coal_fuel / 0.40 - gas / 0.50) / (GAS_EF / 0.50
                                                  - COAL_EF / 0.40)
    assert row["switching_carbon"] == pytest.approx(expected, abs=1e-6)
    # At C=70 < C* (~72), coal is still cheaper -> gas NOT in merit
    assert not bool(row["gas_in_merit"])
    assert row["gas_cost"] == pytest.approx(
        (gas + GAS_EF * carbon) / 0.50, abs=1e-6)


def test_scenario_grid_shocks():
    td = pd.Timestamp("2026-09-10")
    ds = pd.Timestamp("2027-01-01")
    power, gas, carbon = 100.0, 30.0, 70.0
    x = gas + GAS_EF * carbon
    bundle = {"CSS_raw": _pack_raw([
        _pack_row("DE", td, ds, "QUARTERLY", "Q1", power, x,
                  gas_price=gas)])}
    res = cs_analytics.scenario_grid(bundle, "DE", "Q1-27")
    assert res["strip"] == "Q1-27"
    base = res["base"]
    assert base["power"] == pytest.approx(power, abs=1e-6)
    assert base["carbon"] == pytest.approx(carbon, abs=1e-6)
    # Base cell (0, 0) equals the unshocked CSS
    assert res["grid"].loc[0.0, 0.0] == pytest.approx(base["css"], abs=1e-9)
    # gas +5, carbon +10
    expected = power - (gas + 5) / 0.5 - (GAS_EF / 0.5) * (carbon + 10)
    assert res["grid"].loc[10.0, 5.0] == pytest.approx(expected, abs=1e-9)


def test_risk_premium_and_summary():
    delivery = pd.Timestamp("2025-10-01")
    rows = []
    for dtd, value_x in [(90, 30.0), (60, 32.0), (30, 34.0)]:
        td = delivery - pd.Timedelta(days=dtd)
        rows.append(_pack_row("DE", td, delivery, "MONTHLY", "OCT",
                              100.0, value_x))
    bundle = {
        "CSS_raw": _pack_raw(rows),
        "delivered_spreads": pd.DataFrame([{
            "Country": "DE", "Period": "OCT-25", "YEAR": 2025,
            "CSS_MID_EFF": 25.0,
        }]),
    }
    prem = cs_analytics.risk_premium(bundle, "DE")
    assert len(prem) == 1
    row = prem.iloc[0]
    fwd_30 = 100.0 - 34.0 / GAS_EFFS["mid"]
    assert row["fwd_30"] == pytest.approx(fwd_30, abs=1e-9)
    assert row["prem_30"] == pytest.approx(fwd_30 - 25.0, abs=1e-9)
    assert row["prem_90"] == pytest.approx(
        (100.0 - 30.0 / GAS_EFFS["mid"]) - 25.0, abs=1e-9)

    summary = cs_analytics.risk_premium_summary(prem)
    assert len(summary) == 1
    assert summary.iloc[0]["month_num"] == 10
    assert summary.iloc[0]["hit_30"] in (0.0, 100.0)


def test_rolling_betas_recover_theoretical():
    rng = np.random.default_rng(3)
    delivery = pd.Timestamp("2027-01-01")
    dates = pd.bdate_range("2026-04-01", "2026-09-10")
    gas = 30 + np.cumsum(rng.standard_normal(len(dates)) * 0.8)
    carbon = 70 + np.cumsum(rng.standard_normal(len(dates)) * 1.2)
    rows = [
        _pack_row("DE", d, delivery, "QUARTERLY", "Q1",
                  100.0, g + GAS_EF * c, gas_price=g)
        for d, g, c in zip(dates, gas, carbon)
    ]
    bundle = {"CSS_raw": _pack_raw(rows)}
    betas = cs_analytics.rolling_betas(bundle, "DE", "Q1", window=60)
    assert not betas.empty
    last = betas.iloc[-1]
    # P constant -> beta_gas = -1/eta = -2, beta_carbon = -EF/eta = -0.3642
    assert last["BETA_GAS"] == pytest.approx(-2.0, abs=1e-6)
    assert last["BETA_CARBON"] == pytest.approx(-GAS_EF / 0.5, abs=1e-6)
    assert last["R2"] == pytest.approx(1.0, abs=1e-9)


def test_rolldown_table():
    # Trade date inside Q4-26 so the NOV monthly stays on the curve
    td = pd.Timestamp("2026-10-05")
    bundle = {"CSS_raw": _pack_raw([
        _pack_row("DE", td, pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                  100.0, 30.0),
        _pack_row("DE", td, pd.Timestamp("2027-01-01"), "QUARTERLY", "Q1",
                  100.0, 35.0),
    ])}
    roll = cs_analytics.rolldown_table(bundle, "DE")
    assert len(roll) == 2
    assert pd.isna(roll.iloc[0]["Rolldown"])
    # Nearer (NOV, X=30) minus Q1 (X=35): CSS_nov - CSS_q1 = (35-30)/0.5
    assert roll.iloc[1]["Rolldown"] == pytest.approx(5.0 / 0.5, abs=1e-9)


def test_screener_basic_stats():
    delivery = pd.Timestamp("2026-11-01")
    # Last trade date (curve date) shares Q4-26 with the delivery month
    dates = pd.bdate_range("2026-09-15", "2026-10-28")
    rows = [
        _pack_row("DE", d, delivery, "MONTHLY", "NOV",
                  100.0 + 0.5 * i, 30.0)
        for i, d in enumerate(dates)
    ]
    bundle = {"CSS_raw": _pack_raw(rows)}
    scr = cs_analytics.screener(bundle, ["DE"], "CSS")
    assert len(scr) == 1
    row = scr.iloc[0]
    # Steady +0.5/day drift: DoD 0.5, level at its own 100th percentile
    assert row["DoD"] == pytest.approx(0.5, abs=1e-9)
    assert row["Pctile"] == pytest.approx(100.0, abs=1e-9)
    assert row["Obs"] == len(dates)
    # Constant changes -> zero std -> z undefined
    assert pd.isna(row["zDoD"])


def test_screener_heat_rate_metric():
    delivery = pd.Timestamp("2026-11-01")
    dates = pd.bdate_range("2026-09-15", "2026-10-28")
    rows = [
        _pack_row("DE", d, delivery, "MONTHLY", "NOV", 100.0, 30.0,
                  gas_price=20.0)
        for d in dates
    ]
    bundle = {"CSS_raw": _pack_raw(rows)}
    scr = cs_analytics.screener(bundle, ["DE"], "HR_GAS")
    assert len(scr) == 1
    # Clean gas heat rate = P / X = 100 / 30
    assert scr.iloc[0]["Outright"] == pytest.approx(100.0 / 30.0, abs=1e-9)
    # Constant P and X -> flat HR history
    assert scr.iloc[0]["DoD"] == pytest.approx(0.0, abs=1e-12)


def test_rolldown_table_heat_rate():
    td = pd.Timestamp("2026-10-05")
    bundle = {"CSS_raw": _pack_raw([
        _pack_row("DE", td, pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                  100.0, 30.0, gas_price=20.0),
        _pack_row("DE", td, pd.Timestamp("2027-01-01"), "QUARTERLY", "Q1",
                  100.0, 40.0, gas_price=25.0),
    ])}
    roll = cs_analytics.rolldown_table(bundle, "DE", "HR_GAS")
    assert len(roll) == 2
    # HR rolldown = P/X_nov - P/X_q1 = 100/30 - 100/40
    assert roll.iloc[1]["Rolldown"] == pytest.approx(
        100.0 / 30.0 - 100.0 / 40.0, abs=1e-9)


def test_risk_premium_heat_rate(monkeypatch):
    delivery = pd.Timestamp("2025-10-01")
    rows = [
        _pack_row("DE", delivery - pd.Timedelta(days=dtd), delivery,
                  "MONTHLY", "OCT", 100.0, x, gas_price=20.0)
        for dtd, x in [(30, 25.0), (60, 20.0)]
    ]
    bundle = {"CSS_raw": _pack_raw(rows)}
    delivered = pd.DataFrame({
        "month": [pd.Timestamp("2025-10-01")], "value": [3.5]})
    monkeypatch.setattr(cs_data, "delivered_heat_rate_monthly",
                        lambda *a, **k: delivered)
    prem = cs_analytics.risk_premium(bundle, "DE", "HR_GAS")
    assert len(prem) == 1
    # Forward HR at D-30 = 100/25 = 4.0; premium = 4.0 - 3.5
    assert prem.iloc[0]["prem_30"] == pytest.approx(0.5, abs=1e-9)
    assert prem.iloc[0]["prem_60"] == pytest.approx(
        100.0 / 20.0 - 3.5, abs=1e-9)


def test_winsum_spreads():
    strips = pd.DataFrame([
        {"season": "SUM", "season_year": 2027, "value": 20.0,
         "n_months": 6, "STRIP": "SUM-27",
         "season_start": pd.Timestamp("2027-04-01")},
        {"season": "WIN", "season_year": 2027, "value": 35.0,
         "n_months": 6, "STRIP": "WIN-27",
         "season_start": pd.Timestamp("2027-10-01")},
    ])
    out = cs_analytics.winsum_spreads(strips)
    assert len(out) == 1
    assert out.iloc[0]["spread"] == pytest.approx(15.0, abs=1e-9)


def test_hedge_ratios_de_and_gb():
    td = pd.Timestamp("2026-10-05")
    rows = [_pack_row(c, td, pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                      100.0, 30.0, gas_price=20.0) for c in ("DE", "GB")]
    bundle = {"CSS_raw": _pack_raw(rows)}

    de = cs_analytics.hedge_ratios(bundle, "DE", "NOV-26", mw=10.0)
    hours = 30 * 24
    assert de["hours"] == pytest.approx(hours, abs=1e-9)
    assert de["gas_mwh"] == pytest.approx(10 * hours / 0.5, abs=1e-6)
    assert de["carbon_tonnes"] == pytest.approx(
        10 * hours * GAS_EF / 0.5, abs=1e-6)
    assert de["carbon_unit"] == "EUA"

    gb = cs_analytics.hedge_ratios(bundle, "GB", "NOV-26", mw=10.0)
    assert gb["gas_mwh"] == pytest.approx(10 * hours / UK_GAS_EFF, abs=1e-6)
    assert gb["carbon_unit"] == "UKA"
    assert "cps_note" in gb


def test_calendar_heatmap_grid():
    from core.clean_spreads.charts import calendar_heatmap

    dates = pd.date_range("2026-08-03", "2026-09-06", freq="D")  # Mon-Sun
    series = pd.Series(range(len(dates)), index=dates, dtype=float)
    fig = calendar_heatmap(series, "Test", decimals=0)
    heatmap = fig.data[0]
    z = np.array(heatmap.z, dtype=float)
    assert z.shape[0] == 9  # 7 weekdays + week avg + month avg
    assert z.shape[1] == 5  # five ISO weeks
    # First cell: Monday 3 Aug = value 0
    assert z[0, 0] == 0.0
    # Week-average row populated
    assert not np.isnan(z[7, :]).all()
    # Month-average row populated
    assert not np.isnan(z[8, :]).all()


# ── User-selectable efficiencies ───────────────────────────────────────────
def test_normalize_effs_percent_fraction_and_clamp():
    defaults = cs_data.normalize_effs(None)
    assert defaults["gas"] == pytest.approx(GAS_EFFS["mid"])
    assert defaults["coal"] == pytest.approx(COAL_EFFS["mid"])
    assert defaults["lignite"] == pytest.approx(DEFAULT_LIGNITE_EFF)
    assert all(defaults[f"{fuel}_default"]
               for fuel in ("gas", "coal", "lignite"))

    # Percentages as typed in the UI, fractions and numeric strings all work
    typed = cs_data.normalize_effs({"gas": 55, "coal": 0.42, "lignite": "38"})
    assert typed["gas"] == pytest.approx(0.55)
    assert typed["coal"] == pytest.approx(0.42)
    assert typed["lignite"] == pytest.approx(0.38)
    assert not any(typed[f"{fuel}_default"]
                   for fuel in ("gas", "coal", "lignite"))

    # Out of range clamps; blanks / garbage fall back to the defaults
    messy = cs_data.normalize_effs({"gas": 999, "coal": None, "lignite": "x"})
    assert messy["gas"] == pytest.approx(EFF_MAX)
    assert messy["coal"] == pytest.approx(COAL_EFFS["mid"])
    assert messy["lignite"] == pytest.approx(DEFAULT_LIGNITE_EFF)

    # Idempotent: a normalized dict normalizes to itself
    assert cs_data.normalize_effs(typed) == typed


def test_apply_effs_default_leaves_precomputed_columns_untouched():
    css = _make_css_raw()
    bundle = {"CSS_raw": css}
    view = cs_data.apply_effs(bundle, None)

    assert view["CSS_raw"]["CSS_MID_EFF"].equals(css["CSS_MID_EFF"])
    assert "CSS_BAND_LO" not in view["CSS_raw"].columns
    assert cs_data.bundle_effs(view)["gas_default"]
    # No GAS_PRICE in this frame -> no lignite spread, and the cached frame
    # is never mutated in place
    assert "CLS_MID_EFF" not in view["CSS_raw"].columns
    assert "CLS_MID_EFF" not in css.columns
    assert cs_data.EFF_KEY not in bundle


def _one_css_bundle(power=100.0, gas=30.0, carbon=70.0):
    """Single-contract CSS bundle with a recoverable gas/carbon split."""
    return {"CSS_raw": _pack_raw([
        _pack_row("DE", pd.Timestamp("2026-10-05"),
                  pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                  power, gas + GAS_EF * carbon, gas_price=gas)])}


def test_apply_effs_reefficiencies_css_exactly():
    power, gas, carbon = 100.0, 30.0, 70.0
    x = gas + GAS_EF * carbon
    view = cs_data.apply_effs(_one_css_bundle(power, gas, carbon),
                              {"gas": 60})
    row = view["CSS_raw"].iloc[0]

    assert row["CSS_MID_EFF"] == pytest.approx(power - x / 0.60, abs=1e-9)
    assert row["CSS_BAND_LO"] == pytest.approx(
        power - x / (0.60 - EFF_BAND), abs=1e-9)
    assert row["CSS_BAND_HI"] == pytest.approx(
        power - x / (0.60 + EFF_BAND), abs=1e-9)
    # LOW/HI keep the precomputed convention so P and X stay recoverable
    assert row["CSS_LOW_EFF"] == pytest.approx(
        power - x / GAS_EFFS["low"], abs=1e-9)
    p, imp_x = cs_data._implied_p_x(view["CSS_raw"], "CSS", GAS_EFFS)
    assert float(p.iloc[0]) == pytest.approx(power, abs=1e-9)
    assert float(imp_x.iloc[0]) == pytest.approx(x, abs=1e-9)


def test_apply_effs_adds_clean_lignite_spread():
    power, gas, carbon = 100.0, 30.0, 70.0
    bundle = _one_css_bundle(power, gas, carbon)
    lig_x = LIGNITE_FUEL_COST + LIGNITE_EF * carbon

    default = cs_data.apply_effs(bundle, None)["CSS_raw"].iloc[0]
    assert default["CLS_MID_EFF"] == pytest.approx(
        power - lig_x / DEFAULT_LIGNITE_EFF, abs=1e-9)

    typed = cs_data.apply_effs(bundle, {"lignite": 35})["CSS_raw"].iloc[0]
    assert typed["CLS_MID_EFF"] == pytest.approx(
        power - lig_x / 0.35, abs=1e-9)
    assert typed["CLS_BAND_HI"] == pytest.approx(
        power - lig_x / (0.35 + EFF_BAND), abs=1e-9)
    # A negative implied carbon price cannot price lignite -> NaN
    impossible = cs_data.apply_effs(
        _one_css_bundle(power, gas=50.0, carbon=-10.0), None)
    assert pd.isna(impossible["CSS_raw"].iloc[0]["CLS_MID_EFF"])


def test_apply_effs_reefficiencies_cds():
    power, x = 100.0, 25.0
    cds = _pack_raw([_pack_row("DE", pd.Timestamp("2026-10-05"),
                               pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                               power, x, metric="CDS")])
    row = cs_data.apply_effs({"CDS_raw": cds},
                             {"coal": 45})["CDS_raw"].iloc[0]
    assert row["CDS_MID_EFF"] == pytest.approx(power - x / 0.45, abs=1e-9)
    assert row["CDS_BAND_LO"] == pytest.approx(
        power - x / (0.45 - EFF_BAND), abs=1e-9)
    # Coal left alone when the input stays at 40%
    untouched = cs_data.apply_effs({"CDS_raw": cds}, None)["CDS_raw"]
    assert untouched["CDS_MID_EFF"].equals(cds["CDS_MID_EFF"])


def test_spread_eff_gb_keeps_market_convention_until_overridden():
    default = cs_data.apply_effs({}, None)
    assert cs_data.spread_eff(default, "GB") == pytest.approx(UK_GAS_EFF)
    assert cs_data.spread_eff(default, "DE") == pytest.approx(
        GAS_EFFS["mid"])
    assert cs_data.spread_eff(default, "GB", "coal") == pytest.approx(
        COAL_EFFS["mid"])

    typed = cs_data.apply_effs({}, {"gas": 58})
    assert cs_data.spread_eff(typed, "GB") == pytest.approx(0.58)
    assert cs_data.spread_eff(typed, "DE") == pytest.approx(0.58)


def test_metric_band_follows_the_inputs():
    default = cs_data.normalize_effs(None)
    assert cs_data.metric_band("CSS", default) == (
        GAS_EFFS["low"], GAS_EFFS["hi"])
    assert cs_data.metric_band("CLS", default) == pytest.approx(
        (DEFAULT_LIGNITE_EFF - EFF_BAND, DEFAULT_LIGNITE_EFF + EFF_BAND))
    typed = cs_data.normalize_effs({"gas": 60})
    assert cs_data.metric_band("CSS", typed) == pytest.approx(
        (0.60 - EFF_BAND, 0.60 + EFF_BAND))


def test_curve_chart_labels_carry_the_efficiency():
    from core.clean_spreads.charts import curve_trace_name

    default = cs_data.normalize_effs(None)
    assert curve_trace_name("CSS", default) == "CSS mid (band 48–52%)"
    assert curve_trace_name("CDS", default) == "CDS mid (band 36–42%)"
    assert curve_trace_name("CLS", default) == \
        "CLS 37% eff (band 35–39%)"
    typed = cs_data.normalize_effs({"gas": 60})
    assert curve_trace_name("CSS", typed) == "CSS 60% eff (band 58–62%)"


def test_daily_spot_metrics_follows_typed_effs():
    from core.clean_spreads.constants import (
        API2_TO_MWH, USD_TO_EUR_FALLBACK,
    )

    bundle = cs_data.apply_effs(_spot_bundle(),
                                {"gas": 60, "coal": 45, "lignite": 35})
    row = cs_data.daily_spot_metrics(bundle, "DE", days=450).iloc[-1]
    assert row["CSS"] == pytest.approx(
        80 - 30 / 0.6 - (GAS_EF / 0.6) * 70, abs=1e-6)
    coal_eur = 100.0 * USD_TO_EUR_FALLBACK / API2_TO_MWH
    assert row["CDS"] == pytest.approx(
        80 - coal_eur / 0.45 - (COAL_EF / 0.45) * 70, abs=1e-6)
    lig_x = LIGNITE_FUEL_COST + LIGNITE_EF * 70
    assert row["CLS"] == pytest.approx(80 - lig_x / 0.35, abs=1e-6)
    # Heat rates are efficiency-free and must not move
    assert row["HeatRate"] == pytest.approx(80 / (30 + GAS_EF * 70), abs=1e-9)

    # GB follows the typed efficiency too, but keeps 49.13% at the default
    gb_typed = cs_data.daily_spot_metrics(bundle, "GB", days=450).iloc[-1]
    nbp_eur, uka_eur = 25.0, (40.0 + 18.0) / 0.85
    assert gb_typed["CSS"] == pytest.approx(
        90 - nbp_eur / 0.6 - (GAS_EF / 0.6) * uka_eur, abs=1e-6)
    gb_default = cs_data.daily_spot_metrics(
        cs_data.apply_effs(_spot_bundle(), None), "GB", days=450).iloc[-1]
    assert gb_default["CSS"] == pytest.approx(
        90 - nbp_eur / UK_GAS_EFF - (GAS_EF / UK_GAS_EFF) * uka_eur,
        abs=1e-6)


def test_delivered_spread_monthly_switches_to_spot_off_default():
    frame = _delivered_frame()
    default = cs_data.apply_effs({"delivered_spreads": frame}, None)
    assert cs_data.delivered_strip_value(default, "GB", "Q1", 2026) == 11.0
    assert cs_data.delivered_strip_value(default, "GB", "JAN", 2026) == 12.5

    # A typed efficiency cannot reuse the precomputed 50% outturn; without
    # spot data there is nothing to fall back to
    typed = cs_data.apply_effs({"delivered_spreads": frame}, {"gas": 60})
    assert cs_data.delivered_strip_value(typed, "GB", "Q1", 2026) is None

    spot = cs_data.apply_effs(_spot_bundle(), {"gas": 60})
    monthly = cs_data.delivered_spread_monthly(spot, "DE", "CSS")
    expected = 80 - 30 / 0.6 - (GAS_EF / 0.6) * 70
    assert len(monthly) == 2  # Aug + Sep 2026 in the synthetic window
    assert monthly["value"].iloc[0] == pytest.approx(expected, abs=1e-6)
    assert cs_data.delivered_strip_value(
        spot, "DE", "AUG", 2026, "CSS") == pytest.approx(expected, abs=1e-6)
    # Q3 needs Jul-Sep; July is outside the window -> no partial strip mean
    assert cs_data.delivered_strip_value(spot, "DE", "Q3", 2026, "CSS") is None


def test_clean_lignite_metric_flows_through_the_trader_pack():
    td = pd.Timestamp("2026-10-05")
    bundle = cs_data.apply_effs({"CSS_raw": _pack_raw([
        _pack_row("DE", td, pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                  100.0, 30.0 + GAS_EF * 70.0, gas_price=30.0),
        _pack_row("DE", td, pd.Timestamp("2027-01-01"), "QUARTERLY", "Q1",
                  100.0, 30.0 + GAS_EF * 90.0, gas_price=30.0),
    ])}, {"lignite": 40})

    roll = cs_analytics.rolldown_table(bundle, "DE", "CLS")
    assert len(roll) == 2
    lig_nov = LIGNITE_FUEL_COST + LIGNITE_EF * 70.0
    lig_q1 = LIGNITE_FUEL_COST + LIGNITE_EF * 90.0
    assert roll.iloc[1]["Rolldown"] == pytest.approx(
        (lig_q1 - lig_nov) / 0.40, abs=1e-9)

    scr = cs_analytics.screener(bundle, ["DE"], "CLS")
    assert len(scr) == 2
    assert scr.iloc[0]["Outright"] == pytest.approx(
        100.0 - lig_nov / 0.40, abs=1e-9)


# ── Issue date of the forward curves ───────────────────────────────────────
def _two_country_bundle(de_dates, gb_dates, x=40.0):
    rows = []
    for country, dates in (("DE", de_dates), ("GB", gb_dates)):
        for day in dates:
            rows.append(_pack_row(country, pd.Timestamp(day),
                                  pd.Timestamp("2027-01-01"), "QUARTERLY",
                                  "Q1", 100.0, x))
    return {"CSS_raw": _pack_raw(rows)}


def test_curve_issue_dates_per_country():
    bundle = _two_country_bundle(
        de_dates=["2026-09-10", "2026-09-14"],      # Thu, Mon
        gb_dates=["2026-09-10", "2026-09-11"])      # Thu, Fri
    issued = cs_data.curve_issue_dates(bundle)
    assert issued == {"DE": pd.Timestamp("2026-09-14"),
                      "GB": pd.Timestamp("2026-09-11")}


def test_curve_issue_dates_ignore_all_nan_trade_dates():
    bundle = _two_country_bundle(de_dates=["2026-09-10", "2026-09-14"],
                                 gb_dates=["2026-09-14"])
    raw = bundle["CSS_raw"].copy()
    # DE quoted on the 14th but with no price -> the 10th is the real issue
    de_latest = (raw.index.get_level_values("COUNTRY") == "DE") & (
        raw.index.get_level_values("DATE") == pd.Timestamp("2026-09-14"))
    raw.loc[de_latest, "CSS_MID_EFF"] = np.nan
    issued = cs_data.curve_issue_dates({"CSS_raw": raw})
    assert issued["DE"] == pd.Timestamp("2026-09-10")
    assert issued["GB"] == pd.Timestamp("2026-09-14")


def test_forward_issue_summary_flags_staleness_and_laggards():
    bundle = _two_country_bundle(de_dates=["2026-09-14"],
                                 gb_dates=["2026-09-11"])

    # Tuesday looking at Monday's curve: one business day old -> fresh
    fresh = cs_data.forward_issue_summary(bundle, ["DE", "GB"],
                                          today=pd.Timestamp("2026-09-15"))
    assert fresh["latest"] == pd.Timestamp("2026-09-14")
    assert fresh["age"] == 1
    assert fresh["status"] == "fresh"
    # GB's Friday curve is one business day behind the Monday one
    assert fresh["behind"] == {"GB": 1}

    # Three business days later the page is showing last week's curve
    stale = cs_data.forward_issue_summary(bundle, ["DE", "GB"],
                                          today=pd.Timestamp("2026-09-17"))
    assert stale["age"] == 3 and stale["status"] == "stale"

    critical = cs_data.forward_issue_summary(bundle, ["DE", "GB"],
                                             today=pd.Timestamp("2026-09-25"))
    assert critical["age"] == 9 and critical["status"] == "critical"

    empty = cs_data.forward_issue_summary({}, ["DE"])
    assert empty["status"] == "unknown" and empty["latest"] is None


def _css_cds_bundle(css_dates, cds_dates, country="DE"):
    """Bundle whose spark and dark frames stop on different trade dates."""
    css = [_pack_row(country, pd.Timestamp(d), pd.Timestamp("2027-01-01"),
                     "QUARTERLY", "Q1", 100.0, 40.0) for d in css_dates]
    cds = [_pack_row(country, pd.Timestamp(d), pd.Timestamp("2027-01-01"),
                     "QUARTERLY", "Q1", 100.0, 25.0, metric="CDS")
           for d in cds_dates]
    return {"CSS_raw": _pack_raw(css), "CDS_raw": _pack_raw(cds)}


def test_per_metric_issue_dates_are_reported_not_hidden():
    # The real shape of the feed: dark curve one trade day behind spark
    bundle = _css_cds_bundle(css_dates=["2026-09-15", "2026-09-16"],
                             cds_dates=["2026-09-14", "2026-09-15"])
    summary = cs_data.forward_issue_summary(bundle, ["DE"],
                                            today=pd.Timestamp("2026-09-17"))

    # Headline stays the newest frame, but each metric carries its own date
    assert summary["latest"] == pd.Timestamp("2026-09-16")
    assert summary["per_metric"]["CSS"]["latest"] == pd.Timestamp(
        "2026-09-16")
    assert summary["per_metric"]["CDS"]["latest"] == pd.Timestamp(
        "2026-09-15")
    assert summary["per_metric"]["CSS"]["behind"] == 0
    assert summary["per_metric"]["CDS"]["behind"] == 1
    assert summary["metrics_behind"] == {"CDS": 1}
    # One trade day of lag is this feed's normal cadence -> reported, not
    # escalated; the countries themselves are level so nothing warns
    assert summary["per_metric"]["CDS"]["status"] == "fresh"
    assert summary["absolute_status"] == "fresh"
    assert summary["status"] == "fresh"
    assert summary["behind"] == {}


def test_metric_lag_beyond_cadence_escalates():
    bundle = _css_cds_bundle(css_dates=["2026-09-16"],
                             cds_dates=["2026-09-09"])
    summary = cs_data.forward_issue_summary(bundle, ["DE"],
                                            today=pd.Timestamp("2026-09-17"))
    # Spark is current, so the absolute check alone would say "fresh"
    assert summary["absolute_status"] == "fresh"
    # but the dark curve is 5 trade days behind -> the strip escalates
    assert summary["metrics_behind"] == {"CDS": 5}
    assert summary["per_metric"]["CDS"]["status"] == "stale"
    assert summary["status"] == "stale"


def test_clean_lignite_issue_date_only_when_computable():
    # No GAS_PRICE -> no CLS columns -> CLS must not borrow the CSS dates
    bundle = cs_data.apply_effs(
        _css_cds_bundle(["2026-09-16"], ["2026-09-16"]), None)
    summary = cs_data.forward_issue_summary(bundle, ["DE"])
    assert "CLS" not in summary["per_metric"]
    assert cs_data.curve_issue_dates(bundle, "CLS") == {}

    # With a gas leg, CLS is computable and dated off the spark frame
    priced = cs_data.apply_effs({"CSS_raw": _pack_raw([
        _pack_row("DE", pd.Timestamp("2026-09-16"),
                  pd.Timestamp("2027-01-01"), "QUARTERLY", "Q1",
                  100.0, 30.0 + GAS_EF * 70.0, gas_price=30.0)])}, None)
    assert cs_data.curve_issue_dates(priced, "CLS") == {
        "DE": pd.Timestamp("2026-09-16")}


def _gb_leg_bundle(cost_multiplier=1.0):
    """GB bundle whose CSS legs cost ``multiplier`` x the cash fuels."""
    spot = _spot_bundle()
    # NBP cached in EUR/MWh (no FX), UKA in GBP/t (converted with the CPS)
    nbp_eur, uka_gbp, eurgbp = 25.0, 40.0, 0.85
    true_x = nbp_eur + GAS_EF * (uka_gbp + 18.0) / eurgbp
    x = true_x * cost_multiplier
    power = 120.0
    # Quarterly: on a mid-September curve date the front monthly contract
    # falls outside the stitching window (see build_curve)
    css = _pack_raw([_pack_row("GB", pd.Timestamp("2026-09-16"),
                               pd.Timestamp("2026-10-01"), "QUARTERLY",
                               "Q4", power, x)])
    return {**spot, "CSS_raw": css}, true_x


def test_cps_diagnostic_flags_legs_that_do_not_reconcile():
    # A GB cost leg twice the cash fuels: the CPS question is unanswerable
    bundle, true_x = _gb_leg_bundle(cost_multiplier=2.0)
    diag = cs_data.uk_cps_diagnostic(bundle)
    assert diag is not None
    assert diag["ratio"] == pytest.approx(2.0, abs=0.05)
    assert diag["consistent"] is False
    assert "WARNING" in diag["verdict"]
    assert "2.0" in diag["verdict"] or "1.9" in diag["verdict"]
    # CPS is worth a couple of EUR/MWh -- must not be offered as the cause
    assert "INCLUDE" not in diag["verdict"]
    assert "EXCLUDE" not in diag["verdict"]

    # A consistent leg still answers the original CPS question
    healthy, _ = _gb_leg_bundle(cost_multiplier=1.0)
    ok = cs_data.uk_cps_diagnostic(healthy)
    assert ok["consistent"] is True
    assert ok["ratio"] == pytest.approx(1.0, abs=0.05)
    assert "INCLUDE" in ok["verdict"] or "EXCLUDE" in ok["verdict"]
    assert ok["implied_x"] == pytest.approx(true_x, abs=0.5)


def test_uk_tab_warns_when_gb_legs_are_inconsistent(monkeypatch):
    from core.clean_spreads import callbacks as cs_callbacks

    broken, _ = _gb_leg_bundle(cost_multiplier=2.0)
    monkeypatch.setattr(cs_data, "get_bundle", lambda *a, **k: broken)
    _curve, _hist, diagnostic = cs_callbacks.update_uk_charts("uk", None)

    # A styled alert, not a sentence buried in grey footnote text
    assert not isinstance(diagnostic, str)
    text = str(diagnostic)
    assert "look wrong" in text
    assert "upstream data issue" in text


def test_issue_banner_shows_every_metric_date():
    from core.clean_spreads import callbacks as cs_callbacks

    summary = {
        "latest": pd.Timestamp("2026-09-16"),
        "per_metric": {
            "CSS": {"latest": pd.Timestamp("2026-09-16"), "behind": 0,
                    "status": "fresh"},
            "CDS": {"latest": pd.Timestamp("2026-09-15"), "behind": 1,
                    "status": "fresh"},
            "CLS": {"latest": pd.Timestamp("2026-09-09"), "behind": 5,
                    "status": "stale"},
        },
    }
    chips = cs_callbacks._metric_issue_chips(summary)
    text = [chip.children for chip in chips]
    assert text == ["CSS 16 Sep",
                    "CDS 15 Sep (1 trade day behind)",
                    "CLS 09 Sep (5 trade days behind)"]
    # Only the chip beyond normal cadence is highlighted
    assert chips[0].style["fontWeight"] == "500"
    assert chips[1].style["fontWeight"] == "500"
    assert chips[2].style["fontWeight"] == "600"


def test_issue_date_reaches_the_figures_and_the_screener():
    from core.clean_spreads import charts as cs_charts
    from core.clean_spreads.tables import make_screener_table

    issued = pd.Timestamp("2026-09-14")
    assert cs_charts.issued_suffix(issued) == " — issued 14 Sep 2026"
    assert cs_charts.issued_suffix(None) == ""

    bundle = cs_data.apply_effs(_two_country_bundle(
        de_dates=["2026-09-10", "2026-09-14"],
        gb_dates=["2026-09-10", "2026-09-11"]), None)

    curve = cs_data.build_curve(bundle["CSS_raw"], "DE",
                                cs_data.metric_cols("CSS"))
    fig = cs_charts.curve_chart({"CSS": {"current": curve}}, "DE",
                                cs_data.bundle_effs(bundle))
    assert "issued 14 Sep 2026" in fig.layout.title.text

    # Screener rows carry their own issue date, so GB's lag is visible
    scr = cs_analytics.screener(bundle, ["DE", "GB"], "CSS")
    assert dict(zip(scr["Country"], scr["Issued"])) == {
        "DE": pd.Timestamp("2026-09-14"),
        "GB": pd.Timestamp("2026-09-11")}
    table = make_screener_table(scr)
    assert [c["id"] for c in table["columns"]][:4] == [
        "Country", "STRIP", "Type", "Issued"]
    assert {row["Issued"] for row in table["data"]} == {"2026-09-14",
                                                        "2026-09-11"}


# ── Rendered-view cache ────────────────────────────────────────────────────
def _unique_view_name(prefix: str) -> str:
    """A view name no earlier test run can have cached (the disk cache
    outlives the process)."""
    import uuid

    return f"{prefix}_{uuid.uuid4().hex[:10]}"


def test_view_cache_serves_repeats_and_keys_on_effs():
    bundle = cs_data.apply_effs(_one_css_bundle(), None)
    name = _unique_view_name("unit_test_view")
    calls = {"n": 0}

    def build():
        calls["n"] += 1
        return ("payload", calls["n"])

    first = cs_data.cached_view(bundle, name, build, "DE", "CSS")
    again = cs_data.cached_view(bundle, name, build, "DE", "CSS")
    assert first == again == ("payload", 1)
    assert calls["n"] == 1                      # second call served from cache

    # A different control value is a different view
    cs_data.cached_view(bundle, name, build, "FR", "CSS")
    assert calls["n"] == 2
    # ...and so is a different efficiency, even for the same controls
    typed = cs_data.apply_effs(_one_css_bundle(), {"gas": 61})
    cs_data.cached_view(typed, name, build, "DE", "CSS")
    assert calls["n"] == 3


def test_view_cache_is_invalidated_by_a_code_change(monkeypatch):
    """A cached view holds the shape its callback expected at the time.

    Without this, the first request after a deploy that changes a view's
    return shape unpacks the old value into the new outputs (a 500).
    """
    bundle = cs_data.apply_effs(_one_css_bundle(), None)
    name = _unique_view_name("unit_test_shape")
    calls = {"n": 0}

    def build():
        calls["n"] += 1
        return {"shape": "v1", "n": calls["n"]}

    cs_data.cached_view(bundle, name, build, "DE")
    cs_data.cached_view(bundle, name, build, "DE")
    assert calls["n"] == 1

    monkeypatch.setattr(cs_data, "_CODE_FINGERPRINT", "deadbeef")
    cs_data.cached_view(bundle, name, build, "DE")
    assert calls["n"] == 2          # new code -> rebuilt, not reinterpreted


def test_curve_from_flat_matches_build_curve():
    """The ridge slices one country then loops; it must agree with the
    per-call path it replaced."""
    df = _make_css_raw(trade_dates=[pd.Timestamp("2026-09-01"),
                                    pd.Timestamp("2026-09-10")])
    flat = cs_data._country_frame(df, "GB")
    for asof in (None, pd.Timestamp("2026-09-05")):
        direct = cs_data.build_curve(df, "GB", ["CSS_MID_EFF"], asof=asof)
        from_flat = cs_data.curve_from_flat(flat, ["CSS_MID_EFF"], asof=asof)
        pd.testing.assert_frame_equal(direct, from_flat)
    assert cs_data.curve_from_flat(pd.DataFrame(), ["CSS_MID_EFF"]).empty


# ── Table styling: constant size, same colours ─────────────────────────────
def _style_for(styles, column, value):
    """The background a band rule set gives one (column, value) pair."""
    from core.clean_spreads.tables import _GREEN, _RED

    hit = None
    for rule in styles:
        cond = rule.get("if") or {}
        if cond.get("column_id") != column or "filter_query" not in cond:
            continue
        query = cond["filter_query"].replace(f"{{{column}}}", "v")
        if eval(query.replace("&&", "and"), {"v": value}):  # noqa: S307
            hit = rule["backgroundColor"]
    assert hit is None or _GREEN in hit or _RED in hit
    return hit


def test_change_shading_is_banded_not_per_row():
    from core.clean_spreads.tables import _shade, make_snapshot_table

    snapshot = pd.DataFrame({
        "STRIP": [f"Q{i}-27" for i in range(1, 5)],
        "CONTRACT_TYPE": ["QUARTERLY"] * 4,
        "Outright": [10.0, 20.0, 30.0, 40.0],
        "DoD": [0.1, -0.6, 3.0, np.nan],
        "WoW": [-0.2, 1.5, -4.0, 0.0],
        "MoM": [0.0, -2.0, 0.3, 1.0],
    })
    table = make_snapshot_table(snapshot)
    styles = table["style_data_conditional"]

    # One striping rule plus a fixed set of bands: no row_index entries
    assert not [s for s in styles if "row_index" in (s.get("if") or {})
                and s["if"]["row_index"] != "odd"]
    # 3 change columns x 4 buckets x 2 signs, plus the striping rule
    assert len(styles) == 1 + 3 * 4 * 2

    # Adding rows must not add rules
    bigger = pd.concat([snapshot] * 30, ignore_index=True)
    assert len(make_snapshot_table(bigger)["style_data_conditional"]) == \
        len(styles)

    # The bands reproduce the per-cell colours they replaced
    for value in (0.1, 0.9, 2.0, 12.0, -0.1, -0.9, -2.0, -12.0):
        assert _style_for(styles, "DoD", value) == _shade(value, "spread")
    assert _style_for(styles, "DoD", 0.0) is None


def test_screener_shading_is_banded():
    from core.clean_spreads.tables import make_screener_table

    screener = pd.DataFrame({
        "Country": ["DE", "FR", "NL"],
        "STRIP": ["Q1-27"] * 3, "Type": ["Quarterly"] * 3,
        "Issued": pd.to_datetime(["2026-09-16"] * 3),
        "Outright": [10.0, 20.0, 30.0], "DoD": [0.5, -0.5, 1.0],
        "zDoD": [2.5, -0.9, np.nan], "WoW": [1.0, 2.0, 3.0],
        "MoM": [1.0, 2.0, 3.0], "Pctile": [95.0, 5.0, 50.0],
        "Obs": [100, 200, 300],
    })
    styles = make_screener_table(screener)["style_data_conditional"]
    assert not [s for s in styles if "row_index" in (s.get("if") or {})
                and s["if"]["row_index"] != "odd"]
    # 3 shaded z buckets x 2 signs + 2 percentile rules + striping
    assert len(styles) == 1 + 3 * 2 + 2
    assert _style_for(styles, "zDoD", 2.5) is not None
    assert _style_for(styles, "zDoD", 0.2) is None      # inside the dead band
    assert _style_for(styles, "Pctile", 95.0) is not None
    assert _style_for(styles, "Pctile", 50.0) is None


def test_controls_persist_across_reloads():
    from core.clean_spreads.layout import (
        _country_dropdown, _metric_radio, _pack_metric_radio,
    )

    for component in (_country_dropdown("x"), _metric_radio("y"),
                      _pack_metric_radio("z")):
        assert component.persistence is True
        assert component.persistence_type == "local"


def test_layout_exposes_the_efficiency_inputs():
    from core.clean_spreads import callbacks as cs_callbacks  # noqa: F401
    from core.clean_spreads.layout import build_layout

    def _ids(component) -> set:
        found = set()
        component_id = getattr(component, "id", None)
        if isinstance(component_id, str):
            found.add(component_id)
        children = getattr(component, "children", None)
        if children is None:
            return found
        if not isinstance(children, (list, tuple)):
            children = [children]
        for child in children:
            if hasattr(child, "children") or hasattr(child, "id"):
                found |= _ids(child)
        return found

    ids = _ids(build_layout())
    assert {"cs-eff-store", "cs-eff-gas", "cs-eff-coal", "cs-eff-lignite",
            "cs-eff-note", "cs-snap-cls-table",
            "cs-issue-banner", "cs-issue-poll"} <= ids


def test_snapshot_helpers_fill_every_callback_output():
    from core.clean_spreads import callbacks as cs_callbacks

    td = pd.Timestamp("2026-10-05")
    css = _pack_raw([
        _pack_row("DE", td, pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                  100.0, 30.0 + GAS_EF * 70.0, gas_price=30.0),
        _pack_row("DE", td, pd.Timestamp("2027-01-01"), "QUARTERLY", "Q1",
                  100.0, 30.0 + GAS_EF * 75.0, gas_price=30.0),
    ])
    cds = _pack_raw([
        _pack_row("DE", td, pd.Timestamp("2026-11-01"), "MONTHLY", "NOV",
                  100.0, 25.0, metric="CDS"),
    ])
    bundle = cs_data.apply_effs({"CSS_raw": css, "CDS_raw": cds},
                                {"gas": 55, "coal": 42, "lignite": 40})

    # figure + 3 tables x (data, columns, styles) + 3 titles + footnote
    spreads = cs_callbacks._snapshot_spreads(bundle, "DE", "ALL")
    assert len(spreads) == 14
    assert len(spreads[0].data) > 0            # CSS/CDS/CLS traces drawn
    assert spreads[1] and spreads[4] and spreads[7]  # all three tables filled
    assert "55%" in spreads[-1] and "40%" in spreads[-1]

    heat_rates = cs_callbacks._snapshot_heat_rates(bundle, "DE", "COMBINED")
    assert len(heat_rates) == 14


def test_seasonality_matrix_marks_forward():
    delivered = pd.DataFrame({
        "month": [pd.Timestamp(2026, 1, 1), pd.Timestamp(2026, 2, 1)],
        "value": [10.0, 11.0],
    })
    forward = pd.DataFrame({
        "month": [pd.Timestamp(2026, 3, 1), pd.Timestamp(2026, 4, 1)],
        "value": [12.0, 13.0],
        "STRIP": ["MAR-26", "APR-26"],
    })
    matrix = cs_data.seasonality_matrix(delivered, forward)
    values, is_fwd = matrix["values"], matrix["is_forward"]
    assert values.loc[2026, 1] == 10.0
    assert values.loc[2026, 3] == 12.0
    assert not is_fwd.loc[2026, 1]
    assert is_fwd.loc[2026, 3]
