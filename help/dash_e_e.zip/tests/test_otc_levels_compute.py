"""Unit tests for :mod:`core.otc_levels.compute` (pure pandas, no Snowflake)."""
from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import pytest

from core.otc_levels import compute as C


def _print(t, price, qty, venue, aggressor_buy, tenor, family):
    return {
        "TRADE_ID": f"{venue}-{tenor}-{t.isoformat()}-{price}",
        "DEAL_TIME_UTC": t, "PRICE": price, "QUANTITY": qty, "VENUE_CODE": venue,
        "AGGRESSOR_BUY": aggressor_buy, "FROM_BROKEN_SPREAD": False, "CONTRACT_TYPE": "SinglePeriod",
        "TENOR_FAMILY": family, "TENOR_NAME": tenor,
    }


@pytest.fixture
def raw() -> pd.DataFrame:
    t0 = datetime(2026, 9, 1, 9, 0)
    rows = []
    # EEX screen on Cal 27 every 10 minutes, price drifting 80 -> 81
    for i in range(12):
        rows.append(_print(t0 + timedelta(minutes=10 * i), 80 + i * 0.1, 1, "EEX7", bool(i % 2), "2027", "Years"))
    # OTC prints on Cal 27: a 10 MW bid hit on ICAP 5 min after an EEX print at 80.5, a 1 MW offer lifted on BGC
    rows.append(_print(t0 + timedelta(minutes=55), 80.4, 10, "ICAP", False, "2027", "Years"))
    rows.append(_print(t0 + timedelta(minutes=65), 80.7, 1, "BGC", True, "2027", "Years"))
    # broken-spread leg must be dropped
    r = _print(t0 + timedelta(minutes=70), 99.0, 50, "GFI", False, "2027", "Years")
    r["FROM_BROKEN_SPREAD"] = True
    rows.append(r)
    # Q2/Q3 27 legs printed together on ICAP -> Summer strip; plus one unpaired Q2 leg
    ts = t0 + timedelta(hours=2)
    rows.append(_print(ts, 30.0, 20, "ICAP", False, "Q227", "Quarters"))
    rows.append(_print(ts + timedelta(seconds=1), 40.0, 20, "ICAP", False, "Q327", "Quarters"))
    rows.append(_print(ts + timedelta(minutes=30), 31.0, 5, "SPEC", False, "Q227", "Quarters"))
    # EEX on the quarters so the synthetic summer screen exists
    rows.append(_print(t0, 30.2, 1, "EEX7", True, "Q227", "Quarters"))
    rows.append(_print(t0, 40.2, 1, "EEX7", True, "Q327", "Quarters"))
    return pd.DataFrame(rows)


def test_contract_labels():
    assert C.contract_label("2027", "Years") == "Cal 27"
    assert C.contract_label("Q227", "Quarters") == "Q2 27"
    assert C.contract_label("Sep26", "Months") is None


def test_prepare_sides_and_venues(raw):
    df = C.prepare(raw)
    assert (df["QUANTITY"] < 50).all(), "broken-spread leg should be dropped"
    otc = df[df["is_otc"]]
    assert set(otc["venue"]) == {"ICAP", "BGC", "SPEC"}
    icap = otc[(otc["venue"] == "ICAP") & (otc["contract"] == "Cal 27")].iloc[0]
    assert icap["resting"] == "bid"          # seller aggressed -> resting bid hit
    bgc = otc[otc["venue"] == "BGC"].iloc[0]
    assert bgc["resting"] == "offer"         # buyer aggressed -> resting offer lifted
    assert not df[df["VENUE_CODE"] == "EEX7"]["is_otc"].any()


def test_available_and_default_contracts(raw):
    df = C.prepare(raw)
    opts = C.available_contracts(df)
    assert opts == ["Cal 27", "Sum 27", "Q2 27", "Q3 27"]
    assert C.default_contracts(opts, today=datetime(2026, 9, 24)) == ["Cal 27", "Sum 27"]


def test_screen_reference_basis(raw):
    df = C.prepare(raw)
    otc = C.add_screen_reference(df[df["is_otc"]], df[~df["is_otc"]])
    icap = otc[(otc["venue"] == "ICAP") & (otc["contract"] == "Cal 27")].iloc[0]
    # last EEX print before 09:55 was at 09:50 -> 80.5
    assert icap["eex_ref"] == pytest.approx(80.5)
    assert icap["basis"] == pytest.approx(-0.1)


def test_summer_strip_pairing(raw):
    df = C.prepare(raw)
    otc = C.add_screen_reference(df[df["is_otc"]], df[~df["is_otc"]])
    strips = C.build_strips(otc, "27")
    assert len(strips) == 1, "only the ICAP legs share venue, size, side and timestamp"
    s = strips.iloc[0]
    assert s["QUANTITY"] == 20 and s["resting"] == "bid" and s["venue"] == "ICAP"
    expected = (30.0 * 91 + 40.0 * 92) / 183
    assert s["PRICE"] == pytest.approx(expected)


def test_build_dataset_shape(raw):
    ds = C.build_dataset(raw, ["Cal 27", "Sum 27"], "2026-09-01", "2026-09-01", big_clip=5.0)
    assert not ds["empty"]
    assert set(ds["big"]["contract"]) == {"Cal 27", "Sum 27"}
    assert ds["kpis"]["big_bid_mw"] == pytest.approx(30.0)   # 10 MW Cal 27 + 20 MW strip
    assert ds["kpis"]["big_offer_mw"] == 0
    assert ds["kpis"]["top_bid_venue"] == "ICAP"
    assert ds["last_px"]["Cal 27"] == pytest.approx(81.1)
    lad = ds["ladder"]
    assert lad[(lad["contract"] == "Cal 27") & (lad["resting"] == "bid")]["mw"].sum() == 10
    assert set(ds["eex_daily"]["contract"]) == {"Cal 27", "Sum 27"}


def test_build_dataset_window_excludes_outside(raw):
    ds = C.build_dataset(raw, ["Cal 27"], "2026-09-02", "2026-09-03", big_clip=5.0)
    assert ds["prints"].empty


def test_empty_input():
    assert C.build_dataset(pd.DataFrame(), ["Cal 27"], "2026-01-01", "2026-01-02", 5.0) == {"empty": True}
    assert C.prepare(None).empty
