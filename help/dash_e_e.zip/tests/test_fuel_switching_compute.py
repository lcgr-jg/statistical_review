"""
Snapshot / property tests for ``core.fuel_switching.compute``.

These pin the SRMC formula numerically: any accidental change to the
emission factors, conversion constants, or arithmetic will break a
tightly-targeted assert here long before a user spots it on a chart.

Hand-computed expected values (with default constants from
``core.fuel_switching.constants``) are documented inline so reviewers
can audit them.
"""
from __future__ import annotations

import math

import pandas as pd
import pytest

from core.fuel_switching.compute import (
    FuelSwitchingCalculator,
    calculator,
    compute_historical_srmc,
)
from core.fuel_switching.constants import (
    API2_TO_MWH,
    COAL_EMISSIONS,
    GAS_EMISSIONS,
    LIG_EMISSION_FACTOR,
)


# -----------------------------------------------------------------------------
# Fixtures
# -----------------------------------------------------------------------------
@pytest.fixture()
def forward_curve_df() -> pd.DataFrame:
    """Single-row forward curve covering Gas, Coal, Power and Carbon."""
    return pd.DataFrame(
        {
            "Power": [120.0],   # €/MWh
            "Gas": [40.0],      # €/MWh
            "Coal": [110.0],    # USD/t (API2)
            "Carbon": [80.0],   # €/tCO2
        },
        index=pd.to_datetime(["2026-04-01"]),
    )


# -----------------------------------------------------------------------------
# FuelSwitchingCalculator.calculate_srmc
# -----------------------------------------------------------------------------
class TestCalculateSrmc:
    def test_empty_df_returns_empty(self):
        out = calculator.calculate_srmc(pd.DataFrame(), [0.5], [0.4], [0.34], 1.5)
        assert out.empty

    def test_default_usd_to_local_is_injected(self, forward_curve_df):
        df = forward_curve_df.copy()
        out = calculator.calculate_srmc(df, [0.5], [0.4], [0.34], 1.5)
        assert (out["USD_TO_LOCAL"] == 0.96).all()

    def test_gas_srmc_matches_formula(self, forward_curve_df):
        eff = 0.5
        out = calculator.calculate_srmc(
            forward_curve_df.copy(), [eff], [0.4], [0.34], 1.5
        )
        # Gas_SRMC = Gas/eff + (GAS_EMISSIONS/eff) * Carbon
        expected = 40.0 / eff + (GAS_EMISSIONS / eff) * 80.0
        assert math.isclose(out[f"Gas_SRMC_{eff}"].iloc[0], expected, rel_tol=1e-9)

    def test_coal_srmc_uses_usd_to_local_and_api2_conversion(
        self, forward_curve_df
    ):
        eff = 0.4
        out = calculator.calculate_srmc(
            forward_curve_df.copy(), [0.5], [eff], [0.34], 1.5
        )
        coal_local_mwh = 110.0 * 0.96 / API2_TO_MWH
        expected = coal_local_mwh / eff + (COAL_EMISSIONS / eff) * 80.0
        assert math.isclose(out[f"Coal_SRMC_{eff}"].iloc[0], expected, rel_tol=1e-9)

    def test_lignite_srmc_uses_lignite_fuel_cost(self, forward_curve_df):
        eff = 0.34
        fuel_cost = 1.5
        out = calculator.calculate_srmc(
            forward_curve_df.copy(), [0.5], [0.4], [eff], fuel_cost
        )
        expected = fuel_cost / eff + (LIG_EMISSION_FACTOR / eff) * 80.0
        assert math.isclose(
            out[f"Lignite_SRMC_{eff}"].iloc[0], expected, rel_tol=1e-9
        )

    def test_multiple_effs_emit_one_column_per_eff(self, forward_curve_df):
        out = calculator.calculate_srmc(
            forward_curve_df.copy(),
            gas_effs=[0.49, 0.52, 0.59],
            coal_effs=[0.36, 0.45],
            lignite_effs=[0.34, 0.40],
            lignite_fuel_cost=1.5,
        )
        expected_cols = {
            "Gas_SRMC_0.49",
            "Gas_SRMC_0.52",
            "Gas_SRMC_0.59",
            "Coal_SRMC_0.36",
            "Coal_SRMC_0.45",
            "Lignite_SRMC_0.34",
            "Lignite_SRMC_0.4",
        }
        assert expected_cols.issubset(out.columns)

    def test_missing_input_columns_skip_their_blocks(self):
        # Only Power+Carbon -> none of Gas/Coal/Lignite blocks should run.
        df = pd.DataFrame({"Power": [100.0], "Carbon": [80.0]})
        out = calculator.calculate_srmc(df, [0.5], [0.4], [0.34], 1.5)
        # Lignite block runs whenever Carbon is present (no Gas/Coal needed).
        assert "Lignite_SRMC_0.34" in out.columns
        # Gas/Coal blocks require their own input column.
        assert not any(c.startswith("Gas_SRMC_") for c in out.columns)
        assert not any(c.startswith("Coal_SRMC_") for c in out.columns)


# -----------------------------------------------------------------------------
# compute_historical_srmc
# -----------------------------------------------------------------------------
class TestComputeHistoricalSrmc:
    @pytest.fixture()
    def hist_df(self) -> pd.DataFrame:
        # Two rows, picked so min/max of effs produce a non-zero band width.
        return pd.DataFrame(
            {
                "Gas": [40.0, 50.0],
                "Coal": [110.0, 120.0],
                "Carbon": [80.0, 90.0],
            },
            index=pd.to_datetime(["2026-03-01", "2026-03-02"]),
        )

    def test_empty_input_returns_input_unchanged(self):
        empty = pd.DataFrame()
        out = compute_historical_srmc(empty, [0.5], [0.4], [0.34])
        assert out is empty

    def test_uk_mode_uses_137_fx(self, hist_df):
        out = compute_historical_srmc(
            hist_df.copy(), [0.5], [0.4], [0.34], is_uk_mode=True
        )
        assert (out["USD_TO_LOCAL"] == 1.37).all()

    def test_non_uk_mode_uses_096_fx(self, hist_df):
        out = compute_historical_srmc(
            hist_df.copy(), [0.5], [0.4], [0.34], is_uk_mode=False
        )
        assert (out["USD_TO_LOCAL"] == 0.96).all()

    def test_gas_band_orders_min_below_max(self, hist_df):
        out = compute_historical_srmc(
            hist_df.copy(), [0.49, 0.52, 0.59], [0.4], [0.34]
        )
        assert (out["Gas_SRMC_Min"] <= out["Gas_SRMC_Max"]).all()

    def test_coal_band_orders_min_below_max(self, hist_df):
        out = compute_historical_srmc(
            hist_df.copy(), [0.5], [0.36, 0.45], [0.34]
        )
        assert (out["Coal_SRMC_Min"] <= out["Coal_SRMC_Max"]).all()

    def test_lignite_band_orders_min_below_max(self, hist_df):
        out = compute_historical_srmc(
            hist_df.copy(), [0.5], [0.4], [0.34, 0.40]
        )
        assert (out["Lig_SRMC_Min"] <= out["Lig_SRMC_Max"]).all()

    def test_gas_max_matches_min_eff_formula(self, hist_df):
        # Gas_SRMC_Max uses min(eff) (smaller eff -> larger marginal cost).
        out = compute_historical_srmc(
            hist_df.copy(), [0.49, 0.59], [0.4], [0.34]
        )
        eff = 0.49
        expected_first = 40.0 / eff + (GAS_EMISSIONS / eff) * 80.0
        assert math.isclose(out["Gas_SRMC_Max"].iloc[0], expected_first, rel_tol=1e-9)


# -----------------------------------------------------------------------------
# Singleton sanity
# -----------------------------------------------------------------------------
def test_module_calculator_singleton_is_an_instance():
    assert isinstance(calculator, FuelSwitchingCalculator)
