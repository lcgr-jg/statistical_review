"""
Tests for ``core.french_nuclear.unit_eq_delta`` (per-unit EQ availability delta)
and the delta heatmap builder.

These exercise the *pure* pieces — catalogue lookup, curve-name parsing, and the
``latest − reference`` alignment — without touching the Energy Quantified API.
"""
from __future__ import annotations

import pandas as pd
import pytest

from core.french_nuclear import unit_eq_delta as u
from core.french_nuclear.charts import build_unit_delta_heatmap


# -----------------------------------------------------------------------------
# Catalogue + curve-name helpers
# -----------------------------------------------------------------------------
def test_default_catalogue_has_fr_nuclear():
    assert "FR" in u.list_countries()
    assert "nuclear" in u.list_fuels("FR")
    assert u.list_fuels("FR")[0] == "nuclear"  # nuclear floated to front
    assert u.list_countries()[0] == "FR"       # default area floated to front


def test_fleet_curve_and_tech_suffix():
    fleet = u.fleet_curve_name("FR", "nuclear")
    assert fleet == "FR Nuclear Capacity Available MW REMIT"
    # The suffix is what per-unit discovery matches on.
    assert u._tech_suffix("FR", fleet) == "Nuclear Capacity Available MW REMIT"


def test_fleet_curve_unknown_combo_returns_none():
    assert u.fleet_curve_name("ZZ", "unobtanium") is None


def test_unit_label_parse_matches_eq_naming():
    """Mirror the parse in discover_unit_curves on a known EQ name shape."""
    area, suffix = "FR", "Nuclear Capacity Available MW REMIT"
    prefix = f"{area} @"
    name = "FR @Golfech-1 Nuclear Capacity Available MW REMIT"
    assert name.startswith(prefix) and name.endswith(suffix)
    label = name[len(prefix):-len(suffix)].strip()
    assert label == "Golfech-1"


# -----------------------------------------------------------------------------
# compute_unit_delta
# -----------------------------------------------------------------------------
@pytest.fixture()
def snapshots():
    idx = pd.to_datetime(["2026-06-25", "2026-06-26", "2026-06-27"])
    latest = pd.DataFrame(
        {"Golfech-1": [900, 900, 800], "Cattenom-2": [1300, 1200, 1200]}, index=idx
    )
    reference = pd.DataFrame(
        {"Golfech-1": [900, 850, 850], "Cattenom-2": [1300, 1300, 1100]}, index=idx
    )
    return latest, reference


def test_compute_unit_delta_values(snapshots):
    latest, reference = snapshots
    delta = u.compute_unit_delta(latest, reference)
    assert delta.shape == (3, 2)
    assert delta.loc["2026-06-26", "Golfech-1"] == 50
    assert delta.loc["2026-06-27", "Golfech-1"] == -50
    assert delta.loc["2026-06-26", "Cattenom-2"] == -100
    assert delta.loc["2026-06-25", "Cattenom-2"] == 0


def test_compute_unit_delta_aligns_on_common_grid(snapshots):
    latest, reference = snapshots
    # Reference is missing a unit and a date; delta restricts to the overlap.
    reference = reference.drop(columns=["Cattenom-2"]).iloc[:2]
    delta = u.compute_unit_delta(latest, reference)
    assert list(delta.columns) == ["Golfech-1"]
    assert len(delta) == 2


def test_compute_unit_delta_empty_inputs(snapshots):
    latest, reference = snapshots
    assert u.compute_unit_delta(pd.DataFrame(), reference).empty
    assert u.compute_unit_delta(latest, pd.DataFrame()).empty


def test_compute_unit_delta_no_overlap_returns_empty():
    a = pd.DataFrame({"X": [1.0]}, index=pd.to_datetime(["2026-01-01"]))
    b = pd.DataFrame({"Y": [1.0]}, index=pd.to_datetime(["2026-02-01"]))
    assert u.compute_unit_delta(a, b).empty


# -----------------------------------------------------------------------------
# Heatmap builder
# -----------------------------------------------------------------------------
def test_build_unit_delta_heatmap_diverging(snapshots):
    latest, reference = snapshots
    delta = u.compute_unit_delta(latest, reference)
    fig = build_unit_delta_heatmap(
        delta,
        latest_label="25 Jun 2026 12:00",
        reference_label="24 Jun 2026 12:00",
        area="FR",
        fuel="nuclear",
    )
    assert len(fig.data) == 1
    hm = fig.data[0]
    assert type(hm).__name__ == "Heatmap"
    assert hm.zmid == 0
    assert hm.zmin == -hm.zmax  # symmetric scale
    # y-axis are units, x-axis are delivery dates
    assert set(hm.y) == {"Golfech-1", "Cattenom-2"}


def test_build_unit_delta_heatmap_empty_is_safe():
    fig = build_unit_delta_heatmap(
        pd.DataFrame(), latest_label="x", reference_label="y", area="FR", fuel="nuclear"
    )
    # Empty -> placeholder figure, no heatmap trace.
    assert all(type(t).__name__ != "Heatmap" for t in fig.data)
