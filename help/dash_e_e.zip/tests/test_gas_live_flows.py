"""Tests for Live Flows tables and CE flow dataset wiring."""
from __future__ import annotations

import pandas as pd

from core.gas_data_ce.constants import CE_DATASETS, FLOWS_DATASET_KEY
from core.gas_live_flows.constants import FLOW_COLUMNS, REGAS_COUNTRIES
from core.gas_live_flows.data import monthly_history, us_liq_ath
from core.gas_live_flows.table import (
    build_flows_table,
    build_regas_table,
    slice_last_n_days,
)


def test_gas_flows_key_dataset_matches_morning_flows_assets():
    cfg = CE_DATASETS[FLOWS_DATASET_KEY]
    assert cfg["variables"] == ["netFlow"]
    assert cfg["add_total"] is False
    assert cfg["assets"] == {
        "UA Total Imports": 1969,
        "TAP": 2782,
        "Mazara": 1792,
        "Turkstream": 2678,
        "Velke": 1871,
        "UKCS": 466,
        "NL Prodn": 475,
        "NCS": 732,
    }
    assert FLOW_COLUMNS == tuple(cfg["assets"])


def test_lng_country_covers_regas_assets():
    lng_assets = CE_DATASETS["lng_country"]["assets"]
    for country in REGAS_COUNTRIES:
        assert country in lng_assets
    # Same IDs as morning_flows (metadata-correct labels, not positional).
    assert lng_assets["BE"] == 676
    assert lng_assets["DE"] == 687
    assert lng_assets["FR"] == 457
    assert lng_assets["GB"] == 467
    assert lng_assets["IT"] == 1779
    assert lng_assets["NL"] == 476


def test_slice_last_n_days_uses_calendar_window():
    idx = pd.date_range("2026-09-01", periods=20, freq="D")
    df = pd.DataFrame({"BE": range(20)}, index=idx)
    sliced = slice_last_n_days(df, n_days=14)
    assert len(sliced) == 14
    assert sliced.index.min() == pd.Timestamp("2026-09-07")
    assert sliced.index.max() == pd.Timestamp("2026-09-20")


def test_us_liq_ath_is_column_min_excluding_latest_day():
    idx = pd.date_range("2026-09-01", periods=5, freq="D")
    df = pd.DataFrame(
        {
            "Calcasieu": [-1.0, -3.0, -2.0, -9.0, -4.0],
            "Total": [-10.0, -12.0, -11.0, -20.0, -8.0],
        },
        index=idx,
    )
    ath = us_liq_ath(df)
    assert ath is not None
    assert float(ath["Calcasieu"]) == -9.0
    assert float(ath["Total"]) == -20.0


def test_monthly_history_marks_mtd_and_mom():
    idx = pd.date_range("2026-07-01", "2026-09-16", freq="D")
    values = []
    for dt in idx:
        if dt.month == 7:
            values.append(10.0)
        elif dt.month == 8:
            values.append(20.0)
        else:
            values.append(30.0)
    series = pd.Series(values, index=idx)
    hist = monthly_history(series, n_months=6)
    assert list(hist["label"])[-3:] == ["Jul-2026", "Aug-2026", "Sep-2026 MTD"]
    assert bool(hist.iloc[-1]["is_mtd"]) is True
    assert float(hist.iloc[-1]["value"]) == 30.0
    assert float(hist.iloc[-2]["value"]) == 20.0
    assert float(hist.iloc[-1]["mom"]) == 10.0
    assert float(hist.iloc[-2]["mom"]) == 10.0


def test_yoy_chart_daily_and_monthly_build():
    from core.gas_live_flows.charts import build_yoy_chart
    from core.gas_live_flows.constants import GRANULARITY_DAILY, GRANULARITY_MONTHLY

    idx = pd.date_range("2024-01-01", "2026-09-16", freq="D")
    series = pd.Series(range(len(idx)), index=idx, dtype=float)
    daily = build_yoy_chart(
        series,
        granularity=GRANULARITY_DAILY,
        ma_window=7,
        title="Regas: GB",
    )
    monthly = build_yoy_chart(series, granularity=GRANULARITY_MONTHLY)
    assert daily.data
    assert monthly.data
    assert daily.layout.title.text == "Regas: GB"


def test_regas_and_flows_tables_render():
    idx = pd.date_range("2026-09-01", periods=10, freq="D")
    regas = pd.DataFrame(
        {c: [10.0] * 10 for c in (*REGAS_COUNTRIES, "Total")},
        index=idx,
    )
    flows = pd.DataFrame(
        {c: [1.0] * 10 for c in FLOW_COLUMNS},
        index=idx,
    )
    us = pd.Series([8.5] * 10, index=idx, name="US")
    ca = pd.Series([1.2] * 10, index=idx, name="CA")
    regas_el = build_regas_table(regas, n_days=7)
    flows_el = build_flows_table(flows, us_liq=us, ca_liq=ca, n_days=7)
    assert regas_el is not None
    assert flows_el is not None
    assert "table" in str(regas_el).lower() or hasattr(regas_el, "children")
