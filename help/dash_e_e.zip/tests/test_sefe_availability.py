"""SEFE forward availability: Storage Sites curves capped by CE outages."""
from __future__ import annotations

import pandas as pd

from core.gas_storage_summary.constants import UNIT_MCM
from core.gas_storage_summary.sefe_availability import (
    available_rate,
    maintenance_spans,
    outage_frame_from_ce,
    rates_at_fill,
    render_availability,
    scale_curve_params,
)


def _rehden_outages() -> pd.DataFrame:
    rows = []
    for day in pd.date_range("2026-10-01", "2026-10-10", freq="D"):
        out = 25.39 if day <= pd.Timestamp("2026-10-09") else 12.69
        rows.append(
            {
                "assetId": 617,
                "Variable": "injection",
                "Date": day.strftime("%d-%b-%Y"),
                "Out.Total": out,
                "Restr.Cap": 25.39 - out,
            }
        )
        rows.append(
            {
                "assetId": 617,
                "Variable": "withdrawal",
                "Date": day.strftime("%d-%b-%Y"),
                "Out.Total": 0.0,
                "Restr.Cap": 39.06,
            }
        )
    return outage_frame_from_ce(pd.DataFrame(rows))


def test_available_rate_subtracts_maintenance_from_the_curve():
    assert round(available_rate(32.6, 25.4), 1) == 7.2
    assert round(available_rate(30.0, 12.69), 2) == 17.31
    assert available_rate(10.0, 25.39) == 0.0
    assert available_rate(10.0, 0.0) == 10.0
    assert available_rate(10.0, None) == 10.0
    assert available_rate(None, 25.4, 0.0) == 0.0
    assert available_rate(None, None) is None


def test_rehden_injection_maintenance_collapses_through_9_oct():
    frame = _rehden_outages()
    window = frame.loc["2026-10-01":"2026-10-10"]
    spans = maintenance_spans(window.index, window[("rehden", "inj_out")].tolist())
    assert len(spans) == 2
    assert spans[0]["start"] == pd.Timestamp("2026-10-01")
    assert spans[0]["end"] == pd.Timestamp("2026-10-09")
    assert round(spans[0]["value"], 1) == 25.4
    assert spans[1]["start"] == pd.Timestamp("2026-10-10")
    assert round(spans[1]["value"], 1) == 12.7


def test_scaled_curve_uses_storage_sites_power_law():
    params = scale_curve_params(
        pd.Series(
            {
                "p_inj": 0.0,
                "q_wdr": 1.0,
                "max_inj": 20.0,
                "max_wdr": 40.0,
                "max_inj_cap": 18.0,
                "max_wdr_cap": 30.0,
            }
        ),
        0.5,
    )
    assert params["p_inj"] == 0.0
    assert params["max_inj"] == 10.0
    assert params["max_inj_cap"] == 9.0
    # fill 0 → injection at the cap, withdrawal at 0
    inj, wdr = rates_at_fill(params, 0.0)
    assert inj == 9.0
    assert wdr == 0.0


def test_table_shows_rehden_maintenance_subtracted_from_the_curve():
    curves = {
        "jemgum": {"label": "Jemgum", "inj": 10.0, "wdr": 8.0, "fill_pct": 80.0, "scaled": True},
        "rehden": {"label": "Rehden", "inj": 30.0, "wdr": 12.0, "fill_pct": 12.6, "scaled": False},
        "vsp_nord": {"label": "VSP Nord", "inj": 6.0, "wdr": 1.5, "fill_pct": 83.0, "scaled": False},
        "haidach": {"label": "Haidach", "inj": 11.0, "wdr": 9.0, "fill_pct": 68.0, "scaled": False},
    }
    node = render_availability(
        curves,
        _rehden_outages(),
        unit=UNIT_MCM,
        as_of=pd.Timestamp("2026-10-01"),
        n_days=10,
    )
    text = _plain(node)
    titles = _titles(node)
    assert "Rehden injection: 25.4 mcm/d from 1 to 9 Oct 2026." not in text
    assert "maint 25.4" not in text
    assert "Yellow cell: maintenance or a constraint that day." in text
    note = "Each day is the sites inj/wdr curve at the current fill"
    assert note in text
    assert text.index("Yellow cell:") < text.index(note)
    assert any(
        "Available: 4.6 mcm/d\nCurve at latest fill: 30.0 mcm/d\nMaintenance: 25.4 mcm/d\nAvailable = curve − maintenance"
        == title
        for title in titles
    )


def _titles(node) -> list[str]:
    found: list[str] = []

    def walk(item):
        if item is None or isinstance(item, str):
            return
        if isinstance(item, (list, tuple)):
            for child in item:
                walk(child)
            return
        title = getattr(item, "title", None)
        if isinstance(title, str):
            found.append(title)
        children = getattr(item, "children", None)
        if children is not None:
            walk(children)

    walk(node)
    return found


def _plain(node) -> str:
    parts: list[str] = []

    def walk(item):
        if item is None:
            return
        if isinstance(item, str):
            parts.append(item)
            return
        if isinstance(item, (list, tuple)):
            for child in item:
                walk(child)
            return
        children = getattr(item, "children", None)
        if children is not None:
            walk(children)

    walk(node)
    return "\n".join(parts)
