"""Tests for the Price GNN tradeable-contract aggregation layer."""
from datetime import date

import numpy as np
import pandas as pd
import pytest

from portal_pages.price_gnn.contracts import (
    ContractWindow,
    aggregate_history,
    aggregate_windows,
    build_contract_windows,
    enumerate_history_windows,
    expected_hours,
    expected_peak_hours,
    summarise_members,
)


def _hourly_fan(start: str, end: str, members=("e00", "e01"), price=50.0):
    """Naive-UTC hourly frame shaped like fan.parquet, one zone."""
    idx = pd.date_range(start, end, freq="h", inclusive="left")
    frames = []
    for m in members:
        frames.append(pd.DataFrame({
            "target_date": idx,
            "region": "DE",
            "ensemble_member": m,
            "price_eur_mwh": price,
        }))
    return pd.concat(frames, ignore_index=True)


# ---------------------------------------------------------------------------
# Window builder
# ---------------------------------------------------------------------------

class TestBuildContractWindows:
    def test_midweek_issue_produces_da_bow_weekend_and_weeks(self):
        # Wednesday 2026-09-09: DA=Thu, BOW=Fri, weekend Sat 12th, Wk+1 Mon 14th.
        ws = build_contract_windows(date(2026, 9, 9))
        by_label = {w.label: w for w in ws}
        da = [w for w in ws if w.label.startswith("DA")]
        assert len(da) == 1 and da[0].start == date(2026, 9, 10)
        assert da[0].has_peak
        assert any(w.kind == "weekend" and w.start == date(2026, 9, 12) for w in ws)
        weeks = [w for w in ws if w.kind == "week"]
        assert [w.start for w in weeks] == [
            date(2026, 9, 14), date(2026, 9, 21), date(2026, 9, 28)]
        assert all(w.days == 7 for w in weeks)
        assert "M+1 (Oct 2026)" not in by_label or by_label[
            "M+1 (Oct 2026)"].start == date(2026, 10, 1)

    def test_friday_issue_da_is_saturday_base_only(self):
        ws = build_contract_windows(date(2026, 9, 11))  # Friday
        da = [w for w in ws if w.label.startswith("DA")][0]
        assert da.start == date(2026, 9, 12)
        assert not da.has_peak  # Saturday delivery trades base only

    def test_weekend_window_never_has_peak(self):
        for d in range(1, 8):
            ws = build_contract_windows(date(2026, 9, d))
            for w in ws:
                if w.kind == "weekend":
                    assert not w.has_peak

    def test_horizon_bounds_drop_unreachable_and_partial_month(self):
        # 14-day ST horizon from a mid-month Wednesday: M+1 must not appear,
        # and no window may start past the horizon.
        as_of = date(2026, 9, 9)
        horizon_end = date(2026, 9, 23)
        ws = build_contract_windows(as_of, horizon_end=horizon_end)
        assert all(w.kind != "month" for w in ws)
        assert all(w.start <= horizon_end for w in ws)
        # Wk+2 starts 21 Sep <= horizon but ends past it: kept, so the
        # coverage gate (not the builder) decides how it renders.
        assert any(w.start == date(2026, 9, 21) for w in ws)

    def test_month_included_when_fully_covered(self):
        # 46-day MT horizon from late September covers all of October.
        ws = build_contract_windows(date(2026, 9, 25), horizon_end=date(2026, 11, 9))
        months = [w for w in ws if w.kind == "month"]
        assert len(months) == 1
        assert months[0].start == date(2026, 10, 1)
        assert months[0].end == date(2026, 11, 1)

    def test_no_quarters_or_calendars_ever(self):
        ws = build_contract_windows(date(2026, 9, 9), horizon_end=date(2027, 12, 31))
        assert {w.kind for w in ws} <= {"day", "weekend", "week", "month"}


# ---------------------------------------------------------------------------
# Calendar / DST
# ---------------------------------------------------------------------------

class TestExpectedHours:
    def test_normal_day_and_week(self):
        d = ContractWindow("d", "day", date(2026, 9, 10), date(2026, 9, 11), True)
        w = ContractWindow("w", "week", date(2026, 9, 14), date(2026, 9, 21), True)
        assert expected_hours(d) == 24
        assert expected_hours(w) == 168
        assert expected_peak_hours(d) == 12
        assert expected_peak_hours(w) == 60  # 5 weekdays x 12

    def test_dst_spring_forward_day_has_23_hours(self):
        # Last Sunday of March 2026 = 29 March.
        d = ContractWindow("d", "day", date(2026, 3, 29), date(2026, 3, 30), False)
        assert expected_hours(d) == 23

    def test_dst_fall_back_day_has_25_hours(self):
        # Last Sunday of October 2026 = 25 October.
        d = ContractWindow("d", "day", date(2026, 10, 25), date(2026, 10, 26), False)
        assert expected_hours(d) == 25

    def test_dst_week_totals(self):
        wk = ContractWindow("w", "week", date(2026, 3, 23), date(2026, 3, 30), True)
        assert expected_hours(wk) == 167
        # Peak hours are Mon-Fri and unaffected by a Sunday clock change.
        assert expected_peak_hours(wk) == 60


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

class TestAggregateWindows:
    def test_flat_price_base_and_peak(self):
        # Full ISO week at 50 EUR flat; UTC-hourly. CEST = UTC+2 in September,
        # so cover a margin either side of the window.
        fan = _hourly_fan("2026-09-13 00:00", "2026-09-22 00:00")
        wk = ContractWindow("Wk 38", "week", date(2026, 9, 14), date(2026, 9, 21), True)
        out = aggregate_windows(fan, [wk])
        assert set(out["ensemble_member"]) == {"e00", "e01"}
        assert (out["price_eur_mwh_base"] == 50.0).all()
        assert (out["price_eur_mwh_peak"] == 50.0).all()
        assert (out["price_eur_mwh_coverage"] == 1.0).all()

    def test_peak_mean_uses_cet_clock_not_utc(self):
        # Price 100 during CET peak hours, 10 otherwise. If the mask were
        # applied on the UTC clock the peak mean would blend the two levels.
        fan = _hourly_fan("2026-09-09 00:00", "2026-09-12 00:00", members=("e00",))
        berlin = fan["target_date"].dt.tz_localize("UTC").dt.tz_convert("Europe/Berlin")
        is_peak = (berlin.dt.weekday < 5) & berlin.dt.hour.between(8, 19)
        fan["price_eur_mwh"] = np.where(is_peak, 100.0, 10.0)
        d = ContractWindow("DA", "day", date(2026, 9, 10), date(2026, 9, 11), True)
        out = aggregate_windows(fan, [d])
        assert out.loc[0, "price_eur_mwh_peak"] == 100.0
        assert out.loc[0, "price_eur_mwh_base"] == pytest.approx((12 * 100 + 12 * 10) / 24)

    def test_partial_coverage_prices_nan_but_reports_fraction(self):
        # Only 5 of 7 delivery days present: base must be NaN, not a mean of 5 days.
        fan = _hourly_fan("2026-09-13 00:00", "2026-09-19 00:00")
        wk = ContractWindow("Wk 38", "week", date(2026, 9, 14), date(2026, 9, 21), True)
        out = aggregate_windows(fan, [wk])
        assert out["price_eur_mwh_base"].isna().all()
        assert (out["price_eur_mwh_coverage"] < 1.0).all()
        assert (out["price_eur_mwh_coverage"] > 0.5).all()

    def test_member_with_nan_hours_prices_nan_without_hurting_others(self):
        fan = _hourly_fan("2026-09-09 12:00", "2026-09-12 12:00")
        knock = (fan["ensemble_member"] == "e01") & (
            fan["target_date"] == pd.Timestamp("2026-09-10 07:00"))
        fan.loc[knock, "price_eur_mwh"] = np.nan
        d = ContractWindow("DA", "day", date(2026, 9, 10), date(2026, 9, 11), True)
        out = aggregate_windows(fan, [d]).set_index("ensemble_member")
        assert out.loc["e00", "price_eur_mwh_base"] == 50.0
        assert np.isnan(out.loc["e01", "price_eur_mwh_base"])

    def test_weekend_window_has_no_peak_column_values(self):
        fan = _hourly_fan("2026-09-11 00:00", "2026-09-15 00:00")
        we = ContractWindow("Wknd", "weekend", date(2026, 9, 12), date(2026, 9, 14), False)
        out = aggregate_windows(fan, [we])
        assert "price_eur_mwh_peak" not in out.columns
        assert (out["price_eur_mwh_base"] == 50.0).all()

    def test_dst_day_full_coverage_needs_23_hours(self):
        # Spring-forward day: 23 Berlin hours == 23 UTC hours (22:00 Sat ->
        # 21:00 Sun UTC one day later). A frame with exactly those hours must
        # reach coverage 1.0.
        idx = pd.date_range("2026-03-28 23:00", "2026-03-29 22:00", freq="h")
        fan = pd.DataFrame({
            "target_date": idx, "region": "DE",
            "ensemble_member": "e00", "price_eur_mwh": 42.0,
        })
        d = ContractWindow("d", "day", date(2026, 3, 29), date(2026, 3, 30), False)
        out = aggregate_windows(fan, [d])
        assert out.loc[0, "price_eur_mwh_coverage"] == 1.0
        assert out.loc[0, "price_eur_mwh_base"] == 42.0

    def test_multiple_value_columns_for_backtest(self):
        fan = _hourly_fan("2026-09-09 12:00", "2026-09-12 12:00", members=("x",))
        fan = fan.rename(columns={"price_eur_mwh": "y_true"}).drop(
            columns="ensemble_member")
        fan["y_pred"] = 60.0
        d = ContractWindow("DA", "day", date(2026, 9, 10), date(2026, 9, 11), True)
        out = aggregate_windows(
            fan, [d], value_cols=("y_true", "y_pred"), group_cols=("region",))
        assert out.loc[0, "y_true_base"] == 50.0
        assert out.loc[0, "y_pred_base"] == 60.0
        assert out.loc[0, "y_pred_peak"] == 60.0


class TestSummariseMembers:
    def test_quantiles_and_partial_members_excluded(self):
        fan = _hourly_fan("2026-09-09 12:00", "2026-09-12 12:00",
                          members=[f"e{i:02d}" for i in range(10)])
        for i in range(10):
            m = fan["ensemble_member"] == f"e{i:02d}"
            fan.loc[m, "price_eur_mwh"] = 40.0 + i
        # e09 loses an hour -> excluded from the distribution entirely.
        knock = (fan["ensemble_member"] == "e09") & (
            fan["target_date"] == pd.Timestamp("2026-09-10 07:00"))
        fan = fan[~knock]
        d = ContractWindow("DA", "day", date(2026, 9, 10), date(2026, 9, 11), True)
        members = aggregate_windows(fan, [d])
        summary = summarise_members(members)
        base = summary[summary["shape"] == "Base"].iloc[0]
        assert base["n_members"] == 9
        assert base["mean"] == pytest.approx(np.mean([40 + i for i in range(9)]))
        assert base["p50"] == 44.0
        peak = summary[summary["shape"] == "Peak"].iloc[0]
        assert peak["n_members"] == 9


class TestAggregateHistory:
    def _history(self, start, end, seed=7):
        """Hourly two-zone backtest-like frame with noisy prices, naive UTC.

        Zones deliberately appear in NON-sorted order (fr before de): pandas
        groupbys with sort=False keep encounter order while the default sorts,
        and a real regression came from comparing the two without reindexing.
        """
        idx = pd.date_range(start, end, freq="h", inclusive="left")
        rng = np.random.default_rng(seed)
        frames = []
        for zone in ("fr", "de"):
            frames.append(pd.DataFrame({
                "timestamp": idx,
                "border": zone,
                "y_true": rng.normal(80, 20, idx.size),
                "y_pred": rng.normal(78, 18, idx.size),
            }))
        return pd.concat(frames, ignore_index=True)

    def test_matches_aggregate_windows_semantics(self):
        # Same data through the fast calendar path and the per-window path
        # must agree exactly -- covers a DST month (March 2026).
        hist = self._history("2026-02-25 00:00", "2026-04-05 00:00")
        fast = aggregate_history(hist)

        windows = enumerate_history_windows(date(2026, 3, 1), date(2026, 3, 31))
        slow = aggregate_windows(
            hist, windows, time_col="timestamp",
            value_cols=("y_true", "y_pred"), group_cols=("border",),
        )
        merged = slow.merge(
            fast, left_on=["border", "kind", "window_start"],
            right_on=["border", "kind", "window_start"],
            suffixes=("_slow", "_fast"), how="left",
        )
        assert len(merged) == len(slow) and not merged["y_true_base_fast"].isna().all()
        for col in ("y_true_base", "y_pred_base", "y_true_peak", "y_pred_peak"):
            s, f = merged[f"{col}_slow"], merged[f"{col}_fast"]
            both = s.notna() & f.notna()
            assert (s.isna() == f.isna()).all(), col
            assert np.allclose(s[both], f[both]), col

    def test_truncated_edges_fail_coverage(self):
        # History starting mid-week: the first partial week and month must be
        # NaN under the coverage gate, fully-covered days must not.
        hist = self._history("2026-03-04 12:00", "2026-03-12 00:00")
        out = aggregate_history(hist)
        weeks = out[out["kind"] == "week"]
        assert weeks["y_true_base"].isna().all()
        days = out[(out["kind"] == "day")
                   & (out["window_start"] == pd.Timestamp("2026-03-06"))]
        assert days["y_true_base"].notna().all()


class TestEnumerateHistoryWindows:
    def test_counts_over_two_full_months(self):
        ws = enumerate_history_windows(date(2026, 3, 1), date(2026, 4, 30))
        kinds = pd.Series([w.kind for w in ws]).value_counts()
        assert kinds["day"] == 61
        assert kinds["month"] == 2
        # Mondays whose full week fits inside the range.
        assert kinds["week"] == 8
        assert kinds["weekend"] == 8

    def test_saturday_day_windows_are_base_only(self):
        ws = enumerate_history_windows(date(2026, 9, 12), date(2026, 9, 13))
        days = [w for w in ws if w.kind == "day"]
        assert all(not w.has_peak for w in days)
