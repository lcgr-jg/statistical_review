"""
Smoke tests for deterministic fundamentals callback wiring.
"""

from dash import Dash


def _has_output(callback_keys, token):
    return any(token in key for key in callback_keys)


def test_fundamentals_callbacks_register_at_startup():
    from pages.fundamentals import initialize_fundamentals_callbacks

    app = Dash(__name__, suppress_callback_exceptions=True)
    initialize_fundamentals_callbacks(app)

    keys = list(app.callback_map.keys())
    assert _has_output(keys, "avail-charts-container.children")
    assert _has_output(keys, "gen-charts-container.children")
    assert _has_output(keys, "weather-forecast-output.children")
    assert _has_output(keys, "sci-regime-map.figure")


def test_fundamentals_callbacks_fail_fast_on_duplicate_registration():
    from pages.fundamentals import initialize_fundamentals_callbacks

    app = Dash(__name__, suppress_callback_exceptions=True)
    initialize_fundamentals_callbacks(app)

    # In local/dev mode this should fail fast instead of silently re-registering.
    try:
        initialize_fundamentals_callbacks(app)
    except RuntimeError:
        pass
    else:
        raise AssertionError("Expected RuntimeError on duplicate callback registration")
