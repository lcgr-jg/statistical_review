"""SEFE Tracker date default, units, and site totals."""
from __future__ import annotations

import datetime as dt

import pandas as pd
from dash import dcc

from core.gas_storage_summary.constants import (
    SEFE_SITES,
    UNIT_MCM,
    UNIT_TWH,
    default_sefe_cum_start,
)
from core.gas_storage_summary.layout import build_layout
from core.gas_storage_summary.sefe import (
    MCM_TO_TWH,
    TWH_TO_MCM,
    assemble_sefe_frame,
    build_sefe_tracker_body,
    cumulative_injection_by_site,
    cumulative_mcm,
    fill_snapshot,
)
from jain_commods.fundamental.units import get_conversion_factor, unit_conversion_table


def _site_frame(injection, withdrawal, stock, capacity, index) -> pd.DataFrame:
    inj = pd.Series(injection, index=index, dtype=float)
    wdr = pd.Series(withdrawal, index=index, dtype=float)
    return pd.DataFrame(
        {
            "netinjection": inj - wdr,
            "injection": inj,
            "withdrawal": wdr,
            "stock": stock,
            "stockcapacity": capacity,
        },
        index=index,
    )


def _sample() -> pd.DataFrame:
    index = pd.to_datetime(["2026-04-01", "2026-04-02", "2026-10-01", "2026-10-02"])
    raw = {
        425: _site_frame([1.0, 2.0, 3.0, 9.0], [0.0, 0.5, 0.0, 0.0], [10, 11.5, 20, 29], [100] * 4, index),
        448: _site_frame([0.0, 0.0, 4.0, 0.0], [1.0, 0.0, 0.0, 0.0], [40, 39, 43, 43], [400] * 4, index),
        1774: _site_frame([5.0, 0.0, 0.0, 1.0], [0.0, 0.0, 2.0, 0.0], [80, 80, 78, 79], [200] * 4, index),
        549: _site_frame([0.0, 1.0, 0.0, 2.0], [0.0, 0.0, 3.0, 0.0], [50, 51, 48, 50], [150] * 4, index),
    }
    return assemble_sefe_frame(raw)


def test_default_cum_start_is_29_sep_2026():
    assert default_sefe_cum_start() == dt.date(2026, 9, 29)
    assert default_sefe_cum_start(dt.date(2026, 10, 1)) == dt.date(2026, 9, 29)


def test_mcm_twh_uses_corelib_factor():
    assert MCM_TO_TWH == get_conversion_factor("mcm", "twh", unit_conversion_table)
    assert TWH_TO_MCM == get_conversion_factor("twh", "mcm", unit_conversion_table)
    assert MCM_TO_TWH * TWH_TO_MCM == 1
    assert TWH_TO_MCM == 90


def test_sefe_sites_are_the_four_named_facilities():
    assert [site.label for site in SEFE_SITES] == ["Jemgum", "Rehden", "VSP Nord", "Haidach"]
    assert [site.data_id for site in SEFE_SITES] == [425, 448, 1774, 549]
    assert 605 not in {site.data_id for site in SEFE_SITES}


def test_cumulative_and_fill_sum_the_four_sites():
    frame = _sample()
    inj, wdr = cumulative_mcm(frame, "2026-04-01", "2026-10-01")
    # Oct 2 is after the window. Injection = 1+2+3 + 0+0+4 + 5+0+0 + 0+1+0 = 16
    # Withdrawal = 0+0.5+0 + 1+0+0 + 0+0+2 + 0+0+3 = 6.5
    assert inj == 16
    assert wdr == 6.5

    rows = fill_snapshot(frame, "2026-10-01")
    by_label = {row["label"]: row for row in rows}
    assert by_label["Haidach"]["where"] == "Austria, DE grid"
    assert by_label["Haidach"]["stock_mcm"] == 48
    assert by_label["Haidach"]["capacity_mcm"] == 150
    assert by_label["Total"]["stock_mcm"] == 20 + 43 + 78 + 48
    assert by_label["Total"]["capacity_mcm"] == 100 + 400 + 200 + 150
    assert by_label["Total"]["fill_pct"] == (20 + 43 + 78 + 48) / 850 * 100


def test_cumulative_injection_by_site_matches_the_injection_total():
    frame = _sample()
    path = cumulative_injection_by_site(frame, "2026-04-01", "2026-10-01")
    # Oct 2 is outside the window. Site totals: Jemgum 6, Rehden 4, VSP Nord 5, Haidach 1.
    assert path.index.max() == pd.Timestamp("2026-10-01")
    assert path.loc["2026-10-01", "jemgum"] == 6
    assert path.loc["2026-10-01", "rehden"] == 4
    assert path.loc["2026-10-01", "vsp_nord"] == 5
    assert path.loc["2026-10-01", "haidach"] == 1
    assert path.iloc[-1].sum() == 16

    body = build_sefe_tracker_body(
        frame,
        unit=UNIT_MCM,
        start="2026-04-01",
        n_days=2,
        as_of=pd.Timestamp("2026-10-01"),
    )
    text = _plain(body)
    assert "Cumulative injection since 01 Apr 2026" in text
    graphs = _find_all(body, dcc.Graph)
    assert len(graphs) == 1
    fig = graphs[0].figure
    assert [trace.name for trace in fig.data] == ["Jemgum", "Rehden", "VSP Nord", "Haidach"]
    assert sum(float(trace.y[-1]) for trace in fig.data) == 16


def test_tracker_body_converts_stock_to_twh_and_keeps_flows_in_mcm():
    frame = _sample()
    mcm = _plain(build_sefe_tracker_body(
        frame,
        unit=UNIT_MCM,
        start="2026-04-01",
        n_days=2,
        as_of=pd.Timestamp("2026-10-01"),
    ))
    twh = _plain(build_sefe_tracker_body(
        frame,
        unit=UNIT_TWH,
        start="2026-04-01",
        n_days=2,
        as_of=pd.Timestamp("2026-10-01"),
    ))
    assert "16 mcm" in mcm
    assert "(0 TWh)" in mcm
    assert "7 mcm" in mcm
    assert "Stock bcm" in mcm
    assert "720 mcm" in mcm
    assert "(8 TWh)" in mcm
    assert "DE gov request on 29 Sep26 by 15 Dec26." in mcm
    assert "Haidach (AT) is connected to the DE grid." in mcm
    assert "Haidach" in mcm
    # Stock still follows the unit argument; cumulative cards stay mcm.
    assert f"{20 * MCM_TO_TWH:,.2f}" in twh
    assert "Stock TWh" in twh
    assert "720 mcm" in twh
    # Last two days only: 01-Oct and... 30 Sep is not in the index, so 01-Oct
    # if 30 Sep missing the table still includes 01-Oct. n_days=2 from Oct 1
    # is Sep 30–Oct 1; only Oct 1 is in the index.
    assert "02-Oct-2026" not in mcm
    assert "01-Oct-2026" in mcm


def test_sefe_frame_is_read_from_the_ce_cache():
    import core.gas_storage_summary.data as data
    import core.gas_storage_summary.sefe as sefe

    frame = _sample()
    sefe._FALLBACK_FRAME["frame"] = None
    calls = {"n": 0}
    orig_payload = data.get_cached_ce_payload
    orig_load = sefe._load_sefe_frame

    def payload():
        return {"sefe_frame": frame}

    def load():
        calls["n"] += 1
        raise AssertionError("SEFE history should come from the CE cache")

    data.get_cached_ce_payload = payload
    sefe._load_sefe_frame = load
    try:
        first = sefe.get_cached_sefe_frame(0)
        second = sefe.get_cached_sefe_frame(3)
    finally:
        data.get_cached_ce_payload = orig_payload
        sefe._load_sefe_frame = orig_load
        sefe._FALLBACK_FRAME["frame"] = None
    assert calls["n"] == 0
    assert first.equals(frame)
    assert second.equals(frame)
    assert first is not frame


def test_sefe_frame_loads_once_when_the_ce_cache_has_no_sefe_key():
    import core.gas_storage_summary.data as data
    import core.gas_storage_summary.sefe as sefe

    frame = _sample()
    sefe._FALLBACK_FRAME["frame"] = None
    calls = {"n": 0}
    orig_payload = data.get_cached_ce_payload
    orig_load = sefe._load_sefe_frame

    def payload():
        raise RuntimeError("cache empty")

    def load():
        calls["n"] += 1
        return frame

    data.get_cached_ce_payload = payload
    sefe._load_sefe_frame = load
    try:
        first = sefe.get_cached_sefe_frame(0)
        second = sefe.get_cached_sefe_frame(1)
    finally:
        data.get_cached_ce_payload = orig_payload
        sefe._load_sefe_frame = orig_load
        sefe._FALLBACK_FRAME["frame"] = None
    assert calls["n"] == 1
    assert first.equals(frame)
    assert second.equals(frame)


def test_ce_cache_still_saves_when_sefe_load_fails():
    import core.gas_data_ce.data as ce_data
    import core.gas_storage_summary.sefe as sefe

    orig = sefe.load_sefe_tracker_cache

    def boom():
        raise RuntimeError("db down")

    sefe.load_sefe_tracker_cache = boom
    try:
        assert ce_data._sefe_tracker_fields() == {}
    finally:
        sefe.load_sefe_tracker_cache = orig


def test_sefe_tracker_sits_above_daily_storage_action():
    layout = build_layout()
    text = _plain(layout)
    activity = text.index("Daily Storage Activity")
    sefe = text.index("SEFE Tracker")
    action = text.index("Daily Storage Action")
    assert activity < sefe < action
    assert "Forward (days)" in text
    assert "The German government has asked SEFE" not in text
    assert "in the same form as" not in text
    assert "gross totals from the date below" not in text
    slider = _find_id(layout, "gas-stor-sum-sefe-avail-days")
    assert slider.min == 7
    assert slider.max == 60
    assert slider.value == 14
    assert _find_id(layout, "gas-stor-sum-sefe-unit") is None


def _find_all(node, cls) -> list:
    found: list = []

    def walk(item):
        if item is None:
            return
        if isinstance(item, cls):
            found.append(item)
        if isinstance(item, (list, tuple)):
            for child in item:
                walk(child)
            return
        children = getattr(item, "children", None)
        if children is not None:
            walk(children)

    walk(node)
    return found


def _find_id(node, target: str):
    found = None

    def walk(item):
        nonlocal found
        if found is not None or item is None:
            return
        if isinstance(item, (list, tuple)):
            for child in item:
                walk(child)
            return
        if getattr(item, "id", None) == target:
            found = item
            return
        children = getattr(item, "children", None)
        if children is not None:
            walk(children)

    walk(node)
    return found


def _plain(node) -> str:
    parts: list[str] = []

    def walk(item):
        if item is None:
            return
        if isinstance(item, str):
            parts.append(item)
            return
        if isinstance(item, (list, tuple)):
            for child in item:
                walk(child)
            return
        children = getattr(item, "children", None)
        if children is not None:
            walk(children)

    walk(node)
    return "\n".join(parts)
