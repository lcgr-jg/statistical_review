"""Diversion history: AIS/Port moves in and out, window pairing, net volume."""
from __future__ import annotations

from datetime import date

import pandas as pd

from core.cargo_diversions.callbacks import _window_subtitle
from core.cargo_diversions.history import (
    apply_live_frame,
    diversion_events,
    live_only_today_message,
    summarise,
    window_pairs,
)
from core.cargo_diversions.render import build_daily_chart


def _frame(*rows: dict) -> pd.DataFrame:
    base = {
        "KplerVesselId": 1,
        "FromCountry": "Qatar",
        "ToCountry": "Belgium",
        "ToTerminal": "Zeebrugge",
        "Source": "AIS",
        "Volume(mcm)": 100.0,
    }
    records = []
    for row in rows:
        item = dict(base)
        item.update(row)
        records.append(item)
    return pd.DataFrame(records)


def test_window_summary_subtitle_names_the_dates_and_zone():
    text = _window_subtitle(date(2026, 9, 14), date(2026, 10, 13), "NWE")
    assert text == "14-Sep-2026 – 13-Oct-2026 · NWE"
    assert _window_subtitle(date(2026, 10, 1), date(2026, 10, 13), None) == (
        "01-Oct-2026 – 13-Oct-2026 · Custom"
    )


def test_ais_move_into_zone_is_a_diversion():
    prev = _frame({"Vessel": "AL KHARRARAH", "ToCountry": "Bangladesh",
                   "Source": "AIS"})
    curr = _frame({"Vessel": "AL KHARRARAH", "ToCountry": "Belgium",
                   "ToTerminal": "Zeebrugge", "Source": "AIS",
                   "FromCountry": "Qatar", "Volume(mcm)": 98.0})
    events = diversion_events(
        curr, prev, date(2026, 10, 9), date(2026, 10, 8), ["Belgium"])
    assert len(events) == 1
    assert events[0]["direction"] == "in"
    assert events[0]["load_country"] == "Qatar"
    assert events[0]["volume_mcm"] == 98.0
    assert events[0]["prev_source"] == "AIS"


def test_ais_move_out_of_zone_is_a_diversion_when_source_stays_ais():
    prev = _frame({"Vessel": "SHIP", "ToCountry": "Belgium", "Source": "AIS",
                   "Volume(mcm)": 80.0})
    curr = _frame({"Vessel": "SHIP", "ToCountry": "Bangladesh", "Source": "AIS",
                   "FromCountry": "United States", "Volume(mcm)": 80.0})
    events = diversion_events(
        curr, prev, date(2026, 10, 7), date(2026, 10, 6), ["Belgium"])
    assert len(events) == 1
    assert events[0]["direction"] == "out"
    assert events[0]["load_country"] == "United States"


def test_model_move_is_not_a_diversion():
    prev = _frame({"Vessel": "SHIP", "ToCountry": "Bangladesh", "Source": "Model"})
    curr = _frame({"Vessel": "SHIP", "ToCountry": "Belgium", "Source": "Port"})
    assert diversion_events(
        curr, prev, date(2026, 10, 9), date(2026, 10, 8), ["Belgium"]) == []


def test_net_volume_is_in_minus_out():
    events = [
        {"direction": "in", "volume_mcm": 100.0, "load_country": "Qatar",
         "curr_date": "2026-10-09"},
        {"direction": "out", "volume_mcm": 40.0, "load_country": "Qatar",
         "curr_date": "2026-10-09"},
        {"direction": "in", "volume_mcm": 50.0, "load_country": "United States",
         "curr_date": "2026-10-08"},
    ]
    summary = summarise(events)
    assert summary["n_in"] == 2
    assert summary["n_out"] == 1
    assert summary["net_cargoes"] == 1
    assert summary["net_volume"] == 110.0
    assert summary["origin_in"]["Qatar"] == 100.0
    assert summary["origin_out"]["Qatar"] == 40.0


def test_window_pairs_bridge_a_missing_day():
    cached = [date(2026, 10, 1), date(2026, 10, 2), date(2026, 10, 4)]
    pairs, missing = window_pairs(cached, date(2026, 10, 4), window_days=4)
    assert pairs == [
        (date(2026, 10, 2), date(2026, 10, 1)),
        (date(2026, 10, 4), date(2026, 10, 2)),
    ]
    assert missing == [date(2026, 10, 3)]


def test_daily_chart_keeps_quiet_days_on_a_date_axis():
    daily = pd.DataFrame(
        {"volume_in": [10.0, 5.0], "volume_out": [0.0, 4.0]},
        index=pd.to_datetime(["2026-10-01", "2026-10-08"]),
    )
    fig = build_daily_chart(daily, "volume", start="2026-10-01", end="2026-10-10")
    assert fig.layout.xaxis.type == "date"
    assert pd.Timestamp(fig.layout.xaxis.range[0]) < pd.Timestamp("2026-10-01")
    assert pd.Timestamp(fig.layout.xaxis.range[1]) > pd.Timestamp("2026-10-10")
    xs = pd.to_datetime(list(fig.data[0].x))
    assert list(xs) == list(daily.index)
    assert fig.layout.xaxis.dtick == 24 * 60 * 60 * 1000


def test_daily_hover_names_each_vessel_once_under_the_date():
    daily = pd.DataFrame(
        {"volume_in": [98.0], "volume_out": [80.0]},
        index=pd.to_datetime(["2026-10-09"]),
    )
    events = [
        {"curr_date": "2026-10-09", "direction": "in", "vessel": "AL KHARRARAH"},
        {"curr_date": "2026-10-09", "direction": "out", "vessel": "NEW BRAVE"},
    ]
    fig = build_daily_chart(
        daily, "volume", start="2026-10-01", end="2026-10-09", events=events)
    assert fig.data[0].hovertemplate == "%{customdata[1]}<extra></extra>"
    assert fig.data[0].customdata[0][0] == "2026-10-09"
    assert fig.data[0].customdata[0][1] == "98 mcm (AL KHARRARAH)"
    assert fig.data[1].customdata[0][1] == "80 mcm (NEW BRAVE)"


def test_live_frame_replaces_the_end_date_and_keeps_the_previous_day():
    end = date(2026, 10, 9)
    prev = date(2026, 10, 8)
    cached = pd.DataFrame({"ToCountry": ["Belgium"]})
    live = pd.DataFrame({"ToCountry": ["Belgium", "Qatar"]})
    pairs, frames = apply_live_frame(
        [(end, prev)], {end: cached, prev: cached}, end, live)
    assert pairs == [(end, prev)]
    assert frames[end] is live
    assert frames[prev] is cached


def test_live_frame_adds_today_when_it_was_not_cached():
    end = date(2026, 10, 9)
    prev = date(2026, 10, 8)
    live = pd.DataFrame({"ToCountry": ["Belgium"]})
    pairs, frames = apply_live_frame([(prev, date(2026, 10, 7))], {prev: live}, end, live)
    assert pairs[-1] == (end, prev)
    assert end in frames


def test_live_warning_names_today_when_the_window_ends_earlier():
    message = live_only_today_message(date(2026, 10, 9))
    assert "09-Oct-2026 UTC" in message
    assert "06:00 UTC cache" in message


def test_window_excludes_current_dates_before_the_start():
    cached = [date(2026, 10, 1), date(2026, 10, 2), date(2026, 10, 4)]
    pairs, _missing = window_pairs(cached, date(2026, 10, 4), window_days=2)
    assert pairs == [(date(2026, 10, 4), date(2026, 10, 2))]
