"""Level-2 storage fallback for every country on the Storage Summary table."""
from __future__ import annotations

import pandas as pd

from core.gas_data_ce.partial_storage import (
    PARTIAL_CELL_BG,
    PARTIAL_STORAGE_NOTE,
    SITE_QUERY_PAD_DAYS,
    apply_partial_storage,
    coverage_tooltip,
    fetch_partial_storage_detail,
    fetch_partial_storage_injection,
    level2_storage_signs,
    recent_missing_days,
    sum_signed_site_frame,
)
from core.gas_storage_summary.table import build_daily_activity_table

ASSET_IDS = {"AT": 1768, "DE": 688}


def _catalog():
    assets = pd.DataFrame(
        {
            "assetId": [688, 1768, 551, 552, 10, 999],
            "name": ["DE, Storage", "AT, Storage", "Bierwang", "Rehden", "Haidach", "Nested"],
            "type": ["Storage"] * 6,
            "level": [1, 1, 2, 2, 2, 3],
        }
    )
    tree = pd.DataFrame(
        {
            "parent_id": [688, 688, 1768, 551],
            "child_id": [551, 552, 10, 999],
            "sign": [1, -1, 1, 1],
        }
    )
    return assets, tree


def _opdata():
    raw = pd.DataFrame(
        {
            "DateExcel": [1, 2, 3],
            "Date": ["27-Sep-2026", "28-Sep-2026", "29-Sep-2026"],
            111: [10.0, 5.0, 8.0],
            222: [1.0, None, 3.0],
            333: [2.0, 2.0, 4.0],
        }
    )
    meta = pd.DataFrame(
        {
            "seriesId": ["Name", "assetId"],
            111: ["Bierwang", 551],
            222: ["Rehden", 552],
            333: ["Haidach", 10],
        }
    )
    return raw, meta


class _FakeCE:
    def __init__(self):
        self.assets, self.tree = _catalog()
        self.raw, self.meta = _opdata()
        self.calls = []

    def eugasmeta(self, id_):
        self.calls.append(("meta", id_))
        if id_ == "assets":
            return self.assets
        if id_ == "assettree":
            return self.tree
        raise AssertionError(id_)

    def eugasopdata(self, **kwargs):
        self.calls.append(("opdata", kwargs))
        if kwargs.get("meta"):
            return self.meta
        return self.raw


def test_level2_signs_exclude_country_and_deeper_assets():
    assets, tree = _catalog()
    assert level2_storage_signs(assets, tree, 688) == {551: 1.0, 552: -1.0}
    assert level2_storage_signs(assets, tree, 1768) == {10: 1.0}


def test_signed_sum_skips_days_with_no_sites():
    raw, meta = _opdata()
    raw.loc[1, 111] = None
    total = sum_signed_site_frame(raw, meta, {551: 1.0, 552: -1.0})
    assert total.loc[pd.Timestamp("2026-09-27")] == 9.0
    assert pd.isna(total.loc[pd.Timestamp("2026-09-28")])
    assert total.loc[pd.Timestamp("2026-09-29")] == 5.0


def test_recent_missing_is_last_seven_days():
    idx = pd.to_datetime(["2026-09-22", "2026-09-23", "2026-09-29"])
    country = pd.Series([None, None, None], index=idx)
    missing = recent_missing_days(country, lookback_days=7)
    assert list(missing) == [pd.Timestamp("2026-09-23"), pd.Timestamp("2026-09-29")]


def test_fetch_skips_ce_when_country_totals_are_present():
    ce = _FakeCE()
    frame = pd.DataFrame(
        {"AT": [1.0, 2.0], "DE": [1.0, 2.0]},
        index=pd.to_datetime(["2026-09-28", "2026-09-29"]),
    )
    out = fetch_partial_storage_injection(ce, frame, asset_ids=ASSET_IDS)
    assert out.empty
    assert ce.calls == []


def test_fetch_sums_each_country_with_a_recent_gap():
    ce = _FakeCE()
    frame = pd.DataFrame(
        {
            "AT": [None, 1.0, None],
            "DE": [None, 12.0, None],
        },
        index=pd.to_datetime(["2026-08-01", "2026-09-28", "2026-09-29"]),
    )
    out = fetch_partial_storage_injection(ce, frame, asset_ids=ASSET_IDS, lookback_days=7)
    assert list(out.index) == [pd.Timestamp("2026-09-29")]
    assert out.loc[pd.Timestamp("2026-09-29"), "AT"] == 4.0
    assert out.loc[pd.Timestamp("2026-09-29"), "DE"] == 5.0
    opdata_calls = [c for c in ce.calls if c[0] == "opdata" and not c[1].get("meta")]
    assert opdata_calls[0][1]["assets"] == "10,551,552"
    assert opdata_calls[0][1]["nd"] == 7 + SITE_QUERY_PAD_DAYS
    assert "688" not in opdata_calls[0][1]["assets"]
    assert "1768" not in opdata_calls[0][1]["assets"]


def test_coverage_names_sites_missing_on_a_partial_day():
    ce = _FakeCE()
    ce.raw.loc[2, 222] = None
    frame = pd.DataFrame(
        {"DE": [12.0, None]},
        index=pd.to_datetime(["2026-09-28", "2026-09-29"]),
    )
    detail = fetch_partial_storage_detail(ce, frame, asset_ids={"DE": 688}, lookback_days=7)
    assert detail.values.loc[pd.Timestamp("2026-09-29"), "DE"] == 8.0
    row = detail.coverage.loc[(pd.Timestamp("2026-09-29"), "DE")]
    assert int(row["n_sites"]) == 2
    assert row["missing_sites"] == ("Rehden",)
    assert coverage_tooltip(row["n_sites"], row["missing_sites"]) == (
        "1 of 2 sites is missing data\nRehden"
    )


def test_apply_does_not_replace_published_country_totals():
    frame = pd.DataFrame(
        {"AT": [None, 3.0], "DE": [4.0, None]},
        index=pd.to_datetime(["2026-09-28", "2026-09-29"]),
    )
    partial = pd.DataFrame(
        {"AT": [7.0, None], "DE": [99.0, 5.0]},
        index=pd.to_datetime(["2026-09-28", "2026-09-29"]),
    )
    mask = apply_partial_storage(frame, partial)
    assert frame["AT"].tolist() == [7.0, 3.0]
    assert frame["DE"].tolist() == [4.0, 5.0]
    assert bool(mask.loc[pd.Timestamp("2026-09-28"), "AT"])
    assert not bool(mask.loc[pd.Timestamp("2026-09-28"), "DE"])
    assert bool(mask.loc[pd.Timestamp("2026-09-29"), "DE"])
    assert not bool(mask.loc[pd.Timestamp("2026-09-29"), "AT"])


def _walk_text(node) -> str:
    chunks = []
    if isinstance(node, str):
        return node
    children = getattr(node, "children", None)
    if isinstance(children, str):
        chunks.append(children)
    elif isinstance(children, (list, tuple)):
        chunks.extend(_walk_text(child) for child in children)
    return "".join(chunks)


def _titled_cells(node) -> list[tuple[str, str]]:
    found = []
    title = getattr(node, "title", None)
    children = getattr(node, "children", None)
    if title and isinstance(children, str):
        found.append((children, title))
    if isinstance(children, (list, tuple)):
        for child in children:
            found.extend(_titled_cells(child))
    return found


def _amber_labels(node) -> list[str]:
    labels = []
    style = getattr(node, "style", None)
    if isinstance(style, dict) and style.get("backgroundColor") == PARTIAL_CELL_BG:
        children = getattr(node, "children", None)
        if isinstance(children, str):
            labels.append(children)
    children = getattr(node, "children", None)
    if isinstance(children, (list, tuple)):
        for child in children:
            labels.extend(_amber_labels(child))
    return labels


def test_activity_table_highlights_partial_countries_and_total():
    idx = pd.to_datetime(["2026-09-28", "2026-09-29"])
    df = pd.DataFrame(
        {
            "AT": [1.0, None],
            "BE": [1.0, 2.0],
            "DE": [10.0, None],
            "FR": [1.0, 2.0],
            "GB": [1.0, 2.0],
            "IT": [1.0, 2.0],
            "NL": [1.0, 2.0],
        },
        index=idx,
    )
    partial = pd.DataFrame(
        {"AT": [3.2], "DE": [20.4]},
        index=[pd.Timestamp("2026-09-29")],
    )
    day = pd.Timestamp("2026-09-29")
    coverage = pd.DataFrame(
        {
            "n_sites": [8, 40],
            "missing_sites": [("Haidach",), ("Bierwang", "Rehden")],
        },
        index=pd.MultiIndex.from_tuples([(day, "AT"), (day, "DE")], names=["date", "country"]),
    )
    table = build_daily_activity_table(
        df,
        to_date=day,
        n_days=2,
        countries=["AT", "DE"],
        partial=partial,
        coverage=coverage,
    )
    assert PARTIAL_STORAGE_NOTE in _walk_text(table)
    assert "Hover an amber cell" in _walk_text(table)
    # 3.2 → 3, 20.4 → 20, Total 23.6 → 24.
    assert _amber_labels(table) == ["3", "20", "24"]
    titles = dict(_titled_cells(table))
    assert titles["20"] == "2 of 40 sites are missing data\nBierwang\nRehden"
    assert "AT" in titles["24"] and "DE" in titles["24"]
    assert pd.isna(df.loc[pd.Timestamp("2026-09-29"), "DE"])
    assert pd.isna(df.loc[pd.Timestamp("2026-09-29"), "AT"])
