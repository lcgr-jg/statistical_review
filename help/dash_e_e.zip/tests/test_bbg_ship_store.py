"""Tests for the Bloomberg hourly ship-snapshot archive."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
import pytest

from core.lng_data_bbg_ships import store
from core.lng_data_bbg_ships.store import (
    extract_position_rows,
    get_position_history,
    persist_hourly_snapshot,
    reset_store_state,
)


def _ships(imo: int = 9373745, lat: float = 25.9, lon: float = 51.6):
    return pd.DataFrame([{
        "imo": imo,
        "vessel_name": "Al Hamla",
        "latitude": lat,
        "longitude": lon,
        "heading": 180,
        "last_seen": pd.Timestamp("2026-09-03T10:40:00Z"),
        "reported_speed_knots": 12.5,
        "cargo_status": "Laden",
        "normalized_destination": "ZEEBRUGGE",
    }])


class _FakeS3:
    """Minimal in-memory stand-in for the boto3 calls the store makes."""

    def __init__(self):
        self.objects: dict[str, bytes] = {}

    def put_object(self, Bucket, Key, Body):
        self.objects[Key] = Body

    def get_object(self, Bucket, Key):
        from io import BytesIO
        return {"Body": BytesIO(self.objects[Key])}

    def head_object(self, Bucket, Key):
        if Key not in self.objects:
            raise KeyError(Key)

    def get_paginator(self, name):
        objects = self.objects

        class _Paginator:
            def paginate(self, Bucket, Prefix):
                yield {"Contents": [{"Key": k} for k in objects
                                    if k.startswith(Prefix)]}
        return _Paginator()


@pytest.fixture(autouse=True)
def fake_s3(monkeypatch):
    fake = _FakeS3()
    monkeypatch.setattr(store, "_get_s3", lambda: (fake, "test-bucket"))
    reset_store_state()
    yield fake
    reset_store_state()


def test_extract_position_rows_imo_join_key():
    rows = extract_position_rows(_ships(), datetime(2026, 9, 3, 11))
    assert list(rows["imo"]) == [9373745]
    assert float(rows.iloc[0]["latitude"]) == 25.9
    assert str(rows.iloc[0]["destination"]) == "ZEEBRUGGE"


def test_persist_and_track_query(fake_s3):
    pytest.importorskip("pyarrow")
    t0 = datetime(2026, 9, 3, 10)
    t1 = datetime(2026, 9, 3, 11)
    assert persist_hourly_snapshot(
        _ships(lat=25.9, lon=51.6), t0)
    assert not persist_hourly_snapshot(
        _ships(lat=25.9, lon=51.6), t0)
    assert persist_hourly_snapshot(
        _ships(lat=26.2, lon=52.1), t1)

    track = get_position_history(
        9373745, start=t0, end=t1)
    assert len(track) == 2
    assert list(track["latitude"].round(1)) == [25.9, 26.2]

    other = get_position_history(
        1, start=t0, end=t1)
    assert other.empty

    # Hourly snapshots + position history live on S3 only.
    assert any(k.endswith("ships_hourly/20260903_10.parquet") for k in fake_s3.objects)
    assert any(k.endswith("position_hist_v1.parquet") for k in fake_s3.objects)


def test_history_rebuilt_from_s3_after_restart(fake_s3):
    pytest.importorskip("pyarrow")
    t0 = datetime(2026, 9, 3, 10)
    assert persist_hourly_snapshot(_ships(), t0)
    reset_store_state()  # simulate a fresh process
    assert not persist_hourly_snapshot(_ships(), t0)  # already archived
    track = get_position_history(9373745, start=t0, end=t0)
    assert len(track) == 1
