"""Tests for :mod:`portal_pages.fundamentals.met_run_store`.

The store reads issue-dated parquet written by the ``weather_forecasts``
pipeline. Schema v3 added nullable percentile columns because WeatherNext 3
publishes percentiles instead of a standard deviation, so the two things that
most need covering are that pre-v3 parquet still reads and that spread is
derived correctly for a model with no ``value_std``.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from portal_pages.fundamentals import met_run_store as store


CORE = ["model", "run_key", "init_time", "valid_time", "lead_hours",
        "country", "variable", "value_mean", "value_std"]


def _run_frame(model="AIFS-ENS", run_key="20260910_00", n=4,
               value_std=0.8, percentiles=None, base=8.0):
    """One country/variable series, optionally carrying percentiles."""
    init = pd.Timestamp(f"{run_key[:4]}-{run_key[4:6]}-{run_key[6:8]} "
                        f"{run_key[9:]}:00", tz="UTC")
    rows = []
    for i in range(n):
        row = {
            "model": model, "run_key": run_key, "init_time": init,
            "valid_time": init + pd.Timedelta(hours=i + 1),
            "lead_hours": i + 1, "country": "Germany", "variable": "cwg",
            "value_mean": base + i, "value_std": value_std,
        }
        if percentiles:
            row.update({k: base + i + v for k, v in percentiles.items()})
        rows.append(row)
    return pd.DataFrame(rows)


WN3_OFFSETS = {"p10": -2.0, "p25": -1.0, "p50": 0.0, "p75": 1.0, "p90": 2.0}


class TestRegistration:
    def test_weathernext3_is_selectable(self):
        assert "WeatherNext3" in store.MODELS

    def test_every_model_has_a_directory_and_a_label(self):
        """A missing entry silently reads from the wrong S3 prefix."""
        for model in store.MODELS:
            assert model in store.MODEL_DIR, model
            assert model in store.MODEL_LABEL, model

    def test_model_directories_are_unique(self):
        dirs = [store.MODEL_DIR[m] for m in store.MODELS]
        assert len(set(dirs)) == len(dirs)

    def test_weathernext3_reads_its_own_prefix(self):
        assert store.MODEL_DIR["WeatherNext3"] == "weathernext3"
        assert store._model_dir("WeatherNext3") == "weathernext3"

    def test_weathernext3_is_not_treated_as_deterministic(self):
        """It has 64 members; excluding it would hide its conviction heatmap."""
        assert "WeatherNext3" not in store.DETERMINISTIC_MODELS

    def test_weathernext3_outranks_weathernext2_in_display_order(self):
        """WeatherNext 2 predates IFS 50r1 and Google flags it as degraded."""
        assert store.MODELS.index("WeatherNext3") < store.MODELS.index("WeatherNext2")


class TestConform:
    def test_pre_v3_parquet_gains_nan_percentiles(self):
        df = store._conform(_run_frame()[CORE])
        for col in store.PERCENTILE_COLUMNS:
            assert col in df.columns
            assert df[col].isna().all()

    def test_existing_percentiles_are_left_alone(self):
        df = store._conform(_run_frame(percentiles=WN3_OFFSETS))
        assert df["p10"].iloc[0] == pytest.approx(6.0)
        assert df["p90"].iloc[0] == pytest.approx(10.0)

    def test_core_columns_survive(self):
        df = store._conform(_run_frame()[CORE])
        for col in CORE:
            assert col in df.columns


class TestSpreadOf:
    def test_published_standard_deviation_wins(self):
        df = _run_frame(value_std=0.8, percentiles=WN3_OFFSETS)
        assert store.spread_of(df).iloc[0] == pytest.approx(0.8)

    def test_falls_back_to_half_the_interdecile_range(self):
        """WeatherNext 3 publishes no std, so p10/p90 is all there is."""
        df = _run_frame(value_std=np.nan, percentiles=WN3_OFFSETS)
        assert store.spread_of(df).iloc[0] == pytest.approx(2.0)

    def test_is_not_scaled_by_a_normality_factor(self):
        """Half the interdecile range, not an implied sd: no 2.563 divisor."""
        df = _run_frame(value_std=np.nan, percentiles=WN3_OFFSETS)
        assert store.spread_of(df).iloc[0] != pytest.approx(4.0 / 2.563, abs=1e-3)

    def test_without_percentile_columns_it_is_just_the_std(self):
        df = _run_frame()[CORE]
        assert store.spread_of(df).iloc[0] == pytest.approx(0.8)

    def test_no_percentiles_and_no_std_is_nan(self):
        df = store._conform(_run_frame(value_std=np.nan)[CORE])
        assert store.spread_of(df).isna().all()

    def test_result_is_never_negative(self):
        df = _run_frame(value_std=np.nan, percentiles=WN3_OFFSETS)
        assert (store.spread_of(df).dropna() >= 0).all()


class TestComputeDelta:
    """compute_delta reads through load_run, so it is patched here.

    ``__wrapped__`` bypasses the result cache; without it the second call with
    the same model and run keys would replay the first test's frame.
    """

    def _delta(self, monkeypatch, model, latest, previous):
        # Both runs must agree on valid_time or the inner merge finds nothing.
        previous["valid_time"] = latest["valid_time"]
        frames = {latest["run_key"].iloc[0]: latest,
                  previous["run_key"].iloc[0]: previous}
        monkeypatch.setattr(store, "load_run", lambda m, key: frames.get(key))
        return store.compute_delta.__wrapped__(
            model, latest["run_key"].iloc[0], previous["run_key"].iloc[0])

    def test_z_score_uses_percentile_spread_when_std_is_missing(self, monkeypatch):
        delta = self._delta(
            monkeypatch, "WeatherNext3",
            _run_frame("WeatherNext3", "20260910_06", value_std=np.nan,
                       percentiles=WN3_OFFSETS, base=10.0),
            _run_frame("WeatherNext3", "20260910_00", value_std=np.nan,
                       percentiles=WN3_OFFSETS, base=8.0),
        )

        assert delta is not None
        assert delta["spread"].notna().all(), "percentile spread was not derived"
        # The run moved +2.0 everywhere against a spread of 2.0.
        assert delta["z_score"].iloc[0] == pytest.approx(1.0)

    def test_delta_frame_still_exposes_the_expected_columns(self, monkeypatch):
        delta = self._delta(
            monkeypatch, "AIFS-ENS",
            _run_frame(run_key="20260910_06", base=10.0),
            _run_frame(run_key="20260910_00", base=8.0),
        )

        assert list(delta.columns) == [
            "country", "variable", "valid_time", "lead_hours",
            "latest", "previous", "delta", "spread", "z_score",
        ]

    def test_a_model_with_a_std_is_unaffected_by_the_v3_change(self, monkeypatch):
        delta = self._delta(
            monkeypatch, "AIFS-ENS",
            _run_frame(run_key="20260910_06", value_std=0.5, base=10.0),
            _run_frame(run_key="20260910_00", value_std=0.5, base=8.0),
        )

        assert delta["spread"].iloc[0] == pytest.approx(0.5)
        assert delta["z_score"].iloc[0] == pytest.approx(4.0)


class TestRevisionHistory:
    def test_history_carries_spread_and_percentiles(self, monkeypatch):
        frames = {
            "20260910_00": _run_frame("WeatherNext3", "20260910_00",
                                      value_std=np.nan,
                                      percentiles=WN3_OFFSETS),
        }
        monkeypatch.setattr(store, "list_runs", lambda model: list(frames))
        monkeypatch.setattr(store, "load_run", lambda model, key: frames.get(key))

        hist = store.revision_history.__wrapped__(
            "WeatherNext3", "Germany", "cwg")

        assert hist is not None
        assert "spread" in hist.columns
        assert hist["spread"].iloc[0] == pytest.approx(2.0)
        for col in store.PERCENTILE_COLUMNS:
            assert col in hist.columns
