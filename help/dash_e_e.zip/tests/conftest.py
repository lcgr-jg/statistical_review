"""Shared pytest setup."""
import os
import tempfile

# Keep the global ``dashboard_cache`` off the developer's real cache/ folder:
# its disk maintenance deletes files, and tests shouldn't read stale entries.
# Must run before anything imports ``core.cache``.
os.environ.setdefault(
    "DASHBOARD_CACHE_DIR", tempfile.mkdtemp(prefix="dashboard_cache_test_")
)
