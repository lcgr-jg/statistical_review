"""Tests for :mod:`core.constants` env-var helpers."""
from __future__ import annotations

import pytest

from core import constants as C


# -----------------------------------------------------------------------------
# get_port
# -----------------------------------------------------------------------------
def test_get_port_default(monkeypatch):
    monkeypatch.delenv("PORT", raising=False)
    assert C.get_port() == C.DEFAULT_PORT


def test_get_port_env_override(monkeypatch):
    monkeypatch.setenv("PORT", "9000")
    assert C.get_port() == 9000


def test_get_port_invalid_env_raises(monkeypatch):
    monkeypatch.setenv("PORT", "not-a-port")
    with pytest.raises(ValueError):
        C.get_port()


# -----------------------------------------------------------------------------
# get_host
# -----------------------------------------------------------------------------
class TestGetHost:
    def test_dev_default(self, monkeypatch):
        monkeypatch.delenv("HOST", raising=False)
        assert C.get_host(is_dev=True) == C.DEFAULT_HOST_DEV

    def test_prod_default(self, monkeypatch):
        monkeypatch.delenv("HOST", raising=False)
        assert C.get_host(is_dev=False) == C.DEFAULT_HOST_PROD

    def test_env_override(self, monkeypatch):
        monkeypatch.setenv("HOST", "10.0.0.5")
        assert C.get_host(is_dev=True) == "10.0.0.5"

    def test_blank_env_falls_back_to_prod(self, monkeypatch):
        monkeypatch.setenv("HOST", "   ")
        assert C.get_host(is_dev=True) == C.DEFAULT_HOST_PROD


# -----------------------------------------------------------------------------
# Waitress helpers
# -----------------------------------------------------------------------------
def test_waitress_threads_default(monkeypatch):
    monkeypatch.delenv("WAITRESS_THREADS", raising=False)
    assert C.get_waitress_threads() == C.WAITRESS_THREADS_DEFAULT


def test_waitress_threads_env_override(monkeypatch):
    monkeypatch.setenv("WAITRESS_THREADS", "32")
    assert C.get_waitress_threads() == 32


def test_waitress_connection_limit_default(monkeypatch):
    monkeypatch.delenv("WAITRESS_CONNECTION_LIMIT", raising=False)
    assert (
        C.get_waitress_connection_limit() == C.WAITRESS_CONNECTION_LIMIT_DEFAULT
    )


def test_waitress_channel_timeout_default(monkeypatch):
    monkeypatch.delenv("WAITRESS_CHANNEL_TIMEOUT", raising=False)
    assert (
        C.get_waitress_channel_timeout() == C.WAITRESS_CHANNEL_TIMEOUT_DEFAULT
    )


# -----------------------------------------------------------------------------
# TTL bands -- pin the canonical second-counts
# -----------------------------------------------------------------------------
def test_ttl_band_values():
    assert C.TTL_15_MIN == 900
    assert C.TTL_30_MIN == 1_800
    assert C.TTL_HOUR == 3_600
    assert C.TTL_2H == 7_200
    assert C.TTL_4H == 14_400
    assert C.TTL_6H == 21_600
    assert C.TTL_DAY == 86_400


def test_freshness_minute_values():
    assert C.FRESHNESS_HOURLY_MINUTES == 60
    assert C.FRESHNESS_6H_MINUTES == 360
    assert C.FRESHNESS_DAILY_MINUTES == 1_440
