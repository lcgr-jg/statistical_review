"""
Debug exactly what compute_price_metrics_daily returns for future dates.
Run: python scripts/debug_price_metrics.py
"""
import datetime as dt, sys, logging
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
logging.disable(logging.WARNING)

import pandas as pd
from pages.heatmap_balance_data import (
    _get_forward_market_bundle, _price_metrics_from_market_dict,
    _get_market_bundle, compute_price_metrics_daily
)

today      = dt.date.today()
split      = today
start      = split - dt.timedelta(days=5)
end        = split + dt.timedelta(days=15)
fwd_trade  = today - dt.timedelta(days=1)
zone       = "FR"

print(f"zone={zone}  fwd_trade={fwd_trade}  window=[{start} → {end}]\n")

# ── 1. Raw forward bundle ────────────────────────────────────────────────────
mf = _get_forward_market_bundle(zone, fwd_trade, start, end)
print("Forward bundle components:")
for k, v in mf.items():
    if v is None:
        print(f"  {k}: None")
    elif hasattr(v, 'empty') and v.empty:
        print(f"  {k}: empty DataFrame")
    else:
        print(f"  {k}: shape={v.shape},  first={v.index.min()},  last={v.index.max()}")
        if k == "pwr":
            print(f"       columns={list(v.columns)[:3]}...")

# ── 2. Price metrics from forward bundle ─────────────────────────────────────
print("\nForward price metrics:")
tmpf = _price_metrics_from_market_dict(mf, zone, start, end)
if tmpf is None or tmpf.empty:
    print("  EMPTY — returned no data")
else:
    print(tmpf[["Spot","CSS","TTF","EUA"]].to_string())

# ── 3. Full compute_price_metrics_daily output ───────────────────────────────
print("\ncompute_price_metrics_daily output (full):")
out = compute_price_metrics_daily(zone, start, end, forward_trade_date=fwd_trade)
print(out.to_string())
