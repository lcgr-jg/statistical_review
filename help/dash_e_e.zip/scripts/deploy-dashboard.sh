#!/bin/bash
# =============================================================================
# DEPLOY EU-DASHBOARD-POWER TO SERVER
# =============================================================================
# Target server: 10.115.0.70 (same host as the eu_commods_pipelines dagster
# stack). docker-compose v1 is installed for the service account at
# ~/.local/bin/docker-compose.
#
# One-command deployment:
#   1. Refuse if tracked files are dirty
#   2. Merge <dev-branch> into main locally (--no-ff)
#   3. Push dev-branch (backup) + main
#   4. SSH to server, hard-reset to origin/main, rebuild + restart the
#      dashboard container via docker-compose
#   5. Probe /api/live through the container port
#   6. Switch you back to your original local branch
#
# App URL after deploy: http://10.115.0.70/   (nginx -> container port 8071)
#
# Usage (from eu_dashboard_power directory):
#   ./scripts/deploy-dashboard.sh                       # Full deploy (production.yaml)
#   ./scripts/deploy-dashboard.sh --direct              # Deploy dev branch directly (no merge to main)
#   ./scripts/deploy-dashboard.sh --dev                 # Deploy with deploy/dev.yaml
#   ./scripts/deploy-dashboard.sh --dev-branch feature  # Use a different dev branch
#   ./scripts/deploy-dashboard.sh --no-merge            # Skip merge (main already up to date)
#   ./scripts/deploy-dashboard.sh --no-push             # Skip git push
#   ./scripts/deploy-dashboard.sh --no-cache            # Force --no-cache build
#   ./scripts/deploy-dashboard.sh --logs                # Tail container logs after deploy
# =============================================================================

set -e

SERVER_USER="michael.kane"
SERVER_HOST="10.115.0.70"
SERVICE_USER="jsvc-eucommodpm"
REPO_DIR="eu_dashboard_power"
APP_PORT="8071"
SERVICE_NAME="dashboard"

DEV_BRANCH="mk_dev"
DIRECT_MODE=false
USE_DEV_COMPOSE=false
SKIP_MERGE=false
SKIP_PUSH=false
TAIL_LOGS=false
BUILD_FLAG=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --dev-branch)
            DEV_BRANCH="$2"
            shift 2
            ;;
        --direct)   DIRECT_MODE=true; shift ;;
        --dev)      USE_DEV_COMPOSE=true; shift ;;
        --no-merge) SKIP_MERGE=true; shift ;;
        --no-push)  SKIP_PUSH=true;  shift ;;
        --logs)     TAIL_LOGS=true;  shift ;;
        --no-cache) BUILD_FLAG="--no-cache"; shift ;;
        --help|-h)
            echo "Usage: $0 [--dev-branch <name>] [--direct] [--dev] [--no-merge] [--no-push] [--no-cache] [--logs]"
            echo "  --dev-branch  Branch to deploy (default: mk_dev)"
            echo "  --direct      Deploy dev branch directly (skip merge into main, skip push main)"
            echo "  --dev         Use deploy/dev.yaml instead of production.yaml"
            echo "  --no-merge    Skip merge (main already up to date)"
            echo "  --no-push     Skip git push"
            echo "  --no-cache    Build with --no-cache"
            echo "  --logs        Tail container logs after deploy"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

if [ "$USE_DEV_COMPOSE" = true ]; then
    COMPOSE_FILE="deploy/dev.yaml"
else
    COMPOSE_FILE="deploy/production.yaml"
fi

if [ "$DIRECT_MODE" = true ]; then
    DEPLOY_BRANCH="$DEV_BRANCH"
else
    DEPLOY_BRANCH="main"
fi

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

ls wheels/jain_commods-*.whl >/dev/null 2>&1 \
    || fail "No jain_commods wheel in wheels/. Run: pip download --no-deps -d wheels/ jain_commods==<version>"

echo "============================================="
echo "  DEPLOY EU-DASHBOARD-POWER"
echo "  Server: ${SERVER_HOST}"
echo "  Compose: ${COMPOSE_FILE}"
echo "  Dev branch: ${DEV_BRANCH}"
echo "  Deploy branch: ${DEPLOY_BRANCH}"
if [ "$DIRECT_MODE" = true ]; then
    echo "  Mode: DIRECT (no merge to main)"
fi
echo "============================================="
echo ""

ORIGINAL_BRANCH=$(git rev-parse --abbrev-ref HEAD) || fail "Not in a git repo."

# -----------------------------------------------------------------------------
# Step 1: Merge dev branch into main (skipped in --direct mode)
# -----------------------------------------------------------------------------
if [ "$DIRECT_MODE" = true ]; then
    echo "[1/4] Skipping merge (--direct: deploying ${DEV_BRANCH} directly)"
elif [ "$SKIP_MERGE" = false ]; then
    echo "[1/4] Merging ${DEV_BRANCH} into main..."

    if [ -n "$(git status --porcelain --untracked-files=no)" ]; then
        echo "  Working tree has uncommitted changes to tracked files:" >&2
        git status -s --untracked-files=no
        fail "Commit or stash your changes before deploying."
    fi

    untracked=$(git ls-files --others --exclude-standard)
    if [ -n "$untracked" ]; then
        echo "  Note: untracked files present (not deployed):"
        echo "$untracked" | sed 's/^/    /'
    fi

    git rev-parse --verify --quiet "$DEV_BRANCH" >/dev/null \
        || fail "Local branch '$DEV_BRANCH' does not exist."

    echo "  Pushing ${DEV_BRANCH} to origin (backup)..."
    git push origin "$DEV_BRANCH"

    git checkout main
    git pull --ff-only origin main || {
        git checkout "$ORIGINAL_BRANCH" >/dev/null
        fail "pull main failed (non-fast-forward?). Resolve manually."
    }

    if git merge-base --is-ancestor "$DEV_BRANCH" main; then
        echo "  ${DEV_BRANCH} is already merged into main, skipping merge."
    else
        if ! git merge --no-ff "$DEV_BRANCH" -m "Merge ${DEV_BRANCH} into main"; then
            echo "ERROR: merge failed (likely conflicts)." >&2
            echo "       Resolve conflicts on main, commit, then rerun with --no-merge." >&2
            exit 1
        fi
    fi
    echo "  Done."
else
    echo "[1/4] Skipping merge (--no-merge)"
    git checkout main
fi
echo ""

# -----------------------------------------------------------------------------
# Step 2: Push
# -----------------------------------------------------------------------------
if [ "$DIRECT_MODE" = true ]; then
    if [ "$SKIP_PUSH" = false ]; then
        echo "[2/4] Pushing ${DEV_BRANCH} to origin..."
        git push origin "$DEV_BRANCH" || fail "Failed to push ${DEV_BRANCH}."
        echo "  Done."
    else
        echo "[2/4] Skipping git push (--no-push)"
    fi
elif [ "$SKIP_PUSH" = false ]; then
    echo "[2/4] Pushing main to origin..."
    git push origin main || {
        git checkout "$ORIGINAL_BRANCH" >/dev/null
        fail "git push origin main failed."
    }
    echo "  Done."
else
    echo "[2/4] Skipping git push (--no-push)"
fi
echo ""

# -----------------------------------------------------------------------------
# Step 3: Build & restart on server
# -----------------------------------------------------------------------------
echo "[3/4] Pulling and rebuilding dashboard on ${SERVER_HOST}..."
echo "  You will be prompted for your SSH password, then sudo password."
echo ""

set +e
ssh -t "${SERVER_USER}@${SERVER_HOST}" "sudo -iu ${SERVICE_USER} bash -c '
    set -eo pipefail
    cd ~/${REPO_DIR}
    export PATH=\$HOME/.local/bin:\$PATH

    echo Pulling latest ${DEPLOY_BRANCH}...
    git fetch origin ${DEPLOY_BRANCH}
    git checkout ${DEPLOY_BRANCH}
    git reset --hard origin/${DEPLOY_BRANCH}

    if [ ! -f ${COMPOSE_FILE} ]; then
      echo ERROR compose file ${COMPOSE_FILE} not found in repo
      exit 2
    fi
    if grep -q env_file ${COMPOSE_FILE} && [ ! -f deploy/prod.env ]; then
      echo ERROR deploy/prod.env not found on server but ${COMPOSE_FILE} requires it.
      echo Upload it once from your laptop:
      echo \"  scp deploy/prod.env ${SERVER_USER}@${SERVER_HOST}:/tmp/prod.env.tmp\"
      echo \"  ssh ${SERVER_USER}@${SERVER_HOST} sudo -u ${SERVICE_USER} install -m 600 /tmp/prod.env.tmp ~/${REPO_DIR}/deploy/prod.env\"
      exit 3
    fi

    COMPOSE_ENV_ARG=
    if [ -f deploy/prod.env ]; then
      COMPOSE_ENV_ARG=--env-file=deploy/prod.env
    fi

    echo
    echo Building image...
    docker-compose \$COMPOSE_ENV_ARG -f ${COMPOSE_FILE} build ${BUILD_FLAG} ${SERVICE_NAME} 2>&1 | tail -30

    echo
    echo Restarting service...
    docker-compose \$COMPOSE_ENV_ARG -f ${COMPOSE_FILE} up -d --force-recreate ${SERVICE_NAME}

    echo
    echo Container status:
    docker-compose \$COMPOSE_ENV_ARG -f ${COMPOSE_FILE} ps ${SERVICE_NAME}

    echo
    echo Health check:
    for i in \$(seq 1 20); do
        if curl -fsS http://127.0.0.1:${APP_PORT}/api/live >/dev/null 2>&1; then
            echo alive after \$((i * 3)) seconds
            curl -fsS http://127.0.0.1:${APP_PORT}/api/live
            echo
            exit 0
        fi
        sleep 3
    done
    echo ERROR container did not respond on port ${APP_PORT}
    docker-compose \$COMPOSE_ENV_ARG -f ${COMPOSE_FILE} logs --tail=50 ${SERVICE_NAME}
    exit 1
'"
DEPLOY_EXIT=$?
set -e

if [ $DEPLOY_EXIT -ne 0 ]; then
    git checkout "$ORIGINAL_BRANCH" >/dev/null
    fail "Server deploy failed (exit ${DEPLOY_EXIT}). Check container logs on the server."
fi

# -----------------------------------------------------------------------------
# Step 4: Restore original branch and report
# -----------------------------------------------------------------------------
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
if [ "$ORIGINAL_BRANCH" != "$CURRENT_BRANCH" ]; then
    git checkout "$ORIGINAL_BRANCH" >/dev/null
    echo ""
    echo "  Switched back to ${ORIGINAL_BRANCH}."
fi

echo ""
echo "[4/4] Deploy complete!"
echo "  App: http://${SERVER_HOST}/  (container port ${APP_PORT})"
echo "  Deployed branch: ${DEPLOY_BRANCH}"
echo ""

if [ "$TAIL_LOGS" = true ]; then
    echo "Tailing logs (Ctrl+C to stop)..."
    ssh -t "${SERVER_USER}@${SERVER_HOST}" "sudo -iu ${SERVICE_USER} bash -c '
        cd ~/${REPO_DIR} &&
        export PATH=\$HOME/.local/bin:\$PATH &&
        docker-compose -f ${COMPOSE_FILE} logs -f --tail=100 ${SERVICE_NAME}
    '"
fi
