"""
Run the Heatmap Balance view as a single-app Dash process (no full portal).

Usage (from repo root ``eu_dashboard_power``):

    set HEATMAP_STANDALONE=1
    python scripts/run_heatmap_balance_standalone.py

PowerShell:

    $env:HEATMAP_STANDALONE="1"; python scripts/run_heatmap_balance_standalone.py

Default port 8051 (change with --port). Opens http://127.0.0.1:8051/

Requires the same Python env as the portal (jain_commods, core.* on path).
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Repo root: eu_dashboard_power/
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Must be set before importing pages.heatmap_balance (skips dash.register_page)
os.environ["HEATMAP_STANDALONE"] = "1"


def main() -> None:
    parser = argparse.ArgumentParser(description="Heatmap Balance standalone Dash app")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host")
    parser.add_argument("--port", type=int, default=8051, help="Port")
    parser.add_argument("--debug", action="store_true", help="Dash debug mode")
    args = parser.parse_args()

    import dash_bootstrap_components as dbc
    from dash import Dash

    app = Dash(
        __name__,
        use_pages=False,
        title="Heatmap Balance",
        external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.FONT_AWESOME],
        suppress_callback_exceptions=True,
    )

    # Import after app exists so @callback binds to this app
    from pages import heatmap_balance

    app.layout = heatmap_balance.layout

    print(f"Open http://{args.host}:{args.port}/")
    app.run(debug=args.debug, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
