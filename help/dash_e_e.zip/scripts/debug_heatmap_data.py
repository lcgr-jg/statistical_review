"""
Debug script: probe each data source used by the Heatmap Balance dashboard
and report which S3 caches are available vs missing for the current window.

Usage (from repo root):
    python scripts/debug_heatmap_data.py
    python scripts/debug_heatmap_data.py --zone FR --days 5
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import logging
import pandas as pd
logging.basicConfig(level=logging.WARNING)

from jain_commods.core.cache.data.fundamentals import (
    ModelTag, IssueVersion,
    ResLoadBackcast, ConsBackcast, GenWindBackcast, GenSolarBackcast,
    ResLoadFcstST, ConsFcstST, GenWindFcstST, GenSolarFcstST,
    GenNuclearActual, GenNuclearFcstST,
    GenHydroTotalActual, GenHydroTotalFcst,
    GenCoalActual, GenLigniteActual, GenGasActual,
    NetExportDayAhead,
)
from jain_commods.core.cache.data.market import (
    PricePowerSpot, PriceGasSpot, PriceCO2Spot, PriceCoalSpot,
    PricePowerForward, PriceGasForward, PriceCO2Forward, PriceCoalForward,
)

OK   = "\033[92m OK  \033[0m"
MISS = "\033[91mMISS \033[0m"
WARN = "\033[93mWARN \033[0m"


def _probe_actual(cls, zone: str, start: dt.date, end: dt.date) -> tuple[str, str]:
    try:
        obj = cls()
        obj.load(from_s3=True, show_metadata=False, zones=[zone], start_date=start, end_date=end)
        d = getattr(obj, "data", None)
        if d is None or d.empty:
            return MISS, "empty"
        rows = len(d)
        last = pd.Timestamp(d.index.max()).date() if hasattr(d.index.max(), 'date') else d.index.max()
        today = dt.date.today()
        gap = (today - last).days if isinstance(last, dt.date) else "?"
        gap_str = f"  ⚠ {gap}d gap" if isinstance(gap, int) and gap > 1 else ""
        return OK, f"{rows} rows, last={last}{gap_str}"
    except Exception as e:
        return MISS, str(e)[:80]


def _probe_forecast(cls, zone: str, issue: dt.date, start: dt.date, end: dt.date) -> tuple[str, str]:
    try:
        if cls.__name__ == "GenNuclearFcstST":
            obj = GenNuclearFcstST(issue_date=issue)
        elif cls.__name__ == "GenHydroTotalFcst":
            obj = GenHydroTotalFcst(issue_date=issue)
        else:
            obj = cls(tag=ModelTag.EC, issue_date=issue, issue_version=IssueVersion.IV00)
        obj.load(from_s3=True, show_metadata=False, zones=[zone],
                 start_date=start, end_date=end,
                 issue_date=issue, issue_version=IssueVersion.IV00)
        d = getattr(obj, "data", None)
        if d is None or d.empty:
            return MISS, "empty"
        rows = len(d)
        last = d.index.max()
        return OK, f"{rows} rows, last={last}"
    except Exception as e:
        return MISS, str(e)[:80]


def _probe_spot(cls, start: dt.date, end: dt.date, **kw) -> tuple[str, str]:
    try:
        obj = cls(**kw)
        obj.load(from_s3=True, show_metadata=False, start_date=start, end_date=end)
        d = getattr(obj, "data", None)
        if d is None or d.empty:
            return MISS, "empty"
        last = pd.Timestamp(d.index.max()).date() if hasattr(d.index.max(), 'date') else d.index.max()
        today = dt.date.today()
        gap = (today - last).days if isinstance(last, dt.date) else "?"
        gap_str = f"  ⚠ {gap}d gap" if isinstance(gap, int) and gap > 1 else ""
        return OK, f"{len(d)} rows, last={last}{gap_str}"
    except Exception as e:
        return MISS, str(e)[:80]


def _probe_forward(cls, trade: dt.date, **kw) -> tuple[str, str]:
    try:
        obj = cls(**kw)
        obj.load(from_s3=True, show_metadata=False, trade_date=trade)
        d = getattr(obj, "data", None)
        if d is None or d.empty:
            return MISS, "empty"
        return OK, f"{len(d)} rows"
    except Exception as e:
        return MISS, str(e)[:80]


def run(zone: str, history: int, forward: int) -> None:
    today      = dt.date.today()
    split      = today
    issue      = today
    start      = split - dt.timedelta(days=history)
    end        = split + dt.timedelta(days=forward)
    fwd_trade  = issue - dt.timedelta(days=1)

    print(f"\n{'='*70}")
    print(f"  Heatmap Balance data probe — zone={zone.upper()}")
    print(f"  today={today}  window=[{start} → {end}]  issue={issue}  fwd_trade={fwd_trade}")
    print(f"{'='*70}\n")

    rows = []

    # ── Actual backcast fundamentals ─────────────────────────────────────────
    for cls in [ResLoadBackcast, ConsBackcast, GenWindBackcast, GenSolarBackcast,
                GenHydroTotalActual, GenNuclearActual,
                GenCoalActual, GenLigniteActual, GenGasActual, NetExportDayAhead]:
        tag, msg = _probe_actual(cls, zone.lower(), start, end)
        rows.append((tag, f"[actual]  {cls.__name__}", msg))

    # ── ST forecast fundamentals ─────────────────────────────────────────────
    for cls in [ResLoadFcstST, ConsFcstST, GenWindFcstST, GenSolarFcstST,
                GenHydroTotalFcst, GenNuclearFcstST]:
        tag, msg = _probe_forecast(cls, zone.lower(), issue, start, end)
        rows.append((tag, f"[fcst]    {cls.__name__}", msg))

    # ── Spot market ──────────────────────────────────────────────────────────
    tag, msg = _probe_spot(PricePowerSpot, start, end, freq="h")
    rows.append((tag, "[spot]    PricePowerSpot", msg))
    for cls in [PriceGasSpot, PriceCO2Spot, PriceCoalSpot]:
        tag, msg = _probe_spot(cls, start, end)
        rows.append((tag, f"[spot]    {cls.__name__}", msg))

    # ── Forward market ───────────────────────────────────────────────────────
    zu = zone.upper()
    if zu not in ("UK", "GB"):
        tag, msg = _probe_forward(PricePowerForward, fwd_trade, country_code=zu)
        rows.append((tag, f"[forward] PricePowerForward ({zu})", msg))
    for cls in [PriceGasForward, PriceCO2Forward, PriceCoalForward]:
        tag, msg = _probe_forward(cls, fwd_trade)
        rows.append((tag, f"[forward] {cls.__name__}", msg))

    # ── Print ────────────────────────────────────────────────────────────────
    miss_count = 0
    for tag, label, msg in rows:
        print(f"  {tag}  {label:<45}  {msg}")
        if "MISS" in tag:
            miss_count += 1

    print(f"\n  {miss_count}/{len(rows)} sources missing\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--zone", default="DE")
    parser.add_argument("--days", type=int, default=5,
                        help="history days (forward is fixed at 15)")
    args = parser.parse_args()
    run(args.zone, history=args.days, forward=15)
