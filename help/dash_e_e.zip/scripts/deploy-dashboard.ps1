# =============================================================================
# DEPLOY EU-DASHBOARD-POWER TO SERVER (PowerShell)
# =============================================================================
# Target server: 10.115.0.70 (same host as the eu_commods_pipelines dagster
# stack). docker-compose v1 is installed for the service account at
# ~/.local/bin/docker-compose.
#
# One-command deployment:
#   1. Refuse if tracked files are dirty
#   2. Merge <DevBranch> into main locally (--no-ff)
#   3. Push DevBranch (backup) + main
#   4. SSH to server, hard-reset to origin/main, rebuild + restart the
#      dashboard container via docker-compose
#   5. Probe /api/live through the container port
#   6. Switch you back to your original local branch
#
# App URL after deploy: http://10.115.0.70/   (nginx -> container port 8071)
#
# Usage (from eu_dashboard_power directory):
#   .\scripts\deploy-dashboard.ps1                       # Full deploy (production.yaml)
#   .\scripts\deploy-dashboard.ps1 -Direct               # Deploy dev branch directly (no merge to main)
#   .\scripts\deploy-dashboard.ps1 -Dev                  # Deploy with deploy/dev.yaml
#   .\scripts\deploy-dashboard.ps1 -DevBranch feature_x  # Use a different dev branch
#   .\scripts\deploy-dashboard.ps1 -NoMerge              # Skip merge (main already up to date)
#   .\scripts\deploy-dashboard.ps1 -NoPush               # Skip git push
#   .\scripts\deploy-dashboard.ps1 -NoCache              # Force docker-compose build --no-cache
#   .\scripts\deploy-dashboard.ps1 -Logs                 # Tail container logs after deploy
# =============================================================================

param(
    [string]$DevBranch = "mk_dev",
    [switch]$Direct,
    [switch]$Dev,
    [switch]$NoMerge,
    [switch]$NoPush,
    [switch]$NoCache,
    [switch]$Logs,
    [switch]$Help
)

$ServerUser   = "john.morley"
$ServerHost   = "10.115.0.70"
$ServiceUser  = "jsvc-eucommodpm"
$RepoDir      = "eu_dashboard_power"
$AppPort      = "8071"
$ServiceName  = "dashboard"

if ($Dev) {
    $ComposeFile = "deploy/dev.yaml"
} else {
    $ComposeFile = "deploy/production.yaml"
}

if ($Help) {
    Write-Host "Usage: .\deploy-dashboard.ps1 [-DevBranch <name>] [-Direct] [-Dev] [-NoMerge] [-NoPush] [-NoCache] [-Logs]"
    Write-Host "  -DevBranch  Branch to deploy (default: mk_dev)"
    Write-Host "  -Direct     Deploy dev branch directly (skip merge into main, skip push main)"
    Write-Host "  -Dev        Use deploy/dev.yaml instead of production.yaml"
    Write-Host "  -NoMerge    Skip merge (main already has the changes)"
    Write-Host "  -NoPush     Skip git push (deploy what's on remote)"
    Write-Host "  -NoCache    Build with --no-cache"
    Write-Host "  -Logs       Tail container logs after deploy"
    exit 0
}

function Fail($msg) {
    Write-Host "ERROR: $msg" -ForegroundColor Red
    exit 1
}

$DeployBranch = if ($Direct) { $DevBranch } else { "main" }

$pinMatch = Select-String -Path "pyproject.toml" -Pattern 'jain_commods==(\d+\.\d+\.\d+)' |
    Select-Object -First 1
if (-not $pinMatch) {
    Fail "Could not read jain_commods==X.Y.Z from pyproject.toml"
}
$pin = $pinMatch.Matches[0].Groups[1].Value
$wheels = @(Get-ChildItem -Path "wheels\jain_commods-*.whl" -ErrorAction SilentlyContinue)
if (-not $wheels) {
    Fail "No jain_commods wheel in wheels/. Expected jain_commods-$pin-*.whl (see README 'Updating jain_commods')."
}
$match = @($wheels | Where-Object { $_.Name -like "jain_commods-$pin-*" })
if (-not $match) {
    $have = ($wheels | ForEach-Object { $_.Name }) -join ", "
    Fail "pyproject.toml pins jain_commods==$pin but wheels/ has: $have. Commit the matching wheel before deploy -- the server cannot download jain_commods from Azure Artifacts."
}
if ($wheels.Count -gt 1) {
    Write-Host "  Note: extra jain_commods wheels in wheels/ (Docker installs all of them):" -ForegroundColor Yellow
    $wheels | ForEach-Object { Write-Host "    $($_.Name)" -ForegroundColor Yellow }
}

Write-Host "============================================="
Write-Host "  DEPLOY EU-DASHBOARD-POWER"
Write-Host "  Server: ${ServerHost}"
Write-Host "  Compose: ${ComposeFile}"
Write-Host "  Dev branch: ${DevBranch}"
Write-Host "  Deploy branch: ${DeployBranch}"
if ($Direct) { Write-Host "  Mode: DIRECT (no merge to main)" -ForegroundColor Cyan }
Write-Host "============================================="
Write-Host ""

$OriginalBranch = (git rev-parse --abbrev-ref HEAD).Trim()
if ($LASTEXITCODE -ne 0) { Fail "Not in a git repo (or git not on PATH)." }

# -----------------------------------------------------------------------------
# Step 1: Merge DevBranch into main (skipped in -Direct mode)
# -----------------------------------------------------------------------------
if ($Direct) {
    Write-Host "[1/4] Skipping merge (-Direct: deploying ${DevBranch} directly)"
} elseif (-not $NoMerge) {
    Write-Host "[1/4] Merging ${DevBranch} into main..."

    $dirty = git status --porcelain --untracked-files=no
    if ($dirty) {
        Write-Host "  Working tree has uncommitted changes to tracked files:" -ForegroundColor Yellow
        git status -s --untracked-files=no
        Fail "Commit or stash your changes before deploying."
    }

    $untracked = git ls-files --others --exclude-standard
    if ($untracked) {
        Write-Host "  Note: untracked files present (not deployed):" -ForegroundColor DarkGray
        $untracked | ForEach-Object { Write-Host "    $_" -ForegroundColor DarkGray }
    }

    git rev-parse --verify --quiet "$DevBranch" | Out-Null
    if ($LASTEXITCODE -ne 0) { Fail "Local branch '$DevBranch' does not exist." }

    Write-Host "  Pushing ${DevBranch} to origin (backup)..."
    git push origin $DevBranch
    if ($LASTEXITCODE -ne 0) { Fail "Failed to push ${DevBranch}." }

    git checkout main
    if ($LASTEXITCODE -ne 0) { Fail "checkout main failed." }

    git pull --ff-only origin main
    if ($LASTEXITCODE -ne 0) {
        git checkout $OriginalBranch | Out-Null
        Fail "pull main failed (non-fast-forward?). Resolve manually."
    }

    git merge-base --is-ancestor $DevBranch main
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ${DevBranch} is already merged into main, skipping merge."
    } else {
        git merge --no-ff $DevBranch -m "Merge ${DevBranch} into main"
        if ($LASTEXITCODE -ne 0) {
            Write-Host "ERROR: merge failed (likely conflicts)." -ForegroundColor Red
            Write-Host "       Resolve conflicts on main, commit, then rerun with -NoMerge." -ForegroundColor Red
            exit 1
        }
    }
    Write-Host "  Done."
} else {
    Write-Host "[1/4] Skipping merge (-NoMerge)"
    git checkout main | Out-Null
    if ($LASTEXITCODE -ne 0) { Fail "checkout main failed." }
}
Write-Host ""

# -----------------------------------------------------------------------------
# Step 2: Push
# -----------------------------------------------------------------------------
if ($Direct) {
    if (-not $NoPush) {
        Write-Host "[2/4] Pushing ${DevBranch} to origin..."
        git push origin $DevBranch
        if ($LASTEXITCODE -ne 0) { Fail "Failed to push ${DevBranch}." }
        Write-Host "  Done."
    } else {
        Write-Host "[2/4] Skipping git push (-NoPush)"
    }
} elseif (-not $NoPush) {
    Write-Host "[2/4] Pushing main to origin..."
    git push origin main
    if ($LASTEXITCODE -ne 0) {
        git checkout $OriginalBranch | Out-Null
        Fail "git push origin main failed."
    }
    Write-Host "  Done."
} else {
    Write-Host "[2/4] Skipping git push (-NoPush)"
}
Write-Host ""

# -----------------------------------------------------------------------------
# Step 3: Build & restart on server
# -----------------------------------------------------------------------------
$BuildFlag = ""
if ($NoCache) { $BuildFlag = "--no-cache" }

Write-Host "[3/4] Pulling and rebuilding dashboard on ${ServerHost}..."
Write-Host "  You will be prompted for your SSH password, then sudo password."
Write-Host ""

# Literal here-string so bash `if [ ... ]` / `$(seq ...)` is never parsed by PowerShell.
$TempScript = "/tmp/.deploy_dashboard_${PID}.sh"
$RemoteScript = @'
#!/bin/bash
set -eo pipefail
cd ~/__REPO_DIR__
export PATH=$HOME/.local/bin:$PATH

echo Pulling latest __DEPLOY_BRANCH__...
git fetch origin __DEPLOY_BRANCH__
git checkout __DEPLOY_BRANCH__
git reset --hard origin/__DEPLOY_BRANCH__

if [ ! -f __COMPOSE_FILE__ ]; then
  echo ERROR compose file __COMPOSE_FILE__ not found in repo
  exit 2
fi
if grep -q env_file __COMPOSE_FILE__ && [ ! -f deploy/prod.env ]; then
  echo ERROR deploy/prod.env not found on server but __COMPOSE_FILE__ requires it.
  echo Upload it once from your laptop:
  echo   scp deploy/prod.env __SERVER_USER__@__SERVER_HOST__:/tmp/prod.env.tmp
  echo   ssh __SERVER_USER__@__SERVER_HOST__ sudo -u __SERVICE_USER__ install -m 600 /tmp/prod.env.tmp ~/__REPO_DIR__/deploy/prod.env
  exit 3
fi

COMPOSE_ENV_ARG=
if [ -f deploy/prod.env ]; then
  COMPOSE_ENV_ARG=--env-file=deploy/prod.env
fi

echo
echo Building image...
docker-compose $COMPOSE_ENV_ARG -f __COMPOSE_FILE__ build __BUILD_FLAG__ __SERVICE_NAME__ 2>&1 | tail -30

echo
echo Restarting service...
docker-compose $COMPOSE_ENV_ARG -f __COMPOSE_FILE__ up -d --force-recreate __SERVICE_NAME__

echo
echo Container status:
docker-compose $COMPOSE_ENV_ARG -f __COMPOSE_FILE__ ps __SERVICE_NAME__

echo
echo Health check:
for i in $(seq 1 20); do
  if curl -fsS http://127.0.0.1:__APP_PORT__/api/live >/dev/null 2>&1; then
    echo "alive after $((i * 3)) seconds"
    curl -fsS http://127.0.0.1:__APP_PORT__/api/live
    echo
    exit 0
  fi
  sleep 3
done
echo ERROR container did not respond on port __APP_PORT__
docker-compose $COMPOSE_ENV_ARG -f __COMPOSE_FILE__ logs --tail=50 __SERVICE_NAME__
exit 1
'@
$RemoteScript = $RemoteScript.Replace("`r`n", "`n").
    Replace('__REPO_DIR__', $RepoDir).
    Replace('__DEPLOY_BRANCH__', $DeployBranch).
    Replace('__COMPOSE_FILE__', $ComposeFile).
    Replace('__SERVER_USER__', $ServerUser).
    Replace('__SERVER_HOST__', $ServerHost).
    Replace('__SERVICE_USER__', $ServiceUser).
    Replace('__BUILD_FLAG__', $BuildFlag).
    Replace('__SERVICE_NAME__', $ServiceName).
    Replace('__APP_PORT__', $AppPort)

# Step A: upload the script as michael.kane (no sudo, no TTY required)
Write-Host "  Uploading deploy script to server..."
$RemoteScript | ssh "${ServerUser}@${ServerHost}" "cat > '$TempScript' && chmod 644 '$TempScript'"
if ($LASTEXITCODE -ne 0) {
    git checkout $OriginalBranch | Out-Null
    Fail "Failed to upload deploy script to server."
}

# Step B: execute via sudo (TTY allocated for sudo password prompt)
Write-Host "  Running deploy on server (you will be prompted for sudo password)..."
ssh -t "${ServerUser}@${ServerHost}" "sudo -iu ${ServiceUser} bash '$TempScript'; _CODE=`$?; rm -f '$TempScript'; exit `$_CODE"

$DeployExit = $LASTEXITCODE
if ($DeployExit -ne 0) {
    git checkout $OriginalBranch | Out-Null
    Fail "Server deploy failed (exit ${DeployExit}). Check container logs on the server."
}

# -----------------------------------------------------------------------------
# Step 4: Restore original branch and report
# -----------------------------------------------------------------------------
if ($OriginalBranch -ne (git rev-parse --abbrev-ref HEAD).Trim()) {
    git checkout $OriginalBranch | Out-Null
    Write-Host ""
    Write-Host "  Switched back to ${OriginalBranch}."
}

Write-Host ""
Write-Host "[4/4] Deploy complete!" -ForegroundColor Green
Write-Host "  App: http://${ServerHost}/  (container port ${AppPort})"
Write-Host "  Deployed branch: ${DeployBranch}"
Write-Host ""

if ($Logs) {
    Write-Host "Tailing logs (Ctrl+C to stop)..."
    ssh -t "${ServerUser}@${ServerHost}" "sudo -iu ${ServiceUser} bash -c 'cd ~/${RepoDir} && export PATH=`$HOME/.local/bin:`$PATH && docker-compose -f ${ComposeFile} logs -f --tail=100 ${ServiceName}'"
}
