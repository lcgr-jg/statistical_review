@echo off
setlocal EnableExtensions
title EU Power Dashboard (local)

REM Local launcher for portal_app.py — works from Command Prompt / double-click.
REM Does not require conda on PATH or a working PowerShell.

cd /d "%~dp0.."

set "DASH_ENV=local"
set "PORT=8071"
set "DASH_DEBUG=1"

REM Avoid native ACCESS_VIOLATION (-1073741819) from concurrent OpenMP/MKL
REM inside pandas/numpy while cache sources warm in parallel.
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "NUMEXPR_NUM_THREADS=1"
set "CACHE_WARM_WORKERS=1"

REM ── Commodity Essentials credentials ───────────────────────────────────
REM Loaded from scripts\local.env (gitignored). Copy from local.env.example
REM and fill in CE_USER / CE_PASS.
if exist "%~dp0local.env" (
  for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%~dp0local.env") do (
    if not "%%A"=="" set "%%A=%%B"
  )
)

if not defined CE_USER goto :missing_ce
if not defined CE_PASS goto :missing_ce
if "%CE_USER%"=="" goto :missing_ce
if "%CE_PASS%"=="" goto :missing_ce
if "%CE_USER%"=="<ce-username>" goto :missing_ce
if "%CE_PASS%"=="<ce-password>" goto :missing_ce

if defined DASH_PY if exist "%DASH_PY%" (
  set "PY=%DASH_PY%"
  goto :run
)

set "CANDIDATE=%USERPROFILE%\AppData\Local\anaconda3\envs\eu-dashboard\python.exe"
if exist "%CANDIDATE%" (
  set "PY=%CANDIDATE%"
  goto :run
)

set "CANDIDATE=%USERPROFILE%\anaconda3\envs\eu-dashboard\python.exe"
if exist "%CANDIDATE%" (
  set "PY=%CANDIDATE%"
  goto :run
)

set "CANDIDATE=%USERPROFILE%\AppData\Local\miniconda3\envs\eu-dashboard\python.exe"
if exist "%CANDIDATE%" (
  set "PY=%CANDIDATE%"
  goto :run
)

echo ERROR: Could not find eu-dashboard Python.
echo.
echo Set DASH_PY to your interpreter, e.g.:
echo   set DASH_PY=C:\path\to\eu-dashboard\python.exe
echo   scripts\start-local.bat
echo.
pause
exit /b 1

:missing_ce
echo ERROR: CE_USER / CE_PASS not set.
echo.
echo Commodity Essentials credentials are required for the CE gas data cache.
echo Create scripts\local.env from the example and fill them in:
echo.
echo   copy scripts\local.env.example scripts\local.env
echo.
echo Then edit scripts\local.env and set CE_USER and CE_PASS.
echo ^(scripts\local.env is gitignored — do not commit secrets.^)
echo.
pause
exit /b 1

:run
echo Using:  %PY%
echo Repo:   %CD%
echo URL:    http://localhost:%PORT%
echo CE:     user=%CE_USER%
if defined KPLER_LNG_EMAIL (
  echo Kpler:  email=%KPLER_LNG_EMAIL%
) else (
  echo Kpler:  NOT SET — Qatar Monitor cache warm-up will fail until
  echo         KPLER_LNG_EMAIL / KPLER_LNG_PASSWORD are in scripts\local.env
)
echo.
echo Press Ctrl+C to stop.
echo.

"%PY%" portal_app.py
set "EC=%ERRORLEVEL%"
echo.
echo Process exited with code %EC%.
pause
exit /b %EC%
