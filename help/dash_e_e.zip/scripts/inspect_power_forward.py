"""
Inspect PricePowerForward contents for the heatmap forward trade date.
Run: python scripts/inspect_power_forward.py
"""
import datetime as dt
import sys
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import logging
logging.disable(logging.WARNING)

from jain_commods.core.cache.data.market import PricePowerForward

today          = dt.date.today()
trade_date     = today - dt.timedelta(days=1)   # yesterday = forward_trade_date used by dashboard
start          = today - dt.timedelta(days=5)
end            = today + dt.timedelta(days=20)

print(f"Loading PricePowerForward  country=DE  trade_date={trade_date}")
print(f"Delivery window: {start} → {end}\n")

try:
    obj = PricePowerForward(country_code="DE")
    obj.load(from_s3=True, trade_date=trade_date, show_metadata=False,
             start_date=start, end_date=end)
    d = getattr(obj, "data", None)
except Exception as e:
    print(f"ERROR loading: {e}")
    sys.exit(1)

if d is None or d.empty:
    print("Result: empty DataFrame")
    sys.exit(0)

print(f"Shape       : {d.shape}")
print(f"Index type  : {type(d.index).__name__}")
print(f"First date  : {d.index.min()}")
print(f"Last date   : {d.index.max()}")
print(f"Columns     : {list(d.columns)}")
print(f"\nUnique delivery dates ({len(d)} rows):")
print(pd.to_datetime(d.index).normalize().unique().sort_values().tolist())
print(f"\nFull data:\n{d.to_string()}")
