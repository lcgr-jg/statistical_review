"""Shared dark theme for the EU dashboard family.

This is the single source of truth for:
  - Plotly layout defaults (DARK_LAYOUT)
  - Colour palettes (COLORS, TECHNO_COLORS, FUEL_COLORS)
  - Dash DataTable styles
  - The CSS stylesheet (loaded via install_theme_css(app))

Each dashboard's app.py should call ``install_theme_css(app)`` once during
initialisation; the CSS is served from this package's ``assets`` folder.
"""

from pathlib import Path
import shutil

PLOT_HEIGHT = 480
PLOT_TEMPLATE = 'plotly_dark'

# ---------------------------------------------------------------------------
# Plotly layout defaults
# ---------------------------------------------------------------------------

DARK_LAYOUT = dict(
    template=PLOT_TEMPLATE,
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)',
    font_color='#e0e0e0',
    hoverlabel=dict(
        bgcolor='#22262e',
        font_color='#e0e0e0',
        font_size=12,
        bordercolor='#353a44',
    ),
    xaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
    yaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
    height=PLOT_HEIGHT,
    margin=dict(l=50, r=20, t=50, b=40),
    legend=dict(
        bgcolor='rgba(34,38,46,0.95)',
        font=dict(color='#e0e0e0', size=11),
        bordercolor='#353a44',
        borderwidth=1,
    ),
    hovermode='x unified',
)

# ---------------------------------------------------------------------------
# Colour palettes
# ---------------------------------------------------------------------------

# General / legacy naming (used by stack price page, etc.)
COLORS = {
    'stack_price': '#4dabf7',
    'met_price': '#ff6b6b',
    'demand': '#51cf66',
    'nuclear': '#ffa94d',
    'gas': '#ff6b6b',
    'coal': '#8a8f9a',
    'hydro': '#4dabf7',
    'wind': '#74c0fc',
    'solar': '#ffd43b',
    'virtual_thermal': '#cc5de8',
    'other': '#868e96',
    'normal': '#8a8f9a',
}

# Technology keys as they appear in power_stack_dispatch_by_techno / prompt_output
TECHNO_COLORS = {
    'nuclear': '#ffa94d',
    'gas': '#ff6b6b',
    'coal': '#868e96',
    'lignite': '#6b5b4c',
    'hydro_ror': '#4dabf7',
    'hydro_reservoir': '#1971c2',
    'run_of_river': '#4dabf7',
    'reservoirs_pumped_storage': '#1971c2',
    'reservoirs_and_pumped_storage': '#1971c2',
    'hydro_pumped': '#339af0',
    'virtual_thermal': '#cc5de8',
    'wind': '#74c0fc',
    'solar': '#ffd43b',
    'biomass': '#51cf66',
    'oil': '#e8590c',
    'other': '#868e96',
    'import': '#adb5bd',
}

# Fuel-type naming (EQ generation curves / benchmarks)
FUEL_COLORS = {
    'gas': '#ff6b6b',
    'coal': '#868e96',
    'lignite': '#6b5b4c',
    'nuclear': '#ffa94d',
    'wind': '#74c0fc',
    'solar': '#ffd43b',
    'biomass': '#51cf66',
    'oil': '#e8590c',
    'hydro_ror': '#4dabf7',
    'hydro_pumped': '#339af0',
    'hydro_reservoir': '#1c7ed6',
}

# ---------------------------------------------------------------------------
# Dash DataTable styles
# ---------------------------------------------------------------------------

TABLE_STYLE_HEADER = {
    'backgroundColor': '#1e3a5f',
    'color': '#e0e0e0',
    'fontWeight': '600',
    'fontSize': '0.82rem',
    'border': '1px solid #353a44',
    'textAlign': 'center',
}

TABLE_STYLE_CELL = {
    'backgroundColor': '#22262e',
    'color': '#e0e0e0',
    'fontSize': '0.82rem',
    'border': '1px solid #353a44',
    'textAlign': 'center',
    'padding': '6px 10px',
}

TABLE_STYLE_DATA_CONDITIONAL = [
    {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
]


def styled_layout(title: str, y_title: str = '') -> dict:
    """Return a copy of DARK_LAYOUT with a title (and optional y-axis title) applied."""
    layout = dict(DARK_LAYOUT)
    layout['title'] = dict(text=title, font=dict(size=15, color='#e0e0e0'))
    if y_title:
        layout['yaxis'] = dict(
            gridcolor='rgba(255,255,255,0.06)', zeroline=False, title=y_title,
        )
    return layout


# ---------------------------------------------------------------------------
# CSS installation
# ---------------------------------------------------------------------------

_THEME_CSS_NAME = '00-common-theme.css'
_THEME_CSS_SRC = Path(__file__).parent / 'assets' / _THEME_CSS_NAME


def install_theme_css(app) -> None:
    """Copy the shared theme CSS into the dashboard's ``assets/`` folder.

    Dash only serves CSS from each app's own assets directory.  Rather than
    have three copies that drift out of sync, we maintain one file here and
    sync it into each app's assets on startup.  The file is prefixed with
    ``00-`` so it loads before any dashboard-specific overrides.
    """
    if not _THEME_CSS_SRC.exists():
        raise FileNotFoundError(
            f"Common theme CSS missing: {_THEME_CSS_SRC}. "
            f"Create it or reinstall the common package."
        )

    # Dash serves CSS from <app_dir>/assets/.  Locate the caller's app dir.
    # We rely on the fact that app.config.assets_folder is the absolute path.
    assets_dir = Path(app.config.assets_folder)
    assets_dir.mkdir(parents=True, exist_ok=True)

    dest = assets_dir / _THEME_CSS_NAME
    if not dest.exists() or dest.read_bytes() != _THEME_CSS_SRC.read_bytes():
        shutil.copyfile(_THEME_CSS_SRC, dest)
