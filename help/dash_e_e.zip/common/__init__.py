"""Shared utilities for the EU dashboard family.

Each dashboard imports from here via a sys.path entry added at the top of its
app.py:

    import sys, pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
    from common import theme, health

Kept intentionally dependency-light (stdlib + dash only).
"""

from .theme import (
    DARK_LAYOUT, PLOT_HEIGHT, PLOT_TEMPLATE,
    COLORS, TECHNO_COLORS, FUEL_COLORS,
    TABLE_STYLE_HEADER, TABLE_STYLE_CELL, TABLE_STYLE_DATA_CONDITIONAL,
    styled_layout, install_theme_css,
)
from .health import register_health
from .links import url_for, public_host, PORTS

__all__ = [
    'DARK_LAYOUT', 'PLOT_HEIGHT', 'PLOT_TEMPLATE',
    'COLORS', 'TECHNO_COLORS', 'FUEL_COLORS',
    'TABLE_STYLE_HEADER', 'TABLE_STYLE_CELL', 'TABLE_STYLE_DATA_CONDITIONAL',
    'styled_layout', 'install_theme_css', 'register_health',
    'url_for', 'public_host', 'PORTS',
]
