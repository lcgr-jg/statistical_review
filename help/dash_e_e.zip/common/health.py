"""Shared /health endpoint for dashboards.

Call ``register_health(app, name, extra_checks=…)`` once during initialisation.
The supervisor polls ``/health`` and expects JSON ``{"status": "ok"|"loading"|"error", ...}``.
"""

import os
import time
from datetime import datetime
from typing import Callable, Dict

from flask import jsonify

_START_TIME = time.monotonic()


def register_health(
    app,
    name: str,
    extra_checks: Dict[str, Callable[[], bool]] | None = None,
    ready_flag: "callable | None" = None,
) -> None:
    """Register a /health endpoint on the Dash app's Flask server.

    Parameters
    ----------
    app : dash.Dash
        The dashboard application.
    name : str
        A short identifier returned in the payload (e.g. "stack", "price").
    extra_checks : dict[str, callable], optional
        Named predicates that should return True when the subsystem is healthy.
        Any False / raising check flips the overall status to "error".
    ready_flag : callable, optional
        Predicate returning True once background data loading is complete.
        If None, readiness is assumed as soon as the server is up.
    """
    server = app.server
    extra_checks = extra_checks or {}

    @server.route('/health')
    def _health():
        checks_result = {}
        overall_ok = True
        for label, fn in extra_checks.items():
            try:
                ok = bool(fn())
            except Exception as exc:
                ok = False
                checks_result[f"{label}_error"] = str(exc)[:200]
            checks_result[label] = ok
            if not ok:
                overall_ok = False

        ready = True if ready_flag is None else bool(ready_flag())

        if not overall_ok:
            status = 'error'
        elif not ready:
            status = 'loading'
        else:
            status = 'ok'

        payload = {
            'name': name,
            'status': status,
            'pid': os.getpid(),
            'uptime_s': round(time.monotonic() - _START_TIME, 1),
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'ready': ready,
            'checks': checks_result,
        }
        return jsonify(payload)
