"""Dashboard supervisor.

Responsibilities:
  1. Before launching, kill any process already listening on each target port
     (zombie-process prevention).
  2. Launch each dashboard as a detached subprocess with logs tee'd to disk.
  3. Poll each dashboard's /health endpoint on a fixed cadence.
  4. Auto-restart any dashboard that is either:
       - not listening on its port (crashed)
       - returning non-200 for > fail_threshold consecutive polls
       - stuck in "loading" state for longer than startup_grace_s
       - returning "error" status (one of its checks flipped false)
  5. Cap restart attempts to prevent tight crash loops; fall back to
     exponential back-off.

Usage:
    python -m common.supervisor             # run in foreground, prints status
    python -m common.supervisor --once      # single start + health check, exit
    python -m common.supervisor --stop      # kill all known dashboards & exit

All state is in memory; no external deps beyond stdlib + urllib.
"""

from __future__ import annotations

import argparse
import atexit
import logging
import os
import signal
import socket
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.request import urlopen
from urllib.error import URLError

logger = logging.getLogger('supervisor')

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent  # eu_dashboard_power/

# Use the pst conda env python explicitly so dashboards get blpapi, psycopg2, etc.
DEFAULT_PYTHON = r'C:\Users\stephen.allen\.conda\envs\pst\python.exe'


@dataclass
class DashboardSpec:
    name: str
    port: int
    cwd: Path
    entry: str = 'app.py'
    # How long we allow the app to finish its background loading before we
    # consider a "loading" status a failure and restart.
    startup_grace_s: int = 240
    # How many consecutive failed polls before we trigger a restart.
    fail_threshold: int = 3


# Ports are in the 910x range so the rebuilt legacy dashboards can run
# alongside the original 900x dashboards on the server without colliding.
# Port 9104 is reserved for the EPEX auction results app to keep the x4
# slot consistent with the old layout.
DASHBOARDS: list[DashboardSpec] = [
    DashboardSpec(name='fundamental', port=9101, cwd=BASE_DIR / 'fundamental_dashboard'),
    DashboardSpec(name='price',       port=9103, cwd=BASE_DIR / 'price_dashboard'),
    DashboardSpec(name='stack',       port=9105, cwd=BASE_DIR / 'stack_dashboard'),
]

POLL_INTERVAL_S = 10
HEALTH_TIMEOUT_S = 5
MAX_RESTARTS_PER_HOUR = 6
RESTART_BACKOFF_BASE_S = 5

LOCK_FILE = BASE_DIR / '.supervisor.lock'


# ---------------------------------------------------------------------------
# Runtime state
# ---------------------------------------------------------------------------

@dataclass
class DashboardState:
    spec: DashboardSpec
    proc: Optional[subprocess.Popen] = None
    started_at: float = 0.0
    last_ok_at: float = 0.0
    consecutive_failures: int = 0
    restart_times: list[float] = field(default_factory=list)
    backoff_until: float = 0.0


# ---------------------------------------------------------------------------
# Port / process helpers
# ---------------------------------------------------------------------------

def _pids_on_port(port: int) -> list[int]:
    """Return PIDs of processes currently LISTENING on ``port``.

    Uses ``netstat -ano`` on Windows (no PowerShell cmdlets required).
    """
    try:
        out = subprocess.check_output(
            ['netstat', '-ano', '-p', 'TCP'],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []

    pids: set[int] = set()
    needle = f':{port} '
    for line in out.splitlines():
        if needle not in line or 'LISTENING' not in line:
            continue
        parts = line.split()
        if not parts:
            continue
        try:
            pids.add(int(parts[-1]))
        except ValueError:
            continue
    return sorted(pids)


def _kill_pid(pid: int) -> bool:
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        pass
    # Windows SIGTERM is not graceful; give it a moment then force.
    time.sleep(0.5)
    try:
        subprocess.run(
            ['taskkill', '/F', '/PID', str(pid)],
            check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return False
    return True


def kill_port(port: int) -> int:
    pids = _pids_on_port(port)
    for pid in pids:
        logger.info('killing stale pid=%s on port=%s', pid, port)
        _kill_pid(pid)
    if pids:
        time.sleep(1.0)
    return len(pids)


def port_listening(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        try:
            return s.connect_ex(('127.0.0.1', port)) == 0
        except OSError:
            return False


# ---------------------------------------------------------------------------
# Health polling
# ---------------------------------------------------------------------------

def poll_health(port: int) -> tuple[str, dict]:
    """Return (status, payload).  Status in {'ok','loading','error','unreachable'}."""
    url = f'http://127.0.0.1:{port}/health'
    try:
        with urlopen(url, timeout=HEALTH_TIMEOUT_S) as r:
            import json
            payload = json.loads(r.read().decode('utf-8', errors='replace'))
            return payload.get('status', 'error'), payload
    except URLError:
        return 'unreachable', {}
    except (TimeoutError, socket.timeout):
        return 'unreachable', {}
    except Exception as exc:
        return 'error', {'exception': str(exc)[:200]}


# ---------------------------------------------------------------------------
# Launching
# ---------------------------------------------------------------------------

def launch(state: DashboardState, python: str) -> None:
    spec = state.spec
    log_path = spec.cwd / f'{spec.name}.log'
    err_path = spec.cwd / f'{spec.name}.log.err'

    # Truncate old logs so tails stay readable.
    for p in (log_path, err_path):
        try:
            p.write_bytes(b'')
        except OSError:
            pass

    # CREATE_NEW_PROCESS_GROUP + DETACHED_PROCESS so the child survives when
    # we (the supervisor) exit; also so Ctrl+C in our terminal doesn't tear
    # them down unexpectedly.
    creationflags = 0
    if os.name == 'nt':
        creationflags = (
            subprocess.CREATE_NEW_PROCESS_GROUP
            | getattr(subprocess, 'DETACHED_PROCESS', 0x00000008)
        )

    stdout_f = open(log_path, 'ab', buffering=0)
    stderr_f = open(err_path, 'ab', buffering=0)

    # Propagate the configured port to the child via env var.  Each app.py now
    # reads DASH_PORT (falling back to its historical default) so the supervisor
    # is the single source of truth for what runs where.
    child_env = os.environ.copy()
    child_env['DASH_PORT'] = str(spec.port)
    child_env.setdefault('DASH_HOST', '0.0.0.0')

    proc = subprocess.Popen(
        [python, spec.entry],
        cwd=str(spec.cwd),
        stdout=stdout_f,
        stderr=stderr_f,
        stdin=subprocess.DEVNULL,
        creationflags=creationflags,
        close_fds=True,
        env=child_env,
    )
    state.proc = proc
    state.started_at = time.monotonic()
    state.last_ok_at = 0.0
    state.consecutive_failures = 0
    logger.info('[%s] launched pid=%s port=%s log=%s',
                spec.name, proc.pid, spec.port, log_path)


def start_all(states: list[DashboardState], python: str) -> None:
    for st in states:
        kill_port(st.spec.port)
    for st in states:
        launch(st, python)


def stop_all() -> None:
    for spec in DASHBOARDS:
        n = kill_port(spec.port)
        logger.info('[%s] killed %s process(es) on port %s', spec.name, n, spec.port)
    # Also kill any stray supervisor that another shell may have left behind.
    _kill_other_supervisors()
    _release_lock()


# ---------------------------------------------------------------------------
# Single-instance lock (prevents duplicate supervisors from fighting)
# ---------------------------------------------------------------------------

def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        out = subprocess.check_output(
            ['tasklist', '/FI', f'PID eq {pid}', '/NH', '/FO', 'CSV'],
            text=True, stderr=subprocess.DEVNULL, timeout=5,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return False
    return str(pid) in out


def _acquire_lock() -> None:
    """Ensure only one supervisor runs at a time.

    If a lock file exists and its PID is still alive, refuse to start.
    Otherwise take over the lock (and register release on exit).
    """
    my_pid = os.getpid()
    if LOCK_FILE.exists():
        try:
            other = int(LOCK_FILE.read_text().strip() or '0')
        except ValueError:
            other = 0
        if other and other != my_pid and _pid_alive(other):
            raise SystemExit(
                f'Another supervisor is already running (pid={other}). '
                f'Use --stop first, or delete {LOCK_FILE} if you are sure it is stale.'
            )
    LOCK_FILE.write_text(str(my_pid))
    atexit.register(_release_lock)


def _release_lock() -> None:
    try:
        if LOCK_FILE.exists():
            content = LOCK_FILE.read_text().strip()
            if content == str(os.getpid()):
                LOCK_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _kill_other_supervisors() -> None:
    """Find any python.exe running common.supervisor (except ourselves) and kill.

    Uses PowerShell's CIM interface because wmic is deprecated / removed on
    newer Windows versions.
    """
    my_pid = os.getpid()
    cmd = (
        "Get-CimInstance Win32_Process -Filter \"Name = 'python.exe'\" "
        "| Where-Object { $_.CommandLine -like '*common.supervisor*' } "
        "| Select-Object -ExpandProperty ProcessId"
    )
    try:
        out = subprocess.check_output(
            ['powershell', '-NoProfile', '-NonInteractive', '-Command', cmd],
            text=True, stderr=subprocess.DEVNULL, timeout=10,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return
    for line in out.splitlines():
        line = line.strip()
        if not line.isdigit():
            continue
        pid = int(line)
        if pid and pid != my_pid:
            logger.info('killing stray supervisor pid=%s', pid)
            _kill_pid(pid)


# ---------------------------------------------------------------------------
# Supervisor loop
# ---------------------------------------------------------------------------

def _too_many_restarts(state: DashboardState) -> bool:
    now = time.monotonic()
    state.restart_times = [t for t in state.restart_times if now - t < 3600]
    return len(state.restart_times) >= MAX_RESTARTS_PER_HOUR


def _apply_backoff(state: DashboardState) -> None:
    n = len(state.restart_times)
    delay = min(RESTART_BACKOFF_BASE_S * (2 ** n), 300)
    state.backoff_until = time.monotonic() + delay
    logger.warning('[%s] backing off for %ss (restart #%s this hour)',
                   state.spec.name, delay, n)


def supervise(states: list[DashboardState], python: str) -> None:
    logger.info('supervisor entering main loop; polling every %ss', POLL_INTERVAL_S)
    try:
        while True:
            now = time.monotonic()
            for st in states:
                spec = st.spec

                if now < st.backoff_until:
                    continue

                listening = port_listening(spec.port)
                status, payload = ('unreachable', {})
                if listening:
                    status, payload = poll_health(spec.port)

                age = now - st.started_at

                if status == 'ok':
                    if st.consecutive_failures:
                        logger.info('[%s] recovered after %s failures (uptime=%.0fs)',
                                    spec.name, st.consecutive_failures, age)
                    st.consecutive_failures = 0
                    st.last_ok_at = now
                    continue

                # Still within startup grace?
                if status == 'loading' and age < spec.startup_grace_s:
                    logger.debug('[%s] loading (age=%.0fs)', spec.name, age)
                    continue
                if status == 'unreachable' and age < 30 and st.proc and st.proc.poll() is None:
                    # Process alive but not yet bound to port; give it a moment.
                    continue

                st.consecutive_failures += 1
                logger.warning(
                    '[%s] unhealthy (status=%s age=%.0fs failures=%s) payload=%s',
                    spec.name, status, age, st.consecutive_failures,
                    {k: payload.get(k) for k in ('ready', 'checks') if k in payload},
                )

                should_restart = (
                    st.consecutive_failures >= spec.fail_threshold
                    or (status == 'loading' and age >= spec.startup_grace_s)
                    or (st.proc is not None and st.proc.poll() is not None)
                )
                if not should_restart:
                    continue

                if _too_many_restarts(st):
                    logger.error('[%s] exceeded %s restarts/hour; pausing',
                                 spec.name, MAX_RESTARTS_PER_HOUR)
                    _apply_backoff(st)
                    continue

                logger.warning('[%s] restarting', spec.name)
                st.restart_times.append(now)
                kill_port(spec.port)
                if st.proc is not None and st.proc.poll() is None:
                    try:
                        st.proc.terminate()
                    except OSError:
                        pass
                launch(st, python)
                _apply_backoff(st)

            time.sleep(POLL_INTERVAL_S)
    except KeyboardInterrupt:
        logger.info('supervisor interrupted; leaving dashboards running')


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description='EU dashboard supervisor')
    parser.add_argument('--python', default=DEFAULT_PYTHON,
                        help='Python executable to run each dashboard with')
    parser.add_argument('--once', action='store_true',
                        help='Start dashboards, wait for first health result, exit')
    parser.add_argument('--stop', action='store_true',
                        help='Kill any running dashboards on the configured ports and exit')
    parser.add_argument('--status', action='store_true',
                        help='Report health of each configured dashboard and exit')
    parser.add_argument('--log-level', default='INFO')
    args = parser.parse_args()

    logging.basicConfig(
        level=args.log_level.upper(),
        format='%(asctime)s %(levelname)s %(name)s %(message)s',
        datefmt='%H:%M:%S',
    )

    if args.stop:
        stop_all()
        return 0

    if args.status:
        for spec in DASHBOARDS:
            listening = port_listening(spec.port)
            status, payload = poll_health(spec.port) if listening else ('down', {})
            print(f'{spec.name:<12} port={spec.port} listening={listening} '
                  f'status={status} pid={payload.get("pid","?")} '
                  f'uptime={payload.get("uptime_s","?")}s')
        return 0

    if not Path(args.python).exists():
        logger.error('python executable not found: %s', args.python)
        return 2

    # Kill any stray previous supervisor before taking the lock.
    _kill_other_supervisors()
    _acquire_lock()

    states = [DashboardState(spec=s) for s in DASHBOARDS]
    start_all(states, args.python)

    if args.once:
        time.sleep(POLL_INTERVAL_S)
        for st in states:
            status, _ = poll_health(st.spec.port)
            print(f'{st.spec.name}: {status}')
        return 0

    supervise(states, args.python)
    return 0


if __name__ == '__main__':
    sys.exit(main())
