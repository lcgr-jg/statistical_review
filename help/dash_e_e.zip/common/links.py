"""Cross-dashboard hyperlink helpers.

The three dashboards (fundamental, price, stack) link to one another from the
navbar.  The correct URL depends on *where the app is running*:

* Local dev:  ``http://localhost:PORT``
* Server:     ``http://10.115.0.70:PORT`` (the same host the iframe wrapper
  uses)

To avoid hard-coding the host, each app picks it up from the ``DASH_PUBLIC_HOST``
environment variable.  The ``.sh`` launchers set this to the server IP; local
supervisor runs leave it unset, in which case we fall back to ``localhost``.

Port numbers mirror ``common/supervisor.py``'s DASHBOARDS list and
``jg_eu_commod_dashboard_power_config.yaml``.
"""

import os

PORTS = {
    'fundamental':  9101,
    'price':        9103,
    'epex_auction': 9104,
    'stack':        9105,
    'iberia':       9106,
    'wrapper':      9100,
    'portal':       8071,
}


def public_host() -> str:
    """Host used for cross-dashboard links.

    Override by setting DASH_PUBLIC_HOST (no scheme, no port).  Defaults to
    ``localhost`` which is correct for local development.
    """
    return os.environ.get('DASH_PUBLIC_HOST', 'localhost')


def url_for(name: str, path: str = '/') -> str:
    """Return a fully-qualified URL for another dashboard.

    Example:
        >>> url_for('price')
        'http://localhost:9103/'
    """
    if name not in PORTS:
        raise KeyError(f"unknown dashboard {name!r}; known: {sorted(PORTS)}")
    if not path.startswith('/'):
        path = '/' + path
    return f"http://{public_host()}:{PORTS[name]}{path}"
