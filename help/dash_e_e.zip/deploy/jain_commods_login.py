# This file is copied into the installed jain_commods package inside the
# Docker image (see Dockerfile). jain_commods/core/interfaces/snowflake/
# _credentials.py looks for `from ....login import snowflake_login` first
# and only falls back to env vars if that import fails.
#
# The corelib conda env on dev machines has this file present locally
# (gitignored in eu_corelib). In the container, the wheel built by CI does
# NOT include it, so we inject it here so EEXQuery() just works.
#
# WARNING: contains secrets. This file is committed to the private
# eu_dashboard_power repo only. Do NOT copy elsewhere.


# SQL logins
############
# (unused by the dashboard, but kept for compatibility with jain_commods
# modules that import from jain_commods.login)
dev_login = {
    "host": "tech1-rdsdb-dev-2.cluster-c9ie8ooy8h3p.us-east-1.rds.amazonaws.com",
    "dbname": "postgres",
    "username": "svc_commod_research",
    "password": "WFg#55$2ugiUUW",
    "port": 5432,
}

uat_login = {
    "host": "tech1-rdsdb-dev-1.cluster-c9ie8ooy8h3p.us-east-1.rds.amazonaws.com",
    "dbname": "postgres",
    "username": "svc_commod_research",
    "password": "Moib44xbMBoepRUvBXD6",
    "port": 5432,
}

prod_login = {
    "host": "tech1-rdsdb-prod-1.cluster-cfkie8cke8ry.us-east-1.rds.amazonaws.com",
    "dbname": "postgres",
    "username": "svc_commod_research",
    "password": "F8XdmytaKB8DBNxa3XYn",
    "port": 5432,
}

default_login = dev_login


# Snowflake login (this is the one the dashboard needs)
# *****************
snowflake_login = {
    "account": "byb06077.us-east-1",
    "username": "SVC_EU_COMMOD_RESEARCH",
    "keyfilepass": "2eeM9HWxPjMEevAbEhbG",
}


# Other logins
##############
kplerlogin = {
    "api_user": "john.morley@jainglobal.com",
    "api_pw": "Knockers99!",
    "logintype": "prod",
}

aws_creds = {
    "access_key": "AKIAW3MEDJOC4TNRABOU",
    "secret_key": "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",
}
