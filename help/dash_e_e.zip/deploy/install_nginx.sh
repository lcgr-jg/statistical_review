#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <server_name> [app_port]"
  echo "Example: $0 dashboard.company.com 8071"
  exit 1
fi

SERVER_NAME="$1"
APP_PORT="${2:-8071}"
SITE_NAME="${SITE_NAME:-eu-dashboard}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATE="${SCRIPT_DIR}/nginx-eu-dashboard.conf.template"
TMP_CONF="$(mktemp)"

sed \
  -e "s|__SERVER_NAME__|${SERVER_NAME}|g" \
  -e "s|__APP_PORT__|${APP_PORT}|g" \
  "${TEMPLATE}" > "${TMP_CONF}"

echo "Installing nginx config for ${SITE_NAME}..."
sudo install -m 0644 "${TMP_CONF}" "/etc/nginx/sites-available/${SITE_NAME}"
sudo ln -sfn "/etc/nginx/sites-available/${SITE_NAME}" "/etc/nginx/sites-enabled/${SITE_NAME}"

if [[ -f /etc/nginx/sites-enabled/default ]]; then
  echo "Disabling default nginx site..."
  sudo rm -f /etc/nginx/sites-enabled/default
fi

sudo nginx -t
sudo systemctl reload nginx

echo
echo "Nginx configured. Next step (TLS):"
echo "  sudo certbot --nginx -d ${SERVER_NAME}"

rm -f "${TMP_CONF}"

