#!/bin/bash
# Server launcher for the Fundamentals Dashboard (port 9101).
# Mirrors the pattern used by jg_eu_commod_dashboard_power.sh / _lng.sh.
#
# Ports moved from the 9001/9003/9005 range (used by the legacy app.sh
# launchers) to 910x so the rebuilt dashboards can run alongside the old
# ones without colliding.

SCRIPT_DIR="$(dirname "$(realpath "$0")")"
APP_DIR="$SCRIPT_DIR"
LOG_DIR="$APP_DIR/log"
LOG_FILE="$LOG_DIR/fundamental_dashboard.log"

export DASH_PORT=9101
export DASH_HOST=0.0.0.0
export DASH_PRODUCTION=1
export DASH_PUBLIC_HOST=10.115.0.70   # used by navbar links between dashboards

# Dash 3.x reads PORT/HOST from the env and will silently override
# app.run(port=...).  Clear them so DASH_PORT/DASH_HOST win.
unset PORT
unset HOST

# The server has a broken tz config (/etc/sysconfig/clock says UTC,
# /etc/localtime symlinks to America/New_York).  tzlocal refuses to
# guess, and energyquantified imports it eagerly, so we must set TZ
# explicitly.  UTC matches the *_utc columns in Postgres and how the
# dashboards already treat timestamps internally.
export TZ=UTC

# jain_commods.core.cache.utils.eq reads EQ_API_KEY, but the server-side
# secret is exported as EQ_API.  Bridge the two so the EQ client can
# authenticate without needing us to rename the server-side variable.
export EQ_API_KEY="${EQ_API_KEY:-$EQ_API}"

mkdir -p "$LOG_DIR"
START_CMD="python $APP_DIR/app.py >> $LOG_FILE 2>&1 &"

setup_micromamba() {
    # >>> mamba initialize >>>
    export MAMBA_EXE='/jfs/tools/conda/exec/micromamba';
    export MAMBA_ROOT_PREFIX='/jfs/commod/conda/';
    __mamba_setup="$("$MAMBA_EXE" shell hook --shell bash --root-prefix "$MAMBA_ROOT_PREFIX" 2> /dev/null)"
    if [ $? -eq 0 ]; then
        eval "$__mamba_setup"
    else
        alias micromamba="$MAMBA_EXE"
    fi
    unset __mamba_setup
    # <<< mamba initialize <<<

    micromamba activate commod-24.11.1
    echo "$(date "+%Y-%m-%d %H:%M:%S") : micromamba commod-24.11.1 activated."
}

if pgrep -f "python $APP_DIR/app.py" > /dev/null; then
    echo "$(date "+%Y-%m-%d %H:%M:%S") : Fundamental DashApp is already running."
elif [ -e stop ]; then
    echo "$(date "+%Y-%m-%d %H:%M:%S") : stop file exists. will not start service."
else
    echo "$(date "+%Y-%m-%d %H:%M:%S") : Fundamental DashApp not running. Starting..."
    cd "$APP_DIR"
    setup_micromamba
    eval "$START_CMD"
fi
