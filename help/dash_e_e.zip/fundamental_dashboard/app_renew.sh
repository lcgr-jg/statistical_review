#!/bin/bash

# Get the directory of the current script
SCRIPT_DIR="$(dirname "$(realpath "$0")")"

# Paths to the scripts
PYTHON_SCRIPT="$SCRIPT_DIR/app.py"
SHELL_SCRIPT="$SCRIPT_DIR/app.sh"

# Log file path
LOG_FILE="$SCRIPT_DIR/log/cron.log"

echo "Restarting fundamentals job at $(date)" >> $LOG_FILE

# Find and kill the running Python process for the job
echo "Stopping current process..." >> $LOG_FILE
PROCESS_ID=$(ps aux | grep "$PYTHON_SCRIPT" | grep -v grep | awk '{print $2}')

if [ -n "$PROCESS_ID" ]; then
    kill -9 $PROCESS_ID
    echo "Process $PROCESS_ID killed." >> $LOG_FILE
else
    echo "No running process found for $PYTHON_SCRIPT." >> $LOG_FILE
fi

# Wait for a second
sleep 1

# Restart the job
echo "Restarting fundamentals_dashboard job: " >> $LOG_FILE
bash "$SHELL_SCRIPT" >> $LOG_FILE 2>&1 &

echo "fundamentals_dashboard Job restarted successfully at $(date)" >> $LOG_FILE
