import dash
from dash import html, dcc, Input, Output
import dash_bootstrap_components as dbc
import logging
import atexit
import gc
import sys
import os
import pathlib
import time
import threading

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import install_theme_css, register_health  # noqa: E402

from utils.data_handler import DataHandler

# Check if memory profiling is enabled via environment variable
ENABLE_MEMORY_PROFILING = os.getenv('ENABLE_MEMORY_PROFILING', 'false').lower() == 'true'

try:
    import psutil
    if not ENABLE_MEMORY_PROFILING:
        psutil = None  # Disable even if installed
except ImportError:
    logging.warning("psutil not available for memory profiling. Install with 'pip install psutil'")
    psutil = None

# Try to import plotly for figure cleanup
try:
    import plotly.graph_objects as go
except ImportError:
    logging.warning("plotly not available directly - assuming it's installed via dash")

# Set up logging - REDUCE VERBOSITY
logging.basicConfig(level=logging.WARNING)  # Change from INFO to WARNING

# Silence noisy loggers
logging.getLogger('watchdog').setLevel(logging.ERROR)  # Silence watchdog debug messages
logging.getLogger('snowflake.connector').setLevel(logging.ERROR)
logging.getLogger('urllib3').setLevel(logging.ERROR)
logging.getLogger('matplotlib').setLevel(logging.ERROR)
logging.getLogger('PIL').setLevel(logging.ERROR)
logging.getLogger('numba').setLevel(logging.ERROR)
logging.getLogger('asyncio').setLevel(logging.ERROR)
logging.getLogger('parso').setLevel(logging.ERROR)
logging.getLogger('boto3').setLevel(logging.ERROR)
logging.getLogger('botocore').setLevel(logging.ERROR)
logging.getLogger('s3transfer').setLevel(logging.ERROR)
logging.getLogger('filelock').setLevel(logging.ERROR)

# Keep application loggers at INFO level (not DEBUG)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)  # Change from DEBUG to INFO
logging.getLogger('utils').setLevel(logging.INFO)  # Change from DEBUG to INFO
logging.getLogger('pages').setLevel(logging.INFO)  # Change from DEBUG to INFO

# Initialize data handler
data_handler = DataHandler(defer_loading=True)

# Add memory profiling (conditional based on environment variable)
def profile_memory_usage(label=""):
    """Profile memory usage of the current process (only if enabled)"""
    if not ENABLE_MEMORY_PROFILING or not psutil:
        return {}
    
    memory_info = {}
    
    # Get memory info from psutil if available
    if psutil:
        try:
            process = psutil.Process(os.getpid())
            memory_info["rss_mb"] = process.memory_info().rss / (1024 * 1024)
            memory_info["vms_mb"] = process.memory_info().vms / (1024 * 1024)
            
            # Add more detailed memory info
            memory_info["percent"] = process.memory_percent()
            
            # Get memory maps for detailed analysis
            try:
                memory_maps = process.memory_maps()
                total_private = sum(m.private for m in memory_maps if hasattr(m, 'private'))
                memory_info["private_mb"] = total_private / (1024 * 1024)
            except:
                # memory_maps may not be available on all platforms
                pass
        except Exception as e:
            logger.error(f"Error getting memory info: {str(e)}")
    
    logger.info(f"Memory usage {label}: {memory_info}")
    return memory_info

# Add function to clear plotly figure cache
def clear_plotly_figure_cache():
    """Clear plotly figure cache to free memory"""
    try:
        # Try to clear the plotly figure cache
        if 'go' in globals():
            # This is a workaround to clear internal plotly caches
            fig = go.Figure()
            fig.data = []
            fig.layout = {}
            del fig
    except Exception as e:
        logger.error(f"Error clearing plotly figure cache: {str(e)}")

# Enhanced memory cleanup function
def perform_memory_cleanup():
    """Perform comprehensive memory cleanup"""
    logger.info("Starting comprehensive memory cleanup")
    profile_memory_usage("before cleanup")
    
    # Clear data handler cache
    if data_handler is not None:
        logger.info("Cleaning data handler caches")
        data_handler.clear_cache()
    
    # Clean up weather data handler if it exists
    try:
        weather_handler = get_weather_data_handler()
        if weather_handler is not None:
            logger.info("Cleaning weather data handler caches")
            if hasattr(weather_handler, 'cleanup_old_caches'):
                weather_handler.cleanup_old_caches()
            elif hasattr(weather_handler, 'clear_caches'):
                weather_handler.clear_caches()
    except Exception as e:
        logger.error(f"Error cleaning up weather handler: {str(e)}")
    
    # Clear plotly figure cache
    clear_plotly_figure_cache()
    
    # Force multiple garbage collections to ensure memory is freed
    for i in range(3):
        gc.collect()
        time.sleep(0.1)  # Small delay to allow OS to reclaim memory
    
    profile_memory_usage("after cleanup")
    logger.info("Comprehensive memory cleanup completed")

# Initialize the Dash app
app = dash.Dash(
    __name__,
    suppress_callback_exceptions=True,
    external_stylesheets=[
        dbc.themes.BOOTSTRAP,
        dbc.icons.FONT_AWESOME,
        "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",
    ],
    title="Fundamentals Dashboard",
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}]
)

install_theme_css(app)

_bg_ready = threading.Event()

# Dev tools completely disabled in production to avoid polling overhead
app.enable_dev_tools(
    debug=False,
    dev_tools_ui=False,
    dev_tools_props_check=False,
    dev_tools_serve_dev_bundles=False,
    dev_tools_hot_reload=False,
    dev_tools_silence_routes_logging=True,
    dev_tools_prune_errors=True,
)

# Set the app layout
app.layout = html.Div([
    # Store to maintain app state
    dcc.Store(id='app-state', data={'days': 180}),
    
    # URL routing
    dcc.Location(id='url', refresh=False),
    
    # Main content container
    html.Div(id='page-content'),
    
    # Data refresh trigger
    html.Div(id='data-refresh-trigger', style={'display': 'none'}),
    
    # One-shot interval for initial data load only (fires once then stops)
    dcc.Interval(
        id='display-interval',
        interval=2000,
        n_intervals=0,
        max_intervals=1,
    ),
    
    # Memory cleanup disabled — use manual refresh buttons instead
    dcc.Interval(
        id='memory-cleanup-interval',
        interval=10*60*1000,
        n_intervals=0,
        disabled=True,
    ),
    
    # Loading data indicator
    dcc.Loading(
        id="loading-data",
        type="circle",
        children=[html.Div(id="loading-data-trigger")]
    )
])

# Import pages after app initialization to avoid circular imports
from pages.home import register_home_callbacks, get_layout as get_home_layout
from pages.availability import register_availability_callbacks, get_layout as get_availability_layout
from pages.generation_vs_availability import register_generation_callbacks, get_layout as get_generation_layout
from pages.weather_forecast import register_weather_forecast_callbacks, get_layout as get_weather_forecast_layout, get_weather_data_handler
from pages.forecast_comparison import register_forecast_comparison_callbacks, get_layout as get_forecast_comparison_layout

# URL routing callback
@app.callback(
    Output('page-content', 'children'),
    [Input('url', 'pathname')]
)
def display_page(pathname):
    if pathname == '/availability':
        return get_availability_layout(data_handler)
    elif pathname == '/generation-vs-availability':
        return get_generation_layout(data_handler)
    elif pathname == '/weather-forecast':
        return get_weather_forecast_layout(data_handler)
    elif pathname == '/forecast-comparison':
        return get_forecast_comparison_layout(data_handler)
    else:
        return get_home_layout(data_handler)

# No-op callback for the interval (data loads in background thread at startup)
@app.callback(
    Output('loading-data-trigger', 'children'),
    [Input('display-interval', 'n_intervals')]
)
def load_data_after_start(n_intervals):
    return html.Div()


def _background_load_all():
    """Load all data in a background thread so pages are never blocked."""
    import time as _t
    t0 = _t.time()
    try:
        data_handler.ready()
        data_handler.set_schedule_time(minutes=30)
        logger.info("Availability/generation ready in %.1fs", _t.time() - t0)
    except Exception as exc:
        logger.error("Background data load failed: %s", exc, exc_info=True)

    try:
        t1 = _t.time()
        weather_handler = get_weather_data_handler()
        weather_handler.initialize()
        weather_handler.set_schedule_times([
            {'hour': 6, 'minute': 30},
            {'hour': 16, 'minute': 0},
            {'hour': 19, 'minute': 0},
        ])
        logger.info("Weather data ready in %.1fs", _t.time() - t1)
    except Exception as exc:
        logger.error("Weather data load failed: %s", exc, exc_info=True)

    logger.info("All background loading done in %.1fs", _t.time() - t0)
    _bg_ready.set()


_bg_thread = threading.Thread(target=_background_load_all, daemon=True)
_bg_thread.start()

register_health(app, name='fundamental', ready_flag=_bg_ready.is_set)

# Register callbacks for each page
register_home_callbacks(app, data_handler)
register_availability_callbacks(app, data_handler)
register_generation_callbacks(app, data_handler)
register_weather_forecast_callbacks(app, data_handler)
register_forecast_comparison_callbacks(app, data_handler)

# Add a callback for memory cleanup
@app.callback(
    Output('memory-cleanup-interval', 'disabled'),
    [Input('memory-cleanup-interval', 'n_intervals')]
)
def clean_memory(n_intervals):
    """Disabled — manual refresh buttons handle cache invalidation."""
    return True  # Keep interval disabled

# Create a shutdown handler
def shutdown_handlers():
    """Clean up all handlers and threads when application exits"""
    logger.info("Application shutting down - cleaning up handlers")
    
    # Profile memory before shutdown
    profile_memory_usage("before shutdown")
    
    # Clean up data handler
    if data_handler is not None:
        logger.info("Cleaning up data handler")
        data_handler.clear_cache()
    
    # Shut down the weather data handler
    try:
        # Get the weather handler using the function
        weather_handler = get_weather_data_handler()
        if weather_handler is not None:
            logger.info("Shutting down weather data handler")
            if hasattr(weather_handler, 'shutdown'):
                weather_handler.shutdown()
            
            # Clear weather caches
            if hasattr(weather_handler, 'clear_caches'):
                weather_handler.clear_caches()
    except Exception as e:
        logger.error(f"Error shutting down weather handler: {str(e)}")
    
    # Clear plotly figure cache
    clear_plotly_figure_cache()
    
    # Force multiple garbage collections to ensure memory is freed
    for i in range(3):
        gc.collect()
        time.sleep(0.1)  # Small delay to allow OS to reclaim memory
    
    # Profile memory after shutdown
    profile_memory_usage("after shutdown")
    
    logger.info("Shutdown complete")

# Register the shutdown handler
atexit.register(shutdown_handlers)

if __name__ == '__main__':
    logger.info("Starting the Fundamentals Dashboard...")
    profile_memory_usage("at startup")
    logger.info("App will be available almost immediately; data will load in the background")

    # Port is read from the DASH_PORT env var so the same script works locally
    # and on the Linux server without editing code.  Fall back to 9101 to match
    # fundamental_dashboard.sh (the legacy app.sh launcher uses 9001).
    port = int(os.environ.get('DASH_PORT', '9101'))
    host = os.environ.get('DASH_HOST', '0.0.0.0')

    # In production (set DASH_PRODUCTION=1) use waitress, matching the LNG
    # dashboard's deployment pattern.  Locally, fall back to the Dash dev server.
    if os.environ.get('DASH_PRODUCTION', '').lower() in ('1', 'true', 'yes'):
        from waitress import serve
        logger.info('Serving via waitress on %s:%s (production mode)', host, port)
        serve(app.server, host=host, port=port, threads=int(os.environ.get('DASH_THREADS', '8')))
    else:
        app.run(debug=False, host=host, port=port, use_reloader=False)