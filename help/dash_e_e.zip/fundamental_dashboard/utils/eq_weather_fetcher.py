"""
EQ-backed weather/forecast data fetcher.

Replaces the Meteologica/Snowflake-backed fetching with calls to the
Energy Quantified API.  Returns data in the same tuple format that
weather_data_processor.fetch_forecast_data() used to return so the
downstream processing + plotting pipeline needs no changes.

Source → EQ tag mapping
-----------------------
  ECMWF-ENS  → tag "ec-ens"   (ensemble, ~51 members)
  ECMWF-HRES → tag "ec"       (deterministic / control run)
  GEFS       → tag "gfs-ens"  (ensemble, ~31 members)
  Normals    → built from the "ec" climatology (AVERAGE only)
  Meteologica→ dropped (no EQ equivalent; use "ecsr" as replacement)
"""

import logging
from datetime import datetime, timedelta, date, time as _time
from typing import List, Tuple, Optional

import numpy as np
import pandas as pd

from utils.eq_client import get_eq_client
from jain_commods.core.interfaces.energyquantified.curves import (
    GENERATION_FORECAST, DEMAND_FORECAST,
    GENERATION_NORMAL, DEMAND_NORMAL,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Country ↔ EQ area mapping  (full names used by weather pages)
# ---------------------------------------------------------------------------
_COUNTRY_TO_AREA = {
    'Germany': 'DE', 'France': 'FR', 'UK': 'GB',
    'Netherlands': 'NL', 'Belgium': 'BE', 'Spain': 'ES',
}

# Variable → curve lookup (forecasts)
_VARIABLE_CURVE = {
    'Wind':        lambda area: GENERATION_FORECAST.get(area, {}).get('wind'),
    'PV':          lambda area: GENERATION_FORECAST.get(area, {}).get('solar'),
    'PowerDemand': lambda area: DEMAND_FORECAST.get(area),
}

# Variable → curve lookup (climate normals — different EQ timeseries curves)
_VARIABLE_NORMAL_CURVE = {
    'Wind':        lambda area: GENERATION_NORMAL.get(area, {}).get('wind'),
    'PV':          lambda area: GENERATION_NORMAL.get(area, {}).get('solar'),
    'PowerDemand': lambda area: DEMAND_NORMAL.get(area),
}

# Source → (EQ tag, ensemble?)
_SOURCE_TAG = {
    'ECMWF-ENS':  ('ec-ens',  True),
    'ECMWF-HRES': ('ec',      False),
    'GEFS':        ('gfs-ens', True),
    'Normals':     ('ec',      False),
    'Meteologica': ('ecsr',    False),
}


def _issued_from_date_release(d, release: str) -> datetime:
    """Convert a (date, release) pair to a timezone-aware UTC datetime."""
    from energyquantified.time import UTC
    if isinstance(d, str):
        d = pd.to_datetime(d).date()
    elif hasattr(d, 'date'):
        d = d.date()
    return datetime(d.year, d.month, d.day, int(release), 0, tzinfo=UTC)


def _strip_tz(idx: pd.DatetimeIndex) -> pd.DatetimeIndex:
    """Remove timezone info so downstream pipeline gets naive datetimes."""
    if hasattr(idx, 'tz') and idx.tz is not None:
        return idx.tz_localize(None)
    return idx


def _eq_ensemble_to_df(raw_df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert an EQ ensemble DataFrame (MultiIndex columns) into the flat
    format the existing processing pipeline expects:
        FROM_DATETIME | AVERAGE | BOTTOM | TOP | ENS1 | ENS2 | …
    """
    if raw_df.empty:
        return pd.DataFrame()

    cols = raw_df.columns
    if isinstance(cols, pd.MultiIndex):
        members = [c for c in cols if c[-1].startswith('e')]
        control = [c for c in cols if c[-1] == '']
    else:
        members = [c for c in cols if str(c).startswith('e')]
        control = [c for c in cols if str(c) == '']

    timestamps = _strip_tz(raw_df.index)
    out = pd.DataFrame()
    out['FROM_DATETIME'] = timestamps

    if members:
        member_data = raw_df[members].copy()
        member_data.columns = [f'ENS{i+1}' for i in range(len(members))]
        member_data = member_data.reset_index(drop=True)
        for c in member_data.columns:
            out[c] = member_data[c].astype('float32')
        out['AVERAGE'] = member_data.mean(axis=1).astype('float32')
        out['BOTTOM'] = member_data.min(axis=1).astype('float32')
        out['TOP'] = member_data.max(axis=1).astype('float32')
    elif control:
        vals = raw_df[control[0]].reset_index(drop=True).astype('float32')
        out['AVERAGE'] = vals
        out['BOTTOM'] = vals
        out['TOP'] = vals
    else:
        vals = raw_df.iloc[:, 0].reset_index(drop=True).astype('float32')
        out['AVERAGE'] = vals
        out['BOTTOM'] = vals
        out['TOP'] = vals

    return out


def _eq_deterministic_to_df(raw_df: pd.DataFrame) -> pd.DataFrame:
    """Convert a single-column EQ forecast into FORECAST-column format."""
    if raw_df.empty:
        return pd.DataFrame()
    out = pd.DataFrame()
    out['FROM_DATETIME'] = _strip_tz(raw_df.index)
    out['FORECAST'] = raw_df.iloc[:, 0].reset_index(drop=True).astype('float32')
    return out


def _eq_normal_to_df(raw_df: pd.DataFrame) -> pd.DataFrame:
    """Convert a single-column EQ forecast into NORMAL-column format."""
    if raw_df.empty:
        return pd.DataFrame()
    out = pd.DataFrame()
    out['FROM_DATETIME'] = _strip_tz(raw_df.index)
    out['NORMAL'] = raw_df.iloc[:, 0].reset_index(drop=True).astype('float32')
    return out


ResultTuple = Tuple[str, str, str, object, str, pd.DataFrame]


def fetch_eq_forecast_data(
    source: str,
    countries: list,
    variables: list,
    dates: list,
    releases: list,
) -> List[ResultTuple]:
    """
    Replacement for ``weather_data_processor.fetch_forecast_data``.

    Fetches forecast data from Energy Quantified for a single *source*,
    for every (country, variable, date, release) combination and returns
    results in the same tuple format the downstream pipeline expects.

    For the 'Normals' source, fetches proper EQ climate normal timeseries
    (not forecast instances) covering the same date range as the forecasts.
    """
    tag_info = _SOURCE_TAG.get(source)
    if tag_info is None:
        logger.warning("Unknown source %s – returning empty results", source)
        return _empty_results(source, countries, variables, dates, releases)

    tag, is_ensemble = tag_info
    client = get_eq_client()

    results: List[ResultTuple] = []

    # Normals are timeseries (not forecast instances) — fetch once per
    # country/variable with a date range covering today → +15 days, and
    # return the result under the first date/release slot.
    if source == 'Normals':
        d0 = dates[0]
        r0 = releases[0]
        for country in countries:
            area = _COUNTRY_TO_AREA.get(country)
            if area is None:
                logger.warning("No EQ area for country %s", country)
                for v in variables:
                    results.append((source, country, v, d0, r0, pd.DataFrame()))
                continue

            for variable in variables:
                curve_fn = _VARIABLE_NORMAL_CURVE.get(variable)
                curve = curve_fn(area) if curve_fn else None
                if not curve:
                    logger.warning("No EQ Normal curve for %s/%s", country, variable)
                    results.append((source, country, variable, d0, r0, pd.DataFrame()))
                    continue

                try:
                    df = _fetch_normal(client, curve)
                    logger.info("Normal %s/%s/%s: %d rows", country, variable, curve, len(df))
                except Exception as exc:
                    logger.error("EQ Normal fetch %s/%s: %s", country, variable, exc, exc_info=True)
                    df = pd.DataFrame()

                results.append((source, country, variable, d0, r0, df))
        return results

    # All other sources: forecast instances per (date, release)
    for country in countries:
        area = _COUNTRY_TO_AREA.get(country)
        if area is None:
            logger.warning("No EQ area for country %s", country)
            results.extend(_empty_for_country(source, country, variables, dates, releases))
            continue

        for variable in variables:
            curve_fn = _VARIABLE_CURVE.get(variable)
            curve = curve_fn(area) if curve_fn else None
            if not curve:
                logger.warning("No EQ curve for %s/%s/%s", source, country, variable)
                for d in dates:
                    for r in releases:
                        results.append((source, country, variable, d, r, pd.DataFrame()))
                continue

            for d in dates:
                for release in releases:
                    if _should_skip_release(d, release):
                        results.append((source, country, variable, d, release, pd.DataFrame()))
                        continue

                    issued = _issued_from_date_release(d, release)
                    version_key = f"{d}_{release}" if isinstance(d, str) else f"{d.strftime('%Y-%m-%d') if hasattr(d, 'strftime') else d}_{release}"

                    try:
                        if is_ensemble:
                            df = _fetch_ensemble(client, curve, tag, issued)
                        else:
                            df = _fetch_deterministic(client, curve, tag, issued)
                    except Exception as exc:
                        logger.warning("EQ fetch %s/%s/%s %s: %s", source, country, variable, version_key, exc)
                        df = pd.DataFrame()

                    results.append((source, country, variable, d, release, df))

    return results


# ---------------------------------------------------------------------------
# Internal fetch helpers
# ---------------------------------------------------------------------------

def _fetch_ensemble(client, curve: str, tag: str, issued: datetime) -> pd.DataFrame:
    raw = client.get_forecast(curve, issued=issued, tag=tag, ensembles=True, frequency='PT1H')
    return _eq_ensemble_to_df(raw)


def _fetch_deterministic(client, curve: str, tag: str, issued: datetime) -> pd.DataFrame:
    raw = client.get_forecast(curve, issued=issued, tag=tag, frequency='PT1H')
    return _eq_deterministic_to_df(raw)


def _fetch_normal(client, curve: str) -> pd.DataFrame:
    """Fetch true EQ climate normals for the next 15 days via get_normal()."""
    from datetime import date as _date
    begin = _date.today()
    end = begin + timedelta(days=15)
    raw = client.get_normal(curve, begin=begin, end=end, frequency='PT1H')
    return _eq_normal_to_df(raw)


def _should_skip_release(d, release: str) -> bool:
    current_hour = datetime.now().hour
    current_date = datetime.now().date()
    if hasattr(d, 'date'):
        cmp = d.date()
    elif isinstance(d, str):
        cmp = pd.to_datetime(d).date()
    else:
        cmp = d
    return release == "12" and cmp == current_date and current_hour < 19


def _empty_results(source, countries, variables, dates, releases):
    out = []
    for c in countries:
        for v in variables:
            for d in dates:
                for r in releases:
                    out.append((source, c, v, d, r, pd.DataFrame()))
    return out


def _empty_for_country(source, country, variables, dates, releases):
    out = []
    for v in variables:
        for d in dates:
            for r in releases:
                out.append((source, country, v, d, r, pd.DataFrame()))
    return out
