"""
Shared styling constants for the Fundamentals Dashboard.

Mirrors the color scheme and visual language of the Fuel Switching dashboard
for a consistent look across all power dashboard pages.
"""

# ---------------------------------------------------------------------------
# Color palette (shared across all dashboards)
# ---------------------------------------------------------------------------
from core.styles import COLORS

# Fuel-type specific colors (warm, professional palette)
FUEL_COLORS = {
    'nuclear': '#d4a017',
    'fossil gas': '#2171b5',
    'fossil hard coal': '#6c757d',
    'fossil brown coal/lignite': '#a0522d',
    'biomass': '#2ea043',
    'fossil oil': '#8b0000',
    'waste': '#7b9e3a',
    'geothermal': '#c94a2e',
    'other': '#808080',
}

# Secondary / lighter versions for fills
FUEL_FILLS = {k: f'rgba({int(v[1:3],16)},{int(v[3:5],16)},{int(v[5:7],16)},0.18)'
              for k, v in FUEL_COLORS.items()}

CHART_TEMPLATE = 'plotly_white'
CHART_FONT = 'Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif'

# ---------------------------------------------------------------------------
# Chart helper
# ---------------------------------------------------------------------------

def apply_chart_style(fig, height=500, show_rangeslider=False):
    """Apply the unified chart styling to any Plotly figure."""
    fig.update_layout(
        template=CHART_TEMPLATE,
        paper_bgcolor=COLORS['card_bg'],
        plot_bgcolor=COLORS['chart_bg'],
        margin=dict(l=60, r=30, t=40, b=50),
        font=dict(family=CHART_FONT, color=COLORS['text_secondary'], size=12),
        height=height,
        xaxis=dict(gridcolor='#e8e6e1', automargin=True),
        yaxis=dict(gridcolor='#e8e6e1', automargin=True),
        legend=dict(
            orientation='h',
            yanchor='bottom', y=1.02,
            xanchor='right', x=1,
            bgcolor='rgba(250,249,246,0.95)',
            font=dict(size=11),
        ),
        hovermode='x unified',
        hoverlabel=dict(
            bgcolor='#ffffff',
            bordercolor=COLORS['border'],
            font=dict(color=COLORS['text_primary']),
        ),
    )
    if show_rangeslider:
        fig.update_xaxes(rangeslider=dict(visible=True))
    return fig


def styled_empty_figure(message='No data available', height=400):
    """Return a nicely styled empty / placeholder figure."""
    import plotly.graph_objects as go
    fig = go.Figure()
    fig.add_annotation(
        text=message, xref='paper', yref='paper',
        x=0.5, y=0.5, showarrow=False,
        font=dict(size=14, color=COLORS['text_muted'],
                  family=CHART_FONT),
    )
    fig.update_layout(
        template=CHART_TEMPLATE,
        paper_bgcolor=COLORS['card_bg'],
        plot_bgcolor=COLORS['chart_bg'],
        font=dict(family=CHART_FONT, color=COLORS['text_secondary']),
        height=height,
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
    )
    return fig


# ---------------------------------------------------------------------------
# Reusable style dicts
# ---------------------------------------------------------------------------

CARD_STYLE = {
    'backgroundColor': '#ffffff',
    'border': '1px solid #e1e4e8',
    'borderRadius': '12px',
    'marginBottom': '16px',
    'boxShadow': '0 1px 3px rgba(0,0,0,0.04)',
    'overflow': 'hidden',
}

CONTROL_PANEL_STYLE = {
    'backgroundColor': '#ffffff',
    'padding': '20px 24px',
    'borderRadius': '12px',
    'border': '1px solid #e1e4e8',
    'marginBottom': '20px',
    'boxShadow': '0 1px 3px rgba(0,0,0,0.04)',
}

LABEL_STYLE = {
    'fontSize': '12px',
    'fontWeight': '600',
    'color': '#6c757d',
    'marginBottom': '6px',
    'display': 'block',
}

CARD_HEADER_STYLE = {
    'padding': '14px 20px',
    'borderBottom': '1px solid #eaecef',
    'backgroundColor': '#ffffff',
}

CARD_HEADER_TEXT_STYLE = {
    'fontSize': '14px',
    'fontWeight': '600',
    'color': '#231F20',
    'textTransform': 'uppercase',
    'letterSpacing': '0.5px',
    'margin': '0',
}

REFRESH_BTN_STYLE = {
    'padding': '8px 18px',
    'backgroundColor': '#4E738A',
    'color': '#ffffff',
    'border': 'none',
    'borderRadius': '6px',
    'fontSize': '13px',
    'fontWeight': '600',
    'cursor': 'pointer',
    'transition': 'all 0.2s',
}

STATUS_BADGE_OK = {
    'display': 'inline-block',
    'padding': '6px 12px',
    'borderRadius': '20px',
    'fontSize': '12px',
    'fontWeight': '500',
    'backgroundColor': '#e6f4ea',
    'color': '#2ea043',
    'border': '1px solid rgba(46, 160, 67, 0.3)',
}

STATUS_BADGE_LOADING = {
    'display': 'inline-block',
    'padding': '6px 12px',
    'borderRadius': '20px',
    'fontSize': '12px',
    'fontWeight': '500',
    'backgroundColor': 'rgba(210,153,34,0.1)',
    'color': '#b08800',
    'border': '1px solid rgba(210,153,34,0.3)',
}

# ---------------------------------------------------------------------------
# CSS injected into the page via html.Style
# ---------------------------------------------------------------------------

FUNDAMENTALS_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background-color: #f5f6f8;
    color: #231F20;
}

/* ---------- Dropdown ---------- */
.Select-control {
    background-color: #ffffff !important;
    border-color: #e1e4e8 !important;
    border-radius: 6px !important;
    height: 38px !important;
}
.Select-control:hover { border-color: #4E738A !important; }
.Select-menu {
    background-color: #ffffff !important;
    border-radius: 6px !important;
}
.Select-value-label, .Select-placeholder { color: #231F20 !important; }
.Select-option { 
    padding: 8px 12px !important; 
    line-height: 1.4 !important;
    color: #231F20 !important;
}
.Select-menu-outer {
    border: 1px solid #e1e4e8 !important;
    border-radius: 6px !important;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
    z-index: 1000 !important;
}
.Select-option.is-focused { background-color: #f4f5f7 !important; }
.Select-option.is-selected {
    background-color: #4E738A !important;
    color: #ffffff !important;
}

/* ---------- Buttons ---------- */
button:hover {
    opacity: 0.92;
    transform: translateY(-1px);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

/* ---------- Bootstrap tab override ---------- */
.nav-tabs {
    border-bottom: 2px solid #e1e4e8 !important;
    background-color: transparent !important;
}
.nav-tabs .nav-link {
    color: #495057 !important;
    border: none !important;
    border-bottom: 3px solid transparent !important;
    padding: 12px 20px !important;
    font-weight: 500 !important;
    font-size: 13px !important;
    transition: all 0.2s !important;
    background: transparent !important;
}
.nav-tabs .nav-link.active {
    color: #4E738A !important;
    border-bottom-color: #4E738A !important;
    background: transparent !important;
}
.nav-tabs .nav-link:hover {
    color: #4E738A !important;
    border-bottom-color: rgba(78,115,138,0.3) !important;
}

/* ---------- Card override ---------- */
.card {
    border: 1px solid #e1e4e8 !important;
    border-radius: 12px !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04) !important;
    overflow: hidden;
}
.card-header {
    background-color: #ffffff !important;
    border-bottom: 1px solid #eaecef !important;
    padding: 14px 20px !important;
    font-weight: 600 !important;
    font-size: 14px !important;
    color: #231F20 !important;
    letter-spacing: 0.3px !important;
}
.card-body { padding: 16px 20px !important; }

/* ---------- Alert override ---------- */
.alert-info {
    background-color: #e8f0fe !important;
    border-color: #b8d4f0 !important;
    color: #4E738A !important;
    border-radius: 8px !important;
    font-size: 13px !important;
}
.alert-warning {
    border-radius: 8px !important;
    font-size: 13px !important;
}

/* ---------- Range slider ---------- */
.rc-slider-track { background-color: #4E738A !important; }
.rc-slider-handle {
    border-color: #4E738A !important;
    background-color: #ffffff !important;
    box-shadow: 0 2px 4px rgba(0,0,0,0.15) !important;
}
.rc-slider-rail { background-color: #dfe1e6 !important; }

/* ---------- Loading spinner colour ---------- */
._dash-loading-callback { color: #4E738A !important; }

/* ---------- Scrollbar ---------- */
::-webkit-scrollbar { width: 8px; }
::-webkit-scrollbar-track { background: #f5f6f8; }
::-webkit-scrollbar-thumb { background: #c1c7cd; border-radius: 4px; }
::-webkit-scrollbar-thumb:hover { background: #a0a8b0; }
"""
