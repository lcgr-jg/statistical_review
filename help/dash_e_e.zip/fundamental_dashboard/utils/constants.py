# Fuel type colors
FUEL_TYPE_COLORS = {
    'fossil gas': '#00008B',  # Dark blue for gas
    'nuclear': '#FFD700',     # Yellow for nuclear
    'biomass': '#228B22',     # Green for biomass
    'fossil hard coal': '#8B4513',  # Brown for coal
    'fossil brown coal/lignite': '#A0522D',  # Sienna for lignite
    'fossil oil': '#800000',  # Maroon for oil
    'waste': '#9ACD32',       # YellowGreen for waste
    'geothermal': '#FF4500',  # Orange red for geothermal
    'other': '#808080',       # Grey for other
}

# Custom CSS styles
CUSTOM_CSS = """
/* Add any custom CSS styles here */
.dashboard-container {
    padding: 20px;
}

.chart-container {
    margin-bottom: 30px;
    background-color: white;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 15px;
}

.refresh-indicator {
    font-size: 0.9em;
    color: #666;
    margin-bottom: 10px;
}

.country-tabs {
    margin-bottom: 20px;
}

.fuel-type-dropdown {
    margin-bottom: 15px;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .dashboard-container {
        padding: 10px;
    }
    
    .chart-container {
        padding: 10px;
    }
}
""" 