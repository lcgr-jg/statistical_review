"""
DataHandler – availability and generation data backed by Energy Quantified.

Replaces the previous Kpler-based implementation.  Public API is unchanged
so that existing pages (availability, generation_vs_availability) keep working.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import functools
import concurrent.futures
import threading
import gc

from utils.eq_client import (
    get_eq_client, eq_area, dashboard_country, kpler_fuel,
    DASHBOARD_COUNTRIES, MAIN_FUEL_EQ_KEYS, FUEL_DISPLAY_LABELS,
)
from jain_commods.core.interfaces.energyquantified.curves import (
    AVAILABILITY, GENERATION_ACTUAL, get_curve, list_available_fuels,
)

logger = logging.getLogger(__name__)


def _safe_float32(df: pd.DataFrame) -> pd.DataFrame:
    """Down-cast float64 columns to float32 (skip datetime/timedelta cols)."""
    if df is None or df.empty:
        return df
    for col in df.select_dtypes(include=['float64']).columns:
        try:
            df[col] = df[col].astype('float32')
        except (TypeError, ValueError):
            pass
    return df


class DataHandler:
    """Loads REMIT availability and generation actuals from Energy Quantified."""

    def __init__(self, defer_loading: bool = False):
        logger.info("Initialising DataHandler (EQ-backed)")
        self.global_data: dict = {
            'combined_multi_index_df': None,
            'filtered_availability': None,
            'filtered_availability_merge': None,
            'last_update': None,
            'processed_data': {},
        }
        self.is_ready = False
        self._schedule_minutes = 30

        if not defer_loading:
            self.ready()

    # ── public lifecycle ─────────────────────────────────────────────────────

    def ready(self) -> bool:
        if not self.is_ready:
            logger.info("DataHandler: starting initial load")
            self.load_initial_data()
            self.reload_latest_data()
            self.schedule_next_refresh()
            self.is_ready = True
            logger.info("DataHandler: ready")
            return True
        return False

    # ── data loading ─────────────────────────────────────────────────────────

    def load_initial_data(self):
        """Fetch REMIT availability: 'latest' with full history, D-n with short window."""
        logger.info("Loading REMIT availability from EQ …")
        client = get_eq_client()

        now = datetime.now()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)

        fwd_days = 180  # 6 months forward — REMIT schedules extend well ahead

        # 'latest' needs lookback for gen-vs-avail charts + forward window
        latest_begin = today - timedelta(days=90)
        latest_end = now + timedelta(days=fwd_days)

        # D-n snapshots use the same forward horizon so all lines reach the same end
        snapshot_begin = today
        snapshot_end = now + timedelta(days=fwd_days)

        comparison_snapshots = {
            'D-1': now - timedelta(days=1),
            'D-3': now - timedelta(days=3),
            'D-7': now - timedelta(days=7),
            'D-30': now - timedelta(days=30),
        }

        chunks: list[pd.DataFrame] = []
        _lock = threading.Lock()

        def _fetch_avail(country_code, eq_fuel_key, curve_name,
                         as_of_label, issued_at_latest, qbegin, qend):
            try:
                df = client.get_latest_period_instance(
                    curve_name, begin=qbegin, end=qend,
                    issued_at_latest=issued_at_latest,
                    as_timeseries_frequency='PT1H',
                )
                if df is not None and not df.empty:
                    vals = pd.to_numeric(df.iloc[:, 0], errors='coerce').values
                    idx = pd.DatetimeIndex(df.index)
                    if idx.tz is not None:
                        idx = idx.tz_localize(None)
                    chunk = pd.DataFrame({
                        'TIMESTAMP': idx,
                        'COUNTRY': country_code,
                        'FUEL_TYPE': kpler_fuel(eq_fuel_key),
                        'AVAILABILITY_AMOUNT': vals,
                        'AS_OF': as_of_label,
                    })
                    with _lock:
                        chunks.append(chunk)
            except Exception as exc:
                logger.warning("REMIT %s/%s/%s (%s): %s",
                               as_of_label, country_code, eq_fuel_key, curve_name, exc)

        tasks = []
        for country in DASHBOARD_COUNTRIES:
            area = eq_area(country)
            avail_curves = AVAILABILITY.get(area, {})
            for fuel_key, curve_name in avail_curves.items():
                if not curve_name:
                    continue
                # 'latest' with full history
                tasks.append((country, fuel_key, curve_name,
                              'latest', None, latest_begin, latest_end))
                # D-n snapshots with short window
                for label, cutoff in comparison_snapshots.items():
                    tasks.append((country, fuel_key, curve_name,
                                  label, cutoff, snapshot_begin, snapshot_end))

        logger.info("Submitting %d REMIT availability tasks", len(tasks))
        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
            futures = [pool.submit(_fetch_avail, *t) for t in tasks]
            concurrent.futures.wait(futures)

        if chunks:
            avail_df = pd.concat(chunks, ignore_index=True)
            avail_df = _safe_float32(avail_df)
            self.global_data['filtered_availability'] = avail_df

            multi = avail_df.set_index(['AS_OF', 'COUNTRY']).sort_index()
            self.global_data['combined_multi_index_df'] = multi
            logger.info("Loaded %d REMIT availability rows", len(avail_df))
        else:
            logger.warning("No REMIT availability rows returned")
            self.global_data['filtered_availability'] = pd.DataFrame()
            self.global_data['combined_multi_index_df'] = pd.DataFrame()

    def reload_latest_data(self):
        """Fetch generation actuals and merge with availability."""
        logger.info("Loading generation actuals from EQ …")
        client = get_eq_client()

        now = datetime.now()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        gen_begin = today - timedelta(days=90)
        gen_end = today + timedelta(days=1)

        gen_chunks: list[pd.DataFrame] = []
        _gen_lock = threading.Lock()

        def _fetch_gen(country_code: str, eq_fuel_key: str, curve_name: str):
            try:
                df = client.get_actuals(
                    curve_name, begin=gen_begin, end=gen_end,
                    frequency="PT1H",
                )
                if df is not None and not df.empty:
                    idx = pd.DatetimeIndex(df.index)
                    if idx.tz is not None:
                        idx = idx.tz_localize(None)
                    chunk = pd.DataFrame({
                        'TIMESTAMP': idx,
                        'COUNTRY': country_code,
                        'FUEL_TYPE': kpler_fuel(eq_fuel_key),
                        'GENERATION': df.iloc[:, 0].values,
                    })
                    with _gen_lock:
                        gen_chunks.append(chunk)
            except Exception as exc:
                logger.warning("Gen %s/%s: %s", country_code, eq_fuel_key, exc)

        tasks = []
        for country in DASHBOARD_COUNTRIES:
            area = eq_area(country)
            gen_curves = GENERATION_ACTUAL.get(area, {})
            for fuel_key, curve_name in gen_curves.items():
                if curve_name:
                    tasks.append((country, fuel_key, curve_name))

        with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
            futures = [pool.submit(_fetch_gen, *t) for t in tasks]
            concurrent.futures.wait(futures)

        avail_df = self.global_data.get('filtered_availability')
        if avail_df is None or avail_df.empty:
            avail_df = pd.DataFrame(columns=[
                'TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'AVAILABILITY_AMOUNT', 'AS_OF',
            ])

        if gen_chunks:
            gen_df = pd.concat(gen_chunks, ignore_index=True)
            gen_df = _safe_float32(gen_df)
            logger.info("Loaded %d generation rows", len(gen_df))
        else:
            gen_df = pd.DataFrame(columns=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'GENERATION'])
            logger.warning("No generation rows returned")

        # Some countries report gas generation only as "gas ccgt" (e.g. ES)
        # but REMIT availability as "fossil gas".  Remap so the merge aligns
        # and the chart label reads "Fossil Gas" consistently.
        if not gen_df.empty:
            gen_fuels_by_country = gen_df.groupby('COUNTRY')['FUEL_TYPE'].apply(set)
            for country in gen_fuels_by_country.index:
                gen_fuels = gen_fuels_by_country[country]
                if 'gas ccgt' in gen_fuels and 'fossil gas' not in gen_fuels:
                    mask = (gen_df['COUNTRY'] == country) & (gen_df['FUEL_TYPE'] == 'gas ccgt')
                    gen_df.loc[mask, 'FUEL_TYPE'] = 'fossil gas'
                    logger.info("Remapped 'gas ccgt' → 'fossil gas' generation for %s", country)

        # For the gen-vs-avail merge use only the 'latest' availability snapshot
        avail_latest = avail_df[avail_df['AS_OF'] == 'latest'] if not avail_df.empty else avail_df

        # Ensure TIMESTAMP is datetime64 in both DataFrames before merging
        avail_latest = avail_latest.copy()
        avail_latest['TIMESTAMP'] = pd.to_datetime(avail_latest['TIMESTAMP'])
        gen_df['TIMESTAMP'] = pd.to_datetime(gen_df['TIMESTAMP'])
        # Truncate to hourly to ensure clean joins
        avail_latest['TIMESTAMP'] = avail_latest['TIMESTAMP'].dt.floor('h')
        gen_df['TIMESTAMP'] = gen_df['TIMESTAMP'].dt.floor('h')
        # Drop any duplicates from rounding
        avail_latest = avail_latest.drop_duplicates(subset=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'], keep='last')
        gen_df = gen_df.drop_duplicates(subset=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'], keep='last')

        all_keys = pd.concat([
            avail_latest[['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE']],
            gen_df[['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE']],
        ]).drop_duplicates()

        merged = all_keys.merge(
            avail_latest[['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'AVAILABILITY_AMOUNT']],
            on=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'], how='left',
        ).merge(
            gen_df[['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'GENERATION']],
            on=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'], how='left',
        )
        merged = _safe_float32(merged)

        self.global_data['filtered_availability_merge'] = merged
        self.global_data['last_update'] = datetime.now()
        self.clear_cache()
        self.preprocess_data_for_countries()
        logger.info("Merge complete – %d rows", len(merged))
        gc.collect()

    # ── preprocessing ────────────────────────────────────────────────────────

    def preprocess_data_for_countries(self):
        logger.info("Pre-processing data for priority countries …")
        try:
            merged = self.global_data.get('filtered_availability_merge')
            combined = self.global_data.get('combined_multi_index_df')
            if merged is None or merged.empty:
                return

            self.global_data['processed_data'] = {}

            for country in DASHBOARD_COUNTRIES:
                country_fuel_types = merged[merged['COUNTRY'] == country]['FUEL_TYPE'].unique()
                self.global_data['processed_data'][country] = {}

                if combined is not None and not combined.empty:
                    avail_all = combined.reset_index()
                    avail_country = avail_all[avail_all['COUNTRY'] == country]
                else:
                    avail_country = pd.DataFrame()

                merged_country = merged[merged['COUNTRY'] == country]

                for ft in country_fuel_types:
                    avail_ft = avail_country[avail_country['FUEL_TYPE'] == ft] if not avail_country.empty else pd.DataFrame()
                    merged_ft = merged_country[merged_country['FUEL_TYPE'] == ft]
                    self.global_data['processed_data'][country][ft] = {
                        'availability': avail_ft,
                        'merged': merged_ft,
                    }
        except Exception as exc:
            logger.error("preprocess_data_for_countries: %s", exc, exc_info=True)
            self.global_data['processed_data'] = {}

    # ── scheduling ───────────────────────────────────────────────────────────

    def set_schedule_time(self, minutes: int = 30, hours=None):
        self._schedule_minutes = minutes
        self._schedule_hours = hours
        self.schedule_next_refresh()

    def schedule_next_refresh(self):
        now = datetime.now()
        mins = getattr(self, '_schedule_minutes', 30)
        if now.minute >= mins:
            nxt = now.replace(hour=now.hour + 1, minute=mins, second=0, microsecond=0)
        else:
            nxt = now.replace(minute=mins, second=0, microsecond=0)
        if nxt < now:
            nxt += timedelta(days=1)
        secs = (nxt - now).total_seconds()
        logger.info("Next refresh at %s (%.0fs)", nxt.strftime('%H:%M:%S'), secs)
        t = threading.Timer(secs, self.refresh_data_and_reschedule)
        t.daemon = True
        t.start()

    def refresh_data_and_reschedule(self):
        try:
            self.clear_cache()
            self.reload_latest_data()
        except Exception as exc:
            logger.error("Refresh error: %s", exc)
        self.schedule_next_refresh()

    # ── public accessors (same interface as old Kpler handler) ───────────────

    def get_countries(self) -> list[str]:
        if not self.is_ready:
            return []
        merged = self.global_data.get('filtered_availability_merge')
        if merged is None or merged.empty:
            return []
        countries = sorted(merged['COUNTRY'].unique().tolist())
        priority = [c for c in DASHBOARD_COUNTRIES if c in countries]
        rest = [c for c in countries if c not in priority]
        return priority + rest

    def get_fuel_types(self, country: str | None = None) -> list[str]:
        if not self.is_ready:
            return []
        merged = self.global_data.get('filtered_availability_merge')
        if merged is None or merged.empty:
            return []
        if country:
            return sorted(merged[merged['COUNTRY'] == country]['FUEL_TYPE'].unique().tolist())
        return sorted(merged['FUEL_TYPE'].unique().tolist())

    def get_main_fuel_types(self) -> list[str]:
        """Return the main thermal fuel types that should have dedicated charts."""
        return ['fossil gas', 'fossil hard coal', 'nuclear', 'fossil brown coal/lignite']

    def get_other_fuel_types(self, country: str) -> list[str]:
        main = set(self.get_main_fuel_types())
        return [ft for ft in self.get_fuel_types(country) if ft not in main]

    @functools.lru_cache(maxsize=128)
    def get_availability_data(self, country: str, fuel_type: str) -> pd.DataFrame:
        if not self.is_ready:
            return pd.DataFrame()
        proc = self.global_data.get('processed_data', {})
        if country in proc and fuel_type in proc[country]:
            df = proc[country][fuel_type].get('availability', pd.DataFrame())
            if 'AVAILABILITY_AMOUNT' in df.columns and 'AVAILABLE_CAPACITY' not in df.columns:
                df = df.rename(columns={'AVAILABILITY_AMOUNT': 'AVAILABLE_CAPACITY'})
            return df
        combined = self.global_data.get('combined_multi_index_df')
        if combined is None or combined.empty:
            return pd.DataFrame()
        df = combined.reset_index()
        df = df[(df['COUNTRY'] == country) & (df['FUEL_TYPE'] == fuel_type)]
        if 'AVAILABILITY_AMOUNT' in df.columns and 'AVAILABLE_CAPACITY' not in df.columns:
            df = df.rename(columns={'AVAILABILITY_AMOUNT': 'AVAILABLE_CAPACITY'})
        return df

    @functools.lru_cache(maxsize=128)
    def get_merged_data(self, country: str, fuel_type: str) -> pd.DataFrame:
        if not self.is_ready:
            return pd.DataFrame()
        proc = self.global_data.get('processed_data', {})
        if country in proc and fuel_type in proc[country]:
            return proc[country][fuel_type].get('merged', pd.DataFrame())
        merged = self.global_data.get('filtered_availability_merge')
        if merged is None or merged.empty:
            return pd.DataFrame()
        return merged[(merged['COUNTRY'] == country) & (merged['FUEL_TYPE'] == fuel_type)]

    @functools.lru_cache(maxsize=64)
    def get_generation_vs_availability(self, country: str) -> pd.DataFrame:
        if not self.is_ready:
            return pd.DataFrame()
        merged = self.global_data.get('filtered_availability_merge')
        if merged is None or merged.empty:
            return pd.DataFrame()
        return merged[merged['COUNTRY'] == country]

    def get_last_update_time(self):
        return self.global_data.get('last_update')

    # ── cache management ─────────────────────────────────────────────────────

    def clear_cache(self):
        self.global_data['processed_data'] = {}
        self.get_availability_data.cache_clear()
        self.get_merged_data.cache_clear()
        self.get_generation_vs_availability.cache_clear()
        gc.collect()
