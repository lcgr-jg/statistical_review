import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import pandas as pd
from dash import html, dcc
import dash_bootstrap_components as dbc
import logging
from datetime import datetime, timedelta

# Set up logging
logger = logging.getLogger(__name__)

def create_empty_plot(message, plot_height=800):
    """Helper function to create an empty plot with a message"""
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper", yref="paper",
        x=0.5, y=0.5, showarrow=False,
        font=dict(size=14, color="#ff6b6b"),
    )
    fig.update_layout(
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)', height=plot_height,
    )
    return html.Div([dcc.Graph(figure=fig)])

def create_variable_plot(variable, country, forecast_sources, forecast_versions, 
                         preprocessed_plots, source_colors, forecast_source_names, config):
    """Create plot for a variable with improved organization"""
    logger.info(f"Creating plot for {variable} in {country}")
    
    # Validate inputs
    if not forecast_sources or not forecast_versions:
        logger.warning("No sources or versions selected")
        return create_empty_plot(f"No data selected for {variable} in {country}", config['plot_height'])
    
    # Check if we have the latest version in our selected versions
    versions = sorted(forecast_versions)
    latest_version = versions[0] if versions else None

    # Disable cached plots for now since they use the old single-figure format
    # The new subplot format requires regenerating all plots
    # TODO: Update caching mechanism to support subplot format
    # if latest_version:
    #     # Look for a cached plot with all sources for this country/variable/version
    #     cache_key = f"all_sources_{country}_{variable}_{latest_version}"
    #     from pages.weather_forecast import get_weather_data_handler
    #     handler = get_weather_data_handler()
    #     
    #     if handler and cache_key in handler.plot_cache:
    #         logger.info(f"Using cached plot for {variable} in {country}")
    #         
    #         # Check if our request matches the cached plot (all sources, latest version only)
    #         all_possible_sources = list(forecast_source_names.keys())
    #         if set(forecast_sources) == set(all_possible_sources) and len(forecast_versions) == 1:
    #             cached_fig = handler.plot_cache[cache_key]
    #             
    #             # Return a div containing the cached figure with component-level loading
    #             result = html.Div([
    #                 html.H2(f'{variable} in {country}', style={'textAlign': 'center'}),
    #                 # Wrap the graph in its own loading component
    #                 dcc.Loading(
    #                     id=f"loading-{country}-{variable}-main",
    #                     type="circle",
    #                     children=[
    #                         dcc.Graph(figure=cached_fig, config={'responsive': True})
    #                     ]
    #                 )
    #                 # No delta fig for cached plots to keep it simple
    #             ])
    #             
    #             return result
    
    # Create combined figure with subplots
    try:
        # Create a combined figure with main forecast and delta as subplots
        combined_fig = create_combined_forecast_delta_figure(
            variable, country, forecast_sources, forecast_versions,
            preprocessed_plots, source_colors, forecast_source_names, config
        )
        
        # Return a div containing the combined figure
        result = html.Div([
            html.H2(f'{variable} in {country}', style={'textAlign': 'center'}),
            dcc.Loading(
                id=f"loading-{country}-{variable}-combined",
                type="circle",
                children=[
                    dcc.Graph(figure=combined_fig, config={'responsive': True})
                ]
            )
        ])
        
        return result
    except Exception as e:
        logger.error(f"Error creating plot for {variable} in {country}: {str(e)}", exc_info=True)
        return create_empty_plot(f"Error creating plot: {str(e)}", config['plot_height'])

def create_combined_forecast_delta_figure(variable, country, forecast_sources, forecast_versions,
                                         preprocessed_plots, source_colors, forecast_source_names, config):
    """Create a combined figure with forecast and delta as subplots with aligned x-axes"""
    from utils.weather_data_processor import _create_delta_data
    
    # Create subplot figure with 2 rows
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.08,
        row_heights=[0.7, 0.3],
        subplot_titles=(f'{variable} Forecast for {country}', 'Run-on-Run Change')
    )
    
    # Get all available sources and versions for this country/variable
    all_sources = []
    all_versions = set()
    for source in forecast_source_names.keys():
        if source in preprocessed_plots:
            if country in preprocessed_plots[source]:
                if variable in preprocessed_plots[source][country]:
                    all_sources.append(source)
                    versions = list(preprocessed_plots[source][country][variable].keys())
                    all_versions.update(versions)
    
    if not all_sources:
        fig.add_annotation(
            text=f"No data found for {variable} in {country}",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14),
            row=1, col=1
        )
        fig.update_layout(height=config['plot_height'])
        return fig
    
    # Sort versions chronologically
    all_versions = sorted(list(all_versions))
    
    # Add forecast traces to the first subplot
    for source in all_sources:
        if source not in preprocessed_plots or country not in preprocessed_plots[source]:
            continue
            
        source_data = preprocessed_plots[source][country].get(variable, {})
        if not source_data:
            continue
            
        color = source_colors.get(source, 'rgb(128, 128, 128)')
        source_name = forecast_source_names.get(source, source)
        
        # Plot each version
        for version in all_versions:
            if version not in source_data:
                continue
                
            stats = source_data[version]
            if stats is None:
                continue
                
            # Determine if this trace should be visible initially
            is_visible = source in forecast_sources and version in forecast_versions
            
            # Special handling for Normals
            if source == "Normals":
                fig.add_trace(
                    go.Scatter(
                        x=stats['times'],
                        y=stats['average'],
                        name='Climate Normal',
                        line=dict(color=color, dash='dash', width=2),
                        showlegend=True,
                        visible=is_visible,
                        hovertemplate='<b>Climate Normal</b><br>Time: %{x}<br>Value: %{y:.0f} MW<br><extra></extra>'
                    ),
                    row=1, col=1
                )
                continue
                
            # Determine line style based on forecast age
            date_str, release = version.split('_')
            forecast_date = pd.to_datetime(date_str)
            days_old = (pd.Timestamp.now() - forecast_date).days
            
            if days_old >= 2:
                line_style = 'dot'
            elif days_old == 1:
                line_style = 'dash'
            else:
                line_style = 'solid'
            
            # Plot average
            fig.add_trace(
                go.Scatter(
                    x=stats['times'],
                    y=stats['average'],
                    name=f'{source_name} {version} (Average)',
                    line=dict(color=color, dash=line_style),
                    showlegend=True,
                    visible=is_visible,
                    hovertemplate=f'<b>{source_name} {version} (Average)</b><br>Time: %{{x}}<br>Value: %{{y:.0f}} MW<br><extra></extra>'
                ),
                row=1, col=1
            )
            
            # Add ensemble statistics for ensemble sources
            if source != "ECMWF-HRES" and source != "Normals" and source != "Meteologica":
                # Add IQR if available
                has_iqr = (
                    stats['q25'] is not None and 
                    stats['q75'] is not None and 
                    not np.all(np.isnan(stats['q25'])) and 
                    not np.all(np.isnan(stats['q75']))
                )
                if has_iqr:
                    fig.add_trace(
                        go.Scatter(
                            x=np.concatenate([stats['times'], stats['times'][::-1]]),
                            y=np.concatenate([stats['q75'], stats['q25'][::-1]]),
                            fill='toself',
                            fillcolor=f'rgba{color[3:-1]},0.1)',
                            line=dict(color='rgba(255,255,255,0)'),
                            name=f'{source_name} {version} IQR',
                            showlegend=True,
                            visible=is_visible,
                            hovertemplate=f'<b>{source_name} {version} IQR</b><br>Time: %{{x}}<br>Q75: %{{y:.0f}} MW<br><extra></extra>'
                        ),
                        row=1, col=1
                    )
                
                # Plot median if available
                has_median = (stats['median'] is not None and not np.all(np.isnan(stats['median'])))
                if has_median:
                    color_rgb = color[4:-1].split(',')
                    lighter_color = f'rgba({color_rgb[0]},{color_rgb[1]},{color_rgb[2]},0.5)'
                    
                    fig.add_trace(
                        go.Scatter(
                            x=stats['times'],
                            y=stats['median'],
                            name=f'{source_name} {version} (Median)',
                            line=dict(color=lighter_color, dash=line_style),
                            showlegend=True,
                            visible=is_visible,
                            hovertemplate=f'<b>{source_name} {version} (Median)</b><br>Time: %{{x}}<br>Value: %{{y:.0f}} MW<br><extra></extra>'
                        ),
                        row=1, col=1
                    )
                
                # Add confidence interval
                fig.add_trace(
                    go.Scatter(
                        x=np.concatenate([stats['times'], stats['times'][::-1]]),
                        y=np.concatenate([stats['top'], stats['bottom'][::-1]]),
                        fill='toself',
                        fillcolor=f'rgba{color[3:-1]},0.05)',
                        line=dict(color='rgba(255,255,255,0)'),
                        name=f'{source_name} {version} Range',
                        showlegend=True,
                        visible=is_visible,
                        hovertemplate=f'<b>{source_name} {version} Range</b><br>Time: %{{x}}<br>Max: %{{y:.0f}} MW<br><extra></extra>'
                    ),
                    row=1, col=1
                )
    
    # Get delta data for the second subplot
    delta_data = _create_delta_data(preprocessed_plots, country, variable, forecast_versions)
    
    if delta_data:
        for name, data in delta_data.items():
            fig.add_trace(
                go.Bar(
                    x=data['times'],
                    y=data['values'],
                    name=name,
                    marker_color=data['color'],
                    showlegend=True,
                    hovertemplate=f'<b>{name}</b><br>Time: %{{x}}<br>Change: %{{y:.0f}} MW<br><extra></extra>'
                ),
                row=2, col=1
            )
    else:
        fig.add_annotation(
            text="No run-on-run comparison data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14),
            row=2, col=1
        )
    
    fig.update_layout(
        template='plotly_dark',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='#e0e0e0',
        height=config['plot_height'],
        showlegend=True,
        legend=dict(
            orientation="v",
            yanchor="top", y=1, xanchor="left", x=1.02,
            groupclick="toggleitem",
            bgcolor='rgba(34,38,46,0.95)',
            font=dict(color='#e0e0e0', size=11),
            bordercolor='#353a44', borderwidth=1,
        ),
        hovermode='x unified',
        hoverlabel=dict(
            bgcolor='#22262e', font_color='#e0e0e0',
            font_size=12, font_family='Inter, Arial, sans-serif',
        ),
        margin=dict(l=50, r=20, t=40, b=40),
    )

    _grid = 'rgba(255,255,255,0.06)'
    fig.update_xaxes(
        showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
        type='date', tickformat='%d %b %H:%M', dtick=86400000.0,
        row=1, col=1,
    )
    fig.update_xaxes(
        showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
        type='date', tickformat='%d %b %H:%M', dtick=86400000.0,
        row=2, col=1,
    )
    fig.update_yaxes(
        title='Value (MW)', showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
        row=1, col=1,
    )
    fig.update_yaxes(
        title='Change (MW)', showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
        row=2, col=1,
    )
    
    return fig

def create_forecast_figure(variable, country, forecast_sources, forecast_versions,
                          preprocessed_plots, source_colors, forecast_source_names, config):
    """Helper function to create the main forecast figure"""
    forecast_fig = go.Figure()
    
    # Get all available sources and versions for this country/variable
    all_sources = []
    all_versions = set()
    for source in forecast_source_names.keys():
        if source in preprocessed_plots:
            if country in preprocessed_plots[source]:
                if variable in preprocessed_plots[source][country]:
                    all_sources.append(source)
                    versions = list(preprocessed_plots[source][country][variable].keys())
                    all_versions.update(versions)
    
    if not all_sources:
        logger.warning(f"No data found for {country}/{variable}")
        forecast_fig.add_annotation(
            text=f"No data found for {variable} in {country}",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14)
        )
        forecast_fig.update_layout(height=config['plot_height'])
        return forecast_fig
    
    # Sort versions chronologically
    all_versions = sorted(list(all_versions))
    
    # Create traces for main forecast chart
    for source in all_sources:
        if source not in preprocessed_plots or country not in preprocessed_plots[source]:
            continue
            
        source_data = preprocessed_plots[source][country].get(variable, {})
        if not source_data:
            continue
            
        color = source_colors.get(source, 'rgb(128, 128, 128)')
        source_name = forecast_source_names.get(source, source)
        
        # Plot each version
        for version in all_versions:
            if version not in source_data:
                continue
                
            stats = source_data[version]
            if stats is None:
                continue
                
            # Determine if this trace should be visible initially
            is_visible = source in forecast_sources and version in forecast_versions
            
            # Special handling for Normals - just plot as a single line
            if source == "Normals":
                forecast_fig.add_trace(
                    go.Scatter(
                        x=stats['times'],
                        y=stats['average'],  # Use whatever value was stored during processing
                        name='Climate Normal',  # Simple name without version or statistic
                        line=dict(
                            color=color,
                            dash='dash',  # Use dashed line for normals
                            width=2  # Slightly thicker line
                        ),
                        showlegend=True,
                        visible=is_visible,
                        hovertemplate='<b>Climate Normal</b><br>' +
                                    'Time: %{x}<br>' +
                                    'Value: %{y:.0f} MW<br>' +
                                    '<extra></extra>'
                    )
                )
                continue  # Skip the rest of the plotting for normals
                
            # Determine line style based on forecast age
            date_str, release = version.split('_')
            forecast_date = pd.to_datetime(date_str)
            days_old = (pd.Timestamp.now() - forecast_date).days
            
            if days_old >= 2:
                line_style = 'dot'
            elif days_old == 1:
                line_style = 'dash'
            else:
                line_style = 'solid'
            
            # Plot average with hover template
            forecast_fig.add_trace(
                go.Scatter(
                    x=stats['times'],
                    y=stats['average'],
                    name=f'{source_name} {version} (Average)',
                    line=dict(color=color, dash=line_style),
                    showlegend=True,
                    visible=is_visible,
                    hovertemplate=f'<b>{source_name} {version} (Average)</b><br>' +
                                'Time: %{x}<br>' +
                                'Value: %{y:.0f} MW<br>' +
                                '<extra></extra>'
                )
            )
            
            # Only add confidence intervals and IQR for ensemble sources
            if source != "ECMWF-HRES" and source != "Normals" and source != "Meteologica":
                # Add IQR if available (check for non-NaN values)
                has_iqr = (
                    stats['q25'] is not None and 
                    stats['q75'] is not None and 
                    not np.all(np.isnan(stats['q25'])) and 
                    not np.all(np.isnan(stats['q75']))
                )
                if has_iqr:
                    forecast_fig.add_trace(
                        go.Scatter(
                            x=np.concatenate([stats['times'], stats['times'][::-1]]),
                            y=np.concatenate([stats['q75'], stats['q25'][::-1]]),
                            fill='toself',
                            fillcolor=f'rgba{color[3:-1]},0.1)',
                            line=dict(color='rgba(255,255,255,0)'),
                            name=f'{source_name} {version} IQR',
                            showlegend=True,
                            visible=is_visible,
                            hovertemplate=f'<b>{source_name} {version} IQR</b><br>' +
                                        'Time: %{x}<br>' +
                                        'Q75: %{y:.0f} MW<br>' +
                                        '<extra></extra>'
                        )
                    )
                
                # Plot median if available (check for non-NaN values)
                has_median = (
                    stats['median'] is not None and 
                    not np.all(np.isnan(stats['median']))
                )
                if has_median:
                    color_rgb = color[4:-1].split(',')
                    lighter_color = f'rgba({color_rgb[0]},{color_rgb[1]},{color_rgb[2]},0.5)'
                    
                    forecast_fig.add_trace(
                        go.Scatter(
                            x=stats['times'],
                            y=stats['median'],
                            name=f'{source_name} {version} (Median)',
                            line=dict(color=lighter_color, dash=line_style),
                            showlegend=True,
                            visible=is_visible,
                            hovertemplate=f'<b>{source_name} {version} (Median)</b><br>' +
                                        'Time: %{x}<br>' +
                                        'Value: %{y:.0f} MW<br>' +
                                        '<extra></extra>'
                        )
                    )
                
                # Add confidence interval (TOP/BOTTOM)
                forecast_fig.add_trace(
                    go.Scatter(
                        x=np.concatenate([stats['times'], stats['times'][::-1]]),
                        y=np.concatenate([stats['top'], stats['bottom'][::-1]]),
                        fill='toself',
                        fillcolor=f'rgba{color[3:-1]},0.05)',
                        line=dict(color='rgba(255,255,255,0)'),
                        name=f'{source_name} {version} Range',
                        showlegend=True,
                        visible=is_visible,
                        hovertemplate=f'<b>{source_name} {version} Range</b><br>' +
                                    'Time: %{x}<br>' +
                                    'Max: %{y:.0f} MW<br>' +
                                    '<extra></extra>'
                    )
                )
    
    _grid = 'rgba(255,255,255,0.06)'
    forecast_fig.update_layout(
        template='plotly_dark',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='#e0e0e0',
        title=dict(text=f'{variable} Forecast for {country}',
                   font=dict(size=15, color='#e0e0e0')),
        height=int(config['plot_height'] * 0.7),
        xaxis=dict(
            showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
            type='date', tickformat='%d %b %H:%M', dtick=86400000.0,
        ),
        yaxis=dict(
            title='Value (MW)', showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
        ),
        showlegend=True,
        legend=dict(
            orientation="v", yanchor="top", y=1, xanchor="left", x=1.02,
            title=dict(text="Forecast Data"),
            groupclick="toggleitem",
            bgcolor='rgba(34,38,46,0.95)',
            font=dict(color='#e0e0e0', size=11),
            bordercolor='#353a44', borderwidth=1,
        ),
        hovermode='x unified',
        hoverlabel=dict(
            bgcolor='#22262e', font_color='#e0e0e0',
            font_size=12, font_family='Inter, Arial, sans-serif',
        ),
        margin=dict(l=50, r=20, t=40, b=20),
    )
    
    return forecast_fig

def create_delta_figure(country, variable, selected_versions, preprocessed_plots, config):
    """Helper function to create the delta figure"""
    from utils.weather_data_processor import _create_delta_data
    
    delta_fig = go.Figure()
    
    # Get delta data for the plot
    delta_data = _create_delta_data(preprocessed_plots, country, variable, selected_versions)
    
    if delta_data:
        for name, data in delta_data.items():
            delta_fig.add_trace(
                go.Bar(
                    x=data['times'],
                    y=data['values'],
                    name=name,
                    marker_color=data['color'],
                    showlegend=True,
                    hovertemplate=f'<b>{name}</b><br>' +
                                'Time: %{x}<br>' +
                                'Change: %{y:.0f} MW<br>' +
                                '<extra></extra>'
                )
            )
        
        _grid = 'rgba(255,255,255,0.06)'
        delta_fig.update_layout(
            template='plotly_dark',
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='#e0e0e0',
            title=dict(text='Run-on-Run Change',
                       font=dict(size=14, color='#e0e0e0')),
            height=int(config['plot_height'] * 0.3),
            xaxis=dict(
                showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
                type='date', tickformat='%d %b %H:%M', dtick=86400000.0,
            ),
            yaxis=dict(
                title='Change (MW)', showgrid=True, gridwidth=1, gridcolor=_grid, zeroline=False,
            ),
            showlegend=True,
            legend=dict(
                orientation="v", yanchor="top", y=1, xanchor="left", x=1.02,
                title=dict(text="Run-on-Run Deltas"),
                groupclick="toggleitem",
                bgcolor='rgba(34,38,46,0.95)',
                font=dict(color='#e0e0e0', size=11),
                bordercolor='#353a44', borderwidth=1,
            ),
            hovermode='x unified',
            hoverlabel=dict(
                bgcolor='#22262e', font_color='#e0e0e0',
                font_size=12, font_family='Inter, Arial, sans-serif',
            ),
            margin=dict(l=50, r=20, t=50, b=20),
        )
    else:
        delta_fig.add_annotation(
            text="No run-on-run comparison data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14, color='#8a8f9a'),
        )
        delta_fig.update_layout(
            template='plotly_dark',
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            title=dict(text='Run-on-Run Change',
                       font=dict(size=14, color='#e0e0e0')),
            height=int(config['plot_height'] * 0.3),
            showlegend=False,
            margin=dict(l=50, r=20, t=50, b=20),
        )
    
    return delta_fig

def calculate_normal_residual_load(global_data, country):
    """Calculate normal residual load (Demand - Wind - Solar) from climate normals.
    
    Args:
        global_data: Dictionary with raw forecast data
        country: Country code
    
    Returns:
        pandas.DataFrame with normal residual load values, or None if data unavailable
    """
    required_vars = ['PowerDemand', 'Wind', 'PV']
    source = 'Normals'
    
    # Check if all three variables exist for Normals
    for var in required_vars:
        if (source not in global_data or
            country not in global_data[source] or
            var not in global_data[source][country]):
            logger.warning(f"Missing {var} normal data for {country}")
            return None
    
    # Get all available versions (should be just one for normals)
    versions = list(global_data[source][country][required_vars[0]].keys())
    if not versions:
        logger.warning(f"No versions found for Normals data in {country}")
        return None
    
    version = versions[0]  # Use the first (and typically only) version
    
    # Reconstruct DataFrames from stored data
    dataframes = {}
    for var in required_vars:
        if version not in global_data[source][country][var]:
            logger.warning(f"Missing {var} normal data for {country} version {version}")
            return None
            
        stored = global_data[source][country][var][version]
        if not stored or 'data' not in stored:
            return None
        
        df = pd.DataFrame(stored['data'])
        df.index = pd.to_datetime(stored['index'])
        dataframes[var] = df
    
    # Align timestamps across all three variables
    common_times = (dataframes['PowerDemand'].index
                    .intersection(dataframes['Wind'].index)
                    .intersection(dataframes['PV'].index))
    
    if len(common_times) == 0:
        logger.warning(f"No common timestamps for normal data in {country}")
        return None
    
    # Calculate normal residual load: Demand - Wind - Solar
    # Normals typically have a single column (not ensemble members)
    demand_col = dataframes['PowerDemand'].columns[0]
    wind_col = dataframes['Wind'].columns[0]
    pv_col = dataframes['PV'].columns[0]
    
    normal_residual = pd.DataFrame(index=common_times)
    normal_residual['NORMAL'] = (
        dataframes['PowerDemand'].loc[common_times, demand_col] -
        dataframes['Wind'].loc[common_times, wind_col] -
        dataframes['PV'].loc[common_times, pv_col]
    ).astype('float32')
    
    logger.info(f"Calculated normal residual load for {country} with {len(common_times)} timestamps")
    
    return normal_residual

def _create_residual_load_delta_data(preprocessed_plots, country, forecast_versions):
    """
    Create delta data for residual load run-on-run comparisons.
    Uses PREPROCESSED data - just like Wind/Solar/Demand.
    Returns a dictionary of datasets for plotting.
    """
    from datetime import timedelta
    
    # Add explicit None check for preprocessed_plots
    if preprocessed_plots is None:
        logger.warning("preprocessed_plots is None, cannot create residual load delta data")
        return {}
    
    # Only work with ECMWF-ENS for now (same as other variables)
    source = 'ECMWF-ENS'
    
    if not forecast_versions or len(forecast_versions) < 2:
        logger.info(f"Not enough forecast versions ({len(forecast_versions) if forecast_versions else 0}) for delta comparison")
        return {}
    
    # Check if preprocessed ResidualLoad data exists with detailed logging
    if source not in preprocessed_plots:
        logger.warning(f"Source '{source}' not found in preprocessed_plots for residual load delta")
        return {}
    
    if country not in preprocessed_plots.get(source, {}):
        logger.warning(f"Country '{country}' not found in preprocessed_plots[{source}] for residual load delta")
        return {}
    
    if 'ResidualLoad' not in preprocessed_plots.get(source, {}).get(country, {}):
        logger.warning(f"ResidualLoad not found in preprocessed_plots[{source}][{country}] for delta data")
        return {}
    
    residual_data = preprocessed_plots[source][country]['ResidualLoad']
    
    # Get available versions
    available_versions = [v for v in forecast_versions if v in residual_data]
    if len(available_versions) < 2:
        return {}
    
    # Sort versions by date (newest first)
    versions = sorted(available_versions, reverse=True)
    
    # Get latest version
    latest_version = versions[0]
    latest_stats = residual_data[latest_version]
    
    if not latest_stats:
        return {}
    
    # Parse date for calculations
    current_date_str, current_release = latest_version.split('_')
    current_date = pd.to_datetime(current_date_str)
    
    # ALWAYS show D-1 and D-3 deltas
    target_days_back = [1, 3]  # D-1 and D-3
    comparison_versions = []
    
    # Find closest versions to D-1 and D-3
    for days_back in target_days_back:
        target_date = current_date - timedelta(days=days_back)
        target_version_prefix = target_date.strftime('%Y-%m-%d')
        
        # Look for versions matching the target date
        matching_versions = [v for v in versions if v.startswith(target_version_prefix)]
        
        if matching_versions:
            # Prefer 00z if available
            if f"{target_version_prefix}_00" in matching_versions:
                comparison_versions.append(f"{target_version_prefix}_00")
            else:
                # Otherwise use the first available release for that day
                comparison_versions.append(matching_versions[0])
        else:
            # If no exact date match, find the closest previous version
            prev_versions = [v for v in versions if pd.to_datetime(v.split('_')[0]) <= target_date]
            if prev_versions and prev_versions[0] != latest_version:
                comparison_versions.append(prev_versions[0])
    
    # Make sure the comparison versions are unique and not the latest
    comparison_versions = [v for v in list(dict.fromkeys(comparison_versions)) if v != latest_version]
    
    # Process each comparison - using PREPROCESSED data only
    delta_data = {}
    
    for comp_version in comparison_versions:
        # Get comparison version stats - already preprocessed!
        if comp_version not in residual_data:
            continue
        
        comp_stats = residual_data[comp_version]
        if not comp_stats:
            continue
        
        # Get numpy arrays directly from stats - NO calculation needed!
        latest_times = latest_stats['times']
        comp_times = comp_stats['times']
        
        # Find common indices (simple array comparison)
        latest_times_set = set(latest_times)
        common_indices = [i for i, t in enumerate(comp_times) if t in latest_times_set]
        
        if not common_indices:
            continue
        
        # Get aligned data
        comp_times_common = comp_times[common_indices]
        latest_indices = [list(latest_times).index(t) for t in comp_times_common]
        
        # Calculate delta: Latest - Comparison (simple numpy subtraction)
        delta_values = (
            latest_stats['average'][latest_indices] - 
            comp_stats['average'][common_indices]
        )
        
        # Determine name and color based on days difference
        comp_date_str, comp_release = comp_version.split('_')
        comp_date = pd.to_datetime(comp_date_str)
        days_diff = (current_date - comp_date).days
        
        if days_diff == 1:
            name = f"vs D-1 ({comp_version})"
            # Use orange for D-1
            bar_colors = ['rgba(255, 165, 0, 0.8)' if x >= 0 else 'rgba(255, 100, 0, 0.8)' for x in delta_values]
        elif days_diff == 3:
            name = f"vs D-3 ({comp_version})"
            # Use blue for D-3
            bar_colors = ['rgba(0, 100, 255, 0.8)' if x >= 0 else 'rgba(0, 50, 200, 0.8)' for x in delta_values]
        else:
            name = f"vs {comp_version}"
            bar_colors = ['rgba(100, 100, 100, 0.8)' if x >= 0 else 'rgba(50, 50, 50, 0.8)' for x in delta_values]
        
        delta_data[name] = {
            'times': comp_times_common,
            'values': delta_values,
            'color': bar_colors
        }
    
    return delta_data


def calculate_residual_load_from_preprocessed(preprocessed_plots, source, country, version):
    """Calculate residual load stats from preprocessed Wind/Solar/Demand data.
    MUCH faster than recalculating from raw data.
    
    Returns DataFrame with AVERAGE, MEDIAN, Q25, Q75, TOP, BOTTOM or None
    """
    required_vars = ['PowerDemand', 'Wind', 'PV']
    
    # Check if all three variables exist in preprocessed_plots
    if (source not in preprocessed_plots or
        country not in preprocessed_plots.get(source, {}) or
        any(var not in preprocessed_plots.get(source, {}).get(country, {}) for var in required_vars) or
        any(version not in preprocessed_plots.get(source, {}).get(country, {}).get(var, {}) for var in required_vars)):
        return None
    
    try:
        # Get preprocessed stats for each variable
        demand_stats = preprocessed_plots[source][country]['PowerDemand'][version]
        wind_stats = preprocessed_plots[source][country]['Wind'][version]
        pv_stats = preprocessed_plots[source][country]['PV'][version]
        
        if not demand_stats or not wind_stats or not pv_stats:
            return None
        
        # Create DataFrame from the preprocessed stats
        # Residual = Demand - Wind - PV
        residual_df = pd.DataFrame(index=pd.to_datetime(demand_stats['times']))
        residual_df['AVERAGE'] = demand_stats['average'] - wind_stats['average'] - pv_stats['average']
        residual_df['MEDIAN'] = demand_stats['median'] - wind_stats['median'] - pv_stats['median']
        residual_df['Q25'] = demand_stats['q25'] - wind_stats['q25'] - pv_stats['q25']
        residual_df['Q75'] = demand_stats['q75'] - wind_stats['q75'] - pv_stats['q75']
        residual_df['TOP'] = demand_stats['top'] - wind_stats['bottom'] - pv_stats['bottom']  # Worst case
        residual_df['BOTTOM'] = demand_stats['bottom'] - wind_stats['top'] - pv_stats['top']  # Best case
        
        return residual_df
        
    except Exception as e:
        logger.error(f"Error calculating residual load from preprocessed: {str(e)}")
        return None


def create_residual_load_plot_simple(country, forecast_sources, forecast_versions,
                                    preprocessed_plots, source_colors, forecast_source_names, config):
    """Create SIMPLIFIED residual load plot - just average line, no extras.
    This version is fast and won't freeze the browser.
    """
    logger.info(f"Creating SIMPLE residual load plot for {country}")
    
    # Validate preprocessed_plots
    if preprocessed_plots is None:
        return html.Div([
            html.H3('Residual Load (Demand - Wind - Solar)', className='text-center mt-4'),
            dbc.Alert("ResidualLoad data not available", color="warning", className="mt-3")
        ])
    
    # Create figure with subplot for delta chart
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.08,
        row_heights=[0.7, 0.3],
        subplot_titles=(f'Residual Load (Demand - Wind - Solar) for {country}', 'Run-on-Run Change')
    )
    
    # Plot ECMWF-ENS forecast
    source = 'ECMWF-ENS'
    if (source in preprocessed_plots and 
        country in preprocessed_plots[source] and
        'ResidualLoad' in preprocessed_plots[source][country]):
        
        residual_data = preprocessed_plots[source][country]['ResidualLoad']
        color = source_colors.get(source, 'rgb(0, 0, 255)')
        source_name = forecast_source_names.get(source, source)
        
        # Only plot SELECTED versions (keep it minimal)
        for version in forecast_versions:
            if version not in residual_data:
                continue
                
            stats = residual_data[version]
            if not stats:
                continue
            
            # Determine line style based on forecast age (matching other plots)
            date_str, release = version.split('_')
            forecast_date = pd.to_datetime(date_str)
            days_old = (pd.Timestamp.now() - forecast_date).days
            
            if days_old >= 2:
                line_style = 'dot'
            elif days_old == 1:
                line_style = 'dash'
            else:
                line_style = 'solid'
            
            # Add IQR band first (so it's behind the lines)
            has_iqr = (
                'q25' in stats and 'q75' in stats and
                not np.all(np.isnan(stats['q25'])) and 
                not np.all(np.isnan(stats['q75']))
            )
            if has_iqr:
                # Extract RGB values from color and add transparency
                fillcolor = f'rgba{color[3:-1]},0.1)'
                fig.add_trace(
                    go.Scatter(
                        x=np.concatenate([stats['times'], stats['times'][::-1]]),
                        y=np.concatenate([stats['q75'], stats['q25'][::-1]]),
                        fill='toself',
                        fillcolor=fillcolor,
                        line=dict(color='rgba(255,255,255,0)'),
                        name=f'{source_name} {version} IQR',
                        showlegend=True,
                        hoverinfo='skip'
                    ),
                    row=1, col=1
                )
            
            # Add median line
            has_median = ('median' in stats and not np.all(np.isnan(stats['median'])))
            if has_median:
                # Create lighter color for median (matching other plots)
                color_rgb = color[4:-1].split(',')
                lighter_color = f'rgba({color_rgb[0]},{color_rgb[1]},{color_rgb[2]},0.5)'
                
                fig.add_trace(
                    go.Scatter(
                        x=stats['times'],
                        y=stats['median'],
                        name=f'{source_name} {version} (Median)',
                        line=dict(color=lighter_color, dash=line_style),
                        mode='lines',
                        showlegend=True,
                        hovertemplate=f'<b>{source_name} {version} (Median)</b><br>Time: %{{x}}<br>Value: %{{y:.0f}} MW<br><extra></extra>'
                    ),
                    row=1, col=1
                )
            
            # Add average line on top
            fig.add_trace(
                go.Scatter(
                    x=stats['times'],
                    y=stats['average'],
                    name=f'{source_name} {version} (Average)',
                    line=dict(color=color, dash=line_style),
                    mode='lines',
                    showlegend=True,
                    hovertemplate=f'<b>{source_name} {version} (Average)</b><br>Time: %{{x}}<br>Value: %{{y:.0f}} MW<br><extra></extra>'
                ),
                row=1, col=1
            )
    
    # Add Climate Normals if available
    normals_source = 'Normals'
    if (normals_source in preprocessed_plots and 
        country in preprocessed_plots[normals_source] and
        'ResidualLoad' in preprocessed_plots[normals_source][country]):
        
        normals_data = preprocessed_plots[normals_source][country]['ResidualLoad']
        normals_color = source_colors.get(normals_source, 'rgb(128, 128, 128)')
        
        # Normals typically have one version
        if normals_data:
            # Get the first (and likely only) version
            version = list(normals_data.keys())[0]
            stats = normals_data[version]
            
            if stats:
                fig.add_trace(
                    go.Scatter(
                        x=stats['times'],
                        y=stats['average'],
                        name='Climate Normal',
                        line=dict(color=normals_color, dash='dash', width=2),
                        showlegend=True,
                        mode='lines',
                        hovertemplate='<b>Climate Normal</b><br>Time: %{x}<br>Value: %{y:.0f} MW<br><extra></extra>'
                    ),
                    row=1, col=1
                )
    
    # Add delta bars (D-1 and D-3 comparison) to second subplot
    source = 'ECMWF-ENS'
    if (source in preprocessed_plots and 
        country in preprocessed_plots[source] and
        'ResidualLoad' in preprocessed_plots[source][country] and
        len(forecast_versions) > 0):
        
        residual_data = preprocessed_plots[source][country]['ResidualLoad']
        
        # Sort versions to get latest
        sorted_versions = sorted(forecast_versions, reverse=True)
        latest_version = sorted_versions[0]
        
        if latest_version in residual_data:
            latest_stats = residual_data[latest_version]
            
            # Parse latest version date
            latest_date_str, latest_release = latest_version.split('_')
            latest_date = pd.to_datetime(latest_date_str)
            
            # Try D-1 and D-3 (matching colors from other plots)
            for days_back, bar_color in [(1, 'rgba(30, 144, 255, 0.7)'), (3, 'rgba(255, 140, 0, 0.7)')]:
                compare_date = latest_date - timedelta(days=days_back)
                compare_version = f"{compare_date.strftime('%Y-%m-%d')}_{latest_release}"
                
                # Check if comparison version exists
                if compare_version in residual_data:
                    compare_stats = residual_data[compare_version]
                    
                    # Find common timestamps
                    latest_times = pd.DatetimeIndex(latest_stats['times'])
                    compare_times = pd.DatetimeIndex(compare_stats['times'])
                    common_times = latest_times.intersection(compare_times)
                    
                    if len(common_times) > 0:
                        # Get indices for alignment
                        latest_idx = latest_times.get_indexer(common_times)
                        compare_idx = compare_times.get_indexer(common_times)
                        
                        # Calculate delta: Latest - Comparison
                        delta_values = latest_stats['average'][latest_idx] - compare_stats['average'][compare_idx]
                        
                        # Add bar chart
                        trace_name = f'Latest vs D-{days_back}'
                        fig.add_trace(
                            go.Bar(
                                x=common_times,
                                y=delta_values,
                                name=trace_name,
                                marker_color=bar_color,
                                showlegend=True,
                                hovertemplate=f'<b>{trace_name}</b><br>Time: %{{x}}<br>Change: %{{y:.0f}} MW<br><extra></extra>'
                            ),
                            row=2, col=1
                        )
    
    fig.update_layout(
        height=800,  # Increased for subplot
        showlegend=True,
        legend=dict(
            orientation="v",
            yanchor="top",
            y=1,
            xanchor="left",
            x=1.02,
            groupclick="toggleitem"
        ),
        hovermode='x unified',
        hoverlabel=dict(
            bgcolor='white',
            font_size=12,
            font_family='Arial'
        ),
        template='seaborn'
    )
    
    # Update axes
    fig.update_xaxes(
        title_text='Time',
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGrey',
        type='date',
        tickformat='%d %b %H:%M',
        dtick=86400000.0,
        row=2, col=1
    )
    fig.update_yaxes(
        title_text='Residual Load (MW)',
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGrey',
        row=1, col=1
    )
    fig.update_yaxes(
        title_text='Change (MW)',
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGrey',
        row=2, col=1
    )
    
    return html.Div([
        html.H3('Residual Load (Demand - Wind - Solar)', className='text-center mt-4'),
        dcc.Graph(figure=fig, config={'responsive': True})
    ])


def create_residual_load_plot(country, forecast_sources, forecast_versions,
                             global_data, source_colors, forecast_source_names, config, preprocessed_plots=None):
    """Create residual load plot (Demand - Wind - Solar) - uses PREPROCESSED data for speed.
    
    Args:
        country: Country to display
        forecast_sources: List of forecast sources to include
        forecast_versions: List of forecast versions to include
        global_data: Dictionary with raw forecast data (for normals fallback only)
        source_colors: Dictionary mapping sources to colors
        forecast_source_names: Dictionary mapping sources to display names
        config: Configuration dictionary
        preprocessed_plots: Preprocessed data (REQUIRED for fast rendering)
        
    Returns:
        html.Div containing the residual load visualization
    """
    logger.info(f"Creating residual load plot for {country}")
    logger.info(f"Requested forecast versions: {forecast_versions}")
    
    # Early validation: Check if preprocessed_plots is available
    if preprocessed_plots is None:
        logger.error("preprocessed_plots is None - cannot render residual load")
        return html.Div([
            html.H3('Residual Load (Demand - Wind - Solar)', className='text-center mt-4'),
            dbc.Alert(
                "Residual Load data is not available. Preprocessed data is required.",
                color="warning",
                className="mt-3"
            )
        ])
    
    # Validate that ResidualLoad data exists for at least one ensemble source
    ensemble_sources = ['ECMWF-ENS', 'GEFS']
    has_residual_data = False
    
    for source in ensemble_sources:
        if (source in preprocessed_plots and
            country in preprocessed_plots.get(source, {}) and
            'ResidualLoad' in preprocessed_plots.get(source, {}).get(country, {})):
            has_residual_data = True
            break
    
    if not has_residual_data:
        logger.warning(f"No ResidualLoad data found in preprocessed_plots for {country}")
        return html.Div([
            html.H3('Residual Load (Demand - Wind - Solar)', className='text-center mt-4'),
            html.P(
                'Calculated using matched ensemble members: Demand - Wind - Solar',
                className='text-center text-muted mb-3',
                style={'fontSize': '0.9em'}
            ),
            dbc.Alert(
                f"Residual Load data is still being calculated for {country}. "
                "Please refresh the page in a moment or check the base variables (Wind, Solar, Demand) below.",
                color="info",
                className="mt-3"
            )
        ])
    
    # Create subplot figure with 2 rows
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.08,
        row_heights=[0.7, 0.3],
        subplot_titles=(
            f'Residual Load (Demand - Wind - Solar) for {country}',
            'Run-on-Run Change'
        )
    )
    
    # Get all available sources and versions for ResidualLoad - EXACTLY like Wind/Solar/Demand!
    all_sources = []
    all_versions = set()
    
    # Only check ensemble sources
    ensemble_sources = ['ECMWF-ENS', 'GEFS']
    
    for source in forecast_source_names.keys():
        if source not in ensemble_sources:
            continue
        if source in preprocessed_plots:
            if country in preprocessed_plots[source]:
                if 'ResidualLoad' in preprocessed_plots[source][country]:
                    all_sources.append(source)
                    versions = list(preprocessed_plots[source][country]['ResidualLoad'].keys())
                    all_versions.update(versions)
    
    if not all_sources:
        fig.add_annotation(
            text=f"No ResidualLoad data found for {country}",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14),
            row=1, col=1
        )
        fig.update_layout(height=config['plot_height'])
        return html.Div([
            html.H3('Residual Load (Demand - Wind - Solar)', className='text-center mt-4'),
            html.P(
                'Calculated using matched ensemble members: Demand - Wind - Solar',
                className='text-center text-muted mb-3',
                style={'fontSize': '0.9em'}
            ),
            dcc.Loading(
                id=f"loading-{country}-residual-combined",
                type="circle",
                children=[dcc.Graph(figure=fig, config={'responsive': True})]
            )
        ])
    
    # Sort versions chronologically
    all_versions = sorted(list(all_versions))
    
    # CRITICAL: Only create traces for SELECTED versions to prevent UI freeze
    # Unlike other variables, ResidualLoad is computationally expensive
    plot_data_available = False
    
    for source in all_sources:
        if source not in preprocessed_plots or country not in preprocessed_plots[source]:
            continue
            
        source_data = preprocessed_plots[source][country].get('ResidualLoad', {})
        if not source_data:
            continue
        
        color = source_colors.get(source, 'rgb(128, 128, 128)')
        source_name = forecast_source_names.get(source, source)
        
        # ONLY loop through SELECTED forecast_versions to avoid creating too many traces
        for version in forecast_versions:
            # Skip if this version doesn't exist in the data
            if version not in source_data:
                continue
            
            # Skip if this source is not selected
            if source not in forecast_sources:
                continue
            
            stats = source_data[version]
            
            if not stats:
                continue
            
            plot_data_available = True
            
            # Determine line style based on forecast age
            date_str, release = version.split('_')
            forecast_date = pd.to_datetime(date_str)
            days_old = (pd.Timestamp.now() - forecast_date).days
            
            if days_old >= 2:
                line_style = 'dot'
            elif days_old == 1:
                line_style = 'dash'
            else:
                line_style = 'solid'
            
            # Plot average
            fig.add_trace(
                go.Scatter(
                    x=stats['times'],
                    y=stats['average'],
                    name=f'{source_name} {version} (Average)',
                    line=dict(color=color, dash=line_style, width=2),
                    showlegend=True,
                    hovertemplate=(
                        f'<b>{source_name} {version} (Average)</b><br>' +
                        'Time: %{x}<br>' +
                        'Residual Load: %{y:.0f} MW<br>' +
                        '<extra></extra>'
                    )
                ),
                row=1, col=1
            )
            
            # Add IQR
            has_iqr = (
                not np.all(np.isnan(stats['q25'])) and 
                not np.all(np.isnan(stats['q75']))
            )
            if has_iqr:
                fig.add_trace(
                    go.Scatter(
                        x=np.concatenate([stats['times'], stats['times'][::-1]]),
                        y=np.concatenate([stats['q75'], stats['q25'][::-1]]),
                        fill='toself',
                        fillcolor=f'rgba{color[3:-1]},0.15)',
                        line=dict(color='rgba(255,255,255,0)'),
                        name=f'{source_name} {version} IQR',
                        showlegend=True,
                        hovertemplate=(
                            f'<b>{source_name} {version} IQR</b><br>' +
                            'Time: %{x}<br>' +
                            'Q75: %{y:.0f} MW<br>' +
                            '<extra></extra>'
                        )
                    ),
                    row=1, col=1
                )
            
            # Plot median
            has_median = not np.all(np.isnan(stats['median']))
            if has_median:
                color_rgb = color[4:-1].split(',')
                lighter_color = f'rgba({color_rgb[0]},{color_rgb[1]},{color_rgb[2]},0.6)'
                
                fig.add_trace(
                    go.Scatter(
                        x=stats['times'],
                        y=stats['median'],
                        name=f'{source_name} {version} (Median)',
                        line=dict(color=lighter_color, dash=line_style),
                        showlegend=True,
                        hovertemplate=(
                            f'<b>{source_name} {version} (Median)</b><br>' +
                            'Time: %{x}<br>' +
                            'Residual Load: %{y:.0f} MW<br>' +
                            '<extra></extra>'
                        )
                    ),
                    row=1, col=1
                )
            
            # Add confidence interval (TOP/BOTTOM)
            fig.add_trace(
                go.Scatter(
                    x=np.concatenate([stats['times'], stats['times'][::-1]]),
                    y=np.concatenate([stats['top'], stats['bottom'][::-1]]),
                    fill='toself',
                    fillcolor=f'rgba{color[3:-1]},0.08)',
                    line=dict(color='rgba(255,255,255,0)'),
                    name=f'{source_name} {version} Range',
                    showlegend=True,
                    hovertemplate=(
                        f'<b>{source_name} {version} Range</b><br>' +
                        'Time: %{x}<br>' +
                        'Max: %{y:.0f} MW<br>' +
                        '<extra></extra>'
                    )
                ),
                row=1, col=1
            )
    
    # DISABLED: Normal Residual Load calculation is too expensive at render time
    # This was causing UI freeze - needs to be preprocessed instead
    # TODO: Add Normals to preprocess_residual_load() in weather_data_handler.py
    # normal_residual = calculate_normal_residual_load(global_data, country)
    # 
    # if normal_residual is not None and not normal_residual.empty:
    #     # Add normal residual load as a dashed line
    #     fig.add_trace(
    #         go.Scatter(
    #             x=normal_residual.index,
    #             y=normal_residual['NORMAL'],
    #             name='Climate Normal Residual Load',
    #             line=dict(color='rgb(128, 128, 128)', dash='dash', width=3),
    #             showlegend=True,
    #             hovertemplate=(
    #                 '<b>Climate Normal Residual Load</b><br>' +
    #                 'Time: %{x}<br>' +
    #                 'Residual Load: %{y:.0f} MW<br>' +
    #                 '<extra></extra>'
    #             )
    #         ),
    #         row=1, col=1
    #         )
    
    if not plot_data_available:
        logger.warning(f"[RESIDUAL PLOT] No plot data available for {country}")
        fig.add_annotation(
            text=f"No residual load data available for {country}",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14),
            row=1, col=1
        )
    else:
        logger.info(f"[RESIDUAL PLOT] Main plot data added successfully")
    
    # Add run-on-run delta bars to the second subplot - use SELECTED versions only!
    delta_data = _create_residual_load_delta_data(preprocessed_plots, country, forecast_versions)
    
    if delta_data:
        for name, data in delta_data.items():
            fig.add_trace(
                go.Bar(
                    x=data['times'],
                    y=data['values'],
                    name=name,
                    marker_color=data['color'],
                    showlegend=True,
                    hovertemplate=f'<b>{name}</b><br>Time: %{{x}}<br>Change: %{{y:.0f}} MW<br><extra></extra>'
                ),
                row=2, col=1
            )
    else:
        fig.add_annotation(
            text="No run-on-run comparison data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14),
            row=2, col=1
        )
    
    # Update layout
    fig.update_layout(
        height=config['plot_height'],
        showlegend=True,
        legend=dict(
            orientation="v",
            yanchor="top",
            y=1,
            xanchor="left",
            x=1.02,
            groupclick="toggleitem"
        ),
        hovermode='x unified',
        hoverlabel=dict(
            bgcolor='white',
            font_size=12,
            font_family='Arial'
        ),
        template='seaborn'
    )
    
    # Update x-axes
    fig.update_xaxes(
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGrey',
        type='date',
        tickformat='%d %b %H:%M',
        dtick=86400000.0,
        row=1, col=1
    )
    fig.update_xaxes(
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGrey',
        type='date',
        tickformat='%d %b %H:%M',
        dtick=86400000.0,
        row=2, col=1
    )
    
    # Update y-axes
    fig.update_yaxes(
        title='Residual Load (MW)',
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGrey',
        row=1, col=1
    )
    fig.update_yaxes(
        title='Difference (MW)',
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGrey',
        row=2, col=1
    )
    
    # Return combined plot
    logger.info(f"[RESIDUAL PLOT] Returning final plot for {country}")
    return html.Div([
        html.H3('Residual Load (Demand - Wind - Solar)', className='text-center mt-4'),
        html.P(
            'Calculated using matched ensemble members: Demand - Wind - Solar',
            className='text-center text-muted mb-3',
            style={'fontSize': '0.9em'}
        ),
        dcc.Loading(
            id=f"loading-{country}-residual-combined",
            type="circle",
            children=[
        dcc.Graph(figure=fig, config={'responsive': True})
            ]
        )
    ])


def get_plot_cache_key(variable, country, forecast_sources, forecast_versions):
    """Generate a unique key for the plot cache"""
    # Sort sources and versions to ensure consistent keys
    sorted_sources = ','.join(sorted(forecast_sources))
    sorted_versions = ','.join(sorted(forecast_versions))
    return f"{variable}_{country}_{sorted_sources}_{sorted_versions}" 