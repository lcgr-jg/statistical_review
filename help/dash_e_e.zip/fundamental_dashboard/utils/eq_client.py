"""
Energy Quantified client singleton for the Fundamentals Dashboard.

Uses the canonical jain_commods.core.interfaces.energyquantified library
as the sole interface to the EQ API. Provides a shared EQClient instance
and mappings between the dashboard's internal naming conventions
(Kpler-style fuel types, 'UK' country code) and the EQ API conventions.
"""

import logging
import os

logger = logging.getLogger(__name__)

# jain_commods reads EQ_API_KEY on import; on the server the secret is
# exported as EQ_API instead.  Bridge the names before the import fires
# so we don't have to touch jain_commods itself.
if not os.environ.get('EQ_API_KEY') and os.environ.get('EQ_API'):
    os.environ['EQ_API_KEY'] = os.environ['EQ_API']

from jain_commods.core.cache.utils.eq import EQ_API_KEY as _API_KEY
from jain_commods.core.interfaces.energyquantified import EQClient
from jain_commods.core.interfaces.energyquantified.curves import (
    GENERATION_ACTUAL, GENERATION_FORECAST,
    DEMAND_ACTUAL, DEMAND_FORECAST,
    SPOT_PRICE, AVAILABILITY,
    get_curve, list_available_fuels,
)

_client: EQClient | None = None


def get_eq_client() -> EQClient:
    """Return (or lazily create) the module-level EQClient."""
    global _client
    if _client is None:
        if not _API_KEY:
            logger.warning(
                "EQ_API_KEY is empty; EQ fetches will likely fail as "
                "'curve not found'.  Set EQ_API_KEY (or EQ_API) in the "
                "environment before launching."
            )
        logger.info("Initialising EQClient...")
        _client = EQClient(api_key=_API_KEY, timeout=60.0)
        logger.info("EQClient ready")
    return _client


# ── Country code translation ────────────────────────────────────────────────
# Dashboard pages use 'UK'; EQ uses 'GB'.
COUNTRY_TO_EQ = {
    'UK': 'GB',
    'DE': 'DE',
    'FR': 'FR',
    'NL': 'NL',
    'BE': 'BE',
    'ES': 'ES',
    'IT': 'IT',
}
EQ_TO_COUNTRY = {v: k for k, v in COUNTRY_TO_EQ.items()}
EQ_TO_COUNTRY['GB'] = 'UK'  # keep GB→UK for display

DASHBOARD_COUNTRIES = ['DE', 'FR', 'UK', 'NL', 'BE', 'ES']

# ── Fuel-type translation ───────────────────────────────────────────────────
# Kpler-style name → EQ curve key
FUEL_KPLER_TO_EQ = {
    'fossil gas': 'gas',
    'fossil hard coal': 'coal',
    'nuclear': 'nuclear',
    'fossil brown coal/lignite': 'lignite',
    'fossil oil': 'oil',
    'hydro pumped storage': 'hydro_pumped',
    'hydro run-of-river and poundage': 'hydro_ror',
    'hydro water reservoir': 'hydro_reservoir',
    'biomass': 'biomass',
    'gas ccgt': 'gas_ccgt',
    'gas ocgt': 'gas_ocgt',
    'wind': 'wind',
    'wind onshore': 'wind_onshore',
    'wind offshore': 'wind_offshore',
    'solar': 'solar',
    'other': 'other',
}
FUEL_EQ_TO_KPLER = {v: k for k, v in FUEL_KPLER_TO_EQ.items()}
FUEL_EQ_TO_KPLER.update({
    'gas_ccgt': 'gas ccgt',
    'gas_ocgt': 'gas ocgt',
    'hydro': 'hydro',
    'thermal': 'thermal',
    'hydro_reservoir': 'hydro water reservoir',
    'geothermal': 'geothermal',
    'solar_thermal': 'solar thermal',
})

MAIN_FUEL_EQ_KEYS = ['gas', 'coal', 'nuclear', 'lignite']

FUEL_DISPLAY_LABELS = {
    'gas': 'Fossil Gas',
    'coal': 'Hard Coal',
    'nuclear': 'Nuclear',
    'lignite': 'Lignite',
    'oil': 'Oil',
    'hydro_pumped': 'Hydro Pumped',
    'hydro_ror': 'Hydro RoR',
    'hydro_reservoir': 'Hydro Reservoir',
    'biomass': 'Biomass',
    'wind': 'Wind',
    'solar': 'Solar',
    'gas_ccgt': 'Gas CCGT',
    'gas_ocgt': 'Gas OCGT',
    'other': 'Other',
}


def eq_area(dashboard_country: str) -> str:
    """Convert a dashboard country code to an EQ area tag."""
    return COUNTRY_TO_EQ.get(dashboard_country, dashboard_country)


def dashboard_country(eq_area_tag: str) -> str:
    """Convert an EQ area tag back to the dashboard country code."""
    return EQ_TO_COUNTRY.get(eq_area_tag, eq_area_tag)


def kpler_fuel(eq_fuel: str) -> str:
    """Convert an EQ fuel key to the Kpler-style fuel name used in the dashboard."""
    return FUEL_EQ_TO_KPLER.get(eq_fuel, eq_fuel)


def eq_fuel(kpler_name: str) -> str:
    """Convert a Kpler-style fuel name to the EQ curve key."""
    return FUEL_KPLER_TO_EQ.get(kpler_name, kpler_name)
