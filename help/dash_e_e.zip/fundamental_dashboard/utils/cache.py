"""Permanent in-memory cache for query results.

Data is fetched once and held forever until explicitly cleared
via a page refresh button.
"""
import logging
import threading
from functools import wraps

logger = logging.getLogger(__name__)

_cache = {}
_cache_lock = threading.Lock()


def cached(fn):
    """Decorator that caches return values permanently (until manual clear)."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        key = (fn.__module__, fn.__qualname__, args, tuple(sorted(kwargs.items())))
        with _cache_lock:
            if key in _cache:
                return _cache[key]
        result = fn(*args, **kwargs)
        with _cache_lock:
            _cache[key] = result
        return result
    wrapper.cache_clear = lambda: _clear_fn_cache(fn)
    return wrapper


def _clear_fn_cache(fn):
    """Remove all entries for a specific function."""
    prefix = (fn.__module__, fn.__qualname__)
    with _cache_lock:
        for k in [k for k in _cache if k[:2] == prefix]:
            del _cache[k]


def clear_all():
    """Drop the entire cache (called by refresh buttons)."""
    with _cache_lock:
        n = len(_cache)
        _cache.clear()
    logger.info("Cache cleared (%d entries dropped)", n)
