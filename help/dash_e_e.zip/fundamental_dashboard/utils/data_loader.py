import pandas as pd
from datetime import datetime, timedelta
from jain_commods.core.interfaces.snowflake.kplerpowerquery import KplerPowerQuery
import concurrent.futures
import time
import threading

class DataHandler:
    def __init__(self):
        self.kpler = KplerPowerQuery(role='FR_COMMOD_PM_EU')
        self.global_data = {
            'combined_multi_index_df': None,
            'filtered_availability_merge': None,
            'last_update': None,
            'processed_data': {},
        }
        self.figure_cache = {}
        
        # Initialize data
        self.load_initial_data()
        self.reload_latest_data()
        self.schedule_next_refresh()
    
    def get_countries(self):
        """Return list of countries"""
        if 'filtered_availability_merge' not in self.global_data or self.global_data['filtered_availability_merge'] is None:
            return []
            
        countries = sorted(self.global_data['filtered_availability_merge']['COUNTRY'].unique().tolist())
        # Ensure the major countries are at the front
        priority_countries = ['DE', 'FR', 'NL', 'BE', 'UK']
        result = []
        for country in priority_countries:
            if country in countries:
                result.append(country)
                countries.remove(country)
        # Add all other countries
        result.extend(countries)
        return result
    
    def get_fuel_types(self, country=None):
        """Return list of fuel types, optionally filtered by country"""
        if 'filtered_availability_merge' not in self.global_data or self.global_data['filtered_availability_merge'] is None:
            return []
            
        if country:
            return sorted(self.global_data['filtered_availability_merge'][
                self.global_data['filtered_availability_merge']['COUNTRY'] == country
            ]['FUEL_TYPE'].unique().tolist())
        return sorted(self.global_data['filtered_availability_merge']['FUEL_TYPE'].unique().tolist())
    
    def get_main_fuel_types(self):
        """Return the main fuel types that should have dedicated charts"""
        return ['fossil gas', 'fossil hard coal', 'nuclear', 'fossil brown coal/lignite']
    
    def get_other_fuel_types(self, country):
        """Return fuel types that aren't in the main category for a country"""
        main_types = self.get_main_fuel_types()
        country_types = self.get_fuel_types(country)
        return [ft for ft in country_types if ft not in main_types]
    
    def get_availability_data(self, country, fuel_type):
        """Get availability data for multiple as_of dates for a country and fuel type"""
        if ('processed_data' in self.global_data and 
            country in self.global_data['processed_data'] and 
            fuel_type in self.global_data['processed_data'][country] and
            'availability' in self.global_data['processed_data'][country][fuel_type]):
            return self.global_data['processed_data'][country][fuel_type]['availability']
        
        if 'combined_multi_index_df' not in self.global_data or self.global_data['combined_multi_index_df'] is None:
            return pd.DataFrame()
            
        df = self.global_data['combined_multi_index_df'].reset_index()
        return df[
            (df['COUNTRY'] == country) & 
            (df['FUEL_TYPE'] == fuel_type)
        ]
    
    def get_merged_data(self, country, fuel_type):
        """Get merged data (availability + generation) for a country and fuel type"""
        if ('processed_data' in self.global_data and 
            country in self.global_data['processed_data'] and 
            fuel_type in self.global_data['processed_data'][country] and
            'merged' in self.global_data['processed_data'][country][fuel_type]):
            return self.global_data['processed_data'][country][fuel_type]['merged']
        
        if 'filtered_availability_merge' not in self.global_data or self.global_data['filtered_availability_merge'] is None:
            return pd.DataFrame()
            
        return self.global_data['filtered_availability_merge'][
            (self.global_data['filtered_availability_merge']['COUNTRY'] == country) & 
            (self.global_data['filtered_availability_merge']['FUEL_TYPE'] == fuel_type)
        ]
    
    def get_last_update_time(self):
        """Return the timestamp of the last data update"""
        return self.global_data.get('last_update')
    
    def load_initial_data(self):
        """Load initial historical data"""
        print(f"Loading initial data at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        start_time = time.time()
        
        # Define the functions for parallel execution
        def get_historical_availability():
            print("Fetching historical availability data...")
            data = self.kpler.get_availability_by_fueltype(
                start_date=datetime.now().replace(hour=0, minute=0, second=0, microsecond=0),
                end_date=datetime(datetime.now().year + 1, 12, 31, 23, 59, 59),
                as_of=self._get_as_of_dates()
            )
            return data[~data.FUEL_TYPE.isin(self._get_renewable_types())]
        
        def get_day_ahead_availability():
            print("Fetching day ahead availability data...")
            historical_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=180)
            data = self.kpler.get_day_ahead_availability_by_fueltype(
                start_date=historical_start,
                end_date=datetime(datetime.now().year + 1, 12, 31, 23, 59, 59),
            )
            return data
        
        # Execute the functions in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future_historical_avail = executor.submit(get_historical_availability)
            future_day_ahead_avail = executor.submit(get_day_ahead_availability)
            
            # Get results
            availability_as_of = future_historical_avail.result()
            day_ahead_availability = future_day_ahead_avail.result()
        
        # Process the data
        self._process_availability_data(availability_as_of, day_ahead_availability)
        
        end_time = time.time()
        print(f"Initial data loading completed in {end_time - start_time:.2f} seconds")
    
    def reload_latest_data(self):
        """Reload latest data"""
        print(f"Reloading latest data at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        start_time = time.time()
        
        # Define the functions for parallel execution
        def get_latest_availability():
            print("Fetching latest availability data...")
            data = self.kpler.get_availability_by_fueltype(
                start_date=datetime.now().replace(hour=0, minute=0, second=0, microsecond=0),
                end_date=datetime(datetime.now().year + 1, 12, 31, 23, 59, 59),
                as_of='latest'
            )
            return data[~data.FUEL_TYPE.isin(self._get_renewable_types())]
        
        def get_generation():
            print("Fetching generation data...")
            historical_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=180)
            data = self.kpler.get_generation_by_fueltype(
                start_date=historical_start,
                end_date=datetime(datetime.now().year + 1, 12, 31, 23, 59, 59),
            )
            return data
        
        # Execute the functions in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future_latest_avail = executor.submit(get_latest_availability)
            future_generation = executor.submit(get_generation)
            
            # Get results
            latest_availability_date = future_latest_avail.result()
            generation_data = future_generation.result()
        
        # Process the data
        self._process_latest_data(latest_availability_date, generation_data)
        
        end_time = time.time()
        print(f"Latest data reload completed in {end_time - start_time:.2f} seconds")
    
    def schedule_next_refresh(self):
        """Schedule the next data refresh"""
        now = datetime.now()
        
        # Define the next refresh time (next XX:30)
        if now.minute >= 30:
            next_refresh = now.replace(hour=now.hour+1, minute=30, second=0, microsecond=0)
        else:
            next_refresh = now.replace(minute=30, second=0, microsecond=0)
        
        # Handle day rollover
        if next_refresh < now:
            next_refresh = next_refresh + timedelta(days=1)
        
        # Calculate seconds until next refresh
        seconds_until_refresh = (next_refresh - now).total_seconds()
        
        print(f"Next data refresh scheduled for {next_refresh.strftime('%Y-%m-%d %H:%M:%S')} "
              f"({seconds_until_refresh:.0f} seconds from now)")
        
        # Schedule the refresh
        refresh_thread = threading.Timer(seconds_until_refresh, self._refresh_data_and_reschedule)
        refresh_thread.daemon = True
        refresh_thread.start()
    
    def _refresh_data_and_reschedule(self):
        """Refresh data and schedule next refresh"""
        try:
            self.reload_latest_data()
        except Exception as e:
            print(f"Error refreshing data: {e}")
        
        self.schedule_next_refresh()
    
    def _get_as_of_dates(self):
        """Get list of as_of dates"""
        now = datetime.now()
        latest_hour = now.replace(minute=0, second=0, microsecond=0)
        return [
            latest_hour - timedelta(days=1),
            (latest_hour - timedelta(weeks=1)).replace(hour=10, minute=0, second=0, microsecond=0),
            (latest_hour - timedelta(days=31)).replace(hour=10, minute=0, second=0, microsecond=0),
        ]
    
    def _get_renewable_types(self):
        """Get list of renewable types to exclude"""
        return [
            'wind onshore', 
            'wind offshore', 
            'solar', 
            'marine', 
            'hydro run-of-river and poundage',
            'hydro pumped storage',
            'hydro water reservoir'
        ]
    
    def _process_availability_data(self, availability_as_of, day_ahead_availability):
        """Process availability data"""
        # Create historical multi-index DataFrame
        multi_index_df = availability_as_of.set_index(['AS_OF', 'COUNTRY'])
        multi_index_df = multi_index_df.sort_index()
        
        # Filter day ahead availability
        filtered_availability = day_ahead_availability.copy()
        filtered_availability['PROVIDER_PREFERENCE'] = filtered_availability['PROVIDER'].apply(
            lambda x: self._get_availability_provider_preference(x)
        )
        filtered_availability = filtered_availability.sort_values(
            by=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'PROVIDER_PREFERENCE']
        )
        filtered_availability = filtered_availability.drop_duplicates(
            subset=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'], 
            keep='first'
        )
        filtered_availability = filtered_availability.drop(columns=['PROVIDER_PREFERENCE'])
        filtered_availability = filtered_availability[~filtered_availability['FUEL_TYPE'].isin(self._get_renewable_types())]
        
        # Store the historical data
        self.global_data['historical_multi_index_df'] = multi_index_df
        self.global_data['filtered_availability'] = filtered_availability
    
    def _process_latest_data(self, latest_availability_date, generation_data):
        """Process latest data"""
        try:
            # Process latest availability data
            latest_availability_date['AS_OF'] = 'latest'
            latest_multi_index = latest_availability_date.set_index(['AS_OF', 'COUNTRY'])
            
            # Combine with historical data
            if 'historical_multi_index_df' in self.global_data and self.global_data['historical_multi_index_df'] is not None:
                combined_multi_index_df = pd.concat([self.global_data['historical_multi_index_df'], latest_multi_index])
                combined_multi_index_df = combined_multi_index_df.sort_index()
                self.global_data['combined_multi_index_df'] = combined_multi_index_df
            
            # Process generation data
            filtered_generation = generation_data.copy()
            filtered_generation['PROVIDER_PREFERENCE'] = filtered_generation['PROVIDER'].apply(
                lambda x: self._get_generation_provider_preference(x)
            )
            filtered_generation = filtered_generation.sort_values(
                by=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'PROVIDER_PREFERENCE']
            )
            filtered_generation = filtered_generation.drop_duplicates(
                subset=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'], 
                keep='first'
            )
            filtered_generation = filtered_generation.drop(columns=['PROVIDER_PREFERENCE'])
            filtered_generation = filtered_generation[~filtered_generation['FUEL_TYPE'].isin(self._get_renewable_types())]
            
            # Merge generation and availability data
            if 'filtered_availability' in self.global_data and self.global_data['filtered_availability'] is not None:
                generation_columns = ['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'GENERATION']
                generation_to_merge = filtered_generation[generation_columns].copy()
                
                filtered_availability_merge = self.global_data['filtered_availability'].merge(
                    generation_to_merge,
                    on=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'],
                    how='left'
                )
                
                # Clear the figure cache when data is updated
                self.figure_cache.clear()
                
                # Update global data
                self.global_data['filtered_availability_merge'] = filtered_availability_merge
                self.global_data['last_update'] = datetime.now()
                
                # Pre-process data for countries
                self._preprocess_data_for_countries()
        
        except Exception as e:
            print(f"Error processing latest data: {e}")
    
    def _preprocess_data_for_countries(self):
        """Pre-process data for each country and fuel type"""
        print("Pre-processing data for countries...")
        
        if ('combined_multi_index_df' not in self.global_data or 
            self.global_data['combined_multi_index_df'] is None or 
            'filtered_availability_merge' not in self.global_data or 
            self.global_data['filtered_availability_merge'] is None):
            print("Cannot pre-process data - data not loaded yet")
            return
        
        # Reset processed data
        self.global_data['processed_data'] = {}
        
        # Get all countries
        all_countries = self.global_data['filtered_availability_merge']['COUNTRY'].unique()
        
        # Pre-process data for each country
        for country in all_countries:
            # Get all fuel types for this country
            country_fuel_types = self.global_data['filtered_availability_merge'][
                self.global_data['filtered_availability_merge']['COUNTRY'] == country
            ]['FUEL_TYPE'].unique()
            
            # Initialize country data
            self.global_data['processed_data'][country] = {}
            
            # Get availability data for each fuel type
            avail_df = self.global_data['combined_multi_index_df'].reset_index()
            avail_df_country = avail_df[avail_df['COUNTRY'] == country]
            
            # Get merged data for this country
            merged_df_country = self.global_data['filtered_availability_merge'][
                self.global_data['filtered_availability_merge']['COUNTRY'] == country
            ]
            
            # Pre-process data for each fuel type
            for fuel_type in country_fuel_types:
                # Get availability data for this fuel type
                avail_data = avail_df_country[avail_df_country['FUEL_TYPE'] == fuel_type]
                # Get merged data for this fuel type
                merged_data = merged_df_country[merged_df_country['FUEL_TYPE'] == fuel_type]
                
                # Store the pre-processed data
                self.global_data['processed_data'][country][fuel_type] = {
                    'availability': avail_data,
                    'merged': merged_data
                }
        
        print("Data pre-processing completed")
    
    def _get_generation_provider_preference(self, provider):
        """Get provider preference for generation data"""
        preferences = {
            'eex': 1,
            'rte': 2,
            'bmrs': 3,
            'elexon': 4,
            'entsoe': 4,
            'kpler': 5,
        }
        return preferences.get(provider.lower(), 999)
    
    def _get_availability_provider_preference(self, provider):
        """Get provider preference for availability data"""
        preferences = {
            'bmrs': 1,
            'elexon': 2,
            'rte': 3,
            'eex': 4,
            'entsoe': 5,
            'kpler': 6,
        }
        return preferences.get(provider.lower(), 999)
    
    def get_data_coverage(self):
        """Return the percentage of countries with available data"""
        if 'filtered_availability_merge' not in self.global_data or self.global_data['filtered_availability_merge'] is None:
            return 0.0
            
        # Get unique countries with data
        countries_with_data = self.global_data['filtered_availability_merge']['COUNTRY'].nunique()
        
        # Get total expected countries (major countries)
        total_expected_countries = 5  # DE, FR, NL, BE, UK
        
        # Calculate coverage percentage
        coverage = (countries_with_data / total_expected_countries) * 100
        return min(coverage, 100.0)  # Cap at 100%
        
    def get_total_capacity(self):
        """Return the total capacity across all countries and fuel types"""
        if 'filtered_availability_merge' not in self.global_data or self.global_data['filtered_availability_merge'] is None:
            return 0
            
        # Get latest data
        latest_data = self.global_data['filtered_availability_merge'][
            self.global_data['filtered_availability_merge']['AS_OF'] == 'latest'
        ]
        
        if latest_data.empty:
            return 0
            
        # Sum up capacity across all countries and fuel types
        total_capacity = latest_data['AVAILABILITY_AMOUNT'].sum()
        return total_capacity 