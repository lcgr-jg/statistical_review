import pandas as pd
import numpy as np
import logging
import time
from datetime import datetime, timedelta
import concurrent.futures

# Set up logging
logger = logging.getLogger(__name__)

def _should_skip_release(date, release):
    """Check if a release should be skipped based on time of day"""
    current_hour = datetime.now().hour
    current_date = datetime.now().date()
    date_to_compare = date
    if hasattr(date, 'date'):
        date_to_compare = date.date()
    elif isinstance(date, str):
        date_to_compare = pd.to_datetime(date).date()
        
    return release == "12" and date_to_compare == current_date and current_hour < 19

# Helper function to safely convert float64 columns to float32, skipping timestamp columns
def _safe_convert_float64_to_float32(df):
    """
    Safely convert float64 columns to float32, skipping timestamp columns.
    Makes a copy to avoid modifying the original DataFrame.
    """
    if df is None or df.empty:
        return df
        
    df_copy = df.copy()
    
    # Identify timestamp columns (both actual datetime columns and columns with time-related names)
    datetime_cols = df_copy.select_dtypes(include=['datetime64']).columns.tolist()
    time_related_cols = [col for col in df_copy.columns if any(time_term in col.lower() for time_term in ['time', 'date', 'timestamp'])]
    
    # Get all float64 columns
    float64_cols = df_copy.select_dtypes(include=['float64']).columns.tolist()
    
    # Only convert columns that are float64 and not time-related
    safe_float64_cols = [col for col in float64_cols if col not in datetime_cols and col not in time_related_cols]
    
    # Convert safe float64 columns to float32
    for col in safe_float64_cols:
        df_copy[col] = df_copy[col].astype('float32')
    
    return df_copy

def _fetch_normals_data(mq, countries, variables, dates, releases):
    """Helper function to fetch normals data specifically"""
    logger.info(f"Fetching normals data for {len(countries)} countries, {len(variables)} variables")
    results = []
    
    # For normals, set date range from today to 15 days in the future
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    end_date = today + timedelta(days=15)
    
    # Use a single date/release for normals as they're not relevant
    date = dates[0]
    release = releases[0]
    
    try:
        # Fetch all variables in a single query to reduce overhead
        logger.info(f"Fetching normals for all variables")
        
        # PowerDemand variables
        if 'PowerDemand' in variables:
            forecast_data = mq.get_normals(
                country=countries,
                category='PowerDemand',
                from_datetime=today,
                to_datetime=end_date,
                debug=False  # Reduce debug logging
            )
            
            # Distribute results
            if forecast_data is not None and not forecast_data.empty and 'COUNTRY' in forecast_data.columns:
                country_groups = forecast_data.groupby('COUNTRY')
                for country, country_data in country_groups:
                    if country in countries:
                        # Convert float64 to float32
                        country_data = _safe_convert_float64_to_float32(country_data)
                        results.append(("Normals", country, 'PowerDemand', date, release, country_data))
            else:
                for country in countries:
                    results.append(("Normals", country, 'PowerDemand', date, release, pd.DataFrame()))
        
        # Non-PowerDemand variables (Wind, PV)
        other_vars = [v for v in variables if v != 'PowerDemand']
        if other_vars:
            forecast_data = mq.get_normals(
                country=countries,
                fuel_type=other_vars,
                from_datetime=today,
                to_datetime=end_date,
                debug=False  # Reduce debug logging
            )
            
            # Distribute results
            if forecast_data is not None and not forecast_data.empty:
                if 'COUNTRY' in forecast_data.columns and 'FUEL_TYPE' in forecast_data.columns:
                    grouped = forecast_data.groupby(['COUNTRY', 'FUEL_TYPE'])
                    for (country, fuel_type), group_data in grouped:
                        if country in countries and fuel_type in other_vars:
                            # Convert float64 to float32
                            group_data = _safe_convert_float64_to_float32(group_data)
                            results.append(("Normals", country, fuel_type, date, release, group_data))
                else:
                    for country in countries:
                        for variable in other_vars:
                            results.append(("Normals", country, variable, date, release, pd.DataFrame()))
            else:
                for country in countries:
                    for variable in other_vars:
                        results.append(("Normals", country, variable, date, release, pd.DataFrame()))
    except Exception as e:
        logger.error(f"Error fetching normals data: {str(e)}", exc_info=True)
        for country in countries:
            for variable in variables:
                results.append(("Normals", country, variable, date, release, {"error": str(e), "status": "failed"}))
    
    return results

def _filter_meteologica_data(forecast_data, date, release, offset):
    """Helper to filter Meteologica data consistently"""
    if forecast_data is None or (hasattr(forecast_data, 'empty') and forecast_data.empty) or (not hasattr(forecast_data, 'columns') or 'UPDATE_ID' not in forecast_data.columns):
        return forecast_data
        
    # Build expected format
    expected_format = f"{date.strftime('%Y%m%d')}{release.ljust(4, '0')}_{offset}"
    
    # Check if any rows match our expected format before filtering
    matching_rows = forecast_data[forecast_data['UPDATE_ID'] == expected_format]
    if len(matching_rows) == 0:
        # Look for any UPDATE_IDs that contain our date and release
        date_release_prefix = f"{date.strftime('%Y%m%d')}{release.ljust(4, '0')}"
        all_update_ids = forecast_data['UPDATE_ID'].unique()
        matching_prefix = [uid for uid in all_update_ids if uid.startswith(date_release_prefix)]
        if matching_prefix:
            # Try to use the first matching one instead
            if len(matching_prefix) == 1:
                expected_format = matching_prefix[0]
    
    # Exact match filtering - no suffix allowed
    forecast_data = forecast_data[forecast_data['UPDATE_ID'] == expected_format]
    
    # Filter by FREQUENCY to only keep 15min data
    if not forecast_data.empty and 'FREQUENCY' in forecast_data.columns:
        # Filter to keep only 15min data
        forecast_data = forecast_data[forecast_data['FREQUENCY'] == '15min']
    
    return forecast_data

def _fetch_meteologica_data(mq, countries, variables, dates, releases, query_timeout=30, query_retries=2):
    """Helper function to fetch Meteologica data specifically"""
    logger.info(f"Fetching Meteologica data for {len(countries)} countries, {len(variables)} variables")
    results = []
    offset = "post_ECMWF-ENS"
    
    # Create a list of date+release combinations for parallel processing
    date_release_combos = [(date, release) for date in dates for release in releases 
                          if not _should_skip_release(date, release)]
    
    # Use ThreadPoolExecutor to parallelize queries
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(date_release_combos))) as executor:
        futures = []
        
        # Submit PowerDemand queries
        if 'PowerDemand' in variables:
            for date, release in date_release_combos:
                futures.append(executor.submit(
                    _fetch_meteologica_single_query,
                    mq=mq,
                    date=date,
                    release=release,
                    offset=offset,
                    countries=countries,
                    is_power_demand=True,
                    variables=None,
                    query_timeout=query_timeout,
                    query_retries=query_retries
                ))
        
        # Submit other variables queries
        other_vars = [v for v in variables if v != 'PowerDemand']
        if other_vars:
            for date, release in date_release_combos:
                futures.append(executor.submit(
                    _fetch_meteologica_single_query,
                    mq=mq,
                    date=date,
                    release=release,
                    offset=offset,
                    countries=countries,
                    is_power_demand=False,
                    variables=other_vars,
                    query_timeout=query_timeout,
                    query_retries=query_retries
                ))
        
        # Process results as they complete
        for future in concurrent.futures.as_completed(futures):
            try:
                query_results = future.result()
                if query_results:
                    results.extend(query_results)
            except Exception as e:
                logger.error(f"Error processing Meteologica query: {str(e)}")
    
    return results

def _fetch_meteologica_single_query(mq, date, release, offset, countries, is_power_demand, variables, query_timeout, query_retries):
    """Helper to fetch a single Meteologica query with retry logic"""
    results = []
    query_method = mq.get_meteologica_forecast
    
    for retry in range(query_retries + 1):
        try:
            logger.info(f"Fetching Meteologica {'PowerDemand' if is_power_demand else 'fuel types'} for {date}_{release} (attempt {retry+1})")
            
            # Prepare query parameters
            query_params = {
                'issue_date': date,
                'release': release,
                'offset': offset,
                'country': countries,
                'debug': False
            }
            
            if is_power_demand:
                query_params['category'] = 'PowerDemand'
            else:
                query_params['fuel_type'] = variables
            
            # Execute query with timeout
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(query_method, **query_params)
                try:
                    forecast_data = future.result(timeout=query_timeout)
                except concurrent.futures.TimeoutError:
                    logger.error(f"Meteologica query timed out after {query_timeout} seconds")
                    if retry < query_retries:
                        backoff_time = (retry + 1) * 2
                        time.sleep(backoff_time)
                    continue
            
            # Filter data
            forecast_data = _filter_meteologica_data(forecast_data, date, release, offset)
            
            # Distribute results
            if forecast_data is not None and not forecast_data.empty:
                # Convert float64 to float32
                forecast_data = _safe_convert_float64_to_float32(forecast_data)
                    
                if is_power_demand and 'COUNTRY' in forecast_data.columns:
                    country_groups = forecast_data.groupby('COUNTRY')
                    for country, country_data in country_groups:
                        if country in countries:
                            results.append(("Meteologica", country, 'PowerDemand', date, release, country_data))
                elif not is_power_demand and 'COUNTRY' in forecast_data.columns and 'FUEL_TYPE' in forecast_data.columns:
                    grouped = forecast_data.groupby(['COUNTRY', 'FUEL_TYPE'])
                    for (country, fuel_type), group_data in grouped:
                        if country in countries and fuel_type in variables:
                            results.append(("Meteologica", country, fuel_type, date, release, group_data))
            
            # If we got results, we're done
            if results:
                break
                
            # If no results and not the last retry, wait and try again
            if retry < query_retries:
                backoff_time = (retry + 1) * 2
                logger.warning(f"No valid Meteologica data, retrying in {backoff_time}s")
                time.sleep(backoff_time)
                
        except Exception as e:
            logger.error(f"Error in Meteologica query attempt {retry+1}: {str(e)}")
            if retry < query_retries:
                backoff_time = (retry + 1) * 2
                time.sleep(backoff_time)
    
    # If we still don't have results, return empty dataframes
    if not results:
        for country in countries:
            if is_power_demand:
                results.append(("Meteologica", country, 'PowerDemand', date, release, pd.DataFrame()))
            else:
                for variable in variables:
                    results.append(("Meteologica", country, variable, date, release, pd.DataFrame()))
    
    return results

def _fetch_hres_data(mq, countries, variables, dates, releases, query_timeout=30, query_retries=2):
    """Helper function to fetch HRES data specifically"""
    logger.info(f"Fetching HRES data for {len(countries)} countries, {len(variables)} variables")
    results = []
    
    # Create a list of date+release combinations for parallel processing
    date_release_combos = [(date, release) for date in dates for release in releases 
                          if not _should_skip_release(date, release)]
    
    # Use ThreadPoolExecutor to parallelize queries
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(date_release_combos))) as executor:
        futures = []
        
        # Skip PowerDemand queries for HRES
        if 'PowerDemand' in variables:
            for date, release in date_release_combos:
                for country in countries:
                    results.append(("ECMWF-HRES", country, 'PowerDemand', date, release, pd.DataFrame()))
        
        # Submit other variables queries
        other_vars = [v for v in variables if v != 'PowerDemand']
        if other_vars:
            for date, release in date_release_combos:
                futures.append(executor.submit(
                    _fetch_hres_single_query,
                    mq=mq,
                    date=date,
                    release=release,
                    countries=countries,
                    variables=other_vars,
                    query_timeout=query_timeout,
                    query_retries=query_retries
                ))
        
        # Process results as they complete
        for future in concurrent.futures.as_completed(futures):
            try:
                query_results = future.result()
                if query_results:
                    results.extend(query_results)
            except Exception as e:
                logger.error(f"Error processing HRES query: {str(e)}")
    
    return results

def _fetch_hres_single_query(mq, date, release, countries, variables, query_timeout, query_retries):
    """Helper to fetch a single HRES query with retry logic"""
    results = []
    
    for retry in range(query_retries + 1):
        try:
            logger.info(f"Fetching HRES data for {date}_{release} (attempt {retry+1})")
            
            # Execute query with timeout
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(
                    mq.get_deterministic_forecast,
                    issue_date=date,
                    release=release,
                    country=countries,
                    fuel_type=variables,
                    forecast_source="ECMWF-HRES"
                )
                try:
                    forecast_data = future.result(timeout=query_timeout)
                except concurrent.futures.TimeoutError:
                    logger.error(f"HRES query timed out after {query_timeout} seconds")
                    if retry < query_retries:
                        backoff_time = (retry + 1) * 2
                        time.sleep(backoff_time)
                    continue
            
            # Filter by expected UPDATE_ID format
            if forecast_data is not None and not forecast_data.empty and 'UPDATE_ID' in forecast_data.columns:
                expected_format = f"{date.strftime('%Y%m%d')}{release.ljust(4, '0')}"
                forecast_data = forecast_data[forecast_data['UPDATE_ID'] == expected_format]
                
                # Convert float64 to float32
                forecast_data = _safe_convert_float64_to_float32(forecast_data)
            
            # Distribute results
            if forecast_data is not None and not forecast_data.empty:
                if 'COUNTRY' in forecast_data.columns and 'FUEL_TYPE' in forecast_data.columns:
                    grouped = forecast_data.groupby(['COUNTRY', 'FUEL_TYPE'])
                    for (country, fuel_type), group_data in grouped:
                        if country in countries and fuel_type in variables:
                            results.append(("ECMWF-HRES", country, fuel_type, date, release, group_data))
            
            # If we got results, we're done
            if results:
                break
                
            # If no results and not the last retry, wait and try again
            if retry < query_retries:
                backoff_time = (retry + 1) * 2
                logger.warning(f"No valid HRES data, retrying in {backoff_time}s")
                time.sleep(backoff_time)
                
        except Exception as e:
            logger.error(f"Error in HRES query attempt {retry+1}: {str(e)}")
            if retry < query_retries:
                backoff_time = (retry + 1) * 2
                time.sleep(backoff_time)
    
    # If we still don't have results, return empty dataframes
    if not results:
        for country in countries:
            for variable in variables:
                results.append(("ECMWF-HRES", country, variable, date, release, pd.DataFrame()))
    
    return results

def _fetch_ensemble_data(mq, source, countries, variables, dates, releases, query_timeout=30, query_retries=2):
    """Helper function to fetch ensemble forecast data (ENS, GEFS) with improved parallelization"""
    logger.info(f"Fetching ensemble data for {source}")
    results = []
    
    # Create a list of date+release combinations for parallel processing
    date_release_combos = [(date, release) for date in dates for release in releases 
                          if not _should_skip_release(date, release)]
    
    # Use ThreadPoolExecutor to parallelize queries
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(date_release_combos))) as executor:
        futures = []
        
        # Submit PowerDemand queries
        if 'PowerDemand' in variables and source != "GEFS":  # Skip for GEFS
            for date, release in date_release_combos:
                futures.append(executor.submit(
                    _fetch_ensemble_single_query,
                    mq=mq,
                    source=source,
                    date=date,
                    release=release,
                    countries=countries,
                    is_power_demand=True,
                    variables=None,
                    query_timeout=query_timeout,
                    query_retries=query_retries
                ))
        elif 'PowerDemand' in variables:  # For GEFS, just add empty results
            for date, release in date_release_combos:
                for country in countries:
                    results.append((source, country, 'PowerDemand', date, release, pd.DataFrame()))
        
        # Submit other variables queries
        other_vars = [v for v in variables if v != 'PowerDemand']
        if other_vars:
            for date, release in date_release_combos:
                futures.append(executor.submit(
                    _fetch_ensemble_single_query,
                    mq=mq,
                    source=source,
                    date=date,
                    release=release,
                    countries=countries,
                    is_power_demand=False,
                    variables=other_vars,
                    query_timeout=query_timeout,
                    query_retries=query_retries
                ))
        
        # Process results as they complete
        for future in concurrent.futures.as_completed(futures):
            try:
                query_results = future.result()
                if query_results:
                    results.extend(query_results)
            except Exception as e:
                logger.error(f"Error processing ensemble query: {str(e)}")
    
    return results

def _fetch_ensemble_single_query(mq, source, date, release, countries, is_power_demand, variables, query_timeout, query_retries):
    """Helper to fetch a single ensemble forecast query with retry logic.
    
    This function implements an exponential backoff retry strategy for fetching
    ensemble forecast data from Snowflake/Meteologica database.
    
    Args:
        mq: MeteologicaQuery instance for database access
        source: Forecast source name (e.g., 'ECMWF-ENS', 'GEFS')
        date: Issue date of the forecast
        release: Release time (e.g., '00', '12')
        countries: List of country codes to fetch
        is_power_demand: Boolean indicating if fetching PowerDemand category
        variables: List of fuel types/variables (ignored if is_power_demand=True)
        query_timeout: Maximum seconds to wait for query response
        query_retries: Number of retry attempts on failure
    
    Returns:
        List of tuples: (source, country, variable, date, release, dataframe)
        Empty DataFrames returned if query fails after all retries
    
    Retry Strategy:
        - Timeouts trigger immediate retry with exponential backoff
        - Empty results also trigger retry
        - Backoff time = (retry_attempt + 1) * 2 seconds
        - After final retry, returns empty DataFrames rather than raising errors
    
    Success Criteria:
        - Query completes within timeout period
        - Returned data is not None and not empty
        - UPDATE_ID matches expected format (YYYYMMDDHHMMSS)
    """
    results = []
    
    for retry in range(query_retries + 1):
        try:
            logger.info(f"Fetching {source} {'PowerDemand' if is_power_demand else 'fuel types'} for {date}_{release} (attempt {retry+1})")
            
            # Prepare query parameters
            query_params = {
                'issue_date': date,
                'release': release,
                'country': countries,
                'forecast_source': source
            }
            
            if is_power_demand:
                query_params['category'] = 'PowerDemand'
            else:
                query_params['fuel_type'] = variables
            
            # Execute query with timeout
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(
                    mq.get_ensemble_forecast,
                    **query_params
                )
                try:
                    forecast_data = future.result(timeout=query_timeout)
                except concurrent.futures.TimeoutError:
                    logger.error(f"Query timed out after {query_timeout} seconds")
                    if retry < query_retries:
                        backoff_time = (retry + 1) * 2
                        time.sleep(backoff_time)
                    continue
            
            # Filter by expected UPDATE_ID format
            if forecast_data is not None and not forecast_data.empty and 'UPDATE_ID' in forecast_data.columns:
                expected_format = f"{date.strftime('%Y%m%d')}{release.ljust(4, '0')}"
                forecast_data = forecast_data[forecast_data['UPDATE_ID'] == expected_format]
                
                # Convert float64 to float32 safely
                forecast_data = _safe_convert_float64_to_float32(forecast_data)
            
            # Distribute results
            if forecast_data is not None and not forecast_data.empty:
                if is_power_demand and 'COUNTRY' in forecast_data.columns:
                    country_groups = forecast_data.groupby('COUNTRY')
                    for country, country_data in country_groups:
                        if country in countries:
                            results.append((source, country, 'PowerDemand', date, release, country_data))
                elif not is_power_demand and 'COUNTRY' in forecast_data.columns and 'FUEL_TYPE' in forecast_data.columns:
                    grouped = forecast_data.groupby(['COUNTRY', 'FUEL_TYPE'])
                    for (country, fuel_type), group_data in grouped:
                        if country in countries and fuel_type in variables:
                            results.append((source, country, fuel_type, date, release, group_data))
            
            # If we got results, we're done
            if results:
                break
                
            # If no results and not the last retry, wait and try again
            if retry < query_retries:
                backoff_time = (retry + 1) * 2
                logger.warning(f"No valid {source} data, retrying in {backoff_time}s")
                time.sleep(backoff_time)
                
        except Exception as e:
            logger.error(f"Error in {source} query attempt {retry+1}: {str(e)}")
            if retry < query_retries:
                backoff_time = (retry + 1) * 2
                time.sleep(backoff_time)
    
    # If we still don't have results, return empty dataframes
    if not results:
        for country in countries:
            if is_power_demand:
                results.append((source, country, 'PowerDemand', date, release, pd.DataFrame()))
            else:
                for variable in variables:
                    results.append((source, country, variable, date, release, pd.DataFrame()))
    
    return results

def _process_common_preprocessing(data):
    """Common preprocessing for all data types"""
    # Copy data only if needed
    needs_copy = False
    
    if 'FUEL_SUBTYPE' in data.columns and any(~data['FUEL_SUBTYPE'].isna()):
        needs_copy = True
    
    if 'SUB_REGION' in data.columns and any(~data['SUB_REGION'].isna()):
        needs_copy = True
    
    if needs_copy:
        data = data.copy()
    
    # Filter out any data with fuel subtypes
    if 'FUEL_SUBTYPE' in data.columns:
        data = data[data['FUEL_SUBTYPE'].isna()]
    
    # Filter out any data with subregions
    if 'SUB_REGION' in data.columns:
        data = data[data['SUB_REGION'].isna()]
    
    # Set the index to FROM_DATETIME
    if 'FROM_DATETIME' in data.columns:
        # Convert to datetime only if needed
        if not pd.api.types.is_datetime64_any_dtype(data['FROM_DATETIME']):
            data['FROM_DATETIME'] = pd.to_datetime(data['FROM_DATETIME'], errors='coerce')
        
        data = data.set_index('FROM_DATETIME')
        # Sort by index
        data = data.sort_index()
    else:
        logger.error("Missing FROM_DATETIME column")
        return pd.DataFrame()
    
    return data

def fetch_forecast_data(mq, args):
    """Main function to fetch forecast data for a source"""
    source, countries, variables, dates, releases = args
    try:
        logger.info(f"Fetching data for {source}")
        
        # Get configuration values from the parent CONFIG dictionary
        from utils.weather_data_handler import CONFIG
        
        # Use source-specific timeout or default
        if isinstance(CONFIG['query_timeout'], dict):
            query_timeout = CONFIG['query_timeout'].get(source, CONFIG['query_timeout'].get('default', 30))
        else:
            query_timeout = CONFIG['query_timeout']
            
        query_retries = CONFIG['query_retries']
        
        # Log the timeout being used
        logger.info(f"Using timeout of {query_timeout}s for {source} queries")
        
        # Delegate to source-specific functions
        if source == "Normals":
            return _fetch_normals_data(mq, countries, variables, dates, releases)
        elif source == "Meteologica":
            return _fetch_meteologica_data(mq, countries, variables, dates, releases, query_timeout, query_retries)
        elif source == "ECMWF-HRES":
            return _fetch_hres_data(mq, countries, variables, dates, releases, query_timeout, query_retries)
        else:
            return _fetch_ensemble_data(mq, source, countries, variables, dates, releases, query_timeout, query_retries)
    except Exception as e:
        logger.error(f"Error in query for {source}: {str(e)}", exc_info=True)
        # Return error for all combinations
        results = []
        for country in countries:
            for variable in variables:
                for date in dates:
                    for release in releases:
                        results.append((source, country, variable, date, release, 
                                      {"error": str(e), "status": "failed"}))
        return results

def _process_normals_data(data):
    """Process normals data specifically"""
    data = _process_common_preprocessing(data)
    if data.empty:
        return pd.DataFrame()
    
    # Filter for duplicate timestamps, keeping only the most recent ISSUE_DATE
    if 'ISSUE_DATE' in data.columns:
        # Reset index to keep FROM_DATETIME as a column
        data = data.reset_index()
        # Convert ISSUE_DATE to datetime if it's not already
        if not pd.api.types.is_datetime64_any_dtype(data['ISSUE_DATE']):
            data['ISSUE_DATE'] = pd.to_datetime(data['ISSUE_DATE'], errors='coerce')
        
        # Sort by FROM_DATETIME and ISSUE_DATE (descending for ISSUE_DATE)
        data = data.sort_values(
            ['FROM_DATETIME', 'ISSUE_DATE'], 
            ascending=[True, False]
        )
        
        # Keep only the most recent ISSUE_DATE for each FROM_DATETIME
        data = data.drop_duplicates(subset=['FROM_DATETIME'], keep='first')
        
        # Set index back to FROM_DATETIME
        data = data.set_index('FROM_DATETIME')
    
    # Create processed DataFrame with required columns
    processed_data = pd.DataFrame(index=data.index)
    
    # Convert NORMAL column to numeric and ensure float32
    data['NORMAL'] = pd.to_numeric(data['NORMAL'], errors='coerce').astype('float32')
    
    # For plotting framework compatibility, we use the 'average' field to store the normal value
    processed_data['AVERAGE'] = data['NORMAL']
    
    # Normals don't have confidence intervals - keep as NaN to show missing data
    processed_data['MEDIAN'] = np.nan
    processed_data['BOTTOM'] = np.nan
    processed_data['TOP'] = np.nan
    processed_data['Q25'] = np.nan
    processed_data['Q75'] = np.nan
    
    return processed_data

def _process_meteologica_data(data):
    """Process meteologica data specifically"""
    data = _process_common_preprocessing(data)
    if data.empty:
        return pd.DataFrame()
    
    # Create processed DataFrame with required columns
    processed_data = pd.DataFrame(index=data.index)
    
    # Average = Value
    if 'VALUE' in data.columns:
        processed_data['AVERAGE'] = pd.to_numeric(data['VALUE'], errors='coerce').astype('float32')
    else:
        # If no VALUE column, we can't use this data
        logger.error("Missing VALUE column in meteologica data")
        return pd.DataFrame()
    
    # Meteologica is a point forecast - no confidence intervals
    processed_data['MEDIAN'] = np.nan
    processed_data['BOTTOM'] = np.nan
    processed_data['TOP'] = np.nan
    processed_data['Q25'] = np.nan
    processed_data['Q75'] = np.nan
    
    return processed_data

def _process_ensemble_data(data):
    """Process ensemble forecast data"""
    data = _process_common_preprocessing(data)
    if data.empty:
        return pd.DataFrame()
    
    # Create processed DataFrame with required columns
    processed_data = pd.DataFrame(index=data.index)
    
    # Process AVERAGE if available
    if 'AVERAGE' in data.columns:
        processed_data['AVERAGE'] = pd.to_numeric(data['AVERAGE'], errors='coerce').astype('float32')
    else:
        logger.warning("No AVERAGE column found in ensemble data")
        processed_data['AVERAGE'] = np.nan
        
    # Process bottom/top range
    if 'BOTTOM' in data.columns:
        processed_data['BOTTOM'] = pd.to_numeric(data['BOTTOM'], errors='coerce').astype('float32')
    else:
        logger.warning("No BOTTOM column found in ensemble data")
        processed_data['BOTTOM'] = np.nan
        
    if 'TOP' in data.columns:
        processed_data['TOP'] = pd.to_numeric(data['TOP'], errors='coerce').astype('float32')
    else:
        logger.warning("No TOP column found in ensemble data")
        processed_data['TOP'] = np.nan
    
    # Get all ensemble member columns
    ensemble_cols = [col for col in data.columns if col.startswith('ENS')]
    
    # Process ensemble members if available
    if ensemble_cols:
        # Convert ensemble columns to numeric efficiently and ensure float32
        for col in ensemble_cols:
            data[col] = pd.to_numeric(data[col], errors='coerce').astype('float32')
        
        # Calculate statistics from ensemble members more efficiently
        processed_data['MEDIAN'] = data[ensemble_cols].median(axis=1).astype('float32')
        processed_data['Q25'] = data[ensemble_cols].quantile(0.25, axis=1).astype('float32')
        processed_data['Q75'] = data[ensemble_cols].quantile(0.75, axis=1).astype('float32')
        
        # Preserve ensemble member columns for residual load calculation
        for col in ensemble_cols:
            processed_data[col] = data[col]
    else:
        logger.warning("No ensemble members found. Using AVERAGE for all statistics.")
        if 'AVERAGE' in processed_data.columns:
            # Fall back to using AVERAGE for all statistics if no members
            processed_data['MEDIAN'] = processed_data['AVERAGE']
            processed_data['Q25'] = processed_data['AVERAGE']
            processed_data['Q75'] = processed_data['AVERAGE']
        else:
            # No data available
            processed_data['MEDIAN'] = np.nan
            processed_data['Q25'] = np.nan
            processed_data['Q75'] = np.nan
    
    # Ensure no missing values in key columns
    required_cols = ['AVERAGE', 'BOTTOM', 'TOP', 'MEDIAN', 'Q25', 'Q75']
    for col in required_cols:
        if col not in processed_data.columns:
            logger.warning(f"Adding missing column: {col}")
            processed_data[col] = np.nan
    
    # Ensure all columns are float32
    for col in required_cols:
        if processed_data[col].dtype != 'float32':
            processed_data[col] = processed_data[col].astype('float32')
    
    return processed_data

def _process_deterministic_data(data):
    """Process deterministic data with FORECAST column"""
    data = _process_common_preprocessing(data)
    if data.empty:
        return pd.DataFrame()
    
    # Create processed DataFrame with required columns
    processed_data = pd.DataFrame(index=data.index)
    
    # Convert FORECAST to numeric and ensure float32
    data['FORECAST'] = pd.to_numeric(data['FORECAST'], errors='coerce').astype('float32')
    
    # For deterministic forecasts, just store the FORECAST value as 'average'
    processed_data['AVERAGE'] = data['FORECAST']
    
    # Deterministic forecasts don't have confidence intervals
    processed_data['MEDIAN'] = np.nan
    processed_data['BOTTOM'] = np.nan
    processed_data['TOP'] = np.nan
    processed_data['Q25'] = np.nan
    processed_data['Q75'] = np.nan
    
    return processed_data

def _process_value_data(data):
    """Process deterministic data with VALUE column"""
    data = _process_common_preprocessing(data)
    if data.empty:
        return pd.DataFrame()
    
    # Create processed DataFrame with required columns
    processed_data = pd.DataFrame(index=data.index)
    
    # Convert VALUE to numeric and ensure float32
    data['VALUE'] = pd.to_numeric(data['VALUE'], errors='coerce').astype('float32')
    
    # For deterministic data with VALUE, only store the value itself
    processed_data['AVERAGE'] = data['VALUE']
    # No confidence intervals for point forecasts
    processed_data['MEDIAN'] = np.nan
    processed_data['BOTTOM'] = np.nan
    processed_data['TOP'] = np.nan
    processed_data['Q25'] = np.nan
    processed_data['Q75'] = np.nan
    
    return processed_data

def process_forecast_data(data):
    """Process forecast data to calculate statistics with improved error handling and float32 conversion"""
    if data is None or (hasattr(data, 'empty') and data.empty):
        return pd.DataFrame()
    
    # Check data type and apply appropriate processing
    if 'NORMAL' in data.columns:
        return _process_normals_data(data)
    elif 'FORECAST' in data.columns:
        return _process_deterministic_data(data)
    elif 'VALUE' in data.columns:
        return _process_value_data(data)
    else:
        return _process_ensemble_data(data)

def preprocess_plot_data(data, source, country, variable, version, source_colors, forecast_sources):
    """Preprocess data for plotting to improve responsiveness with better error handling"""
    if data is None:
        return None
    
    # Convert stored data to DataFrame or use directly if provided as DataFrame
    if isinstance(data, pd.DataFrame):
        df = data
    else:
        # Check if data is a dictionary with the expected keys
        if not isinstance(data, dict) or 'data' not in data or 'index' not in data or 'columns' not in data:
            return None
            
        df = pd.DataFrame(data['data'])
        df.index = pd.to_datetime(data['index'])
        df.columns = data['columns']
    
    if df.empty:
        return None
    
    # Calculate statistics - convert to numpy arrays for efficiency, ensuring float32
    stats = {
        'average': df['AVERAGE'].values.astype('float32'),
        'median': df['MEDIAN'].values.astype('float32') if 'MEDIAN' in df.columns else None,
        'q25': df['Q25'].values.astype('float32') if 'Q25' in df.columns else None,
        'q75': df['Q75'].values.astype('float32') if 'Q75' in df.columns else None,
        'top': df['TOP'].values.astype('float32'),
        'bottom': df['BOTTOM'].values.astype('float32'),
        'times': df.index.to_numpy(),  # Convert to numpy array
        'color': source_colors.get(source, 'rgb(128, 128, 128)'),
        'source_name': forecast_sources.get(source, source)
    }
    
    return stats

def calculate_residual_load(global_data, source, country, version):
    """Calculate residual load (Demand - Wind - Solar) with matched ensemble members.
    
    Args:
        global_data: Dictionary with raw forecast data
        source: Forecast source (e.g., 'ECMWF-ENS', 'GEFS')
        country: Country code
        version: Forecast version string
    
    Returns:
        pandas.DataFrame with residual load statistics, or None if data unavailable
    """
    # Check if all three variables exist for this source/country/version
    required_vars = ['PowerDemand', 'Wind', 'PV']
    
    for var in required_vars:
        if (source not in global_data or
            country not in global_data[source] or
            var not in global_data[source][country] or
            version not in global_data[source][country][var]):
            logger.warning(
                f"Missing {var} data for {source}/{country}/{version}"
            )
            return None
    
    # Reconstruct DataFrames from stored data
    dataframes = {}
    for var in required_vars:
        stored = global_data[source][country][var][version]
        if not stored or 'data' not in stored:
            return None
        
        df = pd.DataFrame(stored['data'])
        df.index = pd.to_datetime(stored['index'])
        dataframes[var] = df
        
        # Debug: Log available columns
        logger.info(
            f"Available columns for {var} in {source}/{country}/{version}: "
            f"{df.columns.tolist()}"
        )
    
    # Get ensemble member columns (ENS1, ENS2, etc.)
    demand_ens = [col for col in dataframes['PowerDemand'].columns 
                  if col.startswith('ENS')]
    wind_ens = [col for col in dataframes['Wind'].columns 
                if col.startswith('ENS')]
    pv_ens = [col for col in dataframes['PV'].columns 
              if col.startswith('ENS')]
    
    # Find common ensemble members
    common_ens = sorted(set(demand_ens) & set(wind_ens) & set(pv_ens))
    
    if not common_ens:
        logger.warning(
            f"No common ensemble members for {source}/{country}/{version}. "
            f"Demand: {len(demand_ens)}, Wind: {len(wind_ens)}, PV: {len(pv_ens)}"
        )
        return None
    
    logger.info(
        f"Found {len(common_ens)} common ensemble members for "
        f"{source}/{country}/{version}"
    )
    
    # Align timestamps across all three variables
    common_times = (dataframes['PowerDemand'].index
                    .intersection(dataframes['Wind'].index)
                    .intersection(dataframes['PV'].index))
    
    if len(common_times) == 0:
        logger.warning(
            f"No common timestamps for {source}/{country}/{version}"
        )
        return None
    
    # Calculate residual load for each ensemble member
    residual_data = pd.DataFrame(index=common_times)
    
    for ens_col in common_ens:
        # Residual = Demand - Wind - Solar
        demand = dataframes['PowerDemand'].loc[common_times, ens_col]
        wind = dataframes['Wind'].loc[common_times, ens_col]
        pv = dataframes['PV'].loc[common_times, ens_col]
        
        residual_data[ens_col] = demand - wind - pv
    
    # Convert to float32 for memory efficiency
    residual_data = residual_data.astype('float32')
    
    # Calculate statistics from ensemble members
    processed_data = pd.DataFrame(index=residual_data.index)
    processed_data['AVERAGE'] = residual_data.mean(axis=1).astype('float32')
    processed_data['MEDIAN'] = residual_data.median(axis=1).astype('float32')
    processed_data['Q25'] = residual_data.quantile(0.25, axis=1).astype('float32')
    processed_data['Q75'] = residual_data.quantile(0.75, axis=1).astype('float32')
    processed_data['BOTTOM'] = residual_data.min(axis=1).astype('float32')
    processed_data['TOP'] = residual_data.max(axis=1).astype('float32')
    
    logger.info(
        f"Calculated residual load for {source}/{country}/{version} "
        f"using {len(common_ens)} ensemble members"
    )
    
    return processed_data


def _create_delta_data(preprocessed_plots, country, variable, selected_versions=None):
    """
    Create delta data for run-on-run comparisons.
    Returns a dictionary of datasets for plotting.
    """
    # Check if ECMWF-ENS data exists
    if 'ECMWF-ENS' not in preprocessed_plots:
        return {}
        
    if country not in preprocessed_plots['ECMWF-ENS']:
        return {}
        
    if variable not in preprocessed_plots['ECMWF-ENS'][country]:
        return {}
    
    # Get all available versions for ECMWF-ENS
    versions = list(preprocessed_plots['ECMWF-ENS'][country][variable].keys())
    if not versions:
        return {}
    
    # Sort versions by date (newest first)
    versions.sort(reverse=True)
    
    if len(versions) < 2:
        return {}
        
    # Get latest version
    latest_version = versions[0]
    
    # Get data for latest version
    latest_stats = preprocessed_plots['ECMWF-ENS'][country][variable].get(latest_version)
    if latest_stats is None:
        return {}
    
    # Parse date for calculations
    current_date_str, current_release = latest_version.split('_')
    current_date = pd.to_datetime(current_date_str)
    
    # ALWAYS show D-1 and D-3 deltas
    target_days_back = [1, 3]  # D-1 and D-3
    comparison_versions = []
    
    # Find closest versions to D-1 and D-3
    for days_back in target_days_back:
        target_date = current_date - timedelta(days=days_back)
        target_version_prefix = target_date.strftime('%Y-%m-%d')
        
        # Look for versions matching the target date
        matching_versions = [v for v in versions if v.startswith(target_version_prefix)]
        
        if matching_versions:
            # Prefer 00z if available
            if f"{target_version_prefix}_00" in matching_versions:
                comparison_versions.append(f"{target_version_prefix}_00")
            else:
                # Otherwise use the first available release for that day
                comparison_versions.append(matching_versions[0])
        else:
            # If no exact date match, find the closest previous version
            prev_versions = [v for v in versions if pd.to_datetime(v.split('_')[0]) <= target_date]
            if prev_versions and prev_versions[0] != latest_version:
                comparison_versions.append(prev_versions[0])
    
    # Make sure the comparison versions are unique and not the latest
    comparison_versions = [v for v in list(dict.fromkeys(comparison_versions)) if v != latest_version]
    
    # Process each comparison
    delta_data = {}
    for comp_version in comparison_versions:
        # Skip if version doesn't exist
        if comp_version not in preprocessed_plots['ECMWF-ENS'][country][variable]:
            continue
        
        # Get data for comparison version
        comp_stats = preprocessed_plots['ECMWF-ENS'][country][variable].get(comp_version)
        if comp_stats is None:
            continue
        
        # Make sure both datasets have times
        if 'times' not in latest_stats or 'times' not in comp_stats:
            logger.warning(f"Missing 'times' in data for {country}/{variable}")
            continue

        # Create pandas Series without modifying the timestamp types
        try:
            # Check if we have average data in both datasets
            if 'average' not in latest_stats or 'average' not in comp_stats:
                logger.warning(f"Missing 'average' data for {country}/{variable}")
                continue
                
            # Convert to pandas objects for easy indexing operations
            latest_df = pd.DataFrame({'value': latest_stats['average']}, index=latest_stats['times'])
            comp_df = pd.DataFrame({'value': comp_stats['average']}, index=comp_stats['times'])
            
            # Find common indices using pandas index intersection
            common_indices = latest_df.index.intersection(comp_df.index)
            
            if len(common_indices) == 0:
                logger.warning(f"No overlapping timestamps for {country}/{variable}")
                continue
                
            # Calculate delta directly on the subset data frames
            latest_values = latest_df.loc[common_indices, 'value'].values
            comp_values = comp_df.loc[common_indices, 'value'].values
            
            # Calculate delta explicitly as float32
            delta = (latest_values - comp_values).astype('float32')
        except Exception as e:
            logger.error(f"Error calculating deltas: {str(e)}")
            continue
            
        # Get comparison version date for label
        comp_date_str, comp_release = comp_version.split('_')
        comp_date = pd.to_datetime(comp_date_str)
        days_between = (current_date - comp_date).days
        
        # Create trace with proper label and color
        if days_between == 1:
            label = "D-1"
            color = 'rgba(30, 144, 255, 0.7)'  # Blue
        elif days_between == 3:
            label = "D-3"
            color = 'rgba(255, 140, 0, 0.7)'   # Orange
        elif days_between == 2:
            label = "D-2"
            color = 'rgba(60, 179, 113, 0.7)'  # Green
        else:
            label = f"D-{days_between}"
            # Generate a color based on the age
            opacity = max(0.3, 1.0 - (days_between / 10))
            color = f'rgba(128, 128, 128, {opacity})'  # Gray with decreasing opacity
            
        trace_name = f"Latest vs {label}"
        delta_data[trace_name] = {
            'times': common_indices,  # Use the common indices directly
            'values': delta,
            'color': color
        }
    
    return delta_data 