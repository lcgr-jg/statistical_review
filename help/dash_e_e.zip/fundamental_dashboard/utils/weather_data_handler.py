import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import concurrent.futures
import threading
import time
import gc
import os
import sys

# Check if memory profiling is enabled
ENABLE_MEMORY_PROFILING = os.getenv('ENABLE_MEMORY_PROFILING', 'false').lower() == 'true'

try:
    import psutil
    if not ENABLE_MEMORY_PROFILING:
        psutil = None
except ImportError:
    psutil = None

# Set up logging
logging.basicConfig(level=logging.WARNING)  # Change to WARNING from INFO to reduce output
logger = logging.getLogger(__name__)

# Configuration dictionary
CONFIG = {
    'max_workers': 12,  # Reduced from 20 to lower parallelism
    'cache_size': 20,
    'max_versions_to_keep': 10,
    'update_interval': 3600,  # seconds
    'default_country': 'Germany',
    'default_sources': ['ECMWF-ENS'],
    'plot_height': 800,
    'plot_height_no_run_on_run': 600,
    'refresh_interval': 60 * 60 * 1000,  # 1 hour in milliseconds
    'memory_cleanup_interval': 12 * 60 * 60 * 1000,  # 12 hours in milliseconds
    'query_timeout': {
        'default': 30,       # Default timeout (30 seconds)
        'ECMWF-HRES': 60,    # Higher timeout for HRES queries
        'Meteologica': 60,   # Higher timeout for Meteologica queries
        'ECMWF-ENS': 45,     # Medium timeout for ensemble queries
        'GEFS': 45           # Medium timeout for ensemble queries
    },
    'query_retries': 0,   # No retries — missing data is logged, not retried
    'token_max_age_minutes': 45,  # Max age of Snowflake token before refresh
    'forecast_history_days': 1,   # Days of history (today + yesterday = 4 releases)
    'default_schedule_times': [   # Default refresh times (UTC)
        {'hour': 6, 'minute': 30},
        {'hour': 16, 'minute': 0},
        {'hour': 19, 'minute': 0}
    ]
}

# Priority countries - most important countries for pre-processing and caching
PRIORITY_COUNTRIES = [
    'Germany',  # Most important country first
    'France',
    'UK',
    'Netherlands',
    'Belgium',
    'Spain',
]

# All countries to monitor (same as priority for now)
COUNTRIES = PRIORITY_COUNTRIES

# Define forecast sources and their display names
FORECAST_SOURCES = {
    'ECMWF-ENS': 'ECMWF Ensemble',
    'ECMWF-HRES': 'ECMWF High Resolution',
    'GEFS': 'GEFS',
    'Normals': 'Climate Normals',
}

# Define colors for different sources with proper RGB values
SOURCE_COLORS = {
    'ECMWF-ENS': 'rgb(0, 0, 255)',  # blue
    'ECMWF-HRES': 'rgb(255, 51, 51)',  # red
    'GEFS': 'rgb(128, 0, 128)',  # purple
    'Normals': 'rgb(128, 128, 128)',  # gray
}

class WeatherDataHandler:
    """Handler for weather forecast data from multiple sources.
    
    Data Structure:
        This class uses nested dictionaries for efficient data storage and retrieval:
        
        global_data: {source: {country: {variable: {version: raw_data}}}}
            - source: e.g., 'ECMWF-ENS', 'GEFS', 'Meteologica'
            - country: e.g., 'Germany', 'France', 'UK'
            - variable: 'Wind', 'PV', 'PowerDemand'
            - version: 'YYYY-MM-DD_HH' (e.g., '2025-01-15_00')
            - raw_data: Dict with 'data', 'index', 'columns' keys
        
        preprocessed_plots: {source: {country: {variable: {version: plot_data}}}}
            - Same structure as global_data
            - plot_data: Dict with processed statistics for plotting
            - Keys: 'average', 'median', 'q25', 'q75', 'top', 'bottom', 'times'
        
        plot_cache: {cache_key: plotly_figure}
            - cache_key: Composite key like 'all_sources_Germany_Wind_2025-01-15_00'
            - Limited to CONFIG['cache_size'] entries (FIFO eviction)
    
    Note: 4-level nesting is intentional for O(1) lookups but requires careful
          KeyError handling. Consider refactoring to DataFrame if complexity grows.
    """
    def __init__(self):
        self.global_data = {}  # Store for raw data
        self.preprocessed_plots = {}  # Store for preprocessed plot data
        self.plot_cache = {}  # Cache for plot figures
        self.forecast_versions_cache = []  # Cache for forecast versions
        self.data_lock = threading.Lock()
        self.initialized = False
        self.scheduled_times = []  # Times to refresh data
        self.scheduler_thread = None  # Thread for scheduling refreshes
        self.shutdown_flag = False  # Flag to indicate shutdown
    
    def initialize(self):
        """Initialize the data handler by loading data"""
        if not self.initialized:
            # Reset shutdown flag before starting
            self.shutdown_flag = False
            # First load all forecast data (but don't set initialized yet)
            result = self.load_all_forecasts()
            if result:
                # Now we're fully initialized
                self.initialized = True
                logger.info("Weather data handler is now fully initialized")
                # Start scheduler AFTER setting initialized
                self.schedule_next_refresh()
                return True
            return False
        return self.initialized
    
    def shutdown(self):
        """Safely shutdown all running threads and cleanup"""
        logger.info("Shutting down weather data handler")
        # Set shutdown flag to stop new tasks
        self.shutdown_flag = True
        
        # Cancel scheduled refresh if it exists
        if self.scheduler_thread is not None and self.scheduler_thread.is_alive():
            logger.info("Cancelling scheduled refresh during shutdown")
            try:
                # In Python, we can't directly cancel threads, but we can set a flag
                # that the thread checks periodically
                pass
            except:
                pass  # Ignore errors during shutdown
        
        logger.info("Weather data handler shutdown complete")

    def clear_caches(self):
        """Explicitly clear all caches to free memory"""
        logger.info("Clearing all weather data caches")
        
        with self.data_lock:
            # Clear the plot cache first
            self.plot_cache = {}
            
            # Don't clear all global_data and preprocessed_plots completely,
            # as they contain the structure for all sources/countries/variables
            # Just clear the actual data inside
            for source in self.global_data:
                for country in self.global_data[source]:
                    for variable in self.global_data[source][country]:
                        self.global_data[source][country][variable] = {}
                        
            for source in self.preprocessed_plots:
                for country in self.preprocessed_plots[source]:
                    for variable in self.preprocessed_plots[source][country]:
                        self.preprocessed_plots[source][country][variable] = {}
            
            # Clear forecast versions cache
            self.forecast_versions_cache = []
        
        # Force garbage collection to clean up memory
        gc.collect()
        
        # Log memory usage after clearing caches
        self.profile_memory_usage("after clearing caches")
        
        logger.info("Weather cache clearing complete")

    def load_all_forecasts(self):
        """Load all forecast data for all sources, countries, and variables"""
        # Check for shutdown
        if self.shutdown_flag:
            logger.info("Skipping forecast loading due to shutdown")
            return False
        
        # Clear caches before loading new data
        self.clear_caches()
            
        start_time = time.time()
        logger.info("=== Loading all forecast data ===")
        
        # Profile initial memory usage
        self.profile_memory_usage("before loading")
        
        # Get current date and time
        now = datetime.now()
        current_date = now.date()
        
        # Calculate D-N date based on configuration
        days_back = CONFIG['forecast_history_days']
        d_minus_n = current_date - timedelta(days=days_back)
        
        # Generate all dates from D-N to today
        date_range = [d_minus_n + timedelta(days=x) for x in range(days_back + 1)]
        
        # Define common parameters for all queries
        all_countries = COUNTRIES  # Use all countries
        all_variables = ['Wind', 'PV', 'PowerDemand']
        all_releases = ['00', '12']
        
        # Prepare arguments for parallel processing
        parallel_tasks = []
        
        # Process Normals separately
        source = 'Normals'
        if source not in self.global_data:
            self.global_data[source] = {}
            self.preprocessed_plots[source] = {}
            
        for country in all_countries:
            if country not in self.global_data[source]:
                self.global_data[source][country] = {}
                self.preprocessed_plots[source][country] = {}
                
            for variable in all_variables:
                if variable not in self.global_data[source][country]:
                    self.global_data[source][country][variable] = {}
                    self.preprocessed_plots[source][country][variable] = {}
        
        # For Normals, we use arbitrary date and release
        parallel_tasks.append((source, all_countries, all_variables, [current_date], ['00']))
        
        # Handle all other sources
        forecast_sources = [s for s in FORECAST_SOURCES.keys() if s != 'Normals']
        
        # Initialize data structures for all sources
        for source in forecast_sources:
            if source not in self.global_data:
                self.global_data[source] = {}
                self.preprocessed_plots[source] = {}
                
            for country in all_countries:
                if country not in self.global_data[source]:
                    self.global_data[source][country] = {}
                    self.preprocessed_plots[source][country] = {}
                    
                for variable in all_variables:
                    if variable not in self.global_data[source][country]:
                        self.global_data[source][country][variable] = {}
                        self.preprocessed_plots[source][country][variable] = {}
            
            # Create task for this source
            parallel_tasks.append((source, all_countries, all_variables, date_range, all_releases))
        
        # Process data in parallel with each thread handling a full source
        logger.info(f"Starting parallel processing for {len(parallel_tasks)} sources...")
        
        query_start_time = time.time()
        processed_count = 0
        
        # Use parallel processing with ThreadPoolExecutor - with proper shutdown handling
        with concurrent.futures.ThreadPoolExecutor(max_workers=CONFIG['max_workers']) as executor:
            # Check for shutdown before starting tasks
            if self.shutdown_flag:
                logger.info("Shutdown detected during task creation - aborting")
                return False
                
            # Process results directly as they come in
            futures = []
            for args in parallel_tasks:
                # Verify not shutting down before submitting new work
                if self.shutdown_flag:
                    logger.info(f"Shutdown detected - skipping processing for source: {args[0]}")
                    continue
                    
                logger.info(f"Starting processing for source: {args[0]}")
                # Use a try-except to avoid failures during shutdown
                try:
                    futures.append(executor.submit(self.process_source_data, args))
                except RuntimeError as e:
                    if "cannot schedule new futures" in str(e):
                        logger.info(f"Shutdown in progress - skipping processing for source: {args[0]}")
                    else:
                        logger.error(f"Error scheduling task for {args[0]}: {str(e)}")
                    continue
            
            # Wait for all futures to complete
            for future in concurrent.futures.as_completed(futures):
                # Check for shutdown before processing results
                if self.shutdown_flag:
                    logger.info("Shutdown detected during result processing - exiting early")
                    break
                    
                try:
                    source_processed = future.result()
                    processed_count += source_processed
                except Exception as e:
                    logger.error(f"Error processing source data: {str(e)}")
        
        total_time = time.time() - start_time
        
        logger.info(f"=== Finished loading forecast data (Total time: {total_time:.2f}s) ===")
        logger.info(f"Successfully processed {processed_count} results")
        
        # Calculate and store ResidualLoad from Wind/PV/PowerDemand
        logger.info("Preprocessing ResidualLoad data...")
        residual_load_success = self.preprocess_residual_load()
        
        if not residual_load_success:
            logger.warning("⚠️  ResidualLoad preprocessing did not complete successfully")
            logger.warning("   ResidualLoad charts may not be available")
        
        # Perform garbage collection to free memory
        gc.collect()
        
        # Log memory usage
        self.profile_memory_usage("after loading")
        
        # Update forecast versions cache
        self.get_available_forecast_versions(force_refresh=True)
        
        # Pregenerate common plots to improve responsiveness
        if not self.shutdown_flag:
            self.pregenerate_common_plots()
        
        # Do NOT set initialized flag here anymore - moved to initialize() method
        
        return True
    
    def profile_memory_usage(self, label=""):
        """Profile memory usage of major components (only if enabled)"""
        if not ENABLE_MEMORY_PROFILING or not psutil:
            return {}
        
        memory_usage = {
            "global_data": sys.getsizeof(self.global_data) if 'sys' in globals() else 0,
            "preprocessed_plots": sys.getsizeof(self.preprocessed_plots) if 'sys' in globals() else 0,
            "plot_cache": sys.getsizeof(self.plot_cache) if 'sys' in globals() else 0,
        }
        
        logger.info(f"Memory profile {label}: {memory_usage}")
        
        # Log memory usage from psutil
        try:
            process = psutil.Process(os.getpid())
            memory_info = process.memory_info()
            logger.info(f"Memory usage {label}: {memory_info.rss / (1024 * 1024):.2f} MB")
        except Exception as e:
            logger.warning(f"Error profiling memory: {e}")
        
        return memory_usage
    
    def get_available_forecast_versions(self, force_refresh=False):
        """Get list of available forecast versions from the loaded data with better caching"""
        # Return cached versions if available and not forcing refresh
        if self.forecast_versions_cache and not force_refresh:
            return self.forecast_versions_cache
        
        logger.info("Getting available forecast versions...")
        
        versions = set()
        for source, source_data in self.global_data.items():
            for country, country_data in source_data.items():
                for variable, variable_data in country_data.items():
                    versions.update(variable_data.keys())
        
        sorted_versions = sorted(list(versions), reverse=True)
        logger.info(f"Found {len(sorted_versions)} available versions")
        
        # Cache the results
        self.forecast_versions_cache = sorted_versions
        return sorted_versions
    
    def get_countries(self):
        """Return the list of available countries"""
        return COUNTRIES
    
    def get_forecast_sources(self):
        """Return the dictionary of forecast sources"""
        return FORECAST_SOURCES
    
    def get_source_colors(self):
        """Return the dictionary of source colors"""
        return SOURCE_COLORS
    
    def get_config(self):
        """Return the configuration dictionary"""
        return CONFIG
    
    def fetch_forecast_data(self, args):
        """Main function to fetch forecast data from EQ by source"""
        from utils.eq_weather_fetcher import fetch_eq_forecast_data
        source, countries, variables, dates, releases = args
        return fetch_eq_forecast_data(source, countries, variables, dates, releases)
    
    def process_forecast_data(self, data):
        """Process forecast data to calculate statistics"""
        from utils.weather_data_processor import process_forecast_data
        processed_data = process_forecast_data(data)
        
        # Make sure all float data is float32
        if processed_data is not None and not processed_data.empty:
            for col in processed_data.select_dtypes(include=['float64']).columns:
                processed_data[col] = processed_data[col].astype('float32')
        
        return processed_data
    
    def preprocess_plot_data(self, data, source, country, variable, version):
        """Preprocess data for plotting to improve responsiveness with better error handling"""
        from utils.weather_data_processor import preprocess_plot_data
        return preprocess_plot_data(
            data=data,
            source=source,
            country=country,
            variable=variable,
            version=version,
            source_colors=self.get_source_colors(),
            forecast_sources=self.get_forecast_sources()
        )
    
    def preprocess_residual_load(self):
        """Calculate and store ResidualLoad (Demand - Wind - PV) for all sources/countries/versions.
        This is done ONCE during data loading for instant access during rendering.
        
        Returns:
            bool: True if preprocessing completed successfully, False otherwise
        """
        logger.info("=" * 60)
        logger.info("PREPROCESSING RESIDUALLOAD DATA")
        logger.info("=" * 60)
        
        required_vars = ['PowerDemand', 'Wind', 'PV']
        residual_count = 0
        errors_count = 0
        
        try:
            # Validate preprocessed_plots exists
            if not self.preprocessed_plots:
                logger.error("preprocessed_plots is empty - cannot preprocess ResidualLoad")
                return False
            
            for source in self.preprocessed_plots:
                logger.info(f"Processing source: {source}")
                    
                for country in self.preprocessed_plots[source]:
                    # Check if all three variables exist for this source/country
                    missing_vars = [var for var in required_vars 
                                   if var not in self.preprocessed_plots[source][country]]
                    
                    if missing_vars:
                        logger.warning(f"  {source}/{country}: Missing variables {missing_vars}")
                        continue
                    
                    # Get all versions that have all three variables
                    demand_versions = set(self.preprocessed_plots[source][country]['PowerDemand'].keys())
                    wind_versions = set(self.preprocessed_plots[source][country]['Wind'].keys())
                    pv_versions = set(self.preprocessed_plots[source][country]['PV'].keys())
                    
                    common_versions = demand_versions & wind_versions & pv_versions
                    
                    if not common_versions:
                        logger.warning(f"  {source}/{country}: No common versions found")
                        logger.info(f"    Demand versions: {demand_versions}")
                        logger.info(f"    Wind versions: {wind_versions}")
                        logger.info(f"    PV versions: {pv_versions}")
                        continue
                    
                    # Initialize ResidualLoad storage for this source/country
                    if 'ResidualLoad' not in self.preprocessed_plots[source][country]:
                        self.preprocessed_plots[source][country]['ResidualLoad'] = {}
                    
                    # Calculate ResidualLoad for each version
                    logger.info(f"  Processing {source}/{country}: {len(common_versions)} versions")
                    
                    for version in sorted(common_versions):
                        try:
                            demand_stats = self.preprocessed_plots[source][country]['PowerDemand'][version]
                            wind_stats = self.preprocessed_plots[source][country]['Wind'][version]
                            pv_stats = self.preprocessed_plots[source][country]['PV'][version]
                            
                            if not demand_stats or not wind_stats or not pv_stats:
                                logger.warning(f"    {version}: Missing stats data")
                                errors_count += 1
                                continue
                            
                            # Validate that all required keys exist
                            required_keys = ['times', 'average', 'median', 'q25', 'q75', 'top', 'bottom']
                            missing = False
                            for var_name, stats in [('Demand', demand_stats), ('Wind', wind_stats), ('PV', pv_stats)]:
                                missing_keys = [key for key in required_keys if key not in stats]
                                if missing_keys:
                                    logger.error(f"    {version}: {var_name} missing keys {missing_keys}")
                                    errors_count += 1
                                    missing = True
                                    break
                            
                            if missing:
                                continue
                            
                            # DIAGNOSTIC: Check timestamp ranges first
                            demand_times = pd.DatetimeIndex(demand_stats['times'])
                            wind_times = pd.DatetimeIndex(wind_stats['times'])
                            pv_times = pd.DatetimeIndex(pv_stats['times'])
                            
                            # CRITICAL FIX: Check for and handle duplicate timestamps
                            demand_has_dupes = demand_times.duplicated().any()
                            wind_has_dupes = wind_times.duplicated().any()
                            pv_has_dupes = pv_times.duplicated().any()
                            
                            if demand_has_dupes or wind_has_dupes or pv_has_dupes:
                                logger.error(f"    {version}: DUPLICATE TIMESTAMPS DETECTED!")
                                if demand_has_dupes:
                                    n_dupes = demand_times.duplicated().sum()
                                    logger.error(f"      Demand has {n_dupes} duplicate timestamps")
                                    # Deduplicate by taking average of duplicate values
                                    demand_df = pd.DataFrame({
                                        'times': demand_times,
                                        'average': demand_stats['average'],
                                        'median': demand_stats['median'],
                                        'q25': demand_stats['q25'],
                                        'q75': demand_stats['q75'],
                                        'top': demand_stats['top'],
                                        'bottom': demand_stats['bottom']
                                    })
                                    demand_df = demand_df.groupby('times').mean()
                                    demand_times = demand_df.index
                                    for key in ['average', 'median', 'q25', 'q75', 'top', 'bottom']:
                                        demand_stats[key] = demand_df[key].values
                                
                                if wind_has_dupes:
                                    n_dupes = wind_times.duplicated().sum()
                                    logger.error(f"      Wind has {n_dupes} duplicate timestamps")
                                    wind_df = pd.DataFrame({
                                        'times': wind_times,
                                        'average': wind_stats['average'],
                                        'median': wind_stats['median'],
                                        'q25': wind_stats['q25'],
                                        'q75': wind_stats['q75'],
                                        'top': wind_stats['top'],
                                        'bottom': wind_stats['bottom']
                                    })
                                    wind_df = wind_df.groupby('times').mean()
                                    wind_times = wind_df.index
                                    for key in ['average', 'median', 'q25', 'q75', 'top', 'bottom']:
                                        wind_stats[key] = wind_df[key].values
                                
                                if pv_has_dupes:
                                    n_dupes = pv_times.duplicated().sum()
                                    logger.error(f"      PV has {n_dupes} duplicate timestamps")
                                    pv_df = pd.DataFrame({
                                        'times': pv_times,
                                        'average': pv_stats['average'],
                                        'median': pv_stats['median'],
                                        'q25': pv_stats['q25'],
                                        'q75': pv_stats['q75'],
                                        'top': pv_stats['top'],
                                        'bottom': pv_stats['bottom']
                                    })
                                    pv_df = pv_df.groupby('times').mean()
                                    pv_times = pv_df.index
                                    for key in ['average', 'median', 'q25', 'q75', 'top', 'bottom']:
                                        pv_stats[key] = pv_df[key].values
                                
                                logger.info(f"      After deduplication: Demand={len(demand_times)}, Wind={len(wind_times)}, PV={len(pv_times)}")
                            
                            # Log lengths and ranges to diagnose the mismatch
                            if len(demand_times) != len(wind_times) or len(demand_times) != len(pv_times):
                                logger.warning(f"    {version}: LENGTH MISMATCH!")
                                logger.warning(f"      Demand: {len(demand_times)} timestamps [{demand_times.min()} to {demand_times.max()}]")
                                logger.warning(f"      Wind:   {len(wind_times)} timestamps [{wind_times.min()} to {wind_times.max()}]")
                                logger.warning(f"      PV:     {len(pv_times)} timestamps [{pv_times.min()} to {pv_times.max()}]")
                                
                                # Check if they have the same min/max (just different intervals/missing data)
                                all_min = min(demand_times.min(), wind_times.min(), pv_times.min())
                                all_max = max(demand_times.max(), wind_times.max(), pv_times.max())
                                logger.warning(f"      Overall range: {all_min} to {all_max}")
                            
                            # Find common timestamps across all three variables
                            common_times = demand_times.intersection(wind_times).intersection(pv_times)
                            
                            if len(common_times) == 0:
                                logger.error(f"    {version}: No common timestamps between Demand ({len(demand_times)}), Wind ({len(wind_times)}), PV ({len(pv_times)})")
                                errors_count += 1
                                continue
                            
                            # Get indices for common times in each array
                            demand_idx = demand_times.get_indexer(common_times)
                            wind_idx = wind_times.get_indexer(common_times)
                            pv_idx = pv_times.get_indexer(common_times)
                            
                            # Calculate ResidualLoad stats using ALIGNED data: Demand - Wind - PV
                            residual_stats = {
                                'times': common_times.to_numpy(),
                                'average': demand_stats['average'][demand_idx] - wind_stats['average'][wind_idx] - pv_stats['average'][pv_idx],
                                'median': demand_stats['median'][demand_idx] - wind_stats['median'][wind_idx] - pv_stats['median'][pv_idx],
                                'q25': demand_stats['q25'][demand_idx] - wind_stats['q25'][wind_idx] - pv_stats['q25'][pv_idx],
                                'q75': demand_stats['q75'][demand_idx] - wind_stats['q75'][wind_idx] - pv_stats['q75'][pv_idx],
                                'top': demand_stats['top'][demand_idx] - wind_stats['bottom'][wind_idx] - pv_stats['bottom'][pv_idx],  # Worst case
                                'bottom': demand_stats['bottom'][demand_idx] - wind_stats['top'][wind_idx] - pv_stats['top'][pv_idx],  # Best case
                                'color': demand_stats.get('color', 'rgb(128, 128, 128)'),
                                'source_name': demand_stats.get('source_name', source)
                            }
                            
                            # Store the preprocessed ResidualLoad stats
                            self.preprocessed_plots[source][country]['ResidualLoad'][version] = residual_stats
                            residual_count += 1
                            
                            # Log if we had to trim timestamps
                            if len(common_times) < max(len(demand_times), len(wind_times), len(pv_times)):
                                logger.info(f"    {version}: Aligned to {len(common_times)} common timestamps (from {len(demand_times)}/{len(wind_times)}/{len(pv_times)})")
                            
                        except Exception as e:
                            logger.error(f"    Error calculating ResidualLoad for {source}/{country}/{version}: {str(e)}")
                            errors_count += 1
                            continue
            
            logger.info("=" * 60)
            logger.info(f"✅ Preprocessed {residual_count} ResidualLoad datasets")
            if errors_count > 0:
                logger.warning(f"⚠️  Encountered {errors_count} errors during preprocessing")
            logger.info("=" * 60)
            
            # Return True if we successfully processed at least some data
            return residual_count > 0
            
        except Exception as e:
            logger.error(f"❌ Critical error in preprocess_residual_load: {str(e)}", exc_info=True)
            return False
        
    def cleanup_old_caches(self):
        """Remove old data from caches periodically with improved memory management"""
        logger.info("Starting cache cleanup")
        
        try:
            # Force garbage collection first
            gc.collect()
            
            # Get all available versions
            versions = self.get_available_forecast_versions(force_refresh=True)
            
            # Keep only the most recent versions based on configuration
            if len(versions) > self.get_config()['max_versions_to_keep']:
                oldest_versions = sorted(versions)[:-self.get_config()['max_versions_to_keep']]
                logger.info(f"Removing {len(oldest_versions)} old versions: {oldest_versions}")
                
                # Remove old versions from data
                with self.data_lock:
                    for source in self.global_data:
                        for country in self.global_data[source]:
                            for variable in self.global_data[source][country]:
                                for version in list(self.global_data[source][country][variable].keys()):
                                    if version in oldest_versions:
                                        del self.global_data[source][country][variable][version]
                    
                    # Remove from preprocessed plots
                    for source in self.preprocessed_plots:
                        for country in self.preprocessed_plots[source]:
                            for variable in self.preprocessed_plots[source][country]:
                                for version in list(self.preprocessed_plots[source][country][variable].keys()):
                                    if version in oldest_versions:
                                        del self.preprocessed_plots[source][country][variable][version]
                
                # Clear plot cache 
                self.plot_cache = {}
                
                # Clear forecast versions cache to force refresh
                self.forecast_versions_cache = []
                
                # Force garbage collection again
                gc.collect()
                
                # Log memory usage
                self.profile_memory_usage("after cleanup")
                
                logger.info("Cache cleanup completed")
            else:
                logger.info(f"No cleanup needed - only {len(versions)} versions available")
        except Exception as e:
            logger.error(f"Error during cache cleanup: {str(e)}", exc_info=True)
    
    def set_schedule_times(self, times):
        """Set specific times to refresh data
        
        Args:
            times (list): List of dicts with hour and minute keys
                Example: [{'hour': 6, 'minute': 30}, {'hour': 16, 'minute': 0}]
        """
        self.scheduled_times = times
        logger.info(f"Set weather data refresh schedule: {times}")
        
        # Reschedule with new times
        if self.initialized:
            self.schedule_next_refresh()
            
    def schedule_next_refresh(self):
        """Schedule the next data refresh based on configured times"""
        if not self.scheduled_times:
            # Use default schedule from configuration
            self.scheduled_times = CONFIG['default_schedule_times']
            
        now = datetime.now()
        next_refresh = None
        
        # Find the next scheduled time
        for schedule in sorted(self.scheduled_times, key=lambda x: (x['hour'], x['minute'])):
            # Check if this time is later today
            scheduled_time = now.replace(
                hour=schedule['hour'], 
                minute=schedule['minute'],
                second=0,
                microsecond=0
            )
            
            if scheduled_time > now:
                next_refresh = scheduled_time
                break
                
        # If no time found today, use the first time tomorrow
        if next_refresh is None:
            first_schedule = min(self.scheduled_times, key=lambda x: (x['hour'], x['minute']))
            next_refresh = now.replace(
                hour=first_schedule['hour'],
                minute=first_schedule['minute'],
                second=0,
                microsecond=0
            ) + timedelta(days=1)
            
        # Calculate seconds until next refresh
        seconds_until_refresh = (next_refresh - now).total_seconds()
        
        logger.info(
            f"Next weather data refresh scheduled for "
            f"{next_refresh.strftime('%Y-%m-%d %H:%M:%S')} "
            f"({seconds_until_refresh:.0f} seconds from now)"
        )
        
        # Schedule the refresh
        if self.scheduler_thread is not None and self.scheduler_thread.is_alive():
            # Cancel existing scheduled refresh if there is one
            logger.info("Cancelling existing scheduled refresh")
            
        self.scheduler_thread = threading.Timer(seconds_until_refresh, self.refresh_and_reschedule)
        self.scheduler_thread.daemon = True
        self.scheduler_thread.start()
        
    def refresh_and_reschedule(self):
        """Refresh data and schedule the next refresh"""
        # Check for shutdown flag
        if self.shutdown_flag:
            logger.info("Skipping data refresh due to shutdown flag")
            return
            
        try:
            # Clear caches before refreshing
            self.clear_caches()
            
            # Load all forecasts
            logger.info("Refreshing weather data...")
            self.load_all_forecasts()
            logger.info("Weather data refresh complete")
        except Exception as e:
            logger.error(f"Error refreshing weather data: {str(e)}", exc_info=True)
        
        # Schedule the next refresh regardless of success/failure
        self.schedule_next_refresh()
    
    def process_source_data(self, args):
        """Process data for a single source directly without batching"""
        # Check for shutdown before processing
        if self.shutdown_flag:
            logger.info(f"Skipping processing for source {args[0]} due to shutdown")
            return 0
            
        source, countries, variables, dates, releases = args
        processed_count = 0
        
        try:
            # Fetch data
            logger.info(f"Fetching data for source: {source}")
            source_start = time.time()
            source_results = self.fetch_forecast_data(args)
            fetch_time = time.time() - source_start
            logger.info(f"Received {len(source_results)} results for source {source} in {fetch_time:.2f}s")
            
            # Process results directly
            process_start = time.time()
            for i, result in enumerate(source_results):
                # Check for shutdown periodically
                if self.shutdown_flag and i % 10 == 0:
                    logger.info(f"Shutdown detected during processing for source {source} - stopping")
                    break
                    
                source, country, variable, date, release, forecast_data = result
                processed = self._process_single_result(source, country, variable, date, release, forecast_data)
                if processed:
                    processed_count += 1
                    
                # Log progress periodically
                if i > 0 and i % 10 == 0:
                    logger.info(f"Processed {i}/{len(source_results)} results for source {source}")
                    
            process_time = time.time() - process_start
            logger.info(f"Processed {processed_count} results for source {source} in {process_time:.2f}s")
            return processed_count
        except Exception as e:
            logger.error(f"Error processing data for source {source}: {str(e)}")
            return 0
    
    def _process_single_result(self, source, country, variable, date, release, forecast_data):
        """Process a single forecast data result"""
        version_key = f"{date}_{release}"
        
        # Check if forecast_data is an error response
        if isinstance(forecast_data, dict) and forecast_data.get("status") == "failed":
            logger.error(f"Failed to load data for {source}/{country}/{variable}/{version_key}: {forecast_data.get('error')}")
            return False
        
        if forecast_data is not None and (isinstance(forecast_data, pd.DataFrame) and not forecast_data.empty):
            try:
                # Process the data - ensure float32 instead of float64
                processed_data = self.process_forecast_data(forecast_data)
                
                # Only store if we got a non-empty result
                if not processed_data.empty:
                    # Store the raw data efficiently
                    self.global_data[source][country][variable][version_key] = {
                        'data': processed_data.to_dict('records'),
                        'index': processed_data.index.strftime('%Y-%m-%d %H:%M:%S').tolist(),
                        'columns': processed_data.columns.tolist()
                    }
                    
                    # Preprocess the data for plotting
                    self.preprocessed_plots[source][country][variable][version_key] = self.preprocess_plot_data(
                        processed_data,  # Pass DataFrame directly to avoid double conversion
                        source, country, variable, version_key
                    )
                    
                    return True
            except Exception as e:
                logger.error(f"Error processing data for {source}/{country}/{variable}/{version_key}: {str(e)}")
        
        return False
    
    def pregenerate_common_plots(self):
        """Pre-generate commonly accessed plots and cache them for improved responsiveness"""
        logger.info("Pre-generating common plots for faster access")
        start_time = time.time()
        
        # Check if we have data to work with
        if not self.global_data or not self.preprocessed_plots:
            logger.warning("No data available for plot pre-generation")
            return
            
        # Get the latest version
        versions = self.get_available_forecast_versions()
        if not versions:
            logger.warning("No forecast versions available for plot pre-generation")
            return
            
        latest_version = versions[0]  # First version is the most recent
        
        # Define priority countries and variables for pre-generation - ONLY FOR PRIORITY COUNTRIES
        priority_countries = PRIORITY_COUNTRIES  # Only most important countries
        priority_variables = ['Wind', 'PV']  # Most commonly viewed variables  
        priority_sources = list(FORECAST_SOURCES.keys())  # All sources
        
        # Track created plots
        plots_created = 0
        
        # Use with ThreadPoolExecutor for parallel plot generation
        if self.shutdown_flag:
            logger.info("Skipping plot pre-generation due to shutdown")
            return
            
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, CONFIG['max_workers'])) as executor:
                futures = []
                
                # Create plots for priority combinations
                for country in priority_countries:
                    for variable in priority_variables:
                        # Skip if shutting down
                        if self.shutdown_flag:
                            logger.info("Shutdown detected during plot generation - exiting early")
                            return
                            
                        # Create plot for all sources comparison
                        plot_key = f"all_sources_{country}_{variable}_{latest_version}"
                        
                        # Skip if already cached
                        if plot_key in self.plot_cache:
                            continue
                            
                        # Submit the plot generation task
                        try:
                            futures.append(executor.submit(
                                self._generate_cached_plot,
                                priority_sources, country, variable, latest_version, plot_key
                            ))
                        except RuntimeError as e:
                            if "cannot schedule new futures" in str(e):
                                logger.info("Shutdown in progress - stopping plot pre-generation")
                                return
                            logger.error(f"Error scheduling plot generation: {str(e)}")
                
                # Wait for all futures to complete
                for future in concurrent.futures.as_completed(futures):
                    if self.shutdown_flag:
                        logger.info("Shutdown detected during plot generation - exiting early")
                        break
                        
                    try:
                        result = future.result()
                        if result:
                            plots_created += 1
                    except Exception as e:
                        logger.error(f"Error generating cached plot: {str(e)}")
        
        except Exception as e:
            logger.error(f"Error during plot pre-generation: {str(e)}")
            
        total_time = time.time() - start_time
        logger.info(f"Finished pre-generating {plots_created} plots (Time: {total_time:.2f}s)")
        
        # Profile memory after plot generation
        self.profile_memory_usage("after plot generation")
    
    def _generate_cached_plot(self, sources, country, variable, version, plot_key):
        """Generate and cache a single plot
        
        Args:
            sources: List of forecast sources to include
            country: Country to plot
            variable: Weather variable to plot
            version: Forecast version to use
            plot_key: Cache key for the plot
            
        Returns:
            bool: True if plot was successfully generated and cached
        """
        from utils.weather_plotting import create_forecast_figure
        
        try:
            # Check for shutdown
            if self.shutdown_flag:
                return False
                
            # Prepare data for plotting
            preprocessed_data_list = []
            for source in sources:
                # Skip if data doesn't exist
                if (source in self.preprocessed_plots and
                    country in self.preprocessed_plots[source] and
                    variable in self.preprocessed_plots[source][country] and
                    version in self.preprocessed_plots[source][country][variable]):
                    
                    source_data = self.preprocessed_plots[source][country][variable][version]
                    if source_data:
                        # Add metadata for the plotting function
                        plot_item = {
                            'source': source,
                            'data': source_data,
                            'color': self.get_source_colors().get(source, 'rgb(128, 128, 128)'),
                            'source_name': self.get_forecast_sources().get(source, source),
                            'version': version
                        }
                        preprocessed_data_list.append(plot_item)
            
            # Generate the plot if we have data  
            if preprocessed_data_list:
                # Use the main create_forecast_figure from weather_plotting
                figure = create_forecast_figure(
                    variable, country, sources, [version],
                    self.preprocessed_plots, 
                    self.get_source_colors(),
                    self.get_forecast_sources(),
                    self.get_config()
                )
                
                # Cache the plot with size limit enforcement
                with self.data_lock:
                    # Enforce cache size limit
                    if len(self.plot_cache) >= CONFIG['cache_size']:
                        # Remove oldest entry (FIFO)
                        oldest_key = next(iter(self.plot_cache))
                        del self.plot_cache[oldest_key]
                        logger.info(
                            f"Cache size limit reached, "
                            f"removed oldest entry: {oldest_key}"
                        )
                    
                    self.plot_cache[plot_key] = figure
                return True
        
        except Exception as e:
            logger.error(f"Error generating plot for {country} {variable}: {str(e)}")
        
        return False 