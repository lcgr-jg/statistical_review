# Fundamentals Dashboard

A comprehensive dashboard for monitoring power market fundamentals including plant availability, generation data, and renewable forecasts.

## Features

- **Availability Analysis**: Track power plant availability across different time periods and countries
- **Generation vs Availability**: Compare actual generation against availability forecasts
- **Renewables Forecast**: View and analyze renewable power forecasts including wind, solar and power demand

## Requirements

- Python 3.8+
- Dash
- Plotly
- Pandas
- NumPy
- Dash Bootstrap Components
- jain_commods (custom package)

## Running the Dashboard

1. Clone the repository
2. Install the required dependencies: `pip install -r requirements.txt`
3. Run the application: `python app.py`
4. Open your browser and navigate to: `http://0.0.0.0:9101/`

## Pages

### Home
The main dashboard landing page with navigation to the various analysis tools.

### Availability
Analyze power plant availability data by country and fuel type, with historical comparisons.

### Generation vs Availability
Compare actual generation against plant availability to identify trends and discrepancies.

### Weather Forecast
View renewable power production forecasts from multiple sources including:
- ECMWF Ensemble forecasts
- ECMWF High Resolution forecasts
- GEFS forecasts
- Meteologica forecasts
- Climate normals

## Data Sources
The dashboard retrieves data from Kpler Power and Meteologica APIs through the jain_commods package. 