import sys
import pathlib

from dash import html, dcc, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import logging

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import url_for  # noqa: E402

logger = logging.getLogger(__name__)

def get_layout(data_handler):
    """Get the layout for the home page"""
    
    # Check if data is ready or still loading
    data_loading_status = html.Div([
        dbc.Alert(
            [
                html.I(className="fas fa-spinner fa-spin me-2"),
                "Data is being loaded in the background. Basic navigation is available, but data visualizations will appear once loading completes."
            ],
            color="info",
            className="mb-4",
            id="data-loading-alert",
            is_open=not data_handler.is_ready
        )
    ])
    
    return html.Div([
        # Navigation menu
        dbc.Navbar(
            [
                dbc.NavbarBrand("Fundamentals Dashboard", href="/", className="ms-2"),
                dbc.Nav(
                    [
                        dbc.NavItem(dbc.NavLink("Home", href="/", active=True)),
                        dbc.NavItem(dbc.NavLink("Availability", href="/availability")),
                        dbc.NavItem(dbc.NavLink("Generation vs Availability", href="/generation-vs-availability")),
                        dbc.NavItem(dbc.NavLink("Weather Forecast", href="/weather-forecast")),
                        dbc.NavItem(dbc.NavLink("Forecast Compare", href="/forecast-comparison")),
                        dbc.NavItem(dbc.NavLink("Prices", href=url_for('price'), external_link=True)),
                        dbc.NavItem(dbc.NavLink("Stack", href=url_for('stack'), external_link=True)),
                        dbc.NavItem(dbc.NavLink("Portal", href=url_for('portal'), external_link=True)),
                    ],
                    className="ms-auto",
                    navbar=True
                )
            ],
            dark=True,
            className="dashboard-navbar mb-3"
        ),
        
        # App header
        dbc.Row([
            dbc.Col([
                html.H1("Fundamentals Dashboard", className="my-4")
            ], width=12)
        ]),
        
        # Data loading status
        data_loading_status,
        
        # Navigation cards
        dbc.Row([
            # Availability Analysis Card
            dbc.Col(
                dbc.Card([
                    dbc.CardHeader("Availability Analysis", className="text-center"),
                    dbc.CardBody([
                        html.P("Analyze power plant availability across different time periods and countries."),
                        dbc.Button("Go to Analysis", href="/availability", color="primary", className="mt-3")
                    ])
                ], className="h-100 control-card"),
                width=4, className="mb-4"
            ),
            
            # Generation vs Availability Card
            dbc.Col(
                dbc.Card([
                    dbc.CardHeader("Generation vs Availability", className="text-center"),
                    dbc.CardBody([
                        html.P("Compare actual generation against availability forecasts."),
                        dbc.Button("Go to Analysis", href="/generation-vs-availability", color="primary", className="mt-3")
                    ])
                ], className="h-100 control-card"),
                width=4, className="mb-4"
            ),
            
            # Weather Forecast Card
            dbc.Col(
                dbc.Card([
                    dbc.CardHeader("Weather Forecast", className="text-center"),
                    dbc.CardBody([
                        html.P("Analyze renewable energy forecasts from different weather models."),
                        dbc.Button("Go to Forecast", href="/weather-forecast", color="primary", className="mt-3")
                    ])
                ], className="h-100 control-card"),
                width=4, className="mb-4"
            )
        ]),

        # Forecast Comparison Card (second row)
        dbc.Row([
            dbc.Col(
                dbc.Card([
                    dbc.CardHeader("Forecast Comparison – EQ vs Meteologica", className="text-center"),
                    dbc.CardBody([
                        html.P("Compare Energy Quantified price forecasts and residual loads against Meteologica."),
                        dbc.Button("Go to Comparison", href="/forecast-comparison", color="info", className="mt-3")
                    ])
                ], className="h-100 control-card"),
                width=6, className="mb-4"
            ),
        ])
    ])

def register_home_callbacks(app, data_handler):
    """Register all callbacks for the home page"""
    
    @app.callback(
        Output("data-loading-alert", "is_open"),
        [Input("display-interval", "n_intervals")]
    )
    def update_loading_status(n):
        return not data_handler.is_ready