"""
Forecast Comparison Page
========================
Compares ECMWF-ENS ensemble mean forecasts (via Energy Quantified) against
Meteologica forecasts (from Snowflake), side-by-side per country.

Each trace is labelled with its forecast source and initialisation time so it
is clear exactly which model run is being displayed.

Layout
------
- Country tabs (DE, FR, UK, NL, BE, ES)
- Section 1: Residual Load    – EQ ensemble vs Meteologica residual load
- Section 2: Wind / Solar / Demand breakdown comparison
- Daily averages table below each comparison chart
"""

import logging
import pathlib
import sys
import threading
from datetime import datetime, timedelta, date

import dash
import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import html, dcc, Input, Output, dash_table

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import url_for  # noqa: E402

from utils.eq_client import (
    get_eq_client, eq_area, DASHBOARD_COUNTRIES, FUEL_DISPLAY_LABELS,
)
from jain_commods.core.interfaces.energyquantified.curves import (
    DEMAND_FORECAST, GENERATION_FORECAST,
    DEMAND_ACTUAL, get_curve,
)
from jain_commods.core.interfaces.snowflake.mlgquery import MeteologicaQuery
from utils.cache import cached, clear_all

logger = logging.getLogger(__name__)

# ── Theme constants (matching price_dashboard) ───────────────────────────────

PLOT_HEIGHT = 480
PLOT_TEMPLATE = 'plotly_dark'

DARK_LAYOUT = dict(
    template=PLOT_TEMPLATE,
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)',
    font_color='#e0e0e0',
    hoverlabel=dict(
        bgcolor='#22262e',
        font_color='#e0e0e0',
        font_size=12,
        bordercolor='#353a44',
    ),
    xaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
    yaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
    height=PLOT_HEIGHT,
    margin=dict(l=50, r=20, t=50, b=40),
    legend=dict(
        bgcolor='rgba(34,38,46,0.95)',
        font=dict(color='#e0e0e0', size=11),
        bordercolor='#353a44',
        borderwidth=1,
    ),
    hovermode='x unified',
)

COLORS = {
    'eq_wind': '#4dabf7',
    'eq_solar': '#ffa94d',
    'eq_demand': '#51cf66',
    'eq_resload': '#51cf66',
    'met_wind': '#ff6b6b',
    'met_solar': '#ff6b6b',
    'met_demand': '#ff6b6b',
    'met_resload': '#ff6b6b',
    'normal': '#8a8f9a',
}

TABLE_STYLE_HEADER = {
    'backgroundColor': '#1e3a5f',
    'color': '#e0e0e0',
    'fontWeight': '600',
    'fontSize': '0.82rem',
    'border': '1px solid #353a44',
    'textAlign': 'center',
}

TABLE_STYLE_CELL = {
    'backgroundColor': '#22262e',
    'color': '#e0e0e0',
    'fontSize': '0.82rem',
    'border': '1px solid #353a44',
    'textAlign': 'center',
    'padding': '6px 10px',
}

TABLE_STYLE_DATA_CONDITIONAL = [
    {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
]


def _styled_layout(title: str, y_title: str = 'EUR/MWh') -> dict:
    layout = dict(DARK_LAYOUT)
    layout['title'] = dict(text=title, font=dict(size=15, color='#e0e0e0'))
    layout['yaxis'] = dict(
        gridcolor='rgba(255,255,255,0.06)', zeroline=False, title=y_title,
    )
    return layout


# ── Timezone helpers ─────────────────────────────────────────────────────────

def _to_cet(idx):
    """Ensure a DatetimeIndex is in CET (Europe/Berlin). Returns naive CET."""
    if idx is None or len(idx) == 0:
        return idx
    if hasattr(idx, 'tz') and idx.tz is not None:
        return idx.tz_convert('Europe/Berlin').tz_localize(None)
    return idx


def _df_to_cet(df: pd.DataFrame) -> pd.DataFrame:
    """Convert a DataFrame's datetime index to naive CET."""
    if df is None or df.empty:
        return df
    df = df.copy()
    df.index = _to_cet(df.index)
    return df


# ── Label helpers ─────────────────────────────────────────────────────────────

_TAG_DISPLAY = {
    'ec-ens': 'ECMWF-ENS',
    'ec': 'ECMWF-HRES',
    'gfs-ens': 'GEFS',
}


def _eq_issued_label(df: pd.DataFrame) -> str:
    """Extract EQ issued datetime from df.attrs and format as 'ECMWF-ENS 09 Apr 12Z'."""
    issued = df.attrs.get('issued') if hasattr(df, 'attrs') else None
    tag = df.attrs.get('tag', 'ec-ens') if hasattr(df, 'attrs') else 'ec-ens'
    tag_str = _TAG_DISPLAY.get(str(tag), str(tag).upper())
    if issued is not None:
        try:
            if hasattr(issued, 'strftime'):
                return f"{tag_str} {issued.strftime('%d %b %HZ')}"
        except Exception:
            pass
    return tag_str


# ── EQ data fetching helpers (all in CET) ────────────────────────────────────

@cached
def _fetch_eq_ensemble_mean(curve: str, col_name: str,
                            tag: str = 'ec-ens',
                            freq: str = 'PT1H') -> pd.DataFrame:
    """Fetch the latest ECMWF-ENS forecast and return the ensemble mean.

    Returns a single-column DataFrame (named *col_name*) with attrs
    ``issued`` and ``tag`` preserved for labelling.
    """
    client = get_eq_client()
    try:
        df = client.get_latest_forecast(
            curve, tags=tag, frequency=freq, time_zone='CET', ensembles=True,
        )
        if df is None or df.empty:
            return pd.DataFrame()

        saved_attrs = dict(df.attrs) if hasattr(df, 'attrs') else {}
        df = _df_to_cet(df)

        # Ensemble returns multi-column data; compute the mean across members
        numeric = df.select_dtypes(include='number')
        if numeric.shape[1] > 1:
            mean_series = numeric.mean(axis=1)
        else:
            mean_series = numeric.iloc[:, 0]

        result = pd.DataFrame({col_name: mean_series}, index=df.index)
        result.attrs.update(saved_attrs)
        result.attrs['tag'] = tag
        return result
    except Exception as exc:
        logger.warning("EQ ensemble %s (tag=%s): %s", curve, tag, exc)
        return pd.DataFrame()


def _fetch_eq_wind_forecast(area: str) -> pd.DataFrame:
    curve = get_curve(GENERATION_FORECAST, area, 'wind')
    if not curve:
        return pd.DataFrame()
    return _fetch_eq_ensemble_mean(curve, 'wind')


def _fetch_eq_solar_forecast(area: str) -> pd.DataFrame:
    curve = get_curve(GENERATION_FORECAST, area, 'solar')
    if not curve:
        return pd.DataFrame()
    return _fetch_eq_ensemble_mean(curve, 'solar')


def _fetch_eq_demand_forecast(area: str) -> pd.DataFrame:
    curve = DEMAND_FORECAST.get(area)
    if not curve:
        return pd.DataFrame()
    return _fetch_eq_ensemble_mean(curve, 'demand')


# ── Climate normal helpers ─────────────────────────────────────────────────

_NORMAL_CURVES = {
    'wind': '{area} Wind Power Production MWh/h 15min Normal',
    'solar': '{area} Solar Photovoltaic Production MWh/h 15min Normal',
    'demand': '{area} Consumption MWh/h 15min Normal',
    'residual_load': '{area} Residual Load MWh/h 15min Normal',
}


@cached
def _fetch_eq_normal(area: str, variable: str,
                     begin: date = None, end: date = None) -> pd.DataFrame:
    """Fetch a climate-normal timeseries from EQ, aligned to the forecast window."""
    template = _NORMAL_CURVES.get(variable)
    if not template:
        return pd.DataFrame()
    curve = template.format(area=area)
    client = get_eq_client()
    if begin is None:
        begin = date.today()
    if end is None:
        end = date.today() + timedelta(days=15)
    try:
        df = client.get_normal(curve, begin=begin, end=end, time_zone='CET', frequency='PT1H')
        if not df.empty:
            df.columns = [variable]
        return _df_to_cet(df)
    except Exception as exc:
        logger.warning("EQ normal %s/%s: %s", area, variable, exc)
        return pd.DataFrame()


def _forecast_range(*dfs) -> tuple:
    """Return (min_date, max_date) across a set of DataFrames."""
    lo, hi = None, None
    for df in dfs:
        if df is not None and not df.empty:
            idx = df.index
            df_min = idx.min()
            df_max = idx.max()
            lo = df_min if lo is None else min(lo, df_min)
            hi = df_max if hi is None else max(hi, df_max)
    if lo is None:
        today = date.today()
        return today, today + timedelta(days=15)
    return lo.date() if hasattr(lo, 'date') else lo, \
           hi.date() + timedelta(days=1) if hasattr(hi, 'date') else hi


def _compute_eq_residual_load(area: str) -> pd.DataFrame:
    """Residual load = demand - wind - solar (all from EQ latest forecasts)."""
    wind = _fetch_eq_wind_forecast(area)
    solar = _fetch_eq_solar_forecast(area)
    demand = _fetch_eq_demand_forecast(area)

    if demand.empty:
        return pd.DataFrame()

    result = pd.DataFrame(index=demand.index)
    result['demand'] = demand['demand']
    result['wind'] = wind['wind'].reindex(result.index, fill_value=0) if not wind.empty else 0
    result['solar'] = solar['solar'].reindex(result.index, fill_value=0) if not solar.empty else 0
    result['residual_load'] = result['demand'] - result['wind'] - result['solar']
    result.attrs['issued'] = demand.attrs.get('issued')
    result.attrs['tag'] = demand.attrs.get('tag')
    return result


# ── Meteologica data (from Snowflake via MeteologicaQuery) ────────────────────

_met_query = None
_met_lock = threading.Lock()

_CODE_TO_MET_COUNTRY = {
    'DE': 'Germany', 'FR': 'France', 'UK': 'UK',
    'NL': 'Netherlands', 'BE': 'Belgium', 'ES': 'Spain',
}

_MET_OFFSET = 'post_ECMWF-ENS'

def _aggregate_met_wind(raw: pd.DataFrame, col_name: str) -> pd.DataFrame:
    """Select the correct wind forecast from potentially duplicated rows.

    Strategy (per the user's rule):
      - If Total exists alongside Onshore/Offshore: use Total only.
      - If only Onshore + Offshore (no Total): sum them.
    We identify sub-types by scanning all non-numeric columns for values
    containing 'total', 'onshore', or 'offshore'.
    """
    # Handle duplicate column names from the Snowflake JOIN
    if raw.columns.duplicated().any():
        raw = raw.loc[:, ~raw.columns.duplicated()]

    rows_per_ts = raw.groupby('FROM_DATETIME').size()
    if rows_per_ts.empty:
        return pd.DataFrame(columns=[col_name])

    typical_count = int(rows_per_ts.median())
    logger.info("Met wind aggregation: %d rows/timestamp (median)", typical_count)

    if typical_count <= 1:
        return (raw.groupby('FROM_DATETIME')['FORECAST']
                .first().sort_index().to_frame(name=col_name))

    # Find a column that distinguishes Total vs Onshore/Offshore
    type_col = None
    for c in raw.select_dtypes(include='object').columns:
        if c in ('FROM_DATETIME', 'FORECAST'):
            continue
        lower_vals = raw[c].astype(str).str.lower().unique()
        has_total = any('total' in v for v in lower_vals)
        has_parts = any('onshore' in v or 'offshore' in v for v in lower_vals)
        if has_total or has_parts:
            type_col = c
            logger.info("Met wind: found type column '%s' with values: %s",
                        c, raw[c].unique()[:10].tolist())
            break

    if type_col is not None:
        vals_lower = raw[type_col].astype(str).str.lower()

        # The national-level total is the unqualified name:
        # "<Country> wind power generation forecast ..." — "wind" is the second
        # word, with no TSO name or onshore/offshore qualifier in between.
        national_mask = vals_lower.str.match(r'^\S+\s+wind\s+power', na=False)

        if national_mask.any():
            national_rows = raw[national_mask]
            names_used = raw.loc[national_mask, type_col].unique().tolist()
            logger.info("Met wind: using national total rows via %s=%s (%d/%d rows)",
                        type_col, names_used, len(national_rows), len(raw))
            return (national_rows.groupby('FROM_DATETIME')['FORECAST']
                    .first().sort_index().to_frame(name=col_name))

        # No national total found — sum all rows per timestamp
        logger.info("Met wind: no national total found, summing %d rows/ts",
                    typical_count)
        return (raw.groupby('FROM_DATETIME')['FORECAST']
                .sum().sort_index().to_frame(name=col_name))

    # No distinguishing column — sum all rows per timestamp
    logger.info("Met wind: no type col found, summing %d rows/ts", typical_count)
    return (raw.groupby('FROM_DATETIME')['FORECAST']
            .sum().sort_index().to_frame(name=col_name))


def _get_met_query() -> MeteologicaQuery:
    global _met_query
    if _met_query is None:
        with _met_lock:
            if _met_query is None:
                _met_query = MeteologicaQuery()
    return _met_query


def _met_issued_label(df: pd.DataFrame) -> str:
    """Format 'Meteologica (DD Mon HHZ)' from attrs set by the fetch helpers."""
    d = df.attrs.get('met_date') if hasattr(df, 'attrs') else None
    rel = df.attrs.get('met_release', '') if hasattr(df, 'attrs') else ''
    if d is not None:
        try:
            return f"Meteologica {d.strftime('%d %b')} {rel}Z"
        except Exception:
            pass
    return 'Meteologica'


@cached
def _fetch_met_variable(country_code: str, fuel_type=None, category=None,
                        col_name: str = 'value') -> pd.DataFrame:
    """Fetch latest Meteologica forecast from Snowflake, trying releases
    in reverse order until data is found.

    Returns a single-column DataFrame (hourly, CET-naive) with attrs
    ``met_date`` and ``met_release`` set for labelling.
    """
    mq = _get_met_query()
    country = _CODE_TO_MET_COUNTRY.get(country_code, country_code)
    now = datetime.now()
    today = now.date()

    candidates = []
    for days_back in range(4):
        d = today - timedelta(days=days_back)
        for release in ['12', '00']:
            if d == today and int(release) > now.hour:
                continue
            candidates.append((d, release))

    for d, release in candidates:
        try:
            kwargs = dict(
                issue_date=datetime.combine(d, datetime.min.time()),
                release=release,
                offset=_MET_OFFSET,
                country=country,
            )
            if category:
                kwargs['category'] = category
            if fuel_type:
                kwargs['fuel_type'] = fuel_type

            raw = mq.get_meteologica_forecast(**kwargs)
            if raw is None or raw.empty:
                continue

            expected_uid = f"{d.strftime('%Y%m%d')}{release.ljust(4, '0')}_{_MET_OFFSET}"
            if 'UPDATE_ID' in raw.columns:
                raw = raw[raw['UPDATE_ID'] == expected_uid]
            if raw.empty:
                continue

            if fuel_type != 'Wind' and 'SUB_REGION' in raw.columns:
                raw = raw[
                    raw['SUB_REGION'].isna()
                    | (raw['SUB_REGION'] == '')
                    | (raw['SUB_REGION'].str.strip() == '')
                ]
                if raw.empty:
                    logger.warning("Meteologica %s/%s %s_%s: all rows have sub-regions",
                                   country_code, fuel_type or category, d, release)
                    continue

            if 'FREQUENCY' in raw.columns:
                raw = raw[raw['FREQUENCY'] == 'Hourly']
            if raw.empty:
                continue

            if 'FORECAST' not in raw.columns:
                logger.warning("Meteologica %s/%s %s_%s: no FORECAST column",
                               country_code, fuel_type or category, d, release)
                continue

            if 'FROM_DATETIME' not in raw.columns:
                continue

            raw['FROM_DATETIME'] = pd.to_datetime(raw['FROM_DATETIME'])
            raw['FORECAST'] = pd.to_numeric(raw['FORECAST'], errors='coerce')

            # Handle duplicate column names from Snowflake JOIN
            if raw.columns.duplicated().any():
                raw = raw.loc[:, ~raw.columns.duplicated()]

            n_before_dedup = len(raw)
            ts_counts = raw.groupby('FROM_DATETIME').size()
            n_dups = (ts_counts > 1).sum()
            if n_dups > 0:
                logger.info("Meteologica %s/%s %s_%s: %d timestamps have %d+ rows (max %d)",
                            country_code, fuel_type or category, d, release,
                            n_dups, ts_counts.max(), ts_counts.max())

            result = _aggregate_met_wind(raw, col_name) if fuel_type == 'Wind' else (
                raw.groupby('FROM_DATETIME')['FORECAST']
                .first()
                .sort_index()
                .to_frame(name=col_name)
            )

            # Snowflake timestamps are UTC; convert to naive CET to match EQ
            if result.index.tz is None:
                result.index = result.index.tz_localize('UTC')
            result.index = result.index.tz_convert('Europe/Berlin').tz_localize(None)

            # Resample to clean hourly grid to remove sub-hourly noise
            result = result.resample('1h').mean().dropna()

            result.attrs['met_date'] = d
            result.attrs['met_release'] = release
            logger.info("Meteologica %s/%s found: %s_%s (%d raw → %d hourly rows)",
                        country_code, fuel_type or category, d, release,
                        n_before_dedup, len(result))
            return result

        except Exception as exc:
            logger.warning("Meteologica %s/%s %s_%s: %s",
                           country_code, fuel_type or category, d, release, exc)

    logger.warning("Meteologica %s/%s: no data in last 4 days",
                   country_code, fuel_type or category)
    return pd.DataFrame()


def _fetch_met_wind_forecast(country_code: str) -> pd.DataFrame:
    return _fetch_met_variable(country_code, fuel_type='Wind', col_name='wind')


def _fetch_met_solar_forecast(country_code: str) -> pd.DataFrame:
    return _fetch_met_variable(country_code, fuel_type='PV', col_name='solar')


def _fetch_met_demand_forecast(country_code: str) -> pd.DataFrame:
    return _fetch_met_variable(country_code, category='PowerDemand', col_name='demand')


def _compute_met_residual_load(country_code: str) -> pd.DataFrame:
    """Residual load = demand - wind - solar (all from Meteologica / Snowflake)."""
    wind = _fetch_met_wind_forecast(country_code)
    solar = _fetch_met_solar_forecast(country_code)
    demand = _fetch_met_demand_forecast(country_code)

    if demand.empty:
        return pd.DataFrame()

    result = pd.DataFrame(index=demand.index)
    result['demand'] = demand['demand']
    result['wind'] = wind['wind'].reindex(result.index, fill_value=0) if not wind.empty else 0
    result['solar'] = solar['solar'].reindex(result.index, fill_value=0) if not solar.empty else 0
    result['residual_load'] = result['demand'] - result['wind'] - result['solar']
    result.attrs['met_date'] = demand.attrs.get('met_date')
    result.attrs['met_release'] = demand.attrs.get('met_release')
    return result


# ── Daily averages table builder ─────────────────────────────────────────────

def _build_daily_table(eq_times, eq_values, ens_times, ens_values,
                       eq_label: str, ens_label: str, unit: str = 'MWh/h'):
    """Build a daily-average comparison table from two time series."""
    rows = []

    eq_daily = {}
    if eq_times is not None and eq_values is not None and len(eq_times) > 0:
        s = pd.Series(eq_values, index=pd.DatetimeIndex(eq_times))
        eq_daily = s.resample('D').mean().dropna()

    ens_daily = {}
    if ens_times is not None and ens_values is not None and len(ens_times) > 0:
        s = pd.Series(ens_values, index=pd.DatetimeIndex(ens_times))
        ens_daily = s.resample('D').mean().dropna()

    if isinstance(eq_daily, pd.Series):
        all_dates = set(eq_daily.index.date)
    else:
        all_dates = set()
    if isinstance(ens_daily, pd.Series):
        all_dates |= set(ens_daily.index.date)

    has_second = isinstance(ens_daily, pd.Series) and not ens_daily.empty

    for d in sorted(all_dates):
        ts = pd.Timestamp(d)
        eq_val = eq_daily.get(ts) if isinstance(eq_daily, pd.Series) else None
        ens_val = ens_daily.get(ts) if isinstance(ens_daily, pd.Series) else None

        row = {
            'Date': d.strftime('%a %d %b'),
            eq_label: f'{eq_val:,.1f}' if eq_val is not None else '—',
        }

        if has_second:
            diff = None
            if eq_val is not None and ens_val is not None:
                diff = eq_val - ens_val
            row[ens_label] = f'{ens_val:,.1f}' if ens_val is not None else '—'
            row[f'Diff ({unit})'] = f'{diff:+,.1f}' if diff is not None else '—'

        rows.append(row)

    if not rows:
        return html.Div()

    columns = [{'name': c, 'id': c} for c in rows[0].keys()]

    return dash_table.DataTable(
        data=rows,
        columns=columns,
        style_header=TABLE_STYLE_HEADER,
        style_cell=TABLE_STYLE_CELL,
        style_data_conditional=TABLE_STYLE_DATA_CONDITIONAL,
        style_table={'overflowX': 'auto'},
        page_size=14,
    )


# ── Country name mapping ─────────────────────────────────────────────────────

_COUNTRY_FULL = {
    'DE': 'Germany', 'FR': 'France', 'UK': 'UK',
    'NL': 'Netherlands', 'BE': 'Belgium',
}


# ── Layout ───────────────────────────────────────────────────────────────────

def get_layout(data_handler=None):
    nav_bar = dbc.Navbar(
        [
            dbc.NavbarBrand("Fundamentals Dashboard", href="/", className="ms-2"),
            dbc.Nav([
                dbc.NavItem(dbc.NavLink("Home", href="/")),
                dbc.NavItem(dbc.NavLink("Availability", href="/availability")),
                dbc.NavItem(dbc.NavLink("Gen vs Avail", href="/generation-vs-availability")),
                dbc.NavItem(dbc.NavLink("Weather", href="/weather-forecast")),
                dbc.NavItem(dbc.NavLink("Forecast Compare", href="/forecast-comparison", active=True)),
                dbc.NavItem(dbc.NavLink("Prices", href=url_for('price'), external_link=True)),
                dbc.NavItem(dbc.NavLink("Stack", href=url_for('stack'), external_link=True)),
                dbc.NavItem(dbc.NavLink("Portal", href=url_for('portal'), external_link=True)),
            ], className="ms-auto", navbar=True),
        ],
        dark=True, className="dashboard-navbar mb-3",
    )

    return html.Div([
        nav_bar,
        dbc.Container([
            dbc.Row([
                dbc.Col(
                    html.H4("Forecast Comparison — EQ vs Meteologica", className="my-3"),
                    width='auto',
                ),
                dbc.Col(
                    dbc.Button("⟳ Refresh Data", id='fc-refresh', color='primary',
                               size='sm', className='my-3'),
                    width='auto',
                ),
                dbc.Col(
                    html.Span(id='fc-refresh-status', style={'color': '#8a8f9a', 'fontSize': '0.8rem'}),
                    className='d-flex align-items-center',
                ),
            ], align='center'),
            dbc.Row(dbc.Col(
                dbc.Card(dbc.CardBody(
                    dbc.Tabs(
                        id='fc-country-tabs',
                        active_tab='DE',
                        children=[dbc.Tab(label=c, tab_id=c) for c in DASHBOARD_COUNTRIES],
                    ),
                )),
            )),
            dbc.Row(dbc.Col(
                dcc.Loading(
                    id='fc-loading',
                    type='circle',
                    children=[html.Div(id='fc-content', className='mt-3')],
                ),
            )),
        ], fluid=True),
    ])


# ── Callbacks ────────────────────────────────────────────────────────────────

def register_forecast_comparison_callbacks(app, data_handler=None):

    @app.callback(
        [Output('fc-content', 'children'),
         Output('fc-refresh-status', 'children')],
        [Input('fc-country-tabs', 'active_tab'),
         Input('fc-refresh', 'n_clicks')],
    )
    def render_comparison(country_code: str, n_clicks):
        ctx = dash.callback_context
        trigger = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else None

        if trigger == 'fc-refresh' and n_clicks:
            clear_all()
            logger.info("Forecast comparison cache cleared via refresh button")

        if not country_code:
            return html.Div(), ""

        area = eq_area(country_code)
        country_name = _COUNTRY_FULL.get(country_code, country_code)

        # ── 1. Residual Load ──────────────────────────────────────────
        eq_rl = _compute_eq_residual_load(area)
        eq_rl_label = f'EQ ({_eq_issued_label(eq_rl)})' if not eq_rl.empty else 'EQ'

        met_rl = _compute_met_residual_load(country_code)
        met_rl_label = _met_issued_label(met_rl) if not met_rl.empty else 'Meteologica'

        # ── 2. Wind / Solar / Demand ─────────────────────────────────
        eq_wind = _fetch_eq_wind_forecast(area)
        met_wind = _fetch_met_wind_forecast(country_code)
        eq_solar = _fetch_eq_solar_forecast(area)
        met_solar = _fetch_met_solar_forecast(country_code)
        eq_demand = _fetch_eq_demand_forecast(area)
        met_demand = _fetch_met_demand_forecast(country_code)

        # ── Normals: derive date range from all forecast data ────────
        n_begin, n_end = _forecast_range(
            eq_rl, met_rl, eq_wind, met_wind, eq_solar, met_solar,
            eq_demand, met_demand,
        )
        normal_rl = _fetch_eq_normal(area, 'residual_load', n_begin, n_end)
        normal_wind = _fetch_eq_normal(area, 'wind', n_begin, n_end)
        normal_solar = _fetch_eq_normal(area, 'solar', n_begin, n_end)
        normal_demand = _fetch_eq_normal(area, 'demand', n_begin, n_end)

        # ── Build residual load figure ───────────────────────────────
        resload_fig = go.Figure()
        if not eq_rl.empty:
            resload_fig.add_trace(go.Scatter(
                x=eq_rl.index, y=eq_rl['residual_load'],
                name=f'{eq_rl_label} Res. Load',
                line=dict(color=COLORS['eq_resload'], width=2),
            ))
            resload_fig.add_trace(go.Scatter(
                x=eq_rl.index, y=eq_rl['demand'],
                name=f'{eq_rl_label} Demand',
                line=dict(color=COLORS['eq_demand'], width=1, dash='dot'),
            ))
        if not met_rl.empty:
            resload_fig.add_trace(go.Scatter(
                x=met_rl.index, y=met_rl['residual_load'],
                name=f'{met_rl_label} Res. Load',
                line=dict(color=COLORS['met_resload'], width=2, dash='dash'),
            ))
        if not normal_rl.empty:
            resload_fig.add_trace(go.Scatter(
                x=normal_rl.index, y=normal_rl['residual_load'],
                name='Climate Normal',
                line=dict(color=COLORS['normal'], width=1.5, dash='dot'),
                opacity=0.7,
            ))

        resload_fig.update_layout(**_styled_layout(
            f'{country_name} — Residual Load Comparison', 'MW'))

        resload_table = _build_daily_table(
            eq_rl.index if not eq_rl.empty else None,
            eq_rl['residual_load'].values if not eq_rl.empty else None,
            met_rl.index if not met_rl.empty else None,
            met_rl['residual_load'].values if not met_rl.empty else None,
            f'{eq_rl_label} (MW)', f'{met_rl_label} (MW)', 'MW',
        )

        # ── Wind figure ───────────────────────────────────────────────
        eq_wind_label = f'EQ ({_eq_issued_label(eq_wind)})' if not eq_wind.empty else 'EQ'
        met_wind_label = _met_issued_label(met_wind) if not met_wind.empty else 'Meteologica'

        wind_fig = go.Figure()
        if not eq_wind.empty:
            wind_fig.add_trace(go.Scatter(
                x=eq_wind.index, y=eq_wind['wind'],
                name=f'{eq_wind_label} Wind',
                line=dict(color=COLORS['eq_wind'], width=2),
            ))
        if not met_wind.empty:
            wind_fig.add_trace(go.Scatter(
                x=met_wind.index, y=met_wind['wind'],
                name=f'{met_wind_label} Wind',
                line=dict(color=COLORS['met_wind'], width=2, dash='dash'),
            ))
        if not normal_wind.empty:
            wind_fig.add_trace(go.Scatter(
                x=normal_wind.index, y=normal_wind['wind'],
                name='Climate Normal',
                line=dict(color=COLORS['normal'], width=1.5, dash='dot'),
                opacity=0.7,
            ))
        wind_fig.update_layout(**_styled_layout(f'{country_name} — Wind Forecast', 'MWh/h'))

        wind_table = _build_daily_table(
            eq_wind.index if not eq_wind.empty else None,
            eq_wind['wind'].values if not eq_wind.empty else None,
            met_wind.index if not met_wind.empty else None,
            met_wind['wind'].values if not met_wind.empty else None,
            f'{eq_wind_label} (MWh/h)', f'{met_wind_label} (MWh/h)', 'MWh/h',
        )

        # ── Solar figure ──────────────────────────────────────────────
        eq_solar_label = f'EQ ({_eq_issued_label(eq_solar)})' if not eq_solar.empty else 'EQ'
        met_solar_label = _met_issued_label(met_solar) if not met_solar.empty else 'Meteologica'

        solar_fig = go.Figure()
        if not eq_solar.empty:
            solar_fig.add_trace(go.Scatter(
                x=eq_solar.index, y=eq_solar['solar'],
                name=f'{eq_solar_label} Solar',
                line=dict(color=COLORS['eq_solar'], width=2),
            ))
        if not met_solar.empty:
            solar_fig.add_trace(go.Scatter(
                x=met_solar.index, y=met_solar['solar'],
                name=f'{met_solar_label} Solar',
                line=dict(color=COLORS['met_solar'], width=2, dash='dash'),
            ))
        if not normal_solar.empty:
            solar_fig.add_trace(go.Scatter(
                x=normal_solar.index, y=normal_solar['solar'],
                name='Climate Normal',
                line=dict(color=COLORS['normal'], width=1.5, dash='dot'),
                opacity=0.7,
            ))
        solar_fig.update_layout(**_styled_layout(f'{country_name} — Solar Forecast', 'MWh/h'))

        solar_table = _build_daily_table(
            eq_solar.index if not eq_solar.empty else None,
            eq_solar['solar'].values if not eq_solar.empty else None,
            met_solar.index if not met_solar.empty else None,
            met_solar['solar'].values if not met_solar.empty else None,
            f'{eq_solar_label} (MWh/h)', f'{met_solar_label} (MWh/h)', 'MWh/h',
        )

        # ── Demand figure ─────────────────────────────────────────────
        eq_demand_label = f'EQ ({_eq_issued_label(eq_demand)})' if not eq_demand.empty else 'EQ'
        met_demand_label = _met_issued_label(met_demand) if not met_demand.empty else 'Meteologica'

        demand_fig = go.Figure()
        if not eq_demand.empty:
            demand_fig.add_trace(go.Scatter(
                x=eq_demand.index, y=eq_demand['demand'],
                name=f'{eq_demand_label} Demand',
                line=dict(color=COLORS['eq_demand'], width=2),
            ))
        if not met_demand.empty:
            demand_fig.add_trace(go.Scatter(
                x=met_demand.index, y=met_demand['demand'],
                name=f'{met_demand_label} Demand',
                line=dict(color=COLORS['met_demand'], width=2, dash='dash'),
            ))
        if not normal_demand.empty:
            demand_fig.add_trace(go.Scatter(
                x=normal_demand.index, y=normal_demand['demand'],
                name='Climate Normal',
                line=dict(color=COLORS['normal'], width=1.5, dash='dot'),
                opacity=0.7,
            ))
        demand_fig.update_layout(**_styled_layout(f'{country_name} — Demand Forecast', 'MWh/h'))

        demand_table = _build_daily_table(
            eq_demand.index if not eq_demand.empty else None,
            eq_demand['demand'].values if not eq_demand.empty else None,
            met_demand.index if not met_demand.empty else None,
            met_demand['demand'].values if not met_demand.empty else None,
            f'{eq_demand_label} (MWh/h)', f'{met_demand_label} (MWh/h)', 'MWh/h',
        )

        # ── Assemble ─────────────────────────────────────────────────
        content = html.Div([
            html.H5(f'{country_name} — EQ vs Meteologica Forecast Comparison',
                     className='text-center mb-3', style={'color': '#e0e0e0'}),
            html.P('All times in CET', className='text-center',
                    style={'color': '#8a8f9a', 'fontSize': '0.8rem'}),

            dbc.Card(dbc.CardBody([
                dcc.Graph(figure=resload_fig),
                html.H6('Daily Averages — Residual Load', className='mt-3 mb-2',
                         style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
                resload_table,
            ]), className='mb-3'),

            dbc.Row([
                dbc.Col(dbc.Card(dbc.CardBody([
                    dcc.Graph(figure=wind_fig),
                    html.H6('Daily Averages — Wind', className='mt-3 mb-2',
                             style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
                    wind_table,
                ])), md=6),
                dbc.Col(dbc.Card(dbc.CardBody([
                    dcc.Graph(figure=solar_fig),
                    html.H6('Daily Averages — Solar', className='mt-3 mb-2',
                             style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
                    solar_table,
                ])), md=6),
            ], className='mb-3'),

            dbc.Card(dbc.CardBody([
                dcc.Graph(figure=demand_fig),
                html.H6('Daily Averages — Demand', className='mt-3 mb-2',
                         style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
                demand_table,
            ]), className='mb-3'),
        ])

        status = f"Last loaded {datetime.now().strftime('%H:%M:%S')}"
        return content, status
