"""
Scenario Conditional Impact (SCI) Dashboard
===========================================
Trading-grade "if-this-then-what-else" cockpit for ECMWF ensembles.
Optimized for scenario impact and cross-market offsets.

Architecture:
  - Data loading (S3/API) only fires when forecast_date or model changes.
  - Raw hourly data is resampled to daily means per ensemble member and
    cached in memory so subsequent dropdown changes are instant.
  - UI controls (block, trigger, target) only recompute aggregates from cache.
"""
import dash
from dash import html, dcc, Input, Output, State, callback, no_update
import dash_bootstrap_components as dbc
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime, timedelta
from fundamental_dashboard.utils.styles import (
    COLORS, CARD_STYLE, CARD_HEADER_STYLE, CARD_HEADER_TEXT_STYLE,
    CONTROL_PANEL_STYLE, LABEL_STYLE, apply_chart_style, styled_empty_figure
)
from fundamental_dashboard.utils.forecast_data_handler import (
    load_forecast, MODEL_CONFIGS, VARIABLE_CLASSES, SCENARIO_VARIABLE_CLASSES,
    CACHE_AVAILABLE, DEFAULT_ZONES
)
import logging
import pytz

logger = logging.getLogger(__name__)

# --- Configuration & Constants ---
CET = pytz.timezone('CET')

VARIABLES = {
    'Wind': 'Wind Generation',
    'PV': 'Solar Generation',
    'PowerDemand': 'Power Demand',
    'ResidualLoad': 'Residual Load'
}

# Map display variable names to internal forecast_data_handler names
_VAR_TO_INTERNAL = {
    'Wind': 'Wind',
    'PV': 'Solar',
    'PowerDemand': 'Demand',
    'ResidualLoad': 'Residual Load'
}

COUNTRY_ISO_MAP = {
    'Germany': 'DE', 'France': 'FR', 'UK': 'GB', 'Netherlands': 'NL',
    'Belgium': 'BE', 'Spain': 'ES', 'Italy': 'IT', 'Austria': 'AT',
    'Hungary': 'HU'
}

# Only countries that exist in the S3 data (DEFAULT_ZONES)
AVAILABLE_COUNTRIES = list(COUNTRY_ISO_MAP.keys())

_DESC_STYLE = {
    'fontSize': '11px', 'color': COLORS['text_muted'], 'fontStyle': 'italic',
    'padding': '4px 10px 8px', 'lineHeight': '1.4',
}

# ══════════════════════════════════════════════════════════════════════════════
# In-memory ensemble cache: keyed by (model_name, issue_date)
# Stores daily-mean resampled DataFrames per variable, all countries.
# ══════════════════════════════════════════════════════════════════════════════
_ensemble_cache = {}   # {(model, date): {var: DataFrame(daily, MultiIndex cols)}}
_default_results_cache = {}  # pre-computed results for default UI parameters


def precompute_default_scenario(model_name, issue_date):
    """Pre-compute aggregates and figures for the default UI parameters.

    Call after _load_all_ensemble_data so the first tab open is instant.
    """
    issue_date = pd.to_datetime(issue_date).date()
    cache_key = (model_name, str(issue_date))
    if cache_key in _default_results_cache:
        return

    ensemble_data = _ensemble_cache.get(cache_key)
    if not ensemble_data:
        return

    try:
        default_block = [0, 7]  # WK+1
        issue_ts = pd.Timestamp(issue_date)
        days_to_mon = (7 - issue_ts.weekday()) % 7
        if days_to_mon == 0:
            days_to_mon = 7
        wk1_start = issue_ts + timedelta(days=days_to_mon)
        start_tz = pd.Timestamp(wk1_start + timedelta(days=default_block[0]), tz=CET)
        end_tz = pd.Timestamp(wk1_start + timedelta(days=default_block[1]), tz=CET)

        all_member_data = []
        for c in AVAILABLE_COUNTRIES:
            iso = COUNTRY_ISO_MAP.get(c, c).upper()
            for var_key in VARIABLES.keys():
                internal_var = _VAR_TO_INTERNAL.get(var_key, var_key)
                df = ensemble_data.get(internal_var)
                if df is None:
                    continue
                members = _extract_country_members(df, iso)
                if members is None or members.empty:
                    continue
                if members.index.tz is None:
                    members.index = members.index.tz_localize(CET)
                block = members[(members.index >= start_tz) & (members.index < end_tz)]
                if block.empty:
                    continue
                agg = block.mean()
                agg.name = f"{c}|{var_key}"
                all_member_data.append(agg)

        if all_member_data:
            agg_df = pd.concat(all_member_data, axis=1)
            _default_results_cache[cache_key] = agg_df
            logger.info("Pre-computed default SCI aggregates for %s/%s", model_name, issue_date)
    except Exception as exc:
        logger.warning("Failed to pre-compute SCI defaults: %s", exc)


def _load_all_ensemble_data(model_name, issue_date):
    """Load all 4 variables from S3 (or API), resample to daily mean, cache in memory.

    Returns dict: {internal_var: DataFrame} with daily-mean values.
    Each DataFrame has MultiIndex columns (zone, member_id) and a daily DatetimeIndex.
    """
    issue_date = pd.to_datetime(issue_date).date()
    cache_key = (model_name, str(issue_date))
    if cache_key in _ensemble_cache:
        logger.info(f"Using in-memory ensemble cache for {model_name}/{issue_date}")
        return _ensemble_cache[cache_key]

    if not CACHE_AVAILABLE or model_name not in MODEL_CONFIGS:
        return {}

    tag, version, is_mt = MODEL_CONFIGS[model_name]

    def _version_candidates(v):
        candidates = [v]
        value = getattr(v, "value", None)
        if value is not None:
            candidates.append(value)
        for candidate in list(candidates):
            if isinstance(candidate, str):
                digits = ''.join(ch for ch in candidate if ch.isdigit())
                if digits:
                    candidates.append(int(digits))
            else:
                try:
                    candidates.append(int(candidate))
                except Exception:
                    pass
        out = []
        for candidate in candidates:
            if candidate not in out:
                out.append(candidate)
        return out

    def _build_fcst(cls_):
        last_exc = None
        for candidate in _version_candidates(version):
            try:
                return cls_(tag=tag, issue_date=issue_date, issue_version=candidate)
            except TypeError as exc:
                last_exc = exc
        if last_exc is not None:
            logger.debug("Falling back to constructor without issue_version: %s", last_exc)
        return cls_(tag=tag, issue_date=issue_date)

    def _load_fcst(fcst):
        last_exc = None
        for candidate in _version_candidates(version):
            try:
                return fcst.load(from_s3=True, issue_date=issue_date, issue_version=candidate,
                                 show_metadata=False, normalized=False)
            except TypeError as exc:
                last_exc = exc
        if last_exc is not None:
            logger.debug("Falling back to load() without issue_version: %s", last_exc)
        return fcst.load(from_s3=True, issue_date=issue_date, show_metadata=False, normalized=False)

    result = {}
    for internal_var in ['Wind', 'Solar', 'Demand', 'Residual Load']:
        if internal_var not in SCENARIO_VARIABLE_CLASSES:
            continue

        st_cls, mt_cls = SCENARIO_VARIABLE_CLASSES[internal_var]
        cls = mt_cls if is_mt else st_cls
        fcst = _build_fcst(cls)

        # Try S3, fall back to API download
        loaded = False
        try:
            _load_fcst(fcst)
            if fcst.data is not None and not fcst.data.empty:
                loaded = True
                logger.info(f"Ensemble loaded from S3: {internal_var}/{model_name}/{issue_date}")
        except Exception as e:
            logger.info(f"S3 miss for {internal_var}/{model_name}/{issue_date}: {e}")

        if not loaded:
            try:
                logger.info(f"Downloading ensemble {internal_var}/{model_name}/{issue_date} from API...")
                fcst.download(zones=DEFAULT_ZONES)
                if fcst.data is not None and not fcst.data.empty:
                    logger.info(
                        "Skipping S3 save for ensemble %s/%s/%s (read-only runtime)",
                        internal_var, model_name, issue_date
                    )
                    loaded = True
            except Exception as e:
                logger.error(f"API download failed for {internal_var}: {e}")

        if not loaded or fcst.data is None or fcst.data.empty:
            continue

        df = fcst.data

        # Resample hourly to daily mean (keeps MultiIndex columns intact)
        if hasattr(df.index, 'tz') and df.index.tz is not None:
            daily = df.resample('D').mean()
        else:
            daily = df.resample('D').mean()

        result[internal_var] = daily
        logger.info(f"Cached daily ensemble {internal_var}: {daily.shape}")

    _ensemble_cache[cache_key] = result
    logger.info(f"Ensemble cache built for {model_name}/{issue_date}: {list(result.keys())}")
    return result


def _extract_country_members(df, country_iso):
    """Extract ensemble member columns for a given country ISO from a MultiIndex DataFrame.

    Returns a flat DataFrame with member IDs as columns (e.g. E00, E01, ...).
    """
    if isinstance(df.columns, pd.MultiIndex):
        country_cols = [col for col in df.columns if str(col[0]).upper() == country_iso]
        if country_cols:
            sub = df[country_cols]
            sub.columns = [str(col[1]).upper() for col in sub.columns]
            return sub
    return None


# --- Delivery Block Calculations ---

def get_block_dates(block_key, issue_date):
    """Calculate start and end dates for a delivery block.
    Returns (start, end) as tz-aware CET Timestamps.
    """
    if isinstance(issue_date, str):
        issue_date = pd.to_datetime(issue_date.split('_')[0])

    days_to_mon = (7 - issue_date.weekday()) % 7
    if days_to_mon == 0:
        days_to_mon = 7
    wk1_start = issue_date + timedelta(days=days_to_mon)

    blocks = {
        'WK+1': (wk1_start, wk1_start + timedelta(days=7)),
        'WK+2': (wk1_start + timedelta(days=7), wk1_start + timedelta(days=14)),
        'WK+3': (wk1_start + timedelta(days=14), wk1_start + timedelta(days=21)),
        'WK+4': (wk1_start + timedelta(days=21), wk1_start + timedelta(days=28)),
    }
    start, end = blocks.get(block_key, (wk1_start, wk1_start + timedelta(days=7)))
    return pd.Timestamp(start, tz=CET), pd.Timestamp(end, tz=CET)


def compute_aggregates(ensemble_data, countries, variables, issue_date, block_key):
    """Compute block averages for all members across all country/var pairs.

    Uses the in-memory daily cache (no S3 calls).
    Returns DataFrame: rows=member IDs, columns='{Country}|{Var}'.
    """
    start_tz, end_tz = get_block_dates(block_key, issue_date)

    all_member_data = []
    for country in countries:
        iso = COUNTRY_ISO_MAP.get(country, country).upper()
        for var_key in variables:
            internal_var = _VAR_TO_INTERNAL.get(var_key, var_key)
            df = ensemble_data.get(internal_var)
            if df is None:
                continue

            members = _extract_country_members(df, iso)
            if members is None or members.empty:
                continue

            # Make index tz-aware if needed
            if members.index.tz is None:
                members.index = members.index.tz_localize(CET)

            block = members[(members.index >= start_tz) & (members.index < end_tz)]
            if block.empty:
                continue

            agg = block.mean()
            agg.name = f"{country}|{var_key}"
            all_member_data.append(agg)

    if not all_member_data:
        return pd.DataFrame()

    return pd.concat(all_member_data, axis=1)


def apply_condition(agg_df, trigger_col, op, percentile):
    """Filter members based on percentile threshold."""
    if trigger_col not in agg_df.columns:
        return agg_df.index, None

    series = agg_df[trigger_col]
    if op == 'lt':
        threshold = series.quantile(percentile / 100.0)
        selected_members = agg_df[agg_df[trigger_col] <= threshold].index
    else:
        threshold = series.quantile(1.0 - percentile / 100.0)
        selected_members = agg_df[agg_df[trigger_col] >= threshold].index

    return selected_members, threshold


# ══════════════════════════════════════════════════════════════════════════════
# Plotting Functions
# ══════════════════════════════════════════════════════════════════════════════

def create_trigger_plot(agg_df, trigger_col_a, op_a, perc_a, selected_a, threshold_a, 
                        trigger_col_b=None, op_b=None, perc_b=None, selected_b=None, threshold_b=None):
    """Histogram of all members with threshold highlight for Scenario A (and B)."""
    fig = go.Figure()
    series_a = agg_df[trigger_col_a]

    # All Members
    fig.add_trace(go.Histogram(
        x=series_a, name='All Members',
        marker_color='#BDC3C7', nbinsx=15, opacity=0.5
    ))
    
    # Scenario A
    fig.add_trace(go.Histogram(
        x=series_a.loc[selected_a], name='Scenario A',
        marker_color=COLORS['accent'], nbinsx=15
    ))
    
    fig.add_vline(
        x=threshold_a, line_dash="dash", line_color=COLORS['accent'],
        annotation_text=f"A-P{perc_a}", annotation_position="top right"
    )

    # Optional Scenario B (if in Comparison mode)
    if selected_b is not None and trigger_col_b is not None:
        series_b = agg_df[trigger_col_b]
        fig.add_trace(go.Histogram(
            x=series_b.loc[selected_b], name='Scenario B',
            marker_color='#E67E22', nbinsx=15, opacity=0.7
        ))
        fig.add_vline(
            x=threshold_b, line_dash="dash", line_color='#E67E22',
            annotation_text=f"B-P{perc_b}", annotation_position="top left"
        )

    fig.update_layout(
        barmode='overlay',
        margin=dict(l=40, r=40, t=20, b=40),
        xaxis_title="MW",
        yaxis_title="Count",
        showlegend=True,
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
    )
    return apply_chart_style(fig, height=450)


def create_shift_plot(agg_df, target_market, selected_indices_a, selected_indices_b=None):
    """Overlaid violin plot: unconditional vs Scenario A (and optionally Scenario B)."""
    fig = go.Figure()
    uncond = agg_df[target_market].dropna()
    cond_a = uncond.loc[uncond.index.intersection(selected_indices_a)]
    
    # Unconditional distribution (Grey, background)
    fig.add_trace(go.Violin(
        x=uncond, y=[''] * len(uncond),
        name='Unconditional',
        line_color='#95A5A6',
        fillcolor='rgba(189, 195, 199, 0.2)',
        side='negative',
        orientation='h',
        meanline_visible=True,
        points=False,
        marker=dict(color='#BDC3C7', size=3, opacity=0.5),
    ))
    
    # Scenario A (Primary Accent)
    fig.add_trace(go.Violin(
        x=cond_a, y=[''] * len(cond_a),
        name='Scenario A',
        line_color=COLORS['accent'],
        fillcolor=f'rgba(78, 115, 138, 0.4)',
        side='positive',
        orientation='h',
        meanline_visible=True,
        points='all', pointpos=0.5, jitter=0.3,
        marker=dict(color=COLORS['accent'], size=3, opacity=0.6),
    ))

    # Optional Scenario B (Secondary Accent/Orange)
    if selected_indices_b is not None:
        cond_b = uncond.loc[uncond.index.intersection(selected_indices_b)]
        fig.add_trace(go.Violin(
            x=cond_b, y=[''] * len(cond_b),
            name='Scenario B',
            line_color='#E67E22', # Orange
            fillcolor='rgba(230, 126, 34, 0.35)',
            side='positive', # Overlay on same side or negative? Let's overlay positive but shifted?
            # Actually, let's put A and B both positive but different widths or just overlay.
            # Mirroring is cleaner: Uncond (Left) vs Scenarios (Right)
            orientation='h',
            meanline_visible=True,
            points='all', pointpos=0.7, jitter=0.3,
            marker=dict(color='#E67E22', size=3, opacity=0.6),
        ))

    # Annotation: delta means
    uncond_mean = uncond.mean()
    cond_a_mean = cond_a.mean() if len(cond_a) > 0 else uncond_mean
    delta_a = cond_a_mean - uncond_mean
    
    fig.add_vline(x=uncond_mean, line_dash="dot", line_color='#95A5A6', line_width=1)
    fig.add_vline(x=cond_a_mean, line_dash="dot", line_color=COLORS['accent'], line_width=1)
    
    ann_text = f"A: {delta_a:+.0f} MW"
    if selected_indices_b is not None:
        cond_b_mean = cond_b.mean() if len(cond_b) > 0 else uncond_mean
        delta_b = cond_b_mean - uncond_mean
        fig.add_vline(x=cond_b_mean, line_dash="dot", line_color='#E67E22', line_width=1)
        ann_text += f" | B: {delta_b:+.0f} MW"

    fig.add_annotation(
        x=cond_a_mean, y=1.0, yref='paper',
        text=ann_text, showarrow=False,
        font=dict(size=12, color=COLORS['text_primary']),
        bgcolor='rgba(255,255,255,0.85)', borderpad=4,
    )

    fig.update_layout(
        violingap=0, violinmode='overlay',
        margin=dict(l=40, r=40, t=30, b=40),
        xaxis_title=f"{target_market.replace('|', ' ')} (MW)",
        showlegend=True,
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1),
        yaxis=dict(showticklabels=False, zeroline=False),
        xaxis=dict(zeroline=True, zerolinecolor='rgba(0,0,0,0.1)'),
    )
    return apply_chart_style(fig, height=450)


def create_impact_heatmap(agg_df, selected_indices):
    """Heatmap: Delta Z = (CondMean - UncondMean) / UncondStd for all country/variable pairs."""
    uncond_mean = agg_df.mean()
    uncond_std = agg_df.std()
    uncond_std = uncond_std.mask(uncond_std == 0, 1) # Ensure no division by zero
    cond_mean = agg_df.loc[selected_indices].mean()
    delta_z = (cond_mean - uncond_mean) / uncond_std

    countries = sorted(set(c.split('|')[0] for c in agg_df.columns))
    vars_list = sorted(set(c.split('|')[1] for c in agg_df.columns))

    z_matrix = []
    text_matrix = []
    for var in vars_list:
        row, text_row = [], []
        for country in countries:
            key = f"{country}|{var}"
            z_val = delta_z.get(key, np.nan)
            row.append(z_val)
            if not np.isnan(z_val):
                dm = cond_mean.get(key, 0) - uncond_mean.get(key, 0)
                dm_gw = dm / 1000.0
                text_row.append(f"{dm_gw:+.1f} GW")
            else:
                text_row.append("")
        z_matrix.append(row)
        text_matrix.append(text_row)

    fig = go.Figure(data=go.Heatmap(
        z=z_matrix, x=countries, y=vars_list,
        colorscale='RdBu_r', zmid=0, colorbar_title='\u0394Z',
        text=text_matrix, texttemplate='%{text}',
        textfont=dict(color=COLORS['text_primary'], size=10),
        hovertemplate='%{y} / %{x}<br>\u0394Z = %{z:.2f}<extra></extra>',
    ))
    fig.update_layout(
        xaxis_title="Country", yaxis_title="Variable",
        margin=dict(l=80, r=40, t=20, b=40)
    )
    return apply_chart_style(fig, height=450)


def create_balance_waterfall(agg_df, country, selected_indices):
    """Waterfall: conditional shift in Demand, Wind, Solar, and net residual load."""
    required = ['PowerDemand', 'Wind', 'PV', 'ResidualLoad']
    uncond_mean = {}
    cond_mean = {}
    for v in required:
        key = f"{country}|{v}"
        if key in agg_df.columns:
            uncond_mean[v] = agg_df[key].mean()
            cond_mean[v] = agg_df[key].loc[selected_indices].mean()

    deltas = {v: cond_mean[v] - uncond_mean[v] for v in cond_mean}

    labels = ["\u0394Demand", "-\u0394Wind", "-\u0394Solar", "Net \u0394ResLoad"]
    values = [
        deltas.get('PowerDemand', 0),
        -deltas.get('Wind', 0),
        -deltas.get('PV', 0),
        0
    ]

    fig = go.Figure(go.Waterfall(
        name="Balance", orientation="v",
        measure=["relative", "relative", "relative", "total"],
        x=labels, y=values,
        textposition="outside",
        text=[f"{v:+.0f}" for v in values[:-1]] + [f"{deltas.get('ResidualLoad', 0):+.0f}"],
        connector={"line": {"color": "rgb(63, 63, 63)"}},
        increasing={"marker": {"color": "#e74c3c"}},
        decreasing={"marker": {"color": "#27ae60"}},
        totals={"marker": {"color": COLORS['accent']}},
    ))
    fig.update_layout(
        yaxis_title="\u0394 Mean (MW)",
        margin=dict(l=40, r=40, t=20, b=40)
    )
    return apply_chart_style(fig, height=450)


def create_joint_scatter(agg_df, trigger_col, target_col, selected_indices_a, selected_indices_b=None):
    """Joint Structural Scatter: Trigger vs Target coupling."""
    fig = go.Figure()
    
    # All members (Grey background)
    fig.add_trace(go.Scatter(
        x=agg_df[trigger_col], y=agg_df[target_col],
        mode='markers', name='All Members',
        marker=dict(color='#BDC3C7', size=7, opacity=0.4),
        hovertemplate="Trig: %{x:.0f} MW<br>Targ: %{y:.0f} MW<extra></extra>"
    ))
    
    # Scenario A (Blue)
    fig.add_trace(go.Scatter(
        x=agg_df.loc[selected_indices_a, trigger_col],
        y=agg_df.loc[selected_indices_a, target_col],
        mode='markers', name='Scenario A',
        marker=dict(color=COLORS['accent'], size=9, opacity=0.8, line=dict(width=1, color='white')),
        hovertemplate="Scenario A<br>Trig: %{x:.0f} MW<br>Targ: %{y:.0f} MW<extra></extra>"
    ))
    
    # Scenario B (Orange)
    if selected_indices_b is not None:
        fig.add_trace(go.Scatter(
            x=agg_df.loc[selected_indices_b, trigger_col],
            y=agg_df.loc[selected_indices_b, target_col],
            mode='markers', name='Scenario B',
            marker=dict(color='#E67E22', size=9, opacity=0.8, symbol='diamond', line=dict(width=1, color='white')),
            hovertemplate="Scenario B<br>Trig: %{x:.0f} MW<br>Targ: %{y:.0f} MW<extra></extra>"
        ))

    fig.update_layout(
        xaxis_title=f"{trigger_col.replace('|', ' ')} (MW)",
        yaxis_title=f"{target_col.replace('|', ' ')} (MW)",
        margin=dict(l=60, r=40, t=40, b=60),
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1),
        hovermode='closest'
    )
    return apply_chart_style(fig, height=450)


def create_regime_map(agg_df, trigger_col, mode='bands', metric='z'):
    """Heatmap showing European Residual Load shifts across trigger percentiles."""
    trigger_series = agg_df[trigger_col]
    
    # 1. Define Bins
    bins = []
    if mode == 'bands':
        # Partition into equal bands (robust with 50 members)
        edges = [0, 20, 40, 60, 80, 100]
        for i in range(len(edges)-1):
            bins.append({
                'label': f"P{edges[i]}-P{edges[i+1]}",
                'indices': trigger_series[
                    (trigger_series >= trigger_series.quantile(edges[i]/100)) & 
                    (trigger_series < trigger_series.quantile(edges[i+1]/100) if edges[i+1] < 100 else True)
                ].index
            })
    else:
        # Cumulative thresholds (event map)
        thresh_points = [10, 20, 30, 40, 60, 70, 80, 90]
        for p in thresh_points:
            if p <= 50:
                label = f"< P{p}"
                indices = trigger_series[trigger_series <= trigger_series.quantile(p/100)].index
            else:
                label = f"> P{p}"
                indices = trigger_series[trigger_series >= trigger_series.quantile(p/100)].index
            bins.append({'label': label, 'indices': indices})

    # 2. Select Columns (Residual Load across all zones)
    target_vars = [f"{c}|ResidualLoad" for c in AVAILABLE_COUNTRIES if f"{c}|ResidualLoad" in agg_df.columns]
    
    # 3. Compute shifts
    uncond_mean = agg_df[target_vars].mean()
    uncond_std = agg_df[target_vars].std().mask(lambda x: x == 0, 1) # Standardize if MW
    
    z_matrix = []
    text_matrix = []
    row_labels = []
    
    for b in bins:
        idx = b['indices']
        n = len(idx)
        if n == 0: continue
        
        row_labels.append(f"{b['label']} (n={n})")
        cond_mean = agg_df.loc[idx, target_vars].mean()
        
        if metric == 'z':
            row_vals = (cond_mean - uncond_mean) / uncond_std
            z_matrix.append(row_vals.values)
            text_matrix.append([f"{v:+.1f}\u03c3" for v in row_vals])
        else:
            row_vals = (cond_mean - uncond_mean) # Delta MW
            z_matrix.append(row_vals.values / uncond_std.values) # Color by Z even for MW
            text_matrix.append([f"{v/1000.:+.1f}GW" for v in row_vals])

    # 4. Figure
    fig = go.Figure(data=go.Heatmap(
        z=z_matrix,
        x=[c.split('|')[0] for c in target_vars],
        y=row_labels,
        colorscale='RdBu_r', zmid=0,
        zmin=-2.0, zmax=2.0, # Symmetric clamp for better scanning
        text=text_matrix, texttemplate='%{text}',
        textfont=dict(size=10, color=COLORS['text_primary']),
        hovertemplate="Region: %{x}<br>Regime: %{y}<br>Impact: %{text}<extra></extra>"
    ))
    
    fig.update_layout(
        margin=dict(l=40, r=40, t=20, b=40),
        xaxis=dict(side='top'), # Traders like headers at top
        yaxis=dict(autorange='reversed'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
    )
    return apply_chart_style(fig, height=350)


# ══════════════════════════════════════════════════════════════════════════════
# Layout
# ══════════════════════════════════════════════════════════════════════════════

def create_kpi_card(title, value, subtitle=None, color=COLORS['accent']):
    return html.Div(style={**CARD_STYLE, 'padding': '15px', 'textAlign': 'center', 'borderTop': f'4px solid {color}'}, children=[
        html.Div(title, style={'fontSize': '12px', 'fontWeight': '600', 'color': COLORS['text_muted'], 'textTransform': 'uppercase'}),
        html.Div(value, id=f"sci-kpi-{title.lower().replace(' ', '-')}", style={'fontSize': '24px', 'fontWeight': '700', 'color': COLORS['text_primary'], 'margin': '5px 0'}),
        html.Div(subtitle, style={'fontSize': '11px', 'color': COLORS['text_muted']}) if subtitle else None
    ])


def get_layout(data_handler):
    """Main layout for SCI dashboard."""
    today_str = pd.Timestamp.now().strftime('%Y-%m-%d')

    # Compute default date range for the slider (WK+1 through WK+4)
    today = pd.Timestamp.now().floor('D')
    days_to_mon = (7 - today.weekday()) % 7
    if days_to_mon == 0:
        days_to_mon = 7
    wk1_start = today + timedelta(days=days_to_mon)
    wk4_end = wk1_start + timedelta(days=28)

    # Build slider marks for each Monday
    slider_marks = {}
    for wk in range(5):
        d = wk1_start + timedelta(days=7 * wk)
        label = f"WK+{wk+1}" if wk < 4 else ""
        slider_marks[wk * 7] = {'label': label, 'style': {'fontSize': '11px'}}

    return html.Div(style={'padding': '20px', 'backgroundColor': COLORS['background'], 'minHeight': '100vh'}, children=[
        # Header
        html.Div(style={'marginBottom': '16px'}, children=[
            html.H2("Scenario Conditional Impact", style={'color': COLORS['text_primary'], 'fontWeight': '700', 'fontSize': '22px', 'margin': '0'}),
            html.P("ECMWF ensemble conditional analysis: define a trigger event and see cross-market impact.",
                   style={'color': COLORS['text_muted'], 'fontSize': '13px', 'margin': '4px 0 0'})
        ]),

        # Row 1: Data selectors (date + model) — these trigger data load
        html.Div(style={**CONTROL_PANEL_STYLE, 'marginBottom': '8px'}, children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Forecast Date", style=LABEL_STYLE),
                    dcc.DatePickerSingle(
                        id='sci-forecast-date', date=today_str,
                        display_format='YYYY-MM-DD', style={'width': '100%'}
                    )
                ], width=2),
                dbc.Col([
                    html.Label("Model", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id='sci-model-select',
                        options=[{'label': k, 'value': k} for k in MODEL_CONFIGS.keys() if 'ENS' in k or 'EXT' in k],
                        value='EC-ENS 00z', clearable=False
                    )
                ], width=2),
                dbc.Col([
                    html.Label("Delivery Period", style=LABEL_STYLE),
                    html.Div(style={'padding': '0 10px'}, children=[
                        dcc.RangeSlider(
                            id='sci-date-range',
                            min=0, max=28, step=1,
                            value=[0, 7],  # Default: WK+1
                            marks=slider_marks,
                            tooltip={'placement': 'bottom', 'always_visible': False},
                            allowCross=False,
                        ),
                    ]),
                    html.Div(id='sci-date-range-label', style={
                        'fontSize': '11px', 'color': COLORS['text_muted'],
                        'textAlign': 'center', 'marginTop': '2px'
                    }),
                ], width=4),
                dbc.Col([
                    html.Div(id='sci-data-status', style={
                        'fontSize': '12px', 'color': COLORS['text_muted'],
                        'padding': '24px 10px 0',
                    }),
                ], width=3),
                dbc.Col([
                    # html.Label("Expert Mode", style=LABEL_STYLE), # Removed label
                    dbc.Checklist(
                        options=[{"label": "Comparison Mode", "value": 1}],
                        value=[],
                        id="sci-comparison-toggle",
                        switch=True,
                        style={'marginTop': '5px', 'fontSize': '13px', 'fontWeight': '600'}
                    ),
                ], width=1),
            ])
        ]),

        # Row 2: Analysis controls (Scenario A)
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div("Scenario A (Primary)", style={'fontSize': '11px', 'fontWeight': 'bold', 'color': COLORS['accent'], 'marginBottom': '8px', 'textTransform': 'uppercase'}),
            dbc.Row([
                # Trigger Market
                dbc.Col([
                    html.Label("Trigger Market", style=LABEL_STYLE),
                    dbc.Row([
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-country',
                            options=[{'label': c, 'value': c} for c in AVAILABLE_COUNTRIES],
                            value='Germany', clearable=False
                        ), width=6),
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-var',
                            options=[{'label': v, 'value': k} for k, v in VARIABLES.items()],
                            value='Wind', clearable=False
                        ), width=6),
                    ])
                ], width=4),

                # Condition
                dbc.Col([
                    html.Label("Condition", style=LABEL_STYLE),
                    dbc.Row([
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-op',
                            options=[
                                {'label': 'Below (<)', 'value': 'lt'},
                                {'label': 'Above (>)', 'value': 'gt'}
                            ], value='lt', clearable=False
                        ), width=4),
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-perc',
                            options=[{'label': f'P{p}', 'value': p} for p in [10, 20, 25, 30, 40, 50]],
                            value=20, clearable=False
                        ), width=4),
                        dbc.Col(html.Div(
                            id='sci-trigger-absolute-val',
                            style={'fontSize': '11px', 'color': COLORS['text_muted'], 'marginTop': '10px'}
                        ), width=4)
                    ])
                ], width=4),

                # Target Market
                dbc.Col([
                    html.Label("Target for Shift Detail", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id='sci-target-market',
                        options=[
                            {'label': f"{c} {v}", 'value': f"{c}|{k}"}
                            for c in AVAILABLE_COUNTRIES for k, v in VARIABLES.items()
                        ],
                        value='France|PowerDemand', clearable=False
                    )
                ], width=4),
            ])
        ]),

        # Scenario B (Comparison) Controls - Hidden by default
        html.Div(id='sci-controls-b-container', style={**CONTROL_PANEL_STYLE, 'display': 'none', 'borderLeft': '4px solid #E67E22'}, children=[
            html.Div("Scenario B (Comparison)", style={'fontSize': '11px', 'fontWeight': 'bold', 'color': '#E67E22', 'marginBottom': '8px', 'textTransform': 'uppercase'}),
            dbc.Row([
                dbc.Col([
                    html.Label("Trigger Market B", style=LABEL_STYLE),
                    dbc.Row([
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-country-b',
                            options=[{'label': c, 'value': c} for c in AVAILABLE_COUNTRIES],
                            value='France', clearable=False
                        ), width=6),
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-var-b',
                            options=[{'label': v, 'value': k} for k, v in VARIABLES.items()],
                            value='Wind', clearable=False
                        ), width=6),
                    ])
                ], width=4),
                dbc.Col([
                    html.Label("Condition B", style=LABEL_STYLE),
                    dbc.Row([
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-op-b',
                            options=[
                                {'label': 'Below (<)', 'value': 'lt'},
                                {'label': 'Above (>)', 'value': 'gt'}
                            ], value='lt', clearable=False
                        ), width=4),
                        dbc.Col(dcc.Dropdown(
                            id='sci-trigger-perc-b',
                            options=[{'label': f'P{p}', 'value': p} for p in [10, 20, 25, 30, 40, 50]],
                            value=20, clearable=False
                        ), width=4),
                        dbc.Col(html.Div(
                            id='sci-trigger-absolute-val-b',
                            style={'fontSize': '11px', 'color': COLORS['text_muted'], 'marginTop': '10px'}
                        ), width=4)
                    ])
                ], width=4),
            ])
        ]),

        # Loading wrapper for all output panels - shows when data is being loaded
        dcc.Loading(
            id='sci-loading-main', type='circle', color=COLORS['accent'],
            fullscreen=True,
            children=html.Div([
                # Hidden div that gets updated to trigger loading indicator
                html.Div(id='sci-loading-trigger', style={'display': 'none'}),
                html.Div(id='sci-results-container', children=[
                # TOP ROW: Regime Map (Replaces Conviction)
                dbc.Row([
                    dbc.Col([
                        html.Div(style=CARD_STYLE, children=[
                            dbc.Row([
                                dbc.Col(html.Div("Cross-Market Regime Map", style=CARD_HEADER_STYLE), width=6),
                                dbc.Col([
                                    dbc.ButtonGroup([
                                        dbc.Button("Bands (Regime)", id="sci-regime-mode-bands", size="sm", color="primary", outline=True, active=True),
                                        dbc.Button("Thresholds (Event)", id="sci-regime-mode-thresh", size="sm", color="primary", outline=True),
                                    ], className="me-2"),
                                    dbc.ButtonGroup([
                                        dbc.Button("ΔZ", id="sci-regime-metric-z", size="sm", color="secondary", outline=True, active=True),
                                        dbc.Button("ΔMW", id="sci-regime-metric-mw", size="sm", color="secondary", outline=True),
                                    ]),
                                ], width=6, className="text-end", style={'padding': '10px 20px 0 0'}),
                            ]),
                            html.Div("How the European fundamental state (Residual Load) shifts across all percentiles of your chosen trigger variable. Detect offsets or reinforcements at a glance.", style=_DESC_STYLE),
                            
                            dcc.Loading(
                                id='sci-loading-regime-map', type='default', color=COLORS['accent'],
                                children=dcc.Graph(id='sci-regime-map', figure=styled_empty_figure(height=350), config={'displayModeBar': False})
                            ),
                            
                            # Hidden stores for mode/metric state (simpler than complex callbacks)
                            dcc.Store(id='sci-regime-mode-store', data='bands'),
                            dcc.Store(id='sci-regime-metric-store', data='z'),
                        ])
                    ], width=12),
                ], style={'marginBottom': '20px'}),

                dbc.Row([
                    dbc.Col([
                        html.Div(style=CARD_STYLE, children=[
                            html.Div("Trigger A (and B) Distributions", style=CARD_HEADER_STYLE),
                            html.Div("Shows where the ensemble members fall for your trigger variable. Colored bars indicate the specific members selected by your 'Above' or 'Below' condition.", style=_DESC_STYLE),
                            dcc.Loading(
                                id='sci-loading-trigger-plot', type='default', color=COLORS['accent'],
                                children=dcc.Graph(id='sci-trigger-plot', figure=styled_empty_figure())
                            ),
                        ])
                    ], width=12),
                ], style={'marginBottom': '20px'}),

                dbc.Row([
                    dbc.Col([
                        html.Div(style=CARD_STYLE, children=[
                            html.Div("Conditional Shift (Target Market)", style=CARD_HEADER_STYLE),
                            html.Div("Violin overlay: Grey is the total ensemble (unconditional), Colored is your scenario. A separation between the two peaks signals a genuine regime shift.", style=_DESC_STYLE),
                            dcc.Loading(
                                id='sci-loading-shift', type='default', color=COLORS['accent'],
                                children=dcc.Graph(id='sci-shift-plot', figure=styled_empty_figure())
                            ),
                        ])
                    ], width=12),
                ], style={'marginBottom': '20px'}),

                dbc.Row([
                    dbc.Col([
                        html.Div(style=CARD_STYLE, children=[
                            html.Div("Joint Structural Scatter", style=CARD_HEADER_STYLE),
                            html.Div("Dependence Cloud: X=Trigger, Y=Target. This reveals if the relationship is linear, convex, or if the tail behavior is decoupled from the main cluster.", style=_DESC_STYLE),
                            dcc.Loading(
                                id='sci-loading-scatter', type='default', color=COLORS['accent'],
                                children=dcc.Graph(id='sci-joint-scatter-plot', figure=styled_empty_figure())
                            ),
                        ])
                    ], width=12),
                ], style={'marginBottom': '20px'}),

                dbc.Row([
                    dbc.Col([
                        html.Div(style=CARD_STYLE, children=[
                            html.Div(id='sci-impact-heatmap-title', children="Cross-Market Impact (\u0394Z)", style=CARD_HEADER_STYLE),
                            html.Div("Normalized impact across all countries and fundamental variables. 1.0 \u03c3 means the market mean moves by 1 standard deviation.", style=_DESC_STYLE),
                            dcc.Loading(
                                id='sci-loading-hm-a', type='default', color=COLORS['accent'],
                                children=dcc.Graph(id='sci-impact-heatmap', figure=styled_empty_figure())
                            ),
                        ])
                    ], id='sci-heatmap-a-col', width=12),
                ], style={'marginBottom': '20px'}),

                dbc.Row([
                    dbc.Col([
                        html.Div(style=CARD_STYLE, children=[
                            html.Div("Cross-Market Impact (\u0394Z) - Scenario B", style=CARD_HEADER_STYLE),
                            html.Div("Normalized impact for Scenario B. Useful for comparing against Scenario A to see trade offset risks.", style=_DESC_STYLE),
                            dcc.Loading(
                                id='sci-loading-hm-b', type='default', color=COLORS['accent'],
                                children=dcc.Graph(id='sci-impact-heatmap-b', figure=styled_empty_figure())
                            ),
                        ])
                    ], id='sci-heatmap-b-col', width=12, style={'display': 'none', 'marginBottom': '20px'}),
                ]),

                dbc.Row([
                    dbc.Col([
                        html.Div(style=CARD_STYLE, children=[
                            html.Div("Fundamental Balance Waterfall (Scenario A)", style=CARD_HEADER_STYLE),
                            html.Div("Decomposition of the net load shift for the trigger country. \u0394Demand - \u0394Wind - \u0394Solar = Net Residual Load.", style=_DESC_STYLE),
                            dcc.Loading(
                                id='sci-loading-waterfall', type='default', color=COLORS['accent'],
                                children=dcc.Graph(id='sci-balance-waterfall', figure=styled_empty_figure())
                            ),
                        ])
                    ], id='sci-waterfall-col', width=12),
                ], style={'marginBottom': '20px'}),
                ]),
            ]),
        ),

        # Hidden stores
        dcc.Store(id='sci-ensemble-loaded', data=None),  # Tracks which (model, date) is loaded
    ])


# ══════════════════════════════════════════════════════════════════════════════
# Callbacks
# ══════════════════════════════════════════════════════════════════════════════
# Uses module-level @callback decorator (same pattern as all portal pages).
# Split into two callbacks:
#   1. Data loader: fires only on forecast_date / model change → loads from S3
#   2. Analysis: fires on all controls → uses in-memory cache (instant)

def toggle_comparison_mode(switch_val, current_style):
    if switch_val and len(switch_val) > 0:
        current_style['display'] = 'block'
    else:
        current_style['display'] = 'none'
    return current_style


def load_ensemble_data(forecast_date, model_name):
    """Load ensemble data from S3/API when date or model changes. Cached in memory."""
    if not forecast_date or not model_name:
        return "", None, ""

    issue_date = pd.to_datetime(forecast_date).date()
    cache_key = (model_name, str(issue_date))

    # Check if already cached
    if cache_key in _ensemble_cache:
        n_vars = len(_ensemble_cache[cache_key])
        return "", cache_key, f"Cached: {n_vars} variables for {model_name} / {issue_date}"

    # Load (this is the slow part - only runs once per date/model)
    # The loading indicator will show automatically because we're updating sci-loading-trigger
    data = _load_all_ensemble_data(model_name, issue_date)
    n_vars = len(data)

    if n_vars == 0:
        return "", None, f"No data available for {model_name} / {issue_date}"

    return "", cache_key, f"Loaded: {n_vars} variables for {model_name} / {issue_date}"


def update_date_range_label(range_val, forecast_date):
    """Show actual dates for the selected range."""
    if not forecast_date or not range_val:
        return ""
    issue = pd.to_datetime(forecast_date).floor('D')
    days_to_mon = (7 - issue.weekday()) % 7
    if days_to_mon == 0:
        days_to_mon = 7
    wk1_start = issue + timedelta(days=days_to_mon)
    start = wk1_start + timedelta(days=range_val[0])
    end = wk1_start + timedelta(days=range_val[1])
    return f"{start.strftime('%d %b')} \u2013 {end.strftime('%d %b %Y')}"


_SCI_ANALYSIS_OUTPUTS = [
    Output('sci-regime-map', 'figure'),
    Output('sci-trigger-plot', 'figure'),
    Output('sci-shift-plot', 'figure'),
    Output('sci-impact-heatmap', 'figure'),
    Output('sci-impact-heatmap-b', 'figure'),
    Output('sci-balance-waterfall', 'figure'),
    Output('sci-joint-scatter-plot', 'figure'),
    Output('sci-trigger-absolute-val', 'children'),
    Output('sci-trigger-absolute-val-b', 'children'),
    Output('sci-heatmap-b-col', 'style'),
    Output('sci-heatmap-a-col', 'width'),
    Output('sci-waterfall-col', 'style'),
    Output('sci-impact-heatmap-title', 'children'),
]

_SCI_ANALYSIS_INPUTS = [
    Input('sci-ensemble-loaded', 'data'),
    Input('sci-date-range', 'value'),
    Input('sci-trigger-country', 'value'),
    Input('sci-trigger-var', 'value'),
    Input('sci-trigger-op', 'value'),
    Input('sci-trigger-perc', 'value'),
    Input('sci-target-market', 'value'),
    Input('sci-comparison-toggle', 'value'),
    Input('sci-trigger-country-b', 'value'),
    Input('sci-trigger-var-b', 'value'),
    Input('sci-trigger-op-b', 'value'),
    Input('sci-trigger-perc-b', 'value'),
    Input('sci-regime-mode-store', 'data'),
    Input('sci-regime-metric-store', 'data'),
]

_SCI_ANALYSIS_STATES = [
    State('sci-forecast-date', 'date'),
    State('sci-model-select', 'value'),
]

_EMPTY = [styled_empty_figure()] * 7 + ["", "", {'display': 'none'}, 12, {'display': 'block'}, "Cross-Market Impact (\u0394Z)"]

def update_sci_analysis(cache_key, date_range, country, var, op, perc, target,
                        comp_toggle, country_b, var_b, op_b, perc_b,
                        regime_mode, regime_metric,
                        forecast_date, model_name):
    """Recompute analysis from in-memory cache. Instant — no S3 calls."""
    try:
        if not cache_key or not forecast_date:
            return _EMPTY

        resolved_key = tuple(cache_key) if isinstance(cache_key, list) else cache_key
        ensemble_data = _ensemble_cache.get(resolved_key)
        if not ensemble_data:
            return _EMPTY

        # 1. Setup Dates
        issue_ts = pd.to_datetime(forecast_date).floor('D')
        days_to_mon = (7 - issue_ts.weekday()) % 7
        if days_to_mon == 0: days_to_mon = 7
        wk1_start = issue_ts + timedelta(days=days_to_mon)
        start_tz = pd.Timestamp(wk1_start + timedelta(days=date_range[0]), tz=CET)
        end_tz = pd.Timestamp(wk1_start + timedelta(days=date_range[1]), tz=CET)

        # 2. Use pre-computed aggregates if available (default WK+1 block)
        cached_agg = _default_results_cache.get(resolved_key)
        if cached_agg is not None and date_range == [0, 7]:
            agg_df = cached_agg
        else:
            all_member_data = []
            for c in AVAILABLE_COUNTRIES:
                iso = COUNTRY_ISO_MAP.get(c, c).upper()
                for var_key in VARIABLES.keys():
                    internal_var = _VAR_TO_INTERNAL.get(var_key, var_key)
                    df = ensemble_data.get(internal_var)
                    if df is None: continue
                    members = _extract_country_members(df, iso)
                    if members is None or members.empty: continue
                    if members.index.tz is None:
                        members.index = members.index.tz_localize(CET)
                    block = members[(members.index >= start_tz) & (members.index < end_tz)]
                    if block.empty: continue
                    agg = block.mean()
                    agg.name = f"{c}|{var_key}"
                    all_member_data.append(agg)

            if not all_member_data:
                return _EMPTY

            agg_df = pd.concat(all_member_data, axis=1)

        n_members = len(agg_df)

        # 3. Apply Scenario A
        trigger_col_a = f"{country}|{var}"
        if trigger_col_a not in agg_df.columns:
            return _EMPTY
        selected_a, threshold_a = apply_condition(agg_df, trigger_col_a, op, perc)
        
        # 4. Apply Scenario B (if comparison mode)
        comp_active = comp_toggle is not None and len(comp_toggle) > 0
        selected_b, threshold_b = None, None
        trigger_col_b = f"{country_b}|{var_b}"
        if comp_active:
            if trigger_col_b in agg_df.columns:
                selected_b, threshold_b = apply_condition(agg_df, trigger_col_b, op_b, perc_b)

        # 5. Generate Figures
        fig_regime = create_regime_map(agg_df, trigger_col_a, regime_mode, regime_metric)
        
        fig_trig = create_trigger_plot(agg_df, trigger_col_a, op, perc, selected_a, threshold_a,
                                       trigger_col_b, op_b, perc_b, selected_b, threshold_b)
        
        fig_shift = create_shift_plot(agg_df, target, selected_a, selected_b)
        
        fig_hm_a = create_impact_heatmap(agg_df, selected_a)
        fig_hm_b = create_impact_heatmap(agg_df, selected_b) if comp_active and selected_b is not None else styled_empty_figure()
        
        fig_waterfall = create_balance_waterfall(agg_df, country, selected_a)
        
        fig_scatter = create_joint_scatter(agg_df, trigger_col_a, target, selected_a, selected_b)

        # 6. Layout Visibility & Status
        hm_b_style = {'display': 'block'} if comp_active else {'display': 'none'}
        hm_a_width = 12 # Always 12 now
        waterfall_style = {'display': 'block'} # Keep it visible but stacked
        hm_title = f"Impact (\u0394Z) - Scen A: {country} {var}" if comp_active else "Cross-Market Impact (\u0394Z)"

        return [
            fig_regime, fig_trig, fig_shift, fig_hm_a, fig_hm_b, fig_waterfall, fig_scatter,
            f"~ {threshold_a:.0f} MW",
            f"~ {threshold_b:.0f} MW" if threshold_b is not None else "",
            hm_b_style, hm_a_width, waterfall_style, hm_title
        ]

    except Exception as e:
        logger.error(f"Error in SCI analysis: {e}", exc_info=True)
        # Return something to avoid crash, but with enough outputs to match definition
        return [styled_empty_figure(f"Error: {str(e)}")] * 7 + ["", "", {'display': 'none'}, 12, {'display': 'block'}, "Error"]


def register_sci_callbacks(app):
    """Register SCI-specific interactivity callbacks."""

    app.callback(
        Output('sci-controls-b-container', 'style'),
        Input('sci-comparison-toggle', 'value'),
        State('sci-controls-b-container', 'style'),
    )(toggle_comparison_mode)

    app.callback(
        Output('sci-loading-trigger', 'children'),
        Output('sci-ensemble-loaded', 'data'),
        Output('sci-data-status', 'children'),
        Input('sci-forecast-date', 'date'),
        Input('sci-model-select', 'value'),
    )(load_ensemble_data)

    app.callback(
        Output('sci-date-range-label', 'children'),
        Input('sci-date-range', 'value'),
        Input('sci-forecast-date', 'date'),
    )(update_date_range_label)

    app.callback(_SCI_ANALYSIS_OUTPUTS, _SCI_ANALYSIS_INPUTS, _SCI_ANALYSIS_STATES)(
        update_sci_analysis
    )

    @app.callback(
        Output('sci-regime-mode-store', 'data'),
        Output('sci-regime-mode-bands', 'active'),
        Output('sci-regime-mode-thresh', 'active'),
        Input('sci-regime-mode-bands', 'n_clicks'),
        Input('sci-regime-mode-thresh', 'n_clicks'),
        State('sci-regime-mode-store', 'data'),
        prevent_initial_call=True
    )
    def update_regime_mode(b_clicks, t_clicks, current):
        ctx = dash.callback_context
        if not ctx.triggered: return dash.no_update
        btn_id = ctx.triggered[0]['prop_id'].split('.')[0]
        
        if btn_id == 'sci-regime-mode-bands':
            return 'bands', True, False
        else:
            return 'thresholds', False, True

    @app.callback(
        Output('sci-regime-metric-store', 'data'),
        Output('sci-regime-metric-z', 'active'),
        Output('sci-regime-metric-mw', 'active'),
        Input('sci-regime-metric-z', 'n_clicks'),
        Input('sci-regime-metric-mw', 'n_clicks'),
        State('sci-regime-metric-store', 'data'),
        prevent_initial_call=True
    )
    def update_regime_metric(z_clicks, mw_clicks, current):
        ctx = dash.callback_context
        if not ctx.triggered: return dash.no_update
        btn_id = ctx.triggered[0]['prop_id'].split('.')[0]
        
        if btn_id == 'sci-regime-metric-z':
            return 'z', True, False
        else:
            return 'mw', False, True

    @app.callback(
        Output('sci-target-market', 'value'),
        Input('sci-regime-map', 'clickData'),
        prevent_initial_call=True
    )
    def drill_down_regime(clickData):
        """Click a country in the regime map to set it as the target analysis market."""
        if clickData:
            country = clickData['points'][0]['x']
            # Re-map country to target market (ResidualLoad)
            target = f"{country}|ResidualLoad"
            return target
        return dash.no_update
