# Standard library imports
import functools
import logging
import pathlib
import sys
import threading
import time
from datetime import datetime

# Third-party imports
import dash
import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import html, dcc, Input, Output, State, ALL

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import url_for  # noqa: E402

# Local imports
from utils.weather_data_handler import WeatherDataHandler, CONFIG
from utils.weather_plotting import (
    create_variable_plot, 
    create_empty_plot,
    create_residual_load_plot
)

# Set up logging
logger = logging.getLogger(__name__)

# Initialize the data handler lazily
weather_data_handler = None
data_loading_triggered = False

def get_weather_data_handler():
    """Get or initialize the weather data handler"""
    global weather_data_handler
    if weather_data_handler is None:
        logger.info("Creating weather data handler instance")
        weather_data_handler = WeatherDataHandler()
    return weather_data_handler


def initialize_data():
    """Initialize the data if not already initialized"""
    handler = get_weather_data_handler()
    if not handler.initialized:
        logger.info("Starting data initialization")
        # Force initialization and check result
        result = handler.initialize()
        logger.info(f"Data initialization completed with result: {result}")
        # Double check initialized flag
        logger.info(f"Handler initialized flag: {handler.initialized}")
    return handler.initialized

def get_layout(data_handler=None):
    """Get the layout for the weather forecast page"""
    # Just create the handler but don't initialize data yet
    handler = get_weather_data_handler()
    
    # Setup common navigation elements
    nav_bar = dbc.Navbar(
        [
            dbc.NavbarBrand("Fundamentals Dashboard", href="/", className="ms-2"),
            dbc.Nav(
                [
                    dbc.NavItem(dbc.NavLink("Home", href="/")),
                    dbc.NavItem(dbc.NavLink("Availability", href="/availability")),
                    dbc.NavItem(dbc.NavLink("Generation vs Availability", href="/generation-vs-availability")),
                    dbc.NavItem(dbc.NavLink("Weather Forecast", href="/weather-forecast", active=True)),
                    dbc.NavItem(dbc.NavLink("Forecast Compare", href="/forecast-comparison")),
                    dbc.NavItem(dbc.NavLink("Prices", href=url_for('price'), external_link=True)),
                    dbc.NavItem(dbc.NavLink("Stack", href=url_for('stack'), external_link=True)),
                    dbc.NavItem(dbc.NavLink("Portal", href=url_for('portal'), external_link=True)),
                ],
                className="ms-auto",
                navbar=True
            )
        ],
        dark=True,
        className="dashboard-navbar mb-3"
    )
    
    # Log current initialization status
    logger.info(f"Weather forecast page accessed. Data initialized: {handler.initialized}")
    
    # Return a layout with spinners for specific content
    return html.Div([
        # Navigation menu
        nav_bar,
        
        # App header
        dbc.Row([
            dbc.Col([
                html.H1("Weather Forecast Dashboard", className="my-4")
            ], width=12)
        ]),
        
        # Store component to hold global data
        dcc.Store(id='weather-data-store'),
        
        # Auto-refresh disabled — use the Refresh Data button instead
        dcc.Interval(
            id='weather-refresh-interval',
            interval=CONFIG['refresh_interval'],
            n_intervals=0,
            disabled=True,
        ),
        
        # Memory cleanup disabled — runs on manual refresh
        dcc.Interval(
            id='weather-memory-cleanup-interval',
            interval=CONFIG['memory_cleanup_interval'],
            n_intervals=0,
            disabled=True,
        ),
        
        # Main content div - always visible, uses individual loading states
        html.Div(
            id="weather-main-content",
            children=[
                dbc.Row([
                    dbc.Col([
                        # Refresh button and forecast source selection
                        dbc.Card([
                            dbc.CardBody([
                                dbc.Row([
                                    dbc.Col([
                                        dbc.Button('Refresh Data', id='weather-refresh-button', color='primary', n_clicks=0,
                                                  className='me-2')
                                    ], width=3),
                                    dbc.Col([
                                        html.H4('Select Forecast Sources:'),
                                        dcc.Loading(
                                            id="loading-sources-dropdown",
                                            type="circle",
                                            children=[
                                        dcc.Dropdown(
                                            id='weather-forecast-source-dropdown',
                                            options=[
                                                {'label': name, 'value': source}
                                                for source, name in (
                                                    handler.get_forecast_sources().items()
                                                )
                                            ] if handler.initialized else [],
                                                    value=[CONFIG['default_sources'][0]],  # Default
                                                    multi=True,
                                                    className='mb-3'
                                                )
                                            ]
                                        )
                                    ], width=9)
                                ])
                            ])
                        ], className='mb-4')
                    ])
                ]),
                
                dbc.Row([
                    dbc.Col([
                        dbc.Card([
                            dbc.CardBody([
                                html.H4('Forecast Versions:'),
                                dcc.Loading(
                                    id="loading-version-checkboxes",
                                    type="circle",
                                    children=[
                                        html.Div(id='weather-forecast-version-checkboxes')
                                    ]
                                ),
                                html.Div(id='weather-update-status', className='mt-2 text-success')
                            ])
                        ], className='mb-4')
                    ]),
                ]),
                
                dbc.Row([
                    dbc.Col([
                        dbc.Card([
                            dbc.CardBody([
                                dbc.Tabs(
                                    id='weather-country-tabs',
                                    active_tab=CONFIG['default_country'],
                                    children=[
                                        dbc.Tab(label=country, tab_id=country) 
                                        for country in handler.get_countries()
                                    ] if handler.initialized else []
                                ),
                                html.Hr(),
                                dcc.Loading(
                                    id="loading-country-content",
                                    type="circle", 
                                    children=[
                                        html.Div(id='weather-country-content')
                                    ]
                                )
                            ])
                        ])
                    ])
                ])
            ]
        )
    ])

def register_weather_forecast_callbacks(app, data_handler=None):
    """Register callbacks for the weather forecast page"""
    
    @app.callback(
        [Output('weather-data-store', 'data'),
         Output('weather-forecast-version-checkboxes', 'children'),
         Output('weather-update-status', 'children')],
        [Input('weather-refresh-button', 'n_clicks'),
         Input('weather-refresh-interval', 'n_intervals')]
    )
    def refresh_weather_data(n_clicks, n_intervals):
        """Update forecast data display when data is refreshed or initialization completes"""
        start_time = time.time()
        handler = get_weather_data_handler()
        
        # Check if handler is initialized
        if not handler.initialized:
            # Return empty values until data is ready - consistent with uninitialized state
            logger.info("Weather data not yet initialized, returning empty values")
            return {}, [], "Weather data is loading..."
        
        # Determine update source
        ctx = dash.callback_context
        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else None
        
        # Only manually reload data when the button is clicked
        if trigger_id == 'weather-refresh-button' and n_clicks > 0:
            # Manual refresh triggered - reload data
            logger.info(f"Manual refresh triggered (button click)")
            handler.load_all_forecasts()
            update_status = f"Data refreshed at {datetime.now().strftime('%H:%M:%S')}"
        else:
            # Auto refresh or initial load - just update UI with current data
            update_status = f"Data last loaded at {datetime.now().strftime('%H:%M:%S')}"
        
        # Get available forecast versions
        versions = handler.get_available_forecast_versions()
        logger.info(f"Available versions: {versions}")
        
        # Create checkboxes in a horizontal layout
        checkboxes_list = []
        for i, version in enumerate(versions):
            date_str, release = version.split('_')
            
            # Set only the latest version to be selected by default
            is_checked = (i == 0) if versions else False
            
            checkbox = html.Div([
                dbc.Checkbox(
                    id={'type': 'weather-forecast-version-checkbox', 'index': version},
                    value=is_checked,
                    className='me-2'
                ),
                html.Label(f'{date_str} {release}z', className='form-check-label')
            ], style={'display': 'inline-block', 'margin-right': '15px'})
            checkboxes_list.append(checkbox)
        
        # Wrap all checkboxes in a container div
        checkboxes = html.Div(checkboxes_list, style={'display': 'flex', 'flex-wrap': 'wrap'})
        
        logger.info(f"Created {len(checkboxes_list)} checkboxes")
        logger.info(f"Refresh data callback completed in {time.time() - start_time:.2f}s")
        
        # Make sure we return the right number of outputs
        return {'status': 'ok'}, checkboxes, update_status
    
    @app.callback(
        [Output('weather-country-content', 'children')],
        [Input('weather-country-tabs', 'active_tab'),
         Input('weather-forecast-source-dropdown', 'value'),
         Input({'type': 'weather-forecast-version-checkbox', 'index': ALL}, 'value')],
        [State({'type': 'weather-forecast-version-checkbox', 'index': ALL}, 'id'),
         State('weather-data-store', 'data')]
    )
    def render_country_weather_content(country, forecast_sources, checkbox_values, checkbox_ids, stored_data):
        start_time = time.time()
        logger.info(f"Render content callback triggered for {country}")
        
        # Get the weather data handler
        handler = get_weather_data_handler()
        
        # Check if data is ready - consistent error handling with refresh callback
        if not handler.initialized:
            logger.info("Weather data not yet initialized, showing loading message")
            return [html.Div(
                dbc.Alert(
                    "Weather data is still being loaded. Content will appear when ready.",
                    color="info"
                ),
                className="mt-4"
            )]
        
        # Add input validation - consistent alert style
        if not forecast_sources:
            logger.warning("No forecast sources selected")
            return [html.Div(
                dbc.Alert(
                    "Please select at least one forecast source",
                    color="warning"
                ),
                className="mt-4"
            )]
        
        # Get the selected forecast versions
        selected_versions = []
        for value, checkbox_id in zip(checkbox_values, checkbox_ids):
            if value:  # If checkbox is checked
                selected_versions.append(checkbox_id['index'])
        
        if not selected_versions:
            # Default to the first available version
            versions = handler.get_available_forecast_versions()
            if versions:
                selected_versions = [versions[0]]
                logger.info(f"Defaulting to first available version: {selected_versions[0]}")
            else:
                logger.warning("No forecast data available")
                return [html.Div(
                    dbc.Alert(
                        "No forecast data available",
                        color="warning"
                    ),
                    className="mt-4"
                )]
        
        logger.info(f"Selected versions: {selected_versions}")
        
        # Get configuration
        config = handler.get_config()
        source_colors = handler.get_source_colors()
        forecast_source_names = handler.get_forecast_sources()
        
        # Create plots for each variable
        try:
            # First get the base individual variables (these are always available)
            wind_content = create_variable_plot(
                'Wind', country, forecast_sources, selected_versions,
                handler.preprocessed_plots, source_colors, forecast_source_names, config
            )
            
            solar_content = create_variable_plot(
                'PV', country, forecast_sources, selected_versions,
                handler.preprocessed_plots, source_colors, forecast_source_names, config
            )
            
            demand_content = create_variable_plot(
                'PowerDemand', country, forecast_sources, selected_versions,
                handler.preprocessed_plots, source_colors, forecast_source_names, config
            )
            
            # Create residual load plot (simplified version to avoid browser freeze)
            try:
                from utils.weather_plotting import create_residual_load_plot_simple
                residual_load_content = create_residual_load_plot_simple(
                    country, forecast_sources, selected_versions,
                    handler.preprocessed_plots, source_colors, forecast_source_names, config
                )
            except Exception as e:
                logger.error(f"Error creating residual load plot: {str(e)}", exc_info=True)
                residual_load_content = html.Div([
                    html.H3('Residual Load (Demand - Wind - Solar)', className='text-center mt-4'),
                    dbc.Alert(
                        f"Error creating Residual Load chart: {str(e)}",
                        color="danger",
                        className="mt-3"
                    )
                ])
            
            # Create main content with base variables first, residual load last
            main_content = dbc.Container([
                html.H2(f'{country} Weather Forecasts', className='text-center mb-4'),
                
                # Base variables first (always available)
                wind_content,
                html.Hr(className='mt-4 mb-4'),  # Divider between sections
                solar_content,
                html.Hr(className='mt-4 mb-4'),  # Divider between sections
                demand_content,
                html.Hr(className='mt-4 mb-4'),  # Divider between sections
                
                # Residual load last (derived, may be unavailable)
                dcc.Loading(
                    id=f"loading-{country}-residual-load",
                    type="circle",
                    children=[residual_load_content]
                )
            ], fluid=True)
            
            execution_time = time.time() - start_time
            logger.info(f"Render content completed in {execution_time:.2f}s")
            
            return [main_content]
        except Exception as e:
            logger.error(f"Error rendering content: {str(e)}", exc_info=True)
            return [html.Div(
                dbc.Alert(
                    f"Error rendering content: {str(e)}",
                    color="danger"
                ),
                className="mt-4"
            )]
    
    @app.callback(
        Output('weather-memory-cleanup-interval', 'disabled'),
        [Input('weather-memory-cleanup-interval', 'n_intervals')]
    )
    def clean_weather_memory(n_intervals):
        """Periodic memory cleanup callback"""
        if n_intervals > 0:
            logger.info(f"Memory cleanup triggered after {n_intervals} intervals")
            handler = get_weather_data_handler()
            handler.cleanup_old_caches()
        return False  # Keep interval enabled 