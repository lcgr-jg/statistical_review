import sys
import pathlib

import dash
from dash import dcc, html, callback, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
import logging
from plotly.subplots import make_subplots
import plotly.express as px
import gc  # For garbage collection

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import url_for  # noqa: E402

# Set up logging
logging.basicConfig(level=logging.INFO)  # Changed from DEBUG to INFO
logger = logging.getLogger(__name__)

# Priority countries to preload
PRIORITY_COUNTRIES = ['DE', 'FR', 'UK', 'NL', 'BE', 'ES']

# Define fuel type colors
fuel_type_colors = {
    'fossil gas': '#00008B',  # Dark blue for gas
    'nuclear': '#FFD700',     # Yellow for nuclear
    'biomass': '#228B22',     # Green for biomass
    'fossil hard coal': '#8B4513',  # Brown for coal
    'fossil brown coal/lignite': '#A0522D',  # Sienna for lignite
    'fossil oil': '#800000',  # Maroon for oil
    'waste': '#9ACD32',       # YellowGreen for waste
    'geothermal': '#FF4500',  # Orange red for geothermal
    'other': '#808080',       # Grey for other
}

def get_layout(data_handler):
    """Get the layout for the availability page"""
    today = datetime.now().date()
    default_end = today + timedelta(days=92)
    max_end = today + timedelta(days=180)

    return html.Div([
        # Navigation menu
        dbc.Navbar(
            [
                dbc.NavbarBrand("Fundamentals Dashboard", href="/", className="ms-2"),
                dbc.Nav(
                    [
                        dbc.NavItem(dbc.NavLink("Home", href="/")),
                        dbc.NavItem(dbc.NavLink("Availability", href="/availability", active=True)),
                        dbc.NavItem(dbc.NavLink("Generation vs Availability", href="/generation-vs-availability")),
                        dbc.NavItem(dbc.NavLink("Weather Forecast", href="/weather-forecast")),
                        dbc.NavItem(dbc.NavLink("Forecast Compare", href="/forecast-comparison")),
                        dbc.NavItem(dbc.NavLink("Prices", href=url_for('price'), external_link=True)),
                        dbc.NavItem(dbc.NavLink("Stack", href=url_for('stack'), external_link=True)),
                        dbc.NavItem(dbc.NavLink("Portal", href=url_for('portal'), external_link=True)),
                    ],
                    className="ms-auto",
                    navbar=True
                )
            ],
            dark=True,
            className="dashboard-navbar mb-3"
        ),
        
        # Main content
        dbc.Container([
            # Controls row: refresh + date picker
            dbc.Row([
                dbc.Col(
                    dbc.Button(
                        "Force Refresh Data",
                        id="avail-force-refresh",
                        color="primary",
                        className="mb-3"
                    ),
                    width="auto"
                ),
                dbc.Col([
                    html.Label("Date Range:", className="me-2",
                               style={"color": "#e0e0e0", "fontWeight": "bold"}),
                    dcc.DatePickerRange(
                        id="avail-date-range",
                        start_date=str(today),
                        end_date=str(default_end),
                        min_date_allowed=str(today - timedelta(days=180)),
                        max_date_allowed=str(max_end),
                        display_format="DD MMM YYYY",
                        style={"backgroundColor": "transparent"},
                    ),
                ], width="auto", className="d-flex align-items-center"),
                dbc.Col(
                    html.Div(id="avail-refresh-status", className="text-muted"),
                    width="auto"
                )
            ], className="mt-3"),
            
            # Country tabs - hardcoded priority countries to avoid timing issues
            dbc.Tabs(id="avail-country-tabs", active_tab="DE", children=[
                # Create a tab for each priority country (hardcoded)
                *[dbc.Tab(label=country, tab_id=country) for country in PRIORITY_COUNTRIES],
                
                # Create a tab for all other countries
                dbc.Tab(label="Other", tab_id="other", children=[
                    # Dropdown to select other countries - will be populated dynamically
                    html.Div([
                        html.Label("Select Country:"),
                        dcc.Dropdown(
                            id="avail-other-country-dropdown",
                            options=[],  # Will be populated by callback
                            value=None,
                            clearable=False,
                            placeholder="Loading countries..."
                        )
                    ], className="m-3")
                ])
            ], className="mt-3"),
            
            # Content area for country-specific charts
            html.Div(id="avail-content", className="mt-4"),
            
            # Hidden div to trigger content updates
            html.Div(id="avail-refresh-trigger", style={"display": "none"})
        ], fluid=True)
    ])

def register_availability_callbacks(app, data_handler):
    """Register callbacks for the availability page"""
    
    # Callback to populate the "Other" country dropdown
    @app.callback(
        [Output("avail-other-country-dropdown", "options"),
         Output("avail-other-country-dropdown", "value")],
        [Input("avail-country-tabs", "active_tab")]
    )
    def populate_other_countries_dropdown(active_tab):
        """Populate the dropdown with non-priority countries once data is ready"""
        if not data_handler.is_ready:
            return [], None
        
        all_countries = data_handler.get_countries()
        other_countries = [c for c in all_countries if c not in PRIORITY_COUNTRIES]
        
        if not other_countries:
            return [], None
        
        options = [{"label": country, "value": country} for country in other_countries]
        default_value = other_countries[0] if other_countries else None
        
        return options, default_value
    
    # Force refresh — only fires on button click, reads dates from State
    @app.callback(
        [Output("avail-content", "children", allow_duplicate=True),
         Output("avail-refresh-status", "children")],
        [Input("avail-force-refresh", "n_clicks")],
        [State("avail-country-tabs", "active_tab"),
         State("avail-other-country-dropdown", "value"),
         State("avail-date-range", "start_date"),
         State("avail-date-range", "end_date")],
        prevent_initial_call=True
    )
    def force_refresh(n_clicks, active_tab, other_country, start_date, end_date):
        if not n_clicks:
            return dash.no_update, ""
        data_handler.clear_cache()
        gc.collect()
        data_handler.reload_latest_data()
        content = update_content(active_tab, other_country, start_date, end_date)
        status = f"Data refreshed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        return content, status
    
    # Main content callback — fires on tab/dropdown/date changes
    @app.callback(
        Output("avail-content", "children"),
        [Input("avail-country-tabs", "active_tab"),
         Input("avail-other-country-dropdown", "value"),
         Input("avail-date-range", "start_date"),
         Input("avail-date-range", "end_date")]
    )
    def update_content(active_tab, other_country, start_date=None, end_date=None):
        """Update the content based on the selected country tab"""
        # Check if data is ready first
        if not data_handler.is_ready:
            return html.Div([
                dbc.Alert([
                    html.H4("Data is loading...", className="alert-heading"),
                    html.P("Please wait while we fetch the availability data from the database. This usually takes 30-60 seconds."),
                    dbc.Spinner(size="sm")
                ], color="info", className="mt-4")
            ])
        
        # Validate active_tab - reject if it's not a valid country code or "other"
        if not active_tab or (active_tab not in PRIORITY_COUNTRIES and active_tab != "other"):
            return html.Div("Please select a country", className="text-center mt-4")
        
        # Determine which country to display
        if active_tab == "other":
            if not other_country:
                return html.Div("Please select a country from the dropdown", className="text-center mt-4")
            active_country = other_country
        else:
            active_country = active_tab
            
        # If this is a non-priority country, log that we're loading on demand
        if active_country not in PRIORITY_COUNTRIES:
            logger.info(f"Lazy loading availability data for non-priority country: {active_country}")
            
            # For non-priority countries, we need to ensure data is loaded
            # We'll use get_fuel_types to trigger the necessary data loading
            data_handler.get_fuel_types(active_country)
        
        # Get available fuel types from pre-processed data
        processed_data = data_handler.global_data['processed_data']
        if active_country not in processed_data:
            # Try to get fuel types directly instead
            fuel_types = data_handler.get_fuel_types(active_country)
            if not fuel_types:
                return html.Div("No data available for this country", className="text-center mt-4")
            
            # We'll use a different approach for non-priority countries
            all_fuel_types = fuel_types
        else:
            country_data = processed_data[active_country]
            all_fuel_types = list(country_data.keys())
        
        # Define main fuel types to check
        main_fuel_type_candidates = [
            'fossil gas', 'gas ccgt', 'fossil hard coal', 'nuclear',
            'fossil brown coal/lignite', 'biomass',
        ]
        
        # Filter to only include fuel types that exist for this country
        main_fuel_types = []
        for ft in main_fuel_type_candidates:
            # Special case for Germany and nuclear
            if active_country == 'DE' and ft == 'nuclear':
                continue
            
            # Special case for UK - remove coal
            if active_country == 'UK' and ft in ['fossil hard coal', 'fossil brown coal/lignite']:
                continue
            
            if ft in all_fuel_types:
                main_fuel_types.append(ft)
        
        # Determine other fuel types
        other_fuel_types = [ft for ft in all_fuel_types if ft not in main_fuel_type_candidates]
        
        # Create charts for main fuel types
        charts = []
        for fuel_type in main_fuel_types:
            charts.append(
                dbc.Card([
                    dbc.CardHeader(f"{fuel_type.title()}"),
                    dbc.CardBody([
                        # Wrap each graph in its own loading component
                        dcc.Loading(
                            id=f"loading-{active_country}-{fuel_type.replace('/', '-')}",
                            type="circle",
                            children=[
                                dcc.Graph(
                                    id=f"avail-{active_country}-{fuel_type.replace('/', '-')}",
                                    figure=create_availability_figure(data_handler, active_country, fuel_type, start_date, end_date)
                                )
                            ]
                        )
                    ])
                ], className="mb-4")
            )
        
        # Create dropdown and chart for "Other" fuel types
        if other_fuel_types:
            other_section = dbc.Card([
                dbc.CardHeader("Other Fuel Types"),
                dbc.CardBody([
                    dcc.Dropdown(
                        id=f"avail-other-fuel-dropdown-{active_country}",
                        options=[{"label": ft.title(), "value": ft} for ft in other_fuel_types],
                        value=other_fuel_types[0] if other_fuel_types else None,
                        clearable=False
                    ),
                    # Wrap the graph in its own loading component
                    dcc.Loading(
                        id=f"loading-other-{active_country}",
                        type="circle",
                        children=[
                            dcc.Graph(id=f"avail-other-fuel-graph-{active_country}")
                        ]
                    )
                ])
            ], className="mb-4")
            
            charts.append(other_section)
        
        # If no charts were created, display a message
        if not charts:
            return html.Div("No data available for this country", className="text-center mt-4")
        
        return html.Div(charts)
    
    # Individual callbacks for each country's other fuel type graphs
    for country in ["DE", "FR", "NL", "BE", "UK", "ES"]:
        @app.callback(
            Output(f"avail-other-fuel-graph-{country}", "figure"),
            [Input(f"avail-other-fuel-dropdown-{country}", "value"),
             Input("avail-country-tabs", "active_tab"),
             Input("avail-date-range", "start_date"),
             Input("avail-date-range", "end_date")]
        )
        def update_other_fuel_graph(fuel_type, active_tab, start_date, end_date,
                                    country=country):
            if active_tab != country:
                return empty_figure("No data available", data_handler)
            if not fuel_type:
                return empty_figure("No fuel type selected", data_handler)
            
            return create_availability_figure(data_handler, country, fuel_type,
                                              start_date, end_date)
    
    # Callback for other countries' other fuel type graphs
    @app.callback(
        Output({"type": "avail-other-fuel-graph", "country": dash.ALL}, "figure"),
        [Input({"type": "avail-other-fuel-dropdown", "country": dash.ALL}, "value"),
         Input("avail-country-tabs", "active_tab"),
         Input("avail-other-country-dropdown", "value"),
         Input("avail-date-range", "start_date"),
         Input("avail-date-range", "end_date")]
    )
    def update_other_country_fuel_graph(selected_fuel_types, active_tab,
                                        other_country, start_date, end_date):
        if not selected_fuel_types:
            return empty_figure("No fuel type selected", data_handler)
        
        if active_tab != "other":
            return empty_figure("No data available", data_handler)
        
        selected_fuel_type = selected_fuel_types[0]
        
        return create_availability_figure(data_handler, other_country,
                                          selected_fuel_type, start_date, end_date)

_SNAPSHOT_COLORS = {
    'latest': '#4dabf7',
    'D-1':    '#ffa94d',
    'D-3':    '#ff6b6b',
    'D-7':    '#51cf66',
    'D-30':   '#cc5de8',
}

_SNAPSHOT_ORDER = ['latest', 'D-1', 'D-3', 'D-7', 'D-30']


def create_availability_figure(data_handler, country, fuel_type,
                               start_date=None, end_date=None):
    """Create a figure showing availability data with D-1/D-3/D-7/D-30 snapshots."""
    try:
        processed_data = data_handler.global_data.get('processed_data', {})

        if (country in processed_data and
            fuel_type in processed_data.get(country, {}) and
            'availability' in processed_data.get(country, {}).get(fuel_type, {})):
            df = processed_data[country][fuel_type]['availability']
        else:
            df = data_handler.get_availability_data(country, fuel_type)

        if df is None or len(df) == 0:
            return empty_figure(f"No data available for {country} - {fuel_type}", data_handler)

        if 'DATE' in df.columns and 'TIMESTAMP' not in df.columns:
            df = df.rename(columns={'DATE': 'TIMESTAMP'})
        if 'TIMESTAMP' not in df.columns:
            return empty_figure(f"Missing timestamp column for {country} - {fuel_type}", data_handler)

        df['TIMESTAMP'] = pd.to_datetime(df['TIMESTAMP'], errors='coerce')
        df = df.sort_values('TIMESTAMP')

        y_col = 'AVAILABILITY_AMOUNT' if 'AVAILABILITY_AMOUNT' in df.columns else 'AVAILABLE_CAPACITY'
        df[y_col] = pd.to_numeric(df[y_col], errors='coerce')

        fig = make_subplots(
            rows=2, cols=1, shared_xaxes=True,
            vertical_spacing=0.08, row_heights=[0.8, 0.2],
        )

        latest_data = None
        d1_data = None

        for label in _SNAPSHOT_ORDER:
            sub = df[df['AS_OF'] == label]
            if sub.empty:
                continue

            color = _SNAPSHOT_COLORS.get(label, '#adb5bd')
            is_latest = label == 'latest'

            if is_latest:
                latest_data = sub
            elif label == 'D-1':
                d1_data = sub

            fig.add_trace(go.Scatter(
                x=sub['TIMESTAMP'], y=sub[y_col],
                mode='lines',
                name=label,
                line=dict(
                    width=3 if is_latest else 2,
                    color=color,
                    dash='solid' if is_latest else 'dash',
                ),
                fill='tozeroy' if is_latest else None,
                fillcolor=color.replace(')', ',0.15)').replace('rgb', 'rgba')
                    if is_latest and color.startswith('#') is False else
                    f'rgba({int(color[1:3],16)},{int(color[3:5],16)},{int(color[5:7],16)},0.15)'
                    if is_latest else None,
            ), row=1, col=1)

        if latest_data is not None and d1_data is not None:
            merged = latest_data[['TIMESTAMP', y_col]].merge(
                d1_data[['TIMESTAMP', y_col]], on='TIMESTAMP',
                how='inner', suffixes=('_latest', '_d1'),
            )
            merged['diff'] = (merged[f'{y_col}_latest'] - merged[f'{y_col}_d1']).astype('float32')

            fig.add_trace(go.Bar(
                x=merged['TIMESTAMP'], y=merged['diff'],
                name='Latest − D-1',
                marker_color=merged['diff'].apply(
                    lambda v: '#51cf66' if v >= 0 else '#ff6b6b'),
                showlegend=False,
            ), row=2, col=1)

        fig.update_layout(
            template='plotly_dark',
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='#e0e0e0',
            title=dict(
                text=f"{country} — {fuel_type.title()} Availability",
                font=dict(size=16, color='#e0e0e0'),
            ),
            height=700,
            showlegend=True,
            legend=dict(
                orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1,
                bgcolor='rgba(34,38,46,0.95)', font=dict(color='#e0e0e0', size=11),
                bordercolor='#353a44', borderwidth=1,
            ),
            hovermode='x unified',
            hoverlabel=dict(bgcolor='#22262e', font_color='#e0e0e0', font_size=12),
            margin=dict(l=50, r=20, t=60, b=40),
            xaxis=dict(
                gridcolor='rgba(255,255,255,0.06)', zeroline=False,
                type='date',
                range=[start_date, end_date] if start_date and end_date else None,
            ),
            xaxis2=dict(
                gridcolor='rgba(255,255,255,0.06)', zeroline=False,
                type='date',
                range=[start_date, end_date] if start_date and end_date else None,
            ),
            yaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
            yaxis2=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
        )

        fig.update_yaxes(title_text='Availability (MW)', row=1, col=1)
        fig.update_yaxes(title_text='Diff (MW)', row=2, col=1)

        return fig

    except Exception as e:
        import traceback
        logger.error("Error creating figure for %s - %s: %s\n%s",
                     country, fuel_type, e, traceback.format_exc())
        return empty_figure(f"Error: {e}", data_handler)

def empty_figure(message="No data available", data_handler=None):
    """Create an empty figure with a message"""
    fig = go.Figure()

    is_loading = "loading" in message.lower() or "still loading" in message.lower()

    fig.add_annotation(
        text=message, xref="paper", yref="paper", x=0.5, y=0.5,
        showarrow=False,
        font=dict(size=16, color='#4dabf7' if is_loading else '#e0e0e0'),
    )

    if not is_loading and data_handler is not None and not data_handler.is_ready:
        fig.add_annotation(
            text="Data is still loading in the background. Please wait...",
            xref="paper", yref="paper", x=0.5, y=0.4,
            showarrow=False, font=dict(size=14, color='#4dabf7'),
        )

    fig.update_layout(
        template='plotly_dark',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        height=400, showlegend=False,
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
    )
    return fig 