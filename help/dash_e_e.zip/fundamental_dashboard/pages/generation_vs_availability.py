import sys
import pathlib

import dash
from dash import dcc, html, callback, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from plotly.subplots import make_subplots
import plotly.express as px
import gc  # For garbage collection

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import url_for  # noqa: E402

# Set up logging
logging.basicConfig(level=logging.INFO)  # Changed from DEBUG to INFO
logger = logging.getLogger(__name__)

# Priority countries to preload
PRIORITY_COUNTRIES = ['DE', 'FR', 'UK', 'NL', 'BE', 'ES']

# Define fuel type colors
fuel_type_colors = {
    'fossil gas': '#00008B',  # Dark blue for gas
    'nuclear': '#FFD700',     # Yellow for nuclear
    'biomass': '#228B22',     # Green for biomass
    'fossil hard coal': '#8B4513',  # Brown for coal
    'fossil brown coal/lignite': '#A0522D',  # Sienna for lignite
    'fossil oil': '#800000',  # Maroon for oil
    'waste': '#9ACD32',       # YellowGreen for waste
    'geothermal': '#FF4500',  # Orange red for geothermal
    'other': '#808080',       # Grey for other
}

def get_layout(data_handler):
    """Get the layout for the generation vs availability page"""
    today = datetime.now().date()
    default_end = today + timedelta(days=92)
    max_end = today + timedelta(days=180)

    return html.Div([
        # Navigation menu
        dbc.Navbar(
            [
                dbc.NavbarBrand("Fundamentals Dashboard", href="/", className="ms-2"),
                dbc.Nav(
                    [
                        dbc.NavItem(dbc.NavLink("Home", href="/")),
                        dbc.NavItem(dbc.NavLink("Availability", href="/availability")),
                        dbc.NavItem(dbc.NavLink("Generation vs Availability", href="/generation-vs-availability", active=True)),
                        dbc.NavItem(dbc.NavLink("Weather Forecast", href="/weather-forecast")),
                        dbc.NavItem(dbc.NavLink("Forecast Compare", href="/forecast-comparison")),
                        dbc.NavItem(dbc.NavLink("Prices", href=url_for('price'), external_link=True)),
                        dbc.NavItem(dbc.NavLink("Stack", href=url_for('stack'), external_link=True)),
                        dbc.NavItem(dbc.NavLink("Portal", href=url_for('portal'), external_link=True)),
                    ],
                    className="ms-auto",
                    navbar=True
                )
            ],
            dark=True,
            className="dashboard-navbar mb-3"
        ),
        
        # Main content
        dbc.Container([
            # Controls row: refresh + date picker
            dbc.Row([
                dbc.Col(
                    dbc.Button(
                        "Force Refresh Data",
                        id="gen-vs-avail-force-refresh",
                        color="primary",
                        className="mb-3"
                    ),
                    width="auto"
                ),
                dbc.Col([
                    html.Label("Date Range:", className="me-2",
                               style={"color": "#e0e0e0", "fontWeight": "bold"}),
                    dcc.DatePickerRange(
                        id="gen-vs-avail-date-range",
                        start_date=str(today),
                        end_date=str(default_end),
                        min_date_allowed=str(today - timedelta(days=180)),
                        max_date_allowed=str(max_end),
                        display_format="DD MMM YYYY",
                        style={"backgroundColor": "transparent"},
                    ),
                ], width="auto", className="d-flex align-items-center"),
                dbc.Col(
                    html.Div(id="gen-vs-avail-refresh-status", className="text-muted"),
                    width="auto"
                )
            ], className="mt-3"),
            
            # Country tabs - hardcoded priority countries to avoid timing issues
            dbc.Tabs(id="gen-vs-avail-country-tabs", active_tab="DE", children=[
                # Create a tab for each priority country (hardcoded)
                *[dbc.Tab(label=country, tab_id=country) for country in PRIORITY_COUNTRIES],
                
                # Create a tab for all other countries
                dbc.Tab(label="Other", tab_id="other", children=[
                    # Dropdown to select other countries - will be populated dynamically
                    html.Div([
                        html.Label("Select Country:"),
                        dcc.Dropdown(
                            id="gen-vs-avail-other-country-dropdown",
                            options=[],  # Will be populated by callback
                            value=None,
                            clearable=False,
                            placeholder="Loading countries..."
                        )
                    ], className="m-3")
                ])
            ], className="mt-3"),
            
            # Content area for country-specific charts
            html.Div(id="gen-vs-avail-content", className="mt-4"),
            
            # Hidden div to trigger content updates
            html.Div(id="gen-vs-avail-refresh-trigger", style={"display": "none"}),
            
            # Hidden div for download data
            dcc.Download(id="gen-vs-avail-download-data")
        ], fluid=True)
    ])

def register_generation_callbacks(app, data_handler):
    """Register callbacks for the generation vs availability page"""
    
    # Callback to populate the "Other" country dropdown
    @app.callback(
        [Output("gen-vs-avail-other-country-dropdown", "options"),
         Output("gen-vs-avail-other-country-dropdown", "value")],
        [Input("gen-vs-avail-country-tabs", "active_tab")]
    )
    def populate_other_countries_dropdown(active_tab):
        """Populate the dropdown with non-priority countries once data is ready"""
        if not data_handler.is_ready:
            return [], None
        
        all_countries = data_handler.get_countries()
        other_countries = [c for c in all_countries if c not in PRIORITY_COUNTRIES]
        
        if not other_countries:
            return [], None
        
        options = [{"label": country, "value": country} for country in other_countries]
        default_value = other_countries[0] if other_countries else None
        
        return options, default_value
    
    # Force refresh — only fires on button click, reads dates from State
    @app.callback(
        [Output("gen-vs-avail-content", "children", allow_duplicate=True),
         Output("gen-vs-avail-refresh-status", "children")],
        [Input("gen-vs-avail-force-refresh", "n_clicks")],
        [State("gen-vs-avail-country-tabs", "active_tab"),
         State("gen-vs-avail-other-country-dropdown", "value"),
         State("gen-vs-avail-date-range", "start_date"),
         State("gen-vs-avail-date-range", "end_date")],
        prevent_initial_call=True
    )
    def force_refresh(n_clicks, active_tab, other_country, start_date, end_date):
        if not n_clicks:
            return dash.no_update, ""
        data_handler.clear_cache()
        gc.collect()
        data_handler.reload_latest_data()
        content = update_content(active_tab, other_country, start_date, end_date)
        status = f"Data refreshed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        return content, status
    
    # Main content callback — fires on tab/dropdown/date changes
    @app.callback(
        Output("gen-vs-avail-content", "children"),
        [Input("gen-vs-avail-country-tabs", "active_tab"),
         Input("gen-vs-avail-other-country-dropdown", "value"),
         Input("gen-vs-avail-date-range", "start_date"),
         Input("gen-vs-avail-date-range", "end_date")]
    )
    def update_content(active_tab, other_country, start_date=None, end_date=None):
        # Check if data is ready first
        if not data_handler.is_ready:
            return html.Div([
                dbc.Alert([
                    html.H4("Data is loading...", className="alert-heading"),
                    html.P("Please wait while we fetch the generation and availability data from the database. This usually takes 30-60 seconds."),
                    dbc.Spinner(size="sm")
                ], color="info", className="mt-4")
            ])
        
        # Validate active_tab - reject if it's not a valid country code or "other"
        if not active_tab or (active_tab not in PRIORITY_COUNTRIES and active_tab != "other"):
            return html.Div("Please select a country", className="text-center mt-4")
        
        # Determine which country to display
        if active_tab == "other":
            if not other_country:
                return html.Div("Please select a country from the dropdown", className="text-center mt-4")
            active_country = other_country
        else:
            active_country = active_tab
        
        # If not a priority country, show a message that data is being loaded on demand
        if active_country not in PRIORITY_COUNTRIES:
            logger.info(f"Lazy loading data for non-priority country: {active_country}")
        
        # Get available fuel types for this country
        all_fuel_types = data_handler.get_fuel_types(active_country)
        
        main_fuel_type_candidates = [
            'fossil gas', 'gas ccgt', 'fossil hard coal', 'nuclear',
            'fossil brown coal/lignite', 'biomass',
        ]
        
        # Filter to only include fuel types that exist for this country AND have data
        main_fuel_types = []
        for ft in main_fuel_type_candidates:
            # Special case for Germany and nuclear
            if active_country == 'DE' and ft == 'nuclear':
                continue
                
            if ft in all_fuel_types:
                # Check if there's actual data
                try:
                    df = data_handler.get_merged_data(active_country, ft)
                    if not df.empty and 'GENERATION' in df.columns:
                        if not df['GENERATION'].isna().all() and not (df['GENERATION'] == 0).all():
                            main_fuel_types.append(ft)
                except Exception as e:
                    logger.error(f"Error checking data for {active_country} - {ft}: {e}")
        
        # Determine other fuel types
        other_fuel_types = [ft for ft in all_fuel_types if ft not in main_fuel_type_candidates]
        
        # Create charts for main fuel types
        charts = []
        for fuel_type in main_fuel_types:
            charts.append(
                dbc.Card([
                    dbc.CardHeader([
                        html.Div([
                            html.H5(f"{fuel_type.title()}", className="mb-0"),
                            dbc.Button(
                                "Download Data",
                                id={"type": "gen-vs-avail-download-btn", "country": active_country, "fuel": fuel_type},
                                color="primary",
                                size="sm",
                                className="ms-2"
                            )
                        ], className="d-flex align-items-center justify-content-between")
                    ]),
                    dbc.CardBody([
                        # Wrap each graph in its own loading component
                        dcc.Loading(
                            id=f"loading-gen-{active_country}-{fuel_type.replace('/', '-')}",
                            type="circle",
                            children=[
                                dcc.Graph(
                                    id=f"gen-{active_country}-{fuel_type.replace('/', '-')}",
                                    figure=create_generation_figure(data_handler, active_country, fuel_type, start_date, end_date)
                                )
                            ]
                        )
                    ])
                ], className="mb-4")
            )
        
        # Create dropdown and chart for "Other" fuel types
        if other_fuel_types:
            other_section = dbc.Card([
                dbc.CardHeader([
                    html.Div([
                        html.H5("Other Fuel Types", className="mb-0"),
                        dbc.Button(
                            "Download Data",
                            id={"type": "gen-vs-avail-download-btn", "country": active_country, "fuel": "other"},
                            color="primary",
                            size="sm",
                            className="ms-2"
                        )
                    ], className="d-flex align-items-center justify-content-between")
                ]),
                dbc.CardBody([
                    dcc.Dropdown(
                        id=f"gen-vs-avail-other-fuel-dropdown-{active_country}",
                        options=[{"label": ft.title(), "value": ft} for ft in other_fuel_types],
                        value=other_fuel_types[0] if other_fuel_types else None,
                        clearable=False
                    ),
                    # Wrap the graph in its own loading component
                    dcc.Loading(
                        id=f"loading-gen-other-{active_country}",
                        type="circle",
                        children=[
                            dcc.Graph(id=f"gen-vs-avail-other-fuel-graph-{active_country}")
                        ]
                    )
                ])
            ], className="mb-4")
            
            charts.append(other_section)
        
        # If no charts were created, display a message
        if not charts:
            return html.Div("No data available for this country", className="text-center mt-4")
        
        return html.Div(charts)
    
    # Individual callbacks for each country's other fuel type graphs
    for country in ["DE", "FR", "NL", "BE", "UK", "ES"]:
        @app.callback(
            Output(f"gen-vs-avail-other-fuel-graph-{country}", "figure"),
            [Input(f"gen-vs-avail-other-fuel-dropdown-{country}", "value"),
             Input("gen-vs-avail-country-tabs", "active_tab"),
             Input("gen-vs-avail-date-range", "start_date"),
             Input("gen-vs-avail-date-range", "end_date")]
        )
        def update_other_fuel_graph(fuel_type, active_tab, start_date, end_date,
                                    country=country):
            if active_tab != country:
                return empty_figure("No data available")
            if not fuel_type:
                return empty_figure("No fuel type selected")
            
            return create_generation_figure(data_handler, country, fuel_type,
                                            start_date, end_date)
    
    # Callback for other countries' other fuel type graphs
    @app.callback(
        Output({"type": "gen-vs-avail-other-fuel-graph", "country": dash.ALL}, "figure"),
        [Input({"type": "gen-vs-avail-other-fuel-dropdown", "country": dash.ALL}, "value"),
         Input("gen-vs-avail-country-tabs", "active_tab"),
         Input("gen-vs-avail-other-country-dropdown", "value"),
         Input("gen-vs-avail-date-range", "start_date"),
         Input("gen-vs-avail-date-range", "end_date")]
    )
    def update_other_country_fuel_graph(selected_fuel_types, active_tab,
                                        other_country, start_date, end_date):
        if not selected_fuel_types:
            return empty_figure("No fuel type selected")
        
        if active_tab != "other":
            return empty_figure("No data available")
        
        selected_fuel_type = selected_fuel_types[0]
        
        return create_generation_figure(data_handler, other_country,
                                        selected_fuel_type, start_date, end_date)
    
    # Callback for downloading data
    @app.callback(
        Output("gen-vs-avail-download-data", "data"),
        [Input({"type": "gen-vs-avail-download-btn", "country": dash.ALL, "fuel": dash.ALL}, "n_clicks")],
        [State("gen-vs-avail-country-tabs", "active_tab"),
         State("gen-vs-avail-other-country-dropdown", "value"),
         State({"type": "gen-vs-avail-other-fuel-dropdown", "country": dash.ALL}, "value")],
        prevent_initial_call=True
    )
    def download_data(n_clicks, active_tab, other_country, other_fuel_values):
        if not n_clicks or not any(n_clicks):
            return dash.no_update
            
        # Find which button was clicked
        ctx = dash.callback_context
        if not ctx.triggered:
            return dash.no_update
            
        button_id = ctx.triggered[0]["prop_id"].split(".")[0]
        button_id = eval(button_id)  # Convert string to dict
        
        country = button_id["country"]
        fuel_type = button_id["fuel"]
        
        # Handle "other" fuel type case
        if fuel_type == "other":
            if active_tab == "other":
                country = other_country
            fuel_type = other_fuel_values[0] if other_fuel_values else None
            if not fuel_type:
                return dash.no_update
        
        try:
            # Get the data
            df = data_handler.get_merged_data(country, fuel_type)
            if df is None or df.empty:
                return dash.no_update
                
            # Create CSV string
            csv_string = df.to_csv(index=False)
            
            # Return the file for download
            return dcc.send_string(
                csv_string,
                filename=f"generation_vs_availability_{country}_{fuel_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            )
            
        except Exception as e:
            logger.error(f"Error downloading data: {str(e)}")
            return dash.no_update

def create_generation_figure(data_handler, country, fuel_type,
                             start_date=None, end_date=None):
    """Create a figure showing both availability and generation data"""
    try:
        merged_data = data_handler.get_merged_data(country, fuel_type)
        
        if merged_data.empty:
            return empty_figure(f"No data available for {country} - {fuel_type}")
        
        fig = go.Figure()
        
        merged_data = merged_data.sort_values('TIMESTAMP')
        
        # Convert any float64 columns to float32
        for col in merged_data.select_dtypes(include=['float64']).columns:
            try:
                merged_data[col] = merged_data[col].astype('float32')
            except (TypeError, ValueError):
                pass
        
        # Calculate data coverage
        availability_coverage = merged_data['AVAILABILITY_AMOUNT'].notna().mean() * 100
        generation_coverage = merged_data['GENERATION'].notna().mean() * 100
        
        fig.add_trace(go.Scatter(
            x=merged_data['TIMESTAMP'], 
            y=merged_data['AVAILABILITY_AMOUNT'],
            name=f"Availability ({availability_coverage:.1f}%)",
            line=dict(color='#4dabf7', width=2),
        ))
        
        fig.add_trace(go.Scatter(
            x=merged_data['TIMESTAMP'], 
            y=merged_data['GENERATION'],
            name=f"Generation ({generation_coverage:.1f}%)",
            line=dict(color='#ff6b6b', width=2),
        ))
        
        missing_availability = merged_data[merged_data['AVAILABILITY_AMOUNT'].isna()]
        if not missing_availability.empty:
            fig.add_trace(go.Scatter(
                x=missing_availability['TIMESTAMP'],
                y=[0] * len(missing_availability),
                mode='markers',
                marker=dict(symbol='x', size=8, color='#4dabf7', opacity=0.5),
                name='Missing Availability', showlegend=True,
            ))
        
        missing_generation = merged_data[merged_data['GENERATION'].isna()]
        if not missing_generation.empty:
            fig.add_trace(go.Scatter(
                x=missing_generation['TIMESTAMP'],
                y=[0] * len(missing_generation),
                mode='markers',
                marker=dict(symbol='x', size=8, color='#ff6b6b', opacity=0.5),
                name='Missing Generation', showlegend=True,
            ))
        
        fig.update_layout(
            template='plotly_dark',
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font_color='#e0e0e0',
            title=dict(
                text=(f"{country} — {fuel_type.title()} Availability & Generation<br>"
                      f"<sup>Avail: {availability_coverage:.1f}% | "
                      f"Gen: {generation_coverage:.1f}%</sup>"),
                font=dict(size=15, color='#e0e0e0'),
                x=0.5,
            ),
            height=500,
            margin=dict(l=50, r=20, t=80, b=40),
            yaxis_title="Power (MW)",
            hovermode='x unified',
            hoverlabel=dict(bgcolor='#22262e', font_color='#e0e0e0', font_size=12),
            legend=dict(
                bgcolor='rgba(34,38,46,0.95)', font=dict(color='#e0e0e0', size=11),
                bordercolor='#353a44', borderwidth=1,
            ),
            xaxis=dict(
                gridcolor='rgba(255,255,255,0.06)', zeroline=False,
                type="date",
                range=[start_date, end_date] if start_date and end_date else None,
            ),
            yaxis=dict(gridcolor='rgba(255,255,255,0.06)', zeroline=False),
        )
        
        # Set y-axis range based on the maximum of both availability and generation
        avail_max = merged_data['AVAILABILITY_AMOUNT'].max()
        gen_max = merged_data['GENERATION'].max()
        y_max = np.nanmax([
            avail_max if pd.notna(avail_max) else 0,
            gen_max if pd.notna(gen_max) else 0,
        ])
        y_max = float(y_max) * 1.1 if y_max > 0 else 100
        fig.update_yaxes(range=[0, y_max])
        
        return fig
        
    except Exception as e:
        logger.error(f"Error creating generation figure: {str(e)}")
        return empty_figure(f"Error creating chart: {str(e)}")

def empty_figure(message="No data available"):
    """Create an empty figure with a message"""
    fig = go.Figure()

    is_loading = "loading" in message.lower() or "still loading" in message.lower()

    fig.add_annotation(
        text=message, xref="paper", yref="paper", x=0.5, y=0.5,
        showarrow=False,
        font=dict(size=20, color='#4dabf7' if is_loading else '#e0e0e0'),
    )

    fig.update_layout(
        template='plotly_dark',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        xaxis={"visible": False},
        yaxis={"visible": False}
    )
    return fig 