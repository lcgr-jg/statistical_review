"""Real-data debug script for the Trade Data Pivot Table.

This script attempts to fetch actual metadata and trades from the cache/Snowflake
to identify why days_to_expiry is resolving to None.
"""

import os
import sys
import pandas as pd
import numpy as np
import logging

# Add workspace root and corelib to path so we can import core.* and jain_commods.*
sys.path.insert(0, os.getcwd())
sys.path.insert(0, os.path.join(os.getcwd(), "eu_corelib"))
sys.path.insert(0, os.path.join(os.getcwd(), "eu_dashboard_power"))

from core.microstructure.data_pipeline import fetch_trades, fetch_tenor_metadata, clean_trades
from core.microstructure.pivot import enrich_for_pivot, build_pivot_payload

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_real_debug():
    zone = "France"
    shape = "Baseload"
    tenor = "Jun-26" # We'll fetch all but focus on one for print
    
    print(f"=== Real Data Debug: {zone} {shape} ===")
    
    # 1. Fetch Metadata
    print("\n1. Fetching Tenor Metadata...")
    try:
        metadata = fetch_tenor_metadata(zone=zone, shape=shape)
        print(f"   Fetched metadata for {len(metadata)} tenors.")
        if metadata:
            # Print a few examples
            sample_tenors = list(metadata.keys())[:5]
            for t in sample_tenors:
                print(f"   - {t}: {metadata[t]}")
        else:
            print("   [WARN] Metadata is EMPTY!")
    except Exception as e:
        print(f"   [FAIL] Metadata fetch failed: {e}")
        metadata = {}

    # 2. Fetch Trades (last 30 days only for speed)
    print("\n2. Fetching Trades (last 30 days)...")
    try:
        df_raw = fetch_trades(zone=zone, shape=shape, 
                             start_date=pd.Timestamp.now() - pd.Timedelta(days=30))
        print(f"   Fetched {len(df_raw)} raw trades.")
    except Exception as e:
        print(f"   [FAIL] Trade fetch failed: {e}")
        return

    # 3. Clean Trades
    print("\n3. Cleaning Trades...")
    df_clean = clean_trades(df_raw)
    print(f"   {len(df_clean)} trades remaining after cleaning.")
    
    unique_tenors = sorted(df_clean["TENOR_NAME"].unique())
    print(f"   Unique tenors in trades: {unique_tenors}")

    # 4. Check for mismatches
    print("\n4. Checking Tenor Name Mismatches...")
    missing = [t for t in unique_tenors if t not in metadata]
    if missing:
        print(f"   [WARN] {len(missing)} tenors in trades NOT FOUND in metadata!")
        print(f"   Missing tenors: {missing}")
    else:
        print("   [OK] All tenors in trades have metadata.")

    # 5. Test Enrichment
    print("\n5. Testing Enrichment...")
    try:
        enriched = enrich_for_pivot(df_clean, tenor_metadata=metadata)
        print(f"   Enriched frame shape: {enriched.shape}")
        
        # Check days_to_expiry specifically
        dte_stats = enriched["days_to_expiry"].value_counts(dropna=False)
        print("\n--- days_to_expiry value counts ---")
        print(dte_stats.head(10))
        
        if enriched["days_to_expiry"].isna().all():
            print("\n[FAIL] ALL days_to_expiry values are NaN!")
        elif enriched["days_to_expiry"].isna().any():
            nan_count = enriched["days_to_expiry"].isna().sum()
            print(f"\n[WARN] {nan_count} rows have NaN days_to_expiry.")
            # Show examples of rows with NaN
            bad_rows = enriched[enriched["days_to_expiry"].isna()].head(5)
            print("Example rows with NaN DTE:")
            print(bad_rows[["trade_date", "tenor", "contract_type"]])
        else:
            print("\n[OK] No NaNs in days_to_expiry.")

    except Exception as e:
        print(f"   [FAIL] Enrichment failed: {e}")
        import traceback
        traceback.print_exc()
        return

    # 6. Test final payload to dash_pivottable
    print("\n6. Building Pivot Payload...")
    data, n_rows = build_pivot_payload(df_clean, tenor_metadata=metadata)
    print(f"   Payload: {n_rows} rows, {len(data[0])} cols")
    print(f"   Header: {data[0]}")

    # Find the index of days_to_expiry
    if "days_to_expiry" in data[0]:
        dte_idx = data[0].index("days_to_expiry")
        sample_dte = [row[dte_idx] for row in data[1:11]]
        print(f"\n   Sample days_to_expiry values: {sample_dte}")
        print(f"   Types: {[type(v).__name__ for v in sample_dte]}")
    else:
        print("   [FAIL] days_to_expiry not in header!")

if __name__ == "__main__":
    run_real_debug()
