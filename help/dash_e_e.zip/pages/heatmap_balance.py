"""
Heatmap Balance — Dash page registrar.

All implementation lives in ``core.heatmap_balance``:
    * data       -- ``build_balance_matrix`` + cache helpers
    * table      -- ``BalanceTableGenerator`` + Excel display helper
    * layout     -- ``build_layout()``
    * callbacks  -- all Dash callbacks (registered on import)

This file's only jobs are:
    1. register the Dash page (skipped when ``HEATMAP_STANDALONE=1`` so the
       standalone runner can mount the layout on its own ``Dash`` app),
    2. expose the page-level ``layout`` Dash expects,
    3. import ``callbacks`` for its registration side-effect,
    4. re-export public names that other modules (e.g. ``portal_app``) import.
"""
from __future__ import annotations

import os

import dash

from core.heatmap_balance import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.heatmap_balance.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.heatmap_balance.data import (
    build_balance_matrix,
    clear_heatmap_balance_data_cache,
)
from core.heatmap_balance.layout import build_layout
from core.heatmap_balance.table import (
    BalanceTableGenerator,
    display_table_for_export,
)
from core.heatmap_balance.warmup import load_heatmap_balance_data


if os.environ.get("HEATMAP_STANDALONE", "").strip().lower() not in ("1", "true", "yes"):
    dash.register_page(
        __name__,
        path=PAGE_PATH,
        name=PAGE_NAME,
        title=PAGE_TITLE,
        order=PAGE_ORDER,
    )


layout = build_layout()


__all__ = [
    "BalanceTableGenerator",
    "build_balance_matrix",
    "clear_heatmap_balance_data_cache",
    "display_table_for_export",
    "layout",
    "load_heatmap_balance_data",
]
