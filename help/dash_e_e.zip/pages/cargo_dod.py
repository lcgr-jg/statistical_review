"""
LNG — Cargo DoD Changes page registrar.

Implementation lives in ``core.cargo_dod``:
    * data      -- KplerPITStore access (snapshots, coverage, backfill)
    * compare   -- cleaning + day-on-day comparison (port of lng_vessels)
    * render    -- headline cards, change lists, tables, coverage figure
    * layout    -- ``build_layout()``
    * callbacks -- registered on import
"""
from __future__ import annotations

import dash

from core.cargo_dod import callbacks as _callbacks  # noqa: F401
from core.cargo_dod.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.cargo_dod.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)


def layout(**_kwargs):
    """Rebuilt on every page visit so the date pickers' max/default dates
    track the clock (today becomes selectable once its ~06:00 UTC snapshot
    exists) instead of freezing at server-start time."""
    return build_layout()
