"""
Flows — Dash page registrar.

All implementation lives in ``core.flows``:
    * data       -- ``load_flows_data`` + ``aggregate_flows`` + cache helpers
    * layout     -- ``build_layout()``
    * callbacks  -- Cytoscape callback (registered on import)

This file's only jobs are:
    1. register the Dash page,
    2. expose the page-level ``layout`` Dash expects,
    3. import ``callbacks`` for its registration side-effect,
    4. re-export public names that other modules (e.g. ``portal_app``) import.
"""
from __future__ import annotations

import dash

from core.flows import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.flows.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.flows.data import clear_flows_cache, load_flows_data
from core.flows.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()

__all__ = [
    "clear_flows_cache",
    "layout",
    "load_flows_data",
]
