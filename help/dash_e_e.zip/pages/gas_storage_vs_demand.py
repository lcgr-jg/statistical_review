"""
EU Gas Balance — Storage vs Demand page registrar.

Implementation lives in ``core.gas_storage_vs_demand``:
    * data       -- CE stock + demand frames from ``gas_data_ce`` cache
    * charts     -- YoY Storage / Demand % Plotly figure
    * layout     -- ``build_layout()``
    * callbacks  -- registered on import
"""
from __future__ import annotations

import dash

from core.gas_storage_vs_demand import callbacks as _callbacks  # noqa: F401
from core.gas_storage_vs_demand.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.gas_storage_vs_demand.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
