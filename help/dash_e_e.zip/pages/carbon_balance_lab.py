"""
Carbon Balance lab — Dash page registrar.

React Balance (WIP) built by eu_carbon and pushed via
``POST /api/carbon/upload/balance-lab`` (see ``core.carbon_static``).
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/balance-lab",
    name=CARBON_PAGES["balance-lab"],
    title="Carbon Balance lab | JG Power Dashboard",
    order=59,
)

layout = iframe_page_layout("balance-lab")
