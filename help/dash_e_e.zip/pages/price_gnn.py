"""
Price GNN - Multi-tab integration
=================================
Trading views of the flow-GNN power price model: contract board (DA / weekend
/ front week / week+2) with ensemble distributions, per-contract member
distributions, contract-level backtest skill, and run health/provenance.

Data comes from the *research* S3 prefix published by eu_heatrate_model
(``flow_gnn_price_research``); see portal_pages/price_gnn/store.py.
"""
import json
import logging

import dash
from dash import Input, Output, callback, dcc, html

from portal_pages.fundamentals.styles import COLORS

logger = logging.getLogger(__name__)

if __name__ != '__main__':
    dash.register_page(
        __name__,
        path='/power/price_gnn',
        name='Price GNN',
        title='Price GNN | JG Power Dashboard',
        order=11,  # next to the other model dashboards
    )

# ---------------------------------------------------------------------------
# Sub-page management (mirrors pages/heatrate.py)
# ---------------------------------------------------------------------------
_sub_pages_loaded = False
_sub_page_modules = {}


def _ensure_loaded():
    """Lazy-load sub-page layout builders on first access."""
    global _sub_pages_loaded, _sub_page_modules
    if _sub_pages_loaded:
        return
    try:
        from portal_pages.price_gnn import backtest, board, distribution, health
        _sub_page_modules['board'] = board.get_layout
        _sub_page_modules['distribution'] = distribution.get_layout
        _sub_page_modules['backtest'] = backtest.get_layout
        _sub_page_modules['health'] = health.get_layout
        _sub_pages_loaded = True
        logger.info("Price GNN sub-pages loaded successfully")
    except Exception as e:
        logger.error(f"Failed to load Price GNN sub-pages: {e}")


def initialize_price_gnn_callbacks(app):
    """Register all Price GNN callbacks once at startup.

    Must run at startup (before the client fetches /_dash-dependencies):
    callbacks registered lazily inside another callback never fire.
    """
    cb_keys = set(app.callback_map.keys())
    if any("pgnn-board-table.children" in k for k in cb_keys):
        logger.warning("Price GNN callbacks already present. Skipping registration.")
        return
    from portal_pages.price_gnn import backtest, board, distribution, health
    board.register_callbacks(app)
    distribution.register_callbacks(app)
    backtest.register_callbacks(app)
    health.register_callbacks(app)
    logger.info("Price GNN callbacks initialized at startup")


# ---------------------------------------------------------------------------
# Sub-page definitions + tab bar (same look as HeatRate)
# ---------------------------------------------------------------------------
SUB_PAGES = [
    {'key': 'board', 'label': 'Contract Board', 'icon': '\U0001F4CB'},
    {'key': 'distribution', 'label': 'Contract Distribution', 'icon': '\U0001F4CA'},
    {'key': 'backtest', 'label': 'Backtest', 'icon': '\U0001F3AF'},
    {'key': 'health', 'label': 'Run Health', 'icon': '\U0001FA7A'},
]

_TAB_BAR_STYLE = {
    'display': 'flex',
    'gap': '0',
    'borderBottom': f'2px solid {COLORS["border"]}',
    'backgroundColor': COLORS['card_bg'],
    'padding': '0 24px',
    'boxShadow': '0 1px 2px rgba(0,0,0,0.03)',
}
_TAB_BTN_STYLE = {
    'padding': '14px 22px',
    'border': 'none',
    'borderBottom': '3px solid transparent',
    'backgroundColor': 'transparent',
    'color': COLORS['text_secondary'],
    'fontSize': '13px',
    'fontWeight': '500',
    'cursor': 'pointer',
    'transition': 'all 0.2s',
    'fontFamily': 'Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif',
    'letterSpacing': '0.2px',
    'whiteSpace': 'nowrap',
}

layout = html.Div(
    style={'minHeight': '100vh', 'backgroundColor': COLORS['background']},
    children=[
        dcc.Store(id='pgnn-active-tab', data='board'),
        html.Div(
            style=_TAB_BAR_STYLE,
            children=[
                html.Button(
                    f"{sp['icon']}  {sp['label']}",
                    id={'type': 'pgnn-tab-btn', 'index': sp['key']},
                    n_clicks=0,
                    style=_TAB_BTN_STYLE,
                )
                for sp in SUB_PAGES
            ],
        ),
        html.Div(
            id='pgnn-sub-content',
            style={'minHeight': '500px', 'padding': '24px 28px'},
        ),
    ],
)


@callback(
    Output('pgnn-sub-content', 'children'),
    [Input({'type': 'pgnn-tab-btn', 'index': sp['key']}, 'n_clicks')
     for sp in SUB_PAGES],
    prevent_initial_call=False,
)
def switch_pgnn_tab(*n_clicks):
    ctx = dash.callback_context
    triggered_id = 'board'  # default tab

    if ctx.triggered and ctx.triggered[0]['prop_id'] != '.':
        prop_id = ctx.triggered[0]['prop_id']
        try:
            btn_id = json.loads(prop_id.rsplit('.', 1)[0])
            triggered_id = btn_id.get('index', 'board')
        except (json.JSONDecodeError, KeyError):
            pass

    _ensure_loaded()
    if not _sub_pages_loaded:
        return html.Div("Loading Price GNN sub-pages...")

    try:
        get_layout_fn = _sub_page_modules.get(triggered_id)
        if get_layout_fn:
            return get_layout_fn()
        return html.Div(f"Sub-page '{triggered_id}' not found.")
    except Exception as e:
        logger.error(f"Error rendering Price GNN sub-page '{triggered_id}': {e}")
        return html.Div(f"Error loading {triggered_id}: {e}")
