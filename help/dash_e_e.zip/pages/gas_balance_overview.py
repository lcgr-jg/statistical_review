"""
EU Gas Balance — Overview page registrar.

Implementation lives in ``core.gas_balance``:
    * data       -- ``load_gas_balance`` + forecast metadata (cached)
    * layout     -- ``build_layout()``
    * callbacks  -- all Dash callbacks (registered on import)
"""
from __future__ import annotations

import dash

from core.gas_balance import callbacks as _callbacks  # noqa: F401
from core.gas_balance.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.gas_balance.data import clear_gas_balance_cache, load_gas_balance
from core.gas_balance.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()

__all__ = [
    "clear_gas_balance_cache",
    "layout",
    "load_gas_balance",
]
