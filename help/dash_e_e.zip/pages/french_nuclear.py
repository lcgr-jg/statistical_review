"""
French Nuclear Availability - Dash page registrar.

All implementation lives in ``core.french_nuclear``:
    * edf_store  -- reader for the EDF v2 outage store on S3 (remit/edf/)
    * data       -- memoised availability, scheduler-registered loader
    * compute    -- pure analytics (availability grid, market movers, slippage)
    * charts     -- plotly figure builders
    * layout     -- ``build_layout()``
    * callbacks  -- all Dash callbacks (registered on import)

This file's only jobs are:
    1. register the Dash page,
    2. expose the page-level ``layout`` Dash expects,
    3. import ``callbacks`` for its registration side-effect,
    4. re-export public names that other modules (e.g. ``portal_app``) import.
"""
import dash

from core.french_nuclear.layout import build_layout
from core.french_nuclear import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.french_nuclear.data import load_french_nuclear_data


dash.register_page(
    __name__,
    path='/power/french_nuclear',
    name='Nuclear Availability',
    title='Nuclear Availability | JG Power Dashboard',
    order=6,
)

layout = build_layout()


__all__ = ["load_french_nuclear_data", "layout"]
