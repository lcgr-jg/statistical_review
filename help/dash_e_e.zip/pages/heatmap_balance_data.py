"""
Data assembly for the Heatmap Balance dashboard.

Stitches backcast (historical / D-1) with short-term forecast from cache where available,
and computes Spot / CSS / CDS / Heat Rate using the same conventions as
``eu_reports/power_price_report/price_report.py`` (EU hubs).
"""
from __future__ import annotations

import datetime as dt
import logging
import zoneinfo
import re
from collections import OrderedDict
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

_PARIS_TZ = zoneinfo.ZoneInfo("Europe/Paris")


def _hours_in_paris_calendar_day(day: dt.date) -> int:
    """Wall-clock hours from local midnight to next midnight (23 / 24 / 25 around DST)."""
    t0 = dt.datetime(day.year, day.month, day.day, 0, 0, 0, tzinfo=_PARIS_TZ)
    t1 = t0 + dt.timedelta(days=1)
    h = int((t1 - t0).total_seconds() // 3600)
    return max(h, 1)


def _to_calendar_daily_hydro_mwh_to_avg_mw(s: pd.Series) -> pd.Series:
    """
    Hydro total curves are MWh per hour; daily average MW is
    (sum of hourly MWh in that calendar day) / (hours in that day in Europe/Paris).
    """
    if s is None or s.empty:
        return pd.Series(dtype=float)
    x = pd.to_numeric(s, errors="coerce").astype(float)
    x.index = pd.to_datetime(s.index)
    if x.index.tz is not None:
        x.index = x.index.tz_convert("Europe/Paris").tz_localize(None)
    day_key = x.index.normalize()
    daily_mwh = x.groupby(day_key).sum()
    hours = np.array(
        [_hours_in_paris_calendar_day(pd.Timestamp(ts).date()) for ts in daily_mwh.index],
        dtype=float,
    )
    return daily_mwh / np.maximum(hours, 1.0)


# Load all dashboard zones in one S3 read per curve × date window; slice by zone in memory.
_HEATMAP_ZONE_LC = ("de", "fr", "nl", "be", "at", "ch", "it", "es", "gb", "hu", "ro", "bg")

# LRU-ish caches keyed by date window (and issue for forecasts) — switching zone reuses these frames.
_ACTUAL_FRAME_OD: "OrderedDict[tuple[str, str, str], pd.DataFrame]" = OrderedDict()
_FORECAST_FRAME_OD: "OrderedDict[tuple[str, str, str, str], pd.DataFrame]" = OrderedDict()
_MARKET_BUNDLE_OD: "OrderedDict[tuple[str, str], dict[str, Any]]" = OrderedDict()
_FORWARD_BUNDLE_OD: "OrderedDict[tuple[str, str], dict[str, Any]]" = OrderedDict()

_MAX_ACTUAL_FRAMES = 48
_MAX_FORECAST_FRAMES = 48
_MAX_MARKET_BUNDLES = 8
_MAX_FORWARD_BUNDLES = 16

# Window-slack buffer (days) — when a load is triggered we fetch a *wider*
# envelope than strictly requested so that subsequent slider changes (e.g.
# history-days +/- a few weeks) can be served from memory without re-hitting
# S3.  The envelope is rounded outward to the nearest ``_ENVELOPE_GRID`` so
# that small slider tweaks land on the same cache key.
_ENVELOPE_PAD_DAYS = 540  # ≈ 18 months of slack on each side
_ENVELOPE_GRID = 90       # round envelope edges to multiples of this many days

# Negative cache: remember (key -> expiry_ts) for loads that raised, so we don't
# hammer S3 on every callback fire when a parquet hasn't been published yet.
# TTL is short so the dashboard recovers automatically once the file appears.
_NEG_CACHE_TTL_SECS = 300  # 5 minutes
_ACTUAL_FRAME_NEG: "dict[tuple, float]" = {}
_FORECAST_FRAME_NEG: "dict[tuple, float]" = {}
_LEGACY_ACTUAL_NEG: "dict[tuple, float]" = {}
_LEGACY_FORECAST_NEG: "dict[tuple, float]" = {}


def _neg_hit(neg: "dict[tuple, float]", key: tuple) -> bool:
    import time
    exp = neg.get(key)
    if exp is None:
        return False
    if exp < time.time():
        neg.pop(key, None)
        return False
    return True


def _neg_mark(neg: "dict[tuple, float]", key: tuple) -> None:
    import time
    neg[key] = time.time() + _NEG_CACHE_TTL_SECS


def _cache_touch_frame(
    od: "OrderedDict[tuple, pd.DataFrame]",
    key: tuple,
    df: pd.DataFrame,
    maxsize: int,
) -> None:
    od[key] = df
    od.move_to_end(key)
    while len(od) > maxsize:
        od.popitem(last=False)


def _envelope_for(start: dt.date, end: dt.date) -> tuple[dt.date, dt.date]:
    """Round (start, end) outward into a wide envelope so neighbouring requests share a cache key.

    Strategy: pad each side by ``_ENVELOPE_PAD_DAYS`` then snap to the nearest
    ``_ENVELOPE_GRID``-day grid (start floored, end ceiled).  Two requests
    whose windows fall inside the same grid cell will hit the same cache.
    """
    pad = dt.timedelta(days=_ENVELOPE_PAD_DAYS)
    raw_start = start - pad
    raw_end = end + pad
    # Snap to grid relative to a fixed epoch so the buckets are stable
    epoch = dt.date(2000, 1, 1)
    start_off = (raw_start - epoch).days
    end_off = (raw_end - epoch).days
    snapped_start = epoch + dt.timedelta(days=(start_off // _ENVELOPE_GRID) * _ENVELOPE_GRID)
    snapped_end_off = ((end_off + _ENVELOPE_GRID - 1) // _ENVELOPE_GRID) * _ENVELOPE_GRID
    snapped_end = epoch + dt.timedelta(days=snapped_end_off)
    return snapped_start, snapped_end


def _slice_wide_frame_by_window(
    df: pd.DataFrame, start: dt.date, end: dt.date
) -> pd.DataFrame:
    """Slice a cached wide frame (DatetimeIndex or close) to ``[start, end]`` inclusive."""
    if df is None or df.empty:
        return df
    try:
        idx = pd.to_datetime(df.index)
    except Exception:
        return df  # unknown index — let caller handle
    if getattr(idx, "tz", None) is not None:
        idx = idx.tz_convert("Europe/Paris").tz_localize(None)
    ts0 = pd.Timestamp(start)
    ts1 = pd.Timestamp(end) + pd.Timedelta(days=1)
    mask = (idx >= ts0) & (idx < ts1)
    if mask.all():
        return df
    out = df.loc[mask] if mask.any() else df.iloc[0:0]
    return out


def clear_heatmap_balance_data_cache() -> None:
    """Clear server-side wide-frame caches (tests / explicit reset)."""
    _ACTUAL_FRAME_OD.clear()
    _FORECAST_FRAME_OD.clear()
    _MARKET_BUNDLE_OD.clear()
    _FORWARD_BUNDLE_OD.clear()
    _ACTUAL_FRAME_NEG.clear()
    _FORECAST_FRAME_NEG.clear()
    _LEGACY_ACTUAL_NEG.clear()
    _LEGACY_FORECAST_NEG.clear()
    # Legacy in-memory frame caches are defined later in the module; guard
    # with hasattr so this helper still works during partial module reloads.
    for od_name in ("_LEGACY_ACTUAL_OD", "_LEGACY_FORECAST_OD"):
        od = globals().get(od_name)
        if od is not None:
            od.clear()

try:
    from jain_commods.core.cache.data.fundamentals import (
        ModelTag,
        IssueVersion,
        ResLoadBackcast,
        ConsBackcast,
        GenWindBackcast,
        GenSolarBackcast,
        ResLoadFcstST,
        ConsFcstST,
        GenWindFcstST,
        GenSolarFcstST,
        GenNuclearActual,
        GenNuclearFcstST,
        GenHydroTotalActual,
        GenHydroTotalFcst,
        GenCoalActual,
        GenLigniteActual,
        GenGasActual,
        NetExportDayAhead,
    )
    from jain_commods.core.cache.data.market import (
        PricePowerSpot,
        PriceGasSpot,
        PriceCO2Spot,
        PriceCoalSpot,
        PricePowerForward,
        PriceGasForward,
        PriceCO2Forward,
        PriceCoalForward,
        ForexSpot,
    )
    _COMMODS = True
except ImportError as e:
    logger.warning("jain_commods import failed: %s", e)
    _COMMODS = False

# ── Price metric constants (aligned with price_report.DataLoader._calculate_metrics EU branch)
GAS_EFF = 0.5
COAL_EFF = 0.4
GAS_EMISSIONS = 0.1821
COAL_EMISSIONS = 0.34
API2_TO_MWH = 6.97

PRICE_ROWS = ["Spot", "CSS", "CDS", "Heat rate", "TTF", "EUA", "NBP", "UKA"]
# Short header for residual load; derived column next to it
RESIDUAL_LOAD_ROW = "ResL"
RESIDUAL_MINUS_NUKE = "ResL - Nuke"
RESIDUAL_MINUS_NUKE_HYD = "ResL - Nuke - Hyd"
FUND_ROWS = [
    RESIDUAL_LOAD_ROW,
    RESIDUAL_MINUS_NUKE,
    RESIDUAL_MINUS_NUKE_HYD,
    "Consumption",
    "Solar",
    "Wind",
    "Hydro total",
    "Nuclear",
    "Coal gen",
    "Lignite gen",
    "Gas gen",
    "Net Export",
]

# Column-wise table coloring: demand/load rows → high = red; renewable/thermal/nuclear gen → high = green
FUND_DEMAND_ROWS = (
    RESIDUAL_LOAD_ROW,
    RESIDUAL_MINUS_NUKE,
    RESIDUAL_MINUS_NUKE_HYD,
    "Consumption",
)
# Net Export / Gas gen use inverted gradient vs other supply (see heatmap_balance_table)
NET_EXPORT_METRIC = "Net Export"
GAS_GEN_METRIC = "Gas gen"
FUND_SUPPLY_ROWS = tuple(r for r in FUND_ROWS if r not in FUND_DEMAND_ROWS)


def zone_lower(zone: str) -> str:
    z = zone.strip().lower()
    if z in ("uk", "gb"):
        return "gb"
    return z


def zone_upper(zone: str) -> str:
    z = zone.strip().upper()
    if z in ("GB", "UK"):
        return "UK"
    return z


def _to_calendar_daily(s: pd.Series) -> pd.Series:
    """Mean within each calendar day (delivery series, naive or tz-aware index)."""
    if s is None or s.empty:
        return pd.Series(dtype=float)
    x = s.copy()
    x.index = pd.to_datetime(x.index)
    if x.index.tz is not None:
        x.index = x.index.tz_convert("Europe/Paris").tz_localize(None)
    return x.groupby(x.index.normalize()).mean()


def _pick_zone_column(df: pd.DataFrame, zone_lc: str) -> pd.Series:
    if df is None or df.empty:
        return pd.Series(dtype=float)
    zone_lc = zone_lc.lower()
    cols = df.columns
    aliases = {zone_lc}
    if zone_lc == "gb":
        aliases |= {"uk"}

    if isinstance(cols, pd.MultiIndex):
        # 1. Filter frequency = 'H' only when the level is explicitly named 'frequency'
        # (PricePowerSpot has this; PricePowerForward does NOT — keep it safe).
        level_names = [str(n).lower() if n is not None else "" for n in cols.names]
        freq_level_idx = level_names.index("frequency") if "frequency" in level_names else None
        if freq_level_idx is not None:
            freq_lev = cols.get_level_values(freq_level_idx).astype(str).str.upper()
            mask_h = freq_lev == "H"
            if mask_h.any():
                df = df.loc[:, mask_h]
                cols = df.columns

        # Identify which level is 'zone' (defaults to level 0)
        zone_level_idx = level_names.index("zone") if "zone" in level_names else 0

        zlev = cols.get_level_values(zone_level_idx).astype(str).str.lower()
        zone_mask = zlev.isin(aliases)
        if zone_mask.any():
            sub = df.loc[:, zone_mask]
            sub_cols = sub.columns
            sub_level_names = [str(n).lower() if n is not None else "" for n in sub_cols.names]

            # Special handling for GB: prefer MACQ (forward) or GBP N2EX (spot)
            if zone_lc == "gb":
                exch_idx = sub_level_names.index("exchange") if "exchange" in sub_level_names else (1 if sub_cols.nlevels > 1 else None)
                curr_idx = sub_level_names.index("currency") if "currency" in sub_level_names else (2 if sub_cols.nlevels > 2 else None)
                if exch_idx is not None:
                    exch_lev = sub_cols.get_level_values(exch_idx).astype(str).str.upper()
                    # Prefer MACQ (forward) if available
                    macq_pref = exch_lev == "MACQ"
                    if macq_pref.any():
                        return sub.loc[:, macq_pref].mean(axis=1)
                    # Else prefer N2EX GBP (spot)
                    if curr_idx is not None:
                        curr_lev = sub_cols.get_level_values(curr_idx).astype(str).str.upper()
                        gb_pref = (exch_lev == "N2EX") & (curr_lev == "GBP")
                        if gb_pref.any():
                            return sub.loc[:, gb_pref].mean(axis=1)

            return sub.mean(axis=1)

        # Fallback: search other levels for the zone
        for level_i in range(cols.nlevels):
            if level_i == zone_level_idx:
                continue
            zlev = cols.get_level_values(level_i).astype(str).str.lower()
            for want in aliases:
                mask = zlev == want
                if mask.any():
                    sub = df.loc[:, mask]
                    return sub.mean(axis=1)
    else:
        zlev = cols.astype(str).str.lower()
        for want in aliases:
            mask = zlev == want
            if mask.any():
                sub = df.loc[:, mask]
                return sub.mean(axis=1)

    num = df.select_dtypes(include=[np.number])
    if num.shape[1] >= 1:
        return num.mean(axis=1)
    return pd.Series(dtype=float)


def _normalize_forward_frame_index(df: pd.DataFrame) -> pd.DataFrame:
    """Naive midnight index (Paris strip) for consistent delivery-window slicing."""
    if df is None or df.empty:
        return df
    out = df.copy()
    ix = pd.to_datetime(out.index)
    if getattr(ix, "tz", None) is not None:
        ix = ix.tz_convert("Europe/Paris").tz_localize(None)
    out.index = ix.normalize()
    return out[~out.index.duplicated(keep="last")]


def _slice_forward_frame_delivery(df: pd.DataFrame, start: dt.date, end: dt.date) -> pd.DataFrame:
    if df is None or df.empty:
        return df
    dfn = _normalize_forward_frame_index(df)
    ts0 = pd.Timestamp(start)
    ts1 = pd.Timestamp(end) + pd.Timedelta(days=1)
    return dfn.loc[(dfn.index >= ts0) & (dfn.index < ts1)]


def _sparse_series_to_calendar_daily(s: pd.Series, cal_idx: pd.DatetimeIndex) -> pd.Series:
    """
    Map sparse inputs (e.g. monthly gas/carbon forwards) onto every calendar day in ``cal_idx``.

    Uses union(reported dates, calendar) + ffill/bfill so month-ahead prices apply to all
    delivery days in that month (the row index is no longer only month-start timestamps).
    """
    if s is None or s.empty:
        return pd.Series(np.nan, index=cal_idx)
    x = s.copy()
    x.index = pd.to_datetime(x.index)
    if x.index.tz is not None:
        x.index = x.index.tz_convert("Europe/Paris").tz_localize(None)
    x.index = x.index.normalize()
    x = x.groupby(x.index).mean()
    extended = cal_idx.union(x.index).sort_values()
    return x.reindex(extended).ffill(limit=400).bfill(limit=400).reindex(cal_idx)


def _load_actual_frame_wide(cls, start: dt.date, end: dt.date) -> pd.DataFrame:
    """Single S3 load with all heatmap zones; cached per (class, envelope).

    The actual ``[start, end]`` window is *promoted* to a wide envelope (see
    ``_envelope_for``) so that small slider changes (history-days, forward-days)
    are served from memory without re-hitting S3.  Failures are negatively
    cached for ``_NEG_CACHE_TTL_SECS``.
    """
    if not _COMMODS:
        return pd.DataFrame()
    env_start, env_end = _envelope_for(start, end)
    key = (cls.__name__, env_start.isoformat(), env_end.isoformat())
    if key in _ACTUAL_FRAME_OD:
        _ACTUAL_FRAME_OD.move_to_end(key)
        return _slice_wide_frame_by_window(_ACTUAL_FRAME_OD[key], start, end)
    if _neg_hit(_ACTUAL_FRAME_NEG, key):
        return pd.DataFrame()
    try:
        obj = cls()
        obj.load(
            from_s3=True,
            show_metadata=False,
            zones=list(_HEATMAP_ZONE_LC),
            start_date=env_start,
            end_date=env_end,
        )
    except Exception as e:
        logger.debug("%s wide load failed (negative-cached %ds): %s", cls.__name__, _NEG_CACHE_TTL_SECS, e)
        _neg_mark(_ACTUAL_FRAME_NEG, key)
        return pd.DataFrame()
    df = getattr(obj, "data", None)
    full = df.copy() if df is not None and not df.empty else pd.DataFrame()
    _cache_touch_frame(_ACTUAL_FRAME_OD, key, full, _MAX_ACTUAL_FRAMES)
    return _slice_wide_frame_by_window(full, start, end)


def _load_forecast_frame_wide(cls, issue_date: dt.date, start: dt.date, end: dt.date) -> pd.DataFrame:
    """Forecast curves: cached per (class, issue, envelope). Failures negatively cached.

    See ``_load_actual_frame_wide`` re: envelope promotion — same idea here, but the
    cache key also includes ``issue_date`` because forecast vintages are immutable.
    """
    if not _COMMODS:
        return pd.DataFrame()
    env_start, env_end = _envelope_for(start, end)
    key = (cls.__name__, issue_date.isoformat(), env_start.isoformat(), env_end.isoformat())
    if key in _FORECAST_FRAME_OD:
        _FORECAST_FRAME_OD.move_to_end(key)
        return _slice_wide_frame_by_window(_FORECAST_FRAME_OD[key], start, end)
    if _neg_hit(_FORECAST_FRAME_NEG, key):
        return pd.DataFrame()
    try:
        if cls.__name__ == "GenNuclearFcstST":
            obj = GenNuclearFcstST(issue_date=issue_date)
        elif cls.__name__ == "GenHydroTotalFcst":
            obj = GenHydroTotalFcst(issue_date=issue_date)
        else:
            obj = cls(tag=ModelTag.EC, issue_date=issue_date, issue_version=IssueVersion.IV00)
        obj.load(
            from_s3=True,
            show_metadata=False,
            zones=list(_HEATMAP_ZONE_LC),
            start_date=env_start,
            end_date=env_end,
            issue_date=issue_date,
            issue_version=IssueVersion.IV00,
        )
    except Exception as e:
        logger.debug("%s forecast wide load failed (negative-cached %ds): %s", cls.__name__, _NEG_CACHE_TTL_SECS, e)
        _neg_mark(_FORECAST_FRAME_NEG, key)
        return pd.DataFrame()
    df = getattr(obj, "data", None)
    full = df.copy() if df is not None and not df.empty else pd.DataFrame()
    _cache_touch_frame(_FORECAST_FRAME_OD, key, full, _MAX_FORECAST_FRAMES)
    return _slice_wide_frame_by_window(full, start, end)


# Legacy single-zone fallback caches (curve data) — keyed by envelope so slider
# tweaks reuse the in-memory frame.
_LEGACY_ACTUAL_OD: "OrderedDict[tuple[str, str, str, str], pd.DataFrame]" = OrderedDict()
_LEGACY_FORECAST_OD: "OrderedDict[tuple[str, str, str, str, str], pd.DataFrame]" = OrderedDict()
_MAX_LEGACY_FRAMES = 64


def _load_actual_curve_legacy(cls, zone_lc: str, start: dt.date, end: dt.date) -> pd.Series:
    """Single-zone S3 load when wide cache returned empty (fallback).

    Loads on a wide envelope and slices in memory so subsequent slider tweaks
    don't re-hit S3.  Failures are negatively cached.
    """
    if not _COMMODS:
        return pd.Series(dtype=float)
    env_start, env_end = _envelope_for(start, end)
    key = (cls.__name__, zone_lc, env_start.isoformat(), env_end.isoformat())
    if key in _LEGACY_ACTUAL_OD:
        _LEGACY_ACTUAL_OD.move_to_end(key)
        full = _LEGACY_ACTUAL_OD[key]
    elif _neg_hit(_LEGACY_ACTUAL_NEG, key):
        return pd.Series(dtype=float)
    else:
        try:
            obj = cls()
            obj.load(
                from_s3=True,
                show_metadata=False,
                zones=[zone_lc],
                start_date=env_start,
                end_date=env_end,
            )
        except Exception as e:
            logger.debug("%s legacy load (negative-cached %ds): %s", cls.__name__, _NEG_CACHE_TTL_SECS, e)
            _neg_mark(_LEGACY_ACTUAL_NEG, key)
            return pd.Series(dtype=float)
        if getattr(obj, "data", None) is None or obj.data.empty:
            _neg_mark(_LEGACY_ACTUAL_NEG, key)
            return pd.Series(dtype=float)
        full = obj.data.copy()
        _cache_touch_frame(_LEGACY_ACTUAL_OD, key, full, _MAX_LEGACY_FRAMES)
    sliced = _slice_wide_frame_by_window(full, start, end)
    return _pick_zone_column(sliced, zone_lc)


def _load_forecast_curve_legacy(
    cls, zone_lc: str, issue_date: dt.date, start: dt.date, end: dt.date
) -> pd.Series:
    if not _COMMODS:
        return pd.Series(dtype=float)
    env_start, env_end = _envelope_for(start, end)
    key = (cls.__name__, zone_lc, issue_date.isoformat(), env_start.isoformat(), env_end.isoformat())
    if key in _LEGACY_FORECAST_OD:
        _LEGACY_FORECAST_OD.move_to_end(key)
        full = _LEGACY_FORECAST_OD[key]
    elif _neg_hit(_LEGACY_FORECAST_NEG, key):
        return pd.Series(dtype=float)
    else:
        try:
            if cls.__name__ == "GenNuclearFcstST":
                obj = GenNuclearFcstST(issue_date=issue_date)
            elif cls.__name__ == "GenHydroTotalFcst":
                obj = GenHydroTotalFcst(issue_date=issue_date)
            else:
                obj = cls(tag=ModelTag.EC, issue_date=issue_date, issue_version=IssueVersion.IV00)
            obj.load(
                from_s3=True,
                show_metadata=False,
                zones=[zone_lc],
                start_date=env_start,
                end_date=env_end,
                issue_date=issue_date,
                issue_version=IssueVersion.IV00,
            )
        except Exception as e:
            logger.debug("%s forecast legacy load (negative-cached %ds): %s", cls.__name__, _NEG_CACHE_TTL_SECS, e)
            _neg_mark(_LEGACY_FORECAST_NEG, key)
            return pd.Series(dtype=float)
        if getattr(obj, "data", None) is None or obj.data.empty:
            _neg_mark(_LEGACY_FORECAST_NEG, key)
            return pd.Series(dtype=float)
        full = obj.data.copy()
        _cache_touch_frame(_LEGACY_FORECAST_OD, key, full, _MAX_LEGACY_FRAMES)
    sliced = _slice_wide_frame_by_window(full, start, end)
    return _pick_zone_column(sliced, zone_lc)


def _load_actual_curve(cls, zone_lc: str, start: dt.date, end: dt.date) -> pd.Series:
    df = _load_actual_frame_wide(cls, start, end)
    if df.empty:
        return _load_actual_curve_legacy(cls, zone_lc, start, end)
    return _pick_zone_column(df, zone_lc)


def _load_forecast_curve(cls, zone_lc: str, issue_date: dt.date, start: dt.date, end: dt.date) -> pd.Series:
    df = _load_forecast_frame_wide(cls, issue_date, start, end)
    if df.empty:
        return _load_forecast_curve_legacy(cls, zone_lc, issue_date, start, end)
    return _pick_zone_column(df, zone_lc)


def _stitch_daily_forecast_from_today(
    hist: pd.Series,
    fcst: pd.Series,
    split: dt.date,
    calendar_index: pd.DatetimeIndex,
    today: dt.date,
    *,
    to_daily: Optional[Callable[[pd.Series], pd.Series]] = None,
) -> pd.Series:
    """
    For delivery dates **before** calendar ``today``, blend hist vs fcst at ``split`` (hist if ``d < split``, else fcst).
    For **today** and **all later** delivery dates in the window, use **forecast only** so same-day
    actual/backcast values never appear for today.
    """
    daily_fn = to_daily or _to_calendar_daily
    h = daily_fn(hist).reindex(calendar_index)
    f = daily_fn(fcst).reindex(calendar_index)
    idxn = calendar_index.normalize()
    ts_split = pd.Timestamp(split).normalize()
    ts_today = pd.Timestamp(today).normalize()
    out = pd.Series(np.nan, index=calendar_index, dtype=float)
    m_today_onwards = idxn >= ts_today
    m_hist = ~m_today_onwards & (idxn < ts_split)
    m_fcst_before_today = ~m_today_onwards & (idxn >= ts_split)
    out.loc[m_today_onwards] = f.loc[m_today_onwards]
    out.loc[m_hist] = h.loc[m_hist].where(h.loc[m_hist].notna(), f.loc[m_hist])
    out.loc[m_fcst_before_today] = f.loc[m_fcst_before_today]
    return out


def _stitch_nuclear(
    actual: pd.Series,
    fcst: pd.Series,
    split: dt.date,
    calendar_index: pd.DatetimeIndex,
    today: dt.date,
    *,
    to_daily: Optional[Callable[[pd.Series], pd.Series]] = None,
) -> pd.Series:
    """Actual before split for past delivery days; forecast from split onward; today+ → forecast only."""
    return _stitch_daily_forecast_from_today(
        actual, fcst, split, calendar_index, today, to_daily=to_daily
    )


def _get_market_bundle(start: dt.date, end: dt.date) -> Optional[dict[str, Any]]:
    """Power + fuel spot caches — one S3 round-trip per envelope, all hubs in power DF.

    Uses the wide-envelope cache key so slider changes don't re-fetch.
    Downstream consumers re-slice the bundle (via ``_to_calendar_daily`` and
    ``reindex(idx_full)``) so returning a wider frame is safe.
    """
    if not _COMMODS:
        return None
    env_start, env_end = _envelope_for(start, end)
    key = (env_start.isoformat(), env_end.isoformat())
    if key in _MARKET_BUNDLE_OD:
        _MARKET_BUNDLE_OD.move_to_end(key)
        return _MARKET_BUNDLE_OD[key]
    try:
        pwr = PricePowerSpot(freq="h")
        pwr.load(from_s3=True, show_metadata=False, start_date=env_start, end_date=env_end)
        gas_o = PriceGasSpot()
        gas_o.load(from_s3=True, show_metadata=False, start_date=env_start, end_date=env_end)
        co2_o = PriceCO2Spot()
        co2_o.load(from_s3=True, show_metadata=False, start_date=env_start, end_date=env_end)
        coal_o = PriceCoalSpot()
        coal_o.load(from_s3=True, show_metadata=False, start_date=env_start, end_date=env_end)
        fx_o = ForexSpot()
        fx_o.load(from_s3=True, show_metadata=False, start_date=env_start, end_date=env_end)
    except Exception as e:
        logger.warning("Price cache load failed: %s", e)
        return None
    bundle = {
        "pwr": getattr(pwr, "data", None),
        "gas": gas_o.data,
        "co2": co2_o.data,
        "coal": coal_o.data,
        "fx": fx_o.data,
    }
    _MARKET_BUNDLE_OD[key] = bundle
    _MARKET_BUNDLE_OD.move_to_end(key)
    while len(_MARKET_BUNDLE_OD) > _MAX_MARKET_BUNDLES:
        _MARKET_BUNDLE_OD.popitem(last=False)
    return bundle


def _column_series_prefer_name(df: pd.DataFrame, *names: str) -> Optional[pd.Series]:
    """Pick column by exact name or substring match (handles MultiIndex columns from forward pivots)."""
    if df is None or df.empty:
        return None
    for n in names:
        if n in df.columns:
            return df[n]
    for n in names:
        nu = n.upper()
        for c in df.columns:
            labels = [c] if not isinstance(c, tuple) else list(c)
            blob = " ".join(str(x).upper() for x in labels)
            if nu in blob:
                return df[c]
    return None


def _to_1d_series(obj: Any) -> pd.Series:
    """Coerce a picked column (which may be a Series or a 1-col DataFrame with MultiIndex cols) to a 1-D Series.

    Multi-column DataFrames are averaged across columns. Strips any column-level MultiIndex
    so downstream arithmetic doesn't try to align on column names.
    """
    if obj is None:
        return pd.Series(dtype=float)
    if isinstance(obj, pd.Series):
        s = obj
    elif isinstance(obj, pd.DataFrame):
        if obj.shape[1] == 0:
            return pd.Series(dtype=float)
        if obj.shape[1] == 1:
            s = obj.iloc[:, 0]
        else:
            s = obj.mean(axis=1)
    else:
        return pd.Series(dtype=float)
    s = pd.Series(pd.to_numeric(s.values, errors="coerce"), index=s.index, dtype=float)
    return s


def _eex_country_for_power_forward(zone: str) -> Optional[str]:
    """EEX ``PricePowerForward`` hub; UK power forward uses MACQ in ``price_report``, not this cache."""
    zu = zone_upper(zone)
    if zu == "UK":
        return None
    return zu


def _last_uk_business_day(ref_date: dt.date | None = None) -> dt.date:
    """Last business day in UK (skipping weekends and bank holidays)."""
    import holidays
    uk_hols = holidays.UnitedKingdom()
    d = ref_date or dt.date.today()
    while d.weekday() >= 5 or d in uk_hols:
        d -= dt.timedelta(days=1)
    return d


def _fetch_macq_uk_power(as_of_date: dt.date | None = None) -> pd.DataFrame:
    """Fetch UK power forward curve from MACQ_FWD_CURVES in Snowflake."""
    from jain_commods.core.interfaces.snowflake.snowflake import SnowFlake
    as_of = as_of_date or _last_uk_business_day()
    as_of_str = as_of.strftime('%Y-%m-%d')
    try:
        sf = SnowFlake(database='COMMOD', schema='PUBLIC')
        cur = sf._conn.cursor()
        cur.execute(f"""
            SELECT DATE, PRICE, GRANULARITY
            FROM COMMOD.PUBLIC.MACQ_FWD_CURVES
            WHERE COMMODITY = 'ELEC_UK.BASELOAD'
              AND AS_OF_DATE = '{as_of_str}'
            ORDER BY DATE
        """)
        df = cur.fetch_pandas_all()
        cur.close()
        sf._conn.close()
    except Exception as e:
        logger.warning("Error fetching MACQ UK power: %s", e)
        return pd.DataFrame()

    if df.empty:
        return pd.DataFrame()

    contracts = []
    for _, row in df.iterrows():
        d = pd.Timestamp(row['DATE'])
        gran = row['GRANULARITY']
        price = float(row['PRICE'])
        if gran == 'D':
            start, end = d, d + pd.Timedelta(days=1)
        elif gran == 'M':
            start = d
            end = d + pd.offsets.MonthEnd(0) + pd.Timedelta(days=1)
        elif gran == 'Q':
            start = d
            end = d + pd.offsets.QuarterEnd(0) + pd.Timedelta(days=1)
        elif gran == 'Y':
            start = d
            end = pd.Timestamp(year=d.year + 1, month=1, day=1)
        else:
            start, end = d, d + pd.Timedelta(days=1)
        contracts.append({
            'commodity': 'Power', 'hub': 'UK',
            'start': start, 'end': end,
            'price': price, 'shape': 'Base',
            'issue_date': pd.Timestamp(as_of),
        })
    return pd.DataFrame(contracts)


def _load_macq_uk_power_forward(as_of_date: dt.date | None = None) -> pd.Series:
    """Build UK forward curve from MACQ (daily granularity)."""
    from jain_commods.core.util.curves import BootstrapBuilder, RedundancyMode
    try:
        df_contracts = _fetch_macq_uk_power(as_of_date)
        if df_contracts.empty:
            return pd.Series(dtype=float)
        builder = BootstrapBuilder(redundancy_mode=RedundancyMode.PRIORITIZE_GRANULARITY)
        builder.add_contracts(df_contracts)
        curve = builder.build_curves(freq='D', commodity='Power')
        if curve.empty:
            return pd.Series(dtype=float)
        if isinstance(curve.index, pd.PeriodIndex):
            curve.index = curve.index.to_timestamp()
        return curve['price']
    except Exception as e:
        logger.warning("Error building UK MACQ forward: %s", e)
        return pd.Series(dtype=float)


def _get_forward_market_bundle(
    zone: str, trade_date: dt.date, start: dt.date, end: dt.date
) -> Optional[dict[str, Any]]:
    """Forward curve caches built with ``ForwardCurveBuilder`` (see ``Price*Forward`` in jain_commods.market)."""
    if not _COMMODS or trade_date is None:
        return None
    zu = zone_upper(zone)
    cc = _eex_country_for_power_forward(zone)
    key = (trade_date.isoformat(), zu)
    if key in _FORWARD_BUNDLE_OD:
        _FORWARD_BUNDLE_OD.move_to_end(key)
        return _FORWARD_BUNDLE_OD[key]

    bundle: dict[str, Any] = {"pwr": None, "gas": None, "co2": None, "coal": None, "fx": None}
    env_start, env_end = _envelope_for(start, end)
    if cc:
        try:
            pwr_o = PricePowerForward(country_code=cc)
            pwr_o.load(
                from_s3=True,
                trade_date=trade_date,
                show_metadata=False,
                start_date=env_start,
                end_date=env_end,
            )
            bundle["pwr"] = getattr(pwr_o, "data", None)
        except Exception as e:
            logger.debug("PricePowerForward (%s) load: %s", cc, e)
    elif zu == "UK":
        try:
            # For UK, use MACQ marks instead of EEX cache
            uk_pwr = _load_macq_uk_power_forward(as_of_date=trade_date)
            if not uk_pwr.empty:
                # Format into a DataFrame with MultiIndex columns to match PricePowerForward.data
                # Level 0: zone ('gb'), Level 1: exchange ('MACQ'), Level 2: currency ('GBP'), Level 3: frequency ('H')
                # Note: Heatmap dashboard expects hourly for 'pwr' bundle then averages to daily.
                # MACQ is daily, so we broadcast to hourly.
                hourly_idx = pd.date_range(uk_pwr.index.min(), uk_pwr.index.max() + pd.Timedelta(hours=23), freq='h')
                hourly_vals = uk_pwr.reindex(hourly_idx.normalize()).values

                cols = pd.MultiIndex.from_tuples(
                    [('gb', 'MACQ', 'GBP', 'H')],
                    names=['zone', 'exchange', 'currency', 'frequency']
                )
                bundle["pwr"] = pd.DataFrame(hourly_vals, index=hourly_idx, columns=cols)
        except Exception as e:
            logger.debug("UK MACQ forward load: %s", e)

    try:
        gas_o = PriceGasForward()
        gas_o.load(from_s3=True, trade_date=trade_date, show_metadata=False)
        g = getattr(gas_o, "data", None)
        if g is not None and not g.empty:
            bundle["gas"] = g  # monthly delivery index — keep full; _sparse_series_to_calendar_daily ffills
        else:
            bundle["gas"] = g
    except Exception as e:
        logger.debug("PriceGasForward load: %s", e)

    try:
        co2_o = PriceCO2Forward()
        co2_o.load(
            from_s3=True,
            trade_date=trade_date,
            show_metadata=False,
            start_date=env_start,
            end_date=env_end,
        )
        bundle["co2"] = getattr(co2_o, "data", None)
    except Exception as e:
        logger.debug("PriceCO2Forward load: %s", e)

    try:
        coal_o = PriceCoalForward()
        coal_o.load(from_s3=True, trade_date=trade_date, show_metadata=False)
        c = getattr(coal_o, "data", None)
        if c is not None and not c.empty:
            bundle["coal"] = c  # monthly delivery index — keep full; _sparse_series_to_calendar_daily ffills
        else:
            bundle["coal"] = c
    except Exception as e:
        logger.debug("PriceCoalForward load: %s", e)

    try:
        fx_o = ForexSpot()
        fx_o.load(from_s3=True, show_metadata=False, start_date=env_start, end_date=env_end)
        bundle["fx"] = fx_o.data
    except Exception as e:
        logger.debug("ForexSpot load: %s", e)

    # Only cache if at least one component loaded successfully — avoids
    # permanently caching a dead bundle when S3 files are temporarily missing.
    if any(v is not None for v in bundle.values()):
        _FORWARD_BUNDLE_OD[key] = bundle
        _FORWARD_BUNDLE_OD.move_to_end(key)
        while len(_FORWARD_BUNDLE_OD) > _MAX_FORWARD_BUNDLES:
            _FORWARD_BUNDLE_OD.popitem(last=False)
    return bundle


def _price_metrics_from_market_dict(
    mb: dict[str, Any], zone: str, start: dt.date, end: dt.date
) -> pd.DataFrame:
    """
    Spot or forward cache bundle → daily Spot / CSS / CDS / Heat rate / TTF / EUA.
    Same cost stack as ``eu_reports/power_price_report/price_report.py`` EU inputs.
    """
    zu = zone_upper(zone)
    zl = zone_lower(zone)
    is_uk = zu == "UK"

    pwr_data = mb.get("pwr")
    gas_raw = mb.get("gas")
    carbon_raw = mb.get("co2")
    coal_raw = mb.get("coal")
    fx_raw = mb.get("fx")

    if gas_raw is None or gas_raw.empty:
        return pd.DataFrame()

    if is_uk:
        gas_s = _to_1d_series(_column_series_prefer_name(gas_raw, "NBP"))
        if gas_s.empty and "NBP" in gas_raw.columns:
            gas_s = _to_1d_series(gas_raw["NBP"])
        if gas_s.empty and not gas_raw.empty:
            gas_s = _to_1d_series(gas_raw.iloc[:, 0])

        # Convert NBP from EUR to GBP if it's in EUR (Platts AALJG00 is EUR/MWh)
        if fx_raw is not None and not fx_raw.empty:
            eur_gbp = _to_1d_series(_column_series_prefer_name(fx_raw, "EUR_GBP", "EUR/GBP"))
            if not eur_gbp.empty and not gas_s.empty:
                eg_d = _to_calendar_daily(eur_gbp)
                gas_d_raw = _to_calendar_daily(gas_s)
                common_idx = gas_d_raw.index.intersection(eg_d.index)
                if len(common_idx) > 0:
                    gas_s = gas_d_raw.reindex(common_idx) * eg_d.reindex(common_idx)

        carb_s = _to_1d_series(_column_series_prefer_name(carbon_raw, "UKA")) if carbon_raw is not None else pd.Series(dtype=float)
        if carb_s.empty and carbon_raw is not None and not carbon_raw.empty:
            carb_s = _to_1d_series(carbon_raw["UKA"] if "UKA" in carbon_raw.columns else carbon_raw.iloc[:, 0])
    else:
        gas_s = _to_1d_series(_column_series_prefer_name(gas_raw, "TTF"))
        if gas_s.empty and "TTF" in gas_raw.columns:
            gas_s = _to_1d_series(gas_raw["TTF"])
        if gas_s.empty and not gas_raw.empty:
            gas_s = _to_1d_series(gas_raw.iloc[:, 0])
        carb_s = _to_1d_series(_column_series_prefer_name(carbon_raw, "EUA")) if carbon_raw is not None else pd.Series(dtype=float)
        if carb_s.empty and carbon_raw is not None and not carbon_raw.empty:
            carb_s = _to_1d_series(carbon_raw["EUA"] if "EUA" in carbon_raw.columns else carbon_raw.iloc[:, 0])

    if carb_s is None or carb_s.empty:
        return pd.DataFrame()

    if coal_raw is not None and not coal_raw.empty:
        coal_s = _to_1d_series(_column_series_prefer_name(coal_raw, "Coal", "API2"))
        if coal_s.empty and "Coal" in coal_raw.columns:
            coal_s = _to_1d_series(coal_raw["Coal"])
        if coal_s.empty:
            coal_s = _to_1d_series(coal_raw.iloc[:, 0])
        usd_eur = _to_1d_series(coal_raw["USD_TO_EUR"]) if "USD_TO_EUR" in coal_raw.columns else pd.Series(0.85, index=coal_raw.index)
    else:
        coal_s = pd.Series(dtype=float)
        usd_eur = pd.Series(dtype=float)

    power_h = (
        _pick_zone_column(pwr_data, zl if not is_uk else "gb")
        if pwr_data is not None and not pwr_data.empty
        else pd.Series(dtype=float)
    )
    power_d = _to_calendar_daily(power_h) if not power_h.empty else pd.Series(dtype=float)

    gas_d = _to_calendar_daily(gas_s) if not isinstance(gas_s, pd.Series) or not gas_s.empty else pd.Series(dtype=float)
    carb_d = _to_calendar_daily(carb_s)
    coal_d = _to_calendar_daily(coal_s) if not coal_s.empty else pd.Series(dtype=float)
    usd_d = _to_calendar_daily(usd_eur) if not usd_eur.empty else pd.Series(dtype=float)

    # Full delivery calendar — never derive rows only from sparse monthly forward indices
    # (union of month-starts omits May 2–15 if daily power failed to align).
    idx_full = pd.date_range(pd.Timestamp(start), pd.Timestamp(end), freq="D")

    if not power_d.empty:
        pix = pd.to_datetime(power_d.index)
        if pix.tz is not None:
            pix = pix.tz_convert("Europe/Paris").tz_localize(None)
        power_d = power_d.copy()
        power_d.index = pix.normalize()
        power_d = power_d.groupby(level=0).mean()

    df = pd.DataFrame(index=idx_full)
    df["Power"] = power_d.reindex(idx_full)
    df["Gas"] = _sparse_series_to_calendar_daily(gas_d, idx_full)
    df["Carbon"] = _sparse_series_to_calendar_daily(carb_d, idx_full)
    if not coal_d.empty:
        df["Coal"] = _sparse_series_to_calendar_daily(coal_d, idx_full)
    else:
        df["Coal"] = np.nan
    if not usd_d.empty:
        df["USD_TO_EUR"] = _sparse_series_to_calendar_daily(usd_d, idx_full)
    else:
        df["USD_TO_EUR"] = 0.85

    df[["Gas", "Carbon", "Coal", "USD_TO_EUR"]] = df[["Gas", "Carbon", "Coal", "USD_TO_EUR"]].ffill(limit=62).bfill(limit=62)

    if is_uk:
        df["Carbon_Total"] = df["Carbon"] + 18.0
        # For UK, we need USD to GBP for coal cost since we are working in GBP
        usd_gbp_built = False
        if fx_raw is not None and not fx_raw.empty:
            eur_usd = _to_1d_series(_column_series_prefer_name(fx_raw, "EUR_USD", "EUR/USD"))
            eur_gbp = _to_1d_series(_column_series_prefer_name(fx_raw, "EUR_GBP", "EUR/GBP"))
            if not eur_usd.empty and not eur_gbp.empty:
                eu_d = _to_calendar_daily(eur_usd)
                eg_d = _to_calendar_daily(eur_gbp)
                common = eu_d.index.intersection(eg_d.index)
                if len(common) > 0:
                    usd_gbp = (1.0 / eu_d.reindex(common)) * eg_d.reindex(common)
                    df["USD_TO_LOCAL"] = _sparse_series_to_calendar_daily(usd_gbp, idx_full).ffill(limit=62).bfill(limit=62)
                    usd_gbp_built = True
        if not usd_gbp_built:
            df["USD_TO_LOCAL"] = df["USD_TO_EUR"] * 0.85  # rough fallback (EUR→GBP)
    else:
        df["Carbon_Total"] = df["Carbon"]
        df["USD_TO_LOCAL"] = df["USD_TO_EUR"]

    df["Carbon_Total"] = df["Carbon_Total"].ffill(limit=62).bfill(limit=62)

    gas_cost = (df["Gas"] / GAS_EFF) + (GAS_EMISSIONS / GAS_EFF) * df["Carbon_Total"]
    coal_local_mwh = df["Coal"] * df["USD_TO_LOCAL"] / API2_TO_MWH
    coal_cost = (coal_local_mwh / COAL_EFF) + (COAL_EMISSIONS / COAL_EFF) * df["Carbon_Total"]

    out = pd.DataFrame(index=df.index)
    out["Spot"] = df["Power"]
    out["CSS"] = df["Power"] - gas_cost
    out["CDS"] = df["Power"] - coal_cost
    denom = df["Gas"] + GAS_EMISSIONS * df["Carbon_Total"]
    out["Heat rate"] = df["Power"] / denom.replace(0, np.nan)
    
    if is_uk:
        out["NBP"] = df["Gas"]
        out["UKA"] = df["Carbon"]
    else:
        out["TTF"] = df["Gas"]
        out["EUA"] = df["Carbon"]

    return out


def _merge_spot_forward_price_metrics(
    out_spot: pd.DataFrame, out_fwd: pd.DataFrame
) -> pd.DataFrame:
    """Prefer realised spot stack where defined; extend with forward-implied metrics for missing delivery days."""
    if out_fwd is None or out_fwd.empty:
        return out_spot
    cols = list(out_spot.columns)
    idx = out_spot.index.union(out_fwd.index).sort_values()
    left = out_spot.reindex(idx)
    right = out_fwd.reindex(idx)
    out = pd.DataFrame(index=idx)
    for c in cols:
        out[c] = left[c].where(left[c].notna(), right[c])
    return out


def compute_price_metrics_daily(
    zone: str,
    start: dt.date,
    end: dt.date,
    forward_trade_date: Optional[dt.date] = None,
) -> pd.DataFrame:
    """
    Daily Spot, CSS, CDS, Heat rate, TTF, EUA — spot caches plus optional forward curves.

    Forward leg uses ``PricePowerForward`` / ``PriceGasForward`` / ``PriceCO2Forward`` / ``PriceCoalForward``
    (``ForwardCurveBuilder`` in jain_commods), analogous to ``price_report.DataLoader.build_forward_curves``.
    Rows where spot inputs are missing are filled from the forward curve set **as of** ``forward_trade_date``.

    Callers should pass the **prior calendar day** to the forecast ``issue_date`` when they want latest
    settled forward curves (S3 folder ``YYYYMMDD`` matches ``forward_trade_date``).
    """
    cols = ["Spot", "CSS", "CDS", "Heat rate", "TTF", "EUA", "NBP", "UKA"]
    idx_full = pd.date_range(start, end, freq="D")
    empty = pd.DataFrame(index=idx_full, columns=cols, dtype=float)
    if not _COMMODS:
        return empty

    mb_spot = _get_market_bundle(start, end)
    out_spot = empty.copy()
    if mb_spot is not None:
        tmp = _price_metrics_from_market_dict(mb_spot, zone, start, end)
        if tmp is not None and not tmp.empty:
            out_spot = tmp.reindex(idx_full)

    out = out_spot
    if forward_trade_date is not None:
        mf = _get_forward_market_bundle(zone, forward_trade_date, start, end)
        if mf is not None:
            tmpf = _price_metrics_from_market_dict(mf, zone, start, end)
            if tmpf is not None and not tmpf.empty:
                out = _merge_spot_forward_price_metrics(out_spot, tmpf)

    return out.reindex(idx_full)


def build_balance_matrix(
    zone: str,
    history_days: int = 21,
    forward_days: int = 15,
    split_date: Optional[dt.date] = None,
    issue_date: Optional[dt.date] = None,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Rows = metrics (Prices block then Fundamentals block); columns = calendar dates.

    Fundamentals include **Net Export** from ``NetExportDayAhead`` (zonal actual cache, MW),
    same historical handling as coal/lignite/gas (no ST forecast stitch).

    The HTML table view transposes this to **dates as rows** and **Price | Fundamental × metric as columns**
    (see ``heatmap_balance_table._reshape_metrics_by_date_to_display``).

    split_date: delivery dates ``>= split_date`` use ST forecast where applicable;
        earlier dates use backcast (or actual gen for nuclear / thermal).

    Calendar **today** (local ``date.today()``): for stitched fundamentals, **today and future**
    delivery dates use **short-term forecasts only** (no same-day actual/backcast). Actual-only
    series (coal/lignite/gas/net export DA) are **blank from today onward**—there is no ST forecast
    for those in this dashboard.
    """
    meta: Dict[str, Any] = {}
    if not _COMMODS:
        return pd.DataFrame(), meta

    split_date = split_date or dt.date.today()
    issue_date = issue_date or split_date
    today = dt.date.today()
    end = split_date + dt.timedelta(days=forward_days)
    start = split_date - dt.timedelta(days=history_days)

    zl = zone_lower(zone)
    cal = pd.date_range(start, end, freq="D")

    # --- Fundamentals ---
    rsl_b = _load_actual_curve(ResLoadBackcast, zl, start, end)
    rsl_f = _load_forecast_curve(ResLoadFcstST, zl, issue_date, start, end)
    cons_b = _load_actual_curve(ConsBackcast, zl, start, end)
    cons_f = _load_forecast_curve(ConsFcstST, zl, issue_date, start, end)
    w_b = _load_actual_curve(GenWindBackcast, zl, start, end)
    w_f = _load_forecast_curve(GenWindFcstST, zl, issue_date, start, end)
    s_b = _load_actual_curve(GenSolarBackcast, zl, start, end)
    s_f = _load_forecast_curve(GenSolarFcstST, zl, issue_date, start, end)
    hydro_a = _load_actual_curve(GenHydroTotalActual, zl, start, end)
    hydro_f = _load_forecast_curve(GenHydroTotalFcst, zl, issue_date, start, end)
    nuc_a = _load_actual_curve(GenNuclearActual, zl, start, end)
    nuc_f = _load_forecast_curve(GenNuclearFcstST, zl, issue_date, start, end)

    coal = _to_calendar_daily(_load_actual_curve(GenCoalActual, zl, start, end)).reindex(cal)
    lig = _to_calendar_daily(_load_actual_curve(GenLigniteActual, zl, start, end)).reindex(cal)
    gas_g = _to_calendar_daily(_load_actual_curve(GenGasActual, zl, start, end)).reindex(cal)
    net_ex_da = _to_calendar_daily(_load_actual_curve(NetExportDayAhead, zl, start, end)).reindex(cal)

    # Actual-only generation / exchange: never show incomplete same-day actuals — hide today onward (no ST fcst).
    _mask_from_today = cal.normalize() >= pd.Timestamp(today).normalize()
    coal = coal.mask(_mask_from_today)
    lig = lig.mask(_mask_from_today)
    gas_g = gas_g.mask(_mask_from_today)
    net_ex_da = net_ex_da.mask(_mask_from_today)

    fund = pd.DataFrame(index=cal)
    fund[RESIDUAL_LOAD_ROW] = _stitch_daily_forecast_from_today(rsl_b, rsl_f, split_date, cal, today)
    fund["Consumption"] = _stitch_daily_forecast_from_today(cons_b, cons_f, split_date, cal, today)
    fund["Solar"] = _stitch_daily_forecast_from_today(s_b, s_f, split_date, cal, today)
    fund["Wind"] = _stitch_daily_forecast_from_today(w_b, w_f, split_date, cal, today)
    fund["Hydro total"] = _stitch_nuclear(
        hydro_a,
        hydro_f,
        split_date,
        cal,
        today,
        to_daily=_to_calendar_daily_hydro_mwh_to_avg_mw,
    )
    fund["Nuclear"] = _stitch_nuclear(nuc_a, nuc_f, split_date, cal, today)
    # Missing / empty nuclear actual (common for zones with no fleet) yields NaN here; subtraction would
    # wipe ResL derivatives. Treat NaN nuclear as 0 for residual definitions only — Nuclear column unchanged.
    _nuke_for_res = fund["Nuclear"].fillna(0)
    fund[RESIDUAL_MINUS_NUKE] = fund[RESIDUAL_LOAD_ROW] - _nuke_for_res
    fund[RESIDUAL_MINUS_NUKE_HYD] = fund[RESIDUAL_MINUS_NUKE] - fund["Hydro total"]
    fund["Coal gen"] = coal
    fund["Lignite gen"] = lig
    fund["Gas gen"] = gas_g
    fund["Net Export"] = net_ex_da

    # Forward caches are keyed by trade/settlement date; use day before forecast issue for latest settled curves.
    forward_trade_date = issue_date - dt.timedelta(days=1)
    prices = compute_price_metrics_daily(zone, start, end, forward_trade_date=forward_trade_date)
    prices = prices.reindex(cal)

    # Column order: prices rows first
    parts = []
    for row in PRICE_ROWS:
        colname = "Heat rate" if row == "Heat rate" else row
        if colname not in prices.columns:
            parts.append(pd.Series(np.nan, index=cal, name=row))
        else:
            parts.append(prices[colname].rename(row))
    for row in FUND_ROWS:
        if row in fund.columns:
            parts.append(fund[row].rename(row))
        else:
            parts.append(pd.Series(np.nan, index=cal, name=row))

    mat = pd.concat(parts, axis=1).T
    meta["split_date"] = split_date.isoformat()
    meta["issue_date"] = issue_date.isoformat()
    meta["forward_curve_trade_date"] = forward_trade_date.isoformat()
    meta["calendar_today"] = today.isoformat()
    meta["zone"] = zone_upper(zone)
    return mat, meta


def matrix_to_heatmap_z(mat: pd.DataFrame) -> Tuple[np.ndarray, List[str], List[str], np.ndarray]:
    """Convert matrix to z values with row-wise robust scaling for colour."""
    if mat.empty:
        return np.zeros((0, 0)), [], [], np.zeros((0, 0))
    arr = mat.values.astype(float)
    text = np.where(np.isfinite(arr), np.round(arr, 2).astype(str), "")
    return arr, list(mat.index), [d.strftime("%Y-%m-%d") for d in mat.columns], text
