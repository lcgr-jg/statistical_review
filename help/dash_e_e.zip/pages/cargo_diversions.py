"""LNG — Cargo Diversions page registrar."""
from __future__ import annotations

import dash

from core.cargo_diversions import callbacks as _callbacks  # noqa: F401
from core.cargo_diversions.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.cargo_diversions.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)


def layout(**_kwargs):
    return build_layout()
