"""
LNG — Netbacks page registrar.

Implementation lives in ``core.lng_netbacks``:
    * calc      -- freight + netbacks + occupancy (frame in / frame out)
    * data      -- ICE/Platts cache loader + as-of slicing
    * charts    -- Plotly snapshot / history / occupancy figures
    * tables    -- JKM/TFU structure table + assumptions
    * layout    -- ``build_layout()``
    * callbacks -- registered on import
"""
from __future__ import annotations

import dash

from core.lng_netbacks import callbacks as _callbacks  # noqa: F401
from core.lng_netbacks.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.lng_netbacks.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)


def layout(**_kwargs):
    """Rebuilt on every visit so the date picker max tracks the latest settle."""
    return build_layout()
