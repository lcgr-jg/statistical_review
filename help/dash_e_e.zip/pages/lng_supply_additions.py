"""
LNG — Supply Additions page registrar.

Implementation lives in ``core.lng_supply_additions``:
    * schema    -- one row shape for every vendor, filters, name matching
    * data      -- dated CSV snapshots (Goldman, Energy Aspects) + live payload cache
    * vendors   -- Platts API / Snowflake
    * charts    -- country, vendor, cumulative, and startup timeline
    * layout    -- ``build_layout()``
    * callbacks -- registered on import
"""
from __future__ import annotations

import dash

from core.lng_supply_additions import callbacks as _callbacks  # noqa: F401
from core.lng_supply_additions.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.lng_supply_additions.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
