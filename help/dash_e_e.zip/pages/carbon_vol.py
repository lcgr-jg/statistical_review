"""
Carbon Vol Monitor — Dash page registrar.

The dashboard itself is a self-contained Plotly HTML file built by the
eu_carbon repo's scheduled vol-monitor job and pushed here via
``POST /api/carbon/upload/vol`` (see ``core.carbon_static``). This page just
frames the latest pushed file.
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/vol",
    name=CARBON_PAGES["vol"],
    title="Carbon Vol Monitor | JG Power Dashboard",
    order=60,
)

layout = iframe_page_layout("vol")
