"""
Fundamentals Dashboard - Multi-page integration
================================================
Power generation, availability, and weather analytics.
Sub-pages: Home, Availability, Generation vs Availability, Weather Forecast

Styled to match the Fuel Switching dashboard colour scheme.
"""
import dash
from dash import html, dcc, Input, Output, callback
import logging
import os

from portal_pages.fundamentals.styles import (
    COLORS, FUNDAMENTALS_CSS, REFRESH_BTN_STYLE, STATUS_BADGE_OK,
)

logger = logging.getLogger(__name__)

# Register as Dash page (only when running in multi-page mode)
if __name__ != '__main__':
    dash.register_page(
        __name__,
        path='/power/fundamentals',
        name='Fundamental Overview',
        title='Fundamental Overview | JG Power Dashboard',
        order=2,
    )

# ---------------------------------------------------------------------------
# Lazy imports & data loading - only triggered when user navigates here
# ---------------------------------------------------------------------------
_data_handler = None
_sub_pages_loaded = False
_load_attempted = False
_sub_page_modules = {}
_IS_DEV = os.getenv("DASH_ENV", "local") == "local"


def _get_data_handler():
    """Return singleton DataHandler without forcing immediate data load."""
    global _data_handler
    if _data_handler is None:
        from portal_pages.fundamentals.data_handler import DataHandler
        _data_handler = DataHandler(defer_loading=True)
    return _data_handler


def _ensure_loaded():
    """Lazy-load the data handler and sub-page modules on first access."""
    global _data_handler, _sub_pages_loaded, _load_attempted, _sub_page_modules
    if _sub_pages_loaded or _load_attempted:
        return

    _load_attempted = True

    try:
        # Only create DataHandler once; actual data load remains lazy on first page access.
        _data_handler = _get_data_handler()
        if not _data_handler.is_ready:
            _data_handler.ready()

        from portal_pages.fundamentals.availability import (
            get_layout as get_availability_layout,
        )
        from portal_pages.fundamentals.generation_vs_availability import (
            get_layout as get_generation_layout,
        )
        from portal_pages.fundamentals.weather_forecast import (
            get_layout as get_weather_forecast_layout,
        )
        from portal_pages.fundamentals.forecast_comparison import (
            get_layout as get_forecast_comparison_layout,
        )
        from portal_pages.fundamentals.sci_dashboard import (
            get_layout as get_sci_layout,
        )
        from portal_pages.fundamentals.weather_probability import (
            get_layout as get_weather_probability_layout,
        )
        from portal_pages.fundamentals.met_run_deltas import (
            get_layout as get_met_run_deltas_layout,
        )

        _sub_page_modules['availability'] = get_availability_layout
        _sub_page_modules['generation'] = get_generation_layout
        _sub_page_modules['weather'] = get_weather_forecast_layout
        _sub_page_modules['forecast_comparison'] = get_forecast_comparison_layout
        _sub_page_modules['sci'] = get_sci_layout
        _sub_page_modules['weather_probability'] = get_weather_probability_layout
        _sub_page_modules['met_run_deltas'] = get_met_run_deltas_layout

        _sub_pages_loaded = True
        logger.info("Fundamentals sub-pages loaded successfully")
    except Exception as e:
        logger.error(f"Failed to load fundamentals sub-pages: {e}")


def initialize_fundamentals_callbacks(app):
    """Register all fundamentals callbacks once at startup.

    Callback wiring is deterministic; data remains lazy-loaded via `_ensure_loaded()`.
    """
    data_handler = _get_data_handler()

    from portal_pages.fundamentals.availability import register_availability_callbacks
    from portal_pages.fundamentals.generation_vs_availability import register_generation_callbacks
    from portal_pages.fundamentals.weather_forecast import register_weather_forecast_callbacks
    from portal_pages.fundamentals.forecast_comparison import register_forecast_comparison_callbacks
    from portal_pages.fundamentals.sci_dashboard import register_sci_callbacks
    from portal_pages.fundamentals.weather_probability import register_weather_probability_callbacks
    from portal_pages.fundamentals.met_run_deltas import register_met_run_deltas_callbacks

    cb_keys = set(app.callback_map.keys())
    existing = {
        "availability": any("avail-charts-container.children" in k for k in cb_keys),
        "generation": any("gen-charts-container.children" in k for k in cb_keys),
        "weather": any("weather-forecast-output.children" in k for k in cb_keys),
        "forecast_comparison": any("fcmp-charts-container.children" in k for k in cb_keys),
        "sci": any("sci-regime-map.figure" in k for k in cb_keys),
        "weather_probability": any("wprob-content.children" in k for k in cb_keys),
        "met_run_deltas": any("mrd-charts-container.children" in k for k in cb_keys),
    }

    if any(existing.values()):
        msg = (
            "Fundamentals callbacks already present before startup registration. "
            f"existing={existing}"
        )
        if _IS_DEV:
            raise RuntimeError(msg)
        logger.warning(msg)
        return

    register_availability_callbacks(app, data_handler)
    register_generation_callbacks(app, data_handler)
    register_weather_forecast_callbacks(app, data_handler=None)
    register_forecast_comparison_callbacks(app, data_handler=None)
    register_sci_callbacks(app)
    register_weather_probability_callbacks(app, data_handler=None)
    register_met_run_deltas_callbacks(app, data_handler=None)

    logger.info("Fundamentals callbacks initialized at startup")


def load_fundamentals_data():
    """Loader function for the central DataScheduler.

    Initialises the DataHandler and returns it.  Called on a cron schedule
    and on first page access.
    """
    _ensure_loaded()
    return _data_handler


# ---------------------------------------------------------------------------
# Sub-page definitions
# ---------------------------------------------------------------------------
SUB_PAGES = [
    {'key': 'weather',             'label': 'Forecast Monitor',           'icon': '\u26A1'},
    {'key': 'met_run_deltas',      'label': 'Met Run Deltas',             'icon': '\u21C5'},
    {'key': 'weather_probability', 'label': 'Threshold Probability',      'icon': '\u25A6'},
    {'key': 'forecast_comparison', 'label': 'Forecast Comparison',        'icon': '\u2248'},
    {'key': 'sci',                 'label': 'Scenario Impact',            'icon': '\u2042'},
    {'key': 'availability',        'label': 'Availability',              'icon': '\u26A1'},
    {'key': 'generation',          'label': 'Generation vs Availability','icon': '\u2191'},
]

# ---------------------------------------------------------------------------
# Shared inline styles
# ---------------------------------------------------------------------------
_HEADER_STYLE = {
    'background': f'linear-gradient(135deg, {COLORS["header_bg"]} 0%, #3a4f5a 100%)',
    'padding': '28px 32px 20px',
    'boxShadow': '0 2px 8px rgba(0,0,0,0.12)',
}
_TITLE_STYLE = {
    'color': COLORS['header_text'],
    'margin': '0',
    'fontSize': '22px',
    'fontWeight': '600',
    'fontFamily': 'Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif',
    'letterSpacing': '0.3px',
}
_SUBTITLE_STYLE = {
    'color': COLORS['header_sub'],
    'margin': '4px 0 0 0',
    'fontSize': '13px',
    'fontFamily': 'Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif',
}
_TAB_BAR_STYLE = {
    'display': 'flex',
    'gap': '0',
    'borderBottom': f'2px solid {COLORS["border"]}',
    'backgroundColor': COLORS['card_bg'],
    'padding': '0 24px',
    'boxShadow': '0 1px 2px rgba(0,0,0,0.03)',
}
_TAB_BTN_STYLE = {
    'padding': '14px 22px',
    'border': 'none',
    'borderBottom': '3px solid transparent',
    'backgroundColor': 'transparent',
    'color': COLORS['text_secondary'],
    'fontSize': '13px',
    'fontWeight': '500',
    'cursor': 'pointer',
    'transition': 'all 0.2s',
    'fontFamily': 'Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif',
    'letterSpacing': '0.2px',
    'whiteSpace': 'nowrap',
}

# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
layout = html.Div(
    style={
        'minHeight': '100vh',
        'backgroundColor': COLORS['background'],
    },
    children=[
        dcc.Store(id='fundamentals-active-tab', data='weather'),
        dcc.Store(id='fcst-toast-store', data=[]),

        # -------- Sub-page tab bar --------
        html.Div(
            style=_TAB_BAR_STYLE,
            children=[
                html.Button(
                    f"{sp['icon']}  {sp['label']}",
                    id={'type': 'fundamentals-tab-btn', 'index': sp['key']},
                    n_clicks=0,
                    style=_TAB_BTN_STYLE,
                )
                for sp in SUB_PAGES
            ],
        ),

        # -------- Content (no loading wrapper to avoid full-page spinners) --------
        html.Div(
            id='fundamentals-sub-content',
            style={
                'minHeight': '500px',
                'padding': '24px 28px',
            },
        ),
    ],
)


# ---------------------------------------------------------------------------
# Callback: switch sub-pages
# ---------------------------------------------------------------------------
@callback(
    Output('fundamentals-sub-content', 'children'),
    [Input({'type': 'fundamentals-tab-btn', 'index': sp['key']}, 'n_clicks')
     for sp in SUB_PAGES],
    prevent_initial_call=False,
)
def switch_fundamentals_tab(*n_clicks):
    ctx = dash.callback_context
    triggered_id = 'weather'  # default to Forecast Monitor

    if ctx.triggered and ctx.triggered[0]['prop_id'] != '.':
        import json
        prop_id = ctx.triggered[0]['prop_id']
        try:
            btn_id = json.loads(prop_id.rsplit('.', 1)[0])
            triggered_id = btn_id.get('index', 'weather')
        except (json.JSONDecodeError, KeyError):
            pass

    # Lazy-load data & sub-pages (first page visit triggers S3 loads)
    _ensure_loaded()
    if not _sub_pages_loaded or _data_handler is None:
        return html.Div(
            style={
                'padding': '80px 40px',
                'textAlign': 'center',
            },
            children=[
                html.Div(
                    style={
                        'display': 'inline-block',
                        'padding': '40px 60px',
                        'backgroundColor': COLORS['card_bg'],
                        'borderRadius': '16px',
                        'border': f'1px solid {COLORS["border"]}',
                        'boxShadow': '0 2px 12px rgba(0,0,0,0.06)',
                    },
                    children=[
                        html.H3(
                            'Loading Fundamentals Data\u2026',
                            style={
                                'color': COLORS['accent'],
                                'fontWeight': '600',
                                'marginBottom': '12px',
                            },
                        ),
                        html.P(
                            'Data is being loaded from S3 cache. This may take a moment on first load.',
                            style={'color': COLORS['text_muted'], 'fontSize': '14px'},
                        ),
                    ],
                ),
            ],
        )

    try:
        get_layout_fn = _sub_page_modules.get(
            triggered_id, _sub_page_modules.get('weather')
        )
        return get_layout_fn(_data_handler)
    except Exception as e:
        logger.error(f"Error rendering fundamentals sub-page '{triggered_id}': {e}")
        return html.Div(
            style={'padding': '40px'},
            children=[
                html.H3(
                    f'Error loading {triggered_id}',
                    style={'color': COLORS['danger'], 'marginBottom': '12px'},
                ),
                html.Pre(
                    str(e),
                    style={
                        'backgroundColor': COLORS['card_bg_alt'],
                        'padding': '16px',
                        'borderRadius': '8px',
                        'fontSize': '13px',
                        'color': COLORS['text_secondary'],
                        'whiteSpace': 'pre-wrap',
                        'border': f'1px solid {COLORS["border"]}',
                    },
                ),
            ],
        )


