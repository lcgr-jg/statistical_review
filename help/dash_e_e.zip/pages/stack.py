"""
Stack Dashboard — Multi-page integration
=========================================
Power stack model outputs: plant stack, dispatch, prices, assumptions,
benchmark, generation benchmark, and run comparison.

Callbacks for every sub-page are registered at module import time — same
requirement as pages/prices.py: Dash only sees callbacks that exist before the
client fetches /_dash-dependencies.

Stack pages don't take a ``data`` dict — each page's callbacks lazily hit
Postgres / Snowflake via the singletons in portal_pages.stack.utils.db, cached
in-process via portal_pages.stack.utils.cache.
"""
import dash
from dash import html, dcc, Input, Output, callback
import logging

logger = logging.getLogger(__name__)

if __name__ != '__main__':
    dash.register_page(
        __name__,
        path='/power/stack',
        name='Stack Model',
        title='Stack Model | JG Power Dashboard',
        order=5,
    )

# ---------------------------------------------------------------------------
# Sub-page layouts & callback registration (eager).
# ---------------------------------------------------------------------------
_sub_page_layouts: dict = {}


def _register_all_callbacks():
    """Register every stack sub-page's callbacks eagerly at import time."""
    try:
        current_app = dash.get_app()

        from portal_pages.stack.pages.plant_stack import (
            layout as plant_stack_layout,
            register_callbacks as reg_plant_stack,
        )
        from portal_pages.stack.pages.dispatch import (
            layout as dispatch_layout,
            register_callbacks as reg_dispatch,
        )
        from portal_pages.stack.pages.prices import (
            layout as prices_layout,
            register_callbacks as reg_prices,
        )
        from portal_pages.stack.pages.assumptions import (
            layout as assumptions_layout,
            register_callbacks as reg_assumptions,
        )
        from portal_pages.stack.pages.benchmark import (
            layout as benchmark_layout,
            register_callbacks as reg_benchmark,
        )
        from portal_pages.stack.pages.gen_benchmark import (
            layout as gen_benchmark_layout,
            register_callbacks as reg_gen_benchmark,
        )
        from portal_pages.stack.pages.run_comparison import (
            get_layout as run_comparison_layout,
            register_stack_prices_callbacks as reg_run_comparison,
        )

        reg_plant_stack(current_app)
        reg_dispatch(current_app)
        reg_prices(current_app)
        reg_assumptions(current_app)
        reg_benchmark(current_app)
        reg_gen_benchmark(current_app)
        reg_run_comparison(current_app)

        _sub_page_layouts['plant_stack'] = plant_stack_layout
        _sub_page_layouts['dispatch'] = dispatch_layout
        _sub_page_layouts['prices'] = prices_layout
        _sub_page_layouts['assumptions'] = assumptions_layout
        _sub_page_layouts['benchmark'] = benchmark_layout
        _sub_page_layouts['gen_benchmark'] = gen_benchmark_layout
        _sub_page_layouts['run_comparison'] = run_comparison_layout

        logger.info("Stack sub-page callbacks registered (%d pages)", len(_sub_page_layouts))
    except Exception as e:
        logger.error("Failed to register stack callbacks: %s", e)
        import traceback
        traceback.print_exc()


if __name__ != '__main__':
    _register_all_callbacks()


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
SUB_PAGES = [
    {'key': 'plant_stack',    'label': 'Plant Stack',    'icon': '🏭'},
    {'key': 'dispatch',       'label': 'Dispatch',       'icon': '⚡'},
    {'key': 'prices',         'label': 'Prices',         'icon': '💶'},
    {'key': 'assumptions',    'label': 'Assumptions',    'icon': '📋'},
    {'key': 'benchmark',      'label': 'Benchmark',      'icon': '📐'},
    {'key': 'gen_benchmark',  'label': 'Gen Benchmark',  'icon': '⚙️'},
    {'key': 'run_comparison', 'label': 'Run Comparison', 'icon': '🔄'},
]

layout = html.Div([
    dcc.Store(id='stack-active-tab', data='plant_stack'),

    # Sub-page tab bar (same visual treatment as pages/prices.py)
    html.Div(
        style={
            'display': 'flex',
            'gap': '0',
            'borderBottom': '2px solid #2c3e50',
            'backgroundColor': '#f8f9fa',
            'padding': '0 20px',
        },
        children=[
            html.Button(
                f"{sp['icon']}  {sp['label']}",
                id={'type': 'stack-tab-btn', 'index': sp['key']},
                n_clicks=0,
                style={
                    'padding': '14px 24px',
                    'border': 'none',
                    'borderBottom': '3px solid transparent',
                    'backgroundColor': 'transparent',
                    'color': '#495057',
                    'fontSize': '14px',
                    'fontWeight': '500',
                    'cursor': 'pointer',
                    'transition': 'all 0.2s',
                    'fontFamily': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                },
            )
            for sp in SUB_PAGES
        ],
    ),

    dcc.Loading(
        id='stack-loading',
        type='circle',
        color='#2c3e50',
        children=[html.Div(id='stack-sub-content', style={'minHeight': '400px'})],
    ),
])


@callback(
    Output('stack-sub-content', 'children'),
    [Input({'type': 'stack-tab-btn', 'index': sp['key']}, 'n_clicks') for sp in SUB_PAGES],
    prevent_initial_call=False,
)
def switch_stack_tab(*n_clicks):
    ctx = dash.callback_context
    triggered_id = 'plant_stack'

    if ctx.triggered and ctx.triggered[0]['prop_id'] != '.':
        import json
        prop_id = ctx.triggered[0]['prop_id']
        try:
            btn_id = json.loads(prop_id.rsplit('.', 1)[0])
            triggered_id = btn_id.get('index', 'plant_stack')
        except (json.JSONDecodeError, KeyError):
            pass

    layout_fn = _sub_page_layouts.get(triggered_id) or _sub_page_layouts.get('plant_stack')
    if layout_fn is None:
        return html.Div(
            "Stack sub-page modules not loaded. Please refresh.",
            style={'padding': '40px', 'color': '#e74c3c'},
        )
    try:
        return layout_fn() if callable(layout_fn) else layout_fn
    except Exception as e:
        logger.error("Error rendering stack sub-page '%s': %s", triggered_id, e)
        return html.Div(
            style={'padding': '40px'},
            children=[
                html.H3(f"⚠️ Error loading {triggered_id}", style={'color': '#e74c3c'}),
                html.Pre(
                    str(e),
                    style={
                        'backgroundColor': '#f8f9fa',
                        'padding': '15px',
                        'borderRadius': '6px',
                        'fontSize': '13px',
                        'color': '#495057',
                        'whiteSpace': 'pre-wrap',
                    },
                ),
            ],
        )
