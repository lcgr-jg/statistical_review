"""
Carbon Positioning (ICE COT) — Dash page registrar.

Self-contained Plotly HTML built by eu_carbon's ICE COT poll job and pushed
via ``POST /api/carbon/upload/positioning`` (see ``core.carbon_static``).
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/positioning",
    name=CARBON_PAGES["positioning"],
    title="Carbon Positioning | JG Power Dashboard",
    order=64,
)

layout = iframe_page_layout("positioning")
