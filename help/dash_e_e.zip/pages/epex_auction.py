"""
EPEX Day-Ahead Spot Price Dashboard

Fetches Day Ahead power prices from PricePowerSpot cache
and displays an interactive styled table with regional grouping.
"""

import hashlib
import io

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import pandas as pd
import datetime as dt
import logging
from typing import Dict, List, Optional, Any

from core.cache import cached_result, dashboard_cache
from core.data_freshness import tracker

# Setup logging
logger = logging.getLogger(__name__)

# =============================================================================
# Page Registration
# =============================================================================
dash.register_page(
    __name__,
    path='/power/epex_auction',
    name='EPEX Day-Ahead Prices',
    title='EPEX Auction | JG Power Dashboard',
    order=4,
)

# =============================================================================
# Configuration
# =============================================================================
# Regions ordered left-to-right as they appear in the table
from collections import OrderedDict

REGIONS = OrderedDict([
    ("CWE", ["DE", "FR", "NL", "BE", "AT", "CH"]),
    ("Iberia", ["ES", "PT"]),
    ("Italy", ["IT"]),
    ("UK+IE", ["UK", "IE"]),
    ("CEE", ["PL", "CZ", "HU", "SK"]),
    ("SEE", ["RO", "GR", "RS", "BG", "HR", "SI"]),
    ("Nordics", ["SE1", "SE2", "SE3", "SE4", "DK1", "DK2", "FI", "NO1", "NO2", "NO3", "NO4", "NO5"]),
])

# Flatten all zones for download
ALL_ZONES = [zone for zones in REGIONS.values() for zone in zones]

# Zone display name mappings
ZONE_DISPLAY = {
    "DE_LU": "DE", "DE-LU": "DE",
    "GB": "UK",
    "SE_1": "SE1", "SE_2": "SE2", "SE_3": "SE3", "SE_4": "SE4",
    "NO_1": "NO1", "NO_2": "NO2", "NO_3": "NO3", "NO_4": "NO4", "NO_5": "NO5",
    "DK_1": "DK1", "DK_2": "DK2",
}

# Colors for styling (shared)
from core.styles import COLORS


# =============================================================================
# Data Loading
# =============================================================================
class SpotPriceDataLoader:
    """Loads spot price data from PricePowerSpot cache."""
    
    def __init__(self):
        self.regions = REGIONS
        self.all_zones = ALL_ZONES
    
    @staticmethod
    def _normalize_zone_name(zone: str) -> str:
        """Convert API zone names to display names."""
        zone_upper = zone.upper().replace('-', '_')
        return ZONE_DISPLAY.get(zone_upper, zone_upper.replace('_', ''))
    
    def __repr__(self):
        """Ensure consistent string representation for caching keys."""
        return "SpotPriceDataLoader"
    
    @staticmethod
    def _to_download_zone(zone: str) -> str:
        """Normalize display zone code to PricePowerSpot download code."""
        z = zone.strip().lower()
        if z == "uk":
            return "gb"
        return z

    @staticmethod
    def _day_ahead_window(anchor_date: dt.date) -> tuple[dt.date, dt.date]:
        """Bounded day-ahead window with 90 days of history."""
        start_date = anchor_date - dt.timedelta(days=90)
        end_date = anchor_date + dt.timedelta(days=2)
        return start_date, end_date

    def fetch_prices(self) -> pd.DataFrame:
        """Read latest EPEX data from shared dashboard cache."""
        cached = dashboard_cache.get_data("epex_spot")
        if cached is not None:
            return cached
        return self.fetch_prices_for_cache(dt.date.today())

    @cached_result(ttl_seconds=900, key_prefix="epex_spot_prices")
    def fetch_prices_for_cache(self, target_date: dt.date) -> pd.DataFrame:
        """Loader for dashboard cache source: latest day-ahead window only."""
        from jain_commods.core.cache.data.market import PricePowerSpot

        logger.info(f"Fetching day-ahead spot prices for {target_date}...")
        start_date, end_date = self._day_ahead_window(target_date)
        download_zones = [self._to_download_zone(z) for z in self.all_zones]
        download_zones = list(dict.fromkeys(download_zones))

        pwr = PricePowerSpot(freq='h')  # Hourly frequency

        try:
            pwr.download(
                zones=download_zones,
                start_date=start_date,
                end_date=end_date,
            )
        except Exception as e:
            logger.warning(f"PricePowerSpot.download failed, falling back to S3 load: {e}")
            try:
                pwr.load(
                    from_s3=True,
                    show_metadata=False,
                    start_date=start_date,
                    end_date=end_date,
                )
            except Exception as load_exc:
                logger.error(f"Failed to load prices from S3 cache: {load_exc}")
                return pd.DataFrame()

        # Use .data which has MultiIndex columns (zone, exchange, currency, frequency)
        df = pwr.data
        
        if df is None or df.empty:
            logger.warning("No data returned from PricePowerSpot")
            return pd.DataFrame()

        logger.info(f"Raw data shape: {df.shape}")
        logger.info(f"Column levels: {df.columns.names}")

        # Keep only bounded day-ahead window.
        start_date = pd.Timestamp(start_date)
        end_date = pd.Timestamp(end_date)
        if df.index.tz is not None:
            start_date = start_date.tz_localize(df.index.tz)
            end_date = end_date.tz_localize(df.index.tz)
        df = df.loc[(df.index >= start_date) & (df.index <= end_date)]

        # Filter to requested zones only (include aliases such as UK -> GB).
        try:
            requested_zones = {z.lower() for z in self.all_zones}
            # PricePowerSpot uses GB while table displays UK.
            if "uk" in requested_zones:
                requested_zones.add("gb")
            zone_mask = df.columns.get_level_values(0).str.lower().isin(requested_zones)
            df = df.loc[:, zone_mask]
        except Exception as e:
            logger.warning(f"Could not filter by zones: {e}")

        # Filter to EUR currency only (level 2 in MultiIndex)
        try:
            eur_mask = df.columns.get_level_values('currency').str.upper() == 'EUR'
            df = df.loc[:, eur_mask]
            logger.info(f"After EUR filter: {df.shape}")
        except Exception as e:
            logger.warning(f"Could not filter by currency: {e}")
        
        # Collapse MultiIndex to just zone names
        # Take mean if multiple exchanges/frequencies for same zone
        zone_series: Dict[str, List[pd.Series]] = {}
        for col in df.columns:
            zone = col[0]  # First level is zone
            zone_display = self._normalize_zone_name(zone)
            zone_series.setdefault(zone_display, []).append(df[col])

        zone_data = {}
        for zone_display, series_list in zone_series.items():
            if len(series_list) == 1:
                zone_data[zone_display] = series_list[0]
            else:
                # Correct multi-source average: mean across ALL sources at once
                zone_data[zone_display] = pd.concat(series_list, axis=1).mean(axis=1)
        
        df_simple = pd.DataFrame(zone_data)
        logger.info(f"Simplified data shape: {df_simple.shape}")
        logger.info(f"Zones available: {df_simple.columns.tolist()}")
        
        # Create MultiIndex with Region grouping
        zone_to_region = {}
        for region, zones in self.regions.items():
            for zone in zones:
                zone_to_region[zone] = region
        
        tuples = []
        for zone in df_simple.columns:
            region = zone_to_region.get(zone, "Other")
            tuples.append((region, zone))
        
        df_simple.columns = pd.MultiIndex.from_tuples(tuples, names=['Region', 'Country'])

        # Enforce region/country display order from REGIONS (left-to-right),
        # then append any unexpected zones at the end.
        ordered_cols = []
        for region, zones in self.regions.items():
            for zone in zones:
                col = (region, zone)
                if col in df_simple.columns:
                    ordered_cols.append(col)
        remaining_cols = [col for col in df_simple.columns if col not in ordered_cols]
        df_simple = df_simple[ordered_cols + remaining_cols]
        
        # Register data freshness
        tracker.register_data_source(
            "EPEX Spot Prices",
            dt.datetime.now(),
            expected_frequency_minutes=60,
            metadata={'zones': len(df_simple.columns), 'date_range': f"{df_simple.index.min()} to {df_simple.index.max()}"}
        )
        
        logger.info(f"Final data: {len(df_simple)} rows, {len(df_simple.columns)} zones")
        logger.info(f"Date range: {df_simple.index.min()} to {df_simple.index.max()}")
        
        return df_simple


# =============================================================================
# Table Generator (matching your reference code style)
# =============================================================================
class SpotPriceTableGenerator:
    """Generates styled HTML tables from price data."""

    def _slice_day_hourly(
        self, df: pd.DataFrame, target_date: pd.Timestamp
    ) -> Optional[pd.DataFrame]:
        """Return hourly rows (index 0..23) for the calendar delivery day, or None if missing."""
        if df is None or df.empty:
            return None
        work = df.copy()
        target_date_normalized = pd.Timestamp(target_date).normalize()
        if not isinstance(work.index, pd.DatetimeIndex):
            work.index = pd.to_datetime(work.index)
        if work.index.tz is not None:
            target_start = target_date_normalized.tz_localize(work.index.tz)
            target_end = target_start + pd.Timedelta(days=1)
        else:
            target_start = target_date_normalized
            target_end = target_start + pd.Timedelta(days=1)
        df_day = work[(work.index >= target_start) & (work.index < target_end)].copy()
        if df_day.empty:
            return None
        logger.info(f"Filtered to {len(df_day)} rows for {target_date.strftime('%Y-%m-%d')}")
        df_day.index = df_day.index.hour
        df_day.index.name = "Hour"
        return df_day.reindex(range(24))

    def generate(self, df: pd.DataFrame, target_date: pd.Timestamp) -> str:
        """Generate styled HTML table matching specification."""
        if df is None or df.empty:
            return self._error_html("No data available")

        try:
            df_day = self._slice_day_hourly(df, target_date)
            if df_day is None:
                return self._error_html(f"No data for {target_date.strftime('%Y-%m-%d')}")
            return self._generate_styled_html(df_day, target_date)

        except Exception as e:
            logger.error(f"Error generating table: {e}", exc_info=True)
            return self._error_html(f"Error: {str(e)}")

    def build_export_dataframe(
        self, df: pd.DataFrame, target_date: pd.Timestamp
    ) -> pd.DataFrame:
        """Same slice and summary rows as the on-screen table, for Excel export (MultiIndex columns)."""
        df_day = self._slice_day_hourly(df, target_date)
        if df_day is None:
            return pd.DataFrame()
        base = df_day.mean()
        peak = df_day.iloc[8:20].mean()
        offpeak = pd.concat([df_day.iloc[0:8], df_day.iloc[20:24]]).mean()
        spacer = pd.Series([pd.NA] * len(df_day.columns), index=df_day.columns)
        df_summary = pd.DataFrame(
            {"": spacer, "Base": base, "Peak": peak, "Offpeak": offpeak}
        ).T
        df_summary.index.name = "Hour"
        out = df_day.copy()
        out.index = out.index.astype(str)
        df_combined = pd.concat([out, df_summary])
        df_combined.index.name = "Hour"
        return df_combined
    
    def _generate_styled_html(self, df: pd.DataFrame, target_date: pd.Timestamp) -> str:
        """Generate the styled HTML table with summary rows."""
        # Calculate summary statistics
        base = df.mean()
        peak = df.iloc[8:20].mean()  # Hours 8-19 (8 AM to 7 PM)
        offpeak = pd.concat([df.iloc[0:8], df.iloc[20:24]]).mean()
        
        # Create spacer and summary rows
        spacer = pd.Series([pd.NA] * len(df.columns), index=df.columns)
        df_summary = pd.DataFrame({
            '': spacer,
            'Base': base,
            'Peak': peak,
            'Offpeak': offpeak
        }).T
        df_summary.index.name = 'Hour'
        
        # Convert index to string before combining
        df.index = df.index.astype(str)
        
        # Combine hourly data with summary
        df_combined = pd.concat([df, df_summary])
        target_rows = df.index.tolist() + ['Base', 'Peak', 'Offpeak']
        
        # Flatten MultiIndex columns for styling
        if isinstance(df_combined.columns, pd.MultiIndex):
            df_flat = df_combined.copy()
            df_flat.columns = [f"{col[1]}" for col in df_combined.columns]
        else:
            df_flat = df_combined.copy()
        
        # Get min/max for color scaling (exclude NaN)
        numeric_values = df.values.flatten()
        numeric_values = numeric_values[~pd.isna(numeric_values)]
        if len(numeric_values) > 0:
            vmin, vmax = numeric_values.min(), numeric_values.max()
        else:
            vmin, vmax = 0, 100
        
        # Define table styles
        styles = [
            {'selector': 'table', 'props': [
                ('border-collapse', 'collapse'),
                ('font-family', 'Calibri, Arial, sans-serif'),
                ('font-size', '13px'),
                ('width', '100%'),
                ('border', '1px solid #ddd')
            ]},
            {'selector': 'th', 'props': [
                ('background-color', '#f2f2f2'),
                ('color', '#333'),
                ('border', '1px solid #999'),
                ('padding', '4px 2px'),
                ('text-align', 'center'),
                ('font-weight', 'bold'),
                ('font-size', '10px')
            ]},
            {'selector': 'td', 'props': [
                ('border', '1px solid #ddd'),
                ('padding', '2px'),
                ('text-align', 'center'),
                ('font-size', '11px')
            ]},
            {'selector': 'tr:nth-last-child(-n+3)', 'props': [
                ('font-weight', 'bold'),
                ('border-top', '2px solid #333')
            ]},
            {'selector': 'tr:hover', 'props': [('background-color', '#f5f5f5')]}
        ]
        
        def highlight_nan(val):
            return 'background-color: #e0e0e0 !important' if pd.isna(val) else ''
        
        # Apply styling
        styler = df_flat.style \
            .background_gradient(cmap='RdYlGn_r', axis=None, vmin=vmin, vmax=vmax,
                               subset=pd.IndexSlice[target_rows, :]) \
            .map(highlight_nan) \
            .format("{:.2f}", na_rep="") \
            .set_table_styles(styles) \
            .set_caption(f"Day Ahead Power Prices - {target_date.strftime('%Y-%m-%d')}") \
            .set_properties(**{'min-width': '35px', 'max-width': '50px'})
        
        table_html = styler.to_html()
        
        # Inject region header row into the table
        table_html = self._inject_region_header(table_html, df_combined.columns)
        
        # Wrap in styled container
        return self._wrap_html(table_html, target_date)
    
    def _inject_region_header(self, table_html: str, columns: pd.MultiIndex) -> str:
        """Inject a region header row into the table HTML."""
        if not isinstance(columns, pd.MultiIndex):
            return table_html
        
        # Build region counts (preserving order)
        from collections import OrderedDict
        region_counts = OrderedDict()
        for region, zone in columns:
            if region not in region_counts:
                region_counts[region] = 0
            region_counts[region] += 1
        
        # Build region header row HTML
        region_cells = '<th style="background-color:#d4edda;font-size:14px;font-weight:bold;padding:10px 8px;border:1px solid #999;"></th>'  # Empty corner cell
        for region, count in region_counts.items():
            region_cells += f'<th colspan="{count}" style="background-color:#d4edda;font-size:14px;font-weight:bold;padding:10px 8px;border:1px solid #999;text-align:center;">{region}</th>'
        
        region_row = f'<tr class="region-header">{region_cells}</tr>'
        
        # Find the <thead> tag and inject the region row after it
        # The styler generates: <thead><tr>..country headers..</tr></thead>
        # We want: <thead><tr>..region headers..</tr><tr>..country headers..</tr></thead>
        
        import re
        # Match the first <tr> inside <thead>
        thead_pattern = r'(<thead[^>]*>)\s*(<tr)'
        replacement = rf'\1{region_row}\2'
        table_html = re.sub(thead_pattern, replacement, table_html, count=1)
        
        return table_html
    
    def _wrap_html(self, table_html: str, target_date: pd.Timestamp) -> str:
        """Wrap table in full HTML with custom styling."""
        custom_css = """
        <style>
            .price-table-container {
                font-family: Calibri, Arial, sans-serif;
                padding: 20px;
                background-color: white;
            }
            .price-table-container h2 {
                color: #333;
                margin-bottom: 15px;
            }
            /* Region header row styling */
            .region-header th {
                background-color: #e9ecef !important;
                font-size: 11px !important;
                font-weight: bold !important;
                padding: 4px 2px !important;
                border: 1px solid #999 !important;
                text-align: center !important;
            }
            /* Country header row styling */
            .dataframe thead tr:nth-child(2) th {
                background-color: #f8f9fa !important;
                font-size: 10px !important;
                padding: 4px 2px !important;
                border: 1px solid #999 !important;
                text-align: center !important;
            }
            .dataframe tbody tr:nth-last-child(4) td,
            .dataframe tbody tr:nth-last-child(4) th {
                border: none !important;
                background-color: white !important;
                height: 15px;
            }
            .dataframe tbody tr:nth-last-child(3) td {
                border-top: 3px solid #000 !important;
            }
            .dataframe tbody tr:nth-last-child(1) td {
                border-bottom: 3px solid #000 !important;
            }
            .dataframe tbody tr:nth-last-child(1) td:first-child,
            .dataframe tbody tr:nth-last-child(2) td:first-child,
            .dataframe tbody tr:nth-last-child(3) td:first-child {
                border-left: 3px solid #000 !important;
            }
            .dataframe tbody tr:nth-last-child(1) td:last-child,
            .dataframe tbody tr:nth-last-child(2) td:last-child,
            .dataframe tbody tr:nth-last-child(3) td:last-child {
                border-right: 3px solid #000 !important;
            }
            .dataframe tbody tr:nth-last-child(1) td,
            .dataframe tbody tr:nth-last-child(2) td,
            .dataframe tbody tr:nth-last-child(3) td {
                font-weight: bold;
            }
            caption {
                caption-side: top;
                font-size: 16px;
                font-weight: bold;
                padding: 10px;
                color: #333;
            }
        </style>
        """
        
        return f"""
        {custom_css}
        <div class="price-table-container">
            <h2>Day Ahead Power Prices (€/MWh) - {target_date.strftime('%A, %d %B %Y')}</h2>
            <div style="overflow-x: auto;">
                {table_html}
            </div>
        </div>
        """
    
    def _error_html(self, message: str) -> str:
        """Generate error message HTML."""
        return f"""
        <div style="padding: 40px; text-align: center; color: #666;">
            <h3>⚠️ {message}</h3>
        </div>
        """


# =============================================================================
# Initialize components
# =============================================================================
data_loader = SpotPriceDataLoader()
table_generator = SpotPriceTableGenerator()

_html_cache: Dict[str, str] = {}
_HTML_CACHE_MAX = 50


# =============================================================================
# Helper functions
# =============================================================================
def get_available_dates(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Get list of available dates from the DataFrame."""
    if df is None or df.empty:
        return []
    
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    
    # Get unique dates
    dates = df.index.normalize().unique().sort_values(ascending=False)
    
    date_options = []
    for d in dates:
        val = d.strftime('%Y-%m-%d')
        wd = d.strftime('%a')
        label = f"{val} ({wd})"
        date_options.append({'value': val, 'label': label})
    
    return date_options


# =============================================================================
# Layout
# =============================================================================
layout = html.Div(
    style={'backgroundColor': COLORS['background'], 'minHeight': '100vh'},
    children=[
        # Data stores
        dcc.Store(id='epex-data-loaded', data=False),
        dcc.Interval(id='epex-refresh-interval', interval=15 * 60 * 1000, n_intervals=0),
        
        # Header / Controls
        html.Div(
            style={
                'padding': '15px 20px',
                'backgroundColor': COLORS['card_bg'],
                'borderBottom': f'1px solid {COLORS["border"]}',
                'display': 'flex',
                'alignItems': 'center',
                'gap': '20px',
                'flexWrap': 'wrap',
            },
            children=[
                html.Div([
                    html.Label("Select Date:", style={'fontWeight': '600', 'color': COLORS['text_primary'], 'marginRight': '10px'}),
                    dcc.DatePickerSingle(
                        id='epex-date-select',
                        date=None,
                        display_format='YYYY-MM-DD',
                        placeholder='Select a date...',
                        style={'width': '220px'},
                        first_day_of_week=1,
                    ),
                ], style={'display': 'flex', 'alignItems': 'center'}),
                
                html.Button(
                    "Refresh Latest",
                    id='epex-refresh-btn',
                    n_clicks=0,
                    style={
                        'backgroundColor': COLORS['accent'],
                        'color': 'white',
                        'border': 'none',
                        'borderRadius': '6px',
                        'padding': '8px 16px',
                        'cursor': 'pointer',
                        'fontSize': '13px',
                        'fontWeight': '500',
                    },
                ),
                html.Button(
                    "Download Excel",
                    id='epex-download-xlsx-btn',
                    n_clicks=0,
                    style={
                        'backgroundColor': '#6c757d',
                        'color': 'white',
                        'border': 'none',
                        'borderRadius': '6px',
                        'padding': '8px 16px',
                        'cursor': 'pointer',
                        'fontSize': '13px',
                        'fontWeight': '500',
                    },
                ),
                dcc.Download(id='epex-download-excel'),
                html.Div(
                    id="epex-status",
                    style={'marginLeft': 'auto', 'fontSize': '13px', 'color': COLORS['text_secondary']},
                ),
            ],
        ),
        
        # Main content area
        dcc.Loading(
            id='epex-loading',
            type='circle',
            color=COLORS['accent'],
            children=[
                html.Div(
                    id='epex-table-container',
                    style={'padding': '20px', 'minHeight': '500px'},
                ),
            ],
        ),
    ]
)


# =============================================================================
# Callbacks
# =============================================================================
@callback(
    Output('epex-date-select', 'min_date_allowed'),
    Output('epex-date-select', 'max_date_allowed'),
    Output('epex-date-select', 'date'),
    Output('epex-status', 'children'),
    Output('epex-data-loaded', 'data'),
    Input('epex-refresh-interval', 'n_intervals'),
    Input('url', 'pathname'),
    Input('epex-refresh-btn', 'n_clicks'),
    State('epex-date-select', 'date'),
    prevent_initial_call=False
)
def load_data_and_dates(n_intervals, pathname, refresh_clicks, current_value):
    """Load data and set date picker bounds on open, every 15 minutes, or on refresh click."""
    if pathname != '/power/epex_auction':
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

    triggered_id = dash.ctx.triggered_id
    force_download = (triggered_id == 'epex-refresh-btn' and refresh_clicks)

    try:
        if force_download:
            logger.info("Refresh button clicked – downloading latest day-ahead prices...")
            _html_cache.clear()
            df = _download_latest_day_ahead()
        else:
            logger.info(f"Loading EPEX data (interval tick: {n_intervals})...")
            df = data_loader.fetch_prices()

        if df is None or df.empty:
            return None, None, None, "No data available", False

        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index)

        dates = df.index.normalize().unique().sort_values()
        if dates.empty:
            return None, None, None, "No dates available", False

        min_date = dates.min().strftime('%Y-%m-%d')
        max_date = dates.max().strftime('%Y-%m-%d')

        if current_value and min_date <= current_value <= max_date:
            selected_date = current_value
        else:
            selected_date = max_date

        source = "Manual refresh" if force_download else "Auto-refresh every 15 min"
        status = (
            f"{source} | Loaded {len(df.columns)} zones | "
            f"{len(dates)} days available | "
            f"Updated {dt.datetime.now().strftime('%H:%M:%S')}"
        )

        return min_date, max_date, selected_date, status, True

    except Exception as e:
        logger.error(f"Error loading data: {e}", exc_info=True)
        return None, None, None, f"Error: {str(e)}", False


def _download_latest_day_ahead() -> pd.DataFrame:
    """Force-download latest day-ahead prices from EQ and update dashboard cache."""
    target_date = dt.date.today()

    # Bypass @cached_result decorator to force a fresh download
    unwrapped = data_loader.fetch_prices_for_cache.__wrapped__
    df = unwrapped(data_loader, target_date)

    if df is not None and not df.empty:
        dashboard_cache.set("source:epex_spot", df, ttl=900)

    return df if df is not None else pd.DataFrame()


@callback(
    Output('epex-table-container', 'children'),
    Input('epex-date-select', 'date'),
    Input('epex-data-loaded', 'data'),
    prevent_initial_call=False
)
def display_table(selected_date, data_loaded):
    """Display the styled price table.

    Only reacts to date selection changes and data-loaded flag (set by
    load_data_and_dates).  The 15-min interval is intentionally excluded
    to avoid redundant data loads and expensive HTML regeneration.
    """
    if not data_loaded or not selected_date:
        return html.Div(
            style={'padding': '60px', 'textAlign': 'center'},
            children=[
                html.H3("Loading EPEX Day-Ahead Prices...", style={'color': COLORS['text_primary']}),
                html.P("Fetching data from cache...", style={'color': COLORS['text_secondary']}),
            ]
        )

    try:
        df = data_loader.fetch_prices()

        if df is None or df.empty:
            return html.Div(
                style={'padding': '40px', 'textAlign': 'center'},
                children=[
                    html.H3("No Data Available", style={'color': '#e74c3c'}),
                ]
            )

        df_fingerprint = hashlib.md5(
            pd.util.hash_pandas_object(df).values.tobytes()
        ).hexdigest()[:12]
        cache_key = f"{selected_date}|{df_fingerprint}"

        if cache_key in _html_cache:
            table_html = _html_cache[cache_key]
        else:
            target_date = pd.Timestamp(selected_date)
            table_html = table_generator.generate(df, target_date)
            if len(_html_cache) >= _HTML_CACHE_MAX:
                _html_cache.pop(next(iter(_html_cache)))
            _html_cache[cache_key] = table_html

        return html.Iframe(
            srcDoc=table_html,
            style={
                'width': '100%',
                'height': '1400px',
                'border': 'none',
                'backgroundColor': 'white',
            },
            sandbox='allow-same-origin'
        )

    except Exception as e:
        logger.error(f"Error displaying table: {e}", exc_info=True)
        return html.Div(
            style={'padding': '40px'},
            children=[
                html.H3("Error Generating Table", style={'color': '#e74c3c'}),
                html.Pre(str(e), style={
                    'backgroundColor': '#f8f9fa',
                    'padding': '15px',
                    'borderRadius': '6px',
                    'fontSize': '13px',
                    'whiteSpace': 'pre-wrap',
                }),
            ]
        )


@callback(
    Output('epex-download-excel', 'data'),
    Input('epex-download-xlsx-btn', 'n_clicks'),
    State('epex-date-select', 'date'),
    State('epex-data-loaded', 'data'),
    prevent_initial_call=True,
)
def download_epex_excel(n_clicks, selected_date, data_loaded):
    """Export the selected delivery day (same slice as the table) to .xlsx."""
    if not n_clicks or not data_loaded or not selected_date:
        return no_update
    try:
        df = data_loader.fetch_prices()
        if df is None or df.empty:
            return no_update
        target_date = pd.Timestamp(selected_date)
        export_df = table_generator.build_export_dataframe(df, target_date)
        if export_df is None or export_df.empty:
            return no_update
        buf = io.BytesIO()
        sheet = f"DA_{target_date.strftime('%Y%m%d')}"[:31]
        with pd.ExcelWriter(buf, engine='openpyxl') as writer:
            export_df.to_excel(writer, sheet_name=sheet, index=True, merge_cells=True)
        buf.seek(0)
        fname = f"epex_day_ahead_{target_date.strftime('%Y-%m-%d')}.xlsx"
        return dcc.send_bytes(buf.read(), filename=fname)
    except Exception as e:
        logger.exception('EPEX Excel export failed: %s', e)
        return no_update
