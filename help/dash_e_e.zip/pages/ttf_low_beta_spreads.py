"""
TTF Low-Beta Spreads - Dash page registrar.

Finds spreads that are mispriced (extreme z/percentile vs their own rolling
generic history) AND insensitive to front-month flat-price moves (low beta /
correlation of daily changes), so they are not disguised long-or-short
flat-price positions.  Sibling of the TTF Spreads Monitor page.

Implementation lives in ``core.low_beta_spreads``:
    * constants  -- page/scheduler wiring + option defaults
    * data       -- scheduler loader + stats recomputation from cached series
    * components -- heat-mapped stats table
    * charts     -- scatter + drilldown Plotly figures
    * layout     -- ``build_layout()``
    * callbacks  -- registered on import

The spread universe + regression engine is
``jain_commods.core.analytics.spread_beta`` (sibling of the shared
spreads-monitor engine).
"""
from __future__ import annotations

import dash

from core.low_beta_spreads import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.low_beta_spreads.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.low_beta_spreads.data import load_low_beta_spreads_data  # noqa: F401  - re-export for portal_app
from core.low_beta_spreads.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
