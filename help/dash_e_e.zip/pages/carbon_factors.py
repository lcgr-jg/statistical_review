"""
Carbon Factors — Dash page registrar.

Self-contained Plotly HTML built by eu_carbon's factors monitor and pushed
via ``POST /api/carbon/upload/factors`` (see ``core.carbon_static``).
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/factors",
    name=CARBON_PAGES["factors"],
    title="Carbon Factors | JG Power Dashboard",
    order=62,
)

layout = iframe_page_layout("factors")
