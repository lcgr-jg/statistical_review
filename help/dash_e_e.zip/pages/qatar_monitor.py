"""
LNG — Qatar Monitor page registrar.

Implementation lives in ``core.qatar_monitor``:
    * data       -- Kpler LNG cache reads / force refresh
    * charts     -- Ras Laffan idle-gap + Qatar exports Plotly figure
    * stats/tables -- pre/post Iran berth utilisation tables
    * layout     -- ``build_layout()``
    * callbacks  -- registered on import
"""
from __future__ import annotations

import dash

from core.qatar_monitor import callbacks as _callbacks  # noqa: F401
from core.qatar_monitor.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.qatar_monitor.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
