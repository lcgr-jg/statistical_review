"""
EU Gas Balance — Injectability / Withdrawability page registrar.
"""
from __future__ import annotations

import dash

from core.gas_inj_wdr import callbacks as _callbacks  # noqa: F401
from core.gas_inj_wdr.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.gas_inj_wdr.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
