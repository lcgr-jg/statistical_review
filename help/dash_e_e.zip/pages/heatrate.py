"""
HeatRate Dashboard - Multi-page integration
===========================================
Heat rate model analytics, including availability forecasts.
Sub-pages: Availability
"""
import logging
import os

import dash
from dash import Input, Output, callback, dcc, html

from portal_pages.fundamentals.styles import (
    COLORS,
)

logger = logging.getLogger(__name__)

# Register as Dash page
if __name__ != '__main__':
    dash.register_page(
        __name__,
        path='/power/heatrate',
        name='HeatRate Model',
        title='HeatRate Model | JG Power Dashboard',
        order=10,  # Place it after other dashboards
    )

# ---------------------------------------------------------------------------
# Lazy imports & sub-page management
# ---------------------------------------------------------------------------
_data_handler = None
_sub_pages_loaded = False
_sub_page_modules = {}

def _get_data_handler():
    """Return singleton DataHandler from global cache."""
    from core.cache import dashboard_cache
    handler = dashboard_cache.get("source:heatrate_data")
    if handler is None:
        # Fallback for dev or if cache not warm yet
        from portal_pages.heatrate.data_handler import HeatRateDataHandler
        handler = HeatRateDataHandler()
    return handler


def _ensure_loaded():
    """Lazy-load the sub-page modules on first access."""
    global _sub_pages_loaded, _sub_page_modules
    if _sub_pages_loaded:
        return

    try:
        from portal_pages.heatrate.availability import get_layout as get_availability_layout
        from portal_pages.heatrate.forecast_comparison import (
            get_layout as get_forecast_comparison_layout,
        )
        _sub_page_modules['availability'] = get_availability_layout
        _sub_page_modules['forecast_comparison'] = get_forecast_comparison_layout
        _sub_pages_loaded = True
        logger.info("HeatRate sub-pages loaded successfully")
    except Exception as e:
        logger.error(f"Failed to load HeatRate sub-pages: {e}")


def initialize_heatrate_callbacks(app):
    """Register all heatrate callbacks once at startup."""
    handler = _get_data_handler()
    from portal_pages.heatrate.availability import register_availability_callbacks
    from portal_pages.heatrate.forecast_comparison import (
        register_forecast_comparison_callbacks,
    )

    # Check if callbacks are already registered to avoid duplicates
    cb_keys = set(app.callback_map.keys())
    if any("hr-avail-main-chart.figure" in k for k in cb_keys):
        logger.warning("HeatRate callbacks already present. Skipping registration.")
        return

    register_availability_callbacks(app, handler)
    register_forecast_comparison_callbacks(app, handler)
    logger.info("HeatRate callbacks initialized at startup")


# ---------------------------------------------------------------------------
# Sub-page definitions
# ---------------------------------------------------------------------------
SUB_PAGES = [
    {'key': 'availability', 'label': 'Availability', 'icon': '\u26A1'},
    {'key': 'forecast_comparison', 'label': 'Forecast Comparison', 'icon': '\U0001F4C8'},
]

# ---------------------------------------------------------------------------
# Shared inline styles (matching fundamentals.py)
# ---------------------------------------------------------------------------
_TAB_BAR_STYLE = {
    'display': 'flex',
    'gap': '0',
    'borderBottom': f'2px solid {COLORS["border"]}',
    'backgroundColor': COLORS['card_bg'],
    'padding': '0 24px',
    'boxShadow': '0 1px 2px rgba(0,0,0,0.03)',
}
_TAB_BTN_STYLE = {
    'padding': '14px 22px',
    'border': 'none',
    'borderBottom': '3px solid transparent',
    'backgroundColor': 'transparent',
    'color': COLORS['text_secondary'],
    'fontSize': '13px',
    'fontWeight': '500',
    'cursor': 'pointer',
    'transition': 'all 0.2s',
    'fontFamily': 'Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif',
    'letterSpacing': '0.2px',
    'whiteSpace': 'nowrap',
}

# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
layout = html.Div(
    style={
        'minHeight': '100vh',
        'backgroundColor': COLORS['background'],
    },
    children=[
        dcc.Store(id='heatrate-active-tab', data='availability'),

        # -------- Sub-page tab bar --------
        html.Div(
            style=_TAB_BAR_STYLE,
            children=[
                html.Button(
                    f"{sp['icon']}  {sp['label']}",
                    id={'type': 'heatrate-tab-btn', 'index': sp['key']},
                    n_clicks=0,
                    style=_TAB_BTN_STYLE,
                )
                for sp in SUB_PAGES
            ],
        ),

        # -------- Content --------
        html.Div(
            id='heatrate-sub-content',
            style={
                'minHeight': '500px',
                'padding': '24px 28px',
            },
        ),
    ],
)


# ---------------------------------------------------------------------------
# Callback: switch sub-pages
# ---------------------------------------------------------------------------
@callback(
    Output('heatrate-sub-content', 'children'),
    [Input({'type': 'heatrate-tab-btn', 'index': sp['key']}, 'n_clicks')
     for sp in SUB_PAGES],
    prevent_initial_call=False,
)
def switch_heatrate_tab(*n_clicks):
    ctx = dash.callback_context
    triggered_id = 'availability'  # default

    if ctx.triggered and ctx.triggered[0]['prop_id'] != '.':
        import json
        prop_id = ctx.triggered[0]['prop_id']
        try:
            btn_id = json.loads(prop_id.rsplit('.', 1)[0])
            triggered_id = btn_id.get('index', 'availability')
        except (json.JSONDecodeError, KeyError):
            pass

    _ensure_loaded()
    
    if not _sub_pages_loaded:
        return html.Div("Loading HeatRate sub-pages...")

    handler = _get_data_handler()
    try:
        get_layout_fn = _sub_page_modules.get(triggered_id)
        if get_layout_fn:
            return get_layout_fn(handler)
        return html.Div(f"Sub-page '{triggered_id}' not found.")
    except Exception as e:
        logger.error(f"Error rendering HeatRate sub-page '{triggered_id}': {e}")
        return html.Div(f"Error loading {triggered_id}: {e}")
