"""
HTML table + pandas Styler for Heatmap Balance — same styling patterns as ``SpotPriceTableGenerator`` (epex_auction).

* **Rows (y)** = delivery dates ``YYYY-MM-DD``.
* **Columns (x)** = two-level MultiIndex: level 0 = ``Price`` | ``Fundamental``;
  level 1 = metric (Spot, CSS, … / ResL, Solar, …).
* Per **metric column** color scales (``axis=0`` down dates): prices high→red; demand/load high→red;
  renewable/nuclear/thermal gen high→green.
* Metric columns whose values are **all NaN** or **all zero** (finite) are omitted from the HTML table.
* Vertical rule between **Price** and **Fundamental** column blocks (after last price metric).
"""
from __future__ import annotations

import datetime as dt
import logging

import pandas as pd

from .heatmap_balance_data import (
    FUND_DEMAND_ROWS,
    FUND_ROWS,
    FUND_SUPPLY_ROWS,
    GAS_GEN_METRIC,
    NET_EXPORT_METRIC,
    PRICE_ROWS,
)

logger = logging.getLogger(__name__)

BLOCK_PRICE = "Price"
BLOCK_FUNDAMENTAL = "Fundamental"

# Number formats: price-like metrics vs fundamentals (MW)
_PRICE_TWO_DEC = ("Spot", "CSS", "CDS", "Heat rate", "TTF", "EUA")


def _column_format_dict(columns: pd.Index) -> dict:
    """Row-aware display formats for Styler (prices vs MW fundamentals)."""
    fmt: dict = {}
    for col in columns:
        if not isinstance(col, tuple) or len(col) < 2:
            continue
        _, metric = col[0], col[1]
        if metric in _PRICE_TWO_DEC:
            fmt[col] = "{:.2f}"
        else:
            fmt[col] = "{:,.0f}"
    return fmt


def _reshape_metrics_by_date_to_display(mat: pd.DataFrame) -> pd.DataFrame:
    """
    ``build_balance_matrix`` layout: index = metrics, columns = calendar dates
    → display layout: index = delivery dates (str), columns = (Block, Metric).
    """
    if mat is None or mat.empty:
        return mat

    df = mat.T.copy()
    df.index = pd.to_datetime(df.index).normalize()
    df.index.name = "Delivery date"

    tuples = []
    for metric in df.columns:
        if metric in PRICE_ROWS:
            tuples.append((BLOCK_PRICE, metric))
        else:
            tuples.append((BLOCK_FUNDAMENTAL, metric))

    df.columns = pd.MultiIndex.from_tuples(tuples, names=["Block", "Metric"])

    ordered: list[tuple[str, str]] = []
    for m in PRICE_ROWS:
        c = (BLOCK_PRICE, m)
        if c in df.columns:
            ordered.append(c)
    for m in FUND_ROWS:
        c = (BLOCK_FUNDAMENTAL, m)
        if c in df.columns:
            ordered.append(c)

    df = df.reindex(columns=ordered)
    df.index = df.index.map(lambda t: pd.Timestamp(t).strftime("%Y-%m-%d"))
    return df


def _should_drop_metric_column(s: pd.Series) -> bool:
    """True if column is all-NaN or every finite value is zero (no useful signal)."""
    if s.empty or s.isna().all():
        return True
    vals = pd.to_numeric(s, errors="coerce").dropna()
    if vals.empty:
        return True
    return bool((vals == 0).all())


def _drop_uninformative_metric_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Remove metric columns that are entirely NaN or entirely zeros."""
    if df is None or df.empty:
        return df
    keep = [c for c in df.columns if not _should_drop_metric_column(df[c])]
    if not keep:
        return df.iloc[:, :0]
    return df[keep]


def display_table_for_export(mat: pd.DataFrame) -> pd.DataFrame:
    """
    Same grid as the on-screen table: delivery dates as rows, Price | Fundamental × metric columns.
    Omits empty/degenerate metric columns like the HTML view.
    """
    if mat is None or mat.empty:
        return pd.DataFrame()
    df = _reshape_metrics_by_date_to_display(mat.copy())
    df = _drop_uninformative_metric_columns(df)
    return df


def _delivery_label_is_weekend(label: object) -> bool:
    try:
        d = dt.datetime.strptime(str(label), "%Y-%m-%d").date()
    except ValueError:
        return False
    return d.weekday() >= 5


def _weekend_delivery_date_index_styles(idx: pd.Index) -> list[str]:
    """Strong weekend band on the delivery-date column (Sat/Sun)."""
    weekend_css = (
        "background-color: #b8c5df !important;"
        "color: #1a1a1a !important;"
        "font-weight: 700 !important;"
        "border-left: 4px solid #5c6bc0 !important;"
        "box-shadow: inset 0 0 0 1px rgba(92,107,192,0.35) !important;"
    )
    return [weekend_css if _delivery_label_is_weekend(x) else "" for x in idx]


def _first_delivery_label_after(index: pd.Index, today: dt.date) -> str | None:
    """
    Index labels are ``YYYY-MM-DD`` strings. Return the first label whose date is **strictly after**
    ``today`` so a horizontal rule can sit **between** today’s row and the next delivery row
    (typically between today and tomorrow when both exist).
    """
    for label in index:
        try:
            d = dt.datetime.strptime(str(label), "%Y-%m-%d").date()
        except ValueError:
            continue
        if d > today:
            return str(label)
    return None


class BalanceTableGenerator:
    """Styled HTML table — EPEX-like mechanics with balance-specific row/column layout."""

    def generate(
        self,
        mat: pd.DataFrame,
        *,
        zone: str,
        split_date: dt.date,
        issue_date: dt.date,
        hist_days: int,
        fwd_days: int,
    ) -> str:
        if mat is None or mat.empty:
            return self._error_html("No data — check S3 cache / jain_commods")

        try:
            df = _reshape_metrics_by_date_to_display(mat.copy())
            df = _drop_uninformative_metric_columns(df)
            if df.empty or len(df.columns) == 0:
                return self._error_html("No data — check S3 cache / jain_commods")

            return self._generate_styled_html(
                df,
                zone=zone,
                split_date=split_date,
                issue_date=issue_date,
                hist_days=hist_days,
                fwd_days=fwd_days,
            )
        except Exception as e:
            logger.error("Balance table error: %s", e, exc_info=True)
            return self._error_html(str(e))

    def _generate_styled_html(
        self,
        df: pd.DataFrame,
        *,
        zone: str,
        split_date: dt.date,
        issue_date: dt.date,
        hist_days: int,
        fwd_days: int,
    ) -> str:
        calendar_today = dt.date.today()
        # History | future rule sits above the first delivery row strictly after calendar today
        # (between today and tomorrow when both rows exist), not at user split D.
        history_future_rule_label = _first_delivery_label_after(df.index, calendar_today)

        # Keep MultiIndex columns on the frame Styler uses — required for a two-row thead
        # (Level 1 = Price | Fundamental, Level 2 = Spot, CSS, …) like EPEX region + country.
        df = df.copy()
        df.columns.names = [None, None]

        price_cols = [c for c in df.columns if c[0] == BLOCK_PRICE]
        supply_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL
            and c[1] in FUND_SUPPLY_ROWS
            and c[1] != NET_EXPORT_METRIC
            and c[1] != GAS_GEN_METRIC
        ]
        net_export_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL and c[1] == NET_EXPORT_METRIC
        ]
        gas_gen_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL and c[1] == GAS_GEN_METRIC
        ]
        demand_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL and c[1] in FUND_DEMAND_ROWS
        ]

        styles = [
            {"selector": "table", "props": [
                ("border-collapse", "collapse"),
                ("font-family", "Calibri, Arial, sans-serif"),
                ("font-size", "13px"),
                ("width", "100%"),
                ("border", "1px solid #ddd"),
            ]},
            {"selector": "th", "props": [
                ("background-color", "#f2f2f2"),
                ("color", "#333"),
                ("border", "1px solid #999"),
                ("padding", "4px 2px"),
                ("text-align", "center"),
                ("font-weight", "bold"),
                ("font-size", "10px"),
            ]},
            {"selector": "td", "props": [
                ("border", "1px solid #ddd"),
                ("padding", "2px"),
                ("text-align", "center"),
                ("font-size", "11px"),
            ]},
            {"selector": "tr:hover", "props": [("background-color", "#f5f5f5")]},
        ]

        def highlight_nan(val):
            return "background-color: #e0e0e0 !important" if pd.isna(val) else ""

        def split_row_border(row: pd.Series):
            if history_future_rule_label is not None and str(row.name) == history_future_rule_label:
                return ["border-top: 3px dashed #333 !important"] * len(row)
            return [""] * len(row)

        # Per metric column (axis=0): scale independently down delivery dates.
        styler = df.style.apply_index(_weekend_delivery_date_index_styles, axis=0)
        if price_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, price_cols],
            )
        if supply_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn",
                axis=0,
                subset=pd.IndexSlice[:, supply_cols],
            )
        # Gas gen: inverted vs coal/lignite/supply default (stress framing)
        if gas_gen_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, gas_gen_cols],
            )
        # Net Export: inverted vs gen/supply (high imports / low exports → stress)
        if net_export_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, net_export_cols],
            )
        if demand_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, demand_cols],
            )

        fmt_dict = _column_format_dict(df.columns)
        styler = (
            styler.apply(split_row_border, axis=1)
            .map(highlight_nan)
            .format(fmt_dict, na_rep="")
            .set_table_styles(styles)
            .set_properties(**{"min-width": "52px", "max-width": "96px"})
        )

        table_html = styler.to_html(sparse_index=True, sparse_columns=True)

        # Optional: emphasise top-level block row like EPEX region bands (pandas already emits colspan).
        table_html = self._style_block_header_row(table_html)
        table_html = self._inject_price_fundamental_separator(table_html, len(price_cols))

        title = f"Heatmap balance · {zone}"
        return self._wrap_html(table_html, title=title)

    def _style_block_header_row(self, table_html: str) -> str:
        """Light green band on first MultiIndex header row (Price | Fundamental groups)."""
        css = """
        <style>
            .dataframe thead tr:first-child th {
                background-color: #d4edda !important;
                font-size: 12px !important;
                font-weight: bold !important;
            }
        </style>
        """
        return css + table_html

    def _inject_price_fundamental_separator(self, table_html: str, n_price_cols: int) -> str:
        """Vertical rule between Price block and Fundamental block (after last Price column).

        Pandas ``to_html`` with sparse columns + sparse index emits **three** ``thead`` rows:
        block labels (Price | Fundamental), metric labels, then optional index-name row.
        ``thead tr:last-child`` therefore targets the wrong row; we use explicit row indices.

        Selectors are scoped with ``.hb-scroll-wrap`` so ``border-right`` beats the generic
        ``thead th { border: 1px ... !important }`` rules in ``_wrap_html``.
        """
        if n_price_cols <= 0:
            return table_html
        # Col 1 = row index (th or td context); data columns: 2 .. 1+n_price are Price.
        col_last_price = 1 + n_price_cols
        css = f"""<style>
        .hb-scroll-wrap .dataframe tbody td:nth-child({col_last_price}),
        .hb-scroll-wrap .dataframe thead tr:nth-child(2) th:nth-child({col_last_price}),
        .hb-scroll-wrap .dataframe thead tr:nth-child(3) th:nth-child({col_last_price}),
        .hb-scroll-wrap .dataframe thead tr:first-child th:nth-child(2) {{
            border-right: 3px solid #555 !important;
        }}
        </style>"""
        return css + table_html

    def _wrap_html(self, table_html: str, *, title: str) -> str:
        custom_css = """
        <style>
            .hb-scroll-wrap {
                overflow-x: auto;
                border: 1px solid #ddd;
            }
            .price-table-container {
                font-family: Calibri, Arial, sans-serif;
                padding: 20px;
                background-color: white;
            }
            .price-table-container h2 {
                color: #333;
                margin-bottom: 15px;
                font-size: 15px;
            }
            /* Sticky thead + first column (delivery date) */
            .hb-scroll-wrap .dataframe thead tr:first-child th {
                position: sticky;
                top: 0;
                z-index: 6;
                background-color: #d4edda !important;
            }
            .hb-scroll-wrap .dataframe thead tr:nth-child(2) th {
                position: sticky;
                top: 2rem;
                z-index: 5;
                background-color: #f8f9fa !important;
                font-size: 10px !important;
                padding: 4px 2px !important;
                border: 1px solid #999 !important;
                text-align: center !important;
            }
            .hb-scroll-wrap .dataframe thead tr:first-child th:first-child {
                left: 0;
                top: 0;
                z-index: 10;
                background-color: #e8f4ea !important;
                box-shadow: 2px 2px 4px rgba(0,0,0,0.08);
            }
            .hb-scroll-wrap .dataframe thead tr:nth-child(2) th:first-child {
                left: 0;
                top: 2rem;
                z-index: 9;
                background-color: #eef6f0 !important;
                box-shadow: 2px 2px 4px rgba(0,0,0,0.08);
            }
            .hb-scroll-wrap .dataframe tbody th {
                position: sticky;
                left: 0;
                z-index: 4;
                background-color: #fff !important;
                font-weight: 600;
                box-shadow: 2px 0 4px rgba(0,0,0,0.06);
            }
            caption {
                caption-side: top;
                font-size: 14px;
                font-weight: bold;
                padding: 8px;
                color: #333;
            }
        </style>
        """
        return f"""
        {custom_css}
        <div class="price-table-container">
            <h2>{title}</h2>
            <div class="hb-scroll-wrap">
                {table_html}
            </div>
        </div>
        """

    def generate_delta(
        self,
        mat_issue: pd.DataFrame,
        mat_compare: pd.DataFrame,
        *,
        zone: str,
        issue_date: dt.date,
        compare_date: dt.date,
        hist_days: int,
        fwd_days: int,
    ) -> str:
        """Render a Δ table: ``mat_issue − mat_compare`` for Fundamental rows only.

        * Prices are excluded — the delta of a price across two forecast vintages
          is rarely meaningful in isolation.
        * Each metric column uses a **diverging colorscale centred at 0** scaled
          to ±max_abs for that column (supply rows: green = more supply; demand /
          residual-load rows: red = more demand).
        * Values are formatted with an explicit sign (+/−).
        """
        try:
            if mat_issue is None or mat_issue.empty:
                return self._error_html("No data for issue date — check S3 cache")
            if mat_compare is None or mat_compare.empty:
                return self._error_html("No data for compare date — check S3 cache")

            # Keep only rows present in both matrices and listed in FUND_ROWS
            fund_rows = [r for r in FUND_ROWS if r in mat_issue.index and r in mat_compare.index]
            if not fund_rows:
                return self._error_html("No common Fundamental rows between the two dates")

            mi = mat_issue.loc[fund_rows].copy()
            mc = mat_compare.loc[fund_rows].copy()

            # Align on the intersection of delivery-date columns
            common_cols = mi.columns.intersection(mc.columns)
            if len(common_cols) == 0:
                return self._error_html(
                    f"No overlapping delivery dates between issue {issue_date} "
                    f"and compare {compare_date} — try adjusting the History/Forward sliders"
                )

            delta = mi[common_cols].subtract(mc[common_cols])  # positive = higher on issue date

            # Reshape to display layout: index = delivery dates, columns = (Fundamental, metric)
            df = delta.T.copy()
            df.index = pd.to_datetime(df.index).normalize()
            df.index.name = "Delivery date"
            df.columns = pd.MultiIndex.from_tuples(
                [(BLOCK_FUNDAMENTAL, m) for m in df.columns],
                names=[None, None],
            )
            # Drop columns where every value is NaN or all-zero delta
            keep = [c for c in df.columns if not _should_drop_metric_column(df[c])]
            if not keep:
                return self._error_html("All Fundamental deltas are zero — the two dates have identical fundamentals")
            df = df[keep]
            df.index = df.index.map(lambda t: pd.Timestamp(t).strftime("%Y-%m-%d"))

            return self._generate_delta_html(df, zone=zone, issue_date=issue_date, compare_date=compare_date)
        except Exception as e:
            logger.error("Delta table error: %s", e, exc_info=True)
            return self._error_html(str(e))

    def _generate_delta_html(
        self,
        df: pd.DataFrame,
        *,
        zone: str,
        issue_date: dt.date,
        compare_date: dt.date,
    ) -> str:
        """Style and wrap the delta DataFrame as HTML."""
        calendar_today = dt.date.today()
        history_future_rule_label = _first_delivery_label_after(df.index, calendar_today)

        styles = [
            {"selector": "table", "props": [
                ("border-collapse", "collapse"),
                ("font-family", "Calibri, Arial, sans-serif"),
                ("font-size", "13px"),
                ("width", "100%"),
                ("border", "1px solid #ddd"),
            ]},
            {"selector": "th", "props": [
                ("background-color", "#f2f2f2"),
                ("color", "#333"),
                ("border", "1px solid #999"),
                ("padding", "4px 2px"),
                ("text-align", "center"),
                ("font-weight", "bold"),
                ("font-size", "10px"),
            ]},
            {"selector": "td", "props": [
                ("border", "1px solid #ddd"),
                ("padding", "2px"),
                ("text-align", "center"),
                ("font-size", "11px"),
            ]},
            {"selector": "tr:hover", "props": [("background-color", "#f5f5f5")]},
        ]

        def highlight_nan(val):
            return "background-color: #e0e0e0 !important" if pd.isna(val) else ""

        def split_row_border(row: pd.Series):
            if history_future_rule_label is not None and str(row.name) == history_future_rule_label:
                return ["border-top: 3px dashed #333 !important"] * len(row)
            return [""] * len(row)

        styler = df.style.apply_index(_weekend_delivery_date_index_styles, axis=0)

        # Apply a diverging scale per metric column, centred at 0
        for col in df.columns:
            metric = col[1]
            vals = pd.to_numeric(df[col], errors="coerce").dropna()
            if vals.empty:
                continue
            max_abs = float(vals.abs().max())
            if max_abs < 1e-6:
                continue

            # Choose colormap by metric semantics (same logic as normal table)
            if metric in FUND_DEMAND_ROWS:
                # Demand/residual load: positive delta = more demand = tighter = red
                cmap = "RdYlGn_r"
            elif metric == GAS_GEN_METRIC:
                cmap = "RdYlGn_r"
            elif metric == NET_EXPORT_METRIC:
                cmap = "RdYlGn_r"
            else:
                # Supply (solar, wind, nuclear, hydro, coal, lignite): positive = more supply = green
                cmap = "RdYlGn"

            styler = styler.background_gradient(
                cmap=cmap,
                subset=pd.IndexSlice[:, [col]],
                vmin=-max_abs,
                vmax=max_abs,
            )

        # Sign-prefixed format for all delta columns
        fmt_dict = {col: "{:+,.0f}" for col in df.columns}

        styler = (
            styler.apply(split_row_border, axis=1)
            .map(highlight_nan)
            .format(fmt_dict, na_rep="")
            .set_table_styles(styles)
            .set_properties(**{"min-width": "52px", "max-width": "96px"})
        )

        table_html = styler.to_html(sparse_index=True, sparse_columns=True)
        table_html = self._style_block_header_row(table_html)

        title = (
            f"Δ Fundamentals · {zone} · "
            f"issue {issue_date} − compare {compare_date} "
            f"(positive = higher on issue date)"
        )
        return self._wrap_html(table_html, title=title)

    def generate_region(
        self,
        mats_by_zone: dict[str, pd.DataFrame],
        *,
        issue_date: dt.date,
        hist_days: int,
        fwd_days: int,
    ) -> str:
        """Render a region-aggregated table over multiple zones.

        * Fundamental rows are summed element-wise across all selected zones
          (one column per metric, like the single-zone view).  Note: "Net Export"
          is excluded from the region view as summing it across countries
          is not meaningful due to internal flows.
        * Per-zone price metrics — Spot, CSS, CDS, Heat rate — get one column
          per zone, labelled ``Metric · ZONE``.
        * TTF and EUA are zonal-independent fuel/carbon prices and are shown
          once with the bare metric name (the values are taken from the first
          available zone's matrix).

        ``mats_by_zone`` is keyed by zone code (e.g. ``"DE"``) and each value is
        a matrix from ``build_balance_matrix`` (rows=metrics, columns=dates).
        """
        try:
            zones = [z for z, m in mats_by_zone.items() if m is not None and not m.empty]
            if not zones:
                return self._error_html("No data for any selected zone — check S3 cache / jain_commods")

            # Determine the common delivery-date column index by union, sorted.
            cal = None
            for z in zones:
                cols = pd.to_datetime(mats_by_zone[z].columns).normalize()
                cal = cols if cal is None else cal.union(cols)
            cal = pd.DatetimeIndex(sorted(cal))

            # Per-zone-shared price metrics rendered once
            shared_price_metrics = ("TTF", "EUA")
            per_zone_price_metrics = tuple(
                m for m in PRICE_ROWS if m not in shared_price_metrics
            )

            data: dict[tuple[str, str], pd.Series] = {}

            # ── Per-zone price columns (Spot, CSS, CDS, Heat rate × zone) ────
            for metric in per_zone_price_metrics:
                for z in zones:
                    mat = mats_by_zone[z]
                    if metric not in mat.index:
                        continue
                    s = pd.to_numeric(mat.loc[metric], errors="coerce")
                    s.index = pd.to_datetime(s.index).normalize()
                    s = s.reindex(cal)
                    label = f"{metric} · {z}"
                    data[(BLOCK_PRICE, label)] = s

            # ── Shared price columns (TTF, EUA) — one column total ───────────
            for metric in shared_price_metrics:
                for z in zones:
                    mat = mats_by_zone[z]
                    if metric in mat.index:
                        s = pd.to_numeric(mat.loc[metric], errors="coerce")
                        s.index = pd.to_datetime(s.index).normalize()
                        s = s.reindex(cal)
                        if s.notna().any():
                            data[(BLOCK_PRICE, metric)] = s
                            break

            # ── Fundamental columns: element-wise sum across zones ───────────
            for metric in FUND_ROWS:
                if metric == NET_EXPORT_METRIC:
                    continue
                aligned: list[pd.Series] = []
                for z in zones:
                    mat = mats_by_zone[z]
                    if metric not in mat.index:
                        continue
                    s = pd.to_numeric(mat.loc[metric], errors="coerce")
                    s.index = pd.to_datetime(s.index).normalize()
                    aligned.append(s.reindex(cal))
                if not aligned:
                    continue
                stacked = pd.concat(aligned, axis=1)
                # Sum: skip NaNs unless every zone is NaN for that date (then keep NaN)
                any_present = stacked.notna().any(axis=1)
                summed = stacked.sum(axis=1, min_count=1)
                summed = summed.where(any_present)
                data[(BLOCK_FUNDAMENTAL, metric)] = summed

            if not data:
                return self._error_html("No common metrics across the selected zones")

            df = pd.DataFrame(data, index=cal)
            df.index.name = "Delivery date"
            df.columns = pd.MultiIndex.from_tuples(df.columns.tolist(), names=[None, None])

            # Order columns: per-zone prices grouped by metric, then shared, then fundamentals
            ordered: list[tuple[str, str]] = []
            for metric in per_zone_price_metrics:
                for z in zones:
                    c = (BLOCK_PRICE, f"{metric} · {z}")
                    if c in df.columns:
                        ordered.append(c)
            for metric in shared_price_metrics:
                c = (BLOCK_PRICE, metric)
                if c in df.columns:
                    ordered.append(c)
            for metric in FUND_ROWS:
                c = (BLOCK_FUNDAMENTAL, metric)
                if c in df.columns:
                    ordered.append(c)
            df = df.reindex(columns=ordered)

            df = _drop_uninformative_metric_columns(df)
            if df.empty or len(df.columns) == 0:
                return self._error_html("All metrics empty across selected zones")

            df.index = df.index.map(lambda t: pd.Timestamp(t).strftime("%Y-%m-%d"))

            return self._generate_region_html(
                df,
                zones=zones,
                issue_date=issue_date,
                hist_days=hist_days,
                fwd_days=fwd_days,
            )
        except Exception as e:
            logger.error("Region table error: %s", e, exc_info=True)
            return self._error_html(str(e))

    def _generate_region_html(
        self,
        df: pd.DataFrame,
        *,
        zones: list[str],
        issue_date: dt.date,
        hist_days: int,
        fwd_days: int,
    ) -> str:
        """Style + wrap the region-aggregated DataFrame as HTML.

        Reuses the same column-wise gradient logic as the single-zone table:
        prices high → red, supply gen high → green (gas/net-export inverted),
        demand/load high → red.
        """
        calendar_today = dt.date.today()
        history_future_rule_label = _first_delivery_label_after(df.index, calendar_today)

        df = df.copy()
        df.columns.names = [None, None]

        price_cols = [c for c in df.columns if c[0] == BLOCK_PRICE]
        # Strip " · ZONE" suffix to recover the metric name for fund-row classification
        def _bare_metric(col: tuple[str, str]) -> str:
            label = col[1]
            return label.split(" · ", 1)[0]

        supply_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL
            and _bare_metric(c) in FUND_SUPPLY_ROWS
            and _bare_metric(c) != NET_EXPORT_METRIC
            and _bare_metric(c) != GAS_GEN_METRIC
        ]
        net_export_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL and _bare_metric(c) == NET_EXPORT_METRIC
        ]
        gas_gen_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL and _bare_metric(c) == GAS_GEN_METRIC
        ]
        demand_cols = [
            c for c in df.columns
            if c[0] == BLOCK_FUNDAMENTAL and _bare_metric(c) in FUND_DEMAND_ROWS
        ]

        styles = [
            {"selector": "table", "props": [
                ("border-collapse", "collapse"),
                ("font-family", "Calibri, Arial, sans-serif"),
                ("font-size", "13px"),
                ("width", "100%"),
                ("border", "1px solid #ddd"),
            ]},
            {"selector": "th", "props": [
                ("background-color", "#f2f2f2"),
                ("color", "#333"),
                ("border", "1px solid #999"),
                ("padding", "4px 2px"),
                ("text-align", "center"),
                ("font-weight", "bold"),
                ("font-size", "10px"),
            ]},
            {"selector": "td", "props": [
                ("border", "1px solid #ddd"),
                ("padding", "2px"),
                ("text-align", "center"),
                ("font-size", "11px"),
            ]},
            {"selector": "tr:hover", "props": [("background-color", "#f5f5f5")]},
        ]

        def highlight_nan(val):
            return "background-color: #e0e0e0 !important" if pd.isna(val) else ""

        def split_row_border(row: pd.Series):
            if history_future_rule_label is not None and str(row.name) == history_future_rule_label:
                return ["border-top: 3px dashed #333 !important"] * len(row)
            return [""] * len(row)

        styler = df.style.apply_index(_weekend_delivery_date_index_styles, axis=0)
        if price_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, price_cols],
            )
        if supply_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn",
                axis=0,
                subset=pd.IndexSlice[:, supply_cols],
            )
        if gas_gen_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, gas_gen_cols],
            )
        if net_export_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, net_export_cols],
            )
        if demand_cols:
            styler = styler.background_gradient(
                cmap="RdYlGn_r",
                axis=0,
                subset=pd.IndexSlice[:, demand_cols],
            )

        # Region-aware number formats: any column whose bare metric is a price
        # uses 2 decimals; everything else uses 0-decimal MW formatting.
        fmt_dict: dict = {}
        for col in df.columns:
            bare = _bare_metric(col)
            if bare in _PRICE_TWO_DEC:
                fmt_dict[col] = "{:.2f}"
            else:
                fmt_dict[col] = "{:,.0f}"

        styler = (
            styler.apply(split_row_border, axis=1)
            .map(highlight_nan)
            .format(fmt_dict, na_rep="")
            .set_table_styles(styles)
            .set_properties(**{"min-width": "52px", "max-width": "96px"})
        )

        table_html = styler.to_html(sparse_index=True, sparse_columns=True)
        table_html = self._style_block_header_row(table_html)
        table_html = self._inject_price_fundamental_separator(table_html, len(price_cols))

        zones_str = " + ".join(zones)
        title = f"Region balance · {zones_str} · issue {issue_date}"
        return self._wrap_html(table_html, title=title)

    def _error_html(self, message: str) -> str:
        return f"""
        <div style="padding: 40px; text-align: center; color: #666;">
            <h3>{message}</h3>
        </div>
        """
