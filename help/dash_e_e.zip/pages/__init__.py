"""Dash multi-page modules for the Power portal."""
