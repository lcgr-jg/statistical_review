"""Iberia / OMIE -- Dash page registrar.

All implementation lives in :mod:`core.iberia` (constants / data / figures /
layout / callbacks), mirroring :mod:`core.microstructure`. This file only:
    1. registers the Dash page so it appears in the sidebar,
    2. exposes ``layout`` for ``use_pages`` to mount,
    3. imports ``callbacks`` for its registration side-effect.

NOTE: this module is intentionally named ``_iberia.py`` so Dash's ``use_pages``
auto-discovery **skips** it (it ignores ``_``-prefixed files) -- i.e. the
Iberia / OMIE page is currently *unlinked* from the portal. The code is kept
intact. To re-link it: rename this file back to ``pages/iberia.py`` and restore
the ``("Iberia · OMIE", ["Iberia / OMIE"])`` entry in ``SIDEBAR_GROUPS`` in
``portal_app.py``.
"""
from __future__ import annotations

import dash

from core.iberia import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.iberia.constants import PAGE_PATH, PAGE_NAME, PAGE_TITLE, PAGE_ORDER
from core.iberia.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()

__all__ = ["layout"]
