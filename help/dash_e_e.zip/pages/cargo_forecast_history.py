"""
LNG — Cargo Forecast History page registrar.

Implementation lives in ``core.cargo_forecast_history``:
    * data      -- PIT snapshot history + live vessels / Bloomberg position
    * render    -- headline, forecast table, AIS map, Kpler link
    * layout    -- ``build_layout()``
    * callbacks -- registered on import
"""
from __future__ import annotations

import dash

from core.cargo_forecast_history import callbacks as _callbacks  # noqa: F401
from core.cargo_forecast_history.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.cargo_forecast_history.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)


def layout(**_kwargs):
    """Rebuilt on every visit so the vessel list tracks the latest snapshot."""
    return build_layout()
