"""
LNG — Arrivals vs Regas page registrar.

Implementation lives in ``core.arrivals_regas``:
    * data      -- Kpler PIT arrivals counts + CE regas / storage combine
    * render    -- storage-bucketed scatter figure
    * layout    -- ``build_layout()``
    * callbacks -- registered on import
"""
from __future__ import annotations

import dash

from core.arrivals_regas import callbacks as _callbacks  # noqa: F401
from core.arrivals_regas.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.arrivals_regas.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
