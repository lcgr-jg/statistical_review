"""
European Power Fuel Switching Dashboard - Dash page registrar.

All implementation lives in ``core.fuel_switching``:
    * data       -- ``MarketDataCache`` data model + ``market_cache`` singleton
    * compute    -- pure SRMC math (``FuelSwitchingCalculator``)
    * charts     -- plotly figure builders
    * layout     -- ``build_layout()``
    * callbacks  -- all Dash callbacks (registered on import)

This file's only jobs are:
    1. register the Dash page,
    2. expose the page-level ``layout`` Dash expects,
    3. import ``callbacks`` for its registration side-effect,
    4. re-export public names that other modules (e.g. ``portal_app``) import.
"""

import dash

from core.fuel_switching.layout import build_layout
from core.fuel_switching import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.fuel_switching.data import market_cache, load_market_data
from core.fuel_switching.compute import calculator
from core.fuel_switching.constants import (
    API2_TO_MWH,
    CHART_FONT,
    CHART_TEMPLATE,
    COLORS,
)


dash.register_page(
    __name__,
    path='/',
    name='Fuel Switching',
    title='Fuel Switching | JG Power Dashboard',
    order=1,
)

layout = build_layout()


__all__ = [
    "market_cache",
    "load_market_data",
    "calculator",
    "CHART_TEMPLATE",
    "CHART_FONT",
    "API2_TO_MWH",
    "COLORS",
    "layout",
]
