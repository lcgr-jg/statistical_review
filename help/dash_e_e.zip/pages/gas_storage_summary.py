"""
EU Gas Balance — Storage Summary page registrar.

Implementation lives in ``core.gas_storage_summary``:
    * data       -- CE injection frame from ``gas_data_ce`` cache
    * table      -- daily activity HTML table
    * sefe       -- SEFE site tracker (flows, fill, cumulative)
    * sefe_availability -- curve capability vs CE maintenance
    * charts     -- Daily Storage Action Plotly figure
    * layout     -- ``build_layout()``
    * callbacks  -- registered on import
"""
from __future__ import annotations

import dash

from core.gas_storage_summary import callbacks as _callbacks  # noqa: F401
from core.gas_storage_summary.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.gas_storage_summary.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
