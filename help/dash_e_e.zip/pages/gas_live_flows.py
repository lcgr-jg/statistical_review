"""
EU Gas Balance — Live Flows page registrar.

Implementation lives in ``core.gas_live_flows``:
    * data       -- CE regas/flows from ``gas_data_ce`` cache + BBG feedgas
    * table      -- REGAS / FLOWS / US LNG HTML tables
    * layout     -- ``build_layout()``
    * callbacks  -- registered on import
"""
from __future__ import annotations

import dash

from core.gas_live_flows import callbacks as _callbacks  # noqa: F401
from core.gas_live_flows.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.gas_live_flows.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
