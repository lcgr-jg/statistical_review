"""
Flow-Based — Dash page registrar.

All implementation lives in ``core.flowbased``:
    * data       -- ``load_flowbased_data`` + cache helpers
    * layout     -- ``build_layout()``
    * callbacks  -- MaxBex tab callback (registered on import)

This file's only jobs are:
    1. register the Dash page,
    2. expose the page-level ``layout`` Dash expects,
    3. import ``callbacks`` for its registration side-effect,
    4. re-export public names that other modules import.
"""
from __future__ import annotations

import dash

from core.flowbased import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.flowbased.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.flowbased.data import clear_flowbased_cache, load_flowbased_data
from core.flowbased.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()

__all__ = [
    "clear_flowbased_cache",
    "layout",
    "load_flowbased_data",
]
