"""Clean Spark / Clean Dark Spreads - Dash page registrar.

Implementation lives in ``core.clean_spreads``:
    * constants -- page wiring, efficiencies, UK market conventions
    * data      -- curve building, snapshots, UK 49.13% re-efficiency,
                   delivered + forward merges, hedge-ratio math
    * tables    -- DoD/WoW/MoM heat-shaded change tables
    * charts    -- curve, delivered-vs-forward, seasonality, UK figures
    * layout    -- build_layout()
    * callbacks -- registered on import

Data comes from the warm ``price_data`` scheduler source (same bundle as
the Spot vs Forward page); no additional loader is registered.
"""
from __future__ import annotations

import dash

from core.clean_spreads import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.clean_spreads.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.clean_spreads.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
