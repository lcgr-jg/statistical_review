"""
Generation Dashboard - Multi-page integration
=============================================
Per-unit generation analytics for the thermal fleet.

Sub-pages:
    * Run-state Gantt           — htop-style state grid (#4)
    * Trajectory YoY            — cumulative ∑|ΔG| ribbon w/ P10–P90 + intensity (#6+#7)
    * Co-cycling Correlation    — force-directed graph of ΔG correlations (#18)
"""
from __future__ import annotations

import logging

import dash
from dash import Input, Output, callback, dcc, html

from portal_pages.fundamentals.styles import COLORS

logger = logging.getLogger(__name__)


# Register as Dash page.
# DISABLED: page hidden from the dashboard. Re-enable by restoring register_page().
if False and __name__ != "__main__":
    dash.register_page(
        __name__,
        path="/power/generation",
        name="Generation",
        title="Generation | JG Power Dashboard",
        order=11,
    )


# ---------------------------------------------------------------------------
# Lazy imports & sub-page management
# ---------------------------------------------------------------------------
_data_handler = None
_sub_pages_loaded = False
_sub_page_modules = {}


def _get_data_handler():
    """Return singleton DataHandler from global cache."""
    from core.cache import dashboard_cache
    handler = dashboard_cache.get("source:generation_data")
    if handler is None:
        from portal_pages.generation.data_handler import GenerationDataHandler
        handler = GenerationDataHandler()
    return handler


def _ensure_loaded():
    """Lazy-load the sub-page modules on first access."""
    global _sub_pages_loaded, _sub_page_modules
    if _sub_pages_loaded:
        return
    try:
        from portal_pages.generation.run_state import get_layout as get_run_state_layout
        from portal_pages.generation.trajectory import get_layout as get_trajectory_layout
        from portal_pages.generation.correlation import get_layout as get_correlation_layout
        _sub_page_modules["run_state"] = get_run_state_layout
        _sub_page_modules["trajectory"] = get_trajectory_layout
        _sub_page_modules["correlation"] = get_correlation_layout
        _sub_pages_loaded = True
        logger.info("Generation sub-pages loaded successfully")
    except Exception as exc:
        logger.error(f"Failed to load Generation sub-pages: {exc}")


def initialize_generation_callbacks(app):
    """Register all generation callbacks once at startup."""
    handler = _get_data_handler()
    from portal_pages.generation.run_state import register_callbacks as register_rs
    from portal_pages.generation.trajectory import register_callbacks as register_tr
    from portal_pages.generation.correlation import register_callbacks as register_corr

    cb_keys = set(app.callback_map.keys())
    if any("gen-rs-graph.figure" in k for k in cb_keys):
        logger.warning("Generation callbacks already present. Skipping.")
        return

    register_rs(app, handler)
    register_tr(app, handler)
    register_corr(app, handler)
    logger.info("Generation callbacks initialized at startup")


# ---------------------------------------------------------------------------
# Sub-page definitions
# ---------------------------------------------------------------------------
SUB_PAGES = [
    {"key": "run_state",   "label": "Run-state Gantt",        "icon": "\u25A6"},
    {"key": "trajectory",  "label": "Trajectory YoY",         "icon": "\U0001F4C8"},
    {"key": "correlation", "label": "Co-cycling Correlation", "icon": "\u22C8"},
]


# ---------------------------------------------------------------------------
# Inline styles (match the heatrate page for visual consistency)
# ---------------------------------------------------------------------------
_TAB_BAR_STYLE = {
    "display": "flex",
    "gap": "0",
    "borderBottom": f"2px solid {COLORS['border']}",
    "backgroundColor": COLORS["card_bg"],
    "padding": "0 24px",
    "boxShadow": "0 1px 2px rgba(0,0,0,0.03)",
}
_TAB_BTN_STYLE = {
    "padding": "14px 22px",
    "border": "none",
    "borderBottom": "3px solid transparent",
    "backgroundColor": "transparent",
    "color": COLORS["text_secondary"],
    "fontSize": "13px",
    "fontWeight": "500",
    "cursor": "pointer",
    "transition": "all 0.2s",
    "fontFamily": "Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
    "letterSpacing": "0.2px",
    "whiteSpace": "nowrap",
}


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
layout = html.Div(
    style={"minHeight": "100vh", "backgroundColor": COLORS["background"]},
    children=[
        dcc.Store(id="generation-active-tab", data="run_state"),
        html.Div(
            style=_TAB_BAR_STYLE,
            children=[
                html.Button(
                    f"{sp['icon']}  {sp['label']}",
                    id={"type": "generation-tab-btn", "index": sp["key"]},
                    n_clicks=0,
                    style=_TAB_BTN_STYLE,
                )
                for sp in SUB_PAGES
            ],
        ),
        html.Div(
            id="generation-sub-content",
            style={"minHeight": "500px", "padding": "24px 28px"},
        ),
    ],
)


# ---------------------------------------------------------------------------
# Callback: switch sub-pages
# ---------------------------------------------------------------------------
@callback(
    Output("generation-sub-content", "children"),
    [Input({"type": "generation-tab-btn", "index": sp["key"]}, "n_clicks")
     for sp in SUB_PAGES],
    prevent_initial_call=False,
)
def switch_generation_tab(*_n_clicks):
    ctx = dash.callback_context
    triggered_id = "run_state"
    if ctx.triggered and ctx.triggered[0]["prop_id"] != ".":
        import json
        prop_id = ctx.triggered[0]["prop_id"]
        try:
            btn_id = json.loads(prop_id.rsplit(".", 1)[0])
            triggered_id = btn_id.get("index", "run_state")
        except (json.JSONDecodeError, KeyError):
            pass

    _ensure_loaded()
    if not _sub_pages_loaded:
        return html.Div("Loading Generation sub-pages…")

    handler = _get_data_handler()
    try:
        get_layout_fn = _sub_page_modules.get(triggered_id)
        if get_layout_fn:
            return get_layout_fn(handler)
        return html.Div(f"Sub-page '{triggered_id}' not found.")
    except Exception as exc:
        logger.error(f"Error rendering Generation sub-page '{triggered_id}': {exc}")
        return html.Div(f"Error loading {triggered_id}: {exc}")
