"""
Prices Dashboard - Multi-page integration
==========================================
Electricity market analytics: CSS/DSS, flat price, XB spreads, base/peak, spot.

IMPORTANT: Sub-page callbacks MUST be registered at module import time
(before the Dash client fetches /_dash-dependencies). Callbacks registered
lazily inside another callback are invisible to the client and will never fire.

We solve this by:
1. Creating a shared mutable dict (_shared_data) at module level.
2. Registering all sub-page callbacks at import time with _shared_data.
   - Callbacks reference _shared_data by closure, so they always see the latest values.
3. Populating _shared_data lazily on first page access via _ensure_data_loaded().
"""
import dash
from dash import html, dcc, Input, Output, callback
import dash_bootstrap_components as dbc
import logging

logger = logging.getLogger(__name__)

# Register as Dash page (only when running in multi-page mode)
if __name__ != '__main__':
    dash.register_page(
        __name__,
        path='/power/prices',
        name='Spot vs Forward',
        title='Spot vs Forward | JG Power Dashboard',
        order=3,
    )

# ---------------------------------------------------------------------------
# Shared mutable data dict - sub-page callbacks reference this via closure.
# It is populated in-place from `core.data.get_prices()` on first access.
# Keeping this dict object stable is a hard requirement: the sub-page
# callbacks were registered with a reference to it at import time.
# ---------------------------------------------------------------------------
_shared_data: dict = {}
_sub_page_modules: dict = {}


def _ensure_data_loaded():
    """Populate `_shared_data` from the central data service on first access."""
    if _shared_data:
        return

    try:
        from core import data as data_service

        loaded = data_service.get_prices()
        if loaded:
            _shared_data.update(loaded)

        from portal_pages.prices.css_dss import get_layout as get_css_dss_layout
        from portal_pages.prices.flat_price import get_layout as get_flat_price_layout
        from portal_pages.prices.xb_spreads import get_layout as get_xb_spreads_layout
        from portal_pages.prices.base_peak import get_layout as get_base_peak_layout
        from portal_pages.prices.spot import get_layout as get_spot_layout
        from portal_pages.prices.weekly import get_layout as get_weekly_layout
        from portal_pages.prices.heatrate_adjustment import get_layout as get_heatrate_adjustment_layout

        _sub_page_modules['css_dss'] = get_css_dss_layout
        _sub_page_modules['flat_price'] = get_flat_price_layout
        _sub_page_modules['xb_spreads'] = get_xb_spreads_layout
        _sub_page_modules['base_peak'] = get_base_peak_layout
        _sub_page_modules['spot'] = get_spot_layout
        _sub_page_modules['weekly'] = get_weekly_layout
        _sub_page_modules['heatrate_adjustment'] = get_heatrate_adjustment_layout

        if _shared_data:
            logger.info("Prices data loaded and sub-pages ready")
    except Exception as e:
        logger.error(f"Failed to load prices data: {e}")
        import traceback
        traceback.print_exc()


# ---------------------------------------------------------------------------
# Register sub-page callbacks at MODULE IMPORT TIME so they are included
# in the Dash dependency graph before the client fetches /_dash-dependencies.
# ---------------------------------------------------------------------------
def _register_all_callbacks():
    """Register all price sub-page callbacks eagerly at import time."""
    try:
        current_app = dash.get_app()

        from portal_pages.prices.css_dss import register_css_dss_callbacks
        from portal_pages.prices.flat_price import register_flat_price_callbacks
        from portal_pages.prices.xb_spreads import register_xb_spreads_callbacks
        from portal_pages.prices.base_peak import register_base_peak_callbacks
        from portal_pages.prices.spot import register_spot_callbacks
        from portal_pages.prices.weekly import register_weekly_callbacks
        from portal_pages.prices.heatrate_adjustment import register_heatrate_adjustment_callbacks

        register_css_dss_callbacks(current_app, _shared_data)
        register_flat_price_callbacks(current_app, _shared_data)
        register_xb_spreads_callbacks(current_app, _shared_data)
        register_base_peak_callbacks(current_app, _shared_data)
        register_spot_callbacks(current_app, _shared_data)
        register_weekly_callbacks(current_app, _shared_data)
        register_heatrate_adjustment_callbacks(current_app, _shared_data)

        logger.info("Prices sub-page callbacks registered successfully")
    except Exception as e:
        logger.error(f"Failed to register price callbacks: {e}")
        import traceback
        traceback.print_exc()


if __name__ != '__main__':
    _register_all_callbacks()


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
SUB_PAGES = [
    {'key': 'css_dss', 'label': 'CSS / DSS', 'icon': '📉'},
    {'key': 'flat_price', 'label': 'Flat Price', 'icon': '💶'},
    {'key': 'xb_spreads', 'label': 'XB Spreads', 'icon': '↔️'},
    {'key': 'base_peak', 'label': 'Base / Peak', 'icon': '📊'},
    {'key': 'spot', 'label': 'Spot', 'icon': '⚡'},
    {'key': 'weekly', 'label': 'Weekly', 'icon': '📅'},
    {'key': 'heatrate_adjustment', 'label': 'Heat Rate Adjustment', 'icon': '🔥'},
]

layout = html.Div([
    dcc.Store(id='prices-active-tab', data='css_dss'),
    # Global app-state store for price dashboard pages
    dcc.Store(id='app-state', data={
        'flat_time_range': '6M',
        'xb_time_range': '6M',
    }),

    # Sub-page tab bar
    html.Div(
        style={
            'display': 'flex',
            'gap': '0',
            'borderBottom': '2px solid #2c3e50',
            'backgroundColor': '#f8f9fa',
            'padding': '0 20px',
        },
        children=[
            html.Button(
                f"{sp['icon']}  {sp['label']}",
                id={'type': 'prices-tab-btn', 'index': sp['key']},
                n_clicks=0,
                style={
                    'padding': '14px 24px',
                    'border': 'none',
                    'borderBottom': '3px solid transparent',
                    'backgroundColor': 'transparent',
                    'color': '#495057',
                    'fontSize': '14px',
                    'fontWeight': '500',
                    'cursor': 'pointer',
                    'transition': 'all 0.2s',
                    'fontFamily': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                },
            )
            for sp in SUB_PAGES
        ],
    ),

    # Loading spinner
    dcc.Loading(
        id='prices-loading',
        type='circle',
        color='#2c3e50',
        children=[html.Div(id='prices-sub-content', style={'minHeight': '400px'})],
    ),
])


# ---------------------------------------------------------------------------
# Callback: switch sub-pages
# ---------------------------------------------------------------------------
@callback(
    Output('prices-sub-content', 'children'),
    [Input({'type': 'prices-tab-btn', 'index': sp['key']}, 'n_clicks') for sp in SUB_PAGES],
    prevent_initial_call=False,
)
def switch_prices_tab(*n_clicks):
    ctx = dash.callback_context
    triggered_id = 'css_dss'  # Default to CSS/DSS instead of home

    if ctx.triggered and ctx.triggered[0]['prop_id'] != '.':
        import json
        prop_id = ctx.triggered[0]['prop_id']
        try:
            btn_id = json.loads(prop_id.rsplit('.', 1)[0])
            triggered_id = btn_id.get('index', 'css_dss')
        except (json.JSONDecodeError, KeyError):
            pass

    _ensure_data_loaded()

    if not _shared_data:
        return html.Div(
            style={'padding': '60px', 'textAlign': 'center'},
            children=[
                html.H2("⏳ Loading Price Data...", style={'color': '#2c3e50'}),
                html.P(
                    "Data is being loaded from Snowflake. This may take a moment on first load.",
                    style={'color': '#7f8c8d', 'fontSize': '16px'},
                ),
            ],
        )

    try:
        get_layout_fn = _sub_page_modules.get(triggered_id) or _sub_page_modules.get('css_dss')
        if get_layout_fn is None:
            return html.Div("Sub-page modules not loaded. Please refresh.", style={'padding': '40px', 'color': '#e74c3c'})
        return get_layout_fn(_shared_data)
    except Exception as e:
        logger.error(f"Error rendering prices sub-page '{triggered_id}': {e}")
        return html.Div(
            style={'padding': '40px'},
            children=[
                html.H3(f"⚠️ Error loading {triggered_id}", style={'color': '#e74c3c'}),
                html.Pre(str(e), style={
                    'backgroundColor': '#f8f9fa',
                    'padding': '15px',
                    'borderRadius': '6px',
                    'fontSize': '13px',
                    'color': '#495057',
                    'whiteSpace': 'pre-wrap',
                }),
            ],
        )


