"""
Carbon Switching — Dash page registrar.

Self-contained Plotly HTML built by eu_carbon's switching monitor and pushed
via ``POST /api/carbon/upload/switching`` (see ``core.carbon_static``).
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/switching",
    name=CARBON_PAGES["switching"],
    title="Carbon Switching | JG Power Dashboard",
    order=63,
)

layout = iframe_page_layout("switching")
