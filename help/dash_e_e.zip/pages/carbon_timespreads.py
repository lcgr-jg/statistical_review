"""
Carbon Timespreads — Dash page registrar.

The dashboard itself is a self-contained Plotly HTML file built by the
eu_carbon repo's scheduled timespread-monitor job and pushed here via
``POST /api/carbon/upload/timespreads`` (see ``core.carbon_static``). This
page just frames the latest pushed file.
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/timespreads",
    name=CARBON_PAGES["timespreads"],
    title="Carbon Timespreads | JG Power Dashboard",
    order=61,
)

layout = iframe_page_layout("timespreads")
