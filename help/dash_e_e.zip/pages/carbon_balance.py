"""
Carbon Balance — Dash page registrar.

Self-contained Plotly HTML built by eu_carbon's daily power-balance job and
pushed via ``POST /api/carbon/upload/balance`` (see ``core.carbon_static``).
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/balance",
    name=CARBON_PAGES["balance"],
    title="Carbon Balance | JG Power Dashboard",
    order=58,
)

layout = iframe_page_layout("balance")
