"""
Other Nuclear — now a sub-tab of the Nuclear Availability page.

The standalone page registration has been removed: Other Nuclear is rendered
as a tab inside ``core/french_nuclear`` (see ``render_tab_content``).  This
file is left in place so Dash's pages discovery does not error, but it no
longer calls ``dash.register_page``.  Callbacks live in
``core.other_nuclear.callbacks`` and are imported by
``core.french_nuclear.callbacks`` for registration side-effects.
"""
from __future__ import annotations
