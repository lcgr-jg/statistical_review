"""
LNG — Arrivals History page registrar.

Implementation lives in ``core.arrivals_history``:
    * data      -- cache-only arrivals aggregates from the PIT snapshot store
    * render    -- history-window and year-on-year figures
    * layout    -- ``build_layout()``
    * callbacks -- registered on import
"""
from __future__ import annotations

import dash

from core.arrivals_history import callbacks as _callbacks  # noqa: F401
from core.arrivals_history.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.arrivals_history.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
