import dash
from dash import dcc, html, callback, Input, Output, State, dash_table, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from datetime import date
import logging
import traceback

from core.cache import cached_result
from core.styles import (
    COLORS, PAGE_CONTAINER_STYLE, CARD_STYLE, PAGE_HEADER_STYLE,
    SUBHEADER_STYLE, BUTTON_PRIMARY_STYLE, DROPDOWN_STYLE,
    DATA_TABLE_STYLE_HEADER, DATA_TABLE_STYLE_CELL, DATA_TABLE_STYLE_DATA,
    DATA_TABLE_CONDITIONAL_STYLES, get_chart_layout,
)

dash.register_page(
    __name__,
    path='/power/yoy_availability',
    name='YoY Availability',
    title='YoY Availability | JG Power Dashboard',
    order=7,
)

logger = logging.getLogger(__name__)

FUEL_TYPE_MAP = {
    'Nuclear': 'GenAvailPerUnitNuclear',
    'Coal': 'GenAvailPerUnitCoal',
    'Gas': 'GenAvailPerUnitGas',
    'Lignite': 'GenAvailPerUnitLignite',
    'Biomass': 'GenAvailPerUnitBiomass',
    'Hydro PS': 'GenAvailPerUnitHydroPS',
}

GENERATION_FUEL_MAP = {
    'Nuclear': 'nuclear',
    'Coal': 'coal',
    'Gas': 'gas',
    'Lignite': 'lignite',
    'Biomass': 'biomass',
    'Hydro PS': 'hydro_ps',
}

COUNTRY_OPTIONS = [
    {'label': 'France', 'value': 'FR'},
    {'label': 'Germany', 'value': 'DE'},
    {'label': 'Belgium', 'value': 'BE'},
    {'label': 'Netherlands', 'value': 'NL'},
    {'label': 'Great Britain', 'value': 'GB'},
    {'label': 'Spain', 'value': 'ES'},
    {'label': 'Italy', 'value': 'IT'},
    {'label': 'Poland', 'value': 'PL'},
    {'label': 'Czech Republic', 'value': 'CZ'},
    {'label': 'Austria', 'value': 'AT'},
    {'label': 'Switzerland', 'value': 'CH'},
    {'label': 'Sweden', 'value': 'SE'},
    {'label': 'Finland', 'value': 'FI'},
    {'label': 'Norway', 'value': 'NO'},
]

_current_year = date.today().year
YEAR_OPTIONS = [{'label': str(y), 'value': y} for y in range(_current_year, _current_year - 6, -1)]

LOAD_FACTOR_YEAR_COLORS = {
    'previous': '#f97316',
    'current': '#2563eb',
}


@cached_result(ttl=1800, prefix="yoy_per_unit_avail")
def _load_per_unit_avail(country: str, fuel: str, start: date, end: date) -> pd.DataFrame:
    """Load per-unit REMIT availability from cache and return wide DataFrame.

    Returns a DataFrame with DatetimeIndex and one column per unit_id (values in MW).
    """
    from jain_commods.core.cache.data import fundamentals

    cls_name = FUEL_TYPE_MAP[fuel]
    cls = getattr(fundamentals, cls_name)
    instance = cls(zone=country)

    try:
        instance.load(from_s3=True, start_date=start, end_date=end, show_metadata=False)
    except TypeError:
        instance.load(from_s3=True, show_metadata=False)

    if instance.data is None or instance.data.empty:
        try:
            instance.load(from_s3=False, show_metadata=False)
        except Exception:
            pass

    if instance.data is None or instance.data.empty:
        return pd.DataFrame()

    df = instance.data.copy()
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    if df.index.tz is not None:
        df.index = df.index.tz_localize(None)
    df = df.loc[str(start):str(end)]
    return df


@cached_result(ttl=1800, prefix="yoy_per_unit_gen")
def _load_per_unit_generation(country: str, fuel: str, start: date, end: date) -> pd.DataFrame:
    """Load per-unit actual generation from cache and return wide DataFrame.

    Returns a DataFrame with DatetimeIndex and one column per unit_id (values in MW).
    """
    from portal_pages.generation.data_handler import FUEL_CLASSES

    fuel_key = GENERATION_FUEL_MAP[fuel]
    cls = FUEL_CLASSES.get(fuel_key)
    if cls is None:
        return pd.DataFrame()

    instance = cls(zone=country)

    try:
        instance.load(from_s3=True, start_date=start, end_date=end, show_metadata=False)
    except TypeError:
        instance.load(from_s3=True, show_metadata=False)

    if instance.data is None or instance.data.empty:
        try:
            instance.load(from_s3=False, show_metadata=False)
        except Exception:
            pass

    if instance.data is None or instance.data.empty:
        return pd.DataFrame()

    df = instance.data.copy()
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    if df.index.tz is not None:
        df.index = df.index.tz_localize(None)
    df = df.loc[str(start):str(end)]
    return df


def _safe_date(year: int, month: int, day: int) -> date:
    """Clamp day to valid range for month/year (handles Feb 29 on non-leap years)."""
    import calendar
    max_day = calendar.monthrange(year, month)[1]
    return date(year, month, min(day, max_day))


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

_default_end = date.today()
_default_start = date(_default_end.year, _default_end.month, 1)

def layout():
    return html.Div(
        style=PAGE_CONTAINER_STYLE,
        children=[
            html.H2('YoY Unit Availability Waterfall', style=PAGE_HEADER_STYLE),

            html.Div(style=CARD_STYLE, children=[
                dbc.Row([
                    dbc.Col([
                        html.Label('Country', style={'fontWeight': '500', 'marginBottom': '4px'}),
                        dcc.Dropdown(
                            id='yoy-country',
                            options=COUNTRY_OPTIONS,
                            value='FR',
                            clearable=False,
                            style=DROPDOWN_STYLE,
                        ),
                    ], md=2),

                    dbc.Col([
                        html.Label('Fuel Type', style={'fontWeight': '500', 'marginBottom': '4px'}),
                        dcc.Dropdown(
                            id='yoy-fuel',
                            options=[{'label': k, 'value': k} for k in FUEL_TYPE_MAP],
                            value='Nuclear',
                            clearable=False,
                            style=DROPDOWN_STYLE,
                        ),
                    ], md=2),

                    dbc.Col([
                        html.Label('Current Year', style={'fontWeight': '500', 'marginBottom': '4px'}),
                        dcc.Dropdown(
                            id='yoy-year-current',
                            options=YEAR_OPTIONS,
                            value=_current_year,
                            clearable=False,
                            style=DROPDOWN_STYLE,
                        ),
                    ], md=1),

                    dbc.Col([
                        html.Label('Previous Year', style={'fontWeight': '500', 'marginBottom': '4px'}),
                        dcc.Dropdown(
                            id='yoy-year-prev',
                            options=YEAR_OPTIONS,
                            value=_current_year - 1,
                            clearable=False,
                            style=DROPDOWN_STYLE,
                        ),
                    ], md=1),

                    dbc.Col([
                        html.Label('Date Range (month/day)', style={'fontWeight': '500', 'marginBottom': '4px'}),
                        dcc.DatePickerRange(
                            id='yoy-date-range',
                            start_date=_default_start,
                            end_date=_default_end,
                            display_format='DD MMM',
                            style={'width': '100%'},
                        ),
                    ], md=3),

                    dbc.Col([
                        html.Label('Min |delta| MW', style={'fontWeight': '500', 'marginBottom': '4px'}),
                        dcc.Slider(
                            id='yoy-min-delta',
                            min=0, max=500, step=10, value=0,
                            marks={0: '0', 100: '100', 250: '250', 500: '500'},
                            tooltip={'placement': 'bottom', 'always_visible': False},
                        ),
                    ], md=2),

                    dbc.Col([
                        html.Div(style={'height': '22px'}),
                        html.Button(
                            'Calculate',
                            id='yoy-submit',
                            n_clicks=0,
                            style=BUTTON_PRIMARY_STYLE,
                        ),
                    ], md=1, className='d-flex align-items-end'),
                ], className='g-3'),
            ]),

            dcc.Loading(
                id='yoy-loading',
                type='circle',
                children=[
                    html.Div(id='yoy-error', style={'color': COLORS['error'], 'marginBottom': '10px'}),
                    html.Div(id='yoy-chart-container', style=CARD_STYLE, children=[
                        dcc.Graph(id='yoy-waterfall-chart', config={'displayModeBar': True}),
                        html.H4('Filtered Unit Load Factor', style=SUBHEADER_STYLE),
                        dcc.Graph(id='yoy-load-factor-chart', config={'displayModeBar': True}),
                    ]),
                    html.Div(id='yoy-table-container', style=CARD_STYLE, children=[
                        html.H4('Unit-Level Breakdown', style=SUBHEADER_STYLE),
                        dash_table.DataTable(
                            id='yoy-summary-table',
                            columns=[],
                            data=[],
                            style_header=DATA_TABLE_STYLE_HEADER,
                            style_cell=DATA_TABLE_STYLE_CELL,
                            style_data=DATA_TABLE_STYLE_DATA,
                            style_data_conditional=DATA_TABLE_CONDITIONAL_STYLES,
                            sort_action='native',
                            page_size=50,
                            export_format='csv',
                        ),
                    ]),
                ],
            ),
        ],
    )


# ---------------------------------------------------------------------------
# Callback
# ---------------------------------------------------------------------------

@callback(
    Output('yoy-waterfall-chart', 'figure'),
    Output('yoy-load-factor-chart', 'figure'),
    Output('yoy-summary-table', 'data'),
    Output('yoy-summary-table', 'columns'),
    Output('yoy-summary-table', 'style_data_conditional'),
    Output('yoy-error', 'children'),
    Input('yoy-submit', 'n_clicks'),
    State('yoy-country', 'value'),
    State('yoy-fuel', 'value'),
    State('yoy-year-current', 'value'),
    State('yoy-year-prev', 'value'),
    State('yoy-date-range', 'start_date'),
    State('yoy-date-range', 'end_date'),
    State('yoy-min-delta', 'value'),
    prevent_initial_call=True,
)
def update_waterfall(n_clicks, country, fuel, year_curr, year_prev,
                     range_start, range_end, min_delta):
    if not n_clicks:
        return no_update, no_update, no_update, no_update, no_update, ''

    # --- Validation -----------------------------------------------------------
    if year_curr == year_prev:
        return _empty_fig(), _empty_fig(), [], [], DATA_TABLE_CONDITIONAL_STYLES, \
            'Current year and previous year must be different.'

    range_start_dt = pd.Timestamp(range_start)
    range_end_dt = pd.Timestamp(range_end)
    month_start, day_start = range_start_dt.month, range_start_dt.day
    month_end, day_end = range_end_dt.month, range_end_dt.day

    try:
        curr_start = _safe_date(year_curr, month_start, day_start)
        curr_end = _safe_date(year_curr, month_end, day_end)
        prev_start = _safe_date(year_prev, month_start, day_start)
        prev_end = _safe_date(year_prev, month_end, day_end)
    except ValueError as exc:
        return _empty_fig(), _empty_fig(), [], [], DATA_TABLE_CONDITIONAL_STYLES, f'Invalid date range: {exc}'

    overall_start = min(curr_start, prev_start)
    overall_end = max(curr_end, prev_end)

    # --- Load data ------------------------------------------------------------
    try:
        df_wide = _load_per_unit_avail(country, fuel, overall_start, overall_end)
    except Exception:
        logger.error(traceback.format_exc())
        return _empty_fig(), _empty_fig(), [], [], DATA_TABLE_CONDITIONAL_STYLES, \
            f'Failed to load {fuel} availability for {country}. Check cache/S3.'

    if df_wide.empty:
        return _empty_fig(), _empty_fig(), [], [], DATA_TABLE_CONDITIONAL_STYLES, \
            f'No per-unit {fuel} data found for {country}.'

    # --- Slice into two windows and compute mean per unit ---------------------
    mask_curr = (df_wide.index >= pd.Timestamp(curr_start)) & \
                (df_wide.index <= pd.Timestamp(curr_end) + pd.Timedelta(hours=23))
    mask_prev = (df_wide.index >= pd.Timestamp(prev_start)) & \
                (df_wide.index <= pd.Timestamp(prev_end) + pd.Timedelta(hours=23))

    mean_curr = df_wide.loc[mask_curr].mean()
    mean_prev = df_wide.loc[mask_prev].mean()

    all_units = mean_curr.index.union(mean_prev.index)
    mean_curr = mean_curr.reindex(all_units)
    mean_prev = mean_prev.reindex(all_units)

    result = pd.DataFrame({
        'unit_id': all_units,
        'mean_current': mean_curr.values,
        'mean_prev': mean_prev.values,
    })
    result['delta'] = result['mean_current'].fillna(0) - result['mean_prev'].fillna(0)
    both_nan = result['mean_current'].isna() & result['mean_prev'].isna()
    result = result[~both_nan]

    if result.empty:
        return _empty_fig(), _empty_fig(), [], [], DATA_TABLE_CONDITIONAL_STYLES, \
            'No overlapping units with data in both years.'

    # --- Filter by min delta threshold ----------------------------------------
    if min_delta and min_delta > 0:
        result = result[result['delta'].abs() >= min_delta]
        if result.empty:
            return _empty_fig(), _empty_fig(), [], [], DATA_TABLE_CONDITIONAL_STYLES, \
                f'All unit deltas are below the {min_delta} MW threshold.'

    # --- Sort descending by delta ---------------------------------------------
    result = result.sort_values('delta', ascending=False).reset_index(drop=True)

    # --- Build waterfall chart ------------------------------------------------
    country_label = next((o['label'] for o in COUNTRY_OPTIONS if o['value'] == country), country)
    chart_title = (f'{country_label} {fuel} Availability YoY: '
                   f'{day_start} {_month_abbr(month_start)} \u2013 '
                   f'{day_end} {_month_abbr(month_end)} '
                   f'({year_curr} vs {year_prev})')

    fig = _build_waterfall(result, chart_title)

    try:
        gen_wide = _load_per_unit_generation(country, fuel, overall_start, overall_end)
    except Exception:
        logger.error(traceback.format_exc())
        gen_wide = pd.DataFrame()

    load_factor_title = (f'{country_label} {fuel} Daily Load Factor: filtered units '
                         f'({year_curr} vs {year_prev})')
    load_factor_fig = _build_load_factor_chart(
        gen_wide=gen_wide,
        avail_wide=df_wide,
        filtered_units=result['unit_id'].tolist(),
        curr_start=curr_start,
        curr_end=curr_end,
        prev_start=prev_start,
        prev_end=prev_end,
        year_curr=year_curr,
        year_prev=year_prev,
        title=load_factor_title,
    )

    # --- Build summary table --------------------------------------------------
    table_data, table_cols, table_styles = _build_table(result, year_curr, year_prev)

    return fig, load_factor_fig, table_data, table_cols, table_styles, ''


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _month_abbr(m: int) -> str:
    import calendar
    return calendar.month_abbr[m]


def _empty_fig() -> go.Figure:
    fig = go.Figure()
    base = get_chart_layout(height=100)
    base['xaxis']['visible'] = False
    base['yaxis']['visible'] = False
    fig.update_layout(**base)
    return fig


def _build_waterfall(result: pd.DataFrame, title: str) -> go.Figure:
    # Per-unit YoY delta bars on a shared zero baseline. A cumulative waterfall
    # strings each unit along a running total, which buries small movers as
    # near-invisible slivers on a wide axis. Independent bars keep every unit
    # legible regardless of how large the net change is.
    result = result.sort_values('delta', ascending=False)
    units = result['unit_id'].tolist()
    deltas = result['delta'].tolist()
    net_total = float(pd.Series(deltas).sum())

    colors = [COLORS['success'] if v >= 0 else COLORS['error'] for v in deltas]

    dynamic_height = max(400, 26 * len(units) + 160)

    fig = go.Figure(go.Bar(
        orientation='h',
        y=units,
        x=deltas,
        marker={'color': colors},
        text=[f'{v:+.0f}' for v in deltas],
        textposition='outside',
        cliponaxis=False,
        hovertemplate='<b>%{y}</b><br>Delta: %{x:+.1f} MW<extra></extra>',
    ))

    full_title = f'{title}<br><sup>Net change: {net_total:+.0f} MW across {len(units)} units</sup>'
    base_layout = get_chart_layout(title=full_title, height=dynamic_height)
    base_layout['margin'] = {'l': 210, 'r': 80, 't': 70, 'b': 50}
    base_layout['yaxis']['autorange'] = 'reversed'
    base_layout['xaxis']['title'] = 'Delta MW (Current \u2013 Previous)'
    base_layout['yaxis']['title'] = ''
    base_layout['bargap'] = 0.2

    fig.update_layout(**base_layout)
    fig.add_vline(x=0, line_width=1, line_color='#888')
    return fig


def _period_axis(index: pd.DatetimeIndex) -> list[pd.Timestamp]:
    """Align different years onto a common leap year so periods overlay."""
    return [
        pd.Timestamp(year=2000, month=ts.month, day=ts.day)
        for ts in index
    ]


def _capacity_by_unit(
    avail_wide: pd.DataFrame,
    gen_wide: pd.DataFrame,
    units: list[str],
) -> pd.Series:
    """Best available unit capacity proxy for load-factor normalization."""
    capacity = pd.Series(index=units, dtype='float64')
    if avail_wide is not None and not avail_wide.empty:
        capacity = avail_wide.reindex(columns=units).max(skipna=True)
    if gen_wide is not None and not gen_wide.empty:
        gen_capacity = gen_wide.reindex(columns=units).quantile(0.995, axis=0)
        capacity = capacity.combine_first(gen_capacity)
        capacity = pd.concat([capacity, gen_capacity], axis=1).max(axis=1, skipna=True)
    return capacity.replace(0, pd.NA)


def _build_load_factor_chart(
    gen_wide: pd.DataFrame,
    avail_wide: pd.DataFrame,
    filtered_units: list[str],
    curr_start: date,
    curr_end: date,
    prev_start: date,
    prev_end: date,
    year_curr: int,
    year_prev: int,
    title: str,
) -> go.Figure:
    if gen_wide is None or gen_wide.empty:
        fig = _empty_fig()
        fig.update_layout(title='No per-unit generation data found for filtered units')
        return fig

    units = list(filtered_units)
    if not units:
        fig = _empty_fig()
        fig.update_layout(title='No filtered units to show')
        return fig

    capacity = _capacity_by_unit(avail_wide, gen_wide, units)

    n = len(units)
    fig = make_subplots(
        rows=n,
        cols=1,
        shared_xaxes=True,
        vertical_spacing=min(0.08, 0.5 / max(n, 1)),
        subplot_titles=units,
    )

    windows = [
        (year_prev, prev_start, prev_end, LOAD_FACTOR_YEAR_COLORS['previous']),
        (year_curr, curr_start, curr_end, LOAD_FACTOR_YEAR_COLORS['current']),
    ]

    for row, unit in enumerate(units, start=1):
        if unit not in gen_wide.columns:
            _add_subplot_note(fig, row, 'No generation data for this unit')
            fig.update_yaxes(title_text='LF %', range=[0, 105], row=row, col=1)
            continue

        if pd.isna(capacity.get(unit)) or capacity.get(unit) <= 0:
            _add_subplot_note(fig, row, 'No positive capacity proxy for this unit')
            fig.update_yaxes(title_text='LF %', range=[0, 105], row=row, col=1)
            continue

        unit_capacity = float(capacity[unit])
        has_trace = False
        for year, start, end, color in windows:
            mask = (
                (gen_wide.index >= pd.Timestamp(start))
                & (gen_wide.index <= pd.Timestamp(end) + pd.Timedelta(hours=23))
            )
            s = gen_wide.loc[mask, unit].astype('float64').dropna()
            if s.empty:
                continue
            hourly_lf = (s / unit_capacity * 100.0).dropna()
            if hourly_lf.empty:
                continue
            fig.add_trace(
                go.Scatter(
                    x=_period_axis(hourly_lf.index),
                    y=hourly_lf.values,
                    mode='lines',
                    name=str(year),
                    legendgroup=str(year),
                    showlegend=(row == 1),
                    line={'color': color, 'width': 1},
                    customdata=hourly_lf.index.strftime('%Y-%m-%d %H:%M'),
                    hovertemplate=(
                        f'<b>{unit}</b><br>'
                        f'Year: {year}<br>'
                        'Date: %{customdata}<br>'
                        'Load factor: %{y:.1f}%<extra></extra>'
                    ),
                ),
                row=row,
                col=1,
            )
            has_trace = True
        if not has_trace:
            _add_subplot_note(fig, row, 'No generation data in selected periods')
        fig.update_yaxes(title_text='LF %', range=[0, 105], row=row, col=1)

    base_layout = get_chart_layout(title=title, height=max(420, 190 * n + 120))
    base_layout['margin'] = {'l': 80, 'r': 40, 't': 70, 'b': 50}
    base_layout['legend'] = {'orientation': 'h', 'y': 1.02, 'x': 1, 'xanchor': 'right'}
    fig.update_layout(**base_layout)
    fig.update_xaxes(tickformat='%d %b', title_text='Period (hour)', row=n, col=1)
    fig.update_xaxes(showticklabels=True)
    return fig


def _add_subplot_note(fig: go.Figure, row: int, text: str) -> None:
    axis_suffix = '' if row == 1 else str(row)
    fig.add_annotation(
        text=text,
        x=0.5,
        y=0.5,
        xref=f'x{axis_suffix} domain',
        yref=f'y{axis_suffix} domain',
        showarrow=False,
        font={'size': 11, 'color': COLORS['text_muted']},
    )


def _build_table(result: pd.DataFrame, year_curr: int, year_prev: int):
    table_df = result.copy()
    table_df['mean_current'] = table_df['mean_current'].round(1)
    table_df['mean_prev'] = table_df['mean_prev'].round(1)
    table_df['delta'] = table_df['delta'].round(1)

    total_row = {
        'unit_id': 'TOTAL',
        'mean_current': round(table_df['mean_current'].sum(), 1),
        'mean_prev': round(table_df['mean_prev'].sum(), 1),
        'delta': round(table_df['delta'].sum(), 1),
    }
    table_df = pd.concat([table_df, pd.DataFrame([total_row])], ignore_index=True)

    from dash.dash_table.Format import Format, Scheme

    fixed_1 = Format(precision=1, scheme=Scheme.fixed)

    columns = [
        {'name': 'Unit', 'id': 'unit_id'},
        {'name': f'{year_curr} Mean (MW)', 'id': 'mean_current', 'type': 'numeric',
         'format': fixed_1},
        {'name': f'{year_prev} Mean (MW)', 'id': 'mean_prev', 'type': 'numeric',
         'format': fixed_1},
        {'name': 'Delta (MW)', 'id': 'delta', 'type': 'numeric',
         'format': fixed_1},
    ]

    cond_styles = list(DATA_TABLE_CONDITIONAL_STYLES) + [
        {
            'if': {
                'filter_query': '{delta} > 0',
                'column_id': 'delta',
            },
            'color': COLORS['success'],
            'fontWeight': 'bold',
        },
        {
            'if': {
                'filter_query': '{delta} < 0',
                'column_id': 'delta',
            },
            'color': COLORS['error'],
            'fontWeight': 'bold',
        },
        {
            'if': {
                'filter_query': '{unit_id} = "TOTAL"',
            },
            'fontWeight': 'bold',
            'backgroundColor': COLORS['table_header_bg'],
        },
    ]

    return table_df.to_dict('records'), columns, cond_styles
