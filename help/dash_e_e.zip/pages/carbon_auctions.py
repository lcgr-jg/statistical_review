"""
Carbon Auctions — Dash page registrar.

Self-contained Plotly HTML built by eu_carbon's auctions monitor and pushed
via ``POST /api/carbon/upload/auctions`` (see ``core.carbon_static``).
"""
from __future__ import annotations

import dash

from core.carbon_static import CARBON_PAGES, iframe_page_layout

dash.register_page(
    __name__,
    path="/carbon/auctions",
    name=CARBON_PAGES["auctions"],
    title="Carbon Auctions | JG Power Dashboard",
    order=65,
)

layout = iframe_page_layout("auctions")
