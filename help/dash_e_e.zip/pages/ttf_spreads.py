"""
TTF Spreads Monitor - Dash page registrar.

Interactive version of the eu_reports spreads_monitor email.  Implementation
lives in ``core.ttf_spreads``:
    * constants  -- page/scheduler wiring + option defaults
    * data       -- scheduler loader + stats recomputation from cached histories
    * components -- headline cards + heat-mapped stats table
    * charts     -- per-spread rolling-history Plotly figures
    * layout     -- ``build_layout()``
    * callbacks  -- registered on import

The spread engine itself is shared with the email report via
``jain_commods.core.analytics.spreads``.
"""
from __future__ import annotations

import dash

from core.ttf_spreads import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.ttf_spreads.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.ttf_spreads.data import load_ttf_spreads_data  # noqa: F401  - re-export for portal_app
from core.ttf_spreads.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
