"""
EU Gas Balance — Storage Scenarios page registrar.

Implementation lives in ``core.gas_storage_scenarios``.
"""
from __future__ import annotations

import dash

from core.gas_storage_scenarios import callbacks as _callbacks  # noqa: F401
from core.gas_storage_scenarios.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.gas_storage_scenarios.layout import build_layout

dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)

layout = build_layout()
