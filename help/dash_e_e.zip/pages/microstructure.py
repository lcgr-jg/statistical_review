"""
Trade Microstructure -- Dash page registrar.

All implementation lives in :mod:`core.microstructure`:
    * ``constants``     -- page metadata + cache TTLs
    * ``data_pipeline`` -- Snowflake / Trayport fetchers backed by ``DashboardCache``
    * ``signal_engine`` -- daily panel + statistical alpha tests (pure)
    * ``figures``       -- light-theme Plotly figure builders
    * ``layout``        -- ``build_layout()``
    * ``callbacks``     -- Dash callbacks (registered on import)

This file's only jobs are:
    1. register the Dash page so it appears in the sidebar,
    2. expose ``layout`` for ``use_pages`` to mount,
    3. import ``callbacks`` for its registration side-effect,
    4. start the per-prefix microstructure cache cleanup job.
"""
from __future__ import annotations

import logging

import dash

from core.microstructure import callbacks as _callbacks  # noqa: F401  - registers callbacks
from core.microstructure.constants import (
    PAGE_NAME,
    PAGE_ORDER,
    PAGE_PATH,
    PAGE_TITLE,
)
from core.microstructure.data_pipeline import register_microstructure_cleanup_job
from core.microstructure.layout import build_layout

logger = logging.getLogger(__name__)


dash.register_page(
    __name__,
    path=PAGE_PATH,
    name=PAGE_NAME,
    title=PAGE_TITLE,
    order=PAGE_ORDER,
)


layout = build_layout()


# Schedule the per-prefix disk cleanup once, at import time.  The shared
# DashboardCache also enforces its own global cap; this just additionally
# keeps microstructure data from monopolising the budget.  Failures here are
# non-fatal -- the page still works, just without the per-prefix watchdog.
try:
    register_microstructure_cleanup_job()
except Exception as exc:  # pragma: no cover -- defensive
    logger.warning("[microstructure] cleanup job not started: %s", exc)


__all__ = ["layout"]
