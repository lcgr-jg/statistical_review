"""End-to-end walkthrough of the pivot payload.

Prints the actual DataFrame and JSON-serialised list-of-lists that gets
shipped to ``dash_pivottable.PivotTable``.
"""
from __future__ import annotations

import io
import json
import logging
import os
import sys

# Force UTF-8 stdout on Windows cp1252 consoles so prints don't crash.
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "eu_corelib"))
sys.path.insert(0, os.path.dirname(__file__))

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

from core.microstructure.data_pipeline import (
    clean_trades,
    fetch_tenor_metadata,
    fetch_trades,
)
from core.microstructure.pivot import (
    PIVOT_COLUMNS,
    PIVOT_VALUES,
    build_pivot_payload,
    enrich_for_pivot,
)


def main() -> None:
    pd.set_option("display.max_columns", 200)
    pd.set_option("display.width", 250)
    pd.set_option("display.max_colwidth", 30)

    zone, shape = "France", "Baseload"

    print(f"\n{'=' * 80}\n  Pivot payload walkthrough — {zone} {shape}\n{'=' * 80}")

    # ── 1. metadata ───────────────────────────────────────────────────────
    print("\n[1] Fetching tenor metadata …")
    metadata = fetch_tenor_metadata(zone=zone, shape=shape)
    print(f"    Got metadata for {len(metadata)} tenors")
    for k in list(metadata)[:5]:
        print(f"      {k!r:<12} -> {metadata[k]}")

    # ── 2. trades ─────────────────────────────────────────────────────────
    print("\n[2] Fetching last 14 days of trades …")
    df_raw = fetch_trades(
        zone=zone, shape=shape,
        start_date=pd.Timestamp.now() - pd.Timedelta(days=14),
    )
    df_clean = clean_trades(df_raw)
    print(f"    Raw: {len(df_raw):,} | Cleaned: {len(df_clean):,}")
    print(f"    Unique tenors in trades: {sorted(df_clean['TENOR_NAME'].unique())}")

    # ── 3. enriched df ────────────────────────────────────────────────────
    print("\n[3] Building enriched DataFrame …")
    enriched = enrich_for_pivot(df_clean, tenor_metadata=metadata)
    print(f"    Enriched shape: {enriched.shape}")
    print(f"    Columns:        {list(enriched.columns)}")

    print("\n    dtypes:")
    print(enriched.dtypes.to_string())

    print("\n    Per-column NaN / null count:")
    nan_counts = enriched.isna().sum().sort_values(ascending=False)
    print(nan_counts[nan_counts > 0].to_string() or "    (no NaNs)")

    print("\n    days_to_expiry value counts (top 15):")
    print(enriched["days_to_expiry"].value_counts(dropna=False).head(15).to_string())

    print("\n    First 10 rows of key columns:")
    key_cols = [
        "trade_date", "tenor", "tenor_family", "contract_type",
        "days_to_expiry", "tte_start_bucket", "contract_length_bucket",
        "broker_group", "size_bucket", "side", "vwap_premium_bucket",
    ]
    print(enriched[key_cols].head(10).to_string())

    print("\n    Unique tenor -> days_to_expiry mapping (one row per tenor):")
    one_per_tenor = (
        enriched[["tenor", "trade_date", "days_to_expiry", "tenor_family",
                  "contract_type", "tte_start_bucket"]]
        .dropna(subset=["days_to_expiry"])
        .groupby("tenor")
        .first()
        .sort_values("days_to_expiry")
    )
    print(one_per_tenor.to_string())

    # ── 4. final payload ──────────────────────────────────────────────────
    print("\n[4] Building dash_pivottable payload …")
    data, n_rows = build_pivot_payload(df_clean, tenor_metadata=metadata)
    print(f"    Payload: header + {n_rows:,} data rows")
    print(f"    Header ({len(data[0])} cols):")
    for c in data[0]:
        print(f"      - {c}")

    print("\n    First 5 data rows (raw):")
    for row in data[1:6]:
        print(f"      {row}")

    print("\n    Per-column type inventory of first 1000 rows:")
    sample = data[1:1001]
    for col_idx, col_name in enumerate(data[0]):
        types = {type(r[col_idx]).__name__ for r in sample}
        nones = sum(1 for r in sample if r[col_idx] is None)
        print(f"      {col_name:<24} types={sorted(types)}  None={nones}")

    # ── 5. JSON-serialisability check ─────────────────────────────────────
    print("\n[5] JSON-serialisability check (this is what dash sends to React) …")
    try:
        blob = json.dumps(data[:11])
        print(f"    OK — first 10 rows serialise to {len(blob):,} bytes")
        print("    Sample of serialised payload (first 800 chars):")
        print("    " + blob[:800])
    except TypeError as e:
        print(f"    [FAIL] JSON serialisation broke: {e}")
        # Find the offending cell.
        for i, row in enumerate(data[1:11]):
            for j, v in enumerate(row):
                try:
                    json.dumps(v)
                except TypeError:
                    print(f"      row {i} col '{data[0][j]}' = {v!r} ({type(v).__name__})")

    # ── 6. dte distribution by tenor ──────────────────────────────────────
    print("\n[6] days_to_expiry distribution per tenor (sanity check):")
    dist = (
        enriched.groupby("tenor")["days_to_expiry"]
        .agg(["count", "min", "max", "mean", lambda s: s.isna().sum()])
        .rename(columns={"<lambda_0>": "n_null"})
        .sort_values("min")
    )
    print(dist.to_string())


if __name__ == "__main__":
    main()
