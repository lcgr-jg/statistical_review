import os
import io
import sys
import base64
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime, timezone
import webbrowser

from flask import send_file

from dash import Dash, html
from dash.dependencies import Input, Output

#filename = 'C:/Code/eu_dashboard_power/epex_auction_results/epex_auction_results.html'
filename = '/opt/jsvc-eucommodpm/eu_dashboard_power/epex_auction_results/epex_auction_results.html'

# ===== CONFIG =====
INCLUDE_DAYS = 14  # last 14 days
FORCE_HOURLY = bool(globals().get("RESAMPLE_HOUR", False))

# Unified plot sizing (slightly taller than before)
IMG_W   = 4.2
IMG_H   = 9.0
IMG_DPI = 150

def main(filename):
    import io, base64, numpy as np, pandas as pd, seaborn as sns, matplotlib.pyplot as plt
    from datetime import datetime, timezone
    from jain_commods.core.interfaces.snowflake import SnowFlake

    # ===== 1) Load & prepare data (15m preferred, else 60m) =====
    conn = SnowFlake(database='EEX', schema='MARKET_DATA', role='FR_COMMOD_PM_EU')
    conn._login
    cur = conn._conn.cursor()
    cur.execute("""
        SELECT COUNTRY, TIMESTAMP, PRICE, VOLUME, GRANULARITY
        FROM EEX.SPOT.PRICE_VOLUMES
        WHERE MARKET='DA' AND GRANULARITY IN ('15 MIN','60 MIN')
        ORDER BY COUNTRY, TIMESTAMP
    """)
    df = cur.fetch_pandas_all()
    if df.empty:
        raise ValueError("No DA data found for 15/60 MIN.")

    # Local time (Berlin) → naive
    df['TIMESTAMP'] = (pd.to_datetime(df['TIMESTAMP'], utc=True)
                         .dt.tz_convert('Europe/Berlin')
                         .dt.tz_localize(None))
    df['COUNTRY']   = df['COUNTRY'].replace({'DE': 'DE-LU'})
    df['LocalDate'] = df['TIMESTAMP'].dt.normalize()

    # Slot helpers
    df['Slot15'] = df['TIMESTAMP'].dt.floor('15min')
    df['Slot60'] = df['TIMESTAMP'].dt.floor('60min')

    # ===== 2) Date list for the dropdown =====
    all_dates = sorted(df['LocalDate'].unique())
    if not all_dates:
        raise ValueError("No dates found in dataset.")
    dates_to_include = all_dates[-min(len(all_dates), INCLUDE_DAYS):]

    date_options = []
    for d in dates_to_include:
        val = d.strftime('%Y-%m-%d')
        wd  = d.strftime('%a')
        date_options.append({'value': val, 'label': f"{val} ({wd})",
                             'isWeekend': d.weekday() >= 5})

    # ===== Helpers =====
    def _fig_to_base64(fig, dpi=IMG_DPI):
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=dpi, bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)
        return base64.b64encode(buf.read()).decode('utf-8')

    def _has_15(sub: pd.DataFrame) -> bool:
        # True if explicit granularity flag or enough 15m slots present that day
        return (sub.get('GRANULARITY', pd.Series()).eq('15 MIN').any()
                or sub['Slot15'].nunique() > 48)

    # ===== 3) Country panels (one per (date, country)) =====
    country_imgs = []
    for d in dates_to_include:
        day_df = df[df['LocalDate'] == d]
        if day_df.empty:
            continue

        for country in sorted(day_df['COUNTRY'].unique()):
            sub = day_df[day_df['COUNTRY'] == country].copy()
            if sub.empty:
                continue

            # Decide granularity
            show_hourly = FORCE_HOURLY or not _has_15(sub)
            day0 = d

            if show_hourly:
                idx = pd.date_range(day0, day0 + pd.Timedelta(days=1),
                                    freq='60min', inclusive='left', name='Slot60')
                grid = (sub.groupby('Slot60', as_index=True)
                          .agg(PRICE=('PRICE', 'mean'), VOLUME=('VOLUME', 'sum'))
                          .reindex(idx))
                labels   = [f"{t:%H:%M}–{(t+pd.Timedelta(hours=1)):%H:%M}" for t in idx]
                nrows    = len(idx)
                per_row  = 0.20
                baseload = float(grid['PRICE'].mean()) if grid['PRICE'].notna().any() else np.nan
                peak     = float(grid['PRICE'][(idx.hour >= 8) & (idx.hour <= 19)].mean()) if grid['PRICE'].notna().any() else np.nan
            else:
                idx = pd.date_range(day0, day0 + pd.Timedelta(days=1),
                                    freq='15min', inclusive='left', name='Slot15')
                grid = (sub.groupby('Slot15', as_index=True)
                          .agg(PRICE=('PRICE', 'mean'), VOLUME=('VOLUME', 'sum'))
                          .reindex(idx))
                labels   = [f"{t:%H:%M}–{(t+pd.Timedelta(minutes=15)):%H:%M}" for t in idx]
                nrows    = len(idx)
                per_row  = 0.155
                baseload = float(grid['PRICE'].mean()) if grid['PRICE'].notna().any() else np.nan
                # peak 08:00–19:59 local time
                peak     = float(grid['PRICE'].between_time('08:00', '19:59').mean()) if grid['PRICE'].notna().any() else np.nan

            # Plot (wide left margin; every interval labeled and annotated)
            # --- plotting (compact like legacy) ---
            fig, ax = plt.subplots(figsize=(IMG_W, IMG_H), constrained_layout=True)
            #plt.subplots_adjust(top=0.90, left=0.60, right=0.98)

            vmin = grid['PRICE'].min(skipna=True) if grid['PRICE'].notna().any() else None
            vmax = grid['PRICE'].max(skipna=True) if grid['PRICE'].notna().any() else None
            sns.heatmap(grid[['PRICE']], cmap='RdYlGn', vmin=vmin, vmax=vmax, cbar=False, ax=ax)

            for y in range(nrows):
                p = grid['PRICE'].iloc[y]
                v = grid['VOLUME'].iloc[y]
                if pd.notna(p):
                    ax.text(0.5, y + 0.5, f"{p:.2f}", ha='center', va='center', fontsize=6.7)
                if pd.notna(v):
                    ax.text(1.55, y + 0.5, f"{v:,.0f}", ha='center', va='center', fontsize=6.2, clip_on=False)

            ax.set_xticks([0.5, 1.5])
            ax.set_xticklabels(['Price (€/MWh)', 'Volume'], fontsize=7)

            ax.set_yticks(np.arange(0.5, nrows + 0.5, 1))
            ax.set_yticklabels(labels, fontsize=6.2)
            ax.set_ylabel('Interval', fontsize=7)
            ax.set_title(f"{country} ({d:%Y-%m-%d})", fontsize=9)

            img = _fig_to_base64(fig)
            country_imgs.append({
                'date': d.strftime('%Y-%m-%d'),
                'title': country,
                'baseload': f"{baseload:.2f}" if pd.notna(baseload) else "NA",
                'peakload': f"{peak:.2f}" if pd.notna(peak) else "NA",
                'img': img
            })

    # ===== 4) Spread panels (one per (date, border)) =====
    def get_borders():
        pairs = [
            ('AT','DE-LU'),('AT','CH'),('AT','HU'),('AT','SI'),
            ('BE','FR'),('BE','NL'),('BE','DE-LU'),
            ('CH','FR'),('CH','IT'),('CH','DE-LU'),
            ('DE-LU','FR'),('DE-LU','NL'),('DE-LU','PL'),('DE-LU','DK1'),
            ('DK1','DK2'),('DK1','DE-LU'),('DK2','SE4'),
            ('FI','SE1'),('FR','ES'),('FR','IT'),('FR','BE'),
            ('NL','BE'),('NL','DE-LU'),
            ('NO1','NO2'),('NO2','NO5'),('NO3','SE2'),('NO4','SE1'),
            ('PL','DE-LU'),('SE1','SE2'),('SE2','SE3'),('SE3','SE4')
        ]
        return list({tuple(sorted(p)) for p in pairs})

    spread_imgs = []
    for d in dates_to_include:
        day_df = df[df['LocalDate'] == d]
        if day_df.empty:
            continue

        for a, b in get_borders():
            da = day_df[day_df['COUNTRY'] == a].copy()
            db = day_df[day_df['COUNTRY'] == b].copy()
            if da.empty or db.empty:
                continue

            # decide granularity (hourly if forced, else 15m only if both have 15m)
            use_15 = (not FORCE_HOURLY) and _has_15(da) and _has_15(db)
            if use_15:
                gcol, step_td, per_row = 'Slot15', pd.Timedelta(minutes=15), 0.155
                idx = pd.date_range(d, d + pd.Timedelta(days=1), freq='15min', inclusive='left', name=gcol)
            else:
                gcol, step_td, per_row = 'Slot60', pd.Timedelta(hours=1), 0.20
                idx = pd.date_range(d, d + pd.Timedelta(days=1), freq='60min', inclusive='left', name=gcol)

            A = da.groupby(gcol, as_index=True)['PRICE'].mean().reindex(idx)
            B = db.groupby(gcol, as_index=True)['PRICE'].mean().reindex(idx)
            spread = A - B

            labels = [f"{t:%H:%M}–{(t + step_td):%H:%M}" for t in idx]
            nrows  = len(idx)

            baseload_spread = float(spread.mean()) if spread.notna().any() else np.nan
            peak_mask = (idx.hour >= 8) & (idx.hour <= 19)
            peak_spread = float(spread[peak_mask].mean()) if peak_mask.any() else np.nan

            fig, ax = plt.subplots(figsize=(IMG_W, IMG_H), constrained_layout=True)
            #plt.subplots_adjust(top=0.90, left=0.60, right=0.98)

            pv   = spread.to_frame('SPREAD')
            vmin = pv['SPREAD'].min(skipna=True) if pv['SPREAD'].notna().any() else None
            vmax = pv['SPREAD'].max(skipna=True) if pv['SPREAD'].notna().any() else None
            sns.heatmap(pv, annot=False, fmt='.2f', cmap='RdYlGn', center=0, cbar=False,
                        vmin=vmin, vmax=vmax, ax=ax)

            for y in range(nrows):
                val = spread.iloc[y]
                if pd.notna(val):
                    ax.text(0.5, y + 0.5, f"{val:.2f}", ha='center', va='center', fontsize=6.5, color='black')

            ax.set_xticks([0.5])
            ax.set_xticklabels(['Spread (€/MWh)'], fontsize=7)
            ax.set_yticks(np.arange(0.5, nrows + 0.5, 1))
            ax.set_yticklabels(labels, fontsize=6.2)
            ax.set_ylabel('Interval', fontsize=7)
            ax.set_title(f"{a} – {b} ({d:%Y-%m-%d})", fontsize=9)

            img = _fig_to_base64(fig)
            spread_imgs.append({
                'date': d.strftime('%Y-%m-%d'),
                'title': f"{a} - {b}",
                'baseload': f"{baseload_spread:.2f}" if pd.notna(baseload_spread) else "NA",
                'peakload': f"{peak_spread:.2f}" if pd.notna(peak_spread) else "NA",
                'img': img
            })

    # Order spreads by baseload (latest day’s ordering will appear first after filtering)
    spread_imgs.sort(key=lambda x: float(x['baseload']) if x['baseload'] != "NA" else -1e9, reverse=True)

    # ===== 5) Build a standalone HTML page =====
    last_update = datetime.now(timezone.utc).strftime('%A %d %B, %Y %H:%M UTC')
    html = f"""<html><head><meta charset="utf-8"><style>
    body{{font-family:Arial,sans-serif;margin:0}}
    .header{{background:#000;color:#fff;padding:20px;text-align:center}}
    .header h1{{margin:0;font-size:24px}}
    .header p{{margin:6px 0 0;font-size:13px;color:#cfcfcf}}
    .tabs{{display:flex;border-bottom:1px solid #ccc;background:#eee}}
    .tabbtn{{flex:1;padding:10px;cursor:pointer;text-align:center;border:none;background:inherit;font-size:16px}}
    .tabbtn.active{{background:#ddd;font-weight:bold}}
    .toolbar{{padding:10px;background:#f9f9f9;display:flex;align-items:center;gap:10px}}
    .toolbar select{{font-size:1em;padding:5px}}
    .container{{padding:12px;display:grid;grid-template-columns:repeat(auto-fill,minmax(420px,1fr));gap:18px}}
    .chart{{border:1px solid #ccc;padding:10px;box-sizing:border-box;background:#fff}}
    .chart h2{{margin:4px 0;font-size:1.1em}}
    .chart h3{{margin:2px 0;font-size:0.95em;color:#555}}
    .chart img{{width:100%;height:auto;max-height:none;display:block}}
    </style></head><body>
    <div class="header">
      <h1>EPEX Auction Clear Data</h1>
      <p>Last Update: {last_update} • {'Hourly view forced' if FORCE_HOURLY else '15-minute view (preferred where available)'} </p>
    </div>

    <div class="tabs">
      <button class="tabbtn active" onclick="showTab('heat', event)">Country/Zonal Prices</button>
      <button class="tabbtn" onclick="showTab('spread', event)">Cross-Border Spreads</button>
    </div>

    <div class="toolbar">
      <label for="dateSelect">Select Date:</label>
      <select id="dateSelect">
    """
    for opt in date_options:
        sel = ' selected' if opt['value'] == date_options[-1]['value'] else ''
        cls = ' class="weekend"' if opt['isWeekend'] else ''
        html += f"<option value='{opt['value']}'{cls}{sel}>{opt['label']}</option>\n"

    html += """
      </select>
    </div>

    <div id="heat" class="tabcontent" style="display:block">
      <div class="container">
    """
    for s in country_imgs:
        html += (
            f"<div class='chart' data-date='{s['date']}'>"
            f"<h2>{s['title']}</h2>"
            f"<h3>Baseload: {s['baseload']} €/MWh • Peakload: {s['peakload']} €/MWh</h3>"
            f"<img src='data:image/png;base64,{s['img']}' alt='{s['title']}'/>"
            f"</div>\n"
        )
    html += """
      </div>
    </div>

    <div id="spread" class="tabcontent" style="display:none">
      <div class="container">
    """
    for s in spread_imgs:
        html += (
            f"<div class='chart' data-date='{s['date']}'>"
            f"<h2>{s['title']}</h2>"
            f"<h3>Baseload: {s['baseload']} €/MWh • Peakload: {s['peakload']} €/MWh</h3>"
            f"<img src='data:image/png;base64,{s['img']}' alt='{s['title']}'/>"
            f"</div>\n"
        )
    html += """
      </div>
    </div>

    <script>
    function showTab(id, ev){
      document.querySelectorAll('.tabbtn').forEach(b=>b.classList.remove('active'));
      if(ev) ev.currentTarget.classList.add('active');
      document.getElementById('heat').style.display   = (id==='heat')   ? 'block':'none';
      document.getElementById('spread').style.display = (id==='spread') ? 'block':'none';
    }
    const dateSelect = document.getElementById('dateSelect');
    function filterByDate(v){
      document.querySelectorAll('.chart').forEach(c=>{
        c.style.display = (c.getAttribute('data-date')===v) ? 'block' : 'none';
      });
    }
    dateSelect.addEventListener('change', ()=> filterByDate(dateSelect.value));
    // initialize to the last date
    window.onload = () => filterByDate(dateSelect.value);
    </script>

    </body></html>
    """

    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)

def serve_epex_report(filename):
    print("Generating report...")
    main(filename)

    from dash import Dash, html as dhtml
    from flask import send_file

    app = Dash(__name__)
    server = app.server

    @server.route("/epex_report")
    def serve_report():
        return send_file(filename)

    app.layout = dhtml.Div([
        dhtml.Iframe(src="/epex_report",
                     style={"width": "100%", "height": "100vh", "border": "none"})
    ])
    app.run(host="0.0.0.0", port=9004, use_reloader=False)


if __name__ == "__main__":
    serve_epex_report(filename)
