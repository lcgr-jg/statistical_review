"""
EU Commodities Dashboard - Power Portal
Multi-Page Dash Application
"""

import os
import logging
import hmac
import threading
from datetime import timedelta
from urllib.parse import urlparse
import dash
from dash import Dash, html, dcc, Input, Output, State, callback
import dash_bootstrap_components as dbc
from flask import request, redirect, url_for, render_template_string
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user 

from werkzeug.security import check_password_hash

# Import enterprise caching, monitoring, and styling
from core.cache import dashboard_cache
from core.figure_registry import figure_registry
from core.web_perf import attach_performance_layer
from core.data_freshness import tracker
from core.styles import COLORS
from core.freshness_widget import create_freshness_widget, register_freshness_callbacks
from core.toast_manager import create_toast_container, register_toast_callbacks, make_toast
import core.theme  # noqa: F401  -- side-effect: registers the "dashboard" plotly template as default
from core.constants import (
    get_host,
    get_port,
    get_waitress_channel_timeout,
    get_waitress_connection_limit,
    get_waitress_threads,
)

# ── Environment config ────────────────────────────────────────────────────
DASH_ENV = os.getenv("DASH_ENV", "local")          # "local" | "staging" | "prod"
IS_DEV = DASH_ENV == "local"
PORT = get_port()
HOST = get_host(is_dev=IS_DEV)
DEBUG = os.getenv("DASH_DEBUG", "1" if IS_DEV else "0").strip() == "1"
ENV_LABEL = DASH_ENV.upper()
ENV_COLOR = {"local": "#4CAF50", "staging": "#FF9800", "prod": "#2196F3"}.get(DASH_ENV, "#4CAF50")
AUTH_USERS_RAW = os.getenv("DASH_LOGIN_USERS", os.getenv("DASH_AUTH_USERS", "")).strip()
AUTH_ALLOW_EMPTY_IN_PROD = os.getenv("DASH_AUTH_ALLOW_EMPTY_IN_PROD", "0").strip() == "1"
FLASK_SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "")
REMEMBER_DAYS = int(os.getenv("DASH_REMEMBER_DAYS", "14"))
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "0").strip() == "1"

logger = logging.getLogger(__name__)


def _parse_login_users(raw_users: str) -> dict:
    """Parse DASH_LOGIN_USERS='user1:pass1,user2:pass2' into a dict."""
    users = {}
    for part in raw_users.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" not in part:
            raise ValueError(
                f"Invalid DASH_LOGIN_USERS entry '{part}'. "
                "Expected format user:password,user2:password2."
            )
        username, password = part.split(":", 1)
        username = username.strip()
        password = password.strip()
        if not username or not password:
            raise ValueError(
                f"Invalid DASH_LOGIN_USERS entry '{part}'. Username/password cannot be empty."
            )
        users[username] = password
    return users


def _password_matches(stored_password: str, provided_password: str) -> bool:
    """Support either hashed (recommended) or plaintext env passwords."""
    if stored_password.startswith(("pbkdf2:", "scrypt:")):
        return check_password_hash(stored_password, provided_password)
    return hmac.compare_digest(stored_password, provided_password)


def _is_safe_next_url(target: str) -> bool:
    """Prevent open redirects by allowing only same-host relative redirects."""
    if not target:
        return False
    parsed = urlparse(target)
    return parsed.scheme == "" and parsed.netloc == ""

# Initialize the app with pages support
app = Dash(
    __name__,
    use_pages=True,
    pages_folder="pages",
    title="JG EU Commodities Dashboard - Power",
    external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.FONT_AWESOME],
    suppress_callback_exceptions=True,
)

AUTH_ENABLED = bool(AUTH_USERS_RAW)
_LOGIN_USERS = _parse_login_users(AUTH_USERS_RAW) if AUTH_ENABLED else {}
if DASH_ENV == "prod" and not AUTH_ENABLED and not AUTH_ALLOW_EMPTY_IN_PROD:
    raise RuntimeError(
        "DASH_LOGIN_USERS is required in prod. "
        "Set DASH_LOGIN_USERS='user:password,...' or set DASH_AUTH_ALLOW_EMPTY_IN_PROD=1."
    )

# Redirect root to first dashboard
app.config.suppress_callback_exceptions = True

server = app.server

# ── Performance layer: gzip + Cache-Control + /api/fig endpoint ──
# Attach early so every route benefits (including Dash internals).
attach_performance_layer(server)

# Flask session + remember-cookie settings
if not FLASK_SECRET_KEY:
    if DASH_ENV == "prod":
        raise RuntimeError("FLASK_SECRET_KEY is required in prod.")
    FLASK_SECRET_KEY = "local-dev-secret-key-change-me"

server.config.update(
    SECRET_KEY=FLASK_SECRET_KEY,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=COOKIE_SECURE,
    SESSION_COOKIE_SAMESITE="Lax",
    REMEMBER_COOKIE_HTTPONLY=True,
    REMEMBER_COOKIE_SECURE=COOKIE_SECURE,
    REMEMBER_COOKIE_SAMESITE="Lax",
    REMEMBER_COOKIE_DURATION=timedelta(days=REMEMBER_DAYS),
)

login_manager = LoginManager()
login_manager.init_app(server)
login_manager.login_view = "login"


class DashboardUser(UserMixin):
    def __init__(self, user_id: str):
        self.id = user_id


@login_manager.user_loader
def load_user(user_id: str):
    if user_id in _LOGIN_USERS:
        return DashboardUser(user_id)
    return None


@login_manager.unauthorized_handler
def _unauthorized():
    if (
        request.path.startswith("/api/health")
        or request.path.startswith("/api/live")
        or request.path.startswith("/api/cache-status")
        or request.path.startswith("/api/callback-status")
        or request.path.startswith("/api/carbon/upload")
    ):
        return "Unauthorized", 401
    return redirect(url_for("login", next=request.full_path))


LOGIN_TEMPLATE = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>JG EU Commodities Dashboard - Login</title>
  <style>
    :root {
      --bg: #f5f6f8;
      --card-bg: #ffffff;
      --text: #172b4d;
      --muted: #6b778c;
      --border: #dfe3e8;
      --input-border: #ccd5df;
      --primary: #4e738a;
      --primary-hover: #3f6176;
      --header: #2b3a42;
      --header-border: #233038;
      --error-bg: #fff5f5;
      --error-border: #fed7d7;
      --error-text: #c53030;
    }

    * { box-sizing: border-box; }
    html, body { margin: 0; min-height: 100%; }
    body {
      background: radial-gradient(circle at 20% 0%, #ffffff 0%, var(--bg) 42%, #e9edf2 100%);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }

    .top-bar {
      height: 70px;
      background: var(--header);
      border-bottom: 1px solid var(--header-border);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    .top-bar-inner {
      width: min(980px, 100%);
      display: flex;
      align-items: center;
      gap: 14px;
    }

    .logo {
      height: 32px;
      width: auto;
      display: block;
    }

    .brand-title {
      color: #ffffff;
      font-size: 16px;
      font-weight: 600;
      letter-spacing: 0.2px;
    }

    .env-pill {
      margin-left: auto;
      font-size: 11px;
      font-weight: 700;
      color: #8bb4d0;
      background: rgba(139, 180, 208, 0.16);
      border: 1px solid rgba(139, 180, 208, 0.35);
      border-radius: 999px;
      padding: 4px 10px;
      letter-spacing: 0.4px;
    }

    .wrap {
      min-height: calc(100vh - 70px);
      display: grid;
      place-items: center;
      padding: 28px;
    }

    .card {
      width: 100%;
      max-width: 410px;
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 12px;
      box-shadow: 0 10px 28px rgba(23, 43, 77, 0.08);
      overflow: hidden;
    }

    .card-head {
      padding: 18px 22px 14px;
      border-bottom: 1px solid #e9edf2;
      background: linear-gradient(180deg, #ffffff 0%, #fafbfd 100%);
    }

    .title {
      margin: 0;
      font-size: 21px;
      font-weight: 650;
      color: var(--text);
    }

    .sub {
      margin-top: 6px;
      font-size: 13px;
      color: var(--muted);
    }

    .card-body {
      padding: 18px 22px 22px;
    }

    .row { margin-bottom: 13px; }
    label {
      display: block;
      font-size: 12px;
      color: #4a5568;
      margin-bottom: 6px;
      font-weight: 600;
      letter-spacing: 0.2px;
    }

    input[type=text], input[type=password] {
      width: 100%;
      height: 40px;
      border: 1px solid var(--input-border);
      border-radius: 7px;
      padding: 0 11px;
      font-size: 14px;
      transition: border-color 0.15s, box-shadow 0.15s;
      background: #ffffff;
    }

    input[type=text]:focus, input[type=password]:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(78, 115, 138, 0.15);
      outline: none;
    }

    .remember {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: #4a5568;
      margin: 8px 0 18px;
    }

    .remember input {
      width: 15px;
      height: 15px;
      accent-color: var(--primary);
    }

    button {
      width: 100%;
      height: 40px;
      border: 0;
      border-radius: 7px;
      background: var(--primary);
      color: #ffffff;
      font-size: 14px;
      font-weight: 650;
      letter-spacing: 0.2px;
      cursor: pointer;
      transition: background 0.2s, transform 0.1s;
    }

    button:hover { background: var(--primary-hover); }
    button:active { transform: translateY(1px); }

    .err {
      margin: 0 0 12px;
      padding: 9px 11px;
      background: var(--error-bg);
      color: var(--error-text);
      border: 1px solid var(--error-border);
      border-radius: 7px;
      font-size: 13px;
    }
  </style>
</head>
<body>
  <div class="top-bar">
    <div class="top-bar-inner">
      <img class="logo" src="https://www.jainglobal.com/i/logo.png" alt="Jain Global">
      <div class="brand-title">EU Commodities Dashboard</div>
      <div class="env-pill">{{ env_label }}</div>
    </div>
  </div>
  <div class="wrap">
    <form class="card" method="post">
      <div class="card-head">
        <h1 class="title">Sign In</h1>
        <div class="sub">Use your dashboard credentials to continue.</div>
      </div>
      <div class="card-body">
        {% if error %}<div class="err">{{ error }}</div>{% endif %}
        <input type="hidden" name="next" value="{{ next_url }}">
        <div class="row">
          <label>Username</label>
          <input type="text" name="username" autocomplete="username" required>
        </div>
        <div class="row">
          <label>Password</label>
          <input type="password" name="password" autocomplete="current-password" required>
        </div>
        <label class="remember"><input type="checkbox" name="remember" checked> Remember me on this device</label>
        <button type="submit">Sign In</button>
      </div>
    </form>
  </div>
</body>
</html>
"""


@server.route("/login", methods=["GET", "POST"])
def login():
    if not AUTH_ENABLED:
        return redirect("/")

    if current_user.is_authenticated:
        return redirect("/")

    error = None
    next_url = request.args.get("next", "/")
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        next_url = request.form.get("next") or "/"
        remember = (request.form.get("remember") or "").lower() in {"1", "true", "on", "yes"}

        stored = _LOGIN_USERS.get(username)
        if stored and _password_matches(stored, password):
            login_user(DashboardUser(username), remember=remember)
            if _is_safe_next_url(next_url):
                return redirect(next_url)
            return redirect("/")
        error = "Invalid username or password."

    return render_template_string(
        LOGIN_TEMPLATE,
        error=error,
        next_url=next_url,
        env_label=ENV_LABEL,
    )


@server.route("/logout", methods=["GET"])
def logout():
    if AUTH_ENABLED and current_user.is_authenticated:
        logout_user()
    return redirect(url_for("login"))


@server.before_request
def _require_login():
    if not AUTH_ENABLED:
        return None

    path = request.path or "/"
    if path.startswith("/login") or path.startswith("/logout"):
        return None
    if path.startswith("/assets/"):
        return None
    if (
        path.startswith("/api/health")
        or path.startswith("/api/live")
        or path.startswith("/api/cache-status")
        or path.startswith("/api/callback-status")
        # carbon upload does its own HTTP Basic auth (core.carbon_static)
        or path.startswith("/api/carbon/upload")
    ):
        return None

    if current_user.is_authenticated:
        return None

    return redirect(url_for("login", next=request.full_path))


if AUTH_ENABLED:
    logger.info("Flask-Login auth enabled for %d user(s)", len(_LOGIN_USERS))

# ── Carbon section: static dashboard hosting (serve + upload routes) ──
from core.carbon_static import attach_carbon_routes  # noqa: E402

attach_carbon_routes(server, _LOGIN_USERS, _password_matches)

# Sidebar width
SIDEBAR_WIDTH = "280px"

# Note: COLORS imported from core.styles for consistency across all dashboards

# Layout
app.layout = html.Div(
    style={
        "margin": "0",
        "padding": "0",
        "fontFamily": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    },
    children=[
        # URL location for routing
        dcc.Location(id='url', refresh=False),

        # Persisted open/closed state for the sidebar domain accordion
        dcc.Store(id='sidebar-open-domains', storage_type='local'),

        
        # Hidden div to force layout refresh (cache buster)
        html.Div(id='layout-version', style={'display': 'none'}, children='v3.0'),

        # Header
        html.Div(
            style={
                "position": "fixed",
                "top": "0",
                "left": "0",
                "right": "0",
                "height": "70px",
                "backgroundColor": COLORS['header_bg'],
                "display": "flex",
                "alignItems": "center",
                "padding": "0 30px",
                "zIndex": "1000",
                "borderBottom": f"1px solid {COLORS['border_dark']}",
            },
            children=[
                html.Img(
                    src="https://www.jainglobal.com/i/logo.png",
                    style={"height": "40px", "marginRight": "24px"},
                ),
                # ── Cross-dashboard quick links ──
                # Small cards linking to the other dashboards; each opens in a new tab.
                html.Div(
                    style={
                        "display": "flex",
                        "alignItems": "center",
                        "gap": "10px",
                    },
                    children=[
                        html.A(
                            href=link_url,
                            target="_blank",
                            className="topbar-link-card",
                            style={
                                "display": "flex",
                                "alignItems": "center",
                                "gap": "8px",
                                "padding": "8px 14px",
                                "borderRadius": "8px",
                                "backgroundColor": "rgba(255,255,255,0.04)",
                                "border": f"1px solid {COLORS['border_dark_strong']}",
                                "color": COLORS['header_text'],
                                "textDecoration": "none",
                                "fontSize": "13px",
                                "fontWeight": "600",
                                "letterSpacing": "-0.2px",
                                "whiteSpace": "nowrap",
                                "transition": "background-color 0.15s ease, border-color 0.15s ease, transform 0.15s ease",
                            },
                            children=[
                                html.I(
                                    className=icon_class,
                                    style={"fontSize": "14px", "color": COLORS['accent_blue']},
                                ),
                                html.Span(label),
                                html.I(
                                    className="fas fa-arrow-up-right-from-square",
                                    style={"fontSize": "9px", "opacity": "0.45", "marginLeft": "1px"},
                                ),
                            ],
                        )
                        for label, link_url, icon_class in [
                            ("Portfolio Copilot", "http://10.115.0.70:8080", "fas fa-robot"),
                            ("Position Monitor", "http://10.115.0.70:8064", "fas fa-chart-line"),
                            ("Weather", "http://10.115.0.70:8010/", "fas fa-cloud-sun"),
                        ]
                    ],
                ),
                html.Div(
                    ENV_LABEL,
                    style={
                        "fontSize": "11px",
                        "fontWeight": "600",
                        "color": ENV_COLOR,
                        "backgroundColor": f"rgba({int(ENV_COLOR[1:3],16)},{int(ENV_COLOR[3:5],16)},{int(ENV_COLOR[5:7],16)},0.15)",
                        "padding": "6px 12px",
                        "borderRadius": "6px",
                        "border": f"1px solid {ENV_COLOR}40",
                        "marginLeft": "auto",
                    },
                ),
            ],
        ),
        
        # Sidebar
        html.Div(
            id='sidebar',
            style={
                "position": "fixed",
                "top": "70px",
                "left": "0",
                "width": SIDEBAR_WIDTH,
                "height": "calc(100vh - 70px)",
                "backgroundColor": COLORS['sidebar_bg'],
                "overflowY": "auto",
                "overflowX": "hidden",
                "padding": "16px 0",
                "borderRight": f"1px solid {COLORS['border_dark']}",
                "zIndex": "999",
            },
            children=[
                # Navigation items — grouped by category, dynamically generated.
                html.Div(id='nav-items', style={"padding": "10px 0", "flex": "1"}),

            ],
        ),
        
        # Main content area
        html.Div(
            style={
                "marginLeft": SIDEBAR_WIDTH,
                "marginTop": "70px",
                "minHeight": "calc(100vh - 70px)",
                "backgroundColor": "#f5f6f8",
                "position": "relative",
            },
            children=[
                # Page content container
                dash.page_container
            ],
        ),

        # ── Data freshness footer widget (bottom-right) ──
        create_freshness_widget(),

        # ── Toast notification container (top-right) ──
        create_toast_container(),
    ]
)



# Sidebar structure: three collapsible top-level domains (Power / Gas / Carbon),
# each holding (subgroup label, [page names in display order]) tuples.
# Page names must exactly match the ``name=`` passed to ``dash.register_page``.
# Pages not listed here are appended to a "Other" group as a defensive fallback.
SIDEBAR_DOMAINS: list[tuple[str, str, list[tuple[str, list[str]]]]] = [
    ("Power", "fas fa-bolt", [
        ("Prices", [
            "Fuel Switching",
            "Spot vs Forward",
            "Clean Spreads",
            "EPEX Day-Ahead Prices",
            "Trade Data",
        ]),
        ("Availability", [
            "Nuclear Availability",
            "YoY Availability",
        ]),
        ("Hydro", [
            "Hydro Pricing",
        ]),
        ("Cross-Border", [
            "Flows",
            "Transmission",
        ]),
        ("Power Balance", [
            "Fundamental Overview",
            "Heatmap Balance",
        ]),
        ("Models", [
            "Stack Model",
            "HeatRate Model",
            "Price GNN",
        ]),
    ]),
    ("Gas", "fas fa-fire-flame-simple", [
        ("TTF Spreads", [
            "TTF Spreads Monitor",
            "TTF Low-Beta Spreads",
        ]),
        ("EU Gas Balance", [
            "Overview",
            "Live Flows",
            "Storage Summary",
            "Storage vs Demand",
            "Storage Scenarios",
            "Injectability / Withdrawability",
            "Storage Sites",
        ]),
        ("LNG", [
            "Qatar Monitor",
            "Cargo DoD Changes",
            "Cargo Diversions",
            "Cargo Forecast History",
            "Arrivals Analysis",
            "Arrivals vs Regas",
            "Netbacks",
            "Supply Additions",
        ]),
    ]),
    ("Carbon", "fas fa-leaf", [
        ("Carbon", [
            "Vol Monitor",
            "Timespreads",
            "Factors",
            "Switching",
            "Positioning (COT)",
            "Auctions",
        ]),
    ]),
    # ("Iberia · OMIE", ...)  # Unlinked for now -- page module renamed to
    #      # pages/_iberia.py so use_pages skips it. Restore an entry under the
    #      # Power domain + rename the file back to pages/iberia.py to re-link.
]

_DOMAIN_NAMES = [d for d, _, _ in SIDEBAR_DOMAINS]


def _nav_domain_header(domain: str, icon_class: str, is_open: bool) -> html.Div:
    """Tier-1 collapsible domain banner (Power / Gas / Carbon)."""
    return html.Div(
        id={"type": "domain-header", "domain": domain},
        n_clicks=0,
        className="nav-domain-header",
        style={
            "display": "flex",
            "alignItems": "center",
            "gap": "10px",
            "padding": "13px 20px",
            "margin": "4px 0 2px 0",
            "cursor": "pointer",
            "fontSize": "12px",
            "fontWeight": "700",
            "textTransform": "uppercase",
            "letterSpacing": "1.8px",
            "userSelect": "none",
            "color": (
                COLORS["sidebar_text_active"] if is_open else COLORS["sidebar_text"]
            ),
            "borderBottom": f"1px solid {COLORS['border_dark']}",
            "transition": "background-color 0.15s ease, color 0.15s ease",
        },
        children=[
            html.I(
                className=icon_class,
                style={
                    "fontSize": "13px",
                    "width": "18px",
                    "textAlign": "center",
                    "color": COLORS["accent"],
                },
            ),
            html.Span(domain),
            html.I(
                className="fas fa-chevron-down chevron",
                style={
                    "marginLeft": "auto",
                    "fontSize": "10px",
                    "opacity": "0.55",
                    "transform": "rotate(0deg)" if is_open else "rotate(-90deg)",
                },
            ),
        ],
    )


def _nav_group_header(label: str, indent: bool = False) -> html.Div:
    return html.Div(
        label,
        style={
            "padding": (
                "14px 24px 6px 30px" if indent else "18px 24px 8px 24px"
            ),
            "fontSize": "10px",
            "fontWeight": "700",
            "color": COLORS["sidebar_text_muted"],
            "textTransform": "uppercase",
            "letterSpacing": "1.4px",
        },
    )


def _nav_link(page: dict, pathname: str, indent: bool = False) -> dcc.Link:
    is_active = pathname == page["path"]
    style = {
        "display": "block",
        "padding": "9px 17px",
        "margin": "1px 10px 1px 16px" if indent else "1px 10px",
        "cursor": "pointer",
        "borderRadius": "6px",
        "fontSize": "13px",
        "fontWeight": "500",
        "color": (
            COLORS["sidebar_text_active"] if is_active else COLORS["sidebar_text"]
        ),
        "backgroundColor": COLORS["active_item"] if is_active else "transparent",
        "transition": "background-color 0.15s ease, color 0.15s ease",
        "borderLeft": (
            f"2px solid {COLORS['accent']}" if is_active else "2px solid transparent"
        ),
        "textDecoration": "none",
    }
    return dcc.Link(
        page["name"],
        href=page["path"],
        style=style,
        className="" if is_active else "nav-item-hover",
    )


def _active_domain(pathname: str, pages_by_name: dict) -> str | None:
    """Return the domain whose pages include the current pathname."""
    for domain, _icon, groups in SIDEBAR_DOMAINS:
        for _group_label, page_names in groups:
            for name in page_names:
                page = pages_by_name.get(name)
                if page is not None and page["path"] == pathname:
                    return domain
    return None


# Callback to generate navigation items, highlight the active page, and
# toggle the Power / Gas / Carbon accordion domains.
@app.callback(
    Output('nav-items', 'children'),
    Output('sidebar-open-domains', 'data'),
    Input('url', 'pathname'),
    Input({'type': 'domain-header', 'domain': dash.ALL}, 'n_clicks'),
    State('sidebar-open-domains', 'data'),
)
def update_nav_items(pathname, _domain_clicks, open_state):
    """Render the domain-accordion sidebar based on URL + open/closed state."""
    pathname = pathname or ""
    pages_by_name = {p["name"]: p for p in dash.page_registry.values()}
    active_domain = _active_domain(pathname, pages_by_name)

    # Normalise persisted open state; first visit -> open only the active
    # domain (or everything if the current page isn't in any domain).
    if isinstance(open_state, dict) and open_state:
        open_state = {d: bool(open_state.get(d, False)) for d in _DOMAIN_NAMES}
    elif active_domain is not None:
        open_state = {d: (d == active_domain) for d in _DOMAIN_NAMES}
    else:
        open_state = {d: True for d in _DOMAIN_NAMES}

    triggered = dash.callback_context.triggered_id
    if isinstance(triggered, dict) and triggered.get("type") == "domain-header":
        # Ignore spurious triggers from re-created headers (n_clicks reset to 0).
        triggered_value = dash.callback_context.triggered[0]["value"]
        if not triggered_value:
            return dash.no_update, dash.no_update
        domain = triggered["domain"]
        open_state[domain] = not open_state.get(domain, False)
    elif active_domain is not None:
        # URL navigation: make sure the active page's domain is expanded.
        open_state[active_domain] = True

    grouped_names: set[str] = set()
    children: list = []
    for domain, icon_class, groups in SIDEBAR_DOMAINS:
        is_open = open_state.get(domain, False)
        children.append(_nav_domain_header(domain, icon_class, is_open))

        domain_children: list = []
        for group_label, page_names in groups:
            group_items: list = []
            for name in page_names:
                page = pages_by_name.get(name)
                if page is None:
                    logger.warning("Sidebar: page %r not found in registry", name)
                    continue
                grouped_names.add(name)
                group_items.append(_nav_link(page, pathname, indent=True))
            if not group_items:
                continue
            domain_children.append(_nav_group_header(group_label, indent=True))
            domain_children.extend(group_items)

        if is_open:
            children.extend(domain_children)

    # Defensive: surface any registered pages we forgot to group, so nothing
    # silently disappears from the sidebar after a rename.
    leftovers = [
        p for name, p in pages_by_name.items() if name not in grouped_names
    ]
    if leftovers:
        children.append(_nav_group_header("Other"))
        for page in leftovers:
            children.append(_nav_link(page, pathname))

    return children, open_state


# Global page chrome.  All visual styling lives in ``assets/dashboard.css``,
# which Dash auto-includes via ``{%css%}``.  Keep this template tiny.
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        <link rel="icon" type="image/png" href="/assets/favicon.png">
        {%css%}
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''


register_freshness_callbacks(app)
register_toast_callbacks(app)


def _register_startup_callbacks():
    """Register page callbacks deterministically at app startup."""
    try:
        from pages.fundamentals import initialize_fundamentals_callbacks
        initialize_fundamentals_callbacks(app)
        
        from pages.heatrate import initialize_heatrate_callbacks
        initialize_heatrate_callbacks(app)

        from pages.price_gnn import initialize_price_gnn_callbacks
        initialize_price_gnn_callbacks(app)

        # DISABLED: generation page hidden from dashboard
        # from pages.generation import initialize_generation_callbacks
        # initialize_generation_callbacks(app)
    except Exception as exc:
        logger.error("Startup callback registration failed: %s", exc, exc_info=True)
        if IS_DEV:
            raise


def _log_callback_inventory():
    """Log callback inventory + required callback presence for diagnostics."""
    keys = sorted(app.callback_map.keys())
    logger.info("Callback inventory: total=%d", len(keys))
    logger.info("Callback IDs:\n%s", "\n".join(keys))
    required = {
        "availability": "avail-charts-container.children",
        # "generation": "gen-charts-container.children",  # DISABLED
        "weather_forecast": "fcst-grid-container.children",
        "scenario_impact": "sci-regime-map.figure",
        "heatrate_availability": "hr-avail-main-chart.figure",
    }
    for name, token in required.items():
        present = any(token in k for k in keys)
        logger.info("Callback check: %s=%s", name, "ok" if present else "missing")


_register_startup_callbacks()


@app.callback(
    Output('toast-store', 'data', allow_duplicate=True),
    Input('fcst-toast-store', 'data'),
    State('toast-store', 'data'),
    prevent_initial_call=True,
)
def relay_forecast_toasts(fcst_toasts, current_toasts):
    """Forward toasts from the forecast monitor to the global toast container."""
    if not fcst_toasts:
        return dash.no_update
    
    # Combined toasts, ensuring we don't duplicate existing ones by ID if possible
    # (though fcst-toast-store usually sends fresh ones)
    current_toasts = current_toasts or []
    return current_toasts + fcst_toasts




# =============================================================================
# DATA SCHEDULER: Background refresh + cache status endpoint
# =============================================================================
import json as _json
import atexit
import logging

_logger = logging.getLogger("portal_app")


def _setup_scheduler():
    """Register data sources with the background scheduler.

    ALL heavy data loading is deferred (``run_immediately=False``).
    Data is fetched only when a user first visits the relevant page OR
    when the cron trigger fires.  Loader functions use lazy imports so
    that jain_commods, Snowflake, etc. are only imported at call time.
    """

    # ── Price dashboard data (~60 s) ─────────────────────────────────────
    def _load_prices():
        # Fail fast with a clear message if Snowflake creds aren't resolvable.
        # jain_commods.EEXQuery() otherwise crashes deep inside
        # snowflake.connector with "'NoneType' object has no attribute 'find'"
        # when account=None, which is hard to diagnose from the traceback.
        # Creds are normally baked into the image via deploy/jain_commods_login.py
        # (see Dockerfile). Env-var fallback is kept as a safety net.
        try:
            from jain_commods.login import snowflake_login  # type: ignore
            if not snowflake_login.get("account"):
                raise ValueError("snowflake_login.account is empty")
        except Exception:
            missing = [
                k for k in ("SNOWFLAKE_ACCOUNT", "SNOWFLAKE_USR", "SNOWFLAKE_KEYFILE_PASS")
                if not os.getenv(k)
            ]
            if missing:
                raise RuntimeError(
                    f"price_data loader: neither jain_commods/login.py nor env vars "
                    f"are populated (missing env: {missing}). Rebuild the image so "
                    "Dockerfile injects deploy/jain_commods_login.py, or set the "
                    "env vars in deploy/prod.env."
                )
        from price_dashboard.utils.data_loader import load_data
        return load_data()

    dashboard_cache.register_source(
        name="price_data",
        loader=_load_prices,
        cron="0 6,12,18 * * 1-5",
        run_immediately=False,
        ttl=14400,
    )

    # ── Fuel switching data (~7 s) ───────────────────────────────────────
    def _load_fuel_switching():
        from pages.fuel_switching import load_market_data
        return load_market_data()

    dashboard_cache.register_source(
        name="fuel_switching_data",
        loader=_load_fuel_switching,
        cron="0 6,12,18 * * 1-5",
        run_immediately=False,
        ttl=14400,
    )

    # ── French nuclear availability (~4 s) ───────────────────────────────
    def _load_french_nuclear():
        from pages.french_nuclear import load_french_nuclear_data
        return load_french_nuclear_data()

    dashboard_cache.register_source(
        name="french_nuclear_data",
        loader=_load_french_nuclear,
        cron="0 6,18 * * *",
        run_immediately=False,
        ttl=21600,
    )

    # ── Other Nuclear (EQ REMIT availability for the default window) ─────
    def _load_other_nuclear():
        from core.other_nuclear.data import load_other_nuclear_data
        return load_other_nuclear_data()

    dashboard_cache.register_source(
        name="other_nuclear_data",
        loader=_load_other_nuclear,
        cron="0 6,12,18 * * *",
        run_immediately=False,
        ttl=14400,
    )

    # ── Fundamentals (availability + generation, ~30 s) ──────────────────
    def _load_fundamentals():
        from pages.fundamentals import load_fundamentals_data
        return load_fundamentals_data()

    dashboard_cache.register_source(
        name="fundamentals_data",
        loader=_load_fundamentals,
        cron="30 5,11,17 * * *",
        run_immediately=False,
        ttl=7200,
    )

    # ── Forecast monitor data (today + yesterday for both regular and
    #    ensemble classes so Forecast Monitor and SCI Dashboard are instant) ──
    def _load_forecasts():
        from datetime import date, timedelta
        from fundamental_dashboard.utils.forecast_data_handler import (
            load_forecast, DEFAULT_ZONES, _prefetch_forecasts,
        )

        today = date.today()
        yesterday = today - timedelta(days=1)
        model = "EC-ENS 00z"
        variables = ["Wind", "Solar", "Demand", "Residual Load"]

        _prefetch_forecasts(variables, model, [today, yesterday], DEFAULT_ZONES)

        # Also warm the SCI ensemble cache and pre-compute default aggregates
        try:
            from fundamental_dashboard.pages.sci_dashboard import (
                _load_all_ensemble_data, precompute_default_scenario,
            )
            _load_all_ensemble_data(model, today)
            precompute_default_scenario(model, today)
        except Exception as e:
            _logger.debug("Ensemble pre-cache failed: %s", e)

        return {"preloaded": True}

    dashboard_cache.register_source(
        name="forecast_data",
        loader=_load_forecasts,
        interval_minutes=120,
        run_immediately=False,
        ttl=7200,
    )

    # ── EPEX spot prices ──────────────────────────────────────────────────
    def _load_epex():
        from datetime import date
        from pages.epex_auction import SpotPriceDataLoader
        loader = SpotPriceDataLoader()
        return loader.fetch_prices_for_cache(date.today())

    dashboard_cache.register_source(
        name="epex_spot",
        loader=_load_epex,
        interval_minutes=15,
        run_immediately=False,
        ttl=900,
    )

    # ── Heatmap Balance (zonal price + fundamentals matrices, ~20 s) ─────
    # Loader clears in-process S3 frame caches first; see core.heatmap_balance.warmup.
    def _load_heatmap_balance():
        from pages.heatmap_balance import load_heatmap_balance_data
        return load_heatmap_balance_data()

    dashboard_cache.register_source(
        name="heatmap_balance_data",
        loader=_load_heatmap_balance,
        cron="15 5,11,17 * * *",
        run_immediately=False,
        ttl=7200,
    )

    # ── Hydro (reservoir gen + price + hydro balance, ~15 s for NO) ──────
    def _load_hydro():
        from pages.hydro import load_hydro_data
        from core.hydro.constants import DEFAULT_ZONE
        return load_hydro_data(DEFAULT_ZONE)

    dashboard_cache.register_source(
        name="hydro_data",
        loader=_load_hydro,
        cron="30 5,11,17 * * *",
        run_immediately=False,
        ttl=14400,
    )

    # ── Flows (NCF day-ahead + spot prices + net export, last 30 days) ────
    def _load_flows():
        from pages.flows import load_flows_data
        return load_flows_data()  # default: last 30 days

    dashboard_cache.register_source(
        name="flows_data",
        loader=_load_flows,
        cron="45 5,11,17 * * *",
        run_immediately=False,
        ttl=14400,
    )

    # ── Flow-Based / Transmission (MaxBex, MinMax/JAO NP, NTC) ───────────
    # Loads each underlying class once into a disk-cached full-history frame;
    # the page callbacks then slice in memory on zone/date changes.
    def _load_flowbased():
        from core.flowbased.data import refresh_flowbased_cache
        return refresh_flowbased_cache()

    dashboard_cache.register_source(
        name="flowbased_data",
        loader=_load_flowbased,
        cron="50 5,11,17 * * *",
        run_immediately=False,
        ttl=21600,
    )

    # ── HeatRate model data (~5 s) ────────────────────────────────────────
    def _load_heatrate():
        from portal_pages.heatrate.data_handler import HeatRateDataHandler
        handler = HeatRateDataHandler()
        return handler.load_all_data()

    dashboard_cache.register_source(
        name="heatrate_data",
        loader=_load_heatrate,
        cron="0 * * * *",  # Refresh every hour
        run_immediately=False,
        ttl=3600,
    )

    # ── Commodity Essentials gas data (storage, LNG, key flows, demand) ──
    # Configurable asset/variable map lives in core.gas_data_ce.constants.
    # Creds: CE_USER / CE_PASS (deploy/prod.env). UK-time cron.
    def _load_gas_data_ce():
        from core.gas_data_ce.data import load_gas_data_ce
        return load_gas_data_ce()

    from core.gas_data_ce.constants import (
        CRON as _CE_GAS_CRON,
        CRON_TIMEZONE as _CE_GAS_TZ,
        SOURCE_NAME as _CE_GAS_SOURCE,
        TTL_SECONDS as _CE_GAS_TTL,
    )

    dashboard_cache.register_source(
        name=_CE_GAS_SOURCE,
        loader=_load_gas_data_ce,
        cron=_CE_GAS_CRON,
        timezone=_CE_GAS_TZ,
        run_immediately=False,
        ttl=_CE_GAS_TTL,
    )
    # Appear in Data Source Status immediately (before warm-up finishes).
    from core.gas_data_ce.data import mark_ce_freshness_pending
    mark_ce_freshness_pending()

    def _load_gas_inj_wdr():
        from core.gas_inj_wdr.data import load_inj_wdr_capability
        return load_inj_wdr_capability()

    from core.gas_inj_wdr.constants import (
        CRON as _INJ_WDR_CRON,
        CRON_TIMEZONE as _INJ_WDR_TZ,
        SOURCE_NAME as _INJ_WDR_SOURCE,
        TTL_SECONDS as _INJ_WDR_TTL,
    )

    dashboard_cache.register_source(
        name=_INJ_WDR_SOURCE,
        loader=_load_gas_inj_wdr,
        cron=_INJ_WDR_CRON,
        timezone=_INJ_WDR_TZ,
        run_immediately=False,
        ttl=_INJ_WDR_TTL,
    )

    # ── Bloomberg weather actuals (daily) + GenWindActual daily means ─────
    # CSV history via get_weather_actuals is read at request time (fast);
    # only the BBG incremental tail + wind gen are cached here.
    def _load_weather_bbg():
        from core.weather_bbg.data import load_weather_bbg
        return load_weather_bbg()

    from core.weather_bbg.constants import (
        CRON as _WX_BBG_CRON,
        CRON_TIMEZONE as _WX_BBG_TZ,
        SOURCE_NAME as _WX_BBG_SOURCE,
        TTL_SECONDS as _WX_BBG_TTL,
    )

    dashboard_cache.register_source(
        name=_WX_BBG_SOURCE,
        loader=_load_weather_bbg,
        cron=_WX_BBG_CRON,
        timezone=_WX_BBG_TZ,
        run_immediately=False,
        ttl=_WX_BBG_TTL,
    )
    from core.weather_bbg.data import mark_weather_bbg_freshness_pending
    mark_weather_bbg_freshness_pending()

    # ── Kpler LNG (Qatar exports today; more datasets later) ───────────────
    # Creds: KPLER_LNG_EMAIL / KPLER_LNG_PASSWORD (deploy/prod.env). Hourly.
    def _load_lng_data_kpler():
        from core.lng_data_kpler.data import load_lng_data_kpler
        return load_lng_data_kpler()

    from core.lng_data_kpler.constants import (
        CRON as _KPLER_CRON,
        CRON_TIMEZONE as _KPLER_TZ,
        SOURCE_NAME as _KPLER_SOURCE,
        TTL_SECONDS as _KPLER_TTL,
    )

    dashboard_cache.register_source(
        name=_KPLER_SOURCE,
        loader=_load_lng_data_kpler,
        cron=_KPLER_CRON,
        timezone=_KPLER_TZ,
        run_immediately=False,
        ttl=_KPLER_TTL,
    )
    from core.lng_data_kpler.data import mark_kpler_freshness_pending
    mark_kpler_freshness_pending()

    # ── Bloomberg LNG ship positions (lat/lon snapshot; hourly w/ Kpler) ──
    def _load_lng_data_bbg_ships():
        from core.lng_data_bbg_ships.data import load_lng_data_bbg_ships
        return load_lng_data_bbg_ships()

    from core.lng_data_bbg_ships.constants import (
        CRON as _BBG_SHIPS_CRON,
        CRON_TIMEZONE as _BBG_SHIPS_TZ,
        SOURCE_NAME as _BBG_SHIPS_SOURCE,
        TTL_SECONDS as _BBG_SHIPS_TTL,
    )

    dashboard_cache.register_source(
        name=_BBG_SHIPS_SOURCE,
        loader=_load_lng_data_bbg_ships,
        cron=_BBG_SHIPS_CRON,
        timezone=_BBG_SHIPS_TZ,
        run_immediately=False,
        ttl=_BBG_SHIPS_TTL,
    )
    from core.lng_data_bbg_ships.data import mark_bbg_ships_freshness_pending
    mark_bbg_ships_freshness_pending()

    # ── TTF spreads (ICE settle histories + rolling generic spreads, ~30-60 s) ─
    # Interactive version of the eu_reports spreads_monitor email; the spread
    # engine is shared via jain_commods.core.analytics.spreads.
    def _load_ttf_spreads():
        from core.ttf_spreads.data import load_ttf_spreads_data
        return load_ttf_spreads_data()

    from core.ttf_spreads.constants import (
        CRON as _TTF_SPREADS_CRON,
        SOURCE_NAME as _TTF_SPREADS_SOURCE,
        TTL_SECONDS as _TTF_SPREADS_TTL,
    )

    dashboard_cache.register_source(
        name=_TTF_SPREADS_SOURCE,
        loader=_load_ttf_spreads,
        cron=_TTF_SPREADS_CRON,
        run_immediately=False,
        ttl=_TTF_SPREADS_TTL,
    )

    # ── Low-beta spreads (TTF/JKM/TFU universe + FM regressions, ~30-60 s) ─
    # Spread universe + regression engine is shared via
    # jain_commods.core.analytics.spread_beta.
    def _load_low_beta_spreads():
        from core.low_beta_spreads.data import load_low_beta_spreads_data
        return load_low_beta_spreads_data()

    from core.low_beta_spreads.constants import (
        CRON as _LOW_BETA_CRON,
        SOURCE_NAME as _LOW_BETA_SOURCE,
        TTL_SECONDS as _LOW_BETA_TTL,
    )

    dashboard_cache.register_source(
        name=_LOW_BETA_SOURCE,
        loader=_load_low_beta_spreads,
        cron=_LOW_BETA_CRON,
        run_immediately=False,
        ttl=_LOW_BETA_TTL,
    )

    # ── LNG netbacks (ICE HH/JKM/TFU/Spark + Platts freight, ~15-30 s) ──
    def _load_lng_netbacks():
        from core.lng_netbacks.data import load_lng_netbacks_data
        return load_lng_netbacks_data()

    from core.lng_netbacks.constants import (
        CRON as _LNG_NB_CRON,
        SOURCE_NAME as _LNG_NB_SOURCE,
        TTL_SECONDS as _LNG_NB_TTL,
    )

    dashboard_cache.register_source(
        name=_LNG_NB_SOURCE,
        loader=_load_lng_netbacks,
        cron=_LNG_NB_CRON,
        run_immediately=False,
        ttl=_LNG_NB_TTL,
    )
    from core.lng_netbacks.data import mark_lng_netbacks_freshness_pending
    mark_lng_netbacks_freshness_pending()

    # ── Generation per-unit analytics (DISABLED — page hidden from dashboard) ─
    # def _load_generation():
    #     from portal_pages.generation.data_handler import GenerationDataHandler
    #     handler = GenerationDataHandler()
    #     return handler.load_all_data()
    #
    # dashboard_cache.register_source(
    #     name="generation_data",
    #     loader=_load_generation,
    #     cron="0 */3 * * *",  # Invalidate lazy caches every 3 hours
    #     run_immediately=False,
    #     ttl=10800,
    # )

    # Start scheduler, then warm all sources concurrently so the first page
    # load is fast regardless of which page the user visits first.
    dashboard_cache.start(warm=False)

    def _warm_sources_parallel():
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import os as _os

        sources = [
            "fuel_switching_data",
            "fundamentals_data",
            "price_data",
            "forecast_data",
            "french_nuclear_data",
            "other_nuclear_data",
            "epex_spot",
            "heatmap_balance_data",
            "hydro_data",
            "flows_data",
            "heatrate_data",
            "gas_data_ce",
            "gas_inj_wdr",
            "weather_bbg",
            "lng_data_kpler",
            "lng_data_bbg_ships",
            "ttf_spreads_data",
            "low_beta_spreads_data",
            "lng_netbacks_data",
            # "generation_data",  # DISABLED
        ]

        def _refresh(name):
            dashboard_cache.force_refresh(name)
            # force_refresh swallows loader exceptions; check whether data
            # actually landed in the cache before reporting success.
            if dashboard_cache.get(f"source:{name}") is None:
                err = getattr(dashboard_cache._sources.get(name), "error", None)
                raise RuntimeError(err or f"{name} loader returned no data")
            return name

        # Parallel warm-up of large pandas/Arrow loads often triggers a native
        # ACCESS_VIOLATION (-1073741819) on Windows. Default to serial there;
        # override with CACHE_WARM_WORKERS.
        default_workers = "1" if _os.name == "nt" else "4"
        try:
            warm_workers = max(1, int(_os.getenv("CACHE_WARM_WORKERS", default_workers)))
        except ValueError:
            warm_workers = 1 if _os.name == "nt" else 4

        _logger.info("Cache warm-up starting (%d workers)", warm_workers)
        with ThreadPoolExecutor(
            max_workers=warm_workers, thread_name_prefix="cache-warm"
        ) as pool:
            futures = {pool.submit(_refresh, s): s for s in sources}
            for fut in as_completed(futures):
                src = futures[fut]
                try:
                    fut.result()
                    _logger.info("Warm-up OK: %s", src)
                except Exception as exc:
                    _logger.warning("Warm-up FAILED for %s: %s", src, exc)

    import threading as _threading
    _threading.Thread(target=_warm_sources_parallel, daemon=True, name="cache-warm-parallel").start()
    _logger.info("DashboardCache: registered %d sources", len(dashboard_cache.registered_sources))


_setup_scheduler()
atexit.register(dashboard_cache.shutdown)

_log_callback_inventory()


# =============================================================================
# DEFAULT-VIEW FIGURE REGISTRY
# -----------------------------------------------------------------------------
# Each page contributes a *builder* for its default chart.  The registry
# precomputes these on startup (and on data-source refresh) and stashes the
# serialised JSON in ``figure_cache``.  Callbacks then return the cached
# figure in < 50 ms instead of rebuilding from scratch on every page visit.
# =============================================================================
def _register_default_figures():
    """Register per-page default-view figure builders.

    Adding a new page's default chart here = instant first-load for that page.
    Builders must be fast *after* their data source is warm, and must not
    depend on ``dash.callback_context`` (we call them outside of a callback).
    """
    # ---- Fuel Switching: default = DE power / TTF gas, default efficiencies ----
    def _build_fuel_switching_default():
        """Pre-build the default fuel-switching chart.

        Delegates to the canonical ``build_main_switching_chart`` + historical
        SRMC compute helpers so the pre-cached figure is byte-for-byte
        identical to what the slow-path callback would produce.  Previously
        this builder inlined a simplified subset of the chart code that
        omitted the coal and lignite bands, producing a default view that
        differed from every other view.
        """
        import pandas as pd
        from pages.fuel_switching import market_cache, calculator, load_market_data
        from core.fuel_switching.charts import build_main_switching_chart
        from core.fuel_switching.compute import compute_historical_srmc
        from core.fuel_switching.constants import (
            DEFAULT_GAS_EFFS, DEFAULT_COAL_EFFS, DEFAULT_LIGNITE_EFFS,
        )

        # Ensure the data is present (idempotent).
        if market_cache.last_refresh is None:
            load_market_data()

        options, default_settlement = market_cache.get_settlement_date_options()
        if not options:
            return None
        settlement = default_settlement or options[0]["value"]
        if not market_cache.is_complete_settlement_date(settlement):
            settlement = options[0]["value"]

        power_hub, gas_hub = "DE", "TTF"
        gas_effs = list(DEFAULT_GAS_EFFS)
        coal_effs = list(DEFAULT_COAL_EFFS)
        lignite_effs = list(DEFAULT_LIGNITE_EFFS)

        df = market_cache.get_forward_data(power_hub, gas_hub, settlement_date=settlement)
        hist_df = market_cache.get_spot_data(power_hub, gas_hub)
        if df.empty:
            return None

        df = calculator.calculate_srmc(
            df.copy(), gas_effs, coal_effs, lignite_effs, lignite_fuel_cost=1.5,
        )

        if not hist_df.empty:
            hist_df = hist_df.copy()
            d_col = "date" if "date" in hist_df.columns else "DATE"
            hist_df["date"] = pd.to_datetime(hist_df[d_col])
            hist_df = hist_df[hist_df["date"] >= pd.Timestamp("2023-01-01")]
            if "Power" in hist_df.columns:
                hist_df["Power_Rolling"] = hist_df["Power"].rolling(14).mean()
            hist_df = compute_historical_srmc(
                hist_df, gas_effs, coal_effs, lignite_effs,
                lignite_fuel_cost=1.5, is_uk_mode=False,
            )

        return build_main_switching_chart(
            df, hist_df, power_hub, gas_hub, gas_effs, coal_effs, lignite_effs,
            currency="€",
        )

    figure_registry.register(
        key="fuel_switching:DE:TTF:default",
        builder=_build_fuel_switching_default,
        sources=["fuel_switching_data"],
        ttl=7200,
    )


try:
    _register_default_figures()
except Exception as _exc:
    _logger.warning("Figure registry: default registration failed: %s", _exc, exc_info=True)


def _warm_figure_registry():
    """Build registered figures once their declared data sources are loaded.

    Each ``_FigureSpec`` declares ``sources=(…)``.  We poll the dashboard cache
    and only build a figure once *all* of its sources are populated — building
    earlier just races the loader and produces a spurious ``builder returned
    None`` error.  After the initial warm-up we fall back to a 15-min refresh
    loop so cached figures stay fresh as sources tick.
    """
    import time as _time

    def _sources_for(key: str) -> list[str]:
        return list(figure_registry.status()["figures"].get(key, {}).get("sources", []))

    def _all_ready(sources: list[str]) -> bool:
        return all(dashboard_cache.get(f"source:{s}") is not None for s in sources)

    pending = set(figure_registry.keys())
    deadline = _time.time() + 900  # 15 min cap on initial warm-up
    while pending and _time.time() < deadline:
        ready_now = [k for k in pending if _all_ready(_sources_for(k))]
        for key in ready_now:
            try:
                figure_registry.build(key)
            except Exception as exc:
                _logger.warning("figure build failed for %s: %s", key, exc)
            pending.discard(key)
        if pending:
            _time.sleep(3)

    if pending:
        _logger.warning(
            "figure_registry warm-up timed out with %d figure(s) still pending: %s",
            len(pending), sorted(pending),
        )

    while True:
        _time.sleep(900)  # 15 min
        try:
            figure_registry.warm_all(max_workers=2)
        except Exception as exc:
            _logger.warning("figure_registry periodic rebuild failed: %s", exc)


threading.Thread(target=_warm_figure_registry, daemon=True, name="fig-registry-warmer").start()


# ── /api/cache-status JSON endpoint ──────────────────────────────────────
@app.server.route("/api/cache-status")
def _api_cache_status():
    status = dashboard_cache.get_status()
    return _json.dumps(status, indent=2, default=str), 200, {"Content-Type": "application/json"}


# ── /api/callback-status JSON endpoint ────────────────────────────────────
@app.server.route("/api/callback-status")
def _api_callback_status():
    callback_keys = list(app.callback_map.keys())
    required = {
        "availability": "avail-charts-container.children",
        # "generation": "gen-charts-container.children",  # DISABLED
        "weather_forecast": "fcst-grid-container.children",
        "scenario_impact": "sci-regime-map.figure",
        "heatrate_availability": "hr-avail-main-chart.figure",
    }
    checks = {
        name: any(token in key for key in callback_keys)
        for name, token in required.items()
    }
    return _json.dumps({
        "total_callbacks": len(callback_keys),
        "checks": checks,
    }, indent=2), 200, {"Content-Type": "application/json"}


# ── /api/force-refresh endpoint ──────────────────────────────────────────
@app.server.route("/api/force-refresh/<source_name>", methods=["POST"])
def _api_force_refresh(source_name):
    if source_name in dashboard_cache.registered_sources:
        threading.Thread(target=dashboard_cache.force_refresh, args=(source_name,), daemon=True).start()
        return _json.dumps({"status": "queued", "source": source_name}), 202, {"Content-Type": "application/json"}
    return _json.dumps({"error": f"Unknown source: {source_name}"}), 404, {"Content-Type": "application/json"}


@app.server.route("/api/health")
def _api_health():
    """Health check endpoint for load balancers and monitoring."""
    sources = dashboard_cache.registered_sources
    loaded = sum(1 for s in sources if dashboard_cache.get(f"source:{s}") is not None)
    sources_ok = loaded == len(sources)
    status_code = 200 if sources_ok else 503
    return _json.dumps({
        "status": "healthy" if sources_ok else "degraded",
        "env": DASH_ENV,
        "host": HOST,
        "port": PORT,
        "sources_loaded": loaded,
        "sources_total": len(sources),
    }), status_code, {"Content-Type": "application/json"}


@app.server.route("/api/live")
def _api_live():
    """Liveness endpoint: process is up and serving HTTP."""
    return _json.dumps({
        "status": "alive",
        "env": DASH_ENV,
        "host": HOST,
        "port": PORT,
    }), 200, {"Content-Type": "application/json"}


if __name__ == '__main__':
    if IS_DEV:
        _logger.info("Starting portal in DEV mode host=%s port=%s debug=%s", HOST, PORT, DEBUG)
        # Dash 3.x removed app.run_server(); the replacement is app.run() with
        # the same kwargs.  Using app.run keeps us forward-compatible with
        # Dash 2.x as well (it has been an alias since 2.13).
        app.run(
            host=HOST,
            debug=DEBUG,
            port=PORT,
            use_reloader=False,
            dev_tools_hot_reload=True,
        )
    else:
        # Production: use Waitress (thread-pooled, stable, no debug)
        from waitress import serve
        # IO-bound workload (Snowflake/S3/Bloomberg) + few concurrent users →
        # lots of threads cheaply improves responsiveness.  Connection_limit
        # and channel_timeout are tuned to keep Plotly's streaming fetches
        # healthy on slow networks.
        waitress_threads = get_waitress_threads()
        connection_limit = get_waitress_connection_limit()
        channel_timeout = get_waitress_channel_timeout()
        _logger.info(
            "Starting portal in PRODUCTION mode host=%s port=%s threads=%s",
            HOST, PORT, waitress_threads,
        )
        serve(
            app.server,
            host=HOST,
            port=PORT,
            threads=waitress_threads,
            connection_limit=connection_limit,
            channel_timeout=channel_timeout,
        )
