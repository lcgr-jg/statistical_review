import logging
import os
import sys
import pathlib
import threading

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s %(message)s')

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import install_theme_css, register_health  # noqa: E402

import dash  # noqa: E402
from dash import html, dcc, Input, Output  # noqa: E402
import dash_bootstrap_components as dbc  # noqa: E402
from utils.navbar import create_navbar  # noqa: E402

app = dash.Dash(
    __name__,
    suppress_callback_exceptions=True,
    external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.FONT_AWESOME],
    title="Stack Dashboard",
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)

install_theme_css(app)

_prewarm_done = threading.Event()

app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    create_navbar(),
    html.Div(id='page-content', className='mt-2'),
])

# ── Import page modules & register callbacks ──────────────────────────────
from pages.prices import layout as prices_layout, register_callbacks as reg_prices
from pages.dispatch import layout as dispatch_layout, register_callbacks as reg_dispatch
from pages.plant_stack import layout as plant_stack_layout, register_callbacks as reg_plant_stack
from pages.assumptions import layout as assumptions_layout, register_callbacks as reg_assumptions
from pages.run_comparison import get_layout as run_comparison_layout, register_stack_prices_callbacks as reg_run_comparison
from pages.benchmark import layout as benchmark_layout, register_callbacks as reg_benchmark
from pages.gen_benchmark import layout as gen_bench_layout, register_callbacks as reg_gen_bench

reg_prices(app)
reg_dispatch(app)
reg_plant_stack(app)
reg_assumptions(app)
reg_run_comparison(app)
reg_benchmark(app)
reg_gen_bench(app)

_ROUTES = {
    '/prices': prices_layout,
    '/dispatch': dispatch_layout,
    '/plant-stack': plant_stack_layout,
    '/assumptions': assumptions_layout,
    '/run-comparison': run_comparison_layout,
    '/benchmark': benchmark_layout,
    '/gen-benchmark': gen_bench_layout,
}


@app.callback(Output('page-content', 'children'), Input('url', 'pathname'))
def route(pathname):
    if pathname:
        p = pathname.rstrip('/').lower() or '/'
    else:
        p = '/'
    factory = _ROUTES.get(p)
    if factory:
        return factory() if callable(factory) else factory
    return prices_layout() if callable(prices_layout) else prices_layout


def _prewarm():
    """Background thread: pre-load metadata + prices so first page load is instant.

    Only warms indexed-table queries (prices, run_time, scenarios).
    Demand and dispatch use unindexed 100M+ row tables — let them load lazily.
    """
    import time
    logger = logging.getLogger('prewarm')
    logger.info("Pre-warming cache for DE/FR BASECASE ...")
    t0 = time.perf_counter()
    try:
        from pages.prices import (
            _get_run_time, _fetch_available_scenarios,
            _fetch_stack_prices, _fetch_ensemble_p50,
            _fetch_met_prices,
        )
        from pages.dispatch import _get_run_time as d_rt

        for c in ('DE', 'FR'):
            _get_run_time(c, 'BASECASE')
            _fetch_available_scenarios(c, 'BASECASE')
            _fetch_stack_prices(c, 'BASECASE', 'BASELINE')
            _fetch_available_scenarios(c, 'ENS_MEDIUM')
            _fetch_ensemble_p50(c, 'ENS_MEDIUM')
            _fetch_met_prices(c)
            d_rt(c, 'BASECASE')
        logger.info("Pre-warm done in %.1fs", time.perf_counter() - t0)
    except Exception as exc:
        logger.warning("Pre-warm failed: %s", exc)
    finally:
        _prewarm_done.set()


register_health(app, name='stack', ready_flag=_prewarm_done.is_set)

_bg_thread = threading.Thread(target=_prewarm, daemon=True)
_bg_thread.start()


if __name__ == '__main__':
    # Port is read from the DASH_PORT env var so the same script works locally
    # and on the Linux server without editing code.  Fall back to 9105 to match
    # stack_dashboard.sh (the legacy app.sh launcher uses 9005).
    port = int(os.environ.get('DASH_PORT', '9105'))
    host = os.environ.get('DASH_HOST', '0.0.0.0')

    if os.environ.get('DASH_PRODUCTION', '').lower() in ('1', 'true', 'yes'):
        from waitress import serve
        logging.info('Serving via waitress on %s:%s (production mode)', host, port)
        serve(app.server, host=host, port=port, threads=int(os.environ.get('DASH_THREADS', '8')))
    else:
        app.run(debug=False, host=host, port=port, use_reloader=False)
