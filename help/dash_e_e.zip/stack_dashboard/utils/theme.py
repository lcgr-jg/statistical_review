"""Thin shim re-exporting the shared common.theme module.

All theme constants live in ``eu_dashboard_power/common/theme.py``.  This file
exists so existing ``from utils.theme import DARK_LAYOUT`` imports inside the
stack dashboard continue to work without a sweeping refactor.
"""

import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))

from common.theme import (  # noqa: F401,E402
    PLOT_HEIGHT, PLOT_TEMPLATE, DARK_LAYOUT,
    COLORS, TECHNO_COLORS, FUEL_COLORS,
    TABLE_STYLE_HEADER, TABLE_STYLE_CELL, TABLE_STYLE_DATA_CONDITIONAL,
    styled_layout, install_theme_css,
)
