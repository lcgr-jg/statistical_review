import sys
import pathlib

import dash_bootstrap_components as dbc
from dash import html

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import url_for  # noqa: E402


def create_navbar():
    return dbc.Navbar(
        dbc.Container([
            dbc.NavbarBrand("Stack Dashboard", href="/", className="me-auto"),
            dbc.Nav([
                dbc.NavItem(dbc.NavLink("Prices", href="/prices")),
                dbc.NavItem(dbc.NavLink("Dispatch", href="/dispatch")),
                dbc.NavItem(dbc.NavLink("Plant Stack", href="/plant-stack")),
                dbc.NavItem(dbc.NavLink("Assumptions", href="/assumptions")),
                dbc.NavItem(dbc.NavLink("Run Comparison", href="/run-comparison")),
                dbc.NavItem(dbc.NavLink("Benchmark", href="/benchmark")),
                dbc.NavItem(dbc.NavLink("Gen Benchmark", href="/gen-benchmark")),
                dbc.NavItem(dbc.NavLink("Fundamentals",
                                        href=url_for('fundamental'),
                                        external_link=True)),
                dbc.NavItem(dbc.NavLink("Price Dash",
                                        href=url_for('price'),
                                        external_link=True)),
                dbc.NavItem(dbc.NavLink("Portal",
                                        href=url_for('portal'),
                                        external_link=True)),
            ], navbar=True),
        ], fluid=True),
        className="dashboard-navbar",
        dark=True,
    )
