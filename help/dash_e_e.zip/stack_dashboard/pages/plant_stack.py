"""
Page 3 — Plant Stack: merit-order curve built from the model's own
marginal costs (power_stack_prompt_output), plant master data,
nuclear tranche prices, and renewable subsidy tranches.
"""
import logging
import time as _t
import pandas as pd
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output, dash_table, callback_context
from sqlalchemy import text as sa_text

from utils.db import read_table, get_postgres
from utils.cache import cached, clear_all
from utils.theme import (
    styled_layout,
    TABLE_STYLE_HEADER, TABLE_STYLE_CELL, TABLE_STYLE_DATA_CONDITIONAL,
)

logger = logging.getLogger(__name__)

NUCLEAR_CLUSTER_COLORS = {
    1: '#ffb347',
    2: '#e8990c',
    3: '#d4780a',
    4: '#c06008',
    5: '#a84a06',
    6: '#8f3504',
}

TECHNO_COLOR_MAP = {
    'nuclear': '#ffa94d',
    'gas': '#ff6b6b',
    'coal': '#868e96',
    'lignite': '#6b5b4c',
    'oil': '#e8590c',
    'biomass': '#51cf66',
    'wind': '#74c0fc',
    'solar': '#ffd43b',
    'virtual_thermal': '#cc5de8',
    'run_of_river': '#4dabf7',
    'reservoirs_and_pumped_storage': '#339af0',
    'import': '#adb5bd',
}

RENEWABLE_TECHNOS = {'wind', 'solar', 'run_of_river', 'reservoirs_and_pumped_storage', 'biomass'}

# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

@cached
def _load_plants(country: str) -> pd.DataFrame:
    try:
        df = read_table('power_plants_master_current')
        if df.empty:
            return df
        df.columns = [c.lower() for c in df.columns]
        df = df[df['country'] == country].copy()
        for c in ('capacity', 'efficiency'):
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors='coerce')
        if 'status' in df.columns:
            df = df[df['status'] != 'decommissioned']
        if 'decommission_date' in df.columns:
            df['decommission_date'] = pd.to_datetime(df['decommission_date'], errors='coerce')
            today = pd.Timestamp.now().normalize()
            df = df[df['decommission_date'].isna() | (df['decommission_date'] >= today)]
        return df
    except Exception as exc:
        logger.error("Plants %s: %s", country, exc)
        return pd.DataFrame()


@cached
def _fetch_available_hours(country: str, scenario_group: str = 'BASECASE',
                           scenario: str = 'BASELINE') -> list:
    """Return sorted list of (utc_ts, cet_label) for all hours in the latest run."""
    try:
        pg = get_postgres()
        with pg.engine.connect() as conn:
            rt = conn.execute(sa_text(
                "SELECT MAX(run_time_utc) FROM commod_research.power_stack_prompt_output "
                "WHERE country = :c AND scenario_group = :sg AND scenario = :sc"
            ), {'c': country, 'sg': scenario_group, 'sc': scenario}).scalar()
            if rt is None:
                return []
            hours = pd.read_sql(sa_text(
                "SELECT DISTINCT start_time_utc "
                "FROM commod_research.power_stack_prompt_output "
                "WHERE run_time_utc = :rt AND country = :c "
                "AND scenario_group = :sg AND scenario = :sc "
                "ORDER BY start_time_utc"
            ), conn, params={'rt': rt, 'c': country, 'sg': scenario_group, 'sc': scenario})
        if hours.empty:
            return []
        utc = pd.to_datetime(hours['start_time_utc'], utc=True)
        cet = utc.dt.tz_convert('CET')
        return [
            {'label': t.strftime('%Y-%m-%d %H:%M CET'), 'value': str(u)}
            for u, t in zip(utc, cet)
        ]
    except Exception as exc:
        logger.error("available_hours %s: %s", country, exc)
        return []


@cached
def _fetch_prompt_output(country: str, hour_utc: str = None,
                         scenario_group: str = 'BASECASE',
                         scenario: str = 'BASELINE') -> pd.DataFrame:
    """Fetch per-unit marginal cost / availability for a specific delivery hour
    from the model's prompt_output table (latest run).
    If hour_utc is None, picks the first hour with meaningful solar (10:00-14:00 CET)
    or falls back to the first hour."""
    try:
        pg = get_postgres()
        t0 = _t.perf_counter()
        with pg.engine.connect() as conn:
            rt = conn.execute(sa_text(
                "SELECT MAX(run_time_utc) FROM commod_research.power_stack_prompt_output "
                "WHERE country = :c AND scenario_group = :sg AND scenario = :sc"
            ), {'c': country, 'sg': scenario_group, 'sc': scenario}).scalar()
            if rt is None:
                logger.error("No prompt_output run for %s/%s/%s", country, scenario_group, scenario)
                return pd.DataFrame()

            if hour_utc:
                target_h = pd.Timestamp(hour_utc)
            else:
                # Pick a midday CET hour (10:00 CET = 08:00 UTC in summer)
                all_h = conn.execute(sa_text(
                    "SELECT DISTINCT start_time_utc "
                    "FROM commod_research.power_stack_prompt_output "
                    "WHERE run_time_utc = :rt AND country = :c "
                    "AND scenario_group = :sg AND scenario = :sc "
                    "ORDER BY start_time_utc"
                ), {'rt': rt, 'c': country, 'sg': scenario_group, 'sc': scenario}).fetchall()
                utc_hours = [r[0] for r in all_h]
                target_h = utc_hours[0]
                for h in utc_hours:
                    ts = pd.Timestamp(h)
                    if ts.tzinfo is None:
                        ts = ts.tz_localize('UTC')
                    cet_hour = ts.tz_convert('CET').hour
                    if 10 <= cet_hour <= 14:
                        target_h = h
                        break

            df = pd.read_sql(sa_text(
                "SELECT unit_id, techno, availability, marginal_cost, dispatched, shadow_price "
                "FROM commod_research.power_stack_prompt_output "
                "WHERE run_time_utc = :rt AND country = :c "
                "AND scenario_group = :sg AND scenario = :sc "
                "AND start_time_utc = :h "
                "ORDER BY marginal_cost"
            ), conn, params={'rt': rt, 'c': country, 'sg': scenario_group,
                             'sc': scenario, 'h': target_h})

        logger.info("prompt_output %s/%s/%s: %d units, hour=%s, run=%s (%.1fs)",
                     country, scenario_group, scenario, len(df),
                     str(target_h)[:19], str(rt)[:19], _t.perf_counter() - t0)
        return df
    except Exception as exc:
        logger.error("prompt_output %s: %s", country, exc, exc_info=True)
        return pd.DataFrame()


@cached
def _load_nuclear_cluster_map() -> dict:
    """Map unit_id -> cluster_id for nuclear tranche colouring (FR)."""
    try:
        pg = get_postgres()
        with pg.engine.connect() as conn:
            uc = pd.read_sql(sa_text(
                "SELECT asset_id, cluster_id "
                "FROM commod_research.units_clusters "
                "WHERE run_time_utc = (SELECT MAX(run_time_utc) FROM commod_research.units_clusters)"
            ), conn)
        if uc.empty:
            return {}
        return dict(zip(uc['asset_id'], uc['cluster_id']))
    except Exception as exc:
        logger.warning("Nuclear cluster map: %s", exc)
        return {}


# ---------------------------------------------------------------------------
# Merit-order chart — reads MC directly from model output
# ---------------------------------------------------------------------------

def _merit_order(output_df: pd.DataFrame, nuke_clusters: dict,
                 country: str, show_renewables: bool = False) -> go.Figure:
    fig = go.Figure()
    if output_df.empty:
        fig.update_layout(**styled_layout(f'{country} — Merit Order Curve', 'EUR/MWh'))
        return fig

    df = output_df.copy()
    df['availability'] = pd.to_numeric(df['availability'], errors='coerce').fillna(0)
    df['marginal_cost'] = pd.to_numeric(df['marginal_cost'], errors='coerce')
    df = df.dropna(subset=['marginal_cost'])
    df = df[df['availability'] > 0]

    if not show_renewables:
        df = df[~df['techno'].isin(RENEWABLE_TECHNOS)].copy()

    # Exclude imports (not dispatchable in the traditional sense)
    df = df[df['techno'] != 'import'].copy()

    df = df.sort_values('marginal_cost')
    df['cum_cap'] = df['availability'].cumsum()
    df['cum_start'] = df['cum_cap'] - df['availability']
    df['mid'] = df['cum_start'] + df['availability'] / 2

    shadow = df['shadow_price'].iloc[0] if 'shadow_price' in df.columns and not df.empty else None

    legend_added = set()
    for _, row in df.iterrows():
        techno = row['techno']
        uid = row['unit_id']

        # Nuclear cluster colouring for FR
        cid = nuke_clusters.get(uid, 0) if techno == 'nuclear' and country == 'FR' else 0
        if cid > 0:
            legend_key = f'nuclear cluster {cid}'
            color = NUCLEAR_CLUSTER_COLORS.get(cid, '#ffa94d')
        else:
            legend_key = techno
            color = TECHNO_COLOR_MAP.get(techno, '#868e96')

        disp = row.get('dispatched', 0) or 0
        hover = (
            f"<b>{uid}</b><br>"
            f"Techno: {techno}"
            f"{f' — Cluster {cid}' if cid > 0 else ''}<br>"
            f"Availability: {row['availability']:,.0f} MW<br>"
            f"Dispatched: {disp:,.0f} MW<br>"
            f"<b>MC: {row['marginal_cost']:.2f} EUR/MWh</b>"
            f"<extra></extra>"
        )

        show = legend_key not in legend_added
        legend_added.add(legend_key)

        display_name = (legend_key.replace('nuclear cluster ', 'Nuclear Cl.').title()
                        if 'cluster' in legend_key
                        else techno.replace('_', ' ').title())

        fig.add_trace(go.Bar(
            x=[row['mid']],
            y=[row['marginal_cost']],
            width=[row['availability']],
            marker_color=color,
            marker_line=dict(width=0),
            name=display_name,
            legendgroup=legend_key,
            showlegend=show,
            hovertemplate=hover,
        ))

    shadow_label = f' | Shadow price: {shadow:.1f}' if shadow is not None else ''
    fig.update_layout(**styled_layout(
        f'{country} — Merit Order (model MC){shadow_label}', 'Marginal Cost (EUR/MWh)'))
    fig.update_layout(
        xaxis=dict(title='Cumulative Capacity (MW)', gridcolor='rgba(255,255,255,0.06)'),
        barmode='overlay', height=500, showlegend=True,
        bargap=0,
    )
    return fig


def _plant_table(plants: pd.DataFrame):
    if plants.empty:
        return html.Div("No plant data", style={'color': '#8a8f9a'})
    cols_show = [c for c in ['unit_id', 'fuel_type', 'capacity', 'efficiency',
                             'commission_date', 'decommission_date'] if c in plants.columns]
    sub = plants[cols_show].copy()
    for c in ('capacity', 'efficiency'):
        if c in sub.columns:
            sub[c] = sub[c].round(2)
    return dash_table.DataTable(
        data=sub.head(200).to_dict('records'),
        columns=[{'name': c, 'id': c} for c in cols_show],
        style_header=TABLE_STYLE_HEADER,
        style_cell={**TABLE_STYLE_CELL, 'textAlign': 'left'},
        style_data_conditional=TABLE_STYLE_DATA_CONDITIONAL,
        page_size=15, sort_action='native', filter_action='native',
    )


@cached
def _nuclear_tranche_data() -> pd.DataFrame:
    """Cache the raw nuclear tranche data separately."""
    try:
        df = read_table('nuclear_tranches_bidding_prices', limit=5000)
        if not df.empty:
            df.columns = [c.lower() for c in df.columns]
        return df
    except Exception as exc:
        logger.warning("Nuclear tranches: %s", exc)
        return pd.DataFrame()


def _nuclear_tranche_chart(country: str) -> go.Figure:
    fig = go.Figure()
    try:
        df = _nuclear_tranche_data()
        if df.empty:
            fig.update_layout(**styled_layout(f'{country} — Nuclear Tranche Bidding Prices', 'EUR/MWh'))
            return fig
        price_cols = [c for c in df.columns if 'price' in c and 'p50' in c]
        if not price_cols:
            price_cols = [c for c in df.columns if 'price' in c][:3]
        if not price_cols:
            fig.update_layout(**styled_layout(f'{country} — Nuclear Tranche Bidding Prices', 'EUR/MWh'))
            return fig

        for pc in price_cols[:5]:
            fig.add_trace(go.Box(y=df[pc].dropna(), name=pc.replace('_', ' ').title()))
    except Exception as exc:
        logger.warning("Nuclear tranches: %s", exc)

    fig.update_layout(**styled_layout(f'{country} — Nuclear Tranche Bidding Prices', 'EUR/MWh'))
    return fig


def _renewable_subsidy_chart(plants: pd.DataFrame, country: str) -> go.Figure:
    """Stacked bar chart: capacity share × subsidy level per renewable tranche."""
    fig = go.Figure()
    ft = plants['fuel_type'].str.lower().str.strip() if 'fuel_type' in plants.columns else pd.Series(dtype=str)
    ren = plants[ft.isin({'wind', 'solar'})].copy()

    if ren.empty or 'capacity_share' not in ren.columns or 'subsidy_level' not in ren.columns:
        fig.update_layout(**styled_layout(f'{country} — Renewable Subsidy Tranches', 'EUR/MWh'))
        return fig

    ren['capacity_share'] = pd.to_numeric(ren['capacity_share'], errors='coerce').fillna(0)
    ren['subsidy_level'] = pd.to_numeric(ren['subsidy_level'], errors='coerce').fillna(0)
    ren['fuel'] = ft[ren.index]
    ren['label'] = ren['unit_id'].str.replace(f'_{country}', '', regex=False)

    tranche_colors = {
        'Wind_Onshore_CFD': '#5c9eed',
        'Wind_Onshore_FIT': '#74c0fc',
        'Wind_Offshore_FIT': '#1971c2',
        'Wind_Offshore_CFD': '#3b8de0',
        'Solar_CFD': '#fcc419',
        'Solar_FIT': '#ffd43b',
    }

    for fuel in ['wind', 'solar']:
        fuel_df = ren[ren['fuel'] == fuel].sort_values('subsidy_level')
        if fuel_df.empty:
            continue

        for _, row in fuel_df.iterrows():
            label = row['label']
            color = tranche_colors.get(label, '#868e96')
            share_pct = row['capacity_share'] * 100

            fig.add_trace(go.Bar(
                x=[fuel.title()],
                y=[share_pct],
                name=label,
                marker_color=color,
                text=f"{share_pct:.0f}%<br>{row['subsidy_level']:.0f} €/MWh",
                textposition='inside',
                textfont=dict(size=11, color='#1a1a2e'),
                hovertemplate=(
                    f"<b>{label}</b><br>"
                    f"Share: {share_pct:.1f}%<br>"
                    f"Subsidy: {row['subsidy_level']:.1f} EUR/MWh<br>"
                    f"MC in stack: {-row['subsidy_level']:.1f} EUR/MWh"
                    f"<extra></extra>"
                ),
            ))

    fig.update_layout(**styled_layout(
        f'{country} — Renewable Subsidy Tranches (capacity share & bid price)',
        '% of Aggregate Forecast'))
    fig.update_layout(
        barmode='stack',
        height=400,
        xaxis=dict(title=''),
        showlegend=True,
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='center', x=0.5),
    )
    return fig


def layout():
    return dbc.Container([
        html.H4("Plant Stack & Costs", className='text-center mb-1', style={'color': '#e0e0e0'}),
        dbc.Row([
            dbc.Col([
                html.Label("Country", className='control-label'),
                dcc.Dropdown(id='ps-country', options=[
                    {'label': 'Germany (DE)', 'value': 'DE'},
                    {'label': 'France (FR)', 'value': 'FR'},
                ], value='DE', clearable=False),
            ], width=2),
            dbc.Col([
                html.Label("Delivery Hour", className='control-label'),
                dcc.Dropdown(id='ps-hour', placeholder='Auto (midday CET)', clearable=True),
            ], width=4),
            dbc.Col([
                html.Br(),
                dbc.Checklist(
                    id='ps-show-renewables',
                    options=[{'label': ' Include Renewables', 'value': 'yes'}],
                    value=[],
                    switch=True,
                    className='mt-2',
                    style={'color': '#e0e0e0'},
                ),
            ], width=3),
            dbc.Col([
                html.Br(),
                dbc.Button("\u27f3 Refresh Data", id='ps-refresh', color='secondary',
                           size='sm', className='mt-1'),
            ], width=2),
        ], className='mb-3'),

        dbc.Card(dbc.CardBody(dcc.Loading(dcc.Graph(id='ps-merit'), type='circle')), className='mb-3'),

        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody(
                dcc.Loading(dcc.Graph(id='ps-renewables'), type='circle'),
            ), className='mb-3'), width=5),
            dbc.Col(dbc.Card(dbc.CardBody(
                dcc.Loading(dcc.Graph(id='ps-nuclear'), type='circle'),
            ), className='mb-3'), width=7),
        ]),

        dbc.Card(dbc.CardBody([
            html.H6("Power Plants", style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
            html.Div(id='ps-table'),
        ]), className='mb-3'),
    ], fluid=True)


def register_callbacks(app):

    @app.callback(
        Output('ps-hour', 'options'),
        Input('ps-country', 'value'),
    )
    def update_hour_options(country):
        return _fetch_available_hours(country)

    @app.callback(
        [Output('ps-merit', 'figure'),
         Output('ps-table', 'children'),
         Output('ps-renewables', 'figure'),
         Output('ps-nuclear', 'figure')],
        [Input('ps-country', 'value'),
         Input('ps-hour', 'value'),
         Input('ps-show-renewables', 'value'),
         Input('ps-refresh', 'n_clicks')],
    )
    def update(country, selected_hour, renewables_toggle, n_clicks):
        show_renewables = 'yes' in (renewables_toggle or [])
        triggered = callback_context.triggered_id
        if triggered == 'ps-refresh':
            clear_all()
            logger.info("Plant stack: manual refresh — cache cleared")

        t0 = _t.perf_counter()

        output_df = _fetch_prompt_output(country, hour_utc=selected_hour)
        nuke_clusters = _load_nuclear_cluster_map() if country == 'FR' else {}

        plants = _load_plants(country)

        nuke_fig = go.Figure()
        if country == 'FR':
            nuke_fig = _nuclear_tranche_chart(country)
        else:
            nuke_fig.update_layout(**styled_layout(
                f'{country} — Nuclear Tranche Bidding Prices (FR only)', 'EUR/MWh'))

        logger.info("Plant stack callback %s (hour=%s) done in %.1fs",
                     country, selected_hour or 'auto', _t.perf_counter() - t0)

        return (
            _merit_order(output_df, nuke_clusters, country,
                         show_renewables=show_renewables),
            _plant_table(plants),
            _renewable_subsidy_chart(plants, country),
            nuke_fig,
        )
