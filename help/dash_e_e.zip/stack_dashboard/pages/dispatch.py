"""
Page 2 — Dispatch by Technology (stacked area + fuel mix)

Supports scenario group / scenario selection.
For BASECASE, defaults to front 3 months; date picker to expand.
"""
import logging
from datetime import datetime, timedelta

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output, State, dash_table, callback_context, no_update
from sqlalchemy import text as sa_text

from utils.db import get_postgres, get_latest_run_time, get_scenarios_from_stats
from utils.cache import cached, clear_all
from utils.theme import styled_layout, TECHNO_COLORS, TABLE_STYLE_HEADER, TABLE_STYLE_CELL, TABLE_STYLE_DATA_CONDITIONAL

logger = logging.getLogger(__name__)

@cached
def _get_recent_run_times(country: str, n: int = 5) -> list:
    """Get the last N run_times that have dispatch data for BASECASE/BASELINE."""
    try:
        pg = get_postgres()
        q = sa_text("""
            SELECT DISTINCT run_time_utc
            FROM commod_research.power_stack_dispatch_by_techno
            WHERE country = :c AND scenario_group = 'BASECASE' AND scenario = 'BASELINE'
            ORDER BY run_time_utc DESC
            LIMIT :n
        """)
        with pg.engine.connect() as conn:
            rows = conn.execute(q, {'c': country, 'n': n}).fetchall()
        return [r[0] for r in rows]
    except Exception as exc:
        logger.error("Failed to get recent run_times for %s: %s", country, exc)
        return []


def _utc_to_cet(series):
    s = pd.to_datetime(series)
    if s.dt.tz is None:
        s = s.dt.tz_localize('UTC')
    return s.dt.tz_convert('Europe/Berlin').dt.tz_localize(None)


def _default_date_range():
    today = datetime.utcnow().date()
    return today, today + timedelta(days=90)


@cached
def _get_run_time(country: str, scenario_group: str):
    """Latest run_time from stats table (~1s, indexed)."""
    try:
        return get_latest_run_time(country, scenario_group)
    except Exception as exc:
        logger.warning("get_run_time %s %s: %s", country, scenario_group, exc)
        return None


@cached
def _fetch_dispatch_for_rt(country: str, run_time_str: str,
                           date_start: str, date_end: str) -> pd.DataFrame:
    """Fetch BASECASE/BASELINE dispatch for a specific run_time."""
    try:
        pg = get_postgres()
        q = sa_text("""
            SELECT start_time_utc, techno, stack_dispatch
            FROM commod_research.power_stack_dispatch_by_techno
            WHERE run_time_utc = CAST(:rt AS timestamptz)
              AND country = :c
              AND scenario_group = 'BASECASE' AND scenario = 'BASELINE'
              AND start_time_utc >= CAST(:dt_start AS timestamp)
              AND start_time_utc < CAST(:dt_end AS timestamp)
            ORDER BY start_time_utc, techno
        """)
        params = {'rt': run_time_str, 'c': country,
                  'dt_start': date_start, 'dt_end': date_end}
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params=params)
        if df.empty:
            logger.warning("Dispatch empty for %s rt=%s %s-%s", country, run_time_str, date_start, date_end)
            return df
        df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        return df.sort_values('start_time_cet')
    except Exception as exc:
        logger.error("Dispatch fetch %s rt=%s: %s", country, run_time_str, exc)
        return pd.DataFrame()


@cached
def _fetch_dispatch(country: str, scenario_group: str, scenario: str,
                    date_start: str, date_end: str) -> pd.DataFrame:
    try:
        rt = _get_run_time(country, scenario_group)
        if rt is None:
            return pd.DataFrame()
        pg = get_postgres()
        q = sa_text("""
            SELECT start_time_utc, techno, stack_dispatch
            FROM commod_research.power_stack_dispatch_by_techno
            WHERE run_time_utc = :rt AND country = :c
              AND scenario_group = :sg AND scenario = :sc
              AND start_time_utc >= CAST(:dt_start AS timestamp)
              AND start_time_utc < CAST(:dt_end AS timestamp)
            ORDER BY start_time_utc, techno
        """)
        params = {
            'rt': rt, 'c': country, 'sg': scenario_group, 'sc': scenario,
            'dt_start': date_start, 'dt_end': date_end,
        }
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params=params)
        if df.empty:
            return df
        df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        return df.sort_values('start_time_cet')
    except Exception as exc:
        logger.warning("Dispatch %s %s/%s: %s", country, scenario_group, scenario, exc)
        return pd.DataFrame()


@cached
def _fetch_dispatch_ensemble_mean(country: str, scenario_group: str,
                                  date_start: str, date_end: str) -> pd.DataFrame:
    """Fetch all ensemble members and return their mean dispatch per techno/hour."""
    try:
        rt = _get_run_time(country, scenario_group)
        logger.info("Ensemble dispatch %s %s: run_time=%s, dates=%s to %s",
                     country, scenario_group, rt, date_start, date_end)
        if rt is None:
            logger.error("Ensemble dispatch %s %s: run_time is None — aborting", country, scenario_group)
            return pd.DataFrame()
        pg = get_postgres()
        q = sa_text("""
            SELECT start_time_utc, techno,
                   AVG(stack_dispatch) AS stack_dispatch
            FROM commod_research.power_stack_dispatch_by_techno
            WHERE run_time_utc = :rt AND country = :c
              AND scenario_group = :sg
              AND start_time_utc >= CAST(:dt_start AS timestamp)
              AND start_time_utc < CAST(:dt_end AS timestamp)
            GROUP BY start_time_utc, techno
            ORDER BY start_time_utc, techno
        """)
        params = {
            'rt': rt, 'c': country, 'sg': scenario_group,
            'dt_start': date_start, 'dt_end': date_end,
        }
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params=params)
        logger.info("Ensemble dispatch %s %s: got %d rows", country, scenario_group, len(df))
        if df.empty:
            # Check what scenario_groups actually exist for this run_time
            with pg.engine.connect() as conn:
                check = pd.read_sql(sa_text("""
                    SELECT DISTINCT scenario_group, scenario, COUNT(*) as n
                    FROM commod_research.power_stack_dispatch_by_techno
                    WHERE run_time_utc = :rt AND country = :c
                    GROUP BY scenario_group, scenario
                    ORDER BY scenario_group, scenario
                """), conn, params={'rt': rt, 'c': country})
            logger.error("Ensemble dispatch empty! Available scenario_groups for rt=%s:\n%s",
                         rt, check.to_string())
            return df
        df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        return df.sort_values('start_time_cet')
    except Exception as exc:
        logger.error("Dispatch ensemble mean %s %s: %s", country, scenario_group, exc, exc_info=True)
        return pd.DataFrame()


@cached
def _fetch_available_scenarios(country: str, scenario_group: str) -> list:
    """Use stats table for scenario list (fast, indexed)."""
    try:
        return get_scenarios_from_stats(country, scenario_group)
    except Exception as exc:
        logger.warning("Fetch scenarios %s %s: %s", country, scenario_group, exc)
        return []


def _stacked_area(df: pd.DataFrame, country: str, title_suffix: str = '') -> go.Figure:
    fig = go.Figure()
    if df.empty:
        fig.update_layout(**styled_layout(f'{country} — Dispatch by Technology', 'MW'))
        return fig

    pivot = df.pivot_table(
        index='start_time_cet', columns='techno',
        values='stack_dispatch', aggfunc='sum',
    ).fillna(0)

    for tech in pivot.columns:
        color = TECHNO_COLORS.get(tech, '#868e96')
        fig.add_trace(go.Scatter(
            x=pivot.index, y=pivot[tech],
            name=tech, stackgroup='one',
            line=dict(width=0.5, color=color),
            fillcolor=color,
        ))

    title = f'{country} — Hourly Dispatch by Technology'
    if title_suffix:
        title += f' ({title_suffix})'
    fig.update_layout(**styled_layout(title, 'MW'))
    return fig


def _fuel_mix_bar(df: pd.DataFrame, country: str) -> go.Figure:
    fig = go.Figure()
    if df.empty:
        fig.update_layout(**styled_layout(f'{country} — Fuel Mix (avg MW)', 'MW'))
        return fig

    avg = df.groupby('techno')['stack_dispatch'].mean().sort_values(ascending=True)
    colors = [TECHNO_COLORS.get(t, '#868e96') for t in avg.index]

    fig.add_trace(go.Bar(
        x=avg.values, y=avg.index, orientation='h',
        marker_color=colors,
        text=[f'{v:,.0f}' for v in avg.values],
        textposition='auto',
    ))
    fig.update_layout(**styled_layout(f'{country} — Average Dispatch by Technology', 'MW'))
    fig.update_layout(yaxis=dict(title=''), height=400)
    return fig


def _capacity_factor_table(df: pd.DataFrame):
    if df.empty:
        return html.Div("No data", style={'color': '#8a8f9a'})

    summary = df.groupby('techno').agg(
        avg_dispatch=('stack_dispatch', 'mean'),
        max_dispatch=('stack_dispatch', 'max'),
        hours_nonzero=('stack_dispatch', lambda x: (x > 0).sum()),
        total_hours=('stack_dispatch', 'count'),
    ).reset_index()
    summary['capacity_factor_%'] = (
        (summary['hours_nonzero'] / summary['total_hours']) * 100
    ).round(1)
    summary['avg_dispatch'] = summary['avg_dispatch'].round(0)
    summary['max_dispatch'] = summary['max_dispatch'].round(0)
    summary = summary.sort_values('avg_dispatch', ascending=False)
    summary = summary.rename(columns={
        'techno': 'Technology',
        'avg_dispatch': 'Avg Dispatch (MW)',
        'max_dispatch': 'Max Dispatch (MW)',
        'capacity_factor_%': 'Running %',
    })
    cols_show = ['Technology', 'Avg Dispatch (MW)', 'Max Dispatch (MW)', 'Running %']
    return dash_table.DataTable(
        data=summary[cols_show].to_dict('records'),
        columns=[{'name': c, 'id': c} for c in cols_show],
        style_header=TABLE_STYLE_HEADER,
        style_cell=TABLE_STYLE_CELL,
        style_data_conditional=TABLE_STYLE_DATA_CONDITIONAL,
        sort_action='native',
    )


def layout():
    ds, de = _default_date_range()
    return dbc.Container([
        html.H4("Dispatch by Technology", className='text-center mb-1',
                 style={'color': '#e0e0e0'}),
        html.P("BASECASE / BASELINE — all times CET", className='text-center',
               style={'color': '#8a8f9a', 'fontSize': '0.8rem'}),

        dbc.Row([
            dbc.Col([
                html.Label("Country", className='control-label'),
                dcc.Dropdown(id='disp-country', options=[
                    {'label': 'Germany (DE)', 'value': 'DE'},
                    {'label': 'France (FR)', 'value': 'FR'},
                ], value='DE', clearable=False),
            ], width=2),
            dbc.Col([
                html.Label("Run Time", className='control-label'),
                dcc.Dropdown(id='disp-run-time', clearable=False),
            ], width=3),
            dbc.Col([
                html.Label("Date Range", className='control-label'),
                dcc.DatePickerRange(
                    id='disp-daterange',
                    start_date=ds.isoformat(),
                    end_date=de.isoformat(),
                    min_date_allowed='2025-01-01',
                    max_date_allowed='2030-12-31',
                    display_format='DD MMM YYYY',
                    style={'fontSize': '0.85rem'},
                ),
            ], width=5),
            dbc.Col([
                html.Br(),
                dbc.Button("\u27f3 Refresh Data", id='disp-refresh', color='secondary',
                           size='sm', className='mt-1'),
            ], width=2),
        ], className='mb-3'),

        dbc.Card(dbc.CardBody(dcc.Loading(dcc.Graph(id='disp-stacked'), type='circle')), className='mb-3'),

        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody(dcc.Loading(dcc.Graph(id='disp-bar'), type='circle'))), width=6),
            dbc.Col(dbc.Card(dbc.CardBody([
                html.H6("Technology Summary", style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
                html.Div(id='disp-table'),
            ])), width=6),
        ]),
    ], fluid=True)


def register_callbacks(app):

    @app.callback(
        [Output('disp-run-time', 'options'),
         Output('disp-run-time', 'value')],
        [Input('disp-country', 'value'),
         Input('disp-refresh', 'n_clicks')],
    )
    def populate_run_times(country, n_clicks):
        triggered = callback_context.triggered_id
        if triggered == 'disp-refresh':
            clear_all()
            logger.info("Dispatch: manual refresh — cache cleared")

        rts = _get_recent_run_times(country, n=5)
        if not rts:
            return [], None
        opts = []
        for rt in rts:
            cet = pd.Timestamp(rt).tz_convert('Europe/Berlin') if rt.tzinfo else pd.Timestamp(rt, tz='UTC').tz_convert('Europe/Berlin')
            label = cet.strftime('%d %b %Y %H:%M CET')
            opts.append({'label': label, 'value': str(rt)})
        return opts, opts[0]['value']

    @app.callback(
        [Output('disp-stacked', 'figure'),
         Output('disp-bar', 'figure'),
         Output('disp-table', 'children')],
        [Input('disp-country', 'value'),
         Input('disp-run-time', 'value'),
         Input('disp-daterange', 'start_date'),
         Input('disp-daterange', 'end_date')],
    )
    def update(country, run_time_str, date_start, date_end):
        empty = (
            go.Figure().update_layout(**styled_layout(f'{country} — Dispatch', 'MW')),
            go.Figure().update_layout(**styled_layout(f'{country} — Fuel Mix', 'MW')),
            html.Div("No data", style={'color': '#8a8f9a'}),
        )
        if not date_start or not date_end or not run_time_str:
            return empty

        try:
            logger.info("Dispatch update: %s rt=%s %s-%s", country, run_time_str, date_start, date_end)
            df = _fetch_dispatch_for_rt(country, run_time_str, date_start, date_end)
            rt_label = pd.Timestamp(run_time_str).strftime('%d %b %H:%M')
            title_suffix = f'run {rt_label}'
            logger.info("Dispatch result: %d rows", len(df))
        except Exception as exc:
            logger.error("Dispatch callback error: %s", exc, exc_info=True)
            df = pd.DataFrame()
            title_suffix = ''

        return (
            _stacked_area(df, country, title_suffix),
            _fuel_mix_bar(df, country),
            _capacity_factor_table(df),
        )
