"""
Generation Benchmark Page
=========================
Compares the stack model's BASECASE/BASELINE dispatch per fuel type against
actual generation from EnergyQuantified for a user-selected delivery date.

The stack run used is the D-1 run closest to 11:00 UTC (same convention as
the price benchmark).  virtual_thermal is merged into gas.
"""

import logging
from datetime import datetime, timedelta, date, time as dt_time

import dash
import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import html, dcc, Input, Output, State
from sqlalchemy import text as sa_text

from utils.db import get_postgres
from utils.cache import cached, clear_all
from utils.theme import DARK_LAYOUT

logger = logging.getLogger(__name__)

_COUNTRIES = ['DE', 'FR']
_TARGET_HOUR_UTC = 11

# ---------------------------------------------------------------------------
# EQ actual generation curves per country/fuel
# ---------------------------------------------------------------------------

_GEN_ACTUAL_CURVES = {
    'DE': {
        'gas': 'DE Natural Gas Power Production MWh/h 15min Actual',
        'coal': 'DE Hard Coal Power Production MWh/h 15min Actual',
        'lignite': 'DE Lignite Power Production MWh/h 15min Actual',
        'nuclear': 'DE Nuclear Production MWh/h 15min Actual',
        'wind': 'DE Wind Power Production MWh/h 15min Actual',
        'solar': 'DE Solar Photovoltaic Production MWh/h 15min Actual',
        'biomass': 'DE Biomass Power Production MWh/h 15min Actual',
        'hydro_ror': 'DE Hydro Run-of-river Production MWh/h 15min Actual',
        'hydro_pumped': 'DE Hydro Pumped-storage Production MWh/h 15min Actual',
    },
    'FR': {
        'gas': 'FR Natural Gas Power Production MWh/h 30min Actual',
        'coal': 'FR Hard Coal Power Production MWh/h 30min Actual',
        'nuclear': 'FR Nuclear Production MWh/h 30min Actual',
        'wind': 'FR Wind Power Production MWh/h 30min Actual',
        'solar': 'FR Solar Photovoltaic Production MWh/h 30min Actual',
        'biomass': 'FR Biomass Power Production MWh/h 30min Actual',
        'oil': 'FR Oil Power Production MWh/h 30min Actual',
        'hydro_ror': 'FR Hydro Run-of-river Production MWh/h 30min Actual',
        'hydro_reservoir': 'FR Hydro Reservoir Production MWh/h 30min Actual',
        'hydro_pumped': 'FR Hydro Pumped-storage Production MWh/h 30min Actual',
    },
}

_STACK_TO_EQ_FUEL = {
    'gas': 'gas',
    'virtual_thermal': 'gas',
    'coal': 'coal',
    'lignite': 'lignite',
    'nuclear': 'nuclear',
    'wind': 'wind',
    'solar': 'solar',
    'biomass': 'biomass',
    'oil': 'oil',
    'run_of_river': 'hydro_ror',
    'reservoirs_and_pumped_storage': 'hydro_pumped',
}

_FUEL_COLORS = {
    'gas': '#ff6b6b',
    'coal': '#868e96',
    'lignite': '#6b5b4c',
    'nuclear': '#ffa94d',
    'wind': '#74c0fc',
    'solar': '#ffd43b',
    'biomass': '#51cf66',
    'oil': '#e8590c',
    'hydro_ror': '#4dabf7',
    'hydro_pumped': '#339af0',
    'hydro_reservoir': '#1c7ed6',
}

# ---------------------------------------------------------------------------
# EQ client singleton
# ---------------------------------------------------------------------------

_eq_client = None


def _get_eq():
    global _eq_client
    if _eq_client is None:
        from jain_commods.core.cache.utils.eq import EQ_API_KEY
        from jain_commods.core.interfaces.energyquantified.client import EQClient
        _eq_client = EQClient(api_key=EQ_API_KEY, timeout=60.0)
    return _eq_client


# ---------------------------------------------------------------------------
# Pick the D-1 run closest to 11h UTC
# ---------------------------------------------------------------------------

def _forecast_run_date(delivery_date: date) -> date:
    dow = delivery_date.isoweekday()
    if dow == 6:
        return delivery_date - timedelta(days=1)
    elif dow == 7:
        return delivery_date - timedelta(days=2)
    elif dow == 1:
        return delivery_date - timedelta(days=3)
    else:
        return delivery_date - timedelta(days=1)


def _pick_run(delivery_date: date, run_times: list) -> datetime | None:
    run_date = _forecast_run_date(delivery_date)
    target = datetime.combine(run_date, dt_time(_TARGET_HOUR_UTC, 0))
    best, best_diff = None, None
    for rt in run_times:
        rt_naive = rt.replace(tzinfo=None) if hasattr(rt, 'tzinfo') and rt.tzinfo else rt
        if rt_naive.date() != run_date:
            continue
        diff = abs((rt_naive - target).total_seconds())
        if best_diff is None or diff < best_diff:
            best, best_diff = rt, diff
    return best


# ---------------------------------------------------------------------------
# Stack dispatch data
# ---------------------------------------------------------------------------

@cached
def _fetch_dispatch_runs(country: str, since: date) -> list:
    pg = get_postgres()
    q = sa_text("""
        SELECT DISTINCT run_time_utc
        FROM commod_research.power_stack_dispatch_by_techno
        WHERE country = :c AND scenario_group = 'BASECASE' AND scenario = 'BASELINE'
          AND run_time_utc >= :since
        ORDER BY run_time_utc
    """)
    with pg.engine.connect() as conn:
        return [r[0] for r in conn.execute(q, {
            'c': country,
            'since': datetime.combine(since, dt_time(0, 0)),
        }).fetchall()]


@cached
def _fetch_stack_dispatch(country: str, run_time, delivery: date) -> pd.DataFrame:
    pg = get_postgres()
    d0 = datetime.combine(delivery, dt_time(0, 0))
    d1 = d0 + timedelta(days=1)
    q = sa_text("""
        SELECT start_time_utc, techno, stack_dispatch
        FROM commod_research.power_stack_dispatch_by_techno
        WHERE run_time_utc = :rt AND country = :c
          AND scenario_group = 'BASECASE' AND scenario = 'BASELINE'
          AND start_time_utc >= :d0 AND start_time_utc < :d1
        ORDER BY start_time_utc, techno
    """)
    with pg.engine.connect() as conn:
        df = pd.read_sql(q, conn, params={'rt': run_time, 'c': country, 'd0': d0, 'd1': d1})
    if df.empty:
        return df
    df['utc'] = pd.to_datetime(df['start_time_utc'])
    if df['utc'].dt.tz is not None:
        df['utc'] = df['utc'].dt.tz_localize(None)
    df['fuel'] = df['techno'].map(_STACK_TO_EQ_FUEL)
    df = df.dropna(subset=['fuel'])
    return df.groupby(['utc', 'fuel'])['stack_dispatch'].sum().reset_index()


# ---------------------------------------------------------------------------
# EQ actual generation
# ---------------------------------------------------------------------------

@cached
def _fetch_eq_actual(country: str, fuel: str, begin: date, end: date) -> pd.DataFrame:
    curves = _GEN_ACTUAL_CURVES.get(country, {})
    curve = curves.get(fuel)
    if not curve:
        return pd.DataFrame()
    try:
        df = _get_eq().get_actuals(curve, begin=begin, end=end, frequency='PT1H')
        if df is None or df.empty:
            return pd.DataFrame()
        idx = pd.DatetimeIndex(df.index)
        if idx.tz is not None:
            idx = idx.tz_convert('UTC').tz_localize(None)
        return pd.DataFrame({'actual': df.iloc[:, 0].values}, index=idx)
    except Exception as exc:
        logger.error("EQ gen actual %s/%s: %s", country, fuel, exc)
        return pd.DataFrame()


# ---------------------------------------------------------------------------
# Build benchmark for a given delivery date
# ---------------------------------------------------------------------------

def _build(country: str, delivery: date) -> tuple:
    """Returns (stack_wide, actuals_dict, run_time_used)."""
    rts = _fetch_dispatch_runs(country, delivery - timedelta(days=5))
    rt = _pick_run(delivery, rts)
    if rt is None:
        logger.warning("Gen bench %s: no run for %s", country, delivery)
        return pd.DataFrame(), {}, None

    dispatch = _fetch_stack_dispatch(country, rt, delivery)
    if dispatch.empty:
        return pd.DataFrame(), {}, rt

    fuels = sorted(dispatch['fuel'].unique())
    actuals = {}
    for fuel in fuels:
        adf = _fetch_eq_actual(country, fuel, delivery, delivery + timedelta(days=1))
        if not adf.empty:
            actuals[fuel] = adf

    stack_wide = dispatch.pivot(index='utc', columns='fuel',
                                values='stack_dispatch').fillna(0)
    return stack_wide, actuals, rt


# ---------------------------------------------------------------------------
# Charts
# ---------------------------------------------------------------------------

_LAYOUT_SKIP = {'height', 'margin', 'yaxis', 'xaxis', 'legend'}


def _base_layout() -> dict:
    return {k: v for k, v in DARK_LAYOUT.items() if k not in _LAYOUT_SKIP}


def _make_bar_chart(country: str, stack_wide: pd.DataFrame,
                    delivery: date, actuals: dict) -> go.Figure:
    if stack_wide.empty:
        fig = go.Figure()
        fig.add_annotation(text=f"No dispatch data for {country} on {delivery}",
                           xref="paper", yref="paper", x=0.5, y=0.5,
                           showarrow=False, font=dict(size=18, color='#e0e0e0'))
        fig.update_layout(**DARK_LAYOUT)
        return fig

    fuels = sorted(set(stack_wide.columns) | set(actuals.keys()))
    stack_avgs, actual_avgs, labels = [], [], []

    for fuel in fuels:
        stack_avgs.append(stack_wide[fuel].mean() if fuel in stack_wide.columns else 0)
        actual_avgs.append(actuals[fuel]['actual'].mean() if fuel in actuals else np.nan)
        labels.append(fuel.replace('_', ' ').title())

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=labels, y=stack_avgs, name='Stack Forecast',
        marker_color=[_FUEL_COLORS.get(f, '#868e96') for f in fuels],
        marker_line=dict(width=1, color='#1a1a2e'),
        opacity=0.85,
    ))
    fig.add_trace(go.Bar(
        x=labels, y=actual_avgs, name='EQ Actual',
        marker_color=[_FUEL_COLORS.get(f, '#868e96') for f in fuels],
        marker_line=dict(width=2, color='#e0e0e0'),
        marker_pattern_shape='/',
        opacity=0.65,
    ))

    fig.update_layout(
        **_base_layout(),
        barmode='group', height=420,
        margin=dict(l=50, r=20, t=80, b=40),
        title=dict(
            text=(f"{country} — Generation: Stack vs Actual ({delivery})"
                  f"<br><sup>Daily average MW · BASECASE/BASELINE</sup>"),
            font=dict(size=15, color='#e0e0e0'), x=0.5),
        yaxis=dict(title='Average MW', gridcolor='rgba(255,255,255,0.06)'),
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='center', x=0.5,
                    bgcolor='rgba(34,38,46,0.95)', font=dict(color='#e0e0e0', size=11)),
    )
    return fig


def _make_hourly_chart(country: str, stack_wide: pd.DataFrame,
                       delivery: date, actuals: dict) -> go.Figure:
    if stack_wide.empty:
        fig = go.Figure()
        fig.update_layout(**DARK_LAYOUT)
        return fig

    fig = go.Figure()
    fuels = sorted(set(stack_wide.columns) | set(actuals.keys()))

    for fuel in fuels:
        color = _FUEL_COLORS.get(fuel, '#868e96')
        label = fuel.replace('_', ' ').title()
        if fuel in stack_wide.columns:
            fig.add_trace(go.Scatter(
                x=stack_wide.index, y=stack_wide[fuel],
                name=f'{label} (stack)', line=dict(color=color, width=2),
                legendgroup=fuel,
            ))
        if fuel in actuals:
            adf = actuals[fuel]
            fig.add_trace(go.Scatter(
                x=adf.index, y=adf['actual'],
                name=f'{label} (actual)', line=dict(color=color, width=2, dash='dash'),
                legendgroup=fuel,
            ))

    fig.update_layout(
        **_base_layout(),
        height=500,
        margin=dict(l=50, r=20, t=80, b=40),
        title=dict(
            text=f"{country} — Hourly Generation: Stack vs Actual ({delivery})",
            font=dict(size=15, color='#e0e0e0'), x=0.5),
        yaxis=dict(title='MW', gridcolor='rgba(255,255,255,0.06)'),
        xaxis=dict(gridcolor='rgba(255,255,255,0.06)'),
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='center', x=0.5,
                    bgcolor='rgba(34,38,46,0.95)', font=dict(color='#e0e0e0', size=11)),
    )
    return fig


def _make_diff_table(stack_wide: pd.DataFrame, actuals: dict) -> list:
    if stack_wide.empty:
        return [html.Div("No data", style={'color': '#8a8f9a'})]

    fuels = sorted(set(stack_wide.columns) | set(actuals.keys()))
    rows = []
    total_stack, total_actual = 0.0, 0.0
    for fuel in fuels:
        s = stack_wide[fuel].mean() if fuel in stack_wide.columns else 0
        a = actuals[fuel]['actual'].mean() if fuel in actuals else None
        diff = (s - a) if a is not None else None
        pct = (diff / a * 100) if a and a != 0 else None
        total_stack += s
        if a is not None:
            total_actual += a
        rows.append({
            'Fuel': fuel.replace('_', ' ').title(),
            'Stack (MW)': f'{s:,.0f}',
            'Actual (MW)': f'{a:,.0f}' if a is not None else '—',
            'Diff (MW)': f'{diff:+,.0f}' if diff is not None else '—',
            'Diff (%)': f'{pct:+.1f}%' if pct is not None else '—',
        })
    rows.append({
        'Fuel': 'TOTAL',
        'Stack (MW)': f'{total_stack:,.0f}',
        'Actual (MW)': f'{total_actual:,.0f}' if total_actual else '—',
        'Diff (MW)': f'{total_stack - total_actual:+,.0f}' if total_actual else '—',
        'Diff (%)': (f'{(total_stack - total_actual) / total_actual * 100:+.1f}%'
                     if total_actual else '—'),
    })
    return [
        dbc.Table.from_dataframe(
            pd.DataFrame(rows), striped=True, bordered=True, hover=True,
            dark=True, size='sm', className='mt-2',
        ),
    ]


# ---------------------------------------------------------------------------
# Layout & callbacks
# ---------------------------------------------------------------------------

def layout():
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    return html.Div([
        dbc.Container([
            dbc.Row([
                dbc.Col(html.H4("Generation Benchmark",
                                 style={"color": "#e0e0e0"}), width="auto"),
                dbc.Col([
                    dcc.DatePickerSingle(
                        id='gb-date',
                        date=yesterday,
                        display_format='YYYY-MM-DD',
                        style={'backgroundColor': '#1a1a2e'},
                    ),
                ], width="auto"),
                dbc.Col([
                    dbc.RadioItems(
                        id='gb-country',
                        options=[{'label': c, 'value': c} for c in _COUNTRIES],
                        value='DE',
                        inline=True,
                        className='text-light',
                    ),
                ], width="auto"),
                dbc.Col(dbc.Button("Refresh", id="gb-refresh",
                                   color="primary", size="sm"), width="auto"),
                dbc.Col(html.Span(id="gb-status", style={"color": "#adb5bd"}),
                        width="auto"),
            ], className="mt-3 mb-3 align-items-center g-3"),
            dcc.Loading(html.Div(id="gb-content"), type="circle"),
        ], fluid=True),
    ])


def register_callbacks(app):
    @app.callback(
        [Output("gb-content", "children"),
         Output("gb-status", "children")],
        [Input("gb-country", "value"),
         Input("gb-date", "date"),
         Input("gb-refresh", "n_clicks")],
    )
    def update(country, sel_date, n_clicks):
        ctx = dash.callback_context
        triggered = ctx.triggered[0]['prop_id'] if ctx.triggered else ''

        if 'gb-refresh' in triggered:
            clear_all()
            status = f"Refreshed {datetime.now().strftime('%H:%M:%S')}"
        else:
            status = ""

        try:
            delivery = date.fromisoformat(sel_date) if sel_date else date.today() - timedelta(days=1)
            stack_wide, actuals, rt = _build(country, delivery)

            run_info = ""
            if rt is not None:
                rt_str = rt.replace(tzinfo=None).strftime('%Y-%m-%d %H:%M UTC') \
                    if hasattr(rt, 'tzinfo') and rt.tzinfo else str(rt)
                run_info = f"Stack run: {rt_str}"

            bar_fig = _make_bar_chart(country, stack_wide, delivery, actuals)
            hourly_fig = _make_hourly_chart(country, stack_wide, delivery, actuals)
            diff_table = _make_diff_table(stack_wide, actuals)

            content = html.Div([
                html.Div(run_info, className='mb-2',
                         style={'color': '#adb5bd', 'fontSize': '0.9rem'}),
                dbc.Row([
                    dbc.Col(dcc.Graph(figure=bar_fig), lg=6),
                    dbc.Col(diff_table, lg=6),
                ]),
                dcc.Graph(figure=hourly_fig),
            ])
        except Exception as exc:
            logger.error("Gen benchmark %s %s: %s", country, sel_date, exc, exc_info=True)
            content = dbc.Alert(f"Error: {exc}", color="danger")

        return content, status
