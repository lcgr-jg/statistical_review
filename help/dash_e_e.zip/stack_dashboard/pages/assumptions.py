"""
Page 4 — Input Assumptions: gas forward curve, hydro, net exports, seasonal norms.

All queries filter to the latest run_time_utc and future dates.
Scenario selector for hydro / net exports / seasonal norms.
"""
import logging
import pandas as pd
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output, callback_context
from sqlalchemy import text as sa_text

from utils.db import get_postgres
from utils.cache import cached, clear_all
from utils.theme import styled_layout, COLORS

logger = logging.getLogger(__name__)

SCENARIO_OPTIONS = [
    {'label': 'Baseline', 'value': 'baseline'},
    {'label': 'P10', 'value': 'p10'},
    {'label': 'P90', 'value': 'p90'},
]

# Techno colours + renewables set — kept in sync with plant_stack.py
_TECHNO_COLOR_MAP = {
    'nuclear': '#ffa94d',
    'gas': '#ff6b6b',
    'coal': '#868e96',
    'lignite': '#6b5b4c',
    'oil': '#e8590c',
    'biomass': '#51cf66',
    'wind': '#74c0fc',
    'solar': '#ffd43b',
    'virtual_thermal': '#cc5de8',
    'run_of_river': '#4dabf7',
    'reservoirs_and_pumped_storage': '#339af0',
    'import': '#adb5bd',
}

# Renewables are excluded from the forward-availability view.
_RENEWABLE_TECHNOS = {
    'wind', 'solar', 'run_of_river', 'reservoirs_and_pumped_storage', 'biomass',
}

# Draw order: baseload at the bottom of the stack, peakers on top.
_TECHNO_STACK_ORDER = [
    'nuclear', 'lignite', 'coal', 'gas', 'oil', 'virtual_thermal',
]


def _utc_to_cet(series):
    s = pd.to_datetime(series)
    if s.dt.tz is None:
        s = s.dt.tz_localize('UTC')
    return s.dt.tz_convert('Europe/Berlin').dt.tz_localize(None)


def _pg():
    return get_postgres()


@cached
def _fetch_gas_curve() -> pd.DataFrame:
    try:
        q = sa_text("""
            SELECT date, value, geography1
            FROM commod_research.daily_forward_gas_curve
            WHERE run_time_utc = (
                SELECT MAX(run_time_utc) FROM commod_research.daily_forward_gas_curve
            ) AND date >= CURRENT_DATE
            ORDER BY geography1, date
        """)
        with _pg().engine.connect() as conn:
            return pd.read_sql(q, conn)
    except Exception as exc:
        logger.warning("Gas curve: %s", exc)
        return pd.DataFrame()


@cached
def _fetch_hydro(country: str, scenario: str) -> pd.DataFrame:
    try:
        q = sa_text("""
            SELECT start_time_utc, value, type
            FROM commod_research.power_hydro_generation_forecasts
            WHERE run_time_utc = (
                SELECT MAX(run_time_utc) FROM commod_research.power_hydro_generation_forecasts
                WHERE geography1 = :c
            )
            AND geography1 = :c AND scenario = :s
            AND start_time_utc >= NOW()
            ORDER BY type, start_time_utc
        """)
        with _pg().engine.connect() as conn:
            df = pd.read_sql(q, conn, params={'c': country, 's': scenario})
        if df.empty:
            return df
        df['ts'] = _utc_to_cet(df['start_time_utc'])
        return df
    except Exception as exc:
        logger.warning("Hydro %s: %s", country, exc)
        return pd.DataFrame()


@cached
def _fetch_net_exports(country: str, scenario: str) -> pd.DataFrame:
    try:
        q = sa_text("""
            SELECT start_time_utc, value
            FROM commod_research.power_net_exports_forecasts
            WHERE run_time_utc = (
                SELECT MAX(run_time_utc) FROM commod_research.power_net_exports_forecasts
                WHERE geography1 = :c
            )
            AND geography1 = :c AND scenario = :s
            AND start_time_utc >= NOW()
            ORDER BY start_time_utc
        """)
        with _pg().engine.connect() as conn:
            df = pd.read_sql(q, conn, params={'c': country, 's': scenario})
        if df.empty:
            return df
        df['ts'] = _utc_to_cet(df['start_time_utc'])
        return df
    except Exception as exc:
        logger.warning("Net exports %s: %s", country, exc)
        return pd.DataFrame()


@cached
def _fetch_seasonal(table: str, country: str, scenario: str) -> pd.DataFrame:
    try:
        q = sa_text(f"""
            SELECT start_time_utc, value, category2
            FROM commod_research.{table}
            WHERE run_time_utc = (
                SELECT MAX(run_time_utc) FROM commod_research.{table}
                WHERE geography1 = :c
            )
            AND geography1 = :c AND scenario = :s
            AND start_time_utc >= NOW()
            ORDER BY category2, start_time_utc
        """)
        with _pg().engine.connect() as conn:
            df = pd.read_sql(q, conn, params={'c': country, 's': scenario})
        if df.empty:
            return df
        df['ts'] = _utc_to_cet(df['start_time_utc'])
        return df
    except Exception as exc:
        logger.warning("Seasonal %s %s: %s", table, country, exc)
        return pd.DataFrame()


@cached
def _fetch_forward_availability(country: str) -> pd.DataFrame:
    """Forward availability per technology from the stack run's prompt output.

    Sums ``availability`` across all units per ``techno`` × ``start_time_utc``
    for the latest run of ``power_stack_prompt_output`` (BASECASE / BASELINE).
    Renewable technos and imports are filtered out. Horizon matches the stack
    run (i.e. the ENS-medium window).
    """
    try:
        q = sa_text("""
            SELECT start_time_utc,
                   techno,
                   SUM(availability) AS availability_mw
            FROM commod_research.power_stack_prompt_output
            WHERE run_time_utc = (
                SELECT MAX(run_time_utc)
                FROM commod_research.power_stack_prompt_output
                WHERE country = :c
                  AND scenario_group = 'BASECASE'
                  AND scenario = 'BASELINE'
            )
            AND country = :c
            AND scenario_group = 'BASECASE'
            AND scenario = 'BASELINE'
            AND techno NOT IN (
                'wind', 'solar', 'run_of_river',
                'reservoirs_and_pumped_storage', 'biomass', 'import'
            )
            GROUP BY start_time_utc, techno
            ORDER BY start_time_utc, techno
        """)
        with _pg().engine.connect() as conn:
            df = pd.read_sql(q, conn, params={'c': country})
        if df.empty:
            return df
        df['ts'] = _utc_to_cet(df['start_time_utc'])
        df['availability_mw'] = pd.to_numeric(
            df['availability_mw'], errors='coerce'
        ).fillna(0)
        return df
    except Exception as exc:
        logger.warning("Forward availability %s: %s", country, exc)
        return pd.DataFrame()


# ── Figure builders ───────────────────────────────────────────────────────

def _gas_figure(df: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    if df.empty:
        fig.update_layout(**styled_layout('Forward Gas Curve', 'EUR/MWh'))
        return fig

    hub_colors = {'TTF': '#4dabf7', 'PEG': '#ffa94d', 'THE': '#51cf66'}
    for hub in df['geography1'].unique():
        sub = df[df['geography1'] == hub]
        fig.add_trace(go.Scatter(
            x=pd.to_datetime(sub['date']), y=sub['value'],
            name=hub, line=dict(color=hub_colors.get(hub, '#868e96'), width=2),
        ))
    fig.update_layout(**styled_layout('Forward Gas Curve (latest run, future)', 'EUR/MWh'))
    return fig


def _hydro_figure(df: pd.DataFrame, country: str, scenario: str) -> go.Figure:
    fig = go.Figure()
    if df.empty:
        fig.update_layout(**styled_layout(f'{country} — Hydro Forecast', 'MWh'))
        return fig

    hydro_colors = {'run_of_river': '#4dabf7', 'reservoirs_pumped_storage': '#1971c2'}
    for htype in df['type'].unique():
        sub = df[df['type'] == htype]
        fig.add_trace(go.Scatter(
            x=sub['ts'], y=sub['value'],
            name=str(htype).replace('_', ' ').title(),
            line=dict(color=hydro_colors.get(htype, '#868e96'), width=1.5),
        ))
    fig.update_layout(**styled_layout(f'{country} — Hydro Forecast ({scenario})', 'MWh'))
    return fig


def _net_exports_figure(df: pd.DataFrame, country: str, scenario: str) -> go.Figure:
    fig = go.Figure()
    if df.empty:
        fig.update_layout(**styled_layout(f'{country} — Net Exports', 'MWh'))
        return fig

    fig.add_trace(go.Scatter(
        x=df['ts'], y=df['value'],
        name='Net Exports', line=dict(color='#ffa94d', width=2),
        fill='tozeroy', fillcolor='rgba(255,169,77,0.15)',
    ))
    fig.add_hline(y=0, line_dash='dash', line_color='rgba(255,255,255,0.3)')
    fig.update_layout(**styled_layout(f'{country} — Net Exports Forecast ({scenario})', 'MWh'))
    return fig


def _seasonal_figure(ren_df: pd.DataFrame, load_df: pd.DataFrame,
                     country: str, scenario: str) -> go.Figure:
    fig = go.Figure()

    cat_colors = {'SOLAR': '#ffd43b', 'WIND': '#74c0fc', 'Load': '#51cf66'}

    if not ren_df.empty:
        for cat in ren_df['category2'].unique():
            sub = ren_df[ren_df['category2'] == cat]
            fig.add_trace(go.Scatter(
                x=sub['ts'], y=sub['value'],
                name=str(cat).title(),
                line=dict(color=cat_colors.get(cat, '#868e96'), width=1.5),
            ))

    if not load_df.empty:
        fig.add_trace(go.Scatter(
            x=load_df['ts'], y=load_df['value'],
            name='Load',
            line=dict(color=cat_colors['Load'], width=1.5, dash='dash'),
        ))

    fig.update_layout(**styled_layout(
        f'{country} — Seasonal Norms ({scenario})', 'MWh'))
    return fig


def _forward_availability_figure(df: pd.DataFrame, country: str) -> go.Figure:
    """Stacked area chart of forward availability (MW) by technology."""
    fig = go.Figure()
    if df.empty:
        fig.update_layout(**styled_layout(
            f'{country} — Forward Availability by Technology (ex. renewables)', 'MW'))
        return fig

    wide = (df.pivot_table(index='ts', columns='techno',
                           values='availability_mw', aggfunc='sum')
              .sort_index()
              .fillna(0))

    ordered = [t for t in _TECHNO_STACK_ORDER if t in wide.columns]
    extras = [c for c in wide.columns if c not in ordered]
    columns = ordered + sorted(extras)

    for techno in columns:
        color = _TECHNO_COLOR_MAP.get(techno, '#868e96')
        fig.add_trace(go.Scatter(
            x=wide.index,
            y=wide[techno],
            name=techno.replace('_', ' ').title(),
            mode='lines',
            line=dict(width=0.5, color=color),
            stackgroup='avail',
            fillcolor=color,
            hovertemplate=(f'<b>{techno}</b><br>'
                           '%{x|%Y-%m-%d %H:%M}<br>'
                           '%{y:,.0f} MW<extra></extra>'),
        ))

    fig.update_layout(**styled_layout(
        f'{country} — Forward Availability by Technology (ex. renewables)', 'MW'))
    fig.update_layout(hovermode='x unified')
    return fig


# ── Layout ────────────────────────────────────────────────────────────────

def layout():
    return dbc.Container([
        html.H4("Input Assumptions", className='text-center mb-1',
                 style={'color': '#e0e0e0'}),
        html.P("Latest run, future dates only. All times CET.",
               className='text-center', style={'color': '#8a8f9a', 'fontSize': '0.8rem'}),

        dbc.Row([
            dbc.Col([
                html.Label("Country", className='control-label'),
                dcc.Dropdown(id='asm-country', options=[
                    {'label': 'Germany (DE)', 'value': 'DE'},
                    {'label': 'France (FR)', 'value': 'FR'},
                ], value='DE', clearable=False),
            ], width=3),
            dbc.Col([
                html.Label("Scenario", className='control-label'),
                dcc.Dropdown(id='asm-scenario', options=SCENARIO_OPTIONS,
                             value='baseline', clearable=False),
            ], width=3),
            dbc.Col([
                html.Br(),
                dbc.Button("\u27f3 Refresh Data", id='asm-refresh', color='secondary',
                           size='sm', className='mt-1'),
            ], width=2),
        ], className='mb-3'),

        dbc.Card(dbc.CardBody(dcc.Loading(dcc.Graph(id='asm-gas'), type='circle')),
                 className='mb-3'),

        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody(
                dcc.Loading(dcc.Graph(id='asm-hydro'), type='circle'))), width=6),
            dbc.Col(dbc.Card(dbc.CardBody(
                dcc.Loading(dcc.Graph(id='asm-netex'), type='circle'))), width=6),
        ], className='mb-3'),

        dbc.Card(dbc.CardBody(dcc.Loading(dcc.Graph(id='asm-seasonal'), type='circle')),
                 className='mb-3'),

        dbc.Card(dbc.CardBody(
            dcc.Loading(dcc.Graph(id='asm-fwd-availability'), type='circle')),
            className='mb-3'),
    ], fluid=True)


def register_callbacks(app):

    @app.callback(
        [Output('asm-gas', 'figure'),
         Output('asm-hydro', 'figure'),
         Output('asm-netex', 'figure'),
         Output('asm-seasonal', 'figure'),
         Output('asm-fwd-availability', 'figure')],
        [Input('asm-country', 'value'),
         Input('asm-scenario', 'value'),
         Input('asm-refresh', 'n_clicks')],
    )
    def update(country, scenario, n_clicks):
        triggered = callback_context.triggered_id
        if triggered == 'asm-refresh':
            clear_all()
            logger.info("Assumptions: manual refresh — cache cleared")

        try:
            gas = _fetch_gas_curve()
        except Exception as exc:
            logger.error("Assumptions gas error: %s", exc)
            gas = pd.DataFrame()

        try:
            hydro = _fetch_hydro(country, scenario)
        except Exception as exc:
            logger.error("Assumptions hydro error: %s", exc)
            hydro = pd.DataFrame()

        try:
            netex = _fetch_net_exports(country, scenario)
        except Exception as exc:
            logger.error("Assumptions netex error: %s", exc)
            netex = pd.DataFrame()

        try:
            ren = _fetch_seasonal('power_renewables_inhouse_seasonal_norms', country, scenario)
            load = _fetch_seasonal('power_load_inhouse_seasonal_norms', country, scenario)
        except Exception as exc:
            logger.error("Assumptions seasonal error: %s", exc)
            ren = load = pd.DataFrame()

        try:
            fwd_avail = _fetch_forward_availability(country)
        except Exception as exc:
            logger.error("Assumptions forward availability error: %s", exc)
            fwd_avail = pd.DataFrame()

        return (
            _gas_figure(gas),
            _hydro_figure(hydro, country, scenario),
            _net_exports_figure(netex, country, scenario),
            _seasonal_figure(ren, load, country, scenario),
            _forward_availability_figure(fwd_avail, country),
        )
