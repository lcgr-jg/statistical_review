"""
Power Stack Run Comparison Dashboard

A Dash application for comparing power stack price runs with support for
both ensemble (ENS_MEDIUM, ENS_EXTENDED) and deterministic (BASECASE, DETERMINISTIC)
scenario groups across multiple time aggregations.
"""

import dash
from dash import dcc, html, Input, Output, State, dash_table
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Optional, Tuple, List, Dict
import logging

from utils.db import get_stack_query
from utils.cache import cached, clear_all

logger = logging.getLogger(__name__)

stack_query = None

def _ensure_db():
    global stack_query
    if stack_query is None:
        try:
            stack_query = get_stack_query()
        except Exception as e:
            logger.error(f"Failed to initialize database connection: {e}")

MAX_CACHE_SIZE = 50
data_cache = {}

DEFAULT_COUNTRIES = ['DE', 'FR']


# ============================================================================
# DATA LAYER FUNCTIONS
# ============================================================================

@cached
def get_available_countries() -> List[str]:
    """Get list of available countries (cached until manual refresh)."""
    _ensure_db()
    if stack_query is None:
        return DEFAULT_COUNTRIES
    
    try:
        df = stack_query.get_available_run_times(limit=1)
        if df is not None and not df.empty:
            prices = stack_query.get_prices(n_recent_runs=1)
            if prices is not None and not prices.empty:
                return sorted(prices['country'].unique().tolist())
        return DEFAULT_COUNTRIES
    except Exception as e:
        logger.error(f"Error getting countries: {e}")
        return DEFAULT_COUNTRIES


@cached
def get_available_run_times(limit: int = 20) -> List[Dict]:
    """Get available run times as dropdown options (cached until manual refresh)."""
    _ensure_db()
    if stack_query is None:
        return []
    
    try:
        df = stack_query.get_available_run_times(limit=limit)
        if df is not None and not df.empty:
            options = []
            for idx, run_time in enumerate(df['run_time_utc']):
                label = f"{run_time.strftime('%Y-%m-%d %H:%M:%S UTC')}"
                if idx == 0:
                    label += " (Latest)"
                options.append({'label': label, 'value': str(run_time)})
            return options
        return []
    except Exception as e:
        logger.error(f"Error getting run times: {e}")
        return []

def fetch_run_data(run_time: str, countries: List[str], scenario_group: str) -> Dict[str, pd.DataFrame]:
    """
    Fetch data for a specific run and list of countries.
    Returns a dictionary mapping country code to DataFrame.
    """
    results = {}
    missing_countries = []
    
    # Check cache first
    for country in countries:
        cache_key = f"{run_time}_{country}_{scenario_group}"
        if cache_key in data_cache:
            results[country] = data_cache[cache_key]
        else:
            missing_countries.append(country)
            
    if not missing_countries:
        return results

    _ensure_db()
    if stack_query is None:
        return results
        
    try:
        run_time_dt = pd.to_datetime(run_time)
        
        # Batch fetch missing countries
        logger.info(f"Batch fetching {len(missing_countries)} countries: {missing_countries}")
        df_batch = stack_query.get_prices_by_run_time(
            run_time_utc=run_time_dt,
            countries=missing_countries,
            scenario_group=scenario_group
        )
        
        if df_batch is not None and not df_batch.empty:
            # Convert to CET
            df_batch['start_time_cet'] = pd.to_datetime(df_batch['start_time_utc']).dt.tz_convert('Europe/Berlin')
            df_batch['date_cet'] = df_batch['start_time_cet'].dt.date
            df_batch['hour'] = df_batch['start_time_cet'].dt.hour
            
            # Split by country and cache
            for country in missing_countries:
                country_df = df_batch[df_batch['country'] == country].copy()
                if not country_df.empty:
                    cache_key = f"{run_time}_{country}_{scenario_group}"
                    
                    # Simple LRU-like eviction if cache is full
                    if len(data_cache) >= MAX_CACHE_SIZE:
                        # Remove oldest item (first key)
                        first_key = next(iter(data_cache))
                        del data_cache[first_key]
                        
                    data_cache[cache_key] = country_df
                    results[country] = country_df
                    
        return results
        
    except Exception as e:
        logger.error(f"Error fetching run data: {e}")
        return results


def aggregate_to_timeframe(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    """
    Aggregate data to specified timeframe.
    
    Args:
        df: DataFrame with 'start_time_cet' and 'price' columns
        timeframe: One of 'hourly', 'daily', 'weekly', 'quarterly', 'annual', 'trader'
    
    Returns:
        Aggregated DataFrame
    """
    if df is None or df.empty:
        return pd.DataFrame()
    
    df = df.copy()
    df['start_time_cet'] = pd.to_datetime(df['start_time_cet'])
    
    if timeframe == 'hourly' or timeframe == 'trader' or timeframe == 'day_ahead': # Trader view uses full data
        # Already at hourly level, just ensure proper grouping
        group_cols = ['start_time_cet', 'scenario', 'scenario_group', 'country']
        agg_df = df.groupby(group_cols)['price'].mean().reset_index()
        agg_df['time_label'] = agg_df['start_time_cet'].dt.strftime('%Y-%m-%d %H:%M')
        
    elif timeframe == 'daily':
        df['date'] = df['start_time_cet'].dt.date
        group_cols = ['date', 'scenario', 'scenario_group', 'country']
        agg_df = df.groupby(group_cols)['price'].mean().reset_index()
        agg_df['time_label'] = pd.to_datetime(agg_df['date']).dt.strftime('%Y-%m-%d')
        agg_df['start_time_cet'] = pd.to_datetime(agg_df['date'])
        
    elif timeframe == 'weekly':
        df['iso_year'] = df['start_time_cet'].dt.isocalendar().year
        df['iso_week'] = df['start_time_cet'].dt.isocalendar().week
        
        # Calculate coverage per week per scenario
        coverage = df.groupby(['iso_year', 'iso_week', 'scenario'])['start_time_cet'].apply(lambda x: x.dt.date.nunique()).reset_index(name='day_count')
        
        # Filter: Keep only if day_count == 7
        valid_weeks = coverage[coverage['day_count'] == 7]
        
        # Filter original df (indirectly via merge on aggregation)
        group_cols = ['iso_year', 'iso_week', 'scenario', 'scenario_group', 'country']
        agg_df = df.groupby(group_cols)['price'].mean().reset_index()
        
        # Add day count to agg_df to filter
        day_counts = df.groupby(group_cols)['start_time_cet'].apply(lambda x: x.dt.date.nunique()).reset_index(name='day_count')
        agg_df = pd.merge(agg_df, day_counts, on=group_cols)
        
        # Filter strict
        agg_df = agg_df[agg_df['day_count'] == 7]
        
        agg_df['time_label'] = agg_df['iso_year'].astype(str) + '-W' + agg_df['iso_week'].astype(str).str.zfill(2)
        # Use first day of week as representative timestamp
        # Re-calculate min start_time for the filtered rows or construct it
        # Using min from original df is fine as long as we filtered the rows
        # Align start_time_cet with the filtered agg_df (the groupby above returns all groups, but we filtered agg_df)
        # We need to ensure start_time_cet column matches the filtered rows.
        # Let's re-merge min start time
        min_times = df.groupby(group_cols)['start_time_cet'].min().reset_index(name='min_start_time')
        agg_df = pd.merge(agg_df, min_times, on=group_cols)
        agg_df['start_time_cet'] = agg_df['min_start_time']
        agg_df.drop(columns=['min_start_time'], inplace=True)
        
    elif timeframe == 'monthly':
        df['month'] = df['start_time_cet'].dt.month
        df['year'] = df['start_time_cet'].dt.year
        df['days_in_month'] = df['start_time_cet'].dt.days_in_month
        
        # Calculate coverage per month per scenario
        # We group by year, month, scenario to count unique days
        coverage = df.groupby(['year', 'month', 'scenario'])['start_time_cet'].apply(lambda x: x.dt.date.nunique()).reset_index(name='day_count')
        
        # Get max days for each month (using first available row for that month)
        # We can just use the days_in_month column we added
        month_days = df.groupby(['year', 'month'])['days_in_month'].first().reset_index()
        
        # Merge coverage with expected days
        coverage = pd.merge(coverage, month_days, on=['year', 'month'])
        
        # Filter: Keep only if day_count >= days_in_month - 1
        valid_months = coverage[coverage['day_count'] >= coverage['days_in_month'] - 1]
        
        group_cols = ['year', 'month', 'scenario', 'scenario_group', 'country']
        agg_df = df.groupby(group_cols)['price'].mean().reset_index()
        
        # Add day count to agg_df to filter
        day_counts = df.groupby(group_cols)['start_time_cet'].apply(lambda x: x.dt.date.nunique()).reset_index(name='day_count')
        agg_df = pd.merge(agg_df, day_counts, on=group_cols)
        
        # Add expected days
        agg_df = pd.merge(agg_df, month_days, on=['year', 'month'])
        
        # Filter strict
        agg_df = agg_df[agg_df['day_count'] >= agg_df['days_in_month'] - 1]
        
        agg_df['time_label'] = agg_df['year'].astype(str) + '-' + agg_df['month'].astype(str).str.zfill(2)
        
        # Re-merge min start time
        min_times = df.groupby(group_cols)['start_time_cet'].min().reset_index(name='min_start_time')
        agg_df = pd.merge(agg_df, min_times, on=group_cols)
        agg_df['start_time_cet'] = agg_df['min_start_time']
        agg_df.drop(columns=['min_start_time'], inplace=True)

    elif timeframe == 'quarterly':
        df['quarter'] = df['start_time_cet'].dt.quarter
        df['year'] = df['start_time_cet'].dt.year
        
        # Calculate expected days in quarter
        # Q1: 90/91 (Leap), Q2: 91, Q3: 92, Q4: 92
        def get_days_in_quarter(row):
            year = row['year']
            quarter = row['quarter']
            if quarter == 1:
                return 91 if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0) else 90
            elif quarter == 2:
                return 91
            elif quarter == 3:
                return 92
            elif quarter == 4:
                return 92
            return 0

        # We can do this vectorized or just mapping
        # Let's create a mapping df for year-quarter
        unique_yq = df[['year', 'quarter']].drop_duplicates()
        unique_yq['days_in_quarter'] = unique_yq.apply(get_days_in_quarter, axis=1)
        
        group_cols = ['year', 'quarter', 'scenario', 'scenario_group', 'country']
        agg_df = df.groupby(group_cols)['price'].mean().reset_index()
        
        # Add day count
        day_counts = df.groupby(group_cols)['start_time_cet'].apply(lambda x: x.dt.date.nunique()).reset_index(name='day_count')
        agg_df = pd.merge(agg_df, day_counts, on=group_cols)
        
        # Add expected days
        agg_df = pd.merge(agg_df, unique_yq, on=['year', 'quarter'])
        
        # Filter strict
        agg_df = agg_df[agg_df['day_count'] >= agg_df['days_in_quarter']]
        
        agg_df['time_label'] = agg_df['year'].astype(str) + '-Q' + agg_df['quarter'].astype(str)
        
        # Re-merge min start time
        min_times = df.groupby(group_cols)['start_time_cet'].min().reset_index(name='min_start_time')
        agg_df = pd.merge(agg_df, min_times, on=group_cols)
        agg_df['start_time_cet'] = agg_df['min_start_time']
        agg_df.drop(columns=['min_start_time'], inplace=True)
        
    elif timeframe == 'annual':
        df['year'] = df['start_time_cet'].dt.year
        
        # Calculate expected days in year
        def get_days_in_year(year):
             return 366 if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0) else 365
             
        unique_y = df[['year']].drop_duplicates()
        unique_y['days_in_year'] = unique_y['year'].apply(get_days_in_year)
        
        group_cols = ['year', 'scenario', 'scenario_group', 'country']
        agg_df = df.groupby(group_cols)['price'].mean().reset_index()
        
        # Add day count
        day_counts = df.groupby(group_cols)['start_time_cet'].apply(lambda x: x.dt.date.nunique()).reset_index(name='day_count')
        agg_df = pd.merge(agg_df, day_counts, on=group_cols)
        
        # Add expected days
        agg_df = pd.merge(agg_df, unique_y, on=['year'])
        
        # Filter strict
        agg_df = agg_df[agg_df['day_count'] >= agg_df['days_in_year']]
        
        agg_df['time_label'] = agg_df['year'].astype(str)
        
        # Re-merge min start time
        min_times = df.groupby(group_cols)['start_time_cet'].min().reset_index(name='min_start_time')
        agg_df = pd.merge(agg_df, min_times, on=group_cols)
        agg_df['start_time_cet'] = agg_df['min_start_time']
        agg_df.drop(columns=['min_start_time'], inplace=True)
    
    else:
        raise ValueError(f"Unknown timeframe: {timeframe}")
    
    return agg_df


def map_to_products(df: pd.DataFrame) -> pd.DataFrame:
    """
    Map timestamp data to tradable products (Months, Quarters, Years).
    Optimized version using daily aggregation first.
    
    Returns:
        DataFrame with 'product_name', 'product_type', 'sort_order', 'scenario', 'price'
    """
    if df is None or df.empty:
        return pd.DataFrame()
    
    # 1. Pre-calculate Daily Stats (Vectorized)
    # Filter for valid days (23+ hours) to handle DST and incomplete data
    daily_counts = df.groupby(['date_cet', 'scenario'])['price'].count()
    valid_days_mask = daily_counts >= 23
    
    if not valid_days_mask.any():
        return pd.DataFrame()
        
    # Calculate daily sums and counts for weighted average
    # We use the raw df but grouped by date, which is much smaller
    daily_agg = df.groupby(['date_cet', 'scenario'])['price'].agg(['sum', 'count']).reset_index()
    
    # Filter for valid days only
    daily_agg = daily_agg[daily_agg.set_index(['date_cet', 'scenario']).index.isin(valid_days_mask[valid_days_mask].index)]
    
    if daily_agg.empty:
        return pd.DataFrame()

    current_date = pd.Timestamp.now().date()
    current_month = current_date.replace(day=1)
    
    product_defs = []

    # --- Define Products ---

    # 0. Daily Products (Next 7 Days)
    for i in range(7):
        target_date = current_date + pd.Timedelta(days=i)
        product_defs.append({
            'name': target_date.strftime('%d-%b'),
            'type': 'Day',
            'order': i,
            'start': target_date,
            'end': target_date,
            'min_days': 1
        })

    # 0.5 Weekly Products (Next 6 Weeks)
    current_week = pd.Timestamp(current_date).isocalendar().week
    current_year = pd.Timestamp(current_date).isocalendar().year
    
    # Helper for ISO weeks
    def get_week_range(year, week):
        # ISO week starts Monday
        d = pd.Timestamp.fromisocalendar(year, week, 1).date()
        return d, d + pd.Timedelta(days=6)

    weeks = []
    y, w = current_year, current_week
    for i in range(6):
        start, end = get_week_range(y, w)
        product_defs.append({
            'name': f'W{w}-{str(y)[2:]}',
            'type': 'Week',
            'order': 100 + i,
            'start': start,
            'end': end,
            'min_days': 7
        })
        w += 1
        if w > 52: # Simple rollover
            w = 1
            y += 1

    # 1. Monthly Products (Next 3 months)
    for i in range(3):
        target_month = (current_month + pd.DateOffset(months=i)).date()
        # End of month
        next_month = (target_month + pd.DateOffset(months=1)).replace(day=1)
        end_month = (next_month - pd.Timedelta(days=1)).date()
        
        product_defs.append({
            'name': target_month.strftime('%b-%y'),
            'type': 'Month',
            'order': 200 + i,
            'start': target_month,
            'end': end_month,
            'min_days': (end_month - target_month).days + 1
        })

    # 2. Quarterly Products (Next 3 quarters)
    current_q = (current_date.month - 1) // 3 + 1
    start_year = current_date.year
    q_count = 0
    
    # Look ahead enough to find 3 quarters
    for y in range(start_year, start_year + 2):
        start_q = current_q if y == start_year else 1
        for q in range(start_q, 5):
            if q_count >= 3: break
            
            # Define Quarter dates
            q_start_month = (q - 1) * 3 + 1
            q_start = pd.Timestamp(year=y, month=q_start_month, day=1).date()
            q_end = (q_start + pd.DateOffset(months=3) - pd.Timedelta(days=1)).date()
            
            days_in_q = (q_end - q_start).days + 1
            
            product_defs.append({
                'name': f'Q{q}-{str(y)[2:]}',
                'type': 'Quarter',
                'order': 300 + q_count,
                'start': q_start,
                'end': q_end,
                'min_days': days_in_q
            })
            q_count += 1

    # 3. Calendar Years (Next 2 years)
    for i in range(1, 3):
        target_year = start_year + i
        y_start = pd.Timestamp(year=target_year, month=1, day=1).date()
        y_end = pd.Timestamp(year=target_year, month=12, day=31).date()
        days_in_year = 366 if pd.Timestamp(year=target_year, month=1, day=1).is_leap_year else 365
        
        product_defs.append({
            'name': f'Cal-{str(target_year)[2:]}',
            'type': 'Year',
            'order': 400 + i,
            'start': y_start,
            'end': y_end,
            'min_days': days_in_year
        })

    # --- Calculate Prices ---
    results = []
    
    # Convert daily_agg to a format easy to query: date -> row
    # Actually, just filtering is fast enough on small daily_agg
    
    for p in product_defs:
        # Filter days within product range
        mask = (daily_agg['date_cet'] >= p['start']) & (daily_agg['date_cet'] <= p['end'])
        subset = daily_agg[mask]
        
        if subset.empty:
            continue
            
        # Check coverage per scenario
        # We need scenarios that have enough days
        coverage = subset.groupby('scenario')['date_cet'].nunique()
        valid_scenarios = coverage[coverage >= p['min_days']].index
        
        if valid_scenarios.empty:
            continue
            
        # Calculate weighted mean for valid scenarios
        valid_subset = subset[subset['scenario'].isin(valid_scenarios)]
        
        # Group by scenario and sum(sum) / sum(count)
        prod_stats = valid_subset.groupby('scenario').agg({
            'sum': 'sum',
            'count': 'sum'
        }).reset_index()
        
        prod_stats['price'] = prod_stats['sum'] / prod_stats['count']
        prod_stats['product_name'] = p['name']
        prod_stats['product_type'] = p['type']
        prod_stats['sort_order'] = p['order']
        
        results.append(prod_stats[['product_name', 'product_type', 'sort_order', 'scenario', 'price']])

    if not results:
        return pd.DataFrame()
        
    return pd.concat(results, ignore_index=True)


def calculate_ensemble_statistics(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    """
    Calculate ensemble statistics (mean, median, percentiles, std) for each time point.
    
    Args:
        df: DataFrame with aggregated ensemble data
        timeframe: Timeframe for grouping
    
    Returns:
        DataFrame with ensemble statistics
    """
    if df is None or df.empty:
        return pd.DataFrame()
    
    # Group by time point and calculate statistics across all scenarios
    if timeframe == 'hourly':
        group_col = 'start_time_cet'
    elif timeframe == 'daily':
        group_col = 'date' if 'date' in df.columns else 'start_time_cet'
    elif timeframe == 'weekly':
        group_col = 'time_label'
    elif timeframe == 'monthly':
        group_col = 'time_label'
    elif timeframe == 'quarterly':
        group_col = 'time_label'
    elif timeframe == 'annual':
        group_col = 'time_label'
    else:
        group_col = 'start_time_cet'
    
    stats = df.groupby(group_col)['price'].agg([
        ('mean', 'mean'),
        ('median', 'median'),
        ('std', 'std'),
        ('min', 'min'),
        ('max', 'max'),
        ('p10', lambda x: x.quantile(0.10)),
        ('p25', lambda x: x.quantile(0.25)),
        ('p75', lambda x: x.quantile(0.75)),
        ('p90', lambda x: x.quantile(0.90)),
        ('count', 'count')
    ]).reset_index()
    
    stats['spread'] = stats['p90'] - stats['p10']
    stats['iqr'] = stats['p75'] - stats['p25']
    
    return stats


# ============================================================================
# VISUALIZATION FUNCTIONS - TRADER VIEW
# ============================================================================

def create_forward_curve_plot(prod1: pd.DataFrame, prod2: pd.DataFrame,
                              country: str, scenario_group: str) -> go.Figure:
    """Create a Forward Curve comparison (Price vs Product)."""
    fig = go.Figure()
    
    if prod1 is None or prod1.empty:
        fig.add_annotation(text="No data available for Run 1",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    if prod1.empty:
        fig.add_annotation(text="Insufficient data to construct forward curve",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig

    # Aggregate to get mean/median per product across scenarios
    is_ensemble = scenario_group in ['ENS_MEDIUM', 'ENS_EXTENDED']
    
    if is_ensemble:
        curve1 = prod1.groupby(['product_name', 'sort_order'])['price'].median().reset_index()
    else:
        curve1 = prod1[prod1['scenario'] == 'BASELINE'].groupby(['product_name', 'sort_order'])['price'].mean().reset_index()
        
    curve1 = curve1.sort_values('sort_order')
    
    # Collect all unique products and sort them to enforce axis order
    all_products = curve1[['product_name', 'sort_order']].drop_duplicates()
    
    # Plot Run 1
    fig.add_trace(go.Scatter(
        x=curve1['product_name'],
        y=curve1['price'],
        mode='lines+markers',
        name='Run 1 (Curve)',
        line=dict(color='blue', width=3),
        marker=dict(size=8),
        hovertemplate='<b>Run 1</b><br>Product: %{x}<br>Price: %{y:.2f}<extra></extra>'
    ))
    
    # Plot Run 2
    if prod2 is not None and not prod2.empty:
        if is_ensemble:
            curve2 = prod2.groupby(['product_name', 'sort_order'])['price'].median().reset_index()
        else:
            curve2 = prod2[prod2['scenario'] == 'BASELINE'].groupby(['product_name', 'sort_order'])['price'].mean().reset_index()
            
        curve2 = curve2.sort_values('sort_order')
        
        # Add to all products list
        all_products = pd.concat([all_products, curve2[['product_name', 'sort_order']]]).drop_duplicates()
        
        fig.add_trace(go.Scatter(
            x=curve2['product_name'],
            y=curve2['price'],
            mode='lines+markers',
            name='Run 2 (Curve)',
            line=dict(color='red', width=3, dash='dash'),
            marker=dict(size=8),
            hovertemplate='<b>Run 2</b><br>Product: %{x}<br>Price: %{y:.2f}<extra></extra>'
        ))
        
        # Calculate Delta (only for overlapping products)
        merged = pd.merge(curve1, curve2, on='product_name', suffixes=('_1', '_2'), how='inner')
        merged = merged.sort_values('sort_order_1')
        
        merged['delta'] = merged['price_1'] - merged['price_2']
        
        # Add text annotations for Delta
        for idx, row in merged.iterrows():
            fig.add_annotation(
                x=row['product_name'],
                y=max(row['price_1'], row['price_2']),
                text=f"{row['delta']:+.2f}",
                showarrow=False,
                yshift=15,
                font=dict(color='green' if row['delta'] > 0 else 'red', size=10)
            )

    # Sort all products to define axis order
    all_products = all_products.sort_values('sort_order')
    sorted_product_names = all_products['product_name'].tolist()

    fig.update_layout(
        title=f'Forward Curve Comparison (Price vs Tenor): {scenario_group} - {country}',
        xaxis_title='Product',
        yaxis_title='Price',
        hovermode='x unified',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0',
        xaxis={'categoryorder': 'array', 'categoryarray': sorted_product_names}
    )
    
    return fig


def create_volatility_change_plot(prod1: pd.DataFrame, prod2: pd.DataFrame,
                                  country: str, scenario_group: str) -> go.Figure:
    """Create a plot showing change in spread/volatility per product."""
    fig = go.Figure()
    
    # Only relevant for Ensemble
    if scenario_group not in ['ENS_MEDIUM', 'ENS_EXTENDED']:
        fig.add_annotation(text="Volatility analysis only available for Ensemble runs",
                          xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False)
        return fig

    if prod1 is None or prod1.empty:
        return fig
    
    if prod1.empty:
        return fig
        
    # Calculate spread (P90 - P10) for each product
    def calc_spread(df_prod):
        stats = df_prod.groupby(['product_name', 'sort_order'])['price'].agg([
            ('p10', lambda x: x.quantile(0.10)),
            ('p90', lambda x: x.quantile(0.90))
        ]).reset_index()
        stats['spread'] = stats['p90'] - stats['p10']
        return stats.sort_values('sort_order')
        
    spread1 = calc_spread(prod1)
    
    # Collect all unique products and sort them to enforce axis order
    all_products = spread1[['product_name', 'sort_order']].drop_duplicates()
    
    # Plot Run 1 Spread
    fig.add_trace(go.Bar(
        name='Run 1 Spread (P90-P10)',
        x=spread1['product_name'],
        y=spread1['spread'],
        marker_color='blue',
        opacity=0.6
    ))
    
    if prod2 is not None and not prod2.empty:
        spread2 = calc_spread(prod2)
        
        # Add to all products list
        all_products = pd.concat([all_products, spread2[['product_name', 'sort_order']]]).drop_duplicates()
        
        fig.add_trace(go.Bar(
            name='Run 2 Spread (P90-P10)',
            x=spread2['product_name'],
            y=spread2['spread'],
            marker_color='red',
            opacity=0.6
        ))
        
        # Change in spread (only for overlapping products)
        merged = pd.merge(spread1, spread2, on='product_name', suffixes=('_1', '_2'), how='inner')
        merged = merged.sort_values('sort_order_1')
        
        merged['spread_change'] = merged['spread_1'] - merged['spread_2']
        
        # Add annotation for change
        for idx, row in merged.iterrows():
            fig.add_annotation(
                x=row['product_name'],
                y=max(row['spread_1'], row['spread_2']),
                text=f"{row['spread_change']:+.2f}",
                showarrow=False,
                yshift=10,
                font=dict(size=9)
            )

    # Sort all products to define axis order
    all_products = all_products.sort_values('sort_order')
    sorted_product_names = all_products['product_name'].tolist()

    fig.update_layout(
        title=f'Ensemble Spread (Uncertainty) by Product: {scenario_group} - {country}',
        xaxis_title='Product',
        yaxis_title='Spread (P90 - P10)',
        barmode='group',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0',
        xaxis={'categoryorder': 'array', 'categoryarray': sorted_product_names}
    )
    
    return fig


def create_cross_border_spread_plot(base_prod: pd.DataFrame, neighbor_prods: Dict[str, pd.DataFrame], 
                                  base_country: str, scenario_group: str) -> go.Figure:
    """Create a plot showing spreads against other countries."""
    fig = go.Figure()
    
    if base_prod is None or base_prod.empty:
        return fig
    if base_prod.empty:
        return fig
    
    # Filter for BASELINE or Median
    is_ensemble = scenario_group in ['ENS_MEDIUM', 'ENS_EXTENDED']
    if is_ensemble:
        base_curve = base_prod.groupby(['product_name', 'sort_order'])['price'].median().reset_index()
    else:
        base_curve = base_prod[base_prod['scenario'] == 'BASELINE'].groupby(['product_name', 'sort_order'])['price'].mean().reset_index()
    
    # Iterate through neighbors
    for country, neigh_prod in neighbor_prods.items():
        if neigh_prod is None or neigh_prod.empty:
            continue
            
        if is_ensemble:
            neigh_curve = neigh_prod.groupby(['product_name', 'sort_order'])['price'].median().reset_index()
        else:
            neigh_curve = neigh_prod[neigh_prod['scenario'] == 'BASELINE'].groupby(['product_name', 'sort_order'])['price'].mean().reset_index()
            
        # Merge
        merged = pd.merge(base_curve, neigh_curve, on=['product_name', 'sort_order'], suffixes=('_base', '_neigh'))
        merged['spread'] = merged['price_base'] - merged['price_neigh']
        merged = merged.sort_values('sort_order')
        
        fig.add_trace(go.Scatter(
            x=merged['product_name'],
            y=merged['spread'],
            mode='lines+markers',
            name=f'{base_country} - {country}',
            hovertemplate=f'<b>{base_country} - {country}</b><br>Product: %{{x}}<br>Spread: %{{y:.2f}}<extra></extra>'
        ))
        
    fig.add_hline(y=0, line_dash="dash", line_color="gray", opacity=0.5)
    
    fig.update_layout(
        title=f'Cross-Border Spreads ({base_country} vs Neighbors): {scenario_group}',
        xaxis_title='Product',
        yaxis_title='Spread (€/MWh)',
        hovermode='x unified',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


def create_time_spread_plot(prod: pd.DataFrame, country: str, scenario_group: str) -> go.Figure:
    """Create a plot showing time spreads (e.g. Q1 vs Q2)."""
    fig = go.Figure()
    
    if prod is None or prod.empty:
        return fig
    if prod.empty:
        return fig
        
    # Filter for BASELINE or Median
    is_ensemble = scenario_group in ['ENS_MEDIUM', 'ENS_EXTENDED']
    if is_ensemble:
        curve = prod.groupby(['product_name', 'sort_order', 'product_type'])['price'].median().reset_index()
    else:
        curve = prod[prod['scenario'] == 'BASELINE'].groupby(['product_name', 'sort_order', 'product_type'])['price'].mean().reset_index()
    
    curve = curve.sort_values('sort_order')
    
    # Calculate spreads between consecutive products of the same type
    spreads = []
    
    # Include Days, Weeks and Months for short-term forecasts
    for ptype in ['Day', 'Week', 'Month', 'Quarter', 'Year']:
        type_curve = curve[curve['product_type'] == ptype].copy()
        if len(type_curve) < 2:
            continue
            
        # Ensure we are comparing consecutive products
        # For simplicity, we'll just take the sorted list and compare i vs i+1
        # This assumes map_to_products returns them in correct order (which it does via sort_order)
        
        type_curve['next_price'] = type_curve['price'].shift(-1)
        type_curve['next_product'] = type_curve['product_name'].shift(-1)
        
        # Filter out invalid comparisons if needed (e.g. W52 vs W1 of next year is valid, but W10 vs W15 is not)
        # For now, we assume the list contains consecutive available products. 
        # If there's a gap (e.g. W1, W3), it will calculate spread W1-W3. This is still a spread, just not W1-W2.
        # Given the user wants "complete enough", let's just show what we have.
        
        type_curve = type_curve.dropna()
        
        if not type_curve.empty:
            type_curve['spread_name'] = type_curve['product_name'] + ' / ' + type_curve['next_product']
            type_curve['spread_val'] = type_curve['price'] - type_curve['next_price']
            spreads.append(type_curve)
        
    if not spreads:
        fig.add_annotation(text="Insufficient data for time spreads", xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False)
        return fig
        
    spread_df = pd.concat(spreads)
    
    # Color by positive/negative
    colors = ['green' if x > 0 else 'red' for x in spread_df['spread_val']]
    
    fig.add_trace(go.Bar(
        x=spread_df['spread_name'],
        y=spread_df['spread_val'],
        marker_color=colors,
        text=spread_df['spread_val'].round(2),
        textposition='auto'
    ))
    
    fig.add_hline(y=0, line_dash="dash", line_color="black", opacity=0.5)
    
    fig.update_layout(
        title=f'Time Spreads (Backwardation/Contango): {scenario_group} - {country}',
        xaxis_title='Spread Pair',
        yaxis_title='Spread (€/MWh)',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


def create_hourly_shape_plot(df: pd.DataFrame, country: str, scenario_group: str) -> go.Figure:
    """Create a plot showing hourly shape distribution (Violins)."""
    fig = go.Figure()
    
    if df is None or df.empty:
        return fig
        
    # Ensure hour column exists
    if 'hour' not in df.columns:
        df['hour'] = pd.to_datetime(df['start_time_cet']).dt.hour
        
    # For ensemble, use Violins
    if scenario_group in ['ENS_MEDIUM', 'ENS_EXTENDED']:
        # We need the raw data for violins: hour, price, scenario
        # But we want to aggregate over days first? 
        # Usually "Hourly Shape" means average hour over the period.
        # So for each scenario, we calculate the average profile.
        
        avg_profile = df.groupby(['scenario', 'hour'])['price'].mean().reset_index()
        
        fig.add_trace(go.Violin(
            x=avg_profile['hour'],
            y=avg_profile['price'],
            name='Hourly Distribution',
            box_visible=True,
            meanline_visible=True,
            line_color='blue',
            opacity=0.6,
            hoverinfo='y' # Reduce hover info
        ))
        
    else:
        # Deterministic - just plot BASELINE
        hourly = df[df['scenario'] == 'BASELINE'].groupby('hour')['price'].mean().reset_index()
        
        fig.add_trace(go.Scatter(
            x=hourly['hour'],
            y=hourly['price'],
            mode='lines+markers',
            name='Baseline Shape',
            line=dict(color='blue', width=3),
            hovertemplate='Hour: %{x}<br>Price: %{y:.2f}<extra></extra>'
        ))
        
    # Add Peak/Offpeak markers
    fig.add_vrect(x0=8, x1=20, fillcolor="orange", opacity=0.1, layer="below", line_width=0, annotation_text="Peak", annotation_position="top left")
    
    fig.update_layout(
        title=f'Hourly Shape Distribution: {scenario_group} - {country}',
        xaxis_title='Hour (CET)',
        yaxis_title='Price (€/MWh)',
        xaxis=dict(tickmode='linear', tick0=0, dtick=1),
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0',
        showlegend=False
    )
    
    return fig


def create_ensemble_skew_plot(prod: pd.DataFrame, country: str, scenario_group: str) -> go.Figure:
    """Create a histogram of prices for key products to show skew."""
    fig = go.Figure()
    
    if prod is None or prod.empty:
        return fig
        
    if scenario_group not in ['ENS_MEDIUM', 'ENS_EXTENDED']:
        fig.add_annotation(text="Skew analysis only for Ensemble", xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False)
        return fig
    if prod.empty:
        return fig
        
    # Select a few key products (e.g. Front Month, Front Quarter, Cal+1)
    # We'll take the first available of each type
    key_products = []
    for ptype in ['Week', 'Month', 'Quarter', 'Year']:
        prods = prod[prod['product_type'] == ptype]['product_name'].unique()
        if len(prods) > 0:
            key_products.append(prods[0])
            
    if not key_products:
        return fig
        
    for i, product in enumerate(key_products):
        subset = prod[prod['product_name'] == product]
        
        fig.add_trace(go.Histogram(
            x=subset['price'],
            name=product,
            opacity=0.6,
            nbinsx=20
        ))
        
    fig.update_layout(
        title=f'Ensemble Price Distribution (Skew): {scenario_group} - {country}',
        xaxis_title='Price (€/MWh)',
        yaxis_title='Count',
        barmode='overlay',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


# ============================================================================
# VISUALIZATION FUNCTIONS - ENSEMBLE
# ============================================================================

def create_ensemble_spaghetti_plot(agg1: pd.DataFrame, agg2: pd.DataFrame, 
                                   timeframe: str, country: str, 
                                   scenario_group: str, show_members: bool = True) -> go.Figure:
    """Create spaghetti plot with percentile envelopes for ensemble runs."""
    fig = go.Figure()
    
    if agg1 is None or agg1.empty:
        fig.add_annotation(text="No data available for Run 1", 
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    # Get unique time labels
    time_labels = sorted(agg1['time_label'].unique())
    
    # Handle single time point case with a Box Plot
    if len(time_labels) == 1:
        time_label = time_labels[0]
        
        # Run 1 Box
        fig.add_trace(go.Box(
            y=agg1['price'],
            name='Run 1',
            marker_color='blue',
            boxpoints='all', # Show all points
            jitter=0.3,
            pointpos=-1.8
        ))
        
        # Run 2 Box
        if agg2 is not None and not agg2.empty:
            # Ensure we are looking at the same time point if possible, or just whatever is there
            # If agg2 has different time labels, this might be weird, but usually they match.
            fig.add_trace(go.Box(
                y=agg2['price'],
                name='Run 2',
                marker_color='red',
                boxpoints='all',
                jitter=0.3,
                pointpos=-1.8
            ))
            
        fig.update_layout(
            title=f'Price Distribution (Single Period: {time_label}): {scenario_group} - {country}',
            yaxis_title='Price (€/MWh)',
            height=600,
            template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0',
            showlegend=True
        )
        return fig
    
    # Function to add traces for a run
    def add_run_traces(agg, run_name, color_base, dash_style):
        # Calculate percentiles
        stats = calculate_ensemble_statistics(agg, timeframe)
        
        # Plot Median (P50) - Always visible
        fig.add_trace(go.Scatter(
            x=stats[stats.columns[0]], # First column is time
            y=stats['median'],
            mode='lines',
            name=f'{run_name} Median',
            line=dict(color=color_base, width=3, dash=dash_style),
            hovertemplate=f'{run_name} Median<br>%{{x}}<br>Price: %{{y:.2f}}<extra></extra>'
        ))
        
        # Plot P10-P90 Envelope - Always visible
        fig.add_trace(go.Scatter(
            x=pd.concat([stats[stats.columns[0]], stats[stats.columns[0]][::-1]]),
            y=pd.concat([stats['p90'], stats['p10'][::-1]]),
            fill='toself',
            fillcolor=color_base,
            line=dict(color='rgba(255,255,255,0)'),
            opacity=0.2,
            name=f'{run_name} P10-P90',
            showlegend=True,
            hoverinfo='skip'
        ))
        
        # Plot individual members - Conditional
        if show_members:
            scenarios = agg['scenario'].unique()
            for scenario in scenarios:
                df_scen = agg[agg['scenario'] == scenario]
                fig.add_trace(go.Scatter(
                    x=df_scen['time_label'], # Use time_label for x-axis consistency
                    y=df_scen['price'],
                    mode='lines',
                    name=f'{run_name} Members',
                    line=dict(color=color_base, width=1),
                    opacity=0.1,
                    showlegend=False,
                    hoverinfo='skip'
                ))

    add_run_traces(agg1, "Run 1", "blue", "solid")

    if agg2 is not None and not agg2.empty:
        add_run_traces(agg2, "Run 2", "red", "dash")
    
    fig.update_layout(
        title=f'Spaghetti Plot: {scenario_group} - {country} ({timeframe.capitalize()})<br><sub>Light lines = individual ensemble members | Legend shows statistical summaries</sub>',
        xaxis_title='Time',
        yaxis_title='Price',
        hovermode='x unified',
        height=600,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


def create_price_duration_curve(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                timeframe: str, country: str,
                                scenario_group: str) -> go.Figure:
    """Create Price Duration Curve (PDC) for ensemble runs."""
    fig = go.Figure()

    if agg1 is None or agg1.empty:
        fig.add_annotation(text="No data available for Run 1",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig

    # Function to add traces for a run
    def add_run_traces(agg, run_name, color_base, dash_style):
        scenarios = agg['scenario'].unique()
        sorted_prices = []
        
        # Plot individual scenarios faintly
        for scenario in scenarios:
            df_scen = agg[agg['scenario'] == scenario]
            # Drop NaNs to ensure clean sorting
            prices = sorted(df_scen['price'].dropna().values, reverse=True)
            if len(prices) == 0:
                continue
                
            sorted_prices.append(prices)
            x_pct = np.linspace(0, 100, len(prices))
            
            fig.add_trace(go.Scatter(
                x=x_pct,
                y=prices,
                mode='lines',
                name=f'{run_name} Members',
                line=dict(color=color_base, width=1),
                opacity=0.1,
                showlegend=False,
                hoverinfo='skip'
            ))
            
        # Calculate and plot Median PDC
        if sorted_prices:
            # Truncate to min length to allow numpy operations
            min_len = min(len(p) for p in sorted_prices)
            if min_len > 0:
                truncated_prices = [p[:min_len] for p in sorted_prices]
                arr = np.array(truncated_prices)
                median_curve = np.median(arr, axis=0)
                x_pct = np.linspace(0, 100, min_len)
                
                fig.add_trace(go.Scatter(
                    x=x_pct,
                    y=median_curve,
                    mode='lines',
                    name=f'{run_name} Median PDC',
                    line=dict(color=color_base, width=3, dash=dash_style),
                    hovertemplate=f'{run_name} Median<br>Duration: %{{x:.1f}}%<br>Price: %{{y:.2f}}<extra></extra>'
                ))

    add_run_traces(agg1, "Run 1", "blue", "solid")

    if agg2 is not None and not agg2.empty:
        add_run_traces(agg2, "Run 2", "red", "dash")

    fig.update_layout(
        title=f'Price Duration Curve: {scenario_group} - {country} ({timeframe.capitalize()})',
        xaxis_title='Duration (%)',
        yaxis_title='Price',
        height=600,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0',
        xaxis=dict(range=[0, 100]),
        hovermode='x unified'
    )

    return fig


def create_ensemble_violin_plot(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                timeframe: str, country: str,
                                scenario_group: str) -> go.Figure:
    """Create violin plot showing price distribution across ensemble members."""
    fig = go.Figure()
    
    if agg1 is None or agg1.empty:
        fig.add_annotation(text="No data available for Run 1",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    # Limit to first 20 time points for readability
    time_labels = sorted(agg1['time_label'].unique())[:20]
    agg1 = agg1[agg1['time_label'].isin(time_labels)]
    
    # Add Run 1 violins
    for time_label in time_labels:
        prices = agg1[agg1['time_label'] == time_label]['price'].values
        fig.add_trace(go.Violin(
            x=[time_label] * len(prices),
            y=prices,
            name=f'Run 1',
            legendgroup='run1',
            scalegroup='run1',
            line_color='blue',
            showlegend=(time_label == time_labels[0])
        ))
    
    # Add Run 2 if available
    if agg2 is not None and not agg2.empty:
        agg2 = agg2[agg2['time_label'].isin(time_labels)]
        
        for time_label in time_labels:
            prices = agg2[agg2['time_label'] == time_label]['price'].values
            if len(prices) > 0:
                fig.add_trace(go.Violin(
                    x=[time_label] * len(prices),
                    y=prices,
                    name=f'Run 2',
                    legendgroup='run2',
                    scalegroup='run2',
                    line_color='red',
                    showlegend=(time_label == time_labels[0])
                ))
    
    fig.update_layout(
        title=f'Price Distribution: {scenario_group} - {country} ({timeframe.capitalize()})',
        xaxis_title='Time',
        yaxis_title='Price',
        violinmode='group',
        height=600,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


def create_ensemble_comparison_bars(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                    timeframe: str, country: str, scenario_group: str) -> go.Figure:
    """Create bar chart showing delta between runs with confidence intervals."""
    fig = go.Figure()
    
    if agg1 is None or agg1.empty:
        fig.add_annotation(text="No data available for Run 1",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    if agg2 is None or agg2.empty:
        fig.add_annotation(text="Need data from both runs for comparison",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    # Calculate ensemble statistics at each time point
    stats1 = calculate_ensemble_statistics(agg1, timeframe)
    stats2 = calculate_ensemble_statistics(agg2, timeframe)
    
    # Get time labels
    time_col = stats1.columns[0]
    time_labels = stats1[time_col].astype(str).tolist()
    
    # Calculate deltas (Run 1 - Run 2)
    mean_delta = stats1['mean'] - stats2['mean']
    median_delta = stats1['median'] - stats2['median']
    
    # Calculate confidence interval based on combined spread
    # Using propagation of uncertainty: sqrt(std1^2 + std2^2)
    combined_std = np.sqrt(stats1['std']**2 + stats2['std']**2)
    
    # Use 1.96 * std for approximate 95% confidence interval
    ci_upper = 1.96 * combined_std
    ci_lower = 1.96 * combined_std
    
    # Determine bar color based on sign (green for positive, red for negative)
    colors = ['green' if x > 0 else 'red' for x in mean_delta]
    
    # Plot delta bars without confidence intervals
    fig.add_trace(go.Bar(
        name='Mean Difference (Run 1 - Run 2)',
        x=time_labels,
        y=mean_delta,
        marker_color=colors,
        hovertemplate='<b>Delta (Run 1 - Run 2)</b><br>' +
                      'Time: %{x}<br>' +
                      'Mean Diff: %{y:.2f}<br>' +
                      'Median Diff: ' + median_delta.round(2).astype(str) + '<extra></extra>'
    ))
    
    # Add zero reference line
    fig.add_hline(y=0, line_dash="dash", line_color="gray", opacity=0.5, 
                  annotation_text="No difference", annotation_position="right")
    
    fig.update_layout(
        title=f'Price Difference by {timeframe.capitalize()}: {scenario_group} - {country}<br><sub>Green = Run 1 higher, Red = Run 2 higher</sub>',
        xaxis_title='Time',
        yaxis_title='Mean Price Difference (Run 1 - Run 2)',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0',
        showlegend=False
    )
    
    return fig


def create_ensemble_delta_heatmap(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                  timeframe: str, country: str,
                                  scenario_group: str) -> go.Figure:
    """Create heatmap showing price differences between runs over time."""
    fig = go.Figure()
    
    if agg1 is None or agg1.empty or agg2 is None or agg2.empty:
        fig.add_annotation(text="Need data from both runs for comparison",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    # Pivot to get scenarios as columns
    pivot1 = agg1.pivot_table(index='time_label', columns='scenario', values='price')
    pivot2 = agg2.pivot_table(index='time_label', columns='scenario', values='price')
    
    # Calculate difference (Run 1 - Run 2)
    delta = pivot1 - pivot2
    
    # Transpose so scenarios are on y-axis and time on x-axis
    delta_transposed = delta.T
    
    fig = go.Figure(data=go.Heatmap(
        z=delta_transposed.values,
        x=delta_transposed.columns,
        y=delta_transposed.index,
        colorscale='RdBu_r',  # Reversed so red = higher (positive)
        zmid=0,
        colorbar=dict(title='Price Difference<br>(Run 1 - Run 2)'),
        hovertemplate='Time: %{x}<br>Scenario: %{y}<br>Delta: %{z:.2f}<extra></extra>'
    ))
    
    fig.update_layout(
        title=f'Price Difference Heatmap: {scenario_group} - {country} ({timeframe.capitalize()})<br><sub>Positive = Run 1 higher, Negative = Run 2 higher</sub>',
        xaxis_title='Time',
        yaxis_title='Scenario',
        height=600,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


def create_ensemble_comparison_table(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                     timeframe: str, country: str, scenario_group: str) -> html.Div:
    """Create comparison table showing mean and median statistics by time period."""
    
    if agg1 is None or agg1.empty:
        return html.Div("No data available for Run 1", className="text-center text-muted")
    stats1 = calculate_ensemble_statistics(agg1, timeframe)
    
    # Get time column name
    time_col = stats1.columns[0]
    
    # Create base dataframe
    table_data = pd.DataFrame({
        'Time': stats1[time_col].astype(str),
        'Run 1 Mean': stats1['mean'].round(2),
        'Run 1 Median': stats1['median'].round(2),
        'Run 1 Std Dev': stats1['std'].round(2),
        'Run 1 P10': stats1['p10'].round(2),
        'Run 1 P90': stats1['p90'].round(2)
    })
    
    # Add Run 2 if available
    if agg2 is not None and not agg2.empty:
        stats2 = calculate_ensemble_statistics(agg2, timeframe)
        
        table_data['Run 2 Mean'] = stats2['mean'].round(2)
        table_data['Run 2 Median'] = stats2['median'].round(2)
        table_data['Run 2 Std Dev'] = stats2['std'].round(2)
        
        # Calculate differences (Run 1 - Run 2)
        table_data['Mean Diff'] = (stats1['mean'] - stats2['mean']).round(2)
        table_data['Mean Diff %'] = ((stats1['mean'] - stats2['mean']) / stats2['mean'] * 100).round(2)
        table_data['Median Diff'] = (stats1['median'] - stats2['median']).round(2)
        table_data['Median Diff %'] = ((stats1['median'] - stats2['median']) / stats2['median'] * 100).round(2)
    
    # Create DataTable
    table = dash_table.DataTable(
        data=table_data.to_dict('records'),
        columns=[{'name': col, 'id': col} for col in table_data.columns],
        style_table={'overflowX': 'auto'},
        style_cell={
            'textAlign': 'center',
            'padding': '8px',
            'fontSize': '12px',
            'fontFamily': 'Arial, sans-serif',
            'backgroundColor': '#22262e',
            'color': '#e0e0e0',
        },
        style_header={
            'backgroundColor': '#1e3a5f',
            'fontWeight': 'bold',
            'border': '1px solid #353a44',
            'color': '#e0e0e0',
        },
        style_data={
            'border': '1px solid #353a44',
            'backgroundColor': '#22262e',
            'color': '#e0e0e0',
        },
        style_data_conditional=[
            {'if': {'row_index': 'odd'}, 'backgroundColor': '#272b33'},
            {
                'if': {'column_id': 'Mean Diff'},
                'backgroundColor': 'rgba(77,171,247,0.1)'
            },
            {
                'if': {'column_id': 'Median Diff'},
                'backgroundColor': 'rgba(77,171,247,0.1)'
            },
            {
                'if': {
                    'filter_query': '{Mean Diff} > 0',
                    'column_id': 'Mean Diff'
                },
                'color': '#51cf66',
                'fontWeight': 'bold'
            },
            {
                'if': {
                    'filter_query': '{Mean Diff} < 0',
                    'column_id': 'Mean Diff'
                },
                'color': '#ff6b6b',
                'fontWeight': 'bold'
            },
            {
                'if': {
                    'filter_query': '{Median Diff} > 0',
                    'column_id': 'Median Diff'
                },
                'color': '#51cf66',
                'fontWeight': 'bold'
            },
            {
                'if': {
                    'filter_query': '{Median Diff} < 0',
                    'column_id': 'Median Diff'
                },
                'color': '#ff6b6b',
                'fontWeight': 'bold'
            }
        ],
        page_size=20,
        sort_action='native',
        filter_action='native'
    )
    
    return html.Div([
        html.H5(f'Statistical Comparison Table: {scenario_group} - {country} ({timeframe.capitalize()})',
               className='text-center mb-3 mt-4'),
        html.P('Green = Run 1 higher, Red = Run 2 higher', 
              className='text-center text-muted small'),
        table
    ])


# ============================================================================
# VISUALIZATION FUNCTIONS - DETERMINISTIC
# ============================================================================

def create_deterministic_line_chart(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                   timeframe: str, country: str,
                                   scenario_group: str) -> go.Figure:
    """Create line chart showing each scenario from both runs."""
    fig = go.Figure()
    
    if agg1 is None or agg1.empty:
        fig.add_annotation(text="No data available for Run 1",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    scenarios = sorted(agg1['scenario'].unique())
    colors = {'BASELINE': 'blue', 'P10': 'green', 'P90': 'purple'}
    
    # Plot Run 1
    for scenario in scenarios:
        df_scen = agg1[agg1['scenario'] == scenario].sort_values('start_time_cet')
        color = colors.get(scenario, 'gray')
        
        fig.add_trace(go.Scatter(
            x=df_scen['time_label'],
            y=df_scen['price'],
            mode='lines',
            name=f'Run 1: {scenario}',
            line=dict(color=color, width=2),
            hovertemplate=f'Run 1 - {scenario}<br>%{{x}}<br>Price: %{{y:.2f}}<extra></extra>'
        ))
    
    # Plot Run 2 if available
    if agg2 is not None and not agg2.empty:
        
        for scenario in scenarios:
            df_scen = agg2[agg2['scenario'] == scenario].sort_values('start_time_cet')
            color = colors.get(scenario, 'gray')
            
            fig.add_trace(go.Scatter(
                x=df_scen['time_label'],
                y=df_scen['price'],
                mode='lines',
                name=f'Run 2: {scenario}',
                line=dict(color=color, width=2, dash='dash'),
                hovertemplate=f'Run 2 - {scenario}<br>%{{x}}<br>Price: %{{y:.2f}}<extra></extra>'
            ))
    
    fig.update_layout(
        title=f'Scenario Comparison: {scenario_group} - {country} ({timeframe.capitalize()})',
        xaxis_title='Time',
        yaxis_title='Price',
        hovermode='x unified',
        height=600,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


def create_deterministic_bar_comparison(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                       timeframe: str, country: str, scenario_group: str) -> go.Figure:
    """Create bar chart showing price DELTAS (Run 1 - Run 2) by scenario."""
    fig = go.Figure()
    
    if agg1 is None or agg1.empty:
        fig.add_annotation(text="No data available for Run 1",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig

    if agg2 is None or agg2.empty:
        fig.add_annotation(text="Select a second run to view deltas",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    # Get all time periods
    time_labels = sorted(agg1['time_label'].unique())
    agg1 = agg1[agg1['time_label'].isin(time_labels)]
    agg2 = agg2[agg2['time_label'].isin(time_labels)]
    
    scenarios = sorted(agg1['scenario'].unique())
    
    # Create grouped bar chart of DELTAS
    for scenario in scenarios:
        df_scen1 = agg1[agg1['scenario'] == scenario].set_index('time_label')['price']
        df_scen2 = agg2[agg2['scenario'] == scenario].set_index('time_label')['price']
        
        # Align indices
        common_idx = df_scen1.index.intersection(df_scen2.index)
        if common_idx.empty:
            continue
            
        delta = df_scen1.loc[common_idx] - df_scen2.loc[common_idx]
        
        # Determine colors based on sign
        colors = ['green' if x > 0 else 'red' for x in delta.values]
        
        fig.add_trace(go.Bar(
            name=f'{scenario} Delta',
            x=common_idx,
            y=delta.values,
            marker_color=colors,
            legendgroup=scenario,
            hovertemplate=f'{scenario} Delta<br>%{{x}}<br>Diff: %{{y:.2f}}<extra></extra>'
        ))
    
    fig.update_layout(
        title=f'Price Delta (Run 1 - Run 2): {scenario_group} - {country}',
        xaxis_title='Time',
        yaxis_title='Delta (€/MWh)',
        barmode='group',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0',
        hovermode='x unified'
    )
    
    return fig


def create_deterministic_delta_chart(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                    timeframe: str, country: str, scenario_group: str) -> go.Figure:
    """Create chart showing absolute differences by time period for each scenario."""
    fig = go.Figure()
    
    if agg1 is None or agg1.empty or agg2 is None or agg2.empty:
        fig.add_annotation(text="Need data from both runs for comparison",
                          xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False)
        return fig
    
    # Get all time periods
    time_labels = sorted(agg1['time_label'].unique())
    agg1 = agg1[agg1['time_label'].isin(time_labels)]
    agg2 = agg2[agg2['time_label'].isin(time_labels)]
    
    # Pivot to get scenarios as columns
    pivot1 = agg1.pivot_table(index='time_label', columns='scenario', values='price')
    pivot2 = agg2.pivot_table(index='time_label', columns='scenario', values='price')
    
    # Calculate difference (Run 1 - Run 2)
    delta = pivot1 - pivot2
    
    scenarios = sorted(delta.columns.tolist())
    colors = {'BASELINE': 'rgb(31, 119, 180)', 'P10': 'rgb(44, 160, 44)', 'P90': 'rgb(148, 103, 189)'}
    
    # Create line chart showing delta for each scenario over time
    for scenario in scenarios:
        color = colors.get(scenario, 'gray')
        
        fig.add_trace(go.Scatter(
            name=f'{scenario} Delta',
            x=time_labels,
            y=delta[scenario],
            mode='lines+markers',
            line=dict(color=color, width=2),
            marker=dict(size=8),
            hovertemplate=f'{scenario}<br>Time: %{{x}}<br>Delta: %{{y:.2f}}<extra></extra>'
        ))
    
    # Add zero reference line
    fig.add_hline(y=0, line_dash="dash", line_color="gray", opacity=0.5)
    
    fig.update_layout(
        title=f'Price Differences by {timeframe.capitalize()} (Run 1 - Run 2): {scenario_group} - {country}<br><sub>Positive = Run 1 higher, Negative = Run 2 higher</sub>',
        xaxis_title='Time',
        yaxis_title='Price Difference',
        hovermode='x unified',
        height=500,
        template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='#e0e0e0'
    )
    
    return fig


def create_deterministic_comparison_table(agg1: pd.DataFrame, agg2: pd.DataFrame,
                                          timeframe: str, country: str, scenario_group: str) -> html.Div:
    """Create comparison table showing prices by scenario and time period."""
    
    if agg1 is None or agg1.empty:
        return html.Div("No data available for Run 1", className="text-center text-muted")
    
    # Get all time periods
    time_labels = sorted(agg1['time_label'].unique())
    agg1 = agg1[agg1['time_label'].isin(time_labels)]
    
    scenarios = sorted(agg1['scenario'].unique())
    
    # Create table data
    table_rows = []
    
    if agg2 is not None and not agg2.empty:
        agg2 = agg2[agg2['time_label'].isin(time_labels)]
        
        for time_label in time_labels:
            row = {'Time': time_label}
            
            for scenario in scenarios:
                run1_val = agg1[(agg1['time_label'] == time_label) & 
                               (agg1['scenario'] == scenario)]['price']
                run2_val = agg2[(agg2['time_label'] == time_label) & 
                               (agg2['scenario'] == scenario)]['price']
                
                if len(run1_val) > 0:
                    run1_price = run1_val.iloc[0]
                    row[f'{scenario} Run1'] = round(run1_price, 2)
                    
                    if len(run2_val) > 0:
                        run2_price = run2_val.iloc[0]
                        row[f'{scenario} Run2'] = round(run2_price, 2)
                        diff = run1_price - run2_price
                        row[f'{scenario} Diff'] = round(diff, 2)
                        if run2_price != 0:
                            row[f'{scenario} Diff %'] = round((diff / run2_price * 100), 2)
                        else:
                            row[f'{scenario} Diff %'] = 0.0
            
            table_rows.append(row)
    else:
        # Only Run 1 data
        for time_label in time_labels:
            row = {'Time': time_label}
            
            for scenario in scenarios:
                run1_val = agg1[(agg1['time_label'] == time_label) & 
                               (agg1['scenario'] == scenario)]['price']
                
                if len(run1_val) > 0:
                    row[f'{scenario} Run1'] = round(run1_val.iloc[0], 2)
            
            table_rows.append(row)
    
    table_df = pd.DataFrame(table_rows)
    
    # Create conditional styling for difference columns
    style_conditions = []
    for scenario in scenarios:
        diff_col = f'{scenario} Diff'
        if diff_col in table_df.columns:
            style_conditions.extend([
                {
                    'if': {
                        'filter_query': f'{{{diff_col}}} > 0',
                        'column_id': diff_col
                    },
                    'color': '#51cf66',
                    'fontWeight': 'bold'
                },
                {
                    'if': {
                        'filter_query': f'{{{diff_col}}} < 0',
                        'column_id': diff_col
                    },
                    'color': '#ff6b6b',
                    'fontWeight': 'bold'
                },
                {
                    'if': {'column_id': diff_col},
                    'backgroundColor': 'rgba(77,171,247,0.1)'
                }
            ])
    
    # Create DataTable
    table = dash_table.DataTable(
        data=table_df.to_dict('records'),
        columns=[{'name': col, 'id': col} for col in table_df.columns],
        style_table={'overflowX': 'auto'},
        style_cell={
            'textAlign': 'center',
            'padding': '8px',
            'fontSize': '11px',
            'fontFamily': 'Arial, sans-serif',
            'minWidth': '80px',
            'backgroundColor': '#22262e',
            'color': '#e0e0e0',
        },
        style_header={
            'backgroundColor': '#1e3a5f',
            'fontWeight': 'bold',
            'border': '1px solid #353a44',
            'color': '#e0e0e0',
            'whiteSpace': 'normal',
            'height': 'auto'
        },
        style_data={
            'border': '1px solid #353a44',
            'backgroundColor': '#22262e',
            'color': '#e0e0e0',
        },
        style_data_conditional=style_conditions,
        page_size=20,
        sort_action='native',
        filter_action='native'
    )
    
    return html.Div([
        html.H5(f'Price Comparison Table: {scenario_group} - {country} ({timeframe.capitalize()})',
               className='text-center mb-3 mt-4'),
        html.P('Green = Run 1 higher, Red = Run 2 higher', 
              className='text-center text-muted small'),
        table
    ])


# ============================================================================
# LAYOUT
# ============================================================================

def get_layout():
    return dbc.Container([
        dbc.Row([
            dbc.Col(html.H2("Power Stack Price Comparison", className="text-center mb-4"), width=12)
        ]),
        
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("Run Selection"),
                    dbc.CardBody([
                        dbc.Row([
                            dbc.Col([
                                html.Label("Scenario Group"),
                                dcc.Dropdown(
                                    id='scenario-group-dropdown',
                                    options=[
                                        {'label': 'Ensemble Medium', 'value': 'ENS_MEDIUM'},
                                        {'label': 'Ensemble Extended', 'value': 'ENS_EXTENDED'},
                                        {'label': 'Basecase', 'value': 'BASECASE'},
                                        {'label': 'Deterministic', 'value': 'DETERMINISTIC'}
                                    ],
                                    value='ENS_MEDIUM',
                                    clearable=False
                                )
                            ], width=3),
                            dbc.Col([
                                html.Label("Country"),
                                dcc.Dropdown(
                                    id='country-dropdown',
                                    options=[{'label': c, 'value': c} for c in DEFAULT_COUNTRIES],
                                    value='DE',
                                    clearable=False
                                )
                            ], width=2),
                            dbc.Col([
                                html.Label("Timeframe"),
                                dcc.Dropdown(
                                    id='timeframe-dropdown',
                                    options=[
                                        {'label': 'Hourly', 'value': 'hourly'},
                                        {'label': 'Day-Ahead', 'value': 'day_ahead'},
                                        {'label': 'Daily', 'value': 'daily'},
                                        {'label': 'Weekly', 'value': 'weekly'},
                                        {'label': 'Monthly', 'value': 'monthly'},
                                        {'label': 'Quarterly', 'value': 'quarterly'},
                                        {'label': 'Annual', 'value': 'annual'},
                                        {'label': 'Trader View (Products)', 'value': 'trader'}
                                    ],
                                    value='daily',
                                    clearable=False
                                )
                            ], width=2),
                            dbc.Col([
                                html.Label("View Options"),
                                dbc.Checklist(
                                    options=[
                                        {"label": "Show Ensemble Members", "value": "show_members"},
                                    ],
                                    value=["show_members"],
                                    id="view-options-checklist",
                                    switch=True,
                                ),
                            ], width=3),
                            dbc.Col([
                                dbc.Button("Refresh Runs", id="refresh-btn", color="secondary", size="sm", className="mt-4")
                            ], width=2)
                        ]),
                        
                        dbc.Row([
                            dbc.Col([
                                html.Label("Run 1 (Baseline)"),
                                dcc.Dropdown(
                                    id='run1-dropdown',
                                    options=[],
                                    placeholder="Select first run...",
                                    clearable=False
                                )
                            ], width=6),
                            dbc.Col([
                                html.Label("Run 2 (Comparison)"),
                                dcc.Dropdown(
                                    id='run2-dropdown',
                                    options=[],
                                    placeholder="Select second run (optional)...",
                                    clearable=True
                                )
                            ], width=6)
                        ], className="mt-3"),
                        
                        # Day Ahead Controls (Only visible for Hourly/Trader)
                        dbc.Row([
                            dbc.Col([
                                html.Div(id='day-ahead-controls', children=[
                                    html.Hr(),
                                    html.Label("Day Ahead Filter (Optional)"),
                                    dcc.DatePickerSingle(
                                        id='da-date-picker',
                                        min_date_allowed=datetime(2023, 1, 1),
                                        max_date_allowed=datetime(2025, 12, 31),
                                        initial_visible_month=datetime.now(),
                                        date=(datetime.now() + pd.Timedelta(days=1)).date(),
                                        placeholder="Select Date"
                                    ),
                                    dbc.FormText("Filter to specific delivery day")
                                ], style={'display': 'none'})
                            ], width=12)
                        ])
                    ])
                ], className="mb-4")
            ], width=12)
        ]),
        
        # Tabs for different views
        dbc.Tabs(id="tabs", active_tab="tab-charts", children=[
            dbc.Tab(label="Charts & Analysis", tab_id="tab-charts"),
            dbc.Tab(label="Raw Data", tab_id="tab-data", disabled=True),
        ]),
        
        html.Div(id='stack-prices-content', className="mt-4"),
        
        # Hidden stores
        dcc.Store(id='run-times-store'),
        dcc.Interval(id='interval-component', interval=300*1000, n_intervals=0, disabled=True),
    ], fluid=True)


# ============================================================================
# CALLBACKS
# ============================================================================

def register_stack_prices_callbacks(app):
    
    @app.callback(
        [Output('run1-dropdown', 'options'),
         Output('run2-dropdown', 'options'),
         Output('country-dropdown', 'options')],
        [Input('refresh-btn', 'n_clicks'),
         Input('interval-component', 'n_intervals')],
    )
    def refresh_run_times(n_clicks, n_intervals):
        ctx = dash.callback_context
        trigger = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else None
        if trigger == 'refresh-btn' and n_clicks:
            clear_all()
            data_cache.clear()
            logger.info("Run comparison: manual refresh — all caches cleared")

        options = get_available_run_times()
        countries = get_available_countries()
        country_opts = [{'label': c, 'value': c} for c in countries]
        return options, options, country_opts

    # 2. Toggle Day Ahead Controls
    @app.callback(
        [Output('day-ahead-controls', 'style'),
         Output('da-date-picker', 'date')],
        Input('timeframe-dropdown', 'value')
    )
    def toggle_day_ahead_controls(timeframe):
        if timeframe == 'day_ahead':
            return {'display': 'block'}, (datetime.now() + pd.Timedelta(days=1)).date()
        elif timeframe in ['hourly', 'trader']:
            return {'display': 'block'}, None
        return {'display': 'none'}, None

    # 3. Update Available Tabs (Placeholder for future logic)
    @app.callback(
        Output('tabs', 'children'),
        Input('scenario-group-dropdown', 'value')
    )
    def update_available_tabs(scenario_group):
        return [
            dbc.Tab(label="Charts & Analysis", tab_id="tab-charts"),
            dbc.Tab(label="Raw Data", tab_id="tab-data", disabled=True),
        ]

    # 4. Main Update Callback
    @app.callback(
        [Output('stack-prices-content', 'children'),
         Output('run-times-store', 'data')],
        [Input('run1-dropdown', 'value'),
         Input('run2-dropdown', 'value'),
         Input('timeframe-dropdown', 'value'),
         Input('country-dropdown', 'value'),
         Input('scenario-group-dropdown', 'value'),
         Input('da-date-picker', 'date'),
         Input('view-options-checklist', 'value')]
    )
    def update_charts(run1, run2, timeframe, country, scenario_group, da_date, view_options):
        if not run1:
            return html.Div("Please select at least Run 1 to view data.", className="text-center text-muted"), ""
        
        # Parse view options
        show_members = "show_members" in (view_options or [])
        
        try:
            # Fetch Data
            countries = [country]
            
            # Fetch Run 1
            data1 = fetch_run_data(run1, countries, scenario_group)
            df1 = data1.get(country)
            
            # Fetch Run 2
            df2 = None
            if run2:
                data2 = fetch_run_data(run2, countries, scenario_group)
                df2 = data2.get(country)
            
            if df1 is None or df1.empty:
                return html.Div("No data found for Run 1.", className="text-center text-warning"), ""

            # Apply Day Ahead Filter if applicable
            if da_date and timeframe in ['hourly', 'trader', 'day_ahead']:
                target_date = pd.to_datetime(da_date).date()
                df1 = df1[df1['date_cet'] == target_date]
                if df2 is not None:
                    df2 = df2[df2['date_cet'] == target_date]
                    
                if df1.empty:
                    return html.Div(f"No data found for date {da_date}", className="text-center text-warning"), ""

            # Aggregate Data
            if timeframe == 'trader':
                # Map to products
                agg1 = map_to_products(df1)
                agg2 = map_to_products(df2) if df2 is not None else None
            else:
                agg1 = aggregate_to_timeframe(df1, timeframe)
                agg2 = aggregate_to_timeframe(df2, timeframe) if df2 is not None else None

            # Generate Charts based on View
            charts = []
            
            if timeframe == 'trader':
                # Trader View (Forward Curves)
                
                # 1. Forward Curve
                charts.append(dbc.Row([
                    dbc.Col([
                        dcc.Graph(figure=create_forward_curve_plot(agg1, agg2, country, scenario_group))
                    ], width=12)
                ]))
                
                # 2. Volatility/Spread Change (Ensemble only)
                if scenario_group in ['ENS_MEDIUM', 'ENS_EXTENDED']:
                    charts.append(dbc.Row([
                        dbc.Col([
                            dcc.Graph(figure=create_volatility_change_plot(agg1, agg2, country, scenario_group))
                        ], width=12)
                    ]))
                
                # 3. Time Spreads
                charts.append(dbc.Row([
                    dbc.Col([
                        dcc.Graph(figure=create_time_spread_plot(agg1, country, scenario_group))
                    ], width=12)
                ]))
                
                # 4. Cross Border Spreads
                try:
                    # Determine neighbors (fetch all available)
                    all_countries = get_available_countries()
                    neighbor_countries = [c for c in all_countries if c != country][:5] # Limit to 5
                    
                    # Batch fetch neighbors
                    neighbor_dfs = fetch_run_data(run1, neighbor_countries, scenario_group)
                    
                    # Map neighbors to products
                    neighbor_prods = {}
                    for nc, ndf in neighbor_dfs.items():
                        if ndf is not None and not ndf.empty:
                            neighbor_prods[nc] = map_to_products(ndf)
                            
                    charts.append(dbc.Row([
                        dbc.Col([
                            dcc.Graph(figure=create_cross_border_spread_plot(agg1, neighbor_prods, country, scenario_group))
                        ], width=12)
                    ]))
                except Exception as e:
                    logger.error(f"Error generating cross-border plot: {e}")
                
                return html.Div(charts), ""

            # Standard Time Series Views
            if scenario_group in ['ENS_MEDIUM', 'ENS_EXTENDED']:
                # Ensemble
                use_pdc = timeframe == 'annual' # Use PDC for annual view by default? Or maybe add a toggle.
                # For now, let's show Spaghetti for time series, and PDC/Violin below
                
                charts = html.Div([
                    dbc.Row([
                        dbc.Col([
                            dcc.Graph(
                                figure=create_ensemble_spaghetti_plot(
                                    agg1, agg2, timeframe, country, scenario_group, show_members=show_members
                                )
                            )
                        ], width=12)
                    ]),
                    dbc.Row([
                        dbc.Col([
                            dcc.Graph(
                                figure=create_ensemble_delta_heatmap(
                                    agg1, agg2, timeframe, country, scenario_group
                                )
                            )
                        ], width=12)
                    ]),
                    dbc.Row([
                        dbc.Col([
                            dcc.Graph(
                                figure=create_price_duration_curve(
                                    agg1, agg2, timeframe, country, scenario_group
                                ) if use_pdc else create_ensemble_violin_plot(
                                    agg1, agg2, timeframe, country, scenario_group
                                )
                            )
                        ], width=12)
                    ]),
                    dbc.Row([
                        dbc.Col([
                            create_ensemble_comparison_table(
                                agg1, agg2, timeframe, country, scenario_group
                            )
                        ], width=12)
                    ]) if timeframe not in ['hourly', 'day_ahead'] else None
                ])
            else:
                # Deterministic
                charts = html.Div([
                    dbc.Row([
                        dbc.Col([
                            dcc.Graph(
                                figure=create_deterministic_line_chart(
                                    agg1, agg2, timeframe, country, scenario_group
                                )
                            )
                        ], width=12)
                    ]),
                    dbc.Row([
                        dbc.Col([
                            dcc.Graph(
                                figure=create_deterministic_bar_comparison(
                                    agg1, agg2, timeframe, country, scenario_group
                                )
                            )
                        ], width=12)
                    ]),
                    dbc.Row([
                        dbc.Col([
                            dcc.Graph(
                                figure=create_deterministic_delta_chart(
                                    agg1, agg2, timeframe, country, scenario_group
                                )
                            )
                        ], width=12)
                    ]),
                    dbc.Row([
                        dbc.Col([
                            create_deterministic_comparison_table(
                                agg1, agg2, timeframe, country, scenario_group
                            )
                        ], width=12)
                    ]) if timeframe not in ['hourly', 'day_ahead'] else None
                ])
            
            run1_label = pd.to_datetime(run1).strftime('%Y-%m-%d %H:%M')
            run2_label = pd.to_datetime(run2).strftime('%Y-%m-%d %H:%M') if run2 else 'N/A'
            status_msg = html.Div([
                html.Span(f"Comparing: ", className="fw-bold"),
                html.Span(f"Run 1 ({run1_label}) vs Run 2 ({run2_label}) | "),
                html.Span(f"Timeframe: {timeframe.capitalize()}")
            ])
        
            return charts, status_msg
        
        except Exception as e:
            logger.error(f"Error updating charts: {e}", exc_info=True)
            return html.Div(f"Error updating charts: {e}", className="text-center text-danger"), ""


