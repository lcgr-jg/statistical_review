"""Confirm the Met Run Deltas tab now renders from the real S3 store."""
from portal_pages.fundamentals import met_run_deltas as mrd
from portal_pages.fundamentals import met_run_store as store

print("runs in store  :", store.list_runs("AIFS-ENS"))
latest, previous = store.latest_run_pair("AIFS-ENS")
print("latest/previous:", latest, "vs", previous)
print("countries      :", store.available_countries("AIFS-ENS"))
print("labels         :", store.format_run_key(latest), "|", store.format_run_key(previous))

delta = store.compute_delta("AIFS-ENS", latest, previous)
print("\ndelta rows     :", 0 if delta is None else len(delta))
if delta is not None and not delta.empty:
    d = delta[delta["variable"] == "cwg"]
    print("lead range     :", int(d.lead_hours.min()), "-", int(d.lead_hours.max()), "h")
    print("\nrun-over-run temperature change by country (mean / min / max, degC):")
    g = d.groupby("country")["delta"].agg(["mean", "min", "max"]).round(2)
    for c, r in g.iterrows():
        print(f"   {c:12s} {r['mean']:+6.2f}   {r['min']:+6.2f}  {r['max']:+6.2f}")
    print("\nlargest single move:")
    row = d.loc[d["delta"].abs().idxmax()]
    print(f"   {row['country']} at +{int(row['lead_hours'])}h: "
          f"{row['previous']:.2f} -> {row['latest']:.2f} degC "
          f"({row['delta']:+.2f}, z={row['z_score']:+.2f})")

countries = store.available_countries("AIFS-ENS")[:4]
f1 = mrd.build_delta_figure(delta, "cwg", countries)
f2 = mrd.build_conviction_heatmap(delta, "cwg", countries, "AIFS-ENS")
f3 = mrd.build_levels_figure(store.load_run("AIFS-ENS", latest),
                             store.load_run("AIFS-ENS", previous),
                             "cwg", countries[0], latest, previous)
hist = store.revision_history("AIFS-ENS", countries[0], "cwg")
f4 = mrd.build_revision_figure(hist, "cwg", countries[0])
summary = mrd.build_summary(delta, "cwg", countries, "AIFS-ENS")

print("\nfigures:")
print("   delta     :", len(f1.data), "traces")
print("   heatmap   :", len(f2.data), "traces")
print("   levels    :", len(f3.data), "traces")
print("   revisions :", len(f4.data), "traces")
print("   summary   :", len(summary.children), "tiles")

fw = mrd.build_delta_figure(delta, "cww", countries)
msg = fw.layout.annotations[0].text if fw.layout.annotations else None
print("   wind      :", len(fw.data), "traces |", repr(msg))

print("\nstore status:")
for s in store.store_status():
    print(f"   {s['label']:22s} runs={s['n_runs']} latest={s['latest_run']}")
