"""Portal-owned page code.

This package contains the portal's own copies of dashboard code so that
`portal_app.py` and the top-level `pages/*.py` registrations never reach
into the standalone `fundamental_dashboard/`, `price_dashboard/`, or
`stack_dashboard/` packages.

Keeping portal and standalone code paths disjoint means the standalone
apps can evolve (e.g. on feature branches) without colliding with the
portal at merge time.
"""
