"""
Forecast Comparison
───────────────────
Chart-based forecast-on-forecast comparison. For each (variable, zone)
combination the user selects, renders an hourly timeseries with:

  - two lines:   forecast run (today) and reference run (yesterday), MW
  - shaded band: Δ MW (forecast - reference) on a secondary y-axis

Data source: same S3-cached EQ forecast parquet used by the Forecast
Monitor page (portal_pages.fundamentals.forecast_data_handler.load_forecast).

Grid layout: rows = Variable (Wind / Solar / Demand / Residual Load),
cols = Zone. Chart cards wrap responsively.

This page intentionally mirrors the Forecast Monitor's controls (same
Model / Date / Run button / status badge + toast pipeline) so a user
flipping between the tabs keeps the same mental model.
"""

from __future__ import annotations

import datetime
import logging
import uuid
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import html, dcc, Input, Output, State, callback_context, no_update
import dash_bootstrap_components as dbc

logger = logging.getLogger(__name__)

try:
    from portal_pages.fundamentals.styles import COLORS
except ImportError:
    COLORS = {
        'bg': '#faf9f6', 'card_bg': '#ffffff', 'text_primary': '#2c3e50',
        'text_secondary': '#555', 'accent': '#4E738A', 'border': '#e8e6e1',
    }

from portal_pages.fundamentals.forecast_data_handler import (
    MODEL_CONFIGS,
    DEFAULT_ZONES,
    ALL_VARIABLES,
    CACHE_AVAILABLE,
    load_forecast,
    check_and_download_forecast,
)

try:
    from core.toast_manager import make_toast
except ImportError:
    def make_toast(msg, level='info', source=None):
        return {
            'id': str(uuid.uuid4()),
            'message': msg,
            'level': level,
            'source': source or '',
            'timestamp': '',
        }


_ACCENT = COLORS.get('accent', '#4E738A')
_FCST_COLOR = '#2E86AB'
_REF_COLOR = '#8A8A8A'
_DELTA_POS = 'rgba(46, 134, 171, 0.28)'
_DELTA_NEG = 'rgba(200, 75, 75, 0.28)'

# Always show both ST (00z/12z) and MT (EXT) options; same set as Forecast Monitor.
_MODEL_OPTIONS = [{'label': m, 'value': m} for m in MODEL_CONFIGS.keys()]

_LABEL_STYLE = {
    'fontSize': '11px',
    'fontWeight': '600',
    'color': '#666',
    'textTransform': 'uppercase',
    'letterSpacing': '0.5px',
    'marginBottom': '6px',
    'display': 'block',
}


# ═══════════════════════════════════════════════════════════════════════════
# Layout
# ═══════════════════════════════════════════════════════════════════════════

def get_layout(data_handler=None, **kwargs):
    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=1)

    return html.Div(
        style={'padding': '0'},
        children=[
            html.Div(
                style={
                    'backgroundColor': '#ffffff',
                    'padding': '18px 28px',
                    'borderBottom': '1px solid #e1e4e8',
                    'display': 'flex',
                    'flexWrap': 'wrap',
                    'gap': '24px',
                    'alignItems': 'flex-end',
                },
                children=[
                    html.Div([
                        html.Label("Variables", style=_LABEL_STYLE),
                        dcc.Checklist(
                            id='fcmp-variables',
                            options=[{'label': v, 'value': v} for v in ALL_VARIABLES],
                            value=ALL_VARIABLES,
                            inline=True,
                            style={'fontSize': '13px'},
                            inputStyle={'marginRight': '4px'},
                            labelStyle={'marginRight': '14px', 'cursor': 'pointer'},
                        ),
                    ]),
                    html.Div([
                        html.Label("Zones", style=_LABEL_STYLE),
                        dcc.Dropdown(
                            id='fcmp-zones',
                            options=[{'label': z, 'value': z} for z in DEFAULT_ZONES],
                            value=['DE', 'FR', 'GB'],
                            multi=True,
                            clearable=False,
                            style={'minWidth': '260px', 'fontSize': '13px'},
                        ),
                    ]),
                    html.Div([
                        html.Label("Model", style=_LABEL_STYLE),
                        dcc.Dropdown(
                            id='fcmp-model-select',
                            options=_MODEL_OPTIONS,
                            value='EC-ENS 00z' if any(
                                o['value'] == 'EC-ENS 00z' for o in _MODEL_OPTIONS
                            ) else (_MODEL_OPTIONS[0]['value'] if _MODEL_OPTIONS else None),
                            clearable=False,
                            style={'width': '170px', 'fontSize': '13px'},
                        ),
                    ]),
                    html.Div([
                        html.Label("Forecast Date", style=_LABEL_STYLE),
                        dcc.DatePickerSingle(
                            id='fcmp-today-date',
                            date=today,
                            display_format='YYYY-MM-DD',
                            style={'fontSize': '13px'},
                        ),
                    ]),
                    html.Div([
                        html.Label("Reference Date", style=_LABEL_STYLE),
                        dcc.DatePickerSingle(
                            id='fcmp-ref-date',
                            date=yesterday,
                            display_format='YYYY-MM-DD',
                            style={'fontSize': '13px'},
                        ),
                    ]),
                    html.Div([
                        html.Label("Δ band", style=_LABEL_STYLE),
                        dcc.RadioItems(
                            id='fcmp-delta-mode',
                            options=[
                                {'label': 'Show', 'value': 'show'},
                                {'label': 'Hide', 'value': 'hide'},
                            ],
                            value='show',
                            inline=True,
                            style={'fontSize': '13px'},
                            inputStyle={'marginRight': '4px'},
                            labelStyle={'marginRight': '14px', 'cursor': 'pointer'},
                        ),
                    ]),
                    html.Button(
                        "Run",
                        id='fcmp-run-btn',
                        n_clicks=0,
                        title="Load forecasts from S3 cache (fetches missing runs from EQ)",
                        style={
                            'padding': '8px 24px',
                            'backgroundColor': _ACCENT,
                            'color': 'white',
                            'border': 'none',
                            'borderRadius': '6px',
                            'cursor': 'pointer',
                            'fontWeight': '600',
                            'fontSize': '13px',
                        },
                    ),
                    html.Div(
                        id='fcmp-status-badge',
                        style={
                            'fontSize': '12px',
                            'color': '#666',
                            'backgroundColor': '#f4f5f7',
                            'padding': '8px 14px',
                            'borderRadius': '6px',
                            'border': '1px solid #e1e4e8',
                            'alignSelf': 'center',
                        },
                    ),
                ],
            ),
            dcc.Loading(
                id='fcmp-loading',
                type='default',
                color=_ACCENT,
                children=[
                    html.Div(
                        id='fcmp-charts-container',
                        style={'padding': '20px 28px', 'minHeight': '300px'},
                    ),
                ],
            ),
        ],
    )


# ═══════════════════════════════════════════════════════════════════════════
# Chart builder
# ═══════════════════════════════════════════════════════════════════════════

# Sensible y-axis label per variable (all values are MW at hourly resolution
# in the underlying parquet).
_VAR_UNITS = {
    'Wind': 'MW', 'Solar': 'MW', 'Demand': 'MW', 'Residual Load': 'MW',
}


def _forecast_dataframes(
    variable: str,
    zone: str,
    model_name: str,
    today_date: datetime.date,
    ref_date: datetime.date,
) -> Tuple[Optional[pd.Series], Optional[pd.Series]]:
    """Load the forecast and reference series for one (variable, zone)."""
    try:
        fcst_df = load_forecast(variable, model_name, today_date, [zone])
    except Exception as exc:
        logger.warning(f"load_forecast failed {variable}/{zone}/today: {exc}")
        fcst_df = None
    try:
        ref_df = load_forecast(variable, model_name, ref_date, [zone])
    except Exception as exc:
        logger.warning(f"load_forecast failed {variable}/{zone}/ref: {exc}")
        ref_df = None

    fcst_s = fcst_df[zone] if fcst_df is not None and zone in fcst_df.columns else None
    ref_s = ref_df[zone] if ref_df is not None and zone in ref_df.columns else None
    return fcst_s, ref_s


def _chart_card(
    variable: str,
    zone: str,
    model_name: str,
    today_date: datetime.date,
    ref_date: datetime.date,
    show_delta: bool,
) -> html.Div:
    fcst, ref = _forecast_dataframes(variable, zone, model_name, today_date, ref_date)

    if fcst is None and ref is None:
        return _empty_card(
            f"{variable} · {zone}",
            f"No S3 data for {model_name} on {today_date} or {ref_date}",
        )

    fig = go.Figure()

    if fcst is not None:
        fig.add_trace(go.Scatter(
            x=fcst.index, y=fcst.values,
            mode='lines', name=f"{today_date:%b-%d}",
            line=dict(color=_FCST_COLOR, width=2),
            hovertemplate='<b>%{x|%Y-%m-%d %H:%M}</b><br>Forecast: %{y:.0f} MW<extra></extra>',
        ))
    if ref is not None:
        fig.add_trace(go.Scatter(
            x=ref.index, y=ref.values,
            mode='lines', name=f"{ref_date:%b-%d}",
            line=dict(color=_REF_COLOR, width=1.6, dash='dot'),
            hovertemplate='<b>%{x|%Y-%m-%d %H:%M}</b><br>Reference: %{y:.0f} MW<extra></extra>',
        ))

    delta_stats = {'max_abs': 0.0, 'mean': 0.0, 'mean_pct': 0.0}
    if show_delta and fcst is not None and ref is not None:
        common_idx = fcst.index.intersection(ref.index)
        if len(common_idx) > 0:
            diff = (fcst.reindex(common_idx) - ref.reindex(common_idx)).astype(float)
            ref_aligned = ref.reindex(common_idx).astype(float)
            with np.errstate(divide='ignore', invalid='ignore'):
                pct = np.where(
                    np.abs(ref_aligned.values) > 1e-3,
                    100.0 * diff.values / ref_aligned.values,
                    np.nan,
                )
            pos = diff.where(diff >= 0).fillna(0.0)
            neg = diff.where(diff < 0).fillna(0.0)
            fig.add_trace(go.Scatter(
                x=diff.index, y=pos.values,
                mode='lines', name='Δ ≥ 0',
                line=dict(color='rgba(0,0,0,0)'),
                fill='tozeroy', fillcolor=_DELTA_POS,
                yaxis='y2',
                hovertemplate='Δ: +%{y:.0f} MW<extra></extra>',
                showlegend=False,
            ))
            fig.add_trace(go.Scatter(
                x=diff.index, y=neg.values,
                mode='lines', name='Δ < 0',
                line=dict(color='rgba(0,0,0,0)'),
                fill='tozeroy', fillcolor=_DELTA_NEG,
                yaxis='y2',
                hovertemplate='Δ: %{y:.0f} MW<extra></extra>',
                showlegend=False,
            ))
            delta_stats['max_abs'] = float(np.nanmax(np.abs(diff.values))) if len(diff) else 0.0
            delta_stats['mean'] = float(np.nanmean(diff.values)) if len(diff) else 0.0
            finite_pct = pct[np.isfinite(pct)]
            delta_stats['mean_pct'] = float(np.nanmean(finite_pct)) if finite_pct.size else 0.0

    _style_figure(fig, _VAR_UNITS.get(variable, 'MW'), show_delta)

    return html.Div(
        style={
            'backgroundColor': '#ffffff',
            'borderRadius': '10px',
            'border': '1px solid #e1e4e8',
            'overflow': 'hidden',
            'boxShadow': '0 2px 6px rgba(0,0,0,0.06)',
            'display': 'flex',
            'flexDirection': 'column',
        },
        children=[
            html.Div(
                style={
                    'padding': '10px 14px',
                    'backgroundColor': '#f8f9fa',
                    'borderBottom': '1px solid #eaecef',
                    'display': 'flex',
                    'justifyContent': 'space-between',
                    'alignItems': 'center',
                    'gap': '12px',
                },
                children=[
                    html.Span(
                        f"{variable} · {zone}",
                        style={
                            'fontWeight': '600',
                            'fontSize': '13px',
                            'color': COLORS.get('text_primary', '#2c3e50'),
                            'letterSpacing': '0.2px',
                        },
                    ),
                    _delta_pill(delta_stats) if show_delta else html.Span(''),
                ],
            ),
            dcc.Graph(
                figure=fig,
                config={'displayModeBar': False, 'responsive': True},
                style={'height': '260px'},
            ),
        ],
    )


def _style_figure(fig: go.Figure, unit: str, show_delta: bool) -> None:
    fig.update_layout(
        template='plotly_white',
        margin=dict(l=10, r=10, t=10, b=30),
        paper_bgcolor='#ffffff',
        plot_bgcolor='#ffffff',
        showlegend=True,
        legend=dict(
            orientation='h',
            yanchor='bottom', y=1.02,
            xanchor='right', x=1.0,
            font=dict(size=11),
        ),
        xaxis=dict(
            showgrid=True, gridcolor='#f0f1f3',
            zeroline=False, showline=False,
            rangeslider=dict(visible=False),
            type='date',
        ),
        yaxis=dict(
            title=dict(text=unit, font=dict(size=11, color='#666')),
            showgrid=True, gridcolor='#f0f1f3',
            zeroline=False,
            tickfont=dict(size=11, color='#666'),
        ),
        hovermode='x unified',
    )
    if show_delta:
        fig.update_layout(
            yaxis2=dict(
                title=dict(text=f'Δ {unit}', font=dict(size=11, color='#888')),
                overlaying='y', side='right',
                showgrid=False, zeroline=True, zerolinecolor='#d0d0d0',
                tickfont=dict(size=11, color='#888'),
            ),
        )


def _delta_pill(stats: dict) -> html.Span:
    max_abs = stats.get('max_abs', 0.0) or 0.0
    mean = stats.get('mean', 0.0) or 0.0
    mean_pct = stats.get('mean_pct', 0.0) or 0.0
    if max_abs >= 500:
        bg, fg = '#fde2e1', '#9c2b28'
    elif max_abs >= 100:
        bg, fg = '#fff4d6', '#7a5200'
    else:
        bg, fg = '#e3f1e3', '#265c26'
    sign = '+' if mean >= 0 else ''
    return html.Span(
        f"Δ̄ {sign}{mean:,.0f} MW  ({sign}{mean_pct:,.1f}%)  |  max |Δ| {max_abs:,.0f}",
        style={
            'fontSize': '11px',
            'fontWeight': '600',
            'padding': '4px 10px',
            'borderRadius': '999px',
            'backgroundColor': bg,
            'color': fg,
            'letterSpacing': '0.2px',
        },
    )


def _empty_card(title: str, msg: str) -> html.Div:
    return html.Div(
        style={
            'backgroundColor': '#ffffff',
            'borderRadius': '10px',
            'border': '1px dashed #e1e4e8',
            'padding': '16px 18px',
            'color': '#999',
        },
        children=[
            html.Div(
                title,
                style={
                    'fontWeight': '600',
                    'fontSize': '13px',
                    'color': COLORS.get('text_primary', '#2c3e50'),
                    'marginBottom': '6px',
                },
            ),
            html.Div(
                msg,
                style={'fontSize': '12px', 'fontStyle': 'italic'},
            ),
        ],
    )


def _empty_msg(text: str) -> html.Div:
    return html.Div(
        text,
        style={
            'textAlign': 'center',
            'padding': '60px',
            'color': '#888',
            'fontSize': '15px',
            'fontStyle': 'italic',
        },
    )


def _parse_date(s) -> Optional[datetime.date]:
    if s is None:
        return None
    if isinstance(s, datetime.date):
        return s
    try:
        return datetime.date.fromisoformat(str(s)[:10])
    except Exception:
        return None


def _build_grid(cards_by_variable: dict, variables: List[str], zones: List[str]) -> html.Div:
    # rows = variable, cols = zone
    rows: list = []
    for variable in variables:
        row_children = [
            html.Div(
                variable,
                style={
                    'writingMode': 'vertical-rl',
                    'transform': 'rotate(180deg)',
                    'fontSize': '11px',
                    'fontWeight': '600',
                    'letterSpacing': '0.5px',
                    'textTransform': 'uppercase',
                    'color': '#666',
                    'padding': '8px 4px',
                    'alignSelf': 'stretch',
                    'display': 'flex',
                    'alignItems': 'center',
                    'justifyContent': 'center',
                    'minWidth': '28px',
                    'borderRight': '1px solid #eee',
                    'marginRight': '10px',
                },
            ),
        ]
        for zone in zones:
            card = cards_by_variable.get(variable, {}).get(zone)
            if card is None:
                card = _empty_card(f"{variable} · {zone}", "No data")
            row_children.append(
                html.Div(
                    card,
                    style={
                        'flex': '1 1 360px',
                        'minWidth': '320px',
                        'maxWidth': '720px',
                    },
                )
            )
        rows.append(
            html.Div(
                style={
                    'display': 'flex',
                    'gap': '16px',
                    'marginBottom': '20px',
                    'flexWrap': 'wrap',
                    'alignItems': 'stretch',
                },
                children=row_children,
            )
        )
    return html.Div(rows)


# ═══════════════════════════════════════════════════════════════════════════
# Callbacks
# ═══════════════════════════════════════════════════════════════════════════

def register_forecast_comparison_callbacks(app, data_handler=None):
    """Register callbacks for the Forecast Comparison page."""

    @app.callback(
        [Output('fcmp-charts-container', 'children'),
         Output('fcmp-status-badge', 'children'),
         Output('fcst-toast-store', 'data', allow_duplicate=True)],
        [Input('fcmp-run-btn', 'n_clicks'),
         Input('fcmp-model-select', 'value'),
         Input('fcmp-variables', 'value'),
         Input('fcmp-zones', 'value'),
         Input('fcmp-today-date', 'date'),
         Input('fcmp-ref-date', 'date'),
         Input('fcmp-delta-mode', 'value')],
        prevent_initial_call='initial_duplicate',
    )
    def run_comparison(n_clicks, model, variables, zones, today_str, ref_str, delta_mode):
        toasts = []

        if not CACHE_AVAILABLE:
            toasts.append(make_toast(
                "Forecast cache classes not available (jain_commods not installed?).",
                level='error', source='Forecast Comparison',
            ))
            return _empty_msg("Forecast cache classes not available."), "Cache unavailable", toasts

        if not model:
            return _empty_msg("Select a model and click Run."), "", toasts
        if not variables:
            return _empty_msg("Select at least one variable."), "", toasts
        if not zones:
            return _empty_msg("Select at least one zone."), "", toasts

        today_date = _parse_date(today_str)
        ref_date = _parse_date(ref_str)
        if today_date is None or ref_date is None:
            return _empty_msg("Invalid date selection."), "", toasts
        if today_date == ref_date:
            toasts.append(make_toast(
                "Forecast and Reference dates are the same; Δ will be zero.",
                level='warning', source='Forecast Comparison',
            ))

        show_delta = (delta_mode == 'show')

        status_parts = []
        total_errors: List[str] = []
        for issue in (today_date, ref_date):
            loaded, downloaded, errors = check_and_download_forecast(
                model_name=model,
                issue_date=issue,
                zones=zones,
                variables=variables,
            )
            if downloaded:
                status_parts.append(f"{downloaded} downloaded ({issue:%b-%d})")
            if loaded:
                status_parts.append(f"{loaded} cached ({issue:%b-%d})")
            total_errors.extend(errors)

        for err in total_errors:
            toasts.append(make_toast(
                f"Data load failed: {err}",
                level='error', source=f'Forecast Comparison / {model}',
            ))

        cards_by_variable = {}
        total_cards = 0
        for variable in variables:
            cards_by_variable[variable] = {}
            for zone in zones:
                try:
                    cards_by_variable[variable][zone] = _chart_card(
                        variable=variable,
                        zone=zone,
                        model_name=model,
                        today_date=today_date,
                        ref_date=ref_date,
                        show_delta=show_delta,
                    )
                    total_cards += 1
                except Exception as exc:
                    logger.error(
                        f"Failed to render chart for {variable}/{zone}: {exc}",
                        exc_info=True,
                    )
                    cards_by_variable[variable][zone] = _empty_card(
                        f"{variable} · {zone}",
                        f"Render error: {exc}",
                    )
                    toasts.append(make_toast(
                        f"Chart failed for {variable}/{zone}: {exc}",
                        level='error', source='Forecast Comparison',
                    ))

        grid = _build_grid(cards_by_variable, variables, zones)
        status = f"{total_cards} charts"
        if status_parts:
            status += f"  |  {', '.join(status_parts)}"
        if total_errors:
            status += f"  |  {len(total_errors)} errors"

        return grid, status, toasts

    logger.info("Forecast Comparison callbacks registered")
