"""
Fundamentals Dashboard - Met Run Deltas
========================================
Run-over-run changes in the AI ensemble weather forecasts (ECMWF AIFS-ENS,
NCEP AIGEFS, Google WeatherNext 2/3) that drive European power demand and wind.

Each model run's country series is persisted by the ``weather_forecasts``
Dagster code location; this page reads that issue-dated store and shows:

* how the newest run moved against the one before it, per country;
* whether that move is large relative to the ensemble's own spread (z-score),
  which is what separates a tradable signal from ensemble noise;
* the absolute forecast level with its spread band;
* the full revision history for a country, i.e. how each successive run has
  changed its view of the same valid time.
"""
from __future__ import annotations

import logging
from typing import List, Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, dcc, html

from core.styles import CHART_COLORS
from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE, CARD_HEADER_TEXT_STYLE, CARD_STYLE, COLORS,
    CONTROL_PANEL_STYLE, LABEL_STYLE, apply_chart_style, styled_empty_figure,
)
from portal_pages.fundamentals import met_run_store as store

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "AIFS-ENS"
DEFAULT_VARIABLE = "cwg"
DEFAULT_COUNTRIES = ["UK", "France", "Germany"]
DEFAULT_FOCUS = "Germany"

# Beyond ~10 days the ensemble carries little information for power.
MAX_LEAD_DAYS = 15

# |z| above this means the run change is large relative to ensemble spread.
Z_SIGNAL_THRESHOLD = 1.0

_GRAPH_CONFIG = {"displayModeBar": False}


def _country_colour(index: int) -> str:
    return CHART_COLORS[index % len(CHART_COLORS)]


def _card(title: str, subtitle: str, figure: go.Figure, accent: str) -> html.Div:
    """Chart card with a coloured accent bar, matching the Availability tab."""
    return html.Div(style=CARD_STYLE, children=[
        html.Div(style={"display": "flex", "alignItems": "stretch"}, children=[
            html.Div(style={
                "width": "4px",
                "backgroundColor": accent,
                "borderRadius": "12px 0 0 0",
            }),
            html.Div(style={**CARD_HEADER_STYLE, "flex": "1"}, children=[
                html.H4(title, style=CARD_HEADER_TEXT_STYLE),
                html.P(subtitle, style={
                    "fontSize": "12px",
                    "color": COLORS["text_muted"],
                    "margin": "4px 0 0 0",
                    "textTransform": "none",
                    "letterSpacing": "0",
                }),
            ]),
        ]),
        dcc.Graph(figure=figure, config=_GRAPH_CONFIG),
    ])


def _placeholder(message: str) -> html.Div:
    return html.Div(
        style={"textAlign": "center", "padding": "60px",
               "color": COLORS["text_muted"], "fontSize": "14px"},
        children=message,
    )


def _clip_lead(df: pd.DataFrame) -> pd.DataFrame:
    return df[df["lead_hours"] <= MAX_LEAD_DAYS * 24]


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------

def build_delta_figure(delta: Optional[pd.DataFrame], variable: str,
                       countries: List[str]) -> go.Figure:
    """Run-over-run change per country against valid time."""
    meta = store.VARIABLES[variable]
    if delta is None or delta.empty:
        return styled_empty_figure("No run pair available")

    matching = delta[delta["variable"] == variable]
    if matching.empty:
        # The runs are there, this variable is not — usually the fetch did
        # not include the fields it needs.
        return styled_empty_figure(f"These runs hold no {meta['short']} data")

    sub = _clip_lead(matching)
    if sub.empty:
        return styled_empty_figure("No overlapping valid times between these runs")

    fig = go.Figure()
    for i, country in enumerate(countries):
        c = sub[sub["country"] == country]
        if c.empty:
            continue
        fig.add_trace(go.Scatter(
            x=c["valid_time"], y=c["delta"],
            mode="lines", name=country,
            line=dict(width=2.2, color=_country_colour(i)),
            hovertemplate=(f"<b>{country}</b><br>%{{x|%a %d %b %Hz}}"
                           f"<br>{meta['delta_unit']}: %{{y:+.2f}}<extra></extra>"),
        ))

    if not fig.data:
        return styled_empty_figure("No data for the selected countries")

    fig.add_hline(y=0, line=dict(color=COLORS["text_muted"], width=1, dash="dot"))
    apply_chart_style(fig, height=420)
    fig.update_layout(
        yaxis_title=dict(text=f"{meta['short']} change ({meta['delta_unit']})"),
        xaxis=dict(tickformat="%a %d %b"),
    )
    return fig


def build_conviction_heatmap(delta: Optional[pd.DataFrame], variable: str,
                             countries: List[str], model: str) -> go.Figure:
    """Daily-mean z-score per country: run change scaled by ensemble spread."""
    meta = store.VARIABLES[variable]
    if model in store.DETERMINISTIC_MODELS:
        return styled_empty_figure(
            f"{store.MODEL_LABEL.get(model, model)} is deterministic \u2013 "
            "no ensemble spread to scale against"
        )
    if delta is None or delta.empty:
        return styled_empty_figure("No run pair available")

    matching = delta[delta["variable"] == variable]
    if matching.empty:
        return styled_empty_figure(f"These runs hold no {meta['short']} data")

    sub = _clip_lead(matching).copy()
    sub = sub[sub["country"].isin(countries)]
    if sub.empty or sub["z_score"].isna().all():
        return styled_empty_figure("No ensemble spread available for these runs")

    sub["day"] = sub["valid_time"].dt.floor("D")
    pivot = sub.pivot_table(index="country", columns="day",
                            values="z_score", aggfunc="mean")
    pivot = pivot.reindex([c for c in countries if c in pivot.index])
    if pivot.empty:
        return styled_empty_figure("No data for the selected countries")

    z = pivot.to_numpy(dtype=float)
    limit = float(np.nanmax(np.abs(z))) if np.isfinite(z).any() else 1.0
    limit = max(limit, 0.5)

    fig = go.Figure(go.Heatmap(
        z=z,
        x=[d.strftime("%a %d %b") for d in pivot.columns],
        y=list(pivot.index),
        colorscale="RdBu_r",
        zmid=0, zmin=-limit, zmax=limit,
        colorbar=dict(title=dict(text="z", side="right"), thickness=12),
        hovertemplate=("<b>%{y}</b><br>%{x}<br>z: %{z:+.2f}<extra></extra>"),
    ))
    apply_chart_style(fig, height=max(260, 44 * len(pivot.index) + 140))
    fig.update_layout(
        xaxis=dict(showgrid=False, tickangle=-40),
        yaxis=dict(showgrid=False, autorange="reversed"),
        hovermode="closest",
        yaxis_title=None,
    )
    return fig


def build_levels_figure(latest: pd.DataFrame, previous: pd.DataFrame,
                        variable: str, country: str,
                        latest_key: str, previous_key: str) -> go.Figure:
    """Absolute forecast level for one country, latest vs previous run."""
    meta = store.VARIABLES[variable]

    def _series(df: Optional[pd.DataFrame]) -> Optional[pd.DataFrame]:
        if df is None or df.empty:
            return None
        s = df[(df["country"] == country) & (df["variable"] == variable)]
        s = _clip_lead(s)
        return s.sort_values("valid_time") if not s.empty else None

    cur, prev = _series(latest), _series(previous)
    if cur is None:
        return styled_empty_figure(f"No {meta['short']} series for {country}")

    fig = go.Figure()

    # Spread band first so the mean lines sit on top of it. Models that publish
    # percentiles get the real p10-p90 band; the rest get a symmetric +/-1 sd.
    if "p10" in cur.columns and cur["p10"].notna().any():
        lower, upper = cur["p10"], cur["p90"]
        band_name = "p10\u2013p90"
    elif (cur["value_std"] > 1e-6).any():
        lower = cur["value_mean"] - cur["value_std"]
        upper = cur["value_mean"] + cur["value_std"]
        band_name = "\u00b11 ensemble sd"
    else:
        lower = upper = None

    if lower is not None:
        fig.add_trace(go.Scatter(
            x=pd.concat([cur["valid_time"], cur["valid_time"][::-1]]),
            y=pd.concat([upper, lower[::-1]]),
            fill="toself", fillcolor="rgba(74,158,255,0.14)",
            line=dict(width=0), hoverinfo="skip",
            name=band_name,
        ))

    if prev is not None:
        fig.add_trace(go.Scatter(
            x=prev["valid_time"], y=prev["value_mean"],
            mode="lines", name=f"Previous \u2013 {store.format_run_key(previous_key)}",
            line=dict(width=1.8, color=COLORS["text_muted"], dash="dash"),
            hovertemplate=f"Previous<br>%{{x|%a %d %b %Hz}}<br>%{{y:.2f}} {meta['unit']}<extra></extra>",
        ))

    fig.add_trace(go.Scatter(
        x=cur["valid_time"], y=cur["value_mean"],
        mode="lines", name=f"Latest \u2013 {store.format_run_key(latest_key)}",
        line=dict(width=2.6, color=CHART_COLORS[0]),
        hovertemplate=f"Latest<br>%{{x|%a %d %b %Hz}}<br>%{{y:.2f}} {meta['unit']}<extra></extra>",
    ))

    apply_chart_style(fig, height=400)
    fig.update_layout(
        yaxis_title=dict(text=f"{meta['short']} ({meta['unit']})"),
        xaxis=dict(tickformat="%a %d %b"),
    )
    return fig


def build_revision_figure(history: Optional[pd.DataFrame], variable: str,
                          country: str) -> go.Figure:
    """One line per run: how the view of each valid time has evolved."""
    meta = store.VARIABLES[variable]
    if history is None or history.empty:
        return styled_empty_figure(f"No revision history stored for {country}")

    history = _clip_lead(history)
    if history.empty:
        return styled_empty_figure("No revision history within the forecast horizon")

    runs = sorted(history["run_key"].unique())
    fig = go.Figure()
    for i, run_key in enumerate(runs):
        sub = history[history["run_key"] == run_key].sort_values("valid_time")
        is_latest = i == len(runs) - 1
        # Older runs fade into the background; the newest run is the reference.
        opacity = 0.25 + 0.55 * (i / max(len(runs) - 1, 1))
        fig.add_trace(go.Scatter(
            x=sub["valid_time"], y=sub["value_mean"],
            mode="lines",
            name=store.format_run_key(run_key),
            line=dict(
                width=2.8 if is_latest else 1.3,
                color=CHART_COLORS[0] if is_latest
                else f"rgba(110,120,130,{opacity:.2f})",
            ),
            hovertemplate=(f"{store.format_run_key(run_key)}"
                           f"<br>%{{x|%a %d %b %Hz}}<br>%{{y:.2f}} {meta['unit']}"
                           "<extra></extra>"),
        ))

    apply_chart_style(fig, height=400)
    fig.update_layout(
        yaxis_title=dict(text=f"{meta['short']} ({meta['unit']})"),
        xaxis=dict(tickformat="%a %d %b"),
        hovermode="closest",
        legend=dict(orientation="v", yanchor="top", y=1, xanchor="left", x=1.01,
                    font=dict(size=10)),
    )
    return fig


# ---------------------------------------------------------------------------
# Summary strip
# ---------------------------------------------------------------------------

def build_summary(delta: Optional[pd.DataFrame], variable: str,
                  countries: List[str], model: str) -> html.Div:
    """Headline: the largest run-over-run moves, ranked by conviction."""
    meta = store.VARIABLES[variable]
    if delta is None or delta.empty:
        return html.Div()

    sub = _clip_lead(delta[(delta["variable"] == variable)
                           & (delta["country"].isin(countries))])
    if sub.empty:
        return html.Div()

    # Rank on z where the ensemble gives us spread, on raw delta otherwise.
    use_z = model not in store.DETERMINISTIC_MODELS and sub["z_score"].notna().any()
    agg = sub.groupby("country").agg(
        mean_delta=("delta", "mean"),
        max_delta=("delta", lambda s: s.loc[s.abs().idxmax()]),
        mean_z=("z_score", "mean"),
    ).reset_index()
    agg["rank_on"] = agg["mean_z"].abs() if use_z else agg["mean_delta"].abs()
    agg = agg.sort_values("rank_on", ascending=False)

    tiles = []
    for _, row in agg.iterrows():
        d = row["mean_delta"]
        z = row["mean_z"]
        signal = use_z and pd.notna(z) and abs(z) >= Z_SIGNAL_THRESHOLD
        colour = COLORS["danger"] if d > 0 else COLORS["accent"]
        tiles.append(html.Div(
            style={
                "flex": "1 1 140px",
                "padding": "14px 16px",
                "backgroundColor": COLORS["card_bg"],
                "border": (f"1px solid {colour}" if signal
                           else f"1px solid {COLORS['border']}"),
                "borderRadius": "10px",
                "minWidth": "140px",
            },
            children=[
                html.Div(row["country"], style={
                    "fontSize": "12px", "fontWeight": "600",
                    "color": COLORS["text_muted"], "textTransform": "uppercase",
                    "letterSpacing": "0.5px",
                }),
                html.Div(f"{d:+.2f} {meta['unit']}", style={
                    "fontSize": "22px", "fontWeight": "600",
                    "color": colour, "margin": "4px 0 2px 0",
                }),
                html.Div(
                    (f"z {z:+.2f}" if use_z and pd.notna(z) else "no spread"),
                    style={"fontSize": "11px", "color": COLORS["text_muted"]},
                ),
                html.Div(
                    f"peak {row['max_delta']:+.2f}",
                    style={"fontSize": "11px", "color": COLORS["text_muted"]},
                ),
            ],
        ))

    return html.Div(
        style={"display": "flex", "gap": "12px", "flexWrap": "wrap",
               "marginBottom": "20px"},
        children=tiles,
    )


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def _run_options(model: str) -> List[dict]:
    return [{"label": store.format_run_key(k), "value": k}
            for k in reversed(store.list_runs(model))]


def get_layout(data_handler=None):
    """Return the Met Run Deltas layout.

    ``data_handler`` is accepted for signature compatibility with the other
    Fundamentals sub-pages; this page reads the weather run store directly.
    """
    try:
        status = store.store_status()
    except Exception as e:  # noqa: BLE001 - never break the tab bar
        logger.error("Met run store unavailable: %s", e)
        status = []

    model = DEFAULT_MODEL
    latest_key, previous_key = store.latest_run_pair(model)
    countries = store.available_countries(model) or DEFAULT_COUNTRIES
    selected = [c for c in DEFAULT_COUNTRIES if c in countries] or countries[:3]
    focus = DEFAULT_FOCUS if DEFAULT_FOCUS in countries else (countries[0] if countries else None)

    status_chips = [
        html.Div(
            style={
                "padding": "8px 14px",
                "borderRadius": "20px",
                "fontSize": "12px",
                "backgroundColor": COLORS["card_bg_alt"],
                "border": f"1px solid {COLORS['border']}",
                "color": COLORS["text_secondary"],
            },
            children=[
                html.Span(s["label"], style={"fontWeight": "600"}),
                html.Span(
                    f"  {store.format_run_key(s['latest_run'])}  \u00b7  {s['n_runs']} runs"
                    if s["latest_run"] else "  no runs stored",
                    style={"color": COLORS["text_muted"]},
                ),
            ],
        )
        for s in status
    ]

    return html.Div([
        # -------- Control panel --------
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div(
                style={"display": "flex", "alignItems": "flex-end",
                       "gap": "20px", "flexWrap": "wrap"},
                children=[
                    html.Div([
                        html.Label("Model", style=LABEL_STYLE),
                        dcc.Dropdown(
                            id="mrd-model-select",
                            options=[{"label": store.MODEL_LABEL[m], "value": m}
                                     for m in store.MODELS],
                            value=model, clearable=False,
                            style={"width": "210px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Variable", style=LABEL_STYLE),
                        dcc.Dropdown(
                            id="mrd-variable-select",
                            options=[{"label": v["label"], "value": k}
                                     for k, v in store.VARIABLES.items()],
                            value=DEFAULT_VARIABLE, clearable=False,
                            style={"width": "200px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Latest run", style=LABEL_STYLE),
                        dcc.Dropdown(
                            id="mrd-latest-run",
                            options=_run_options(model),
                            value=latest_key, clearable=False,
                            style={"width": "150px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Compared with", style=LABEL_STYLE),
                        dcc.Dropdown(
                            id="mrd-previous-run",
                            options=_run_options(model),
                            value=previous_key, clearable=False,
                            style={"width": "150px"},
                        ),
                    ]),
                    html.Div(style={"flex": "1 1 240px"}, children=[
                        html.Label("Countries", style=LABEL_STYLE),
                        dcc.Dropdown(
                            id="mrd-country-select",
                            options=[{"label": c, "value": c} for c in countries],
                            value=selected, multi=True,
                        ),
                    ]),
                    html.Div([
                        html.Label("Focus country", style=LABEL_STYLE),
                        dcc.Dropdown(
                            id="mrd-focus-country",
                            options=[{"label": c, "value": c} for c in countries],
                            value=focus, clearable=False,
                            style={"width": "150px"},
                        ),
                    ]),
                ],
            ),
            html.Div(
                style={"display": "flex", "gap": "10px", "flexWrap": "wrap",
                       "marginTop": "16px"},
                children=status_chips,
            ),
        ]),

        # -------- Charts --------
        dcc.Loading(
            type="circle", color=COLORS["accent"],
            children=[html.Div(id="mrd-charts-container",
                               children=_placeholder("Loading forecast run history\u2026"))],
        ),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_met_run_deltas_callbacks(app, data_handler=None):
    """Register the Met Run Deltas callbacks."""

    @app.callback(
        [Output("mrd-latest-run", "options"),
         Output("mrd-latest-run", "value"),
         Output("mrd-previous-run", "options"),
         Output("mrd-previous-run", "value"),
         Output("mrd-country-select", "options"),
         Output("mrd-country-select", "value"),
         Output("mrd-focus-country", "options"),
         Output("mrd-focus-country", "value")],
        Input("mrd-model-select", "value"),
    )
    def update_model_options(model):
        """Repoint the run and country pickers when the model changes."""
        if not model:
            return [], None, [], None, [], [], [], None

        options = _run_options(model)
        latest_key, previous_key = store.latest_run_pair(model)
        countries = store.available_countries(model, latest_key)
        country_options = [{"label": c, "value": c} for c in countries]
        selected = [c for c in DEFAULT_COUNTRIES if c in countries] or countries[:3]
        focus = DEFAULT_FOCUS if DEFAULT_FOCUS in countries else (
            countries[0] if countries else None)

        return (options, latest_key, options, previous_key,
                country_options, selected, country_options, focus)

    @app.callback(
        Output("mrd-charts-container", "children"),
        [Input("mrd-model-select", "value"),
         Input("mrd-variable-select", "value"),
         Input("mrd-latest-run", "value"),
         Input("mrd-previous-run", "value"),
         Input("mrd-country-select", "value"),
         Input("mrd-focus-country", "value")],
    )
    def update_charts(model, variable, latest_key, previous_key, countries, focus):
        if not model or not variable:
            return _placeholder("Select a model and variable.")
        if not latest_key:
            return _placeholder(
                f"No runs stored yet for {store.MODEL_LABEL.get(model, model)}. "
                "The weather_forecasts pipeline populates this after its next run."
            )
        if not previous_key:
            return _placeholder(
                "Only one run is stored, so there is nothing to compare against yet."
            )
        if latest_key == previous_key:
            return _placeholder("Pick two different runs to compare.")

        countries = countries or []
        if not countries:
            return _placeholder("Select at least one country.")

        meta = store.VARIABLES[variable]
        model_label = store.MODEL_LABEL.get(model, model)

        try:
            delta = store.compute_delta(model, latest_key, previous_key)
            latest_df = store.load_run(model, latest_key)
            previous_df = store.load_run(model, previous_key)
        except Exception as e:  # noqa: BLE001
            logger.error("Met run delta load failed: %s", e)
            return _placeholder(f"Could not read the run store: {e}")

        if delta is None or delta.empty:
            return _placeholder(
                f"{store.format_run_key(latest_key)} and "
                f"{store.format_run_key(previous_key)} share no valid times."
            )

        pair = (f"{store.format_run_key(latest_key)} vs "
                f"{store.format_run_key(previous_key)}")

        cards = [
            build_summary(delta, variable, countries, model),
            _card(
                f"{meta['short']} run-over-run change",
                f"{model_label} \u00b7 {pair} \u00b7 {meta['description']}",
                build_delta_figure(delta, variable, countries),
                CHART_COLORS[0],
            ),
            _card(
                "Conviction (change / ensemble spread)",
                f"Daily-mean z-score \u00b7 |z| \u2265 {Z_SIGNAL_THRESHOLD:.0f} "
                "means the move is large relative to ensemble uncertainty",
                build_conviction_heatmap(delta, variable, countries, model),
                CHART_COLORS[2],
            ),
        ]

        if focus:
            cards.append(_card(
                f"{focus} \u2013 forecast level",
                f"{model_label} \u00b7 {pair} \u00b7 shaded band is \u00b11 ensemble sd",
                build_levels_figure(latest_df, previous_df, variable, focus,
                                    latest_key, previous_key),
                CHART_COLORS[1],
            ))

            try:
                history = store.revision_history(model, focus, variable)
            except Exception as e:  # noqa: BLE001
                logger.error("Revision history load failed: %s", e)
                history = None

            cards.append(_card(
                f"{focus} \u2013 revision history",
                f"{model_label} \u00b7 every stored run's view of the same valid times",
                build_revision_figure(history, variable, focus),
                CHART_COLORS[3],
            ))

        return cards
