"""
DataHandler - Fundamentals dashboard data loading from S3 cache.

Replaces the original Kpler/Snowflake-based DataHandler with one that reads
pre-cached REMIT availability and actual generation data from S3 parquet files
(sourced from EnergyQuantified via eu_corelib).

Public API is unchanged so that all sub-pages (availability, generation vs
availability, home) continue to work without modification.
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import functools
import concurrent.futures
import threading

# Import cache classes from eu_corelib
from jain_commods.core.cache.data.fundamentals import (
    GenAvailNuclear, GenAvailGas, GenAvailCoal, GenAvailLignite,
    GenAvailOil, GenAvailBiomass,
    GenNuclearActual, GenGasActual, GenCoalActual, GenLigniteActual,
    GenBiomassActual,
)

# Import enterprise caching
from core.cache import dashboard_cache
from core.data_freshness import tracker

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants & mappings
# ---------------------------------------------------------------------------

# Mapping from internal tech key → Kpler-style FUEL_TYPE strings
FUEL_TYPE_MAP = {
    'nuclear': 'nuclear',
    'gas': 'fossil gas',
    'coal': 'fossil hard coal',
    'lignite': 'fossil brown coal/lignite',
    'biomass': 'biomass',
    'oil': 'fossil oil',
}

# Main national-level zones → dashboard country codes
ZONE_TO_COUNTRY = {
    'at': 'AT', 'be': 'BE', 'de': 'DE', 'fr': 'FR', 'nl': 'NL',
    'ch': 'CH', 'gb': 'UK', 'ie': 'IE', 'es': 'ES', 'pt': 'PT',
    'it': 'IT', 'bg': 'BG', 'hr': 'HR', 'gr': 'GR', 'pl': 'PL',
    'cz': 'CZ', 'si': 'SI', 'sk': 'SK', 'hu': 'HU', 'ro': 'RO',
    'rs': 'RS', 'ba': 'BA', 'mk': 'MK', 'tr': 'TR', 'al': 'AL',
    'me': 'ME', 'xk': 'XK', 'dk': 'DK', 'se': 'SE', 'no': 'NO',
    'fi': 'FI', 'lv': 'LV', 'lt': 'LT', 'ee': 'EE', 'ua': 'UA',
    'md': 'MD',
}
MAIN_ZONES = list(ZONE_TO_COUNTRY.keys())

# REMIT availability cache classes (daily, contains history + forward forecast)
AVAIL_CLASSES = {
    'nuclear': GenAvailNuclear,
    'gas': GenAvailGas,
    'coal': GenAvailCoal,
    'lignite': GenAvailLignite,
    'oil': GenAvailOil,
    'biomass': GenAvailBiomass,
}

# Actual generation cache classes (hourly, historical only)
ACTUAL_CLASSES = {
    'nuclear': GenNuclearActual,
    'gas': GenGasActual,
    'coal': GenCoalActual,
    'lignite': GenLigniteActual,
    'biomass': GenBiomassActual,
}

# Priority countries that should be pre-processed and cached
PRIORITY_COUNTRIES = ['DE', 'FR', 'UK', 'NL', 'BE']

# Define renewable types to exclude (kept for API compatibility)
renewable_types_to_exclude = [
    'wind onshore',
    'wind offshore',
    'solar',
    'marine',
    'hydro run-of-river and poundage',
    'hydro pumped storage',
    'hydro water reservoir',
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _convert_float64_to_float32(df):
    """Convert float64 columns to float32 to save memory."""
    if df is None or not isinstance(df, pd.DataFrame):
        return df
    for col in df.select_dtypes(include=['float64']).columns:
        df[col] = df[col].astype(np.float32)
    return df


# ---------------------------------------------------------------------------
# DataHandler
# ---------------------------------------------------------------------------

class DataHandler:
    """Loads fundamentals data from S3 cache (REMIT availability + actual generation)."""

    def __init__(self, defer_loading=False):
        logger.debug("Initializing DataHandler (S3 cache mode)")
        self.global_data = {
            'combined_multi_index_df': None,
            'filtered_availability_merge': None,
            'last_update': None,
            'processed_data': {},
        }
        self.is_ready = False

        if not defer_loading:
            self.ready()

    # ------------------------------------------------------------------
    # Token management (no-op in S3 cache mode)
    # ------------------------------------------------------------------

    def ensure_fresh_token(self):
        """No-op: S3 cache mode does not require token management."""
        return True

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def ready(self):
        """Initialize all data. Call this after app startup to prepare data."""
        if not self.is_ready:
            logger.info("Initializing DataHandler from S3 cache")

            # Check if we already have data loaded
            if ('historical_multi_index_df' in self.global_data and
                    self.global_data['historical_multi_index_df'] is not None and
                    'filtered_availability' in self.global_data and
                    self.global_data['filtered_availability'] is not None):
                logger.info("Data already loaded, skipping initialization")
                self.is_ready = True
                return True

            # Load availability + generation in a single pass (avoids
            # loading availability twice which the old flow did).
            self.reload_latest_data()
            self.schedule_next_refresh()
            self.is_ready = True
            return True
        return False

    # ------------------------------------------------------------------
    # S3 cache loading helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_cache_class(cls):
        """Load a single cache class from S3 and return its data DataFrame."""
        try:
            obj = cls()
            obj.load(from_s3=True, show_metadata=False)
            return obj.data
        except Exception as e:
            logger.warning(f"Failed to load {cls.__name__} from S3: {e}")
            return None

    @staticmethod
    def _reshape_to_long(df, zones, value_col='value'):
        """Reshape a wide cache DataFrame (index=valuedate, cols=zones) → long format."""
        available = [z for z in zones if z in df.columns]
        if not available:
            return pd.DataFrame()

        sub = df[available].copy()
        sub = sub.reset_index()
        # First column is the date index (named 'valuedate')
        sub = sub.rename(columns={sub.columns[0]: 'TIMESTAMP'})
        long = pd.melt(sub, id_vars=['TIMESTAMP'], var_name='zone', value_name=value_col)
        long['COUNTRY'] = long['zone'].map(ZONE_TO_COUNTRY)
        long = long.drop(columns=['zone'])
        long = long.dropna(subset=[value_col])
        return long

    def _load_availability_from_cache(self):
        """Load all REMIT availability data from S3 cache → long-format DataFrame.

        Returns DataFrame with columns: TIMESTAMP, COUNTRY, FUEL_TYPE, AVAILABILITY_AMOUNT
        """
        frames = []
        for tech_key, cls in AVAIL_CLASSES.items():
            data = self._load_cache_class(cls)
            if data is None or data.empty:
                logger.info(f"  No availability data for {tech_key}")
                continue
            long = self._reshape_to_long(data, MAIN_ZONES, value_col='AVAILABILITY_AMOUNT')
            if long.empty:
                continue
            long['FUEL_TYPE'] = FUEL_TYPE_MAP[tech_key]
            frames.append(long)
            logger.info(f"  Loaded availability: {tech_key} → {len(long):,} rows")

        if frames:
            return pd.concat(frames, ignore_index=True)
        return pd.DataFrame()

    def _load_generation_from_cache(self):
        """Load all actual generation data from S3 cache → long-format DataFrame.

        Returns DataFrame with columns: TIMESTAMP, COUNTRY, FUEL_TYPE, GENERATION
        """
        frames = []
        for tech_key, cls in ACTUAL_CLASSES.items():
            data = self._load_cache_class(cls)
            if data is None or data.empty:
                logger.info(f"  No generation data for {tech_key}")
                continue
            # Load all available data (no cutoff - S3 parquet is already efficient)
            long = self._reshape_to_long(data, MAIN_ZONES, value_col='GENERATION')
            if long.empty:
                continue
            long['FUEL_TYPE'] = FUEL_TYPE_MAP[tech_key]
            frames.append(long)
            logger.info(f"  Loaded generation: {tech_key} → {len(long):,} rows")

        if frames:
            return pd.concat(frames, ignore_index=True)
        return pd.DataFrame()

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------

    def load_initial_data(self):
        """Load availability data from S3 cache."""
        logger.info("Loading availability data from S3 cache...")
        try:
            availability_df = self._load_availability_from_cache()

            if availability_df.empty:
                logger.warning("No availability data loaded from cache")
                return

            availability_df = _convert_float64_to_float32(availability_df)

            # Create multi-index DataFrame with AS_OF = 'latest'
            availability_df['AS_OF'] = 'latest'
            multi_index_df = availability_df.set_index(['AS_OF', 'COUNTRY'])
            multi_index_df = multi_index_df.sort_index()

            # Store availability (also used in the merge step)
            filtered_availability = availability_df.copy()
            filtered_availability = _convert_float64_to_float32(filtered_availability)

            self.global_data['historical_multi_index_df'] = multi_index_df
            self.global_data['filtered_availability'] = filtered_availability

            # Register data freshness
            tracker.register_data_source(
                "Fundamentals Availability (S3 Cache)",
                datetime.now(),
                expected_frequency_minutes=60,
                metadata={
                    'rows': len(availability_df),
                    'countries': availability_df['COUNTRY'].nunique(),
                }
            )

            logger.info(
                f"Availability data loaded: {len(availability_df):,} rows, "
                f"{availability_df['COUNTRY'].nunique()} countries, "
                f"{availability_df['FUEL_TYPE'].nunique()} fuel types"
            )

        except Exception as e:
            logger.error(f"Error loading initial data from cache: {e}")
            raise

    def reload_latest_data(self):
        """Reload latest data: generation from cache, merge with availability."""
        logger.info("Reloading latest data from S3 cache...")
        try:
            # Clear caches before loading new data to free memory
            self.clear_cache()

            # Load generation and fresh availability in parallel
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
                future_gen = executor.submit(self._load_generation_from_cache)
                future_avail = executor.submit(self._load_availability_from_cache)

                generation_df = future_gen.result(timeout=120)
                fresh_avail = future_avail.result(timeout=120)

                generation_df = _convert_float64_to_float32(generation_df)
                fresh_avail = _convert_float64_to_float32(fresh_avail)

            # Update availability if we got fresh data
            if fresh_avail is not None and not fresh_avail.empty:
                fresh_avail['AS_OF'] = 'latest'
                multi_index_df = fresh_avail.set_index(['AS_OF', 'COUNTRY']).sort_index()
                self.global_data['historical_multi_index_df'] = multi_index_df
                self.global_data['combined_multi_index_df'] = multi_index_df
                self.global_data['filtered_availability'] = fresh_avail.copy()

                tracker.register_data_source(
                    "Fundamentals Availability (S3 Cache)",
                    datetime.now(),
                    expected_frequency_minutes=60,
                    metadata={
                        'rows': len(fresh_avail),
                        'countries': fresh_avail['COUNTRY'].nunique(),
                    }
                )
                logger.info(
                    f"Availability data loaded: {len(fresh_avail):,} rows, "
                    f"{fresh_avail['COUNTRY'].nunique()} countries, "
                    f"{fresh_avail['FUEL_TYPE'].nunique()} fuel types"
                )
            elif 'historical_multi_index_df' in self.global_data:
                self.global_data['combined_multi_index_df'] = self.global_data['historical_multi_index_df']

            # Register data freshness for generation
            if generation_df is not None and not generation_df.empty:
                tracker.register_data_source(
                    "Fundamentals Generation (S3 Cache)",
                    datetime.now(),
                    expected_frequency_minutes=60,
                    metadata={
                        'rows': len(generation_df),
                        'countries': generation_df['COUNTRY'].nunique(),
                    }
                )

            # Merge availability + generation
            filtered_avail = self.global_data.get('filtered_availability')
            has_avail = filtered_avail is not None and not filtered_avail.empty
            has_gen = generation_df is not None and not generation_df.empty

            if has_avail and has_gen:
                # Clear old merged data
                if self.global_data.get('filtered_availability_merge') is not None:
                    del self.global_data['filtered_availability_merge']

                # Get all unique timestamp/country/fuel combinations
                all_keys = pd.concat([
                    filtered_avail[['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE']],
                    generation_df[['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE']],
                ]).drop_duplicates()

                base_df = all_keys.copy()

                # Merge availability
                avail_cols = [c for c in ['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE',
                                          'AVAILABILITY_AMOUNT', 'AS_OF']
                              if c in filtered_avail.columns]
                base_df = base_df.merge(
                    filtered_avail[avail_cols],
                    on=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'],
                    how='left',
                )

                # Merge generation
                gen_cols = [c for c in ['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE', 'GENERATION']
                            if c in generation_df.columns]
                base_df = base_df.merge(
                    generation_df[gen_cols],
                    on=['TIMESTAMP', 'COUNTRY', 'FUEL_TYPE'],
                    how='left',
                )

                base_df = _convert_float64_to_float32(base_df)
                self.global_data['filtered_availability_merge'] = base_df
                del all_keys

            elif has_avail:
                self.global_data['filtered_availability_merge'] = filtered_avail.copy()

            self.global_data['last_update'] = datetime.now()

            # Pre-process data for priority countries
            self.preprocess_data_for_countries()

            logger.info("Latest data reload completed")

        except Exception as e:
            import traceback
            logger.error(f"Error reloading latest data: {type(e).__name__}: {e}")
            logger.error(f"Full traceback: {traceback.format_exc()}")
            self.clear_cache()

    # ------------------------------------------------------------------
    # Pre-processing
    # ------------------------------------------------------------------

    def preprocess_data_for_countries(self):
        """Pre-process data for each country and fuel type to speed up chart rendering."""
        logger.debug("Pre-processing data for countries...")

        try:
            if ('combined_multi_index_df' not in self.global_data or
                    self.global_data['combined_multi_index_df'] is None or
                    'filtered_availability_merge' not in self.global_data or
                    self.global_data['filtered_availability_merge'] is None):
                logger.warning("Cannot pre-process data - data not loaded yet")
                return

            # Reset processed data
            self.global_data['processed_data'] = {}

            if 'COUNTRY' not in self.global_data['filtered_availability_merge'].columns:
                logger.error("COUNTRY column missing from filtered_availability_merge")
                return

            all_countries = self.global_data['filtered_availability_merge']['COUNTRY'].unique()

            for country in all_countries:
                # Skip non-priority countries (lazy loading)
                if country not in PRIORITY_COUNTRIES:
                    continue

                country_fuel_types = self.global_data['filtered_availability_merge'][
                    self.global_data['filtered_availability_merge']['COUNTRY'] == country
                ]['FUEL_TYPE'].unique()

                self.global_data['processed_data'][country] = {}

                avail_df = self.global_data['combined_multi_index_df'].reset_index()
                avail_df_country = avail_df[avail_df['COUNTRY'] == country]

                merged_df_country = self.global_data['filtered_availability_merge'][
                    self.global_data['filtered_availability_merge']['COUNTRY'] == country
                ]

                for fuel_type in country_fuel_types:
                    avail_data = avail_df_country[avail_df_country['FUEL_TYPE'] == fuel_type]
                    merged_data = merged_df_country[merged_df_country['FUEL_TYPE'] == fuel_type]

                    self.global_data['processed_data'][country][fuel_type] = {
                        'availability': avail_data,
                        'merged': merged_data,
                    }

            logger.debug("Data pre-processing completed for priority countries")

        except Exception as e:
            import traceback
            logger.error(f"Error in preprocess_data_for_countries: {type(e).__name__}: {e}")
            logger.error(f"Full traceback: {traceback.format_exc()}")
            self.global_data['processed_data'] = {}

    # ------------------------------------------------------------------
    # Scheduling
    # ------------------------------------------------------------------

    def set_schedule_time(self, minutes=30, hours=None):
        """Set a specific schedule time for data refreshes.

        Args:
            minutes (int): Minute of each hour to refresh (default 30).
            hours (list, optional): Specific hours to refresh. If None, refresh every hour.
        """
        self.schedule_minutes = minutes
        self.schedule_hours = hours
        logger.info(f"Setting schedule: minutes={minutes}, hours={hours}")
        self.schedule_next_refresh()

    def schedule_next_refresh(self):
        now = datetime.now()

        if hasattr(self, 'schedule_hours') and self.schedule_hours is not None:
            next_hour = None
            for hour in sorted(self.schedule_hours):
                if hour > now.hour or (hour == now.hour and getattr(self, 'schedule_minutes', 30) > now.minute):
                    next_hour = hour
                    break

            if next_hour is None:
                next_hour = sorted(self.schedule_hours)[0]
                next_refresh = now.replace(
                    hour=next_hour,
                    minute=getattr(self, 'schedule_minutes', 30),
                    second=0, microsecond=0,
                ) + timedelta(days=1)
            else:
                next_refresh = now.replace(
                    hour=next_hour,
                    minute=getattr(self, 'schedule_minutes', 30),
                    second=0, microsecond=0,
                )
        else:
            sched_min = getattr(self, 'schedule_minutes', 30)
            if now.minute >= sched_min:
                # Avoid invalid hour=24 at day boundary; add one hour first.
                next_refresh = (now + timedelta(hours=1)).replace(
                    minute=sched_min, second=0, microsecond=0,
                )
            else:
                next_refresh = now.replace(
                    minute=sched_min, second=0, microsecond=0,
                )

        if next_refresh < now:
            next_refresh += timedelta(days=1)

        seconds_until_refresh = (next_refresh - now).total_seconds()
        logger.debug(
            f"Next data refresh scheduled for {next_refresh.strftime('%Y-%m-%d %H:%M:%S')} "
            f"({seconds_until_refresh:.0f} seconds from now)"
        )

        refresh_thread = threading.Timer(seconds_until_refresh, self.refresh_data_and_reschedule)
        refresh_thread.daemon = True
        refresh_thread.start()

    def refresh_data_and_reschedule(self):
        try:
            self.clear_cache()
            self.reload_latest_data()
        except Exception as e:
            logger.error(f"Error refreshing data: {e}")
        self.schedule_next_refresh()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_countries(self):
        """Return list of available countries."""
        try:
            if not self.is_ready:
                logger.warning("Data not ready yet when get_countries was called")
                return []

            if ('filtered_availability_merge' not in self.global_data or
                    self.global_data['filtered_availability_merge'] is None):
                return []

            countries = sorted(
                self.global_data['filtered_availability_merge']['COUNTRY'].unique().tolist()
            )
            # Ensure the major countries are at the front
            priority_countries = ['DE', 'FR', 'NL', 'BE', 'UK']
            result = []
            for country in priority_countries:
                if country in countries:
                    result.append(country)
                    countries.remove(country)
            result.extend(countries)
            return result
        except Exception as e:
            logger.error(f"Error getting countries: {e}")
            return []

    def get_fuel_types(self, country=None):
        """Return list of fuel types, optionally filtered by country."""
        try:
            if not self.is_ready:
                logger.warning("Data not ready yet when get_fuel_types was called")
                return []

            if ('filtered_availability_merge' not in self.global_data or
                    self.global_data['filtered_availability_merge'] is None):
                return []

            df = self.global_data['filtered_availability_merge']
            if country:
                return sorted(df[df['COUNTRY'] == country]['FUEL_TYPE'].unique().tolist())
            return sorted(df['FUEL_TYPE'].unique().tolist())
        except Exception as e:
            logger.error(f"Error getting fuel types: {e}")
            return []

    def get_main_fuel_types(self):
        """Return the main fuel types that should have dedicated charts."""
        return ['fossil gas', 'fossil hard coal', 'nuclear', 'fossil brown coal/lignite']

    def get_other_fuel_types(self, country):
        """Return fuel types that aren't in the main category for a country."""
        main_types = self.get_main_fuel_types()
        country_types = self.get_fuel_types(country)
        return [ft for ft in country_types if ft not in main_types]

    @functools.lru_cache(maxsize=128)
    def get_availability_data(self, country, fuel_type):
        """Get availability data for a country and fuel type (cached).

        Returns a *copy* so callers cannot corrupt the cache.
        """
        if not self.is_ready:
            logger.warning("Data not ready yet when get_availability_data was called")
            return pd.DataFrame()

        # First check pre-processed data
        if ('processed_data' in self.global_data and
                country in self.global_data.get('processed_data', {}) and
                fuel_type in self.global_data['processed_data'].get(country, {}) and
                'availability' in self.global_data['processed_data'][country].get(fuel_type, {})):
            df = self.global_data['processed_data'][country][fuel_type]['availability'].copy()
            if 'AVAILABILITY_AMOUNT' in df.columns and 'AVAILABLE_CAPACITY' not in df.columns:
                df = df.rename(columns={'AVAILABILITY_AMOUNT': 'AVAILABLE_CAPACITY'})
            if 'DATE' in df.columns and 'TIMESTAMP' not in df.columns:
                df = df.rename(columns={'DATE': 'TIMESTAMP'})
            return df

        # Lazy loading for non-priority countries
        if country not in PRIORITY_COUNTRIES:
            logger.info(f"Lazy loading availability data for non-priority country: {country} - {fuel_type}")

        if ('combined_multi_index_df' not in self.global_data or
                self.global_data['combined_multi_index_df'] is None):
            return pd.DataFrame()

        df = self.global_data['combined_multi_index_df'].reset_index()
        df = df[
            (df['COUNTRY'] == country) &
            (df['FUEL_TYPE'] == fuel_type)
        ].copy()

        if 'AVAILABILITY_AMOUNT' in df.columns and 'AVAILABLE_CAPACITY' not in df.columns:
            df = df.rename(columns={'AVAILABILITY_AMOUNT': 'AVAILABLE_CAPACITY'})
        if 'DATE' in df.columns and 'TIMESTAMP' not in df.columns:
            df = df.rename(columns={'DATE': 'TIMESTAMP'})

        return df

    @functools.lru_cache(maxsize=128)
    def get_merged_data(self, country, fuel_type):
        """Get merged data (availability + generation) for a country and fuel type (cached).

        Returns a *copy* so callers cannot corrupt the cache.
        """
        if not self.is_ready:
            logger.warning("Data not ready yet when get_merged_data was called")
            return pd.DataFrame()

        # First check pre-processed data
        if ('processed_data' in self.global_data and
                country in self.global_data.get('processed_data', {}) and
                fuel_type in self.global_data['processed_data'].get(country, {}) and
                'merged' in self.global_data['processed_data'][country].get(fuel_type, {})):
            return self.global_data['processed_data'][country][fuel_type]['merged'].copy()

        # Lazy loading for non-priority countries
        if country not in PRIORITY_COUNTRIES:
            logger.info(f"Lazy loading merged data for non-priority country: {country} - {fuel_type}")

        if ('filtered_availability_merge' not in self.global_data or
                self.global_data['filtered_availability_merge'] is None):
            return pd.DataFrame()

        return self.global_data['filtered_availability_merge'][
            (self.global_data['filtered_availability_merge']['COUNTRY'] == country) &
            (self.global_data['filtered_availability_merge']['FUEL_TYPE'] == fuel_type)
        ].copy()

    @functools.lru_cache(maxsize=64)
    def get_generation_vs_availability(self, country):
        """Get generation vs availability data for a country (cached).

        Returns a *copy* so callers cannot corrupt the cache.
        """
        try:
            if not self.is_ready:
                logger.warning("Data not ready yet when get_generation_vs_availability was called")
                return pd.DataFrame()

            if ('filtered_availability_merge' not in self.global_data or
                    self.global_data['filtered_availability_merge'] is None):
                return pd.DataFrame()

            if country not in PRIORITY_COUNTRIES:
                logger.info(f"Lazy loading generation vs availability for: {country}")

            return self.global_data['filtered_availability_merge'][
                self.global_data['filtered_availability_merge']['COUNTRY'] == country
            ].copy()
        except Exception as e:
            logger.error(f"Error getting generation vs availability data: {e}")
            return pd.DataFrame()

    def get_last_update_time(self):
        """Return the timestamp of the last data update."""
        return self.global_data.get('last_update')

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------

    def clear_cache(self):
        """Clear all caches to free memory before loading new data."""
        logger.debug("Clearing all data caches to free memory")

        try:
            import gc
            gc.collect()
        except Exception:
            logger.warning("Unable to force garbage collection")

        if 'processed_data' in self.global_data:
            self.global_data['processed_data'] = {}

        # Clear function-level caches
        self.get_availability_data.cache_clear()
        self.get_merged_data.cache_clear()
        self.get_generation_vs_availability.cache_clear()
        
        # Clear enterprise figure caches (from availability and generation pages)
        try:
            from core.cache import dashboard_cache
            # Clear all cached figures with our key prefixes
            dashboard_cache.clear(prefix='avail_fig:')
            dashboard_cache.clear(prefix='gen_fig:')
            logger.debug("Cleared cached Plotly figures")
        except Exception as e:
            logger.warning(f"Could not clear figure cache: {e}")

        try:
            import gc
            gc.collect()
        except Exception:
            pass

        logger.debug("Cache clearing completed")
