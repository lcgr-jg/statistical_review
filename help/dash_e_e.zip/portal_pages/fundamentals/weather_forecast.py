"""
Power Forecast Monitor
──────────────────────
Interactive pivot table showing forecast-on-forecast deltas for tradeable
power tenors (D+1 … WK+4), aggregated from hourly S3 cached forecast data.

Uses dash-pivottable for drag-and-drop pivoting and exploration.

Variables : Wind, Solar, Demand, Residual Load
Models    : EC, EC-ENS, GFS, GFS-ENS  (ST) ;  EC-EXT, GFS-EXT  (MT)
Display   : Absolute (GW)  |  Delta (GW)  |  Delta (%)
"""

import datetime
import logging
import uuid
from typing import List

from dash import html, dcc, Input, Output, State, no_update, callback_context
import dash_bootstrap_components as dbc
import dash_pivottable

logger = logging.getLogger(__name__)

# ── Styling (shared) ──────────────────────────────────────────────────────
try:
    from portal_pages.fundamentals.styles import COLORS
except ImportError:
    COLORS = {
        'bg': '#faf9f6', 'card_bg': '#ffffff', 'text_primary': '#2c3e50',
        'text_secondary': '#555', 'accent': '#4E738A', 'border': '#e8e6e1',
    }

# ── Data handler ──────────────────────────────────────────────────────────
from portal_pages.fundamentals.forecast_data_handler import (
    MODEL_CONFIGS, DEFAULT_ZONES, ALL_VARIABLES,
    build_pivot_data, check_and_download_forecast,
    CACHE_AVAILABLE,
)

# ── Toast notification support ─────────────────────────────────────────────
try:
    from core.toast_manager import make_toast
    TOAST_AVAILABLE = True
except ImportError:
    TOAST_AVAILABLE = False
    import uuid
    def make_toast(msg, level='info', source=None):
        return {'id': str(uuid.uuid4()), 'message': msg, 'level': level, 'source': source or '', 'timestamp': ''}


# ═══════════════════════════════════════════════════════════════════════════
# Layout
# ═══════════════════════════════════════════════════════════════════════════

def get_layout(data_handler=None, **kwargs):
    """Return the Forecast Monitor layout."""

    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=1)

    # ── Options ──
    model_options = [{'label': m, 'value': m} for m in MODEL_CONFIGS.keys()]

    return html.Div(
        style={'padding': '0'},
        children=[
            # ── Controls: Model, Display, Dates, Refresh ──────────────
            html.Div(
                style={
                    'backgroundColor': '#ffffff',
                    'padding': '18px 28px',
                    'borderBottom': '1px solid #e1e4e8',
                    'display': 'flex',
                    'flexWrap': 'wrap',
                    'gap': '24px',
                    'alignItems': 'flex-end',
                },
                children=[
                    # Model
                    html.Div([
                        html.Label("Model", style=_LABEL),
                        dcc.Dropdown(
                            id='fcst-model-select',
                            options=model_options,
                            value='EC-ENS 00z',  # Default to ST ensemble model
                            clearable=False,
                            style={'width': '170px', 'fontSize': '13px'},
                        ),
                    ]),

                    # Display mode
                    html.Div([
                        html.Label("Display", style=_LABEL),
                        dcc.RadioItems(
                            id='fcst-display-mode',
                            options=[
                                {'label': 'Delta GW',   'value': 'delta'},
                                {'label': 'Absolute GW', 'value': 'absolute'},
                            ],
                            value='delta',
                            inline=True,
                            style={'fontSize': '13px'},
                            inputStyle={'marginRight': '4px'},
                            labelStyle={'marginRight': '14px', 'cursor': 'pointer'},
                        ),
                    ]),

                    # Forecast date
                    html.Div([
                        html.Label("Forecast Date", style=_LABEL),
                        dcc.DatePickerSingle(
                            id='fcst-today-date',
                            date=today,
                            display_format='YYYY-MM-DD',
                            style={'fontSize': '13px'},
                        ),
                    ]),

                    # Reference date
                    html.Div([
                        html.Label("Reference Date", style=_LABEL),
                        dcc.DatePickerSingle(
                            id='fcst-ref-date',
                            date=yesterday,
                            display_format='YYYY-MM-DD',
                            style={'fontSize': '13px'},
                        ),
                    ]),

                    # Run button - checks S3, downloads missing from API
                    html.Button(
                        "Run",
                        id='fcst-run-btn',
                        n_clicks=0,
                        title="Load from S3 cache, download missing data from API",
                        style={
                            'padding': '8px 24px',
                            'backgroundColor': COLORS['accent'],
                            'color': 'white',
                            'border': 'none',
                            'borderRadius': '6px',
                            'cursor': 'pointer',
                            'fontWeight': '600',
                            'fontSize': '13px',
                        },
                    ),

                    # Status badge
                    html.Div(
                        id='fcst-status-badge',
                        style={
                            'fontSize': '12px',
                            'color': '#666',
                            'backgroundColor': '#f4f5f7',
                            'padding': '8px 14px',
                            'borderRadius': '6px',
                            'border': '1px solid #e1e4e8',
                            'alignSelf': 'center',
                        },
                    ),
                ],
            ),

            # ── Pivot table container with loading spinner ────────────
            dcc.Loading(
                id='fcst-loading',
                type='default',
                color=COLORS['accent'],
                children=[
                    html.Div(
                        id='fcst-grid-container',
                        style={'padding': '20px 28px', 'minHeight': '300px'},
                    ),
                ],
            ),
        ],
    )


# ═══════════════════════════════════════════════════════════════════════════
# Callbacks
# ═══════════════════════════════════════════════════════════════════════════

def register_weather_forecast_callbacks(app, data_handler=None):
    """Register interactive callbacks for the forecast monitor."""

    @app.callback(
        [Output('fcst-grid-container', 'children'),
         Output('fcst-status-badge', 'children'),
         Output('fcst-toast-store', 'data')],
        [Input('fcst-run-btn', 'n_clicks'),
         Input('fcst-model-select', 'value'),
         Input('fcst-display-mode', 'value'),
         Input('fcst-today-date', 'date'),
         Input('fcst-ref-date', 'date')],
    )
    def run_forecast_grid(
        n_clicks, model, display_mode, today_str, ref_str,
    ):
        """
        Main callback: Check S3 for data, download missing from API, build pivot table.
        Sends toast notifications for errors and warnings via fcst-toast-store.
        """
        variables = ['Residual Load']
        zones = DEFAULT_ZONES

        toasts = []

        if not model:
            return _empty_msg("Please select a model and click Run."), "", []

        if not CACHE_AVAILABLE:
            toasts.append(make_toast(
                "Forecast cache classes not available. Ensure jain_commods is installed.",
                level='error', source='Forecast Monitor',
            ))
            return _empty_msg(
                "Forecast cache classes not available. "
                "Ensure jain_commods is installed."
            ), "Cache unavailable", toasts

        # Parse dates
        today_date = _parse_date(today_str)
        ref_date   = _parse_date(ref_str)
        if today_date is None or ref_date is None:
            return _empty_msg("Invalid date selection."), "", []

        # Check S3 and download missing data for both dates
        status_parts = []
        
        # Check/download for forecast date
        loaded_today, downloaded_today, errors_today = check_and_download_forecast(
            model_name=model,
            issue_date=today_date,
            zones=zones,
            variables=variables,
        )
        
        # Check/download for reference date
        loaded_ref, downloaded_ref, errors_ref = check_and_download_forecast(
            model_name=model,
            issue_date=ref_date,
            zones=zones,
            variables=variables,
        )
        
        total_loaded = loaded_today + loaded_ref
        total_downloaded = downloaded_today + downloaded_ref
        total_errors = errors_today + errors_ref
        
        # Build status message
        if total_downloaded > 0:
            status_parts.append(f"{total_downloaded} downloaded")
        if total_loaded > 0:
            status_parts.append(f"{total_loaded} cached")
        if total_errors:
            status_parts.append(f"{len(total_errors)} errors")
            # Send toast for each error
            for err in total_errors:
                toasts.append(make_toast(
                    f"Data load failed: {err}",
                    level='error',
                    source=f'Forecast Monitor / {model}',
                ))

        # Build pivot data (flat list-of-lists for PivotTable)
        try:
            data, val_col, missing_dates = build_pivot_data(
                variables=variables,
                zones=zones,
                model_name=model,
                today_date=today_date,
                ref_date=ref_date,
                display_mode=display_mode,
            )
        except Exception as e:
            logger.error(f"Error building pivot data: {e}", exc_info=True)
            toasts.append(make_toast(
                f"Error building pivot data: {e}",
                level='error',
                source=f'Forecast Monitor / {model}',
            ))
            return _empty_msg(f"Error loading data: {e}"), "Error", toasts

        if len(data) <= 1:  # Only headers, no data rows
            toasts.append(make_toast(
                f"No data available for {model} ({today_date} vs {ref_date})",
                level='warning',
                source='Forecast Monitor',
            ))
            return _empty_msg("No data available for the selected parameters."), "", toasts

        # Send toast for missing dates
        if missing_dates:
            toasts.append(make_toast(
                f"Model not available for: {', '.join(missing_dates)}",
                level='warning',
                source=f'Forecast Monitor / {model}',
            ))

        # Count tenors for status
        tenors_in_data = set()
        for row in data[1:]:
            if len(row) >= 3:
                tenors_in_data.add(row[2])
        
        # Status badge
        status = f"{len(tenors_in_data)} tenors"
        if status_parts:
            status += f" | {', '.join(status_parts)}"

        # Build pivot table component with unique ID to force re-render
        # Pass missing_dates to show warning if needed
        pivot = _build_pivot(data, val_col, variables, model, today_date, ref_date, missing_dates)
        return pivot, status, toasts

    logger.info("Forecast monitor callbacks registered")


# ═══════════════════════════════════════════════════════════════════════════
# Pivot table builder
# ═══════════════════════════════════════════════════════════════════════════

def _build_pivot(
    data: List[List],
    val_col: str,
    variables: List[str],
    model_name: str,
    forecast_date: datetime.date,
    reference_date: datetime.date,
    missing_dates: List[str] = None,
):
    """Build a styled card wrapping the PivotTable component."""

    # Log what we're sending to the pivot table
    tenors = set()
    for row in data[1:]:  # Skip header
        if len(row) >= 3:
            tenors.add(row[2])
    logger.info(f"Building PivotTable with {len(tenors)} tenors: {sorted(tenors)}")
    logger.info(f"Data has {len(data)} total rows (including header)")
    
    # Generate a unique wrapper key to force React to completely re-mount
    # This is crucial because PivotTable keeps internal state
    unique_key = uuid.uuid4().hex
    
    # Default layout:
    #   - Columns: Variable, Zone (nested - shows all zones per variable)
    #   - Rows: Tenor (D+1, D+2, ..., WK+2)
    # This gives a compact view with tenors as rows and Variable/Zone combinations as columns
    pivot = dash_pivottable.PivotTable(
        id=f'fcst-pivot-{unique_key}',
        data=data,
        cols=['Variable', 'Zone'],  # Nested columns: Variable -> Zone
        rows=['Tenor'],              # Tenors as rows
        vals=[val_col],
        aggregatorName='Average',
        rendererName='Table Col Heatmap',  # Column heatmap with custom RdWhGn colors
        colOrder='key_a_to_z',
        rowOrder='key_a_to_z',
        menuLimit=500,
    )

    # Format header: "EC-ENS 00z  2026-02-12 vs 2026-02-11 (forecast - reference)"
    header_text = f"{model_name}  {forecast_date:%Y-%m-%d} vs {reference_date:%Y-%m-%d} (forecast - reference)"

    # Build children list - add warning banner if dates are missing
    children = []
    
    # Add warning banner if any dates have missing data
    if missing_dates:
        warning_text = f"Model is not available for date(s): {', '.join(missing_dates)}"
        children.append(
            html.Div(
                style={
                    'padding': '12px 20px',
                    'backgroundColor': '#fff3cd',
                    'borderBottom': '1px solid #ffecb5',
                    'color': '#856404',
                    'fontSize': '13px',
                    'fontWeight': '500',
                    'display': 'flex',
                    'alignItems': 'center',
                    'gap': '8px',
                },
                children=[
                    html.Span('⚠️', style={'fontSize': '16px'}),
                    html.Span(warning_text),
                ],
            )
        )
    
    # Add card header with model and date comparison
    children.append(
        html.Div(
            style={
                'padding': '12px 20px',
                'borderBottom': '1px solid #eaecef',
                'backgroundColor': '#f8f9fa',
                'display': 'flex',
                'alignItems': 'center',
                'justifyContent': 'space-between',
            },
            children=[
                html.Span(
                    header_text,
                    style={
                        'fontWeight': '600', 'fontSize': '14px',
                        'color': COLORS['text_primary'],
                    },
                ),
                html.Span(
                    f"{val_col}",
                    style={'fontSize': '12px', 'color': '#666', 'fontStyle': 'italic'},
                ),
            ],
        )
    )
    
    # Add PivotTable
    children.append(
        html.Div(
            children=[pivot],
            style={'padding': '12px'},
        )
    )

    # Wrap in a styled card with unique key to force complete re-render
    return html.Div(
        key=unique_key,
        style={
            'backgroundColor': '#ffffff',
            'borderRadius': '10px',
            'border': '1px solid #e1e4e8',
            'overflow': 'hidden',
            'boxShadow': '0 2px 6px rgba(0,0,0,0.06)',
        },
        children=children,
    )


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

_LABEL = {
    'fontSize': '11px',
    'fontWeight': '600',
    'color': '#666',
    'textTransform': 'uppercase',
    'letterSpacing': '0.5px',
    'marginBottom': '6px',
    'display': 'block',
}


def _empty_msg(text: str):
    return html.Div(
        text,
        style={
            'textAlign': 'center',
            'padding': '60px',
            'color': '#888',
            'fontSize': '15px',
            'fontStyle': 'italic',
        },
    )


def _parse_date(s) -> datetime.date:
    """Parse date string or date object."""
    if s is None:
        return None
    if isinstance(s, datetime.date):
        return s
    try:
        return datetime.date.fromisoformat(str(s)[:10])
    except Exception:
        return None
