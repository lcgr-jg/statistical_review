"""
Weather Threshold Probability
=============================
Next-week ensemble probabilities that at least N days are above or below a
selected GW threshold, styled for the Fundamental Overview dashboard.
"""

from __future__ import annotations

import datetime as dt
import logging
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, dcc, html

from core.cache import cached_result
from portal_pages.fundamentals.forecast_data_handler import (
    CACHE_AVAILABLE,
    DEFAULT_ZONES,
    MODEL_CONFIGS,
    SCENARIO_VARIABLE_CLASSES,
    _build_forecast_instance,
    _call_with_issue_params,
)
from portal_pages.fundamentals.styles import (
    CARD_STYLE,
    COLORS,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
    apply_chart_style,
)

logger = logging.getLogger(__name__)


VARIABLE_OPTIONS = [
    {"label": "Wind Generation", "value": "Wind"},
    {"label": "Solar Generation", "value": "Solar"},
    {"label": "Power Demand", "value": "Demand"},
    {"label": "Residual Load", "value": "Residual Load"},
]

COUNTRY_OPTIONS = [{"label": zone, "value": zone} for zone in DEFAULT_ZONES]
DEFAULT_MODEL = "EC-ENS 00z"
_DAILY_ENSEMBLE_CACHE = {}

_CONTROL_GRID_STYLE = {
    "display": "flex",
    "alignItems": "center",
    "gap": "18px",
    "flexWrap": "wrap",
}

_STATUS_STYLE = {
    "marginLeft": "auto",
    "fontSize": "13px",
    "color": COLORS["text_secondary"],
}


def get_layout(data_handler=None, **kwargs):
    """Return the threshold probability dashboard layout."""
    today = dt.date.today()
    model_options = [
        {"label": name, "value": name}
        for name in MODEL_CONFIGS
        if "ENS" in name.upper()
    ]
    if not model_options and DEFAULT_MODEL in MODEL_CONFIGS:
        model_options = [{"label": DEFAULT_MODEL, "value": DEFAULT_MODEL}]

    return html.Div(
        style={"padding": "0"},
        children=[
            html.Div(
                style={
                    "padding": "15px 20px",
                    "backgroundColor": COLORS["card_bg"],
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "display": "flex",
                    "alignItems": "center",
                    "gap": "20px",
                    "flexWrap": "wrap",
                },
                children=[
                    html.Div(
                        style={
                            "minWidth": "230px",
                            "paddingRight": "4px",
                        },
                        children=[
                            html.Div(
                                "Weather Threshold Probability",
                                style={
                                    "fontWeight": "700",
                                    "color": COLORS["text_primary"],
                                    "fontSize": "16px",
                                },
                            ),
                            html.Div(
                                "Next-week ensemble day-count probabilities",
                                style={"fontSize": "12px", "color": COLORS["text_secondary"]},
                            ),
                        ],
                    ),
                    html.Div(
                        style=_CONTROL_GRID_STYLE,
                        children=[
                            _control_dropdown(
                                "Model",
                                "wprob-model",
                                model_options,
                                DEFAULT_MODEL if DEFAULT_MODEL in MODEL_CONFIGS else (
                                    model_options[0]["value"] if model_options else None
                                ),
                            ),
                            _control_date("Issue Date", "wprob-issue-date", today),
                            _control_dropdown(
                                "Variable",
                                "wprob-variable",
                                VARIABLE_OPTIONS,
                                "Wind",
                            ),
                            _control_dropdown(
                                "Country",
                                "wprob-country",
                                COUNTRY_OPTIONS,
                                "DE" if "DE" in DEFAULT_ZONES else DEFAULT_ZONES[0],
                            ),
                            _control_number("Step (GW)", "wprob-threshold-step", 5),
                        ],
                    ),
                    html.Div(id="wprob-status", style=_STATUS_STYLE),
                ],
            ),
            dcc.Loading(
                id="wprob-loading",
                type="circle",
                color=COLORS["accent"],
                children=html.Div(
                    id="wprob-content",
                    style={"padding": "20px", "minHeight": "500px"},
                ),
            ),
        ],
    )


def register_weather_probability_callbacks(app, data_handler=None):
    """Register callbacks for the threshold probability subtab."""

    @app.callback(
        [Output("wprob-content", "children"), Output("wprob-status", "children")],
        [
            Input("wprob-model", "value"),
            Input("wprob-issue-date", "date"),
            Input("wprob-variable", "value"),
            Input("wprob-country", "value"),
            Input("wprob-threshold-step", "value"),
        ],
    )
    def update_probability_view(
        model_name,
        issue_date,
        variable,
        country,
        threshold_step,
    ):
        if not CACHE_AVAILABLE:
            return _empty_state("Forecast cache classes are not available."), "Cache unavailable"

        if not all([model_name, issue_date, variable, country]):
            return _empty_state("Select a model, issue date, variable, and country."), "Waiting for inputs"

        try:
            result = build_probability_result(
                model_name=model_name,
                issue_date=str(pd.to_datetime(issue_date).date()),
                variable=variable,
                country=country,
                threshold_step=float(threshold_step),
            )
        except Exception as exc:
            logger.exception("Failed to build weather probability view")
            return _empty_state(str(exc)), "Error"

        if result["status"] != "ok":
            return _empty_state(result["message"]), result["message"]

        return _render_result(result), _status_text(result)


@cached_result(ttl_seconds=3600, key_prefix="weather_probability")
def build_probability_result(
    model_name: str,
    issue_date: str,
    variable: str,
    country: str,
    threshold_step: float,
) -> Dict:
    """Load cached ensemble data and compute above/below day-count tables."""
    issue_dt = pd.to_datetime(issue_date).date()
    daily_df = _load_variable_ensemble_daily(model_name, issue_dt, variable)
    if daily_df is None or daily_df.empty:
        return {
            "status": "empty",
            "message": f"No {variable} ensemble data for {model_name} / {issue_dt}.",
        }

    members = _extract_country_members(daily_df, country.upper())
    if members is None or members.empty:
        return {"status": "empty", "message": f"No {country} member data for {variable}."}

    members = _prepare_daily_gw(members)
    weekday_dates, weekend_dates = _next_week_dates(issue_dt)
    thresholds, observed_max = _make_dynamic_thresholds(
        members,
        weekday_dates + weekend_dates,
        threshold_step,
    )

    windows = {
        "Weekdays": weekday_dates,
        "Weekend": weekend_dates,
    }
    tables = {}
    coverage = {}
    for window_name, dates in windows.items():
        table_above, available = _compute_probability_table(
            members,
            dates,
            thresholds,
            above=True,
        )
        table_below, _ = _compute_probability_table(
            members,
            dates,
            thresholds,
            above=False,
        )
        tables[(window_name, "Above")] = table_above
        tables[(window_name, "Below")] = table_below
        coverage[window_name] = {
            "requested_days": len(dates),
            "available_days": available,
            "date_range": _format_date_range(dates),
        }

    return {
        "status": "ok",
        "model_name": model_name,
        "issue_date": str(issue_dt),
        "variable": variable,
        "country": country.upper(),
        "thresholds": list(thresholds),
        "threshold_max": float(thresholds[-1]) if thresholds else None,
        "observed_max": observed_max,
        "member_count": int(len(members.columns)),
        "tables": tables,
        "coverage": coverage,
    }


def _load_variable_ensemble_daily(
    model_name: str,
    issue_date: dt.date,
    variable: str,
) -> pd.DataFrame | None:
    """Load one variable's ensemble data and cache daily means in-process."""
    cache_key = (model_name, str(issue_date), variable)
    if cache_key in _DAILY_ENSEMBLE_CACHE:
        return _DAILY_ENSEMBLE_CACHE[cache_key]

    if not CACHE_AVAILABLE or model_name not in MODEL_CONFIGS:
        return None
    if variable not in SCENARIO_VARIABLE_CLASSES:
        return None

    tag, version, is_mt = MODEL_CONFIGS[model_name]
    st_cls, mt_cls = SCENARIO_VARIABLE_CLASSES[variable]
    cls = mt_cls if is_mt else st_cls
    fcst = _build_forecast_instance(cls, tag, issue_date, version)

    loaded = False
    try:
        _call_with_issue_params(
            fcst.load,
            issue_date=issue_date,
            version=version,
            from_s3=True,
            normalized=False,
            show_metadata=False,
        )
        loaded = fcst.data is not None and not fcst.data.empty
    except Exception as exc:
        logger.info("S3 miss for %s/%s/%s: %s", variable, model_name, issue_date, exc)

    if not loaded:
        try:
            fcst.download(zones=DEFAULT_ZONES)
            loaded = fcst.data is not None and not fcst.data.empty
            if loaded:
                logger.info(
                    "Loaded %s/%s/%s from API for threshold probability; skipping S3 save",
                    variable,
                    model_name,
                    issue_date,
                )
        except Exception as exc:
            logger.warning("Failed to download %s/%s/%s: %s", variable, model_name, issue_date, exc)
            return None

    if not loaded:
        return None

    daily = fcst.data.resample("D").mean()
    _DAILY_ENSEMBLE_CACHE[cache_key] = daily
    return daily


def _extract_country_members(df: pd.DataFrame, country_iso: str) -> pd.DataFrame | None:
    """Return a flat member-column frame for one country from MultiIndex columns."""
    if isinstance(df.columns, pd.MultiIndex):
        country_cols = [col for col in df.columns if str(col[0]).upper() == country_iso]
        if country_cols:
            members = df[country_cols].copy()
            members.columns = [str(col[1]).upper() for col in country_cols]
            return members
    return None


def _control_dropdown(label, component_id, options, value):
    return html.Div(
        style={"display": "flex", "alignItems": "center", "gap": "8px"},
        children=[
            html.Label(
                f"{label}:",
                style={
                    "fontWeight": "600",
                    "color": COLORS["text_primary"],
                    "marginRight": "2px",
                    "whiteSpace": "nowrap",
                    "fontSize": "13px",
                },
            ),
            dcc.Dropdown(
                id=component_id,
                options=options,
                value=value,
                clearable=False,
                style={"fontSize": "13px", "minWidth": "135px"},
            ),
        ],
    )


def _control_date(label, component_id, value):
    return html.Div(
        style={"display": "flex", "alignItems": "center", "gap": "8px"},
        children=[
            html.Label(
                f"{label}:",
                style={
                    "fontWeight": "600",
                    "color": COLORS["text_primary"],
                    "marginRight": "2px",
                    "whiteSpace": "nowrap",
                    "fontSize": "13px",
                },
            ),
            dcc.DatePickerSingle(
                id=component_id,
                date=value,
                display_format="YYYY-MM-DD",
                style={"fontSize": "13px", "width": "160px"},
                first_day_of_week=1,
            ),
        ],
    )


def _control_number(label, component_id, value):
    return html.Div(
        style={"display": "flex", "alignItems": "center", "gap": "8px"},
        children=[
            html.Label(
                f"{label}:",
                style={
                    "fontWeight": "600",
                    "color": COLORS["text_primary"],
                    "marginRight": "2px",
                    "whiteSpace": "nowrap",
                    "fontSize": "13px",
                },
            ),
            dcc.Input(
                id=component_id,
                type="number",
                value=value,
                debounce=True,
                style={
                    "width": "100%",
                    "maxWidth": "78px",
                    "height": "38px",
                    "border": "1px solid #dfe3e8",
                    "borderRadius": "6px",
                    "padding": "6px 10px",
                    "fontSize": "13px",
                },
            ),
        ],
    )


def _make_dynamic_thresholds(
    members_gw: pd.DataFrame,
    dates: Sequence[dt.date],
    step,
) -> Tuple[List[float], float]:
    step = float(step)
    if step <= 0:
        raise ValueError("Threshold step must be greater than zero.")

    sample = members_gw.loc[members_gw.index.isin(dates)]
    if sample.empty:
        raise ValueError("No forecast values found for the selected next-week range.")

    observed_max = float(np.nanmax(sample.to_numpy(dtype=float)))
    if not np.isfinite(observed_max) or observed_max <= 0:
        raise ValueError("Forecast values are empty or non-positive for the selected range.")

    dynamic_max = np.ceil((observed_max * 1.2) / step) * step
    thresholds = np.arange(0, dynamic_max + step / 2.0, step)
    if len(thresholds) > 80:
        raise ValueError("Please use a coarser threshold step; maximum 80 rows.")
    return [round(float(x), 4) for x in thresholds], observed_max


def _next_week_dates(issue_date: dt.date) -> Tuple[List[dt.date], List[dt.date]]:
    days_until_monday = (7 - issue_date.weekday()) % 7
    if days_until_monday == 0:
        days_until_monday = 7
    next_monday = issue_date + dt.timedelta(days=days_until_monday)
    days = [next_monday + dt.timedelta(days=i) for i in range(7)]
    return days[:5], days[5:]


def _prepare_daily_gw(members: pd.DataFrame) -> pd.DataFrame:
    members = members.copy()
    idx = pd.to_datetime(members.index)
    if getattr(idx, "tz", None) is not None:
        idx = idx.tz_convert(None)
    members.index = idx.normalize().date

    # Forecast cache data is MW; the UI threshold convention is GW.
    members = members / 1000.0
    return members.sort_index()


def _compute_probability_table(
    members_gw: pd.DataFrame,
    dates: Sequence[dt.date],
    thresholds: Iterable[float],
    above: bool,
) -> Tuple[pd.DataFrame, int]:
    date_index = list(dates)
    sample = members_gw.loc[members_gw.index.isin(date_index)]
    available_days = int(len(set(sample.index)))
    columns = [f"{n} day" if n == 1 else f"{n} days" for n in range(1, len(date_index) + 1)]

    result = pd.DataFrame(index=list(thresholds), columns=columns, dtype=float)
    result.index.name = "Threshold (GW)"

    if sample.empty or sample.shape[1] == 0:
        return result, available_days

    for threshold in result.index:
        condition = sample >= threshold if above else sample <= threshold
        counts = condition.sum(axis=0)
        for n_days, column in enumerate(columns, start=1):
            result.loc[threshold, column] = float((counts >= n_days).mean() * 100.0)

    return result, available_days


def _render_result(result: Dict):
    return html.Div(
        children=[
            _summary_strip(result),
            _probability_table_card(result),
        ],
    )


def _summary_strip(result: Dict):
    items = [
        ("Issue", result["issue_date"]),
        ("Model", result["model_name"]),
        ("Country", result["country"]),
        ("Variable", result["variable"]),
        ("Members", f"{result['member_count']:,}"),
        ("Max Fcst", f"{result['observed_max']:.1f} GW"),
        ("Top Threshold", f"{result['threshold_max']:.1f} GW"),
    ]
    return html.Div(
        style={
            **CARD_STYLE,
            "display": "grid",
            "gridTemplateColumns": "repeat(auto-fit, minmax(120px, 1fr))",
            "gap": "0",
            "marginBottom": "16px",
            "overflow": "hidden",
        },
        children=[
            html.Div(
                style={
                    "padding": "13px 16px",
                    "borderRight": "1px solid #eef1f3",
                    "backgroundColor": "#ffffff",
                },
                children=[
                    html.Div(label, style={"fontSize": "11px", "fontWeight": "700", "color": COLORS["text_muted"], "textTransform": "uppercase"}),
                    html.Div(value, style={"fontSize": "14px", "fontWeight": "700", "color": COLORS["text_primary"]}),
                ],
            )
            for label, value in items
        ],
    )


def _probability_table_card(result: Dict):
    coverage = result["coverage"]
    title = (
        f"Next Week Threshold Probabilities - {result['country']} "
        f"{result['variable']} ({result['issue_date']})"
    )
    subtitle = (
        "Each cell is the probability that at least N days breach the threshold. "
        f"Weekdays: {coverage['Weekdays']['date_range']} | "
        f"Weekend: {coverage['Weekend']['date_range']}"
    )
    return html.Div(
        style={
            "fontFamily": "Calibri, Arial, sans-serif",
            "padding": "20px",
            "backgroundColor": "white",
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "8px",
            "boxShadow": "0 1px 3px rgba(0,0,0,0.04)",
        },
        children=[
            html.H2(
                title,
                style={
                    "color": "#333",
                    "fontSize": "18px",
                    "fontWeight": "700",
                    "margin": "0 0 4px",
                },
            ),
            html.Div(
                subtitle,
                style={"fontSize": "12px", "color": COLORS["text_secondary"], "marginBottom": "14px"},
            ),
            html.Div(
                style={"overflowX": "auto"},
                children=_probability_matrix_table(result),
            ),
        ],
    )


def _probability_matrix_table(result: Dict):
    tables = result["tables"]
    sections = [
        ("Weekdays Above", tables[("Weekdays", "Above")]),
        ("Weekdays Below", tables[("Weekdays", "Below")]),
        ("Weekend Above", tables[("Weekend", "Above")]),
        ("Weekend Below", tables[("Weekend", "Below")]),
    ]
    thresholds = sorted(sections[0][1].index, reverse=True)

    region_header = [
        html.Th("", style=_region_header_style()),
    ]
    for section_idx, (section_name, table) in enumerate(sections):
        if section_idx == 2:
            region_header.append(html.Th("", style=_divider_header_style()))
        region_header.append(
            html.Th(
                section_name,
                colSpan=len(table.columns),
                style=_region_header_style(),
            )
        )

    day_header = [
        html.Th("Threshold", style=_country_header_style()),
    ]
    for section_idx, (_, table) in enumerate(sections):
        if section_idx == 2:
            day_header.append(html.Th("", style=_divider_header_style()))
        day_header.extend(
            html.Th(column, style=_country_header_style())
            for column in table.columns
        )

    body_rows = []
    for threshold in thresholds:
        cells = [
            html.Th(
                f"{threshold:g}",
                style={
                    **_row_header_style(),
                    "backgroundColor": "#f8f9fa",
                    "fontWeight": "700",
                },
            )
        ]
        for section_idx, (_, table) in enumerate(sections):
            if section_idx == 2:
                cells.append(html.Td("", style=_divider_cell_style()))
            for column in table.columns:
                value = table.loc[threshold, column]
                cells.append(
                    html.Td(
                        "" if pd.isna(value) else f"{value:.0f}%",
                        style={
                            **_data_cell_style(),
                            **_probability_cell_style(value),
                        },
                    )
                )
        body_rows.append(html.Tr(cells))

    return html.Table(
        style={
            "borderCollapse": "collapse",
            "fontFamily": "Calibri, Arial, sans-serif",
            "fontSize": "13px",
            "width": "100%",
            "border": "1px solid #ddd",
            "tableLayout": "fixed",
        },
        children=[
            html.Thead([html.Tr(region_header), html.Tr(day_header)]),
            html.Tbody(body_rows),
        ],
    )


def _region_header_style():
    return {
        "backgroundColor": "#e9ecef",
        "fontSize": "11px",
        "fontWeight": "700",
        "padding": "5px 3px",
        "border": "1px solid #999",
        "textAlign": "center",
        "color": "#333",
    }


def _country_header_style():
    return {
        "backgroundColor": "#f8f9fa",
        "fontSize": "10px",
        "fontWeight": "700",
        "padding": "4px 2px",
        "border": "1px solid #999",
        "textAlign": "center",
        "color": "#333",
    }


def _divider_header_style():
    return {
        "backgroundColor": "#ffffff",
        "borderLeft": "3px solid #000000",
        "borderRight": "3px solid #000000",
        "borderTop": "1px solid #999",
        "borderBottom": "1px solid #999",
        "padding": "0",
        "width": "14px",
        "minWidth": "14px",
        "maxWidth": "14px",
    }


def _divider_cell_style():
    return {
        "backgroundColor": "#ffffff",
        "borderLeft": "3px solid #000000",
        "borderRight": "3px solid #000000",
        "borderTop": "1px solid #ffffff",
        "borderBottom": "1px solid #ffffff",
        "padding": "0",
        "width": "14px",
        "minWidth": "14px",
        "maxWidth": "14px",
    }


def _row_header_style():
    return {
        "border": "1px solid #ddd",
        "padding": "3px 4px",
        "textAlign": "center",
        "fontSize": "11px",
        "minWidth": "56px",
        "color": "#333",
    }


def _data_cell_style():
    return {
        "border": "1px solid #ddd",
        "padding": "3px 2px",
        "textAlign": "center",
        "fontSize": "11px",
        "minWidth": "42px",
    }


def _probability_cell_style(value):
    if pd.isna(value):
        return {"backgroundColor": "#e0e0e0", "color": "#777"}

    # Approximate EPEX's RdYlGn_r table palette: low green, mid yellow, high red.
    anchors = [
        (0.0, (26, 150, 65)),
        (25.0, (166, 217, 106)),
        (50.0, (255, 255, 191)),
        (75.0, (253, 174, 97)),
        (100.0, (215, 48, 39)),
    ]
    rgb = _interpolate_rgb(float(value), anchors)
    text_color = "#ffffff" if value >= 82 or value <= 12 else "#111111"
    return {"backgroundColor": f"rgb({rgb[0]}, {rgb[1]}, {rgb[2]})", "color": text_color}


def _interpolate_rgb(value: float, anchors: List[Tuple[float, Tuple[int, int, int]]]) -> Tuple[int, int, int]:
    value = max(0.0, min(100.0, value))
    for idx in range(1, len(anchors)):
        lo_value, lo_rgb = anchors[idx - 1]
        hi_value, hi_rgb = anchors[idx]
        if value <= hi_value:
            span = hi_value - lo_value
            weight = 0.0 if span == 0 else (value - lo_value) / span
            return tuple(
                int(round(lo_rgb[channel] + (hi_rgb[channel] - lo_rgb[channel]) * weight))
                for channel in range(3)
            )
    return anchors[-1][1]


def _heatmap_card(title: str, subtitle: str, fig: go.Figure):
    return html.Div(
        style={**CARD_STYLE, "marginBottom": "0"},
        children=[
            html.Div(
                style={
                    "padding": "14px 18px",
                    "borderBottom": "1px solid #e8edf0",
                    "backgroundColor": "#fbfcfd",
                },
                children=[
                    html.Div(
                        title,
                        style={
                            "fontSize": "14px",
                            "fontWeight": "700",
                            "color": COLORS["text_primary"],
                            "letterSpacing": "0.2px",
                        },
                    ),
                    html.Div(
                        subtitle,
                        style={
                            "fontSize": "12px",
                            "color": COLORS["text_muted"],
                            "marginTop": "2px",
                        },
                    ),
                ],
            ),
            dcc.Graph(figure=fig, config={"displayModeBar": False}),
        ],
    )


def _make_heatmap(table: pd.DataFrame, direction: str) -> go.Figure:
    z = table.to_numpy(dtype=float)
    text = np.where(np.isnan(z), "", np.vectorize(lambda x: f"{x:.0f}%")(np.nan_to_num(z)))

    colorscale = (
        [[0.0, "#f7f9fa"], [0.25, "#dcebf2"], [0.5, "#9ec3d3"], [0.75, "#4E738A"], [1.0, "#203f52"]]
        if direction == "Above"
        else [[0.0, "#faf9f4"], [0.25, "#efe2c7"], [0.5, "#d5b66f"], [0.75, "#9a7435"], [1.0, "#5d421f"]]
    )

    fig = go.Figure(
        data=go.Heatmap(
            z=z,
            x=list(table.columns),
            y=[f"{x:g}" for x in table.index],
            colorscale=colorscale,
            zmin=0,
            zmax=100,
            text=text,
            texttemplate="%{text}",
            hovertemplate="Threshold %{y} GW<br>%{x}: %{z:.1f}%<extra></extra>",
            colorbar={"title": "%", "len": 0.82},
        )
    )
    fig.update_layout(
        title=None,
        xaxis_title="At least N days",
        yaxis_title="Threshold (GW)",
        margin=dict(l=68, r=24, t=18, b=52),
    )
    fig.update_xaxes(side="top")
    return apply_chart_style(fig, height=360)


def _format_date_range(dates: Sequence[dt.date]) -> str:
    if not dates:
        return "No dates"
    if len(dates) == 1:
        return dates[0].strftime("%d %b %Y")
    return f"{dates[0].strftime('%d %b')} - {dates[-1].strftime('%d %b %Y')}"


def _status_text(result: Dict) -> str:
    weekday = result["coverage"]["Weekdays"]
    weekend = result["coverage"]["Weekend"]
    return (
        f"{result['member_count']:,} members | "
        f"Weekdays {weekday['available_days']}/{weekday['requested_days']} days | "
        f"Weekend {weekend['available_days']}/{weekend['requested_days']} days"
    )


def _empty_state(message: str):
    return html.Div(
        style={
            **CARD_STYLE,
            "padding": "42px 30px",
            "textAlign": "center",
            "color": COLORS["text_secondary"],
        },
        children=[
            html.Div(
                "No probability matrix",
                style={
                    "fontSize": "18px",
                    "fontWeight": "700",
                    "color": COLORS["text_primary"],
                    "marginBottom": "8px",
                },
            ),
            html.Div(message, style={"fontSize": "13px"}),
        ],
    )
