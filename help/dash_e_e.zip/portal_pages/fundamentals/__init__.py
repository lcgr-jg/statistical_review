"""Portal-owned copies of fundamentals page code."""
