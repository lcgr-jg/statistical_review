"""
Reader for the weather_forecasts issue-dated run store.
=======================================================

The ``weather_forecasts`` Dagster code location persists one parquet per
(model, run) under ``weather_forecasts/runs/{model}/{run_key}.parquet`` in the
house S3 bucket. Each file holds the full country-level series for that run:

    model | run_key | init_time | valid_time | lead_hours
          | country | variable  | value_mean | value_std
          | p10 | p25 | p50 | p75 | p90

``variable`` is ``cwg`` (population-weighted temperature, degC) or ``cww``
(capacity-weighted 100m/10m wind speed, m/s). ``value_std`` is the ensemble
spread and is 0 for deterministic models.

The percentile columns are schema v3 and nullable: WeatherNext 3 publishes
percentiles rather than a standard deviation, so for that model ``value_std``
is NaN and spread has to be derived from ``p10``/``p90``. Parquet written
before v3 has no percentile columns at all, hence ``_conform`` below.

This module reads those parquets directly rather than importing the
``weather_forecasts`` package, so the dashboard image does not need the GRIB
toolchain. Deltas and revision history are derived views computed here.
"""
from __future__ import annotations

import io
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from core.cache import cached_result

logger = logging.getLogger(__name__)

S3_PREFIX = "weather_forecasts/runs"

# Display order matters: AIFS-ENS is the primary ensemble.
MODELS: List[str] = ["AIFS-ENS", "AIGEFS", "WeatherNext3", "WeatherNext2"]

MODEL_DIR: Dict[str, str] = {
    "AIFS-ENS": "aifs_ens",
    "AIGEFS": "aigefs",
    "WeatherNext2": "weathernext2",
    "WeatherNext3": "weathernext3",
}

MODEL_LABEL: Dict[str, str] = {
    "AIFS-ENS": "ECMWF AIFS-ENS",
    "AIGEFS": "NCEP AIGEFS",
    "WeatherNext2": "Google WeatherNext 2",
    "WeatherNext3": "Google WeatherNext 3",
}

VARIABLES: Dict[str, Dict[str, str]] = {
    "cwg": {
        "label": "Temperature (CWG)",
        "short": "CWG",
        "unit": "\u00b0C",
        "delta_unit": "\u0394\u00b0C",
        "description": "Population-weighted 2m temperature",
    },
    "cww": {
        "label": "Wind speed (CWW)",
        "short": "CWW",
        "unit": "m/s",
        "delta_unit": "\u0394m/s",
        "description": "Capacity-weighted wind speed",
    },
}

# Deterministic models carry no spread, so z-scores are undefined for them.
DETERMINISTIC_MODELS = {"AIGEFS"}

# Schema v3, nullable. Only models that publish percentiles populate these.
PERCENTILE_COLUMNS: List[str] = ["p10", "p25", "p50", "p75", "p90"]


def _conform(df: pd.DataFrame) -> pd.DataFrame:
    """Give *df* the full v3 column set so pre-v3 parquet reads the same."""
    for col in PERCENTILE_COLUMNS:
        if col not in df.columns:
            df[col] = np.nan
    return df


def spread_of(df: pd.DataFrame) -> pd.Series:
    """Best available dispersion per row, in the value's own units.

    Prefers a published standard deviation. Where there is none, falls back to
    half the interdecile range, which is the same quantity for a normal
    distribution but does not assume one.
    """
    std = pd.to_numeric(df.get("value_std"), errors="coerce")
    if "p10" in df.columns and "p90" in df.columns:
        p10 = pd.to_numeric(df["p10"], errors="coerce")
        p90 = pd.to_numeric(df["p90"], errors="coerce")
        return std.fillna((p90 - p10) / 2.0)
    return std


# ---------------------------------------------------------------------------
# Backends
# ---------------------------------------------------------------------------

def _s3():
    """Return the jain_commods S3 helper, or None when unavailable."""
    try:
        from jain_commods.core.cache.utils.s3 import S3
        return S3()
    except Exception as e:  # noqa: BLE001 - import or credential failure
        logger.warning("jain_commods S3 unavailable for met run store: %s", e)
        return None


def _local_root() -> Optional[Path]:
    """Local parquet root, when one is configured (dev convenience)."""
    raw = os.environ.get("WF_RUN_STORE_LOCAL")
    if not raw:
        return None
    path = Path(raw)
    return path if path.exists() else None


def _model_dir(model: str) -> str:
    return MODEL_DIR.get(model, model.lower().replace("-", "_"))


# ---------------------------------------------------------------------------
# Raw reads
# ---------------------------------------------------------------------------

@cached_result(ttl_seconds=900, key_prefix="met_run_keys")
def list_runs(model: str) -> List[str]:
    """Sorted run keys (``YYYYMMDD_HH``) available for *model*, newest last."""
    keys = set()

    root = _local_root()
    if root is not None:
        local_dir = root / _model_dir(model)
        if local_dir.exists():
            keys.update(p.stem for p in local_dir.glob("*.parquet"))

    s3 = _s3()
    if s3 is not None:
        try:
            for fname in s3.list_files(f"{S3_PREFIX}/{_model_dir(model)}"):
                if fname.endswith(".parquet"):
                    keys.add(fname[: -len(".parquet")])
        except Exception as e:  # noqa: BLE001
            logger.warning("S3 listing failed for %s: %s", model, e)

    return sorted(keys)


@cached_result(ttl_seconds=3600, key_prefix="met_run_series")
def load_run(model: str, run_key: str) -> Optional[pd.DataFrame]:
    """Load one run's country series. Local first (dev), then S3."""
    root = _local_root()
    if root is not None:
        path = root / _model_dir(model) / f"{run_key}.parquet"
        if path.exists():
            return _conform(pd.read_parquet(path))

    s3 = _s3()
    if s3 is None:
        return None
    try:
        raw = s3.read(f"{S3_PREFIX}/{_model_dir(model)}/{run_key}.parquet")
        return _conform(pd.read_parquet(io.BytesIO(raw)))
    except Exception as e:  # noqa: BLE001
        logger.warning("Could not read %s run %s: %s", model, run_key, e)
        return None


# ---------------------------------------------------------------------------
# Derived views
# ---------------------------------------------------------------------------

def latest_run_pair(model: str) -> Tuple[Optional[str], Optional[str]]:
    """The two most recent run keys for *model* (latest, previous)."""
    runs = list_runs(model)
    if len(runs) < 2:
        return (runs[-1] if runs else None), None
    return runs[-1], runs[-2]


@cached_result(ttl_seconds=1800, key_prefix="met_run_delta")
def compute_delta(model: str, latest_key: str, previous_key: str) -> Optional[pd.DataFrame]:
    """Run-over-run delta on the valid times the two runs share.

    Returns columns: country, variable, valid_time, lead_hours, latest,
    previous, delta, spread, z_score.
    """
    latest = load_run(model, latest_key)
    previous = load_run(model, previous_key)
    if latest is None or previous is None or latest.empty or previous.empty:
        return None

    merged = latest.merge(
        previous[["country", "variable", "valid_time", "value_mean"]],
        on=["country", "variable", "valid_time"],
        how="inner",
        suffixes=("", "_prev"),
    )
    if merged.empty:
        return None

    # Derive the spread before the rename, while the source columns are intact.
    merged["spread"] = spread_of(merged)
    merged = merged.rename(columns={
        "value_mean": "latest",
        "value_mean_prev": "previous",
    })
    merged["delta"] = merged["latest"] - merged["previous"]

    # A delta only carries signal relative to the ensemble's own uncertainty.
    spread = merged["spread"].to_numpy(dtype=float)
    merged["z_score"] = np.where(
        spread > 1e-6, merged["delta"].to_numpy(dtype=float) / spread, np.nan,
    )

    cols = ["country", "variable", "valid_time", "lead_hours",
            "latest", "previous", "delta", "spread", "z_score"]
    return merged[cols].sort_values(["variable", "country", "valid_time"])


@cached_result(ttl_seconds=1800, key_prefix="met_run_revisions")
def revision_history(model: str, country: str, variable: str,
                     n_runs: int = 12) -> Optional[pd.DataFrame]:
    """How successive runs have forecast each valid time.

    Returns one row per (run_key, valid_time) across the last *n_runs* runs,
    which is what a backtest of forecast drift needs.
    """
    runs = list_runs(model)[-n_runs:]
    if not runs:
        return None

    frames = []
    for run_key in runs:
        df = load_run(model, run_key)
        if df is None or df.empty:
            continue
        sub = df[(df["country"] == country) & (df["variable"] == variable)]
        if sub.empty:
            continue
        sub = sub.copy()
        # Carried so a plot can shade a band for models that publish no std.
        sub["spread"] = spread_of(sub)
        frames.append(sub[["run_key", "init_time", "valid_time", "lead_hours",
                           "value_mean", "value_std", "spread",
                           *PERCENTILE_COLUMNS]])

    if not frames:
        return None
    return pd.concat(frames, ignore_index=True).sort_values(["init_time", "valid_time"])


@cached_result(ttl_seconds=900, key_prefix="met_run_status")
def store_status() -> List[Dict[str, object]]:
    """Per-model summary of what is in the store, for the status strip."""
    status = []
    for model in MODELS:
        runs = list_runs(model)
        latest_init = None
        if runs:
            try:
                latest_init = pd.to_datetime(runs[-1], format="%Y%m%d_%H", utc=True)
            except ValueError:
                latest_init = None
        status.append({
            "model": model,
            "label": MODEL_LABEL.get(model, model),
            "n_runs": len(runs),
            "latest_run": runs[-1] if runs else None,
            "previous_run": runs[-2] if len(runs) > 1 else None,
            "latest_init": latest_init,
        })
    return status


def available_countries(model: str, run_key: Optional[str] = None) -> List[str]:
    """Countries present in a run (defaults to the latest run)."""
    if run_key is None:
        runs = list_runs(model)
        if not runs:
            return []
        run_key = runs[-1]
    df = load_run(model, run_key)
    if df is None or df.empty:
        return []
    return sorted(df["country"].unique().tolist())


def format_run_key(run_key: Optional[str]) -> str:
    """``20260910_06`` -> ``10 Sep 06z``."""
    if not run_key:
        return "\u2013"
    try:
        ts = pd.to_datetime(run_key, format="%Y%m%d_%H", utc=True)
    except ValueError:
        return run_key
    return f"{ts:%d %b} {ts:%H}z"
