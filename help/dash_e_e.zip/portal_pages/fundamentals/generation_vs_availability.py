"""
Fundamentals Dashboard - Generation vs Availability page
=========================================================
Compares actual generation against REMIT availability per fuel type.
Styled to match the Fuel Switching dashboard.
"""
import dash
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime
import logging

from portal_pages.fundamentals.styles import (
    COLORS, FUEL_COLORS, CHART_FONT, CHART_TEMPLATE,
    CARD_STYLE, CARD_HEADER_STYLE, CARD_HEADER_TEXT_STYLE,
    CONTROL_PANEL_STYLE, LABEL_STYLE,
    apply_chart_style, styled_empty_figure,
)

# Import enterprise caching
from core.cache import cached_result

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PRIORITY_COUNTRIES = ['DE', 'FR', 'UK', 'NL', 'BE']

MAIN_FUEL_TYPES = [
    'nuclear',
    'fossil gas',
    'fossil hard coal',
    'fossil brown coal/lignite',
]

_EXCLUDE = {
    'DE': {'nuclear'},
    'UK': {'fossil hard coal', 'fossil brown coal/lignite'},
}


# ---------------------------------------------------------------------------
# Chart creation
# ---------------------------------------------------------------------------

@cached_result(ttl_seconds=3600, key_prefix="gen_fig")
def create_generation_figure(data_handler, country, fuel_type):
    """Build a generation-vs-availability chart for *country / fuel_type*.
    
    Cached for 1 hour to avoid re-rendering identical charts.
    """
    try:
        merged = data_handler.get_merged_data(country, fuel_type)
        if merged is None or merged.empty:
            return styled_empty_figure(f'No data for {country} \u2013 {fuel_type}')

        merged = merged.sort_values('TIMESTAMP').copy()

        # Convert float64 → float32 for memory
        for col in merged.select_dtypes(include=['float64']).columns:
            merged[col] = merged[col].astype('float32')

        base_hex = FUEL_COLORS.get(fuel_type, COLORS['accent'])
        r, g, b = int(base_hex[1:3], 16), int(base_hex[3:5], 16), int(base_hex[5:7], 16)

        fig = go.Figure()

        # Availability trace
        avail_coverage = merged['AVAILABILITY_AMOUNT'].notna().mean() * 100
        fig.add_trace(go.Scatter(
            x=merged['TIMESTAMP'],
            y=merged['AVAILABILITY_AMOUNT'],
            mode='lines',
            name=f'Availability ({avail_coverage:.0f}%)',
            line=dict(color=base_hex, width=2),
            fill='tozeroy',
            fillcolor=f'rgba({r},{g},{b},0.10)',
        ))

        # Generation trace
        gen_coverage = merged['GENERATION'].notna().mean() * 100
        fig.add_trace(go.Scatter(
            x=merged['TIMESTAMP'],
            y=merged['GENERATION'],
            mode='lines',
            name=f'Generation ({gen_coverage:.0f}%)',
            line=dict(color=COLORS['danger'], width=1.8),
        ))

        # Style
        apply_chart_style(fig, height=400)
        fig.update_layout(
            yaxis_title=dict(text='Power (MW)'),
            xaxis=dict(
                tickformat='%b %Y',
                rangeselector=dict(
                    buttons=[
                        dict(count=1, label='1 M', step='month', stepmode='backward'),
                        dict(count=3, label='3 M', step='month', stepmode='backward'),
                        dict(count=6, label='6 M', step='month', stepmode='backward'),
                        dict(step='all', label='All'),
                    ],
                    bgcolor=COLORS['card_bg_alt'],
                    activecolor=COLORS['accent'],
                    font=dict(size=11),
                ),
            ),
        )

        # Y-axis range
        y_max = max(
            merged['AVAILABILITY_AMOUNT'].max() if merged['AVAILABILITY_AMOUNT'].notna().any() else 0,
            merged['GENERATION'].max() if merged['GENERATION'].notna().any() else 0,
        )
        if y_max > 0:
            fig.update_yaxes(range=[0, y_max * 1.1])

        return fig

    except Exception as e:
        logger.error(f'Error creating generation figure for {country}-{fuel_type}: {e}')
        return styled_empty_figure(f'Error: {e}')


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def get_layout(data_handler, country='DE'):
    """Return styled generation-vs-availability layout with dynamic chart rendering."""

    countries = data_handler.get_countries() if data_handler.is_ready else PRIORITY_COUNTRIES
    all_fuel_types = data_handler.get_fuel_types(country) if data_handler.is_ready else []
    excluded = _EXCLUDE.get(country, set())

    fuel_types = []
    for ft in MAIN_FUEL_TYPES:
        if ft in all_fuel_types and ft not in excluded:
            try:
                df = data_handler.get_merged_data(country, ft)
                if (not df.empty and 'GENERATION' in df.columns and
                        not df['GENERATION'].isna().all() and
                        not (df['GENERATION'] == 0).all()):
                    fuel_types.append(ft)
            except Exception:
                pass
    other_fuel_types = [ft for ft in all_fuel_types if ft not in MAIN_FUEL_TYPES]

    initial_cards = []
    for ft in fuel_types:
        fig = create_generation_figure(data_handler, country, ft)
        accent = FUEL_COLORS.get(ft, COLORS['accent'])
        initial_cards.append(
            html.Div(style=CARD_STYLE, children=[
                html.Div(style={'display': 'flex', 'alignItems': 'stretch'}, children=[
                    html.Div(style={
                        'width': '4px',
                        'backgroundColor': accent,
                        'borderRadius': '12px 0 0 0',
                    }),
                    html.Div(style={**CARD_HEADER_STYLE, 'flex': '1'}, children=[
                        html.H4(ft.title(), style=CARD_HEADER_TEXT_STYLE),
                        html.Span(
                            f'{country}',
                            style={'fontSize': '12px', 'color': COLORS['text_muted'], 'marginLeft': '12px'},
                        ),
                    ]),
                ]),
                dcc.Graph(figure=fig, config={'displayModeBar': False}),
            ]),
        )

    for ft in other_fuel_types:
        try:
            df = data_handler.get_merged_data(country, ft)
            if df.empty or 'GENERATION' not in df.columns or df['GENERATION'].isna().all():
                continue
        except Exception:
            continue
        fig = create_generation_figure(data_handler, country, ft)
        initial_cards.append(
            html.Div(style=CARD_STYLE, children=[
                html.Div(style=CARD_HEADER_STYLE, children=[
                    html.H4(ft.title(), style={**CARD_HEADER_TEXT_STYLE, 'color': COLORS['text_muted']}),
                ]),
                dcc.Graph(figure=fig, config={'displayModeBar': False}),
            ]),
        )

    if not initial_cards:
        initial_cards = [html.Div(
            style={'textAlign': 'center', 'padding': '60px', 'color': COLORS['text_muted']},
            children='No generation vs availability data for this country.',
        )]
    initial_fuel_count = f'Comparing REMIT availability vs actual generation • {len(fuel_types)} fuel types'

    return html.Div([
        # Control panel
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div(style={'display': 'flex', 'alignItems': 'flex-end', 'gap': '24px', 'flexWrap': 'wrap'}, children=[
                html.Div([
                    html.Label('Country', style=LABEL_STYLE),
                    dcc.Dropdown(
                        id='gen-country-select',
                        options=[{'label': c, 'value': c} for c in countries],
                        value=country,
                        clearable=False,
                        style={'width': '140px'},
                    ),
                ]),
                html.Div(style={'flex': '1'}),
                html.Div(id='gen-fuel-count', children=initial_fuel_count, style={'fontSize': '12px', 'color': COLORS['text_muted']}),
            ]),
        ]),

        # Chart cards container (populated by callback)
        dcc.Loading(
            type='circle', color=COLORS['accent'],
            children=[html.Div(id='gen-charts-container', children=initial_cards)],
        ),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_generation_callbacks(app, data_handler):
    """Register interactive callbacks."""

    @app.callback(
        [Output('gen-charts-container', 'children'),
         Output('gen-fuel-count', 'children')],
        Input('gen-country-select', 'value'),
    )
    def update_charts(country):
        """Update charts when country selection changes."""
        if not country or not data_handler.is_ready:
            return [html.Div(
                style={'textAlign': 'center', 'padding': '60px', 'color': COLORS['text_muted']},
                children='Loading data...',
            )], ''

        all_fuel_types = data_handler.get_fuel_types(country)
        excluded = _EXCLUDE.get(country, set())

        # Only show fuel types that actually have generation data
        fuel_types = []
        for ft in MAIN_FUEL_TYPES:
            if ft in all_fuel_types and ft not in excluded:
                try:
                    df = data_handler.get_merged_data(country, ft)
                    if (not df.empty and 'GENERATION' in df.columns and
                            not df['GENERATION'].isna().all() and
                            not (df['GENERATION'] == 0).all()):
                        fuel_types.append(ft)
                except Exception:
                    pass

        other_fuel_types = [ft for ft in all_fuel_types if ft not in MAIN_FUEL_TYPES]

        # Build chart cards
        chart_cards = []
        for ft in fuel_types:
            fig = create_generation_figure(data_handler, country, ft)
            accent = FUEL_COLORS.get(ft, COLORS['accent'])
            chart_cards.append(
                html.Div(style=CARD_STYLE, children=[
                    html.Div(style={'display': 'flex', 'alignItems': 'stretch'}, children=[
                        html.Div(style={
                            'width': '4px',
                            'backgroundColor': accent,
                            'borderRadius': '12px 0 0 0',
                        }),
                        html.Div(style={**CARD_HEADER_STYLE, 'flex': '1'}, children=[
                            html.H4(ft.title(), style=CARD_HEADER_TEXT_STYLE),
                            html.Span(
                                f'{country}',
                                style={'fontSize': '12px', 'color': COLORS['text_muted'], 'marginLeft': '12px'},
                            ),
                        ]),
                    ]),
                    dcc.Graph(figure=fig, config={'displayModeBar': False}),
                ]),
            )

        # Other fuel types
        for ft in other_fuel_types:
            try:
                df = data_handler.get_merged_data(country, ft)
                if df.empty or 'GENERATION' not in df.columns or df['GENERATION'].isna().all():
                    continue
            except Exception:
                continue
            fig = create_generation_figure(data_handler, country, ft)
            chart_cards.append(
                html.Div(style=CARD_STYLE, children=[
                    html.Div(style=CARD_HEADER_STYLE, children=[
                        html.H4(ft.title(), style={**CARD_HEADER_TEXT_STYLE, 'color': COLORS['text_muted']}),
                    ]),
                    dcc.Graph(figure=fig, config={'displayModeBar': False}),
                ]),
            )

        if not chart_cards:
            chart_cards = [html.Div(
                style={'textAlign': 'center', 'padding': '60px', 'color': COLORS['text_muted']},
                children='No generation vs availability data for this country.',
            )]

        fuel_count_text = f'Comparing REMIT availability vs actual generation \u2022 {len(fuel_types)} fuel types'

        return chart_cards, fuel_count_text
