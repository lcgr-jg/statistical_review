"""
Forecast Data Handler
─────────────────────
Loads forecast data from S3 cache, aggregates hourly values to tradeable
power tenors, and computes forecast-on-forecast deltas.

Used by the Power Forecast Monitor dashboard page.
"""
import datetime
import logging
import threading
from typing import Dict, List, Optional, Tuple, Any

import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

# ── Data quality & freshness tracking ──────────────────────────────────────
try:
    from core.data_quality import validate_forecast
    from core.data_freshness import tracker as freshness_tracker
    DQ_AVAILABLE = True
except ImportError:
    DQ_AVAILABLE = False

# ── Import forecast cache classes ──────────────────────────────────────────
try:
    from jain_commods.core.cache.data.fundamentals import (
        ConsFcstST, ConsFcstMT, ConsFcstSTEns, ConsFcstMTEns,
        GenWindFcstST, GenWindFcstMT, GenWindFcstSTEns, GenWindFcstMTEns,
        GenSolarFcstST, GenSolarFcstMT, GenSolarFcstSTEns, GenSolarFcstMTEns,
        ResLoadFcstST, ResLoadFcstMT, ResLoadFcstSTEns, ResLoadFcstMTEns,
        ModelTag, IssueVersion,
    )
    CACHE_AVAILABLE = True
except ImportError:
    logger.warning("Could not import forecast cache classes from jain_commods")
    CACHE_AVAILABLE = False


# ── Configuration ──────────────────────────────────────────────────────────

# Variable display name → (ShortTerm curve class, MediumTerm curve class)
VARIABLE_CLASSES: Dict[str, tuple] = {}
SCENARIO_VARIABLE_CLASSES: Dict[str, tuple] = {}
if CACHE_AVAILABLE:
    VARIABLE_CLASSES = {
        'Wind':          (GenWindFcstST,  GenWindFcstMT),
        'Solar':         (GenSolarFcstST, GenSolarFcstMT),
        'Demand':        (ConsFcstST,     ConsFcstMT),
        'Residual Load': (ResLoadFcstST,  ResLoadFcstMT),
    }

    # Variable display name → (ShortTerm ensemble/scenario class, MediumTerm ensemble/scenario class)
    SCENARIO_VARIABLE_CLASSES = {
        'Wind':          (GenWindFcstSTEns,  GenWindFcstMTEns),
        'Solar':         (GenSolarFcstSTEns, GenSolarFcstMTEns),
        'Demand':        (ConsFcstSTEns,     ConsFcstMTEns),
        'Residual Load': (ResLoadFcstSTEns,  ResLoadFcstMTEns),
    }

# Model display name → (ModelTag, IssueVersion, is_medium_term)
MODEL_CONFIGS = {}
if CACHE_AVAILABLE:
    MODEL_CONFIGS = {
        'EC 00z':      (ModelTag.EC,      IssueVersion.IV00, False),
        'EC 12z':      (ModelTag.EC,      IssueVersion.IV12, False),
        'EC-ENS 00z':  (ModelTag.EC_ENS,  IssueVersion.IV00, False),
        'EC-ENS 12z':  (ModelTag.EC_ENS,  IssueVersion.IV12, False),
        'GFS 00z':     (ModelTag.GFS,     IssueVersion.IV00, False),
        'GFS-ENS 00z': (ModelTag.GFS_ENS, IssueVersion.IV00, False),
        'EC-EXT 00z':  (ModelTag.EC_EXT,  IssueVersion.IV00, True),
        'GFS-EXT 00z': (ModelTag.GFS_EXT, IssueVersion.IV00, True),
    }

DEFAULT_ZONES = ['DE', 'FR', 'NL', 'GB', 'ES', 'BE', 'IT', 'AT', 'HU']
ALL_VARIABLES = ['Wind', 'Solar', 'Demand', 'Residual Load']


def _normalize_issue_date(issue_date: Any) -> datetime.date:
    """Normalize date-like input to ``datetime.date``."""
    if isinstance(issue_date, datetime.datetime):
        return issue_date.date()
    if isinstance(issue_date, datetime.date):
        return issue_date
    if isinstance(issue_date, str):
        return pd.to_datetime(issue_date).date()
    if hasattr(issue_date, "date"):
        return issue_date.date()
    raise ValueError(f"Unsupported issue_date type: {type(issue_date)}")


def _version_candidates(version: Any) -> List[Any]:
    """Return candidate issue_version representations for API compatibility."""
    candidates = [version]
    value = getattr(version, "value", None)
    if value is not None:
        candidates.append(value)

    for candidate in list(candidates):
        if isinstance(candidate, str):
            digits = ''.join(ch for ch in candidate if ch.isdigit())
            if digits:
                candidates.append(int(digits))
        else:
            try:
                candidates.append(int(candidate))
            except Exception:
                pass

    deduped = []
    for candidate in candidates:
        if candidate not in deduped:
            deduped.append(candidate)
    return deduped


def _build_forecast_instance(cls, tag: Any, issue_date: datetime.date, version: Any):
    """Create forecast instance across jain_commods API variants."""
    last_exc = None
    for candidate in _version_candidates(version):
        try:
            return cls(tag=tag, issue_date=issue_date, issue_version=candidate)
        except TypeError as exc:
            last_exc = exc
    try:
        return cls(tag=tag, issue_date=issue_date)
    except TypeError as exc:
        if last_exc is not None:
            raise last_exc
        raise exc


def _call_with_issue_params(method, issue_date: datetime.date, version: Any, **base_kwargs):
    """Call load/save style methods across signature variants."""
    last_exc = None
    for candidate in _version_candidates(version):
        try:
            return method(issue_date=issue_date, issue_version=candidate, **base_kwargs)
        except TypeError as exc:
            last_exc = exc

    try:
        return method(issue_date=issue_date, **base_kwargs)
    except TypeError as exc:
        last_exc = exc

    if last_exc is not None:
        raise last_exc
    return method(**base_kwargs)


# ── Tenor definitions ──────────────────────────────────────────────────────

def compute_tenor_dates(
    reference_date: datetime.date,
    is_mt: bool = False
) -> Dict[str, Tuple[datetime.date, datetime.date]]:
    """
    Compute date ranges for each tradeable tenor relative to *reference_date*.

    ST models (EC-ENS, GFS-ENS, EC, GFS):
        D+1 … D+5, WE+1, WE+2, WK+1, WK+2

    MT models (EC-EXT, GFS-EXT):
        All of the above  +  WK+3, WK+4

    Returns
    -------
    dict  {tenor_name: (start_date, end_date)}   inclusive
    """
    d = reference_date
    tenors = {}

    # ── Daily tenors D+1 … D+5 ──
    for i in range(1, 6):
        tenors[f'D+{i}'] = (
            d + datetime.timedelta(days=i),
            d + datetime.timedelta(days=i),
        )

    # ── Weekend tenors ──
    # Next Saturday from reference date
    days_to_sat = (5 - d.weekday()) % 7
    if days_to_sat == 0:
        days_to_sat = 7               # if reference is a Saturday, skip to next
    next_sat = d + datetime.timedelta(days=days_to_sat)
    next_sun = next_sat + datetime.timedelta(days=1)

    tenors['WE+1'] = (next_sat, next_sun)
    tenors['WE+2'] = (
        next_sat + datetime.timedelta(days=7),
        next_sun + datetime.timedelta(days=7),
    )

    # ── Week tenors (Mon→Sun) ──
    days_to_mon = (7 - d.weekday()) % 7
    if days_to_mon == 0:
        days_to_mon = 7               # if reference is a Monday, skip to next
    next_mon = d + datetime.timedelta(days=days_to_mon)

    max_weeks = 4 if is_mt else 2
    for w in range(max_weeks):
        wk_start = next_mon + datetime.timedelta(days=7 * w)
        wk_end   = wk_start + datetime.timedelta(days=6)   # Mon → Sun
        tenors[f'WK+{w + 1}'] = (wk_start, wk_end)

    # Log computed tenors for debugging
    logger.debug(f"Computed tenors for reference_date={reference_date} ({d.strftime('%A')}):")
    for tenor_name, (start, end) in sorted(tenors.items()):
        logger.debug(f"  {tenor_name}: {start} to {end}")

    return tenors


# ── S3 loading ─────────────────────────────────────────────────────────────

# In-memory cache: (variable, model, issue_date) → DataFrame
_forecast_cache: Dict[tuple, pd.DataFrame] = {}
_forecast_cache_lock = threading.Lock()


def clear_forecast_cache():
    """Clear the in-memory forecast cache."""
    with _forecast_cache_lock:
        _forecast_cache.clear()
    logger.info("Forecast data cache cleared")


def check_and_download_forecast(
    model_name: str,
    issue_date: datetime.date,
    zones: List[str] = None,
    variables: List[str] = None,
) -> Tuple[int, int, List[str]]:
    """
    Check if forecast data exists in S3 cache, download missing data from API.
    
    This is the main "Run" function that:
    1. Checks if each variable/model/date combination exists in S3
    2. Downloads from EnergyQuantified API only if missing (using default cache download)
    3. Returns status of what was loaded vs downloaded
    
    Parameters
    ----------
    model_name : str
        Model display name (e.g., 'EC-EXT 00z')
    issue_date : datetime.date
        Forecast issue date
    zones : List[str], optional
        Zones to load/download. Defaults to DEFAULT_ZONES.
    variables : List[str], optional
        Variables to load/download. Defaults to ALL_VARIABLES.
    
    Returns
    -------
    Tuple[int, int, List[str]]
        (loaded_from_cache, downloaded_from_api, list_of_errors)
    """
    if not CACHE_AVAILABLE:
        return 0, 0, ["Cache classes not available"]
    
    if zones is None:
        zones = DEFAULT_ZONES
    if variables is None:
        variables = ALL_VARIABLES
    
    if model_name not in MODEL_CONFIGS:
        return 0, 0, [f"Unknown model: {model_name}"]

    issue_date = _normalize_issue_date(issue_date)
    
    tag, version, is_mt = MODEL_CONFIGS[model_name]
    
    loaded_count = 0
    downloaded_count = 0
    errors = []
    
    for variable in variables:
        if variable not in VARIABLE_CLASSES:
            errors.append(f"Unknown variable: {variable}")
            continue
        
        st_cls, mt_cls = VARIABLE_CLASSES[variable]
        cls = mt_cls if is_mt else st_cls
        
        # First, try to load from S3 cache
        cache_key = (variable, model_name, issue_date)
        with _forecast_cache_lock:
            if cache_key in _forecast_cache:
                # Already in memory cache
                loaded_count += 1
                continue
        
        try:
            fcst = _build_forecast_instance(cls, tag, issue_date, version)
            _call_with_issue_params(
                fcst.load,
                issue_date=issue_date,
                version=version,
                from_s3=True,
                normalized=False,
                show_metadata=False,
            )
            
            if fcst.data is not None and not fcst.data.empty:
                # Data exists in S3, cache it in memory
                df = fcst.data
                df.columns = [str(c).upper() for c in df.columns]
                with _forecast_cache_lock:
                    _forecast_cache[cache_key] = df
                loaded_count += 1
                logger.info(f"Loaded {variable} / {model_name} / {issue_date} from S3")
                continue
        except Exception as e:
            logger.info(f"S3 load failed for {variable}/{model_name}/{issue_date}: {e}")
        
        # Data not in S3, download from API using default cache download method
        # Only pass issue_date to let the cache class handle zones/dates correctly
        try:
            logger.info(f"Downloading {variable} / {model_name} for {issue_date} from API")
            fcst = _build_forecast_instance(cls, tag, issue_date, version)
            
            # Download only the zones we need (DEFAULT_ZONES if not specified)
            download_zones = zones if zones else DEFAULT_ZONES
            fcst.download(zones=download_zones)
            
            if fcst.data is None or fcst.data.empty:
                errors.append(f"{variable}/{model_name}: No data returned from API")
                continue
            
            # Intentionally do not write back to S3 from dashboard runtime.
            logger.info(
                "Skipping S3 save for %s / %s / %s (read-only runtime)",
                variable, model_name, issue_date
            )
            
            # Cache in memory
            df = fcst.data
            df.columns = [str(c).upper() for c in df.columns]
            with _forecast_cache_lock:
                _forecast_cache[cache_key] = df
            downloaded_count += 1
            
        except Exception as e:
            error_msg = f"{variable}/{model_name}: {str(e)}"
            logger.error(f"Download failed: {error_msg}")
            errors.append(error_msg)
    
    return loaded_count, downloaded_count, errors


def load_forecast(
    variable: str,
    model_name: str,
    issue_date: datetime.date,
    zones: List[str],
) -> Optional[pd.DataFrame]:
    """
    Load a single forecast vintage from S3 cache.

    Returns a DataFrame with:
        index  = valuedate (hourly)
        columns = zone names (uppercase, e.g. 'DE', 'FR')
        values = MW
    or None if unavailable or contains no valid data.
    """
    if not CACHE_AVAILABLE:
        logger.warning("Cache classes not available")
        return None

    issue_date = _normalize_issue_date(issue_date)
    cache_key = (variable, model_name, issue_date)
    with _forecast_cache_lock:
        if cache_key in _forecast_cache:
            df = _forecast_cache[cache_key].copy()
            df.columns = [str(c).upper() for c in df.columns]
            zone_cols = [z for z in zones if z in df.columns]
            return df[zone_cols] if zone_cols else None

    tag, version, is_mt = MODEL_CONFIGS[model_name]
    st_cls, mt_cls = VARIABLE_CLASSES[variable]
    cls = mt_cls if is_mt else st_cls

    try:
        fcst = _build_forecast_instance(cls, tag, issue_date, version)
        _call_with_issue_params(
            fcst.load,
            issue_date=issue_date,
            version=version,
            from_s3=True,
            normalized=False,
            show_metadata=False,
        )
        df = fcst.data
        if df is None or df.empty:
            logger.info(f"No data for {variable}/{model_name}/{issue_date}")
            return None

        # CRITICAL: Normalize columns to uppercase for consistent zone matching
        # Some S3 files have lowercase columns (older saves), some have uppercase (newer saves)
        df.columns = [str(c).upper() for c in df.columns]
        logger.info(f"Loaded {variable}/{model_name}/{issue_date}: shape={df.shape}, cols={list(df.columns)[:8]}")

        # ── Data quality validation ──
        if DQ_AVAILABLE:
            dq_result = validate_forecast(
                df, issue_date, variable, model_name, zones
            )
            if not dq_result.passed:
                logger.warning(
                    f"DQ FAILED for {variable}/{model_name}/{issue_date}: "
                    f"{dq_result.failed_checks}"
                )
                # Still return data but log the failure; caller decides
            # Register freshness
            try:
                idx = df.index
                idx_start = str(idx.min())[:19] if len(idx) > 0 else 'N/A'
                freshness_tracker.register_data_source(
                    source_name=f"{variable} / {model_name} / {issue_date}",
                    update_time=datetime.datetime.now(),
                    expected_frequency_minutes=360,  # 6h for forecast data
                    metadata={
                        'records': len(df),
                        'issue_date': str(issue_date),
                        'index_start': idx_start,
                        'dq_status': 'pass' if dq_result.passed else 'fail',
                        'dq_warnings': len(dq_result.warnings),
                    },
                )
            except Exception:
                pass  # Don't let freshness tracking break data loading

        # Cache for re-use within this session
        with _forecast_cache_lock:
            _forecast_cache[cache_key] = df

        # Filter to requested zones (zones should already be uppercase)
        zone_cols = [z for z in zones if z in df.columns]
        if not zone_cols:
            logger.warning(
                f"No matching zones found for {variable}/{model_name}/{issue_date}. "
                f"Requested: {zones}, Available: {list(df.columns)[:10]}"
            )
            return None
        return df[zone_cols]

    except Exception as e:
        logger.warning(f"Failed to load {variable}/{model_name}/{issue_date}: {e}")
        return None


# ── Tenor aggregation ──────────────────────────────────────────────────────

def aggregate_to_tenors(
    df: pd.DataFrame,
    reference_date: datetime.date,
    is_mt: bool = False,
) -> pd.DataFrame:
    """
    Aggregate hourly MW forecast to tenor-period averages in **GW**.

    Returns
    -------
    DataFrame  rows = zones (uppercase), columns = tenor names
    """
    tenors = compute_tenor_dates(reference_date, is_mt=is_mt)
    results = {}

    # Make sure the index is tz-naive for comparison (handle CET data)
    idx = df.index
    if hasattr(idx, 'tz') and idx.tz is not None:
        idx_naive = idx.tz_localize(None)
    else:
        idx_naive = idx

    # Log data range for debugging
    logger.debug(
        f"Aggregating to tenors: reference_date={reference_date}, "
        f"data_range=[{idx_naive.min()}, {idx_naive.max()}], "
        f"total_hours={len(idx_naive)}"
    )

    for tenor_name, (start, end) in tenors.items():
        start_ts = pd.Timestamp(start)
        # Include all hours of the last day
        end_ts = pd.Timestamp(end) + pd.Timedelta(hours=23, minutes=59)

        mask = (idx_naive >= start_ts) & (idx_naive <= end_ts)
        tenor_slice = df.loc[mask]
        
        # Log tenor matching for debugging
        hours_matched = len(tenor_slice)
        if hours_matched == 0:
            logger.debug(
                f"  {tenor_name} ({start} to {end}): NO DATA FOUND in range "
                f"[{start_ts}, {end_ts}]"
            )
        else:
            sample_values = tenor_slice.mean() / 1000.0
            non_zero_zones = (sample_values != 0).sum()
            logger.debug(
                f"  {tenor_name} ({start} to {end}): {hours_matched} hours, "
                f"{non_zero_zones}/{len(sample_values)} non-zero zones"
            )

        if tenor_slice.empty:
            results[tenor_name] = {col: np.nan for col in df.columns}
        else:
            # Average MW → GW
            results[tenor_name] = (tenor_slice.mean() / 1000.0).to_dict()

    # Rows = zones, columns = tenors
    return pd.DataFrame(results)


# ── Batch pre-fetch ────────────────────────────────────────────────────────

def _prefetch_forecasts(
    variables: List[str],
    model_name: str,
    dates: List[datetime.date],
    zones: List[str],
) -> None:
    """Load all (variable, model, date) combinations into _forecast_cache
    concurrently so that subsequent load_forecast() calls are instant."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    tasks = []
    for variable in variables:
        for d in dates:
            cache_key = (variable, model_name, _normalize_issue_date(d))
            with _forecast_cache_lock:
                if cache_key in _forecast_cache:
                    continue
            tasks.append((variable, d))

    if not tasks:
        return

    def _fetch(args):
        var, dt_ = args
        load_forecast(var, model_name, dt_, zones)

    with ThreadPoolExecutor(max_workers=min(len(tasks), 4)) as pool:
        futs = [pool.submit(_fetch, t) for t in tasks]
        for f in as_completed(futs):
            try:
                f.result()
            except Exception:
                pass


# ── Grid data builder ──────────────────────────────────────────────────────

def build_grid_data(
    variables: List[str],
    zones: List[str],
    model_name: str,
    today_date: datetime.date,
    ref_date: datetime.date,
    display_mode: str = 'delta',      # 'absolute' | 'delta' | 'pct_delta'
) -> Tuple[List[dict], List[str]]:
    """
    Build the row-data list and ordered tenor names for the AG Grid.

    Parameters
    ----------
    variables : list of str      e.g. ['Wind', 'Solar', 'Demand']
    zones     : list of str      e.g. ['DE', 'FR']
    model_name: str              e.g. 'EC-ENS 00z'
    today_date: date             forecast date (today)
    ref_date  : date             reference forecast date (yesterday)
    display_mode : str           'absolute', 'delta', 'pct_delta'

    Returns
    -------
    (rows, tenor_names)
        rows        – list of dicts ready for AG Grid rowData
        tenor_names – ordered list of tenor column names
    """
    _, _, is_mt = MODEL_CONFIGS[model_name]
    all_tenors = list(compute_tenor_dates(today_date, is_mt=is_mt).keys())

    _prefetch_forecasts(variables, model_name, [today_date, ref_date], zones)

    rows = []
    for variable in variables:
        df_today = load_forecast(variable, model_name, today_date, zones)
        df_ref   = load_forecast(variable, model_name, ref_date,   zones)

        # Aggregate to tenors
        t_today = (
            aggregate_to_tenors(df_today, today_date, is_mt=is_mt)
            if df_today is not None else None
        )
        t_ref = (
            aggregate_to_tenors(df_ref, today_date, is_mt=is_mt)
            if df_ref is not None else None
        )

        for zone in zones:
            row = {'Variable': variable, 'Zone': zone}

            for tenor in all_tenors:
                val_today = _safe_get(t_today, zone, tenor)
                val_ref   = _safe_get(t_ref,   zone, tenor)

                if display_mode == 'absolute':
                    row[tenor] = _round(val_today, 2)
                elif display_mode == 'delta':
                    if _valid(val_today) and _valid(val_ref):
                        row[tenor] = _round(val_today - val_ref, 2)
                    else:
                        row[tenor] = None
                elif display_mode == 'pct_delta':
                    if _valid(val_today) and _valid(val_ref) and abs(val_ref) > 0.001:
                        row[tenor] = _round(
                            (val_today - val_ref) / abs(val_ref) * 100, 1
                        )
                    else:
                        row[tenor] = None

            rows.append(row)

    return rows, all_tenors


# ── helpers ────────────────────────────────────────────────────────────────

def build_pivot_data(
    variables: List[str],
    zones: List[str],
    model_name: str,
    today_date: datetime.date,
    ref_date: datetime.date,
    display_mode: str = 'delta',
) -> Tuple[List[List], str, List[str]]:
    """
    Build flat data suitable for ``dash_pivottable.PivotTable``.

    Returns
    -------
    (data, val_col, missing_dates)
        data          – list of lists; first row is headers, rest are records.
        val_col       – the name of the value column (depends on display_mode).
        missing_dates – list of dates (as strings) for which data is not available.
    """
    # Pre-fetch all needed (variable, model, date) combinations in parallel
    # so the per-variable checks and build_grid_data calls below all hit cache.
    _prefetch_forecasts(variables, model_name, [today_date, ref_date], zones)

    # Check which dates have missing data
    missing_dates = []
    missing_details = []

    today_missing = False
    for variable in variables:
        df_today = load_forecast(variable, model_name, today_date, zones)
        if df_today is None or df_today.empty:
            today_missing = True
            missing_details.append(f"{variable}/{today_date}")
            logger.warning(f"Missing data: {variable}/{model_name}/{today_date}")
        else:
            logger.info(f"Found data: {variable}/{model_name}/{today_date} - shape={df_today.shape}, cols={list(df_today.columns)}")
    
    # Check reference date
    ref_missing = False
    for variable in variables:
        df_ref = load_forecast(variable, model_name, ref_date, zones)
        if df_ref is None or df_ref.empty:
            ref_missing = True
            missing_details.append(f"{variable}/{ref_date}")
            logger.warning(f"Missing data: {variable}/{model_name}/{ref_date}")
        else:
            logger.info(f"Found data: {variable}/{model_name}/{ref_date} - shape={df_ref.shape}, cols={list(df_ref.columns)}")
    
    if today_missing:
        missing_dates.append(today_date.strftime('%Y-%m-%d'))
    if ref_missing:
        missing_dates.append(ref_date.strftime('%Y-%m-%d'))
    
    if missing_details:
        logger.warning(f"Missing data details: {missing_details}")
    
    # For absolute mode, we need to get data for both dates separately
    if display_mode == 'absolute':
        # Build rows for both dates
        rows_today, tenor_names = build_grid_data(
            variables=variables,
            zones=zones,
            model_name=model_name,
            today_date=today_date,
            ref_date=ref_date,
            display_mode='absolute',
        )
        rows_ref, _ = build_grid_data(
            variables=variables,
            zones=zones,
            model_name=model_name,
            today_date=ref_date,  # Load ref_date data as "today" to get absolute values
            ref_date=ref_date,    # Same date for both
            display_mode='absolute',
        )
        
        val_col = 'GW'
        headers = ['Variable', 'Zone', 'Tenor', 'Issue Date', val_col]
        data: List[List] = [headers]
        
        # Add today's data
        today_str = today_date.strftime('%Y-%m-%d')
        for row in rows_today:
            variable = row['Variable']
            zone = row['Zone']
            for tenor in tenor_names:
                val = row.get(tenor)
                if val is not None:
                    data.append([variable, zone, tenor, today_str, round(val, 2)])
                else:
                    data.append([variable, zone, tenor, today_str, 'NaN'])
        
        # Add reference date data
        ref_str = ref_date.strftime('%Y-%m-%d')
        for row in rows_ref:
            variable = row['Variable']
            zone = row['Zone']
            for tenor in tenor_names:
                val = row.get(tenor)
                if val is not None:
                    data.append([variable, zone, tenor, ref_str, round(val, 2)])
                else:
                    data.append([variable, zone, tenor, ref_str, 'NaN'])
        
        return data, val_col, missing_dates
    
    else:
        # Delta modes - existing behavior
        rows, tenor_names = build_grid_data(
            variables=variables,
            zones=zones,
            model_name=model_name,
            today_date=today_date,
            ref_date=ref_date,
            display_mode=display_mode,
        )

        val_col = {
            'delta': 'Delta GW',
            'pct_delta': 'Delta %',
        }.get(display_mode, 'Value')

        headers = ['Variable', 'Zone', 'Tenor', val_col]
        data: List[List] = [headers]

        for row in rows:
            variable = row['Variable']
            zone = row['Zone']
            for tenor in tenor_names:
                val = row.get(tenor)
                # Include all tenors - use 'NaN' string for missing data (displays properly)
                if val is not None:
                    data.append([variable, zone, tenor, round(val, 2)])
                else:
                    # Use string 'NaN' instead of None/0 for display
                    data.append([variable, zone, tenor, 'NaN'])

        return data, val_col, missing_dates


# ── helpers ────────────────────────────────────────────────────────────────

def _safe_get(tenor_df: Optional[pd.DataFrame], zone: str, tenor: str):
    """Safely extract a value from the tenor DataFrame."""
    if tenor_df is None:
        return None
    if zone not in tenor_df.index or tenor not in tenor_df.columns:
        return None
    v = tenor_df.loc[zone, tenor]
    if pd.isna(v):
        return None
    return float(v)


def _valid(v) -> bool:
    return v is not None and not (isinstance(v, float) and np.isnan(v))


def _round(v, decimals: int):
    if v is None:
        return None
    return round(v, decimals)
