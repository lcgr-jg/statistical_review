"""
Fundamentals Dashboard - Availability page
============================================
REMIT availability forecasts per fuel type, styled to match the Fuel Switching
dashboard.  Charts are pre-rendered in ``get_layout()`` so they display
immediately when loaded inside the multi-page wrapper (fundamentals.py).

The ``register_availability_callbacks()`` function adds interactivity (country
switching, force-refresh) when the page is run in **standalone** mode.
"""
import dash
from dash import dcc, html, callback, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
import logging
from plotly.subplots import make_subplots
import gc

from portal_pages.fundamentals.styles import (
    COLORS, FUEL_COLORS, FUEL_FILLS, CHART_FONT, CHART_TEMPLATE,
    CARD_STYLE, CARD_HEADER_STYLE, CARD_HEADER_TEXT_STYLE,
    CONTROL_PANEL_STYLE, LABEL_STYLE, REFRESH_BTN_STYLE,
    STATUS_BADGE_OK, apply_chart_style, styled_empty_figure,
)

# Import enterprise caching
from core.cache import cached_result

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PRIORITY_COUNTRIES = ['DE', 'FR', 'UK', 'NL', 'BE']

# Main fuel types to chart (in display order)
MAIN_FUEL_TYPES = [
    'nuclear',
    'fossil gas',
    'fossil hard coal',
    'fossil brown coal/lignite',
]

# Country-specific exclusions
_EXCLUDE = {
    'DE': {'nuclear'},
    'UK': {'fossil hard coal', 'fossil brown coal/lignite'},
}


# ---------------------------------------------------------------------------
# Chart creation
# ---------------------------------------------------------------------------

@cached_result(ttl_seconds=3600, key_prefix="avail_fig")
def create_availability_figure(data_handler, country, fuel_type):
    """Build a styled availability chart (single row) for *country / fuel_type*.
    
    Cached for 1 hour to avoid re-rendering identical charts.
    """
    try:
        # Get data
        processed = data_handler.global_data.get('processed_data', {})
        if (country in processed and
                fuel_type in processed.get(country, {}) and
                'availability' in processed[country].get(fuel_type, {})):
            df = processed[country][fuel_type]['availability']
        else:
            df = data_handler.get_availability_data(country, fuel_type)

        if df is None or len(df) == 0:
            return styled_empty_figure(f'No availability data for {country} \u2013 {fuel_type}')

        # Ensure TIMESTAMP column exists
        if 'TIMESTAMP' not in df.columns:
            if 'DATE' in df.columns:
                df = df.rename(columns={'DATE': 'TIMESTAMP'})
            else:
                return styled_empty_figure('Missing timestamp column')

        df = df.sort_values('TIMESTAMP')

        # Determine y column
        y_col = 'AVAILABILITY_AMOUNT' if 'AVAILABILITY_AMOUNT' in df.columns else 'AVAILABLE_CAPACITY'

        # Colour for this fuel type
        base_hex = FUEL_COLORS.get(fuel_type, '#4E738A')
        r, g, b = int(base_hex[1:3], 16), int(base_hex[3:5], 16), int(base_hex[5:7], 16)
        fill = f'rgba({r},{g},{b},0.15)'

        fig = go.Figure()

        # Split by AS_OF if available
        if 'AS_OF' in df.columns:
            as_of_vals = df['AS_OF'].unique()
            for i, ao in enumerate(as_of_vals):
                sub = df[df['AS_OF'] == ao]
                label = 'Latest' if ao == 'latest' else (
                    f'As-of {ao.strftime("%Y-%m-%d")}' if hasattr(ao, 'strftime') else str(ao)
                )
                if ao == 'latest' or i == 0:
                    fig.add_trace(go.Scatter(
                        x=sub['TIMESTAMP'], y=sub[y_col],
                        mode='lines', name=label,
                        line=dict(width=2.5, color=base_hex),
                        fill='tozeroy', fillcolor=fill,
                    ))
                else:
                    fig.add_trace(go.Scatter(
                        x=sub['TIMESTAMP'], y=sub[y_col],
                        mode='lines', name=label,
                        line=dict(width=1.5, dash='dash',
                                  color=f'rgba({r},{g},{b},0.55)'),
                    ))
        else:
            fig.add_trace(go.Scatter(
                x=df['TIMESTAMP'], y=df[y_col],
                mode='lines', name='Availability',
                line=dict(width=2.5, color=base_hex),
                fill='tozeroy', fillcolor=fill,
            ))

        # Style
        apply_chart_style(fig, height=380)
        fig.update_layout(
            yaxis_title=dict(text='Availability (MW)'),
            xaxis=dict(
                tickformat='%b %Y',
                rangeselector=dict(
                    buttons=[
                        dict(count=1, label='1 M', step='month', stepmode='backward'),
                        dict(count=3, label='3 M', step='month', stepmode='backward'),
                        dict(count=6, label='6 M', step='month', stepmode='backward'),
                        dict(count=1, label='1 Y', step='year', stepmode='backward'),
                        dict(step='all', label='All'),
                    ],
                    bgcolor=COLORS['card_bg_alt'],
                    activecolor=COLORS['accent'],
                    font=dict(size=11),
                ),
            ),
        )
        return fig

    except Exception as e:
        logger.error(f'Error creating availability figure for {country}-{fuel_type}: {e}')
        return styled_empty_figure(f'Error: {e}')


# ---------------------------------------------------------------------------
# Layout  (pre-rendered charts for the default country)
# ---------------------------------------------------------------------------

def get_layout(data_handler, country='DE'):
    """Return styled availability layout with dynamic chart rendering."""

    countries = data_handler.get_countries() if data_handler.is_ready else PRIORITY_COUNTRIES
    all_fuel_types = data_handler.get_fuel_types(country) if data_handler.is_ready else []
    excluded = _EXCLUDE.get(country, set())
    fuel_types = [ft for ft in MAIN_FUEL_TYPES if ft in all_fuel_types and ft not in excluded]
    other_fuel_types = [ft for ft in all_fuel_types if ft not in MAIN_FUEL_TYPES]

    initial_cards = []
    for ft in fuel_types:
        fig = create_availability_figure(data_handler, country, ft)
        accent = FUEL_COLORS.get(ft, COLORS['accent'])
        initial_cards.append(
            html.Div(style=CARD_STYLE, children=[
                html.Div(style={'display': 'flex', 'alignItems': 'stretch'}, children=[
                    html.Div(style={
                        'width': '4px',
                        'backgroundColor': accent,
                        'borderRadius': '12px 0 0 0',
                    }),
                    html.Div(style={**CARD_HEADER_STYLE, 'flex': '1'}, children=[
                        html.H4(ft.title(), style=CARD_HEADER_TEXT_STYLE),
                    ]),
                ]),
                dcc.Graph(figure=fig, config={'displayModeBar': False}),
            ]),
        )

    for ft in other_fuel_types:
        fig = create_availability_figure(data_handler, country, ft)
        initial_cards.append(
            html.Div(style=CARD_STYLE, children=[
                html.Div(style=CARD_HEADER_STYLE, children=[
                    html.H4(ft.title(), style={**CARD_HEADER_TEXT_STYLE, 'color': COLORS['text_muted']}),
                ]),
                dcc.Graph(figure=fig, config={'displayModeBar': False}),
            ]),
        )

    if not initial_cards:
        initial_cards = [html.Div(
            style={'textAlign': 'center', 'padding': '60px', 'color': COLORS['text_muted']},
            children='No availability data for this country.',
        )]
    initial_fuel_count = f'Showing REMIT availability • {len(fuel_types)} fuel types'

    return html.Div([
        # Control panel
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div(style={'display': 'flex', 'alignItems': 'flex-end', 'gap': '24px', 'flexWrap': 'wrap'}, children=[
                html.Div([
                    html.Label('Country', style=LABEL_STYLE),
                    dcc.Dropdown(
                        id='avail-country-select',
                        options=[{'label': c, 'value': c} for c in countries],
                        value=country,
                        clearable=False,
                        style={'width': '140px'},
                    ),
                ]),
                html.Div(style={'flex': '1'}),
                html.Div(id='avail-fuel-count', children=initial_fuel_count, style={'fontSize': '12px', 'color': COLORS['text_muted']}),
            ]),
        ]),

        # Chart cards container (populated by callback)
        dcc.Loading(
            type='circle', color=COLORS['accent'],
            children=[html.Div(id='avail-charts-container', children=initial_cards)],
        ),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_availability_callbacks(app, data_handler):
    """Register interactive callbacks."""

    @app.callback(
        [Output('avail-charts-container', 'children'),
         Output('avail-fuel-count', 'children')],
        Input('avail-country-select', 'value'),
    )
    def update_charts(country):
        """Update charts when country selection changes."""
        if not country or not data_handler.is_ready:
            return [html.Div(
                style={'textAlign': 'center', 'padding': '60px', 'color': COLORS['text_muted']},
                children='Loading data...',
            )], ''

        all_fuel_types = data_handler.get_fuel_types(country)
        
        # Determine which fuels to chart
        excluded = _EXCLUDE.get(country, set())
        fuel_types = [ft for ft in MAIN_FUEL_TYPES if ft in all_fuel_types and ft not in excluded]
        
        # Other fuel types (biomass, oil, etc.)
        other_fuel_types = [ft for ft in all_fuel_types if ft not in MAIN_FUEL_TYPES]
        
        # Build chart cards
        chart_cards = []
        for ft in fuel_types:
            fig = create_availability_figure(data_handler, country, ft)
            accent = FUEL_COLORS.get(ft, COLORS['accent'])
            chart_cards.append(
                html.Div(style=CARD_STYLE, children=[
                    # Header with accent bar
                    html.Div(style={'display': 'flex', 'alignItems': 'stretch'}, children=[
                        html.Div(style={
                            'width': '4px',
                            'backgroundColor': accent,
                            'borderRadius': '12px 0 0 0',
                        }),
                        html.Div(style={**CARD_HEADER_STYLE, 'flex': '1'}, children=[
                            html.H4(ft.title(), style=CARD_HEADER_TEXT_STYLE),
                        ]),
                    ]),
                    dcc.Graph(figure=fig, config={'displayModeBar': False}),
                ]),
            )
        
        # Other fuel type cards
        for ft in other_fuel_types:
            fig = create_availability_figure(data_handler, country, ft)
            chart_cards.append(
                html.Div(style=CARD_STYLE, children=[
                    html.Div(style=CARD_HEADER_STYLE, children=[
                        html.H4(ft.title(), style={**CARD_HEADER_TEXT_STYLE, 'color': COLORS['text_muted']}),
                    ]),
                    dcc.Graph(figure=fig, config={'displayModeBar': False}),
                ]),
            )
        
        if not chart_cards:
            chart_cards = [html.Div(
                style={'textAlign': 'center', 'padding': '60px', 'color': COLORS['text_muted']},
                children='No availability data for this country.',
            )]
        
        fuel_count_text = f'Showing REMIT availability \u2022 {len(fuel_types)} fuel types'
        
        return chart_cards, fuel_count_text
