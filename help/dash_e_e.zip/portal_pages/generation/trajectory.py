"""
Generation Dashboard - Trajectory YoY sub-tab
=============================================
For the selected (zone, fuel), plot the cumulative path length

    T_y(t) = sum_{h <= t} |G_h - G_{h-1}|

aggregated to the fleet level, one line per calendar year. A P10/P90 envelope
from the historical years anchors today's reading. A radio button switches
between absolute ``∑|ΔG|`` (MWh) and the normalised intensity
``∑|ΔG| / (nameplate × hours-elapsed)`` (unit-less; "fraction of nameplate
cycled per hour"), making the chart apples-to-apples across fleets.
"""
from __future__ import annotations

import logging
from datetime import date

import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, dcc, html

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    COLORS,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
    apply_chart_style,
    styled_empty_figure,
)

from portal_pages.generation.data_handler import DEFAULT_ZONES, FUELS

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Chart
# ---------------------------------------------------------------------------

def _doy_index_label(doy_values):
    """Map day-of-year integers to mid-month tick labels."""
    base = pd.Timestamp("2024-01-01")  # any non-leap year for label aesthetics
    return [(base + pd.Timedelta(days=int(d - 1))).strftime("%b %d") for d in doy_values]


def _build_trajectory_chart(traj: pd.DataFrame, normalised: bool, fuel: str, zone: str):
    if traj is None or traj.empty:
        return styled_empty_figure(f"No data for {zone} {fuel.title()}")

    current_year = date.today().year
    years = sorted(traj.index)
    historical = [y for y in years if y < current_year]

    fig = go.Figure()

    # P10 / P90 envelope from historical years.
    if len(historical) >= 3:
        hist = traj.loc[historical]
        p10 = hist.quantile(0.10, axis=0)
        p90 = hist.quantile(0.90, axis=0)
        median = hist.median(axis=0)
        x_labels = _doy_index_label(traj.columns)

        fig.add_trace(go.Scatter(
            x=x_labels, y=p90.values,
            mode="lines",
            line=dict(width=0),
            showlegend=False,
            hoverinfo="skip",
            name="P90",
        ))
        fig.add_trace(go.Scatter(
            x=x_labels, y=p10.values,
            mode="lines",
            line=dict(width=0),
            fill="tonexty",
            fillcolor="rgba(120, 144, 156, 0.18)",
            showlegend=True,
            name="P10–P90 (historical)",
            hoverinfo="skip",
        ))
        fig.add_trace(go.Scatter(
            x=x_labels, y=median.values,
            mode="lines",
            line=dict(width=1.5, color="#78909c", dash="dot"),
            name="Median (historical)",
        ))

    # Per-year lines: greys for past, fuel-coloured + thick for current.
    accent = COLORS.get("accent", "#1976d2")
    n_hist = max(len(historical), 1)
    for i, y in enumerate(years):
        is_current = y == current_year
        if is_current:
            color, width = accent, 3.0
        else:
            # Older years fade lighter.
            shade = int(60 + 120 * (i / n_hist))  # 60-180 grey
            color, width = f"rgb({shade},{shade},{shade})", 1.2

        x_labels = _doy_index_label(traj.columns)
        fig.add_trace(go.Scatter(
            x=x_labels,
            y=traj.loc[y].values,
            mode="lines",
            name=str(y),
            line=dict(width=width, color=color),
            opacity=1.0 if is_current else 0.7,
        ))

    apply_chart_style(fig, height=520)
    y_title = (
        "Cycling intensity (fraction of nameplate / h)"
        if normalised else "Cumulative ∑ |ΔG| (MWh)"
    )
    fig.update_layout(
        title=dict(
            text=(
                f"Trajectory YoY: {zone} {fuel.title()} — "
                f"{'normalised intensity' if normalised else 'cumulative ramp'}"
            ),
            font=dict(size=16),
        ),
        xaxis_title="Day of Year",
        yaxis_title=y_title,
        legend=dict(orientation="v", yanchor="top", y=1.0, xanchor="left", x=1.02),
        hovermode="x unified",
    )
    return fig


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def get_layout(data_handler):
    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Country", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="gen-tr-zone",
                        options=[{"label": z, "value": z} for z in DEFAULT_ZONES],
                        value="FR",
                        clearable=False,
                    ),
                ], width=2),
                dbc.Col([
                    html.Label("Fuel", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="gen-tr-fuel",
                        options=[{"label": f.title(), "value": f} for f in FUELS],
                        value="nuclear",
                        clearable=False,
                    ),
                ], width=2),
                dbc.Col([
                    html.Label("Metric", style=LABEL_STYLE),
                    dcc.RadioItems(
                        id="gen-tr-metric",
                        options=[
                            {"label": "  Cumulative ∑|ΔG| (MWh)", "value": "abs"},
                            {"label": "  Normalised intensity",   "value": "norm"},
                        ],
                        value="abs",
                        labelStyle={"display": "block", "fontSize": "12px"},
                    ),
                ], width=3),
            ]),
        ]),

        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.H4("Trajectory YoY", style=CARD_HEADER_TEXT_STYLE),
            ]),
            dcc.Loading(
                type="circle",
                color=COLORS["accent"],
                children=[dcc.Graph(id="gen-tr-graph", config={"displayModeBar": False})],
            ),
        ]),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_callbacks(app, data_handler):
    @app.callback(
        Output("gen-tr-graph", "figure"),
        [
            Input("gen-tr-zone", "value"),
            Input("gen-tr-fuel", "value"),
            Input("gen-tr-metric", "value"),
        ],
    )
    def update_trajectory(zone, fuel, metric):
        if not zone or not fuel:
            return styled_empty_figure("Select a country and fuel")
        try:
            traj = data_handler.get_trajectory_yoy(
                zone, fuel, normalised=(metric == "norm")
            )
        except Exception as exc:
            logger.warning(f"Trajectory load failed for {zone}/{fuel}: {exc}")
            return styled_empty_figure(f"Error: {exc}")
        return _build_trajectory_chart(traj, normalised=(metric == "norm"),
                                       fuel=fuel, zone=zone)
