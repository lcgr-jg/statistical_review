"""Generation dashboard package (per-unit analytics)."""
