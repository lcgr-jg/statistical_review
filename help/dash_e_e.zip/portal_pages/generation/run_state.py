"""
Generation Dashboard - Run-state Gantt sub-tab
==============================================
Renders an "htop"-style grid: rows = units, columns = hours, colour = the
classified operating state (cold-off → full-load → ramping → MEL, etc.).

The classifier lives in ``data_handler._classify_states``.
"""
from __future__ import annotations

import logging
from datetime import date, timedelta

import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, dcc, html

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    COLORS,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
    apply_chart_style,
    styled_empty_figure,
)

from portal_pages.generation.data_handler import (
    DEFAULT_ZONES,
    FUELS,
    STATES,
    STATE_COLORS,
    STATE_TO_INT,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Chart
# ---------------------------------------------------------------------------

def _build_gantt(states_df: pd.DataFrame, nameplate: pd.Series, window_days: int):
    """Build the Run-state Gantt heatmap for the last ``window_days``."""
    if states_df is None or states_df.empty:
        return styled_empty_figure("No per-unit data available")

    end = states_df.index.max()
    start = end - pd.Timedelta(days=window_days)
    sub = states_df.loc[states_df.index >= start]
    if sub.empty:
        return styled_empty_figure("No per-unit data in window")

    # Order units by nameplate (largest at the top reads naturally).
    units = sorted(
        sub.columns,
        key=lambda u: float(nameplate.get(u, 0.0)),
        reverse=True,
    )
    sub = sub[units]

    # Convert states to integers for an imshow-style heatmap.
    # DataFrame.map (pandas >= 2.1) is the replacement for the deprecated applymap.
    map_fn = sub.map if hasattr(sub, "map") else sub.applymap  # type: ignore[attr-defined]
    Z = map_fn(lambda s: STATE_TO_INT.get(s, -1)).T  # rows=units, cols=time
    # Mask invalid (-1) so they render transparent.
    Zf = Z.astype("float32").where(Z >= 0, np.nan)

    # Build discrete colorscale spanning [0, len(STATES)-1].
    n = len(STATES)
    boundaries = [(i / (n - 1)) for i in range(n)]
    colorscale = []
    for i, b in enumerate(boundaries):
        colorscale.append([b - (1e-9 if i > 0 else 0), STATE_COLORS[STATES[i]]])
        colorscale.append([b + (1e-9 if i < n - 1 else 0), STATE_COLORS[STATES[i]]])

    # Render: one row per unit, one column per hour.
    fig = go.Figure(
        data=go.Heatmap(
            z=Zf.values,
            x=sub.index,
            y=[f"{u}  ({int(nameplate.get(u, 0))} MW)" for u in units],
            colorscale=colorscale,
            zmin=0,
            zmax=n - 1,
            showscale=False,
            hovertemplate=(
                "<b>%{y}</b><br>%{x|%Y-%m-%d %H:%M}<br>"
                "state=%{customdata}<extra></extra>"
            ),
            customdata=sub.T.values,
            xgap=0,
            ygap=1,
        )
    )

    apply_chart_style(fig, height=max(360, 22 * len(units) + 80))
    fig.update_layout(
        margin=dict(l=200, r=20, t=40, b=40),
        xaxis=dict(title="Time", showgrid=False),
        yaxis=dict(title="", showgrid=False, autorange="reversed"),
    )
    return fig


def _state_legend() -> html.Div:
    """A horizontal legend strip matching the STATE_COLORS palette."""
    return html.Div(
        style={
            "display": "flex",
            "flexWrap": "wrap",
            "gap": "14px",
            "padding": "8px 12px",
            "fontSize": "12px",
            "color": COLORS["text_secondary"],
        },
        children=[
            html.Div(
                style={"display": "flex", "alignItems": "center", "gap": "6px"},
                children=[
                    html.Div(
                        style={
                            "width": "14px",
                            "height": "14px",
                            "backgroundColor": STATE_COLORS[s],
                            "borderRadius": "2px",
                        },
                    ),
                    html.Span(s),
                ],
            )
            for s in STATES
        ],
    )


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def get_layout(data_handler):
    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Country", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="gen-rs-zone",
                        options=[{"label": z, "value": z} for z in DEFAULT_ZONES],
                        value="FR",
                        clearable=False,
                    ),
                ], width=2),
                dbc.Col([
                    html.Label("Fuel", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="gen-rs-fuel",
                        options=[{"label": f.title(), "value": f} for f in FUELS],
                        value="nuclear",
                        clearable=False,
                    ),
                ], width=2),
                dbc.Col([
                    html.Label("Window (days)", style=LABEL_STYLE),
                    dcc.Slider(
                        id="gen-rs-window",
                        min=3, max=30, step=1, value=14,
                        marks={d: str(d) for d in (3, 7, 14, 21, 30)},
                        tooltip={"placement": "bottom"},
                    ),
                ], width=4),
            ]),
        ]),

        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.H4("Unit Run-state Gantt", style=CARD_HEADER_TEXT_STYLE),
            ]),
            _state_legend(),
            dcc.Loading(
                type="circle",
                color=COLORS["accent"],
                children=[dcc.Graph(id="gen-rs-graph", config={"displayModeBar": False})],
            ),
        ]),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_callbacks(app, data_handler):
    @app.callback(
        Output("gen-rs-graph", "figure"),
        [
            Input("gen-rs-zone", "value"),
            Input("gen-rs-fuel", "value"),
            Input("gen-rs-window", "value"),
        ],
    )
    def update_gantt(zone, fuel, window_days):
        if not zone or not fuel:
            return styled_empty_figure("Select a country and fuel")
        try:
            states = data_handler.get_states(zone, fuel)
            nameplate = data_handler.get_nameplate(zone, fuel)
        except Exception as exc:
            logger.warning(f"State load failed for {zone}/{fuel}: {exc}")
            return styled_empty_figure(f"Error: {exc}")
        return _build_gantt(states, nameplate, int(window_days or 14))
