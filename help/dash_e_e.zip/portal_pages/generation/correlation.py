"""
Generation Dashboard - Co-cycling correlation graph sub-tab
===========================================================
For the selected (zone, fuel), compute pairwise Pearson correlation of the
hourly generation deltas ``ΔG`` across all units in the fleet over the chosen
look-back window, then render it as a force-directed (``cose``) graph in
Cytoscape. Tight clusters → units that ramp together (likely shared portfolio
operator, contracted block, or local network constraint). Outliers — units
that should be in a cluster but aren't — are the editorial flag.
"""
from __future__ import annotations

import logging

import dash_bootstrap_components as dbc
import dash_cytoscape as cyto
import pandas as pd
from dash import Input, Output, dcc, html

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    COLORS,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
)

from portal_pages.generation.data_handler import DEFAULT_ZONES, FUELS

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Cytoscape elements + stylesheet builders
# ---------------------------------------------------------------------------

def _build_elements(
    corr: pd.DataFrame,
    edges: pd.DataFrame,
    nameplate: pd.Series,
):
    """Convert the correlation outputs into Cytoscape elements."""
    if corr is None or corr.empty or edges is None or edges.empty:
        return []

    # Nodes appearing in at least one edge (the rest are irrelevant to layout).
    nodes_set = set(edges["source"]).union(edges["target"])
    elements = []
    np_max = float(nameplate.reindex(list(nodes_set)).fillna(0).max() or 1.0)

    for unit in nodes_set:
        np_mw = float(nameplate.get(unit, 0.0))
        elements.append({
            "data": {
                "id": str(unit),
                "label": str(unit),
                "nameplate_mw": np_mw,
                "size": max(10.0, 6.0 + 30.0 * (np_mw / np_max)),
            },
            "classes": "unit",
        })

    for _, row in edges.iterrows():
        rho = float(row["rho"])
        sign = "pos" if rho > 0 else "neg"
        elements.append({
            "data": {
                "source": str(row["source"]),
                "target": str(row["target"]),
                "weight": abs(rho),
                "rho": rho,
            },
            "classes": f"corr-edge {sign}",
        })
    return elements


_STYLESHEET = [
    {
        "selector": "node.unit",
        "style": {
            "label": "data(label)",
            "background-color": "#1976d2",
            "width": "data(size)",
            "height": "data(size)",
            "font-size": 8,
            "color": "#cfd8dc",
            "text-outline-width": 1,
            "text-outline-color": "#0d1117",
            "text-valign": "center",
            "text-halign": "center",
            "border-width": 1,
            "border-color": "#0d47a1",
        },
    },
    {
        "selector": "node:selected",
        "style": {
            "background-color": "#ff9800",
            "border-width": 2,
            "border-color": "#fb8c00",
        },
    },
    {
        "selector": "edge.corr-edge",
        "style": {
            "width": "mapData(weight, 0.5, 1.0, 0.6, 4.0)",
            "opacity": "mapData(weight, 0.5, 1.0, 0.25, 0.85)",
            "curve-style": "haystack",
            "haystack-radius": 0.3,
        },
    },
    {
        "selector": "edge.pos",
        "style": {"line-color": "#42a5f5"},
    },
    {
        "selector": "edge.neg",
        "style": {"line-color": "#ef5350"},
    },
]


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def _cytoscape() -> cyto.Cytoscape:
    return cyto.Cytoscape(
        id="gen-corr-graph",
        layout={
            "name": "cose",
            "animate": False,
            "idealEdgeLength": 60,
            "nodeRepulsion": 6000,
            "gravity": 0.4,
            "fit": True,
            "padding": 30,
        },
        style={
            "width": "100%",
            "height": "720px",
            "backgroundColor": COLORS["chart_bg"],
        },
        elements=[],
        stylesheet=_STYLESHEET,
        responsive=True,
        userPanningEnabled=True,
        userZoomingEnabled=True,
        wheelSensitivity=0.15,
    )


def get_layout(data_handler):
    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Country", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="gen-corr-zone",
                        options=[{"label": z, "value": z} for z in DEFAULT_ZONES],
                        value="FR",
                        clearable=False,
                    ),
                ], width=2),
                dbc.Col([
                    html.Label("Fuel", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="gen-corr-fuel",
                        options=[{"label": f.title(), "value": f} for f in FUELS],
                        value="nuclear",
                        clearable=False,
                    ),
                ], width=2),
                dbc.Col([
                    html.Label("Look-back (days)", style=LABEL_STYLE),
                    dcc.Slider(
                        id="gen-corr-lookback",
                        min=30, max=730, step=30, value=365,
                        marks={30: "30d", 90: "90d", 180: "180d",
                               365: "1y", 730: "2y"},
                        tooltip={"placement": "bottom"},
                    ),
                ], width=4),
                dbc.Col([
                    html.Label("Min |ρ| edge", style=LABEL_STYLE),
                    dcc.Slider(
                        id="gen-corr-rho",
                        min=0.2, max=0.9, step=0.05, value=0.5,
                        marks={0.2: "0.2", 0.5: "0.5", 0.7: "0.7", 0.9: "0.9"},
                        tooltip={"placement": "bottom"},
                    ),
                ], width=2),
            ]),
        ]),

        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.H4(
                    "Co-cycling Correlation Graph",
                    style=CARD_HEADER_TEXT_STYLE,
                ),
            ]),
            html.Div(
                style={
                    "padding": "6px 12px",
                    "fontSize": "11px",
                    "color": COLORS["text_secondary"],
                },
                children=(
                    "Force-directed layout of hourly ΔG Pearson correlation. "
                    "Blue edges = positive (co-cycle), red = negative (anti-cycle). "
                    "Node size = empirical nameplate. Drag nodes to reflow."
                ),
            ),
            dcc.Loading(
                type="circle",
                color=COLORS["accent"],
                children=[_cytoscape()],
            ),
            html.Div(
                id="gen-corr-summary",
                style={
                    "padding": "10px 14px",
                    "fontSize": "12px",
                    "color": COLORS["text_secondary"],
                },
            ),
        ]),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_callbacks(app, data_handler):
    @app.callback(
        [Output("gen-corr-graph", "elements"),
         Output("gen-corr-summary", "children")],
        [Input("gen-corr-zone", "value"),
         Input("gen-corr-fuel", "value"),
         Input("gen-corr-lookback", "value"),
         Input("gen-corr-rho", "value")],
    )
    def update_graph(zone, fuel, lookback_days, rho_threshold):
        if not zone or not fuel:
            return [], "Select a country and fuel"
        try:
            corr, edges = data_handler.get_correlation(
                zone, fuel,
                lookback_days=int(lookback_days or 365),
                edge_threshold=float(rho_threshold or 0.5),
            )
            nameplate = data_handler.get_nameplate(zone, fuel)
        except Exception as exc:
            logger.warning(f"Correlation load failed for {zone}/{fuel}: {exc}")
            return [], f"Error: {exc}"

        if corr.empty or edges.empty:
            return [], (
                f"No edges meeting |ρ| ≥ {rho_threshold:.2f} for "
                f"{zone} {fuel.title()} in the last {lookback_days} days."
            )

        n_nodes = int(edges[["source", "target"]].stack().nunique())
        n_pos = int((edges["rho"] > 0).sum())
        n_neg = int((edges["rho"] < 0).sum())
        median_pos = float(edges.loc[edges["rho"] > 0, "rho"].median()) if n_pos else float("nan")

        summary = (
            f"{n_nodes} units • {n_pos} positive edges (median ρ "
            f"{median_pos:0.2f}) • {n_neg} negative edges • "
            f"window {lookback_days}d • threshold |ρ| ≥ {rho_threshold:0.2f}"
        )
        elements = _build_elements(corr, edges, nameplate)
        return elements, summary
