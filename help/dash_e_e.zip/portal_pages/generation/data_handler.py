"""
DataHandler for the Generation Dashboard
========================================
Loads and caches per-unit hourly generation from the corelib cache
(``GenPerUnit{Fuel}``) and computes the derived analytics used by the
Run-state Gantt, Trajectory YoY, and Co-cycling Correlation sub-tabs.

The data is loaded **lazily** per ``(zone, fuel)`` the first time it's needed
and cached in-process. ``load_all_data`` is registered with the central
DashboardCache scheduler — its job is to invalidate the lazy caches on a cron
so newly-published hourly bars get picked up.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from jain_commods.core.cache.data.fundamentals import (
    GenAvailPerUnitBiomass,
    GenAvailPerUnitCoal,
    GenAvailPerUnitGas,
    GenAvailPerUnitHydroPS,
    GenAvailPerUnitLignite,
    GenAvailPerUnitNuclear,
    GenPerUnitBiomass,
    GenPerUnitCoal,
    GenPerUnitGas,
    GenPerUnitHydroPS,
    GenPerUnitLignite,
    GenPerUnitNuclear,
    GenPerUnitOil,
)

from core.data_freshness import tracker

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public fuel / zone catalogues
# ---------------------------------------------------------------------------

FUEL_CLASSES = {
    "gas": GenPerUnitGas,
    "coal": GenPerUnitCoal,
    "lignite": GenPerUnitLignite,
    "nuclear": GenPerUnitNuclear,
    "biomass": GenPerUnitBiomass,
    "oil": GenPerUnitOil,
    "hydro_ps": GenPerUnitHydroPS,
}
FUELS = list(FUEL_CLASSES.keys())

# Per-unit declared (REMIT) availability classes per fuel. Missing entries
# (e.g. oil) cause the correlation filter to fall back to no availability mask.
AVAIL_CLASSES = {
    "gas": GenAvailPerUnitGas,
    "coal": GenAvailPerUnitCoal,
    "lignite": GenAvailPerUnitLignite,
    "nuclear": GenAvailPerUnitNuclear,
    "biomass": GenAvailPerUnitBiomass,
    "hydro_ps": GenAvailPerUnitHydroPS,
}

# Sensible default zones to expose. Per-unit hourly data is published for these.
DEFAULT_ZONES = ["DE", "FR", "NL", "BE", "ES", "IT", "AT", "PL", "CZ", "GB"]

# Look-back used for trajectory / correlation computations.
DEFAULT_HISTORY_YEARS = 5


# ---------------------------------------------------------------------------
# Run-state classification
# ---------------------------------------------------------------------------

# Discrete state labels (ordered: matches the colour-mapping in the Gantt UI).
STATES = [
    "cold-off",
    "warm-off",
    "hot-off",
    "ramping-up",
    "ramping-down",
    "MEL",
    "part-load",
    "full-load",
]
STATE_TO_INT = {s: i for i, s in enumerate(STATES)}

# Diverging discrete palette (cool greys for off, warm for ramps, fuel-y for on).
STATE_COLORS = {
    "cold-off": "#1f2933",
    "warm-off": "#3e4c59",
    "hot-off":  "#7b8794",
    "ramping-up":   "#ffb74d",
    "ramping-down": "#ba68c8",
    "MEL":          "#90a4ae",
    "part-load":    "#42a5f5",
    "full-load":    "#2e7d32",
}


def _classify_states(
    unit_hourly: pd.Series,
    nameplate: float,
    *,
    on_frac: float = 0.01,
    mel_frac: float = 0.35,
    full_frac: float = 0.95,
    ramp_frac: float = 0.05,
    hot_off_h: int = 8,
    warm_off_h: int = 48,
) -> pd.Series:
    """Map an hourly MW series for a single unit to discrete operating states.

    Thresholds are expressed as fractions of the unit's nameplate MW so the
    classifier scales across small peakers and large baseloaders alike.
    """
    if nameplate is None or not np.isfinite(nameplate) or nameplate <= 0:
        return pd.Series(index=unit_hourly.index, dtype="object")

    s = unit_hourly.astype("float64")
    on_mw = on_frac * nameplate
    mel_mw = mel_frac * nameplate
    full_mw = full_frac * nameplate
    ramp_mw = ramp_frac * nameplate

    on = s >= on_mw
    ds = s.diff().fillna(0.0)
    ramping_up = on & (ds > ramp_mw)
    ramping_down = on & (ds < -ramp_mw)

    # Hours-since-last-on (forward count from the last True in `on`).
    # ffill the index of the last "on" hour, then subtract.
    on_int = on.astype(int)
    idx = pd.RangeIndex(len(s))
    last_on_idx = pd.Series(np.where(on, idx, np.nan), index=s.index).ffill()
    hours_since_on = idx - last_on_idx.fillna(-1e9).to_numpy()

    state = pd.Series(index=s.index, dtype="object")

    # Off states first
    off_mask = ~on
    state[off_mask & (hours_since_on > warm_off_h)] = "cold-off"
    state[off_mask & (hours_since_on > hot_off_h) & (hours_since_on <= warm_off_h)] = "warm-off"
    state[off_mask & (hours_since_on <= hot_off_h)] = "hot-off"
    # Ramps win over level states when on
    state[ramping_up] = "ramping-up"
    state[ramping_down] = "ramping-down"
    # Level states for remaining on hours
    level = on & ~ramping_up & ~ramping_down
    state[level & (s >= full_mw)] = "full-load"
    state[level & (s < full_mw) & (s >= mel_mw)] = "part-load"
    state[level & (s < mel_mw)] = "MEL"

    return state


# ---------------------------------------------------------------------------
# Pairwise masked Pearson correlation (used by the Co-cycling graph)
# ---------------------------------------------------------------------------

def _pairwise_corr_masked(
    X: np.ndarray,
    avail_high_mask: np.ndarray,
    min_overlap: int = 200,
) -> np.ndarray:
    """Pairwise Pearson correlation with a per-pair "both-low" filter.

    Parameters
    ----------
    X : (T, N) float array
        Hourly ``ΔG`` series, one column per unit. May contain NaNs.
    avail_high_mask : (T, N) bool array
        ``True`` where a unit's declared availability is **above** its P20.
        For each pair (i, j) we include only rows where ``mask_i OR mask_j``
        is True. The exclusion case is "both units are below their own P20"
        — those hours add zero-on-both ramps and inflate correlations.
    min_overlap : int
        If fewer than this many rows survive the mask for a pair, the
        correlation is set to NaN (under-determined).

    Returns
    -------
    (N, N) float array of correlations with NaN diagonal.
    """
    T, N = X.shape
    if T == 0 or N == 0:
        return np.full((N, N), np.nan, dtype="float64")

    # Replace NaN values in X with 0 *only after building a NaN-mask*, so we
    # can exclude NaN hours from every pair as well.
    valid = ~np.isnan(X)
    Xz = np.where(valid, X, 0.0).astype("float64")
    M = avail_high_mask & valid

    out = np.full((N, N), np.nan, dtype="float64")
    for i in range(N):
        Mi = M[:, i]
        Xi = Xz[:, i]
        for j in range(i + 1, N):
            pair_mask = (Mi | M[:, j]) & valid[:, i] & valid[:, j]
            n = int(pair_mask.sum())
            if n < min_overlap:
                continue
            xi = Xi[pair_mask]
            xj = Xz[pair_mask, j]
            mxi = xi.mean()
            mxj = xj.mean()
            dxi = xi - mxi
            dxj = xj - mxj
            denom = np.sqrt((dxi * dxi).sum() * (dxj * dxj).sum())
            if denom <= 0:
                continue
            rho = float((dxi * dxj).sum() / denom)
            out[i, j] = rho
            out[j, i] = rho
    return out


# ---------------------------------------------------------------------------
# DataHandler
# ---------------------------------------------------------------------------

class GenerationDataHandler:
    """Lazy loader + cache for per-unit hourly generation data."""

    def __init__(self, history_years: int = DEFAULT_HISTORY_YEARS):
        self.history_years = history_years
        # (zone, fuel) -> hourly DataFrame, columns=unit_id
        self._hourly_cache: Dict[Tuple[str, str], pd.DataFrame] = {}
        # (zone, fuel) -> per-unit hourly availability DataFrame (MW)
        self._avail_cache: Dict[Tuple[str, str], pd.DataFrame] = {}
        # (zone, fuel) -> Series of nameplate MW per unit_id
        self._nameplate_cache: Dict[Tuple[str, str], pd.Series] = {}
        # (zone, fuel) -> DataFrame of state strings (same shape as hourly)
        self._state_cache: Dict[Tuple[str, str], pd.DataFrame] = {}
        # (zone, fuel) -> DataFrame indexed by year, columns=day_of_year (cumulative |dG|)
        self._traj_cache: Dict[Tuple[str, str], pd.DataFrame] = {}
        # (zone, fuel) -> Series indexed by year, total nameplate MW for that fleet-year
        self._traj_nameplate_cache: Dict[Tuple[str, str], pd.Series] = {}
        # (zone, fuel) -> (corr DataFrame, edges DataFrame)
        self._corr_cache: Dict[Tuple[str, str], Tuple[pd.DataFrame, pd.DataFrame]] = {}

        self.last_update: Optional[datetime] = None
        self.is_ready = False

    # ------------------------------------------------------------------
    # Scheduler hook
    # ------------------------------------------------------------------
    def load_all_data(self):
        """Invalidate lazy caches so the next page-load picks up fresh data.

        Called by the central DashboardCache scheduler. We intentionally do
        *not* warm every (zone, fuel) combination here — that would be a huge
        upfront S3 cost. Instead we clear the in-process caches and let the
        first user click on each combination pull a fresh copy.
        """
        n_cleared = sum(map(len, (
            self._hourly_cache, self._nameplate_cache, self._state_cache,
            self._traj_cache, self._corr_cache,
        )))
        self._hourly_cache.clear()
        self._avail_cache.clear()
        self._nameplate_cache.clear()
        self._state_cache.clear()
        self._traj_cache.clear()
        self._traj_nameplate_cache.clear()
        self._corr_cache.clear()
        self.last_update = datetime.now()
        self.is_ready = True

        tracker.register_data_source(
            "Generation Per-Unit (S3)",
            self.last_update,
            expected_frequency_minutes=60,
            metadata={"cache_entries_cleared": n_cleared},
        )
        logger.info(
            f"GenerationDataHandler: invalidated {n_cleared} lazy cache entries"
        )
        return self

    # ------------------------------------------------------------------
    # Raw hourly data loader
    # ------------------------------------------------------------------
    def get_hourly(self, zone: str, fuel: str) -> pd.DataFrame:
        """Return hourly per-unit generation for ``(zone, fuel)``.

        Columns = unit_id, index = naive hourly DatetimeIndex (local-day-aligned
        in CET via the corelib cache convention), values in MW.
        """
        key = (zone.upper(), fuel.lower())
        if key in self._hourly_cache:
            return self._hourly_cache[key]

        cls = FUEL_CLASSES.get(key[1])
        if cls is None:
            return pd.DataFrame()

        end = date.today()
        start = end - timedelta(days=int(365.25 * self.history_years))

        try:
            obj = cls(zone=key[0])
            try:
                obj.load(
                    from_s3=True,
                    start_date=start,
                    end_date=end,
                    show_metadata=False,
                )
            except TypeError:
                # Older signature
                obj.load(from_s3=True, show_metadata=False)
            df = getattr(obj, "data", None)
        except Exception as exc:
            logger.warning(f"GenPerUnit load failed for {key}: {exc}")
            df = None

        if df is None or df.empty:
            df = pd.DataFrame()
        else:
            df = df.copy()
            if not isinstance(df.index, pd.DatetimeIndex):
                df.index = pd.to_datetime(df.index)
            if df.index.tz is not None:
                df.index = df.index.tz_localize(None)
            df = df.sort_index()
            # Keep last N years strictly to bound memory.
            cutoff = pd.Timestamp(start)
            df = df.loc[df.index >= cutoff]
            df = df.dropna(axis=1, how="all")
            # Coerce to float32 to halve memory for these wide tables.
            df = df.astype("float32")

        self._hourly_cache[key] = df
        return df

    def get_availability(self, zone: str, fuel: str) -> pd.DataFrame:
        """Return per-unit hourly REMIT availability (MW). Empty if not published."""
        key = (zone.upper(), fuel.lower())
        if key in self._avail_cache:
            return self._avail_cache[key]

        cls = AVAIL_CLASSES.get(key[1])
        if cls is None:
            self._avail_cache[key] = pd.DataFrame()
            return self._avail_cache[key]

        end = date.today()
        start = end - timedelta(days=int(365.25 * self.history_years))
        try:
            obj = cls(zone=key[0])
            try:
                obj.load(
                    from_s3=True, start_date=start, end_date=end,
                    show_metadata=False,
                )
            except TypeError:
                obj.load(from_s3=True, show_metadata=False)
            df = getattr(obj, "data", None)
        except Exception as exc:
            logger.warning(f"GenAvailPerUnit load failed for {key}: {exc}")
            df = None

        if df is None or df.empty:
            df = pd.DataFrame()
        else:
            df = df.copy()
            if not isinstance(df.index, pd.DatetimeIndex):
                df.index = pd.to_datetime(df.index)
            if df.index.tz is not None:
                df.index = df.index.tz_localize(None)
            df = df.sort_index().astype("float32")
            df = df.loc[df.index >= pd.Timestamp(start)]
            df = df.dropna(axis=1, how="all")

        self._avail_cache[key] = df
        return df

    def get_nameplate(self, zone: str, fuel: str) -> pd.Series:
        """Per-unit nameplate (MW). Estimated as the empirical max observed gen."""
        key = (zone.upper(), fuel.lower())
        if key in self._nameplate_cache:
            return self._nameplate_cache[key]
        df = self.get_hourly(*key)
        if df.empty:
            s = pd.Series(dtype="float64")
        else:
            # Robust max: use the 99.5th percentile to avoid one-off spikes.
            s = df.quantile(0.995, axis=0).astype("float64")
            # Round to the nearest 5 MW for cosmetic stability.
            s = (s / 5.0).round() * 5.0
        self._nameplate_cache[key] = s
        return s

    # ------------------------------------------------------------------
    # State classification (used by Run-state Gantt)
    # ------------------------------------------------------------------
    def get_states(self, zone: str, fuel: str) -> pd.DataFrame:
        """Return a DataFrame of operating-state strings, same shape as ``get_hourly``."""
        key = (zone.upper(), fuel.lower())
        if key in self._state_cache:
            return self._state_cache[key]

        df = self.get_hourly(*key)
        nameplate = self.get_nameplate(*key)
        if df.empty:
            out = pd.DataFrame()
        else:
            out = pd.DataFrame(index=df.index, columns=df.columns, dtype="object")
            for unit in df.columns:
                np_mw = float(nameplate.get(unit, np.nan))
                out[unit] = _classify_states(df[unit], np_mw)
        self._state_cache[key] = out
        return out

    # ------------------------------------------------------------------
    # Cumulative trajectory (used by Trajectory YoY)
    # ------------------------------------------------------------------
    def get_trajectory_yoy(
        self,
        zone: str,
        fuel: str,
        *,
        normalised: bool = False,
    ) -> pd.DataFrame:
        """Return a DataFrame indexed by year × day-of-year of cumulative ``∑|ΔG|``.

        If ``normalised`` is True, the value is divided by
        (fleet nameplate MW × hours elapsed since Jan 1) — units become
        "fraction of nameplate cycled per hour" (apples-to-apples across fleets).
        """
        key = (zone.upper(), fuel.lower())
        if key not in self._traj_cache:
            self._build_trajectory(key)
        traj = self._traj_cache[key]
        if traj.empty:
            return traj
        if not normalised:
            return traj
        nameplate = self._traj_nameplate_cache[key]
        hours_elapsed = pd.Series(
            np.arange(1, traj.shape[1] + 1, dtype="float64") * 24.0,
            index=traj.columns,
        )
        out = traj.div(hours_elapsed, axis=1)
        out = out.div(nameplate, axis=0)
        return out

    def _build_trajectory(self, key: Tuple[str, str]) -> None:
        df = self.get_hourly(*key)
        if df.empty:
            self._traj_cache[key] = pd.DataFrame()
            self._traj_nameplate_cache[key] = pd.Series(dtype="float64")
            return

        # Fleet ΣMW per hour and its absolute diffs.
        fleet_mw = df.sum(axis=1, min_count=1).astype("float64")
        delta = fleet_mw.diff().abs().fillna(0.0)
        # Group by year, build cumulative over day-of-year.
        delta = delta.to_frame("d")
        delta["year"] = delta.index.year
        delta["doy"] = delta.index.dayofyear

        # Aggregate to daily total of |ΔG| (sum of |Δh| within the day).
        daily = delta.groupby(["year", "doy"])["d"].sum().unstack(level="doy", fill_value=0.0)
        cum = daily.cumsum(axis=1)

        nameplate_per_year = pd.Series(
            {y: self._fleet_nameplate_year(df, y) for y in cum.index},
            name="nameplate_mw",
        )

        self._traj_cache[key] = cum
        self._traj_nameplate_cache[key] = nameplate_per_year

    def _fleet_nameplate_year(self, df: pd.DataFrame, year: int) -> float:
        """Sum of per-unit empirical nameplates for units that ran at all in ``year``.

        This avoids retired units inflating the older years' nameplate base.
        """
        sub = df.loc[df.index.year == year]
        if sub.empty:
            return float("nan")
        sub = sub.dropna(axis=1, how="all")
        if sub.empty:
            return float("nan")
        per_unit = (sub.quantile(0.995, axis=0).fillna(0) / 5.0).round() * 5.0
        total = float(per_unit.sum())
        return total if total > 0 else float("nan")

    # ------------------------------------------------------------------
    # Co-cycling correlation (used by Correlation Graph)
    # ------------------------------------------------------------------
    def get_correlation(
        self,
        zone: str,
        fuel: str,
        *,
        lookback_days: int = 365,
        edge_threshold: float = 0.5,
        max_edges_per_node: int = 6,
        avail_low_pct: float = 0.20,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Compute pairwise Pearson correlation of hourly ``ΔG`` across units.

        Pairs are evaluated **only on hours where at least one of the two
        units' declared availability is above its own P20**. This removes
        spurious co-movement driven by long stretches where both units are
        derated / off (hours that would otherwise contribute zero ``ΔG`` to
        both series and inflate apparent correlation).

        If the unit-level availability cache is empty for this fuel (e.g.
        oil), the mask is skipped and the full-window correlation is used.

        Returns
        -------
        corr : DataFrame
            Square correlation matrix (units that survived variance filter).
        edges : DataFrame
            Long-format ``[source, target, rho]`` with self-loops and weak
            edges (|rho| < ``edge_threshold``) removed. Capped per-node so
            the force-directed layout stays legible.
        """
        cache_key = (zone.upper(), fuel.lower())
        if cache_key in self._corr_cache:
            return self._corr_cache[cache_key]

        df = self.get_hourly(zone, fuel)
        empty = pd.DataFrame()
        if df.empty:
            self._corr_cache[cache_key] = (empty, empty)
            return empty, empty

        end = df.index.max()
        start = end - pd.Timedelta(days=lookback_days)
        sub = df.loc[df.index >= start]
        if sub.empty or sub.shape[1] < 2:
            self._corr_cache[cache_key] = (empty, empty)
            return empty, empty

        # Hourly ΔG, drop hours/units that are all-zero.
        delta = sub.diff().dropna(how="all")
        var = delta.var(axis=0, skipna=True)
        keep = var[var > 1.0].index  # >1 MW² variance threshold
        delta = delta[keep]
        if delta.shape[1] < 2:
            self._corr_cache[cache_key] = (empty, empty)
            return empty, empty

        # Align availability mask (rows = same time index, cols = same units).
        avail = self.get_availability(zone, fuel)
        if not avail.empty:
            avail = avail.reindex(index=delta.index, columns=delta.columns)
            # Per-unit P20 threshold from the lookback-window availability.
            thresh = avail.quantile(avail_low_pct, axis=0)
            # Missing thresholds default to -inf so the unit is always "available".
            thresh = thresh.fillna(-np.inf)
            # Treat NaN avail as "available" (don't drop hours we can't classify).
            high_mask = (avail.fillna(np.inf).to_numpy() > thresh.to_numpy())  # T × N
        else:
            high_mask = np.ones(delta.shape, dtype=bool)

        corr_df = _pairwise_corr_masked(delta.to_numpy(dtype="float64"), high_mask)
        corr_df = pd.DataFrame(corr_df, index=delta.columns, columns=delta.columns).astype("float32")

        # Long-format edge list, prune symmetry + self-loops + weak edges.
        m = corr_df.where(np.triu(np.ones(corr_df.shape, dtype=bool), k=1))
        edges = m.stack().rename("rho").reset_index()
        edges.columns = ["source", "target", "rho"]
        edges = edges[edges["rho"].abs() >= edge_threshold].copy()
        edges = edges.dropna()

        # Cap fan-out so the force layout stays readable on large fleets.
        if not edges.empty:
            keep_idx = []
            for node in pd.unique(edges[["source", "target"]].values.ravel("K")):
                sel = edges[(edges["source"] == node) | (edges["target"] == node)]
                top = sel.reindex(
                    sel["rho"].abs().sort_values(ascending=False).index
                ).head(max_edges_per_node)
                keep_idx.extend(top.index.tolist())
            edges = edges.loc[sorted(set(keep_idx))].reset_index(drop=True)

        self._corr_cache[cache_key] = (corr_df, edges)
        return corr_df, edges

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------
    def list_units(self, zone: str, fuel: str) -> List[str]:
        return list(self.get_hourly(zone, fuel).columns)

    def get_last_update_time(self):
        return self.last_update
