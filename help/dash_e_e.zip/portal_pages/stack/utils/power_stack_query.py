import numpy as np
import pandas as pd
from sqlalchemy import text
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List
from jain_commods.core.interfaces.sqldb import SQLdb


class PowerStackQuery(SQLdb):
    """
    A class to manage power stack prices data queries.
    Inherits from SQLdb for database connection management.
    """
    
    def __init__(self,
                 login: Dict = {},
                 logintype: str = 'default',
                 table_prices: str = 'power_stack_prices',
                 table_output: str = 'power_stack_prompt_output',
                 schema: str = 'commod_research'):
        """
        
        Initialize PowerStackQuery with database connection details.
        
        Args:
            login: Dictionary with database credentials
            logintype: Type of login credentials to use
            table_prices: Name of power stack prices table
            table_output: Name of power stack output table
            schema: Database schema name
        """
        self.table_prices = table_prices
        self.table_output = table_output
        self.schema = schema
        
        # Set up logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        
        # Initialize SQLdb parent class
        super().__init__(login, logintype)
    
    def get_info(self) -> str:
        """
        Get instance configuration information.
        
        Returns:
            str: Formatted string with configuration details
        """
        info = f"""
        PowerStackQuery instance config:
        ================================
        {super().get_info()}
        Prices table: {self.table_prices}
        Output table: {self.table_output}
        Schema: {self.schema}
        """
        return info
    
    def get_prices(self, 
                   countries: Optional[List[str]] = None,
                   scenario_group: Optional[str] = None,
                   scenario: Optional[str] = None,
                   n_recent_runs: int = 1) -> Optional[pd.DataFrame]:
        """
        Get power stack prices for the most recent run(s).
        
        Args:
            countries: List of country codes (e.g., ['DE', 'FR']). If None, returns all countries.
            scenario_group: Filter by scenario group. If None, returns all scenario groups.
            scenario: Filter by scenario. If None, returns all scenarios.
            n_recent_runs: Number of most recent runs to retrieve (default: 1 for latest only)
            
        Returns:
            pd.DataFrame: Query results with prices from n most recent runs
        """
        try:
            # Build query to get n most recent run times
            query = f"""
            WITH recent_runs AS (
                SELECT DISTINCT run_time_utc
                FROM {self.schema}.{self.table_prices}
                ORDER BY run_time_utc DESC
                LIMIT {n_recent_runs}
            )
            SELECT
                p.run_time_utc,
                p.scenario_group,
                p.scenario,
                p.start_time_utc,
                p.end_time_utc,
                p.country,
                p.price
            FROM {self.schema}.{self.table_prices} p
            WHERE p.run_time_utc IN (SELECT run_time_utc FROM recent_runs)
            """
            
            params = {}
            
            # Add filters
            if countries:
                placeholders = ','.join([f':country_{i}' for i in range(len(countries))])
                query += f" AND p.country IN ({placeholders})"
                params.update({f'country_{i}': country for i, country in enumerate(countries)})
            
            if scenario_group:
                query += " AND p.scenario_group = :scenario_group"
                params['scenario_group'] = scenario_group
            
            if scenario:
                query += " AND p.scenario = :scenario"
                params['scenario'] = scenario
            
            query += " ORDER BY p.run_time_utc DESC, p.country, p.scenario_group, p.scenario, p.start_time_utc"
            
            self.logger.info(f"Executing query for {n_recent_runs} recent run(s) with filters: "
                           f"countries={countries}, scenario_group={scenario_group}, scenario={scenario}")
            
            df = pd.read_sql(text(query), self.engine, params=params)
            self.logger.info(f"Retrieved {len(df)} records from {df['run_time_utc'].nunique()} run(s)")
            return df
            
        except Exception as e:
            self.logger.error(f"Error getting prices: {str(e)}")
            return None
    
    def get_prices_by_run_time(self, 
                               run_time_utc: datetime,
                               countries: Optional[List[str]] = None,
                               scenario_group: Optional[str] = None) -> Optional[pd.DataFrame]:
        """
        Get power stack prices for a specific run time.
        
        Args:
            run_time_utc: Specific run time to query
            countries: List of country codes. If None, returns all countries.
            scenario_group: Filter by scenario group. If None, returns all scenario groups.
            
        Returns:
            pd.DataFrame: Query results for specified run time
        """
        try:
            query = f"""
            SELECT
                run_time_utc,
                scenario_group,
                scenario,
                start_time_utc,
                end_time_utc,
                country,
                price
            FROM {self.schema}.{self.table_prices}
            WHERE run_time_utc = :run_time_utc
            """
            
            params = {'run_time_utc': run_time_utc}
            
            if countries:
                placeholders = ','.join([f':country_{i}' for i in range(len(countries))])
                query += f" AND country IN ({placeholders})"
                params.update({f'country_{i}': country for i, country in enumerate(countries)})
            
            if scenario_group:
                query += " AND scenario_group = :scenario_group"
                params['scenario_group'] = scenario_group
            
            query += " ORDER BY country, scenario_group, scenario, start_time_utc"
            
            self.logger.info(f"Executing query for run_time_utc={run_time_utc}, scenario_group={scenario_group}")
            
            df = pd.read_sql(text(query), self.engine, params=params)
            self.logger.info(f"Retrieved {len(df)} records")
            return df
            
        except Exception as e:
            self.logger.error(f"Error getting prices by run time: {str(e)}")
            return None
    
    def get_available_run_times(self, limit: int = 10) -> Optional[pd.DataFrame]:
        """
        Get list of available run times.
        
        Args:
            limit: Maximum number of run times to return (most recent first)
            
        Returns:
            pd.DataFrame: List of distinct run times
        """
        try:
            query = f"""
            SELECT DISTINCT run_time_utc
            FROM {self.schema}.{self.table_prices}
            ORDER BY run_time_utc DESC
            LIMIT {limit}
            """
            
            df = pd.read_sql(query, self.engine)
            self.logger.info(f"Retrieved {len(df)} distinct run times")
            return df
            
        except Exception as e:
            self.logger.error(f"Error getting available run times: {str(e)}")
            return None
    
    def get_scenarios(self, n_recent_runs: int = 1) -> Optional[pd.DataFrame]:
        """
        Get list of available scenario groups and scenarios from recent runs.
        
        Args:
            n_recent_runs: Number of most recent runs to include (default: 1)
        
        Returns:
            pd.DataFrame: Distinct scenario groups and scenarios with country counts
        """
        try:
            query = f"""
            WITH recent_runs AS (
                SELECT DISTINCT run_time_utc
                FROM {self.schema}.{self.table_prices}
                ORDER BY run_time_utc DESC
                LIMIT {n_recent_runs}
            )
            SELECT DISTINCT
                p.scenario_group,
                p.scenario,
                COUNT(DISTINCT p.country) as num_countries
            FROM {self.schema}.{self.table_prices} p
            WHERE p.run_time_utc IN (SELECT run_time_utc FROM recent_runs)
            GROUP BY p.scenario_group, p.scenario
            ORDER BY p.scenario_group, p.scenario
            """
            
            df = pd.read_sql(query, self.engine)
            self.logger.info(f"Retrieved {len(df)} distinct scenario combinations")
            return df
            
        except Exception as e:
            self.logger.error(f"Error getting scenarios: {str(e)}")
            return None



