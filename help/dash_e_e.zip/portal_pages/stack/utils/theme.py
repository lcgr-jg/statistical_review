"""Theme for the stack sub-pages — kept in lock-step with the portal's light
theme in ``core/styles.py`` so Stack Dashboard blends with Prices / Fundamentals
visually.

All palettes here are colour-vision-deficiency friendly: we use the Okabe-Ito
8-colour scheme (https://jfly.uni-koeln.de/color/) extended with a few
perceptually-distinct muted shades for technologies that sit visually close
to each other on the stack (e.g. hydro variants).

The original stack dashboard was dark-themed — for backward compatibility the
``DARK_LAYOUT`` name still exports, but it now returns a **light** layout.
"""

# ---------------------------------------------------------------------------
# Plotly layout defaults (light, matches core/styles.py)
# ---------------------------------------------------------------------------

PLOT_HEIGHT = 480
PLOT_TEMPLATE = 'plotly_white'

_PAGE_BG = '#ffffff'        # matches COLORS['card_bg'] in core/styles.py
_TEXT_PRIMARY = '#231F20'   # matches COLORS['text_primary']
_TEXT_MUTED = '#6c757d'     # matches COLORS['text_muted']
_GRID = '#e1e4e8'           # matches COLORS['border']
_LEGEND_BG = 'rgba(255,255,255,0.95)'
_LEGEND_BORDER = '#e1e4e8'

# Exported as DARK_LAYOUT to keep existing ``from ... import DARK_LAYOUT`` call
# sites working without a sweeping refactor — the NAME is dark, the VALUES are
# light, matching the rest of the portal.
DARK_LAYOUT = dict(
    template=PLOT_TEMPLATE,
    plot_bgcolor=_PAGE_BG,
    paper_bgcolor=_PAGE_BG,
    font_color=_TEXT_PRIMARY,
    hoverlabel=dict(
        bgcolor='#ffffff',
        font_color=_TEXT_PRIMARY,
        font_size=12,
        bordercolor=_GRID,
    ),
    xaxis=dict(gridcolor=_GRID, zeroline=False),
    yaxis=dict(gridcolor=_GRID, zeroline=False),
    height=PLOT_HEIGHT,
    margin=dict(l=50, r=20, t=50, b=40),
    legend=dict(
        bgcolor=_LEGEND_BG,
        font=dict(color=_TEXT_PRIMARY, size=11),
        bordercolor=_LEGEND_BORDER,
        borderwidth=1,
    ),
    hovermode='x unified',
)

# Convenience alias so new code can use a clearer name.
LIGHT_LAYOUT = DARK_LAYOUT


# ---------------------------------------------------------------------------
# Colour-vision-deficiency-friendly palettes
# ---------------------------------------------------------------------------
#
# Base: Okabe-Ito 8-colour scheme (CVD-safe).
#   orange         #E69F00
#   sky blue       #56B4E9
#   bluish green   #009E73
#   yellow         #F0E442
#   blue           #0072B2
#   vermillion     #D55E00
#   reddish purple #CC79A7
#   grey           #999999
#
# Supplemented with a few muted shades (dark blue, brown, dark grey) for the
# long tail of technology categories. Every pair has sufficient luminance
# AND hue separation to stay distinguishable under deuteranopia / protanopia.

OKABE_ITO = [
    '#E69F00',  # orange
    '#56B4E9',  # sky blue
    '#009E73',  # bluish green
    '#F0E442',  # yellow
    '#0072B2',  # blue
    '#D55E00',  # vermillion
    '#CC79A7',  # reddish purple
    '#999999',  # grey
]

# Default chart colour sequence for line / bar traces when a semantic
# colour (by fuel) is not appropriate. Matches core/styles.CHART_COLORS in
# spirit but uses Okabe-Ito hues so it's CVD-safe.
CHART_COLORS = OKABE_ITO + [
    '#1F4E78',  # dark blue
    '#6B4E2B',  # warm brown
    '#555555',  # charcoal
]

# Legacy / semantic names used by the stack price page and a few others.
COLORS = {
    'stack_price': '#0072B2',     # blue — the primary line on the prices page
    'met_price':   '#D55E00',     # vermillion — overlay
    'demand':      '#009E73',     # bluish green
    'nuclear':     '#E69F00',     # orange
    'gas':         '#D55E00',     # vermillion
    'coal':        '#999999',     # grey
    'hydro':       '#56B4E9',     # sky blue
    'wind':        '#56B4E9',     # sky blue (bright)
    'solar':       '#F0E442',     # yellow
    'virtual_thermal': '#CC79A7', # reddish purple
    'other':       '#6c757d',     # muted neutral (matches portal text_muted)
    'normal':      '#999999',
}

# Technology keys as they appear in power_stack_dispatch_by_techno /
# prompt_output. Paired to maximise distinguishability among fuels that
# routinely stack together in the same chart.
TECHNO_COLORS = {
    'nuclear':                       '#E69F00',  # orange
    'gas':                           '#D55E00',  # vermillion
    'coal':                          '#999999',  # grey
    'lignite':                       '#6B4E2B',  # warm brown (distinguishable from grey coal)
    'hydro_ror':                     '#56B4E9',  # sky blue
    'hydro_reservoir':               '#0072B2',  # blue
    'run_of_river':                  '#56B4E9',
    'reservoirs_pumped_storage':     '#1F4E78',  # dark blue
    'reservoirs_and_pumped_storage': '#1F4E78',
    'hydro_pumped':                  '#1F4E78',
    'virtual_thermal':               '#CC79A7',  # reddish purple
    'wind':                          '#009E73',  # bluish green — high contrast vs hydros
    'solar':                         '#F0E442',  # yellow
    'biomass':                       '#3D8E5A',  # deeper green, offset from wind
    'oil':                           '#B35900',  # darker vermillion, offset from gas
    'other':                         '#999999',
    'import':                        '#B3B3B3',  # lighter grey
}

# Fuel-type naming (EQ generation curves / benchmark page). Same palette as
# TECHNO_COLORS so the two pages look consistent side-by-side.
FUEL_COLORS = {
    'gas':             '#D55E00',
    'coal':            '#999999',
    'lignite':         '#6B4E2B',
    'nuclear':         '#E69F00',
    'wind':            '#009E73',
    'solar':           '#F0E442',
    'biomass':         '#3D8E5A',
    'oil':             '#B35900',
    'hydro_ror':       '#56B4E9',
    'hydro_pumped':    '#1F4E78',
    'hydro_reservoir': '#0072B2',
}


# ---------------------------------------------------------------------------
# Dash DataTable styles — matches core/styles.DATA_TABLE_STYLE_* (light)
# ---------------------------------------------------------------------------

TABLE_STYLE_HEADER = {
    'backgroundColor': '#f2f2f2',
    'color': _TEXT_PRIMARY,
    'fontWeight': '600',
    'fontSize': '0.82rem',
    'border': f'1px solid {_GRID}',
    'textAlign': 'center',
}

TABLE_STYLE_CELL = {
    'backgroundColor': '#ffffff',
    'color': _TEXT_PRIMARY,
    'fontSize': '0.82rem',
    'border': f'1px solid {_GRID}',
    'textAlign': 'center',
    'padding': '6px 10px',
}

TABLE_STYLE_DATA_CONDITIONAL = [
    {'if': {'row_index': 'odd'}, 'backgroundColor': 'rgba(0,0,0,0.03)'},
]


def styled_layout(title: str, y_title: str = '') -> dict:
    """Return a copy of the default (light) layout with a title applied."""
    layout = dict(DARK_LAYOUT)
    layout['title'] = dict(text=title, font=dict(size=15, color=_TEXT_PRIMARY))
    if y_title:
        layout['yaxis'] = dict(
            gridcolor=_GRID, zeroline=False, title=y_title,
        )
    return layout


# ---------------------------------------------------------------------------
# No-op CSS installer — kept so stale callers don't crash. The portal owns its
# own CSS via assets/dashboard.css, so we never write a CSS file from here.
# ---------------------------------------------------------------------------

def install_theme_css(app) -> None:  # pragma: no cover - intentional no-op
    """Kept for backward compatibility. The portal owns theme CSS directly."""
    return None
