"""Lazy-loaded database singletons for the Stack Dashboard."""

import threading
import logging
import pandas as pd
from sqlalchemy import text
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_stack_query = None
_postgres = None
_met_query = None
_ice_query = None

SCHEMA = 'commod_research'


def get_stack_query():
    """PowerStackQuery singleton (uses reshaped prices table)."""
    global _stack_query
    if _stack_query is None:
        with _lock:
            if _stack_query is None:
                from jain_commods.core.interfaces.sqldb.powerstackquery import PowerStackQuery
                _stack_query = PowerStackQuery(
                    logintype='prod',
                    table_prices='power_stack_prices_reshaped',
                    table_output='power_stack_prompt_output',
                    schema=SCHEMA,
                )
                logger.info("PowerStackQuery initialised")
    return _stack_query


def get_postgres():
    """Raw SQLdb connection for reading master tables.

    Re-creates the engine if the underlying connection has gone stale
    (e.g. SSL disconnect after idle timeout).
    """
    global _postgres
    if _postgres is None:
        with _lock:
            if _postgres is None:
                from jain_commods.core.interfaces.sqldb import SQLdb
                _postgres = SQLdb(logintype='prod')
                logger.info("SQLdb (prod) initialised")
    else:
        try:
            with _postgres.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
        except Exception:
            with _lock:
                logger.warning("PostgreSQL connection stale — reconnecting")
                from jain_commods.core.interfaces.sqldb import SQLdb
                _postgres = SQLdb(logintype='prod')
                logger.info("SQLdb (prod) re-initialised")
    return _postgres


def get_met_query():
    """MeteologicaQuery singleton for Snowflake price forecasts."""
    global _met_query
    if _met_query is None:
        with _lock:
            if _met_query is None:
                from jain_commods.core.interfaces.snowflake.mlgquery import MeteologicaQuery
                _met_query = MeteologicaQuery()
                logger.info("MeteologicaQuery initialised")
    return _met_query


def get_ice_query():
    """ICEFuturesQuery singleton for coal/carbon/gasoil from Snowflake."""
    global _ice_query
    if _ice_query is None:
        with _lock:
            if _ice_query is None:
                from jain_commods.core.interfaces.snowflake import ICEFuturesQuery
                _ice_query = ICEFuturesQuery()
                logger.info("ICEFuturesQuery initialised")
    return _ice_query


def get_latest_run_time(country: str = None, scenario_group: str = None):
    """Get the latest run_time from power_stack_prices_reshaped.

    Uses a bare index-only scan (no WHERE filters) because the btree on
    run_time_utc can be scanned backwards in <100ms.  The run_time is
    shared across all countries / scenario_groups in a single stack run,
    so filters are unnecessary.
    """
    pg = get_postgres()
    with pg.engine.connect() as conn:
        rt = conn.execute(text(
            "SELECT run_time_utc "
            "FROM commod_research.power_stack_prices_reshaped "
            "ORDER BY run_time_utc DESC LIMIT 1"
        )).scalar()
    return rt


def get_scenarios_from_stats(country: str, scenario_group: str, run_time=None):
    """Get available scenario names from stats table (fast, indexed)."""
    if run_time is None:
        run_time = get_latest_run_time(country, scenario_group)
    if run_time is None:
        return []
    pg = get_postgres()
    with pg.engine.connect() as conn:
        df = pd.read_sql(text(
            "SELECT DISTINCT statistic FROM commod_research.power_stack_stats "
            "WHERE country = :c AND scenario_group = :sg AND run_time_utc = :rt"
        ), conn, params={'c': country, 'sg': scenario_group, 'rt': run_time})
    return df['statistic'].tolist() if not df.empty else []


def read_table(
    table: str,
    schema: str = SCHEMA,
    columns: Optional[List[str]] = None,
    where: str = '',
    order_by: str = '',
    params: Optional[Dict] = None,
    limit: Optional[int] = None,
) -> pd.DataFrame:
    """Read a table from PostgreSQL."""
    pg = get_postgres()
    col_str = ', '.join(columns) if columns else '*'
    q = f"SELECT {col_str} FROM {schema}.{table}"
    if where:
        q += f" WHERE {where}"
    if order_by:
        q += f" ORDER BY {order_by}"
    if limit:
        q += f" LIMIT {limit}"
    try:
        with pg.engine.connect() as conn:
            return pd.read_sql(text(q), conn, params=params or {})
    except Exception as exc:
        logger.error("read_table %s.%s: %s", schema, table, exc)
        return pd.DataFrame()
