"""
Benchmark Page
==============
Compares realised spot prices (from EQ) against the stack model's ENS_MEDIUM
P50 (median across ensemble members) forecast for the last 7 days, for DE & FR.

For each delivery day the forecast run used is the one closest to 11:00 UTC on
the preceding *business* day — Saturday and Sunday both use the Friday run.
"""

import logging
from datetime import datetime, timedelta, date, time as dt_time

import dash
import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import html, dcc, Input, Output
from plotly.subplots import make_subplots
from sqlalchemy import text as sa_text

from portal_pages.stack.utils.db import get_postgres
from portal_pages.stack.utils.cache import cached, clear_all
from portal_pages.stack.utils.theme import DARK_LAYOUT

logger = logging.getLogger(__name__)

_COUNTRIES = ['DE', 'FR']
_TARGET_HOUR_UTC = 11
_LOOKBACK_DAYS = 7
_SCENARIO_GROUP = 'ENS_MEDIUM'

# ---------------------------------------------------------------------------
# Spot prices — pulled from the portal's S3-backed price cache
# (``core.data.get_prices()['power_spot_normalized']``). This is the same
# cache the Prices dashboard uses, so the Benchmark page automatically
# sees whatever the scheduled price_data refresh produced.
# ---------------------------------------------------------------------------


@cached
def _fetch_spot(country: str, begin: date, end: date) -> pd.DataFrame:
    """Hourly EPEX spot prices for [begin, end), returned as UTC-naive 'spot' column."""
    try:
        from core import data as data_service
        cache = data_service.get_prices()
    except Exception as exc:
        logger.error("price_data cache read failed: %s", exc)
        return pd.DataFrame()
    if not cache:
        return pd.DataFrame()

    spot_norm = cache.get('power_spot_normalized')
    if spot_norm is None or getattr(spot_norm, 'empty', True):
        return pd.DataFrame()

    df = spot_norm[
        (spot_norm['zone'].str.upper() == country.upper())
        & (spot_norm['exchange'].str.upper() == 'EPEX')
        & (spot_norm['currency'].str.upper() == 'EUR')
        & (spot_norm['frequency'].str.upper() == 'H')
    ]
    if df.empty:
        return pd.DataFrame()

    # Convert CET-aware timestamps to UTC-naive, matching the previous EQ signature.
    vd = pd.to_datetime(df['valuedate'])
    if vd.dt.tz is not None:
        vd = vd.dt.tz_convert('UTC').dt.tz_localize(None)

    begin_ts = pd.Timestamp(begin)
    end_ts = pd.Timestamp(end)
    mask = (vd >= begin_ts) & (vd < end_ts)

    result = pd.DataFrame({'spot': df.loc[mask, 'value'].values}, index=vd[mask])
    result.index.name = 'utc'
    result = result.sort_index()
    # Collapse duplicates that can arise at DST switch (keep first).
    result = result[~result.index.duplicated(keep='first')]
    return result.dropna()


# ---------------------------------------------------------------------------
# Stack model forecast prices — ENS_MEDIUM P50
# ---------------------------------------------------------------------------

@cached
def _fetch_ens_run_times(country: str, n_days: int = 10) -> list:
    """Get all ENS_MEDIUM run_times from the last *n_days* days."""
    pg = get_postgres()
    q = sa_text("""
        SELECT DISTINCT run_time_utc
        FROM commod_research.power_stack_prices_reshaped
        WHERE country = :c
          AND scenario_group = :sg
          AND run_time_utc >= :since
        ORDER BY run_time_utc
    """)
    since = datetime.utcnow() - timedelta(days=n_days)
    with pg.engine.connect() as conn:
        rows = conn.execute(q, {'c': country, 'sg': _SCENARIO_GROUP,
                                 'since': since}).fetchall()
    return [r[0] for r in rows]


def _forecast_run_date(delivery_date: date) -> date:
    """The business day before delivery whose ~11h run we want.

    Sat/Sun delivery → use Friday's run.
    Mon delivery → use Friday's run (standard D-1).
    Tue–Fri delivery → use the previous calendar day.
    """
    dow = delivery_date.isoweekday()  # Mon=1 … Sun=7
    if dow == 6:        # Saturday → Friday
        return delivery_date - timedelta(days=1)
    elif dow == 7:      # Sunday → Friday
        return delivery_date - timedelta(days=2)
    elif dow == 1:      # Monday → Friday
        return delivery_date - timedelta(days=3)
    else:               # Tue–Fri → previous day
        return delivery_date - timedelta(days=1)


def _pick_run_for_delivery_day(delivery_date: date,
                               run_times: list) -> datetime | None:
    """Pick the run_time closest to 11:00 UTC on the appropriate run date."""
    run_date = _forecast_run_date(delivery_date)
    target = datetime.combine(run_date, dt_time(_TARGET_HOUR_UTC, 0))

    best, best_diff = None, None
    for rt in run_times:
        rt_naive = rt.replace(tzinfo=None) if hasattr(rt, 'tzinfo') and rt.tzinfo else rt
        if rt_naive.date() != run_date:
            continue
        diff = abs((rt_naive - target).total_seconds())
        if best_diff is None or diff < best_diff:
            best, best_diff = rt, diff

    return best


@cached
def _fetch_ens_p50_forecast(country: str, run_time,
                            delivery_date: date) -> pd.DataFrame:
    """P50 (median) across ENS_MEDIUM members for a single delivery day."""
    pg = get_postgres()
    d_start = datetime.combine(delivery_date, dt_time(0, 0))
    d_end = d_start + timedelta(days=1)
    q = sa_text("""
        SELECT start_time_utc,
               percentile_cont(0.50) WITHIN GROUP (ORDER BY price) AS price
        FROM commod_research.power_stack_prices_reshaped
        WHERE run_time_utc = :rt AND country = :c
          AND scenario_group = :sg
          AND start_time_utc >= :d0 AND start_time_utc < :d1
        GROUP BY start_time_utc
        ORDER BY start_time_utc
    """)
    with pg.engine.connect() as conn:
        rows = conn.execute(q, {'rt': run_time, 'c': country,
                                 'sg': _SCENARIO_GROUP,
                                 'd0': d_start, 'd1': d_end}).fetchall()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows, columns=['utc', 'forecast'])
    df['utc'] = pd.to_datetime(df['utc'])
    if df['utc'].dt.tz is not None:
        df['utc'] = df['utc'].dt.tz_localize(None)
    df = df.set_index('utc')
    return df


# ---------------------------------------------------------------------------
# Build the combined benchmark DataFrame
# ---------------------------------------------------------------------------

def _build_benchmark(country: str) -> tuple[pd.DataFrame, dict]:
    """Return (merged_df, metadata_dict) for the last 7 days + today + tomorrow."""
    today = date.today()
    tomorrow = today + timedelta(days=1)
    begin = today - timedelta(days=_LOOKBACK_DAYS)

    # Fetch spot through end of tomorrow (day-ahead spot may be published)
    spot = _fetch_spot(country, begin, tomorrow + timedelta(days=1))
    run_times = _fetch_ens_run_times(country, n_days=_LOOKBACK_DAYS + 5)

    meta = {}
    frames = []

    # offset -1 = tomorrow (today's run), 0 = today, 1 = yesterday, …
    for offset in range(_LOOKBACK_DAYS, -2, -1):
        delivery = today - timedelta(days=offset)
        rt = _pick_run_for_delivery_day(delivery, run_times)
        if rt is None:
            logger.warning("Benchmark %s: no ENS_MEDIUM run for delivery %s "
                           "(run date %s)", country, delivery,
                           _forecast_run_date(delivery))
            continue

        fc = _fetch_ens_p50_forecast(country, rt, delivery)
        if fc.empty:
            logger.warning("Benchmark %s: empty P50 for delivery %s (run %s)",
                           country, delivery, rt)
            continue

        rt_naive = rt.replace(tzinfo=None) if hasattr(rt, 'tzinfo') and rt.tzinfo else rt
        meta[delivery.isoformat()] = rt_naive.strftime('%Y-%m-%d %H:%M UTC')
        frames.append(fc)

    if not frames:
        return pd.DataFrame(), meta

    forecast_df = pd.concat(frames)
    forecast_df = forecast_df[~forecast_df.index.duplicated(keep='last')]

    if spot.empty:
        merged = forecast_df.copy()
        merged['spot'] = np.nan
    else:
        merged = spot.join(forecast_df, how='outer')

    merged = merged.sort_index()
    merged = merged.loc[str(begin):str(tomorrow + timedelta(days=1))]

    return merged, meta


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

def _make_benchmark_figure(country: str, df: pd.DataFrame, meta: dict) -> go.Figure:
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text=f"No benchmark data for {country}",
                           xref="paper", yref="paper", x=0.5, y=0.5,
                           showarrow=False, font=dict(size=18, color='#231F20'))
        fig.update_layout(**DARK_LAYOUT)
        return fig

    fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                        vertical_spacing=0.08, row_heights=[0.7, 0.3])

    fig.add_trace(go.Scatter(
        x=df.index, y=df['spot'], name='Spot (actual)',
        line=dict(color='#4dabf7', width=2),
    ), row=1, col=1)

    fig.add_trace(go.Scatter(
        x=df.index, y=df['forecast'], name='ENS_MEDIUM P50 (D-1 ~11h)',
        line=dict(color='#ffa94d', width=2, dash='dot'),
    ), row=1, col=1)

    # Error = forecast − spot
    if 'spot' in df.columns and 'forecast' in df.columns:
        err = df['forecast'] - df['spot']
        fig.add_trace(go.Bar(
            x=df.index, y=err, name='Error (fc − spot)',
            marker_color=err.apply(lambda v: '#51cf66' if v >= 0 else '#ff6b6b'),
            showlegend=False,
        ), row=2, col=1)

    # Stats
    valid = df.dropna(subset=['spot', 'forecast'])
    if not valid.empty:
        mae = (valid['forecast'] - valid['spot']).abs().mean()
        rmse = np.sqrt(((valid['forecast'] - valid['spot']) ** 2).mean())
        bias = (valid['forecast'] - valid['spot']).mean()
        title_text = (f"{country} — Spot vs Stack Forecast (last {_LOOKBACK_DAYS} days)"
                      f"<br><sup>MAE: {mae:.1f} €/MWh | RMSE: {rmse:.1f} | "
                      f"Bias: {bias:+.1f}</sup>")
    else:
        title_text = f"{country} — Spot vs Stack Forecast (last {_LOOKBACK_DAYS} days)"

    layout_kw = {k: v for k, v in DARK_LAYOUT.items()
                 if k not in ('height', 'margin')}
    fig.update_layout(
        **layout_kw,
        height=550,
        margin=dict(l=50, r=20, t=80, b=40),
        title=dict(text=title_text, font=dict(size=15, color='#231F20'), x=0.5),
    )
    fig.update_yaxes(title_text='EUR/MWh', row=1, col=1)
    fig.update_yaxes(title_text='Error', row=2, col=1)
    fig.update_xaxes(type='date', row=2, col=1)

    return fig


def _make_run_table(meta: dict) -> list:
    """Render a small table showing which run was used per delivery day."""
    if not meta:
        return []
    rows = []
    for delivery, rt_str in sorted(meta.items()):
        rows.append({'Delivery Day': delivery, 'Stack Run Used': rt_str})
    return [
        html.H6("Forecast runs used", className="mt-3",
                 style={"color": "#231F20"}),
        dbc.Table.from_dataframe(
            pd.DataFrame(rows), striped=True, bordered=True, hover=True, size='sm', className="mt-1",
        ),
    ]



# ---------------------------------------------------------------------------
# Dash layout & callbacks
# ---------------------------------------------------------------------------

def layout():
    return html.Div([
        dbc.Container([
            dbc.Row([
                dbc.Col(html.H4("Benchmark", style={"color": "#231F20"}), width="auto"),
                dbc.Col(dbc.Button("Refresh", id="bench-refresh",
                                   color="primary", size="sm"), width="auto"),
                dbc.Col(html.Span(id="bench-status", style={"color": "#adb5bd"}),
                        width="auto"),
            ], className="mt-3 mb-3 align-items-center"),
            dbc.Tabs(
                id="bench-tabs",
                active_tab="DE",
                children=[dbc.Tab(label=c, tab_id=c) for c in _COUNTRIES],
            ),
            dcc.Loading(html.Div(id="bench-content"), type="circle"),
        ], fluid=True),
    ])


def register_callbacks(app):
    @app.callback(
        [Output("bench-content", "children"),
         Output("bench-status", "children")],
        [Input("bench-tabs", "active_tab"),
         Input("bench-refresh", "n_clicks")],
    )
    def update(country, n_clicks):
        ctx = dash.callback_context
        triggered = ctx.triggered[0]['prop_id'] if ctx.triggered else ''

        if 'bench-refresh' in triggered:
            clear_all()
            status = f"Refreshed {datetime.now().strftime('%H:%M:%S')}"
        else:
            status = ""

        try:
            df, meta = _build_benchmark(country)
            fig = _make_benchmark_figure(country, df, meta)
            table = _make_run_table(meta)
            content = html.Div([
                dcc.Graph(figure=fig),
                *table,
            ])
        except Exception as exc:
            logger.error("Benchmark %s: %s", country, exc, exc_info=True)
            content = dbc.Alert(f"Error: {exc}", color="danger")

        return content, status
