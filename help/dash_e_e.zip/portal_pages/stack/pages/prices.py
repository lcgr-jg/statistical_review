"""
Page 1 — Stack Prices vs Meteologica Price Forecasts (DE / FR)

Optimised: uses power_stack_stats (2M indexed rows) for metadata,
direct SQL with exact run_time_utc for data.
"""
import logging
import calendar
from datetime import datetime, timedelta, date, time as dt_time

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output, dash_table, callback_context
from sqlalchemy import text as sa_text

from portal_pages.stack.utils.db import get_postgres, get_met_query, get_latest_run_time, get_scenarios_from_stats
from portal_pages.stack.utils.cache import cached, clear_all
from portal_pages.stack.utils.theme import (
    styled_layout, COLORS, DARK_LAYOUT,
    TABLE_STYLE_HEADER, TABLE_STYLE_CELL, TABLE_STYLE_DATA_CONDITIONAL,
)
logger = logging.getLogger(__name__)

_CODE_TO_MET = {'DE': 'Germany', 'FR': 'France'}
_MET_OFFSET = 'post_ECMWF-ENS'

_EQ_PRICE_FORECAST = {
    'DE': 'DE Price Spot EUR/MWh H Forecast',
    'FR': 'FR Price Spot EUR/MWh H Forecast',
}

_eq_client = None
def _get_eq_client():
    global _eq_client
    if _eq_client is None:
        from jain_commods.core.cache.utils.eq import EQ_API_KEY
        from jain_commods.core.interfaces.energyquantified.client import EQClient
        _eq_client = EQClient(api_key=EQ_API_KEY, timeout=60.0)
    return _eq_client

SCENARIO_GROUPS = [
    {'label': 'Basecase', 'value': 'BASECASE'},
    {'label': 'Deterministic', 'value': 'DETERMINISTIC'},
    {'label': 'Ensemble Medium', 'value': 'ENS_MEDIUM'},
    {'label': 'Ensemble Extended', 'value': 'ENS_EXTENDED'},
]


def _utc_to_cet(series):
    s = pd.to_datetime(series)
    if s.dt.tz is None:
        s = s.dt.tz_localize('UTC')
    return s.dt.tz_convert('Europe/Berlin').dt.tz_localize(None)


@cached
def _fetch_available_scenarios(country: str, scenario_group: str) -> list:
    """Return scenario names from the small stats table (~0.3s)."""
    try:
        return get_scenarios_from_stats(country, scenario_group)
    except Exception as exc:
        logger.warning("Fetch scenarios %s %s: %s", country, scenario_group, exc)
        return []


@cached
def _get_run_time(country: str, scenario_group: str):
    """Latest run_time from stats table (~1s)."""
    try:
        return get_latest_run_time(country, scenario_group)
    except Exception as exc:
        logger.warning("get_run_time %s %s: %s", country, scenario_group, exc)
        return None


@cached
def _fetch_stack_prices(country: str, scenario_group: str,
                        scenario: str = None) -> pd.DataFrame:
    """Direct SQL with exact run_time — uses the run_time_utc index (~1.5s)."""
    try:
        rt = _get_run_time(country, scenario_group)
        if rt is None:
            return pd.DataFrame()
        pg = get_postgres()
        if scenario:
            q = sa_text("""
                SELECT start_time_utc, price, run_time_utc, scenario
                FROM commod_research.power_stack_prices_reshaped
                WHERE run_time_utc = :rt AND country = :c
                  AND scenario_group = :sg AND scenario = :scen
                ORDER BY start_time_utc
            """)
            params = {'rt': rt, 'c': country, 'sg': scenario_group, 'scen': scenario}
        else:
            q = sa_text("""
                SELECT start_time_utc, price, run_time_utc, scenario
                FROM commod_research.power_stack_prices_reshaped
                WHERE run_time_utc = :rt AND country = :c
                  AND scenario_group = :sg
                ORDER BY start_time_utc
            """)
            params = {'rt': rt, 'c': country, 'sg': scenario_group}
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params=params)
        if df.empty:
            return df
        df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        return df.sort_values('start_time_cet')
    except Exception as exc:
        logger.warning("Stack prices %s %s: %s", country, scenario_group, exc)
        return pd.DataFrame()


@cached
def _fetch_original_prices(country: str, scenario_group: str,
                           scenario: str = None) -> pd.DataFrame:
    """Fetch from the non-reshaped power_stack_prices table for comparison."""
    try:
        rt = _get_run_time(country, scenario_group)
        if rt is None:
            return pd.DataFrame()
        pg = get_postgres()
        if scenario:
            q = sa_text("""
                SELECT start_time_utc, price, run_time_utc, scenario
                FROM commod_research.power_stack_prices
                WHERE run_time_utc = :rt AND country = :c
                  AND scenario_group = :sg AND scenario = :scen
                ORDER BY start_time_utc
            """)
            params = {'rt': rt, 'c': country, 'sg': scenario_group, 'scen': scenario}
        else:
            q = sa_text("""
                SELECT start_time_utc, price, run_time_utc, scenario
                FROM commod_research.power_stack_prices
                WHERE run_time_utc = :rt AND country = :c
                  AND scenario_group = :sg
                ORDER BY start_time_utc
            """)
            params = {'rt': rt, 'c': country, 'sg': scenario_group}
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params=params)
        if df.empty:
            return df
        df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        return df.sort_values('start_time_cet')
    except Exception as exc:
        logger.warning("Original prices %s %s: %s", country, scenario_group, exc)
        return pd.DataFrame()


@cached
def _fetch_original_p50(country: str, scenario_group: str) -> pd.DataFrame:
    """P50 from the non-reshaped table for ensemble comparison."""
    try:
        rt = _get_run_time(country, scenario_group)
        if rt is None:
            return pd.DataFrame()
        pg = get_postgres()
        q = sa_text("""
            SELECT start_time_utc, run_time_utc,
                   percentile_cont(0.50) WITHIN GROUP (ORDER BY price) AS price,
                   count(*) AS n_members
            FROM commod_research.power_stack_prices
            WHERE run_time_utc = :rt AND country = :c
              AND scenario_group = :sg
            GROUP BY start_time_utc, run_time_utc
            ORDER BY start_time_utc
        """)
        params = {'rt': rt, 'c': country, 'sg': scenario_group}
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params=params)
        if df.empty:
            return df
        df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        return df.sort_values('start_time_cet')
    except Exception as exc:
        logger.warning("Original P50 %s %s: %s", country, scenario_group, exc)
        return pd.DataFrame()


@cached
def _fetch_ensemble_p50(country: str, scenario_group: str) -> pd.DataFrame:
    """Compute median (P50) across ensemble members in SQL."""
    try:
        rt = _get_run_time(country, scenario_group)
        if rt is None:
            return pd.DataFrame()
        pg = get_postgres()
        q = sa_text("""
            SELECT start_time_utc, run_time_utc,
                   percentile_cont(0.50) WITHIN GROUP (ORDER BY price) AS price,
                   count(*) AS n_members
            FROM commod_research.power_stack_prices_reshaped
            WHERE run_time_utc = :rt AND country = :c
              AND scenario_group = :sg
            GROUP BY start_time_utc, run_time_utc
            ORDER BY start_time_utc
        """)
        params = {'rt': rt, 'c': country, 'sg': scenario_group}
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params=params)
        if df.empty:
            return df
        df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        return df.sort_values('start_time_cet')
    except Exception as exc:
        logger.warning("Ensemble P50 %s %s: %s", country, scenario_group, exc)
        return pd.DataFrame()


@cached
def _fetch_met_prices(country_code: str) -> pd.DataFrame:
    mq = get_met_query()
    country = _CODE_TO_MET.get(country_code, country_code)
    now = datetime.now()
    today = now.date()

    candidates = []
    for days_back in range(4):
        d = today - timedelta(days=days_back)
        for release in ['18', '12', '06', '00']:
            if d == today and int(release) > now.hour:
                continue
            candidates.append((d, release))

    for d, release in candidates:
        try:
            raw = mq.get_meteologica_forecast(
                issue_date=datetime.combine(d, datetime.min.time()),
                release=release,
                offset=_MET_OFFSET,
                country=country,
                category='PowerPrice',
            )
            if raw is None or raw.empty:
                continue
            ts_col = next((c for c in raw.columns if 'DATETIME' in c.upper() or 'TIMESTAMP' in c.upper()), None)
            val_col = None
            if 'FORECAST' in raw.columns:
                val_col = 'FORECAST'
            else:
                for c in raw.columns:
                    if c.startswith('VALUE') or c.startswith('MEMBER'):
                        val_col = c
                        break
            if ts_col is None or val_col is None:
                continue
            out = raw[[ts_col, val_col]].copy()
            out.columns = ['ts', 'price']
            out['price'] = pd.to_numeric(out['price'], errors='coerce')
            out['ts'] = pd.to_datetime(out['ts'])
            if out['ts'].dt.tz is None:
                out['ts'] = out['ts'].dt.tz_localize('UTC')
            out['ts'] = out['ts'].dt.tz_convert('Europe/Berlin').dt.tz_localize(None)
            out = out.set_index('ts').sort_index()
            out.attrs['met_date'] = d
            out.attrs['met_release'] = release
            out.attrs['met_nwp'] = 'ECMWF-ENS'
            return out
        except Exception:
            continue
    return pd.DataFrame()


@cached
def _fetch_eq_forecast(country_code: str, tag: str = 'postfix') -> pd.DataFrame:
    """Fetch latest EQ day-ahead price forecast for a given tag (postfix/prefix)."""
    curve = _EQ_PRICE_FORECAST.get(country_code)
    if not curve:
        return pd.DataFrame()
    try:
        client = _get_eq_client()
        df = client.get_forecasts(curve, tags=tag, limit=1)
        if df is None or df.empty:
            return pd.DataFrame()
        out = pd.DataFrame({'price': df.iloc[:, 0].values}, index=df.index)
        if out.index.tz is not None:
            out.index = out.index.tz_localize(None)
        out.index.name = 'ts'
        issued_raw = str(df.columns[0][1]) if len(df.columns[0]) > 1 else ''
        out.attrs['eq_issued'] = issued_raw
        out.attrs['eq_tag'] = tag
        return out.sort_index()
    except Exception as exc:
        logger.warning("EQ forecast %s tag=%s: %s", country_code, tag, exc)
        return pd.DataFrame()


def _fetch_latest_eq_forecast(country_code: str,
                              tags: tuple[str, ...] = ('postfix', 'prefix')) -> pd.DataFrame:
    """Fetch latest EQ forecast across supported tags."""
    best = pd.DataFrame()
    best_ts = None

    for tag in tags:
        df = _fetch_eq_forecast(country_code, tag=tag)
        if df.empty:
            continue

        issued_raw = str(df.attrs.get('eq_issued', '')).strip()
        issued_ts = pd.to_datetime(issued_raw, errors='coerce', utc=True)

        if best.empty:
            best = df
            best_ts = issued_ts
            continue

        # Prefer the most recent issue time when parseable.
        if pd.notna(issued_ts) and (pd.isna(best_ts) or issued_ts > best_ts):
            best = df
            best_ts = issued_ts

    return best


# ── Price Comparison Table: Stack vs EEX Settlement ────────────────────

_EEX_BASE = {'DE': 'DE Futures Power Base EUR/MWh EEX OHLC',
             'FR': 'FR Futures Power Base EUR/MWh EEX OHLC'}
_EEX_PEAK = {'DE': 'DE Futures Power Peak EUR/MWh EEX OHLC',
             'FR': 'FR Futures Power Peak EUR/MWh EEX OHLC'}


def _previous_business_day(d: date) -> date:
    """Step back to the most recent Mon–Fri."""
    d -= timedelta(days=1)
    while d.isoweekday() > 5:
        d -= timedelta(days=1)
    return d


def _build_product_windows(today: date) -> list[dict]:
    """Define tradeable product windows.

    Each dict: {label, start, end, has_peak}
    start/end are dates, range is [start, end) in days.
    """
    products = []
    dow = today.isoweekday()  # Mon=1 … Sun=7

    # -- Balance-of-week individual days (today → Friday) --
    if dow <= 5:
        for d_offset in range(0, 6 - dow):
            d = today + timedelta(days=d_offset)
            name = d.strftime('%a %d %b')
            products.append({'label': name, 'start': d,
                             'end': d + timedelta(days=1), 'has_peak': True})

    # -- Weekend (Sat + Sun of this week) — no peak --
    days_to_sat = 6 - dow if dow <= 5 else (6 - dow) % 7
    sat = today + timedelta(days=days_to_sat)
    sun = sat + timedelta(days=1)
    products.append({'label': f'Weekend {sat.strftime("%d %b")}',
                     'start': sat, 'end': sun + timedelta(days=1),
                     'has_peak': False})

    # -- Week+1, Week+2 (ISO weeks starting Monday) --
    next_mon = today + timedelta(days=(8 - dow) % 7 or 7)
    for i in range(2):
        w_start = next_mon + timedelta(weeks=i)
        w_end = w_start + timedelta(days=7)
        wk_num = w_start.isocalendar()[1]
        products.append({'label': f'Wk {wk_num} ({w_start.strftime("%d %b")})',
                         'start': w_start, 'end': w_end, 'has_peak': True})

    # -- M+1, M+2 --
    y, m = today.year, today.month
    for i in range(1, 3):
        nm = m + i
        ny = y + (nm - 1) // 12
        nm = ((nm - 1) % 12) + 1
        m_start = date(ny, nm, 1)
        m_end_day = calendar.monthrange(ny, nm)[1]
        m_end = date(ny, nm, m_end_day) + timedelta(days=1)
        products.append({'label': f'{calendar.month_abbr[nm]} {ny}',
                         'start': m_start, 'end': m_end, 'has_peak': True})

    # -- Q+1, Q+2, Q+3 --
    cur_q = (today.month - 1) // 3 + 1
    for i in range(1, 4):
        q_num = cur_q + i
        q_year = y + (q_num - 1) // 4
        q_num = ((q_num - 1) % 4) + 1
        q_start = date(q_year, (q_num - 1) * 3 + 1, 1)
        q_end_m = q_num * 3
        q_end = date(q_year, q_end_m, calendar.monthrange(q_year, q_end_m)[1]) + timedelta(days=1)
        products.append({'label': f'Q{q_num} {q_year}',
                         'start': q_start, 'end': q_end, 'has_peak': True})

    # -- Cal+1 --
    cal_year = y + 1
    products.append({'label': f'Cal {cal_year}',
                     'start': date(cal_year, 1, 1),
                     'end': date(cal_year + 1, 1, 1), 'has_peak': True})

    return products


def _compute_base_peak(hourly_utc: pd.DataFrame, start: date, end: date,
                       has_peak: bool) -> dict:
    """Compute base / peak / spread from hourly UTC prices for a delivery window.

    CET peak = Mon–Fri hours 8–19 (i.e. 08:00–20:00 CET).
    """
    if hourly_utc.empty:
        return {}
    cet_idx = hourly_utc.index.tz_localize('UTC').tz_convert('Europe/Berlin')
    s = pd.Series(hourly_utc['price'].values, index=cet_idx)
    mask = (s.index >= pd.Timestamp(start, tz='Europe/Berlin')) & \
           (s.index < pd.Timestamp(end, tz='Europe/Berlin'))
    s = s[mask]
    if s.empty:
        return {}
    base = round(float(s.mean()), 2)
    result = {'Base': base}
    if has_peak:
        peak_mask = (s.index.weekday < 5) & (s.index.hour >= 8) & (s.index.hour < 20)
        peak_vals = s[peak_mask]
        if not peak_vals.empty:
            peak = round(float(peak_vals.mean()), 2)
            result['Peak'] = peak
            result['B-P'] = round(base - peak, 2)
    return result


@cached
def _fetch_eex_latest(country: str) -> tuple[pd.DataFrame, pd.DataFrame, date]:
    """Fetch previous business day's EEX base + peak OHLC for all contracts."""
    client = _get_eq_client()
    tday = _previous_business_day(date.today())

    base_curve = _EEX_BASE.get(country)
    peak_curve = _EEX_PEAK.get(country)
    base_df = pd.DataFrame()
    peak_df = pd.DataFrame()

    if base_curve:
        try:
            base_df = client.get_ohlc_latest(base_curve, trading_date=tday)
        except Exception as exc:
            logger.error("EEX base %s: %s", country, exc)
    if peak_curve:
        try:
            peak_df = client.get_ohlc_latest(peak_curve, trading_date=tday)
        except Exception as exc:
            logger.error("EEX peak %s: %s", country, exc)

    return base_df, peak_df, tday


def _match_eex_contract(eex_df: pd.DataFrame, product: dict) -> float | None:
    """Find the EEX settlement price whose delivery matches a product window."""
    if eex_df.empty or 'settlement' not in eex_df.columns:
        return None

    p_start = pd.Timestamp(product['start'])
    p_end = pd.Timestamp(product['end'] - timedelta(days=1))  # inclusive end

    for _, row in eex_df.iterrows():
        delivery = pd.Timestamp(row['delivery'])
        period = row.get('period', '')

        if period == 'DAY':
            c_start = delivery
            c_end = delivery
        elif period == 'WEEKEND':
            c_start = delivery  # Saturday
            c_end = delivery + pd.Timedelta(days=1)  # Sunday
        elif period == 'WEEK':
            c_start = delivery
            c_end = delivery + pd.Timedelta(days=6)
        elif period == 'MONTH':
            c_start = delivery
            m_end = calendar.monthrange(delivery.year, delivery.month)[1]
            c_end = pd.Timestamp(date(delivery.year, delivery.month, m_end))
        elif period == 'QUARTER':
            c_start = delivery
            q_end_m = delivery.month + 2
            q_end_y = delivery.year
            if q_end_m > 12:
                q_end_m -= 12
                q_end_y += 1
            c_end = pd.Timestamp(date(q_end_y, q_end_m,
                                      calendar.monthrange(q_end_y, q_end_m)[1]))
        elif period == 'YEAR':
            c_start = delivery
            c_end = pd.Timestamp(date(delivery.year, 12, 31))
        else:
            continue

        if c_start == p_start and c_end == p_end:
            val = row['settlement']
            if pd.notna(val):
                return round(float(val), 2)

    return None


def _build_price_comparison_table(country: str, hourly_utc: pd.DataFrame):
    """Build the stack-vs-EEX comparison table for tradeable products."""
    today = date.today()
    products = _build_product_windows(today)

    eex_base_df, eex_peak_df, eex_date = _fetch_eex_latest(country)

    rows = []
    for p in products:
        stack = _compute_base_peak(hourly_utc, p['start'], p['end'], p['has_peak'])
        eex_base = _match_eex_contract(eex_base_df, p)
        eex_peak = _match_eex_contract(eex_peak_df, p) if p['has_peak'] else None

        row = {'Product': p['label']}
        row['Stack Base'] = stack.get('Base', '')
        row['EEX Base'] = eex_base if eex_base is not None else ''

        if p['has_peak']:
            row['Stack Peak'] = stack.get('Peak', '')
            row['EEX Peak'] = eex_peak if eex_peak is not None else ''
            row['Stack B-P'] = stack.get('B-P', '')
            if eex_base is not None and eex_peak is not None:
                row['EEX B-P'] = round(eex_base - eex_peak, 2)
            else:
                row['EEX B-P'] = ''
        else:
            row['Stack Peak'] = '—'
            row['EEX Peak'] = '—'
            row['Stack B-P'] = '—'
            row['EEX B-P'] = '—'

        rows.append(row)

    if not rows:
        return html.Div("No products available", style={'color': '#8a8f9a'})

    columns = ['Product', 'Stack Base', 'EEX Base',
               'Stack Peak', 'EEX Peak', 'Stack B-P', 'EEX B-P']

    cond = list(TABLE_STYLE_DATA_CONDITIONAL)
    for col_pair in [('Stack Base', 'EEX Base'),
                     ('Stack Peak', 'EEX Peak')]:
        stack_col, eex_col = col_pair
        cond.append({
            'if': {
                'filter_query': f'{{{stack_col}}} > {{{eex_col}}}',
                'column_id': stack_col,
            },
            'color': '#ff6b6b',
        })
        cond.append({
            'if': {
                'filter_query': f'{{{stack_col}}} < {{{eex_col}}}',
                'column_id': stack_col,
            },
            'color': '#51cf66',
        })

    return html.Div([
        html.H6(f"Stack vs EEX Settlement ({eex_date.strftime('%d %b %Y')})",
                className='mt-3 mb-2',
                style={'color': '#231F20', 'fontSize': '0.9rem'}),
        dash_table.DataTable(
            data=rows,
            columns=[{'name': c, 'id': c} for c in columns],
            style_header=TABLE_STYLE_HEADER,
            style_cell=TABLE_STYLE_CELL,
            style_data_conditional=cond,
            page_size=20,
        ),
    ])


def _build_daily_table(series_list):
    """Build daily-average table from a list of (index, values, label) tuples."""
    rows = {}
    for idx, vals, label in series_list:
        if idx is None or vals is None:
            continue
        s = pd.Series(vals, index=idx)
        for d, g in s.groupby(s.index.date):
            rows.setdefault(str(d), {})[label] = round(g.mean(), 2)
    if not rows:
        return html.Div("No data", style={'color': '#8a8f9a'})
    all_cols = ['Date']
    for _, _, label in series_list:
        if label not in all_cols:
            all_cols.append(label)
    records = [{'Date': k, **v} for k, v in sorted(rows.items())]
    cols = [{'name': c, 'id': c} for c in all_cols if any(c in r for r in records)]
    return dash_table.DataTable(
        data=records, columns=cols,
        style_header=TABLE_STYLE_HEADER,
        style_cell=TABLE_STYLE_CELL,
        style_data_conditional=TABLE_STYLE_DATA_CONDITIONAL,
        page_size=14,
        sort_action='native',
    )


# ── Price-setting plant (marginal unit) per hour ──────────────────────────

MARGINAL_TECHNO_COLORS = {
    'gas': '#ff6b6b',
    'coal': '#868e96',
    'lignite': '#6b5b4c',
    'oil': '#e8590c',
    'biomass': '#51cf66',
    'virtual_thermal': '#cc5de8',
    'nuclear': '#ffa94d',
    'wind': '#74c0fc',
    'solar': '#ffd43b',
    'run_of_river': '#4dabf7',
    'reservoirs_and_pumped_storage': '#339af0',
}


@cached
def _fetch_marginal_plants(country: str, scenario_group: str = 'BASECASE',
                           scenario: str = 'BASELINE') -> pd.DataFrame:
    """For each hour, find the dispatched unit whose MC is closest to the
    shadow price (= the price-setting plant)."""
    try:
        rt = _get_run_time(country, scenario_group)
        if rt is None:
            return pd.DataFrame()
        pg = get_postgres()
        import time as _t; t0 = _t.perf_counter()
        q = sa_text("""
            WITH ranked AS (
                SELECT start_time_utc, unit_id, techno, marginal_cost,
                       availability, dispatched, shadow_price,
                       ROW_NUMBER() OVER (
                           PARTITION BY start_time_utc
                           ORDER BY ABS(marginal_cost - shadow_price),
                                    dispatched DESC
                       ) AS rn
                FROM commod_research.power_stack_prompt_output
                WHERE run_time_utc = :rt AND country = :c
                  AND scenario_group = :sg AND scenario = :sc
                  AND dispatched > 0
            )
            SELECT start_time_utc, unit_id, techno, marginal_cost,
                   availability, dispatched, shadow_price
            FROM ranked WHERE rn = 1
            ORDER BY start_time_utc
        """)
        with pg.engine.connect() as conn:
            df = pd.read_sql(q, conn, params={
                'rt': rt, 'c': country, 'sg': scenario_group, 'sc': scenario,
            })
        if not df.empty:
            df['start_time_cet'] = _utc_to_cet(df['start_time_utc'])
        logger.info("marginal_plants %s/%s/%s: %d hours (%.1fs)",
                     country, scenario_group, scenario, len(df),
                     _t.perf_counter() - t0)
        return df
    except Exception as exc:
        logger.error("marginal_plants %s: %s", country, exc)
        return pd.DataFrame()


def _build_marginal_chart(marg: pd.DataFrame, country: str) -> go.Figure:
    """Shadow price timeseries, scatter-coloured by the price-setting technology."""
    fig = go.Figure()
    if marg.empty:
        fig.update_layout(**styled_layout(f'{country} — Price-Setting Plant', 'EUR/MWh'))
        return fig

    for techno, grp in marg.groupby('techno'):
        color = MARGINAL_TECHNO_COLORS.get(techno, '#868e96')
        fig.add_trace(go.Scatter(
            x=grp['start_time_cet'],
            y=grp['shadow_price'],
            mode='markers',
            marker=dict(color=color, size=7, line=dict(width=0.5, color='#1a1a2e')),
            name=techno.replace('_', ' ').title(),
            hovertemplate=(
                '<b>%{customdata[0]}</b><br>'
                'Techno: %{customdata[1]}<br>'
                'Shadow: %{y:.2f} EUR/MWh<br>'
                'MC: %{customdata[2]:.2f} EUR/MWh<br>'
                'Dispatched: %{customdata[3]:,.0f} / %{customdata[4]:,.0f} MW'
                '<extra></extra>'
            ),
            customdata=grp[['unit_id', 'techno', 'marginal_cost',
                            'dispatched', 'availability']].values,
        ))

    fig.update_layout(**styled_layout(
        f'{country} — Price-Setting Plant per Hour', 'Shadow Price (EUR/MWh)'))
    fig.update_layout(
        height=350,
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='center', x=0.5),
    )
    return fig


def _build_marginal_table(marg: pd.DataFrame):
    """Compact table: hour (CET), shadow price, unit_id, techno, MC, dispatched."""
    if marg.empty:
        return html.Div("No marginal plant data", style={'color': '#8a8f9a'})
    tbl = marg[['start_time_cet', 'shadow_price', 'unit_id', 'techno',
                'marginal_cost', 'dispatched', 'availability']].copy()
    tbl.columns = ['Hour (CET)', 'Shadow Price', 'Unit ID', 'Technology',
                   'MC (EUR/MWh)', 'Dispatched (MW)', 'Availability (MW)']
    tbl['Hour (CET)'] = tbl['Hour (CET)'].dt.strftime('%Y-%m-%d %H:%M')
    for c in ['Shadow Price', 'MC (EUR/MWh)']:
        tbl[c] = tbl[c].round(2)
    for c in ['Dispatched (MW)', 'Availability (MW)']:
        tbl[c] = tbl[c].round(0).astype(int)

    return dash_table.DataTable(
        data=tbl.to_dict('records'),
        columns=[{'name': c, 'id': c} for c in tbl.columns],
        style_header=TABLE_STYLE_HEADER,
        style_cell={**TABLE_STYLE_CELL, 'textAlign': 'left', 'minWidth': '80px'},
        style_data_conditional=TABLE_STYLE_DATA_CONDITIONAL,
        page_size=12, sort_action='native', filter_action='native',
    )


# ── Layout ────────────────────────────────────────────────────────────────

def layout():
    return dbc.Container([
        html.H4("Stack Prices vs Meteologica", className='text-center mb-1',
                 style={'color': '#231F20'}),
        html.P("All times CET", className='text-center',
               style={'color': '#8a8f9a', 'fontSize': '0.8rem'}),

        dbc.Row([
            dbc.Col([
                html.Label("Country", className='control-label'),
                dcc.Dropdown(id='sp-country', options=[
                    {'label': 'Germany (DE)', 'value': 'DE'},
                    {'label': 'France (FR)', 'value': 'FR'},
                ], value='DE', clearable=False),
            ], width=3),
            dbc.Col([
                html.Label("Scenario Group", className='control-label'),
                dcc.Dropdown(id='sp-scen-group',
                             options=SCENARIO_GROUPS, value='ENS_MEDIUM',
                             clearable=False),
            ], width=3),
            dbc.Col([
                html.Label("Scenario", className='control-label'),
                dcc.Dropdown(id='sp-scenario',
                             options=[], value=None,
                             clearable=False),
            ], width=3),
            dbc.Col([
                html.Br(),
                dbc.Button("\u27f3 Refresh Data", id='sp-refresh', color='secondary',
                           size='sm', className='mt-1'),
            ], width=2),
        ], className='mb-3'),

        dbc.Card(dbc.CardBody([
            dcc.Loading(dcc.Graph(id='sp-price-chart'), type='circle'),
            html.H6("Daily Averages", className='mt-3 mb-2',
                     style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
            html.Div(id='sp-daily-table'),
        ]), className='mb-3'),

        dbc.Card(dbc.CardBody([
            dcc.Loading(html.Div(id='sp-comparison-table'), type='circle'),
        ]), className='mb-3'),

        dbc.Card(dbc.CardBody([
            dcc.Loading(dcc.Graph(id='sp-marginal-chart'), type='circle'),
            html.H6("Price-Setting Plants (BASECASE/BASELINE)", className='mt-3 mb-2',
                     style={'color': '#8a8f9a', 'fontSize': '0.85rem'}),
            dcc.Loading(html.Div(id='sp-marginal-table'), type='circle'),
        ]), className='mb-3'),
    ], fluid=True)


# ── Callbacks ─────────────────────────────────────────────────────────────

def register_callbacks(app):

    @app.callback(
        [Output('sp-scenario', 'options'),
         Output('sp-scenario', 'value'),
         Output('sp-scenario', 'multi')],
        [Input('sp-scen-group', 'value'),
         Input('sp-country', 'value')],
    )
    def update_scenario_options(scen_group, country):
        import time as _t; _t0 = _t.perf_counter()
        logger.info("update_scenario_options(%s, %s) START", scen_group, country)
        scenarios = _fetch_available_scenarios(country, scen_group)
        logger.info("  scenarios fetched in %.1fs: %s", _t.perf_counter() - _t0, scenarios)
        is_ensemble = scen_group in ('ENS_MEDIUM', 'ENS_EXTENDED')

        if is_ensemble:
            opts = [{'label': 'All members (fan chart)', 'value': '_ALL'}]
            for s in scenarios:
                opts.append({'label': s, 'value': s})
            return opts, '_ALL', False
        else:
            if not scenarios:
                scenarios = ['BASELINE']
            opts = [{'label': s, 'value': s} for s in scenarios]
            default = 'BASELINE' if 'BASELINE' in scenarios else scenarios[0]
            return opts, default, False

    @app.callback(
        [Output('sp-price-chart', 'figure'),
         Output('sp-daily-table', 'children'),
         Output('sp-comparison-table', 'children'),
         Output('sp-marginal-chart', 'figure'),
         Output('sp-marginal-table', 'children')],
        [Input('sp-country', 'value'),
         Input('sp-scen-group', 'value'),
         Input('sp-scenario', 'value'),
         Input('sp-refresh', 'n_clicks')],
    )
    def update_prices(country, scen_group, scenario, n_clicks):
        import time as _t; _t0 = _t.perf_counter()
        logger.info("update_prices(%s, %s, %s) START", country, scen_group, scenario)

        triggered = callback_context.triggered_id
        if triggered == 'sp-refresh':
            clear_all()
            logger.info("Prices: manual refresh — cache cleared")

        is_ensemble = scen_group in ('ENS_MEDIUM', 'ENS_EXTENDED')
        show_fan = is_ensemble and scenario == '_ALL'

        # ── Fetch stack data first (fast, from cache / indexed table) ─
        price_fig = go.Figure()
        stack_idx = None
        stack_vals = None

        if show_fan:
            all_members = pd.DataFrame()
            try:
                _ts = _t.perf_counter()
                all_members = _fetch_stack_prices(country, scen_group)
                logger.info("  ensemble members in %.1fs (%d rows)",
                            _t.perf_counter() - _ts, len(all_members))
            except Exception as exc:
                logger.error("Ensemble members error: %s", exc)

            stack = pd.DataFrame()
            try:
                _ts = _t.perf_counter()
                stack = _fetch_ensemble_p50(country, scen_group)
                logger.info("  ensemble_p50 in %.1fs (%d rows)",
                            _t.perf_counter() - _ts, len(stack))
            except Exception as exc:
                logger.error("Ensemble P50 error: %s", exc)

            if not all_members.empty:
                run_label = ''
                if 'run_time_utc' in all_members.columns:
                    rt = pd.to_datetime(all_members['run_time_utc'].iloc[0])
                    run_label = f" (run {rt.strftime('%d %b %H:%MZ')})"

                scenarios = sorted(all_members['scenario'].unique())
                n_mem = len(scenarios)

                for i, scen in enumerate(scenarios):
                    scen_df = all_members[all_members['scenario'] == scen].set_index('start_time_cet')
                    price_fig.add_trace(go.Scatter(
                        x=scen_df.index, y=scen_df['price'],
                        name=scen,
                        legendgroup='members',
                        showlegend=(i == 0),
                        line=dict(color='rgba(77, 171, 247, 0.4)', width=1),
                        hovertemplate=f'{scen}: %{{y:.1f}} EUR/MWh<extra></extra>',
                    ))

            if not stack.empty:
                run_label = ''
                if 'run_time_utc' in stack.columns:
                    rt = pd.to_datetime(stack['run_time_utc'].iloc[0])
                    run_label = f" (run {rt.strftime('%d %b %H:%MZ')})"
                n_mem_p50 = int(stack['n_members'].iloc[0]) if 'n_members' in stack.columns else n_mem if not all_members.empty else '?'

                ts = stack.set_index('start_time_cet')
                price_fig.add_trace(go.Scatter(
                    x=ts.index, y=ts['price'],
                    name=f'P50 (reshaped){run_label}',
                    line=dict(color=COLORS['stack_price'], width=2.5),
                ))
                stack_idx = ts.index
                stack_vals = ts['price'].values

                # Original (non-reshaped) P50 for comparison
                try:
                    _to = _t.perf_counter()
                    orig_p50 = _fetch_original_p50(country, scen_group)
                    logger.info("  original_p50 in %.1fs (%d rows)",
                                _t.perf_counter() - _to, len(orig_p50))
                    if not orig_p50.empty:
                        ots = orig_p50.set_index('start_time_cet')
                        price_fig.add_trace(go.Scatter(
                            x=ots.index, y=ots['price'],
                            name=f'P50 (original){run_label}',
                            line=dict(color='#e599f7', width=2, dash='dash'),
                        ))
                except Exception as exc:
                    logger.error("Original P50 error: %s", exc)

                title = f'{country} — {scen_group} P50 ({n_mem_p50} members){run_label}'
            elif not all_members.empty:
                title = f'{country} — {scen_group} ({n_mem} members){run_label}'
            else:
                title = f'{country} — {scen_group} (no data)'
        else:
            stack = pd.DataFrame()
            try:
                _ts = _t.perf_counter()
                stack = _fetch_stack_prices(country, scen_group, scenario)
                logger.info("  stack_prices in %.1fs (%d rows)", _t.perf_counter() - _ts, len(stack))
            except Exception as exc:
                logger.error("Prices stack error: %s", exc)

            run_label = ''
            if not stack.empty and 'run_time_utc' in stack.columns:
                rt = pd.to_datetime(stack['run_time_utc'].iloc[0])
                run_label = f" (run {rt.strftime('%d %b %H:%MZ')})"

            if not stack.empty:
                ts = stack.set_index('start_time_cet')
                price_fig.add_trace(go.Scatter(
                    x=ts.index, y=ts['price'],
                    name=f'{scenario} (reshaped){run_label}',
                    line=dict(color=COLORS['stack_price'], width=2),
                ))
                stack_idx = ts.index
                stack_vals = ts['price'].values

            # Original (non-reshaped) for comparison
            try:
                _to = _t.perf_counter()
                orig = _fetch_original_prices(country, scen_group, scenario)
                logger.info("  original_prices in %.1fs (%d rows)",
                            _t.perf_counter() - _to, len(orig))
                if not orig.empty:
                    ots = orig.set_index('start_time_cet')
                    price_fig.add_trace(go.Scatter(
                        x=ots.index, y=ots['price'],
                        name=f'{scenario} (original){run_label}',
                        line=dict(color='#e599f7', width=2, dash='dash'),
                    ))
            except Exception as exc:
                logger.error("Original prices error: %s", exc)

            title = f'{country} — {scen_group}'
            if scenario:
                title += f' / {scenario}'

        # ── Meteologica (Snowflake — can be slow, fetch after stack) ──
        met = pd.DataFrame()
        met_label = 'Met'
        try:
            _tm = _t.perf_counter()
            met = _fetch_met_prices(country)
            logger.info("  met in %.1fs (%d rows)", _t.perf_counter() - _tm, len(met))
        except Exception as exc:
            logger.error("Prices met error: %s", exc)

        if not met.empty:
            d = met.attrs.get('met_date')
            r = met.attrs.get('met_release', '')
            nwp = met.attrs.get('met_nwp', '')
            if d:
                met_label = f"Met {nwp} {d.strftime('%d %b')} {r}Z"
            price_fig.add_trace(go.Scatter(
                x=met.index, y=met['price'],
                name=met_label,
                line=dict(color=COLORS['met_price'], width=2, dash='dash'),
            ))

        # ── EQ price forecast ──
        eq_fc = pd.DataFrame()
        eq_label = 'EQ'
        try:
            _te = _t.perf_counter()
            eq_fc = _fetch_latest_eq_forecast(country)
            logger.info("  eq_forecast in %.1fs (%d rows)", _t.perf_counter() - _te, len(eq_fc))
        except Exception as exc:
            logger.error("EQ forecast error: %s", exc)

        if not eq_fc.empty:
            issued_raw = eq_fc.attrs.get('eq_issued', '')
            tag = eq_fc.attrs.get('eq_tag', '')
            if issued_raw:
                eq_label = f'EQ {issued_raw}'
            price_fig.add_trace(go.Scatter(
                x=eq_fc.index, y=eq_fc['price'],
                name=eq_label,
                line=dict(color='#ffa94d', width=2, dash='dot'),
            ))

        price_fig.update_layout(**styled_layout(title, 'EUR/MWh'))

        daily = _build_daily_table([
            (stack_idx, stack_vals, 'Stack (EUR/MWh)'),
            (met.index if not met.empty else None,
             met['price'].values if not met.empty else None,
             f'{met_label} (EUR/MWh)'),
            (eq_fc.index if not eq_fc.empty else None,
             eq_fc['price'].values if not eq_fc.empty else None,
             f'{eq_label} (EUR/MWh)'),
        ])

        # Build the stack-vs-EEX comparison table using ENS_MEDIUM P50
        try:
            ens_p50 = _fetch_ensemble_p50(country, 'ENS_MEDIUM')
            if not ens_p50.empty:
                hourly_utc = ens_p50[['start_time_utc', 'price']].copy()
                hourly_utc['start_time_utc'] = pd.to_datetime(hourly_utc['start_time_utc'])
                if hourly_utc['start_time_utc'].dt.tz is not None:
                    hourly_utc['start_time_utc'] = hourly_utc['start_time_utc'].dt.tz_localize(None)
                hourly_utc = hourly_utc.set_index('start_time_utc').sort_index()
                comparison = _build_price_comparison_table(country, hourly_utc)
            else:
                comparison = html.Div("No ENS_MEDIUM data for comparison",
                                      style={'color': '#8a8f9a'})
        except Exception as exc:
            logger.error("Comparison table %s: %s", country, exc, exc_info=True)
            comparison = html.Div(f"Error building comparison: {exc}",
                                  style={'color': '#ff6b6b'})

        # Marginal (price-setting) plant per hour — always BASECASE/BASELINE
        try:
            _tm = _t.perf_counter()
            marg = _fetch_marginal_plants(country, 'BASECASE', 'BASELINE')
            marginal_chart = _build_marginal_chart(marg, country)
            marginal_table = _build_marginal_table(marg)
            logger.info("  marginal_plants in %.1fs (%d hours)", _t.perf_counter() - _tm, len(marg))
        except Exception as exc:
            logger.error("Marginal plants error: %s", exc)
            marginal_chart = go.Figure()
            marginal_chart.update_layout(**styled_layout(f'{country} — Price-Setting Plant', 'EUR/MWh'))
            marginal_table = html.Div("Error loading marginal plant data", style={'color': '#ff6b6b'})

        logger.info("update_prices done in %.1fs", _t.perf_counter() - _t0)
        return price_fig, daily, comparison, marginal_chart, marginal_table
