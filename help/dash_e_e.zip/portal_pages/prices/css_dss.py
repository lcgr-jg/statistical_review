import dash
from dash import html, dcc, Input, Output, State, callback_context, no_update
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from dash.dependencies import ALL
from portal_pages.prices.constants import BASE_METRIC_OPTIONS, APP_COLORS
from portal_pages.prices.prices_data_bundle import effective_prices_bundle
from core.cache import cached_figure
from portal_pages.prices.chart_styles import (
    CHART_COLORS, get_base_layout, get_line_trace, get_bar_trace,
    format_currency_axis, add_zero_line, apply_professional_config
)
from .components.navbar import get_navbar
from .components.days_buttons import get_days_buttons

logger = logging.getLogger(__name__)


def get_layout(data):
    """Get the layout for the CSS/DSS page"""
    return html.Div([
        # Minimal page header with breadcrumb
        html.Div([
            html.Div([
                html.Span("Price Dashboard", style={'color': '#888', 'fontSize': '13px'}),
                html.Span(" / ", style={'color': '#666', 'margin': '0 8px', 'fontSize': '13px'}),
                html.Span("CSS/DSS Analysis", style={'color': '#333', 'fontSize': '13px', 'fontWeight': '600'}),
            ], style={'marginBottom': '20px'}),
        ], style={'padding': '20px 30px 0 30px'}),
        
        # Compact control bar (inline, not a card)
        html.Div([
            html.Div([
                # Country dropdown
                html.Div([
                    html.Label("Country", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Select(
                        id='css-country-dropdown',
                        options=[{'label': c.upper(), 'value': c} for c in["de","fr","nl","gb","be","ch","it","es","at"]],
                        value='de',
                        style={'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'marginRight': '20px', 'width': '140px'}),
                
                # Metric dropdown
                html.Div([
                    html.Label("Metric", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Select(
                        id='metric-dropdown',
                        options=[{'label': m.replace('_', ' '), 'value': m} for m in BASE_METRIC_OPTIONS],
                        value=BASE_METRIC_OPTIONS[0],
                        style={'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'width': '280px'}),
            ], style={'display': 'flex', 'alignItems': 'flex-end', 'gap': '20px'}),
        ], style={'padding': '0 30px 20px 30px', 'borderBottom': '1px solid #e5e5e5'}),
        
        # CSS/DSS inner tabs - minimal style
        html.Div([
            dbc.Tabs(
                id='css-dss-tabs',
                active_tab='Quarters',
                className="minimal-tabs",
                children=[
                    dbc.Tab(label="Months", tab_id="Months"),
                    dbc.Tab(label="Quarters", tab_id="Quarters"),
                    dbc.Tab(label="Cal", tab_id="Cal"),
                    dbc.Tab(label="Fuel Comparison", tab_id="Fuel Comparison")
                ]
            ),
        ], style={'padding': '0 30px', 'marginTop': '20px'}),
        
        # Days buttons container
        html.Div(id='days-buttons-container', style={'padding': '0 30px'}),
        
        # Content container with specific styling to maximize space
        html.Div(id='css-dss-content', style={'padding': '0 30px 30px 30px', 'minHeight': '600px'})
    ], style={'backgroundColor': '#f5f6f8', 'minHeight': '100vh'})

@cached_figure(ttl_seconds=900, key_prefix="css_line")
def plot_line_chart(cds_df, css_df, country='DE', 
                   cds_cols=['CDS_LOW_EFF', 'CDS_HI_EFF'], 
                   css_cols=['CSS_LOW_EFF', 'CSS_HI_EFF'],
                   cds_labels=['CDS 36%', 'CDS 42%'],
                   css_labels=['CSS 48%', 'CSS 52%']):
    """Create a line chart comparing CDS and CSS curves."""
    logger.debug(f"plot_line_chart called: Country: {country}, CDS_df shape: {cds_df.shape if not cds_df.empty else 'EMPTY'}, CSS_df shape: {css_df.shape if not css_df.empty else 'EMPTY'}")
    logger.debug(f"CDS columns to use: {cds_cols}, CSS columns to use: {css_cols}")
    
    # Build both curves
    logger.debug("Building CDS curve...")
    cds_curve = build_forward_curve(cds_df, country=country, cols=cds_cols)
    logger.debug(f"CDS curve shape: {cds_curve.shape if not cds_curve.empty else 'EMPTY'}")
    if not cds_curve.empty:
        logger.debug(f"CDS curve index: {cds_curve.index.tolist()[:5]}")
        logger.debug(f"CDS curve columns: {list(cds_curve.columns)}")
    
    logger.debug("Building CSS curve...")
    css_curve = build_forward_curve(css_df, country=country, cols=css_cols)
    logger.debug(f"CSS curve shape: {css_curve.shape if not css_curve.empty else 'EMPTY'}")
    if not css_curve.empty:
        logger.debug(f"CSS curve index: {css_curve.index.tolist()[:5]}")
        logger.debug(f"CSS curve columns: {list(css_curve.columns)}")
    
    if cds_curve.empty and css_curve.empty:
        return go.Figure(), []
    
    # Get common periods for line chart
    if not cds_curve.empty and not css_curve.empty:
        common_strips = sorted(set(cds_curve.index) & set(css_curve.index), 
                              key=lambda x: cds_curve.loc[x, 'DELIVERY_START'] if x in cds_curve.index 
                              else css_curve.loc[x, 'DELIVERY_START'])
        
        # Filter both curves to common periods
        cds_curve = cds_curve.loc[common_strips]
        css_curve = css_curve.loc[common_strips]
    elif not cds_curve.empty:
        common_strips = sorted(cds_curve.index)
    elif not css_curve.empty:
        common_strips = sorted(css_curve.index)
    else:
        common_strips = []
    
    # Create figure with professional styling
    fig = go.Figure()
    
    # Calculate y-axis range
    y_min = float('inf')
    y_max = float('-inf')
    
    # CDS lines (professional red palette)
    if not cds_curve.empty and len(cds_cols) >= 2:
        cds_min = min(cds_curve[cds_cols].min().min(), 0)  # Include 0 in range
        cds_max = cds_curve[cds_cols].max().max()
        y_min = min(y_min, cds_min)
        y_max = max(y_max, cds_max)
        
        fig.add_trace(go.Scatter(
            **get_line_trace(
                x=common_strips,
                y=cds_curve[cds_cols[0]],
                name=cds_labels[0],
                color=CHART_COLORS['cds_low'],
                line_style='solid',
                marker_style='default'
            )
        ))
        
        fig.add_trace(go.Scatter(
            **get_line_trace(
                x=common_strips,
                y=cds_curve[cds_cols[1]],
                name=cds_labels[1],
                color=CHART_COLORS['cds_high'],
                line_style='solid',
                marker_style='default'
            )
        ))
        
        # Add fill between CDS curves
        fig.add_trace(
            go.Scatter(
                x=common_strips + common_strips[::-1],
                y=list(cds_curve[cds_cols[0]]) + list(cds_curve[cds_cols[1]])[::-1],
                fill='toself',
                fillcolor='rgba(255,0,0,0.2)',
                line=dict(color='rgba(255,0,0,0)'),
                hoverinfo='skip',
                showlegend=False
            )
        )
    
    # CSS lines (professional green palette)
    if not css_curve.empty and len(css_cols) >= 2:
        css_min = min(css_curve[css_cols].min().min(), 0)  # Include 0 in range
        css_max = css_curve[css_cols].max().max()
        y_min = min(y_min, css_min)
        y_max = max(y_max, css_max)
        
        fig.add_trace(go.Scatter(
            **get_line_trace(
                x=common_strips,
                y=css_curve[css_cols[0]],
                name=css_labels[0],
                color=CHART_COLORS['css_low'],
                line_style='solid',
                marker_style='default'
            )
        ))
        
        fig.add_trace(go.Scatter(
            **get_line_trace(
                x=common_strips,
                y=css_curve[css_cols[1]],
                name=css_labels[1],
                color=CHART_COLORS['css_high'],
                line_style='solid',
                marker_style='default'
            )
        ))
        
        # Add fill between CSS curves with green tint
        fig.add_trace(
            go.Scatter(
                x=common_strips + common_strips[::-1],
                y=list(css_curve[css_cols[0]]) + list(css_curve[css_cols[1]])[::-1],
                fill='toself',
                fillcolor='rgba(44, 160, 44, 0.15)',  # Light green fill
                line=dict(color='rgba(44, 160, 44, 0)'),
                hoverinfo='skip',
                showlegend=False,
                name='CSS Range'
            )
        )
    
    # Add padding to y-axis range
    y_range = y_max - y_min
    y_padding = y_range * 0.1  # 10% padding
    y_min -= y_padding
    y_max += y_padding
    
    # Apply professional layout
    layout = get_base_layout(
        title=f'CDS vs CSS Efficiency Curves - {country.upper()}',
        height=520,
        show_legend=True
    )
    layout['xaxis']['title'] = 'Delivery period (CET/CEST)'
    layout['yaxis']['title'] = 'Spark Spread (EUR/MWh)'
    layout['yaxis']['range'] = [y_min, y_max]
    layout['uirevision'] = 'constant'  # Preserve zoom/pan state
    
    fig.update_layout(layout)
    
    # Add zero line for reference
    fig = add_zero_line(fig, axis='y')
    
    # Apply professional config
    fig = apply_professional_config(fig)
    
    # Format currency axis
    fig = format_currency_axis(fig, axis='yaxis', currency='€', decimals=1)
    
    return fig, common_strips

@cached_figure(ttl_seconds=900, key_prefix="css_bar")
def plot_bar_chart(cds_df, css_df, country='DE', 
                  cds_col='CDS_MID_EFF', css_col='CSS_MID_EFF',
                  common_strips=None,
                  compare_periods=['1D', '1W', '1M'],
                  cds_label='CDS 40%', css_label='CSS 50%'):
    """Create just the bar chart showing changes over time"""
    
    logger.debug(f"plot_bar_chart called: Country: {country}, CDS_df shape: {cds_df.shape if not cds_df.empty else 'EMPTY'}, CSS_df shape: {css_df.shape if not css_df.empty else 'EMPTY'}")
    logger.debug(f"CDS column to use: {cds_col}, CSS column to use: {css_col}, Common strips provided: {len(common_strips) if common_strips else 'None'}")
    
    # Get comparison dates
    cds_latest_date = cds_df.index.get_level_values('DATE').max()
    css_latest_date = css_df.index.get_level_values('DATE').max()
    logger.debug(f"CDS latest date: {cds_latest_date}, CSS latest date: {css_latest_date}")
    
    cds_available_dates = sorted(cds_df.index.get_level_values('DATE').unique())
    css_available_dates = sorted(css_df.index.get_level_values('DATE').unique())
    
    # Helper function to find closest previous date
    def find_prev_date(target_date, available_dates):
        prev_dates = [d for d in available_dates if d < target_date]
        return max(prev_dates) if prev_dates else None
    
    # Get comparison dates for CDS and CSS
    cds_prev_dates = {}
    css_prev_dates = {}
    
    for period in compare_periods:
        if period == '1D':
            cds_prev_dates['1D'] = find_prev_date(cds_latest_date, cds_available_dates)
            css_prev_dates['1D'] = find_prev_date(css_latest_date, css_available_dates)
        elif period == '1W':
            # Week
            cds_target = cds_latest_date - pd.Timedelta(days=7)
            css_target = css_latest_date - pd.Timedelta(days=7)
            
            cds_closest = find_prev_date(cds_target + pd.Timedelta(days=1), cds_available_dates)
            css_closest = find_prev_date(css_target + pd.Timedelta(days=1), css_available_dates)
            
            if cds_closest: cds_prev_dates['1W'] = cds_closest
            if css_closest: css_prev_dates['1W'] = css_closest
        elif period == '1M':
            # Month
            cds_target = cds_latest_date - pd.Timedelta(days=30)
            css_target = css_latest_date - pd.Timedelta(days=30)
            
            cds_closest = find_prev_date(cds_target + pd.Timedelta(days=1), cds_available_dates)
            css_closest = find_prev_date(css_target + pd.Timedelta(days=1), css_available_dates)
            
            if cds_closest: cds_prev_dates['1M'] = cds_closest
            if css_closest: css_prev_dates['1M'] = css_closest
    
    # Get current curves
    cds_current = build_forward_curve(cds_df, country=country, cols=[cds_col])
    css_current = build_forward_curve(css_df, country=country, cols=[css_col])
    
    # Get historical curves
    cds_historical = {}
    css_historical = {}
    
    for period, hist_date in cds_prev_dates.items():
        if hist_date:
            hist_curve = build_forward_curve(cds_df, country=country, cols=[cds_col], date=hist_date)
            cds_historical[period] = hist_curve
    
    for period, hist_date in css_prev_dates.items():
        if hist_date:
            hist_curve = build_forward_curve(css_df, country=country, cols=[css_col], date=hist_date)
            css_historical[period] = hist_curve
    
    # If no common strips provided, determine them
    if common_strips is None or not common_strips:
        all_strips = set()
        if not cds_current.empty:
            all_strips.update(cds_current.index)
        if not css_current.empty:
            all_strips.update(css_current.index)
        
        # Filter to ensure they exist in historical data (but be less strict - just require current data)
        # Don't require historical data to exist for all periods
        common_strips = sorted(all_strips)
    
    # Define colors - consistent with line chart
    cds_colors = {
        '1D': APP_COLORS['CDS_COLORS']['LOW'],   # Use LOW for 1D
        '1W': APP_COLORS['CDS_COLORS']['MID'],   # Use MID for 1W
        '1M': APP_COLORS['CDS_COLORS']['HIGH']   # Use HIGH for 1M
    }
    
    css_colors = {
        '1D': APP_COLORS['CSS_COLORS']['LOW'],   # Use LOW for 1D
        '1W': APP_COLORS['CSS_COLORS']['MID'],   # Use MID for 1W 
        '1M': APP_COLORS['CSS_COLORS']['HIGH']   # Use HIGH for 1M
    }
    
    # Create figure
    fig = go.Figure()
    
    # Group all changes by contract for plotting
    all_changes = {}
    for contract in common_strips:
        all_changes[contract] = {}
        
        # Add CDS changes
        for period in compare_periods:
            if period in cds_historical and not cds_historical[period].empty and \
               contract in cds_current.index and contract in cds_historical[period].index:
                change = cds_current.loc[contract, cds_col] - cds_historical[period].loc[contract, cds_col]
                all_changes[contract][f'CDS_{period}'] = change
                
        # Add CSS changes
        for period in compare_periods:
            if period in css_historical and not css_historical[period].empty and \
               contract in css_current.index and contract in css_historical[period].index:
                change = css_current.loc[contract, css_col] - css_historical[period].loc[contract, css_col]
                all_changes[contract][f'CSS_{period}'] = change
    
    # Create one trace per period that covers all contracts
    # CSS traces first (to appear on the left)
    for period in compare_periods:
        css_key = f'CSS_{period}'
        x = []
        y = []
        
        for contract in common_strips:
            if contract in all_changes and css_key in all_changes[contract]:
                x.append(contract)
                y.append(all_changes[contract][css_key])
        
        if x:  # Only add if we have data
            fig.add_trace(
                go.Bar(
                    x=x,
                    y=y,
                    name=f'{css_label} {period}',
                    marker_color=css_colors[period],
                    offsetgroup=f'css_{period}',  # Unique offsetgroup for CSS
                    width=0.08,  # Slightly wider bars
                    base=0  # Start from zero
                )
            )
    
    # CDS traces second (to appear on the right)
    for period in compare_periods:
        cds_key = f'CDS_{period}'
        x = []
        y = []
        
        for contract in common_strips:
            if contract in all_changes and cds_key in all_changes[contract]:
                x.append(contract)
                y.append(all_changes[contract][cds_key])
        
        if x:  # Only add if we have data
            fig.add_trace(
                go.Bar(
                    x=x,
                    y=y,
                    name=f'{cds_label} {period}',
                    marker_color=cds_colors[period],
                    offsetgroup=f'cds_{period}',  # Unique offsetgroup for CDS
                    width=0.08,  # Slightly wider bars
                    base=0  # Start from zero
                )
            )
    
    # Add a zero line
    fig.add_shape(
        type="line",
        x0=0,
        y0=0,
        x1=1,
        y1=0,
        line=dict(color="black", width=1, dash="solid"),
        xref="paper",
        yref="y"
    )
    
    # Update layout with optimized settings
    # Apply professional layout
    layout = get_base_layout(
        title=f'Period-over-Period Changes - {country.upper()}',
        height=480,
        show_legend=True
    )
    layout['xaxis']['title'] = 'Delivery period (CET/CEST)'
    layout['xaxis']['tickangle'] = -45
    layout['xaxis']['type'] = 'category'
    layout['yaxis']['title'] = 'Change in Spread (EUR/MWh)'
    layout['barmode'] = 'group'
    layout['bargap'] = 0.15
    layout['bargroupgap'] = 0.1
    layout['legend']['y'] = -0.3  # Lower to accommodate angled labels
    layout['uirevision'] = 'constant'
    
    fig.update_layout(layout)
    
    # Add zero line
    fig = add_zero_line(fig, axis='y')
    
    # Apply professional config
    fig = apply_professional_config(fig)
    
    # Format currency axis
    fig = format_currency_axis(fig, axis='yaxis', currency='€', decimals=1)
    
    return fig

def build_forward_curve(df, country='DE', cols=None, date=None):
    """
    Build a proper forward curve with:
    1. Individual months until the end of the current quarter
    2. Full quarters after that
    3. Calendar years after the last quarter
    """
    logger.debug(f"build_forward_curve called: Country: {country}, Cols: {cols}, Date: {date}, DF shape: {df.shape if not df.empty else 'EMPTY'}, DF empty: {df.empty}")
    
    if df.empty:
        logger.debug("Returning empty DataFrame (input df is empty)")
        return pd.DataFrame()
    
    # Get date to use - find latest date that has good forward curve coverage
    if date is None:
        try:
            logger.debug(f"Attempting to get country data for: {country}")
            # Get all data for this country
            country_data = df.xs(country, level='COUNTRY')
            logger.debug(f"Country data shape: {country_data.shape}")
            country_df_reset = country_data.reset_index()
            logger.debug(f"Country data reset shape: {country_df_reset.shape}")
            
            # Find the most recent date that has contracts covering the next year
            # This ensures we get a proper forward curve, not just far-dated contracts
            country_df_reset['DELIVERY_START'] = pd.to_datetime(country_df_reset['DELIVERY_START'])
            
            # Get unique dates sorted descending
            available_dates = sorted(country_df_reset['DATE'].unique(), reverse=True)
            
            # Find the first date that has contracts in the next 12 months
            date_to_use = None
            for check_date in available_dates[:10]:  # Check last 10 trading days
                date_contracts = country_df_reset[country_df_reset['DATE'] == check_date]
                # Check if we have contracts delivering in the next 12 months
                near_term = date_contracts[
                    (date_contracts['DELIVERY_START'] > check_date) &
                    (date_contracts['DELIVERY_START'] <= check_date + pd.DateOffset(months=12))
                ]
                if len(near_term) > 5:  # Need at least some near-term contracts
                    date_to_use = check_date
                    break
            
            if date_to_use is None:
                # Fallback to most recent date
                date_to_use = available_dates[0]
                
        except Exception as e:
            logger.error(f"Exception getting country data: {e}", exc_info=True)
            return pd.DataFrame()
    else:
        date_to_use = date
        logger.debug(f"Using provided date: {date_to_use}")
        # Check if this date exists in the data for this country
        try:
            country_data = df.xs(country, level='COUNTRY')
            if date_to_use not in country_data.index.get_level_values('DATE'):
                logger.debug(f"Date {date_to_use} not in data, finding closest...")
                available_dates = sorted(country_data.index.get_level_values('DATE').unique())
                prev_dates = [d for d in available_dates if d <= date_to_use]
                if prev_dates:
                    date_to_use = max(prev_dates)
                    logger.debug(f"Using closest date: {date_to_use}")
                else:
                    logger.debug("No suitable date found")
                    return pd.DataFrame()
        except Exception as e:
            logger.error(f"Exception checking date: {e}", exc_info=True)
            return pd.DataFrame()
    
    logger.debug(f"Final date to use: {date_to_use}")
    
    # Filter for date and country
    try:
        logger.debug(f"Filtering for date={date_to_use} and country={country}")
        filtered_df = df.xs(date_to_use, level='DATE').xs(country, level='COUNTRY')
        logger.debug(f"Filtered DF shape: {filtered_df.shape}, index: {filtered_df.index.names}")
    except Exception as e:
        logger.error(f"Exception filtering data: {e}", exc_info=True)
        return pd.DataFrame()
    
    # Reset index to work with columns
    working_df = filtered_df.reset_index()
    logger.debug(f"Working DF shape after reset: {working_df.shape}, columns: {list(working_df.columns)}")
    
    if working_df.empty:
        logger.debug("Returning empty DataFrame (working_df is empty after reset)")
        return pd.DataFrame()
    
    # DELIVERY_PERIOD is in 'YYYY-MM-DD' format from the index
    if 'DELIVERY_PERIOD' not in working_df.columns:
        logger.error(f"No DELIVERY_PERIOD column! Available columns: {list(working_df.columns)}")
        return pd.DataFrame()
    
    logger.debug(f"DELIVERY_PERIOD sample values: {working_df['DELIVERY_PERIOD'].head(3).tolist()}")
    
    # Parse DELIVERY_PERIOD to get DELIVERY_START
    working_df['DELIVERY_START'] = pd.to_datetime(working_df['DELIVERY_PERIOD'])
    
    # Estimate DELIVERY_END if not present (typically 1 month, but we'll refine this)
    if 'DELIVERY_END' not in working_df.columns:
        working_df['DELIVERY_END'] = working_df['DELIVERY_START'] + pd.DateOffset(months=1)
    else:
        working_df['DELIVERY_END'] = pd.to_datetime(working_df['DELIVERY_END'])
    
    # Filter for valid columns if specified
    if cols:
        working_df = working_df.dropna(subset=cols)
    
    # Determine contract type from delivery date patterns
    # Group by unique delivery start dates to identify contract types
    def get_contract_type(delivery_start, delivery_end):
        """Determine if contract is monthly, quarterly, or yearly based on delivery period"""
        days_diff = (delivery_end - delivery_start).days
        if days_diff < 32:  # Monthly
            return 'monthly'
        elif days_diff < 100:  # Quarterly
            return 'quarterly'
        else:  # Yearly
            return 'yearly'
    
    working_df['contract_type'] = working_df.apply(
        lambda row: get_contract_type(row['DELIVERY_START'], row['DELIVERY_END']), 
        axis=1
    )
    
    # Split periods by type
    months = working_df[working_df['contract_type'] == 'monthly'].copy()
    quarters = working_df[working_df['contract_type'] == 'quarterly'].copy()
    years = working_df[working_df['contract_type'] == 'yearly'].copy()
    
    # Current date for curve construction - use the date we're building the curve for
    current_date = pd.Timestamp(date_to_use)
    
    # Calculate current quarter end
    current_month = current_date.month
    current_quarter = (current_month - 1) // 3 + 1
    quarter_end_month = current_quarter * 3
    
    if quarter_end_month == 12:
        next_quarter_start = pd.Timestamp(year=current_date.year + 1, month=1, day=1)
    else:
        next_quarter_start = pd.Timestamp(year=current_date.year, month=quarter_end_month + 1, day=1)
    
    current_quarter_end = next_quarter_start - pd.Timedelta(days=1)
    
    # Sort all by delivery start
    months = months.sort_values('DELIVERY_START')
    quarters = quarters.sort_values('DELIVERY_START')
    years = years.sort_values('DELIVERY_START')
    
    # Build clean curve without overlaps
    # Strategy: Prefer granular contracts near-term, coarser contracts far-term
    # - Months: until end of current quarter
    # - Quarters: from next quarter onwards  
    # - Years: only if no quarterly contracts exist for that period
    
    curve_rows = []
    added_periods = set()  # Track which delivery periods we've already added
    
    # 1. Add monthly contracts until end of current quarter
    if not months.empty:
        remaining_months = months[
            (months['DELIVERY_START'] >= current_date) & 
            (months['DELIVERY_START'] <= current_quarter_end)
        ]
        for _, row in remaining_months.iterrows():
            period_key = row['DELIVERY_START'].strftime('%Y-%m')
            if period_key not in added_periods:
                curve_rows.append(row)
                added_periods.add(period_key)
    
    # 2. Add quarterly contracts starting from next quarter
    if not quarters.empty:
        future_quarters = quarters[quarters['DELIVERY_START'] >= next_quarter_start]
        for _, row in future_quarters.iterrows():
            # For quarters, track the start month
            period_key = row['DELIVERY_START'].strftime('%Y-%m')
            if period_key not in added_periods:
                curve_rows.append(row)
                added_periods.add(period_key)
    
    # 3. Add yearly contracts only if no quarterly exists for that year
    if not years.empty:
        for _, row in years.iterrows():
            year_key = row['DELIVERY_START'].year
            # Check if any quarter starts in this year
            has_quarter = any(q['DELIVERY_START'].year == year_key for q in curve_rows 
                            if q.get('contract_type') == 'quarterly')
            period_key = row['DELIVERY_START'].strftime('%Y')
            if not has_quarter and period_key not in added_periods:
                curve_rows.append(row)
                added_periods.add(period_key)
    
    # Convert to DataFrame and sort chronologically
    if curve_rows:
        result_df = pd.DataFrame(curve_rows)
        result_df = result_df.sort_values('DELIVERY_START')
        
        # Add the date as a column for reference
        result_df['DATE'] = date_to_use
        
        # Use DELIVERY_PERIOD as the index
        if 'DELIVERY_PERIOD' in result_df.columns:
            result_df = result_df.set_index('DELIVERY_PERIOD')
        
        logger.debug(f"Forward curve built successfully! Result shape: {result_df.shape}, index (first 5): {result_df.index.tolist()[:5]}, columns: {list(result_df.columns)[:10]}")
        
        return result_df
    else:
        logger.debug("No curve rows - returning empty DataFrame")
        return pd.DataFrame()

def create_plots(cds_df, css_df, country='DE'):
    """Create both line and bar charts for CDS vs CSS comparison."""
    line_fig, common_strips = plot_line_chart(cds_df, css_df, country)
    bar_fig = plot_bar_chart(cds_df, css_df, country, common_strips=common_strips)
    return line_fig, bar_fig

def register_css_dss_callbacks(app, data):
    """Register callbacks for the CSS/DSS page"""
    
    # Get delivered spreads data
    delivered_spreads = data.get('delivered_spreads', pd.DataFrame())
    
    # Debug: Check delivered spreads structure.  Expected to be empty at
    # callback-registration time because data loads lazily after startup;
    # the real error, if any, surfaces via the page's own callbacks.
    logger.debug("=== Delivered spreads debug ===")
    if delivered_spreads is None or delivered_spreads.empty:
        logger.debug("delivered_spreads is empty or None at register time (expected on cold start)")
    else:
        logger.debug(f"Delivered spreads shape: {delivered_spreads.shape}")
        logger.debug(f"Columns: {delivered_spreads.columns.tolist()}")
        logger.debug(f"Countries: {delivered_spreads['Country'].unique()}")
        logger.debug(f"Sample periods: {sorted(delivered_spreads['Period'].unique())[:10]}")
        logger.debug(f"Sample years: {sorted(delivered_spreads['YEAR'].unique())}")
        logger.debug(f"First few rows:\n{delivered_spreads.head(3)}")
    logger.debug("=== Debug end ===")

    @app.callback(
        Output('days-buttons-container', 'children'),
        [Input('css-dss-tabs', 'active_tab')],
        [State('app-state', 'data')]
    )
    def render_css_days_buttons(active_tab, state):
        return get_days_buttons('css')

    @app.callback(
        Output('app-state', 'data', allow_duplicate=True),
        [Input({'type': 'css-days-button', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data'),
         State({'type': 'css-days-button', 'value': ALL}, 'id')],
        prevent_initial_call=True
    )
    def update_css_days(button_clicks, current_state, button_ids):
        ctx = callback_context
        if not ctx.triggered:
            return no_update

        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        new_state = dict(current_state) if current_state else {}

        if 'css-days-button' in trigger_id:
            import json
            button_id = json.loads(trigger_id)['value']
            new_state['css_days'] = 'All' if button_id == 'All' else int(button_id)
            return new_state
        
        return no_update

    @app.callback(
        Output('css-dss-content', 'children'),
        [Input('css-dss-tabs', 'active_tab')],
        prevent_initial_call=False
    )
    def render_css_dss_content(active_tab):
        if active_tab == "Fuel Comparison":
            return html.Div([
                # Two charts stacked vertically
                dcc.Graph(id='line-chart', style={'height': '400px', 'width': '100%'}),
                dcc.Graph(id='bar-chart', style={'height': '400px', 'width': '100%'})
            ], style={'display': 'flex', 'flexDirection': 'column', 'gap': '20px'})
        else:
            return html.Div([
                dcc.Graph(
                    id='period-graph', 
                    style={'height': '100%', 'width': '100%'},
                    config={
                        'responsive': True,
                        'displayModeBar': True,
                        'scrollZoom': True,
                        'doubleClick': 'reset+autosize'
                    }
                )
            ], style={'height': '100%'})

    @app.callback(
        [Output('line-chart', 'figure'),
         Output('bar-chart', 'figure')],
        [Input('css-country-dropdown', 'value')],
        prevent_initial_call=False
    )
    def update_fuel_graphs(country):
        """Update the fuel comparison graphs."""
        # Use futures-only raw data (excludes spot with DAYS_TO_DELIVERY == 0)
        # This prevents spot data from interfering with forward curve construction
        cds_df = data.get('CDS_raw_futures', data['CDS_raw'])
        css_df = data.get('CSS_raw_futures', data['CSS_raw'])
        
        # DEBUG: Inspect the data structure
        logger.debug(f"FUEL COMPARISON DEBUG - Country: {country}")
        logger.debug(f"CDS_df type: {type(cds_df)}, shape: {cds_df.shape if not cds_df.empty else 'EMPTY'}")
        logger.debug(f"CSS_df type: {type(css_df)}, shape: {css_df.shape if not css_df.empty else 'EMPTY'}")
        
        if not cds_df.empty:
            logger.debug(f"CDS_df index names: {cds_df.index.names}, columns: {list(cds_df.columns)}")
            for level in cds_df.index.names:
                unique_vals = cds_df.index.get_level_values(level).unique()
                logger.debug(f"CDS_df {level}: {len(unique_vals)} unique values")
                if level == 'COUNTRY':
                    logger.debug(f"CDS_df Countries: {sorted(unique_vals)}")
                elif level == 'DAYS_TO_DELIVERY':
                    logger.debug(f"CDS_df Days range: {unique_vals.min()} to {unique_vals.max()}")
            logger.debug(f"CDS_df first 3 rows:\n{cds_df.head(3)}")
        
        if not css_df.empty:
            logger.debug(f"CSS_df index names: {css_df.index.names}, columns: {list(css_df.columns)}")
            for level in css_df.index.names:
                unique_vals = css_df.index.get_level_values(level).unique()
                logger.debug(f"CSS_df {level}: {len(unique_vals)} unique values")
                if level == 'COUNTRY':
                    logger.debug(f"CSS_df Countries: {sorted(unique_vals)}")
                elif level == 'DAYS_TO_DELIVERY':
                    logger.debug(f"CSS_df Days range: {unique_vals.min()} to {unique_vals.max()}")
            logger.debug(f"CSS_df first 3 rows:\n{css_df.head(3)}")
        
        if cds_df.empty or css_df.empty:
            logger.warning(f"Missing CDS or CSS data for {country}")
            empty_fig = go.Figure()
            empty_fig.update_layout(template='seaborn')
            return empty_fig, empty_fig
        
        line_fig, common_strips = plot_line_chart(
            cds_df, css_df, country=country.upper(),
            cds_cols=['CDS_LOW_EFF', 'CDS_HI_EFF'],
            css_cols=['CSS_LOW_EFF', 'CSS_HI_EFF'],
            cds_labels=['CDS 36%', 'CDS 42%'],
            css_labels=['CSS 48%', 'CSS 52%']
        )
        
        bar_fig = plot_bar_chart(
            cds_df, css_df, country=country.upper(),
            cds_col='CDS_MID_EFF', css_col='CSS_MID_EFF',
            common_strips=common_strips,
            cds_label='CDS 40%', css_label='CSS 50%'
        )
        
        shared_uirevision = f"fuel_comparison_{country}"
        line_fig.update_layout(uirevision=shared_uirevision)
        bar_fig.update_layout(uirevision=shared_uirevision)
        
        for trace in line_fig.data:
            if trace.name and 'CDS' in trace.name:
                trace.legendgroup = f"CDS_{trace.name.split()[-1]}" if trace.showlegend else None
            elif trace.name and 'CSS' in trace.name:
                trace.legendgroup = f"CSS_{trace.name.split()[-1]}" if trace.showlegend else None
        
        for trace in bar_fig.data:
            if trace.name and 'CDS' in trace.name:
                trace.legendgroup = f"CDS_{trace.name.split()[-1]}" if trace.showlegend else None
            elif trace.name and 'CSS' in trace.name:
                trace.legendgroup = f"CSS_{trace.name.split()[-1]}" if trace.showlegend else None
        
        return line_fig, bar_fig

    def find_delivered_spread_value(delivered_spreads, period, year, country, metric):
        """Helper function to find delivered spread value for a specific period, year, country and metric
        
        Args:
            delivered_spreads: DataFrame with delivered spread values
            period: Period string to match (e.g. 'JAN', 'Q1', etc.)
            year: Year to match
            country: Country to match
            metric: Metric column to extract (e.g. 'CSS_MID_EFF')
            
        Returns:
            Delivered spread value if found, None otherwise
        """
        if delivered_spreads is None or delivered_spreads.empty:
            return None
        
        # Convert inputs to match data format
        country = country.upper()
        period_upper = period.upper()
        
        # Try exact match first
        match = delivered_spreads[
            (delivered_spreads['Period'].str.upper() == period_upper) &
            (delivered_spreads['YEAR'] == year) &
            (delivered_spreads['Country'] == country)
        ]
        
        if not match.empty and metric in match.columns:
            value = match[metric].iloc[0]
            if pd.notna(value):
                return float(value)
        
        # Try partial matches for different period formats
        # For months: try matching just the month part (e.g., 'JAN' matches 'JAN-24')
        if len(period_upper) == 3:  # Month abbreviation
            match = delivered_spreads[
                (delivered_spreads['Period'].str.upper().str.startswith(period_upper)) &
                (delivered_spreads['YEAR'] == year) &
                (delivered_spreads['Country'] == country)
            ]
            
            if not match.empty and metric in match.columns:
                value = match[metric].iloc[0]
                if pd.notna(value):
                    return float(value)
        
        # For quarters: try matching Q1, Q2, etc.
        if period_upper.startswith('Q') and len(period_upper) == 2:
            match = delivered_spreads[
                (delivered_spreads['Period'].str.upper().str.startswith(period_upper)) &
                (delivered_spreads['YEAR'] == year) &
                (delivered_spreads['Country'] == country)
            ]
            
            if not match.empty and metric in match.columns:
                value = match[metric].iloc[0]
                if pd.notna(value):
                    return float(value)
        
        # For calendar years: try matching CAL
        if period_upper.startswith('C'):
            match = delivered_spreads[
                (delivered_spreads['Period'].str.upper().str.startswith('CAL')) &
                (delivered_spreads['YEAR'] == year) &
                (delivered_spreads['Country'] == country)
            ]
            
            if not match.empty and metric in match.columns:
                value = match[metric].iloc[0]
                if pd.notna(value):
                    return float(value)
        
        return None

    @app.callback(
        Output('period-graph', 'figure'),
        [Input('css-country-dropdown', 'value'),
         Input('css-dss-tabs', 'active_tab'),
         Input('metric-dropdown', 'value'),
         Input('app-state', 'data')],
        prevent_initial_call=False
    )
    def update_graph(country, period_tab, metric, state):
        """Update the period graph based on selected filters."""
        bundle = effective_prices_bundle(data)
        days_limit = state.get('css_days', 180) if state else 180
        
        # For Fuel Comparison tab, use the original create_plots function
        if period_tab == "Fuel Comparison":
            tenor_map = {
                'Months': 'month',
                'Quarters': 'quarter',
                'Cal': 'cal'
            }
            tenor = tenor_map.get(period_tab)
            if not tenor:
                fig = go.Figure()
                fig.update_layout(
                    title=f"Please select Months, Quarters, or Cal tab",
                    template='seaborn'
                )
                return fig
            return create_plots(bundle['CDS_raw'], bundle['CSS_raw'], country)
        
        # For other tabs, use the new sorting logic with real delivery periods
        df_reset = bundle['CSS_processed'].reset_index()
        country_data = df_reset[df_reset['COUNTRY'] == country.upper()]
        
        # Filter out spot data (DAYS_TO_DELIVERY < 2) for futures curves only
        country_data = country_data[country_data['DAYS_TO_DELIVERY'] >= 2]
        
        if country_data.empty:
            fig = go.Figure()
            fig.add_annotation(text=f"No data available for {country.upper()}", xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False, font=dict(size=14, color="#888"))
            fig.update_layout(xaxis=dict(visible=False), yaxis=dict(visible=False), height=400)
            return fig
        
        # Filter by tenor using Period category, but work with actual delivery periods
        if period_tab == 'Months':
            # Get delivery periods for monthly contracts
            monthly_data = country_data[~country_data['Period'].str.startswith(('Q', 'CAL'))]
            periods = sorted(monthly_data['Period'].unique())
            # Sort months chronologically
            month_order = {
                'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 
                'MAY': 5, 'JUN': 6, 'JUL': 7, 'AUG': 8,
                'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12
            }
            periods = sorted(periods, key=lambda x: month_order.get(x, 0))
        elif period_tab == 'Quarters':
            # Get delivery periods for quarterly contracts
            quarterly_data = country_data[country_data['Period'].str.startswith('Q')]
            periods = sorted(quarterly_data['Period'].unique())
            # Sort quarters chronologically
            quarter_order = {'Q1': 1, 'Q2': 2, 'Q3': 3, 'Q4': 4}
            periods = sorted(periods, key=lambda x: quarter_order.get(x, 0))
        else:  # Cal
            # Get delivery periods for calendar contracts
            cal_data = country_data[country_data['Period'].str.startswith('CAL')]
            periods = sorted(cal_data['Period'].unique())
        
        if not periods:
            fig = go.Figure()
            fig.add_annotation(text=f"No {period_tab} periods found", xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False, font=dict(size=14, color="#888"))
            fig.update_layout(xaxis=dict(visible=False), yaxis=dict(visible=False), height=400)
            return fig
        
        # Create subplots with optimized layout
        if period_tab == 'Quarters':
            n_cols = 2  # Force 2 columns for quarters
            n_rows = 2  # Force 2 rows for quarters
            vertical_spacing = 0.15
            horizontal_spacing = 0.12
        elif period_tab == 'Months':
            n_cols = 3  # Force 3 columns for months
            n_rows = 4  # Force 4 rows for months
            vertical_spacing = 0.08
            horizontal_spacing = 0.06
        else:  # Cal
            n_cols = 1
            n_rows = 1
            vertical_spacing = 0.1
            horizontal_spacing = 0.1
        
        # Smaller titles
        subplot_titles = [f"<b>{period}</b>" for period in periods]
        
        fig = make_subplots(
            rows=n_rows, 
            cols=n_cols, 
            subplot_titles=subplot_titles,
            vertical_spacing=vertical_spacing,
            horizontal_spacing=horizontal_spacing
        )
        
        # Get all unique years across all periods for consistent coloring
        all_years = sorted(country_data['Year'].unique())
        colors = APP_COLORS['YEAR_COLORS']
        
        # Create a consistent color mapping for all years
        year_color_map = {}
        for i, year in enumerate(all_years):
            year_color_map[year] = colors[i % len(colors)]
        
        # Add traces for each period
        for idx, period in enumerate(periods):
            row = (idx // n_cols) + 1
            col = (idx % n_cols) + 1
            
            period_data = country_data[country_data['Period'] == period]
            
            # Filter by days limit if not 'All'
            if days_limit != 'All':
                period_data = period_data[period_data['DAYS_TO_DELIVERY'] <= days_limit]
            # For 'All' - don't filter the data
            
            # Get unique years for this period
            years = sorted(period_data['Year'].unique())
            
            # Get max days for delivered spread lines
            max_days = period_data['DAYS_TO_DELIVERY'].max() if not period_data.empty else 365
            
            for year in years:
                year_data = period_data[period_data['Year'] == year]
                if not year_data.empty:
                    # Add futures data trace with consistent color
                    fig.add_trace(
                        go.Scatter(
                            x=year_data['DAYS_TO_DELIVERY'],
                            y=year_data[metric],
                            mode='lines',
                            name=f"{year}",
                            # Use consistent legendgroup for each year across all subplots
                            legendgroup=f"year_{year}",
                            showlegend=(idx == 0),  # Only show in legend for first subplot
                            line=dict(color=year_color_map[year], width=2)
                        ),
                        row=row, col=col
                    )
                    
                    _ds = bundle.get("delivered_spreads", pd.DataFrame())
                    delivered_value = None
                    if _ds is not None and not _ds.empty:
                        delivered_value = find_delivered_spread_value(
                            _ds, period, year, country, metric
                        )
                    if delivered_value is not None:
                        # Add horizontal line for delivered spread with consistent color
                        fig.add_trace(
                            go.Scatter(
                                x=[0, max_days],  # From delivery date to max days
                                y=[delivered_value, delivered_value],
                                mode='lines',
                                line=dict(
                                    color=year_color_map[year],
                                    width=2,
                                    dash="dot",
                                ),
                                name=f"{year} Delivered",
                                legendgroup=f"delivered_{year}",
                                showlegend=(idx == 0),  # Only show in first subplot
                                hovertemplate=f"<b>Delivered {metric}:</b> {delivered_value:.2f} EUR/MWh<extra></extra>"
                            ),
                            row=row, col=col
                        )
        
        # Calculate appropriate height based on number of rows
        if period_tab == 'Months':
            fig_height = 1400  # 4 rows × 350px per row
        elif period_tab == 'Quarters':
            fig_height = 800   # 2 rows × 400px per row
        else:  # Cal
            fig_height = 500
        
        # Apply professional layout
        fig.update_layout(
            height=fig_height,
            template='plotly_white',
            plot_bgcolor=CHART_COLORS['background'],
            paper_bgcolor=CHART_COLORS['background'],
            font=dict(
                family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                size=11,
                color=CHART_COLORS['text']
            ),
            legend=dict(
                orientation="h",
                yanchor="top",
                y=1.02,
                xanchor="center",
                x=0.5,
                groupclick="togglegroup",
                bgcolor='rgba(255,255,255,0.9)',
                bordercolor=CHART_COLORS['grid'],
                borderwidth=1,
                font=dict(size=10)
            ),
            margin=dict(l=60, r=30, t=80, b=50),
            uirevision='constant',
            hovermode='closest'
        )
        
        # Update font sizes for subplot titles
        for annotation in fig['layout']['annotations']:
            annotation['font'] = dict(size=13, color=CHART_COLORS['text'])
        
        # Reverse x-axis and add professional styling for all subplots
        for i in range(1, n_rows + 1):
            for j in range(1, n_cols + 1):
                fig.update_xaxes(
                    autorange="reversed", 
                    title_text="Days to Delivery" if i == n_rows else "",
                    title_font=dict(size=11, color=CHART_COLORS['text']),
                    tickfont=dict(size=10, color=CHART_COLORS['text']),
                    showgrid=True,
                    gridwidth=1,
                    gridcolor=CHART_COLORS['grid'],
                    zeroline=False,
                    showline=True,
                    linewidth=1,
                    linecolor=CHART_COLORS['grid'],
                    row=i, 
                    col=j
                )
                fig.update_yaxes(
                    title_text=f"{metric.replace('_', ' ')}" if j == 1 else "",
                    title_font=dict(size=11, color=CHART_COLORS['text']),
                    tickfont=dict(size=10, color=CHART_COLORS['text']),
                    showgrid=True,
                    gridwidth=1,
                    gridcolor=CHART_COLORS['grid'],
                    zeroline=True,
                    zerolinewidth=2,
                    zerolinecolor=CHART_COLORS['grid'],
                    showline=True,
                    linewidth=1,
                    linecolor=CHART_COLORS['grid'],
                    row=i, 
                    col=j
                )
        
        # Apply professional config
        fig = apply_professional_config(fig)
        
        return fig