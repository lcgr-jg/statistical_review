"""
Price dashboard data for callbacks.

The Spot sub-page reads ``pages.prices._shared_data`` (the ``data`` argument passed
at callback registration) directly — that is the bundle users see when Spot works.
Other pages used ``{**_shared, **get_prices()}`` so the dashboard **cache** overwrote
in-memory data; ``get_prices()`` can be a stale/empty 4h disk snapshot while
``_shared_data`` was just updated. Delivered lines must use the same source as Spot.

We merge: start from cache, overlay ``_shared_data``, then for spot-related frames
**always prefer the shared copy when it has any rows** (if only the cache has rows,
keep those).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

# Same rows Spot + delivered CSS / XB / base-peak need from ``_shared_data``.
_SPOT_DERIVED_KEYS: List[str] = [
    "power_spot_normalized",
    "gas_spot_normalized",
    "co2_spot_normalized",
    "coal_spot_normalized",
    "block_averages_data",
    "delivered_spreads",
    "fx_data",
    "epex_hourly_spot_data",
    "delivered_spot_data",
]


def _df_len(x: Any) -> int:
    try:
        if x is None or not hasattr(x, "empty") or x.empty:
            return 0
        return int(len(x))
    except Exception:
        return 0


def effective_prices_bundle(page_data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge ``_shared_data`` (page) with ``core.data.get_prices()``.

    Shared in-memory data wins for spot/curve inputs whenever it has at least
    one row, matching the behaviour of the Spot sub-page.
    """
    _lg = __import__("logging").getLogger(__name__)
    cached: Optional[Dict[str, Any]] = None
    try:
        from core import data as data_service
        c = data_service.get_prices()
        if c is not None and isinstance(c, dict):
            cached = c
    except Exception as e:
        _lg.debug("effective_prices_bundle: cache read failed: %s", e)

    p = page_data or {}
    c2 = dict(cached) if cached else {}
    # Overlay shared dict (what Spot uses) on top of cache
    out = {**c2, **p}
    for k in _SPOT_DERIVED_KEYS:
        a, b = p.get(k), c2.get(k) if c2 else None
        la, lb = _df_len(a), _df_len(b)
        if la > 0:
            out[k] = a
        elif lb > 0 and la == 0:
            out[k] = b
    return out
