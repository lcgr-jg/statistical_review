# Base metric options
BASE_METRIC_OPTIONS = [
    'CSS_MID_EFF', 'CSS_LOW_EFF', 'CSS_HI_EFF',
    'CDS_LOW_EFF', 'CDS_MID_EFF', 'CDS_HI_EFF',
    'GAS_PRICE', 'POWER_PRICE',
    'ROLLING_CORR_POWER_GAS', 'BETA_POWER_GAS'
]

# Month name to number mapping for chronological ordering
MONTH_TO_NUM = {
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
    'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
}

# Import enterprise color scheme from parent dashboard
try:
    from core.styles import COLORS, CHART_COLORS
    
    # Consistent color palette matching enterprise theme
    APP_COLORS = {
        # Year colors (use enterprise chart colors)
        'YEAR_COLORS': CHART_COLORS,
        # Base/Peak colors
        'BASE_COLOR': COLORS['chart_primary'],  # Blue
        'PEAK_COLOR': COLORS['chart_tertiary'],   # Red
        # CDS/CSS colors
        'CDS_COLORS': {
            'LOW': COLORS['chart_tertiary'],      # Red
            'MID': '#c0392b',                      # Darker red
            'HIGH': '#922b21'                      # Darkest red
        },
        'CSS_COLORS': {
            'LOW': COLORS['chart_primary'],        # Blue
            'MID': '#2874a6',                      # Darker blue
            'HIGH': '#1a5490'                      # Darkest blue
        },
        # Time comparison colors
        'TIME_COLORS': {
            'CURRENT': COLORS['chart_primary'],    # Blue
            'DAY': COLORS['chart_quaternary'],     # Yellow
            'WEEK': COLORS['chart_secondary'],     # Green
            'MONTH': COLORS['chart_tertiary']      # Red
        },
        # Table styling
        'header_bg': COLORS['table_header_bg'],
        'header_text': COLORS['text_dark'],
        'highlight_bg': '#e9ecef',
        'highlight_text': '#495057',
        # Background colors
        'page_bg': COLORS['page_bg'],
        'card_bg': COLORS['card_bg'],
    }
except ImportError:
    # Fallback if core.styles not available (standalone mode)
    APP_COLORS = {
        'YEAR_COLORS': [
            "#4a9eff", "#50c878", "#ff6b6b", "#ffd93d", "#9b59b6",
            "#1abc9c", "#e74c3c", "#3498db", "#f39c12", "#2ecc71",
        ],
        'BASE_COLOR': '#4a9eff',
        'PEAK_COLOR': '#ff6b6b',
        'CDS_COLORS': {'LOW': '#ff6b6b', 'MID': '#c0392b', 'HIGH': '#922b21'},
        'CSS_COLORS': {'LOW': '#4a9eff', 'MID': '#2874a6', 'HIGH': '#1a5490'},
        'TIME_COLORS': {
            'CURRENT': '#4a9eff', 'DAY': '#ffd93d',
            'WEEK': '#50c878', 'MONTH': '#ff6b6b'
        },
        'header_bg': '#f2f2f2',
        'header_text': '#333333',
        'highlight_bg': '#e9ecef',
        'highlight_text': '#495057',
        'page_bg': '#f5f6f8',
        'card_bg': '#ffffff',
    }

# Custom CSS for the application (matching enterprise theme)
CUSTOM_CSS = """
.control-label {
    font-weight: 500;
    margin-bottom: 5px;
    color: #333;
}

.dash-dropdown .Select-control {
    border-radius: 6px;
    border: 1px solid #ddd;
}

.dash-dropdown .Select-control:hover {
    border-color: #4a9eff;
    box-shadow: 0 0 0 0.2rem rgba(74, 158, 255, 0.25);
}

/* Custom card styling (enterprise theme) */
.control-card {
    background-color: #ffffff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    border: none;
}

/* Custom tab styling (matching enterprise) */
.dash-tab, .nav-pills .nav-link {
    padding: 15px 20px;
    font-weight: 500;
    color: #333 !important;
    text-decoration: none;
    cursor: pointer;
}

.dash-tab--selected, .nav-pills .nav-link.active {
    border-bottom: 2px solid #4a9eff !important;
    color: #333 !important;
    background-color: #f0f0f0 !important;
    font-weight: 600 !important;
}

/* Fix for navbar links */
.navbar .nav-link {
    color: white !important;
    cursor: pointer;
    text-decoration: none;
}

.navbar .nav-link:hover {
    text-decoration: none;
    opacity: 0.8;
}

.navbar .nav-link.active {
    font-weight: bold;
    text-decoration: underline;
}

/* Parent tabs specific styling */
#parent-tabs .nav-link.active {
    background-color: #f0f0f0 !important;
    border-bottom: 2px solid #4a9eff !important;
}

/* Days button styling with hover and active states */
.days-button {
    margin-right: 0.5rem;
    transition: all 0.2s ease;
    font-weight: 500;
    border-radius: 6px;
    padding: 0.375rem 0.75rem;
}

.days-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.days-button.active {
    background-color: #4a9eff !important;
    color: white !important;
    border-color: #4a9eff !important;
    border-width: 2px !important;
}

/* Improve heading legibility */
h1, h2, h3, h4, h5, h6 {
    color: #333 !important;
    font-weight: 600;
}

/* Main heading styling */
.text-primary {
    color: #333 !important;
}

/* Page background */
body {
    background-color: #f5f6f8;
}
""" 