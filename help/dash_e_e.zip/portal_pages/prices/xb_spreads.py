from dash import html, dcc, Input, Output, State, ALL, callback_context, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
import dash
from plotly.subplots import make_subplots
import re
from portal_pages.prices.constants import APP_COLORS
from .components.navbar import get_navbar
from .components.days_buttons import get_days_buttons

# Plot caching
from core.cache import cached_figure
from .xb_spreads_chart import create_xb_spreads_chart
from .prices_data_bundle import effective_prices_bundle

import logging
logger = logging.getLogger(__name__)

MONTH_TO_NUM = {
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
    'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
}


def get_layout(data):
    """Get the layout for the XB Spreads page"""
    combined_spreads = data['combined_spreads']
    xb_tenors = sorted(combined_spreads['tenor'].unique())
    
    country_cols = [col for col in combined_spreads.columns 
                    if 'SETTLEMENT_PRICE_' in col and not col.endswith('_spread')]
    xb_countries = sorted([col.split('_')[-1].lower() for col in country_cols])
    
    spread_types = sorted(combined_spreads['SPREAD_TYPE'].unique())
    default_spread = 'DE-FR' if 'DE-FR' in spread_types else (spread_types[0] if spread_types else None)
    
    return html.Div([
        # Minimal page header with breadcrumb
        html.Div([
            html.Div([
                html.Span("Price Dashboard", style={'color': '#888', 'fontSize': '13px'}),
                html.Span(" / ", style={'color': '#666', 'margin': '0 8px', 'fontSize': '13px'}),
                html.Span("Cross-Border Spreads", style={'color': '#333', 'fontSize': '13px', 'fontWeight': '600'}),
            ], style={'marginBottom': '20px'}),
        ], style={'padding': '20px 30px 0 30px'}),
        
        # Compact control bar
        html.Div([
            html.Div([
                # Tenor tabs - inline
                html.Div([
                    html.Label("Tenor", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Tabs(
                        id="xb-tenor-tabs",
                        className="minimal-tabs",
                        children=[
                            dbc.Tab(label=tenor.capitalize(), tab_id=tenor) for tenor in xb_tenors
                        ],
                        active_tab=xb_tenors[0] if xb_tenors else None
                    )
                ], style={'display': 'inline-block', 'marginRight': '30px'}),
                
                # Country selection
                html.Div([
                    html.Label("Countries", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dcc.Dropdown(
                        id="xb-country-dropdown",
                        options=[{"label": country.upper(), "value": country} for country in xb_countries],
                        value=[],
                        multi=True,
                        placeholder="Select countries (optional)",
                        style={'width': '280px', 'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'marginRight': '20px'}),
                
                # Spreads selection
                html.Div([
                    html.Label("Spreads", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dcc.Dropdown(
                        id="xb-spread-dropdown",
                        options=[{"label": spread, "value": spread} for spread in spread_types],
                        value=[default_spread] if default_spread else [spread_types[0]] if spread_types else [],
                        multi=True,
                        placeholder="Select spreads (optional)",
                        style={'width': '280px', 'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'marginRight': '20px'}),
                
                # Profile selector
                html.Div([
                    html.Label("Profile", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.RadioItems(
                        id="xb-profile-selector",
                        options=[
                            {"label": "Base", "value": "Base"},
                            {"label": "Peak", "value": "Peak"},
                            {"label": "Both", "value": "Both"}
                        ],
                        value="Base",
                        inline=True,
                        style={'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'marginRight': '20px', 'paddingTop': '6px'}),
                
                # Toggle for showing negative days
                html.Div([
                    html.Label("Options", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Checklist(
                        options=[
                            {"label": "Show Past Delivery", "value": "show_negative"}
                        ],
                        value=[],
                        id="xb-display-options",
                        switch=True,
                        style={'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'paddingTop': '6px'}),
            ], style={'display': 'flex', 'alignItems': 'flex-end', 'gap': '20px'}),
        ], style={'padding': '0 30px 20px 30px', 'borderBottom': '1px solid #e5e5e5'}),
        
        # Days buttons
        html.Div(id='xb-days-buttons-container', style={'padding': '0 30px'}),
        
        # Graph container
        html.Div([
            dbc.Spinner(
                html.Div(id="xb-graph-container"),
                spinner_style={"width": "3rem", "height": "3rem"},
                color="primary",
                type="border"
            )
        ], style={'padding': '30px'})
    ], style={'backgroundColor': '#f5f6f8', 'minHeight': '100vh'})

def register_xb_spreads_callbacks(app, data):
    """Register callbacks for the xb-spreads page"""
    
    # Check the structure of delivered_spot_data.  Expected to be empty at
    # callback-registration time because data loads lazily after startup.
    logger.debug("Delivered spot data debug")
    delivered_spot_data = data.get('delivered_spot_data', pd.DataFrame())
    if delivered_spot_data is None or delivered_spot_data.empty:
        logger.debug("delivered_spot_data is empty or None at register time (expected on cold start)")
    else:
        logger.debug(f"Delivered spot data shape: {delivered_spot_data.shape}")
        logger.debug(f"Columns: {delivered_spot_data.columns.tolist()}")
        logger.debug(f"First few rows: {delivered_spot_data.head(3)}")
        
        # Check for key columns required for matching
        for col in ['Period', 'year', 'Country', 'Country-Pair', 'DELIVERED_PRICE']:
            if col in delivered_spot_data.columns:
                logger.debug(f"Column {col} exists with {delivered_spot_data[col].nunique()} unique values")
                logger.debug(f"Sample values: {delivered_spot_data[col].dropna().head(5).tolist()}")
            else:
                logger.debug(f"MISSING COLUMN: {col}")
        
        # Try to find some example country-pairs to match with futures data
        if 'Country-Pair' in delivered_spot_data.columns:
            spreads = delivered_spot_data['Country-Pair'].dropna().unique()
            spread_examples = [s for s in spreads if s in ['DE-FR', 'FR-GB', 'FR-IT']]
            logger.debug(f"Found spreads in delivered data: {spread_examples}")
            
            # Test: Try to find a few specific examples that should match
            for spread in spread_examples:
                test_years = delivered_spot_data[delivered_spot_data['Country-Pair'] == spread]['year'].unique()
                if len(test_years) > 0:
                    test_year = test_years[0]
                    logger.debug(f"Testing match for {spread} in year {test_year}")
                    test_periods = delivered_spot_data[
                        (delivered_spot_data['Country-Pair'] == spread) & 
                        (delivered_spot_data['year'] == test_year)
                    ]['Period'].unique()
                    if len(test_periods) > 0:
                        logger.debug(f"Found periods: {test_periods[:5]}")
                    else:
                        logger.debug(f"No periods found for {spread} in year {test_year}")
                else:
                    logger.debug(f"No years found for {spread}")
    
    logger.debug("Delivered spot data debug end")
    
    @app.callback(
        Output('xb-days-buttons-container', 'children'),
        [Input('xb-tenor-tabs', 'active_tab')],
        [State('app-state', 'data')]
    )
    def render_xb_days_buttons(active_tab, state):
        return get_days_buttons('xb')
    
    @app.callback(
        Output('xb-graph-container', 'children'),
        [
            Input("xb-tenor-tabs", "active_tab"),
            Input("xb-spread-dropdown", "value"),
            Input("xb-country-dropdown", "value"),
            Input("xb-profile-selector", "value"),
            Input("xb-display-options", "value"),
            Input("app-state", "data")
        ],
        prevent_initial_call=False
    )
    def update_xb_container(tenor, spreads, countries, profile, display_options, state):
        bundle = effective_prices_bundle(data)
        combined_spreads = bundle.get('combined_spreads')
        delivered_spot_data = bundle.get('delivered_spot_data', pd.DataFrame())
        
        if combined_spreads is None or combined_spreads.empty:
            fig = go.Figure()
            fig.update_layout(
                title="Loading data...",
                template='seaborn',
                annotations=[dict(
                    text="Loading cross-border spreads data...",
                    xref="paper", yref="paper",
                    x=0.5, y=0.5, showarrow=False,
                    font=dict(size=16, color="#888")
                )]
            )
            return dcc.Graph(
                id="xb-spreads-graph",
                figure=fig,
                style={'height': '80vh'},
                config={'displayModeBar': True, 'scrollZoom': True}
            )
        
        days_state = state.get('xb_days', 180) if state else 180
        is_all_button = days_state == 'All'
        
        # Check display options
        show_negative = 'show_negative' in display_options if display_options else False
        
        # Ensure values are lists
        if spreads is None:
            # Default to 'DE-FR' if available, otherwise first spread
            spread_types = sorted(combined_spreads['SPREAD_TYPE'].unique())
            default_spread = 'DE-FR' if 'DE-FR' in spread_types else spread_types[0] if spread_types else None
            spreads = [default_spread] if default_spread else []
        elif isinstance(spreads, str):
            spreads = [spreads]
            
        if countries is None:
            countries = []
        elif isinstance(countries, str):
            countries = [countries]
        
        # Ensure we have at least one selection
        if not countries and not spreads:
            # Default to 'DE-FR' spread if no selection
            spread_types = sorted(combined_spreads['SPREAD_TYPE'].unique())
            if 'DE-FR' in spread_types:
                spreads = ['DE-FR']
            elif spread_types:
                spreads = [spread_types[0]]
            else:
                fig = go.Figure()
                fig.update_layout(
                    title="No Selection",
                    template='seaborn',
                    annotations=[dict(
                        text="Please select at least one country or spread",
                        xref="paper", yref="paper",
                        x=0.5, y=0.5, showarrow=False,
                        font=dict(size=16, color="crimson")
                    )]
                )
                return dcc.Graph(
                    id="xb-spreads-graph",
                    figure=fig,
                    style={'height': '80vh'},
                    config={'displayModeBar': True, 'scrollZoom': True}
                )
        
        # Filter data by tenor
        df = combined_spreads.copy()
        tenor_df = df[df['tenor'] == tenor]
        
        # Filter by days if not "All"
        if not is_all_button:
            tenor_df = tenor_df[tenor_df['DAYS_TO_DELIVERY'] <= days_state]
        
        # Filter out negative days if "Show Past Delivery" is not selected
        if not show_negative:
            tenor_df = tenor_df[tenor_df['DAYS_TO_DELIVERY'] >= 0]
        
        # Create the chart using the cached function
        fig = create_xb_spreads_chart(
            tenor_df=tenor_df,
            tenor=tenor,
            spreads=spreads,
            countries=countries,
            profile=profile,
            days_state=days_state,
            is_all_button=is_all_button,
            delivered_spot_data=delivered_spot_data,
            show_negative=show_negative,
        )
        
        return dcc.Graph(
            id="xb-spreads-graph",
            figure=fig,
            style={'height': '80vh'},
            config={'displayModeBar': True, 'scrollZoom': True}
        )

    @app.callback(
        Output('app-state', 'data', allow_duplicate=True),
        [Input({'type': 'xb-days-button', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data'),
         State({'type': 'xb-days-button', 'value': ALL}, 'id')],
        prevent_initial_call=True
    )
    def update_xb_days_only(button_clicks, current_state, button_ids):
        ctx = callback_context
        if not ctx.triggered:
            return no_update

        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        new_state = dict(current_state) if current_state else {}

        if 'xb-days-button' in trigger_id:
            import json
            button_id = json.loads(trigger_id)['value']
            new_state['xb_days'] = 'All' if button_id == 'All' else int(button_id)
            return new_state
        
        return no_update

def find_delivered_spot_price(delivered_spot_data, period, year, entity, is_spread=False):
    """Helper function to find delivered spot price with more flexible matching
    
    Args:
        delivered_spot_data: DataFrame with delivered spot prices
        period: Period string to match (e.g. 'Jan', 'Q1', etc.)
        year: Year to match
        entity: Country code or spread to match (e.g. 'DE', 'DE-FR')
        is_spread: Whether entity is a spread (True) or country (False)
    
    Returns:
        Delivered spot price if found, None otherwise
    """
    if delivered_spot_data is None or delivered_spot_data.empty:
        return None
    
    # Normalize inputs
    period = str(period).upper().strip()
    year = int(year)
    entity = str(entity).upper().strip()
    
    # Choose the right column based on whether we're looking for a country or spread
    entity_col = 'Country-Pair' if is_spread else 'Country'
    
    # First try exact match
    match = delivered_spot_data[
        (delivered_spot_data['Period'].str.upper() == period) & 
        (delivered_spot_data['year'] == year) &
        (delivered_spot_data[entity_col] == entity)
    ]
    
    # If no match, try matching just the first part of the period (e.g. 'JAN' from 'JAN-23')
    if match.empty and '-' in period:
        period_prefix = period.split('-')[0]
        match = delivered_spot_data[
            (delivered_spot_data['Period'].str.upper().str.startswith(period_prefix)) & 
            (delivered_spot_data['year'] == year) &
            (delivered_spot_data[entity_col] == entity)
        ]
    
    # If no match with first part, try first 3 chars for month names
    if match.empty and len(period) >= 3:
        match = delivered_spot_data[
            (delivered_spot_data['Period'].str.upper().str.startswith(period[:3])) & 
            (delivered_spot_data['year'] == year) &
            (delivered_spot_data[entity_col] == entity)
        ]
    
    # Try more aggressive matching for quarter and month names
    if match.empty:
        # Check for quarters (Q1, Q2, Q3, Q4)
        if period.startswith('Q') and len(period) >= 2 and period[1].isdigit():
            quarter_num = period[1]
            match = delivered_spot_data[
                (delivered_spot_data['Period'].str.upper().str.contains(f"Q{quarter_num}")) & 
                (delivered_spot_data['year'] == year) &
                (delivered_spot_data[entity_col] == entity)
            ]
        
        # Check for month abbreviations in different formats
        elif len(period) >= 3:
            month_abbr = period[:3]
            match = delivered_spot_data[
                (delivered_spot_data['Period'].str.upper().str.contains(month_abbr)) & 
                (delivered_spot_data['year'] == year) &
                (delivered_spot_data[entity_col] == entity)
            ]
    
    # If we found a match and it has the price column, return the value
    if not match.empty and 'DELIVERED_PRICE' in match.columns:
        spot_value = float(match['DELIVERED_PRICE'].iloc[0])
        return spot_value
    
    return None 