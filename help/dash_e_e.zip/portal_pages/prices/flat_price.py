from dash import html, dcc, Input, Output, State, ALL, callback_context
from dash.exceptions import PreventUpdate
from dash import no_update
import dash_bootstrap_components as dbc
from portal_pages.prices.constants import BASE_METRIC_OPTIONS, APP_COLORS
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from .components.navbar import get_navbar

# Plot caching
from core.cache import cached_figure

import logging
logger = logging.getLogger(__name__)


def get_layout(data):
    """Get the layout for the Flat Price analysis page"""
    return html.Div([
        # Minimal page header with breadcrumb
        html.Div([
            html.Div([
                html.Span("Price Dashboard", style={'color': '#888', 'fontSize': '13px'}),
                html.Span(" / ", style={'color': '#666', 'margin': '0 8px', 'fontSize': '13px'}),
                html.Span("Flat Price Analysis", style={'color': '#333', 'fontSize': '13px', 'fontWeight': '600'}),
            ], style={'marginBottom': '20px'}),
        ], style={'padding': '20px 30px 0 30px'}),
        
        # Compact control bar
        html.Div([
            html.Div([
                # Country dropdown
                html.Div([
                    html.Label("Country", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Select(
                        id='flat-price-country-dropdown',
                        options=[{'label': c.upper(), 'value': c} for c in ['de', 'fr', 'nl', 'gb']],
                        value='de',
                        style={'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'marginRight': '20px', 'width': '140px'}),
                
                # Contract dropdown
                html.Div([
                    html.Label("Contract", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Select(
                        id='flat-price-contract-dropdown',
                        options=[],
                        value=None,
                        style={'fontSize': '13px', 'width': '280px'}
                    )
                ], style={'display': 'inline-block', 'marginRight': '20px'}),
                
                # Time range buttons - inline
                html.Div([
                    html.Label("Time Range", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.ButtonGroup([
                        dbc.Button("1M", id={"type": "flat-time-range", "value": "1M"}, color="primary", outline=True, size="sm"),
                        dbc.Button("3M", id={"type": "flat-time-range", "value": "3M"}, color="primary", outline=True, size="sm"),
                        dbc.Button("6M", id={"type": "flat-time-range", "value": "6M"}, color="primary", outline=True, size="sm"),
                        dbc.Button("1Y", id={"type": "flat-time-range", "value": "1Y"}, color="primary", outline=True, size="sm"),
                        dbc.Button("ALL", id={"type": "flat-time-range", "value": "ALL"}, color="primary", outline=True, size="sm")
                    ])
                ], style={'display': 'inline-block', 'marginRight': '20px'}),
                
                # Show Expired checkbox - inline
                html.Div([
                    html.Label("Options", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Checkbox(
                        id='show-expired-checkbox',
                        label='Show Expired',
                        value=False,
                        style={'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'paddingTop': '6px'}),
            ], style={'display': 'flex', 'alignItems': 'flex-end', 'gap': '20px'}),
        ], style={'padding': '0 30px 20px 30px', 'borderBottom': '1px solid #e5e5e5'}),
        
        # Charts container - maximized space
        html.Div([
            dbc.Row([
                # Base Price Candlestick
                dbc.Col([
                    dcc.Graph(id='base-candlestick-chart', config={'displayModeBar': True, 'displaylogo': False})
                ], width=12, className="mb-4"),
            
                # Peak Price Candlestick
                dbc.Col([
                    dcc.Graph(id='peak-candlestick-chart', config={'displayModeBar': True, 'displaylogo': False})
                ], width=12, className="mb-4"),
                
                # Volume chart
                dbc.Col([
                    dcc.Graph(id='volume-chart', config={'displayModeBar': True, 'displaylogo': False})
                ], width=12, className="mb-4"),
                
                # Forward curve comparison
                dbc.Col([
                    dcc.Graph(id='forward-curve-chart', config={'displayModeBar': True, 'displaylogo': False})
                ], width=12)
            ])
        ], style={'padding': '30px', 'backgroundColor': '#ffffff', 'margin': '20px 30px', 'borderRadius': '6px', 'boxShadow': '0 1px 3px rgba(0,0,0,0.04)'})
    ], style={'backgroundColor': '#f5f6f8', 'minHeight': '100vh'})

def register_flat_price_callbacks(app, data):
    """Register callbacks for the Flat Price analysis page"""
    
    def get_strip_order(strip):
        """Helper function to determine chronological order of strips"""
        try:
            # Split the strip into period and year
            period, year = strip.split('-')
            year = int(year)
            
            if period.startswith('Q'):
                # For quarters, convert Q1, Q2, etc. to 1, 2, etc.
                quarter = int(period[1:])
                # Return a tuple (year, quarter) for proper sorting
                return (year, quarter)
            else:
                # For months, convert Jan, Feb, etc. to 1, 2, etc.
                month_map = {
                    'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
                    'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12
                }
                month = month_map.get(period[:3], 99)
                # Return a tuple (year, month) for proper sorting
                return (year, month)
        except (ValueError, IndexError, KeyError):
            return (9999, 99)
    
    @app.callback(
        [Output('flat-price-contract-dropdown', 'options'),
         Output('flat-price-contract-dropdown', 'value')],
        [Input('flat-price-country-dropdown', 'value'),
         Input('show-expired-checkbox', 'value')]
    )
    def update_contract_dropdown(country, show_expired):
        if not country:
            return [], None
        
        # Get base_peak_data from the shared data dictionary
        base_peak_data = data.get('base_peak_df')
        if base_peak_data is None or base_peak_data.empty:
            return [], None
        
        try:
            # Filter by country
            country_data = base_peak_data[base_peak_data['COUNTRY_CODE'] == country.lower()]
            
            # Filter out expired contracts if show_expired is False
            if not show_expired:
                current_date = pd.Timestamp.now()
                # Get unique strips and their maturity dates
                strip_maturities = country_data[['STRIP', 'MATURITY']].drop_duplicates()
                # Convert MATURITY to datetime
                strip_maturities['MATURITY'] = pd.to_datetime(strip_maturities['MATURITY'])
                # Filter strips where maturity is in the future
                active_strips = strip_maturities[strip_maturities['MATURITY'] > current_date]['STRIP']
                country_data = country_data[country_data['STRIP'].isin(active_strips)]
            
            # Get unique strips and sort them chronologically
            strips = sorted(country_data['STRIP'].unique(), key=get_strip_order)
            options = [{'label': strip, 'value': strip} for strip in strips]
            
            # Set default value to first strip in the sorted list
            default_value = strips[0] if strips else None
            
            return options, default_value
        except Exception as e:
            logger.error("Error updating contract dropdown: %s", str(e), exc_info=True)
            if base_peak_data is not None:
                logger.debug("Available columns: %s", base_peak_data.columns.tolist())
            return [], None
    
    @app.callback(
        Output('app-state', 'data', allow_duplicate=True),
        [Input({'type': 'flat-time-range', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data'),
         State({'type': 'flat-time-range', 'value': ALL}, 'id')],
        prevent_initial_call=True
    )
    def update_app_state_from_time_buttons(button_clicks, current_state, button_ids):
        ctx = callback_context
        if not ctx.triggered:
            return no_update

        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        new_state = dict(current_state)

        if 'flat-time-range' in trigger_id:
            import json
            button_id = json.loads(trigger_id)['value']
            new_state['flat_time_range'] = button_id

        return new_state
    
    @app.callback(
        [Output('base-candlestick-chart', 'figure'),
         Output('peak-candlestick-chart', 'figure')],
        [Input('flat-price-country-dropdown', 'value'),
         Input('flat-price-contract-dropdown', 'value'),
         Input({'type': 'flat-time-range', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data')],
        prevent_initial_call=False
    )
    def update_candlestick_charts(country, strip, time_button_clicks, app_state):
        # Get base_peak_data from the shared data dictionary
        base_peak_data = data.get('base_peak_df')
        
        if not country or not strip or base_peak_data is None or base_peak_data.empty:
            # Return empty figure with loading message
            empty_fig = go.Figure()
            empty_fig.add_annotation(
                text="Select a contract to view price data" if (country and strip) else "Loading data...",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=14, color="#888")
            )
            empty_fig.update_layout(
                xaxis=dict(visible=False),
                yaxis=dict(visible=False),
                plot_bgcolor='white',
                height=400
            )
            return empty_fig, empty_fig
        
        # Determine time range from app state
        time_range = app_state.get('flat_time_range', 'ALL')
        
        # Check if a button was clicked in this callback
        ctx = callback_context
        if ctx.triggered and 'flat-time-range' in ctx.triggered[0]['prop_id']:
            trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
            import json
            button_value = json.loads(trigger_id)['value']
            time_range = button_value
        
        return create_candlestick_chart(base_peak_data, country, strip, time_range)
    
    @app.callback(
        Output('volume-chart', 'figure'),
        [Input('flat-price-country-dropdown', 'value'),
         Input('flat-price-contract-dropdown', 'value'),
         Input({'type': 'flat-time-range', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data')],
        prevent_initial_call=False
    )
    def update_volume_chart(country, strip, time_button_clicks, app_state):
        # Get base_peak_data from the shared data dictionary
        base_peak_data = data.get('base_peak_df')
        
        if not country or not strip or base_peak_data is None or base_peak_data.empty:
            empty_fig = go.Figure()
            empty_fig.add_annotation(
                text="Select a contract to view volume data" if (country and strip) else "Loading data...",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=14, color="#888")
            )
            empty_fig.update_layout(
                xaxis=dict(visible=False),
                yaxis=dict(visible=False),
                plot_bgcolor='white',
                height=300
            )
            return empty_fig
        
        # Determine time range from app state
        time_range = app_state.get('flat_time_range', 'ALL')
        
        # Check if a button was clicked in this callback
        ctx = callback_context
        if ctx.triggered and 'flat-time-range' in ctx.triggered[0]['prop_id']:
            trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
            import json
            button_value = json.loads(trigger_id)['value']
            time_range = button_value
        
        return create_volume_chart(base_peak_data, country, strip, time_range)
    
    @app.callback(
        Output('forward-curve-chart', 'figure'),
        [Input('flat-price-country-dropdown', 'value')],
        prevent_initial_call=False
    )
    def update_forward_curve_chart(country):
        # Get base_peak_data from the shared data dictionary
        base_peak_data = data.get('base_peak_df')
        
        if not country or base_peak_data is None or base_peak_data.empty:
            empty_fig = go.Figure()
            empty_fig.add_annotation(
                text="Loading forward curve..." if country else "Select a country",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=14, color="#888")
            )
            empty_fig.update_layout(
                xaxis=dict(visible=False),
                yaxis=dict(visible=False),
                plot_bgcolor='white',
                height=400
            )
            return empty_fig
        return create_forward_curve_comparison(base_peak_data, country)

@cached_figure(ttl_seconds=900, key_prefix="flat_candlestick")
def create_candlestick_chart(df, country, strip, time_range='ALL'):
    """Create a candlestick chart for the selected contract (cached 15 min)."""
    try:
        # Create a copy of the DataFrame at the start
        df = df.copy()
        
        # Convert trading day to datetime
        df['TRADING_DAY'] = pd.to_datetime(df['TRADING_DAY'])
        
        # Filter data
        mask = (df['COUNTRY_CODE'] == country.lower()) & (df['STRIP'] == strip)
        df_filtered = df[mask].copy()
        
        if df_filtered.empty:
            return go.Figure(), go.Figure()
            
        # Find first day with traded volume
        first_trade_day = df_filtered[df_filtered['TRADED_VOLUME_base'] > 0]['TRADING_DAY'].min()
        df_filtered = df_filtered[df_filtered['TRADING_DAY'] >= first_trade_day].copy()
        
        # Apply time range filter
        if time_range != 'ALL':
            end_date = df_filtered['TRADING_DAY'].max()
            if time_range == '1M':
                start_date = end_date - pd.DateOffset(months=1)
            elif time_range == '3M':
                start_date = end_date - pd.DateOffset(months=3)
            elif time_range == '6M':
                start_date = end_date - pd.DateOffset(months=6)
            elif time_range == '1Y':
                start_date = end_date - pd.DateOffset(years=1)
            else:
                start_date = first_trade_day
            df_filtered = df_filtered[df_filtered['TRADING_DAY'] >= start_date].copy()
            
        # Group by date to get OHLC values for base and peak
        daily_data = df_filtered.groupby('TRADING_DAY').agg({
            'OPEN_PRICE_base': 'first',
            'HIGH_PRICE_base': 'max',
            'LOW_PRICE_base': 'min',
            'LAST_PRICE_base': 'last',
            'OPEN_PRICE_peak': 'first',
            'HIGH_PRICE_peak': 'max',
            'LOW_PRICE_peak': 'min',
            'LAST_PRICE_peak': 'last'
        }).reset_index()
        
        # Create base price figure
        fig_base = go.Figure(data=[go.Candlestick(
            x=daily_data['TRADING_DAY'],
            open=daily_data['OPEN_PRICE_base'],
            high=daily_data['HIGH_PRICE_base'],
            low=daily_data['LOW_PRICE_base'],
            close=daily_data['LAST_PRICE_base'],
            name='Base Price'
        )])
        
        # Create peak price figure
        fig_peak = go.Figure(data=[go.Candlestick(
            x=daily_data['TRADING_DAY'],
            open=daily_data['OPEN_PRICE_peak'],
            high=daily_data['HIGH_PRICE_peak'],
            low=daily_data['LOW_PRICE_peak'],
            close=daily_data['LAST_PRICE_peak'],
            name='Peak Price'
        )])
        
        # Update base figure layout
        fig_base.update_layout(
            title=f'Base Price Evolution - {strip} ({country.upper()})',
            yaxis_title='Price (EUR/MWh)',
            xaxis_title='Trading day (CET/CEST, EEX)',
            template='seaborn',
            height=300,
            margin=dict(b=50),
            xaxis_rangeslider=dict(thickness=0.1),
            showlegend=True
        )
        
        # Update peak figure layout
        fig_peak.update_layout(
            title=f'Peak Price Evolution - {strip} ({country.upper()})',
            yaxis_title='Price (EUR/MWh)',
            xaxis_title='Trading day (CET/CEST, EEX)',
            template='seaborn',
            height=300,
            margin=dict(b=50),
            xaxis_rangeslider=dict(thickness=0.1),
            showlegend=True
        )
        
        return fig_base, fig_peak
        
    except Exception as e:
        logger.error("Error creating candlestick chart: %s", str(e), exc_info=True)
        return go.Figure(), go.Figure()

@cached_figure(ttl_seconds=900, key_prefix="flat_volume")
def create_volume_chart(df, country, strip, time_range='ALL'):
    """Create a volume chart for the selected contract"""
    try:
        # Create a copy of the DataFrame at the start
        df = df.copy()
        
        # Convert trading day to datetime
        df['TRADING_DAY'] = pd.to_datetime(df['TRADING_DAY'])
        
        # Filter data
        mask = (df['COUNTRY_CODE'] == country.lower()) & (df['STRIP'] == strip)
        df_filtered = df[mask].copy()
        
        if df_filtered.empty:
            return go.Figure()
            
        # Find first day with traded volume
        first_trade_day = df_filtered[df_filtered['TRADED_VOLUME_base'] > 0]['TRADING_DAY'].min()
        df_filtered = df_filtered[df_filtered['TRADING_DAY'] >= first_trade_day].copy()
        
        # Apply time range filter
        if time_range != 'ALL':
            end_date = df_filtered['TRADING_DAY'].max()
            if time_range == '1M':
                start_date = end_date - pd.DateOffset(months=1)
            elif time_range == '3M':
                start_date = end_date - pd.DateOffset(months=3)
            elif time_range == '6M':
                start_date = end_date - pd.DateOffset(months=6)
            elif time_range == '1Y':
                start_date = end_date - pd.DateOffset(years=1)
            else:
                start_date = first_trade_day
            df_filtered = df_filtered[df_filtered['TRADING_DAY'] >= start_date].copy()
            
        # Group by date to get volume data
        daily_data = df_filtered.groupby('TRADING_DAY').agg({
            'TRADED_VOLUME_base': 'sum',
            'TRADED_VOLUME_peak': 'sum'
        }).reset_index()
        
        # Create volume figure
        fig = go.Figure()
        
        # Add base volume
        fig.add_trace(go.Bar(
            x=daily_data['TRADING_DAY'],
            y=daily_data['TRADED_VOLUME_base'],
            name='Base Volume',
            marker_color=APP_COLORS['BASE_COLOR']
        ))
        
        # Add peak volume
        fig.add_trace(go.Bar(
            x=daily_data['TRADING_DAY'],
            y=daily_data['TRADED_VOLUME_peak'],
            name='Peak Volume',
            marker_color=APP_COLORS['PEAK_COLOR']
        ))
        
        # Update layout
        fig.update_layout(
            title=f'Trading Volume - {strip} ({country.upper()})',
            yaxis_title='Volume (MW)',
            xaxis_title='Trading day (CET/CEST, EEX)',
            template='seaborn',
            height=400,
            margin=dict(b=50),
            xaxis_rangeslider=dict(thickness=0.1),
            barmode='group'
        )
        
        return fig
        
    except Exception as e:
        logger.error("Error creating volume chart: %s", str(e), exc_info=True)
        return go.Figure()

@cached_figure(ttl_seconds=900, key_prefix="flat_fwd_curve")
def create_forward_curve_comparison(df, country, date=None):
    """Create a forward curve comparison chart showing evolution of base forward curve"""
    try:
        # Create a copy of the DataFrame at the start to avoid chained indexing
        df = df.copy()
        
        # Convert all dates to datetime using loc
        df['TRADING_DAY'] = pd.to_datetime(df['TRADING_DAY'])
        df['MATURITY'] = pd.to_datetime(df['MATURITY'])
        
        # Filter for the selected country
        df = df[df['COUNTRY_CODE'] == country.lower()]
        
        # Get latest trading day if date not specified
        if date is None:
            latest_date = df['TRADING_DAY'].max()
        else:
            latest_date = pd.to_datetime(date)
            if latest_date not in df['TRADING_DAY'].unique():
                available_dates = sorted(df['TRADING_DAY'].unique())
                prev_dates = [d for d in available_dates if d <= latest_date]
                if prev_dates:
                    latest_date = max(prev_dates)
                else:
                    return go.Figure()

        # Get the trading days we want to compare
        all_trading_days = sorted(df['TRADING_DAY'].unique())
        target_days = {
            'D': latest_date,
            'D-1': None,
            'D-7': None,
            'D-30': None
        }
        
        # Find nearest trading days for D-1, D-7, and D-30
        latest_idx = all_trading_days.index(latest_date)
        for days_back, label in [(1, 'D-1'), (7, 'D-7'), (30, 'D-30')]:
            target_date = latest_date - pd.Timedelta(days=days_back)
            # Find nearest previous trading day
            prev_dates = [d for d in all_trading_days if d <= target_date]
            if prev_dates:
                target_days[label] = max(prev_dates)
        
        # Create forward curve chart
        fig = go.Figure()
        
        # Color scheme
        colors = {
            'D': APP_COLORS['TIME_COLORS']['CURRENT'],    # Current day - Blue
            'D-1': APP_COLORS['TIME_COLORS']['DAY'],      # Previous day - Orange
            'D-7': APP_COLORS['TIME_COLORS']['WEEK'],     # Previous week - Green
            'D-30': APP_COLORS['TIME_COLORS']['MONTH']    # Previous month - Red
        }
        
        # Helper function to sort strips
        def sort_strips(df_day):
            # Create a copy of the input DataFrame
            df_day = df_day.copy()
            
            # Split periods by type and create new DataFrames
            months_mask = df_day['STRIP'].str.match(r'^[A-Z]{3}-\d{2}$')
            quarters_mask = df_day['STRIP'].str.match(r'^Q\d-\d{2}$')
            years_mask = df_day['STRIP'].str.match(r'^CAL-\d{2}$')
            
            months = df_day[months_mask].copy()
            quarters = df_day[quarters_mask].copy()
            years = df_day[years_mask].copy()
            
            # Sort all by maturity
            months = months.sort_values('MATURITY')
            quarters = quarters.sort_values('MATURITY')
            years = years.sort_values('MATURITY')
            
            # Build the curve - no overlapping periods
            curve_rows = []
            
            # Current date for curve construction
            current_date = pd.Timestamp.now()
            
            # Calculate current quarter end
            current_month = current_date.month
            current_quarter = (current_month - 1) // 3 + 1
            quarter_end_month = current_quarter * 3
            
            if quarter_end_month == 12:
                next_quarter_start = pd.Timestamp(year=current_date.year + 1, month=1, day=1)
            else:
                next_quarter_start = pd.Timestamp(year=current_date.year, month=quarter_end_month + 1, day=1)
            
            current_quarter_end = next_quarter_start - pd.Timedelta(days=1)
            
            # 1. Add individual months until end of current quarter
            remaining_months = months[
                (months['MATURITY'] >= current_date.replace(day=1)) & 
                (months['MATURITY'] <= current_quarter_end)
            ].copy()
            
            if not remaining_months.empty:
                curve_rows.extend(remaining_months.to_dict('records'))
                last_end = remaining_months['MATURITY'].max()
            else:
                last_end = current_date - pd.Timedelta(days=1)
            
            # 2. Add quarters after the current quarter
            future_quarters = quarters[quarters['MATURITY'] >= next_quarter_start].copy()
            
            if not future_quarters.empty:
                curve_rows.extend(future_quarters.to_dict('records'))
            
            return pd.DataFrame(curve_rows)
        
        # Add traces for each day
        for label, day in target_days.items():
            if day is not None:
                day_data = df[df['TRADING_DAY'] == day].copy()
                if not day_data.empty:
                    sorted_data = sort_strips(day_data)
                    if not sorted_data.empty:
                        fig.add_trace(go.Scatter(
                            x=sorted_data['STRIP'],
                            y=sorted_data['LAST_PRICE_base'],
                            name=f'{label} ({day.strftime("%Y-%m-%d")})',
                            line=dict(color=colors[label]),
                            mode='lines+markers'
                        ))
        
        # Update layout
        fig.update_layout(
            title=f'Forward Curve Evolution - Base ({country.upper()})',
            yaxis_title='Price (EUR/MWh)',
            xaxis_title='Contract',
            template='seaborn',
            height=600,
            showlegend=True
        )
        
        return fig
        
    except Exception as e:
        logger.error("Error creating forward curve comparison: %s", str(e), exc_info=True)
        return go.Figure()