from dash import html, dcc, Input, Output, State, ALL, callback_context, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from plotly.subplots import make_subplots
from portal_pages.prices.constants import APP_COLORS
import dash
from dash import callback
from datetime import datetime
import numpy as np
from .components.navbar import get_navbar
from .components.days_buttons import get_days_buttons
from .prices_data_bundle import effective_prices_bundle

# Plot caching
from core.cache import cached_figure

import logging
from typing import Optional

logger = logging.getLogger(__name__)


def _delivered_base_peak_from_block_averages(
    block_averages_data: pd.DataFrame,
    country: str,
    year,
    period: str,
) -> Optional[float]:
    """EPEX block BASE–PEAK average (same lookup as price_dashboard base_peak)."""
    if block_averages_data is None or block_averages_data.empty:
        return None
    p = str(period)
    ys = str(int(year))[-2:]
    if p.upper().startswith("Q"):
        lookup_period = f"{p}-{ys}"
    elif p.upper().startswith("C") or p.upper().startswith("CAL"):
        lookup_period = f"CAL-{ys}"
    else:
        lookup_period = f"{p.upper()[:3]}-{ys}"
    m = block_averages_data[
        (block_averages_data["Metric"] == "BASE-PEAK")
        & (block_averages_data["Country"] == str(country).upper())
        & (block_averages_data["Period"] == lookup_period)
    ]
    if m.empty:
        return None
    for col in ("Value", "VALUE"):
        if col in m.columns:
            v = m.iloc[0][col]
            if pd.notna(v):
                return float(v)
    return None


def get_layout(data):
    """Get the layout for the Base/Peak analysis page"""
    base_peak_df = data['base_peak_df']

    return html.Div([
        # Minimal page header with breadcrumb
        html.Div([
            html.Div([
                html.Span("Price Dashboard", style={'color': '#888', 'fontSize': '13px'}),
                html.Span(" / ", style={'color': '#666', 'margin': '0 8px', 'fontSize': '13px'}),
                html.Span("Base-Peak Spreads", style={'color': '#333', 'fontSize': '13px', 'fontWeight': '600'}),
            ], style={'marginBottom': '20px'}),
        ], style={'padding': '20px 30px 0 30px'}),
        
        # Compact control bar
        html.Div([
            html.Div([
                # Period tabs - inline
                html.Div([
                    html.Label("Period", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Tabs(
                        id='basepeak-tabs',
                        className="minimal-tabs",
                        children=[
                            dbc.Tab(label="Months", tab_id="Months"),
                            dbc.Tab(label="Quarters", tab_id="Quarters"),
                            dbc.Tab(label="Cal", tab_id="Cal")
                        ],
                        active_tab="Quarters"
                    )
                ], style={'display': 'inline-block', 'marginRight': '30px'}),
                
                # Country selection
                html.Div([
                    html.Label("Country", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dcc.Dropdown(
                        id='basepeak-country-dropdown',
                        options=[{'label': c.upper(), 'value': c.lower()} for c in ['de', 'fr', 'it', 'gb', 'nl', 'be', 'at', 'ch', 'hu', 'no2', 'se4', 'dk2', 'dk1']],
                        value='de',
                        clearable=False,
                        style={'width': '140px', 'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'marginRight': '20px'}),
                
                # Display options
                html.Div([
                    html.Label("Options", style={'fontSize': '11px', 'fontWeight': '600', 'color': '#666', 'marginBottom': '6px', 'display': 'block', 'textTransform': 'uppercase', 'letterSpacing': '0.5px'}),
                    dbc.Checklist(
                        options=[
                            {"label": "Show Past Delivery", "value": "show_negative"}
                        ],
                        value=[],
                        id="basepeak-display-options",
                        switch=True,
                        style={'fontSize': '13px'}
                    )
                ], style={'display': 'inline-block', 'paddingTop': '6px'}),
            ], style={'display': 'flex', 'alignItems': 'flex-end', 'gap': '20px'}),
        ], style={'padding': '0 30px 20px 30px', 'borderBottom': '1px solid #e5e5e5'}),
        
        # Main content
        html.Div([
            get_days_buttons('basepeak'),
            
            # Graph container
            dbc.Spinner(
                html.Div(id='basepeak-graph-container'),
                spinner_style={"width": "3rem", "height": "3rem"},
                color="primary",
                type="border"
            )
        ], style={'padding': '30px'})
    ], style={'backgroundColor': '#f5f6f8', 'minHeight': '100vh'})

def register_base_peak_callbacks(app, data):
    """Register callbacks for the Base/Peak analysis page"""
    
    @app.callback(
        Output('app-state', 'data', allow_duplicate=True),
        [Input({'type': 'basepeak-days-button', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data'),
         State({'type': 'basepeak-days-button', 'value': ALL}, 'id')],
        prevent_initial_call=True
    )
    def update_basepeak_days(button_clicks, current_state, button_ids):
        ctx = callback_context
        if not ctx.triggered:
            return no_update

        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
        new_state = dict(current_state)

        if 'basepeak-days-button' in trigger_id:
            import json
            button_id = json.loads(trigger_id)['value']
            new_state['basepeak_days'] = 'All' if button_id == 'All' else int(button_id)

        return new_state
    
    @app.callback(
        Output('basepeak-graph-container', 'children'),
        [Input('basepeak-country-dropdown', 'value'),
         Input('basepeak-tabs', 'active_tab'),
         Input('basepeak-display-options', 'value'),
         Input({'type': 'basepeak-days-button', 'value': ALL}, 'n_clicks')],
        [State('app-state', 'data')],
        prevent_initial_call=False
    )
    def update_graph(country, period_tab, display_options, days_button_clicks, app_state):
        """Update the Base/Peak graph based on selected filters"""
        logger.debug("Base/Peak graph update - country=%s tab=%s", country, period_tab)
        
        # Prefer warm dashboard cache over page dict (S3 power loads async)
        bundle = effective_prices_bundle(data)
        base_peak_df = bundle.get('base_peak_df')
        block_averages_data = bundle.get('block_averages_data')
        
        if base_peak_df is None or base_peak_df.empty:
            logger.debug("base_peak_df is empty or None")
            return []
        
        if not country or not period_tab:
            logger.debug("Missing required parameters")
            return []
        
        days_limit = app_state.get('basepeak_days', 180) if app_state else 180
        
        # Check if a button was clicked in this callback
        ctx = callback_context
        if ctx.triggered and 'basepeak-days-button' in ctx.triggered[0]['prop_id']:
            trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
            import json
            button_value = json.loads(trigger_id)['value']
            days_limit = button_value
            
        # Check display options
        show_negative = 'show_negative' in display_options if display_options else False
        
        try:
            # Use the local base_peak_df variable from the closure
            df = base_peak_df.copy()
            logger.debug("Base/Peak DataFrame shape: %s", df.shape)
            logger.debug("Columns: %s", df.columns.tolist())
            
            # Filter data for the selected country
            df = df[df['COUNTRY_CODE'] == country.lower()]
            
            # Filter by days limit if not 'All'
            if days_limit != 'All':
                df = df[df['DAYS_TO_DELIVERY'] <= days_limit]
                
            # Filter out negative days if "Show Past Delivery" is not selected
            if not show_negative:
                df = df[df['DAYS_TO_DELIVERY'] >= 0]
            
            # Filter periods based on tab
            if period_tab == 'Months':
                periods = sorted([p for p in df['period'].unique() if not p.startswith(('Q', 'C'))],
                               key=lambda x: pd.to_datetime(x, format='%b').month if pd.to_datetime(x, format='%b', errors='coerce') is not pd.NaT else 0)
            elif period_tab == 'Quarters':
                periods = sorted([p for p in df['period'].unique() if p.startswith('Q')])
            elif period_tab == 'Cal':
                periods = sorted([p for p in df['period'].unique() if p.startswith('C')])
            else:
                logger.warning("Invalid period_tab: %s", period_tab)
                return []
            
            logger.debug("Selected periods: %s", periods)
            
            if not periods:
                logger.warning("No periods found for selected tab")
                return []
            
            # Calculate subplot layout
            if period_tab == 'Quarters':
                n_cols = 2  # Force 2 columns for quarters
                n_rows = 2  # Force 2 rows for quarters
                plot_height = 800
            else:
                n_cols = min(3, len(periods)) or 1
                n_rows = 4 if period_tab == 'Months' else 1
                plot_height = 1200 if period_tab == 'Months' else 700
            
            # Create figure with subplots
            fig = make_subplots(
                rows=n_rows, 
                cols=n_cols, 
                subplot_titles=periods,
                vertical_spacing=0.1,
                horizontal_spacing=0.1
            )
            
            # Create mapping of periods to subplot positions
            period_positions = {}
            for i, period in enumerate(periods):
                row = (i // n_cols) + 1
                col = (i % n_cols) + 1
                period_positions[period] = (row, col)
            
            # Get unique years
            years = sorted(df['year'].unique())
            colors = APP_COLORS['YEAR_COLORS']
            
            # Track which legend items have been added
            legend_added = set()
            
            # Add traces for each period
            for period in periods:
                row, col = period_positions[period]
                period_df = df[df['period'] == period]
                
                # Add traces for each year
                for i, year in enumerate(years):
                    year_data = period_df[period_df['year'] == year]
                    
                    if year_data.empty:
                        continue
                    
                    # Sort by days to delivery
                    year_data = year_data.sort_values('DAYS_TO_DELIVERY')
                    
                    # Handle legend
                    legend_key = year
                    if legend_key not in legend_added:
                        showlegend = True
                        legend_added.add(legend_key)
                    else:
                        showlegend = False
                    
                    # Add the futures line
                    fig.add_trace(
                        go.Scatter(
                            x=year_data['DAYS_TO_DELIVERY'],
                            y=year_data['SETTLEMENT_PRICE_spread'],
                            mode='lines',
                            name=str(year),
                            legendgroup=str(year),
                            showlegend=showlegend,
                            line=dict(
                                color=colors[i % len(colors)],
                                width=2
                            ),
                            hovertemplate='<b>Days to Delivery</b>: %{x}<br>' +
                                        '<b>Spread</b>: %{y:.2f}<br>' +
                                        f'<b>Year</b>: {year}<br>' +
                                        f'<b>Period</b>: {period}<extra></extra>'
                        ),
                        row=row, col=col
                    )
                    
                    spot_value = None
                    hover_deliv = ""
                    line_name = ""
                    try:
                        spot_value = _delivered_base_peak_from_block_averages(
                            block_averages_data, country, year, period
                        )
                    except Exception as e:
                        logger.warning(
                            "EPEX block delivered failed: %s", e, exc_info=True
                        )
                    if spot_value is not None:
                        hover_deliv = (
                            f"<b>Delivered BASE-PEAK</b>: {spot_value:.2f} EUR/MWh"
                            f"<br><i>Source: EPEX block average</i>"
                        )
                        line_name = f"{year} Delivered"
                    if spot_value is not None:
                        min_x = 0
                        max_x = year_data['DAYS_TO_DELIVERY'].max() if not year_data.empty else 60
                        legend_group = f"delivered_{year}"
                        is_first_subplot = legend_group not in legend_added
                        fig.add_trace(
                            go.Scatter(
                                x=[min_x, max_x],
                                y=[spot_value, spot_value],
                                mode='lines',
                                line=dict(
                                    color=colors[i % len(colors)],
                                    width=2,
                                    dash='dot',
                                ),
                                name=line_name,
                                legendgroup=legend_group,
                                showlegend=is_first_subplot,
                                hovertemplate=(
                                    f"<b>Year</b>: {year}<br>"
                                    f"<b>Period</b>: {period}<br>"
                                    + hover_deliv
                                    + "<extra></extra>"
                                ),
                            ),
                            row=row, col=col
                        )
                        if is_first_subplot:
                            legend_added.add(legend_group)
                
                # Find max days for this period to set proper axis range
                max_days = year_data['DAYS_TO_DELIVERY'].max() if not year_data.empty else 180
                
                # Configure axes - set fixed range to match data
                fig.update_xaxes(
                    title='Days to delivery (delivered = EPEX block average)',
                    autorange="reversed",
                    gridcolor='lightgray',
                    range=[max_days*1.05, 0],  # Set explicit range with small padding
                    row=row, col=col
                )
                
                fig.update_yaxes(
                    title='Spread (EUR/MWh)',
                    gridcolor='lightgray',
                    zeroline=True,
                    zerolinecolor='gray',
                    row=row, col=col
                )
                
                # Add zero line
                fig.add_hline(y=0, line_dash="dash", line_color="gray", row=row, col=col)
            
            # Update layout
            fig.update_layout(
                height=plot_height,
                template='seaborn',
                hovermode='closest',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="center",
                    x=0.5,
                    groupclick="togglegroup"  # This ensures clicking a legend item only toggles items in that group
                ),
                margin=dict(l=40, r=40, t=120, b=60),
                paper_bgcolor='white',
                plot_bgcolor='#E5ECF6',
                uirevision=f'basepeak_{period_tab}_{country}'  # Make uirevision dependent on tab and country
            )
            
            return dcc.Graph(
                id='basepeak-graph',
                figure=fig,
                style={'height': '80vh'},
                config={'displayModeBar': True, 'scrollZoom': True}
            )
        except Exception as e:
            logger.error("Error updating graph: %s", str(e), exc_info=True)
            return []

def generate_basepeak_figure(df, tenor, countries, state):
    """Generate the base-peak figure based on selected filters and state"""
    # Get days limit value from state
    days_state = state.get('days', 180)
    is_all_button = days_state == 'All'
    
    # Ensure countries is a list
    if isinstance(countries, str):
        countries = [countries]
        
    if not countries:
        fig = go.Figure()
        fig.update_layout(
            title="No countries selected",
            template='seaborn',
            annotations=[dict(
                text="Please select at least one country",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=16, color="crimson")
            )]
        )
        return fig
    
    # Filter data
    filtered_df = df[(df['tenor'] == tenor) & 
                    (df['COUNTRY_CODE'].isin(countries))]
    
    if filtered_df.empty:
        fig = go.Figure()
        fig.update_layout(
            title="No data available",
            template='seaborn',
            annotations=[dict(
                text="No data available for the selected filters",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=16, color="crimson")
            )]
        )
        return fig
    
    # Get unique periods
    periods = sorted(filtered_df['period'].unique())
    
    # Create figure
    fig = go.Figure()
    colors = APP_COLORS['YEAR_COLORS']
    
    # Plot for each country
    for i, country in enumerate(countries):
        country_data = filtered_df[filtered_df['COUNTRY_CODE'] == country]
        
        # Get unique years for this country
        years = sorted(country_data['year'].unique())
        
        # Use a custom color palette with light purple
        custom_colors = APP_COLORS['YEAR_COLORS']
        year_to_color = {year: custom_colors[i % len(custom_colors)] for i, year in enumerate(years)}
        
        # Plot each year's data
        for year in years:
            year_data = country_data[country_data['year'] == year]
            
            if not is_all_button:
                year_data = year_data[year_data['DAYS_TO_DELIVERY'] <= days_state]
            
            if not year_data.empty:
                fig.add_trace(go.Scatter(
                    x=year_data['DAYS_TO_DELIVERY'],
                    y=year_data['SETTLEMENT_PRICE_spread'],
                    mode='lines+markers',
                    name=f"{country.upper()} {year}",
                    line=dict(
                        color=year_to_color[year],
                        width=2
                    ),
                    marker=dict(
                        size=6,
                        symbol='circle'
                    ),
                    hovertemplate='Days: %{x}<br>Spread: %{y:.2f}<extra></extra>'
                ))
    
    # Add zero line
    fig.add_hline(y=0, line_dash="dash", line_color="gray")
    
    # Update layout
    days_display = "All" if is_all_button else str(days_state)
    countries_str = ", ".join(country.upper() for country in countries)
    
    fig.update_layout(
        xaxis_title="Days to Delivery",
        yaxis_title="Base-Peak Spread (EUR/MWh)",
        template='seaborn',
        height=800,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="center",
            x=0.5,
            groupclick="toggleitem"  # This ensures clicking a legend item only toggles that specific item
        ),
        margin=dict(l=40, r=40, t=100, b=60),
        xaxis=dict(
            autorange="reversed",
            gridcolor='lightgray'
        ),
        yaxis=dict(
            gridcolor='lightgray',
            zeroline=True,
            zerolinecolor='gray'
        ),
        paper_bgcolor='white',
        plot_bgcolor='#E5ECF6'  # Light blue-gray background
    )
    
    return fig 