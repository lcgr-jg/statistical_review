"""
Weekly prices sub-page for the portal Prices dashboard.

Forked from the standalone price_dashboard's weekly page. Differences:
- No navbar: the portal supplies its own tab bar in pages/prices.py.
- Reads data via ``effective_prices_bundle(data)`` so S3-cached spot frames
  (power_spot_normalized, epex_hourly_spot_data, ...) are merged in on top of
  the page's in-memory dict — same pattern as the other portal price pages.
- ``weekly_eex_df`` is an optional key introduced on the standalone main branch;
  if it is absent (as on this branch) the code falls back to monthly spreads
  from ``base_peak_df``.
"""

import logging
from dash import html, dcc, Input, Output, State, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta

from .prices_data_bundle import effective_prices_bundle
from core.cache import cached_result

logger = logging.getLogger(__name__)

# Snowflake's POWER_DERIVS_FUTURE_PRICES.COUNTRY_CODE column is lowercase —
# using uppercase here returns zero rows. We upper-case again when populating
# the output frame so downstream joins (which use uppercase) still work.
WEEKLY_FORWARD_COUNTRIES = [
    'de', 'fr', 'gb', 'nl', 'be', 'at', 'ch', 'it', 'es', 'hu',
]


@cached_result(ttl=14400, prefix="weekly_eex_forwards")
def _load_weekly_forwards_from_eex():
    """Fetch native EEX weekly (WKxx-yy) forward settles for Base and Peak.

    Uses ``EEXQuery.get_contracts_by_tenor('week', ...)`` which returns only
    currently active contracts at the latest trading day, so each row is the
    freshest settle for a forward week. Returned frame matches the
    ``weekly_eex_df`` schema that ``_build_weekly_series`` expects.

    Cached 4h so only one Snowflake round-trip per refresh cycle, regardless of
    how many users hit the Weekly tab.
    """
    from jain_commods.core.interfaces.snowflake.eexquery import EEXQuery  # type: ignore

    eex = EEXQuery()
    parts = []
    for profile in ('Base', 'Peak'):
        try:
            df = eex.get_contracts_by_tenor(
                tenor='week',
                country_code=WEEKLY_FORWARD_COUNTRIES,
                profile=profile,
            )
        except Exception as exc:
            logger.warning("Weekly forwards: EEX query failed for profile=%s: %s", profile, exc)
            continue
        if df is None or df.empty:
            continue
        df = df.copy()
        df['PROFILE'] = profile
        parts.append(df)

    if not parts:
        return pd.DataFrame()

    out = pd.concat(parts, ignore_index=True)
    out['COUNTRY_CODE'] = out['COUNTRY_CODE'].astype(str).str.upper()
    out['TRADING_DAY'] = pd.to_datetime(out['TRADING_DAY'])
    out['DELIVERY_START'] = pd.to_datetime(out['DELIVERY_START'])
    iso = out['DELIVERY_START'].dt.isocalendar()
    out['ISO_YEAR'] = iso.year.astype(int)
    out['ISO_WEEK'] = iso.week.astype(int)
    logger.info("Weekly forwards: loaded %d WK-contract rows (countries=%s)",
                len(out), sorted(out['COUNTRY_CODE'].unique()))
    return out

PREFERRED_COUNTRY_ORDER = [
    'DE', 'FR', 'GB', 'NL', 'BE', 'AT', 'CH', 'IT', 'ES', 'HU',
    'CZ', 'SK', 'NO2', 'SE4', 'DK1', 'DK2',
]

COUNTRY_COLORS = {
    'DE': '#4dabf7', 'FR': '#ffa94d', 'GB': '#51cf66', 'NL': '#ff6b6b',
    'BE': '#cc5de8', 'AT': '#e8590c', 'CH': '#f783ac', 'IT': '#868e96',
    'ES': '#fcc419', 'HU': '#22b8cf', 'CZ': '#91a7ff', 'SK': '#ffd8a8',
    'NO2': '#8ce99a', 'SE4': '#ffa8a8', 'DK1': '#b197fc', 'DK2': '#d0bfff',
}

PEAK_HOURS_CET = list(range(8, 20))

CHART_TEMPLATE = "plotly_dark"
CHART_BG = "rgba(0,0,0,0)"
CHART_PAPER_BG = "rgba(0,0,0,0)"
CHART_GRID = "rgba(255,255,255,0.06)"


def _build_weekly_series(data):
    """Build a unified weekly price series from spot (EPEX + BBG) and futures (EEX).

    Returns a DataFrame with columns:
        ISO_YEAR, ISO_WEEK, COUNTRY, PROFILE, PRICE, SOURCE
    where SOURCE is 'spot', 'futures', or 'blend'.
    """
    today = pd.Timestamp.now().normalize()
    rows = []

    # --- Spot: aggregate hourly EPEX + BBG data into weekly base/peak ---
    epex_hourly = data.get('epex_hourly_spot_data', pd.DataFrame())
    bbg_hourly = data.get('bbg_electricity_data', pd.DataFrame())

    spot_frames = []

    if not epex_hourly.empty:
        df = epex_hourly.copy()
        date_col = 'DELIVERY_TIME' if 'DELIVERY_TIME' in df.columns else (
            'TIMESTAMP' if 'TIMESTAMP' in df.columns else df.columns[0])
        country_col = 'COUNTRY' if 'COUNTRY' in df.columns else 'COUNTRY_CODE'
        price_col = 'PRICE' if 'PRICE' in df.columns else 'VALUE'
        df['_dt'] = pd.to_datetime(df[date_col])
        df['_country'] = df[country_col].str.upper()
        df['_price'] = pd.to_numeric(df[price_col], errors='coerce')
        df['_hour'] = df['_dt'].dt.hour
        df['_weekday'] = df['_dt'].dt.weekday
        spot_frames.append(df[['_dt', '_country', '_price', '_hour', '_weekday']].dropna(subset=['_price']))

    if not bbg_hourly.empty:
        df = bbg_hourly.copy()
        df['_dt'] = pd.to_datetime(df['DeliveryTime'], utc=True).dt.tz_convert('CET').dt.tz_localize(None)
        df['_country'] = df['Country'].str.upper()
        df['_price'] = pd.to_numeric(df['Value'], errors='coerce')
        df['_hour'] = df['_dt'].dt.hour
        df['_weekday'] = df['_dt'].dt.weekday
        spot_frames.append(df[['_dt', '_country', '_price', '_hour', '_weekday']].dropna(subset=['_price']))

    if spot_frames:
        spot_all = pd.concat(spot_frames, ignore_index=True)
        spot_all['_iso_year'] = spot_all['_dt'].dt.isocalendar().year.astype(int)
        spot_all['_iso_week'] = spot_all['_dt'].dt.isocalendar().week.astype(int)

        is_peak = (spot_all['_hour'].isin(PEAK_HOURS_CET)) & (spot_all['_weekday'] < 5)

        for profile, mask in [('Base', slice(None)), ('Peak', is_peak)]:
            subset = spot_all.loc[mask] if isinstance(mask, pd.Series) else spot_all
            weekly = (
                subset.groupby(['_iso_year', '_iso_week', '_country'])['_price']
                .mean()
                .reset_index()
            )
            weekly.columns = ['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PRICE']
            weekly['PROFILE'] = profile
            weekly['SOURCE'] = 'spot'
            rows.append(weekly)

    # --- Futures: prefer native EEX weekly contracts when the cache has them.
    current_iso = today.isocalendar()
    today_week_start = today - pd.Timedelta(days=today.weekday())

    futures_rows: list[dict] = []

    weekly_df_raw = data.get('weekly_eex_df', pd.DataFrame())
    if weekly_df_raw is None or weekly_df_raw.empty:
        # Main-branch price_data loader isn't wired up on this branch, so fetch
        # the native WK-contract settles directly (cached 4h).
        try:
            weekly_df_raw = _load_weekly_forwards_from_eex()
        except Exception as exc:
            logger.warning("Weekly forwards: lazy load failed, falling back to empty: %s", exc)
            weekly_df_raw = pd.DataFrame()

    if not weekly_df_raw.empty:
        try:
            wdf = weekly_df_raw.copy()
            wdf['COUNTRY_CODE'] = wdf['COUNTRY_CODE'].str.upper()
            wdf['TRADING_DAY'] = pd.to_datetime(wdf['TRADING_DAY'])
            wdf['DELIVERY_START'] = pd.to_datetime(wdf['DELIVERY_START'])

            wdf_forward = wdf[wdf['DELIVERY_START'] >= today_week_start].copy()
            wdf_forward = (
                wdf_forward.sort_values('TRADING_DAY')
                .drop_duplicates(
                    subset=['COUNTRY_CODE', 'PROFILE', 'ISO_YEAR', 'ISO_WEEK'],
                    keep='last',
                )
            )

            for _, row in wdf_forward.iterrows():
                price = row.get('SETTLEMENT_PRICE')
                if pd.isna(price):
                    price = row.get('LAST_PRICE')
                if pd.isna(price):
                    continue
                futures_rows.append({
                    'ISO_YEAR': int(row['ISO_YEAR']),
                    'ISO_WEEK': int(row['ISO_WEEK']),
                    'COUNTRY': row['COUNTRY_CODE'],
                    'PRICE': float(price),
                    'PROFILE': row['PROFILE'],
                    'SOURCE': 'futures',
                })
        except Exception as e:
            logger.error("Failed to process weekly_eex_df: %s", e, exc_info=True)

    if futures_rows:
        futures_df = pd.DataFrame(futures_rows)
        rows.append(futures_df)
        logger.info(
            "Weekly futures built: %d rows from native WK contracts for countries: %s",
            len(futures_df), ', '.join(sorted(futures_df['COUNTRY'].unique())),
        )
    else:
        logger.warning(
            "Weekly: no native WK-contract forward rows available (weekly_eex_df empty and "
            "lazy EEX load returned nothing). Forward curve will be spot-only."
        )

    if not rows:
        return pd.DataFrame(columns=['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PROFILE', 'PRICE', 'SOURCE'])

    result = pd.concat(rows, ignore_index=True)

    # Spot beats futures for any week where spot has an observation.
    result['_sort'] = result['SOURCE'].map({'spot': 0, 'blend': 1, 'futures': 2})
    result = result.sort_values('_sort').drop_duplicates(
        subset=['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PROFILE'], keep='first'
    ).drop(columns=['_sort'])

    current_mask = (result['ISO_YEAR'] == current_iso[0]) & (result['ISO_WEEK'] == current_iso[1])
    result.loc[current_mask & (result['SOURCE'] == 'spot'), 'SOURCE'] = 'blend'

    result = result.sort_values(['ISO_YEAR', 'ISO_WEEK', 'COUNTRY', 'PROFILE'])
    return result


def get_layout(data):
    bundle = effective_prices_bundle(data)
    weekly_df = _build_weekly_series(bundle)

    available_countries = sorted(
        weekly_df['COUNTRY'].unique(),
        key=lambda c: PREFERRED_COUNTRY_ORDER.index(c) if c in PREFERRED_COUNTRY_ORDER else 999,
    ) if not weekly_df.empty else ['DE', 'FR', 'GB']
    default_countries = [c for c in ['DE', 'FR', 'GB'] if c in available_countries]

    return html.Div([
        dbc.Container([
            dbc.Card([
                dbc.CardBody([
                    dbc.Row([
                        dbc.Col([
                            html.Label("Countries", className="control-label"),
                            dcc.Dropdown(
                                id='weekly-country-dropdown',
                                options=[{'label': c, 'value': c} for c in available_countries],
                                value=default_countries,
                                multi=True,
                                placeholder="Select countries...",
                                style={'position': 'relative', 'zIndex': 1050},
                            ),
                        ], md=5, style={'position': 'relative', 'zIndex': 1050}),
                        dbc.Col([
                            html.Label("Profile", className="control-label"),
                            dbc.RadioItems(
                                id='weekly-profile-selector',
                                options=[
                                    {'label': 'Base', 'value': 'Base'},
                                    {'label': 'Peak', 'value': 'Peak'},
                                ],
                                value='Base',
                                inline=True,
                                className="mt-1",
                            ),
                        ], md=3),
                        dbc.Col([
                            html.Label("Lookback", className="control-label"),
                            dbc.Select(
                                id='weekly-lookback',
                                options=[
                                    {'label': '12 wk', 'value': '12'},
                                    {'label': '26 wk', 'value': '26'},
                                    {'label': '52 wk', 'value': '52'},
                                ],
                                value='26',
                            ),
                        ], md=2),
                        dbc.Col([
                            html.Label("Forward", className="control-label"),
                            dbc.Select(
                                id='weekly-forward',
                                options=[
                                    {'label': '4 wk', 'value': '4'},
                                    {'label': '8 wk', 'value': '8'},
                                    {'label': '13 wk', 'value': '13'},
                                    {'label': '26 wk', 'value': '26'},
                                ],
                                value='13',
                            ),
                        ], md=2),
                    ], className="align-items-end"),
                ]),
            ], className="control-card mb-3",
               style={'overflow': 'visible', 'position': 'relative', 'zIndex': 1040}),

            html.Div(
                dcc.Graph(id='weekly-chart',
                          style={'height': '72vh'},
                          config={'displayModeBar': True, 'scrollZoom': True}),
                style={'position': 'relative', 'zIndex': 1},
            ),

            html.Div([
                dbc.Button(
                    [html.I(className="fas fa-download me-2"), "Export CSV"],
                    id='weekly-export-btn',
                    color="secondary",
                    outline=True,
                    size="sm",
                    className="mt-2",
                ),
            ]),
            dcc.Download(id='weekly-download'),

            dcc.Store(id='weekly-data-store',
                      data=weekly_df.to_json(date_format='iso', orient='split')),
        ], fluid=True, className="px-3"),
    ])


def register_weekly_callbacks(app, data):

    @app.callback(
        Output('weekly-chart', 'figure'),
        [Input('weekly-country-dropdown', 'value'),
         Input('weekly-profile-selector', 'value'),
         Input('weekly-lookback', 'value'),
         Input('weekly-forward', 'value')],
        [State('weekly-data-store', 'data')],
    )
    def update_weekly_chart(countries, profile, lookback_str, forward_str, json_data):
        if not countries or not json_data:
            return _empty_fig("Select at least one country")

        lookback = int(lookback_str)
        forward = int(forward_str)
        df = pd.read_json(json_data, orient='split')
        if df.empty:
            return _empty_fig("No weekly data available")

        df = df[df['PROFILE'] == profile]
        if isinstance(countries, str):
            countries = [countries]
        df = df[df['COUNTRY'].isin(countries)]

        today = pd.Timestamp.now().normalize()

        df['WEEK_START'] = df.apply(
            lambda r: datetime.strptime(f"{int(r['ISO_YEAR'])}-W{int(r['ISO_WEEK']):02d}-1", "%G-W%V-%u"),
            axis=1,
        )

        window_start = today - timedelta(weeks=lookback)
        window_end = today + timedelta(weeks=forward)
        df = df[(df['WEEK_START'] >= window_start) & (df['WEEK_START'] <= window_end)]

        if df.empty:
            return _empty_fig("No data in selected window")

        fig = go.Figure()

        for country in countries:
            cdf = df[df['COUNTRY'] == country].sort_values('WEEK_START')
            if cdf.empty:
                continue

            color = COUNTRY_COLORS.get(country, '#adb5bd')

            spot_mask = cdf['SOURCE'].isin(['spot', 'blend'])
            spot_df = cdf[spot_mask]
            fut_df = cdf[~spot_mask]

            if not spot_df.empty:
                fig.add_trace(go.Scatter(
                    x=spot_df['WEEK_START'], y=spot_df['PRICE'],
                    mode='lines+markers',
                    name=f'{country} spot',
                    line=dict(color=color, width=2.5),
                    marker=dict(size=5),
                    legendgroup=country,
                    hovertemplate=(
                        f'<b>{country}</b> spot<br>'
                        'Week: %{x|%d %b %Y}<br>'
                        'Price: %{y:.2f} EUR/MWh<extra></extra>'
                    ),
                ))

            if not fut_df.empty:
                fig.add_trace(go.Scatter(
                    x=fut_df['WEEK_START'], y=fut_df['PRICE'],
                    mode='lines+markers',
                    name=f'{country} futures',
                    line=dict(color=color, width=2, dash='dash'),
                    marker=dict(size=5, symbol='diamond'),
                    legendgroup=country,
                    hovertemplate=(
                        f'<b>{country}</b> futures<br>'
                        'Week: %{x|%d %b %Y}<br>'
                        'Price: %{y:.2f} EUR/MWh<extra></extra>'
                    ),
                ))

        fig.add_vline(
            x=today.timestamp() * 1000,
            line_dash='dot', line_color='rgba(255,255,255,0.3)',
            annotation_text='Today', annotation_font_color='rgba(255,255,255,0.5)',
            annotation_position='top',
        )

        fig.update_layout(
            title=dict(text=f'Weekly {profile} Prices - Spot vs Futures',
                       font=dict(size=15)),
            xaxis_title='Week starting',
            yaxis_title='EUR / MWh',
            template=CHART_TEMPLATE,
            plot_bgcolor=CHART_BG,
            paper_bgcolor=CHART_PAPER_BG,
            hovermode='x unified',
            hoverlabel=dict(
                bgcolor='#22262e',
                font_color='#e0e0e0',
                font_size=12,
                bordercolor='#353a44',
            ),
            legend=dict(
                orientation='h', yanchor='bottom', y=1.02,
                xanchor='center', x=0.5,
                bgcolor='rgba(34,38,46,0.95)',
                font=dict(size=11, color='#e0e0e0'),
            ),
            margin=dict(l=50, r=20, t=70, b=45),
            xaxis=dict(gridcolor=CHART_GRID, zeroline=False),
            yaxis=dict(gridcolor=CHART_GRID, zeroline=False),
        )

        return fig

    @app.callback(
        Output('weekly-download', 'data'),
        Input('weekly-export-btn', 'n_clicks'),
        [State('weekly-country-dropdown', 'value'),
         State('weekly-profile-selector', 'value'),
         State('weekly-lookback', 'value'),
         State('weekly-forward', 'value'),
         State('weekly-data-store', 'data')],
        prevent_initial_call=True,
    )
    def export_weekly_csv(n_clicks, countries, profile, lookback_str, forward_str, json_data):
        if not n_clicks or not json_data:
            return no_update

        df = pd.read_json(json_data, orient='split')
        if df.empty:
            return no_update

        df = df[df['PROFILE'] == profile]
        if countries:
            if isinstance(countries, str):
                countries = [countries]
            df = df[df['COUNTRY'].isin(countries)]

        lookback = int(lookback_str)
        forward = int(forward_str)
        today = pd.Timestamp.now().normalize()
        df['WEEK_START'] = df.apply(
            lambda r: datetime.strptime(f"{int(r['ISO_YEAR'])}-W{int(r['ISO_WEEK']):02d}-1", "%G-W%V-%u"),
            axis=1,
        )
        window_start = today - timedelta(weeks=lookback)
        window_end = today + timedelta(weeks=forward)
        df = df[(df['WEEK_START'] >= window_start) & (df['WEEK_START'] <= window_end)]

        export_cols = ['WEEK_START', 'COUNTRY', 'PROFILE', 'PRICE', 'SOURCE']
        export_df = df[[c for c in export_cols if c in df.columns]].sort_values(['WEEK_START', 'COUNTRY'])

        return dcc.send_data_frame(export_df.to_csv, f"weekly_{profile.lower()}_prices.csv", index=False)


def _empty_fig(msg):
    fig = go.Figure()
    fig.update_layout(
        title=msg,
        template=CHART_TEMPLATE,
        plot_bgcolor=CHART_BG,
        paper_bgcolor=CHART_PAPER_BG,
    )
    return fig
