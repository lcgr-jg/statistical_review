"""
Spot Price Dashboard – simplified rewrite.

Key design changes vs. original:
- dcc.Store holds only pre-aggregated data (~30k rows), NOT raw 3M-row data.
  Daily averages:  ~365 days × 42 countries = ~15k rows
  14-day hourly:   ~14 days × 24h × 42 countries = ~14k rows
- All chart/table functions receive the store dict directly – no format mismatch.
- Single clear load callback (no duplicate triggers).
- Pattern-matched buttons replaced by simple RadioItems for time range.
"""

from dash import html, dcc, Input, Output, dash_table, callback_context, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

# EPEX / EU power spot is quoted in local exchange time (CET in winter, CEST in summer).
_TZ_EXCHANGE = ZoneInfo("Europe/Berlin")
from portal_pages.prices.constants import APP_COLORS

import logging
logger = logging.getLogger(__name__)


# ── Constants ─────────────────────────────────────────────────────────────────

PREFERRED_COUNTRIES = [
    'DK1', 'DK2', 'NO2', 'DE', 'CH', 'FR', 'GB', 'NL', 'BE',
    'IT', 'IT-NORTH', 'ES', 'AT', 'HU', 'CZ', 'SK', 'SI', 'GR', 'RO', 'BG', 'HR',
]

TIME_RANGES = [
    {"label": "1 Day",    "value": "24h", "days": 1},
    {"label": "3 Days",   "value": "3d",  "days": 3},
    {"label": "7 Days",   "value": "1w",  "days": 7},
    {"label": "30 Days",  "value": "1m",  "days": 30},
    {"label": "6 Months", "value": "6m",  "days": 180},
    {"label": "1 Year",   "value": "1y",  "days": 365},
]
TIME_MAP = {r["value"]: r["days"] for r in TIME_RANGES}

DEFAULT_COUNTRIES = ['DE', 'FR', 'GB', 'BE', 'NL', 'CH', 'IT', 'ES']
DROPDOWN_COUNTRIES = PREFERRED_COUNTRIES  # use preferred order for dropdown options


def get_ordered_countries(countries):
    """Sort country list in preferred order."""
    avail = [c for c in PREFERRED_COUNTRIES if c in countries]
    extra = sorted([c for c in countries if c not in PREFERRED_COUNTRIES])
    return avail + extra


# ── Data preparation (server-side) ────────────────────────────────────────────

def _prepare_store_data(app_data):
    """
    Extract, filter, and aggregate spot price data for dcc.Store.
    Returns a compact dict rather than serialising millions of raw rows.
    """
    raw = app_data.get('power_spot_normalized', pd.DataFrame())
    if raw is None or raw.empty:
        return {'data_loaded': False, 'error': 'No power spot data'}

    # Filter: hourly, EUR only
    mask = (raw['frequency'].str.upper() == 'H') & (raw['currency'].str.upper() == 'EUR')
    df = raw.loc[mask, ['valuedate', 'zone', 'value']].copy()
    df.columns = ['DeliveryTime', 'Country', 'Value']

    # Source times are UTC (S3 cache / EQ); convert to exchange local (CET/CEST) for display + hour bucket
    df['DeliveryTime'] = pd.to_datetime(df['DeliveryTime'], utc=True, errors='coerce')
    df['DeliveryTime'] = df['DeliveryTime'].dt.tz_convert(_TZ_EXCHANGE)

    # Keep last 365 days
    latest_dt = df['DeliveryTime'].max()
    df = df[df['DeliveryTime'] >= latest_dt - pd.Timedelta(days=365)]

    df['Date'] = df['DeliveryTime'].dt.strftime('%Y-%m-%d')
    df['Hour'] = df['DeliveryTime'].dt.hour
    latest_date = df['Date'].max()

    # Daily base average (all 24 hours)
    daily = (df.groupby(['Date', 'Country'])['Value']
               .mean().round(2).reset_index())

    # Daily peak average (hours 8-20)
    daily_peak = (
        df[df['Hour'].between(8, 20)]
        .groupby(['Date', 'Country'])['Value']
        .mean().round(2).reset_index()
        .rename(columns={'Value': 'PeakValue'})
    )

    # Recent 14-day hourly
    cutoff_14d = (pd.to_datetime(latest_date) - pd.Timedelta(days=13)).strftime('%Y-%m-%d')
    hourly_14d = df[df['Date'] >= cutoff_14d].copy()
    hourly_14d['DeliveryTime'] = hourly_14d['DeliveryTime'].dt.strftime('%Y-%m-%d %H:%M')

    countries = get_ordered_countries(df['Country'].unique().tolist())

    logger.info(
        f"Spot store: {len(daily)} daily rows, {len(hourly_14d)} hourly rows, "
        f"{len(countries)} countries, latest={latest_date}"
    )

    return {
        'data_loaded': True,
        'countries': countries,
        'latest_date': latest_date,
        'daily': daily.to_dict('records'),
        'daily_peak': daily_peak.to_dict('records'),
        'hourly_14d': hourly_14d[['DeliveryTime', 'Date', 'Hour', 'Country', 'Value']].to_dict('records'),
    }


def _add_css_to_store(store, app_data):
    """Optionally add CSS spark spread data to the store."""
    try:
        css_raw = app_data.get('CSS_processed_spot', pd.DataFrame())
        if css_raw is None or css_raw.empty:
            return store

        # DATE, HOUR, COUNTRY etc. are MultiIndex levels – flatten first
        css = css_raw.reset_index() if isinstance(css_raw.index, pd.MultiIndex) else css_raw.copy()

        # Validate required columns are present after reset
        required = {'DATE', 'HOUR', 'COUNTRY', 'CSS_MID_EFF'}
        missing = required - set(css.columns)
        if missing:
            logger.warning(f"CSS spot data missing columns after reset_index: {missing}")
            return store

        css['DeliveryTime'] = (
            pd.to_datetime(css['DATE']) + pd.to_timedelta(css['HOUR'], unit='h')
        )
        if css['DeliveryTime'].dt.tz is None:
            css['DeliveryTime'] = css['DeliveryTime'].dt.tz_localize('UTC')
        css['DeliveryTime'] = css['DeliveryTime'].dt.tz_convert(_TZ_EXCHANGE)
        css['Date'] = css['DeliveryTime'].dt.strftime('%Y-%m-%d')
        css['Hour'] = css['DeliveryTime'].dt.hour
        css = css.rename(columns={'COUNTRY': 'Country', 'CSS_MID_EFF': 'Value'})

        css_daily = css.groupby(['Date', 'Country'])['Value'].mean().round(2).reset_index()

        latest = css['Date'].max()
        cutoff = (pd.to_datetime(latest) - pd.Timedelta(days=13)).strftime('%Y-%m-%d')
        css_hourly = css[css['Date'] >= cutoff].copy()
        css_hourly['DeliveryTime'] = css_hourly['DeliveryTime'].dt.strftime('%Y-%m-%d %H:%M')

        store['css_daily'] = css_daily.to_dict('records')
        store['css_hourly_14d'] = css_hourly[['DeliveryTime', 'Date', 'Hour', 'Country', 'Value']].to_dict('records')
    except Exception as e:
        logger.warning(f"CSS spot data unavailable: {e}")
    return store


# ── Chart / table builders ────────────────────────────────────────────────────

def _build_graph(store, countries, time_range_value, resampling, data_type):
    """Build the spot price / CSS spark spread line chart."""
    if not store or not store.get('data_loaded'):
        return html.Div("Loading data…", className="text-center text-muted my-5")

    days = TIME_MAP.get(time_range_value, 7)
    use_hourly = (resampling == 'hourly' and days <= 14)

    if data_type == 'spark':
        key = 'css_hourly_14d' if use_hourly else 'css_daily'
        y_label, title_prefix = "CSS Spread (EUR/MWh)", "CSS Spark Spreads"
    else:
        key = 'hourly_14d' if use_hourly else 'daily'
        y_label, title_prefix = "Price (EUR/MWh)", "Spot Prices"

    records = store.get(key, [])
    if not records:
        return html.Div(f"No {title_prefix.lower()} data available",
                        className="text-center text-muted my-5")

    df = pd.DataFrame(records)

    # Date-range filter
    latest = pd.to_datetime(store['latest_date']).date()
    start = (latest - timedelta(days=days - 1)).strftime('%Y-%m-%d')
    df = df[df['Date'] >= start]

    if countries:
        df = df[df['Country'].isin(countries)]

    if df.empty:
        return html.Div("No data for the selected filters", className="text-center text-muted my-5")

    # hourly_14d has DeliveryTime (naive wall-clock after JSON round-trip = Europe/Berlin); daily uses Date
    if 'DeliveryTime' in df.columns:
        t = pd.to_datetime(df['DeliveryTime'], errors='coerce')
        if use_hourly:
            if getattr(t.dt, 'tz', None) is None:
                t = t.dt.tz_localize(_TZ_EXCHANGE, ambiguous='infer', nonexistent='shift_forward')
        else:
            if getattr(t.dt, 'tz', None) is None:
                t = t.dt.tz_localize(_TZ_EXCHANGE)
        df = df.assign(DeliveryTime=t)
    else:
        d = pd.to_datetime(df['Date'], errors='coerce')
        if getattr(d.dt, 'tz', None) is None:
            d = d.dt.tz_localize(_TZ_EXCHANGE)
        df = df.assign(DeliveryTime=d)
    df = df.sort_values('DeliveryTime')

    fig = go.Figure()
    plot_countries = [c for c in (countries or []) if c in df['Country'].unique()]
    for country in plot_countries:
        cdf = df[df['Country'] == country]
        if cdf.empty:
            continue
        fig.add_trace(go.Scatter(
            x=cdf['DeliveryTime'],
            y=cdf['Value'],
            mode='lines',
            name=country,
            line=dict(width=2, shape='hv' if use_hourly else 'linear'),
            hovertemplate=f"{country}: %{{y:.1f}} EUR/MWh<extra></extra>",
        ))

    time_label = {r["value"]: r["label"] for r in TIME_RANGES}.get(time_range_value, "")
    mode_label = "Hourly" if use_hourly else "Daily Avg"
    fig.update_layout(
        title=f"{title_prefix} – {mode_label} – {time_label} (CET/CEST · Europe/Berlin)",
        xaxis_title="Delivery time (CET/CEST)",
        yaxis_title=y_label,
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        template="seaborn",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    if use_hourly:
        fig.update_xaxes(tickformat='%d %b %H:%M')

    return dcc.Graph(
        figure=fig,
        style={'height': '60vh'},
        config={'scrollZoom': True, 'displayModeBar': True},
    )


def _build_heatmap(store, heatmap_type, time_range, data_type):
    """Build daily or weekly price heatmap."""
    if not store or not store.get('data_loaded'):
        return html.Div("Loading…", className="text-center text-muted my-5")

    key = 'css_daily' if data_type == 'spark' and 'css_daily' in store else 'daily'
    records = store.get(key, [])
    if not records:
        return html.Div("No data available", className="text-center text-muted my-5")

    df = pd.DataFrame(records)
    latest = df['Date'].max()

    if heatmap_type == 'daily':
        start = (pd.to_datetime(latest) - pd.Timedelta(days=int(time_range) - 1)).strftime('%Y-%m-%d')
        df = df[df['Date'] >= start]
        pivot = df.pivot_table(index='Country', columns='Date', values='Value')
        col_labels = [pd.to_datetime(c).strftime('%d-%b-%y') for c in pivot.columns]
        type_label = f"{time_range} Days"
    else:
        # Weekly aggregation
        df['Week'] = (pd.to_datetime(df['Date'])
                      .dt.to_period('W').dt.start_time
                      .dt.strftime('%Y-%m-%d'))
        latest_week = df['Week'].max()
        start_week = (pd.to_datetime(latest_week) - pd.Timedelta(weeks=int(time_range) - 1)).strftime('%Y-%m-%d')
        df = df[df['Week'] >= start_week]
        weekly = df.groupby(['Week', 'Country'])['Value'].mean().round(2).reset_index()
        pivot = weekly.pivot_table(index='Country', columns='Week', values='Value')
        col_labels = [pd.to_datetime(c).strftime('W%V-%y') for c in pivot.columns]
        type_label = f"{time_range} Weeks"

    if pivot.empty:
        return html.Div("No data for selected range", className="text-center text-muted my-5")

    ordered = get_ordered_countries(pivot.index.tolist())
    ordered = [c for c in ordered if c in pivot.index]
    pivot = pivot.reindex(ordered)

    y_label = "CSS Spread (EUR/MWh)" if data_type == 'spark' else "Price (EUR/MWh)"

    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=col_labels,
        y=pivot.index.tolist(),
        colorscale='RdBu_r',
        colorbar=dict(title=y_label),
        hovertemplate='<b>%{y}</b><br>%{x}: %{z:.1f} EUR/MWh<extra></extra>',
    ))
    fig.update_layout(
        title=f"Price Heatmap – {type_label} (daily avg · CET/CEST delivery days)",
        xaxis=dict(title='', tickangle=-45, type='category'),
        yaxis=dict(title='Country', categoryorder='array', categoryarray=ordered),
        height=550,
        margin=dict(l=50, r=50, t=80, b=100),
    )

    return dcc.Graph(
        figure=fig,
        style={'height': '70vh', 'width': '100%'},
        config={'displayModeBar': True},
    )


def _build_table(store, countries, active_tab, data_type):
    """Build one of the table views from store data."""
    if not store or not store.get('data_loaded'):
        return html.Div("Loading…", className="text-center text-muted my-5")

    ordered = get_ordered_countries(countries or [])
    header_bg = APP_COLORS.get('header_bg', '#f8f9fa')
    header_text = APP_COLORS.get('header_text', '#212529')
    hl_bg = APP_COLORS.get('highlight_bg', '#e9ecef')
    hl_text = APP_COLORS.get('highlight_text', '#495057')

    tbl_style = {
        'overflowX': 'auto', 'maxHeight': '600px', 'overflowY': 'auto',
        'border': '1px solid #e0e0e0', 'borderRadius': '5px',
    }
    cell_style = {
        'textAlign': 'center', 'padding': '10px 8px',
        'fontFamily': 'Arial, sans-serif', 'fontSize': '13px',
    }
    hdr_style = {'backgroundColor': header_bg, 'color': header_text, 'fontWeight': 'bold'}

    def fmt(v):
        try:
            f = float(v)
            return f"{f:.2f}" if pd.notna(f) else "-"
        except (TypeError, ValueError):
            return "-"

    # ── Hourly tab ─────────────────────────────────────────────────
    if active_tab == "hourly":
        key = 'css_hourly_14d' if data_type == 'spark' and 'css_hourly_14d' in store else 'hourly_14d'
        records = store.get(key, [])
        if not records:
            return html.Div("No hourly data available", className="text-center text-muted my-5")

        df = pd.DataFrame(records)
        now_cet = datetime.now(_TZ_EXCHANGE)
        # Try yesterday first (latest complete day), fall back to latest available
        target_day = (now_cet.date() - timedelta(days=1)).strftime('%Y-%m-%d')
        day_df = df[df['Date'] == target_day]
        if day_df.empty:
            target_day = df['Date'].max()
            day_df = df[df['Date'] == target_day]

        avail = [c for c in ordered if c in day_df['Country'].unique()]
        rows = []
        for h in range(24):
            row = {'Hour': f"{h:02d}:00"}
            hdf = day_df[day_df['Hour'] == h]
            for c in avail:
                vals = hdf[hdf['Country'] == c]['Value']
                row[c] = fmt(vals.mean()) if not vals.empty else "-"
            rows.append(row)

        cols = [{"name": "Hour (CET/CEST)", "id": "Hour"}] + [{"name": c, "id": c} for c in avail]
        return html.Div([
            html.H5(
                f"Hourly Prices – {pd.to_datetime(target_day).strftime('%d %b %Y')} (CET/CEST)",
                className="text-center mb-3"
            ),
            dash_table.DataTable(
                columns=cols, data=rows,
                style_table=tbl_style, style_cell=cell_style, style_header=hdr_style,
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#f9f9f9'},
                    {'if': {'column_id': 'Hour'}, 'textAlign': 'left',
                     'fontWeight': 'bold', 'backgroundColor': hl_bg, 'color': hl_text},
                ],
            ),
        ])

    # ── Base / Peak tabs ───────────────────────────────────────────
    elif active_tab in ("base", "peak"):
        is_peak = (active_tab == "peak")
        if is_peak:
            records = store.get('daily_peak', [])
            val_col = 'PeakValue'
            title = "Peak Load Prices (hours 8–20 average)"
        else:
            records = store.get('daily', [])
            val_col = 'Value'
            title = "Base Load Prices (24-hour average)"

        if not records:
            return html.Div("No data available", className="text-center text-muted my-5")

        df = pd.DataFrame(records)
        latest = df['Date'].max()
        start = (pd.to_datetime(latest) - pd.Timedelta(days=13)).strftime('%Y-%m-%d')
        df = df[df['Date'] >= start]

        avail = [c for c in ordered if c in df['Country'].unique()]
        pivot = df.pivot_table(index='Date', columns='Country', values=val_col)
        pivot = pivot.reset_index().sort_values('Date', ascending=False)

        rows = [
            {'Date': r['Date'], **{c: fmt(r.get(c)) for c in avail}}
            for _, r in pivot.iterrows()
        ]
        cols = [{"name": "Date", "id": "Date"}] + [{"name": c, "id": c} for c in avail]

        return html.Div([
            html.H5(f"{title} – Last 14 Days (CET/CEST delivery days)", className="text-center mb-3"),
            dash_table.DataTable(
                columns=cols, data=rows,
                style_table=tbl_style, style_cell=cell_style, style_header=hdr_style,
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#f9f9f9'},
                    {'if': {'column_id': 'Date'}, 'textAlign': 'left',
                     'fontWeight': 'bold', 'backgroundColor': hl_bg, 'color': hl_text},
                ],
            ),
        ])

    # ── Averages tab ───────────────────────────────────────────────
    elif active_tab == "averages":
        records = store.get('daily', [])
        if not records:
            return html.Div("No data available", className="text-center text-muted my-5")

        df = pd.DataFrame(records)
        now_cet = datetime.now(_TZ_EXCHANGE)
        today = now_cet.date().strftime('%Y-%m-%d')
        yesterday = (now_cet.date() - timedelta(days=1)).strftime('%Y-%m-%d')
        week_start = (now_cet.date() - timedelta(days=6)).strftime('%Y-%m-%d')

        rows = []
        for c in ordered:
            cdf = df[df['Country'] == c]
            if cdf.empty:
                continue
            rows.append({
                'Country': c,
                'Today Avg':     fmt(cdf[cdf['Date'] == today]['Value'].mean()),
                'Yesterday Avg': fmt(cdf[cdf['Date'] == yesterday]['Value'].mean()),
                '7-Day Avg':     fmt(cdf[cdf['Date'] >= week_start]['Value'].mean()),
            })

        if not rows:
            return html.Div("No averages available", className="text-center text-muted my-5")

        today_dt = pd.to_datetime(today)
        yest_dt = pd.to_datetime(yesterday)
        cols = [
            {"name": "Country", "id": "Country"},
            {"name": f"Today ({today_dt.strftime('%d %b')})", "id": "Today Avg"},
            {"name": f"Yesterday ({yest_dt.strftime('%d %b')})", "id": "Yesterday Avg"},
            {"name": "7-Day Avg", "id": "7-Day Avg"},
        ]
        return html.Div([
            html.H5("Price Averages Summary (EUR/MWh)", className="text-center mb-3"),
            dash_table.DataTable(
                columns=cols, data=rows,
                style_table=tbl_style, style_cell=cell_style, style_header=hdr_style,
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#f9f9f9'},
                    {'if': {'column_id': 'Country'}, 'textAlign': 'left',
                     'fontWeight': 'bold', 'backgroundColor': hl_bg, 'color': hl_text},
                ],
            ),
        ])

    # ── Weekly summary tab ─────────────────────────────────────────
    elif active_tab == "weekly_summary":
        records = store.get('daily', [])
        if not records:
            return html.Div("No data available", className="text-center text-muted my-5")

        df = pd.DataFrame(records)
        df['dt'] = pd.to_datetime(df['Date'])
        df['WeekStart'] = (
            df['dt'] - pd.to_timedelta(df['dt'].dt.dayofweek, unit='D')
        ).dt.strftime('%Y-%m-%d')
        df['DayOfWeek'] = df['dt'].dt.dayofweek

        # Last 4 weeks
        now_cet = datetime.now(_TZ_EXCHANGE)
        today = now_cet.date()
        week0 = (today - timedelta(days=today.weekday())).strftime('%Y-%m-%d')
        start = (pd.to_datetime(week0) - pd.Timedelta(weeks=3)).strftime('%Y-%m-%d')
        df = df[df['WeekStart'] >= start]

        weeks = sorted(df['WeekStart'].unique())
        rows = []
        for c in ordered:
            cdf = df[df['Country'] == c]
            if cdf.empty:
                continue
            row = {'Country': c}
            for w in weeks:
                wdf = cdf[cdf['WeekStart'] == w]
                label = pd.to_datetime(w).strftime('%d %b')
                row[f"{label} Wkday"] = fmt(wdf[wdf['DayOfWeek'] < 5]['Value'].mean())
                row[f"{label} Wkend"] = fmt(wdf[wdf['DayOfWeek'] >= 5]['Value'].mean())
                row[f"{label} All"]   = fmt(wdf['Value'].mean())
            rows.append(row)

        if not rows:
            return html.Div("No weekly data available", className="text-center text-muted my-5")

        week_cols = [
            col
            for w in weeks
            for col in [
                {"name": f"{pd.to_datetime(w).strftime('%d %b')} Wkday", "id": f"{pd.to_datetime(w).strftime('%d %b')} Wkday"},
                {"name": f"{pd.to_datetime(w).strftime('%d %b')} Wkend", "id": f"{pd.to_datetime(w).strftime('%d %b')} Wkend"},
                {"name": f"{pd.to_datetime(w).strftime('%d %b')} All",   "id": f"{pd.to_datetime(w).strftime('%d %b')} All"},
            ]
        ]
        cols = [{"name": "Country", "id": "Country"}] + week_cols

        return html.Div([
            html.H5("Weekly Price Summary (EUR/MWh) – Last 4 Weeks", className="text-center mb-3"),
            dash_table.DataTable(
                columns=cols, data=rows,
                style_table=tbl_style, style_cell=cell_style, style_header=hdr_style,
                style_data_conditional=[
                    {'if': {'row_index': 'odd'}, 'backgroundColor': '#f9f9f9'},
                    {'if': {'column_id': 'Country'}, 'textAlign': 'left',
                     'fontWeight': 'bold', 'backgroundColor': hl_bg, 'color': hl_text},
                ],
            ),
        ])

    return html.Div("Unknown tab", className="text-center text-muted my-5")


# ── Layout ────────────────────────────────────────────────────────────────────

def get_layout(data):
    """Spot page layout."""
    label_style = {
        'fontSize': '11px', 'fontWeight': '600', 'color': '#666',
        'marginBottom': '5px', 'display': 'block',
        'textTransform': 'uppercase', 'letterSpacing': '0.5px',
    }

    return html.Div([
        # Store & one-shot load trigger
        dcc.Store(id='spot-store', data=None),
        dcc.Interval(id='spot-load-trigger', interval=500, n_intervals=0, max_intervals=1),

        # Header bar
        html.Div([
            html.Div([
                html.Span("Price Dashboard", style={'color': '#888', 'fontSize': '13px'}),
                html.Span(" / ", style={'color': '#666', 'margin': '0 6px', 'fontSize': '13px'}),
                html.Span("Spot Prices", style={'color': '#333', 'fontSize': '13px', 'fontWeight': '600'}),
            ]),
            html.Div([
                dbc.Button("↻ Refresh", id="spot-refresh-btn", color="link", size="sm",
                           style={'fontSize': '12px', 'padding': '2px 10px'}),
                html.Span("", id="spot-last-refresh",
                          style={'fontSize': '11px', 'color': '#888', 'marginLeft': '12px'}),
            ], style={'display': 'flex', 'alignItems': 'center'}),
        ], style={
            'padding': '16px 30px', 'borderBottom': '1px solid #e5e5e5',
            'display': 'flex', 'alignItems': 'center', 'justifyContent': 'space-between',
        }),

        # Control bar
        html.Div([
            # Data type
            html.Div([
                html.Label("Data Type", style=label_style),
                dbc.RadioItems(
                    id="spot-data-type",
                    options=[
                        {"label": "Spot Prices",       "value": "spot"},
                        {"label": "CSS Spark Spreads", "value": "spark"},
                    ],
                    value="spot", inline=True, style={'fontSize': '13px'},
                ),
            ]),
            # Countries
            html.Div([
                html.Label("Countries", style=label_style),
                dcc.Dropdown(
                    id="spot-countries",
                    options=[{"label": c, "value": c} for c in DROPDOWN_COUNTRIES],
                    value=DEFAULT_COUNTRIES, multi=True,
                    style={'width': '420px', 'fontSize': '13px'},
                ),
            ]),
            # Resampling
            html.Div([
                html.Label("View", style=label_style),
                dbc.RadioItems(
                    id="spot-resampling",
                    options=[
                        {"label": "Hourly",    "value": "hourly"},
                        {"label": "Daily Avg", "value": "daily"},
                    ],
                    value="hourly", inline=True, style={'fontSize': '13px'},
                ),
            ]),
            # Time range
            html.Div([
                html.Label("Time Range", style=label_style),
                dbc.RadioItems(
                    id="spot-time-range",
                    options=[{"label": r["label"], "value": r["value"]} for r in TIME_RANGES],
                    value="1w", inline=True, style={'fontSize': '13px'},
                ),
            ]),
        ], style={
            'padding': '16px 30px', 'borderBottom': '1px solid #e5e5e5',
            'display': 'flex', 'alignItems': 'flex-end', 'flexWrap': 'wrap', 'gap': '24px',
        }),

        # Chart panel
        html.Div([
            dbc.Spinner(
                html.Div(id="spot-graph-container",
                         children=html.P("Loading spot price data…",
                                         className="text-center text-muted my-5")),
                color="primary", type="border",
                spinner_style={"width": "3rem", "height": "3rem"},
            ),
        ], style={
            'padding': '24px 30px', 'backgroundColor': '#fff',
            'margin': '16px 30px', 'borderRadius': '6px',
            'boxShadow': '0 1px 3px rgba(0,0,0,0.05)',
        }),

        # Table panel
        html.Div([
            html.Div([
                html.H5("Table View", style={'fontSize': '15px', 'fontWeight': '600',
                                             'color': '#333', 'marginBottom': '12px'}),
                dbc.Tabs(
                    id="spot-table-tabs", active_tab="hourly",
                    children=[
                        dbc.Tab(label="Hourly",         tab_id="hourly"),
                        dbc.Tab(label="Base Load",      tab_id="base"),
                        dbc.Tab(label="Peak Load",      tab_id="peak"),
                        dbc.Tab(label="Averages",       tab_id="averages"),
                        dbc.Tab(label="Weekly Summary", tab_id="weekly_summary"),
                    ],
                ),
            ], style={'marginBottom': '16px'}),
            html.Div(id="spot-table-container",
                     children=html.P("Loading…", className="text-center text-muted my-5")),
        ], style={
            'padding': '24px 30px', 'backgroundColor': '#fff',
            'margin': '16px 30px', 'borderRadius': '6px',
            'boxShadow': '0 1px 3px rgba(0,0,0,0.05)',
        }),

        # Heatmap panel
        html.Div([
            html.Div([
                html.H5("Heatmap", style={'fontSize': '15px', 'fontWeight': '600',
                                          'color': '#333', 'marginBottom': '12px'}),
                html.Div([
                    dbc.Tabs(
                        id="spot-heatmap-type", active_tab="daily",
                        children=[
                            dbc.Tab(label="Daily",  tab_id="daily"),
                            dbc.Tab(label="Weekly", tab_id="weekly"),
                        ],
                    ),
                ], style={'marginBottom': '12px'}),
                # Daily range selector
                html.Div([
                    html.Label("Days", style=label_style),
                    dcc.Dropdown(
                        id="spot-daily-range",
                        options=[
                            {"label": "7 Days",   "value": 7},
                            {"label": "30 Days",  "value": 30},
                            {"label": "90 Days",  "value": 90},
                            {"label": "180 Days", "value": 180},
                            {"label": "1 Year",   "value": 365},
                        ],
                        value=30, clearable=False, style={'width': '180px', 'fontSize': '13px'},
                    ),
                ], id="spot-daily-range-div"),
                # Weekly range selector
                html.Div([
                    html.Label("Weeks", style=label_style),
                    dcc.Dropdown(
                        id="spot-weekly-range",
                        options=[
                            {"label": "4 Weeks",  "value": 4},
                            {"label": "13 Weeks", "value": 13},
                            {"label": "26 Weeks", "value": 26},
                            {"label": "52 Weeks", "value": 52},
                        ],
                        value=13, clearable=False, style={'width': '180px', 'fontSize': '13px'},
                    ),
                ], id="spot-weekly-range-div", style={'display': 'none'}),
            ], style={'marginBottom': '16px'}),

            dbc.Spinner(
                html.Div(id="spot-heatmap-container",
                         children=html.P("Loading…", className="text-center text-muted my-5")),
                color="primary", type="border",
                spinner_style={"width": "3rem", "height": "3rem"},
            ),
        ], style={
            'padding': '24px 30px', 'backgroundColor': '#fff',
            'margin': '16px 30px', 'borderRadius': '6px',
            'boxShadow': '0 1px 3px rgba(0,0,0,0.05)',
        }),

    ], style={'backgroundColor': '#f5f6f8', 'minHeight': '100vh'})


# ── Callbacks ─────────────────────────────────────────────────────────────────

def register_spot_callbacks(app, data):
    """Register all spot page callbacks."""
    app_data = data  # shared reference – populated lazily by portal

    @app.callback(
        [Output('spot-store', 'data'),
         Output('spot-last-refresh', 'children')],
        [Input('spot-load-trigger', 'n_intervals'),
         Input('spot-refresh-btn', 'n_clicks')],
        prevent_initial_call=False,
    )
    def load_data(_n, _refresh):
        store = _prepare_store_data(app_data)
        _add_css_to_store(store, app_data)
        ts = f"Updated: {datetime.now(_TZ_EXCHANGE).strftime('%H:%M:%S')} CET/CEST"
        return store, ts

    @app.callback(
        Output('spot-graph-container', 'children'),
        [Input('spot-countries', 'value'),
         Input('spot-time-range', 'value'),
         Input('spot-resampling', 'value'),
         Input('spot-data-type', 'value'),
         Input('spot-store', 'data')],
        prevent_initial_call=False,
    )
    def update_graph(countries, time_range, resampling, data_type, store):
        return _build_graph(store, countries, time_range, resampling, data_type)

    @app.callback(
        Output('spot-table-container', 'children'),
        [Input('spot-countries', 'value'),
         Input('spot-table-tabs', 'active_tab'),
         Input('spot-data-type', 'value'),
         Input('spot-store', 'data')],
        prevent_initial_call=False,
    )
    def update_table(countries, tab, data_type, store):
        return _build_table(store, countries or [], tab, data_type)

    @app.callback(
        [Output('spot-heatmap-container', 'children'),
         Output('spot-daily-range-div', 'style'),
         Output('spot-weekly-range-div', 'style')],
        [Input('spot-heatmap-type', 'active_tab'),
         Input('spot-daily-range', 'value'),
         Input('spot-weekly-range', 'value'),
         Input('spot-data-type', 'value'),
         Input('spot-store', 'data')],
        prevent_initial_call=False,
    )
    def update_heatmap(heatmap_type, daily_range, weekly_range, data_type, store):
        show = {'display': 'block'}
        hide = {'display': 'none'}
        time_range = daily_range if heatmap_type == 'daily' else weekly_range
        daily_style  = show if heatmap_type == 'daily'  else hide
        weekly_style = show if heatmap_type == 'weekly' else hide
        return _build_heatmap(store, heatmap_type, time_range, data_type), daily_style, weekly_style
