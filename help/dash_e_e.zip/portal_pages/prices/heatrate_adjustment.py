"""
Heat Rate Adjustment
=====================
Compare historical power prices across periods on a like-for-like fuel basis by
re-pricing every hour at *today's* forward fuel cost.

Method
------
1. Hourly implied heat rate:

       HR_h = power_spot_h / (gas_spot_d + 0.1821 * eua_spot_d)

   where gas_spot_d / eua_spot_d are that day's TTF gas and EUA carbon spot.

2. Re-price to current forward fuel cost using the latest settlement of the
   front-month TTF and front-December EUA:

       adjusted_h = HR_h * (front_TTF + 0.1821 * front_Dec_EUA)   if power_spot_h > 0
       adjusted_h = power_spot_h                                   otherwise

   (Zero / negative spot hours are left untouched.)

The page renders:
  * A Year x Month table (rows = year, cols = month) of the monthly-average
    adjusted power price for the selected hub (mirrors the price_report layout).
  * A spot-vs-adjusted daily time series for a user-selected date range, with
    an Excel download of the underlying data.
"""

from __future__ import annotations

import io
import logging
from datetime import date, datetime, timedelta

import dash_bootstrap_components as dbc
import pandas as pd
import plotly.graph_objects as go
from dash import ALL, Input, Output, State, dash_table, dcc, html, no_update

from portal_pages.prices.constants import APP_COLORS
from portal_pages.prices.prices_data_bundle import effective_prices_bundle

logger = logging.getLogger(__name__)

# CO2 emission factor for a gas CCGT (tCO2 / MWh thermal) used to convert the
# carbon price into the gas-equivalent fuel cost embedded in the heat rate.
CO2_FACTOR = 0.1821

MONTH_LABELS = {
    1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
    7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec",
}
MONTH_NUM_BY_LABEL = {v.upper(): k for k, v in MONTH_LABELS.items()}

PREFERRED_HUBS = [
    "DE", "FR", "GB", "NL", "BE", "CH", "AT", "IT", "IT-NORTH", "ES",
    "DK1", "DK2", "NO2", "HU", "CZ", "SK", "SI", "GR", "RO", "BG", "HR",
]
DEFAULT_HUB = "DE"

# Interconnection topology (which zones share a border). Used by the Location
# Spreads view to pick the set of neighbours for a chosen country. Only zones
# present in PREFERRED_HUBS are surfaced in the UI; anything else is ignored.
BORDERS = {
    "DE":       ["FR", "NL", "BE", "CH", "AT", "CZ", "HU", "IT", "DK1", "DK2", "NO2"],
    "FR":       ["DE", "BE", "CH", "GB", "ES", "IT-NORTH"],
    "GB":       ["FR", "BE", "NL", "NO2"],
    "NL":       ["DE", "BE", "GB", "NO2", "DK1"],
    "BE":       ["FR", "DE", "NL", "GB"],
    "CH":       ["DE", "FR", "AT", "IT"],
    "AT":       ["DE", "CH", "IT", "CZ", "SI", "HU", "SK"],
    "IT":       ["DE", "GR", "FR" , "HU" , "DE"],
    "IT-NORTH": ["FR", "CH", "AT", "SI"],
    "ES":       ["FR"],
    "DK1":      ["DE", "NL", "DK2", "NO2"],
    "DK2":      ["DE", "DK1"],
    "NO2":      ["DE", "NL", "GB", "DK1"],
    "HU":       ["AT", "SK", "SI", "RO", "HR", "IT"],
    "CZ":       ["DE", "AT", "SK"],
    "SK":       ["CZ", "AT", "HU"],
    "SI":       ["AT", "IT-NORTH", "HU", "HR"],
    "GR":       ["BG", "IT"],
    "RO":       ["HU", "BG"],
    "BG":       ["RO", "GR"],
    "HR":       ["SI", "HU"],
}


def _neighbors(country: str) -> list:
    """Borders of ``country`` that we have a power hub for, de-duplicated."""
    raw = BORDERS.get(str(country).upper(), [])
    seen, out = set(), []
    for z in raw:
        if z in PREFERRED_HUBS and z not in seen and z != country:
            seen.add(z)
            out.append(z)
    return out


# ── Forward settlements ─────────────────────────────────────────────────────

def _get_forward_settlements():
    """
    Latest settlement of the front-month TTF and the front (nearest) December
    EUA contract, pulled from the Fuel Switching forward cache.

    Returns ``(front_ttf, front_dec_eua, settlement_date)`` where any element
    may be ``None`` if the forward cache is unavailable.
    """
    try:
        from core import data as data_service

        cache = data_service.get_fuel_switching()
        if cache is None:
            return None, None, None

        fwd = cache.get_forward_data("DE", "TTF")
        if fwd is None or fwd.empty:
            return None, None, None

        settlement = None
        try:
            settlement = cache.get_settlement_date_options()[1]
        except Exception:
            settlement = None

        fwd = fwd.sort_index()

        # Front-month TTF = first (nearest) month of the gas forward curve.
        front_ttf = None
        if "Gas" in fwd.columns:
            gas = fwd["Gas"].dropna()
            if not gas.empty:
                front_ttf = float(gas.iloc[0])

        # Front December EUA = nearest December delivery on the carbon curve.
        front_dec_eua = None
        if "Carbon" in fwd.columns and "Month" in fwd.columns and "Year" in fwd.columns:
            carbon = fwd.dropna(subset=["Carbon"])
            dec_rows = carbon[carbon["Month"] == 12]
            if not dec_rows.empty:
                front_dec_eua = float(dec_rows.sort_values("Year")["Carbon"].iloc[0])
            elif not carbon.empty:
                # No explicit December on the curve — fall back to last point.
                front_dec_eua = float(carbon["Carbon"].iloc[-1])

        return front_ttf, front_dec_eua, settlement
    except Exception as e:
        logger.warning("Heat-rate adjustment: forward settlements unavailable: %s", e)
        return None, None, None


def _daily_hub_series(normalized: pd.DataFrame, hub_col: str, hub_value: str) -> pd.Series:
    """Daily-average value for a single hub from a normalized spot frame."""
    if normalized is None or getattr(normalized, "empty", True):
        return pd.Series(dtype="float64")
    df = normalized.copy()
    df[hub_col] = df[hub_col].astype(str)
    df = df[df[hub_col].str.upper() == hub_value.upper()]
    if df.empty:
        return pd.Series(dtype="float64")
    df["d"] = pd.to_datetime(df["valuedate"]).dt.date
    return df.groupby("d")["value"].mean()


# ── Core computation ─────────────────────────────────────────────────────────

def _compute_hourly(bundle, hub, front_ttf, front_dec_eua) -> pd.DataFrame:
    """
    Build the hourly spot + heat-rate-adjusted series for one power hub.

    Returns a DataFrame indexed by hour with columns ``spot`` and ``adjusted``.
    """
    power = bundle.get("power_spot_normalized")
    if power is None or getattr(power, "empty", True):
        return pd.DataFrame()

    p = power.copy()
    p["zone"] = p["zone"].astype(str)
    p = p[p["zone"].str.upper() == str(hub).upper()]
    if "frequency" in p.columns:
        p = p[p["frequency"].astype(str).str.upper() == "H"]
    if "currency" in p.columns:
        p = p[p["currency"].astype(str).str.upper() == "EUR"]
    if p.empty:
        return pd.DataFrame()

    p["dt"] = pd.to_datetime(p["valuedate"], utc=True, errors="coerce")
    p = p.dropna(subset=["dt"])
    p = p[["dt", "value"]].rename(columns={"value": "spot"})
    p = p.groupby("dt", as_index=True)["spot"].mean().to_frame()
    p = p.sort_index()
    p["d"] = p.index.tz_convert("UTC").date

    gas_daily = _daily_hub_series(bundle.get("gas_spot_normalized"), "hub", "TTF")
    eua_daily = _daily_hub_series(bundle.get("co2_spot_normalized"), "hub", "EUA")
    if gas_daily.empty or eua_daily.empty:
        return pd.DataFrame()

    p["gas"] = p["d"].map(gas_daily)
    p["eua"] = p["d"].map(eua_daily)
    # Carry the last known fuel spot over weekends / holidays with no print.
    p[["gas", "eua"]] = p[["gas", "eua"]].ffill()

    denom = p["gas"] + CO2_FACTOR * p["eua"]
    heat_rate = p["spot"] / denom

    # Target fuel cost at today's forward settlements.
    if front_ttf is not None and front_dec_eua is not None:
        target = front_ttf + CO2_FACTOR * front_dec_eua
    else:
        # Fallback: re-price at the latest available fuel spot (no adjustment).
        target = denom

    adjustable = (p["spot"] > 0) & (denom > 0) & denom.notna()
    p["adjusted"] = p["spot"].where(~adjustable, heat_rate * target)

    return p[["spot", "adjusted"]]


def _monthly_pivot(hourly: pd.DataFrame) -> pd.DataFrame:
    """Year x Month average of the adjusted price."""
    if hourly is None or hourly.empty:
        return pd.DataFrame()
    df = hourly.copy()
    idx = df.index
    df["Year"] = idx.year
    df["Month"] = idx.month
    monthly = df.groupby(["Year", "Month"])["adjusted"].mean().reset_index()
    pivot = monthly.pivot(index="Year", columns="Month", values="adjusted")
    pivot = pivot.reindex(columns=range(1, 13))
    pivot = pivot.sort_index(ascending=False)
    return pivot


def _daily_frame(hourly: pd.DataFrame) -> pd.DataFrame:
    """Daily-average spot + adjusted, for the chart and Excel export."""
    if hourly is None or hourly.empty:
        return pd.DataFrame(columns=["Date", "Spot", "Adjusted"])
    daily = hourly.copy()
    daily.index = daily.index.tz_convert("UTC")
    daily = daily.resample("D").mean()
    daily = daily.dropna(how="all")
    out = daily.reset_index().rename(
        columns={"dt": "Date", "index": "Date", "spot": "Spot", "adjusted": "Adjusted"}
    )
    out.columns = ["Date", "Spot", "Adjusted"]
    out["Date"] = pd.to_datetime(out["Date"]).dt.strftime("%Y-%m-%d")
    out["Spot"] = out["Spot"].round(2)
    out["Adjusted"] = out["Adjusted"].round(2)
    return out


_TZ_BERLIN = None  # initialised lazily

def _tz_berlin():
    global _TZ_BERLIN
    if _TZ_BERLIN is None:
        from zoneinfo import ZoneInfo
        _TZ_BERLIN = ZoneInfo("Europe/Berlin")
    return _TZ_BERLIN


def _get_full_bundle(app_data: dict) -> dict:
    """
    Return a data bundle that contains the fullest available coverage for
    ``power_spot_normalized``, ``gas_spot_normalized``, ``co2_spot_normalized``.

    Strategy:
    1. Use ``effective_prices_bundle(app_data)`` (already in memory, fastest).
    2. If ``power_spot_normalized`` is empty or very small, fall back to loading
       the full history directly from the S3 cache via the data-loader functions
       (each carries its own 1-hour ``@cached_result`` so repeated calls are fast).
    """
    bundle = effective_prices_bundle(app_data)

    power = bundle.get("power_spot_normalized")
    if power is not None and not getattr(power, "empty", True):
        return bundle  # In-memory bundle is sufficient

    # Fallback: load directly from S3 (cached per process with 1-h TTL)
    logger.info("HRA: power_spot_normalized missing from bundle, loading from S3…")
    try:
        from portal_pages.prices.data_loader import (
            load_power_spot_data,
            load_gas_spot_data,
            load_co2_spot_data,
        )
        _, power_norm = load_power_spot_data()
        _, gas_norm   = load_gas_spot_data()
        _, co2_norm   = load_co2_spot_data()

        out = dict(bundle)
        if power_norm is not None and not power_norm.empty:
            out["power_spot_normalized"] = power_norm
        if gas_norm is not None and not gas_norm.empty:
            out["gas_spot_normalized"] = gas_norm
        if co2_norm is not None and not co2_norm.empty:
            out["co2_spot_normalized"] = co2_norm
        return out
    except Exception as e:
        logger.warning("HRA: S3 fallback load failed: %s", e)
        return bundle


def _filter_power_by_date(bundle: dict, start_date, end_date):
    """
    Narrow ``power_spot_normalized`` in ``bundle`` to the requested window.

    Returns ``(bundle, has_data)``.  Doing this once (instead of inside every
    per-zone computation) keeps the Location-Spreads view fast when several
    neighbouring zones are processed from the same date window.
    """
    power = bundle.get("power_spot_normalized")
    if power is None or getattr(power, "empty", True):
        return bundle, False
    if not (start_date or end_date):
        return bundle, True

    import datetime as _dt_mod
    pf = power.copy()
    pf["_dt"] = pd.to_datetime(pf["valuedate"], utc=True, errors="coerce")
    if start_date:
        pf = pf[pf["_dt"] >= pd.to_datetime(start_date, utc=True)]
    if end_date:
        # Include the full end day (+1 day, then trim later in display).
        pf = pf[pf["_dt"] < (pd.to_datetime(end_date) + timedelta(days=1)).replace(tzinfo=_dt_mod.timezone.utc)]
    pf = pf.drop(columns=["_dt"])
    out = {**bundle, "power_spot_normalized": pf}
    return out, (not pf.empty)


def _compute_hourly_for_range(
    app_data: dict,
    hub: str,
    front_ttf,
    front_dec_eua,
    start_date=None,
    end_date=None,
) -> pd.DataFrame:
    """
    Compute the hourly spot + adjusted DataFrame for the requested hub and
    date range.  Filters the raw ``power_spot_normalized`` to the requested
    window *before* the expensive heat-rate computation so large bundles stay
    fast for narrow date ranges.
    """
    bundle = _get_full_bundle(app_data)
    bundle, ok = _filter_power_by_date(bundle, start_date, end_date)
    if not ok:
        return pd.DataFrame()
    return _compute_hourly(bundle, hub, front_ttf, front_dec_eua)


def _hourly_to_df(hourly: pd.DataFrame, start_date=None, end_date=None) -> pd.DataFrame:
    """
    Convert the hourly UTC index to CET/CEST wall-clock time and apply the
    date-range filter.  Returns a flat DataFrame with columns
    [DateTime (str), Spot, Adjusted].
    """
    if hourly is None or hourly.empty:
        return pd.DataFrame(columns=["DateTime", "Spot", "Adjusted"])

    TZ = _tz_berlin()
    h = hourly.copy()
    h.index = h.index.tz_convert(TZ)

    if start_date:
        h = h[h.index >= pd.to_datetime(start_date).replace(tzinfo=TZ)]
    if end_date:
        # Include through end of the end date in local time.
        end_ts = (pd.to_datetime(end_date) + timedelta(days=1)).replace(tzinfo=TZ)
        h = h[h.index < end_ts]

    if h.empty:
        return pd.DataFrame(columns=["DateTime", "Spot", "Adjusted"])

    h = h.sort_index()
    out = h.reset_index()
    out.columns = ["DateTime", "Spot", "Adjusted"]
    out["DateTime"] = pd.to_datetime(out["DateTime"]).dt.strftime("%Y-%m-%d %H:%M")
    out["Spot"]     = out["Spot"].round(2)
    out["Adjusted"] = out["Adjusted"].round(2)
    return out


# ── Store builder ────────────────────────────────────────────────────────────

def _build_store(bundle, hub) -> dict:
    front_ttf, front_dec_eua, settlement = _get_forward_settlements()
    hourly = _compute_hourly(bundle, hub, front_ttf, front_dec_eua)
    if hourly is None or hourly.empty:
        return {"loaded": False, "hub": hub}

    daily = _daily_frame(hourly)
    pivot = _monthly_pivot(hourly)

    pivot_records = []
    for yr, row in pivot.iterrows():
        rec = {"Year": int(yr)}
        for m in range(1, 13):
            v = row.get(m)
            rec[MONTH_LABELS[m]] = (round(float(v), 1) if pd.notna(v) else None)
        pivot_records.append(rec)

    return {
        "loaded": True,
        "hub": hub,
        "front_ttf": front_ttf,
        "front_dec_eua": front_dec_eua,
        "settlement": settlement,
        "adjusted_to": (
            front_ttf + CO2_FACTOR * front_dec_eua
            if (front_ttf is not None and front_dec_eua is not None) else None
        ),
        "daily": daily.to_dict("records"),
        # Hourly data is NOT stored here — it is computed on-the-fly in the
        # chart callback so there is no size cap and historical S3 data can
        # be fetched transparently when the in-memory bundle is insufficient.
        "monthly": pivot_records,
        "latest_date": daily["Date"].max() if not daily.empty else None,
        "earliest_date": daily["Date"].min() if not daily.empty else None,
    }


# ── Builders (table / chart) ──────────────────────────────────────────────────

def _build_monthly_table(store):
    if not store or not store.get("loaded"):
        return html.Div("No data available for this hub.",
                        className="text-center text-muted my-5")
    records = store.get("monthly", [])
    if not records:
        return html.Div("No monthly data available.",
                        className="text-center text-muted my-5")

    header_bg = APP_COLORS.get("header_bg", "#f2f2f2")
    header_text = APP_COLORS.get("header_text", "#333")
    hl_bg = APP_COLORS.get("highlight_bg", "#e9ecef")
    hl_text = APP_COLORS.get("highlight_text", "#495057")

    # Numeric values for the heat-map shading.
    vals = [
        v for rec in records for k, v in rec.items()
        if k != "Year" and isinstance(v, (int, float))
    ]
    vmin = min(vals) if vals else 0
    vmax = max(vals) if vals else 1

    def shade(v):
        if vmax == vmin:
            return "#ffffff"
        t = (v - vmin) / (vmax - vmin)
        # white -> orange-red (YlOrRd-ish)
        r = 255
        g = int(255 - 150 * t)
        b = int(235 - 235 * t)
        return f"rgb({r},{g},{b})"

    cols = [{"name": "Year", "id": "Year"}] + [
        {"name": MONTH_LABELS[m], "id": MONTH_LABELS[m]} for m in range(1, 13)
    ]

    style_data_conditional = [
        {"if": {"column_id": "Year"}, "fontWeight": "bold",
         "backgroundColor": hl_bg, "color": hl_text},
    ]
    for row_idx, rec in enumerate(records):
        for m in range(1, 13):
            col = MONTH_LABELS[m]
            v = rec.get(col)
            if isinstance(v, (int, float)):
                style_data_conditional.append({
                    "if": {"row_index": row_idx, "column_id": col},
                    "backgroundColor": shade(v),
                })

    data = [
        {k: ("" if v is None else v) for k, v in rec.items()}
        for rec in records
    ]

    return dash_table.DataTable(
        columns=cols,
        data=data,
        style_table={"overflowX": "auto", "border": "1px solid #e0e0e0",
                     "borderRadius": "5px"},
        style_cell={"textAlign": "center", "padding": "10px 8px",
                    "fontFamily": "Arial, sans-serif", "fontSize": "13px",
                    "minWidth": "60px"},
        style_header={"backgroundColor": header_bg, "color": header_text,
                      "fontWeight": "bold"},
        style_data_conditional=style_data_conditional,
    )


def _no_data_message(store, resolution):
    """Return a helpful 'no data' Div that shows the available date window."""
    earliest = store.get("earliest_date") if store else None
    latest = store.get("latest_date") if store else None

    def _fmt(d):
        try:
            return pd.to_datetime(d).strftime("%d %b %Y")
        except Exception:
            return str(d)

    if earliest and latest:
        window_msg = (
            f"Available data runs from {_fmt(earliest)} to {_fmt(latest)}. "
            "Adjust the date range to fall within this window."
        )
    else:
        window_msg = "No data loaded yet — try refreshing the page."

    return html.Div([
        html.P("No data in the selected date range.",
               className="text-center text-muted mb-1",
               style={"fontWeight": "600"}),
        html.P(window_msg,
               className="text-center text-muted",
               style={"fontSize": "12px"}),
    ], style={"padding": "40px 0"})


def _make_figure(hub, df, date_col, use_hourly):
    """Shared Plotly figure builder for daily and hourly charts."""
    line_shape = "hv" if use_hourly else "linear"
    res_label  = "hourly (CET/CEST)" if use_hourly else "daily avg"
    lw = 1.5 if use_hourly else 2

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df[date_col], y=df["Spot"], mode="lines", name="Spot",
        line=dict(width=lw, color=APP_COLORS.get("BASE_COLOR", "#4a9eff"), shape=line_shape),
        hovertemplate="Spot: %{y:.1f} EUR/MWh<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=df[date_col], y=df["Adjusted"], mode="lines", name="Adjusted",
        line=dict(width=lw, color=APP_COLORS.get("PEAK_COLOR", "#ff6b6b"), shape=line_shape),
        hovertemplate="Adjusted: %{y:.1f} EUR/MWh<extra></extra>",
    ))
    fig.update_layout(
        title=f"{hub} — Spot vs Heat-Rate-Adjusted Power Price ({res_label})",
        xaxis_title="Delivery time (CET/CEST)" if use_hourly else "Delivery day",
        yaxis_title="Price (EUR/MWh)",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        template="seaborn",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    if use_hourly:
        fig.update_xaxes(tickformat="%d %b %H:%M")
    return dcc.Graph(figure=fig, style={"height": "60vh"},
                     config={"scrollZoom": True, "displayModeBar": True})


def _build_daily_chart(store, start_date, end_date):
    """Build the daily-average chart from pre-computed store data."""
    if not store or not store.get("loaded"):
        return html.Div("No data available for this hub.",
                        className="text-center text-muted my-5")
    records = store.get("daily", [])
    if not records:
        return _no_data_message(store, "daily")

    df = pd.DataFrame(records)
    df["DateTs"] = pd.to_datetime(df["Date"])
    if start_date:
        df = df[df["DateTs"] >= pd.to_datetime(start_date)]
    if end_date:
        df = df[df["DateTs"] <= pd.to_datetime(end_date)]
    if df.empty:
        return _no_data_message(store, "daily")

    return _make_figure(store.get("hub", ""), df.sort_values("DateTs"), "DateTs", False)


def _build_hourly_chart(store, start_date, end_date, app_data):
    """
    Build the hourly chart, computing on-the-fly for the requested window.
    Falls back to the S3 loader when the in-memory bundle is insufficient.
    """
    if not store or not store.get("loaded"):
        return html.Div("No data available for this hub.",
                        className="text-center text-muted my-5")

    hub        = store.get("hub", DEFAULT_HUB)
    front_ttf  = store.get("front_ttf")
    front_dec  = store.get("front_dec_eua")

    try:
        hourly = _compute_hourly_for_range(
            app_data, hub, front_ttf, front_dec, start_date, end_date
        )
    except Exception as e:
        logger.exception("HRA hourly computation failed: %s", e)
        return html.Div(f"Error computing hourly data: {e}",
                        className="text-center text-muted my-5")

    if hourly is None or hourly.empty:
        return _no_data_message(store, "hourly")

    df = _hourly_to_df(hourly, start_date, end_date)
    if df.empty:
        return _no_data_message(store, "hourly")

    df["DateTs"] = pd.to_datetime(df["DateTime"], errors="coerce")

    # Warn if > 90 days selected — chart will be heavy but still works.
    n_days = (df["DateTs"].max() - df["DateTs"].min()).days if len(df) > 1 else 0
    children = [_make_figure(hub, df.sort_values("DateTs"), "DateTs", True)]
    if n_days > 90:
        children.insert(0, dbc.Alert(
            f"Showing {n_days} days of hourly data ({len(df):,} hours). "
            "For faster rendering consider switching to Daily.",
            color="info", className="mx-0 mb-3", style={"fontSize": "12px"},
        ))
    return html.Div(children)


# ── Location spreads ──────────────────────────────────────────────────────────

def _zone_adjusted_frame(bundle, zone, ttf, eua, start_date, end_date, use_hourly):
    """
    Adjusted + spot series for a single zone from an already date-filtered
    bundle.  Returns a DataFrame with columns [key, Spot, Adjusted] where
    ``key`` is a date ('YYYY-MM-DD') or hour ('YYYY-MM-DD HH:MM') string.
    """
    hourly = _compute_hourly(bundle, zone, ttf, eua)
    if hourly is None or hourly.empty:
        return None
    if use_hourly:
        d = _hourly_to_df(hourly, start_date, end_date)
        if d.empty:
            return None
        d = d.rename(columns={"DateTime": "key"})
    else:
        d = _daily_frame(hourly)
        if d.empty:
            return None
        d = d.rename(columns={"Date": "key"})
    return d[["key", "Spot", "Adjusted"]]


def _period_to_month(period) -> int | None:
    """Parse dashboard period labels such as Jan, JAN-26, or 1 into a month."""
    if pd.isna(period):
        return None
    text = str(period).strip().upper()
    if not text:
        return None
    prefix = text[:3]
    if prefix in MONTH_NUM_BY_LABEL:
        return MONTH_NUM_BY_LABEL[prefix]
    try:
        num = int(text)
        return num if 1 <= num <= 12 else None
    except Exception:
        return None


def _period_to_months(period, tenor=None) -> tuple[list[int], int] | tuple[None, None]:
    """
    Expand an XB forward period into delivery months.

    Returns ``(months, priority)`` where lower priority wins when several
    products cover the same month:
      0 = explicit monthly, 1 = quarterly, 2 = Cal/yearly.
    """
    text = "" if pd.isna(period) else str(period).strip().upper()
    tenor_text = "" if pd.isna(tenor) else str(tenor).strip().upper()

    month = _period_to_month(text)
    if month is not None and not text.startswith("Q"):
        return [month], 0

    q_num = None
    if text.startswith("Q") and len(text) >= 2 and text[1].isdigit():
        q_num = int(text[1])
    elif "QUART" in tenor_text and text and text[0].isdigit():
        q_num = int(text[0])
    if q_num in (1, 2, 3, 4):
        start = (q_num - 1) * 3 + 1
        return [start, start + 1, start + 2], 1

    is_year = (
        text.startswith("CAL")
        or "YEAR" in tenor_text
        or "ANNUAL" in tenor_text
        or tenor_text == "CAL"
    )
    if is_year:
        return list(range(1, 13)), 2

    return None, None


def _forward_location_spread_lookup(bundle, home, neighbors) -> dict:
    """
    Latest unadjusted forward power spread by border/month.

    Uses the existing XB spread bundle.  Returns:
        {"FR": {"2026-07": -4.2, ...}, ...}
    Values are oriented as ``home - border``; reversed spread rows are negated.
    """
    combined = (bundle or {}).get("combined_spreads")
    if combined is None or getattr(combined, "empty", True):
        return {}

    required = {"SPREAD_TYPE", "period", "year", "SETTLEMENT_PRICE_spread"}
    if not required.issubset(set(combined.columns)):
        return {}

    df = combined.copy()
    if "tenor" not in df.columns:
        df["tenor"] = ""
    if "PROFILE" in df.columns:
        df = df[df["PROFILE"].astype(str).str.upper() == "BASE"]
    if df.empty:
        return {}

    expanded = []
    for _, row in df.iterrows():
        months, priority = _period_to_months(row.get("period"), row.get("tenor"))
        if not months:
            continue
        for month in months:
            rec = row.to_dict()
            rec["Month"] = month
            rec["ContractPriority"] = priority
            expanded.append(rec)
    if not expanded:
        return {}

    df = pd.DataFrame(expanded)
    df["Year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    df["SpreadValue"] = pd.to_numeric(df["SETTLEMENT_PRICE_spread"], errors="coerce")
    df = df.dropna(subset=["Month", "Year", "SpreadValue", "ContractPriority"])
    if df.empty:
        return {}

    today = pd.Timestamp.today().normalize()
    current_month = pd.Timestamp(year=today.year, month=today.month, day=1)

    out = {}
    spread_u = df["SPREAD_TYPE"].astype(str).str.upper()
    for brd in neighbors:
        direct = f"{home}-{brd}".upper()
        reverse = f"{brd}-{home}".upper()

        sign = 1.0
        sub = df[spread_u == direct].copy()
        if sub.empty:
            sub = df[spread_u == reverse].copy()
            sign = -1.0
        if sub.empty:
            continue

        sub["DeliveryMonth"] = pd.to_datetime(
            {
                "year": sub["Year"].astype(int),
                "month": sub["Month"].astype(int),
                "day": 1,
            },
            errors="coerce",
        )
        sub = sub[sub["DeliveryMonth"] >= current_month]
        if sub.empty:
            continue

        if "DAYS_TO_DELIVERY" in sub.columns:
            sub["DAYS_TO_DELIVERY"] = pd.to_numeric(sub["DAYS_TO_DELIVERY"], errors="coerce")
            non_negative = sub[sub["DAYS_TO_DELIVERY"] >= 0]
            if not non_negative.empty:
                sub = non_negative
            sub = sub.sort_values(["Year", "Month", "ContractPriority", "DAYS_TO_DELIVERY"],
                                  ascending=[True, True, True, True])
        else:
            sub = sub.sort_values(["Year", "Month", "ContractPriority"])

        latest = sub.groupby(["Year", "Month"], as_index=False).first()
        border_map = {}
        for _, row in latest.iterrows():
            ym = f"{int(row['Year']):04d}-{int(row['Month']):02d}"
            border_map[ym] = round(float(row["SpreadValue"]) * sign, 2)
        if border_map:
            out[brd] = border_map

    return out


def _compute_location_spreads(
    app_data, home, neighbors, zone_fuels, start_date, end_date, use_hourly
):
    """
    Compute adjusted & spot location spreads (home − neighbour) for each border.

    ``zone_fuels`` maps a zone -> (ttf, eua).  Returns a dict::

        {
          "home": home, "use_hourly": bool,
          "borders": [b1, b2, ...],          # borders that yielded data
          "series": {border: [ {key, spot_spread, adj_spread}, ... ]},
          "summary": [ {Border, AvgSpot, AvgAdj, LatestAdj, Diff}, ... ],
          "monthly": [ {Period, <border>: adj_spread, ...}, ... ],
          "forward_monthly": {border: {"YYYY-MM": forward_spread, ...}},
        }

    or ``None`` when home data is unavailable.
    """
    bundle = _get_full_bundle(app_data)
    bundle, ok = _filter_power_by_date(bundle, start_date, end_date)
    if not ok:
        return None

    forward_monthly = _forward_location_spread_lookup(bundle, home, neighbors)

    home_ttf, home_eua = zone_fuels.get(home, (None, None))
    home_df = _zone_adjusted_frame(
        bundle, home, home_ttf, home_eua, start_date, end_date, use_hourly
    )
    if home_df is None or home_df.empty:
        return None
    home_df = home_df.rename(columns={"Spot": "spot_home", "Adjusted": "adj_home"})

    series, summary, borders_ok = {}, [], []
    monthly_frames = []

    for brd in neighbors:
        b_ttf, b_eua = zone_fuels.get(brd, (None, None))
        b_df = _zone_adjusted_frame(
            bundle, brd, b_ttf, b_eua, start_date, end_date, use_hourly
        )
        if b_df is None or b_df.empty:
            continue
        b_df = b_df.rename(columns={"Spot": "spot_brd", "Adjusted": "adj_brd"})
        m = home_df.merge(b_df, on="key", how="inner")
        if m.empty:
            continue

        m["spot_spread"] = (m["spot_home"] - m["spot_brd"]).round(2)
        m["adj_spread"] = (m["adj_home"] - m["adj_brd"]).round(2)
        m = m.sort_values("key")

        borders_ok.append(brd)
        series[brd] = m[["key", "spot_spread", "adj_spread"]].to_dict("records")

        avg_spot = float(m["spot_spread"].mean())
        avg_adj = float(m["adj_spread"].mean())
        latest_adj = float(m["adj_spread"].iloc[-1])
        summary.append({
            "Border": f"{home}–{brd}",
            "Avg Spot Spread": round(avg_spot, 2),
            "Avg Adj Spread": round(avg_adj, 2),
            "Latest Adj Spread": round(latest_adj, 2),
            "Adj − Spot": round(avg_adj - avg_spot, 2),
        })

        mf = m[["key", "adj_spread"]].copy()
        mf["Period"] = mf["key"].str.slice(0, 7)
        mf = mf.groupby("Period")["adj_spread"].mean().round(2).rename(brd)
        monthly_frames.append(mf)

    if not borders_ok:
        return None

    # Monthly pivot: rows = period (YYYY-MM), one column per border.
    monthly_records = []
    if monthly_frames:
        mtable = pd.concat(monthly_frames, axis=1).sort_index(ascending=False)
        for period, row in mtable.iterrows():
            rec = {"Period": period}
            for brd in borders_ok:
                v = row.get(brd)
                rec[brd] = (round(float(v), 1) if pd.notna(v) else None)
            monthly_records.append(rec)

    return {
        "home": home,
        "use_hourly": use_hourly,
        "borders": borders_ok,
        "series": series,
        "summary": summary,
        "monthly": monthly_records,
        "forward_monthly": forward_monthly,
    }


_SPREAD_PALETTE = [
    "#4a9eff", "#ff6b6b", "#2ecc71", "#f39c12", "#9b59b6",
    "#1abc9c", "#e74c3c", "#34495e", "#e67e22", "#16a085",
]


def _build_spread_chart(result, metric):
    """Multi-line time-series of location spreads (one trace per border)."""
    if not result or not result.get("borders"):
        return html.Div("No spread data for this selection.",
                        className="text-center text-muted my-5")

    home = result["home"]
    use_hourly = result.get("use_hourly", False)
    line_shape = "hv" if use_hourly else "linear"

    fig = go.Figure()
    for i, brd in enumerate(result["borders"]):
        recs = result["series"].get(brd, [])
        if not recs:
            continue
        df = pd.DataFrame(recs)
        df["x"] = pd.to_datetime(df["key"], errors="coerce")
        color = _SPREAD_PALETTE[i % len(_SPREAD_PALETTE)]
        if metric in ("adjusted", "both"):
            fig.add_trace(go.Scatter(
                x=df["x"], y=df["adj_spread"], mode="lines",
                name=f"{home}–{brd} (adj)",
                line=dict(width=2, color=color, shape=line_shape),
                hovertemplate=f"{home}–{brd} adj: " + "%{y:.1f}<extra></extra>",
            ))
        if metric in ("spot", "both"):
            fig.add_trace(go.Scatter(
                x=df["x"], y=df["spot_spread"], mode="lines",
                name=f"{home}–{brd} (spot)",
                line=dict(width=1.3, color=color, shape=line_shape,
                          dash="dot" if metric == "both" else "solid"),
                hovertemplate=f"{home}–{brd} spot: " + "%{y:.1f}<extra></extra>",
            ))

    fig.add_hline(y=0, line_width=1, line_dash="dash", line_color="#999")
    title_metric = {"adjusted": "Adjusted", "spot": "Spot", "both": "Spot vs Adjusted"}.get(metric, "Adjusted")
    fig.update_layout(
        title=f"{home} Location Spreads — {title_metric} ({'hourly' if use_hourly else 'daily avg'})",
        xaxis_title="Delivery time (CET/CEST)" if use_hourly else "Delivery day",
        yaxis_title="Spread (EUR/MWh)",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
        template="seaborn",
        margin=dict(l=40, r=40, t=70, b=40),
    )
    if use_hourly:
        fig.update_xaxes(tickformat="%d %b %H:%M")
    return dcc.Graph(figure=fig, style={"height": "60vh"},
                     config={"scrollZoom": True, "displayModeBar": True})


def _build_spread_summary_table(result):
    """Per-border summary of average / latest spreads."""
    if not result or not result.get("summary"):
        return html.Div("No data.", className="text-center text-muted my-4")
    records = result["summary"]
    cols = ["Border", "Avg Spot Spread", "Avg Adj Spread", "Latest Adj Spread", "Adj − Spot"]
    return dash_table.DataTable(
        columns=[{"name": c, "id": c} for c in cols],
        data=records,
        style_table={"overflowX": "auto", "border": "1px solid #e0e0e0",
                     "borderRadius": "5px"},
        style_cell={"textAlign": "center", "padding": "9px 8px",
                    "fontFamily": "Arial, sans-serif", "fontSize": "13px",
                    "minWidth": "90px"},
        style_header={"backgroundColor": APP_COLORS.get("header_bg", "#f2f2f2"),
                      "color": APP_COLORS.get("header_text", "#333"),
                      "fontWeight": "bold"},
        style_data_conditional=[
            {"if": {"column_id": "Border"}, "fontWeight": "bold",
             "backgroundColor": APP_COLORS.get("highlight_bg", "#e9ecef")},
            {"if": {"filter_query": "{Avg Adj Spread} > 0", "column_id": "Avg Adj Spread"},
             "color": "#1a7a3c"},
            {"if": {"filter_query": "{Avg Adj Spread} < 0", "column_id": "Avg Adj Spread"},
             "color": "#c0392b"},
        ],
    )


def _spread_month_year_records(result, border):
    """
    Month x year table records for one border.

    Historical cells use heat-rate-adjusted location spread. Current/future
    cells use the unadjusted forward power spread when available, matching the
    convention in location_spread_report.py.
    """
    recs = (result.get("series") or {}).get(border, [])
    hist_values = {}
    if recs:
        df = pd.DataFrame(recs)
        df["ts"] = pd.to_datetime(df["key"], errors="coerce")
        df = df.dropna(subset=["ts"])
        if not df.empty:
            df["Year"] = df["ts"].dt.year
            df["Month"] = df["ts"].dt.month
            monthly = df.groupby(["Year", "Month"])["adj_spread"].mean().reset_index()
            hist_values = {
                (int(row["Year"]), int(row["Month"])): round(float(row["adj_spread"]), 1)
                for _, row in monthly.iterrows()
                if pd.notna(row["adj_spread"])
            }

    fwd_values = {}
    for ym, value in ((result.get("forward_monthly") or {}).get(border) or {}).items():
        try:
            ts = pd.to_datetime(f"{ym}-01")
            fwd_values[(int(ts.year), int(ts.month))] = round(float(value), 1)
        except Exception:
            continue

    years = sorted({y for y, _ in hist_values.keys()} | {y for y, _ in fwd_values.keys()})
    if not years:
        return [], [], []

    future_cells = []
    records = []
    for m in range(1, 13):
        out = {"Month": MONTH_LABELS[m]}
        vals = []
        row_idx = len(records)
        for yr in years:
            col = str(yr)
            key = (yr, m)
            if key in fwd_values:
                value = fwd_values[key]
                future_cells.append((row_idx, col))
            else:
                value = hist_values.get(key)
            if value is not None:
                vals.append(value)
                out[col] = value
            else:
                out[col] = None
        records.append(out)

    avg = {"Month": "Avg"}
    avg_row_idx = len(records)
    for yr in years:
        col = str(yr)
        vals = [
            records[m - 1].get(col)
            for m in range(1, 13)
            if isinstance(records[m - 1].get(col), (int, float))
        ]
        avg[col] = round(float(pd.Series(vals).mean()), 1) if vals else None
        if any((yr, m) in fwd_values for m in range(1, 13)):
            future_cells.append((avg_row_idx, col))
    records.append(avg)

    return records, [str(y) for y in years], future_cells


def _build_single_spread_heatmap(result, border):
    """One location-spread heatmap table: y=month, x=year."""
    home = result.get("home", "")
    title = f"{home} - {border}"
    records, years, future_cells = _spread_month_year_records(result, border)
    if not records:
        return html.Div([
            html.H6(title, style={"fontSize": "13px", "fontWeight": "700",
                                  "color": "#333", "marginBottom": "8px"}),
            html.Div("No monthly data.", className="text-center text-muted py-4"),
        ], style={"backgroundColor": "#fff", "border": "1px solid #e0e0e0",
                  "borderRadius": "6px", "padding": "12px"})

    vals = [v for rec in records for k, v in rec.items()
            if k != "Month" and isinstance(v, (int, float))]
    vmax_abs = max((abs(v) for v in vals), default=1) or 1

    def shade(v):
        # Diverging red/green scale: positive = home above border, negative = below.
        t = max(-1.0, min(1.0, v / vmax_abs))
        if t >= 0:
            r = int(250 - 95 * t)
            g = int(250 - 35 * t)
            b = int(250 - 115 * t)
        else:
            r = int(250 - 10 * t)
            g = int(250 + 115 * t)
            b = int(250 + 115 * t)
        return f"rgb({r},{g},{b})"

    cols = [{"name": "Month", "id": "Month"}] + [{"name": y, "id": y} for y in years]

    style_data_conditional = [
        {"if": {"column_id": "Month"}, "fontWeight": "bold",
         "backgroundColor": APP_COLORS.get("highlight_bg", "#e9ecef"),
         "color": APP_COLORS.get("highlight_text", "#495057")},
        {"if": {"filter_query": "{Month} = 'Avg'"}, "fontWeight": "bold",
         "borderTop": "2px solid #999"},
    ]
    for row_idx, rec in enumerate(records):
        for col in years:
            v = rec.get(col)
            if isinstance(v, (int, float)):
                style_data_conditional.append({
                    "if": {"row_index": row_idx, "column_id": col},
                    "backgroundColor": shade(v),
                })
    for row_idx, col in future_cells:
        style_data_conditional.append({
            "if": {"row_index": row_idx, "column_id": col},
            "border": "2px solid #111",
        })

    data = [{k: ("" if v is None else v) for k, v in rec.items()} for rec in records]
    table = dash_table.DataTable(
        columns=cols,
        data=data,
        style_table={"overflowX": "auto"},
        style_cell={"textAlign": "center", "padding": "7px 8px",
                    "fontFamily": "Arial, sans-serif", "fontSize": "12px",
                    "minWidth": "58px"},
        style_header={"backgroundColor": APP_COLORS.get("header_bg", "#f2f2f2"),
                      "color": APP_COLORS.get("header_text", "#333"),
                      "fontWeight": "bold"},
        style_data_conditional=style_data_conditional,
    )
    return html.Div([
        html.Div([
            html.H6(title, style={"fontSize": "13px", "fontWeight": "700",
                                  "color": "#333", "marginBottom": "0"}),
            html.Span("Black border = forward spread", style={
                "fontSize": "11px", "color": "#777", "marginLeft": "8px",
            }),
        ], style={"display": "flex", "alignItems": "baseline",
                  "justifyContent": "space-between", "marginBottom": "8px"}),
        table,
    ], style={"backgroundColor": "#fff", "border": "1px solid #e0e0e0",
              "borderRadius": "6px", "padding": "12px",
              "boxShadow": "0 1px 2px rgba(0,0,0,0.03)"})


def _build_spread_monthly_table(result):
    """Responsive grid of per-border Year x Month adjusted-spread heatmaps."""
    if not result or not result.get("borders"):
        return html.Div("No monthly data.", className="text-center text-muted my-4")

    cards = [_build_single_spread_heatmap(result, border) for border in result["borders"]]
    return html.Div(cards, style={
        "display": "grid",
        "gridTemplateColumns": "repeat(auto-fit, minmax(560px, 1fr))",
        "gap": "16px",
        "alignItems": "start",
    })


def _build_adjust_panel(country, ttf_default, eua_default):
    """Per-zone editable forward-fuel inputs (home + each border)."""
    zones = [country] + _neighbors(country)

    cell = {"fontSize": "12px", "fontWeight": "600", "color": "#666",
            "textTransform": "uppercase", "letterSpacing": "0.4px"}
    head = html.Div([
        html.Div("Zone", style={**cell, "flex": "0 0 140px"}),
        html.Div("Front TTF (EUR/MWh)", style={**cell, "flex": "0 0 180px"}),
        html.Div("Front Dec EUA (EUR/t)", style={**cell, "flex": "0 0 180px"}),
    ], style={"display": "flex", "gap": "12px", "alignItems": "center",
              "padding": "6px 0", "borderBottom": "1px solid #eee"})

    rows = [head]
    for z in zones:
        is_home = (z == country)
        label = html.Div([
            html.Span(z, style={"fontWeight": "700" if is_home else "500",
                                "fontSize": "13px", "color": "#333"}),
            html.Span(" home" if is_home else "", style={
                "marginLeft": "6px", "fontSize": "10px", "color": "#fff",
                "backgroundColor": "#2c3e50", "padding": "1px 6px",
                "borderRadius": "8px"} if is_home else {"display": "none"}),
        ], style={"flex": "0 0 140px"})
        rows.append(html.Div([
            label,
            dcc.Input(id={"type": "lsp-ttf", "index": z}, type="number",
                      value=ttf_default, debounce=True, step=0.1,
                      style={"flex": "0 0 180px", "fontSize": "13px", "padding": "4px 8px",
                             "border": "1px solid #ccc", "borderRadius": "4px"}),
            dcc.Input(id={"type": "lsp-eua", "index": z}, type="number",
                      value=eua_default, debounce=True, step=0.1,
                      style={"flex": "0 0 180px", "fontSize": "13px", "padding": "4px 8px",
                             "border": "1px solid #ccc", "borderRadius": "4px"}),
        ], style={"display": "flex", "gap": "12px", "alignItems": "center", "padding": "6px 0"}))

    return html.Div(rows)


# ── Layout ────────────────────────────────────────────────────────────────────

def _location_spread_layout(label_style, panel_style, today, default_start):
    """The Location Spreads tab content."""
    return html.Div([
        # Controls
        html.Div([
            html.Div([
                html.Label("Country (home)", style=label_style),
                dcc.Dropdown(
                    id="lsp-country",
                    options=[{"label": h, "value": h} for h in PREFERRED_HUBS],
                    value=DEFAULT_HUB, clearable=False,
                    style={"width": "180px", "fontSize": "13px"},
                ),
            ]),
            html.Div([
                html.Label("Resolution", style=label_style),
                dbc.RadioItems(
                    id="lsp-resolution",
                    options=[{"label": "Daily", "value": "daily"},
                             {"label": "Hourly", "value": "hourly"}],
                    value="daily", inline=True, style={"fontSize": "13px"},
                ),
            ]),
            html.Div([
                html.Label("Graph metric", style=label_style),
                dbc.RadioItems(
                    id="lsp-metric",
                    options=[{"label": "Adjusted", "value": "adjusted"},
                             {"label": "Spot", "value": "spot"},
                             {"label": "Both", "value": "both"}],
                    value="adjusted", inline=True, style={"fontSize": "13px"},
                ),
            ]),
            html.Div([
                html.Label("Date Range", style=label_style),
                html.Div([
                    dcc.DatePickerRange(
                        id="lsp-date-range",
                        start_date=default_start, end_date=today,
                        display_format="DD-MMM-YYYY",
                        style={"fontSize": "13px"},
                    ),
                    html.Div([
                        html.Button("3M",  id="lsp-quick-3m",  n_clicks=0, className="btn btn-sm btn-outline-secondary", style={"fontSize": "11px", "padding": "2px 8px"}),
                        html.Button("6M",  id="lsp-quick-6m",  n_clicks=0, className="btn btn-sm btn-outline-secondary", style={"fontSize": "11px", "padding": "2px 8px"}),
                        html.Button("12M", id="lsp-quick-12m", n_clicks=0, className="btn btn-sm btn-outline-secondary", style={"fontSize": "11px", "padding": "2px 8px"}),
                        html.Button("All", id="lsp-quick-all", n_clicks=0, className="btn btn-sm btn-outline-secondary", style={"fontSize": "11px", "padding": "2px 8px"}),
                    ], style={"display": "flex", "gap": "4px", "marginTop": "6px"}),
                ]),
            ]),
        ], style={
            "padding": "16px 30px", "borderBottom": "1px solid #e5e5e5",
            "display": "flex", "alignItems": "flex-end", "flexWrap": "wrap", "gap": "24px",
        }),

        # Per-zone fuel adjustment panel
        html.Div([
            html.Div([
                html.H5("Per-zone forward fuel adjustment",
                        style={"fontSize": "15px", "fontWeight": "600",
                               "color": "#333", "marginBottom": "4px"}),
                html.Span(id="lsp-defaults-note",
                          style={"fontSize": "12px", "color": "#888"}),
            ], style={"display": "flex", "justifyContent": "space-between",
                      "alignItems": "baseline", "marginBottom": "12px"}),
            html.P("Set the front-month TTF (EUR/MWh) and front-Dec EUA (EUR/t) used to "
                   "re-price each zone. Defaults to the latest market settlement; edit any "
                   "cell to model a different forward, then press Compute.",
                   style={"fontSize": "12px", "color": "#888", "marginBottom": "14px"}),
            dbc.Spinner(
                html.Div(id="lsp-adjust-panel"),
                color="primary", type="border",
            ),
            html.Div([
                dbc.Button("Compute spreads", id="lsp-compute-btn", color="primary",
                           size="sm", style={"fontSize": "13px", "marginRight": "8px"}),
                dbc.Button("Reset to market", id="lsp-reset-btn", color="secondary",
                           size="sm", outline=True, style={"fontSize": "13px", "marginRight": "8px"}),
                dbc.Button("⬇ Excel", id="lsp-download-btn", color="primary",
                           size="sm", outline=True, style={"fontSize": "13px"}),
            ], style={"marginTop": "14px"}),
        ], style=panel_style),

        # Monthly table panel
        html.Div([
            html.H5("Monthly Location Spread Heatmaps (EUR/MWh)",
                    style={"fontSize": "15px", "fontWeight": "600",
                           "color": "#333", "marginBottom": "6px"}),
            html.P("One heatmap per border, with rows = month and columns = year. "
                   "Historical cells use adjusted spread; black-bordered future cells "
                   "use unadjusted forward spread. Green = home above border, red = below.",
                   style={"fontSize": "12px", "color": "#888", "marginBottom": "14px"}),
            dbc.Spinner(
                html.Div(id="lsp-monthly-container"),
                color="primary", type="border",
            ),
        ], style=panel_style),

        # Chart panel
        html.Div([
            html.H5("Location Spreads — Time Series",
                    style={"fontSize": "15px", "fontWeight": "600",
                           "color": "#333", "marginBottom": "4px"}),
            dbc.Spinner(
                html.Div(id="lsp-chart-container"),
                color="primary", type="border",
            ),
        ], style=panel_style),
    ])


def get_layout(data):
    label_style = {
        "fontSize": "11px", "fontWeight": "600", "color": "#666",
        "marginBottom": "5px", "display": "block",
        "textTransform": "uppercase", "letterSpacing": "0.5px",
    }
    panel_style = {
        "padding": "24px 30px", "backgroundColor": "#fff",
        "margin": "16px 30px", "borderRadius": "6px",
        "boxShadow": "0 1px 3px rgba(0,0,0,0.05)",
    }

    today = date.today()
    default_start = date(2021, 1, 1)

    return html.Div([
        dcc.Store(id="hra-store", data=None),
        dcc.Store(id="lsp-store", data=None),
        dcc.Interval(id="hra-load-trigger", interval=500, n_intervals=0, max_intervals=1),
        dcc.Download(id="hra-download"),
        dcc.Download(id="lsp-download"),

        # Header / breadcrumb
        html.Div([
            html.Div([
                html.Span("Price Dashboard", style={"color": "#888", "fontSize": "13px"}),
                html.Span(" / ", style={"color": "#666", "margin": "0 6px", "fontSize": "13px"}),
                html.Span("Heat Rate Adjustment",
                          style={"color": "#333", "fontSize": "13px", "fontWeight": "600"}),
            ]),
            html.Span("", id="hra-settlement-note",
                      style={"fontSize": "12px", "color": "#888"}),
        ], style={
            "padding": "16px 30px", "borderBottom": "1px solid #e5e5e5",
            "display": "flex", "alignItems": "center", "justifyContent": "space-between",
        }),

        dbc.Tabs(id="hra-view-tabs", active_tab="single",
                 style={"padding": "8px 30px 0 30px", "backgroundColor": "#fff"},
                 children=[
            dbc.Tab(label="Single Hub", tab_id="single", children=html.Div([

        # Controls
        html.Div([
            html.Div([
                html.Label("Hub", style=label_style),
                dcc.Dropdown(
                    id="hra-hub",
                    options=[{"label": h, "value": h} for h in PREFERRED_HUBS],
                    value=DEFAULT_HUB, clearable=False,
                    style={"width": "180px", "fontSize": "13px"},
                ),
            ]),
            html.Div([
                html.Label("Resolution", style=label_style),
                dbc.RadioItems(
                    id="hra-resolution",
                    options=[
                        {"label": "Daily", "value": "daily"},
                        {"label": "Hourly", "value": "hourly"},
                    ],
                    value="daily",
                    inline=True,
                    style={"fontSize": "13px"},
                ),
            ]),
            html.Div([
                html.Label("Date Range (time series)", style=label_style),
                html.Div([
                    dcc.DatePickerRange(
                        id="hra-date-range",
                        start_date=default_start,
                        end_date=today,
                        display_format="DD-MMM-YYYY",
                        style={"fontSize": "13px"},
                    ),
                    html.Div([
                        html.Button("3M",  id="hra-quick-3m",  n_clicks=0, className="btn btn-sm btn-outline-secondary",
                                    style={"fontSize": "11px", "padding": "2px 8px"}),
                        html.Button("6M",  id="hra-quick-6m",  n_clicks=0, className="btn btn-sm btn-outline-secondary",
                                    style={"fontSize": "11px", "padding": "2px 8px"}),
                        html.Button("12M", id="hra-quick-12m", n_clicks=0, className="btn btn-sm btn-outline-secondary",
                                    style={"fontSize": "11px", "padding": "2px 8px"}),
                        html.Button("All", id="hra-quick-all", n_clicks=0, className="btn btn-sm btn-outline-secondary",
                                    style={"fontSize": "11px", "padding": "2px 8px"}),
                    ], style={"display": "flex", "gap": "4px", "marginTop": "6px"}),
                ]),
            ]),
            html.Div([
                html.Label("Download", style=label_style),
                dbc.Button("⬇ Excel", id="hra-download-btn", color="primary",
                           size="sm", outline=True, style={"fontSize": "13px"}),
            ]),
        ], style={
            "padding": "16px 30px", "borderBottom": "1px solid #e5e5e5",
            "display": "flex", "alignItems": "flex-end", "flexWrap": "wrap", "gap": "24px",
        }),

        # Monthly table panel
        html.Div([
            html.H5("Monthly Adjusted Power Price (EUR/MWh)",
                    style={"fontSize": "15px", "fontWeight": "600",
                           "color": "#333", "marginBottom": "6px"}),
            html.P("Each hour re-priced to the latest front-month TTF and front-December "
                   "EUA settlement, then averaged by month.",
                   style={"fontSize": "12px", "color": "#888", "marginBottom": "14px"}),
            dbc.Spinner(
                html.Div(id="hra-table-container",
                         children=html.P("Loading…", className="text-center text-muted my-5")),
                color="primary", type="border",
            ),
        ], style=panel_style),

        # Time-series panel
        html.Div([
            html.H5("Spot vs Adjusted — Time Series",
                    style={"fontSize": "15px", "fontWeight": "600",
                           "color": "#333", "marginBottom": "4px"}),
            html.P(
                id="hra-chart-note",
                style={"fontSize": "12px", "color": "#888", "marginBottom": "14px"},
            ),
            dbc.Spinner(
                html.Div(id="hra-chart-container",
                         children=html.P("Loading…", className="text-center text-muted my-5")),
                color="primary", type="border",
            ),
        ], style=panel_style),

            ])),  # end Single Hub tab

            dbc.Tab(label="Location Spreads", tab_id="spreads",
                    children=_location_spread_layout(label_style, panel_style, today, default_start)),
        ]),

    ], style={"backgroundColor": "#f5f6f8", "minHeight": "100vh"})


# ── Callbacks ─────────────────────────────────────────────────────────────────

def register_heatrate_adjustment_callbacks(app, data):
    """Register all Heat Rate Adjustment callbacks. ``data`` is the shared price bundle."""
    app_data = data

    @app.callback(
        [Output("hra-store", "data"),
         Output("hra-settlement-note", "children")],
        [Input("hra-load-trigger", "n_intervals"),
         Input("hra-hub", "value")],
        prevent_initial_call=False,
    )
    def load_store(_n, hub):
        hub = hub or DEFAULT_HUB
        try:
            bundle = effective_prices_bundle(app_data)
            store = _build_store(bundle, hub)
        except Exception as e:
            logger.exception("Heat-rate adjustment store build failed: %s", e)
            return {"loaded": False, "hub": hub}, "Data unavailable"

        if store.get("adjusted_to") is not None:
            note = (
                f"Adjusted to front-month TTF {store['front_ttf']:.2f} + "
                f"{CO2_FACTOR}×front-Dec EUA {store['front_dec_eua']:.2f} "
                f"= {store['adjusted_to']:.2f} EUR/MWh"
            )
            if store.get("settlement"):
                note += f"  (settlement {store['settlement']})"
        else:
            note = "Forward settlements unavailable — showing unadjusted spot"
        return store, note

    @app.callback(
        Output("hra-table-container", "children"),
        Input("hra-store", "data"),
        prevent_initial_call=False,
    )
    def update_table(store):
        return _build_monthly_table(store)

    @app.callback(
        [Output("hra-date-range", "start_date"),
         Output("hra-date-range", "end_date")],
        [Input("hra-quick-3m",  "n_clicks"),
         Input("hra-quick-6m",  "n_clicks"),
         Input("hra-quick-12m", "n_clicks"),
         Input("hra-quick-all", "n_clicks")],
        State("hra-store", "data"),
        prevent_initial_call=True,
    )
    def apply_quick_range(n3m, n6m, n12m, nall, store):
        import dash
        ctx = dash.callback_context
        if not ctx.triggered:
            return no_update, no_update
        btn_id = ctx.triggered[0]["prop_id"].split(".")[0]

        latest_str = (store or {}).get("latest_date")
        earliest_str = (store or {}).get("earliest_date")

        # Anchor the end of the range to the latest available date (not necessarily today).
        end = pd.to_datetime(latest_str).date() if latest_str else date.today()

        if btn_id == "hra-quick-3m":
            start = (end - timedelta(days=91))
        elif btn_id == "hra-quick-6m":
            start = (end - timedelta(days=182))
        elif btn_id == "hra-quick-12m":
            start = (end - timedelta(days=365))
        else:  # All
            start = pd.to_datetime(earliest_str).date() if earliest_str else end - timedelta(days=365)

        return str(start), str(end)

    @app.callback(
        [Output("hra-chart-container", "children"),
         Output("hra-chart-note", "children")],
        [Input("hra-store", "data"),
         Input("hra-date-range", "start_date"),
         Input("hra-date-range", "end_date"),
         Input("hra-resolution", "value")],
        prevent_initial_call=False,
    )
    def update_chart(store, start_date, end_date, resolution):
        resolution = resolution or "daily"
        if resolution == "hourly":
            note = "Hourly (CET/CEST delivery time). Full history available — fetched from S3 if needed."
            chart = _build_hourly_chart(store, start_date, end_date, app_data)
        else:
            note = "Daily average."
            chart = _build_daily_chart(store, start_date, end_date)
        return chart, note

    @app.callback(
        Output("hra-download", "data"),
        Input("hra-download-btn", "n_clicks"),
        [State("hra-store", "data"),
         State("hra-date-range", "start_date"),
         State("hra-date-range", "end_date"),
         State("hra-resolution", "value")],
        prevent_initial_call=True,
    )
    def download_excel(n_clicks, store, start_date, end_date, resolution):
        if not n_clicks or not store or not store.get("loaded"):
            return no_update

        use_hourly = (resolution == "hourly")
        hub = store.get("hub", "hub")

        if use_hourly:
            try:
                raw = _compute_hourly_for_range(
                    app_data,
                    hub,
                    store.get("front_ttf"),
                    store.get("front_dec_eua"),
                    start_date,
                    end_date,
                )
                df = _hourly_to_df(raw, start_date, end_date)
                if df.empty:
                    return no_update
                date_col_in = "DateTime"
            except Exception as e:
                logger.exception("HRA Excel hourly export failed: %s", e)
                return no_update
        else:
            records = store.get("daily", [])
            if not records:
                return no_update
            df = pd.DataFrame(records)
            date_col_in = "Date"
            df["_ts"] = pd.to_datetime(df[date_col_in], errors="coerce")
            if start_date:
                df = df[df["_ts"] >= pd.to_datetime(start_date)]
            if end_date:
                df = df[df["_ts"] <= pd.to_datetime(end_date)]
            if df.empty:
                return no_update

        if df.empty:
            return no_update

        export = df[[date_col_in, "Spot", "Adjusted"]].copy()
        res_tag = "hourly" if use_hourly else "daily"

        buf = io.BytesIO()
        sheet = f"{hub}_{res_tag}"[:31]
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            export.to_excel(writer, sheet_name=sheet, index=False)
        buf.seek(0)
        fname = f"heatrate_adjusted_{hub}_{res_tag}.xlsx"
        return dcc.send_bytes(buf.read(), filename=fname)

    # ── Location Spreads callbacks ────────────────────────────────────────────

    @app.callback(
        [Output("lsp-adjust-panel", "children"),
         Output("lsp-defaults-note", "children")],
        [Input("lsp-country", "value"),
         Input("lsp-reset-btn", "n_clicks")],
        prevent_initial_call=False,
    )
    def render_adjust_panel(country, _reset):
        country = country or DEFAULT_HUB
        ttf, eua, settlement = _get_forward_settlements()
        ttf_d = round(ttf, 2) if ttf is not None else None
        eua_d = round(eua, 2) if eua is not None else None
        if ttf_d is not None and eua_d is not None:
            note = (f"Market default: TTF {ttf_d:.2f} + {CO2_FACTOR}×EUA {eua_d:.2f}"
                    + (f"  (settlement {settlement})" if settlement else ""))
        else:
            note = "Forward settlements unavailable — enter values manually."
        return _build_adjust_panel(country, ttf_d, eua_d), note

    @app.callback(
        [Output("lsp-date-range", "start_date"),
         Output("lsp-date-range", "end_date")],
        [Input("lsp-quick-3m",  "n_clicks"),
         Input("lsp-quick-6m",  "n_clicks"),
         Input("lsp-quick-12m", "n_clicks"),
         Input("lsp-quick-all", "n_clicks")],
        prevent_initial_call=True,
    )
    def apply_lsp_quick_range(n3m, n6m, n12m, nall):
        import dash
        ctx = dash.callback_context
        if not ctx.triggered:
            return no_update, no_update
        btn_id = ctx.triggered[0]["prop_id"].split(".")[0]
        end = date.today()
        if btn_id == "lsp-quick-3m":
            start = end - timedelta(days=91)
        elif btn_id == "lsp-quick-6m":
            start = end - timedelta(days=182)
        elif btn_id == "lsp-quick-12m":
            start = end - timedelta(days=365)
        else:  # All
            start = end - timedelta(days=365 * 3)
        return str(start), str(end)

    @app.callback(
        Output("lsp-store", "data"),
        [Input("lsp-compute-btn", "n_clicks"),
         Input("lsp-resolution", "value"),
         Input("lsp-date-range", "start_date"),
         Input("lsp-date-range", "end_date")],
        [State("lsp-country", "value"),
         State({"type": "lsp-ttf", "index": ALL}, "value"),
         State({"type": "lsp-ttf", "index": ALL}, "id"),
         State({"type": "lsp-eua", "index": ALL}, "value"),
         State({"type": "lsp-eua", "index": ALL}, "id")],
        prevent_initial_call=True,
    )
    def compute_lsp(_n, resolution, start_date, end_date,
                    country, ttf_vals, ttf_ids, eua_vals, eua_ids):
        country = country or DEFAULT_HUB
        neighbors = _neighbors(country)
        if not neighbors:
            return {"error": f"No bordering hubs configured for {country}."}

        # Build per-zone fuel overrides from the editable inputs.
        zone_fuels = {}
        for val, idd in zip(ttf_vals, ttf_ids):
            zone_fuels.setdefault(idd["index"], [None, None])[0] = val
        for val, idd in zip(eua_vals, eua_ids):
            zone_fuels.setdefault(idd["index"], [None, None])[1] = val
        zone_fuels = {z: (v[0], v[1]) for z, v in zone_fuels.items()}

        use_hourly = (resolution == "hourly")
        try:
            result = _compute_location_spreads(
                app_data, country, neighbors, zone_fuels,
                start_date, end_date, use_hourly,
            )
        except Exception as e:
            logger.exception("Location-spread computation failed: %s", e)
            return {"error": f"Computation failed: {e}"}

        if result is None:
            return {"error": "No spread data for this country / date range."}
        return result

    @app.callback(
        [Output("lsp-monthly-container", "children"),
         Output("lsp-chart-container", "children")],
        [Input("lsp-store", "data"),
         Input("lsp-metric", "value")],
        prevent_initial_call=True,
    )
    def render_lsp_outputs(result, metric):
        if not result:
            msg = html.P("Choose a country and press Compute.",
                         className="text-center text-muted my-4")
            return msg, msg
        if result.get("error"):
            err = dbc.Alert(result["error"], color="warning",
                            className="mx-0", style={"fontSize": "13px"})
            blank = html.Div()
            return err, blank
        metric = metric or "adjusted"
        return (
            _build_spread_monthly_table(result),
            _build_spread_chart(result, metric),
        )

    @app.callback(
        Output("lsp-download", "data"),
        Input("lsp-download-btn", "n_clicks"),
        State("lsp-store", "data"),
        prevent_initial_call=True,
    )
    def download_lsp(n_clicks, result):
        if not n_clicks or not result or result.get("error") or not result.get("borders"):
            return no_update

        home = result["home"]
        res_tag = "hourly" if result.get("use_hourly") else "daily"

        # Long-format frame: one row per (key, border) with spot & adjusted spread.
        long_rows = []
        for brd in result["borders"]:
            for rec in result["series"].get(brd, []):
                long_rows.append({
                    "Border": f"{home}-{brd}",
                    "Period": rec["key"],
                    "Spot Spread": rec["spot_spread"],
                    "Adjusted Spread": rec["adj_spread"],
                })
        if not long_rows:
            return no_update

        long_df = pd.DataFrame(long_rows)
        summary_df = pd.DataFrame(result.get("summary", []))
        monthly_df = pd.DataFrame(result.get("monthly", []))

        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            if not summary_df.empty:
                summary_df.to_excel(writer, sheet_name="Summary", index=False)
            if not monthly_df.empty:
                monthly_df.to_excel(writer, sheet_name="Monthly", index=False)
            long_df.to_excel(writer, sheet_name="TimeSeries", index=False)
        buf.seek(0)
        fname = f"location_spreads_{home}_{res_tag}.xlsx"
        return dcc.send_bytes(buf.read(), filename=fname)
