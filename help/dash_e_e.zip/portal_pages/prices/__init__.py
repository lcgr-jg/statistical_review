"""Portal-owned copies of prices page code."""
