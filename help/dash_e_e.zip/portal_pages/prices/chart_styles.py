"""
Professional Chart Styling for Hedge Fund-Grade Dashboards

This module provides consistent, Bloomberg-style chart configurations
for all visualizations across the price dashboard.
"""

# Professional Color Palette (Inspired by Bloomberg Terminal)
CHART_COLORS = {
    # Primary data colors
    'blue': '#1f77b4',
    'orange': '#ff7f0e',
    'green': '#2ca02c',
    'red': '#d62728',
    'purple': '#9467bd',
    'brown': '#8c564b',
    'pink': '#e377c2',
    'gray': '#7f7f7f',
    'olive': '#bcbd22',
    'cyan': '#17becf',
    
    # Semantic colors
    'positive': '#2ca02c',
    'negative': '#d62728',
    'neutral': '#1f77b4',
    
    # CDS/CSS specific
    'cds_low': '#d62728',      # Red for CDS low efficiency
    'cds_mid': '#c44e52',      # Medium red
    'cds_high': '#8b0000',     # Dark red
    'css_low': '#2ca02c',      # Green for CSS low efficiency
    'css_mid': '#228b22',      # Medium green
    'css_high': '#006400',     # Dark green
    
    # UI colors
    'grid': '#e5e5e5',
    'grid_light': '#f5f5f5',
    'background': '#ffffff',
    'text': '#333333',
    'text_light': '#666666',
}

# Line styles for different data series
LINE_STYLES = {
    'solid': dict(width=2.5, dash='solid'),
    'dashed': dict(width=2, dash='dash'),
    'dotted': dict(width=2, dash='dot'),
    'thick': dict(width=3, dash='solid'),
    'thin': dict(width=1.5, dash='solid'),
}

# Marker styles
MARKER_STYLES = {
    'default': dict(size=8, symbol='circle'),
    'small': dict(size=6, symbol='circle'),
    'large': dict(size=10, symbol='circle'),
    'square': dict(size=8, symbol='square'),
    'diamond': dict(size=8, symbol='diamond'),
}


def get_base_layout(title=None, height=500, show_legend=True):
    """
    Get base layout configuration for professional charts.
    
    Args:
        title: Chart title (optional)
        height: Chart height in pixels
        show_legend: Whether to show legend
        
    Returns:
        dict: Plotly layout configuration
    """
    layout = {
        'template': 'plotly_white',
        'height': height,
        'margin': dict(l=70, r=30, t=50 if title else 30, b=60),
        'hovermode': 'x unified',
        'plot_bgcolor': CHART_COLORS['background'],
        'paper_bgcolor': CHART_COLORS['background'],
        'font': dict(
            family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            size=12,
            color=CHART_COLORS['text']
        ),
        'xaxis': dict(
            showgrid=True,
            gridwidth=1,
            gridcolor=CHART_COLORS['grid'],
            zeroline=False,
            showline=True,
            linewidth=1,
            linecolor=CHART_COLORS['grid'],
            tickfont=dict(size=11, color=CHART_COLORS['text']),
            title_font=dict(size=12, color=CHART_COLORS['text'])
        ),
        'yaxis': dict(
            showgrid=True,
            gridwidth=1,
            gridcolor=CHART_COLORS['grid'],
            zeroline=True,
            zerolinewidth=2,
            zerolinecolor=CHART_COLORS['grid'],
            showline=True,
            linewidth=1,
            linecolor=CHART_COLORS['grid'],
            tickfont=dict(size=11, color=CHART_COLORS['text']),
            title_font=dict(size=12, color=CHART_COLORS['text'])
        ),
    }
    
    if title:
        layout['title'] = dict(
            text=title,
            font=dict(size=16, color=CHART_COLORS['text'], family='inherit'),
            x=0.02,
            xanchor='left'
        )
    
    if show_legend:
        layout['legend'] = dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='right',
            x=1,
            bgcolor='rgba(255,255,255,0.9)',
            bordercolor=CHART_COLORS['grid'],
            borderwidth=1,
            font=dict(size=11)
        )
    else:
        layout['showlegend'] = False
    
    return layout


def get_line_trace(x, y, name, color=None, line_style='solid', marker_style='default', **kwargs):
    """
    Create a professional line trace.
    
    Args:
        x: X-axis data
        y: Y-axis data
        name: Trace name for legend
        color: Line color (hex or name from CHART_COLORS)
        line_style: Style key from LINE_STYLES
        marker_style: Style key from MARKER_STYLES
        **kwargs: Additional trace properties
        
    Returns:
        dict: Plotly trace configuration
    """
    if color and color in CHART_COLORS:
        color = CHART_COLORS[color]
    
    trace = {
        'x': x,
        'y': y,
        'mode': 'lines+markers',
        'name': name,
        'line': {**LINE_STYLES.get(line_style, LINE_STYLES['solid']), 'color': color},
        'marker': {**MARKER_STYLES.get(marker_style, MARKER_STYLES['default']), 'color': color},
        'hovertemplate': '<b>%{x}</b><br>%{y:.2f}<extra></extra>',
        **kwargs
    }
    
    return trace


def get_bar_trace(x, y, name, color=None, **kwargs):
    """
    Create a professional bar trace.
    
    Args:
        x: X-axis data
        y: Y-axis data
        name: Trace name for legend
        color: Bar color (hex or name from CHART_COLORS)
        **kwargs: Additional trace properties
        
    Returns:
        dict: Plotly trace configuration
    """
    if color and color in CHART_COLORS:
        color = CHART_COLORS[color]
    
    trace = {
        'x': x,
        'y': y,
        'type': 'bar',
        'name': name,
        'marker': dict(
            color=color,
            line=dict(width=0)
        ),
        'hovertemplate': '<b>%{x}</b><br>%{y:.2f}<extra></extra>',
        **kwargs
    }
    
    return trace


def format_currency_axis(fig, axis='yaxis', currency='€', decimals=2):
    """
    Format axis to show currency values.
    
    Args:
        fig: Plotly figure
        axis: 'xaxis' or 'yaxis'
        currency: Currency symbol
        decimals: Number of decimal places
    """
    fig.update_layout({
        axis: dict(
            tickformat=f',.{decimals}f',
            tickprefix=currency,
        )
    })
    return fig


def format_percentage_axis(fig, axis='yaxis', decimals=1):
    """
    Format axis to show percentage values.
    
    Args:
        fig: Plotly figure
        axis: 'xaxis' or 'yaxis'
        decimals: Number of decimal places
    """
    fig.update_layout({
        axis: dict(
            tickformat=f',.{decimals}f',
            ticksuffix='%',
        )
    })
    return fig


def add_zero_line(fig, axis='y', color=None):
    """
    Add a prominent zero reference line.
    
    Args:
        fig: Plotly figure
        axis: 'x' or 'y'
        color: Line color (default: grid color)
    """
    if color is None:
        color = CHART_COLORS['text_light']
    
    if axis == 'y':
        fig.add_hline(
            y=0,
            line_dash="solid",
            line_color=color,
            line_width=2,
            opacity=0.5
        )
    else:
        fig.add_vline(
            x=0,
            line_dash="solid",
            line_color=color,
            line_width=2,
            opacity=0.5
        )
    
    return fig


def apply_professional_config(fig):
    """
    Apply professional configuration to any figure.
    
    Args:
        fig: Plotly figure
        
    Returns:
        fig: Updated figure
    """
    fig.update_layout(
        hoverlabel=dict(
            bgcolor="white",
            font_size=12,
            font_family='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            bordercolor=CHART_COLORS['grid']
        ),
        modebar=dict(
            bgcolor='rgba(255,255,255,0.8)',
            color=CHART_COLORS['text_light'],
            activecolor=CHART_COLORS['blue']
        )
    )
    
    # Update all traces to have consistent hover behavior
    fig.update_traces(
        hoverlabel=dict(namelength=-1)
    )
    
    return fig
