"""
Gas / CO2 daily series aggregated to Period labels (JAN-25, Q1-25, CAL-25, …).

Shared by ``calculate_delivered_spreads_new`` (standalone price_dashboard logic) and
hourly-S3 delivered CSS when replacing EPEX ``DELIVERED_PRICE`` with mean spot power.
"""

from __future__ import annotations

import logging
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)

UK_CARBON_TAX_GBP = 18.0


def build_all_period_gas_co2_prices(
    gas_spot_normalized: pd.DataFrame,
    co2_spot_normalized: pd.DataFrame,
    fx_data: pd.DataFrame,
) -> pd.DataFrame:
    """
    Same TTF / NBP / EUA / UKA table as ``calculate_delivered_spreads_new`` in data_loader
    (price_dashboard: delivered spark vs period-matched gas/carbon).
    """
    if gas_spot_normalized is None or co2_spot_normalized is None:
        return pd.DataFrame()
    if gas_spot_normalized.empty or co2_spot_normalized.empty:
        return pd.DataFrame()

    gas_daily = gas_spot_normalized.copy()
    gas_daily["valuedate"] = pd.to_datetime(gas_daily["valuedate"])
    gas_daily["hub"] = gas_daily["hub"].astype(str)

    ttf_data = gas_daily[gas_daily["hub"].str.upper() == "TTF"].copy()
    nbp_data = gas_daily[gas_daily["hub"].str.upper() == "NBP"].copy()

    ttf_daily = ttf_data.groupby("valuedate")["value"].mean().reset_index()
    ttf_daily.rename(columns={"valuedate": "DATE", "value": "TTF_EUR_MWh"}, inplace=True)

    nbp_daily = nbp_data.groupby("valuedate")["value"].mean().reset_index()
    nbp_daily.rename(columns={"valuedate": "DATE", "value": "NBP_GBP_MWh"}, inplace=True)

    co2_daily = co2_spot_normalized.copy()
    co2_daily["valuedate"] = pd.to_datetime(co2_daily["valuedate"])
    co2_daily["hub"] = co2_daily["hub"].astype(str)

    eua_data = co2_daily[co2_daily["hub"].str.upper() == "EUA"].copy()
    uka_data = co2_daily[co2_daily["hub"].str.upper() == "UKA"].copy()

    eua_daily = eua_data.groupby("valuedate")["value"].mean().reset_index()
    eua_daily.rename(columns={"valuedate": "DATE", "value": "EUA_EUR_tonne"}, inplace=True)

    uka_daily = uka_data.groupby("valuedate")["value"].mean().reset_index()
    uka_daily.rename(columns={"valuedate": "DATE", "value": "UKA_GBP_tonne"}, inplace=True)

    if fx_data is None or (hasattr(fx_data, "empty") and fx_data.empty):
        logger.error("FX data is empty - cannot build period fuel prices (GBP→EUR)")
        return pd.DataFrame()

    fx_daily = fx_data.copy()
    fx_daily = fx_daily.reset_index()

    if "date" in fx_daily.columns:
        fx_daily["DATE"] = pd.to_datetime(fx_daily["date"])
    elif "DATE" in fx_daily.columns:
        fx_daily["DATE"] = pd.to_datetime(fx_daily["DATE"])
    else:
        fx_daily["DATE"] = pd.to_datetime(fx_daily.index)

    eurgbp_col = None
    for col in fx_daily.columns:
        cu = str(col).upper()
        if "EURGBP" in cu and "PX_LAST" in cu:
            eurgbp_col = col
            break
    if not eurgbp_col:
        for col in fx_daily.columns:
            cu = str(col).upper()
            if "EUR" in cu and "GBP" in cu and (
                "PX" in cu or "LAST" in cu or "VALUE" in cu or "LAST_PRICE" in cu
            ):
                eurgbp_col = col
                break
    if not eurgbp_col:
        for col in fx_daily.columns:
            cu = str(col).upper()
            if cu in ("DATE", "INDEX", "LEVEL_0"):
                continue
            if pd.api.types.is_numeric_dtype(fx_daily[col]):
                eurgbp_col = col
                logger.warning(
                    "FX: using first numeric column %r as EUR/GBP (fallback; "
                    "no EURGBP/PX_LAST name match — verify Bloomberg field layout).",
                    col,
                )
                break

    if not eurgbp_col:
        logger.error("Could not find EUR/GBP FX column; columns: %s", list(fx_daily.columns))
        return pd.DataFrame()
    fx_daily = fx_daily.rename(columns={eurgbp_col: "EURGBP"})

    daily_prices = ttf_daily.merge(nbp_daily, on="DATE", how="outer")
    daily_prices = daily_prices.merge(eua_daily, on="DATE", how="outer")
    daily_prices = daily_prices.merge(uka_daily, on="DATE", how="outer")
    daily_prices = daily_prices.merge(fx_daily[["DATE", "EURGBP"]], on="DATE", how="outer")
    daily_prices = daily_prices.sort_values("DATE").ffill()

    daily_prices["NBP_EUR_MWh"] = daily_prices["NBP_GBP_MWh"] / daily_prices["EURGBP"]
    daily_prices["UKA_EUR_tonne"] = (
        daily_prices["UKA_GBP_tonne"] + UK_CARBON_TAX_GBP
    ) / daily_prices["EURGBP"]

    daily_prices["YEAR"] = daily_prices["DATE"].dt.year
    daily_prices["WEEK"] = daily_prices["DATE"].dt.isocalendar().week
    daily_prices["MONTH"] = daily_prices["DATE"].dt.month
    daily_prices["QUARTER"] = daily_prices["DATE"].dt.quarter

    weekly_prices = daily_prices.groupby(["YEAR", "WEEK"]).agg(
        {
            "TTF_EUR_MWh": "mean",
            "NBP_EUR_MWh": "mean",
            "EUA_EUR_tonne": "mean",
            "UKA_EUR_tonne": "mean",
        }
    ).reset_index()
    weekly_prices["Period"] = weekly_prices.apply(
        lambda x: f"WK{int(x['WEEK']):02d}-{int(x['YEAR']) % 100:02d}", axis=1
    )

    monthly_prices = daily_prices.groupby(["YEAR", "MONTH"]).agg(
        {
            "TTF_EUR_MWh": "mean",
            "NBP_EUR_MWh": "mean",
            "EUA_EUR_tonne": "mean",
            "UKA_EUR_tonne": "mean",
        }
    ).reset_index()
    month_map = {
        1: "JAN", 2: "FEB", 3: "MAR", 4: "APR", 5: "MAY", 6: "JUN",
        7: "JUL", 8: "AUG", 9: "SEP", 10: "OCT", 11: "NOV", 12: "DEC",
    }
    monthly_prices["Period"] = monthly_prices.apply(
        lambda x: f"{month_map[x['MONTH']]}-{int(x['YEAR']) % 100:02d}", axis=1
    )

    quarterly_prices = daily_prices.groupby(["YEAR", "QUARTER"]).agg(
        {
            "TTF_EUR_MWh": "mean",
            "NBP_EUR_MWh": "mean",
            "EUA_EUR_tonne": "mean",
            "UKA_EUR_tonne": "mean",
        }
    ).reset_index()
    quarterly_prices["Period"] = quarterly_prices.apply(
        lambda x: f"Q{int(x['QUARTER'])}-{int(x['YEAR']) % 100:02d}", axis=1
    )

    yearly_prices = daily_prices.groupby(["YEAR"]).agg(
        {
            "TTF_EUR_MWh": "mean",
            "NBP_EUR_MWh": "mean",
            "EUA_EUR_tonne": "mean",
            "UKA_EUR_tonne": "mean",
        }
    ).reset_index()
    yearly_prices["Period"] = yearly_prices.apply(
        lambda x: f"CAL-{int(x['YEAR']) % 100:02d}", axis=1
    )

    return pd.concat(
        [weekly_prices, monthly_prices, quarterly_prices, yearly_prices], ignore_index=True
    )


def period_key_from_chart(period: str, year: int) -> str:
    """Map CSS chart Period + Year to keys used in build_all_period_gas_co2_prices (e.g. JAN-25, Q1-25)."""
    p = (period or "").strip().upper()
    yy = int(year) % 100
    if p.startswith("CAL") or p == "C" or p == "CY":
        return f"CAL-{yy:02d}"
    if p.startswith("Q") and len(p) >= 2 and p[1].isdigit():
        return f"Q{int(p[1])}-{yy:02d}"
    if len(p) >= 3 and p[:3] in (
        "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
        "JUL", "AUG", "SEP", "OCT", "NOV", "DEC",
    ):
        return f"{p[:3]}-{yy:02d}"
    if p.startswith("WK") or p.startswith("W"):
        if "-" in p:
            return p
    return f"{p}-{yy:02d}"


def lookup_period_fuel_row(
    all_period_prices: pd.DataFrame, period: str, year: int
) -> Optional[pd.Series]:
    if all_period_prices is None or all_period_prices.empty:
        return None
    ap = all_period_prices
    want = period_key_from_chart(period, year)
    m = ap[ap["Period"].str.upper() == want.upper()]
    if not m.empty:
        return m.iloc[0]
    period_u = (period or "").strip().upper()
    yy = int(year) % 100
    suf = f"-{yy:02d}"
    if len(period_u) == 3 and period_u in (
        "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
        "JUL", "AUG", "SEP", "OCT", "NOV", "DEC",
    ):
        m = ap[ap["Period"].str.upper().str.startswith(period_u + "-")]
    elif len(period_u) >= 2 and period_u.startswith("Q") and period_u[1:2].isdigit():
        m = ap[ap["Period"].str.upper().str.startswith(period_u[:2] + "-")]
    elif period_u.startswith("C") or period_u == "CAL":
        m = ap[ap["Period"].str.upper().str.startswith("CAL-")]
    else:
        m = ap[ap["Period"].str.upper().str.startswith(period_u[: min(3, len(period_u))])]
    if m is None or m.empty:
        return None
    m2 = m[m["Period"].str.upper().str.endswith(suf)]
    if not m2.empty:
        return m2.iloc[0]
    return m.iloc[0]
