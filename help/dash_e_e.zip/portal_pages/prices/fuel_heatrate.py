"""
Fuel Heat Rates
===============
Year x Month heatmap tables of the implied power heat rate for each thermal fuel,
mirroring the monthly heat-rate table in ``eu_reports.power_price_report.price_report``.

For each delivery day we compute, from the spot (and, for future months, forward)
power / fuel / carbon stack:

    Gas HR      = Power / (Gas + 0.1821 * Carbon)
    Coal HR     = Power / (Coal_EUR_MWh + 0.34 * Carbon)     Coal_EUR_MWh = Coal_USD_t * USD->EUR / 6.97
    Lignite HR  = Power / (3.0 + 0.40 * Carbon)              (fixed lignite fuel cost)
    Blended HR  = mean(Gas HR, Coal HR, Lignite HR)

Denominators are the fuel-plus-carbon cost per MWh thermal *before* plant efficiency,
so each heat rate is the dimensionless MWh_th / MWh_e implied by the market.

Daily values are averaged by month and pivoted to a Month (rows) x Year (cols) table,
one table per fuel, shaded like the report (green = low, red = high). Cells whose
delivery month is the current month or later are sourced from forward curves and
outlined in black.
"""

from __future__ import annotations

import datetime as dt
import logging

import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
from dash import Input, Output, dash_table, dcc, html

from portal_pages.prices.constants import APP_COLORS

logger = logging.getLogger(__name__)

MONTH_LABELS = {
    1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
    7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec",
}

PREFERRED_HUBS = [
    "DE", "FR", "GB", "NL", "BE", "CH", "AT", "IT", "IT-NORTH", "ES",
    "DK1", "DK2", "NO2", "HU", "CZ", "SK", "SI", "GR", "RO", "BG", "HR",
]
DEFAULT_HUB = "DE"

# (store key, display label) for each fuel heat rate.
METRICS = [
    ("Gas HR", "Gas Heat Rate"),
    ("Coal HR", "Coal Heat Rate"),
    ("Lignite HR", "Lignite Heat Rate"),
    ("Blended HR", "Blended Heat Rate"),
]
METRIC_KEYS = [k for k, _ in METRICS]

# How many calendar years of history to show (columns = these years + current + next).
YEARS_BACK = 4


# ── Computation ───────────────────────────────────────────────────────────────

def _pivot_records(s: pd.Series, today: dt.date, estimated: set):
    """
    Build Month x Year records for one fuel from a month-indexed series.

    ``s`` is indexed by month-start ``Timestamp`` with the metric value. Returns
    ``(records, years, future_cells, estimated_cells)`` where ``records`` is 12
    month rows plus an ``Avg`` row, ``years`` are the string year columns,
    ``future_cells`` are ``(row_index, year_str)`` cells whose delivery month is
    current-or-later (spot has ended → forward curve), and ``estimated_cells`` are
    cells filled by interpolating the front near-month gap (no forward power mark).
    """
    if s is None or s.empty:
        return [], [], [], []
    s = s.dropna()
    if s.empty:
        return [], [], [], []

    years = sorted({int(ts.year) for ts in s.index})
    year_cols = [str(y) for y in years]

    def _is_future(year: int, month: int) -> bool:
        return year > today.year or (year == today.year and month >= today.month)

    records, future_cells, estimated_cells = [], [], []
    for m in range(1, 13):
        row = {"Month": MONTH_LABELS[m]}
        row_idx = len(records)
        for y in years:
            col = str(y)
            val = s.get(pd.Timestamp(year=y, month=m, day=1))
            if val is not None and pd.notna(val):
                row[col] = round(float(val), 2)
                if _is_future(y, m):
                    future_cells.append((row_idx, col))
                if (y, m) in estimated:
                    estimated_cells.append((row_idx, col))
            else:
                row[col] = None
        records.append(row)

    # Yearly average row (mean over available months).
    avg = {"Month": "Avg"}
    avg_row_idx = len(records)
    for y in years:
        col = str(y)
        vals = [records[m - 1][col] for m in range(1, 13)
                if isinstance(records[m - 1][col], (int, float))]
        avg[col] = round(float(np.mean(vals)), 2) if vals else None
    records.append(avg)
    # Mark the whole Avg column cell as forward when any month that year is forward.
    for y in years:
        if any(fc[0] < avg_row_idx and fc[1] == str(y) for fc in future_cells):
            future_cells.append((avg_row_idx, str(y)))

    return records, year_cols, future_cells, estimated_cells


def _build_store(hub: str) -> dict:
    """Compute the per-fuel Month x Year tables for ``hub``."""
    today = dt.date.today()
    start = dt.date(today.year - YEARS_BACK, 1, 1)
    end = dt.date(today.year + 1, 12, 31)
    forward_trade_date = today - dt.timedelta(days=1)

    try:
        from pages.heatmap_balance_data import compute_price_metrics_daily

        daily = compute_price_metrics_daily(
            hub, start, end, forward_trade_date=forward_trade_date
        )
    except Exception as e:  # pragma: no cover - defensive
        logger.exception("Fuel heat-rate computation failed for %s: %s", hub, e)
        return {"loaded": False, "hub": hub}

    if daily is None or daily.empty:
        return {"loaded": False, "hub": hub}

    have = [m for m in METRIC_KEYS if m in daily.columns]
    if not have:
        return {"loaded": False, "hub": hub}

    df = daily[have].copy()
    df = df[df.index.notna()]
    df.index = pd.to_datetime(df.index)
    # Month-start index across the full window; months with no data become NaN.
    monthly = df.resample("MS").mean()

    metrics = {}
    for key in METRIC_KEYS:
        if key not in monthly.columns:
            metrics[key] = {"records": [], "years": [], "future": [], "estimated": []}
            continue
        s = monthly[key]
        # Bridge the front near-month gap (spot ended, forward power curve not yet
        # started for the in-delivery quarter) by interpolating interior gaps only.
        # ``limit_area="inside"`` never extrapolates past the last quoted forward.
        had = s.notna()
        s_filled = s.interpolate(method="linear", limit_area="inside")
        estimated = {(ts.year, ts.month) for ts in s_filled.index[s_filled.notna() & ~had]}
        records, years, future, est = _pivot_records(s_filled, today, estimated)
        metrics[key] = {
            "records": records, "years": years, "future": future, "estimated": est,
        }

    return {"loaded": True, "hub": hub, "metrics": metrics}


# ── Rendering ─────────────────────────────────────────────────────────────────

def _shade(v, vmin, vmax):
    """Green (low heat rate) → yellow → red (high), robust-scaled like the report."""
    if vmax <= vmin:
        return "#ffffff"
    t = max(0.0, min(1.0, (v - vmin) / (vmax - vmin)))
    # Green (46,204,113) → Yellow (241,196,15) → Red (231,76,60)
    if t < 0.5:
        u = t / 0.5
        r = int(46 + (241 - 46) * u)
        g = int(204 + (196 - 204) * u)
        b = int(113 + (15 - 113) * u)
    else:
        u = (t - 0.5) / 0.5
        r = int(241 + (231 - 241) * u)
        g = int(196 + (76 - 196) * u)
        b = int(15 + (60 - 15) * u)
    return f"rgb({r},{g},{b})"


def _build_metric_table(metric_key: str, label: str, payload: dict):
    """One fuel heat-rate heatmap table."""
    records = (payload or {}).get("records") or []
    years = (payload or {}).get("years") or []
    future = (payload or {}).get("future") or []
    estimated = (payload or {}).get("estimated") or []

    header = html.H6(label, style={"fontSize": "14px", "fontWeight": "700",
                                   "color": "#333", "marginBottom": "8px"})

    if not records or not years:
        return html.Div([
            header,
            html.Div("No data available.", className="text-center text-muted py-4"),
        ], style={"backgroundColor": "#fff", "border": "1px solid #e0e0e0",
                  "borderRadius": "6px", "padding": "12px"})

    # Robust colour scale from the monthly cells only (exclude the Avg row).
    month_vals = [
        v for rec in records[:-1] for k, v in rec.items()
        if k != "Month" and isinstance(v, (int, float))
    ]
    if month_vals:
        vmin, vmax = np.percentile(month_vals, [10, 90])
    else:
        vmin, vmax = 0.0, 1.0

    cols = [{"name": "Month", "id": "Month"}] + [{"name": y, "id": y} for y in years]

    style_data_conditional = [
        {"if": {"column_id": "Month"}, "fontWeight": "bold",
         "backgroundColor": APP_COLORS.get("highlight_bg", "#e9ecef"),
         "color": APP_COLORS.get("highlight_text", "#495057")},
        {"if": {"filter_query": "{Month} = 'Avg'"}, "fontWeight": "bold",
         "borderTop": "2px solid #333", "backgroundColor": "#f7f7f7"},
    ]
    # Shade the monthly cells (not the Avg row).
    for row_idx, rec in enumerate(records[:-1]):
        for y in years:
            v = rec.get(y)
            if isinstance(v, (int, float)):
                style_data_conditional.append({
                    "if": {"row_index": row_idx, "column_id": y},
                    "backgroundColor": _shade(v, vmin, vmax),
                })
    # Outline forward (current-month-onward) cells.
    for row_idx, col in future:
        style_data_conditional.append({
            "if": {"row_index": row_idx, "column_id": col},
            "border": "2px solid #111",
        })
    # Estimated (interpolated) near-month cells: dashed border + italic, overrides
    # the solid forward outline so they read as bridged rather than a real mark.
    for row_idx, col in estimated:
        style_data_conditional.append({
            "if": {"row_index": row_idx, "column_id": col},
            "border": "2px dashed #555", "fontStyle": "italic", "color": "#555",
        })

    data = [{k: ("" if v is None else v) for k, v in rec.items()} for rec in records]

    table = dash_table.DataTable(
        columns=cols,
        data=data,
        style_table={"overflowX": "auto"},
        style_cell={"textAlign": "center", "padding": "7px 8px",
                    "fontFamily": "Arial, sans-serif", "fontSize": "12px",
                    "minWidth": "58px"},
        style_header={"backgroundColor": APP_COLORS.get("header_bg", "#f2f2f2"),
                      "color": APP_COLORS.get("header_text", "#333"),
                      "fontWeight": "bold"},
        style_data_conditional=style_data_conditional,
    )

    return html.Div([
        html.Div([
            header,
            html.Span("Solid border = forward curve · dashed = interpolated", style={
                "fontSize": "11px", "color": "#777", "marginLeft": "8px",
            }),
        ], style={"display": "flex", "alignItems": "baseline",
                  "justifyContent": "space-between", "marginBottom": "8px"}),
        table,
    ], style={"backgroundColor": "#fff", "border": "1px solid #e0e0e0",
              "borderRadius": "6px", "padding": "12px",
              "boxShadow": "0 1px 2px rgba(0,0,0,0.03)"})


def _build_tables(store):
    if not store or not store.get("loaded"):
        return html.Div(
            "No heat-rate data available for this hub.",
            className="text-center text-muted my-5",
        )
    metrics = store.get("metrics", {})
    cards = [
        _build_metric_table(key, label, metrics.get(key, {}))
        for key, label in METRICS
    ]
    return html.Div(cards, style={
        "display": "grid",
        "gridTemplateColumns": "repeat(auto-fit, minmax(520px, 1fr))",
        "gap": "16px",
        "alignItems": "start",
    })


# ── Layout ────────────────────────────────────────────────────────────────────

def get_layout(data):
    label_style = {
        "fontSize": "11px", "fontWeight": "600", "color": "#666",
        "marginBottom": "5px", "display": "block",
        "textTransform": "uppercase", "letterSpacing": "0.5px",
    }
    panel_style = {
        "padding": "24px 30px", "backgroundColor": "#fff",
        "margin": "16px 30px", "borderRadius": "6px",
        "boxShadow": "0 1px 3px rgba(0,0,0,0.05)",
    }

    return html.Div([
        dcc.Store(id="fhr-store", data=None),
        dcc.Interval(id="fhr-load-trigger", interval=500, n_intervals=0, max_intervals=1),

        # Header / breadcrumb
        html.Div([
            html.Div([
                html.Span("Price Dashboard", style={"color": "#888", "fontSize": "13px"}),
                html.Span(" / ", style={"color": "#666", "margin": "0 6px", "fontSize": "13px"}),
                html.Span("Fuel Heat Rates",
                          style={"color": "#333", "fontSize": "13px", "fontWeight": "600"}),
            ]),
        ], style={
            "padding": "16px 30px", "borderBottom": "1px solid #e5e5e5",
            "display": "flex", "alignItems": "center", "justifyContent": "space-between",
        }),

        # Controls
        html.Div([
            html.Div([
                html.Label("Hub", style=label_style),
                dcc.Dropdown(
                    id="fhr-hub",
                    options=[{"label": h, "value": h} for h in PREFERRED_HUBS],
                    value=DEFAULT_HUB, clearable=False,
                    style={"width": "180px", "fontSize": "13px"},
                ),
            ]),
        ], style={
            "padding": "16px 30px", "borderBottom": "1px solid #e5e5e5",
            "display": "flex", "alignItems": "flex-end", "flexWrap": "wrap", "gap": "24px",
        }),

        # Tables panel
        html.Div([
            html.H5("Monthly Implied Heat Rates (MWh_th / MWh_e)",
                    style={"fontSize": "15px", "fontWeight": "600",
                           "color": "#333", "marginBottom": "6px"}),
            html.P("Power price divided by the fuel-plus-carbon cost per MWh thermal, "
                   "averaged by month. Gas uses TTF + EUA, coal uses API2 (USD→EUR) + EUA, "
                   "lignite uses a fixed fuel cost + EUA. Blended is the mean of the three. "
                   "Green = low, red = high. Solid-bordered cells are priced off forward "
                   "curves; dashed cells are interpolated across the in-delivery quarter, "
                   "where spot has ended but the forward power curve has not yet started.",
                   style={"fontSize": "12px", "color": "#888", "marginBottom": "14px"}),
            dbc.Spinner(
                html.Div(id="fhr-tables-container",
                         children=html.P("Loading…", className="text-center text-muted my-5")),
                color="primary", type="border",
                spinner_style={"width": "3rem", "height": "3rem"},
            ),
        ], style=panel_style),

    ], style={"backgroundColor": "#f5f6f8", "minHeight": "100vh"})


# ── Callbacks ─────────────────────────────────────────────────────────────────

def register_fuel_heatrate_callbacks(app, data):
    """Register Fuel Heat Rate callbacks. ``data`` is the shared price bundle (unused;
    heat rates are computed directly from the market cache for full history)."""

    @app.callback(
        Output("fhr-store", "data"),
        [Input("fhr-load-trigger", "n_intervals"),
         Input("fhr-hub", "value")],
        prevent_initial_call=False,
    )
    def load_store(_n, hub):
        return _build_store(hub or DEFAULT_HUB)

    @app.callback(
        Output("fhr-tables-container", "children"),
        Input("fhr-store", "data"),
        prevent_initial_call=False,
    )
    def render_tables(store):
        return _build_tables(store)
