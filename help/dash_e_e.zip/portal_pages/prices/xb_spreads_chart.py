"""
XB Spreads chart creation functions with caching support.

Extracted from xb_spreads.py to enable plot caching.
"""

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import re
import logging
from portal_pages.prices.constants import APP_COLORS
logger = logging.getLogger(__name__)


def _find_delivered_spot_price(delivered_spot_data, period, year, entity, is_spread=False):
    """Look up a delivered spot price (or spread) for (period, year, entity).

    Matches the behaviour of xb_spreads.find_delivered_spot_price — inlined here
    to keep the chart module self-contained and avoid a circular import.
    """
    if delivered_spot_data is None or delivered_spot_data.empty:
        return None
    entity_col = 'Country-Pair' if is_spread else 'Country'
    if entity_col not in delivered_spot_data.columns or 'DELIVERED_PRICE' not in delivered_spot_data.columns:
        return None
    period_u = str(period).upper().strip()
    year_i = int(year)
    entity_u = str(entity).upper().strip()

    def _first(mask):
        sub = delivered_spot_data[mask]
        if sub.empty:
            return None
        val = sub['DELIVERED_PRICE'].iloc[0]
        try:
            return float(val)
        except Exception:
            return None

    periods_u = delivered_spot_data['Period'].str.upper()
    base_mask = (delivered_spot_data['year'] == year_i) & (delivered_spot_data[entity_col] == entity_u)

    v = _first((periods_u == period_u) & base_mask)
    if v is not None:
        return v
    if '-' in period_u:
        v = _first(periods_u.str.startswith(period_u.split('-')[0]) & base_mask)
        if v is not None:
            return v
    if len(period_u) >= 3:
        v = _first(periods_u.str.startswith(period_u[:3]) & base_mask)
        if v is not None:
            return v
    if period_u.startswith('Q') and len(period_u) >= 2 and period_u[1].isdigit():
        v = _first(periods_u.str.contains(f"Q{period_u[1]}") & base_mask)
        if v is not None:
            return v
    if len(period_u) >= 3:
        v = _first(periods_u.str.contains(period_u[:3]) & base_mask)
        if v is not None:
            return v
    return None

MONTH_TO_NUM = {
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
    'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
}


def get_chronological_key(period):
    """
    Returns a tuple key for chronological sorting of periods.
    Lower tuple values come first in sort order.
    """
    period_lower = period.lower()
    
    # Check for month abbreviations (Jan, Feb, etc.)
    for month, num in MONTH_TO_NUM.items():
        if period_lower.startswith(month):
            return (1, num, 0)  # (type, month_num, extra)
    
    # Check for "W" followed by numbers (week designations like W01, W02)
    week_match = re.match(r'^w(\d+)', period_lower)
    if week_match:
        week_num = int(week_match.group(1))
        return (2, week_num, 0)
    
    # Check for "Q" followed by numbers (quarters like Q1, Q2)
    quarter_match = re.match(r'^q(\d+)', period_lower)
    if quarter_match:
        quarter_num = int(quarter_match.group(1))
        return (3, quarter_num, 0)
    
    # Check for "Cal" followed by optional numbers
    cal_match = re.match(r'^cal(\d*)', period_lower)
    if cal_match:
        year_part = cal_match.group(1)
        year = int(year_part) if year_part else 0
        return (4, year, 0)
    
    # Check for month numbers (01, 02, etc.)
    if re.match(r'^\d{1,2}$', period_lower):
        try:
            month_num = int(period_lower)
            if 1 <= month_num <= 12:
                return (1, month_num, 0)
        except ValueError:
            pass
    
    # For any other format, use lexicographical ordering
    return (99, 0, period)


def create_xb_spreads_chart(
    tenor_df, tenor, spreads, countries, profile,
    days_state, is_all_button, delivered_spot_data, show_negative,
):
    """
    Create XB spreads chart with caching (cached 15 min).
    
    Args:
        tenor_df: DataFrame with filtered tenor data
        tenor: Tenor selection (e.g., 'Monthly', 'Quarterly')
        spreads: List of selected spreads
        countries: List of selected countries
        profile: Profile selection ('Base', 'Peak', 'Both')
        days_state: Number of days to show or 'All'
        is_all_button: Boolean indicating if showing all data
        delivered_spot_data: DataFrame of realised EPEX period averages used to overlay
            a horizontal "delivered" line per (period, year, spread/country).
        show_negative: Boolean for showing past delivery dates

    Returns:
        Plotly Figure object
    """
    try:
        # Get unique periods and sort them chronologically
        periods = sorted(tenor_df['period'].unique(), key=get_chronological_key)
        
        # DYNAMIC LAYOUT BASED ON NUMBER OF PERIODS
        if len(periods) == 1:
            rows, cols = 1, 1
            plot_height = 700
        elif len(periods) == 2:
            rows, cols = 1, 2
            plot_height = 600
        elif len(periods) <= 4:
            rows, cols = 2, 2
            plot_height = 800
        elif len(periods) <= 6:
            rows, cols = 2, 3
            plot_height = 800
        else:
            cols = 3
            rows = 4
            plot_height = 1200
        
        # Create subplots with adjusted spacing
        fig = make_subplots(
            rows=rows,
            cols=cols,
            subplot_titles=periods,
            shared_yaxes=False,
            horizontal_spacing=0.06,
            vertical_spacing=0.1
        )
        
        # Color mapping for years
        years = sorted(tenor_df['year'].unique())
        custom_colors = APP_COLORS['YEAR_COLORS']
        year_to_color = {year: custom_colors[i % len(custom_colors)] for i, year in enumerate(years)}
        
        # Add traces for each period
        for idx, period in enumerate(periods):
            row = (idx // cols) + 1
            col = (idx % cols) + 1
            
            period_df = tenor_df[tenor_df['period'] == period]
            
            # Get max days_to_delivery for this period to set line length and axis range
            if not period_df.empty:
                max_days = period_df['DAYS_TO_DELIVERY'].max()
            else:
                max_days = 180  # Default if no data
                
            # Add traces for each spread
            for spread in spreads:
                spread_df = period_df[period_df['SPREAD_TYPE'] == spread]
                
                for year in years:
                    year_df = spread_df[spread_df['year'] == year].sort_values('DAYS_TO_DELIVERY', ascending=False)
                    
                    if year_df.empty:
                        continue
                    
                    # Handle profile selection
                    if profile == "Both":
                        # Add Base trace
                        base_df = year_df[year_df['PROFILE'] == 'Base']
                        if not base_df.empty:
                            fig.add_trace(
                                go.Scatter(
                                    x=base_df['DAYS_TO_DELIVERY'],
                                    y=base_df['SETTLEMENT_PRICE_spread'],
                                    mode='lines',
                                    name=f"{spread} {year} Base",
                                    line=dict(color=year_to_color[year]),
                                    legendgroup=f"{year}",
                                    showlegend=(idx == 0),
                                    hovertemplate='Year: %{text}<br>Days: %{x}<br>Spread: %{y:.2f}<extra></extra>',
                                    text=[str(year)]*len(base_df)
                                ),
                                row=row,
                                col=col
                            )
                        
                        # Add Peak trace
                        peak_df = year_df[year_df['PROFILE'] == 'Peak']
                        if not peak_df.empty:
                            fig.add_trace(
                                go.Scatter(
                                    x=peak_df['DAYS_TO_DELIVERY'],
                                    y=peak_df['SETTLEMENT_PRICE_spread'],
                                    mode='lines',
                                    name=f"{spread} {year} Peak",
                                    line=dict(color=year_to_color[year], dash='dash'),
                                    legendgroup=f"{year}",
                                    showlegend=(idx == 0),
                                    hovertemplate='Year: %{text}<br>Days: %{x}<br>Spread: %{y:.2f}<extra></extra>',
                                    text=[str(year)]*len(peak_df)
                                ),
                                row=row,
                                col=col
                            )
                    else:
                        # Single profile
                        profile_df = year_df[year_df['PROFILE'] == profile]
                        if not profile_df.empty:
                            fig.add_trace(
                                go.Scatter(
                                    x=profile_df['DAYS_TO_DELIVERY'],
                                    y=profile_df['SETTLEMENT_PRICE_spread'],
                                    mode='lines',
                                    name=f"{spread} {year} {profile}",
                                    line=dict(color=year_to_color[year]),
                                    legendgroup=f"{year}",
                                    showlegend=(idx == 0),
                                    hovertemplate='Year: %{text}<br>Days: %{x}<br>Spread: %{y:.2f}<extra></extra>',
                                    text=[str(year)]*len(profile_df)
                                ),
                                row=row,
                                col=col
                            )

                    # Overlay realised delivered spread as a horizontal reference line
                    delivered_value = _find_delivered_spot_price(
                        delivered_spot_data, period, year, spread, is_spread=True
                    )
                    if delivered_value is not None:
                        min_x = 0 if not show_negative else min(period_df['DAYS_TO_DELIVERY'].min(), 0)
                        fig.add_trace(
                            go.Scatter(
                                x=[min_x, max_days],
                                y=[delivered_value, delivered_value],
                                mode='lines',
                                name=f"{spread} {year} Delivered",
                                line=dict(color=year_to_color[year], width=2, dash='dot'),
                                legendgroup=f"delivered_{year}",
                                showlegend=(idx == 0),
                                hovertemplate=f"<b>Delivered {spread} {year}:</b> {delivered_value:.2f} EUR/MWh<extra></extra>",
                            ),
                            row=row, col=col,
                        )

            # Add country price traces if countries are selected
            if countries:
                for country in countries:
                    price_col = f'SETTLEMENT_PRICE_{country.upper()}'
                    if price_col in period_df.columns:
                        country_df = period_df.copy()
                        
                        for year in years:
                            year_country_df = country_df[country_df['year'] == year].sort_values('DAYS_TO_DELIVERY', ascending=False)
                            
                            if year_country_df.empty:
                                continue
                            
                            # Handle profile selection for countries
                            if profile == "Both":
                                # Add Base trace
                                base_df = year_country_df[year_country_df['PROFILE'] == 'Base']
                                if not base_df.empty and not base_df[price_col].isna().all():
                                    fig.add_trace(
                                        go.Scatter(
                                            x=base_df['DAYS_TO_DELIVERY'],
                                            y=base_df[price_col],
                                            mode='lines',
                                            name=f"{country.upper()} {year} Base",
                                            line=dict(color=year_to_color[year], width=1),
                                            legendgroup=f"{year}",
                                            showlegend=(idx == 0),
                                            hovertemplate=f'{country.upper()} {{text}}<br>Days: {{x}}<br>Price: {{y:.2f}}<extra></extra>',
                                            text=[str(year)]*len(base_df)
                                        ),
                                        row=row,
                                        col=col
                                    )
                                
                                # Add Peak trace
                                peak_df = year_country_df[year_country_df['PROFILE'] == 'Peak']
                                if not peak_df.empty and not peak_df[price_col].isna().all():
                                    fig.add_trace(
                                        go.Scatter(
                                            x=peak_df['DAYS_TO_DELIVERY'],
                                            y=peak_df[price_col],
                                            mode='lines',
                                            name=f"{country.upper()} {year} Peak",
                                            line=dict(color=year_to_color[year], dash='dash', width=1),
                                            legendgroup=f"{year}",
                                            showlegend=(idx == 0),
                                            hovertemplate=f'{country.upper()} {{text}}<br>Days: {{x}}<br>Price: {{y:.2f}}<extra></extra>',
                                            text=[str(year)]*len(peak_df)
                                        ),
                                        row=row,
                                        col=col
                                    )
                            else:
                                # Single profile
                                profile_df = year_country_df[year_country_df['PROFILE'] == profile]
                                if not profile_df.empty and not profile_df[price_col].isna().all():
                                    fig.add_trace(
                                        go.Scatter(
                                            x=profile_df['DAYS_TO_DELIVERY'],
                                            y=profile_df[price_col],
                                            mode='lines',
                                            name=f"{country.upper()} {year} {profile}",
                                            line=dict(color=year_to_color[year], width=1),
                                            legendgroup=f"{year}",
                                            showlegend=(idx == 0),
                                            hovertemplate=f'{country.upper()} {{text}}<br>Days: {{x}}<br>Price: {{y:.2f}}<extra></extra>',
                                            text=[str(year)]*len(profile_df)
                                        ),
                                        row=row,
                                        col=col
                                    )

                            # Overlay realised delivered country spot price as a horizontal line
                            delivered_country_value = _find_delivered_spot_price(
                                delivered_spot_data, period, year, country, is_spread=False
                            )
                            if delivered_country_value is not None:
                                min_x = 0 if not show_negative else min(period_df['DAYS_TO_DELIVERY'].min(), 0)
                                fig.add_trace(
                                    go.Scatter(
                                        x=[min_x, max_days],
                                        y=[delivered_country_value, delivered_country_value],
                                        mode='lines',
                                        name=f"{country.upper()} {year} Delivered",
                                        line=dict(color=year_to_color[year], width=1, dash='dot'),
                                        legendgroup=f"delivered_{year}",
                                        showlegend=(idx == 0),
                                        hovertemplate=f"<b>Delivered {country.upper()} {year}:</b> {delivered_country_value:.2f} EUR/MWh<extra></extra>",
                                    ),
                                    row=row, col=col,
                                )

        # Update layout
        days_display = "All" if is_all_button else str(days_state)
        profile_text = f" ({profile})" if profile != "Both" else ""
        
        # Calculate total height based on number of rows
        total_height = plot_height + 100
        
        fig.update_layout(
            hovermode='closest',
            template='seaborn',
            height=total_height,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="center",
                x=0.5,
                groupclick="togglegroup"
            ),
            margin=dict(l=40, r=40, t=100, b=60),
            uirevision=f'xb_{tenor}_{profile}'
        )
        
        # Update axes for each subplot
        for i in range(1, rows + 1):
            for j in range(1, cols + 1):
                # Set x-axis range
                fig.update_xaxes(
                    title_text="Days to average delivery (contract)",
                    autorange="reversed",
                    row=i,
                    col=j
                )
                
                fig.update_yaxes(
                    title_text="Price / Spread (EUR/MWh)",
                    row=i,
                    col=j
                )
                # Add zero line for spreads
                fig.add_hline(y=0, line_dash="dash", line_color="gray", row=i, col=j)
        
        return fig
        
    except Exception as e:
        logger.error(f"Error creating XB spreads chart: {e}", exc_info=True)
        # Return empty figure on error
        fig = go.Figure()
        fig.update_layout(
            title="Error creating chart",
            template='seaborn',
            annotations=[dict(
                text=f"Error: {str(e)}",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=14, color="red")
            )]
        )
        return fig
