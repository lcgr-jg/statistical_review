"""Shared days button component for filtering by time range."""
import dash_bootstrap_components as dbc


def get_days_buttons(button_id_prefix):
    """
    Get standardized days button group.
    
    Args:
        button_id_prefix: Prefix for button IDs (e.g., 'css', 'basepeak', 'xb', 'flat')
    """
    days_options = [30, 60, 90, 180, 365, "All"]
    
    return dbc.ButtonGroup([
        dbc.Button(
            f"{days}D" if days != "All" else "All",
            id={"type": f"{button_id_prefix}-days-button", "value": days},
            color="primary",
            outline=True,
            size="sm",
            className="days-button me-2"
        )
        for days in days_options
    ], className="d-flex justify-content-center my-3")

