"""Shared navigation bar component for all dashboard pages."""
import dash_bootstrap_components as dbc


def get_navbar(active_page=None):
    """
    Get standardized navigation bar for all pages.
    
    Args:
        active_page: One of 'home', 'css-dss', 'base-peak', 'xb-spreads', 'flat-price', 'spot'
    """
    nav_items = [
        {"label": "Home", "href": "/", "id": "home"},
        {"label": "CSS/DSS", "href": "/css-dss", "id": "css-dss"},
        {"label": "Base/Peak", "href": "/base-peak", "id": "base-peak"},
        {"label": "XB Spreads", "href": "/xb-spreads", "id": "xb-spreads"},
        {"label": "Flat Price", "href": "/flat-price", "id": "flat-price"},
        {"label": "Spot", "href": "/spot", "id": "spot"},
        {"label": "Fundamentals", "href": "http://localhost:9001/", "id": "fundamentals"},
        {"label": "Stack", "href": "http://localhost:9005/", "id": "stack"}
    ]
    
    return dbc.Navbar(
        [
            dbc.NavbarBrand("Power Market Dashboard", href="/", className="ms-2"),
            dbc.Nav(
                [
                    dbc.NavItem(
                        dbc.NavLink(
                            item["label"],
                            href=item["href"],
                            active=(active_page == item["id"]),
                            external_link=True
                        )
                    )
                    for item in nav_items
                ],
                className="ms-auto",
                navbar=True
            )
        ],
        color="primary",
        dark=True,
        className="mb-4"
    )

