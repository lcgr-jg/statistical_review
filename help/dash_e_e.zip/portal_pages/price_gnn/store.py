"""Reader for Price GNN research-published forecasts and backtest artefacts.
==========================================================================

The Price GNN production path (``eu_heatrate_model``) publishes to::

    s3://jg-tech1prod-s3-eu-gas-power/commodity-data-cache/heatrate/
      {component}/
        forecasts/as_of=YYYY-MM-DD/
          fan.parquet            <- consolidated member fan (single-GET read)
          manifest.json          <- run provenance (issue dates, members, anchors)
          region=*/scenario=*/   <- ~3,500 per-member partitions (NOT read here)
        latest_success.json      <- pointer, flipped only after a full publish
        backtest/run_id={id}/
          hourly.parquet         <- compact test-split predictions vs realised
          run_meta.json

The component defaults to the *research* prefix: the model's calibration is
still under investigation, so nothing here reads the production component
unless explicitly re-pointed via ``PRICE_GNN_COMPONENT``.

This module reads those artefacts directly (boto3 via the jain_commods ``S3``
helper) rather than importing ``eu_heatrate_model``, so the dashboard image
does not need torch or the model toolchain. ``PRICE_GNN_LOCAL`` points at a
directory mirroring the component layout for offline development.
"""
from __future__ import annotations

import io
import json
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from core.cache import cached_result

logger = logging.getLogger(__name__)

S3_ROOT = "commodity-data-cache/heatrate"
DEFAULT_COMPONENT = "flow_gnn_price_research"

# Used only when backtest/index.json cannot be read; the real default is the
# newest run in the index (see resolve_backtest_run).
FALLBACK_BACKTEST_RUN = "v6"

# Optional per-run tables. hourly.parquet + run_meta.json are guaranteed for
# every run in the index; everything here must be treated as possibly absent
# (run_meta["files"] lists what was actually published).
BACKTEST_TABLES = (
    "metrics", "aggregate", "regime_metrics", "coverage",
    "scorecard", "by_lead", "by_origin", "by_regime",
)

# Columns of fan.parquet, kept in lock-step with _FAN_COLUMNS in
# eu_heatrate_model.io.flow_gnn_s3.
FAN_COLUMNS = [
    "target_date", "region", "forecast_family",
    "ensemble_member", "lead_hours", "price_eur_mwh",
]

# Published family tags (suffix of the scenario label).
FAMILY_ST = "ec-ens"   # short term, 51 members, 14 days
FAMILY_MT = "ec-ext"   # medium term, 101 members, 46 days


def _component() -> str:
    return os.environ.get("PRICE_GNN_COMPONENT", DEFAULT_COMPONENT)


def component_prefix() -> str:
    """Bucket-relative key prefix of the component root."""
    return f"{S3_ROOT}/{_component()}"


# ---------------------------------------------------------------------------
# Backends
# ---------------------------------------------------------------------------

def _s3_client():
    """boto3 client from the jain_commods helper, or None when unavailable."""
    try:
        from jain_commods.core.cache.utils.s3 import S3
        helper = S3()
        return helper.get_client(), helper.bucket_name
    except Exception as e:  # noqa: BLE001 - import or credential failure
        logger.warning("jain_commods S3 unavailable for price GNN store: %s", e)
        return None


def _local_root() -> Optional[Path]:
    """Local mirror of the component layout, when configured (dev)."""
    raw = os.environ.get("PRICE_GNN_LOCAL")
    if not raw:
        return None
    path = Path(raw)
    return path if path.exists() else None


def _is_missing_key(exc: Exception) -> bool:
    """True for a plain 'object does not exist' S3 error."""
    response = getattr(exc, "response", None)
    if not isinstance(response, dict):
        return False
    code = str((response.get("Error") or {}).get("Code", ""))
    return code in ("NoSuchKey", "NoSuchBucket", "404", "NotFound")


def _read_bytes(rel_key: str) -> Optional[bytes]:
    """Read one object by key relative to the component root. Local first."""
    root = _local_root()
    if root is not None:
        path = root / rel_key
        if path.exists():
            return path.read_bytes()

    client = _s3_client()
    if client is None:
        return None
    c, bucket = client
    key = f"{component_prefix()}/{rel_key}"
    try:
        return c.get_object(Bucket=bucket, Key=key)["Body"].read()
    except Exception as e:  # noqa: BLE001
        # Optional artefacts are absent by design (a fixed-split run has no
        # walk-forward tables), so a missing key is not a problem worth
        # shouting about; anything else is.
        if _is_missing_key(e):
            logger.debug("No object at s3://%s/%s", bucket, key)
        else:
            logger.warning("Could not read s3://%s/%s: %s", bucket, key, e)
        return None


def _read_json(rel_key: str) -> Optional[dict]:
    raw = _read_bytes(rel_key)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception as e:  # noqa: BLE001
        logger.warning("Malformed JSON at %s: %s", rel_key, e)
        return None


def _read_parquet(rel_key: str) -> Optional[pd.DataFrame]:
    raw = _read_bytes(rel_key)
    if raw is None:
        return None
    try:
        return pd.read_parquet(io.BytesIO(raw))
    except Exception as e:  # noqa: BLE001
        logger.warning("Could not parse parquet at %s: %s", rel_key, e)
        return None


# ---------------------------------------------------------------------------
# Production forecast reads
# ---------------------------------------------------------------------------

@cached_result(ttl_seconds=900, key_prefix="pgnn_latest")
def latest_success() -> Optional[Dict]:
    """The atomic 'last good run' pointer, or None when nothing is published."""
    return _read_json("latest_success.json")


@cached_result(ttl_seconds=3600, key_prefix="pgnn_manifest")
def manifest(as_of: str) -> Optional[Dict]:
    """Run provenance: issue dates, member counts, anchors, warnings, errors."""
    return _read_json(f"forecasts/as_of={as_of}/manifest.json")


@cached_result(ttl_seconds=1800, key_prefix="pgnn_fan")
def load_fan(as_of: str) -> Optional[pd.DataFrame]:
    """The consolidated member fan for one run (~3M rows, one GET).

    Columns: target_date (naive UTC hourly), region (upper-case zone),
    forecast_family (ec-ens | ec-ext), ensemble_member (e00..), lead_hours,
    price_eur_mwh.
    """
    fan = _read_parquet(f"forecasts/as_of={as_of}/fan.parquet")
    if fan is None:
        return None
    missing = [c for c in FAN_COLUMNS if c not in fan.columns]
    if missing:
        logger.warning("fan.parquet for %s lacks columns %s", as_of, missing)
        return None
    return fan


@cached_result(ttl_seconds=900, key_prefix="pgnn_asof_list")
def list_as_of() -> List[str]:
    """Published run dates, oldest first."""
    dates: set = set()

    root = _local_root()
    if root is not None:
        for p in (root / "forecasts").glob("as_of=*"):
            dates.add(p.name.split("=", 1)[1])

    client = _s3_client()
    if client is not None:
        c, bucket = client
        prefix = f"{component_prefix()}/forecasts/"
        try:
            paginator = c.get_paginator("list_objects_v2")
            for page in paginator.paginate(
                Bucket=bucket, Prefix=prefix, Delimiter="/",
            ):
                for cp in page.get("CommonPrefixes", []):
                    part = cp["Prefix"][len(prefix):].strip("/")
                    if part.startswith("as_of="):
                        dates.add(part.split("=", 1)[1])
        except Exception as e:  # noqa: BLE001
            logger.warning("S3 as_of listing failed: %s", e)

    return sorted(dates)


def latest_run() -> Optional[str]:
    """as_of of the newest fully-published run (via the atomic pointer)."""
    pointer = latest_success()
    if pointer and pointer.get("as_of"):
        return str(pointer["as_of"])
    runs = list_as_of()
    return runs[-1] if runs else None


# ---------------------------------------------------------------------------
# Backtest reads
# ---------------------------------------------------------------------------

@cached_result(ttl_seconds=900, key_prefix="pgnn_bt_index")
def backtest_index() -> Dict:
    """Catalogue of every published run.

    The publisher writes index.json last, so any run listed here has all of
    its files in place. Shape: {"component", "updated_at", "runs": {id: {...}}}.
    """
    return _read_json("backtest/index.json") or {"runs": {}}


def list_backtest_runs() -> List[Dict]:
    """Index entries, newest ``published_at`` first (for a run selector)."""
    runs = list((backtest_index().get("runs") or {}).values())
    return sorted(runs, key=lambda r: str(r.get("published_at") or ""),
                  reverse=True)


def resolve_backtest_run(run_id: Optional[str] = None) -> Optional[str]:
    """A concrete run id: the argument, else the newest published run."""
    if run_id:
        return str(run_id)
    runs = list_backtest_runs()
    if runs and runs[0].get("run_id"):
        return str(runs[0]["run_id"])
    return FALLBACK_BACKTEST_RUN


def backtest_run_entry(run_id: Optional[str] = None) -> Dict:
    """The index entry for one run ({} when the run is not catalogued)."""
    run = resolve_backtest_run(run_id)
    runs = (backtest_index().get("runs") or {})
    return dict(runs.get(run) or {})


def load_backtest_hourly(run_id: Optional[str] = None) -> Optional[pd.DataFrame]:
    """Compact test-split predictions: timestamp (naive UTC), border
    (lower-case zone), split, y_true, y_pred, and where published
    y_baseline, y_persist, regime, denom, origin, lead_days."""
    run = resolve_backtest_run(run_id)
    return _load_backtest_hourly(run) if run else None


@cached_result(ttl_seconds=86400, key_prefix="pgnn_backtest")
def _load_backtest_hourly(run_id: str) -> Optional[pd.DataFrame]:
    return _read_parquet(f"backtest/run_id={run_id}/hourly.parquet")


def backtest_meta(run_id: Optional[str] = None) -> Optional[Dict]:
    """run_meta.json: identity, window, provenance, headline metrics, zone_r2."""
    run = resolve_backtest_run(run_id)
    return _backtest_meta(run) if run else None


@cached_result(ttl_seconds=86400, key_prefix="pgnn_backtest_meta")
def _backtest_meta(run_id: str) -> Optional[Dict]:
    return _read_json(f"backtest/run_id={run_id}/run_meta.json")


def load_backtest_table(run_id: Optional[str],
                        name: str) -> Optional[pd.DataFrame]:
    """One optional per-run parquet table by name, e.g. ``metrics``,
    ``regime_metrics``, ``by_lead``. None when that run did not publish it."""
    run = resolve_backtest_run(run_id)
    return _load_backtest_table(run, name) if run else None


@cached_result(ttl_seconds=86400, key_prefix="pgnn_bt_table")
def _load_backtest_table(run_id: str, name: str) -> Optional[pd.DataFrame]:
    return _read_parquet(f"backtest/run_id={run_id}/{name}.parquet")


# ---------------------------------------------------------------------------
# Status for freshness badges
# ---------------------------------------------------------------------------

def store_status() -> Dict[str, object]:
    """Summary for the run-health view and the freshness tracker."""
    pointer = latest_success() or {}
    as_of = pointer.get("as_of")
    return {
        "component": _component(),
        "as_of": as_of,
        "promoted_at": pointer.get("promoted_at"),
        "model_run_id": pointer.get("model_run_id"),
        "n_partitions": pointer.get("n_partitions"),
        "available_runs": list_as_of(),
    }
