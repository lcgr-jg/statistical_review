"""Plotly figure builders for the Price GNN pages.

All builders take tidy frames from :mod:`.store` / :mod:`.contracts` and
return styled figures via ``apply_chart_style`` so the section matches the
rest of the portal. The hourly fan and spaghetti are ports of the model
repo's ``flow_gnn/dashboard/views_scenarios.py`` fan logic, re-based onto the
published ``fan.parquet`` long format.
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from portal_pages.fundamentals.styles import apply_chart_style, styled_empty_figure

FAMILY_LABEL = {"ec-ens": "EC-ENS (ST, 14d)", "ec-ext": "EC-EXT (MT, 46d)"}

_FAN_FILL = "rgba(70,130,180,0.16)"
_FAN_FILL_INNER = "rgba(70,130,180,0.28)"
_FAN_LINE = "steelblue"
_MEAN_LINE = "#1a3a5c"

_MEMBER_COLOURS = [
    "#4E738A", "#c94a2e", "#2ea043", "#d4a017", "#6f42c1",
    "#0969da", "#8b0000", "#7b9e3a", "#b08800", "#6c757d",
]


def member_wide(fan: pd.DataFrame, zone: str, family: str) -> pd.DataFrame:
    """Pivot one (zone, family) slice of fan.parquet to [hour x member]."""
    sub = fan[(fan["region"] == zone) & (fan["forecast_family"] == family)]
    if sub.empty:
        return pd.DataFrame()
    return sub.pivot_table(
        index="target_date", columns="ensemble_member",
        values="price_eur_mwh", aggfunc="first",
    ).sort_index()


def fig_hourly_fan(
    wide: pd.DataFrame, zone: str, family: str, resample: Optional[str] = None,
) -> go.Figure:
    """P10/P25/median/P75/P90 band + member mean across the ensemble."""
    if wide.empty:
        return styled_empty_figure(f"No forecast data for {zone}")
    if resample:
        wide = wide.resample(resample).mean()

    q = wide.quantile([0.10, 0.25, 0.50, 0.75, 0.90], axis=1).T
    mean = wide.mean(axis=1)
    x = q.index

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=list(x) + list(x[::-1]),
        y=list(q[0.90]) + list(q[0.10][::-1]),
        fill="toself", fillcolor=_FAN_FILL,
        line=dict(color="rgba(0,0,0,0)"), hoverinfo="skip",
        name="P10\u2013P90",
    ))
    fig.add_trace(go.Scatter(
        x=list(x) + list(x[::-1]),
        y=list(q[0.75]) + list(q[0.25][::-1]),
        fill="toself", fillcolor=_FAN_FILL_INNER,
        line=dict(color="rgba(0,0,0,0)"), hoverinfo="skip",
        name="P25\u2013P75",
    ))
    fig.add_trace(go.Scatter(
        x=x, y=q[0.50], mode="lines", name="Median",
        line=dict(color=_FAN_LINE, width=1.4, dash="dot"),
    ))
    fig.add_trace(go.Scatter(
        x=x, y=mean, mode="lines", name="Member mean",
        line=dict(color=_MEAN_LINE, width=2.2),
    ))
    fig.update_layout(title=(
        f"{zone}: ensemble price fan \u2014 {FAMILY_LABEL.get(family, family)} "
        f"({wide.shape[1]} members)"
    ))
    fig.update_yaxes(title_text="EUR/MWh")
    return apply_chart_style(fig, height=460)


def fig_spaghetti(
    wide: pd.DataFrame, zone: str, family: str,
    resample: Optional[str] = "D", max_members: int = 60,
) -> go.Figure:
    """One faint line per member (daily mean by default), mean on top."""
    if wide.empty:
        return styled_empty_figure(f"No forecast data for {zone}")
    if resample:
        wide = wide.resample(resample).mean()

    fig = go.Figure()
    cols = list(wide.columns)[:max_members]
    for i, member in enumerate(cols):
        fig.add_trace(go.Scatter(
            x=wide.index, y=wide[member], mode="lines", name=member,
            line=dict(color=_MEMBER_COLOURS[i % len(_MEMBER_COLOURS)], width=0.7),
            opacity=0.35, showlegend=False,
            hovertemplate=f"{member}: %{{y:.1f}} EUR/MWh<extra></extra>",
        ))
    fig.add_trace(go.Scatter(
        x=wide.index, y=wide.mean(axis=1), mode="lines", name="Member mean",
        line=dict(color=_MEAN_LINE, width=2.4),
    ))
    fig.update_layout(title=(
        f"{zone}: member spaghetti \u2014 {FAMILY_LABEL.get(family, family)}"
        + (f" (daily means, first {max_members} members)" if resample else "")
    ), hovermode="closest")
    fig.update_yaxes(title_text="EUR/MWh")
    return apply_chart_style(fig, height=460)


def fig_member_distribution(
    values: pd.Series, title: str,
    realised: Optional[float] = None,
    quantiles: Sequence[float] = (0.05, 0.25, 0.50, 0.75, 0.95),
) -> go.Figure:
    """Violin + rug of per-member contract prices, with an optional realised marker."""
    vals = pd.Series(values).dropna()
    if vals.empty:
        return styled_empty_figure("No fully-covered members for this contract")

    fig = go.Figure()
    fig.add_trace(go.Violin(
        x=vals.values, name="members",
        orientation="h", side="positive", width=1.6,
        points="all", pointpos=-0.25, jitter=0.18, marker=dict(size=4, opacity=0.55),
        line_color="#4E738A", fillcolor="rgba(78,115,138,0.18)",
        meanline_visible=True, hoveron="points",
        hovertemplate="%{x:.2f} EUR/MWh<extra></extra>",
    ))
    for qv in quantiles:
        xq = float(vals.quantile(qv))
        fig.add_vline(x=xq, line_dash="dot", line_color="#9aa5ad", line_width=1,
                      annotation_text=f"p{int(qv * 100)}",
                      annotation_position="top",
                      annotation_font=dict(size=10, color="#6c757d"))
    if realised is not None and np.isfinite(realised):
        fig.add_vline(x=float(realised), line_color="#c94a2e", line_width=2,
                      annotation_text="realised", annotation_position="bottom",
                      annotation_font=dict(size=11, color="#c94a2e"))
    fig.update_layout(title=title, showlegend=False)
    fig.update_xaxes(title_text="EUR/MWh")
    fig.update_yaxes(visible=False)
    return apply_chart_style(fig, height=380)


def fig_pred_vs_realised(df: pd.DataFrame, title: str) -> go.Figure:
    """Contract-level predicted vs realised scatter with the identity line."""
    if df.empty:
        return styled_empty_figure("No scored contracts in this selection")
    lo = float(min(df["y_true"].min(), df["y_pred"].min()))
    hi = float(max(df["y_true"].max(), df["y_pred"].max()))
    pad = (hi - lo) * 0.05 or 1.0
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=[lo - pad, hi + pad], y=[lo - pad, hi + pad], mode="lines",
        name="realised = predicted", line=dict(color="#9aa5ad", dash="dash", width=1),
    ))
    fig.add_trace(go.Scatter(
        x=df["y_true"], y=df["y_pred"], mode="markers", name="contracts",
        marker=dict(size=5, opacity=0.55, color="#4E738A"),
        text=df.get("hover"),
        hovertemplate="%{text}<br>realised %{x:.1f} / predicted %{y:.1f}<extra></extra>",
    ))
    fig.update_layout(title=title, hovermode="closest")
    fig.update_xaxes(title_text="Realised EUR/MWh")
    fig.update_yaxes(title_text="Predicted EUR/MWh")
    return apply_chart_style(fig, height=460)


_SERIES_STYLE = {
    "y_true": dict(color="#231F20", width=2.0, label="Realised"),
    "y_pred": dict(color="#4E738A", width=1.8, label="GNN"),
    "y_baseline": dict(color="#d4a017", width=1.2, label="Anchored baseline"),
    "y_persist": dict(color="#9aa5ad", width=1.0, label="24h persistence"),
}


def fig_backtest_series(wide: pd.DataFrame, title: str) -> go.Figure:
    """Realised vs predicted through the test window (CET-indexed)."""
    if wide is None or wide.empty:
        return styled_empty_figure("No backtest rows for this selection")
    fig = go.Figure()
    for col in ("y_true", "y_pred", "y_baseline", "y_persist"):
        if col not in wide.columns or wide[col].isna().all():
            continue
        style = _SERIES_STYLE[col]
        fig.add_trace(go.Scatter(
            x=wide.index, y=wide[col], mode="lines", name=style["label"],
            line=dict(color=style["color"], width=style["width"]),
            hovertemplate=(f"{style['label']}: %{{y:.1f}} EUR/MWh"
                           "<extra></extra>"),
        ))
    fig.update_layout(title=title, hovermode="x unified")
    fig.update_yaxes(title_text="EUR/MWh")
    fig.update_xaxes(title_text="Delivery (CET)")
    return apply_chart_style(fig, height=430)


def fig_error_by_hour(frame: pd.DataFrame, title: str) -> go.Figure:
    """GNN bias and MAE by CET hour of day."""
    if frame is None or frame.empty:
        return styled_empty_figure("No errors to profile")
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=frame["hour"], y=frame["bias"], name="Bias",
        marker_color="#4E738A", opacity=0.85,
        hovertemplate="hour %{x}: bias %{y:+.2f}<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=frame["hour"], y=frame["mae"], mode="lines+markers", name="MAE",
        line=dict(color="#c94a2e", width=2),
        hovertemplate="hour %{x}: MAE %{y:.2f}<extra></extra>",
    ))
    fig.add_hline(y=0.0, line_color="#231F20", line_width=1)
    fig.update_layout(title=title, hovermode="x unified", barmode="relative")
    fig.update_xaxes(title_text="Hour of day (CET)", dtick=2)
    fig.update_yaxes(title_text="EUR/MWh")
    return apply_chart_style(fig, height=380)


def fig_zone_metric(df: pd.DataFrame, metric: str, title: str) -> go.Figure:
    """Per-zone metric bars, worst first for R² and best first for errors."""
    if df is None or df.empty or metric not in df.columns:
        return styled_empty_figure("No per-zone metrics published for this run")
    frame = df.dropna(subset=[metric]).copy()
    if frame.empty:
        return styled_empty_figure(f"No {metric} values in this run")
    ascending = metric in ("r2", "sign_accuracy", "skill_vs_persistence",
                           "skill_vs_baseline")
    frame = frame.sort_values(metric, ascending=ascending)
    colours = ["#c94a2e" if v < 0 else "#4E738A" for v in frame[metric]]
    fig = go.Figure(go.Bar(
        x=frame[metric], y=frame["zone"], orientation="h",
        marker_color=colours,
        hovertemplate="%{y}: %{x:.3f}<extra></extra>",
    ))
    fig.update_layout(title=title, showlegend=False)
    fig.update_xaxes(title_text=metric)
    fig.update_yaxes(title_text="", automargin=True)
    return apply_chart_style(fig, height=max(360, 18 * len(frame) + 120))


def fig_walk_forward(df: pd.DataFrame, key: str, metric: str,
                     title: str) -> go.Figure:
    """Walk-forward metric against lead days, retrain origin or regime."""
    if df is None or df.empty or key not in df.columns:
        return styled_empty_figure("Not a walk-forward run")
    if metric not in df.columns:
        return styled_empty_figure(f"{metric} not published for this run")
    frame = df.dropna(subset=[metric]).sort_values(key)
    if frame.empty:
        return styled_empty_figure(f"No {metric} values to plot")
    is_line = key in ("lead_days", "origin")
    if is_line:
        trace = go.Scatter(
            x=frame[key], y=frame[metric], mode="lines+markers",
            line=dict(color="#4E738A", width=2), marker=dict(size=6),
            name=metric,
            hovertemplate="%{x}: %{y:.3f}<extra></extra>",
        )
    else:
        label_col = "regime_name" if "regime_name" in frame.columns else key
        trace = go.Bar(x=frame[label_col].astype(str), y=frame[metric],
                       marker_color="#4E738A", name=metric,
                       hovertemplate="%{x}: %{y:.3f}<extra></extra>")
    fig = go.Figure(trace)
    fig.update_layout(title=title, showlegend=False, hovermode="x")
    fig.update_xaxes(title_text={"lead_days": "Days since retrain",
                                 "origin": "Retrain origin"}.get(key, key))
    fig.update_yaxes(title_text=metric)
    return apply_chart_style(fig, height=380)


def fig_error_histogram(errors: pd.Series, title: str) -> go.Figure:
    """Contract price error (predicted - realised) distribution."""
    vals = pd.Series(errors).dropna()
    if vals.empty:
        return styled_empty_figure("No errors to plot")
    fig = go.Figure(go.Histogram(
        x=vals.values, nbinsx=60, marker_color="#4E738A", opacity=0.85,
    ))
    fig.add_vline(x=0.0, line_color="#231F20", line_width=1)
    fig.add_vline(x=float(vals.mean()), line_color="#c94a2e", line_dash="dash",
                  annotation_text=f"bias {vals.mean():+.1f}",
                  annotation_font=dict(size=11, color="#c94a2e"))
    fig.update_layout(title=title, showlegend=False, hovermode="x")
    fig.update_xaxes(title_text="Predicted \u2212 realised (EUR/MWh)")
    fig.update_yaxes(title_text="Contracts")
    return apply_chart_style(fig, height=380)
