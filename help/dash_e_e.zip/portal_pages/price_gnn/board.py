"""Contract Board tab: zone x contract member distributions for one run.

The board answers the desk question "where does the model put each tradeable
block, and how wide is the ensemble around it" -- mean with P10-P90 per zone
and contract, plus an hourly fan and member spaghetti for a selected zone.
"""
from __future__ import annotations

import logging

import pandas as pd
from dash import Input, Output, dash_table, dcc, html

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
)

from . import compute, figures, store

logger = logging.getLogger(__name__)

# Persistent calibration warning. Measured on issue 2026-08-27 (fully realised
# out-of-sample window): 80% band coverage 27.8%, realised above P90 in 61.9%
# of zone-hours, mean PIT 0.779. Do not remove this banner until a re-measured
# PIT is close to flat.
CALIBRATION_BANNER = (
    "Calibration warning: the ensemble fan is known to sit LOW and TIGHT versus "
    "realised spot (measured 2026-08-27: 80% band covered only 27.8% of outcomes; "
    "realised exceeded P90 in 62% of zone-hours). Treat levels as a relative view, "
    "not a tradeable price. See the Backtest tab for skill by contract."
)

_BANNER_STYLE = {
    "backgroundColor": "#fdf2ef",
    "border": "1px solid #e8b4a5",
    "borderRadius": "8px",
    "color": "#9a3412",
    "padding": "12px 16px",
    "fontSize": "13px",
    "marginBottom": "16px",
}


def _dropdown(id_, options, value, width="220px", clearable=False):
    return html.Div(
        style={"width": width, "marginRight": "18px"},
        children=[dcc.Dropdown(id=id_, options=options, value=value,
                               clearable=clearable)],
    )


def get_layout():
    runs = store.list_as_of()
    latest = store.latest_run()
    run_options = [{"label": r, "value": r} for r in runs] or (
        [{"label": latest, "value": latest}] if latest else [])

    return html.Div([
        html.Div(CALIBRATION_BANNER, style=_BANNER_STYLE),

        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div(style={"display": "flex", "flexWrap": "wrap",
                            "alignItems": "flex-end", "gap": "6px"}, children=[
                html.Div([
                    html.Label("Run (as_of)", style=LABEL_STYLE),
                    _dropdown("pgnn-board-run", run_options, latest),
                ]),
                html.Div([
                    html.Label("Shape", style=LABEL_STYLE),
                    _dropdown("pgnn-board-shape",
                              [{"label": "Base", "value": "Base"},
                               {"label": "Peak", "value": "Peak"}], "Base",
                              width="130px"),
                ]),
                html.Div([
                    html.Label("Family", style=LABEL_STYLE),
                    _dropdown("pgnn-board-family",
                              [{"label": "Auto (ST where covered)", "value": "auto"},
                               {"label": "EC-ENS (ST)", "value": store.FAMILY_ST},
                               {"label": "EC-EXT (MT)", "value": store.FAMILY_MT}],
                              "auto", width="220px"),
                ]),
            ]),
        ]),

        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.P("Contract board \u2014 member mean (P10 \u2013 P90), EUR/MWh",
                       style=CARD_HEADER_TEXT_STYLE),
            ]),
            html.Div(style={"padding": "12px 16px", "overflowX": "auto"},
                     children=[dcc.Loading(html.Div(id="pgnn-board-table"))]),
        ]),

        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div(style={"display": "flex", "alignItems": "flex-end"}, children=[
                html.Div([
                    html.Label("Zone (fan / spaghetti)", style=LABEL_STYLE),
                    _dropdown("pgnn-board-zone", [], None, width="160px"),
                ]),
                html.Div([
                    html.Label("Fan family", style=LABEL_STYLE),
                    _dropdown("pgnn-board-fan-family",
                              [{"label": "EC-ENS (ST)", "value": store.FAMILY_ST},
                               {"label": "EC-EXT (MT)", "value": store.FAMILY_MT}],
                              store.FAMILY_ST, width="180px"),
                ]),
            ]),
        ]),

        html.Div(style=CARD_STYLE, children=[
            dcc.Loading(dcc.Graph(id="pgnn-board-fan")),
        ]),
        html.Div(style=CARD_STYLE, children=[
            dcc.Loading(dcc.Graph(id="pgnn-board-spaghetti")),
        ]),
    ])


def _board_cells(summary: pd.DataFrame, shape: str, family_mode: str):
    """DataTable rows: contracts in delivery order, one column per zone."""
    df = summary[summary["shape"] == shape].copy()
    if family_mode == "auto":
        df = df[df["preferred"]]
    else:
        df = df[df["family"] == family_mode]
    if df.empty:
        return None

    contracts = compute.contract_order(df)
    zones = sorted(df["region"].unique())

    def fmt(row) -> str:
        if row is None or not row["n_members"]:
            return "n/a"
        return f"{row['mean']:.1f}  ({row['p10']:.0f}\u2013{row['p90']:.0f})"

    lookup = {(r["region"], r["contract"]): r for _, r in df.iterrows()}
    records = []
    for contract in contracts:
        rec = {"Contract": contract}
        fam = {lookup[(z, contract)]["family"]
               for z in zones if (z, contract) in lookup}
        rec["Fam"] = "/".join(sorted(f.replace("ec-", "").upper() for f in fam))
        for z in zones:
            rec[compute.zone_label(z)] = fmt(lookup.get((z, contract)))
        records.append(rec)

    columns = ([{"name": "Contract", "id": "Contract"}, {"name": "Fam", "id": "Fam"}]
               + [{"name": compute.zone_label(z), "id": compute.zone_label(z)}
                  for z in zones])
    return dash_table.DataTable(
        data=records,
        columns=columns,
        style_table={"overflowX": "auto"},
        style_cell={"fontSize": "12px", "fontFamily": "Inter, sans-serif",
                    "padding": "6px 10px", "textAlign": "center",
                    "whiteSpace": "nowrap"},
        style_cell_conditional=[
            {"if": {"column_id": "Contract"},
             "textAlign": "left", "fontWeight": "600", "minWidth": "150px"},
            {"if": {"column_id": "Fam"}, "color": "#6c757d"},
        ],
        style_header={"fontWeight": "600", "backgroundColor": "#f4f5f7",
                      "fontSize": "12px"},
        style_data_conditional=[
            {"if": {"filter_query": '{{{0}}} = "n/a"'.format(compute.zone_label(z)),
                    "column_id": compute.zone_label(z)},
             "color": "#b0b6bb"} for z in zones
        ],
    )


def register_callbacks(app):
    @app.callback(
        Output("pgnn-board-table", "children"),
        Output("pgnn-board-zone", "options"),
        Output("pgnn-board-zone", "value"),
        Input("pgnn-board-run", "value"),
        Input("pgnn-board-shape", "value"),
        Input("pgnn-board-family", "value"),
    )
    def update_board(as_of, shape, family_mode):
        if not as_of:
            return html.Div("No published runs found on the research prefix.",
                            style={"color": "#6c757d"}), [], None
        summary = compute.board_summary(as_of)
        if summary is None or summary.empty:
            return html.Div(f"Run {as_of}: fan.parquet not available.",
                            style={"color": "#6c757d"}), [], None
        table = _board_cells(summary, shape or "Base", family_mode or "auto")
        zones = sorted(summary["region"].unique())
        options = [{"label": compute.zone_label(z), "value": z} for z in zones]
        default = "DE" if "DE" in zones else (zones[0] if zones else None)
        if table is None:
            table = html.Div("No contracts covered for this selection.",
                             style={"color": "#6c757d"})
        return table, options, default

    @app.callback(
        Output("pgnn-board-fan", "figure"),
        Output("pgnn-board-spaghetti", "figure"),
        Input("pgnn-board-run", "value"),
        Input("pgnn-board-zone", "value"),
        Input("pgnn-board-fan-family", "value"),
    )
    def update_fan(as_of, zone, family):
        from portal_pages.fundamentals.styles import styled_empty_figure
        if not as_of or not zone:
            empty = styled_empty_figure("Select a run and zone")
            return empty, empty
        fan = store.load_fan(as_of)
        if fan is None:
            empty = styled_empty_figure(f"No fan data for {as_of}")
            return empty, empty
        wide = figures.member_wide(fan, zone, family or store.FAMILY_ST)
        return (
            figures.fig_hourly_fan(wide, compute.zone_label(zone), family),
            figures.fig_spaghetti(wide, compute.zone_label(zone), family),
        )
