"""Tradeable-contract aggregation for hourly power price forecasts.
================================================================

The Price GNN publishes *hourly* prices per (zone, ensemble member). A trading
desk quotes *contracts*: day-ahead, front weekend, front week, week+2, front
month -- each as a Base and (weekdays only) Peak block. This module is the one
place those contracts are defined, so the production forecast pages and the
backtest pages price the exact same windows.

Conventions (deliberately identical to the Stack model's product table in
``portal_pages/stack/pages/prices.py`` and the EPEX pages):

* Delivery windows are CET/CEST calendar windows (``Europe/Berlin``).
* Peak  = Mon-Fri, delivery hours 08:00-20:00 CET (clock hours 8..19).
* Base  = all hours in the window.
* Weekend products trade Base only.

The model's timestamps are tz-naive UTC (the panel index strips timezones
after converting to UTC), so aggregation localises to UTC then converts to
Berlin before applying the calendar masks. DST days (23/25 hours) fall out
correctly because expected hour counts are derived from the Berlin calendar,
not from ``days * 24``.

Coverage gate: a contract price is only reported when **100%** of the window's
delivery hours are present for that (zone, member). A Wk+2 base built from five
of seven days is a wrong number, not an approximate one; partially covered
windows surface as NaN with a ``coverage`` fraction so the UI can render
"n/a (partial)".
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Iterable, List, Optional, Sequence

import numpy as np
import pandas as pd

CET = "Europe/Berlin"

# Peak block: Mon-Fri, CET clock hours 8..19 inclusive (delivery 08:00-20:00).
PEAK_HOUR_START = 8
PEAK_HOUR_END = 20  # exclusive


@dataclass(frozen=True)
class ContractWindow:
    """One tradeable delivery window. ``end`` is exclusive (date granularity)."""

    label: str          # display label, e.g. "DA Tue 15 Sep", "Wk 39 (21 Sep)"
    kind: str           # "day" | "weekend" | "week" | "month"
    start: date         # first delivery date
    end: date           # exclusive end date
    has_peak: bool      # weekend blocks trade base only

    @property
    def days(self) -> int:
        return (self.end - self.start).days


# ---------------------------------------------------------------------------
# Window builders
# ---------------------------------------------------------------------------

def build_contract_windows(
    as_of: date,
    horizon_end: Optional[date] = None,
) -> List[ContractWindow]:
    """Forward contract windows for a run issued on *as_of*.

    First delivery day is ``as_of + 1`` (the production run scores from
    ``start_offset_days=1``). Windows: DA, remaining balance-of-week days,
    front weekend, Wk+1..Wk+3 and -- only when it fits entirely inside the
    horizon -- M+1. No quarters or calendars: the model reaches 46 days at
    most, so those contracts are unpriceable and must not appear on a board.

    *horizon_end* is the last delivery date available (inclusive). Windows
    that start beyond it are dropped; windows that merely extend past it are
    kept so the coverage gate can render them as partial rather than silently
    hiding them.
    """
    first = as_of + timedelta(days=1)
    windows: List[ContractWindow] = []

    # -- DA plus balance-of-week individual days (through Friday) ----------
    d = first
    while d.isoweekday() <= 5 and (d - first).days < 7:
        prefix = "DA" if d == first else "BOW"
        windows.append(ContractWindow(
            label=f"{prefix} {d.strftime('%a %d %b')}",
            kind="day", start=d, end=d + timedelta(days=1), has_peak=True,
        ))
        if d.isoweekday() == 5:
            break
        d += timedelta(days=1)
    if first.isoweekday() > 5:
        # Issued Fri/Sat: DA lands on the weekend and is a base-only day.
        windows.append(ContractWindow(
            label=f"DA {first.strftime('%a %d %b')}",
            kind="day", start=first, end=first + timedelta(days=1),
            has_peak=False,
        ))

    # -- Front weekend (next Sat+Sun on/after the first delivery day) ------
    sat = first + timedelta(days=(6 - first.isoweekday()) % 7)
    windows.append(ContractWindow(
        label=f"Wknd {sat.strftime('%d %b')}",
        kind="weekend", start=sat, end=sat + timedelta(days=2), has_peak=False,
    ))

    # -- Wk+1 .. Wk+3 (ISO weeks, Mon-Sun) ---------------------------------
    next_mon = as_of + timedelta(days=(8 - as_of.isoweekday()) % 7 or 7)
    for i in range(3):
        w_start = next_mon + timedelta(weeks=i)
        wk_num = w_start.isocalendar()[1]
        windows.append(ContractWindow(
            label=f"Wk+{i + 1} (Wk {wk_num}, {w_start.strftime('%d %b')})",
            kind="week", start=w_start, end=w_start + timedelta(days=7),
            has_peak=True,
        ))

    # -- M+1, only when the whole month is inside the horizon --------------
    ny = as_of.year + (as_of.month // 12)
    nm = as_of.month % 12 + 1
    m_start = date(ny, nm, 1)
    m_end = m_start + timedelta(days=calendar.monthrange(ny, nm)[1])
    if horizon_end is None or m_end - timedelta(days=1) <= horizon_end:
        windows.append(ContractWindow(
            label=f"M+1 ({calendar.month_abbr[nm]} {ny})",
            kind="month", start=m_start, end=m_end, has_peak=True,
        ))

    if horizon_end is not None:
        windows = [w for w in windows if w.start <= horizon_end]
    # De-duplicate (a Friday-issued run can produce DA == a weekend day) and
    # keep delivery order.
    seen = set()
    out: List[ContractWindow] = []
    for w in sorted(windows, key=lambda w: (w.start, w.days)):
        key = (w.start, w.end, w.has_peak)
        if key not in seen:
            seen.add(key)
            out.append(w)
    return out


def enumerate_history_windows(start: date, end: date) -> List[ContractWindow]:
    """Every day / weekend / ISO week / month window inside ``[start, end]``.

    Used by the backtest pages: rather than "the front week as of today", the
    history view scores every historical instance of each contract *type*.
    Only windows fully inside the range are emitted -- a truncated first week
    would fail the coverage gate anyway.
    """
    windows: List[ContractWindow] = []
    d = start
    while d <= end:
        windows.append(ContractWindow(
            label=d.isoformat(), kind="day",
            start=d, end=d + timedelta(days=1),
            has_peak=d.isoweekday() <= 5,
        ))
        if d.isoweekday() == 6 and d + timedelta(days=1) <= end:
            windows.append(ContractWindow(
                label=f"Wknd {d.isoformat()}", kind="weekend",
                start=d, end=d + timedelta(days=2), has_peak=False,
            ))
        if d.isoweekday() == 1 and d + timedelta(days=6) <= end:
            windows.append(ContractWindow(
                label=f"Wk {d.isocalendar()[1]} {d.year}", kind="week",
                start=d, end=d + timedelta(days=7), has_peak=True,
            ))
        if d.day == 1:
            m_end = d + timedelta(days=calendar.monthrange(d.year, d.month)[1])
            if m_end - timedelta(days=1) <= end:
                windows.append(ContractWindow(
                    label=f"{calendar.month_abbr[d.month]} {d.year}",
                    kind="month", start=d, end=m_end, has_peak=True,
                ))
        d += timedelta(days=1)
    return windows


# ---------------------------------------------------------------------------
# Calendar helpers
# ---------------------------------------------------------------------------

def _berlin_index(ts: pd.Series) -> pd.DatetimeIndex:
    """Model timestamps (naive UTC) -> tz-aware Berlin wall clock."""
    idx = pd.DatetimeIndex(ts)
    if idx.tz is None:
        idx = idx.tz_localize("UTC")
    return idx.tz_convert(CET)


def expected_hours(window: ContractWindow) -> int:
    """Delivery hours in the window on the Berlin calendar (DST-correct)."""
    rng = pd.date_range(
        pd.Timestamp(window.start, tz=CET),
        pd.Timestamp(window.end, tz=CET),
        freq="h", inclusive="left",
    )
    return len(rng)


def expected_peak_hours(window: ContractWindow) -> int:
    rng = pd.date_range(
        pd.Timestamp(window.start, tz=CET),
        pd.Timestamp(window.end, tz=CET),
        freq="h", inclusive="left",
    )
    mask = (rng.weekday < 5) & (rng.hour >= PEAK_HOUR_START) & (rng.hour < PEAK_HOUR_END)
    return int(mask.sum())


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

def aggregate_windows(
    df: pd.DataFrame,
    windows: Iterable[ContractWindow],
    *,
    time_col: str = "target_date",
    value_cols: Sequence[str] = ("price_eur_mwh",),
    group_cols: Sequence[str] = ("region", "ensemble_member"),
) -> pd.DataFrame:
    """Price each contract window from an hourly frame.

    Returns one row per (window, *group_cols*) with, for every value column,
    ``{col}_base`` and (peak windows only) ``{col}_peak``, plus ``coverage``
    (fraction of expected delivery hours present -- prices are NaN unless it
    is exactly 1.0) and the window's metadata columns.

    Works for both the production fan (group by zone + member, one value
    column) and the backtest history (group by zone, several value columns:
    ``y_true``, ``y_pred``, ...). Rows where a value column is NaN reduce that
    column's own coverage: a member that lacks hours prices as NaN without
    dragging down members that have them.
    """
    berlin = _berlin_index(df[time_col])
    hours = berlin.hour
    weekdays = berlin.weekday
    # Berlin-date per row, computed once; window slicing is then a cheap
    # date-range comparison instead of repeated tz conversions.
    dates = np.array(berlin.date)
    peak_row = (weekdays < 5) & (hours >= PEAK_HOUR_START) & (hours < PEAK_HOUR_END)

    group_cols = list(group_cols)
    value_cols = list(value_cols)
    frames: List[pd.DataFrame] = []

    for w in windows:
        sel = (dates >= w.start) & (dates < w.end)
        if not sel.any():
            continue
        sub = df.loc[sel, group_cols + value_cols].copy()
        sub_peak = pd.Series(peak_row[sel], index=sub.index)

        exp_base = expected_hours(w)
        exp_peak = expected_peak_hours(w) if w.has_peak else 0

        gb = sub.groupby(group_cols, sort=False, observed=True)
        out = pd.DataFrame(index=gb.size().index)
        for col in value_cols:
            n = gb[col].count()
            mean = gb[col].mean()
            out[f"{col}_base"] = mean.where(n == exp_base)
            out[f"{col}_coverage"] = n / float(exp_base)
            if w.has_peak and exp_peak:
                masked = sub[col].where(sub_peak)
                pk = masked.groupby([sub[c] for c in group_cols], observed=True)
                # The peak groupby sorts its groups (pandas default) while the
                # base one was built with sort=False: reindex onto the output
                # index instead of trusting positional alignment.
                n_pk = pk.count().reindex(out.index).fillna(0)
                out[f"{col}_peak"] = pk.mean().reindex(out.index).where(n_pk == exp_peak)
        out = out.reset_index()
        out["contract"] = w.label
        out["kind"] = w.kind
        out["window_start"] = pd.Timestamp(w.start)
        out["window_end"] = pd.Timestamp(w.end)
        out["has_peak"] = w.has_peak
        frames.append(out)

    if not frames:
        cols = (group_cols
                + [f"{c}_base" for c in value_cols]
                + [f"{c}_coverage" for c in value_cols]
                + ["contract", "kind", "window_start", "window_end", "has_peak"])
        return pd.DataFrame(columns=cols)
    return pd.concat(frames, ignore_index=True)


def aggregate_history(
    df: pd.DataFrame,
    *,
    time_col: str = "timestamp",
    zone_col: str = "border",
    value_cols: Sequence[str] = ("y_true", "y_pred"),
    extra_group_cols: Sequence[str] = (),
) -> pd.DataFrame:
    """Vectorised calendar aggregation of a long hourly history.

    Semantics are identical to running :func:`aggregate_windows` over
    :func:`enumerate_history_windows` (a test pins the two together), but this
    path groups every day / weekend / ISO week / month in one pass instead of
    masking per window -- the backtest frame is ~285k rows against ~700
    windows, which the per-window path handles in minutes and this one in
    milliseconds.

    Returns one row per (zone, *extra_group_cols*, kind, window_start) with
    ``{col}_base`` / ``{col}_peak`` under the same 100%-coverage gate.
    ``extra_group_cols`` lets the caller keep e.g. the market ``regime`` --
    note the coverage gate then applies within each subgroup, so only
    constant-within-window columns make sense there.
    """
    berlin = _berlin_index(df[time_col])
    peak_row = (berlin.weekday < 5) & (berlin.hour >= PEAK_HOUR_START) & (berlin.hour < PEAK_HOUR_END)

    value_cols = list(value_cols)
    extra_group_cols = list(extra_group_cols)
    work = df[[zone_col, *extra_group_cols, *value_cols]].copy()
    work["_peak"] = np.asarray(peak_row)

    day = pd.Series(berlin.normalize().tz_localize(None), index=df.index)
    weekday = pd.Series(berlin.weekday, index=df.index)
    keys = {
        "day": day,
        "week": day - pd.to_timedelta(weekday, unit="D"),
        "month": day.dt.to_period("M").dt.start_time,
        # Weekend key: Saturday for Sat/Sun rows, NaT otherwise.
        "weekend": (day - pd.to_timedelta(weekday - 5, unit="D")).where(weekday >= 5),
    }

    frames: List[pd.DataFrame] = []
    for kind, key in keys.items():
        w = work[key.notna()].copy() if key.isna().any() else work.copy()
        k = key.dropna() if key.isna().any() else key
        w["_wstart"] = k

        gcols = [zone_col, *extra_group_cols, "_wstart"]
        gb = w.groupby(gcols, sort=False, observed=True)
        out = pd.DataFrame(index=gb.size().index)

        # Expected hours per window, from the Berlin calendar.
        n_days = {"day": 1, "weekend": 2, "week": 7}.get(kind)
        starts = w["_wstart"].drop_duplicates()
        exp = {}
        for s in starts:
            s_date = s.date()
            if n_days is not None:
                e_date = s_date + timedelta(days=n_days)
            else:
                e_date = s_date + timedelta(
                    days=calendar.monthrange(s_date.year, s_date.month)[1])
            win = ContractWindow("", kind, s_date, e_date, True)
            exp[s] = (expected_hours(win), expected_peak_hours(win))
        # Per-group expected hour counts (constant within a window).
        wstart_of_group = gb["_wstart"].first()
        exp_b = wstart_of_group.map({k_: v[0] for k_, v in exp.items()})
        exp_p = wstart_of_group.map({k_: v[1] for k_, v in exp.items()})

        for col in value_cols:
            n = gb[col].count()
            out[f"{col}_base"] = gb[col].mean().where(n == exp_b)
            out[f"{col}_coverage"] = n / exp_b.astype(float)
            if kind != "weekend":
                masked = w[col].where(w["_peak"])
                pk = masked.groupby([w[c] for c in gcols], observed=True)
                # Reindex: this groupby sorts its groups, the sort=False one
                # above does not, and pandas refuses cross-labelled compares.
                n_pk = pk.count().reindex(out.index).fillna(0)
                # Weekend *days* (kind=day, Sat/Sun) have zero expected peak
                # hours: leave peak NaN there rather than 0/0.
                out[f"{col}_peak"] = pk.mean().reindex(out.index).where(
                    (n_pk == exp_p) & (exp_p > 0))
        out = out.reset_index().rename(columns={"_wstart": "window_start"})
        out["kind"] = kind
        frames.append(out)

    return pd.concat(frames, ignore_index=True)


def summarise_members(
    member_contracts: pd.DataFrame,
    *,
    value_col: str = "price_eur_mwh",
    quantiles: Sequence[float] = (0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95),
) -> pd.DataFrame:
    """Collapse per-member contract prices into a distribution summary.

    Input is ``aggregate_windows`` output grouped by (region, member). Output
    is one row per (region, contract, shape) with mean, std, the requested
    quantiles, member count and the window metadata. Members whose window was
    partially covered (NaN price) are excluded from the distribution rather
    than treated as zero.
    """
    rows: List[dict] = []
    meta_cols = ["kind", "window_start", "window_end", "has_peak"]
    shapes = [("Base", f"{value_col}_base")]
    if f"{value_col}_peak" in member_contracts.columns:
        shapes.append(("Peak", f"{value_col}_peak"))

    for (region, contract), grp in member_contracts.groupby(
        ["region", "contract"], sort=False, observed=True,
    ):
        meta = grp.iloc[0][meta_cols].to_dict()
        for shape, col in shapes:
            if shape == "Peak" and not meta["has_peak"]:
                continue
            vals = grp[col].dropna() if col in grp.columns else pd.Series(dtype=float)
            row = {
                "region": region, "contract": contract, "shape": shape,
                "n_members": int(vals.size),
                "coverage": float(grp[f"{value_col}_coverage"].max())
                if f"{value_col}_coverage" in grp.columns else np.nan,
                **meta,
            }
            if vals.size:
                row["mean"] = float(vals.mean())
                row["std"] = float(vals.std(ddof=0))
                for q in quantiles:
                    row[f"p{int(round(q * 100)):02d}"] = float(vals.quantile(q))
            rows.append(row)
    return pd.DataFrame(rows)
