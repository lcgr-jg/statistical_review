"""Cached derived views: contracts priced from the fan and the backtest.

Everything here is deterministic given (as_of / run_id), so results are cached
aggressively; the underlying S3 reads are themselves cached in :mod:`.store`.
"""
from __future__ import annotations

import datetime as dt
import logging
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from core.cache import cached_result

from . import store
from .contracts import (
    aggregate_history,
    aggregate_windows,
    build_contract_windows,
    summarise_members,
)

logger = logging.getLogger(__name__)

FAMILIES = (store.FAMILY_ST, store.FAMILY_MT)

# Zone display aliases (model codes are upper-case; the desk says UK, not GB).
ZONE_DISPLAY = {"GB": "UK"}


def zone_label(zone: str) -> str:
    return ZONE_DISPLAY.get(zone, zone)


# ---------------------------------------------------------------------------
# Production fan -> contracts
# ---------------------------------------------------------------------------

@cached_result(ttl_seconds=1800, key_prefix="pgnn_member_contracts")
def member_contracts(as_of: str) -> Optional[pd.DataFrame]:
    """Per-member contract prices for one run, both families.

    One row per (family, region, member, contract) with ``price_eur_mwh_base``
    / ``_peak`` under the 100%-coverage gate, from :func:`aggregate_windows`.
    """
    fan = store.load_fan(as_of)
    if fan is None or fan.empty:
        return None
    windows = build_contract_windows(dt.date.fromisoformat(as_of))
    parts: List[pd.DataFrame] = []
    for family in FAMILIES:
        sub = fan[fan["forecast_family"] == family]
        if sub.empty:
            continue
        agg = aggregate_windows(sub, windows)
        agg["family"] = family
        parts.append(agg)
    if not parts:
        return None
    return pd.concat(parts, ignore_index=True)


@cached_result(ttl_seconds=1800, key_prefix="pgnn_board")
def board_summary(as_of: str) -> Optional[pd.DataFrame]:
    """Distribution summary per (family, region, contract, shape).

    Adds ``preferred``: True on the family the board shows by default -- the
    short-term family wherever it fully covers the window (more members closer
    to their skill horizon), the medium-term family beyond that.
    """
    members = member_contracts(as_of)
    if members is None:
        return None
    parts: List[pd.DataFrame] = []
    for family, grp in members.groupby("family", observed=True):
        summ = summarise_members(grp)
        summ["family"] = family
        parts.append(summ)
    summary = pd.concat(parts, ignore_index=True)

    covered_st = summary[
        (summary["family"] == store.FAMILY_ST) & (summary["n_members"] > 0)
    ].set_index(["region", "contract", "shape"]).index
    key = pd.MultiIndex.from_frame(summary[["region", "contract", "shape"]])
    summary["preferred"] = np.where(
        summary["family"] == store.FAMILY_ST,
        key.isin(covered_st),
        ~key.isin(covered_st),
    )
    return summary


def available_zones(as_of: str) -> List[str]:
    summary = board_summary(as_of)
    if summary is None:
        return []
    return sorted(summary["region"].unique())


def contract_order(summary: pd.DataFrame) -> List[str]:
    """Contracts in delivery order (the summary carries window_start)."""
    order = (summary[["contract", "window_start", "window_end"]]
             .drop_duplicates()
             .sort_values(["window_start", "window_end"]))
    return list(order["contract"])


# ---------------------------------------------------------------------------
# Backtest -> contracts
# ---------------------------------------------------------------------------

def backtest_contracts(run_id: Optional[str] = None) -> Optional[pd.DataFrame]:
    """Contract-level realised vs predicted for one run (newest by default)."""
    run = store.resolve_backtest_run(run_id)
    return _backtest_contracts(run) if run else None


@cached_result(ttl_seconds=86400, key_prefix="pgnn_backtest_contracts")
def _backtest_contracts(run_id: str) -> Optional[pd.DataFrame]:
    """Contract-level realised vs predicted over the test split.

    One row per (border, regime, kind, window_start) with base/peak contract
    prices for y_true / y_pred / y_baseline / y_persist. The regime is kept as
    the *dominant* regime of the window (mode of hourly regimes) so windows are
    never split by intra-window regime flips.
    """
    hourly = store.load_backtest_hourly(run_id)
    if hourly is None or hourly.empty:
        return None
    hourly = hourly[hourly["split"] == "test"].copy()
    if hourly.empty:
        return None

    value_cols = [c for c in ("y_true", "y_pred", "y_baseline", "y_persist")
                  if c in hourly.columns]
    out = aggregate_history(
        hourly, time_col="timestamp", zone_col="border", value_cols=value_cols,
    )

    if "regime" in hourly.columns:
        # Dominant regime per (zone, day); windows inherit it from their start day.
        berlin_day = (
            pd.DatetimeIndex(hourly["timestamp"]).tz_localize("UTC")
            .tz_convert("Europe/Berlin").normalize().tz_localize(None)
        )
        dom = (
            hourly.assign(_day=berlin_day)
            .groupby(["border", "_day"], observed=True)["regime"]
            .agg(lambda s: s.mode().iloc[0] if not s.mode().empty else np.nan)
        )
        out["regime"] = [
            dom.get((z, w), np.nan)
            for z, w in zip(out["border"], out["window_start"])
        ]
    return out


def backtest_scorecard(
    contracts_df: pd.DataFrame,
    *,
    shape: str = "base",
    kinds: Optional[List[str]] = None,
) -> pd.DataFrame:
    """Per (zone, kind) skill metrics on contract prices.

    MAE / bias / RMSE of ``y_pred`` vs ``y_true``, plus skill (1 - MAE ratio)
    vs the persistence and anchored-baseline references where present.
    """
    suffix = f"_{shape}"
    df = contracts_df.copy()
    if kinds:
        df = df[df["kind"].isin(kinds)]
    needed = [f"y_true{suffix}", f"y_pred{suffix}"]
    df = df.dropna(subset=[c for c in needed if c in df.columns])
    if df.empty:
        return pd.DataFrame()

    rows: List[Dict] = []
    for (zone, kind), grp in df.groupby(["border", "kind"], observed=True):
        y, p = grp[f"y_true{suffix}"], grp[f"y_pred{suffix}"]
        err = p - y
        row = {
            "zone": zone.upper(), "kind": kind, "n": int(len(grp)),
            "mae": float(err.abs().mean()),
            "bias": float(err.mean()),
            "rmse": float(np.sqrt((err ** 2).mean())),
        }
        for ref, name in (("y_persist", "skill_vs_persist"),
                          ("y_baseline", "skill_vs_baseline")):
            col = f"{ref}{suffix}"
            if col in grp.columns and grp[col].notna().any():
                ref_mae = float((grp[col] - y).abs().mean())
                row[name] = 1.0 - row["mae"] / ref_mae if ref_mae > 0 else np.nan
        rows.append(row)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Backtest -> run-level views
# ---------------------------------------------------------------------------

MODELS = ("gnn", "baseline", "persistence")

# hourly.parquet prediction columns, in display order
PRED_COLUMNS = {
    "y_pred": "GNN",
    "y_baseline": "Anchored baseline",
    "y_persist": "24h persistence",
}

REGIME_NAMES = {
    0: "pre-2021", 1: "2021 ramp", 2: "2022 crisis",
    3: "2023-24 normalisation", 4: "2025 onward",
}


def regime_label(regime) -> str:
    try:
        return REGIME_NAMES.get(int(regime), f"regime {int(regime)}")
    except (TypeError, ValueError):
        return "all regimes"


def run_options() -> List[Dict[str, str]]:
    """Dropdown options for the run selector, newest run first."""
    options = []
    for entry in store.list_backtest_runs():
        run_id = str(entry.get("run_id") or "")
        if not run_id:
            continue
        bits = [run_id]
        if entry.get("preset"):
            bits.append(str(entry["preset"]))
        if entry.get("kind"):
            bits.append("WF" if entry["kind"] == "walk_forward" else "fixed")
        published = str(entry.get("published_at") or "")[:10]
        label = " · ".join(bits) + (f"  ({published})" if published else "")
        options.append({"label": label, "value": run_id})
    return options


def headline_skill(meta: Optional[Dict], ref: str) -> Optional[float]:
    """1 - rmse_gnn / rmse_ref from the headline block, when both exist."""
    headline = (meta or {}).get("headline") or {}
    gnn = (headline.get("gnn") or {}).get("rmse")
    reference = (headline.get(ref) or {}).get("rmse")
    try:
        if gnn is None or not reference:
            return None
        return 1.0 - float(gnn) / float(reference)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def zone_metrics(run_id: Optional[str] = None,
                 model: str = "gnn") -> Optional[pd.DataFrame]:
    """Per-zone test metrics for one model.

    Prefers ``metrics.parquet`` (rmse/mae/r2/skill columns); falls back to the
    ``zone_r2`` dict in run_meta.json when that table was not published, so a
    minimal run still gets a zone view.
    """
    run = store.resolve_backtest_run(run_id)
    metrics = store.load_backtest_table(run, "metrics")
    if metrics is not None and not metrics.empty:
        df = metrics.copy()
        if "split" in df.columns:
            df = df[df["split"].astype(str) == "test"]
        if "model" in df.columns:
            df = df[df["model"].astype(str) == model]
        if not df.empty and "border" in df.columns:
            df = df.rename(columns={"border": "zone"})
            df["zone"] = df["zone"].astype(str).str.upper()
            return df.sort_values("zone").reset_index(drop=True)

    meta = store.backtest_meta(run) or {}
    zone_r2 = meta.get("zone_r2") or {}
    if not zone_r2 or model != "gnn":
        return None
    return pd.DataFrame(
        {"zone": [str(z).upper() for z in zone_r2],
         "r2": [zone_r2[z] for z in zone_r2]}
    ).sort_values("zone").reset_index(drop=True)


def backtest_hourly(run_id: Optional[str] = None,
                    zone: Optional[str] = None) -> Optional[pd.DataFrame]:
    """Test-split hourly rows, optionally for one zone, with CET stamps.

    Adds ``ts_cet`` (tz-naive Europe/Berlin) because day-ahead delivery days
    and peak blocks are CET-shaped while ``timestamp`` is naive UTC.
    """
    hourly = store.load_backtest_hourly(run_id)
    if hourly is None or hourly.empty:
        return None
    df = hourly
    if "split" in df.columns:
        df = df[df["split"].astype(str) == "test"]
    if zone:
        df = df[df["border"].astype(str).str.lower() == str(zone).lower()]
    if df.empty:
        return None
    df = df.copy()
    df["ts_cet"] = (
        pd.DatetimeIndex(df["timestamp"]).tz_localize("UTC")
        .tz_convert("Europe/Berlin").tz_localize(None)
    )
    return df.sort_values("timestamp").reset_index(drop=True)


def resample_hourly(df: pd.DataFrame, freq: str) -> pd.DataFrame:
    """Mean of the prediction columns on a CET calendar ('h', 'D', 'W')."""
    cols = [c for c in ("y_true", *PRED_COLUMNS) if c in df.columns]
    out = df.set_index("ts_cet")[cols]
    if freq and freq != "h":
        out = out.resample(freq).mean()
    return out.dropna(how="all")


def error_by_hour(df: pd.DataFrame) -> pd.DataFrame:
    """Bias and MAE of the GNN by CET hour of day."""
    if df.empty or "y_pred" not in df.columns:
        return pd.DataFrame()
    err = df["y_pred"] - df["y_true"]
    frame = pd.DataFrame({"hour": df["ts_cet"].dt.hour, "err": err})
    grouped = frame.groupby("hour")["err"]
    return pd.DataFrame({
        "hour": grouped.mean().index,
        "bias": grouped.mean().values,
        "mae": grouped.apply(lambda s: s.abs().mean()).values,
    })


def pooled_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """RMSE / MAE / bias / R² per available prediction column on a slice."""
    rows: List[Dict] = []
    if df.empty or "y_true" not in df.columns:
        return pd.DataFrame()
    y = df["y_true"]
    ss_tot = float(((y - y.mean()) ** 2).sum())
    for col, label in PRED_COLUMNS.items():
        if col not in df.columns or df[col].isna().all():
            continue
        err = (df[col] - y).dropna()
        if err.empty:
            continue
        rows.append({
            "model": label,
            "n": int(len(err)),
            "rmse": float(np.sqrt((err ** 2).mean())),
            "mae": float(err.abs().mean()),
            "bias": float(err.mean()),
            "r2": (1.0 - float((err ** 2).sum()) / ss_tot
                   if ss_tot > 0 else np.nan),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Realised spot (for settled forward windows)
# ---------------------------------------------------------------------------

@cached_result(ttl_seconds=3600, key_prefix="pgnn_realised_spot")
def load_realised_spot(start: str, end: str) -> Optional[pd.DataFrame]:
    """Hourly realised day-ahead spot per zone, naive UTC, EUR only.

    Columns are lower-case zone codes matching the market cache (``gb`` for
    UK). Returns None when the market cache is unreachable.
    """
    try:
        from jain_commods.core.cache.data.market import PricePowerSpot
        pwr = PricePowerSpot(freq="h")
        pwr.load(from_s3=True, show_metadata=False,
                 start_date=pd.Timestamp(start), end_date=pd.Timestamp(end))
        df = pwr.data
    except Exception as e:  # noqa: BLE001
        logger.warning("PricePowerSpot unavailable for realised overlay: %s", e)
        return None
    if df is None or df.empty:
        return None
    try:
        eur = df.columns.get_level_values("currency").str.upper() == "EUR"
        df = df.loc[:, eur]
    except Exception:  # noqa: BLE001 - currency level missing
        pass
    # Collapse (zone, exchange, ...) to one column per zone.
    out: Dict[str, pd.Series] = {}
    for zone in df.columns.get_level_values(0).unique():
        sub = df.xs(zone, axis=1, level=0)
        out[str(zone).lower()] = sub.mean(axis=1) if sub.ndim > 1 else sub
    wide = pd.DataFrame(out)
    if wide.index.tz is not None:
        wide.index = wide.index.tz_convert("UTC").tz_localize(None)
    return wide


def realised_contract_price(zone: str, window_start, window_end, shape: str) -> Optional[float]:
    """Realised base/peak price for one settled (or partly settled) window.

    Returns None unless every delivery hour of the window has settled -- the
    same 100%-coverage rule the forecasts are held to.
    """
    from .contracts import ContractWindow, aggregate_windows

    spot = load_realised_spot(str(pd.Timestamp(window_start).date()),
                              str(pd.Timestamp(window_end).date()))
    if spot is None:
        return None
    z = zone.lower()
    if z not in spot.columns:
        return None
    series = spot[z].dropna()
    if series.empty:
        return None
    frame = pd.DataFrame({
        "target_date": series.index, "region": zone.upper(),
        "ensemble_member": "realised", "price_eur_mwh": series.values,
    })
    win = ContractWindow(
        "w", "custom",
        pd.Timestamp(window_start).date(), pd.Timestamp(window_end).date(),
        has_peak=shape.lower() == "peak",
    )
    agg = aggregate_windows(frame, [win])
    if agg.empty:
        return None
    col = "price_eur_mwh_peak" if shape.lower() == "peak" else "price_eur_mwh_base"
    if col not in agg.columns:
        return None
    val = agg[col].iloc[0]
    return float(val) if pd.notna(val) else None
