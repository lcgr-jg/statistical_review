"""Run Health tab: provenance and gate status of the published runs.

Everything here comes from ``manifest.json`` / ``latest_success.json`` -- the
files the publisher writes only after every partition and the fan roll-up
succeeded, so a run that appears here passed all production gates (price
bounds, member completeness, issue freshness, horizon coverage).
"""
from __future__ import annotations

import datetime as dt
import logging

import pandas as pd
from dash import Input, Output, dash_table, dcc, html

from core.data_freshness import tracker
from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
)

from . import store

logger = logging.getLogger(__name__)

FRESHNESS_SOURCE = "Price GNN Forecasts (research)"

_KV_STYLE = {"fontSize": "13px", "padding": "3px 0",
             "display": "flex", "gap": "8px"}
_K_STYLE = {"color": "#6c757d", "minWidth": "220px", "fontWeight": "500"}
_WARN_STYLE = {"color": "#b08800", "fontSize": "13px", "padding": "2px 0"}
_ERR_STYLE = {"color": "#c94a2e", "fontSize": "13px", "padding": "2px 0"}


def register_freshness() -> None:
    """Register the latest promoted run with the portal freshness tracker."""
    pointer = store.latest_success()
    if not pointer or not pointer.get("promoted_at"):
        return
    try:
        promoted = dt.datetime.fromisoformat(str(pointer["promoted_at"]))
        tracker.register_data_source(
            FRESHNESS_SOURCE,
            promoted,
            expected_frequency_minutes=24 * 60,  # daily run
            metadata={"as_of": pointer.get("as_of"),
                      "model_run_id": pointer.get("model_run_id")},
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("freshness registration failed: %s", e)


def _kv(key: str, value) -> html.Div:
    return html.Div(style=_KV_STYLE, children=[
        html.Span(key, style=_K_STYLE), html.Span(str(value)),
    ])


def get_layout():
    register_freshness()
    runs = store.list_as_of()
    latest = store.latest_run()
    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Label("Run (as_of)", style=LABEL_STYLE),
            dcc.Dropdown(id="pgnn-health-run",
                         options=[{"label": r, "value": r} for r in runs],
                         value=latest, clearable=False,
                         style={"width": "220px"}),
        ]),
        dcc.Loading(html.Div(id="pgnn-health-content")),
    ])


def _family_table(families: dict) -> dash_table.DataTable:
    records = []
    for fam, info in (families or {}).items():
        prov = info.get("load_provenance") or {}
        window = info.get("window") or {}
        records.append({
            "Family": fam,
            "Members": info.get("n_scenarios"),
            "Issue requested": prov.get("requested_issue_date", ""),
            "Issue resolved": prov.get("resolved_issue_date", ""),
            "Staleness (d)": prov.get("issue_staleness_days", ""),
            "Horizon end": str(prov.get("horizon_end", ""))[:16],
            "Hours beyond horizon": prov.get("hours_beyond_horizon", ""),
            "Degraded to mean": prov.get("degraded_to_mean", False),
            "Window": f"{window.get('start', '')} \u2192 {window.get('end', '')}",
        })
    return dash_table.DataTable(
        data=records,
        columns=[{"name": k, "id": k} for k in (records[0] if records else {})],
        style_cell={"fontSize": "12px", "fontFamily": "Inter, sans-serif",
                    "padding": "6px 12px", "textAlign": "center",
                    "whiteSpace": "nowrap"},
        style_header={"fontWeight": "600", "backgroundColor": "#f4f5f7",
                      "fontSize": "12px"},
    )


def register_callbacks(app):
    @app.callback(
        Output("pgnn-health-content", "children"),
        Input("pgnn-health-run", "value"),
    )
    def update_health(as_of):
        if not as_of:
            return html.Div("No published runs found on the research prefix. "
                            "Every earlier run was a dry run; the first real "
                            "publish creates latest_success.json.",
                            style={"color": "#6c757d", "padding": "12px"})
        man = store.manifest(as_of)
        pointer = store.latest_success() or {}
        if man is None:
            return html.Div(f"manifest.json missing for {as_of}",
                            style={"color": "#c94a2e", "padding": "12px"})

        anchors = man.get("anchors") or {}
        warnings = man.get("warnings") or []
        errors = man.get("errors") or []
        is_latest = str(pointer.get("as_of")) == str(as_of)

        cards = [
            html.Div(style=CARD_STYLE, children=[
                html.Div(style=CARD_HEADER_STYLE, children=[
                    html.P("Run identity", style=CARD_HEADER_TEXT_STYLE)]),
                html.Div(style={"padding": "12px 20px"}, children=[
                    _kv("as_of", man.get("as_of")),
                    _kv("Promoted latest", "yes" if is_latest else
                        f"no (latest is {pointer.get('as_of')})"),
                    _kv("Model run id", man.get("model_run_id")),
                    _kv("Model S3 URI", man.get("model_s3_uri")),
                    _kv("Component", man.get("component")),
                    _kv("Published at", man.get("published_at")),
                    _kv("Zones", f"{len(man.get('zones') or [])}: "
                        + ", ".join(man.get("zones") or [])),
                    _kv("Partitions", man.get("n_partitions")),
                    _kv("Fan rows", man.get("fan_rows")),
                ]),
            ]),
            html.Div(style=CARD_STYLE, children=[
                html.Div(style=CARD_HEADER_STYLE, children=[
                    html.P("Families & cache provenance", style=CARD_HEADER_TEXT_STYLE)]),
                html.Div(style={"padding": "12px 16px", "overflowX": "auto"},
                         children=[_family_table(man.get("families"))]),
            ]),
            html.Div(style=CARD_STYLE, children=[
                html.Div(style=CARD_HEADER_STYLE, children=[
                    html.P("Merit-order anchors", style=CARD_HEADER_TEXT_STYLE)]),
                html.Div(style={"padding": "12px 20px"}, children=[
                    _kv("TTF gas (EUR/MWh)", anchors.get("gas_price")),
                    _kv("API2 coal (USD/t)", anchors.get("coal_price")),
                    _kv("EUA carbon (EUR/t)", anchors.get("co2_price")),
                ]),
            ]),
        ]
        if warnings or errors:
            cards.append(html.Div(style=CARD_STYLE, children=[
                html.Div(style=CARD_HEADER_STYLE, children=[
                    html.P(f"Warnings ({len(warnings)}) / errors ({len(errors)})",
                           style=CARD_HEADER_TEXT_STYLE)]),
                html.Div(style={"padding": "12px 20px"}, children=(
                    [html.Div(f"error: {e}", style=_ERR_STYLE) for e in errors]
                    + [html.Div(f"warning: {w}", style=_WARN_STYLE) for w in warnings]
                )),
            ]))
        return html.Div(cards)
