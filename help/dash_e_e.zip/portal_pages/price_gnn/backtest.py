"""Backtest tab: skill of a published run on its held-out test window.

Driven entirely by the run catalogue the model repo publishes to the research
prefix (``backtest/index.json``): pick a run, and every section below reads
that run's artefacts -- ``run_meta.json`` for the headline tiles,
``metrics.parquet`` for per-zone skill, ``hourly.parquet`` for the hourly
explorer and the contract scorecard, and the walk-forward tables
(``by_lead`` / ``by_origin`` / ``by_regime``) when the run has them.

IMPORTANT FRAMING (also shown on the page): a fixed-split run is scored on
*realised* fundamentals -- realised weather, load, availability. Those numbers
are the model's skill ceiling given perfect inputs, NOT the tradeable skill of
a forward forecast driven by ensemble weather, and lead-time decay is not
measurable from it. Walk-forward runs do carry a lead-time dimension, and the
page switches framing and views accordingly.
"""
from __future__ import annotations

import logging

import pandas as pd
from dash import Input, Output, dash_table, dcc, html

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
    styled_empty_figure,
)

from . import compute, figures, store

logger = logging.getLogger(__name__)

CEILING_NOTE = (
    "Skill ceiling, not tradeable skill: this test window is scored on realised "
    "fundamentals (weather, load, availability), so it shows how well the model "
    "prices a block given perfect inputs. A forward forecast driven by ensemble "
    "weather will be worse, and lead-time decay cannot be measured from this "
    "artefact. Train window ends before the test split; no retraining inside it."
)
WALK_FORWARD_NOTE = (
    "Walk-forward run: the model is retrained at each origin and scored only on "
    "the block that follows, so these numbers do carry a lead-time dimension "
    "(see accuracy vs days since retrain below). Fundamentals are still realised."
)

_NOTE_STYLE = {
    "backgroundColor": "#eef4fa",
    "border": "1px solid #b8d4f0",
    "borderRadius": "8px",
    "color": "#33536b",
    "padding": "12px 16px",
    "fontSize": "13px",
    "marginBottom": "16px",
}
_MUTED = {"color": "#6c757d", "fontSize": "13px", "padding": "12px"}
# For slots that carry a message only some of the time: no vertical
# padding, so an empty slot collapses instead of leaving a gap.
_MSG_STYLE = {"color": "#6c757d", "fontSize": "13px"}

_TILE_STYLE = {
    "flex": "1 1 150px",
    "minWidth": "140px",
    "backgroundColor": "#ffffff",
    "border": "1px solid #e3e6ea",
    "borderRadius": "8px",
    "padding": "10px 14px",
}
_TILE_LABEL = {"fontSize": "10px", "fontWeight": "600", "letterSpacing": "0.5px",
               "textTransform": "uppercase", "color": "#6c757d"}
_TILE_VALUE = {"fontSize": "18px", "fontWeight": "600", "color": "#231F20"}
_TILE_SUB = {"fontSize": "11px", "color": "#6c757d"}

_KV_STYLE = {"fontSize": "12px", "padding": "2px 0", "display": "flex",
             "gap": "8px"}
_K_STYLE = {"color": "#6c757d", "minWidth": "150px", "fontWeight": "500"}

KIND_LABEL = {
    "day": "Day (DA-shaped)",
    "weekend": "Weekend",
    "week": "Week (Mon–Sun)",
    "month": "Month",
}

ZONE_METRICS = [
    {"label": "R²", "value": "r2"},
    {"label": "RMSE (EUR/MWh)", "value": "rmse"},
    {"label": "MAE (EUR/MWh)", "value": "mae"},
    {"label": "RMSE / anchor", "value": "rmse_norm"},
    {"label": "Sign accuracy", "value": "sign_accuracy"},
    {"label": "Skill vs persistence", "value": "skill_vs_persistence"},
    {"label": "Skill vs baseline", "value": "skill_vs_baseline"},
]

WF_VIEWS = [
    {"label": "Accuracy vs days since retrain", "value": "by_lead"},
    {"label": "Score per retrain origin", "value": "by_origin"},
    {"label": "Score per regime", "value": "by_regime"},
]
WF_KEY = {"by_lead": "lead_days", "by_origin": "origin", "by_regime": "regime"}


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def _tile(label: str, value, sub: str = "") -> html.Div:
    return html.Div(style=_TILE_STYLE, children=[
        html.Div(label, style=_TILE_LABEL),
        html.Div("—" if value is None else str(value), style=_TILE_VALUE),
        html.Div(sub, style=_TILE_SUB),
    ])


def _kv(key: str, value) -> html.Div:
    return html.Div(style=_KV_STYLE, children=[
        html.Span(key, style=_K_STYLE),
        html.Span("—" if value in (None, "") else str(value)),
    ])


def _card(title: str, body, padding: str = "12px 16px") -> html.Div:
    return html.Div(style=CARD_STYLE, children=[
        html.Div(style=CARD_HEADER_STYLE, children=[
            html.P(title, style=CARD_HEADER_TEXT_STYLE)]),
        html.Div(style={"padding": padding}, children=[body]),
    ])


def get_layout():
    options = compute.run_options()
    default = options[0]["value"] if options else None
    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div(style={"display": "flex", "flexWrap": "wrap",
                            "alignItems": "flex-end", "gap": "18px"},
                     children=[
                         html.Div([
                             html.Label("Run", style=LABEL_STYLE),
                             dcc.Dropdown(id="pgnn-bt-run", options=options,
                                          value=default, clearable=False,
                                          style={"width": "320px"}),
                         ]),
                         html.Div(id="pgnn-bt-runinfo",
                                  style={"fontSize": "12px",
                                         "color": "#6c757d"}),
                     ]),
        ]),

        dcc.Loading(html.Div(id="pgnn-bt-note")),
        dcc.Loading(html.Div(id="pgnn-bt-tiles",
                             style={"display": "flex", "flexWrap": "wrap",
                                    "gap": "12px", "marginBottom": "16px"})),

        # --- per-zone skill -------------------------------------------------
        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.P("Skill per zone — test split", style=CARD_HEADER_TEXT_STYLE)]),
            html.Div(style={"padding": "12px 16px"}, children=[
                html.Div(style={"display": "flex", "gap": "18px",
                                "alignItems": "flex-end",
                                "marginBottom": "10px"}, children=[
                    html.Div([
                        html.Label("Metric", style=LABEL_STYLE),
                        dcc.Dropdown(id="pgnn-bt-zonemetric",
                                     options=ZONE_METRICS, value="r2",
                                     clearable=False,
                                     style={"width": "230px"}),
                    ]),
                ]),
                html.Div(style={"display": "grid",
                                "gridTemplateColumns": "minmax(0,1fr) minmax(0,1fr)",
                                "gap": "16px"}, children=[
                    dcc.Loading(dcc.Graph(id="pgnn-bt-zonechart")),
                    html.Div(style={"overflowX": "auto"}, children=[
                        html.Div(id="pgnn-bt-zonemsg", style=_MSG_STYLE),
                        _table_panel("pgnn-bt-zonetable"),
                    ]),
                ]),
            ]),
        ]),

        # --- hourly explorer ------------------------------------------------
        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.P("Hourly explorer — realised vs predicted",
                       style=CARD_HEADER_TEXT_STYLE)]),
            html.Div(style={"padding": "12px 16px"}, children=[
                html.Div(style={"display": "flex", "gap": "18px",
                                "alignItems": "flex-end", "flexWrap": "wrap",
                                "marginBottom": "10px"}, children=[
                    html.Div([
                        html.Label("Zone", style=LABEL_STYLE),
                        dcc.Dropdown(id="pgnn-bt-hzone", options=[], value=None,
                                     clearable=False, style={"width": "150px"}),
                    ]),
                    html.Div([
                        html.Label("Resolution", style=LABEL_STYLE),
                        dcc.Dropdown(id="pgnn-bt-hfreq",
                                     options=[{"label": "Hourly", "value": "h"},
                                              {"label": "Daily", "value": "D"},
                                              {"label": "Weekly", "value": "W"}],
                                     value="D", clearable=False,
                                     style={"width": "130px"}),
                    ]),
                    html.Div(id="pgnn-bt-pooled",
                             style={"fontSize": "12px", "color": "#6c757d"}),
                ]),
                dcc.Loading(dcc.Graph(id="pgnn-bt-series")),
                html.Div(style={"display": "grid",
                                "gridTemplateColumns": "1fr 1fr 1fr",
                                "gap": "16px", "marginTop": "8px"}, children=[
                    dcc.Loading(dcc.Graph(id="pgnn-bt-hscatter")),
                    dcc.Loading(dcc.Graph(id="pgnn-bt-herrhist")),
                    dcc.Loading(dcc.Graph(id="pgnn-bt-hbyhour")),
                ]),
            ]),
        ]),

        # --- walk-forward (hidden for fixed-split runs) ----------------------
        html.Div(id="pgnn-bt-wf-wrap", style={"display": "none"}, children=[
            html.Div(style=CARD_STYLE, children=[
                html.Div(style=CARD_HEADER_STYLE, children=[
                    html.P("Walk-forward: out-of-sample decay and stability",
                           style=CARD_HEADER_TEXT_STYLE)]),
                html.Div(style={"padding": "12px 16px"}, children=[
                    html.Div(style={"display": "flex", "gap": "18px",
                                    "alignItems": "flex-end",
                                    "marginBottom": "10px"}, children=[
                        html.Div([
                            html.Label("View", style=LABEL_STYLE),
                            dcc.Dropdown(id="pgnn-bt-wfview", options=WF_VIEWS,
                                         value="by_lead", clearable=False,
                                         style={"width": "290px"}),
                        ]),
                        html.Div([
                            html.Label("Metric", style=LABEL_STYLE),
                            dcc.Dropdown(id="pgnn-bt-wfmetric",
                                         options=[
                                             {"label": "R²", "value": "r2"},
                                             {"label": "RMSE", "value": "rmse"},
                                             {"label": "MAE", "value": "mae"},
                                             {"label": "RMSE / anchor",
                                              "value": "rmse_norm"},
                                         ],
                                         value="r2", clearable=False,
                                         style={"width": "170px"}),
                        ]),
                    ]),
                    dcc.Loading(dcc.Graph(id="pgnn-bt-wfchart")),
                ]),
            ]),
        ]),

        # --- contract skill (unchanged analysis, now run-aware) -------------
        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.P("Contract skill — tradeable blocks priced from the "
                       "hourly series", style=CARD_HEADER_TEXT_STYLE)]),
            html.Div(style={"padding": "12px 16px"}, children=[
                html.Div(style={"display": "flex", "flexWrap": "wrap",
                                "alignItems": "flex-end", "gap": "18px",
                                "marginBottom": "10px"}, children=[
                    html.Div([
                        html.Label("Contract type", style=LABEL_STYLE),
                        dcc.Dropdown(id="pgnn-bt-kind",
                                     options=[{"label": v, "value": k}
                                              for k, v in KIND_LABEL.items()],
                                     value="day", clearable=False,
                                     style={"width": "200px"}),
                    ]),
                    html.Div([
                        html.Label("Shape", style=LABEL_STYLE),
                        dcc.Dropdown(id="pgnn-bt-shape",
                                     options=[{"label": "Base", "value": "base"},
                                              {"label": "Peak", "value": "peak"}],
                                     value="base", clearable=False,
                                     style={"width": "120px"}),
                    ]),
                    html.Div([
                        html.Label("Zone (scatter / histogram)",
                                   style=LABEL_STYLE),
                        dcc.Dropdown(id="pgnn-bt-zone", options=[], value=None,
                                     clearable=False, style={"width": "150px"}),
                    ]),
                    html.Div([
                        html.Label("Regime", style=LABEL_STYLE),
                        dcc.Dropdown(id="pgnn-bt-regime", options=[],
                                     value="all", clearable=False,
                                     style={"width": "200px"}),
                    ]),
                ]),
                html.Div(style={"overflowX": "auto"}, children=[
                    html.Div(id="pgnn-bt-scorecardmsg", style=_MSG_STYLE),
                    _table_panel("pgnn-bt-scorecard"),
                ]),
                html.Div(style={"display": "grid",
                                "gridTemplateColumns": "1fr 1fr",
                                "gap": "16px", "marginTop": "8px"}, children=[
                    dcc.Loading(dcc.Graph(id="pgnn-bt-scatter")),
                    dcc.Loading(dcc.Graph(id="pgnn-bt-errhist")),
                ]),
            ]),
        ]),

        dcc.Loading(html.Div(id="pgnn-bt-provenance")),
    ])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt(value, spec: str = ".3f") -> str:
    try:
        if value is None or pd.isna(value):
            return "—"
        return format(float(value), spec)
    except (TypeError, ValueError):
        return str(value)


def _filtered(run_id, kind: str, regime):
    contracts = compute.backtest_contracts(run_id)
    if contracts is None or contracts.empty:
        return None
    df = contracts[contracts["kind"] == kind]
    if regime not in (None, "all") and "regime" in df.columns:
        df = df[df["regime"] == regime]
    return df


def _table_panel(table_id: str) -> dash_table.DataTable:
    """A DataTable declared in the layout, filled by callbacks.

    Callbacks feed these tables ``data``/``columns``/``page_size`` rather
    than returning a whole DataTable into a ``children`` slot. A table
    injected into children has no stable tracked path, so the derived_*
    props it writes back (native sorting, pagination) can land in the
    parent's children slot instead -- "An object was provided as
    `children` instead of a component". Clean Spreads feeds its tables
    the same way.
    """
    return dash_table.DataTable(
        id=table_id,
        data=[],
        columns=[],
        sort_action="native",
        style_cell={"fontSize": "12px", "fontFamily": "Inter, sans-serif",
                    "padding": "6px 12px", "textAlign": "center"},
        style_header={"fontWeight": "600", "backgroundColor": "#f4f5f7",
                      "fontSize": "12px"},
    )


def _table_props(records, first_col_left: str | None = None,
                 page_size: int = 40) -> tuple:
    """``(data, columns, page_size, style_cell_conditional)`` for a table."""
    columns = [{"name": k, "id": k} for k in (records[0] if records else {})]
    # Only paginate when there is more than a screenful; 23 zones is not.
    rows = page_size if len(records) > page_size else max(len(records), 1)
    styles = ([{"if": {"column_id": first_col_left},
                "textAlign": "left", "fontWeight": "600"}]
              if first_col_left else [])
    return records, columns, rows, styles


EMPTY_TABLE: tuple = ([], [], 1, [])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_callbacks(app):

    # --- run header: note, tiles, provenance, walk-forward visibility ------
    @app.callback(
        Output("pgnn-bt-note", "children"),
        Output("pgnn-bt-tiles", "children"),
        Output("pgnn-bt-runinfo", "children"),
        Output("pgnn-bt-provenance", "children"),
        Output("pgnn-bt-wf-wrap", "style"),
        Input("pgnn-bt-run", "value"),
    )
    def update_header(run_id):
        meta = store.backtest_meta(run_id) or {}
        entry = store.backtest_run_entry(run_id)
        if not meta and not entry:
            return (html.Div(
                "No backtest runs found on the research prefix. Publish one "
                "with `flow-gnn publish-run`, or point PRICE_GNN_LOCAL at a "
                "local mirror.", style=_MUTED),
                [], "", None, {"display": "none"})

        kind = str(meta.get("kind") or entry.get("kind") or "fixed_split")
        is_wf = kind == "walk_forward"
        headline = meta.get("headline") or {}
        gnn = headline.get("gnn") or {}
        window = f"{str(meta.get('test_start') or '')[:10]} → " \
                 f"{str(meta.get('test_end') or '')[:10]}"

        note = meta.get("note") or (WALK_FORWARD_NOTE if is_wf
                                    else CEILING_NOTE)
        tiles = [
            _tile("Test window", window,
                  f"{int(meta.get('n_rows') or entry.get('n_rows') or 0):,} rows"),
            _tile("Pooled R²", _fmt(gnn.get("r2")),
                  f"mean zone R² {_fmt(gnn.get('mean_zone_r2'))}"),
            _tile("RMSE", _fmt(gnn.get("rmse"), ".2f"), "EUR/MWh, pooled"),
            _tile("MAE", _fmt(gnn.get("mae"), ".2f"), "EUR/MWh, pooled"),
        ]
        for ref, label in (("baseline", "vs baseline"),
                           ("persistence", "vs persistence")):
            skill = compute.headline_skill(meta, ref)
            if skill is None:
                continue
            ref_rmse = _fmt((headline.get(ref) or {}).get("rmse"), ".2f")
            tiles.append(_tile(f"RMSE skill {label}", f"{skill:+.1%}",
                               f"{label} RMSE {ref_rmse}"))
        zones = meta.get("zones")
        n_zones = len(zones) if zones else entry.get("n_zones")
        tiles.append(_tile("Zones", n_zones,
                           str(meta.get("graph") or entry.get("graph") or "")))

        published = str(meta.get("published_at")
                        or entry.get("published_at") or "")[:19]
        runinfo = " · ".join([
            f"kind {kind}",
            f"preset {meta.get('preset') or entry.get('preset') or 'n/a'}",
            f"trained {str(meta.get('trained_at') or '')[:10]}",
            f"published {published}",
        ])

        backtest_block = meta.get("backtest") or {}
        overall = backtest_block.get("overall") or {}
        config = backtest_block.get("config") or {}
        prov_rows = [
            _kv("Run id", meta.get("run_id") or run_id),
            _kv("Component", meta.get("component")),
            _kv("Target", meta.get("target_kind")),
            _kv("Train window", f"{str((meta.get('window') or {}).get('start'))[:10]}"
                f" → {str((meta.get('window') or {}).get('end'))[:10]}"),
            _kv("Epochs / seed",
                f"{(meta.get('train') or {}).get('epochs')} / "
                f"{(meta.get('train') or {}).get('seed')}"),
            _kv("git sha", str((meta.get("git") or {}).get("sha")
                               or entry.get("git_sha") or "")[:12]),
            _kv("git dirty", (meta.get("git") or {}).get("dirty")),
            _kv("Python", meta.get("python")),
            _kv("Command", meta.get("command")),
            _kv("Files published", ", ".join(meta.get("files") or [])),
        ]
        if overall:
            prov_rows += [
                _kv("WF origins / days",
                    f"{overall.get('n_origins')} / {overall.get('n_days')}"),
                _kv("WF cadence / block",
                    f"{config.get('cadence_days')}d / {config.get('block_days')}d"
                    f" ({config.get('window')})"),
            ]
        provenance = _card("Run provenance",
                           html.Div(prov_rows), padding="12px 20px")

        wf_style = ({"display": "block"} if is_wf else {"display": "none"})
        return (html.Div(note, style=_NOTE_STYLE), tiles, runinfo,
                provenance, wf_style)

    # --- per-zone skill ----------------------------------------------------
    @app.callback(
        Output("pgnn-bt-zonechart", "figure"),
        Output("pgnn-bt-zonetable", "data"),
        Output("pgnn-bt-zonetable", "columns"),
        Output("pgnn-bt-zonetable", "page_size"),
        Output("pgnn-bt-zonetable", "style_cell_conditional"),
        Output("pgnn-bt-zonemsg", "children"),
        Input("pgnn-bt-run", "value"),
        Input("pgnn-bt-zonemetric", "value"),
    )
    def update_zone_skill(run_id, metric):
        zone_df = compute.zone_metrics(run_id)
        if zone_df is None or zone_df.empty:
            return (styled_empty_figure("No per-zone metrics for this run"),
                    *EMPTY_TABLE,
                    "metrics.parquet not published for this run and "
                    "run_meta.json carries no zone_r2.")
        metric = metric if metric in zone_df.columns else "r2"
        display = zone_df.copy()
        display["zone"] = [compute.zone_label(z) for z in display["zone"]]
        chart = figures.fig_zone_metric(
            display, metric, f"Per-zone {metric} — test split")

        cols = [c for c in ("zone", "n", "r2", "rmse", "mae", "rmse_norm",
                            "sign_accuracy", "skill_vs_persistence",
                            "skill_vs_baseline") if c in display.columns]
        records = []
        for _, row in display[cols].iterrows():
            rec = {"Zone": row["zone"]}
            if "n" in cols:
                rec["n"] = f"{int(row['n']):,}"
            for key, label, spec in (("r2", "R²", ".3f"),
                                     ("rmse", "RMSE", ".2f"),
                                     ("mae", "MAE", ".2f"),
                                     ("rmse_norm", "RMSE/anchor", ".3f"),
                                     ("sign_accuracy", "Sign acc", ".3f")):
                if key in cols:
                    rec[label] = _fmt(row[key], spec)
            for key, label in (("skill_vs_persistence", "Skill vs persist"),
                               ("skill_vs_baseline", "Skill vs baseline")):
                if key in cols and pd.notna(row[key]):
                    rec[label] = f"{float(row[key]):+.1%}"
            records.append(rec)
        return (chart, *_table_props(records, first_col_left="Zone"), "")

    # --- hourly explorer ---------------------------------------------------
    @app.callback(
        Output("pgnn-bt-hzone", "options"),
        Output("pgnn-bt-hzone", "value"),
        Output("pgnn-bt-zone", "options"),
        Output("pgnn-bt-zone", "value"),
        Output("pgnn-bt-regime", "options"),
        Input("pgnn-bt-run", "value"),
    )
    def update_selectors(run_id):
        hourly = store.load_backtest_hourly(run_id)
        regime_opts = [{"label": "All regimes", "value": "all"}]
        if hourly is None or hourly.empty:
            return [], None, [], None, regime_opts
        zones = sorted(hourly["border"].astype(str).str.lower().unique())
        opts = [{"label": compute.zone_label(z.upper()), "value": z}
                for z in zones]
        default = "de" if "de" in zones else (zones[0] if zones else None)
        if "regime" in hourly.columns:
            for r in sorted(pd.Series(hourly["regime"]).dropna().unique()):
                regime_opts.append({"label": compute.regime_label(r),
                                    "value": int(r)})
        # The contract scorecard keys zones upper-case
        contract_opts = [{"label": compute.zone_label(z.upper()),
                          "value": z.upper()} for z in zones]
        contract_default = default.upper() if default else None
        return opts, default, contract_opts, contract_default, regime_opts

    @app.callback(
        Output("pgnn-bt-series", "figure"),
        Output("pgnn-bt-hscatter", "figure"),
        Output("pgnn-bt-herrhist", "figure"),
        Output("pgnn-bt-hbyhour", "figure"),
        Output("pgnn-bt-pooled", "children"),
        Input("pgnn-bt-run", "value"),
        Input("pgnn-bt-hzone", "value"),
        Input("pgnn-bt-hfreq", "value"),
    )
    def update_hourly(run_id, zone, freq):
        empty = styled_empty_figure("No hourly backtest rows")
        if not zone:
            return empty, empty, empty, empty, ""
        df = compute.backtest_hourly(run_id, zone)
        if df is None or df.empty:
            return empty, empty, empty, empty, ""

        label = compute.zone_label(str(zone).upper())
        wide = compute.resample_hourly(df, freq or "D")
        freq_label = {"h": "hourly", "D": "daily mean",
                      "W": "weekly mean"}.get(freq or "D", "daily mean")
        series = figures.fig_backtest_series(
            wide, f"{label}: realised vs predicted ({freq_label})")

        plot = pd.DataFrame({
            "y_true": df["y_true"],
            "y_pred": df["y_pred"],
            "hover": df["ts_cet"].dt.strftime("%Y-%m-%d %H:%M"),
        }).dropna()
        scatter = figures.fig_pred_vs_realised(
            plot, f"{label}: hourly predicted vs realised ({len(plot):,} h)")
        errhist = figures.fig_error_histogram(
            plot["y_pred"] - plot["y_true"], f"{label}: hourly error")
        byhour = figures.fig_error_by_hour(
            compute.error_by_hour(df), f"{label}: error by hour of day")

        pooled = compute.pooled_metrics(df)
        summary = " · ".join(
            f"{r['model']} RMSE {r['rmse']:.2f} / MAE {r['mae']:.2f} / "
            f"R² {r['r2']:.3f}"
            for _, r in pooled.iterrows()
        ) if not pooled.empty else ""
        return series, scatter, errhist, byhour, summary

    # --- walk-forward ------------------------------------------------------
    @app.callback(
        Output("pgnn-bt-wfchart", "figure"),
        Input("pgnn-bt-run", "value"),
        Input("pgnn-bt-wfview", "value"),
        Input("pgnn-bt-wfmetric", "value"),
    )
    def update_walk_forward(run_id, view, metric):
        view = view or "by_lead"
        table = store.load_backtest_table(run_id, view)
        if table is None or table.empty:
            return styled_empty_figure(f"{view}.parquet not published "
                                       "for this run")
        titles = {"by_lead": "Out-of-sample skill vs days since retrain",
                  "by_origin": "Skill per retrain origin",
                  "by_regime": "Skill per market regime"}
        return figures.fig_walk_forward(
            table, WF_KEY[view], metric or "r2", titles[view])

    # --- contract skill ----------------------------------------------------
    @app.callback(
        Output("pgnn-bt-scorecard", "data"),
        Output("pgnn-bt-scorecard", "columns"),
        Output("pgnn-bt-scorecard", "page_size"),
        Output("pgnn-bt-scorecard", "style_cell_conditional"),
        Output("pgnn-bt-scorecardmsg", "children"),
        Input("pgnn-bt-run", "value"),
        Input("pgnn-bt-kind", "value"),
        Input("pgnn-bt-shape", "value"),
        Input("pgnn-bt-regime", "value"),
    )
    def update_scorecard(run_id, kind, shape, regime):
        df = _filtered(run_id, kind or "day", regime)
        if df is None or df.empty:
            return (*EMPTY_TABLE,
                    "No hourly artefact for this run "
                    f"(backtest/run_id={store.resolve_backtest_run(run_id)}/"
                    "hourly.parquet).")
        card = compute.backtest_scorecard(df, shape=shape or "base")
        if card.empty:
            return (*EMPTY_TABLE,
                    "No fully-covered contracts for this selection "
                    "(weekend blocks trade Base only).")
        card = card.sort_values("mae")
        records = []
        for _, r in card.iterrows():
            rec = {
                "Zone": compute.zone_label(r["zone"]),
                "Contracts": r["n"],
                "MAE": f"{r['mae']:.2f}",
                "Bias": f"{r['bias']:+.2f}",
                "RMSE": f"{r['rmse']:.2f}",
            }
            if "skill_vs_persist" in card.columns and pd.notna(r.get("skill_vs_persist")):
                rec["Skill vs persist"] = f"{r['skill_vs_persist']:+.1%}"
            if "skill_vs_baseline" in card.columns and pd.notna(r.get("skill_vs_baseline")):
                rec["Skill vs baseline"] = f"{r['skill_vs_baseline']:+.1%}"
            records.append(rec)
        return (*_table_props(records, first_col_left="Zone"), "")

    @app.callback(
        Output("pgnn-bt-scatter", "figure"),
        Output("pgnn-bt-errhist", "figure"),
        Input("pgnn-bt-run", "value"),
        Input("pgnn-bt-kind", "value"),
        Input("pgnn-bt-shape", "value"),
        Input("pgnn-bt-zone", "value"),
        Input("pgnn-bt-regime", "value"),
    )
    def update_charts(run_id, kind, shape, zone, regime):
        df = _filtered(run_id, kind or "day", regime)
        if df is None or df.empty or not zone:
            empty = styled_empty_figure("No backtest data")
            return empty, empty
        suffix = f"_{shape or 'base'}"
        sub = df[df["border"].str.upper() == zone].copy()
        sub = sub.dropna(subset=[f"y_true{suffix}", f"y_pred{suffix}"])
        if sub.empty:
            empty = styled_empty_figure("No fully-covered contracts here")
            return empty, empty
        plot = pd.DataFrame({
            "y_true": sub[f"y_true{suffix}"],
            "y_pred": sub[f"y_pred{suffix}"],
            "hover": sub["window_start"].dt.strftime("%Y-%m-%d")
            + " (" + sub["kind"] + ")",
        })
        label = (f"{compute.zone_label(zone)} {KIND_LABEL.get(kind, kind)} "
                 f"{(shape or 'base').capitalize()}")
        scatter = figures.fig_pred_vs_realised(
            plot, f"{label}: predicted vs realised ({len(plot)} contracts)")
        errhist = figures.fig_error_histogram(
            plot["y_pred"] - plot["y_true"], f"{label}: contract price error")
        return scatter, errhist
