"""Contract Distribution tab: full member distribution for one contract.

Pick a zone and a contract; get the violin of per-member contract prices, a
quantile table, and -- once the delivery window has settled -- the realised
spot marker computed under the same CET base/peak rules.
"""
from __future__ import annotations

import logging

import pandas as pd
from dash import Input, Output, dash_table, dcc, html

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    CONTROL_PANEL_STYLE,
    LABEL_STYLE,
    styled_empty_figure,
)

from . import compute, figures, store

logger = logging.getLogger(__name__)

QUANTS = [0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95]


def get_layout():
    runs = store.list_as_of()
    latest = store.latest_run()
    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            html.Div(style={"display": "flex", "flexWrap": "wrap",
                            "alignItems": "flex-end", "gap": "18px"}, children=[
                html.Div([
                    html.Label("Run (as_of)", style=LABEL_STYLE),
                    dcc.Dropdown(id="pgnn-dist-run",
                                 options=[{"label": r, "value": r} for r in runs],
                                 value=latest, clearable=False,
                                 style={"width": "180px"}),
                ]),
                html.Div([
                    html.Label("Zone", style=LABEL_STYLE),
                    dcc.Dropdown(id="pgnn-dist-zone", options=[], value=None,
                                 clearable=False, style={"width": "140px"}),
                ]),
                html.Div([
                    html.Label("Contract", style=LABEL_STYLE),
                    dcc.Dropdown(id="pgnn-dist-contract", options=[], value=None,
                                 clearable=False, style={"width": "260px"}),
                ]),
                html.Div([
                    html.Label("Shape", style=LABEL_STYLE),
                    dcc.Dropdown(id="pgnn-dist-shape",
                                 options=[{"label": s, "value": s}
                                          for s in ("Base", "Peak")],
                                 value="Base", clearable=False,
                                 style={"width": "120px"}),
                ]),
                html.Div([
                    html.Label("Family", style=LABEL_STYLE),
                    dcc.Dropdown(id="pgnn-dist-family",
                                 options=[
                                     {"label": "EC-ENS (ST)", "value": store.FAMILY_ST},
                                     {"label": "EC-EXT (MT)", "value": store.FAMILY_MT},
                                 ],
                                 value=store.FAMILY_ST, clearable=False,
                                 style={"width": "170px"}),
                ]),
            ]),
        ]),

        html.Div(style=CARD_STYLE, children=[
            dcc.Loading(dcc.Graph(id="pgnn-dist-violin")),
        ]),

        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.P("Member quantiles (EUR/MWh)", style=CARD_HEADER_TEXT_STYLE),
            ]),
            html.Div(style={"padding": "12px 16px"},
                     children=[dcc.Loading(html.Div(id="pgnn-dist-table"))]),
        ]),
    ])


def _member_values(as_of: str, zone: str, contract: str, shape: str, family: str):
    members = compute.member_contracts(as_of)
    if members is None:
        return None, None
    sel = members[
        (members["family"] == family)
        & (members["region"] == zone)
        & (members["contract"] == contract)
    ]
    if sel.empty:
        return None, None
    col = "price_eur_mwh_peak" if shape == "Peak" else "price_eur_mwh_base"
    if col not in sel.columns:
        return None, sel
    return sel[col].dropna(), sel


def register_callbacks(app):
    @app.callback(
        Output("pgnn-dist-zone", "options"),
        Output("pgnn-dist-zone", "value"),
        Output("pgnn-dist-contract", "options"),
        Output("pgnn-dist-contract", "value"),
        Input("pgnn-dist-run", "value"),
        Input("pgnn-dist-family", "value"),
    )
    def update_selectors(as_of, family):
        if not as_of:
            return [], None, [], None
        members = compute.member_contracts(as_of)
        if members is None:
            return [], None, [], None
        fam = members[members["family"] == (family or store.FAMILY_ST)]
        zones = sorted(fam["region"].unique())
        contracts = compute.contract_order(fam.rename(columns={}))
        zone_opts = [{"label": compute.zone_label(z), "value": z} for z in zones]
        contract_opts = [{"label": c, "value": c} for c in contracts]
        return (
            zone_opts, ("DE" if "DE" in zones else (zones[0] if zones else None)),
            contract_opts, (contracts[0] if contracts else None),
        )

    @app.callback(
        Output("pgnn-dist-violin", "figure"),
        Output("pgnn-dist-table", "children"),
        Input("pgnn-dist-run", "value"),
        Input("pgnn-dist-zone", "value"),
        Input("pgnn-dist-contract", "value"),
        Input("pgnn-dist-shape", "value"),
        Input("pgnn-dist-family", "value"),
    )
    def update_distribution(as_of, zone, contract, shape, family):
        if not all([as_of, zone, contract, shape, family]):
            return styled_empty_figure("Select a run, zone and contract"), None
        values, sel = _member_values(as_of, zone, contract, shape, family)
        if values is None or values.empty:
            return styled_empty_figure(
                "No fully-covered members for this contract/shape "
                "(weekend blocks trade Base only)"), None

        meta = sel.iloc[0]
        realised = None
        try:
            win_end = pd.Timestamp(meta["window_end"])
            if win_end <= pd.Timestamp.utcnow().tz_localize(None):
                realised = compute.realised_contract_price(
                    zone, meta["window_start"], meta["window_end"], shape)
        except Exception as e:  # noqa: BLE001
            logger.warning("realised overlay failed: %s", e)

        title = (f"{compute.zone_label(zone)} {contract} {shape} \u2014 "
                 f"{len(values)} members ({figures.FAMILY_LABEL.get(family, family)})")
        fig = figures.fig_member_distribution(values, title, realised=realised)

        row = {"Members": len(values),
               "Mean": f"{values.mean():.2f}",
               "Std": f"{values.std(ddof=0):.2f}"}
        for q in QUANTS:
            row[f"P{int(q * 100)}"] = f"{values.quantile(q):.2f}"
        if realised is not None:
            row["Realised"] = f"{realised:.2f}"
        table = dash_table.DataTable(
            data=[row],
            columns=[{"name": k, "id": k} for k in row],
            style_cell={"fontSize": "12px", "fontFamily": "Inter, sans-serif",
                        "padding": "6px 12px", "textAlign": "center"},
            style_header={"fontWeight": "600", "backgroundColor": "#f4f5f7",
                          "fontSize": "12px"},
        )
        return fig, table
