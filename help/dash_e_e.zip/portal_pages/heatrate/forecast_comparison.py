"""
HeatRate Dashboard - Forecast Comparison sub-page
=================================================
For a chosen country + fuel, overlays:

    * Realised (REMIT) availability for the last 30 days
    * Every forecast issued in the last 30 days (one trace per as_of)

The newest forecast is highlighted; older issue dates fade towards grey so
the eye can trace how the forecast trajectory drifted run-over-run.
"""
import logging
from datetime import date

import dash_bootstrap_components as dbc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, dcc, html
from jain_commods.core.cache.data.availability import ModelArea, ModelFuel

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    COLORS,
    CONTROL_PANEL_STYLE,
    FUEL_COLORS,
    LABEL_STYLE,
    apply_chart_style,
    styled_empty_figure,
)

logger = logging.getLogger(__name__)

_FUEL_COLOR_MAP = {
    ModelFuel.GAS.value: 'fossil gas',
    ModelFuel.COAL.value: 'fossil hard coal',
    ModelFuel.LIGNITE.value: 'fossil brown coal/lignite',
    ModelFuel.NUCLEAR.value: 'nuclear',
    ModelFuel.BIOMASS.value: 'biomass',
}

# Refresh issue-date listing on the client every 2 hours.
_ASOF_REFRESH_MS = 2 * 60 * 60 * 1000

_LOOKBACK_DAYS = 30


# ---------------------------------------------------------------------------
# Chart
# ---------------------------------------------------------------------------

def _fuel_color(fuel: str) -> str:
    color_key = _FUEL_COLOR_MAP.get(fuel, 'other')
    return FUEL_COLORS.get(color_key, COLORS['accent'])


def _interp_color(base_hex: str, mix: float) -> str:
    """Linearly mix ``base_hex`` toward light grey by ``mix`` in [0, 1]."""
    r, g, b = int(base_hex[1:3], 16), int(base_hex[3:5], 16), int(base_hex[5:7], 16)
    target = (200, 200, 200)
    nr = int(r + (target[0] - r) * mix)
    ng = int(g + (target[1] - g) * mix)
    nb = int(b + (target[2] - b) * mix)
    return f"rgb({nr},{ng},{nb})"


def create_forecast_comparison_chart(
    forecasts: dict,
    realised_df: pd.DataFrame,
    area: str,
    fuel: str,
):
    """Build the comparison chart.

    Parameters
    ----------
    forecasts :
        ``{as_of_iso: forecast DataFrame}`` for each issue date in the lookback
        window. The most recent as_of is rendered with the full fuel color;
        older issue dates fade toward grey.
    realised_df :
        Realised series (last 30 days) with columns target_date / realised_mw.
    """
    if not forecasts and (realised_df is None or realised_df.empty):
        return styled_empty_figure(f"No forecasts or realised data for {area} {fuel.title()}")

    base_hex = _fuel_color(fuel)
    fig = go.Figure()

    # Sort issue dates ascending so older are added first (drawn below newer).
    as_of_keys = sorted(forecasts.keys())
    n = len(as_of_keys)
    for i, as_of_iso in enumerate(as_of_keys):
        df = forecasts[as_of_iso].sort_values("target_date")
        # mix=0 for the newest forecast, ~0.75 for the oldest.
        mix = 0.0 if n <= 1 else (1 - i / max(n - 1, 1)) * 0.75
        color = _interp_color(base_hex, mix)
        is_newest = i == n - 1
        fig.add_trace(go.Scatter(
            x=df["target_date"],
            y=df["model_prediction_mw"],
            mode="lines",
            name=f"Forecast {as_of_iso}",
            line=dict(width=3 if is_newest else 1.2, color=color),
            opacity=1.0 if is_newest else 0.7,
            legendgroup="forecasts",
            legendgrouptitle_text="Forecast issue dates" if i == 0 else None,
        ))

    if realised_df is not None and not realised_df.empty:
        fig.add_trace(go.Scatter(
            x=realised_df["target_date"],
            y=realised_df["realised_mw"],
            mode="lines",
            name="Realised (REMIT)",
            line=dict(width=3, color="#111", dash="solid"),
        ))

    apply_chart_style(fig, height=560)
    fig.update_layout(
        title=dict(
            text=(
                f"Forecast Comparison: {area} {fuel.title()} "
                f"— last {_LOOKBACK_DAYS} days"
            ),
            font=dict(size=16),
        ),
        yaxis_title="Availability (MW)",
        xaxis_title="Target Date",
        legend=dict(orientation="v", yanchor="top", y=1.0, xanchor="left", x=1.02),
        hovermode="x unified",
    )
    return fig


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def get_layout(data_handler):
    """Return the layout for the Forecast Comparison sub-page."""
    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Country", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="hr-fc-area-select",
                        options=[{"label": a.name, "value": a.value} for a in ModelArea],
                        value=ModelArea.FR.value,
                        clearable=False,
                    )
                ], width=3),
                dbc.Col([
                    html.Label("Fuel", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="hr-fc-fuel-select",
                        options=[{"label": f.title(), "value": f.value} for f in ModelFuel],
                        value=ModelFuel.NUCLEAR.value,
                        clearable=False,
                    )
                ], width=3),
            ])
        ]),

        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.H4("Forecast Comparison (last 30 days)", style=CARD_HEADER_TEXT_STYLE),
            ]),
            dcc.Loading(
                type="circle",
                color=COLORS['accent'],
                children=[
                    dcc.Graph(id="hr-fc-main-chart", config={"displayModeBar": False})
                ]
            )
        ]),

        # Quiet client-side ticker so when new as_of partitions land mid-session
        # we redraw with the new forecasts automatically.
        dcc.Interval(
            id="hr-fc-refresh-interval",
            interval=_ASOF_REFRESH_MS,
            n_intervals=0,
        ),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_forecast_comparison_callbacks(app, data_handler):
    """Register callbacks for the Forecast Comparison sub-page."""

    @app.callback(
        Output("hr-fc-main-chart", "figure"),
        [Input("hr-fc-area-select", "value"),
         Input("hr-fc-fuel-select", "value"),
         Input("hr-fc-refresh-interval", "n_intervals")],
    )
    def update_chart(area, fuel, _n):
        if not area or not fuel:
            return styled_empty_figure("Select country and fuel")

        try:
            forecasts = data_handler.get_forecasts_in_window(
                area, fuel, lookback_days=_LOOKBACK_DAYS
            )
        except Exception as exc:
            logger.warning(f"Forecast window load failed for {area}/{fuel}: {exc}")
            forecasts = {}

        try:
            realised = data_handler.get_realised_availability(area, fuel)
        except Exception as exc:
            logger.warning(f"Realised load failed for {area}/{fuel}: {exc}")
            realised = pd.DataFrame()

        return create_forecast_comparison_chart(forecasts, realised, area, fuel)
