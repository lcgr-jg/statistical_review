"""
DataHandler for HeatRate Dashboard
==================================
Loads and caches heat-rate availability forecasts from S3.
"""
import logging
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple

import pandas as pd
from jain_commods.core.cache.data.availability import (
    ModelArea,
    ModelFuel,
    factory_zonal_forecast_availability,
)
from jain_commods.core.cache.data.fundamentals import (
    GenAvailBiomass,
    GenAvailCoal,
    GenAvailGas,
    GenAvailLignite,
    GenAvailNuclear,
)

# Import enterprise caching
from core.data_freshness import tracker

logger = logging.getLogger(__name__)

# Realised (REMIT history) availability cache classes per fuel.
_REALISED_AVAIL_CLASSES = {
    ModelFuel.GAS.value: GenAvailGas,
    ModelFuel.COAL.value: GenAvailCoal,
    ModelFuel.LIGNITE.value: GenAvailLignite,
    ModelFuel.NUCLEAR.value: GenAvailNuclear,
    ModelFuel.BIOMASS.value: GenAvailBiomass,
}

class HeatRateDataHandler:
    """Loads and caches HeatRate model data from S3."""

    def __init__(self):
        self._availability_cache: Dict[str, pd.DataFrame] = {}
        # (fuel, as_of_iso) -> all-areas DataFrame for that issue date
        self._as_of_cache: Dict[Tuple[str, str], pd.DataFrame] = {}
        # fuel -> sorted list of available as_of dates
        self._as_of_dates_cache: Dict[str, List[date]] = {}
        # fuel -> wide DataFrame (index=valuedate, cols=zones) of realised availability
        self._realised_cache: Dict[str, pd.DataFrame] = {}
        self.last_update: Optional[datetime] = None
        self.is_ready = False

    def load_all_data(self):
        """
        Load the latest availability forecasts for all supported area/fuel pairs.
        Called by the global DashboardCache scheduler.
        """
        logger.info("HeatRateDataHandler: Loading all availability forecasts from S3...")
        
        new_cache = {}
        total_rows = 0
        
        # We iterate through all supported fuels and areas to warm the cache
        for fuel in ModelFuel:
            try:
                reader = factory_zonal_forecast_availability(fuel.value)
                # We can use load_all_areas to get all areas for this fuel in one S3 call
                # if the model publishes the 'all.parquet' file.
                as_of = reader.latest_as_of()
                if not as_of:
                    continue
                
                df_all = reader.load_all_areas(as_of=as_of)
                if df_all.empty:
                    continue
                
                # Store by fuel
                new_cache[fuel.value] = df_all
                total_rows += len(df_all)
                
            except Exception as e:
                logger.warning(f"HeatRateDataHandler: Failed to load {fuel.value}: {e}")

        self._availability_cache = new_cache
        # The scheduled refresh invalidates per-as_of, dates-listing and
        # realised caches so the dashboard picks up newly published forecasts
        # (e.g. today's as_of becoming available).
        self._as_of_cache.clear()
        self._as_of_dates_cache.clear()
        self._realised_cache.clear()
        self.last_update = datetime.now()
        self.is_ready = True
        
        # Register with data freshness tracker
        tracker.register_data_source(
            "HeatRate Availability (S3)",
            self.last_update,
            expected_frequency_minutes=60,
            metadata={
                'total_rows': total_rows,
                'fuels_loaded': list(new_cache.keys()),
            }
        )
        
        logger.info(f"HeatRateDataHandler: Load complete. {total_rows} rows cached.")
        return self

    def get_availability(self, area: str, fuel: str) -> pd.DataFrame:
        """Get cached availability for a specific area and fuel."""
        fuel = fuel.lower()
        area = area.upper()
        
        df_fuel = self._availability_cache.get(fuel)
        if df_fuel is None or df_fuel.empty:
            # Fallback to direct load if not in cache (shouldn't happen if warm)
            try:
                reader = factory_zonal_forecast_availability(fuel)
                return reader.load_latest(area=area)
            except Exception:
                return pd.DataFrame()
        
        # Filter the cached fuel dataframe for the specific area
        mask = df_fuel['area'].astype(str).str.upper() == area
        return df_fuel[mask].copy()

    def list_all_as_of_dates(self) -> List[date]:
        """Union of issue dates across every supported fuel, sorted desc.

        Today's date is always included in the dropdown so the UI lets the user
        select it as soon as the daily forecast publishes.
        """
        all_dates: set = set()
        for fuel in ModelFuel:
            try:
                all_dates.update(self.list_as_of_dates(fuel.value))
            except Exception as exc:
                logger.warning(f"list_all_as_of_dates: skip {fuel.value}: {exc}")
        all_dates.add(date.today())
        return sorted(all_dates, reverse=True)

    def list_as_of_dates(self, fuel: str) -> List[date]:
        """Return all available forecast as_of (issue) dates for a fuel, sorted desc."""
        fuel = fuel.lower()
        if fuel in self._as_of_dates_cache:
            return self._as_of_dates_cache[fuel]
        try:
            reader = factory_zonal_forecast_availability(fuel)
            dates = sorted(reader.list_as_of_dates(), reverse=True)
        except Exception as e:
            logger.warning(f"Failed to list as_of dates for {fuel}: {e}")
            dates = []
        self._as_of_dates_cache[fuel] = dates
        return dates

    def get_availability_for_as_of(
        self, area: str, fuel: str, as_of: date
    ) -> pd.DataFrame:
        """Load forecast availability for a specific area/fuel/as_of date."""
        fuel = fuel.lower()
        area = area.upper()
        key = (fuel, as_of.isoformat() if isinstance(as_of, date) else str(as_of))

        df_all = self._as_of_cache.get(key)
        if df_all is None:
            try:
                reader = factory_zonal_forecast_availability(fuel)
                df_all = reader.load_all_areas(as_of=as_of)
            except Exception as exc:
                logger.warning(
                    f"load_all_areas failed for {fuel}@{as_of}, falling back to "
                    f"single-area load: {exc}"
                )
                try:
                    reader = factory_zonal_forecast_availability(fuel)
                    df_all = reader.load(area=area, as_of=as_of, fuel=fuel)
                except Exception as exc2:
                    logger.error(f"Failed to load {fuel}@{as_of} for {area}: {exc2}")
                    return pd.DataFrame()
            self._as_of_cache[key] = df_all

        if df_all is None or df_all.empty:
            return pd.DataFrame()
        mask = df_all["area"].astype(str).str.upper() == area
        return df_all[mask].copy()

    def get_forecasts_in_window(
        self,
        area: str,
        fuel: str,
        lookback_days: int = 30,
    ) -> Dict[str, pd.DataFrame]:
        """Return {as_of_iso: forecast_df} for every as_of in the last N days.

        Forecasts published outside the window are skipped. Per-as_of frames
        are reused from the lazy ``_as_of_cache``.
        """
        today = date.today()
        cutoff = today - timedelta(days=lookback_days)
        out: Dict[str, pd.DataFrame] = {}
        for d in self.list_as_of_dates(fuel):
            if d < cutoff or d > today:
                continue
            df = self.get_availability_for_as_of(area, fuel, d)
            if df is not None and not df.empty:
                out[d.isoformat()] = df
        return out

    def get_realised_availability(self, area: str, fuel: str) -> pd.DataFrame:
        """Return realised (REMIT-history) availability for a fuel/area.

        Returns a DataFrame with columns ['target_date', 'realised_mw'], one row
        per day, only for dates with non-null observed availability.
        """
        fuel = fuel.lower()
        area = area.upper()

        cls = _REALISED_AVAIL_CLASSES.get(fuel)
        if cls is None:
            return pd.DataFrame()

        wide = self._realised_cache.get(fuel)
        if wide is None:
            try:
                obj = cls()
                obj.load(from_s3=True, show_metadata=False)
                wide = getattr(obj, "data", None)
            except Exception as exc:
                logger.warning(f"Failed to load realised availability for {fuel}: {exc}")
                wide = None
            self._realised_cache[fuel] = wide if wide is not None else pd.DataFrame()
            wide = self._realised_cache[fuel]

        if wide is None or wide.empty:
            return pd.DataFrame()

        zone_col = area.lower()
        if zone_col not in wide.columns:
            return pd.DataFrame()

        s = wide[zone_col].dropna()
        if s.empty:
            return pd.DataFrame()

        out = s.reset_index()
        out.columns = ["target_date", "realised_mw"]
        out["target_date"] = pd.to_datetime(out["target_date"]).dt.date
        # Restrict to the last 30 days up to today.
        today = date.today()
        cutoff = today - timedelta(days=30)
        out = out[(out["target_date"] <= today) & (out["target_date"] >= cutoff)]
        return out

    def get_last_update_time(self):
        return self.last_update
