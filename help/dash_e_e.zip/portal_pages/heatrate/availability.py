"""
HeatRate Dashboard - Availability sub-page
==========================================
Availability forecasts for thermal fleets (Gas, Coal, Lignite, Nuclear, Biomass)
loaded from the heatrate model S3 cache.

Layout:
    * Country dropdown        (default: FR)
    * Issue Date dropdown     (default: today; union of as_ofs across all fuels)

The chart overlays, for the selected country and issue date, one forecast line
per fuel plus the realised (REMIT) availability line for the last 30 days.

The issue-date dropdown is auto-refreshed every 2 hours by a client-side
``dcc.Interval`` so that the user sees today's as_of partition as soon as the
upstream model publishes it.
"""
import logging
from datetime import date

import dash_bootstrap_components as dbc
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash import Input, Output, dcc, html
from jain_commods.core.cache.data.availability import ModelArea, ModelFuel

from portal_pages.fundamentals.styles import (
    CARD_HEADER_STYLE,
    CARD_HEADER_TEXT_STYLE,
    CARD_STYLE,
    COLORS,
    CONTROL_PANEL_STYLE,
    FUEL_COLORS,
    LABEL_STYLE,
    apply_chart_style,
    styled_empty_figure,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Map ModelFuel.value -> key in FUEL_COLORS palette.
_FUEL_COLOR_MAP = {
    ModelFuel.GAS.value: 'fossil gas',
    ModelFuel.COAL.value: 'fossil hard coal',
    ModelFuel.LIGNITE.value: 'fossil brown coal/lignite',
    ModelFuel.NUCLEAR.value: 'nuclear',
    ModelFuel.BIOMASS.value: 'biomass',
}

_FUELS = [f.value for f in ModelFuel]

# Refresh issue-date options every 2 hours (client-side dcc.Interval).
_ASOF_REFRESH_MS = 2 * 60 * 60 * 1000


# ---------------------------------------------------------------------------
# Chart Creation
# ---------------------------------------------------------------------------

def _fuel_color(fuel: str) -> str:
    color_key = _FUEL_COLOR_MAP.get(fuel, 'other')
    return FUEL_COLORS.get(color_key, COLORS['accent'])


def _resample_realised_to_daily_mean(df: pd.DataFrame) -> pd.DataFrame:
    """Return realised availability as one daily mean observation per day."""
    if df is None or df.empty:
        return pd.DataFrame()

    daily = df.copy()
    daily["target_date"] = pd.to_datetime(daily["target_date"])
    daily["realised_mw"] = pd.to_numeric(daily["realised_mw"], errors="coerce")
    daily = (
        daily.dropna(subset=["target_date", "realised_mw"])
        .set_index("target_date")["realised_mw"]
        .resample("D")
        .mean()
        .dropna()
        .reset_index()
    )
    return daily


def create_availability_chart(
    fuel_frames: dict,
    realised_frames: dict,
    area: str,
    as_of_iso: str | None,
):
    """Build the multi-fuel availability chart as a stack of subplots.

    One subplot per fuel, each showing:
        * Model Prediction (forecast)
        * EQ Baseline (planned availability from EnergyQuantified)
        * Realised (REMIT history, last 30 days)

    Parameters
    ----------
    fuel_frames :
        ``{fuel: forecast DataFrame}`` for the selected (area, as_of). Frames
        may be empty if a fuel was not published for that as_of.
    realised_frames :
        ``{fuel: realised DataFrame}`` (last 30 days), keyed by fuel.
    """
    # Only show fuels for which we actually produced a forecast for this
    # (area, as_of). Fuels with no forecast (e.g. DE nuclear, waste) are
    # dropped entirely so we don't render empty subplots.
    fuels_to_show = [
        f for f in _FUELS
        if fuel_frames.get(f) is not None and not fuel_frames[f].empty
    ]
    if not fuels_to_show:
        return styled_empty_figure(f"No forecast for {area} on {as_of_iso or 'today'}")

    n = len(fuels_to_show)
    fig = make_subplots(
        rows=n, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.10,
        subplot_titles=[f.title() for f in fuels_to_show],
    )

    for i, fuel in enumerate(fuels_to_show, start=1):
        base_hex = _fuel_color(fuel)
        r, g, b = int(base_hex[1:3], 16), int(base_hex[3:5], 16), int(base_hex[5:7], 16)
        fill = f'rgba({r},{g},{b},0.12)'

        df = fuel_frames.get(fuel)
        if df is not None and not df.empty:
            df = df.sort_values("target_date")

            fig.add_trace(go.Scatter(
                x=df["target_date"],
                y=df["model_prediction_mw"],
                mode="lines",
                name="Model Prediction",
                line=dict(width=2.5, color=base_hex),
                fill="tozeroy",
                fillcolor=fill,
                legendgroup=fuel,
                showlegend=(i == 1),
            ), row=i, col=1)

            if "eq_forecast_mw" in df.columns and not df["eq_forecast_mw"].isna().all():
                fig.add_trace(go.Scatter(
                    x=df["target_date"],
                    y=df["eq_forecast_mw"],
                    mode="lines",
                    name="EQ Planned",
                    line=dict(width=1.5, color="#888", dash="dash"),
                    legendgroup=fuel,
                    showlegend=(i == 1),
                ), row=i, col=1)

        rdf = realised_frames.get(fuel)
        if rdf is not None and not rdf.empty:
            rdf = _resample_realised_to_daily_mean(rdf)

        if rdf is not None and not rdf.empty:
            fig.add_trace(go.Scatter(
                x=rdf["target_date"],
                y=rdf["realised_mw"],
                mode="lines",
                name="Realised (REMIT)",
                line=dict(width=2, color="#222", dash="solid"),
                legendgroup=fuel,
                showlegend=(i == 1),
            ), row=i, col=1)

        fig.update_yaxes(title_text="MW", row=i, col=1)

    fig.update_xaxes(title_text="Target Date", row=n, col=1)
    # shared_xaxes hides tick labels on non-bottom subplots by default; restore them.
    fig.update_xaxes(showticklabels=True)

    apply_chart_style(fig, height=300 * n)

    title = f"Availability: {area} — all fuels"
    if as_of_iso:
        title += f" (Forecast as-of {as_of_iso})"
    fig.update_layout(
        title=dict(text=title, font=dict(size=16)),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hovermode="x unified",
    )

    return fig


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def _build_as_of_options(data_handler):
    """Return (options, default_value) for the issue-date dropdown."""
    dates = data_handler.list_all_as_of_dates()
    today_iso = date.today().isoformat()
    options = [{"label": d.isoformat(), "value": d.isoformat()} for d in dates]
    default = today_iso if any(o["value"] == today_iso for o in options) else (
        options[0]["value"] if options else None
    )
    return options, default


def get_layout(data_handler):
    """Return the layout for the availability sub-page."""
    as_of_options, default_as_of = _build_as_of_options(data_handler)

    return html.Div([
        html.Div(style=CONTROL_PANEL_STYLE, children=[
            dbc.Row([
                dbc.Col([
                    html.Label("Country", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="hr-avail-area-select",
                        options=[{"label": a.name, "value": a.value} for a in ModelArea],
                        value=ModelArea.FR.value,
                        clearable=False,
                    )
                ], width=3),
                dbc.Col([
                    html.Label("Issue Date (As-of)", style=LABEL_STYLE),
                    dcc.Dropdown(
                        id="hr-avail-asof-select",
                        options=as_of_options,
                        value=default_as_of,
                        clearable=False,
                        placeholder="Select an issue date",
                    )
                ], width=3),
            ])
        ]),

        html.Div(style=CARD_STYLE, children=[
            html.Div(style=CARD_HEADER_STYLE, children=[
                html.H4("Availability Forecast", style=CARD_HEADER_TEXT_STYLE),
            ]),
            dcc.Loading(
                type="circle",
                color=COLORS['accent'],
                children=[
                    dcc.Graph(id="hr-avail-main-chart", config={"displayModeBar": False})
                ]
            )
        ]),

        # Periodically refresh the issue-date dropdown so today's as_of
        # appears as soon as the upstream publishes (cron warms every hour;
        # this picks up the result client-side every 2h).
        dcc.Interval(
            id="hr-avail-asof-refresh-interval",
            interval=_ASOF_REFRESH_MS,
            n_intervals=0,
        ),
    ])


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_availability_callbacks(app, data_handler):
    """Register callbacks for the availability sub-page."""

    @app.callback(
        Output("hr-avail-asof-select", "options"),
        [Input("hr-avail-asof-refresh-interval", "n_intervals")],
    )
    def refresh_as_of_options(_n):
        """Re-list the as_of dates every 2h (and on first load)."""
        options, _ = _build_as_of_options(data_handler)
        return options

    @app.callback(
        Output("hr-avail-main-chart", "figure"),
        [Input("hr-avail-area-select", "value"),
         Input("hr-avail-asof-select", "value")],
    )
    def update_availability_chart(area, as_of_iso):
        if not area:
            return styled_empty_figure("Select a country")

        if not as_of_iso:
            as_of_iso = date.today().isoformat()

        try:
            as_of = date.fromisoformat(as_of_iso)
        except ValueError:
            logger.warning(f"Bad as_of value '{as_of_iso}', falling back to today.")
            as_of = date.today()
            as_of_iso = as_of.isoformat()

        fuel_frames: dict = {}
        realised_frames: dict = {}
        for fuel in _FUELS:
            try:
                df = data_handler.get_availability_for_as_of(area, fuel, as_of)
            except Exception as exc:
                logger.warning(f"Forecast load failed for {fuel}@{as_of}: {exc}")
                df = pd.DataFrame()
            fuel_frames[fuel] = df

            try:
                rdf = data_handler.get_realised_availability(area, fuel)
            except Exception as exc:
                logger.warning(f"Realised load failed for {fuel}/{area}: {exc}")
                rdf = pd.DataFrame()
            realised_frames[fuel] = rdf

        return create_availability_chart(fuel_frames, realised_frames, area, as_of_iso)
