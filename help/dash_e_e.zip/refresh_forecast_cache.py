"""
Script to refresh forecast cache data by re-downloading from EQ API and overwriting S3.

Usage:
    python refresh_forecast_cache.py --issue_date 2026-02-13 --model EC-EXT

This will:
1. Download fresh data from EnergyQuantified API for the specified issue date
2. Overwrite the existing S3 cache files with correct data
"""
import datetime
import argparse

# Import forecast cache classes
from jain_commods.core.cache.data.fundamentals import (
    GenWindFcstMT, GenSolarFcstMT, ConsFcstMT, ResLoadFcstMT,
    GenWindFcstST, GenSolarFcstST, ConsFcstST, ResLoadFcstST,
    ModelTag, IssueVersion,
)


# Model tag mappings
MODEL_TAG_MAP = {
    'EC-EXT': (ModelTag.EC_EXT, IssueVersion.IV00, True),
    'GFS-EXT': (ModelTag.GFS_EXT, IssueVersion.IV00, True),
    'EC': (ModelTag.EC, IssueVersion.IV00, False),
    'EC-ENS': (ModelTag.EC_ENS, IssueVersion.IV00, False),
    'GFS': (ModelTag.GFS, IssueVersion.IV00, False),
    'GFS-ENS': (ModelTag.GFS_ENS, IssueVersion.IV00, False),
}

# Variable class mappings (ST class, MT class)
VARIABLE_CLASSES = {
    'Wind': (GenWindFcstST, GenWindFcstMT),
    'Solar': (GenSolarFcstST, GenSolarFcstMT),
    'Demand': (ConsFcstST, ConsFcstMT),
    'Residual Load': (ResLoadFcstST, ResLoadFcstMT),
}


def refresh_forecast(
    issue_date: datetime.date,
    model: str = 'EC-EXT',
    variables: list = None,
):
    """
    Re-download forecast data from EQ API and save to S3, overwriting existing data.
    
    Parameters
    ----------
    issue_date : datetime.date
        The forecast issue date to refresh
    model : str
        Model name (e.g., 'EC-EXT', 'GFS-EXT', 'EC', 'EC-ENS')
    variables : list, optional
        List of variables to refresh. Defaults to all: ['Wind', 'Solar', 'Demand', 'Residual Load']
    """
    if variables is None:
        variables = ['Wind', 'Solar', 'Demand', 'Residual Load']
    
    if model not in MODEL_TAG_MAP:
        print(f"Unknown model: {model}")
        print(f"Available models: {list(MODEL_TAG_MAP.keys())}")
        return
    
    tag, version, is_mt = MODEL_TAG_MAP[model]
    
    print("=" * 80)
    print(f"REFRESHING FORECAST CACHE")
    print(f"  Model: {model} (tag={tag}, version={version}, is_mt={is_mt})")
    print(f"  Issue Date: {issue_date}")
    print(f"  Variables: {variables}")
    print("=" * 80)
    
    for variable in variables:
        if variable not in VARIABLE_CLASSES:
            print(f"\n[SKIP] Unknown variable: {variable}")
            continue
        
        st_cls, mt_cls = VARIABLE_CLASSES[variable]
        cls = mt_cls if is_mt else st_cls
        
        print(f"\n{'-' * 60}")
        print(f"Processing: {variable}")
        print(f"  Class: {cls.__name__}")
        
        try:
            # Check if class supports this tag
            if hasattr(cls, 'supported_tags') and tag not in cls.supported_tags:
                print(f"  [SKIP] {cls.__name__} does not support tag {tag}")
                print(f"         Supported tags: {cls.supported_tags}")
                continue
            
            # Create instance
            fcst = cls(tag=tag, issue_date=issue_date, issue_version=version)
            
            # Download from EQ API (using default zones and date ranges)
            # Note: issue_date is already set in constructor, download() uses self.issue_date
            print(f"  Downloading from EQ API...")
            fcst.download()
            
            if fcst.data is None or fcst.data.empty:
                print(f"  [ERROR] No data returned from API")
                continue
            
            # Show data info
            df = fcst.data
            print(f"  Downloaded data:")
            print(f"    Shape: {df.shape}")
            print(f"    Columns: {list(df.columns)[:8]}...")
            print(f"    Date range: {df.index.min()} to {df.index.max()}")
            
            # Check column casing
            sample_cols = list(df.columns)[:5]
            has_uppercase = any(str(c).isupper() for c in sample_cols)
            has_lowercase = any(str(c).islower() for c in sample_cols)
            print(f"    Column casing: uppercase={has_uppercase}, lowercase={has_lowercase}")
            
            # Save to S3 (overwriting existing)
            print(f"  Saving to S3...")
            fcst.save(to_s3=True, issue_date=issue_date)
            
            print(f"  [OK] Successfully refreshed {variable}")
            
        except Exception as e:
            print(f"  [ERROR] Failed to refresh {variable}: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 80)
    print("REFRESH COMPLETE")
    print("=" * 80)


def main():
    parser = argparse.ArgumentParser(description='Refresh forecast cache by re-downloading from EQ API')
    parser.add_argument('--issue_date', type=str, required=True,
                        help='Issue date in YYYY-MM-DD format (e.g., 2026-02-13)')
    parser.add_argument('--model', type=str, default='EC-EXT',
                        help='Model name (e.g., EC-EXT, GFS-EXT, EC, EC-ENS)')
    parser.add_argument('--variables', type=str, nargs='*', default=None,
                        help='Variables to refresh (default: all)')
    
    args = parser.parse_args()
    
    # Parse date
    issue_date = datetime.datetime.strptime(args.issue_date, '%Y-%m-%d').date()
    
    refresh_forecast(
        issue_date=issue_date,
        model=args.model,
        variables=args.variables,
    )


if __name__ == '__main__':
    main()
