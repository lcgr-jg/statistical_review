"""Redispatch (RT / RTR) — system-wide technical-restriction analytics.

Day-ahead (RT_MD) and real-time (RTR) restriction volumes and costs from the
I90 gold fact table: the up/down profile through the day, the most-redispatched
units, and the split by technology. Signed energy: + = constrained up, − = down.
"""
import sys
import pathlib

import numpy as np
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import styled_layout  # noqa: E402

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from utils.iberia_data import (  # noqa: E402
    get_unit_facts, day_window, to_madrid, cat_label, classify_unit,
)

_MUTED = "#9aa0a6"
_TEXT = "#e0e0e0"
# Diverging redispatch palette: up = warm, down = cool; day-ahead lighter than real-time.
_C = {("RT_MD", "up"): "#ffd8a8", ("RT_MD", "down"): "#a5d8ff",
      ("RTR", "up"): "#ffa94d", ("RTR", "down"): "#4dabf7"}


def _empty_fig(msg, height=360):
    fig = go.Figure()
    fig.update_layout(**styled_layout(""))
    fig.add_annotation(text=msg, showarrow=False, font=dict(color=_MUTED, size=13),
                       xref="paper", yref="paper", x=0.5, y=0.5)
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(height=height)
    return fig


def _facts(date):
    ds, de = day_window(date)
    return get_unit_facts(ds, de, categories=("RT_MD", "RTR"))  # all units, both measures


def build_volume_profile(date) -> go.Figure:
    f = _facts(date)
    e = f[f["measure"] == "energy_mwh"].copy() if not f.empty else f
    if e is None or e.empty:
        return _empty_fig(f"No redispatch on {date}")
    e["tod"] = to_madrid(e["datetime"]).strftime("%H:%M")
    e["dir"] = np.where(e["value"] >= 0, "up", "down")
    fig = go.Figure()
    for cat in ("RT_MD", "RTR"):
        for d in ("up", "down"):
            g = e[(e["category"] == cat) & (e["dir"] == d)].groupby("tod")["value"].sum().sort_index()
            if len(g):
                fig.add_bar(x=list(g.index), y=list(g.values),
                            name=f"{cat_label(cat)} {'↑' if d == 'up' else '↓'}",
                            marker_color=_C[(cat, d)])
    fig.update_layout(barmode="relative", **styled_layout(f"System redispatch volume by QH · {date}", "MWh"))
    fig.update_layout(height=360)
    fig.update_xaxes(nticks=24)
    return fig


def build_top_units(date, n=15) -> go.Figure:
    f = _facts(date)
    e = f[f["measure"] == "energy_mwh"].copy() if not f.empty else f
    if e is None or e.empty:
        return _empty_fig(f"No redispatch on {date}")
    e["abs"] = e["value"].abs()
    by_unit = e.groupby("unit")["abs"].sum().nlargest(n)
    order = list(by_unit.index)[::-1]  # largest at top of horizontal bar
    fig = go.Figure()
    for cat in ("RT_MD", "RTR"):
        g = (e[e["category"] == cat].groupby("unit")["abs"].sum().reindex(order).fillna(0))
        fig.add_bar(y=order, x=list(g.values), name=cat_label(cat), orientation="h",
                    marker_color=_C[(cat, "up")])
    fig.update_layout(barmode="stack", **styled_layout(f"Most-redispatched units · {date}", ""))
    fig.update_layout(height=460, margin=dict(l=110, r=20, t=50, b=40))
    fig.update_xaxes(title="Redispatch energy |MWh|")
    return fig


def build_by_tech(date) -> go.Figure:
    f = _facts(date)
    e = f[f["measure"] == "energy_mwh"].copy() if not f.empty else f
    if e is None or e.empty:
        return _empty_fig(f"No redispatch on {date}")
    e["tech"] = e["unit"].map(classify_unit)
    e["dir"] = np.where(e["value"] >= 0, "up", "down")
    fig = go.Figure()
    for d, color in (("up", "#ffa94d"), ("down", "#4dabf7")):
        g = e[e["dir"] == d].groupby("tech")["value"].sum().sort_values()
        if len(g):
            fig.add_bar(x=list(g.index), y=list(g.values),
                        name=f"Constrained {'up ↑' if d == 'up' else 'down ↓'}", marker_color=color)
    fig.update_layout(barmode="relative", **styled_layout(f"Redispatch by technology · {date}", "MWh"))
    fig.update_layout(height=360)
    return fig


def _kpis(date):
    f = _facts(date)
    if f is None or f.empty:
        return None
    e = f[f["measure"] == "energy_mwh"]
    out = {}
    for cat in ("RT_MD", "RTR"):
        c = e[e["category"] == cat]["value"]
        out[f"{cat}_up"] = c[c > 0].sum()
        out[f"{cat}_dn"] = c[c < 0].sum()
    # Pay-as-bid cost = |energy| × price, joined on (unit, datetime, category).
    piv = f.pivot_table(index=["unit", "datetime", "category"], columns="measure",
                        values="value", aggfunc="first")
    if "price_eur_mwh" in piv.columns and "energy_mwh" in piv.columns:
        piv["cost"] = piv["energy_mwh"].abs() * piv["price_eur_mwh"]
        out["cost"] = float(piv["cost"].sum(skipna=True))
    else:
        out["cost"] = float("nan")
    return out


def _stat(value, label):
    return dbc.Card(dbc.CardBody([
        html.Div(value, style={"fontSize": "1.3rem", "fontWeight": 700, "color": _TEXT}),
        html.Div(label, style={"color": _MUTED, "fontSize": "0.8rem"}),
    ]), className="mb-3")


def build_kpis(date):
    k = _kpis(date)
    if not k:
        return html.Div()
    gwh = lambda v: f"{v / 1000:,.1f} GWh"
    cost = "—" if np.isnan(k["cost"]) else f"€{k['cost'] / 1e6:,.2f} m"
    return dbc.Row([
        dbc.Col(_stat(gwh(k["RT_MD_up"]), "RT day-ahead ↑"), md=2),
        dbc.Col(_stat(gwh(k["RT_MD_dn"]), "RT day-ahead ↓"), md=2),
        dbc.Col(_stat(gwh(k["RTR_up"]), "RT real-time ↑"), md=2),
        dbc.Col(_stat(gwh(k["RTR_dn"]), "RT real-time ↓"), md=2),
        dbc.Col(_stat(cost, "Redispatch cost (pay-as-bid)"), md=4),
    ], className="g-3")


def layout():
    return dbc.Container([
        html.H4("Redispatch · technical restrictions", className="mt-3", style={"color": _TEXT}),
        html.P("Day-ahead (RT) and real-time (RTR) restriction volumes & cost across the system. "
               "Signed energy: + constrained up, − down.", style={"color": _MUTED}),
        dbc.Card(dbc.CardBody(dbc.Row([
            dbc.Col([html.Label("Delivery date", className="form-label"), html.Br(),
                     dcc.DatePickerSingle(id="rd-date", date="2025-01-15", display_format="YYYY-MM-DD")], md=4),
        ])), className="mb-3"),
        html.Div(id="rd-kpis", className="mb-2"),
        dbc.Card(dbc.CardBody(dcc.Graph(id="rd-profile", config={"displayModeBar": False},
                                        style={"height": "360px"})), className="mb-3"),
        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody(dcc.Graph(id="rd-top", config={"displayModeBar": False},
                                                    style={"height": "460px"}))), lg=6),
            dbc.Col(dbc.Card(dbc.CardBody(dcc.Graph(id="rd-tech", config={"displayModeBar": False},
                                                    style={"height": "460px"}))), lg=6),
        ], className="g-0"),
    ], fluid=True)


def register_callbacks(app):
    @app.callback(
        Output("rd-kpis", "children"), Output("rd-profile", "figure"),
        Output("rd-top", "figure"), Output("rd-tech", "figure"),
        Input("rd-date", "date"),
    )
    def _update(date):
        return build_kpis(date), build_volume_profile(date), build_top_units(date), build_by_tech(date)
