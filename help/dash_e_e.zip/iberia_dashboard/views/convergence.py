"""Convergence & mark-up — how a unit's programme and prices evolve by session.

Programme convergence: the unit's energy across PBF → intraday (PHF1–3) → final
P48, showing post-day-ahead repositioning. Price convergence: the system session
marginals (MD → S1 → S2 → S3) for context.

(Per-unit offer-vs-clearing mark-up needs the OMIE intraday curves keyed by UOF;
that lands once the UOF↔UP unit reference is scraped — see the build notes.)
"""
import sys
import pathlib

import numpy as np
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output, State
from dash.exceptions import PreventUpdate

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import styled_layout  # noqa: E402

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from utils.iberia_data import (  # noqa: E402
    get_unit_facts, get_session_prices, list_units, unit_options,
    month_window, day_window, to_madrid, cat_label, available_unit_dates,
    SESSION_KEYS, SESSION_LABELS,
)

_MUTED = "#9aa0a6"
_TEXT = "#e0e0e0"
_SESSION_LINE = {"PBF": "#868e96", "PVP": "#adb5bd", "PHF1": "#d0bfff",
                 "PHF2": "#9775fa", "PHF3": "#7048e8", "P48": "#4dabf7"}
_PRICE_LINE = {"price_day_ahead": "#868e96", "price_intraday_1": "#d0bfff",
               "price_intraday_2": "#9775fa", "price_intraday_3": "#4dabf7"}


def _empty_fig(msg, height=380):
    fig = go.Figure()
    fig.update_layout(**styled_layout(""))
    fig.add_annotation(text=msg, showarrow=False, font=dict(color=_MUTED, size=13),
                       xref="paper", yref="paper", x=0.5, y=0.5)
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(height=height)
    return fig


def build_programme_convergence(unit, date) -> go.Figure:
    if not unit or not date:
        return _empty_fig("Select a unit and a date")
    ds, de = day_window(date)
    cats = ("PBF", "PVP", "PHF1", "PHF2", "PHF3", "P48")
    f = get_unit_facts(ds, de, unit=unit, categories=cats, measure="energy_mwh")
    if f is None or f.empty:
        return _empty_fig(f"No programme data for {unit} on {date}")
    f = f.assign(dt=to_madrid(f["datetime"]))
    fig = go.Figure()
    for cat in cats:
        sub = f[f["category"] == cat]
        if sub.empty:
            continue
        g = sub.groupby("dt")["value"].sum().sort_index()
        fig.add_scatter(x=list(g.index), y=list(g.values), name=cat_label(cat), mode="lines",
                        line=dict(color=_SESSION_LINE.get(cat, "#868e96"), shape="hv", width=2))
    fig.update_layout(**styled_layout(f"Programme convergence across sessions · {unit}", "MWh"))
    fig.update_layout(height=400)
    return fig


def build_intraday_adjustment(unit, date) -> go.Figure:
    if not unit or not date:
        return _empty_fig("Select a unit and a date")
    ds, de = day_window(date)
    f = get_unit_facts(ds, de, unit=unit, categories=("PBF", "P48"), measure="energy_mwh")
    if f is None or f.empty:
        return _empty_fig(f"No programme data for {unit} on {date}")
    f = f.assign(hour=to_madrid(f["datetime"]).floor("h"))
    p48 = f[f["category"] == "P48"].groupby("hour")["value"].mean()
    pbf = f[f["category"] == "PBF"].groupby("hour")["value"].mean()
    adj = (p48 - pbf).dropna().sort_index()
    if adj.empty:
        return _empty_fig(f"PBF and P48 not both present for {unit} on {date}")
    colors = ["#ffa94d" if v >= 0 else "#4dabf7" for v in adj.values]
    fig = go.Figure(go.Bar(x=list(adj.index), y=list(adj.values), marker_color=colors,
                           name="P48 − PBF"))
    fig.update_layout(**styled_layout(f"Net post-day-ahead adjustment (P48 − PBF) · {unit}", "MWh"))
    fig.update_layout(height=320)
    return fig


def build_price_convergence(date) -> go.Figure:
    if not date:
        return _empty_fig("Select a date")
    ds, de = day_window(date)
    px = get_session_prices(ds, de, "ES")
    if px is None or px.empty:
        return _empty_fig("Session prices not loaded for this date")
    dt = to_madrid(px.index)
    fig = go.Figure()
    for key in SESSION_KEYS:
        if key in px.columns and px[key].notna().any():
            fig.add_scatter(x=list(dt), y=list(px[key].to_numpy()), mode="lines",
                            name=SESSION_LABELS[key], line=dict(color=_PRICE_LINE.get(key), width=2))
    fig.update_layout(**styled_layout(f"Session price convergence · ES · {date}", "€/MWh"))
    fig.update_layout(height=320)
    return fig


def layout():
    dates = available_unit_dates()
    default_date = dates[-1] if dates else "2025-01-15"
    opts = unit_options(list_units(*month_window(default_date))) if dates else []
    default_unit = opts[0]["value"] if opts else None
    return dbc.Container([
        html.H4("Convergence & mark-up", className="mt-3", style={"color": _TEXT}),
        html.P("How a unit's programme moves from the day-ahead base through the intraday "
               "sessions to the final P48, against the session price path.", style={"color": _MUTED}),
        dbc.Card(dbc.CardBody(dbc.Row([
            dbc.Col([html.Label("Unit", className="form-label"),
                     dcc.Dropdown(id="cv-unit", options=opts, value=default_unit, clearable=False)], md=4),
            dbc.Col([html.Label("Delivery date", className="form-label"), html.Br(),
                     dcc.DatePickerSingle(id="cv-date", date=default_date,
                                          min_date_allowed=dates[0] if dates else None,
                                          max_date_allowed=dates[-1] if dates else None,
                                          display_format="YYYY-MM-DD")], md=3),
        ], className="g-3 align-items-end")), className="mb-3"),
        dbc.Card(dbc.CardBody(dcc.Graph(id="cv-programme", config={"displayModeBar": False},
                                        style={"height": "400px"})), className="mb-3"),
        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody(dcc.Graph(id="cv-adjust", config={"displayModeBar": False},
                                                    style={"height": "320px"}))), lg=6),
            dbc.Col(dbc.Card(dbc.CardBody(dcc.Graph(id="cv-price", config={"displayModeBar": False},
                                                    style={"height": "320px"}))), lg=6),
        ], className="g-0"),
    ], fluid=True)


def register_callbacks(app):
    @app.callback(
        Output("cv-unit", "options"), Output("cv-unit", "value"),
        Input("cv-date", "date"), State("cv-unit", "value"),
    )
    def _units(date, current):
        if not date:
            raise PreventUpdate
        units = list_units(*month_window(date))
        opts = unit_options(units)
        value = current if current in units else (opts[0]["value"] if opts else None)
        return opts, value

    @app.callback(
        Output("cv-programme", "figure"), Output("cv-adjust", "figure"), Output("cv-price", "figure"),
        Input("cv-unit", "value"), Input("cv-date", "date"),
    )
    def _update(unit, date):
        return (build_programme_convergence(unit, date),
                build_intraday_adjustment(unit, date),
                build_price_convergence(date))
