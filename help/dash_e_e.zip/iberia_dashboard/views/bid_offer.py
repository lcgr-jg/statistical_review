"""Bid-offer & Merit order — OMIE aggregate supply/demand cross for one hour.

Plots the day-ahead offer stack: the supply curve (sell offers, ascending price)
against the demand curve (buy bids, descending price); their crossing is the
market clearing, marked against the day-ahead price. Sourced from the OMIE
curve order book (OMIECurves).
"""
import sys
import pathlib

import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import styled_layout  # noqa: E402

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from utils.iberia_data import (  # noqa: E402
    get_supply_demand, get_session_prices, day_window, to_madrid,
)

_MUTED = "#9aa0a6"
_TEXT = "#e0e0e0"


def _empty_fig(msg: str, height: int = 520) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(**styled_layout(""))
    fig.add_annotation(text=msg, showarrow=False, font=dict(color=_MUTED, size=13),
                       xref="paper", yref="paper", x=0.5, y=0.5)
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(height=height)
    return fig


def build_cross(date, hour) -> go.Figure:
    """Supply/demand cross for one Madrid delivery hour, with the MD clearing line."""
    if not date:
        return _empty_fig("Select a date and hour")
    hour = int(hour) if hour is not None else 12
    sd = get_supply_demand(date, hour, "day_ahead")
    sell, buy = sd.get("sell"), sd.get("buy")
    has_sell = sell is not None and not sell.empty
    has_buy = buy is not None and not buy.empty
    if not has_sell and not has_buy:
        return _empty_fig(f"No curve data for {date} {hour:02d}:00 — "
                          "OMIE day-ahead curves cover 2021 → present")

    fig = go.Figure()
    if has_sell:
        fig.add_scatter(x=sell["cum_mwh"], y=sell["price_eur_mwh"], name="Supply · sell offers",
                        mode="lines", line=dict(color="#51cf66", width=2, shape="hv"))
    if has_buy:
        fig.add_scatter(x=buy["cum_mwh"], y=buy["price_eur_mwh"], name="Demand · buy bids",
                        mode="lines", line=dict(color="#4dabf7", width=2, shape="hv"))

    # Day-ahead clearing reference for the hour (ES).
    ds, de = day_window(date)
    px = get_session_prices(ds, de, "ES")
    if px is not None and not px.empty and "price_day_ahead" in px.columns:
        tod = to_madrid(px.index)
        match = px[tod.hour == hour]
        if len(match):
            p = float(match["price_day_ahead"].dropna().iloc[0])
            fig.add_hline(y=p, line=dict(color=_MUTED, dash="dash"),
                          annotation_text=f"MD clearing ≈ {p:.1f} €/MWh",
                          annotation_position="top left",
                          annotation_font=dict(color=_MUTED))

    fig.update_layout(**styled_layout(f"Supply / demand · day-ahead · {date} {hour:02d}:00 (Madrid)", "€/MWh"))
    fig.update_layout(height=520)
    fig.update_xaxes(title="Cumulative offered energy (MWh)")
    return fig


def layout():
    hours = [{"label": f"{h:02d}:00", "value": h} for h in range(24)]
    controls = dbc.Card(dbc.CardBody(dbc.Row([
        dbc.Col([html.Label("Delivery date", className="form-label"), html.Br(),
                 dcc.DatePickerSingle(id="bo-date", date="2025-01-15", display_format="YYYY-MM-DD")], md=4),
        dbc.Col([html.Label("Hour (Madrid)", className="form-label"),
                 dcc.Dropdown(id="bo-hour", options=hours, value=20, clearable=False)], md=3),
    ], className="g-3 align-items-end")), className="mb-3")

    return dbc.Container([
        html.H4("Bid-offer & Merit order", className="mt-3", style={"color": _TEXT}),
        html.P("OMIE day-ahead supply/demand curves for a single delivery hour — the offer "
               "stack and where the market clears.", style={"color": _MUTED}),
        controls,
        dbc.Card(dbc.CardBody([
            html.H6("Supply / demand cross", className="card-title",
                    style={"color": _TEXT, "marginBottom": "8px"}),
            dcc.Graph(id="bo-cross", config={"displayModeBar": False}, style={"height": "520px"}),
        ])),
    ], fluid=True)


def register_callbacks(app):
    @app.callback(Output("bo-cross", "figure"), Input("bo-date", "date"), Input("bo-hour", "value"))
    def _cross(date, hour):
        return build_cross(date, hour)
