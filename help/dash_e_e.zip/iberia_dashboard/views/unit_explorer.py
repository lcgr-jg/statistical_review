"""Unit Explorer — per-unit program & price decomposition.

Signature view: the month heatmap (days × quarter-hour) of a unit's programme,
with an MWh ↔ €/MWh toggle. Plus signed volume-by-category and price-by-category
panels. All sourced from the I90 gold fact table via the iberia adapter.

Panel 2 (intraday OHLC-across-sessions) is wired as a placeholder pending the
next build phase.
"""
import sys
import pathlib

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash import html, dcc, Input, Output, State
from dash.exceptions import PreventUpdate

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import styled_layout  # noqa: E402

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from utils.iberia_data import (  # noqa: E402
    get_unit_facts, get_unit_prices, get_day_ahead_price, get_session_prices,
    list_units, available_unit_dates, unit_options,
    month_window, day_window, to_madrid, cat_label,
    PRICE_CATEGORIES, SESSION_KEYS, SESSION_LABELS,
)

# Dark-theme category palette (programs cool, redispatch warm, reserves distinct).
CATEGORY_COLORS = {
    "PBF": "#4dabf7", "P48": "#74c0fc", "PVP": "#3b8fd6",
    "PHF1": "#9775fa", "PHF2": "#b197fc", "PHF3": "#d0bfff", "PHFC": "#845ef7",
    "BILATERAL": "#868e96",
    "RT_MD": "#ffa94d", "RTR": "#ff6b6b",
    "TERTIARY": "#cc5de8", "RR": "#20c997",
    "SECONDARY": "#51cf66", "SECONDARY_E": "#69db7c",
}
# Stacking order for the volume panel (programs first, then adjustments).
_VOLUME_ORDER = ["P48", "PBF", "PVP", "PHF1", "PHF2", "PHF3", "PHFC",
                 "RT_MD", "RTR", "TERTIARY", "RR", "SECONDARY", "SECONDARY_E", "BILATERAL"]
_MUTED = "#9aa0a6"


def _empty_fig(msg: str, height: int = 380) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(**styled_layout(""))
    fig.add_annotation(text=msg, showarrow=False, font=dict(color=_MUTED, size=13),
                       xref="paper", yref="paper", x=0.5, y=0.5)
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(height=height)
    return fig


def _es_day_ahead(px):
    """Pick the ES day-ahead price Series from IberiaPower.prices() wide output."""
    if px is None or getattr(px, "empty", True):
        return None
    if isinstance(px.columns, pd.MultiIndex):
        cols = [c for c in px.columns if c[0] == "ES"]
        return px[cols[0]] if cols else None
    return px.iloc[:, 0]


# ---------------------------------------------------------------------------
# Figure builders (pure — unit/date in, go.Figure out)
# ---------------------------------------------------------------------------

def build_heatmap(unit, date, measure, program) -> go.Figure:
    """Month heatmap: days × quarter-hour, coloured by MWh or by €/MWh."""
    if not unit or not date:
        return _empty_fig("Select a unit and a date", height=460)
    ms, me = month_window(date)

    if measure == "price":
        s = _es_day_ahead(get_day_ahead_price(ms, me, ("ES",)))
        if s is None or s.empty:
            return _empty_fig("No day-ahead price for this month", height=460)
        dt = to_madrid(s.index)
        frame = pd.DataFrame({"day": dt.strftime("%Y-%m-%d"),
                              "tod": dt.strftime("%H:%M"),
                              "v": s.values})
        title = f"Day-ahead price · ES · {ms[:7]} (€/MWh)"
        colorscale, unit_lbl = "Inferno", "€/MWh"
    else:
        facts = get_unit_facts(ms, me, unit=unit, categories=(program,), measure="energy_mwh")
        if facts is None or facts.empty:
            return _empty_fig(f"No {program} data for {unit} in {ms[:7]} — I90 backfill in progress",
                              height=460)
        dt = to_madrid(facts["datetime"])
        frame = pd.DataFrame({"day": dt.strftime("%Y-%m-%d"),
                              "tod": dt.strftime("%H:%M"),
                              "v": facts["value"].to_numpy()})
        title = f"{program} programme · {unit} · {ms[:7]} (MWh)"
        colorscale, unit_lbl = "Viridis", "MWh"

    mat = frame.pivot_table(index="day", columns="tod", values="v", aggfunc="sum").sort_index()
    fig = go.Figure(go.Heatmap(
        z=mat.values, x=list(mat.columns), y=list(mat.index),
        colorscale=colorscale, colorbar=dict(title=unit_lbl),
        hovertemplate="%{y} %{x}<br>%{z:.1f} " + unit_lbl + "<extra></extra>",
    ))
    fig.update_layout(**styled_layout(title))
    fig.update_layout(height=460, margin=dict(l=90, r=20, t=50, b=40))
    fig.update_xaxes(title="Quarter-hour (Madrid)", showgrid=False, nticks=24)
    fig.update_yaxes(title="", showgrid=False, autorange="reversed")
    return fig


def build_volume(unit, date) -> go.Figure:
    """Signed stacked volume by market category for one delivery day."""
    if not unit or not date:
        return _empty_fig("Select a unit and a date")
    ds, de = day_window(date)
    facts = get_unit_facts(ds, de, unit=unit, measure="energy_mwh")
    if facts is None or facts.empty:
        return _empty_fig(f"No programme data for {unit} on {date}")
    facts = facts.assign(tod=to_madrid(facts["datetime"]).strftime("%H:%M"))
    fig = go.Figure()
    present = [c for c in _VOLUME_ORDER if c in set(facts["category"])]
    for cat in present:
        g = facts[facts["category"] == cat].groupby("tod")["value"].sum().sort_index()
        fig.add_bar(x=list(g.index), y=list(g.values), name=cat_label(cat),
                    marker_color=CATEGORY_COLORS.get(cat, "#868e96"))
    fig.update_layout(barmode="relative", **styled_layout(f"Programme volume by category · {unit} · {date}", "MWh"))
    fig.update_layout(height=380)
    fig.update_xaxes(nticks=24)
    return fig


def build_price(unit, date) -> go.Figure:
    """Per-unit adjustment prices vs the system day-ahead ('med')."""
    if not unit or not date:
        return _empty_fig("Select a unit and a date")
    ds, de = day_window(date)
    pr = get_unit_prices(unit, ds, de)
    fig = go.Figure()
    traces = 0
    if pr is not None and not pr.empty:
        idx = to_madrid(pr.index).strftime("%H:%M")
        for cat in PRICE_CATEGORIES:
            if cat in pr.columns and pr[cat].notna().any():
                fig.add_scatter(x=list(idx), y=list(pr[cat].to_numpy()), mode="lines",
                                name=f"{cat_label(cat)} (unit)",
                                line=dict(color=CATEGORY_COLORS.get(cat, "#868e96"), width=2))
                traces += 1
    s = _es_day_ahead(get_day_ahead_price(ds, de, ("ES",)))
    if s is not None and not s.empty:
        idx = to_madrid(s.index).strftime("%H:%M")
        fig.add_scatter(x=list(idx), y=list(s.to_numpy()), mode="lines", name="Day-ahead · system (med)",
                        line=dict(color=_MUTED, width=1.5, dash="dash"))
        traces += 1
    if traces == 0:
        return _empty_fig(f"No adjustment prices for {unit} on {date}")
    fig.update_layout(**styled_layout(f"Unit price by adjustment category · {unit}", "€/MWh"))
    fig.update_layout(height=380)
    fig.update_xaxes(nticks=24)
    return fig


def build_ohlc(unit, date) -> go.Figure:
    """Intraday OHLC built across sessions (MD → S1 → S2 → S3), per quarter-hour.

    Open = MD, Close = last available session, High/Low = range across sessions.
    A green candle means the QH repriced *above* the day-ahead by the last
    intraday auction; red means it was marked down. Hourly intraday prices are
    forward-filled onto the finer MD grid so every QH carries its session ladder.
    """
    if not date:
        return _empty_fig("Select a date")
    ds, de = day_window(date)
    px = get_session_prices(ds, de, "ES")
    if px is None or px.empty or "price_day_ahead" not in px.columns:
        return _empty_fig("Intraday session prices not loaded for this date")

    cols = [c for c in SESSION_KEYS if c in px.columns]
    aligned = px[cols].copy().sort_index()
    for c in cols:                      # hourly intraday → fill its 3 trailing QHs
        if c != "price_day_ahead":
            aligned[c] = aligned[c].ffill(limit=3)

    arr = aligned.to_numpy(dtype="float64")
    md = aligned["price_day_ahead"].to_numpy(dtype="float64")
    high = np.nanmax(arr, axis=1)
    low = np.nanmin(arr, axis=1)
    close = np.array([row[~np.isnan(row)][-1] if np.any(~np.isnan(row)) else np.nan
                      for row in arr])
    x = to_madrid(aligned.index).strftime("%H:%M")
    ladder = [" → ".join(f"{SESSION_LABELS[c]} {row[i]:.1f}"
                         for i, c in enumerate(cols) if not np.isnan(row[i]))
              for row in arr]

    fig = go.Figure(go.Candlestick(
        x=list(x), open=list(md), high=list(high), low=list(low), close=list(close),
        increasing_line_color="#51cf66", decreasing_line_color="#ff6b6b",
        name="MD → S1 → S2 → S3", text=ladder,
    ))
    fig.update_layout(**styled_layout(f"Intraday price across sessions · ES · {date}", "€/MWh"))
    fig.update_layout(height=380, xaxis_rangeslider_visible=False)
    fig.update_xaxes(nticks=24)
    return fig


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

def _card(title, graph_id, height=460):
    return dbc.Card(dbc.CardBody([
        html.H6(title, className="card-title", style={"color": "#e0e0e0", "marginBottom": "8px"}),
        dcc.Graph(id=graph_id, config={"displayModeBar": False}, style={"height": f"{height}px"}),
    ]), className="mb-3")


def layout():
    dates = available_unit_dates()
    default_date = dates[-1] if dates else "2025-01-15"
    units = list_units(*month_window(default_date)) if dates else []
    opts = unit_options(units)
    default_unit = opts[0]["value"] if opts else None

    controls = dbc.Card(dbc.CardBody(dbc.Row([
        dbc.Col([html.Label("Unit", className="form-label"),
                 dcc.Dropdown(id="ue-unit", options=opts, value=default_unit, clearable=False)], md=4),
        dbc.Col([html.Label("Delivery date", className="form-label"), html.Br(),
                 dcc.DatePickerSingle(id="ue-date", date=default_date,
                                      min_date_allowed=dates[0] if dates else None,
                                      max_date_allowed=dates[-1] if dates else None,
                                      display_format="YYYY-MM-DD")], md=3),
        dbc.Col([html.Label("Heatmap colour", className="form-label"),
                 dbc.RadioItems(id="ue-measure", value="mwh", inline=True,
                                options=[{"label": "MWh", "value": "mwh"},
                                         {"label": "€/MWh", "value": "price"}])], md=3),
        dbc.Col([html.Label("Programme", className="form-label"),
                 dbc.RadioItems(id="ue-program", value="P48", inline=True,
                                options=[{"label": "P48", "value": "P48"},
                                         {"label": "PBF", "value": "PBF"}])], md=2),
    ], className="g-3 align-items-end")), className="mb-3")

    return dbc.Container([
        html.H4("Unit Explorer", className="mt-3", style={"color": "#e0e0e0"}),
        html.P("Per-unit programme and price decomposition across the market sequence "
               "(MD → intraday → P48 → restrictions). Data: REE I90 settlement (historical).",
               style={"color": _MUTED}),
        controls,
        _card("Programme month heatmap", "ue-heatmap", height=460),
        dbc.Row([
            dbc.Col(_card("Intraday OHLC across sessions", "ue-ohlc", height=380), lg=6),
            dbc.Col(_card("Programme volume by category", "ue-volume", height=380), lg=6),
        ], className="g-0"),
        _card("Unit price by adjustment category", "ue-price", height=380),
    ], fluid=True)


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def register_callbacks(app):
    @app.callback(
        Output("ue-unit", "options"), Output("ue-unit", "value"),
        Input("ue-date", "date"), State("ue-unit", "value"),
    )
    def _units_for_date(date, current):
        if not date:
            raise PreventUpdate
        units = list_units(*month_window(date))
        opts = unit_options(units)
        value = current if current in units else (opts[0]["value"] if opts else None)
        return opts, value

    @app.callback(
        Output("ue-heatmap", "figure"),
        Input("ue-unit", "value"), Input("ue-date", "date"),
        Input("ue-measure", "value"), Input("ue-program", "value"),
    )
    def _heatmap(unit, date, measure, program):
        return build_heatmap(unit, date, measure, program)

    @app.callback(
        Output("ue-volume", "figure"), Output("ue-price", "figure"), Output("ue-ohlc", "figure"),
        Input("ue-unit", "value"), Input("ue-date", "date"),
    )
    def _panels(unit, date):
        return build_volume(unit, date), build_price(unit, date), build_ohlc(unit, date)
