"""Overview — landing page: data coverage + a guide to the sections."""
import sys
import pathlib

import dash_bootstrap_components as dbc
from dash import html

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from utils.iberia_data import available_unit_dates  # noqa: E402

_MUTED = "#9aa0a6"
_TEXT = "#e0e0e0"

_SECTIONS = [
    ("Unit Explorer", "/unit",
     "Per-unit programme & price decomposition — month heatmap, volume and price by market category."),
    ("Bid-offer & Merit order", "/curves",
     "OMIE aggregate supply/demand cross at a chosen hour, the marginal unit, and where a unit sits in the stack."),
    ("Redispatch (RT/RTR)", "/redispatch",
     "Technical-restriction volumes & costs — constrained up/down by unit, technology and zone."),
    ("Convergence & mark-up", "/convergence",
     "Day-ahead → intraday → final programme evolution, and offer-vs-clearing mark-up per unit."),
]


def _stat_card(value, label, sub=""):
    return dbc.Card(dbc.CardBody([
        html.Div(value, style={"fontSize": "1.6rem", "fontWeight": 700, "color": _TEXT}),
        html.Div(label, style={"color": _MUTED, "fontSize": "0.85rem"}),
        html.Div(sub, style={"color": _MUTED, "fontSize": "0.75rem"}) if sub else None,
    ]), className="mb-3")


def layout():
    dates = available_unit_dates()
    n = len(dates)
    span = f"{dates[0]} → {dates[-1]}" if dates else "no data yet"

    coverage = dbc.Row([
        dbc.Col(_stat_card(f"{n}", "I90 delivery dates", span), md=4),
        dbc.Col(_stat_card("ES · PT", "Markets", "MIBEL day-ahead + intraday"), md=4),
        dbc.Col(_stat_card("REE I90", "Per-unit source", "settlement · historical"), md=4),
    ], className="g-3")

    guide = dbc.Row([
        dbc.Col(dbc.Card(dbc.CardBody([
            html.A(html.H6(name, style={"color": _TEXT, "marginBottom": "4px"}), href=href),
            html.P(desc, style={"color": _MUTED, "fontSize": "0.85rem", "marginBottom": 0}),
        ]), className="mb-3 h-100"), md=6)
        for name, href, desc in _SECTIONS
    ], className="g-3")

    return dbc.Container([
        html.H4("Iberian power · OMIE / ESIOS", className="mt-3", style={"color": _TEXT}),
        html.P("Unit bidding behaviour, operating schedules and redispatch across the Iberian "
               "market sequence. Per-unit data is REE I90 settlement (historical); prices and "
               "bid-offer curves are OMIE/ESIOS.", style={"color": _MUTED}),
        coverage,
        html.H6("Sections", className="mt-4", style={"color": _TEXT}),
        guide,
    ], fluid=True)
