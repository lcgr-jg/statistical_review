"""Shared placeholder layout for sections landing in later build phases."""
import dash_bootstrap_components as dbc
from dash import html

_MUTED = "#9aa0a6"


def placeholder_layout(title: str, subtitle: str, bullets=None):
    items = [html.Li(b, style={"color": _MUTED}) for b in (bullets or [])]
    return dbc.Container([
        html.H4(title, className="mt-3", style={"color": "#e0e0e0"}),
        html.P(subtitle, style={"color": _MUTED}),
        dbc.Card(dbc.CardBody([
            html.P("Planned for this section:", style={"color": "#e0e0e0", "fontWeight": 600}),
            html.Ul(items) if items else html.Span("Coming soon.", style={"color": _MUTED}),
        ])),
    ], fluid=True)
