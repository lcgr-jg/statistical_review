import sys
import pathlib

import dash_bootstrap_components as dbc

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from common import url_for  # noqa: E402


def create_navbar():
    return dbc.Navbar(
        dbc.Container([
            dbc.NavbarBrand("Iberia · OMIE", href="/", className="me-auto"),
            dbc.Nav([
                dbc.NavItem(dbc.NavLink("Overview", href="/")),
                dbc.NavItem(dbc.NavLink("Unit Explorer", href="/unit")),
                dbc.NavItem(dbc.NavLink("Bid-offer & Merit", href="/curves")),
                dbc.NavItem(dbc.NavLink("Redispatch", href="/redispatch")),
                dbc.NavItem(dbc.NavLink("Convergence", href="/convergence")),
                dbc.NavItem(dbc.NavLink("Stack", href=url_for('stack'), external_link=True)),
                dbc.NavItem(dbc.NavLink("Fundamentals", href=url_for('fundamental'), external_link=True)),
                dbc.NavItem(dbc.NavLink("Price", href=url_for('price'), external_link=True)),
                dbc.NavItem(dbc.NavLink("Portal", href=url_for('portal'), external_link=True)),
            ], navbar=True),
        ], fluid=True),
        className="dashboard-navbar",
        dark=True,
    )
