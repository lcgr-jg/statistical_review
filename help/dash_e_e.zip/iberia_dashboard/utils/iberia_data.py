"""Cached data service for the Iberia / OMIE dashboard.

Thin ``@cached`` wrappers over the jain_commods ``iberia`` adapters
(``IberiaUnits`` / ``OMIECurves`` / ``IberiaPower``), mirroring the per-app data
layer in the stack/price dashboards. Adapters are imported lazily so module
import stays cheap.

Cache note: ``@cached`` keys on the call args, so only hashable args are passed
(str / tuple — never list).

Units are identified by REE programming-unit code (e.g. ``ECT3``). The
technology/label classifier here is a **v1 heuristic** pending the authoritative
unit-reference scrape (UP/UOF → name, fuel, zone).
"""
from __future__ import annotations

import logging
import re

import pandas as pd

from .cache import cached

logger = logging.getLogger(__name__)

MADRID = "Europe/Madrid"


# ---------------------------------------------------------------------------
# Lazy adapter handles
# ---------------------------------------------------------------------------

def _units():
    from jain_commods.core.cache.data.iberia import IberiaUnits
    return IberiaUnits()


def _power():
    from jain_commods.core.cache.data.iberia import IberiaPower
    return IberiaPower()


def _curves():
    from jain_commods.core.cache.data.iberia import OMIECurves
    return OMIECurves()


# ---------------------------------------------------------------------------
# Category metadata (labels + grouping for the unit decomposition)
# ---------------------------------------------------------------------------

CATEGORY_LABELS = {
    "PBF": "PBF · base program",
    "P48": "P48 · final program",
    "PVP": "PVP · viability",
    "PHF1": "Intraday S1",
    "PHF2": "Intraday S2",
    "PHF3": "Intraday S3",
    "PHFC": "Intraday · continuous",
    "BILATERAL": "Bilateral",
    "RT_MD": "Restrictions · day-ahead",
    "RTR": "Restrictions · real-time",
    "TERTIARY": "Tertiary (mFRR)",
    "RR": "Replacement reserve",
    "SECONDARY": "Secondary band",
    "SECONDARY_E": "Secondary energy",
}
PROGRAM_CATEGORIES = ["PBF", "P48", "PVP", "PHF1", "PHF2", "PHF3", "PHFC", "BILATERAL"]
ADJUSTMENT_CATEGORIES = ["RT_MD", "RTR", "TERTIARY", "RR", "SECONDARY", "SECONDARY_E"]
PRICE_CATEGORIES = ["RT_MD", "RTR", "TERTIARY", "RR"]


def cat_label(cat: str) -> str:
    return CATEGORY_LABELS.get(cat, cat)


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------

def to_madrid(idx):
    """Convert a tz-aware (UTC) DatetimeIndex/Series to Europe/Madrid wall-clock."""
    s = pd.DatetimeIndex(idx)
    if s.tz is None:
        s = s.tz_localize("UTC")
    return s.tz_convert(MADRID)


def month_window(date_str: str):
    """(month_start, next_month_start) date strings for the month containing date_str."""
    d = pd.Timestamp(date_str)
    start = d.replace(day=1).normalize()
    end = start + pd.offsets.MonthBegin(1)
    return start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")


def day_window(date_str: str):
    """(day_start, next_day) date strings for a single delivery date."""
    d = pd.Timestamp(date_str).normalize()
    return d.strftime("%Y-%m-%d"), (d + pd.Timedelta(days=1)).strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Cached accessors (hashable args only)
# ---------------------------------------------------------------------------

@cached
def get_unit_program(unit: str, start: str, end: str) -> pd.DataFrame:
    """Wide energy-by-category for one unit (UTC datetime index × category)."""
    return _units().get_unit_program(unit, start, end)


@cached
def get_unit_prices(unit: str, start: str, end: str) -> pd.DataFrame:
    """Wide price-by-category for one unit (UTC datetime index × category)."""
    return _units().get_unit_prices(unit, start, end)


@cached
def get_unit_facts(start: str, end: str, unit: str = None,
                   categories: tuple = None, measure: str = None) -> pd.DataFrame:
    """Long-form unit facts (see iberia.read_unit_facts)."""
    cats = list(categories) if categories else None
    return _units().read(start, end, units=unit, categories=cats, measure=measure)


@cached
def list_units(start: str, end: str) -> list:
    """Programming units present in [start, end)."""
    return _units().list_units(start, end)


@cached
def get_day_ahead_price(start: str, end: str, geos: tuple = ("ES",)) -> pd.DataFrame:
    """System day-ahead spot price (wide geo × series) for the price overlay."""
    return _power().prices(geos=list(geos), start=start, end=end)


# Session price keys (MD + the three intraday auctions) in catalogue order.
SESSION_KEYS = ["price_day_ahead", "price_intraday_1", "price_intraday_2", "price_intraday_3"]
SESSION_LABELS = {"price_day_ahead": "MD", "price_intraday_1": "S1",
                  "price_intraday_2": "S2", "price_intraday_3": "S3"}


@cached
def get_session_prices(start: str, end: str, geo: str = "ES") -> pd.DataFrame:
    """MD + intraday S1–S3 marginal prices for one geo (wide datetime × session key)."""
    px = _power().get(SESSION_KEYS, geos=[geo], start=start, end=end)
    if px is None or px.empty:
        return pd.DataFrame()
    # Collapse the (geo, series) column MultiIndex to bare session keys.
    if hasattr(px.columns, "nlevels") and px.columns.nlevels > 1:
        px = px.xs(geo, axis=1, level="geo")
    return px


@cached
def get_supply_demand(date: str, hour: int, market: str = "day_ahead") -> dict:
    """OMIE supply/demand offer curves for one Madrid delivery hour.

    Returns {'sell': supply_df, 'buy': demand_df} with a cumulative-MWh column.
    """
    midnight_utc = pd.Timestamp(date, tz=MADRID).tz_convert("UTC")
    ts = midnight_utc + pd.Timedelta(hours=int(hour))
    return _curves().supply_demand(market, ts)


@cached
def available_unit_dates() -> list:
    """Delivery dates present in the I90 gold dataset (from S3 keys)."""
    from jain_commods.core.cache.utils.s3 import S3, AWS_BUCKET_NAME
    s3 = S3().get_client()
    rx = re.compile(r"data_date=(\d{4}-\d{2}-\d{2})")
    dates = set()
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=AWS_BUCKET_NAME, Prefix="esios/i90/gold/"):
        for obj in page.get("Contents", []):
            m = rx.search(obj["Key"])
            if m:
                dates.add(m.group(1))
    return sorted(dates)


# ---------------------------------------------------------------------------
# Unit technology / label classifier — v1 HEURISTIC
# (replace with the authoritative UP/UOF reference map when scraped)
# ---------------------------------------------------------------------------

# Known Spanish nuclear sites by UP-code prefix.
_NUCLEAR_PREFIX = {
    "ALM": "Almaraz", "ASC": "Ascó", "COF": "Cofrentes",
    "TRI": "Trillo", "VAN": "Vandellós", "GAR": "Garoña",
}

TECH_ORDER = ["Nuclear", "CCGT", "Coal", "Hydro", "Pumped storage",
              "Wind", "Solar", "Cogeneration", "Other"]


def classify_unit(up: str) -> str:
    """Best-effort technology from a programming-unit code (v1 heuristic).

    Honest fallback: returns 'Other' when the code doesn't match a known
    pattern. Superseded by the authoritative unit-reference once available.
    """
    if not up or up == "SYSTEM":
        return "Other"
    u = str(up).upper()
    for pfx, _site in _NUCLEAR_PREFIX.items():
        if u.startswith(pfx):
            return "Nuclear"
    # Common REE code conventions (best-effort):
    if u.endswith("B") or "BOMBEO" in u:
        return "Pumped storage"
    if u.startswith(("EOL", "PARQ")) or u.endswith("EOL"):
        return "Wind"
    if u.startswith(("FV", "SOL", "SF")):
        return "Solar"
    if u.startswith(("CTG", "CT")) or u.endswith("CC"):
        return "CCGT"
    if u.startswith(("HID", "H")) or u.endswith("H"):
        return "Hydro"
    if u.startswith("COG"):
        return "Cogeneration"
    return "Other"


def unit_label(up: str) -> str:
    """Friendly-ish label: nuclear sites get their name; others show code + tech."""
    if not up:
        return up
    u = str(up).upper()
    for pfx, site in _NUCLEAR_PREFIX.items():
        if u.startswith(pfx):
            return f"{up} · {site} (Nuclear)"
    tech = classify_unit(up)
    return f"{up} · {tech}" if tech != "Other" else str(up)


def unit_options(units: list) -> list:
    """Dash dropdown options sorted by (technology, code) with tech-tagged labels."""
    opts = sorted(units, key=lambda u: (TECH_ORDER.index(classify_unit(u))
                                        if classify_unit(u) in TECH_ORDER else 99, u))
    return [{"label": unit_label(u), "value": u} for u in opts]
