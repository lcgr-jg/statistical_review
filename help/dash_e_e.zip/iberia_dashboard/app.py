import logging
import os
import sys
import pathlib

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s %(message)s')

_HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE.parent))   # repo root → resolves `common`
sys.path.insert(0, str(_HERE))          # this app's dir → `utils`/`pages` win over any root-level `pages`
from common import install_theme_css, register_health  # noqa: E402

import dash  # noqa: E402
from dash import html, dcc, Input, Output  # noqa: E402
import dash_bootstrap_components as dbc  # noqa: E402
from utils.navbar import create_navbar  # noqa: E402

app = dash.Dash(
    __name__,
    suppress_callback_exceptions=True,
    external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.FONT_AWESOME],
    title="Iberia / OMIE",
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)

install_theme_css(app)

app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    create_navbar(),
    html.Div(id='page-content', className='mt-2'),
])

# ── Page modules & callbacks ──────────────────────────────────────────────
from views.overview import layout as overview_layout  # noqa: E402
from views.unit_explorer import layout as unit_layout, register_callbacks as reg_unit  # noqa: E402
from views.bid_offer import layout as bid_offer_layout, register_callbacks as reg_bid_offer  # noqa: E402
from views.redispatch import layout as redispatch_layout, register_callbacks as reg_redispatch  # noqa: E402
from views.convergence import layout as convergence_layout, register_callbacks as reg_convergence  # noqa: E402

reg_unit(app)
reg_bid_offer(app)
reg_redispatch(app)
reg_convergence(app)

_ROUTES = {
    '/': overview_layout,
    '/unit': unit_layout,
    '/curves': bid_offer_layout,
    '/redispatch': redispatch_layout,
    '/convergence': convergence_layout,
}


@app.callback(Output('page-content', 'children'), Input('url', 'pathname'))
def route(pathname):
    p = (pathname or '/').rstrip('/').lower() or '/'
    factory = _ROUTES.get(p, overview_layout)
    return factory() if callable(factory) else factory


register_health(app, name='iberia', ready_flag=lambda: True)


if __name__ == '__main__':
    port = int(os.environ.get('DASH_PORT', '9106'))
    host = os.environ.get('DASH_HOST', '0.0.0.0')
    if os.environ.get('DASH_PRODUCTION', '').lower() in ('1', 'true', 'yes'):
        from waitress import serve
        logging.info('Serving via waitress on %s:%s (production)', host, port)
        serve(app.server, host=host, port=port, threads=int(os.environ.get('DASH_THREADS', '8')))
    else:
        app.run(debug=False, host=host, port=port, use_reloader=False)
