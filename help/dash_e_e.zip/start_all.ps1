# Simple PowerShell launcher for local development of the LEGACY
# three-dashboard setup (fundamental / price / stack on separate ports).
#
# Usage:
#   .\start_all.ps1                       # uses 'python' on PATH
#   .\start_all.ps1 -Python "<path>"      # force a specific interpreter
#   $env:DASH_PY="<path>"; .\start_all.ps1
#
# For production/server use common/supervisor.py or the *.sh launchers.
#
# Ports match jg_eu_commod_dashboard_power_config.yaml so that browsing
# http://localhost:9000 via the iframe wrapper works the same way on the
# server (http://10.115.0.70:9000).

param(
    [string]$Python = ""
)

$ErrorActionPreference = 'SilentlyContinue'

# Auto-resolve repo base = directory containing this script.
$base = Split-Path -Parent $MyInvocation.MyCommand.Path

# Python interpreter resolution:
#   1. -Python arg
#   2. $env:DASH_PY
#   3. devlop_venv under ~/Documents/Development (dev machine default –
#      base Anaconda doesn't have flask_login / blpapi / dash_pivottable)
#   4. 'python' on PATH
function Resolve-Python([string]$explicit) {
    if ($explicit -and (Test-Path $explicit)) { return $explicit }
    if ($env:DASH_PY -and (Test-Path $env:DASH_PY)) { return $env:DASH_PY }
    $devlop = Join-Path $env:USERPROFILE 'Documents\Development\devlop_venv\Scripts\python.exe'
    if (Test-Path $devlop) { return $devlop }
    return "python"
}

$python = Resolve-Python $Python
Write-Host "Using Python: $python"
Write-Host "Repo base:    $base"
Write-Host ""

function Start-Dashboard {
    param([string]$Name, [string]$Dir, [int]$Port)

    $procs = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
             Select-Object -ExpandProperty OwningProcess -Unique
    foreach ($p in $procs) { Stop-Process -Id $p -Force -ErrorAction SilentlyContinue }

    $logPath = Join-Path $Dir "$Name.log"
    $errPath = "$logPath.err"
    foreach ($f in $logPath, $errPath) {
        if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue }
    }

    # DASH_PORT is the single source of truth.  app.py reads it (falling back
    # to its historical default if unset).
    $env:DASH_PORT = "$Port"

    # Dash 3.x has a sharp edge: it reads the generic PORT/HOST env vars in
    # app.run() and silently overrides whatever port you pass as an argument.
    # Clear them so our DASH_PORT wins.  (These are per-process env vars
    # inherited by Start-Process below.)
    Remove-Item Env:PORT -ErrorAction SilentlyContinue
    Remove-Item Env:HOST -ErrorAction SilentlyContinue

    Start-Process -FilePath $python -ArgumentList "app.py" `
        -WorkingDirectory $Dir `
        -WindowStyle Hidden `
        -RedirectStandardOutput $logPath `
        -RedirectStandardError $errPath | Out-Null

    Write-Host "Started $Name -> port $Port (log: $logPath)"
}

function Start-Portal {
    param([int]$Port = 8071)

    $procs = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
             Select-Object -ExpandProperty OwningProcess -Unique
    foreach ($p in $procs) { Stop-Process -Id $p -Force -ErrorAction SilentlyContinue }

    $logPath = Join-Path $base "portal_app.log"
    $errPath = "$logPath.err"
    foreach ($f in $logPath, $errPath) {
        if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue }
    }

    # portal_app.py reads PORT/HOST directly via core.constants.get_port() –
    # the opposite of the three Dash apps, so here we *set* PORT.
    $env:PORT = "$Port"
    Remove-Item Env:HOST -ErrorAction SilentlyContinue
    $env:DASH_ENV = "local"

    Start-Process -FilePath $python -ArgumentList "portal_app.py" `
        -WorkingDirectory $base `
        -WindowStyle Hidden `
        -RedirectStandardOutput $logPath `
        -RedirectStandardError $errPath | Out-Null

    # Don't leak PORT=8071 to the next Start-Dashboard call.
    Remove-Item Env:PORT -ErrorAction SilentlyContinue

    Write-Host "Started portal -> port $Port (log: $logPath)"
}

Start-Dashboard -Name fundamental -Dir "$base\fundamental_dashboard" -Port 9101
Start-Dashboard -Name price       -Dir "$base\price_dashboard"       -Port 9103
Start-Dashboard -Name stack       -Dir "$base\stack_dashboard"       -Port 9105
Start-Portal                                                          -Port 8071

Write-Host ""
Write-Host "All dashboards launching.  Give them ~60 seconds then visit:"
Write-Host "  http://localhost:9101  (fundamental)"
Write-Host "  http://localhost:9103  (price)"
Write-Host "  http://localhost:9105  (stack)"
Write-Host "  http://localhost:8071  (portal)"
