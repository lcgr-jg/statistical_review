"""
Quick Plotly Dash dashboard: French nuclear forced-outage extension analysis.

Cohort: outages whose v1 was `Fortuite` (forced) and that are now fully resolved.

Run:
    python -m power_analysis.nuclear.app           # default port 8061
    python -m power_analysis.nuclear.app --port 8070 --debug
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, Input, Output, dash_table, dcc, html

# Make repo root importable when run as a script
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from french_nuclear_availability.availability_model_class import AvailabilityModel  # noqa: E402
from french_nuclear_availability.data_utils.data_loader import EDFDataLoader  # noqa: E402

from power_analysis.nuclear.data_prep import (  # noqa: E402
    CohortConfig,
    build_outage_cohort,
    summary_stats,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("nuclear_extension_app")


# ---------------------------------------------------------------------------
# Data load (one-shot, on import)
# ---------------------------------------------------------------------------
COLORS = {
    "background": "#f5f6f8",
    "card_bg": "#ffffff",
    "chart_bg": "#faf9f6",
    "border": "#e1e4e8",
    "text_primary": "#231F20",
    "text_secondary": "#323E48",
    "accent": "#4E738A",
    "warning": "#d94f00",
    "danger": "#de350b",
    "success": "#00875a",
}


def _is_main_process() -> bool:
    val = os.environ.get("WERKZEUG_RUN_MAIN")
    return val == "true" or val is None


def load_cohort() -> tuple[pd.DataFrame, dict]:
    loader = EDFDataLoader(logger=logger)
    data_path = loader.get_data_path(force_refresh=False)
    logger.info(f"Loaded EDF data: {data_path}")

    model = AvailabilityModel(data_path)
    base_df = model.base_df
    logger.info(f"Base df: {len(base_df):,} version rows, "
                f"{base_df['identifiant'].nunique():,} unique outages")

    cohort = build_outage_cohort(
        base_df=base_df,
        classify_fn=AvailabilityModel.classify_message,
        config=CohortConfig(),
    )
    logger.info(f"Cohort (resolved + v1=Fortuite): {len(cohort):,} outages")

    meta = {
        "data_path": data_path,
        "n_base_rows": int(len(base_df)),
        "n_base_outages": int(base_df["identifiant"].nunique()),
        "n_cohort": int(len(cohort)),
        "loaded_at": datetime.now().isoformat(timespec="seconds"),
    }
    return cohort, meta


if _is_main_process():
    COHORT, META = load_cohort()
else:
    COHORT, META = pd.DataFrame(), {}


# ---------------------------------------------------------------------------
# Layout helpers
# ---------------------------------------------------------------------------
METRIC_OPTIONS = [
    {"label": "End-date extension (days)", "value": "end_extension_days"},
    {"label": "Duration extension (days)", "value": "duration_extension_days"},
    {"label": "Pct duration extension (%)", "value": "pct_duration_extension"},
    {"label": "Start-date shift (days)", "value": "start_shift_days"},
    {"label": "Number of versions", "value": "n_versions"},
    {"label": "Realized duration (days)", "value": "realized_duration_days"},
    {"label": "Planned duration v1 (days)", "value": "planned_duration_days"},
]

GROUP_OPTIONS = [
    {"label": "(none)", "value": "__none__"},
    {"label": "Reactor unit", "value": "unit_name"},
    {"label": "Info category (v1)", "value": "category_v1"},
    {"label": "Year of v1", "value": "year_v1"},
    {"label": "Type transition (v1 → final)", "value": "type_transition"},
]


def _kpi_card(label: str, value: str, sub: str = "") -> html.Div:
    return html.Div(
        [
            html.Div(label, style={
                "fontSize": "11px", "color": COLORS["text_secondary"],
                "textTransform": "uppercase", "letterSpacing": "0.05em",
            }),
            html.Div(value, style={
                "fontSize": "22px", "fontWeight": 600,
                "color": COLORS["text_primary"], "marginTop": "4px",
            }),
            html.Div(sub, style={
                "fontSize": "11px", "color": COLORS["text_secondary"],
                "marginTop": "2px",
            }),
        ],
        style={
            "background": COLORS["card_bg"],
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "6px",
            "padding": "12px 14px",
            "flex": "1 1 0",
            "minWidth": "140px",
        },
    )


def build_layout() -> html.Div:
    units = sorted(COHORT["unit_name"].dropna().unique().tolist()) if not COHORT.empty else []
    cats = sorted(COHORT["category_v1"].dropna().unique().tolist()) if not COHORT.empty else []
    if not COHORT.empty:
        years = sorted(pd.to_datetime(COHORT["publication_ts_v1"]).dt.year.dropna().unique().astype(int).tolist())
    else:
        years = []

    header = html.Div(
        [
            html.H2(
                "French Nuclear — Forced Outage Extension Analysis",
                style={"margin": 0, "color": COLORS["text_primary"]},
            ),
            html.Div(
                f"Cohort: {META.get('n_cohort', 0):,} fully-resolved outages with v1 = Fortuite "
                f"  •   {META.get('n_base_outages', 0):,} total nuclear outages in source"
                f"  •   loaded {META.get('loaded_at', '?')}",
                style={"fontSize": "12px", "color": COLORS["text_secondary"], "marginTop": "4px"},
            ),
        ],
        style={"padding": "14px 20px", "borderBottom": f"1px solid {COLORS['border']}"},
    )

    controls = html.Div(
        [
            html.Div([
                html.Label("Metric", style={"fontSize": "11px", "color": COLORS["text_secondary"]}),
                dcc.Dropdown(
                    id="metric-dd",
                    options=METRIC_OPTIONS,
                    value="end_extension_days",
                    clearable=False,
                ),
            ], style={"flex": "1 1 220px", "minWidth": "200px"}),

            html.Div([
                html.Label("Group by", style={"fontSize": "11px", "color": COLORS["text_secondary"]}),
                dcc.Dropdown(
                    id="group-dd",
                    options=GROUP_OPTIONS,
                    value="category_v1",
                    clearable=False,
                ),
            ], style={"flex": "1 1 200px", "minWidth": "180px"}),

            html.Div([
                html.Label("Reactor unit filter", style={"fontSize": "11px", "color": COLORS["text_secondary"]}),
                dcc.Dropdown(
                    id="unit-dd",
                    options=[{"label": u, "value": u} for u in units],
                    value=[], multi=True, placeholder="All units",
                ),
            ], style={"flex": "2 1 280px", "minWidth": "240px"}),

            html.Div([
                html.Label("Info category filter (v1)", style={"fontSize": "11px", "color": COLORS["text_secondary"]}),
                dcc.Dropdown(
                    id="cat-dd",
                    options=[{"label": c, "value": c} for c in cats],
                    value=[], multi=True, placeholder="All categories",
                ),
            ], style={"flex": "2 1 280px", "minWidth": "240px"}),

            html.Div([
                html.Label("v1 year filter", style={"fontSize": "11px", "color": COLORS["text_secondary"]}),
                dcc.Dropdown(
                    id="year-dd",
                    options=[{"label": str(y), "value": int(y)} for y in years],
                    value=[], multi=True, placeholder="All years",
                ),
            ], style={"flex": "1 1 180px", "minWidth": "160px"}),

            html.Div([
                html.Label("Type-conversion filter", style={"fontSize": "11px", "color": COLORS["text_secondary"]}),
                dcc.Dropdown(
                    id="conv-dd",
                    options=[
                        {"label": "All (forced at v1)", "value": "all"},
                        {"label": "Stayed forced (Fortuite → Fortuite)", "value": "stayed"},
                        {"label": "Converted to planned (Fortuite → Planifiée)", "value": "converted"},
                    ],
                    value="all", clearable=False,
                ),
            ], style={"flex": "1 1 240px", "minWidth": "220px"}),

            html.Div([
                html.Label("Trim x-axis to percentile", style={"fontSize": "11px", "color": COLORS["text_secondary"]}),
                dcc.Slider(
                    id="trim-slider", min=80, max=100, step=1, value=99,
                    marks={80: "80", 90: "90", 95: "95", 99: "99", 100: "100"},
                    tooltip={"placement": "bottom", "always_visible": False},
                ),
            ], style={"flex": "1 1 200px", "minWidth": "180px"}),
        ],
        style={
            "display": "flex", "flexWrap": "wrap", "gap": "14px",
            "padding": "14px 20px",
            "background": COLORS["card_bg"],
            "borderBottom": f"1px solid {COLORS['border']}",
        },
    )

    kpis = html.Div(id="kpi-row", style={
        "display": "flex", "gap": "10px", "flexWrap": "wrap",
        "padding": "12px 20px",
    })

    charts_row1 = html.Div([
        dcc.Graph(id="hist-graph", style={"flex": "1 1 50%", "minWidth": "420px"}),
        dcc.Graph(id="cdf-graph", style={"flex": "1 1 50%", "minWidth": "420px"}),
    ], style={"display": "flex", "flexWrap": "wrap", "gap": "12px", "padding": "0 20px"})

    charts_row2 = html.Div([
        dcc.Graph(id="box-graph", style={"flex": "1 1 50%", "minWidth": "420px"}),
        dcc.Graph(id="scatter-graph", style={"flex": "1 1 50%", "minWidth": "420px"}),
    ], style={"display": "flex", "flexWrap": "wrap", "gap": "12px", "padding": "12px 20px 0 20px"})

    stats_table = html.Div(
        [
            html.H4("Summary statistics by group", style={
                "margin": "16px 20px 6px 20px",
                "color": COLORS["text_primary"],
            }),
            html.Div(id="stats-table-wrap", style={"padding": "0 20px"}),
        ]
    )

    return html.Div(
        [header, controls, kpis, charts_row1, charts_row2, stats_table,
         html.Div(style={"height": "30px"})],
        style={
            "background": COLORS["background"],
            "minHeight": "100vh",
            "fontFamily": '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        },
    )


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
app = Dash(__name__, title="Nuclear Outage Extensions", suppress_callback_exceptions=True)
server = app.server
app.layout = build_layout


def _filter_cohort(units, cats, years, conv) -> pd.DataFrame:
    df = COHORT.copy()
    if df.empty:
        return df
    df["year_v1"] = pd.to_datetime(df["publication_ts_v1"]).dt.year
    if units:
        df = df[df["unit_name"].isin(units)]
    if cats:
        df = df[df["category_v1"].isin(cats)]
    if years:
        df = df[df["year_v1"].isin(years)]
    if conv == "stayed":
        df = df[~df["converted_to_planned"].astype(bool)]
    elif conv == "converted":
        df = df[df["converted_to_planned"].astype(bool)]
    return df


def _trim_range(values: pd.Series, pct: float) -> tuple[float, float]:
    s = pd.to_numeric(values, errors="coerce").dropna()
    if len(s) == 0:
        return (0.0, 1.0)
    if pct >= 100:
        lo, hi = float(s.min()), float(s.max())
    else:
        upper_q = pct / 100.0
        lower_q = 1.0 - upper_q
        lo = float(s.quantile(min(0.0, lower_q))) if lower_q < 0 else float(s.quantile(max(0.0, lower_q)))
        hi = float(s.quantile(upper_q))
    if lo == hi:
        hi = lo + 1.0
    pad = (hi - lo) * 0.03
    return (lo - pad, hi + pad)


@app.callback(
    [
        Output("kpi-row", "children"),
        Output("hist-graph", "figure"),
        Output("cdf-graph", "figure"),
        Output("box-graph", "figure"),
        Output("scatter-graph", "figure"),
        Output("stats-table-wrap", "children"),
    ],
    [
        Input("metric-dd", "value"),
        Input("group-dd", "value"),
        Input("unit-dd", "value"),
        Input("cat-dd", "value"),
        Input("year-dd", "value"),
        Input("conv-dd", "value"),
        Input("trim-slider", "value"),
    ],
)
def update_all(metric, group, units, cats, years, conv, trim_pct):
    df = _filter_cohort(units, cats, years, conv)
    metric_label = next((o["label"] for o in METRIC_OPTIONS if o["value"] == metric), metric)

    if df.empty or metric not in df.columns:
        empty = go.Figure().update_layout(
            title="No data for current filter", template="plotly_white",
            paper_bgcolor=COLORS["card_bg"], plot_bgcolor=COLORS["chart_bg"],
        )
        return ([_kpi_card("Cohort size", "0")], empty, empty, empty, empty, html.Div("No rows."))

    s = pd.to_numeric(df[metric], errors="coerce")
    if metric == "pct_duration_extension":
        s = s * 100.0  # display as percent

    valid = s.dropna()
    stats = summary_stats(valid)
    unit = "%" if metric == "pct_duration_extension" else (
        "" if metric == "n_versions" else "days"
    )

    kpis = [
        _kpi_card("Cohort size", f"{stats['n']:,}"),
        _kpi_card("Mean", f"{stats['mean']:.2f} {unit}"),
        _kpi_card("Median", f"{stats['median']:.2f} {unit}"),
        _kpi_card("Std dev", f"{stats['std']:.2f} {unit}"),
        _kpi_card("P90", f"{stats['p90']:.2f} {unit}"),
        _kpi_card("P95", f"{stats['p95']:.2f} {unit}"),
        _kpi_card("P99", f"{stats['p99']:.2f} {unit}"),
        _kpi_card("Max", f"{stats['max']:.2f} {unit}"),
        _kpi_card("Skew", f"{stats['skew']:.2f}"),
        _kpi_card("% extended (>0)", f"{stats['pct_extended']:.1f}%"),
    ]

    # Trim x-axis range based on percentile slider
    x_lo, x_hi = _trim_range(valid, trim_pct)

    # ------- Histogram -------
    hist = go.Figure()
    hist.add_trace(go.Histogram(
        x=valid, nbinsx=60,
        marker=dict(color=COLORS["accent"], line=dict(color="white", width=0.5)),
        name="count",
    ))
    if stats["n"] > 0:
        hist.add_vline(x=stats["mean"], line=dict(color=COLORS["danger"], dash="dash"),
                       annotation_text=f"mean {stats['mean']:.1f}", annotation_position="top")
        hist.add_vline(x=stats["median"], line=dict(color=COLORS["success"], dash="dot"),
                       annotation_text=f"median {stats['median']:.1f}", annotation_position="bottom")
    hist.update_layout(
        title=f"Distribution — {metric_label}",
        template="plotly_white",
        paper_bgcolor=COLORS["card_bg"], plot_bgcolor=COLORS["chart_bg"],
        xaxis=dict(title=f"{metric_label}", range=[x_lo, x_hi]),
        yaxis=dict(title="Number of outages"),
        margin=dict(l=50, r=20, t=50, b=40),
        bargap=0.05,
    )

    # ------- ECDF -------
    cdf = go.Figure()
    if group and group != "__none__" and group in df.columns:
        for label, sub in df.groupby(group, dropna=True):
            sv = pd.to_numeric(sub[metric], errors="coerce").dropna()
            if metric == "pct_duration_extension":
                sv = sv * 100.0
            if len(sv) < 5:
                continue
            sv_sorted = np.sort(sv.values)
            ecdf = np.arange(1, len(sv_sorted) + 1) / len(sv_sorted)
            cdf.add_trace(go.Scatter(
                x=sv_sorted, y=ecdf, mode="lines",
                name=f"{label} (n={len(sv_sorted)})",
            ))
    else:
        sv_sorted = np.sort(valid.values)
        ecdf = np.arange(1, len(sv_sorted) + 1) / len(sv_sorted)
        cdf.add_trace(go.Scatter(
            x=sv_sorted, y=ecdf, mode="lines",
            line=dict(color=COLORS["accent"]), name=f"all (n={len(sv_sorted)})",
        ))
    cdf.update_layout(
        title=f"Empirical CDF — {metric_label}",
        template="plotly_white",
        paper_bgcolor=COLORS["card_bg"], plot_bgcolor=COLORS["chart_bg"],
        xaxis=dict(title=metric_label, range=[x_lo, x_hi]),
        yaxis=dict(title="P(X ≤ x)", range=[0, 1.02]),
        margin=dict(l=50, r=20, t=50, b=40),
        legend=dict(font=dict(size=10)),
    )

    # ------- Box / strip by group -------
    if group and group != "__none__" and group in df.columns:
        plot_df = df.copy()
        if metric == "pct_duration_extension":
            plot_df[metric] = pd.to_numeric(plot_df[metric], errors="coerce") * 100.0
        # Order groups by median descending
        order = (
            plot_df.groupby(group)[metric].median().sort_values(ascending=False).index.tolist()
        )
        box = px.box(
            plot_df, x=group, y=metric, points="outliers",
            category_orders={group: order},
        )
        box.update_traces(marker=dict(color=COLORS["accent"]),
                          line=dict(color=COLORS["accent"]))
        box.update_layout(
            title=f"{metric_label} by {group}",
            template="plotly_white",
            paper_bgcolor=COLORS["card_bg"], plot_bgcolor=COLORS["chart_bg"],
            xaxis=dict(title=group, tickangle=-30),
            yaxis=dict(title=metric_label),
            margin=dict(l=60, r=20, t=50, b=80),
        )
    else:
        box = go.Figure()
        box.add_trace(go.Box(y=valid, name="all", marker=dict(color=COLORS["accent"])))
        box.update_layout(
            title=f"{metric_label} (all)", template="plotly_white",
            paper_bgcolor=COLORS["card_bg"], plot_bgcolor=COLORS["chart_bg"],
            yaxis=dict(title=metric_label),
            margin=dict(l=60, r=20, t=50, b=40),
        )

    # ------- Scatter: planned duration vs metric -------
    sc_df = df.copy()
    if metric == "pct_duration_extension":
        sc_df[metric] = pd.to_numeric(sc_df[metric], errors="coerce") * 100.0
    color_col = group if (group and group != "__none__" and group in sc_df.columns) else None
    scatter = px.scatter(
        sc_df,
        x="planned_duration_days", y=metric,
        color=color_col,
        hover_data=["unit_name", "category_v1", "publication_ts_v1", "n_versions"],
        opacity=0.7,
    )
    scatter.update_layout(
        title=f"{metric_label} vs planned duration (v1)",
        template="plotly_white",
        paper_bgcolor=COLORS["card_bg"], plot_bgcolor=COLORS["chart_bg"],
        xaxis=dict(title="Planned duration v1 (days)"),
        yaxis=dict(title=metric_label),
        margin=dict(l=60, r=20, t=50, b=40),
        legend=dict(font=dict(size=10)),
    )

    # ------- Stats table -------
    if group and group != "__none__" and group in df.columns:
        rows = []
        for label, sub in df.groupby(group, dropna=False):
            sv = pd.to_numeric(sub[metric], errors="coerce")
            if metric == "pct_duration_extension":
                sv = sv * 100.0
            st = summary_stats(sv)
            st_row = {"group": str(label) if pd.notna(label) else "(NaN)"}
            st_row.update({k: (round(v, 3) if isinstance(v, float) and not np.isnan(v) else v)
                           for k, v in st.items()})
            rows.append(st_row)
        rows.sort(key=lambda r: (r.get("median") if r.get("median") is not None else -1e18), reverse=True)
        stats_df = pd.DataFrame(rows)
    else:
        st = summary_stats(valid)
        st_row = {"group": "all"}
        st_row.update({k: (round(v, 3) if isinstance(v, float) and not np.isnan(v) else v)
                       for k, v in st.items()})
        stats_df = pd.DataFrame([st_row])

    cols = [{"name": c, "id": c} for c in stats_df.columns]
    table = dash_table.DataTable(
        data=stats_df.to_dict("records"),
        columns=cols,
        style_cell={"fontSize": 12, "fontFamily": "monospace", "padding": "6px 8px"},
        style_header={"backgroundColor": COLORS["chart_bg"], "fontWeight": 600},
        style_data_conditional=[{
            "if": {"row_index": "odd"}, "backgroundColor": "#fafbfc",
        }],
        sort_action="native",
        page_size=20,
    )

    return kpis, hist, cdf, box, scatter, table


def main(argv: Optional[list[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Nuclear forced-outage extension dashboard")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8061)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(argv)

    print(f"Open http://{args.host}:{args.port}/")
    app.run(debug=args.debug, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
