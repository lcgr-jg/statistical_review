# French Nuclear — Forced Outage Extension Analysis

Quick standalone Plotly Dash dashboard for studying how unplanned (forced)
French nuclear outages get extended after their first published version.

## Cohort definition

For each EDF outage `identifiant`:

1. Take the **first version** (lowest `version`, earliest `publication_ts`).
2. Keep only outages where v1's `type_norm == "Fortuite"` (forced/unplanned).
3. Keep only **fully resolved** outages:
   - latest non-cancelled version's `end` is in the past, AND
   - latest `publication_ts` is at least 7 days old (no recent revisions).
4. Drop outages whose latest status is `Annulée` or `Supprimée`.

For each surviving outage we compute:

- `planned_duration_days`  = `end_v1 − start_v1`
- `realized_duration_days` = `end_final − start_final`
- `end_extension_days`     = `end_final − end_v1`            ← headline metric
- `start_shift_days`       = `start_final − start_v1`
- `duration_extension_days` = realized − planned
- `pct_duration_extension` = duration_extension / planned
- `n_versions`             = distinct version count
- `category_v1`            = info classifier on v1 (`OUTAGE_MAY_BE_EXTENDED`,
  `CORROSION_RISK_CSC`, `TECHNICAL_INVESTIGATION`, etc., from
  `french_nuclear_availability/utils.py`)

## Run

From `eu_dashboard_power/`:

```bash
python -m power_analysis.nuclear.app
```

Then open http://127.0.0.1:8061/

Options:

```bash
python -m power_analysis.nuclear.app --port 8070 --debug
```

The app loads EDF data via the existing `EDFDataLoader` (S3 + 6h local
cache) and `AvailabilityModel`, so no extra config is needed beyond the
same env that runs the main portal.

## Charts

- KPI strip: n, mean, median, std, P90/95/99, max, skew, % extended.
- Histogram with mean/median markers.
- Empirical CDF (split by selected group).
- Boxplot per group, sorted by median.
- Scatter of metric vs `planned_duration_days` to see scale dependence.
- Per-group statistics table.

Filters: reactor unit, info category (v1), v1 year, x-axis trim percentile
(to tame heavy tails for visualisation).
