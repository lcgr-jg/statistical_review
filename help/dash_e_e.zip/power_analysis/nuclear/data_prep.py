"""
Data preparation for the French Nuclear forced-outage extension analysis.

Cohort definition (per user spec):
- Per outage `identifiant`, the FIRST published version (v1) must be
  classified as `Fortuite` (forced/unplanned) in `type_norm`.
- The "final" version is the latest non-cancelled version of the SAME
  identifiant, regardless of whether `type_norm` has been converted to
  `Planifiée` later in the version history. Outages that start forced and
  later get reclassified to planned ARE included; `end_final` is taken from
  the truly last (non-cancelled) version even if its type is `Planifiée`.
- Only "fully resolved" outages: latest non-cancelled version's `end`
  is in the past AND last `publication_ts` is at least
  `RESOLVED_BUFFER_DAYS` ago (so we believe no further revisions will arrive).
- Cancelled outages (latest status `Annulée` or `Supprimée`) are dropped.

For each surviving outage we compute:
- v1: start_v1, end_v1, publication_ts_v1, planned_duration_v1 = end_v1 - start_v1
- final: start_final, end_final, publication_ts_final
- realized_duration = end_final - start_final
- end_extension_days = end_final - end_v1     (positive => extended)
- start_shift_days   = start_final - start_v1 (rarely non-zero)
- duration_extension_days = realized_duration - planned_duration_v1
- pct_duration_extension = duration_extension_days / planned_duration_v1
- n_versions
- unit_name, pmax_mw_v1, pavail_mw_v1, info_v1, category_v1

The category is computed via `AvailabilityModel.classify_message` on the v1
`info` string.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd


RESOLVED_BUFFER_DAYS = 7  # require last publication >= this many days old


@dataclass
class CohortConfig:
    resolved_buffer_days: int = RESOLVED_BUFFER_DAYS
    require_v1_forced: bool = True
    drop_cancelled: bool = True
    min_planned_duration_hours: float = 1.0  # filter pathological zero-length v1


def _select_first_version(group: pd.DataFrame) -> pd.Series:
    """Return the row corresponding to the earliest (version, publication_ts)."""
    g = group.sort_values(["version", "publication_ts"], na_position="last")
    return g.iloc[0]


def _select_last_noncancelled_version(group: pd.DataFrame) -> Optional[pd.Series]:
    """Latest version that isn't Annulée/Supprimée."""
    g = group.sort_values(["version", "publication_ts"], na_position="first")
    # Status could be 'Active' / 'Inactive' / 'Annulée' / 'Supprimée'
    mask_alive = ~g["status"].astype(str).str.contains(
        "Annul|Supprim", case=False, na=False
    )
    alive = g[mask_alive]
    if len(alive) == 0:
        return None
    return alive.iloc[-1]


def build_outage_cohort(
    base_df: pd.DataFrame,
    classify_fn,
    as_of: Optional[datetime] = None,
    config: Optional[CohortConfig] = None,
) -> pd.DataFrame:
    """
    Build the per-outage cohort dataframe.

    Parameters
    ----------
    base_df
        ``AvailabilityModel.base_df`` (already filtered to nuclear
        Planifiée/Fortuite, with normalised columns).
    classify_fn
        Callable mapping an `info` string to a category label
        (use ``AvailabilityModel.classify_message``).
    as_of
        Reference "now". Defaults to ``datetime.now()``.
    config
        Cohort configuration knobs.

    Returns
    -------
    pandas.DataFrame
        One row per outage, indexed by `identifiant`.
    """
    cfg = config or CohortConfig()
    now = as_of or datetime.now()
    cutoff_pub = now - timedelta(days=cfg.resolved_buffer_days)

    df = base_df.copy()
    # Defensive: ensure required columns exist
    required = {
        "identifiant", "version", "status", "type_norm", "unit_name",
        "start", "end", "publication_ts", "pmax_mw", "pavail_mw", "info",
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"base_df missing columns: {sorted(missing)}")

    # Group by identifiant
    rows = []
    for ident, group in df.groupby("identifiant", sort=False):
        if group.empty:
            continue

        v1 = _select_first_version(group)
        last = _select_last_noncancelled_version(group)
        if last is None:
            # Entire outage history is cancelled
            continue

        # v1 must be forced
        if cfg.require_v1_forced and str(v1.get("type_norm")).strip() != "Fortuite":
            continue

        # Resolution check
        end_final = last["end"]
        last_pub = last["publication_ts"]
        if pd.isna(end_final) or pd.isna(last_pub):
            continue
        if end_final >= now:
            continue  # outage still in the future / ongoing
        if last_pub > cutoff_pub:
            continue  # too recently revised, may not be settled

        start_v1 = v1["start"]
        end_v1 = v1["end"]
        start_final = last["start"]

        if pd.isna(start_v1) or pd.isna(end_v1) or pd.isna(start_final):
            continue

        planned_dur_h = (end_v1 - start_v1).total_seconds() / 3600.0
        if planned_dur_h < cfg.min_planned_duration_hours:
            continue

        realized_dur_h = (end_final - start_final).total_seconds() / 3600.0
        end_ext_days = (end_final - end_v1).total_seconds() / 86400.0
        start_shift_days = (start_final - start_v1).total_seconds() / 86400.0
        dur_ext_days = (realized_dur_h - planned_dur_h) / 24.0
        pct_dur_ext = (
            dur_ext_days / (planned_dur_h / 24.0) if planned_dur_h > 0 else np.nan
        )

        info_v1 = v1.get("info")
        category_v1 = classify_fn(info_v1) if classify_fn is not None else "OTHER"

        # n_versions = number of distinct version rows in the group
        n_versions = int(group["version"].nunique())

        type_v1 = v1.get("type_norm")
        type_final = last.get("type_norm")
        type_transition = (
            f"{type_v1}->{type_final}" if type_v1 != type_final else str(type_v1)
        )

        rows.append({
            "identifiant": ident,
            "unit_name": v1.get("unit_name"),
            "type_v1": type_v1,
            "type_final": type_final,
            "type_transition": type_transition,
            "converted_to_planned": (type_v1 == "Fortuite" and type_final == "Planifiée"),
            "status_final": last.get("status"),
            "category_v1": category_v1,
            "info_v1": info_v1,
            "start_v1": start_v1,
            "end_v1": end_v1,
            "publication_ts_v1": v1.get("publication_ts"),
            "start_final": start_final,
            "end_final": end_final,
            "publication_ts_final": last_pub,
            "planned_duration_days": planned_dur_h / 24.0,
            "realized_duration_days": realized_dur_h / 24.0,
            "end_extension_days": end_ext_days,
            "start_shift_days": start_shift_days,
            "duration_extension_days": dur_ext_days,
            "pct_duration_extension": pct_dur_ext,
            "n_versions": n_versions,
            "pmax_mw_v1": v1.get("pmax_mw"),
            "pavail_mw_v1": v1.get("pavail_mw"),
        })

    cohort = pd.DataFrame(rows)
    if not cohort.empty:
        cohort = cohort.set_index("identifiant").sort_values("publication_ts_v1")
    return cohort


def summary_stats(series: pd.Series) -> dict:
    """Return a dict of headline statistics for a numeric series."""
    s = pd.to_numeric(series, errors="coerce").dropna()
    if len(s) == 0:
        return {k: np.nan for k in [
            "n", "mean", "median", "std", "min", "max",
            "p10", "p25", "p75", "p90", "p95", "p99",
            "skew", "kurtosis", "pct_extended", "pct_shortened",
        ]}
    return {
        "n": int(len(s)),
        "mean": float(s.mean()),
        "median": float(s.median()),
        "std": float(s.std(ddof=1)) if len(s) > 1 else 0.0,
        "min": float(s.min()),
        "max": float(s.max()),
        "p10": float(s.quantile(0.10)),
        "p25": float(s.quantile(0.25)),
        "p75": float(s.quantile(0.75)),
        "p90": float(s.quantile(0.90)),
        "p95": float(s.quantile(0.95)),
        "p99": float(s.quantile(0.99)),
        "skew": float(s.skew()) if len(s) > 2 else np.nan,
        "kurtosis": float(s.kurt()) if len(s) > 3 else np.nan,
        "pct_extended": float((s > 0).mean() * 100),
        "pct_shortened": float((s < 0).mean() * 100),
    }
