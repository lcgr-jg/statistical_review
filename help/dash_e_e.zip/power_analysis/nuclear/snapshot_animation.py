"""
French nuclear availability — Q2 + Q3 2026 snapshot animation
==============================================================

Builds an animated Plotly figure showing how the EQ REMIT forward
availability curve for France nuclear evolved across the last 25 Monday
snapshots, covering Q2 + Q3 2026 (1 Apr – 30 Sep 2026).

For each Monday snapshot S:
  • Realised segment : 1 Apr 2026 … S       (cache only, refresh=False)
    → only applies when S is on or after 1 Apr 2026
  • Forward segment  : S+1       … 30 Sep 2026
    → EQ snapshot as-of 23:59:59 on S

Chart axes:
  x = value_date (actual calendar date in Q2/Q3 2026)
  y = availability (MW)
  colour = snapshot_date (YlOrRd ramp — oldest = pale, newest = vivid)

Animation:
  One frame per Monday.  The active snapshot is drawn thick + full
  opacity; all previous snapshots are thin and semi-transparent;
  snapshots not yet "reached" are hidden, so the picture builds up
  cumulatively as you press Play.

Run (from eu_dashboard_power/):
    python -m power_analysis.nuclear.snapshot_animation
    python -m power_analysis.nuclear.snapshot_animation --html out.html --no-browser
    python -m power_analysis.nuclear.snapshot_animation --weeks 20 --port 8062
"""
from __future__ import annotations

import argparse
import datetime as dt
import logging
import os
import sys
from pathlib import Path

_here = Path(__file__).resolve().parent
_repo = _here.parents[1]                          # eu_dashboard_power/
_eu_hr = _repo.parent / "eu_heatrate_model"       # sibling repo
for _p in (_repo, _eu_hr):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.colors import sample_colorscale

from availability.config import AvailabilityConfig, DEFAULT_STORAGE
from availability.curves import resolve_curve_name
from availability.data.eq_adapter import EQSnapshotClient
from availability.data.loader import AvailabilityDataLoader

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
logger = logging.getLogger(__name__)

CURVE_FR_NUCLEAR = resolve_curve_name("FR", "nuclear")

# ── Constants ─────────────────────────────────────────────────────────────────
Q2_Q3_START = dt.date(2026, 4, 1)
Q2_Q3_END   = dt.date(2026, 9, 30)   # inclusive
WINDOW_BEGIN = dt.datetime(2026, 4, 1, 0, 0, 0)
WINDOW_END   = dt.datetime(2026, 10, 1, 0, 0, 0)  # exclusive


def _default_cache_root() -> Path:
    return Path(DEFAULT_STORAGE.local_cache_dir).expanduser().resolve()


def _mondays_up_to(n: int, reference: dt.date | None = None) -> list[dt.date]:
    """Return the last `n` Mondays (weekday=0) up to and including the most
    recent Monday on or before `reference` (default: today)."""
    ref = reference or dt.date.today()
    # Roll back to last Monday
    days_since_monday = ref.weekday()  # 0=Mon, 6=Sun
    last_monday = ref - dt.timedelta(days=days_since_monday)
    mondays = [last_monday - dt.timedelta(weeks=k) for k in range(n)]
    return list(reversed(mondays))  # oldest first


def _as_of(d: dt.date) -> dt.datetime:
    """End of calendar day (naive UTC) — inclusive of publications on d."""
    return dt.datetime.combine(d, dt.time(23, 59, 59))


def _fetch_snapshot_series(
    snap: dt.date,
    client: EQSnapshotClient,
    loader: AvailabilityDataLoader,
) -> pd.Series:
    """
    Return a daily MW Series for Q2+Q3 2026 as known at end of `snap`.

    For dates in [Q2_Q3_START, snap]:
        use realised cache  (refresh=False — no network)
    For dates in [snap+1, Q2_Q3_END]:
        use EQ forward snapshot as-of end of snap
    """
    parts: list[pd.DataFrame] = []

    # ── Realised segment ──────────────────────────────────────────────────────
    if snap >= Q2_Q3_START:
        real_start = WINDOW_BEGIN
        # +1 day because get_realised_daily uses exclusive end
        real_end   = dt.datetime.combine(snap + dt.timedelta(days=1), dt.time.min)
        try:
            df_real = loader.get_realised_daily(real_start, real_end, refresh=False)
            if not df_real.empty:
                parts.append(df_real)
        except Exception as exc:
            logger.warning("Realised fetch failed for snap=%s: %s", snap, exc)

    # ── Forward snapshot segment ───────────────────────────────────────────────
    fwd_begin = dt.datetime.combine(snap + dt.timedelta(days=1), dt.time.min)
    if fwd_begin < WINDOW_END:
        try:
            df_fwd = client.fetch_forecast_snapshot(
                CURVE_FR_NUCLEAR,
                as_of=_as_of(snap),
                begin=max(fwd_begin, WINDOW_BEGIN),
                end=WINDOW_END,
            )
            if not df_fwd.empty:
                df_fwd = df_fwd.copy()
                df_fwd.index = pd.to_datetime(df_fwd.index).tz_localize(None).normalize()
                df_fwd.index.name = "date"
                parts.append(df_fwd)
        except Exception as exc:
            logger.warning("Forward snapshot failed for snap=%s: %s", snap, exc)

    if not parts:
        return pd.Series(dtype=float, name="mw")

    combined = pd.concat(parts, axis=0)
    combined = combined[~combined.index.duplicated(keep="last")].sort_index()
    # Trim to Q2+Q3 window
    lo = pd.Timestamp(Q2_Q3_START)
    hi = pd.Timestamp(Q2_Q3_END)
    combined = combined.loc[(combined.index >= lo) & (combined.index <= hi)]
    return combined["mw"].rename("mw")


def _color_ramp(n: int) -> list[str]:
    """Colour ramp for n snapshots: oldest = pale cool, newest = vivid warm."""
    if n == 1:
        return ["#e34a33"]
    fracs = [i / (n - 1) for i in range(n)]
    return list(sample_colorscale("YlOrRd", fracs))


def build_figure(
    mondays: list[dt.date],
    cache_root: Path,
) -> go.Figure:
    """
    Build the animated Plotly figure.

    Layout:
     • One Scatter trace per Monday snapshot (all pre-added).
     • frames[k]: snapshot k is thick+full-opacity; 0..k-1 thin+faded; k+1.. invisible.
     • Play button + slider over the 25 frames.
    """
    client = EQSnapshotClient()
    cfg    = AvailabilityConfig(area="FR", fuel="nuclear")
    loader = AvailabilityDataLoader(cfg, client, cache_root=cache_root)

    n = len(mondays)
    colors = _color_ramp(n)

    # ── Fetch all snapshot series ─────────────────────────────────────────────
    series_list: list[pd.Series] = []
    for snap in mondays:
        logger.info("Fetching snapshot %s …", snap)
        s = _fetch_snapshot_series(snap, client, loader)
        series_list.append(s)
        logger.info("  → %d daily rows", len(s))

    # ── Static figure: all traces at initial state (only first visible) ───────
    fig = go.Figure()

    today = dt.date.today()

    for i, (snap, s, color) in enumerate(zip(mondays, series_list, colors)):
        is_current_snap = snap <= today  # sanity; all should be ≤ today

        # Segment hover info: mark realised vs forward per value_date
        hover_segs = []
        for d in pd.to_datetime(s.index):
            d_date = d.date()
            if d_date <= snap:
                hover_segs.append("realised")
            else:
                hover_segs.append("forward snapshot")

        custom = np.column_stack([
            [snap.strftime("%d-%b-%Y")] * len(s),
            hover_segs,
        ])

        # Initial state: frame 0 shows only the first trace;
        # all others start invisible (opacity=0).
        initial_opacity = 1.0 if i == 0 else 0.0
        initial_width   = 3.0 if i == 0 else 1.2

        fig.add_trace(go.Scatter(
            x=s.index.astype(str),   # ISO date strings for clean tick formatting
            y=s.values,
            mode="lines",
            name=snap.strftime("%d-%b"),
            line=dict(color=color, width=initial_width),
            opacity=initial_opacity,
            customdata=custom,
            hovertemplate=(
                "<b>Snapshot %{customdata[0]}</b> · %{customdata[1]}<br>"
                "Value date: %{x}<br>"
                "%{y:,.0f} MW"
                "<extra></extra>"
            ),
            legendgroup=snap.isoformat(),
        ))

    # ── Build animation frames ────────────────────────────────────────────────
    frames = []
    slider_steps = []

    for k, snap_k in enumerate(mondays):
        frame_data = []
        for i in range(n):
            if i < k:
                # Previous snapshots: visible but dimmed
                frame_data.append(go.Scatter(
                    opacity=0.25,
                    line=dict(width=1.0),
                ))
            elif i == k:
                # Active snapshot: prominent
                frame_data.append(go.Scatter(
                    opacity=1.0,
                    line=dict(width=3.5),
                ))
            else:
                # Future snapshots: invisible
                frame_data.append(go.Scatter(
                    opacity=0.0,
                    line=dict(width=0.5),
                ))

        frame_name = str(k)
        frames.append(go.Frame(
            data=frame_data,
            name=frame_name,
            traces=list(range(n)),
        ))

        slider_steps.append({
            "args": [
                [frame_name],
                {"frame": {"duration": 300, "redraw": True},
                 "mode": "immediate",
                 "transition": {"duration": 150}},
            ],
            "label": snap_k.strftime("%d-%b"),
            "method": "animate",
        })

    fig.frames = frames

    # ── Layout ────────────────────────────────────────────────────────────────
    fig.update_layout(
        title=dict(
            text=(
                "FR Nuclear Availability — Q2 + Q3 2026<br>"
                "<sub>EQ REMIT snapshot evolution · last 25 Monday snapshots · "
                "thick line = active snapshot · thin lines = previous snapshots · "
                "colour: oldest pale → newest vivid</sub>"
            ),
            font=dict(size=14),
        ),
        xaxis=dict(
            title="Value date",
            tickformat="%d-%b",
            tickangle=-30,
            tickmode="auto",
            nticks=26,
        ),
        yaxis=dict(title="MW", rangemode="tozero"),
        hovermode="x unified",
        height=580,
        margin=dict(t=100, b=120),
        legend=dict(
            title="Snapshot (Mon)",
            orientation="v",
            x=1.01, y=1.0,
            font=dict(size=10),
        ),
        updatemenus=[{
            "type": "buttons",
            "showactive": False,
            "y": -0.18,
            "x": 0.0,
            "xanchor": "left",
            "yanchor": "top",
            "buttons": [
                {
                    "label": "▶ Play",
                    "method": "animate",
                    "args": [
                        None,
                        {"frame": {"duration": 600, "redraw": True},
                         "fromcurrent": True,
                         "transition": {"duration": 200}},
                    ],
                },
                {
                    "label": "⏸ Pause",
                    "method": "animate",
                    "args": [
                        [None],
                        {"frame": {"duration": 0, "redraw": False},
                         "mode": "immediate",
                         "transition": {"duration": 0}},
                    ],
                },
            ],
        }],
        sliders=[{
            "active": 0,
            "steps": slider_steps,
            "x": 0.08,
            "len": 0.88,
            "y": -0.12,
            "yanchor": "top",
            "currentvalue": {
                "prefix": "Snapshot: ",
                "visible": True,
                "xanchor": "center",
                "font": {"size": 12},
            },
            "transition": {"duration": 150},
        }],
    )

    # Mark today with a vertical line.
    # add_vline fails on string/categorical axes — use add_shape + add_annotation.
    today_str = today.isoformat()
    if Q2_Q3_START.isoformat() <= today_str <= Q2_Q3_END.isoformat():
        fig.add_shape(
            type="line",
            x0=today_str, x1=today_str,
            y0=0, y1=1,
            xref="x", yref="paper",
            line=dict(color="#4E738A", width=1.5, dash="dot"),
        )
        fig.add_annotation(
            x=today_str,
            y=1.0,
            xref="x", yref="paper",
            text="Today",
            showarrow=False,
            yanchor="bottom",
            font=dict(size=10, color="#4E738A"),
        )

    return fig


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--weeks", type=int, default=25,
                   help="Number of Monday snapshots to include (default 25)")
    p.add_argument("--cache-root", type=Path, default=None,
                   help="Root containing FR/nuclear/realised.parquet")
    p.add_argument("--html", type=str, default="",
                   help="Write interactive HTML to this path instead of (or in addition to) showing")
    p.add_argument("--no-browser", action="store_true",
                   help="Do not call fig.show()")
    args = p.parse_args(argv)

    cache_root = (args.cache_root.expanduser().resolve()
                  if args.cache_root else _default_cache_root())

    mondays = _mondays_up_to(args.weeks)
    logger.info(
        "Building animation: %d Monday snapshots  %s → %s",
        len(mondays), mondays[0], mondays[-1],
    )
    logger.info("Q2+Q3 window: %s → %s", Q2_Q3_START, Q2_Q3_END)

    fig = build_figure(mondays, cache_root=cache_root)

    if args.html:
        out = Path(args.html)
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.write_html(str(out), include_plotlyjs="cdn")
        logger.info("Wrote %s", out)

    if not args.no_browser:
        fig.show()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
