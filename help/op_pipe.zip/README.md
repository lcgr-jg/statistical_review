# Options Structure Lab

A desk tool for commodity option structures. FastAPI prices Black-76 packages, path P&L, Monte Carlo and spot-vol regressions. React draws them.

Bloomberg reference and history go through `BBGQuery(p_on_server=True)` in the `corelib` environment. The ticker resolver is separate: it spawns `bbg-mcp-server` (Desktop API, so a logged-in Terminal has to be running) and only writes `backend/config/underlyings.yaml` after you approve.

## Run

Backend, from the `corelib` env:

```powershell
cd backend
copy .env.example .env
# set ANTHROPIC_API_KEY if you want the resolver
& "$env:LOCALAPPDATA\miniconda3\envs\corelib\python.exe" -m uvicorn app.main:app --port 8000
```

Call the `corelib` interpreter by path. If `conda activate` has not taken, a bare `python` resolves to the system Python, which has neither uvicorn nor `jain_commods`.

Frontend:

```powershell
cd frontend
npm.cmd install
npm.cmd run dev
```

Open http://127.0.0.1:5173. Vite proxies `/api` to port 8000.

## Getting a market

Click **Find market** and type a name, e.g. `TTF`. Bloomberg search lists products, with options products tagged OPT (TTF is `FJSA Comdty`). Pick one and the dialog lists every contract in its `FUT_CHAIN` that has listed options, showing the option expiry and the future. The front month is selected automatically; mark a second row as **Back** for calendars and diagonals.

For the chosen expiry the backend reads `OPT_CHAIN`. By default (**Settlement**) it implies Black-76 vols from the out-of-the-money options' `PX_SETTLE` against the future's `PX_SETTLE`, timed from the settlement date. Strikes that settled at the minimum tick are left out (their implied vol is the tick, not the market), the settlement prices are checked for call spreads and butterflies that price outside no-arbitrage bounds, and put-call parity on the near-the-money pairs is compared with the futures settlement; each of these is a warning on the smile. The fitted pillars are in delta, so they carry over to the live future. **Live mids** uses Bloomberg's `IVOL_MID` instead, falling back to `IVOL_LAST_RT` on expiries with no live bid/ask. The choice is kept with the market so Refresh re-pulls the same source. Where one future carries several option series (EUA Dec futures have monthly serials, e.g. `MZBV6` and `MZBX6` on `MZBZ6`), each series is its own row and its own smile. It recomputes Black-76 forward deltas, drops off-curve stale quotes with a robust polynomial pass, then fits SABR (β fixed at 1, α solved from the ATM, ρ and ν calibrated) and reads the 10/25/50 delta pillars off it. The fit's parameters, rmse, 25Δ risk reversal and butterfly are shown under the chart, every point carries its residual (hover), the curve is dashed beyond the listed strikes, and the fitted smile is checked for negative butterflies. If SABR fits a chain clearly worse than the polynomial, the polynomial is used and the smile says so. Pillars the listed strikes do not reach are left blank. Every pillar is editable before you click **Use market**. **Refresh** in the strip re-pulls the same contracts.

Size defaults to per lot (`FUT_CONT_SIZE`, e.g. 720 MWh), and the rate is 0 because these options are futures-style margined. The **Manual** tab keeps the typed-in form.

All of this runs over the desk B-PIPE session, so no Terminal or Claude is needed. The Claude resolver (`/`) is still there for writing tickers into `underlyings.yaml`.

## Tests

```powershell
cd backend
python -m pytest tests -q
```

## Deploy

The app runs on 10.115.0.70 at http://10.115.0.70:8075/, under the same service account as eu_dashboard_power, and is linked as "Options" in that dashboard's header. One container serves both the API and the built frontend.

```powershell
.\deploy\deploy.ps1            # tests, upload, docker build (UI included), restart, health check
.\deploy\deploy.ps1 -Logs      # same, then tail container logs
.\deploy\deploy.ps1 -Help      # all flags
```

On the server, `git pull` and `docker-compose -p options-lab -f deploy/production.yaml build` is enough: the image runs `npm ci` and `npm run build`, so `frontend/dist` is not in git and does not need to be copied. `.\deploy\deploy.ps1` does the same from your laptop over scp. You will be asked for your SSH password twice, then your sudo password. The server keeps the previous release at `~/options_analytics.prev`.

- `wheels/` holds the `jain_commods` wheel, because the server cannot reach Azure Artifacts. Only the Bloomberg module is used, so it is installed with `--no-deps` and needs no Snowflake or AWS credentials.
- Optional `ANTHROPIC_API_KEY` goes in `backend/.env` locally and `deploy/prod.env` on the server (see `deploy/prod.env.example`). That file survives redeploys. Pass it with `--env-file deploy/prod.env` when you run `docker-compose up` by hand.
- The ticker resolver spawns the Bloomberg MCP server. Locally that is `jain-mcp-servers/bbg-mcp-server` on your Terminal. In the container it is the copy in `backend/vendor/bbg_mcp/server.py`, run with `BBG_MODE=bpipe` (the same B-PIPE app login as `BBGQuery(p_on_server=True)`). Re-copy that file when the upstream server changes.
- History parquet cache is persisted at `/var/lib/options-lab/cache`.
- Underlyings added through the resolver are written inside the container and are lost on redeploy. Add them to `backend/config/underlyings.yaml` locally to keep them.

## Copilot

Press `/` or the Copilot button (Esc closes it). On wide screens it docks beside the page instead of covering it. It prices against the market on screen, and it also sees what the current page computed: the drawn path and its attribution, the last Monte Carlo run, or the regime regression. "Explain with Copilot" buttons on the Builder, Path, Monte Carlo and Regimes pages send a question with that context.

- Find a structure: describe a view, with a budget or loss limit if you have one. It turns the view into a scenario (spot move, vol move, horizon), designs its own leg skeletons, searches strike and ratio combinations, refines the winners and offers the best. Load puts the legs into the Builder.
- Critique my structure: reviews the legs you have loaded, including spot shocks and a Monte Carlo shortfall, and can offer alternatives.
- Ask: free questions about the loaded market. It can pull the smile, the term and the vol history.

Every premium and greek on a proposal card is re-priced by the app after the reply. The model is told not to invent numbers. The Resolver tab is the ticker lookup for adding underlyings.

## Screens

The navigation is grouped by what you are doing: Price (Builder, Path, Monte Carlo), Vol (Surface, IV vs RV, Screener, Rolls, Regimes) and Trade (Backtest, Journal, Deck). Every screen has the same shape: controls on the left of the toolbar, Explain / CSV / Refresh on the right, a row of headline tiles, then fixed-height panels, with method notes in small print at the bottom and in tooltips rather than in paragraphs. Pages that need a market show a single Find market gate.

- Builder: templates, legs, premium and greeks, payoff, spot × vol P&L, scenario ladder.
- Path: click a spot-vol path from today to expiry. The background is the structure's P&L. Scrub time. Attribution splits each day into delta, gamma, theta, vega, vanna, volga and a residual.
- Monte Carlo: lognormal future plus mean-reverting log vol. A sample of paths is drawn on the path lab.
- Surface: every listed expiry fitted from its chain in one table: future, ATM, 25Δ RR and BF, 10Δ RR, SABR ρ and ν, fit error, strikes used, and pass/fail flags for the fitted density, static arbitrage on the settlements and put-call parity. Overlaid smiles by delta, the term structure of ATM/RR/BF, the fit residuals by strike for the selected expiry, and the history of ATM/RR/BF/ρ/ν by curve position (M+1…M+4) from the daily snapshots, with z-scores and percentiles on the front-month tiles. Settlement or mid prices; fitting stores today's snapshot for every expiry. API: `GET /api/vol/surface?product=&limit=&source=` and `GET /api/vol/surface/history?contracts=&ranks=`.
- IV vs RV (`/vol`): implied against realised for one contract, IV percentile, realised cone with the listed expiries on it, ATM term structure now against a week and a month ago with RR and fly by expiry, spot-vol changes regression and rolling correlation/beta. "Use in Monte Carlo" sends ρ, κ and vol of vol across.
- Regimes: futures against implied vol, changes regression, rolling beta, realised against implied, smile ridgeline, same-month analogs.
- Backtest: re-opens the loaded structure (same days to expiry, same deltas or % of forward) every week, fortnight, month or quarter through up to ten years of the product's generic history, and holds it to expiry, optionally delta-hedged. The hedge uses the smile-consistent delta by default (the package repriced with the future bumped under the chosen regime, so sticky-delta gives Bartlett's delta); Black-76 forward delta is the alternative. Costs are a half spread in bp on every futures trade, a rebalance band in lots, and a half spread in vol points on entry against each leg's vega. Each trade's option P&L is split with the previous day's greeks into delta, gamma, theta, vega and a residual; gamma + theta is the carry, the realised-against-implied variance term, and the page shows the mean split alongside realised minus implied over the trades. Shows hit rate, mean, worst, drawdown, Sharpe, total before and after costs, the equity curve and P&L against the move. Below it, the breakevens against how often the future moved that far over the same number of days, and realised vol over those windows against today's ATM.
- Screener: every listed expiry with ATM, 1d/1w/1m changes, 20-day realised, IV − RV and the 1-year percentile; an ATM-change heatmap; a smile-change heatmap by pillar; skew (110% − 90%) and slope (60d − 30d) history with percentiles; and vol seasonality by calendar month.
- Rolls: how a calendar vol spread (M+n − M+m, at ATM or any delta) moves into the M+1 expiry. Every past pair is overlaid on days to the roll with the median and 25–75% band, the live pair is drawn on top, and tiles show where it sits against past cycles at the same days to expiry and the usual move into expiry. Below that are the rolling M+n − M+m series and a table of each cycle at 40/30/20/10/5/0 days.
- Journal: paste a broker run or chat. Claude reads the legs, months, bid/offer, size and futures reference; the app prices each quote on its own contract's live smile (at the quoted reference when given), shows bid and offer against the model and the ATM vol the quote implies. Save quotes, log trades, add notes and statuses, and load any of them into the Builder.
- Deck: a printable one-page summary of the loaded structure: legs, risk, payoff, scenario table, history on the generic, and optional Copilot commentary. Print / PDF from the browser.
- Alerts (header): price or ATM-vol levels on any contract. The server checks them every five minutes over B-PIPE, each fires once and waits to be re-armed, and the browser shows a notification if you allow it.

History studies use the product's 1st and 2nd generics (`ROOT1`/`ROOT2 Comdty`), roll-adjusted on `FUT_CUR_GEN_TICKER` changes, and Bloomberg's constant-maturity 30d/60d ATM and 90%/110% moneyness vols. The backtest uses today's smile shape on the historical ATM; the page lists its assumptions. Smiles are snapshotted once a day per contract into `cache/smiles/`: the pillars (which feed the smile-change heatmap and Rolls), the SABR parameters, every strike's vol, settlement price and residual, and the parity and arbitrage checks, so the surface can be refitted or its parameters z-scored later without Bloomberg. "Record today's smiles" on the Screener snapshots the whole curve. Journal and alerts live in `cache/journal.json` and `cache/alerts.json`, on the persisted volume. Set `ALERTS_BACKGROUND=0` to stop the server-side checker.

Rolls uses each listed contract's own ATM history (`HIST_CALL_IMP_VOL`/`HIST_PUT_IMP_VOL`). Bloomberg only has it from Dec25 onwards (option expiry 26 Nov 2025), so there are about a dozen cycles so far. Expired contracts have no option chain, so other deltas are approximated: contract ATM plus the generic's constant-maturity 30d/60d moneyness skew, interpolated to the contract's days to expiry, with the strike solved for the delta. The 90–110% moneyness range does not reach 10 delta, and 25 delta only sometimes, so those points are extrapolated (capped) and counted on the page. To build real pillar history, the server snapshots the first eight expiries' smiles every weekday after 17:00 London time, and Rolls uses those snapshots wherever they exist. `SMILE_SNAPSHOT_PRODUCTS` (comma-separated, default `FJSA Comdty`) picks the products, `SMILE_SNAPSHOT_COUNT` the number of expiries; `SMILE_SNAPSHOT_BACKGROUND=0` turns it off.

The copilot can call the same studies (`backtest_structure`, `breakeven_vs_history`, `vol_seasonality`, `skew_slope_history`, `vol_roll_history`), and Critique uses them when a Bloomberg market is loaded.

Keyboard: `b` builder, `p` path, `c` Monte Carlo, `f` surface, `v` IV vs RV, `s` screener, `o` rolls, `r` regimes, `t` backtest, `j` journal, `d` deck, `/` copilot, Ctrl/Cmd-K search (which also lists every screen with its shortcut). Shortcuts stay quiet while you are typing in a field.
