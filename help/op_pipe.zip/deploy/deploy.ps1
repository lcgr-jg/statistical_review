# =============================================================================
# DEPLOY OPTIONS STRUCTURE LAB TO SERVER (PowerShell)
# =============================================================================
# Target server: 10.115.0.70 (same host and service account as
# eu_dashboard_power). docker-compose v1 lives at ~/.local/bin/docker-compose
# for the service account.
#
# The repo has no git remote yet, so instead of `git pull` on the server this
# script ships a tarball:
#   1. Run backend tests (corelib python)
#   2. Pack backend + frontend source + Dockerfile + deploy/ + wheels/
#      (the image builds the UI itself; frontend/dist is not required)
#   3. scp the tarball to /tmp, then as the service account: unpack into
#      ~/options_analytics.new, build the image, swap it in for
#      ~/options_analytics (previous release kept as .prev), restart
#   4. Probe /api/health
#
# A failed build leaves the running container and release untouched.
# deploy/prod.env on the server (optional, see prod.env.example) is carried
# across releases.
#
# App URL after deploy: http://10.115.0.70:8075/
#
# Usage (from the options_analytics directory):
#   .\deploy\deploy.ps1               # Full deploy
#   .\deploy\deploy.ps1 -SkipTests    # Skip pytest
#   .\deploy\deploy.ps1 -NoCache      # docker-compose build --no-cache
#   .\deploy\deploy.ps1 -Logs         # Tail container logs after deploy
#
# Prompts: SSH password (scp), SSH password (ssh), then sudo password.
# =============================================================================

param(
    [switch]$SkipTests,
    [switch]$NoCache,
    [switch]$Logs,
    [switch]$Help
)

$ServerUser  = "michael.kane"
$ServerHost  = "10.115.0.70"
$ServiceUser = "jsvc-eucommodpm"
$RepoDir     = "options_analytics"
$Project     = "options-lab"
$ServiceName = "options-lab"
$ComposeFile = "deploy/production.yaml"
$AppPort     = "8075"

if ($Help) {
    Write-Host "Usage: .\deploy\deploy.ps1 [-SkipTests] [-NoCache] [-Logs]"
    exit 0
}

function Fail($msg) {
    Write-Host "ERROR: $msg" -ForegroundColor Red
    exit 1
}

$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Python = Join-Path $env:LOCALAPPDATA "miniconda3\envs\corelib\python.exe"

if (-not (Test-Path "Dockerfile")) { Fail "Run from the options_analytics repo (Dockerfile not found in $Root)." }

$wheels = @(Get-ChildItem -Path "wheels\jain_commods-*.whl" -ErrorAction SilentlyContinue)
if (-not $wheels) {
    Fail "No jain_commods wheel in wheels/. Copy one from ..\eu_dashboard_power\wheels\ (the server cannot download it)."
}

Write-Host "============================================="
Write-Host "  DEPLOY OPTIONS STRUCTURE LAB"
Write-Host "  Server: ${ServerHost}  port ${AppPort}"
Write-Host "  Wheel:  $($wheels[-1].Name)"
Write-Host "============================================="
Write-Host ""

# -----------------------------------------------------------------------------
# Step 1: Tests
# -----------------------------------------------------------------------------
if ($SkipTests) {
    Write-Host "[1/5] Skipping tests (-SkipTests)"
} else {
    Write-Host "[1/5] Running backend tests..."
    if (-not (Test-Path $Python)) { Fail "corelib python not found at $Python (use -SkipTests to skip)." }
    Push-Location backend
    & $Python -m pytest tests -q
    $code = $LASTEXITCODE
    Pop-Location
    if ($code -ne 0) { Fail "Backend tests failed." }
}
Write-Host ""

# -----------------------------------------------------------------------------
# Step 2: Pack (the image runs npm run build)
# -----------------------------------------------------------------------------
Write-Host "[2/4] Packing release..."
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$TarName = "options_lab_${Stamp}.tgz"
$ScriptName = "options_lab_${Stamp}.sh"
$LocalTar = Join-Path $env:TEMP $TarName
$LocalScript = Join-Path $env:TEMP $ScriptName

tar.exe -czf $LocalTar `
    --exclude "__pycache__" --exclude "*.pyc" --exclude ".pytest_cache" --exclude "*.egg-info" `
    --exclude "backend/cache" --exclude "backend/.env" --exclude "backend/tests" `
    --exclude "frontend/node_modules" --exclude "frontend/dist" `
    Dockerfile .dockerignore backend frontend deploy/production.yaml deploy/prod.env.example wheels
if ($LASTEXITCODE -ne 0) { Fail "tar failed." }
Write-Host ("  {0} ({1:N1} MB)" -f $TarName, ((Get-Item $LocalTar).Length / 1MB))
Write-Host ""

# -----------------------------------------------------------------------------
# Step 4: Upload, build and restart on server
# -----------------------------------------------------------------------------
$BuildFlag = ""
if ($NoCache) { $BuildFlag = "--no-cache" }

# Literal here-string so bash syntax is never parsed by PowerShell.
$RemoteScript = @'
#!/bin/bash
set -eo pipefail
export PATH=$HOME/.local/bin:$PATH
APP=$HOME/__REPO_DIR__
NEW=$APP.new
COMPOSE="docker-compose -p __PROJECT__ -f __COMPOSE_FILE__"

echo Unpacking release...
rm -rf "$NEW"
mkdir -p "$NEW"
tar -xzf /tmp/__TAR_NAME__ -C "$NEW"
if [ -f "$APP/deploy/prod.env" ]; then
  cp -p "$APP/deploy/prod.env" "$NEW/deploy/prod.env"
fi
cd "$NEW"

ENV_ARG=
if [ -f deploy/prod.env ]; then
  ENV_ARG=--env-file=deploy/prod.env
fi

if ss -ltn | awk '{print $4}' | grep -qE ":__APP_PORT__$"; then
  if ! docker ps --format '{{.Names}}' | grep -qx __SERVICE_NAME__; then
    echo ERROR port __APP_PORT__ is already used by something other than __SERVICE_NAME__.
    ss -ltnp 2>/dev/null | grep ":__APP_PORT__ " || true
    exit 4
  fi
fi

echo
echo Building image...
$COMPOSE $ENV_ARG build __BUILD_FLAG__ __SERVICE_NAME__ 2>&1 | tail -40

echo
echo Swapping release...
rm -rf "$APP.prev"
if [ -d "$APP" ]; then mv "$APP" "$APP.prev"; fi
mv "$NEW" "$APP"
cd "$APP"

echo Restarting service...
$COMPOSE $ENV_ARG up -d --force-recreate __SERVICE_NAME__

echo
echo Container status:
$COMPOSE $ENV_ARG ps __SERVICE_NAME__

echo
echo Health check:
for i in $(seq 1 20); do
  if curl -fsS http://127.0.0.1:__APP_PORT__/api/health >/dev/null 2>&1; then
    echo "alive after $((i * 3)) seconds"
    curl -fsS http://127.0.0.1:__APP_PORT__/api/health
    echo
    exit 0
  fi
  sleep 3
done
echo ERROR container did not respond on port __APP_PORT__
$COMPOSE $ENV_ARG logs --tail=60 __SERVICE_NAME__
exit 1
'@
$RemoteScript = $RemoteScript.Replace("`r`n", "`n").
    Replace('__REPO_DIR__', $RepoDir).
    Replace('__PROJECT__', $Project).
    Replace('__COMPOSE_FILE__', $ComposeFile).
    Replace('__TAR_NAME__', $TarName).
    Replace('__BUILD_FLAG__', $BuildFlag).
    Replace('__SERVICE_NAME__', $ServiceName).
    Replace('__APP_PORT__', $AppPort)
[IO.File]::WriteAllText($LocalScript, $RemoteScript, (New-Object Text.UTF8Encoding $false))

Write-Host "[3/4] Uploading to ${ServerHost}..."
scp $LocalTar $LocalScript "${ServerUser}@${ServerHost}:/tmp/"
$code = $LASTEXITCODE
Remove-Item $LocalTar, $LocalScript -ErrorAction SilentlyContinue
if ($code -ne 0) { Fail "scp failed." }

Write-Host "  Building and restarting on server (you will be prompted for sudo password)..."
ssh -t "${ServerUser}@${ServerHost}" "chmod 644 /tmp/$TarName /tmp/$ScriptName; sudo -iu ${ServiceUser} bash /tmp/$ScriptName; _CODE=`$?; rm -f /tmp/$TarName /tmp/$ScriptName; exit `$_CODE"
$DeployExit = $LASTEXITCODE
if ($DeployExit -ne 0) { Fail "Server deploy failed (exit ${DeployExit}). The previous release is still running if the build failed." }

# -----------------------------------------------------------------------------
# Step 5: Report
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "[4/4] Deploy complete!" -ForegroundColor Green
Write-Host "  App: http://${ServerHost}:${AppPort}/"
Write-Host ""

if ($Logs) {
    Write-Host "Tailing logs (Ctrl+C to stop)..."
    ssh -t "${ServerUser}@${ServerHost}" "sudo -iu ${ServiceUser} bash -c 'cd ~/${RepoDir} && export PATH=`$HOME/.local/bin:`$PATH && docker-compose -p ${Project} -f ${ComposeFile} logs -f --tail=100 ${ServiceName}'"
}
