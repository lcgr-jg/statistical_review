from datetime import date

import numpy as np
import pytest
from scipy.special import ndtr

from app.market import discovery
from app.quant.black76 import strike_from_call_delta


def test_ticker_and_option_parsing():
    assert discovery._ticker("FJSA<cmdty>") == "FJSA Comdty"
    assert discovery._ticker("SX5E<index>") == "SX5E Index"
    assert discovery._parse_option("FJSX6C   76 Comdty") == ("C", 76.0)
    assert discovery._parse_option("FJSX6P   28.5 Comdty") == ("P", 28.5)
    assert discovery._parse_option("FJSX6 Comdty") is None
    assert discovery._label("TTF NAT GAS F     Nov26", "x") == "Nov26"


def test_smile_recovers_flat_vol(monkeypatch):
    discovery._memo.clear()
    as_of = date(2026, 10, 7)
    expiry = date(2026, 12, 6)
    T = (expiry - as_of).days / 365.25
    forward, sigma = 80.0, 0.6
    strikes = sorted({round(float(strike_from_call_delta(forward, sigma, T, d)), 1) for d in
                      [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95]})
    tickers = [f"XYZ6{cp}   {k:g} Comdty" for k in strikes for cp in "CP"]

    monkeypatch.setattr(discovery, "_option_chains", lambda contracts: {contracts[0]: tickers})

    def fake_refdata(securities, fields):
        if securities == ["XYZ6 Comdty"]:
            return {"XYZ6 Comdty": {"NAME": "TEST Dec26", "PX_LAST": forward, "FUT_CONT_SIZE": 744.0}}
        return {
            t: {"IVOL_MID": sigma * 100, "OPT_EXPIRE_DT": expiry.isoformat(), "OPT_UNDL_PX": forward}
            for t in securities
        }

    monkeypatch.setattr(discovery, "_refdata", fake_refdata)
    out = discovery.smile("XYZ6 Comdty", as_of=as_of)
    assert out["expiry"] == expiry.isoformat()
    assert out["label"] == "Dec26"
    assert out["multiplier"] == 744.0
    for name, vol in out["pillars"].items():
        assert vol == pytest.approx(sigma, abs=1e-4), name
    assert out["fit"]["model"] == "sabr" and abs(out["fit"]["rho"]) < 0.05
    assert all(p["strike"] >= forward for p in out["points"] if p["cp"] == "C")
    assert all(p["strike"] < forward for p in out["points"] if p["cp"] == "P")


def test_implied_vol_round_trips():
    from app.quant.black76 import implied_vol, price

    strikes = np.array([60.0, 80.0, 100.0])
    cp = np.array([-1, 1, 1])
    premiums = price(80.0, strikes, 0.45, 0.2, 0.0, cp)
    assert implied_vol(80.0, strikes, 0.2, premiums, cp) == pytest.approx([0.45] * 3, abs=1e-8)
    assert np.isnan(implied_vol(80.0, 60.0, 0.2, 20.0, 1))


def test_settlement_smile_uses_settle_prices(monkeypatch):
    from app.quant.black76 import price

    discovery._memo.clear()
    as_of, settle_day, expiry = date(2026, 10, 8), date(2026, 10, 7), date(2026, 12, 9)
    settle_fwd, live, sigma = 85.0, 87.0, 0.5
    T = (expiry - settle_day).days / 365.25
    strikes = [50, 60, 70, 75, 80, 85, 90, 95, 100, 110, 120, 140]
    tickers = [f"XYZZ6{cp}   {k} Comdty" for k in strikes for cp in "CP"]
    monkeypatch.setattr(discovery, "_option_chains", lambda contracts: {contracts[0]: tickers})

    def fake_refdata(securities, fields):
        if "NAME" in fields:
            return {"XYZZ6 Comdty": {"NAME": "TEST Dec26", "PX_LAST": live, "PX_SETTLE": settle_fwd, "PX_SETTLE_LAST_DT": settle_day}}
        out = {}
        for t in securities:
            cp, k = discovery._parse_option(t)
            premium = float(price(settle_fwd, k, sigma, T, 0.0, 1 if cp == "C" else -1))
            out[t] = {"IVOL_MID": 99.0, "OPT_EXPIRE_DT": expiry, "OPT_UNDL_PX": live, "PX_SETTLE": premium}
        return out

    monkeypatch.setattr(discovery, "_refdata", fake_refdata)
    out = discovery.smile("XYZZ6 Comdty", as_of=as_of)
    assert out["vol_source"] == "settle"
    assert out["settle"] == {"date": "2026-10-07", "forward": settle_fwd}
    assert out["forward"] == live
    assert out["pillars"]["50D"] == pytest.approx(sigma, abs=1e-4)
    assert out["arbitrage"]["ok"]
    assert all(p["price"] > 0 for p in out["points"])
    assert out["parity"]["forward"] == pytest.approx(settle_fwd, abs=1e-9)
    assert out["parity"]["break"] is False and out["parity"]["n_pairs"] == 6
    assert discovery.smile("XYZZ6 Comdty", as_of=as_of, source="mid")["pillars"]["50D"] == pytest.approx(0.99, abs=1e-4)


def test_settlement_smile_matches_the_options_settlement_day(monkeypatch):
    """Futures settle before options: the future shows Monday's settlement while every option still has
    Friday's. Vols must be implied against Friday's futures settlement, not Monday's."""
    import pandas as pd

    from app.quant.black76 import price

    discovery._memo.clear()
    as_of, option_day, expiry = date(2026, 10, 12), date(2026, 10, 9), date(2026, 11, 26)
    friday_fwd, monday_fwd, sigma = 81.346, 84.193, 0.9
    T = (expiry - option_day).days / 365.25
    strikes = [40, 50, 60, 70, 75, 78, 80, 81, 82, 83, 84, 85, 86, 88, 90, 95, 100, 110, 125, 150]
    tickers = [f"XYZZ6{cp}   {k} Comdty" for k in strikes for cp in "CP"]
    monkeypatch.setattr(discovery, "_option_chains", lambda contracts: {contracts[0]: tickers})

    def fake_refdata(securities, fields):
        if "NAME" in fields:
            return {"XYZZ6 Comdty": {"NAME": "TEST Dec26", "PX_LAST": 84.1, "PX_SETTLE": monday_fwd, "PX_SETTLE_LAST_DT": as_of}}
        out = {}
        for t in securities:
            cp, k = discovery._parse_option(t)
            premium = float(price(friday_fwd, k, sigma, T, 0.0, 1 if cp == "C" else -1))
            out[t] = {"OPT_EXPIRE_DT": expiry, "OPT_UNDL_PX": 84.1, "PX_SETTLE": premium, "PX_SETTLE_LAST_DT": option_day}
        return out

    def fake_history(tickers, fields, start, end):
        index = pd.to_datetime(["2026-10-08", "2026-10-09"])
        return pd.DataFrame({"XYZZ6 Comdty_PX_SETTLE": [80.0, friday_fwd], "XYZZ6 Comdty_PX_LAST": [80.1, friday_fwd]}, index=index)

    monkeypatch.setattr(discovery, "_refdata", fake_refdata)
    monkeypatch.setattr(discovery, "history", fake_history)
    out = discovery.smile("XYZZ6 Comdty", as_of=as_of)
    assert out["settle"] == {"date": "2026-10-09", "forward": friday_fwd}
    assert out["pillars"]["50D"] == pytest.approx(sigma, abs=1e-3)
    assert out["pillars"]["25DC"] == pytest.approx(sigma, abs=1e-3)
    assert out["pillars"]["25DP"] == pytest.approx(sigma, abs=1e-3)
    assert out["parity"]["break"] is False
    assert any("Option settlements are from 2026-10-09" in w for w in out["warnings"])
    assert all(p["strike"] >= friday_fwd for p in out["points"] if p["cp"] == "C")

    # Without Friday's futures settlement, the mismatch is flagged rather than hidden.
    discovery._memo.clear()

    def no_history(*args):
        raise discovery.MarketDataError("down")

    monkeypatch.setattr(discovery, "history", no_history)
    out = discovery.smile("XYZZ6 Comdty", as_of=as_of)
    assert out["settle"]["date"] == "2026-10-12"
    assert any("unavailable" in w for w in out["warnings"])


def test_settlement_smile_drops_tick_floor_and_flags_parity(monkeypatch):
    from app.quant.black76 import price

    discovery._memo.clear()
    as_of, settle_day, expiry = date(2026, 10, 8), date(2026, 10, 7), date(2026, 11, 20)
    settle_fwd, sigma, tick = 30.0, 0.6, 0.005
    T = (expiry - settle_day).days / 365.25
    strikes = [12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 45, 60, 75, 90]
    tickers = [f"XYZX6{cp}   {k} Comdty" for k in strikes for cp in "CP"]
    monkeypatch.setattr(discovery, "_option_chains", lambda contracts: {contracts[0]: tickers})
    call_shift = {"value": 0.0}

    def fake_refdata(securities, fields):
        if "NAME" in fields:
            return {"XYZX6 Comdty": {"NAME": "TEST Nov26", "PX_LAST": settle_fwd, "PX_SETTLE": settle_fwd, "PX_SETTLE_LAST_DT": settle_day}}
        out = {}
        for t in securities:
            cp, k = discovery._parse_option(t)
            premium = float(price(settle_fwd, k, sigma, T, 0.0, 1 if cp == "C" else -1))
            # The exchange rounds to the tick and never settles below one tick.
            premium = max(round(premium / tick) * tick, tick) + (call_shift["value"] if cp == "C" else 0.0)
            out[t] = {"OPT_EXPIRE_DT": expiry, "OPT_UNDL_PX": settle_fwd, "PX_SETTLE": premium, "OPT_TICK_SIZE": tick}
        return out

    monkeypatch.setattr(discovery, "_refdata", fake_refdata)
    out = discovery.smile("XYZX6 Comdty", as_of=as_of)
    assert out["tick"] == tick
    floored = [p["strike"] for p in out["points"] if p["strike"] in (12, 15, 75, 90)]
    assert floored == [], "strikes settling at one tick must not enter the fit"
    assert any("minimum tick" in w for w in out["warnings"])
    assert out["pillars"]["50D"] == pytest.approx(sigma, abs=5e-3)
    assert out["parity"]["break"] is False

    discovery._memo.clear()
    call_shift["value"] = 0.2
    shifted = discovery.smile("XYZX6 Comdty", as_of=as_of)
    assert shifted["parity"]["break"] is True
    assert shifted["parity"]["diff"] == pytest.approx(0.2, abs=1e-9)
    assert any("parity" in w for w in shifted["warnings"])


def test_tick_floor_inference():
    assert discovery.tick_floor([0.5, 0.2, 0.01, 0.01, 0.01], None) == pytest.approx(0.01)
    assert discovery.tick_floor([0.5, 0.2, 0.03], None) is None
    assert discovery.tick_floor([0.5, 0.2, 0.03], 0.005) == pytest.approx(0.005)


def test_serial_options_on_one_future_stay_apart(monkeypatch):
    discovery._memo.clear()
    as_of = date(2026, 10, 8)
    forward = 86.0
    setup = {"XYZV6": (date(2026, 10, 21), 0.9), "XYZZ6": (date(2026, 12, 9), 0.3)}
    strikes = [60, 70, 80, 85, 90, 100, 110, 120]
    tickers = [f"{root}{cp}   {k} Comdty" for root in setup for k in strikes for cp in "CP"]
    monkeypatch.setattr(discovery, "_option_chains", lambda contracts: {c: tickers for c in contracts})

    def fake_refdata(securities, fields):
        if "NAME" in fields:
            return {"XYZZ6 Comdty": {"NAME": "TEST Dec26", "PX_LAST": forward}}
        out = {}
        for t in securities:
            expiry, sigma = setup[t.split("C")[0].split("P")[0]]
            out[t] = {"IVOL_MID": sigma * 100, "OPT_EXPIRE_DT": expiry, "OPT_UNDL_PX": forward}
        return out

    monkeypatch.setattr(discovery, "_refdata", fake_refdata)
    monkeypatch.setattr(discovery, "_future_chain", lambda product: ["XYZZ6 Comdty"])
    main = discovery.smile("XYZZ6 Comdty", as_of=as_of)
    assert (main["series"], main["main"], main["expiry"]) == ("XYZZ6", True, "2026-12-09")
    assert main["pillars"]["50D"] == pytest.approx(0.3, abs=1e-4)
    serial = discovery.smile("XYZZ6 Comdty", as_of=as_of, series="XYZV6")
    assert (serial["label"], serial["expiry"]) == ("Oct26 on Dec26", "2026-10-21")
    assert serial["pillars"]["50D"] == pytest.approx(0.9, abs=1e-4)
    assert [r["series"] for r in discovery.expiries("X", serials=True)["contracts"]] == ["XYZV6", "XYZZ6"]
    assert [r["option_expiry"] for r in discovery.expiries("X")["contracts"]] == ["2026-12-09"]


def test_prime_smiles_batches_a_curve(monkeypatch):
    discovery._memo.clear()
    as_of, expiry = date(2026, 10, 7), date(2026, 12, 6)
    forward, sigma = 80.0, 0.6
    strikes = [40, 50, 60, 70, 75, 80, 85, 90, 100, 120, 140]
    chains = {c: [f"{c.split()[0]}{cp}   {k} Comdty" for k in strikes for cp in "CP"] for c in ("XYZF7 Comdty", "XYZG7 Comdty", "XYZH7 Comdty")}
    monkeypatch.setattr(discovery, "_option_chains", lambda contracts: {c: chains[c] for c in contracts})
    calls = []

    def fake_refdata(securities, fields):
        calls.append(list(securities))
        return {
            s: {"NAME": f"TEST {s[3:5]}", "PX_LAST": forward} if s in chains else {"IVOL_MID": sigma * 100, "OPT_EXPIRE_DT": expiry.isoformat(), "OPT_UNDL_PX": forward}
            for s in securities
        }

    monkeypatch.setattr(discovery, "_refdata", fake_refdata)
    assert discovery.prime_smiles(list(chains)) == 3
    # One request for the three futures, one for every option on all three.
    assert len(calls) == 2 and sorted(calls[0]) == sorted(chains)
    calls.clear()
    fits = [discovery.smile(c, as_of=as_of) for c in chains]
    assert calls == [], "smile must read what prime_smiles fetched"
    assert all(f["pillars"]["50D"] == pytest.approx(sigma, abs=1e-4) for f in fits)
    assert discovery.prime_smiles(list(chains)) == 0, "a fresh memo is not refetched"


def test_fit_ignores_stale_wing_quote():
    forward, T = 76.0, 50 / 365.25
    true = lambda z: 0.90 + 0.06 * z + 0.015 * z * z
    atm = true(0.0)
    scale = atm * T**0.5
    points = []
    for i, z in enumerate([x / 4 for x in range(-8, 9)]):
        strike = forward * float(np.exp(z * scale))
        vol = true(z) - (0.12 if i == 13 else 0.0)
        d1 = (np.log(forward / strike) + 0.5 * vol * vol * T) / (vol * T**0.5)
        points.append({"strike": strike, "vol": vol, "call_delta": float(ndtr(d1)), "cp": "C" if z >= 0 else "P"})
    pillars, curve, warnings, fit = discovery.fit_smile(points, forward, T)
    assert not points[13]["used"]
    assert abs(points[13]["resid"]) > 0.08
    in_range = sum(0.03 <= p["call_delta"] <= 0.97 for p in points)
    assert sum(p["used"] for p in points) == in_range - 1
    for name, delta in [("50D", 0.5), ("25DC", 0.25), ("25DP", 0.75)]:
        strike = float(strike_from_call_delta(forward, pillars[name], T, delta))
        assert pillars[name] == pytest.approx(true(np.log(strike / forward) / scale), abs=0.005), name
    assert curve and any("left out" in w for w in warnings)
    assert fit["model"] == "sabr" and fit["rmse_used"] < 0.004
    assert fit["density"]["ok"]
    assert fit["rr25"] == pytest.approx(pillars["25DC"] - pillars["25DP"])
    assert any(c["extrapolated"] for c in curve) and any(not c["extrapolated"] for c in curve)


def test_sabr_round_trip_and_atm_pin():
    from app.quant import sabr

    F, T = 30.0, 60 / 365.25
    true = {"alpha": 0.9, "beta": 0.5, "rho": -0.3, "nu": 1.8}
    K = F * np.exp(np.linspace(-0.6, 0.6, 15))
    vols = sabr.hagan_vol(F, K, T, **true)
    atm = float(sabr.hagan_vol(F, F, T, **true))
    fit = sabr.calibrate(K, vols, F, T, atm, beta=0.5)
    assert fit["rho"] == pytest.approx(true["rho"], abs=1e-3)
    assert fit["nu"] == pytest.approx(true["nu"], abs=1e-2)
    assert fit["alpha"] == pytest.approx(true["alpha"], rel=1e-3)
    assert fit["rmse"] < 1e-5
    # Alpha is pinned so the fitted ATM is the ATM asked for, whatever rho and nu came out.
    assert float(sabr.vol(fit, F, F, T)) == pytest.approx(atm, abs=1e-9)
    assert sabr.density(F, T, K, vols)["ok"]
    # A steep enough wing goes arbitrageable: vol rising faster than the Lee bound.
    bad = vols + np.where(K < F, 0.9 * (np.log(F / K)) ** 2, 0.0)
    assert not sabr.density(F, T, K, bad)["ok"]


def test_static_checks_on_settlement_prices():
    from app.quant import sabr
    from app.quant.black76 import price

    F, T, tick = 30.0, 45 / 365.25, 0.005
    K = np.arange(20.0, 41.0, 1.0)
    calls = np.round(price(F, K, 0.55, T, 0.0, 1.0) / tick) * tick
    assert sabr.static_checks(K, calls, tick)["ok"], "tick rounding alone must not flag"
    calls[10] -= 0.1  # one call marked too low makes the flies it is a wing of negative
    out = sabr.static_checks(K, calls, tick)
    assert set(out["butterfly"]) == {29.0, 31.0}
    calls[3] = calls[2] + 0.05  # a call that rises with strike
    assert 23.0 in sabr.static_checks(K, calls, tick)["vertical"]
