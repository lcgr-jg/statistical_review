import time
import types

import pytest

blpapi = pytest.importorskip("blpapi")

from app.market import bbg


class Msg:
    def __init__(self, cid, body, kind="Response"):
        self._cid, self._body, self._kind = cid, body, kind

    def correlationIds(self):
        return [self._cid] if self._cid is not None else []

    def toPy(self):
        return self._body

    def messageType(self):
        return self._kind


class Event:
    def __init__(self, kind, msgs=()):
        self._kind, self._msgs = kind, list(msgs)

    def eventType(self):
        return self._kind

    def __iter__(self):
        return iter(self._msgs)


class FakeSession:
    """Plays back the events ``script(cid)`` returns for each request, then times out."""

    def __init__(self, script):
        self.script = script
        self.queue: list[Event] = []
        self.cancelled = []
        self.stopped = False

    def openService(self, name):
        return True

    def getService(self, name):
        return self

    def createRequest(self, operation):
        return types.SimpleNamespace(fromPy=lambda payload: None)

    def sendRequest(self, request, correlationId):
        self.queue = list(self.script(correlationId))

    def nextEvent(self, ms):
        if self.queue:
            return self.queue.pop(0)
        time.sleep(ms / 1000)
        return Event(blpapi.Event.TIMEOUT)

    def cancel(self, cid):
        self.cancelled.append(cid)

    def stopAsync(self):
        self.stopped = True


@pytest.fixture
def session(monkeypatch):
    def install(script):
        fake = FakeSession(script)
        monkeypatch.setattr(bbg, "_query", types.SimpleNamespace(session=fake))
        monkeypatch.setattr(bbg, "_timeouts", 0)
        bbg._open_services.add(bbg.REFDATA)
        bbg._memo.clear()
        return fake

    return install


def test_reply_to_another_request_is_ignored(session):
    stale = blpapi.CorrelationId(10**9)
    session(
        lambda cid: [
            Event(blpapi.Event.RESPONSE, [Msg(stale, {"securityData": [{"security": "OLD", "fieldData": {"PX_LAST": 9.0}}]})]),
            Event(blpapi.Event.RESPONSE, [Msg(cid, {"securityData": [{"security": "A", "fieldData": {"PX_LAST": 1.5}}]})]),
        ]
    )
    frame = bbg.reference(["A"], ["PX_LAST"])
    assert list(frame.index) == ["A"] and frame.loc["A", "PX_LAST"] == 1.5


def test_failed_request_raises_instead_of_waiting(session):
    session(lambda cid: [Event(blpapi.Event.REQUEST_STATUS, [Msg(cid, {}, "RequestFailure")])])
    with pytest.raises(bbg.MarketDataError, match="failed"):
        bbg.request(bbg.REFDATA, "ReferenceDataRequest", {}, timeout=5)


def test_repeated_timeouts_reopen_the_session(session, monkeypatch):
    monkeypatch.setattr(bbg.settings, "bbg_reset_after_timeouts", 2)
    fake = session(lambda cid: [])
    for _ in range(2):
        with pytest.raises(bbg.MarketDataError, match="timed out"):
            bbg.request(bbg.REFDATA, "ReferenceDataRequest", {}, timeout=0.05)
    assert len(fake.cancelled) == 2
    assert fake.stopped and bbg._query is None


def test_waiting_for_a_held_session_is_bounded(session, monkeypatch):
    session(lambda cid: [])
    monkeypatch.setattr(bbg.settings, "bbg_lock_wait_seconds", 0.05)
    assert bbg._lock.acquire(timeout=1)
    try:
        started = time.monotonic()
        with pytest.raises(bbg.MarketDataError, match="busy"):
            bbg.request(bbg.REFDATA, "ReferenceDataRequest", {})
        assert time.monotonic() - started < 1
    finally:
        bbg._lock.release()


def test_history_is_framed_like_fetch_hist(session):
    from datetime import date, datetime

    def script(cid):
        a = {"securityData": {"security": "A", "fieldData": [{"date": date(2026, 1, 2), "PX_LAST": 1.0}, {"date": date(2026, 1, 5), "PX_LAST": 2.0}]}}
        b = {"securityData": {"security": "B", "fieldData": [{"date": date(2026, 1, 5), "PX_LAST": 7.0, "VOL": 3.0}]}}
        return [Event(blpapi.Event.PARTIAL_RESPONSE, [Msg(cid, a)]), Event(blpapi.Event.RESPONSE, [Msg(cid, b)])]

    session(script)
    frame = bbg._fetch_history(["A", "B"], ["PX_LAST", "VOL"], datetime(2026, 1, 1), datetime(2026, 1, 9))
    assert list(frame.columns) == ["A_PX_LAST", "A_VOL", "B_PX_LAST", "B_VOL"]
    assert frame.loc["2026-01-05", "B_PX_LAST"] == 7.0
    assert frame["A_VOL"].isna().all()
