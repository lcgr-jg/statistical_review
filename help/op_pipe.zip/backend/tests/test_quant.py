from __future__ import annotations

from datetime import date, timedelta

import numpy as np

from app.quant.black76 import greeks, price
from app.quant.montecarlo import black_reference, simulate
from app.quant.path_pnl import evaluate_path
from app.quant.regression import analyse, ols
from app.quant.smile import Smile
from app.quant.black76 import strike_from_call_delta
from app.quant.structures import expiry_payoff, prepare_slices, resolve_leg
from app.schemas import ExpirySliceIn, LegIn, MarketIn


def _market(forward=100.0, vol=0.20, days=365, rate=0.0, beta=0.0, pillars=None) -> MarketIn:
    as_of = date(2026, 1, 1)
    return MarketIn(
        as_of=as_of,
        rate=rate,
        multiplier=1.0,
        beta=beta,
        slices=[ExpirySliceIn(
            expiry=as_of + timedelta(days=days),
            forward=forward,
            pillars=pillars or {"50D": vol},
        )],
    )


def _call(strike=100.0) -> LegIn:
    return LegIn(call_put="C", qty=1, strike_mode="absolute", strike=strike)


def test_put_call_parity():
    df = np.exp(-0.03 * 1.0)
    call = price(110, 100, 0.2, 1.0, 0.03, 1)
    put = price(110, 100, 0.2, 1.0, 0.03, -1)
    assert abs(float(call - put - df * 10)) < 1e-8


def test_greeks_match_finite_differences():
    base = dict(F=100.0, K=100.0, sigma=0.22, T=0.8, r=0.02, cp=1.0)
    g = greeks(**base)
    h_f = 1e-3
    h_s = 1e-4
    h_t = 1e-4

    def p(**kw):
        args = {**base, **kw}
        return float(price(args["F"], args["K"], args["sigma"], args["T"], args["r"], args["cp"]))

    def d(**kw):
        args = {**base, **kw}
        return float(greeks(**args)["delta"])

    def v(**kw):
        args = {**base, **kw}
        return float(greeks(**args)["vega"])

    delta_fd = (p(F=base["F"] + h_f) - p(F=base["F"] - h_f)) / (2 * h_f)
    gamma_fd = (p(F=base["F"] + h_f) - 2 * p() + p(F=base["F"] - h_f)) / h_f**2
    vega_fd = (p(sigma=base["sigma"] + h_s) - p(sigma=base["sigma"] - h_s)) / (2 * h_s)
    theta_fd = -(p(T=base["T"] + h_t) - p(T=base["T"] - h_t)) / (2 * h_t)
    vanna_fd = (d(sigma=base["sigma"] + h_s) - d(sigma=base["sigma"] - h_s)) / (2 * h_s)
    volga_fd = (v(sigma=base["sigma"] + h_s) - v(sigma=base["sigma"] - h_s)) / (2 * h_s)
    charm_fd = -(d(T=base["T"] + h_t) - d(T=base["T"] - h_t)) / (2 * h_t)

    assert abs(float(g["delta"]) - delta_fd) < 1e-5
    assert abs(float(g["gamma"]) - gamma_fd) < 1e-5
    assert abs(float(g["vega"]) - vega_fd) < 1e-4
    assert abs(float(g["theta"]) - theta_fd) < 1e-3
    assert abs(float(g["vanna"]) - vanna_fd) < 1e-3
    assert abs(float(g["volga"]) - volga_fd) < 1e-2
    assert abs(float(g["charm"]) - charm_fd) < 1e-3


def test_smile_delta_roundtrip():
    pillars = {"10DC": 0.30, "25DC": 0.24, "50D": 0.20, "25DP": 0.26, "10DP": 0.34}
    smile = Smile.from_pillars(100, 1.0, 0.0, pillars)
    strike = float(strike_from_call_delta(100, 0.24, 1.0, 0.25))
    vol = float(smile.vol_at_strike(strike, 100, 0.20, 1.0, "delta"))
    assert abs(vol - 0.24) < 1e-3


def test_call_spread_payoff_at_expiry():
    market = _market()
    legs = [_call(100), LegIn(call_put="C", qty=-1, strike_mode="absolute", strike=110)]
    sl, T, smile = prepare_slices(market, market.as_of)[0]
    resolved = [resolve_leg(leg, sl, smile, T) for leg in legs]
    pnl = expiry_payoff(resolved, np.array([100.0, 105.0, 120.0]), 0.0, 0.0, T, 1.0)
    assert abs(pnl[0]) < 1e-8
    assert abs(pnl[1] - 5) < 1e-8
    assert abs(pnl[2] - 10) < 1e-8


def test_flat_path_decays_by_theta_and_attribution_sums():
    market = _market(days=90)
    T = (market.slices[0].expiry - market.as_of).days / 365.25
    result = evaluate_path(
        market,
        [_call(100)],
        "sticky-delta",
        [
            {"t": 0.0, "forward": 100.0, "atm_vol": 0.20},
            {"t": T, "forward": 100.0, "atm_vol": 0.20},
        ],
        "none",
        "path",
        market.as_of,
    )
    attr = result["attribution"]
    assert abs(sum(attr.values()) - result["pnl"]) < 1e-6
    for key in ("delta", "gamma", "vega", "vanna", "volga"):
        assert abs(attr[key]) < 1e-6
    assert result["pnl"] < 0
    assert abs(attr["theta"] - result["pnl"]) / abs(result["pnl"]) < 0.05


def test_monte_carlo_constant_vol_matches_black():
    market = _market(days=365, rate=0.0)
    legs = [_call(100)]
    result = simulate(
        market, legs, "sticky-delta", market.as_of,
        n_paths=8000, n_steps=8, kappa=0.0, xi=0.0, rho=0.0,
        sigma_bar=None, seed=11, n_overlay=4, hedge=False,
    )
    black = black_reference(market, legs, market.as_of)
    assert abs(result["discounted_payoff_mean"] - black) < 0.6
    assert abs(result["premium"] - black) < 1e-6


def test_regression_recovers_beta():
    rng = np.random.default_rng(3)
    x = rng.normal(size=400)
    y = -0.2 + 1.35 * x + rng.normal(scale=0.02, size=400)
    fit = ols(y, x)
    assert abs(fit["slope"] - 1.35) < 0.05
    assert fit["r2"] > 0.95

    futures = 100 * np.exp(np.cumsum(rng.normal(scale=0.01, size=300)))
    logf = np.log(futures)
    dlog = np.diff(logf, prepend=np.nan)
    beta = -0.4
    dv = beta * dlog + rng.normal(scale=0.0005, size=300)
    dv[0] = 0.0
    vol = 0.4 + np.cumsum(np.nan_to_num(dv))
    stats = analyse(futures, vol, None, window=40)
    assert abs(stats["changes"]["slope"] - beta) < 0.05
    assert stats["beta"] == stats["changes"]["slope"]
