from datetime import date, timedelta

import numpy as np
import pandas as pd
import pytest

from app import journal
from app.quant.backtest import run_backtest
from app.quant.regimes import REGIMES, regime_of
from app.quant.var import book_var
from app.schemas import ExpirySliceIn, LegIn, MarketIn
from test_history_features import STRADDLE, market, synthetic_history

AS_OF = date(2026, 10, 6)
PILLARS = {"10DP": 0.4, "25DP": 0.37, "50D": 0.35, "25DC": 0.36, "10DC": 0.38}


def strip_market() -> MarketIn:
    slices = [ExpirySliceIn(expiry=AS_OF + timedelta(days=d), forward=f, pillars=PILLARS) for d, f in ((45, 50.0), (75, 52.0), (105, 51.0))]
    return MarketIn(as_of=AS_OF, rate=0.0, multiplier=10.0, slices=slices)


def strip_legs(strike: float = 51.0) -> list[LegIn]:
    return [LegIn(call_put="C", qty=1, strike_mode="absolute", strike=strike, expiry=sl.expiry) for sl in strip_market().slices]


def test_regime_windows_do_not_overlap():
    spans = sorted((r["start"], r["end"]) for r in REGIMES)
    assert all(a[1] < b[0] for a, b in zip(spans, spans[1:]))
    assert regime_of("2022-08-26") == "energy_crisis"
    assert regime_of("2020-03-16") == "covid"


def test_strip_backtest_holds_to_last_expiry_and_splits_by_regime():
    hist = synthetic_history()
    front = run_backtest(strip_market(), strip_legs(), "sticky-delta", hist, every=21)
    last = run_backtest(strip_market(), strip_legs(), "sticky-delta", hist, every=21, hold="last")
    assert front["settings"]["hold_days"] == 45
    assert last["settings"]["hold_days"] == 105
    for t in last["trades"]:
        assert (pd.Timestamp(t["exit"]) - pd.Timestamp(t["entry"])).days >= 105
        explained = t["delta_pnl"] + t["gamma_pnl"] + t["theta_pnl"] + t["vega_pnl"] + t["residual_pnl"]
        assert explained == pytest.approx(t["pnl"], abs=1e-6)
    # Each month settles on the first session on or after its own expiry: exercised into the
    # future if in the money (then marked on the path), worthless otherwise.
    index = hist.index
    path = hist["f1"].iloc[0] * np.exp(np.cumsum(np.nan_to_num(hist["ret"].to_numpy())))
    path = pd.Series(path, index=index)
    for t in last["trades"]:
        entry = pd.Timestamp(t["entry"])
        F0, F_exit = t["forward_entry"], t["forward_exit"]
        scale = F_exit / path[pd.Timestamp(t["exit"])]
        expected = 0.0
        for days, fwd in ((45, 50.0), (75, 52.0), (105, 51.0)):
            K = 51.0 / fwd * F0
            settle_day = index[index.searchsorted(entry + timedelta(days=days))]
            F_settle = path[settle_day] * scale
            expected += 10.0 * ((F_exit - K) if F_settle > K else 0.0)
        assert t["value_exit"] == pytest.approx(expected, abs=1e-6)
    regimes = last["regimes"]
    assert sum(r["n"] for r in regimes) == last["metrics"]["n"]
    assert sum(r["total"] or 0.0 for r in regimes) == pytest.approx(last["metrics"]["total"])
    assert next(r for r in regimes if r["id"] == "energy_crisis")["n"] > 0


def _position(pid: str, legs, size: float = 1.0, m: MarketIn | None = None) -> dict:
    return {"id": pid, "label": pid, "market": m or market(), "legs": legs, "contract": "XXXZ6 Comdty", "size": size}


def test_var_of_a_single_straddle():
    hist = synthetic_history()
    result = book_var([_position("straddle", STRADDLE)], {"XXXZ6 Comdty": hist}, "sticky-delta", horizon=1)
    v95, v99 = result["levels"]["95"], result["levels"]["99"]
    assert 0 < v95["var"] <= v99["var"]
    assert v95["es"] >= v95["var"]
    assert result["positions"][0]["es_contribution_95"] == pytest.approx(v95["es"])
    assert result["totals"]["vega_point"] > 0 and result["totals"]["theta_day"] < 0
    longer = book_var([_position("straddle", STRADDLE)], {"XXXZ6 Comdty": hist}, "sticky-delta", horizon=10)
    assert longer["levels"]["95"]["var"] > v95["var"]
    assert any(s["id"] == "energy_crisis" and s["n"] > 0 for s in result["stresses"])


def test_var_nets_offsetting_positions_and_contributions_add_up():
    hist = synthetic_history()
    histories = {"XXXZ6 Comdty": hist}
    flat = book_var([_position("long", STRADDLE), _position("short", STRADDLE, size=-1.0)], histories, "sticky-delta")
    assert flat["levels"]["95"]["var"] == pytest.approx(0.0, abs=1e-9)
    book = [_position("straddle", STRADDLE), _position("strip", strip_legs(), m=strip_market(), size=2.0)]
    result = book_var(book, histories, "sticky-delta", horizon=5)
    contributions = sum(p["es_contribution_95"] for p in result["positions"])
    assert contributions == pytest.approx(result["levels"]["95"]["es"])
    assert len(result["worst"]) == 10
    assert result["worst"][0]["pnl"] == pytest.approx(min(result["series"]["pnl"]))


def test_journal_routes_record_the_user(tmp_path, monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    from app.api.routes import router

    monkeypatch.setattr(journal, "PATH", tmp_path / "journal.json")
    app = FastAPI()
    app.include_router(router, prefix="/api")
    client = TestClient(app)
    who = {"X-User": "Ren%C3%A9e%20K"}
    entry = client.post("/api/journal", json={"kind": "trade", "label": "Win-27 C 60", "tags": ["winter"]}, headers=who).json()
    assert entry["author"] == "Renée K"
    client.patch(f"/api/journal/{entry['id']}", json={"status": "done"}, headers=who)
    assert client.post(f"/api/journal/{entry['id']}/comments", json={"text": ""}, headers=who).status_code == 400
    row = client.post(f"/api/journal/{entry['id']}/comments", json={"text": "rolled into Sum-28"}, headers=who).json()
    assert row["comments"][0]["author"] == "Renée K"
    assert client.delete(f"/api/journal/{entry['id']}", headers=who).json() == {"ok": True}
    events = client.get("/api/journal/audit").json()["events"]
    assert [e["action"] for e in events] == ["deleted", "commented", "changed", "created"]
    assert client.get("/api/journal").json()["entries"] == []
    assert client.get("/api/regimes").json()["regimes"][0]["id"] == "pre_covid"


def test_journal_audit_trail(tmp_path, monkeypatch):
    monkeypatch.setattr(journal, "PATH", tmp_path / "journal.json")
    entry = journal.add_entry({"kind": "trade", "label": "Q1-27 90 calls", "tags": "#Winter, strip winter"}, author="mk")
    assert entry["tags"] == ["winter", "strip"]
    journal.update_entry(entry["id"], {"status": "done", "price": 1.5, "id": "hijack"}, author="ab")
    journal.update_entry(entry["id"], {"status": "done"}, author="ab")
    journal.add_comment(entry["id"], "Filled at 1.50 with Marex", author="mk")
    with pytest.raises(ValueError):
        journal.add_comment(entry["id"], "  ", author="mk")
    row = journal.list_entries()[0]
    assert row["id"] == entry["id"]
    assert [c["text"] for c in row["comments"]] == ["Filled at 1.50 with Marex"]
    changes = [(e["action"], e.get("field"), e["author"]) for e in row["history"]]
    assert changes == [("created", None, "mk"), ("changed", "status", "ab"), ("changed", "price", "ab"), ("commented", None, "mk")]
    assert row["history"][1]["before"] == "open" and row["history"][1]["after"] == "done"
    assert journal.delete_entry(entry["id"], author="ab")
    assert journal.list_entries() == []
    kept = journal.list_entries(include_deleted=True)[0]
    assert kept["deleted"] and kept["history"][-1]["action"] == "deleted"
    assert journal.audit()[0]["action"] == "deleted"
    assert not journal.delete_entry(entry["id"])
