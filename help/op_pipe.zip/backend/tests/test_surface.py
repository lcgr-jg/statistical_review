import json
from datetime import date, timedelta

import pytest

from app.market import screener, vol_surface


def _fitted(contract: str, label: str, expiry: date, atm: float, rr: float, rho: float) -> dict:
    pillars = {"10DP": atm - rr + 0.04, "25DP": atm - rr / 2, "50D": atm, "25DC": atm + rr / 2, "10DC": atm + rr + 0.04}
    return {
        "contract": contract,
        "label": label,
        "expiry": expiry.isoformat(),
        "forward": 30.0,
        "pillars": pillars,
        "vol_source": "settle",
        "as_of": date.today().isoformat(),
        "fit": {"model": "sabr", "alpha": atm, "beta": 1.0, "rho": rho, "nu": 1.2, "rmse": 0.002, "rmse_used": 0.002, "rr25": rr, "bf25": 0.01, "density": {"ok": True, "vertical": [], "butterfly": []}},
        "parity": {"break": False, "diff": 0.01},
        "arbitrage": {"ok": True, "vertical": [], "butterfly": []},
        "points": [{"strike": 30.0, "cp": "C", "vol": atm, "call_delta": 0.5, "used": True, "resid": 0.001, "price": 1.0}],
        "curve": [{"strike": 30.0, "vol": atm, "call_delta": 0.5, "extrapolated": False}],
        "warnings": [],
        "main": True,
    }


def test_surface_rows_and_snapshot(monkeypatch, tmp_path):
    monkeypatch.setattr(screener, "SNAP_DIR", tmp_path / "smiles")
    today = date.today()
    listing = {"contracts": [{"contract": "XYZX6 Comdty", "label": "Nov26", "option_expiry": (today + timedelta(days=30)).isoformat()}, {"contract": "XYZZ6 Comdty", "label": "Dec26", "option_expiry": (today + timedelta(days=60)).isoformat()}], "warning": None}
    monkeypatch.setattr(vol_surface, "expiries", lambda product, limit: listing)
    fits = {
        "XYZX6 Comdty": _fitted("XYZX6 Comdty", "Nov26", today + timedelta(days=30), 0.6, 0.02, -0.1),
        "XYZZ6 Comdty": _fitted("XYZZ6 Comdty", "Dec26", today + timedelta(days=60), 0.55, 0.03, -0.2),
    }
    monkeypatch.setattr(vol_surface, "smile", lambda contract, source="settle": fits[contract])
    primed = []
    monkeypatch.setattr(vol_surface, "prime_smiles", lambda contracts, source: primed.append((contracts, source)))
    out = vol_surface.surface("XYZA Comdty", 12)
    assert primed == [(["XYZX6 Comdty", "XYZZ6 Comdty"], "settle")]
    assert [r["label"] for r in out["rows"]] == ["Nov26", "Dec26"]
    row = out["rows"][0]
    assert row["days"] == 30 and row["rho"] == -0.1 and row["rr25"] == pytest.approx(0.02)
    assert row["density_ok"] and row["arbitrage_ok"] and row["parity_break"] is False
    stored = json.loads((tmp_path / "smiles" / f"{today.isoformat()}.json").read_text())
    assert set(stored) == set(fits)
    assert stored["XYZZ6 Comdty"]["fit"]["rho"] == -0.2


def test_surface_history_by_contract_and_rank(monkeypatch, tmp_path):
    snap = tmp_path / "smiles"
    snap.mkdir()
    monkeypatch.setattr(screener, "SNAP_DIR", snap)
    monkeypatch.setattr(vol_surface, "SNAP_DIR", snap)
    nov, dec = date(2026, 11, 20), date(2026, 12, 18)
    days = [date(2026, 11, 10) + timedelta(days=i) for i in range(12)]
    for i, day in enumerate(days):
        data = {}
        if day <= nov:
            data["XYZX6 Comdty"] = _fitted("XYZX6 Comdty", "Nov26", nov, 0.6 + 0.01 * i, 0.02, -0.1 - 0.01 * i)
        data["XYZZ6 Comdty"] = _fitted("XYZZ6 Comdty", "Dec26", dec, 0.5, 0.03, -0.2)
        if i == 0:
            # An old snapshot without a fit: pillars only.
            data["XYZZ6 Comdty"] = {k: v for k, v in data["XYZZ6 Comdty"].items() if k in ("pillars", "forward", "expiry")}
        (snap / f"{day.isoformat()}.json").write_text(json.dumps(data))

    out = vol_surface.surface_history(None, ranks=2)
    assert out["days"] == 12
    nov_series = out["by_contract"]["XYZX6 Comdty"]
    assert len(nov_series["dates"]) == 11  # stored up to and including expiry day
    assert nov_series["stats"]["rho"]["current"] == pytest.approx(-0.2)
    assert nov_series["stats"]["rho"]["z"] < -1
    dec_series = out["by_contract"]["XYZZ6 Comdty"]
    assert dec_series["series"]["rho"][0] is None and dec_series["series"]["rr25"][0] == pytest.approx(0.03)
    # M+1 is Nov while Nov is alive, then Dec.
    m1 = out["by_rank"]["M+1"]
    assert m1["contracts"][0] == "XYZX6 Comdty" and m1["contracts"][-1] == "XYZZ6 Comdty"
    assert len(m1["dates"]) == 12
    m2 = out["by_rank"]["M+2"]
    assert all(c == "XYZZ6 Comdty" for c in m2["contracts"]) and len(m2["dates"]) == 11
    only = vol_surface.surface_history(["XYZZ6 Comdty"], ranks=1)
    assert list(only["by_contract"]) == ["XYZZ6 Comdty"]
