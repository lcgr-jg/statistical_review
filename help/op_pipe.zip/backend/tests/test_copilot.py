from __future__ import annotations

import json
from datetime import date, timedelta

from app.copilot.agent import proposals_from_text
from app.copilot.tools import ToolContext, verify_proposals
from app.quant.structures import summarise
from app.schemas import ExpirySliceIn, LegIn, MarketIn


def _market() -> MarketIn:
    as_of = date(2026, 1, 1)
    return MarketIn(
        as_of=as_of,
        slices=[
            ExpirySliceIn(expiry=as_of + timedelta(days=90), forward=40.0, pillars={"50D": 0.8, "25DC": 0.75, "25DP": 0.9}),
            ExpirySliceIn(expiry=as_of + timedelta(days=180), forward=41.0, pillars={"50D": 0.7}),
        ],
    )


def _ctx() -> ToolContext:
    return ToolContext(_market(), [], "sticky-delta", "FJSA Comdty", "FJSX6 Comdty")


def test_expand_and_price_match_summarise():
    ctx = _ctx()
    legs = ctx.expand_template({"name": "straddle"})["legs"]
    priced = ctx.price_structure({"legs": legs})
    direct = summarise(_market(), [LegIn.model_validate(leg) for leg in legs], "sticky-delta", False, _market().as_of)
    assert priced["premium"] == round(direct["premium"], 2)
    assert priced["pop"] is not None
    assert len(priced["legs"]) == 2


def test_scenarios_cover_spot_and_vol_shocks():
    ctx = _ctx()
    legs = ctx.expand_template({"name": "call"})["legs"]
    shocks = ctx.pnl_scenarios({"legs": legs})
    spots = {row["spot_pct"] for row in shocks["points"] if row["vol_pts"] == 0}
    assert spots == {-0.2, -0.1, 0.0, 0.1, 0.2}
    assert shocks["best"]["pnl"] >= shocks["worst"]["pnl"]


def test_monte_carlo_returns_terminal_stats():
    ctx = _ctx()
    legs = ctx.expand_template({"name": "put"})["legs"]
    result = ctx.monte_carlo({"legs": legs, "n_paths": 300, "rho": 0.3})
    assert set(result) >= {"mean", "p5", "p50", "p95", "var_95", "es_95", "prob_profit"}
    assert 0 <= result["prob_profit"] <= 1


def test_calendar_needs_the_second_expiry():
    ctx = _ctx()
    legs = ctx.expand_template({"name": "calendar"})["legs"]
    assert legs[0]["expiry"] != legs[1]["expiry"]
    assert "error" not in ctx.price_structure({"legs": legs})


def test_unknown_tool_is_an_error_payload():
    assert "error" in _ctx().call("place_order", {})


def test_verify_rejects_an_expiry_outside_the_market():
    cards = verify_proposals(_market(), "sticky-delta", [{
        "label": "Broken",
        "rationale": "wrong month",
        "legs": [{"call_put": "C", "qty": 1, "strike_mode": "delta", "strike": 0.5, "expiry": "2020-01-01"}],
    }])
    assert "error" in cards[0]
    assert "2020-01-01" in cards[0]["error"]


def test_verify_attaches_a_fresh_price():
    legs = _ctx().expand_template({"name": "strangle"})["legs"]
    cards = verify_proposals(_market(), "sticky-delta", [{
        "label": "Long wings",
        "rationale": "cheap convexity",
        "legs": legs,
    }])
    assert cards[0]["error"] if "error" in cards[0] else cards[0]["premium"] == _ctx().price_structure({"legs": legs})["premium"]
    assert cards[0]["label"] == "Long wings"


def test_verify_keeps_the_loadable_legs():
    legs = [
        {"call_put": "P", "qty": -1, "strike_mode": "delta", "strike": 0.7},
        {"call_put": "P", "qty": 1, "strike_mode": "delta", "strike": 0.9},
    ]
    card = verify_proposals(_market(), "sticky-delta", [{"label": "Bull put", "legs": legs}])[0]
    assert "error" not in card
    assert [leg["strike_mode"] for leg in card["legs"]] == ["delta", "delta"]
    assert [leg["strike"] for leg in card["legs"]] == [0.7, 0.9]
    assert len(card["resolved_legs"]) == 2
    reloaded = summarise(_market(), [LegIn.model_validate(leg) for leg in card["legs"]], "sticky-delta", False, _market().as_of)
    assert reloaded["premium"] == card["premium"] or abs(reloaded["premium"] - card["premium"]) < 0.01


def test_delta_strike_outside_zero_one_is_rejected():
    card = verify_proposals(_market(), "sticky-delta", [{
        "label": "Bad", "legs": [{"call_put": "P", "qty": 1, "strike_mode": "delta", "strike": 70.0}],
    }])[0]
    assert "between 0 and 1" in card["error"]


def test_expand_template_with_one_expiry():
    ctx = _ctx()
    ctx.market = ctx.market.model_copy(update={"slices": ctx.market.slices[:1]})
    result = json.loads(ctx.call("expand_template", {"name": "call_spread"}))
    assert "error" not in result
    assert len(result["legs"]) == 2
    calendar = json.loads(ctx.call("expand_template", {"name": "calendar"}))
    assert "two expiries" in calendar["error"]


def test_search_expands_strike_and_ratio_lists():
    result = _ctx().search_structures({
        "skeletons": [{
            "label": "call ratio",
            "legs": [
                {"call_put": "C", "qty": 1, "strike_mode": "delta", "strike": [0.5, 0.4]},
                {"call_put": "C", "qty": [-1, -2], "strike_mode": "delta", "strike": [0.25, 0.15]},
            ],
        }],
        "view": {"spot_pct": 0.1, "vol_pts": 0.0, "horizon": 0.5},
        "top": 10,
    })
    assert result["priced"] == 8
    assert len(result["best"]) == 8


def test_search_ranks_by_the_view():
    result = _ctx().search_structures({
        "skeletons": [
            {"label": "call", "legs": [{"call_put": "C", "qty": 1, "strike_mode": "delta", "strike": 0.5}]},
            {"label": "put", "legs": [{"call_put": "P", "qty": 1, "strike_mode": "delta", "strike": 0.5}]},
        ],
        "view": {"spot_pct": 0.2, "horizon": 0.3},
        "rank_by": "scenario_pnl",
    })
    assert result["best"][0]["label"] == "call"
    assert result["best"][0]["scenario_pnl"] > 0 > result["best"][1]["scenario_pnl"]


def test_search_respects_a_premium_budget():
    result = _ctx().search_structures({
        "skeletons": [{"label": "calls", "legs": [{"call_put": "C", "qty": 1, "strike_mode": "delta", "strike": [0.5, 0.25, 0.1]}]}],
        "view": {"spot_pct": 0.15},
        "max_premium": 0.0,
    })
    assert result["kept"] == 0


def test_search_caps_combinations():
    strikes = [0.05 * i for i in range(1, 19)]
    result = _ctx().search_structures({
        "skeletons": [{"legs": [
            {"call_put": "C", "qty": 1, "strike": strikes},
            {"call_put": "C", "qty": -1, "strike": strikes},
            {"call_put": "P", "qty": 1, "strike": strikes},
        ]}],
        "view": {"spot_pct": 0.1},
    })
    assert "error" in result


def test_proposals_come_from_the_fenced_block():
    text = 'I priced three.\n```json\n{"proposals": [{"label": "A", "rationale": "fits", "legs": []}]}\n```'
    found = proposals_from_text(text)
    assert found[0]["label"] == "A"
    assert proposals_from_text("no structure here") == []
