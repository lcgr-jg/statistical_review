import threading
import time

from app.market import warm


def test_cached_builds_once_and_stamps(monkeypatch):
    monkeypatch.setattr(warm, "_results", {})
    calls = []

    def build():
        calls.append(1)
        return {"rows": [1, 2]}

    first = warm.cached(("k",), 60, build)
    second = warm.cached(("k",), 60, build)
    assert calls == [1] and first is second
    assert first["rows"] == [1, 2] and first["computed_at"]
    warm.cached(("k",), 60, build, refresh=True)
    assert len(calls) == 2


def test_cached_expires(monkeypatch):
    monkeypatch.setattr(warm, "_results", {})
    calls = []
    warm.cached(("k",), 0.01, lambda: calls.append(1) or {})
    time.sleep(0.02)
    warm.cached(("k",), 0.01, lambda: calls.append(1) or {})
    assert len(calls) == 2


def test_concurrent_callers_share_one_build(monkeypatch):
    monkeypatch.setattr(warm, "_results", {})
    calls = []

    def slow():
        calls.append(1)
        time.sleep(0.2)
        return {"ok": True}

    out = []
    threads = [threading.Thread(target=lambda: out.append(warm.cached(("slow",), 60, slow))) for _ in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(calls) == 1 and len(out) == 5 and all(o is out[0] for o in out)
