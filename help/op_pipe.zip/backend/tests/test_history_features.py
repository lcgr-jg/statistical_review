from datetime import date, timedelta

import numpy as np
import pandas as pd
import pytest

from app import alerts, journal
from app.copilot.quotes import month_code, resolve_contract
from app.market.generic import build_continuous, generic_root, iv_at
from app.quant.backtest import breakeven_analysis, run_backtest, seasonality, skew_slope
from app.schemas import ExpirySliceIn, LegIn, MarketIn


def synthetic_history(days: int = 900, seed: int = 3) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    index = pd.bdate_range("2022-01-03", periods=days)
    f1 = pd.Series(50.0 * np.exp(np.cumsum(rng.normal(0, 0.02, days))), index=index)
    f2 = f1 * 1.01
    gen = pd.Series([f"XXX{'FGHJKMNQUVXZ'[d.month - 1]}{d.year % 10}" for d in index], index=index)
    ivs = {
        "iv30": pd.Series(35 + 5 * np.sin(np.arange(days) / 40), index=index),
        "iv60": pd.Series(34 + 5 * np.sin(np.arange(days) / 40), index=index),
        "iv90m": pd.Series(np.full(days, 38.0), index=index),
        "iv110m": pd.Series(np.full(days, 36.0), index=index),
    }
    return build_continuous(f1, f2, gen, ivs)


def market() -> MarketIn:
    as_of = date(2026, 10, 6)
    return MarketIn(
        as_of=as_of,
        rate=0.0,
        multiplier=10.0,
        slices=[ExpirySliceIn(expiry=as_of + timedelta(days=45), forward=50.0, pillars={"10DP": 0.4, "25DP": 0.37, "50D": 0.35, "25DC": 0.36, "10DC": 0.38})],
    )


STRADDLE = [LegIn(call_put="C", qty=1, strike_mode="delta", strike=0.5), LegIn(call_put="P", qty=1, strike_mode="delta", strike=0.5)]


def test_generic_root():
    assert generic_root("FJSZ6 Comdty") == "FJS"
    assert generic_root("FJSA Comdty") == "FJS"
    assert generic_root("FJS1 Comdty") == "FJS"


def test_build_continuous_uses_second_generic_on_roll_days():
    hist = synthetic_history()
    rolls = hist.index[hist["rolled"]]
    assert len(rolls) > 10
    day = rolls[0]
    prev = hist.index[hist.index.get_loc(day) - 1]
    assert hist.loc[day, "ret"] == pytest.approx(np.log(hist.loc[day, "f1"] / hist.loc[prev, "f2"]))
    assert hist["iv30"].max() < 1.0


def test_iv_at_interpolates():
    hist = synthetic_history(100)
    assert iv_at(hist, 45).iloc[0] == pytest.approx(0.5 * (hist["iv30"].iloc[0] + hist["iv60"].iloc[0]))
    assert iv_at(hist, 10).iloc[0] == pytest.approx(hist["iv30"].iloc[0])


def test_backtest_runs_and_metrics_add_up():
    hist = synthetic_history()
    result = run_backtest(market(), STRADDLE, "sticky-delta", hist, every=21)
    totals = np.array([t["total"] for t in result["trades"]])
    assert result["metrics"]["n"] == len(totals) > 20
    assert result["metrics"]["total"] == pytest.approx(totals.sum())
    assert all(t["premium"] > 0 for t in result["trades"])
    assert result["equity"]["drawdown"][-1] <= 0
    hedged = run_backtest(market(), STRADDLE, "sticky-delta", hist, every=21, hedge=True)
    assert hedged["metrics"]["n"] == result["metrics"]["n"]
    for t in result["trades"]:
        explained = t["delta_pnl"] + t["gamma_pnl"] + t["theta_pnl"] + t["vega_pnl"] + t["residual_pnl"]
        assert explained == pytest.approx(t["pnl"], abs=1e-6)
        assert t["carry_pnl"] == pytest.approx(t["gamma_pnl"] + t["theta_pnl"])
        assert t["total"] == pytest.approx(t["gross"])
    assert result["metrics"]["attribution"]["hedge"] is None
    assert hedged["metrics"]["attribution"]["hedge"] is not None
    # A long straddle hedged daily should have its delta P&L mostly offset by the hedge.
    hedge_offsets = [abs(t["delta_pnl"] + t["hedge_pnl"]) < abs(t["delta_pnl"]) for t in hedged["trades"] if abs(t["delta_pnl"]) > 1.0]
    assert np.mean(hedge_offsets) > 0.8


def test_backtest_futures_path_survives_missing_vol_days():
    hist = synthetic_history()
    # A gap longer than the forward fill: those sessions are dropped from the vol grid but the
    # future still moved, so the trade's exit forward must reflect every return in between.
    gap = hist.index[300:312]
    hist.loc[gap, ["iv30", "iv60"]] = np.nan
    result = run_backtest(market(), STRADDLE, "sticky-delta", hist, every=21)
    spanning = [t for t in result["trades"] if t["entry"] < gap[0].strftime("%Y-%m-%d") < t["exit"]]
    assert spanning
    for t in spanning:
        rets = hist["ret"].loc[t["entry"] : t["exit"]].to_numpy()[1:]
        expected = t["forward_entry"] * np.exp(np.nansum(rets))
        assert t["forward_exit"] == pytest.approx(expected, rel=1e-9)


def test_backtest_costs_and_hedge_delta():
    hist = synthetic_history()
    base = run_backtest(market(), STRADDLE, "sticky-delta", hist, every=21, hedge=True)
    costly = run_backtest(market(), STRADDLE, "sticky-delta", hist, every=21, hedge=True, hedge_cost_bps=5.0, entry_cost_vol=0.005)
    assert costly["metrics"]["gross_total"] == pytest.approx(base["metrics"]["gross_total"])
    assert costly["metrics"]["total"] < base["metrics"]["total"]
    for t in costly["trades"]:
        assert t["hedge_cost"] > 0 and t["entry_cost"] > 0
        assert t["total"] == pytest.approx(t["gross"] - t["hedge_cost"] - t["entry_cost"])
    banded = run_backtest(market(), STRADDLE, "sticky-delta", hist, every=21, hedge=True, hedge_cost_bps=5.0, hedge_band=0.5)
    assert sum(t["hedge_cost"] for t in banded["trades"]) < sum(t["hedge_cost"] for t in costly["trades"])
    # With a flat smile the smile-consistent delta is the Black delta.
    as_of = date(2026, 10, 6)
    flat = MarketIn(as_of=as_of, multiplier=10.0, slices=[ExpirySliceIn(expiry=as_of + timedelta(days=45), forward=50.0, pillars={"50D": 0.35})])
    smile = run_backtest(flat, STRADDLE, "sticky-delta", hist, every=21, hedge=True, hedge_delta="smile")
    black = run_backtest(flat, STRADDLE, "sticky-delta", hist, every=21, hedge=True, hedge_delta="black")
    for a, b in zip(smile["trades"], black["trades"]):
        assert a["hedge_pnl"] == pytest.approx(b["hedge_pnl"], abs=1e-3)
    # With skew, a sticky-delta hedge differs from the Black delta.
    skewed = run_backtest(market(), STRADDLE, "sticky-delta", hist, every=21, hedge=True, hedge_delta="black")
    assert any(abs(a["hedge_pnl"] - b["hedge_pnl"]) > 1e-3 for a, b in zip(base["trades"], skewed["trades"]))


def test_breakeven_analysis_probabilities():
    result = breakeven_analysis(market(), STRADDLE, "sticky-delta", synthetic_history())
    assert {b["direction"] for b in result["breakevens"]} == {"up", "down"}
    for level in result["breakevens"]:
        assert 0.0 <= level["hist_prob_beyond"] <= 1.0
    assert result["realised"]["median"] > 0


def test_seasonality_and_skew_slope():
    hist = synthetic_history()
    season = seasonality(hist)
    assert len(season["months"]) == 12
    stats = skew_slope(hist)["stats"]
    assert stats["skew"]["current"] == pytest.approx(-0.02)
    assert stats["slope"]["current"] == pytest.approx(-0.01)


def test_roll_skew_and_delta_solver():
    from scipy.stats import norm

    from app.market.rolls import MONEYNESS, skew_offsets, vol_at_delta

    cm = {(t, m): 0.5 + (0.1 if t == 60 else 0.0) + (m - 1.0) * (-0.5 if t == 30 else -0.3) for t in (30, 60) for m in MONEYNESS}
    assert skew_offsets(cm, 30)[0] == pytest.approx(0.05)
    assert skew_offsets(cm, 45)[0] == pytest.approx(0.04)
    assert skew_offsets(cm, 90)[0] == pytest.approx(0.03)
    flat = [0.0] * 5
    vol, extrapolated = vol_at_delta(0.4, flat, 50.0, 30, 0.5)
    assert vol == pytest.approx(0.4)
    assert not extrapolated
    offsets = skew_offsets(cm, 30)
    vol, _ = vol_at_delta(0.5, offsets, 50.0, 30, 0.75)
    T = 30 / 365.25
    log_m = -vol * np.sqrt(T) * norm.ppf(0.75) + 0.5 * vol * vol * T
    assert norm.cdf((-log_m + 0.5 * vol * vol * T) / (vol * np.sqrt(T))) == pytest.approx(0.75, abs=1e-4)
    assert vol > 0.5


def test_contract_tickers_walk_months():
    from app.market.rolls import contract_tickers

    rows = contract_tickers("FJS", date(2025, 11, 15), months_ahead=0)
    assert rows[0] == ("FJSX5 Comdty", date(2025, 11, 1))
    assert rows[2][0] == "FJSF6 Comdty"


def test_month_codes_and_contracts():
    assert month_code("Dec26") == "Z6"
    assert month_code("dec-2026") == "Z6"
    assert month_code("h7") == "H7"
    assert month_code("spring") is None
    chain = ["FJSX6 Comdty", "FJSZ6 Comdty", "FJSH7 Comdty"]
    assert resolve_contract("Z6", chain) == "FJSZ6 Comdty"
    assert resolve_contract("M7", chain) is None


def test_spot_vol_history_uses_the_contracts_own_50_delta(monkeypatch):
    from app.market.surface import history_for_contract, vol_series_label

    index = pd.bdate_range("2026-10-01", periods=3)
    frame = pd.DataFrame(
        {"FJSZ6 Comdty_PX_LAST": [80.0, 81.0, 82.0], "FJSZ6 Comdty_HIST_CALL_IMP_VOL": [90.0, 92.0, 91.0]},
        index=index,
    )
    seen = {}

    def fake_history(tickers, fields, start, end):
        seen["fields"] = fields
        return frame

    monkeypatch.setattr("app.market.bbg.history", fake_history)
    out = history_for_contract("FJSZ6 Comdty", date(2026, 10, 1), date(2026, 10, 6))
    assert seen["fields"] == ["PX_LAST", "HIST_CALL_IMP_VOL"]
    assert out["atm"].iloc[0] == pytest.approx(0.90)
    assert vol_series_label("FJSZ6 Comdty", None) == "FJSZ6 Comdty HIST_CALL_IMP_VOL"
    assert vol_series_label("FJSZ6 Comdty", "CUSTOM Index") == "CUSTOM Index"


def test_journal_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(journal, "PATH", tmp_path / "journal.json")
    entry = journal.add_entry({"kind": "quote", "label": "Z6 85/95 cs", "price": 1.2})
    assert journal.list_entries()[0]["id"] == entry["id"]
    journal.update_entry(entry["id"], {"status": "done", "id": "hijack"})
    assert journal.list_entries()[0]["status"] == "done"
    assert journal.list_entries()[0]["id"] == entry["id"]
    assert journal.delete_entry(entry["id"])
    assert journal.list_entries() == []


def test_alerts_fire_once(tmp_path, monkeypatch):
    from app.market import discovery

    monkeypatch.setattr(alerts, "PATH", tmp_path / "alerts.json")
    monkeypatch.setattr(discovery, "_refdata", lambda tickers, fields: {"FJSZ6 Comdty": {"PX_LAST": 82.0, "HIST_CALL_IMP_VOL": 60.0, "HIST_PUT_IMP_VOL": 62.0}})
    price = alerts.add_alert("FJSZ6 Comdty", "price", "above", 80.0)
    vol = alerts.add_alert("FJSZ6 Comdty", "atm_vol", "below", 0.5)
    fired = alerts.check_now()
    assert [a["id"] for a in fired] == [price["id"]]
    assert alerts.check_now() == []
    rows = {a["id"]: a for a in alerts.list_alerts()}
    assert rows[vol["id"]]["last_value"] == pytest.approx(0.61)
    assert alerts.reset_alert(price["id"])["triggered_at"] is None
