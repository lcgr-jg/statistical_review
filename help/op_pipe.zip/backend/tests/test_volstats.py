import numpy as np
import pandas as pd
import pytest

from app.quant import volstats


def test_realised_vol_and_spot_vol_beta():
    rng = np.random.default_rng(7)
    n, sigma, beta = 600, 0.5, -0.4
    ret = rng.normal(0, sigma / np.sqrt(252), n)
    futures = 80 * np.exp(np.cumsum(ret))
    atm = 0.6 + beta * (np.log(futures) - np.log(80)) + rng.normal(0, 0.002, n)
    frame = pd.DataFrame(
        {"futures": futures, "atm": atm, "iv30": atm},
        index=pd.bdate_range("2024-01-01", periods=n),
    )
    out = volstats.analyse(frame)
    assert out["changes_fit"]["slope"] == pytest.approx(beta, abs=0.05)
    assert out["stats"]["corr"] < -0.8
    rv60 = [v for v in out["series"]["rv60"] if v is not None]
    assert np.median(rv60) == pytest.approx(sigma, rel=0.15)
    cone = {row["window"]: row for row in out["cone"]}
    assert cone[20]["p10"] <= cone[20]["p50"] <= cone[20]["p90"]
    fwd = out["series"]["rv20_fwd"]
    assert fwd[-1] is None and fwd[0] is not None
    assert len(out["dates"]) == n
