"""Trade and quote journal, stored as one JSON file in the persisted cache volume.

Every entry carries an append-only ``history`` (who changed what, from and to) and a ``comments``
thread. Deleting marks the entry deleted and records it, so the audit trail survives.
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone

from app.settings import CACHE_DIR

PATH = CACHE_DIR / "journal.json"
_lock = threading.Lock()
EDITABLE = {"notes", "tags", "status", "label", "side", "price", "size", "counterparty"}
MAX_COMMENT = 4000


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _read() -> list[dict]:
    if not PATH.exists():
        return []
    try:
        return json.loads(PATH.read_text())
    except json.JSONDecodeError:
        return []


def _write(entries: list[dict]) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(entries, indent=1, default=str))
    tmp.replace(PATH)


def _tags(value) -> list[str]:
    if isinstance(value, str):
        value = value.replace(",", " ").split()
    seen: list[str] = []
    for tag in value or []:
        tag = str(tag).strip().lstrip("#").lower()
        if tag and tag not in seen:
            seen.append(tag[:40])
    return seen


def _event(author: str, action: str, **detail) -> dict:
    return {"at": _now(), "author": author or "unknown", "action": action, **detail}


def list_entries(include_deleted: bool = False) -> list[dict]:
    with _lock:
        entries = [e for e in _read() if include_deleted or not e.get("deleted")]
    for entry in entries:
        entry.setdefault("comments", [])
        entry.setdefault("history", [])
    return sorted(entries, key=lambda e: e.get("created", ""), reverse=True)


def add_entry(entry: dict, author: str = "") -> dict:
    created = _now()
    record = {
        **{k: v for k, v in entry.items() if k not in ("history", "comments", "deleted")},
        "id": uuid.uuid4().hex[:12],
        "created": created,
        "author": author or entry.get("author") or "unknown",
        "tags": _tags(entry.get("tags")),
        "status": entry.get("status") or "open",
        "comments": [],
        "history": [_event(author, "created", kind=entry.get("kind"), status=entry.get("status") or "open")],
    }
    with _lock:
        entries = _read()
        entries.append(record)
        _write(entries)
    return record


def update_entry(entry_id: str, patch: dict, author: str = "") -> dict | None:
    with _lock:
        entries = _read()
        for entry in entries:
            if entry["id"] != entry_id or entry.get("deleted"):
                continue
            history = entry.setdefault("history", [])
            for key, value in patch.items():
                if key not in EDITABLE:
                    continue
                if key == "tags":
                    value = _tags(value)
                before = entry.get(key)
                if before == value:
                    continue
                entry[key] = value
                history.append(_event(author, "changed", field=key, before=before, after=value))
            entry["updated"] = _now()
            _write(entries)
            return entry
    return None


def add_comment(entry_id: str, text: str, author: str = "") -> dict | None:
    text = text.strip()[:MAX_COMMENT]
    if not text:
        raise ValueError("A comment needs some text.")
    with _lock:
        entries = _read()
        for entry in entries:
            if entry["id"] != entry_id or entry.get("deleted"):
                continue
            comment = {"id": uuid.uuid4().hex[:8], "at": _now(), "author": author or "unknown", "text": text}
            entry.setdefault("comments", []).append(comment)
            entry.setdefault("history", []).append(_event(author, "commented", comment=comment["id"]))
            entry["updated"] = comment["at"]
            _write(entries)
            return entry
    return None


def delete_entry(entry_id: str, author: str = "") -> bool:
    with _lock:
        entries = _read()
        for entry in entries:
            if entry["id"] == entry_id and not entry.get("deleted"):
                entry["deleted"] = True
                entry.setdefault("history", []).append(_event(author, "deleted"))
                entry["updated"] = _now()
                _write(entries)
                return True
    return False


def audit(limit: int = 200) -> list[dict]:
    """Every journal event, newest first, with the entry it belongs to."""
    with _lock:
        entries = _read()
    events = [
        (event["at"], seq, {**event, "entry": entry["id"], "label": entry.get("label"), "kind": entry.get("kind")})
        for entry in entries
        for seq, event in enumerate(entry.get("history", []))
    ]
    return [e for _, _, e in sorted(events, key=lambda x: (x[0], x[1]), reverse=True)[:limit]]
