from __future__ import annotations

from datetime import date
from typing import Literal

from pydantic import BaseModel, Field

PillarName = Literal["10DC", "25DC", "50D", "25DP", "10DP"]
Regime = Literal["sticky-delta", "sticky-strike", "beta"]
StrikeMode = Literal["absolute", "delta", "pct_atm"]
HedgeFreq = Literal["none", "daily", "weekly"]
VolSource = Literal["path", "beta"]


class ExpirySliceIn(BaseModel):
    expiry: date
    forward: float = Field(gt=0)
    pillars: dict[str, float | None]


class MarketIn(BaseModel):
    as_of: date
    rate: float = 0.0
    multiplier: float = Field(default=1.0, gt=0)
    currency: str = "EUR"
    unit: str = "EUR/MWh"
    beta: float | None = None
    slices: list[ExpirySliceIn] = Field(min_length=1)


class LegIn(BaseModel):
    call_put: Literal["C", "P"]
    qty: float
    strike_mode: StrikeMode = "absolute"
    strike: float
    expiry: date | None = None
    vol: float | None = None


class PriceRequest(BaseModel):
    market: MarketIn
    legs: list[LegIn] = Field(min_length=1)
    regime: Regime = "sticky-delta"
    follow_beta: bool = False


class TemplateRequest(BaseModel):
    name: str
    expiries: list[date] = Field(min_length=1)
    qty: float = 1.0


class GridRequest(BaseModel):
    market: MarketIn
    legs: list[LegIn] = Field(min_length=1)
    regime: Regime = "sticky-delta"
    spot_min: float = Field(gt=0)
    spot_max: float = Field(gt=0)
    vol_min: float = Field(gt=0)
    vol_max: float = Field(gt=0)
    n_spot: int = Field(default=31, ge=5, le=81)
    n_vol: int = Field(default=21, ge=5, le=61)
    life_fractions: list[float] = Field(default_factory=lambda: [0.0, 0.25, 0.5, 0.75, 1.0])


class PathPointIn(BaseModel):
    t: float = Field(ge=0)
    forward: float = Field(gt=0)
    atm_vol: float = Field(gt=0)


class PathRequest(BaseModel):
    market: MarketIn
    legs: list[LegIn] = Field(min_length=1)
    regime: Regime = "sticky-delta"
    points: list[PathPointIn] = Field(min_length=2)
    hedge: HedgeFreq = "none"
    vol_source: VolSource = "path"


class MonteCarloRequest(BaseModel):
    market: MarketIn
    legs: list[LegIn] = Field(min_length=1)
    regime: Regime = "sticky-delta"
    n_paths: int = Field(default=4000, ge=200, le=20000)
    n_steps: int = Field(default=48, ge=8, le=160)
    kappa: float = Field(default=1.0, ge=0)
    xi: float = Field(default=0.0, ge=0)
    rho: float = Field(default=0.0, ge=-0.999, le=0.999)
    sigma_bar: float | None = None
    seed: int = 7
    n_overlay: int = Field(default=30, ge=0, le=80)
    hedge: bool = False


class HistoryRequest(BaseModel):
    futures_ticker: str
    vol_ticker: str | None = None
    rr_ticker: str | None = None
    pillar_tickers: dict[str, str] | None = None
    start: date
    end: date
    window: int = Field(default=60, ge=15, le=250)


class AnalogRequest(BaseModel):
    month_code: str = Field(min_length=1, max_length=1)
    futures_template: str
    vol_template: str | None = None
    years: list[int] = Field(min_length=1, max_length=8)
    window_days: int = Field(default=120, ge=20, le=400)


class ResolverMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ResolverChatRequest(BaseModel):
    messages: list[ResolverMessage] = Field(min_length=1)
    underlying_id: str | None = None


class CopilotChatRequest(BaseModel):
    messages: list[ResolverMessage] = Field(min_length=1)
    market: MarketIn
    legs: list[LegIn] = Field(default_factory=list)
    mode: Literal["structure", "critique", "chat"] = "chat"
    regime: Regime = "sticky-delta"
    product: str | None = None
    contract: str | None = None
    page: str | None = None
    context: dict | None = None


class BacktestRequest(BaseModel):
    market: MarketIn
    legs: list[LegIn] = Field(min_length=1)
    regime: Regime = "sticky-delta"
    contract: str
    years: float = Field(default=6.0, ge=1.0, le=12.0)
    every: int = Field(default=21, ge=1, le=126)
    hedge: bool = False
    hedge_delta: Literal["smile", "black"] = "smile"
    # Half spread per futures trade, in bp of notional.
    hedge_cost_bps: float = Field(default=0.0, ge=0.0, le=100.0)
    # Rebalance only when the delta gap exceeds this many lots. 0 rebalances daily.
    hedge_band: float = Field(default=0.0, ge=0.0, le=100.0)
    # Half spread paid on entry, in absolute vol (0.005 is half a vol point) per unit of each leg's vega.
    entry_cost_vol: float = Field(default=0.0, ge=0.0, le=0.2)
    # "last" holds a multi-expiry structure (a strip, a calendar) until its last leg expires.
    hold: Literal["front", "last"] = "front"


class BreakevenRequest(BaseModel):
    market: MarketIn
    legs: list[LegIn] = Field(min_length=1)
    regime: Regime = "sticky-delta"
    contract: str
    years: float = Field(default=6.0, ge=1.0, le=12.0)


class PositionIn(BaseModel):
    id: str
    label: str = ""
    market: MarketIn
    legs: list[LegIn] = Field(min_length=1)
    # Any contract of the product; its generic history drives the scenarios.
    contract: str
    # Scales every leg's qty, e.g. lots traded.
    size: float = 1.0


class VarRequest(BaseModel):
    positions: list[PositionIn] = Field(min_length=1, max_length=50)
    regime: Regime = "sticky-delta"
    years: float = Field(default=6.0, ge=1.0, le=12.0)
    horizon: int = Field(default=1, ge=1, le=20)


class QuoteParseRequest(BaseModel):
    text: str = Field(min_length=2, max_length=8000)
    product: str
    regime: Regime = "sticky-delta"
    rate: float = 0.0
    multiplier: float = 1.0


class AlertIn(BaseModel):
    ticker: str = Field(min_length=3)
    field: Literal["price", "atm_vol"]
    op: Literal["above", "below"]
    level: float
    note: str = ""


class SampleCheck(BaseModel):
    ticker: str
    field: str = "PX_LAST"
    purpose: str = ""


class UnderlyingProposal(BaseModel):
    id: str = Field(min_length=1, max_length=16)
    name: str
    currency: str = "EUR"
    unit: str = ""
    multiplier: float = Field(default=1.0, gt=0)
    rate: float = 0.0
    futures_root: str
    futures_ticker_template: str
    expiry_field: str = "LAST_TRADEABLE_DT"
    month_codes: str = "FGHJKMNQUVXZ"
    curve_months: int = Field(default=16, ge=1, le=36)
    vol_pillars: dict[str, str]
    notes: str = ""
    sample_checks: list[SampleCheck] = Field(default_factory=list)
