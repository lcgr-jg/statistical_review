"""Spot and log-vol Monte Carlo.

The future is simulated in the forward measure, so it has no drift:

    dF / F = sigma dW1

Log-vol is an Ornstein-Uhlenbeck process:

    d ln sigma = kappa (ln sigma_bar - ln sigma) dt + xi dW2

with corr(dW1, dW2) = rho. When xi is 0 the volatility is deterministic and,
if it is also constant, the mean discounted payoff of a vanilla converges to
the Black-76 price.

The package is marked every step with the same smile rules as the pricer.
A delta-hedged run carries minus the forward delta, with variation margin
discounted back to as-of.
"""
from __future__ import annotations

from datetime import date

import numpy as np

from app.quant.black76 import price
from app.quant.structures import _skew_name, prepare_slices, resolve_legs


def _calibrated_bar(atm: float) -> float:
    return max(atm, 1e-3)


def simulate(
    market,
    legs,
    regime: str,
    as_of: date,
    n_paths: int,
    n_steps: int,
    kappa: float,
    xi: float,
    rho: float,
    sigma_bar: float | None,
    seed: int,
    n_overlay: int,
    hedge: bool,
) -> dict:
    prepared = prepare_slices(market, as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    primary = min(leg["slice"].expiry for leg in resolved)
    sl0, T0, smile0 = by_exp[primary]
    if T0 <= 1e-6:
        raise ValueError("The primary expiry has no time left.")
    single = all(leg["slice"].expiry == primary for leg in resolved)
    if not single:
        raise ValueError("Monte Carlo currently prices a single expiry. Split calendars out.")

    n_paths = int(np.clip(n_paths, 200, 20000))
    n_steps = int(np.clip(n_steps, 8, 160))
    dt = T0 / n_steps
    sqrt_dt = np.sqrt(dt)
    rho = float(np.clip(rho, -0.999, 0.999))
    xi = max(float(xi), 0.0)
    kappa = max(float(kappa), 0.0)
    bar = _calibrated_bar(smile0.atm if sigma_bar is None else sigma_bar)
    log_bar = np.log(bar)
    skew = _skew_name(regime)
    rate = market.rate
    mult = market.multiplier
    df_pay = float(np.exp(-rate * T0))

    rng = np.random.default_rng(seed)
    F = np.full(n_paths, sl0.forward)
    log_sig = np.full(n_paths, np.log(smile0.atm))
    # Store a stride of steps for the fans so the payload stays small.
    stride = max(1, n_steps // 40)
    snap_idx = list(range(0, n_steps + 1, stride))
    if snap_idx[-1] != n_steps:
        snap_idx.append(n_steps)
    spot_snaps = np.empty((len(snap_idx), n_paths))
    vol_snaps = np.empty((len(snap_idx), n_paths))
    pnl_snaps = np.empty((len(snap_idx), n_paths))
    overlay_ix = np.linspace(0, n_paths - 1, min(n_overlay, n_paths)).astype(int)
    overlay_f = np.empty((n_steps + 1, len(overlay_ix)))
    overlay_v = np.empty((n_steps + 1, len(overlay_ix)))

    strikes = np.array([leg["strike"] for leg in resolved])
    cps = np.array([leg["cp"] for leg in resolved])
    qtys = np.array([leg["qty"] for leg in resolved])
    overrides = [leg["vol_override"] for leg in resolved]

    def mark(forward, sigma, t_rem) -> np.ndarray:
        total = np.zeros(n_paths)
        for strike, cp, qty, override in zip(strikes, cps, qtys, overrides):
            if override is not None:
                vol = np.full(n_paths, override)
            else:
                vol = smile0.vol_at_strike(strike, forward, sigma, max(t_rem, 1e-6), skew)
            total = total + qty * mult * price(forward, strike, vol, t_rem, rate, cp)
        return total

    value0 = mark(F, np.exp(log_sig), T0)
    hedge_pos = np.zeros(n_paths)
    cum_hedge = np.zeros(n_paths)
    if hedge:
        # forward delta at t0, one finite bump shared across paths
        bump = sl0.forward * 1e-4
        up = mark(F + bump, np.exp(log_sig), T0)
        down = mark(F - bump, np.exp(log_sig), T0)
        cash_delta = (up - down) / (2 * bump)
        hedge_pos = -cash_delta * np.exp(rate * T0)

    def capture(step_i, snap_slot, t_rem, value):
        spot_snaps[snap_slot] = F
        vol_snaps[snap_slot] = np.exp(log_sig)
        pnl_snaps[snap_slot] = value - value0 + cum_hedge
        if step_i in (0, n_steps) or True:
            pass

    snap_slot = 0
    spot_snaps[0] = F
    vol_snaps[0] = np.exp(log_sig)
    pnl_snaps[0] = cum_hedge
    overlay_f[0] = F[overlay_ix]
    overlay_v[0] = np.exp(log_sig[overlay_ix])
    next_snap = snap_idx[1] if len(snap_idx) > 1 else None
    snap_slot = 1

    for step in range(1, n_steps + 1):
        z1 = rng.standard_normal(n_paths)
        z2 = rng.standard_normal(n_paths)
        dW1 = sqrt_dt * z1
        dW2 = sqrt_dt * (rho * z1 + np.sqrt(1 - rho * rho) * z2)
        sig = np.exp(log_sig)
        F_prev = F
        logF = np.log(np.maximum(F, 1e-12)) - 0.5 * sig * sig * dt + sig * dW1
        F = np.exp(logF)
        if xi > 0 and kappa > 0:
            # Exact OU step on log-vol, independent of the spot discretisation.
            decay = np.exp(-kappa * dt)
            var = xi * xi * (1 - decay * decay) / (2 * kappa)
            # Rebuild the shock so the correlation with dW1 is preserved in the limit.
            shock = dW2
            log_sig = log_bar + (log_sig - log_bar) * decay + xi * shock * np.sqrt(max(var, 0.0)) / max(xi * sqrt_dt, 1e-12)
        elif xi > 0:
            log_sig = log_sig + xi * dW2
        log_sig = np.clip(log_sig, np.log(0.02), np.log(3.0))
        t_rem = max(T0 - step * dt, 0.0)
        if hedge:
            dF = F - F_prev
            cum_hedge = cum_hedge + np.exp(-rate * step * dt) * hedge_pos * dF
        value = mark(F, np.exp(log_sig), t_rem)
        if hedge and step < n_steps:
            bump = np.maximum(F * 1e-4, 1e-4)
            up = mark(F + bump, np.exp(log_sig), t_rem)
            down = mark(F - bump, np.exp(log_sig), t_rem)
            cash_delta = (up - down) / (2 * bump)
            hedge_pos = -cash_delta * np.exp(rate * t_rem)
        overlay_f[step] = F[overlay_ix]
        overlay_v[step] = np.exp(log_sig[overlay_ix])
        if next_snap is not None and step == next_snap:
            spot_snaps[snap_slot] = F
            vol_snaps[snap_slot] = np.exp(log_sig)
            pnl_snaps[snap_slot] = value - value0 + cum_hedge
            snap_slot += 1
            next_snap = snap_idx[snap_slot] if snap_slot < len(snap_idx) else None

    terminal_value = mark(F, np.exp(log_sig), 0.0)
    terminal = terminal_value - value0 + cum_hedge
    payoff = _vanilla_payoff(resolved, F, mult)
    discounted_payoff = float(np.exp(-rate * T0) * np.mean(payoff))

    def pct(a, ps=(5, 25, 50, 75, 95)):
        return {f"p{p}": np.percentile(a, p, axis=1).tolist() for p in ps}

    times = (np.array(snap_idx) * dt).tolist()
    var_cut = np.percentile(terminal, 5)
    es = float(terminal[terminal <= var_cut].mean()) if np.any(terminal <= var_cut) else float(var_cut)
    hist, edges = np.histogram(terminal, bins=40)
    return {
        "n_paths": n_paths,
        "n_steps": n_steps,
        "times": times,
        "spot": pct(spot_snaps),
        "vol": pct(vol_snaps),
        "pnl": pct(pnl_snaps),
        "terminal": {
            "mean": float(terminal.mean()),
            "std": float(terminal.std()),
            "var_95": float(np.percentile(terminal, 5)),
            "es_95": es,
            "p5": float(np.percentile(terminal, 5)),
            "p50": float(np.percentile(terminal, 50)),
            "p95": float(np.percentile(terminal, 95)),
            "prob_profit": float(np.mean(terminal > 0)),
            "hist_counts": hist.tolist(),
            "hist_edges": edges.tolist(),
        },
        "premium": float(np.mean(value0)),
        "discounted_payoff_mean": discounted_payoff,
        "overlays": {
            "times": (np.arange(n_steps + 1) * dt).tolist(),
            "forward": overlay_f.T.tolist(),
            "vol": overlay_v.T.tolist(),
        },
        "params": {
            "kappa": kappa,
            "xi": xi,
            "rho": rho,
            "sigma_bar": bar,
            "hedge": hedge,
            "seed": seed,
        },
    }


def _vanilla_payoff(resolved, F, mult) -> np.ndarray:
    total = np.zeros_like(F)
    for leg in resolved:
        total = total + leg["qty"] * mult * np.maximum(leg["cp"] * (F - leg["strike"]), 0.0)
    return total


def black_reference(market, legs, as_of: date) -> float:
    """Discounted payoff is compared with this by the tests. Returned for the UI too."""
    prepared = prepare_slices(market, as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    primary = min(leg["slice"].expiry for leg in resolved)
    sl, T, smile = by_exp[primary]
    total = 0.0
    for leg in resolved:
        vol = leg["vol_override"] if leg["vol_override"] is not None else float(
            smile.vol_at_strike(leg["strike"], sl.forward, smile.atm, max(T, 1e-4), "delta")
        )
        total += leg["qty"] * market.multiplier * float(price(sl.forward, leg["strike"], vol, T, market.rate, leg["cp"]))
    return total
