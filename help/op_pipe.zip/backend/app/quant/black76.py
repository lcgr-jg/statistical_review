"""Black-76 futures options.

Prices and greeks are present values. Delta is dV/dF (cash delta). Forward
delta is cash delta times exp(rT), i.e. N(d1) for a call. Vega is dV per 1.0
of absolute volatility (divide by 100 for a vol point). Theta and charm are
calendar derivatives: the change as time passes and time-to-expiry shrinks.
Year fractions are ACT/365.25.
"""
from __future__ import annotations

import numpy as np
from scipy.special import ndtr

_INV_SQRT_2PI = 0.3989422804014327
_T_FLOOR = 1e-6
_SIG_FLOOR = 1e-4


def year_fraction(as_of, expiry) -> float:
    return max((expiry - as_of).days / 365.25, 0.0)


def _pdf(x: np.ndarray) -> np.ndarray:
    return _INV_SQRT_2PI * np.exp(-0.5 * x * x)


def _d1_d2(F, K, sigma, T):
    sig = np.maximum(sigma, _SIG_FLOOR)
    t = np.maximum(T, _T_FLOOR)
    vol_sqrt = sig * np.sqrt(t)
    d1 = (np.log(np.maximum(F, 1e-12) / np.maximum(K, 1e-12)) + 0.5 * sig * sig * t) / vol_sqrt
    d2 = d1 - vol_sqrt
    return d1, d2, sig, t


def price(F, K, sigma, T, r, cp) -> np.ndarray:
    """cp is +1 for a call and -1 for a put. Broadcasts over the inputs."""
    F = np.asarray(F, dtype=float)
    K = np.asarray(K, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    T = np.asarray(T, dtype=float)
    r = np.asarray(r, dtype=float)
    cp = np.asarray(cp, dtype=float)
    df = np.exp(-r * np.maximum(T, 0.0))
    intrinsic = df * np.maximum(cp * (F - K), 0.0)
    alive = T > _T_FLOOR
    d1, d2, _, _ = _d1_d2(F, K, sigma, T)
    fwd = np.where(cp > 0, F * ndtr(d1) - K * ndtr(d2), K * ndtr(-d2) - F * ndtr(-d1))
    return np.where(alive, df * fwd, intrinsic)


def implied_vol(F, K, T, premium, cp, r=0.0, lo=0.01, hi=5.0, iterations=60) -> np.ndarray:
    """Bisection on sigma. NaN where the premium is at or below intrinsic or above the hi-vol price."""
    F, K, T, premium, cp = (np.asarray(x, dtype=float) for x in (F, K, T, premium, cp))
    low = np.full(np.broadcast(F, K, T, premium, cp).shape, lo)
    high = np.full_like(low, hi)
    valid = (price(F, K, lo, T, r, cp) < premium) & (premium < price(F, K, hi, T, r, cp))
    for _ in range(iterations):
        mid = 0.5 * (low + high)
        above = price(F, K, mid, T, r, cp) > premium
        high = np.where(above, mid, high)
        low = np.where(above, low, mid)
    return np.where(valid, 0.5 * (low + high), np.nan)


def greeks(F, K, sigma, T, r, cp) -> dict[str, np.ndarray]:
    """Cash greeks plus forward delta, vanna, volga and calendar charm.

    Expired options (T below a fraction of a day) return intrinsic value and a
    unit digital delta; the other greeks are zero.
    """
    F = np.asarray(F, dtype=float)
    K = np.asarray(K, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    T = np.asarray(T, dtype=float)
    r = np.asarray(r, dtype=float)
    cp = np.asarray(cp, dtype=float)

    df = np.exp(-r * np.maximum(T, 0.0))
    alive = T > _T_FLOOR
    d1, d2, sig, t = _d1_d2(F, K, sigma, T)
    nprime = _pdf(d1)
    sqrt_t = np.sqrt(t)
    nd1 = ndtr(d1)

    delta_call = df * nd1
    delta = np.where(cp > 0, delta_call, delta_call - df)
    forward_delta = delta * np.exp(r * np.maximum(T, 0.0))
    gamma = df * nprime / (np.maximum(F, 1e-12) * sig * sqrt_t)
    vega = df * F * nprime * sqrt_t
    value = price(F, K, sigma, T, r, cp)
    dvdT = -r * value + df * F * nprime * sig / (2.0 * sqrt_t)
    theta = -dvdT
    vanna = -df * nprime * d2 / sig
    volga = vega * d1 * d2 / sig
    dd1_dT = -d2 / (2.0 * t)
    d_delta_dT = -r * delta + df * nprime * dd1_dT
    charm = -d_delta_dT

    zero = np.zeros_like(value, dtype=float)
    intrinsic_delta = np.where(cp * (F - K) > 0.0, cp * 1.0, 0.0)
    # ATM expiry is a convention; treat the strike as not strictly in the money.
    intrinsic_delta = np.where(np.abs(F - K) <= 1e-12, 0.0, intrinsic_delta)

    def _alive(live, dead):
        return np.where(alive, live, dead)

    return {
        "price": value,
        "delta": _alive(delta, intrinsic_delta),
        "forward_delta": _alive(forward_delta, intrinsic_delta),
        "gamma": _alive(gamma, zero),
        "vega": _alive(vega, zero),
        "theta": _alive(theta, zero),
        "vanna": _alive(vanna, zero),
        "volga": _alive(volga, zero),
        "charm": _alive(charm, zero),
    }


def strike_from_call_delta(F, sigma, T, call_delta) -> np.ndarray:
    """Strike whose undiscounted Black forward delta equals ``call_delta``.

    Forward delta is N(d1). A 25-delta call is 0.25; a 25-delta put strike is
    the strike whose call delta is 0.75.
    """
    F = np.asarray(F, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    T = np.asarray(T, dtype=float)
    call_delta = np.clip(np.asarray(call_delta, dtype=float), 1e-4, 1.0 - 1e-4)
    from scipy.special import ndtri

    d1 = ndtri(call_delta)
    sig = np.maximum(sigma, _SIG_FLOOR)
    t = np.maximum(T, _T_FLOOR)
    return F * np.exp(-d1 * sig * np.sqrt(t) + 0.5 * sig * sig * t)
