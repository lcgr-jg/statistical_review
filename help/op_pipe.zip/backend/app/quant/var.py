"""Historical-simulation VaR for a book of option structures, possibly on several products.

Each scenario is one historical start date d. Over the horizon of h sessions every position's
futures move by its product's roll-adjusted log return from d to d+h, and each expiry's ATM moves
by the change in the constant-maturity ATM for that tenor (interpolated between 30d and 60d). The
smile shape follows the regime, as in the Builder. Positions are full-revalued under the scenario,
not approximated with greeks, and lined up by date, so correlation between products is whatever
history did on those days.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from app.market.generic import iv_at
from app.quant.backtest import IV_GAP_FILL, SESSIONS
from app.quant.regimes import REGIMES
from app.quant.structures import _skew_name, prepare_slices, price_package, resolve_legs

LEVELS = (0.95, 0.99)
ASSUMPTIONS = [
    "Full revaluation under each historical move; no greek approximation.",
    "Every expiry of a product moves with its 1st generic's roll-adjusted return (a parallel shift of the curve).",
    "Each expiry's ATM moves by the change in the constant-maturity ATM at its tenor, interpolated between 30d and 60d; "
    f"vol gaps of up to {IV_GAP_FILL} sessions are carried forward.",
    "The smile shape follows the selected regime. Rates, time decay and the horizon's theta are included.",
    "Positions are aligned on scenario dates; dates missing for any product are dropped.",
]


def _scenarios(hist: pd.DataFrame, tenors: dict, horizon: int) -> tuple[pd.Series, dict]:
    """Log move and per-expiry ATM change over ``horizon`` sessions, indexed by start date."""
    frame = hist.sort_index()
    logp = pd.Series(np.cumsum(np.nan_to_num(frame["ret"].to_numpy(dtype=float))), index=frame.index)
    filled = frame.assign(**{c: frame[c].ffill(limit=IV_GAP_FILL) for c in ("iv30", "iv60")})
    move = (logp.shift(-horizon) - logp).dropna()
    dvol = {}
    for exp, days in tenors.items():
        iv = iv_at(filled, max(days, 1))
        dvol[exp] = (iv.shift(-horizon) - iv).reindex(move.index)
    return move, dvol


def position_scenarios(position: dict, hist: pd.DataFrame, regime: str, horizon: int) -> tuple[pd.Series, dict]:
    """Scenario P&L series for one position and its current risk."""
    market, legs = position["market"], position["legs"]
    size = float(position.get("size") or 1.0)
    prepared = prepare_slices(market, market.as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    skew = _skew_name(regime)
    follow_beta = regime == "beta"
    rate, mult = market.rate, market.multiplier
    used = {item["slice"].expiry for item in resolved}
    F0 = {exp: by_exp[exp][0].forward for exp in used}
    atm0 = {exp: by_exp[exp][0].pillars["50D"] for exp in used}
    T0 = {exp: by_exp[exp][1] for exp in used}
    tenors = {exp: (exp - market.as_of).days for exp in used}

    base = price_package(resolved, F0, atm0, T0, rate, skew, follow_beta, mult)
    move, dvol = _scenarios(hist, tenors, horizon)
    ok = np.isfinite(move.to_numpy())
    for exp in used:
        ok &= np.isfinite(dvol[exp].to_numpy())
    move = move[ok]
    elapsed = horizon / SESSIONS
    F = {exp: F0[exp] * np.exp(move.to_numpy()) for exp in used}
    atm = {exp: np.maximum(atm0[exp] + dvol[exp][ok].to_numpy(), 0.01) for exp in used}
    T = {exp: np.full(len(move), max(T0[exp] - elapsed, 0.0)) for exp in used}
    shocked = np.asarray(price_package(resolved, F, atm, T, rate, skew, follow_beta, mult)["price"], dtype=float)
    pnl = pd.Series((shocked - float(base["price"])) * size, index=move.index)
    risk = {
        "value": float(base["price"]) * size,
        "delta": float(base["delta"]) * size,
        "gamma": float(base["gamma"]) * size,
        "vega_point": float(base["vega"]) / 100.0 * size,
        "theta_day": float(base["theta"]) / 365.25 * size,
    }
    return pnl.rename(position.get("id") or position.get("label")), {"risk": risk, "move": move}


def _tail(values: np.ndarray, level: float) -> tuple[float, float, float]:
    """VaR and expected shortfall as positive losses, and the cut-off P&L."""
    cut = float(np.quantile(values, 1.0 - level))
    tail = values[values <= cut]
    return -cut, float(-tail.mean()) if len(tail) else -cut, cut


def book_var(positions: list[dict], histories: dict[str, pd.DataFrame], regime: str, horizon: int = 1) -> dict:
    """``positions``: dicts with id, label, market, legs, contract and size. ``histories`` by contract."""
    if not positions:
        raise ValueError("The book is empty.")
    series, info = [], []
    for i, position in enumerate(positions):
        try:
            pnl, extra = position_scenarios(position, histories[position["contract"]], regime, horizon)
        except ValueError as exc:
            raise ValueError(f"{position.get('label') or 'Position'}: {exc}") from exc
        if pnl.name in {s.name for s in series}:
            pnl = pnl.rename(f"{pnl.name}-{i}")
        series.append(pnl)
        info.append({"id": pnl.name, "label": position.get("label") or pnl.name, "contract": position["contract"], **extra["risk"]})
    frame = pd.concat(series, axis=1, join="inner").dropna()
    if len(frame) < 60:
        raise ValueError(f"Only {len(frame)} common scenario dates across the book. Use more years or fewer products.")
    book = frame.sum(axis=1).to_numpy()

    levels = {}
    for level in LEVELS:
        var, es, cut = _tail(book, level)
        levels[f"{round(level * 100)}"] = {"var": var, "es": es}
        if level == LEVELS[0]:
            tail_rows = book <= cut
    for row in info:
        values = frame[row["id"]].to_numpy()
        row["var_95"] = _tail(values, 0.95)[0]
        # Contributions to the book's 95% expected shortfall sum to the book ES.
        row["es_contribution_95"] = float(-values[tail_rows].mean())

    worst_idx = np.argsort(book)[:10]
    worst = [
        {
            "date": frame.index[i].strftime("%Y-%m-%d"),
            "pnl": float(book[i]),
            "positions": {col: float(frame.iloc[i][col]) for col in frame.columns},
        }
        for i in worst_idx
    ]
    stresses = []
    dates = frame.index.strftime("%Y-%m-%d")
    for regime_row in REGIMES:
        mask = (dates >= regime_row["start"]) & (dates <= regime_row["end"])
        if not mask.any():
            stresses.append({"id": regime_row["id"], "label": regime_row["label"], "n": 0, "worst": None, "worst_date": None, "mean": None, "var_95": None})
            continue
        values = book[mask]
        j = int(np.argmin(values))
        stresses.append({
            "id": regime_row["id"],
            "label": regime_row["label"],
            "n": int(mask.sum()),
            "worst": float(values[j]),
            "worst_date": dates[mask][j],
            "mean": float(values.mean()),
            "var_95": _tail(values, 0.95)[0] if mask.sum() >= 20 else None,
        })
    counts, edges = np.histogram(book, bins=50)
    totals = {k: float(sum(row[k] for row in info)) for k in ("value", "delta", "gamma", "vega_point", "theta_day")}
    return {
        "horizon": horizon,
        "n_scenarios": int(len(book)),
        "from": dates[0],
        "to": dates[-1],
        "levels": levels,
        "mean": float(book.mean()),
        "std": float(book.std(ddof=1)),
        "positions": info,
        "totals": totals,
        "worst": worst,
        "stresses": stresses,
        "histogram": {"counts": counts.tolist(), "edges": edges.tolist()},
        "series": {"dates": list(dates), "pnl": book.tolist()},
        "assumptions": ASSUMPTIONS,
    }
