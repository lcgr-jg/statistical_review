"""Spot against implied vol.

Levels: ATM vol on log futures. Changes: daily change in ATM vol on the daily
log return. Rolling beta uses a fixed window of the changes regression.
Realised vol is the standard deviation of log returns times sqrt(252).
The vol risk premium is implied minus realised, in absolute vol.
Kappa is the AR(1) speed on log vol, annualised with 252 sessions, and xi is
the residual standard deviation of daily log-vol changes times sqrt(252).
"""
from __future__ import annotations

import numpy as np


def ols(y: np.ndarray, x: np.ndarray) -> dict:
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    mask = np.isfinite(y) & np.isfinite(x)
    y, x = y[mask], x[mask]
    if len(y) < 5:
        return {"n": int(len(y)), "intercept": None, "slope": None, "r2": None}
    X = np.column_stack([np.ones(len(x)), x])
    beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
    fitted = X @ beta
    resid = y - fitted
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = None if ss_tot <= 0 else float(1 - np.sum(resid ** 2) / ss_tot)
    return {
        "n": int(len(y)),
        "intercept": float(beta[0]),
        "slope": float(beta[1]),
        "r2": r2,
    }


def rolling_beta(y: np.ndarray, x: np.ndarray, window: int) -> dict:
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    n = len(y)
    slope = np.full(n, np.nan)
    r2 = np.full(n, np.nan)
    w = max(int(window), 10)
    for i in range(w, n + 1):
        fit = ols(y[i - w:i], x[i - w:i])
        if fit["slope"] is not None:
            slope[i - 1] = fit["slope"]
            r2[i - 1] = fit["r2"] if fit["r2"] is not None else np.nan
    return {"slope": slope, "r2": r2}


def realised_vol(log_returns: np.ndarray, window: int) -> np.ndarray:
    r = np.asarray(log_returns, dtype=float)
    out = np.full(len(r), np.nan)
    w = max(int(window), 5)
    csum = np.cumsum(np.nan_to_num(r))
    csum2 = np.cumsum(np.nan_to_num(r) ** 2)
    valid = np.isfinite(r).astype(float)
    cv = np.cumsum(valid)
    for i in range(w, len(r) + 1):
        n = cv[i - 1] - (cv[i - w - 1] if i - w - 1 >= 0 else 0)
        if n < w * 0.8:
            continue
        s = csum[i - 1] - (csum[i - w - 1] if i - w - 1 >= 0 else 0)
        s2 = csum2[i - 1] - (csum2[i - w - 1] if i - w - 1 >= 0 else 0)
        var = s2 / n - (s / n) ** 2
        out[i - 1] = np.sqrt(max(var, 0.0) * 252)
    return out


def ou_params(vol: np.ndarray) -> dict:
    """Daily AR(1) on log vol. Kappa is annualised as -ln(phi) * 252."""
    v = np.asarray(vol, dtype=float)
    mask = np.isfinite(v) & (v > 0)
    x = np.log(v[mask])
    if len(x) < 20:
        return {"kappa": None, "xi": None, "rho_proxy": None}
    lag = x[:-1]
    now = x[1:]
    fit = ols(now, lag)
    phi = fit["slope"]
    if phi is None or phi <= 0 or phi >= 1.2:
        kappa = None
    else:
        kappa = float(-np.log(min(phi, 0.999)) * 252)
    resid = now - (fit["intercept"] + phi * lag) if phi is not None and fit["intercept"] is not None else None
    xi = None if resid is None else float(np.std(resid) * np.sqrt(252))
    return {"kappa": kappa, "xi": xi}


def analyse(futures: np.ndarray, atm: np.ndarray, rr: np.ndarray | None, window: int) -> dict:
    f = np.asarray(futures, dtype=float)
    v = np.asarray(atm, dtype=float)
    logf = np.log(np.maximum(f, 1e-12))
    dlog = np.diff(logf, prepend=np.nan)
    dv = np.diff(v, prepend=np.nan)
    levels = ols(v, logf)
    changes = ols(dv, dlog)
    roll = rolling_beta(dv, dlog, window)
    rv = realised_vol(dlog, window)
    vrp = v - rv

    def _opt(arr: np.ndarray) -> list:
        return [None if not np.isfinite(x) else float(x) for x in arr]
    rr_fit = None
    if rr is not None:
        rr_fit = ols(np.diff(np.asarray(rr, dtype=float), prepend=np.nan), dlog)
    # Spot-vol correlation of daily changes, for the Monte Carlo rho.
    mask = np.isfinite(dv) & np.isfinite(dlog)
    rho = None
    if mask.sum() > 10 and np.std(dv[mask]) > 0 and np.std(dlog[mask]) > 0:
        rho = float(np.corrcoef(dv[mask], dlog[mask])[0, 1])
    ou = ou_params(v)
    return {
        "levels": levels,
        "changes": changes,
        "rolling_slope": _opt(roll["slope"]),
        "rolling_r2": _opt(roll["r2"]),
        "realised_vol": _opt(rv),
        "vol_risk_premium": _opt(vrp),
        "rr_changes": rr_fit,
        "rho": rho,
        "ou": ou,
        "beta": changes["slope"],
    }
