"""SABR smile for one expiry: Hagan's lognormal implied vol, calibration and density checks.

Convention follows the desk recipe: fix beta, solve alpha from the ATM vol so the fit pins the
ATM, and calibrate rho and nu to the rest of the chain. Vols are absolute (0.48 is 48 vol), the
forward is the future, and prices are Black-76 on that future.

``density`` prices calls on a fine strike grid from the fitted vols and checks the two static
no-arbitrage conditions a smile can break: calls must fall with strike no faster than one-for-one
(vertical spreads), and must be convex in strike (butterflies, i.e. a non-negative density).
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import least_squares

from app.quant.black76 import price

# Lognormal backbone. Beta is close to unidentifiable from one day's chain, so it is fixed and the
# smile dynamics are handled by the sticky-strike / sticky-delta regimes in the pricer.
DEFAULT_BETA = 1.0
RHO_BOUNDS = (-0.999, 0.999)
NU_BOUNDS = (1e-3, 10.0)


def hagan_vol(F, K, T, alpha: float, beta: float, rho: float, nu: float) -> np.ndarray:
    """Hagan et al. (2002) lognormal implied vol. Broadcasts over K."""
    F = float(F)
    K = np.asarray(K, dtype=float)
    T = float(T)
    one_b = 1.0 - beta
    fk = F * K
    fk_pow = fk ** (one_b / 2.0)
    log_fk = np.log(F / K)
    z = (nu / alpha) * fk_pow * log_fk
    sqrt_term = np.sqrt(np.maximum(1.0 - 2.0 * rho * z + z * z, 0.0))
    x = np.log(np.maximum((sqrt_term + z - rho) / (1.0 - rho), 1e-300))
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(np.abs(z) < 1e-7, 1.0 - 0.5 * rho * z, z / x)
    pre = alpha / (fk_pow * (1.0 + one_b**2 / 24.0 * log_fk**2 + one_b**4 / 1920.0 * log_fk**4))
    correction = 1.0 + (one_b**2 / 24.0 * alpha**2 / fk**one_b + 0.25 * rho * beta * nu * alpha / fk_pow + (2.0 - 3.0 * rho**2) / 24.0 * nu**2) * T
    return np.maximum(pre * ratio * correction, 1e-4)


def alpha_from_atm(F: float, T: float, atm: float, beta: float, rho: float, nu: float) -> float:
    """Smallest positive root of the cubic that makes Hagan's ATM vol equal ``atm``."""
    one_b = 1.0 - beta
    f_pow = F**one_b
    coef = [
        one_b**2 * T / (24.0 * f_pow**2),
        0.25 * rho * beta * nu * T / f_pow,
        1.0 + (2.0 - 3.0 * rho**2) / 24.0 * nu**2 * T,
        -atm * f_pow,
    ]
    roots = np.roots(coef)
    real = [r.real for r in roots if abs(r.imag) < 1e-9 and r.real > 0]
    return float(min(real)) if real else float(atm * f_pow)


def calibrate(
    strikes,
    vols,
    F: float,
    T: float,
    atm: float,
    beta: float = DEFAULT_BETA,
    weights=None,
) -> dict:
    """Fit rho and nu with alpha pinned to ``atm``. Returns the parameters and the fit error.

    Several starts guard against the local minima the (rho, nu) surface has when the chain is short.
    """
    K = np.asarray(strikes, dtype=float)
    v = np.asarray(vols, dtype=float)
    w = np.ones_like(v) if weights is None else np.asarray(weights, dtype=float)

    def residuals(p):
        rho, nu = p
        alpha = alpha_from_atm(F, T, atm, beta, rho, nu)
        return w * (hagan_vol(F, K, T, alpha, beta, rho, nu) - v)

    best = None
    for rho0, nu0 in ((0.0, 0.5), (-0.4, 1.0), (0.4, 1.0), (0.0, 2.0)):
        try:
            sol = least_squares(residuals, x0=[rho0, nu0], bounds=([RHO_BOUNDS[0], NU_BOUNDS[0]], [RHO_BOUNDS[1], NU_BOUNDS[1]]), xtol=1e-10, ftol=1e-10)
        except Exception:
            continue
        if best is None or sol.cost < best.cost:
            best = sol
    if best is None:
        raise ValueError("SABR calibration did not converge.")
    rho, nu = (float(x) for x in best.x)
    alpha = alpha_from_atm(F, T, atm, beta, rho, nu)
    fitted = hagan_vol(F, K, T, alpha, beta, rho, nu)
    return {
        "model": "sabr",
        "alpha": alpha,
        "beta": float(beta),
        "rho": rho,
        "nu": nu,
        "atm": float(atm),
        "rmse": float(np.sqrt(np.mean((fitted - v) ** 2))),
        "max_abs": float(np.max(np.abs(fitted - v))),
        "n": int(len(K)),
    }


def vol(params: dict, F: float, K, T: float) -> np.ndarray:
    return hagan_vol(F, K, T, params["alpha"], params["beta"], params["rho"], params["nu"])


def density(F: float, T: float, strikes, vols, tol: float = 1e-6) -> dict:
    """Static-arbitrage check of a smile given on a strike grid.

    Calls are priced from the vols, undiscounted. ``vertical`` lists strikes where the call falls
    faster than one-for-one or rises; ``butterfly`` lists strikes where the density goes negative.
    ``min_density`` is the most negative second difference per unit strike squared, scaled by F so
    it is comparable across products.
    """
    K = np.asarray(strikes, dtype=float)
    v = np.asarray(vols, dtype=float)
    order = np.argsort(K)
    K, v = K[order], v[order]
    C = np.asarray(price(F, K, v, T, 0.0, 1.0), dtype=float)
    dK = np.diff(K)
    slope = np.diff(C) / dK
    vertical = K[1:][(slope > tol) | (slope < -1.0 - tol)]
    curvature = np.diff(slope) / (0.5 * (dK[1:] + dK[:-1]))
    butterfly = K[1:-1][curvature < -tol / F]
    return {
        "vertical": vertical.tolist(),
        "butterfly": butterfly.tolist(),
        "min_density": float(np.min(curvature) * F) if len(curvature) else None,
        "ok": len(vertical) == 0 and len(butterfly) == 0,
    }


def static_checks(strikes, calls, tick: float | None = None, F: float | None = None) -> dict:
    """The same two conditions on raw call prices, with a tolerance for prices rounded to a tick.

    Call prices on a chain of futures-style options: C = P + F - K for the puts. Each price is
    rounded to the tick, so a slope can be off by two ticks over the strike gap and a butterfly by
    about four ticks; violations inside that are rounding, not arbitrage.
    """
    K = np.asarray(strikes, dtype=float)
    C = np.asarray(calls, dtype=float)
    order = np.argsort(K)
    K, C = K[order], C[order]
    if len(K) < 3:
        return {"vertical": [], "butterfly": [], "n": int(len(K)), "ok": True}
    tick = float(tick) if tick else 0.0
    dK = np.diff(K)
    slope = np.diff(C) / dK
    slope_tol = 2.0 * tick / dK + 1e-9
    vertical = K[1:][(slope > slope_tol) | (slope < -1.0 - slope_tol)]
    # Butterfly: long K1, short 2 K2 (weighted for uneven spacing), long K3 must not cost less than zero.
    left = dK[:-1]
    right = dK[1:]
    fly = C[:-2] * right + C[2:] * left - C[1:-1] * (left + right)
    fly_tol = 2.0 * tick * (left + right) + 1e-9
    butterfly = K[1:-1][fly < -fly_tol]
    return {
        "vertical": vertical.tolist(),
        "butterfly": butterfly.tolist(),
        "n": int(len(K)),
        "ok": len(vertical) == 0 and len(butterfly) == 0,
    }
