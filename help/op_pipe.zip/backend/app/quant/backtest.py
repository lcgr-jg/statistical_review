"""Historical studies of a structure on a product's continuous generic history.

Backtest: enter the same structure (same deltas or % of forward, same days to expiry) every
``every`` sessions, price it with the app's pricer at that day's constant-maturity ATM plus
today's smile shape, and value it at the front expiry on the continuous futures path.
Optionally delta-hedge daily with the structure's forward delta.

Hedging uses the smile-consistent delta by default: the package is repriced with the future bumped
up and down under the chosen regime, so under sticky-delta the hedge includes the vol change a
fixed strike sees when the future moves (Bartlett's delta). ``hedge_delta="black"`` uses the plain
Black-76 forward delta instead. Costs: ``hedge_cost_bps`` is charged on the notional of every
futures trade (initial hedge, each rebalance, the unwind at expiry); ``hedge_band`` (in lots) is the
delta gap that triggers a rebalance; ``entry_cost_vol`` is the half spread paid on entry, in
absolute vol per unit of each leg's vega.

Each trade's option P&L is split day by day into delta, gamma, theta, vega and a residual, with the
previous day's greeks (vega against the front tenor's ATM change). Gamma plus theta is the carry,
the term ½ Γ F² (σ_realised² − σ_implied²) dt that tells you whether the vol was worth owning.

Assumptions the user must see: the smile shape (pillar minus ATM) is today's, not the historical
one; every expiry shares the generic forward; ATM for a tenor is interpolated between the 30 and
60 day constant-maturity vols and is flat outside that range.
"""
from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd

from app.market.generic import iv_at
from app.quant.black76 import greeks
from app.quant.regimes import by_regime
from app.quant.structures import _leg_vol, _skew_name, prepare_slices, price_package, resolve_legs, summarise
from app.schemas import ExpirySliceIn, LegIn, MarketIn

SESSIONS = 252
IV_GAP_FILL = 5
ASSUMPTIONS = [
    "Smile shape (each pillar minus ATM) is today's, applied to the historical ATM.",
    "ATM for a tenor is interpolated between the 30d and 60d constant-maturity implied vols, flat outside. "
    f"Gaps of up to {IV_GAP_FILL} sessions in the vol history are carried forward; the futures path is never gapped.",
    "All expiries share the generic forward; returns are roll-adjusted on the 1st generic.",
    "One structure is entered every N sessions and held to the front expiry, or to the last expiry when chosen; "
    "an expired leg is worth its intrinsic value on the generic forward until the exit.",
    "Hedge cost is charged on the notional of every futures trade, including the first hedge and the unwind at expiry. "
    "Entry cost is a half spread in vol applied to each leg's vega; the structure is held to expiry so no exit spread is paid.",
    "Attribution uses the previous day's greeks; vega is against the front tenor's ATM change.",
]


def _template(market: MarketIn, legs: list[LegIn]):
    """Express the loaded structure in relative terms: tenor in days, strike as delta or % of forward."""
    prepared = prepare_slices(market, market.as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    rows = []
    for leg, item in zip(legs, resolved):
        sl = item["slice"]
        tenor = max((sl.expiry - market.as_of).days, 1)
        if leg.strike_mode == "absolute":
            mode, strike = "pct_atm", float(leg.strike) / sl.forward
        else:
            mode, strike = leg.strike_mode, float(leg.strike)
        rows.append({"call_put": leg.call_put, "qty": float(leg.qty), "strike_mode": mode, "strike": strike, "tenor": tenor, "vol": leg.vol})
    offsets = {}
    for sl in market.slices:
        tenor = max((sl.expiry - market.as_of).days, 1)
        atm = sl.pillars.get("50D")
        offsets[tenor] = {k: (v - atm if v is not None and atm is not None else None) for k, v in sl.pillars.items() if k != "50D"}
    return rows, offsets


def _market_on(day: pd.Timestamp, forward: float, atm_by_tenor: dict[int, float], offsets: dict[int, dict], base: MarketIn) -> MarketIn:
    slices = []
    for tenor, atm in sorted(atm_by_tenor.items()):
        pillars = {"50D": atm}
        for name, off in (offsets.get(tenor) or {}).items():
            pillars[name] = None if off is None else max(atm + off, 0.01)
        slices.append(ExpirySliceIn(expiry=day.date() + timedelta(days=tenor), forward=forward, pillars=pillars))
    return MarketIn(as_of=day.date(), rate=base.rate, multiplier=base.multiplier, currency=base.currency, unit=base.unit, beta=base.beta, slices=slices)


def _first_on_or_after(index: pd.DatetimeIndex, start: int, target: pd.Timestamp) -> int | None:
    pos = int(index.searchsorted(target, side="left"))
    return pos if pos < len(index) and pos > start else None


def _gross_vega(resolved, forward: float, atm: dict, T: dict, rate: float, skew: str, follow_beta: bool, mult: float) -> float:
    """Sum of |qty x vega| over the legs, the vega the entry spread is paid on."""
    total = 0.0
    for leg in resolved:
        exp = leg["slice"].expiry
        vol = _leg_vol(leg, forward, atm[exp], T[exp], skew, follow_beta)
        g = greeks(forward, leg["strike"], vol, T[exp], rate, leg["cp"])
        total += abs(float(np.asarray(g["vega"])) * leg["qty"] * mult)
    return total


def run_backtest(
    market: MarketIn,
    legs: list[LegIn],
    regime: str,
    hist: pd.DataFrame,
    every: int = 21,
    hedge: bool = False,
    max_trades: int = 150,
    hedge_delta: str = "smile",
    hedge_cost_bps: float = 0.0,
    hedge_band: float = 0.0,
    entry_cost_vol: float = 0.0,
    hold: str = "front",
) -> dict:
    rows, offsets = _template(market, legs)
    tenors = sorted({r["tenor"] for r in rows})
    front = tenors[0]
    hold_days = tenors[-1] if hold == "last" else front
    skew = _skew_name(regime)
    follow_beta = regime == "beta"
    rate = market.rate
    mult = market.multiplier

    # The futures path is cumulated on the full frame, before any vol-driven row drops, so a day
    # with no implied vol still contributes its move. Short vol gaps are carried forward.
    full = hist.sort_index()
    full = full.assign(logp=np.cumsum(np.nan_to_num(full["ret"].to_numpy(dtype=float))))
    filled = full[["iv30", "iv60"]].ffill(limit=IV_GAP_FILL)
    hist = full.assign(iv30=filled["iv30"], iv60=filled["iv60"]).dropna(subset=["iv30"])
    if len(hist) < 60:
        raise ValueError("Fewer than 60 sessions with implied vol history.")
    index = pd.DatetimeIndex(hist.index)
    logp = hist["logp"].to_numpy(dtype=float)
    iv30 = hist["iv30"].to_numpy(dtype=float)
    iv60 = hist["iv60"].fillna(hist["iv30"]).to_numpy(dtype=float)
    full_ret = full["ret"]
    cost_rate = float(hedge_cost_bps) / 1e4
    band = float(hedge_band) * mult

    def atm_for(k, days_left):
        """Constant-maturity ATM at row(s) ``k`` for ``days_left`` to expiry. Broadcasts."""
        w = np.clip((np.asarray(days_left, dtype=float) - 30.0) / 30.0, 0.0, 1.0)
        return (1.0 - w) * iv30[k] + w * iv60[k]

    trades = []
    pos = 0
    while pos < len(index) and len(trades) < max_trades:
        entry_day = index[pos]
        exit_pos = _first_on_or_after(index, pos, entry_day + timedelta(days=hold_days))
        if exit_pos is None:
            break
        atm0 = {t: float(atm_for(pos, t)) for t in tenors}
        if not all(np.isfinite(v) for v in atm0.values()):
            pos += every
            continue
        F0 = float(hist["f1"].iloc[pos])
        entry_market = _market_on(entry_day, F0, atm0, offsets, market)
        entry_legs = [
            LegIn(call_put=r["call_put"], qty=r["qty"], strike_mode=r["strike_mode"], strike=r["strike"], expiry=entry_day.date() + timedelta(days=r["tenor"]), vol=r["vol"])
            for r in rows
        ]
        prepared = prepare_slices(entry_market, entry_market.as_of)
        by_exp, resolved = resolve_legs(prepared, entry_legs)
        expiries = {exp: (sl.expiry - entry_day.date()).days for exp, (sl, _, _) in by_exp.items()}
        front_exp = min(expiries, key=expiries.get)
        last_exp = max(expiries, key=expiries.get)

        # Whole holding period in one vectorised reprice: rows pos..exit_pos.
        ks = np.arange(pos, exit_pos + 1)
        days = index[ks]
        F = F0 * np.exp(logp[ks] - logp[pos])
        elapsed = np.array([(d - entry_day).days for d in days], dtype=float)
        T = {exp: np.maximum(n - elapsed, 0.0) / 365.25 for exp, n in expiries.items()}
        atm = {}
        for exp, n in expiries.items():
            a = atm_for(ks, np.maximum(n - elapsed, 1.0))
            atm[exp] = np.where(np.isfinite(a), a, atm0[n])

        # A leg that expires before the exit is exercised into the future if in the money on the
        # first session on or after its expiry, and is worth nothing afterwards if not.
        exercised = {}
        for j, leg in enumerate(resolved):
            dead = np.nonzero(T[leg["slice"].expiry] <= 0)[0]
            if len(dead):
                exercised[j] = leg["cp"] * (F[dead[0]] - leg["strike"]) > 0

        def mark(fwd_arr, atm_dict, T_dict):
            out = price_package(resolved, {exp: fwd_arr for exp in expiries}, atm_dict, T_dict, rate, skew, follow_beta, mult)
            for j, itm in exercised.items():
                leg = resolved[j]
                dead = T_dict[leg["slice"].expiry] <= 0
                linear = leg["cp"] * (fwd_arr - leg["strike"])
                w = leg["qty"] * mult
                held = linear if itm else 0.0
                out["price"] = out["price"] + np.where(dead, w * (held - np.maximum(linear, 0.0)), 0.0)
                held_delta = leg["cp"] if itm else 0.0
                for key in ("delta", "forward_delta"):
                    out[key] = out[key] + np.where(dead, w * (held_delta - np.where(linear > 0, leg["cp"], 0.0)), 0.0)
            return out

        out = mark(F, atm, T)
        price = np.asarray(out["price"], dtype=float)
        cash_delta = np.asarray(out["delta"], dtype=float)
        gamma = np.asarray(out["gamma"], dtype=float)
        vega = np.asarray(out["vega"], dtype=float)
        T_hold = T[last_exp if hold == "last" else front_exp]
        if hedge_delta == "black":
            hedge_target = np.asarray(out["forward_delta"], dtype=float)
        else:
            bump = F * 1e-4
            up = np.asarray(mark(F + bump, atm, T)["price"], dtype=float)
            down = np.asarray(mark(F - bump, atm, T)["price"], dtype=float)
            hedge_target = (up - down) / (2.0 * bump) * np.exp(rate * T_hold)
        hedge_target = np.where(T_hold > 0, hedge_target, 0.0)

        # Attribution with the previous day's greeks. Theta is a full reprice of yesterday's
        # market at today's time, so a flat day decays by theta with no residual.
        dF = np.diff(F)
        d_sig = np.diff(atm[front_exp])
        aged = np.asarray(
            mark(F[:-1], {exp: atm[exp][:-1] for exp in expiries}, {exp: T[exp][1:] for exp in expiries})["price"],
            dtype=float,
        )
        theta_pnl = aged - price[:-1]
        delta_pnl = cash_delta[:-1] * dF
        gamma_pnl = 0.5 * gamma[:-1] * dF * dF
        vega_pnl = vega[:-1] * d_sig
        steps = np.diff(price)
        residual = steps - (delta_pnl + gamma_pnl + theta_pnl + vega_pnl)

        hedge_pnl = 0.0
        hedge_cost = 0.0
        if hedge:
            held = -hedge_target[0]
            hedge_cost += abs(held) * F[0] * cost_rate
            for i in range(1, len(F)):
                hedge_pnl += held * dF[i - 1]
                if i == len(F) - 1:
                    hedge_cost += abs(held) * F[i] * cost_rate
                    held = 0.0
                    break
                target = -hedge_target[i]
                if abs(target - held) > band:
                    hedge_cost += abs(target - held) * F[i] * cost_rate
                    held = target
        entry_cost = 0.0
        if entry_cost_vol > 0:
            entry_cost = entry_cost_vol * _gross_vega(
                resolved, F0, {exp: float(atm[exp][0]) for exp in expiries}, {exp: float(T[exp][0]) for exp in expiries}, rate, skew, follow_beta, mult
            )

        pnl = float(price[-1] - price[0])
        window = full_ret.loc[entry_day : index[exit_pos]].to_numpy(dtype=float)[1:]
        rv = float(np.nanstd(window, ddof=1) * np.sqrt(SESSIONS)) if np.isfinite(window).sum() > 2 else None
        trades.append({
            "entry": entry_day.strftime("%Y-%m-%d"),
            "exit": index[exit_pos].strftime("%Y-%m-%d"),
            "forward_entry": F0,
            "forward_exit": float(F[-1]),
            "move": float(np.log(F[-1] / F0)),
            "atm_entry": atm0[front],
            "realised": rv,
            "premium": float(price[0]),
            "value_exit": float(price[-1]),
            "pnl": pnl,
            "delta_pnl": float(delta_pnl.sum()),
            "gamma_pnl": float(gamma_pnl.sum()),
            "theta_pnl": float(theta_pnl.sum()),
            "vega_pnl": float(vega_pnl.sum()),
            "residual_pnl": float(residual.sum()),
            "carry_pnl": float(gamma_pnl.sum() + theta_pnl.sum()),
            "hedge_pnl": hedge_pnl if hedge else None,
            "hedge_cost": hedge_cost if hedge else None,
            "entry_cost": entry_cost,
            "gross": pnl + hedge_pnl,
            "total": pnl + hedge_pnl - hedge_cost - entry_cost,
        })
        pos += every

    if not trades:
        raise ValueError("No complete trades in the history window. Try more years or a shorter expiry.")
    totals = np.array([t["total"] for t in trades])
    order = np.argsort([t["exit"] for t in trades], kind="stable")
    equity = np.cumsum(totals[order])
    drawdown = equity - np.maximum.accumulate(np.maximum(equity, 0.0))
    years_span = max((pd.Timestamp(trades[-1]["exit"]) - pd.Timestamp(trades[0]["entry"])).days / 365.25, 1e-6)
    per_year = len(trades) / years_span
    std = float(totals.std(ddof=1)) if len(totals) > 1 else 0.0
    wins = totals[totals > 0]
    losses = totals[totals < 0]
    counts, edges = np.histogram(totals, bins=min(24, max(6, len(totals) // 3)))

    def mean_of(key: str) -> float | None:
        values = [t[key] for t in trades if t.get(key) is not None]
        return float(np.mean(values)) if values else None

    paired = [(t["realised"], t["atm_entry"]) for t in trades if t["realised"] is not None]
    return {
        "trades": trades,
        "equity": {"dates": [trades[i]["exit"] for i in order], "pnl": equity.tolist(), "drawdown": drawdown.tolist()},
        "histogram": {"counts": counts.tolist(), "edges": edges.tolist()},
        "regimes": by_regime(trades),
        "metrics": {
            "n": len(trades),
            "hit_rate": float((totals > 0).mean()),
            "mean": float(totals.mean()),
            "median": float(np.median(totals)),
            "std": std,
            "best": float(totals.max()),
            "worst": float(totals.min()),
            "total": float(totals.sum()),
            "gross_total": float(sum(t["gross"] for t in trades)),
            "avg_premium": mean_of("premium"),
            "profit_factor": float(wins.sum() / -losses.sum()) if len(losses) and losses.sum() < 0 else None,
            "sharpe": float(totals.mean() / std * np.sqrt(per_year)) if std > 0 else None,
            "max_drawdown": float(drawdown.min()),
            "trades_per_year": per_year,
            "attribution": {
                "delta": mean_of("delta_pnl"),
                "gamma": mean_of("gamma_pnl"),
                "theta": mean_of("theta_pnl"),
                "carry": mean_of("carry_pnl"),
                "vega": mean_of("vega_pnl"),
                "residual": mean_of("residual_pnl"),
                "hedge": mean_of("hedge_pnl"),
                "hedge_cost": mean_of("hedge_cost"),
                "entry_cost": mean_of("entry_cost"),
            },
            "mean_realised_minus_implied": float(np.mean([rv - iv for rv, iv in paired])) if paired else None,
            "share_realised_above_implied": float(np.mean([rv > iv for rv, iv in paired])) if paired else None,
        },
        "settings": {
            "every": every,
            "hedge": hedge,
            "hedge_delta": hedge_delta if hedge else None,
            "hedge_cost_bps": float(hedge_cost_bps) if hedge else None,
            "hedge_band": float(hedge_band) if hedge else None,
            "entry_cost_vol": float(entry_cost_vol),
            "front_days": front,
            "hold": hold,
            "hold_days": hold_days,
            "tenors": tenors,
            "from": trades[0]["entry"],
            "to": trades[-1]["exit"],
        },
        "assumptions": ASSUMPTIONS,
    }


def breakeven_analysis(market: MarketIn, legs: list[LegIn], regime: str, hist: pd.DataFrame) -> dict:
    """Breakevens of the loaded structure against what history did over the same number of days."""
    summary = summarise(market, legs, regime, regime == "beta", market.as_of)
    prepared = prepare_slices(market, market.as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    primary = min(item["slice"].expiry for item in resolved)
    sl = by_exp[primary][0]
    tenor = max((primary - market.as_of).days, 1)
    forward = sl.forward
    atm = sl.pillars.get("50D")

    index = pd.DatetimeIndex(hist.index)
    rets = np.nan_to_num(hist["ret"].to_numpy())
    logp = np.concatenate([[0.0], np.cumsum(rets[1:])])
    iv_tenor = iv_at(hist, tenor).to_numpy()
    moves, rvs, ivs, dates = [], [], [], []
    for pos in range(len(index)):
        end = _first_on_or_after(index, pos, index[pos] + timedelta(days=tenor))
        if end is None:
            break
        moves.append(logp[end] - logp[pos])
        window = rets[pos + 1 : end + 1]
        rvs.append(float(np.std(window, ddof=1) * np.sqrt(SESSIONS)) if len(window) > 2 else np.nan)
        ivs.append(float(iv_tenor[pos]) if np.isfinite(iv_tenor[pos]) else np.nan)
        dates.append(index[pos].strftime("%Y-%m-%d"))
    if len(moves) < 20:
        raise ValueError("Not enough history for this many days to expiry.")
    moves_a = np.array(moves)
    rvs_a = np.array(rvs)
    ivs_a = np.array(ivs)

    levels = []
    for b in summary["breakevens"]:
        if b is None or b <= 0:
            continue
        move = float(np.log(b / forward))
        frac = float((moves_a >= move).mean()) if move > 0 else float((moves_a <= move).mean())
        levels.append({"price": float(b), "move": move, "direction": "up" if move > 0 else "down", "hist_prob_beyond": frac})

    valid_rv = rvs_a[np.isfinite(rvs_a)]
    paired = np.isfinite(rvs_a) & np.isfinite(ivs_a)
    counts, edges = np.histogram(moves_a, bins=40)
    return {
        "tenor_days": tenor,
        "forward": forward,
        "premium": summary["premium"],
        "atm": atm,
        "breakevens": levels,
        "moves": {"counts": counts.tolist(), "edges": edges.tolist(), "p5": float(np.percentile(moves_a, 5)), "p95": float(np.percentile(moves_a, 95)), "std": float(moves_a.std())},
        "realised": {
            "dates": dates,
            "rv": [None if not np.isfinite(v) else v for v in rvs_a.tolist()],
            "iv": [None if not np.isfinite(v) else v for v in ivs_a.tolist()],
            "median": float(np.median(valid_rv)) if len(valid_rv) else None,
            "p25": float(np.percentile(valid_rv, 25)) if len(valid_rv) else None,
            "p75": float(np.percentile(valid_rv, 75)) if len(valid_rv) else None,
            "share_above_atm": float((valid_rv > atm).mean()) if len(valid_rv) and atm else None,
            "mean_iv_minus_rv": float(np.mean(ivs_a[paired] - rvs_a[paired])) if paired.any() else None,
        },
        "n_windows": len(moves),
    }


def seasonality(hist: pd.DataFrame) -> dict:
    """Monthly average 30d ATM implied and 20d realised, by year and across years."""
    frame = pd.DataFrame(index=pd.DatetimeIndex(hist.index))
    frame["iv"] = hist["iv30"].to_numpy()
    frame["rv"] = (hist["ret"].rolling(20, min_periods=16).std() * np.sqrt(SESSIONS)).to_numpy()
    frame["year"] = frame.index.year
    frame["month"] = frame.index.month
    by = frame.groupby(["year", "month"])[["iv", "rv"]].mean()
    years = sorted(frame["year"].unique().tolist())
    out_years = {}
    for y in years:
        row = []
        for m in range(1, 13):
            try:
                v = by.loc[(y, m), "iv"]
                row.append(None if not np.isfinite(v) else float(v))
            except KeyError:
                row.append(None)
        out_years[str(y)] = row
    stats = []
    for m in range(1, 13):
        iv = by.xs(m, level="month")["iv"].dropna() if m in by.index.get_level_values("month") else pd.Series(dtype=float)
        rv = by.xs(m, level="month")["rv"].dropna() if m in by.index.get_level_values("month") else pd.Series(dtype=float)
        stats.append({
            "month": m,
            "iv_mean": float(iv.mean()) if len(iv) else None,
            "iv_min": float(iv.min()) if len(iv) else None,
            "iv_max": float(iv.max()) if len(iv) else None,
            "rv_mean": float(rv.mean()) if len(rv) else None,
            "years": int(len(iv)),
        })
    last = frame["iv"].dropna()
    return {
        "years": out_years,
        "months": stats,
        "current": {"date": last.index[-1].strftime("%Y-%m-%d"), "iv": float(last.iloc[-1]), "month": int(last.index[-1].month)} if len(last) else None,
    }


def skew_slope(hist: pd.DataFrame) -> dict:
    """30d call wing minus put wing (110% − 90% moneyness) and 60d minus 30d ATM, with percentiles."""
    frame = pd.DataFrame(index=pd.DatetimeIndex(hist.index))
    frame["atm"] = hist["iv30"].to_numpy()
    frame["skew"] = (hist["iv110m"] - hist["iv90m"]).to_numpy()
    frame["slope"] = (hist["iv60"] - hist["iv30"]).to_numpy()
    frame = frame.dropna(how="all")

    def stat(col: str) -> dict:
        s = frame[col].dropna()
        if not len(s):
            return {"current": None, "percentile": None, "mean": None, "z": None}
        cur = float(s.iloc[-1])
        std = float(s.std())
        return {
            "current": cur,
            "percentile": float((s <= cur).mean()),
            "mean": float(s.mean()),
            "z": (cur - float(s.mean())) / std if std > 0 else None,
            "p10": float(s.quantile(0.1)),
            "p90": float(s.quantile(0.9)),
        }

    return {
        "dates": [d.strftime("%Y-%m-%d") for d in frame.index],
        "series": {col: [None if not np.isfinite(v) else float(v) for v in frame[col].to_numpy()] for col in ("atm", "skew", "slope")},
        "stats": {col: stat(col) for col in ("atm", "skew", "slope")},
    }
