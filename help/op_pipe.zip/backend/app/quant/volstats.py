"""Implied against realised vol, spot-vol co-movement and the realised vol cone for one futures contract.

Inputs are daily closes of the future and of its ATM implied vol (absolute, 0.80 = 80%).
Realised vol is close-to-close, annualised with 252 sessions. Forward realised vol at date t is the
realised vol over the next ``window`` sessions, so implied at t can be compared with what followed.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from app.quant.regression import ols, ou_params

RV_WINDOWS = (10, 20, 60)
CONE_WINDOWS = (5, 10, 20, 40, 60, 120)
ROLL_WINDOW = 60
SESSIONS = 252


def _list(series: pd.Series | np.ndarray) -> list:
    values = series.to_numpy() if isinstance(series, pd.Series) else np.asarray(series)
    return [None if v is None or not np.isfinite(v) else float(v) for v in values]


def _rv(returns: pd.Series, window: int) -> pd.Series:
    return returns.rolling(window, min_periods=int(window * 0.8)).std() * np.sqrt(SESSIONS)


def analyse(frame: pd.DataFrame) -> dict:
    """``frame`` has a DatetimeIndex and columns futures, atm and optionally iv30."""
    frame = frame.sort_index()
    frame = frame[frame["futures"] > 0]
    if len(frame) < 30:
        raise ValueError("Fewer than 30 sessions of futures history.")
    logf = np.log(frame["futures"])
    ret = logf.diff()
    atm = frame["atm"]
    dvol = atm.diff()

    out = pd.DataFrame(index=frame.index)
    out["futures"] = frame["futures"]
    out["atm"] = atm
    out["iv30"] = frame["iv30"] if "iv30" in frame else np.nan
    for w in RV_WINDOWS:
        out[f"rv{w}"] = _rv(ret, w)
    out["rv20_fwd"] = _rv(ret, 20).shift(-20)
    out["vrp20"] = out["atm"] - out["rv20"]
    out["corr60"] = ret.rolling(ROLL_WINDOW, min_periods=40).corr(dvol)
    cov = ret.rolling(ROLL_WINDOW, min_periods=40).cov(dvol)
    var = ret.rolling(ROLL_WINDOW, min_periods=40).var()
    out["beta60"] = cov / var

    mask = ret.notna() & dvol.notna()
    changes = ols(dvol[mask].to_numpy(), ret[mask].to_numpy())
    corr = float(np.corrcoef(ret[mask], dvol[mask])[0, 1]) if mask.sum() > 10 else None
    lev_mask = atm.notna()
    levels = ols(atm[lev_mask].to_numpy(), logf[lev_mask].to_numpy())

    cone = []
    for w in CONE_WINDOWS:
        rv = _rv(ret, w).dropna()
        if len(rv) < 5:
            continue
        q = np.percentile(rv, [0, 10, 25, 50, 75, 90, 100])
        cone.append(
            {
                "window": w,
                "min": float(q[0]),
                "p10": float(q[1]),
                "p25": float(q[2]),
                "p50": float(q[3]),
                "p75": float(q[4]),
                "p90": float(q[5]),
                "max": float(q[6]),
                "current": float(rv.iloc[-1]),
            }
        )

    atm_valid = atm.dropna()
    last_atm = float(atm_valid.iloc[-1]) if len(atm_valid) else None
    pct = float((atm_valid <= atm_valid.iloc[-1]).mean()) if len(atm_valid) else None
    paired = out[["atm", "rv20_fwd"]].dropna()
    beta = changes["slope"]

    def last(col: str):
        s = out[col].dropna()
        return float(s.iloc[-1]) if len(s) else None

    return {
        "dates": [d.strftime("%Y-%m-%d") for d in out.index],
        "series": {col: _list(out[col]) for col in out.columns},
        "scatter": {
            "ret": _list(ret[mask]),
            "dvol": _list(dvol[mask]),
            "dates": [d.strftime("%Y-%m-%d") for d in ret[mask].index],
        },
        "levels_fit": levels,
        "changes_fit": {**changes, "corr": corr},
        "cone": cone,
        "stats": {
            "atm": last_atm,
            "atm_percentile": pct,
            "rv20": last("rv20"),
            "rv60": last("rv60"),
            "vrp20": last("vrp20"),
            "mean_premium_realised": float((paired["atm"] - paired["rv20_fwd"]).mean()) if len(paired) else None,
            "corr60": last("corr60"),
            "corr": corr,
            "beta": beta,
            "vol_pts_per_10pct": None if beta is None else float(beta * np.log(1.1) * 100),
            **{k: v for k, v in ou_params(atm.dropna().to_numpy()).items() if k in ("kappa", "xi")},
        },
    }
