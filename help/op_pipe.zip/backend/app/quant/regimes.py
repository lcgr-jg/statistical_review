"""Named market regimes for European energy, used to split backtests and to stress a book.

Windows are by entry date (backtests) or scenario start date (VaR). They overlap with nothing
except "All history", so a trade is counted in at most one named window.
"""
from __future__ import annotations

from datetime import date

import numpy as np

REGIMES: list[dict] = [
    {"id": "pre_covid", "label": "Pre-COVID", "start": "2015-01-01", "end": "2020-02-19",
     "note": "Oversupplied gas, low and stable vol."},
    {"id": "covid", "label": "COVID crash", "start": "2020-02-20", "end": "2020-06-30",
     "note": "Demand collapse; TTF fell below 4 EUR/MWh."},
    {"id": "recovery", "label": "Recovery", "start": "2020-07-01", "end": "2021-06-30",
     "note": "Demand recovers, storage tightens."},
    {"id": "energy_crisis", "label": "Energy crisis", "start": "2021-07-01", "end": "2022-12-31",
     "note": "Russian supply cuts; TTF above 300 in August 2022, vol over 150."},
    {"id": "normalisation", "label": "Normalisation", "start": "2023-01-01", "end": "2024-12-31",
     "note": "LNG replaces pipeline gas; prices and vol fall back."},
    {"id": "recent", "label": "2025 onwards", "start": "2025-01-01", "end": "2099-12-31",
     "note": "The latest regime."},
]


def regime_of(day: str | date) -> str | None:
    text = day.isoformat() if isinstance(day, date) else str(day)[:10]
    for regime in REGIMES:
        if regime["start"] <= text <= regime["end"]:
            return regime["id"]
    return None


def by_regime(trades: list[dict], key: str = "total", when: str = "entry") -> list[dict]:
    """Per named window: trade count, hit rate, mean, total and worst of ``key``."""
    out = []
    for regime in REGIMES:
        values = np.array([t[key] for t in trades if regime["start"] <= t[when] <= regime["end"] and t.get(key) is not None], dtype=float)
        paired = [
            t["realised"] - t["atm_entry"]
            for t in trades
            if regime["start"] <= t[when] <= regime["end"] and t.get("realised") is not None and t.get("atm_entry") is not None
        ]
        row = {k: regime[k] for k in ("id", "label", "start", "end", "note")}
        if len(values):
            row.update({
                "n": int(len(values)),
                "hit_rate": float((values > 0).mean()),
                "mean": float(values.mean()),
                "total": float(values.sum()),
                "worst": float(values.min()),
                "best": float(values.max()),
                "realised_minus_implied": float(np.mean(paired)) if paired else None,
            })
        else:
            row.update({"n": 0, "hit_rate": None, "mean": None, "total": None, "worst": None, "best": None, "realised_minus_implied": None})
        out.append(row)
    return out
