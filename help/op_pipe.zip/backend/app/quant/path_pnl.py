"""Reprice a structure along a spot and ATM-vol path and attribute the P&L.

The path is a list of (t, forward, atm vol) with t in years from as-of. It is
resampled onto a daily grid. Each day's P&L is the change in present value.
The Taylor terms use the previous day's greeks:

    delta dF + 1/2 gamma dF^2 + theta dt + vega dSig
        + vanna dF dSig + 1/2 volga dSig^2

Theta is the calendar derivative, so theta * dt is the decay over a step of
dt years. The residual is the part the expansion does not explain. Including
the residual, the components sum to the day's P&L.

A delta hedge is a position of minus the forward delta, variation-margined.
The present value of each margin payment is discounted from the step date.
Rehedge daily or every seventh calendar day.
"""
from __future__ import annotations

from datetime import date

import numpy as np

from app.quant.structures import _skew_name, prepare_slices, price_package, resolve_legs


def _resample(points: list[dict], T: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    pts = sorted(points, key=lambda p: p["t"])
    if len(pts) < 2:
        raise ValueError("A path needs a start and an end.")
    t = np.array([p["t"] for p in pts], dtype=float)
    if t[0] > 1e-6:
        raise ValueError("The path must start at t = 0.")
    if t[-1] < T - 1.5 / 365.25:
        raise ValueError("The path must run to expiry.")
    f = np.array([p["forward"] for p in pts], dtype=float)
    sig = np.array([p["atm_vol"] for p in pts], dtype=float)
    n = int(np.clip(round(T * 365.25) + 1, 2, 500))
    grid = np.linspace(0.0, T, n)
    return grid, np.interp(grid, t, f), np.interp(grid, t, sig)


def evaluate_path(market, legs, regime: str, points: list[dict], hedge: str, vol_source: str, as_of: date) -> dict:
    prepared = prepare_slices(market, as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    primary = min(leg["slice"].expiry for leg in resolved)
    _, T0, _ = by_exp[primary]
    if T0 <= 1e-6:
        raise ValueError("The primary expiry has no time left.")

    ts, spot, atm = _resample(points, T0)
    follow_beta = vol_source == "beta"
    skew = _skew_name(regime)
    rate = market.rate
    mult = market.multiplier
    f0 = by_exp[primary][0].forward
    forwards0 = {sl.expiry: sl.forward for sl, _, _ in prepared}
    atms0 = {sl.expiry: smile.atm for sl, _, smile in prepared}

    def mark(spot_value: float, atm_value: float, elapsed: float) -> dict[str, float]:
        ratio = spot_value / f0
        fwd = {exp: forwards0[exp] * ratio for exp in forwards0}
        shift = atm_value - atms0[primary]
        a = {exp: max(atms0[exp] + shift, 1e-3) for exp in atms0}
        trem = {exp: max(by_exp[exp][1] - elapsed, 0.0) for exp in by_exp}
        packed = price_package(resolved, fwd, a, trem, rate, skew, follow_beta, mult)
        return {k: float(np.asarray(v)) for k, v in packed.items()}

    def value_and_greeks(i: int) -> dict[str, float]:
        return mark(float(spot[i]), float(atm[i]), float(ts[i]))

    rows = []
    prev = value_and_greeks(0)
    cum_hedge = 0.0
    cum = {k: 0.0 for k in ("delta", "gamma", "theta", "vega", "vanna", "volga", "residual", "hedge")}
    step_days = 7 if hedge == "weekly" else 1
    # Hold minus the forward delta. Every slice is shifted with the primary,
    # so this delta is the sensitivity of the package to `spot`.
    hedge_pos = 0.0 if hedge == "none" else -prev["forward_delta"]

    rows.append(_row(ts[0], spot[0], atm[0], prev, {k: 0.0 for k in cum}, 0.0, 0.0))

    for i in range(1, len(ts)):
        cur = value_and_greeks(i)
        dF = spot[i] - spot[i - 1]
        d_sig = atm[i] - atm[i - 1]
        if follow_beta:
            # Beta ignores the drawn vol. Attribute vega to the vol that was priced.
            smile = by_exp[primary][2]
            used_prev = float(np.asarray(smile.resolve_atm(spot[i - 1], atm[i - 1], True)))
            used_cur = float(np.asarray(smile.resolve_atm(spot[i], atm[i], True)))
            d_sig = used_cur - used_prev
        # Theta is a full reprice with the market held at the previous close,
        # so a path that does not move decays by theta with no residual.
        aged = mark(float(spot[i - 1]), float(atm[i - 1]), float(ts[i]))
        theta_pnl = aged["price"] - prev["price"]
        delta_pnl = aged["delta"] * dF
        gamma_pnl = 0.5 * aged["gamma"] * dF * dF
        vega_pnl = aged["vega"] * d_sig
        vanna_pnl = aged["vanna"] * dF * d_sig
        volga_pnl = 0.5 * aged["volga"] * d_sig * d_sig
        explained = delta_pnl + gamma_pnl + theta_pnl + vega_pnl + vanna_pnl + volga_pnl
        step = cur["price"] - prev["price"]
        residual = step - explained
        hedge_step = 0.0
        if hedge != "none":
            hedge_step = float(np.exp(-rate * ts[i]) * hedge_pos * dF)
            cum_hedge += hedge_step
            if i % step_days == 0:
                hedge_pos = -cur["forward_delta"]
        for key, bit in (
            ("delta", delta_pnl),
            ("gamma", gamma_pnl),
            ("theta", theta_pnl),
            ("vega", vega_pnl),
            ("vanna", vanna_pnl),
            ("volga", volga_pnl),
            ("residual", residual),
            ("hedge", hedge_step),
        ):
            cum[key] += bit
        rows.append(_row(ts[i], spot[i], atm[i], cur, cum, step, cur["price"] - rows[0]["value"]))
        prev = cur

    total = rows[-1]["pnl"]
    hedged_total = total + cum_hedge
    return {
        "T": T0,
        "hedge": hedge,
        "vol_source": vol_source,
        "pnl": total,
        "hedged_pnl": hedged_total,
        "attribution": {k: cum[k] for k in ("delta", "gamma", "theta", "vega", "vanna", "volga", "residual")},
        "rows": rows,
    }


def _row(t, forward, atm, greeks_now, cum, step, pnl) -> dict:
    return {
        "t": float(t),
        "forward": float(forward),
        "atm_vol": float(atm),
        "value": greeks_now["price"],
        "step_pnl": float(step),
        "pnl": float(pnl),
        "delta": greeks_now["delta"],
        "gamma": greeks_now["gamma"],
        "vega": greeks_now["vega"],
        "theta": greeks_now["theta"],
        "vanna": greeks_now["vanna"],
        "volga": greeks_now["volga"],
        "delta_pnl": cum["delta"],
        "gamma_pnl": cum["gamma"],
        "theta_pnl": cum["theta"],
        "vega_pnl": cum["vega"],
        "vanna_pnl": cum["vanna"],
        "volga_pnl": cum["volga"],
        "residual_pnl": cum["residual"],
        "hedge_pnl": cum["hedge"],
    }
