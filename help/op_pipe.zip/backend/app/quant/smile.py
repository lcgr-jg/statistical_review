"""Delta-quoted smile.

Pillars are stored by call delta: 10Δ call = 0.10, ATM = 0.50, 25Δ put = 0.75,
10Δ put = 0.90. Vols are absolute (0.48 is 48 vol). Interpolation is monotone
cubic in call-delta space with flat wings.

Sticky delta keeps that shape and shifts it so ATM equals the vol you pass.
Sticky strike keeps the absolute-strike curve built at the quote, then applies
the same parallel ATM shift. Beta replaces the ATM vol with
``atm0 + beta * ln(F / F0)`` when the caller asks for it; the skew stays in
delta space.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.special import ndtr

from app.quant.black76 import strike_from_call_delta

PILLAR_CALL_DELTA = {
    "10DC": 0.10,
    "25DC": 0.25,
    "50D": 0.50,
    "25DP": 0.75,
    "10DP": 0.90,
}
PILLAR_ORDER = ("10DC", "25DC", "50D", "25DP", "10DP")


@dataclass
class Smile:
    forward: float
    T: float
    rate: float
    atm: float
    beta: float
    deltas: np.ndarray
    vols: np.ndarray
    strikes: np.ndarray

    def __post_init__(self) -> None:
        order = np.argsort(self.deltas)
        self.deltas = np.asarray(self.deltas, dtype=float)[order]
        self.vols = np.asarray(self.vols, dtype=float)[order]
        self.strikes = np.asarray(self.strikes, dtype=float)[order]
        self._delta_interp = _flat_pchip(self.deltas, self.vols)
        self._strike_interp = _flat_pchip(np.log(np.maximum(self.strikes, 1e-8)), self.vols)

    @classmethod
    def from_pillars(
        cls,
        forward: float,
        T: float,
        rate: float,
        pillars: dict[str, float],
        beta: float = 0.0,
    ) -> "Smile":
        if "50D" not in pillars or pillars["50D"] is None:
            raise ValueError("An ATM (50D) vol is required.")
        clean = {k: float(v) for k, v in pillars.items() if v is not None and k in PILLAR_CALL_DELTA}
        if clean["50D"] <= 0:
            raise ValueError("ATM vol must be positive.")
        deltas = np.array([PILLAR_CALL_DELTA[k] for k in clean], dtype=float)
        vols = np.array([clean[k] for k in clean], dtype=float)
        strikes = strike_from_call_delta(forward, vols, max(T, 1e-4), deltas)
        return cls(
            forward=float(forward),
            T=float(T),
            rate=float(rate),
            atm=float(clean["50D"]),
            beta=float(beta or 0.0),
            deltas=deltas,
            vols=vols,
            strikes=np.asarray(strikes, dtype=float),
        )

    def skew(self, call_delta: np.ndarray) -> np.ndarray:
        return self._delta_interp(np.clip(call_delta, self.deltas[0], self.deltas[-1])) - self.atm

    def vol_at_delta(self, call_delta: np.ndarray, atm: np.ndarray | float) -> np.ndarray:
        return np.asarray(atm, dtype=float) + self.skew(np.asarray(call_delta, dtype=float))

    def resolve_atm(self, forward, explicit_atm, follow_beta: bool):
        if follow_beta:
            f = np.maximum(np.asarray(forward, dtype=float), 1e-12)
            return self.atm + self.beta * np.log(f / self.forward)
        return explicit_atm

    def vol_at_strike(self, strike, forward, atm, T, skew: str) -> np.ndarray:
        """Implied vol of ``strike`` after the forward and ATM have moved.

        ``skew`` is ``delta`` or ``strike``. ``T`` is the remaining year fraction
        used to convert a strike into a delta. At expiry the vol is unused.
        """
        K = np.asarray(strike, dtype=float)
        F = np.asarray(forward, dtype=float)
        atm_arr = np.asarray(atm, dtype=float)
        t = np.maximum(np.asarray(T, dtype=float), 1e-6)
        if skew == "strike":
            raw = self._strike_interp(np.log(np.maximum(K, 1e-8)))
            raw_atm = self._strike_vol_of_atm(F, t)
            return np.clip(raw + (atm_arr - raw_atm), 1e-3, 5.0)
        sig = np.broadcast_to(atm_arr, np.broadcast(K, F, atm_arr, t).shape).astype(float).copy()
        sqrt_t = np.sqrt(t)
        for _ in range(8):
            d1 = (np.log(np.maximum(F, 1e-12) / np.maximum(K, 1e-12)) + 0.5 * sig * sig * t) / (
                np.maximum(sig, 1e-4) * sqrt_t
            )
            delta = ndtr(d1)
            sig = np.clip(atm_arr + self.skew(delta), 1e-3, 5.0)
        return sig

    def _strike_vol_of_atm(self, forward, T) -> np.ndarray:
        """Vol the sticky-strike curve assigns to the 50-delta strike at this forward."""
        # One fixed-point step is enough: the 50-delta strike depends on vol,
        # and the curve is smooth. Iterate a few times.
        sig = np.full(np.broadcast(forward, T).shape, self.atm, dtype=float)
        for _ in range(6):
            k_atm = strike_from_call_delta(forward, sig, T, 0.5)
            sig = np.clip(self._strike_interp(np.log(np.maximum(k_atm, 1e-8))), 1e-3, 5.0)
        return sig


def _flat_pchip(x: np.ndarray, y: np.ndarray):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    order = np.argsort(x)
    x, y = x[order], y[order]
    # Drop duplicate x so PCHIP will build.
    keep = np.concatenate([[True], np.diff(x) > 1e-12])
    x, y = x[keep], y[keep]
    if len(x) == 1:
        level = float(y[0])

        def _interp(z):
            return np.full(np.shape(z), level, dtype=float)

        return _interp
    spline = PchipInterpolator(x, y, extrapolate=False)

    def _interp(z):
        z = np.asarray(z, dtype=float)
        out = spline(np.clip(z, x[0], x[-1]))
        return np.asarray(out, dtype=float)

    return _interp
