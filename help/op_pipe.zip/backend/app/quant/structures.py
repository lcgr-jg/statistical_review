"""Structures: legs, template expansion, and a risk summary.

Premium is the present value of the package. Expiry P&L is the undiscounted
intrinsic value minus the future value of the premium, which is the P&L if the
package is held to expiry and the premium is financed at the flat rate.
Breakevens are the forwards where that P&L is zero. Probability of profit is
the risk-neutral probability under the ATM lognormal of the primary expiry.
"""
from __future__ import annotations

from datetime import date

import numpy as np

from app.quant.black76 import greeks, price, strike_from_call_delta, year_fraction
from app.quant.smile import Smile

TEMPLATES: dict[str, str] = {
    "call": "ATM call",
    "put": "ATM put",
    "call_spread": "Long 50Δ call, short 25Δ call",
    "put_spread": "Long 50Δ put, short 25Δ put",
    "straddle": "Long ATM straddle",
    "strangle": "Long 25Δ strangle",
    "risk_reversal": "Long 25Δ call, short 25Δ put",
    "call_fly": "Call fly, 25Δ / 50Δ / 25Δ put-wing",
    "put_fly": "Put fly, 25Δ call-wing / 50Δ / 25Δ",
    "condor": "Call condor at 20 / 40 / 60 / 80Δ",
    "seagull": "Long 50Δ put, short 25Δ put, short 25Δ call",
    "collar": "Long 25Δ put, short 25Δ call",
    "call_ratio": "Long 1x ATM call, short 2x 25Δ call",
    "calendar": "Short front ATM call, long back ATM call",
    "diagonal": "Short front ATM call, long back 25Δ call",
}


def expand_template(name: str, expiries: list[date], params: dict | None = None) -> list[dict]:
    """Build legs in the API's strike convention. ``strike`` for delta mode is a call delta."""
    if name not in TEMPLATES:
        raise ValueError(f"Unknown template {name}.")
    params = params or {}
    qty = float(params.get("qty", 1.0))
    front = expiries[0]
    back = expiries[1] if len(expiries) > 1 else None
    if name in {"calendar", "diagonal"} and back is None:
        raise ValueError(f"{name} needs two expiries.")

    def leg(cp, q, delta, expiry, mode="delta"):
        return {
            "call_put": cp,
            "qty": q * qty,
            "strike_mode": mode,
            "strike": delta,
            "expiry": expiry.isoformat() if expiry else None,
            "vol": None,
        }

    d25c, d50, d25p = 0.25, 0.50, 0.75
    table = {
        "call": [leg("C", 1, d50, front)],
        "put": [leg("P", 1, d50, front)],
        "call_spread": [leg("C", 1, d50, front), leg("C", -1, d25c, front)],
        "put_spread": [leg("P", 1, d50, front), leg("P", -1, d25p, front)],
        "straddle": [leg("C", 1, d50, front), leg("P", 1, d50, front)],
        "strangle": [leg("P", 1, d25p, front), leg("C", 1, d25c, front)],
        "risk_reversal": [leg("C", 1, d25c, front), leg("P", -1, d25p, front)],
        "call_fly": [leg("C", 1, d25c, front), leg("C", -2, d50, front), leg("C", 1, d25p, front)],
        "put_fly": [leg("P", 1, d25p, front), leg("P", -2, d50, front), leg("P", 1, d25c, front)],
        "condor": [
            leg("C", 1, 0.20, front),
            leg("C", -1, 0.40, front),
            leg("C", -1, 0.60, front),
            leg("C", 1, 0.80, front),
        ],
        "seagull": [leg("P", 1, d50, front), leg("P", -1, d25p, front), leg("C", -1, d25c, front)],
        "collar": [leg("P", 1, d25p, front), leg("C", -1, d25c, front)],
        "call_ratio": [leg("C", 1, d50, front), leg("C", -2, d25c, front)],
        "calendar": [leg("C", -1, d50, front), leg("C", 1, d50, back)],
        "diagonal": [leg("C", -1, d50, front), leg("C", 1, d25c, back)],
    }
    return table[name]


def prepare_slices(market, as_of: date):
    """Attach year fraction and a built smile to each expiry slice."""
    prepared = []
    beta = market.beta or 0.0
    for sl in market.slices:
        T = year_fraction(as_of, sl.expiry)
        pillars = dict(sl.pillars)
        if pillars.get("50D") is None:
            raise ValueError(f"Expiry {sl.expiry} has no 50D vol.")
        smile = Smile.from_pillars(sl.forward, max(T, 1e-4), market.rate, pillars, beta=beta)
        prepared.append((sl, T, smile))
    return prepared


def resolve_legs(prepared, legs) -> tuple[dict, list[dict]]:
    """Resolve every leg against its expiry slice. Returns the expiry lookup and the resolved legs."""
    if not prepared:
        raise ValueError("The market has no expiries.")
    by_exp = {sl.expiry: (sl, T, smile) for sl, T, smile in prepared}
    resolved = []
    for leg in legs:
        expiry = leg.expiry or prepared[0][0].expiry
        if expiry not in by_exp:
            available = ", ".join(str(e) for e in sorted(by_exp))
            raise ValueError(
                f"A leg expires {expiry}, which is not in the loaded market ({available}). "
                "Pick the leg's expiry again in the Builder."
            )
        sl, T, smile = by_exp[expiry]
        resolved.append(resolve_leg(leg, sl, smile, T))
    if not resolved:
        raise ValueError("Add at least one leg.")
    return by_exp, resolved


def resolve_leg(leg, sl, smile: Smile, T: float) -> dict:
    cp = 1.0 if leg.call_put == "C" else -1.0
    if leg.strike_mode == "absolute":
        strike = float(leg.strike)
    elif leg.strike_mode == "pct_atm":
        strike = float(leg.strike) * sl.forward
    elif leg.strike_mode == "delta":
        delta = float(leg.strike)
        if not 0.0 < delta < 1.0:
            raise ValueError(f"A delta strike must be a call delta between 0 and 1, got {delta:g}. Use Strike mode for a price.")
        vol = float(smile.vol_at_delta(delta, smile.atm))
        strike = float(strike_from_call_delta(sl.forward, vol, max(T, 1e-4), delta))
    else:
        raise ValueError(f"Unknown strike mode {leg.strike_mode}.")
    return {"cp": cp, "qty": float(leg.qty), "strike": strike, "vol_override": leg.vol, "slice": sl, "smile": smile, "T0": T}


def _leg_vol(resolved, forward, atm, T, skew: str, follow_beta: bool) -> np.ndarray:
    smile: Smile = resolved["smile"]
    if resolved["vol_override"] is not None:
        return np.asarray(resolved["vol_override"], dtype=float)
    used = smile.resolve_atm(forward, atm, follow_beta)
    return smile.vol_at_strike(resolved["strike"], forward, used, T, skew)


def _skew_name(regime: str) -> str:
    return "strike" if regime == "sticky-strike" else "delta"


def price_package(resolved, forward, atm, T, rate, skew: str, follow_beta: bool, multiplier: float) -> dict[str, np.ndarray]:
    """Sum leg greeks. ``forward`` and ``atm`` broadcast against each other."""
    acc = None
    for leg in resolved:
        # Each leg keeps its own remaining time if the caller passes a scalar T
        # per leg via the ``T`` argument already being that leg's time. Callers
        # that reprice one expiry pass one T. Multi-expiry packages pass a dict.
        t_leg = T[leg["slice"].expiry] if isinstance(T, dict) else T
        f_leg = forward[leg["slice"].expiry] if isinstance(forward, dict) else forward
        a_leg = atm[leg["slice"].expiry] if isinstance(atm, dict) else atm
        vol = _leg_vol(leg, f_leg, a_leg, t_leg, skew, follow_beta)
        g = greeks(f_leg, leg["strike"], vol, t_leg, rate, leg["cp"])
        scaled = {k: g[k] * leg["qty"] * multiplier for k in g}
        if acc is None:
            acc = scaled
        else:
            for k in acc:
                acc[k] = acc[k] + scaled[k]
    assert acc is not None
    return acc


def expiry_payoff(resolved, forwards: np.ndarray, premium: float, rate: float, T: float, multiplier: float) -> np.ndarray:
    """Undiscounted terminal P&L of a single-expiry package, financed premium."""
    payoff = np.zeros_like(forwards, dtype=float)
    for leg in resolved:
        intrinsic = np.maximum(leg["cp"] * (forwards - leg["strike"]), 0.0)
        payoff = payoff + leg["qty"] * multiplier * intrinsic
    return payoff - premium * np.exp(rate * max(T, 0.0))


def _breakevens(spots: np.ndarray, pnl: np.ndarray) -> list[float]:
    out = []
    for i in range(len(pnl) - 1):
        a, b = pnl[i], pnl[i + 1]
        if a == 0:
            out.append(float(spots[i]))
        elif a * b < 0:
            w = abs(a) / (abs(a) + abs(b))
            out.append(float(spots[i] + w * (spots[i + 1] - spots[i])))
    # de-duplicate near-identical roots
    cleaned: list[float] = []
    for x in out:
        if not cleaned or abs(x - cleaned[-1]) > 1e-6 * max(1.0, abs(x)):
            cleaned.append(x)
    return cleaned


def _wings(resolved) -> tuple[float, float]:
    """Net call quantity (upside slope) and net put quantity (downside, payoff as F->0 is sum qty*K for puts)."""
    net_call = sum(leg["qty"] for leg in resolved if leg["cp"] > 0)
    return net_call, 0.0


def pop_lognormal(spots, pnl, forward, atm, T) -> float | None:
    if T <= 1e-6 or atm <= 0:
        return None
    # Risk-neutral forward measure: ln F ~ N(ln F0 - 0.5 s^2 T, s^2 T)
    z = np.linspace(-6, 6, 4001)
    dz = z[1] - z[0]
    var = atm * atm * T
    mean = np.log(forward) - 0.5 * var
    f = np.exp(mean + np.sqrt(var) * z)
    weights = np.exp(-0.5 * z * z) * dz / np.sqrt(2 * np.pi)
    sampled = np.interp(f, spots, pnl)
    return float(np.sum(weights * (sampled > 0)) / np.sum(weights))


def summarise(market, legs, regime: str, follow_beta: bool, as_of: date) -> dict:
    prepared = prepare_slices(market, as_of)
    by_exp, resolved = resolve_legs(prepared, legs)

    primary_exp = min(leg["slice"].expiry for leg in resolved)
    primary = by_exp[primary_exp]
    skew = _skew_name(regime)
    rate = market.rate
    mult = market.multiplier

    forwards = {sl.expiry: sl.forward for sl, _, _ in prepared}
    atms = {sl.expiry: smile.atm for sl, _, smile in prepared}
    times = {sl.expiry: T for sl, T, _ in prepared}
    base = price_package(resolved, forwards, atms, times, rate, skew, False, mult)
    scalar = {k: float(np.asarray(v)) for k, v in base.items()}

    # Spot profile on the primary expiry. Other expiries stay at their marks,
    # shifted by the same log-forward move so calendars stay coherent.
    f0 = primary[0].forward
    spots = f0 * np.linspace(0.55, 1.7, 93)
    log_move = np.log(spots / f0)

    def _bumped_forward(spot_scalar_or_arr):
        ratio = np.asarray(spot_scalar_or_arr, dtype=float) / f0
        return {exp: fwd * ratio for exp, fwd in forwards.items()}

    profile_fwd = _bumped_forward(spots)
    profile_T = {exp: np.full(spots.shape, times[exp]) for exp in times}
    profile_atm = {exp: np.full(spots.shape, atms[exp]) for exp in atms}
    use_beta = follow_beta and regime == "beta"
    profile = price_package(resolved, profile_fwd, profile_atm, profile_T, rate, skew, use_beta, mult)

    # Expiry payoff uses the primary expiry only when every leg shares it.
    single = all(leg["slice"].expiry == primary_exp for leg in resolved)
    payoff_spots = f0 * np.linspace(0.4, 1.9, 241)
    if single:
        terminal = expiry_payoff(resolved, payoff_spots, scalar["price"], rate, primary[1], mult)
        breakevens = _breakevens(payoff_spots, terminal)
        pop = pop_lognormal(payoff_spots, terminal, f0, primary[2].atm, primary[1])
    else:
        terminal = None
        breakevens = []
        pop = None

    net_call, _ = _wings(resolved)
    unlimited_gain = net_call > 1e-9
    unlimited_loss = net_call < -1e-9
    finite = terminal if terminal is not None else np.asarray(profile["price"], dtype=float)
    max_gain = None if unlimited_gain else float(np.max(finite))
    max_loss = None if unlimited_loss else float(np.min(finite))

    # Intermediate reprices: fraction of primary life elapsed, forwards unchanged.
    frames = []
    life = max(primary[1], 1e-6)
    for frac in (0.0, 0.25, 0.5, 0.75, 1.0):
        remaining = {exp: max(times[exp] - frac * life, 0.0) for exp in times}
        grid = f0 * np.linspace(0.6, 1.5, 81)
        bumped = _bumped_forward(grid)
        rem = {exp: np.full(grid.shape, remaining[exp]) for exp in remaining}
        atm_grid = {exp: np.full(grid.shape, atms[exp]) for exp in atms}
        valued = price_package(resolved, bumped, atm_grid, rem, rate, skew, use_beta, mult)
        frames.append({
            "life_fraction": frac,
            "spots": grid.tolist(),
            "value": np.asarray(valued["price"]).tolist(),
        })

    # Scenario ladder: spot percent shocks, and a parallel vol shock in absolute vol.
    ladder = []
    for spot_pct in (-0.2, -0.1, -0.05, 0.0, 0.05, 0.1, 0.2):
        for vol_pts in (-0.10, -0.05, 0.0, 0.05, 0.10):
            f = {exp: fwd * (1.0 + spot_pct) for exp, fwd in forwards.items()}
            a = {exp: max(atms[exp] + vol_pts, 1e-3) for exp in atms}
            t = {exp: times[exp] for exp in times}
            valued = price_package(resolved, f, a, t, rate, skew, use_beta, mult)
            ladder.append({
                "spot_pct": spot_pct,
                "vol_pts": vol_pts,
                "pnl": float(np.asarray(valued["price"]) - scalar["price"]),
                "delta": float(np.asarray(valued["delta"])),
            })

    legs_out = []
    for leg, src in zip(resolved, legs):
        vol = _leg_vol(leg, leg["slice"].forward, leg["smile"].atm, leg["T0"], skew, False)
        g = greeks(leg["slice"].forward, leg["strike"], float(np.asarray(vol)), leg["T0"], rate, leg["cp"])
        legs_out.append({
            "call_put": src.call_put,
            "qty": leg["qty"],
            "strike": leg["strike"],
            "expiry": leg["slice"].expiry.isoformat(),
            "vol": float(np.asarray(vol)),
            "premium": float(g["price"]) * leg["qty"] * mult,
            "delta": float(g["delta"]) * leg["qty"] * mult,
            "vega": float(g["vega"]) * leg["qty"] * mult,
        })

    return {
        "premium": scalar["price"],
        "delta": scalar["delta"],
        "forward_delta": scalar["forward_delta"],
        "gamma": scalar["gamma"],
        "vega": scalar["vega"],
        "vega_point": scalar["vega"] / 100.0,
        "theta_day": scalar["theta"] / 365.25,
        "vanna": scalar["vanna"],
        "volga": scalar["volga"],
        "charm_day": scalar["charm"] / 365.25,
        "breakevens": breakevens,
        "max_gain": max_gain,
        "max_loss": max_loss,
        "unlimited_gain": unlimited_gain,
        "unlimited_loss": unlimited_loss,
        "pop": pop,
        "single_expiry": single,
        "legs": legs_out,
        "spot_profile": {
            "spots": spots.tolist(),
            "value": np.asarray(profile["price"]).tolist(),
            "delta": np.asarray(profile["delta"]).tolist(),
            "gamma": np.asarray(profile["gamma"]).tolist(),
            "vega": np.asarray(profile["vega"]).tolist(),
        },
        "payoff": None if terminal is None else {"spots": payoff_spots.tolist(), "pnl": terminal.tolist()},
        "frames": frames,
        "ladder": ladder,
    }


def pnl_grid(market, legs, regime: str, as_of: date, spot_axis: np.ndarray, vol_axis: np.ndarray, life_fractions: list[float]) -> dict:
    """Spot x vol P&L heatmaps at several fractions of the primary life."""
    prepared = prepare_slices(market, as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    primary = min(leg["slice"].expiry for leg in resolved)
    _, T0, _ = by_exp[primary]
    f0 = by_exp[primary][0].forward
    rate = market.rate
    mult = market.multiplier
    skew = _skew_name(regime)
    forwards0 = {sl.expiry: sl.forward for sl, _, _ in prepared}
    atms0 = {sl.expiry: smile.atm for sl, _, smile in prepared}
    times0 = {sl.expiry: T for sl, T, _ in prepared}
    base = float(np.asarray(price_package(resolved, forwards0, atms0, times0, rate, skew, False, mult)["price"]))

    spots = np.asarray(spot_axis, dtype=float)
    vols = np.asarray(vol_axis, dtype=float)
    # Broadcast: vol rows, spot columns.
    ff = spots[None, :]
    vv = vols[:, None]
    ratio = ff / f0
    frames = []
    for frac in life_fractions:
        remaining = {exp: max(times0[exp] - frac * T0, 0.0) for exp in times0}
        fwd = {exp: forwards0[exp] * ratio for exp in forwards0}
        # Explicit vol on every slice: shift each slice's ATM by the same amount.
        atm_shift = vv - atms0[primary]
        atm = {exp: np.maximum(atms0[exp] + atm_shift, 1e-3) for exp in atms0}
        trem = {exp: np.full(ff.shape, remaining[exp]) for exp in remaining}
        valued = price_package(resolved, fwd, atm, trem, rate, skew, False, mult)
        pnl = np.asarray(valued["price"]) - base
        frames.append({"life_fraction": frac, "pnl": pnl.tolist()})
    return {
        "spots": spots.tolist(),
        "vols": vols.tolist(),
        "premium": base,
        "frames": frames,
    }
