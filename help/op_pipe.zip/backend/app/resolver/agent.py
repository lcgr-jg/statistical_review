"""Claude ticker resolver.

The agent talks to the local Bloomberg MCP server, which uses the Desktop API
on localhost:8194, so a logged-in Terminal has to be running. Tools are limited
to discovery. Nothing is written to the underlying config from this loop; the
user approves a separate apply call that re-checks the tickers on B-PIPE.
"""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

from app.api.routes import proposal_from_text
from app.schemas import ResolverMessage
from app.settings import settings

ALLOWED_TOOLS = {
    "check_connection",
    "usage_today",
    "bdp",
    "bds",
    "bdh",
    "futures_curve",
    "field_search",
    "field_info",
    "security_search",
}

SYSTEM = """You configure commodity underlyings for an options desk. You may only report Bloomberg tickers that a tool result in this conversation actually returned. If a search comes back empty, say so and leave that field blank.

Vol pillars are 10DP, 25DP, 50D, 25DC and 10DC. Templates may use {m} month code, {y} last digit of the year, {yy}, {yyyy}, {contract} and {pillar}.

When you have verified what you can, end with one fenced json block and no other JSON:

```json
{"proposal": {"id": "TTF", "name": "Dutch TTF", "currency": "EUR", "unit": "EUR/MWh", "multiplier": 1, "rate": 0, "futures_root": "", "futures_ticker_template": "", "expiry_field": "LAST_TRADEABLE_DT", "month_codes": "FGHJKMNQUVXZ", "curve_months": 16, "vol_pillars": {"10DP": "", "25DP": "", "50D": "", "25DC": "", "10DC": ""}, "notes": "", "sample_checks": [{"ticker": "", "field": "PX_LAST", "purpose": ""}]}}
```

Empty string means not found. Do not guess a ticker to fill a gap.
"""


def _server_command() -> tuple[str, list[str], str]:
    script = Path(settings.bbg_mcp_server_path)
    if not script.exists():
        raise FileNotFoundError(f"BBG MCP server not found at {script}.")
    if settings.bbg_mcp_python:
        return settings.bbg_mcp_python, [str(script)], str(script.parent)
    uv = shutil.which("uv")
    if uv:
        return uv, ["run", "--directory", str(script.parent), "python", str(script)], str(script.parent)
    return "python", [str(script)], str(script.parent)


async def stream_chat(messages: list[ResolverMessage], underlying_id: str | None):
    if not settings.anthropic_api_key:
        yield {"type": "error", "data": {"message": "ANTHROPIC_API_KEY is not set. Add it to backend/.env."}}
        return
    try:
        from mcp import ClientSession
        from mcp.client.stdio import stdio_client
        from mcp import StdioServerParameters
    except ImportError as exc:
        yield {"type": "error", "data": {"message": f"The mcp package is not installed ({exc})."}}
        return
    try:
        import anthropic
    except ImportError as exc:
        yield {"type": "error", "data": {"message": f"The anthropic package is not installed ({exc})."}}
        return

    command, args, cwd = _server_command()
    params = StdioServerParameters(command=command, args=args, cwd=cwd, env=os.environ.copy())
    client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
    convo = [{"role": m.role, "content": m.content} for m in messages]
    if underlying_id:
        convo[-1] = {
            "role": convo[-1]["role"],
            "content": convo[-1]["content"] + f"\n\nThe underlying id to configure is {underlying_id}.",
        }

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            listed = await session.list_tools()
            tools = []
            for tool in listed.tools:
                if tool.name not in ALLOWED_TOOLS:
                    continue
                tools.append({
                    "name": tool.name,
                    "description": tool.description or "",
                    "input_schema": tool.inputSchema,
                })
            yield {"type": "status", "data": {"message": f"Bloomberg tools ready ({len(tools)})."}}

            for _ in range(8):
                collected = ""
                async with client.messages.stream(
                    model=settings.anthropic_model,
                    max_tokens=4096,
                    system=SYSTEM,
                    tools=tools,
                    messages=convo,
                ) as stream:
                    async for delta in stream.text_stream:
                        collected += delta
                        yield {"type": "text", "data": {"delta": delta}}
                    final = await stream.get_final_message()

                convo.append({"role": "assistant", "content": _dump_content(final)})
                tool_uses = [b for b in final.content if getattr(b, "type", None) == "tool_use"]
                if not tool_uses:
                    proposal = proposal_from_text(collected)
                    yield {"type": "done", "data": {"proposal": proposal}}
                    return

                results = []
                for block in tool_uses:
                    if block.name not in ALLOWED_TOOLS:
                        payload = f"Refused: {block.name} is not a discovery tool."
                    else:
                        try:
                            result = await session.call_tool(block.name, arguments=dict(block.input or {}))
                            payload = _tool_text(result)[:12000]
                        except Exception as exc:
                            payload = f"Tool failed: {exc}"
                    yield {"type": "tool", "data": {"name": block.name, "arguments": block.input, "preview": payload[:1500]}}
                    results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": payload,
                    })
                convo.append({"role": "user", "content": results})

    yield {"type": "done", "data": {"proposal": None, "message": "Stopped after 8 tool rounds without a proposal."}}


def _dump_content(message) -> list[dict]:
    dumped = message.model_dump()
    return dumped["content"]


def _tool_text(result) -> str:
    parts = []
    for block in getattr(result, "content", []) or []:
        text = getattr(block, "text", None)
        if text:
            parts.append(text)
        elif isinstance(block, dict) and block.get("text"):
            parts.append(block["text"])
    if not parts:
        parts.append(json.dumps(result, default=str)[:4000])
    if getattr(result, "isError", False):
        parts.insert(0, "ERROR")
    return "\n".join(parts)
