from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import router
from app.settings import FRONTEND_DIST

@asynccontextmanager
async def lifespan(_app: FastAPI):
    tasks = []
    if os.environ.get("ALERTS_BACKGROUND", "1") != "0":
        from app.alerts import run_forever

        tasks.append(asyncio.create_task(run_forever()))
    products = [p.strip() for p in os.environ.get("SMILE_SNAPSHOT_PRODUCTS", "FJSA Comdty").split(",") if p.strip()]
    if products and os.environ.get("SMILE_SNAPSHOT_BACKGROUND", "1") != "0":
        from app.market.screener import record_daily

        tasks.append(asyncio.create_task(record_daily(products)))
    warm_products = [p.strip() for p in os.environ.get("WARM_PRODUCTS", ",".join(products)).split(",") if p.strip()]
    if warm_products and os.environ.get("WARM_BACKGROUND", "1") != "0":
        from app.market.warm import warm_forever

        tasks.append(asyncio.create_task(warm_forever(warm_products)))
    yield
    for task in tasks:
        task.cancel()


app = FastAPI(title="Options Structure Lab", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router, prefix="/api")

if (FRONTEND_DIST / "index.html").is_file():
    root = FRONTEND_DIST.resolve()
    app.mount("/assets", StaticFiles(directory=root / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith("api/"):
            raise HTTPException(status_code=404)
        file = (root / path).resolve()
        if path and file.is_file() and root in file.parents:
            return FileResponse(file)
        # Client-side routes (/vol, /path, ...) all load the app shell.
        return FileResponse(root / "index.html", headers={"Cache-Control": "no-cache"})
