"""Server-side cache for the curve-wide endpoints, kept warm in the background for the main products.

Surface, Screener and the term structure fit or read every listed expiry, which costs seconds of
Bloomberg time per call. Their results are kept for a few minutes and stamped with ``computed_at``,
so a repeat request (from any user) is answered at once and the page can say how old the numbers are.
``warm_forever`` rebuilds Surface and Screener for ``WARM_PRODUCTS`` a little more often than they
expire, during London trading hours, so those products never go cold while the desk is using them.
"""
from __future__ import annotations

import asyncio
import logging
import os
import threading
import time
from datetime import datetime, timezone
from typing import Callable

log = logging.getLogger(__name__)

SETTLE_TTL = 300.0
# Mid-based fits move with the live market, so they are only shared between near-simultaneous requests.
LIVE_TTL = 30.0
TERM_TTL = 60.0
WARM_SECONDS = float(os.environ.get("WARM_SECONDS", "240"))
WARM_HOURS = (7, 19)

_results: dict[tuple, tuple[float, dict]] = {}
_building: dict[tuple, threading.Lock] = {}
_guard = threading.Lock()


def cached(key: tuple, ttl: float, build: Callable[[], dict], refresh: bool = False) -> dict:
    """Return the stored result for ``key`` if younger than ``ttl``, else build it once.

    Concurrent callers for the same key wait for the one build rather than each going to Bloomberg.
    ``refresh`` rebuilds even when the stored result is fresh (the background warmer uses it).
    """
    hit = _results.get(key)
    if hit and not refresh and time.time() - hit[0] < ttl:
        return hit[1]
    with _guard:
        lock = _building.setdefault(key, threading.Lock())
    with lock:
        hit = _results.get(key)
        if hit and not refresh and time.time() - hit[0] < ttl:
            return hit[1]
        value = {**build(), "computed_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        _results[key] = (time.time(), value)
        return value


def surface(product: str, limit: int = 12, source: str = "settle", refresh: bool = False) -> dict:
    from app.market.vol_surface import surface as build

    ttl = SETTLE_TTL if source == "settle" else LIVE_TTL
    return cached(("surface", product, limit, source), ttl, lambda: build(product, limit, source), refresh)


def screener(product: str, limit: int = 12, refresh: bool = False) -> dict:
    from app.market.screener import screener as build

    return cached(("screener", product, limit), SETTLE_TTL, lambda: build(product, limit), refresh)


def term(product: str, limit: int = 18) -> dict:
    from app.market.discovery import term_structure

    return cached(("term", product, limit), TERM_TTL, lambda: term_structure(product, limit))


def _in_hours(now: datetime) -> bool:
    return now.weekday() < 5 and WARM_HOURS[0] <= now.hour < WARM_HOURS[1]


async def warm_forever(products: list[str]) -> None:
    """Rebuild Surface and Screener for each product at start-up, then every ``WARM_SECONDS`` in hours."""
    from zoneinfo import ZoneInfo

    first = True
    while True:
        if first or _in_hours(datetime.now(ZoneInfo("Europe/London"))):
            for product in products:
                for name, job in (("surface", surface), ("screener", screener)):
                    started = time.monotonic()
                    try:
                        await asyncio.to_thread(job, product, refresh=True)
                        log.info("Warmed %s for %s in %.1fs", name, product, time.monotonic() - started)
                    except Exception as exc:
                        log.warning("Warming %s for %s failed: %s", name, product, exc)
        first = False
        await asyncio.sleep(WARM_SECONDS)
