"""Find a listed options market on Bloomberg from a free-text name.

search("TTF")            -> products, e.g. FJSA Comdty (TTF options, active contract)
expiries("FJSA Comdty")  -> contracts in FUT_CHAIN that have listed options, with option expiry
smile("FJSX6 Comdty")    -> forward, option expiry and delta-pillar vols fitted to the OPT_CHAIN implied vols
                            (IVOL_MID, or IVOL_LAST_RT on expiries with no live bid/ask)

Everything goes through the desk B-PIPE session. Deltas are recomputed with Black-76 from the
Bloomberg mid implied vol so the pillars use the same forward-delta convention as the pricer.
"""
from __future__ import annotations

import re
import time
from collections import Counter
from datetime import date, datetime, timedelta
from typing import Any, Callable

import numpy as np
import pandas as pd
from scipy.special import ndtr

from app.market.bbg import MarketDataError, as_float, history, request, security_data
from app.quant import sabr
from app.quant.black76 import implied_vol

REFDATA = "//blp/refdata"
INSTRUMENTS = "//blp/instruments"
CHAIN_TTL = 600.0
QUOTE_TTL = 30.0
PILLAR_DELTAS = {"10DC": 0.10, "25DC": 0.25, "50D": 0.50, "25DP": 0.75, "10DP": 0.90}
DELTA_SLACK = 0.02
FIT_DELTA_RANGE = (0.03, 0.97)
OUTLIER_FLOOR = 0.02
MIN_MID_POINTS = 6
# In-the-money options this close to the future are also fetched, for the put-call parity check.
PARITY_RANGE = (0.8, 1.25)
# SABR is dropped for the polynomial when its rmse is both 1.5x the polynomial's and above this (absolute vol).
SABR_RMSE_FLOOR = 0.01
# How far past the data the SABR curve is drawn, in standardised moneyness.
CURVE_PAD = 0.75
OPTION_TICKER = re.compile(r"^(?P<root>\S+?)(?P<cp>[CP])\s+(?P<strike>-?[\d.]+)\s+(?P<yk>\w+)$")
FUTURE_FIELDS = ["NAME", "PX_LAST", "CRNCY", "QUOTE_UNITS", "FUT_CONT_SIZE", "PX_SETTLE", "PX_SETTLE_LAST_DT"]
OPTION_FIELDS = ["IVOL_MID", "IVOL_LAST_RT", "OPT_EXPIRE_DT", "OPT_UNDL_PX", "PX_SETTLE", "PX_SETTLE_LAST_DT", "OPT_TICK_SIZE"]
# Securities per batched reference request.
REFDATA_CHUNK = 400

_memo: dict[tuple, tuple[float, Any]] = {}


def _cached(key: tuple, ttl: float, build: Callable[[], Any]) -> Any:
    hit = _memo.get(key)
    now = time.time()
    if hit and now - hit[0] < ttl:
        return hit[1]
    value = build()
    _memo[key] = (now, value)
    return value


YELLOW_KEYS = {
    "cmdty": "Comdty",
    "index": "Index",
    "curncy": "Curncy",
    "equity": "Equity",
    "govt": "Govt",
    "corp": "Corp",
    "mmkt": "M-Mkt",
    "muni": "Muni",
    "pfd": "Pfd",
}


def _ticker(security: str) -> str:
    """instrumentListRequest returns 'FJSA<cmdty>'; refdata wants 'FJSA Comdty'."""
    match = re.match(r"^(.*)<(\w+)>$", security.strip())
    if not match:
        return security.strip()
    key = match.group(2).lower()
    return f"{match.group(1)} {YELLOW_KEYS.get(key, key.capitalize())}"


def search(query: str, limit: int = 30) -> list[dict]:
    query = query.strip()
    if not query:
        return []

    def build() -> list[dict]:
        msgs = request(
            INSTRUMENTS,
            "instrumentListRequest",
            {"query": query, "maxResults": limit, "yellowKeyFilter": "YK_FILTER_CMDT"},
        )
        rows: list[dict] = []
        for msg in msgs:
            for item in msg.get("results") or []:
                description = str(item.get("description", ""))
                lower = description.lower()
                rows.append(
                    {
                        "ticker": _ticker(str(item.get("security", ""))),
                        "description": description,
                        "kind": "options" if "option" in lower else "futures",
                        "active": "active contract" in lower or "generic" in lower,
                    }
                )
        return rows

    rows = list(_cached(("search", query.lower(), limit), CHAIN_TTL, build))
    if re.search(r"\s(Comdty|Index|Curncy)$", query, re.IGNORECASE) and not any(r["ticker"] == query for r in rows):
        rows.insert(0, {"ticker": query, "description": "Typed ticker", "kind": "unknown", "active": True})
    rank = {("options", True): 0, ("unknown", True): 1, ("futures", True): 2, ("options", False): 3}
    rows.sort(key=lambda r: rank.get((r["kind"], r["active"]), 4))
    return rows


def _bulk(securities: list[str], field: str) -> dict[str, list[str]]:
    msgs = request(REFDATA, "ReferenceDataRequest", {"securities": securities, "fields": [field]})
    out: dict[str, list[str]] = {}
    for row in security_data(msgs):
        values = (row.get("fieldData") or {}).get(field) or []
        out[row.get("security", "")] = [str(next(iter(v.values()))) for v in values if isinstance(v, dict) and v]
    return out


def _refdata(securities: list[str], fields: list[str]) -> dict[str, dict]:
    if not securities:
        return {}
    msgs = request(REFDATA, "ReferenceDataRequest", {"securities": securities, "fields": fields})
    out: dict[str, dict] = {}
    for row in security_data(msgs):
        out[row.get("security", "")] = dict(row.get("fieldData") or {})
    return out


def _future_chain(product: str) -> list[str]:
    return _cached(("fut_chain", product), CHAIN_TTL, lambda: _bulk([product], "FUT_CHAIN").get(product, []))


def _option_chains(contracts: list[str]) -> dict[str, list[str]]:
    missing = [c for c in contracts if ("opt_chain", c) not in _memo or time.time() - _memo[("opt_chain", c)][0] > CHAIN_TTL]
    if missing:
        fetched = _bulk(missing, "OPT_CHAIN")
        now = time.time()
        for contract in missing:
            _memo[("opt_chain", contract)] = (now, fetched.get(contract, []))
    return {c: _memo[("opt_chain", c)][1] for c in contracts}


def _label(name: str | None, fallback: str) -> str:
    if name:
        token = str(name).split()[-1]
        if re.fullmatch(r"[A-Za-z]{3}\d{2}", token):
            return token
    return fallback


def _iso(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, date):
        return value.isoformat()
    text = str(value)[:10]
    return text if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text) else None


def _series(tickers: list[str]) -> dict[str, list[str]]:
    """Group an OPT_CHAIN by option root. EUA Dec futures carry serial options (MZBV6, MZBX6) beside MZBZ6."""
    groups: dict[str, list[str]] = {}
    for ticker in tickers:
        match = OPTION_TICKER.match(ticker.strip())
        if match:
            groups.setdefault(match.group("root"), []).append(ticker)
    return groups


def _main_series(contract: str, groups: dict[str, list[str]]) -> str | None:
    if not groups:
        return None
    head = contract.split()[0]
    return head if head in groups else max(groups, key=lambda root: len(groups[root]))


def expiries(product: str, limit: int = 18, serials: bool = False) -> dict:
    """One row per future with its main option series; with serials=True, also one row per serial series."""
    chain = _future_chain(product)
    if not chain:
        raise MarketDataError(f"{product} has no FUT_CHAIN. Pick an active contract or a generic future.")
    contracts = chain[:limit]
    chains = _option_chains(contracts)
    with_options = [c for c in contracts if chains.get(c)]
    if not with_options:
        return {
            "product": product,
            "contracts": [],
            "warning": f"No listed options on {product}. Pick the options product in the search (tagged OPT).",
        }
    wanted: list[tuple[str, str, bool, list[str]]] = []
    for contract in with_options:
        groups = _series(chains[contract])
        main = _main_series(contract, groups)
        for root, tickers in groups.items():
            if root == main or serials:
                wanted.append((contract, root, root == main, tickers))
    probes = {(c, root): tickers[len(tickers) // 2] for c, root, _, tickers in wanted}
    option_ref = _refdata(list(probes.values()), ["OPT_EXPIRE_DT", "OPT_UNDL_TICKER"])
    future_ref = _refdata(with_options, ["NAME", "PX_LAST", "LAST_TRADEABLE_DT", "FUT_CONT_SIZE", "CRNCY", "QUOTE_UNITS"])
    rows = []
    for contract, root, is_main, tickers in wanted:
        fut = future_ref.get(contract, {})
        opt = option_ref.get(probes[(contract, root)], {})
        label = _label(fut.get("NAME"), contract.split()[0])
        option_expiry = _iso(opt.get("OPT_EXPIRE_DT"))
        rows.append(
            {
                "contract": contract,
                "series": root,
                "main": is_main,
                "label": label if is_main else f"{_expiry_label(option_expiry, root)} on {label}",
                "name": fut.get("NAME"),
                "option_expiry": option_expiry,
                "future_expiry": _iso(fut.get("LAST_TRADEABLE_DT")),
                "forward": as_float(fut.get("PX_LAST")),
                "n_options": len(tickers),
                "currency": fut.get("CRNCY"),
                "unit": fut.get("QUOTE_UNITS"),
                "multiplier": as_float(fut.get("FUT_CONT_SIZE")),
            }
        )
    if serials:
        rows.sort(key=lambda r: (r["option_expiry"] or "9999", not r["main"]))
    return {"product": product, "contracts": rows, "warning": None}


def _expiry_label(option_expiry: str | None, fallback: str) -> str:
    return date.fromisoformat(option_expiry).strftime("%b%y") if option_expiry else fallback


def _parse_option(ticker: str) -> tuple[str, float] | None:
    match = OPTION_TICKER.match(ticker.strip())
    if not match:
        return None
    try:
        return match.group("cp"), float(match.group("strike"))
    except ValueError:
        return None


def _centre(fut: dict, source: str) -> tuple[str, float | None]:
    """The smile's centre: the settlement for source='settle' when the future has one, else the last price."""
    last = as_float(fut.get("PX_LAST"))
    settle_px = as_float(fut.get("PX_SETTLE"))
    if source == "settle" and settle_px and settle_px > 0 and _iso(fut.get("PX_SETTLE_LAST_DT")):
        return "settle", settle_px
    return "mid", last if last and last > 0 else None


def _select_options(tickers: list[str], centre: float, moneyness: tuple[float, float]) -> tuple[list[tuple[str, str, float]], list[tuple[str, str, float]]]:
    """Out-of-the-money options inside the moneyness band, and the near in-the-money ones for the parity check."""
    wanted: list[tuple[str, str, float]] = []
    in_the_money: list[tuple[str, str, float]] = []
    for ticker in tickers:
        parsed = _parse_option(ticker)
        if not parsed:
            continue
        cp, strike = parsed
        if strike <= 0 or not (moneyness[0] * centre <= strike <= moneyness[1] * centre):
            continue
        if (cp == "C" and strike >= centre) or (cp == "P" and strike < centre):
            wanted.append((ticker, cp, strike))
        elif PARITY_RANGE[0] * centre <= strike <= PARITY_RANGE[1] * centre:
            in_the_money.append((ticker, cp, strike))
    return wanted, in_the_money


def _future_settle_on(contract: str, day: str) -> float | None:
    """The future's settlement on ``day``. Exchanges publish futures settlements before option ones,
    so for part of the evening the future's PX_SETTLE is a day ahead of its options'."""

    def load() -> float | None:
        end = datetime.combine(date.fromisoformat(day), datetime.min.time())
        try:
            frame = history([contract], ["PX_SETTLE", "PX_LAST"], end - timedelta(days=7), end)
        except MarketDataError:
            return None
        frame = frame[[pd.Timestamp(d).date() == end.date() for d in frame.index]]
        for field in ("PX_SETTLE", "PX_LAST"):
            column = f"{contract}_{field}"
            if column in frame and len(frame[column].dropna()):
                value = as_float(frame[column].dropna().iloc[-1])
                if value and value > 0:
                    return value
        return None

    return _cached(("future-settle", contract, day), 6 * 3600.0, load)


def _options_key(contract: str, series: str, source: str, centre: float) -> tuple:
    return ("options", contract, series, source, round(centre, 2))


def _fresh(key: tuple, ttl: float) -> bool:
    hit = _memo.get(key)
    return bool(hit) and time.time() - hit[0] < ttl


def prime_smiles(contracts: list[str], source: str = "settle", moneyness: tuple[float, float] = (0.3, 3.0)) -> int:
    """Fetch the futures and option quotes for many contracts' main series in a few batched requests.

    ``smile`` asks Bloomberg for each contract's future and options separately, two round trips per
    expiry. Calling this first leaves the same data in the memo under the keys ``smile`` reads, so a
    whole curve costs a handful of requests. Returns the number of option sets fetched.
    """
    chains = _option_chains(contracts)
    stale = [c for c in contracts if not _fresh(("future", c), QUOTE_TTL)]
    if stale:
        fetched = _refdata(stale, FUTURE_FIELDS)
        now = time.time()
        for contract in stale:
            _memo[("future", contract)] = (now, fetched.get(contract, {}))
    plans: dict[tuple, list[str]] = {}
    for contract in contracts:
        groups = _series(chains.get(contract, []))
        series = _main_series(contract, groups)
        if not series:
            continue
        effective, centre = _centre(_memo[("future", contract)][1], source)
        if centre is None:
            continue
        wanted, in_the_money = _select_options(groups[series], centre, moneyness)
        key = _options_key(contract, series, effective, centre)
        if wanted and not _fresh(key, QUOTE_TTL):
            plans[key] = [w[0] for w in wanted + in_the_money]
    if not plans:
        return 0
    tickers = list(dict.fromkeys(t for group in plans.values() for t in group))
    data: dict[str, dict] = {}
    for i in range(0, len(tickers), REFDATA_CHUNK):
        data.update(_refdata(tickers[i : i + REFDATA_CHUNK], OPTION_FIELDS))
    now = time.time()
    for key, group in plans.items():
        _memo[key] = (now, {t: data[t] for t in group if t in data})
    return len(plans)


def smile(
    contract: str,
    as_of: date | None = None,
    moneyness: tuple[float, float] = (0.3, 3.0),
    series: str | None = None,
    source: str = "settle",
) -> dict:
    """source='settle' fits vols implied from yesterday's settlement prices against the future's settlement;
    source='mid' fits Bloomberg's live mid implied vols. Pillars are in delta, so either applies to the live future."""
    as_of = as_of or date.today()
    groups = _series(_option_chains([contract]).get(contract, []))
    if not groups:
        raise MarketDataError(f"{contract} has no listed options (OPT_CHAIN is empty).")
    series = series or _main_series(contract, groups)
    if series not in groups:
        raise MarketDataError(f"{contract} has no option series {series}. It has {', '.join(sorted(groups))}.")
    tickers = groups[series]
    fut = _cached(("future", contract), QUOTE_TTL, lambda: _refdata([contract], FUTURE_FIELDS).get(contract, {}))
    last = as_float(fut.get("PX_LAST"))
    if last is None or last <= 0:
        raise MarketDataError(f"{contract} has no PX_LAST, so the smile cannot be centred.")
    settle_px = as_float(fut.get("PX_SETTLE"))
    settle_day = _iso(fut.get("PX_SETTLE_LAST_DT"))
    warnings_pre: list[str] = []
    if source == "settle" and _centre(fut, source)[0] == "mid":
        warnings_pre.append(f"{contract} has no settlement price, so live mids are used.")
    source, centre = _centre(fut, source)

    wanted, in_the_money = _select_options(tickers, centre, moneyness)
    if not wanted:
        raise MarketDataError(f"No out-of-the-money options near {centre:g} on {contract}.")

    ref = _cached(
        _options_key(contract, series, source, centre),
        QUOTE_TTL,
        lambda: _refdata([w[0] for w in wanted] + [w[0] for w in in_the_money], OPTION_FIELDS),
    )
    expiries_seen = Counter(_iso(ref.get(t, {}).get("OPT_EXPIRE_DT")) for t, _, _ in wanted)
    expiries_seen.pop(None, None)
    if not expiries_seen:
        raise MarketDataError(f"Bloomberg returned no OPT_EXPIRE_DT for options on {contract}.")
    expiry = expiries_seen.most_common(1)[0][0]
    wanted = [w for w in wanted if _iso(ref.get(w[0], {}).get("OPT_EXPIRE_DT")) == expiry]
    underlying = [as_float(ref.get(t, {}).get("OPT_UNDL_PX")) for t, _, _ in wanted]
    underlying = [u for u in underlying if u and u > 0]
    forward = float(np.median(underlying)) if underlying else last
    T = max((date.fromisoformat(expiry) - as_of).days / 365.25, 1.0 / 365.25)

    def point(ticker: str, cp: str, strike: float, sigma: float, F: float, t: float) -> dict:
        d1 = (np.log(F / strike) + 0.5 * sigma * sigma * t) / (sigma * np.sqrt(t))
        return {"ticker": ticker, "cp": cp, "strike": strike, "vol": sigma, "call_delta": float(ndtr(d1))}

    def collect(field: str) -> list[dict]:
        out = []
        for ticker, cp, strike in wanted:
            vol_pct = as_float(ref.get(ticker, {}).get(field))
            if vol_pct is None or not (1.0 < vol_pct < 500.0):
                continue
            out.append(point(ticker, cp, strike, vol_pct / 100.0, forward, T))
        return out

    tick = next((as_float(ref.get(t, {}).get("OPT_TICK_SIZE")) for t, _, _ in wanted if as_float(ref.get(t, {}).get("OPT_TICK_SIZE"))), None)

    def from_settlement(F: float, t: float) -> tuple[list[dict], int, list[tuple[float, str, float]]]:
        rows = [(w, as_float(ref.get(w[0], {}).get("PX_SETTLE"))) for w in wanted]
        rows = [(w, p) for w, p in rows if p is not None and p > 0]
        if not rows:
            return [], 0, []
        floor = tick_floor([p for _, p in rows], tick)
        kept = [(w, p) for w, p in rows if floor is None or p > floor]
        vols = implied_vol(F, [w[2] for w, _ in kept], t, [p for _, p in kept], [1 if w[1] == "C" else -1 for w, _ in kept])
        out = []
        for (w, p), v in zip(kept, vols):
            if np.isfinite(v):
                out.append({**point(*w, float(v), F, t), "price": p})
        return out, len(rows) - len(kept), [(w[2], w[1], p) for w, p in kept]

    settle = None
    parity = None
    arbitrage = None
    vol_source = source
    fit_forward, fit_T = forward, T
    if source == "settle":
        option_days = Counter(_iso(ref.get(t, {}).get("PX_SETTLE_LAST_DT")) for t, _, _ in wanted)
        option_days.pop(None, None)
        option_day = option_days.most_common(1)[0][0] if option_days else settle_day
        if option_day and settle_day and option_day < settle_day:
            matched = _future_settle_on(contract, option_day)
            if matched is not None:
                warnings_pre.append(
                    f"Option settlements are from {option_day}, the future's from {settle_day}; vols are implied "
                    f"against the future's {option_day} settlement of {matched:.4g}."
                )
                settle_px, settle_day = matched, option_day
                # Calls and puts were split around the newer settlement; split again around the one that matches.
                known = [t for t in tickers if t in ref and _iso(ref[t].get("OPT_EXPIRE_DT")) == expiry]
                wanted, in_the_money = _select_options(known, settle_px, moneyness)
            else:
                warnings_pre.append(
                    f"Option settlements are from {option_day} but the future's is from {settle_day}, and the "
                    f"{option_day} futures settlement is unavailable; the vols are skewed by the move between them."
                )
        fit_forward = settle_px
        fit_T = max((date.fromisoformat(expiry) - date.fromisoformat(settle_day)).days / 365.25, 1.0 / 365.25)
        points, at_floor, settled = from_settlement(fit_forward, fit_T)
        settle = {"date": settle_day, "forward": settle_px}
        if at_floor:
            warnings_pre.append(
                f"{at_floor} far strike{'s' if at_floor > 1 else ''} settled at the minimum tick and {'were' if at_floor > 1 else 'was'} left out."
            )
        # Static arbitrage on the raw settlements: out-of-the-money puts become calls by parity.
        arbitrage = sabr.static_checks(
            [k for k, _, _ in settled],
            [p if cp == "C" else p + settle_px - k for k, cp, p in settled],
            tick,
            settle_px,
        )
        if not arbitrage["ok"]:
            bits = []
            if arbitrage["vertical"]:
                bits.append(f"call spreads at {', '.join(f'{k:g}' for k in arbitrage['vertical'][:4])}")
            if arbitrage["butterfly"]:
                bits.append(f"butterflies at {', '.join(f'{k:g}' for k in arbitrage['butterfly'][:4])}")
            warnings_pre.append("Settlement prices break static no-arbitrage bounds: " + " and ".join(bits) + ".")
        settles = {t: as_float(ref.get(t, {}).get("PX_SETTLE")) for t, _, _ in wanted + in_the_money}
        parity = parity_check(
            [(t, cp, k) for t, cp, k in wanted + in_the_money if _iso(ref.get(t, {}).get("OPT_EXPIRE_DT")) == expiry],
            settles,
            settle_px,
            tick,
        )
        if parity and parity["break"]:
            warnings_pre.append(
                f"Put-call parity implies a forward of {parity['forward']:.4g} against the futures settlement of {settle_px:.4g} "
                f"({parity['diff']:+.4g}, {parity['n_pairs']} strikes). The option and futures settlements disagree."
            )
        if len(points) < MIN_MID_POINTS:
            warnings_pre.append("Too few settlement prices on this expiry, so live mids are used.")
            vol_source, fit_forward, fit_T, settle = "mid", forward, T, None
    if vol_source == "mid":
        points = collect("IVOL_MID")
        if len(points) < MIN_MID_POINTS:
            fallback = collect("IVOL_LAST_RT")
            if len(fallback) > len(points):
                points, vol_source = fallback, "last"
    points.sort(key=lambda p: p["strike"])
    pillars, curve, warnings, fit = fit_smile(points, fit_forward, fit_T)
    warnings = warnings_pre + warnings
    if vol_source == "last":
        warnings.insert(0, "No live bid/ask on this expiry, so vols are implied from last prices.")
    if pillars["50D"] is None:
        warnings.append("ATM vol could not be read from the chain. Type it in before pricing.")

    label = _label(fut.get("NAME"), contract.split()[0])
    is_main = series == _main_series(contract, groups)
    return {
        "contract": contract,
        "series": series,
        "main": is_main,
        "label": label if is_main else f"{_expiry_label(expiry, series)} on {label}",
        "name": fut.get("NAME"),
        "as_of": as_of.isoformat(),
        "expiry": expiry,
        "forward": forward,
        "future_last": last,
        "currency": fut.get("CRNCY"),
        "unit": fut.get("QUOTE_UNITS"),
        "multiplier": as_float(fut.get("FUT_CONT_SIZE")),
        "pillars": pillars,
        "points": points,
        "curve": curve,
        "vol_source": vol_source,
        "settle": settle,
        "fit": fit,
        "parity": parity,
        "arbitrage": arbitrage,
        "tick": tick,
        "warnings": warnings,
    }


def tick_floor(prices: list[float], tick: float | None) -> float | None:
    """Settlement level at or below which a price is the exchange minimum, not a market.

    With a known tick, that is one tick. Without one, the smallest settlement counts as the floor
    when more than one strike sits on it, which is how a chain looks when its wings have run out of
    premium.
    """
    if not prices:
        return None
    if tick and tick > 0:
        return tick * (1.0 + 1e-9)
    low = min(prices)
    return low * (1.0 + 1e-9) if sum(abs(p - low) <= 1e-12 for p in prices) >= 2 else None


def parity_check(options: list[tuple[str, str, float]], settles: dict[str, float | None], forward: float, tick: float | None, pairs: int = 6) -> dict | None:
    """Forward implied by put-call parity on settlement prices, against the futures settlement.

    Futures-style options carry no discounting, so F = K + C - P at every strike with both legs
    settled. The nearest ``pairs`` strikes to the money are used; wings settle on too few ticks.
    """
    calls = {k: settles.get(t) for t, cp, k in options if cp == "C"}
    puts = {k: settles.get(t) for t, cp, k in options if cp == "P"}
    rows = []
    for k in sorted(set(calls) & set(puts), key=lambda k: abs(k - forward)):
        c, p = calls[k], puts[k]
        if c is None or p is None or c <= 0 or p <= 0:
            continue
        rows.append({"strike": k, "forward": k + c - p})
        if len(rows) >= pairs:
            break
    if len(rows) < 2:
        return None
    implied = float(np.median([r["forward"] for r in rows]))
    diff = implied - forward
    tolerance = max(3.0 * tick if tick else 0.0, 1e-3 * forward)
    return {
        "forward": implied,
        "settle": forward,
        "diff": diff,
        "diff_pct": diff / forward,
        "n_pairs": len(rows),
        "spread": float(np.max([r["forward"] for r in rows]) - np.min([r["forward"] for r in rows])),
        "tolerance": tolerance,
        "break": abs(diff) > tolerance,
        "strikes": rows,
    }


ATM_FIELDS = ["HIST_CALL_IMP_VOL", "HIST_PUT_IMP_VOL"]
IV30_FIELD = "30DAY_IMPVOL_100.0%MNY_DF"


def _atm(call, put) -> float | None:
    values = [v for v in (as_float(call), as_float(put)) if v is not None and v > 0]
    return float(np.mean(values)) / 100.0 if values else None


def vol_history(contract: str, years: float = 2.0) -> dict:
    """Daily future, contract ATM implied (HIST_CALL/PUT_IMP_VOL) and 30-day constant-maturity implied."""
    from datetime import datetime, timedelta

    import pandas as pd

    from app.market.bbg import history
    from app.quant import volstats

    end = datetime.combine(date.today(), datetime.min.time())
    start = end - timedelta(days=int(365.25 * years))
    raw = history([contract], ["PX_LAST", *ATM_FIELDS, IV30_FIELD], start, end)
    if raw.empty:
        raise MarketDataError(f"No history for {contract}.")
    col = lambda field: raw.get(f"{contract}_{field}", pd.Series(np.nan, index=raw.index)).astype(float)
    atm = pd.concat([col(ATM_FIELDS[0]), col(ATM_FIELDS[1])], axis=1).mean(axis=1, skipna=True) / 100.0
    frame = pd.DataFrame({"futures": col("PX_LAST"), "atm": atm, "iv30": col(IV30_FIELD) / 100.0})
    frame = frame.dropna(subset=["futures"])
    try:
        result = volstats.analyse(frame)
    except ValueError as exc:
        raise MarketDataError(f"{contract}: {exc}") from exc
    if not any(v is not None for v in result["series"]["atm"]):
        result["warning"] = f"Bloomberg has no ATM implied vol history for {contract}; only realised vol is shown."
    else:
        result["warning"] = None
    return {"contract": contract, **result}


def term_structure(product: str, limit: int = 18) -> dict:
    """ATM implied vol by option expiry today, a week ago and a month ago."""
    from datetime import datetime, timedelta

    import pandas as pd

    from app.market.bbg import history

    listing = expiries(product, limit)
    rows = listing["contracts"]
    if not rows:
        return {"product": product, "contracts": [], "warning": listing["warning"]}
    contracts = [r["contract"] for r in rows]
    live = _cached(("term_live", tuple(contracts)), QUOTE_TTL, lambda: _refdata(contracts, ATM_FIELDS))
    end = datetime.combine(date.today(), datetime.min.time())
    hist = history(contracts, ATM_FIELDS, end - timedelta(days=40), end)

    def ago(contract: str, days: int) -> float | None:
        if hist.empty:
            return None
        cut = hist.loc[hist.index <= pd.Timestamp(end - timedelta(days=days))]
        if cut.empty:
            return None
        values = [cut.get(f"{contract}_{f}") for f in ATM_FIELDS]
        values = [s.dropna() for s in values if s is not None]
        values = [float(s.iloc[-1]) for s in values if len(s)]
        return float(np.mean(values)) / 100.0 if values else None

    today = date.today()
    out = []
    for row in rows:
        c = row["contract"]
        ref = live.get(c, {})
        exp = row["option_expiry"]
        out.append(
            {
                "contract": c,
                "label": row["label"],
                "option_expiry": exp,
                "days": (date.fromisoformat(exp) - today).days if exp else None,
                "forward": row["forward"],
                "atm": _atm(ref.get(ATM_FIELDS[0]), ref.get(ATM_FIELDS[1])),
                "atm_1w": ago(c, 7),
                "atm_1m": ago(c, 30),
            }
        )
    return {"product": product, "contracts": out, "warning": None}


def fit_smile(points: list[dict], forward: float, T: float, beta: float = sabr.DEFAULT_BETA) -> tuple[dict[str, float | None], list[dict], list[str], dict | None]:
    """Fit a SABR smile to the chain and read the delta pillars off it.

    A robust polynomial in standardised moneyness z = ln(K/F) / (atm vol * sqrt(T)) goes first: listed
    wings carry stale mids, so points more than three robust deviations (and at least two vol points)
    from that curve are dropped and it is refitted until nothing moves. Its value at z = 0 is the ATM
    that SABR's alpha is solved from; rho and nu are then calibrated to the surviving points with beta
    fixed. If SABR fits clearly worse than the polynomial the polynomial is kept and the fit says so.

    Each point gets ``used`` and ``resid`` (market vol minus fitted vol, in absolute vol). Pillars
    outside the strikes that survive are left blank rather than extrapolated. The curve runs a little
    beyond the data when the model is SABR, with those points marked ``extrapolated``. The fitted curve
    is checked for negative butterflies and the result is returned in the fit.
    """
    pillars: dict[str, float | None] = {name: None for name in PILLAR_DELTAS}
    usable = [p for p in points if FIT_DELTA_RANGE[0] <= p["call_delta"] <= FIT_DELTA_RANGE[1]]
    for p in points:
        p["used"] = False
        p["resid"] = None
    if len(usable) < 3:
        return pillars, [], ["Fewer than three options near the money returned a mid implied vol."], None

    atm_vol = min(usable, key=lambda p: abs(p["call_delta"] - 0.5))["vol"]
    scale = atm_vol * np.sqrt(T)
    strikes_pt = np.array([p["strike"] for p in usable])
    z = np.log(strikes_pt / forward) / scale
    vol = np.array([p["vol"] for p in usable])
    keep = np.ones(len(usable), dtype=bool)
    max_drops = len(usable) // 3
    while True:
        degree = 4 if keep.sum() >= 12 else 2
        coef = np.polyfit(z[keep], vol[keep], degree)
        resid = np.abs(vol - np.polyval(coef, z))
        spread = 1.4826 * np.median(np.abs(resid[keep] - np.median(resid[keep])))
        worst = int(np.argmax(np.where(keep, resid, -1.0)))
        if resid[worst] <= max(3.0 * spread, OUTLIER_FLOOR) or (~keep).sum() >= max_drops:
            break
        keep[worst] = False
        if keep.sum() < 3:
            return pillars, [], ["The option chain is too noisy to fit a smile."], None
    for p, flag in zip(usable, keep):
        p["used"] = bool(flag)

    poly_rmse = float(np.sqrt(np.mean(resid[keep] ** 2)))
    atm_poly = float(max(np.polyval(coef, 0.0), 0.01))
    fit: dict | None = None
    warnings: list[str] = []
    if keep.sum() >= 4:
        try:
            fit = sabr.calibrate(strikes_pt[keep], vol[keep], forward, T, atm_poly, beta)
        except ValueError:
            fit = None
        if fit is not None and fit["rmse"] > max(1.5 * poly_rmse, SABR_RMSE_FLOOR):
            warnings.append(f"SABR fits this chain poorly (rmse {fit['rmse'] * 100:.1f} vol pts against {poly_rmse * 100:.1f} for a polynomial), so the polynomial is used.")
            fit = None
    if fit is None:
        fit = {"model": "poly", "degree": int(degree), "atm": atm_poly, "rmse": poly_rmse, "n": int(keep.sum())}

    def model(K: np.ndarray) -> np.ndarray:
        if fit["model"] == "sabr":
            return np.asarray(sabr.vol(fit, forward, K, T), dtype=float)
        return np.maximum(np.polyval(coef, np.log(K / forward) / scale), 0.01)

    lo, hi = float(z[keep].min()), float(z[keep].max())
    pad = CURVE_PAD if fit["model"] == "sabr" else 0.0
    grid = np.linspace(lo - pad, hi + pad, 801 + int(2 * pad * 100))
    inside = (grid >= lo) & (grid <= hi)
    strikes = forward * np.exp(grid * scale)
    fit_vol = model(strikes)
    d1 = (np.log(forward / strikes) + 0.5 * fit_vol**2 * T) / (fit_vol * np.sqrt(T))
    delta = ndtr(d1)
    delta_in, vol_in = delta[inside], fit_vol[inside]
    monotone = np.all(np.diff(delta_in) < 0)
    for name, target in PILLAR_DELTAS.items():
        if not (delta_in[-1] - DELTA_SLACK <= target <= delta_in[0] + DELTA_SLACK):
            warnings.append(f"No reliable strikes reach the {name} pillar; it is left blank.")
            continue
        if monotone:
            pillars[name] = float(np.interp(target, delta_in[::-1], vol_in[::-1]))
        else:
            pillars[name] = float(vol_in[int(np.argmin(np.abs(delta_in - target)))])
    dropped = len(usable) - int(keep.sum())
    if dropped:
        warnings.append(f"{dropped} strike{'s' if dropped > 1 else ''} with off-curve mids left out of the fit.")

    fitted_pt = model(strikes_pt)
    for p, f in zip(usable, fitted_pt):
        p["resid"] = float(p["vol"] - f)
    fit["rmse_used"] = float(np.sqrt(np.mean((vol[keep] - fitted_pt[keep]) ** 2)))
    if pillars["25DC"] is not None and pillars["25DP"] is not None and pillars["50D"] is not None:
        fit["rr25"] = pillars["25DC"] - pillars["25DP"]
        fit["bf25"] = 0.5 * (pillars["25DC"] + pillars["25DP"]) - pillars["50D"]
    else:
        fit["rr25"] = fit["bf25"] = None
    fit["density"] = sabr.density(forward, T, strikes[inside], vol_in)
    if fit["density"]["butterfly"]:
        bad = fit["density"]["butterfly"]
        where = f"at {bad[0]:g}" if len(bad) == 1 else f"between {min(bad):g} and {max(bad):g}"
        warnings.append(f"The fitted smile has a negative density {where}: butterflies there price below zero.")

    step = max(1, len(grid) // (80 + int(2 * pad * 10)))
    curve = [
        {"strike": float(k), "vol": float(v), "call_delta": float(d), "extrapolated": not bool(i)}
        for k, v, d, i in zip(strikes[::step], fit_vol[::step], delta[::step], inside[::step])
    ]
    return pillars, curve, warnings, fit
