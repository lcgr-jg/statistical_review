"""Calendar vol spreads between listed months (M+n − M+m) and how they behave into expiry.

ATM comes from each contract's own history (HIST_CALL/PUT_IMP_VOL), which Bloomberg keeps for
live contracts and recently expired ones. The series stops on the option expiry, so the last
date with a vol is that contract's expiry.

Other deltas have no contract history on Bloomberg. Where the app stored a fitted smile for that
contract and day (``cache/smiles``), the stored pillar is used. Otherwise the vol is the contract's
ATM plus the skew of the product's constant-maturity surface (30 and 60 day, 90–110% moneyness)
interpolated to the contract's days to expiry. Strikes beyond 90/110% are extrapolated linearly in
log-moneyness and flagged.
"""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd
from scipy.special import ndtri

from app.market.bbg import MarketDataError, history
from app.market.generic import MONTH_CODES, generic_root

ATM_FIELDS = ["HIST_CALL_IMP_VOL", "HIST_PUT_IMP_VOL"]
MONEYNESS = [0.90, 0.95, 1.00, 1.05, 1.10]
CM_FIELDS = {(tenor, m): f"{tenor}DAY_IMPVOL_{m * 100:.1f}%MNY_DF" for tenor in (30, 60) for m in MONEYNESS}
MAX_EXTRAPOLATION = 0.15
PILLAR_DELTAS = {"10DC": 0.10, "25DC": 0.25, "50D": 0.50, "25DP": 0.75, "10DP": 0.90}
NOTES = [
    "ATM is each contract's own Bloomberg ATM implied vol; the series ends on the option expiry.",
    "Other deltas: a stored smile for that contract and day when the app has one, otherwise the contract's ATM plus the "
    "generic's constant-maturity skew (30d/60d, 90–110% moneyness) at the contract's days to expiry.",
    "Strikes beyond 90% or 110% moneyness are extrapolated from the nearest two moneyness points, for at most 0.15 in "
    "log-moneyness and flat after that, and flagged. Wing spreads that are mostly extrapolated are indicative only.",
]


def contract_tickers(root: str, start: date, months_ahead: int = 8) -> list[tuple[str, date]]:
    """Single-digit-year tickers from ``start`` to a few months ahead, with their delivery month."""
    out = []
    month = date(start.year, start.month, 1)
    stop = date.today() + timedelta(days=31 * months_ahead)
    while month <= stop:
        out.append((f"{root}{MONTH_CODES[month.month - 1]}{month.year % 10} Comdty", month))
        month = date(month.year + (month.month // 12), month.month % 12 + 1, 1)
    return out


def _snapshots(contracts: set[str]) -> dict[tuple[str, str], dict]:
    from app.market.screener import SNAP_DIR

    out: dict[tuple[str, str], dict] = {}
    if not SNAP_DIR.exists():
        return out
    for path in SNAP_DIR.glob("*.json"):
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError:
            continue
        for contract, snap in data.items():
            if contract in contracts and snap.get("pillars"):
                out[(path.stem, contract)] = snap
    return out


def skew_offsets(cm: dict[tuple[int, float], float | None], days: float) -> list[float] | None:
    """Vol minus ATM at each moneyness point, interpolated between the 30 and 60 day surfaces."""
    w = float(np.clip((days - 30.0) / 30.0, 0.0, 1.0))
    rows = []
    for tenor in (30, 60):
        vols = [cm.get((tenor, m)) for m in MONEYNESS]
        rows.append(None if any(v is None or not np.isfinite(v) for v in vols) else np.array(vols, dtype=float))
    if rows[0] is None and rows[1] is None:
        return None
    a = rows[0] if rows[0] is not None else rows[1]
    b = rows[1] if rows[1] is not None else rows[0]
    vols = (1.0 - w) * a + w * b
    return (vols - vols[2]).tolist()


def vol_at_delta(atm: float, offsets: list[float], forward: float, days: float, call_delta: float) -> tuple[float, bool]:
    """Solve the strike with this call delta on ATM + offsets(moneyness). Returns (vol, extrapolated)."""
    x = np.log(np.array(MONEYNESS))
    off = np.array(offsets)
    T = max(days, 1.0) / 365.25

    def smile(log_m: float) -> float:
        if log_m < x[0]:
            slope = (off[1] - off[0]) / (x[1] - x[0])
            value = off[0] + slope * (max(log_m, x[0] - MAX_EXTRAPOLATION) - x[0])
        elif log_m > x[-1]:
            slope = (off[-1] - off[-2]) / (x[-1] - x[-2])
            value = off[-1] + slope * (min(log_m, x[-1] + MAX_EXTRAPOLATION) - x[-1])
        else:
            value = float(np.interp(log_m, x, off))
        return float(np.clip(atm + value, 0.05, 3.0))

    sigma = atm
    z = float(ndtri(call_delta))
    log_m = 0.0
    for _ in range(40):
        log_m = float(np.clip(-sigma * np.sqrt(T) * z + 0.5 * sigma * sigma * T, -2.0, 2.0))
        new = smile(log_m)
        if abs(new - sigma) < 1e-7:
            sigma = new
            break
        sigma = 0.5 * sigma + 0.5 * new
    return sigma, not (x[0] - 1e-9 <= log_m <= x[-1] + 1e-9)


def _delta_from_pillar_name(delta: float) -> str | None:
    for name, value in PILLAR_DELTAS.items():
        if abs(value - delta) < 1e-9:
            return name
    return None


def vol_rolls(ticker: str, front: int = 1, back: int = 2, call_delta: float = 0.5, years: float = 3.0, lookback: int = 60) -> dict:
    if not 1 <= front < back <= 8:
        raise ValueError("Pick a front month before the back month, both between M+1 and M+8.")
    if not 0.02 <= call_delta <= 0.98:
        raise ValueError("Delta must be a call delta between 0.02 and 0.98 (a 25 delta put is 0.75).")
    root = generic_root(ticker)
    end = datetime.combine(date.today(), datetime.min.time())
    start = end - timedelta(days=int(365.25 * float(np.clip(years, 0.5, 3.5))))
    listed = contract_tickers(root, start.date())
    tickers = [t for t, _ in listed]
    raw = history(tickers, ["PX_LAST", *ATM_FIELDS], start - timedelta(days=200), end)
    if raw.empty:
        raise MarketDataError(f"No contract history for {root}.")

    atm: dict[str, pd.Series] = {}
    px: dict[str, pd.Series] = {}
    for t in tickers:
        cols = [raw[f"{t}_{f}"].astype(float) for f in ATM_FIELDS if f"{t}_{f}" in raw]
        if not cols:
            continue
        s = (pd.concat(cols, axis=1).mean(axis=1, skipna=True) / 100.0).dropna()
        s = s[s > 0]
        if len(s) < 5:
            continue
        atm[t] = s
        px[t] = raw.get(f"{t}_PX_LAST", pd.Series(dtype=float)).astype(float)
    if len(atm) < back:
        raise MarketDataError(f"Bloomberg has contract ATM vol history for only {len(atm)} {root} contracts.")

    today = pd.Timestamp(date.today())
    last_seen = max(s.index.max() for s in atm.values())
    expiry: dict[str, pd.Timestamp] = {}
    live = _live_expiries(ticker)
    for t, s in atm.items():
        end_of_series = s.index.max()
        if t in live:
            expiry[t] = pd.Timestamp(live[t])
        elif end_of_series < last_seen - pd.Timedelta(days=3):
            expiry[t] = end_of_series
    order = sorted(expiry, key=lambda t: expiry[t])

    use_skew = abs(call_delta - 0.5) > 1e-9
    cm: dict = {}
    if use_skew:
        g1 = f"{root}1 Comdty"
        cm_raw = history([g1], list(CM_FIELDS.values()), start - timedelta(days=200), end)
        cm = {key: cm_raw.get(f"{g1}_{field}", pd.Series(dtype=float)).astype(float) / 100.0 for key, field in CM_FIELDS.items()}
    pillar = _delta_from_pillar_name(call_delta)
    snaps = _snapshots(set(order)) if use_skew and pillar else {}

    def vol(t: str, day: pd.Timestamp) -> tuple[float | None, str]:
        a = atm[t].get(day)
        if a is None or not np.isfinite(a):
            return None, ""
        if not use_skew:
            return float(a), "atm"
        snap = snaps.get((day.strftime("%Y-%m-%d"), t))
        if snap and snap["pillars"].get(pillar) is not None:
            return float(snap["pillars"][pillar]), "snapshot"
        days = (expiry[t] - day).days
        offsets = skew_offsets({k: _at(s, day) for k, s in cm.items()}, days)
        forward = _at(px[t], day)
        if offsets is None or forward is None:
            return None, ""
        value, extrapolated = vol_at_delta(float(a), offsets, forward, days, call_delta)
        return value, "extrapolated" if extrapolated else "skew"

    # Before the earliest known expiry's own front-month window, older contracts with no vol history would be M+1.
    first_valid = max(pd.Timestamp(start), expiry[order[0]] - pd.Timedelta(days=31))
    dates = sorted({d for t in order for d in atm[t].index if first_valid <= d <= end})
    series = {"dates": [], "front": [], "back": [], "front_vol": [], "back_vol": [], "spread": [], "dte": [], "source": []}
    for day in dates:
        alive = [t for t in order if expiry[t] >= day and day in atm[t].index]
        if len(alive) < back:
            continue
        f, b = alive[front - 1], alive[back - 1]
        fv, fs = vol(f, day)
        bv, bs = vol(b, day)
        if fv is None or bv is None:
            continue
        series["dates"].append(day.strftime("%Y-%m-%d"))
        series["front"].append(f)
        series["back"].append(b)
        series["front_vol"].append(fv)
        series["back_vol"].append(bv)
        series["spread"].append(fv - bv)
        series["dte"].append(int((expiry[alive[0]] - day).days))
        series["source"].append(_worst(fs, bs))

    gap = back - front
    cycles = []
    for i, f in enumerate(order):
        if i + gap >= len(order):
            break
        if i - (front - 1) < 0:
            continue
        b = order[i + gap]
        roll = expiry[order[i - (front - 1)]]
        points = []
        for day in atm[f].index:
            dte = (roll - day).days
            if not (0 <= dte <= lookback) or day not in atm[b].index or day < start:
                continue
            fv, fs = vol(f, day)
            bv, bs = vol(b, day)
            if fv is None or bv is None:
                continue
            points.append({"date": day.strftime("%Y-%m-%d"), "dte": int(dte), "front_vol": fv, "back_vol": bv, "spread": fv - bv, "source": _worst(fs, bs)})
        if len(points) < 3:
            continue
        cycles.append({
            "front": f,
            "back": b,
            "label": f"{_month_label(f)}−{_month_label(b)}",
            "expiry": roll.strftime("%Y-%m-%d"),
            "complete": roll < today,
            "points": points,
        })

    profile = _profile([c for c in cycles if c["complete"]], lookback)
    current = next((c for c in cycles if not c["complete"]), None)
    stats = _stats(current, [c for c in cycles if c["complete"]])
    sources = series["source"] + [p["source"] for c in cycles for p in c["points"]]
    return {
        "root": root,
        "front": front,
        "back": back,
        "call_delta": call_delta,
        "lookback": lookback,
        "series": series,
        "cycles": cycles,
        "profile": profile,
        "stats": stats,
        "sources": {k: sources.count(k) for k in ("atm", "snapshot", "skew", "extrapolated") if k in sources},
        "history_from": min(s.index.min() for s in atm.values()).strftime("%Y-%m-%d"),
        "notes": NOTES if use_skew else NOTES[:1],
    }


def _live_expiries(ticker: str) -> dict[str, str]:
    from app.market.discovery import expiries

    try:
        rows = expiries(ticker, 12)["contracts"]
    except Exception:
        return {}
    return {r["contract"]: r["option_expiry"] for r in rows if r.get("option_expiry")}


def _at(series: pd.Series, day: pd.Timestamp) -> float | None:
    if series is None or series.empty:
        return None
    value = series.get(day)
    if value is None or not np.isfinite(value):
        prior = series.loc[:day].dropna()
        if prior.empty or (day - prior.index[-1]).days > 5:
            return None
        value = prior.iloc[-1]
    return float(value)


def _worst(a: str, b: str) -> str:
    rank = {"atm": 0, "snapshot": 1, "skew": 2, "extrapolated": 3}
    return a if rank.get(a, 0) >= rank.get(b, 0) else b


def _month_label(ticker: str) -> str:
    head = ticker.split()[0]
    code, year = head[-2], head[-1]
    names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    i = MONTH_CODES.find(code)
    return f"{names[i]}{year}" if i >= 0 else head


def _profile(cycles: list[dict], lookback: int) -> dict:
    out = {"dte": [], "median": [], "p25": [], "p75": [], "n": []}
    for dte in range(lookback, -1, -1):
        values = []
        for c in cycles:
            near = [p for p in c["points"] if abs(p["dte"] - dte) <= 1]
            if near:
                values.append(min(near, key=lambda p: abs(p["dte"] - dte))["spread"])
        if len(values) < 3:
            continue
        out["dte"].append(dte)
        out["median"].append(float(np.median(values)))
        out["p25"].append(float(np.percentile(values, 25)))
        out["p75"].append(float(np.percentile(values, 75)))
        out["n"].append(len(values))
    return out


def _nearest(points: list[dict], dte: int, tol: int = 2) -> dict | None:
    near = [p for p in points if abs(p["dte"] - dte) <= tol]
    return min(near, key=lambda p: abs(p["dte"] - dte)) if near else None


def _stats(current: dict | None, done: list[dict]) -> dict:
    if not current or not current["points"]:
        return {"current": None}
    now = current["points"][-1]
    dte = now["dte"]
    same = [p["spread"] for c in done if (p := _nearest(c["points"], dte))]
    moves = []
    for c in done:
        start = _nearest(c["points"], dte)
        last = min(c["points"], key=lambda p: p["dte"])
        if start and last["dte"] <= 3:
            moves.append(last["spread"] - start["spread"])
    return {
        "current": {"date": now["date"], "dte": dte, "spread": now["spread"], "front_vol": now["front_vol"], "back_vol": now["back_vol"], "pair": current["label"]},
        "cycles_at_same_dte": len(same),
        "percentile_at_same_dte": float(np.mean([v <= now["spread"] for v in same])) if same else None,
        "median_at_same_dte": float(np.median(same)) if same else None,
        "median_change_to_expiry": float(np.median(moves)) if moves else None,
        "share_rising_to_expiry": float(np.mean([m > 0 for m in moves])) if moves else None,
        "cycles_to_expiry": len(moves),
    }
