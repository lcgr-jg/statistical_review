"""Build a futures curve and a delta smile from the underlying config.

Contracts are generated from the ticker template rather than ``FUT_CHAIN``,
because the desk reference wrapper does not unpack bulk fields. A contract is
kept when Bloomberg returns a price and an expiry. Vol pillars with an empty
template are omitted, and the snapshot says so.
"""
from __future__ import annotations

from datetime import date, datetime

import pandas as pd

from app.market.bbg import MarketDataError, as_float, reference
from app.market.config import MONTH_CODES, get_underlying


def _contracts(cfg: dict, as_of: date, count: int) -> list[dict]:
    template = cfg.get("futures_ticker_template") or ""
    codes = cfg.get("month_codes") or MONTH_CODES
    year, month = as_of.year, as_of.month
    out = []
    for _ in range(count):
        code = codes[month - 1]
        token = {
            "m": code,
            "y": str(year)[-1],
            "yy": f"{year % 100:02d}",
            "yyyy": str(year),
        }
        out.append({
            "month": code,
            "year": year,
            "ticker": template.format(**token),
        })
        month += 1
        if month == 13:
            month = 1
            year += 1
    return out


def _pillar_ticker(template: str, contract: dict, pillar: str) -> str | None:
    if not template:
        return None
    return template.format(
        m=contract["month"],
        y=str(contract["year"])[-1],
        yy=f"{contract['year'] % 100:02d}",
        yyyy=str(contract["year"]),
        pillar=pillar,
        contract=f"{contract['month']}{contract['year'] % 100:02d}",
    )


def _as_date(value) -> str | None:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    text = str(value)
    if len(text) >= 10 and text[4] == "-":
        return text[:10]
    return None


def snapshot(underlying_id: str, as_of: date | None = None) -> dict:
    cfg = get_underlying(underlying_id)
    today = as_of or date.today()
    contracts = _contracts(cfg, today, int(cfg.get("curve_months") or 16))
    expiry_field = cfg.get("expiry_field") or "LAST_TRADEABLE_DT"
    fields = ["PX_LAST", expiry_field]
    warnings: list[str] = []
    try:
        frame = reference([c["ticker"] for c in contracts], fields)
    except MarketDataError as exc:
        return {
            "id": underlying_id,
            "name": cfg.get("name", underlying_id),
            "ok": False,
            "error": str(exc),
            "contracts": [],
            "warnings": [],
        }

    pillars_cfg = cfg.get("vol_pillars") or {}
    live = []
    for contract in contracts:
        row = _row(frame, contract["ticker"])
        forward = as_float(row.get("PX_LAST")) if row else None
        expiry = _as_date(row.get(expiry_field)) if row else None
        if forward is None or expiry is None:
            continue
        if date.fromisoformat(expiry) < today:
            continue
        pillars = {}
        for name, template in pillars_cfg.items():
            ticker = _pillar_ticker(str(template or ""), contract, name)
            pillars[name] = {"ticker": ticker, "vol": None}
        live.append({**contract, "forward": forward, "expiry": expiry, "pillars": pillars})

    if not live:
        warnings.append("Bloomberg returned no live contracts for this template. Check the futures ticker pattern.")

    vol_tickers = []
    vol_index = []
    for i, contract in enumerate(live):
        for name, spec in contract["pillars"].items():
            if spec["ticker"]:
                vol_tickers.append(spec["ticker"])
                vol_index.append((i, name))
    missing = [name for name, template in pillars_cfg.items() if not template]
    if missing:
        warnings.append(
            "No ticker configured for " + ", ".join(missing) + ". The resolver can search for them."
        )
    if expiry_field == "LAST_TRADEABLE_DT":
        warnings.append(
            "Expiry is the future's last tradeable date. Option expiry can be a few sessions earlier."
        )

    if vol_tickers:
        try:
            vols = reference(vol_tickers, ["PX_LAST"])
        except MarketDataError as exc:
            warnings.append(str(exc))
            vols = None
        if vols is not None:
            for (i, name), ticker in zip(vol_index, vol_tickers):
                row = _row(vols, ticker)
                value = as_float(row.get("PX_LAST")) if row else None
                # Bloomberg quotes implied vol in percent. Store absolute vol.
                if value is not None and value > 3:
                    value = value / 100.0
                live[i]["pillars"][name]["vol"] = value

    return {
        "id": underlying_id,
        "name": cfg.get("name", underlying_id),
        "ok": True,
        "currency": cfg.get("currency", ""),
        "unit": cfg.get("unit", ""),
        "multiplier": cfg.get("multiplier", 1.0),
        "rate": cfg.get("rate", 0.0),
        "as_of": today.isoformat(),
        "futures_root": cfg.get("futures_root", ""),
        "contracts": live,
        "warnings": warnings,
    }


def _row(frame, ticker: str) -> dict | None:
    if frame is None or frame.empty:
        return None
    if ticker in frame.index:
        return frame.loc[ticker].to_dict()
    return None


# ATM call implied vol of the contract itself. On a listed commodity future this is the 50-delta
# vol of that expiry, so the regression does not need a second ticker.
ATM_VOL_FIELD = "HIST_CALL_IMP_VOL"


def vol_series_label(futures_ticker: str, vol_ticker: str | None) -> str:
    if vol_ticker:
        return vol_ticker
    return f"{futures_ticker} {ATM_VOL_FIELD}"


def history_for_contract(
    futures_ticker: str,
    start: date,
    end: date,
    vol_ticker: str | None = None,
    rr_ticker: str | None = None,
    pillar_tickers: dict[str, str] | None = None,
):
    """Return aligned daily series. Vols quoted above 3 are treated as percent.

    With no ``vol_ticker``, ATM vol is the contract's own 50-delta call implied vol.
    """
    from app.market.bbg import history

    tickers = [futures_ticker]
    fields = ["PX_LAST"]
    if not vol_ticker:
        fields.append(ATM_VOL_FIELD)
    extra = {}
    if vol_ticker:
        extra["atm"] = vol_ticker
    if rr_ticker:
        extra["rr"] = rr_ticker
    for name, ticker in (pillar_tickers or {}).items():
        if ticker:
            extra[name] = ticker
    tickers.extend(extra.values())
    frame = history(
        tickers,
        fields,
        datetime(start.year, start.month, start.day),
        datetime(end.year, end.month, end.day),
    )
    if frame.empty:
        return frame

    def col(ticker: str, field: str = "PX_LAST") -> pd.Series:
        name = f"{ticker}_{field}"
        if name not in frame.columns:
            return pd.Series(index=frame.index, dtype=float)
        return pd.to_numeric(frame[name], errors="coerce")

    out = pd.DataFrame({"futures": col(futures_ticker)})
    if not vol_ticker:
        series = col(futures_ticker, ATM_VOL_FIELD)
        if series.dropna().median() > 3:
            series = series / 100.0
        out["atm"] = series
    for key, ticker in extra.items():
        series = col(ticker)
        if series.dropna().median() > 3:
            series = series / 100.0
        out[key] = series
    out.index = pd.to_datetime(out.index)
    return out.dropna(subset=["futures"])
