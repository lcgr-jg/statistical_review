"""Continuous history for a futures product from its 1st and 2nd generic contracts.

Daily log returns are taken on the 1st generic. On a roll day (FUT_CUR_GEN_TICKER changes) the
return is today's 1st generic against yesterday's 2nd generic, which is the same contract, so the
series has no roll gaps. Constant-maturity implied vols come from the 1st generic:
30/60-day ATM and the 30-day 90% / 110% moneyness wings, all as decimals (0.80 = 80%).
"""
from __future__ import annotations

import re
import time
from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd

from app.market.bbg import MarketDataError, history

IV_FIELDS = {
    "iv30": "30DAY_IMPVOL_100.0%MNY_DF",
    "iv60": "60DAY_IMPVOL_100.0%MNY_DF",
    "iv90m": "30DAY_IMPVOL_90.0%MNY_DF",
    "iv110m": "30DAY_IMPVOL_110.0%MNY_DF",
}
GEN_FIELD = "FUT_CUR_GEN_TICKER"
MONTH_CODES = "FGHJKMNQUVXZ"
_memo: dict[tuple, tuple[float, pd.DataFrame]] = {}
TTL = 1800.0


def generic_root(ticker: str) -> str:
    """'FJSZ6 Comdty' / 'FJSA Comdty' / 'FJS1 Comdty' -> 'FJS'."""
    head = ticker.strip().split()[0]
    match = re.fullmatch(rf"(.+?)[{MONTH_CODES}]\d{{1,2}}", head)
    if match:
        return match.group(1)
    match = re.fullmatch(r"(.+?)\d", head)
    if match:
        return match.group(1)
    if head.endswith("A") and len(head) > 2:
        return head[:-1]
    return head


def generic_history(ticker: str, years: float = 6.0) -> pd.DataFrame:
    """Columns: f1, f2, gen, ret, iv30, iv60, iv90m, iv110m. Index: session dates."""
    root = generic_root(ticker)
    years = float(np.clip(years, 1.0, 12.0))
    key = (root, round(years, 2))
    hit = _memo.get(key)
    if hit and time.time() - hit[0] < TTL:
        return hit[1].copy()
    g1, g2 = f"{root}1 Comdty", f"{root}2 Comdty"
    end = datetime.combine(date.today(), datetime.min.time())
    start = end - timedelta(days=int(365.25 * years))
    raw = history([g1, g2], ["PX_LAST", GEN_FIELD, *IV_FIELDS.values()], start, end)
    if raw.empty or f"{g1}_PX_LAST" not in raw:
        raise MarketDataError(f"No generic history for {g1}. Check the product root ({root}).")
    frame = build_continuous(
        raw[f"{g1}_PX_LAST"],
        raw.get(f"{g2}_PX_LAST"),
        raw.get(f"{g1}_{GEN_FIELD}"),
        {name: raw.get(f"{g1}_{field}") for name, field in IV_FIELDS.items()},
    )
    frame.attrs["root"] = root
    _memo[key] = (time.time(), frame)
    return frame.copy()


def build_continuous(f1: pd.Series, f2: pd.Series | None, gen: pd.Series | None, ivs: dict[str, pd.Series | None]) -> pd.DataFrame:
    index = pd.to_datetime(f1.index)
    out = pd.DataFrame(index=index)
    out["f1"] = pd.to_numeric(pd.Series(f1.to_numpy(), index=index), errors="coerce")
    out["f2"] = np.nan if f2 is None else pd.to_numeric(pd.Series(f2.reindex(f1.index).to_numpy(), index=index), errors="coerce")
    out["gen"] = None if gen is None else pd.Series(gen.reindex(f1.index).to_numpy(), index=index).ffill()
    out = out[out["f1"] > 0].sort_index()
    prev_f1 = out["f1"].shift(1)
    prev_f2 = out["f2"].shift(1)
    rolled = out["gen"].notna() & out["gen"].shift(1).notna() & (out["gen"] != out["gen"].shift(1))
    base = np.where(rolled & (prev_f2 > 0), prev_f2, prev_f1)
    out["ret"] = np.log(out["f1"] / base)
    out["rolled"] = rolled
    for name, series in ivs.items():
        if series is None:
            out[name] = np.nan
        else:
            values = pd.to_numeric(pd.Series(series.reindex(f1.index).to_numpy(), index=pd.to_datetime(f1.index)), errors="coerce")
            out[name] = values.reindex(out.index) / 100.0
    return out


def iv_at(frame: pd.DataFrame, tenor_days: float) -> pd.Series:
    """ATM implied for a tenor in calendar days: linear between 30 and 60 days, flat outside."""
    w = float(np.clip((tenor_days - 30.0) / 30.0, 0.0, 1.0))
    iv30 = frame["iv30"]
    iv60 = frame["iv60"].fillna(iv30)
    return (1.0 - w) * iv30 + w * iv60
