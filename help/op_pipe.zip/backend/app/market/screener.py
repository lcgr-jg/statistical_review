"""Curve screener and smile-change heatmap.

Every fitted smile is stored once per contract per day (``cache/smiles/YYYY-MM-DD.json``), so the
heatmap can show pillar changes against the latest earlier snapshot. ATM changes over 1 day,
1 week and 1 month come from Bloomberg history and need no snapshots.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd

from app.market.bbg import history
from app.market.discovery import ATM_FIELDS, term_structure
from app.settings import CACHE_DIR

SNAP_DIR = CACHE_DIR / "smiles"
SESSIONS = 252
_lock = threading.Lock()
log = logging.getLogger(__name__)


POINT_KEYS = ("strike", "cp", "vol", "call_delta", "price", "used", "resid")


def store_snapshot(smile: dict) -> None:
    """Keep today's fit for the contract: pillars for the heatmaps and rolls, and the SABR parameters,
    every strike's vol and residual, and the parity and static-arbitrage results so the surface can be
    refitted or z-scored later without going back to Bloomberg."""
    pillars = smile.get("pillars") or {}
    if not any(v is not None for v in pillars.values()) or smile.get("main") is False:
        return
    day = smile.get("as_of") or date.today().isoformat()
    path = SNAP_DIR / f"{day}.json"
    fit = smile.get("fit") or None
    parity = smile.get("parity") or None
    record = {
        "pillars": pillars,
        "forward": smile.get("forward"),
        "expiry": smile.get("expiry"),
        "vol_source": smile.get("vol_source"),
        "settle": smile.get("settle"),
        "tick": smile.get("tick"),
        "fit": {k: v for k, v in fit.items() if k != "density"} | {"density_ok": (fit.get("density") or {}).get("ok")} if fit else None,
        "parity": {k: v for k, v in parity.items() if k != "strikes"} if parity else None,
        "arbitrage": smile.get("arbitrage"),
        "points": [{k: p.get(k) for k in POINT_KEYS} for p in smile.get("points") or []],
    }
    with _lock:
        SNAP_DIR.mkdir(parents=True, exist_ok=True)
        data = json.loads(path.read_text()) if path.exists() else {}
        data[smile["contract"]] = record
        path.write_text(json.dumps(data))


def latest_snapshot(contract: str, before: date) -> tuple[str, dict] | None:
    if not SNAP_DIR.exists():
        return None
    for path in sorted(SNAP_DIR.glob("*.json"), reverse=True):
        if path.stem >= before.isoformat():
            continue
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError:
            continue
        if contract in data:
            return path.stem, data[contract]
    return None


def today_snapshot(contract: str) -> dict | None:
    path = SNAP_DIR / f"{date.today().isoformat()}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text()).get(contract)
    except json.JSONDecodeError:
        return None


SNAPSHOT_COUNT = int(os.environ.get("SMILE_SNAPSHOT_COUNT", "8"))


def record_curve(product: str, count: int = SNAPSHOT_COUNT) -> list[str]:
    """Fit and store today's smile for the first ``count`` listed expiries. Returns the contracts stored."""
    from app.market.discovery import expiries, smile

    stored = []
    for row in expiries(product, count)["contracts"][:count]:
        try:
            store_snapshot(smile(row["contract"]))
            stored.append(row["contract"])
        except Exception as exc:
            log.warning("Smile snapshot failed for %s: %s", row["contract"], exc)
    return stored


async def record_daily(products: list[str], count: int = SNAPSHOT_COUNT, after_hour: int = 17) -> None:
    """Once per weekday after ``after_hour`` London time, snapshot the front of each product's curve."""
    from zoneinfo import ZoneInfo

    done: set[tuple[str, str]] = set()
    while True:
        now = datetime.now(ZoneInfo("Europe/London"))
        if now.weekday() < 5 and now.hour >= after_hour:
            for product in products:
                key = (now.date().isoformat(), product)
                if key in done:
                    continue
                try:
                    stored = await asyncio.to_thread(record_curve, product, count)
                    log.info("Stored %d smiles for %s", len(stored), product)
                    done.add(key)
                except Exception as exc:
                    log.warning("Daily smile snapshot failed for %s: %s", product, exc)
        await asyncio.sleep(1800)


def screener(product: str, limit: int = 12) -> dict:
    term = term_structure(product, limit)
    rows = term["contracts"]
    if not rows:
        return {"product": product, "rows": [], "warning": term["warning"]}
    contracts = [r["contract"] for r in rows]
    end = datetime.combine(date.today(), datetime.min.time())
    hist = history(contracts, ["PX_LAST", *ATM_FIELDS], end - timedelta(days=400), end)
    out = []
    for row in rows:
        c = row["contract"]
        px = hist.get(f"{c}_PX_LAST", pd.Series(dtype=float)).astype(float).dropna() if not hist.empty else pd.Series(dtype=float)
        atm_cols = [hist.get(f"{c}_{f}") for f in ATM_FIELDS] if not hist.empty else []
        atm_cols = [s.astype(float) for s in atm_cols if s is not None]
        atm_hist = (pd.concat(atm_cols, axis=1).mean(axis=1, skipna=True) / 100.0).dropna() if atm_cols else pd.Series(dtype=float)
        ret = np.log(px / px.shift(1)).dropna()
        rv20 = float(ret.tail(20).std(ddof=1) * np.sqrt(SESSIONS)) if len(ret) >= 15 else None
        atm = row["atm"]
        # The live ATM is today's. History ends today after settlement and yesterday before it,
        # so "previous close" is the last row whose date is before today.
        before_today = atm_hist[atm_hist.index.normalize() < pd.Timestamp(date.today())]
        prev = float(before_today.iloc[-1]) if len(before_today) else None
        pct = float((atm_hist <= atm).mean()) if atm is not None and len(atm_hist) > 20 else None
        snap_prev = latest_snapshot(c, date.today())
        snap_now = today_snapshot(c)
        pillar_change = None
        if snap_prev and snap_now:
            pillar_change = {
                k: (snap_now["pillars"].get(k) - v) if v is not None and snap_now["pillars"].get(k) is not None else None
                for k, v in snap_prev[1]["pillars"].items()
            }
        out.append({
            **row,
            "chg_1d": None if atm is None or prev is None else atm - prev,
            "chg_1w": None if atm is None or row["atm_1w"] is None else atm - row["atm_1w"],
            "chg_1m": None if atm is None or row["atm_1m"] is None else atm - row["atm_1m"],
            "rv20": rv20,
            "iv_minus_rv": None if atm is None or rv20 is None else atm - rv20,
            "atm_pct_1y": pct,
            "pillar_change": pillar_change,
            "pillar_change_since": snap_prev[0] if snap_prev and snap_now else None,
        })
    return {"product": product, "rows": out, "warning": term["warning"]}
