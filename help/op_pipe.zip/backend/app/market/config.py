from __future__ import annotations

from pathlib import Path

import yaml

from app.settings import CONFIG_PATH

MONTH_CODES = "FGHJKMNQUVXZ"


def load_config(path: Path | None = None) -> dict:
    target = path or CONFIG_PATH
    raw = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    return raw.get("underlyings") or {}


def save_underlying(underlying_id: str, payload: dict, path: Path | None = None) -> None:
    target = path or CONFIG_PATH
    raw = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    raw.setdefault("underlyings", {})
    raw["underlyings"][underlying_id] = payload
    target.write_text(yaml.safe_dump(raw, sort_keys=False), encoding="utf-8")


def list_underlyings() -> list[dict]:
    out = []
    for key, cfg in load_config().items():
        pillars = cfg.get("vol_pillars") or {}
        out.append({
            "id": key,
            "name": cfg.get("name", key),
            "currency": cfg.get("currency", ""),
            "unit": cfg.get("unit", ""),
            "multiplier": cfg.get("multiplier", 1.0),
            "rate": cfg.get("rate", 0.0),
            "model": cfg.get("model", "black76"),
            "futures_root": cfg.get("futures_root", ""),
            "futures_ticker_template": cfg.get("futures_ticker_template", ""),
            "expiry_field": cfg.get("expiry_field", "LAST_TRADEABLE_DT"),
            "vol_pillars": pillars,
            "configured_pillars": [name for name, ticker in pillars.items() if ticker],
            "notes": cfg.get("notes", ""),
        })
    return out


def get_underlying(underlying_id: str) -> dict:
    cfg = load_config().get(underlying_id)
    if cfg is None:
        raise KeyError(underlying_id)
    return cfg
