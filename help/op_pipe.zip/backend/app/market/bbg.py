"""Bloomberg access through the desk B-PIPE session.

``BBGQuery`` is a process-wide singleton and its session is not safe to share across threads, so
every call takes one lock. Its own ``fetch_live`` / ``fetch_hist`` wait for a final response with
no deadline (``fetch_hist`` calls ``nextEvent()`` with no timeout, and neither stops on a failed
request), so one lost reply would hold that lock forever and stall the whole API. Requests here
are therefore sent on the raw session with a correlation id and a deadline, waiting for the lock is
bounded, and repeated timeouts reopen the session.

Reference data is memoised for a short TTL. History is stored as parquet and reused until it goes stale.
"""
from __future__ import annotations

import itertools
import logging
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

from app.settings import CACHE_DIR, settings

log = logging.getLogger(__name__)

REFDATA = "//blp/refdata"

_lock = threading.Lock()
_query = None
_memo: dict[tuple, tuple[float, pd.DataFrame]] = {}
_open_services: set[str] = set()
_ids = itertools.count(1)
_timeouts = 0


class MarketDataError(RuntimeError):
    pass


def _client():
    global _query
    if _query is None:
        try:
            from jain_commods.core.interfaces.bloomberg.bpipe import BBGQuery
        except Exception as exc:  # pragma: no cover - import depends on the desk env
            raise MarketDataError(
                "Could not import BBGQuery. Run the API from the corelib environment."
            ) from exc
        try:
            _query = BBGQuery(p_on_server=True)
        except Exception as exc:
            raise MarketDataError(f"Bloomberg session did not start: {exc}") from exc
        if _query.session is None:
            _forget_session()
            raise MarketDataError("Bloomberg session started but //blp/refdata did not open.")
        _open_services.add(REFDATA)
    return _query


def _forget_session() -> None:
    """Drop the session so the next call opens a fresh one. Called with the lock held."""
    global _query, _timeouts
    old, _query, _timeouts = _query, None, 0
    _open_services.clear()
    try:
        from jain_commods.core.interfaces.bloomberg.bpipe import BBGQuery

        BBGQuery._instance = None
    except Exception:  # pragma: no cover - import depends on the desk env
        pass
    session = getattr(old, "session", None)
    if session is not None:
        try:
            session.stopAsync()
        except Exception:  # pragma: no cover - best effort on a session that is already broken
            pass


@contextmanager
def _session_lock():
    if not _lock.acquire(timeout=settings.bbg_lock_wait_seconds):
        raise MarketDataError(
            f"Bloomberg is busy: another request has held the session for over {settings.bbg_lock_wait_seconds:.0f}s. Try again shortly."
        )
    try:
        yield
    finally:
        _lock.release()


def _timed_out(operation: str, timeout: float) -> MarketDataError:
    global _timeouts
    _timeouts += 1
    if _timeouts >= settings.bbg_reset_after_timeouts:
        log.warning("%s timed out %d times in a row; reopening the Bloomberg session.", operation, _timeouts)
        _forget_session()
    return MarketDataError(f"{operation} timed out after {timeout:.0f}s.")


def request(service: str, operation: str, payload: dict, timeout: float | None = None) -> list[dict]:
    """Send one raw request on the B-PIPE session and return each of its response messages as a dict.

    Only messages carrying this request's correlation id are read, so a late reply to an earlier
    request that timed out cannot be taken for this one.
    """
    global _timeouts
    try:
        import blpapi
    except Exception as exc:  # pragma: no cover - depends on the desk env
        raise MarketDataError("blpapi is not installed in this environment.") from exc
    timeout = settings.bbg_reference_timeout_seconds if timeout is None else timeout
    with _session_lock():
        session = _client().session
        cid = blpapi.CorrelationId(next(_ids))
        try:
            if service not in _open_services:
                if not session.openService(service):
                    raise MarketDataError(f"Could not open {service}.")
                _open_services.add(service)
            req = session.getService(service).createRequest(operation)
            req.fromPy(payload)
            session.sendRequest(req, correlationId=cid)
            out: list[dict] = []
            deadline = time.monotonic() + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    try:
                        session.cancel(cid)
                    except Exception:
                        pass
                    raise _timed_out(operation, timeout)
                event = session.nextEvent(int(min(500, remaining * 1000)) or 1)
                kind = event.eventType()
                done = False
                for msg in event:
                    if kind == blpapi.Event.SESSION_STATUS and str(msg.messageType()) in ("SessionTerminated", "SessionConnectionDown"):
                        _forget_session()
                        raise MarketDataError(f"Bloomberg session dropped ({msg.messageType()}). Retry to reconnect.")
                    if cid not in msg.correlationIds():
                        continue
                    if kind == blpapi.Event.REQUEST_STATUS:
                        raise MarketDataError(f"{operation} failed: {msg}")
                    if kind in (blpapi.Event.PARTIAL_RESPONSE, blpapi.Event.RESPONSE):
                        out.append(msg.toPy())
                        done = done or kind == blpapi.Event.RESPONSE
                if done:
                    _timeouts = 0
                    return out
        except MarketDataError:
            raise
        except Exception as exc:
            raise MarketDataError(f"{operation} failed: {exc}") from exc


def security_data(messages: list[dict]) -> list[dict]:
    rows: list[dict] = []
    for msg in messages:
        block = msg.get("securityData")
        if isinstance(block, list):
            rows.extend(block)
        elif isinstance(block, dict):
            rows.append(block)
    return rows


def reference(tickers: list[str], fields: list[str]) -> pd.DataFrame:
    """Live reference data, one row per ticker and one column per field, as ``BBGQuery.fetch_live`` returns it."""
    key = ("bdp", tuple(tickers), tuple(fields))
    now = time.time()
    hit = _memo.get(key)
    if hit and now - hit[0] < settings.bbg_ttl_seconds:
        return hit[1].copy()
    msgs = request(REFDATA, "ReferenceDataRequest", {"securities": list(tickers), "fields": list(fields)})
    data = {row.get("security", ""): dict(row.get("fieldData") or {}) for row in security_data(msgs)}
    frame = pd.DataFrame.from_dict(data, orient="index") if data else pd.DataFrame()
    _memo[key] = (now, frame)
    return frame.copy()


def _slug(tickers: list[str], fields: list[str]) -> str:
    import hashlib

    raw = "__".join(tickers + fields)
    keep = "".join(c if c.isalnum() else "_" for c in raw)[:120]
    return f"{keep}_{hashlib.sha1(raw.encode()).hexdigest()[:10]}"


def _fetch_history(tickers: list[str], fields: list[str], start: datetime, end: datetime) -> pd.DataFrame:
    """HistoricalDataRequest, framed like ``BBGQuery.fetch_hist``: a date index and ``{ticker}_{field}`` columns."""
    msgs = request(
        REFDATA,
        "HistoricalDataRequest",
        {
            "securities": list(tickers),
            "fields": list(fields),
            "startDate": start.strftime("%Y%m%d"),
            "endDate": end.strftime("%Y%m%d"),
            "periodicitySelection": "DAILY",
        },
        timeout=settings.bbg_history_timeout_seconds,
    )
    rows: dict[str, list[dict]] = {}
    for block in security_data(msgs):
        ticker = block.get("security", "")
        rows.setdefault(ticker, []).extend(r for r in block.get("fieldData") or [] if isinstance(r, dict) and "date" in r)
    frames = []
    for ticker, records in rows.items():
        if not records:
            continue
        df = pd.DataFrame(records).set_index("date").reindex(columns=fields)
        df.columns = [f"{ticker}_{col}" for col in df.columns]
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    out = frames[0]
    for df in frames[1:]:
        out = out.merge(df, how="outer", left_index=True, right_index=True)
    out.index = pd.to_datetime(out.index)
    return out


def history(tickers: list[str], fields: list[str], start: datetime, end: datetime) -> pd.DataFrame:
    """Daily history. Columns are ``{ticker}_{field}``."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    path = CACHE_DIR / f"{_slug(tickers, fields)}.parquet"
    cached = _read_cache(path)
    fresh = cached is not None and _cache_covers(cached, start, end)
    if fresh:
        return _slice(cached, start, end)
    try:
        fetched = _fetch_history(tickers, fields, start, end)
    except MarketDataError:
        if cached is not None:
            log.warning("History refresh failed for %s; serving the cached copy.", tickers[:3])
            return _slice(cached, start, end)
        raise
    if fetched is None or fetched.empty:
        if cached is not None:
            return _slice(cached, start, end)
        return pd.DataFrame()
    fetched.index = pd.to_datetime(fetched.index)
    merged = fetched if cached is None else pd.concat([cached, fetched]).sort_index()
    merged = merged[~merged.index.duplicated(keep="last")]
    merged.to_parquet(path)
    return _slice(merged, start, end)


def _read_cache(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    age = datetime.now() - datetime.fromtimestamp(path.stat().st_mtime)
    frame = pd.read_parquet(path)
    frame.index = pd.to_datetime(frame.index)
    if age > timedelta(hours=settings.history_refresh_hours):
        # Keep it so a failed refresh can still fall back, but do not treat it as fresh.
        frame.attrs["stale"] = True
    return frame


def _cache_covers(frame: pd.DataFrame, start: datetime, end: datetime) -> bool:
    if frame.attrs.get("stale"):
        return False
    if frame.empty:
        return False
    return frame.index.min() <= pd.Timestamp(start) and frame.index.max() >= pd.Timestamp(end) - pd.Timedelta(days=4)


def _slice(frame: pd.DataFrame, start: datetime, end: datetime) -> pd.DataFrame:
    idx = pd.to_datetime(frame.index)
    mask = (idx >= pd.Timestamp(start)) & (idx <= pd.Timestamp(end))
    out = frame.loc[mask].copy()
    out.index = pd.to_datetime(out.index)
    return out


def as_float(value) -> float | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if np.isnan(number):
        return None
    return number
