"""The whole surface of a product: every listed expiry's fitted smile today, and the history of the
fit parameters from the daily snapshots.

``surface`` fits each expiry with ``discovery.smile`` (settlement prices by default) and returns one
row per expiry with the SABR parameters, the 25-delta risk reversal and butterfly, the fit error and
the three checks (fitted density, static arbitrage on the settlements, put-call parity). Each fit is
stored as today's snapshot on the way.

``surface_history`` reads ``cache/smiles`` and turns the snapshots into time series of ATM, RR25, BF25,
rho and nu, both per listed contract and per curve position (M+1, M+2, ...), with z-scores of the
latest value against each series' own history. Snapshots from before the SABR fit was stored carry
pillars only, so RR and BF are computed from the pillars and rho and nu are blank there.
"""
from __future__ import annotations

import json
import logging
from datetime import date

import numpy as np

from app.market.bbg import MarketDataError
from app.market.discovery import expiries, prime_smiles, smile
from app.market.screener import SNAP_DIR, store_snapshot

log = logging.getLogger(__name__)

SERIES_KEYS = ("atm", "rr25", "bf25", "rho", "nu", "rmse", "forward")
CURVE_STEP = 4


def _rr_bf(pillars: dict) -> tuple[float | None, float | None]:
    c, p, a = pillars.get("25DC"), pillars.get("25DP"), pillars.get("50D")
    rr = c - p if c is not None and p is not None else None
    bf = 0.5 * (c + p) - a if c is not None and p is not None and a is not None else None
    return rr, bf


def _row(listing: dict, fitted: dict, today: date) -> dict:
    fit = fitted.get("fit") or {}
    parity = fitted.get("parity") or {}
    arbitrage = fitted.get("arbitrage") or {}
    density = fit.get("density") or {}
    pillars = fitted.get("pillars") or {}
    rr, bf = _rr_bf(pillars)
    points = fitted.get("points") or []
    expiry = fitted.get("expiry") or listing.get("option_expiry")
    return {
        "contract": fitted["contract"],
        "label": fitted.get("label") or listing.get("label"),
        "expiry": expiry,
        "days": (date.fromisoformat(expiry) - today).days if expiry else None,
        "forward": fitted.get("forward"),
        "pillars": pillars,
        "vol_source": fitted.get("vol_source"),
        "model": fit.get("model"),
        "alpha": fit.get("alpha"),
        "beta": fit.get("beta"),
        "rho": fit.get("rho"),
        "nu": fit.get("nu"),
        "rmse": fit.get("rmse_used", fit.get("rmse")),
        "rr25": fit.get("rr25", rr),
        "bf25": fit.get("bf25", bf),
        "n_used": sum(1 for p in points if p.get("used")),
        "n_points": len(points),
        "density_ok": density.get("ok"),
        "arbitrage_ok": arbitrage.get("ok"),
        "parity_break": parity.get("break"),
        "parity_diff": parity.get("diff"),
        "warnings": fitted.get("warnings") or [],
        "curve": [
            {"call_delta": c["call_delta"], "vol": c["vol"], "strike": c["strike"], "extrapolated": bool(c.get("extrapolated"))}
            for c in (fitted.get("curve") or [])[::CURVE_STEP]
        ],
        "points": [
            {"strike": p["strike"], "cp": p["cp"], "vol": p["vol"], "call_delta": p["call_delta"], "used": bool(p.get("used")), "resid": p.get("resid")}
            for p in points
        ],
        "error": None,
    }


def surface(product: str, limit: int = 12, source: str = "settle") -> dict:
    listing = expiries(product, limit)
    today = date.today()
    try:
        prime_smiles([item["contract"] for item in listing["contracts"]], source)
    except MarketDataError as exc:
        log.warning("Batched quote fetch failed for %s, fitting contract by contract: %s", product, exc)
    rows = []
    for item in listing["contracts"]:
        try:
            fitted = smile(item["contract"], source=source)
        except MarketDataError as exc:
            rows.append({"contract": item["contract"], "label": item["label"], "expiry": item.get("option_expiry"), "days": None, "error": str(exc)})
            continue
        try:
            store_snapshot(fitted)
        except Exception as exc:  # pragma: no cover - disk problems should not break the page
            log.warning("Could not store snapshot for %s: %s", item["contract"], exc)
        rows.append(_row(item, fitted, today))
    return {"product": product, "as_of": today.isoformat(), "source": source, "rows": rows, "warning": listing.get("warning")}


def _load_snapshots() -> dict[str, dict[str, dict]]:
    """{date: {contract: record}} for every stored day, oldest first."""
    out: dict[str, dict[str, dict]] = {}
    if not SNAP_DIR.exists():
        return out
    for path in sorted(SNAP_DIR.glob("*.json")):
        try:
            out[path.stem] = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            continue
    return out


def _values(record: dict) -> dict[str, float | None]:
    fit = record.get("fit") or {}
    pillars = record.get("pillars") or {}
    rr, bf = _rr_bf(pillars)
    return {
        "atm": pillars.get("50D"),
        "rr25": fit.get("rr25", rr),
        "bf25": fit.get("bf25", bf),
        "rho": fit.get("rho") if fit.get("model") == "sabr" else None,
        "nu": fit.get("nu") if fit.get("model") == "sabr" else None,
        "rmse": fit.get("rmse_used", fit.get("rmse")),
        "forward": record.get("forward"),
    }


def _stat(values: list[float | None]) -> dict:
    clean = np.array([v for v in values if v is not None and np.isfinite(v)], dtype=float)
    if not len(clean):
        return {"current": None, "mean": None, "std": None, "z": None, "percentile": None, "n": 0}
    current = float(clean[-1])
    std = float(clean.std(ddof=1)) if len(clean) > 2 else None
    return {
        "current": current,
        "mean": float(clean.mean()),
        "std": std,
        "z": (current - float(clean.mean())) / std if std else None,
        "percentile": float((clean <= current).mean()),
        "n": int(len(clean)),
    }


def surface_history(contracts: list[str] | None = None, ranks: int = 4) -> dict:
    """Time series of the fit parameters from the snapshots.

    ``by_contract`` covers the contracts asked for (default: every contract that appears). ``by_rank``
    follows curve position: on each day the stored contracts whose expiry is still ahead are sorted by
    expiry and M+1 is the first. Each series carries z-score stats of its latest value.
    """
    snaps = _load_snapshots()
    dates = sorted(snaps)
    wanted = set(contracts) if contracts else {c for day in snaps.values() for c in day}
    by_contract: dict[str, dict] = {}
    for contract in sorted(wanted):
        series: dict[str, list] = {k: [] for k in SERIES_KEYS}
        c_dates = []
        for day in dates:
            record = snaps[day].get(contract)
            if not record:
                continue
            c_dates.append(day)
            for k, v in _values(record).items():
                series[k].append(v)
        if c_dates:
            by_contract[contract] = {"dates": c_dates, "series": series, "stats": {k: _stat(series[k]) for k in SERIES_KEYS}}

    by_rank: dict[str, dict] = {}
    for r in range(1, ranks + 1):
        series = {k: [] for k in SERIES_KEYS}
        r_dates = []
        labels = []
        for day in dates:
            live = [(rec.get("expiry") or "9999", c, rec) for c, rec in snaps[day].items() if (rec.get("expiry") or "9999") >= day]
            live.sort()
            if len(live) < r:
                continue
            _, contract, record = live[r - 1]
            r_dates.append(day)
            labels.append(contract)
            for k, v in _values(record).items():
                series[k].append(v)
        if r_dates:
            by_rank[f"M+{r}"] = {"dates": r_dates, "contracts": labels, "series": series, "stats": {k: _stat(series[k]) for k in SERIES_KEYS}}

    return {"days": len(dates), "from": dates[0] if dates else None, "to": dates[-1] if dates else None, "by_contract": by_contract, "by_rank": by_rank}
