from __future__ import annotations

import difflib
import json
import re
from datetime import date, timedelta
from urllib.parse import unquote

import numpy as np
import pandas as pd
from fastapi import APIRouter, Header, HTTPException
from fastapi.responses import StreamingResponse

from app.market import discovery
from app.market.bbg import MarketDataError, as_float, reference
from app.market.config import get_underlying, list_underlyings, load_config, save_underlying
from app.market.surface import history_for_contract, snapshot
from app.quant.montecarlo import black_reference, simulate
from app.quant.path_pnl import evaluate_path
from app.quant.regression import analyse
from app.quant.structures import TEMPLATES, expand_template, pnl_grid, summarise
from app.schemas import (
    AlertIn,
    BacktestRequest,
    BreakevenRequest,
    CopilotChatRequest,
    QuoteParseRequest,
    AnalogRequest,
    GridRequest,
    HistoryRequest,
    MonteCarloRequest,
    PathRequest,
    PriceRequest,
    ResolverChatRequest,
    TemplateRequest,
    UnderlyingProposal,
    VarRequest,
)
from app.settings import CONFIG_PATH, settings

router = APIRouter()


def _bad(exc: Exception) -> HTTPException:
    return HTTPException(status_code=400, detail=str(exc))


@router.get("/health")
async def health():
    # Async so it runs on the event loop: sync routes share a thread pool that blocked Bloomberg calls can fill.
    return {"ok": True}


@router.get("/underlyings")
def underlyings():
    return {"underlyings": list_underlyings()}


@router.get("/market/{underlying_id}/snapshot")
def market_snapshot(underlying_id: str):
    try:
        return snapshot(underlying_id)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Unknown underlying {underlying_id}.")
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/discover/search")
def discover_search(q: str):
    try:
        return {"results": discovery.search(q)}
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/discover/expiries")
def discover_expiries(product: str, limit: int = 18, serials: bool = False):
    try:
        return discovery.expiries(product, max(1, min(limit, 48)), serials=serials)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/discover/smile")
def discover_smile(contract: str, series: str | None = None, source: str = "settle"):
    if source not in ("settle", "mid"):
        raise HTTPException(status_code=400, detail="source must be settle or mid.")
    try:
        result = discovery.smile(contract, series=series, source=source)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    try:
        from app.market.screener import store_snapshot

        store_snapshot(result)
    except Exception:
        pass
    return result


@router.get("/vol/history")
def vol_history(contract: str, years: float = 2.0):
    try:
        return discovery.vol_history(contract, max(0.25, min(years, 10.0)))
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/vol/term")
def vol_term(product: str, limit: int = 18):
    from app.market import warm

    try:
        return warm.term(product, max(1, min(limit, 48)))
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


def _generic(contract: str, years: float):
    from app.market.generic import generic_history

    try:
        return generic_history(contract, years)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.post("/backtest")
def backtest(body: BacktestRequest):
    from app.quant.backtest import run_backtest

    hist = _generic(body.contract, body.years)
    try:
        return run_backtest(
            body.market,
            body.legs,
            body.regime,
            hist,
            body.every,
            body.hedge,
            hedge_delta=body.hedge_delta,
            hedge_cost_bps=body.hedge_cost_bps,
            hedge_band=body.hedge_band,
            entry_cost_vol=body.entry_cost_vol,
            hold=body.hold,
        )
    except ValueError as exc:
        raise _bad(exc)


@router.post("/breakeven")
def breakeven(body: BreakevenRequest):
    from app.quant.backtest import breakeven_analysis

    hist = _generic(body.contract, body.years)
    try:
        return breakeven_analysis(body.market, body.legs, body.regime, hist)
    except ValueError as exc:
        raise _bad(exc)


@router.get("/regimes")
def regimes():
    from app.quant.regimes import REGIMES

    return {"regimes": REGIMES}


@router.post("/risk/var")
def risk_var(body: VarRequest):
    from app.quant.var import book_var

    histories = {p.contract: _generic(p.contract, body.years) for p in body.positions}
    positions = [p.model_dump() | {"market": p.market, "legs": p.legs} for p in body.positions]
    try:
        return book_var(positions, histories, body.regime, body.horizon)
    except ValueError as exc:
        raise _bad(exc)


@router.get("/vol/seasonality")
def vol_seasonality(contract: str, years: float = 8.0):
    from app.quant.backtest import seasonality

    return seasonality(_generic(contract, years))


@router.get("/vol/skew-slope")
def vol_skew_slope(contract: str, years: float = 6.0):
    from app.quant.backtest import skew_slope

    return skew_slope(_generic(contract, years))


@router.get("/vol/rolls")
def vol_rolls_route(ticker: str, front: int = 1, back: int = 2, delta: float = 0.5, years: float = 3.0, lookback: int = 60):
    from app.market.rolls import vol_rolls

    try:
        return vol_rolls(ticker, front, back, delta, years, max(10, min(lookback, 120)))
    except ValueError as exc:
        raise _bad(exc)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/vol/screener")
def vol_screener(product: str, limit: int = 12, refresh: bool = False):
    from app.market import warm

    try:
        return warm.screener(product, max(1, min(limit, 24)), refresh=refresh)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/vol/surface")
def vol_surface(product: str, limit: int = 12, source: str = "settle", refresh: bool = False):
    from app.market import warm

    if source not in ("settle", "mid"):
        raise HTTPException(status_code=400, detail="source must be settle or mid.")
    try:
        return warm.surface(product, max(1, min(limit, 24)), source, refresh=refresh)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/vol/surface/history")
def vol_surface_history(contracts: str | None = None, ranks: int = 4):
    from app.market.vol_surface import surface_history

    wanted = [c.strip() for c in contracts.split(",") if c.strip()] if contracts else None
    return surface_history(wanted, max(1, min(ranks, 8)))


@router.post("/quotes/parse")
async def quotes_parse(body: QuoteParseRequest):
    from app.copilot.quotes import extract, price_quotes

    if not body.text.strip():
        raise HTTPException(status_code=400, detail="Paste a quote first.")
    if not settings.anthropic_api_key:
        raise HTTPException(status_code=503, detail="ANTHROPIC_API_KEY is not set, so quotes cannot be parsed.")
    quotes = await extract(body.text)
    if not quotes:
        return {"quotes": [], "message": "No option quotes found in the text."}
    try:
        priced = price_quotes(quotes, body.product, body.regime, body.rate, body.multiplier)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"quotes": priced}


@router.get("/journal")
def journal_list(deleted: bool = False):
    from app.journal import list_entries

    return {"entries": list_entries(include_deleted=deleted)}


@router.get("/journal/audit")
def journal_audit(limit: int = 200):
    from app.journal import audit

    return {"events": audit(max(1, min(limit, 2000)))}


@router.post("/journal")
def journal_add(entry: dict, x_user: str = Header(default="")):
    from app.journal import add_entry

    if entry.get("kind") not in ("quote", "trade", "idea"):
        raise HTTPException(status_code=400, detail="kind must be quote, trade or idea.")
    return add_entry(entry, author=unquote(x_user))


@router.patch("/journal/{entry_id}")
def journal_update(entry_id: str, patch: dict, x_user: str = Header(default="")):
    from app.journal import update_entry

    entry = update_entry(entry_id, patch, author=unquote(x_user))
    if entry is None:
        raise HTTPException(status_code=404, detail="No such journal entry.")
    return entry


@router.post("/journal/{entry_id}/comments")
def journal_comment(entry_id: str, body: dict, x_user: str = Header(default="")):
    from app.journal import add_comment

    try:
        entry = add_comment(entry_id, str(body.get("text") or ""), author=unquote(x_user))
    except ValueError as exc:
        raise _bad(exc)
    if entry is None:
        raise HTTPException(status_code=404, detail="No such journal entry.")
    return entry


@router.delete("/journal/{entry_id}")
def journal_delete(entry_id: str, x_user: str = Header(default="")):
    from app.journal import delete_entry

    if not delete_entry(entry_id, author=unquote(x_user)):
        raise HTTPException(status_code=404, detail="No such journal entry.")
    return {"ok": True}


@router.get("/alerts")
def alerts_list(check: bool = True):
    from app import alerts

    if check:
        alerts.maybe_check()
    return {"alerts": alerts.list_alerts(), "interval_seconds": alerts.CHECK_SECONDS}


@router.post("/alerts")
def alerts_add(body: AlertIn):
    from app import alerts

    try:
        return alerts.add_alert(body.ticker, body.field, body.op, body.level, body.note)
    except ValueError as exc:
        raise _bad(exc)


@router.post("/alerts/{alert_id}/reset")
def alerts_reset(alert_id: str):
    from app import alerts

    alert = alerts.reset_alert(alert_id)
    if alert is None:
        raise HTTPException(status_code=404, detail="No such alert.")
    return alert


@router.delete("/alerts/{alert_id}")
def alerts_delete(alert_id: str):
    from app import alerts

    if not alerts.delete_alert(alert_id):
        raise HTTPException(status_code=404, detail="No such alert.")
    return {"ok": True}


@router.get("/templates")
def templates():
    return {"templates": [{"id": key, "label": label} for key, label in TEMPLATES.items()]}


@router.post("/structures/template")
def template(body: TemplateRequest):
    try:
        legs = expand_template(body.name, body.expiries, {"qty": body.qty})
    except ValueError as exc:
        raise _bad(exc)
    return {"legs": legs}


@router.post("/structures/price")
def price(body: PriceRequest):
    try:
        return summarise(body.market, body.legs, body.regime, body.follow_beta, body.market.as_of)
    except ValueError as exc:
        raise _bad(exc)


@router.post("/structures/grid")
def grid(body: GridRequest):
    spots = np.linspace(body.spot_min, body.spot_max, body.n_spot)
    vols = np.linspace(body.vol_min, body.vol_max, body.n_vol)
    try:
        return pnl_grid(
            body.market,
            body.legs,
            body.regime,
            body.market.as_of,
            spots,
            vols,
            body.life_fractions,
        )
    except ValueError as exc:
        raise _bad(exc)


@router.post("/paths/evaluate")
def paths(body: PathRequest):
    points = [p.model_dump() for p in body.points]
    try:
        return evaluate_path(
            body.market,
            body.legs,
            body.regime,
            points,
            body.hedge,
            body.vol_source,
            body.market.as_of,
        )
    except ValueError as exc:
        raise _bad(exc)


@router.post("/montecarlo")
def montecarlo(body: MonteCarloRequest):
    try:
        result = simulate(
            body.market,
            body.legs,
            body.regime,
            body.market.as_of,
            body.n_paths,
            body.n_steps,
            body.kappa,
            body.xi,
            body.rho,
            body.sigma_bar,
            body.seed,
            body.n_overlay,
            body.hedge,
        )
        result["black_price"] = black_reference(body.market, body.legs, body.market.as_of)
        return result
    except ValueError as exc:
        raise _bad(exc)


@router.post("/history/spot-vol")
def history_spot_vol(body: HistoryRequest):
    try:
        frame = history_for_contract(
            body.futures_ticker,
            body.start,
            body.end,
            vol_ticker=body.vol_ticker,
            rr_ticker=body.rr_ticker,
            pillar_tickers=body.pillar_tickers,
        )
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    if frame.empty or "atm" not in frame.columns:
        raise HTTPException(
            status_code=404,
            detail="No overlapping futures and ATM vol history. Check the tickers.",
        )
    aligned = frame.dropna(subset=["futures", "atm"])
    stats = analyse(
        aligned["futures"].to_numpy(),
        aligned["atm"].to_numpy(),
        aligned["rr"].to_numpy() if "rr" in aligned.columns else None,
        body.window,
    )
    pillar_cols = [c for c in aligned.columns if c in {"10DC", "25DC", "50D", "25DP", "10DP"}]
    records = []
    for ts, row in aligned.iterrows():
        item = {
            "date": pd.Timestamp(ts).date().isoformat(),
            "futures": _num(row["futures"]),
            "atm": _num(row["atm"]),
            "rr": _num(row["rr"]) if "rr" in aligned.columns else None,
            "pillars": {name: _num(row[name]) for name in pillar_cols},
        }
        records.append(item)
    from app.market.surface import vol_series_label

    return {
        "points": records,
        "stats": stats,
        "window": body.window,
        "vol_series": vol_series_label(body.futures_ticker, body.vol_ticker),
    }


@router.post("/history/analogs")
def history_analogs(body: AnalogRequest):
    """Same calendar month across years, aligned by sessions before expiry.

    Paths are percent moves in the future and absolute vol-point moves in ATM
    vol, both measured from the first day of the window.
    """
    paths = []
    errors = []
    for year in body.years:
        token = {
            "m": body.month_code.upper(),
            "y": str(year)[-1],
            "yy": f"{year % 100:02d}",
            "yyyy": str(year),
            "pillar": "50D",
            "contract": f"{body.month_code.upper()}{year % 100:02d}",
        }
        try:
            futures = body.futures_template.format(**token)
            vol = body.vol_template.format(**token) if body.vol_template else None
        except KeyError as exc:
            raise _bad(exc)
        end = date(year, 12, 31)
        start = end - timedelta(days=int(body.window_days * 2.2))
        try:
            frame = history_for_contract(futures, start, end, vol_ticker=vol)
        except MarketDataError as exc:
            errors.append(f"{year}: {exc}")
            continue
        if frame.empty:
            errors.append(f"{year}: no futures history for {futures}.")
            continue
        window = frame.tail(body.window_days)
        base_f = float(window["futures"].iloc[0])
        base_v = float(window["atm"].iloc[0]) if "atm" in window.columns and pd.notna(window["atm"].iloc[0]) else None
        points = []
        for i, (ts, row) in enumerate(window.iterrows()):
            points.append({
                "date": pd.Timestamp(ts).date().isoformat(),
                "sessions": i,
                "futures_pct": float(row["futures"] / base_f - 1.0),
                "vol_pts": None if base_v is None or pd.isna(row.get("atm", np.nan)) else float(row["atm"] - base_v),
                "futures": float(row["futures"]),
                "atm": None if "atm" not in window.columns or pd.isna(row.get("atm", np.nan)) else float(row["atm"]),
            })
        from app.market.surface import vol_series_label

        paths.append({"year": year, "futures_ticker": futures, "vol_ticker": vol_series_label(futures, vol), "points": points})
    return {"paths": paths, "errors": errors}


def _num(value):
    number = as_float(value)
    return number


@router.post("/resolver/chat")
async def resolver_chat(body: ResolverChatRequest):
    from app.resolver.agent import stream_chat

    async def events():
        try:
            async for event in stream_chat(body.messages, body.underlying_id):
                yield f"event: {event['type']}\ndata: {json.dumps(event['data'])}\n\n"
        except Exception as exc:
            yield f"event: error\ndata: {json.dumps({'message': str(exc)})}\n\n"

    return StreamingResponse(events(), media_type="text/event-stream")


@router.post("/copilot/chat")
async def copilot_chat(body: CopilotChatRequest):
    from app.copilot.agent import stream_chat

    async def events():
        try:
            async for event in stream_chat(
                body.messages, body.market, body.legs, body.mode, body.regime, body.product, body.contract,
                page=body.page, screen=body.context,
            ):
                yield f"event: {event['type']}\ndata: {json.dumps(event['data'])}\n\n"
        except Exception as exc:
            yield f"event: error\ndata: {json.dumps({'message': str(exc)})}\n\n"

    return StreamingResponse(events(), media_type="text/event-stream")


@router.post("/resolver/preview")
def resolver_preview(body: UnderlyingProposal):
    proposal = _proposal_config(body)
    current = load_config()
    before = yaml_dump({"underlyings": {body.id: current.get(body.id)}}) if body.id in current else ""
    after = yaml_dump({"underlyings": {body.id: proposal}})
    diff = "".join(difflib.unified_diff(
        before.splitlines(keepends=True),
        after.splitlines(keepends=True),
        fromfile=f"{body.id} (current)",
        tofile=f"{body.id} (proposal)",
    ))
    checks = _validate_proposal(body)
    return {"diff": diff, "config": proposal, "checks": checks}


@router.post("/resolver/apply")
def resolver_apply(body: UnderlyingProposal):
    checks = _validate_proposal(body)
    failures = [c for c in checks if not c["ok"]]
    if failures:
        raise HTTPException(status_code=422, detail={"message": "Bloomberg did not return data for every ticker.", "checks": checks})
    save_underlying(body.id, _proposal_config(body))
    return {"written": str(CONFIG_PATH), "id": body.id, "checks": checks}


def _proposal_config(body: UnderlyingProposal) -> dict:
    return {
        "name": body.name,
        "currency": body.currency,
        "unit": body.unit,
        "multiplier": body.multiplier,
        "model": "black76",
        "rate": body.rate,
        "futures_root": body.futures_root,
        "futures_ticker_template": body.futures_ticker_template,
        "expiry_field": body.expiry_field,
        "month_codes": body.month_codes,
        "curve_months": body.curve_months,
        "vol_pillars": {k: v or "" for k, v in body.vol_pillars.items()},
        "notes": body.notes,
    }


def _validate_proposal(body: UnderlyingProposal) -> list[dict]:
    checks = []
    tickers = [body.futures_root]
    purposes = ["futures root"]
    for sample in body.sample_checks:
        tickers.append(sample.ticker)
        purposes.append(sample.purpose or sample.field)
    # Probe one formatted vol ticker, using the current month as a stand-in.
    today = date.today()
    token = {
        "m": "FGHJKMNQUVXZ"[today.month - 1],
        "y": str(today.year)[-1],
        "yy": f"{today.year % 100:02d}",
        "yyyy": str(today.year),
        "contract": f"{'FGHJKMNQUVXZ'[today.month - 1]}{today.year % 100:02d}",
    }
    for pillar, template in body.vol_pillars.items():
        if not template:
            continue
        try:
            ticker = template.format(**token, pillar=pillar)
        except KeyError:
            checks.append({"ticker": template, "ok": False, "purpose": pillar, "detail": "Template has an unknown token."})
            continue
        tickers.append(ticker)
        purposes.append(f"{pillar} vol")
    try:
        frame = reference(tickers, ["PX_LAST"])
    except MarketDataError as exc:
        return [{"ticker": t, "ok": False, "purpose": p, "detail": str(exc)} for t, p in zip(tickers, purposes)]
    for ticker, purpose in zip(tickers, purposes):
        row = frame.loc[ticker].to_dict() if ticker in getattr(frame, "index", []) else {}
        value = as_float(row.get("PX_LAST")) if row else None
        checks.append({
            "ticker": ticker,
            "ok": value is not None,
            "purpose": purpose,
            "value": value,
            "detail": None if value is not None else "No PX_LAST.",
        })
    return checks


def yaml_dump(payload: dict) -> str:
    import yaml
    return yaml.safe_dump(payload, sort_keys=False)


def proposal_from_text(text: str) -> dict | None:
    """Pull the last fenced JSON object that contains a proposal."""
    blocks = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.DOTALL)
    candidates = blocks or re.findall(r"(\{.*\})", text, flags=re.DOTALL)
    for raw in reversed(candidates):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict) and "proposal" in parsed:
            return parsed["proposal"]
    return None
