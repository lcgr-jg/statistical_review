"""Pricing and market tools the copilot may call.

Every number the agent is allowed to quote comes back from one of these.
Discovery tools hit B-PIPE; the pricing tools only use the market the user has loaded.
"""
from __future__ import annotations

import itertools
import json

import numpy as np

from app.quant.montecarlo import simulate
from app.quant.structures import (
    TEMPLATES,
    _skew_name,
    expand_template,
    prepare_slices,
    price_package,
    resolve_legs,
    summarise,
)
from app.schemas import LegIn, MarketIn

MAX_COMBINATIONS = 400

SEARCH_LEG_SCHEMA = {
    "type": "object",
    "properties": {
        "call_put": {"type": "string", "enum": ["C", "P"]},
        "qty": {"description": "A number, or a list of numbers to try.", "oneOf": [{"type": "number"}, {"type": "array", "items": {"type": "number"}}]},
        "strike_mode": {"type": "string", "enum": ["absolute", "delta", "pct_atm"]},
        "strike": {"description": "A number, or a list of numbers to try.", "oneOf": [{"type": "number"}, {"type": "array", "items": {"type": "number"}}]},
        "expiry": {"type": "string"},
    },
    "required": ["call_put", "qty", "strike"],
}

LEG_SCHEMA = {
    "type": "object",
    "properties": {
        "call_put": {"type": "string", "enum": ["C", "P"]},
        "qty": {"type": "number"},
        "strike_mode": {"type": "string", "enum": ["absolute", "delta", "pct_atm"]},
        "strike": {"type": "number", "description": "Absolute strike, call delta (0.25 is the 25-delta call, 0.75 the 25-delta put), or percent of the forward."},
        "expiry": {"type": "string", "description": "YYYY-MM-DD. Must be one of the loaded expiries. Omit to use the front."},
    },
    "required": ["call_put", "qty", "strike"],
}


def _num(value, digits: int = 4):
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not np.isfinite(number):
        return None
    return round(number, digits)


def _legs(raw: list[dict] | None, fallback: list[LegIn]) -> list[LegIn]:
    if not raw:
        if not fallback:
            raise ValueError("No legs were given and none are loaded.")
        return fallback
    return [LegIn.model_validate(item) for item in raw]


def _dump(payload: dict) -> str:
    return json.dumps(payload, default=str)


class ToolContext:
    def __init__(self, market: MarketIn, legs: list[LegIn], regime: str, product: str | None, contract: str | None):
        self.market = market
        self.legs = legs
        self.regime = regime
        self.product = product
        self.contract = contract

    def definitions(self) -> list[dict]:
        return [
            {
                "name": "list_templates",
                "description": "Named structures the desk uses, and the view each one expresses. Call this before inventing a structure.",
                "input_schema": {"type": "object", "properties": {}},
            },
            {
                "name": "expand_template",
                "description": "Turn a template name into legs on the loaded expiries (the front one, or the first on or after `expiry`). Calendars and diagonals need two expiries. Price the result with price_structure.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "qty": {"type": "number"},
                        "expiry": {"type": "string", "description": "Optional ISO date to start from."},
                    },
                    "required": ["name"],
                },
            },
            {
                "name": "price_structure",
                "description": "Price legs on the loaded market. Returns premium, greeks, breakevens, max gain and loss, and probability of profit. Omit legs to price what the user has loaded.",
                "input_schema": {
                    "type": "object",
                    "properties": {"legs": {"type": "array", "items": LEG_SCHEMA}},
                },
            },
            {
                "name": "search_structures",
                "description": (
                    "Design and rank structures of your own. Give one or more skeletons, each a list of legs. Any leg's "
                    "strike or qty may be a list, and every combination is priced. Each candidate is scored on the view: "
                    "P&L if spot moves spot_pct and ATM vol moves vol_pts once horizon (0 today, 1 at the front expiry) "
                    "of the front expiry's life has passed. Returns the best candidates with premium, scenario P&L, "
                    "worst ladder loss and the payoff ratio. Constraints drop candidates before ranking."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "skeletons": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "label": {"type": "string"},
                                    "legs": {"type": "array", "items": SEARCH_LEG_SCHEMA},
                                },
                                "required": ["legs"],
                            },
                        },
                        "view": {
                            "type": "object",
                            "properties": {
                                "spot_pct": {"type": "number", "description": "0.15 is a 15% rally, -0.1 a 10% fall."},
                                "vol_pts": {"type": "number", "description": "Absolute vol change, 0.05 is +5 points."},
                                "horizon": {"type": "number", "description": "Fraction of the front expiry's life, 0 to 1."},
                            },
                            "required": ["spot_pct"],
                        },
                        "max_premium": {"type": "number", "description": "Largest premium to pay. Negative means the structure must take in at least that much."},
                        "max_loss": {"type": "number", "description": "Worst ladder P&L allowed, as a positive number."},
                        "rank_by": {"type": "string", "enum": ["scenario_pnl", "payoff_ratio", "premium"]},
                        "top": {"type": "integer"},
                    },
                    "required": ["skeletons", "view"],
                },
            },
            {
                "name": "pnl_scenarios",
                "description": "P&L if spot moves ±10% or ±20%, and if vol moves ±10 points, plus the best and worst cell of that ladder.",
                "input_schema": {
                    "type": "object",
                    "properties": {"legs": {"type": "array", "items": LEG_SCHEMA}},
                },
            },
            {
                "name": "monte_carlo",
                "description": "Terminal P&L distribution for a single-expiry structure. Returns mean, percentiles, 95% VaR and expected shortfall, and the probability of profit.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "legs": {"type": "array", "items": LEG_SCHEMA},
                        "rho": {"type": "number", "description": "Spot-vol correlation, -1 to 1."},
                        "kappa": {"type": "number"},
                        "xi": {"type": "number", "description": "Vol of vol. 0 keeps vol flat."},
                        "n_paths": {"type": "integer"},
                    },
                },
            },
            {
                "name": "get_smile",
                "description": "Live fitted smile for one futures contract: forward, expiry and the delta pillars.",
                "input_schema": {
                    "type": "object",
                    "properties": {"contract": {"type": "string"}},
                },
            },
            {
                "name": "get_term_structure",
                "description": "ATM vol by expiry for the loaded product, today and a week ago.",
                "input_schema": {"type": "object", "properties": {}},
            },
            {
                "name": "vol_history_stats",
                "description": "Two years of history for one future: ATM percentile, realised vol, variance risk premium, spot-vol correlation and beta.",
                "input_schema": {
                    "type": "object",
                    "properties": {"contract": {"type": "string"}},
                },
            },
            {
                "name": "backtest_structure",
                "description": (
                    "Re-open the same relative structure (same days to expiry, same delta or % strikes) every `every` "
                    "sessions over the product's history on the generic contract and hold it to expiry. Returns hit rate, "
                    "mean, median, worst, total, Sharpe, max drawdown and profit factor in currency, after costs, plus the "
                    "mean P&L split into delta, gamma, theta (gamma + theta is the carry), vega, residual, hedge and costs, "
                    "and realised minus implied vol over the trades."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "legs": {"type": "array", "items": LEG_SCHEMA},
                        "every": {"type": "integer", "description": "Sessions between entries, default 21."},
                        "hedge": {"type": "boolean", "description": "Delta-hedge daily on the future with the smile-consistent delta."},
                        "hedge_cost_bps": {"type": "number", "description": "Half spread on each futures trade in bp of notional, default 0."},
                        "entry_cost_vol_pts": {"type": "number", "description": "Half spread paid on entry in vol points per unit vega, default 0."},
                        "years": {"type": "number"},
                    },
                },
            },
            {
                "name": "breakeven_vs_history",
                "description": "The structure's breakevens against how often the generic future moved that far over the same number of days, and realised vol over such windows against today's ATM.",
                "input_schema": {
                    "type": "object",
                    "properties": {"legs": {"type": "array", "items": LEG_SCHEMA}},
                },
            },
            {
                "name": "vol_seasonality",
                "description": "Average 30-day ATM implied and realised vol by calendar month over up to eight years, and today's level.",
                "input_schema": {"type": "object", "properties": {}},
            },
            {
                "name": "vol_roll_history",
                "description": (
                    "Calendar vol spread between listed months, M+front minus M+back, at a call delta (0.5 ATM, 0.75 the 25 delta put). "
                    "Returns today's spread and days to the front expiry, where it sits against past cycles at the same days to expiry, "
                    "the median path into expiry, and each past cycle's spread 30, 10 and 0 days out. ATM is real contract history; "
                    "other deltas add constant-maturity skew and are partly extrapolated (the sources field says how much)."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "front": {"type": "integer", "description": "1 for M+1."},
                        "back": {"type": "integer", "description": "2 for M+2."},
                        "call_delta": {"type": "number"},
                    },
                },
            },
            {
                "name": "skew_slope_history",
                "description": "Current 30-day ATM, skew (110% minus 90% moneyness vol) and slope (60d minus 30d ATM) with percentile and z-score over six years.",
                "input_schema": {"type": "object", "properties": {}},
            },
        ]

    def call(self, name: str, arguments: dict) -> str:
        try:
            handler = {
                "list_templates": self.list_templates,
                "expand_template": self.expand_template,
                "price_structure": self.price_structure,
                "search_structures": self.search_structures,
                "pnl_scenarios": self.pnl_scenarios,
                "monte_carlo": self.monte_carlo,
                "get_smile": self.get_smile,
                "get_term_structure": self.get_term_structure,
                "vol_history_stats": self.vol_history_stats,
                "backtest_structure": self.backtest_structure,
                "breakeven_vs_history": self.breakeven_vs_history,
                "vol_seasonality": self.vol_seasonality,
                "skew_slope_history": self.skew_slope_history,
                "vol_roll_history": self.vol_roll_history,
            }[name]
        except KeyError:
            return _dump({"error": f"{name} is not a copilot tool."})
        try:
            return _dump(handler(arguments or {}))
        except Exception as exc:
            return _dump({"error": str(exc)})

    def list_templates(self, _arguments: dict) -> dict:
        return {"templates": [{"name": name, "expresses": text} for name, text in TEMPLATES.items()]}

    def expand_template(self, arguments: dict) -> dict:
        expiries = sorted(sl.expiry for sl in self.market.slices)
        wanted = arguments.get("expiry")
        if wanted:
            expiries = [e for e in expiries if e.isoformat() >= str(wanted)] or expiries
        legs = expand_template(arguments["name"], expiries, {"qty": arguments.get("qty", 1.0)})
        return {"legs": legs}

    def price_structure(self, arguments: dict) -> dict:
        legs = _legs(arguments.get("legs"), self.legs)
        summary = summarise(self.market, legs, self.regime, self.regime == "beta", self.market.as_of)
        return _compact_price(summary)

    def search_structures(self, arguments: dict) -> dict:
        view = arguments.get("view") or {}
        spot_pct = float(view.get("spot_pct", 0.0))
        vol_pts = float(view.get("vol_pts", 0.0))
        horizon = float(np.clip(view.get("horizon", 0.0), 0.0, 1.0))
        max_premium = arguments.get("max_premium")
        max_loss = arguments.get("max_loss")
        rank_by = arguments.get("rank_by") or "payoff_ratio"
        top = int(np.clip(arguments.get("top") or 6, 1, 15))

        candidates = []
        for index, skeleton in enumerate(arguments.get("skeletons") or []):
            label = skeleton.get("label") or f"Skeleton {index + 1}"
            for legs in _expand_skeleton(skeleton.get("legs") or []):
                candidates.append((label, legs))
                if len(candidates) > MAX_COMBINATIONS:
                    return {"error": f"More than {MAX_COMBINATIONS} combinations. Narrow the strike or qty lists."}
        if not candidates:
            return {"error": "Give at least one skeleton with legs."}

        scored, rejected = [], 0
        for label, raw in candidates:
            try:
                legs = [LegIn.model_validate(leg) for leg in raw]
                outcome = scenario_outcome(self.market, legs, self.regime, spot_pct, vol_pts, horizon)
            except Exception as exc:
                rejected += 1
                last_error = str(exc)
                continue
            if max_premium is not None and outcome["premium"] > float(max_premium):
                continue
            if max_loss is not None and outcome["worst"] < -abs(float(max_loss)):
                continue
            scored.append({"label": label, "legs": raw, **outcome})

        key = {
            "scenario_pnl": lambda row: row["scenario_pnl"],
            "payoff_ratio": lambda row: row["payoff_ratio"] if row["payoff_ratio"] is not None else -1e18,
            "premium": lambda row: -row["premium"],
        }[rank_by]
        scored.sort(key=key, reverse=True)
        result = {
            "view": {"spot_pct": spot_pct, "vol_pts": vol_pts, "horizon": horizon},
            "priced": len(candidates) - rejected,
            "kept": len(scored),
            "best": [
                {**row, **{k: _num(row[k], 2) for k in ("premium", "scenario_pnl", "worst", "best")}, "payoff_ratio": _num(row["payoff_ratio"], 2)}
                for row in scored[:top]
            ],
        }
        if rejected:
            result["rejected"] = rejected
            result["last_error"] = last_error
        return result

    def pnl_scenarios(self, arguments: dict) -> dict:
        legs = _legs(arguments.get("legs"), self.legs)
        summary = summarise(self.market, legs, self.regime, self.regime == "beta", self.market.as_of)
        ladder = summary["ladder"]
        points = [
            {"spot_pct": row["spot_pct"], "vol_pts": row["vol_pts"], "pnl": _num(row["pnl"], 2)}
            for row in ladder
            if (row["vol_pts"] == 0 and row["spot_pct"] in (-0.2, -0.1, 0.0, 0.1, 0.2))
            or (row["spot_pct"] == 0 and row["vol_pts"] in (-0.10, 0.10))
        ]
        best = max(ladder, key=lambda row: row["pnl"])
        worst = min(ladder, key=lambda row: row["pnl"])
        return {
            "points": points,
            "best": {"spot_pct": best["spot_pct"], "vol_pts": best["vol_pts"], "pnl": _num(best["pnl"], 2)},
            "worst": {"spot_pct": worst["spot_pct"], "vol_pts": worst["vol_pts"], "pnl": _num(worst["pnl"], 2)},
        }

    def monte_carlo(self, arguments: dict) -> dict:
        legs = _legs(arguments.get("legs"), self.legs)
        result = simulate(
            self.market,
            legs,
            self.regime,
            self.market.as_of,
            int(arguments.get("n_paths") or 1500),
            24,
            float(arguments.get("kappa") or 1.0),
            float(arguments.get("xi") or 0.0),
            float(arguments.get("rho") or 0.0),
            None,
            7,
            0,
            False,
        )
        terminal = result["terminal"]
        return {
            "premium": _num(result["premium"], 2),
            "mean": _num(terminal["mean"], 2),
            "p5": _num(terminal["p5"], 2),
            "p50": _num(terminal["p50"], 2),
            "p95": _num(terminal["p95"], 2),
            "var_95": _num(terminal["var_95"], 2),
            "es_95": _num(terminal["es_95"], 2),
            "prob_profit": _num(terminal["prob_profit"], 3),
        }

    def get_smile(self, arguments: dict) -> dict:
        from app.market.discovery import smile

        contract = arguments.get("contract") or self.contract
        if not contract:
            return {"error": "No contract. Pass one, or load a market from Bloomberg."}
        raw = smile(contract, self.market.as_of)
        return {
            "contract": raw["contract"],
            "expiry": raw["expiry"],
            "forward": _num(raw["forward"], 4),
            "pillars": {k: _num(v, 4) for k, v in raw["pillars"].items()},
            "vol_source": raw["vol_source"],
            "fit": {k: _num(v, 4) for k, v in (raw.get("fit") or {}).items() if k in ("model", "alpha", "beta", "rho", "nu", "rmse_used", "rr25", "bf25")} | {"model": (raw.get("fit") or {}).get("model")},
            "parity": {k: _num(v, 4) for k, v in (raw.get("parity") or {}).items() if k in ("forward", "settle", "diff", "n_pairs")} | {"break": (raw.get("parity") or {}).get("break")} if raw.get("parity") else None,
            "largest_residuals": [
                {"strike": p["strike"], "cp": p["cp"], "vol": _num(p["vol"], 4), "resid": _num(p["resid"], 4)}
                for p in sorted((p for p in raw["points"] if p.get("resid") is not None), key=lambda p: -abs(p["resid"]))[:4]
            ],
            "warnings": raw["warnings"],
        }

    def get_term_structure(self, _arguments: dict) -> dict:
        from app.market.discovery import term_structure

        if not self.product:
            return {"error": "No product is loaded. Search for one in Find market first."}
        raw = term_structure(self.product)
        return {
            "product": raw["product"],
            "warning": raw.get("warning"),
            "contracts": [
                {
                    "label": row["label"],
                    "contract": row["contract"],
                    "days": row["days"],
                    "forward": _num(row["forward"], 4),
                    "atm": _num(row["atm"], 4),
                    "atm_1w": _num(row["atm_1w"], 4),
                }
                for row in raw["contracts"]
            ],
        }

    def vol_history_stats(self, arguments: dict) -> dict:
        from app.market.discovery import vol_history

        contract = arguments.get("contract") or self.contract
        if not contract:
            return {"error": "No contract. Pass one, or load a market from Bloomberg."}
        raw = vol_history(contract, 2.0)
        stats = {key: _num(value, 4) for key, value in raw["stats"].items()}
        cone = [
            {"window": row["window"], "p10": _num(row["p10"], 4), "p50": _num(row["p50"], 4), "p90": _num(row["p90"], 4), "current": _num(row["current"], 4)}
            for row in raw["cone"]
        ]
        return {"contract": raw["contract"], "warning": raw.get("warning"), "stats": stats, "cone": cone}

    def _history(self, years: float = 6.0):
        from app.market.generic import generic_history

        ticker = self.contract or self.product
        if not ticker:
            raise ValueError("No market is loaded from Bloomberg, so there is no history to use.")
        return generic_history(ticker, years)

    def backtest_structure(self, arguments: dict) -> dict:
        from app.quant.backtest import run_backtest

        legs = _legs(arguments.get("legs"), self.legs)
        hist = self._history(float(arguments.get("years") or 6.0))
        every = int(np.clip(arguments.get("every") or 21, 1, 126))
        result = run_backtest(
            self.market,
            legs,
            self.regime,
            hist,
            every,
            bool(arguments.get("hedge")),
            hedge_cost_bps=float(np.clip(arguments.get("hedge_cost_bps") or 0.0, 0.0, 100.0)),
            entry_cost_vol=float(np.clip(arguments.get("entry_cost_vol_pts") or 0.0, 0.0, 10.0)) / 100.0,
        )
        metrics = {k: (_num(v, 3) if not isinstance(v, dict) else {kk: _num(vv, 2) for kk, vv in v.items()}) for k, v in result["metrics"].items()}
        return {
            "settings": result["settings"],
            "metrics": metrics,
            "worst_trades": [
                {"entry": t["entry"], "move": _num(t["move"], 3), "total": _num(t["total"], 2)}
                for t in sorted(result["trades"], key=lambda t: t["total"])[:3]
            ],
            "assumptions": result["assumptions"],
        }

    def breakeven_vs_history(self, arguments: dict) -> dict:
        from app.quant.backtest import breakeven_analysis

        legs = _legs(arguments.get("legs"), self.legs)
        result = breakeven_analysis(self.market, legs, self.regime, self._history())
        realised = {k: _num(v, 4) for k, v in result["realised"].items() if k not in ("dates", "rv", "iv")}
        return {
            "tenor_days": result["tenor_days"],
            "forward": _num(result["forward"], 4),
            "premium": _num(result["premium"], 2),
            "atm": _num(result["atm"], 4),
            "breakevens": [{**b, "price": _num(b["price"], 3), "move": _num(b["move"], 4), "hist_prob_beyond": _num(b["hist_prob_beyond"], 3)} for b in result["breakevens"]],
            "move_p5": _num(result["moves"]["p5"], 4),
            "move_p95": _num(result["moves"]["p95"], 4),
            "realised": realised,
            "n_windows": result["n_windows"],
        }

    def vol_seasonality(self, _arguments: dict) -> dict:
        from app.quant.backtest import seasonality

        result = seasonality(self._history(8.0))
        return {
            "months": [{k: _num(v, 4) if isinstance(v, float) else v for k, v in row.items()} for row in result["months"]],
            "current": result["current"],
        }

    def vol_roll_history(self, arguments: dict) -> dict:
        from app.market.rolls import vol_rolls

        ticker = self.product or self.contract
        if not ticker:
            raise ValueError("No market is loaded from Bloomberg.")
        result = vol_rolls(ticker, int(arguments.get("front") or 1), int(arguments.get("back") or 2), float(arguments.get("call_delta") or 0.5))

        def at(points: list[dict], dte: int):
            near = [p for p in points if abs(p["dte"] - dte) <= 2]
            return _num(min(near, key=lambda p: abs(p["dte"] - dte))["spread"], 4) if near else None

        profile = result["profile"]
        return {
            "pair": f"M+{result['front']} minus M+{result['back']}",
            "call_delta": result["call_delta"],
            "stats": {k: (_num(v, 4) if isinstance(v, float) else v) for k, v in result["stats"].items() if k != "current"},
            "current": {k: (_num(v, 4) if isinstance(v, float) else v) for k, v in (result["stats"].get("current") or {}).items()},
            "median_path": {str(d): _num(m, 4) for d, m in zip(profile["dte"], profile["median"]) if d % 5 == 0},
            "cycles": [
                {"pair": c["label"], "expiry": c["expiry"], "dte30": at(c["points"], 30), "dte10": at(c["points"], 10), "dte0": at(c["points"], 0)}
                for c in result["cycles"]
            ],
            "sources": result["sources"],
            "notes": result["notes"],
        }

    def skew_slope_history(self, _arguments: dict) -> dict:
        from app.quant.backtest import skew_slope

        result = skew_slope(self._history())
        return {
            "stats": {name: {k: _num(v, 4) for k, v in stat.items()} for name, stat in result["stats"].items()},
            "as_of": result["dates"][-1] if result["dates"] else None,
        }


def _expand_skeleton(legs: list[dict]) -> list[list[dict]]:
    """Every combination of the strike and qty lists in a skeleton."""
    axes = []
    for leg in legs:
        strikes = leg["strike"] if isinstance(leg.get("strike"), list) else [leg.get("strike")]
        qtys = leg["qty"] if isinstance(leg.get("qty"), list) else [leg.get("qty", 1)]
        axes.append([(s, q) for s in strikes for q in qtys])
    out = []
    for combo in itertools.product(*axes):
        built = []
        for leg, (strike, qty) in zip(legs, combo):
            item = {k: v for k, v in leg.items() if k not in ("strike", "qty")}
            item.update({"strike": strike, "qty": qty, "strike_mode": leg.get("strike_mode", "delta")})
            built.append(item)
        out.append(built)
        if len(out) > MAX_COMBINATIONS:
            break
    return out


def scenario_outcome(market: MarketIn, legs: list[LegIn], regime: str, spot_pct: float, vol_pts: float, horizon: float) -> dict:
    """Premium, P&L in the view's scenario, and the best and worst of a spot x vol ladder at that horizon."""
    prepared = prepare_slices(market, market.as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    primary = min(leg["slice"].expiry for leg in resolved)
    T0 = by_exp[primary][1]
    skew = _skew_name(regime)
    use_beta = regime == "beta"
    forwards = {sl.expiry: sl.forward for sl, _, _ in prepared}
    atms = {sl.expiry: smile.atm for sl, _, smile in prepared}
    times = {sl.expiry: T for sl, T, _ in prepared}
    remaining = {exp: max(t - horizon * T0, 0.0) for exp, t in times.items()}

    def value(spot_move: float, vol_move: float, when: dict) -> float:
        fwd = {exp: f * (1.0 + spot_move) for exp, f in forwards.items()}
        vol = {exp: max(a + vol_move, 1e-3) for exp, a in atms.items()}
        priced = price_package(resolved, fwd, vol, when, market.rate, skew, use_beta, market.multiplier)
        return float(np.asarray(priced["price"]))

    premium = value(0.0, 0.0, times)
    scenario = value(spot_pct, vol_pts, remaining) - premium
    ladder = [
        value(s, v, remaining) - premium
        for s in (-0.3, -0.2, -0.1, 0.0, 0.1, 0.2, 0.3)
        for v in (-0.10, 0.0, 0.10)
    ]
    worst, best = min(ladder), max(ladder)
    risk = max(-worst, abs(premium), 1e-9)
    return {
        "premium": premium,
        "scenario_pnl": scenario,
        "worst": worst,
        "best": best,
        "payoff_ratio": scenario / risk if risk > 1e-9 else None,
    }


def _compact_price(summary: dict) -> dict:
    return {
        "premium": _num(summary["premium"], 2),
        "delta": _num(summary["delta"], 3),
        "gamma": _num(summary["gamma"], 4),
        "vega_point": _num(summary["vega_point"], 3),
        "theta_day": _num(summary["theta_day"], 3),
        "vanna": _num(summary["vanna"], 3),
        "volga": _num(summary["volga"], 2),
        "breakevens": [_num(b, 2) for b in summary["breakevens"]],
        "max_gain": _num(summary["max_gain"], 2),
        "max_loss": _num(summary["max_loss"], 2),
        "unlimited_gain": summary["unlimited_gain"],
        "unlimited_loss": summary["unlimited_loss"],
        "pop": _num(summary["pop"], 3),
        "legs": [
            {
                "call_put": leg["call_put"],
                "qty": leg["qty"],
                "strike": _num(leg["strike"], 4),
                "expiry": leg["expiry"],
                "vol": _num(leg["vol"], 4),
                "premium": _num(leg["premium"], 2),
                "delta": _num(leg["delta"], 3),
            }
            for leg in summary["legs"]
        ],
    }


def verify_proposals(market: MarketIn, regime: str, proposals: list[dict]) -> list[dict]:
    """Re-price every proposed structure. The UI shows these numbers, not the model's."""
    checked = []
    for proposal in proposals:
        card = {
            "label": str(proposal.get("label") or "Structure"),
            "rationale": str(proposal.get("rationale") or ""),
            "legs": proposal.get("legs") or [],
        }
        try:
            legs = _legs(card["legs"], [])
            priced = _compact_price(summarise(market, legs, regime, regime == "beta", market.as_of))
            priced["resolved_legs"] = priced.pop("legs")
            card.update(priced)
            card["legs"] = [leg.model_dump(mode="json") for leg in legs]
        except Exception as exc:
            card["error"] = str(exc)
        checked.append(card)
    return checked


def market_brief(market: MarketIn, legs: list[LegIn], product: str | None, contract: str | None) -> str:
    slices = [
        {"expiry": sl.expiry.isoformat(), "forward": sl.forward, "pillars": sl.pillars}
        for sl in market.slices
    ]
    loaded = [leg.model_dump(mode="json") for leg in legs]
    return json.dumps({
        "as_of": market.as_of.isoformat(),
        "currency": market.currency,
        "unit": market.unit,
        "multiplier": market.multiplier,
        "beta": market.beta,
        "product": product,
        "front_contract": contract,
        "slices": slices,
        "loaded_legs": loaded,
    }, default=str)
