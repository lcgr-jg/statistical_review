"""Claude copilot. Tools are the app's own pricing functions, called in-process.

The model may only quote numbers a tool returned. Any structure it proposes is
re-priced here before it reaches the screen.
"""
from __future__ import annotations

import json
import re

from app.copilot.tools import ToolContext, market_brief, verify_proposals
from app.schemas import LegIn, MarketIn, ResolverMessage
from app.settings import settings

MODES = ("structure", "critique", "chat")

_SHARED = """You are the structuring copilot for a commodity options desk. The loaded market, in JSON, follows this instruction.

Rules:
- Quote a premium, greek, probability, correlation or vol only when a tool result in this conversation returned it. If you have not priced it, say so and call the tool.
- Strikes in delta mode are call deltas: 0.25 is the 25-delta call, 0.75 is the 25-delta put, 0.50 is at the money.
- Expiries must be taken from the loaded market. Do not invent a contract.
- Prefer delta strikes over absolute strikes so the structure survives a move in the forward.
- If a "Screen" section follows, it holds numbers the app computed for what the user is looking at (a path, a Monte Carlo run, regime stats, a backtest, the vol screener, the fitted surface with its SABR parameters and checks, parsed broker quotes). You may quote those as well.
- vol_roll_history works on listed contracts (M+1, M+2, ...). Spreads are front vol minus back vol; quote them in vol points.
- History tools (backtest_structure, breakeven_vs_history, vol_seasonality, skew_slope_history) run on the product's generic 1st/2nd contracts. Say so when you quote them, and mention the backtest's assumptions when they matter.

Format (the reply is rendered as markdown in a narrow side panel):
- Open with a one or two sentence verdict in bold. No preamble, and do not narrate which tools you are about to call.
- Then short `###` sections with bullets. Use a small table for scenario grids. Keep it under about 250 words unless asked for more.
- Put units on numbers (EUR, vol pts, per day) and round sensibly.

When you recommend structures, end with one fenced json block and no other JSON:

```json
{"proposals": [{"label": "short name", "rationale": "why it fits the view, citing tool results", "legs": [{"call_put": "C", "qty": 1, "strike_mode": "delta", "strike": 0.5, "expiry": "YYYY-MM-DD"}]}]}
```
"""

PROMPTS = {
    "structure": _SHARED + """
The user is describing a view. Design structures for it yourself. Templates are a starting point, not a menu: you may use any mix of calls and puts, any quantities and ratios, delta or absolute strikes, and more than one expiry.

Work like a structurer:
1. Turn the view into a scenario: direction and size of the move (spot_pct), what vol does (vol_pts), and when (horizon as a fraction of the front expiry). State the scenario you chose. Ask only if the view gives no direction at all.
2. Call search_structures with several different skeletons. At least one should be your own design, not a template. Give lists of strikes and ratios so the search explores the space, and use max_premium or max_loss if the user named a budget or a risk limit.
3. Refine: run a second, narrower search around the winners, or try a different shape if nothing fits.
4. price_structure the finalists, and run monte_carlo or pnl_scenarios when the view is about a tail or a path.
5. Return the two or three best as proposals, best first. In each rationale, say how it expresses the view and what would make it lose.
""",
    "critique": _SHARED + """
The user wants the loaded structure reviewed. Price it, run pnl_scenarios, and run monte_carlo. When a Bloomberg market is loaded, also run breakeven_vs_history and backtest_structure, and say how often history reached the breakevens and how the structure did when rolled. Cover premium paid or received, theta, what happens on a 10% and 20% move, and the 95% shortfall. Then price one or two alternatives and return those as proposals. If the loaded structure is the one you would keep, say so and return an empty proposals list.
""",
    "chat": _SHARED + """
Answer the question with the tools. Return a proposals block only when you are actually recommending a structure the user could load.
""",
}


def proposals_from_text(text: str) -> list[dict]:
    """Pull the last fenced JSON object that contains proposals."""
    blocks = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.DOTALL)
    candidates = blocks or re.findall(r"(\{.*\})", text, flags=re.DOTALL)
    for raw in reversed(candidates):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict) and isinstance(parsed.get("proposals"), list):
            return [item for item in parsed["proposals"] if isinstance(item, dict)]
    return []


def _replay_blocks(content) -> list[dict]:
    """Assistant blocks in the shape the API accepts back. SDK-only fields such as parsed_output are rejected."""
    blocks = []
    for block in content:
        kind = getattr(block, "type", None)
        if kind == "text":
            if block.text:
                blocks.append({"type": "text", "text": block.text})
        elif kind == "tool_use":
            blocks.append({"type": "tool_use", "id": block.id, "name": block.name, "input": block.input or {}})
        else:
            dumped = block.model_dump(exclude_none=True)
            dumped.pop("parsed_output", None)
            blocks.append(dumped)
    return blocks


async def stream_chat(
    messages: list[ResolverMessage],
    market: MarketIn,
    legs: list[LegIn],
    mode: str,
    regime: str,
    product: str | None,
    contract: str | None,
    page: str | None = None,
    screen: dict | None = None,
):
    if not settings.anthropic_api_key:
        yield {"type": "error", "data": {"message": "ANTHROPIC_API_KEY is not set. Add it to backend/.env and restart."}}
        return
    try:
        import anthropic
    except ImportError as exc:
        yield {"type": "error", "data": {"message": f"The anthropic package is not installed ({exc})."}}
        return
    if mode not in MODES:
        yield {"type": "error", "data": {"message": f"Unknown mode {mode}."}}
        return

    context = ToolContext(market, legs, regime, product, contract)
    system = PROMPTS[mode] + "\nLoaded market:\n" + market_brief(market, legs, product, contract)
    if page:
        system += f"\n\nThe user is on the {page} page."
    if screen:
        system += "\n\nScreen:\n" + json.dumps(screen, default=str)[:8000]
    client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
    convo = [{"role": message.role, "content": message.content} for message in messages]

    collected = ""
    for round_index in range(14):
        if round_index and collected.strip():
            yield {"type": "text", "data": {"delta": "\n\n"}}
        collected = ""
        async with client.messages.stream(
            model=settings.anthropic_model,
            max_tokens=4096,
            system=system,
            tools=context.definitions(),
            messages=convo,
        ) as stream:
            async for delta in stream.text_stream:
                collected += delta
                yield {"type": "text", "data": {"delta": delta}}
            final = await stream.get_final_message()

        convo.append({"role": "assistant", "content": _replay_blocks(final.content)})
        tool_uses = [block for block in final.content if getattr(block, "type", None) == "tool_use"]
        if not tool_uses:
            proposals = verify_proposals(market, regime, proposals_from_text(collected))
            yield {"type": "done", "data": {"proposals": proposals}}
            return

        results = []
        for block in tool_uses:
            payload = context.call(block.name, dict(block.input or {}))[:12000]
            yield {"type": "tool", "data": {"name": block.name, "arguments": block.input, "preview": payload[:1500]}}
            results.append({"type": "tool_result", "tool_use_id": block.id, "content": payload})
        convo.append({"role": "user", "content": results})

    proposals = verify_proposals(market, regime, proposals_from_text(collected))
    yield {
        "type": "done",
        "data": {"proposals": proposals, "message": "Stopped after 14 tool rounds."},
    }
