"""Parse broker option runs into priced structures.

Claude only extracts what the text says (legs, contract months, bid/offer, size). Every number
shown afterwards comes from this app: each quoted month is looked up on the product's chain, priced
on that contract's live smile, and the quote's implied ATM is solved from its price.
"""
from __future__ import annotations

import re

import numpy as np
from scipy.optimize import brentq

from app.market import discovery
from app.quant.structures import _skew_name, prepare_slices, price_package, resolve_legs, summarise
from app.schemas import ExpirySliceIn, LegIn, MarketIn
from app.settings import settings

MONTHS = {m: code for m, code in zip(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], "FGHJKMNQUVXZ"
)}

PROMPT = """Extract every option quote from a commodity options broker run or chat. Call record_quotes once.

Conventions:
- Each quote is a package. Legs are signed from the buyer's side as quoted: a call spread "85/95 cs" is +1 C 85 and -1 C 95; a put spread "70/60 ps" is +1 P 70, -1 P 60; a straddle is +1 C K and +1 P K; a strangle "70/90" is +1 P 70, +1 C 90; "1x2" ratios set qty 1 and -2.
- A risk reversal or fence is ambiguous about direction: record it as +1 call, -1 put and say so in notes.
- contract is the futures month as a month code and the last digit of the year (Z6 = Dec 2026, H7 = Mar 2027). Convert names like Dec26 or Dec-26.
- bid and offer are the package prices per unit as written. Leave either empty if absent. "1.20/1.35" is bid 1.20, offer 1.35; "1.20 bid" is bid only; "@1.35" or "offered 1.35" is offer only.
- size in lots if given; future_ref is the futures reference ("vs 80.50", "ref 80.5"); delta if given ("d25", "25 delta").
- Do not invent strikes, months or prices. If something is unreadable, put it in notes.
"""

TOOL = {
    "name": "record_quotes",
    "description": "Record the option quotes found in the text.",
    "input_schema": {
        "type": "object",
        "properties": {
            "quotes": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "label": {"type": "string", "description": "Short name as a trader would say it, e.g. 'Z6 85/95 cs'."},
                        "legs": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "call_put": {"type": "string", "enum": ["C", "P"]},
                                    "qty": {"type": "number"},
                                    "strike": {"type": "number"},
                                    "contract": {"type": "string"},
                                },
                                "required": ["call_put", "qty", "strike", "contract"],
                            },
                        },
                        "bid": {"type": "number"},
                        "offer": {"type": "number"},
                        "size": {"type": "number"},
                        "future_ref": {"type": "number"},
                        "delta": {"type": "number"},
                        "notes": {"type": "string"},
                    },
                    "required": ["label", "legs"],
                },
            }
        },
        "required": ["quotes"],
    },
}


def month_code(text: str) -> str | None:
    """'Z6', 'z26', 'Dec26', 'Dec-26', 'DEC 2026' -> 'Z6'."""
    raw = text.strip().replace("-", "").replace(" ", "")
    match = re.fullmatch(r"([FGHJKMNQUVXZ])(\d{1,4})", raw, flags=re.IGNORECASE)
    if match:
        return match.group(1).upper() + match.group(2)[-1]
    match = re.fullmatch(r"([A-Za-z]{3})(\d{1,4})", raw)
    if match and match.group(1).lower() in MONTHS:
        return MONTHS[match.group(1).lower()] + match.group(2)[-1]
    return None


def resolve_contract(code: str, chain: list[str]) -> str | None:
    for ticker in chain:
        head = ticker.split()[0]
        if re.fullmatch(rf".+{code[0]}{code[1]}", head):
            return ticker
    return None


async def extract(text: str) -> list[dict]:
    import anthropic

    client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
    message = await client.messages.create(
        model=settings.anthropic_model,
        max_tokens=4096,
        system=PROMPT,
        tools=[TOOL],
        tool_choice={"type": "tool", "name": "record_quotes"},
        messages=[{"role": "user", "content": text}],
    )
    for block in message.content:
        if getattr(block, "type", None) == "tool_use" and block.name == "record_quotes":
            return list((block.input or {}).get("quotes") or [])
    return []


def price_quotes(quotes: list[dict], product: str, regime: str, rate: float = 0.0, fallback_multiplier: float = 1.0) -> list[dict]:
    chain = [row["contract"] for row in discovery.expiries(product, 24)["contracts"]]
    smiles: dict[str, dict] = {}
    out = []
    for quote in quotes:
        card = {**quote, "legs_in": quote.get("legs") or []}
        try:
            legs, contracts = [], []
            for leg in card["legs_in"]:
                code = month_code(str(leg.get("contract", "")))
                if not code:
                    raise ValueError(f"Cannot read the month '{leg.get('contract')}'.")
                contract = resolve_contract(code, chain)
                if not contract:
                    raise ValueError(f"{code} is not on the {product} option chain.")
                if contract not in smiles:
                    smiles[contract] = discovery.smile(contract)
                contracts.append(contract)
                legs.append((leg, contract))
            if not legs:
                raise ValueError("No legs in this quote.")
            unique = list(dict.fromkeys(contracts))
            screen_forward = smiles[unique[0]]["forward"]
            ref = quote.get("future_ref")
            scale = float(ref) / screen_forward if ref and screen_forward and 0.5 < float(ref) / screen_forward < 2.0 else 1.0
            slices = [
                ExpirySliceIn(expiry=smiles[c]["expiry"], forward=smiles[c]["forward"] * scale, pillars=smiles[c]["pillars"])
                for c in unique
            ]
            multiplier = smiles[unique[0]].get("multiplier") or fallback_multiplier
            market = MarketIn(as_of=smiles[unique[0]]["as_of"], rate=rate, multiplier=1.0, slices=slices)
            leg_models = [
                LegIn(call_put=leg["call_put"], qty=float(leg["qty"]), strike_mode="absolute", strike=float(leg["strike"]), expiry=smiles[c]["expiry"])
                for leg, c in legs
            ]
            summary = summarise(market, leg_models, regime, regime == "beta", market.as_of)
            model = float(summary["premium"])
            bid, offer = quote.get("bid"), quote.get("offer")
            mid = (bid + offer) / 2 if bid is not None and offer is not None else (bid if bid is not None else offer)
            card.update({
                "contracts": unique,
                "labels": [smiles[c]["label"] for c in unique],
                "multiplier": multiplier,
                "model_price": model,
                "model_delta": float(summary["delta"]),
                "model_vega_point": float(summary["vega_point"]),
                "screen_atm": smiles[unique[0]]["pillars"].get("50D"),
                "forward": screen_forward,
                "priced_forward": screen_forward * scale,
                "priced_at_ref": scale != 1.0,
                "mid": mid,
                "bid_edge": None if bid is None else bid - model,
                "offer_edge": None if offer is None else offer - model,
                "implied_atm_shift": implied_shift(market, leg_models, regime, mid) if mid is not None else None,
                "legs": [
                    {"call_put": l.call_put, "qty": l.qty, "strike_mode": "absolute", "strike": l.strike, "expiry": l.expiry.isoformat()}
                    for l in leg_models
                ],
            })
        except Exception as exc:
            card["error"] = str(exc)
        out.append(card)
    return out


def implied_shift(market: MarketIn, legs: list[LegIn], regime: str, target: float) -> float | None:
    """Parallel ATM shift (vol points as a decimal) that makes the model price equal the quote."""
    prepared = prepare_slices(market, market.as_of)
    by_exp, resolved = resolve_legs(prepared, legs)
    forwards = {exp: sl.forward for exp, (sl, _, _) in by_exp.items()}
    atms = {exp: smile.atm for exp, (_, _, smile) in by_exp.items()}
    times = {exp: T for exp, (_, T, _) in by_exp.items()}
    skew = _skew_name(regime)

    def gap(shift: float) -> float:
        atm = {exp: max(a + shift, 0.01) for exp, a in atms.items()}
        out = price_package(resolved, forwards, atm, times, market.rate, skew, regime == "beta", 1.0)
        return float(np.asarray(out["price"])) - target

    lo, hi = -0.6, 1.5
    try:
        if gap(lo) * gap(hi) > 0:
            return None
        return float(brentq(gap, lo, hi, xtol=1e-5))
    except Exception:
        return None
