"""Price and ATM-vol alerts, checked on B-PIPE every few minutes by a background task.

An alert fires once, records when and at what value, and stays fired until it is reset.
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
import uuid
from datetime import datetime, timezone

from app.settings import CACHE_DIR

PATH = CACHE_DIR / "alerts.json"
CHECK_SECONDS = 300
FIELDS = {"price": ["PX_LAST"], "atm_vol": ["HIST_CALL_IMP_VOL", "HIST_PUT_IMP_VOL"]}
_lock = threading.Lock()
_last_check = 0.0
log = logging.getLogger("alerts")


def _read() -> list[dict]:
    if not PATH.exists():
        return []
    try:
        return json.loads(PATH.read_text())
    except json.JSONDecodeError:
        return []


def _write(alerts: list[dict]) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(alerts, indent=1))
    tmp.replace(PATH)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def list_alerts() -> list[dict]:
    with _lock:
        return _read()


def add_alert(ticker: str, field: str, op: str, level: float, note: str = "") -> dict:
    if field not in FIELDS:
        raise ValueError(f"Unknown alert field {field}.")
    if op not in ("above", "below"):
        raise ValueError("op must be above or below.")
    alert = {
        "id": uuid.uuid4().hex[:10],
        "ticker": ticker.strip(),
        "field": field,
        "op": op,
        "level": float(level),
        "note": note,
        "created": _now(),
        "triggered_at": None,
        "triggered_value": None,
        "last_value": None,
        "last_checked": None,
    }
    with _lock:
        alerts = _read()
        alerts.append(alert)
        _write(alerts)
    return alert


def delete_alert(alert_id: str) -> bool:
    with _lock:
        alerts = _read()
        kept = [a for a in alerts if a["id"] != alert_id]
        _write(kept)
        return len(kept) != len(alerts)


def reset_alert(alert_id: str) -> dict | None:
    with _lock:
        alerts = _read()
        for alert in alerts:
            if alert["id"] == alert_id:
                alert["triggered_at"] = None
                alert["triggered_value"] = None
                _write(alerts)
                return alert
    return None


def _value(field: str, row: dict) -> float | None:
    from app.market.bbg import as_float

    if field == "price":
        return as_float(row.get("PX_LAST"))
    vols = [as_float(row.get(f)) for f in FIELDS["atm_vol"]]
    vols = [v for v in vols if v is not None and v > 0]
    return sum(vols) / len(vols) / 100.0 if vols else None


def check_now() -> list[dict]:
    """Evaluate every alert against live B-PIPE values. Returns the alerts that fired on this check."""
    global _last_check
    from app.market.discovery import _refdata

    with _lock:
        alerts = _read()
    if not alerts:
        _last_check = time.time()
        return []
    tickers = sorted({a["ticker"] for a in alerts})
    fields = sorted({f for a in alerts for f in FIELDS[a["field"]]})
    data = _refdata(tickers, fields)
    fired = []
    stamp = _now()
    with _lock:
        alerts = _read()
        for alert in alerts:
            value = _value(alert["field"], data.get(alert["ticker"], {}))
            alert["last_value"] = value
            alert["last_checked"] = stamp
            if value is None or alert["triggered_at"]:
                continue
            hit = value >= alert["level"] if alert["op"] == "above" else value <= alert["level"]
            if hit:
                alert["triggered_at"] = stamp
                alert["triggered_value"] = value
                fired.append(alert)
        _write(alerts)
    _last_check = time.time()
    return fired


def maybe_check(min_age: float = 60.0) -> None:
    if time.time() - _last_check >= min_age:
        try:
            check_now()
        except Exception as exc:
            log.warning("Alert check failed: %s", exc)


async def run_forever() -> None:
    while True:
        try:
            await asyncio.to_thread(check_now)
        except Exception as exc:
            log.warning("Alert check failed: %s", exc)
        await asyncio.sleep(CHECK_SECONDS)
