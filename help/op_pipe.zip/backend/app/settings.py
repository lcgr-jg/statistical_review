from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_ROOT = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    anthropic_api_key: str | None = None
    anthropic_model: str = "claude-sonnet-5-5"
    bbg_mcp_server_path: str = (
        r"C:\Users\michael.kane\OneDrive - Jain Global\Projects\jain-mcp-servers\bbg-mcp-server\server.py"
    )
    bbg_mcp_python: str | None = None
    default_rate: float = 0.0
    bbg_ttl_seconds: float = 30.0
    # How long a request waits for the shared B-PIPE session before giving up with "Bloomberg is busy".
    bbg_lock_wait_seconds: float = 45.0
    bbg_reference_timeout_seconds: float = 60.0
    bbg_history_timeout_seconds: float = 120.0
    # Consecutive timeouts after which the session is torn down and reopened on the next call.
    bbg_reset_after_timeouts: int = 2
    history_refresh_hours: float = 6.0
    frontend_dist: str | None = None

    model_config = SettingsConfigDict(
        env_file=str(BACKEND_ROOT / ".env"),
        extra="ignore",
    )


settings = Settings()
CONFIG_PATH = BACKEND_ROOT / "config" / "underlyings.yaml"
CACHE_DIR = BACKEND_ROOT / "cache"
FRONTEND_DIST = Path(settings.frontend_dist) if settings.frontend_dist else BACKEND_ROOT.parent / "frontend" / "dist"
