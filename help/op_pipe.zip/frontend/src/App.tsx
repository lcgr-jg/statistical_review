import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "./components/shell/AppShell";
import { Backtest } from "./pages/Backtest";
import { Builder } from "./pages/Builder";
import { Deck } from "./pages/Deck";
import { Journal } from "./pages/Journal";
import { Rolls } from "./pages/Rolls";
import { Screener } from "./pages/Screener";
import { MonteCarlo } from "./pages/MonteCarlo";
import { PathLab } from "./pages/PathLab";
import { Regimes } from "./pages/Regimes";
import { Risk } from "./pages/Risk";
import { Surface } from "./pages/Surface";
import { Vol } from "./pages/Vol";

export function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<Builder />} />
        <Route path="path" element={<PathLab />} />
        <Route path="surface" element={<Surface />} />
        <Route path="vol" element={<Vol />} />
        <Route path="montecarlo" element={<MonteCarlo />} />
        <Route path="regimes" element={<Regimes />} />
        <Route path="backtest" element={<Backtest />} />
        <Route path="screener" element={<Screener />} />
        <Route path="rolls" element={<Rolls />} />
        <Route path="journal" element={<Journal />} />
        <Route path="risk" element={<Risk />} />
        <Route path="deck" element={<Deck />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
