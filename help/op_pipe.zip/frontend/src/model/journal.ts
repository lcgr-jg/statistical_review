import { getJson, sendJson } from "./api";
import { fetchSmile, sliceFromSmile } from "./chain";
import type { JournalEntry, JournalEvent, SavedStructure, VarPositionIn } from "./history";
import { uid } from "./id";
import { toLegs, toMarketIn, type Leg, type Market, type PriceResult } from "./types";

export const journalQuery = { queryKey: ["journal"], queryFn: () => getJson<{ entries: JournalEntry[] }>("/api/journal") };
export const auditQuery = { queryKey: ["journal-audit"], queryFn: () => getJson<{ events: JournalEvent[] }>("/api/journal/audit") };

export const addEntry = (entry: Partial<JournalEntry>, user: string) => sendJson<JournalEntry>("POST", "/api/journal", entry, user);
export const patchEntry = (id: string, patch: Partial<JournalEntry>, user: string) => sendJson<JournalEntry>("PATCH", `/api/journal/${id}`, patch, user);
export const commentOn = (id: string, text: string, user: string) => sendJson<JournalEntry>("POST", `/api/journal/${id}/comments`, { text }, user);
export const deleteEntry = (id: string, user: string) => sendJson<{ ok: boolean }>("DELETE", `/api/journal/${id}`, undefined, user);

/** Freeze the Builder's structure with resolved strikes so it can be re-priced on any later day. */
export function saveStructure(market: Market, legs: Leg[], priced: PriceResult): SavedStructure | null {
  const source = market.source;
  if (!source) return null;
  return {
    product: source.product,
    contracts: source.contracts,
    series: source.series ?? source.contracts.map(() => null),
    labels: source.labels,
    volSource: source.volSource,
    multiplier: market.multiplier,
    legs: legs.map((leg, i) => ({
      call_put: leg.callPut,
      qty: leg.qty,
      strike: priced.legs[i]?.strike ?? leg.strike,
      expiry: priced.legs[i]?.expiry ?? leg.expiry ?? market.slices[0].expiry,
      ...(leg.strip ? { strip: leg.strip.label } : {}),
    })),
  };
}

/** Contracts, legs and lot multiplier of an entry, whether it was saved from the Builder or a parsed quote. */
function holding(entry: JournalEntry): { contracts: string[]; series: (string | null)[]; legs: SavedStructure["legs"]; product: string; volSource?: SavedStructure["volSource"] } | null {
  if (entry.structure) return entry.structure;
  const quote = entry.quote;
  if (quote?.contracts?.length && quote.legs?.length && !quote.error) {
    return { contracts: quote.contracts, series: quote.contracts.map(() => null), legs: quote.legs, product: entry.product ?? "" };
  }
  return null;
}

export const inBook = (entry: JournalEntry) => entry.kind === "trade" && entry.status === "open" && !!holding(entry);

/** Today's market for an entry at the current smiles, with each leg's contract size (months differ by their hours). */
export async function marketFor(entry: JournalEntry): Promise<{ market: Market; legs: Leg[]; lotSizes: number[] }> {
  const held = holding(entry);
  if (!held) throw new Error(`${entry.label} has no legs on named contracts.`);
  const smiles = await Promise.all(held.contracts.map((c, i) => fetchSmile(c, held.series[i], held.volSource ?? "settle")));
  const byExpiry = new Map<string, number>();
  smiles.forEach((s, i) => byExpiry.set(s.expiry, i));
  const missing = held.legs.find((leg) => !byExpiry.has(leg.expiry));
  if (missing) throw new Error(`${entry.label}: a leg expiring ${missing.expiry} is no longer listed (expired or rolled).`);
  const market: Market = {
    asOf: smiles[0].as_of,
    rate: 0,
    multiplier: smiles[0].multiplier ?? 1,
    currency: smiles[0].currency ?? "EUR",
    unit: smiles[0].unit ?? "",
    beta: null,
    slices: smiles.map((s) => sliceFromSmile(s)),
    source: { product: held.product, contracts: held.contracts, labels: smiles.map((s) => s.label), series: held.series, volSource: held.volSource },
  };
  const legs: Leg[] = held.legs.map((leg) => ({ id: uid(), callPut: leg.call_put, qty: leg.qty, strikeMode: "absolute", strike: leg.strike, expiry: leg.expiry, vol: null }));
  const lotSizes = held.legs.map((leg) => smiles[byExpiry.get(leg.expiry)!].multiplier ?? 1);
  return { market, legs, lotSizes };
}

export async function positionFor(entry: JournalEntry): Promise<VarPositionIn> {
  const { market, legs, lotSizes } = await marketFor(entry);
  return {
    id: entry.id,
    label: entry.label,
    market: toMarketIn({ ...market, multiplier: 1 }),
    legs: toLegs(legs.map((leg, i) => ({ ...leg, qty: leg.qty * lotSizes[i] }))),
    contract: market.source!.contracts[0],
    size: entry.size ?? 1,
  };
}

export function describeEvent(event: JournalEvent): string {
  const show = (v: unknown) => (v == null || v === "" ? "—" : Array.isArray(v) ? v.join(" ") || "—" : String(v));
  if (event.action === "changed") return `${event.field}: ${show(event.before)} → ${show(event.after)}`;
  if (event.action === "created") return "created";
  if (event.action === "commented") return "commented";
  return "deleted";
}
