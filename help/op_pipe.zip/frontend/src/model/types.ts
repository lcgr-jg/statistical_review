export type Pillar = "10DC" | "25DC" | "50D" | "25DP" | "10DP";
export const PILLARS: Pillar[] = ["10DC", "25DC", "50D", "25DP", "10DP"];

export type Regime = "sticky-delta" | "sticky-strike" | "beta";
export type StrikeMode = "absolute" | "delta" | "pct_atm";
export type HedgeFreq = "none" | "daily" | "weekly";
export type VolSource = "path" | "beta";

export type Slice = {
  expiry: string;
  forward: number;
  pillars: Partial<Record<Pillar, number>>;
};

export type Market = {
  asOf: string;
  rate: number;
  multiplier: number;
  currency: string;
  unit: string;
  beta: number | null;
  slices: Slice[];
  source?: MarketSource;
};

export type MarketSource = {
  product: string;
  description?: string;
  contracts: string[];
  labels: string[];
  series?: (string | null)[];
  volSource?: SmileSource;
};

export type SmileSource = "settle" | "mid";

export type SearchHit = {
  ticker: string;
  description: string;
  kind: "options" | "futures" | "unknown";
  active: boolean;
};

export type ExpiryRow = {
  contract: string;
  series?: string;
  main?: boolean;
  label: string;
  name: string | null;
  option_expiry: string | null;
  future_expiry: string | null;
  forward: number | null;
  n_options: number;
  currency: string | null;
  unit: string | null;
  multiplier: number | null;
};

export type ExpiryList = {
  product: string;
  contracts: ExpiryRow[];
  warning: string | null;
};

export type SmilePoint = {
  ticker: string;
  cp: "C" | "P";
  strike: number;
  vol: number;
  call_delta: number;
  used?: boolean;
  resid?: number | null;
  price?: number;
};

export type SmileFit = {
  model: "sabr" | "poly";
  alpha?: number;
  beta?: number;
  rho?: number;
  nu?: number;
  degree?: number;
  atm: number;
  rmse: number;
  rmse_used?: number;
  n: number;
  rr25: number | null;
  bf25: number | null;
  density: { vertical: number[]; butterfly: number[]; min_density: number | null; ok: boolean };
};

export type SmileParity = {
  forward: number;
  settle: number;
  diff: number;
  diff_pct: number;
  n_pairs: number;
  spread: number;
  tolerance: number;
  break: boolean;
  strikes: { strike: number; forward: number }[];
};

export type ChainSmile = {
  contract: string;
  series?: string;
  main?: boolean;
  label: string;
  name: string | null;
  as_of: string;
  expiry: string;
  forward: number;
  future_last: number;
  currency: string | null;
  unit: string | null;
  multiplier: number | null;
  pillars: Record<Pillar, number | null>;
  points: SmilePoint[];
  curve: { strike: number; vol: number; call_delta: number; extrapolated?: boolean }[];
  vol_source: "settle" | "mid" | "last";
  settle?: { date: string; forward: number } | null;
  fit?: SmileFit | null;
  parity?: SmileParity | null;
  arbitrage?: { vertical: number[]; butterfly: number[]; n: number; ok: boolean } | null;
  tick?: number | null;
  warnings: string[];
};

export type Leg = {
  id: string;
  callPut: "C" | "P";
  qty: number;
  strikeMode: StrikeMode;
  strike: number;
  expiry: string | null;
  vol: number | null;
  /** Legs of one strip share an id and are edited together: one month each, one strike. */
  strip?: { id: string; label: string };
};

export type ControlPoint = {
  id: string;
  spot: number;
  vol: number;
  t: number;
  tUser: boolean;
  free?: boolean;
};

export type GhostPath = { spot: number; vol: number }[];

export type Underlying = {
  id: string;
  name: string;
  currency: string;
  unit: string;
  multiplier: number;
  rate: number;
  futures_root: string;
  futures_ticker_template: string;
  vol_pillars: Record<string, string>;
  configured_pillars: string[];
  notes: string;
};

export type ContractSnap = {
  ticker: string;
  month: string;
  year: number;
  forward: number;
  expiry: string;
  pillars: Record<string, { ticker: string | null; vol: number | null }>;
};

export type Snapshot = {
  id: string;
  name?: string;
  ok: boolean;
  error?: string;
  currency?: string;
  unit?: string;
  multiplier?: number;
  rate?: number;
  as_of?: string;
  contracts: ContractSnap[];
  warnings: string[];
};

export type PriceLeg = {
  call_put: string;
  qty: number;
  strike: number;
  expiry: string;
  vol: number;
  premium: number;
  delta: number;
  vega: number;
};

export type PriceResult = {
  premium: number;
  delta: number;
  forward_delta: number;
  gamma: number;
  vega: number;
  vega_point: number;
  theta_day: number;
  vanna: number;
  volga: number;
  charm_day: number;
  breakevens: number[];
  max_gain: number | null;
  max_loss: number | null;
  unlimited_gain: boolean;
  unlimited_loss: boolean;
  pop: number | null;
  single_expiry: boolean;
  legs: PriceLeg[];
  spot_profile: { spots: number[]; value: number[]; delta: number[]; gamma: number[]; vega: number[] };
  payoff: { spots: number[]; pnl: number[] } | null;
  frames: { life_fraction: number; spots: number[]; value: number[] }[];
  ladder: { spot_pct: number; vol_pts: number; pnl: number; delta: number }[];
};

export type GridResult = {
  spots: number[];
  vols: number[];
  premium: number;
  frames: { life_fraction: number; pnl: number[][] }[];
};

export type PathRow = {
  t: number;
  forward: number;
  atm_vol: number;
  value: number;
  step_pnl: number;
  pnl: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  delta_pnl: number;
  gamma_pnl: number;
  theta_pnl: number;
  vega_pnl: number;
  vanna_pnl: number;
  volga_pnl: number;
  residual_pnl: number;
  hedge_pnl: number;
};

export type PathResult = {
  T: number;
  pnl: number;
  hedged_pnl: number;
  attribution: Record<string, number>;
  rows: PathRow[];
};

export type McResult = {
  times: number[];
  spot: Record<string, number[]>;
  vol: Record<string, number[]>;
  pnl: Record<string, number[]>;
  terminal: {
    mean: number;
    std: number;
    var_95: number;
    es_95: number;
    p5: number;
    p50: number;
    p95: number;
    prob_profit: number;
    hist_counts: number[];
    hist_edges: number[];
  };
  premium: number;
  discounted_payoff_mean: number;
  black_price: number;
  overlays: { times: number[]; forward: number[][]; vol: number[][] };
  params: { kappa: number; xi: number; rho: number; sigma_bar: number; hedge: boolean };
};

export type HistPoint = {
  date: string;
  futures: number;
  atm: number;
  rr: number | null;
  pillars: Record<string, number | null>;
};

export type Fit = { n: number; intercept: number | null; slope: number | null; r2: number | null };

export type HistResult = {
  points: HistPoint[];
  window: number;
  vol_series: string;
  stats: {
    levels: Fit;
    changes: Fit;
    rolling_slope: (number | null)[];
    rolling_r2: (number | null)[];
    realised_vol: (number | null)[];
    vol_risk_premium: (number | null)[];
    rr_changes: Fit | null;
    rho: number | null;
    ou: { kappa: number | null; xi: number | null };
    beta: number | null;
  };
};

export type AnalogPath = {
  year: number;
  futures_ticker: string;
  vol_ticker: string | null;
  points: {
    date: string;
    sessions: number;
    futures_pct: number;
    vol_pts: number | null;
    futures: number;
    atm: number | null;
  }[];
};

export function marketReady(market: Market | null): market is Market {
  if (!market || market.slices.length === 0) return false;
  return market.slices.every((s) => s.forward > 0 && (s.pillars["50D"] ?? 0) > 0 && !!s.expiry);
}

export function yearFraction(asOf: string, expiry: string): number {
  const ms = Date.parse(expiry) - Date.parse(asOf);
  return Math.max(ms / 86400000 / 365.25, 0);
}

export function toMarketIn(market: Market) {
  return {
    as_of: market.asOf,
    rate: market.rate,
    multiplier: market.multiplier,
    currency: market.currency,
    unit: market.unit,
    beta: market.beta,
    slices: market.slices.map((s) => ({
      expiry: s.expiry,
      forward: s.forward,
      pillars: s.pillars,
    })),
  };
}

/**
 * Move legs onto expiries that exist in `to`. A leg keeps its position in the curve
 * (front stays front) when its old slice is known, otherwise it takes the nearest date.
 */
export function alignLegs(legs: Leg[], from: Slice[] | null, to: Slice[]): Leg[] {
  if (!to.length) return legs;
  const valid = new Set(to.map((s) => s.expiry));
  const oldRank = from ? [...from].sort((a, b) => a.expiry.localeCompare(b.expiry)).map((s) => s.expiry) : [];
  const target = [...to].sort((a, b) => a.expiry.localeCompare(b.expiry)).map((s) => s.expiry);
  let changed = false;
  const next = legs.map((leg) => {
    if (!leg.expiry || valid.has(leg.expiry)) return leg;
    changed = true;
    // A moved month no longer belongs to its period, so the leg stops being part of the strip.
    const rank = oldRank.indexOf(leg.expiry);
    if (rank >= 0) return { ...leg, expiry: target[Math.min(rank, target.length - 1)], strip: undefined };
    const when = Date.parse(leg.expiry);
    const nearest = target.reduce((best, e) => (Math.abs(Date.parse(e) - when) < Math.abs(Date.parse(best) - when) ? e : best));
    return { ...leg, expiry: nearest, strip: undefined };
  });
  return changed ? next : legs;
}

export function toLegs(legs: Leg[]) {
  return legs.map((leg) => ({
    call_put: leg.callPut,
    qty: leg.qty,
    strike_mode: leg.strikeMode,
    strike: leg.strike,
    expiry: leg.expiry,
    vol: leg.vol,
  }));
}
