import type { Leg, Market, Regime, SmileSource } from "./types";
import { toLegs, toMarketIn } from "./types";

export type BacktestTrade = {
  entry: string;
  exit: string;
  forward_entry: number;
  forward_exit: number;
  move: number;
  atm_entry: number;
  realised: number | null;
  premium: number;
  value_exit: number;
  pnl: number;
  delta_pnl: number;
  gamma_pnl: number;
  theta_pnl: number;
  vega_pnl: number;
  residual_pnl: number;
  carry_pnl: number;
  hedge_pnl: number | null;
  hedge_cost: number | null;
  entry_cost: number;
  gross: number;
  total: number;
};

export type BacktestAttribution = {
  delta: number | null;
  gamma: number | null;
  theta: number | null;
  carry: number | null;
  vega: number | null;
  residual: number | null;
  hedge: number | null;
  hedge_cost: number | null;
  entry_cost: number | null;
};

export type BacktestResult = {
  trades: BacktestTrade[];
  equity: { dates: string[]; pnl: number[]; drawdown: number[] };
  histogram: { counts: number[]; edges: number[] };
  metrics: {
    n: number;
    hit_rate: number;
    mean: number;
    median: number;
    std: number;
    best: number;
    worst: number;
    total: number;
    gross_total: number;
    avg_premium: number;
    profit_factor: number | null;
    sharpe: number | null;
    max_drawdown: number;
    trades_per_year: number;
    attribution: BacktestAttribution;
    mean_realised_minus_implied: number | null;
    share_realised_above_implied: number | null;
  };
  settings: {
    every: number;
    hedge: boolean;
    hedge_delta: "smile" | "black" | null;
    hedge_cost_bps: number | null;
    hedge_band: number | null;
    entry_cost_vol: number;
    front_days: number;
    hold: "front" | "last";
    hold_days: number;
    tenors: number[];
    from: string;
    to: string;
  };
  regimes: RegimeRow[];
  assumptions: string[];
};

export type RegimeWindow = { id: string; label: string; start: string; end: string; note: string };

export type RegimeRow = RegimeWindow & {
  n: number;
  hit_rate: number | null;
  mean: number | null;
  total: number | null;
  worst: number | null;
  best: number | null;
  realised_minus_implied: number | null;
};

export type VarPositionIn = {
  id: string;
  label: string;
  market: ReturnType<typeof toMarketIn>;
  legs: ReturnType<typeof toLegs>;
  contract: string;
  size: number;
};

export type VarBody = { positions: VarPositionIn[]; regime: Regime; years: number; horizon: number };

export type VarPosition = {
  id: string;
  label: string;
  contract: string;
  value: number;
  delta: number;
  gamma: number;
  vega_point: number;
  theta_day: number;
  var_95: number;
  es_contribution_95: number;
};

export type VarResult = {
  horizon: number;
  n_scenarios: number;
  from: string;
  to: string;
  levels: Record<"95" | "99", { var: number; es: number }>;
  mean: number;
  std: number;
  positions: VarPosition[];
  totals: { value: number; delta: number; gamma: number; vega_point: number; theta_day: number };
  worst: { date: string; pnl: number; positions: Record<string, number> }[];
  stresses: { id: string; label: string; n: number; worst: number | null; worst_date: string | null; mean: number | null; var_95: number | null }[];
  histogram: { counts: number[]; edges: number[] };
  series: { dates: string[]; pnl: number[] };
  assumptions: string[];
};

export type BreakevenResult = {
  tenor_days: number;
  forward: number;
  premium: number;
  atm: number | null;
  breakevens: { price: number; move: number; direction: "up" | "down"; hist_prob_beyond: number }[];
  moves: { counts: number[]; edges: number[]; p5: number; p95: number; std: number };
  realised: {
    dates: string[];
    rv: (number | null)[];
    iv: (number | null)[];
    median: number | null;
    p25: number | null;
    p75: number | null;
    share_above_atm: number | null;
    mean_iv_minus_rv: number | null;
  };
  n_windows: number;
};

export type SeasonalityResult = {
  years: Record<string, (number | null)[]>;
  months: { month: number; iv_mean: number | null; iv_min: number | null; iv_max: number | null; rv_mean: number | null; years: number }[];
  current: { date: string; iv: number; month: number } | null;
};

export type SeriesStat = { current: number | null; percentile: number | null; mean: number | null; z: number | null; p10?: number | null; p90?: number | null };

export type SkewSlopeResult = {
  dates: string[];
  series: { atm: (number | null)[]; skew: (number | null)[]; slope: (number | null)[] };
  stats: { atm: SeriesStat; skew: SeriesStat; slope: SeriesStat };
};

export type ScreenerRow = {
  contract: string;
  label: string;
  option_expiry: string | null;
  days: number | null;
  forward: number | null;
  atm: number | null;
  atm_1w: number | null;
  atm_1m: number | null;
  chg_1d: number | null;
  chg_1w: number | null;
  chg_1m: number | null;
  rv20: number | null;
  iv_minus_rv: number | null;
  atm_pct_1y: number | null;
  pillar_change: Record<string, number | null> | null;
  pillar_change_since: string | null;
};

export type ScreenerResult = { product: string; rows: ScreenerRow[]; warning: string | null; computed_at?: string };

export type QuoteLeg = { call_put: "C" | "P"; qty: number; strike_mode: "absolute"; strike: number; expiry: string };

export type ParsedQuote = {
  label: string;
  legs: QuoteLeg[];
  legs_in: { call_put: "C" | "P"; qty: number; strike: number; contract: string }[];
  bid?: number | null;
  offer?: number | null;
  size?: number | null;
  future_ref?: number | null;
  delta?: number | null;
  notes?: string | null;
  error?: string;
  contracts?: string[];
  labels?: string[];
  multiplier?: number;
  model_price?: number;
  model_delta?: number;
  model_vega_point?: number;
  screen_atm?: number | null;
  forward?: number;
  priced_forward?: number;
  priced_at_ref?: boolean;
  mid?: number | null;
  bid_edge?: number | null;
  offer_edge?: number | null;
  implied_atm_shift?: number | null;
};

export type JournalEntry = {
  id: string;
  created: string;
  kind: "quote" | "trade" | "idea";
  status: string;
  label: string;
  tags: string[];
  notes?: string;
  side?: string;
  price?: number | null;
  size?: number | null;
  counterparty?: string;
  quote?: ParsedQuote;
  structure?: SavedStructure;
  product?: string;
  author?: string;
  updated?: string;
  deleted?: boolean;
  comments: JournalComment[];
  history: JournalEvent[];
};

/** A structure saved from the Builder: absolute legs on named contracts, so it can be re-priced later. */
export type SavedStructure = {
  product: string;
  contracts: string[];
  series: (string | null)[];
  labels: string[];
  volSource?: SmileSource;
  multiplier: number;
  legs: { call_put: "C" | "P"; qty: number; strike: number; expiry: string; strip?: string }[];
};

export type JournalComment = { id: string; at: string; author: string; text: string };

export type JournalEvent = {
  at: string;
  author: string;
  action: "created" | "changed" | "commented" | "deleted";
  field?: string;
  before?: unknown;
  after?: unknown;
  entry?: string;
  label?: string;
  kind?: string;
};

export type Alert = {
  id: string;
  ticker: string;
  field: "price" | "atm_vol";
  op: "above" | "below";
  level: number;
  note: string;
  created: string;
  triggered_at: string | null;
  triggered_value: number | null;
  last_value: number | null;
  last_checked: string | null;
};

export type RollSource = "atm" | "snapshot" | "skew" | "extrapolated";

export type RollPoint = { date: string; dte: number; front_vol: number; back_vol: number; spread: number; source: RollSource };

export type RollCycle = { front: string; back: string; label: string; expiry: string; complete: boolean; points: RollPoint[] };

export type RollResult = {
  root: string;
  front: number;
  back: number;
  call_delta: number;
  lookback: number;
  series: {
    dates: string[];
    front: string[];
    back: string[];
    front_vol: number[];
    back_vol: number[];
    spread: number[];
    dte: number[];
    source: RollSource[];
  };
  cycles: RollCycle[];
  profile: { dte: number[]; median: number[]; p25: number[]; p75: number[]; n: number[] };
  stats: {
    current: { date: string; dte: number; spread: number; front_vol: number; back_vol: number; pair: string } | null;
    cycles_at_same_dte?: number;
    percentile_at_same_dte?: number | null;
    median_at_same_dte?: number | null;
    median_change_to_expiry?: number | null;
    share_rising_to_expiry?: number | null;
    cycles_to_expiry?: number;
  };
  sources: Partial<Record<RollSource, number>>;
  history_from: string;
  notes: string[];
};

export function structureBody(market: Market, legs: Leg[], regime: Regime) {
  return {
    market: toMarketIn(market),
    legs: toLegs(legs),
    regime,
    contract: market.source?.contracts[0] ?? market.source?.product ?? "",
  };
}

export const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
