import { fetchSmile, sliceFromSmile } from "./chain";
import { uid } from "./id";
import type { ExpiryRow, Leg, Market, SmileSource } from "./types";

/**
 * Energy periods priced as strips of monthly options: one option per delivery month, all at the
 * same strike, each on its own month's forward and smile. Quarters, gas seasons (winter Oct–Mar,
 * summer Apr–Sep) and calendar years.
 */
export type Period = { id: string; label: string; kind: "Quarter" | "Season" | "Calendar"; rows: ExpiryRow[] };

const MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
const CODES = "FGHJKMNQUVXZ";

/** Delivery month of a listed contract: from its label ("Jan27"), else its ticker's month code. */
export function deliveryMonth(row: ExpiryRow): { year: number; month: number } | null {
  const label = row.label.match(/^([A-Za-z]{3})(\d{2})$/);
  if (label) {
    const month = MONTHS.indexOf(label[1].toLowerCase());
    if (month >= 0) return { year: 2000 + Number(label[2]), month: month + 1 };
  }
  const code = row.contract.split(" ")[0].match(/([FGHJKMNQUVXZ])(\d{1,2})$/);
  const expiry = row.future_expiry ?? row.option_expiry;
  if (!code || !expiry) return null;
  const digits = code[2];
  const base = Number(expiry.slice(0, 4)) - 1;
  const span = 10 ** digits.length;
  let year = base - (base % span) + Number(digits);
  if (year < base) year += span;
  return { year, month: CODES.indexOf(code[1]) + 1 };
}

const yy = (year: number) => String(year % 100).padStart(2, "0");

export function periods(rows: ExpiryRow[], today = new Date().toISOString().slice(0, 10)): Period[] {
  const byMonth = new Map<string, ExpiryRow>();
  for (const row of rows) {
    if (row.main === false || !row.option_expiry || row.option_expiry <= today) continue;
    const when = deliveryMonth(row);
    if (!when) continue;
    const key = `${when.year}-${when.month}`;
    if (!byMonth.has(key)) byMonth.set(key, row);
  }
  const years = [...new Set([...byMonth.keys()].map((k) => Number(k.split("-")[0])))].sort();
  const out: Period[] = [];
  const add = (id: string, label: string, kind: Period["kind"], months: [number, number][]) => {
    const picked = months.map(([y, m]) => byMonth.get(`${y}-${m}`));
    if (picked.every((row): row is ExpiryRow => !!row)) out.push({ id, label, kind, rows: picked });
  };
  const span = (year: number, from: number, n: number): [number, number][] =>
    Array.from({ length: n }, (_, i) => {
      const m = from - 1 + i;
      return [year + Math.floor(m / 12), (m % 12) + 1];
    });
  for (const year of years) {
    for (let q = 1; q <= 4; q++) add(`Q${q}-${yy(year)}`, `Q${q}-${yy(year)}`, "Quarter", span(year, 3 * q - 2, 3));
    add(`Sum-${yy(year)}`, `Sum-${yy(year)}`, "Season", span(year, 4, 6));
    add(`Win-${yy(year)}`, `Win-${yy(year)}`, "Season", span(year, 10, 6));
    add(`Cal-${yy(year)}`, `Cal-${yy(year)}`, "Calendar", span(year, 1, 12));
  }
  return out.sort((a, b) => (a.rows[0].option_expiry ?? "").localeCompare(b.rows[0].option_expiry ?? "") || a.rows.length - b.rows.length);
}

/** Add any month of the period the market lacks. Returns the market and each month's option expiry. */
export async function withPeriod(market: Market, period: Period, volSource: SmileSource = "settle"): Promise<{ market: Market; expiries: string[] }> {
  const source = market.source;
  if (!source) throw new Error("A strip needs a market loaded from Bloomberg.");
  const series = source.series ?? source.contracts.map(() => null);
  const have = (row: ExpiryRow) => source.contracts.findIndex((c, i) => c === row.contract && (series[i] ?? null) === (row.series ?? null));
  const missing = period.rows.filter((row) => have(row) < 0);
  const smiles = await Promise.all(missing.map((row) => fetchSmile(row.contract, row.series, volSource)));
  const empty = smiles.find((s) => !(s.pillars["50D"] && s.forward > 0 && s.expiry));
  if (empty) throw new Error(`${empty.label} has no usable smile yet, so the ${period.label} strip cannot be priced.`);
  const next: Market = {
    ...market,
    slices: [...market.slices, ...smiles.map((s) => sliceFromSmile(s))],
    source: {
      ...source,
      contracts: [...source.contracts, ...smiles.map((s) => s.contract)],
      labels: [...source.labels, ...smiles.map((s) => s.label)],
      series: [...series, ...smiles.map((s) => s.series ?? null)],
    },
  };
  const expiries = period.rows.map((row) => {
    const i = have(row);
    return i >= 0 ? market.slices[i].expiry : smiles[missing.indexOf(row)].expiry;
  });
  return { market: next, expiries };
}

/** Equal-weighted average of the months' forwards: the strip's ATM. */
export function stripForward(market: Market, expiries: string[]): number | null {
  const forwards = expiries.map((e) => market.slices.find((s) => s.expiry === e)?.forward).filter((f): f is number => !!f);
  return forwards.length === expiries.length && forwards.length ? forwards.reduce((a, b) => a + b, 0) / forwards.length : null;
}

export function stripLegs(label: string, expiries: string[], callPut: "C" | "P", qty: number, strike: number): Leg[] {
  const strip = { id: uid(), label };
  return expiries.map((expiry) => ({ id: uid(), callPut, qty, strikeMode: "absolute", strike, expiry, vol: null, strip }));
}

/** Legs in display order: a strip collapses to its first leg, followed by its other months. */
export function groupLegs(legs: Leg[]): { key: string; legs: Leg[] }[] {
  const groups: { key: string; legs: Leg[] }[] = [];
  const index = new Map<string, number>();
  for (const leg of legs) {
    const key = leg.strip?.id ?? leg.id;
    if (index.has(key)) groups[index.get(key)!].legs.push(leg);
    else {
      index.set(key, groups.length);
      groups.push({ key, legs: [leg] });
    }
  }
  return groups;
}
