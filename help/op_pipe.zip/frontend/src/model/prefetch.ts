import { useQueryClient, type QueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useLab } from "../store/lab";
import {
  BACKTEST_DEFAULTS,
  ROLL_DEFAULTS,
  SURFACE_LIMIT,
  VOL_YEARS,
  backtestQuery,
  breakevenQuery,
  contractSmileQuery,
  rollsQuery,
  screenerQuery,
  seasonalityQuery,
  skewSlopeQuery,
  surfaceHistoryQuery,
  surfaceQuery,
  volHistoryQuery,
  volTermQuery,
} from "./queries";
import { marketReady, type Leg, type Market, type Regime } from "./types";

const SKEW_CONTRACTS = 8;
const SETTLE_MS = 800;

type Step = { label: string; run: (client: QueryClient) => Promise<unknown> };
export type WarmState = { done: number; total: number; label: string } | null;

function marketSteps(market: Market): Step[] {
  const source = market.source;
  if (!source?.product) return [];
  const product = source.product;
  const contract = source.contracts[0];
  const smileSource = source.volSource ?? "settle";
  const steps: Step[] = [
    { label: "IV vs RV", run: (c) => c.prefetchQuery(volTermQuery(product)) },
    { label: "Screener", run: (c) => c.prefetchQuery(screenerQuery(product)) },
    { label: "Rolls", run: (c) => c.prefetchQuery(rollsQuery(product, ROLL_DEFAULTS.front, ROLL_DEFAULTS.back, ROLL_DEFAULTS.delta, ROLL_DEFAULTS.lookback)) },
  ];
  if (contract) {
    steps.push(
      { label: "IV vs RV", run: (c) => c.prefetchQuery(volHistoryQuery(contract, VOL_YEARS)) },
      { label: "Screener", run: (c) => c.prefetchQuery(skewSlopeQuery(contract)) },
      { label: "Screener", run: (c) => c.prefetchQuery(seasonalityQuery(contract)) },
    );
  }
  steps.push(
    { label: "Surface", run: (c) => c.prefetchQuery(surfaceQuery(product, smileSource, SURFACE_LIMIT)) },
    {
      label: "Surface",
      run: (c) => {
        const surface = c.getQueryData<{ rows: { contract: string; error: string | null }[] }>(surfaceQuery(product, smileSource, SURFACE_LIMIT).queryKey);
        const fitted = (surface?.rows ?? []).filter((r) => !r.error).map((r) => r.contract);
        return fitted.length ? c.prefetchQuery(surfaceHistoryQuery(fitted)) : Promise.resolve();
      },
    },
    {
      label: "IV vs RV",
      run: async (c) => {
        const term = c.getQueryData<{ contracts: { contract: string }[] }>(volTermQuery(product).queryKey);
        for (const row of (term?.contracts ?? []).slice(0, SKEW_CONTRACTS)) await c.prefetchQuery(contractSmileQuery(row.contract));
      },
    },
  );
  return steps;
}

function structureSteps(market: Market, legs: Leg[], regime: Regime): Step[] {
  if (!marketReady(market) || !market.source || legs.length === 0) return [];
  return [
    { label: "Backtest", run: (c) => c.prefetchQuery(backtestQuery(market, legs, regime)) },
    { label: "Backtest", run: (c) => c.prefetchQuery(breakevenQuery(market, legs, regime, BACKTEST_DEFAULTS.years)) },
  ];
}

/**
 * Warms every Bloomberg-backed tab for the loaded market and structure, one request at a time.
 * The API holds a single lock on the B-PIPE session, so running these in parallel would only queue
 * them on the server and push the page the user is looking at to the back of that queue.
 */
export function usePrefetchTabs(): WarmState {
  const client = useQueryClient();
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const regime = useLab((s) => s.regime);
  const [state, setState] = useState<WarmState>(null);

  useEffect(() => {
    if (!market) {
      setState(null);
      return;
    }
    const steps = [...marketSteps(market), ...structureSteps(market, legs, regime)];
    if (!steps.length) return;
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      for (let i = 0; i < steps.length; i++) {
        if (cancelled) return;
        setState({ done: i, total: steps.length, label: steps[i].label });
        try {
          await steps[i].run(client);
        } catch {
          /* a tab that fails here shows its own error when opened */
        }
      }
      if (!cancelled) setState(null);
    }, SETTLE_MS);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [client, market, legs, regime]);

  return state;
}
