import { getJson } from "./api";
import { PILLARS, type ChainSmile, type Market, type Pillar, type Slice, type SmileSource } from "./types";

export function fetchSmile(contract: string, series?: string | null, source: SmileSource = "settle") {
  const query = (series ? `&series=${encodeURIComponent(series)}` : "") + `&source=${source}`;
  return getJson<ChainSmile>(`/api/discover/smile?contract=${encodeURIComponent(contract)}${query}`);
}

export function sliceFromSmile(smile: ChainSmile, override?: Partial<Record<Pillar, number | null>>): Slice {
  const pillars: Partial<Record<Pillar, number>> = {};
  for (const name of PILLARS) {
    const value = override && name in override ? override[name] : smile.pillars[name];
    if (value != null && Number.isFinite(value) && value > 0) pillars[name] = value;
  }
  return { expiry: smile.expiry, forward: smile.forward, pillars };
}

export async function refreshMarket(market: Market): Promise<Market> {
  if (!market.source?.contracts.length) return market;
  const series = market.source.series ?? [];
  const smiles = await Promise.all(market.source.contracts.map((contract, i) => fetchSmile(contract, series[i], market.source?.volSource)));
  return {
    ...market,
    asOf: smiles[0].as_of,
    slices: smiles.map((smile) => sliceFromSmile(smile)),
  };
}

export function riskReversal(pillars: Partial<Record<Pillar, number | null>>) {
  const call = pillars["25DC"];
  const put = pillars["25DP"];
  return call != null && put != null ? call - put : null;
}

export function butterfly(pillars: Partial<Record<Pillar, number | null>>) {
  const call = pillars["25DC"];
  const put = pillars["25DP"];
  const atm = pillars["50D"];
  return call != null && put != null && atm != null ? (call + put) / 2 - atm : null;
}
