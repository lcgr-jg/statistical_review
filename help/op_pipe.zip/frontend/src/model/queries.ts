import { queryOptions } from "@tanstack/react-query";
import { getJson, postJson } from "./api";
import { fetchSmile } from "./chain";
import {
  structureBody,
  type BacktestResult,
  type BreakevenResult,
  type RollResult,
  type ScreenerResult,
  type SeasonalityResult,
  type SkewSlopeResult,
  type VarBody,
  type VarResult,
} from "./history";
import type { ExpiryList, Leg, Market, Regime, SmileSource } from "./types";

/**
 * Query definitions shared by the pages and the background prefetcher. A page and the prefetcher must
 * build the same key for the same request, otherwise the prefetched result is never read.
 */

const MIN = 60_000;

export const SURFACE_LIMIT = 12;
export const VOL_YEARS = 2;
export const ROLL_DEFAULTS = { front: 1, back: 2, delta: 0.5, lookback: 60 };
export const BACKTEST_DEFAULTS = {
  years: 6,
  every: 21,
  hedge: false,
  hedgeDelta: "smile" as "smile" | "black",
  hedgeCostBps: 0,
  hedgeBand: 0,
  entryCostPts: 0,
  hold: undefined as Hold | undefined,
};
export type BacktestSettings = typeof BACKTEST_DEFAULTS;
export type Hold = "front" | "last";

/** A strip is only settled once its last month expires, so hold it that long unless told otherwise. */
export const defaultHold = (legs: Leg[]): Hold => (legs.some((leg) => leg.strip) ? "last" : "front");

export const volTermQuery = <T>(product: string) =>
  queryOptions({
    queryKey: ["vol-term", product],
    queryFn: () => getJson<T>(`/api/vol/term?product=${encodeURIComponent(product)}`),
    staleTime: MIN,
  });

export const volHistoryQuery = <T>(contract: string, years: number) =>
  queryOptions({
    queryKey: ["vol-history", contract, years],
    queryFn: () => getJson<T>(`/api/vol/history?contract=${encodeURIComponent(contract)}&years=${years}`),
    staleTime: 5 * MIN,
  });

export const expiryListQuery = (product: string) =>
  queryOptions({
    queryKey: ["discover-expiries", product],
    queryFn: () => getJson<ExpiryList>(`/api/discover/expiries?product=${encodeURIComponent(product)}&serials=true`),
    staleTime: 10 * MIN,
  });

export const contractSmileQuery = (contract: string) =>
  queryOptions({
    queryKey: ["discover-smile", contract],
    queryFn: () => fetchSmile(contract),
    staleTime: MIN,
  });

// ``refresh`` only changes the request, not the key, so a forced rebuild lands in the entry the page is showing.
// The server keeps these for a few minutes; without it a Refresh click would get the server's copy back.
const force = (refresh: boolean) => (refresh ? "&refresh=true" : "");

export const screenerQuery = (product: string, refresh = false) =>
  queryOptions({
    queryKey: ["screener", product],
    queryFn: () => getJson<ScreenerResult>(`/api/vol/screener?product=${encodeURIComponent(product)}&limit=12${force(refresh)}`),
    staleTime: refresh ? 0 : 5 * MIN,
  });

export const skewSlopeQuery = (contract: string) =>
  queryOptions({
    queryKey: ["skew-slope", contract],
    queryFn: () => getJson<SkewSlopeResult>(`/api/vol/skew-slope?contract=${encodeURIComponent(contract)}`),
    staleTime: 30 * MIN,
  });

export const seasonalityQuery = (contract: string) =>
  queryOptions({
    queryKey: ["seasonality", contract],
    queryFn: () => getJson<SeasonalityResult>(`/api/vol/seasonality?contract=${encodeURIComponent(contract)}`),
    staleTime: 30 * MIN,
  });

export const rollsQuery = (ticker: string, front: number, back: number, callDelta: number, lookback: number) =>
  queryOptions({
    queryKey: ["rolls", ticker, front, back, callDelta, lookback],
    queryFn: () =>
      getJson<RollResult>(
        `/api/vol/rolls?ticker=${encodeURIComponent(ticker)}&front=${front}&back=${back}&delta=${callDelta}&lookback=${lookback}`,
      ),
    staleTime: 30 * MIN,
  });

export const surfaceQuery = <T>(product: string, source: SmileSource, limit: number, refresh = false) =>
  queryOptions({
    queryKey: ["vol-surface", product, source, limit],
    queryFn: () => getJson<T>(`/api/vol/surface?product=${encodeURIComponent(product)}&source=${source}&limit=${limit}${force(refresh)}`),
    staleTime: refresh ? 0 : 5 * MIN,
  });

export const surfaceHistoryQuery = <T>(contracts: string[]) =>
  queryOptions({
    queryKey: ["vol-surface-history", contracts.join(",")],
    queryFn: () => getJson<T>(`/api/vol/surface/history?contracts=${encodeURIComponent(contracts.join(","))}&ranks=4`),
    staleTime: 5 * MIN,
  });

export const backtestQuery = (market: Market, legs: Leg[], regime: Regime, s: BacktestSettings = BACKTEST_DEFAULTS) => {
  const hold = s.hold ?? defaultHold(legs);
  return queryOptions({
    queryKey: ["backtest", market, legs, regime, s.years, s.every, s.hedge, s.hedgeDelta, s.hedgeCostBps, s.hedgeBand, s.entryCostPts, hold],
    queryFn: () =>
      postJson<BacktestResult>("/api/backtest", {
        ...structureBody(market, legs, regime),
        years: s.years,
        every: s.every,
        hedge: s.hedge,
        hedge_delta: s.hedgeDelta,
        hedge_cost_bps: s.hedgeCostBps,
        hedge_band: s.hedgeBand,
        entry_cost_vol: s.entryCostPts / 100,
        hold,
      }),
    staleTime: 10 * MIN,
  });
};

export const varQuery = (body: VarBody | null) =>
  queryOptions({
    queryKey: ["risk-var", body],
    queryFn: () => postJson<VarResult>("/api/risk/var", body),
    enabled: !!body && body.positions.length > 0,
    staleTime: 5 * MIN,
  });

export const breakevenQuery = (market: Market, legs: Leg[], regime: Regime, years: number) =>
  queryOptions({
    queryKey: ["breakeven", market, legs, regime, years],
    queryFn: () => postJson<BreakevenResult>("/api/breakeven", { ...structureBody(market, legs, regime), years }),
    staleTime: 10 * MIN,
  });
