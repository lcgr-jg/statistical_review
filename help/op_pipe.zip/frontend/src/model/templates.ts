import { uid } from "./id";
import type { Leg } from "./types";

type Spec = { callPut: "C" | "P"; qty: number; delta: number; which: 0 | 1 };

const BOOK: Record<string, Spec[]> = {
  call: [{ callPut: "C", qty: 1, delta: 0.5, which: 0 }],
  put: [{ callPut: "P", qty: 1, delta: 0.5, which: 0 }],
  call_spread: [
    { callPut: "C", qty: 1, delta: 0.5, which: 0 },
    { callPut: "C", qty: -1, delta: 0.25, which: 0 },
  ],
  put_spread: [
    { callPut: "P", qty: 1, delta: 0.5, which: 0 },
    { callPut: "P", qty: -1, delta: 0.75, which: 0 },
  ],
  straddle: [
    { callPut: "C", qty: 1, delta: 0.5, which: 0 },
    { callPut: "P", qty: 1, delta: 0.5, which: 0 },
  ],
  strangle: [
    { callPut: "P", qty: 1, delta: 0.75, which: 0 },
    { callPut: "C", qty: 1, delta: 0.25, which: 0 },
  ],
  risk_reversal: [
    { callPut: "C", qty: 1, delta: 0.25, which: 0 },
    { callPut: "P", qty: -1, delta: 0.75, which: 0 },
  ],
  call_fly: [
    { callPut: "C", qty: 1, delta: 0.25, which: 0 },
    { callPut: "C", qty: -2, delta: 0.5, which: 0 },
    { callPut: "C", qty: 1, delta: 0.75, which: 0 },
  ],
  put_fly: [
    { callPut: "P", qty: 1, delta: 0.75, which: 0 },
    { callPut: "P", qty: -2, delta: 0.5, which: 0 },
    { callPut: "P", qty: 1, delta: 0.25, which: 0 },
  ],
  condor: [
    { callPut: "C", qty: 1, delta: 0.2, which: 0 },
    { callPut: "C", qty: -1, delta: 0.4, which: 0 },
    { callPut: "C", qty: -1, delta: 0.6, which: 0 },
    { callPut: "C", qty: 1, delta: 0.8, which: 0 },
  ],
  seagull: [
    { callPut: "P", qty: 1, delta: 0.5, which: 0 },
    { callPut: "P", qty: -1, delta: 0.75, which: 0 },
    { callPut: "C", qty: -1, delta: 0.25, which: 0 },
  ],
  collar: [
    { callPut: "P", qty: 1, delta: 0.75, which: 0 },
    { callPut: "C", qty: -1, delta: 0.25, which: 0 },
  ],
  call_ratio: [
    { callPut: "C", qty: 1, delta: 0.5, which: 0 },
    { callPut: "C", qty: -2, delta: 0.25, which: 0 },
  ],
  calendar: [
    { callPut: "C", qty: -1, delta: 0.5, which: 0 },
    { callPut: "C", qty: 1, delta: 0.5, which: 1 },
  ],
  diagonal: [
    { callPut: "C", qty: -1, delta: 0.5, which: 0 },
    { callPut: "C", qty: 1, delta: 0.25, which: 1 },
  ],
};

export const TEMPLATE_LABELS: { id: string; label: string; needsBack: boolean }[] = [
  { id: "call", label: "Call", needsBack: false },
  { id: "put", label: "Put", needsBack: false },
  { id: "call_spread", label: "Call spread", needsBack: false },
  { id: "put_spread", label: "Put spread", needsBack: false },
  { id: "straddle", label: "Straddle", needsBack: false },
  { id: "strangle", label: "Strangle", needsBack: false },
  { id: "risk_reversal", label: "Risk reversal", needsBack: false },
  { id: "call_fly", label: "Call fly", needsBack: false },
  { id: "put_fly", label: "Put fly", needsBack: false },
  { id: "condor", label: "Condor", needsBack: false },
  { id: "seagull", label: "Seagull", needsBack: false },
  { id: "collar", label: "Collar", needsBack: false },
  { id: "call_ratio", label: "Call ratio", needsBack: false },
  { id: "calendar", label: "Calendar", needsBack: true },
  { id: "diagonal", label: "Diagonal", needsBack: true },
];

export function expandTemplate(name: string, expiries: string[], qty = 1): Leg[] {
  const spec = BOOK[name];
  if (!spec) throw new Error(`Unknown template ${name}`);
  return spec.map((row) => ({
    id: uid(),
    callPut: row.callPut,
    qty: row.qty * qty,
    strikeMode: "delta",
    strike: row.delta,
    expiry: expiries[row.which] ?? expiries[0],
    vol: null,
  }));
}
