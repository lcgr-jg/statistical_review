import { useQuery } from "@tanstack/react-query";
import { getJson } from "./api";

export type SpotVolFit = {
  beta: number;
  corr: number | null;
  resid: number;
  retStd: number;
  n: number;
  r2: number | null;
};

type HistorySlice = {
  scatter: { ret: (number | null)[]; dvol: (number | null)[] };
  changes_fit: {
    n: number;
    intercept: number | null;
    slope: number | null;
    r2: number | null;
    corr: number | null;
  };
};

/** Daily change in ATM vol on the daily log return, plus the residual size of that fit. */
export function fitFromHistory(data: HistorySlice): SpotVolFit | null {
  const slope = data.changes_fit.slope;
  const intercept = data.changes_fit.intercept ?? 0;
  if (slope == null) return null;
  const xs: number[] = [];
  const ys: number[] = [];
  const n = Math.min(data.scatter.ret.length, data.scatter.dvol.length);
  for (let i = 0; i < n; i++) {
    const x = data.scatter.ret[i];
    const y = data.scatter.dvol[i];
    if (x == null || y == null || !Number.isFinite(x) || !Number.isFinite(y)) continue;
    xs.push(x);
    ys.push(y);
  }
  if (xs.length < 10) return null;
  let sse = 0;
  let mean = 0;
  for (let i = 0; i < xs.length; i++) {
    mean += xs[i];
    const error = ys[i] - intercept - slope * xs[i];
    sse += error * error;
  }
  mean /= xs.length;
  let varRet = 0;
  for (const x of xs) varRet += (x - mean) ** 2;
  const retStd = Math.sqrt(varRet / xs.length);
  if (!(retStd > 0)) return null;
  return {
    beta: slope,
    corr: data.changes_fit.corr,
    resid: Math.sqrt(sse / xs.length),
    retStd,
    n: xs.length,
    r2: data.changes_fit.r2,
  };
}

/** Expected vol at a spot, and a ±1σ band. The band widens with the size of the move. */
export function likelyVol(spot: number, forward: number, atm: number, fit: SpotVolFit) {
  const move = Math.log(spot / forward);
  const mid = Math.max(0.01, atm + fit.beta * move);
  const typicalDays = Math.abs(move) / fit.retStd;
  const half = fit.resid * Math.max(typicalDays, 1);
  return { mid, lo: Math.max(0.01, mid - half), hi: mid + half };
}

export function bandLabel(fit: SpotVolFit): string {
  const pts = fit.beta * Math.log(1.1) * 100;
  const rho = fit.corr == null ? "" : `, ρ ${fit.corr.toFixed(2)}`;
  return `History ${pts >= 0 ? "+" : ""}${pts.toFixed(1)} vol pts per 10% rally${rho}. Shaded band is ±1σ of that fit.`;
}

export function useSpotVolFit(contract: string | undefined) {
  return useQuery({
    queryKey: ["vol-history", contract, 2],
    queryFn: () => getJson<HistorySlice>(`/api/vol/history?contract=${encodeURIComponent(contract!)}&years=2`),
    enabled: !!contract,
    staleTime: 5 * 60_000,
    select: fitFromHistory,
  });
}
