import { useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { EChart } from "../components/charts/EChart";
import { accent, axis, down, mute, tooltip, up, warn } from "../components/charts/theme";
import { Empty, Field, Freshness, Note, Page, Panel, Problem, Td, Th, Tile, Tiles, Toolbar } from "../components/ui";
import { downloadText, toCsv } from "../model/export";
import { px, signed } from "../model/format";
import type { JournalEntry, VarBody, VarPositionIn, VarResult } from "../model/history";
import { inBook, journalQuery, positionFor } from "../model/journal";
import { varQuery } from "../model/queries";
import { marketReady, toLegs, toMarketIn } from "../model/types";
import { useLab } from "../store/lab";

const BUILDER_ID = "builder";

export function Risk() {
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const regime = useLab((s) => s.regime);
  const excluded = useLab((s) => s.bookExcluded);
  const toggleBook = useLab((s) => s.toggleBook);
  const setScreen = useLab((s) => s.setScreen);
  const askCopilot = useLab((s) => s.askCopilot);
  const navigate = useNavigate();
  const [horizon, setHorizon] = useState(1);
  const [years, setYears] = useState(6);
  const [withBuilder, setWithBuilder] = useState(false);

  const journal = useQuery(journalQuery);
  const candidates = useMemo(() => (journal.data?.entries ?? []).filter(inBook), [journal.data]);
  const chosen = candidates.filter((e) => !excluded.includes(e.id));
  const builderReady = marketReady(market) && legs.length > 0 && !!market.source;

  const positions = useQuery({
    queryKey: ["risk-positions", chosen.map((e) => e.id)],
    enabled: chosen.length > 0,
    staleTime: 60_000,
    queryFn: async () => {
      const settled = await Promise.allSettled(chosen.map((e) => positionFor(e)));
      const ok: VarPositionIn[] = [];
      const failed: { entry: JournalEntry; error: string }[] = [];
      settled.forEach((r, i) => (r.status === "fulfilled" ? ok.push(r.value) : failed.push({ entry: chosen[i], error: (r.reason as Error).message })));
      return { ok, failed };
    },
  });

  const body: VarBody | null = useMemo(() => {
    const list = [...(positions.data?.ok ?? [])];
    if (withBuilder && builderReady) {
      list.push({ id: BUILDER_ID, label: "Builder structure", market: toMarketIn(market!), legs: toLegs(legs), contract: market!.source!.contracts[0], size: 1 });
    }
    return list.length ? { positions: list, regime, years, horizon } : null;
  }, [positions.data, withBuilder, builderReady, market, legs, regime, years, horizon]);
  const risk = useQuery(varQuery(body));
  const r = risk.data;

  useEffect(() => {
    if (!r) return;
    setScreen("Risk", {
      horizon_sessions: r.horizon,
      scenarios: r.n_scenarios,
      var_es: r.levels,
      totals: r.totals,
      positions: r.positions,
      stresses: r.stresses.filter((s) => s.n > 0),
      worst_days: r.worst.slice(0, 5).map((w) => ({ date: w.date, pnl: w.pnl })),
    });
  }, [r, setScreen]);

  const hist = useMemo(() => histChart(r), [r]);
  const path = useMemo(() => pathChart(r), [r]);
  const ccy = market?.currency ?? "EUR";

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <Freshness queries={[risk]} />
            <button className="btn" disabled={!r} onClick={() => askCopilot({ mode: "chat", prompt: "Read this book's VaR and stresses. What drives the tail, which regime hurts most, and what would you trade to cut it?", page: "Risk" })}>
              Explain
            </button>
            <button className="btn" disabled={!r} onClick={() => r && downloadText("book_scenarios.csv", toCsv(r.series.dates.map((d, i) => ({ date: d, pnl: r.series.pnl[i] }))))}>
              CSV
            </button>
          </>
        }
      >
        <Field label="Horizon" hint="Sessions over which each historical move is applied">
          <select value={horizon} onChange={(e) => setHorizon(Number(e.target.value))}>
            <option value={1}>1 day</option>
            <option value={5}>1 week</option>
            <option value={10}>10 days</option>
          </select>
        </Field>
        <Field label="Years" hint="History the scenarios are drawn from, limited by when the product's implied-vol history starts">
          <select value={years} onChange={(e) => setYears(Number(e.target.value))}>
            {[3, 4, 6, 8, 10].map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        </Field>
        <label className="flex items-center gap-1 pb-1 text-[12px]" title={builderReady ? "Add what is loaded in the Builder, one lot, as a what-if" : "Load a Bloomberg market and legs in the Builder first"}>
          <input type="checkbox" disabled={!builderReady} checked={withBuilder && builderReady} onChange={(e) => setWithBuilder(e.target.checked)} />
          Add Builder structure (what-if)
        </label>
        <span className="pb-1 text-mute">{chosen.length} of {candidates.length} open trades · {regime}</span>
      </Toolbar>

      <Problem error={journal.error ?? risk.error} />
      {positions.data?.failed.map((f) => (
        <p key={f.entry.id} className="mb-1 text-[12px] text-warn">Left out {f.entry.label}: {f.error}</p>
      ))}

      {!candidates.length && !withBuilder && (
        <Empty>
          No open trades in the Journal. Log a structure as traded from the Builder, or mark a parsed quote as traded, and it appears here.{" "}
          <button className="btn ml-1" onClick={() => navigate("/journal")}>Open Journal</button>
        </Empty>
      )}
      {(risk.isFetching || positions.isFetching) && !r && <div className="skeleton mb-3 h-20" />}

      {r && (
        <Tiles>
          <Tile k={`VaR 95%, ${ccy}`} v={signed(-r.levels["95"].var, 0)} tone="down" sub={`${r.horizon}-session loss, 1 in 20`} hint="Loss exceeded in 5% of historical scenarios" />
          <Tile k="ES 95%" v={signed(-r.levels["95"].es, 0)} tone="down" hint="Average loss in the worst 5% of scenarios" />
          <Tile k="VaR 99%" v={signed(-r.levels["99"].var, 0)} tone="down" />
          <Tile k="ES 99%" v={signed(-r.levels["99"].es, 0)} tone="down" />
          <Tile k="Scenarios" v={String(r.n_scenarios)} sub={`${r.from} → ${r.to}`} />
          <Tile k="Net delta" v={px(r.totals.delta, 1)} hint="Cash delta: P&L per unit move in the future" />
          <Tile k="Vega / pt" v={signed(r.totals.vega_point, 0)} tone={r.totals.vega_point >= 0 ? "up" : "down"} />
          <Tile k="Theta / day" v={signed(r.totals.theta_day, 0)} tone={r.totals.theta_day >= 0 ? "up" : "down"} />
        </Tiles>
      )}

      <Panel title="Book" size="auto" pad={false} className="mb-3" right={<span className="text-[11px]">open trades from the Journal, re-priced on today's smiles</span>}>
        {candidates.length === 0 && !withBuilder ? (
          <Empty>Nothing in the book yet.</Empty>
        ) : (
          <table className="blotter">
            <thead>
              <tr>
                <Th />
                <Th>Position</Th>
                <Th right>Lots</Th>
                <Th right>Value</Th>
                <Th right>Delta</Th>
                <Th right>Vega / pt</Th>
                <Th right>Theta / day</Th>
                <Th right hint="The position's own 95% VaR">VaR 95% alone</Th>
                <Th right hint="Average P&L of this position in the book's worst 5% of scenarios; these add up to the book's ES">Share of ES 95%</Th>
              </tr>
            </thead>
            <tbody>
              {candidates.map((e) => {
                const row = r?.positions.find((p) => p.id === e.id);
                const off = excluded.includes(e.id);
                return (
                  <tr key={e.id} className={off ? "opacity-40" : ""}>
                    <Td><input type="checkbox" checked={!off} onChange={() => toggleBook(e.id)} title="Include in the book" /></Td>
                    <Td mono={false}>{e.label}{e.tags.length ? <span className="ml-1 text-[10px] text-mute">{e.tags.map((t) => `#${t}`).join(" ")}</span> : null}</Td>
                    <Td right>{e.size ?? 1}</Td>
                    <RiskCells row={row} es={r?.levels["95"].es} />
                  </tr>
                );
              })}
              {withBuilder && builderReady && (
                <tr>
                  <Td />
                  <Td mono={false} className="text-accent">Builder structure (what-if)</Td>
                  <Td right>1</Td>
                  <RiskCells row={r?.positions.find((p) => p.id === BUILDER_ID)} es={r?.levels["95"].es} />
                </tr>
              )}
            </tbody>
          </table>
        )}
      </Panel>

      {r && (
        <div className="grid gap-3 xl:grid-cols-2">
          <Panel title={`Book P&L over ${r.horizon} session${r.horizon > 1 ? "s" : ""}, by scenario`}>
            <EChart option={hist} />
          </Panel>
          <Panel title="Scenario P&L by start date">
            <EChart option={path} />
          </Panel>
          <Panel title="Stress by regime" size="auto" pad={false}>
            <table className="blotter">
              <thead>
                <tr>
                  <Th>Regime</Th>
                  <Th right>Scenarios</Th>
                  <Th right>Worst</Th>
                  <Th>On</Th>
                  <Th right>Mean</Th>
                  <Th right>VaR 95%</Th>
                </tr>
              </thead>
              <tbody>
                {r.stresses.map((s) => (
                  <tr key={s.id} className={s.n ? "" : "opacity-40"}>
                    <Td mono={false}>{s.label}</Td>
                    <Td right>{s.n || "—"}</Td>
                    <Td right tone={s.worst}>{signed(s.worst, 0)}</Td>
                    <Td className="text-mute">{s.worst_date ?? "—"}</Td>
                    <Td right tone={s.mean}>{signed(s.mean, 0)}</Td>
                    <Td right>{s.var_95 == null ? "—" : signed(-s.var_95, 0)}</Td>
                  </tr>
                ))}
              </tbody>
            </table>
            {r.stresses.some((s) => s.n === 0) && (
              <p className="px-2 pb-2 text-[11px] text-mute">
                Faded regimes have no scenarios: they are before the Years window or before every product in the book has implied-vol history (TTF from August 2020).
              </p>
            )}
          </Panel>
          <Panel title="Ten worst scenarios" size="auto" pad={false}>
            <table className="blotter">
              <thead>
                <tr>
                  <Th>Start</Th>
                  <Th right>Book</Th>
                  {r.positions.map((p) => <Th key={p.id} right>{p.label}</Th>)}
                </tr>
              </thead>
              <tbody>
                {r.worst.map((w) => (
                  <tr key={w.date}>
                    <Td>{w.date}</Td>
                    <Td right tone={w.pnl}>{signed(w.pnl, 0)}</Td>
                    {r.positions.map((p) => <Td key={p.id} right tone={w.positions[p.id]}>{signed(w.positions[p.id], 0)}</Td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </Panel>
        </div>
      )}
      {r && (
        <Note>
          <ul className="list-disc space-y-1 pl-4">
            {r.assumptions.map((a) => <li key={a}>{a}</li>)}
            <li>
              Journal trades are valued per lot (the contract size) times the lots logged. The Builder what-if is valued as the Builder prices it, per unit or per lot.
              Every position is summed in its own currency, so mix products in one currency only.
            </li>
          </ul>
        </Note>
      )}
    </Page>
  );
}

function RiskCells({ row, es }: { row?: VarResult["positions"][number]; es?: number }) {
  if (!row) return <>{Array.from({ length: 6 }, (_, i) => <Td key={i} right className="text-mute">—</Td>)}</>;
  return (
    <>
      <Td right>{signed(row.value, 0)}</Td>
      <Td right>{px(row.delta, 1)}</Td>
      <Td right tone={row.vega_point}>{signed(row.vega_point, 0)}</Td>
      <Td right tone={row.theta_day}>{signed(row.theta_day, 0)}</Td>
      <Td right>{signed(-row.var_95, 0)}</Td>
      <Td right>{es ? `${((row.es_contribution_95 / es) * 100).toFixed(0)}%` : "—"}</Td>
    </>
  );
}

function histChart(r: VarResult | undefined): EChartsOption {
  if (!r) return {};
  const { counts, edges } = r.histogram;
  const width = edges[1] - edges[0];
  const cut95 = -r.levels["95"].var;
  const cut99 = -r.levels["99"].var;
  return {
    tooltip,
    grid: { left: 44, right: 12, top: 16, bottom: 32 },
    xAxis: { type: "value", ...axis(), min: edges[0], max: edges[edges.length - 1] },
    yAxis: { type: "value", ...axis() },
    series: [
      {
        type: "bar",
        barWidth: "95%",
        data: counts.map((c, i) => {
          const mid = edges[i] + width / 2;
          return { value: [mid, c], itemStyle: { color: mid <= cut99 ? down : mid <= cut95 ? warn : mid >= 0 ? up : "#3c4452" } };
        }),
        markLine: {
          symbol: "none",
          label: { color: mute, fontSize: 10, formatter: (p: { name?: string }) => p.name ?? "" },
          lineStyle: { color: accent, type: "dashed" },
          data: [
            { name: "VaR 95", xAxis: cut95 },
            { name: "VaR 99", xAxis: cut99 },
          ],
        },
      },
    ],
  };
}

function pathChart(r: VarResult | undefined): EChartsOption {
  if (!r) return {};
  return {
    tooltip: { ...tooltip, trigger: "axis" },
    grid: { left: 56, right: 12, top: 16, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: r.series.dates },
    yAxis: { type: "value", ...axis() },
    series: [
      {
        type: "bar",
        data: r.series.pnl.map((v) => ({ value: v, itemStyle: { color: v >= 0 ? up : down } })),
        markLine: { symbol: "none", lineStyle: { color: warn, type: "dashed" }, label: { color: mute, fontSize: 10 }, data: [{ name: "VaR 95", yAxis: -r.levels["95"].var }] },
      },
    ],
  };
}
