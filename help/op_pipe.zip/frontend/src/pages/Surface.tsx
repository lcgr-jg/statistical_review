import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useMemo, useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, down, ink, mute, tooltip, up, warn } from "../components/charts/theme";
import { Empty, Field, Flag, Freshness, Gate, Loading, Note, Page, Panel, Problem, Segmented, Td, Th, Tile, Tiles, Toolbar } from "../components/ui";
import { downloadText, toCsv } from "../model/export";
import { px, signed, volPts } from "../model/format";
import { SURFACE_LIMIT, surfaceHistoryQuery, surfaceQuery } from "../model/queries";
import type { Pillar, SmileSource } from "../model/types";
import { useLab } from "../store/lab";

type SurfaceRow = {
  contract: string;
  label: string;
  expiry: string | null;
  days: number | null;
  error: string | null;
  forward?: number | null;
  pillars?: Partial<Record<Pillar, number | null>>;
  vol_source?: string;
  model?: "sabr" | "poly" | null;
  alpha?: number | null;
  beta?: number | null;
  rho?: number | null;
  nu?: number | null;
  rmse?: number | null;
  rr25?: number | null;
  bf25?: number | null;
  n_used?: number;
  n_points?: number;
  density_ok?: boolean | null;
  arbitrage_ok?: boolean | null;
  parity_break?: boolean | null;
  parity_diff?: number | null;
  warnings?: string[];
  curve?: { call_delta: number; vol: number; strike: number; extrapolated: boolean }[];
  points?: { strike: number; cp: "C" | "P"; vol: number; call_delta: number; used: boolean; resid: number | null }[];
};

type Surface = { product: string; as_of: string; source: SmileSource; rows: SurfaceRow[]; warning: string | null; computed_at?: string };

type SeriesKey = "atm" | "rr25" | "bf25" | "rho" | "nu" | "rmse" | "forward";
type SeriesStats = { current: number | null; mean: number | null; std: number | null; z: number | null; percentile: number | null; n: number };
type HistorySeries = { dates: string[]; contracts?: string[]; series: Record<SeriesKey, (number | null)[]>; stats: Record<SeriesKey, SeriesStats> };
type SurfaceHistory = { days: number; from: string | null; to: string | null; by_contract: Record<string, HistorySeries>; by_rank: Record<string, HistorySeries> };

const METRICS: { key: SeriesKey; label: string; fmt: (v: number | null | undefined) => string; hint: string }[] = [
  { key: "atm", label: "ATM", fmt: (v) => volPts(v), hint: "50-delta vol" },
  { key: "rr25", label: "25Δ RR", fmt: (v) => signed(v == null ? null : v * 100, 1), hint: "25-delta call minus 25-delta put" },
  { key: "bf25", label: "25Δ BF", fmt: (v) => signed(v == null ? null : v * 100, 1), hint: "Average of the 25-delta wings minus ATM" },
  { key: "rho", label: "ρ", fmt: (v) => (v == null ? "—" : v.toFixed(2)), hint: "SABR spot-vol correlation: sets the skew" },
  { key: "nu", label: "ν", fmt: (v) => (v == null ? "—" : v.toFixed(2)), hint: "SABR vol of vol: sets the curvature" },
];

const RANK_COLOURS = [accent, warn, "#7aa6c2", "#b39ddb", up, down, ink, mute];

export function Surface() {
  const market = useLab((s) => s.market);
  const setScreen = useLab((s) => s.setScreen);
  const askCopilot = useLab((s) => s.askCopilot);
  const product = market?.source?.product;
  const [source, setSource] = useState<SmileSource>(market?.source?.volSource ?? "settle");
  const [limit, setLimit] = useState(SURFACE_LIMIT);
  const [selected, setSelected] = useState<string | null>(null);
  const [metric, setMetric] = useState<SeriesKey>("rr25");
  const queryClient = useQueryClient();

  const surface = useQuery({ ...surfaceQuery<Surface>(product ?? "", source, limit), enabled: !!product });

  const contracts = (surface.data?.rows ?? []).filter((r) => !r.error).map((r) => r.contract);
  const history = useQuery({ ...surfaceHistoryQuery<SurfaceHistory>(contracts), enabled: contracts.length > 0 });

  const rows = useMemo(() => (surface.data?.rows ?? []).filter((r) => !r.error), [surface.data]);
  const failed = (surface.data?.rows ?? []).filter((r) => r.error);
  const current = rows.find((r) => r.contract === selected) ?? rows[0];

  useEffect(() => {
    if (!rows.length) {
      setScreen("Surface", null);
      return;
    }
    const m1 = history.data?.by_rank["M+1"]?.stats;
    setScreen("Surface", {
      product,
      source,
      as_of: surface.data?.as_of,
      expiries: rows.map((r) => ({
        label: r.label, days: r.days, future: r.forward, atm: r.pillars?.["50D"], rr25: r.rr25, bf25: r.bf25, model: r.model, rho: r.rho, nu: r.nu, rmse: r.rmse,
        density_ok: r.density_ok, static_arb_ok: r.arbitrage_ok, parity_break: r.parity_break, warnings: r.warnings,
      })),
      front_month_history: m1 ? { days: history.data?.days, atm: m1.atm, rr25: m1.rr25, bf25: m1.bf25, rho: m1.rho, nu: m1.nu } : null,
    });
  }, [rows, history.data, product, source, surface.data?.as_of, setScreen]);

  if (!product) {
    return <Gate title="The whole surface, one expiry per row." text="Find a market first. Every listed expiry is fitted from its settlement chain and checked for arbitrage." />;
  }

  const m1 = history.data?.by_rank["M+1"];
  const front = rows[0];
  const checks = rows.reduce(
    (acc, r) => ({
      density: acc.density + (r.density_ok === false ? 1 : 0),
      arb: acc.arb + (r.arbitrage_ok === false ? 1 : 0),
      parity: acc.parity + (r.parity_break ? 1 : 0),
      poly: acc.poly + (r.model === "poly" ? 1 : 0),
    }),
    { density: 0, arb: 0, parity: 0, poly: 0 },
  );
  const issues = checks.density + checks.arb + checks.parity;

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <button
              className="btn"
              disabled={!rows.length}
              onClick={() =>
                askCopilot({
                  mode: "chat",
                  prompt: "Read this vol surface. Where are skew and fly rich or cheap against their own history, which expiries fail the fit or arbitrage checks and why, and which relative-value trades across expiries or strikes does it suggest?",
                  page: "Surface",
                })
              }
            >
              Explain
            </button>
            <button className="btn" disabled={!rows.length} onClick={() => downloadText(`surface-${product.split(" ")[0]}.csv`, toCsv(rows.map(csvRow)))}>
              CSV
            </button>
            <Freshness queries={[surface, history]} />
            <button
              className="btn"
              disabled={surface.isFetching}
              onClick={() => queryClient.fetchQuery(surfaceQuery<Surface>(product, source, limit, true))}
            >
              {surface.isFetching ? "Fitting…" : "Refresh"}
            </button>
          </>
        }
      >
        <Field label="Prices" hint="Settlement chain (clean, once a day) or live mid">
          <Segmented value={source} onChange={setSource} options={[{ value: "settle", label: "Settle" }, { value: "mid", label: "Mid" }]} />
        </Field>
        <Field label="Expiries">
          <select value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
            {[6, 8, 12, 16, 24].map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </Field>
        <Field label="History metric" hint="Series drawn in the parameter-history panel">
          <Segmented value={metric} onChange={setMetric} options={METRICS.map((m) => ({ value: m.key, label: m.label, hint: m.hint }))} />
        </Field>
        <span className="text-mute">{surface.data ? `As of ${surface.data.as_of}` : ""}</span>
      </Toolbar>

      <Problem error={surface.error} warning={surface.data?.warning ?? (failed.length ? `${failed.length} expir${failed.length === 1 ? "y" : "ies"} could not be fitted: ${failed.map((f) => f.label).join(", ")}` : null)} />

      <Tiles>
        <Tile k={`Front ATM · ${front?.label ?? ""}`} v={volPts(front?.pillars?.["50D"])} sub={zText(m1?.stats.atm)} tone={zTone(m1?.stats.atm)} hint="50-delta vol of the first expiry, with its z-score against the stored history" />
        <Tile k="Front 25Δ RR" v={signed((front?.rr25 ?? NaN) * 100, 1)} sub={zText(m1?.stats.rr25)} tone={zTone(m1?.stats.rr25)} hint="Call minus put vol at 25 delta. Positive: calls bid." />
        <Tile k="Front 25Δ BF" v={signed((front?.bf25 ?? NaN) * 100, 1)} sub={zText(m1?.stats.bf25)} tone={zTone(m1?.stats.bf25)} hint="Wings over ATM. Higher: fatter tails priced." />
        <Tile k="Front ρ / ν" v={front?.model === "sabr" ? `${front.rho?.toFixed(2)} / ${front.nu?.toFixed(2)}` : "—"} sub={m1 ? `ρ ${zText(m1.stats.rho)} · ν ${zText(m1.stats.nu)}` : undefined} hint="SABR correlation and vol of vol for the front expiry" />
        <Tile k="Slope M+1 → M+3" v={slopeText(rows)} hint="ATM of the third expiry minus the first, in vol points" />
        <Tile k="Checks" v={issues ? `${issues} flag${issues === 1 ? "" : "s"}` : rows.length ? "Clean" : "—"} tone={issues ? "down" : rows.length ? "up" : ""} sub={issues ? [checks.density && `${checks.density} density`, checks.arb && `${checks.arb} static arb`, checks.parity && `${checks.parity} parity`].filter(Boolean).join(" · ") : checks.poly ? `${checks.poly} polynomial fallback` : "All expiries SABR, no arbitrage"} hint="Fitted density, static arbitrage on settlements, put-call parity" />
        <Tile k="History" v={history.data ? `${history.data.days}d` : "—"} sub={history.data?.from ? `${history.data.from} → ${history.data.to}` : "Snapshots accumulate daily"} hint="Days of stored smile snapshots behind the z-scores" />
      </Tiles>

      <div className="grid gap-3 xl:grid-cols-3">
        <Panel title="Expiries" span={2} size="xl" pad={false} right={<span className="text-[11px]">{rows.length ? `${rows.length} fitted · click a row for its residuals` : ""}</span>}>
          {surface.isFetching && !surface.data ? (
            <Loading label="Fitting every listed expiry…" />
          ) : rows.length ? (
            <div className="h-full overflow-auto">
              <table className="blotter">
                <thead className="sticky top-0 bg-raised">
                  <tr>
                    <Th>Expiry</Th>
                    <Th right>Days</Th>
                    <Th right>Future</Th>
                    <Th right hint="50-delta vol">ATM</Th>
                    <Th right hint="25Δ call minus 25Δ put, vol pts">RR</Th>
                    <Th right hint="Wings minus ATM, vol pts">BF</Th>
                    <Th right hint="10Δ call minus 10Δ put, vol pts">RR10</Th>
                    <Th right hint="SABR correlation">ρ</Th>
                    <Th right hint="SABR vol of vol">ν</Th>
                    <Th right hint="Fit error on the strikes used, vol pts">Err</Th>
                    <Th right hint="Strikes used / quoted">Pts</Th>
                    <Th>Checks</Th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const rr10 = r.pillars?.["10DC"] != null && r.pillars?.["10DP"] != null ? r.pillars["10DC"]! - r.pillars["10DP"]! : null;
                    const active = r.contract === current?.contract;
                    return (
                      <tr key={r.contract} className={`cursor-pointer hover:bg-[#20252d] ${active ? "bg-[#20252d]" : ""}`} onClick={() => setSelected(r.contract)} title={r.warnings?.join("\n")}>
                        <Td mono={false}>
                          <span className={active ? "text-accent" : ""}>{r.label}</span>
                          <span className="ml-1 text-[10px] text-mute">{r.contract.replace(/ Comdty$/, "")}</span>
                        </Td>
                        <Td right>{r.days ?? "—"}</Td>
                        <Td right>{px(r.forward)}</Td>
                        <Td right>{volPts(r.pillars?.["50D"])}</Td>
                        <Td right tone={r.rr25}>{signed((r.rr25 ?? NaN) * 100, 1)}</Td>
                        <Td right>{signed((r.bf25 ?? NaN) * 100, 1)}</Td>
                        <Td right tone={rr10}>{signed(rr10 == null ? null : rr10 * 100, 1)}</Td>
                        <Td right>{r.model === "sabr" ? r.rho?.toFixed(2) : "—"}</Td>
                        <Td right>{r.model === "sabr" ? r.nu?.toFixed(2) : "—"}</Td>
                        <Td right tone={r.rmse != null && r.rmse > 0.01 ? "down" : ""}>{r.rmse == null ? "—" : (r.rmse * 100).toFixed(2)}</Td>
                        <Td right>{r.n_used}/{r.n_points}</Td>
                        <Td mono={false}>
                          <span className="flex gap-1">
                            <Flag ok={r.model === "sabr"} label={r.model === "sabr" ? "SABR" : "poly"} hint={r.model === "sabr" ? "SABR fit" : "SABR did not fit well enough; polynomial smile used"} />
                            <Flag ok={r.density_ok} label="dens" hint="Fitted smile implies a positive risk-neutral density" />
                            <Flag ok={r.arbitrage_ok} label="arb" hint="Settlement prices pass vertical and butterfly checks" />
                            <Flag ok={r.parity_break == null ? null : !r.parity_break} label="par" hint={r.parity_diff != null ? `Parity-implied forward differs from the future by ${signed(r.parity_diff, 3)}` : "Put-call parity implied forward against the future"} />
                          </span>
                        </Td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <Empty>No expiries fitted.</Empty>
          )}
        </Panel>

        <Panel title="Smiles by delta" size="xl" right={<span className="text-[11px]">front bright, back faded</span>}>
          {rows.length ? <EChart option={smilesChart(rows, current?.contract)} /> : <Empty />}
        </Panel>

        <Panel title="Term structure of ATM, RR and BF">
          {rows.length ? <EChart option={termChart(rows)} /> : <Empty />}
        </Panel>

        <Panel title={`${METRICS.find((m) => m.key === metric)?.label ?? metric} by curve position, from snapshots`} right={<span className="text-[11px]">{history.data?.days ? `${history.data.days} days stored` : ""}</span>}>
          {history.isFetching && !history.data ? <Loading /> : history.data && history.data.days > 1 ? <EChart option={historyChart(history.data, metric)} /> : <Empty>Snapshots build up one per day; the history view needs two or more.</Empty>}
        </Panel>

        <Panel title={current ? `${current.label} fit residuals by strike` : "Fit residuals"} right={current && <span className="text-[11px]">{current.model === "sabr" ? `α ${current.alpha?.toFixed(3)} β ${current.beta} ρ ${current.rho?.toFixed(2)} ν ${current.nu?.toFixed(2)}` : "polynomial fallback"}</span>}>
          {current?.points?.length ? <EChart option={residualChart(current)} /> : <Empty>Select an expiry.</Empty>}
        </Panel>
      </div>

      <Note>
        Each expiry is fitted on its own from the chain: SABR with β fixed, α solved from the ATM, ρ and ν least-squares on the quoted strikes after dropping tick-floor settlements.
        Err is the RMS vol error on the strikes used. Checks: <b>dens</b> fitted density stays positive; <b>arb</b> settlement prices are monotone and convex in strike within a tick; <b>par</b> the put-call-parity forward sits within tolerance of the future.
        z-scores compare today's value with this product's stored snapshots at the same curve position, so they mean little until a few weeks of history exist.
      </Note>
    </Page>
  );
}

function zText(stat: SeriesStats | undefined) {
  if (!stat || stat.z == null) return stat && stat.n ? `${stat.n}d history` : undefined;
  return `z ${signed(stat.z, 1)} · ${Math.round((stat.percentile ?? 0) * 100)}th pct · ${stat.n}d`;
}

function zTone(stat: SeriesStats | undefined): "up" | "down" | "" {
  if (!stat || stat.z == null) return "";
  return stat.z > 1.5 ? "up" : stat.z < -1.5 ? "down" : "";
}

function slopeText(rows: SurfaceRow[]) {
  const a = rows[0]?.pillars?.["50D"];
  const b = rows[2]?.pillars?.["50D"];
  return a != null && b != null ? signed((b - a) * 100, 1) : "—";
}

function csvRow(r: SurfaceRow) {
  return {
    contract: r.contract, label: r.label, expiry: r.expiry, days: r.days, future: r.forward,
    atm: r.pillars?.["50D"], d25c: r.pillars?.["25DC"], d25p: r.pillars?.["25DP"], d10c: r.pillars?.["10DC"], d10p: r.pillars?.["10DP"],
    rr25: r.rr25, bf25: r.bf25, model: r.model, alpha: r.alpha, beta: r.beta, rho: r.rho, nu: r.nu, rmse: r.rmse,
    n_used: r.n_used, n_points: r.n_points, density_ok: r.density_ok, arbitrage_ok: r.arbitrage_ok, parity_break: r.parity_break, warnings: (r.warnings ?? []).join(" | "),
  };
}

const deltaAxis = {
  type: "value" as const,
  min: 0.05,
  max: 0.95,
  inverse: true,
  ...axis(),
  name: "call delta",
  nameLocation: "middle" as const,
  nameGap: 20,
  axisLabel: { ...axis().axisLabel, formatter: (v: number) => `${Math.round(v * 100)}` },
};

function smilesChart(rows: SurfaceRow[], highlight?: string): EChartsOption {
  const n = rows.length;
  return {
    tooltip: { ...tooltip, trigger: "axis", valueFormatter: (v) => (typeof v === "number" ? v.toFixed(1) : "—") },
    legend: { type: "scroll", textStyle: { color: mute, fontSize: 10 }, top: 0 },
    grid: { left: 44, right: 16, top: 30, bottom: 36 },
    xAxis: deltaAxis,
    yAxis: { type: "value", ...axis(), scale: true, axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v)) } },
    series: rows.map((r, i) => {
      const active = r.contract === highlight;
      const t = n > 1 ? i / (n - 1) : 0;
      return {
        name: r.label,
        type: "line" as const,
        showSymbol: false,
        smooth: true,
        z: active ? 10 : 1,
        data: (r.curve ?? []).filter((c) => !c.extrapolated).map((c) => [c.call_delta, c.vol * 100]),
        lineStyle: { color: active ? ink : accent, width: active ? 2.2 : 1.2, opacity: active ? 1 : 0.9 - 0.7 * t },
        itemStyle: { color: active ? ink : accent, opacity: active ? 1 : 0.9 - 0.7 * t },
      };
    }),
  };
}

function termChart(rows: SurfaceRow[]): EChartsOption {
  const labels = rows.map((r) => r.label);
  const pts = (v: number | null | undefined) => (v == null ? null : v * 100);
  return {
    tooltip: { ...tooltip, trigger: "axis", valueFormatter: (v) => (typeof v === "number" ? v.toFixed(1) : "—") },
    legend: { textStyle: { color: mute, fontSize: 10 }, top: 0 },
    grid: { left: 44, right: 44, top: 28, bottom: 40 },
    xAxis: { type: "category", data: labels, ...axis(), axisLabel: { ...axis().axisLabel, formatter: (l: string, i: number) => `${l}\n${rows[i]?.days ?? ""}d` } },
    yAxis: [
      { type: "value", ...axis(), name: "ATM", scale: true, axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v)) } },
      { type: "value", ...axis(), name: "RR / BF", splitLine: { show: false } },
    ],
    series: [
      { name: "ATM", type: "line", symbolSize: 5, data: rows.map((r) => pts(r.pillars?.["50D"])), lineStyle: { color: accent, width: 2 }, itemStyle: { color: accent } },
      { name: "25Δ RR", type: "bar", yAxisIndex: 1, barWidth: 7, data: rows.map((r) => pts(r.rr25)), itemStyle: { color: "#7aa6c2", opacity: 0.8 } },
      { name: "25Δ BF", type: "bar", yAxisIndex: 1, barWidth: 7, data: rows.map((r) => pts(r.bf25)), itemStyle: { color: "#b39ddb", opacity: 0.8 } },
    ],
  };
}

function historyChart(data: SurfaceHistory, metric: SeriesKey): EChartsOption {
  const ranks = Object.keys(data.by_rank);
  const scale = metric === "rho" || metric === "nu" ? 1 : 100;
  const dates = Array.from(new Set(ranks.flatMap((r) => data.by_rank[r].dates))).sort();
  return {
    tooltip: { ...tooltip, trigger: "axis", valueFormatter: (v) => (typeof v === "number" ? v.toFixed(scale === 1 ? 2 : 1) : "—") },
    legend: { textStyle: { color: mute, fontSize: 10 }, top: 0 },
    grid: { left: 44, right: 16, top: 28, bottom: 32 },
    xAxis: { type: "category", data: dates, ...axis() },
    yAxis: { type: "value", ...axis(), scale: true },
    series: ranks.map((rank, i) => {
      const s = data.by_rank[rank];
      const by = new Map(s.dates.map((d, k) => [d, s.series[metric][k]]));
      return {
        name: rank,
        type: "line" as const,
        showSymbol: dates.length < 40,
        symbolSize: 4,
        connectNulls: true,
        data: dates.map((d) => {
          const v = by.get(d);
          return v == null ? null : v * scale;
        }),
        lineStyle: { color: RANK_COLOURS[i % RANK_COLOURS.length], width: i === 0 ? 2 : 1.2 },
        itemStyle: { color: RANK_COLOURS[i % RANK_COLOURS.length] },
      };
    }),
  };
}

function residualChart(row: SurfaceRow): EChartsOption {
  const points = [...(row.points ?? [])].sort((a, b) => a.strike - b.strike);
  return {
    tooltip: {
      ...tooltip,
      trigger: "item",
      formatter: (p: unknown) => {
        const item = p as { dataIndex: number };
        const q = points[item.dataIndex];
        return `${q.cp} ${px(q.strike)}<br/>vol ${volPts(q.vol)} · Δ ${Math.round(q.call_delta * 100)}<br/>${q.used ? `residual ${signed((q.resid ?? 0) * 100, 2)} pts` : "dropped from fit"}`;
      },
    },
    grid: { left: 44, right: 16, top: 16, bottom: 32 },
    xAxis: { type: "category", data: points.map((q) => px(q.strike, 2)), ...axis(), name: "strike", nameLocation: "middle", nameGap: 20 },
    yAxis: { type: "value", ...axis(), name: "market − fit, pts" },
    series: [
      {
        type: "bar",
        barWidth: "60%",
        data: points.map((q) => ({
          value: q.used && q.resid != null ? q.resid * 100 : 0,
          itemStyle: { color: !q.used ? mute : (q.resid ?? 0) >= 0 ? up : down, opacity: q.used ? 0.85 : 0.35 },
        })),
        markLine: { silent: true, symbol: "none", lineStyle: { color: mute, type: "dashed" }, data: [{ yAxis: 0 }], label: { show: false } },
      },
    ],
  };
}
