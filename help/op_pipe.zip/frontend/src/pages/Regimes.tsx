import { useMutation, useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, down, tooltip, up, warn } from "../components/charts/theme";
import { Empty, Field, Page, Panel, Problem, Segmented, Tile, Tiles, Toolbar } from "../components/ui";
import { getJson, postJson } from "../model/api";
import { downloadText, toCsv } from "../model/export";
import { PILLARS, type AnalogPath, type ControlPoint, type HistResult, type Snapshot } from "../model/types";
import { useLab } from "../store/lab";

export function Regimes() {
  const underlying = useLab((s) => s.underlyingId);
  const market = useLab((s) => s.market);
  const setCalibration = useLab((s) => s.setCalibration);
  const setGhosts = useLab((s) => s.setGhosts);
  const setPoints = useLab((s) => s.setPoints);
  const askCopilot = useLab((s) => s.askCopilot);
  const today = new Date().toISOString().slice(0, 10);
  const [futures, setFutures] = useState(market?.source?.contracts[0] ?? "");
  const [vol, setVol] = useState("");
  const [rr, setRr] = useState("");
  const [start, setStart] = useState(shiftYears(today, -3));
  const [end, setEnd] = useState(today);
  const [window, setWindow] = useState(60);
  const [pillars, setPillars] = useState<Record<string, string>>({});
  const [showPillars, setShowPillars] = useState(false);
  const [month, setMonth] = useState("X");
  const [futureTemplate, setFutureTemplate] = useState("TZT{m}{y} Comdty");
  const [volTemplate, setVolTemplate] = useState("");
  const [years, setYears] = useState("2022,2023,2024,2025");

  const history = useMutation({
    mutationFn: () =>
      postJson<HistResult>("/api/history/spot-vol", {
        futures_ticker: futures.trim(),
        vol_ticker: vol.trim() || null,
        rr_ticker: rr.trim() || null,
        pillar_tickers: Object.fromEntries(Object.entries(pillars).filter(([, ticker]) => ticker.trim())),
        start,
        end,
        window,
      }),
    onSuccess: (result) => {
      setCalibration({
        rho: result.stats.rho,
        kappa: result.stats.ou.kappa,
        xi: result.stats.ou.xi,
        beta: result.stats.beta,
      });
    },
  });

  const analogs = useMutation({
    mutationFn: () =>
      postJson<{ paths: AnalogPath[]; errors: string[] }>("/api/history/analogs", {
        month_code: month,
        futures_template: futureTemplate,
        vol_template: volTemplate.trim() || null,
        years: years.split(",").map((y) => Number(y.trim())).filter((y) => Number.isFinite(y)),
        window_days: 120,
      }),
  });

  const curve = useQuery({
    queryKey: ["snapshot", underlying],
    queryFn: () => getJson<Snapshot>(`/api/market/${underlying}/snapshot`),
    enabled: false,
  });
  const data = history.data;

  const canRun = !!futures.trim();

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <button
              className="btn"
              disabled={!data}
              onClick={() =>
                data &&
                askCopilot({
                  mode: "chat",
                  prompt: "Read this regime analysis. Is implied vol rich or cheap against realised and history, which spot-vol regime fits, and what does that mean for structuring?",
                  page: "Regimes",
                  context: { regression: { futures, vol, risk_reversal: rr, start, end, window }, stats: data.stats },
                })
              }
            >
              Explain
            </button>
            <button className="btn" disabled={!data} onClick={() => data && downloadText("spot-vol.csv", toCsv(data.points as unknown as Record<string, unknown>[]))}>
              CSV
            </button>
            <button className="btn btn-primary" disabled={!canRun || history.isPending} onClick={() => history.mutate()}>
              {history.isPending ? "Loading…" : "Run regression"}
            </button>
          </>
        }
      >
        <TextField label={`${underlying} futures ticker`} value={futures} onChange={setFutures} className="w-44" />
        <TextField label="50Δ vol ticker" value={vol} onChange={setVol} className="w-44" hint="Blank uses this contract's own 50-delta implied vol" />
        <TextField label="25d risk reversal" value={rr} onChange={setRr} className="w-44" hint="Optional" />
        <TextField label="Start" value={start} onChange={setStart} type="date" />
        <TextField label="End" value={end} onChange={setEnd} type="date" />
        <Field label="Window" hint="Sessions in the rolling regression">
          <Segmented value={String(window)} onChange={(v) => setWindow(Number(v))} options={[20, 60, 120].map((w) => ({ value: String(w), label: String(w) }))} />
        </Field>
        <button className="btn" onClick={() => setShowPillars(!showPillars)}>{showPillars ? "Hide pillars" : "Pillar tickers"}</button>
      </Toolbar>
      {showPillars && (
        <div className="mb-3 grid gap-2 text-[12px] md:grid-cols-4">
          {PILLARS.filter((name) => name !== "50D").map((name) => (
            <TextField key={name} label={`${name} ticker`} value={pillars[name] ?? ""} onChange={(v) => setPillars({ ...pillars, [name]: v })} />
          ))}
        </div>
      )}

      <Problem error={history.error} />
      {history.isPending && <div className="skeleton mb-3 h-20" />}
      {!data && !history.isPending && (
        <Empty>
          Enter a futures ticker and run. 50-delta vol is read from that contract. The regression gives the spot-vol beta, correlation and mean reversion that feed Monte Carlo.
        </Empty>
      )}
      {data && (
        <>
          <p className="mb-2 text-[11px] text-mute">50Δ vol: {data.vol_series}</p>
          <Tiles>
            <Tile k="Beta, changes" v={fmt(data.stats.changes.slope)} sub={data.stats.beta != null ? `+10% rally ≈ ${(data.stats.beta * Math.log(1.1) * 100).toFixed(1)} vol pts` : undefined} hint="Slope of daily ATM-vol changes on daily log returns of the future" />
            <Tile k="R² changes" v={fmt(data.stats.changes.r2, 2)} />
            <Tile k="Beta, levels" v={fmt(data.stats.levels.slope)} hint="Slope of vol level on the future level" />
            <Tile k="Spot-vol corr" v={fmt(data.stats.rho, 2)} />
            <Tile k="Kappa" v={fmt(data.stats.ou.kappa, 2)} hint="Mean-reversion speed of log vol; sent to Monte Carlo" />
            <Tile k="Vol of vol" v={fmt(data.stats.ou.xi, 3)} hint="Sent to Monte Carlo" />
          </Tiles>
          <div className="grid gap-3 xl:grid-cols-3">
            <Panel title="Futures against 50d vol"><EChart option={scatterLevels(data)} /></Panel>
            <Panel title="Daily changes"><EChart option={scatterChanges(data)} /></Panel>
            <Panel title="Rolling beta"><EChart option={rolling(data)} /></Panel>
            <Panel title="Realised against implied"><EChart option={rvIv(data)} /></Panel>
            <Panel title="Smile through time"><EChart option={ridges(data)} /></Panel>
            <Panel title="Risk reversal against the future"><EChart option={rrChart(data)} /></Panel>
            <Panel
              title="Term structure"
              span={3}
              size="sm"
              right={<button className="btn !py-0 text-[11px]" disabled={curve.isFetching} onClick={() => curve.refetch()}>Load live curve</button>}
            >
              {curve.error ? <Empty>{(curve.error as Error).message}</Empty> : <EChart option={termChart(curve.data)} />}
            </Panel>
          </div>
        </>
      )}

      <h2 className="mb-2 mt-5 text-[13px] text-mute">Same month, other years</h2>
      <Toolbar
        actions={
          <button className="btn" disabled={analogs.isPending} onClick={() => analogs.mutate()}>
            {analogs.isPending ? "Loading…" : "Load analogs"}
          </button>
        }
      >
        <TextField label="Month code" value={month} onChange={setMonth} className="w-16" />
        <TextField label="Futures template" value={futureTemplate} onChange={setFutureTemplate} className="w-44" hint="{m} month code, {y} year digit" />
        <TextField label="Vol template" value={volTemplate} onChange={setVolTemplate} className="w-44" hint="Blank uses each contract's own 50-delta vol" />
        <TextField label="Years" value={years} onChange={setYears} className="w-44" />
      </Toolbar>
      {analogs.data?.errors.map((error) => <Problem key={error} warning={error} />)}
      {analogs.data && analogs.data.paths.length > 0 && (
        <Panel
          title="Percent move in the future, from the start of the window"
          right={
            <>
              {analogs.data.paths.map((path) => (
                <button key={path.year} className="btn !py-0 text-[11px]" disabled={!market?.slices[0]} onClick={() => setPoints(analogPoints(path, market?.slices[0]))} title="Use this year as the path in the Path lab">
                  {path.year}
                </button>
              ))}
              <button className="btn !py-0 text-[11px]" disabled={!market?.slices[0]} onClick={() => dropAnalogs(analogs.data!.paths, market?.slices[0], setGhosts)}>
                Drop all onto Path
              </button>
            </>
          }
        >
          <EChart option={analogChart(analogs.data.paths)} />
        </Panel>
      )}
    </Page>
  );
}

function analogPoints(
  path: AnalogPath,
  slice: { forward: number; pillars: { "50D"?: number } } | undefined,
): ControlPoint[] {
  if (!slice?.pillars["50D"]) return [];
  const atm = slice.pillars["50D"];
  const usable = path.points.filter((p) => p.vol_pts != null);
  if (usable.length < 2) return [];
  const step = Math.max(1, Math.floor(usable.length / 7));
  const picked = usable.filter((_, i) => i % step === 0);
  if (picked[picked.length - 1] !== usable[usable.length - 1]) picked.push(usable[usable.length - 1]);
  return picked.map((point, i) => ({
    id: `${path.year}-${i}`,
    spot: slice.forward * (1 + point.futures_pct),
    vol: Math.max(0.01, atm + (point.vol_pts ?? 0)),
    t: i / (picked.length - 1),
    tUser: false,
  }));
}

function termChart(data: Snapshot | undefined): EChartsOption {
  const contracts = data?.contracts ?? [];
  if (!contracts.length) {
    return { title: { text: "Load the live curve to see forwards and 50d vol by expiry.", left: "center", top: "middle", textStyle: { color: "#8d938c", fontSize: 12, fontWeight: 400 } } };
  }
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 48, right: 48, top: 28, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: contracts.map((c) => c.month) },
    yAxis: [
      { type: "value", ...axis(), name: "Future" },
      { type: "value", ...axis(), name: "Vol", axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v * 100)) }, splitLine: { show: false } },
    ],
    series: [
      { name: "Future", type: "line", showSymbol: false, data: contracts.map((c) => c.forward), lineStyle: { color: accent } },
      { name: "50d", type: "line", yAxisIndex: 1, showSymbol: false, data: contracts.map((c) => c.pillars["50D"]?.vol ?? null), lineStyle: { color: warn } },
    ],
  };
}

function dropAnalogs(
  paths: AnalogPath[],
  slice: { forward: number; pillars: { "50D"?: number } } | undefined,
  setGhosts: (paths: { spot: number; vol: number }[][]) => void,
) {
  if (!slice?.pillars["50D"]) return;
  const atm = slice.pillars["50D"];
  setGhosts(
    paths
      .filter((path) => path.points.some((p) => p.vol_pts != null))
      .map((path) =>
        path.points
          .filter((p) => p.vol_pts != null)
          .map((p) => ({ spot: slice.forward * (1 + p.futures_pct), vol: atm + (p.vol_pts ?? 0) })),
      ),
  );
}

function TextField({ label, value, onChange, type = "text", className = "", hint }: { label: string; value: string; onChange: (v: string) => void; type?: string; className?: string; hint?: string }) {
  return (
    <Field label={label} hint={hint}>
      <input className={`w-full ${className}`} type={type} value={value} onChange={(e) => onChange(e.target.value)} />
    </Field>
  );
}

function fmt(value: number | null | undefined, digits = 3) {
  if (value == null || !Number.isFinite(value)) return "—";
  return value.toFixed(digits);
}

function shiftYears(iso: string, years: number) {
  const date = new Date(iso);
  date.setFullYear(date.getFullYear() + years);
  return date.toISOString().slice(0, 10);
}

function scatterLevels(data: HistResult): EChartsOption {
  return {
    tooltip,
    grid: { left: 48, right: 12, top: 16, bottom: 32 },
    xAxis: { type: "value", ...axis(), name: "Future" },
    yAxis: { type: "value", ...axis(), name: "Vol pts", axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v * 100)) } },
    visualMap: {
      show: false,
      dimension: 2,
      min: 0,
      max: Math.max(data.points.length - 1, 1),
      inRange: { color: ["#3d4c4c", accent, warn] },
    },
    series: [{
      type: "scatter",
      symbolSize: 6,
      data: data.points.map((p, i) => [p.futures, p.atm, i]),
    }],
  };
}

function scatterChanges(data: HistResult): EChartsOption {
  const xs: number[] = [];
  const ys: number[] = [];
  for (let i = 1; i < data.points.length; i++) {
    const prev = data.points[i - 1];
    const cur = data.points[i];
    xs.push(Math.log(cur.futures / prev.futures));
    ys.push(cur.atm - prev.atm);
  }
  const fit = data.stats.changes;
  const line = fit.slope == null || fit.intercept == null ? [] : [Math.min(...xs), Math.max(...xs)].map((x) => [x, fit.intercept! + fit.slope! * x]);
  return {
    tooltip,
    grid: { left: 48, right: 12, top: 16, bottom: 32 },
    xAxis: { type: "value", ...axis(), name: "Log return" },
    yAxis: { type: "value", ...axis(), name: "Δ vol" },
    series: [
      { type: "scatter", symbolSize: 4, itemStyle: { color: warn, opacity: 0.7 }, data: xs.map((x, i) => [x, ys[i]]) },
      { type: "line", showSymbol: false, lineStyle: { color: accent }, data: line },
    ],
  };
}

function rolling(data: HistResult): EChartsOption {
  const dates = data.points.map((p) => p.date);
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 48, right: 48, top: 28, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: dates },
    yAxis: [{ type: "value", ...axis(), name: "Beta" }, { type: "value", ...axis(), name: "R²", max: 1, splitLine: { show: false } }],
    series: [
      { name: "Beta", type: "line", showSymbol: false, data: data.stats.rolling_slope, lineStyle: { color: accent } },
      { name: "R²", type: "line", showSymbol: false, yAxisIndex: 1, data: data.stats.rolling_r2, lineStyle: { color: warn } },
    ],
  };
}

function rvIv(data: HistResult): EChartsOption {
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 48, right: 12, top: 28, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: data.points.map((p) => p.date) },
    yAxis: { type: "value", ...axis(), axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v * 100)) } },
    series: [
      { name: "Implied", type: "line", showSymbol: false, data: data.points.map((p) => p.atm), lineStyle: { color: accent } },
      { name: "Realised", type: "line", showSymbol: false, data: data.stats.realised_vol, lineStyle: { color: warn } },
      {
        name: "VRP",
        type: "bar",
        data: data.stats.vol_risk_premium.map((value) => ({
          value,
          itemStyle: { color: (value ?? 0) >= 0 ? up : down },
        })),
      },
    ],
  };
}

function ridges(data: HistResult): EChartsOption {
  const has = PILLARS.some((name) => data.points.some((p) => p.pillars[name] != null));
  if (!has) {
    return { title: { text: "Add pillar tickers to see the smile.", left: "center", top: "middle", textStyle: { color: "#8d938c", fontSize: 12, fontWeight: 400 } } };
  }
  const step = Math.max(1, Math.floor(data.points.length / 6));
  const picked = data.points.filter((_, i) => i % step === 0);
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 40, right: 12, top: 28, bottom: 28 },
    xAxis: { type: "category", ...axis(), data: ["10c", "25c", "50", "25p", "10p"] },
    yAxis: { type: "value", ...axis() },
    series: picked.map((point) => ({
      name: point.date,
      type: "line" as const,
      showSymbol: true,
      data: PILLARS.map((name) => (name === "50D" ? point.atm : point.pillars[name]) == null ? null : ((name === "50D" ? point.atm : point.pillars[name]) as number) * 100),
    })),
  };
}

function rrChart(data: HistResult): EChartsOption {
  if (!data.points.some((p) => p.rr != null)) {
    return { title: { text: "Add a 25 delta risk-reversal ticker.", left: "center", top: "middle", textStyle: { color: "#8d938c", fontSize: 12, fontWeight: 400 } } };
  }
  return {
    tooltip,
    grid: { left: 48, right: 12, top: 16, bottom: 32 },
    xAxis: { type: "value", ...axis(), name: "Future" },
    yAxis: { type: "value", ...axis(), name: "RR" },
    series: [{ type: "scatter", symbolSize: 5, itemStyle: { color: warn }, data: data.points.filter((p) => p.rr != null).map((p) => [p.futures, (p.rr ?? 0) * 100]) }],
  };
}

function analogChart(paths: AnalogPath[]): EChartsOption {
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 48, right: 12, top: 28, bottom: 28 },
    xAxis: { type: "value", ...axis(), name: "Sessions" },
    yAxis: { type: "value", ...axis(), name: "%" },
    series: paths.map((path) => ({
      name: String(path.year),
      type: "line" as const,
      showSymbol: false,
      data: path.points.map((p) => [p.sessions, p.futures_pct * 100]),
    })),
  };
}
