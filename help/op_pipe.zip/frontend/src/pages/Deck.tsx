import { useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { EChart } from "../components/charts/EChart";
import { Field, Gate, Segmented, Toolbar } from "../components/ui";
import { postJson, postSse } from "../model/api";
import { pct, px, signed, volPts } from "../model/format";
import type { BacktestResult } from "../model/history";
import { BACKTEST_DEFAULTS, backtestQuery, breakevenQuery } from "../model/queries";
import { marketReady, toLegs, toMarketIn, type PriceResult } from "../model/types";
import { useLab } from "../store/lab";

const PROPOSAL_BLOCK = /```json[\s\S]*?```/g;
const PAPER_AXIS = {
  axisLine: { lineStyle: { color: "#c9ced4" } },
  axisTick: { show: false },
  axisLabel: { color: "#6b7280", fontSize: 10 },
  splitLine: { lineStyle: { color: "#eef0f2" } },
  nameTextStyle: { color: "#6b7280", fontSize: 10 },
};

const SUMMARY_PROMPT =
  "Write the commentary for a one-page trade deck on the loaded structure. Price it, and run breakeven_vs_history and backtest_structure if a Bloomberg market is loaded. " +
  "Give: the thesis in one sentence, what it costs, where it makes and loses money, how history treated it, and the main risk. Under 160 words, no proposals block.";

export function Deck() {
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const regime = useLab((s) => s.regime);
  const followBeta = useLab((s) => s.followBeta);
  const [title, setTitle] = useState("");
  const [thesis, setThesis] = useState("");
  const [withHistory, setWithHistory] = useState(true);
  const [summary, setSummary] = useState("");
  const [summaryState, setSummaryState] = useState<"idle" | "busy" | "error">("idle");
  const abortRef = useRef<AbortController | null>(null);
  const ready = marketReady(market) && legs.length > 0;
  const fromBbg = ready && !!market.source;

  const price = useQuery({
    queryKey: ["price", market, legs, regime, followBeta],
    enabled: ready,
    queryFn: () => postJson<PriceResult>("/api/structures/price", { market: toMarketIn(market!), legs: toLegs(legs), regime, follow_beta: followBeta }),
  });
  const backtest = useQuery({ ...backtestQuery(market!, legs, regime), enabled: fromBbg && withHistory });
  const breakeven = useQuery({ ...breakevenQuery(market!, legs, regime, BACKTEST_DEFAULTS.years), enabled: fromBbg && withHistory });

  const p = price.data;
  const payoff = useMemo(() => payoffChart(p), [p]);
  const equity = useMemo(() => equityChart(backtest.data), [backtest.data]);

  async function writeSummary() {
    if (!ready) return;
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setSummary("");
    setSummaryState("busy");
    try {
      await postSse("/api/copilot/chat", {
        messages: [{ role: "user", content: SUMMARY_PROMPT + (thesis.trim() ? ` The PM's thesis: ${thesis.trim()}` : "") }],
        market: toMarketIn(market!),
        legs: toLegs(legs),
        mode: "chat",
        regime,
        product: market!.source?.product ?? null,
        contract: market!.source?.contracts[0] ?? null,
        page: "Deck",
        context: null,
      }, (event, data) => {
        if (event === "text") setSummary((s) => s + String(data.delta ?? ""));
        if (event === "error") setSummaryState("error");
      }, controller.signal);
      setSummaryState((s) => (s === "busy" ? "idle" : s));
    } catch {
      setSummaryState("error");
    }
  }

  if (!ready) {
    return <Gate title="Turn the loaded structure into a one-page deck." text="Find a market and build legs in the Builder, then come back here to print or save as PDF." />;
  }

  const source = market!.source;
  const unit = market!.currency;
  const spots = p ? [...new Set(p.ladder.map((r) => r.spot_pct))] : [];
  const vols = p ? [...new Set(p.ladder.map((r) => r.vol_pts))] : [];
  const cell = (s: number, v: number) => p?.ladder.find((r) => r.spot_pct === s && r.vol_pts === v)?.pnl ?? null;
  const bt = backtest.data?.metrics;
  const be = breakeven.data;

  return (
    <div className="print-flow h-full overflow-auto p-3">
      <div className="print:hidden">
        <Toolbar
          actions={
            <>
              <button className="btn" disabled={summaryState === "busy"} onClick={writeSummary}>
                {summaryState === "busy" ? "Writing…" : summary ? "Rewrite commentary" : "Copilot commentary"}
              </button>
              <button className="btn btn-primary" onClick={() => window.print()}>Print / PDF</button>
            </>
          }
        >
          <Field label="Title">
            <input className="w-64" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={source?.description ?? "Structure"} />
          </Field>
          <Field label="Thesis" className="min-w-[320px] flex-1">
            <input className="w-full max-w-xl" value={thesis} onChange={(e) => setThesis(e.target.value)} placeholder="Why this trade, in a sentence" />
          </Field>
          <Field label="History" hint={fromBbg ? "Include the backtest and breakeven section" : "Needs a Bloomberg market"}>
            <Segmented value={withHistory && fromBbg ? "on" : "off"} disabled={!fromBbg} onChange={(v) => setWithHistory(v === "on")} options={[{ value: "off", label: "Off" }, { value: "on", label: "On" }]} />
          </Field>
        </Toolbar>
      </div>

      <article className="deck mx-auto max-w-[900px] rounded-sm p-8 text-[12px] shadow-lg">
        <header className="deck-section flex items-start justify-between border-b border-[#e3e5e8] pb-3">
          <div>
            <h1 className="text-[20px] font-medium">{title || source?.description || "Structure"}</h1>
            <p className="muted mt-1">
              {source?.labels.join(" / ") ?? market!.slices.map((s) => s.expiry).join(" / ")} · forward {px(market!.slices[0].forward)} · ATM {volPts(market!.slices[0].pillars["50D"])} · {regime}
            </p>
            {thesis && <p className="mt-2 text-[13px]">{thesis}</p>}
          </div>
          <div className="muted text-right">
            <div>As of {market!.asOf}</div>
            <div>Options Structure Lab</div>
          </div>
        </header>

        {p && (
          <section className="deck-section mt-4 grid grid-cols-[1.1fr_1fr] gap-6">
            <div>
              <h3 className="mb-1 text-[13px] font-medium">Legs</h3>
              <table className="w-full tabular-nums">
                <thead className="muted">
                  <tr><th className="text-left font-normal">Leg</th><th className="text-right font-normal">Strike</th><th className="text-right font-normal">Expiry</th><th className="text-right font-normal">Vol</th><th className="text-right font-normal">Premium</th></tr>
                </thead>
                <tbody>
                  {p.legs.map((leg, i) => (
                    <tr key={i}>
                      <td>{leg.qty > 0 ? "Buy" : "Sell"} {Math.abs(leg.qty)} {leg.call_put === "C" ? "call" : "put"}</td>
                      <td className="text-right">{px(leg.strike)}</td>
                      <td className="text-right">{leg.expiry}</td>
                      <td className="text-right">{volPts(leg.vol)}</td>
                      <td className="text-right">{signed(leg.premium)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <h3 className="mb-1 mt-4 text-[13px] font-medium">Risk, {unit}</h3>
              <div className="grid grid-cols-4 gap-y-2 tabular-nums">
                <Kv k="Premium" v={signed(p.premium)} />
                <Kv k="Delta" v={px(p.delta, 3)} />
                <Kv k="Vega / pt" v={px(p.vega_point, 2)} />
                <Kv k="Theta / day" v={signed(p.theta_day, 2)} />
                <Kv k="Max gain" v={p.unlimited_gain ? "Unlimited" : signed(p.max_gain)} />
                <Kv k="Max loss" v={p.unlimited_loss ? "Unlimited" : signed(p.max_loss)} />
                <Kv k="P(profit)" v={p.pop == null ? "—" : pct(p.pop, 0)} />
                <Kv k="Breakevens" v={p.breakevens.length ? p.breakevens.map((b) => px(b)).join(", ") : "—"} />
              </div>
            </div>
            <div className="h-60">
              <h3 className="mb-1 text-[13px] font-medium">P&L against the forward</h3>
              <EChart option={payoff} height="calc(100% - 20px)" />
            </div>
          </section>
        )}

        {p && (
          <section className="deck-section mt-4">
            <h3 className="mb-1 text-[13px] font-medium">Scenario P&L today, {unit}: spot move across, ATM vol change down</h3>
            <table className="w-full tabular-nums">
              <thead className="muted">
                <tr>
                  <th className="text-left font-normal">Vol</th>
                  {spots.map((s) => <th key={s} className="text-right font-normal">{signed(s * 100, 0)}%</th>)}
                </tr>
              </thead>
              <tbody>
                {vols.map((v) => (
                  <tr key={v}>
                    <td className="muted">{signed(v * 100, 0)} pts</td>
                    {spots.map((s) => {
                      const value = cell(s, v);
                      return <td key={s} className={`text-right ${value == null ? "" : value >= 0 ? "pos" : "neg"}`}>{value == null ? "—" : signed(value, 0)}</td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        )}

        {withHistory && fromBbg && (
          <section className="deck-section mt-4 grid grid-cols-[1fr_1fr] gap-6">
            <div>
              <h3 className="mb-1 text-[13px] font-medium">History on the generic</h3>
              {(backtest.isPending || breakeven.isPending) && <p className="muted">Loading history…</p>}
              {(backtest.error || breakeven.error) && <p className="neg">{((backtest.error ?? breakeven.error) as Error).message}</p>}
              <div className="grid grid-cols-3 gap-y-2 tabular-nums">
                {be?.breakevens.map((b) => (
                  <Kv key={b.price} k={`Reached ${b.direction === "up" ? "upper" : "lower"} BE`} v={pct(b.hist_prob_beyond, 0)} />
                ))}
                {be && <Kv k="Realised, median" v={volPts(be.realised.median)} />}
                {be && <Kv k="Implied − realised" v={volPts(be.realised.mean_iv_minus_rv)} />}
                {bt && <Kv k="Monthly rolls" v={String(bt.n)} />}
                {bt && <Kv k="Hit rate" v={pct(bt.hit_rate, 0)} />}
                {bt && <Kv k={`Mean, ${unit}`} v={signed(bt.mean, 0)} />}
                {bt && <Kv k="Worst" v={signed(bt.worst, 0)} />}
                {bt && <Kv k="Max drawdown" v={signed(bt.max_drawdown, 0)} />}
              </div>
              {backtest.data && <p className="muted mt-2 text-[10px]">{backtest.data.assumptions.join(" ")}</p>}
            </div>
            <div className="h-48">
              {backtest.data && <EChart option={equity} height="100%" />}
            </div>
          </section>
        )}

        {(summary || summaryState === "busy") && (
          <section className="deck-section mt-4 border-t border-[#e3e5e8] pt-3">
            <h3 className="mb-1 text-[13px] font-medium">Commentary</h3>
            {summaryState === "busy" && !summary && <p className="muted">Pricing and writing…</p>}
            <div className="copilot-md">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{summary.replace(PROPOSAL_BLOCK, "").trim()}</ReactMarkdown>
            </div>
            {summaryState === "error" && <p className="neg">The copilot did not finish.</p>}
          </section>
        )}

        <footer className="muted mt-6 border-t border-[#e3e5e8] pt-2 text-[10px]">
          Model values from Black-76 on the fitted smile as of {market!.asOf}. Indicative only, not an offer.
        </footer>
      </article>
    </div>
  );
}

function Kv({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="muted text-[10px]">{k}</div>
      <div>{v}</div>
    </div>
  );
}

function payoffChart(data: PriceResult | undefined): EChartsOption {
  if (!data) return {};
  const today = data.frames.find((f) => f.life_fraction === 0);
  return {
    animation: false,
    legend: { top: 0, textStyle: { color: "#6b7280", fontSize: 10 } },
    grid: { left: 52, right: 8, top: 24, bottom: 24 },
    xAxis: { type: "value", ...PAPER_AXIS, scale: true },
    yAxis: { type: "value", ...PAPER_AXIS },
    series: [
      ...(data.payoff ? [{ name: "At expiry", type: "line" as const, showSymbol: false, lineStyle: { color: "#1f6aa5", width: 2 }, data: data.payoff.spots.map((s, i) => [s, data.payoff!.pnl[i]]) }] : []),
      ...(today ? [{ name: "Today", type: "line" as const, showSymbol: false, lineStyle: { color: "#e08a2e", width: 1.5 }, data: today.spots.map((s, i) => [s, today.value[i] - data.premium]) }] : []),
    ],
  };
}

function equityChart(bt: BacktestResult | undefined): EChartsOption {
  if (!bt) return {};
  return {
    animation: false,
    grid: { left: 56, right: 8, top: 12, bottom: 24 },
    xAxis: { type: "category", ...PAPER_AXIS, data: bt.equity.dates },
    yAxis: { type: "value", ...PAPER_AXIS },
    series: [{ type: "line", showSymbol: false, data: bt.equity.pnl, lineStyle: { color: "#1f6aa5", width: 1.5 }, areaStyle: { color: "#1f6aa5", opacity: 0.08 } }],
  };
}
