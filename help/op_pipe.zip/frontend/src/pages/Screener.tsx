import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useMemo, useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, mute, pnlVisualMap, tooltip, warn } from "../components/charts/theme";
import { Empty, Freshness, Gate, Loading, Note, Page, Panel, Problem, Td, Th, Tile, Tiles, Toolbar } from "../components/ui";
import { fetchSmile } from "../model/chain";
import { downloadText, toCsv } from "../model/export";
import { pct, px, signed, volPts } from "../model/format";
import { MONTH_NAMES, type ScreenerRow, type SeasonalityResult, type SkewSlopeResult } from "../model/history";
import { screenerQuery, seasonalityQuery, skewSlopeQuery } from "../model/queries";
import type { Pillar } from "../model/types";
import { useLab } from "../store/lab";

const CHANGES: { key: keyof ScreenerRow; label: string }[] = [
  { key: "chg_1d", label: "1d" },
  { key: "chg_1w", label: "1w" },
  { key: "chg_1m", label: "1m" },
];

export function Screener() {
  const market = useLab((s) => s.market);
  const askCopilot = useLab((s) => s.askCopilot);
  const setScreen = useLab((s) => s.setScreen);
  const client = useQueryClient();
  const product = market?.source?.product;
  const contract = market?.source?.contracts[0];
  const [recording, setRecording] = useState<string | null>(null);

  const screen = useQuery({ ...screenerQuery(product ?? ""), enabled: !!product });
  const skew = useQuery({ ...skewSlopeQuery(contract ?? ""), enabled: !!contract });
  const season = useQuery({ ...seasonalityQuery(contract ?? ""), enabled: !!contract });

  const rows = screen.data?.rows ?? [];
  useEffect(() => {
    if (!rows.length && !skew.data && !season.data) return;
    setScreen("Screener", {
      product,
      curve: rows.map(({ pillar_change: _p, ...row }) => row),
      skew_slope: skew.data?.stats ?? null,
      seasonality: season.data ? { months: season.data.months, current: season.data.current } : null,
    });
  }, [rows, skew.data, season.data, product, setScreen]);

  const changeOption = useMemo(() => changeHeat(rows), [rows]);
  const pillarOption = useMemo(() => pillarHeat(rows), [rows]);
  const skewOption = useMemo(() => skewChart(skew.data), [skew.data]);
  const seasonOption = useMemo(() => seasonChart(season.data), [season.data]);
  const hasPillars = rows.some((r) => r.pillar_change);

  async function recordSmiles() {
    for (const row of rows) {
      setRecording(row.label);
      try {
        await fetchSmile(row.contract);
      } catch {
        /* contracts without a usable chain are skipped */
      }
    }
    setRecording(null);
    if (product) client.fetchQuery(screenerQuery(product, true));
  }

  if (!product) {
    return <Gate title="Screen a product's vol curve." text="Find a market first. The screener lists every expiry of its product and ranks them against realised, history and season." />;
  }

  const front = rows[0];
  const richest = rows.reduce<ScreenerRow | null>((best, r) => (r.iv_minus_rv != null && (best?.iv_minus_rv == null || r.iv_minus_rv > best.iv_minus_rv) ? r : best), null);
  const cheapest = rows.reduce<ScreenerRow | null>((best, r) => (r.iv_minus_rv != null && (best?.iv_minus_rv == null || r.iv_minus_rv < best.iv_minus_rv) ? r : best), null);

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <button
              className="btn"
              disabled={!rows.length}
              onClick={() =>
                askCopilot({
                  mode: "chat",
                  prompt: "Read this vol screen. Which expiries look rich or cheap against realised, their own history and the seasonal norm, what is skew and slope saying, and which structures would express that?",
                  page: "Screener",
                })
              }
            >
              Explain
            </button>
            <button className="btn" disabled={!rows.length} onClick={() => downloadText("screener.csv", toCsv(rows.map(({ pillar_change: _p, ...r }) => r) as unknown as Record<string, unknown>[]))}>
              CSV
            </button>
            <button className="btn" disabled={!!recording || !rows.length} onClick={recordSmiles} title="Fit and store today's smile for every expiry so the pillar-change map and the Surface history fill in">
              {recording ? `Recording ${recording}…` : "Record smiles"}
            </button>
            <Freshness queries={[screen, skew, season]} />
            <button className="btn" disabled={screen.isFetching} onClick={() => client.fetchQuery(screenerQuery(product, true))}>
              {screen.isFetching ? "Loading…" : "Refresh"}
            </button>
          </>
        }
      >
        <span className="text-[14px]">{market?.source?.description ?? product}</span>
        <span className="text-mute">{rows.length ? `${rows.length} expiries` : ""}</span>
      </Toolbar>
      <Problem error={screen.error} warning={screen.data?.warning} />

      <Tiles>
        <Tile k={`Front ATM · ${front?.label ?? ""}`} v={volPts(front?.atm)} sub={front ? `${pct(front.atm_pct_1y, 0)} 1y pctile` : undefined} />
        <Tile k="Front IV − RV20" v={signed((front?.iv_minus_rv ?? NaN) * 100, 1)} tone={front?.iv_minus_rv == null ? "" : front.iv_minus_rv > 0 ? "down" : "up"} hint="Red: implied above realised" />
        <Tile k="Richest v realised" v={richest ? `${richest.label} ${signed(richest.iv_minus_rv! * 100, 1)}` : "—"} tone="down" />
        <Tile k="Cheapest v realised" v={cheapest ? `${cheapest.label} ${signed(cheapest.iv_minus_rv! * 100, 1)}` : "—"} tone="up" />
        <Tile k="Skew 110−90, 30d" v={volPts(skew.data?.stats.skew.current)} sub={skew.data ? `z ${px(skew.data.stats.skew.z, 1)} · ${pct(skew.data.stats.skew.percentile, 0)}` : undefined} hint="30-day 110% moneyness vol minus 90%, from Bloomberg's constant-maturity fields on the first generic. Positive: calls over puts." />
        <Tile k="Slope 60−30d" v={volPts(skew.data?.stats.slope.current)} sub={skew.data ? `z ${px(skew.data.stats.slope.z, 1)} · ${pct(skew.data.stats.slope.percentile, 0)}` : undefined} hint="60-day minus 30-day constant-maturity ATM" />
        <Tile k="30d ATM" v={volPts(skew.data?.stats.atm.current)} sub={skew.data ? `z ${px(skew.data.stats.atm.z, 1)} · ${pct(skew.data.stats.atm.percentile, 0)}` : undefined} hint="Constant-maturity 30-day ATM on the first generic, against its own history" />
      </Tiles>

      <div className="grid gap-3 xl:grid-cols-3">
        <Panel title="Expiries" span={2} size="lg" pad={false}>
          {screen.isPending ? (
            <Loading />
          ) : rows.length ? (
            <div className="h-full overflow-auto">
              <table className="blotter">
                <thead className="sticky top-0 bg-raised">
                  <tr>
                    <Th>Expiry</Th>
                    <Th right>Days</Th>
                    <Th right>Future</Th>
                    <Th right>ATM</Th>
                    <Th right hint="ATM change in vol points">Δ 1d</Th>
                    <Th right hint="ATM change in vol points">Δ 1w</Th>
                    <Th right hint="ATM change in vol points">Δ 1m</Th>
                    <Th right hint="20-session realised on that future">RV 20d</Th>
                    <Th right hint="Red: implied above realised">IV − RV</Th>
                    <Th right hint="Today's ATM within the contract's own last year">1y pctile</Th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.contract} className={row.contract === contract ? "text-accent" : ""}>
                      <Td mono={false}>{row.label}</Td>
                      <Td right>{row.days ?? "—"}</Td>
                      <Td right>{px(row.forward)}</Td>
                      <Td right>{volPts(row.atm)}</Td>
                      {CHANGES.map((c) => {
                        const v = row[c.key] as number | null;
                        return <Td key={c.key} right tone={v}>{v == null ? "—" : signed(v * 100, 1)}</Td>;
                      })}
                      <Td right>{volPts(row.rv20)}</Td>
                      <Td right tone={row.iv_minus_rv == null ? "" : row.iv_minus_rv > 0 ? "down" : "up"}>{row.iv_minus_rv == null ? "—" : signed(row.iv_minus_rv * 100, 1)}</Td>
                      <Td right>{pct(row.atm_pct_1y, 0)}</Td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <Empty>No expiries listed.</Empty>
          )}
        </Panel>
        <Panel title="ATM change by expiry, vol pts" size="lg">
          {rows.length ? <EChart option={changeOption} /> : <Empty />}
        </Panel>
        <Panel title={`Smile change by pillar${hasPillars ? `, since ${rows.find((r) => r.pillar_change_since)?.pillar_change_since}` : ""}`}>
          {hasPillars ? <EChart option={pillarOption} /> : <Empty>Needs a stored smile from today and an earlier day. Use Record smiles to store today's now.</Empty>}
        </Panel>
        <Panel title="Skew and slope on the generic, vol pts">
          {skew.isPending ? <Loading /> : skew.error ? <Empty>{(skew.error as Error).message}</Empty> : <EChart option={skewOption} />}
        </Panel>
        <Panel title="30d ATM by calendar month">
          {season.isPending ? <Loading /> : season.error ? <Empty>{(season.error as Error).message}</Empty> : <EChart option={seasonOption} />}
        </Panel>
      </div>
      <Note>
        Changes are in vol points. IV − RV compares each expiry's ATM with 20-session realised on its own future. Skew and slope use Bloomberg's constant-maturity fields on the first generic; seasonality averages 30-day ATM and 20-day realised by calendar month, with this year dashed.
      </Note>
    </Page>
  );
}

function changeHeat(rows: ScreenerRow[]): EChartsOption {
  if (!rows.length) return {};
  const data: [number, number, number | null][] = [];
  rows.forEach((row, y) => CHANGES.forEach((c, x) => {
    const v = row[c.key] as number | null;
    data.push([x, y, v == null ? null : v * 100]);
  }));
  const span = Math.max(1, ...data.map((d) => Math.abs(d[2] ?? 0)));
  return heat(data, CHANGES.map((c) => c.label), rows.map((r) => r.label), span);
}

function pillarHeat(rows: ScreenerRow[]): EChartsOption {
  const shown = rows.filter((r) => r.pillar_change);
  if (!shown.length) return {};
  const names: Pillar[] = ["10DP", "25DP", "50D", "25DC", "10DC"];
  const data: [number, number, number | null][] = [];
  shown.forEach((row, y) => names.forEach((name, x) => {
    const v = row.pillar_change?.[name];
    data.push([x, y, v == null ? null : v * 100]);
  }));
  const span = Math.max(1, ...data.map((d) => Math.abs(d[2] ?? 0)));
  return heat(data, ["10P", "25P", "ATM", "25C", "10C"], shown.map((r) => r.label), span);
}

function heat(data: [number, number, number | null][], xs: string[], ys: string[], span: number): EChartsOption {
  return {
    tooltip: { ...tooltip, formatter: (p: unknown) => {
      const d = (p as { data: [number, number, number | null] }).data;
      return `${ys[d[1]]} ${xs[d[0]]}: ${d[2] == null ? "—" : d[2].toFixed(2)} pts`;
    } },
    grid: { left: 96, right: 12, top: 8, bottom: 24 },
    xAxis: { type: "category", ...axis(), data: xs, splitArea: { show: false } },
    yAxis: { type: "category", ...axis(), data: ys, inverse: true },
    visualMap: pnlVisualMap(span),
    series: [{
      type: "heatmap",
      data,
      label: { show: true, color: "#e4e1d8", fontSize: 10, formatter: (p: { data: [number, number, number | null] }) => (p.data[2] == null ? "" : p.data[2].toFixed(1)) },
    }],
  } as EChartsOption;
}

function skewChart(data: SkewSlopeResult | undefined): EChartsOption {
  if (!data) return {};
  const pts = (series: (number | null)[]) => series.map((v) => (v == null ? null : v * 100));
  return {
    tooltip: { ...tooltip, trigger: "axis" },
    legend: { textStyle: { color: mute, fontSize: 10 }, top: 0 },
    grid: { left: 40, right: 12, top: 28, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: data.dates },
    yAxis: { type: "value", ...axis() },
    series: [
      { name: "Skew 110−90", type: "line", showSymbol: false, data: pts(data.series.skew), lineStyle: { color: warn, width: 1 } },
      { name: "Slope 60−30", type: "line", showSymbol: false, data: pts(data.series.slope), lineStyle: { color: accent, width: 1 } },
    ],
  };
}

function seasonChart(data: SeasonalityResult | undefined): EChartsOption {
  if (!data) return {};
  const years = Object.keys(data.years).sort();
  const latest = years[years.length - 1];
  return {
    tooltip: { ...tooltip, trigger: "axis" },
    legend: { textStyle: { color: mute, fontSize: 10 }, top: 0, type: "scroll" },
    grid: { left: 40, right: 12, top: 28, bottom: 28 },
    xAxis: { type: "category", ...axis(), data: MONTH_NAMES },
    yAxis: { type: "value", ...axis(), axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v * 100)) } },
    series: [
      { name: "Range", type: "line", stack: "range", showSymbol: false, lineStyle: { opacity: 0 }, data: data.months.map((m) => m.iv_min), tooltip: { show: false } },
      { name: "Range", type: "line", stack: "range", showSymbol: false, lineStyle: { opacity: 0 }, areaStyle: { color: accent, opacity: 0.1 }, data: data.months.map((m) => (m.iv_max == null || m.iv_min == null ? null : m.iv_max - m.iv_min)), tooltip: { show: false } },
      { name: "Implied, avg", type: "line", data: data.months.map((m) => m.iv_mean), lineStyle: { color: accent, width: 2 }, symbolSize: 4 },
      { name: "Realised, avg", type: "line", data: data.months.map((m) => m.rv_mean), lineStyle: { color: warn, width: 1.5 }, symbolSize: 4 },
      ...(latest ? [{ name: latest, type: "line" as const, data: data.years[latest], lineStyle: { color: "#e4e1d8", width: 1, type: "dashed" as const }, symbolSize: 3 }] : []),
    ],
  } as EChartsOption;
}
