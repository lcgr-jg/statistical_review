import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Fragment, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Empty, Field, Page, Panel, Problem, Segmented, Td, Th } from "../components/ui";
import { postJson } from "../model/api";
import { fetchSmile, sliceFromSmile } from "../model/chain";
import { downloadText, toCsv } from "../model/export";
import { px, signed, volPts } from "../model/format";
import type { JournalEntry, ParsedQuote } from "../model/history";
import { uid } from "../model/id";
import { addEntry, auditQuery, commentOn, deleteEntry, describeEvent, journalQuery, marketFor, patchEntry } from "../model/journal";
import type { Leg, Market } from "../model/types";
import { useLab } from "../store/lab";

const STATUSES = ["open", "done", "passed", "expired"];
const when = (iso: string) => iso.slice(0, 16).replace("T", " ");

export function Journal() {
  const market = useLab((s) => s.market);
  const regime = useLab((s) => s.regime);
  const setMarket = useLab((s) => s.setMarket);
  const setLegs = useLab((s) => s.setLegs);
  const askCopilot = useLab((s) => s.askCopilot);
  const setScreen = useLab((s) => s.setScreen);
  const navigate = useNavigate();
  const client = useQueryClient();
  const [text, setText] = useState("");
  const [product, setProduct] = useState(market?.source?.product ?? "");
  const [kind, setKind] = useState<"all" | JournalEntry["kind"]>("all");
  const [view, setView] = useState<"entries" | "audit">("entries");
  const [tagFilter, setTagFilter] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const user = useLab((s) => s.userName);
  const setUserName = useLab((s) => s.setUserName);

  useEffect(() => {
    if (!product && market?.source?.product) setProduct(market.source.product);
  }, [market, product]);

  const parse = useMutation({
    mutationFn: () =>
      postJson<{ quotes: ParsedQuote[]; message?: string }>("/api/quotes/parse", {
        text,
        product: product.trim(),
        regime,
        rate: market?.rate ?? 0,
        multiplier: market?.multiplier ?? 1,
      }),
  });
  const journal = useQuery(journalQuery);
  const audit = useQuery({ ...auditQuery, enabled: view === "audit" });
  const refresh = () => {
    client.invalidateQueries({ queryKey: ["journal"] });
    client.invalidateQueries({ queryKey: ["journal-audit"] });
  };
  const add = useMutation({ mutationFn: (entry: Partial<JournalEntry>) => addEntry(entry, user), onSuccess: refresh });
  const update = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<JournalEntry> }) => patchEntry(id, patch, user),
    onSuccess: refresh,
  });
  const comment = useMutation({ mutationFn: ({ id, text }: { id: string; text: string }) => commentOn(id, text, user), onSuccess: refresh });
  const remove = useMutation({ mutationFn: (id: string) => deleteEntry(id, user), onSuccess: refresh });

  async function loadStructure(entry: JournalEntry) {
    setLoadError(null);
    try {
      const { market: next, legs } = await marketFor(entry);
      const strips = new Map<string, { id: string; label: string }>();
      const tagged: Leg[] = legs.map((leg, i) => {
        const label = entry.structure?.legs[i]?.strip;
        if (!label) return leg;
        if (!strips.has(label)) strips.set(label, { id: uid(), label });
        return { ...leg, strip: strips.get(label) };
      });
      setMarket({ ...next, multiplier: entry.structure?.multiplier ?? next.multiplier });
      setLegs(tagged);
      navigate("/");
    } catch (exc) {
      setLoadError((exc as Error).message);
    }
  }

  const quotes = parse.data?.quotes ?? [];
  useEffect(() => {
    if (!quotes.length) return;
    setScreen("Journal", {
      parsed_quotes: quotes.map((q) => ({
        label: q.label, legs: q.legs_in, bid: q.bid, offer: q.offer, size: q.size, model_price_per_unit: q.model_price,
        bid_minus_model: q.bid_edge, offer_minus_model: q.offer_edge, screen_atm: q.screen_atm, implied_atm_shift: q.implied_atm_shift, error: q.error,
      })),
    });
  }, [quotes, setScreen]);

  async function loadQuote(quote: ParsedQuote) {
    if (!quote.contracts?.length) return;
    setLoadError(null);
    try {
      const smiles = await Promise.all(quote.contracts.map((c) => fetchSmile(c)));
      const perLot = (market?.multiplier ?? 1) > 1;
      const next: Market = {
        asOf: smiles[0].as_of,
        rate: market?.rate ?? 0,
        multiplier: perLot ? smiles[0].multiplier ?? 1 : 1,
        currency: smiles[0].currency ?? market?.currency ?? "EUR",
        unit: smiles[0].unit ?? market?.unit ?? "",
        beta: market?.beta ?? null,
        slices: smiles.map((s) => sliceFromSmile(s)),
        source: { product: product.trim(), description: market?.source?.description, contracts: quote.contracts, labels: smiles.map((s) => s.label) },
      };
      setMarket(next);
      setLegs(quote.legs.map((leg) => ({ id: uid(), callPut: leg.call_put, qty: leg.qty, strikeMode: "absolute", strike: leg.strike, expiry: leg.expiry, vol: null })));
      navigate("/");
    } catch (exc) {
      setLoadError((exc as Error).message);
    }
  }

  function save(quote: ParsedQuote, as: JournalEntry["kind"]) {
    add.mutate({
      kind: as,
      label: quote.label,
      product: product.trim(),
      price: quote.mid ?? null,
      size: quote.size ?? null,
      side: quote.bid != null && quote.offer != null ? "two-way" : quote.bid != null ? "bid" : quote.offer != null ? "offer" : "",
      quote,
    });
  }

  const wanted = tagFilter.trim().toLowerCase().replace(/^#/, "");
  const entries = (journal.data?.entries ?? []).filter(
    (e) => (kind === "all" || e.kind === kind) && (!wanted || e.tags.some((t) => t.startsWith(wanted))),
  );
  const allTags = [...new Set((journal.data?.entries ?? []).flatMap((e) => e.tags))].sort();

  return (
    <Page>
      <Panel title="Broker quotes" size="auto" className="mb-3" right={<span className="text-[11px]">priced per unit on each contract's live smile, {regime}</span>}>
        <div className="grid gap-3 p-2 lg:grid-cols-[minmax(0,1fr)_220px]">
          <textarea
            className="h-28 w-full font-mono text-[12px]"
            placeholder={"Paste a run or chat, e.g.\nZ6 85/95 cs 1.20/1.35 x50 vs 80.5\nH7 70 puts 3.10 bid"}
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="space-y-2 text-[12px]">
            <Field label="Product">
              <input className="w-full" value={product} onChange={(e) => setProduct(e.target.value)} placeholder="FJSA Comdty" />
            </Field>
            <button className="btn btn-primary w-full" disabled={!text.trim() || !product.trim() || parse.isPending} onClick={() => parse.mutate()}>
              {parse.isPending ? "Reading and pricing…" : "Parse and price"}
            </button>
            <button
              className="btn w-full"
              disabled={!quotes.length}
              onClick={() =>
                askCopilot({
                  mode: "chat",
                  prompt: "Look at these parsed broker quotes against the model. Which are cheap or rich, what implied vol is each quote paying, and which would you act on?",
                  page: "Journal",
                })
              }
            >
              Explain
            </button>
          </div>
        </div>
      </Panel>
      <Problem error={parse.error ?? loadError} warning={parse.data?.message} />

      {quotes.length > 0 && (
        <div className="mb-3 grid gap-3 xl:grid-cols-2">
          {quotes.map((quote, i) => (
            <QuoteCard key={`${quote.label}-${i}`} quote={quote} onLoad={() => loadQuote(quote)} onSave={(as) => save(quote, as)} />
          ))}
        </div>
      )}

      <Panel
        title="Journal"
        size="auto"
        pad={false}
        right={
          <>
            <label className="flex items-center gap-1 text-[11px]" title="Stamped on every change and comment you make">
              You
              <input className={`w-24 ${user ? "" : "border-warn"}`} placeholder="your name" defaultValue={user} onBlur={(e) => setUserName(e.target.value)} />
            </label>
            <Segmented value={view} onChange={setView} options={[{ value: "entries", label: "Entries" }, { value: "audit", label: "Audit trail" }]} />
            {view === "entries" && (
              <>
                <Segmented value={kind} onChange={setKind} options={(["all", "quote", "trade", "idea"] as const).map((k) => ({ value: k, label: k }))} />
                <input className="w-28" list="journal-tags" placeholder="#tag" value={tagFilter} onChange={(e) => setTagFilter(e.target.value)} />
                <datalist id="journal-tags">{allTags.map((t) => <option key={t} value={t} />)}</datalist>
              </>
            )}
            <button
              className="btn !py-0 text-[11px]"
              disabled={view === "entries" ? !entries.length : !audit.data?.events.length}
              onClick={() =>
                view === "entries"
                  ? downloadText(
                      "journal.csv",
                      toCsv(
                        entries.map(({ quote, structure: _s, comments, history: _h, tags, ...e }) => ({
                          ...e,
                          tags: tags.join(" "),
                          model: quote?.model_price ?? null,
                          comments: comments.map((c) => `${when(c.at)} ${c.author}: ${c.text}`).join(" | "),
                        })) as unknown as Record<string, unknown>[],
                      ),
                    )
                  : downloadText("journal_audit.csv", toCsv((audit.data?.events ?? []).map((e) => ({ at: e.at, author: e.author, entry: e.label, change: describeEvent(e) }))))
              }
            >
              CSV
            </button>
          </>
        }
      >
        {journal.error && <Problem error={journal.error} />}
        {view === "audit" ? (
          <AuditTable events={audit.data?.events} error={audit.error} />
        ) : entries.length === 0 ? (
          <Empty>{wanted ? `Nothing tagged #${wanted}.` : "Nothing saved yet. Save a parsed quote, mark it as traded, or log a structure from the Builder."}</Empty>
        ) : (
          <table className="blotter">
            <thead>
              <tr>
                <Th>When</Th>
                <Th>Kind</Th>
                <Th>Structure</Th>
                <Th right>Price</Th>
                <Th right hint="Model price when the quote was parsed">Model then</Th>
                <Th right hint="Lots; negative when sold">Size</Th>
                <Th>Status</Th>
                <Th>Tags</Th>
                <Th>Notes</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {entries.map((entry) => (
                <Fragment key={entry.id}>
                  <tr className="align-top">
                    <Td className="text-mute">
                      {when(entry.created)}
                      {entry.author && <div className="text-[10px]">{entry.author}</div>}
                    </Td>
                    <Td mono={false}>{entry.kind}</Td>
                    <Td mono={false}>{entry.label}</Td>
                    <Td right>{px(entry.price ?? null, 3)}</Td>
                    <Td right>{px(entry.quote?.model_price ?? null, 3)}</Td>
                    <Td right>
                      <input
                        className="w-14 text-right"
                        type="number"
                        defaultValue={entry.size ?? ""}
                        onBlur={(e) => {
                          const size = e.target.value === "" ? null : Number(e.target.value);
                          if (size !== (entry.size ?? null)) update.mutate({ id: entry.id, patch: { size } });
                        }}
                      />
                    </Td>
                    <Td mono={false}>
                      <select value={entry.status} onChange={(e) => update.mutate({ id: entry.id, patch: { status: e.target.value } })}>
                        {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </Td>
                    <Td mono={false}>
                      <input
                        className="w-full min-w-[110px]"
                        placeholder="#tags"
                        defaultValue={entry.tags.map((t) => `#${t}`).join(" ")}
                        onBlur={(e) => {
                          const tags = e.target.value.replace(/#/g, " ").split(/[\s,]+/).filter(Boolean).map((t) => t.toLowerCase());
                          if (tags.join(" ") !== entry.tags.join(" ")) update.mutate({ id: entry.id, patch: { tags } });
                        }}
                      />
                    </Td>
                    <Td mono={false}>
                      <input
                        className="w-full min-w-[160px]"
                        defaultValue={entry.notes ?? ""}
                        onBlur={(e) => e.target.value !== (entry.notes ?? "") && update.mutate({ id: entry.id, patch: { notes: e.target.value } })}
                      />
                    </Td>
                    <Td right className="whitespace-nowrap">
                      <button
                        className={`btn ${openId === entry.id ? "text-accent" : ""}`}
                        onClick={() => setOpenId(openId === entry.id ? null : entry.id)}
                        title="Comments and change history"
                      >
                        {entry.comments.length ? `${entry.comments.length} comment${entry.comments.length > 1 ? "s" : ""}` : "History"}
                      </button>
                      {entry.structure ? (
                        <button className="btn ml-1" onClick={() => loadStructure(entry)}>Load</button>
                      ) : entry.quote?.contracts?.length ? (
                        <button className="btn ml-1" onClick={() => loadQuote(entry.quote!)}>Load</button>
                      ) : null}
                      <button className="btn ml-1" onClick={() => remove.mutate(entry.id)} title="Delete; it stays in the audit trail">✕</button>
                    </Td>
                  </tr>
                  {openId === entry.id && (
                    <tr>
                      <td colSpan={10} className="bg-sunken">
                        <EntryThread entry={entry} pending={comment.isPending} onComment={(text) => comment.mutate({ id: entry.id, text })} />
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        )}
        {(update.error || comment.error || remove.error) && <Problem error={update.error ?? comment.error ?? remove.error} />}
      </Panel>
    </Page>
  );
}

function EntryThread({ entry, pending, onComment }: { entry: JournalEntry; pending: boolean; onComment: (text: string) => void }) {
  const [text, setText] = useState("");
  const send = () => {
    if (!text.trim()) return;
    onComment(text);
    setText("");
  };
  return (
    <div className="grid gap-4 p-2 text-[12px] lg:grid-cols-2">
      <div>
        <div className="mb-1 text-[11px] text-mute">Comments</div>
        {entry.comments.length === 0 && <p className="text-mute">No comments yet.</p>}
        <ul className="space-y-1.5">
          {entry.comments.map((c) => (
            <li key={c.id}>
              <span className="text-mute">{when(c.at)} · {c.author}</span>
              <div className="whitespace-pre-wrap">{c.text}</div>
            </li>
          ))}
        </ul>
        <div className="mt-2 flex gap-1">
          <input
            className="min-w-0 flex-1"
            placeholder="Add a comment: fills, rationale, what changed"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
          />
          <button className="btn" disabled={pending || !text.trim()} onClick={send}>Comment</button>
        </div>
      </div>
      <div>
        <div className="mb-1 text-[11px] text-mute">History</div>
        <ul className="space-y-0.5 font-mono text-[11px]">
          {[...entry.history].reverse().map((e, i) => (
            <li key={i}>
              <span className="text-mute">{when(e.at)} {e.author}</span> {describeEvent(e)}
            </li>
          ))}
        </ul>
        {entry.structure && (
          <div className="mt-2 text-[11px] text-mute">
            Saved legs: {entry.structure.legs.map((l) => `${l.qty > 0 ? "+" : ""}${l.qty} ${l.call_put} ${px(l.strike)} ${l.expiry}${l.strip ? ` (${l.strip})` : ""}`).join(" · ")}
          </div>
        )}
      </div>
    </div>
  );
}

function AuditTable({ events, error }: { events?: JournalEntry["history"]; error: unknown }) {
  if (error) return <Problem error={error} />;
  if (!events) return <div className="skeleton m-2 h-16" />;
  if (!events.length) return <Empty>No changes recorded yet.</Empty>;
  return (
    <table className="blotter">
      <thead>
        <tr>
          <Th>When</Th>
          <Th>Who</Th>
          <Th>Entry</Th>
          <Th>Change</Th>
        </tr>
      </thead>
      <tbody>
        {events.map((e, i) => (
          <tr key={`${e.entry}-${i}`}>
            <Td className="text-mute">{when(e.at)}</Td>
            <Td mono={false}>{e.author}</Td>
            <Td mono={false}>{e.label ?? e.entry} <span className="text-mute">{e.kind}</span></Td>
            <Td mono={false} className={e.action === "deleted" ? "text-down" : ""}>{describeEvent(e)}</Td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function QuoteCard({ quote, onLoad, onSave }: { quote: ParsedQuote; onLoad: () => void; onSave: (as: JournalEntry["kind"]) => void }) {
  const impliedAtm = quote.screen_atm != null && quote.implied_atm_shift != null ? quote.screen_atm + quote.implied_atm_shift : null;
  return (
    <div className="panel p-3 text-[12px]">
      <div className="flex items-center gap-2">
        <span className="text-[13px] text-ink">{quote.label}</span>
        {quote.labels?.length ? <span className="text-mute">{quote.labels.join(" / ")}</span> : null}
        {quote.size != null && <span className="ml-auto text-mute">x{quote.size}</span>}
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        {quote.legs_in.map((leg, i) => (
          <span key={i} className="rounded border border-line px-1.5 py-0.5 font-mono">
            {leg.qty > 0 ? "+" : ""}{leg.qty} {leg.call_put} {leg.strike} {leg.contract}
          </span>
        ))}
      </div>
      {quote.error ? (
        <p className="mt-2 text-down">{quote.error}</p>
      ) : (
        <div className="mt-2 grid grid-cols-4 gap-2 tabular-nums">
          <Metric k="Bid" v={px(quote.bid ?? null, 3)} />
          <Metric k="Offer" v={px(quote.offer ?? null, 3)} />
          <Metric k="Model" v={px(quote.model_price ?? null, 3)} />
          <Metric k="Delta" v={px(quote.model_delta ?? null, 2)} />
          <Metric k="Bid − model" v={signed(quote.bid_edge ?? null, 3)} tone={quote.bid_edge == null ? "" : quote.bid_edge > 0 ? "up" : "down"} />
          <Metric k="Offer − model" v={signed(quote.offer_edge ?? null, 3)} tone={quote.offer_edge == null ? "" : quote.offer_edge < 0 ? "up" : "down"} />
          <Metric k="Screen ATM" v={volPts(quote.screen_atm ?? null)} />
          <Metric k="Quote's ATM" v={impliedAtm == null ? "—" : `${volPts(impliedAtm)} (${signed((quote.implied_atm_shift ?? 0) * 100, 1)})`} />
        </div>
      )}
      {quote.future_ref != null && !quote.error && (
        <p className="mt-2 text-mute">
          {quote.priced_at_ref
            ? `Model priced at the quoted reference ${px(quote.future_ref)} (screen future ${px(quote.forward ?? null)}).`
            : `Reference ${px(quote.future_ref)} is too far from the screen future ${px(quote.forward ?? null)} to use, so the model is on the screen.`}
        </p>
      )}
      {quote.notes && <p className="mt-2 text-warn">{quote.notes}</p>}
      <div className="mt-3 flex gap-2">
        <button className="btn" disabled={!!quote.error} onClick={onLoad}>Load into Builder</button>
        <button className="btn" onClick={() => onSave("quote")}>Save quote</button>
        <button className="btn" onClick={() => onSave("trade")}>Log as traded</button>
      </div>
    </div>
  );
}

function Metric({ k, v, tone = "" }: { k: string; v: string; tone?: string }) {
  return (
    <div>
      <div className="text-[11px] text-mute">{k}</div>
      <div className={tone}>{v}</div>
    </div>
  );
}
