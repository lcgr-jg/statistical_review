import { curveCatmullRom, line, scaleLinear, type ScaleLinear } from "d3";
import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import { uid } from "../../model/id";
import { likelyVol, type SpotVolFit } from "../../model/spotvol";
import type { ControlPoint, GhostPath } from "../../model/types";
import { pnlColor } from "../../components/charts/theme";

export type CanvasHandle = { exportPng: () => void };

type Sample = { t: number; spot: number; vol: number };

type Props = {
  forward: number;
  atm: number;
  remaining: number;
  spotMin: number;
  spotMax: number;
  volMin: number;
  volMax: number;
  spots: number[];
  vols: number[];
  pnl: number[][] | null;
  points: ControlPoint[];
  playhead: number;
  ghosts: GhostPath[];
  showDelta: boolean;
  showHistory: boolean;
  fit: SpotVolFit | null;
  pinStart: boolean;
  onChange: (points: ControlPoint[], record: boolean) => void;
  onSamples: (samples: Sample[]) => void;
};

const PAD = { l: 52, r: 16, t: 16, b: 40 };

const HALO = { stroke: "#101216", strokeWidth: 3, strokeLinejoin: "round" as const, paintOrder: "stroke" };
const LABEL = { ...HALO, fill: "#e4e1d8", fontSize: 12, fontFamily: "JetBrains Mono, monospace" };
const TITLE = { ...HALO, fill: "#e4e1d8", fontSize: 12, fontWeight: 500 };

export const SpotVolCanvas = forwardRef<CanvasHandle, Props>(function SpotVolCanvas(props, ref) {
  const frameRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [size, setSize] = useState({ w: 640, h: 640 });
  const live = useRef(props.points);
  const drag = useRef<{ index: number; recorded: boolean } | null>(null);
  live.current = props.points;

  useEffect(() => {
    const el = frameRef.current;
    if (!el) return;
    const observer = new ResizeObserver(() => {
      const rect = el.getBoundingClientRect();
      setSize({ w: Math.max(rect.width, 32), h: Math.max(rect.height, 32) });
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const x = scaleLinear().domain([props.spotMin, props.spotMax]).range([PAD.l, size.w - PAD.r]);
  const y = scaleLinear().domain([props.volMin, props.volMax]).range([size.h - PAD.b, PAD.t]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ratio = window.devicePixelRatio || 1;
    canvas.width = size.w * ratio;
    canvas.height = size.h * ratio;
    canvas.style.width = `${size.w}px`;
    canvas.style.height = `${size.h}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, size.w, size.h);
    ctx.fillStyle = "#101216";
    ctx.fillRect(0, 0, size.w, size.h);
    if (!props.pnl) return;
    const span = Math.max(...props.pnl.flat().map((v) => Math.abs(v)), 1e-6);
    const { spots, vols, pnl } = props;
    ctx.save();
    ctx.beginPath();
    ctx.rect(PAD.l, PAD.t, size.w - PAD.l - PAD.r, size.h - PAD.t - PAD.b);
    ctx.clip();
    for (let j = 0; j < vols.length; j++) {
      const y0 = edge(y, vols, j, -1);
      const y1 = edge(y, vols, j, 1);
      for (let i = 0; i < spots.length; i++) {
        const x0 = edge(x, spots, i, -1);
        const x1 = edge(x, spots, i, 1);
        ctx.fillStyle = heatColor(pnl[j][i], span);
        ctx.fillRect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0) + 0.6, Math.abs(y1 - y0) + 0.6);
      }
    }
    ctx.restore();
  }, [props, size, x, y]);

  const samples = curveSamples(props.points, x, y);
  useEffect(() => {
    props.onSamples(samples);
    // The parent stores samples for the pricer. Including props would refire every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(samples)]);

  useImperativeHandle(ref, () => ({
    exportPng() {
      const canvas = canvasRef.current;
      const svg = svgRef.current;
      if (!canvas || !svg) return;
      const xml = new XMLSerializer().serializeToString(svg);
      const image = new Image();
      const blob = new Blob([xml], { type: "image/svg+xml" });
      const url = URL.createObjectURL(blob);
      image.onload = () => {
        const out = document.createElement("canvas");
        out.width = canvas.width;
        out.height = canvas.height;
        const ctx = out.getContext("2d");
        if (!ctx) return;
        ctx.drawImage(canvas, 0, 0);
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
        const link = document.createElement("a");
        link.href = out.toDataURL("image/png");
        link.download = "path-lab.png";
        link.click();
        URL.revokeObjectURL(url);
      };
      image.src = url;
    },
  }));

  function local(event: React.PointerEvent) {
    const rect = svgRef.current!.getBoundingClientRect();
    return { sx: event.clientX - rect.left, sy: event.clientY - rect.top };
  }

  function hit(sx: number, sy: number) {
    return props.points.findIndex((p) => Math.hypot(x(p.spot) - sx, y(p.vol) - sy) < 9);
  }

  const d = props.points.length > 1
    ? line<ControlPoint>().x((p) => x(p.spot)).y((p) => y(p.vol)).curve(curveCatmullRom.alpha(0.5))(props.points)
    : null;
  const zero = props.pnl ? zeroContour(props.spots, props.vols, props.pnl, x, y) : "";
  const play = samples.reduce<(typeof samples)[number] | null>((best, item) => {
    if (!best || Math.abs(item.t - props.playhead) < Math.abs(best.t - props.playhead)) return item;
    return best;
  }, null);

  return (
    <div ref={frameRef} className="relative h-full w-full">
      <canvas ref={canvasRef} className="absolute inset-0" />
      <svg
        ref={svgRef}
        className="absolute inset-0"
        width={size.w}
        height={size.h}
        onPointerDown={(event) => {
          const pos = local(event);
          const index = hit(pos.sx, pos.sy);
          if (index >= 0) {
            drag.current = { index, recorded: false };
            (event.target as Element).setPointerCapture?.(event.pointerId);
          }
        }}
        onPointerMove={(event) => {
          if (!drag.current) return;
          const pos = local(event);
          const index = drag.current.index;
          const next = live.current.map((p, i) =>
            i === index
              ? { ...p, spot: x.invert(pos.sx), vol: Math.max(0.01, y.invert(pos.sy)), free: true }
              : p,
          );
          live.current = next;
          props.onChange(next, !drag.current.recorded);
          drag.current.recorded = true;
        }}
        onPointerUp={(event) => {
          if (drag.current) {
            drag.current = null;
            return;
          }
          const pos = local(event);
          if (pos.sx < PAD.l || pos.sy > size.h - PAD.b) return;
          const spot = x.invert(pos.sx);
          const vol = Math.max(0.01, y.invert(pos.sy));
          props.onChange(appendPoint(props.points, spot, vol, props.pinStart, props.forward, props.atm), true);
        }}
      >
        {x.ticks(5).map((tick) => (
          <g key={`x${tick}`}>
            <line x1={x(tick)} x2={x(tick)} y1={PAD.t} y2={size.h - PAD.b} stroke="#ffffff" strokeOpacity="0.14" />
            <text x={x(tick)} y={size.h - 16} textAnchor="middle" {...LABEL}>
              {tick.toFixed(1)}
            </text>
          </g>
        ))}
        {y.ticks(5).map((tick) => (
          <g key={`y${tick}`}>
            <line y1={y(tick)} y2={y(tick)} x1={PAD.l} x2={size.w - PAD.r} stroke="#ffffff" strokeOpacity="0.14" />
            <text x={PAD.l - 6} y={y(tick) + 4} textAnchor="end" {...LABEL}>
              {(tick * 100).toFixed(0)}
            </text>
          </g>
        ))}
        <text x={size.w / 2} y={size.h - 2} textAnchor="middle" {...TITLE}>Spot</text>
        <text x={14} y={size.h / 2} textAnchor="middle" {...TITLE} transform={`rotate(-90 14 ${size.h / 2})`}>Vol %</text>
        {zero && <path d={zero} fill="none" stroke="#e4e1d8" strokeOpacity="0.55" strokeDasharray="3 3" />}
        {props.showHistory && props.fit && (
          <HistoryBand
            fit={props.fit}
            forward={props.forward}
            atm={props.atm}
            spotMin={props.spotMin}
            spotMax={props.spotMax}
            x={x}
            y={y}
            width={size.w}
            height={size.h}
          />
        )}
        {props.showDelta && isoDeltas(props.forward, props.atm, props.remaining * (1 - props.playhead), props.vols, x, y)}
        <line x1={x(props.forward)} x2={x(props.forward)} y1={PAD.t} y2={size.h - PAD.b} stroke="#5ec8c5" strokeOpacity="0.35" />
        <line y1={y(props.atm)} y2={y(props.atm)} x1={PAD.l} x2={size.w - PAD.r} stroke="#5ec8c5" strokeOpacity="0.35" />
        {props.ghosts.map((path, i) => (
          <polyline
            key={i}
            fill="none"
            stroke="#8d938c"
            strokeOpacity="0.28"
            points={path.map((p) => `${x(p.spot)},${y(p.vol)}`).join(" ")}
          />
        ))}
        {samples.length > 1 &&
          samples.slice(1).map((item, i) => (
            <line
              key={i}
              x1={x(samples[i].spot)}
              y1={y(samples[i].vol)}
              x2={x(item.spot)}
              y2={y(item.vol)}
              stroke={mixColor(item.t)}
              strokeWidth="2"
            />
          ))}
        {monthTicks(samples, props.remaining).map((mark) => (
          <g key={mark.label}>
            <circle cx={x(mark.spot)} cy={y(mark.vol)} r="2.5" fill="#e4e1d8" />
            <text x={x(mark.spot) + 6} y={y(mark.vol) - 6} {...LABEL} fontWeight={600}>
              {mark.label}
            </text>
          </g>
        ))}
        {d && <path d={d} fill="none" stroke="none" />}
        {props.points.map((p) => (
          <circle key={p.id} cx={x(p.spot)} cy={y(p.vol)} r="5" fill="#14171c" stroke="#5ec8c5" strokeWidth="1.5" />
        ))}
        {play && <circle cx={x(play.spot)} cy={y(play.vol)} r="4" fill="#e4e1d8" />}
        <rect x={x(props.forward) - 4} y={y(props.atm) - 4} width="8" height="8" transform={`rotate(45 ${x(props.forward)} ${y(props.atm)})`} fill="#5ec8c5" />
      </svg>
    </div>
  );
});

function HistoryBand({
  fit,
  forward,
  atm,
  spotMin,
  spotMax,
  x,
  y,
  width,
  height,
}: {
  fit: SpotVolFit;
  forward: number;
  atm: number;
  spotMin: number;
  spotMax: number;
  x: ScaleLinear<number, number>;
  y: ScaleLinear<number, number>;
  width: number;
  height: number;
}) {
  const steps = 48;
  const hi: string[] = [];
  const lo: string[] = [];
  const mid: string[] = [];
  for (let i = 0; i <= steps; i++) {
    const spot = spotMin + ((spotMax - spotMin) * i) / steps;
    const band = likelyVol(spot, forward, atm, fit);
    hi.push(`${x(spot)},${y(band.hi)}`);
    lo.push(`${x(spot)},${y(band.lo)}`);
    mid.push(`${x(spot)},${y(band.mid)}`);
  }
  return (
    <>
      <defs>
        <clipPath id="history-clip">
          <rect x={PAD.l} y={PAD.t} width={width - PAD.l - PAD.r} height={height - PAD.t - PAD.b} />
        </clipPath>
      </defs>
      <g clipPath="url(#history-clip)">
        <polygon points={[...hi, ...lo.reverse()].join(" ")} fill="#5ec8c5" fillOpacity="0.16" />
        <polyline points={mid.join(" ")} fill="none" stroke="#e4e1d8" strokeWidth="1.5" strokeDasharray="4 3" />
      </g>
    </>
  );
}

function edge(scale: (v: number) => number, values: number[], index: number, dir: -1 | 1) {
  const step = values.length > 1 ? Math.abs(values[1] - values[0]) : Math.abs(values[0]) * 0.05 || 1;
  const neighbor = values[index + dir];
  if (neighbor == null) return scale(values[index] + dir * step / 2);
  return (scale(values[index]) + scale(neighbor)) / 2;
}

function heatColor(value: number, span: number) {
  return pnlColor(value, span);
}

function monthTicks(samples: Sample[], years: number) {
  if (samples.length < 2 || years <= 0) return [];
  const marks: { spot: number; vol: number; label: string }[] = [];
  const months = Math.round(years * 12);
  for (let month = 1; month < months; month++) {
    const life = month / 12 / years;
    if (life <= 0 || life >= 1) continue;
    let best = samples[0];
    for (const sample of samples) {
      if (Math.abs(sample.t - life) < Math.abs(best.t - life)) best = sample;
    }
    marks.push({ spot: best.spot, vol: best.vol, label: `${month}m` });
  }
  return marks;
}

function mixColor(t: number) {
  const a = [94, 200, 197];
  const b = [209, 161, 90];
  const c = a.map((channel, i) => Math.round(channel + (b[i] - channel) * t));
  return `rgb(${c[0]}, ${c[1]}, ${c[2]})`;
}

function appendPoint(points: ControlPoint[], spot: number, vol: number, pinStart: boolean, forward: number, atm: number) {
  if (points.length === 0) {
    return [{
      id: uid(),
      spot: pinStart ? forward : spot,
      vol: pinStart ? atm : vol,
      t: 0,
      tUser: false,
      free: !pinStart,
    }];
  }
  return arcTime([...points, { id: uid(), spot, vol, t: 1, tUser: false }]);
}

export function arcTime(points: ControlPoint[]): ControlPoint[] {
  if (points.length < 2) return points.map((p) => ({ ...p, t: 0 }));
  const seg = [0];
  for (let i = 1; i < points.length; i++) {
    const ds = Math.hypot(
      (points[i].spot - points[i - 1].spot) / Math.max(points[0].spot, 1),
      (points[i].vol - points[i - 1].vol) / Math.max(points[0].vol, 0.05),
    );
    seg.push(seg[seg.length - 1] + ds);
  }
  const total = seg[seg.length - 1] || 1;
  return points.map((p, i) => {
    if (i === 0) return { ...p, t: 0 };
    if (i === points.length - 1) return { ...p, t: 1 };
    if (p.tUser) return p;
    return { ...p, t: seg[i] / total };
  });
}

function curveSamples(
  points: ControlPoint[],
  x: ScaleLinear<number, number>,
  y: ScaleLinear<number, number>,
): Sample[] {
  if (points.length === 0) return [];
  if (points.length === 1) return [{ t: 0, spot: points[0].spot, vol: points[0].vol }];
  const d = line<ControlPoint>().x((p) => x(p.spot)).y((p) => y(p.vol)).curve(curveCatmullRom.alpha(0.5))(points);
  if (!d) return points.map((p) => ({ t: p.t, spot: p.spot, vol: p.vol }));
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", d);
  const total = path.getTotalLength();
  const knots = points.map((p) => {
    let best = 0;
    let bestD = Infinity;
    for (let i = 0; i <= 80; i++) {
      const q = path.getPointAtLength((total * i) / 80);
      const dist = (q.x - x(p.spot)) ** 2 + (q.y - y(p.vol)) ** 2;
      if (dist < bestD) {
        bestD = dist;
        best = (total * i) / 80;
      }
    }
    return { len: best, t: p.t };
  }).sort((a, b) => a.len - b.len);
  const out: Sample[] = [];
  for (let i = 0; i <= 80; i++) {
    const len = (total * i) / 80;
    const q = path.getPointAtLength(len);
    let t = knots[0]?.t ?? 0;
    for (let k = 1; k < knots.length; k++) {
      if (len <= knots[k].len) {
        const span = knots[k].len - knots[k - 1].len || 1;
        const w = (len - knots[k - 1].len) / span;
        t = knots[k - 1].t + w * (knots[k].t - knots[k - 1].t);
        break;
      }
      t = knots[k].t;
    }
    out.push({ t, spot: x.invert(q.x), vol: y.invert(q.y) });
  }
  return out;
}

function zeroContour(
  spots: number[],
  vols: number[],
  pnl: number[][],
  x: (v: number) => number,
  y: (v: number) => number,
) {
  const parts: string[] = [];
  for (let j = 0; j < vols.length - 1; j++) {
    for (let i = 0; i < spots.length - 1; i++) {
      const corners = [
        { px: x(spots[i]), py: y(vols[j]), v: pnl[j][i] },
        { px: x(spots[i + 1]), py: y(vols[j]), v: pnl[j][i + 1] },
        { px: x(spots[i + 1]), py: y(vols[j + 1]), v: pnl[j + 1][i + 1] },
        { px: x(spots[i]), py: y(vols[j + 1]), v: pnl[j + 1][i] },
      ];
      const hits: { px: number; py: number }[] = [];
      for (let e = 0; e < 4; e++) {
        const a = corners[e];
        const b = corners[(e + 1) % 4];
        if (a.v === 0 || a.v * b.v < 0) {
          const w = a.v === b.v ? 0.5 : a.v / (a.v - b.v);
          hits.push({ px: a.px + w * (b.px - a.px), py: a.py + w * (b.py - a.py) });
        }
      }
      if (hits.length >= 2) parts.push(`M${hits[0].px},${hits[0].py}L${hits[1].px},${hits[1].py}`);
    }
  }
  return parts.join(" ");
}

function isoDeltas(
  forward: number,
  atm: number,
  remaining: number,
  vols: number[],
  x: (v: number) => number,
  y: (v: number) => number,
) {
  if (remaining < 1 / 365) return null;
  return [0.25, 0.5, 0.75].map((delta) => {
    const strike = forward * Math.exp(-invNorm(delta) * atm * Math.sqrt(Math.max(remaining, 1e-4)) + 0.5 * atm * atm * remaining);
    const pts = vols.map((sig) => {
      const f = strike * Math.exp(invNorm(delta) * sig * Math.sqrt(remaining) - 0.5 * sig * sig * remaining);
      return `${x(f)},${y(sig)}`;
    });
    return <polyline key={delta} points={pts.join(" ")} fill="none" stroke="#8d938c" strokeOpacity="0.45" />;
  });
}

function invNorm(p: number) {
  const a = [2.50662823884, -18.61500062529, 41.39119773534, -25.44106049637];
  const b = [-8.4735109309, 23.08336743743, -21.06224101826, 3.13082909833];
  const c = [0.3374754822726147, 0.9761690190917186, 0.1607979322950937, 0.0276438810333863, 0.0038405729373609, 0.0003951896511919, 0.0000321767881768, 0.0000002888167364, 0.0000003960315187];
  const q = p - 0.5;
  if (Math.abs(q) < 0.42) {
    const r = q * q;
    return q * (((a[3] * r + a[2]) * r + a[1]) * r + a[0]) / ((((b[3] * r + b[2]) * r + b[1]) * r + b[0]) * r + 1);
  }
  const r = p < 0.5 ? p : 1 - p;
  const s = Math.sqrt(-Math.log(Math.max(r, 1e-12)));
  let u = c[0];
  for (let i = 1; i < c.length; i++) u = u * s + c[i];
  return p < 0.5 ? -u : u;
}
