import { useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useMemo, useRef, useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, down, tooltip, warn } from "../components/charts/theme";
import { Field, Gate, Panel, Problem, Segmented, Tile, Tiles, Toolbar } from "../components/ui";
import { postJson } from "../model/api";
import { downloadText, toCsv } from "../model/export";
import { signed, tone } from "../model/format";
import { bandLabel, useSpotVolFit } from "../model/spotvol";
import { expandTemplate, TEMPLATE_LABELS } from "../model/templates";
import {
  marketReady,
  toLegs,
  toMarketIn,
  yearFraction,
  type ControlPoint,
  type GridResult,
  type PathResult,
} from "../model/types";
import { useLab } from "../store/lab";
import { arcTime, SpotVolCanvas, type CanvasHandle } from "./path/SpotVolCanvas";

export function PathLab() {
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const regime = useLab((s) => s.regime);
  const points = useLab((s) => s.points);
  const setPoints = useLab((s) => s.setPoints);
  const hedge = useLab((s) => s.hedge);
  const setHedge = useLab((s) => s.setHedge);
  const volSource = useLab((s) => s.volSource);
  const setVolSource = useLab((s) => s.setVolSource);
  const ghosts = useLab((s) => s.ghosts);
  const mcTerminal = useLab((s) => s.mcTerminal);
  const setLegs = useLab((s) => s.setLegs);
  const [playhead, setPlayhead] = useState(0);
  const [showHelp, setShowHelp] = useState(false);
  const [showDelta, setShowDelta] = useState(false);
  const [showHistory, setShowHistory] = useState(true);
  const [showCloud, setShowCloud] = useState(true);
  const [pinStart, setPinStart] = useState(true);
  const [undo, setUndo] = useState<ControlPoint[][]>([]);
  const [redo, setRedo] = useState<ControlPoint[][]>([]);
  const [samples, setSamples] = useState<{ t: number; spot: number; vol: number }[]>([]);
  const canvasRef = useRef<CanvasHandle>(null);

  const ready = marketReady(market) && legs.length > 0;
  const slice = market?.slices[0];
  const T = slice && market ? yearFraction(market.asOf, slice.expiry) : 0;
  const forward = slice?.forward ?? 1;
  const atm = slice?.pillars["50D"] ?? 0.2;
  const viewDay = playhead * T * 365.25;
  const history = useSpotVolFit(market?.source?.contracts[0]);
  const fit = history.data ?? null;

  const domain = useMemo(() => {
    const spots = [forward * 0.72, forward * 1.42, ...points.map((p) => p.spot)];
    const vols = [Math.max(0.05, atm * 0.45), atm * 1.75, ...points.map((p) => p.vol)];
    return {
      spotMin: Math.min(...spots),
      spotMax: Math.max(...spots),
      volMin: Math.max(0.02, Math.min(...vols)),
      volMax: Math.max(...vols),
    };
  }, [forward, atm, points]);

  const grid = useQuery({
    queryKey: ["path-grid", market, legs, regime, domain],
    enabled: ready,
    queryFn: () =>
      postJson<GridResult>("/api/structures/grid", {
        market: toMarketIn(market!),
        legs: toLegs(legs),
        regime,
        spot_min: domain.spotMin,
        spot_max: domain.spotMax,
        vol_min: domain.volMin,
        vol_max: domain.volMax,
        n_spot: 28,
        n_vol: 20,
        life_fractions: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1],
      }),
  });

  const daily = useMemo(() => resample(samples, T), [samples, T]);
  const evaluated = useQuery({
    queryKey: ["path", market, legs, regime, hedge, volSource, daily],
    enabled: ready && daily.length >= 2,
    queryFn: () =>
      postJson<PathResult>("/api/paths/evaluate", {
        market: toMarketIn(market!),
        legs: toLegs(legs),
        regime,
        hedge,
        vol_source: volSource,
        points: daily,
      }),
  });

  const pnl = useMemo(() => blend(grid.data, playhead), [grid.data, playhead]);
  const setScreen = useLab((s) => s.setScreen);
  const askCopilot = useLab((s) => s.askCopilot);

  useEffect(() => {
    const data = evaluated.data;
    if (!data?.rows.length) {
      setScreen("Path", null);
      return;
    }
    const rows = data.rows;
    const first = rows[0];
    const last = rows[rows.length - 1];
    const round = (v: number, d = 2) => Number(v.toFixed(d));
    const forwards = rows.map((r) => r.forward);
    setScreen("Path", {
      drawn_path: {
        days: round(data.T * 365.25, 0),
        forward_start: round(first.forward),
        forward_end: round(last.forward),
        forward_low: round(Math.min(...forwards)),
        forward_high: round(Math.max(...forwards)),
        atm_vol_start: round(first.atm_vol, 4),
        atm_vol_end: round(last.atm_vol, 4),
      },
      hedge,
      vol_source: volSource,
      pnl_to_expiry: round(data.pnl),
      hedged_pnl_to_expiry: hedge === "none" ? null : round(data.hedged_pnl),
      attribution_to_expiry: Object.fromEntries(Object.entries(data.attribution).map(([k, v]) => [k, round(v)])),
      hedge_pnl_to_expiry: round(last.hedge_pnl),
      note: "Attribution is a daily Taylor split with greeks re-measured each day; residual closes the gap to actual P&L.",
    });
  }, [evaluated.data, hedge, volSource, setScreen]);

  function change(next: ControlPoint[], record: boolean) {
    if (record) {
      setUndo((stack) => [...stack.slice(-40), points]);
      setRedo([]);
    }
    setPoints(next);
  }

  if (!marketReady(market) || !slice || !market) {
    return <Gate title="Draw a spot and vol path out to expiry." text="Find a market first. The first click is today, the last point is expiry." />;
  }

  if (!legs.length) {
    const hasBack = market.slices.length > 1;
    return (
      <Gate
        title={`${slice.expiry} is loaded. Pick a structure to draw against.`}
        text="The square then shows that structure's P&L. The first click is today and the last point is expiry."
        action={
          <div className="flex flex-wrap justify-center gap-2">
            {TEMPLATE_LABELS.filter((template) => !template.needsBack || hasBack).map((template) => (
              <button
                key={template.id}
                className={`btn ${template.id === "straddle" ? "btn-primary" : ""}`}
                onClick={() => setLegs(expandTemplate(template.id, market.slices.map((s) => s.expiry)))}
              >
                {template.label}
              </button>
            ))}
          </div>
        }
      />
    );
  }

  return (
    <div className="grid h-full min-h-0 grid-cols-1 xl:grid-cols-[minmax(0,1fr)_minmax(460px,40%)]">
      <div className="flex min-h-0 flex-col p-3">
        <div className="mb-2 flex flex-wrap items-center gap-2 text-[12px]">
          <button className="btn" disabled={!undo.length} onClick={() => {
            const previous = undo[undo.length - 1];
            setUndo(undo.slice(0, -1));
            setRedo([points, ...redo]);
            setPoints(previous);
          }}>Undo</button>
          <button className="btn" disabled={!redo.length} onClick={() => {
            const [next, ...rest] = redo;
            setRedo(rest);
            setUndo([...undo, points]);
            setPoints(next);
          }}>Redo</button>
          <button className="btn" onClick={() => change([], true)}>Clear</button>
          <button className="btn" onClick={() => canvasRef.current?.exportPng()}>PNG</button>
          <label className="flex items-center gap-1 text-mute">
            <input type="checkbox" checked={pinStart} onChange={(e) => setPinStart(e.target.checked)} />
            Pin start to market
          </label>
          <label className="flex items-center gap-1 text-mute">
            <input type="checkbox" checked={showDelta} onChange={(e) => setShowDelta(e.target.checked)} />
            Iso-delta
          </label>
          <label className="flex items-center gap-1 text-mute" title={fit ? bandLabel(fit) : "Loads once this market has a Bloomberg future"}>
            <input type="checkbox" checked={showHistory} onChange={(e) => setShowHistory(e.target.checked)} disabled={!fit} />
            History band
          </label>
          <label className="flex items-center gap-1 text-mute">
            <input type="checkbox" checked={showCloud} onChange={(e) => setShowCloud(e.target.checked)} />
            Monte Carlo cloud
          </label>
          <span className="text-mute">{points.length < 2 ? "Click the square to start the path." : `${points.length} points`}</span>
        </div>
        <div className="mx-auto aspect-square w-full max-w-[calc(100vh-300px)] min-h-0 flex-1">
          <SpotVolCanvas
            ref={canvasRef}
            forward={forward}
            atm={atm}
            remaining={T}
            {...domain}
            spots={grid.data?.spots ?? []}
            vols={grid.data?.vols ?? []}
            pnl={pnl}
            points={points}
            playhead={playhead}
            ghosts={showCloud ? ghosts : []}
            showDelta={showDelta}
            showHistory={showHistory}
            fit={fit}
            pinStart={pinStart}
            onChange={change}
            onSamples={setSamples}
          />
        </div>
        <div className="mt-2 border border-line bg-raised px-3 py-2 text-[12px]">
          <label
            className="flex items-center gap-3"
            title="Moves the white dot along your path and recolours the square with the structure's P&L on that day. It only changes what you see; the P&L on the right always runs over the whole path."
          >
            <span className="w-28 shrink-0 text-ink">Time to view</span>
            <input className="flex-1" type="range" min={0} max={1} step={0.005} value={playhead} onChange={(e) => setPlayhead(Number(e.target.value))} />
            <span className="num w-36 shrink-0 text-right">
              day {Math.round(playhead * T * 365.25)} of {Math.round(T * 365.25)} · {Math.round((1 - playhead) * T * 365.25)}d left
            </span>
          </label>

          {points.length > 2 && (
            <>
              <div
                className="mt-3 flex items-baseline justify-between"
                title="By default the time between points is shared out by distance along the curve. Drag a slider left to reach that point sooner (a faster move, more time afterwards), right to reach it later. Moved points turn cyan."
              >
                <span className="text-ink">When the path reaches each point</span>
                <button
                  className="btn !py-0 text-[11px]"
                  disabled={!points.some((p) => p.tUser)}
                  onClick={() => change(arcTime(points.map((p) => ({ ...p, tUser: false }))), true)}
                >
                  Even pacing
                </button>
              </div>
              <div className="mt-1 grid gap-x-4 gap-y-1 sm:grid-cols-2">
                {points.slice(1, -1).map((point, k) => {
                  const index = k + 1;
                  const day = Math.round(point.t * T * 365.25);
                  return (
                    <label key={point.id} className="flex items-center gap-2 text-[11px] text-mute">
                      <span className="w-14 shrink-0">Point {index + 1}</span>
                      <input
                        className="flex-1"
                        type="range"
                        min={points[index - 1].t + 0.01}
                        max={points[index + 1].t - 0.01}
                        step={0.01}
                        value={point.t}
                        onChange={(e) => {
                          const t = Number(e.target.value);
                          change(points.map((item, i) => (i === index ? { ...item, t, tUser: true } : item)), true);
                        }}
                      />
                      <span className={`num w-12 shrink-0 text-right ${point.tUser ? "text-accent" : ""}`}>day {day}</span>
                    </label>
                  );
                })}
              </div>
            </>
          )}
          {points.length === 2 && (
            <p className="mt-2 text-[11px] text-mute">Add a third point to control when the path gets there.</p>
          )}
        </div>
      </div>
      <aside className="min-h-0 overflow-auto border-l border-line p-3">
        <Toolbar>
          <Field label="Hedge">
            <Segmented
              value={hedge}
              onChange={setHedge}
              options={[{ value: "none", label: "None" }, { value: "daily", label: "Daily Δ" }, { value: "weekly", label: "Weekly Δ" }]}
            />
          </Field>
          <Field label="Vol" hint={`Drawn: the vol you draw. Regression: ATM + β ln(F/F0) with β ${market.beta ?? 0} from the market.`}>
            <Segmented value={volSource} onChange={setVolSource} options={[{ value: "path", label: "Drawn" }, { value: "beta", label: "Regression β" }]} />
          </Field>
        </Toolbar>
        {evaluated.data && (
          <Tiles>
            <Tile k="Path P&L" v={signed(evaluated.data.pnl)} tone={tone(evaluated.data.pnl)} />
            <Tile k="Hedged" v={signed(evaluated.data.hedged_pnl)} tone={tone(evaluated.data.hedged_pnl)} />
            {mcTerminal && <Tile k="MC percentile" v={percentileLabel(evaluated.data.pnl, mcTerminal)} hint="Where this path's P&L sits in the last Monte Carlo run" />}
          </Tiles>
        )}
        {evaluated.isFetching && <div className="skeleton mb-3 h-16" />}
        <Problem error={evaluated.error} />
        <Panel title="Cumulative P&L" className="mb-3" right={<button className="btn !py-0 text-[11px]" onClick={() => evaluated.data && downloadText("path.csv", toCsv(evaluated.data.rows))}>CSV</button>}>
          <EChart option={pnlChart(evaluated.data, hedge !== "none", viewDay)} />
        </Panel>
        <div className="panel mb-3">
          <div className="panel-h">
            <span>Attribution: where the P&L came from</span>
            <div className="flex gap-1">
              <button
                className="btn !py-0 text-[11px]"
                disabled={!evaluated.data}
                onClick={() => askCopilot({ mode: "chat", prompt: "Explain the P&L on this path. Which greeks drove it, and what would change the outcome?" })}
              >
                Explain
              </button>
              <button className="btn !py-0 text-[11px]" onClick={() => setShowHelp(!showHelp)}>
                {showHelp ? "Hide explainer" : "How to read this"}
              </button>
            </div>
          </div>
          {showHelp && (
            <div className="border-b border-line px-3 py-2 text-[11px] leading-snug text-mute">
              <p>
                Each day along your path the structure is repriced. The day's P&L is then split into pieces: time
                passing first (theta), then the move in the future and in vol, using the greeks at the start of that
                day. Each coloured line is the <span className="text-ink">running total</span> of one piece from today
                up to that day, and the thick white line is the actual total P&L. At any day the coloured lines add up
                to the white line, and the residual takes up any difference.
              </p>
              <ul className="mt-2 space-y-1">
                {[...ATTRIBUTION, ...(hedge !== "none" ? [HEDGE_ROW] : [])].map((part) => (
                  <li key={part.name}>
                    <span style={{ color: part.color }}>{part.name}</span> — {part.what}
                  </li>
                ))}
              </ul>
              <p className="mt-2">
                Delta is measured afresh every day, so on a smooth trend most of the gain lands in delta (your delta
                grows as the market rallies) and gamma stays small. Gamma shows up when the path jumps a long way in a
                few days. A long straddle on a quiet path shows a falling theta line and little else. The bars
                underneath show the breakdown up to the day chosen with Time to view, or to expiry when it is at 0.
              </p>
            </div>
          )}
          <div className="h-[260px]">
            <EChart option={attrChart(evaluated.data, hedge !== "none", viewDay)} height="100%" />
          </div>
          {evaluated.data && <Breakdown data={evaluated.data} hedged={hedge !== "none"} day={viewDay} />}
        </div>
        <Panel title="Greeks along the path">
          <EChart option={greekChart(evaluated.data, viewDay)} />
        </Panel>
      </aside>
    </div>
  );
}

function percentileLabel(pnl: number, hist: { edges: number[]; counts: number[] }) {
  let below = 0;
  let total = 0;
  for (let i = 0; i < hist.counts.length; i++) {
    total += hist.counts[i];
    const mid = (hist.edges[i] + hist.edges[i + 1]) / 2;
    if (mid <= pnl) below += hist.counts[i];
  }
  if (!total) return "—";
  return `${Math.round((below / total) * 100)}th`;
}

function resample(samples: { t: number; spot: number; vol: number }[], T: number) {
  if (samples.length < 2 || T <= 0) return [];
  const n = Math.min(400, Math.max(2, Math.round(T * 365.25) + 1));
  const rows = [];
  for (let i = 0; i < n; i++) {
    const life = i / (n - 1);
    const point = atLife(samples, life);
    rows.push({ t: life * T, forward: point.spot, atm_vol: Math.max(point.vol, 0.01) });
  }
  rows[0].t = 0;
  rows[rows.length - 1].t = T;
  return rows;
}

function atLife(samples: { t: number; spot: number; vol: number }[], life: number) {
  if (life <= samples[0].t) return samples[0];
  for (let i = 1; i < samples.length; i++) {
    if (samples[i].t >= life) {
      const a = samples[i - 1];
      const b = samples[i];
      const w = (life - a.t) / (b.t - a.t || 1);
      return { t: life, spot: a.spot + w * (b.spot - a.spot), vol: a.vol + w * (b.vol - a.vol) };
    }
  }
  return samples[samples.length - 1];
}

function blend(grid: GridResult | undefined, life: number): number[][] | null {
  if (!grid?.frames.length) return null;
  let lower = grid.frames[0];
  let upper = grid.frames[grid.frames.length - 1];
  for (let i = 0; i < grid.frames.length - 1; i++) {
    if (grid.frames[i].life_fraction <= life && grid.frames[i + 1].life_fraction >= life) {
      lower = grid.frames[i];
      upper = grid.frames[i + 1];
      break;
    }
  }
  const span = upper.life_fraction - lower.life_fraction || 1;
  const weight = (life - lower.life_fraction) / span;
  return lower.pnl.map((row, j) => row.map((value, i) => value * (1 - weight) + upper.pnl[j][i] * weight));
}

type RowKey = keyof PathResult["rows"][number];

export const ATTRIBUTION: { key: RowKey; name: string; color: string; what: string }[] = [
  { key: "delta_pnl", name: "Delta", color: accent, what: "Direction. P&L from the future moving, at the delta you held each day." },
  { key: "gamma_pnl", name: "Gamma", color: "#7f93b0", what: "Convexity. Extra P&L from the size of the moves, ½·Γ·ΔF². Long options earn it on big days." },
  { key: "theta_pnl", name: "Theta", color: down, what: "Time decay. What one more day costs with spot and vol unchanged. Long options pay it every day." },
  { key: "vega_pnl", name: "Vega", color: warn, what: "Vol level. P&L from the drawn vol moving up or down, at the vega you held." },
  { key: "vanna_pnl", name: "Vanna", color: "#b9a0c4", what: "Spot and vol moving together. Matters when your path rallies and vol rises (or falls) on the same day." },
  { key: "volga_pnl", name: "Volga", color: "#8faf88", what: "Vol convexity. Extra P&L from large vol moves, ½·volga·Δσ². Wings carry most of it." },
  { key: "residual_pnl", name: "Residual", color: "#8d938c", what: "Whatever the Taylor terms miss: higher-order effects and expiry. Small on smooth paths." },
];

const HEDGE_ROW = { key: "hedge_pnl" as RowKey, name: "Hedge", color: "#e4e1d8", what: "P&L on the short futures delta hedge. It roughly cancels the delta term." };

function nearest(rows: PathResult["rows"], day: number) {
  let best = rows[0];
  for (const row of rows) if (Math.abs(row.t * 365.25 - day) < Math.abs(best.t * 365.25 - day)) best = row;
  return best;
}

function cursor(day: number) {
  return {
    silent: true,
    symbol: "none",
    animation: false,
    lineStyle: { color: "#e4e1d8", type: "dashed" as const, width: 1, opacity: 0.85 },
    label: { show: day > 0.5, position: "insideEndTop" as const, rotate: 0, color: "#e4e1d8", fontSize: 10, formatter: `day ${Math.round(day)}` },
    data: [{ xAxis: day }],
  };
}

const axisTooltip = { ...tooltip, trigger: "axis" as const, valueFormatter: (v: unknown) => (typeof v === "number" ? signed(v) : "—") };
const dayAxis = (T: number) => ({ type: "value" as const, ...axis(), name: "days", nameLocation: "middle" as const, nameGap: 20, min: 0, max: Math.round(T * 365.25) });

function pnlChart(data: PathResult | undefined, hedged: boolean, day: number): EChartsOption {
  if (!data) return {};
  const series: EChartsOption["series"] = [
    {
      name: "Option",
      type: "line",
      showSymbol: false,
      data: data.rows.map((row) => [row.t * 365.25, row.pnl]),
      lineStyle: { color: accent },
      itemStyle: { color: accent },
      markLine: cursor(day),
    },
  ];
  if (hedged) {
    series.push({
      name: "Option + hedge",
      type: "line",
      showSymbol: false,
      data: data.rows.map((row) => [row.t * 365.25, row.pnl + row.hedge_pnl]),
      lineStyle: { color: warn },
      itemStyle: { color: warn },
    });
  }
  return {
    tooltip: axisTooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 52, right: 16, top: 24, bottom: 36 },
    xAxis: dayAxis(data.T),
    yAxis: { type: "value", ...axis() },
    series,
  };
}

function attrChart(data: PathResult | undefined, hedged: boolean, day: number): EChartsOption {
  if (!data) return {};
  const x = data.rows.map((row) => row.t * 365.25);
  const parts = hedged ? [...ATTRIBUTION, HEDGE_ROW] : ATTRIBUTION;
  return {
    tooltip: axisTooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0, type: "scroll" },
    grid: { left: 52, right: 16, top: 28, bottom: 36 },
    xAxis: dayAxis(data.T),
    yAxis: { type: "value", ...axis() },
    series: [
      ...parts.map((part, k) => ({
        name: part.name,
        type: "line" as const,
        showSymbol: false,
        lineStyle: { width: 1.5, color: part.color },
        itemStyle: { color: part.color },
        data: data.rows.map((row, i) => [x[i], row[part.key] as number]),
        ...(k === 0 ? { markLine: cursor(day) } : {}),
      })),
      {
        name: "Total",
        type: "line" as const,
        showSymbol: false,
        z: 10,
        lineStyle: { color: "#e4e1d8", width: 2.5 },
        itemStyle: { color: "#e4e1d8" },
        areaStyle: { color: "rgba(228, 225, 216, 0.06)" },
        data: data.rows.map((row, i) => [x[i], hedged ? row.pnl + row.hedge_pnl : row.pnl]),
      },
    ],
  };
}

function greekChart(data: PathResult | undefined, day: number): EChartsOption {
  if (!data) return {};
  return {
    tooltip: { ...tooltip, trigger: "axis" },
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 52, right: 52, top: 24, bottom: 36 },
    xAxis: dayAxis(data.T),
    yAxis: [
      { type: "value", ...axis(), name: "delta" },
      { type: "value", ...axis(), name: "vega", splitLine: { show: false } },
    ],
    series: [
      {
        name: "Delta",
        type: "line",
        showSymbol: false,
        data: data.rows.map((row) => [row.t * 365.25, row.delta]),
        lineStyle: { color: accent },
        itemStyle: { color: accent },
        markLine: cursor(day),
      },
      {
        name: "Vega",
        type: "line",
        showSymbol: false,
        yAxisIndex: 1,
        data: data.rows.map((row) => [row.t * 365.25, row.vega]),
        lineStyle: { color: warn },
        itemStyle: { color: warn },
      },
    ],
  };
}

function Breakdown({ data, hedged, day }: { data: PathResult; hedged: boolean; day: number }) {
  const atStart = day < 0.5;
  const row = atStart ? data.rows[data.rows.length - 1] : nearest(data.rows, day);
  const parts = hedged ? [...ATTRIBUTION, HEDGE_ROW] : ATTRIBUTION;
  const values = parts.map((part) => ({ ...part, value: row[part.key] as number }));
  const total = hedged ? row.pnl + row.hedge_pnl : row.pnl;
  const scale = Math.max(...values.map((v) => Math.abs(v.value)), Math.abs(total), 1e-9);
  return (
    <div className="border-t border-line px-3 py-2 text-[11px]">
      <div className="mb-1 flex justify-between text-mute">
        <span>
          {atStart
            ? `Total to expiry (day ${Math.round(row.t * 365.25)}). Move Time to view to see it at an earlier day.`
            : `Running total to day ${Math.round(row.t * 365.25)}`}
        </span>
        <span className="num">
          total <span className={tone(total)}>{signed(total)}</span>
        </span>
      </div>
      {values.map((v) => (
        <div key={v.name} className="flex items-center gap-2 py-[1px]" title={v.what}>
          <span className="w-14 shrink-0" style={{ color: v.color }}>{v.name}</span>
          <div className="relative h-2 flex-1 bg-sunken">
            <div className="absolute top-0 h-2 w-px bg-line" style={{ left: "50%" }} />
            <div
              className="absolute top-0 h-2"
              style={{
                background: v.color,
                opacity: 0.8,
                width: `${(Math.abs(v.value) / scale) * 50}%`,
                left: v.value >= 0 ? "50%" : `${50 - (Math.abs(v.value) / scale) * 50}%`,
              }}
            />
          </div>
          <span className={`num w-20 shrink-0 text-right ${tone(v.value)}`}>{signed(v.value)}</span>
        </div>
      ))}
    </div>
  );
}
