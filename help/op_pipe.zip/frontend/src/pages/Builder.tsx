import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useMemo, useRef, useState } from "react";
import ReactECharts from "echarts-for-react";
import { EChart } from "../components/charts/EChart";
import { axis, pnlVisualMap, tooltip } from "../components/charts/theme";
import { Empty, Gate, Loading, Panel, Tile, Tiles } from "../components/ui";
import { postJson } from "../model/api";
import { bandLabel, likelyVol, useSpotVolFit, type SpotVolFit } from "../model/spotvol";
import { downloadText, downloadUrl, toCsv } from "../model/export";
import { px, signed, tone, volPts } from "../model/format";
import { uid } from "../model/id";
import { addEntry, saveStructure } from "../model/journal";
import { expiryListQuery } from "../model/queries";
import { groupLegs, periods, stripForward, stripLegs, withPeriod, type Period } from "../model/strips";
import { TEMPLATE_LABELS, expandTemplate } from "../model/templates";
import {
  marketReady,
  toLegs,
  toMarketIn,
  type GridResult,
  type Leg,
  type Market,
  type PriceResult,
} from "../model/types";
import { useLab } from "../store/lab";

export function Builder() {
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const setLegs = useLab((s) => s.setLegs);
  const updateLeg = useLab((s) => s.updateLeg);
  const regime = useLab((s) => s.regime);
  const followBeta = useLab((s) => s.followBeta);
  const askCopilot = useLab((s) => s.askCopilot);
  const [life, setLife] = useState(0);
  const payoffRef = useRef<ReactECharts>(null);
  const ready = marketReady(market) && legs.length > 0;
  const slice = market?.slices[0];

  const price = useQuery({
    queryKey: ["price", market, legs, regime, followBeta],
    enabled: ready,
    queryFn: () =>
      postJson<PriceResult>("/api/structures/price", {
        market: toMarketIn(market!),
        legs: toLegs(legs),
        regime,
        follow_beta: followBeta,
      }),
  });

  const grid = useQuery({
    queryKey: ["grid", market, legs, regime, slice?.forward, slice?.pillars["50D"]],
    enabled: ready && !!slice,
    queryFn: () =>
      postJson<GridResult>("/api/structures/grid", {
        market: toMarketIn(market!),
        legs: toLegs(legs),
        regime,
        spot_min: slice!.forward * 0.7,
        spot_max: slice!.forward * 1.45,
        vol_min: Math.max(0.05, (slice!.pillars["50D"] ?? 0.2) * 0.45),
        vol_max: (slice!.pillars["50D"] ?? 0.2) * 1.8,
        n_spot: 29,
        n_vol: 17,
        life_fractions: [0, 0.25, 0.5, 0.75, 1],
      }),
  });

  const contract = market?.source?.contracts[0];
  const history = useSpotVolFit(contract);
  const fit = history.data ?? null;

  const payoffOption = useMemo(() => payoffChart(price.data), [price.data]);
  const greekOption = useMemo(() => greekChart(price.data), [price.data]);
  const heatOption = useMemo(
    () => heatChart(grid.data, life, fit, slice?.forward ?? 0, slice?.pillars["50D"] ?? 0),
    [grid.data, life, fit, slice?.forward, slice?.pillars],
  );
  const ladderOption = useMemo(() => ladderChart(price.data), [price.data]);

  if (!marketReady(market)) {
    return <Gate title="Price a structure from a forward and a vol." text="Search Bloomberg for a product such as TTF and pick an expiry, or type a market in by hand." />;
  }

  const summary = price.data;
  const back = market.slices.length > 1;

  return (
    <div className="grid h-full min-h-0 grid-cols-1 lg:grid-cols-[320px_1fr]">
      <aside className="min-h-0 overflow-auto border-r border-line p-3">
        <div className="mb-1.5 text-[11px] text-mute">Templates</div>
        <div className="flex flex-wrap gap-1">
          {TEMPLATE_LABELS.map((template) => (
            <button
              key={template.id}
              className="btn"
              disabled={template.needsBack && !back}
              title={template.needsBack && !back ? "Add a second expiry in the market" : template.label}
              onClick={() => setLegs(expandTemplate(template.id, market.slices.map((s) => s.expiry)))}
            >
              {template.label}
            </button>
          ))}
        </div>
        <StripPicker market={market} />
        <div className="mb-1.5 mt-4 text-[11px] text-mute">Legs</div>
        <table className="blotter">
          <thead>
            <tr>
              <th>C/P</th>
              <th>Qty</th>
              <th>Strike</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {groupLegs(legs).map(({ key, legs: group }) =>
              group[0].strip ? (
                <StripRow
                  key={key}
                  legs={group}
                  market={market}
                  resolved={group.map((leg) => summary?.legs[legs.indexOf(leg)])}
                  onChange={(patch) => setLegs(legs.map((leg) => (leg.strip?.id === key ? { ...leg, ...patch } : leg)))}
                  onRemove={() => setLegs(legs.filter((leg) => leg.strip?.id !== key))}
                />
              ) : (
                <LegRow
                  key={key}
                  leg={group[0]}
                  resolved={summary?.legs[legs.indexOf(group[0])]}
                  expiries={market.slices.map((s) => s.expiry)}
                  onChange={(patch) => updateLeg(group[0].id, patch)}
                  onRemove={() => setLegs(legs.filter((item) => item.id !== group[0].id))}
                />
              ),
            )}
          </tbody>
        </table>
        <button
          className="btn mt-2"
          onClick={() =>
            setLegs([
              ...legs,
              {
                id: uid(),
                callPut: "C",
                qty: 1,
                strikeMode: "delta",
                strike: 0.5,
                expiry: market.slices[0].expiry,
                vol: null,
              },
            ])
          }
        >
          Add leg
        </button>
        {price.error && <p className="mt-3 text-[12px] text-down">{(price.error as Error).message}</p>}
        {summary && (
          <div className="mt-3 border-t border-line pt-3 text-[11px] text-mute">
            <div>Breakevens {summary.breakevens.length ? summary.breakevens.map((b) => px(b)).join(", ") : "none on the grid"}</div>
            <div className="mt-1">{summary.legs.map((leg) => `${leg.call_put} ${px(leg.strike)} @ ${volPts(leg.vol)}`).join(" · ")}</div>
          </div>
        )}
        {summary && <SaveToJournal market={market} legs={legs} priced={summary} />}
        <div className="mt-4 border-t border-line pt-3">
          <div className="mb-1.5 text-[11px] text-mute">Copilot</div>
          <div className="flex flex-col gap-1">
            <button
              className="btn text-left"
              disabled={!legs.length}
              onClick={() => askCopilot({ mode: "critique", prompt: "Critique the structure I have loaded." })}
            >
              Critique this structure
            </button>
            <button
              className="btn text-left"
              disabled={!legs.length}
              onClick={() => askCopilot({ mode: "structure", prompt: "Find structures that express the same view as what I have loaded, but cheaper or with better risk/reward." })}
            >
              Find better alternatives
            </button>
            <button
              className="btn text-left"
              disabled={!legs.length}
              onClick={() => askCopilot({ mode: "chat", prompt: "What is my biggest risk on this structure, and how would you hedge or adjust it?" })}
            >
              Biggest risk and hedge
            </button>
          </div>
        </div>
      </aside>
      <section className="min-h-0 overflow-auto p-3">
        {price.isLoading && <div className="skeleton mb-3 h-16" />}
        {!legs.length && !price.isLoading && <Empty>Pick a template or add a leg to price it.</Empty>}
        {summary && (
          <Tiles>
            <Tile k="Premium" v={signed(summary.premium)} tone={tone(summary.premium)} hint="Per unit, positive when you pay" />
            <Tile k="Delta" v={px(summary.delta, 3)} />
            <Tile k="Gamma" v={px(summary.gamma, 4)} />
            <Tile k="Vega / pt" v={px(summary.vega_point, 3)} hint="Per vol point" />
            <Tile k="Theta / day" v={signed(summary.theta_day, 3)} tone={tone(summary.theta_day)} />
            <Tile k="Vanna" v={px(summary.vanna, 3)} hint="Change in delta per vol point" />
            <Tile k="Volga" v={px(summary.volga, 2)} hint="Change in vega per vol point" />
            <Tile k="P(profit)" v={summary.pop == null ? "—" : `${(summary.pop * 100).toFixed(0)}%`} hint="Under the smile's risk-neutral distribution at expiry" />
            <Tile k="Max gain / loss" v={`${summary.unlimited_gain ? "∞" : signed(summary.max_gain)} / ${summary.unlimited_loss ? "∞" : signed(summary.max_loss)}`} />
          </Tiles>
        )}
        {summary && (
          <div className="grid gap-3 xl:grid-cols-2">
            <Panel title="P&L against the future" right={<button className="btn !py-0 text-[11px]" onClick={() => exportChart(payoffRef.current, "payoff.png")}>PNG</button>}>
              <EChart ref={payoffRef} option={payoffOption} />
            </Panel>
            <Panel title="Delta and vega against the future">
              <EChart option={greekOption} />
            </Panel>
            <Panel
              title="Future × vol P&L"
              size="lg"
              right={
                <label className="flex items-center gap-2 text-[11px]" title={fit ? `${bandLabel(fit)}. Vol at each future level is today's ATM plus β times the log move; the band is one residual standard deviation.` : undefined}>
                  {fit && <span className="hidden 2xl:inline">{bandLabel(fit)}</span>}
                  Life {Math.round(life * 100)}%
                  <input type="range" min={0} max={1} step={0.25} value={life} onChange={(e) => setLife(Number(e.target.value))} />
                </label>
              }
            >
              {grid.error ? <Empty>{(grid.error as Error).message}</Empty> : grid.isLoading ? <Loading /> : <EChart option={heatOption} />}
            </Panel>
            <Panel
              title="Scenario ladder"
              size="lg"
              right={<button className="btn !py-0 text-[11px]" onClick={() => summary && downloadText("ladder.csv", toCsv(summary.ladder as unknown as Record<string, unknown>[]))}>CSV</button>}
            >
              <EChart option={ladderOption} />
            </Panel>
          </div>
        )}
      </section>
    </div>
  );
}

function LegRow({
  leg,
  resolved,
  expiries,
  onChange,
  onRemove,
}: {
  leg: Leg;
  resolved?: PriceResult["legs"][number];
  expiries: string[];
  onChange: (patch: Partial<Leg>) => void;
  onRemove: () => void;
}) {
  return (
    <>
      <tr>
        <td>
          <select value={leg.callPut} onChange={(e) => onChange({ callPut: e.target.value as Leg["callPut"] })}>
            <option value="C">C</option>
            <option value="P">P</option>
          </select>
        </td>
        <td>
          <input type="number" value={leg.qty} step="1" onChange={(e) => onChange({ qty: Number(e.target.value) })} />
        </td>
        <td>
          <select value={leg.strikeMode} onChange={(e) => onChange({ strikeMode: e.target.value as Leg["strikeMode"] })}>
            <option value="delta">Delta</option>
            <option value="absolute">Strike</option>
            <option value="pct_atm">% of F</option>
          </select>
        </td>
        <td>
          <button className="btn" onClick={onRemove}>×</button>
        </td>
      </tr>
      <tr>
        <td colSpan={4}>
          <div className="flex gap-1">
            <input
              aria-label="Strike value"
              type="number"
              step="0.01"
              value={leg.strike}
              onChange={(e) => onChange({ strike: Number(e.target.value) })}
            />
            <select value={leg.expiry ?? expiries[0]} onChange={(e) => onChange({ expiry: e.target.value })}>
              {expiries.map((expiry) => (
                <option key={expiry} value={expiry}>{expiry}</option>
              ))}
            </select>
          </div>
          {resolved && <div className="num mt-1 text-mute">K {px(resolved.strike)} · {volPts(resolved.vol)}</div>}
        </td>
      </tr>
    </>
  );
}

const round2 = (value: number) => Math.round(value * 100) / 100;

function monthLabel(market: Market, expiry: string | null) {
  const i = market.slices.findIndex((s) => s.expiry === expiry);
  return (i >= 0 && market.source?.labels[i]) || expiry || "";
}

function StripPicker({ market }: { market: Market }) {
  const setMarket = useLab((s) => s.setMarket);
  const setLegs = useLab((s) => s.setLegs);
  const product = market.source?.product;
  const list = useQuery({ ...expiryListQuery(product ?? ""), enabled: !!product });
  const options = useMemo(() => periods(list.data?.contracts ?? []), [list.data]);
  const [pick, setPick] = useState("");
  const [callPut, setCallPut] = useState<"C" | "P">("C");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  if (!product) return null;
  const chosen: Period | undefined = options.find((p) => p.id === pick) ?? options[0];

  async function add() {
    if (!chosen) return;
    setBusy(true);
    setError(null);
    try {
      const { market: next, expiries } = await withPeriod(market, chosen, market.source?.volSource ?? "settle");
      const atm = stripForward(next, expiries) ?? next.slices[0].forward;
      setMarket(next);
      setLegs([...useLab.getState().legs, ...stripLegs(chosen.label, expiries, callPut, 1, round2(atm))]);
    } catch (exc) {
      setError((exc as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mt-4">
      <div className="mb-1.5 text-[11px] text-mute" title="One option per delivery month, all at one strike, each priced on its own month's forward and smile">
        Strips · quarters, seasons, calendars
      </div>
      {list.isLoading ? (
        <div className="text-[11px] text-mute">Reading the listed months…</div>
      ) : !options.length ? (
        <div className="text-[11px] text-mute">{list.error ? (list.error as Error).message : "No complete quarter or season is listed with options."}</div>
      ) : (
        <>
          <div className="flex gap-1">
            <select className="min-w-0 flex-1" value={chosen?.id} onChange={(e) => setPick(e.target.value)}>
              {(["Quarter", "Season", "Calendar"] as const).map((kind) => (
                <optgroup key={kind} label={kind}>
                  {options.filter((p) => p.kind === kind).map((p) => (
                    <option key={p.id} value={p.id}>{p.label}</option>
                  ))}
                </optgroup>
              ))}
            </select>
            <select value={callPut} onChange={(e) => setCallPut(e.target.value as "C" | "P")}>
              <option value="C">Calls</option>
              <option value="P">Puts</option>
            </select>
            <button className="btn" disabled={busy || !chosen} onClick={add}>{busy ? "Loading…" : "Add"}</button>
          </div>
          {chosen && <div className="mt-1 text-[11px] text-mute">{chosen.rows.map((r) => r.label).join(" ")} · struck at the strip forward</div>}
        </>
      )}
      {error && <p className="mt-1 text-[11px] text-down">{error}</p>}
    </div>
  );
}

function StripRow({
  legs,
  market,
  resolved,
  onChange,
  onRemove,
}: {
  legs: Leg[];
  market: Market;
  resolved: (PriceResult["legs"][number] | undefined)[];
  onChange: (patch: Partial<Leg>) => void;
  onRemove: () => void;
}) {
  const lead = legs[0];
  const forward = stripForward(market, legs.map((leg) => leg.expiry ?? ""));
  const vols = resolved.map((r) => r?.vol).filter((v): v is number => v != null);
  const avgVol = vols.length ? vols.reduce((a, b) => a + b, 0) / vols.length : null;
  return (
    <>
      <tr>
        <td>
          <select value={lead.callPut} onChange={(e) => onChange({ callPut: e.target.value as Leg["callPut"] })}>
            <option value="C">C</option>
            <option value="P">P</option>
          </select>
        </td>
        <td>
          <input type="number" value={lead.qty} step="1" title="Lots per month" onChange={(e) => onChange({ qty: Number(e.target.value) })} />
        </td>
        <td className="text-accent" title="Priced as a strip of monthly options">{lead.strip!.label} strip</td>
        <td>
          <button className="btn" onClick={onRemove}>×</button>
        </td>
      </tr>
      <tr>
        <td colSpan={4}>
          <div className="flex gap-1">
            <input aria-label="Strip strike" type="number" step="0.05" value={lead.strike} onChange={(e) => onChange({ strike: Number(e.target.value) })} />
            <button className="btn" disabled={!forward} title="Strike at the strip forward, the average of the months' forwards" onClick={() => forward && onChange({ strike: round2(forward) })}>
              ATM
            </button>
          </div>
          <div className="num mt-1 text-mute">
            {legs.length} months · F̄ {px(forward)} · K/F̄ {forward ? `${((lead.strike / forward) * 100).toFixed(1)}%` : "—"} · avg vol {volPts(avgVol)}
          </div>
          <div className="num text-[10px] text-mute">
            {legs.map((leg, i) => `${monthLabel(market, leg.expiry)} ${volPts(resolved[i]?.vol ?? null, 1)}`).join(" · ")}
          </div>
        </td>
      </tr>
    </>
  );
}

function structureLabel(market: Market, legs: Leg[], priced: PriceResult) {
  return groupLegs(legs)
    .map(({ legs: group }) => {
      const leg = group[0];
      const strike = px(priced.legs[legs.indexOf(leg)]?.strike ?? leg.strike);
      const qty = `${leg.qty > 0 ? "+" : ""}${leg.qty}`;
      return leg.strip ? `${qty} ${leg.strip.label} ${leg.callPut} ${strike}` : `${qty} ${monthLabel(market, leg.expiry)} ${leg.callPut} ${strike}`;
    })
    .join(" / ");
}

function SaveToJournal({ market, legs, priced }: { market: Market; legs: Leg[]; priced: PriceResult }) {
  const user = useLab((s) => s.userName);
  const client = useQueryClient();
  const [size, setSize] = useState(1);
  const [tags, setTags] = useState("");
  const save = useMutation({
    mutationFn: (kind: "trade" | "idea") => {
      const structure = saveStructure(market, legs, priced);
      if (!structure) throw new Error("Load the market from Bloomberg to save it; a typed-in market has no contracts to re-price.");
      return addEntry(
        {
          kind,
          label: structureLabel(market, legs, priced),
          product: structure.product,
          price: priced.premium / (market.multiplier || 1),
          size,
          tags: tags.split(/[\s,]+/).filter(Boolean),
          structure,
        },
        user,
      );
    },
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["journal"] });
      client.invalidateQueries({ queryKey: ["journal-audit"] });
    },
  });
  return (
    <div className="mt-4 border-t border-line pt-3">
      <div className="mb-1.5 text-[11px] text-mute">Journal</div>
      <div className="flex gap-1">
        <label className="flex items-center gap-1 text-[11px] text-mute" title="Lots; negative when sold">
          Lots <input className="w-14" type="number" step="1" value={size} onChange={(e) => setSize(Number(e.target.value))} />
        </label>
        <input className="min-w-0 flex-1" placeholder="tags, e.g. winter hedge" value={tags} onChange={(e) => setTags(e.target.value)} />
      </div>
      <div className="mt-1 flex gap-1">
        <button className="btn flex-1" disabled={save.isPending || size === 0} onClick={() => save.mutate("trade")} title="Open trades are in the Risk book">Log as traded</button>
        <button className="btn flex-1" disabled={save.isPending} onClick={() => save.mutate("idea")}>Save idea</button>
      </div>
      {save.isSuccess && <p className="mt-1 text-[11px] text-up">Saved {save.data.kind} “{save.data.label}”.</p>}
      {save.error && <p className="mt-1 text-[11px] text-down">{(save.error as Error).message}</p>}
    </div>
  );
}

function payoffChart(data: PriceResult | undefined): EChartsOption {
  if (!data) return {};
  const series = data.frames.map((frame) => ({
    name: frame.life_fraction === 1 ? "Expiry value" : `${Math.round(frame.life_fraction * 100)}% life`,
    type: "line" as const,
    showSymbol: false,
    data: frame.spots.map((spot, i) => [spot, frame.value[i] - data.premium]),
  }));
  if (data.payoff) {
    series.push({
      name: "Expiry P&L",
      type: "line",
      showSymbol: false,
      data: data.payoff.spots.map((spot, i) => [spot, data.payoff!.pnl[i]]),
    });
  }
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 48, right: 12, top: 28, bottom: 28 },
    xAxis: { type: "value", ...axis(), name: "Forward" },
    yAxis: { type: "value", ...axis(), name: "P&L" },
    series,
  };
}

function greekChart(data: PriceResult | undefined): EChartsOption {
  if (!data) return {};
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 48, right: 48, top: 28, bottom: 28 },
    xAxis: { type: "value", ...axis() },
    yAxis: [
      { type: "value", ...axis(), name: "Delta" },
      { type: "value", ...axis(), name: "Vega", splitLine: { show: false } },
    ],
    series: [
      { name: "Delta", type: "line", showSymbol: false, yAxisIndex: 0, data: data.spot_profile.spots.map((s, i) => [s, data.spot_profile.delta[i]]) },
      { name: "Vega", type: "line", showSymbol: false, yAxisIndex: 1, data: data.spot_profile.spots.map((s, i) => [s, data.spot_profile.vega[i]]) },
    ],
  };
}

function heatChart(data: GridResult | undefined, life: number, fit: SpotVolFit | null, forward: number, atm: number): EChartsOption {
  if (!data) return {};
  const frame = data.frames.reduce((best, item) =>
    Math.abs(item.life_fraction - life) < Math.abs(best.life_fraction - life) ? item : best,
  );
  const flat = frame.pnl.flat();
  const span = Math.max(...flat.map((v) => Math.abs(v)), 1e-6);
  const points: [number, number, number][] = [];
  frame.pnl.forEach((row, j) => row.forEach((value, i) => points.push([i, j, value])));
  return {
    tooltip,
    grid: { left: 48, right: 16, top: 12, bottom: 28 },
    xAxis: { type: "category", data: data.spots.map((s) => px(s, 1)), ...axis() },
    yAxis: { type: "category", data: data.vols.map((v) => volPts(v, 0)), ...axis() },
    visualMap: { ...pnlVisualMap(span), seriesIndex: 0 },
    series: [
      { type: "heatmap", data: points, z: 1 },
      ...(fit && forward > 0 && atm > 0 ? [historyBand(data.spots, data.vols, forward, atm, fit)] : []),
    ],
  };
}

function historyBand(spots: number[], vols: number[], forward: number, atm: number, fit: SpotVolFit) {
  const index = (value: number) => (vols.length < 2 ? 0 : (value - vols[0]) / (vols[1] - vols[0]));
  const upper: number[][] = [];
  const lower: number[][] = [];
  const mid: number[][] = [];
  spots.forEach((spot, i) => {
    const band = likelyVol(spot, forward, atm, fit);
    upper.push([i, index(band.hi)]);
    lower.push([i, index(band.lo)]);
    mid.push([i, index(band.mid)]);
  });
  return {
    type: "custom" as const,
    name: "History",
    silent: true,
    clip: true,
    z: 4,
    data: [0],
    renderItem: (_params: unknown, api: { coord: (value: number[]) => number[] }) => {
      // Category axes round fractional values to a cell, so interpolate between cell centres here.
      const origin = api.coord([0, 0]);
      const dx = api.coord([1, 0])[0] - origin[0];
      const dy = api.coord([0, 1])[1] - origin[1];
      const px = ([x, y]: number[]) => [origin[0] + x * dx, origin[1] + y * dy];
      return {
        type: "group" as const,
        children: [
          {
            type: "polygon" as const,
            shape: { points: [...upper.map(px), ...[...lower].reverse().map(px)] },
            style: { fill: "rgba(94, 200, 197, 0.22)", stroke: "rgba(94, 200, 197, 0.7)", lineWidth: 1 },
          },
          {
            type: "polyline" as const,
            shape: { points: mid.map(px) },
            style: { fill: "none", stroke: "#e4e1d8", lineWidth: 1.5, lineDash: [4, 3] },
          },
        ],
      };
    },
  };
}

function ladderChart(data: PriceResult | undefined): EChartsOption {
  if (!data) return {};
  const spots = [...new Set(data.ladder.map((row) => row.spot_pct))];
  const vols = [...new Set(data.ladder.map((row) => row.vol_pts))];
  const span = Math.max(...data.ladder.map((row) => Math.abs(row.pnl)), 1e-6);
  return {
    tooltip,
    grid: { left: 56, right: 12, top: 12, bottom: 28 },
    xAxis: { type: "category", data: spots.map((s) => `${Math.round(s * 100)}%`), ...axis(), name: "Spot" },
    yAxis: { type: "category", data: vols.map((v) => signed(v * 100, 0)), ...axis(), name: "Vol pts" },
    visualMap: pnlVisualMap(span),
    series: [{
      type: "heatmap",
      data: data.ladder.map((row) => [spots.indexOf(row.spot_pct), vols.indexOf(row.vol_pts), row.pnl]),
    }],
  };
}

function exportChart(chart: ReactECharts | null, name: string) {
  const url = chart?.getEchartsInstance().getDataURL({ type: "png", backgroundColor: "#14171c", pixelRatio: 2 });
  if (url) downloadUrl(url, name);
}
