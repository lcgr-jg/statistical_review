import { useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useMemo, useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, down, mute, tooltip, up, warn } from "../components/charts/theme";
import { Field, Freshness, Gate, Note, Page, Panel, Problem, Segmented, Td, Th, Tile, Tiles, Toolbar } from "../components/ui";
import { downloadText, toCsv } from "../model/export";
import { pct, signed, volPts } from "../model/format";
import type { RollCycle, RollPoint, RollResult } from "../model/history";
import { ROLL_DEFAULTS, rollsQuery } from "../model/queries";
import { useLab } from "../store/lab";

const DELTAS = [
  { value: 0.9, label: "10D put" },
  { value: 0.75, label: "25D put" },
  { value: 0.5, label: "ATM (50D)" },
  { value: 0.25, label: "25D call" },
  { value: 0.1, label: "10D call" },
];
const CHECKPOINTS = [40, 30, 20, 10, 5, 0];

export function Rolls() {
  const market = useLab((s) => s.market);
  const askCopilot = useLab((s) => s.askCopilot);
  const setScreen = useLab((s) => s.setScreen);
  const ticker = market?.source?.product ?? market?.source?.contracts[0];
  const [front, setFront] = useState(ROLL_DEFAULTS.front);
  const [back, setBack] = useState(ROLL_DEFAULTS.back);
  const [delta, setDelta] = useState(ROLL_DEFAULTS.delta);
  const [custom, setCustom] = useState("");
  const [lookback, setLookback] = useState(ROLL_DEFAULTS.lookback);
  const [hidden, setHidden] = useState<Set<string>>(new Set());

  const customDelta = custom.trim() === "" ? null : Number(custom) / 100;
  const callDelta = customDelta != null && customDelta > 0.02 && customDelta < 0.98 ? customDelta : delta;

  const rolls = useQuery({ ...rollsQuery(ticker ?? "", front, back, callDelta, lookback), enabled: !!ticker && back > front });
  const data = rolls.data;

  useEffect(() => {
    if (!data) return;
    setScreen("Rolls", {
      pair: `M+${data.front} minus M+${data.back}`,
      call_delta: data.call_delta,
      stats: data.stats,
      median_path: Object.fromEntries(data.profile.dte.filter((d) => d % 5 === 0).map((d) => [d, data.profile.median[data.profile.dte.indexOf(d)]])),
      cycles: data.cycles.map((c) => ({ pair: c.label, expiry: c.expiry, ...checkpoints(c.points) })),
      sources: data.sources,
      notes: data.notes,
    });
  }, [data, setScreen]);

  const overlay = useMemo(() => overlayChart(data, hidden), [data, hidden]);
  const series = useMemo(() => seriesChart(data), [data]);

  if (!ticker) {
    return <Gate title="See how calendar vol spreads behave into expiry." text="Find a market first. The page walks its listed contracts to build each roll cycle." />;
  }

  const s = data?.stats;
  const total = data ? Object.values(data.sources).reduce((a, b) => a + (b ?? 0), 0) : 0;
  const extrapolated = data && total ? (data.sources.extrapolated ?? 0) / total : 0;
  const deltaLabel = DELTAS.find((d) => Math.abs(d.value - callDelta) < 1e-9)?.label ?? `${Math.round(callDelta * 100)} call delta`;

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <Freshness queries={[rolls]} />
            <button
              className="btn"
              disabled={!data}
              onClick={() =>
                askCopilot({
                  mode: "chat",
                  prompt: `Read this M+${front} minus M+${back} ${deltaLabel} vol spread study. Where is the spread against past cycles at the same days to expiry, how does it usually move into expiry, and what calendar trade would express that?`,
                  page: "Rolls",
                })
              }
            >
              Explain
            </button>
            <button
              className="btn"
              disabled={!data}
              onClick={() => data && downloadText("vol-rolls.csv", toCsv(data.series.dates.map((date, i) => ({
                date, front: data.series.front[i], back: data.series.back[i], front_vol: data.series.front_vol[i],
                back_vol: data.series.back_vol[i], spread: data.series.spread[i], dte: data.series.dte[i], source: data.series.source[i],
              }))))}
            >
              CSV
            </button>
          </>
        }
      >
        <Field label="Pair">
          <span className="flex items-center gap-1">
            <select value={front} onChange={(e) => { const v = Number(e.target.value); setFront(v); if (back <= v) setBack(v + 1); }}>
              {[1, 2, 3, 4].map((m) => <option key={m} value={m}>M+{m}</option>)}
            </select>
            <span className="text-mute">−</span>
            <select value={back} onChange={(e) => setBack(Number(e.target.value))}>
              {[2, 3, 4, 5, 6].filter((m) => m > front).map((m) => <option key={m} value={m}>M+{m}</option>)}
            </select>
          </span>
        </Field>
        <Field label="Strike" hint="Pillar to compare across the two expiries, or type any call delta">
          <span className="flex items-center gap-1">
            <select value={delta} onChange={(e) => { setDelta(Number(e.target.value)); setCustom(""); }}>
              {DELTAS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
            </select>
            <input className="w-14" value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="Δ" title="Custom call delta, e.g. 35" />
          </span>
        </Field>
        <Field label="Days before expiry">
          <Segmented value={String(lookback)} onChange={(v) => setLookback(Number(v))} options={[30, 45, 60, 90].map((d) => ({ value: String(d), label: String(d) }))} />
        </Field>
      </Toolbar>

      <Problem error={rolls.error} warning={extrapolated > 0.25 ? `${pct(extrapolated, 0)} of these points needed the skew extrapolated beyond 90–110% moneyness. Treat this delta as indicative; ATM is the cleanest read.` : null} />
      {rolls.isPending && <div className="skeleton mb-3 h-24" />}

      {data && s?.current && (
        <Tiles>
          <Tile k={`${s.current.pair}, ${deltaLabel}`} v={`${signed(s.current.spread * 100, 1)} pts`} tone={s.current.spread} sub={`${volPts(s.current.front_vol)} − ${volPts(s.current.back_vol)}`} />
          <Tile k="Days to M+1 expiry" v={String(s.current.dte)} />
          <Tile k={`Past cycles at ${s.current.dte}d`} v={s.median_at_same_dte == null ? "—" : `${signed(s.median_at_same_dte * 100, 1)} pts`} sub={`today at ${pct(s.percentile_at_same_dte ?? null, 0)} pctile`} hint="Median spread of completed cycles at the same days to expiry, and where today sits among them" />
          <Tile k="Median move into expiry" v={s.median_change_to_expiry == null ? "—" : `${signed(s.median_change_to_expiry * 100, 1)} pts`} tone={s.median_change_to_expiry} sub={s.share_rising_to_expiry == null ? undefined : `rose in ${pct(s.share_rising_to_expiry, 0)} of ${s.cycles_to_expiry}`} hint="How the spread changed from this many days out to expiry in past cycles" />
        </Tiles>
      )}

      {data && (
        <>
          <div className="grid gap-3 xl:grid-cols-[1.4fr_1fr]">
            <Panel title="Spread into the M+1 expiry, vol pts" size="lg" right={<span className="text-[11px]">band: 25–75% of completed cycles</span>}>
              <EChart option={overlay} />
            </Panel>
            <Panel title="By cycle, at days to expiry" size="lg" pad={false}>
              <div className="h-full overflow-auto">
                <table className="blotter">
                  <thead className="sticky top-0 bg-raised">
                    <tr>
                      <Th>Pair</Th>
                      {CHECKPOINTS.map((d) => <Th key={d} right>{d}d</Th>)}
                      <Th />
                    </tr>
                  </thead>
                  <tbody>
                    {[...data.cycles].reverse().map((c) => {
                      const row = checkpoints(c.points);
                      return (
                        <tr key={c.front} className={`${c.complete ? "" : "text-accent"} ${hidden.has(c.label) ? "opacity-40" : ""}`}>
                          <Td mono={false}>{c.label}{c.complete ? "" : " (live)"}</Td>
                          {CHECKPOINTS.map((d) => {
                            const v = row[`d${d}`];
                            return <Td key={d} right tone={v}>{v == null ? "" : signed(v * 100, 1)}</Td>;
                          })}
                          <Td right>
                            <button className="text-mute hover:text-ink" title="Show or hide on the chart" onClick={() => toggle(c.label)}>
                              {hidden.has(c.label) ? "○" : "●"}
                            </button>
                          </Td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Panel>
            <Panel title={`M+${data.front} and M+${data.back} through time, ${deltaLabel}`} size="lg" className="xl:col-span-2" right={<span className="text-[11px]">dotted: front expiries, where the pair rolls</span>}>
              <EChart option={series} />
            </Panel>
          </div>
          <Note>
            Contract vol history on Bloomberg starts {data.history_from}, so the oldest complete cycle is {data.cycles[0]?.label ?? "—"}; the stored daily smiles extend it with real pillars from here on.
            {data.notes.length ? ` ${data.notes.join(" ")}` : ""}
          </Note>
        </>
      )}
    </Page>
  );

  function toggle(label: string) {
    setHidden((prev) => {
      const next = new Set(prev);
      if (next.has(label)) next.delete(label);
      else next.add(label);
      return next;
    });
  }
}

function checkpoints(points: RollPoint[]): Record<string, number | null> {
  const out: Record<string, number | null> = {};
  for (const d of CHECKPOINTS) {
    const near = points.filter((p) => Math.abs(p.dte - d) <= 2);
    out[`d${d}`] = near.length ? near.reduce((a, b) => (Math.abs(a.dte - d) <= Math.abs(b.dte - d) ? a : b)).spread : null;
  }
  return out;
}

function overlayChart(data: RollResult | undefined, hidden: Set<string>): EChartsOption {
  if (!data) return {};
  const p = data.profile;
  const shown = data.cycles.filter((c) => !hidden.has(c.label));
  const line = (c: RollCycle) => ({
    name: c.label,
    type: "line" as const,
    showSymbol: false,
    z: c.complete ? 2 : 5,
    lineStyle: c.complete ? { width: 1, opacity: 0.45 } : { width: 3, color: accent },
    itemStyle: c.complete ? undefined : { color: accent },
    emphasis: { focus: "series" as const, lineStyle: { width: 2.5, opacity: 1 } },
    data: c.points.map((pt) => [pt.dte, pt.spread * 100]),
  });
  return {
    tooltip: {
      ...tooltip,
      trigger: "item",
      formatter: (params: unknown) => {
        const q = params as { seriesName: string; data: [number, number] };
        return `${q.seriesName}<br/>${q.data[0]}d to expiry: ${q.data[1].toFixed(1)} pts`;
      },
    },
    legend: { show: false },
    grid: { left: 44, right: 16, top: 16, bottom: 36 },
    xAxis: { type: "value", ...axis(), inverse: true, min: 0, max: data.lookback, name: "Days to M+1 expiry", nameLocation: "middle", nameGap: 24 },
    yAxis: { type: "value", ...axis() },
    series: [
      { name: "p25", type: "line", stack: "band", showSymbol: false, silent: true, lineStyle: { opacity: 0 }, data: p.dte.map((d, i) => [d, p.p25[i] * 100]), tooltip: { show: false } },
      { name: "band", type: "line", stack: "band", showSymbol: false, silent: true, lineStyle: { opacity: 0 }, areaStyle: { color: warn, opacity: 0.12 }, data: p.dte.map((d, i) => [d, (p.p75[i] - p.p25[i]) * 100]), tooltip: { show: false } },
      { name: "Median of completed cycles", type: "line", showSymbol: false, z: 4, lineStyle: { color: warn, width: 2, type: "dashed" }, data: p.dte.map((d, i) => [d, p.median[i] * 100]) },
      ...shown.map(line),
      { name: "zero", type: "line", silent: true, showSymbol: false, data: [], markLine: { symbol: "none", silent: true, lineStyle: { color: mute, type: "solid", opacity: 0.4 }, label: { show: false }, data: [{ yAxis: 0 }] } },
    ],
  } as EChartsOption;
}

function seriesChart(data: RollResult | undefined): EChartsOption {
  if (!data) return {};
  const sr = data.series;
  const rolls = sr.dates.filter((_, i) => i > 0 && sr.front[i] !== sr.front[i - 1]);
  return {
    tooltip: {
      ...tooltip,
      trigger: "axis",
      formatter: (params: unknown) => {
        const rows = params as { dataIndex: number }[];
        const i = rows[0]?.dataIndex ?? 0;
        return `${sr.dates[i]} · ${sr.dte[i]}d to M+1 expiry<br/>` +
          `${sr.front[i].split(" ")[0]} ${volPts(sr.front_vol[i])} − ${sr.back[i].split(" ")[0]} ${volPts(sr.back_vol[i])} = ${signed(sr.spread[i] * 100, 1)} pts` +
          (sr.source[i] === "extrapolated" ? "<br/><i>skew extrapolated</i>" : "");
      },
    },
    legend: { textStyle: { color: mute, fontSize: 10 }, top: 0 },
    grid: [
      { left: 44, right: 16, top: 24, height: "38%" },
      { left: 44, right: 16, top: "60%", bottom: 28 },
    ],
    axisPointer: { link: [{ xAxisIndex: "all" }] },
    xAxis: [
      { type: "category", ...axis(), data: sr.dates, gridIndex: 0, axisLabel: { show: false } },
      { type: "category", ...axis(), data: sr.dates, gridIndex: 1 },
    ],
    yAxis: [
      { type: "value", ...axis(), gridIndex: 0, scale: true, axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v * 100)) } },
      { type: "value", ...axis(), gridIndex: 1, name: "pts" },
    ],
    dataZoom: [{ type: "inside", xAxisIndex: [0, 1] }],
    series: [
      { name: `M+${data.front}`, type: "line", showSymbol: false, xAxisIndex: 0, yAxisIndex: 0, data: sr.front_vol, lineStyle: { color: accent, width: 1.2 }, itemStyle: { color: accent } },
      { name: `M+${data.back}`, type: "line", showSymbol: false, xAxisIndex: 0, yAxisIndex: 0, data: sr.back_vol, lineStyle: { color: warn, width: 1.2 }, itemStyle: { color: warn } },
      {
        name: "Spread",
        type: "bar",
        xAxisIndex: 1,
        yAxisIndex: 1,
        barCategoryGap: 0,
        data: sr.spread.map((v) => ({ value: v * 100, itemStyle: { color: v >= 0 ? up : down } })),
        markLine: { symbol: "none", silent: true, label: { show: false }, lineStyle: { color: mute, type: "dotted", opacity: 0.6 }, data: rolls.map((d) => ({ xAxis: d })) },
      },
    ],
  } as EChartsOption;
}
