import { useQueries, useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, down, ink, mute, tooltip, up, warn } from "../components/charts/theme";
import { Field, Freshness, Gate, Loading, Note, Page, Panel, Problem, Segmented, Tile, Tiles, Toolbar } from "../components/ui";
import { butterfly, riskReversal } from "../model/chain";
import { downloadText, toCsv } from "../model/export";
import { pct, signed, volPts } from "../model/format";
import { VOL_YEARS, contractSmileQuery, volHistoryQuery, volTermQuery } from "../model/queries";
import { useLab } from "../store/lab";

type Fit = { n: number; intercept: number | null; slope: number | null; r2: number | null };

type VolHistory = {
  contract: string;
  warning: string | null;
  dates: string[];
  series: Record<
    "futures" | "atm" | "iv30" | "rv10" | "rv20" | "rv60" | "rv20_fwd" | "vrp20" | "corr60" | "beta60",
    (number | null)[]
  >;
  scatter: { ret: number[]; dvol: number[]; dates: string[] };
  levels_fit: Fit;
  changes_fit: Fit & { corr: number | null };
  cone: { window: number; min: number; p10: number; p25: number; p50: number; p75: number; p90: number; max: number; current: number }[];
  stats: {
    atm: number | null;
    atm_percentile: number | null;
    rv20: number | null;
    rv60: number | null;
    vrp20: number | null;
    mean_premium_realised: number | null;
    corr60: number | null;
    corr: number | null;
    beta: number | null;
    vol_pts_per_10pct: number | null;
    kappa?: number | null;
    xi?: number | null;
  };
};

type TermRow = {
  contract: string;
  label: string;
  option_expiry: string | null;
  days: number | null;
  forward: number | null;
  atm: number | null;
  atm_1w: number | null;
  atm_1m: number | null;
};

type Term = { product: string; contracts: TermRow[]; warning: string | null };

const SKEW_CONTRACTS = 8;
const LOOKBACKS = [1, 2, 3, 5];

export function Vol() {
  const market = useLab((s) => s.market);
  const setCalibration = useLab((s) => s.setCalibration);
  const product = market?.source?.product;
  const [contract, setContract] = useState<string>(market?.source?.contracts[0] ?? "");
  const [years, setYears] = useState(VOL_YEARS);
  const [applied, setApplied] = useState(false);

  useEffect(() => {
    if (market?.source?.contracts[0]) setContract(market.source.contracts[0]);
  }, [market?.source?.contracts[0]]);

  const term = useQuery({ ...volTermQuery<Term>(product ?? ""), enabled: !!product });

  const history = useQuery({ ...volHistoryQuery<VolHistory>(contract, years), enabled: !!contract });

  const skewContracts = (term.data?.contracts ?? []).slice(0, SKEW_CONTRACTS);
  const smiles = useQueries({ queries: skewContracts.map((row) => contractSmileQuery(row.contract)) });

  if (!product) {
    return <Gate title="Implied against realised, term structure and spot-vol co-movement." text="Find a market first. Everything here comes from the product's listed contracts." />;
  }

  const data = history.data;
  const s = data?.stats;
  const skew = skewContracts.map((row, i) => {
    const smile = smiles[i]?.data;
    return {
      label: row.label,
      rr: smile ? riskReversal(smile.pillars) : null,
      fly: smile ? butterfly(smile.pillars) : null,
    };
  });
  const loading = <Loading label="Loading history…" />;

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <Freshness queries={[term, history]} />
            <button
              className="btn"
              disabled={!s}
              title="Send spot-vol correlation, mean reversion and vol-of-vol to the Monte Carlo screen"
              onClick={() => {
                if (!s) return;
                setCalibration({ rho: s.corr, kappa: s.kappa ?? null, xi: s.xi ?? null, beta: s.beta });
                setApplied(true);
              }}
            >
              {applied ? "Sent to Monte Carlo ✓" : "Use in Monte Carlo"}
            </button>
            <button className="btn" disabled={!data} onClick={() => data && downloadText(`vol-${contract.split(" ")[0]}.csv`, toCsv(rowsOf(data)))}>
              CSV
            </button>
          </>
        }
      >
        <Field label="Contract">
          <select value={contract} onChange={(e) => setContract(e.target.value)}>
            {(term.data?.contracts ?? [{ contract, label: contract.replace(/ Comdty$/, "") } as TermRow]).map((row) => (
              <option key={row.contract} value={row.contract}>
                {row.label} · {row.contract.replace(/ Comdty$/, "")}
                {row.atm != null ? ` · ${volPts(row.atm)}` : ""}
              </option>
            ))}
          </select>
        </Field>
        <Field label="History">
          <Segmented value={String(years)} onChange={(v) => setYears(Number(v))} options={LOOKBACKS.map((y) => ({ value: String(y), label: `${y}y` }))} />
        </Field>
      </Toolbar>

      <Problem error={history.error} warning={data?.warning} />

      <Tiles>
        <Tile k="ATM implied" v={volPts(s?.atm)} />
        <Tile k="IV percentile" v={s?.atm_percentile == null ? "—" : pct(s.atm_percentile, 0)} hint={`Of the last ${years}y of this contract`} />
        <Tile k="Realised 20d" v={volPts(s?.rv20)} />
        <Tile k="Realised 60d" v={volPts(s?.rv60)} />
        <Tile k="IV − RV20" v={signed((s?.vrp20 ?? NaN) * 100, 1)} tone={s?.vrp20} hint="Positive: implied above recent realised" />
        <Tile k="Avg IV − realised after" v={signed((s?.mean_premium_realised ?? NaN) * 100, 1)} tone={s?.mean_premium_realised} hint="Implied minus the 20 sessions that followed, averaged over the history" />
        <Tile k="Spot-vol corr 60d" v={s?.corr60 == null ? "—" : s.corr60.toFixed(2)} />
        <Tile k="Vol pts per +10%" v={signed(s?.vol_pts_per_10pct, 1)} hint="Fitted change in ATM vol for a 10% move in the future" />
      </Tiles>

      <div className="grid gap-3 xl:grid-cols-2">
        <Panel title="Implied against realised" span={2} size="lg">
          {data ? <EChart option={ivRvChart(data)} /> : loading}
        </Panel>
        <Panel title="ATM term structure, now against a week and a month ago" size="lg">
          {term.isFetching && !term.data ? <Loading /> : <EChart option={termChart(term.data, skew)} />}
        </Panel>
        <Panel title="Realised vol cone, with implied by days to expiry" size="lg">
          {data ? <EChart option={coneChart(data, term.data)} /> : loading}
        </Panel>
        <Panel title={`Daily spot against vol changes${fitTitle(data)}`} size="lg">
          {data ? <EChart option={changesChart(data)} /> : loading}
        </Panel>
        <Panel title="Rolling 60d spot-vol correlation and beta" size="lg">
          {data ? <EChart option={rollingChart(data)} /> : loading}
        </Panel>
        <Panel title="Future against ATM implied, coloured by date" span={2} size="lg">
          {data ? <EChart option={levelsChart(data)} /> : loading}
        </Panel>
      </div>
      <Note>
        Realised vols are close-to-close, annualised on 252 days. IV percentile and the cone use this contract's own history over the lookback. Spot-vol beta is the slope of daily ATM changes on daily log returns of the future.
      </Note>
    </Page>
  );
}

const legend = { textStyle: { color: mute, fontSize: 10 }, top: 0 };
const pts = (v: number | null) => (v == null ? null : v * 100);
const volAxisLabel = { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v)) };

function fitTitle(data: VolHistory | undefined) {
  const fit = data?.changes_fit;
  if (!fit || fit.slope == null) return "";
  return ` · β ${(fit.slope * Math.log(1.1) * 100).toFixed(1)} pts per 10% · ρ ${fit.corr?.toFixed(2) ?? "—"} · R² ${fit.r2?.toFixed(2) ?? "—"}`;
}

function rowsOf(data: VolHistory) {
  return data.dates.map((date, i) => {
    const row: Record<string, unknown> = { date };
    for (const [key, values] of Object.entries(data.series)) row[key] = values[i];
    return row;
  });
}

function ivRvChart(data: VolHistory): EChartsOption {
  const s = data.series;
  return {
    tooltip: { ...tooltip, trigger: "axis", valueFormatter: (v) => (typeof v === "number" ? v.toFixed(1) : "—") },
    legend,
    grid: { left: 44, right: 44, top: 28, bottom: 52 },
    dataZoom: [{ type: "inside" }, { type: "slider", height: 14, bottom: 6, borderColor: "#2a2f38", textStyle: { color: mute } }],
    xAxis: { type: "category", data: data.dates, ...axis() },
    yAxis: [
      { type: "value", ...axis(), name: "vol", axisLabel: volAxisLabel, scale: true },
      { type: "value", ...axis(), name: "IV − RV", axisLabel: volAxisLabel, splitLine: { show: false } },
    ],
    series: [
      { name: "ATM implied", type: "line", showSymbol: false, data: s.atm.map(pts), lineStyle: { color: accent, width: 1.6 }, itemStyle: { color: accent } },
      { name: "30d constant maturity", type: "line", showSymbol: false, data: s.iv30.map(pts), lineStyle: { color: accent, width: 1, type: "dashed", opacity: 0.6 }, itemStyle: { color: accent } },
      { name: "Realised 20d", type: "line", showSymbol: false, data: s.rv20.map(pts), lineStyle: { color: warn, width: 1.4 }, itemStyle: { color: warn } },
      { name: "Realised 60d", type: "line", showSymbol: false, data: s.rv60.map(pts), lineStyle: { color: mute, width: 1 }, itemStyle: { color: mute } },
      { name: "Realised next 20d", type: "line", showSymbol: false, data: s.rv20_fwd.map(pts), lineStyle: { color: ink, width: 1, type: "dotted" }, itemStyle: { color: ink } },
      {
        name: "IV − RV20",
        type: "bar",
        yAxisIndex: 1,
        barWidth: "70%",
        data: s.vrp20.map((v) => ({ value: pts(v), itemStyle: { color: (v ?? 0) >= 0 ? up : down, opacity: 0.45 } })),
      },
    ],
  };
}

function termChart(data: Term | undefined, skew: { label: string; rr: number | null; fly: number | null }[]): EChartsOption {
  const rows = data?.contracts ?? [];
  if (!rows.length) {
    return { title: { text: data?.warning ?? "No listed expiries.", left: "center", top: "middle", textStyle: { color: mute, fontSize: 12, fontWeight: 400 } } };
  }
  const labels = rows.map((r) => r.label);
  const skewBy = new Map(skew.map((row) => [row.label, row]));
  return {
    tooltip: { ...tooltip, trigger: "axis", valueFormatter: (v) => (typeof v === "number" ? v.toFixed(1) : "—") },
    legend,
    grid: { left: 44, right: 44, top: 28, bottom: 40 },
    xAxis: {
      type: "category",
      data: labels,
      ...axis(),
      axisLabel: { ...axis().axisLabel, formatter: (label: string, i: number) => `${label}\n${rows[i]?.days ?? ""}d` },
    },
    yAxis: [
      { type: "value", ...axis(), name: "ATM", axisLabel: volAxisLabel, scale: true },
      { type: "value", ...axis(), name: "skew", axisLabel: volAxisLabel, splitLine: { show: false } },
    ],
    series: [
      { name: "Now", type: "line", symbolSize: 5, data: rows.map((r) => pts(r.atm)), lineStyle: { color: accent, width: 2 }, itemStyle: { color: accent } },
      { name: "1w ago", type: "line", symbolSize: 3, data: rows.map((r) => pts(r.atm_1w)), lineStyle: { color: warn, width: 1 }, itemStyle: { color: warn } },
      { name: "1m ago", type: "line", symbolSize: 3, data: rows.map((r) => pts(r.atm_1m)), lineStyle: { color: mute, width: 1, type: "dashed" }, itemStyle: { color: mute } },
      {
        name: "25d RR",
        type: "bar",
        yAxisIndex: 1,
        barWidth: 6,
        data: labels.map((l) => pts(skewBy.get(l)?.rr ?? null)),
        itemStyle: { color: "#7aa6c2", opacity: 0.7 },
      },
      {
        name: "25d fly",
        type: "bar",
        yAxisIndex: 1,
        barWidth: 6,
        data: labels.map((l) => pts(skewBy.get(l)?.fly ?? null)),
        itemStyle: { color: "#b39ddb", opacity: 0.7 },
      },
    ],
  };
}

function coneChart(data: VolHistory, term: Term | undefined): EChartsOption {
  const cone = data.cone;
  const at = (key: keyof VolHistory["cone"][number]) => cone.map((c) => [c.window, (c[key] as number) * 100]);
  const implied = (term?.contracts ?? [])
    .filter((r) => r.atm != null && r.days != null && r.days > 0)
    .map((r) => ({ value: [Math.round((r.days! * 252) / 365), r.atm! * 100], name: r.label }))
    .filter((p) => p.value[0] <= (cone[cone.length - 1]?.window ?? 120) * 1.2);
  const band = (name: string, lo: keyof VolHistory["cone"][number], hi: keyof VolHistory["cone"][number], opacity: number) => [
    { name, type: "line" as const, stack: name, showSymbol: false, lineStyle: { opacity: 0 }, data: at(lo), silent: true },
    {
      name,
      type: "line" as const,
      stack: name,
      showSymbol: false,
      lineStyle: { opacity: 0 },
      areaStyle: { color: warn, opacity },
      data: cone.map((c) => [c.window, ((c[hi] as number) - (c[lo] as number)) * 100]),
      silent: true,
    },
  ];
  return {
    tooltip: { ...tooltip, trigger: "item", formatter: (p: unknown) => {
      const item = p as { seriesName: string; value: number[]; name?: string };
      return `${item.name && item.seriesName === "Implied" ? item.name : item.seriesName}<br/>${item.value[0]} sessions · ${item.value[1].toFixed(1)}`;
    } },
    legend: { ...legend, data: ["10–90%", "25–75%", "Median", "Current", "Implied"] },
    grid: { left: 44, right: 16, top: 28, bottom: 32 },
    xAxis: { type: "value", ...axis(), name: "sessions", nameLocation: "middle", nameGap: 20, min: 0 },
    yAxis: { type: "value", ...axis(), axisLabel: volAxisLabel, scale: true },
    series: [
      ...band("10–90%", "p10", "p90", 0.12),
      ...band("25–75%", "p25", "p75", 0.22),
      { name: "Median", type: "line", showSymbol: false, data: at("p50"), lineStyle: { color: warn, width: 1.2 }, itemStyle: { color: warn } },
      { name: "Min/max", type: "line", showSymbol: false, data: at("max"), lineStyle: { color: mute, width: 1, type: "dotted" }, itemStyle: { color: mute } },
      { name: "Min/max", type: "line", showSymbol: false, data: at("min"), lineStyle: { color: mute, width: 1, type: "dotted" } },
      { name: "Current", type: "line", symbolSize: 6, data: at("current"), lineStyle: { color: ink, width: 1.4 }, itemStyle: { color: ink } },
      { name: "Implied", type: "scatter", symbol: "diamond", symbolSize: 10, data: implied, itemStyle: { color: accent } },
    ],
  };
}

function changesChart(data: VolHistory): EChartsOption {
  const { ret, dvol, dates } = data.scatter;
  const xs = ret.map((r) => r * 100);
  const fit = data.changes_fit;
  const lo = Math.min(...xs);
  const hi = Math.max(...xs);
  const line =
    fit.slope == null || fit.intercept == null
      ? []
      : [lo, hi].map((x) => [x, (fit.intercept! + fit.slope! * (x / 100)) * 100]);
  return {
    tooltip: { ...tooltip, trigger: "item", formatter: (p: unknown) => {
      const item = p as { value: number[]; seriesName: string };
      if (item.seriesName !== "Days") return "Fit";
      return `${dates[item.value[2]]}<br/>future ${signed(item.value[0], 2)}% · vol ${signed(item.value[1], 2)} pts`;
    } },
    grid: { left: 44, right: 16, top: 16, bottom: 32 },
    visualMap: { show: false, dimension: 2, seriesIndex: 0, min: 0, max: Math.max(xs.length - 1, 1), inRange: { color: ["#3c4452", "#7aa6c2", accent] } },
    xAxis: { type: "value", ...axis(), name: "future %", nameLocation: "middle", nameGap: 20 },
    yAxis: { type: "value", ...axis(), name: "Δ vol pts" },
    series: [
      { name: "Days", type: "scatter", symbolSize: 4, data: xs.map((x, i) => [x, dvol[i] * 100, i]) },
      { name: "Fit", type: "line", showSymbol: false, data: line, lineStyle: { color: warn, width: 1.5 } },
    ],
  };
}

function rollingChart(data: VolHistory): EChartsOption {
  return {
    tooltip: { ...tooltip, trigger: "axis", valueFormatter: (v) => (typeof v === "number" ? v.toFixed(2) : "—") },
    legend,
    grid: { left: 44, right: 48, top: 28, bottom: 32 },
    xAxis: { type: "category", data: data.dates, ...axis() },
    yAxis: [
      { type: "value", ...axis(), name: "corr", min: -1, max: 1 },
      { type: "value", ...axis(), name: "pts / 10%", splitLine: { show: false } },
    ],
    series: [
      {
        name: "Correlation",
        type: "line",
        showSymbol: false,
        data: data.series.corr60,
        lineStyle: { color: accent },
        itemStyle: { color: accent },
        markLine: { silent: true, symbol: "none", lineStyle: { color: mute, type: "dashed" }, data: [{ yAxis: 0 }], label: { show: false } },
      },
      {
        name: "Beta, vol pts per +10%",
        type: "line",
        yAxisIndex: 1,
        showSymbol: false,
        data: data.series.beta60.map((b) => (b == null ? null : b * Math.log(1.1) * 100)),
        lineStyle: { color: warn, width: 1 },
        itemStyle: { color: warn },
      },
    ],
  };
}

function levelsChart(data: VolHistory): EChartsOption {
  const pairs = data.dates
    .map((date, i) => ({ date, f: data.series.futures[i], v: data.series.atm[i] }))
    .filter((p) => p.f != null && p.v != null);
  const fit = data.levels_fit;
  const fs = pairs.map((p) => p.f as number);
  const line =
    fit.slope == null || fit.intercept == null || !fs.length
      ? []
      : Array.from({ length: 40 }, (_, k) => {
          const f = Math.min(...fs) + ((Math.max(...fs) - Math.min(...fs)) * k) / 39;
          return [f, (fit.intercept! + fit.slope! * Math.log(f)) * 100];
        });
  const last = pairs[pairs.length - 1];
  return {
    tooltip: { ...tooltip, trigger: "item", formatter: (p: unknown) => {
      const item = p as { value: number[]; seriesName: string };
      if (item.seriesName === "Fit") return "Fit";
      return `${pairs[item.value[2]]?.date ?? "now"}<br/>${item.value[0].toFixed(2)} · ${item.value[1].toFixed(1)}%`;
    } },
    grid: { left: 44, right: 24, top: 16, bottom: 32 },
    visualMap: {
      show: true,
      dimension: 2,
      min: 0,
      max: Math.max(pairs.length - 1, 1),
      orient: "horizontal",
      right: 8,
      top: 0,
      itemHeight: 80,
      itemWidth: 8,
      text: ["recent", "older"],
      textStyle: { color: mute, fontSize: 10 },
      inRange: { color: ["#0b3a66", "#1f6aa5", "#8ec4e0", "#e6c07b", "#e08a2e"] },
      seriesIndex: 0,
    },
    xAxis: { type: "value", ...axis(), name: "future", nameLocation: "middle", nameGap: 20, scale: true },
    yAxis: { type: "value", ...axis(), name: "ATM", axisLabel: volAxisLabel, scale: true },
    series: [
      { name: "Days", type: "scatter", symbolSize: 5, data: pairs.map((p, i) => [p.f as number, (p.v as number) * 100, i]) },
      { name: "Fit", type: "line", showSymbol: false, data: line, lineStyle: { color: mute, width: 1, type: "dashed" } },
      ...(last
        ? [{ name: "Now", type: "scatter" as const, symbol: "diamond", symbolSize: 12, data: [[last.f as number, (last.v as number) * 100, pairs.length - 1]], itemStyle: { color: ink, borderColor: "#14171c" } }]
        : []),
    ],
  };
}
