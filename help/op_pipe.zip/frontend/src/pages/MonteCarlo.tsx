import { useMutation } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, tooltip, warn } from "../components/charts/theme";
import { Empty, Field, Gate, Page, Panel, Problem, Segmented, Tile, Tiles, Toolbar } from "../components/ui";
import { postJson } from "../model/api";
import { pct, signed, tone } from "../model/format";
import { marketReady, toLegs, toMarketIn, type McResult } from "../model/types";
import { useLab } from "../store/lab";

export function MonteCarlo() {
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const regime = useLab((s) => s.regime);
  const calibration = useLab((s) => s.calibration);
  const setGhosts = useLab((s) => s.setGhosts);
  const setMcTerminal = useLab((s) => s.setMcTerminal);
  const [paths, setPaths] = useState(4000);
  const [steps, setSteps] = useState(48);
  const [kappa, setKappa] = useState(1);
  const [xi, setXi] = useState(0);
  const [rho, setRho] = useState(0);
  const [sigmaBar, setSigmaBar] = useState("");
  const [hedge, setHedge] = useState(false);
  const [seed, setSeed] = useState(7);

  const run = useMutation({
    mutationFn: () =>
      postJson<McResult>("/api/montecarlo", {
        market: toMarketIn(market!),
        legs: toLegs(legs),
        regime,
        n_paths: paths,
        n_steps: steps,
        kappa,
        xi,
        rho,
        sigma_bar: sigmaBar.trim() === "" ? null : Number(sigmaBar),
        seed,
        n_overlay: 30,
        hedge,
      }),
    onSuccess: (result) => {
      setGhosts(
        result.overlays.forward.map((path, i) =>
          path.map((spot, t) => ({ spot, vol: result.overlays.vol[i][t] })),
        ),
      );
      setMcTerminal({ edges: result.terminal.hist_edges, counts: result.terminal.hist_counts });
      const { hist_counts: _counts, hist_edges: _edges, ...stats } = result.terminal;
      setScreen("Monte Carlo", {
        n_paths: paths,
        n_steps: steps,
        params: result.params,
        terminal_pnl: stats,
        premium: result.premium,
        black_price: result.black_price,
        discounted_payoff_mean: result.discounted_payoff_mean,
      });
    },
  });
  const setScreen = useLab((s) => s.setScreen);
  const askCopilot = useLab((s) => s.askCopilot);

  if (!marketReady(market) || legs.length === 0) {
    return <Gate title="Simulate the structure out to expiry." text="Find a market and build legs in the Builder first." />;
  }

  const result = run.data;

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <button
              className="btn"
              disabled={!result}
              onClick={() => askCopilot({ mode: "chat", prompt: "Explain this Monte Carlo run. Is the risk/reward attractive, and what drives the tails?" })}
            >
              Explain
            </button>
            <button
              className="btn"
              disabled={!calibration}
              title={calibration ? "Fill ρ, κ and vol of vol from the latest regression (IV vs RV or Regimes)" : "Run a regression on IV vs RV or Regimes first"}
              onClick={() => {
                if (!calibration) return;
                if (calibration.rho != null) setRho(Number(calibration.rho.toFixed(3)));
                if (calibration.kappa != null) setKappa(Number(calibration.kappa.toFixed(2)));
                if (calibration.xi != null) setXi(Number(calibration.xi.toFixed(3)));
              }}
            >
              Use regression
            </button>
            <button className="btn btn-primary" disabled={run.isPending} onClick={() => run.mutate()}>
              {run.isPending ? "Simulating…" : "Run"}
            </button>
          </>
        }
      >
        <Num label="Paths" value={paths} onChange={setPaths} />
        <Num label="Steps" value={steps} onChange={setSteps} />
        <Num label="κ" hint="Mean reversion of log vol, per year" value={kappa} onChange={setKappa} step="0.1" />
        <Num label="Vol of vol" hint="Annualised vol of log vol. 0 gives a flat vol." value={xi} onChange={setXi} step="0.05" />
        <Num label="Spot-vol ρ" hint="Correlation between returns and vol changes" value={rho} onChange={setRho} step="0.05" />
        <Field label="Vol mean" hint="Long-run vol in decimals; blank uses the entry ATM">
          <input className="w-16" value={sigmaBar} onChange={(e) => setSigmaBar(e.target.value)} placeholder="ATM" />
        </Field>
        <Num label="Seed" value={seed} onChange={setSeed} />
        <Field label="Hedge" hint="Delta hedge along each path">
          <Segmented value={hedge ? "on" : "off"} onChange={(v) => setHedge(v === "on")} options={[{ value: "off", label: "Off" }, { value: "on", label: "Daily Δ" }]} />
        </Field>
      </Toolbar>

      <Problem error={run.error} />
      {run.isPending && <div className="skeleton mb-3 h-16" />}
      {result && (
        <Tiles>
          <Tile k="Mean P&L" v={signed(result.terminal.mean)} tone={tone(result.terminal.mean)} />
          <Tile k="P(profit)" v={pct(result.terminal.prob_profit, 0)} />
          <Tile k="5% / 95%" v={`${signed(result.terminal.p5)} / ${signed(result.terminal.p95)}`} />
          <Tile k="Expected shortfall 95" v={signed(result.terminal.es_95)} tone="down" hint="Mean of the worst 5% of outcomes" />
          <Tile k="Black price" v={signed(result.black_price)} sub={`MC payoff ${signed(result.discounted_payoff_mean)}`} hint="With vol of vol 0 and no correlation, the mean discounted payoff should sit on the Black price" />
        </Tiles>
      )}
      {!result && !run.isPending && (
        <Empty>Set the dynamics and run. Defaults are a flat vol uncorrelated with spot, not a market estimate. The path cloud is also drawn on the Path screen.</Empty>
      )}
      {result && (
        <div className="grid gap-3 xl:grid-cols-2">
          <Panel title="Forward fan"><EChart option={fan(result, "spot", "Forward")} /></Panel>
          <Panel title="Vol fan"><EChart option={fan(result, "vol", "Vol", true)} /></Panel>
          <Panel title="P&L fan"><EChart option={fan(result, "pnl", "P&L")} /></Panel>
          <Panel title="Terminal P&L"><EChart option={histogram(result)} /></Panel>
        </div>
      )}
    </Page>
  );
}

function Num({ label, value, onChange, step = "1", hint }: { label: string; value: number; onChange: (n: number) => void; step?: string; hint?: string }) {
  return (
    <Field label={label} hint={hint}>
      <input className="w-20" type="number" step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </Field>
  );
}

function fan(result: McResult | undefined, key: "spot" | "vol" | "pnl", name: string, asVol = false): EChartsOption {
  if (!result) return {};
  const scale = (v: number) => (asVol ? v * 100 : v);
  return {
    tooltip,
    legend: { textStyle: { color: "#8d938c", fontSize: 10 }, top: 0 },
    grid: { left: 48, right: 12, top: 28, bottom: 28 },
    xAxis: { type: "value", ...axis(), name: "Days" },
    yAxis: { type: "value", ...axis(), name },
    series: [
      { name: "p50", type: "line", showSymbol: false, lineStyle: { color: accent }, data: result.times.map((t, i) => [t * 365.25, scale(result[key].p50[i])]) },
      { name: "p25", type: "line", showSymbol: false, lineStyle: { color: accent, opacity: 0.45 }, data: result.times.map((t, i) => [t * 365.25, scale(result[key].p25[i])]) },
      { name: "p75", type: "line", showSymbol: false, lineStyle: { color: accent, opacity: 0.45 }, data: result.times.map((t, i) => [t * 365.25, scale(result[key].p75[i])]) },
      { name: "p5", type: "line", showSymbol: false, lineStyle: { color: warn, type: "dashed" }, data: result.times.map((t, i) => [t * 365.25, scale(result[key].p5[i])]) },
      { name: "p95", type: "line", showSymbol: false, lineStyle: { color: warn, type: "dashed" }, data: result.times.map((t, i) => [t * 365.25, scale(result[key].p95[i])]) },
    ],
  };
}

function histogram(result: McResult | undefined): EChartsOption {
  if (!result) return {};
  const { hist_counts: counts, hist_edges: edges } = result.terminal;
  return {
    tooltip,
    grid: { left: 40, right: 12, top: 16, bottom: 28 },
    xAxis: { type: "category", ...axis(), data: counts.map((_, i) => ((edges[i] + edges[i + 1]) / 2).toFixed(1)) },
    yAxis: { type: "value", ...axis() },
    series: [{ type: "bar", data: counts, itemStyle: { color: accent } }],
  };
}
