import { useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useMemo, useState } from "react";
import { EChart } from "../components/charts/EChart";
import { accent, axis, down, mute, tooltip, up, warn } from "../components/charts/theme";
import { Field, Freshness, Gate, Note, Page, Panel, Problem, Segmented, Td, Th, Tile, Tiles, Toolbar } from "../components/ui";
import { downloadText, toCsv } from "../model/export";
import { pct, px, signed, tone, volPts } from "../model/format";
import type { BacktestResult, BreakevenResult } from "../model/history";
import { BACKTEST_DEFAULTS, backtestQuery, breakevenQuery, defaultHold, type Hold } from "../model/queries";
import { marketReady } from "../model/types";
import { useLab } from "../store/lab";

const EVERY = [
  { value: 5, label: "Weekly" },
  { value: 10, label: "Fortnightly" },
  { value: 21, label: "Monthly" },
  { value: 63, label: "Quarterly" },
];

export function Backtest() {
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const regime = useLab((s) => s.regime);
  const askCopilot = useLab((s) => s.askCopilot);
  const setScreen = useLab((s) => s.setScreen);
  const [years, setYears] = useState(BACKTEST_DEFAULTS.years);
  const [every, setEvery] = useState(BACKTEST_DEFAULTS.every);
  const [hedge, setHedge] = useState(BACKTEST_DEFAULTS.hedge);
  const [hedgeDelta, setHedgeDelta] = useState(BACKTEST_DEFAULTS.hedgeDelta);
  const [hedgeCostBps, setHedgeCostBps] = useState(BACKTEST_DEFAULTS.hedgeCostBps);
  const [hedgeBand, setHedgeBand] = useState(BACKTEST_DEFAULTS.hedgeBand);
  const [entryCostPts, setEntryCostPts] = useState(BACKTEST_DEFAULTS.entryCostPts);
  const [holdChoice, setHoldChoice] = useState<Hold | undefined>(BACKTEST_DEFAULTS.hold);
  const [showRegimes, setShowRegimes] = useState(true);
  const ready = marketReady(market) && legs.length > 0 && !!market.source;
  const multiExpiry = new Set(legs.map((leg) => leg.expiry)).size > 1;
  const hold = holdChoice ?? defaultHold(legs);

  const backtest = useQuery({
    ...backtestQuery(market!, legs, regime, { years, every, hedge, hedgeDelta, hedgeCostBps, hedgeBand, entryCostPts, hold: holdChoice }),
    enabled: ready,
  });
  const breakeven = useQuery({ ...breakevenQuery(market!, legs, regime, years), enabled: ready });

  const bt = backtest.data;
  const be = breakeven.data;

  useEffect(() => {
    if (!bt && !be) return;
    setScreen("Backtest", {
      generic_of: market?.source?.contracts[0],
      backtest: bt ? { settings: bt.settings, metrics: bt.metrics, by_regime: bt.regimes.filter((r) => r.n > 0), assumptions: bt.assumptions } : null,
      breakeven: be
        ? { tenor_days: be.tenor_days, premium: be.premium, atm: be.atm, breakevens: be.breakevens, move_p5: be.moves.p5, move_p95: be.moves.p95, realised: { ...be.realised, dates: undefined, rv: undefined, iv: undefined } }
        : null,
    });
  }, [bt, be, market, setScreen]);

  const equity = useMemo(() => equityChart(bt, showRegimes), [bt, showRegimes]);
  const hist = useMemo(() => histChart(bt), [bt]);
  const scatter = useMemo(() => scatterChart(bt), [bt]);
  const moves = useMemo(() => movesChart(be), [be]);
  const rv = useMemo(() => rvChart(be), [be]);

  if (!ready) {
    return (
      <Gate
        title="Backtest a structure on the product's history."
        text="Find a market and build legs in the Builder. The backtest re-opens the same structure, at the same days to expiry and the same deltas, through the generic contract's history."
      />
    );
  }

  const m = bt?.metrics;
  const unit = market!.currency;
  const a = m?.attribution;
  const costs = (a?.hedge_cost ?? 0) + (a?.entry_cost ?? 0);

  return (
    <Page>
      <Toolbar
        actions={
          <>
            <Freshness queries={[backtest, breakeven]} />
            <button
              className="btn"
              disabled={!bt && !be}
              onClick={() =>
                askCopilot({
                  mode: "chat",
                  prompt: "Read this backtest and breakeven study. Was the structure worth owning historically, when did it lose, how often did history reach the breakevens, and what would you change?",
                  page: "Backtest",
                })
              }
            >
              Explain
            </button>
            <button className="btn" disabled={!bt} onClick={() => bt && downloadText("backtest.csv", toCsv(bt.trades as unknown as Record<string, unknown>[]))}>
              CSV
            </button>
          </>
        }
      >
        <Field label="Years">
          <select value={years} onChange={(e) => setYears(Number(e.target.value))}>
            {[2, 3, 4, 6, 8, 10].map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        </Field>
        <Field label="Enter">
          <select value={every} onChange={(e) => setEvery(Number(e.target.value))}>
            {EVERY.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </Field>
        <Field label="Hedge" hint="Off: hold the options to expiry. Smile: delta from repricing with the future bumped under the chosen regime (Bartlett's delta under sticky-delta). Black: plain Black-76 forward delta.">
          <Segmented
            value={hedge ? hedgeDelta : "none"}
            onChange={(v) => {
              if (v === "none") setHedge(false);
              else {
                setHedge(true);
                setHedgeDelta(v);
              }
            }}
            options={[{ value: "none", label: "None" }, { value: "smile", label: "Smile Δ" }, { value: "black", label: "Black Δ" }]}
          />
        </Field>
        {hedge && (
          <>
            <Field label="Futures cost, bp" hint="Half spread on every futures trade, in basis points of notional">
              <input className="w-16" type="number" min={0} max={100} step={0.5} value={hedgeCostBps} onChange={(e) => setHedgeCostBps(Number(e.target.value))} />
            </Field>
            <Field label="Band, lots" hint="Rebalance only when the delta gap exceeds this many lots. 0 rebalances every day.">
              <input className="w-16" type="number" min={0} max={100} step={0.1} value={hedgeBand} onChange={(e) => setHedgeBand(Number(e.target.value))} />
            </Field>
          </>
        )}
        {multiExpiry && (
          <Field label="Hold to" hint="Front: close the whole structure when the first leg expires. Last: each leg settles at its own expiry (exercised into the future if in the money), held until the last one. Strips default to last.">
            <Segmented value={hold} onChange={setHoldChoice} options={[{ value: "front", label: "Front expiry" }, { value: "last", label: "Last expiry" }]} />
          </Field>
        )}
        <Field label="Entry cost, vol pts" hint="Half spread paid on entry, in vol points, on each leg's vega">
          <input className="w-16" type="number" min={0} max={10} step={0.1} value={entryCostPts} onChange={(e) => setEntryCostPts(Number(e.target.value))} />
        </Field>
        <span className="pb-1 text-mute">
          {market!.source!.contracts[0].replace(/ Comdty$/, "")} generic · {legs.length} leg{legs.length === 1 ? "" : "s"} · {regime}
        </span>
      </Toolbar>

      <Problem error={backtest.error} />
      {backtest.isPending && <div className="skeleton mb-3 h-20" />}
      {m && (
        <Tiles>
          <Tile k="Trades" v={String(m.n)} sub={`${bt!.settings.from} → ${bt!.settings.to}`} />
          <Tile k="Hit rate" v={pct(m.hit_rate, 0)} />
          <Tile k={`Mean / trade, ${unit}`} v={signed(m.mean, 0)} tone={tone(m.mean)} sub={`median ${signed(m.median, 0)}`} />
          <Tile k="Total" v={signed(m.total, 0)} tone={tone(m.total)} sub={costs > 0 ? `${signed(m.gross_total, 0)} before costs` : undefined} />
          <Tile k="Worst / best" v={`${signed(m.worst, 0)} / ${signed(m.best, 0)}`} />
          <Tile k="Max drawdown" v={signed(m.max_drawdown, 0)} tone="down" />
          <Tile k="Sharpe" v={px(m.sharpe, 2)} sub={`profit factor ${px(m.profit_factor, 2)}`} />
          <Tile k="Avg premium" v={signed(m.avg_premium, 0)} />
        </Tiles>
      )}
      {a && (
        <Tiles>
          <Tile k="Carry (Γ + θ)" v={signed(a.carry, 0)} tone={tone(a.carry)} hint="Mean per trade. Gamma + theta: the realised-against-implied variance term." />
          <Tile k="Gamma" v={signed(a.gamma, 0)} tone={tone(a.gamma)} hint="½ Γ ΔF² with the previous day's gamma" />
          <Tile k="Theta" v={signed(a.theta, 0)} tone={tone(a.theta)} hint="One day of decay at unchanged future and vol" />
          <Tile k="Vega" v={signed(a.vega, 0)} tone={tone(a.vega)} hint="Vega × change in ATM" />
          <Tile k="Delta" v={signed(a.delta, 0)} tone={tone(a.delta)} hint="Option delta × move in the future" />
          {a.hedge != null && <Tile k="Hedge" v={signed(a.hedge, 0)} tone={tone(a.hedge)} hint="Futures hedge P&L" />}
          <Tile k="Residual" v={signed(a.residual, 0)} hint="What the first-order greeks do not explain" />
          {costs > 0 && <Tile k="Costs" v={signed(-costs, 0)} tone="down" sub={[a.hedge_cost ? `hedge ${signed(-a.hedge_cost, 0)}` : null, a.entry_cost ? `entry ${signed(-a.entry_cost, 0)}` : null].filter(Boolean).join(" · ")} />}
          <Tile k="Realised − implied" v={volPts(m!.mean_realised_minus_implied)} tone={tone(m!.mean_realised_minus_implied)} sub={`realised above ${pct(m!.share_realised_above_implied, 0)} of trades`} hint="Average over trades of realised vol over the hold minus the ATM paid at entry" />
        </Tiles>
      )}

      {bt && (
        <div className="grid gap-3 xl:grid-cols-3">
          <Panel
            title={`Cumulative P&L, ${unit}`}
            span={2}
            right={
              <label className="flex items-center gap-1 text-[11px]">
                <input type="checkbox" checked={showRegimes} onChange={(e) => setShowRegimes(e.target.checked)} /> Regimes
              </label>
            }
          >
            <EChart option={equity} />
          </Panel>
          <Panel title="P&L per trade">
            <EChart option={hist} />
          </Panel>
          <Panel title="P&L against the move in the future" span={2}>
            <EChart option={scatter} />
          </Panel>
          <Panel title="Assumptions" size="md">
            <div className="h-full overflow-auto p-2 text-[12px] text-mute">
              <p className="mb-2">
                Entries every {bt.settings.every} sessions, held {bt.settings.hold_days} days to the {bt.settings.hold === "last" ? "last" : "front"} expiry
                {bt.settings.hedge
                  ? `, hedged with the ${bt.settings.hedge_delta === "black" ? "Black-76 forward" : "smile-consistent"} delta${
                      bt.settings.hedge_band ? ` when the gap exceeds ${bt.settings.hedge_band} lots` : " daily"
                    }${bt.settings.hedge_cost_bps ? ` at ${bt.settings.hedge_cost_bps} bp per futures trade` : ", free of cost"}`
                  : ", unhedged"}
                {bt.settings.entry_cost_vol ? `; ${(bt.settings.entry_cost_vol * 100).toFixed(1)} vol points paid on entry` : ""}.
              </p>
              <ul className="list-disc space-y-1 pl-4">
                {bt.assumptions.map((x) => <li key={x}>{x}</li>)}
              </ul>
            </div>
          </Panel>
        </div>
      )}

      {bt && (
        <Panel title="By regime" size="auto" pad={false} className="mt-3" right={<span className="text-[11px]">trades grouped by entry date</span>}>
          <table className="blotter">
            <thead>
              <tr>
                <Th>Regime</Th>
                <Th>Window</Th>
                <Th right>Trades</Th>
                <Th right>Hit rate</Th>
                <Th right>{`Mean, ${unit}`}</Th>
                <Th right>Total</Th>
                <Th right>Worst</Th>
                <Th right hint="Average realised vol over the hold minus the ATM paid at entry">Realised − implied</Th>
              </tr>
            </thead>
            <tbody>
              {bt.regimes.map((r) => (
                <tr key={r.id} className={r.n ? "" : "opacity-40"} title={r.note}>
                  <Td mono={false}>{r.label}</Td>
                  <Td className="text-mute">{r.start} → {r.end > "2090" ? "today" : r.end}</Td>
                  <Td right>{r.n || "—"}</Td>
                  <Td right>{r.hit_rate == null ? "—" : pct(r.hit_rate, 0)}</Td>
                  <Td right className={tone(r.mean)}>{signed(r.mean, 0)}</Td>
                  <Td right className={tone(r.total)}>{signed(r.total, 0)}</Td>
                  <Td right className={tone(r.worst)}>{signed(r.worst, 0)}</Td>
                  <Td right className={tone(r.realised_minus_implied)}>{volPts(r.realised_minus_implied)}</Td>
                </tr>
              ))}
            </tbody>
          </table>
          {bt.regimes.some((r) => r.n === 0) && (
            <p className="px-2 pb-2 text-[11px] text-mute">
              Faded regimes have no trades: they are before the Years window, or before the product's implied-vol history starts (for TTF, Bloomberg's constant-maturity vols begin in August 2020).
            </p>
          )}
        </Panel>
      )}

      <h2 className="mb-2 mt-5 text-[13px] text-mute">Breakevens against history</h2>
      <Problem error={breakeven.error} />
      {breakeven.isPending && <div className="skeleton mb-3 h-20" />}
      {be && (
        <>
          <Tiles>
            <Tile k="Days to expiry" v={String(be.tenor_days)} sub={`${be.n_windows} overlapping windows`} />
            {be.breakevens.map((b) => (
              <Tile
                key={b.price}
                k={`Breakeven ${b.direction === "up" ? "above" : "below"}`}
                v={`${px(b.price)} (${signed(b.move * 100, 1)}%)`}
                sub={`history went beyond ${pct(b.hist_prob_beyond, 0)}`}
                hint="Log move from today's forward; share of historical windows that finished beyond it"
              />
            ))}
            <Tile k="ATM today" v={volPts(be.atm)} />
            <Tile k="Realised, median" v={volPts(be.realised.median)} sub={`above ATM ${pct(be.realised.share_above_atm, 0)}`} hint="Realised vol over each window; implied is the constant-maturity ATM at its start" />
            <Tile k="Implied − realised, avg" v={volPts(be.realised.mean_iv_minus_rv)} tone={tone(be.realised.mean_iv_minus_rv)} />
          </Tiles>
          <div className="grid gap-3 xl:grid-cols-2">
            <Panel title={`${be.tenor_days}-day moves, with the breakevens`}>
              <EChart option={moves} />
            </Panel>
            <Panel title="Realised over the window against implied at the start">
              <EChart option={rv} />
            </Panel>
          </div>
        </>
      )}
      <Note>
        Both studies run on the roll-adjusted generic. Option P&L is attributed each day with the previous day's greeks; the remainder is the residual.
      </Note>
    </Page>
  );
}

function regimeAreas(bt: BacktestResult, dates: string[]) {
  const areas = [];
  for (const [i, r] of bt.regimes.entries()) {
    const inside = dates.filter((d) => d >= r.start && d <= r.end);
    if (!inside.length) continue;
    areas.push([
      { xAxis: inside[0], name: r.label, itemStyle: { color: i % 2 ? "rgba(94,200,197,0.07)" : "rgba(228,225,216,0.05)" } },
      { xAxis: inside[inside.length - 1] },
    ]);
  }
  return areas;
}

function equityChart(bt: BacktestResult | undefined, regimes: boolean): EChartsOption {
  if (!bt) return {};
  return {
    tooltip: { ...tooltip, trigger: "axis" },
    legend: { textStyle: { color: mute, fontSize: 10 }, top: 0 },
    grid: { left: 64, right: 16, top: 28, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: bt.equity.dates },
    yAxis: { type: "value", ...axis() },
    series: [
      {
        name: "Cumulative",
        type: "line",
        showSymbol: false,
        data: bt.equity.pnl,
        lineStyle: { color: accent, width: 2 },
        ...(regimes
          ? { markArea: { silent: true, label: { color: mute, fontSize: 9, position: "insideTop" as const }, data: regimeAreas(bt, bt.equity.dates) as never } }
          : {}),
      },
      { name: "Drawdown", type: "line", showSymbol: false, data: bt.equity.drawdown, lineStyle: { color: down, width: 1 }, areaStyle: { color: down, opacity: 0.15 } },
    ],
  };
}

function histChart(bt: BacktestResult | undefined): EChartsOption {
  if (!bt) return {};
  const { counts, edges } = bt.histogram;
  const mids = counts.map((_, i) => (edges[i] + edges[i + 1]) / 2);
  return {
    tooltip,
    grid: { left: 40, right: 12, top: 16, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: mids.map((v) => Math.round(v).toLocaleString("en-GB")) },
    yAxis: { type: "value", ...axis() },
    series: [{ type: "bar", data: counts.map((c, i) => ({ value: c, itemStyle: { color: mids[i] >= 0 ? up : down } })) }],
  };
}

function scatterChart(bt: BacktestResult | undefined): EChartsOption {
  if (!bt) return {};
  return {
    tooltip: {
      ...tooltip,
      formatter: (p: unknown) => {
        const d = (p as { data: [number, number, string] }).data;
        return `${d[2]}<br/>move ${(d[0] * 100).toFixed(1)}%<br/>P&L ${Math.round(d[1]).toLocaleString("en-GB")}`;
      },
    },
    grid: { left: 64, right: 16, top: 16, bottom: 32 },
    xAxis: { type: "value", ...axis(), name: "Log move, %", axisLabel: { ...axis().axisLabel, formatter: (v: number) => (v * 100).toFixed(0) } },
    yAxis: { type: "value", ...axis() },
    series: [{
      type: "scatter",
      symbolSize: 6,
      data: bt.trades.map((t) => ({ value: [t.move, t.total, t.entry], itemStyle: { color: t.total >= 0 ? up : down } })),
    }],
  };
}

function movesChart(be: BreakevenResult | undefined): EChartsOption {
  if (!be) return {};
  const { counts, edges } = be.moves;
  const width = edges[1] - edges[0];
  const inside = (mid: number) => be.breakevens.every((b) => (b.direction === "up" ? mid < b.move : mid > b.move));
  return {
    tooltip,
    grid: { left: 40, right: 12, top: 16, bottom: 32 },
    xAxis: { type: "value", ...axis(), name: "%", min: edges[0], max: edges[edges.length - 1], axisLabel: { ...axis().axisLabel, formatter: (v: number) => (v * 100).toFixed(0) } },
    yAxis: { type: "value", ...axis() },
    series: [
      {
        type: "bar",
        barWidth: "95%",
        data: counts.map((c, i) => {
          const mid = edges[i] + width / 2;
          return { value: [mid, c], itemStyle: { color: inside(mid) ? "#3c4452" : warn } };
        }),
        markLine: {
          symbol: "none",
          label: { color: mute, fontSize: 10, formatter: (p: { value?: unknown }) => `${(Number(p.value) * 100).toFixed(1)}%` },
          lineStyle: { color: accent, type: "dashed" },
          data: be.breakevens.map((b) => ({ xAxis: b.move })),
        },
      },
    ],
  };
}

function rvChart(be: BreakevenResult | undefined): EChartsOption {
  if (!be) return {};
  return {
    tooltip: { ...tooltip, trigger: "axis" },
    legend: { textStyle: { color: mute, fontSize: 10 }, top: 0 },
    grid: { left: 40, right: 12, top: 28, bottom: 32 },
    xAxis: { type: "category", ...axis(), data: be.realised.dates },
    yAxis: { type: "value", ...axis(), axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v * 100)) } },
    series: [
      { name: "Realised", type: "line", showSymbol: false, data: be.realised.rv, lineStyle: { color: warn, width: 1 } },
      { name: "Implied", type: "line", showSymbol: false, data: be.realised.iv, lineStyle: { color: accent, width: 1 } },
      ...(be.atm
        ? [{ name: "ATM today", type: "line" as const, showSymbol: false, data: be.realised.dates.map(() => be.atm), lineStyle: { color: "#e4e1d8", type: "dashed" as const, width: 1 } }]
        : []),
    ],
  };
}
