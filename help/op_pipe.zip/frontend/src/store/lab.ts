import { create } from "zustand";
import { createJSONStorage, persist, type StateStorage } from "zustand/middleware";
import { alignLegs } from "../model/types";
import type { ControlPoint, GhostPath, HedgeFreq, Leg, Market, Regime, SearchHit, VolSource } from "../model/types";

type Calibration = {
  rho: number | null;
  kappa: number | null;
  xi: number | null;
  beta: number | null;
};

export type CopilotMode = "structure" | "critique" | "chat";
export type CopilotRequest = {
  id: string;
  mode: CopilotMode;
  prompt: string;
  page?: string;
  context?: Record<string, unknown>;
};

type LabState = {
  underlyingId: string;
  regime: Regime;
  followBeta: boolean;
  volSource: VolSource;
  hedge: HedgeFreq;
  market: Market | null;
  legs: Leg[];
  points: ControlPoint[];
  ghosts: GhostPath[];
  calibration: Calibration | null;
  mcTerminal: { edges: number[]; counts: number[] } | null;
  recentProducts: SearchHit[];
  paletteOpen: boolean;
  resolverOpen: boolean;
  copilotOpen: boolean;
  assistantTab: "copilot" | "resolver";
  copilotRequest: CopilotRequest | null;
  screen: Record<string, Record<string, unknown>>;
  setScreen: (page: string, context: Record<string, unknown> | null) => void;
  marketOpen: boolean;
  askCopilot: (request: Omit<CopilotRequest, "id">) => void;
  setUnderlyingId: (id: string) => void;
  setRegime: (regime: Regime) => void;
  setFollowBeta: (on: boolean) => void;
  setVolSource: (source: VolSource) => void;
  setHedge: (hedge: HedgeFreq) => void;
  setMarket: (market: Market | null) => void;
  setLegs: (legs: Leg[]) => void;
  updateLeg: (id: string, patch: Partial<Leg>) => void;
  setPoints: (points: ControlPoint[]) => void;
  setGhosts: (ghosts: GhostPath[]) => void;
  setCalibration: (calibration: Calibration | null) => void;
  setMcTerminal: (mcTerminal: { edges: number[]; counts: number[] } | null) => void;
  rememberProduct: (hit: SearchHit) => void;
  setPaletteOpen: (open: boolean) => void;
  setResolverOpen: (open: boolean) => void;
  setCopilotOpen: (open: boolean) => void;
  setAssistantTab: (tab: "copilot" | "resolver") => void;
  setMarketOpen: (open: boolean) => void;
  /** Stamped on Journal changes and comments. */
  userName: string;
  setUserName: (name: string) => void;
  /** Journal entries excluded from the risk book; everything else that is an open trade is in. */
  bookExcluded: string[];
  toggleBook: (id: string) => void;
};

// Each tab works on its own copy (sessionStorage). localStorage only seeds a new tab with the last saved state.
const tabStorage: StateStorage = {
  getItem: (name) => sessionStorage.getItem(name) ?? localStorage.getItem(name),
  setItem: (name, value) => {
    sessionStorage.setItem(name, value);
    localStorage.setItem(name, value);
  },
  removeItem: (name) => {
    sessionStorage.removeItem(name);
    localStorage.removeItem(name);
  },
};

export const useLab = create<LabState>()(
  persist(
    (set) => ({
      underlyingId: "TTF",
      regime: "sticky-delta",
      followBeta: false,
      volSource: "path",
      hedge: "none",
      market: null,
      legs: [],
      points: [],
      ghosts: [],
      calibration: null,
      mcTerminal: null,
      recentProducts: [],
      paletteOpen: false,
      resolverOpen: false,
      copilotOpen: false,
      assistantTab: "copilot",
      copilotRequest: null,
      screen: {},
      setScreen: (page, context) =>
        set((state) => {
          const screen = { ...state.screen };
          if (context) screen[page] = context;
          else delete screen[page];
          return { screen };
        }),
      marketOpen: false,
      askCopilot: (request) =>
        set({
          copilotOpen: true,
          assistantTab: "copilot",
          copilotRequest: { ...request, id: `${Date.now()}-${Math.random()}` },
        }),
      setUnderlyingId: (underlyingId) => set({ underlyingId }),
      setRegime: (regime) =>
        set({
          regime,
          followBeta: regime === "beta",
          volSource: regime === "beta" ? "beta" : "path",
        }),
      setFollowBeta: (followBeta) => set({ followBeta }),
      setVolSource: (volSource) => set({ volSource }),
      setHedge: (hedge) => set({ hedge }),
      setMarket: (market) =>
        set((state) => ({
          market,
          legs: market ? alignLegs(state.legs, state.market?.slices ?? null, market.slices) : state.legs,
        })),
      setLegs: (legs) => set({ legs }),
      updateLeg: (id, patch) =>
        set((state) => ({
          legs: state.legs.map((leg) => (leg.id === id ? { ...leg, ...patch } : leg)),
        })),
      setPoints: (points) => set({ points }),
      setGhosts: (ghosts) => set({ ghosts }),
      setCalibration: (calibration) => set({ calibration }),
      setMcTerminal: (mcTerminal) => set({ mcTerminal }),
      rememberProduct: (hit) =>
        set((state) => ({
          recentProducts: [hit, ...state.recentProducts.filter((p) => p.ticker !== hit.ticker)].slice(0, 6),
        })),
      setPaletteOpen: (paletteOpen) => set({ paletteOpen }),
      setResolverOpen: (resolverOpen) =>
        set(resolverOpen ? { resolverOpen: true, copilotOpen: true, assistantTab: "resolver" } : { resolverOpen: false, copilotOpen: false }),
      setCopilotOpen: (copilotOpen) => set(copilotOpen ? { copilotOpen: true, assistantTab: "copilot" } : { copilotOpen: false }),
      setAssistantTab: (assistantTab) => set({ assistantTab }),
      setMarketOpen: (marketOpen) => set({ marketOpen }),
      userName: "",
      setUserName: (userName) => set({ userName: userName.trim().slice(0, 40) }),
      bookExcluded: [],
      toggleBook: (id) =>
        set((state) => ({
          bookExcluded: state.bookExcluded.includes(id) ? state.bookExcluded.filter((x) => x !== id) : [...state.bookExcluded, id],
        })),
    }),
    {
      name: "structure-lab",
      version: 1,
      storage: createJSONStorage(() => tabStorage),
      partialize: (state) => ({
        underlyingId: state.underlyingId,
        regime: state.regime,
        followBeta: state.followBeta,
        volSource: state.volSource,
        hedge: state.hedge,
        market: state.market,
        legs: state.legs,
        points: state.points,
        calibration: state.calibration,
        recentProducts: state.recentProducts,
        userName: state.userName,
        bookExcluded: state.bookExcluded,
      }),
      merge: (persisted, current) => {
        const state = { ...current, ...(persisted as Partial<LabState>) };
        return { ...state, legs: alignLegs(state.legs, null, state.market?.slices ?? []) };
      },
    },
  ),
);
