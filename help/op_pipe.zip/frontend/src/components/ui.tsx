import type { ReactNode } from "react";
import { useLab } from "../store/lab";

/**
 * Shared page furniture so every screen reads the same way:
 * toolbar on top (controls left, actions right), a row of tiles, then panels of a fixed height.
 */

export function Page({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`h-full overflow-auto p-3 ${className}`}>{children}</div>;
}

/** Controls on the left, actions on the right. */
export function Toolbar({ children, actions }: { children?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-3 flex flex-wrap items-end gap-3 text-[12px]">
      {children}
      {actions && <div className="ml-auto flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

/** A labelled control in the toolbar. */
export function Field({ label, hint, children, className = "" }: { label: string; hint?: string; children: ReactNode; className?: string }) {
  return (
    <label className={`text-mute ${className}`} title={hint}>
      {label}
      <div className="mt-1">{children}</div>
    </label>
  );
}

/** Segmented control for short enumerations (regimes, sources, windows). */
export function Segmented<T extends string>({
  value,
  onChange,
  options,
  disabled,
}: {
  value: T;
  onChange: (value: T) => void;
  options: { value: T; label: string; hint?: string }[];
  disabled?: boolean;
}) {
  return (
    <div className="inline-flex overflow-hidden rounded-[2px] border border-line">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          disabled={disabled}
          title={option.hint}
          onClick={() => onChange(option.value)}
          className={`px-2 py-1 text-[12px] ${value === option.value ? "bg-accent text-[#101216]" : "text-mute hover:text-ink"} disabled:opacity-40`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

const HEIGHTS = { sm: "h-56", md: "h-72", lg: "h-80", xl: "h-96", auto: "" } as const;

export function Panel({
  title,
  right,
  children,
  size = "md",
  span,
  className = "",
  pad = true,
}: {
  title?: ReactNode;
  right?: ReactNode;
  children: ReactNode;
  size?: keyof typeof HEIGHTS;
  span?: 2 | 3;
  className?: string;
  pad?: boolean;
}) {
  const spanCls = span === 2 ? "xl:col-span-2" : span === 3 ? "xl:col-span-3" : "";
  return (
    <div className={`panel flex flex-col ${HEIGHTS[size]} ${spanCls} ${className}`}>
      {(title || right) && (
        <div className="panel-h shrink-0">
          <span className="truncate">{title}</span>
          {right && <span className="flex shrink-0 items-center gap-2">{right}</span>}
        </div>
      )}
      <div className={`min-h-0 flex-1 ${pad ? "p-1" : ""} ${size === "auto" ? "" : "overflow-hidden"}`}>{children}</div>
    </div>
  );
}

/** Row of headline numbers. */
export function Tiles({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`panel tiles mb-3 flex overflow-x-auto ${className}`}>{children}</div>;
}

export function Tile({
  k,
  v,
  hint,
  tone,
  sub,
  onClick,
  active,
}: {
  k: string;
  v: ReactNode;
  hint?: string;
  tone?: number | null | string;
  sub?: ReactNode;
  onClick?: () => void;
  active?: boolean;
}) {
  const cls =
    typeof tone === "string" ? tone : tone == null || !Number.isFinite(tone) || tone === 0 ? "" : tone > 0 ? "up" : "down";
  const Tag = onClick ? "button" : "div";
  return (
    <Tag
      className={`tile min-w-[7.5rem] flex-1 text-left ${onClick ? "hover:bg-[#20252d]" : ""} ${active ? "bg-[#20252d]" : ""}`}
      title={hint}
      onClick={onClick}
      type={onClick ? "button" : undefined}
    >
      <div className="k">{k}</div>
      <div className={`v ${cls === "warn" ? "text-warn" : cls}`}>{v}</div>
      {sub && <div className="text-[10px] text-mute">{sub}</div>}
    </Tag>
  );
}

export function Empty({ children = "Nothing to show yet." }: { children?: ReactNode }) {
  return <div className="flex h-full items-center justify-center p-4 text-center text-[12px] text-mute">{children}</div>;
}

export function Loading({ label = "Loading…" }: { label?: string }) {
  return <div className="flex h-full items-center justify-center text-[12px] text-mute">{label}</div>;
}

/** Inline problem text under the toolbar. */
export function Problem({ error, warning }: { error?: unknown; warning?: string | null }) {
  const message = error instanceof Error ? error.message : typeof error === "string" ? error : null;
  if (!message && !warning) return null;
  return (
    <div className="mb-2 space-y-1 text-[12px]">
      {message && <p className="text-down">{message}</p>}
      {warning && <p className="text-warn">{warning}</p>}
    </div>
  );
}

/** Small-print footnote: method, caveats, data source. */
export function Note({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <p className={`mt-3 text-[11px] leading-relaxed text-mute ${className}`}>{children}</p>;
}

/** Placeholder shown when a screen needs a Bloomberg market first. */
export function Gate({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  const setMarketOpen = useLab((s) => s.setMarketOpen);
  return (
    <div className="flex h-full items-center justify-center p-6">
      <div className="max-w-md text-center">
        <p className="text-[15px]">{title}</p>
        {text && <p className="mt-2 text-[13px] text-mute">{text}</p>}
        <div className="mt-4 flex justify-center gap-2">
          {action ?? (
            <button className="btn btn-primary" onClick={() => setMarketOpen(true)}>
              Find market
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export function Th({ children, right, className = "", hint }: { children?: ReactNode; right?: boolean; className?: string; hint?: string }) {
  return (
    <th className={`${right ? "text-right" : ""} ${className}`} title={hint}>
      {children}
    </th>
  );
}

export function Td({ children, right, className = "", tone, mono = true }: { children?: ReactNode; right?: boolean; className?: string; tone?: number | null | string; mono?: boolean }) {
  const toneCls =
    typeof tone === "string" ? tone : tone == null || !Number.isFinite(tone) || tone === 0 ? "" : tone > 0 ? "up" : "down";
  return <td className={`${right ? "text-right" : ""} ${mono ? "num" : ""} ${toneCls} ${className}`}>{children}</td>;
}

/** Pass / fail / unknown marker for a check. */
export function Flag({ ok, label, hint }: { ok: boolean | null | undefined; label: string; hint?: string }) {
  const cls = ok == null ? "text-mute" : ok ? "text-up" : "text-down";
  return (
    <span className={`inline-block rounded-[2px] border border-line px-1 text-[10px] ${cls}`} title={hint}>
      {label}
    </span>
  );
}

type FreshQuery = { data?: unknown; dataUpdatedAt: number; isFetching: boolean };
const STALE_AFTER = 15 * 60_000;

/**
 * When the numbers on screen were computed, and whether a newer copy is loading. Uses the server's
 * ``computed_at`` where the endpoint caches its result, otherwise when the browser received it; with
 * several queries it shows the oldest.
 */
export function Freshness({ queries }: { queries: FreshQuery[] }) {
  const times = queries
    .map((q) => {
      const stamp = (q.data as { computed_at?: string } | undefined)?.computed_at;
      return stamp ? Date.parse(stamp) : q.dataUpdatedAt || null;
    })
    .filter((t): t is number => t != null && Number.isFinite(t));
  const fetching = queries.some((q) => q.isFetching);
  if (!times.length && !fetching) return null;
  const at = times.length ? Math.min(...times) : null;
  const old = at != null && Date.now() - at > STALE_AFTER;
  const clock = at != null ? new Date(at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : null;
  return (
    <span
      className={`whitespace-nowrap text-[11px] ${old ? "text-warn" : "text-mute"}`}
      title={at != null ? `Computed ${new Date(at).toLocaleString()}${fetching ? ". A newer copy is loading." : ""}` : "Loading"}
    >
      {clock ? `as of ${clock}` : "loading"}
      {clock && fetching ? " · refreshing" : ""}
    </span>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return <kbd className="rounded-[2px] border border-line px-1 font-mono text-[10px] text-mute">{children}</kbd>;
}
