import * as Dialog from "@radix-ui/react-dialog";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { getJson } from "../../model/api";
import { refreshMarket, riskReversal } from "../../model/chain";
import { daysBetween, px, signed, volPts } from "../../model/format";
import { PILLARS, type Market, type Pillar, type Underlying } from "../../model/types";
import { useLab } from "../../store/lab";
import { Segmented } from "../ui";
import { MarketFinder } from "./MarketFinder";

type Draft = {
  asOf: string;
  currency: string;
  unit: string;
  ratePct: string;
  multiplier: string;
  beta: string;
  expiry: string;
  forward: string;
  atm: string;
  wings: Record<Pillar, string>;
  expiry2: string;
  forward2: string;
  atm2: string;
};

const EMPTY_WINGS: Record<Pillar, string> = { "10DC": "", "25DC": "", "50D": "", "25DP": "", "10DP": "" };

function draftFrom(market: Market | null): Draft {
  const slice = market?.slices[0];
  const back = market?.slices[1];
  const wings = { ...EMPTY_WINGS };
  for (const name of PILLARS) {
    const value = slice?.pillars[name];
    if (name !== "50D" && value != null) wings[name] = (value * 100).toFixed(2);
  }
  return {
    asOf: market?.asOf ?? new Date().toISOString().slice(0, 10),
    currency: market?.currency ?? "EUR",
    unit: market?.unit ?? "EUR/MWh",
    ratePct: market ? String(market.rate * 100) : "0",
    multiplier: market ? String(market.multiplier) : "1",
    beta: market?.beta != null ? String(market.beta) : "",
    expiry: slice?.expiry ?? "",
    forward: slice ? String(slice.forward) : "",
    atm: slice?.pillars["50D"] != null ? (slice.pillars["50D"] * 100).toFixed(2) : "",
    wings,
    expiry2: back?.expiry ?? "",
    forward2: back ? String(back.forward) : "",
    atm2: back?.pillars["50D"] != null ? ((back.pillars["50D"] ?? 0) * 100).toFixed(2) : "",
  };
}

function pillarsFrom(atm: string, wings: Record<Pillar, string>) {
  const out: Partial<Record<Pillar, number>> = { "50D": Number(atm) / 100 };
  for (const name of PILLARS) {
    if (name === "50D" || !wings[name]) continue;
    out[name] = Number(wings[name]) / 100;
  }
  return out;
}

export function MarketStrip() {
  const underlyingId = useLab((s) => s.underlyingId);
  const setUnderlyingId = useLab((s) => s.setUnderlyingId);
  const market = useLab((s) => s.market);
  const setMarket = useLab((s) => s.setMarket);
  const regime = useLab((s) => s.regime);
  const setRegime = useLab((s) => s.setRegime);
  const open = useLab((s) => s.marketOpen);
  const setOpen = useLab((s) => s.setMarketOpen);
  const [tab, setTab] = useState<"bloomberg" | "manual">("bloomberg");

  const underlyings = useQuery({
    queryKey: ["underlyings"],
    queryFn: () => getJson<{ underlyings: Underlying[] }>("/api/underlyings"),
  });

  const refresh = useMutation({
    mutationFn: (current: Market) => refreshMarket(current),
    onSuccess: (next) => setMarket(next),
  });

  const slice = market?.slices[0];
  const rr = slice ? riskReversal(slice.pillars) : null;
  const source = market?.source;
  const list = underlyings.data?.underlyings ?? [];

  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-line px-3 py-2 text-[12px]">
      {list.length > 1 && (
        <select aria-label="Underlying" value={underlyingId} onChange={(e) => setUnderlyingId(e.target.value)}>
          {list.map((u) => (
            <option key={u.id} value={u.id}>
              {u.id}
            </option>
          ))}
        </select>
      )}
      {slice ? (
        <>
          <span className="num" title={source?.description ?? "Manual market"}>
            <span className="text-accent">{source ? source.labels[0] : slice.expiry}</span>
            {source && <span className="ml-1.5 text-mute">{source.contracts[0].replace(/ Comdty$/, "")}</span>}
            {source?.labels[1] && <span className="ml-1.5 text-mute">/ {source.labels[1]}</span>}
            {!source && market!.slices[1] && <span className="ml-1.5 text-mute">/ {market!.slices[1].expiry}</span>}
          </span>
          <Readout k="F" v={px(slice.forward)} hint={`Future ${market!.unit ? `in ${market!.unit}` : ""}`} />
          <Readout k="ATM" v={volPts(slice.pillars["50D"])} hint="50-delta implied vol" />
          <Readout k="25Δ RR" v={rr == null ? "—" : signed(rr * 100, 1)} tone={rr} hint="25-delta call minus put vol" />
          <Readout k="DTE" v={String(daysBetween(market!.asOf, slice.expiry))} hint={`Option expiry ${slice.expiry} · as of ${market!.asOf}`} />
          {market!.multiplier !== 1 && <Readout k="Lot" v={`×${px(market!.multiplier, 0)}`} hint="Contract multiplier" />}
          {source?.volSource && <span className="text-[10px] uppercase tracking-wider text-mute/70" title="Where the smile vols came from">{source.volSource}</span>}
        </>
      ) : (
        <span className="text-mute">No market yet. Search Bloomberg for a product, or type one in.</span>
      )}
      <Segmented
        value={regime}
        onChange={setRegime}
        options={[
          { value: "sticky-delta", label: "Sticky Δ", hint: "Smile moves with the future: vol by delta is fixed" },
          { value: "sticky-strike", label: "Sticky K", hint: "Vol by strike is fixed as the future moves" },
          { value: "beta", label: "β", hint: "ATM follows the future with the market's beta" },
        ]}
      />
      {refresh.error && <span className="text-down">{(refresh.error as Error).message}</span>}
      <div className="ml-auto flex gap-2">
        {source && (
          <button
            className="btn"
            disabled={refresh.isPending}
            title="Pull the latest future and option-chain vols for this market"
            onClick={() => market && refresh.mutate(market)}
          >
            {refresh.isPending ? "Refreshing…" : "Refresh"}
          </button>
        )}
        <button
          className="btn btn-primary"
          onClick={() => {
            setTab("bloomberg");
            setOpen(true);
          }}
        >
          {slice ? "Change market" : "Find market"}
        </button>
      </div>

      <Dialog.Root open={open} onOpenChange={setOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-40 bg-black/60" />
          <Dialog.Content className="fixed left-1/2 top-[6%] z-50 max-h-[88vh] w-[min(980px,calc(100vw-24px))] -translate-x-1/2 overflow-auto border border-line bg-raised p-4">
            <div className="flex items-center justify-between gap-3">
              <Dialog.Title className="text-[15px]">Market</Dialog.Title>
              <div className="flex border border-line text-[12px]">
                {(["bloomberg", "manual"] as const).map((key) => (
                  <button
                    key={key}
                    className={`px-3 py-1 ${tab === key ? "bg-sunken text-accent" : "text-mute hover:text-ink"}`}
                    onClick={() => setTab(key)}
                  >
                    {key === "bloomberg" ? "Bloomberg" : "Manual"}
                  </button>
                ))}
              </div>
            </div>
            <Dialog.Description className="mt-1 text-[12px] text-mute">
              {tab === "bloomberg"
                ? "Search a product, pick an expiry. Future, option expiry and smile come from the listed option chain."
                : "Vols are in points: 48.2 is 48.2%. A rate of 0 prices in the forward measure."}
            </Dialog.Description>
            {tab === "bloomberg" ? <MarketFinder onDone={() => setOpen(false)} /> : <ManualForm onDone={() => setOpen(false)} />}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
  );
}

function Readout({ k, v, hint, tone }: { k: string; v: string; hint?: string; tone?: number | null }) {
  const cls = tone == null || !Number.isFinite(tone) || tone === 0 ? "" : tone > 0 ? "up" : "down";
  return (
    <span className="num" title={hint}>
      <span className="mr-1 text-[10px] text-mute">{k}</span>
      <span className={cls}>{v}</span>
    </span>
  );
}

function ManualForm({ onDone }: { onDone: () => void }) {
  const market = useLab((s) => s.market);
  const setMarket = useLab((s) => s.setMarket);
  const [draft, setDraft] = useState<Draft>(() => draftFrom(market));
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    setDraft(draftFrom(market));
  }, [market]);

  function save() {
    const forward = Number(draft.forward);
    const atm = Number(draft.atm);
    if (!draft.expiry || !(forward > 0) || !(atm > 0)) {
      setFormError("Forward, expiry and ATM vol are required. Vol is in points, so 48.2 means 48.2%.");
      return;
    }
    const slices = [{ expiry: draft.expiry, forward, pillars: pillarsFrom(draft.atm, draft.wings) }];
    if (draft.expiry2 || draft.forward2 || draft.atm2) {
      const forward2 = Number(draft.forward2);
      const atm2 = Number(draft.atm2);
      if (!draft.expiry2 || !(forward2 > 0) || !(atm2 > 0)) {
        setFormError("The second expiry needs its own forward and ATM vol, or leave all three blank.");
        return;
      }
      slices.push({ expiry: draft.expiry2, forward: forward2, pillars: { "50D": atm2 / 100 } });
    }
    const beta = draft.beta.trim() === "" ? null : Number(draft.beta);
    if (beta != null && !Number.isFinite(beta)) {
      setFormError("Beta has to be a number, or blank.");
      return;
    }
    setMarket({
      asOf: draft.asOf,
      rate: Number(draft.ratePct) / 100 || 0,
      multiplier: Number(draft.multiplier) || 1,
      currency: draft.currency || "EUR",
      unit: draft.unit || "",
      beta,
      slices,
    });
    onDone();
  }

  return (
    <>
      <div className="mt-3 grid grid-cols-2 gap-2 text-[12px] md:grid-cols-4">
        <Field label="As of" value={draft.asOf} type="date" onChange={(v) => setDraft({ ...draft, asOf: v })} />
        <Field label="Option expiry" value={draft.expiry} type="date" onChange={(v) => setDraft({ ...draft, expiry: v })} />
        <Field label="Forward" value={draft.forward} onChange={(v) => setDraft({ ...draft, forward: v })} />
        <Field label="ATM vol" value={draft.atm} onChange={(v) => setDraft({ ...draft, atm: v })} />
        {PILLARS.filter((name) => name !== "50D").map((name) => (
          <Field
            key={name}
            label={`${name} vol`}
            value={draft.wings[name]}
            onChange={(v) => setDraft({ ...draft, wings: { ...draft.wings, [name]: v } })}
          />
        ))}
        <Field label="Rate %" value={draft.ratePct} onChange={(v) => setDraft({ ...draft, ratePct: v })} />
        <Field label="Multiplier" value={draft.multiplier} onChange={(v) => setDraft({ ...draft, multiplier: v })} />
        <Field label="Currency" value={draft.currency} onChange={(v) => setDraft({ ...draft, currency: v })} />
        <Field label="Unit" value={draft.unit} onChange={(v) => setDraft({ ...draft, unit: v })} />
        <Field label="Beta, vol per log-forward" value={draft.beta} onChange={(v) => setDraft({ ...draft, beta: v })} />
      </div>
      <p className="mt-3 text-[12px] text-mute">Second expiry, for calendars and diagonals. Leave blank to skip.</p>
      <div className="mt-2 grid grid-cols-3 gap-2 text-[12px]">
        <Field label="Back expiry" value={draft.expiry2} type="date" onChange={(v) => setDraft({ ...draft, expiry2: v })} />
        <Field label="Back forward" value={draft.forward2} onChange={(v) => setDraft({ ...draft, forward2: v })} />
        <Field label="Back ATM" value={draft.atm2} onChange={(v) => setDraft({ ...draft, atm2: v })} />
      </div>
      {formError && <p className="mt-3 text-[12px] text-down">{formError}</p>}
      <div className="mt-4 flex justify-end gap-2">
        <Dialog.Close className="btn">Cancel</Dialog.Close>
        <button className="btn btn-primary" onClick={save}>Save market</button>
      </div>
    </>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <label className="block text-mute">
      {label}
      <input className="mt-1 w-full" type={type} value={value} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}
