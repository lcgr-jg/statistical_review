export type NavLinkDef = { to: string; label: string; key: string; end?: boolean; hint: string };

/** Pages grouped by what a trader is doing: pricing a structure, reading vol, managing trades. */
export const NAV_GROUPS: { name: string; links: NavLinkDef[] }[] = [
  {
    name: "Price",
    links: [
      { to: "/", label: "Builder", key: "b", end: true, hint: "Build and price a structure" },
      { to: "/path", label: "Path", key: "p", hint: "Draw a spot path and see the P&L along it" },
      { to: "/montecarlo", label: "Monte Carlo", key: "c", hint: "Terminal P&L distribution" },
    ],
  },
  {
    name: "Vol",
    links: [
      { to: "/surface", label: "Surface", key: "f", hint: "Every expiry fitted: skew, fly, SABR, checks" },
      { to: "/vol", label: "IV vs RV", key: "v", hint: "Implied against realised, cone, spot-vol" },
      { to: "/screener", label: "Screener", key: "s", hint: "Rank expiries by richness and skew" },
      { to: "/rolls", label: "Rolls", key: "o", hint: "Calendar roll-down and spread history" },
      { to: "/regimes", label: "Regimes", key: "r", hint: "Sticky-strike v sticky-delta evidence" },
    ],
  },
  {
    name: "Trade",
    links: [
      { to: "/backtest", label: "Backtest", key: "t", hint: "Delta-hedged history of the structure" },
      { to: "/journal", label: "Journal", key: "j", hint: "Saved ideas and their outcomes" },
      { to: "/risk", label: "Risk", key: "k", hint: "Historical VaR and stress of the open trades" },
      { to: "/deck", label: "Deck", key: "d", hint: "Printable trade summary" },
    ],
  },
];

export const NAV_LINKS = NAV_GROUPS.flatMap((group) => group.links);
