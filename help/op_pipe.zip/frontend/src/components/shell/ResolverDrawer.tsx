import { useState } from "react";
import { postJson, postSse } from "../../model/api";
import { useLab } from "../../store/lab";

type ToolRow = { name: string; preview: string };
type Check = { ticker: string; ok: boolean; purpose: string; value?: number | null; detail?: string | null };

export function ResolverDrawer({ embedded = false }: { embedded?: boolean }) {
  const open = useLab((s) => s.resolverOpen);
  const setOpen = useLab((s) => s.setCopilotOpen);
  const underlyingId = useLab((s) => s.underlyingId);
  const [input, setInput] = useState("Find the ICE TTF futures root and the delta-quoted vol tickers for 10 and 25 delta puts and calls, plus 50 delta.");
  const [transcript, setTranscript] = useState("");
  const [tools, setTools] = useState<ToolRow[]>([]);
  const [proposal, setProposal] = useState("");
  const [diff, setDiff] = useState("");
  const [checks, setChecks] = useState<Check[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [written, setWritten] = useState<string | null>(null);

  if (!embedded && !open) return null;

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setBusy(true);
    setError(null);
    setWritten(null);
    setTranscript("");
    setTools([]);
    setProposal("");
    setDiff("");
    setChecks([]);
    try {
      await postSse("/api/resolver/chat", {
        underlying_id: underlyingId,
        messages: [{ role: "user", content: text }],
      }, (event, data) => {
        if (event === "text") setTranscript((prev) => prev + String(data.delta ?? ""));
        if (event === "tool") {
          setTools((prev) => [...prev, { name: String(data.name), preview: String(data.preview ?? "") }]);
        }
        if (event === "error") setError(String(data.message ?? "Resolver failed"));
        if (event === "done" && data.proposal) {
          setProposal(JSON.stringify(data.proposal, null, 2));
        }
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Resolver failed");
    } finally {
      setBusy(false);
    }
  }

  async function preview() {
    setError(null);
    try {
      const body = JSON.parse(proposal);
      const result = await postJson<{ diff: string; checks: Check[] }>("/api/resolver/preview", body);
      setDiff(result.diff);
      setChecks(result.checks);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Preview failed");
    }
  }

  async function apply() {
    setError(null);
    try {
      const body = JSON.parse(proposal);
      const result = await postJson<{ written: string; checks: Check[] }>("/api/resolver/apply", body);
      setWritten(result.written);
      setChecks(result.checks);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Apply failed");
    }
  }

  const form = (
      <div className="min-h-0 flex-1 space-y-3 overflow-auto px-3 py-3 text-[12px]">
        <textarea className="h-24 w-full" value={input} onChange={(e) => setInput(e.target.value)} />
        <button className="btn btn-primary" disabled={busy} onClick={() => void send()}>
          {busy ? "Asking…" : `Ask about ${underlyingId}`}
        </button>
        {error && <p className="text-down">{error}</p>}
        {tools.map((tool, i) => (
          <details key={`${tool.name}-${i}`} className="border border-line px-2 py-1">
            <summary className="cursor-pointer">{tool.name}</summary>
            <pre className="mt-1 whitespace-pre-wrap text-mute">{tool.preview}</pre>
          </details>
        ))}
        {transcript && <pre className="whitespace-pre-wrap text-ink">{transcript}</pre>}
        <label className="block text-mute">
          Proposal
          <textarea className="mt-1 h-48 w-full" value={proposal} onChange={(e) => setProposal(e.target.value)} />
        </label>
        <div className="flex gap-2">
          <button className="btn" disabled={!proposal} onClick={() => void preview()}>Preview diff</button>
          <button className="btn btn-primary" disabled={!proposal} onClick={() => void apply()}>Apply</button>
        </div>
        {checks.length > 0 && (
          <ul className="space-y-1">
            {checks.map((check) => (
              <li key={check.ticker + check.purpose} className={check.ok ? "up" : "down"}>
                {check.purpose}: {check.ticker} {check.ok ? check.value : check.detail}
              </li>
            ))}
          </ul>
        )}
        {diff && <pre className="whitespace-pre-wrap text-mute">{diff}</pre>}
        {written && <p className="up">Wrote {written}. Reload the Bloomberg pull to use it.</p>}
      </div>
  );

  if (embedded) return form;
  return (
    <div className="fixed inset-y-0 right-0 z-30 flex w-[min(440px,100vw)] flex-col border-l border-line bg-raised">
      <div className="flex items-center justify-between border-b border-line px-3 py-2">
        <div>
          <div className="text-[13px]">Ticker resolver</div>
          <div className="text-[11px] text-mute">Reads Bloomberg through your MCP server. Nothing is saved until you apply.</div>
        </div>
        <button className="btn" onClick={() => setOpen(false)}>Close</button>
      </div>
      {form}
    </div>
  );
}
