import { useQuery } from "@tanstack/react-query";
import type { EChartsOption } from "echarts";
import { useEffect, useMemo, useRef, useState } from "react";
import { getJson } from "../../model/api";
import { butterfly, fetchSmile, riskReversal, sliceFromSmile } from "../../model/chain";
import { daysBetween, px, signed, volPts } from "../../model/format";
import { expiryListQuery } from "../../model/queries";
import {
  PILLARS,
  type ChainSmile,
  type ExpiryRow,
  type Market,
  type Pillar,
  type SearchHit,
  type SmileSource,
} from "../../model/types";
import { useLab } from "../../store/lab";
import { EChart } from "../charts/EChart";
import { accent, axis, ink, mute, tooltip, warn } from "../charts/theme";

const PILLAR_LABEL: Record<Pillar, string> = { "10DP": "10P", "25DP": "25P", "50D": "ATM", "25DC": "25C", "10DC": "10C" };
const PILLAR_ORDER: Pillar[] = ["10DP", "25DP", "50D", "25DC", "10DC"];
const PILLAR_DELTA: Record<Pillar, number> = { "10DC": 0.1, "25DC": 0.25, "50D": 0.5, "25DP": 0.75, "10DP": 0.9 };

type Props = { onDone: () => void };

export function MarketFinder({ onDone }: Props) {
  const market = useLab((s) => s.market);
  const setMarket = useLab((s) => s.setMarket);
  const recent = useLab((s) => s.recentProducts);
  const rememberProduct = useLab((s) => s.rememberProduct);

  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [product, setProduct] = useState<SearchHit | null>(null);
  const [front, setFront] = useState<string | null>(null);
  const [back, setBack] = useState<string | null>(null);
  const [edits, setEdits] = useState<Record<Pillar, string>>(blankEdits());
  const [perLot, setPerLot] = useState(true);
  const [beta, setBeta] = useState(market?.beta != null ? String(market.beta) : "");
  const [volSource, setVolSource] = useState<SmileSource>(market?.source?.volSource ?? "settle");
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const id = window.setTimeout(() => setDebounced(query.trim()), 250);
    return () => window.clearTimeout(id);
  }, [query]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const search = useQuery({
    queryKey: ["discover-search", debounced],
    queryFn: () => getJson<{ results: SearchHit[] }>(`/api/discover/search?q=${encodeURIComponent(debounced)}`),
    enabled: debounced.length >= 2 && !product,
    staleTime: 10 * 60_000,
  });

  const expiries = useQuery({ ...expiryListQuery(product?.ticker ?? ""), enabled: !!product });

  const frontSmile = useQuery({
    queryKey: ["discover-smile", front, volSource],
    queryFn: () => fetchSmile(...splitKey(front!), volSource),
    enabled: !!front,
    staleTime: 30_000,
  });

  const backSmile = useQuery({
    queryKey: ["discover-smile", back, volSource],
    queryFn: () => fetchSmile(...splitKey(back!), volSource),
    enabled: !!back,
    staleTime: 30_000,
  });

  useEffect(() => {
    const rows = expiries.data?.contracts ?? [];
    const first = rows.find((r) => r.main !== false) ?? rows[0];
    if (first && !front) setFront(rowKey(first));
  }, [expiries.data, front]);

  useEffect(() => {
    if (frontSmile.data) setEdits(editsFrom(frontSmile.data));
  }, [frontSmile.data]);

  function pick(hit: SearchHit) {
    setProduct(hit);
    setFront(null);
    setBack(null);
    setError(null);
  }

  function reset() {
    setProduct(null);
    setFront(null);
    setBack(null);
    setError(null);
    window.setTimeout(() => inputRef.current?.focus(), 0);
  }

  const editedPillars = useMemo(() => {
    const out: Partial<Record<Pillar, number | null>> = {};
    for (const name of PILLARS) {
      const text = edits[name].trim();
      out[name] = text === "" ? null : Number(text) / 100;
    }
    return out;
  }, [edits]);

  function use() {
    const smile = frontSmile.data;
    if (!smile || !product) return;
    const atm = editedPillars["50D"];
    if (atm == null || !(atm > 0)) {
      setError("ATM vol is missing. Type it in points, e.g. 79.5.");
      return;
    }
    if (back && !backSmile.data) {
      setError("The back expiry is still loading.");
      return;
    }
    const parsedBeta = beta.trim() === "" ? null : Number(beta);
    if (parsedBeta != null && !Number.isFinite(parsedBeta)) {
      setError("Beta has to be a number, or blank.");
      return;
    }
    const slices = [sliceFromSmile(smile, editedPillars)];
    const contracts = [smile.contract];
    const labels = [smile.label];
    const series = [smile.series ?? null];
    if (back && backSmile.data) {
      slices.push(sliceFromSmile(backSmile.data));
      contracts.push(backSmile.data.contract);
      labels.push(backSmile.data.label);
      series.push(backSmile.data.series ?? null);
    }
    const next: Market = {
      asOf: smile.as_of,
      rate: 0,
      multiplier: perLot ? smile.multiplier ?? 1 : 1,
      currency: smile.currency ?? "EUR",
      unit: smile.unit ?? "",
      beta: parsedBeta,
      slices,
      source: { product: product.ticker, description: product.description, contracts, labels, series, volSource },
    };
    setMarket(next);
    rememberProduct(product);
    onDone();
  }

  const hits = search.data?.results ?? [];
  const rows = expiries.data?.contracts ?? [];
  const smile = frontSmile.data;
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="mt-3 grid gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)]">
      <section className="min-w-0">
        {!product ? (
          <>
            <input
              ref={inputRef}
              className="w-full !py-2 !text-[13px]"
              placeholder="TTF, Brent, EUA, German power, or a ticker"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && hits[0]) pick(hits[0]);
              }}
            />
            {!debounced && recent.length > 0 && (
              <div className="mt-3">
                <div className="mb-1 text-[11px] text-mute">Recent</div>
                <div className="flex flex-wrap gap-1">
                  {recent.map((hit) => (
                    <button key={hit.ticker} className="btn num" title={hit.description} onClick={() => pick(hit)}>
                      {hit.ticker.replace(/ Comdty$/, "")}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {search.isFetching && <div className="skeleton mt-3 h-40" />}
            {search.error && <p className="mt-3 text-[12px] text-down">{(search.error as Error).message}</p>}
            {!search.isFetching && debounced.length >= 2 && search.data && hits.length === 0 && (
              <p className="mt-3 text-[12px] text-mute">Nothing on Bloomberg for “{debounced}”.</p>
            )}
            {hits.length > 0 && !search.isFetching && (
              <ul className="mt-2 max-h-[52vh] overflow-auto border border-line">
                {hits.map((hit, i) => (
                  <li key={`${hit.ticker}-${i}`}>
                    <button
                      className="flex w-full items-baseline gap-2 border-b border-line/60 px-2 py-1.5 text-left hover:bg-sunken"
                      onClick={() => pick(hit)}
                    >
                      <Kind kind={hit.kind} />
                      <span className="num w-28 shrink-0 text-[12px]">{hit.ticker.replace(/ Comdty$/, "")}</span>
                      <span className={`truncate text-[12px] ${hit.active ? "text-ink" : "text-mute"}`}>{hit.description}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
            {!debounced && recent.length === 0 && (
              <p className="mt-3 text-[12px] leading-relaxed text-mute">
                Search by name. Pick the options product (tagged OPT); its listed expiries, futures and smile come
                straight from the option chain.
              </p>
            )}
          </>
        ) : (
          <>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-baseline gap-2">
                  <Kind kind={product.kind} />
                  <span className="num text-[13px]">{product.ticker}</span>
                </div>
                <div className="truncate text-[12px] text-mute">{product.description}</div>
              </div>
              <button className="btn shrink-0" onClick={reset}>Change</button>
            </div>
            {expiries.isFetching && <div className="skeleton mt-3 h-56" />}
            {expiries.error && <p className="mt-3 text-[12px] text-down">{(expiries.error as Error).message}</p>}
            {expiries.data?.warning && <p className="mt-3 text-[12px] text-warn">{expiries.data.warning}</p>}
            {rows.length > 0 && !expiries.isFetching && (
              <div className="mt-2 max-h-[52vh] overflow-auto border border-line">
                <table className="blotter">
                  <thead className="sticky top-0 bg-raised">
                    <tr>
                      <th>Contract</th>
                      <th>Opt expiry</th>
                      <th className="text-right">Days</th>
                      <th className="text-right">Future</th>
                      <th className="text-right">Back</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row) => {
                      const key = rowKey(row);
                      const selected = key === front;
                      const isBack = key === back;
                      return (
                        <tr
                          key={key}
                          className={`cursor-pointer ${selected ? "bg-sunken text-accent" : "hover:bg-sunken"}`}
                          onClick={() => {
                            setFront(key);
                            if (isBack) setBack(null);
                          }}
                        >
                          <td className="num">
                            {row.label}
                            <span className="ml-2 text-[11px] text-mute">
                              {row.main === false ? `${row.series} serial` : row.contract.replace(/ Comdty$/, "")}
                            </span>
                          </td>
                          <td className="num">{row.option_expiry ?? "—"}</td>
                          <td className="num text-right">{row.option_expiry ? daysBetween(today, row.option_expiry) : "—"}</td>
                          <td className="num text-right">{px(row.forward)}</td>
                          <td className="text-right">
                            <button
                              className={`btn !px-1.5 !py-0 text-[11px] ${isBack ? "!border-accent text-accent" : ""}`}
                              disabled={selected}
                              title="Second expiry for calendars and diagonals"
                              onClick={(e) => {
                                e.stopPropagation();
                                setBack(isBack ? null : key);
                              }}
                            >
                              {isBack ? "Back ✓" : "Back"}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </section>

      <section className="min-w-0 border-line md:border-l md:pl-3">
        {!front && <EmptyRight product={!!product} />}
        {front && frontSmile.isFetching && !smile && <div className="skeleton h-72" />}
        {frontSmile.error && <p className="text-[12px] text-down">{(frontSmile.error as Error).message}</p>}
        {smile && (
          <>
            <div className="flex items-baseline justify-between gap-2">
              <div className="text-[13px]">
                {smile.label} options
                <span className="num ml-2 text-[11px] text-mute">underlying {smile.contract}</span>
              </div>
              <div className="flex items-center gap-2">
                {frontSmile.isFetching && <span className="text-[11px] text-mute">refreshing…</span>}
                <div className="flex border border-line text-[11px]">
                  {(["settle", "mid"] as SmileSource[]).map((s) => (
                    <button
                      key={s}
                      className={`px-2 py-0.5 ${volSource === s ? "bg-sunken text-accent" : "text-mute hover:text-ink"}`}
                      title={s === "settle" ? "Vols implied from the last exchange settlement" : "Bloomberg live mid implied vols"}
                      onClick={() => setVolSource(s)}
                    >
                      {s === "settle" ? "Settlement" : "Live mids"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-2 grid grid-cols-5 border border-line">
              <Tile k="Future" v={px(smile.forward)} />
              <Tile k="Expiry" v={`${daysBetween(smile.as_of, smile.expiry)}d`} hint={smile.expiry} />
              <Tile k="ATM" v={volPts(editedPillars["50D"])} />
              <Tile k="25d RR" v={signed((riskReversal(editedPillars) ?? NaN) * 100, 1)} />
              <Tile k="25d fly" v={signed((butterfly(editedPillars) ?? NaN) * 100, 1)} last />
            </div>
            <div className="mt-2 h-48 border border-line">
              <EChart option={smileChart(smile, editedPillars)} height="100%" />
            </div>
            <div className="mt-2 grid grid-cols-5 gap-1 text-[11px]">
              {PILLAR_ORDER.map((name) => (
                <label key={name} className="block text-mute">
                  {PILLAR_LABEL[name]}
                  <input
                    className="mt-0.5 w-full text-right"
                    value={edits[name]}
                    onChange={(e) => setEdits({ ...edits, [name]: e.target.value })}
                  />
                </label>
              ))}
            </div>
            <p className="mt-1 text-[11px] text-mute">
              {smile.fit?.model === "sabr" ? "SABR fit" : "Smooth fit"}
              {smile.vol_source === "settle" && smile.settle
                ? ` to vols implied from the ${smile.settle.date} settlement prices (future ${px(smile.settle.forward)}) of `
                : ` to ${smile.vol_source === "mid" ? "live mid" : "last-price"} implied vols of `}
              {smile.points.filter((p) => p.used).length} out-of-the-money listed options, read off at Black-76
              forward deltas{smile.vol_source === "settle" ? " and applied to the live future by delta" : ""}. Hollow
              points were left out of the fit; the dashed curve is beyond the listed strikes. Edit any pillar before using it.
            </p>
            {smile.fit && (
              <p className="mt-1 text-[11px] text-mute num">
                {smile.fit.model === "sabr"
                  ? `SABR β ${smile.fit.beta} · α ${px(smile.fit.alpha, 3)} · ρ ${px(smile.fit.rho, 2)} · ν ${px(smile.fit.nu, 2)}`
                  : `Polynomial, degree ${smile.fit.degree}`}
                {` · rmse ${volPts(smile.fit.rmse_used ?? smile.fit.rmse, 2)} vol pts`}
                {smile.fit.rr25 != null && ` · 25Δ RR ${volPts(smile.fit.rr25)}`}
                {smile.fit.bf25 != null && ` · 25Δ BF ${volPts(smile.fit.bf25)}`}
                {smile.parity && ` · parity forward ${px(smile.parity.forward, 3)}`}
              </p>
            )}
            {smile.warnings.map((w) => (
              <p key={w} className="mt-1 text-[11px] text-warn">{w}</p>
            ))}
            {back && (
              <p className="mt-2 text-[12px]">
                <span className="text-mute">Back </span>
                {backSmile.isFetching && !backSmile.data ? (
                  <span className="text-mute">loading…</span>
                ) : backSmile.data ? (
                  <span className="num">
                    {backSmile.data.label} · {px(backSmile.data.forward)} · {volPts(backSmile.data.pillars["50D"])} ATM ·{" "}
                    {backSmile.data.expiry}
                  </span>
                ) : (
                  <span className="text-down">{(backSmile.error as Error | null)?.message ?? "unavailable"}</span>
                )}
              </p>
            )}
            <div className="mt-3 flex flex-wrap items-end gap-3 text-[12px]">
              <label className="text-mute">
                Size
                <select className="mt-1 block" value={perLot ? "lot" : "unit"} onChange={(e) => setPerLot(e.target.value === "lot")}>
                  <option value="lot">Per lot{smile.multiplier ? ` (${px(smile.multiplier, 0)} ${unitQty(smile.unit)})` : ""}</option>
                  <option value="unit">Per {unitQty(smile.unit) || "unit"}</option>
                </select>
              </label>
              <label className="text-mute">
                Beta, vol per log-forward
                <input className="mt-1 block w-28" value={beta} placeholder="optional" onChange={(e) => setBeta(e.target.value)} />
              </label>
              <button className="btn btn-primary ml-auto !px-4 !py-1.5" onClick={use} disabled={frontSmile.isFetching && !smile}>
                Use market
              </button>
            </div>
            {error && <p className="mt-2 text-[12px] text-down">{error}</p>}
          </>
        )}
      </section>
    </div>
  );
}

function EmptyRight({ product }: { product: boolean }) {
  return (
    <div className="flex h-full min-h-[240px] items-center justify-center border border-dashed border-line p-6 text-center text-[12px] text-mute">
      {product ? "Choose an expiry." : "The smile for the chosen expiry appears here."}
    </div>
  );
}

function Kind({ kind }: { kind: SearchHit["kind"] }) {
  const label = kind === "options" ? "OPT" : kind === "futures" ? "FUT" : "TKR";
  const tone = kind === "options" ? "border-accent text-accent" : "border-line text-mute";
  return <span className={`num shrink-0 border px-1 text-[10px] leading-4 ${tone}`}>{label}</span>;
}

function Tile({ k, v, hint, last }: { k: string; v: string; hint?: string; last?: boolean }) {
  return (
    <div className={`px-2 py-1.5 ${last ? "" : "border-r border-line"}`} title={hint}>
      <div className="text-[10px] text-mute">{k}</div>
      <div className="num text-[13px]">{v}</div>
    </div>
  );
}

function rowKey(row: ExpiryRow): string {
  return row.series ? `${row.contract}|${row.series}` : row.contract;
}

function splitKey(key: string): [string, string | null] {
  const [contract, series] = key.split("|");
  return [contract, series ?? null];
}

function blankEdits(): Record<Pillar, string> {
  return { "10DC": "", "25DC": "", "50D": "", "25DP": "", "10DP": "" };
}

function editsFrom(smile: ChainSmile): Record<Pillar, string> {
  const out = blankEdits();
  for (const name of PILLARS) {
    const value = smile.pillars[name];
    out[name] = value == null ? "" : (value * 100).toFixed(2);
  }
  return out;
}

function unitQty(unit: string | null): string {
  if (!unit) return "";
  const parts = unit.split("/");
  return parts.length === 2 ? parts[1] : "";
}

function smileChart(smile: ChainSmile, pillars: Partial<Record<Pillar, number | null>>): EChartsOption {
  const visible = smile.points.filter((p) => p.call_delta > 0.03 && p.call_delta < 0.97);
  const calls = visible.filter((p) => p.cp === "C" && p.used !== false);
  const puts = visible.filter((p) => p.cp === "P" && p.used !== false);
  const dropped = visible.filter((p) => p.used === false);
  const marks = PILLAR_ORDER.filter((name) => pillars[name] != null).map((name) => ({
    value: [PILLAR_DELTA[name], (pillars[name] as number) * 100],
    name: PILLAR_LABEL[name],
  }));
  return {
    tooltip: {
      ...tooltip,
      formatter: (raw: unknown) => {
        const p = raw as { data: { value?: number[]; strike?: number; name?: string } | number[]; seriesName: string };
        const data = Array.isArray(p.data) ? { value: p.data } : p.data;
        const [delta, vol] = data.value ?? [0, 0];
        const label = data.strike != null ? `K ${data.strike}` : data.name ?? p.seriesName;
        const resid = (data as { resid?: number | null }).resid;
        const tail = resid != null ? ` · fit ${resid >= 0 ? "+" : "−"}${(Math.abs(resid) * 100).toFixed(2)}` : "";
        return `${label}<br/>Δc ${delta.toFixed(2)} · ${vol.toFixed(1)}%${tail}`;
      },
    },
    grid: { left: 40, right: 12, top: 12, bottom: 28 },
    xAxis: {
      type: "value",
      ...axis(),
      min: 0.03,
      max: 0.97,
      inverse: true,
      name: "call delta",
      nameLocation: "middle",
      nameGap: 18,
      axisLabel: { ...axis().axisLabel, formatter: (v: number) => v.toFixed(1) },
    },
    yAxis: { type: "value", ...axis(), scale: true, axisLabel: { ...axis().axisLabel, formatter: (v: number) => String(Math.round(v)) } },
    series: [
      {
        name: "Fit",
        type: "line",
        showSymbol: false,
        silent: true,
        lineStyle: { color: mute, width: 1.5 },
        data: smile.curve.filter((c) => !c.extrapolated).map((c) => [c.call_delta, c.vol * 100]),
      },
      {
        name: "Beyond strikes",
        type: "line",
        showSymbol: false,
        silent: true,
        lineStyle: { color: mute, width: 1, type: "dashed" },
        data: smile.curve.filter((c) => c.extrapolated).map((c) => [c.call_delta, c.vol * 100]),
      },
      {
        name: "Left out",
        type: "scatter",
        symbol: "emptyCircle",
        symbolSize: 5,
        itemStyle: { color: mute, opacity: 0.6 },
        data: dropped.map((p) => ({ value: [p.call_delta, p.vol * 100], strike: p.strike, resid: p.resid })),
      },
      {
        name: "Puts",
        type: "scatter",
        symbolSize: 5,
        itemStyle: { color: warn, opacity: 0.8 },
        data: puts.map((p) => ({ value: [p.call_delta, p.vol * 100], strike: p.strike, resid: p.resid })),
      },
      {
        name: "Calls",
        type: "scatter",
        symbolSize: 5,
        itemStyle: { color: accent, opacity: 0.8 },
        data: calls.map((p) => ({ value: [p.call_delta, p.vol * 100], strike: p.strike, resid: p.resid })),
      },
      {
        name: "Pillars",
        type: "line",
        symbol: "diamond",
        symbolSize: 9,
        lineStyle: { color: ink, width: 1, opacity: 0.6 },
        itemStyle: { color: ink },
        label: { show: true, position: "top", color: mute, fontSize: 10, formatter: (p: { name?: string }) => p.name ?? "" },
        data: marks,
      },
    ],
  };
}
