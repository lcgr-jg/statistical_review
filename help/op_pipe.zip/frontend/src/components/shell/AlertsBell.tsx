import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { getJson, postJson } from "../../model/api";
import { px, volPts } from "../../model/format";
import type { Alert } from "../../model/history";
import { useLab } from "../../store/lab";

const SEEN_KEY = "options-lab-alerts-seen";

function seen(): Set<string> {
  try {
    return new Set(JSON.parse(localStorage.getItem(SEEN_KEY) ?? "[]") as string[]);
  } catch {
    return new Set();
  }
}

function fmtValue(alert: Alert, value: number | null) {
  return alert.field === "atm_vol" ? volPts(value) : px(value);
}

export function AlertsBell() {
  const market = useLab((s) => s.market);
  const client = useQueryClient();
  const [open, setOpen] = useState(false);
  const [ticker, setTicker] = useState("");
  const [field, setField] = useState<Alert["field"]>("price");
  const [op, setOp] = useState<Alert["op"]>("above");
  const [level, setLevel] = useState("");
  const [note, setNote] = useState("");
  const [seenIds, setSeenIds] = useState(seen);
  const boxRef = useRef<HTMLDivElement>(null);

  const alerts = useQuery({
    queryKey: ["alerts"],
    queryFn: () => getJson<{ alerts: Alert[] }>("/api/alerts"),
    refetchInterval: 60_000,
  });
  const refresh = () => client.invalidateQueries({ queryKey: ["alerts"] });
  const add = useMutation({
    mutationFn: () => postJson<Alert>("/api/alerts", { ticker: ticker.trim(), field, op, level: field === "atm_vol" ? Number(level) / 100 : Number(level), note }),
    onSuccess: () => {
      setLevel("");
      setNote("");
      refresh();
    },
  });
  const act = useMutation({
    mutationFn: ({ id, action }: { id: string; action: "reset" | "delete" }) =>
      action === "reset"
        ? postJson(`/api/alerts/${id}/reset`, {})
        : fetch(`/api/alerts/${id}`, { method: "DELETE" }).then((r) => r.json()),
    onSuccess: refresh,
  });

  const rows = alerts.data?.alerts ?? [];
  const fired = rows.filter((a) => a.triggered_at);
  const unseen = fired.filter((a) => !seenIds.has(`${a.id}:${a.triggered_at}`));

  useEffect(() => {
    if (!unseen.length || typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const notified = JSON.parse(sessionStorage.getItem(SEEN_KEY) ?? "[]") as string[];
    for (const a of unseen) {
      const key = `${a.id}:${a.triggered_at}`;
      if (notified.includes(key)) continue;
      new Notification(`${a.ticker.replace(/ Comdty$/, "")} ${a.field === "atm_vol" ? "ATM vol" : "price"} ${a.op} ${fmtValue(a, a.level)}`, {
        body: `Now ${fmtValue(a, a.triggered_value)}${a.note ? ` · ${a.note}` : ""}`,
      });
      notified.push(key);
    }
    sessionStorage.setItem(SEEN_KEY, JSON.stringify(notified));
  }, [unseen]);

  useEffect(() => {
    if (!open) return;
    setSeenIds((prev) => {
      const next = new Set(prev);
      fired.forEach((a) => next.add(`${a.id}:${a.triggered_at}`));
      localStorage.setItem(SEEN_KEY, JSON.stringify([...next]));
      return next;
    });
    if (!ticker && market?.source?.contracts[0]) setTicker(market.source.contracts[0]);
    function onClick(event: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(event.target as Node)) setOpen(false);
    }
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, rows.length, fired.length]);

  function submit() {
    if (typeof Notification !== "undefined" && Notification.permission === "default") void Notification.requestPermission();
    add.mutate();
  }

  return (
    <div className="relative" ref={boxRef}>
      <button className={`btn ${unseen.length ? "btn-primary" : ""}`} onClick={() => setOpen(!open)} title="Price and vol alerts">
        Alerts{rows.length ? ` ${unseen.length ? `· ${unseen.length} new` : `(${rows.length})`}` : ""}
      </button>
      {open && (
        <div className="panel absolute right-0 top-full z-40 mt-1 w-[420px] p-3 text-[12px] shadow-xl">
          <div className="mb-2 flex items-center">
            <span className="text-ink">Alerts</span>
            <span className="ml-2 text-mute">checked on the server every {Math.round((alerts.data as { interval_seconds?: number } | undefined)?.interval_seconds ?? 300) / 60} min</span>
          </div>
          {rows.length === 0 && <p className="mb-2 text-mute">No alerts yet.</p>}
          <div className="max-h-64 space-y-1 overflow-auto">
            {rows.map((a) => (
              <div key={a.id} className={`flex items-center gap-2 border-b border-line/60 py-1 ${a.triggered_at ? "text-warn" : ""}`}>
                <div className="min-w-0 flex-1">
                  <div className="truncate">
                    {a.ticker.replace(/ Comdty$/, "")} {a.field === "atm_vol" ? "ATM vol" : "price"} {a.op} {fmtValue(a, a.level)}
                  </div>
                  <div className="truncate text-[11px] text-mute">
                    {a.triggered_at
                      ? `Fired ${a.triggered_at.slice(0, 16).replace("T", " ")} at ${fmtValue(a, a.triggered_value)}`
                      : `Last ${fmtValue(a, a.last_value)}${a.last_checked ? ` · ${a.last_checked.slice(11, 16)}` : ""}`}
                    {a.note ? ` · ${a.note}` : ""}
                  </div>
                </div>
                {a.triggered_at && <button className="btn" onClick={() => act.mutate({ id: a.id, action: "reset" })}>Re-arm</button>}
                <button className="btn" onClick={() => act.mutate({ id: a.id, action: "delete" })}>✕</button>
              </div>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-[1fr_auto_auto_80px] gap-1">
            <input value={ticker} onChange={(e) => setTicker(e.target.value)} placeholder="FJSZ6 Comdty" />
            <select value={field} onChange={(e) => setField(e.target.value as Alert["field"])}>
              <option value="price">Price</option>
              <option value="atm_vol">ATM vol</option>
            </select>
            <select value={op} onChange={(e) => setOp(e.target.value as Alert["op"])}>
              <option value="above">above</option>
              <option value="below">below</option>
            </select>
            <input value={level} onChange={(e) => setLevel(e.target.value)} placeholder={field === "atm_vol" ? "vol pts" : "level"} />
          </div>
          <div className="mt-1 flex gap-1">
            <input className="flex-1" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Note (optional)" />
            <button className="btn btn-primary" disabled={!ticker.trim() || !Number.isFinite(Number(level)) || level.trim() === "" || add.isPending} onClick={submit}>
              Add
            </button>
          </div>
          {add.error && <p className="mt-1 text-down">{(add.error as Error).message}</p>}
          <p className="mt-2 text-[11px] text-mute">Each alert fires once, then waits until you re-arm it. Vol is the contract's ATM from Bloomberg's call and put implied vols.</p>
        </div>
      )}
    </div>
  );
}
