import { useEffect } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { usePrefetchTabs } from "../../model/prefetch";
import { useLab } from "../../store/lab";
import { CommandPalette } from "./CommandPalette";
import { AlertsBell } from "./AlertsBell";
import { CopilotDrawer } from "./CopilotDrawer";
import { MarketStrip } from "./MarketStrip";
import { NAV_GROUPS, NAV_LINKS } from "./nav";

export function AppShell() {
  const navigate = useNavigate();
  const setPaletteOpen = useLab((s) => s.setPaletteOpen);
  const setCopilotOpen = useLab((s) => s.setCopilotOpen);
  const copilotOpen = useLab((s) => s.copilotOpen);
  const warming = usePrefetchTabs();

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      const typing = !!target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName);
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen(true);
        return;
      }
      if (event.key === "Escape" && useLab.getState().copilotOpen && !useLab.getState().paletteOpen) {
        setCopilotOpen(false);
        return;
      }
      if (typing || event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.key === "/") {
        event.preventDefault();
        setCopilotOpen(true);
        return;
      }
      const link = NAV_LINKS.find((l) => l.key === event.key);
      if (link) navigate(link.to);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate, setPaletteOpen, setCopilotOpen]);

  return (
    <div className="print-flow flex h-full min-h-0 flex-col print:block">
      <header className="flex items-center gap-5 border-b border-line px-3 py-1.5 print:hidden">
        <span className="text-[13px] font-medium tracking-tight">Structure</span>
        <nav className="flex items-center text-[12.5px]">
          {NAV_GROUPS.map((group) => (
            <div key={group.name} className="nav-group">
              <span className="mr-1 text-[10px] uppercase tracking-wider text-mute/70">{group.name}</span>
              {group.links.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.end}
                  title={`${link.hint}  (${link.key})`}
                  className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
                >
                  {link.label}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {warming && (
            <span className="text-[11px] text-mute" title="Loading the other tabs in the background so they open instantly">
              Preparing {warming.label} · {warming.done + 1}/{warming.total}
            </span>
          )}
          <AlertsBell />
          <button className="btn" onClick={() => setPaletteOpen(true)} title="Search (Ctrl K)">
            Search
          </button>
          <button
            className={`btn ${copilotOpen ? "btn-primary" : ""}`}
            onClick={() => setCopilotOpen(!copilotOpen)}
            title="Copilot (/)"
          >
            Copilot
          </button>
        </div>
      </header>
      <div className="print:hidden">
        <MarketStrip />
      </div>
      <div className="print-flow flex min-h-0 flex-1 print:block">
        <main className="print-flow min-h-0 min-w-0 flex-1">
          <Outlet />
        </main>
        <div className="contents print:hidden">
          <CopilotDrawer />
        </div>
      </div>
      <CommandPalette />
    </div>
  );
}
