import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { useLocation, useNavigate } from "react-router-dom";
import { postSse } from "../../model/api";
import { pct, signed } from "../../model/format";
import { uid } from "../../model/id";
import { marketReady, toLegs, toMarketIn, type Leg } from "../../model/types";
import { useLab, type CopilotMode } from "../../store/lab";
import { ResolverDrawer } from "./ResolverDrawer";

type ToolRow = { name: string; preview: string };
type ProposalLeg = {
  call_put: "C" | "P";
  qty: number;
  strike_mode: Leg["strikeMode"];
  strike: number;
  expiry: string | null;
};
type Proposal = {
  label: string;
  rationale: string;
  legs: ProposalLeg[];
  premium?: number;
  delta?: number;
  vega_point?: number;
  theta_day?: number;
  pop?: number | null;
  max_loss?: number | null;
  error?: string;
};
type Turn = {
  role: "user" | "assistant";
  content: string;
  mode?: CopilotMode;
  tools?: ToolRow[];
  proposals?: Proposal[];
  error?: string;
};

const MODES: { mode: CopilotMode; label: string; hint: string }[] = [
  { mode: "structure", label: "Find a structure", hint: "Describe a view: TTF +15% by Dec expiry, vol flat, spend under 2." },
  { mode: "critique", label: "Critique", hint: "Anything to focus on? Leave empty for a full review." },
  { mode: "chat", label: "Ask", hint: "Ask about the market, the structure or what is on screen." },
];

const TOOL_LABELS: Record<string, string> = {
  list_templates: "Templates",
  expand_template: "Template legs",
  price_structure: "Priced",
  search_structures: "Searched structures",
  pnl_scenarios: "Scenarios",
  monte_carlo: "Monte Carlo",
  get_smile: "Smile",
  get_term_structure: "Term structure",
  vol_history_stats: "Vol history",
  backtest_structure: "Backtest",
  breakeven_vs_history: "Breakevens vs history",
  vol_seasonality: "Seasonality",
  skew_slope_history: "Skew and slope",
  vol_roll_history: "Vol rolls",
};

const PAGES: Record<string, string> = {
  "/": "Builder",
  "/path": "Path",
  "/surface": "Surface",
  "/vol": "Vol",
  "/montecarlo": "Monte Carlo",
  "/regimes": "Regimes",
  "/backtest": "Backtest",
  "/screener": "Screener",
  "/rolls": "Rolls",
  "/journal": "Journal",
  "/risk": "Risk",
  "/deck": "Deck",
};

const SUGGESTIONS: Record<string, { mode: CopilotMode; prompt: string }[]> = {
  Builder: [
    { mode: "critique", prompt: "Critique the structure I have loaded." },
    { mode: "chat", prompt: "Where is my biggest risk on this structure, and how would you hedge it?" },
    { mode: "structure", prompt: "Find a cheaper structure with the same directional view as what I have loaded." },
  ],
  Path: [
    { mode: "chat", prompt: "Explain the P&L on this path. Which greeks drove it and what would change the outcome?" },
    { mode: "chat", prompt: "Would delta hedging have helped on this path?" },
  ],
  "Monte Carlo": [
    { mode: "chat", prompt: "Explain this Monte Carlo distribution. Is the risk/reward attractive?" },
  ],
  Regimes: [
    { mode: "chat", prompt: "Is implied vol rich or cheap against history and realised right now?" },
    { mode: "chat", prompt: "Which spot-vol regime fits this market, and what does that mean for my structure?" },
  ],
  Surface: [
    { mode: "chat", prompt: "Where are skew and fly rich or cheap against their own history on this surface, and which expiries fail the checks?" },
    { mode: "structure", prompt: "Suggest a relative-value trade across expiries or strikes from what this surface shows." },
  ],
  Vol: [
    { mode: "chat", prompt: "Is implied rich or cheap against realised and the cone, and what does spot-vol say about the regime?" },
  ],
  Backtest: [
    { mode: "chat", prompt: "Was this structure worth owning historically, and when did it lose?" },
    { mode: "structure", prompt: "Find a variation of this structure that would have done better through history without paying more." },
  ],
  Screener: [
    { mode: "chat", prompt: "Which expiries look rich or cheap right now, against realised and their own history?" },
    { mode: "chat", prompt: "What are skew, slope and seasonality saying, and what would you trade on it?" },
  ],
  Rolls: [
    { mode: "chat", prompt: "Is the front calendar spread rich or cheap for this point in the cycle, and how does it usually move into expiry?" },
    { mode: "structure", prompt: "Design a calendar spread that expresses what the roll history suggests for the front two months." },
  ],
  Journal: [
    { mode: "chat", prompt: "Which of these broker quotes is the best value against the model?" },
  ],
  Risk: [
    { mode: "chat", prompt: "Which positions drive the book's tail risk, and what single trade would cut the 99% VaR most?" },
  ],
  Deck: [
    { mode: "chat", prompt: "Write a short pitch for this structure that I can send to the PM." },
  ],
};

const PROPOSAL_BLOCK = /```(?:json)?\s*\{[\s\S]*?"proposals"[\s\S]*?\}\s*```/g;

export function CopilotDrawer() {
  const open = useLab((s) => s.copilotOpen);
  const tab = useLab((s) => s.assistantTab);
  const setTab = useLab((s) => s.setAssistantTab);
  const setOpen = useLab((s) => s.setCopilotOpen);
  const market = useLab((s) => s.market);
  const legs = useLab((s) => s.legs);
  const regime = useLab((s) => s.regime);
  const setLegs = useLab((s) => s.setLegs);
  const request = useLab((s) => s.copilotRequest);
  const screens = useLab((s) => s.screen);
  const navigate = useNavigate();
  const location = useLocation();
  const page = PAGES[location.pathname] ?? "Builder";

  const [mode, setMode] = useState<CopilotMode>("chat");
  const [input, setInput] = useState("");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [live, setLive] = useState<Turn | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const liveRef = useRef<Turn | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const handled = useRef<string | null>(null);

  useEffect(() => {
    if (!request || handled.current === request.id) return;
    handled.current = request.id;
    setTab("copilot");
    void send(request.prompt, request.mode, request.context);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [request]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [turns, live]);

  if (!open) return null;

  function update(patch: (turn: Turn) => Turn) {
    if (!liveRef.current) return;
    liveRef.current = patch(liveRef.current);
    setLive(liveRef.current);
  }

  async function send(text: string, nextMode: CopilotMode, extra?: Record<string, unknown>) {
    const content = text.trim() || (nextMode === "critique" ? "Critique the structure I have loaded." : "");
    if (!content || busy) return;
    if (!marketReady(market)) {
      setError("Load a market first. The copilot prices against the market on screen.");
      return;
    }
    if (nextMode === "critique" && legs.length === 0) {
      setError("Load a structure in the Builder before asking for a critique.");
      return;
    }
    const history: Turn[] = [...turns, { role: "user", content, mode: nextMode }];
    setTurns(history);
    setInput("");
    setMode(nextMode);
    setBusy(true);
    setError(null);
    liveRef.current = { role: "assistant", content: "", mode: nextMode, tools: [], proposals: [] };
    setLive(liveRef.current);
    const controller = new AbortController();
    abortRef.current = controller;
    const context = { ...(screens[page] ?? {}), ...(extra ?? {}) };
    try {
      await postSse("/api/copilot/chat", {
        messages: history.map((turn) => ({ role: turn.role, content: turn.content || "(no reply)" })),
        market: toMarketIn(market),
        legs: toLegs(legs),
        mode: nextMode,
        regime,
        product: market.source?.product ?? null,
        contract: market.source?.contracts[0] ?? null,
        page,
        context: Object.keys(context).length ? context : null,
      }, (event, data) => {
        if (event === "text") update((turn) => ({ ...turn, content: turn.content + String(data.delta ?? "") }));
        if (event === "tool") {
          update((turn) => ({
            ...turn,
            tools: [...(turn.tools ?? []), { name: String(data.name), preview: String(data.preview ?? "") }],
          }));
        }
        if (event === "error") update((turn) => ({ ...turn, error: String(data.message ?? "Copilot failed") }));
        if (event === "done") {
          const found = Array.isArray(data.proposals) ? (data.proposals as Proposal[]) : [];
          update((turn) => ({ ...turn, proposals: found, error: data.message ? String(data.message) : turn.error }));
        }
      }, controller.signal);
    } catch (err) {
      const aborted = err instanceof DOMException && err.name === "AbortError";
      update((turn) => ({ ...turn, error: aborted ? "Stopped." : err instanceof Error ? err.message : "Copilot failed" }));
    } finally {
      const finished = liveRef.current;
      if (finished) setTurns((prev) => [...prev, finished]);
      liveRef.current = null;
      setLive(null);
      setBusy(false);
      abortRef.current = null;
    }
  }

  function load(card: Proposal, to: "/" | "/path") {
    setLegs(card.legs.map((leg) => ({
      id: uid(),
      callPut: leg.call_put,
      qty: leg.qty,
      strikeMode: leg.strike_mode ?? "absolute",
      strike: leg.strike,
      expiry: leg.expiry ?? null,
      vol: null,
    })));
    navigate(to);
  }

  const shown = live ? [...turns, live] : turns;
  const current = MODES.find((m) => m.mode === mode) ?? MODES[2];
  const contextBits = [
    market?.source?.product ?? market?.source?.contracts?.[0],
    market?.source?.contracts?.[0],
    `${legs.length} leg${legs.length === 1 ? "" : "s"}`,
    regime,
    page,
  ].filter(Boolean);

  return (
    <aside className="fixed inset-y-0 right-0 z-30 flex w-[min(460px,100vw)] shrink-0 flex-col border-l border-line bg-raised shadow-2xl xl:static xl:z-auto xl:h-full xl:shadow-none">
      <div className="flex items-center gap-1 border-b border-line px-2 py-1.5">
        <button className={`btn !py-0.5 ${tab === "copilot" ? "btn-primary" : ""}`} onClick={() => setTab("copilot")}>Copilot</button>
        <button className={`btn !py-0.5 ${tab === "resolver" ? "btn-primary" : ""}`} onClick={() => setTab("resolver")}>Resolver</button>
        <div className="ml-auto flex gap-1">
          {tab === "copilot" && turns.length > 0 && (
            <button className="btn !py-0.5" disabled={busy} onClick={() => { setTurns([]); setError(null); }}>New chat</button>
          )}
          <button className="btn !py-0.5" onClick={() => setOpen(false)} title="Close (Esc)">✕</button>
        </div>
      </div>
      {tab === "resolver" ? (
        <ResolverDrawer embedded />
      ) : (
        <div className="flex min-h-0 flex-1 flex-col">
          <div className="flex flex-wrap gap-1 border-b border-line px-3 py-1.5 text-[10px] text-mute">
            {contextBits.map((bit, i) => (
              <span key={`${bit}-${i}`} className="border border-line px-1.5 py-[1px]">{bit}</span>
            ))}
          </div>
          <div ref={scrollRef} className="min-h-0 flex-1 space-y-4 overflow-auto px-3 py-3 text-[12px]">
            {shown.length === 0 && <Welcome page={page} onPick={(s) => void send(s.prompt, s.mode)} />}
            {shown.map((turn, i) =>
              turn.role === "user" ? (
                <div key={i} className="flex justify-end">
                  <div className="max-w-[85%] bg-sunken px-2.5 py-1.5 text-ink">
                    <div className="mb-0.5 text-[10px] uppercase tracking-wide text-mute">{MODES.find((m) => m.mode === turn.mode)?.label}</div>
                    {turn.content}
                  </div>
                </div>
              ) : (
                <AssistantTurn
                  key={i}
                  turn={turn}
                  working={busy && turn === live}
                  onLoad={load}
                />
              ),
            )}
            {error && <p className="text-down">{error}</p>}
          </div>
          <div className="border-t border-line px-3 py-2">
            <div className="mb-2 flex gap-1">
              {MODES.map((m) => (
                <button
                  key={m.mode}
                  className={`btn flex-1 !py-0.5 text-[11px] ${mode === m.mode ? "btn-primary" : ""}`}
                  onClick={() => setMode(m.mode)}
                >
                  {m.label}
                </button>
              ))}
            </div>
            <textarea
              className="h-16 w-full resize-none"
              value={input}
              placeholder={current.hint}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send(input, mode);
                }
              }}
            />
            <div className="mt-1 flex items-center justify-between text-[10px] text-mute">
              <span>Enter to send, Shift+Enter for a new line</span>
              {busy ? (
                <button className="btn !py-0.5" onClick={() => abortRef.current?.abort()}>Stop</button>
              ) : (
                <button
                  className="btn btn-primary !py-0.5"
                  disabled={!input.trim() && mode !== "critique"}
                  onClick={() => void send(input, mode)}
                >
                  {mode === "critique" && !input.trim() ? "Critique" : "Send"}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}

function Welcome({ page, onPick }: { page: string; onPick: (s: { mode: CopilotMode; prompt: string }) => void }) {
  const items = SUGGESTIONS[page] ?? SUGGESTIONS.Builder;
  return (
    <div className="space-y-2">
      <p className="text-mute">
        The copilot prices with this app's own models on the market loaded above. It can design and search structures,
        critique what you hold and explain what is on the {page} page. Proposals are re-priced before you see them.
      </p>
      <div className="space-y-1">
        {items.map((item) => (
          <button key={item.prompt} className="btn block w-full text-left !py-1 text-[11px]" onClick={() => onPick(item)}>
            {item.prompt}
          </button>
        ))}
      </div>
    </div>
  );
}

function AssistantTurn({ turn, working, onLoad }: { turn: Turn; working: boolean; onLoad: (card: Proposal, to: "/" | "/path") => void }) {
  const text = turn.content.replace(PROPOSAL_BLOCK, "").trim();
  return (
    <div className="space-y-2">
      <Activity tools={turn.tools ?? []} working={working} />
      {text && (
        <div className="copilot-md text-ink">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>{text}</ReactMarkdown>
        </div>
      )}
      {(turn.proposals ?? []).length > 0 && (
        <div className="space-y-2">
          {turn.proposals!.map((card, i) => (
            <ProposalCard key={card.label + i} card={card} rank={i + 1} onLoad={onLoad} />
          ))}
        </div>
      )}
      {turn.error && <p className="text-down">{turn.error}</p>}
    </div>
  );
}

function Activity({ tools, working }: { tools: ToolRow[]; working: boolean }) {
  if (!tools.length && !working) return null;
  const counts = new Map<string, number>();
  for (const tool of tools) counts.set(tool.name, (counts.get(tool.name) ?? 0) + 1);
  const last = tools[tools.length - 1];
  const failed = tools.filter((tool) => tool.preview.startsWith('{"error"')).length;
  return (
    <details className="border border-line bg-sunken px-2 py-1 text-[11px] text-mute">
      <summary className="cursor-pointer select-none">
        {working ? (
          <span className="text-accent">
            Working{last ? ` · ${TOOL_LABELS[last.name] ?? last.name}` : "…"} ({tools.length} checks)
          </span>
        ) : (
          <span>
            {tools.length} checks: {[...counts].map(([name, n]) => `${TOOL_LABELS[name] ?? name}${n > 1 ? ` ×${n}` : ""}`).join(", ")}
            {failed > 0 && <span className="text-down"> · {failed} failed</span>}
          </span>
        )}
      </summary>
      <div className="mt-1 space-y-1">
        {tools.map((tool, i) => (
          <details key={i} className="border-t border-line pt-1">
            <summary className="cursor-pointer">{i + 1}. {TOOL_LABELS[tool.name] ?? tool.name}</summary>
            <pre className="mt-1 max-h-40 overflow-auto whitespace-pre-wrap text-[10px]">{tool.preview}</pre>
          </details>
        ))}
      </div>
    </details>
  );
}

function legText(leg: ProposalLeg) {
  const qty = leg.qty > 0 ? `+${leg.qty}` : `${leg.qty}`;
  const strike =
    leg.strike_mode === "delta"
      ? leg.strike === 0.5
        ? "ATM"
        : leg.call_put === "C"
          ? `${Math.round(leg.strike * 100)}Δ`
          : `${Math.round((1 - leg.strike) * 100)}Δ`
      : leg.strike_mode === "pct_atm"
        ? `${Math.round(leg.strike * 100)}% ATM`
        : `${leg.strike}`;
  const expiry = leg.expiry ? new Date(leg.expiry).toLocaleDateString("en-GB", { month: "short", year: "2-digit" }) : "front";
  return `${qty} ${strike} ${leg.call_put === "C" ? "call" : "put"} ${expiry}`;
}

function ProposalCard({ card, rank, onLoad }: { card: Proposal; rank: number; onLoad: (card: Proposal, to: "/" | "/path") => void }) {
  const metrics: [string, string][] = [
    ["Premium", signed(card.premium)],
    ["Delta", signed(card.delta, 3)],
    ["Vega/pt", signed(card.vega_point, 2)],
    ["Theta/day", signed(card.theta_day, 2)],
    ["P(profit)", card.pop == null ? "—" : pct(card.pop, 0)],
  ];
  return (
    <div className="border border-line bg-sunken">
      <div className="flex items-baseline gap-2 border-b border-line px-2 py-1.5">
        <span className="num text-[10px] text-accent">#{rank}</span>
        <span className="text-[13px] text-ink">{card.label}</span>
      </div>
      <div className="space-y-1.5 px-2 py-1.5">
        <div className="flex flex-wrap gap-1">
          {(card.legs ?? []).map((leg, i) => (
            <span key={i} className={`num border px-1 text-[10px] ${leg.qty > 0 ? "border-accent/50 text-accent" : "border-down/50 text-down"}`}>
              {legText(leg)}
            </span>
          ))}
        </div>
        {card.error ? (
          <p className="text-down">{card.error}</p>
        ) : (
          <div className="grid grid-cols-5 gap-1">
            {metrics.map(([k, v]) => (
              <div key={k}>
                <div className="text-[9px] uppercase tracking-wide text-mute">{k}</div>
                <div className="num text-ink">{v}</div>
              </div>
            ))}
          </div>
        )}
        {card.rationale && <p className="text-[11px] leading-snug text-mute">{card.rationale}</p>}
        <div className="flex gap-1">
          <button className="btn btn-primary !py-0.5" disabled={!!card.error || !card.legs?.length} onClick={() => onLoad(card, "/")}>
            Load into Builder
          </button>
          <button className="btn !py-0.5" disabled={!!card.error || !card.legs?.length} onClick={() => onLoad(card, "/path")}>
            Try on a path
          </button>
        </div>
      </div>
    </div>
  );
}
