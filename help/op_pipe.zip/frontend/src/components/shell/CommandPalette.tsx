import { Command } from "cmdk";
import { useNavigate } from "react-router-dom";
import { useLab } from "../../store/lab";
import { NAV_GROUPS } from "./nav";

export function CommandPalette() {
  const open = useLab((s) => s.paletteOpen);
  const setOpen = useLab((s) => s.setPaletteOpen);
  const setResolver = useLab((s) => s.setResolverOpen);
  const setCopilot = useLab((s) => s.setCopilotOpen);
  const setMarket = useLab((s) => s.setMarketOpen);
  const setRegime = useLab((s) => s.setRegime);
  const navigate = useNavigate();

  function go(path: string) {
    navigate(path);
    setOpen(false);
  }

  return (
    <Command.Dialog open={open} onOpenChange={setOpen} label="Command palette">
      <Command.Input placeholder="Jump, set a regime, open the resolver" />
      <Command.List>
        <Command.Empty className="px-3 py-3 text-[13px] text-mute">Nothing matches.</Command.Empty>
        {NAV_GROUPS.map((group) => (
          <Command.Group key={group.name} heading={group.name}>
            {group.links.map((link) => (
              <Command.Item key={link.to} onSelect={() => go(link.to)} value={`${link.label} ${link.hint}`}>
                <span>
                  {link.label} <span className="ml-2 text-[11px] text-mute">{link.hint}</span>
                </span>
                <span className="text-mute">{link.key}</span>
              </Command.Item>
            ))}
          </Command.Group>
        ))}
        <Command.Group heading="Market">
          <Command.Item onSelect={() => { setMarket(true); setOpen(false); }}>Find market</Command.Item>
          <Command.Item onSelect={() => { setCopilot(true); setOpen(false); }}>Copilot <span className="text-mute">/</span></Command.Item>
          <Command.Item onSelect={() => { setResolver(true); setOpen(false); }}>Ticker resolver</Command.Item>
        </Command.Group>
        <Command.Group heading="Smile">
          <Command.Item onSelect={() => { setRegime("sticky-delta"); setOpen(false); }}>Sticky delta</Command.Item>
          <Command.Item onSelect={() => { setRegime("sticky-strike"); setOpen(false); }}>Sticky strike</Command.Item>
          <Command.Item onSelect={() => { setRegime("beta"); setOpen(false); }}>Beta, vol follows spot</Command.Item>
        </Command.Group>
      </Command.List>
    </Command.Dialog>
  );
}
