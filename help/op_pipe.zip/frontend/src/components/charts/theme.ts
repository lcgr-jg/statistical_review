import type { EChartsOption } from "echarts";

export const ink = "#e4e1d8";
export const mute = "#8d938c";
export const line = "#2a2f38";
export const accent = "#5ec8c5";
export const up = "#8faf88";
export const down = "#d0897a";
export const warn = "#d1a15a";

/** Diverging P&L scale: blue loss, slate zero, amber gain. Evenly spaced from -span to +span. */
export const pnlScale = ["#0b3a66", "#1f6aa5", "#8ec4e0", "#3c4452", "#e6c07b", "#e08a2e", "#c4511a"];

const pnlStops: [number, number, number][] = [
  [11, 58, 102],
  [31, 106, 165],
  [142, 196, 224],
  [60, 68, 82],
  [230, 192, 123],
  [224, 138, 46],
  [196, 81, 26],
];

export function pnlColor(value: number, span: number): string {
  const x = (Math.max(-1, Math.min(1, span > 0 ? value / span : 0)) + 1) / 2;
  const last = pnlStops.length - 1;
  const pos = x * last;
  const i = Math.min(last - 1, Math.floor(pos));
  const f = pos - i;
  const channel = pnlStops[i].map((start, k) => Math.round(start + (pnlStops[i + 1][k] - start) * f));
  return `rgb(${channel[0]}, ${channel[1]}, ${channel[2]})`;
}

export function pnlVisualMap(span: number) {
  return { show: false, min: -span, max: span, inRange: { color: pnlScale } };
}

const mono = "JetBrains Mono, ui-monospace, monospace";

export const tooltip = {
  backgroundColor: "#1b1f26",
  borderColor: line,
  textStyle: { color: ink, fontFamily: mono, fontSize: 11 },
};

export function axis() {
  return {
    axisLine: { lineStyle: { color: line } },
    axisTick: { show: false },
    axisLabel: { color: mute, fontFamily: mono, fontSize: 10 },
    splitLine: { lineStyle: { color: "rgba(255,255,255,0.04)" } },
    nameTextStyle: { color: mute, fontSize: 11 },
  };
}

export function baseOption(extra: EChartsOption = {}): EChartsOption {
  return {
    backgroundColor: "transparent",
    textStyle: { fontFamily: "Inter, sans-serif", color: mute },
    tooltip,
    grid: { left: 48, right: 16, top: 28, bottom: 32 },
    ...extra,
  };
}
