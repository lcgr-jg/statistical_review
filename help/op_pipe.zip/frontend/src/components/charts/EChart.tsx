import { forwardRef } from "react";
import ReactECharts from "echarts-for-react";
import type { EChartsOption } from "echarts";

type Props = {
  option: EChartsOption;
  height?: number | string;
};

export const EChart = forwardRef<ReactECharts, Props>(function EChart({ option, height = "100%" }, ref) {
  return (
    <ReactECharts
      ref={ref}
      option={option}
      style={{ height, width: "100%" }}
      notMerge
      opts={{ renderer: "canvas" }}
    />
  );
});
