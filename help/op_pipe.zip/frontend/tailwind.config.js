/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#14171c",
        raised: "#1b1f26",
        sunken: "#101216",
        line: "#2a2f38",
        ink: "#e4e1d8",
        mute: "#8d938c",
        accent: "#5ec8c5",
        up: "#8faf88",
        down: "#d0897a",
        warn: "#d1a15a",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
    },
  },
  plugins: [],
};
